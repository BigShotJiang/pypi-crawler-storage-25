class OABError(Exception):
    """Base exception for all ownAPIbridge SDK errors."""
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(OABError):
    """Raised when the API key is invalid, revoked, or expired."""


class ModelNotFoundError(OABError):
    """Raised when the requested model is not in the curated list."""


class ProviderError(OABError):
    """Raised when the upstream provider (OpenAI, Anthropic, etc.) returns an error."""


class RateLimitError(OABError):
    """Raised when you hit a rate limit."""
