from setuptools import setup, find_packages

setup(
    name="ownapibridge",
    version="0.1.0",
    description="Python client for the ownAPIbridge API — access 100+ AI models with one key",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="ownAPIbridge",
    python_requires=">=3.9",
    packages=find_packages(),
    install_requires=[],          # zero external dependencies
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
