# ownAPIbridge Python SDK

Access 10+ AI models (GPT, Claude, Gemini, DALL·E, and more) through a single API key.

## Install

```bash
pip install ownapibridge
# or from source:
pip install -e sdk/python
```

## Quick start

```python
from ownapibridge import OABClient

client = OABClient(
    api_key="sk-oab-your-key-here",
    base_url="http://localhost:8000",   # or your deployed server
)

# --- Chat ---
response = client.chat.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "What is the capital of France?"}],
)
print(response.content)   # Paris
print(response.total_tokens)

# --- Streaming ---
for chunk in client.chat.stream(model="claude-sonnet-4", messages=[
    {"role": "user", "content": "Write a haiku about code."}
]):
    print(chunk, end="", flush=True)

# --- List models ---
models = client.models.list()
for m in models:
    print(m.id, m.provider, f"${m.price_per_1m_input}/1M in")

# --- Image generation ---
image = client.images.generate(
    model="dall-e-3",
    prompt="A red fox in the snow, photorealistic",
)
print(image.url)

# --- Video generation ---
video = client.videos.generate(
    model="kling-v1-5",
    prompt="A timelapse of a flower blooming",
    duration=5,
)
print(video.url)
```

## Error handling

```python
from ownapibridge import OABClient, AuthenticationError, ModelNotFoundError, ProviderError

try:
    response = client.chat.create(model="gpt-4o", messages=[...])
except AuthenticationError:
    print("Invalid or expired API key")
except ModelNotFoundError:
    print("Model not found")
except ProviderError as e:
    print(f"Upstream provider error: {e}")
```

## Zero dependencies

The SDK uses only Python's standard library (`urllib`, `json`, `dataclasses`). No pip installs required beyond the package itself.

## API reference

### `OABClient(api_key, base_url)`

| Resource | Methods |
|---|---|
| `client.chat` | `.create(model, messages, temperature, max_tokens, system)` → `ChatResponse` |
| `client.chat` | `.stream(model, messages, ...)` → `Iterator[str]` |
| `client.models` | `.list()` → `list[ModelInfo]` |
| `client.images` | `.generate(model, prompt, size, quality, n)` → `ImageResponse` |
| `client.videos` | `.generate(model, prompt, duration, aspect_ratio)` → `VideoResponse` |


## Available models [id (name) - provider])
- gemini-3-1-pro (Gemini 3.1 Pro Preview) - google
- gpt-5.4 (GPT-5.4) - openai
- claude-opus-4 (Claude Opus 4.6) - anthropic
- claude-sonnet-4 (Claude Sonnet 4.6) - anthropic
- gpt-4o (GPT-4o) - openai
- gemini-3-flash (Gemini 3 Flash) - google
- claude-haiku-4 (Claude Haiku 4.5) - anthropic
- gpt-4o-mini (GPT-4o Mini) - openai
- deepseek-v3 (DeepSeek V3.2) - deepseek
- o3 (o3) - openai
- o4-mini (o4-mini) - openai
- gpt-4-1 (GPT-4.1) - openai
- gpt-4-1-mini (GPT-4.1 Mini) - openai
- gemini-2-0-flash (Gemini 2.0 Flash) - google
- llama-4-maverick (Llama 4 Maverick) - groq
- llama-3-3-70b (Llama 3.3 70B) - groq
- qwq-32b (QwQ-32B) - groq
- deepseek-r1 (DeepSeek R1) - deepseek
