# Benchmark Reference — xwquery

**Library:** exonware-xwquery  
**Produced by:** `GUIDE_54_BENCH.md`  
**Last Updated:** (from `version.get_date()` at build time)

---

## Purpose

Performance **SLAs** and **benchmark campaign** pointers for xwquery (GUIDE_54_BENCH). Benchmark evidence lives under **`benchmarks/`** at the project root when campaigns are run.

---

## Targets (initial)

| Workload | Metric | Target | Status |
|----------|--------|--------|--------|
| **Core import** | `import exonware.xwquery` | Cold import acceptable on dev hardware | TBD — run campaign |
| **Parse round-trip** | Representative SQL / XWQS samples | No unbounded regression vs baseline | TBD |

---

## Campaigns

- **None committed as baseline yet.** When adding a campaign, use `benchmarks/YYYYMMDD-benchmark <title>/` per GUIDE_00_MASTER / GUIDE_54_BENCH and link the run here.

---

## Related

- [GUIDE_54_BENCH.md](../../.docs/guides/GUIDE_54_BENCH.md) — methodology (central guide)  
- [REF_22_PROJECT.md](REF_22_PROJECT.md) — performance NFRs
