# Quality Assurance Reference — xwquery

**Library:** exonware-xwquery  
**Produced by:** `GUIDE_50_QA.md`  
**Last Updated:** (from `version.get_date()` at build time)

---

## Purpose

Canonical **quality gates** and **current readiness** state for xwquery (GUIDE_50_QA). Use with `REF_51_TEST.md` and `docs/logs/tests/`.

---

## Release gates (target)

| Gate | Criterion | Owner |
|------|-----------|--------|
| **Tests** | Core + unit suites pass for the release branch; no skipped tests masking failures | GUIDE_51_TEST |
| **Regression** | Fixes include regression tests per GUIDE_53_FIX | GUIDE_53_FIX |
| **Docs** | REF_* aligned with `README.md` and public API (GUIDE_63_README, GUIDE_15_API) | GUIDE_41_DOCS |
| **Security** | No known injection surfaces in untrusted query paths without documented mitigation | GUIDE_31_DEV |

---

## Current readiness

| Area | Status | Notes |
|------|--------|--------|
| **Alpha** | Active | Large surface (many strategies/executors); FR-005 (4-layer tests) in progress per REF_22_PROJECT |
| **Go / No-Go** | Not set for production | Treat as **alpha** until gates above are explicitly green |

---

## Related

- [REF_51_TEST.md](REF_51_TEST.md) — test status and coverage  
- [REF_22_PROJECT.md](REF_22_PROJECT.md) — milestones and NFRs  
- [GUIDE_50_QA.md](../../.docs/guides/GUIDE_50_QA.md) — methodology (central guide)
