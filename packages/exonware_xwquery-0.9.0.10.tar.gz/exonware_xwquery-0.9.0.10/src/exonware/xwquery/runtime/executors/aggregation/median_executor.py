#!/usr/bin/env python3
"""
MEDIAN Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.10
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class MedianExecutor(AUniversalOperationExecutor):
    """MEDIAN operation executor."""

    OPERATION_NAME = "MEDIAN"
    OPERATION_TYPE = OperationType.AGGREGATION
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params or {}
        data = self._execute_median(context.node, params)
        return ExecutionResult(
            success=True,
            data=data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _execute_median(self, node: Any, params: dict[str, Any]) -> dict[str, Any]:
        items = extract_items(node)
        field: Optional[str] = params.get("field")
        as_field = params.get("as_field", "median")
        values = self._extract_numeric_values(items, field)
        values.sort()

        median = self._compute_median(values)
        return {
            as_field: median,
            "count": len(values),
            "field": field,
        }

    def _extract_numeric_values(self, items: list[Any], field: Optional[str]) -> list[float]:
        values: list[float] = []
        for item in items:
            raw = extract_field_value(item, field) if field else item
            numeric = self._to_number(raw)
            if numeric is not None:
                values.append(numeric)
        return values

    def _compute_median(self, values: list[float]) -> Optional[float]:
        n = len(values)
        if n == 0:
            return None
        mid = n // 2
        if n % 2 == 1:
            return values[mid]
        return (values[mid - 1] + values[mid]) / 2.0

    def _to_number(self, value: Any) -> Optional[float]:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            try:
                return float(value)
            except ValueError:
                return None
        return None


__all__ = ["MedianExecutor"]
