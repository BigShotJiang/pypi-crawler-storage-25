#!/usr/bin/env python3
"""
ROW_NUMBER Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.10
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class RowNumberExecutor(AUniversalOperationExecutor):
    """ROW_NUMBER - Assign sequential numbers within partitions."""
    OPERATION_NAME = "ROW_NUMBER"
    OPERATION_TYPE = OperationType.ADVANCED
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_row_number(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _partition_key(self, item: Any, partition_by: Optional[list[str]]) -> Any:
        if not partition_by:
            return "__all__"
        return tuple(extract_field_value(item, field) for field in partition_by)

    def _sort_items(self, items: list[Any], order_by: Optional[Any]) -> list[Any]:
        if not order_by:
            return list(items)
        if isinstance(order_by, dict):
            field = order_by.get("field")
            direction = str(order_by.get("direction", "asc")).lower()
        else:
            field = str(order_by)
            direction = "asc"
        reverse = direction == "desc"
        return sorted(items, key=lambda it: extract_field_value(it, field), reverse=reverse)

    def _execute_row_number(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        items = extract_items(node)
        partition_by = params.get("partition_by")
        order_by = params.get("order_by")
        as_field = params.get("as_field", "_row_number")
        if partition_by and not isinstance(partition_by, list):
            partition_by = [partition_by]

        partitions: dict[Any, list[Any]] = {}
        for item in items:
            partitions.setdefault(self._partition_key(item, partition_by), []).append(item)

        output = []
        for _, part_items in partitions.items():
            sorted_items = self._sort_items(part_items, order_by)
            for index, item in enumerate(sorted_items, start=1):
                record = dict(item) if isinstance(item, dict) else {"value": item}
                record[as_field] = index
                output.append(record)

        return {
            "items": output,
            "count": len(output),
            "partition_count": len(partitions),
            "as_field": as_field,
        }
