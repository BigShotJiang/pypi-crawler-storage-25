"""
Query Operation Executors
This package implements the execution layer for 195 XWQuery Script operations.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.10
Generation Date: 11-Oct-2025
"""

from .contracts import (
    IOperationExecutor,
    QueryAction,
    ExecutionContext,
    ExecutionResult
)
from .defs import OperationCapability, OperationType, ExecutionStatus
from .errors import ExecutorError, OperationExecutionError, ValidationError, UnsupportedOperationError
from .base import AOperationExecutor
from .registry import OperationRegistry, get_operation_registry, register_operation
from .engine import NativeOperationsExecutionEngine
# ============================================================================
# Import all executors from all categories
# ============================================================================
# CORE (9)
from .core import (
    SelectExecutor, InsertExecutor, UpdateExecutor, DeleteExecutor,
    CreateExecutor, DropExecutor, TruncateExecutor, UpsertExecutor, ExplainExecutor
)
# FILTERING (21)
from .filtering import (
    WhereExecutor, FilterExecutor, LikeExecutor, InExecutor, HasExecutor,
    BetweenExecutor, RangeExecutor, TermExecutor, OptionalExecutor, ValuesExecutor,
    ExistsExecutor, NotInExecutor, IsNullExecutor, ContainsExecutor,
    StartsWithExecutor, EndsWithExecutor, RegexExecutor, FuzzyExecutor,
    IsMissingExecutor, AnyMatchExecutor, AllMatchExecutor
)
# AGGREGATION (18)
from .aggregation import (
    CountExecutor, SumExecutor, AvgExecutor, MinExecutor, MaxExecutor,
    DistinctExecutor, GroupExecutor, HavingExecutor, SummarizeExecutor,
    CollectExecutor, ReduceExecutor, StddevExecutor, VarianceExecutor,
    MedianExecutor, PercentileExecutor, FirstValueExecutor, LastValueExecutor,
    GroupConcatExecutor
)
# PROJECTION (2)
from .projection import ProjectExecutor, ExtendExecutor
# ORDERING (3 + alias)
from .ordering import OrderExecutor, ByExecutor, LimitExecutor
# GRAPH (40)
from .graph import (
    MatchExecutor, PathExecutor, OutExecutor, InTraverseExecutor, ReturnExecutor,
    AllPathsExecutor, AllShortestPathsExecutor, AllSimplePathsExecutor,
    BothExecutor, BothEExecutor, BothVExecutor, InEExecutor, InVExecutor,
    OutEExecutor, OutVExecutor, CloneExecutor, ConnectedComponentsExecutor,
    CreateEdgeExecutor, CycleDetectionExecutor, DeleteEdgeExecutor,
    DetachDeleteExecutor, DegreeExecutor, ExpandExecutor, ExtractPathExecutor,
    NeighborsExecutor, PathLengthExecutor, PropertiesExecutor, SetExecutor,
    ShortestPathExecutor, SimplePathExecutor, SubgraphExecutor,
    TraversalExecutor, UpdateEdgeExecutor, VariablePathExecutor,
    RepeatExecutor, CoalesceStepExecutor, ChooseExecutor,
    AddVertexExecutor, DropVertexExecutor, PageRankExecutor
)
# DATA (9)
from .data import (
    LoadExecutor, StoreExecutor, MergeExecutor, AlterExecutor, FileSourceExecutor,
    ImportExecutor, ExportExecutor, CopyExecutor, BulkWriteExecutor
)
# ARRAY (12)
from .array import (
    SlicingExecutor, IndexingExecutor,
    UnwindExecutor, FlattenExecutor, ArrayLengthExecutor, ArrayContainsExecutor,
    ArraySortExecutor, ArrayReverseExecutor, ArrayConcatExecutor,
    ArrayDistinctExecutor, PushExecutor, PopExecutor
)
# ADVANCED (26)
from .advanced import (
    JoinExecutor, IncludeExecutor, UnionExecutor, MinusExecutor, WithCteExecutor,
    AggregateExecutor, ForeachExecutor, LetExecutor, ForLoopExecutor, WindowExecutor,
    DescribeExecutor, ConstructExecutor, AskExecutor,
    SubscribeExecutor, SubscriptionExecutor, MutationExecutor,
    PipeExecutor, OptionsExecutor,
    IntersectExecutor, SubqueryExecutor, PivotExecutor, UnpivotExecutor,
    RowNumberExecutor, RankExecutor, DenseRankExecutor, RecursiveCteExecutor
)
# CONDITIONAL (5) - new category
from .conditional import (
    CaseExecutor, CoalesceExecutor, NullifExecutor, IfExprExecutor, SwitchExecutor
)
# STRING (15) - new category
from .string import (
    ConcatExecutor, SubstringExecutor, UpperExecutor, LowerExecutor, TrimExecutor,
    ReplaceStrExecutor, SplitStrExecutor, LengthExecutor, LpadExecutor, RpadExecutor,
    ReverseStrExecutor, PositionExecutor, RepeatStrExecutor,
    RegexExtractExecutor, RegexReplaceExecutor
)
# MATH (14) - new category
from .math import (
    AbsExecutor, CeilExecutor, FloorExecutor, RoundExecutor, PowerExecutor,
    SqrtExecutor, ModExecutor, LogExecutor, ExpExecutor, SignExecutor,
    RandomExecutor, GreatestExecutor, LeastExecutor, TruncExecutor
)
# DATETIME (10) - new category
from .datetime import (
    NowExecutor, DateAddExecutor, DateDiffExecutor, ExtractDateExecutor,
    DateFormatExecutor, DateParseExecutor, DateTruncExecutor, IntervalExecutor,
    UnixTimestampExecutor, FromUnixtimeExecutor
)
# TYPE (9) - new category
from .type import (
    CastExecutor, TypeofExecutor, TryCastExecutor, ToStringExecutor,
    ToNumberExecutor, ToBooleanExecutor, ToDateExecutor,
    IsNumberExecutor, IsStringExecutor
)
# ============================================================================
# Register all operations
# ============================================================================
_registry = get_operation_registry()
# Register CORE operations (9)
_registry.register('SELECT', SelectExecutor)
_registry.register('INSERT', InsertExecutor)
_registry.register('UPDATE', UpdateExecutor)
_registry.register('DELETE', DeleteExecutor)
_registry.register('CREATE', CreateExecutor)
_registry.register('DROP', DropExecutor)
_registry.register('TRUNCATE', TruncateExecutor)
_registry.register('UPSERT', UpsertExecutor)
_registry.register('EXPLAIN', ExplainExecutor)
# Register FILTERING operations (21)
_registry.register('WHERE', WhereExecutor)
_registry.register('FILTER', FilterExecutor)
_registry.register('LIKE', LikeExecutor)
_registry.register('IN', InExecutor)
_registry.register('HAS', HasExecutor)
_registry.register('BETWEEN', BetweenExecutor)
_registry.register('RANGE', RangeExecutor)
_registry.register('TERM', TermExecutor)
_registry.register('OPTIONAL', OptionalExecutor)
_registry.register('VALUES', ValuesExecutor)
_registry.register('EXISTS', ExistsExecutor)
_registry.register('NOT_IN', NotInExecutor)
_registry.register('IS_NULL', IsNullExecutor)
_registry.register('CONTAINS', ContainsExecutor)
_registry.register('STARTS_WITH', StartsWithExecutor)
_registry.register('ENDS_WITH', EndsWithExecutor)
_registry.register('REGEX', RegexExecutor)
_registry.register('FUZZY', FuzzyExecutor)
_registry.register('IS_MISSING', IsMissingExecutor)
_registry.register('ANY_MATCH', AnyMatchExecutor)
_registry.register('ALL_MATCH', AllMatchExecutor)
# Register AGGREGATION operations (18)
_registry.register('COUNT', CountExecutor)
_registry.register('SUM', SumExecutor)
_registry.register('AVG', AvgExecutor)
_registry.register('MIN', MinExecutor)
_registry.register('MAX', MaxExecutor)
_registry.register('DISTINCT', DistinctExecutor)
_registry.register('GROUP', GroupExecutor)
_registry.register('HAVING', HavingExecutor)
_registry.register('SUMMARIZE', SummarizeExecutor)
_registry.register('COLLECT', CollectExecutor)
_registry.register('REDUCE', ReduceExecutor)
_registry.register('STDDEV', StddevExecutor)
_registry.register('VARIANCE', VarianceExecutor)
_registry.register('MEDIAN', MedianExecutor)
_registry.register('PERCENTILE', PercentileExecutor)
_registry.register('FIRST_VALUE', FirstValueExecutor)
_registry.register('LAST_VALUE', LastValueExecutor)
_registry.register('GROUP_CONCAT', GroupConcatExecutor)
# Register PROJECTION operations (2)
_registry.register('PROJECT', ProjectExecutor)
_registry.register('EXTEND', ExtendExecutor)
# Register ORDERING operations (4)
_registry.register('ORDER', OrderExecutor)
_registry.register('BY', ByExecutor)
_registry.register('LIMIT', LimitExecutor)
_registry.register('OFFSET', LimitExecutor)
# Register GRAPH operations (40)
_registry.register('MATCH', MatchExecutor)
_registry.register('PATH', PathExecutor)
_registry.register('OUT', OutExecutor)
_registry.register('IN_TRAVERSE', InTraverseExecutor)
_registry.register('RETURN', ReturnExecutor)
_registry.register('ALL_PATHS', AllPathsExecutor)
_registry.register('ALL_SHORTEST_PATHS', AllShortestPathsExecutor)
_registry.register('ALL_SIMPLE_PATHS', AllSimplePathsExecutor)
_registry.register('BOTH', BothExecutor)
_registry.register('bothE', BothEExecutor)
_registry.register('bothV', BothVExecutor)
_registry.register('inE', InEExecutor)
_registry.register('inV', InVExecutor)
_registry.register('outE', OutEExecutor)
_registry.register('outV', OutVExecutor)
_registry.register('CLONE', CloneExecutor)
_registry.register('CONNECTED_COMPONENTS', ConnectedComponentsExecutor)
_registry.register('CREATE_EDGE', CreateEdgeExecutor)
_registry.register('CYCLE_DETECTION', CycleDetectionExecutor)
_registry.register('DELETE_EDGE', DeleteEdgeExecutor)
_registry.register('DETACH_DELETE', DetachDeleteExecutor)
_registry.register('DEGREE', DegreeExecutor)
_registry.register('EXPAND', ExpandExecutor)
_registry.register('EXTRACT_PATH', ExtractPathExecutor)
_registry.register('NEIGHBORS', NeighborsExecutor)
_registry.register('PATH_LENGTH', PathLengthExecutor)
_registry.register('PROPERTIES', PropertiesExecutor)
_registry.register('SET', SetExecutor)
_registry.register('SHORTEST_PATH', ShortestPathExecutor)
_registry.register('SIMPLE_PATH', SimplePathExecutor)
_registry.register('SUBGRAPH', SubgraphExecutor)
_registry.register('TRAVERSAL', TraversalExecutor)
_registry.register('UPDATE_EDGE', UpdateEdgeExecutor)
_registry.register('VARIABLE_PATH', VariablePathExecutor)
_registry.register('REPEAT', RepeatExecutor)
_registry.register('COALESCE_STEP', CoalesceStepExecutor)
_registry.register('CHOOSE', ChooseExecutor)
_registry.register('ADD_VERTEX', AddVertexExecutor)
_registry.register('DROP_VERTEX', DropVertexExecutor)
_registry.register('PAGE_RANK', PageRankExecutor)
# Register DATA operations (9)
_registry.register('LOAD', LoadExecutor)
_registry.register('STORE', StoreExecutor)
_registry.register('MERGE', MergeExecutor)
_registry.register('ALTER', AlterExecutor)
_registry.register('FILE_SOURCE', FileSourceExecutor)
_registry.register('IMPORT', ImportExecutor)
_registry.register('EXPORT', ExportExecutor)
_registry.register('COPY', CopyExecutor)
_registry.register('BULK_WRITE', BulkWriteExecutor)
# Register ARRAY operations (12)
_registry.register('SLICING', SlicingExecutor)
_registry.register('INDEXING', IndexingExecutor)
_registry.register('UNWIND', UnwindExecutor)
_registry.register('FLATTEN', FlattenExecutor)
_registry.register('ARRAY_LENGTH', ArrayLengthExecutor)
_registry.register('ARRAY_CONTAINS', ArrayContainsExecutor)
_registry.register('ARRAY_SORT', ArraySortExecutor)
_registry.register('ARRAY_REVERSE', ArrayReverseExecutor)
_registry.register('ARRAY_CONCAT', ArrayConcatExecutor)
_registry.register('ARRAY_DISTINCT', ArrayDistinctExecutor)
_registry.register('PUSH', PushExecutor)
_registry.register('POP', PopExecutor)
# Register ADVANCED operations (26)
_registry.register('JOIN', JoinExecutor)
_registry.register('INCLUDE', IncludeExecutor)
_registry.register('UNION', UnionExecutor)
_registry.register('MINUS', MinusExecutor)
_registry.register('WITH', WithCteExecutor)
_registry.register('AGGREGATE', AggregateExecutor)
_registry.register('FOREACH', ForeachExecutor)
_registry.register('LET', LetExecutor)
_registry.register('FOR', ForLoopExecutor)
_registry.register('WINDOW', WindowExecutor)
_registry.register('DESCRIBE', DescribeExecutor)
_registry.register('CONSTRUCT', ConstructExecutor)
_registry.register('ASK', AskExecutor)
_registry.register('SUBSCRIBE', SubscribeExecutor)
_registry.register('SUBSCRIPTION', SubscriptionExecutor)
_registry.register('MUTATION', MutationExecutor)
_registry.register('PIPE', PipeExecutor)
_registry.register('OPTIONS', OptionsExecutor)
_registry.register('INTERSECT', IntersectExecutor)
_registry.register('SUBQUERY', SubqueryExecutor)
_registry.register('PIVOT', PivotExecutor)
_registry.register('UNPIVOT', UnpivotExecutor)
_registry.register('ROW_NUMBER', RowNumberExecutor)
_registry.register('RANK', RankExecutor)
_registry.register('DENSE_RANK', DenseRankExecutor)
_registry.register('RECURSIVE_CTE', RecursiveCteExecutor)
# Register CONDITIONAL operations (5)
_registry.register('CASE', CaseExecutor)
_registry.register('COALESCE', CoalesceExecutor)
_registry.register('NULLIF', NullifExecutor)
_registry.register('IF_EXPR', IfExprExecutor)
_registry.register('SWITCH', SwitchExecutor)
# Register STRING operations (15)
_registry.register('CONCAT', ConcatExecutor)
_registry.register('SUBSTRING', SubstringExecutor)
_registry.register('UPPER', UpperExecutor)
_registry.register('LOWER', LowerExecutor)
_registry.register('TRIM', TrimExecutor)
_registry.register('REPLACE_STR', ReplaceStrExecutor)
_registry.register('SPLIT', SplitStrExecutor)
_registry.register('LENGTH', LengthExecutor)
_registry.register('LPAD', LpadExecutor)
_registry.register('RPAD', RpadExecutor)
_registry.register('REVERSE_STR', ReverseStrExecutor)
_registry.register('POSITION', PositionExecutor)
_registry.register('REPEAT_STR', RepeatStrExecutor)
_registry.register('REGEX_EXTRACT', RegexExtractExecutor)
_registry.register('REGEX_REPLACE', RegexReplaceExecutor)
# Register MATH operations (14)
_registry.register('ABS', AbsExecutor)
_registry.register('CEIL', CeilExecutor)
_registry.register('FLOOR', FloorExecutor)
_registry.register('ROUND', RoundExecutor)
_registry.register('POWER', PowerExecutor)
_registry.register('SQRT', SqrtExecutor)
_registry.register('MOD', ModExecutor)
_registry.register('LOG', LogExecutor)
_registry.register('EXP', ExpExecutor)
_registry.register('SIGN', SignExecutor)
_registry.register('RANDOM', RandomExecutor)
_registry.register('GREATEST', GreatestExecutor)
_registry.register('LEAST', LeastExecutor)
_registry.register('TRUNC', TruncExecutor)
# Register DATETIME operations (10)
_registry.register('NOW', NowExecutor)
_registry.register('DATE_ADD', DateAddExecutor)
_registry.register('DATE_DIFF', DateDiffExecutor)
_registry.register('EXTRACT_DATE', ExtractDateExecutor)
_registry.register('DATE_FORMAT', DateFormatExecutor)
_registry.register('DATE_PARSE', DateParseExecutor)
_registry.register('DATE_TRUNC', DateTruncExecutor)
_registry.register('INTERVAL', IntervalExecutor)
_registry.register('UNIX_TIMESTAMP', UnixTimestampExecutor)
_registry.register('FROM_UNIXTIME', FromUnixtimeExecutor)
# Register TYPE operations (9)
_registry.register('CAST', CastExecutor)
_registry.register('TYPEOF', TypeofExecutor)
_registry.register('TRY_CAST', TryCastExecutor)
_registry.register('TO_STRING', ToStringExecutor)
_registry.register('TO_NUMBER', ToNumberExecutor)
_registry.register('TO_BOOLEAN', ToBooleanExecutor)
_registry.register('TO_DATE', ToDateExecutor)
_registry.register('IS_NUMBER', IsNumberExecutor)
_registry.register('IS_STRING', IsStringExecutor)
__all__ = [
    'IOperationExecutor', 'QueryAction', 'ExecutionContext', 'ExecutionResult',
    'OperationCapability', 'OperationType', 'ExecutionStatus',
    'ExecutorError', 'OperationExecutionError', 'ValidationError', 'UnsupportedOperationError',
    'AOperationExecutor', 'NativeOperationsExecutionEngine',
    'OperationRegistry', 'get_operation_registry', 'register_operation',
]
