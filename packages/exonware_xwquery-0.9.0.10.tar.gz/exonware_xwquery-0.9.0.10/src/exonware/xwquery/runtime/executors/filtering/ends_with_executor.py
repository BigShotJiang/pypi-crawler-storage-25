#!/usr/bin/env python3
"""
ENDS_WITH Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.10
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class EndsWithExecutor(AUniversalOperationExecutor):
    """Filter items where a field ends with a suffix. O(n)."""

    OPERATION_NAME = "ENDS_WITH"
    OPERATION_TYPE = OperationType.FILTERING
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        field = params.get("field")
        suffix = params.get("suffix")
        case_sensitive = params.get("case_sensitive", True)
        path = params.get("path", None)

        if not field:
            return ExecutionResult(
                success=False,
                data=None,
                error=f"ENDS_WITH requires 'field'. Got: {action.params}",
                action_type=self.OPERATION_NAME,
            )

        if suffix is None:
            return ExecutionResult(
                success=False,
                data=None,
                error=f"ENDS_WITH requires 'suffix'. Got: {action.params}",
                action_type=self.OPERATION_NAME,
            )

        result_data = self._execute_ends_with(context.node, field, suffix, case_sensitive, path)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"matched_count": len(result_data.get("items", []))},
        )

    def _execute_ends_with(
        self,
        node: Any,
        field: str,
        suffix: Any,
        case_sensitive: bool,
        path: Optional[str],
    ) -> dict:
        if path:
            try:
                data = node.get(path, default=None)
            except Exception:
                data = None
        else:
            data = node

        items = extract_items(data)
        suffix_text = str(suffix)
        if not case_sensitive:
            suffix_text = suffix_text.lower()

        matched_items = []
        for item in items:
            field_value = extract_field_value(item, field)
            if field_value is None:
                continue
            value_text = str(field_value)
            if not case_sensitive:
                value_text = value_text.lower()
            if value_text.endswith(suffix_text):
                matched_items.append(item)

        return {
            "items": matched_items,
            "count": len(matched_items),
            "total_items": len(items),
            "field": field,
            "suffix": suffix,
            "case_sensitive": bool(case_sensitive),
        }


__all__ = ["EndsWithExecutor"]
