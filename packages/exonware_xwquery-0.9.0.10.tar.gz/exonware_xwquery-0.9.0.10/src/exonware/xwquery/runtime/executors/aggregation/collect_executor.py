#!/usr/bin/env python3
"""
COLLECT Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.10
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class CollectExecutor(AUniversalOperationExecutor):
    """COLLECT operation executor."""

    OPERATION_NAME = "COLLECT"
    OPERATION_TYPE = OperationType.AGGREGATION
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params or {}
        data = self._execute_collect(context.node, params)
        return ExecutionResult(
            success=True,
            data=data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _execute_collect(self, node: Any, params: dict[str, Any]) -> dict[str, Any]:
        items = extract_items(node)
        field: Optional[str] = params.get("field")
        unique = bool(params.get("unique", False))
        as_field = params.get("as_field", "collect")

        values: list[Any] = []
        seen: set[str] = set()
        for item in items:
            value = extract_field_value(item, field) if field else item
            if unique:
                marker = repr(value)
                if marker in seen:
                    continue
                seen.add(marker)
            values.append(value)

        return {
            as_field: values,
            "count": len(values),
            "field": field,
            "unique": unique,
        }


__all__ = ["CollectExecutor"]
