"""
Compatibility shim for query format detection.

Canonical implementation moved to `exonware.xwsyntax.query_format_detector`.
"""

from exonware.xwsyntax import QueryFormatDetector, detect_query_format

__all__ = ["QueryFormatDetector", "detect_query_format"]
