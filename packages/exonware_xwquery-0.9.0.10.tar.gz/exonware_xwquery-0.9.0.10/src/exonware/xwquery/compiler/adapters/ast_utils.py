"""
Compatibility shim for AST utilities.

Canonical implementations moved to `exonware.xwsyntax.ast_utils`.
"""

from exonware.xwsyntax.ast_utils import *  # noqa: F401,F403
