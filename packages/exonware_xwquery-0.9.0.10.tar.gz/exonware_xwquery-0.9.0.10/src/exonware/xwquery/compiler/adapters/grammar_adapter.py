"""
Compatibility shim for grammar adapter.

Canonical implementation moved to `exonware.xwsyntax.query_grammar_adapter`.
"""

from exonware.xwsyntax.query_grammar_adapter import (
    UniversalGrammarAdapter,
    SQLGrammarAdapter,
    GraphQLGrammarAdapter,
    CypherGrammarAdapter,
    MongoDBGrammarAdapter,
    SPARQLGrammarAdapter,
)

__all__ = [
    "UniversalGrammarAdapter",
    "SQLGrammarAdapter",
    "GraphQLGrammarAdapter",
    "CypherGrammarAdapter",
    "MongoDBGrammarAdapter",
    "SPARQLGrammarAdapter",
]
