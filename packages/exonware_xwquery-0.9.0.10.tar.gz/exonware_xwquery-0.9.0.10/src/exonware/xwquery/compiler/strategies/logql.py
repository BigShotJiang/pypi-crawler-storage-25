from exonware.xwquery.strategies.logql import LogQLStrategy
LogqlStrategy = LogQLStrategy
__all__ = ["LogQLStrategy", "LogqlStrategy"]
