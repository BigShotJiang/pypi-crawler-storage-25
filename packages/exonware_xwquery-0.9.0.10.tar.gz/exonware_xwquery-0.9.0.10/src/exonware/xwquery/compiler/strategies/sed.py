from .compat_passthrough import CompatPassthroughStrategy


class SedStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SED"


__all__ = ["SedStrategy"]
