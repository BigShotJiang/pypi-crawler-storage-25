from .compat_passthrough import CompatPassthroughStrategy

class SurrealQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SURREALQL"

__all__ = ["SurrealQLStrategy"]
