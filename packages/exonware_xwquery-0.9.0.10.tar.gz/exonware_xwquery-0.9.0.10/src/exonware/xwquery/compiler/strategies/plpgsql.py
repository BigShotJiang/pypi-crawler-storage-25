from .compat_passthrough import CompatPassthroughStrategy

class PLpgSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "PLPGSQL"

__all__ = ["PLpgSQLStrategy"]
