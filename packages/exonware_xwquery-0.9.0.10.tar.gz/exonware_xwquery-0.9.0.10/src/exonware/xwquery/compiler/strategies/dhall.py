from .compat_passthrough import CompatPassthroughStrategy


class DhallStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "DHALL"


__all__ = ["DhallStrategy"]
