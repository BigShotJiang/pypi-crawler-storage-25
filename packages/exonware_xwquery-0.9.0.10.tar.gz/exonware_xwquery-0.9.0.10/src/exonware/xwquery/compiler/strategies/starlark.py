from .compat_passthrough import CompatPassthroughStrategy


class StarlarkStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "STARLARK"


__all__ = ["StarlarkStrategy"]
