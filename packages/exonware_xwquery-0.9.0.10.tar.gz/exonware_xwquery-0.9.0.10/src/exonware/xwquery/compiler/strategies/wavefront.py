from .compat_passthrough import CompatPassthroughStrategy


class WavefrontStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "WAVEFRONT"


__all__ = ["WavefrontStrategy"]
