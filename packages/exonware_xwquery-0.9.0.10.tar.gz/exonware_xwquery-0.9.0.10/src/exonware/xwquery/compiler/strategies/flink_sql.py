from .compat_passthrough import CompatPassthroughStrategy

class FlinkSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "FLINK_SQL"

__all__ = ["FlinkSQLStrategy"]
