from .compat_passthrough import CompatPassthroughStrategy

class PLPythonStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "PLPYTHON"

__all__ = ["PLPythonStrategy"]
