from .compat_passthrough import CompatPassthroughStrategy


class OpenSearchDSLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "OPENSEARCH_DSL"


__all__ = ["OpenSearchDSLStrategy"]
