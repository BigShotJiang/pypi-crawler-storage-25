from .compat_passthrough import CompatPassthroughStrategy

class TICKStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "TICK"

__all__ = ["TICKStrategy"]
