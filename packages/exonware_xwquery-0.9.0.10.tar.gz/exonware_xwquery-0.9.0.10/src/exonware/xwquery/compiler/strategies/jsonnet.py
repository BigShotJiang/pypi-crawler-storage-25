from .compat_passthrough import CompatPassthroughStrategy


class JsonnetStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "JSONNET"


__all__ = ["JsonnetStrategy"]
