from .compat_passthrough import CompatPassthroughStrategy

class SumoLogicStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SUMOLOGIC"

__all__ = ["SumoLogicStrategy"]
