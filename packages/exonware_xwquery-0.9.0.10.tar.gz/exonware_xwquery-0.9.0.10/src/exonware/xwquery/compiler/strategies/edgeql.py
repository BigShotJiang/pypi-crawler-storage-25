from .compat_passthrough import CompatPassthroughStrategy

class EdgeQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "EDGEQL"

__all__ = ["EdgeQLStrategy"]
