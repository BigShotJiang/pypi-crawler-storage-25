from exonware.xwquery.strategies.kql import KQLStrategy
KqlStrategy = KQLStrategy
__all__ = ["KQLStrategy", "KqlStrategy"]
