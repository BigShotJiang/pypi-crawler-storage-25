from .compat_passthrough import CompatPassthroughStrategy

class ODataStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "ODATA"

__all__ = ["ODataStrategy"]
