from .compat_passthrough import CompatPassthroughStrategy

class DrillStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "DRILL"

__all__ = ["DrillStrategy"]
