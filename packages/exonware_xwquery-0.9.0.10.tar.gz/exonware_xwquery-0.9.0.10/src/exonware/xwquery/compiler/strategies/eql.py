from exonware.xwquery.strategies.eql import EQLStrategy
EqlStrategy = EQLStrategy
__all__ = ["EQLStrategy", "EqlStrategy"]
