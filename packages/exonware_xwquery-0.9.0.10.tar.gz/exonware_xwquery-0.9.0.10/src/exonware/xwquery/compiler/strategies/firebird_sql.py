from .compat_passthrough import CompatPassthroughStrategy

class FirebirdSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "FIREBIRD_SQL"

__all__ = ["FirebirdSQLStrategy"]
