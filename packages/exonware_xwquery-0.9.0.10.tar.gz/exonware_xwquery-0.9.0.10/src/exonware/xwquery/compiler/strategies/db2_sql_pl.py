from .compat_passthrough import CompatPassthroughStrategy

class Db2SQLPLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "DB2_SQL_PL"

__all__ = ["Db2SQLPLStrategy"]
