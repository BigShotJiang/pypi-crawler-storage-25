from .compat_passthrough import CompatPassthroughStrategy

class OpenSearchPPLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "OPENSEARCH_PPL"

__all__ = ["OpenSearchPPLStrategy"]
