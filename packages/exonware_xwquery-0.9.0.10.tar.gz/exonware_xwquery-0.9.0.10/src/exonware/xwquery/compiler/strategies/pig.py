from exonware.xwquery.strategies.pig import PigStrategy
__all__ = ["PigStrategy", "PigStrategy"]
