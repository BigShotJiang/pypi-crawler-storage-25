from .compat_passthrough import CompatPassthroughStrategy


class M3QLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "M3QL"


__all__ = ["M3QLStrategy"]
