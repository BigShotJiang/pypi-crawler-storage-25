from .compat_passthrough import CompatPassthroughStrategy

class DatabricksSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "DATABRICKS_SQL"

__all__ = ["DatabricksSQLStrategy"]
