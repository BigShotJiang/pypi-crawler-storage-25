from .compat_passthrough import CompatPassthroughStrategy

class SPLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SPL"

__all__ = ["SPLStrategy"]
