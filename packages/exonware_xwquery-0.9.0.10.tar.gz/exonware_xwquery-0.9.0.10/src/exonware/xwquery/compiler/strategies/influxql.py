from .compat_passthrough import CompatPassthroughStrategy

class InfluxQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "INFLUXQL"

__all__ = ["InfluxQLStrategy"]
