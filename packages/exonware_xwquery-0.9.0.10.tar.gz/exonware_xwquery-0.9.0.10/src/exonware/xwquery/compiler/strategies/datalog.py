"""Compatibility shim for legacy compiler strategy imports."""

from ...strategies.datalog import DatalogStrategy

__all__ = ["DatalogStrategy"]

