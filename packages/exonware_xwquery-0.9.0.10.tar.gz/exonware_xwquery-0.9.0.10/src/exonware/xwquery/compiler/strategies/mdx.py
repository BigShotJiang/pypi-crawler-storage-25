from .compat_passthrough import CompatPassthroughStrategy

class MDXStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "MDX"

__all__ = ["MDXStrategy"]
