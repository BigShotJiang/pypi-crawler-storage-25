from .compat_passthrough import CompatPassthroughStrategy

class GQLGAEStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "GQL_GAE"

__all__ = ["GQLGAEStrategy"]
