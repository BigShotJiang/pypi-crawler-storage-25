from .compat_passthrough import CompatPassthroughStrategy

class ExasolSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "EXASOL_SQL"

__all__ = ["ExasolSQLStrategy"]
