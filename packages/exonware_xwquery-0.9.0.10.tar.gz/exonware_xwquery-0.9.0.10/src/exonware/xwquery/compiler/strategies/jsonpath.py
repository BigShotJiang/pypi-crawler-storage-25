from .compat_passthrough import CompatPassthroughStrategy


class JSONPathStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "JSONPATH"


__all__ = ["JSONPathStrategy"]
