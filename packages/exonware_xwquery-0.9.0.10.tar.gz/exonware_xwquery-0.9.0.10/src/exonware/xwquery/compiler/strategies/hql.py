from exonware.xwquery.strategies.hql import HQLStrategy
HqlStrategy = HQLStrategy
__all__ = ["HQLStrategy", "HqlStrategy"]
