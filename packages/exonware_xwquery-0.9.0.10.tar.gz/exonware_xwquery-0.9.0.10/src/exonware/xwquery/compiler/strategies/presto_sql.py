from .compat_passthrough import CompatPassthroughStrategy

class PrestoSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "PRESTO_SQL"

__all__ = ["PrestoSQLStrategy"]
