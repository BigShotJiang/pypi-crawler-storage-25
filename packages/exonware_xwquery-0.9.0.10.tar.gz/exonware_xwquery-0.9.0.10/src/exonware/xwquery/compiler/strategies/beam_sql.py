from .compat_passthrough import CompatPassthroughStrategy

class BeamSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "BEAM_SQL"

__all__ = ["BeamSQLStrategy"]
