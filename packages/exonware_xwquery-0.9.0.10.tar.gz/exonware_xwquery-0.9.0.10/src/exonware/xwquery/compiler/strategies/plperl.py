from .compat_passthrough import CompatPassthroughStrategy

class PLPerlStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "PLPERL"

__all__ = ["PLPerlStrategy"]
