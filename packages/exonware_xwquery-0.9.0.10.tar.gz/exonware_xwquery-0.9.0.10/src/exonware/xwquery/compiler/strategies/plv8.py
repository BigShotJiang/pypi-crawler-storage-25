from .compat_passthrough import CompatPassthroughStrategy

class PLv8Strategy(CompatPassthroughStrategy):
    FORMAT_NAME = "PLV8"

__all__ = ["PLv8Strategy"]
