from .compat_passthrough import CompatPassthroughStrategy

class VerticaSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "VERTICA_SQL"

__all__ = ["VerticaSQLStrategy"]
