from .compat_passthrough import CompatPassthroughStrategy

class ElasticsearchSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "ELASTICSEARCH_SQL"

__all__ = ["ElasticsearchSQLStrategy"]
