from .compat_passthrough import CompatPassthroughStrategy

class RisingWaveStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "RISINGWAVE"

__all__ = ["RisingWaveStrategy"]
