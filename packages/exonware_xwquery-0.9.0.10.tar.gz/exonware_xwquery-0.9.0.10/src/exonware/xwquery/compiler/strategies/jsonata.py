from .compat_passthrough import CompatPassthroughStrategy


class JSONataStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "JSONATA"


__all__ = ["JSONataStrategy"]
