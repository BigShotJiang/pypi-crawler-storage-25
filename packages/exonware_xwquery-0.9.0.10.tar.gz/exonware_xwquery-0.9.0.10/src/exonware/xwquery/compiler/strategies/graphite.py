from .compat_passthrough import CompatPassthroughStrategy

class GraphiteStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "GRAPHITE"

__all__ = ["GraphiteStrategy"]
