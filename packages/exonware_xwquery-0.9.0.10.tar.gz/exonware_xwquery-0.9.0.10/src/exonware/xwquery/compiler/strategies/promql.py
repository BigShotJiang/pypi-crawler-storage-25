from exonware.xwquery.strategies.promql import PromQLStrategy
PromqlStrategy = PromQLStrategy
__all__ = ["PromQLStrategy", "PromqlStrategy"]
