from .compat_passthrough import CompatPassthroughStrategy


class SOSLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SOSL"


__all__ = ["SOSLStrategy"]
