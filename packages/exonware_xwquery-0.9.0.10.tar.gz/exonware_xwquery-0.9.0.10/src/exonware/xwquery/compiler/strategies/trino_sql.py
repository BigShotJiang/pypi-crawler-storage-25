from .compat_passthrough import CompatPassthroughStrategy

class TrinoSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "TRINO_SQL"

__all__ = ["TrinoSQLStrategy"]
