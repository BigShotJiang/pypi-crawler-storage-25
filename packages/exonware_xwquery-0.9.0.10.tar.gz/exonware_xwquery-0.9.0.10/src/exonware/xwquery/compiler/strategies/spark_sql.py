from .compat_passthrough import CompatPassthroughStrategy

class SparkSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SPARK_SQL"

__all__ = ["SparkSQLStrategy"]
