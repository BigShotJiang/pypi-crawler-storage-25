from exonware.xwquery.strategies.partiql import PartiQLStrategy
PartiqlStrategy = PartiQLStrategy
__all__ = ["PartiQLStrategy", "PartiqlStrategy"]
