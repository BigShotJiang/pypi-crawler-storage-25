from .compat_passthrough import CompatPassthroughStrategy

class NetezzaSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "NETEZZA_SQL"

__all__ = ["NetezzaSQLStrategy"]
