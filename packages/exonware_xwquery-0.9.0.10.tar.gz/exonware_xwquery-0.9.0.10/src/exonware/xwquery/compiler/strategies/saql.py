from .compat_passthrough import CompatPassthroughStrategy

class SAQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SAQL"

__all__ = ["SAQLStrategy"]
