from .compat_passthrough import CompatPassthroughStrategy

class AsterixDBAQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "ASTERIXDB_AQL"

__all__ = ["AsterixDBAQLStrategy"]
