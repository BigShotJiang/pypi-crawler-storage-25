from .compat_passthrough import CompatPassthroughStrategy

class TimescaleDBStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "TIMESCALEDB"

__all__ = ["TimescaleDBStrategy"]
