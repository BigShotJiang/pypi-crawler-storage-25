from .compat_passthrough import CompatPassthroughStrategy

class SQLPlusPlusStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "SQL_PLUS_PLUS"

__all__ = ["SQLPlusPlusStrategy"]
