from .compat_passthrough import CompatPassthroughStrategy

class MaterializeStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "MATERIALIZE"

__all__ = ["MaterializeStrategy"]
