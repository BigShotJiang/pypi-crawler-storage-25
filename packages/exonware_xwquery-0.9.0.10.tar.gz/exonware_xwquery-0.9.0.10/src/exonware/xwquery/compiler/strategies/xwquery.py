from exonware.xwquery.compiler.strategies.xwqs import XWQSStrategy
XwqueryStrategy = XWQSStrategy
XWQueryScriptStrategy = XWQSStrategy
from exonware.xwquery.compiler.strategies.xwqs import FORMAT_STRATEGY_MAP
__all__ = ["XWQSStrategy", "XWQueryScriptStrategy", "XwqueryStrategy", "FORMAT_STRATEGY_MAP"]

# Backward-compat registrations for newer strategy identifiers
for _k in ["GQL_GAE", "SOSL", "SAQL", "DAX", "MDX", "M", "POWERFX", "ODATA", "OPENSEARCH_DSL", "OPENSEARCH_PPL"]:
    FORMAT_STRATEGY_MAP.setdefault(_k, XWQSStrategy)
