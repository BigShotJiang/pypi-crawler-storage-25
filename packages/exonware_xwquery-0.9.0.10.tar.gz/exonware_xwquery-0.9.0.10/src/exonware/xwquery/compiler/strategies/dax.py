from .compat_passthrough import CompatPassthroughStrategy

class DAXStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "DAX"

__all__ = ["DAXStrategy"]
