from .compat_passthrough import CompatPassthroughStrategy

class ChronografStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "CHRONOGRAF"

__all__ = ["ChronografStrategy"]
