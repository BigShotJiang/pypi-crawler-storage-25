from .compat_passthrough import CompatPassthroughStrategy

class MySQLStoredStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "MYSQL_STORED"

__all__ = ["MySQLStoredStrategy"]
