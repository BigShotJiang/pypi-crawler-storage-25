from .compat_passthrough import CompatPassthroughStrategy

class TeradataSQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "TERADATA_SQL"

__all__ = ["TeradataSQLStrategy"]
