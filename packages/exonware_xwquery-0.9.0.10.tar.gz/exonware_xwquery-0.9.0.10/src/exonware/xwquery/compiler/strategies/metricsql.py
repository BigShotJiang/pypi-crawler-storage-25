from .compat_passthrough import CompatPassthroughStrategy


class MetricsQLStrategy(CompatPassthroughStrategy):
    FORMAT_NAME = "METRICSQL"


__all__ = ["MetricsQLStrategy"]
