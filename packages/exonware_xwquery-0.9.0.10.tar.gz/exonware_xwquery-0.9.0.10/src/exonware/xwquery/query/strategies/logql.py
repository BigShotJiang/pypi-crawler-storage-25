from exonware.xwquery.strategies.logql import *
