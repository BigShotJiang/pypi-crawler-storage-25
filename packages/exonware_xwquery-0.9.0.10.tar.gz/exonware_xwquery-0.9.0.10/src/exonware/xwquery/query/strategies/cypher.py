from exonware.xwquery.strategies.cypher import *
