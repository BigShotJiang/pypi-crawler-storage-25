from exonware.xwquery.strategies.kql import *
