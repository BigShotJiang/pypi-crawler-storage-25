from exonware.xwquery.strategies.datalog import *
