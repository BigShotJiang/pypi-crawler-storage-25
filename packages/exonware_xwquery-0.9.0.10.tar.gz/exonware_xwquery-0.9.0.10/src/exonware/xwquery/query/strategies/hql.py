from exonware.xwquery.strategies.hql import *
