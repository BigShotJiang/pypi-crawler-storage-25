from exonware.xwquery.strategies.partiql import *
