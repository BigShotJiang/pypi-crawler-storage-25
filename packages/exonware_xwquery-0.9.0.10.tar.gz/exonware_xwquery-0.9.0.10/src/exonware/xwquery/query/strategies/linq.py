from exonware.xwquery.strategies.linq import *
