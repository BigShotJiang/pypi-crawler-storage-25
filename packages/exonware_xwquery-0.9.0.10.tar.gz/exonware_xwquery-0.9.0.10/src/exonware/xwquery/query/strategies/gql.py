from exonware.xwquery.strategies.gql import *
