from exonware.xwquery.strategies.cql import *
