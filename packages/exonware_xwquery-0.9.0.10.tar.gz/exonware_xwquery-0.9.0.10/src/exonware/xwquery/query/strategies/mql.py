from exonware.xwquery.strategies.mql import *
