from exonware.xwquery.strategies.pig import *
