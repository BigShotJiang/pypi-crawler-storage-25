from exonware.xwquery.strategies.n1ql import *
