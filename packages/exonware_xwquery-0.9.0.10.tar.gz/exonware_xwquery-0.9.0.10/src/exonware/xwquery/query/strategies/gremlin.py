from exonware.xwquery.strategies.gremlin import *
