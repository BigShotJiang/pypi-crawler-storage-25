from exonware.xwquery.strategies.sparql import *
