from exonware.xwquery.compiler.parsers.format_detector import QueryFormatDetector, detect_query_format
__all__=["QueryFormatDetector","detect_query_format"]
