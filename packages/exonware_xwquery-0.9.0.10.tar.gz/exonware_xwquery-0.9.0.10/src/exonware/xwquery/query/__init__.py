from .adapters import UniversalGrammarAdapter
