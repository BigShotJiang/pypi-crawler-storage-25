"""Back-compat shim for legacy `exonware.nodes` imports."""

from exonware.xwnode.nodes.strategies.contracts import NodeType

__all__ = ["NodeType"]

