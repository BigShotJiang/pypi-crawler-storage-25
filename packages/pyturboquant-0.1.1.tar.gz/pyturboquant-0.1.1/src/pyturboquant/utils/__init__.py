"""pyturboquant.utils -- Utility modules."""
