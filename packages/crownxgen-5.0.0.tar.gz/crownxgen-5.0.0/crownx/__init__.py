from . import gen
from . import ChooseNewbieChoice_pb2
from . import MajorLoginRes_pb2