"""Session storage."""
