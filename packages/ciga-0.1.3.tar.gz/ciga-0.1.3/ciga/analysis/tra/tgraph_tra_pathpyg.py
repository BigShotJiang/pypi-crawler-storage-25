import pandas as pd
import numpy as np
from typing import Dict, Any

def get_pathpyg_temporal_graph(tgraph):
    """
    Adapter: Adapts and converts CIGA's TGraph into a TemporalGraph object 
    for pathpyG (PyTorch-based). This is a prerequisite for using 
    advanced, high-computational-complexity temporal analysis algorithms.

    Args:
        tgraph: The CIGA TGraph instance.

    Returns:
        pathpyG.TemporalGraph: The temporal graph object.
    """
    try:
        import pathpyG as pp
        import torch
    except ImportError:
        raise ImportError(
            "This feature requires 'pathpyG' and 'torch'. "
            "Please install them via: pip install pathpyG torch"
        )

    df = tgraph.data.copy()
    positions = list(tgraph._position)
    df = df.sort_values(by=positions)

    # 1. Map string sources and targets to continuous integer IDs starting from 0 (PyG format)
    if not tgraph.name_to_id:
        tgraph._create_vnames()

    df['src_id'] = df['source'].map(tgraph.name_to_id)
    df['dst_id'] = df['target'].map(tgraph.name_to_id)

    # Drop dirty nodes that could not be mapped
    df = df.dropna(subset=['src_id', 'dst_id'])

    # 2. Flatten multidimensional timestamps (e.g. Season, Episode) into a 1D continuous integer sequence
    # pathpyG uses 1D timestamps. We divide all ordered events into incremental steps.
    if len(positions) == 1:
        time_series = df[positions[0]]
        if pd.api.types.is_numeric_dtype(time_series):
            times = time_series.values
        else:
            times = time_series.astype('category').cat.codes.values
    else:
        # Use factorize on the combined multi-column values to create a 0, 1, 2... sequence
        times = pd.factorize(list(zip(*[df[c] for c in positions])))[0]

    # 3. Build PyTorch Tensors
    edge_index = torch.tensor([df['src_id'].values, df['dst_id'].values], dtype=torch.long)
    timestamps = torch.tensor(times, dtype=torch.long)

    # If the original data contains weights, include them
    edge_weights = None
    if 'weight' in df.columns:
        edge_weights = torch.tensor(df['weight'].values, dtype=torch.float32)

    # 4. Generate the pathpyG TemporalGraph
    temporal_graph = pp.TemporalGraph(
        edge_index=edge_index,
        timestamps=timestamps,
        num_nodes=len(tgraph._vnames),
        edge_attr=edge_weights
    )

    # Attach CIGA's reverse mapping dictionary so node names can be restored after calculation
    temporal_graph.ciga_id_to_name = tgraph.id_to_name

    return temporal_graph

def temporal_betweenness_centrality(tgraph) -> Dict[str, float]:
    """
    Computes global advanced "Temporal Betweenness Centrality" using pathpyG.

    This algorithm extracts all network paths that strictly observe temporal order,
    measuring each character's role as a transit bridge in information flow.

    Args:
        tgraph (TGraph): The temporal graph object.

    Returns:
        Dict[str, float]: A dictionary mapping node names to their centrality scores.
    """
    try:
        from pathpyG.algorithms.centralities import temporal_betweenness
    except ImportError:
        raise ImportError(
            "This feature requires 'pathpyG'. "
            "Please ensure pathpyG algorithms are correctly installed."
        )

    # 1. Adapt the data
    tg = get_pathpyg_temporal_graph(tgraph)

    # 2. Call the high-computation temporal graph algorithm
    # (Note: pathpyG's API may vary slightly with major version upgrades, the following is standard)
    tb_scores = temporal_betweenness(tg)

    # 3. Map back to original names
    result_scores = {}

    # tb_scores is usually a Tensor/Numpy Array of length num_nodes
    # Process dictionaries specifically if returned
    if isinstance(tb_scores, dict):
        for n_id, score in tb_scores.items():
            name = tg.ciga_id_to_name.get(n_id)
            if name:
                result_scores[name] = float(score)
    else:
        for n_id, score in enumerate(tb_scores):
            name = tg.ciga_id_to_name.get(n_id)
            if name:
                result_scores[name] = float(score)

    return result_scores
