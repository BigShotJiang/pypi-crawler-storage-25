import pandas as pd
from typing import Dict, List, Optional
from ciga.analysis.tra.tgraph_tra_paths import temporal_reachability, earliest_arrival_times

def temporal_reachability_sequence(
    tgraph,
    window_size: Optional[int] = None,
    accumulate: bool = False,
    normalize: bool = True
) -> pd.DataFrame:
    """
    Computes the 'Temporal Reachability Centrality' sequence based on a sliding window or accumulator.
    This metric measures the proportion of other nodes in the network that a node can reach
    within a given time window (spreading potential).

    Args:
        tgraph (TGraph): The temporal graph object.
        window_size (int, optional): The time window size. If not specified, controlled by the `accumulate` parameter.
        accumulate (bool, optional): Whether to accumulate (0 -> t). Mutually exclusive with `window_size`. Defaults to False.
        normalize (bool, optional): Whether to normalize reachability scores (divide by the maximum possible reachable nodes, excluding self).
            Defaults to True.

    Returns:
        pd.DataFrame: A sequence DataFrame containing 'time_point' and corresponding scores for each node.
    """
    if window_size is not None and accumulate:
        raise ValueError("window_size defines its own window and is mutually exclusive with accumulate=True.")

    # Get all sorted unique timesteps
    all_steps = tgraph.data.index.unique().tolist()
    # Sort by positions
    if isinstance(tgraph.data.index, pd.MultiIndex):
        all_steps = sorted(all_steps)
    else:
        all_steps = sorted(all_steps)

    all_nodes = tgraph._vnames
    if not all_nodes:
        all_nodes = list(pd.unique(tgraph.data[['source', 'target']].values.ravel('K')))
    total_nodes = len(all_nodes)

    # Prevent division by zero if total nodes is 0 or 1
    max_possible_reach = max(1, total_nodes - 1)

    result_sequence = []

    if accumulate:
        # === Incremental Streaming Mode (O(E) complexity) ===
        # Track all child nodes each node can reach
        reachable_from = {n: {n} for n in all_nodes}
        # Track all parent nodes that can reach the current node (for quick backwards lookup)
        who_can_reach = {n: {n} for n in all_nodes}

        is_directed = tgraph.is_directed
        df = tgraph.data
        positions = list(tgraph._position)

        # Group by time nodes, process in sequence
        grouped = df.groupby(positions)

        for current_time in all_steps:
            try:
                chunk = grouped.get_group(current_time)
            except KeyError:
                chunk = pd.DataFrame()

            for row in chunk[['source', 'target']].itertuples(index=False):
                u = row.source
                v = row.target

                if u not in who_can_reach or v not in who_can_reach:
                    continue  # Defensively filter out potentially dirty nodes not registered in tgraph._vnames

                # u can reach v, meaning anyone who can reach u can now also reach v
                if is_directed:
                    new_origins = who_can_reach[u] - who_can_reach[v]
                    if new_origins:
                        who_can_reach[v].update(new_origins)
                        for orig in new_origins:
                            reachable_from[orig].add(v)
                else:
                    # For undirected graphs, u and v infect each other, all sources reaching u or v can spread to each other
                    union_origins = who_can_reach[u] | who_can_reach[v]
                    new_for_u = union_origins - who_can_reach[u]
                    new_for_v = union_origins - who_can_reach[v]

                    if new_for_u or new_for_v:
                        who_can_reach[u] = set(union_origins)
                        who_can_reach[v] = set(union_origins)
                        for orig in new_for_u:
                            reachable_from[orig].add(u)
                        for orig in new_for_v:
                            reachable_from[orig].add(v)

            # Record the size of influence radiation for everyone at the current time
            scores = {}
            for node in all_nodes:
                reach_size = len(reachable_from[node]) - 1
                if normalize:
                    scores[node] = reach_size / max_possible_reach
                else:
                    scores[node] = reach_size

            entry = {'time_point': current_time}
            entry.update(scores)
            result_sequence.append(entry)

    else:
        # === Sliding Window Mode (Fall back to slicing and recalculating) ===
        for i in range(len(all_steps)):
            current_time = all_steps[i]

            if window_size is not None:
                if window_size < 1:
                    raise ValueError("window_size must be a positive integer.")
                start_idx = max(0, i - window_size + 1)
                window_start = all_steps[start_idx]
                window_data = tgraph.take_interval(start=window_start, end=current_time)
            else:
                # Non-accumulating network only for the current moment
                window_data = tgraph.take_interval(start=current_time, end=current_time)

            scores = {}
            for node in all_nodes:
                if window_data.empty:
                    reach_size = 0
                else:
                    reachable_set = temporal_reachability(tgraph, node, data=window_data)
                    reach_size = len(reachable_set) - 1

                if normalize:
                    scores[node] = reach_size / max_possible_reach
                else:
                    scores[node] = reach_size

            entry = {'time_point': current_time}
            entry.update(scores)
            result_sequence.append(entry)

    df_seq = pd.DataFrame(result_sequence)
    # Split time_point back into respective columns (Handle MultiIndex tuples)
    if all_steps and isinstance(all_steps[0], tuple):
        pos_names = tgraph._position
        for idxPos, col_name in enumerate(pos_names):
            df_seq.insert(idxPos, col_name, df_seq['time_point'].apply(lambda x: x[idxPos]))
        df_seq = df_seq.drop(columns=['time_point'])

    return df_seq
