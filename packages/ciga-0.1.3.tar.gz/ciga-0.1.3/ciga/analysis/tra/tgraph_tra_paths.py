import pandas as pd
from typing import Dict, Set, Tuple

def temporal_reachability(tgraph, source_node: str, data: pd.DataFrame = None) -> Set[str]:
    """
    Computes the set of nodes reachable from the `source_node` via Time-Respecting Paths.
    
    Args:
        tgraph (TGraph): The CIGA temporal graph object.
        source_node (str): The starting node name.
        data (pd.DataFrame, optional): A subset of `tgraph.data` (e.g., windowed data) 
            to use instead of the full dataset.

    Returns:
        Set[str]: A set of reachable nodes (including the `source_node` itself).
    """
    df = (data if data is not None else tgraph.data)
    # If the data is not strictly ordered by position, it should be sorted.
    # However, in CIGA, `_flatten_interactions` already handles sorting.
    # To avoid performance loss from redundant sorting, we assume it's a basically ordered event stream.
    positions = list(tgraph._position)

    reachable = {source_node}

    # Abandon slow iterrows, use itertuples for a massive performance boost.
    for row in df[['source', 'target']].itertuples(index=False):
        u = row.source
        v = row.target

        if u in reachable:
            reachable.add(v)

        if not tgraph.is_directed and v in reachable:
            reachable.add(u)

    return reachable

def earliest_arrival_times(tgraph, source_node: str, data: pd.DataFrame = None) -> Dict[str, Tuple]:
    """
    Computes the earliest arrival times to reach other nodes in the network starting from `source_node`.
    
    Args:
        tgraph (TGraph): The CIGA temporal graph object.
        source_node (str): The starting node name.
        data (pd.DataFrame, optional): A subset of `tgraph.data` (e.g., windowed data)
            to use instead of the full dataset.

    Returns:
        Dict[str, Tuple]: A dictionary where the keys are node names and values are tuples
            representing the earliest arrival times.
    """
    df = (data if data is not None else tgraph.data).copy()
    positions = list(tgraph._position)

    if set(positions).issubset(set(df.index.names)):
        df = df.reset_index()

    df = df.sort_values(by=positions)
    arrival_times = {source_node: tuple([float('-inf')] * len(positions))}

    for row in df.itertuples(index=False):
        u = getattr(row, 'source')
        v = getattr(row, 'target')
        t = tuple(getattr(row, pos) for pos in positions)

        if u in arrival_times and arrival_times[u] <= t:
            if v not in arrival_times or t < arrival_times[v]:
                arrival_times[v] = t

        if not tgraph.is_directed:
            if v in arrival_times and arrival_times[v] <= t:
                if u not in arrival_times or t < arrival_times[u]:
                    arrival_times[u] = t

    if arrival_times.get(source_node) == tuple([float('-inf')] * len(positions)):
        del arrival_times[source_node]

    return arrival_times
