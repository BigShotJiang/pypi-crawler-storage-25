import ciga as cg
import pandas as pd
import matplotlib.pyplot as plt
import os

data_path = os.path.join(os.path.dirname(__file__), 'BB_F4_with_speakers_listeners.csv')
df = pd.read_csv(data_path)

def weight_func(interaction):
    return 1

positions = ('Scene', 'Shot', 'Line')
interactions = cg.prepare_data(data=df,
                               positions=positions,
                               source='Speaker', 
                               target='Listener', 
                               interaction='transcripts')

sub_interactions = cg.segment(interactions, start=(1, 1, 1), end=(2, 1, 1), positions=positions)
weights = cg.calculate_weights(sub_interactions, weight_func)
agg_weights = cg.agg_weights(data=weights, 
                             positions=positions[:-1], 
                             agg_func=lambda x: sum(x))

tg = cg.TGraph(data=agg_weights, 
               positions=positions[:-1], 
               directed=False)

graph = tg.get_graph((2, 1))
cg.graph_viz(graph)

res = cg.tgraph_degree_centrality(tg, weighted=True, normalized=True)

# res.to_csv('results.csv')