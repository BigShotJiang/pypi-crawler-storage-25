import warnings

import pandas as pd
import numpy as np
from igraph import Graph

class TGraph:
    """
    TGraph is a class for managing and analyzing temporal graphs using the igraph library.

    Attributes:
        data (pd.DataFrame): The dataset containing graph edges and their attributes.
        _position (tuple): The positional indices used for temporal positioning in the data.
        _layout (Any): The layout of the graph (currently unused).
        _directed (bool): Indicates whether the graph is directed.
        _vnames (list): List of vertex names.
        name_to_id (dict): Mapping from vertex names to their IDs.
        id_to_name (dict): Mapping from vertex IDs to their names.
        _cache_graph (Graph): Cached version of the graph for performance optimization.
        _cache_time_point (tuple): Cached time point corresponding to the cached graph.
    """

    def __init__(self, init_graph=None, data=None, positions=None, directed=True):
        """
        Initializes a new instance of the TGraph class.

        Args:
            init_graph (Graph, optional): An existing igraph.Graph object to initialize the graph.
                If not provided, a new graph is created.
            data (pd.DataFrame): The dataset containing graph edges and their attributes. **Required**.
            position (list or tuple): The positional indices or keys used for temporal positioning in the data. **Required**.
            directed (bool, optional): Determines whether the graph is directed. Defaults to True.

        Raises:
            ValueError: If `data` or `position` is not provided.
            ValueError: If the `weight` column is missing in the data.
        """
        if data is None:
            raise ValueError("Data must be provided.")
        if positions is None:
            raise ValueError("Position must be provided.")
        if 'weight' not in data.columns:
            raise ValueError("Weight column not found in data. Run calculate_weights() first.")

        self.data = data.copy()
        self._position = positions
        self._layout = None
        self._directed = directed
        self._vnames = []
        self.name_to_id = {}
        self.id_to_name = {}
        self._cache_graph = None
        self._cache_time_point = tuple([-np.inf] * len(self._position))

        # Set multi-index if not already set (Force MultiIndex even for 1D to ensure tuple consistency)
        if not isinstance(self.data.index, pd.MultiIndex):
            self.data.set_index(list(self._position), inplace=True)
            if not isinstance(self.data.index, pd.MultiIndex):
                self.data.index = pd.MultiIndex.from_arrays([self.data.index], names=list(self._position))
            self.data.sort_index(inplace=True)

        # For undirected graphs, ensure consistent edge ordering
        if not self._directed:
            idx = self.data['source'] > self.data['target']
            self.data.loc[idx, ['source', 'target']] = self.data.loc[idx, ['target', 'source']].values

        if init_graph is None:
            self._init_graph = Graph(directed=self._directed)
            self._init_graph.vs['name'] = []
            # good for optimization but char havnt appear shouldn't be added
            # all_nodes = np.unique(self.data[['source', 'target']].values)
            # self._init_graph.add_vertices(all_nodes)
        else:
            self._init_graph = init_graph
            self._directed = init_graph.is_directed()

        # Create name to ID mappings
        self._vnames = self._init_graph.vs['name']
        self._create_vnames()

        # Initialize the cached graph
        self._cache_graph = self._init_graph.copy()

    def _create_vnames(self):
        """
        Creates mappings between vertex names and their corresponding IDs.

        Returns:
            list: A list of vertex names.
        """
        self.name_to_id = {name: idx for idx, name in enumerate(self._vnames)}
        self.id_to_name = {idx: name for idx, name in enumerate(self._vnames)}
        return self._vnames

    @property
    def is_directed(self):
        """
        Checks if the graph is directed.

        Returns:
            bool: True if the graph is directed, False otherwise.
        """
        return self._directed

    def _normalize_graph_weight(self, graph):
        """
        Normalizes the weights of the graph's edges so that the maximum weight becomes 1.

        Args:
            graph (Graph): The graph whose edge weights are to be normalized.

        Returns:
            Graph: The graph with normalized edge weights.

        Raises:
            Warning: If the total weight is 0 and no normalization is performed.
        """
        # safety
        if graph.ecount() == 0 or 'weight' not in graph.es.attributes():
            return graph

        weights = graph.es['weight']
        if not weights:
            return graph
        max_weight = max(weights)
        if max_weight > 0:
            graph.es['weight'] = [w / max_weight for w in graph.es['weight']]
        else:
            warnings.warn("Max weight <= 0. No normalization is done.")
        return graph

    def _invert_graph_weight(self, graph, method='reciprocal'):
        """
        Inverts the weights of the graph's edges.

        Args:
            graph (Graph): The graph whose edge weights are to be inverted.
            method (str): The method used for inversion ('reciprocal' or 'max_minus').

        Returns:
            Graph: The graph with inverted edge weights.
        """
        # safety
        if graph.ecount() == 0 or 'weight' not in graph.es.attributes():
            return graph
        weights = np.array(graph.es['weight'])
        
        if method == 'reciprocal':
            adjusted_weights = 1 / (weights + 1e-6)
        elif method == 'max_minus':
            # Shift by max value. Add epsilon to ensure max weight edge isn't 0 
            # (which would be deleted by downstream <=0 check)
            adjusted_weights = (np.max(weights) + 1e-6) - weights
        else:
            raise ValueError(f"Unknown inversion method: {method}")
            
        graph.es['weight'] = adjusted_weights
        return graph

    # consider separate this into two function: get_data() and get_graph()
    # decay calculation can be done in get_data()
    def get_graph(
        self,
        time_point=None,
        *,
        accumulate=False,
        window_size=None,
        w_normalized=False,
        invert_weight=False,
        mean_weight=False
    ):
        """
        Retrieves the graph at a specific time point with various transformation options.

        Args:
            time_point (tuple, optional): The time point at which to retrieve the graph.
                Defaults to infinity for all positions.
            accumulate (bool, optional): Whether to accumulate changes up to the specified time point.
                Defaults to False. Mutually exclusive with ``window_size``.
            window_size (int, optional): If set, only the most recent ``window_size`` time steps
                (measured by position-index order) up to and including ``time_point`` are used
                to build the graph.  Steps at the head of the sequence where fewer than
                ``window_size`` steps are available use whatever data exists (partial window).
                Mutually exclusive with ``accumulate=True``. Defaults to None.
            w_normalized (bool, optional): Whether to normalize edge weights. Defaults to False.
            invert_weight (bool or str, optional): Whether to invert edge weights. Pass `True` or `'reciprocal'` 
                for 1/(w+eps), or `'max_minus'` for max(w)-w. Defaults to False.
            mean_weight (bool, optional): Whether to average edge weights by dividing by the number of
                time steps inside the window / from the start up to ``time_point``.
                Defaults to False.

        Returns:
            Graph or None: The transformed graph at the specified time point or None if no data is available.
        """
        if window_size is not None and accumulate:
            raise ValueError(
                "window_size and accumulate=True are mutually exclusive. "
                "window_size defines its own bounded accumulation window."
            )
        if window_size is not None and window_size < 1:
            raise ValueError("window_size must be a positive integer.")

        if mean_weight and not accumulate and window_size is None:
            raise ValueError(
                "mean_weight requires accumulate=True. "
                "Averaging weights over time only makes sense on a cumulative graph, "
                "not on a single-moment snapshot."
            )

        raw_time_point = time_point

        if time_point is None:
            time_point = tuple([np.inf] * len(self._position))
        elif not isinstance(time_point, (tuple, list)):
            time_point = (time_point,)
            
        if len(time_point) < len(self._position):
            time_point = tuple(list(time_point) + [np.inf] * (len(self._position) - len(time_point)))

        def adjust_graph_weight(graph, duration=1):
            if mean_weight and duration > 0:
                graph.es['weight'] = [w / duration for w in graph.es['weight']]
            if w_normalized:
                graph = self._normalize_graph_weight(graph)
            if invert_weight:
                method = invert_weight if isinstance(invert_weight, str) else 'reciprocal'
                graph = self._invert_graph_weight(graph, method=method)
            # ensure weight > 0
            if graph.ecount() > 0:
                bad_edges = [e.index for e in graph.es if e['weight'] <= 0]
                if bad_edges:
                    graph.delete_edges(bad_edges)
            return graph
            
        def get_duration(data=None):
            if data is None or data.empty:
                return 1
            # Assuming the index represents time steps.
            # We count unique time steps present in the data slice.
            # This is a proxy for duration if time steps are discrete and we only care about active steps.
            # For continuous time, max-min would be better, but index format is unknown.
            # Using unique index values is a safe default for discrete event data.
            return len(data.index.unique())

        # ── Sliding-window mode ─────────────────────────────────────────
        if window_size is not None:
            # Resolve all unique sorted steps from the full dataset (always tuples due to MultiIndex)
            all_steps = self.data.index.unique().tolist()
            
            # Use the normalized time_point (always a tuple) for matching
            lookup_point = time_point

            # Locate current step; fall back to the last step ≤ lookup_point
            if lookup_point is not None and lookup_point in all_steps:
                current_idx = all_steps.index(lookup_point)
            elif lookup_point is not None:
                # Find the closest step that does not exceed lookup_point
                # Tuple comparison (3,) <= (4,) works correctly for MultiIndex coordinates
                current_idx = next(
                    (i for i, s in reversed(list(enumerate(all_steps))) if s <= lookup_point),
                    0
                )
            else:
                current_idx = len(all_steps) - 1  # use the last step when time_point is None

            window_start_idx = max(0, current_idx - window_size + 1)
            window_start = all_steps[window_start_idx]
            window_end = all_steps[current_idx]

            window_data = self.take_interval(start=window_start, end=window_end)
            window_graph = Graph(directed=self._directed)
            window_graph.vs['name'] = []
            if window_data.empty:
                return None
            self._update_graph(window_graph, window_data)
            duration = get_duration(window_data) if mean_weight else 1
            return adjust_graph_weight(window_graph, duration=duration)
        # ── Instantaneous (non-accumulate) mode ─────────────────────────
        if not accumulate:
            moment_graph = Graph(directed=self._directed)
            moment_graph.vs['name'] = []
            idx = pd.IndexSlice
            # Get subset data where position matches time_point
            key = raw_time_point if raw_time_point is not None else slice(None)
            try:
                moment_data = self.data.loc[idx[key], :].copy()
                if isinstance(moment_data, pd.Series):
                    moment_data = moment_data.to_frame().T
            except KeyError:
                moment_data = pd.DataFrame()

            if moment_data.empty:
                return None
            self._update_graph(moment_graph, moment_data)
            return adjust_graph_weight(moment_graph, duration=get_duration(moment_data) if mean_weight else 1)
        
        # Accumulate logic
        # For duration calculation in accumulate mode, we need the total duration from start to time_point.
        # Since _cache_graph is cumulative, we can't easily get the 'active duration' from it directly.
        # We need to query the full interval data to get the duration count.
        
        full_interval_data = None
        if mean_weight:
             full_interval_data = self.take_interval(end=time_point)

        if self._cache_time_point and self._cache_time_point < time_point:
            start = list(self._cache_time_point)
            start[-1] += 1
            delta_data = self.take_interval(start=start, end=time_point)
        else:
            delta_data = self.take_interval(start=None, end=time_point)
            self._cache_graph = self._init_graph.copy()

        if delta_data.empty:
             # Even if delta is empty, we might return cached graph.
             # Duration should still be calculated up to time_point.
            duration = 1
            if mean_weight:
                 duration = get_duration(full_interval_data)
            return adjust_graph_weight(self._cache_graph.copy(), duration=duration)

        self._update_graph(self._cache_graph, delta_data)
        self._cache_time_point = time_point
        
        duration = 1
        if mean_weight:
             duration = get_duration(full_interval_data)

        return adjust_graph_weight(self._cache_graph.copy(), duration=duration)

    def graph_sub(self, graph1, graph2):
        """
        Subtracts the weights of graph2 from graph1.

        Args:
            graph1 (Graph): The base graph.
            graph2 (Graph): The graph to subtract from graph1.

        Returns:
            Graph: The resulting graph after subtraction.

        Raises:
            ValueError: If the directedness of graph1 and graph2 do not match.
            ValueError: If either graph lacks the 'name' attribute for vertices.
        """
        # Ensure both graphs have the same directedness
        if graph1.is_directed() != graph2.is_directed():
            raise ValueError("Both graphs must be either directed or undirected.")

        # Copy graph1 to avoid modifying the original
        result_graph = graph1.copy()

        # Ensure that 'name' attribute exists in both graphs
        if 'name' not in result_graph.vs.attributes() or 'name' not in graph2.vs.attributes():
            raise ValueError("Both graphs must have 'name' attribute for vertices.")

        # Build a dictionary for quick edge weight lookup in graph2
        graph2_edge_weights = {}
        for e in graph2.es:
            source_name = graph2.vs[e.source]['name']
            target_name = graph2.vs[e.target]['name']
            key = (source_name, target_name)
            graph2_edge_weights[key] = e['weight']

        # Subtract weights in result_graph
        edges_to_delete = []
        for e in result_graph.es:
            source_name = result_graph.vs[e.source]['name']
            target_name = result_graph.vs[e.target]['name']
            key = (source_name, target_name)

            # Get the weight to subtract from graph2 if the edge exists
            weight_to_subtract = graph2_edge_weights.get(key, 0)

            # Subtract the weights
            new_weight = e['weight'] - weight_to_subtract

            if new_weight <= 0: # only positive weight
                # Mark edge for deletion
                edges_to_delete.append(e.index)
            else:
                # Update the edge weight
                e['weight'] = new_weight

        # Delete edges with zero or negative weights
        result_graph.delete_edges(edges_to_delete)

        # Remove isolated vertices (nodes with no edges)
        degrees = result_graph.degree()
        isolated_vertices = [idx for idx, deg in enumerate(degrees) if deg == 0]
        result_graph.delete_vertices(isolated_vertices)

        return result_graph

    def get_delta_graph(
        self,
        start=None,
        end=None,
        *,
        dw_normalized=False,
        w_normalized=False,
        invert_weight=False,
        mean_weight=False
    ):
        """
        Computes the delta (difference) between two graph states over a time interval.

        Args:
            start (tuple, optional): The starting time point of the interval.
            end (tuple, optional): The ending time point of the interval.
            dw_normalized (bool, optional): Whether to consider normalized weights for delta computation.
                Defaults to False.
            w_normalized (bool, optional): Whether to normalize weights in the resulting graph.
                Defaults to False.
            invert_weight (bool or str, optional): Whether to invert weights in the resulting graph. 
                Pass `True` or `'reciprocal'` for 1/(w+eps), or `'max_minus'` for max(w)-w. Defaults to False.
            mean_weight (bool, optional): Whether to average edge weights by dividing by the time duration. Defaults to False.

        Returns:
            Graph: The delta graph representing the changes between `start` and `end` time points.
        """
        interval_graph = None
        if dw_normalized:
            g1 = self.get_graph(time_point=start, w_normalized=dw_normalized, mean_weight=mean_weight)
            g2 = self.get_graph(time_point=end, w_normalized=dw_normalized, mean_weight=mean_weight)
            interval_graph = self.graph_sub(g2, g1)
        else:
            if start is not None and len(start) == len(self._position):
                start = list(start)
                start[-1] += 1

            delta_data = self.take_interval(start=start, end=end)
            if delta_data.empty:
                interval_graph = Graph(directed=self._directed)
                interval_graph.vs['name'] = [] # bug fix: init empty graph needs name attr if nodes added later or empty result
            else:
                agg_data = delta_data.groupby(['source', 'target'])['weight'].sum().reset_index()
                
                # Apply mean weight calculation
                if mean_weight:
                    # Calculate duration based on unique time indices in the interval
                    duration = len(delta_data.index.unique())
                    if duration > 0:
                        agg_data['weight'] = agg_data['weight'] / duration

                # filter out <= weight
                agg_data = agg_data[agg_data['weight'] > 0]
                if agg_data.empty:
                    interval_graph = Graph(directed=self._directed)
                    interval_graph.vs['name'] = []
                else:
                    nodes = set(agg_data['source']).union(set(agg_data['target']))
                    temp_node_to_id = {node: idx for idx, node in enumerate(nodes)}

                    agg_data['source_id'] = agg_data['source'].map(temp_node_to_id)
                    agg_data['target_id'] = agg_data['target'].map(temp_node_to_id)

                    edges = list(zip(agg_data['source_id'], agg_data['target_id']))
                    weights = agg_data['weight'].tolist()

                    interval_graph = Graph(edges=edges, directed=self._directed)
                    interval_graph.vs['name'] = list(temp_node_to_id.keys())
                    interval_graph.es['weight'] = weights

            if w_normalized:
                interval_graph = self._normalize_graph_weight(interval_graph)
                
        if invert_weight:
            method = invert_weight if isinstance(invert_weight, str) else 'reciprocal'
            interval_graph = self._invert_graph_weight(interval_graph, method=method)
        return interval_graph

    def _update_graph(self, graph, data):
        """
        Updates the graph with new data by adding new nodes and edges or updating existing ones.

        Args:
            graph (Graph): The graph to be updated.
            data (pd.DataFrame): The new data containing edge information to update the graph.

        Returns:
            Graph: The updated graph.
        """
        agg_data = data.groupby(['source', 'target'])['weight'].sum().reset_index()

        # prevent adding 0 weight edges
        agg_data = agg_data[agg_data['weight'] > 0]
        if agg_data.empty:
            return graph

        # Identify existing and new nodes
        existing_nodes = set(graph.vs['name'])
        new_nodes = set(agg_data['source']).union(set(agg_data['target'])) - set(existing_nodes)

        # Add new nodes to the graph and update mappings
        if new_nodes:
            graph.add_vertices(list(new_nodes))
            self._vnames = graph.vs['name']  # Update vertex names
            # Update name to ID mappings starting from the last index
            for idx, node in enumerate(new_nodes, start=len(existing_nodes)):
                self.name_to_id[node] = idx
                self.id_to_name[idx] = node

        # Map source and target names to their respective IDs
        agg_data['source_id'] = agg_data['source'].map(self.name_to_id)
        agg_data['target_id'] = agg_data['target'].map(self.name_to_id)

        # Check if edges already exist
        edges_in_data = list(zip(agg_data['source_id'], agg_data['target_id']))
        whether_edge_exists = graph.get_eids(pairs=edges_in_data, error=False)
        agg_data['eid'] = whether_edge_exists

        # Identify new edges and existing edges to update
        new_edges = agg_data[agg_data['eid'] == -1][['source_id', 'target_id']].values.tolist()
        new_weights = agg_data[agg_data['eid'] == -1]['weight'].tolist()

        existing_edge_ids_to_update = agg_data[agg_data['eid'] != -1]['eid'].tolist()
        weight_updates = agg_data[agg_data['eid'] != -1]['weight'].tolist()

        # existing_edges = graph.get_edgelist()
        # edges_in_data = pd.DataFrame(existing_edges, columns=['source_id', 'target_id'])
        #
        # # merge to identify existing and new edges
        # df_merged = pd.merge(
        #     agg_data,
        #     edges_in_data,
        #     on=['source_id', 'target_id'],
        #     how='left',
        #     indicator=True
        # )
        #
        # df_new_edges = df_merged[df_merged['_merge'] == 'left_only']
        # df_to_update = df_merged[df_merged['_merge'] == 'both']

        # new_edges = list(zip(df_new_edges['source_id'], df_new_edges['target_id']))
        # get those with eid value of -1 for new edges
        # new_weights = df_new_edges['weight'].tolist()
        # edges_to_update = list(zip(df_to_update['source_id'], df_to_update['target_id']))
        # edges to update are those with eid value not equal to -1
        # existing_edge_ids_to_update = graph.get_eids(pairs=edges_to_update, directed=graph.is_directed())
        # weight_updates = df_to_update['weight'].tolist()

        # Add new edges in bulk
        if new_edges:
            graph.add_edges(new_edges)
            # Set weights for new edges
            new_edge_ids = graph.es[-len(new_edges):].indices
            graph.es[new_edge_ids]['weight'] = new_weights

        # Update weights of existing edges in bulk
        if existing_edge_ids_to_update:
            # Retrieve current weights
            current_weights = graph.es[existing_edge_ids_to_update]['weight']
            # Update weights by adding the new weights
            updated_weights = [cw + w for cw, w in zip(current_weights, weight_updates)]
            graph.es[existing_edge_ids_to_update]['weight'] = updated_weights

        # prevent edges with weight <= 0
        edges_to_delete = [e.index for e in graph.es if e['weight'] <= 0]
        if edges_to_delete:
            graph.delete_edges(edges_to_delete)

        return graph

    def take_interval(self, start=None, end=None):
        """
        Retrieves a subset of the data within the specified time interval.

        Args:
            start (list or tuple, optional): The starting bounds of the interval.
            end (list or tuple, optional): The ending bounds of the interval.

        Returns:
            pd.DataFrame: The filtered data within the specified interval.

        Raises:
            ValueError: If the length of `start` or `end` is out of range relative to `position`.
        """
        if start is None:
            start = [-np.inf] * len(self._position)
        else:
            if len(start) < len(self._position):
                start = list(start) + [None] * (len(self._position) - len(start))
            start = [s if s is not None else -np.inf for s in start]

        if end is None:
            end = [np.inf] * len(self._position)
        else:
            if len(end) < len(self._position):
                end = list(end) + [None] * (len(self._position) - len(end))
            end = [e if e is not None else np.inf for e in end]

        if len(self._position) > len(start) or len(self._position) > len(end):
            raise ValueError("The length of 'start/end' is out of range.")

        idx = pd.IndexSlice
        if len(self._position) == 1:
            filtered_data = self.data.loc[idx[start[0]: end[0]], :].copy()
        else:
            filtered_data = self.data.loc[idx[tuple(start): tuple(end)], :].copy()

        return filtered_data


