from igraph import Graph
from typing import Optional, Callable


def filter_edges(
        graph: Graph,
        min_weight: Optional[float] = None,
        max_weight: Optional[float] = None,
        condition: Optional[Callable] = None,
        delete_isolated_nodes: bool = True
) -> Graph:
    """
    Filter edges of an igraph Graph based on weight thresholds or a custom condition.

    Args:
        graph (Graph): The igraph Graph object to filter.
        min_weight (float, optional): The minimum weight to keep (inclusive). Defaults to None.
        max_weight (float, optional): The maximum weight to keep (inclusive). Defaults to None.
        condition (Callable, optional): A custom function applied to each edge to determine 
            if the edge should be kept. E.g., `lambda edge: edge['weight'] > 5`. Defaults to None.
        delete_isolated_nodes (bool, optional): Whether to remove nodes that become isolated 
            after edge deletion. Defaults to True.

    Returns:
        Graph: A new Graph object containing only the edges that satisfy the conditions.
    """
    filtered_graph = graph.copy()

    if condition is not None:
        edges_to_delete = [e.index for e in filtered_graph.es if not condition(e)]
    else:
        if 'weight' not in filtered_graph.es.attributes():
            raise ValueError("Edge weights are missing in the graph.")
            
        edges_to_delete = []
        for e in filtered_graph.es:
            w = e['weight']
            if min_weight is not None and w < min_weight:
                edges_to_delete.append(e.index)
            elif max_weight is not None and w > max_weight:
                edges_to_delete.append(e.index)

    filtered_graph.delete_edges(edges_to_delete)

    if delete_isolated_nodes:
        degrees = filtered_graph.degree()
        isolated_vertices = [idx for idx, deg in enumerate(degrees) if deg == 0]
        filtered_graph.delete_vertices(isolated_vertices)

    return filtered_graph


def add_graphs_by_weight(g1: Graph, g2: Graph) -> Graph:
    """
    Add the edge weights of two igraph Graph objects together.
    Nodes and edges present in either graph will be combined.

    Args:
        g1 (Graph): The first graph.
        g2 (Graph): The second graph.

    Returns:
        Graph: A new Graph with combined edges and summed weights.
    """
    if g1.is_directed() != g2.is_directed():
        raise ValueError("Graphs must have the same directedness.")
    if 'name' not in g1.vs.attributes() or 'name' not in g2.vs.attributes():
        raise ValueError("Both graphs must have 'name' vertex attributes.")

    # Extract all edges and sum weights
    combined_edges = {}
    
    def process_edges(g: Graph):
        for e in g.es:
            u, v = g.vs[e.source]['name'], g.vs[e.target]['name']
            if not g.is_directed() and u > v:
                u, v = v, u  # standardize undirected pairs
            w = e['weight'] if 'weight' in g.es.attributes() else 1.0
            combined_edges[(u, v)] = combined_edges.get((u, v), 0.0) + w

    process_edges(g1)
    process_edges(g2)

    # Create new graph
    all_nodes = list(set([n for pair in combined_edges.keys() for n in pair]))
    res_g = Graph(directed=g1.is_directed())
    res_g.add_vertices(all_nodes)
    
    edge_list = list(combined_edges.keys())
    weights = list(combined_edges.values())
    
    res_g.add_edges(edge_list)
    res_g.es['weight'] = weights

    return res_g


def subtract_graphs_by_weight(g1: Graph, g2: Graph, drop_isolated_nodes: bool = True) -> Graph:
    """
    Subtract the edge weights of the second graph (g2) from the first graph (g1).
    Edges with a resulting weight <= 0 are removed.

    Args:
        g1 (Graph): The base graph.
        g2 (Graph): The graph whose weights are to be subtracted.
        drop_isolated_nodes (bool, optional): Remove nodes without edges after subtraction. Defaults to True.

    Returns:
        Graph: A new Graph with subtracted weights.
    """
    if g1.is_directed() != g2.is_directed():
        raise ValueError("Graphs must have the same directedness.")
    if 'name' not in g1.vs.attributes() or 'name' not in g2.vs.attributes():
        raise ValueError("Both graphs must have 'name' vertex attributes.")

    res_g = g1.copy()

    # Build lookup for g2 weights
    g2_weights = {}
    for e in g2.es:
        u, v = g2.vs[e.source]['name'], g2.vs[e.target]['name']
        w = e['weight'] if 'weight' in g2.es.attributes() else 1.0
        g2_weights[(u, v)] = w
        if not g2.is_directed():
            g2_weights[(v, u)] = w

    edges_to_delete = []
    for e in res_g.es:
        u, v = res_g.vs[e.source]['name'], res_g.vs[e.target]['name']
        w2 = g2_weights.get((u, v), 0.0)
        new_w = e['weight'] - w2
        if new_w <= 0:
            edges_to_delete.append(e.index)
        else:
            e['weight'] = new_w

    res_g.delete_edges(edges_to_delete)

    if drop_isolated_nodes:
        isolated = [v.index for v in res_g.vs if res_g.degree(v.index) == 0]
        res_g.delete_vertices(isolated)

    return res_g


