from typing import Optional, Callable
import pandas as pd
from ciga.ciga import TGraph


def filter_edges(
        tgraph: TGraph,
        min_weight: Optional[float] = None,
        max_weight: Optional[float] = None,
        condition: Optional[Callable] = None
) -> TGraph:
    """
    Filter edges of a TGraph based on weight thresholds or a custom condition.
    This creates a new TGraph with the underlying data filtered.

    Args:
        tgraph (TGraph): The TGraph object to filter.
        min_weight (float, optional): The minimum weight to keep (inclusive). Defaults to None.
        max_weight (float, optional): The maximum weight to keep (inclusive). Defaults to None.
        condition (Callable, optional): A custom function applied to each row in the TGraph data. Defaults to None.

    Returns:
        TGraph: A new TGraph object with filtered data.
    """
    df = tgraph.data.copy().reset_index()

    if condition is not None:
        df = df[df.apply(condition, axis=1)]
    else:
        if 'weight' not in df.columns:
            raise ValueError("Weight column not found in TGraph data.")
            
        if min_weight is not None:
            df = df[df['weight'] >= min_weight]
        if max_weight is not None:
            df = df[df['weight'] <= max_weight]

    # Reconstruct the TGraph with the new filtered dataframe
    return TGraph(
        data=df, 
        positions=tgraph._position, 
        directed=tgraph.is_directed
    )


def _align_tgraphs(tg1: TGraph, tg2: TGraph):
    """Helper method to validate and align TGraph underlying dataframes."""
    if tg1.is_directed != tg2.is_directed:
        raise ValueError("TGraphs must have the same directedness.")
    if list(tg1._position) != list(tg2._position):
        raise ValueError("TGraphs must have the same positions (time columns).")
        
    df1 = tg1.data.copy().reset_index()
    df2 = tg2.data.copy().reset_index()
    
    merge_cols = list(tg1._position) + ['source', 'target']
    
    # Keep only necessary columns to avoid duplicated columns after merge
    df1 = df1[merge_cols + ['weight']]
    df2 = df2[merge_cols + ['weight']]
    
    return df1, df2, merge_cols


def add_tgraphs_by_weight(tg1: TGraph, tg2: TGraph) -> TGraph:
    """
    Add the interactions of two TGraph objects. 
    Matches rows by time-step and characters, summing their edge weights.

    Args:
        tg1 (TGraph): The first TGraph.
        tg2 (TGraph): The second TGraph.

    Returns:
        TGraph: A new TGraph with combined temporal data.
    """
    df1, df2, merge_cols = _align_tgraphs(tg1, tg2)
    
    # Outer join to capture interactions from both tgraphs
    df_merged = pd.merge(df1, df2, on=merge_cols, how='outer', suffixes=('_1', '_2'))
    
    # Sum weights, treating NaNs as 0
    df_merged['weight'] = df_merged['weight_1'].fillna(0) + df_merged['weight_2'].fillna(0)
    
    df_final = df_merged[merge_cols + ['weight']]
    
    return TGraph(data=df_final, positions=tg1._position, directed=tg1.is_directed)


def subtract_tgraphs_by_weight(tg1: TGraph, tg2: TGraph) -> TGraph:
    """
    Subtract the interactions of the second TGraph from the first.
    Matches rows by time-step and characters, subtracting tg2's weights from tg1's.
    Only edges with resultant weight > 0 are kept.

    Args:
        tg1 (TGraph): The base TGraph.
        tg2 (TGraph): The TGraph representing subtractions.

    Returns:
        TGraph: A new TGraph representing the remaining temporal data.
    """
    df1, df2, merge_cols = _align_tgraphs(tg1, tg2)
    
    # Left join because we only care about discounting edges that exist in tg1
    df_merged = pd.merge(df1, df2, on=merge_cols, how='left')
    
    df_merged['weight_y'] = df_merged['weight_y'].fillna(0)
    df_merged['weight'] = df_merged['weight_x'] - df_merged['weight_y']
    
    # Prune non-positive weights
    df_final = df_merged[df_merged['weight'] > 0].copy()
    
    df_final = df_final[merge_cols + ['weight']]
    
    return TGraph(data=df_final, positions=tg1._position, directed=tg1.is_directed)

