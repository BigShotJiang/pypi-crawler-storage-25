import pytest
import pandas as pd
from ciga.ciga import TGraph
from ciga.utils.data_utils import prepare_data

@pytest.fixture
def advanced_tgraph():
    df = pd.DataFrame({
        'time': [1, 1, 2, 2, 3],
        'source': ['A', 'A', 'B', 'B', 'B'],
        'target': ['B', 'C', 'C', 'A', 'A'],
        'weight': [10.0, 5.0, 3.0, 7.0, 4.0]
    })
    prepared_df = prepare_data(df, positions=('time',), source='source', target='target', weight='weight')
    return TGraph(data=prepared_df, positions=('time',), directed=True)

def test_get_graph_accumulate(advanced_tgraph):
    # Step 1: A->B, A->C
    g1 = advanced_tgraph.get_graph(time_point=(1,), accumulate=False)
    assert g1.ecount() == 2

    # Step 2: B->C, B->A
    g2 = advanced_tgraph.get_graph(time_point=(2,), accumulate=False)
    assert g2.ecount() == 2
    
    # Step 2 Accumulate: A->B(10), A->C(5), B->C(3), B->A(7)
    g2_acc = advanced_tgraph.get_graph(time_point=(2,), accumulate=True)
    assert g2_acc.ecount() == 4
    edge_weights = { (g2_acc.vs[e.source]['name'], g2_acc.vs[e.target]['name']): e['weight'] for e in g2_acc.es }
    assert edge_weights[('B', 'C')] == 3.0

def test_get_graph_weight_modifiers(advanced_tgraph):
    # Step 3 Accumulate: A->B(10), A->C(5), B->C(3), B->A(11) -> wait, B->A at t=2 is 7, at t=3 is 4, total = 11.
    g3_acc = advanced_tgraph.get_graph(time_point=(3,), accumulate=True)
    edge_weights = { (g3_acc.vs[e.source]['name'], g3_acc.vs[e.target]['name']): e['weight'] for e in g3_acc.es }
    assert edge_weights[('B', 'A')] == 11.0
    
    # Test mean_weight
    # At t=3, if mean_weight=True, we divide by step count? 
    # Let's see how mean_weight works: "divided by the number of time steps".
    # Since we are at step 3, number of steps is 3!
    g3_mean = advanced_tgraph.get_graph(time_point=(3,), accumulate=True, mean_weight=True)
    edge_weights_mean = { (g3_mean.vs[e.source]['name'], g3_mean.vs[e.target]['name']): e['weight'] for e in g3_mean.es }
    assert edge_weights_mean[('B', 'A')] == 11.0 / 3

    # Test w_normalized
    # Max accumulated weight at step 3 is 11.0 (from B->A).
    g3_norm = advanced_tgraph.get_graph(time_point=(3,), accumulate=True, w_normalized=True)
    edge_weights_norm = { (g3_norm.vs[e.source]['name'], g3_norm.vs[e.target]['name']): e['weight'] for e in g3_norm.es }
    assert edge_weights_norm[('B', 'A')] == 1.0
    assert edge_weights_norm[('A', 'B')] == 10.0 / 11.0

    # Test invert_weight=True ("reciprocal" logic, weight -> 1/(weight+epsilon))
    g3_inv = advanced_tgraph.get_graph(time_point=(3,), accumulate=True, invert_weight=True)
    edge_weights_inv = { (g3_inv.vs[e.source]['name'], g3_inv.vs[e.target]['name']): e['weight'] for e in g3_inv.es }
    import math
    assert pytest.approx(edge_weights_inv[('B', 'A')], 0.0001) == 1.0 / (11.0 + 1e-6)

