"""Validation and repair of pyproject.toml structure."""

from __future__ import annotations

from typing import TYPE_CHECKING

import tomlkit
from tomlkit.items import Array, Table

from usethis._config import usethis_config
from usethis._console import tick_print
from usethis._file.dir import get_project_name_from_dir
from usethis._file.pyproject_toml.io_ import PyprojectTOMLManager

if TYPE_CHECKING:
    from tomlkit import TOMLDocument


def ensure_pyproject_validity():
    """Ensure pyproject.toml has a valid structure, adding missing required fields."""
    if not (usethis_config.cpd() / "pyproject.toml").exists():
        return

    toml_document = PyprojectTOMLManager().get()

    try:
        project = _ensure_project_section(toml_document)
        project = _ensure_project_name(project, toml_document)
        _ensure_project_version(project)
    except TypeError:
        # Give up - the file is badly formatted. Let uv give a better error message.
        return

    PyprojectTOMLManager().commit(toml_document)


def _ensure_project_section(toml_document: TOMLDocument) -> Table:
    if "project" not in toml_document:
        tick_print("Adding 'project' section to 'pyproject.toml'.")
        toml_document["project"] = {}

    project = toml_document["project"]
    if not isinstance(project, Table):
        msg = f"Expected 'project' to be a TOML Table, got '{type(project)}'."
        raise TypeError(msg)

    return project


def _ensure_project_version(project: Table) -> None:
    if "version" in project:
        return
    if "dynamic" in project:
        dynamic = project["dynamic"]
        if isinstance(dynamic, Array) and "version" in dynamic:
            # N.B. if the dynamic section is in the wrong format then
            # we will put 'version' in the project section.
            return
    tick_print("Setting project version to '0.1.0' in 'pyproject.toml'.")
    project["version"] = "0.1.0"


def _ensure_project_name(project: Table, toml_document: TOMLDocument) -> Table:
    if "name" in project:
        return project

    name = get_project_name_from_dir()

    tick_print(f"Setting project name to '{name}' in 'pyproject.toml'.")
    if project.value:
        # Build a new table with 'name' first, then copy all existing items.
        # We iterate `body` (not `items()`) because `body` includes comments and
        # whitespace entries with None keys that cannot be added via dict-style
        # assignment. `Table.append` accepts None keys, covering all entry types.
        new_table = tomlkit.table()
        new_table["name"] = name
        for key, item in project.value.body:
            new_table.append(key, item)
        toml_document["project"] = new_table
        return new_table
    else:
        project["name"] = name
        return project
