import pytest

from usethis._pipeweld.containers import depgroup, parallel, series
from usethis._pipeweld.func import (
    Adder,
    Partition,
    _extract_ordered_steps,
    _flatten_partition,
    _linearize_component,
    _op_series_merge_partitions,
    _parallel_merge_partitions,
    get_predecessor,
)
from usethis._pipeweld.ops import InsertParallel, InsertSuccessor
from usethis._pipeweld.result import WeldResult


class TestAdder:
    class TestAdd:
        def test_empty_series_start(self):
            # Arrange
            step = "A"
            pipeline = series()

            # Act
            result = Adder(pipeline=pipeline, step=step).add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.instructions == [
                # N.B. None means Place at the start of the pipeline
                InsertParallel(after=None, step="A")
            ]
            assert result.solution == series("A")

        def test_series_singleton_start(self):
            # Arrange
            adder = Adder(step="B", pipeline=series("A"))

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.instructions == [
                # N.B. None means Place at the start of the pipeline
                InsertParallel(after=None, step="B")
            ]
            assert result.solution == series(parallel("A", "B"))

        def test_parallel_singleton_start(self):
            # Arrange
            adder = Adder(
                step="B",
                pipeline=series(parallel("A")),
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.instructions == [
                # N.B. None means Place at the start of the pipeline
                InsertParallel(after=None, step="B")
            ]
            assert result.solution == series(parallel("A", "B"))

        def test_two_element_start(self):
            # Arrange
            adder = Adder(
                step="C",
                pipeline=series("A", "B"),
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.instructions == [
                # N.B. None means Place at the start of the pipeline
                InsertParallel(after=None, step="C")
            ]
            assert result.solution == series(parallel("A", "C"), "B")

        def test_prerequisite(self):
            # Arrange
            prerequisites = {"A"}
            adder = Adder(
                step="C",
                pipeline=series("A", "B"),
                prerequisites=prerequisites,
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.instructions == [InsertParallel(after="A", step="C")]
            assert result.solution == series("A", parallel("B", "C"))

        def test_mixed_dependency_parallelism_of_steps(self):
            # Arrange
            adder = Adder(
                step="C",
                pipeline=series(parallel("A", "B")),
                prerequisites={"A"},
                postrequisites={"B"},
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series("A", "C", "B")
            assert result.instructions == [
                InsertSuccessor(after=None, step="A"),
                InsertSuccessor(after="A", step="B"),
                InsertSuccessor(after="A", step="C"),
            ]

        def test_mixed_dependency_parallelism_of_series(self):
            # Arrange
            adder = Adder(
                step="F",
                pipeline=series("A", parallel(series("B", "D"), series("C", "E"))),
                prerequisites={"B"},
                postrequisites={"E"},
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series("A", "B", parallel("D", "C", "F"), "E")
            assert result.instructions == [
                InsertSuccessor(after="A", step="B"),
                InsertSuccessor(after="B", step="C"),
                InsertParallel(after="B", step="D"),
                InsertSuccessor(after="C", step="E"),
                InsertParallel(after="B", step="F"),
            ]

        def test_singleton_series(self):
            # Arrange
            adder = Adder(
                step="B",
                pipeline=series("A"),
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series(parallel("A", "B"))

        def test_nested_series(self):
            # Arrange
            adder = Adder(
                step="B",
                pipeline=series(series("A")),
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series(series(parallel("A", "B")))

        class TestDoubleNesting:
            def test_no_nesting(self):
                # Arrange
                adder = Adder(
                    step="H",
                    pipeline=series("D", "E", "F"),
                    prerequisites={"A"},
                    postrequisites={"B", "E"},
                )

                # Act
                result = adder.add()

                # Assert
                assert isinstance(result, WeldResult)
                assert result.solution == series(parallel("D", "H"), "E", "F")

            def test_single_nesting(self):
                # Arrange
                adder = Adder(
                    step="H",
                    pipeline=series(series("D", "E", "F")),
                )

                # Act
                result = adder.add()

                # Assert
                assert isinstance(result, WeldResult)
                assert result.solution == series(series(parallel("D", "H"), "E", "F"))

            def test_single_nesting_with_dep(self):
                # Arrange
                adder = Adder(
                    step="H",
                    pipeline=series(series("D", "E", "F")),
                    prerequisites={"A"},
                    postrequisites={"B", "E"},
                )

                # Act
                result = adder.add()

                # Assert
                assert isinstance(result, WeldResult)
                assert result.solution == series(parallel("D", "H"), series("E", "F"))

            def test_multiple_nesting(self):
                # Arrange
                adder = Adder(
                    step="H",
                    pipeline=series(series(parallel(series("D", "E", "F")))),
                    prerequisites={"A"},
                    postrequisites={"B", "E"},
                )

                # Act
                result = adder.add()

                # Assert
                assert isinstance(result, WeldResult)
                assert result.solution == series(
                    series(parallel(series(parallel("D", "H"), "E", "F")))
                )

            def test_full_complex_case(self):
                # Arrange
                adder = Adder(
                    step="H",
                    pipeline=series(
                        parallel("A", "B"),
                        "C",
                        series(parallel(series("D", "E", "F"), "G")),
                    ),
                    prerequisites={"A"},
                    postrequisites={"B", "E"},
                )

                # Act
                result = adder.add()

                # Assert
                assert isinstance(result, WeldResult)
                assert result.solution == series(
                    "A", "H", "B", "C", parallel(series("D", "E", "F"), "G")
                )

        def test_multi_level_heirarchy(self):
            # Arrange
            adder = Adder(
                step="E",
                pipeline=series("A", parallel("B", series("C", "D"))),
                prerequisites={"C"},
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series(
                "A", parallel("B", series("C", parallel("D", "E")))
            )
            assert result.instructions == [InsertParallel(after="C", step="E")]

        def test_mixed_dependency_parallelism_of_series_pure_parallel(self):
            # Arrange
            adder = Adder(
                step="E",
                pipeline=series(parallel(series("A", "B"), series("C", "D"))),
                prerequisites={"A"},
                postrequisites={"D"},
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series("A", parallel("C", "E", "B"), "D")

        def test_config_groups(self):
            # Arrange
            adder = Adder(
                step="A",
                pipeline=series(depgroup("B", "C", config_group="x")),
                prerequisites={"B"},
                postrequisites={"C"},
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series(
                depgroup("B", config_group="x"), "A", depgroup("C", config_group="x")
            )

        def test_config_groups_in_series(self):
            # Arrange
            adder = Adder(
                step="E",
                pipeline=series("A", depgroup("B", "C", config_group="x")),
                prerequisites={"B"},
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series(
                "A",
                depgroup("B", config_group="x"),
                parallel(depgroup("C", config_group="x"), "E"),
            )

        def test_insert_at_end(self):
            # Arrange
            adder = Adder(
                step="C",
                pipeline=series("A", "B"),
                prerequisites={"B"},
            )

            # Act
            result = adder.add()

            # Assert
            assert isinstance(result, WeldResult)
            assert result.solution == series("A", "B", "C")


class TestParallelMergePartitions:
    def test_basic(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component=None,
            nondependent_component="C",
            postrequisite_component=None,
            top_ranked_endpoint="C",
        )
        partition2 = Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )

        # Act
        result, instructions = _parallel_merge_partitions(
            partition1, partition2, predecessor=None
        )

        # Assert
        assert result == Partition(
            prerequisite_component="A",
            nondependent_component="C",
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )
        assert instructions == [
            InsertSuccessor(after=None, step="A"),
            InsertSuccessor(after="A", step="C"),
            InsertSuccessor(after="C", step="B"),
        ]


class TestFlattenPartition:
    def test_basic(self):
        # Arrange
        partition = Partition(
            prerequisite_component="A",
            nondependent_component="B",
            postrequisite_component="C",
            top_ranked_endpoint="C",
        )

        # Act
        result = _flatten_partition(partition)

        # Assert
        assert result == series("A", "B", "C")

    def test_no_components(self):
        # Arrange
        partition = Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component=None,
            top_ranked_endpoint="fake",
        )

        # Act, Assert
        with pytest.raises(ValueError, match="Flatten failed: no components"):
            _flatten_partition(partition)


class TestOpSeriesMergePartitions:
    def test_rhs_prerequisite_lhs_no_prerequisite(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component=None,
            nondependent_component="C",
            postrequisite_component=None,
            top_ranked_endpoint="C",
        )
        partition2 = Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component=series("C", "A"),
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )

    def test_both_prerequisite(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component=None,
            top_ranked_endpoint="A",
        )
        partition2 = Partition(
            prerequisite_component="B",
            nondependent_component=None,
            postrequisite_component=None,
            top_ranked_endpoint="B",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component=series("A", "B"),
            nondependent_component=None,
            postrequisite_component=None,
            top_ranked_endpoint="B",
        )

    def test_no_rhs_prerequsite_rhs_non_dependent_and_lhs_postrequsite(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )
        partition2 = Partition(
            prerequisite_component=None,
            nondependent_component="C",
            postrequisite_component=None,
            top_ranked_endpoint="C",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component=series("B", "C"),
            top_ranked_endpoint="C",
        )

    def test_both_prerequisite_rhs_non_dependent_and_lhs_postrequsite(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )
        partition2 = Partition(
            prerequisite_component="D",
            nondependent_component="C",
            postrequisite_component=None,
            top_ranked_endpoint="C",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component=series("A", "B", "D"),
            nondependent_component="C",
            postrequisite_component=None,
            top_ranked_endpoint="C",
        )

    def test_no_prerequsites_rhs_non_dependent_and_lhs_postrequsite(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )
        partition2 = Partition(
            prerequisite_component=None,
            nondependent_component="A",
            postrequisite_component=None,
            top_ranked_endpoint="A",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component=series("B", "A"),
            top_ranked_endpoint="A",
        )

    def test_no_prequisites_and_no_nondependents_both_postrequisites(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )
        partition2 = Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component="A",
            top_ranked_endpoint="A",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component=series("B", "A"),
            top_ranked_endpoint="A",
        )

    def test_no_rhs_prequisite_and_lhs_prerequisite_and_no_nondependents(self):
        # Arrange
        partition1 = Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component=None,
            top_ranked_endpoint="A",
        )
        partition2 = Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component="A",
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )

    def test_rhs_nondependents_and_no_prequisites_and_lhs_prerequisite_and_nondependents(
        self,
    ):
        # Arrange
        partition1 = Partition(
            prerequisite_component="A",
            nondependent_component="C",
            postrequisite_component=None,
            top_ranked_endpoint="A",
        )
        partition2 = Partition(
            prerequisite_component=None,
            nondependent_component="B",
            postrequisite_component=None,
            top_ranked_endpoint="B",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component="A",
            nondependent_component=series("C", "B"),
            postrequisite_component=None,
            top_ranked_endpoint="B",
        )

    def test_rhs_no_nondependents_and_no_prequisites_and_lhs_prerequisite_and_nondependents(
        self,
    ):
        # Arrange
        partition1 = Partition(
            prerequisite_component="A",
            nondependent_component="C",
            postrequisite_component=None,
            top_ranked_endpoint="A",
        )
        partition2 = Partition(
            prerequisite_component=None,
            nondependent_component=None,
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )

        # Act
        partition = _op_series_merge_partitions(partition1, partition2)

        # Assert
        assert partition == Partition(
            prerequisite_component="A",
            nondependent_component="C",
            postrequisite_component="B",
            top_ranked_endpoint="B",
        )


class TestExtractOrderedSteps:
    def test_single_string(self):
        assert _extract_ordered_steps("A") == ["A"]

    def test_flat_series(self):
        assert _extract_ordered_steps(series("A", "B", "C")) == ["A", "B", "C"]

    def test_parallel(self):
        result = _extract_ordered_steps(parallel("A", "B"))
        assert sorted(result) == ["A", "B"]

    def test_nested_series(self):
        assert _extract_ordered_steps(series("A", series("B", "C"))) == ["A", "B", "C"]

    def test_depgroup(self):
        assert _extract_ordered_steps(depgroup("A", "B", config_group="x")) == [
            "A",
            "B",
        ]


class TestLinearizeComponent:
    def test_single_string(self):
        assert _linearize_component("A", new_step="A", original_order=[]) == ["A"]

    def test_series_of_strings(self):
        assert _linearize_component(
            series("A", "B", "C"), new_step="D", original_order=["A", "B", "C"]
        ) == ["A", "B", "C"]

    def test_parallel_new_step_last(self):
        result = _linearize_component(
            parallel("A", "B"), new_step="B", original_order=["A"]
        )
        assert result == ["A", "B"]

    def test_parallel_preserves_existing_order(self):
        result = _linearize_component(
            parallel("B", "A"), new_step="C", original_order=["A", "B"]
        )
        assert result == ["A", "B"]

    def test_series_with_parallel(self):
        result = _linearize_component(
            series(parallel("foo", "new"), "codespell"),
            new_step="new",
            original_order=["foo", "codespell"],
        )
        assert result == ["foo", "new", "codespell"]

    def test_depgroup(self):
        result = _linearize_component(
            depgroup("A", "B", config_group="x"),
            new_step="C",
            original_order=["A", "B"],
        )
        assert result == ["A", "B"]


class TestAdderForceLinear:
    def test_parallel_resolved_to_linear(self):
        adder = Adder(
            pipeline=series("A"),
            step="B",
            force_linear=True,
        )
        result = adder.add()
        # A comes first (existing), B last (new)
        assert result.solution == series("A", "B")

    def test_new_step_before_postrequisite(self):
        adder = Adder(
            pipeline=series("codespell"),
            step="ruff",
            postrequisites={"codespell"},
            force_linear=True,
        )
        result = adder.add()
        assert result.solution == series("ruff", "codespell")

    def test_new_step_after_prerequisite(self):
        adder = Adder(
            pipeline=series("pyproject-fmt"),
            step="ruff",
            prerequisites={"pyproject-fmt"},
            force_linear=True,
        )
        result = adder.add()
        assert result.solution == series("pyproject-fmt", "ruff")

    def test_empty_pipeline(self):
        adder = Adder(
            pipeline=series(),
            step="A",
            force_linear=True,
        )
        result = adder.add()
        assert result.solution == series("A")

    def test_mixed_nondependent_and_postrequisite(self):
        adder = Adder(
            pipeline=series("foo", "codespell"),
            step="ruff-format",
            postrequisites={"codespell"},
            force_linear=True,
        )
        result = adder.add()
        assert result.solution == series("foo", "ruff-format", "codespell")


class TestGetPredecessor:
    def test_single_string_found(self):
        assert get_predecessor("A", "A") is None

    def test_single_string_not_found(self):
        with pytest.raises(ValueError, match="not found"):
            get_predecessor("A", "B")

    def test_flat_series_first(self):
        assert get_predecessor(series("A", "B", "C"), "A") is None

    def test_flat_series_middle(self):
        assert get_predecessor(series("A", "B", "C"), "B") == "A"

    def test_flat_series_last(self):
        assert get_predecessor(series("A", "B", "C"), "C") == "B"

    def test_flat_series_not_found(self):
        with pytest.raises(ValueError, match="not found"):
            get_predecessor(series("A", "B"), "Z")

    def test_nested_series(self):
        component = series("A", series("B", "C"))
        assert get_predecessor(component, "B") == "A"

    def test_nested_series_inner_predecessor(self):
        component = series("A", series("B", "C"))
        assert get_predecessor(component, "C") == "B"

    def test_parallel_first_in_branch(self):
        component = series("A", parallel("B", "C"))
        assert get_predecessor(component, "B") == "A"

    def test_parallel_other_branch(self):
        component = series("A", parallel("B", "C"))
        assert get_predecessor(component, "C") == "A"

    def test_parallel_not_found(self):
        with pytest.raises(ValueError, match="not found"):
            get_predecessor(parallel("A", "B"), "Z")

    def test_parallel_at_start(self):
        component = parallel("A", "B")
        assert get_predecessor(component, "A") is None

    def test_depgroup(self):
        component = depgroup("A", "B", config_group="x")
        assert get_predecessor(component, "B") == "A"

    def test_depgroup_first(self):
        component = depgroup("A", "B", config_group="x")
        assert get_predecessor(component, "A") is None

    def test_series_with_depgroup(self):
        component = series("X", depgroup("A", "B", config_group="x"))
        assert get_predecessor(component, "A") == "X"

    def test_deep_nesting(self):
        component = series("A", series("B", series("C", "D")))
        assert get_predecessor(component, "D") == "C"
        assert get_predecessor(component, "C") == "B"
        assert get_predecessor(component, "B") == "A"
        assert get_predecessor(component, "A") is None
