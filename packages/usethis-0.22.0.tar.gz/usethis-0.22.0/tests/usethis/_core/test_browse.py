import pytest
import typer

from usethis._core.browse import browse_pypi


class TestPyPI:
    def test_message(self, capfd: pytest.CaptureFixture[str]):
        # Act
        browse_pypi(package="numpy", browser=False)

        # Assert
        out, err = capfd.readouterr()
        assert not err
        assert out == "☐ Open URL <https://pypi.org/project/numpy/>.\n"

    def test_open_in_browser(self, monkeypatch: pytest.MonkeyPatch):
        # Arrange
        class MockLaunch:
            def __init__(self):
                self.url = None

            def __call__(self, url: str):
                self.url = url

        mock_launch = MockLaunch()
        monkeypatch.setattr(typer, "launch", mock_launch)

        # Act
        browse_pypi(package="numpy", browser=True)

        # Assert
        assert mock_launch.url == "https://pypi.org/project/numpy/"
