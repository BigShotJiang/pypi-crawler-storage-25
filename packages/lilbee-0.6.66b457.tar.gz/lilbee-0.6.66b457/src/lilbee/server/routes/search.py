"""Search, ask, ask_stream, chat, and chat_stream route handlers."""

from __future__ import annotations

from litestar import get, post
from litestar.exceptions import HTTPException, ValidationException
from litestar.params import Parameter
from litestar.response import Stream

from lilbee.query import ChatMessage as ChatMessageDict
from lilbee.results import DocumentResult
from lilbee.server import handlers
from lilbee.server.auth import read_only
from lilbee.server.models import (
    AskRequest,
    AskResponse,
    ChatRequest,
)
from lilbee.store import scope_to_chunk_type


@get("/api/search")
@read_only
async def search_route(
    q: str = Parameter(query="q"),
    top_k: int = Parameter(query="top_k", default=5, le=100),
    chunk_type: str | None = Parameter(query="chunk_type", default=None),
) -> list[DocumentResult]:
    """Search indexed documents by semantic similarity. No LLM call required."""
    try:
        chunk_type = scope_to_chunk_type(chunk_type)
    except ValueError as exc:
        raise ValidationException(str(exc)) from exc
    try:
        return await handlers.search(q, top_k=top_k, chunk_type=chunk_type)
    except ValueError as exc:
        raise ValidationException(str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@post("/api/ask")
async def ask_route(data: AskRequest) -> AskResponse:
    """One-shot RAG question returning an answer with source chunks."""
    try:
        return await handlers.ask(
            question=data.question,
            top_k=data.top_k,
            options=data.options,
            chunk_type=data.chunk_type,
        )
    except ValueError as exc:
        raise ValidationException(str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@post("/api/ask/stream")
async def ask_stream_route(data: AskRequest) -> Stream:
    """Streaming SSE version of ask, emitting token-by-token answer chunks."""
    return Stream(
        handlers.ask_stream(
            question=data.question,
            top_k=data.top_k,
            options=data.options,
            chunk_type=data.chunk_type,
        ),
        media_type="text/event-stream",
    )


@post("/api/chat")
async def chat_route(data: ChatRequest) -> AskResponse:
    """RAG chat with conversation history, returning an answer with sources."""
    history: list[ChatMessageDict] = [
        ChatMessageDict(role=m.role, content=m.content) for m in data.history
    ]
    return await handlers.chat(
        question=data.question,
        history=history,
        top_k=data.top_k,
        options=data.options,
        chunk_type=data.chunk_type,
    )


@post("/api/chat/stream")
async def chat_stream_route(data: ChatRequest) -> Stream:
    """Streaming SSE version of chat with conversation history."""
    history: list[ChatMessageDict] = [
        ChatMessageDict(role=m.role, content=m.content) for m in data.history
    ]
    return Stream(
        handlers.chat_stream(
            question=data.question,
            history=history,
            top_k=data.top_k,
            options=data.options,
            chunk_type=data.chunk_type,
        ),
        media_type="text/event-stream",
    )
