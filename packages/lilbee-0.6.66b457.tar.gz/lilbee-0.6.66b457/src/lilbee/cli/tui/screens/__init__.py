"""TUI screen definitions."""
