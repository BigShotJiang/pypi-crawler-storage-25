"""TUI widget definitions."""
