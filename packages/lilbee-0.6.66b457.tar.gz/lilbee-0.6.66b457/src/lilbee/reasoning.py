"""Reasoning token filter — detects <think>...</think> tags in streaming output.

Reasoning models (Qwen3, DeepSeek-R1) wrap their thinking process in
``<think>...</think>`` tags. This module provides a stateful filter that
classifies tokens as reasoning or response content.
"""

from __future__ import annotations

import contextlib
import re
from collections.abc import Generator, Iterator
from dataclasses import dataclass

from lilbee.providers.base import ClosableIterator

_OPEN_TAG = "<think>"
_CLOSE_TAG = "</think>"
_THINK_BLOCK_RE = re.compile(r"<think>[\s\S]*?</think>\s*|<think>[\s\S]*$")


@dataclass
class StreamToken:
    """A classified token from the stream."""

    content: str
    is_reasoning: bool


class _TagParser:
    """Stateful parser that tracks whether we're inside a thinking block."""

    def __init__(self, *, show: bool) -> None:
        self.show = show
        self.buf = ""
        self.in_thinking = False
        self.reasoning_chars = 0

    def feed(self, token: str) -> list[StreamToken]:
        """Feed a token and return any complete StreamTokens."""
        self.buf += token
        result: list[StreamToken] = []
        while self.buf:
            emitted = self._process_thinking() if self.in_thinking else self._process_normal()
            if emitted is None:
                break  # waiting for more data (partial tag)
            if emitted.content:
                result.append(emitted)
        return result

    def flush(self) -> StreamToken | None:
        """Flush remaining buffer at end of stream."""
        if not self.buf:
            return None
        if self.in_thinking:
            return StreamToken(content=self.buf, is_reasoning=True) if self.show else None
        return StreamToken(content=self.buf, is_reasoning=False)

    def _process_thinking(self) -> StreamToken | None:
        """Process buffer while inside a <think> block. Returns None if waiting."""
        close_idx = self.buf.find(_CLOSE_TAG)
        if close_idx == -1:
            if _could_be_partial(_CLOSE_TAG, self.buf):
                return None  # wait for more
            content = self.buf
            self.reasoning_chars += len(content)
            self.buf = ""
            return (
                StreamToken(content=content, is_reasoning=True)
                if self.show
                else StreamToken(content="", is_reasoning=True)
            )

        thinking_content = self.buf[:close_idx]
        self.reasoning_chars += len(thinking_content)
        self.buf = self.buf[close_idx + len(_CLOSE_TAG) :]
        self.in_thinking = False
        if thinking_content and self.show:
            return StreamToken(content=thinking_content, is_reasoning=True)
        return StreamToken(content="", is_reasoning=True)

    def _process_normal(self) -> StreamToken | None:
        """Process buffer while outside thinking blocks. Returns None if waiting."""
        open_idx = self.buf.find(_OPEN_TAG)
        if open_idx == -1:
            if _could_be_partial(_OPEN_TAG, self.buf):
                return None  # wait for more
            content = self.buf
            self.buf = ""
            return StreamToken(content=content, is_reasoning=False)

        before = self.buf[:open_idx]
        self.buf = self.buf[open_idx + len(_OPEN_TAG) :]
        self.in_thinking = True
        return StreamToken(content=before, is_reasoning=False)


_MAX_REASONING_CHARS = 16_000  # ~4K tokens — safety limit for runaway reasoning

# Drain at most this many chars of post-truncation response content
# before giving up; each token pull triggers another inference step.
_DRAIN_CAP = 512


def filter_reasoning(tokens: Iterator[str], *, show: bool) -> Iterator[StreamToken]:
    """Filter ``<think>...</think>`` tags from a token stream; cap runaway reasoning.

    When *show* is True, yields thinking content as ``StreamToken(is_reasoning=True)``;
    when False, strips it. Always closes the upstream iterator on exit so a
    runaway think loop doesn't leave llama.cpp holding the chat lock.
    """
    parser = _TagParser(show=show)
    try:
        truncated = yield from _stream_until_cap(parser, tokens)
        if truncated:
            yield from _drain_after_truncation(parser, tokens)
        final = parser.flush()
        if final and final.content:
            yield final
    finally:
        _close_iterator(tokens)


def _stream_until_cap(
    parser: _TagParser, tokens: Iterator[str]
) -> Generator[StreamToken, None, bool]:
    """Yield from *tokens* until the reasoning cap fires. Returns True if truncated."""
    for token in tokens:
        for st in parser.feed(token):
            if st.content:
                yield st
        if parser.reasoning_chars > _MAX_REASONING_CHARS:
            parser.in_thinking = False
            parser.buf = ""
            yield StreamToken(content="\n[reasoning truncated]", is_reasoning=True)
            return True
    return False


def _drain_after_truncation(parser: _TagParser, tokens: Iterator[str]) -> Iterator[StreamToken]:
    """After truncation, yield up to ``_DRAIN_CAP`` chars of response content."""
    drain_chars = 0
    for token in tokens:
        drain_chars += len(token)
        if drain_chars > _DRAIN_CAP:
            return
        for st in parser.feed(token):
            if st.content and not st.is_reasoning:
                yield st


def _close_iterator(tokens: Iterator[str]) -> None:
    """Close *tokens* if it satisfies the ClosableIterator protocol."""
    if isinstance(tokens, ClosableIterator):
        with contextlib.suppress(Exception):
            tokens.close()


def strip_reasoning(text: str) -> str:
    """Remove ``<think>...</think>`` blocks from a complete (non-streaming) string."""
    return _THINK_BLOCK_RE.sub("", text)


def _could_be_partial(tag: str, buf: str) -> bool:
    """Check if the end of buf could be the start of the given tag."""
    return any(buf.endswith(tag[:length]) for length in range(1, len(tag)))
