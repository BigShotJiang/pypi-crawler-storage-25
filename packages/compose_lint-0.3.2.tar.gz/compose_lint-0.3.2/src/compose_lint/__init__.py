"""A security-focused linter for Docker Compose files."""

__version__ = "0.3.2"
