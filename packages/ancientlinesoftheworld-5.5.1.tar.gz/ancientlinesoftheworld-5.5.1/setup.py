from setuptools import setup, find_packages
from pathlib import Path

VERSION = "5.5.1"
PACKAGE_NAME = "ancientlinesoftheworld"
MODULE_NAME = "ancient"

root = Path(__file__).parent
long_description = (root / "README.md").read_text(encoding="utf-8")
description = """Convert Persian and English text to 15+ ancient scripts including:
Runic (Viking Futhark), Cuneiform, Pahlavi, Avestan, Manichaean,
Egyptian Hieroglyphs, Akkadian, Linear B, Brahmi, Kharosthi,
Hebrew, Sanskrit, Oracle Bone Script, Elamite, and Phoenician."""
setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description=description,
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Amir Hossein Khazaei",
    author_email="amirhossinpython03@gmail.com",
    url="https://github.com/amirhossinpython/ancientlinesoftheworld",
    license="MIT",

    packages=find_packages(),
    include_package_data=True,

    package_data={
        MODULE_NAME: [
            "background.jpg",
            "NotoSansCuneiform-Regular.ttf",
            "data/*.json",
            "templates/*.html",
            "static/*",
            "static/**/*",
        ],
    },

    install_requires=[
        "deep-translator",
        "Pillow",
        "openai",
        "feedparser",
        "Flask",
        "flask-cors",
        "pyaudio",
        "speechrecognition",
        "pyTelegramBotAPI",
        "rubpy"
        
    ],

    python_requires=">=3.8",

    entry_points={
        "console_scripts": [
            "ancient-convert=ancient.cli:main",
        ],
    }
)
