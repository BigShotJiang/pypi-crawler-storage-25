from openai import OpenAI
import pyaudio
import wave
from ancient import AncientScripts


class SpeechToAncient:
    def __init__(self, api_key: str,base_url="https://api.gapgpt.app/v1", script: str = "cuneiform",output_file="output.mp3",model = "gapgpt/whisper-1"):
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.script = script
        self.converter = AncientScripts()
        self.output_file = output_file
        self.model = model
    
    def record(self, duration: int = 5) -> str:
        """ضبط صدا"""
        try:
            CHUNK = 1024
            FORMAT = pyaudio.paInt16
            CHANNELS = 1
            RATE = 16000
            
            p = pyaudio.PyAudio()
            stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
            
            print(f"🎤 ضبط {duration} ثانیه...")
            frames = [stream.read(CHUNK) for _ in range(0, int(RATE / CHUNK * duration))]
            
            stream.stop_stream()
            stream.close()
            p.terminate()
            
            with wave.open(self.output_file, 'wb') as wf:
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(p.get_sample_size(FORMAT))
                wf.setframerate(RATE)
                wf.writeframes(b''.join(frames))
            
            return self.output_file
        except Exception as e:
            return f"❌ خطا در ضبط صدا: {str(e)}"
    
    def to_ancient(self, duration: int = 5) -> str:
        """ضبط صدا و تبدیل مستقیم به خط باستانی"""
        try:
            audio_file = self.record(duration)
            
            if audio_file.startswith("❌"):
                return audio_file
            
            with open(audio_file, "rb") as f:
                response = self.client.audio.transcriptions.create(
                    model=self.model,
                    file=f
                )
            
            text = response.text
            print(f"📝 متن: {text}")
            
            func = getattr(self.converter, self.script.lower())
            return func(text)
        except Exception as e:
            return f"❌ خطا در تبدیل صدا به خط باستانی: {str(e)}"
    
    def from_file(self, file_path: str) -> str:
        """تبدیل فایل صوتی موجود به خط باستانی"""
        try:
            with open(file_path, "rb") as f:
                response = self.client.audio.transcriptions.create(
                    model=self.model,
                    file=f
                )
            
            text = response.text
            print(f"📝 متن: {text}")
            
            func = getattr(self.converter, self.script.lower())
            return func(text)
        except FileNotFoundError:
            return f"❌ خطا: فایل '{file_path}' پیدا نشد."
        except Exception as e:
            return f"❌ خطا در تبدیل فایل صوتی: {str(e)}"