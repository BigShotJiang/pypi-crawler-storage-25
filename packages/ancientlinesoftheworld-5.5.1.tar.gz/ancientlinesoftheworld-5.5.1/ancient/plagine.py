# ancient/plagine.py

import unicodedata
from pathlib import Path
from typing import Dict
from datetime import datetime


class Plugin:
    """ساخت پلاگین خط جدید با یک دیکشنری ساده"""
    
    def __init__(
        self,
        mapping: Dict[str, str],
        script_name: str,
        description: str = "",
        author: str = ""
    ):
        self.mapping = mapping
        self.script_name = script_name.lower()
        self.description = description or f"خط {script_name}"
        self.author = author or "کاربر"
        
        self._create_plugin_file()
    
    def _format_mapping(self) -> str:
        """فرمت مرتب دیکشنری"""
        lines = [f"    {repr(k)}: {repr(v)}," for k, v in self.mapping.items()]
        return '\n'.join(lines) if lines else "    # خالی"
    
    def _create_plugin_file(self):
        """ساخت فایل پلاگین تمیز"""
        plugins_dir = Path.cwd() / "plugins"
        plugins_dir.mkdir(parents=True, exist_ok=True)
        
        plugin_file = plugins_dir / f"{self.script_name}.py"
        if plugin_file.exists():
            return
        
        content = f'''"""
پلاگین خط {self.script_name}
نویسنده: {self.author}
توضیحات: {self.description}
تاریخ: {datetime.now().strftime("%Y/%m/%d - %H:%M:%S")}
"""

mapping = {{{'' if not self.mapping else chr(10) + self._format_mapping() + chr(10)}}}


def convert_to_{self.script_name}(text: str) -> str:
    import unicodedata
    return unicodedata.normalize("NFKC", ''.join(mapping.get(c, c) for c in text))
'''
        plugin_file.write_text(content, encoding='utf-8')
    
    def created_script(self):
        print(f"✅ پلاگین '{self.script_name}' ساخته شد.")
        return True