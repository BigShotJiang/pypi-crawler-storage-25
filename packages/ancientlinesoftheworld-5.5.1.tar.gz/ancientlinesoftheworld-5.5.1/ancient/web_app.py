# web_app.py
from flask import Flask, render_template, request, jsonify, send_from_directory,send_file
from deep_translator import GoogleTranslator
import logging
import os
from .core import AncientScripts
from flask_cors import CORS
from typing import Tuple, Optional
from .visualizer import AncientImageGenerator
from .analyze_photo import AnalyzePhoto
import os
import time

# تنظیمات لاگ
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# کلاس AncientAIWeb - قرار بگیره تو فایل ancient.py



class AncientAIWeb:
    def __init__(self, api_key: str, base_url: str):
        
        self.api_key = api_key
        self.base_url = base_url
        
        self.app = Flask(__name__)
        CORS(self.app)
        
        self.app.config['UPLOAD_FOLDER'] = 'static/uploads'
        self.app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
        
        os.makedirs(self.app.config['UPLOAD_FOLDER'], exist_ok=True)
        
        self.generator = AncientImageGenerator()
        self.analyzer = AnalyzePhoto(base_url=self.base_url, api_key=self.api_key)
        
        self.image_timestamps = {}
        
        # تنظیمات پیشفرض
        self.enhance_contrast = True
        self.text_color = (255, 215, 0)  # طلایی
        self.rtl = False
        
        self._register_routes()
    
    def set_config(self, enhance_contrast: bool = True, text_color: Tuple[int, int, int] = (255, 215, 0), rtl: bool = False):
        """تنظیمات شخصی‌سازی تصویر"""
        self.enhance_contrast = enhance_contrast
        self.text_color = text_color
        self.rtl = rtl
        return self
    
    def _register_routes(self):
        
        @self.app.route('/')
        def index():
            return render_template('ai.html')
        
        @self.app.route('/generate', methods=['POST'])
        def generate_image():
            try:
                data = request.get_json()
                text = data.get('text', '').strip()
                
                if not text:
                    return jsonify({'error': 'لطفاً متن را وارد کنید'}), 400
                
                timestamp = int(time.time())
                filename = f"ancient_{timestamp}.png"
                filepath = os.path.join(self.app.config['UPLOAD_FOLDER'], filename)
                
                # استفاده از تنظیمات کلاس
                output_path = self.generator.generate_image(
                    text=text,
                    output_filename=filepath,
                    rtl=self.rtl,
                    enhance_contrast=self.enhance_contrast,
                    text_color=self.text_color
                )
                
                self.image_timestamps[filename] = time.time()
                analysis_result = self.analyzer.analyze_image(output_path)
                relative_path = f"/static/uploads/{filename}"
                
                return jsonify({
                    'success': True,
                    'image_path': relative_path,
                    'analysis': analysis_result,
                    'filename': filename
                })
                
            except Exception as e:
                return jsonify({'error': f'خطا در پردازش: {str(e)}'}), 500
        
        @self.app.route('/download/<filename>')
        def download_image(filename):
            try:
                filepath = os.path.join(self.app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(filepath):
                    return send_file(filepath, as_attachment=True, download_name=filename)
                return jsonify({'error': 'فایل یافت نشد'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 500
    
    def run_app(self, host: str = "0.0.0.0", port: int = 5000, debug: bool = False):
        print(f"🏛️ AncientAIWeb running on http://{host}:{port}")
        self.app.run(host=host, port=port, debug=debug)
class AncientWeb:
    """
    اجرای وب اپلیکیشن لوکال برای تبدیل متن به خطوط باستانی
    """

    def __init__(self, version="5.4.1"):
        self.version = version
        self.convert = AncientScripts()

        # مسیر قالب‌ها و فایل‌های استاتیک داخل پکیج
        base_dir = os.path.dirname(__file__)
        template_dir = os.path.join(base_dir, "templates")
        static_dir = os.path.join(base_dir, "static")

        self.app = Flask(__name__, 
                         template_folder=template_dir, 
                         static_folder=static_dir)
        
        self._setup_routes()

    # --------------------------- Routes ---------------------------
    def _setup_routes(self):

        @self.app.route('/')
        def index():
            return render_template('index.html', version=self.version)

        @self.app.route('/convert', methods=['POST'])
        def convert_text():
            data = request.get_json()
            text = data.get('text', '')
            language = data.get('language', '')

            logger.info(f'Request: text="{text}", language="{language}"')

            converted = self._convert(text, language)
            return jsonify({'result': converted})

        @self.app.route('/service-worker.js')
        def service_worker():
            return send_from_directory(self.app.static_folder, 'service-worker.js')


    # --------------------------- Converter ---------------------------
    def _convert(self, text, language):
        try:
            if language == 'cuneiform':
                return self.convert.cuneiform(text)

            elif language == 'pahlavi':
                return self.convert.pahlavi(text)

            elif language == 'manichaean':
                return self.convert.manichaean(text)

            elif language == 'hieroglyph':
                return self.convert.hieroglyph(text)

            elif language == 'Hebrew':
                return GoogleTranslator(source='auto', target='iw').translate(text)

            elif language == "linear_b_optimized":
                return self.convert.linear_b(text)

            elif language == "sanskrit":
                return GoogleTranslator(source='auto', target='sa').translate(text)

            elif language == 'akkadian':
                return self.convert.akkadian(text)

            elif language == 'oracle_bone':
                return self.convert.oracle_bone(text)

            elif language == 'avestan':
                return self.convert.avestan(text)
            
            elif language == 'brahmi':
                return self.convert.brahmi(text)
            elif language == 'kharosthi':
                return self.convert.kharosthi(text=text)
            
            elif language == 'runic':
                return self.convert.runic(text)
            
            elif language == 'phoenician':
                return self.convert.phoenician(text)
            
            elif language == 'elamite':
                return self.convert.elamite(text)
            
            

            return "Invalid language selection."

        except Exception as e:
            logger.error(f"Conversion Error: {e}")
            return f"❌ Error: {e}"

    # --------------------------- Runner ---------------------------
    def run_app(self, host='127.0.0.1', port=5000, debug=True):
        print(f"🌐 WebApp running: http://{host}:{port}")
        self.app.run(host=host, port=port, debug=debug)



class AncientDocs:
    def __init__(self, version="5.5.0"):
        self.doc = Flask(__name__)
        self.version = version
        self._setup_routes()
    
    def _setup_routes(self):
        @self.doc.route('/')
        def  index():
            return render_template('doc.html')
    def run(self, host='127.0.0.1', port=5000, debug=True):
        print(f"🌐 WebApp running: http://{host}:{port}")
        self.app.run(host=host, port=port, debug=debug)


    
    
            
        
        
        
        