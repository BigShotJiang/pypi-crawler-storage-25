from .core import AncientScripts
from .mappings import (
    persian_to_cuneiform_mapping, persian_to_manichaean_mapping,
    persian_to_hieroglyph_mapping, english_to_cuneiform_mapping,
    english_to_pahlavi_mapping, persian_to_pahlavi_mapping,
    english_to_manichaean_mapping, english_to_hieroglyph_mapping,
    linear_b_dict, conversion_dict, convert_to_cuneiform,
    convert_to_pahlavi, convert_to_manichaean, convert_to_hieroglyph,
    text_to_linear_b_optimized, convert_to_akkadian, convert_to_oracle_bone,convert_to_avestan,convert_to_phoenician,convert_to_elamite,
   convert_to_kharosthi,conversion_dict_brahmi,convert_to_brahmi,convert_to_runic
)

from .timeline import AncientTimeline
from .visualizer import AncientImageGenerator
from .ai_chat import AncientScriptAI
from .releases import get_releases
from .web_app import AncientWeb,AncientAIWeb,AncientDocs
from .animate import AncientAnimator
from .reverse_ancient_converter import AncientReverseAI
from .analyze_photo import AnalyzePhoto
from .plugin_system import AncientScripts
from .plagine import Plugin
from .speech_to_ancient import SpeechToAncient
from .run_bot import AncientBot

__version__ = "5.5.1"
__all__ = ['AncientScripts','AncientTimeline','AncientImageGenerator','AncientScriptAI','AncientWeb','AncientAnimator','AncientReverseAI',' AnalyzePhoto','AncientAIWeb'
        ,'Plugin','SpeechToAncient','AncientDocs',' AncientBot']



__author__ = "Amir Hossein Khazaei"
__website__ = ["https://civilica.com/note/17282/","https://daramet.com/amirhossinpython","https://virgool.io/@m_70183455"]


__description__ = (
    "A comprehensive Python library for converting modern text into ancient scripts, "
    "offering precise, character-by-character transformations across more than 14 historical writing systems. "
    "Includes rich historical datasets for accurate conversions, AI-powered chat functionality for intelligent text analysis, "
    "automatic text generation in ancient styles, customizable image creation, and speech-to-ancient conversion. "
    "Perfect for researchers, educators, artists, and developers interested in historical scripts and creative projects."
)


__license__ = "MIT"


__platform__ = ["Windows", "Linux", "MacOS"]

__status__ = "Stable"

__copyright__ = "© 2025-2026 Amir Hossein Khazaei"

__docs__ = "https://github.com/amirhossinpython/ancientlinesoftheworld"

__long_description__ = """
🏛️ AncientLinesOfTheWorld - کامل‌ترین کتابخانه تبدیل متن به خطوط باستانی در جهان

✨ قابلیت‌های منحصربه‌فرد نسخه 5.4.1:

📜 تبدیل متن به ۱۴+ خط باستانی:
   • میخی (Cuneiform) - خط هخامنشیان
   • هیروگلیف (Hieroglyph) - خط مصر باستان
   • پهلوی (Pahlavi) - خط فارسی میانه
   • اوستایی (Avestan) - خط کتاب مقدس زرتشتیان
   • منیایی (Manichaean) - خط آیین مانی
   • خط B (Linear B) - خط یونان باستان
   • براهمی (Brahmi) - خط باستانی هند
   • خروشتی (Kharosthi) - خط شمال هند
   • رونی (Runic) - خط وایکینگ‌ها
   • عبری (Hebrew) - خط عبری باستان
   • سانسکریت (Sanskrit) - خط دیواناگری
   • اکدی (Akkadian) - خط بین‌النهرین
   • اوراکل بون (Oracle Bone) - خط چین باستان
   • 🆕 عیلامی (Elamite) - خط تمدن شوش
   • 🆕 فنیقی (Phoenician) - مادر الفباهای جهان

🎬 انیمیشن (AncientAnimator):
   • نمایش حرف به حرف خطوط باستانی
   • قابلیت تنظیم سرعت

🖼️ تولید تصویر (AncientImageGenerator):
   • تبدیل متن باستانی به تصویر با کیفیت بالا
   • قابلیت تنظیم رنگ، سایه، کنتراست

🌐 وب اپ محلی (AncientWeb):
   • بدون نیاز به سرور خارجی
   • استفاده آفلاین و رایگان

🤖 هوش مصنوعی (AncientScriptAI):
   • دریافت پاسخ هوشمند به خطوط باستانی

🔄 ترجمه معکوس (AncientReverseAI):
   • تبدیل متن باستانی به فارسی/انگلیسی مفهومی

📸 تحلیل تصویر (AnalyzePhoto):
   • تشخیص خط باستانی از روی عکس
   • تفسیر و ترجمه مفهومی

🧩 سیستم پلاگین (Plugin/Plagine):
   • کاربران می‌توانند خطوط جدید اضافه کنند
   • بدون تغییر در کد اصلی
   • فایل پلاگین خودکار ساخته می‌شود

⏳ تایم‌لاین باستانی (AncientTimeline):
   • نمایش زمان فعلی به خطوط باستانی

🎙️ تبدیل گفتار به خط باستانی (SpeechToAncient):
   • ضبط صدا از میکروفون → خط باستانی
   • تبدیل فایل صوتی موجود → خط باستانی
   • مدیریت خطا با try/except
   سایت داکیومنت به صورت لوکال وب اپ(AncientDocs)
   

🚀 نصب:
   pip install --upgrade ancientlinesoftheworld

📖 مستندات:
   https://github.com/amirhossinpython/ancientlinesoftheworld

👨‍💻 نویسنده: امیرحسین خزاعی (AmirHossein Khazaei)
📅 5.4.2 نسخه
📜 مجوز: MIT

🇮🇷 پاسداری از فرهنگ و تاریخ ایران باستان، با قدرت پایتون
"""

__topics__ = ["Text Conversion", "Ancient Scripts", "AI", "Image Generation", "Digital Humanities",'ancientlinesoftheworld','ancient scripts',
    "خطوط باستانی",'کتابخانه تبدیل متن به خطوط باستانی']

__repository__ = "https://github.com/amirhossinpython/ancientlinesoftheworld"


__dependencies__ = ["Flask", "Pillow", "feedparser", "openai","deep-translator","pyaudio"]

__maintainer__ = "Amir Hossein Khazaei"


__keywords__ = [

    "ancient scripts",
    "ancient writing",
    "ancient text converter",
    "historical scripts",
    "epigraphy",
    "paleography",
    "linguistics",
    "ancient linguistics",
    "ancientlinesoftheworld",

    # Specific scripts supported
    "cuneiform",
    "akkadian",
    "old persian",
    "pahlavi",
    "avestan",
    "manichaean",
    "hieroglyph",
    "egyptian hieroglyphs",
    "linear b",
    "oracle bone script",
    "sanskrit",
    "brahmi",
    "hebrew ancient",
    "elamite",
    "phoenician",

    # AI / NLP features
    "AI",
    "artificial intelligence",
    "NLP",
    "language model",
    "text transformation",
    "script generation",
    "ancient script AI",
    "text to script",
    "speech to ancient",

    # Persian/Iran-related
    "Iranian studies",
    "ancient Iran",
    "Persian scripts",
    "تبدیل متن",
    "تبدیل متن به خطوط باستانی",
    "خطوط باستانی",
    "خط میخی",
    "خط پهلوی",
    "خط اوستایی",
    "خط ایلامی",
    "خط فنیقی",
    "باستان شناسی",
    "فرهنگ ایران باستان",

    # Software & library
    "python library",
    "text converter",
    "visual generator",
    "image generator",
    "web app",
    "script visualizer",
    "timeline generator",
    "ancient timeline",

    # General tags for better SEO
    "unicode converter",
    "script mapping",
    "historical tools",
    "cultural heritage",
    "digital humanities",
    "linguistic tools",
]

__license__ = "MIT"