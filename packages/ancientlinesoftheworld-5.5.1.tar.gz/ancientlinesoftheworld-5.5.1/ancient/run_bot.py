from rubpy.bot import BotClient, filters
from rubpy.bot.models import Update
from .core import AncientScripts
from .visualizer import AncientImageGenerator
import telebot



class AncientBot:
    def __init__(self, script: str = "cuneiform"):
        self.script = script
        self.converter = AncientScripts()
        self.image_gen = AncientImageGenerator("cuneiform")
    
    def run_rubika(self,token):
        bot = BotClient(token=token)
        
        @bot.on_update(filters.text, filters.private)
        async def handle(bot_client: BotClient, message: Update):
            text = message.new_message.text
            
            # دستور استارت
            if text == "/start":
                await message.reply(
                    "🏛️ به ربات تبدیل متن به خطوط باستانی خوش آمدید\n\n"
                    "📜 نحوه استفاده:\n"
                    "باستانی متن خود را وارد کنید\n\n"
                    "مثال:\n"
                    "باستانی امیرحسین\n\n"
                    "🖼️ ربات تصویر خط باستانی را نیز برای شما ارسال می‌کند."
                )
                return
            
        
            if text.startswith("باستانی "):
                original_text = text.replace("باستانی ", "").strip()
                
                if not original_text:
                    await message.reply("⚠️ لطفاً بعد از 'باستانی' یک متن وارد کنید.")
                    return
                
            
                func = getattr(self.converter, self.script.lower())
                ancient_text = func(original_text)
            
                
        
            
                f = self.image_gen.generate_image(
                    text=ancient_text,
                    output_filename="test.png",
                    text_color=(255, 215, 0),
                    rtl=True,
                    enhance_contrast=True
                )
                
                
        
                await message.reply_photo(
                    file=f,
                    text=f"📜 متن اصلی: {original_text}\n🏛️ خط {self.script}: {ancient_text}",
                )
                
            
            
                return
                
            
            
        
        
        
        bot.run()
    def run_telegram(self, token: str):
        bot = telebot.TeleBot(token)
        @bot.message_handler(commands=['start'])
        def start(message):
            bot.reply_to(
                message,
                "🏛️ به ربات تبدیل متن به خطوط باستانی خوش آمدید\n\n"
                "📜 نحوه استفاده:\n"
                "باستانی متن خود را وارد کنید\n\n"
                "مثال:\n"
                "باستانی امیرحسین\n\n"
                "🖼️ ربات تصویر خط باستانی را نیز برای شما ارسال می‌کند."
            )
        @bot.message_handler(func=lambda m: m.text and m.text.startswith("باستانی "))
        def  convert(message):
            original_text = message.text.replace("باستانی ", "").strip()
            
            if not original_text:
                bot.reply_to(message, "⚠️ لطفاً بعد از 'باستانی' یک متن وارد کنید.")
                return
            
            func = getattr(self.converter, self.script.lower())
            ancient_text = func(original_text)
            f = self.image_gen.generate_image(
                    text=ancient_text,
                    output_filename="test.png",
                    text_color=(255, 215, 0),
                    rtl=True,
                    enhance_contrast=True
                )
            bot.send_photo(
                        message.chat.id,
                        photo=f,
                        caption=f"📜 متن اصلی: {original_text}\n🏛️ خط {self.script}: {ancient_text}"
                    )
        
            
            
        
        
        
