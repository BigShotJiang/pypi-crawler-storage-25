# ancient/plugin_system.py

import unicodedata
from pathlib import Path
import importlib.util
from typing import Dict, Optional, Callable
from .core import AncientScripts as _BaseAncientScripts


class AncientScripts(_BaseAncientScripts):
    """کلاس اصلی با پشتیبانی از پلاگین"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._plugin_manager = _PluginManager()
    
    def __getattr__(self, name):
        # پلاگین‌ها را چک کن
        plugin = self._plugin_manager.get_plugin(name)
        if plugin:
            return plugin
        raise AttributeError(f"خط '{name}' یافت نشد")
    
    def get_supported_scripts(self):
        """لیست خطوط اصلی + پلاگین"""
        scripts = super().get_supported_scripts()
        for name in self._plugin_manager.list_plugins():
            scripts[name] = "خط پلاگین"
        return scripts


class _PluginManager:
    """مدیریت داخلی پلاگین"""
    
    def __init__(self):
        self.plugins_dir = Path.cwd() / "plugins"
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self._plugins = {}
        self._loaded = False
    
    def _load_plugins(self):
        if self._loaded:
            return
        self._plugins.clear()
        
        for file_path in self.plugins_dir.glob("*.py"):
            if file_path.name == "__init__.py":
                continue
            
            try:
                script_name = file_path.stem.lower()
                
                spec = importlib.util.spec_from_file_location(f"_plugin_{script_name}", file_path)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    # پیدا کردن تابع تبدیل
                    convert_func = None
                    func_name = f"convert_to_{script_name}"
                    if hasattr(module, func_name):
                        convert_func = getattr(module, func_name)
                    
                    if convert_func is None and hasattr(module, 'mapping'):
                        mapping = module.mapping
                        def make_converter(m):
                            def conv(text):
                                result = ''.join(m.get(c, c) for c in text)
                                return unicodedata.normalize("NFKC", result)
                            return conv
                        convert_func = make_converter(mapping)
                    
                    if convert_func:
                        self._plugins[script_name] = convert_func
                        
            except Exception:
                pass
        
        self._loaded = True
    
    def get_plugin(self, name: str) -> Optional[Callable]:
        self._load_plugins()
        return self._plugins.get(name.lower())
    
    def list_plugins(self) -> list:
        self._load_plugins()
        return list(self._plugins.keys())