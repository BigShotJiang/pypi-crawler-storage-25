"""Tests for the DeepSchema write hook."""

import json
from pathlib import Path

from deepwork.hooks.deepschema_write import deepschema_write_hook
from deepwork.hooks.wrapper import HookInput, NormalizedEvent, Platform


def _make_hook_input(
    file_path: str,
    cwd: str,
    tool_name: str = "write_file",
) -> HookInput:
    return HookInput(
        platform=Platform.CLAUDE,
        event=NormalizedEvent.AFTER_TOOL,
        tool_name=tool_name,
        tool_input={"file_path": file_path},
        cwd=cwd,
    )


class TestDeepschemaWriteHook:
    def test_no_schemas_returns_empty(self, tmp_path: Path) -> None:
        hook_input = _make_hook_input(str(tmp_path / "test.py"), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert result.context == ""
        assert result.decision == ""

    def test_injects_conformance_note(self, tmp_path: Path) -> None:
        # Create a named schema matching .py files
        schema_dir = tmp_path / ".deepwork" / "schemas" / "py_schema"
        schema_dir.mkdir(parents=True)
        (schema_dir / "deepschema.yml").write_text(
            "matchers:\n  - '**/*.py'\nrequirements:\n  r1: 'MUST exist'\n",
            encoding="utf-8",
        )
        # Create the target file
        target = tmp_path / "src" / "app.py"
        target.parent.mkdir(parents=True)
        target.write_text("print('hello')", encoding="utf-8")

        hook_input = _make_hook_input(str(target), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert "must conform to the DeepSchema" in result.context

    def test_anonymous_schema_conformance_note(self, tmp_path: Path) -> None:
        # Create anonymous schema
        (tmp_path / ".deepschema.config.json.yml").write_text(
            "requirements:\n  r1: 'MUST be valid'\n",
            encoding="utf-8",
        )
        target = tmp_path / "config.json"
        target.write_text('{"key": "value"}', encoding="utf-8")

        hook_input = _make_hook_input(str(target), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert "must conform to the DeepSchema" in result.context

    def test_json_schema_validation_failure(self, tmp_path: Path) -> None:
        # Create a JSON Schema
        json_schema = tmp_path / ".deepwork" / "schemas" / "json_test" / "test.schema.json"
        json_schema.parent.mkdir(parents=True)
        json_schema.write_text(
            json.dumps(
                {
                    "type": "object",
                    "required": ["name"],
                    "properties": {"name": {"type": "string"}},
                }
            ),
            encoding="utf-8",
        )
        # Create schema referencing the JSON Schema
        (json_schema.parent / "deepschema.yml").write_text(
            "matchers:\n  - '**/*.json'\njson_schema_path: 'test.schema.json'\nrequirements:\n  r1: 'MUST conform'\n",
            encoding="utf-8",
        )
        # Write invalid JSON
        target = tmp_path / "data.json"
        target.write_text('{"other": "field"}', encoding="utf-8")

        hook_input = _make_hook_input(str(target), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert "CRITICAL" in result.context
        assert "validation failed" in result.context.lower()

    def test_json_schema_validation_success(self, tmp_path: Path) -> None:
        json_schema = tmp_path / ".deepwork" / "schemas" / "json_test" / "test.schema.json"
        json_schema.parent.mkdir(parents=True)
        json_schema.write_text(
            json.dumps(
                {
                    "type": "object",
                    "required": ["name"],
                    "properties": {"name": {"type": "string"}},
                }
            ),
            encoding="utf-8",
        )
        (json_schema.parent / "deepschema.yml").write_text(
            "matchers:\n  - '**/*.json'\njson_schema_path: 'test.schema.json'\nrequirements:\n  r1: 'MUST conform'\n",
            encoding="utf-8",
        )
        target = tmp_path / "data.json"
        target.write_text('{"name": "valid"}', encoding="utf-8")

        hook_input = _make_hook_input(str(target), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert "must conform to the DeepSchema" in result.context
        assert "CRITICAL" not in result.context

    def test_json_schema_validation_of_yaml_file(self, tmp_path: Path) -> None:
        """YAML files validated against a JSON Schema should be parsed as YAML, not JSON."""
        json_schema = tmp_path / ".deepwork" / "schemas" / "yml_test" / "test.schema.json"
        json_schema.parent.mkdir(parents=True)
        json_schema.write_text(
            json.dumps(
                {
                    "type": "object",
                    "required": ["name"],
                    "properties": {"name": {"type": "string"}},
                }
            ),
            encoding="utf-8",
        )
        (json_schema.parent / "deepschema.yml").write_text(
            "matchers:\n  - '**/*.yml'\njson_schema_path: 'test.schema.json'\nrequirements:\n  r1: 'MUST conform'\n",
            encoding="utf-8",
        )
        target = tmp_path / "data.yml"
        target.write_text("name: valid\nother: field\n", encoding="utf-8")

        hook_input = _make_hook_input(str(target), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert "must conform to the DeepSchema" in result.context
        assert "CRITICAL" not in result.context

    def test_json_schema_validation_of_invalid_yaml_file(self, tmp_path: Path) -> None:
        """YAML files that fail JSON Schema validation should report errors."""
        json_schema = tmp_path / ".deepwork" / "schemas" / "yml_test" / "test.schema.json"
        json_schema.parent.mkdir(parents=True)
        json_schema.write_text(
            json.dumps(
                {
                    "type": "object",
                    "required": ["name"],
                    "properties": {"name": {"type": "string"}},
                }
            ),
            encoding="utf-8",
        )
        (json_schema.parent / "deepschema.yml").write_text(
            "matchers:\n  - '**/*.yml'\njson_schema_path: 'test.schema.json'\nrequirements:\n  r1: 'MUST conform'\n",
            encoding="utf-8",
        )
        target = tmp_path / "data.yml"
        target.write_text("other: field\n", encoding="utf-8")

        hook_input = _make_hook_input(str(target), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert "CRITICAL" in result.context

    def test_verification_command_failure(self, tmp_path: Path) -> None:
        schema_dir = tmp_path / ".deepwork" / "schemas" / "bash_test"
        schema_dir.mkdir(parents=True)
        (schema_dir / "deepschema.yml").write_text(
            "matchers:\n  - '**/*.txt'\nverification_bash_command:\n  - 'grep required_word \"$1\"'\nrequirements:\n  r1: 'MUST contain required_word'\n",
            encoding="utf-8",
        )
        target = tmp_path / "test.txt"
        target.write_text("no matching content here", encoding="utf-8")

        hook_input = _make_hook_input(str(target), str(tmp_path))
        result = deepschema_write_hook(hook_input)
        assert "CRITICAL" in result.context

    def test_ignores_non_write_events(self) -> None:
        hook_input = HookInput(
            platform=Platform.CLAUDE,
            event=NormalizedEvent.BEFORE_TOOL,
            tool_name="write_file",
            tool_input={"file_path": "/some/file"},
            cwd="/tmp",
        )
        result = deepschema_write_hook(hook_input)
        assert result.context == ""

    def test_ignores_non_write_tools(self) -> None:
        hook_input = HookInput(
            platform=Platform.CLAUDE,
            event=NormalizedEvent.AFTER_TOOL,
            tool_name="shell",
            tool_input={"command": "echo hi"},
            cwd="/tmp",
        )
        result = deepschema_write_hook(hook_input)
        assert result.context == ""
