"""Qiskit-Pasqal provider version."""

__version__ = "0.2.1"
