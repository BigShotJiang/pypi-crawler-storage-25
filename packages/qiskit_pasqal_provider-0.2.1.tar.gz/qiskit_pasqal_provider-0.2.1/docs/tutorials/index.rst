.. nbgallery::
   :glob:

   *
