# Phase 3: Production Readiness Design Spec

## Overview

Two parts: (A) complete provider coverage + real streaming, (B) production infrastructure.

## Part A: Providers + Streaming

### A1: Deepgram Real-time Streaming STT

Replace batch-only `transcribe_stream()` with real WebSocket streaming using Deepgram's live transcription API.

**Implementation:**
- `transcribe_stream()` opens a WebSocket to `wss://api.deepgram.com/v1/listen`
- Accepts `AsyncIterator[bytes]` of raw PCM audio chunks
- Yields `Transcription` objects as Deepgram returns interim/final results
- Handles connection lifecycle: open → stream audio → receive results → close

**Settings:** Use existing `DeepgramSTTSettings` (api_key, model, language, punctuate, smart_format).

### A2: CosyVoice TTS (Local Chinese TTS)

- **Exec mode:** SUBPROCESS (heavy model loading, GPU)
- **SDK:** CosyVoice Python package (local)
- **Settings:** `model_dir`, `device`, `fp16`
- **`synthesize()`:** Load model in subprocess, generate audio, return PCM/WAV
- Pattern: same as faster-whisper — pickle provider, load model in `start()`, inference in `synthesize()`

### A3: Fish-Speech TTS (Local Multi-language TTS)

- **Exec mode:** IN_PROCESS (WebSocket to local Fish-Speech server)
- **SDK:** `httpx` for HTTP API to a locally running Fish-Speech service
- **Settings:** `api_url` (default `http://localhost:8080`), `reference_audio` (for voice clone)
- **`synthesize()`:** POST to Fish-Speech API, receive audio bytes

### A4: Piper TTS (Lightweight CPU TTS)

- **Exec mode:** IN_PROCESS
- **SDK:** `piper-tts` (runs on CPU, no GPU needed)
- **Settings:** `model_path`, `config_path`, `speaker_id`, `length_scale`, `noise_scale`
- **`synthesize()`:** Load piper model, generate WAV audio

### A5: Wire Real Streaming into WS /v1/stt/stream

Currently the WebSocket STT endpoint accumulates all audio then transcribes once. Replace with:
- If provider supports `STREAMING` capability → use `transcribe_stream()` (Deepgram)
- Else → fallback to current accumulate-and-transcribe behavior
- Send `{"type": "partial"}` frames as interim results arrive
- Send `{"type": "final"}` when utterance is complete

## Part B: Production Infrastructure

### B1: API Key Authentication Middleware

FastAPI middleware that validates `Authorization: Bearer <token>` header.

```yaml
# providers.yaml
server:
  auth:
    enabled: true
    api_keys:
      - ${OPENSPEECH_API_KEY}
```

- If `auth.enabled` is false or missing, no authentication (development mode)
- Invalid/missing token returns 401
- WebSocket connections validate token in query param `?token=<key>`
- Management endpoints (`/v1/health`) exempt from auth

### B2: Docker

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install -e ".[all,server]"
EXPOSE 8600
CMD ["openspeechapi", "serve", "--config", "providers.yaml"]
```

docker-compose.yml with GPU support for local models.

### B3: GitHub Actions CI

`.github/workflows/ci.yml`:
- Trigger: push to main, PR to main
- Python 3.11
- Install dev deps
- Run ruff lint
- Run unit + integration tests (no E2E — needs API keys)
- Coverage report

### B4: README Update

Add: deployment section, Docker usage, auth configuration, streaming docs.
