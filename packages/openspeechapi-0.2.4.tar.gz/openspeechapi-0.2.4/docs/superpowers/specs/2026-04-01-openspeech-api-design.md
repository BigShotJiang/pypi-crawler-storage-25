# OpenSpeechAPI Design Spec

## Overview

OpenSpeechAPI is a unified speech interface framework for personal multi-project reuse. It provides a single abstraction layer over multiple STT/TTS providers (local and cloud), with support for mixed execution modes (in-process, subprocess, remote), concurrent dispatch, result filtering, and full observability.

**Primary goals:**

- Eliminate repeated speech integration work across multiple personal projects
- Support both software applications (Python) and hardware audio devices
- Enable flexible switching between local models and cloud APIs through configuration
- Provide a clean extension path from library to networked service

**Non-goals (explicitly excluded):**

- Pipeline/orchestration (STT→LLM→TTS chaining)
- RTVI protocol support
- Frame-based data flow model
- Becoming an open standard or community project

## Architecture

Three-layer architecture with phased delivery:

```
Phase 2
┌─────────────────────────────────────────────────────────────┐
│ L3: Protocol Layer (HTTP / WebSocket)                       │
│  REST API · WS streaming · device access · Client SDK       │
└─────────────────────────────────────────────────────────────┘

Phase 1 — Core
┌─────────────────────────────────────────────────────────────┐
│ L2: Dispatch & Execution Layer                              │
│  service dispatch · process mgmt · fanout · filter · observe│
├─────────────────────────────────────────────────────────────┤
│ L1: Provider Interface Layer                                │
│  unified STT/TTS abstraction · provider adapters · config   │
└─────────────────────────────────────────────────────────────┘
```

**Design principles:**

- ServiceDispatcher is the single entry point for all upper layers
- Providers return plain dataclasses, no coupling to framework-specific types
- Observer pattern for non-intrusive observability
- Configuration-driven execution mode selection
- Optional dependencies per provider (extras groups)
- Pydantic for configuration validation and settings models; plain dataclasses for data transfer objects (AudioData, Transcription, etc.) to keep the core lightweight

## L1: Provider Interface Layer

### Core Abstractions

```python
class SpeechProvider(ABC):
    name: str                    # "faster-whisper", "elevenlabs"
    provider_type: ProviderType  # STT | TTS | BOTH
    execution_mode: ExecMode     # IN_PROCESS | SUBPROCESS | REMOTE
    settings: BaseSettings       # Provider-specific config (dataclass)
    capabilities: set[Capability]

    async def start() -> None
    async def stop() -> None
    async def health_check() -> bool

class STTProvider(SpeechProvider):
    async def transcribe(audio: AudioData, opts: STTOptions) -> Transcription
    async def transcribe_stream(stream: AsyncIterator[bytes]) -> AsyncIterator[TranscriptionEvent]

class TTSProvider(SpeechProvider):
    async def synthesize(text: str, opts: TTSOptions) -> AudioData
    async def synthesize_stream(text: str, opts: TTSOptions) -> AsyncIterator[AudioChunk]
```

### Data Models

```python
class AudioData:
    data: bytes
    sample_rate: int
    channels: int
    format: AudioFormat
    duration_ms: int | None

class Transcription:
    text: str
    language: str | None
    confidence: float | None
    words: list[Word] | None
    duration_ms: int | None

class STTOptions:
    language: str | None
    prompt: str | None
    temperature: float | None

class TTSOptions:
    voice: str | None
    speed: float = 1.0
    output_format: AudioFormat

class Capability(Enum):
    STREAMING
    BATCH
    MULTILINGUAL
    VOICE_CLONE
    EMOTION
    WORD_TIMESTAMPS
    # extensible
```

### Provider Adapters

Each adapter extends `STTProvider` or `TTSProvider`, implements the abstract methods, and declares its capabilities and default execution mode.

**Phase 1 adapters (11 total):**

| Provider | Type | Default ExecMode | Connection |
|---|---|---|---|
| faster-whisper | STT | SUBPROCESS | In-process (model load) |
| whisper | STT | SUBPROCESS | In-process (model load) |
| deepgram | STT | IN_PROCESS | WebSocket SDK |
| openai (STT) | STT | IN_PROCESS | REST SDK |
| fish-speech | TTS | IN_PROCESS | WebSocket remote |
| piper | TTS | IN_PROCESS | In-process or HTTP |
| coqui/XTTS | TTS | IN_PROCESS | HTTP remote |
| cosyvoice | TTS | SUBPROCESS | In-process (model load) |
| elevenlabs | TTS | IN_PROCESS | WebSocket + HTTP |
| openai (TTS) | TTS | IN_PROCESS | REST SDK |
| minimax | TTS | IN_PROCESS | HTTP streaming |

**Key design decisions:**

- Settings use dataclass pattern (borrowed from Pipecat)
- Capabilities are declared as a set, enabling upper-layer routing decisions
- `execution_mode` is a default declaration; actual mode is overridden by L2 configuration
- Provider code is unaware of whether it runs in-process or subprocess

### Provider Registry

Providers register themselves by name. The registry supports:

- Lookup by name (e.g., `"faster-whisper"`)
- Lookup by capability (e.g., all providers supporting `STREAMING`)
- Lookup by type (STT / TTS)

## L2: Dispatch & Execution Layer

### Execution Modes

The core problem: the same provider (e.g., FasterWhisperSTT) may run in different modes depending on the deployment context. The caller should not care where or how the provider executes.

```python
from typing import TypeVar, Generic

R = TypeVar("R")  # Transcription, AudioData, etc.

class Executor(ABC, Generic[R]):
    async def start(provider_cls: type[SpeechProvider], settings: BaseSettings) -> None
    async def stop() -> None
    async def invoke(method: str, **kwargs) -> R
    async def invoke_stream(method: str, **kwargs) -> AsyncIterator[R]
    async def health_check() -> bool
```

**Return type contract:** `InProcessExecutor` returns the provider's native dataclass directly (`Transcription`, `AudioData`, etc.). `SubprocessExecutor` serializes via msgpack on the worker side and deserializes back to the same dataclass on the main side — the caller always receives the same typed domain object regardless of execution mode. `RemoteExecutor` delegates to the provider adapter which handles its own protocol and returns domain objects.

**Three implementations:**

| Executor | Mechanism | IPC | Use Case |
|---|---|---|---|
| InProcessExecutor | Instantiate provider in main process, CPU-bound ops via `asyncio.to_thread()` | Direct function call | Lightweight providers (cloud SDK wrappers, small models) |
| SubprocessExecutor | Fork independent Python process, run IPC server inside | Unix Domain Socket + msgpack; large audio via shared memory/pipe | Heavy models (faster-whisper large-v3, cosyvoice), GPU isolation, crash isolation |
| RemoteExecutor | Connect to an already-running external service endpoint | HTTP/gRPC/WebSocket (provider adapter handles protocol) | Cloud APIs, or self-hosted services on another machine |

### SubprocessExecutor IPC Protocol

Communication between main process and worker subprocess:

```
Main Process (Dispatcher)              Worker Process
        │                                      │
        │── StartRequest ─────────────────────▶│ Load Provider
        │◀── StartResponse(ok) ────────────────│
        │                                      │
        │── InvokeRequest(method, shm_ref) ───▶│ Execute
        │◀── InvokeResponse(result) ───────────│
        │                                      │
        │── StreamRequest(method, pipe_fd) ───▶│ Stream execute
        │◀── StreamChunk(data) ────────────────│
        │◀── StreamChunk(data) ────────────────│
        │◀── StreamEnd ────────────────────────│
```

- Serialization: msgpack (lightweight, fast)
- Large audio data: shared memory reference to avoid copying
- Streaming: pipe file descriptor for low-latency chunk delivery

**Error handling in IPC:**

- Worker errors are serialized as `ErrorResponse(error_type, message, traceback_str)` and sent back over the socket
- Main process reconstructs and re-raises as `ProviderError(provider_name, original_error_type, message)`
- Crash detection: main process monitors the worker via `process.is_alive()` and socket heartbeat (every 5s)
- On worker crash mid-invocation: the pending `invoke()` raises `ProviderCrashedError` to the caller
- Restart policy: configurable per provider — `restart_on_crash: bool` (default: true), `max_restarts: int` (default: 3), `restart_delay_s: float` (default: 1.0). After max restarts exhausted, the provider is marked unhealthy and further invocations raise `ProviderUnavailableError`

### ServiceDispatcher

The central coordinator. Responsibilities:

- Load configuration (providers.yaml)
- Instantiate Executors based on configured exec_mode per provider
- Route invocations to the correct Executor
- Manage provider lifecycle (start/stop/health)
- Coordinate FanOut/FanIn for concurrent dispatch
- Apply ResultFilter chains
- Notify Observers on all invocation events

```python
# Usage
dispatcher = Dispatcher.from_config("providers.yaml")
await dispatcher.start()

text = await dispatcher.stt.transcribe("faster-whisper-local", audio)
audio = await dispatcher.tts.synthesize("elevenlabs", "Hello world")

await dispatcher.stop()
```

### Configuration

```yaml
# providers.yaml
providers:
  faster-whisper-local:
    provider: faster-whisper
    exec_mode: subprocess
    settings:
      model_size: large-v3
      device: cuda

  elevenlabs:
    provider: elevenlabs
    exec_mode: in_process
    settings:
      api_key: ${ELEVENLABS_API_KEY}
      voice_id: Rachel

  whisper-server:
    provider: faster-whisper
    exec_mode: remote
    endpoint: http://gpu-server:8080
```

The same provider class can be instantiated multiple times with different names and execution modes.

**Environment variable interpolation:** `${VAR_NAME}` syntax in YAML values is resolved from environment variables at config load time. If the variable is not set, config loading raises `ConfigError` with the missing variable name. No fallback/default mechanism — missing secrets should fail fast. Literal `$` is escaped as `$$`.

### Concurrent Dispatch (FanOut/FanIn)

Send the same input to multiple providers simultaneously, then merge results.

```python
result = await dispatcher.fanout_stt(
    providers=["deepgram", "faster-whisper-local"],
    audio=audio_data,
    strategy=FirstCompleted()
)
```

**MergeStrategy implementations:**

| Strategy | Behavior |
|---|---|
| FirstCompleted | Return the first successful result that arrives. Failed providers are ignored unless all fail, in which case a `FanOutAllFailedError` is raised containing all individual errors. |
| HighestConfidence | Wait for all to complete (or fail). Pick the highest-confidence successful result. Failed providers are excluded. If all fail, raise `FanOutAllFailedError`. |
| CollectAll | Wait for all. Return a `FanOutResult` containing `successes: dict[str, Result]` and `errors: dict[str, Exception]`. Caller decides how to handle partial failures. |
| Custom | User-defined merge logic via `async def merge(results: dict[str, Result | Exception]) -> Result` |

### Result Filters

Post-processing chain applied to provider results before returning to caller.

```python
from typing import TypeVar, Generic

T = TypeVar("T", Transcription, AudioData, AudioChunk)

class ResultFilter(ABC, Generic[T]):
    def should_pass(self, result: T) -> bool:
        """Return False to drop this result from the chain."""
        return True

    def transform(self, result: T) -> T:
        """Transform the result. Called only if should_pass returns True."""
        return result
```

**Filter chain execution order:** For each result, the chain calls `should_pass()` first. If it returns `False`, the result is dropped and subsequent filters are skipped. If `True`, `transform()` is called and the (possibly modified) result is passed to the next filter. A dropped result returns `None` to the caller (for single invocations) or is excluded from the list (for fanout `CollectAll`).

**Built-in filters:**

- `ConfidenceFilter(min=0.8)` — drop low-confidence transcriptions
- `LanguageFilter(allow=["zh", "en"])` — filter by detected language
- `DurationFilter(min_ms=100)` — drop too-short audio results
- `AudioFormatFilter(target=PCM_16K)` — convert audio output format (transformation, not filtering)

Filters are configured per provider instance and applied as a chain.

### InvokeContext

Carries request-scoped metadata through the entire invocation lifecycle.

```python
@dataclass
class InvokeContext:
    request_id: str           # Unique request ID
    provider_name: str        # "faster-whisper-local"
    method: str               # "transcribe" | "synthesize" | ...
    exec_mode: ExecMode       # Actual execution mode
    start_time_ns: int        # Nanosecond timestamp
    ttfb_ns: int | None       # Time to first byte
    end_time_ns: int | None   # Completion time
    metadata: dict[str, Any]  # Extension fields
    parent_id: str | None     # Parent request ID in fanout scenarios
```

## Observability

Non-intrusive observer pattern. Observers are registered on the Dispatcher and receive callbacks on all invocation events without affecting the call chain.

**Observer error isolation:** Observer callbacks are wrapped in try/except. If an observer raises an exception, it is logged via `loguru` at `warning` level but does **not** propagate to the caller or affect the invocation result. Observers must never block or crash the dispatch chain. An observer that raises repeatedly (>10 consecutive errors) is automatically deregistered and a warning is emitted.

```python
class DispatchObserver(ABC):
    async def on_invoke_start(ctx: InvokeContext) -> None
    async def on_invoke_end(ctx: InvokeContext, result: Result) -> None
    async def on_invoke_error(ctx: InvokeContext, error: Exception) -> None
    async def on_stream_chunk(ctx: InvokeContext, chunk: Any) -> None
    async def on_provider_start(provider: str, exec_mode: ExecMode) -> None
    async def on_provider_stop(provider: str) -> None
    async def on_health_change(provider: str, healthy: bool) -> None
```

### Built-in Observers

| Observer | Function | Inspired by Pipecat |
|---|---|---|
| MetricsObserver | Collect TTFB, processing duration, throughput | FrameProcessorMetrics + TTFBMetricsData |
| LatencyObserver | End-to-end latency tracking: invoke start → first byte → completion | UserBotLatencyObserver + LatencyBreakdown |
| DebugLogObserver | Detailed logs: call params, provider name, exec mode, duration | DebugLogObserver formatted output |
| TracingObserver | OpenTelemetry span integration, one trace per invocation | utils/tracing/ subsystem |
| UsageObserver | Call counts, character counts, audio duration per provider for cost estimation | TTSUsageMetricsData |

## L3: Protocol Layer (Phase 2)

Conceptual design for Phase 2. Not implemented in Phase 1 but the architecture ensures clean extension.

**Architecture:** FastAPI application that wraps ServiceDispatcher. Internal calls are direct Python method invocations, zero adaptation cost.

**API surface:**

```
# STT
POST /v1/stt/transcribe          — single provider transcription
POST /v1/stt/transcribe/fanout   — concurrent multi-provider
WS   /v1/stt/stream              — streaming transcription

# TTS
POST /v1/tts/synthesize          — single provider synthesis
WS   /v1/tts/stream              — streaming synthesis

# Management
GET  /v1/providers               — list providers and their status
GET  /v1/health                  — health check
GET  /v1/metrics                 — metrics snapshot
```

**Python SDK dual-mode:**

```python
# Mode 1: Library (direct L1/L2, no network)
from openspeechapi import Dispatcher
d = Dispatcher.from_config("providers.yaml")
text = await d.stt.transcribe("faster-whisper", audio)

# Mode 2: Client (connect to L3 service)
from openspeechapi import Client
c = Client("http://gpu-server:8600")
text = await c.stt.transcribe("faster-whisper", audio)
# Identical interface, HTTP underneath
```

## Project Structure

```
openspeechapi/
├── core/                        # L1: Provider Interface Layer
│   ├── base.py                  # SpeechProvider, STTProvider, TTSProvider
│   ├── models.py                # AudioData, Transcription, AudioChunk, Options
│   ├── capabilities.py          # Capability enum, ExecMode enum
│   ├── settings.py              # BaseSettings, config loading
│   └── registry.py              # Provider registry (lookup by name/capability)
│
├── providers/                   # L1: Provider Adapters
│   ├── stt/
│   │   ├── faster_whisper.py
│   │   ├── whisper.py
│   │   ├── deepgram.py
│   │   └── openai.py
│   ├── tts/
│   │   ├── fish_speech.py
│   │   ├── piper.py
│   │   ├── coqui.py
│   │   ├── cosyvoice.py
│   │   ├── elevenlabs.py
│   │   ├── openai.py
│   │   └── minimax.py
│   └── _template.py             # New adapter template
│
├── dispatch/                    # L2: Dispatch & Execution Layer
│   ├── dispatcher.py            # ServiceDispatcher
│   ├── executors/
│   │   ├── base.py              # Executor ABC
│   │   ├── in_process.py        # InProcessExecutor
│   │   ├── subprocess.py        # SubprocessExecutor + IPC protocol
│   │   └── remote.py            # RemoteExecutor
│   ├── fanout.py                # FanOut/FanIn + MergeStrategy
│   ├── filters.py               # ResultFilter chain
│   └── context.py               # InvokeContext
│
├── observe/                     # L2: Observability
│   ├── base.py                  # DispatchObserver ABC
│   ├── metrics.py               # MetricsObserver
│   ├── latency.py               # LatencyObserver
│   ├── debug.py                 # DebugLogObserver
│   ├── tracing.py               # TracingObserver (OpenTelemetry)
│   └── usage.py                 # UsageObserver
│
├── server/                      # L3: Protocol Layer (Phase 2)
│   ├── app.py                   # FastAPI application
│   ├── routes/
│   │   ├── stt.py
│   │   ├── tts.py
│   │   └── management.py
│   └── ws/
│       ├── stt_stream.py
│       └── tts_stream.py
│
├── client/                      # L3: Python thin client (Phase 2)
│   └── client.py
│
├── config.py                    # YAML config loading & validation
├── __init__.py                  # Top-level exports
└── cli.py                       # CLI entry point

tests/
├── unit/
│   ├── test_providers/
│   ├── test_dispatch/
│   └── test_observe/
└── integration/
    ├── test_in_process.py
    ├── test_subprocess.py
    └── test_fanout.py
```

### Dependency Management

Core package is minimal. Each provider's dependencies are installed via optional extras:

```toml
[project]
dependencies = ["pydantic", "pyyaml", "msgpack", "loguru"]

[project.optional-dependencies]
faster-whisper = ["faster-whisper"]
elevenlabs = ["elevenlabs"]
deepgram = ["deepgram-sdk"]
openai = ["openai"]
fish-speech = ["httpx"]
piper = ["piper-tts"]
coqui = ["httpx"]
cosyvoice = ["httpx"]
minimax = ["httpx"]
server = ["fastapi", "uvicorn", "websockets"]   # Phase 2
tracing = ["opentelemetry-api", "opentelemetry-sdk"]
all = ["openspeechapi[faster-whisper,elevenlabs,deepgram,...]"]
```

## Phase Roadmap

### Phase 1: Core Library

- L1: Full provider interface + 11 adapters
- L2: Three execution modes (in-process / subprocess / remote)
- L2: Concurrent fanout with merge strategies
- L2: Result filter chain
- L2: Full observability (5 built-in observers)
- Python SDK: direct import usage (Library mode)
- CLI: `openspeechapi list`, `openspeechapi check`
- Tests: unit + integration

### Phase 2: Protocol Layer

- L3: FastAPI HTTP/WebSocket service
- L3: Python thin client
- CLI: `openspeechapi serve`
- Device and cross-language access via HTTP/WS

## References

- **Pipecat** (pipecat-ai/pipecat): Borrowed provider adapter pattern, observer pattern, metrics/latency tracking design. Did not adopt Frame-based pipeline model, agent-first architecture, or single-process constraint.
- **Provider documentation**: Each adapter follows the respective provider's official SDK/API documentation.
