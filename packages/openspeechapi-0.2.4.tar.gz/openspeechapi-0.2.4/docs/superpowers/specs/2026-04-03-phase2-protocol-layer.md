# Phase 1.5 + Phase 2: Protocol Layer Design Spec

## Overview

Two sub-projects delivered sequentially:

- **Phase 1.5**: API normalization (dispatcher namespace) + 3 priority adapter implementations
- **Phase 2**: L3 Protocol Layer — FastAPI HTTP/WebSocket server + Python thin client

## Sub-project A: Phase 1.5

### A1: Dispatcher Namespace

Align the `ServiceDispatcher` public API with the original design spec's namespace pattern.

**Current (flat):**
```python
await dispatcher.transcribe("stt-1", audio)
await dispatcher.synthesize("tts-1", text)
await dispatcher.fanout_transcribe(["stt-1", "stt-2"], audio, strategy=...)
```

**Target (namespaced):**
```python
await dispatcher.stt.transcribe("stt-1", audio)
await dispatcher.stt.fanout("stt-1", "stt-2"], audio, strategy=...)
await dispatcher.tts.synthesize("tts-1", text)
```

**Implementation:**

```python
class _STTNamespace:
    def __init__(self, dispatcher: ServiceDispatcher) -> None:
        self._d = dispatcher

    async def transcribe(self, provider: str, audio: AudioData, opts=None) -> Transcription:
        return await self._d.transcribe(provider, audio, opts)

    async def fanout(self, providers: list[str], audio: AudioData, opts=None, strategy=None) -> Any:
        return await self._d.fanout_transcribe(providers, audio, opts, strategy)

class _TTSNamespace:
    def __init__(self, dispatcher: ServiceDispatcher) -> None:
        self._d = dispatcher

    async def synthesize(self, provider: str, text: str, opts=None) -> AudioData:
        return await self._d.synthesize(provider, text, opts)
```

`ServiceDispatcher` exposes `self.stt = _STTNamespace(self)` and `self.tts = _TTSNamespace(self)` in `__init__`. The existing flat methods (`transcribe()`, `synthesize()`, `fanout_transcribe()`) remain as internal implementation — the namespaced API (`dispatcher.stt.transcribe()`, `dispatcher.tts.synthesize()`) is the only public interface going forward. Existing tests and demo code are updated to use the new namespace.

### A2: Priority Adapter Implementations

Three adapters to implement with real logic:

#### Deepgram STT

- **SDK:** `deepgram-sdk` (async WebSocket client)
- **Exec mode:** IN_PROCESS
- **Capabilities:** STREAMING, BATCH, MULTILINGUAL
- **`transcribe()`:** Uses Deepgram's `listen.rest.v("1").transcribe_file()` for batch mode
- **`transcribe_stream()`:** Uses Deepgram's WebSocket live transcription API, yields `Transcription` per utterance
- **Settings:**

```python
@dataclass
class DeepgramSTTSettings(BaseSettings):
    api_key: str = ""
    model: str = "nova-2"
    language: str = "en"
    punctuate: bool = True
    smart_format: bool = True
```

#### ElevenLabs TTS

- **SDK:** `elevenlabs` (async HTTP client)
- **Exec mode:** IN_PROCESS
- **Capabilities:** STREAMING, VOICE_CLONE, EMOTION
- **`synthesize()`:** Uses `client.text_to_speech.convert()` for batch
- **`synthesize_stream()`:** Uses `client.text_to_speech.convert_as_stream()` for streaming, yields `AudioChunk`
- **Settings:**

```python
@dataclass
class ElevenLabsTTSSettings(BaseSettings):
    api_key: str = ""
    voice_id: str = "21m00Tcm4TlvDq8ikWAM"  # Rachel
    model_id: str = "eleven_monolingual_v1"
    stability: float = 0.5
    similarity_boost: float = 0.75
    style: float = 0.0
    use_speaker_boost: bool = True
```

#### Minimax TTS

- **SDK:** `httpx` (REST API + SSE streaming)
- **Exec mode:** IN_PROCESS
- **Capabilities:** STREAMING
- **`synthesize()`:** POST to `https://api.minimax.chat/v1/t2a_v2`, returns audio bytes
- **`synthesize_stream()`:** Same endpoint with `stream=true`, yields `AudioChunk` per SSE event
- **Settings:**

```python
@dataclass
class MinimaxTTSSettings(BaseSettings):
    api_key: str = ""
    group_id: str = ""
    model: str = "speech-01-turbo"
    voice_id: str = "male-qn-qingse"
    speed: float = 1.0
    vol: float = 1.0
    pitch: int = 0
```

## Sub-project B: Phase 2 — L3 Protocol Layer

### B1: FastAPI Server

**Architecture:** FastAPI application wrapping `ServiceDispatcher`. The server loads `providers.yaml`, builds a registry with all known providers, creates a `ServiceDispatcher`, and exposes it via HTTP/WebSocket endpoints.

**File structure:**
```
openspeechapi/server/
├── __init__.py
├── app.py           # FastAPI app factory, lifespan, dispatcher setup
├── routes/
│   ├── __init__.py
│   ├── stt.py       # POST /v1/stt/transcribe, POST /v1/stt/transcribe/fanout
│   ├── tts.py       # POST /v1/tts/synthesize
│   └── management.py  # GET /v1/providers, /v1/health, /v1/metrics
└── ws/
    ├── __init__.py
    ├── stt_stream.py  # WS /v1/stt/stream
    └── tts_stream.py  # WS /v1/tts/stream
```

#### REST Endpoints

**POST /v1/stt/transcribe**

Request: multipart form — `audio` (file), `provider` (string), `language` (optional), `prompt` (optional), `temperature` (optional float)

Response:
```json
{
  "text": "Hello world",
  "language": "en",
  "confidence": 0.95,
  "words": [{"text": "Hello", "start_ms": 0, "end_ms": 500, "confidence": 0.98}],
  "duration_ms": 1200,
  "provider": "faster-whisper"
}
```

**POST /v1/stt/transcribe/fanout**

Request: multipart form — `audio` (file), `providers` (comma-separated string), `strategy` (string: `first_completed` | `highest_confidence` | `collect_all`)

Response (collect_all):
```json
{
  "strategy": "collect_all",
  "successes": {
    "openai": {"text": "Hello world", "confidence": null},
    "faster-whisper": {"text": "Hello world", "confidence": 0.95}
  },
  "errors": {}
}
```

**POST /v1/tts/synthesize**

Request: JSON — `{"text": "Hello", "provider": "openai-tts", "voice": "alloy", "speed": 1.0}`

Response: audio bytes with `Content-Type: audio/wav` (or `audio/pcm` depending on provider). Response headers include `X-Provider`, `X-Duration-Ms`, `X-Sample-Rate`.

**GET /v1/providers**

Response:
```json
{
  "providers": [
    {"name": "faster-whisper", "type": "stt", "exec_mode": "subprocess", "healthy": true},
    {"name": "openai-tts", "type": "tts", "exec_mode": "in_process", "healthy": true}
  ]
}
```

**GET /v1/health**

Response: `{"status": "ok", "providers": {"faster-whisper": true, "openai-tts": true}}`

**GET /v1/metrics**

Response: metrics snapshot from `MetricsObserver` — call counts, durations, error counts per provider.

#### Error Responses

All REST endpoints return errors as:
```json
{"error": "ProviderNotFoundError", "detail": "Provider 'nonexistent' not found", "status": 404}
```

| Error | HTTP Status |
|-------|-------------|
| ProviderNotFoundError | 404 |
| ProviderUnavailableError | 503 |
| ConfigError | 400 |
| FanOutAllFailedError | 502 |
| Validation error | 422 |
| Internal error | 500 |

For fanout, partial failures are NOT HTTP errors — they're returned in the `errors` dict of the response body. `FanOutAllFailedError` (all providers failed) returns 502.

#### WebSocket Endpoints

**WS /v1/stt/stream**

Connect with query params: `?provider=deepgram&language=en`

**Binary frame format:** Client sends raw PCM audio — 16-bit signed LE, mono. Frame size: 1024-8192 bytes (provider dependent, 4096 recommended). Server auto-detects sample rate from query param `?sample_rate=16000` (default: 16000).

Protocol:
```
Client → binary audio chunk (raw PCM, ≤8192 bytes)
Client → binary audio chunk
Server ← {"type": "partial", "text": "Hello"}
Client → binary audio chunk
Server ← {"type": "final", "text": "Hello world", "confidence": 0.95, "language": "en"}
Client → {"type": "stop"}  (text frame, signals end of audio)
Server ← {"type": "closed"}
```

Server closes the connection after 30s of idle (no frames from client).

**WS /v1/tts/stream**

Client sends a JSON text frame with synthesis request. Server responds with binary audio chunks (raw PCM, 24kHz mono 16-bit), then a JSON done frame:

```
Client → {"text": "Hello world", "provider": "openai-tts", "voice": "alloy"}
Server ← binary audio chunk (raw PCM, sequence implied by order)
Server ← binary audio chunk
Server ← {"type": "done", "total_bytes": 48000, "sample_rate": 24000}
```

### B2: Python Thin Client

**File:** `openspeechapi/client/client.py`

The client mirrors the `ServiceDispatcher` interface but makes HTTP/WebSocket calls underneath. Users can switch between Library mode and Client mode with no code changes except the import.

```python
from openspeechapi import Client  # exported from openspeechapi/__init__.py

client = Client("http://gpu-server:8600")

# Same interface as dispatcher.stt / dispatcher.tts
result = await client.stt.transcribe("faster-whisper", audio)
audio = await client.tts.synthesize("openai-tts", "Hello world")

# Streaming TTS
async for chunk in client.tts.synthesize_stream("openai-tts", "Hello"):
    play(chunk.data)

# Streaming STT — feed audio chunks, receive transcriptions
async def audio_source():
    """Yields raw PCM chunks from microphone or file."""
    yield pcm_chunk_1
    yield pcm_chunk_2

async for transcription in client.stt.transcribe_stream("deepgram", audio_source()):
    print(transcription.text)

# FanOut — strategy as string at HTTP level
result = await client.stt.fanout(["openai", "faster-whisper"], audio, strategy="first_completed")

# Management
providers = await client.list_providers()
health = await client.health()
```

**Implementation:** Uses `httpx.AsyncClient` for REST calls and `websockets` for streaming. Audio data is serialized as multipart form for STT requests and raw bytes for TTS responses. The `Client` class is exported from `openspeechapi/__init__.py` for top-level access.

**File structure:**
```
openspeechapi/client/
├── __init__.py
└── client.py       # Client class with stt/tts namespace
```

### B3: CLI `openspeechapi serve`

Add `serve` subcommand to `openspeechapi/cli.py`:

```bash
openspeechapi serve --config providers.yaml --host 0.0.0.0 --port 8600
```

Implementation: loads config, builds registry + dispatcher, creates FastAPI app, runs with uvicorn.

### B4: Server Configuration

The server reads the same `providers.yaml` as the library. Additional server-specific config:

```yaml
# providers.yaml
server:
  host: 0.0.0.0
  port: 8600
  cors_origins: ["*"]

providers:
  faster-whisper-local:
    provider: faster-whisper
    exec_mode: subprocess
    settings:
      model_size: large-v3
      device: cuda
  # ...
```

## Delivery Order

```
A1: Dispatcher namespace ──┐
                           ├──→ B1: FastAPI server (REST → WS) ──→ B3: CLI serve ──→ B4: Integration tests
A2: 3 adapters (parallel) ─┘         ↕ (parallel)
                                B2: Python thin client ──────────┘
```

1. **A1**: Dispatcher namespace — blocks B1 (server wraps dispatcher)
2. **A2**: Deepgram, ElevenLabs, Minimax adapters — parallel with A1
3. **B1 + B2**: Server and client in parallel (once A1 merges)
4. **B3**: CLI serve command (depends on B1)
5. **B4**: Integration + E2E tests (depends on B1 + B2)

## Dependencies

Phase 2 server extras (already defined in pyproject.toml):
```toml
server = ["fastapi", "uvicorn", "websockets"]
```

Client uses `httpx` (already a dependency of several providers) and `websockets`.

## Testing Strategy

- Unit tests for each REST route (TestClient)
- Unit tests for client (mocked HTTP)
- Integration test: start server in background, use client to call it
- E2E test: server + real providers (skip when deps missing)
