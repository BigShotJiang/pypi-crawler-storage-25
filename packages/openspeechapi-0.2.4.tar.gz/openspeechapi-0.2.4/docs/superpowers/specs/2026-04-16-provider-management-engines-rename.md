# Provider 服务商管理 + providers→engines 全局重命名

**日期**: 2026-04-16
**状态**: Implemented

## 概述

引入两层架构：**Provider（服务商）** 持有共享凭据，**Engine（引擎）** 引用 Provider 获取凭据并只保留自身特有参数。
同时将原配置文件中的 `providers:` 引擎列表重命名为 `engines:`，以避免与新增的 `providers:`（服务商凭据）命名混淆。

核心改动：
1. **Provider 服务商管理** — 新增 `providers:` 配置节，存放共享凭据（API Key 等）
2. **全局重命名** — 原 `providers:` → `engines:`，贯穿配置文件、后端代码、API 响应、前端
3. **Vendor Registry** — 新增 `vendor_registry.yaml`，定义 12 个云端服务商的凭据字段模板
4. **Config UI** — Config 页面左侧新增 Providers 分组，支持查看/编辑服务商凭据
5. **向后兼容** — 旧格式配置文件（仅 `providers:` 键）仍可正常解析

## 1. 配置文件新结构

### 1.1 新格式（providers + engines）

```yaml
providers:
  iflytek:
    app_id: dbda61c3
    api_key: xxx
    api_secret: xxx

engines:
  iflytek_stt:
    provider: iflytek          # 引用 providers 节的服务商
    exec_mode: remote
    settings:
      language: zh_cn
  iflytek_tts:
    provider: iflytek
    exec_mode: remote
    settings:
      voice: xiaoyan
      speed: 50
  native_tts:
    exec_mode: in_process      # 无需 provider
    settings:
      default_voice: ''
      default_rate: 200
```

### 1.2 provider 字段双重用途

Engine 的 `provider` 字段具有双重含义：
- **引用服务商**：若值匹配 `providers:` 节中的某个键（如 `iflytek`），则合并该服务商的凭据到 engine settings，并从 engine_registry 查找工厂键
- **工厂键**（向后兼容）：若值不匹配任何服务商（如 `iflytek-stt`），则直接作为工厂键使用

### 1.3 凭据合并规则

```
最终 settings = {**provider凭据, **engine自身settings}
```

Engine 自身的 settings 优先覆盖 Provider 凭据中的同名字段。

### 1.4 向后兼容

旧格式仍然支持：
```yaml
providers:
  iflytek_stt:
    provider: iflytek-stt
    exec_mode: remote
    settings:
      app_id: xxx
      api_key: xxx
      language: zh_cn
```

检测逻辑：若配置文件存在 `engines:` 键 → 新格式；否则 `providers:` 键按旧格式（引擎列表）解析。

## 2. Vendor Registry（服务商模板）

### 2.1 文件

`openspeechapi/vendor_registry.yaml` — 12 个云端服务商模板：

| 服务商 | 共享字段 |
|--------|---------|
| OpenAI | api_key, base_url |
| iFlytek | app_id, api_key, api_secret |
| Google Cloud | api_key |
| Azure | subscription_key, region |
| Alibaba | api_key, base_url |
| Tencent | secret_id, secret_key |
| Baidu | api_key, secret_key |
| Volcengine | access_token, app_id |
| Deepgram | api_key |
| AssemblyAI | api_key |
| ElevenLabs | api_key |
| MiniMax | api_key, group_id |

每个字段定义包含：`required`, `description`, `secret`（是否敏感）, `default`（可选默认值）。

### 2.2 用途

- Config UI 根据模板自动渲染 Provider 编辑表单
- 安装引擎时自动创建对应 Provider（若不存在）
- `/v1/admin/vendor-templates` API 返回模板数据

## 3. Engine Registry 变更

### 3.1 新增 vendor 字段

`openspeechapi/engine_registry.yaml` 中每个云端引擎新增 `vendor:` 字段，关联到 vendor_registry：

```yaml
- name: iflytek-stt
  vendor: iflytek          # 关联服务商
  provider: iflytek-stt    # 工厂键
  type: stt
  category: cloud
  display_name: "iFlytek STT"
  ...
```

20 个云端引擎均已添加 vendor 字段。本地/Native 引擎不需要 vendor。

### 3.2 CatalogEntry 新增字段

```python
@dataclass
class CatalogEntry:
    ...
    vendor: str = ""  # 服务商键（cloud 引擎）
```

## 4. 全局重命名 providers→engines

### 4.1 数据类/类型

| 旧名 | 新名 | 文件 |
|------|------|------|
| `ProviderConfig` | `EngineConfig`（保留旧名别名） | `config.py` |
| `_ProviderHandle` | `_EngineHandle`（保留旧名别名） | `dispatcher.py` |
| `ProviderConfigUpdate` | `EngineConfigUpdate`（保留旧名别名） | `management.py` |
| — | `ProviderCredentials` / `CloudProviderConfig` | `config.py`（新增） |

### 4.2 配置键

| 旧 | 新 | 位置 |
|----|-----|------|
| `providers:` | `engines:` | providers.yaml, providers.example.yaml |
| `raw["providers"]` | `raw["engines"]` 或 `raw.get("engines") or raw.get("providers")` | config.py, management.py |
| `config.providers` | `config.engines` | dispatcher.py, cli.py |
| `OpenSpeechConfig.providers` | `OpenSpeechConfig.engines`（`.providers` 保留为属性别名） | config.py |

### 4.3 方法名

| 旧 | 新 | 文件 |
|----|-----|------|
| `list_providers()` | `list_engines()`（保留旧名别名） | dispatcher.py |
| `list_providers()` | `list_engines()`（保留旧名别名） | client.py |
| `renderProviders()` | `renderEngines()`（保留旧名别名） | app.js |

### 4.4 API 端点与响应键

| 端点 | 旧键 | 新键 | 备注 |
|------|------|------|------|
| `GET /v1/engines`（新） | — | `{"engines": [...]}` | 主端点 |
| `GET /v1/providers`（保留） | `{"providers": [...]}` | 不变 | 向后兼容 |
| `GET /v1/health` | `{"providers": {...}}` | `{"engines": {...}}` | |
| `GET /v1/admin/config` | `{"providers": {...}}` | `{"providers": {...}, "engines": {...}}` | 返回两个节 |
| `PUT /v1/admin/config` | `{"providers": {...}}` | `{"engines": {...}, "providers": {...}}` | 接受两个节 |

### 4.5 新增 API 端点

| 端点 | 方法 | 说明 |
|------|------|------|
| `/v1/admin/providers` | GET | 返回已配置的服务商列表（凭据脱敏） |
| `/v1/admin/providers` | PUT | 更新服务商凭据 + 热加载 |
| `/v1/admin/vendor-templates` | GET | 返回 vendor_registry 模板 |

### 4.6 前端 (app.js)

| 旧 | 新 |
|----|-----|
| `state.providers` | `state.engines` |
| `providersData.providers` | `enginesData.engines` |
| `healthData.providers` | `healthData.engines` |
| `fetchJson("/v1/providers")` | `fetchJson("/v1/engines")` |
| `configData = ...providers` | `configData = ...engines` |

## 5. Config UI — Provider 管理

### 5.1 侧栏布局

Config 页面左侧边栏新增 **"Providers"** 分组，位于引擎分组上方：

```
[Providers]
  ● iFlytek (科大讯飞) (2)
  ● OpenAI (3)

[STT — Cloud]
  ● OpenAI STT
  ● iFlytek STT

[STT — Local / Native]
  ● Native STT

[TTS — Cloud]
  ...
```

- 蓝色圆点标识 Provider
- 括号内数字为关联引擎数量

### 5.2 Provider 编辑

点击 Provider 显示凭据编辑表单：
- 字段从 vendor_registry 模板自动渲染
- Secret 字段使用 password 输入框
- 显示 "Used by" 关联引擎列表
- "Save Provider" 按钮单独保存凭据

### 5.3 自动创建

安装引擎时，若对应 Provider 不存在，自动创建空 Provider 条目（字段值为空，等待用户填写）。

## 6. 文件清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `openspeechapi/vendor_registry.yaml` | 新增 | 12 个服务商模板 |
| `openspeechapi/engine_registry.yaml` | 修改 | 20 个云端引擎添加 `vendor` 字段 |
| `openspeechapi/config.py` | 重构 | EngineConfig + ProviderCredentials + 双格式解析 + 凭据合并 |
| `openspeechapi/engine_catalog.py` | 修改 | CatalogEntry 添加 `vendor` + vendor registry 加载 + get_installed_engines 适配 |
| `openspeechapi/dispatch/dispatcher.py` | 修改 | _EngineHandle + config.engines + list_engines() |
| `openspeechapi/server/routes/management.py` | 重构 | /v1/engines + Provider API + 响应键重命名 |
| `openspeechapi/server/webui/app.js` | 修改 | 全局重命名 + Provider 管理 UI |
| `openspeechapi/server/webui/styles.css` | 修改 | dot-blue + badge.provider + provider-used-by |
| `openspeechapi/client/client.py` | 修改 | list_engines() |
| `openspeechapi/cli.py` | 修改 | config.engines |
| `providers.yaml` | 重构 | providers + engines 双节结构 |
| `providers.example.yaml` | 重构 | 新格式示例 |

## 7. 测试覆盖

- 9 个 config 测试全部通过（含旧格式向后兼容）
- 46 个 server 测试全部通过（含 config API、auth、routes、websocket）
- dispatcher 同步测试通过（list_engines 等）
- WebSocket 测试修复（meta 消息处理）
- 向后兼容测试：旧 `providers:` 格式配置文件正常加载

## 8. 凭据合并验证

```
providers.yaml:
  providers:
    iflytek:
      app_id: dbda61c3
      api_key: xxx
      api_secret: xxx
  engines:
    iflytek_stt:
      provider: iflytek
      settings:
        language: zh_cn

→ config.engines["iflytek_stt"].settings = {
    app_id: "dbda61c3",       ← 来自 provider
    api_key: "xxx",           ← 来自 provider
    api_secret: "xxx",        ← 来自 provider
    language: "zh_cn"         ← 来自 engine 自身
  }
```
