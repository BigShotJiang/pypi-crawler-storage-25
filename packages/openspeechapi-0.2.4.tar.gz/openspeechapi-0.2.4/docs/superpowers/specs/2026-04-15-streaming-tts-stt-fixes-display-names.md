# 流式 TTS 播放 + STT 修复 + 引擎显示名 + Windows 原生支持

**日期**: 2026-04-15
**状态**: Implemented
**后续变更**: 2026-04-16 配置结构重构 — `providers:` 引擎列表重命名为 `engines:`，新增 `providers:` 服务商凭据节。详见 [2026-04-16-provider-management-engines-rename.md](2026-04-16-provider-management-engines-rename.md)。

## 概述

本次更新包含多项功能增强和 Bug 修复：
1. **流式 TTS 播放** — 支持合成过程中逐步播放，不再等完整合成后一次性播放
2. **TTS 下载功能** — 合成完成后支持选择格式（WAV/MP3/OGG/FLAC/OPUS）下载
3. **iFlytek TTS 修复** — 修复无声输出、发音人/语种选择缺失
4. **Windows 原生引擎** — 新增 Windows STT (System.Speech) 和 TTS (SAPI5) provider
5. **Live STT 批量模式修复** — 修复 native_stt 识别结果一闪而过的问题
6. **引擎显示名优化** — 全部引擎使用人类友好的 display_name（如 "iFlytek STT" 而非 "iflytek_stt"）
7. **全 Provider 日志统一** — 34 个 provider 全部切换至 loguru，添加性能追踪日志

## 1. 流式 TTS 播放

### 1.1 播放策略

前端根据浏览器能力和音频格式，自动选择最佳播放方式：

| 策略 | 条件 | 行为 |
|------|------|------|
| **MSE Player** | 浏览器支持 MediaSource + MP3 格式 | 真正的逐块播放，延迟最低 |
| **Progressive Blob** | 非 MSE 场景 | 收到第一个块后开始播放，结束时重建完整 Blob |
| **Full Buffer** | 兜底方案 | 收集所有块后一次性播放 |

### 1.2 WebSocket 流式协议

`tts_stream.py` 在发送音频数据前先发送 `meta` JSON 消息：

```json
{"type": "meta", "audio_format": "mp3"}
```

随后发送二进制音频块，最后发送：

```json
{"type": "done"}
```

### 1.3 关键文件

- `openspeechapi/server/ws/tts_stream.py` — 流式 meta + 音频块
- `openspeechapi/server/webui/app.js` — `createStreamPlayer()`, `createMSEPlayer()`, `createProgressiveBlobPlayer()`

## 2. TTS 下载功能

### 2.1 用户流程

合成完成后，页面显示格式选择下拉框 + Download 按钮：
- **Original** — 直接下载合成的原始格式（零转换）
- **WAV/MP3/OGG/FLAC/OPUS** — 通过后端 `/v1/tts/convert` 转换后下载

### 2.2 新增 API

```
POST /v1/tts/convert     — 音频格式转换（multipart: audio + source_format + target_format）
GET  /v1/tts/formats      — 可用格式列表（含 ffmpeg 可用性标志）
```

### 2.3 关键文件

- `openspeechapi/server/routes/tts.py` — convert + formats 端点
- `openspeechapi/server/webui/index.html` — 下载 UI 区域
- `openspeechapi/server/webui/styles.css` — `.tts-download-area` 样式

## 3. iFlytek TTS 修复

### 3.1 无声输出修复

- **根因**: `aue: "raw"` 返回全零 PCM 数据
- **修复**: 改为 `aue: "lame"` (MP3) + `sfl: 1` (流式标志)
- 响应 MIME type 从 `audio/wav` 改为 `audio/mpeg`

### 3.2 流式合成支持

- 新增 `Capability.STREAMING`
- 实现 `synthesize_stream()` — 每个 WebSocket 消息 yield 一个 `AudioChunk`
- 重构 `synthesize()` 为流收集模式

### 3.3 发音人/语种选择

- 新增 `list_voices()` 方法，返回 19 个发音人（中文 11 个、粤语 1 个、方言 2 个、英语 3 个、日语 1 个、韩语 1 个）
- `_VOICES` 类常量包含 `(vcn, description, language, group)` 元组
- `opts.voice` 正确传递到 WebSocket 构建消息

## 4. Windows 原生引擎

### 4.1 Windows STT (`windows_speech.py`)

- 基于 .NET `System.Speech.Recognition.SpeechRecognitionEngine`
- 通过 PowerShell 子进程调用，JSON 文件交换结果
- `_find_powershell()` 支持 PATH 查找 + 回退到已知系统路径
- 支持语言: zh-CN, en-US, ja-JP, ko-KR, fr-FR, de-DE, es-ES

### 4.2 Windows TTS (`windows_sapi.py`)

- 基于 pyttsx3 (SAPI5 COM)
- 通过 `asyncio.to_thread()` 避免阻塞事件循环
- 支持发音人列表、语速控制

### 4.3 跨平台 Native 别名

`native-stt` / `native-tts` 自动解析到平台特定 provider：
- darwin → `macos-stt` / `macos-say`
- win32 → `windows-stt` / `windows-tts`

## 5. Live STT 批量模式修复

### 5.1 问题

native_stt (Windows System.Speech) 在 Live 模式下识别结果一闪而过：
1. 7 秒 `noTokenFallbackTimer` 对批量型 provider 总会触发（批量型不发送部分结果），强制切换 HTTP fallback 并丢弃已积累音频
2. `stopLiveSTT()` 发送 "stop" 后立即关闭 WS，后端转录结果无法送达

### 5.2 修复

**后端** (`stt_stream.py`):
- WS 连接后发送 `{"type": "meta", "streaming": false}` 告知前端批量模式
- 添加详细日志追踪批量转录流程

**前端** (`app.js`):
- 处理 `meta` 消息，设置 `ctx.isBatchMode`
- 批量模式下跳过 7 秒 fallback timer
- `stopLiveSTT()` 发送 "stop" 后等待后端返回 "closed"（最多 20 秒），而非立即关闭
- 等待期间显示 "transcribing" 状态提示
- 缓冲 WS 连接阶段的早期消息（`earlyMessages`），避免 meta 丢失

## 6. 引擎显示名 (display_name)

### 6.1 设计

每个引擎增加 `display_name` 字段，用于所有 UI 展示：

| 内部标识 | display_name |
|---------|-------------|
| `iflytek_stt` | iFlytek STT |
| `native_tts` | Native TTS |
| `faster-whisper` | Faster Whisper |
| `openai-stt` | OpenAI STT |
| `elevenlabs-tts` | ElevenLabs TTS |

命名规则：品牌名保留原始大小写，类型后缀大写（STT/TTS）。

### 6.2 数据流

```
engine_registry.yaml (display_name)
    ↓
engine_catalog.py (CatalogEntry.display_name)
    ↓
management.py API (/providers, /engine-catalog, /provider-templates)
    ↓
app.js (Dashboard 卡片、Lab 下拉、Engines 目录、Config 侧栏/详情、Add Provider 对话框)
```

### 6.3 影响文件

| 文件 | 改动 |
|------|------|
| `openspeechapi/engine_registry.yaml` | 30 个引擎全部添加 `display_name` |
| `openspeechapi/engine_catalog.py` | `CatalogEntry` 增加 `display_name` 字段 |
| `openspeechapi/server/routes/management.py` | 3 个 API 返回 `display_name` |
| `openspeechapi/server/webui/app.js` | 5 处 UI 显示改用 `display_name` |

## 7. 全 Provider 日志统一

### 7.1 改动范围

34 个 provider 文件全部：
- `import logging` / `log = logging.getLogger(__name__)` → `from loguru import logger`
- `log.info/debug/warning` → `logger.info/debug/warning`
- `%s`/`%d`/`%.0f` 格式串 → `{}`/`{:.0f}` (loguru 格式)
- 共修改 141 处日志调用

### 7.2 日志内容

每个 provider 的 `transcribe()` / `synthesize()` 方法添加：
- 入口日志：请求参数、音频大小
- 出口日志：耗时（ms）、结果大小
- 错误日志：异常详情

## 8. 其他修复

### 8.1 UI 修复
- Engines 页 checkbox 对齐（全局 `input { width: 100% }` 导致 checkbox 拉宽）
- 批量安装 "Cannot set properties of null" 错误（`renderTasks()` 空元素保护）
- 禁用 checkbox 缺少 `catalog-cb` class

### 8.2 引擎安装机制

- `engine_registry.yaml` 模板文件包含引擎清单和基本信息
- 默认 `providers.yaml` 仅保留 native 引擎
- `CatalogEntry.platforms` 支持平台兼容性检测
- 批量安装 API: `POST /v1/engine-catalog/batch-install`

## 9. 文件清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `openspeechapi/engine_registry.yaml` | 新增 | 引擎模板（30 引擎 + display_name） |
| `openspeechapi/engine_catalog.py` | 修改 | 从模板加载，增加 display_name/platforms |
| `openspeechapi/providers/stt/windows_speech.py` | 新增 | Windows STT (System.Speech) |
| `openspeechapi/providers/tts/windows_sapi.py` | 新增 | Windows TTS (SAPI5/pyttsx3) |
| `openspeechapi/providers/tts/iflytek.py` | 修改 | MP3 输出 + 流式 + 发音人选择 |
| `openspeechapi/server/ws/stt_stream.py` | 修改 | 批量模式 meta + 日志 |
| `openspeechapi/server/ws/tts_stream.py` | 修改 | 流式 meta + 音频块 |
| `openspeechapi/server/routes/tts.py` | 修改 | convert/formats API + 动态 MIME |
| `openspeechapi/server/routes/management.py` | 修改 | display_name + batch-install |
| `openspeechapi/server/webui/app.js` | 修改 | 流式播放 + 下载 + 批量 STT 修复 + display_name |
| `openspeechapi/server/webui/index.html` | 修改 | 下载 UI |
| `openspeechapi/server/webui/styles.css` | 修改 | checkbox 对齐 + 下载样式 |
| `openspeechapi/providers/stt/*.py` (12) | 修改 | loguru + 性能日志 |
| `openspeechapi/providers/tts/*.py` (15) | 修改 | loguru + 性能日志 |
| `providers.yaml` | 修改 | 仅 native + iflytek |
