# 云端 STT/TTS 服务集成 + WebUI 多页改造 + 统一引擎管理

**日期**: 2026-04-12
**状态**: Implemented
**后续变更**: 2026-04-16 配置结构重构 — `providers:` 引擎列表重命名为 `engines:`，新增 `providers:` 服务商凭据节。详见 [2026-04-16-provider-management-engines-rename.md](2026-04-16-provider-management-engines-rename.md)。

## 概述

集成所有主流云端 STT/TTS 服务（30 个 provider），将 WebUI 改造为 5 Tab 布局，
引入统一引擎目录（Engine Catalog），支持云端+本地引擎的安装/卸载/配置。

## 1. 云端 Provider 集成

### 1.1 OpenAI 兼容层扩展

给 `openai-stt` 和 `openai-tts` 添加 `base_url` 参数，一改即支持：
- OpenAI（默认）、Groq、SiliconFlow、Azure OpenAI

### 1.2 新增 Provider（16 个云端，全部使用 httpx，无 SDK 依赖）

| Provider | 文件 | 认证方式 |
|----------|------|----------|
| Google Cloud STT/TTS | `google_cloud.py` | API Key |
| Azure Speech STT/TTS | `azure_speech.py` | Subscription Key |
| AssemblyAI STT | `assemblyai.py` | API Key |
| 火山引擎 STT/TTS | `volcengine.py` | Bearer Token + AppID |
| 阿里云 STT/TTS | `alibaba.py` | API Key (百炼 OpenAI 兼容) |
| 腾讯云 STT/TTS | `tencent.py` | TC3-HMAC-SHA256 |
| 百度 STT/TTS | `baidu.py` | OAuth Token |
| 讯飞 STT/TTS | `iflytek.py` | WebSocket + HMAC-SHA256 |

### 1.3 Health Check 机制

- 云端 provider：检查 API key/credentials 是否配置（不依赖 lazy-start 状态）
- 本地 provider：检查进程/服务是否运行
- macOS native：检查命令/二进制是否存在
- `RemoteExecutor`/`InProcessExecutor`：通过 `set_provider_info()` 缓存 provider 信息，
  支持 lazy-start 前的 health check

### 1.4 Deepgram 改造

从 `deepgram-sdk` 依赖改为 `httpx` REST API 直接调用，消除 SDK 依赖。

## 2. 统一引擎目录（Engine Catalog）

### 2.1 架构

`openspeechapi/engine_catalog.py` + `openspeechapi/engine_registry.yaml` — 30 个引擎的统一注册表：
- 20 个云端（10 STT + 10 TTS）
- 5 个本地（faster-whisper, whisper, whisperlivekit, sherpa-onnx, fish-speech）
- 2 个 macOS native（macos-stt, macos-tts）
- 2 个 Windows native（windows-stt, windows-tts）
- 1 个跨平台 native（native-stt, native-tts 自动解析到平台特定 provider）

```python
@dataclass
class CatalogEntry:
    name: str              # "openai-stt"
    provider: str          # factory key
    type: str              # "stt" | "tts"
    category: str          # "cloud" | "local" | "native"
    description: str
    default_alias: str     # providers.yaml 中的别名
    display_name: str      # UI 友好显示名，如 "iFlytek STT"
    default_settings: dict
    default_exec_mode: str
    pip_deps: list[str]    # 安装时需要的 pip 包
    pip_extras: list[str]  # pyproject.toml extras
    field_options: dict    # 字段下拉选项
    platforms: list[str]   # 平台兼容，空=全平台
```

### 2.2 安装/卸载流程

- `POST /v1/engine-catalog/{name}/install`
  - 写入 providers.yaml → 运行安装脚本（pip 依赖）→ 热加载
- `POST /v1/engine-catalog/{name}/uninstall`
  - 从 providers.yaml 移除 → 热加载

### 2.3 可见性规则

- **未安装**：仅在 Engines 页显示（灰色圆点 + Install 按钮）
- **已安装未配置**：Dashboard/Config/Lab 可见（黄色圆点）
- **已安装且健康**：全部可见（绿色圆点）

### 2.4 安装脚本

- 云端引擎：`scripts/engines/cloud/install.sh`（检查 httpx + 安装 pip 依赖）
- 本地引擎：各自的 `scripts/engines/{name}/native/install.sh`
- pip_deps 声明：openai, elevenlabs, websockets

## 3. WebUI 5 Tab 布局

### 3.1 Tab 结构

| Tab | 功能 |
|-----|------|
| **Dashboard** | Provider 状态面板，按 STT/TTS + Cloud/Local 分组，健康状态圆点，本地引擎快捷 Start/Stop |
| **Lab** | STT/TTS 能力测试，左右双栏布局，高级选项折叠 |
| **Engines** | 引擎目录浏览，Install/Uninstall/Start/Stop 按钮，点击引擎名跳转 Config |
| **Config** | 左右分栏：左侧按分组显示已安装 provider 列表，右侧编辑配置（有预定义选项的字段渲染为下拉框），Save & Apply 热加载 |
| **Logs** | 操作日志：记录 install/uninstall/start/stop 等活动，带时间戳和状态 |

### 3.2 分组顺序（全页面统一）

1. STT — Cloud
2. STT — Local / Native
3. TTS — Cloud
4. TTS — Local / Native

### 3.3 Config 下拉选项（field_options）

`CatalogEntry.field_options` 定义每个 setting 字段的可选值列表。23/27 个引擎配置了 field_options：
- STT：model（whisper-1, nova-2 等）、language（en-US, zh-CN 等）、region、engine_type、dev_pid
- TTS：model、voice（alloy, JennyNeural 等）、language、voice_type、region
- 本地：device（auto, cpu, cuda, mps）、compute_type、model_size

Config UI 根据 field_options 自动渲染为 `<select>` 下拉框，用户也可以输入自定义值。

### 3.4 Config API

- `GET /admin/config` — 当前配置（API key 脱敏）
- `GET /admin/config/raw` — 原始配置（用于保存时保留未修改的密钥）
- `PUT /admin/config` — 更新配置 + 热加载
- `GET /admin/provider-templates` — 所有注册 provider 的默认 settings schema
- `GET /engine-catalog` — 引擎目录（含安装状态）

## 4. 文件清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `openspeechapi/engine_catalog.py` | 新增 | 统一引擎目录（27 引擎） |
| `openspeechapi/providers/stt/*.py` | 新增/修改 | 8 个新云端 STT + deepgram 改 httpx |
| `openspeechapi/providers/tts/*.py` | 新增/修改 | 8 个新云端 TTS |
| `openspeechapi/factory.py` | 修改 | 注册 30 个 provider |
| `openspeechapi/server/routes/management.py` | 修改 | Config API + Engine Catalog API |
| `openspeechapi/dispatch/executors/remote.py` | 修改 | pre-start health check |
| `openspeechapi/dispatch/executors/in_process.py` | 修改 | pre-start health check |
| `openspeechapi/dispatch/dispatcher.py` | 修改 | set_provider_info 调用 |
| `openspeechapi/server/webui/index.html` | 重写 | 5 Tab 布局 |
| `openspeechapi/server/webui/app.js` | 重写 | Tab 切换、Config 分栏、Catalog、Logs |
| `openspeechapi/server/webui/styles.css` | 修改 | Tab/Config/Catalog/Logs 样式 |
| `scripts/engines/cloud/install.sh` | 新增 | 云端引擎通用安装脚本 |
| `providers.yaml` | 修改 | 27 个 provider 配置 |

## 5. 测试覆盖

- 540+ 单元测试（含 50+ 新 provider 测试、Config API 测试）
- 7 E2E 测试（Tab 切换、STT 文件上传、TTS 合成、错误显示等）
- 所有 30 个 provider factory 导入验证通过
