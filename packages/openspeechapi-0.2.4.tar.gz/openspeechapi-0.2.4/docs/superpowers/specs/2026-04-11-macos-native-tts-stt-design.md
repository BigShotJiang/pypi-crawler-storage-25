# macOS 原生 TTS/STT 集成 + 音频转换模块 + Provider 插件机制

**日期**: 2026-04-11
**状态**: Approved

## 概述

集成 macOS 内置语音能力作为 OpenSpeechAPI 的轻量级 fallback 引擎：
- **TTS**: 通过 `say` 命令实现，零额外依赖
- **STT**: 通过编译 Swift 小程序包装 `SFSpeechRecognizer`，避免 pyobjc 重依赖

同时：
- 新增统一音频格式转换模块 `openspeechapi/utils/audio_converter.py`
- 增强 WebUI TTS 表单，支持发音人选择（按语言分组）和语速控制
- 引入 Provider 插件机制，支持外部扩展

## 1. 音频格式转换模块

### 1.1 背景

当前项目音频格式处理散落在各 provider 中：
- `audio_playback.py` 中有 PCM→WAV 包装
- `sherpa_onnx.py` 中有重采样和多声道混音
- `whisper.py`/`faster_whisper.py` 中有 WAV 检测包装
- 各 TTS provider 输出格式不统一（WAV/MP3/PCM）

需要一个统一的音频转换模块，让所有 provider 复用，也为 macOS 引擎的 AIFF→WAV 转换提供支持。

### 1.2 文件

`openspeechapi/utils/audio_converter.py`

### 1.3 设计原则

- **纯 Python 标准库** 实现基础转换（PCM↔WAV、重采样、声道混音）
- **ffmpeg 作为可选后端** 处理高级格式（MP3、OGG、FLAC、OPUS、AIFF）
- ffmpeg 不可用时优雅降级，仅支持标准库能处理的格式
- 所有函数均为同步（音频转换是 CPU 密集型，异步无益）

### 1.4 核心 API

```python
class AudioConverter:
    """统一音频格式转换器。"""

    @staticmethod
    def convert(
        audio: AudioData,
        target_format: AudioFormat,
        target_sample_rate: int | None = None,
        target_channels: int | None = None,
    ) -> AudioData:
        """将 AudioData 转换为目标格式/采样率/声道数。"""

    @staticmethod
    def to_wav(audio: AudioData, sample_rate: int | None = None) -> AudioData:
        """快捷方法：任意格式 → WAV。"""

    @staticmethod
    def to_pcm16k(audio: AudioData) -> AudioData:
        """快捷方法：任意格式 → PCM 16kHz 16-bit mono。"""

    @staticmethod
    def resample(pcm_bytes: bytes, src_rate: int, dst_rate: int, channels: int = 1) -> bytes:
        """PCM 重采样（线性插值）。"""

    @staticmethod
    def mix_to_mono(pcm_bytes: bytes, channels: int) -> bytes:
        """多声道混音为单声道。"""

    @staticmethod
    def detect_format(data: bytes) -> AudioFormat:
        """通过文件头检测音频格式。"""

    @staticmethod
    def ffmpeg_available() -> bool:
        """检查 ffmpeg 是否可用。"""
```

### 1.5 格式检测

通过文件头魔数检测：

| 格式 | 魔数 |
|------|------|
| WAV | `RIFF....WAVE` |
| AIFF | `FORM....AIFF` |
| MP3 | `\xff\xfb` 或 `ID3` |
| OGG | `OggS` |
| FLAC | `fLaC` |
| OPUS | OGG 容器内 `OpusHead` |

无法检测的 raw bytes 视为 PCM。

### 1.6 转换矩阵

| 源 → 目标 | 实现方式 |
|-----------|---------|
| PCM → WAV | 标准库 `wave` 模块包装 |
| WAV → PCM | 标准库 `wave` 模块读取 frames |
| PCM ↔ 重采样 | 线性插值算法（标准库） |
| 多声道 → 单声道 | `struct` 解包，取平均值 |
| AIFF → WAV | 标准库 `aifc` 模块读取 + `wave` 写入；或 ffmpeg |
| MP3/OGG/FLAC/OPUS → WAV | ffmpeg subprocess |
| WAV → MP3/OGG/FLAC/OPUS | ffmpeg subprocess |

### 1.7 ffmpeg 调用封装

```python
@staticmethod
def _ffmpeg_convert(
    input_bytes: bytes,
    input_format: str,
    output_format: str,
    sample_rate: int | None = None,
    channels: int | None = None,
) -> bytes:
    """通过 ffmpeg 管道转换音频（stdin → stdout，无临时文件）。"""
    cmd = ["ffmpeg", "-i", "pipe:0", "-f", output_format]
    if sample_rate:
        cmd.extend(["-ar", str(sample_rate)])
    if channels:
        cmd.extend(["-ac", str(channels)])
    cmd.extend(["-loglevel", "error", "pipe:1"])
    proc = subprocess.run(cmd, input=input_bytes, capture_output=True, check=True)
    return proc.stdout
```

使用管道（stdin/stdout），避免临时文件 IO 开销。

### 1.8 流式转换接口（预留）

预留流式转换 API，本次不实现（抛出 `NotImplementedError`）：

```python
@staticmethod
async def convert_stream(
    chunks: AsyncIterator[bytes],
    src_format: AudioFormat,
    dst_format: AudioFormat,
    src_sample_rate: int,
    dst_sample_rate: int | None = None,
) -> AsyncIterator[bytes]:
    raise NotImplementedError("Streaming conversion not yet supported")
```

预留理由：当前 macOS 引擎和大部分 provider 都是批处理模式，流式转换的 chunk 边界处理（重采样残余样本、编解码状态）复杂度高。等实际有流式需求时再实现。

### 1.10 与现有代码的关系

新模块创建后，后续可逐步替换现有分散的转换代码：
- `audio_playback.py` 的 `_wav_bytes_from_audio()` → 内部调用 `AudioConverter.to_wav()`
- 各 STT provider 的 WAV 包装逻辑 → 调用 `AudioConverter.to_wav()`
- macOS TTS 的 AIFF→WAV → 调用 `AudioConverter.convert()`

**本次只创建模块并在 macOS provider 中使用，现有 provider 的迁移作为后续优化。**

### 1.11 AudioFormat 枚举扩展

在 `openspeechapi/core/enums.py` 中增加 AIFF 格式：

```python
class AudioFormat(str, Enum):
    PCM_16K = "pcm_16k"
    PCM_44K = "pcm_44k"
    WAV = "wav"
    AIFF = "aiff"      # ← 新增
    MP3 = "mp3"
    OGG = "ogg"
    FLAC = "flac"
    OPUS = "opus"
```

## 2. macOS Native TTS Provider

### 1.1 文件

`openspeechapi/providers/tts/macos_say.py`

### 1.2 实现方式

通过 `asyncio.create_subprocess_exec` 调用 macOS 内置 `say` 命令：

```
say -v <voice> -r <rate> -o /tmp/out.aiff "<text>"
```

生成 AIFF 文件后，用 Python 标准库转换为 WAV 格式返回 `AudioData`。

### 1.3 Settings

```python
@dataclass
class MacOSSaySettings(BaseSettings):
    default_voice: str = "Samantha"
    default_rate: int = 200          # words per minute
```

### 1.4 类元数据

```python
name = "macos-say"
provider_type = ProviderType.TTS
execution_mode = ExecMode.IN_PROCESS
capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
```

### 1.5 发音人列表

实现 `list_voices()` 方法，通过解析 `say -v ?` 输出获取：

```
# say -v ? 输出格式:
# Samantha            en_US    # Most people recognize me by my voice.
# Ting-Ting           zh_CN    # 你好，我叫Ting-Ting。我讲中文。
```

解析为结构化数据：

```python
@dataclass
class VoiceInfo:
    name: str        # "Ting-Ting"
    language: str    # "zh_CN"
    description: str # "你好，我叫Ting-Ting。我讲中文。"
    group: str       # "中文" (根据 language code 映射的显示名)
```

缓存结果，避免重复调用。

### 1.6 核心方法

- `start()`: 验证 `say` 命令可用（`which say`）
- `stop()`: 无操作
- `health_check()`: 检查 `say` 命令存在且平台为 macOS
- `synthesize(text, opts)`: 调用 say → AIFF → WAV → AudioData
- `synthesize_stream()`: 抛出 `NotImplementedError`
- `list_voices()`: 解析 `say -v ?` 返回 `list[VoiceInfo]`

### 1.7 音频格式转换

AIFF → WAV 转换使用 Python 标准库 `audioop` + `wave`：
1. 用 `wave` 模块读取 AIFF（或用 `subprocess` 调 `afconvert`）
2. 写为 WAV 格式
3. 返回 `AudioData(data=wav_bytes, sample_rate=22050, channels=1, format=AudioFormat.WAV)`

备选：直接用 macOS `afconvert` 命令转换格式更可靠：
```
afconvert /tmp/out.aiff /tmp/out.wav -d LEI16 -f WAVE
```

### 1.8 限制

- 不支持流式合成（需等文件写完）
- 音质一般，不如专业 TTS 引擎
- 仅限 macOS 平台

## 3. macOS Native STT Provider

### 2.1 文件

- Provider: `openspeechapi/providers/stt/macos_speech.py`
- Swift 工具源码: `scripts/engines/macos-stt/macos_stt.swift`
- 安装脚本: `scripts/engines/macos-stt/install.sh`

### 2.2 实现方式

编译一个 Swift CLI 工具包装 `SFSpeechRecognizer`，Python provider 通过 subprocess 调用。
二进制编译后打包为 `.app` bundle，以便 macOS TCC 框架追踪语音识别授权。

**选择 Swift 而非 pyobjc 的原因**：
- 避免 pyobjc 重依赖（~100MB）
- macOS 自带 Swift 编译器（Xcode Command Line Tools）
- 编译后二进制仅几百 KB

### 2.3 Swift 工具

`scripts/engines/macos-stt/macos_stt.swift`

**调用方式**：
```bash
# 直接调用（--check 等不需要 TCC 的操作）
macos-stt-helper --check [--language zh-CN]

# 通过 .app bundle 调用（识别操作，需要 TCC 授权）
open -W MacOSSTTHelper.app --args --audio /tmp/input.wav --language zh-CN --output /tmp/result.json
```

**输出 JSON**：
```json
{"text": "你好世界", "confidence": 0.95, "language": "zh-CN"}
```

**核心逻辑**：
1. 解析命令行参数（`--audio`, `--language`, `--check`, `--output`）
2. `--check` 模式：检查 `SFSpeechRecognizer` 可用性和授权状态
3. 识别模式：创建 `SFSpeechURLRecognitionRequest` → 使用 `RunLoop.main.run` 轮询等待回调 → 输出 JSON
4. `--output <path>` 支持：将结果写入文件而非 stdout（配合 `open -W` 使用）

**关键实现细节**：
- `recognitionTask` 回调在主线程调度，**必须使用 RunLoop 轮询**而非信号量等待，否则会死锁
- 不设置 `requiresOnDeviceRecognition = true`，避免本地模型未下载时静默挂起
- 错误信息统一写入 stdout（JSON 格式），Python 端优先从 stdout 解析

### 2.4 TCC 授权与 .app Bundle

macOS TCC（Transparency, Consent, and Control）要求通过 bundle ID 追踪语音识别权限。
裸 CLI 二进制无法被 TCC 追踪，因此需要 `.app` bundle 包装。

**架构**：
```
MacOSSTTHelper.app/
  Contents/
    Info.plist          # bundle ID: com.openspeechapi.macos-stt-helper
    MacOS/
      macos-stt-helper  # 编译后的 Swift 二进制
```

**授权流程**：
1. `install.sh` 编译二进制并创建 `.app` bundle，ad-hoc 代码签名
2. 用户运行 `open MacOSSTTHelper.app` 触发 TCC 授权对话框
3. Python provider 通过 `open -W MacOSSTTHelper.app --args ...` 调用，继承 .app 的 TCC 授权
4. 结果通过 `--output <tmpfile>` 传递（`open` 不转发 stdout）

**注意**：每次重新编译会改变代码签名，需重新授权。

### 2.5 安装脚本

`scripts/engines/macos-stt/install.sh`:
- 检查平台为 macOS
- 检查 Xcode Command Line Tools 已安装
- 编译 Swift 源码到 `.app` bundle 内
- 生成 `Info.plist`（含 `NSSpeechRecognitionUsageDescription`）
- Ad-hoc 代码签名
- 创建便捷 symlink

### 2.5 Provider Settings

```python
@dataclass
class MacOSSpeechSettings(BaseSettings):
    language: str = "zh-CN"
    binary_path: str = ""    # 空则自动检测 scripts/engines/macos-stt/macos-stt-helper
```

### 2.6 类元数据

```python
name = "macos-stt"
provider_type = ProviderType.STT
execution_mode = ExecMode.IN_PROCESS
capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
```

### 2.8 核心方法

- `start()`: 检查 .app bundle 和二进制存在 → 运行 `--check` 验证授权和可用性
- `stop()`: 清理状态
- `health_check()`: 检查已启动、已授权、二进制存在
- `transcribe(audio, opts)`: AudioData → 转 WAV → 写临时文件 → 通过 `open -W` 调用 .app → 从 `--output` 文件读取 JSON → 返回 `Transcription`
- `transcribe_stream()`: 抛出 `NotImplementedError`

### 2.9 限制

- 首次使用需通过 `.app` bundle 授权语音识别权限
- 需在系统设置中下载对应语言的听写模型，否则识别会超时
- macOS 13+ 支持离线识别，旧版本需联网
- 不支持流式识别
- 需要 Xcode Command Line Tools
- 每次重新编译后需重新授权（代码签名变化）

## 4. Voice 列表 API

### 3.1 基类扩展

在 `openspeechapi/core/base.py` 的 `TTSProvider` 中增加默认方法：

```python
class TTSProvider(SpeechProvider):
    # ... 现有方法 ...
    
    async def list_voices(self) -> list[dict]:
        """返回可用发音人列表。子类可覆盖。"""
        return []
```

### 3.2 新增 API 端点

在 `openspeechapi/server/routes/tts.py` 中新增：

```
GET /v1/tts/{provider}/voices
```

响应：
```json
{
  "voices": [
    {"name": "Ting-Ting", "language": "zh_CN", "group": "中文", "description": "..."},
    {"name": "Samantha", "language": "en_US", "group": "English", "description": "..."}
  ]
}
```

逻辑：通过 dispatcher 获取对应 provider 实例 → 调用 `list_voices()` → 返回结果。

## 5. WebUI 增强

### 4.1 TTS 表单改造

`openspeechapi/server/webui/index.html` 中 TTS 表单新增：

```html
<label>Voice
  <select id="tts-voice">
    <optgroup label="中文">
      <option value="Ting-Ting">Ting-Ting</option>
    </optgroup>
    <optgroup label="English">
      <option value="Samantha">Samantha</option>
    </optgroup>
  </select>
</label>
<label>Speed
  <input id="tts-speed" type="number" min="0.5" max="2.0" step="0.1" value="1.0">
</label>
```

### 4.2 交互逻辑

`openspeechapi/server/webui/app.js` 新增：

1. **Provider 切换时加载发音人**：监听 `tts-provider` 的 `change` 事件 → `GET /v1/tts/{provider}/voices` → 填充 `tts-voice` 下拉框
2. **Voice 按语言分组**：用 `<optgroup>` 按 `group` 字段分组显示
3. **空列表处理**：若 API 返回空 voices → 隐藏 Voice 下拉框
4. **发送请求时传参**：`POST /v1/tts/synthesize` body 中增加 `voice` 和 `speed` 字段

### 4.3 STT 部分

无需额外 UI 改动。macOS STT 作为 provider 选项出现在现有 STT 表单的 Provider 下拉中即可。

## 6. Provider 插件机制

### 5.1 目标

允许外部 provider 通过两种方式注册，无需修改 `factory.py`：

1. **pip 安装**：`pip install openspeechapi-plugin-xxx`，yaml 中指定 module
2. **本地 plugins 目录**：在项目根目录 `plugins/` 下放置 `.py` 文件

### 5.2 providers.yaml 扩展

新增可选字段 `module` 和 `class`：

```yaml
providers:
  my-custom-tts:
    provider: my-custom-tts
    module: "my_plugin_package.tts"     # Python import 路径
    class: "MyCustomTTS"                # 类名
    exec_mode: in_process
    settings:
      api_key: "xxx"
```

### 5.3 factory.py 改造

`get_provider_class()` 加载优先级：

1. **检查 config 中的 `module` + `class` 字段** → `importlib.import_module(module)` → `getattr(mod, class_name)`
2. **Fallback 到 `_PROVIDER_MAP`** → 现有内置 provider 映射

### 5.4 plugins 目录支持

factory 初始化时：
- 检查项目根目录是否存在 `plugins/` 目录
- 若存在，将其加入 `sys.path`
- 这样 yaml 中 `module: "my_custom_tts"` 可直接导入 `plugins/my_custom_tts.py`

### 5.5 内置 provider 注册

macOS 两个新 provider 同时注册到 `_PROVIDER_MAP`（作为内置），也可通过 yaml module 字段加载（验证插件机制）：

```python
# factory.py _PROVIDER_MAP 新增
"macos-say": ("openspeechapi.providers.tts.macos_say", "MacOSSayTTS", "MacOSSaySettings"),
"macos-stt": ("openspeechapi.providers.stt.macos_speech", "MacOSSpeechSTT", "MacOSSpeechSettings"),
```

## 7. 配置示例

`providers.yaml` 新增：

```yaml
providers:
  # macOS 原生 TTS
  tts:
    provider: macos-say
    exec_mode: in_process
    settings:
      default_voice: Ting-Ting
      default_rate: 200

  # macOS 原生 STT
  stt:
    provider: macos-stt
    exec_mode: in_process
    settings:
      language: zh-CN
```

## 8. 文件改动清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `openspeechapi/utils/audio_converter.py` | 新增 | 统一音频格式转换模块 |
| `openspeechapi/core/enums.py` | 修改 | AudioFormat 增加 AIFF |
| `openspeechapi/providers/tts/macos_say.py` | 新增 | macOS TTS provider |
| `openspeechapi/providers/stt/macos_speech.py` | 新增 | macOS STT provider |
| `openspeechapi/core/base.py` | 修改 | TTSProvider 增加 `list_voices()` 默认方法 |
| `openspeechapi/factory.py` | 修改 | 注册新 provider + 插件机制 |
| `openspeechapi/config.py` | 修改 | ProviderConfig 增加 `module`/`class` 可选字段 |
| `openspeechapi/server/routes/tts.py` | 修改 | 新增 voices 端点 |
| `openspeechapi/server/webui/index.html` | 修改 | TTS 表单增加 Voice/Speed |
| `openspeechapi/server/webui/app.js` | 修改 | Voice 加载与请求参数 |
| `scripts/engines/macos-stt/macos_stt.swift` | 新增 | Swift STT CLI 工具 |
| `scripts/engines/macos-stt/install.sh` | 新增 | 编译安装脚本 |
| `providers.yaml` | 修改 | 添加 macOS provider 配置 |

## 9. 测试要求

### 8.1 UI E2E 测试

按项目规范，需覆盖以下场景：

1. **TTS Voice 选择**: GIVEN macOS TTS provider 已选中 → WHEN 页面加载 → THEN Voice 下拉按语言分组显示所有发音人
2. **TTS 切换 Provider**: GIVEN 从 macOS TTS 切换到其他 provider → WHEN 新 provider 无 voices → THEN Voice 下拉隐藏
3. **TTS 合成带参数**: GIVEN 选择发音人和语速 → WHEN 点击 Run TTS → THEN 请求携带 voice/speed 参数 AND 返回音频正常播放
4. **STT 识别**: GIVEN macOS STT provider 可用 → WHEN 上传音频文件 → THEN 返回识别文本

### 9.2 单元测试

- AudioConverter: 格式检测、PCM↔WAV 转换、重采样、多声道混音、ffmpeg 不可用时降级
- macOS TTS: `say -v ?` 输出解析、通过 AudioConverter 进行 AIFF→WAV 转换
- macOS STT: Swift 工具 JSON 输出解析
- Factory: 插件机制加载优先级验证
