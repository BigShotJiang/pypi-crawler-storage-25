# Hot-Reload + Lazy-Loading Design Spec

## Overview

Two architectural improvements to ServiceDispatcher:

1. **Hot-reload**: Detect config/env changes and update providers without server restart
2. **Lazy-loading**: Start providers on first use, auto-unload after idle TTL

## Config Extensions

```yaml
providers:
  faster-whisper-local:
    provider: faster-whisper
    exec_mode: subprocess
    preload: false          # default false — start on first request
    keepalive: 300          # seconds idle before auto-unload (0 = never unload)
    settings:
      model_size: large-v3

  openai-stt:
    provider: openai-stt
    preload: true           # start immediately at server launch
    keepalive: 0            # never unload (lightweight cloud API)
    settings:
      api_key: ${OPENAI_API_KEY}
```

New fields on `ProviderConfig`:
- `preload: bool = False`
- `keepalive: int = 0` (seconds, 0 = never unload)

## Provider Lifecycle

```
REGISTERED ──(first request or preload)──→ STARTING ──→ READY
                                                          │
                                              (each request resets TTL)
                                                          │
                                              (idle > keepalive)
                                                          ↓
                                                       STOPPING ──→ STOPPED
                                                                      │
                                                         (next request)
                                                                      ↓
                                                                   STARTING ──→ READY
```

States: `REGISTERED`, `STARTING`, `READY`, `STOPPED`

## Implementation

### ProviderLifecycleManager

New file: `openspeechapi/dispatch/lifecycle.py`

Manages per-provider state, TTL timers, and lazy start.

```python
class ProviderState(Enum):
    REGISTERED = "registered"   # config loaded, not started
    STARTING = "starting"       # start() in progress
    READY = "ready"             # accepting requests
    STOPPED = "stopped"         # was running, now stopped (can restart)

class ProviderLifecycleManager:
    - tracks state per provider handle
    - ensure_ready(name) → starts provider if not READY, returns when READY
    - touch(name) → resets idle timer
    - _idle_checker() → background task, stops providers past keepalive
    - stop_provider(name) → gracefully stop one provider
    - start_provider(name) → start one provider
    - stop_all() → stop all running providers
```

Key: `ensure_ready()` uses an `asyncio.Lock` per provider to prevent concurrent start races.

### Dispatcher Changes

`ServiceDispatcher.start()` changes from "start all" to:
1. Start the lifecycle manager
2. For providers with `preload: true` → call `ensure_ready(name)`
3. For providers with `preload: false` → leave in REGISTERED state

`_transcribe()` / `_synthesize()` add:
```python
await self._lifecycle.ensure_ready(provider_name)
# ... then invoke as before
self._lifecycle.touch(provider_name)
```

### Hot-Reload: ConfigWatcher

New file: `openspeechapi/dispatch/watcher.py`

Uses `watchdog` library (add to deps) to monitor `providers.yaml` and `.env`.

```python
class ConfigWatcher:
    - watches config_path and .env path
    - on change: reload config, diff with current, apply changes
    - diff logic:
        - new provider → add to dispatcher as REGISTERED
        - removed provider → stop and remove
        - changed settings → stop provider, update handle, mark as STOPPED (lazy restarts)
        - changed env vars → re-interpolate, treat as settings change
    - debounce: 1s after last change (avoid rapid-fire during saves)
```

### Hot-Reload: Admin API

New endpoint in `openspeechapi/server/routes/management.py`:

```
POST /v1/admin/reload
```

Response:
```json
{
  "added": ["new-provider"],
  "removed": ["old-provider"],
  "updated": ["changed-provider"],
  "unchanged": ["stable-provider"]
}
```

### Keepalive Timer

Background `asyncio.Task` in ProviderLifecycleManager:
- Runs every 30s
- For each READY provider with `keepalive > 0`:
  - If `now - last_used > keepalive` → stop provider, set state to STOPPED
- Respects `keepalive: 0` as "never unload"

## File Changes

| File | Change |
|------|--------|
| `openspeechapi/config.py` | Add `preload`, `keepalive` to `ProviderConfig` |
| `openspeechapi/dispatch/lifecycle.py` | NEW — `ProviderLifecycleManager` |
| `openspeechapi/dispatch/watcher.py` | NEW — `ConfigWatcher` with watchdog |
| `openspeechapi/dispatch/dispatcher.py` | Integrate lifecycle manager, lazy ensure_ready |
| `openspeechapi/server/app.py` | Start watcher in lifespan, wire admin reload |
| `openspeechapi/server/routes/management.py` | Add POST /v1/admin/reload |
| `pyproject.toml` | Add `watchdog` to server extras |
| Tests | Unit tests for lifecycle, watcher, lazy start |

## Testing

- Unit: lifecycle state transitions, TTL expiry, concurrent ensure_ready
- Unit: config diff detection (added/removed/changed providers)
- Integration: lazy start (provider not started until first request)
- Integration: hot-reload (change config, verify provider updates)
