# macOS 原生 TTS/STT + 音频转换模块 + Provider 插件机制 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 集成 macOS 内置 TTS (`say`) 和 STT (`SFSpeechRecognizer`)，新增统一音频转换模块，支持 WebUI 发音人选择和语速控制，引入 provider 插件机制。

**Architecture:** 新增 `AudioConverter` 工具类处理所有音频格式转换。macOS TTS 通过 subprocess 调用 `say` 命令，STT 通过编译的 Swift CLI 工具调用 `SFSpeechRecognizer`。Provider 插件机制允许通过 `providers.yaml` 的 `module`/`class` 字段加载外部 provider，同时支持 `plugins/` 本地目录。WebUI TTS 表单增加 Voice（按语言分组）和 Speed 控件。

**Tech Stack:** Python 标准库 (wave, aifc, struct, subprocess)、ffmpeg (可选)、Swift (SFSpeechRecognizer)、Vanilla JS

**Spec:** `docs/superpowers/specs/2026-04-11-macos-native-tts-stt-design.md`

---

### Task 1: AudioFormat 枚举扩展

**Files:**
- Modify: `openspeechapi/core/enums.py:22-29`
- Modify: `tests/unit/test_enums.py`

- [ ] **Step 1: 在 AudioFormat 枚举中添加 AIFF**

在 `openspeechapi/core/enums.py` 的 `AudioFormat` 类中，在 `WAV` 之后添加 `AIFF`：

```python
class AudioFormat(str, Enum):
    PCM_16K = "pcm_16k"
    PCM_44K = "pcm_44k"
    WAV = "wav"
    AIFF = "aiff"
    MP3 = "mp3"
    OGG = "ogg"
    FLAC = "flac"
    OPUS = "opus"
```

- [ ] **Step 2: 添加测试验证 AIFF 枚举值**

在 `tests/unit/test_enums.py` 中添加：

```python
def test_audio_format_aiff():
    assert AudioFormat.AIFF == "aiff"
    assert AudioFormat.AIFF.value == "aiff"
```

- [ ] **Step 3: 运行测试验证**

Run: `python -m pytest tests/unit/test_enums.py -v`
Expected: PASS

- [ ] **Step 4: Commit**

```bash
git add openspeechapi/core/enums.py tests/unit/test_enums.py
git commit -m "feat: add AIFF to AudioFormat enum"
```

---

### Task 2: 音频格式转换模块

**Files:**
- Create: `openspeechapi/utils/audio_converter.py`
- Create: `tests/unit/test_audio_converter.py`

- [ ] **Step 1: 编写 AudioConverter 测试**

创建 `tests/unit/test_audio_converter.py`：

```python
"""Tests for unified audio format converter."""
from __future__ import annotations

import io
import struct
import wave
from unittest.mock import patch, MagicMock

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData
from openspeechapi.utils.audio_converter import AudioConverter


def _make_pcm_bytes(num_samples: int = 100, channels: int = 1) -> bytes:
    """Generate silent PCM16 bytes."""
    return b"\x00\x00" * num_samples * channels


def _make_wav_bytes(sample_rate: int = 16000, channels: int = 1, num_samples: int = 100) -> bytes:
    """Build a minimal valid WAV buffer."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"\x00\x00" * num_samples * channels)
    return buf.getvalue()


def _make_aiff_bytes(sample_rate: int = 22050, channels: int = 1, num_samples: int = 100) -> bytes:
    """Build a minimal valid AIFF buffer."""
    import aifc
    buf = io.BytesIO()
    with aifc.open(buf, "wb") as af:
        af.setnchannels(channels)
        af.setsampwidth(2)
        af.setframerate(sample_rate)
        af.writeframes(b"\x00\x00" * num_samples * channels)
    return buf.getvalue()


# ---- detect_format ----

class TestDetectFormat:
    def test_detect_wav(self):
        assert AudioConverter.detect_format(_make_wav_bytes()) == AudioFormat.WAV

    def test_detect_aiff(self):
        assert AudioConverter.detect_format(_make_aiff_bytes()) == AudioFormat.AIFF

    def test_detect_mp3_id3(self):
        assert AudioConverter.detect_format(b"ID3" + b"\x00" * 100) == AudioFormat.MP3

    def test_detect_mp3_sync(self):
        assert AudioConverter.detect_format(b"\xff\xfb" + b"\x00" * 100) == AudioFormat.MP3

    def test_detect_ogg(self):
        assert AudioConverter.detect_format(b"OggS" + b"\x00" * 100) == AudioFormat.OGG

    def test_detect_flac(self):
        assert AudioConverter.detect_format(b"fLaC" + b"\x00" * 100) == AudioFormat.FLAC

    def test_detect_unknown_returns_pcm(self):
        assert AudioConverter.detect_format(b"\x00\x00\x10\x00") == AudioFormat.PCM_16K


# ---- to_wav ----

class TestToWav:
    def test_wav_passthrough(self):
        wav = _make_wav_bytes()
        audio = AudioData(data=wav, sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = AudioConverter.to_wav(audio)
        assert result.data == wav
        assert result.format == AudioFormat.WAV

    def test_pcm_to_wav(self):
        pcm = _make_pcm_bytes()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = AudioConverter.to_wav(audio)
        assert result.data[:4] == b"RIFF"
        assert result.format == AudioFormat.WAV
        with wave.open(io.BytesIO(result.data), "rb") as wf:
            assert wf.getframerate() == 16000
            assert wf.getnchannels() == 1

    def test_aiff_to_wav(self):
        aiff = _make_aiff_bytes(22050)
        audio = AudioData(data=aiff, sample_rate=22050, channels=1, format=AudioFormat.AIFF)
        result = AudioConverter.to_wav(audio)
        assert result.data[:4] == b"RIFF"
        assert result.format == AudioFormat.WAV
        with wave.open(io.BytesIO(result.data), "rb") as wf:
            assert wf.getframerate() == 22050

    def test_to_wav_with_resample(self):
        pcm = _make_pcm_bytes(200)
        audio = AudioData(data=pcm, sample_rate=44100, channels=1, format=AudioFormat.PCM_44K)
        result = AudioConverter.to_wav(audio, sample_rate=16000)
        assert result.format == AudioFormat.WAV
        with wave.open(io.BytesIO(result.data), "rb") as wf:
            assert wf.getframerate() == 16000


# ---- resample ----

class TestResample:
    def test_same_rate_passthrough(self):
        pcm = _make_pcm_bytes(100)
        result = AudioConverter.resample(pcm, 16000, 16000)
        assert result == pcm

    def test_downsample(self):
        pcm = _make_pcm_bytes(200)
        result = AudioConverter.resample(pcm, 44100, 16000)
        expected_samples = int(200 * 16000 / 44100)
        actual_samples = len(result) // 2
        assert abs(actual_samples - expected_samples) <= 1

    def test_upsample(self):
        pcm = _make_pcm_bytes(100)
        result = AudioConverter.resample(pcm, 16000, 44100)
        expected_samples = int(100 * 44100 / 16000)
        actual_samples = len(result) // 2
        assert abs(actual_samples - expected_samples) <= 1


# ---- mix_to_mono ----

class TestMixToMono:
    def test_mono_passthrough(self):
        pcm = _make_pcm_bytes(100)
        result = AudioConverter.mix_to_mono(pcm, 1)
        assert result == pcm

    def test_stereo_to_mono(self):
        # Build stereo: left=100, right=200 per frame → mono should be 150
        left, right = 100, 200
        stereo = struct.pack("<hh", left, right) * 10
        mono = AudioConverter.mix_to_mono(stereo, 2)
        assert len(mono) == len(stereo) // 2
        samples = struct.unpack(f"<{len(mono)//2}h", mono)
        assert samples[0] == (left + right) // 2


# ---- to_pcm16k ----

class TestToPcm16k:
    def test_pcm16k_passthrough(self):
        pcm = _make_pcm_bytes()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = AudioConverter.to_pcm16k(audio)
        assert result.data == pcm
        assert result.sample_rate == 16000

    def test_wav_to_pcm16k(self):
        wav = _make_wav_bytes(44100)
        audio = AudioData(data=wav, sample_rate=44100, channels=1, format=AudioFormat.WAV)
        result = AudioConverter.to_pcm16k(audio)
        assert result.format == AudioFormat.PCM_16K
        assert result.sample_rate == 16000


# ---- convert (general) ----

class TestConvert:
    def test_pcm_to_wav(self):
        pcm = _make_pcm_bytes()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = AudioConverter.convert(audio, AudioFormat.WAV)
        assert result.format == AudioFormat.WAV
        assert result.data[:4] == b"RIFF"

    def test_wav_to_pcm(self):
        wav = _make_wav_bytes()
        audio = AudioData(data=wav, sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = AudioConverter.convert(audio, AudioFormat.PCM_16K)
        assert result.format == AudioFormat.PCM_16K


# ---- ffmpeg ----

class TestFfmpegAvailable:
    def test_ffmpeg_available_true(self):
        with patch("shutil.which", return_value="/usr/bin/ffmpeg"):
            assert AudioConverter.ffmpeg_available() is True

    def test_ffmpeg_available_false(self):
        with patch("shutil.which", return_value=None):
            assert AudioConverter.ffmpeg_available() is False

    def test_convert_to_mp3_without_ffmpeg_raises(self):
        pcm = _make_pcm_bytes()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        with patch("shutil.which", return_value=None):
            with pytest.raises(RuntimeError, match="ffmpeg"):
                AudioConverter.convert(audio, AudioFormat.MP3)
```

- [ ] **Step 2: 运行测试确认全部失败**

Run: `python -m pytest tests/unit/test_audio_converter.py -v`
Expected: FAIL (module not found)

- [ ] **Step 3: 实现 AudioConverter**

创建 `openspeechapi/utils/audio_converter.py`：

```python
"""Unified audio format converter."""
from __future__ import annotations

import io
import shutil
import struct
import subprocess
import wave
from collections.abc import AsyncIterator
from typing import Any

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData


# Language code → display group name mapping
_MAGIC_HEADERS: list[tuple[bytes, AudioFormat]] = [
    (b"RIFF", AudioFormat.WAV),      # check WAVE at offset 8 too
    (b"FORM", AudioFormat.AIFF),     # check AIFF at offset 8 too
    (b"fLaC", AudioFormat.FLAC),
    (b"OggS", AudioFormat.OGG),
    (b"ID3", AudioFormat.MP3),
]


class AudioConverter:
    """Unified audio format converter.

    - Pure Python standard library for basic conversions (PCM↔WAV, AIFF→WAV, resample, mix)
    - ffmpeg as optional backend for MP3/OGG/FLAC/OPUS
    """

    @staticmethod
    def detect_format(data: bytes) -> AudioFormat:
        """Detect audio format from file header magic bytes."""
        if len(data) < 12:
            return AudioFormat.PCM_16K

        # WAV: RIFF....WAVE
        if data[:4] == b"RIFF" and data[8:12] == b"WAVE":
            return AudioFormat.WAV
        # AIFF: FORM....AIFF
        if data[:4] == b"FORM" and data[8:12] == b"AIFF":
            return AudioFormat.AIFF
        if data[:4] == b"fLaC":
            return AudioFormat.FLAC
        if data[:4] == b"OggS":
            return AudioFormat.OGG
        if data[:3] == b"ID3" or data[:2] == b"\xff\xfb":
            return AudioFormat.MP3

        return AudioFormat.PCM_16K

    @staticmethod
    def ffmpeg_available() -> bool:
        """Check if ffmpeg is available on the system."""
        return shutil.which("ffmpeg") is not None

    @staticmethod
    def resample(pcm_bytes: bytes, src_rate: int, dst_rate: int, channels: int = 1) -> bytes:
        """Resample PCM16 audio using linear interpolation."""
        if src_rate == dst_rate:
            return pcm_bytes

        num_samples = len(pcm_bytes) // (2 * channels)
        if num_samples == 0:
            return b""

        samples = struct.unpack(f"<{num_samples * channels}h", pcm_bytes)

        ratio = dst_rate / src_rate
        new_num_samples = int(num_samples * ratio)
        result = []

        for i in range(new_num_samples):
            src_pos = i / ratio
            idx = int(src_pos)
            frac = src_pos - idx

            for ch in range(channels):
                if idx + 1 < num_samples:
                    s0 = samples[idx * channels + ch]
                    s1 = samples[(idx + 1) * channels + ch]
                    val = int(s0 + (s1 - s0) * frac)
                else:
                    val = samples[min(idx, num_samples - 1) * channels + ch]
                val = max(-32768, min(32767, val))
                result.append(val)

        return struct.pack(f"<{len(result)}h", *result)

    @staticmethod
    def mix_to_mono(pcm_bytes: bytes, channels: int) -> bytes:
        """Mix multi-channel PCM16 to mono by averaging channels."""
        if channels <= 1:
            return pcm_bytes

        num_frames = len(pcm_bytes) // (2 * channels)
        samples = struct.unpack(f"<{num_frames * channels}h", pcm_bytes)
        mono = []
        for i in range(num_frames):
            total = sum(samples[i * channels + ch] for ch in range(channels))
            mono.append(total // channels)
        return struct.pack(f"<{num_frames}h", *mono)

    @staticmethod
    def _pcm_to_wav(pcm_bytes: bytes, sample_rate: int, channels: int) -> bytes:
        """Wrap raw PCM16 in a WAV container."""
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm_bytes)
        return buf.getvalue()

    @staticmethod
    def _wav_to_pcm(wav_bytes: bytes) -> tuple[bytes, int, int]:
        """Extract raw PCM frames from WAV. Returns (pcm_bytes, sample_rate, channels)."""
        with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
            frames = wf.readframes(wf.getnframes())
            return frames, wf.getframerate(), wf.getnchannels()

    @staticmethod
    def _aiff_to_pcm(aiff_bytes: bytes) -> tuple[bytes, int, int]:
        """Extract raw PCM frames from AIFF. Returns (pcm_bytes, sample_rate, channels)."""
        import aifc
        with aifc.open(io.BytesIO(aiff_bytes), "rb") as af:
            frames = af.readframes(af.getnframes())
            sample_rate = af.getframerate()
            channels = af.getnchannels()
            sampwidth = af.getsampwidth()

        # AIFF uses big-endian; convert to little-endian for PCM16
        if sampwidth == 2:
            n = len(frames) // 2
            be_samples = struct.unpack(f">{n}h", frames)
            frames = struct.pack(f"<{n}h", *be_samples)
        elif sampwidth == 1:
            # 8-bit unsigned → 16-bit signed
            result = []
            for b in frames:
                result.append((b - 128) * 256)
            frames = struct.pack(f"<{len(result)}h", *result)

        return frames, sample_rate, channels

    @staticmethod
    def _ffmpeg_convert(
        input_bytes: bytes,
        input_format: str,
        output_format: str,
        sample_rate: int | None = None,
        channels: int | None = None,
    ) -> bytes:
        """Convert audio via ffmpeg pipe (stdin → stdout)."""
        cmd = ["ffmpeg", "-y", "-f", input_format, "-i", "pipe:0"]
        if sample_rate:
            cmd.extend(["-ar", str(sample_rate)])
        if channels:
            cmd.extend(["-ac", str(channels)])
        cmd.extend(["-f", output_format, "-loglevel", "error", "pipe:1"])
        proc = subprocess.run(cmd, input=input_bytes, capture_output=True, check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg failed: {proc.stderr.decode(errors='replace')}")
        return proc.stdout

    @classmethod
    def to_wav(cls, audio: AudioData, sample_rate: int | None = None) -> AudioData:
        """Convert any supported format to WAV."""
        fmt = audio.format
        if fmt == AudioFormat.WAV and audio.data[:4] == b"RIFF":
            if sample_rate is None or sample_rate == audio.sample_rate:
                return audio
            # Need to resample
            pcm, src_rate, channels = cls._wav_to_pcm(audio.data)
            pcm = cls.resample(pcm, src_rate, sample_rate, channels)
            wav = cls._pcm_to_wav(pcm, sample_rate, channels)
            return AudioData(data=wav, sample_rate=sample_rate, channels=channels, format=AudioFormat.WAV)

        if fmt in (AudioFormat.PCM_16K, AudioFormat.PCM_44K):
            pcm = audio.data
            src_rate = audio.sample_rate
            channels = audio.channels
            if sample_rate and sample_rate != src_rate:
                pcm = cls.resample(pcm, src_rate, sample_rate, channels)
                src_rate = sample_rate
            wav = cls._pcm_to_wav(pcm, src_rate, channels)
            return AudioData(data=wav, sample_rate=src_rate, channels=channels, format=AudioFormat.WAV)

        if fmt == AudioFormat.AIFF:
            pcm, src_rate, channels = cls._aiff_to_pcm(audio.data)
            if sample_rate and sample_rate != src_rate:
                pcm = cls.resample(pcm, src_rate, sample_rate, channels)
                src_rate = sample_rate
            wav = cls._pcm_to_wav(pcm, src_rate, channels)
            return AudioData(data=wav, sample_rate=src_rate, channels=channels, format=AudioFormat.WAV)

        # MP3/OGG/FLAC/OPUS → WAV via ffmpeg
        if not cls.ffmpeg_available():
            raise RuntimeError(
                f"Cannot convert {fmt.value} to WAV: ffmpeg not found. "
                "Install ffmpeg for advanced format conversion."
            )
        fmt_map = {"mp3": "mp3", "ogg": "ogg", "flac": "flac", "opus": "ogg"}
        in_fmt = fmt_map.get(fmt.value, fmt.value)
        wav_bytes = cls._ffmpeg_convert(audio.data, in_fmt, "wav", sample_rate)
        # Parse the WAV to get actual sample rate
        with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
            actual_rate = wf.getframerate()
            actual_channels = wf.getnchannels()
        return AudioData(data=wav_bytes, sample_rate=actual_rate, channels=actual_channels, format=AudioFormat.WAV)

    @classmethod
    def to_pcm16k(cls, audio: AudioData) -> AudioData:
        """Convert any format to PCM 16kHz 16-bit mono."""
        if (
            audio.format == AudioFormat.PCM_16K
            and audio.sample_rate == 16000
            and audio.channels == 1
        ):
            return audio

        # First convert to WAV (handles all format decoding)
        wav_audio = cls.to_wav(audio, sample_rate=16000)
        pcm, rate, channels = cls._wav_to_pcm(wav_audio.data)

        if channels > 1:
            pcm = cls.mix_to_mono(pcm, channels)

        return AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)

    @classmethod
    def convert(
        cls,
        audio: AudioData,
        target_format: AudioFormat,
        target_sample_rate: int | None = None,
        target_channels: int | None = None,
    ) -> AudioData:
        """Convert AudioData to target format/sample_rate/channels."""
        # WAV target
        if target_format == AudioFormat.WAV:
            result = cls.to_wav(audio, target_sample_rate)
            if target_channels and target_channels != result.channels:
                pcm, rate, ch = cls._wav_to_pcm(result.data)
                if target_channels == 1:
                    pcm = cls.mix_to_mono(pcm, ch)
                wav = cls._pcm_to_wav(pcm, rate, target_channels)
                return AudioData(data=wav, sample_rate=rate, channels=target_channels, format=AudioFormat.WAV)
            return result

        # PCM targets
        if target_format in (AudioFormat.PCM_16K, AudioFormat.PCM_44K):
            target_rate = target_sample_rate or (16000 if target_format == AudioFormat.PCM_16K else 44100)
            wav_audio = cls.to_wav(audio, target_rate)
            pcm, rate, channels = cls._wav_to_pcm(wav_audio.data)
            ch = target_channels or 1
            if channels != ch:
                if ch == 1:
                    pcm = cls.mix_to_mono(pcm, channels)
            return AudioData(data=pcm, sample_rate=rate, channels=ch, format=target_format)

        # AIFF target (rare, but for completeness)
        if target_format == AudioFormat.AIFF:
            wav_audio = cls.to_wav(audio, target_sample_rate)
            if not cls.ffmpeg_available():
                raise RuntimeError("Cannot convert to AIFF: ffmpeg not found.")
            aiff_bytes = cls._ffmpeg_convert(wav_audio.data, "wav", "aiff", target_sample_rate, target_channels)
            return AudioData(
                data=aiff_bytes,
                sample_rate=target_sample_rate or wav_audio.sample_rate,
                channels=target_channels or wav_audio.channels,
                format=AudioFormat.AIFF,
            )

        # MP3/OGG/FLAC/OPUS → ffmpeg
        if not cls.ffmpeg_available():
            raise RuntimeError(
                f"Cannot convert to {target_format.value}: ffmpeg not found. "
                "Install ffmpeg for advanced format conversion."
            )
        wav_audio = cls.to_wav(audio, target_sample_rate)
        fmt_map = {"mp3": "mp3", "ogg": "ogg", "flac": "flac", "opus": "opus"}
        out_fmt = fmt_map.get(target_format.value, target_format.value)
        result_bytes = cls._ffmpeg_convert(
            wav_audio.data, "wav", out_fmt, target_sample_rate, target_channels
        )
        return AudioData(
            data=result_bytes,
            sample_rate=target_sample_rate or wav_audio.sample_rate,
            channels=target_channels or wav_audio.channels,
            format=target_format,
        )

    @staticmethod
    async def convert_stream(
        chunks: AsyncIterator[bytes],
        src_format: AudioFormat,
        dst_format: AudioFormat,
        src_sample_rate: int,
        dst_sample_rate: int | None = None,
    ) -> AsyncIterator[bytes]:
        """Streaming conversion (reserved, not yet implemented)."""
        raise NotImplementedError("Streaming conversion not yet supported")
        yield  # pragma: no cover
```

- [ ] **Step 4: 运行测试验证全部通过**

Run: `python -m pytest tests/unit/test_audio_converter.py -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/utils/audio_converter.py tests/unit/test_audio_converter.py
git commit -m "feat: add unified AudioConverter module with format detection, conversion, and resampling"
```

---

### Task 3: TTSProvider 基类增加 list_voices()

**Files:**
- Modify: `openspeechapi/core/base.py:47-58`
- Modify: `tests/unit/test_base.py`

- [ ] **Step 1: 编写测试**

在 `tests/unit/test_base.py` 中添加测试验证默认 list_voices 返回空列表：

```python
@pytest.mark.asyncio
async def test_tts_provider_list_voices_default():
    """TTSProvider.list_voices() should return empty list by default."""
    # Use FakeTTS from conftest which inherits TTSProvider
    from tests.conftest import FakeTTS
    provider = FakeTTS()
    voices = await provider.list_voices()
    assert voices == []
```

- [ ] **Step 2: 运行测试确认失败**

Run: `python -m pytest tests/unit/test_base.py::test_tts_provider_list_voices_default -v`
Expected: FAIL (list_voices not defined)

- [ ] **Step 3: 在 TTSProvider 中添加 list_voices 方法**

在 `openspeechapi/core/base.py` 的 `TTSProvider` 类中，在 `synthesize_stream` 之后添加：

```python
    async def list_voices(self) -> list[dict]:
        """Return available voices. Override in subclass to provide voice list."""
        return []
```

- [ ] **Step 4: 运行测试**

Run: `python -m pytest tests/unit/test_base.py::test_tts_provider_list_voices_default -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/core/base.py tests/unit/test_base.py
git commit -m "feat: add list_voices() default method to TTSProvider base class"
```

---

### Task 4: macOS TTS Provider (macos-say)

**Files:**
- Create: `openspeechapi/providers/tts/macos_say.py`
- Create: `tests/unit/test_providers/test_macos_say.py`

- [ ] **Step 1: 编写测试**

创建 `tests/unit/test_providers/test_macos_say.py`：

```python
"""Tests for macOS Say TTS provider."""
from __future__ import annotations

import io
import wave
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.providers.tts.macos_say import MacOSSayTTS, MacOSSaySettings


class TestMacOSSaySettings:
    def test_defaults(self):
        s = MacOSSaySettings()
        assert s.default_voice == "Samantha"
        assert s.default_rate == 200

    def test_custom(self):
        s = MacOSSaySettings(default_voice="Ting-Ting", default_rate=150)
        assert s.default_voice == "Ting-Ting"
        assert s.default_rate == 150


class TestMacOSSayTTS:
    def test_metadata(self):
        p = MacOSSayTTS()
        assert p.name == "macos-say"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is MacOSSaySettings
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    @pytest.mark.asyncio
    async def test_start_success(self):
        with patch("shutil.which", return_value="/usr/bin/say"):
            p = MacOSSayTTS()
            await p.start()
            assert p._available is True

    @pytest.mark.asyncio
    async def test_start_not_macos(self):
        with patch("shutil.which", return_value=None):
            p = MacOSSayTTS()
            with pytest.raises(RuntimeError, match="say"):
                await p.start()

    @pytest.mark.asyncio
    async def test_stop(self):
        p = MacOSSayTTS()
        p._available = True
        await p.stop()
        assert p._available is False

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = MacOSSayTTS()
        assert await p.health_check() is False
        p._available = True
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_synthesize_not_started(self):
        p = MacOSSayTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self):
        from openspeechapi.core.models import AudioData

        p = MacOSSayTTS()
        p._available = True

        # Build a fake AIFF file that afconvert/say would produce
        aiff_bytes = b"fake_aiff"

        # Mock _run_say to write a WAV file and return it
        wav_buf = io.BytesIO()
        with wave.open(wav_buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(22050)
            wf.writeframes(b"\x00\x00" * 100)
        fake_wav = wav_buf.getvalue()

        with patch.object(p, "_run_say", new_callable=AsyncMock, return_value=fake_wav):
            result = await p.synthesize("hello")

        assert isinstance(result, AudioData)
        assert result.format == AudioFormat.WAV
        assert result.data[:4] == b"RIFF"

    @pytest.mark.asyncio
    async def test_synthesize_stream_not_implemented(self):
        p = MacOSSayTTS()
        p._available = True
        with pytest.raises(NotImplementedError):
            async for _ in p.synthesize_stream("hello"):
                pass

    def test_parse_voices(self):
        output = (
            "Alex                en_US    # Most people recognize me by my voice.\n"
            "Samantha            en_US    # Hello, my name is Samantha. I am an American-English voice.\n"
            "Ting-Ting           zh_CN    # 你好，我叫Ting-Ting。我讲中文。\n"
            "Mei-Jia             zh_TW    # 你好，我叫美佳。我說中文。\n"
        )
        voices = MacOSSayTTS._parse_voices_output(output)
        assert len(voices) == 4
        assert voices[0]["name"] == "Alex"
        assert voices[0]["language"] == "en_US"
        assert voices[2]["name"] == "Ting-Ting"
        assert voices[2]["language"] == "zh_CN"
        # Check group names
        assert voices[0]["group"] == "English"
        assert voices[2]["group"] == "中文"

    @pytest.mark.asyncio
    async def test_list_voices(self):
        p = MacOSSayTTS()
        p._available = True
        fake_output = "Samantha            en_US    # Hello.\nTing-Ting           zh_CN    # 你好。\n"
        with patch.object(p, "_run_command", new_callable=AsyncMock, return_value=fake_output):
            voices = await p.list_voices()
        assert len(voices) == 2
        assert voices[0]["name"] == "Samantha"
```

- [ ] **Step 2: 运行测试确认失败**

Run: `python -m pytest tests/unit/test_providers/test_macos_say.py -v`
Expected: FAIL (module not found)

- [ ] **Step 3: 实现 MacOSSayTTS**

创建 `openspeechapi/providers/tts/macos_say.py`：

```python
"""macOS native TTS provider using the `say` command."""
from __future__ import annotations

import asyncio
import re
import shutil
import tempfile
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

from openspeechapi.core.base import TTSProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings
from openspeechapi.utils.audio_converter import AudioConverter


# Language code prefix → display group name
_LANG_GROUPS: dict[str, str] = {
    "zh": "中文",
    "en": "English",
    "ja": "日本語",
    "ko": "한국어",
    "fr": "Français",
    "de": "Deutsch",
    "es": "Español",
    "it": "Italiano",
    "pt": "Português",
    "ru": "Русский",
    "ar": "العربية",
    "nl": "Nederlands",
    "sv": "Svenska",
    "da": "Dansk",
    "fi": "Suomi",
    "nb": "Norsk",
    "pl": "Polski",
    "tr": "Türkçe",
    "th": "ไทย",
    "he": "עברית",
    "hi": "हिन्दी",
    "id": "Bahasa Indonesia",
    "ro": "Română",
    "cs": "Čeština",
    "el": "Ελληνικά",
    "hu": "Magyar",
    "sk": "Slovenčina",
}

_VOICE_LINE_RE = re.compile(r"^(\S+)\s+(\S+)\s+#\s*(.*)$")


@dataclass
class MacOSSaySettings(BaseSettings):
    default_voice: str = "Samantha"
    default_rate: int = 200


class MacOSSayTTS(TTSProvider):
    name = "macos-say"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = MacOSSaySettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}

    def __init__(self, settings: MacOSSaySettings | None = None) -> None:
        self.settings = settings or MacOSSaySettings()
        self._available = False
        self._voices_cache: list[dict] | None = None

    async def start(self) -> None:
        if not shutil.which("say"):
            raise RuntimeError(
                "macOS `say` command not found. This provider requires macOS."
            )
        self._available = True

    async def stop(self) -> None:
        self._available = False
        self._voices_cache = None

    async def health_check(self) -> bool:
        return self._available

    async def _run_command(self, cmd_str: str) -> str:
        """Run a shell command and return stdout."""
        proc = await asyncio.create_subprocess_shell(
            cmd_str,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return stdout.decode("utf-8", errors="replace")

    async def _run_say(self, text: str, voice: str, rate: int) -> bytes:
        """Run `say` to produce audio, convert AIFF→WAV, return WAV bytes."""
        with tempfile.NamedTemporaryFile(suffix=".aiff", delete=False) as f:
            aiff_path = Path(f.name)

        try:
            cmd = ["say", "-v", voice, "-r", str(rate), "-o", str(aiff_path), "--", text]
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise RuntimeError(f"say failed: {stderr.decode(errors='replace')}")

            aiff_data = aiff_path.read_bytes()
            audio = AudioData(
                data=aiff_data,
                sample_rate=22050,
                channels=1,
                format=AudioFormat.AIFF,
            )
            wav_audio = AudioConverter.to_wav(audio)
            return wav_audio.data
        finally:
            aiff_path.unlink(missing_ok=True)

    async def synthesize(self, text: str, opts: TTSOptions | None = None) -> AudioData:
        if not self._available:
            raise RuntimeError("Provider not started — call start() first")

        opts = opts or TTSOptions()
        voice = opts.voice or self.settings.default_voice
        rate = int(self.settings.default_rate * opts.speed) if opts.speed != 1.0 else self.settings.default_rate

        wav_bytes = await self._run_say(text, voice, rate)

        import wave as wave_mod
        import io
        with wave_mod.open(io.BytesIO(wav_bytes), "rb") as wf:
            sample_rate = wf.getframerate()
            channels = wf.getnchannels()
            duration_frames = wf.getnframes()
            duration_ms = int(duration_frames / sample_rate * 1000) if sample_rate else 0

        return AudioData(
            data=wav_bytes,
            sample_rate=sample_rate,
            channels=channels,
            format=AudioFormat.WAV,
            duration_ms=duration_ms,
        )

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError("MacOSSayTTS does not support streaming synthesis")
        yield  # pragma: no cover

    @staticmethod
    def _parse_voices_output(output: str) -> list[dict]:
        """Parse `say -v ?` output into structured voice list."""
        voices = []
        for line in output.strip().splitlines():
            m = _VOICE_LINE_RE.match(line.strip())
            if not m:
                continue
            name, lang_code, description = m.group(1), m.group(2), m.group(3).strip()
            lang_prefix = lang_code.split("_")[0]
            group = _LANG_GROUPS.get(lang_prefix, lang_code)
            voices.append({
                "name": name,
                "language": lang_code,
                "description": description,
                "group": group,
            })
        return voices

    async def list_voices(self) -> list[dict]:
        """List all available macOS voices by running `say -v ?`."""
        if self._voices_cache is not None:
            return self._voices_cache

        output = await self._run_command("say -v ?")
        self._voices_cache = self._parse_voices_output(output)
        return self._voices_cache
```

- [ ] **Step 4: 运行测试**

Run: `python -m pytest tests/unit/test_providers/test_macos_say.py -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/providers/tts/macos_say.py tests/unit/test_providers/test_macos_say.py
git commit -m "feat: add macOS native TTS provider (macos-say) using say command"
```

---

### Task 5: macOS STT Provider (macos-stt)

**Files:**
- Create: `scripts/engines/macos-stt/macos_stt.swift`
- Create: `scripts/engines/macos-stt/install.sh`
- Create: `openspeechapi/providers/stt/macos_speech.py`
- Create: `tests/unit/test_providers/test_macos_speech.py`

- [ ] **Step 1: 创建 Swift STT 工具**

创建 `scripts/engines/macos-stt/macos_stt.swift`：

```swift
import Foundation
import Speech

// Usage: macos-stt-helper --audio <path> [--language <code>]

func main() {
    let args = CommandLine.arguments
    var audioPath: String?
    var language = "en-US"

    var i = 1
    while i < args.count {
        switch args[i] {
        case "--audio":
            i += 1
            if i < args.count { audioPath = args[i] }
        case "--language":
            i += 1
            if i < args.count { language = args[i] }
        default:
            break
        }
        i += 1
    }

    guard let path = audioPath else {
        let error = ["error": "Missing --audio argument"]
        printJSON(error)
        exit(1)
    }

    let url = URL(fileURLWithPath: path)
    guard FileManager.default.fileExists(atPath: path) else {
        let error = ["error": "Audio file not found: \(path)"]
        printJSON(error)
        exit(1)
    }

    let locale = Locale(identifier: language)
    guard let recognizer = SFSpeechRecognizer(locale: locale) else {
        let error = ["error": "Speech recognizer not available for language: \(language)"]
        printJSON(error)
        exit(1)
    }

    guard recognizer.isAvailable else {
        let error = ["error": "Speech recognizer is not available (check permissions)"]
        printJSON(error)
        exit(1)
    }

    let request = SFSpeechURLRecognitionRequest(url: url)
    request.shouldReportPartialResults = false

    let semaphore = DispatchSemaphore(value: 0)
    var resultText = ""
    var resultConfidence: Float = 0.0
    var errorMessage: String?

    recognizer.recognitionTask(with: request) { result, error in
        if let error = error {
            errorMessage = error.localizedDescription
            semaphore.signal()
            return
        }

        if let result = result, result.isFinal {
            resultText = result.bestTranscription.formattedString
            let segments = result.bestTranscription.segments
            if !segments.isEmpty {
                resultConfidence = segments.map { $0.confidence }.reduce(0, +) / Float(segments.count)
            }
            semaphore.signal()
        }
    }

    let timeout = DispatchTime.now() + .seconds(60)
    if semaphore.wait(timeout: timeout) == .timedOut {
        let error = ["error": "Recognition timed out"]
        printJSON(error)
        exit(1)
    }

    if let err = errorMessage {
        let error = ["error": err]
        printJSON(error)
        exit(1)
    }

    let output: [String: Any] = [
        "text": resultText,
        "confidence": resultConfidence,
        "language": language
    ]
    printJSON(output)
}

func printJSON(_ dict: [String: Any]) {
    if let data = try? JSONSerialization.data(withJSONObject: dict, options: []),
       let str = String(data: data, encoding: .utf8) {
        print(str)
    }
}

main()
```

- [ ] **Step 2: 创建安装脚本**

创建 `scripts/engines/macos-stt/install.sh`：

```bash
#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BINARY_NAME="macos-stt-helper"
OUTPUT_PATH="${SCRIPT_DIR}/${BINARY_NAME}"

echo "=== macOS STT Helper Installer ==="

# Check platform
if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "ERROR: This tool requires macOS."
    exit 1
fi

# Check Xcode Command Line Tools
if ! xcode-select -p &>/dev/null; then
    echo "ERROR: Xcode Command Line Tools not installed."
    echo "Run: xcode-select --install"
    exit 1
fi

# Compile
echo "Compiling ${BINARY_NAME}..."
swiftc \
    -o "${OUTPUT_PATH}" \
    "${SCRIPT_DIR}/macos_stt.swift" \
    -framework Speech \
    -framework Foundation

chmod +x "${OUTPUT_PATH}"
echo "Installed: ${OUTPUT_PATH}"
echo "Done."
```

- [ ] **Step 3: 编写 Provider 测试**

创建 `tests/unit/test_providers/test_macos_speech.py`：

```python
"""Tests for macOS Speech STT provider."""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData
from openspeechapi.providers.stt.macos_speech import MacOSSpeechSTT, MacOSSpeechSettings


class TestMacOSSpeechSettings:
    def test_defaults(self):
        s = MacOSSpeechSettings()
        assert s.language == "zh-CN"
        assert s.binary_path == ""

    def test_custom(self):
        s = MacOSSpeechSettings(language="en-US", binary_path="/usr/local/bin/macos-stt-helper")
        assert s.language == "en-US"
        assert s.binary_path == "/usr/local/bin/macos-stt-helper"


class TestMacOSSpeechSTT:
    def test_metadata(self):
        p = MacOSSpeechSTT()
        assert p.name == "macos-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is MacOSSpeechSettings
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    @pytest.mark.asyncio
    async def test_start_binary_found(self):
        p = MacOSSpeechSTT()
        with patch("pathlib.Path.exists", return_value=True):
            await p.start()
        assert p._available is True

    @pytest.mark.asyncio
    async def test_start_binary_not_found(self):
        p = MacOSSpeechSTT()
        with patch("pathlib.Path.exists", return_value=False):
            with pytest.raises(RuntimeError, match="not found"):
                await p.start()

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = MacOSSpeechSTT()
        assert await p.health_check() is False
        p._available = True
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_transcribe_not_started(self):
        p = MacOSSpeechSTT()
        audio = AudioData(data=b"fake", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        with pytest.raises(RuntimeError, match="not started"):
            await p.transcribe(audio)

    @pytest.mark.asyncio
    async def test_transcribe_returns_transcription(self):
        from openspeechapi.core.models import Transcription

        p = MacOSSpeechSTT()
        p._available = True
        p._binary_path = "/fake/macos-stt-helper"

        audio = AudioData(
            data=b"RIFF" + b"\x00" * 40,
            sample_rate=16000,
            channels=1,
            format=AudioFormat.WAV,
        )

        json_output = json.dumps({"text": "hello world", "confidence": 0.95, "language": "en-US"})

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(json_output.encode(), b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            with patch("tempfile.NamedTemporaryFile"):
                with patch("pathlib.Path.write_bytes"):
                    with patch("pathlib.Path.unlink"):
                        result = await p.transcribe(audio)

        assert isinstance(result, Transcription)
        assert result.text == "hello world"
        assert result.confidence == 0.95

    @pytest.mark.asyncio
    async def test_transcribe_stream_not_implemented(self):
        p = MacOSSpeechSTT()
        p._available = True
        with pytest.raises(NotImplementedError):
            async for _ in p.transcribe_stream(iter([])):
                pass
```

- [ ] **Step 4: 运行测试确认失败**

Run: `python -m pytest tests/unit/test_providers/test_macos_speech.py -v`
Expected: FAIL (module not found)

- [ ] **Step 5: 实现 MacOSSpeechSTT**

创建 `openspeechapi/providers/stt/macos_speech.py`：

```python
"""macOS native STT provider using SFSpeechRecognizer via Swift CLI helper."""
from __future__ import annotations

import asyncio
import json
import tempfile
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openspeechapi.core.base import STTProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings
from openspeechapi.utils.audio_converter import AudioConverter


_DEFAULT_BINARY_PATHS = [
    Path(__file__).resolve().parents[3] / "scripts" / "engines" / "macos-stt" / "macos-stt-helper",
]


@dataclass
class MacOSSpeechSettings(BaseSettings):
    language: str = "zh-CN"
    binary_path: str = ""


class MacOSSpeechSTT(STTProvider):
    name = "macos-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = MacOSSpeechSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}

    def __init__(self, settings: MacOSSpeechSettings | None = None) -> None:
        self.settings = settings or MacOSSpeechSettings()
        self._available = False
        self._binary_path: str = ""

    def _find_binary(self) -> str | None:
        """Find the compiled Swift binary."""
        if self.settings.binary_path:
            p = Path(self.settings.binary_path)
            return str(p) if p.exists() else None

        for path in _DEFAULT_BINARY_PATHS:
            if path.exists():
                return str(path)
        return None

    async def start(self) -> None:
        binary = self._find_binary()
        if not binary:
            raise RuntimeError(
                "macOS STT helper binary not found. "
                "Run: bash scripts/engines/macos-stt/install.sh"
            )
        self._binary_path = binary
        self._available = True

    async def stop(self) -> None:
        self._available = False

    async def health_check(self) -> bool:
        return self._available

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if not self._available:
            raise RuntimeError("Provider not started — call start() first")

        opts = opts or STTOptions()
        language = opts.language or self.settings.language

        # Ensure audio is WAV format
        wav_audio = AudioConverter.to_wav(audio)

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            tmp_path = Path(f.name)

        try:
            tmp_path.write_bytes(wav_audio.data)

            proc = await asyncio.create_subprocess_exec(
                self._binary_path,
                "--audio", str(tmp_path),
                "--language", language,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()

            if proc.returncode != 0:
                err = stderr.decode(errors="replace") or stdout.decode(errors="replace")
                raise RuntimeError(f"macOS STT failed: {err}")

            result = json.loads(stdout.decode("utf-8"))
            if "error" in result:
                raise RuntimeError(f"macOS STT error: {result['error']}")

            return Transcription(
                text=result.get("text", ""),
                confidence=result.get("confidence"),
                language=result.get("language", language),
            )
        finally:
            tmp_path.unlink(missing_ok=True)

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError("MacOSSpeechSTT does not support streaming transcription")
        yield  # pragma: no cover
```

- [ ] **Step 6: 运行测试**

Run: `python -m pytest tests/unit/test_providers/test_macos_speech.py -v`
Expected: ALL PASS

- [ ] **Step 7: 给 install.sh 添加执行权限**

Run: `chmod +x scripts/engines/macos-stt/install.sh`

- [ ] **Step 8: Commit**

```bash
git add scripts/engines/macos-stt/ openspeechapi/providers/stt/macos_speech.py tests/unit/test_providers/test_macos_speech.py
git commit -m "feat: add macOS native STT provider with Swift SFSpeechRecognizer helper"
```

---

### Task 6: Provider 插件机制

**Files:**
- Modify: `openspeechapi/config.py:43-51`
- Modify: `openspeechapi/factory.py`
- Modify: `openspeechapi/cli.py:36-45`
- Create: `tests/unit/test_plugin_mechanism.py`

- [ ] **Step 1: 编写测试**

创建 `tests/unit/test_plugin_mechanism.py`：

```python
"""Tests for provider plugin mechanism."""
from __future__ import annotations

import sys
import importlib
from pathlib import Path
from textwrap import dedent
from unittest.mock import patch

import pytest

from openspeechapi.config import ProviderConfig
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.factory import _PROVIDER_MAP, _resolve, _resolve_from_config


class TestProviderConfig:
    def test_module_class_fields_default_none(self):
        cfg = ProviderConfig(provider="test", exec_mode="in_process")
        assert cfg.module is None
        assert cfg.provider_class is None

    def test_module_class_fields_set(self):
        cfg = ProviderConfig(
            provider="test",
            exec_mode="in_process",
            module="my_plugin.tts",
            provider_class="MyTTS",
        )
        assert cfg.module == "my_plugin.tts"
        assert cfg.provider_class == "MyTTS"


class TestResolveFromConfig:
    def test_resolve_with_module_and_class(self, tmp_path):
        # Create a fake plugin module
        plugin_dir = tmp_path / "my_plugin"
        plugin_dir.mkdir()
        (plugin_dir / "__init__.py").write_text("")
        (plugin_dir / "tts.py").write_text(dedent("""\
            from dataclasses import dataclass
            from openspeechapi.core.base import TTSProvider
            from openspeechapi.core.enums import Capability, ExecMode, ProviderType
            from openspeechapi.core.settings import BaseSettings

            @dataclass
            class MyTTSSettings(BaseSettings):
                voice: str = "default"

            class MyTTS(TTSProvider):
                name = "my-tts"
                provider_type = ProviderType.TTS
                execution_mode = ExecMode.IN_PROCESS
                settings_cls = MyTTSSettings
                capabilities = {Capability.BATCH}

                def __init__(self, settings=None):
                    self.settings = settings or MyTTSSettings()

                async def start(self): pass
                async def stop(self): pass
                async def health_check(self): return True
                async def synthesize(self, text, opts=None): pass
                async def synthesize_stream(self, text, opts=None):
                    raise NotImplementedError
                    yield
        """))

        sys.path.insert(0, str(tmp_path))
        try:
            cfg = ProviderConfig(
                provider="my-tts",
                exec_mode="in_process",
                module="my_plugin.tts",
                provider_class="MyTTS",
            )
            provider_cls, settings_cls = _resolve_from_config(cfg)
            assert provider_cls.name == "my-tts"
            assert settings_cls.__name__ == "MyTTSSettings"
        finally:
            sys.path.remove(str(tmp_path))
            # Clean up loaded modules
            for mod_name in list(sys.modules):
                if mod_name.startswith("my_plugin"):
                    del sys.modules[mod_name]

    def test_resolve_fallback_to_provider_map(self):
        cfg = ProviderConfig(provider="piper", exec_mode="in_process")
        provider_cls, settings_cls = _resolve_from_config(cfg)
        assert provider_cls.name == "piper"

    def test_resolve_unknown_provider_raises(self):
        cfg = ProviderConfig(provider="nonexistent", exec_mode="in_process")
        with pytest.raises(Exception):
            _resolve_from_config(cfg)


class TestPluginsDirectory:
    def test_plugins_dir_added_to_sys_path(self, tmp_path):
        from openspeechapi.factory import _ensure_plugins_dir
        plugins = tmp_path / "plugins"
        plugins.mkdir()
        _ensure_plugins_dir(tmp_path)
        assert str(plugins) in sys.path
        sys.path.remove(str(plugins))

    def test_no_plugins_dir_no_error(self, tmp_path):
        from openspeechapi.factory import _ensure_plugins_dir
        _ensure_plugins_dir(tmp_path)  # Should not raise
```

- [ ] **Step 2: 运行测试确认失败**

Run: `python -m pytest tests/unit/test_plugin_mechanism.py -v`
Expected: FAIL

- [ ] **Step 3: 修改 ProviderConfig 增加 module/class 字段**

在 `openspeechapi/config.py` 的 `ProviderConfig` 中添加两个可选字段：

```python
@dataclass
class ProviderConfig:
    provider: str
    exec_mode: str
    settings: dict[str, Any] = field(default_factory=dict)
    filters: list[dict[str, Any]] = field(default_factory=list)
    endpoint: str | None = None
    preload: bool = False
    keepalive: int = 0
    module: str | None = None
    provider_class: str | None = None
```

在 `load_config` 中解析这两个字段，在创建 `ProviderConfig` 的地方添加：

```python
    providers[name] = ProviderConfig(
        provider=spec["provider"],
        exec_mode=spec["exec_mode"],
        settings=spec.get("settings", {}),
        filters=spec.get("filters", []),
        endpoint=spec.get("endpoint"),
        preload=bool(spec.get("preload", False)),
        keepalive=int(spec.get("keepalive", 0)),
        module=spec.get("module"),
        provider_class=spec.get("class"),
    )
```

- [ ] **Step 4: 修改 factory.py 添加插件解析和 plugins 目录支持**

在 `openspeechapi/factory.py` 中，在 `_PROVIDER_MAP` 新增 macos 条目，并添加 `_resolve_from_config` 和 `_ensure_plugins_dir`：

```python
# 在 _PROVIDER_MAP 中添加:
"macos-say": (
    "openspeechapi.providers.tts.macos_say",
    "MacOSSayTTS",
    "MacOSSaySettings",
),
"macos-stt": (
    "openspeechapi.providers.stt.macos_speech",
    "MacOSSpeechSTT",
    "MacOSSpeechSettings",
),
```

在文件末尾添加：

```python
def _resolve_from_config(prov_cfg: Any) -> tuple[type, type]:
    """Resolve provider class from config, with plugin mechanism support.

    Priority:
    1. If config has module + provider_class → importlib.import_module
    2. Fallback to _PROVIDER_MAP
    """
    import importlib

    module_path = getattr(prov_cfg, "module", None)
    class_name = getattr(prov_cfg, "provider_class", None)

    if module_path and class_name:
        mod = importlib.import_module(module_path)
        provider_cls = getattr(mod, class_name)
        # Try to find settings class: convention is <ClassName>Settings or settings_cls attribute
        settings_cls = getattr(provider_cls, "settings_cls", None)
        if settings_cls is None:
            from openspeechapi.core.settings import BaseSettings
            settings_cls = BaseSettings
        return provider_cls, settings_cls

    return _resolve(prov_cfg.provider)


def _ensure_plugins_dir(project_root: Path | None = None) -> None:
    """Add plugins/ directory to sys.path if it exists."""
    import sys

    if project_root is None:
        project_root = Path.cwd()

    plugins_dir = project_root / "plugins"
    if plugins_dir.is_dir():
        plugins_str = str(plugins_dir)
        if plugins_str not in sys.path:
            sys.path.insert(0, plugins_str)
```

Also add `from pathlib import Path` at the top of `factory.py`.

- [ ] **Step 5: 修改 cli.py 中的 registry 构建逻辑**

在 `openspeechapi/cli.py` 的 `_cmd_serve` 函数中，在构建 registry 之前调用 `_ensure_plugins_dir`：

```python
def _cmd_serve(args: argparse.Namespace) -> None:
    import uvicorn
    from openspeechapi.server.app import create_app
    from openspeechapi.core.registry import ProviderRegistry

    config_path = Path(args.config)

    from openspeechapi.factory import _PROVIDER_MAP, _resolve, _ensure_plugins_dir
    _ensure_plugins_dir()

    registry = ProviderRegistry()
    for name in _PROVIDER_MAP:
        try:
            provider_cls, _ = _resolve(name)
            registry.register(name, provider_cls)
        except Exception:
            pass

    app = create_app(config_path, registry)
    # ... rest unchanged
```

- [ ] **Step 6: 运行测试**

Run: `python -m pytest tests/unit/test_plugin_mechanism.py -v`
Expected: ALL PASS

- [ ] **Step 7: 运行现有测试确认无回归**

Run: `python -m pytest tests/unit/test_config.py tests/unit/test_cli.py -v`
Expected: ALL PASS

- [ ] **Step 8: Commit**

```bash
git add openspeechapi/config.py openspeechapi/factory.py openspeechapi/cli.py tests/unit/test_plugin_mechanism.py
git commit -m "feat: add provider plugin mechanism with module/class config and plugins/ directory support"
```

---

### Task 7: Voice 列表 API 端点

**Files:**
- Modify: `openspeechapi/server/routes/tts.py`
- Modify: `tests/unit/test_server/test_routes.py`

- [ ] **Step 1: 编写测试**

在 `tests/unit/test_server/test_routes.py` 中添加 voice 列表端点测试：

```python
@pytest.mark.asyncio
async def test_tts_voices_endpoint(client):
    """GET /v1/tts/{provider}/voices returns voice list."""
    resp = await client.get("/v1/tts/tts/voices")
    assert resp.status_code == 200
    data = resp.json()
    assert "voices" in data
    assert isinstance(data["voices"], list)


@pytest.mark.asyncio
async def test_tts_voices_unknown_provider(client):
    """GET /v1/tts/{provider}/voices returns 404 for unknown provider."""
    resp = await client.get("/v1/tts/nonexistent/voices")
    assert resp.status_code == 404
```

- [ ] **Step 2: 运行测试确认失败**

Run: `python -m pytest tests/unit/test_server/test_routes.py -k "voices" -v`
Expected: FAIL (404 — route not defined)

- [ ] **Step 3: 在 tts.py 路由中添加 voices 端点**

在 `openspeechapi/server/routes/tts.py` 中添加：

```python
@router.get("/{provider}/voices")
async def list_voices(request: Request, provider: str):
    dispatcher = request.app.state.dispatcher
    try:
        handle = dispatcher._get_handle(provider)
    except ProviderNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    await dispatcher._lifecycle.ensure_ready(provider)
    instance = dispatcher._lifecycle.get_instance(provider)

    if instance is None or not hasattr(instance, "list_voices"):
        return {"voices": []}

    voices = await instance.list_voices()
    return {"voices": voices}
```

Note: We need to check if `get_instance` exists on the lifecycle manager. If not, we need to add a way to access the provider instance. Check the lifecycle manager:

- [ ] **Step 4: 检查并适配 lifecycle manager**

查看 `openspeechapi/dispatch/lifecycle.py` 是否有获取 provider 实例的方法。如果没有 `get_instance`，需要添加。

在 `ProviderLifecycleManager` 中添加：

```python
def get_instance(self, name: str) -> SpeechProvider | None:
    """Return the provider instance if started, else None."""
    entry = self._entries.get(name)
    if entry is None:
        return None
    return entry.instance
```

- [ ] **Step 5: 运行测试**

Run: `python -m pytest tests/unit/test_server/test_routes.py -k "voices" -v`
Expected: ALL PASS

- [ ] **Step 6: Commit**

```bash
git add openspeechapi/server/routes/tts.py openspeechapi/dispatch/lifecycle.py tests/unit/test_server/test_routes.py
git commit -m "feat: add GET /v1/tts/{provider}/voices API endpoint"
```

---

### Task 8: WebUI TTS 表单增强

**Files:**
- Modify: `openspeechapi/server/webui/index.html:104-115`
- Modify: `openspeechapi/server/webui/app.js`

- [ ] **Step 1: 修改 HTML TTS 表单**

在 `openspeechapi/server/webui/index.html` 的 TTS 表单中，在 Provider 和 Text 之间添加 Voice 和 Speed 控件：

将原来的 `<form id="tts-form">` 替换为：

```html
<form id="tts-form" class="panel">
  <h3>TTS Test</h3>
  <label>Provider
    <select id="tts-provider"></select>
  </label>
  <label id="tts-voice-label">Voice
    <select id="tts-voice"></select>
  </label>
  <label>Speed
    <input id="tts-speed" type="number" min="0.5" max="2.0" step="0.1" value="1.0" />
  </label>
  <label>Text
    <textarea id="tts-text" rows="4" required>Hello from OpenSpeechAPI web UI.</textarea>
  </label>
  <button type="submit" class="btn btn-primary">Run TTS</button>
  <audio id="tts-audio" controls></audio>
  <pre id="tts-result" class="result"></pre>
</form>
```

- [ ] **Step 2: 添加 voice 加载逻辑到 app.js**

在 `openspeechapi/server/webui/app.js` 中添加 `loadTTSVoices` 函数（在 `renderProviders` 函数之后）：

```javascript
async function loadTTSVoices(provider) {
  const voiceSelect = $("tts-voice");
  const voiceLabel = $("tts-voice-label");
  voiceSelect.innerHTML = "";

  if (!provider) {
    voiceLabel.classList.add("hidden");
    return;
  }

  try {
    const data = await fetchJson(`/v1/tts/${provider}/voices`);
    const voices = data.voices || [];

    if (voices.length === 0) {
      voiceLabel.classList.add("hidden");
      return;
    }

    voiceLabel.classList.remove("hidden");

    // Group voices by group name
    const groups = {};
    for (const v of voices) {
      const group = v.group || v.language || "Other";
      if (!groups[group]) groups[group] = [];
      groups[group].push(v);
    }

    // Sort groups: Chinese first, then English, then alphabetical
    const sortedKeys = Object.keys(groups).sort((a, b) => {
      if (a === "中文") return -1;
      if (b === "中文") return 1;
      if (a === "English") return -1;
      if (b === "English") return 1;
      return a.localeCompare(b);
    });

    for (const group of sortedKeys) {
      const optgroup = document.createElement("optgroup");
      optgroup.label = group;
      for (const v of groups[group]) {
        const option = document.createElement("option");
        option.value = v.name;
        option.textContent = v.name;
        if (v.description) option.title = v.description;
        optgroup.appendChild(option);
      }
      voiceSelect.appendChild(optgroup);
    }
  } catch (err) {
    voiceLabel.classList.add("hidden");
  }
}
```

- [ ] **Step 3: 修改 renderProviders，在 TTS provider 切换时加载 voices**

在 `renderProviders` 函数末尾（`pickDefault` 调用之后），添加：

```javascript
  // Load voices for selected TTS provider
  loadTTSVoices(ttsSelect.value);
```

- [ ] **Step 4: 绑定 TTS provider change 事件**

在 `bindEvents` 函数中，`$("tts-form").addEventListener("submit", runTTS);` 之前添加：

```javascript
  $("tts-provider").addEventListener("change", () => {
    loadTTSVoices($("tts-provider").value);
  });
```

- [ ] **Step 5: 修改 runTTS 函数传递 voice 和 speed 参数**

在 `runTTS` 函数中，修改 fetch 请求体：

将：
```javascript
body: JSON.stringify({ provider, text }),
```

替换为：
```javascript
body: JSON.stringify({
  provider,
  text,
  voice: $("tts-voice").value || null,
  speed: parseFloat($("tts-speed").value) || 1.0,
}),
```

- [ ] **Step 6: 在 styles.css 中添加 hidden 类（如果不存在）**

检查 `styles.css` 是否有 `.hidden` 类。在 `app.js` 中搜索已有用法确认存在。如果不存在则添加：

```css
.hidden {
  display: none !important;
}
```

- [ ] **Step 7: Commit**

```bash
git add openspeechapi/server/webui/index.html openspeechapi/server/webui/app.js openspeechapi/server/webui/styles.css
git commit -m "feat: add Voice (grouped by language) and Speed controls to WebUI TTS form"
```

---

### Task 9: providers.yaml 配置更新

**Files:**
- Modify: `providers.yaml`

- [ ] **Step 1: 添加 macOS provider 配置**

在 `providers.yaml` 的 `# ---- Local TTS ----` 部分之后添加：

```yaml
  # ---- macOS Native ----
  macos_tts:
    provider: macos-say
    exec_mode: in_process
    settings:
      default_voice: Ting-Ting
      default_rate: 200

  macos_stt:
    provider: macos-stt
    exec_mode: in_process
    settings:
      language: zh-CN
```

- [ ] **Step 2: Commit**

```bash
git add providers.yaml
git commit -m "feat: add macOS native TTS/STT provider configuration"
```

---

### Task 10: 全量测试验证

**Files:** (no new files)

- [ ] **Step 1: 运行全部单元测试**

Run: `python -m pytest tests/unit/ -v --tb=short`
Expected: ALL PASS

- [ ] **Step 2: 运行集成测试**

Run: `python -m pytest tests/integration/ -v --tb=short`
Expected: ALL PASS (or skip if deps missing)

- [ ] **Step 3: 验证配置加载**

Run: `python -m openspeechapi --config providers.yaml check`
Expected: Config OK

- [ ] **Step 4: Final commit（如果有修复）**

如果前面步骤中有测试失败并修复，进行最终提交。
