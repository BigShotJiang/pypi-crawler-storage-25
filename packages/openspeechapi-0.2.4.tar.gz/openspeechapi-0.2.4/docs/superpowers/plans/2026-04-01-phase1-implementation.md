# OpenSpeechAPI Phase 1 Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the OpenSpeechAPI core library — a unified speech interface with provider abstractions, multi-mode execution, concurrent dispatch, result filtering, and observability.

**Architecture:** Three-layer design (L1 Provider Interface → L2 Dispatch & Execution → Observability). ServiceDispatcher is the single entry point. Providers return plain dataclasses. Configuration-driven execution mode selection. Observer pattern for non-intrusive observability.

**Tech Stack:** Python 3.11+, pydantic (config validation), pyyaml, msgpack (IPC serialization), loguru (logging), pytest + pytest-asyncio (testing)

**Spec:** `docs/superpowers/specs/2026-04-01-openspeechapi-api-design.md`

---

## File Structure

```
openspeechapi/
├── __init__.py                  # Top-level exports
├── __main__.py                  # python -m openspeechapi support
├── core/
│   ├── __init__.py
│   ├── models.py                # AudioData, Transcription, AudioChunk, Word, STTOptions, TTSOptions
│   ├── enums.py                 # ProviderType, ExecMode, AudioFormat, Capability
│   ├── base.py                  # SpeechProvider, STTProvider, TTSProvider ABCs (with settings_cls attribute)
│   ├── settings.py              # BaseSettings base class
│   └── registry.py              # ProviderRegistry
├── config.py                    # YAML config loading, env var interpolation
├── exceptions.py                # All project exceptions
├── dispatch/
│   ├── __init__.py
│   ├── context.py               # InvokeContext
│   ├── executors/
│   │   ├── __init__.py
│   │   ├── base.py              # Executor ABC
│   │   ├── in_process.py        # InProcessExecutor
│   │   ├── subprocess_exec.py   # SubprocessExecutor + worker
│   │   └── remote.py            # RemoteExecutor
│   ├── dispatcher.py            # ServiceDispatcher
│   ├── fanout.py                # FanOut/FanIn + MergeStrategies
│   └── filters.py               # ResultFilter chain + built-in filters
├── observe/
│   ├── __init__.py
│   ├── base.py                  # DispatchObserver ABC + ObserverManager
│   ├── metrics.py               # MetricsObserver
│   ├── latency.py               # LatencyObserver
│   ├── debug.py                 # DebugLogObserver
│   ├── tracing.py               # TracingObserver (OpenTelemetry)
│   └── usage.py                 # UsageObserver
├── providers/
│   ├── __init__.py
│   ├── _template.py             # New adapter template
│   ├── stt/
│   │   ├── __init__.py
│   │   ├── faster_whisper.py
│   │   ├── whisper.py
│   │   ├── deepgram.py
│   │   └── openai.py
│   └── tts/
│       ├── __init__.py
│       ├── fish_speech.py
│       ├── piper.py
│       ├── coqui.py
│       ├── cosyvoice.py
│       ├── elevenlabs.py
│       ├── openai.py
│       └── minimax.py
└── cli.py                       # CLI entry point

tests/
├── __init__.py
├── conftest.py                  # Shared fixtures: FakeSTT, FakeTTS providers
├── unit/
│   ├── __init__.py
│   ├── test_models.py
│   ├── test_enums.py
│   ├── test_base.py
│   ├── test_registry.py
│   ├── test_config.py
│   ├── test_exceptions.py
│   ├── test_context.py
│   ├── test_executor_base.py
│   ├── test_in_process.py
│   ├── test_subprocess.py
│   ├── test_remote.py
│   ├── test_dispatcher.py
│   ├── test_fanout.py
│   ├── test_filters.py
│   ├── test_observer_base.py
│   ├── test_metrics_observer.py
│   ├── test_latency_observer.py
│   ├── test_debug_observer.py
│   ├── test_usage_observer.py
│   ├── test_latency_observer.py
│   ├── test_debug_observer.py
│   └── test_cli.py
└── integration/
    ├── __init__.py
    ├── test_in_process_integration.py
    ├── test_subprocess_integration.py
    └── test_fanout_integration.py

pyproject.toml
providers.example.yaml
```

---

## Chunk 1: Project Scaffolding + L1 Core Models

### Task 1: Project scaffolding

**Files:**
- Create: `pyproject.toml`
- Create: `openspeechapi/__init__.py`
- Create: `openspeechapi/core/__init__.py`
- Create: `openspeechapi/exceptions.py`
- Create: `tests/conftest.py`

- [ ] **Step 1: Create pyproject.toml with core dependencies and extras**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "openspeechapi"
version = "0.1.0"
description = "Unified speech interface for STT/TTS providers"
requires-python = ">=3.11"
dependencies = [
    "pydantic>=2.0",
    "pyyaml>=6.0",
    "msgpack>=1.0",
    "loguru>=0.7",
]

[project.optional-dependencies]
faster-whisper = ["faster-whisper"]
elevenlabs = ["elevenlabs"]
deepgram = ["deepgram-sdk"]
openai = ["openai"]
fish-speech = ["httpx"]
piper = ["piper-tts"]
coqui = ["httpx"]
cosyvoice = ["httpx"]
minimax = ["httpx"]
tracing = ["opentelemetry-api", "opentelemetry-sdk"]
server = ["fastapi", "uvicorn", "websockets"]
dev = ["pytest>=8.0", "pytest-asyncio>=0.24", "pytest-cov", "ruff"]

[project.scripts]
openspeechapi = "openspeechapi.cli:main"

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]

[tool.ruff]
target-version = "py311"
line-length = 100
```

- [ ] **Step 2: Create openspeechapi/__init__.py with version**

```python
"""OpenSpeechAPI — Unified speech interface for STT/TTS providers."""

__version__ = "0.1.0"
```

- [ ] **Step 3: Create openspeechapi/core/__init__.py (empty)**

```python
```

- [ ] **Step 4: Create openspeechapi/exceptions.py with base exceptions**

```python
"""OpenSpeechAPI exception hierarchy."""


class OpenSpeechError(Exception):
    """Base exception for all OpenSpeechAPI errors."""


class ProviderError(OpenSpeechError):
    """Error from a provider invocation."""

    def __init__(self, provider_name: str, original_type: str, message: str) -> None:
        self.provider_name = provider_name
        self.original_type = original_type
        super().__init__(f"[{provider_name}] {original_type}: {message}")


class ProviderCrashedError(OpenSpeechError):
    """Provider subprocess crashed during invocation."""

    def __init__(self, provider_name: str) -> None:
        self.provider_name = provider_name
        super().__init__(f"Provider '{provider_name}' crashed during invocation")


class ProviderUnavailableError(OpenSpeechError):
    """Provider exhausted restart attempts and is unavailable."""

    def __init__(self, provider_name: str) -> None:
        self.provider_name = provider_name
        super().__init__(f"Provider '{provider_name}' is unavailable (max restarts exhausted)")


class ConfigError(OpenSpeechError):
    """Configuration loading or validation error."""


class FanOutAllFailedError(OpenSpeechError):
    """All providers in a fanout invocation failed."""

    def __init__(self, errors: dict[str, Exception]) -> None:
        self.errors = errors
        names = ", ".join(errors.keys())
        super().__init__(f"All fanout providers failed: {names}")


class ProviderNotFoundError(OpenSpeechError):
    """Provider not found in registry or dispatcher."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Provider '{name}' not found")
```

- [ ] **Step 5: Create tests/__init__.py, tests/unit/__init__.py, tests/integration/__init__.py**

```python
# Empty __init__.py files for test package discovery
```

- [ ] **Step 6: Create tests/conftest.py (empty for now, fixtures added later)**

```python
"""Shared test fixtures for OpenSpeechAPI tests."""
```

- [ ] **Step 7: Create openspeechapi/__main__.py**

```python
"""Allow running as python -m openspeechapi."""
from openspeechapi.cli import main

if __name__ == "__main__":
    main()
```

- [ ] **Step 8: Install project in dev mode and verify**

Run: `cd /Users/hjma/workspace/AI/Practics/OpenSpeechAPI && pip install -e ".[dev]"`
Expected: Successful installation

- [ ] **Step 9: Commit**

```bash
git add pyproject.toml openspeechapi/ tests/
git commit -m "feat: project scaffolding with core deps and exception hierarchy"
```

---

### Task 2: Core enums

**Files:**
- Create: `openspeechapi/core/enums.py`
- Create: `tests/unit/test_enums.py`

- [ ] **Step 1: Write failing tests for enums**

```python
# tests/unit/test_enums.py
"""Tests for core enums."""
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType


def test_provider_type_values():
    assert ProviderType.STT.value == "stt"
    assert ProviderType.TTS.value == "tts"
    assert ProviderType.BOTH.value == "both"


def test_exec_mode_values():
    assert ExecMode.IN_PROCESS.value == "in_process"
    assert ExecMode.SUBPROCESS.value == "subprocess"
    assert ExecMode.REMOTE.value == "remote"


def test_audio_format_values():
    assert AudioFormat.PCM_16K is not None
    assert AudioFormat.WAV is not None
    assert AudioFormat.MP3 is not None
    assert AudioFormat.OGG is not None


def test_capability_values():
    caps = {Capability.STREAMING, Capability.BATCH, Capability.MULTILINGUAL}
    assert len(caps) == 3


def test_capability_has_expected_members():
    expected = {"STREAMING", "BATCH", "MULTILINGUAL", "VOICE_CLONE", "EMOTION", "WORD_TIMESTAMPS"}
    actual = {c.name for c in Capability}
    assert expected.issubset(actual)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_enums.py -v`
Expected: FAIL — ModuleNotFoundError

- [ ] **Step 3: Implement enums**

```python
# openspeechapi/core/enums.py
"""Core enumerations for OpenSpeechAPI."""
from enum import Enum


class ProviderType(str, Enum):
    STT = "stt"
    TTS = "tts"
    BOTH = "both"


class ExecMode(str, Enum):
    IN_PROCESS = "in_process"
    SUBPROCESS = "subprocess"
    REMOTE = "remote"


class AudioFormat(str, Enum):
    PCM_16K = "pcm_16k"
    PCM_44K = "pcm_44k"
    WAV = "wav"
    MP3 = "mp3"
    OGG = "ogg"
    FLAC = "flac"
    OPUS = "opus"


class Capability(str, Enum):
    STREAMING = "streaming"
    BATCH = "batch"
    MULTILINGUAL = "multilingual"
    VOICE_CLONE = "voice_clone"
    EMOTION = "emotion"
    WORD_TIMESTAMPS = "word_timestamps"
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_enums.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/core/enums.py tests/unit/test_enums.py
git commit -m "feat: core enums — ProviderType, ExecMode, AudioFormat, Capability"
```

---

### Task 3: Core data models

**Files:**
- Create: `openspeechapi/core/models.py`
- Create: `tests/unit/test_models.py`

- [ ] **Step 1: Write failing tests for data models**

```python
# tests/unit/test_models.py
"""Tests for core data models."""
from dataclasses import FrozenInstanceError

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import (
    AudioChunk,
    AudioData,
    STTOptions,
    TTSOptions,
    Transcription,
    Word,
)


class TestAudioData:
    def test_create_with_required_fields(self):
        audio = AudioData(data=b"raw", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        assert audio.data == b"raw"
        assert audio.sample_rate == 16000
        assert audio.channels == 1
        assert audio.format == AudioFormat.PCM_16K
        assert audio.duration_ms is None

    def test_create_with_duration(self):
        audio = AudioData(
            data=b"raw", sample_rate=16000, channels=1,
            format=AudioFormat.WAV, duration_ms=1500,
        )
        assert audio.duration_ms == 1500


class TestTranscription:
    def test_create_minimal(self):
        t = Transcription(text="hello")
        assert t.text == "hello"
        assert t.language is None
        assert t.confidence is None
        assert t.words is None
        assert t.duration_ms is None

    def test_create_full(self):
        words = [Word(text="hello", start_ms=0, end_ms=500, confidence=0.99)]
        t = Transcription(
            text="hello", language="en", confidence=0.95,
            words=words, duration_ms=500,
        )
        assert t.language == "en"
        assert len(t.words) == 1
        assert t.words[0].text == "hello"


class TestWord:
    def test_create(self):
        w = Word(text="hi", start_ms=0, end_ms=200, confidence=0.9)
        assert w.text == "hi"
        assert w.start_ms == 0
        assert w.end_ms == 200


class TestSTTOptions:
    def test_defaults(self):
        opts = STTOptions()
        assert opts.language is None
        assert opts.prompt is None
        assert opts.temperature is None

    def test_custom(self):
        opts = STTOptions(language="zh", temperature=0.2)
        assert opts.language == "zh"
        assert opts.temperature == 0.2


class TestTTSOptions:
    def test_defaults(self):
        opts = TTSOptions()
        assert opts.voice is None
        assert opts.speed == 1.0
        assert opts.output_format == AudioFormat.PCM_16K

    def test_custom(self):
        opts = TTSOptions(voice="Rachel", speed=1.5, output_format=AudioFormat.MP3)
        assert opts.voice == "Rachel"
        assert opts.speed == 1.5


class TestAudioChunk:
    def test_create(self):
        chunk = AudioChunk(data=b"chunk", sequence=0)
        assert chunk.data == b"chunk"
        assert chunk.sequence == 0
        assert chunk.is_final is False

    def test_final_chunk(self):
        chunk = AudioChunk(data=b"", sequence=5, is_final=True)
        assert chunk.is_final is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_models.py -v`
Expected: FAIL

- [ ] **Step 3: Implement data models**

```python
# openspeechapi/core/models.py
"""Core data models — plain dataclasses for data transfer."""
from __future__ import annotations

from dataclasses import dataclass, field

from openspeechapi.core.enums import AudioFormat


@dataclass
class AudioData:
    data: bytes
    sample_rate: int
    channels: int
    format: AudioFormat
    duration_ms: int | None = None


@dataclass
class Word:
    text: str
    start_ms: int
    end_ms: int
    confidence: float | None = None


@dataclass
class Transcription:
    text: str
    language: str | None = None
    confidence: float | None = None
    words: list[Word] | None = None
    duration_ms: int | None = None


@dataclass
class AudioChunk:
    data: bytes
    sequence: int
    is_final: bool = False


@dataclass
class STTOptions:
    language: str | None = None
    prompt: str | None = None
    temperature: float | None = None


@dataclass
class TTSOptions:
    voice: str | None = None
    speed: float = 1.0
    output_format: AudioFormat = AudioFormat.PCM_16K
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_models.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/core/models.py tests/unit/test_models.py
git commit -m "feat: core data models — AudioData, Transcription, Word, Options"
```

---

### Task 4: Provider base classes

**Files:**
- Create: `openspeechapi/core/settings.py`
- Create: `openspeechapi/core/base.py`
- Create: `tests/unit/test_base.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_base.py
"""Tests for provider base classes."""
from dataclasses import dataclass

import pytest

from openspeechapi.core.base import SpeechProvider, STTProvider, TTSProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType, AudioFormat
from openspeechapi.core.models import AudioData, STTOptions, TTSOptions, Transcription
from openspeechapi.core.settings import BaseSettings


@dataclass
class FakeSTTSettings(BaseSettings):
    model_size: str = "tiny"


class FakeSTT(STTProvider):
    name = "fake-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    capabilities = {Capability.BATCH}

    def __init__(self, settings: FakeSTTSettings | None = None):
        self.settings = settings or FakeSTTSettings()

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    async def health_check(self) -> bool:
        return True

    async def transcribe(self, audio: AudioData, opts: STTOptions | None = None) -> Transcription:
        return Transcription(text="fake")

    async def transcribe_stream(self, stream):
        yield Transcription(text="chunk")


class TestSTTProvider:
    @pytest.mark.asyncio
    async def test_transcribe(self):
        stt = FakeSTT()
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await stt.transcribe(audio)
        assert result.text == "fake"

    def test_attributes(self):
        stt = FakeSTT()
        assert stt.name == "fake-stt"
        assert stt.provider_type == ProviderType.STT
        assert Capability.BATCH in stt.capabilities

    @pytest.mark.asyncio
    async def test_lifecycle(self):
        stt = FakeSTT()
        await stt.start()
        assert await stt.health_check() is True
        await stt.stop()


class TestBaseSettings:
    def test_is_dataclass(self):
        s = FakeSTTSettings(model_size="large")
        assert s.model_size == "large"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_base.py -v`
Expected: FAIL

- [ ] **Step 3: Implement BaseSettings**

```python
# openspeechapi/core/settings.py
"""Base settings for provider configuration."""
from dataclasses import dataclass


@dataclass
class BaseSettings:
    """Base class for provider-specific settings. Subclass as a dataclass."""
    pass
```

- [ ] **Step 4: Implement provider ABCs**

```python
# openspeechapi/core/base.py
"""Provider abstract base classes."""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, STTOptions, TTSOptions, Transcription
from openspeechapi.core.settings import BaseSettings


class SpeechProvider(ABC):
    """Base class for all speech providers."""

    name: str
    provider_type: ProviderType
    execution_mode: ExecMode
    settings: BaseSettings
    settings_cls: type[BaseSettings] = BaseSettings  # Override in subclass
    capabilities: set[Capability]

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def stop(self) -> None: ...

    @abstractmethod
    async def health_check(self) -> bool: ...


class STTProvider(SpeechProvider):
    """Base class for speech-to-text providers."""

    @abstractmethod
    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription: ...

    @abstractmethod
    def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]: ...


class TTSProvider(SpeechProvider):
    """Base class for text-to-speech providers."""

    @abstractmethod
    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData: ...

    @abstractmethod
    def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]: ...
```

- [ ] **Step 5: Run test to verify it passes**

Run: `pytest tests/unit/test_base.py -v`
Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add openspeechapi/core/settings.py openspeechapi/core/base.py tests/unit/test_base.py
git commit -m "feat: provider ABCs — SpeechProvider, STTProvider, TTSProvider"
```

---

### Task 5: Provider registry

**Files:**
- Create: `openspeechapi/core/registry.py`
- Create: `tests/unit/test_registry.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_registry.py
"""Tests for provider registry."""
import pytest

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.exceptions import ProviderNotFoundError


class FakeProviderCls:
    name = "fake-stt"
    provider_type = ProviderType.STT
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}


class FakeTTSCls:
    name = "fake-tts"
    provider_type = ProviderType.TTS
    capabilities = {Capability.STREAMING}


class TestProviderRegistry:
    def setup_method(self):
        self.registry = ProviderRegistry()

    def test_register_and_get(self):
        self.registry.register("fake-stt", FakeProviderCls)
        assert self.registry.get("fake-stt") is FakeProviderCls

    def test_get_not_found_raises(self):
        with pytest.raises(ProviderNotFoundError):
            self.registry.get("nonexistent")

    def test_lookup_by_type(self):
        self.registry.register("fake-stt", FakeProviderCls)
        self.registry.register("fake-tts", FakeTTSCls)
        stt_providers = self.registry.find_by_type(ProviderType.STT)
        assert len(stt_providers) == 1
        assert stt_providers[0][0] == "fake-stt"

    def test_lookup_by_capability(self):
        self.registry.register("fake-stt", FakeProviderCls)
        self.registry.register("fake-tts", FakeTTSCls)
        streaming = self.registry.find_by_capability(Capability.STREAMING)
        assert len(streaming) == 1
        assert streaming[0][0] == "fake-tts"

    def test_list_all(self):
        self.registry.register("a", FakeProviderCls)
        self.registry.register("b", FakeTTSCls)
        assert len(self.registry.list_all()) == 2

    def test_duplicate_register_overwrites(self):
        self.registry.register("fake-stt", FakeProviderCls)
        self.registry.register("fake-stt", FakeTTSCls)
        assert self.registry.get("fake-stt") is FakeTTSCls
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_registry.py -v`
Expected: FAIL

- [ ] **Step 3: Implement registry**

```python
# openspeechapi/core/registry.py
"""Provider registry — lookup by name, type, or capability."""
from __future__ import annotations

from typing import Any

from openspeechapi.core.enums import Capability, ProviderType
from openspeechapi.exceptions import ProviderNotFoundError


class ProviderRegistry:
    """Registry for provider classes. Lookup by name, type, or capability."""

    def __init__(self) -> None:
        self._providers: dict[str, Any] = {}

    def register(self, name: str, provider_cls: Any) -> None:
        self._providers[name] = provider_cls

    def get(self, name: str) -> Any:
        if name not in self._providers:
            raise ProviderNotFoundError(name)
        return self._providers[name]

    def find_by_type(self, provider_type: ProviderType) -> list[tuple[str, Any]]:
        return [
            (name, cls) for name, cls in self._providers.items()
            if getattr(cls, "provider_type", None) == provider_type
        ]

    def find_by_capability(self, capability: Capability) -> list[tuple[str, Any]]:
        return [
            (name, cls) for name, cls in self._providers.items()
            if capability in getattr(cls, "capabilities", set())
        ]

    def list_all(self) -> list[tuple[str, Any]]:
        return list(self._providers.items())
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_registry.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/core/registry.py tests/unit/test_registry.py
git commit -m "feat: provider registry with name/type/capability lookup"
```

---

## Chunk 2: Configuration + InvokeContext

### Task 6: YAML config loading with env var interpolation

**Files:**
- Create: `openspeechapi/config.py`
- Create: `tests/unit/test_config.py`
- Create: `providers.example.yaml`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_config.py
"""Tests for YAML config loading."""
import os
from pathlib import Path
from textwrap import dedent

import pytest

from openspeechapi.config import load_config, interpolate_env, ProviderConfig, OpenSpeechConfig
from openspeechapi.exceptions import ConfigError


class TestInterpolateEnv:
    def test_simple_interpolation(self, monkeypatch):
        monkeypatch.setenv("MY_KEY", "secret123")
        assert interpolate_env("${MY_KEY}") == "secret123"

    def test_missing_var_raises(self):
        with pytest.raises(ConfigError, match="MY_MISSING"):
            interpolate_env("${MY_MISSING}")

    def test_escaped_dollar(self):
        assert interpolate_env("$$literal") == "$literal"

    def test_no_interpolation_needed(self):
        assert interpolate_env("plain_value") == "plain_value"

    def test_mixed_text_and_var(self, monkeypatch):
        monkeypatch.setenv("HOST", "localhost")
        assert interpolate_env("http://${HOST}:8080") == "http://localhost:8080"


class TestLoadConfig:
    def test_load_minimal_config(self, tmp_path):
        cfg_file = tmp_path / "providers.yaml"
        cfg_file.write_text(dedent("""\
            providers:
              fake-stt:
                provider: fake
                exec_mode: in_process
                settings:
                  model: tiny
        """))
        config = load_config(cfg_file)
        assert "fake-stt" in config.providers
        p = config.providers["fake-stt"]
        assert p.provider == "fake"
        assert p.exec_mode == "in_process"
        assert p.settings["model"] == "tiny"

    def test_load_with_env_var(self, tmp_path, monkeypatch):
        monkeypatch.setenv("API_KEY", "sk-test")
        cfg_file = tmp_path / "providers.yaml"
        cfg_file.write_text(dedent("""\
            providers:
              cloud:
                provider: openai
                exec_mode: in_process
                settings:
                  api_key: ${API_KEY}
        """))
        config = load_config(cfg_file)
        assert config.providers["cloud"].settings["api_key"] == "sk-test"

    def test_missing_file_raises(self):
        with pytest.raises(ConfigError, match="not found"):
            load_config(Path("/nonexistent/providers.yaml"))

    def test_load_with_filters(self, tmp_path):
        cfg_file = tmp_path / "providers.yaml"
        cfg_file.write_text(dedent("""\
            providers:
              stt-1:
                provider: fake
                exec_mode: in_process
                settings: {}
                filters:
                  - type: confidence
                    min: 0.8
        """))
        config = load_config(cfg_file)
        assert len(config.providers["stt-1"].filters) == 1
        assert config.providers["stt-1"].filters[0]["type"] == "confidence"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_config.py -v`
Expected: FAIL

- [ ] **Step 3: Implement config loading**

```python
# openspeechapi/config.py
"""YAML configuration loading with environment variable interpolation."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from openspeechapi.exceptions import ConfigError

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def interpolate_env(value: str) -> str:
    """Interpolate ${VAR} references in a string. $$ escapes to literal $."""
    if "$$" in value:
        value = value.replace("$$", "\x00")

    def _replace(match: re.Match) -> str:
        var_name = match.group(1)
        val = os.environ.get(var_name)
        if val is None:
            raise ConfigError(f"Environment variable '{var_name}' not set")
        return val

    result = _ENV_PATTERN.sub(_replace, value)
    return result.replace("\x00", "$")


def _interpolate_recursive(obj: Any) -> Any:
    if isinstance(obj, str):
        return interpolate_env(obj)
    if isinstance(obj, dict):
        return {k: _interpolate_recursive(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_interpolate_recursive(item) for item in obj]
    return obj


@dataclass
class ProviderConfig:
    provider: str
    exec_mode: str
    settings: dict[str, Any] = field(default_factory=dict)
    filters: list[dict[str, Any]] = field(default_factory=list)
    endpoint: str | None = None


@dataclass
class OpenSpeechConfig:
    providers: dict[str, ProviderConfig]


def load_config(path: Path) -> OpenSpeechConfig:
    """Load and validate providers.yaml configuration."""
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")

    with open(path) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict) or "providers" not in raw:
        raise ConfigError("Config must contain a 'providers' key")

    raw = _interpolate_recursive(raw)

    providers = {}
    for name, spec in raw["providers"].items():
        providers[name] = ProviderConfig(
            provider=spec["provider"],
            exec_mode=spec["exec_mode"],
            settings=spec.get("settings", {}),
            filters=spec.get("filters", []),
            endpoint=spec.get("endpoint"),
        )

    return OpenSpeechConfig(providers=providers)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_config.py -v`
Expected: All PASS

- [ ] **Step 5: Create providers.example.yaml**

```yaml
# providers.example.yaml — Example configuration
providers:
  faster-whisper-local:
    provider: faster-whisper
    exec_mode: subprocess
    settings:
      model_size: large-v3
      device: cuda

  elevenlabs:
    provider: elevenlabs
    exec_mode: in_process
    settings:
      api_key: ${ELEVENLABS_API_KEY}
      voice_id: Rachel

  whisper-server:
    provider: faster-whisper
    exec_mode: remote
    endpoint: http://gpu-server:8080
    settings: {}
```

- [ ] **Step 6: Commit**

```bash
git add openspeechapi/config.py tests/unit/test_config.py providers.example.yaml
git commit -m "feat: YAML config loading with env var interpolation"
```

---

### Task 7: InvokeContext

**Files:**
- Create: `openspeechapi/dispatch/__init__.py`
- Create: `openspeechapi/dispatch/context.py`
- Create: `tests/unit/test_context.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_context.py
"""Tests for InvokeContext."""
import time

from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext


class TestInvokeContext:
    def test_create_minimal(self):
        ctx = InvokeContext(
            provider_name="test",
            method="transcribe",
            exec_mode=ExecMode.IN_PROCESS,
        )
        assert ctx.request_id  # auto-generated
        assert ctx.provider_name == "test"
        assert ctx.method == "transcribe"
        assert ctx.start_time_ns > 0
        assert ctx.ttfb_ns is None
        assert ctx.end_time_ns is None
        assert ctx.parent_id is None

    def test_record_ttfb(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
        )
        ctx.record_ttfb()
        assert ctx.ttfb_ns is not None
        assert ctx.ttfb_ns >= ctx.start_time_ns

    def test_record_end(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
        )
        ctx.record_end()
        assert ctx.end_time_ns is not None

    def test_elapsed_ms(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
        )
        ctx.record_end()
        assert ctx.elapsed_ms >= 0

    def test_metadata(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
            metadata={"key": "value"},
        )
        assert ctx.metadata["key"] == "value"

    def test_parent_id_for_fanout(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
            parent_id="parent-123",
        )
        assert ctx.parent_id == "parent-123"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_context.py -v`
Expected: FAIL

- [ ] **Step 3: Implement InvokeContext**

```python
# openspeechapi/dispatch/__init__.py
```

```python
# openspeechapi/dispatch/context.py
"""InvokeContext — request-scoped metadata for invocation lifecycle."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from openspeechapi.core.enums import ExecMode


@dataclass
class InvokeContext:
    provider_name: str
    method: str
    exec_mode: ExecMode
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    start_time_ns: int = field(default_factory=time.time_ns)
    ttfb_ns: int | None = None
    end_time_ns: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    parent_id: str | None = None

    def record_ttfb(self) -> None:
        if self.ttfb_ns is None:
            self.ttfb_ns = time.time_ns()

    def record_end(self) -> None:
        self.end_time_ns = time.time_ns()

    @property
    def elapsed_ms(self) -> float:
        end = self.end_time_ns or time.time_ns()
        return (end - self.start_time_ns) / 1_000_000
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_context.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/dispatch/ tests/unit/test_context.py
git commit -m "feat: InvokeContext with request lifecycle tracking"
```

---

## Chunk 3: Executors

### Task 8: Executor ABC

**Files:**
- Create: `openspeechapi/dispatch/executors/__init__.py`
- Create: `openspeechapi/dispatch/executors/base.py`
- Create: `tests/unit/test_executor_base.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_executor_base.py
"""Tests for Executor ABC."""
import pytest

from openspeechapi.dispatch.executors.base import Executor


class TestExecutorABC:
    def test_cannot_instantiate(self):
        with pytest.raises(TypeError):
            Executor()

    def test_has_required_methods(self):
        methods = {"start", "stop", "invoke", "invoke_stream", "health_check"}
        abc_methods = {m for m in dir(Executor) if not m.startswith("_")}
        assert methods.issubset(abc_methods)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_executor_base.py -v`
Expected: FAIL

- [ ] **Step 3: Implement Executor ABC**

```python
# openspeechapi/dispatch/executors/__init__.py
```

```python
# openspeechapi/dispatch/executors/base.py
"""Executor abstract base class."""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

from openspeechapi.core.base import SpeechProvider
from openspeechapi.core.settings import BaseSettings


class Executor(ABC):
    """Abstract executor — runs provider methods in a specific execution mode."""

    @abstractmethod
    async def start(
        self, provider_cls: type[SpeechProvider], settings: BaseSettings
    ) -> None: ...

    @abstractmethod
    async def stop(self) -> None: ...

    @abstractmethod
    async def invoke(self, method: str, **kwargs: Any) -> Any: ...

    @abstractmethod
    async def invoke_stream(self, method: str, **kwargs: Any) -> AsyncIterator[Any]: ...

    @abstractmethod
    async def health_check(self) -> bool: ...
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_executor_base.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/dispatch/executors/ tests/unit/test_executor_base.py
git commit -m "feat: Executor ABC with start/stop/invoke/stream/health"
```

---

### Task 9: InProcessExecutor

**Files:**
- Create: `openspeechapi/dispatch/executors/in_process.py`
- Create: `tests/unit/test_in_process.py`
- Modify: `tests/conftest.py` (add shared fake providers)

- [ ] **Step 1: Add shared fake providers to conftest**

```python
# tests/conftest.py
"""Shared test fixtures for OpenSpeechAPI tests."""
from __future__ import annotations

from dataclasses import dataclass

import pytest

from openspeechapi.core.base import STTProvider, TTSProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, STTOptions, TTSOptions, Transcription
from openspeechapi.core.settings import BaseSettings


@dataclass
class FakeSTTSettings(BaseSettings):
    model_size: str = "tiny"
    fail: bool = False


class FakeSTT(STTProvider):
    name = "fake-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = FakeSTTSettings
    capabilities = {Capability.BATCH}

    def __init__(self, settings: FakeSTTSettings | None = None):
        self.settings = settings or FakeSTTSettings()
        self._started = False

    async def start(self) -> None:
        self._started = True

    async def stop(self) -> None:
        self._started = False

    async def health_check(self) -> bool:
        return self._started

    async def transcribe(self, audio: AudioData, opts: STTOptions | None = None) -> Transcription:
        if self.settings.fail:
            raise RuntimeError("Fake STT error")
        return Transcription(text="fake transcription", confidence=0.95, language="en")

    async def transcribe_stream(self, stream):
        yield Transcription(text="chunk1")
        yield Transcription(text="chunk2")


@dataclass
class FakeTTSSettings(BaseSettings):
    voice: str = "default"


class FakeTTS(TTSProvider):
    name = "fake-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = FakeTTSSettings
    capabilities = {Capability.STREAMING}

    def __init__(self, settings: FakeTTSSettings | None = None):
        self.settings = settings or FakeTTSSettings()
        self._started = False

    async def start(self) -> None:
        self._started = True

    async def stop(self) -> None:
        self._started = False

    async def health_check(self) -> bool:
        return self._started

    async def synthesize(self, text: str, opts: TTSOptions | None = None) -> AudioData:
        return AudioData(
            data=b"fake_audio", sample_rate=16000, channels=1,
            format=AudioFormat.PCM_16K, duration_ms=100,
        )

    async def synthesize_stream(self, text: str, opts: TTSOptions | None = None):
        yield AudioChunk(data=b"chunk1", sequence=0)
        yield AudioChunk(data=b"chunk2", sequence=1, is_final=True)
```

- [ ] **Step 2: Write failing tests for InProcessExecutor**

```python
# tests/unit/test_in_process.py
"""Tests for InProcessExecutor."""
import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.dispatch.executors.in_process import InProcessExecutor
from tests.conftest import FakeSTT, FakeSTTSettings


class TestInProcessExecutor:
    @pytest.mark.asyncio
    async def test_start_and_invoke(self):
        executor = InProcessExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await executor.invoke("transcribe", audio=audio)
        assert isinstance(result, Transcription)
        assert result.text == "fake transcription"
        await executor.stop()

    @pytest.mark.asyncio
    async def test_health_check(self):
        executor = InProcessExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        assert await executor.health_check() is True
        await executor.stop()

    @pytest.mark.asyncio
    async def test_invoke_stream(self):
        executor = InProcessExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        chunks = []
        async for chunk in executor.invoke_stream("transcribe_stream", stream=iter([])):
            chunks.append(chunk)
        assert len(chunks) == 2
        await executor.stop()

    @pytest.mark.asyncio
    async def test_invoke_before_start_raises(self):
        executor = InProcessExecutor()
        with pytest.raises(RuntimeError, match="not started"):
            await executor.invoke("transcribe")

    @pytest.mark.asyncio
    async def test_provider_error_propagates(self):
        executor = InProcessExecutor()
        await executor.start(FakeSTT, FakeSTTSettings(fail=True))
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        with pytest.raises(RuntimeError, match="Fake STT error"):
            await executor.invoke("transcribe", audio=audio)
        await executor.stop()
```

- [ ] **Step 3: Run test to verify it fails**

Run: `pytest tests/unit/test_in_process.py -v`
Expected: FAIL

- [ ] **Step 4: Implement InProcessExecutor**

```python
# openspeechapi/dispatch/executors/in_process.py
"""InProcessExecutor — runs provider directly in the main process."""
from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from openspeechapi.core.base import SpeechProvider
from openspeechapi.core.settings import BaseSettings
from openspeechapi.dispatch.executors.base import Executor


class InProcessExecutor(Executor):
    """Execute provider methods directly in the current process."""

    def __init__(self) -> None:
        self._provider: SpeechProvider | None = None

    async def start(
        self, provider_cls: type[SpeechProvider], settings: BaseSettings
    ) -> None:
        self._provider = provider_cls(settings=settings)
        await self._provider.start()

    async def stop(self) -> None:
        if self._provider:
            await self._provider.stop()
            self._provider = None

    async def invoke(self, method: str, **kwargs: Any) -> Any:
        if self._provider is None:
            raise RuntimeError("Executor not started")
        fn = getattr(self._provider, method)
        return await fn(**kwargs)

    async def invoke_stream(self, method: str, **kwargs: Any) -> AsyncIterator[Any]:
        if self._provider is None:
            raise RuntimeError("Executor not started")
        fn = getattr(self._provider, method)
        async for item in fn(**kwargs):
            yield item

    async def health_check(self) -> bool:
        if self._provider is None:
            return False
        return await self._provider.health_check()
```

- [ ] **Step 5: Run test to verify it passes**

Run: `pytest tests/unit/test_in_process.py -v`
Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add openspeechapi/dispatch/executors/in_process.py tests/conftest.py tests/unit/test_in_process.py
git commit -m "feat: InProcessExecutor with direct provider invocation"
```

---

### Task 10: SubprocessExecutor (IPC protocol + worker)

**Files:**
- Create: `openspeechapi/dispatch/executors/subprocess_exec.py`
- Create: `tests/unit/test_subprocess.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_subprocess.py
"""Tests for SubprocessExecutor."""
import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.dispatch.executors.subprocess_exec import SubprocessExecutor
from tests.conftest import FakeSTT, FakeSTTSettings


class TestSubprocessExecutor:
    @pytest.mark.asyncio
    async def test_start_and_invoke(self):
        executor = SubprocessExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await executor.invoke("transcribe", audio=audio)
        assert isinstance(result, Transcription)
        assert result.text == "fake transcription"
        await executor.stop()

    @pytest.mark.asyncio
    async def test_health_check(self):
        executor = SubprocessExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        assert await executor.health_check() is True
        await executor.stop()

    @pytest.mark.asyncio
    async def test_stop_cleans_up(self):
        executor = SubprocessExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        await executor.stop()
        assert await executor.health_check() is False

    @pytest.mark.asyncio
    async def test_invoke_before_start_raises(self):
        executor = SubprocessExecutor()
        with pytest.raises(RuntimeError, match="not started"):
            await executor.invoke("transcribe")

    @pytest.mark.asyncio
    async def test_restart_on_crash(self):
        executor = SubprocessExecutor(max_restarts=2, restart_delay_s=0.1)
        await executor.start(FakeSTT, FakeSTTSettings())
        # Force kill the worker
        if executor._process:
            executor._process.terminate()
            await executor._process.wait()
        # Next invoke should trigger restart
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await executor.invoke("transcribe", audio=audio)
        assert result.text == "fake transcription"
        await executor.stop()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_subprocess.py -v`
Expected: FAIL

- [ ] **Step 3: Implement SubprocessExecutor**

This is the most complex component. It uses Unix Domain Sockets + msgpack for IPC.

```python
# openspeechapi/dispatch/executors/subprocess_exec.py
"""SubprocessExecutor — runs provider in a separate process via UDS + msgpack IPC."""
from __future__ import annotations

import asyncio
import os
import pickle
import struct
import sys
import tempfile
from collections.abc import AsyncIterator
from dataclasses import asdict
from pathlib import Path
from typing import Any

import msgpack

from openspeechapi.core.base import SpeechProvider
from openspeechapi.core.settings import BaseSettings
from openspeechapi.dispatch.executors.base import Executor
from openspeechapi.exceptions import ProviderCrashedError, ProviderUnavailableError

# Message types
MSG_START = 1
MSG_INVOKE = 2
MSG_STREAM = 3
MSG_RESPONSE = 4
MSG_ERROR = 5
MSG_STREAM_CHUNK = 6
MSG_STREAM_END = 7
MSG_HEALTH = 8


def _encode_message(msg_type: int, payload: Any) -> bytes:
    """Encode a message as: [4-byte length][msgpack payload]."""
    packed = msgpack.packb({"type": msg_type, "payload": payload}, use_bin_type=True)
    return struct.pack("!I", len(packed)) + packed


async def _read_message(reader: asyncio.StreamReader) -> dict:
    """Read a length-prefixed msgpack message."""
    header = await reader.readexactly(4)
    length = struct.unpack("!I", header)[0]
    data = await reader.readexactly(length)
    return msgpack.unpackb(data, raw=False)


def _worker_main(socket_path: str, provider_cls_pickle: bytes, settings_pickle: bytes) -> None:
    """Worker process entry point. Runs an asyncio event loop serving IPC requests."""
    import asyncio

    provider_cls = pickle.loads(provider_cls_pickle)
    settings = pickle.loads(settings_pickle)

    async def _run():
        provider = provider_cls(settings=settings)
        await provider.start()

        async def handle_client(reader, writer):
            try:
                while True:
                    try:
                        msg = await _read_message(reader)
                    except (asyncio.IncompleteReadError, ConnectionError):
                        break

                    msg_type = msg["type"]
                    payload = msg["payload"]

                    if msg_type == MSG_INVOKE:
                        try:
                            method = payload["method"]
                            kwargs = payload.get("kwargs", {})
                            fn = getattr(provider, method)
                            # Reconstruct dataclass args from dicts
                            result = await fn(**_reconstruct_kwargs(kwargs))
                            result_data = _serialize_result(result)
                            writer.write(_encode_message(MSG_RESPONSE, result_data))
                        except Exception as e:
                            writer.write(_encode_message(MSG_ERROR, {
                                "error_type": type(e).__name__,
                                "message": str(e),
                            }))
                        await writer.drain()

                    elif msg_type == MSG_HEALTH:
                        try:
                            healthy = await provider.health_check()
                            writer.write(_encode_message(MSG_RESPONSE, {"healthy": healthy}))
                        except Exception:
                            writer.write(_encode_message(MSG_RESPONSE, {"healthy": False}))
                        await writer.drain()

            finally:
                writer.close()

        server = await asyncio.start_unix_server(handle_client, socket_path)
        async with server:
            await server.serve_forever()

    asyncio.run(_run())


def _serialize_result(result: Any) -> Any:
    """Serialize a dataclass result to a dict for msgpack transport."""
    if hasattr(result, "__dataclass_fields__"):
        d = asdict(result)
        d["__type__"] = type(result).__qualname__
        return d
    return result


def _deserialize_result(data: Any) -> Any:
    """Deserialize a dict back to the appropriate dataclass."""
    if isinstance(data, dict) and "__type__" in data:
        from openspeechapi.core import models
        type_name = data.pop("__type__")
        cls = getattr(models, type_name, None)
        if cls:
            return cls(**data)
    return data


def _reconstruct_kwargs(kwargs: dict) -> dict:
    """Reconstruct dataclass kwargs from dicts sent over IPC."""
    from openspeechapi.core import models
    result = {}
    for k, v in kwargs.items():
        if isinstance(v, dict) and "__type__" in v:
            type_name = v.pop("__type__")
            cls = getattr(models, type_name, None)
            result[k] = cls(**v) if cls else v
        else:
            result[k] = v
    return result


class SubprocessExecutor(Executor):
    """Execute provider methods in a separate subprocess via UDS + msgpack IPC."""

    def __init__(
        self,
        restart_on_crash: bool = True,
        max_restarts: int = 3,
        restart_delay_s: float = 1.0,
    ) -> None:
        self._provider_cls: type[SpeechProvider] | None = None
        self._settings: BaseSettings | None = None
        self._process: asyncio.subprocess.Process | None = None
        self._socket_path: str | None = None
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._restart_on_crash = restart_on_crash
        self._max_restarts = max_restarts
        self._restart_delay_s = restart_delay_s
        self._restart_count = 0

    async def start(
        self, provider_cls: type[SpeechProvider], settings: BaseSettings
    ) -> None:
        self._provider_cls = provider_cls
        self._settings = settings
        await self._spawn_worker()

    async def _spawn_worker(self) -> None:
        socket_dir = tempfile.mkdtemp(prefix="openspeech_")
        self._socket_path = os.path.join(socket_dir, "worker.sock")

        cls_pickle = pickle.dumps(self._provider_cls)
        settings_pickle = pickle.dumps(self._settings)

        # Launch worker as subprocess — use package root for sys.path
        import openspeechapi as _pkg
        pkg_root = str(Path(_pkg.__file__).parent.parent)
        code = (
            "import pickle, sys; "
            f"sys.path.insert(0, {pkg_root!r}); "
            "from openspeechapi.dispatch.executors.subprocess_exec import _worker_main; "
            "_worker_main(sys.argv[1], pickle.loads(bytes.fromhex(sys.argv[2])), "
            "pickle.loads(bytes.fromhex(sys.argv[3])))"
        )
        self._process = await asyncio.create_subprocess_exec(
            sys.executable, "-c", code,
            self._socket_path,
            cls_pickle.hex(),
            settings_pickle.hex(),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )

        # Wait for socket to be available
        for _ in range(50):
            if os.path.exists(self._socket_path):
                break
            await asyncio.sleep(0.1)
        else:
            raise RuntimeError("Worker process failed to create socket")

        self._reader, self._writer = await asyncio.open_unix_connection(self._socket_path)

    async def stop(self) -> None:
        if self._writer:
            self._writer.close()
            self._writer = None
            self._reader = None
        if self._process:
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self._process.kill()
            self._process = None
        if self._socket_path:
            try:
                os.unlink(self._socket_path)
                os.rmdir(os.path.dirname(self._socket_path))
            except OSError:
                pass
            self._socket_path = None

    async def _ensure_alive(self) -> None:
        """Check if worker is alive, restart if crashed and policy allows."""
        if self._process and self._process.returncode is None:
            return  # Still running

        if not self._restart_on_crash or self._restart_count >= self._max_restarts:
            raise ProviderUnavailableError(
                getattr(self._provider_cls, "name", "unknown")
            )

        self._restart_count += 1
        await asyncio.sleep(self._restart_delay_s)
        await self._spawn_worker()

    async def invoke(self, method: str, **kwargs: Any) -> Any:
        if self._process is None:
            raise RuntimeError("Executor not started")

        await self._ensure_alive()

        # Serialize kwargs (convert dataclasses to dicts)
        serialized_kwargs = {}
        for k, v in kwargs.items():
            if hasattr(v, "__dataclass_fields__"):
                d = asdict(v)
                d["__type__"] = type(v).__qualname__
                serialized_kwargs[k] = d
            else:
                serialized_kwargs[k] = v

        self._writer.write(_encode_message(MSG_INVOKE, {
            "method": method,
            "kwargs": serialized_kwargs,
        }))
        await self._writer.drain()

        msg = await _read_message(self._reader)
        if msg["type"] == MSG_ERROR:
            payload = msg["payload"]
            raise RuntimeError(f"{payload['error_type']}: {payload['message']}")

        return _deserialize_result(msg["payload"])

    async def invoke_stream(self, method: str, **kwargs: Any) -> AsyncIterator[Any]:
        # For initial implementation, fall back to non-streaming
        result = await self.invoke(method, **kwargs)
        yield result

    async def health_check(self) -> bool:
        if self._process is None or self._process.returncode is not None:
            return False
        try:
            self._writer.write(_encode_message(MSG_HEALTH, {}))
            await self._writer.drain()
            msg = await _read_message(self._reader)
            return msg["payload"].get("healthy", False)
        except Exception:
            return False
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_subprocess.py -v -x`
Expected: All PASS (may need adjustments for async timing)

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/dispatch/executors/subprocess_exec.py tests/unit/test_subprocess.py
git commit -m "feat: SubprocessExecutor with UDS + msgpack IPC and crash restart"
```

---

### Task 11: RemoteExecutor

**Files:**
- Create: `openspeechapi/dispatch/executors/remote.py`
- Create: `tests/unit/test_remote.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_remote.py
"""Tests for RemoteExecutor."""
import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.dispatch.executors.remote import RemoteExecutor
from tests.conftest import FakeSTT, FakeSTTSettings


class TestRemoteExecutor:
    """RemoteExecutor delegates to provider adapter which handles its own protocol.
    It's essentially an InProcessExecutor where the provider itself does remote calls."""

    @pytest.mark.asyncio
    async def test_start_and_invoke(self):
        executor = RemoteExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await executor.invoke("transcribe", audio=audio)
        assert isinstance(result, Transcription)
        await executor.stop()

    @pytest.mark.asyncio
    async def test_health_check(self):
        executor = RemoteExecutor()
        await executor.start(FakeSTT, FakeSTTSettings())
        assert await executor.health_check() is True
        await executor.stop()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_remote.py -v`
Expected: FAIL

- [ ] **Step 3: Implement RemoteExecutor**

Per spec: RemoteExecutor delegates to the provider adapter which handles its own protocol (HTTP/gRPC/WebSocket). So it's structurally similar to InProcessExecutor — the "remote" part is in the provider implementation, not the executor.

```python
# openspeechapi/dispatch/executors/remote.py
"""RemoteExecutor — delegates to provider adapter that handles its own remote protocol."""
from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from openspeechapi.core.base import SpeechProvider
from openspeechapi.core.settings import BaseSettings
from openspeechapi.dispatch.executors.base import Executor


class RemoteExecutor(Executor):
    """Execute provider methods where the provider itself manages remote communication.

    The provider adapter is responsible for HTTP/gRPC/WebSocket calls.
    This executor simply instantiates the provider and forwards method calls.
    """

    def __init__(self) -> None:
        self._provider: SpeechProvider | None = None

    async def start(
        self, provider_cls: type[SpeechProvider], settings: BaseSettings
    ) -> None:
        self._provider = provider_cls(settings=settings)
        await self._provider.start()

    async def stop(self) -> None:
        if self._provider:
            await self._provider.stop()
            self._provider = None

    async def invoke(self, method: str, **kwargs: Any) -> Any:
        if self._provider is None:
            raise RuntimeError("Executor not started")
        fn = getattr(self._provider, method)
        return await fn(**kwargs)

    async def invoke_stream(self, method: str, **kwargs: Any) -> AsyncIterator[Any]:
        if self._provider is None:
            raise RuntimeError("Executor not started")
        fn = getattr(self._provider, method)
        async for item in fn(**kwargs):
            yield item

    async def health_check(self) -> bool:
        if self._provider is None:
            return False
        return await self._provider.health_check()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_remote.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/dispatch/executors/remote.py tests/unit/test_remote.py
git commit -m "feat: RemoteExecutor delegating to provider's own protocol"
```

---

## Chunk 4: Dispatch Layer — Filters, FanOut, ServiceDispatcher

### Task 12: Result filters

**Files:**
- Create: `openspeechapi/dispatch/filters.py`
- Create: `tests/unit/test_filters.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_filters.py
"""Tests for result filter chain."""
import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.dispatch.filters import (
    AudioFormatFilter,
    ConfidenceFilter,
    DurationFilter,
    FilterChain,
    LanguageFilter,
    ResultFilter,
)


class TestConfidenceFilter:
    def test_passes_high_confidence(self):
        f = ConfidenceFilter(min_confidence=0.8)
        t = Transcription(text="hello", confidence=0.95)
        assert f.should_pass(t) is True

    def test_drops_low_confidence(self):
        f = ConfidenceFilter(min_confidence=0.8)
        t = Transcription(text="hello", confidence=0.5)
        assert f.should_pass(t) is False

    def test_passes_when_no_confidence(self):
        f = ConfidenceFilter(min_confidence=0.8)
        t = Transcription(text="hello", confidence=None)
        assert f.should_pass(t) is True


class TestLanguageFilter:
    def test_passes_allowed_language(self):
        f = LanguageFilter(allow=["en", "zh"])
        t = Transcription(text="hello", language="en")
        assert f.should_pass(t) is True

    def test_drops_disallowed_language(self):
        f = LanguageFilter(allow=["en", "zh"])
        t = Transcription(text="hola", language="es")
        assert f.should_pass(t) is False

    def test_passes_when_no_language(self):
        f = LanguageFilter(allow=["en"])
        t = Transcription(text="hello", language=None)
        assert f.should_pass(t) is True


class TestDurationFilter:
    def test_passes_long_enough(self):
        f = DurationFilter(min_ms=100)
        audio = AudioData(data=b"x", sample_rate=16000, channels=1,
                          format=AudioFormat.PCM_16K, duration_ms=500)
        assert f.should_pass(audio) is True

    def test_drops_too_short(self):
        f = DurationFilter(min_ms=100)
        audio = AudioData(data=b"x", sample_rate=16000, channels=1,
                          format=AudioFormat.PCM_16K, duration_ms=50)
        assert f.should_pass(audio) is False


class TestFilterChain:
    def test_all_pass(self):
        chain = FilterChain([
            ConfidenceFilter(min_confidence=0.5),
            LanguageFilter(allow=["en"]),
        ])
        t = Transcription(text="hello", confidence=0.9, language="en")
        result = chain.apply(t)
        assert result is not None
        assert result.text == "hello"

    def test_first_filter_drops(self):
        chain = FilterChain([
            ConfidenceFilter(min_confidence=0.99),
            LanguageFilter(allow=["en"]),
        ])
        t = Transcription(text="hello", confidence=0.5, language="en")
        result = chain.apply(t)
        assert result is None

    def test_empty_chain_passes(self):
        chain = FilterChain([])
        t = Transcription(text="hello")
        assert chain.apply(t) is t
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_filters.py -v`
Expected: FAIL

- [ ] **Step 3: Implement filters**

```python
# openspeechapi/dispatch/filters.py
"""Result filter chain — post-processing filters applied to provider results."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription

T = TypeVar("T")


class ResultFilter(ABC, Generic[T]):
    """Base class for result filters."""

    def should_pass(self, result: T) -> bool:
        return True

    def transform(self, result: T) -> T:
        return result


class ConfidenceFilter(ResultFilter):
    def __init__(self, min_confidence: float = 0.8) -> None:
        self._min = min_confidence

    def should_pass(self, result: Any) -> bool:
        confidence = getattr(result, "confidence", None)
        if confidence is None:
            return True
        return confidence >= self._min


class LanguageFilter(ResultFilter):
    def __init__(self, allow: list[str]) -> None:
        self._allow = set(allow)

    def should_pass(self, result: Any) -> bool:
        language = getattr(result, "language", None)
        if language is None:
            return True
        return language in self._allow


class DurationFilter(ResultFilter):
    def __init__(self, min_ms: int = 100) -> None:
        self._min_ms = min_ms

    def should_pass(self, result: Any) -> bool:
        duration = getattr(result, "duration_ms", None)
        if duration is None:
            return True
        return duration >= self._min_ms


class AudioFormatFilter(ResultFilter):
    def __init__(self, target: AudioFormat = AudioFormat.PCM_16K) -> None:
        self._target = target

    def should_pass(self, result: Any) -> bool:
        return True

    def transform(self, result: Any) -> Any:
        if isinstance(result, AudioData) and result.format != self._target:
            # Placeholder: actual format conversion would go here
            return AudioData(
                data=result.data, sample_rate=result.sample_rate,
                channels=result.channels, format=self._target,
                duration_ms=result.duration_ms,
            )
        return result


class FilterChain:
    """Applies a sequence of filters to a result."""

    def __init__(self, filters: list[ResultFilter]) -> None:
        self._filters = filters

    def apply(self, result: Any) -> Any | None:
        for f in self._filters:
            if not f.should_pass(result):
                return None
            result = f.transform(result)
        return result
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_filters.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/dispatch/filters.py tests/unit/test_filters.py
git commit -m "feat: result filter chain with Confidence/Language/Duration/AudioFormat filters"
```

---

### Task 13: FanOut/FanIn concurrent dispatch

**Files:**
- Create: `openspeechapi/dispatch/fanout.py`
- Create: `tests/unit/test_fanout.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_fanout.py
"""Tests for FanOut/FanIn concurrent dispatch."""
import asyncio

import pytest

from openspeechapi.core.models import Transcription
from openspeechapi.dispatch.fanout import (
    CollectAll,
    FanOutResult,
    FirstCompleted,
    HighestConfidence,
    fan_out,
)
from openspeechapi.exceptions import FanOutAllFailedError


async def _fast_provider() -> Transcription:
    await asyncio.sleep(0.01)
    return Transcription(text="fast", confidence=0.8)


async def _slow_provider() -> Transcription:
    await asyncio.sleep(0.1)
    return Transcription(text="slow", confidence=0.99)


async def _failing_provider() -> Transcription:
    raise RuntimeError("provider failed")


class TestFirstCompleted:
    @pytest.mark.asyncio
    async def test_returns_first(self):
        tasks = {"fast": _fast_provider(), "slow": _slow_provider()}
        result = await fan_out(tasks, FirstCompleted())
        assert result.text == "fast"

    @pytest.mark.asyncio
    async def test_all_fail_raises(self):
        tasks = {"a": _failing_provider(), "b": _failing_provider()}
        with pytest.raises(FanOutAllFailedError):
            await fan_out(tasks, FirstCompleted())

    @pytest.mark.asyncio
    async def test_partial_failure_returns_success(self):
        tasks = {"fail": _failing_provider(), "ok": _fast_provider()}
        result = await fan_out(tasks, FirstCompleted())
        assert result.text == "fast"


class TestHighestConfidence:
    @pytest.mark.asyncio
    async def test_picks_highest(self):
        tasks = {"fast": _fast_provider(), "slow": _slow_provider()}
        result = await fan_out(tasks, HighestConfidence())
        assert result.text == "slow"
        assert result.confidence == 0.99

    @pytest.mark.asyncio
    async def test_all_fail_raises(self):
        tasks = {"a": _failing_provider()}
        with pytest.raises(FanOutAllFailedError):
            await fan_out(tasks, HighestConfidence())


class TestCollectAll:
    @pytest.mark.asyncio
    async def test_collects_successes_and_errors(self):
        tasks = {"ok": _fast_provider(), "fail": _failing_provider()}
        result = await fan_out(tasks, CollectAll())
        assert isinstance(result, FanOutResult)
        assert "ok" in result.successes
        assert "fail" in result.errors
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_fanout.py -v`
Expected: FAIL

- [ ] **Step 3: Implement FanOut/FanIn**

```python
# openspeechapi/dispatch/fanout.py
"""FanOut/FanIn — concurrent dispatch to multiple providers with merge strategies."""
from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from openspeechapi.exceptions import FanOutAllFailedError


@dataclass
class FanOutResult:
    """Result container for CollectAll strategy."""
    successes: dict[str, Any] = field(default_factory=dict)
    errors: dict[str, Exception] = field(default_factory=dict)


class MergeStrategy(ABC):
    @abstractmethod
    async def merge(self, results: dict[str, Any | Exception]) -> Any: ...


class FirstCompleted(MergeStrategy):
    async def merge(self, results: dict[str, Any | Exception]) -> Any:
        successes = {k: v for k, v in results.items() if not isinstance(v, Exception)}
        if not successes:
            errors = {k: v for k, v in results.items() if isinstance(v, Exception)}
            raise FanOutAllFailedError(errors)
        # Return first success (dict preserves insertion order = completion order)
        return next(iter(successes.values()))


class HighestConfidence(MergeStrategy):
    async def merge(self, results: dict[str, Any | Exception]) -> Any:
        successes = {k: v for k, v in results.items() if not isinstance(v, Exception)}
        if not successes:
            errors = {k: v for k, v in results.items() if isinstance(v, Exception)}
            raise FanOutAllFailedError(errors)
        return max(successes.values(), key=lambda r: getattr(r, "confidence", 0) or 0)


class CollectAll(MergeStrategy):
    async def merge(self, results: dict[str, Any | Exception]) -> FanOutResult:
        fan_result = FanOutResult()
        for k, v in results.items():
            if isinstance(v, Exception):
                fan_result.errors[k] = v
            else:
                fan_result.successes[k] = v
        return fan_result


class CustomMerge(MergeStrategy):
    def __init__(self, fn: Callable[[dict[str, Any | Exception]], Awaitable[Any]]) -> None:
        self._fn = fn

    async def merge(self, results: dict[str, Any | Exception]) -> Any:
        return await self._fn(results)


async def fan_out(
    tasks: dict[str, Awaitable[Any]],
    strategy: MergeStrategy,
) -> Any:
    """Execute tasks concurrently and merge results using the given strategy."""
    if isinstance(strategy, FirstCompleted):
        return await _fan_out_first_completed(tasks, strategy)

    # For strategies that need all results
    results: dict[str, Any | Exception] = {}

    async def _run(name: str, coro: Awaitable[Any]) -> None:
        try:
            results[name] = await coro
        except Exception as e:
            results[name] = e

    await asyncio.gather(*[_run(name, coro) for name, coro in tasks.items()])
    return await strategy.merge(results)


async def _fan_out_first_completed(
    tasks: dict[str, Awaitable[Any]],
    strategy: FirstCompleted,
) -> Any:
    """Optimized first-completed: return as soon as first succeeds."""
    results: dict[str, Any | Exception] = {}
    done_event = asyncio.Event()

    async def _run(name: str, coro: Awaitable[Any]) -> None:
        try:
            result = await coro
            results[name] = result
            done_event.set()
        except Exception as e:
            results[name] = e
            if len(results) == len(tasks):
                done_event.set()

    async_tasks = [asyncio.create_task(_run(name, coro)) for name, coro in tasks.items()]

    await done_event.wait()

    # Cancel remaining tasks
    for t in async_tasks:
        if not t.done():
            t.cancel()

    # Gather to suppress CancelledError
    await asyncio.gather(*async_tasks, return_exceptions=True)

    return await strategy.merge(results)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_fanout.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/dispatch/fanout.py tests/unit/test_fanout.py
git commit -m "feat: FanOut/FanIn with FirstCompleted, HighestConfidence, CollectAll strategies"
```

---

### Task 14: ServiceDispatcher

**Files:**
- Create: `openspeechapi/dispatch/dispatcher.py`
- Create: `tests/unit/test_dispatcher.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_dispatcher.py
"""Tests for ServiceDispatcher."""
from textwrap import dedent

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.exceptions import ProviderNotFoundError
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def registry():
    r = ProviderRegistry()
    r.register("fake-stt", FakeSTT)
    r.register("fake-tts", FakeTTS)
    return r


@pytest.fixture
def config_file(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          my-stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          my-tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    return cfg


class TestServiceDispatcher:
    @pytest.mark.asyncio
    async def test_create_from_config(self, config_file, registry):
        dispatcher = ServiceDispatcher.from_config(config_file, registry)
        await dispatcher.start()
        assert dispatcher.list_providers() == ["my-stt", "my-tts"]
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_stt_transcribe(self, config_file, registry):
        dispatcher = ServiceDispatcher.from_config(config_file, registry)
        await dispatcher.start()
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await dispatcher.transcribe("my-stt", audio)
        assert isinstance(result, Transcription)
        assert result.text == "fake transcription"
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_tts_synthesize(self, config_file, registry):
        dispatcher = ServiceDispatcher.from_config(config_file, registry)
        await dispatcher.start()
        result = await dispatcher.synthesize("my-tts", "hello")
        assert isinstance(result, AudioData)
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_unknown_provider_raises(self, config_file, registry):
        dispatcher = ServiceDispatcher.from_config(config_file, registry)
        await dispatcher.start()
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        with pytest.raises(ProviderNotFoundError):
            await dispatcher.transcribe("nonexistent", audio)
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_health(self, config_file, registry):
        dispatcher = ServiceDispatcher.from_config(config_file, registry)
        await dispatcher.start()
        health = await dispatcher.health()
        assert health["my-stt"] is True
        assert health["my-tts"] is True
        await dispatcher.stop()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_dispatcher.py -v`
Expected: FAIL

- [ ] **Step 3: Implement ServiceDispatcher**

```python
# openspeechapi/dispatch/dispatcher.py
"""ServiceDispatcher — central coordinator for provider invocations."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from openspeechapi.config import load_config, OpenSpeechConfig
from openspeechapi.core.enums import ExecMode
from openspeechapi.core.models import AudioData, STTOptions, TTSOptions, Transcription
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.dispatch.executors.base import Executor
from openspeechapi.dispatch.executors.in_process import InProcessExecutor
from openspeechapi.dispatch.executors.remote import RemoteExecutor
from openspeechapi.dispatch.executors.subprocess_exec import SubprocessExecutor
from openspeechapi.dispatch.fanout import MergeStrategy, fan_out
from openspeechapi.dispatch.filters import FilterChain
from openspeechapi.exceptions import ProviderNotFoundError

_EXEC_MAP = {
    "in_process": InProcessExecutor,
    "subprocess": SubprocessExecutor,
    "remote": RemoteExecutor,
}


class _ProviderHandle:
    """Internal handle for a configured provider instance."""

    def __init__(
        self,
        name: str,
        provider_cls: Any,
        executor: Executor,
        exec_mode: str,
        settings_dict: dict,
        filters: FilterChain,
    ) -> None:
        self.name = name
        self.provider_cls = provider_cls
        self.executor = executor
        self.exec_mode = exec_mode
        self.settings_dict = settings_dict
        self.filters = filters


class ServiceDispatcher:
    """Central coordinator. Loads config, manages executors, routes invocations."""

    def __init__(self, handles: dict[str, _ProviderHandle]) -> None:
        self._handles = handles
        from openspeechapi.observe.base import ObserverManager
        self._observer_mgr = ObserverManager()

    @classmethod
    def from_config(
        cls, config_path: Path, registry: ProviderRegistry
    ) -> ServiceDispatcher:
        config = load_config(config_path)
        handles: dict[str, _ProviderHandle] = {}

        for instance_name, prov_config in config.providers.items():
            provider_cls = registry.get(prov_config.provider)
            exec_cls = _EXEC_MAP.get(prov_config.exec_mode)
            if exec_cls is None:
                raise ValueError(f"Unknown exec_mode: {prov_config.exec_mode}")

            executor = exec_cls()

            # Build filter chain from config
            from openspeechapi.dispatch.filters import (
                ConfidenceFilter, LanguageFilter, DurationFilter, AudioFormatFilter, ResultFilter,
            )
            filter_map = {
                "confidence": lambda cfg: ConfidenceFilter(min_confidence=cfg.get("min", 0.8)),
                "language": lambda cfg: LanguageFilter(allow=cfg.get("allow", [])),
                "duration": lambda cfg: DurationFilter(min_ms=cfg.get("min_ms", 100)),
                "audio_format": lambda cfg: AudioFormatFilter(),
            }
            filters: list[ResultFilter] = []
            for f_cfg in prov_config.filters:
                f_type = f_cfg.get("type", "")
                builder = filter_map.get(f_type)
                if builder:
                    filters.append(builder(f_cfg))
            filter_chain = FilterChain(filters)

            handles[instance_name] = _ProviderHandle(
                name=instance_name,
                provider_cls=provider_cls,
                executor=executor,
                exec_mode=prov_config.exec_mode,
                settings_dict=prov_config.settings,
                filters=filter_chain,
            )

        return cls(handles)

    async def start(self) -> None:
        for handle in self._handles.values():
            # Use provider's settings_cls to construct typed settings from config dict
            settings_cls = getattr(handle.provider_cls, "settings_cls", BaseSettings)
            settings = settings_cls(**handle.settings_dict)
            await handle.executor.start(handle.provider_cls, settings)

    async def stop(self) -> None:
        for handle in self._handles.values():
            await handle.executor.stop()

    def list_providers(self) -> list[str]:
        return list(self._handles.keys())

    def _get_handle(self, name: str) -> _ProviderHandle:
        if name not in self._handles:
            raise ProviderNotFoundError(name)
        return self._handles[name]

    async def transcribe(
        self, provider_name: str, audio: AudioData, opts: STTOptions | None = None,
    ) -> Transcription | None:
        handle = self._get_handle(provider_name)
        ctx = InvokeContext(provider_name=provider_name, method="transcribe", exec_mode=ExecMode(handle.exec_mode))
        await self._observer_mgr.notify_invoke_start(ctx)
        try:
            kwargs: dict[str, Any] = {"audio": audio}
            if opts:
                kwargs["opts"] = opts
            result = await handle.executor.invoke("transcribe", **kwargs)
            ctx.record_end()
            await self._observer_mgr.notify_invoke_end(ctx, result)
            return handle.filters.apply(result)
        except Exception as e:
            ctx.record_end()
            await self._observer_mgr.notify_invoke_error(ctx, e)
            raise

    async def synthesize(
        self, provider_name: str, text: str, opts: TTSOptions | None = None,
    ) -> AudioData | None:
        handle = self._get_handle(provider_name)
        ctx = InvokeContext(provider_name=provider_name, method="synthesize", exec_mode=ExecMode(handle.exec_mode), metadata={"text": text})
        await self._observer_mgr.notify_invoke_start(ctx)
        try:
            kwargs: dict[str, Any] = {"text": text}
            if opts:
                kwargs["opts"] = opts
            result = await handle.executor.invoke("synthesize", **kwargs)
            ctx.record_end()
            await self._observer_mgr.notify_invoke_end(ctx, result)
            return handle.filters.apply(result)
        except Exception as e:
            ctx.record_end()
            await self._observer_mgr.notify_invoke_error(ctx, e)
            raise

    async def fanout_transcribe(
        self,
        provider_names: list[str],
        audio: AudioData,
        strategy: MergeStrategy,
        opts: STTOptions | None = None,
    ) -> Any:
        tasks = {}
        for name in provider_names:
            handle = self._get_handle(name)
            kwargs: dict[str, Any] = {"audio": audio}
            if opts:
                kwargs["opts"] = opts
            tasks[name] = handle.executor.invoke("transcribe", **kwargs)
        return await fan_out(tasks, strategy)

    async def health(self) -> dict[str, bool]:
        result = {}
        for name, handle in self._handles.items():
            result[name] = await handle.executor.health_check()
        return result

    def add_observer(self, observer: Any) -> None:
        self._observer_mgr.add(observer)

    def remove_observer(self, observer: Any) -> None:
        self._observer_mgr.remove(observer)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_dispatcher.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/dispatch/dispatcher.py tests/unit/test_dispatcher.py
git commit -m "feat: ServiceDispatcher with config-driven executor routing and fanout"
```

---

## Chunk 5: Observability

### Task 15: Observer base + ObserverManager

**Files:**
- Create: `openspeechapi/observe/__init__.py`
- Create: `openspeechapi/observe/base.py`
- Create: `tests/unit/test_observer_base.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_observer_base.py
"""Tests for observer base and manager."""
import pytest

from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver, ObserverManager


class CountingObserver(DispatchObserver):
    def __init__(self):
        self.starts = 0
        self.ends = 0
        self.errors = 0

    async def on_invoke_start(self, ctx):
        self.starts += 1

    async def on_invoke_end(self, ctx, result):
        self.ends += 1

    async def on_invoke_error(self, ctx, error):
        self.errors += 1


class FailingObserver(DispatchObserver):
    def __init__(self):
        self.call_count = 0

    async def on_invoke_start(self, ctx):
        self.call_count += 1
        raise RuntimeError("observer broken")


class TestObserverManager:
    @pytest.mark.asyncio
    async def test_notify_invoke_start(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        ctx = InvokeContext(provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS)
        await mgr.notify_invoke_start(ctx)
        assert obs.starts == 1

    @pytest.mark.asyncio
    async def test_failing_observer_does_not_propagate(self):
        mgr = ObserverManager()
        failing = FailingObserver()
        counting = CountingObserver()
        mgr.add(failing)
        mgr.add(counting)
        ctx = InvokeContext(provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS)
        await mgr.notify_invoke_start(ctx)
        assert counting.starts == 1  # Other observers still notified

    @pytest.mark.asyncio
    async def test_auto_deregister_after_consecutive_errors(self):
        mgr = ObserverManager(max_consecutive_errors=3)
        failing = FailingObserver()
        mgr.add(failing)
        ctx = InvokeContext(provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS)
        for _ in range(4):
            await mgr.notify_invoke_start(ctx)
        assert failing not in mgr.list()

    def test_add_and_remove(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        assert obs in mgr.list()
        mgr.remove(obs)
        assert obs not in mgr.list()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_observer_base.py -v`
Expected: FAIL

- [ ] **Step 3: Implement observer base + manager**

```python
# openspeechapi/observe/__init__.py
```

```python
# openspeechapi/observe/base.py
"""DispatchObserver ABC and ObserverManager with error isolation."""
from __future__ import annotations

from abc import ABC
from typing import Any

from loguru import logger

from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext


class DispatchObserver(ABC):
    """Base class for dispatch observers. All methods are optional no-ops."""

    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        pass

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        pass

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        pass

    async def on_stream_chunk(self, ctx: InvokeContext, chunk: Any) -> None:
        pass

    async def on_provider_start(self, provider: str, exec_mode: ExecMode) -> None:
        pass

    async def on_provider_stop(self, provider: str) -> None:
        pass

    async def on_health_change(self, provider: str, healthy: bool) -> None:
        pass


class ObserverManager:
    """Manages observers with error isolation and auto-deregistration."""

    def __init__(self, max_consecutive_errors: int = 10) -> None:
        self._observers: list[DispatchObserver] = []
        self._error_counts: dict[int, int] = {}  # id(observer) -> count
        self._max_errors = max_consecutive_errors

    def add(self, observer: DispatchObserver) -> None:
        self._observers.append(observer)
        self._error_counts[id(observer)] = 0

    def remove(self, observer: DispatchObserver) -> None:
        self._observers.remove(observer)
        self._error_counts.pop(id(observer), None)

    def list(self) -> list[DispatchObserver]:
        return list(self._observers)

    async def _notify(self, method: str, *args: Any, **kwargs: Any) -> None:
        to_remove = []
        for obs in self._observers:
            try:
                fn = getattr(obs, method)
                await fn(*args, **kwargs)
                self._error_counts[id(obs)] = 0
            except Exception as e:
                obs_id = id(obs)
                self._error_counts[obs_id] = self._error_counts.get(obs_id, 0) + 1
                logger.warning(
                    f"Observer {type(obs).__name__} raised {type(e).__name__}: {e} "
                    f"(consecutive errors: {self._error_counts[obs_id]})"
                )
                if self._error_counts[obs_id] >= self._max_errors:
                    to_remove.append(obs)
                    logger.warning(
                        f"Auto-deregistering observer {type(obs).__name__} "
                        f"after {self._max_errors} consecutive errors"
                    )

        for obs in to_remove:
            self.remove(obs)

    async def notify_invoke_start(self, ctx: InvokeContext) -> None:
        await self._notify("on_invoke_start", ctx)

    async def notify_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        await self._notify("on_invoke_end", ctx, result)

    async def notify_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        await self._notify("on_invoke_error", ctx, error)

    async def notify_stream_chunk(self, ctx: InvokeContext, chunk: Any) -> None:
        await self._notify("on_stream_chunk", ctx, chunk)

    async def notify_provider_start(self, provider: str, exec_mode: ExecMode) -> None:
        await self._notify("on_provider_start", provider, exec_mode)

    async def notify_provider_stop(self, provider: str) -> None:
        await self._notify("on_provider_stop", provider)

    async def notify_health_change(self, provider: str, healthy: bool) -> None:
        await self._notify("on_health_change", provider, healthy)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_observer_base.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/observe/ tests/unit/test_observer_base.py
git commit -m "feat: DispatchObserver ABC + ObserverManager with error isolation"
```

---

### Task 16: Built-in observers (Metrics, Latency, Debug, Usage)

**Files:**
- Create: `openspeechapi/observe/metrics.py`
- Create: `openspeechapi/observe/latency.py`
- Create: `openspeechapi/observe/debug.py`
- Create: `openspeechapi/observe/usage.py`
- Create: `openspeechapi/observe/tracing.py`
- Create: `tests/unit/test_metrics_observer.py`
- Create: `tests/unit/test_usage_observer.py`

- [ ] **Step 1: Write failing tests for MetricsObserver and UsageObserver**

```python
# tests/unit/test_metrics_observer.py
"""Tests for MetricsObserver."""
import pytest

from openspeechapi.core.enums import ExecMode
from openspeechapi.core.models import Transcription
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.metrics import MetricsObserver


class TestMetricsObserver:
    @pytest.mark.asyncio
    async def test_records_invocation(self):
        obs = MetricsObserver()
        ctx = InvokeContext(provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS)
        await obs.on_invoke_start(ctx)
        ctx.record_ttfb()
        ctx.record_end()
        result = Transcription(text="hello")
        await obs.on_invoke_end(ctx, result)
        metrics = obs.get_metrics("test")
        assert metrics["total_calls"] == 1
        assert metrics["error_count"] == 0
        assert len(metrics["durations_ms"]) == 1

    @pytest.mark.asyncio
    async def test_records_error(self):
        obs = MetricsObserver()
        ctx = InvokeContext(provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS)
        await obs.on_invoke_start(ctx)
        await obs.on_invoke_error(ctx, RuntimeError("fail"))
        metrics = obs.get_metrics("test")
        assert metrics["error_count"] == 1
```

```python
# tests/unit/test_usage_observer.py
"""Tests for UsageObserver."""
import pytest

from openspeechapi.core.enums import AudioFormat, ExecMode
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.usage import UsageObserver


class TestUsageObserver:
    @pytest.mark.asyncio
    async def test_tracks_call_count(self):
        obs = UsageObserver()
        ctx = InvokeContext(provider_name="stt-1", method="transcribe", exec_mode=ExecMode.IN_PROCESS)
        await obs.on_invoke_end(ctx, Transcription(text="hi"))
        usage = obs.get_usage("stt-1")
        assert usage["call_count"] == 1

    @pytest.mark.asyncio
    async def test_tracks_audio_duration(self):
        obs = UsageObserver()
        ctx = InvokeContext(provider_name="tts-1", method="synthesize", exec_mode=ExecMode.IN_PROCESS)
        audio = AudioData(data=b"x", sample_rate=16000, channels=1,
                         format=AudioFormat.PCM_16K, duration_ms=2000)
        await obs.on_invoke_end(ctx, audio)
        usage = obs.get_usage("tts-1")
        assert usage["total_audio_ms"] == 2000

    @pytest.mark.asyncio
    async def test_tracks_character_count(self):
        obs = UsageObserver()
        ctx = InvokeContext(provider_name="tts-1", method="synthesize", exec_mode=ExecMode.IN_PROCESS,
                           metadata={"text": "hello world"})
        audio = AudioData(data=b"x", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        await obs.on_invoke_end(ctx, audio)
        usage = obs.get_usage("tts-1")
        assert usage["total_characters"] == 11
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_metrics_observer.py tests/unit/test_usage_observer.py -v`
Expected: FAIL

- [ ] **Step 3: Implement MetricsObserver**

```python
# openspeechapi/observe/metrics.py
"""MetricsObserver — collect TTFB, processing duration, throughput."""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class MetricsObserver(DispatchObserver):
    def __init__(self) -> None:
        self._data: dict[str, dict[str, Any]] = defaultdict(
            lambda: {"total_calls": 0, "error_count": 0, "durations_ms": [], "ttfb_ms": []}
        )

    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        pass

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        m = self._data[ctx.provider_name]
        m["total_calls"] += 1
        if ctx.end_time_ns and ctx.start_time_ns:
            m["durations_ms"].append((ctx.end_time_ns - ctx.start_time_ns) / 1_000_000)
        if ctx.ttfb_ns and ctx.start_time_ns:
            m["ttfb_ms"].append((ctx.ttfb_ns - ctx.start_time_ns) / 1_000_000)

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        self._data[ctx.provider_name]["error_count"] += 1

    def get_metrics(self, provider_name: str) -> dict[str, Any]:
        return dict(self._data[provider_name])
```

- [ ] **Step 4: Implement LatencyObserver**

```python
# openspeechapi/observe/latency.py
"""LatencyObserver — end-to-end latency tracking."""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class LatencyObserver(DispatchObserver):
    def __init__(self, max_samples: int = 1000) -> None:
        self._max_samples = max_samples
        self._latencies: dict[str, list[dict[str, float]]] = defaultdict(list)

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        entry: dict[str, float] = {}
        if ctx.end_time_ns and ctx.start_time_ns:
            entry["total_ms"] = (ctx.end_time_ns - ctx.start_time_ns) / 1_000_000
        if ctx.ttfb_ns and ctx.start_time_ns:
            entry["ttfb_ms"] = (ctx.ttfb_ns - ctx.start_time_ns) / 1_000_000
        if entry:
            samples = self._latencies[ctx.provider_name]
            samples.append(entry)
            if len(samples) > self._max_samples:
                samples.pop(0)

    def get_latencies(self, provider_name: str) -> list[dict[str, float]]:
        return list(self._latencies[provider_name])
```

- [ ] **Step 5: Implement DebugLogObserver**

```python
# openspeechapi/observe/debug.py
"""DebugLogObserver — detailed structured logging."""
from __future__ import annotations

from typing import Any

from loguru import logger

from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class DebugLogObserver(DispatchObserver):
    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        logger.debug(
            f"[{ctx.request_id}] START {ctx.provider_name}.{ctx.method} "
            f"mode={ctx.exec_mode.value}"
        )

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        logger.debug(
            f"[{ctx.request_id}] END {ctx.provider_name}.{ctx.method} "
            f"elapsed={ctx.elapsed_ms:.1f}ms"
        )

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        logger.debug(
            f"[{ctx.request_id}] ERROR {ctx.provider_name}.{ctx.method} "
            f"{type(error).__name__}: {error}"
        )

    async def on_provider_start(self, provider: str, exec_mode: ExecMode) -> None:
        logger.debug(f"Provider {provider} started (mode={exec_mode.value})")

    async def on_provider_stop(self, provider: str) -> None:
        logger.debug(f"Provider {provider} stopped")
```

- [ ] **Step 6: Implement UsageObserver**

```python
# openspeechapi/observe/usage.py
"""UsageObserver — call counts, character counts, audio duration per provider."""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from openspeechapi.core.models import AudioData
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class UsageObserver(DispatchObserver):
    def __init__(self) -> None:
        self._usage: dict[str, dict[str, int]] = defaultdict(
            lambda: {"call_count": 0, "total_audio_ms": 0, "total_characters": 0}
        )

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        u = self._usage[ctx.provider_name]
        u["call_count"] += 1

        if isinstance(result, AudioData) and result.duration_ms:
            u["total_audio_ms"] += result.duration_ms

        text = ctx.metadata.get("text", "")
        if text:
            u["total_characters"] += len(text)

    def get_usage(self, provider_name: str) -> dict[str, int]:
        return dict(self._usage[provider_name])
```

- [ ] **Step 7: Create TracingObserver stub**

```python
# openspeechapi/observe/tracing.py
"""TracingObserver — OpenTelemetry span integration (requires tracing extras)."""
from __future__ import annotations

from typing import Any

from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class TracingObserver(DispatchObserver):
    """OpenTelemetry tracing observer. Requires openspeechapi[tracing] extras."""

    def __init__(self, service_name: str = "openspeechapi") -> None:
        try:
            from opentelemetry import trace
            self._tracer = trace.get_tracer(service_name)
        except ImportError:
            self._tracer = None

        self._spans: dict[str, Any] = {}

    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        if self._tracer is None:
            return
        span = self._tracer.start_span(
            f"{ctx.provider_name}.{ctx.method}",
            attributes={
                "provider": ctx.provider_name,
                "method": ctx.method,
                "exec_mode": ctx.exec_mode.value,
                "request_id": ctx.request_id,
            },
        )
        self._spans[ctx.request_id] = span

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        span = self._spans.pop(ctx.request_id, None)
        if span:
            span.end()

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        span = self._spans.pop(ctx.request_id, None)
        if span:
            from opentelemetry.trace import StatusCode
            span.set_status(StatusCode.ERROR, str(error))
            span.end()
```

- [ ] **Step 8: Run tests to verify they pass**

Run: `pytest tests/unit/test_metrics_observer.py tests/unit/test_usage_observer.py -v`
Expected: All PASS

- [ ] **Step 9: Commit**

```bash
git add openspeechapi/observe/ tests/unit/test_metrics_observer.py tests/unit/test_usage_observer.py
git commit -m "feat: built-in observers — Metrics, Latency, Debug, Usage, Tracing"
```

---

## Chunk 6: CLI + Top-level Exports

### Task 17: CLI entry point

**Files:**
- Create: `openspeechapi/cli.py`
- Create: `tests/unit/test_cli.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_cli.py
"""Tests for CLI."""
import subprocess
import sys

import pytest


class TestCLI:
    def test_list_command(self, tmp_path):
        cfg = tmp_path / "providers.yaml"
        cfg.write_text("providers: {}")
        result = subprocess.run(
            [sys.executable, "-m", "openspeechapi.cli", "list", "--config", str(cfg)],
            capture_output=True, text=True,
        )
        assert result.returncode == 0

    def test_check_command(self, tmp_path):
        cfg = tmp_path / "providers.yaml"
        cfg.write_text("providers: {}")
        result = subprocess.run(
            [sys.executable, "-m", "openspeechapi.cli", "check", "--config", str(cfg)],
            capture_output=True, text=True,
        )
        assert result.returncode == 0

    def test_no_args_shows_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "openspeechapi.cli"],
            capture_output=True, text=True,
        )
        assert "usage" in result.stdout.lower() or "usage" in result.stderr.lower()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_cli.py -v`
Expected: FAIL

- [ ] **Step 3: Implement CLI**

```python
# openspeechapi/cli.py
"""CLI entry point for OpenSpeechAPI."""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

from openspeechapi.config import load_config
from openspeechapi.exceptions import ConfigError


def _cmd_list(args: argparse.Namespace) -> None:
    """List configured providers."""
    try:
        config = load_config(Path(args.config))
    except ConfigError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if not config.providers:
        print("No providers configured.")
        return

    print(f"{'Name':<25} {'Provider':<20} {'ExecMode':<15}")
    print("-" * 60)
    for name, prov in config.providers.items():
        print(f"{name:<25} {prov.provider:<20} {prov.exec_mode:<15}")


def _cmd_check(args: argparse.Namespace) -> None:
    """Validate configuration."""
    try:
        config = load_config(Path(args.config))
        print(f"Config OK: {len(config.providers)} provider(s) configured.")
    except ConfigError as e:
        print(f"Config error: {e}", file=sys.stderr)
        sys.exit(1)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="openspeechapi", description="OpenSpeechAPI CLI")
    parser.add_argument("--config", default="providers.yaml", help="Config file path")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List configured providers")
    sub.add_parser("check", help="Validate configuration")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return

    commands = {"list": _cmd_list, "check": _cmd_check}
    commands[args.command](args)


if __name__ == "__main__":
    main()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_cli.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/cli.py tests/unit/test_cli.py
git commit -m "feat: CLI with list and check commands"
```

---

### Task 18: Top-level exports in __init__.py

**Files:**
- Modify: `openspeechapi/__init__.py`
- Modify: `openspeechapi/core/__init__.py`

- [ ] **Step 1: Update openspeechapi/__init__.py with public API exports**

```python
# openspeechapi/__init__.py
"""OpenSpeechAPI — Unified speech interface for STT/TTS providers."""

__version__ = "0.1.0"

from openspeechapi.core.base import SpeechProvider, STTProvider, TTSProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, STTOptions, Transcription, TTSOptions, Word
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.core.settings import BaseSettings
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.exceptions import (
    ConfigError,
    FanOutAllFailedError,
    OpenSpeechError,
    ProviderCrashedError,
    ProviderError,
    ProviderNotFoundError,
    ProviderUnavailableError,
)

__all__ = [
    "AudioChunk",
    "AudioData",
    "AudioFormat",
    "BaseSettings",
    "Capability",
    "ConfigError",
    "ExecMode",
    "FanOutAllFailedError",
    "OpenSpeechError",
    "ProviderCrashedError",
    "ProviderError",
    "ProviderNotFoundError",
    "ProviderRegistry",
    "ProviderType",
    "ProviderUnavailableError",
    "STTOptions",
    "STTProvider",
    "ServiceDispatcher",
    "SpeechProvider",
    "TTSOptions",
    "TTSProvider",
    "Transcription",
    "Word",
]
```

- [ ] **Step 2: Verify imports work**

Run: `python -c "import openspeechapi; print(openspeechapi.__version__)"`
Expected: `0.1.0`

- [ ] **Step 3: Commit**

```bash
git add openspeechapi/__init__.py openspeechapi/core/__init__.py
git commit -m "feat: top-level public API exports"
```

---

## Chunk 7: Integration Tests

### Task 19: Integration tests

**Files:**
- Create: `tests/integration/test_in_process_integration.py`
- Create: `tests/integration/test_fanout_integration.py`

- [ ] **Step 1: Write in-process integration test**

```python
# tests/integration/test_in_process_integration.py
"""Integration test: full flow with InProcess execution."""
from pathlib import Path
from textwrap import dedent

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def full_config(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
            filters:
              - type: confidence
                min: 0.5
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    return cfg


@pytest.fixture
def registry():
    r = ProviderRegistry()
    r.register("fake-stt", FakeSTT)
    r.register("fake-tts", FakeTTS)
    return r


class TestInProcessIntegration:
    @pytest.mark.asyncio
    async def test_full_stt_flow(self, full_config, registry):
        dispatcher = ServiceDispatcher.from_config(full_config, registry)
        await dispatcher.start()

        audio = AudioData(data=b"hello", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await dispatcher.transcribe("stt", audio)
        assert result is not None
        assert isinstance(result, Transcription)
        assert result.text == "fake transcription"

        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_full_tts_flow(self, full_config, registry):
        dispatcher = ServiceDispatcher.from_config(full_config, registry)
        await dispatcher.start()

        result = await dispatcher.synthesize("tts", "Hello world")
        assert result is not None
        assert isinstance(result, AudioData)
        assert result.data == b"fake_audio"

        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_health_check_all(self, full_config, registry):
        dispatcher = ServiceDispatcher.from_config(full_config, registry)
        await dispatcher.start()
        health = await dispatcher.health()
        assert all(health.values())
        await dispatcher.stop()
```

- [ ] **Step 2: Write fanout integration test**

```python
# tests/integration/test_fanout_integration.py
"""Integration test: FanOut with multiple providers."""
from textwrap import dedent

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.dispatch.fanout import CollectAll, FirstCompleted, HighestConfidence
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def fanout_config(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt-1:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          stt-2:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
    """))
    return cfg


@pytest.fixture
def registry():
    r = ProviderRegistry()
    r.register("fake-stt", FakeSTT)
    return r


class TestFanOutIntegration:
    @pytest.mark.asyncio
    async def test_fanout_first_completed(self, fanout_config, registry):
        dispatcher = ServiceDispatcher.from_config(fanout_config, registry)
        await dispatcher.start()

        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await dispatcher.fanout_transcribe(
            ["stt-1", "stt-2"], audio, FirstCompleted()
        )
        assert result.text == "fake transcription"
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_fanout_collect_all(self, fanout_config, registry):
        dispatcher = ServiceDispatcher.from_config(fanout_config, registry)
        await dispatcher.start()

        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await dispatcher.fanout_transcribe(
            ["stt-1", "stt-2"], audio, CollectAll()
        )
        assert len(result.successes) == 2
        await dispatcher.stop()
```

- [ ] **Step 3: Run all integration tests**

Run: `pytest tests/integration/ -v`
Expected: All PASS

- [ ] **Step 4: Run full test suite**

Run: `pytest --tb=short -q`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add tests/integration/
git commit -m "test: integration tests for in-process flow and fanout"
```

---

## Chunk 8: Provider Adapter Template + First Two Adapters

Provider adapters are the most external-dependency-heavy part. Each adapter follows the same pattern. We implement 2 representative adapters (one STT, one TTS) to prove the architecture, then the remaining 9 follow the same pattern.

### Task 20: Provider adapter template

**Files:**
- Create: `openspeechapi/providers/__init__.py`
- Create: `openspeechapi/providers/stt/__init__.py`
- Create: `openspeechapi/providers/tts/__init__.py`
- Create: `openspeechapi/providers/_template.py`

- [ ] **Step 1: Create template and package init files**

```python
# openspeechapi/providers/__init__.py
```

```python
# openspeechapi/providers/stt/__init__.py
```

```python
# openspeechapi/providers/tts/__init__.py
```

```python
# openspeechapi/providers/_template.py
"""Template for implementing a new provider adapter.

Copy this file and fill in the implementation:
1. Rename the class
2. Set name, provider_type, execution_mode, capabilities
3. Implement start/stop/health_check
4. Implement transcribe (STT) or synthesize (TTS)
5. Optionally implement streaming methods
"""
from __future__ import annotations

from dataclasses import dataclass

from openspeechapi.core.base import STTProvider  # or TTSProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings


@dataclass
class MyProviderSettings(BaseSettings):
    """Provider-specific configuration. Add your fields here."""
    model: str = "default"
    # api_key: str = ""


class MySTTProvider(STTProvider):
    name = "my-provider"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    capabilities = {Capability.BATCH}

    def __init__(self, settings: MyProviderSettings | None = None) -> None:
        self.settings = settings or MyProviderSettings()

    async def start(self) -> None:
        # Initialize SDK, load model, etc.
        pass

    async def stop(self) -> None:
        # Cleanup resources
        pass

    async def health_check(self) -> bool:
        return True

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        raise NotImplementedError("Implement transcription logic")

    async def transcribe_stream(self, stream):
        raise NotImplementedError("Implement streaming if supported")
        yield  # pragma: no cover
```

- [ ] **Step 2: Commit**

```bash
git add openspeechapi/providers/
git commit -m "feat: provider adapter template and package structure"
```

---

### Task 21: OpenAI STT adapter

**Files:**
- Create: `openspeechapi/providers/stt/openai.py`
- Create: `tests/unit/test_providers/test_openai_stt.py`

- [ ] **Step 1: Write failing tests (mocking OpenAI SDK)**

```python
# tests/unit/test_providers/__init__.py
```

```python
# tests/unit/test_providers/test_openai_stt.py
"""Tests for OpenAI STT provider (mocked)."""
from unittest.mock import AsyncMock, MagicMock, patch
from dataclasses import dataclass

import pytest

from openspeechapi.core.enums import AudioFormat, Capability
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.providers.stt.openai import OpenAISTT, OpenAISTTSettings


class TestOpenAISTTSettings:
    def test_defaults(self):
        s = OpenAISTTSettings(api_key="test")
        assert s.model == "whisper-1"
        assert s.api_key == "test"


class TestOpenAISTT:
    def test_capabilities(self):
        stt = OpenAISTT(settings=OpenAISTTSettings(api_key="test"))
        assert Capability.BATCH in stt.capabilities
        assert Capability.MULTILINGUAL in stt.capabilities

    @pytest.mark.asyncio
    async def test_transcribe_calls_sdk(self):
        stt = OpenAISTT(settings=OpenAISTTSettings(api_key="test"))

        mock_response = MagicMock()
        mock_response.text = "hello world"

        mock_client = MagicMock()
        mock_client.audio.transcriptions.create = AsyncMock(return_value=mock_response)
        stt._client = mock_client

        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = await stt.transcribe(audio, STTOptions(language="en"))

        assert isinstance(result, Transcription)
        assert result.text == "hello world"
        assert result.language == "en"

    @pytest.mark.asyncio
    async def test_health_check_with_client(self):
        stt = OpenAISTT(settings=OpenAISTTSettings(api_key="test"))
        stt._client = MagicMock()
        assert await stt.health_check() is True

    @pytest.mark.asyncio
    async def test_health_check_without_client(self):
        stt = OpenAISTT(settings=OpenAISTTSettings(api_key="test"))
        assert await stt.health_check() is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_providers/test_openai_stt.py -v`
Expected: FAIL

- [ ] **Step 3: Implement OpenAI STT adapter**

```python
# openspeechapi/providers/stt/openai.py
"""OpenAI STT provider adapter (Whisper API)."""
from __future__ import annotations

import io
from dataclasses import dataclass

from openspeechapi.core.base import STTProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings


@dataclass
class OpenAISTTSettings(BaseSettings):
    api_key: str = ""
    model: str = "whisper-1"


class OpenAISTT(STTProvider):
    name = "openai-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}

    def __init__(self, settings: OpenAISTTSettings | None = None) -> None:
        self.settings = settings or OpenAISTTSettings()
        self._client = None

    async def start(self) -> None:
        try:
            from openai import AsyncOpenAI
            self._client = AsyncOpenAI(api_key=self.settings.api_key)
        except ImportError:
            raise ImportError("Install openai: pip install openspeechapi[openai]")

    async def stop(self) -> None:
        self._client = None

    async def health_check(self) -> bool:
        return self._client is not None

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started")

        opts = opts or STTOptions()
        audio_file = io.BytesIO(audio.data)
        audio_file.name = "audio.wav"

        kwargs = {"model": self.settings.model, "file": audio_file}
        if opts.language:
            kwargs["language"] = opts.language
        if opts.prompt:
            kwargs["prompt"] = opts.prompt
        if opts.temperature is not None:
            kwargs["temperature"] = opts.temperature

        response = await self._client.audio.transcriptions.create(**kwargs)
        return Transcription(
            text=response.text,
            language=opts.language,
        )

    async def transcribe_stream(self, stream):
        raise NotImplementedError("OpenAI Whisper API does not support streaming input")
        yield  # pragma: no cover
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_providers/test_openai_stt.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/providers/stt/openai.py tests/unit/test_providers/
git commit -m "feat: OpenAI STT adapter (Whisper API)"
```

---

### Task 22: OpenAI TTS adapter

**Files:**
- Create: `openspeechapi/providers/tts/openai.py`
- Create: `tests/unit/test_providers/test_openai_tts.py`

- [ ] **Step 1: Write failing tests (mocked)**

```python
# tests/unit/test_providers/test_openai_tts.py
"""Tests for OpenAI TTS provider (mocked)."""
from unittest.mock import AsyncMock, MagicMock

import pytest

from openspeechapi.core.enums import AudioFormat, Capability
from openspeechapi.core.models import AudioData, TTSOptions
from openspeechapi.providers.tts.openai import OpenAITTS, OpenAITTSSettings


class TestOpenAITTS:
    def test_capabilities(self):
        tts = OpenAITTS(settings=OpenAITTSSettings(api_key="test"))
        assert Capability.STREAMING in tts.capabilities

    @pytest.mark.asyncio
    async def test_synthesize_calls_sdk(self):
        tts = OpenAITTS(settings=OpenAITTSSettings(api_key="test"))

        mock_response = MagicMock()
        mock_response.content = b"audio_bytes"

        mock_client = MagicMock()
        mock_client.audio.speech.create = AsyncMock(return_value=mock_response)
        tts._client = mock_client

        result = await tts.synthesize("hello", TTSOptions(voice="alloy"))

        assert isinstance(result, AudioData)
        assert result.data == b"audio_bytes"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_providers/test_openai_tts.py -v`
Expected: FAIL

- [ ] **Step 3: Implement OpenAI TTS adapter**

```python
# openspeechapi/providers/tts/openai.py
"""OpenAI TTS provider adapter."""
from __future__ import annotations

from dataclasses import dataclass

from openspeechapi.core.base import TTSProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings


@dataclass
class OpenAITTSSettings(BaseSettings):
    api_key: str = ""
    model: str = "tts-1"
    default_voice: str = "alloy"


class OpenAITTS(TTSProvider):
    name = "openai-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    capabilities = {Capability.STREAMING, Capability.BATCH}

    def __init__(self, settings: OpenAITTSSettings | None = None) -> None:
        self.settings = settings or OpenAITTSSettings()
        self._client = None

    async def start(self) -> None:
        try:
            from openai import AsyncOpenAI
            self._client = AsyncOpenAI(api_key=self.settings.api_key)
        except ImportError:
            raise ImportError("Install openai: pip install openspeechapi[openai]")

    async def stop(self) -> None:
        self._client = None

    async def health_check(self) -> bool:
        return self._client is not None

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started")

        opts = opts or TTSOptions()
        voice = opts.voice or self.settings.default_voice

        response = await self._client.audio.speech.create(
            model=self.settings.model,
            voice=voice,
            input=text,
            speed=opts.speed,
        )
        return AudioData(
            data=response.content,
            sample_rate=24000,
            channels=1,
            format=AudioFormat.MP3,
        )

    async def synthesize_stream(self, text: str, opts: TTSOptions | None = None):
        raise NotImplementedError("Use synthesize for now; streaming TBD")
        yield  # pragma: no cover
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/unit/test_providers/test_openai_tts.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add openspeechapi/providers/tts/openai.py tests/unit/test_providers/test_openai_tts.py
git commit -m "feat: OpenAI TTS adapter"
```

---

## Chunk 9: Remaining Provider Adapters (Stubs)

The remaining 9 adapters follow the exact same pattern. For Phase 1 delivery, we create working stubs with proper settings, capabilities, and structure — full implementations depend on specific SDK access.

### Task 23: Create all remaining adapter stubs

**Files:**
- Create: `openspeechapi/providers/stt/faster_whisper.py`
- Create: `openspeechapi/providers/stt/whisper.py`
- Create: `openspeechapi/providers/stt/deepgram.py`
- Create: `openspeechapi/providers/tts/fish_speech.py`
- Create: `openspeechapi/providers/tts/piper.py`
- Create: `openspeechapi/providers/tts/coqui.py`
- Create: `openspeechapi/providers/tts/cosyvoice.py`
- Create: `openspeechapi/providers/tts/elevenlabs.py`
- Create: `openspeechapi/providers/tts/minimax.py`

Each adapter follows this structure:
1. Dataclass settings with provider-specific fields
2. Provider class with correct `name`, `provider_type`, `execution_mode`, `capabilities`
3. `start()` imports the SDK (lazy) and initializes the client
4. `transcribe()`/`synthesize()` calls the SDK
5. Placeholder streaming if not yet implemented

- [ ] **Step 1: Implement all 9 adapter stubs**

_(Each adapter follows the template pattern. The key details per adapter are:)_

| File | Class | Default ExecMode | Capabilities | SDK |
|------|-------|------------------|-------------|-----|
| `stt/faster_whisper.py` | `FasterWhisperSTT` | SUBPROCESS | BATCH, MULTILINGUAL, WORD_TIMESTAMPS | `faster-whisper` |
| `stt/whisper.py` | `WhisperSTT` | SUBPROCESS | BATCH, MULTILINGUAL | `whisper` |
| `stt/deepgram.py` | `DeepgramSTT` | IN_PROCESS | STREAMING, BATCH, MULTILINGUAL | `deepgram-sdk` |
| `tts/fish_speech.py` | `FishSpeechTTS` | IN_PROCESS | STREAMING, VOICE_CLONE | `httpx` |
| `tts/piper.py` | `PiperTTS` | IN_PROCESS | BATCH | `piper-tts` |
| `tts/coqui.py` | `CoquiTTS` | IN_PROCESS | VOICE_CLONE, MULTILINGUAL | `httpx` |
| `tts/cosyvoice.py` | `CosyVoiceTTS` | SUBPROCESS | VOICE_CLONE, MULTILINGUAL | `httpx` |
| `tts/elevenlabs.py` | `ElevenLabsTTS` | IN_PROCESS | STREAMING, VOICE_CLONE, EMOTION | `elevenlabs` |
| `tts/minimax.py` | `MinimaxTTS` | IN_PROCESS | STREAMING | `httpx` |

- [ ] **Step 2: Write one test per adapter verifying settings and capabilities**

- [ ] **Step 3: Run tests**

Run: `pytest tests/unit/test_providers/ -v`
Expected: All PASS

- [ ] **Step 4: Commit**

```bash
git add openspeechapi/providers/ tests/unit/test_providers/
git commit -m "feat: all 11 provider adapter stubs with settings and capabilities"
```

---

## Chunk 10: Final Polish

### Task 24: Run full test suite and verify coverage

- [ ] **Step 1: Run full test suite with coverage**

Run: `pytest --cov=openspeechapi --cov-report=term-missing -v`
Expected: 80%+ coverage, all tests pass

- [ ] **Step 2: Fix any failing tests or coverage gaps**

- [ ] **Step 3: Run ruff linter**

Run: `ruff check openspeechapi/ tests/`
Expected: No errors

- [ ] **Step 4: Commit any fixes**

```bash
git add -A
git commit -m "chore: fix linting and coverage gaps"
```

---

### Task 25: Update project documentation

- [ ] **Step 1: Verify providers.example.yaml is complete and accurate**

- [ ] **Step 2: Update openspeechapi/__init__.py __all__ if any exports were missed**

- [ ] **Step 3: Final commit**

```bash
git add -A
git commit -m "docs: finalize Phase 1 implementation"
```

---

## Summary

| Chunk | Tasks | Focus |
|-------|-------|-------|
| 1 | T1–T5 | Project scaffolding, enums, data models, provider ABCs, registry |
| 2 | T6–T7 | YAML config loading, InvokeContext |
| 3 | T8–T11 | Executor ABC, InProcess, Subprocess (IPC), Remote |
| 4 | T12–T14 | Filters, FanOut/FanIn, ServiceDispatcher |
| 5 | T15–T16 | Observer base, 5 built-in observers |
| 6 | T17–T18 | CLI, top-level exports |
| 7 | T19 | Integration tests |
| 8 | T20–T22 | Adapter template, OpenAI STT, OpenAI TTS |
| 9 | T23 | 9 remaining adapter stubs |
| 10 | T24–T25 | Coverage, linting, docs |

**Total: 25 tasks, ~110 steps, ~25 commits**

**Review fixes applied:**
- Added `settings_cls` class attribute to SpeechProvider for typed settings construction
- Fixed ServiceDispatcher.start() to use provider's settings_cls with config dict
- Added ObserverManager integration — dispatcher now fires observer notifications
- Fixed SubprocessExecutor sys.path to use package root instead of CWD
- Added `__main__.py` for `python -m openspeechapi` support
- Added `__init__.py` for all test directories
- Fixed TracingObserver broken import
- Added LatencyObserver and DebugLogObserver to test file structure

Each chunk produces working, testable software. No chunk depends on a later chunk.
