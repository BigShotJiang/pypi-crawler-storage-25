# Fish-Speech Native Runtime

Native runtime is now available for `fish-speech` with lifecycle actions:

- `install`
- `update`
- `start`
- `stop`
- `status`
- `logs`

## Native Root

- Default native root: `~/AI/services`
- Configurable via CLI `--install-dir`
- Configurable via WebUI `Native Root` input
- Services are managed under: `<native-root>/<engine-name>/`

Example layout:

- `~/AI/services/fish-speech/src` (source repo)
- `~/AI/services/fish-speech/.venv` (isolated venv)
- `~/AI/services/fish-speech/run/native.pid`
- `~/AI/services/fish-speech/run/native.log`

## Notes

- Native install uses `pip install -e .[cpu]` by default.
- Native install auto-downloads `fishaudio/s2-pro` into `checkpoints/s2-pro`.
- On macOS, run with MPS (`native_device=mps`) and keep `compile` disabled.
- You can override model source via options: `native_model_repo`, `native_model_dir`, `native_hf_max_workers`.
- Native install is script-driven by default: `scripts/engines/fish-speech/native/install.sh`.
- The backend parses script progress lines in format:
  `OPENSPEECH_PHASE:<phase>:<progress>:<message>`
  so future engines can be added by predefining installation scripts.
