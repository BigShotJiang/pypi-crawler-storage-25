# STT Native Model Engines

This project now supports native STT local engines:

- `faster-whisper`
- `whisper`
- `whisperlivekit` (service engine, not model-only)
- `sherpa-onnx` (service engine)

`faster-whisper` and `whisper` are model-asset style native engines.
`whisperlivekit` and `sherpa-onnx` are native **service engines** (long-running local server).

## Commands

```bash
openspeechapi engine install --name faster-whisper --runtime native --follow
openspeechapi engine start   --name faster-whisper --runtime native --follow
openspeechapi engine status  --name faster-whisper --runtime native

openspeechapi engine install --name whisper --runtime native --follow
openspeechapi engine start   --name whisper --runtime native --follow
openspeechapi engine status  --name whisper --runtime native

openspeechapi engine install --name whisperlivekit --runtime native --follow
openspeechapi engine start   --name whisperlivekit --runtime native --follow
openspeechapi engine status  --name whisperlivekit --runtime native

openspeechapi engine install --name sherpa-onnx --runtime native --follow
openspeechapi engine start   --name sherpa-onnx --runtime native --follow
openspeechapi engine status  --name sherpa-onnx --runtime native

# install with a real model repo download (instead of simulation)
openspeechapi engine install \
  --name sherpa-onnx \
  --runtime native \
  --model-repo k2-fsa/sherpa-onnx-streaming-zipformer-bilingual-zh-en-2023-02-20 \
  --no-simulate-download \
  --follow
```

## Existing model reuse

Install flow now prioritizes AIM for model resolution and download:

1. Resolve model paths with `aim resolve`
2. If missing and engine has `native_aim_downloads`, run `aim download`
3. Re-resolve from AIM and link to runtime
4. If AIM is unavailable or download still unresolved, fallback to legacy install script flow

Legacy fallback scripts still support local-path linking/simulated download, but they are no longer the first choice when AIM is enabled.

Path resolution details from AIM:

- `~/.aim/config.json` (root mapping)
- `~/.aim/registry.json` (model IDs and provision targets)

Current defaults:

- `faster-whisper` -> model id `faster-whisper-large-v3-turbo`
- `whisper` -> model ids `whisper-large-v3-turbo`, `whisper-large-v3`
- `sherpa-onnx` -> model ids `sherpa-onnx-paraformer-zh-en`, `sherpa-onnx-zipformer-zh-en`

Then it falls back to static local path candidates (configured in engine defaults):

- `faster-whisper`: `~/AI/whisper/faster-whisper-large-v3-turbo`
- `whisper`: `~/AI/whisper/large-v3-turbo.pt`, fallback `~/AI/whisper/large-v3.pt`

If no path exists, install can complete through a simulated download flow (for progress validation).

## WhisperLiveKit service engine

`whisperlivekit` is a local service engine. The default native start command uses
`mlx-whisper` backend, and provider `whisperlivekit-stt` can call it through
Deepgram-compatible WebSocket path `/v1/listen`.

Install mode: source (editable)

- The installer now syncs WhisperLiveKit source into:
  - `~/AI/services/whisperlivekit/src`
- Then installs editable package into:
  - `~/AI/services/whisperlivekit/.venv` via `pip install -e`
- Repo URL/ref can be configured via engine options:
  - `native_repo_url`
  - `native_repo_ref`

## Sherpa model download behavior

Install flow for `sherpa-onnx`:

1. Reuse existing local model paths (AIM + fallback paths)
2. If `native_model_repo` is provided, download from Hugging Face repo via `hf download`
3. If not found/downloaded and `native_simulate_download=true`, create a placeholder model
4. Otherwise, install fails with a clear message
