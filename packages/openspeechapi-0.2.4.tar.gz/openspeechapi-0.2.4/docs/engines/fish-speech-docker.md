# Fish-Speech Docker Runtime

## Install image

```bash
openspeechapi engine install --name fish-speech --runtime docker --follow
```

## Start service

```bash
openspeechapi engine start --name fish-speech --runtime docker --follow
```

By default this starts container `openspeechapi-fish-speech` and exposes port `8080`.

## Check status

```bash
openspeechapi engine status --name fish-speech --runtime docker
```

## Show logs

```bash
openspeechapi engine logs --name fish-speech --runtime docker --lines 200
```

## Stop service

```bash
openspeechapi engine stop --name fish-speech --runtime docker --follow
```

## Optional overrides

- `--image` to choose a custom image
- `--container-name` to avoid conflicts
- `--host-port` to change exposed host port
- `--health-url` if your image uses a non-default health endpoint
