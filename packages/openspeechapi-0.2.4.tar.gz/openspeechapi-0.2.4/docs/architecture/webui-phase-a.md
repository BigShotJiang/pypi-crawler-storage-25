# WebUI Phase A

OpenSpeechAPI now includes a built-in WebUI at `/ui` for:

- Capability Lab: STT and TTS test operations from browser
- Engine Manager: install/update/start/stop local engines with live task progress
- Dashboard: provider health and recent task overview

## How to run

```bash
python -m openspeechapi.cli serve --host 0.0.0.0 --port 8600
# open http://127.0.0.1:8600/ui
```

## API dependencies

The UI consumes these backend endpoints:

- `GET /v1/providers`
- `GET /v1/health`
- `POST /v1/stt/transcribe`
- `POST /v1/tts/synthesize`
- `POST /v1/engines/actions`
- `GET /v1/engines/status`
- `GET /v1/engines/logs`
- `GET /v1/engines/tasks`
- `GET /v1/engines/tasks/{task_id}`
- `GET /v1/engines/tasks/{task_id}/events` (SSE)
- `POST /v1/engines/tasks/{task_id}/cancel`

## E2E

A browser E2E case is provided in:

- `tests/e2e/test_webui_e2e.py`

It validates the TTS page flow from UI action to frontend result rendering.
