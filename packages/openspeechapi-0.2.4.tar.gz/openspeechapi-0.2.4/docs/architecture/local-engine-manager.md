# Local Engine Manager (M1)

`openspeechapi.local_engines` is an engine-runtime layer separated from provider adapters.

## Goals

- Keep provider invocation path lightweight (`fish-speech` provider still calls HTTP API only).
- Support long-running runtime operations with progress feedback.
- Enable one manager core shared by CLI and future WebUI.

## Current scope

- Engine: `fish-speech`
- Runtime backend: `docker` and `native` (both implemented)
- Actions: `install`, `update`, `start`, `stop`, `status`, `logs`
- Persisted tasks: saved under `~/.openspeechapi/engine_tasks/*.json`

## Progress model

Long-running actions emit structured progress events:

- `task_id`
- `engine`
- `action`
- `phase`
- `message`
- `status` (`queued/running/succeeded/failed`)
- `progress` (0-100, when available)

CLI can stream updates in real time:

```bash
openspeechapi engine install --name fish-speech --runtime docker --follow
```

Task history is queryable across processes:

```bash
openspeechapi engine task list --name fish-speech
openspeechapi engine task status --task-id <TASK_ID>
```

## HTTP endpoints (for future WebUI)

- `POST /v1/engines/actions` start an async runtime task
- `GET /v1/engines/tasks` list recent tasks
- `GET /v1/engines/tasks/{task_id}` get one task status
- `GET /v1/engines/tasks/{task_id}/events` SSE stream (`snapshot/progress/done`)
- `POST /v1/engines/tasks/{task_id}/cancel` request cancellation

## Notes

- Docker `start` waits for health check by polling configured health URL.
- Runtime-specific logic is encapsulated in backend implementations, not provider adapters.
- Native runtime defaults to `~/AI/services` as root path for local service management.
