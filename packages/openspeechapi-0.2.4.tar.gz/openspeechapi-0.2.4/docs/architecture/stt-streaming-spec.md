# STT 流式识别开发规范

> 本文档定义了 OpenSpeechAPI 中 STT Provider 实现流式识别 (`transcribe_stream`) 时必须遵循的协议和最佳实践。  
> 所有声明了 `Capability.STREAMING` 的 STT Provider 均适用。

## 1. 整体架构

```
浏览器麦克风 (PCM16, 16kHz)
  │  WebSocket 二进制帧 (~42ms/帧)
  ▼
stt_stream.py  ─── audio_queue ──→  audio_source() async generator
  │                                       │
  │                                       ▼
  │                              Provider.transcribe_stream(stream)
  │                                 ├─ sender task   (音频 → 引擎 WS)
  │                                 ├─ receiver task (引擎 WS → results Queue)
  │                                 └─ yield loop    (Queue → yield Transcription)
  │                                       │
  │  ◄── yield Transcription ─────────────┘
  │
  │  send_json(type="partial" | "final")
  ▼
前端 app.js
  └─ streamTextSnapshot(): 直接替换显示（非追加）
  └─ 收到 "final" → 自动停止录音
  └─ 收到 "closed" → 清理资源
```

## 2. 核心协议：`is_partial` 字段

`Transcription` 数据类包含 `is_partial: bool` 字段（默认 `False`）：

| `is_partial` | 含义 | 服务端转发类型 | 前端行为 |
|:---:|--------|:---:|--------|
| `True` | 中间结果，可能被后续纠正 | `"partial"` | 实时更新显示文本 |
| `False` | 最终结果（VAD / 用户停止） | `"final"` | 更新文本 + **自动停止录音** |

### 规则

1. **流式循环中**每次 yield 的中间结果必须设置 `is_partial=True`
2. **最终结果**（引擎 VAD 触发、连接关闭、用户停止后的最后一次输出）必须设置 `is_partial=False`
3. 服务端 `stt_stream.py` 根据 `is_partial` 自动区分消息类型，Provider 只需正确设置此字段

### 示例

```python
# 中间结果
yield Transcription(text=current_text, is_partial=True)

# 最终结果
yield Transcription(text=final_text, is_partial=False)
```

## 3. 全文快照模式

每次 yield 的 `Transcription.text` 必须是**当前已识别的完整文本快照**，而非增量片段。

前端使用 `streamTextSnapshot()` 直接替换显示内容，如果 yield 的只是当前 utterance 片段，之前已确认的文本会丢失。

### 实现方式

维护一个已确认文本的累积列表，每次 yield 时拼接已确认部分 + 当前中间文本：

```python
confirmed_parts: list[str] = []

# 引擎确认一个 utterance 后
if is_final_utterance:
    confirmed_parts.append(utterance_text)

# 构建快照
snapshot = " ".join(confirmed_parts)       # 已确认部分
if current_interim_text:
    snapshot += " " + current_interim_text  # 当前中间文本

yield Transcription(text=snapshot.strip(), is_partial=True)
```

不同引擎的实现参考：
- **iFlytek**: `segments[]` 数组 + wpgs `pgs`/`rg`/`sn` 纠正协议，`"".join(segments)` 作为快照
- **Deepgram**: `confirmed_parts[]` 累积 `is_final` utterance + 当前 interim，`" ".join(parts)` 作为快照
- **Sherpa-Onnx**: `final_parts[]` + `current_text` 按 segment 累积，`_merge_with_current()` 合并

## 4. sender / receiver 并发模型

`transcribe_stream` 使用两个并发 Task + Queue 模式：

```python
results: asyncio.Queue[Transcription | None] = asyncio.Queue()
_sender_stop = asyncio.Event()

async with websockets.connect(url) as ws:
    async def sender():
        try:
            async for chunk in stream:
                if _sender_stop.is_set():
                    break
                await ws.send(encode(chunk))
            # 发送结束标记
            if not _sender_stop.is_set():
                await ws.send(end_sentinel)
        except websockets.exceptions.ConnectionClosed:
            pass

    async def receiver():
        try:
            async for msg in ws:
                # 解析 → 构建快照 → put to queue
                await results.put(Transcription(text=..., is_partial=True/False))
                if is_end_of_speech:
                    _sender_stop.set()  # 通知 sender 退出
                    break              # 必须 break！否则尾部消息导致重复 final
        except websockets.exceptions.ConnectionClosed:
            _sender_stop.set()
            # emit 已有内容作为 final
        finally:
            _sender_stop.set()
            await results.put(None)  # sentinel

    send_task = asyncio.create_task(sender())
    recv_task = asyncio.create_task(receiver())

    while True:
        item = await results.get()
        if item is None:
            break
        yield item

    # 防挂起清理
    send_task.cancel()
    try:
        await send_task
    except asyncio.CancelledError:
        pass
    await recv_task
```

### 关键要求

| 要求 | 说明 |
|------|------|
| **`_sender_stop` Event** | receiver 完成后通知 sender 退出，避免 sender 永远等待 `stream` 的下一个 chunk |
| **receiver 收到终止信号后 `break`** | 引擎的 VAD/结束标志触发 `is_partial=False` 后必须立即 `break` 退出接收循环，否则引擎后续发送的尾部消息会导致重复 yield final |
| **sender `ConnectionClosed` 容错** | 引擎关闭连接时 sender 不应抛异常（`try/except`） |
| **防挂起 `send_task.cancel()`** | yield 循环结束后 cancel sender，避免 `await send_task` 永久阻塞 |
| **Queue sentinel `None`** | receiver 的 `finally` 块必须 `put(None)` 确保 yield 循环退出 |
| **连接关闭时 emit final** | `ConnectionClosed` 异常中将已有文本作为 `is_partial=False` emit |

## 5. 性能日志（里程碑计时）

每个流式 STT Provider 必须在关键节点输出 `logger` 日志，用于性能分析和问题排查。

### 必须记录的里程碑

| 里程碑 | 时机 | 日志级别 | 包含信息 |
|--------|------|----------|----------|
| WS 连接开始 | `websockets.connect()` 前 | `debug` | Provider 名称 |
| WS 连接完成 | `connect()` 返回后 | `info` | 连接耗时 (ms) |
| 首帧发送 | sender 第一次 `ws.send()` 后 | `debug` | 距起始时间 (ms) |
| 首次响应 | receiver 第一条有效结果 | `debug` | 距起始时间 (ms) + 协议元数据 |
| 最终结果 | `is_partial=False` 时 | `info` | 距起始时间 (ms)、响应总数、文本预览 (前60字符) |
| sender 结束 | sender finally | `debug` | 已发送帧数、总耗时 |
| 流式完成 | yield 循环退出后 | `info` | 总耗时 (ms)、总帧数 |

### 模板代码

```python
_t0 = time.perf_counter()
_frames_sent = 0

logger.debug("{}: connecting to XXX WebSocket...", self.name)
async with websockets.connect(url) as ws:
    _t_connected = time.perf_counter()
    logger.info("{}: WS connected in {:.0f}ms", self.name,
                (_t_connected - _t0) * 1000)

    async def sender():
        nonlocal _frames_sent
        ...
        _frames_sent += 1
        if _frames_sent == 1:
            logger.debug("{}: first frame sent at {:.0f}ms",
                         self.name, (time.perf_counter() - _t0) * 1000)
        ...
        # finally:
        logger.debug("{}: stream sender done, sent {} frames in {:.0f}ms",
                     self.name, _frames_sent, (time.perf_counter() - _t0) * 1000)

    async def receiver():
        _resp_count = 0
        ...
        _resp_count += 1
        if _resp_count == 1:
            logger.debug("{}: first response at {:.0f}ms  ...",
                         self.name, (time.perf_counter() - _t0) * 1000)
        ...
        # final result:
        logger.info("{}: final result at {:.0f}ms  responses={}  text='{}'",
                    self.name, (time.perf_counter() - _t0) * 1000,
                    _resp_count, text[:60])

    # after yield loop:
    logger.info("{}: stream completed in {:.0f}ms, frames={}",
                self.name, (time.perf_counter() - _t0) * 1000, _frames_sent)
```

### 日志分析示例

```
iflytek-stt: connecting to iFlytek WebSocket...
iflytek-stt: WS connected in 120ms
iflytek-stt: first frame sent at 125ms
iflytek-stt: first response at 380ms  sn=0  pgs=apd
iflytek-stt: final result at 4200ms  responses=28  text='今天天气很好...'
iflytek-stt: stream sender done, sent 98 frames in 4210ms
iflytek-stt: stream completed in 4215ms, frames=98
```

通过这些日志可以快速定位：
- **连接慢**：WS connected 时间过长 → 网络/认证问题
- **首帧延迟**：first frame sent 远大于 connected → 前端音频采集延迟
- **首次响应慢**：first response 远大于 first frame → 引擎处理延迟
- **总响应少**：responses 过少 → 帧间隔过大或音频时长过短

## 6. 批量模式帧间 pacing

对于 `transcribe`（批量模式），预录音频不应以全速发送，否则可能触发引擎的读超时。

```python
frame_size = 8000     # ~250ms of 16kHz 16bit mono
frame_interval = 0.01 # 10ms between frames (~25x real-time)

while offset < total:
    await ws.send(chunk)
    if status != 2 and frame_interval > 0:
        await asyncio.sleep(frame_interval)
```

| 参数 | 建议值 | 说明 |
|------|--------|------|
| `frame_size` | 8000 bytes | 批量模式下较大帧减少发送次数 |
| `frame_interval` | 0.01s (10ms) | 帧间延迟，~25x 实时速度 |
| `vad_eos` | 2000ms | 语音结束检测超时，减少等待 |

## 8. 前端音频帧参数

| 参数 | 值 | 说明 |
|------|----|------|
| `createScriptProcessor bufferSize` | `2048` | ~42ms/帧 @ 48kHz 浏览器采样率 |
| 降采样目标 | 16kHz PCM16 mono | ~1366 字节/帧，接近讯飞推荐的 1280 字节 (40ms) |
| 发送方式 | WebSocket 二进制帧 | 每帧直接发送，无额外分帧 |

选择 2048 而非 4096 的原因：
- 4096 @ 48kHz ≈ 85ms/帧 → 延迟过大，部分引擎可能因帧间隔超时
- 2048 @ 48kHz ≈ 42ms/帧 → 接近主流引擎推荐的 40ms 帧间隔

## 9. 服务端 `stt_stream.py` 协议

服务端在流式模式下的消息类型与 Provider `is_partial` 的对应关系：

```python
async for transcription in handle.executor.invoke_stream(...):
    msg_type = "final" if not getattr(transcription, "is_partial", True) else "partial"
    await websocket.send_json({
        "type": msg_type,          # "partial" | "final"
        "text": transcription.text,
        "confidence": transcription.confidence,
        "language": transcription.language,
    })
```

流式结束后发送 `"type": "closed"`，前端据此做最终资源清理。

## 10. 前端自动停止机制

前端收到 `"type": "final"` 后自动停止录音：

1. 停止麦克风（`stream.getTracks().forEach(t => t.stop())`）
2. 断开音频管道（`processor.disconnect()`, `source.disconnect()`）
3. 关闭 AudioContext
4. 状态设为 `"stopped"`
5. WS 连接保持打开，等待 `"closed"` 消息完成最终清理

这确保了引擎 VAD 检测到语音结束后，用户不需要手动点击 Stop。

## 11. Checklist：新增流式 STT Provider

新增支持 `Capability.STREAMING` 的 STT Provider 时，对照以下清单：

- [ ] `transcribe_stream` 返回 `AsyncIterator[Transcription]`
- [ ] 中间结果 `is_partial=True`，最终结果 `is_partial=False`
- [ ] 每次 yield 的 text 是**全文快照**（非增量片段）
- [ ] 使用 `_sender_stop = asyncio.Event()` 协调 sender/receiver
- [ ] sender 包含 `ConnectionClosed` try/except
- [ ] receiver 的 `finally` 必须 `_sender_stop.set()` + `results.put(None)`
- [ ] yield 循环后 `send_task.cancel()` 防挂起
- [ ] receiver 收到终止信号（VAD / status=2 / speech_final）后 `_sender_stop.set()` + `break`
- [ ] 连接异常关闭时将已有文本作为 `is_partial=False` emit
- [ ] 里程碑计时日志：WS 连接、首帧发送、首次响应、最终结果、流式完成（参考第 5 章）
- [ ] 批量模式 `transcribe` 如有 WS 发送，需添加帧间 pacing 防止服务端超时（参考第 6 章）
- [ ] `field_options` 包含所有枚举型 settings 字段
