# OpenSpeechAPI 日志与性能事件规范

> 本文档描述 OpenSpeechAPI 统一日志系统的字段契约、事件枚举、配置方式
> 以及 LLM 解析指引。新增日志 / 事件必须先在此登记再落地，以保证下游
> 消费者（控制台、文件、LLM 分析）的字段稳定性。

## 1. 设计目标

1. **分级开关**：日志详细度（`TRACE` ～ `ERROR`）与性能统计详细度
   （`off / basic / verbose`）独立可调。
2. **结构化**：支持以 JSONL 形式输出到文件，字段扁平、可被 `jq`、
   Loki、OpenSearch 或 LLM 直接检索。
3. **链路贯通**：每一次请求（HTTP、WebSocket、子进程调用）都由一个
   12-hex 的 `request_id` 串起，跨模块、跨线程/协程自动传递。
4. **里程碑可观测**：WS、Dispatcher、Lifecycle、Provider、Audio 五
   层的关键阶段均产出统一命名的 `event` 字段，便于做端到端耗时分析。

## 2. 字段契约

每条结构化日志（控制台 text 可省略部分字段，文件 JSONL 必须包含）都
遵循以下 schema。未列出的额外字段会被放入 `payload` 子对象，保持顶层
字段集稳定。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `ts` | ISO8601 | 事件发生时间 |
| `level` | string | `TRACE / DEBUG / INFO / WARNING / ERROR / CRITICAL` |
| `module` | string | `logger.name`（通常即 Python 模块名） |
| `message` | string | 人读信息；结构化事件可等于 `event` 值 |
| `event` | string | 事件命名空间；见第 4 节。非结构化日志可缺省 |
| `request_id` | string | 12-hex 请求唯一 ID，由中间件 / WS 端点生成 |
| `session_id` | string? | 会话级 ID（多轮对话场景） |
| `provider` | string? | 当前 provider 名（`faster-whisper`、`openai-tts`…） |
| `engine` | string? | 当前引擎别名，通常同 `provider` |
| `phase` | string? | `event` 进一步的子阶段（可选） |
| `elapsed_ms` | number? | 对应 PerfTimer 的耗时（毫秒，2 位小数） |
| `ttfb_ms` | number? | 首字节 / 首响应时间（毫秒） |
| `exception` | object? | `{type, value}`，异常场景填充 |
| `payload` | object? | 其余自由字段（`bytes_sent`、`text_preview`…） |

字段来源：
- 上层业务通过 `bind_context(request_id=..., provider=...)` 绑定上下文，
  下游 `logger.*` 调用自动携带。
- `milestone(event, ...)` / `PerfTimer` 注入 `event`、`elapsed_ms`、
  `ttfb_ms` 等性能字段。

## 3. 配置

### 命令行

```bash
openspeechapi --log-level INFO --log-format json --log-dir logs --log-perf basic serve
```

| 参数 | 环境变量 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `--log-level` | `OPENSPEECH_LOG_LEVEL` | `INFO` | 控制台/文件最低日志级别 |
| `--log-format` | `OPENSPEECH_LOG_FORMAT` | `text` | 控制台输出格式：`text` / `json` |
| `--log-dir` | `OPENSPEECH_LOG_DIR` | `logs` | JSONL 文件目录；传空串禁用文件输出 |
| `--log-perf` | `OPENSPEECH_LOG_PERF` | `basic` | 性能里程碑详细度：`off` / `basic` / `verbose` |

### 程序化

```python
from openspeechapi import configure_logging, bind_context, milestone, Event, PerfTimer

configure_logging(level="INFO", format="json", log_dir="logs", perf="verbose")

with bind_context(request_id="abc123", provider="faster-whisper"):
    with PerfTimer(Event.DISPATCH_TOTAL, method="transcribe"):
        ...
```

### 文件输出

- 位置：`<log_dir>/openspeechapi.jsonl`（默认 `logs/openspeechapi.jsonl`）
- 轮转：单文件 50 MB，保留 14 天（参数可配置）。
- 写入：每条一行 JSON（`\n` 结尾），异步 enqueue 落盘，不阻塞事件循环。

### 与宿主应用集成（wallex 等使用 loguru 的主程序）

当 OpenSpeechAPI 被其他 loguru 应用以库方式集成时，调用
`integrate_with_host()` 即可让本库**不接管 sink**，只在每条记录上打
`record.extra["component"]` 标签，由宿主的 sink 自行处理。

```python
from loguru import logger
from openspeechapi import (
    integrate_with_host,
    openspeech_filter,
    openspeech_level_filter,
)

# 1. 宿主先配置自己的 sink（正常做法）
logger.add("wallex.log", format="{time} | {level} | [{extra[component]}] {message}")

# 2. 一行完成集成：给 OpenSpeechAPI 记录打 tag、设独立级别
integrate_with_host(tag="openspeechapi", level="DEBUG", perf="verbose")

# 之后 OpenSpeechAPI 的 logger.info(...) 会自动走宿主的 sink，
# 且带 record.extra["component"] == "openspeechapi"

# 可选：给一条 sink 单独限定 openspeechapi 的级别
logger.add("wallex.log", filter=openspeech_level_filter("WARNING"))

# 可选：把 openspeechapi 日志分离到独立文件
logger.add("openspeechapi.log", filter=openspeech_filter)
```

`integrate_with_host` 参数：

| 参数 | 说明 |
| --- | --- |
| `tag` | `record.extra["component"]` 的值；默认 `"openspeechapi"` |
| `level` | **仅对 OpenSpeechAPI 记录**生效的最低级别（通过 filter 实现） |
| `perf` | 性能里程碑详细度（`off` / `basic` / `verbose`），独立于宿主日志级别 |
| `attach_sinks` | 默认 `False` — OpenSpeechAPI 把 sink 完全让给宿主；`True` 保留自带的 console/JSONL sink（罕用） |

辅助函数：

- `openspeech_filter(record) -> bool`：判断是否为 OpenSpeechAPI 记录。
- `openspeech_level_filter(min_level)`：返回一个 loguru sink filter，对
  OpenSpeechAPI 记录应用单独的最低级别，其他来源记录不受影响。
- `get_integration_tag()` / `is_host_managed()`：查询当前集成状态。

语义保证：

- `integrate_with_host()` **绝不**调用 `logger.remove()`；宿主已有的 sink
  不会被误删。
- 之后调用 `create_app()` 或任何 openspeechapi API 不会再注册 OpenSpeechAPI 自己
  的 sink（`ensure_configured()` 在 `host_managed=True` 时是 no-op）。
- `tag` 可在运行时通过再次调用 `integrate_with_host(tag="...")` 更新。
- **宿主的 sink 格式字符串**请使用 `{extra[component]}` 读取 tag；注意
  host 自身的日志记录不包含该字段，推荐用 `filter=openspeech_filter` 或
  callable sink（读取 `message.record["extra"].get("component", "")`）
  避免 KeyError。

## 4. 事件枚举（`Event`）

下表即 `openspeechapi.telemetry.perf.Event` 全量值。命名原则：`<layer>.<phase>`；
一旦发布就不允许重命名，只允许新增。

### 4.1 HTTP 层（中间件）
| 事件 | 级别 | payload 字段 |
| --- | --- | --- |
| `http.request_start` | verbose | `method`, `path` |
| `http.request_end` | basic | `method`, `path`, `status_code`, `elapsed_ms`, `error_type?`, `error_message?` |

### 4.2 WebSocket 层
| 事件 | 级别 | payload 字段 |
| --- | --- | --- |
| `ws.accept` | basic | `scope` (stt/tts), `language?`, `sample_rate?` |
| `ws.meta_sent` | verbose | `scope`, `streaming` |
| `ws.first_audio_frame` | basic | `scope`, `bytes`, `elapsed_ms` |
| `ws.first_response` | basic | `scope`, `msg_type`, `elapsed_ms` |
| `ws.partial_sent` | verbose | `scope` |
| `ws.final_sent` | basic | `scope`, `text_preview`, `elapsed_ms` |
| `ws.closed` | basic | `scope`, `mode`, `reason?` |
| `ws.error` | basic | `scope`, `error_type`, `error_message` |
| `ws.total` | basic | `scope`, `mode`, `frames_received?`, `bytes_received?`, `bytes_sent?`, `chunks_sent?`, `elapsed_ms`, `ttfb_ms?` |

### 4.3 Dispatcher 层
| 事件 | 级别 | payload 字段 |
| --- | --- | --- |
| `dispatch.invoke_start` | verbose | `method`, `exec_mode` |
| `dispatch.invoke_end` | verbose | `method`, `elapsed_ms` |
| `dispatch.invoke_error` | basic | `method`, `error_type`, `error_message` |
| `dispatch.stream_start` | basic | `method`, `text_len?` |
| `dispatch.stream_end` | basic | `method`, `items` |
| `dispatch.total` | basic | `method`, `exec_mode`, `elapsed_ms`, `stream_items?` |
| `dispatch.queue_wait` | verbose | `seconds` |
| `dispatch.executor_acquire` | verbose | `elapsed_ms` |

### 4.4 Lifecycle 层
| 事件 | 级别 | payload 字段 |
| --- | --- | --- |
| `lifecycle.provider_init` | basic | `exec_mode`, `elapsed_ms` |
| `lifecycle.provider_warmup` | basic | `elapsed_ms` |
| `lifecycle.provider_ready` | basic | `exec_mode` |
| `lifecycle.provider_stop` | basic | `reason`, `elapsed_ms` |
| `lifecycle.idle_recycle` | basic | `idle_seconds`, `keepalive` |

### 4.5 Provider 层（由 Executor 统一注入）
| 事件 | 级别 | payload 字段 |
| --- | --- | --- |
| `provider.connect` | verbose | 自定义 |
| `provider.first_chunk_sent` | verbose | `bytes` |
| `provider.first_partial` | basic | `elapsed_ms` |
| `provider.final` | basic | `elapsed_ms`, `text_preview` |
| `provider.total` | basic | `method`, `exec_mode`, `elapsed_ms`, `items?` |
| `provider.error` | basic | `phase`, `error_type`, `error_message` |

### 4.6 Audio 工具层（预留）
`audio.decode`, `audio.encode`, `audio.resample` — 按 `basic` 级别打点，
供音频转换模块补齐。

## 5. LLM 解析指引

- **优先字段**：使用 `event` + `elapsed_ms` + `request_id` 即可复现完整
  调用时序。
- **检索模板**：
  - 单请求全链路：`grep '"request_id":"abc123"' openspeechapi.jsonl`
  - TTFB 分析：`jq 'select(.event=="ws.first_response") | .elapsed_ms'`
  - Provider 冷启动耗时：`jq 'select(.event=="lifecycle.provider_init") | {provider, elapsed_ms}'`
- **错误聚类**：`select(.level=="ERROR" and .exception)` 过滤，再按
  `exception.type` 分组。
- **端到端耗时**：`ws.total.elapsed_ms` ≥ `dispatch.total.elapsed_ms`
  ≥ `provider.total.elapsed_ms`，差值即各层本身的开销。

## 6. 贡献规范

1. 新增 `Event` 条目必须：
   - 在 `openspeechapi/telemetry/perf.py` 的 `Event` 枚举中新增；
   - 在本文件 4.x 节中补充一行描述（级别 + payload 字段）；
   - 在发布之前写入单测或集成测试验证。
2. 不允许同名事件改变含义；必须保证字段向后兼容。
3. 纯文本 `logger.info("...")` 保留给"事件化成本过高"的场景，结构化
   事件必须经 `milestone` / `PerfTimer` 产出。
4. 禁止在日志字段里打印大对象（`>1 KB`）；超过时裁剪并标记 `truncated=true`。

## 7. 已知开销

- 控制台 `text` 格式约 30 μs/行；JSONL 文件写入异步 enqueue 约 10 μs/行。
- `PerfTimer` 在 `off` 时完全不落日志（仅 `perf_counter_ns` 成本可忽略）。
- `bind_context` 依靠 `contextvars`，跨 `asyncio.Task` 自动继承，不需要手工显式传递。
