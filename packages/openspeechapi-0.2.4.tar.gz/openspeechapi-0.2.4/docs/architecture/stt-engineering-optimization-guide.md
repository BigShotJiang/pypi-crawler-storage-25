# STT 交互工程优化指南

> 基于 Wallex 项目 Java/Python 双端讯飞 ASR 实现的工程实践总结，
> 提炼出一份通用的实时语音识别（STT）系统工程优化指导文档。

## 一、Java 端讯飞 STT 实现的工程优化分析

### 1.1 架构概览

Java 端的 STT 链路由四层组成：

```
MessageProcessServiceImpl (编排层)
  │ processAudioFrame() → 首帧 / 后续帧分发
  ↓
AsrServiceImpl (ASR 服务层)
  │ startAsync() → connectWithRetry() → drainPendingQueue() → sendToAsr()
  │ AsrWebSocketClient.onMessage() → AsrResultDecoder.decode()
  ↓
VoiceSession (会话状态层)
  │ pendingQueue: LinkedBlockingQueue<AudioFrame>(200)
  │ asrFuture: CompletableFuture<String>
  ↓
讯飞 IAT WebSocket (外部服务)
```

### 1.2 具体工程优化点

#### 1.2.1 异步连接 + 帧缓冲队列（解耦收发）

**核心设计**：收到首帧时不阻塞等待连接完成，而是立即将帧放入 `pendingQueue`，在独立线程池 `asrConnectExecutor` 中异步建连。

```java
// AsrServiceImpl.java L59-91
public void startAsync(String requestId, VoiceSession session, ...) {
    session.setAsrFuture(new CompletableFuture<>());
    session.getPendingQueue().offer(firstFrame);  // 帧立即入队，不等连接

    asrConnectExecutor.submit(() -> {
        AsrWebSocketClient asrWs = connectWithRetry(requestId, session, authUrl);
        drainPendingQueue(requestId, session, asrWs);  // 连接成功后开始消费
    });
}
```

**优化效果**：
- WebSocket 主线程不阻塞，可继续接收后续帧
- 连接建立期间（50-200ms）到达的帧不会丢失
- 首帧处理延迟 = 连接耗时，后续帧处理延迟 ≈ 0

#### 1.2.2 有界队列 + 旧帧淘汰（背压控制）

```java
// VoiceSession.java L84-85
private LinkedBlockingQueue<AudioFrame> pendingQueue = new LinkedBlockingQueue<>(200);

// AsrServiceImpl.java L110-114
synchronized (session.getAsrLock()) {
    if (!session.getPendingQueue().offer(frame)) {
        session.getPendingQueue().poll();   // 满时丢弃最旧帧
        session.getPendingQueue().offer(frame);
    }
}
```

**设计意图**：
- 队列容量 200 帧，按 160ms/帧计算可缓冲 32 秒音频，足够应对连接延迟
- 满时优先丢弃最旧帧（而非阻塞生产者或丢弃新帧），保证实时性
- 使用 `synchronized(asrLock)` 保护 poll+offer 的原子性

**适用场景**：网络抖动或连接重试期间大量帧积压时，优先保留最新音频。

#### 1.2.3 紧循环消费 + 100ms 超时（低延迟转发）

```java
// AsrServiceImpl.java L144-171
private void drainPendingQueue(...) {
    boolean tailSent = false;
    while (!tailSent && !asrWs.isClosed()) {
        AudioFrame frame = session.getPendingQueue().poll(100, TimeUnit.MILLISECONDS);
        if (frame != null) {
            sendToAsr(asrWs, frame, requestId);
            if (frame.getStatus() == 2) {
                tailSent = true;
            }
        }
    }
}
```

**关键特征**：
- **无人工 pacing**：帧到即发，不添加额外延迟
- **100ms poll 超时**：队列空时最多等 100ms，避免无限阻塞；尾帧到达后立即退出
- **双退出条件**：尾帧已发 OR WebSocket 已关闭，覆盖正常和异常情况

**对比反模式**：某些实现会给帧之间加 `sleep(40ms)` 来"模拟实时"，这在流式场景下**完全不必要**——音频本身就是实时到达的，人为限速只会增加延迟。

#### 1.2.4 wpgs 动态修正解码器

```java
// AsrServiceImpl.java L377-416
private static class AsrResultDecoder {
    private AsrTextSegment[] texts;
    private int capacity = 10;

    public synchronized void decode(AsrTextSegment segment) {
        if (segment.sn >= this.capacity) resize();

        if ("rpl".equals(segment.pgs) && segment.rg != null) {
            for (int i = segment.rg[0]; i <= segment.rg[1]; i++) {
                if (this.texts[i] != null) this.texts[i].deleted = true;
            }
        }
        this.texts[segment.sn] = segment;
    }
}
```

**设计要点**：
- 使用定长数组 + 倍增扩容（`capacity <<= 1`），避免频繁内存分配
- `rpl`（替换）操作标记旧段为 `deleted`，不实际删除，toString 时过滤
- `synchronized` 保护并发访问（onMessage 回调在 WS 线程中）
- 每条响应都调用 `toString()` 拼接当前全文并推送，实现实时纠正效果

#### 1.2.5 中间结果即时推送

```java
// AsrServiceImpl.java L327-335
if (status == 2) {
    pushRecognitionResult(currentText, false);     // 最终结果
    session.getAsrFuture().complete(currentText);  // 触发后续流水线
} else if (!currentText.isEmpty()) {
    pushRecognitionResult(currentText, true);      // 中间结果
}
```

**关键行为**：
- **每条**讯飞响应（不论 status）都推送给前端，`partial=true` 表示中间结果
- 前端可实时显示正在识别的文字，用户感知延迟大幅降低
- 最终结果通过 `CompletableFuture.complete()` 解锁 AI 对话阶段，实现流水线衔接

#### 1.2.6 指数退避重试（连接可靠性）

```java
// AsrServiceImpl.java L176-203
int[] backoffMs = {300, 600, 1200};
for (int attempt = 0; attempt < MAX_RETRY; attempt++) {
    boolean connected = client.connectBlocking(asrConfig.getTimeout(), TimeUnit.SECONDS);
    if (connected) return client;
    TimeUnit.MILLISECONDS.sleep(backoffMs[attempt]);
}
```

**设计**：
- 最多 4 次重试，退避间隔 300ms → 600ms → 1200ms
- 连接超时 15 秒（`asrConfig.getTimeout()`）
- 失败后抛 `AsrException(ASR_BUSY)` 向上传播

#### 1.2.7 CompletableFuture 流水线编排 + 超时保护

```java
// MessageProcessServiceImpl.java L169-198
voiceSession.getAsrFuture()
    .orTimeout(15, TimeUnit.SECONDS)              // ASR 阶段 15s 超时
    .exceptionally(ex -> { ... })                  // 超时时关闭连接
    .thenApplyAsync(asrText -> {
        return processAIAndTts(voiceSession, text); // AI + TTS
    }, businessExecutor)
    .orTimeout(60, TimeUnit.SECONDS)              // 整体 60s 超时
    .whenComplete((result, ex) -> handleCompletion(...));
```

**优势**：
- ASR → AI → TTS 通过 Future 链自动衔接，无需手动回调嵌套
- 每阶段独立超时（ASR 15s，整体 60s），任何环节超时都能兜底
- `businessExecutor` 独立线程池（50 线程），避免阻塞 ASR 连接线程

#### 1.2.8 帧级延迟追踪日志

```java
// AsrServiceImpl.java L152-157
long timeSinceReceive = System.currentTimeMillis() - frame.getReceiveTime();
frameLog.append("seq=").append(frame.getSeq()).append("/").append(timeSinceReceive).append("ms");

// 输出示例：
// ASR 队列消费完成，requestId: xxx，[seq=1/45ms, seq=2/12ms, seq=3/8ms, ...]
```

每帧记录从"WebSocket 收到"到"实际发给讯飞"的延迟，可精确定位瓶颈。

### 1.3 Java 端未优化 / 可改进的点

| 项目 | 现状 | 改进建议 |
|------|------|----------|
| vad_eos 未传给讯飞 | `AsrConfig.eos=2000` 配置了但 `sendToAsr()` 的 business 字段未包含 | 补充 `business.put("vad_eos", asrConfig.getEos())` |
| 帧大小由前端决定 | Java 端不裁剪不聚合，完全透传 | 合理，但需与前端配合控制分帧粒度 |
| 无 base64 编解码 | 前端 → Java → 讯飞全程 base64 透传，不做 decode/re-encode | 高效：避免不必要的 CPU 消耗 |
| 无连接池 / 复用 | 每次语音请求新建 WebSocket 连接 | 可考虑连接预热或池化（但讯飞 IAT 是一次性连接） |
| 会话清理 | 仅在 `handleCompletion` 和 `cleanupSession` 中清理 | 可增加定时扫描兜底清理泄露会话 |

---

## 二、Python (OpenSpeechAPI) 端已完成的对齐优化

基于 Java 端分析和三轮实测迭代，Python 端已完成以下优化：

| 优化项 | Java | Python 状态 |
|--------|------|-------------|
| 帧缓冲队列 | `LinkedBlockingQueue(200)` | `asyncio.Queue()`（无界，async 天然背压）✅ |
| 异步连接 + 帧桥接 | `asrConnectExecutor` + 队列 | `asyncio.create_task` + `frame_queue` ✅ |
| wpgs 动态修正 | `AsrResultDecoder` | `receiver()` 中 segments 数组 ✅ |
| 中间结果推送 | 每条响应推 `partial=true` | `RESP_ASR_PARTIAL` + `RESP_SPEECH_RECOGNITION` ✅ |
| 无人工 pacing | 紧循环，帧到即发 | `sender()` 中无 sleep ✅ |
| sender 崩溃保护 | N/A（Java 阻塞模型不存在） | `_sender_stop` Event + try/except ✅ |
| 客户端分帧 | 由前端控制 | 400ms → 160ms ✅ |
| vad_eos | 配置 2000（未传） | 3000 → 2000 ✅ |
| **Provider 预热** | Spring Bean 启动即初始化 | 应用启动时 `ensure_ready()` ✅ |
| **Final 结果立即回调** | `asrFuture.complete()` 在 onMessage 中立即触发 | 收到 `is_partial=False` 时立即调用 `on_result` ✅ |
| **前端自动停止录音** | 前端手动控制 | 收到 final 结果后自动 `stopVoice()` ✅ |

### 2.1 三轮实测优化效果对比

| ��标 | 第1轮 (基础实现) | 第2轮 (+预热) | 第3轮 (+立即回调) |
|------|----------------|-------------|-----------------|
| Provider start 延迟 | 3865ms | **0ms** | 0ms |
| 首帧发出 | T=6054ms | T=2492ms | **T=2198ms** |
| 首个 partial | T=7439ms | T=4949ms | **T=4408ms** |
| Final result | T=7719ms | T=5858ms | **T=5860ms** |
| final→on_result | ~1650ms | ~1650ms | **1ms** |
| ASR done (可用) | T=9341ms | T=7508ms | **T=5861ms** |
| "session not found" | 25条 | 1条 | **0条** |
| 无效帧浪费 | 59帧 | 48帧 | **38帧** |

**累计优化**：ASR 可用时间从 9.3s 降至 5.9s（**-3.4s，减少 37%**）。

### 2.2 发现的关键问题与修复

#### 问题 1: Provider Lazy-Start 阻塞（-3.9s）

**��象**：首次语音请求时 `ensure_ready()` 触发 provider 初始化（创建 httpx client），耗时 3.9s。
期间 `transcribe_stream()` 被阻塞，但 `feed_frame()` 继续向 `frame_queue` 塞帧，导致建连前积压 38 帧。

**修复**：在 `SpeechManager.start()` 中预热活跃引擎：
```python
# speech.py — start() 尾部
for alias in (self._stt_engine, self._tts_engine):
    await self._dispatcher._lifecycle.ensure_ready(alias)
```

#### 问题 2: Final 结果延迟回调（-1.65s）

**现象**：`_transcribe_stream()` 中 `async for` 循环在 iflytek receiver 放入 sentinel 后才退出，
但 dispatcher 还要执行 `await send_task` / `await recv_task` 等清理逻辑（1.6s），导致 `on_result` 延迟触发。

**修复**：在收到 `is_partial=False` 的 final Transcription 时，立即在循环内调用 `on_result()`：
```python
# speech.py — _transcribe_stream() 中
if transcription.is_partial:
    session.on_partial(text)
else:
    # Final result — fire immediately, don't wait for loop cleanup
    session.on_result(text)
```

#### 问题 3: 前端 ASR 完成后仍发帧��-25 条告警）

**现象**：ASR 完成并清理 session 后，前端仍在发音频帧，产生大量 "session not found" 告警。

**修复**：
1. 后端 `_on_asr_result` 发送 `RESP_SPEECH_RECOGNITION(partial=false)` 通知前端
2. 前端收到 final 结果后自动调用 `stopVoice()`：
```javascript
// App.vue — onMessage handler
if (payload.partial === false && voiceState.value === 'recording') {
    stopVoice()
}
```

### 2.3 剩余瓶颈

讯飞 WebSocket 建连耗时 **2.0-2.5s**（纯网络延迟），是当前最大瓶颈。
建连期间音频帧在队列中积压（~10帧），建连完成后 ~500ms 内消化。

可能的改进方向：
- 使用更低延迟的网络线路 / 国内节点
- 本地 STT 引擎（如 sherpa-onnx）消除网络依赖
- 连接预建（用户点录音前就建连，但讯飞 IAT 是一次性连接，难以复用）

---

## 三、通用 STT 交互工程优化指南

以下是从实践中提炼出的通用优化原则，适用于任何实时 STT 系统。

### 3.1 延迟分解模型

一次完整的语音识别延迟可分解为：

```
T_total = T_chunk + T_network + T_connect + T_queue + T_engine + T_vad_tail + T_push

T_chunk      客户端音频分帧攒包延迟（由分帧大小决定）
T_network    客户端 → 服务端 → STT 引擎的网络传输延迟
T_connect    STT 引擎 WebSocket 首次建连延迟
T_queue      服务端内部帧排队等待延迟
T_engine     STT 引擎处理延迟（编解码 + 声学模型 + 语言模型）
T_vad_tail   VAD 端点检测的尾部静音等待（vad_eos）
T_push       结果推送到客户端的延迟
```

### 3.2 分帧策略优化

#### 原则：分帧粒度决定系统响应下限

| 分帧大小 | 对应音频时长 (16kHz/16bit) | 帧率 | 适用场景 |
|----------|--------------------------|------|----------|
| 640 bytes | 20ms | 50 fps | 极致低延迟（对讲机、实时翻译）|
| 1280 bytes | 40ms | 25 fps | 讯飞推荐值，均衡选择 |
| **2560 bytes** | **80ms** | **12.5 fps** | 内网低延迟场景 |
| **5120 bytes** | **160ms** | **6.25 fps** | **推荐：Web 场景均衡点** |
| 12800 bytes | 400ms | 2.5 fps | 过大，延迟明显 |

**Web 场景推荐 160ms（5120 bytes）的理由**：
- WebSocket JSON 消息有固定开销（header + base64 膨胀 33%），太小帧浪费带宽
- 浏览器 AudioWorklet 回调粒度 128 samples (8ms)，160ms = 20 次回调，攒包开销可忽略
- 6.25 fps 足以让 partial 结果流畅更新（人眼阅读刷新率 ~5Hz）
- 比 400ms 降低首字延迟 ~240ms

#### 分帧实现要点

```
DO:
  ✅ 在 AudioWorklet 中攒包，到达阈值立即发送
  ✅ 录音停止时立即发送剩余缓冲（不等凑满）
  ✅ 首帧携带 status=0，尾帧携带 status=2，中间帧 status=1

DON'T:
  ❌ 在 AudioWorklet 内做 base64 编码（process() 是实时线程）
  ❌ 用 setInterval 定时发送（与音频流不同步）
  ❌ 攒包到数秒后一次性发送（失去流式优势）
```

### 3.3 服务端帧转发优化

#### 原则：帧到即发，零缓冲透传

```
DO:
  ✅ 收到帧立即放入 STT 引擎的发送队列/管道
  ✅ 使用异步 I/O（asyncio / NIO），避免阻塞等待
  ✅ STT 连接建立与帧接收解耦（队列桥接）

DON'T:
  ❌ 在服务端对帧加 sleep/pacing（实时流自带节奏）
  ❌ 等连接建立后才开始接收帧（帧会丢失）
  ❌ 在中间层做不必要的 base64 decode/re-encode
```

#### 特殊情况：预录音频的批量发送

当发送预录音频（非实时流）时，需要人工限速避免 STT 服务端超时：

```python
# 批量模式下需要 pacing，但不要太慢
frame_interval = 0.01   # 10ms 间隔 ≈ 25x 实时速度（8000 bytes/帧）
# 太快 → 服务端 read timeout
# 太慢 → 不必要的延迟
```

### 3.4 STT 引擎连接管理

#### 3.4.1 连接时机

| 策略 | 延迟 | 资源消耗 | 适用场景 |
|------|------|----------|----------|
| **按需建连** | +100-200ms | 最低 | 低频使用，成本敏感 |
| **预建连（连接池）** | 0ms | 中等 | 高频使用，延迟敏感 |
| **首帧触发 + 帧队列缓冲** | 0ms（用户无感知） | 最低 | **推荐：均衡方案** |

推荐"首帧触发 + 帧队列缓冲"方案：首帧到达时异步建连，同时将帧放入缓冲队列。连接建立后立即消费队列中积压的帧。用户不会感知到连接延迟，因为帧不会丢失。

#### 3.4.2 Provider / 引擎��热

STT 引擎通常有初始化开销（加载模型、创建 HTTP 客户端、建立连接池等）。如果采用 lazy-start 策略，
首次请求会承担全部��始化延迟。

```
推荐策略：应用���动时预热活跃引擎

DO:
  ✅ 在 startup 阶段调用引擎的 start() / ensure_ready()
  ✅ 预热失败只记告警，不阻止应用启动（降级为 lazy-start）
  ✅ 引擎切换时预热新引擎

DON'T:
  ❌ 预热所有已注册引擎（浪费资源）
  ❌ 预热失败时 panic / 退出（影响可用性）
```

**实测数据**：讯飞 STT provider lazy-start 耗时 3.9s，预热后首请求节省 3.9s。

#### 3.4.3 连接重试

```
推荐策略：指数退避，3-4 次重试
  - 间隔：300ms → 600ms → 1200ms
  - 连接超时：10-15 秒
  - 最终失败：向客户端报 ASR_BUSY 错误

注意：
  - 重试期间帧继续入队，不阻塞前端
  - 重试成功后消费队列中积压帧
  - 超过重试次数后清空队列、关闭会话
```

#### 3.4.3 连接关闭处理

STT 服务可能在以下情况下主动关闭 WebSocket：
- 服务端 VAD 检测到长时间静音（vad_eos 超时）
- 服务端 read timeout（长时间未收到帧）
- 服务端错误 / 限流

**必须**在 sender 侧捕获连接关闭异常并优雅退出，避免崩溃：

```python
# ✅ 正确做法
async def sender():
    try:
        async for chunk in stream:
            if _stop_signal.is_set():
                break
            await ws.send(chunk)
    except ConnectionClosed:
        pass  # 服务端关闭，正常退出

# ❌ 错误做法
async def sender():
    async for chunk in stream:
        await ws.send(chunk)  # 连接关闭时直接崩溃
```

### 3.5 VAD（端点检测）策略

#### 3.5.1 vad_eos 参数选择

`vad_eos` 控制 STT 引擎在检测到多长时间的静音后认为用户说完：

| vad_eos | 行为 | 适用场景 |
|---------|------|----------|
| 1000ms | 激进，短停顿可能误切 | 快节奏交互、简短指令 |
| **2000ms** | **均衡，覆盖自然停顿** | **推荐：通用场景** |
| 3000ms | 保守，长等待 | 长句朗读、口述 |
| 5000ms+ | 过于保守 | 不建议 |

#### 3.5.2 客户端 VAD vs 服务端 VAD

| 方案 | 实现位置 | 优点 | 缺点 |
|------|----------|------|------|
| 服务端 VAD | STT 引擎内置 | 精度高（声学模型参与） | 延迟增加 vad_eos |
| 客户端 VAD | 浏览器 / 端侧 | 延迟最低 | 精度低，易误触发 |
| **手动停止** | 用户点击按钮 | 精度 100%，无等待 | 需要用户操作 |
| **混合模式** | 客户端 + 服务端 | 兼顾延迟和精度 | 实现复杂 |

**推荐**：手动停止为主（用户按住说话 / 点击停止），服务端 VAD 作为兜底。

当用户手动停止时：
1. 客户端立即发送 `status=2` 尾帧
2. 服务端转发给 STT 引擎
3. STT 引擎不再等待 vad_eos，直接返回最终结果

当用户不手动停止时：
1. STT 引擎服务端 VAD 检测到静音 → 返回 `status=2` 最终结果
2. 需要 sender 侧正确处理连接关闭（见 3.4.3）

### 3.6 中间结果（Partial Results）处理

#### 3.6.1 为什么中间结果很重要

STT 引擎在处理音频流的过程中会持续输出中间识别结果。这些结果可能不完整或不准确，但对用户体验至关重要：

- **感知延迟降低**：用户看到文字逐渐出现，心理等待感大幅减少
- **错误提前发现**：用户说到一半发现识别方向错误，可以及时纠正
- **交互反馈**：确认系统"在听"，而不是无响应

#### 3.6.2 wpgs 动态修正协议（讯飞特有）

讯飞 IAT 的 `dwa=wpgs` 模式启用动态修正，响应中包含：

```json
{
  "data": {
    "status": 1,
    "result": {
      "sn": 3,                    // 段落编号
      "pgs": "rpl",               // "rpl"=替换, "apd"=追加
      "rg": [2, 3],               // 替换范围：段落 2~3
      "ws": [{"cw": [{"w": "关闭卧室灯"}]}]
    }
  }
}
```

**解码逻辑**：

```
维护段落数组 segments[]

对每条响应：
  if pgs == "rpl":
    将 segments[rg[0]..rg[1]] 标记为删除/清空
    将新文本写入 segments[sn]
  elif pgs == "apd":
    将新文本写入 segments[sn]
  else:
    （无 wpgs 的传统模式）写入 segments[sn]

  当前全文 = 拼接所有未删除的 segments
  推送给客户端（partial=true / false）
```

**效果示例**：
```
partial 1: "关"
partial 2: "关闭"
partial 3: "关闭我是"        ← 引擎初步猜测
partial 4: "关闭卧室"        ← rpl 修正：替换了 "我是" → "卧室"
partial 5: "关闭卧室灯"
final:     "关闭卧室灯"      ← status=2，最终结果
```

#### 3.6.3 通用中间结果处理原则

```
DO:
  ✅ 每条引擎响应都推送给客户端（区分 partial / final）
  ✅ 客户端对 partial 结果直接覆盖显示（不追加）
  ✅ 支持引擎的动态修正协议（如 wpgs）
  ✅ final 结果触发后续流水线（AI 对话等）

DON'T:
  ❌ 只等最终结果（用户体验差）
  ❌ 对 partial 结果做业务处理（内容不稳定）
  ❌ 累积多条 partial 后批量推送（失去实时性）
```

### 3.7 流水线编排与超时保护

#### 3.7.1 异步流水线

语音交互通常包含多阶段流水线：ASR → AI → TTS。推荐使用异步编排：

```
Java:   CompletableFuture 链式调用
Python: asyncio.create_task + await
```

**关键设计**：
- 每阶段独立超时，任何环节超时都能兜底
- ASR 完成（final result）自动触发 AI 阶段，无需轮询
- 各阶段使用独立线程池 / 任务调度，避免互相阻塞

#### 3.7.2 Final 结果立即回调（关键优化）

流式 STT 的常见实现模式是 sender/receiver 两个并发协程 + 结果队列。
当 receiver 收到 final result 后，还需要等 sender 清理（关闭连接、drain 队列等），
这段清理时间可达 1-2 秒，如果等清理完才触发回调，会白白增加延迟。

```
❌ 错误：等流式循环结束后才触发后续流水线
    async for result in stt_stream(...):
        collect(result)
    # 这里才触发 → 多等 1-2s
    on_result(final_text)

✅ 正确：收到 final result 时立即触发，与清理并行
    async for result in stt_stream(...):
        if result.is_partial:
            on_partial(result.text)
        else:
            on_result(result.text)  # ← 立即触发！
    # 清理在后台进行，不阻塞业务
```

**实测数据**：此优化将 final result 到 `on_result` 的延迟从 1650ms 降至 1ms。

#### 3.7.3 前端自动停止录音

当服务端返回 ASR final result 时，应通知前端停止录音，避免：
- 前端继续发送无效音频帧（浪费带宽、触发 "session not found" 告警）
- 用户需要手动点击停止按钮（体验差）

```
服务端: 发送 RESP_SPEECH_RECOGNITION(partial=false)
前端:   收到后自动调用 stopVoice()
```

注意区分 partial 和 final：只有 `partial === false` 时才触发自动停止。

#### 3.7.2 超时设置参考

| 阶段 | 推荐超时 | 说明 |
|------|----------|------|
| STT 引擎连接 | 10-15s | 含重试 |
| STT 识别 | 15-30s | 含 vad_eos 等待 |
| AI 对话 | 30-60s | LLM 推理可能较慢 |
| TTS 合成 | 15-30s | 含音频传输 |
| 整体端到端 | 60-120s | 兜底超时 |

### 3.8 可观测性

#### 3.8.1 关键指标

| 指标 | 采集点 | 意义 |
|------|--------|------|
| `T_first_frame` | 服务端收到首帧的时刻 | 流水线起点 |
| `T_connect` | STT 连接建立完成 | 连接延迟 |
| `T_first_partial` | 收到第一条中间结果 | 首字延迟 |
| `T_vad_end` | 收到尾帧(status=2) | 用户说话总时长 |
| `T_final_result` | 收到最终识别结果 | VAD→文字延迟 |
| `frame_count` | 发送帧总数 | 音频量 |
| `frame_lag` | 每帧: 收到时刻 - 发送时刻 | 帧级转发延迟 |
| `partial_count` | 中间结果总条数 | 引擎响应频率 |

#### 3.8.2 帧级延迟日志

```
// Java 实现：每帧记录 receiveTime → sendTime 差值
ASR 队列消费完成 [seq=1/45ms, seq=2/12ms, seq=3/8ms, seq=4/7ms, ...]
                   ↑首帧含连接时间  ↑后续帧：纯转发延迟
```

这种日志格式可以精确定位：
- 首帧延迟是否由连接耗时主导
- 后续帧是否有积压
- 是否存在某帧的异常高延迟

#### 3.8.3 Python 端完整时序日志示例

以下是优化后的一次实际交互日志（说 "Turn on bedroom light"）：

```
[客户端] ▶ 开始录音
[客户端] 🎤 首帧发送  seq=1  t=165ms              ← 攒满160ms后发出

[WsHandler] Voice first frame  reqId=18d335a4
[Speech-STT] session started  mode=streaming  engine=iflytek-stt
[Speech-STT] >> stream start
  iflytek-stt: connecting to iFlytek WebSocket...   ← T=0ms

[Speech-STT]    frame #2  queue=2   t=342ms         ← 建连期间帧入队
[Speech-STT]    frame #10 queue=10  t=1442ms         ← 积压 10 帧

  iflytek-stt: WS connected in 2197ms               ← 建连完成
  iflytek-stt: first frame sent at 2198ms            ← 立即消费积压

[Speech-STT]    frame #20 queue=1   t=3039ms         ← 积压已消化 ✅
  iflytek-stt: first response at 4407ms  sn=1        ← 讯飞首条响应

[Speech-STT]    partial #1  t=4408ms  text='Good'
[Speech-STT]    partial #2  t=4408ms  text='Good morning'
[Speech-STT]    partial #6  t=5062ms  text='Turn on bedroom light'  ← wpgs 修正
  iflytek-stt: final result at 5860ms  text='Turn on bedroom light.'

[Speech-STT] << final result  t=5861ms               ← 立即回调
[WsHandler] ASR done: 'Turn on bedroom light.'  (ASR_total=5861ms)

[客户端] ← ASR(final): "Turn on bedroom light."  t=5900ms
[客户端] ASR final → auto stop recording             ← 自动停止 ✅

[WsHandler] AI done  is_control=True  llm1=3575ms
[WsHandler] VAD end (last frame)                      ← 0条 "session not found" ✅
```

**关键时间点**：
- 客户端首帧发出: T=165ms（分帧延迟）
- 讯飞 WS 建连: 2197ms（网络延迟，不可优化）
- 首个 partial 到达客户端: T≈4.5s
- Final 结果到达客户端: T≈5.9s
- 前端自动停止录音: T≈5.9s（收到 final 后立即）
- AI 处理完成: T≈9.5s

### 3.9 安全与资源管理

#### 3.9.1 会话清理

```
必须实现的清理路径：
  1. 正常完成：ASR final → AI → TTS → cleanup
  2. 超时取消：超时触发 → 关闭 STT 连接 → cleanup
  3. 客户端断开：WebSocket onClose → 取消所有 Future → cleanup
  4. 异常退出：catch → cleanup
  5. 兜底扫描：定时任务清理超时未关闭的会话（防泄露）
```

#### 3.9.2 CAS 防重复完成

```java
// Java: AtomicBoolean + CAS
public boolean markCompleted() {
    return completed.compareAndSet(false, true);
}
```

确保会话完成逻辑（清理资源、发送响应）只执行一次，即使多个线程同时触发完成。

### 3.11 端到端优化清单

| 优先级 | 优化项 | 预期收益 | 实现难度 | 实测验证 |
|--------|--------|----------|----------|----------|
| **P0** | 客户端分帧 ≤ 200ms | 首字延迟 -200ms+ | 低 | 400ms→160ms ✅ |
| **P0** | 每条响应推送 partial | 感知延迟大幅降低 | 低 | wpgs partial ✅ |
| **P0** | sender 异常处理 | 避免不点停止时崩溃 | 低 | _sender_stop ✅ |
| **P0** | **Provider 预热** | **首请求延迟 -3.9s** | **低** | **ensure_ready ✅** |
| **P0** | **Final 结果立即回调** | **回调延迟 1650ms→1ms** | **低** | **循环内触发 ✅** |
| **P0** | **前端自动停止录音** | **消除无效帧、改善体验** | **低** | **auto stop ✅** |
| **P1** | vad_eos = 2000ms | 尾部等待 -1s | 配置项 | 3000→2000 ✅ |
| **P1** | 异步建连 + 帧队列缓冲 | 首帧延迟 → 0（用户无感） | 中 | Queue 桥接 ✅ |
| **P1** | wpgs 动态修正 | 中间结果准确率提升 | 中 | rpl/apd ✅ |
| **P1** | 帧级延迟日志 | 精确定位瓶颈 | 低 | queue depth ✅ |
| **P2** | 连接重试（指数退避） | 网络抖动容错 | 中 | |
| **P2** | 阶段超时保护 | 异常场景不卡死 | 中 | |
| **P2** | 有界队列 + 旧帧淘汰 | 极端积压保护 | 低 | |
| **P3** | 连接预热 / 池化 | 消除建连延迟 | 高（受限于引擎协议） | |
| **P3** | 客户端 VAD 辅助 | 减少无效音频传输 | 高 | |
| **P3** | 帧压缩（Speex/Opus） | 带宽节省 50-80% | 中（需引擎支持） | |

---

## 四、附录：讯飞 IAT WebSocket 协议要点速查

### 请求格式

```json
{
  "common": { "app_id": "..." },
  "business": {
    "language": "zh_cn",
    "domain": "iat",
    "accent": "mandarin",
    "dwa": "wpgs",
    "vad_eos": 2000
  },
  "data": {
    "status": 0,
    "format": "audio/L16;rate=16000",
    "encoding": "raw",
    "audio": "<base64>"
  }
}
```

- `common` + `business` 仅首帧携带
- 中间帧只需 `data`（status=1）
- 尾帧 `data.status=2`，`audio` 可为空串

### 响应格式

```json
{
  "code": 0,
  "data": {
    "status": 1,
    "result": {
      "sn": 1,
      "pgs": "rpl",
      "rg": [0, 1],
      "ws": [
        { "cw": [{ "w": "关闭" }] },
        { "cw": [{ "w": "卧室灯" }] }
      ]
    }
  }
}
```

- `code != 0` 为错误
- `data.status == 2` 为最终结果
- `pgs` / `rg` 仅在 `dwa=wpgs` 模式下出现
