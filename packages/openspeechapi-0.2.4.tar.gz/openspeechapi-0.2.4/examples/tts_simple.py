"""最简 TTS demo — 只通过字符串指定 provider，无需知道任何实现类."""
import asyncio
import os
import wave

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from openspeechapi import create_provider


async def main():
    # 1. 通过名称创建 provider，settings 作为关键字参数传入
    tts = create_provider("openai-tts", api_key=os.environ["OPENAI_API_KEY"])

    # 2. 启动
    await tts.start()

    # 3. 合成
    audio = await tts.synthesize("你好，这是 OpenSpeechAPI 的语音合成演示。")
    print(f"合成完成: {len(audio.data):,} bytes, {audio.sample_rate}Hz")

    # 4. 保存为 WAV
    with wave.open("output.wav", "wb") as wf:
        wf.setnchannels(audio.channels)
        wf.setsampwidth(2)
        wf.setframerate(audio.sample_rate)
        wf.writeframes(audio.data)
    print("已保存: output.wav")

    # 5. 停止
    await tts.stop()


if __name__ == "__main__":
    asyncio.run(main())
