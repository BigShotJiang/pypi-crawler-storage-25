"""最简 Client TTS demo — 通过 HTTP 调用远端 OpenSpeechAPI 服务合成语音.

先启动服务:  openspeechapi serve --config providers.yaml --port 8600
再运行本脚本: python examples/client_tts.py
"""
import asyncio
import wave

from openspeechapi import Client


async def main():
    async with Client("http://localhost:8600") as c:
        # 合成
        audio = await c.tts.synthesize("openai-tts", "你好，这是通过 HTTP 客户端合成的语音。")
        print(f"合成完成: {len(audio.data):,} bytes, {audio.sample_rate}Hz")

        # 保存
        with wave.open("client_output.wav", "wb") as wf:
            wf.setnchannels(audio.channels)
            wf.setsampwidth(2)
            wf.setframerate(audio.sample_rate)
            wf.writeframes(audio.data)
        print("已保存: client_output.wav")


if __name__ == "__main__":
    asyncio.run(main())
