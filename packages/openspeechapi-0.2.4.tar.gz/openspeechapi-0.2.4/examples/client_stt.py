"""最简 Client STT demo — 通过 HTTP 调用远端 OpenSpeechAPI 服务转录音频.

先启动服务:  openspeechapi serve --config providers.yaml --port 8600
再运行本脚本: python examples/client_stt.py
"""
import asyncio
from pathlib import Path

from openspeechapi import AudioData, AudioFormat, Client


async def main():
    audio_path = Path("client_output.wav")
    if not audio_path.exists():
        print("未找到 client_output.wav，请先运行 client_tts.py 生成")
        return

    async with Client("http://localhost:8600") as c:
        # 转录
        audio = AudioData(
            data=audio_path.read_bytes(),
            sample_rate=16000, channels=1, format=AudioFormat.WAV,
        )
        result = await c.stt.transcribe("faster-whisper", audio)

        print(f"转录文本: {result.text}")
        print(f"语言: {result.language}")
        if result.confidence:
            print(f"置信度: {result.confidence:.3f}")


if __name__ == "__main__":
    asyncio.run(main())
