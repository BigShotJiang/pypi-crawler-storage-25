"""最简 STT demo — 本地 faster-whisper 转录，无需 API Key."""
import asyncio

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from openspeechapi import create_provider


async def main():
    # 1. 创建本地 STT provider
    stt = create_provider("faster-whisper", model_size="tiny", device="auto")

    # 2. 启动（加载模型）
    await stt.start()

    # 3. 用上一个 demo 生成的 output.wav 转录（也可换成任意音频文件）
    from openspeechapi import AudioData, AudioFormat
    from pathlib import Path

    audio_path = Path("output.wav")
    if not audio_path.exists():
        print("未找到 output.wav，请先运行 tts_simple.py 生成")
        return

    audio = AudioData(
        data=audio_path.read_bytes(),
        sample_rate=16000,
        channels=1,
        format=AudioFormat.WAV,
    )

    result = await stt.transcribe(audio)

    # 4. 输出结果
    print(f"转录文本: {result.text}")
    print(f"语言: {result.language}")
    print(f"置信度: {result.confidence:.3f}" if result.confidence else "")

    # 5. 停止
    await stt.stop()


if __name__ == "__main__":
    asyncio.run(main())
