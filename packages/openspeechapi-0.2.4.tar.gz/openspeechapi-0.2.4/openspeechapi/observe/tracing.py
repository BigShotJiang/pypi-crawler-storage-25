"""TracingObserver — OpenTelemetry tracing stub, graceful if not installed."""
from __future__ import annotations
from typing import Any
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class TracingObserver(DispatchObserver):
    """Wraps each invocation in an OpenTelemetry span.  Falls back to a no-op when
    the ``opentelemetry`` package is not installed."""

    def __init__(self, service_name: str = "openspeechapi") -> None:
        try:
            from opentelemetry import trace
            self._tracer = trace.get_tracer(service_name)
        except ImportError:
            self._tracer = None
        self._spans: dict[str, Any] = {}

    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        if self._tracer is None:
            return
        span = self._tracer.start_span(
            f"{ctx.provider_name}.{ctx.method}",
            attributes={
                "provider": ctx.provider_name,
                "method": ctx.method,
                "exec_mode": ctx.exec_mode.value,
                "request_id": ctx.request_id,
            },
        )
        self._spans[ctx.request_id] = span

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        span = self._spans.pop(ctx.request_id, None)
        if span:
            span.end()

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        span = self._spans.pop(ctx.request_id, None)
        if span:
            from opentelemetry.trace import StatusCode
            span.set_status(StatusCode.ERROR, str(error))
            span.end()
