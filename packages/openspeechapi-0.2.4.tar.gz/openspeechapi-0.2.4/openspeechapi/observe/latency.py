"""LatencyObserver — records total_ms and ttfb_ms latency samples."""
from __future__ import annotations
from typing import Any
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class LatencyObserver(DispatchObserver):
    """Accumulates per-invocation latency samples (total duration and TTFB)."""

    def __init__(self) -> None:
        self.total_ms: list[float] = []
        self.ttfb_ms: list[float] = []

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        self.total_ms.append(ctx.elapsed_ms)
        if ctx.ttfb_ns is not None:
            ttfb = (ctx.ttfb_ns - ctx.start_time_ns) / 1_000_000
            self.ttfb_ms.append(ttfb)
