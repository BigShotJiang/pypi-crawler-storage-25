"""DispatchObserver ABC and ObserverManager with error isolation."""
from __future__ import annotations
from abc import ABC
from typing import Any
from openspeechapi.logging_config import logger
from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext


class DispatchObserver(ABC):
    """Base class for dispatch observers. All methods are optional no-ops."""

    async def on_invoke_start(self, ctx: InvokeContext) -> None: pass
    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None: pass
    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None: pass
    async def on_stream_chunk(self, ctx: InvokeContext, chunk: Any) -> None: pass
    async def on_provider_start(self, provider: str, exec_mode: ExecMode) -> None: pass
    async def on_provider_stop(self, provider: str) -> None: pass
    async def on_health_change(self, provider: str, healthy: bool) -> None: pass


class ObserverManager:
    """Manages observers with error isolation and auto-deregistration."""

    def __init__(self, max_consecutive_errors: int = 10) -> None:
        self._observers: list[DispatchObserver] = []
        self._error_counts: dict[int, int] = {}
        self._max_errors = max_consecutive_errors

    def add(self, observer: DispatchObserver) -> None:
        self._observers.append(observer)
        self._error_counts[id(observer)] = 0

    def remove(self, observer: DispatchObserver) -> None:
        self._observers.remove(observer)
        self._error_counts.pop(id(observer), None)

    def list(self) -> list[DispatchObserver]:
        return list(self._observers)

    async def _notify(self, method: str, *args: Any, **kwargs: Any) -> None:
        to_remove = []
        for obs in self._observers:
            try:
                fn = getattr(obs, method)
                await fn(*args, **kwargs)
                self._error_counts[id(obs)] = 0
            except Exception as e:
                obs_id = id(obs)
                self._error_counts[obs_id] = self._error_counts.get(obs_id, 0) + 1
                logger.warning(f"Observer {type(obs).__name__} raised {type(e).__name__}: {e}")
                if self._error_counts[obs_id] >= self._max_errors:
                    to_remove.append(obs)
                    logger.warning(
                        f"Auto-deregistering {type(obs).__name__} after {self._max_errors} consecutive errors"
                    )
        for obs in to_remove:
            self.remove(obs)

    async def notify_invoke_start(self, ctx: InvokeContext) -> None:
        await self._notify("on_invoke_start", ctx)

    async def notify_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        await self._notify("on_invoke_end", ctx, result)

    async def notify_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        await self._notify("on_invoke_error", ctx, error)

    async def notify_stream_chunk(self, ctx: InvokeContext, chunk: Any) -> None:
        await self._notify("on_stream_chunk", ctx, chunk)

    async def notify_provider_start(self, provider: str, exec_mode: ExecMode) -> None:
        await self._notify("on_provider_start", provider, exec_mode)

    async def notify_provider_stop(self, provider: str) -> None:
        await self._notify("on_provider_stop", provider)

    async def notify_health_change(self, provider: str, healthy: bool) -> None:
        await self._notify("on_health_change", provider, healthy)
