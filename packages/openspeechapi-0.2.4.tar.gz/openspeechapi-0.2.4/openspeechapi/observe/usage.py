"""UsageObserver — tracks call counts, audio duration, and character counts."""
from __future__ import annotations
from typing import Any
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class UsageObserver(DispatchObserver):
    """Accumulates usage statistics: invocation counts, audio duration, and text characters."""

    def __init__(self) -> None:
        self.call_count: int = 0
        self.total_audio_duration_ms: int = 0
        self.total_characters: int = 0

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        self.call_count += 1

        # Accumulate audio duration from AudioData results (STT input or TTS output)
        audio_duration = getattr(result, "duration_ms", None)
        if audio_duration is not None:
            self.total_audio_duration_ms += audio_duration

        # Accumulate text characters from ctx.metadata["text"] (set by caller for TTS)
        text = ctx.metadata.get("text")
        if isinstance(text, str):
            self.total_characters += len(text)
