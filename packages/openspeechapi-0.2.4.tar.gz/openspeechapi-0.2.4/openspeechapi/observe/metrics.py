"""MetricsObserver — tracks TTFB, duration, and error counts per provider+method."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


@dataclass
class _ProviderMethodMetrics:
    total_calls: int = 0
    error_count: int = 0
    durations_ms: list[float] = field(default_factory=list)
    ttfb_ms: list[float] = field(default_factory=list)


class MetricsObserver(DispatchObserver):
    """Collects invocation metrics (call counts, durations, TTFB, errors) keyed by provider+method."""

    def __init__(self) -> None:
        self._data: dict[str, _ProviderMethodMetrics] = {}

    def _key(self, ctx: InvokeContext) -> str:
        return f"{ctx.provider_name}.{ctx.method}"

    def _get(self, key: str) -> _ProviderMethodMetrics:
        if key not in self._data:
            self._data[key] = _ProviderMethodMetrics()
        return self._data[key]

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        key = self._key(ctx)
        m = self._get(key)
        m.total_calls += 1
        m.durations_ms.append(ctx.elapsed_ms)
        if ctx.ttfb_ns is not None:
            ttfb = (ctx.ttfb_ns - ctx.start_time_ns) / 1_000_000
            m.ttfb_ms.append(ttfb)

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        key = self._key(ctx)
        m = self._get(key)
        m.error_count += 1

    def get(self, provider: str, method: str) -> _ProviderMethodMetrics | None:
        """Return accumulated metrics for the given provider+method, or None if not seen."""
        return self._data.get(f"{provider}.{method}")
