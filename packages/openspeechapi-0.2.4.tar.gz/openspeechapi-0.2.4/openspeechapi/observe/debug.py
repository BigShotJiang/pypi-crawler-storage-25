"""DebugLogObserver — emits loguru debug output for every lifecycle event."""
from __future__ import annotations
from typing import Any
from openspeechapi.logging_config import logger
from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver


class DebugLogObserver(DispatchObserver):
    """Logs all dispatch lifecycle events at DEBUG level via loguru."""

    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        logger.debug(
            "[openspeechapi] invoke_start provider={} method={} request_id={}",
            ctx.provider_name, ctx.method, ctx.request_id,
        )

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        logger.debug(
            "[openspeechapi] invoke_end provider={} method={} request_id={} elapsed_ms={:.2f}",
            ctx.provider_name, ctx.method, ctx.request_id, ctx.elapsed_ms,
        )

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        logger.debug(
            "[openspeechapi] invoke_error provider={} method={} request_id={} error={}",
            ctx.provider_name, ctx.method, ctx.request_id, repr(error),
        )

    async def on_stream_chunk(self, ctx: InvokeContext, chunk: Any) -> None:
        logger.debug(
            "[openspeechapi] stream_chunk provider={} method={} request_id={}",
            ctx.provider_name, ctx.method, ctx.request_id,
        )

    async def on_provider_start(self, provider: str, exec_mode: ExecMode) -> None:
        logger.debug("[openspeechapi] provider_start provider={} exec_mode={}", provider, exec_mode)

    async def on_provider_stop(self, provider: str) -> None:
        logger.debug("[openspeechapi] provider_stop provider={}", provider)

    async def on_health_change(self, provider: str, healthy: bool) -> None:
        logger.debug("[openspeechapi] health_change provider={} healthy={}", provider, healthy)
