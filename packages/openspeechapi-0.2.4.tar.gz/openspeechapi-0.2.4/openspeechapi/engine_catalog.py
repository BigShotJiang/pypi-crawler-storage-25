"""Unified engine catalog — loads engine list from registry YAML,
enriches with runtime metadata (default_settings, field_options) from provider code.

Only "installed" engines appear in providers.yaml and are visible on Dashboard/Config/Lab.
"""
from __future__ import annotations

import dataclasses
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class CatalogEntry:
    """A single engine entry in the catalog."""
    name: str                   # Unique engine ID, e.g. "openai-stt", "fish-speech"
    provider: str               # factory _PROVIDER_MAP key
    type: str                   # "stt" | "tts"
    category: str               # "cloud" | "local" | "native"
    description: str            # Human-readable description
    default_alias: str          # Default alias in config
    display_name: str = ""      # Human-friendly display name, e.g. "iFlytek STT"
    vendor: str = ""            # Vendor key from vendor_registry.yaml (cloud engines only)
    default_settings: dict = field(default_factory=dict)
    default_exec_mode: str = "remote"
    pip_deps: list[str] = field(default_factory=list)
    pip_extras: list[str] = field(default_factory=list)   # pyproject.toml extras names
    field_options: dict[str, list] = field(default_factory=dict)
    platforms: list[str] = field(default_factory=list)     # empty = all platforms

    @property
    def compatible(self) -> bool:
        """Whether this engine is compatible with the current platform."""
        return not self.platforms or sys.platform in self.platforms


# ---------------------------------------------------------------------------
# Registry loading
# ---------------------------------------------------------------------------

_REGISTRY_PATH = Path(__file__).parent / "engine_registry.yaml"
_VENDOR_REGISTRY_PATH = Path(__file__).parent / "vendor_registry.yaml"


def _load_registry(path: Path | None = None) -> list[dict]:
    """Load engine list from registry YAML file."""
    path = path or _REGISTRY_PATH
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    return raw.get("engines", [])


def _load_vendor_registry(path: Path | None = None) -> dict:
    """Load vendor registry from YAML file."""
    path = path or _VENDOR_REGISTRY_PATH
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    return raw.get("vendors", {})


def get_vendor_registry() -> dict:
    """Get vendor templates for provider credential fields."""
    return _load_vendor_registry()


def _enrich_from_provider(entry: CatalogEntry) -> CatalogEntry:
    """Enrich a catalog entry with default_settings and field_options from provider code."""
    try:
        from openspeechapi.factory import _resolve
        provider_cls, settings_cls = _resolve(entry.provider)

        # Extract default_settings from settings dataclass defaults
        if dataclasses.is_dataclass(settings_cls):
            defaults = {}
            for f in dataclasses.fields(settings_cls):
                if f.default is not dataclasses.MISSING:
                    defaults[f.name] = f.default
                elif f.default_factory is not dataclasses.MISSING:
                    defaults[f.name] = f.default_factory()

            # Filter out vendor shared fields (e.g. api_key, api_secret)
            # — these are inherited from vendor credentials, not engine settings
            if entry.vendor:
                vendor_registry = _load_vendor_registry()
                vendor_tpl = vendor_registry.get(entry.vendor, {})
                shared_keys = set(vendor_tpl.get("shared_fields", {}).keys())
                defaults = {k: v for k, v in defaults.items() if k not in shared_keys}

            entry.default_settings = defaults

        # Extract field_options from provider class attribute
        fo = getattr(provider_cls, "field_options", None)
        if fo:
            entry.field_options = dict(fo)

        # Extract pip_deps from provider class if available
        pd = getattr(provider_cls, "pip_deps", None)
        if pd:
            entry.pip_deps = list(pd)

    except Exception:
        pass  # Provider not importable (missing deps) — keep registry defaults

    return entry


def build_catalog(registry_path: Path | None = None) -> list[CatalogEntry]:
    """Build the full engine catalog from registry YAML + provider metadata."""
    raw_entries = _load_registry(registry_path)
    entries: list[CatalogEntry] = []

    for raw in raw_entries:
        entry = CatalogEntry(
            name=raw["name"],
            provider=raw["provider"],
            type=raw["type"],
            category=raw.get("category", "cloud"),
            description=raw.get("description", ""),
            default_alias=raw.get("default_alias", raw["name"].replace("-", "_")),
            display_name=raw.get("display_name", ""),
            vendor=raw.get("vendor", ""),
            default_exec_mode=raw.get("default_exec_mode", "remote"),
            pip_extras=raw.get("pip_extras", []),
            platforms=raw.get("platforms", []),
        )
        # Try to enrich with provider code metadata
        entry = _enrich_from_provider(entry)
        entries.append(entry)

    return entries


# ---------------------------------------------------------------------------
# Singleton & helpers
# ---------------------------------------------------------------------------

_catalog: list[CatalogEntry] | None = None


def get_catalog() -> list[CatalogEntry]:
    """Get the singleton catalog."""
    global _catalog
    if _catalog is None:
        _catalog = build_catalog()
    return _catalog


def get_catalog_entry(name: str) -> CatalogEntry | None:
    """Look up a catalog entry by name or default_alias.

    For native meta-aliases (native_stt / native_tts), returns the
    platform-specific entry (e.g. windows-stt on win32).
    """
    from openspeechapi.factory import _NATIVE_ALIASES

    # Check if this is a native meta-alias (by name or default_alias)
    for meta_name, platform_map in _NATIVE_ALIASES.items():
        meta_alias = meta_name.replace("-", "_")
        if name in (meta_name, meta_alias):
            concrete = platform_map.get(sys.platform)
            if concrete:
                for e in get_catalog():
                    if e.provider == concrete:
                        return e
            return None

    for e in get_catalog():
        if e.name == name or e.default_alias == name:
            return e
    return None


def get_installed_engines(config_path: Path) -> set[str]:
    """Return set of catalog engine names that are installed (present in config).

    Native meta-aliases (native_stt/native_tts) are resolved to platform-specific
    catalog entries (e.g. windows-stt on win32).
    """
    if not config_path.exists():
        return set()
    with open(config_path, encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    # Support both new format (engines:) and old format (providers:)
    engines_raw = raw.get("engines") or {}
    if not engines_raw:
        engines_raw = raw.get("providers") or {}

    # Build reverse map: provider key → catalog name
    installed = set()
    catalog = get_catalog()
    provider_to_catalog = {e.provider: e.name for e in catalog}

    # Also build alias → catalog name map
    alias_to_catalog = {e.default_alias: e.name for e in catalog}

    # Load providers section for credential provider resolution
    providers_section = raw.get("providers") or {}
    is_new_format = "engines" in raw

    for alias, spec in engines_raw.items():
        if not isinstance(spec, dict):
            continue
        # Skip credential provider entries (no exec_mode)
        if "exec_mode" not in spec and "provider" not in spec:
            continue

        # Resolve via get_catalog_entry (handles native meta-aliases)
        resolved = get_catalog_entry(alias)
        if resolved:
            installed.add(resolved.name)
            continue

        provider_val = spec.get("provider", "")

        # In new format, provider might reference credential provider
        if is_new_format and provider_val in providers_section:
            # Try to resolve via catalog
            for e in catalog:
                if e.vendor == provider_val and e.default_alias == alias:
                    installed.add(e.name)
                    break
        else:
            # Direct factory key
            if provider_val in provider_to_catalog:
                installed.add(provider_to_catalog[provider_val])

    return installed
