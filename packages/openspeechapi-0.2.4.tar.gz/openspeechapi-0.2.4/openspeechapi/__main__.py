"""Allow running as python -m openspeechapi."""
from openspeechapi.cli import main

if __name__ == "__main__":
    main()
