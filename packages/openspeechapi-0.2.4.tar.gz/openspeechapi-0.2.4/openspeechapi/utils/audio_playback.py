"""Audio playback utilities for demo and external applications."""
from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
import wave
from array import array
from pathlib import Path
from typing import Any

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData


def _wav_bytes_from_audio(audio: AudioData) -> bytes:
    if audio.format == AudioFormat.WAV and audio.data[:4] == b"RIFF":
        return audio.data

    data = audio.data
    if audio.format == AudioFormat.PCM_44K:
        sample_rate = 44100
    elif audio.format == AudioFormat.PCM_16K:
        sample_rate = 16000
    else:
        sample_rate = audio.sample_rate

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(audio.channels)
        wf.setsampwidth(2)  # 16-bit PCM
        wf.setframerate(sample_rate)
        wf.writeframes(data)
    return buf.getvalue()


def _scale_pcm16(pcm_bytes: bytes, volume: float) -> bytes:
    if volume == 1.0:
        return pcm_bytes
    samples = array("h")
    samples.frombytes(pcm_bytes)
    for i, s in enumerate(samples):
        v = int(s * volume)
        if v > 32767:
            v = 32767
        elif v < -32768:
            v = -32768
        samples[i] = v
    return samples.tobytes()


def _play_with_sounddevice(
    audio: AudioData,
    device: str | int | None,
    volume: float,
    blocking: bool,
) -> None:
    try:
        import numpy as np
        import sounddevice as sd
    except ImportError as exc:
        raise RuntimeError(
            "sounddevice backend unavailable. Install extras: pip install openspeechapi[audio]"
        ) from exc

    wav_bytes = _wav_bytes_from_audio(audio)
    with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
        frames = wf.readframes(wf.getnframes())
        channels = wf.getnchannels()
        sample_rate = wf.getframerate()
        sample_width = wf.getsampwidth()

    if sample_width != 2:
        raise RuntimeError(f"Only 16-bit PCM playback is supported, got sample_width={sample_width}")

    scaled = _scale_pcm16(frames, volume)
    pcm = np.frombuffer(scaled, dtype=np.int16)
    if channels > 1:
        pcm = pcm.reshape(-1, channels)

    sd.play(pcm, samplerate=sample_rate, device=device, blocking=blocking)
    if blocking:
        sd.wait()


def _play_with_external_player(
    audio: AudioData,
    device: str | int | None,
    blocking: bool,
) -> None:
    if device is not None:
        raise RuntimeError("device selection is only supported with backend='sounddevice'")

    wav_bytes = _wav_bytes_from_audio(audio)
    with tempfile.NamedTemporaryFile(prefix="openspeech_", suffix=".wav", delete=False) as f:
        temp_path = Path(f.name)
        f.write(wav_bytes)

    if shutil.which("ffplay"):
        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "error", str(temp_path)]
    elif shutil.which("afplay"):
        cmd = ["afplay", str(temp_path)]
    elif shutil.which("aplay"):
        cmd = ["aplay", str(temp_path)]
    else:
        temp_path.unlink(missing_ok=True)
        raise RuntimeError(
            "No playback backend found. Install sounddevice or ffplay/afplay/aplay."
        )

    if blocking:
        subprocess.run(cmd, check=False)
        temp_path.unlink(missing_ok=True)
    else:
        subprocess.Popen(cmd)  # noqa: S603


def play_audio(
    audio: AudioData,
    *,
    device: str | int | None = None,
    volume: float = 1.0,
    blocking: bool = True,
    backend: str = "auto",
) -> None:
    """Play AudioData with optional backend/device selection."""
    if volume <= 0:
        raise ValueError("volume must be > 0")
    backend = backend.lower().strip()
    if backend not in {"auto", "sounddevice", "external"}:
        raise ValueError("backend must be one of: auto, sounddevice, external")

    if backend in {"auto", "sounddevice"}:
        try:
            _play_with_sounddevice(audio, device=device, volume=volume, blocking=blocking)
            return
        except RuntimeError:
            if backend == "sounddevice":
                raise

    _play_with_external_player(audio, device=device, blocking=blocking)


def list_output_devices() -> list[dict[str, Any]]:
    """List playback devices for sounddevice backend."""
    try:
        import sounddevice as sd
    except ImportError:
        return []

    devices = []
    for idx, dev in enumerate(sd.query_devices()):  # type: ignore[arg-type]
        if dev.get("max_output_channels", 0) > 0:
            devices.append({"id": idx, "name": dev.get("name", f"device-{idx}")})
    return devices
