"""Base settings for provider configuration."""
from dataclasses import dataclass


@dataclass
class BaseSettings:
    """Base class for provider-specific settings. Subclass as a dataclass."""
    pass
