"""Provider registry — lookup by name, type, or capability."""
from __future__ import annotations

from typing import Any

from openspeechapi.core.enums import Capability, ProviderType
from openspeechapi.exceptions import ProviderNotFoundError


class ProviderRegistry:
    """Registry for provider classes. Lookup by name, type, or capability."""

    def __init__(self) -> None:
        self._providers: dict[str, Any] = {}

    def register(self, name: str, provider_cls: Any) -> None:
        self._providers[name] = provider_cls

    def get(self, name: str) -> Any:
        if name not in self._providers:
            raise ProviderNotFoundError(name)
        return self._providers[name]

    def find_by_type(self, provider_type: ProviderType) -> list[tuple[str, Any]]:
        return [
            (name, cls) for name, cls in self._providers.items()
            if getattr(cls, "provider_type", None) == provider_type
        ]

    def find_by_capability(self, capability: Capability) -> list[tuple[str, Any]]:
        return [
            (name, cls) for name, cls in self._providers.items()
            if capability in getattr(cls, "capabilities", set())
        ]

    def list_all(self) -> list[tuple[str, Any]]:
        return list(self._providers.items())
