"""Provider abstract base classes."""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, STTOptions, TTSOptions, Transcription
from openspeechapi.core.settings import BaseSettings


class SpeechProvider(ABC):
    """Base class for all speech providers."""

    name: str
    provider_type: ProviderType
    execution_mode: ExecMode
    settings: BaseSettings
    settings_cls: type[BaseSettings] = BaseSettings  # Override in subclass
    capabilities: set[Capability]
    field_options: dict[str, list] = {}  # Dropdown choices per setting key (override in subclass)

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def stop(self) -> None: ...

    @abstractmethod
    async def health_check(self) -> bool: ...

    def set_http_client(self, client: Any) -> None:
        """Inject a shared HTTP client before ``start()`` is called.

        Override in providers that use ``httpx.AsyncClient`` so they can
        reuse a single client instance (and its SSL/transport resources)
        instead of each creating their own.  Providers that receive a
        shared client must **not** close it in ``stop()``.

        The default implementation is a no-op — providers that don't use
        HTTP (WebSocket-only, local inference, etc.) simply ignore it.
        """


class STTProvider(SpeechProvider):
    """Base class for speech-to-text providers."""

    @abstractmethod
    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription: ...

    @abstractmethod
    def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]: ...


class TTSProvider(SpeechProvider):
    """Base class for text-to-speech providers."""

    @abstractmethod
    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData: ...

    @abstractmethod
    def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]: ...

    async def list_voices(self) -> list[dict]:
        """Return available voices. Override in subclass to provide voice list."""
        return []
