"""Core enumerations for OpenSpeechAPI."""
from enum import Enum


class ProviderType(str, Enum):
    STT = "stt"
    TTS = "tts"
    BOTH = "both"


class ExecMode(str, Enum):
    # True in-process model execution (reserved for ultra-low-latency local models).
    IN_PROCESS = "in_process"
    # Local service engine (managed separately; provider talks over HTTP/HTTPS).
    LOCAL = "local"
    # Provider worker subprocess + IPC.
    SUBPROCESS = "subprocess"
    # Cloud/remote service over network API.
    REMOTE = "remote"


class AudioFormat(str, Enum):
    PCM_16K = "pcm_16k"
    PCM_44K = "pcm_44k"
    WAV = "wav"
    AIFF = "aiff"
    MP3 = "mp3"
    OGG = "ogg"
    FLAC = "flac"
    OPUS = "opus"


class Capability(str, Enum):
    STREAMING = "streaming"
    BATCH = "batch"
    MULTILINGUAL = "multilingual"
    VOICE_CLONE = "voice_clone"
    EMOTION = "emotion"
    WORD_TIMESTAMPS = "word_timestamps"
