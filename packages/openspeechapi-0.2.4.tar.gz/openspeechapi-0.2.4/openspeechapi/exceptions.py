"""OpenSpeechAPI exception hierarchy."""


class OpenSpeechError(Exception):
    """Base exception for all OpenSpeechAPI errors."""


class ProviderError(OpenSpeechError):
    """Error from a provider invocation."""

    def __init__(self, provider_name: str, original_type: str, message: str) -> None:
        self.provider_name = provider_name
        self.original_type = original_type
        super().__init__(f"[{provider_name}] {original_type}: {message}")


class ProviderCrashedError(OpenSpeechError):
    """Provider subprocess crashed during invocation."""

    def __init__(self, provider_name: str) -> None:
        self.provider_name = provider_name
        super().__init__(f"Provider '{provider_name}' crashed during invocation")


class ProviderUnavailableError(OpenSpeechError):
    """Provider exhausted restart attempts and is unavailable."""

    def __init__(self, provider_name: str) -> None:
        self.provider_name = provider_name
        super().__init__(f"Provider '{provider_name}' is unavailable (max restarts exhausted)")


class ConfigError(OpenSpeechError):
    """Configuration loading or validation error."""


class FanOutAllFailedError(OpenSpeechError):
    """All providers in a fanout invocation failed."""

    def __init__(self, errors: dict[str, Exception]) -> None:
        self.errors = errors
        names = ", ".join(errors.keys())
        super().__init__(f"All fanout providers failed: {names}")


class ProviderNotFoundError(OpenSpeechError):
    """Provider not found in registry or dispatcher."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Provider '{name}' not found")
