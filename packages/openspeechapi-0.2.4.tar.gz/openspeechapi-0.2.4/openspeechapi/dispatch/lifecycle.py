"""Provider lifecycle management — lazy start, TTL-based auto-stop."""
from __future__ import annotations

import asyncio
import time
from enum import Enum
from typing import Any

from openspeechapi.logging_config import logger

from openspeechapi.logging_config import bind_context
from openspeechapi.telemetry.perf import Event, PerfTimer, milestone


class ProviderState(str, Enum):
    REGISTERED = "registered"
    STARTING = "starting"
    READY = "ready"
    STOPPED = "stopped"


class _ProviderEntry:
    def __init__(self, name: str, handle: Any, keepalive: int) -> None:
        self.name = name
        self.handle = handle
        self.keepalive = keepalive
        self.state = ProviderState.REGISTERED
        self.last_used: float = 0.0
        self._lock = asyncio.Lock()


class ProviderLifecycleManager:
    """Manages per-provider state, lazy start, and TTL-based auto-stop."""

    def __init__(self) -> None:
        self._entries: dict[str, _ProviderEntry] = {}
        self._checker_task: asyncio.Task | None = None
        self._check_interval: float = 30.0
        self._shared_http_client: Any = None

    def set_shared_http_client(self, client: Any) -> None:
        """Store a shared httpx.AsyncClient for injection into providers."""
        self._shared_http_client = client

    def register(self, name: str, handle: Any, keepalive: int = 0) -> None:
        self._entries[name] = _ProviderEntry(name, handle, keepalive)

    def unregister(self, name: str) -> None:
        self._entries.pop(name, None)

    def get_state(self, name: str) -> ProviderState | None:
        entry = self._entries.get(name)
        return entry.state if entry else None

    def list_states(self) -> dict[str, str]:
        return {name: entry.state.value for name, entry in self._entries.items()}

    async def ensure_ready(self, name: str) -> None:
        """Ensure provider is READY. Starts it if needed. Thread-safe."""
        entry = self._entries.get(name)
        if entry is None:
            from openspeechapi.exceptions import ProviderNotFoundError
            raise ProviderNotFoundError(name)

        if entry.state == ProviderState.READY:
            entry.last_used = time.monotonic()
            return

        async with entry._lock:
            # Double-check after acquiring lock
            if entry.state == ProviderState.READY:
                entry.last_used = time.monotonic()
                return

            with bind_context(provider=name, engine=name):
                logger.info("lazy-starting provider '{}'", name)
                entry.state = ProviderState.STARTING
                try:
                    import dataclasses
                    from openspeechapi.core.settings import BaseSettings
                    handle = entry.handle
                    settings_cls = getattr(handle.provider_cls, "settings_cls", BaseSettings)
                    # Filter settings to only include fields the class accepts
                    valid_fields = {f.name for f in dataclasses.fields(settings_cls)}
                    filtered = {k: v for k, v in handle.settings_dict.items() if k in valid_fields}
                    settings = settings_cls(**filtered)
                    with PerfTimer(
                        Event.LIFECYCLE_PROVIDER_INIT,
                        exec_mode=handle.exec_mode.value,
                    ):
                        await handle.executor.start(
                            handle.provider_cls, settings,
                            http_client=self._shared_http_client,
                        )
                    entry.state = ProviderState.READY
                    entry.last_used = time.monotonic()
                    milestone(
                        Event.LIFECYCLE_PROVIDER_READY,
                        exec_mode=handle.exec_mode.value,
                    )
                    logger.info("provider '{}' ready", name)
                except Exception as e:
                    entry.state = ProviderState.STOPPED
                    milestone(
                        Event.PROVIDER_ERROR,
                        phase="init",
                        error_type=type(e).__name__,
                        error_message=str(e),
                    )
                    logger.error("failed to start provider '{}': {}", name, e)
                    raise

    def get_instance(self, name: str) -> Any | None:
        """Return the running provider instance, or None."""
        entry = self._entries.get(name)
        if entry is None or entry.state != ProviderState.READY:
            return None
        executor = entry.handle.executor
        return getattr(executor, "_provider", None)

    def touch(self, name: str) -> None:
        """Reset idle timer for a provider."""
        entry = self._entries.get(name)
        if entry:
            entry.last_used = time.monotonic()

    async def stop_provider(self, name: str, *, reason: str = "manual") -> None:
        """Stop a single provider."""
        entry = self._entries.get(name)
        if entry is None or entry.state not in (ProviderState.READY, ProviderState.STARTING):
            return
        with bind_context(provider=name, engine=name):
            try:
                with PerfTimer(Event.LIFECYCLE_PROVIDER_STOP, reason=reason):
                    await entry.handle.executor.stop()
                entry.state = ProviderState.STOPPED
                logger.info("provider '{}' stopped (reason={})", name, reason)
            except Exception as e:
                logger.warning("error stopping provider '{}': {}", name, e)
                entry.state = ProviderState.STOPPED

    async def stop_all(self) -> None:
        """Stop all running providers and the idle checker."""
        if self._checker_task:
            self._checker_task.cancel()
            try:
                await self._checker_task
            except asyncio.CancelledError:
                pass
            self._checker_task = None

        for name, entry in self._entries.items():
            if entry.state == ProviderState.READY:
                await self.stop_provider(name)

    def start_idle_checker(self) -> None:
        """Start background task that stops idle providers."""
        if self._checker_task is None or self._checker_task.done():
            self._checker_task = asyncio.create_task(self._idle_check_loop())

    async def _idle_check_loop(self) -> None:
        while True:
            await asyncio.sleep(self._check_interval)
            now = time.monotonic()
            for name, entry in list(self._entries.items()):
                if (entry.state == ProviderState.READY
                        and entry.keepalive > 0
                        and entry.last_used > 0
                        and (now - entry.last_used) > entry.keepalive):
                    idle_s = now - entry.last_used
                    milestone(
                        Event.LIFECYCLE_IDLE_RECYCLE,
                        provider=name,
                        engine=name,
                        idle_seconds=round(idle_s, 2),
                        keepalive=entry.keepalive,
                    )
                    await self.stop_provider(name, reason="idle_ttl")
