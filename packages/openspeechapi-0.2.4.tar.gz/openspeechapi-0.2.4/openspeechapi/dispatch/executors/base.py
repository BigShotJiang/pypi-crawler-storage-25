"""Executor abstract base class."""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

from openspeechapi.core.base import SpeechProvider
from openspeechapi.core.settings import BaseSettings


class Executor(ABC):
    """Abstract executor — runs provider methods in a specific execution mode."""

    @abstractmethod
    async def start(
        self,
        provider_cls: type[SpeechProvider],
        settings: BaseSettings,
        *,
        http_client: Any = None,
    ) -> None: ...

    @abstractmethod
    async def stop(self) -> None: ...

    @abstractmethod
    async def invoke(self, method: str, **kwargs: Any) -> Any: ...

    @abstractmethod
    async def invoke_stream(self, method: str, **kwargs: Any) -> AsyncIterator[Any]: ...

    @abstractmethod
    async def health_check(self) -> bool: ...
