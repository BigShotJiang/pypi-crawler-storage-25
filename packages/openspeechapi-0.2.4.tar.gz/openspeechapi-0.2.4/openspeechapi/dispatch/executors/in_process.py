"""InProcessExecutor — runs provider directly in the main process."""
from __future__ import annotations
from collections.abc import AsyncIterator
from typing import Any
from openspeechapi.core.base import SpeechProvider
from openspeechapi.core.settings import BaseSettings
from openspeechapi.dispatch.executors.base import Executor
from openspeechapi.telemetry.perf import Event, PerfTimer


class InProcessExecutor(Executor):
    def __init__(self) -> None:
        self._provider: SpeechProvider | None = None
        self._provider_cls: type[SpeechProvider] | None = None
        self._settings: BaseSettings | None = None

    async def start(
        self,
        provider_cls: type[SpeechProvider],
        settings: BaseSettings,
        *,
        http_client: Any = None,
    ) -> None:
        self._provider_cls = provider_cls
        self._settings = settings
        self._provider = provider_cls(settings=settings)
        if http_client is not None:
            self._provider.set_http_client(http_client)
        await self._provider.start()

    def set_provider_info(self, provider_cls: type[SpeechProvider], settings: BaseSettings) -> None:
        """Store provider class and settings for pre-start health checks."""
        self._provider_cls = provider_cls
        self._settings = settings

    async def stop(self) -> None:
        if self._provider:
            await self._provider.stop()
            self._provider = None

    async def invoke(self, method: str, **kwargs: Any) -> Any:
        if self._provider is None:
            raise RuntimeError("Executor not started")
        fn = getattr(self._provider, method)
        with PerfTimer(Event.PROVIDER_TOTAL, method=method, exec_mode="in_process"):
            return await fn(**kwargs)

    async def invoke_stream(self, method: str, **kwargs: Any) -> AsyncIterator[Any]:
        if self._provider is None:
            raise RuntimeError("Executor not started")
        fn = getattr(self._provider, method)
        with PerfTimer(Event.PROVIDER_TOTAL, method=method, exec_mode="in_process") as t:
            count = 0
            async for item in fn(**kwargs):
                count += 1
                yield item
            t.add(items=count)

    async def health_check(self) -> bool:
        if self._provider is not None:
            return await self._provider.health_check()
        # Provider not started yet — instantiate temporarily to check
        if self._provider_cls is not None and self._settings is not None:
            tmp = self._provider_cls(settings=self._settings)
            return await tmp.health_check()
        return False
