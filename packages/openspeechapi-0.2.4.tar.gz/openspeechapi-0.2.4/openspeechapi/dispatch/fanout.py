"""FanOut/FanIn — concurrent dispatch to multiple providers with merge strategies."""
from __future__ import annotations
import asyncio
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any
from openspeechapi.exceptions import FanOutAllFailedError


@dataclass
class FanOutResult:
    successes: dict[str, Any] = field(default_factory=dict)
    errors: dict[str, Exception] = field(default_factory=dict)


class MergeStrategy(ABC):
    @abstractmethod
    async def merge(self, results: dict[str, Any | Exception]) -> Any: ...


class FirstCompleted(MergeStrategy):
    async def merge(self, results: dict[str, Any | Exception]) -> Any:
        successes = {k: v for k, v in results.items() if not isinstance(v, Exception)}
        if not successes:
            errors = {k: v for k, v in results.items() if isinstance(v, Exception)}
            raise FanOutAllFailedError(errors)
        return next(iter(successes.values()))


class HighestConfidence(MergeStrategy):
    async def merge(self, results: dict[str, Any | Exception]) -> Any:
        successes = {k: v for k, v in results.items() if not isinstance(v, Exception)}
        if not successes:
            errors = {k: v for k, v in results.items() if isinstance(v, Exception)}
            raise FanOutAllFailedError(errors)
        return max(successes.values(), key=lambda r: getattr(r, "confidence", 0) or 0)


class CollectAll(MergeStrategy):
    async def merge(self, results: dict[str, Any | Exception]) -> FanOutResult:
        fan_result = FanOutResult()
        for k, v in results.items():
            if isinstance(v, Exception):
                fan_result.errors[k] = v
            else:
                fan_result.successes[k] = v
        return fan_result


class CustomMerge(MergeStrategy):
    def __init__(self, fn: Callable[[dict[str, Any | Exception]], Awaitable[Any]]) -> None:
        self._fn = fn

    async def merge(self, results: dict[str, Any | Exception]) -> Any:
        return await self._fn(results)


async def fan_out(tasks: dict[str, Awaitable[Any]], strategy: MergeStrategy) -> Any:
    if isinstance(strategy, FirstCompleted):
        return await _fan_out_first_completed(tasks, strategy)

    results: dict[str, Any | Exception] = {}

    async def _run(name: str, coro: Awaitable[Any]) -> None:
        try:
            results[name] = await coro
        except Exception as e:
            results[name] = e

    await asyncio.gather(*[_run(name, coro) for name, coro in tasks.items()])
    return await strategy.merge(results)


async def _fan_out_first_completed(tasks: dict[str, Awaitable[Any]], strategy: FirstCompleted) -> Any:
    results: dict[str, Any | Exception] = {}
    done_event = asyncio.Event()

    async def _run(name: str, coro: Awaitable[Any]) -> None:
        try:
            result = await coro
            results[name] = result
            done_event.set()
        except Exception as e:
            results[name] = e
            if len(results) == len(tasks):
                done_event.set()

    async_tasks = [asyncio.create_task(_run(name, coro)) for name, coro in tasks.items()]
    await done_event.wait()
    for t in async_tasks:
        if not t.done():
            t.cancel()
    await asyncio.gather(*async_tasks, return_exceptions=True)
    return await strategy.merge(results)
