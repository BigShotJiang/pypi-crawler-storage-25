"""InvokeContext — request-scoped metadata for invocation lifecycle."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from openspeechapi.core.enums import ExecMode


@dataclass
class InvokeContext:
    provider_name: str
    method: str
    exec_mode: ExecMode
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    start_time_ns: int = field(default_factory=time.time_ns)
    ttfb_ns: int | None = None
    end_time_ns: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    parent_id: str | None = None

    def record_ttfb(self) -> None:
        if self.ttfb_ns is None:
            self.ttfb_ns = time.time_ns()

    def record_end(self) -> None:
        self.end_time_ns = time.time_ns()

    @property
    def elapsed_ms(self) -> float:
        end = self.end_time_ns or time.time_ns()
        return (end - self.start_time_ns) / 1_000_000
