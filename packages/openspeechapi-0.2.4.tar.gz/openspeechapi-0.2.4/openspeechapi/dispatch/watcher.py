"""Config file watcher for hot-reload."""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Awaitable, Callable

from openspeechapi.logging_config import logger


class ConfigWatcher:
    """Watches providers.yaml and .env for changes, triggers reload callback."""

    def __init__(
        self,
        config_path: Path,
        on_reload: Callable[[], Awaitable[dict[str, list[str]]]],
        debounce_s: float = 1.0,
    ) -> None:
        self._config_path = config_path
        self._env_path = config_path.parent / ".env"
        self._on_reload = on_reload
        self._debounce_s = debounce_s
        self._task: asyncio.Task | None = None
        self._last_config_mtime: float = 0.0
        self._last_env_mtime: float = 0.0
        self._poll_interval: float = 2.0  # poll every 2 seconds

    def start(self) -> None:
        """Start watching in background."""
        self._last_config_mtime = self._get_mtime(self._config_path)
        self._last_env_mtime = self._get_mtime(self._env_path)
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._watch_loop())
            logger.info(f"Config watcher started: {self._config_path}")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    @staticmethod
    def _get_mtime(path: Path) -> float:
        try:
            return path.stat().st_mtime
        except FileNotFoundError:
            return 0.0

    async def _watch_loop(self) -> None:
        """Poll for file changes and trigger reload."""
        while True:
            await asyncio.sleep(self._poll_interval)
            changed = False

            config_mtime = self._get_mtime(self._config_path)
            if config_mtime > self._last_config_mtime:
                self._last_config_mtime = config_mtime
                changed = True

            env_mtime = self._get_mtime(self._env_path)
            if env_mtime > self._last_env_mtime:
                self._last_env_mtime = env_mtime
                # Re-load .env into os.environ
                try:
                    from dotenv import load_dotenv
                    load_dotenv(self._env_path, override=True)
                except ImportError:
                    pass
                changed = True

            if changed:
                # Debounce: wait a bit to coalesce rapid saves
                await asyncio.sleep(self._debounce_s)
                try:
                    result = await self._on_reload()
                    logger.info(f"Config reloaded: {result}")
                except Exception as e:
                    logger.error(f"Config reload failed: {e}")
