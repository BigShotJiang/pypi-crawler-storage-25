"""Result filter chain — post-processing filters applied to provider results."""
from __future__ import annotations
from abc import ABC
from typing import Any, Generic, TypeVar
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData

T = TypeVar("T")


class ResultFilter(ABC, Generic[T]):
    def should_pass(self, result: T) -> bool:
        return True

    def transform(self, result: T) -> T:
        return result


class ConfidenceFilter(ResultFilter):
    def __init__(self, min_confidence: float = 0.8) -> None:
        self._min = min_confidence

    def should_pass(self, result: Any) -> bool:
        confidence = getattr(result, "confidence", None)
        if confidence is None:
            return True
        return confidence >= self._min


class LanguageFilter(ResultFilter):
    def __init__(self, allow: list[str]) -> None:
        self._allow = set(allow)

    def should_pass(self, result: Any) -> bool:
        language = getattr(result, "language", None)
        if language is None:
            return True
        return language in self._allow


class DurationFilter(ResultFilter):
    def __init__(self, min_ms: int = 100) -> None:
        self._min_ms = min_ms

    def should_pass(self, result: Any) -> bool:
        duration = getattr(result, "duration_ms", None)
        if duration is None:
            return True
        return duration >= self._min_ms


class AudioFormatFilter(ResultFilter):
    def __init__(self, target: AudioFormat = AudioFormat.PCM_16K) -> None:
        self._target = target

    def transform(self, result: Any) -> Any:
        if isinstance(result, AudioData) and result.format != self._target:
            return AudioData(data=result.data, sample_rate=result.sample_rate,
                             channels=result.channels, format=self._target,
                             duration_ms=result.duration_ms)
        return result


class FilterChain:
    def __init__(self, filters: list[ResultFilter]) -> None:
        self._filters = filters

    def apply(self, result: Any) -> Any | None:
        for f in self._filters:
            if not f.should_pass(result):
                return None
            result = f.transform(result)
        return result
