"""WhisperLiveKit local STT engine spec."""
from __future__ import annotations

from openspeechapi.local_engines.models import EngineSpec


WHISPERLIVEKIT_SPEC = EngineSpec(
    name="whisperlivekit",
    default_runtime="native",
    description="WhisperLiveKit local streaming STT engine (mlx-whisper backend)",
    options={
        "native_install_script": "scripts/engines/whisperlivekit/native/install.sh",
        "native_repo_url": "https://github.com/QuentinFuxa/WhisperLiveKit.git",
        "native_repo_ref": "main",
        "native_model_dir": "models/whisperlivekit",
        "native_use_aim": True,
        "native_aim_model_ids": [
            "whisper-large-v3-turbo",
            "whisper-large-v3",
        ],
        "native_aim_downloads": [
            {
                "model_id": "whisper-large-v3-turbo",
                "source": "hf:openai/whisper-large-v3-turbo",
                "category": "asr",
            },
            {
                "model_id": "whisper-large-v3",
                "source": "hf:openai/whisper-large-v3",
                "category": "asr",
            },
        ],
        "native_aim_provision_engine": "whisper",
        "native_aim_model_kind": "file",
        "native_existing_model_paths": [
            "~/AI/whisper/large-v3-turbo.pt",
            "~/AI/whisper/large-v3.pt",
        ],
        # Override with cfg.options.native_start_cmd if WhisperLiveKit CLI changes.
        "native_start_cmd": [
            "{service_dir}/.venv/bin/wlk",
            "serve",
            "--host",
            "{api_host}",
            "--port",
            "{api_port}",
            "--backend",
            "mlx-whisper",
            "--pcm-input",
            "--no-vac",
            "--no-vad",
            "--min-chunk-size",
            "0.2",
            "--never-fire",
            "--protocol-log",
            "--protocol-log-max-chars",
            "300",
        ],
    },
)
