"""Sherpa-ONNX local STT engine spec."""
from __future__ import annotations

from openspeechapi.local_engines.models import EngineSpec


SHERPA_ONNX_SPEC = EngineSpec(
    name="sherpa-onnx",
    default_runtime="native",
    description="Sherpa-ONNX local streaming STT engine",
    options={
        "native_install_script": "scripts/engines/sherpa-onnx/native/install.sh",
        "native_repo_url": "https://github.com/k2-fsa/sherpa-onnx.git",
        "native_repo_ref": "master",
        "native_model_only": False,
        "native_model_dir": "models/sherpa-onnx",
        "native_model_marker": "metadata.json",
        "native_use_aim": True,
        "native_aim_model_ids": [
            "sherpa-onnx-paraformer-zh-en",
            "sherpa-onnx-zipformer-zh-en",
        ],
        "native_aim_downloads": [
            {
                "model_id": "sherpa-onnx-zipformer-zh-en",
                "source": "hf:csukuangfj/sherpa-onnx-streaming-zipformer-bilingual-zh-en-2023-02-20",
                "category": "asr",
            },
            {
                "model_id": "sherpa-onnx-paraformer-zh-en",
                "source": "hf:k2-fsa/sherpa-onnx-paraformer-zh-en",
                "category": "asr",
            },
        ],
        "native_aim_provision_engine": "whisper",
        "native_aim_model_kind": "dir",
        "native_existing_model_paths": [
            "~/AI/store/asr/model/sherpa-onnx-paraformer-zh-en",
            "~/AI/store/asr/model/sherpa-onnx-zipformer-zh-en",
        ],
        "native_simulate_download": True,
        "native_model_repo": "",
        "native_start_cmd": [
            "{venv_python}",
            "{project_root}/scripts/engines/sherpa-onnx/native/run_streaming_server.py",
            "--repo-dir",
            "{repo_dir}",
            "--host",
            "{api_host}",
            "--port",
            "{api_port}",
            "--model-dir",
            "{model_dir}/current",
        ],
    },
)
