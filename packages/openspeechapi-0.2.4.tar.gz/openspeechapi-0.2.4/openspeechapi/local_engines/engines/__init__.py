"""Engine spec definitions."""
