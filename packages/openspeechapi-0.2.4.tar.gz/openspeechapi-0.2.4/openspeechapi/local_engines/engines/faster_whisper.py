"""Faster-Whisper local model engine spec."""
from __future__ import annotations

from openspeechapi.local_engines.models import EngineSpec


FASTER_WHISPER_SPEC = EngineSpec(
    name="faster-whisper",
    default_runtime="native",
    description="Faster-Whisper local STT model assets",
    options={
        "native_model_only": True,
        "native_install_script": "scripts/engines/faster-whisper/native/install.sh",
        "native_model_dir": "models/faster-whisper",
        "native_model_marker": "current",
        "native_simulate_download": True,
        "native_use_aim": True,
        "native_aim_model_ids": [
            "faster-whisper-large-v3-turbo",
        ],
        "native_aim_downloads": [
            {
                "model_id": "faster-whisper-large-v3-turbo",
                "source": "hf:mobiuslabsgmbh/faster-whisper-large-v3-turbo",
                "category": "asr",
            }
        ],
        "native_aim_provision_engine": "whisper",
        "native_aim_model_kind": "dir",
        "native_existing_model_paths": [
            "~/AI/whisper/faster-whisper-large-v3-turbo",
            "~/AI/whisper/models--mobiuslabsgmbh--faster-whisper-large-v3-turbo",
            "~/.cache/huggingface/hub/models--Systran--faster-whisper-large-v3-turbo",
        ],
    },
)
