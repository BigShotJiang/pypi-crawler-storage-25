"""Whisper local model engine spec."""
from __future__ import annotations

from openspeechapi.local_engines.models import EngineSpec


WHISPER_SPEC = EngineSpec(
    name="whisper",
    default_runtime="native",
    description="OpenAI Whisper local STT model assets",
    options={
        "native_model_only": True,
        "native_install_script": "scripts/engines/whisper/native/install.sh",
        "native_model_dir": "models/whisper",
        "native_model_marker": "current.pt",
        "native_simulate_download": True,
        "native_use_aim": True,
        "native_aim_model_ids": [
            "whisper-large-v3-turbo",
            "whisper-large-v3",
        ],
        "native_aim_downloads": [
            {
                "model_id": "whisper-large-v3-turbo",
                "source": "hf:openai/whisper-large-v3-turbo",
                "category": "asr",
            },
            {
                "model_id": "whisper-large-v3",
                "source": "hf:openai/whisper-large-v3",
                "category": "asr",
            },
        ],
        "native_aim_provision_engine": "whisper",
        "native_aim_model_kind": "file",
        "native_existing_model_paths": [
            "~/AI/whisper/large-v3-turbo.pt",
            "~/AI/whisper/large-v3.pt",
        ],
    },
)
