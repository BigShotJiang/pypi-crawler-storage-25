"""Fish-Speech engine spec."""
from __future__ import annotations

from openspeechapi.local_engines.models import EngineSpec


FISH_SPEECH_SPEC = EngineSpec(
    name="fish-speech",
    default_runtime="docker",
    description="Fish-Speech local TTS engine",
    options={
        "docker_image": "fishaudio/fish-speech:latest",
        "container_name": "openspeechapi-fish-speech",
        "platform": "linux/amd64",
        "container_port": 8080,
        "host_port": 8080,
        "health_path": "/health",
        # Override this if your image requires a custom startup command.
        "start_command": "",
        # Native runtime defaults.
        "native_repo_url": "https://github.com/fishaudio/fish-speech.git",
        "native_repo_ref": "main",
        "native_install_script": "scripts/engines/fish-speech/native/install.sh",
        "native_install_target": ".[cpu]",
        "native_device": "mps",
        "native_model_repo": "fishaudio/s2-pro",
        "native_model_dir": "checkpoints/s2-pro",
        "native_hf_max_workers": 4,
        "native_llama_checkpoint_path": "checkpoints/s2-pro",
        "native_decoder_checkpoint_path": "checkpoints/s2-pro/codec.pth",
        "native_decoder_config_name": "modded_dac_vq",
    },
)
