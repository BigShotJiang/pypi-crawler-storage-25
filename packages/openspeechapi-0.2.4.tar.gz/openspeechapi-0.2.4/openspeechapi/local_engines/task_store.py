"""Persistent task store for local engine operations."""
from __future__ import annotations

import json
import threading
from pathlib import Path

from openspeechapi.local_engines.tasks import EngineTask


class JsonTaskStore:
    """Stores each task as a JSON file for cross-process access."""

    def __init__(self, root_dir: Path | None = None) -> None:
        base = root_dir or (Path.home() / ".openspeechapi" / "engine_tasks")
        self._dir = base.expanduser().resolve()
        self._dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _path(self, task_id: str) -> Path:
        return self._dir / f"{task_id}.json"

    def save(self, task: EngineTask) -> None:
        path = self._path(task.task_id)
        payload = task.snapshot()
        tmp = path.with_suffix(".tmp")
        with self._lock:
            tmp.write_text(json.dumps(payload, ensure_ascii=True, indent=2))
            tmp.replace(path)

    def get(self, task_id: str) -> EngineTask | None:
        path = self._path(task_id)
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        return EngineTask.from_snapshot(data)

    def list(self, engine: str | None = None, limit: int = 20) -> list[EngineTask]:
        files = sorted(self._dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        tasks: list[EngineTask] = []
        for p in files:
            try:
                data = json.loads(p.read_text())
                task = EngineTask.from_snapshot(data)
            except Exception:
                continue
            if engine and task.engine != engine:
                continue
            tasks.append(task)
            if len(tasks) >= max(1, limit):
                break
        return tasks
