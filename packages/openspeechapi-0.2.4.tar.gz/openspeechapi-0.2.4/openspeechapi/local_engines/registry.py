"""Engine registry for local runtime manager."""
from __future__ import annotations

from openspeechapi.local_engines.engines.faster_whisper import FASTER_WHISPER_SPEC
from openspeechapi.local_engines.engines.fish_speech import FISH_SPEECH_SPEC
from openspeechapi.local_engines.engines.sherpa_onnx import SHERPA_ONNX_SPEC
from openspeechapi.local_engines.engines.whisper import WHISPER_SPEC
from openspeechapi.local_engines.engines.whisperlivekit import WHISPERLIVEKIT_SPEC
from openspeechapi.local_engines.models import EngineSpec


def default_engine_registry() -> dict[str, EngineSpec]:
    return {
        FISH_SPEECH_SPEC.name: FISH_SPEECH_SPEC,
        FASTER_WHISPER_SPEC.name: FASTER_WHISPER_SPEC,
        WHISPER_SPEC.name: WHISPER_SPEC,
        WHISPERLIVEKIT_SPEC.name: WHISPERLIVEKIT_SPEC,
        SHERPA_ONNX_SPEC.name: SHERPA_ONNX_SPEC,
    }
