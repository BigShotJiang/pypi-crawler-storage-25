"""Progress events for long-running local engine operations."""
from __future__ import annotations

import queue
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from openspeechapi.local_engines.models import TaskStatus


@dataclass
class ProgressEvent:
    task_id: str
    engine: str
    action: str
    runtime: str
    phase: str
    message: str
    status: TaskStatus
    progress: float | None = None
    eta_seconds: int | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, Any] = field(default_factory=dict)


class ProgressEmitter:
    """In-process pub/sub emitter for progress events."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._watchers: dict[str, list[queue.Queue[ProgressEvent]]] = defaultdict(list)
        self._global_watchers: list[queue.Queue[ProgressEvent]] = []

    def subscribe(self, task_id: str) -> "queue.Queue[ProgressEvent]":
        q: queue.Queue[ProgressEvent] = queue.Queue()
        with self._lock:
            self._watchers[task_id].append(q)
        return q

    def unsubscribe(self, task_id: str, q: "queue.Queue[ProgressEvent]") -> None:
        with self._lock:
            watchers = self._watchers.get(task_id, [])
            if q in watchers:
                watchers.remove(q)
            if not watchers and task_id in self._watchers:
                del self._watchers[task_id]

    def subscribe_all(self) -> "queue.Queue[ProgressEvent]":
        q: queue.Queue[ProgressEvent] = queue.Queue()
        with self._lock:
            self._global_watchers.append(q)
        return q

    def unsubscribe_all(self, q: "queue.Queue[ProgressEvent]") -> None:
        with self._lock:
            if q in self._global_watchers:
                self._global_watchers.remove(q)

    def emit(self, event: ProgressEvent) -> None:
        with self._lock:
            queues = list(self._watchers.get(event.task_id, []))
            global_queues = list(self._global_watchers)
        for q in queues:
            q.put(event)
        for q in global_queues:
            q.put(event)
