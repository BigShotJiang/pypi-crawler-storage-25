"""Models for local engine lifecycle management."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TaskStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EngineAction(str, Enum):
    INSTALL = "install"
    UPDATE = "update"
    START = "start"
    STOP = "stop"


@dataclass
class RuntimeConfig:
    runtime: str = "docker"
    api_url: str = "http://127.0.0.1:8080"
    install_dir: str = "~/AI/services"
    work_dir: str = ".openspeechapi/engines"
    timeout_s: float = 120.0
    retries: int = 0
    options: dict[str, Any] = field(default_factory=dict)


@dataclass
class EngineSpec:
    name: str
    default_runtime: str = "docker"
    description: str = ""
    options: dict[str, Any] = field(default_factory=dict)


@dataclass
class EngineStatus:
    engine: str
    runtime: str
    running: bool
    healthy: bool
    detail: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
