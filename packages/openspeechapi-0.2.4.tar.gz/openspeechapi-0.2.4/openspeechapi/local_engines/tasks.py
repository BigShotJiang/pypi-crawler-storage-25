"""Task models for local engine operations."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from openspeechapi.local_engines.models import EngineAction, TaskStatus


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class EngineTask:
    engine: str
    action: EngineAction
    runtime: str
    task_id: str = field(default_factory=lambda: uuid4().hex)
    status: TaskStatus = TaskStatus.QUEUED
    phase: str = "queued"
    message: str = "Task queued."
    progress: float | None = 0.0
    eta_seconds: int | None = None
    error: str | None = None
    started_at: datetime = field(default_factory=_utc_now)
    updated_at: datetime = field(default_factory=_utc_now)
    finished_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def snapshot(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "engine": self.engine,
            "action": self.action.value,
            "runtime": self.runtime,
            "status": self.status.value,
            "phase": self.phase,
            "message": self.message,
            "progress": self.progress,
            "eta_seconds": self.eta_seconds,
            "error": self.error,
            "started_at": self.started_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "metadata": self.metadata,
        }

    @classmethod
    def from_snapshot(cls, data: dict[str, Any]) -> "EngineTask":
        task = cls(
            engine=data["engine"],
            action=EngineAction(data["action"]),
            runtime=data["runtime"],
            task_id=data["task_id"],
            status=TaskStatus(data["status"]),
            phase=data.get("phase", "queued"),
            message=data.get("message", ""),
            progress=data.get("progress"),
            eta_seconds=data.get("eta_seconds"),
            error=data.get("error"),
            metadata=data.get("metadata", {}),
        )
        task.started_at = datetime.fromisoformat(data["started_at"])
        task.updated_at = datetime.fromisoformat(data["updated_at"])
        finished_raw = data.get("finished_at")
        if finished_raw:
            task.finished_at = datetime.fromisoformat(finished_raw)
        return task
