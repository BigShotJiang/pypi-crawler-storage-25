"""Task-based local engine manager with progress events."""
from __future__ import annotations

from datetime import datetime, timezone
import threading
from typing import Callable

from openspeechapi.local_engines.backends.docker_backend import DockerBackend
from openspeechapi.local_engines.backends.native_backend import NativeBackend
from openspeechapi.local_engines.models import EngineAction, EngineStatus, RuntimeConfig, TaskStatus
from openspeechapi.local_engines.progress import ProgressEmitter, ProgressEvent
from openspeechapi.local_engines.registry import default_engine_registry
from openspeechapi.local_engines.task_store import JsonTaskStore
from openspeechapi.local_engines.tasks import EngineTask


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class _TaskCancelled(RuntimeError):
    """Internal cancellation sentinel."""


class EngineManager:
    """Coordinates local engine actions with structured progress updates."""

    def __init__(self) -> None:
        self._engines = default_engine_registry()
        self._backends = {
            "docker": DockerBackend(),
            "native": NativeBackend(),
        }
        self._tasks: dict[str, EngineTask] = {}
        self._task_threads: dict[str, threading.Thread] = {}
        self._lock = threading.Lock()
        self._store = JsonTaskStore()
        self.emitter = ProgressEmitter()

    def _resolve_engine(self, name: str):
        if name not in self._engines:
            available = ", ".join(sorted(self._engines))
            raise ValueError(f"Unknown engine '{name}'. Available: {available}")
        return self._engines[name]

    def _resolve_runtime(self, runtime: str):
        if runtime not in self._backends:
            available = ", ".join(sorted(self._backends))
            raise ValueError(f"Unknown runtime '{runtime}'. Available: {available}")
        return self._backends[runtime]

    def _emit(self, task: EngineTask) -> None:
        self._store.save(task)
        self.emitter.emit(
            ProgressEvent(
                task_id=task.task_id,
                engine=task.engine,
                action=task.action.value,
                runtime=task.runtime,
                phase=task.phase,
                message=task.message,
                progress=task.progress,
                eta_seconds=task.eta_seconds,
                status=task.status,
                metadata=dict(task.metadata),
            )
        )

    def _raise_if_cancelled(self, task: EngineTask) -> None:
        if bool(task.metadata.get("cancel_requested", False)):
            raise _TaskCancelled("Task was cancelled by user.")

    def _reporter(self, task: EngineTask) -> Callable:
        def _report(
            phase: str,
            message: str,
            progress: float | None = None,
            *,
            eta_seconds: int | None = None,
        ) -> None:
            self._raise_if_cancelled(task)
            task.phase = phase
            task.message = message
            task.progress = progress
            task.eta_seconds = eta_seconds
            task.updated_at = _utc_now()
            self._emit(task)

        return _report

    def _create_task(self, engine: str, action: EngineAction, runtime: str) -> EngineTask:
        task = EngineTask(engine=engine, action=action, runtime=runtime)
        with self._lock:
            self._tasks[task.task_id] = task
        self._emit(task)
        return task

    def get_task(self, task_id: str) -> EngineTask | None:
        with self._lock:
            if task_id in self._tasks:
                return self._tasks[task_id]
        return self._store.get(task_id)

    def list_tasks(self, engine: str | None = None, limit: int = 20) -> list[EngineTask]:
        return self._store.list(engine=engine, limit=limit)

    def cancel_task(self, task_id: str) -> EngineTask | None:
        task = self.get_task(task_id)
        if task is None:
            return None
        if task.status in {TaskStatus.SUCCEEDED, TaskStatus.FAILED, TaskStatus.CANCELLED}:
            return task
        task.metadata["cancel_requested"] = True
        task.phase = "cancel_requested"
        task.message = "Cancellation requested. Waiting for safe stop point..."
        task.updated_at = _utc_now()
        self._emit(task)
        return task

    def _execute_task(self, task: EngineTask, cfg: RuntimeConfig) -> EngineTask:
        spec = self._resolve_engine(task.engine)
        backend = self._resolve_runtime(task.runtime)
        self._raise_if_cancelled(task)

        task.status = TaskStatus.RUNNING
        task.phase = "starting"
        task.message = f"{task.action.value} started."
        task.progress = 0.0
        task.updated_at = _utc_now()
        self._emit(task)

        report = self._reporter(task)
        try:
            if task.action == EngineAction.INSTALL:
                backend.install(spec, cfg, report)
            elif task.action == EngineAction.UPDATE:
                backend.update(spec, cfg, report)
            elif task.action == EngineAction.START:
                backend.start(spec, cfg, report)
            elif task.action == EngineAction.STOP:
                backend.stop(spec, cfg, report)
            else:
                raise ValueError(f"Unsupported action: {task.action}")
            task.status = TaskStatus.SUCCEEDED
            task.phase = "completed"
            task.message = f"{task.action.value} completed."
            task.progress = 100.0
            task.finished_at = _utc_now()
            task.updated_at = task.finished_at
            self._emit(task)
            return task
        except _TaskCancelled:
            task.status = TaskStatus.CANCELLED
            task.phase = "cancelled"
            task.message = "Task cancelled by user."
            task.error = None
            task.finished_at = _utc_now()
            task.updated_at = task.finished_at
            self._emit(task)
            return task
        except Exception as exc:
            task.status = TaskStatus.FAILED
            task.phase = "failed"
            task.message = str(exc)
            task.error = str(exc)
            task.finished_at = _utc_now()
            task.updated_at = task.finished_at
            self._emit(task)
            raise

    def run_action(self, engine: str, action: EngineAction, cfg: RuntimeConfig) -> EngineTask:
        spec = self._resolve_engine(engine)
        runtime = cfg.runtime or spec.default_runtime
        task = self._create_task(engine=engine, action=action, runtime=runtime)
        return self._execute_task(task, cfg)

    def run_action_async(self, engine: str, action: EngineAction, cfg: RuntimeConfig) -> EngineTask:
        spec = self._resolve_engine(engine)
        runtime = cfg.runtime or spec.default_runtime
        task = self._create_task(engine=engine, action=action, runtime=runtime)

        def _worker() -> None:
            try:
                self._execute_task(task, cfg)
            except Exception:
                # _execute_task already records terminal state and error details.
                pass
            finally:
                with self._lock:
                    self._task_threads.pop(task.task_id, None)

        t = threading.Thread(target=_worker, daemon=True)
        with self._lock:
            self._task_threads[task.task_id] = t
        t.start()
        return task

    def status(self, engine: str, cfg: RuntimeConfig) -> EngineStatus:
        spec = self._resolve_engine(engine)
        runtime = cfg.runtime or spec.default_runtime
        backend = self._resolve_runtime(runtime)
        return backend.status(spec, cfg)

    def logs(self, engine: str, cfg: RuntimeConfig, lines: int = 100) -> str:
        spec = self._resolve_engine(engine)
        runtime = cfg.runtime or spec.default_runtime
        backend = self._resolve_runtime(runtime)
        return backend.logs(spec, cfg, lines=lines)
