"""Abstractions for local engine backends."""
from __future__ import annotations

from abc import ABC, abstractmethod

from openspeechapi.local_engines.models import EngineSpec, EngineStatus, RuntimeConfig


class RuntimeBackend(ABC):
    """Backend contract for local runtime operations (docker/native/etc)."""

    runtime_name: str

    @abstractmethod
    def install(self, spec: EngineSpec, cfg: RuntimeConfig, report) -> None: ...

    @abstractmethod
    def update(self, spec: EngineSpec, cfg: RuntimeConfig, report) -> None: ...

    @abstractmethod
    def start(self, spec: EngineSpec, cfg: RuntimeConfig, report) -> None: ...

    @abstractmethod
    def stop(self, spec: EngineSpec, cfg: RuntimeConfig, report) -> None: ...

    @abstractmethod
    def status(self, spec: EngineSpec, cfg: RuntimeConfig) -> EngineStatus: ...

    @abstractmethod
    def logs(self, spec: EngineSpec, cfg: RuntimeConfig, lines: int = 100) -> str: ...
