"""Resolve model paths from AIM CLI output."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
from typing import Any


def _run_aim(args: list[str]) -> str:
    proc = subprocess.run(
        ["aim", *args],
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError((proc.stderr or proc.stdout or "").strip() or f"aim {' '.join(args)} failed")
    return (proc.stdout or "").strip()


def _parse_aim_resolve_json(raw: str) -> dict[str, Any]:
    data = json.loads(raw)
    if not isinstance(data, dict):
        return {}
    return data


def resolve_aim_model_paths(
    *,
    model_ids: list[str],
    provision_engine: str = "whisper",
    kind: str = "any",
) -> list[str]:
    """Return absolute model paths for requested model IDs from AIM CLI.

    Args:
        model_ids: model IDs in priority order.
        provision_engine: target engine filter.
        kind: "file", "dir", or "any".
    """
    ids = [x.strip() for x in model_ids if str(x).strip()]
    if not ids:
        return []

    out: list[str] = []
    seen: set[str] = set()
    for mid in ids:
        try:
            resolved = _parse_aim_resolve_json(
                _run_aim(["resolve", mid, "--engine", provision_engine, "--json"])
            )
        except Exception:
            continue
        engines = resolved.get("engines", [])
        if isinstance(engines, list) and engines:
            if provision_engine and provision_engine not in {str(x).strip() for x in engines}:
                continue

        resolved_path = str(resolved.get("path", "")).strip()
        if not resolved_path:
            continue
        abs_path = Path(resolved_path).expanduser()
        abs_str = str(abs_path)
        if abs_str not in seen:
            seen.add(abs_str)
            out.append(abs_str)

        resolved_file = str(resolved.get("resolved_file", "") or "").strip()
        if resolved_file:
            rf = str(Path(resolved_file).expanduser())
            if rf not in seen:
                seen.add(rf)
                out.append(rf)

        # whisper-style canonical directory often contains .pt/.bin payload files.
        if abs_path.is_dir():
            for p in sorted(abs_path.iterdir()):
                if p.is_file() and p.suffix.lower() in {".pt", ".bin"}:
                    f = str(p)
                    if f not in seen:
                        seen.add(f)
                        out.append(f)

    if kind == "any":
        return out
    if kind == "file":
        return [x for x in out if Path(x).is_file() or Path(x).suffix.lower() in {".pt", ".bin"}]
    if kind == "dir":
        return [x for x in out if Path(x).is_dir() or (not Path(x).suffix and not x.endswith(".pt"))]
    return out
