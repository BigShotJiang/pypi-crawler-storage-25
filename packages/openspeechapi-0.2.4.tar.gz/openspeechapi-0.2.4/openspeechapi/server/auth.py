"""API Key authentication middleware."""
from __future__ import annotations
import json
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

# Exempt paths (no auth required)
EXEMPT_PATHS = {"/v1/health", "/docs", "/openapi.json", "/redoc"}
EXEMPT_PREFIXES = ("/ui",)


def _unauthorized(detail: str) -> JSONResponse:
    return JSONResponse(status_code=401, content={"detail": detail})


class AuthMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, api_keys: list[str]) -> None:
        super().__init__(app)
        self._api_keys = set(api_keys)

    async def dispatch(self, request: Request, call_next):
        # Skip auth for exempt paths
        if request.url.path in EXEMPT_PATHS:
            return await call_next(request)
        if request.url.path.startswith(EXEMPT_PREFIXES):
            return await call_next(request)

        # Skip auth for WebSocket (handled separately via query param)
        if request.scope.get("type") == "websocket":
            return await call_next(request)

        # Check Bearer token
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return _unauthorized("Missing or invalid Authorization header")

        token = auth_header[7:]  # Strip "Bearer "
        if token not in self._api_keys:
            return _unauthorized("Invalid API key")

        return await call_next(request)
