"""WebSocket STT streaming endpoint."""
from __future__ import annotations
import asyncio
import json
import uuid
from openspeechapi.logging_config import logger
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from openspeechapi.core.enums import Capability
from openspeechapi.logging_config import bind_context
from openspeechapi.telemetry.perf import Event, PerfTimer, milestone

router = APIRouter()


@router.websocket("/stream")
async def stt_stream(
    websocket: WebSocket,
    provider: str = "faster-whisper",
    language: str | None = None,
    sample_rate: int = 16000,
):
    # Establish request_id early so all log lines from this connection are
    # correlated, including auth-failure paths.
    request_id = (
        websocket.query_params.get("request_id")
        or websocket.headers.get("x-request-id")
        or uuid.uuid4().hex[:12]
    )

    with bind_context(request_id=request_id, provider=provider, engine=provider):
        # WebSocket auth via query param
        server_config = getattr(websocket.app.state, "server_config", None)
        if server_config is not None and server_config.auth_enabled:
            token = websocket.query_params.get("token", "")
            if token not in server_config.api_keys:
                milestone(Event.WS_ERROR, reason="unauthorized", scope="stt")
                await websocket.close(code=4001, reason="Unauthorized")
                return

        with PerfTimer(Event.WS_TOTAL, scope="stt", provider=provider) as ws_timer:
            await websocket.accept()
            milestone(
                Event.WS_ACCEPT,
                scope="stt",
                provider=provider,
                language=language,
                sample_rate=sample_rate,
            )
            dispatcher = websocket.app.state.dispatcher

            # Determine if the provider supports real streaming
            handle = dispatcher._handles.get(provider)
            provider_cls = handle.provider_cls if handle else None
            supports_streaming = (
                provider_cls is not None
                and Capability.STREAMING in getattr(provider_cls, "capabilities", set())
            )

            # Send meta message so frontend knows batch vs streaming mode
            await websocket.send_json({
                "type": "meta",
                "streaming": supports_streaming,
                "provider": provider,
                "request_id": request_id,
            })
            milestone(
                Event.WS_META_SENT,
                level="verbose",
                scope="stt",
                streaming=supports_streaming,
            )

            try:
                if supports_streaming:
                    await _run_streaming(
                        websocket=websocket,
                        dispatcher=dispatcher,
                        provider=provider,
                        language=language,
                        ws_timer=ws_timer,
                    )
                else:
                    await _run_batch(
                        websocket=websocket,
                        dispatcher=dispatcher,
                        provider=provider,
                        language=language,
                        sample_rate=sample_rate,
                        ws_timer=ws_timer,
                    )
            except WebSocketDisconnect:
                milestone(Event.WS_CLOSED, scope="stt", reason="client_disconnect")
            except Exception as exc:
                milestone(
                    Event.WS_ERROR,
                    scope="stt",
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
                logger.exception("STT WS error")
                try:
                    await websocket.send_json({"type": "error", "detail": str(exc)})
                except Exception:
                    pass


async def _run_streaming(
    *,
    websocket: WebSocket,
    dispatcher,
    provider: str,
    language: str | None,
    ws_timer: PerfTimer,
) -> None:
    """Pipe real-time audio chunks through ``transcribe_stream``."""
    audio_queue: asyncio.Queue[bytes | None] = asyncio.Queue()
    first_audio_logged = False
    first_response_logged = False

    async def audio_source():
        while True:
            chunk = await audio_queue.get()
            if chunk is None:
                break
            yield chunk

    async def receive_audio():
        """Receive WebSocket messages and push audio into the queue."""
        nonlocal first_audio_logged
        frame_count = 0
        total_bytes = 0
        try:
            while True:
                message = await websocket.receive()
                if message.get("type") == "websocket.disconnect":
                    break
                if message.get("bytes") is not None:
                    if not first_audio_logged:
                        first_audio_logged = True
                        ws_timer.emit_milestone(
                            Event.WS_FIRST_AUDIO_FRAME,
                            scope="stt",
                            bytes=len(message["bytes"]),
                        )
                    frame_count += 1
                    total_bytes += len(message["bytes"])
                    await audio_queue.put(message["bytes"])
                elif message.get("text") is not None:
                    data = json.loads(message["text"])
                    if data.get("type") == "stop":
                        break
        finally:
            ws_timer.add(frames_received=frame_count, bytes_received=total_bytes)
            await audio_queue.put(None)

    recv_task = asyncio.create_task(receive_audio())

    # Ensure provider is started before streaming (lazy-load)
    await dispatcher._lifecycle.ensure_ready(provider)

    # Stream via executor.invoke_stream
    handle = dispatcher._handles[provider]
    partial_count = 0
    final_count = 0
    async for transcription in handle.executor.invoke_stream(
        "transcribe_stream", stream=audio_source()
    ):
        is_partial = getattr(transcription, "is_partial", True)
        msg_type = "final" if not is_partial else "partial"
        if not first_response_logged:
            first_response_logged = True
            ws_timer.mark_ttfb()
            ws_timer.emit_milestone(
                Event.WS_FIRST_RESPONSE,
                scope="stt",
                msg_type=msg_type,
            )
        if is_partial:
            partial_count += 1
        else:
            final_count += 1
            ws_timer.emit_milestone(
                Event.WS_FINAL_SENT,
                scope="stt",
                text_preview=(transcription.text or "")[:80],
            )
        await websocket.send_json({
            "type": msg_type,
            "text": transcription.text,
            "confidence": transcription.confidence,
            "language": transcription.language,
        })

    # Give receive_audio a chance to finish (client may have already
    # disconnected after receiving "final"); cancel if it doesn't complete
    # promptly so we don't hang forever.
    recv_task.cancel()
    try:
        await recv_task
    except asyncio.CancelledError:
        pass
    ws_timer.add(partials=partial_count, finals=final_count, mode="streaming")
    await websocket.send_json({"type": "closed"})
    milestone(Event.WS_CLOSED, scope="stt", mode="streaming")


async def _run_batch(
    *,
    websocket: WebSocket,
    dispatcher,
    provider: str,
    language: str | None,
    sample_rate: int,
    ws_timer: PerfTimer,
) -> None:
    """Accumulate all audio then transcribe in one batch call (fallback)."""
    audio_buffer = bytearray()
    logger.info("STT WS batch mode start")

    while True:
        message = await websocket.receive()
        if message.get("type") == "websocket.disconnect":
            break
        if message.get("bytes") is not None:
            audio_buffer.extend(message["bytes"])
        elif message.get("text") is not None:
            data = json.loads(message["text"])
            if data.get("type") == "stop":
                break

    if audio_buffer:
        from openspeechapi.core.enums import AudioFormat
        from openspeechapi.core.models import AudioData, STTOptions

        audio_data = AudioData(
            data=bytes(audio_buffer),
            sample_rate=sample_rate,
            channels=1,
            format=AudioFormat.PCM_16K,
        )
        opts = STTOptions(language=language)
        ws_timer.add(bytes_received=len(audio_buffer), mode="batch")
        with PerfTimer(Event.DISPATCH_TOTAL, scope="stt", provider=provider, method="transcribe"):
            result = await dispatcher.stt.transcribe(provider, audio_data, opts)
        ws_timer.mark_ttfb()
        if result:
            ws_timer.emit_milestone(
                Event.WS_FINAL_SENT,
                scope="stt",
                text_preview=(result.text or "")[:80],
            )
            await websocket.send_json({
                "type": "final",
                "text": result.text,
                "confidence": result.confidence,
                "language": result.language,
            })
    else:
        logger.warning("STT WS batch: empty audio buffer, skipping transcription")

    await websocket.send_json({"type": "closed"})
    milestone(Event.WS_CLOSED, scope="stt", mode="batch")
