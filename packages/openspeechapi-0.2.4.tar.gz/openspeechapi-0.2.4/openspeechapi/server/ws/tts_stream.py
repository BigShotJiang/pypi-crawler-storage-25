"""WebSocket TTS streaming endpoint."""
from __future__ import annotations
import json
import uuid
from openspeechapi.logging_config import logger
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from openspeechapi.core.enums import Capability
from openspeechapi.logging_config import bind_context
from openspeechapi.telemetry.perf import Event, PerfTimer, milestone

router = APIRouter()


@router.websocket("/stream")
async def tts_stream(websocket: WebSocket):
    request_id = (
        websocket.query_params.get("request_id")
        or websocket.headers.get("x-request-id")
        or uuid.uuid4().hex[:12]
    )

    with bind_context(request_id=request_id):
        # WebSocket auth via query param
        server_config = getattr(websocket.app.state, "server_config", None)
        if server_config is not None and server_config.auth_enabled:
            token = websocket.query_params.get("token", "")
            if token not in server_config.api_keys:
                milestone(Event.WS_ERROR, reason="unauthorized", scope="tts")
                await websocket.close(code=4001, reason="Unauthorized")
                return

        with PerfTimer(Event.WS_TOTAL, scope="tts") as ws_timer:
            await websocket.accept()
            milestone(Event.WS_ACCEPT, scope="tts")
            dispatcher = websocket.app.state.dispatcher

            try:
                # Receive synthesis request
                message = await websocket.receive_text()
                data = json.loads(message)

                provider = data.get("provider", "openai-tts")
                text = data.get("text", "")
                voice = data.get("voice")
                speed = data.get("speed", 1.0)
                model = data.get("model")
                stream_transport = data.get("stream_transport")

                # Bind provider now that we know it.
                with bind_context(provider=provider, engine=provider):
                    ws_timer.add(provider=provider, text_len=len(text))

                    from openspeechapi.core.models import TTSOptions
                    opts = TTSOptions(
                        voice=voice,
                        speed=float(speed),
                        model=str(model).strip() if model else None,
                        stream_transport=str(stream_transport).strip() if stream_transport else None,
                    )

                    # Check if provider supports true streaming
                    handle = dispatcher._get_handle(provider)
                    provider_cls = handle.provider_cls
                    has_streaming = (
                        Capability.STREAMING in getattr(provider_cls, "capabilities", set())
                    )

                    # Detect output format from provider settings when possible
                    # (fallback to wav for PCM-like providers).
                    audio_format = "wav"
                    try:
                        settings = getattr(handle, "settings_dict", {}) or {}
                        if "output_format" in settings and settings["output_format"]:
                            # e.g. mp3_44100_128 -> mp3
                            audio_format = str(settings["output_format"]).split("_", 1)[0]
                        elif hasattr(provider_cls, "name") and "iflytek" in provider_cls.name:
                            audio_format = "mp3"
                    except Exception:
                        pass

                    if has_streaming:
                        await _run_streaming(
                            websocket=websocket,
                            dispatcher=dispatcher,
                            provider=provider,
                            text=text,
                            opts=opts,
                            audio_format=audio_format,
                            ws_timer=ws_timer,
                        )
                    else:
                        await _run_batch(
                            websocket=websocket,
                            dispatcher=dispatcher,
                            provider=provider,
                            text=text,
                            opts=opts,
                            ws_timer=ws_timer,
                        )
            except WebSocketDisconnect:
                milestone(Event.WS_CLOSED, scope="tts", reason="client_disconnect")
            except Exception as exc:
                milestone(
                    Event.WS_ERROR,
                    scope="tts",
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
                logger.exception("TTS WS error")
                try:
                    await websocket.send_json({"type": "error", "detail": str(exc)})
                except Exception:
                    pass


async def _run_streaming(
    *,
    websocket: WebSocket,
    dispatcher,
    provider: str,
    text: str,
    opts,
    audio_format: str,
    ws_timer: PerfTimer,
) -> None:
    """True streaming: yield chunks as they're produced."""
    await websocket.send_json({
        "type": "meta",
        "streaming": True,
        "audio_format": audio_format,
    })
    milestone(Event.WS_META_SENT, level="verbose", scope="tts", streaming=True)

    total_bytes = 0
    chunk_seq = 0
    async for chunk in dispatcher.tts.synthesize_stream(provider, text, opts):
        if chunk.data:
            if chunk_seq == 0:
                ws_timer.mark_ttfb()
                ws_timer.emit_milestone(
                    Event.WS_FIRST_RESPONSE,
                    scope="tts",
                    chunk_bytes=len(chunk.data),
                )
            await websocket.send_bytes(chunk.data)
            total_bytes += len(chunk.data)
            chunk_seq += 1
        if chunk.is_final:
            break

    ws_timer.add(chunks_sent=chunk_seq, bytes_sent=total_bytes, mode="streaming")
    await websocket.send_json({
        "type": "done",
        "total_bytes": total_bytes,
        "streaming": True,
        "audio_format": audio_format,
    })
    milestone(Event.WS_CLOSED, scope="tts", mode="streaming")


async def _run_batch(
    *,
    websocket: WebSocket,
    dispatcher,
    provider: str,
    text: str,
    opts,
    ws_timer: PerfTimer,
) -> None:
    """Batch synthesize, then stream chunks to client."""
    await dispatcher._lifecycle.ensure_ready(provider)
    with PerfTimer(Event.DISPATCH_TOTAL, scope="tts", method="synthesize"):
        result = await dispatcher.tts.synthesize(provider, text, opts)

    if not result:
        return

    ws_timer.mark_ttfb()
    fmt = getattr(result, "format", "wav") or "wav"
    await websocket.send_json({
        "type": "meta",
        "sample_rate": result.sample_rate,
        "channels": result.channels,
        "duration_ms": result.duration_ms or 0,
        "total_bytes": len(result.data),
        "audio_format": str(fmt),
    })
    milestone(Event.WS_META_SENT, level="verbose", scope="tts", streaming=False)

    chunk_size = 4096
    total_bytes = len(result.data)
    chunk_seq = 0
    for i in range(0, total_bytes, chunk_size):
        chunk_data = result.data[i : i + chunk_size]
        await websocket.send_bytes(chunk_data)
        chunk_seq += 1

    ws_timer.add(chunks_sent=chunk_seq, bytes_sent=total_bytes, mode="batch")
    await websocket.send_json({
        "type": "done",
        "total_bytes": total_bytes,
        "sample_rate": result.sample_rate,
        "streaming": False,
        "audio_format": str(fmt),
    })
    milestone(Event.WS_CLOSED, scope="tts", mode="batch")
