"""FastAPI application wrapping ServiceDispatcher."""
from __future__ import annotations
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request

from openspeechapi.config import load_config
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.dispatch.watcher import ConfigWatcher
from openspeechapi.local_engines import EngineManager
from openspeechapi.logging_config import ensure_configured
from openspeechapi.server.middleware import RequestContextMiddleware
from openspeechapi.server.routes import stt, tts, management, webui
from openspeechapi.server.ws import stt_stream, tts_stream


def create_app(config_path: Path, registry: ProviderRegistry) -> FastAPI:
    """Create FastAPI app with dispatcher lifecycle."""
    ensure_configured()
    dispatcher = ServiceDispatcher.from_config(config_path, registry)
    config = load_config(config_path)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await dispatcher.start()

        async def _on_reload() -> dict:
            return await dispatcher.reload_config(config_path, registry)

        watcher = ConfigWatcher(config_path, on_reload=_on_reload)
        watcher.start()

        yield

        await watcher.stop()
        await dispatcher.stop()

    app = FastAPI(title="OpenSpeechAPI API", version="0.1.0", lifespan=lifespan)
    app.state.dispatcher = dispatcher
    app.state.config_path = config_path
    app.state.registry = registry
    app.state.server_config = config.server
    app.state.engine_manager = EngineManager()

    # Request-scoped logging context (request_id + route timing) — added first
    # so that auth-middleware rejections still get logged with a request_id.
    app.add_middleware(RequestContextMiddleware)

    # Conditionally add authentication middleware
    if config.server.auth_enabled and config.server.api_keys:
        from openspeechapi.server.auth import AuthMiddleware
        app.add_middleware(AuthMiddleware, api_keys=config.server.api_keys)

    # Register routes
    app.include_router(stt.router, prefix="/v1/stt", tags=["STT"])
    app.include_router(tts.router, prefix="/v1/tts", tags=["TTS"])
    app.include_router(management.router, prefix="/v1", tags=["Management"])
    app.include_router(webui.router, tags=["WebUI"])

    # Register WebSocket endpoints
    app.include_router(stt_stream.router, prefix="/v1/stt", tags=["STT Streaming"])
    app.include_router(tts_stream.router, prefix="/v1/tts", tags=["TTS Streaming"])

    return app


def get_dispatcher(request: Request) -> ServiceDispatcher:
    """Dependency to get dispatcher from app state."""
    return request.app.state.dispatcher
