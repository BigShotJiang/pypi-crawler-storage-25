"""HTTP middleware for request_id injection and route-level perf logging."""
from __future__ import annotations

import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

from openspeechapi.logging_config import bind_context
from openspeechapi.telemetry.perf import Event, milestone


REQUEST_ID_HEADER = "X-Request-Id"


class RequestContextMiddleware(BaseHTTPMiddleware):
    """Generate/propagate ``X-Request-Id`` and emit HTTP perf events.

    Order of precedence for the id:
    1. Inbound ``X-Request-Id`` header (so callers can correlate across
       services).
    2. A new 12-hex-char id if the header is absent.

    Every request emits two structured records:
    - ``http.request_start`` (perf level: verbose)
    - ``http.request_end``   (perf level: basic, carries ``elapsed_ms``
      and ``status_code``)
    """

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next) -> Response:
        inbound = request.headers.get(REQUEST_ID_HEADER)
        request_id = inbound or uuid.uuid4().hex[:12]
        # Expose request_id on the ASGI scope so handlers can read it.
        request.state.request_id = request_id

        start_ns = time.perf_counter_ns()
        with bind_context(request_id=request_id):
            milestone(
                Event.HTTP_REQUEST_START,
                level="verbose",
                method=request.method,
                path=request.url.path,
            )
            try:
                response = await call_next(request)
            except Exception as exc:
                elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
                milestone(
                    Event.HTTP_REQUEST_END,
                    level="basic",
                    method=request.method,
                    path=request.url.path,
                    status_code=500,
                    elapsed_ms=elapsed_ms,
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
                raise
            elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
            response.headers[REQUEST_ID_HEADER] = request_id
            milestone(
                Event.HTTP_REQUEST_END,
                level="basic",
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                elapsed_ms=elapsed_ms,
            )
            return response
