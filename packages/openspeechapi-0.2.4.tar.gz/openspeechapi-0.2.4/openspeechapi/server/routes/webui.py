"""Web UI static routes."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

router = APIRouter()

_WEBUI_DIR = Path(__file__).resolve().parent.parent / "webui"


@router.get("/ui")
async def webui_index():
    index = _WEBUI_DIR / "index.html"
    if not index.exists():
        raise HTTPException(status_code=404, detail="WebUI is not available")
    return FileResponse(index)


@router.get("/ui/{asset_name}")
async def webui_asset(asset_name: str):
    path = (_WEBUI_DIR / asset_name).resolve()
    if _WEBUI_DIR not in path.parents and path != _WEBUI_DIR:
        raise HTTPException(status_code=400, detail="Invalid path")
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="Asset not found")
    return FileResponse(path)
