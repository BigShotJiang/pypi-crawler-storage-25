"""TTS REST endpoints."""
from __future__ import annotations
import time
from fastapi import APIRouter, Request, HTTPException, UploadFile, File, Form
from fastapi.responses import Response
from pydantic import BaseModel
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, TTSOptions
from openspeechapi.exceptions import ProviderNotFoundError
from openspeechapi.utils.audio_converter import AudioConverter

router = APIRouter()

_MIME_MAP = {
    "wav": "audio/wav",
    "mp3": "audio/mpeg",
    "ogg": "audio/ogg",
    "flac": "audio/flac",
    "opus": "audio/opus",
    "pcm_16k": "audio/pcm",
    "pcm_44k": "audio/pcm",
}

_FORMAT_EXT = {
    "wav": ".wav",
    "mp3": ".mp3",
    "ogg": ".ogg",
    "flac": ".flac",
    "opus": ".opus",
    "pcm_16k": ".pcm",
    "pcm_44k": ".pcm",
}


class SynthesizeRequest(BaseModel):
    text: str
    provider: str
    voice: str | None = None
    speed: float = 1.0
    model: str | None = None
    stream_transport: str | None = None


@router.get("/{provider}/voices")
async def list_voices(request: Request, provider: str):
    dispatcher = request.app.state.dispatcher
    try:
        dispatcher._get_handle(provider)
    except ProviderNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    await dispatcher._lifecycle.ensure_ready(provider)
    instance = dispatcher._lifecycle.get_instance(provider)

    if instance is None or not hasattr(instance, "list_voices"):
        return {"voices": []}

    voices = await instance.list_voices()
    return {"voices": voices}


@router.post("/synthesize")
async def synthesize(request: Request, body: SynthesizeRequest):
    dispatcher = request.app.state.dispatcher
    opts = TTSOptions(
        voice=body.voice,
        speed=body.speed,
        model=body.model,
        stream_transport=body.stream_transport,
    )
    started = time.perf_counter()

    try:
        result = await dispatcher.tts.synthesize(body.provider, body.text, opts)
    except ProviderNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    if result is None:
        raise HTTPException(status_code=500, detail="Synthesis returned no result")

    fmt = str(getattr(result, "format", "wav") or "wav")
    media_type = _MIME_MAP.get(fmt, "audio/wav")

    return Response(
        content=result.data,
        media_type=media_type,
        headers={
            "X-Provider": body.provider,
            "X-Audio-Format": fmt,
            "X-Sample-Rate": str(result.sample_rate),
            "X-Duration-Ms": str(result.duration_ms or 0),
            "X-Elapsed-Ms": str(int((time.perf_counter() - started) * 1000)),
        },
    )


@router.post("/convert")
async def convert_audio(
    audio: UploadFile = File(...),
    source_format: str = Form("mp3"),
    target_format: str = Form("wav"),
    sample_rate: int = Form(16000),
    channels: int = Form(1),
):
    """Convert audio between formats. Requires ffmpeg for MP3/OGG/FLAC/OPUS."""
    # Validate target format
    try:
        target = AudioFormat(target_format)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Unsupported target format: {target_format}")

    data = await audio.read()
    if not data:
        raise HTTPException(status_code=400, detail="Empty audio data")

    # Detect or use declared source format
    try:
        src_fmt = AudioFormat(source_format)
    except ValueError:
        src_fmt = AudioConverter.detect_format(data)

    src_audio = AudioData(
        data=data,
        sample_rate=sample_rate,
        channels=channels,
        format=src_fmt,
    )

    try:
        result = AudioConverter.convert(src_audio, target)
    except RuntimeError as e:
        raise HTTPException(status_code=422, detail=str(e))

    ext = _FORMAT_EXT.get(target_format, ".bin")
    media_type = _MIME_MAP.get(target_format, "application/octet-stream")

    return Response(
        content=result.data,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="audio{ext}"',
            "X-Audio-Format": target_format,
            "X-Sample-Rate": str(result.sample_rate),
        },
    )


@router.get("/formats")
async def supported_formats():
    """Return supported download formats and whether ffmpeg is available."""
    has_ffmpeg = AudioConverter.ffmpeg_available()
    formats = [
        {"id": "wav", "label": "WAV", "ext": ".wav", "available": True},
        {"id": "mp3", "label": "MP3", "ext": ".mp3", "available": has_ffmpeg},
        {"id": "ogg", "label": "OGG Vorbis", "ext": ".ogg", "available": has_ffmpeg},
        {"id": "flac", "label": "FLAC", "ext": ".flac", "available": has_ffmpeg},
        {"id": "opus", "label": "Opus", "ext": ".opus", "available": has_ffmpeg},
    ]
    return {"formats": formats, "ffmpeg": has_ffmpeg}
