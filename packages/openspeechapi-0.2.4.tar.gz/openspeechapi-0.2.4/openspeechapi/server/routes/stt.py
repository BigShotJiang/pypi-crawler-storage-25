"""STT REST endpoints."""
from __future__ import annotations
from fastapi import APIRouter, File, Form, Request, UploadFile, HTTPException
from openspeechapi.core.models import AudioData, STTOptions
from openspeechapi.dispatch.fanout import FirstCompleted, HighestConfidence, CollectAll
from openspeechapi.exceptions import ProviderNotFoundError, FanOutAllFailedError
from openspeechapi.utils.audio_converter import AudioConverter

router = APIRouter()

STRATEGY_MAP = {
    "first_completed": FirstCompleted,
    "highest_confidence": HighestConfidence,
    "collect_all": CollectAll,
}


@router.post("/transcribe")
async def transcribe(
    request: Request,
    audio: UploadFile = File(...),
    provider: str = Form(...),
    language: str | None = Form(None),
    prompt: str | None = Form(None),
    temperature: float | None = Form(None),
    model: str | None = Form(None),
    device: str | None = Form(None),
    beam_size: int | None = Form(None),
    compute_type: str | None = Form(None),
    fp16: bool | None = Form(None),
):
    dispatcher = request.app.state.dispatcher
    audio_bytes = await audio.read()
    detected_fmt = AudioConverter.detect_format(audio_bytes)
    audio_data = AudioData(data=audio_bytes, sample_rate=16000, channels=1, format=detected_fmt)
    opts = STTOptions(
        language=language,
        prompt=prompt,
        temperature=temperature,
        model=model,
        device=device,
        beam_size=beam_size,
        compute_type=compute_type,
        fp16=fp16,
    )

    try:
        result = await dispatcher.stt.transcribe(provider, audio_data, opts)
    except ProviderNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"Provider '{provider}' failed: {e}")

    if result is None:
        return {"text": "", "filtered": True}

    return {
        "text": result.text,
        "language": result.language,
        "confidence": result.confidence,
        "words": [
            {
                "text": (w.get("text") if isinstance(w, dict) else w.text),
                "start_ms": (w.get("start_ms") if isinstance(w, dict) else w.start_ms),
                "end_ms": (w.get("end_ms") if isinstance(w, dict) else w.end_ms),
                "confidence": (w.get("confidence") if isinstance(w, dict) else w.confidence),
            }
            for w in (result.words or [])
        ],
        "duration_ms": result.duration_ms,
        "provider": provider,
    }


@router.post("/transcribe/fanout")
async def transcribe_fanout(
    request: Request,
    audio: UploadFile = File(...),
    providers: str = Form(...),  # comma-separated
    strategy: str = Form("first_completed"),
    language: str | None = Form(None),
):
    dispatcher = request.app.state.dispatcher
    audio_bytes = await audio.read()
    detected_fmt = AudioConverter.detect_format(audio_bytes)
    audio_data = AudioData(data=audio_bytes, sample_rate=16000, channels=1, format=detected_fmt)
    opts = STTOptions(language=language)
    provider_list = [p.strip() for p in providers.split(",")]

    strategy_cls = STRATEGY_MAP.get(strategy)
    if strategy_cls is None:
        raise HTTPException(
            status_code=422,
            detail=f"Unknown strategy: {strategy}. Use: {list(STRATEGY_MAP)}",
        )

    try:
        result = await dispatcher.stt.fanout(provider_list, audio_data, opts=opts, strategy=strategy_cls())
    except ProviderNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except FanOutAllFailedError as e:
        raise HTTPException(status_code=502, detail=f"All providers failed: {list(e.errors.keys())}")
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"Fanout request failed: {e}")

    # CollectAll returns FanOutResult, others return Transcription
    if hasattr(result, "successes"):
        return {
            "strategy": strategy,
            "successes": {
                name: {"text": t.text, "confidence": t.confidence, "language": t.language}
                for name, t in result.successes.items()
            },
            "errors": {name: str(e) for name, e in result.errors.items()},
        }
    return {
        "text": result.text,
        "language": result.language,
        "confidence": result.confidence,
        "provider": "fanout",
    }
