"""OpenSpeechAPI FastAPI server."""
