"""OpenSpeechAPI Python thin client."""
from openspeechapi.client.client import Client

__all__ = ["Client"]
