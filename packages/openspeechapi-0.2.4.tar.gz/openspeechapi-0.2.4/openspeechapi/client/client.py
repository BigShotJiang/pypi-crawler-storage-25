"""Python thin client for OpenSpeechAPI HTTP/WebSocket server."""
from __future__ import annotations

from typing import Any

import httpx

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, AudioChunk, STTOptions, TTSOptions, Transcription, Word


class _ClientSTT:
    def __init__(self, client: "Client") -> None:
        self._client = client

    async def transcribe(
        self, provider: str, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        opts = opts or STTOptions()
        data = {"provider": provider}
        if opts.language:
            data["language"] = opts.language
        if opts.prompt:
            data["prompt"] = opts.prompt
        if opts.temperature is not None:
            data["temperature"] = str(opts.temperature)
        if opts.model:
            data["model"] = opts.model
        if opts.device:
            data["device"] = opts.device
        if opts.beam_size is not None:
            data["beam_size"] = str(opts.beam_size)
        if opts.compute_type:
            data["compute_type"] = opts.compute_type
        if opts.fp16 is not None:
            data["fp16"] = str(bool(opts.fp16)).lower()

        files = {"audio": ("audio.wav", audio.data, "audio/wav")}
        resp = await self._client._http.post(
            f"{self._client._base_url}/v1/stt/transcribe",
            data=data, files=files,
        )
        resp.raise_for_status()
        j = resp.json()

        words = None
        if j.get("words"):
            words = [Word(text=w["text"], start_ms=w["start_ms"], end_ms=w["end_ms"],
                         confidence=w.get("confidence")) for w in j["words"]]

        return Transcription(
            text=j["text"],
            language=j.get("language"),
            confidence=j.get("confidence"),
            words=words,
            duration_ms=j.get("duration_ms"),
        )

    async def fanout(
        self, providers: list[str], audio: AudioData,
        opts: STTOptions | None = None, strategy: str = "first_completed",
    ) -> Any:
        opts = opts or STTOptions()
        data = {
            "providers": ",".join(providers),
            "strategy": strategy,
        }
        if opts.language:
            data["language"] = opts.language
        if opts.model:
            data["model"] = opts.model
        if opts.device:
            data["device"] = opts.device
        if opts.beam_size is not None:
            data["beam_size"] = str(opts.beam_size)

        files = {"audio": ("audio.wav", audio.data, "audio/wav")}
        resp = await self._client._http.post(
            f"{self._client._base_url}/v1/stt/transcribe/fanout",
            data=data, files=files,
        )
        resp.raise_for_status()
        return resp.json()


class _ClientTTS:
    def __init__(self, client: "Client") -> None:
        self._client = client

    async def synthesize(
        self, provider: str, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        opts = opts or TTSOptions()
        body = {"text": text, "provider": provider}
        if opts.voice:
            body["voice"] = opts.voice
        if opts.speed != 1.0:
            body["speed"] = opts.speed

        resp = await self._client._http.post(
            f"{self._client._base_url}/v1/tts/synthesize",
            json=body,
        )
        resp.raise_for_status()

        sample_rate = int(resp.headers.get("X-Sample-Rate", "16000"))
        return AudioData(
            data=resp.content,
            sample_rate=sample_rate,
            channels=1,
            format=AudioFormat.WAV,
        )


class Client:
    """OpenSpeechAPI HTTP client — same interface as ServiceDispatcher."""

    def __init__(self, base_url: str, timeout: float = 30.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(timeout=timeout)
        self.stt = _ClientSTT(self)
        self.tts = _ClientTTS(self)

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "Client":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def list_engines(self) -> list[dict]:
        resp = await self._http.get(f"{self._base_url}/v1/engines")
        resp.raise_for_status()
        return resp.json()["engines"]

    # Backward compatibility alias
    async def list_providers(self) -> list[dict]:
        return await self.list_engines()

    async def health(self) -> dict:
        resp = await self._http.get(f"{self._base_url}/v1/health")
        resp.raise_for_status()
        return resp.json()
