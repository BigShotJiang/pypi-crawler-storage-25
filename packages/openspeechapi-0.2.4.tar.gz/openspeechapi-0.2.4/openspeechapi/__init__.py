"""OpenSpeechAPI — Unified speech interface for STT/TTS providers."""

__version__ = "0.2.4"

from openspeechapi.config import load_config
from openspeechapi.core.base import SpeechProvider, STTProvider, TTSProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, STTOptions, Transcription, TTSOptions, Word
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.core.settings import BaseSettings
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.client.client import Client
from openspeechapi.factory import create_default_registry, create_provider, list_providers
from openspeechapi.logging_config import (
    bind_context,
    configure_logging,
    get_integration_tag,
    get_log_settings,
    integrate_with_host,
    is_host_managed,
    openspeech_filter,
    openspeech_level_filter,
)
from openspeechapi.telemetry.perf import Event, PerfTimer, milestone
from openspeechapi.utils import list_output_devices, play_audio
from openspeechapi.exceptions import (
    ConfigError,
    FanOutAllFailedError,
    OpenSpeechError,
    ProviderCrashedError,
    ProviderError,
    ProviderNotFoundError,
    ProviderUnavailableError,
)

def list_configured_engines(
    config_path: "str | Path",
    engine_type: str | None = None,
) -> list[dict]:
    """List configured engines from a config file (without starting providers).

    Lightweight query: parses YAML + resolves catalog metadata only.
    Suitable for populating UI dropdowns without running a full server.

    Args:
        config_path: Path to ``providers.yaml`` (or equivalent config file).
        engine_type: Optional filter — ``"stt"``, ``"tts"``, or ``None`` for all.

    Returns:
        List of engine info dicts (same schema as
        :py:meth:`ServiceDispatcher.list_engines_info`).
    """
    from pathlib import Path as _Path

    registry = create_default_registry()
    dispatcher = ServiceDispatcher.from_config(_Path(config_path), registry)
    return dispatcher.list_engines_info(engine_type=engine_type)


__all__ = [
    "AudioChunk", "AudioData", "AudioFormat", "BaseSettings", "Capability",
    "Client", "ConfigError", "Event", "ExecMode", "FanOutAllFailedError", "InvokeContext",
    "PerfTimer",
    "bind_context", "configure_logging", "get_integration_tag", "get_log_settings",
    "integrate_with_host", "is_host_managed", "milestone",
    "openspeech_filter", "openspeech_level_filter",
    "create_default_registry", "create_provider", "list_configured_engines", "list_providers",
    "OpenSpeechError", "ProviderCrashedError", "ProviderError",
    "ProviderNotFoundError", "ProviderRegistry", "ProviderType",
    "ProviderUnavailableError", "STTOptions", "STTProvider", "ServiceDispatcher",
    "SpeechProvider", "TTSOptions", "TTSProvider", "Transcription", "Word",
    "list_output_devices", "play_audio",
    "load_config",
]
