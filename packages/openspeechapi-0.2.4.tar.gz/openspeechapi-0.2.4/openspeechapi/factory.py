"""High-level factory — create providers by string name, no class imports needed."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from openspeechapi.core.base import SpeechProvider
from openspeechapi.exceptions import ProviderNotFoundError

# Lazy registry: name → (module_path, class_name, settings_class_name)
_PROVIDER_MAP: dict[str, tuple[str, str, str]] = {
    # STT
    "openai-stt": (
        "openspeechapi.providers.stt.openai",
        "OpenAISTT",
        "OpenAISTTSettings",
    ),
    "faster-whisper": (
        "openspeechapi.providers.stt.faster_whisper",
        "FasterWhisperSTT",
        "FasterWhisperSTTSettings",
    ),
    "whisper": (
        "openspeechapi.providers.stt.whisper",
        "WhisperSTT",
        "WhisperSTTSettings",
    ),
    "deepgram": (
        "openspeechapi.providers.stt.deepgram",
        "DeepgramSTT",
        "DeepgramSTTSettings",
    ),
    "elevenlabs-stt": (
        "openspeechapi.providers.stt.elevenlabs",
        "ElevenLabsSTT",
        "ElevenLabsSTTSettings",
    ),
    "deepgram-tts": (
        "openspeechapi.providers.tts.deepgram",
        "DeepgramTTS",
        "DeepgramTTSSettings",
    ),
    "whisperlivekit-stt": (
        "openspeechapi.providers.stt.whisperlivekit",
        "WhisperLiveKitSTT",
        "WhisperLiveKitSTTSettings",
    ),
    "sherpa-onnx-stt": (
        "openspeechapi.providers.stt.sherpa_onnx",
        "SherpaOnnxSTT",
        "SherpaOnnxSTTSettings",
    ),
    # TTS
    "openai-tts": (
        "openspeechapi.providers.tts.openai",
        "OpenAITTS",
        "OpenAITTSSettings",
    ),
    "elevenlabs": (
        "openspeechapi.providers.tts.elevenlabs",
        "ElevenLabsTTS",
        "ElevenLabsTTSSettings",
    ),
    "piper": (
        "openspeechapi.providers.tts.piper",
        "PiperTTS",
        "PiperTTSSettings",
    ),
    "coqui": (
        "openspeechapi.providers.tts.coqui",
        "CoquiTTS",
        "CoquiTTSSettings",
    ),
    "cosyvoice": (
        "openspeechapi.providers.tts.cosyvoice",
        "CosyVoiceTTS",
        "CosyVoiceTTSSettings",
    ),
    "fish-speech": (
        "openspeechapi.providers.tts.fish_speech",
        "FishSpeechTTS",
        "FishSpeechTTSSettings",
    ),
    "minimax": (
        "openspeechapi.providers.tts.minimax",
        "MinimaxTTS",
        "MinimaxTTSSettings",
    ),
    "macos-say": (
        "openspeechapi.providers.tts.macos_say",
        "MacOSSayTTS",
        "MacOSSaySettings",
    ),
    "macos-stt": (
        "openspeechapi.providers.stt.macos_speech",
        "MacOSSpeechSTT",
        "MacOSSpeechSettings",
    ),
    # Windows Native
    "windows-tts": (
        "openspeechapi.providers.tts.windows_sapi",
        "WindowsSapiTTS",
        "WindowsSapiSettings",
    ),
    "windows-stt": (
        "openspeechapi.providers.stt.windows_speech",
        "WindowsSpeechSTT",
        "WindowsSpeechSettings",
    ),
    # Cloud STT
    "google-stt": (
        "openspeechapi.providers.stt.google_cloud",
        "GoogleCloudSTT",
        "GoogleCloudSTTSettings",
    ),
    "azure-stt": (
        "openspeechapi.providers.stt.azure_speech",
        "AzureSpeechSTT",
        "AzureSpeechSTTSettings",
    ),
    "assemblyai-stt": (
        "openspeechapi.providers.stt.assemblyai",
        "AssemblyAISTT",
        "AssemblyAISTTSettings",
    ),
    "volcengine-stt": (
        "openspeechapi.providers.stt.volcengine",
        "VolcengineSTT",
        "VolcengineSTTSettings",
    ),
    "alibaba-stt": (
        "openspeechapi.providers.stt.alibaba",
        "AlibabaSTT",
        "AlibabaSTTSettings",
    ),
    "tencent-stt": (
        "openspeechapi.providers.stt.tencent",
        "TencentSTT",
        "TencentSTTSettings",
    ),
    "baidu-stt": (
        "openspeechapi.providers.stt.baidu",
        "BaiduSTT",
        "BaiduSTTSettings",
    ),
    "iflytek-stt": (
        "openspeechapi.providers.stt.iflytek",
        "IflytekSTT",
        "IflytekSTTSettings",
    ),
    # Cloud TTS
    "google-tts": (
        "openspeechapi.providers.tts.google_cloud",
        "GoogleCloudTTS",
        "GoogleCloudTTSSettings",
    ),
    "azure-tts": (
        "openspeechapi.providers.tts.azure_speech",
        "AzureSpeechTTS",
        "AzureSpeechTTSSettings",
    ),
    "volcengine-tts": (
        "openspeechapi.providers.tts.volcengine",
        "VolcengineTTS",
        "VolcengineTTSSettings",
    ),
    "alibaba-tts": (
        "openspeechapi.providers.tts.alibaba",
        "AlibabaTTS",
        "AlibabaTTSSettings",
    ),
    "tencent-tts": (
        "openspeechapi.providers.tts.tencent",
        "TencentTTS",
        "TencentTTSSettings",
    ),
    "baidu-tts": (
        "openspeechapi.providers.tts.baidu",
        "BaiduTTS",
        "BaiduTTSSettings",
    ),
    "iflytek-tts": (
        "openspeechapi.providers.tts.iflytek",
        "IflytekTTS",
        "IflytekTTSSettings",
    ),
}


# Platform-generic aliases that resolve to the correct native provider.
_NATIVE_ALIASES: dict[str, dict[str, str]] = {
    "native-tts": {"darwin": "macos-say", "win32": "windows-tts"},
    "native-stt": {"darwin": "macos-stt", "win32": "windows-stt"},
}


def _resolve_native(alias: str) -> str:
    """Map a ``native-*`` alias to the concrete provider name for this OS."""
    platform_map = _NATIVE_ALIASES.get(alias)
    if platform_map is None:
        raise ProviderNotFoundError(f"Unknown native alias '{alias}'")
    concrete = platform_map.get(sys.platform)
    if concrete is None:
        supported = ", ".join(sorted(platform_map.keys()))
        raise ProviderNotFoundError(
            f"No native provider for platform '{sys.platform}'. "
            f"Supported: {supported}"
        )
    return concrete


def _resolve(name: str) -> tuple[type, type]:
    """Lazily import and return (ProviderClass, SettingsClass).

    Raises ``ProviderNotFoundError`` with a ``pip install`` hint when the
    provider's optional extras are not installed.
    """
    import importlib

    # Handle native aliases
    if name in _NATIVE_ALIASES:
        name = _resolve_native(name)

    entry = _PROVIDER_MAP.get(name)
    if entry is None:
        available = ", ".join(sorted(_PROVIDER_MAP))
        raise ProviderNotFoundError(
            f"Unknown provider '{name}'. Available: {available}"
        )

    module_path, cls_name, settings_name = entry
    try:
        mod = importlib.import_module(module_path)
    except ImportError as e:
        raise ProviderNotFoundError(
            f"Provider '{name}' requires optional dependencies that are not installed. "
            f"Install with:  pip install 'openspeechapi[{name}]'  "
            f"(missing: {e.name or e})"
        ) from e
    return getattr(mod, cls_name), getattr(mod, settings_name)


def _resolve_from_config(prov_cfg) -> tuple[type, type]:
    """Resolve provider class from a ProviderConfig.

    If the config specifies ``module`` and ``provider_class``, use importlib
    to load the class dynamically.  Otherwise fall back to the built-in
    ``_PROVIDER_MAP`` via ``_resolve()``.
    """
    import importlib

    if prov_cfg.module and prov_cfg.provider_class:
        mod = importlib.import_module(prov_cfg.module)
        provider_cls = getattr(mod, prov_cfg.provider_class)
        settings_cls = getattr(provider_cls, "settings_cls", None)
        return provider_cls, settings_cls

    return _resolve(prov_cfg.provider)


def _ensure_plugins_dir(project_root: Path | None = None) -> None:
    """Add ``<project_root>/plugins`` to *sys.path* if the directory exists."""
    if project_root is None:
        project_root = Path.cwd()
    plugins_dir = project_root / "plugins"
    if plugins_dir.is_dir():
        plugins_str = str(plugins_dir)
        if plugins_str not in sys.path:
            sys.path.insert(0, plugins_str)


def create_provider(name: str, **settings: Any) -> SpeechProvider:
    """Create a provider instance by name.

    Usage::

        tts = create_provider("openai-tts", api_key="sk-...")
        stt = create_provider("faster-whisper", model_size="tiny")

    """
    provider_cls, settings_cls = _resolve(name)
    s = settings_cls(**settings)
    return provider_cls(settings=s)


def list_providers() -> list[str]:
    """Return all registered provider names."""
    return sorted(_PROVIDER_MAP)


def create_default_registry() -> "ProviderRegistry":
    """Build a ProviderRegistry pre-populated with all known providers.

    Resolves all entries in ``_PROVIDER_MAP`` and ``_NATIVE_ALIASES``,
    silently skipping any whose dependencies are missing.
    """
    from openspeechapi.core.registry import ProviderRegistry

    from openspeechapi.logging_config import logger

    _ensure_plugins_dir()
    registry = ProviderRegistry()
    skipped: list[str] = []
    for name in _PROVIDER_MAP:
        try:
            provider_cls, _ = _resolve(name)
            registry.register(name, provider_cls)
        except ProviderNotFoundError as e:
            skipped.append(name)
            logger.debug(f"skip provider '{name}': {e}")
        except Exception as e:
            logger.debug(f"skip provider '{name}' (unexpected): {e}")
    for alias in _NATIVE_ALIASES:
        try:
            provider_cls, _ = _resolve(alias)
            registry.register(alias, provider_cls)
        except Exception as e:
            logger.debug(f"skip native alias '{alias}': {e}")
    if skipped:
        logger.info(
            f"{len(skipped)} provider(s) unavailable due to missing optional deps: "
            f"{', '.join(skipped)}. Install e.g. `pip install 'openspeechapi[<name>]'`."
        )
    return registry
