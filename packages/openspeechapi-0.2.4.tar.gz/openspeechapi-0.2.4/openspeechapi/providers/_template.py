"""
Provider adapter template — copy-paste starting point for new adapters.

Steps to create a new adapter:
1. Copy this file to providers/stt/<name>.py or providers/tts/<name>.py
2. Replace MyProvider* placeholders with the real names
3. Fill in the correct name, provider_type, execution_mode, capabilities
4. Implement start() to import the SDK and build the client
5. Implement transcribe() / synthesize() (and streaming variants if supported)
6. Add the provider to openspeechapi/core/registry.py if auto-registration is desired
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openspeechapi.core.base import STTProvider  # swap for TTSProvider as needed
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings


# ---------------------------------------------------------------------------
# Settings dataclass — one field per provider-specific config value
# ---------------------------------------------------------------------------
@dataclass
class MyProviderSettings(BaseSettings):
    api_key: str = ""
    model: str = "default-model"
    # add more fields as needed


# ---------------------------------------------------------------------------
# Provider class
# ---------------------------------------------------------------------------
class MyProviderSTT(STTProvider):
    # --- class-level metadata (required by SpeechProvider ABC) ---
    name = "my-provider"
    provider_type = ProviderType.STT            # or ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS        # or SUBPROCESS / REMOTE
    settings_cls = MyProviderSettings
    capabilities = {Capability.BATCH}           # choose from enums.Capability

    def __init__(self, settings: MyProviderSettings | None = None) -> None:
        self.settings = settings or MyProviderSettings()
        self._client: Any = None

    # --- lifecycle ---

    async def start(self) -> None:
        """Import SDK and initialise the client."""
        try:
            import my_sdk  # noqa: F401  replace with real import
            self._client = object()  # replace with real client construction
        except ImportError:
            raise ImportError(
                "Install the SDK: pip install openspeechapi[my-provider]"
            )

    async def stop(self) -> None:
        """Release resources."""
        self._client = None

    async def health_check(self) -> bool:
        return self._client is not None

    # --- STT interface (remove if implementing TTSProvider) ---

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        opts = opts or STTOptions()
        raise NotImplementedError("Implement transcribe() for MyProviderSTT")

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "Streaming transcription is not supported by MyProviderSTT"
        )
        yield  # pragma: no cover

    # --- TTS interface (uncomment if implementing TTSProvider) ---

    # async def synthesize(
    #     self, text: str, opts: TTSOptions | None = None
    # ) -> AudioData:
    #     if self._client is None:
    #         raise RuntimeError("Provider not started — call start() first")
    #     raise NotImplementedError("Implement synthesize() for MyProviderTTS")

    # async def synthesize_stream(
    #     self, text: str, opts: TTSOptions | None = None
    # ) -> AsyncIterator[AudioChunk]:
    #     raise NotImplementedError(
    #         "Streaming synthesis is not supported by MyProviderTTS"
    #     )
    #     yield  # pragma: no cover
