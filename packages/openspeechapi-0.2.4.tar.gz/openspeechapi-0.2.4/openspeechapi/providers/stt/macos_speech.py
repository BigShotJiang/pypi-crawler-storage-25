"""macOS native STT provider using SFSpeechRecognizer via compiled Swift binary.

The Swift helper lives inside a .app bundle so that macOS TCC can track its
Speech Recognition authorization by bundle ID.  The provider launches it via
``open -W`` which inherits the .app TCC grant; results are exchanged through
a temporary JSON file (``--output``).
"""
from __future__ import annotations

import asyncio
import json
from openspeechapi.logging_config import logger
import tempfile
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openspeechapi.core.base import STTProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings
from openspeechapi.utils.audio_converter import AudioConverter

@dataclass
class MacOSSpeechSettings(BaseSettings):
    language: str = "zh-CN"
    binary_path: str = ""

class MacOSSpeechSTT(STTProvider):
    """STT provider wrapping macOS SFSpeechRecognizer via a compiled Swift helper."""

    name = "macos-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = MacOSSpeechSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"language": ["zh-CN", "en-US", "en-AE", "ja-JP", "ko-KR", "fr-FR", "de-DE", "es-ES"]}

    # .app bundle that contains the Swift helper binary.
    _DEFAULT_APP_BUNDLE = (
        Path(__file__).resolve().parents[3]
        / "scripts"
        / "engines"
        / "macos-stt"
        / "MacOSSTTHelper.app"
    )

    def __init__(self, settings: MacOSSpeechSettings | None = None) -> None:
        self.settings = settings or MacOSSpeechSettings()
        self._app_bundle: Path | None = None
        self._binary: Path | None = None
        self._started = False
        self._auth_ok = False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _run_via_open(self, *extra_args: str, output_file: str | None = None) -> dict:
        """Launch the helper through ``open -W`` so it inherits .app TCC grants.

        If *output_file* is given the helper writes JSON there (``--output``);
        otherwise we fall back to direct execution for ``--check`` which
        doesn't need TCC.
        """
        if self._app_bundle is None:
            return {"status": "error", "error": "app bundle not set"}

        cmd: list[str]
        if output_file is not None:
            # Launch via `open -W` for TCC context, results via --output file
            cmd = [
                "open", "-W", str(self._app_bundle),
                "--args", *extra_args, "--output", output_file,
            ]
        else:
            # Direct execution is fine for --check (no TCC needed)
            if self._binary is None:
                return {"status": "error", "error": "binary not set"}
            cmd = [str(self._binary), *extra_args]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()

        # Read result from output file or stdout
        raw = ""
        if output_file is not None:
            out_path = Path(output_file)
            if out_path.exists():
                raw = out_path.read_text(encoding="utf-8").strip()
                out_path.unlink(missing_ok=True)
        else:
            raw = stdout.decode(errors="replace").strip() if stdout else ""

        if not raw:
            return {"status": "error", "error": f"no output (rc={proc.returncode})"}
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {"status": "error", "error": raw}

    async def _run_check(self) -> dict:
        """Run ``--check`` — direct execution, no TCC needed."""
        return await self._run_via_open(
            "--check", "--language", self.settings.language,
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        if self.settings.binary_path:
            # Custom binary path — use directly (user manages TCC)
            candidate = Path(self.settings.binary_path)
            if not candidate.exists():
                raise RuntimeError(
                    f"macos-stt binary not found at {candidate}."
                )
            self._binary = candidate
            self._app_bundle = None
        else:
            app = self._DEFAULT_APP_BUNDLE
            binary = app / "Contents" / "MacOS" / "macos-stt-helper"
            if not binary.exists():
                raise RuntimeError(
                    f"macos-stt binary not found at {binary}. "
                    "Run scripts/engines/macos-stt/install.sh to compile it."
                )
            self._app_bundle = app
            self._binary = binary

        # Verify speech recognition availability via --check
        check = await self._run_check()
        if check.get("status") != "ok":
            err = check.get("error", "unknown authorization issue")
            logger.warning("macos-stt auth check failed: {}", err)
            raise RuntimeError(f"macos-stt not authorized: {err}")

        self._auth_ok = True
        self._started = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._binary = None
        self._app_bundle = None
        self._started = False
        self._auth_ok = False
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        if self._started and self._auth_ok:
            return True
        # Pre-start check: verify binary exists
        if self._binary is not None and self._binary.exists():
            return True
        # Check default location
        default = self._DEFAULT_APP_BUNDLE / "Contents" / "MacOS" / "macos-stt-helper"
        return default.exists()

    # ------------------------------------------------------------------
    # Transcription
    # ------------------------------------------------------------------

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if not self._started or self._binary is None:
            raise RuntimeError("Provider not started -- call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        opts = opts or STTOptions()
        language = opts.language or self.settings.language

        # Convert to WAV for the Swift helper.
        wav_audio = AudioConverter.to_wav(audio)

        tmp_wav: str | None = None
        tmp_out: str | None = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(wav_audio.data)
                tmp_wav = f.name
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
                tmp_out = f.name

            result = await self._run_via_open(
                "--audio", tmp_wav,
                "--language", language,
                output_file=tmp_out if self._app_bundle else None,
            )

            # When running without .app bundle (custom binary_path), _run_via_open
            # uses direct execution and reads stdout — handle that path too.
            if self._app_bundle is None and not result:
                raise RuntimeError("macos-stt-helper returned no output")

            if "error" in result:
                raise RuntimeError(
                    f"macos-stt-helper error: {result['error']}"
                )

            transcription = Transcription(
                text=result.get("text", ""),
                language=result.get("language"),
                confidence=result.get("confidence"),
            )
            logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(transcription.text))
            return transcription
        finally:
            if tmp_wav is not None:
                Path(tmp_wav).unlink(missing_ok=True)
            if tmp_out is not None:
                Path(tmp_out).unlink(missing_ok=True)

    def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError("macOS SFSpeechRecognizer does not support streaming via this provider")
