"""AssemblyAI STT provider adapter (batch, httpx)."""
from __future__ import annotations

import asyncio
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class AssemblyAISTTSettings(BaseSettings):
    api_key: str = ""
    model: str = "best"
    language: str = "en"

class AssemblyAISTT(STTProvider):
    name = "assemblyai-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.REMOTE
    settings_cls = AssemblyAISTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"model": ["best", "nano"], "language": ["en", "zh", "ja", "ko", "es", "fr", "de", "pt", "it", "nl", "ru", "ar", "hi", "auto"]}

    def __init__(self, settings: AssemblyAISTTSettings | None = None) -> None:
        self.settings = settings or AssemblyAISTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()
        opts = opts or STTOptions()
        language = opts.language or self.settings.language
        headers = {"Authorization": self.settings.api_key}

        # Step 1: Upload audio
        upload_resp = await self._client.post(
            "https://api.assemblyai.com/v2/upload",
            headers=headers,
            content=audio.data,
        )
        if upload_resp.status_code != 200:
            raise RuntimeError(
                f"AssemblyAI upload error {upload_resp.status_code}: {upload_resp.text}"
            )
        upload_url = upload_resp.json()["upload_url"]

        # Step 2: Create transcript
        create_resp = await self._client.post(
            "https://api.assemblyai.com/v2/transcript",
            headers=headers,
            json={
                "audio_url": upload_url,
                "language_code": language,
                "speech_model": self.settings.model,
            },
        )
        if create_resp.status_code != 200:
            raise RuntimeError(
                f"AssemblyAI transcript creation error "
                f"{create_resp.status_code}: {create_resp.text}"
            )
        transcript_id = create_resp.json()["id"]

        # Step 3: Poll until completed
        poll_url = f"https://api.assemblyai.com/v2/transcript/{transcript_id}"
        max_wait = 60.0
        elapsed = 0.0
        while elapsed < max_wait:
            poll_resp = await self._client.get(poll_url, headers=headers)
            if poll_resp.status_code != 200:
                raise RuntimeError(
                    f"AssemblyAI poll error {poll_resp.status_code}: {poll_resp.text}"
                )
            data = poll_resp.json()
            status = data.get("status", "")
            if status == "completed":
                result = Transcription(
                    text=data.get("text", ""),
                    language=language,
                    confidence=data.get("confidence"),
                )
                logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
                return result
            if status == "error":
                raise RuntimeError(
                    f"AssemblyAI transcription failed: {data.get('error', 'unknown')}"
                )
            await asyncio.sleep(1.0)
            elapsed += 1.0

        raise RuntimeError(
            f"AssemblyAI transcription timed out after {max_wait}s "
            f"for transcript {transcript_id}"
        )

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "AssemblyAI batch provider does not support streaming input"
        )
        yield  # pragma: no cover
