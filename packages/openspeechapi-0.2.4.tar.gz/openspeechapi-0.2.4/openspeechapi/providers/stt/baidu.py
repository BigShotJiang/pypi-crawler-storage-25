"""Baidu Cloud ASR STT provider adapter."""
from __future__ import annotations

import base64
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class BaiduSTTSettings(BaseSettings):
    api_key: str = ""
    secret_key: str = ""
    dev_pid: int = 1537  # 1537=普通话, 1737=英语, 1637=粤语

class BaiduSTT(STTProvider):
    name = "baidu-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = BaiduSTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"dev_pid": [1537, 1737, 1637, 1936, 1836]}

    def __init__(self, settings: BaiduSTTSettings | None = None) -> None:
        self.settings = settings or BaiduSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True
        self._token: str | None = None
        self._token_expires_at: float = 0.0

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        self._token = None
        self._token_expires_at = 0.0
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key) and bool(self.settings.secret_key)

    async def _get_token(self) -> str:
        """Fetch or return cached OAuth access token."""
        if self._token and time.time() < self._token_expires_at:
            return self._token

        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")

        resp = await self._client.get(
            "https://aip.baidubce.com/oauth/2.0/token",
            params={
                "grant_type": "client_credentials",
                "client_id": self.settings.api_key,
                "client_secret": self.settings.secret_key,
            },
        )
        resp.raise_for_status()
        data = resp.json()

        if "access_token" not in data:
            raise RuntimeError(
                f"Baidu OAuth error: {data.get('error_description', 'unknown')}"
            )

        self._token = data["access_token"]
        self._token_expires_at = time.time() + data.get("expires_in", 2592000) - 60
        return self._token  # type: ignore[return-value]

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        token = await self._get_token()
        base64_audio = base64.b64encode(audio.data).decode("utf-8")

        payload = {
            "format": "wav",
            "rate": 16000,
            "channel": 1,
            "cuid": "openspeechapi",
            "token": token,
            "dev_pid": self.settings.dev_pid,
            "speech": base64_audio,
            "len": len(audio.data),
        }

        resp = await self._client.post(
            "https://vop.baidu.com/server_api",
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()

        err_no = data.get("err_no", 0)
        if err_no != 0:
            raise RuntimeError(
                f"Baidu ASR error [{err_no}]: {data.get('err_msg', 'unknown')}"
            )

        results = data.get("result", [])
        text = results[0] if results else ""

        result = Transcription(text=text)
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
        return result

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError("Baidu STT streaming not implemented")
        yield  # noqa: unreachable — makes this an async generator
