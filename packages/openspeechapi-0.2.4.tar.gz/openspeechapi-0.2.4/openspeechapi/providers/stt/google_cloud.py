"""Google Cloud STT provider adapter (batch, httpx)."""
from __future__ import annotations

import base64
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class GoogleCloudSTTSettings(BaseSettings):
    api_key: str = ""
    model: str = "latest_long"
    language: str = "en-US"

class GoogleCloudSTT(STTProvider):
    name = "google-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.REMOTE
    settings_cls = GoogleCloudSTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"model": ["latest_long", "latest_short", "telephony", "command_and_search"], "language": ["en-US", "zh-CN", "ja-JP", "ko-KR", "es-ES", "fr-FR", "de-DE", "pt-BR", "it-IT", "ru-RU", "ar-SA", "hi-IN"]}

    def __init__(self, settings: GoogleCloudSTTSettings | None = None) -> None:
        self.settings = settings or GoogleCloudSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()
        opts = opts or STTOptions()
        language = opts.language or self.settings.language
        model = self.settings.model

        b64_audio = base64.b64encode(audio.data).decode("utf-8")
        url = (
            "https://speech.googleapis.com/v1/speech:recognize"
            f"?key={self.settings.api_key}"
        )
        body = {
            "config": {
                "encoding": "LINEAR16",
                "sampleRateHertz": audio.sample_rate,
                "languageCode": language,
                "model": model,
            },
            "audio": {"content": b64_audio},
        }
        response = await self._client.post(url, json=body)
        if response.status_code != 200:
            raise RuntimeError(
                f"Google Cloud STT API error {response.status_code}: {response.text}"
            )
        data = response.json()
        results = data.get("results", [])
        if not results:
            return Transcription(text="", language=language)
        alternative = results[0]["alternatives"][0]
        result = Transcription(
            text=alternative.get("transcript", ""),
            language=language,
            confidence=alternative.get("confidence"),
        )
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
        return result

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "Google Cloud STT batch provider does not support streaming input"
        )
        yield  # pragma: no cover
