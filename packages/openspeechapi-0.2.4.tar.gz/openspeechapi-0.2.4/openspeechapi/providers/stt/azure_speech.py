"""Azure Speech STT provider adapter (batch, httpx)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class AzureSpeechSTTSettings(BaseSettings):
    subscription_key: str = ""
    region: str = "eastus"
    language: str = "en-US"

class AzureSpeechSTT(STTProvider):
    name = "azure-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.REMOTE
    settings_cls = AzureSpeechSTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"language": ["en-US", "zh-CN", "ja-JP", "ko-KR", "es-ES", "fr-FR", "de-DE", "pt-BR", "it-IT", "ru-RU", "ar-SA", "hi-IN"], "region": ["eastus", "westus2", "westeurope", "eastasia", "southeastasia"]}

    def __init__(self, settings: AzureSpeechSTTSettings | None = None) -> None:
        self.settings = settings or AzureSpeechSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.subscription_key)

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()
        opts = opts or STTOptions()
        language = opts.language or self.settings.language
        region = self.settings.region

        url = (
            f"https://{region}.stt.speech.microsoft.com"
            f"/speech/recognition/conversation/cognitiveservices/v1"
            f"?language={language}"
        )
        headers = {
            "Ocp-Apim-Subscription-Key": self.settings.subscription_key,
            "Content-Type": "audio/wav",
        }
        response = await self._client.post(url, headers=headers, content=audio.data)
        if response.status_code != 200:
            raise RuntimeError(
                f"Azure Speech STT API error {response.status_code}: {response.text}"
            )
        data = response.json()
        recognition_status = data.get("RecognitionStatus", "")
        if recognition_status != "Success":
            return Transcription(text="", language=language)
        result = Transcription(
            text=data.get("DisplayText", ""),
            language=language,
            confidence=data.get("Confidence"),
        )
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
        return result

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "Azure Speech STT batch provider does not support streaming input"
        )
        yield  # pragma: no cover
