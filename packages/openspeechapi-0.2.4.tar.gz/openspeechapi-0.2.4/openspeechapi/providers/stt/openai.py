"""OpenAI STT provider adapter (Whisper API)."""
from __future__ import annotations

import io
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class OpenAISTTSettings(BaseSettings):
    api_key: str = ""
    base_url: str = ""
    model: str = "whisper-1"

class OpenAISTT(STTProvider):
    name = "openai-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = OpenAISTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"model": ["whisper-1", "gpt-4o-transcribe", "gpt-4o-mini-transcribe"]}

    def __init__(self, settings: OpenAISTTSettings | None = None) -> None:
        self.settings = settings or OpenAISTTSettings()
        self._client: Any = None

    async def start(self) -> None:
        try:
            from openai import AsyncOpenAI
            kwargs: dict[str, Any] = {"api_key": self.settings.api_key}
            if self.settings.base_url:
                kwargs["base_url"] = self.settings.base_url
            self._client = AsyncOpenAI(**kwargs)
        except ImportError:
            raise ImportError("Install openai: pip install openspeechapi[openai]")
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()
        opts = opts or STTOptions()
        audio_file = io.BytesIO(audio.data)
        audio_file.name = "audio.wav"
        kwargs: dict[str, Any] = {
            "model": self.settings.model,
            "file": audio_file,
        }
        if opts.language:
            kwargs["language"] = opts.language
        if opts.prompt:
            kwargs["prompt"] = opts.prompt
        if opts.temperature is not None:
            kwargs["temperature"] = opts.temperature
        response = await self._client.audio.transcriptions.create(**kwargs)
        result = Transcription(text=response.text, language=opts.language)
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
        return result

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "OpenAI Whisper API does not support streaming input"
        )
        yield  # pragma: no cover
