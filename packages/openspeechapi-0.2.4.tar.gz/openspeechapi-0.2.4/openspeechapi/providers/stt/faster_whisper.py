"""Faster-Whisper STT provider adapter (local, subprocess mode)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import os
from pathlib import Path
import tempfile
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription, Word
from openspeechapi.core.settings import BaseSettings

@dataclass
class FasterWhisperSTTSettings(BaseSettings):
    model_size: str = "base"
    device: str = "auto"
    compute_type: str = "default"
    download_root: str | None = None
    beam_size: int = 5

class FasterWhisperSTT(STTProvider):
    name = "faster-whisper"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.SUBPROCESS
    settings_cls = FasterWhisperSTTSettings
    capabilities = {
        Capability.BATCH,
        Capability.MULTILINGUAL,
        Capability.WORD_TIMESTAMPS,
    }
    field_options = {"device": ["auto", "cpu", "cuda", "mps"], "compute_type": ["default", "auto", "float16", "float32", "int8", "int8_float16"], "model_size": ["tiny", "base", "small", "medium", "large-v2", "large-v3", "large-v3-turbo"]}

    def __init__(self, settings: FasterWhisperSTTSettings | None = None) -> None:
        self.settings = settings or FasterWhisperSTTSettings()
        self._client: Any = None
        self._model: Any = None
        self._loaded_model_size = self.settings.model_size
        self._loaded_device = self.settings.device
        self._loaded_compute_type = self.settings.compute_type

    async def start(self) -> None:
        await self._ensure_model(
            model_size=self.settings.model_size,
            device=self.settings.device,
            compute_type=self.settings.compute_type,
        )
        logger.info("{} provider started", self.name)

    async def _ensure_model(
        self,
        *,
        model_size: str,
        device: str,
        compute_type: str,
    ) -> None:
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            raise ImportError(
                "Install faster-whisper: pip install openspeechapi[faster-whisper]"
            )

        normalized_model_size = self._resolve_model_dir(model_size)

        if (
            self._model is not None
            and self._loaded_model_size == normalized_model_size
            and self._loaded_device == device
            and self._loaded_compute_type == compute_type
        ):
            return

        self._model = WhisperModel(
            normalized_model_size,
            device=device,
            compute_type=compute_type,
            download_root=self.settings.download_root,
        )
        self._client = self._model  # for health_check
        self._loaded_model_size = normalized_model_size
        self._loaded_device = device
        self._loaded_compute_type = compute_type

    @staticmethod
    def _resolve_model_dir(model_size: str) -> str:
        raw = (model_size or "").strip()
        p = Path(raw).expanduser()
        if not p.is_absolute() or not p.exists() or not p.is_dir():
            return raw
        if (p / "model.bin").exists():
            return str(p)
        snapshots = p / "snapshots"
        if snapshots.is_dir():
            for d in sorted(snapshots.iterdir()):
                if d.is_dir() and (d / "model.bin").exists():
                    return str(d)
        return str(p)

    async def stop(self) -> None:
        self._client = None
        self._model = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return self._client is not None

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        opts = opts or STTOptions()
        requested_model = (opts.model or self.settings.model_size).strip()
        requested_device = (opts.device or self.settings.device).strip()
        requested_compute_type = (opts.compute_type or self.settings.compute_type).strip()
        await self._ensure_model(
            model_size=requested_model,
            device=requested_device,
            compute_type=requested_compute_type,
        )

        # Ensure proper WAV headers — raw PCM from TTS providers needs wrapping
        import io
        import wave

        is_wav = len(audio.data) > 4 and audio.data[:4] == b"RIFF"
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            if is_wav:
                f.write(audio.data)
            else:
                buf = io.BytesIO()
                with wave.open(buf, "wb") as wf:
                    wf.setnchannels(audio.channels)
                    wf.setsampwidth(2)
                    wf.setframerate(audio.sample_rate)
                    wf.writeframes(audio.data)
                f.write(buf.getvalue())
            tmp_path = f.name

        try:
            beam_size = int(opts.beam_size) if opts.beam_size is not None else int(self.settings.beam_size)
            kwargs: dict[str, Any] = {"beam_size": beam_size}
            if opts.language:
                kwargs["language"] = opts.language

            segments, info = self._model.transcribe(tmp_path, **kwargs)

            text_parts = []
            words_list: list[Word] = []
            max_end_s = 0.0
            for segment in segments:
                text_parts.append(segment.text)
                seg_end = getattr(segment, "end", None)
                if seg_end is not None:
                    try:
                        max_end_s = max(max_end_s, float(seg_end))
                    except Exception:
                        pass
                if hasattr(segment, "words") and segment.words:
                    for w in segment.words:
                        words_list.append(
                            Word(
                                text=w.word,
                                start_ms=int(w.start * 1000),
                                end_ms=int(w.end * 1000),
                                confidence=getattr(w, "probability", None),
                            )
                        )
                        try:
                            max_end_s = max(max_end_s, float(w.end))
                        except Exception:
                            pass

            duration_ms: int | None = None
            info_duration = getattr(info, "duration", None)
            if info_duration is not None:
                try:
                    duration_ms = int(float(info_duration) * 1000)
                except Exception:
                    duration_ms = None
            if duration_ms is None and max_end_s > 0:
                duration_ms = int(max_end_s * 1000)

            result = Transcription(
                text=" ".join(text_parts).strip(),
                language=info.language if hasattr(info, "language") else None,
                confidence=getattr(info, "language_probability", None),
                words=words_list if words_list else None,
                duration_ms=duration_ms,
            )
            logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
            return result
        finally:
            os.unlink(tmp_path)

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "FasterWhisperSTT does not support streaming transcription"
        )
        yield  # pragma: no cover
