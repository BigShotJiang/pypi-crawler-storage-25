"""ElevenLabs STT provider adapter (batch + realtime WS)."""
from __future__ import annotations

import asyncio
import base64
import inspect
import json
from urllib.parse import urlencode
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import STTProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription, Word
from openspeechapi.core.settings import BaseSettings
from openspeechapi.logging_config import logger


def _ws_connect_with_headers(websockets_mod, url: str, headers: dict[str, str]):
    """Compatible connect kwargs across websockets versions.

    websockets>=15 uses ``additional_headers``; older versions use ``extra_headers``.
    """
    try:
        sig = inspect.signature(websockets_mod.connect)
        if "additional_headers" in sig.parameters:
            return websockets_mod.connect(url, additional_headers=headers)
    except Exception:
        pass
    return websockets_mod.connect(url, extra_headers=headers)


@dataclass
class ElevenLabsSTTSettings(BaseSettings):
    api_key: str = ""
    model_id: str = "scribe_v2"
    realtime_model_id: str = "scribe_v2_realtime"
    language_code: str = ""
    diarize: bool = False
    tag_audio_events: bool = True
    num_speakers: int | None = None
    timestamps_granularity: str = "word"
    diarization_threshold: float | None = None
    use_multi_channel: bool = False
    no_verbatim: bool = False
    detect_speaker_roles: bool = False
    temperature: float | None = None
    entity_detection: str = ""
    realtime_audio_format: str = "pcm_16000"
    realtime_commit_strategy: str = "vad"  # manual | vad
    realtime_include_timestamps: bool = True
    realtime_include_language_detection: bool = True
    realtime_vad_silence_threshold_secs: float = 1.0


class ElevenLabsSTT(STTProvider):
    name = "elevenlabs-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.REMOTE
    settings_cls = ElevenLabsSTTSettings
    capabilities = {Capability.BATCH, Capability.STREAMING, Capability.MULTILINGUAL}
    field_options = {
        "model_id": ["scribe_v2", "scribe_v1"],
        "realtime_model_id": ["scribe_v2_realtime"],
        "realtime_audio_format": ["pcm_16000", "pcm_22050", "pcm_24000", "pcm_44100"],
        "realtime_commit_strategy": ["vad", "manual"],
        "timestamps_granularity": ["none", "word", "character"],
        "language_code": [
            "",
            "en", "zh", "ja", "ko", "es", "fr", "de", "pt", "it", "hi",
            "id", "nl", "tr", "pl", "sv", "ar", "ru", "uk", "vi", "hu",
            "no", "da", "fi", "cs", "el", "ro", "bg", "hr", "sk", "ms",
            "ta", "fil",
        ],
        "diarize": [False, True],
        "tag_audio_events": [True, False],
        "no_verbatim": [False, True],
        "detect_speaker_roles": [False, True],
        "use_multi_channel": [False, True],
    }

    def __init__(self, settings: ElevenLabsSTTSettings | None = None) -> None:
        self.settings = settings or ElevenLabsSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0, trust_env=False)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")

        opts = opts or STTOptions()
        language_code = (opts.language or self.settings.language_code or "").strip()

        data: dict[str, str] = {
            "model_id": self.settings.model_id,
            "diarize": "true" if self.settings.diarize else "false",
            "tag_audio_events": "true" if self.settings.tag_audio_events else "false",
            "timestamps_granularity": self.settings.timestamps_granularity,
            "no_verbatim": "true" if self.settings.no_verbatim else "false",
            "detect_speaker_roles": "true" if self.settings.detect_speaker_roles else "false",
            "use_multi_channel": "true" if self.settings.use_multi_channel else "false",
        }
        if language_code:
            data["language_code"] = language_code
        if self.settings.num_speakers is not None:
            data["num_speakers"] = str(self.settings.num_speakers)
        if self.settings.diarization_threshold is not None:
            data["diarization_threshold"] = str(self.settings.diarization_threshold)
        if self.settings.temperature is not None:
            data["temperature"] = str(self.settings.temperature)
        if self.settings.entity_detection:
            data["entity_detection"] = self.settings.entity_detection

        files = {
            "file": (
                "audio",
                audio.data,
                self._mime_for_format(audio.format),
            )
        }
        headers = {"xi-api-key": self.settings.api_key}

        resp = await self._client.post(
            "https://api.elevenlabs.io/v1/speech-to-text",
            headers=headers,
            data=data,
            files=files,
        )
        if resp.status_code != 200:
            raise RuntimeError(
                f"ElevenLabs STT API error {resp.status_code}: {resp.text}"
            )

        payload = resp.json()
        text = str(payload.get("text", "") or "")
        if not text and isinstance(payload.get("transcripts"), list):
            parts: list[str] = []
            for item in payload.get("transcripts", []):
                channel_text = str((item or {}).get("text", "") or "").strip()
                if channel_text:
                    parts.append(channel_text)
            text = "\n".join(parts)
        response_lang = payload.get("language_code")

        words: list[Word] = []
        source_word_lists = []
        if isinstance(payload.get("words"), list):
            source_word_lists.append(payload.get("words", []))
        if isinstance(payload.get("transcripts"), list):
            for item in payload.get("transcripts", []):
                if isinstance((item or {}).get("words"), list):
                    source_word_lists.append((item or {}).get("words", []))
        for word_items in source_word_lists:
            for item in word_items:
                wtxt = str(item.get("text", "") or "").strip()
                if not wtxt:
                    continue
                start_ms = int(float(item.get("start", 0.0) or 0.0) * 1000)
                end_ms = int(float(item.get("end", 0.0) or 0.0) * 1000)
                words.append(
                    Word(
                        text=wtxt,
                        start_ms=start_ms,
                        end_ms=end_ms,
                    )
                )

        return Transcription(
            text=text,
            language=response_lang or (language_code or None),
            confidence=float(payload.get("language_probability", 0.0) or 0.0)
            if payload.get("language_probability") is not None
            else None,
            words=words if words else None,
        )

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        """Realtime STT over ElevenLabs WebSocket.

        Protocol summary (official docs):
        - Connect: ``wss://api.elevenlabs.io/v1/speech-to-text/realtime``
        - Send audio frames as ``input_audio_chunk`` with base64 payload
        - Receive ``partial_transcript`` and ``committed_transcript*`` events
        """
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")

        import websockets

        params = {
            "model_id": self.settings.realtime_model_id,
            "audio_format": self.settings.realtime_audio_format,
            "commit_strategy": self.settings.realtime_commit_strategy,
            "include_timestamps": "true" if self.settings.realtime_include_timestamps else "false",
            "include_language_detection": "true" if self.settings.realtime_include_language_detection else "false",
            "vad_silence_threshold_secs": str(self.settings.realtime_vad_silence_threshold_secs),
        }
        language_code = (self.settings.language_code or "").strip()
        if language_code:
            params["language_code"] = language_code

        url = "wss://api.elevenlabs.io/v1/speech-to-text/realtime?" + urlencode(params)
        headers = {"xi-api-key": self.settings.api_key}

        logger.debug("{}: connecting realtime WS...", self.name)
        _frames_sent = 0
        _sender_done = asyncio.Event()
        _confirmed_parts: list[str] = []
        _last_partial: str = ""
        results: asyncio.Queue[Transcription | None] = asyncio.Queue()

        async with _ws_connect_with_headers(websockets, url, headers) as ws:
            async def _sender() -> None:
                nonlocal _frames_sent
                try:
                    async for chunk in stream:
                        if not chunk:
                            continue
                        payload = {
                            "message_type": "input_audio_chunk",
                            "audio_base_64": base64.b64encode(chunk).decode("ascii"),
                            "sample_rate": 16000,
                        }
                        # In manual mode, we explicitly commit each frame.
                        if self.settings.realtime_commit_strategy == "manual":
                            payload["commit"] = True
                        await ws.send(json.dumps(payload))
                        _frames_sent += 1
                finally:
                    # Trigger a final commit after stream ends to flush any buffered text.
                    if self.settings.realtime_commit_strategy != "manual":
                        try:
                            await ws.send(json.dumps({
                                "message_type": "input_audio_chunk",
                                "audio_base_64": "",
                                "sample_rate": 16000,
                                "commit": True,
                            }))
                        except Exception:
                            pass
                    _sender_done.set()

            async def _receiver() -> None:
                nonlocal _last_partial
                try:
                    async for raw in ws:
                        data = json.loads(raw)
                        mtype = str(data.get("message_type", "") or "")
                        if mtype == "session_started":
                            continue

                        if mtype.startswith("scribe") or mtype == "error":
                            detail = data.get("message") or data.get("detail") or data
                            raise RuntimeError(f"ElevenLabs realtime STT error: {detail}")

                        if mtype == "partial_transcript":
                            partial = str(data.get("text", "") or "").strip()
                            if not partial:
                                continue
                            _last_partial = partial
                            snapshot = self._snapshot_text(_confirmed_parts, _last_partial)
                            if not snapshot:
                                continue
                            await results.put(Transcription(
                                text=snapshot,
                                language=data.get("language_code") or language_code or None,
                                confidence=data.get("confidence"),
                                is_partial=True,
                            ))
                            continue

                        if mtype in {"committed_transcript", "committed_transcript_with_timestamps"}:
                            committed = str(data.get("text", "") or "").strip()
                            if committed:
                                if not _confirmed_parts or _confirmed_parts[-1] != committed:
                                    _confirmed_parts.append(committed)
                            _last_partial = ""
                            snapshot = self._snapshot_text(_confirmed_parts, _last_partial)
                            if not snapshot:
                                continue
                            words = None
                            if mtype == "committed_transcript_with_timestamps":
                                words = self._parse_stream_words(data.get("words") or [])
                            await results.put(Transcription(
                                text=snapshot,
                                language=data.get("language_code") or language_code or None,
                                confidence=data.get("confidence"),
                                words=words,
                                is_partial=False,
                            ))
                finally:
                    await results.put(None)

            sender_task = asyncio.create_task(_sender())
            receiver_task = asyncio.create_task(_receiver())

            while True:
                try:
                    timeout = 1.2 if _sender_done.is_set() else None
                    item = await asyncio.wait_for(results.get(), timeout=timeout)
                except asyncio.TimeoutError:
                    break
                if item is None:
                    break
                yield item

            if not sender_task.done():
                sender_task.cancel()
            if not receiver_task.done():
                receiver_task.cancel()
            for task in (sender_task, receiver_task):
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        logger.debug("{}: realtime WS finished, sent {} frames", self.name, _frames_sent)

    @staticmethod
    def _mime_for_format(fmt: AudioFormat) -> str:
        if fmt == AudioFormat.WAV:
            return "audio/wav"
        if fmt == AudioFormat.MP3:
            return "audio/mpeg"
        if fmt == AudioFormat.FLAC:
            return "audio/flac"
        if fmt == AudioFormat.OGG:
            return "audio/ogg"
        if fmt == AudioFormat.OPUS:
            return "audio/opus"
        if fmt in (AudioFormat.PCM_16K, AudioFormat.PCM_44K):
            return "audio/wav"
        return "application/octet-stream"

    @staticmethod
    def _snapshot_text(confirmed_parts: list[str], partial: str) -> str:
        base = " ".join([p for p in confirmed_parts if p]).strip()
        p = (partial or "").strip()
        if not base:
            return p
        if not p:
            return base
        if p.startswith(base):
            return p
        return f"{base} {p}".strip()

    @staticmethod
    def _parse_stream_words(words_payload: list[dict]) -> list[Word] | None:
        words: list[Word] = []
        for item in words_payload:
            if str(item.get("type", "word")) != "word":
                continue
            txt = str(item.get("text", "") or "").strip()
            if not txt:
                continue
            start_ms = int(float(item.get("start", 0.0) or 0.0) * 1000)
            end_ms = int(float(item.get("end", 0.0) or 0.0) * 1000)
            words.append(Word(text=txt, start_ms=start_ms, end_ms=end_ms))
        return words or None
