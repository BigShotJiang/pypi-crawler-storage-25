"""Alibaba Cloud (Bailian/DashScope) STT provider adapter — OpenAI-compatible."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class AlibabaSTTSettings(BaseSettings):
    api_key: str = ""
    model: str = "paraformer-v2"
    base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"

class AlibabaSTT(STTProvider):
    name = "alibaba-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = AlibabaSTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"model": ["paraformer-v2", "paraformer-realtime-v2", "paraformer-8k-v1"]}

    def __init__(self, settings: AlibabaSTTSettings | None = None) -> None:
        self.settings = settings or AlibabaSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        opts = opts or STTOptions()
        model = opts.model or self.settings.model
        url = f"{self.settings.base_url}/audio/transcriptions"

        headers = {"Authorization": f"Bearer {self.settings.api_key}"}
        files = {"file": ("audio.wav", audio.data, "audio/wav")}
        data = {"model": model}

        resp = await self._client.post(
            url, headers=headers, files=files, data=data
        )
        resp.raise_for_status()
        result = resp.json()

        transcription = Transcription(text=result.get("text", ""))
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(transcription.text))
        return transcription

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError("Alibaba STT streaming not implemented")
        yield  # noqa: unreachable — makes this an async generator
