"""OpenAI Whisper (local) STT provider adapter (subprocess mode)."""
from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
import io
from openspeechapi.logging_config import logger
import os
import tempfile
import time
from typing import Any
import wave

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription, Word
from openspeechapi.core.settings import BaseSettings

@dataclass
class WhisperSTTSettings(BaseSettings):
    model_name: str = "base"
    device: str = "cpu"
    fp16: bool = False
    download_root: str | None = None
    beam_size: int = 5

class WhisperSTT(STTProvider):
    name = "whisper"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.SUBPROCESS
    settings_cls = WhisperSTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"device": ["cpu", "cuda", "mps"], "model_name": ["tiny", "base", "small", "medium", "large-v2", "large-v3", "large-v3-turbo"]}

    def __init__(self, settings: WhisperSTTSettings | None = None) -> None:
        self.settings = settings or WhisperSTTSettings()
        self._client: Any = None
        self._model: Any = None
        self._loaded_model_name = self.settings.model_name
        self._loaded_device = self.settings.device

    async def start(self) -> None:
        await self._ensure_model(
            model_name=self.settings.model_name,
            device=self.settings.device,
        )
        logger.info("{} provider started", self.name)

    async def _ensure_model(self, *, model_name: str, device: str) -> None:
        try:
            import whisper
        except ImportError:
            raise ImportError(
                "Install whisper: pip install openspeechapi[whisper]"
            )
        if (
            self._model is not None
            and self._loaded_model_name == model_name
            and self._loaded_device == device
        ):
            return
        self._model = whisper.load_model(
            model_name,
            device=device,
            download_root=self.settings.download_root,
        )
        self._client = self._model
        self._loaded_model_name = model_name
        self._loaded_device = device

    async def stop(self) -> None:
        self._client = None
        self._model = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return self._client is not None

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()
        opts = opts or STTOptions()
        requested_model = (opts.model or self.settings.model_name).strip()
        requested_device = (opts.device or self.settings.device).strip()
        await self._ensure_model(model_name=requested_model, device=requested_device)

        is_wav = len(audio.data) > 4 and audio.data[:4] == b"RIFF"
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            if is_wav:
                f.write(audio.data)
            else:
                buf = io.BytesIO()
                with wave.open(buf, "wb") as wf:
                    wf.setnchannels(audio.channels)
                    wf.setsampwidth(2)
                    wf.setframerate(audio.sample_rate)
                    wf.writeframes(audio.data)
                f.write(buf.getvalue())
            tmp_path = f.name

        try:
            kwargs: dict[str, Any] = {
                "fp16": bool(self.settings.fp16 if opts.fp16 is None else opts.fp16),
                "beam_size": int(self.settings.beam_size if opts.beam_size is None else opts.beam_size),
                "word_timestamps": True,
            }
            if opts.language:
                kwargs["language"] = opts.language
            result = self._model.transcribe(tmp_path, **kwargs)

            segments = result.get("segments") or []
            words: list[Word] = []
            for seg in segments:
                for item in (seg.get("words") or []):
                    word_text = str(item.get("word", "")).strip()
                    if not word_text:
                        continue
                    words.append(
                        Word(
                            text=word_text,
                            start_ms=int(float(item.get("start", 0.0)) * 1000),
                            end_ms=int(float(item.get("end", 0.0)) * 1000),
                            confidence=float(item["probability"]) if item.get("probability") is not None else None,
                        )
                    )
            duration_ms: int | None = None
            if segments:
                last_end = float(segments[-1].get("end", 0.0))
                if last_end > 0:
                    duration_ms = int(last_end * 1000)
            transcription = Transcription(
                text=str(result.get("text", "")).strip(),
                language=result.get("language"),
                words=words or None,
                duration_ms=duration_ms,
            )
            logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(transcription.text))
            return transcription
        finally:
            os.unlink(tmp_path)

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "WhisperSTT does not support streaming transcription"
        )
        yield  # pragma: no cover
