"""iFlytek (讯飞) STT provider adapter — WebSocket-based."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
from openspeechapi.logging_config import logger
import time
import urllib.parse
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import formatdate
from typing import Any

import httpx
import websockets

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class IflytekSTTSettings(BaseSettings):
    app_id: str = ""
    api_key: str = ""
    api_secret: str = ""
    # iFlytek-canonical language code. Acceptable values per iFlytek
    # IAT docs: ``zh_cn``, ``en_us``, ``ja_jp``, ``ko_kr``, ``ru-ru``.
    # Common ISO short codes (``en``, ``zh``, ``ja``, ``ko``, ``ru``)
    # are accepted here and mapped on the request hop — see
    # ``_canonical_language``. iFlytek silently falls back to ``zh_cn``
    # when given an unrecognised value, so the alias mapping prevents
    # English audio from being transcribed by the Chinese model
    # (caught 04-28 by an "english only" deployment that had set
    # ``language: en`` and got hanzi back).
    language: str = "zh_cn"
    # ``vad_eos`` — milliseconds of trailing silence iFlytek treats as
    # end-of-sentence before emitting the final result (``status == 2``).
    # iFlytek's documented default is 2000; lower values give faster
    # finalization at the cost of cutting off slow speakers mid-thought.
    # The 04-28 17:00 audit found vad_eos=2000 contributed ~89% of the
    # user-perceived latency budget — the speech itself only used ~3 s
    # but iFlytek waited an additional 2 s of silence before declaring
    # final. Common production values: 800-1000 (responsive),
    # 1500 (conservative), 2000 (default, slow). Below ~500 risks
    # premature finalization on natural pauses. Per-deployment override
    # via ``speech_providers.yaml`` so different sites can pick their
    # own latency-vs-tolerance trade-off.
    vad_eos: int = 2000


# iFlytek expects the full locale tag; common ISO short codes need to
# be translated. Keys are casefolded for tolerant matching. Values are
# the iFlytek-canonical strings the WS request will carry.
_LANGUAGE_ALIASES: dict[str, str] = {
    # Canonical pass-through (allow case variation)
    "zh_cn": "zh_cn", "en_us": "en_us", "ja_jp": "ja_jp",
    "ko_kr": "ko_kr", "ru-ru": "ru-ru", "ru_ru": "ru-ru",
    # ISO 639-1 short codes — most config sources use these
    "zh": "zh_cn", "zh-cn": "zh_cn", "zh-hans": "zh_cn",
    "en": "en_us", "en-us": "en_us", "en-gb": "en_us",
    "ja": "ja_jp", "ja-jp": "ja_jp",
    "ko": "ko_kr", "ko-kr": "ko_kr",
    "ru": "ru-ru",
}


def _canonical_language(raw: str | None) -> str:
    """Translate a configured language string to iFlytek's canonical form.

    Returns the iFlytek-canonical code (e.g. ``en_us``). Unknown inputs
    pass through unchanged so iFlytek surfaces a real protocol error
    instead of silently falling back to Chinese.
    """
    if not raw:
        return "zh_cn"
    return _LANGUAGE_ALIASES.get(raw.casefold().strip(), raw)


class IflytekSTT(STTProvider):
    name = "iflytek-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = IflytekSTTSettings
    capabilities = {Capability.BATCH, Capability.STREAMING, Capability.MULTILINGUAL}
    field_options = {
        "language": ["zh_cn", "en_us", "ja_jp", "ko_kr", "ru-ru"],
    }

    _WS_HOST = "iat-api.xfyun.cn"
    _WS_PATH = "/v2/iat"

    def __init__(self, settings: IflytekSTTSettings | None = None) -> None:
        self.settings = settings or IflytekSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        # Surface the effective language (after alias mapping) and
        # vad_eos at startup so deployments can verify the iFlytek model
        # and silence-finalization threshold that will actually run.
        # The 04-28 audit caught a deployment shipping ``language: en``
        # (invalid) which silently routed every request to the Chinese
        # model; an analogous oversight on vad_eos would silently
        # double the user-perceived latency. Logging both makes
        # mis-config obvious from the first request.
        effective = _canonical_language(self.settings.language)
        if effective != self.settings.language:
            logger.info(
                "{} provider started, language={!r} (canonicalized from {!r}), vad_eos={}ms",
                self.name, effective, self.settings.language, self.settings.vad_eos,
            )
        else:
            logger.info(
                "{} provider started, language={!r}, vad_eos={}ms",
                self.name, effective, self.settings.vad_eos,
            )

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.app_id) and bool(self.settings.api_key) and bool(self.settings.api_secret)

    def _build_auth_url(self) -> str:
        """Build HMAC-SHA256 signed WebSocket URL."""
        now = datetime.now(tz=timezone.utc)
        date = formatdate(timeval=now.timestamp(), localtime=False, usegmt=True)

        signature_origin = (
            f"host: {self._WS_HOST}\n"
            f"date: {date}\n"
            f"GET {self._WS_PATH} HTTP/1.1"
        )
        signature_sha = hmac.new(
            self.settings.api_secret.encode("utf-8"),
            signature_origin.encode("utf-8"),
            hashlib.sha256,
        ).digest()
        signature = base64.b64encode(signature_sha).decode("utf-8")

        authorization_origin = (
            f'api_key="{self.settings.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature}"'
        )
        authorization = base64.b64encode(
            authorization_origin.encode("utf-8")
        ).decode("utf-8")

        params = urllib.parse.urlencode(
            {"authorization": authorization, "date": date, "host": self._WS_HOST}
        )
        return f"wss://{self._WS_HOST}{self._WS_PATH}?{params}"

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        url = self._build_auth_url()
        audio_bytes = audio.data
        # iFlytek recommends ~40ms per frame at 16kHz 16bit mono = 1280 bytes.
        # Use larger frames (8000 bytes = ~250ms) with pacing to avoid server
        # read-timeout when sending pre-recorded audio faster than real-time.
        frame_size = 8000  # bytes per chunk (~250ms of 16kHz 16bit mono)
        # Pacing: small delay between frames to avoid server read-timeout
        # when sending pre-recorded audio faster than real-time.
        # 8000 bytes = 250ms of audio; 10ms interval = ~25x real-time.
        frame_interval = 0.01  # 10ms between frames (~25x real-time)

        result_texts: list[str] = []

        async with websockets.connect(url) as ws:
            # Send audio in chunks with interleaved receive
            total = len(audio_bytes)
            offset = 0
            status = 0  # 0=first frame
            frames_sent = 0

            while offset < total:
                end = min(offset + frame_size, total)
                chunk = audio_bytes[offset:end]

                if end >= total:
                    status = 2  # last frame
                elif offset > 0:
                    status = 1  # continue

                frame_data = base64.b64encode(chunk).decode("utf-8")

                if status == 0:
                    # First frame includes common and business params.
                    # ``accent="mandarin"`` is only meaningful for the
                    # Chinese model; sending it on en_us / ja_jp / etc.
                    # is a wire-level no-op on iFlytek's side but
                    # confuses anyone reading the request body, so
                    # gate it on the canonical language.
                    canon = _canonical_language(self.settings.language)
                    # Per-call override (``opts.vad_eos``) trumps the
                    # provider default. Wallex routes the panel's
                    # ``parameter.iat.eos`` through here so a kiosk
                    # can ship a tighter or looser silence threshold
                    # than the deployment yaml.
                    eos = (opts.vad_eos
                           if opts is not None and opts.vad_eos is not None
                           else self.settings.vad_eos)
                    business = {
                        "language": canon,
                        "domain": "iat",
                        "vad_eos": eos,
                    }
                    if canon == "zh_cn":
                        business["accent"] = "mandarin"
                    msg = {
                        "common": {"app_id": self.settings.app_id},
                        "business": business,
                        "data": {
                            "status": 0,
                            "format": "audio/L16;rate=16000",
                            "encoding": "raw",
                            "audio": frame_data,
                        },
                    }
                else:
                    msg = {
                        "data": {
                            "status": status,
                            "format": "audio/L16;rate=16000",
                            "encoding": "raw",
                            "audio": frame_data,
                        }
                    }

                await ws.send(json.dumps(msg))
                frames_sent += 1
                offset = end

                # Pacing: small delay between frames to avoid server timeout
                if status != 2 and frame_interval > 0:
                    await asyncio.sleep(frame_interval)

            logger.debug("{}: sent {} frames in {:.0f}ms", self.name, frames_sent,
                         (time.perf_counter() - _t0) * 1000)

            # Receive results
            async for message in ws:
                resp = json.loads(message)
                code = resp.get("code", -1)
                if code != 0:
                    raise RuntimeError(
                        f"iFlytek STT error [{code}]: {resp.get('message', 'unknown')}"
                    )

                data = resp.get("data", {})
                result = data.get("result", {})
                ws_items = result.get("ws", [])
                for ws_item in ws_items:
                    cw_list = ws_item.get("cw", [])
                    for cw in cw_list:
                        result_texts.append(cw.get("w", ""))

                if data.get("status") == 2:
                    break

        result = Transcription(text="".join(result_texts))
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
        return result

    @staticmethod
    def _extract_segment_text(ws_items: list[dict]) -> str:
        """Extract text from a single response's ws array."""
        parts: list[str] = []
        for ws_item in ws_items:
            for cw in ws_item.get("cw", []):
                parts.append(cw.get("w", ""))
        return "".join(parts)

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes], opts: STTOptions | None = None,
    ) -> AsyncIterator[Transcription]:
        """Stream audio chunks to iFlytek via WebSocket and yield transcriptions.

        Each bytes chunk from *stream* is a raw PCM frame (16kHz 16bit mono).
        A ``None`` or empty chunk signals end-of-stream (VAD end).

        The implementation uses two concurrent coroutines:
        - **sender**: reads chunks from *stream* and forwards them to iFlytek
          with natural pacing (frames arrive at ~real-time from the mic).
        - **receiver**: reads iFlytek responses, parses ``dwa=wpgs`` dynamic
          correction fields (``pgs``/``rg``), maintains a segment array, and
          yields partial ``Transcription`` on every response plus a final one
          on ``status == 2``.

        wpgs protocol:
        - ``pgs="apd"``: append — new segment at index ``sn``
        - ``pgs="rpl"``: replace — replace segments ``rg[0]..rg[1]`` with
          new content, effectively a correction of earlier partial results
        - No ``pgs`` field: legacy mode (no dynamic correction) — accumulate
        """
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")

        url = self._build_auth_url()
        results: asyncio.Queue[Transcription | None] = asyncio.Queue()
        _t0 = time.perf_counter()
        _frames_sent = 0

        # Event to signal sender to stop (set by receiver when iFlytek
        # returns status=2 or the connection closes). This handles the case
        # where the user doesn't click stop — iFlytek's VAD triggers a final
        # result, and we need the sender to stop consuming the frame queue.
        _sender_stop = asyncio.Event()

        logger.debug("{}: connecting to iFlytek WebSocket...", self.name)
        async with websockets.connect(url) as ws:
            _t_connected = time.perf_counter()
            logger.info("{}: WS connected in {:.0f}ms", self.name,
                        (_t_connected - _t0) * 1000)

            async def sender() -> None:
                nonlocal _frames_sent
                is_first = True
                try:
                    async for chunk in stream:
                        # Check if receiver signaled us to stop
                        if _sender_stop.is_set():
                            break
                        if chunk is None or len(chunk) == 0:
                            # End-of-stream sentinel — send last frame
                            break
                        frame_data = base64.b64encode(chunk).decode("utf-8")
                        if is_first:
                            # See transcribe() for rationale on
                            # canonicalizing language and gating accent.
                            canon = _canonical_language(self.settings.language)
                            # Per-call ``opts.vad_eos`` (e.g. wallex
                            # forwarding the panel's ``parameter.iat.eos``)
                            # trumps the provider's configured default.
                            eos = (opts.vad_eos
                                   if opts is not None and opts.vad_eos is not None
                                   else self.settings.vad_eos)
                            business = {
                                "language": canon,
                                "domain": "iat",
                                "dwa": "wpgs",
                                "vad_eos": eos,
                            }
                            if canon == "zh_cn":
                                business["accent"] = "mandarin"
                            msg = {
                                "common": {"app_id": self.settings.app_id},
                                "business": business,
                                "data": {
                                    "status": 0,
                                    "format": "audio/L16;rate=16000",
                                    "encoding": "raw",
                                    "audio": frame_data,
                                },
                            }
                            is_first = False
                        else:
                            msg = {
                                "data": {
                                    "status": 1,
                                    "format": "audio/L16;rate=16000",
                                    "encoding": "raw",
                                    "audio": frame_data,
                                }
                            }
                        await ws.send(json.dumps(msg))
                        _frames_sent += 1
                        if _frames_sent == 1:
                            logger.debug("{}: first frame sent at {:.0f}ms",
                                         self.name, (time.perf_counter() - _t0) * 1000)

                    # Send empty last frame to signal end (only if WS still open)
                    if not _sender_stop.is_set():
                        last_msg = {
                            "data": {
                                "status": 2,
                                "format": "audio/L16;rate=16000",
                                "encoding": "raw",
                                "audio": "",
                            }
                        }
                        await ws.send(json.dumps(last_msg))
                except websockets.exceptions.ConnectionClosed:
                    # iFlytek closed the connection (e.g. server read timeout
                    # or VAD-triggered close). This is expected when the user
                    # doesn't click stop — just exit silently.
                    pass
                finally:
                    logger.debug(
                        "{}: stream sender done, sent {} frames in {:.0f}ms",
                        self.name, _frames_sent, (time.perf_counter() - _t0) * 1000,
                    )

            async def receiver() -> None:
                # Segment array for wpgs dynamic correction.
                # Index = sn (sentence number from iFlytek).
                # Each element is the text for that segment.
                segments: list[str] = []
                _resp_count = 0

                try:
                    async for message in ws:
                        resp = json.loads(message)
                        code = resp.get("code", -1)
                        if code != 0:
                            raise RuntimeError(
                                f"iFlytek STT error [{code}]: {resp.get('message', 'unknown')}"
                            )

                        _resp_count += 1
                        data = resp.get("data", {})
                        resp_status = data.get("status", 0)
                        result = data.get("result", {})
                        ws_items = result.get("ws", [])
                        pgs = result.get("pgs", "")  # "apd" or "rpl"
                        rg = result.get("rg", [])    # [start, end] for rpl
                        sn = result.get("sn", 0)     # segment number

                        seg_text = self._extract_segment_text(ws_items)

                        if _resp_count == 1:
                            logger.debug("{}: first response at {:.0f}ms  sn={}  pgs={}",
                                         self.name, (time.perf_counter() - _t0) * 1000,
                                         sn, pgs or "none")

                        if pgs == "rpl" and len(rg) == 2:
                            # Replace: clear segments rg[0]..rg[1], put new
                            # text at rg[0], remove the rest in range.
                            start, end = rg[0], rg[1]
                            # Ensure segments list is large enough
                            while len(segments) <= end:
                                segments.append("")
                            # Clear the replaced range
                            for i in range(start, end + 1):
                                segments[i] = ""
                            # Put new text at start position
                            segments[start] = seg_text
                        elif pgs == "apd":
                            # Append: add/overwrite segment at index sn
                            while len(segments) <= sn:
                                segments.append("")
                            segments[sn] = seg_text
                        else:
                            # No pgs (legacy / non-wpgs fallback): append
                            while len(segments) <= sn:
                                segments.append("")
                            segments[sn] = seg_text

                        # Build current full text from all segments
                        current_text = "".join(segments).strip()

                        if resp_status == 2:
                            # Final result — stop sender
                            _sender_stop.set()
                            logger.info("{}: final result at {:.0f}ms  responses={}  text='{}'",
                                        self.name, (time.perf_counter() - _t0) * 1000,
                                        _resp_count, current_text[:60])
                            if current_text:
                                await results.put(
                                    Transcription(text=current_text, is_partial=False)
                                )
                            break
                        else:
                            # Partial result — yield for real-time display
                            if current_text:
                                await results.put(
                                    Transcription(text=current_text, is_partial=True)
                                )

                except websockets.exceptions.ConnectionClosed:
                    # Connection closed by server — stop sender, emit whatever we have
                    _sender_stop.set()
                    current_text = "".join(segments).strip()
                    if current_text:
                        await results.put(
                            Transcription(text=current_text, is_partial=False)
                        )
                finally:
                    _sender_stop.set()  # ensure sender stops in all cases
                    await results.put(None)  # sentinel

            send_task = asyncio.create_task(sender())
            recv_task = asyncio.create_task(receiver())

            while True:
                item = await results.get()
                if item is None:
                    break
                yield item

            logger.info(
                "{}: stream completed in {:.0f}ms, frames={}",
                self.name, (time.perf_counter() - _t0) * 1000, _frames_sent,
            )
            # Wait for tasks; suppress sender errors (e.g. ConnectionClosed
            # that slipped past the try/except if timing was tight).
            for task in (send_task, recv_task):
                try:
                    await task
                except websockets.exceptions.ConnectionClosed:
                    pass
