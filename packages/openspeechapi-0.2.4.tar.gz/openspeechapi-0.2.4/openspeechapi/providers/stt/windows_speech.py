"""Windows native STT provider using System.Speech.Recognition via PowerShell.

Uses PowerShell to invoke the .NET System.Speech.Recognition.SpeechRecognitionEngine,
which is available on all Windows 10+ systems without extra dependencies.
Results are exchanged through a temporary JSON file.
"""
from __future__ import annotations

import asyncio
import json
from openspeechapi.logging_config import logger
import shutil
import sys
import tempfile
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openspeechapi.core.base import STTProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings
from openspeechapi.utils.audio_converter import AudioConverter

# PowerShell script that performs speech recognition and outputs JSON.
_PS_RECOGNIZE_SCRIPT = r"""
param(
    [Parameter(Mandatory=$true)][string]$AudioPath,
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [string]$Language = "zh-CN"
)

try {
    Add-Type -AssemblyName System.Speech

    $culture = New-Object System.Globalization.CultureInfo($Language)
    $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine($culture)
    $grammar = New-Object System.Speech.Recognition.DictationGrammar
    $engine.LoadGrammar($grammar)
    $engine.SetInputToWaveFile($AudioPath)

    $result = $engine.Recognize()
    $engine.Dispose()

    if ($result -ne $null) {
        $output = @{
            status = "ok"
            text = $result.Text
            confidence = [math]::Round($result.Confidence, 4)
            language = $Language
        }
    } else {
        $output = @{
            status = "ok"
            text = ""
            confidence = 0
            language = $Language
        }
    }
} catch {
    $output = @{
        status = "error"
        error = $_.Exception.Message
    }
}

$output | ConvertTo-Json -Compress | Out-File -FilePath $OutputPath -Encoding UTF8
"""

@dataclass
class WindowsSpeechSettings(BaseSettings):
    language: str = "zh-CN"

class WindowsSpeechSTT(STTProvider):
    """Windows native STT via System.Speech.Recognition (PowerShell)."""

    name = "windows-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = WindowsSpeechSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"language": ["zh-CN", "en-US", "ja-JP", "ko-KR", "fr-FR", "de-DE", "es-ES"]}

    def __init__(self, settings: WindowsSpeechSettings | None = None) -> None:
        self.settings = settings or WindowsSpeechSettings()
        self._available: bool = False
        self._powershell: str | None = None

    # -- lifecycle ------------------------------------------------------------

    @staticmethod
    def _find_powershell() -> str | None:
        """Locate PowerShell executable — try PATH first, then well-known paths."""
        ps = shutil.which("powershell") or shutil.which("pwsh")
        if ps:
            return ps
        # Fallback: well-known Windows paths
        for candidate in (
            Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"),
            Path(r"C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"),
        ):
            if candidate.exists():
                return str(candidate)
        return None

    async def start(self) -> None:
        if sys.platform != "win32":
            raise RuntimeError(
                "Windows STT (System.Speech) is only available on Windows"
            )
        # Locate PowerShell
        ps = self._find_powershell()
        if ps is None:
            raise RuntimeError("PowerShell not found on this system")
        self._powershell = ps
        logger.debug("Using PowerShell: {}", ps)

        # Verify System.Speech is available
        ok = await self._check_system_speech()
        if not ok:
            raise RuntimeError(
                "System.Speech assembly not available. "
                "Ensure Windows Speech Recognition is installed."
            )
        self._available = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._available = False
        self._powershell = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        if self._available:
            return True
        if sys.platform != "win32":
            return False
        return self._find_powershell() is not None

    # -- transcription --------------------------------------------------------

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if not self._available or self._powershell is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        opts = opts or STTOptions()
        language = opts.language or self.settings.language

        # Convert to WAV (16-bit PCM) for System.Speech
        wav_audio = AudioConverter.to_wav(audio)

        tmp_wav: str | None = None
        tmp_out: str | None = None
        tmp_ps: str | None = None
        try:
            # Write WAV to temp file
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(wav_audio.data)
                tmp_wav = f.name

            # Output file for JSON result
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
                tmp_out = f.name

            # Write PowerShell script to temp file
            with tempfile.NamedTemporaryFile(
                suffix=".ps1", delete=False, mode="w", encoding="utf-8"
            ) as f:
                f.write(_PS_RECOGNIZE_SCRIPT)
                tmp_ps = f.name

            # Run PowerShell
            cmd = [
                self._powershell,
                "-ExecutionPolicy", "Bypass",
                "-NoProfile",
                "-File", tmp_ps,
                "-AudioPath", tmp_wav,
                "-OutputPath", tmp_out,
                "-Language", language,
            ]
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()

            # Read JSON result
            out_path = Path(tmp_out)
            if not out_path.exists() or out_path.stat().st_size == 0:
                err_msg = stderr.decode(errors="replace").strip() if stderr else "no output"
                raise RuntimeError(f"Windows STT failed: {err_msg}")

            raw = out_path.read_text(encoding="utf-8-sig").strip()
            result = json.loads(raw)

            if result.get("status") == "error":
                raise RuntimeError(
                    f"Windows STT error: {result.get('error', 'unknown')}"
                )

            transcription = Transcription(
                text=result.get("text", ""),
                language=result.get("language"),
                confidence=result.get("confidence"),
            )
            logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(transcription.text))
            return transcription
        finally:
            for p in (tmp_wav, tmp_out, tmp_ps):
                if p is not None:
                    try:
                        Path(p).unlink(missing_ok=True)
                    except OSError:
                        pass

    def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError(
            "Windows System.Speech does not support streaming via this provider"
        )

    # -- internal helpers -----------------------------------------------------

    async def _check_system_speech(self) -> bool:
        """Verify that System.Speech assembly is loadable."""
        check_script = (
            'try { Add-Type -AssemblyName System.Speech; '
            'Write-Output "ok" } '
            'catch { Write-Output "fail" }'
        )
        proc = await asyncio.create_subprocess_exec(
            self._powershell,
            "-ExecutionPolicy", "Bypass",
            "-NoProfile",
            "-Command", check_script,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return stdout.decode(errors="replace").strip() == "ok"
