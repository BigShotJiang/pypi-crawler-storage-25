"""Volcengine (ByteDance) STT provider adapter."""
from __future__ import annotations

import base64
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class VolcengineSTTSettings(BaseSettings):
    access_token: str = ""
    app_id: str = ""
    cluster: str = "volcengine_streaming_common"

class VolcengineSTT(STTProvider):
    name = "volcengine-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = VolcengineSTTSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"cluster": ["volcengine_streaming_common", "volcengine_input_common"]}

    def __init__(self, settings: VolcengineSTTSettings | None = None) -> None:
        self.settings = settings or VolcengineSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.access_token) and bool(self.settings.app_id)

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        base64_audio = base64.b64encode(audio.data).decode("utf-8")
        payload = {
            "app": {
                "appid": self.settings.app_id,
                "cluster": self.settings.cluster,
            },
            "audio": {
                "format": "wav",
                "data": base64_audio,
            },
            "user": {"uid": "openspeechapi"},
        }
        headers = {
            "Authorization": f"Bearer;{self.settings.access_token}",
            "Content-Type": "application/json",
        }

        resp = await self._client.post(
            "https://openspeechapi.bytedance.com/api/v1/auc/submit",
            json=payload,
            headers=headers,
        )
        resp.raise_for_status()
        data = resp.json()

        if data.get("code") != 0 and data.get("code") is not None:
            raise RuntimeError(
                f"Volcengine STT error: {data.get('message', 'unknown error')}"
            )

        text = data.get("result", "")
        if isinstance(text, dict):
            text = text.get("text", "")

        result = Transcription(text=text)
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
        return result

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes]
    ) -> AsyncIterator[Any]:
        raise NotImplementedError("Volcengine STT streaming not implemented")
        yield  # noqa: unreachable — makes this an async generator
