"""macOS native TTS provider using the ``say`` command."""
from __future__ import annotations

import asyncio
import io
from openspeechapi.logging_config import logger
import shutil
import struct
import tempfile
import time
import wave
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings
from openspeechapi.utils.audio_converter import AudioConverter

# Language prefix → human-readable group name
_LANG_GROUP_MAP: dict[str, str] = {
    "zh": "中文",
    "en": "English",
    "ja": "日本語",
    "ko": "한국어",
    "fr": "Français",
    "de": "Deutsch",
    "es": "Español",
    "it": "Italiano",
    "pt": "Português",
    "ru": "Русский",
    "ar": "العربية",
    "nl": "Nederlands",
    "sv": "Svenska",
    "da": "Dansk",
    "fi": "Suomi",
    "nb": "Norsk",
    "pl": "Polski",
    "tr": "Türkçe",
    "th": "ไทย",
    "hi": "हिन्दी",
    "he": "עברית",
    "ro": "Română",
    "hu": "Magyar",
    "cs": "Čeština",
    "el": "Ελληνικά",
    "id": "Bahasa Indonesia",
    "vi": "Tiếng Việt",
}

@dataclass
class MacOSSaySettings(BaseSettings):
    default_voice: str = "Samantha"
    default_rate: int = 200

class MacOSSayTTS(TTSProvider):
    """macOS native TTS via the ``say`` command-line tool."""

    name = "macos-say"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = MacOSSaySettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}

    def __init__(self, settings: MacOSSaySettings | None = None) -> None:
        self.settings = settings or MacOSSaySettings()
        self._available: bool = False
        self._voices_cache: list[dict] | None = None

    # -- lifecycle ------------------------------------------------------------

    async def start(self) -> None:
        if shutil.which("say") is None:
            raise RuntimeError(
                "macOS 'say' command not found — this provider requires macOS"
            )
        self._available = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._available = False
        self._voices_cache = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        if self._available:
            return True
        # Pre-start check: verify say command exists on macOS
        return shutil.which("say") is not None

    # -- synthesis ------------------------------------------------------------

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if not self._available:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()

        opts = opts or TTSOptions()
        voice = opts.voice or self.settings.default_voice
        rate = int(self.settings.default_rate * opts.speed)

        tmp_path: str | None = None
        try:
            # Create a temp file for the AIFF output
            fd, tmp_path = tempfile.mkstemp(suffix=".aiff")
            import os
            os.close(fd)

            await self._run_say(voice, rate, tmp_path, text)

            aiff_data = Path(tmp_path).read_bytes()

            # Convert AIFF → WAV via AudioConverter
            aiff_audio = AudioData(
                data=aiff_data,
                sample_rate=22050,  # placeholder; to_wav parses AIFF header
                channels=1,
                format=AudioFormat.AIFF,
            )
            wav_audio = AudioConverter.to_wav(aiff_audio)

            # Parse WAV to compute duration
            with wave.open(io.BytesIO(wav_audio.data), "rb") as wf:
                n_frames = wf.getnframes()
                frame_rate = wf.getframerate()
                duration_ms = int(n_frames / frame_rate * 1000) if frame_rate else 0

            result = AudioData(
                data=wav_audio.data,
                sample_rate=wav_audio.sample_rate,
                channels=wav_audio.channels,
                format=AudioFormat.WAV,
                duration_ms=duration_ms,
            )
            logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
            return result
        finally:
            if tmp_path is not None:
                try:
                    Path(tmp_path).unlink(missing_ok=True)
                except OSError:
                    pass

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        """Batch-then-chunk fallback: synthesize full audio, then yield chunks."""
        logger.info("{}: stream request, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        result = await self.synthesize(text, opts)
        chunk_size = 4096
        sequence = 0
        chunk_count = 0
        for i in range(0, len(result.data), chunk_size):
            chunk_data = result.data[i : i + chunk_size]
            logger.debug("{}: chunk #{}, {} bytes", self.name, sequence, len(chunk_data))
            yield AudioChunk(data=chunk_data, sequence=sequence)
            sequence += 1
            chunk_count += 1
        yield AudioChunk(data=b"", sequence=sequence, is_final=True)
        logger.info("{}: stream complete, {} chunks in {:.0f}ms", self.name, chunk_count, (time.perf_counter() - _t0) * 1000)

    # -- voices ---------------------------------------------------------------

    async def list_voices(self) -> list[dict]:
        if self._voices_cache is not None:
            return self._voices_cache

        output = await self._run_command(["say", "-v", "?"])
        self._voices_cache = self._parse_voices_output(output)
        return self._voices_cache

    # -- internal helpers -----------------------------------------------------

    async def _run_say(
        self, voice: str, rate: int, output_path: str, text: str
    ) -> None:
        """Execute ``say`` to produce an AIFF file."""
        cmd = ["say", "-v", voice, "-r", str(rate), "-o", output_path, "--", text]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(
                f"say command failed (exit {proc.returncode}): "
                f"{stderr.decode(errors='replace')}"
            )

    async def _run_command(self, cmd: list[str]) -> str:
        """Run an arbitrary command and return its stdout."""
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return stdout.decode(errors="replace")

    @staticmethod
    def _parse_voices_output(output: str) -> list[dict]:
        """Parse the output of ``say -v ?`` into a list of voice dicts.

        Expected line format::

            Samantha            en_US    # Hello, my name is Samantha.
        """
        voices: list[dict] = []
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue

            # Split on '#' to separate the description
            description = ""
            if "#" in line:
                main_part, description = line.split("#", 1)
                description = description.strip()
            else:
                main_part = line

            # The name and language are separated by whitespace.
            # Name can contain spaces, but language is always the last
            # whitespace-separated token before the '#'.
            parts = main_part.rsplit(None, 1)
            if len(parts) < 2:
                continue

            name = parts[0].strip()
            language = parts[1].strip()

            # Derive group from language prefix
            lang_prefix = language.split("_")[0].lower()
            group = _LANG_GROUP_MAP.get(lang_prefix, lang_prefix.upper())

            voices.append({
                "name": name,
                "language": language,
                "description": description,
                "group": group,
            })

        return voices
