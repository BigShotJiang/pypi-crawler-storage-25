"""Alibaba Cloud (Bailian/DashScope) TTS provider adapter — OpenAI-compatible."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class AlibabaTTSSettings(BaseSettings):
    api_key: str = ""
    model: str = "cosyvoice-v1"
    voice: str = "longxiaochun"
    base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"

class AlibabaTTS(TTSProvider):
    name = "alibaba-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = AlibabaTTSSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"model": ["cosyvoice-v1", "sambert-v1"], "voice": ["longxiaochun", "longhua", "longxiaoxia", "longlaotie", "longshu"]}

    def __init__(self, settings: AlibabaTTSSettings | None = None) -> None:
        self.settings = settings or AlibabaTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()

        voice = opts.voice or self.settings.voice
        url = f"{self.settings.base_url}/audio/speech"

        headers = {
            "Authorization": f"Bearer {self.settings.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.settings.model,
            "input": text,
            "voice": voice,
        }

        resp = await self._client.post(url, json=payload, headers=headers)
        resp.raise_for_status()

        result = AudioData(
            data=resp.content,
            sample_rate=24000,
            channels=1,
            format=opts.output_format,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError("Alibaba TTS streaming not implemented")
        yield  # noqa: unreachable — makes this an async generator
