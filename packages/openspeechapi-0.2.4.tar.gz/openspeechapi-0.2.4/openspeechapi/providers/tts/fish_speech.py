"""Fish-Speech TTS provider adapter (HTTP API, in-process)."""
from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
import io
from openspeechapi.logging_config import logger
import time
from typing import Any
from urllib.parse import urljoin
import wave

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class FishSpeechTTSSettings(BaseSettings):
    api_url: str = "http://localhost:8080"
    reference_audio: str | None = None
    reference_id: str | None = None
    timeout_s: float = 60.0
    retries: int = 0
    health_path: str = "/health"
    format: str = "wav"
    latency: str = "balanced"
    chunk_length: int = 200
    max_new_tokens: int = 1024
    top_p: float = 0.8
    repetition_penalty: float = 1.1
    temperature: float = 0.8
    use_memory_cache: str = "on"
    normalize: bool = True

class FishSpeechTTS(TTSProvider):
    name = "fish-speech"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = FishSpeechTTSSettings
    capabilities = {Capability.STREAMING, Capability.VOICE_CLONE}
    field_options = {
        "format": ["wav", "mp3", "flac", "opus"],
        "latency": ["normal", "balanced"],
    }

    def __init__(self, settings: FishSpeechTTSSettings | None = None) -> None:
        self.settings = settings or FishSpeechTTSSettings()
        self._client: Any = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            try:
                import httpx
            except ImportError:
                raise ImportError(
                    "Install httpx: pip install openspeechapi[fish-speech]"
                )
            # Ignore process-level proxy env vars by default to avoid accidental SOCKS deps.
            self._client = httpx.AsyncClient(timeout=self.settings.timeout_s, trust_env=False)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        if self._client is None:
            return False
        try:
            url = urljoin(self.settings.api_url.rstrip("/") + "/", self.settings.health_path.lstrip("/"))
            resp = await self._client.get(url)
            return resp.status_code < 500
        except Exception:
            return False

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        payload: dict[str, Any] = {
            "text": text,
            "format": self.settings.format,
            "latency": self.settings.latency,
            "chunk_length": self.settings.chunk_length,
            "max_new_tokens": self.settings.max_new_tokens,
            "top_p": self.settings.top_p,
            "repetition_penalty": self.settings.repetition_penalty,
            "temperature": self.settings.temperature,
            "use_memory_cache": self.settings.use_memory_cache,
            "normalize": self.settings.normalize,
        }
        if opts.voice:
            payload["voice"] = opts.voice
        if opts.speed and opts.speed != 1.0:
            payload["speed"] = opts.speed
        if self.settings.reference_audio:
            payload["reference_audio"] = self.settings.reference_audio
        if self.settings.reference_id:
            payload["reference_id"] = self.settings.reference_id
        last_exc: Exception | None = None
        response = None
        attempts = max(0, self.settings.retries) + 1
        for _ in range(attempts):
            try:
                response = await self._client.post(
                    f"{self.settings.api_url}/v1/tts",
                    json=payload,
                )
                break
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
        if response is None:
            raise RuntimeError(f"Fish-Speech request failed: {last_exc}") from last_exc
        response.raise_for_status()
        duration_ms = self._wav_duration_ms(response.content)
        result = AudioData(
            data=response.content,
            sample_rate=44100,
            channels=1,
            format=AudioFormat.WAV,
            duration_ms=duration_ms,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError(
            "FishSpeechTTS.synthesize_stream() is not yet implemented"
        )
        yield  # pragma: no cover

    @staticmethod
    def _wav_duration_ms(data: bytes) -> int | None:
        try:
            with wave.open(io.BytesIO(data), "rb") as wf:
                sample_rate = wf.getframerate()
                if sample_rate <= 0:
                    return None
                frames = wf.getnframes()
                return int((frames / sample_rate) * 1000)
        except Exception:
            return None
