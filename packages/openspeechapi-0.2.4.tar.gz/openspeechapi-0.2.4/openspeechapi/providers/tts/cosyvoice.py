"""CosyVoice TTS provider adapter (voice clone + multilingual, subprocess mode)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class CosyVoiceTTSSettings(BaseSettings):
    model_dir: str = ""
    device: str = "auto"
    fp16: bool = False
    spk_id: str | None = None

class CosyVoiceTTS(TTSProvider):
    name = "cosyvoice"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.SUBPROCESS
    settings_cls = CosyVoiceTTSSettings
    capabilities = {Capability.VOICE_CLONE, Capability.MULTILINGUAL}
    field_options = {
        "device": ["auto", "cpu", "cuda", "mps"],
    }

    def __init__(self, settings: CosyVoiceTTSSettings | None = None) -> None:
        self.settings = settings or CosyVoiceTTSSettings()
        self._client: Any = None
        self._model: Any = None

    async def start(self) -> None:
        try:
            from cosyvoice.cli.cosyvoice import CosyVoice as CosyVoiceModel
        except ImportError:
            raise ImportError(
                "Install cosyvoice: pip install openspeechapi[cosyvoice]"
            )
        self._model = CosyVoiceModel(self.settings.model_dir)
        self._client = self._model
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._client = None
        self._model = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return self._client is not None

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        import io

        import torchaudio

        spk_id = self.settings.spk_id or "中文女"
        output = list(self._model.inference_sft(text, spk_id))
        if not output:
            raise RuntimeError("CosyVoice produced no output")
        speech = output[0]["tts_speech"]
        buf = io.BytesIO()
        torchaudio.save(buf, speech, 22050, format="wav")
        result = AudioData(
            data=buf.getvalue(),
            sample_rate=22050,
            channels=1,
            format=AudioFormat.WAV,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError(
            "CosyVoiceTTS.synthesize_stream() is not yet implemented"
        )
        yield  # pragma: no cover
