"""Baidu Cloud TTS provider adapter."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class BaiduTTSSettings(BaseSettings):
    api_key: str = ""
    secret_key: str = ""
    per: int = 0    # 0=female, 1=male, 3=度逍遥, 4=度丫丫
    spd: int = 5    # speed 0-15
    pit: int = 5    # pitch 0-15
    vol: int = 5    # volume 0-15

class BaiduTTS(TTSProvider):
    name = "baidu-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = BaiduTTSSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"per": [0, 1, 3, 4, 5, 103, 106, 110, 111]}

    def __init__(self, settings: BaiduTTSSettings | None = None) -> None:
        self.settings = settings or BaiduTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True
        self._token: str | None = None
        self._token_expires_at: float = 0.0

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        self._token = None
        self._token_expires_at = 0.0
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key) and bool(self.settings.secret_key)

    async def _get_token(self) -> str:
        """Fetch or return cached OAuth access token."""
        if self._token and time.time() < self._token_expires_at:
            return self._token

        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")

        resp = await self._client.get(
            "https://aip.baidubce.com/oauth/2.0/token",
            params={
                "grant_type": "client_credentials",
                "client_id": self.settings.api_key,
                "client_secret": self.settings.secret_key,
            },
        )
        resp.raise_for_status()
        data = resp.json()

        if "access_token" not in data:
            raise RuntimeError(
                f"Baidu OAuth error: {data.get('error_description', 'unknown')}"
            )

        self._token = data["access_token"]
        self._token_expires_at = time.time() + data.get("expires_in", 2592000) - 60
        return self._token  # type: ignore[return-value]

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()

        token = await self._get_token()

        form_data = {
            "tex": text,
            "tok": token,
            "cuid": "openspeechapi",
            "ctp": "1",
            "lan": "zh",
            "spd": str(self.settings.spd),
            "pit": str(self.settings.pit),
            "vol": str(self.settings.vol),
            "per": str(self.settings.per),
            "aue": "6",  # 6 = WAV format
        }

        resp = await self._client.post(
            "https://tsn.baidu.com/text2audio",
            data=form_data,
        )
        resp.raise_for_status()

        content_type = resp.headers.get("content-type", "")
        if "audio" in content_type:
            result = AudioData(
                data=resp.content,
                sample_rate=16000,
                channels=1,
                format=opts.output_format,
            )
            logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
            return result

        # JSON response means error
        error_data = resp.json()
        raise RuntimeError(
            f"Baidu TTS error [{error_data.get('err_no')}]: "
            f"{error_data.get('err_msg', 'unknown')}"
        )

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError("Baidu TTS streaming not implemented")
        yield  # noqa: unreachable — makes this an async generator
