"""ElevenLabs TTS provider adapter (streaming + voice clone + emotion, in-process)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import base64
import json
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode

import httpx

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class ElevenLabsTTSSettings(BaseSettings):
    api_key: str = ""
    voice_id: str = "21m00Tcm4TlvDq8ikWAM"  # Rachel
    model_id: str = "eleven_multilingual_v2"
    output_format: str = "mp3_44100_128"
    optimize_streaming_latency: int | None = None
    seed: int | None = None
    language_code: str = ""
    apply_text_normalization: str = "auto"
    apply_language_text_normalization: bool = False
    stability: float = 0.5
    similarity_boost: float = 0.75
    style: float = 0.0
    use_speaker_boost: bool = True
    stream_transport: str = "http"  # http | ws
    ws_chunk_length_schedule: list[int] | None = None

class ElevenLabsTTS(TTSProvider):
    name = "elevenlabs"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = ElevenLabsTTSSettings
    capabilities = {
        Capability.STREAMING,
        Capability.VOICE_CLONE,
        Capability.EMOTION,
    }
    field_options = {
        # Synced with ElevenLabs models overview and TTS API docs (Apr 2026):
        # https://elevenlabs.io/docs/overview/models
        # https://elevenlabs.io/docs/api-reference/text-to-speech
        "model_id": [
            "eleven_v3",
            "eleven_flash_v2_5",
            "eleven_flash_v2",
            "eleven_multilingual_v2",
            # Deprecated but still accepted by API in compatibility mode.
            "eleven_multilingual_v1",
            "eleven_turbo_v2_5",
            "eleven_turbo_v2",
            "eleven_monolingual_v1",
        ],
        "output_format": [
            "mp3_22050_32", "mp3_44100_32", "mp3_44100_64", "mp3_44100_96",
            "mp3_44100_128", "mp3_44100_192",
            "opus_48000_32", "opus_48000_64", "opus_48000_96", "opus_48000_128", "opus_48000_192",
            "pcm_16000", "pcm_22050", "pcm_24000", "pcm_32000", "pcm_44100", "pcm_48000", "pcm_8000",
            "wav_16000", "wav_22050", "wav_24000", "wav_32000", "wav_44100", "wav_48000", "wav_8000",
            "ulaw_8000", "alaw_8000",
        ],
        "optimize_streaming_latency": [0, 1, 2, 3, 4],
        "stream_transport": ["http", "ws"],
        "apply_text_normalization": ["auto", "on", "off"],
        # Common language_code options (ISO-639-1) for TTS endpoint.
        "language_code": [
            "",
            "en", "zh", "ja", "ko", "es", "fr", "de", "pt", "it", "hi",
            "id", "nl", "tr", "pl", "sv", "ar", "ru", "uk", "vi", "hu",
            "no", "da", "fi", "cs", "el", "ro", "bg", "hr", "sk", "ms",
            "ta", "fil",
        ],
    }

    def __init__(self, settings: ElevenLabsTTSSettings | None = None) -> None:
        self.settings = settings or ElevenLabsTTSSettings()
        self._client: Any = None
        self._http_client: httpx.AsyncClient | None = None

    async def start(self) -> None:
        try:
            from elevenlabs.client import AsyncElevenLabs
        except ImportError:
            raise ImportError(
                "Install elevenlabs: pip install openspeechapi[elevenlabs-tts]"
            )
        self._http_client = httpx.AsyncClient(timeout=240.0, trust_env=False)
        self._client = AsyncElevenLabs(
            api_key=self.settings.api_key,
            httpx_client=self._http_client,
        )
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._client = None
        if self._http_client is not None:
            await self._http_client.aclose()
        self._http_client = None
        logger.info("{} provider stopped", self.name)

    async def list_voices(self) -> list[dict]:
        if self._client is None:
            return []
        try:
            resp = await self._client.voices.get_all(show_legacy=False)
        except Exception as exc:
            logger.warning("{}: failed to fetch voices: {}", self.name, exc)
            return []

        voices: list[dict] = []
        for v in getattr(resp, "voices", []) or []:
            voice_id = str(getattr(v, "voice_id", "") or "").strip()
            if not voice_id:
                continue
            display_name = str(getattr(v, "name", "") or voice_id).strip()
            category = str(getattr(v, "category", "") or "").strip()
            labels = getattr(v, "labels", None) or {}
            language = ""
            if isinstance(labels, dict):
                language = str(labels.get("language") or labels.get("accent") or "").strip()
            item: dict[str, str] = {"id": voice_id, "name": display_name}
            if category:
                item["group"] = category.title()
            if language:
                item["language"] = language
            voices.append(item)
        voices.sort(key=lambda x: (x.get("group", ""), x.get("name", "").lower()))
        return voices

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        voice_id = opts.voice or self.settings.voice_id
        model_id = opts.model or self.settings.model_id
        request_kwargs = {
            "voice_id": voice_id,
            "text": text,
            "model_id": model_id,
            "output_format": self.settings.output_format,
            "optimize_streaming_latency": self.settings.optimize_streaming_latency,
            "seed": self.settings.seed,
            "language_code": (self.settings.language_code or None),
            "apply_text_normalization": self.settings.apply_text_normalization,
            "apply_language_text_normalization": self.settings.apply_language_text_normalization,
            "voice_settings": {
                "stability": self.settings.stability,
                "similarity_boost": self.settings.similarity_boost,
                "style": self.settings.style,
                "use_speaker_boost": self.settings.use_speaker_boost,
            },
        }
        response = self._client.text_to_speech.convert(
            **request_kwargs,
        )
        # Use bytearray to avoid quadratic copy cost on long streamed outputs.
        audio_buf = bytearray()
        async for chunk in response:
            audio_buf.extend(chunk)
        result = AudioData(
            data=bytes(audio_buf),
            sample_rate=44100,
            channels=1,
            format=AudioFormat.MP3,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: stream request, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        voice_id = opts.voice or self.settings.voice_id
        model_id = opts.model or self.settings.model_id
        stream_transport = (opts.stream_transport or self.settings.stream_transport or "http").strip().lower()
        request_kwargs = {
            "voice_id": voice_id,
            "text": text,
            "model_id": model_id,
            "output_format": self.settings.output_format,
            "optimize_streaming_latency": self.settings.optimize_streaming_latency,
            "seed": self.settings.seed,
            "language_code": (self.settings.language_code or None),
            "apply_text_normalization": self.settings.apply_text_normalization,
            "apply_language_text_normalization": self.settings.apply_language_text_normalization,
            "voice_settings": {
                "stability": self.settings.stability,
                "similarity_boost": self.settings.similarity_boost,
                "style": self.settings.style,
                "use_speaker_boost": self.settings.use_speaker_boost,
            },
        }
        # ElevenLabs docs: text-to-speech WS isn't available for eleven_v3.
        if stream_transport == "ws" and str(model_id) == "eleven_v3":
            logger.warning("{}: model {} does not support WS input streaming, fallback to HTTP streaming", self.name, model_id)
            stream_transport = "http"

        if stream_transport == "ws":
            async for chunk in self._synthesize_stream_ws(text=text, request_kwargs=request_kwargs):
                yield chunk
            return

        response = self._client.text_to_speech.convert(**request_kwargs)
        sequence = 0
        chunk_count = 0
        async for chunk in response:
            logger.debug("{}: chunk #{}, {} bytes", self.name, sequence, len(chunk))
            yield AudioChunk(data=chunk, sequence=sequence)
            sequence += 1
            chunk_count += 1
        yield AudioChunk(data=b"", sequence=sequence, is_final=True)
        logger.info("{}: stream complete, {} chunks in {:.0f}ms", self.name, chunk_count, (time.perf_counter() - _t0) * 1000)

    async def _synthesize_stream_ws(
        self, *, text: str, request_kwargs: dict[str, Any]
    ) -> AsyncIterator[AudioChunk]:
        """Low-latency input-streaming over ElevenLabs WebSocket API."""
        import websockets

        voice_id = request_kwargs["voice_id"]
        params = {
            "model_id": request_kwargs.get("model_id"),
            "output_format": request_kwargs.get("output_format"),
        }
        if request_kwargs.get("optimize_streaming_latency") is not None:
            params["optimize_streaming_latency"] = request_kwargs["optimize_streaming_latency"]
        if request_kwargs.get("language_code"):
            params["language_code"] = request_kwargs.get("language_code")
        qs = urlencode({k: v for k, v in params.items() if v not in (None, "")})
        url = f"wss://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream-input?{qs}"

        generation_config: dict[str, Any] = {}
        if self.settings.ws_chunk_length_schedule:
            generation_config["chunk_length_schedule"] = self.settings.ws_chunk_length_schedule

        init_msg: dict[str, Any] = {
            "text": " ",
            "xi_api_key": self.settings.api_key,
            "voice_settings": request_kwargs.get("voice_settings") or {},
        }
        if generation_config:
            init_msg["generation_config"] = generation_config

        sequence = 0
        had_audio = False
        async with websockets.connect(url) as ws:
            await ws.send(json.dumps(init_msg))
            await ws.send(json.dumps({"text": text}))
            # Force pending audio generation, then explicitly terminate input
            # with EOS. Official protocol treats {"text": ""} as EOS.
            await ws.send(json.dumps({"text": "", "flush": True}))
            await ws.send(json.dumps({"text": ""}))

            async for raw in ws:
                try:
                    data = json.loads(raw)
                except Exception:
                    continue

                if "error" in data:
                    raw_err = data.get("error")
                    if isinstance(raw_err, dict):
                        err_msg = str(raw_err.get("code") or raw_err.get("message") or raw_err)
                    else:
                        err_msg = str(raw_err or "")
                    # Some sessions return input timeout after all usable audio
                    # has already been emitted; treat it as graceful close.
                    if "input_timeout_exceeded" in err_msg and had_audio:
                        logger.warning(
                            "{}: ws ended with input timeout after audio output; treating as complete",
                            self.name,
                        )
                        break
                    raise RuntimeError(f"ElevenLabs TTS WS error: {raw_err}")

                audio_b64 = data.get("audio") or data.get("audio_base64") or ""
                if audio_b64:
                    try:
                        chunk = base64.b64decode(audio_b64)
                    except Exception:
                        chunk = b""
                    if chunk:
                        had_audio = True
                        yield AudioChunk(data=chunk, sequence=sequence)
                        sequence += 1

                if data.get("isFinal") is True:
                    break

        yield AudioChunk(data=b"", sequence=sequence, is_final=True)
