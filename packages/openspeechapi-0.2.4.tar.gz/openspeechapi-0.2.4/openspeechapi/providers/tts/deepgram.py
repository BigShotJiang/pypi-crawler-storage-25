"""Deepgram TTS provider adapter (Aura API, httpx-based, no SDK needed)."""
from __future__ import annotations

import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx
from openspeechapi.logging_config import logger

from openspeechapi.core.base import TTSProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings


@dataclass
class DeepgramTTSSettings(BaseSettings):
    api_key: str = ""
    model: str = "aura-asteria-en"


class DeepgramTTS(TTSProvider):
    name = "deepgram-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = DeepgramTTSSettings
    capabilities = {Capability.STREAMING, Capability.MULTILINGUAL}
    field_options = {
        "model": [
            # Aura-2 English
            "aura-2-asteria-en", "aura-2-athena-en", "aura-2-luna-en",
            "aura-2-hera-en", "aura-2-orion-en", "aura-2-orpheus-en",
            "aura-2-arcas-en", "aura-2-zeus-en", "aura-2-apollo-en",
            "aura-2-helena-en", "aura-2-andromeda-en", "aura-2-thalia-en",
            "aura-2-aurora-en", "aura-2-iris-en", "aura-2-electra-en",
            # Aura-2 Chinese / Japanese / Korean
            "aura-2-uzume-ja", "aura-2-ebisu-ja", "aura-2-fujin-ja",
            # Aura-2 European
            "aura-2-agathe-fr", "aura-2-hector-fr",
            "aura-2-elara-de", "aura-2-aurelia-de", "aura-2-julius-de",
            "aura-2-sirio-es", "aura-2-carina-es", "aura-2-diana-es",
            "aura-2-melia-it", "aura-2-elio-it",
            "aura-2-beatrix-nl", "aura-2-daphne-nl",
            # Aura-1 English (legacy)
            "aura-asteria-en", "aura-luna-en", "aura-stella-en",
            "aura-athena-en", "aura-hera-en", "aura-orion-en",
            "aura-arcas-en", "aura-perseus-en", "aura-angus-en",
            "aura-orpheus-en", "aura-helios-en", "aura-zeus-en",
        ],
    }

    def __init__(self, settings: DeepgramTTSSettings | None = None) -> None:
        self.settings = settings or DeepgramTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()

        model = self.settings.model
        headers = {
            "Authorization": f"Token {self.settings.api_key}",
            "Content-Type": "application/json",
        }
        payload = {"text": text}

        resp = await self._client.post(
            "https://api.deepgram.com/v1/speak",
            params={"model": model, "encoding": "linear16", "sample_rate": "24000"},
            headers=headers,
            json=payload,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"Deepgram TTS API error ({resp.status_code}): {resp.text}")

        audio_bytes = resp.content
        result = AudioData(
            data=audio_bytes,
            sample_rate=24000,
            channels=1,
            format=AudioFormat.PCM_16K,
        )
        logger.info(
            "{}: completed in {:.0f}ms, output={} bytes",
            self.name,
            (time.perf_counter() - _t0) * 1000,
            len(result.data),
        )
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: stream request, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()

        model = self.settings.model
        headers = {
            "Authorization": f"Token {self.settings.api_key}",
            "Content-Type": "application/json",
        }
        payload = {"text": text}

        async with self._client.stream(
            "POST",
            "https://api.deepgram.com/v1/speak",
            params={"model": model, "encoding": "linear16", "sample_rate": "24000"},
            headers=headers,
            json=payload,
        ) as response:
            if response.status_code != 200:
                body = await response.aread()
                raise RuntimeError(f"Deepgram TTS API error ({response.status_code}): {body.decode()}")
            sequence = 0
            chunk_count = 0
            async for chunk in response.aiter_bytes(chunk_size=4096):
                logger.debug("{}: chunk #{}, {} bytes", self.name, sequence, len(chunk))
                yield AudioChunk(data=chunk, sequence=sequence)
                sequence += 1
                chunk_count += 1
            yield AudioChunk(data=b"", sequence=sequence, is_final=True)
        logger.info(
            "{}: stream complete, {} chunks in {:.0f}ms",
            self.name,
            chunk_count,
            (time.perf_counter() - _t0) * 1000,
        )

    async def list_voices(self) -> list[dict]:
        """Return available Deepgram Aura voice models."""
        voices = []
        for m in self.field_options["model"]:
            # Extract readable name: "aura-2-asteria-en" → "Asteria (en)"
            parts = m.split("-")
            if parts[0] == "aura" and parts[1] == "2":
                name = parts[2].title()
                lang = parts[3] if len(parts) > 3 else ""
                label = f"{name} ({lang})" if lang else name
            else:
                name = parts[1].title() if len(parts) > 1 else m
                lang = parts[2] if len(parts) > 2 else ""
                label = f"{name} ({lang})" if lang else name
            voices.append({"id": m, "name": label})
        return voices
