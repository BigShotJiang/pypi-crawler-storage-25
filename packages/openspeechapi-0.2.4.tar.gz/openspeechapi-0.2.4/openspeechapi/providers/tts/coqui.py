"""Coqui TTS provider adapter (voice clone + multilingual, in-process)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class CoquiTTSSettings(BaseSettings):
    model_name: str = "tts_models/en/ljspeech/tacotron2-DDC"
    vocoder_name: str | None = None
    use_cuda: bool = False
    speaker_wav: str | None = None
    language: str | None = None

class CoquiTTS(TTSProvider):
    name = "coqui"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = CoquiTTSSettings
    capabilities = {Capability.VOICE_CLONE, Capability.MULTILINGUAL}

    def __init__(self, settings: CoquiTTSSettings | None = None) -> None:
        self.settings = settings or CoquiTTSSettings()
        self._client: Any = None

    async def start(self) -> None:
        try:
            from TTS.api import TTS  # noqa: F401
            self._client = object()  # sentinel
        except ImportError:
            raise ImportError(
                "Install coqui TTS: pip install openspeechapi[coqui]"
            )
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return self._client is not None

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        raise NotImplementedError("CoquiTTS.synthesize() is not yet implemented")

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError("CoquiTTS does not support streaming synthesis")
        yield  # pragma: no cover
