"""Google Cloud TTS provider adapter (batch, httpx)."""
from __future__ import annotations

import base64
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class GoogleCloudTTSSettings(BaseSettings):
    api_key: str = ""
    language: str = "en-US"
    voice_name: str = "en-US-Standard-A"
    speaking_rate: float = 1.0

class GoogleCloudTTS(TTSProvider):
    name = "google-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.REMOTE
    settings_cls = GoogleCloudTTSSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"language": ["en-US", "zh-CN", "ja-JP", "ko-KR", "es-ES", "fr-FR", "de-DE", "pt-BR"], "voice_name": ["en-US-Standard-A", "en-US-Standard-B", "en-US-Standard-C", "en-US-Standard-D", "en-US-Wavenet-A", "en-US-Wavenet-B", "zh-CN-Standard-A", "zh-CN-Standard-B", "zh-CN-Standard-C", "zh-CN-Standard-D", "zh-CN-Wavenet-A", "ja-JP-Standard-A", "ja-JP-Standard-B"]}

    def __init__(self, settings: GoogleCloudTTSSettings | None = None) -> None:
        self.settings = settings or GoogleCloudTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        voice_name = opts.voice or self.settings.voice_name
        language = self.settings.language
        speaking_rate = opts.speed if opts.speed != 1.0 else self.settings.speaking_rate

        url = (
            "https://texttospeech.googleapis.com/v1/text:synthesize"
            f"?key={self.settings.api_key}"
        )
        body = {
            "input": {"text": text},
            "voice": {
                "languageCode": language,
                "name": voice_name,
            },
            "audioConfig": {
                "audioEncoding": "LINEAR16",
                "speakingRate": speaking_rate,
            },
        }
        response = await self._client.post(url, json=body)
        if response.status_code != 200:
            raise RuntimeError(
                f"Google Cloud TTS API error {response.status_code}: {response.text}"
            )
        data = response.json()
        audio_bytes = base64.b64decode(data["audioContent"])
        result = AudioData(
            data=audio_bytes,
            sample_rate=24000,
            channels=1,
            format=AudioFormat.WAV,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError(
            "Google Cloud TTS batch provider does not support streaming output"
        )
        yield  # pragma: no cover
