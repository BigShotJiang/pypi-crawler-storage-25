"""Volcengine (ByteDance) TTS provider adapter."""
from __future__ import annotations

import base64
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class VolcengineTTSSettings(BaseSettings):
    access_token: str = ""
    app_id: str = ""
    cluster: str = "volcano_tts"
    voice_type: str = "BV001_streaming"

class VolcengineTTS(TTSProvider):
    name = "volcengine-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = VolcengineTTSSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"voice_type": ["BV001_streaming", "BV002_streaming", "BV700_streaming", "BV406_streaming", "BV407_streaming"]}

    def __init__(self, settings: VolcengineTTSSettings | None = None) -> None:
        self.settings = settings or VolcengineTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.access_token) and bool(self.settings.app_id)

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()

        payload = {
            "app": {
                "appid": self.settings.app_id,
                "cluster": self.settings.cluster,
            },
            "user": {"uid": "openspeechapi"},
            "audio": {
                "voice_type": self.settings.voice_type,
                "encoding": "wav",
                "speed_ratio": opts.speed,
            },
            "request": {
                "text": text,
                "operation": "query",
            },
        }
        headers = {
            "Authorization": f"Bearer;{self.settings.access_token}",
            "Content-Type": "application/json",
        }

        resp = await self._client.post(
            "https://openspeechapi.bytedance.com/api/v1/tts",
            json=payload,
            headers=headers,
        )
        resp.raise_for_status()
        result = resp.json()

        if result.get("code") != 0 and result.get("code") is not None:
            raise RuntimeError(
                f"Volcengine TTS error: {result.get('message', 'unknown error')}"
            )

        audio_b64 = result.get("data", "")
        audio_bytes = base64.b64decode(audio_b64)

        result = AudioData(
            data=audio_bytes,
            sample_rate=24000,
            channels=1,
            format=opts.output_format,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError("Volcengine TTS streaming not implemented")
        yield  # noqa: unreachable — makes this an async generator
