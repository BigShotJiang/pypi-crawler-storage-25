"""Tencent Cloud TTS provider adapter (TC3-HMAC-SHA256 signed)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
from openspeechapi.logging_config import logger
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import httpx

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class TencentTTSSettings(BaseSettings):
    secret_id: str = ""
    secret_key: str = ""
    voice_type: int = 1001
    region: str = "ap-guangzhou"

class TencentTTS(TTSProvider):
    name = "tencent-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = TencentTTSSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"voice_type": [1001, 1002, 1003, 1004, 1005, 1007, 1008, 1009, 1010, 1017, 1018, 101001, 101002], "region": ["ap-guangzhou", "ap-shanghai", "ap-beijing"]}

    _SERVICE = "tts"
    _HOST = "tts.tencentcloudapi.com"

    def __init__(self, settings: TencentTTSSettings | None = None) -> None:
        self.settings = settings or TencentTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.secret_id) and bool(self.settings.secret_key)

    # ---- TC3-HMAC-SHA256 signing ------------------------------------------------

    def _sign_request(
        self, action: str, version: str, payload_json: str
    ) -> dict[str, str]:
        """Build Tencent Cloud API v3 signed headers."""
        timestamp = int(time.time())
        date = datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime(
            "%Y-%m-%d"
        )

        # 1. Canonical request
        http_method = "POST"
        canonical_uri = "/"
        canonical_querystring = ""
        ct = "application/json; charset=utf-8"
        canonical_headers = (
            f"content-type:{ct}\nhost:{self._HOST}\nx-tc-action:{action.lower()}\n"
        )
        signed_headers = "content-type;host;x-tc-action"
        hashed_payload = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        canonical_request = (
            f"{http_method}\n{canonical_uri}\n{canonical_querystring}\n"
            f"{canonical_headers}\n{signed_headers}\n{hashed_payload}"
        )

        # 2. String to sign
        algorithm = "TC3-HMAC-SHA256"
        credential_scope = f"{date}/{self._SERVICE}/tc3_request"
        hashed_canonical = hashlib.sha256(
            canonical_request.encode("utf-8")
        ).hexdigest()
        string_to_sign = (
            f"{algorithm}\n{timestamp}\n{credential_scope}\n{hashed_canonical}"
        )

        # 3. Signing key
        secret_date = hmac.new(
            ("TC3" + self.settings.secret_key).encode("utf-8"),
            date.encode("utf-8"),
            hashlib.sha256,
        ).digest()
        secret_service = hmac.new(
            secret_date, self._SERVICE.encode("utf-8"), hashlib.sha256
        ).digest()
        secret_signing = hmac.new(
            secret_service, b"tc3_request", hashlib.sha256
        ).digest()

        # 4. Signature
        signature = hmac.new(
            secret_signing, string_to_sign.encode("utf-8"), hashlib.sha256
        ).hexdigest()

        authorization = (
            f"{algorithm} Credential={self.settings.secret_id}/{credential_scope}, "
            f"SignedHeaders={signed_headers}, Signature={signature}"
        )

        return {
            "Authorization": authorization,
            "Content-Type": ct,
            "Host": self._HOST,
            "X-TC-Action": action,
            "X-TC-Version": version,
            "X-TC-Timestamp": str(timestamp),
            "X-TC-Region": self.settings.region,
        }

    # ---- API call ----------------------------------------------------------------

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()

        session_id = uuid.uuid4().hex
        payload = {
            "Text": text,
            "SessionId": session_id,
            "VoiceType": self.settings.voice_type,
            "Codec": "wav",
            "Volume": 0,
            "Speed": 0,
        }
        payload_json = json.dumps(payload)
        headers = self._sign_request("TextToVoice", "2019-08-23", payload_json)

        resp = await self._client.post(
            f"https://{self._HOST}",
            content=payload_json,
            headers=headers,
        )
        resp.raise_for_status()
        result = resp.json()

        response = result.get("Response", {})
        if "Error" in response:
            err = response["Error"]
            raise RuntimeError(
                f"Tencent TTS error [{err.get('Code')}]: {err.get('Message')}"
            )

        audio_b64 = response.get("Audio", "")
        audio_bytes = base64.b64decode(audio_b64)

        result = AudioData(
            data=audio_bytes,
            sample_rate=16000,
            channels=1,
            format=opts.output_format,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError("Tencent TTS streaming not implemented")
        yield  # noqa: unreachable — makes this an async generator
