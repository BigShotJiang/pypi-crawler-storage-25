"""MiniMax TTS provider adapter (REST API, in-process)."""
from __future__ import annotations

import base64
from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class MinimaxTTSSettings(BaseSettings):
    api_key: str = ""
    group_id: str = ""
    model: str = "speech-01"
    voice_id: str = "male-qn-qingse"
    speed: float = 1.0
    vol: float = 1.0
    pitch: int = 0

class MinimaxTTS(TTSProvider):
    name = "minimax"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = MinimaxTTSSettings
    capabilities = {Capability.STREAMING}
    field_options = {
        "model": ["speech-01", "speech-01-turbo", "speech-02"],
        "voice_id": [
            "male-qn-qingse", "male-qn-jingying", "male-qn-badao", "male-qn-daxuesheng",
            "female-shaonv", "female-yujie", "female-chengshu", "female-tianmei",
            "presenter_male", "presenter_female",
        ],
    }

    def __init__(self, settings: MinimaxTTSSettings | None = None) -> None:
        self.settings = settings or MinimaxTTSSettings()
        self._client: Any = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            try:
                import httpx
            except ImportError:
                raise ImportError(
                    "Install httpx: pip install openspeechapi[minimax]"
                )
            self._client = httpx.AsyncClient(timeout=30.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        url = f"https://api.minimax.chat/v1/t2a_v2?GroupId={self.settings.group_id}"
        payload = {
            "model": self.settings.model,
            "text": text,
            "stream": False,
            "voice_setting": {
                "voice_id": opts.voice or self.settings.voice_id,
                "speed": opts.speed if opts.speed != 1.0 else self.settings.speed,
                "vol": self.settings.vol,
                "pitch": self.settings.pitch,
            },
            "audio_setting": {
                "sample_rate": 32000,
                "bitrate": 128000,
                "format": "mp3",
            },
        }
        headers = {
            "Authorization": f"Bearer {self.settings.api_key}",
            "Content-Type": "application/json",
        }
        response = await self._client.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()
        if "data" in data and "audio" in data["data"]:
            audio_bytes = base64.b64decode(data["data"]["audio"])
            result = AudioData(
                data=audio_bytes,
                sample_rate=32000,
                channels=1,
                format=AudioFormat.MP3,
            )
            logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
            return result
        raise RuntimeError(f"Minimax API error: {data}")

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError(
            "MinimaxTTS.synthesize_stream() — streaming not yet implemented"
        )
        yield  # pragma: no cover
