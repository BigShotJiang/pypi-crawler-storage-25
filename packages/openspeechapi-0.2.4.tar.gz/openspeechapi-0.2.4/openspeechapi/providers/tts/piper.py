"""Piper TTS provider adapter (batch, in-process)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class PiperTTSSettings(BaseSettings):
    model_path: str = ""
    config_path: str = ""
    use_cuda: bool = False
    noise_scale: float = 0.667
    length_scale: float = 1.0
    noise_w: float = 0.8

class PiperTTS(TTSProvider):
    name = "piper"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = PiperTTSSettings
    capabilities = {Capability.BATCH}

    def __init__(self, settings: PiperTTSSettings | None = None) -> None:
        self.settings = settings or PiperTTSSettings()
        self._client: Any = None
        self._voice: Any = None

    async def start(self) -> None:
        try:
            import piper
        except ImportError:
            raise ImportError(
                "Install piper-tts: pip install openspeechapi[piper]"
            )
        self._voice = piper.PiperVoice.load(
            self.settings.model_path,
            config_path=self.settings.config_path or None,
            use_cuda=self.settings.use_cuda,
        )
        self._client = self._voice
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._client = None
        self._voice = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return self._client is not None

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        import io
        import wave

        audio_data = b""
        for audio_bytes in self._voice.synthesize_stream_raw(
            text,
            length_scale=self.settings.length_scale,
            noise_scale=self.settings.noise_scale,
            noise_w=self.settings.noise_w,
        ):
            audio_data += audio_bytes

        sample_rate = 22050
        if hasattr(self._voice, "config") and hasattr(self._voice.config, "sample_rate"):
            sample_rate = self._voice.config.sample_rate

        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(audio_data)
        result = AudioData(
            data=buf.getvalue(),
            sample_rate=sample_rate,
            channels=1,
            format=AudioFormat.WAV,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError(
            "PiperTTS does not support streaming synthesis"
        )
        yield  # pragma: no cover
