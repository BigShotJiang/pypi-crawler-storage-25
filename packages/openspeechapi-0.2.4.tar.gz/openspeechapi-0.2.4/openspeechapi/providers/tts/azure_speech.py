"""Azure Speech TTS provider adapter (batch, httpx)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class AzureSpeechTTSSettings(BaseSettings):
    subscription_key: str = ""
    region: str = "eastus"
    voice: str = "en-US-JennyNeural"
    language: str = "en-US"

class AzureSpeechTTS(TTSProvider):
    name = "azure-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.REMOTE
    settings_cls = AzureSpeechTTSSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}
    field_options = {"language": ["en-US", "zh-CN", "ja-JP", "ko-KR", "es-ES", "fr-FR", "de-DE"], "voice": ["en-US-JennyNeural", "en-US-GuyNeural", "en-US-AriaNeural", "zh-CN-XiaoxiaoNeural", "zh-CN-YunxiNeural", "zh-CN-XiaoyiNeural", "ja-JP-NanamiNeural", "ko-KR-SunHiNeural"], "region": ["eastus", "westus2", "westeurope", "eastasia", "southeastasia"]}

    def __init__(self, settings: AzureSpeechTTSSettings | None = None) -> None:
        self.settings = settings or AzureSpeechTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.subscription_key)

    async def _get_access_token(self) -> str:
        """Fetch a short-lived access token from the Azure token endpoint."""
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        url = (
            f"https://{self.settings.region}.api.cognitive.microsoft.com"
            f"/sts/v1.0/issueToken"
        )
        headers = {
            "Ocp-Apim-Subscription-Key": self.settings.subscription_key,
            "Content-Length": "0",
        }
        response = await self._client.post(url, headers=headers, content=b"")
        if response.status_code != 200:
            raise RuntimeError(
                f"Azure token endpoint error {response.status_code}: {response.text}"
            )
        return response.text

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        voice = opts.voice or self.settings.voice
        language = self.settings.language

        token = await self._get_access_token()

        url = (
            f"https://{self.settings.region}.tts.speech.microsoft.com"
            f"/cognitiveservices/v1"
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/ssml+xml",
            "X-Microsoft-OutputFormat": "riff-24khz-16bit-mono-pcm",
        }
        ssml = (
            f"<speak version='1.0' xml:lang='{language}'>"
            f"<voice name='{voice}'>{text}</voice>"
            f"</speak>"
        )
        response = await self._client.post(url, headers=headers, content=ssml)
        if response.status_code != 200:
            raise RuntimeError(
                f"Azure Speech TTS API error {response.status_code}: {response.text}"
            )
        result = AudioData(
            data=response.content,
            sample_rate=24000,
            channels=1,
            format=AudioFormat.WAV,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        raise NotImplementedError(
            "Azure Speech TTS batch provider does not support streaming output"
        )
        yield  # pragma: no cover
