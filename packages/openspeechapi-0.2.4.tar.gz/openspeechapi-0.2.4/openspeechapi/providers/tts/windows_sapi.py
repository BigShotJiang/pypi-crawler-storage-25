"""Windows native TTS provider using SAPI5 via ``pyttsx3``."""
from __future__ import annotations

import asyncio
import io
from openspeechapi.logging_config import logger
import os
import sys
import tempfile
import time
import wave
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

# Language prefix → human-readable group name (reuse same map as macos_say)
_LANG_GROUP_MAP: dict[str, str] = {
    "zh": "中文",
    "en": "English",
    "ja": "日本語",
    "ko": "한국어",
    "fr": "Français",
    "de": "Deutsch",
    "es": "Español",
    "it": "Italiano",
    "pt": "Português",
    "ru": "Русский",
    "ar": "العربية",
}

@dataclass
class WindowsSapiSettings(BaseSettings):
    default_voice: str = ""      # Empty = system default; or voice name substring
    default_rate: int = 200      # pyttsx3 rate (words per minute)

class WindowsSapiTTS(TTSProvider):
    """Windows native TTS via SAPI5 (pyttsx3)."""

    name = "windows-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = WindowsSapiSettings
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}

    def __init__(self, settings: WindowsSapiSettings | None = None) -> None:
        self.settings = settings or WindowsSapiSettings()
        self._available: bool = False
        self._voices_cache: list[dict] | None = None

    # -- lifecycle ------------------------------------------------------------

    async def start(self) -> None:
        if sys.platform != "win32":
            raise RuntimeError(
                "Windows TTS (SAPI5) is only available on Windows"
            )
        try:
            import pyttsx3  # noqa: F401
        except ImportError:
            raise RuntimeError(
                "pyttsx3 is required for Windows TTS. "
                "Install with: pip install pyttsx3"
            )
        # Quick validation: ensure engine can be created
        await asyncio.to_thread(self._validate_engine)
        self._available = True
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._available = False
        self._voices_cache = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        if self._available:
            return True
        if sys.platform != "win32":
            return False
        try:
            import pyttsx3  # noqa: F401
            return True
        except ImportError:
            return False

    # -- synthesis ------------------------------------------------------------

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if not self._available:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()

        opts = opts or TTSOptions()
        voice_hint = opts.voice or self.settings.default_voice
        rate = int(self.settings.default_rate * opts.speed)

        wav_bytes = await asyncio.to_thread(
            self._synthesize_sync, text, voice_hint, rate,
        )

        # Parse WAV to extract real sample_rate/channels/duration
        with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
            sample_rate = wf.getframerate()
            channels = wf.getnchannels()
            n_frames = wf.getnframes()
            duration_ms = int(n_frames / sample_rate * 1000) if sample_rate else 0

        result = AudioData(
            data=wav_bytes,
            sample_rate=sample_rate,
            channels=channels,
            format=AudioFormat.WAV,
            duration_ms=duration_ms,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        """Batch-then-chunk fallback: synthesize full audio, then yield chunks."""
        logger.info("{}: stream request, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        result = await self.synthesize(text, opts)
        chunk_size = 4096
        sequence = 0
        chunk_count = 0
        for i in range(0, len(result.data), chunk_size):
            chunk_data = result.data[i : i + chunk_size]
            logger.debug("{}: chunk #{}, {} bytes", self.name, sequence, len(chunk_data))
            yield AudioChunk(data=chunk_data, sequence=sequence)
            sequence += 1
            chunk_count += 1
        yield AudioChunk(data=b"", sequence=sequence, is_final=True)
        logger.info("{}: stream complete, {} chunks in {:.0f}ms", self.name, chunk_count, (time.perf_counter() - _t0) * 1000)

    # -- voices ---------------------------------------------------------------

    async def list_voices(self) -> list[dict]:
        if self._voices_cache is not None:
            return self._voices_cache

        voices = await asyncio.to_thread(self._list_voices_sync)
        self._voices_cache = voices
        return self._voices_cache

    # -- internal helpers (sync, run in thread) --------------------------------

    @staticmethod
    def _validate_engine() -> None:
        """Create and immediately dispose a pyttsx3 engine to verify SAPI5."""
        import pyttsx3
        engine = pyttsx3.init("sapi5")
        engine.stop()

    @staticmethod
    def _synthesize_sync(text: str, voice_hint: str, rate: int) -> bytes:
        """Synchronous TTS: create engine, synthesize to WAV, return bytes."""
        import pyttsx3

        engine = pyttsx3.init("sapi5")
        try:
            # Set rate
            engine.setProperty("rate", rate)

            # Resolve and set voice
            if voice_hint:
                voices = engine.getProperty("voices")
                hint_lower = voice_hint.lower()
                for v in voices:
                    if hint_lower in v.name.lower() or hint_lower in v.id.lower():
                        engine.setProperty("voice", v.id)
                        break

            # Synthesize to temp WAV file
            fd, tmp_path = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            try:
                engine.save_to_file(text, tmp_path)
                engine.runAndWait()
                wav_bytes = Path(tmp_path).read_bytes()
            finally:
                try:
                    Path(tmp_path).unlink(missing_ok=True)
                except OSError:
                    pass

            return wav_bytes
        finally:
            engine.stop()

    @staticmethod
    def _list_voices_sync() -> list[dict]:
        """List SAPI5 voices synchronously."""
        import pyttsx3

        engine = pyttsx3.init("sapi5")
        try:
            voices = engine.getProperty("voices")
            result: list[dict] = []
            for v in voices:
                # SAPI voice language is in v.languages (list of bytes)
                # or can be parsed from v.id
                lang_str = ""
                if v.languages:
                    # pyttsx3 gives languages as list; first entry is primary
                    raw = v.languages[0]
                    if isinstance(raw, bytes):
                        lang_str = raw.decode("utf-8", errors="replace").strip("\x00")
                    elif isinstance(raw, str):
                        lang_str = raw

                # Derive group from language
                lang_prefix = lang_str.split("-")[0].split("_")[0].lower() if lang_str else ""
                group = _LANG_GROUP_MAP.get(lang_prefix, lang_prefix.upper()) if lang_prefix else "Other"

                result.append({
                    "name": v.name,
                    "language": lang_str,
                    "description": getattr(v, "description", "") or "",
                    "group": group,
                    "id": v.id,
                })
            return result
        finally:
            engine.stop()
