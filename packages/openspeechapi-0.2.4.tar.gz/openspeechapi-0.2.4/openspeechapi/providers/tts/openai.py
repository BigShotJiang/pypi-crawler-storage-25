"""OpenAI TTS provider adapter (speech API)."""
from __future__ import annotations

from openspeechapi.logging_config import logger
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openspeechapi.core.base import TTSProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class OpenAITTSSettings(BaseSettings):
    api_key: str = ""
    base_url: str = ""
    model: str = "tts-1"
    voice: str = "alloy"
    response_format: str = "pcm"

class OpenAITTS(TTSProvider):
    name = "openai-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = OpenAITTSSettings
    capabilities = {Capability.STREAMING, Capability.MULTILINGUAL}
    field_options = {"model": ["tts-1", "tts-1-hd", "gpt-4o-mini-tts"], "voice": ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer", "verse"]}

    def __init__(self, settings: OpenAITTSSettings | None = None) -> None:
        self.settings = settings or OpenAITTSSettings()
        self._client: Any = None

    async def start(self) -> None:
        try:
            from openai import AsyncOpenAI
            kwargs: dict[str, Any] = {"api_key": self.settings.api_key}
            if self.settings.base_url:
                kwargs["base_url"] = self.settings.base_url
            self._client = AsyncOpenAI(**kwargs)
        except ImportError:
            raise ImportError("Install openai: pip install openspeechapi[openai]")
        logger.info("{} provider started", self.name)

    async def stop(self) -> None:
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.api_key)

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        voice = opts.voice or self.settings.voice
        model = getattr(opts, "model", None) or self.settings.model
        response = await self._client.audio.speech.create(
            model=model,
            voice=voice,
            input=text,
            response_format=self.settings.response_format,
        )
        audio_bytes = response.content
        result = AudioData(
            data=audio_bytes,
            sample_rate=24000,
            channels=1,
            format=opts.output_format,
        )
        logger.info("{}: completed in {:.0f}ms, output={} bytes", self.name, (time.perf_counter() - _t0) * 1000, len(result.data))
        return result

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: stream request, text={} chars", self.name, len(text))
        _t0 = time.perf_counter()
        opts = opts or TTSOptions()
        voice = opts.voice or self.settings.voice
        model = getattr(opts, "model", None) or self.settings.model
        chunk_count = 0
        async with self._client.audio.speech.with_streaming_response.create(
            model=model,
            voice=voice,
            input=text,
            response_format=self.settings.response_format,
        ) as response:
            sequence = 0
            async for chunk in response.iter_bytes(chunk_size=4096):
                logger.debug("{}: chunk #{}, {} bytes", self.name, sequence, len(chunk))
                yield AudioChunk(data=chunk, sequence=sequence)
                sequence += 1
                chunk_count += 1
            yield AudioChunk(data=b"", sequence=sequence, is_final=True)
        logger.info("{}: stream complete, {} chunks in {:.0f}ms", self.name, chunk_count, (time.perf_counter() - _t0) * 1000)
