#!/usr/bin/env bash
set -euo pipefail

echo "OPENSPEECH_PHASE:prepare_dirs:10:Preparing service directories..."
mkdir -p "${OPENSPEECH_SERVICE_DIR}"
mkdir -p "${OPENSPEECH_MODEL_DIR}"
mkdir -p "${OPENSPEECH_SERVICE_DIR}/run"
mkdir -p "${OPENSPEECH_REPO_DIR}"

if [[ -x "${OPENSPEECH_VENV_DIR}/bin/python" ]]; then
  VENV_VER="$("${OPENSPEECH_VENV_DIR}/bin/python" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  VENV_MAJOR="${VENV_VER%%.*}"
  VENV_MINOR="${VENV_VER##*.}"
  if [[ "${VENV_MAJOR}" -lt 3 || ( "${VENV_MAJOR}" -eq 3 && "${VENV_MINOR}" -lt 11 ) ]]; then
    echo "OPENSPEECH_PHASE:create_venv:35:Recreating incompatible virtualenv at ${OPENSPEECH_VENV_DIR} ..."
    rm -rf "${OPENSPEECH_VENV_DIR}"
  fi
fi

if [[ -x "${OPENSPEECH_VENV_DIR}/bin/python" ]]; then
  echo "OPENSPEECH_PHASE:create_venv:35:Virtualenv already exists: ${OPENSPEECH_VENV_DIR}"
else
  echo "OPENSPEECH_PHASE:create_venv:35:Creating virtualenv at ${OPENSPEECH_VENV_DIR} ..."
  "${OPENSPEECH_PYTHON_BIN}" -m venv "${OPENSPEECH_VENV_DIR}"
fi

echo "OPENSPEECH_PHASE:install_deps:55:Installing WhisperLiveKit dependencies..."
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install --upgrade pip

REPO_URL="${OPENSPEECH_REPO_URL:-https://github.com/QuentinFuxa/WhisperLiveKit.git}"
REPO_REF="${OPENSPEECH_REPO_REF:-main}"

echo "OPENSPEECH_PHASE:sync_repo:45:Syncing WhisperLiveKit source (${REPO_REF}) ..."
if [[ -d "${OPENSPEECH_REPO_DIR}/.git" ]]; then
  git -C "${OPENSPEECH_REPO_DIR}" remote set-url origin "${REPO_URL}" || true
  git -C "${OPENSPEECH_REPO_DIR}" fetch --all --tags --prune
else
  rm -rf "${OPENSPEECH_REPO_DIR}"
  git clone "${REPO_URL}" "${OPENSPEECH_REPO_DIR}"
fi

if git -C "${OPENSPEECH_REPO_DIR}" show-ref --verify --quiet "refs/remotes/origin/${REPO_REF}"; then
  git -C "${OPENSPEECH_REPO_DIR}" checkout -B "${REPO_REF}" "origin/${REPO_REF}"
else
  git -C "${OPENSPEECH_REPO_DIR}" checkout "${REPO_REF}"
fi

mkdir -p "${OPENSPEECH_MODEL_DIR}"

echo "OPENSPEECH_PHASE:install_deps:60:Installing WhisperLiveKit in editable mode..."
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install --upgrade setuptools wheel
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install -e "${OPENSPEECH_REPO_DIR}"
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install mlx-whisper websockets "httpx[socks]" python-multipart

expand_path() {
  local p="$1"
  if [[ "$p" == ~* ]]; then
    printf "%s\n" "${HOME}${p:1}"
  else
    printf "%s\n" "$p"
  fi
}

echo "OPENSPEECH_PHASE:scan_local_models:70:Scanning local model paths..."
FOUND=""
IFS=':' read -r -a CANDIDATES <<< "${OPENSPEECH_EXISTING_MODEL_PATHS:-}"
for raw in "${CANDIDATES[@]}"; do
  [[ -z "${raw}" ]] && continue
  candidate="$(expand_path "${raw}")"
  if [[ -f "${candidate}" ]]; then
    FOUND="${candidate}"
    break
  fi
done

if [[ -n "${FOUND}" ]]; then
  echo "OPENSPEECH_PHASE:link_model:85:Linking existing model file: ${FOUND}"
  ln -sfn "${FOUND}" "${OPENSPEECH_MODEL_DIR}/current.pt"
  cat > "${OPENSPEECH_MODEL_DIR}/metadata.json" <<JSON
{"engine":"whisperlivekit","source":"${FOUND}","mode":"linked"}
JSON
else
  echo "OPENSPEECH_PHASE:link_model:85:No local model file linked (WhisperLiveKit may auto-download)."
fi

echo "OPENSPEECH_PHASE:done:100:WhisperLiveKit install completed."
