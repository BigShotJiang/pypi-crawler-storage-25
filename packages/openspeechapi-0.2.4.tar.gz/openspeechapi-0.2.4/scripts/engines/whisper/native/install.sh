#!/usr/bin/env bash
set -euo pipefail

echo "OPENSPEECH_PHASE:prepare_dirs:10:Preparing service directories..."
mkdir -p "${OPENSPEECH_SERVICE_DIR}"
mkdir -p "${OPENSPEECH_MODEL_DIR}"
mkdir -p "${OPENSPEECH_SERVICE_DIR}/run"

expand_path() {
  local p="$1"
  if [[ "$p" == ~* ]]; then
    printf "%s\n" "${HOME}${p:1}"
  else
    printf "%s\n" "$p"
  fi
}

echo "OPENSPEECH_PHASE:scan_local_models:25:Scanning local model paths..."
FOUND=""
IFS=':' read -r -a CANDIDATES <<< "${OPENSPEECH_EXISTING_MODEL_PATHS:-}"
for raw in "${CANDIDATES[@]}"; do
  [[ -z "${raw}" ]] && continue
  candidate="$(expand_path "${raw}")"
  if [[ -f "${candidate}" ]]; then
    FOUND="${candidate}"
    break
  fi
done

if [[ -n "${FOUND}" ]]; then
  echo "OPENSPEECH_PHASE:link_model:65:Linking existing model file: ${FOUND}"
  ln -sfn "${FOUND}" "${OPENSPEECH_MODEL_DIR}/current.pt"
  cat > "${OPENSPEECH_MODEL_DIR}/metadata.json" <<JSON
{"engine":"whisper","source":"${FOUND}","mode":"linked"}
JSON
  echo "OPENSPEECH_PHASE:done:100:Install completed with existing local model."
  exit 0
fi

if [[ "${OPENSPEECH_SIMULATE_DOWNLOAD:-1}" == "1" ]]; then
  echo "OPENSPEECH_PHASE:simulate_download:40:No local model found, simulating download..."
  echo "OPENSPEECH_PHASE:simulate_download:55:Downloading model checkpoint (simulated)..."
  sleep 0.2
  echo "OPENSPEECH_PHASE:simulate_download:75:Verifying checkpoint (simulated)..."
  sleep 0.2
  PLACEHOLDER="${OPENSPEECH_MODEL_DIR}/placeholder-whisper.pt"
  echo "simulated whisper model placeholder" > "${PLACEHOLDER}"
  ln -sfn "${PLACEHOLDER}" "${OPENSPEECH_MODEL_DIR}/current.pt"
  cat > "${OPENSPEECH_MODEL_DIR}/metadata.json" <<JSON
{"engine":"whisper","source":"simulated","mode":"placeholder"}
JSON
  echo "OPENSPEECH_PHASE:done:100:Install completed with simulated model placeholder."
  exit 0
fi

echo "OPENSPEECH_PHASE:failed:100:No local model found and simulation disabled."
exit 1

