#!/usr/bin/env bash
set -euo pipefail

echo "OPENSPEECH_PHASE:prepare_dirs:12:Preparing service directories..."
mkdir -p "${OPENSPEECH_SERVICE_DIR}"
mkdir -p "${OPENSPEECH_MODEL_DIR}"

if [[ -d "${OPENSPEECH_REPO_DIR}/.git" ]]; then
  echo "OPENSPEECH_PHASE:clone_repo:25:Repository already exists: ${OPENSPEECH_REPO_DIR}"
else
  echo "OPENSPEECH_PHASE:clone_repo:25:Cloning repository from ${OPENSPEECH_REPO_URL} ..."
  git clone --depth 1 --branch "${OPENSPEECH_REPO_REF}" "${OPENSPEECH_REPO_URL}" "${OPENSPEECH_REPO_DIR}"
fi

if [[ -x "${OPENSPEECH_VENV_DIR}/bin/python" ]]; then
  VENV_VER="$("${OPENSPEECH_VENV_DIR}/bin/python" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  VENV_MAJOR="${VENV_VER%%.*}"
  VENV_MINOR="${VENV_VER##*.}"
  if [[ "${VENV_MAJOR}" -lt 3 || ( "${VENV_MAJOR}" -eq 3 && "${VENV_MINOR}" -lt 10 ) ]]; then
    echo "OPENSPEECH_PHASE:create_venv:42:Recreating incompatible virtualenv at ${OPENSPEECH_VENV_DIR} ..."
    rm -rf "${OPENSPEECH_VENV_DIR}"
  fi
fi

if [[ -x "${OPENSPEECH_VENV_DIR}/bin/python" ]]; then
  echo "OPENSPEECH_PHASE:create_venv:42:Virtualenv already exists: ${OPENSPEECH_VENV_DIR}"
else
  echo "OPENSPEECH_PHASE:create_venv:42:Creating virtualenv at ${OPENSPEECH_VENV_DIR} ..."
  "${OPENSPEECH_PYTHON_BIN}" -m venv "${OPENSPEECH_VENV_DIR}"
fi

if [[ -f "${OPENSPEECH_MODEL_DIR}/codec.pth" && -f "${OPENSPEECH_MODEL_DIR}/model.safetensors.index.json" ]]; then
  echo "OPENSPEECH_PHASE:download_model:50:Model weights already present: ${OPENSPEECH_MODEL_DIR}"
else
  echo "OPENSPEECH_PHASE:download_model:50:Downloading model weights from ${OPENSPEECH_MODEL_REPO} ..."
  HF_ARGS=(
    download
    "${OPENSPEECH_MODEL_REPO}"
    --local-dir "${OPENSPEECH_MODEL_DIR}"
    --max-workers "${OPENSPEECH_HF_MAX_WORKERS}"
  )
  if [[ -n "${OPENSPEECH_HF_TOKEN:-}" ]]; then
    HF_ARGS+=(--token "${OPENSPEECH_HF_TOKEN}")
  fi
  "${OPENSPEECH_HF_BIN}" "${HF_ARGS[@]}"
  echo "OPENSPEECH_PHASE:download_model:55:Model weights downloaded to ${OPENSPEECH_MODEL_DIR}"
fi

echo "OPENSPEECH_PHASE:install_deps:58:Installing Python dependencies (this may take a while)..."
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install --upgrade pip
cd "${OPENSPEECH_REPO_DIR}"
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install -e "${OPENSPEECH_INSTALL_TARGET}"

echo "OPENSPEECH_PHASE:done:100:Install script completed."
