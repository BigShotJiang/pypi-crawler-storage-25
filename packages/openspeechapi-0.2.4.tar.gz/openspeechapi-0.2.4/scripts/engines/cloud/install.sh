#!/usr/bin/env bash
# Generic cloud engine install script.
# Called by the engine catalog install API for cloud providers.
#
# Environment variables (set by the caller):
#   OPENSPEECH_ENGINE       - engine name (e.g. "openai-stt")
#   OPENSPEECH_PIP_DEPS     - space-separated pip packages to install
#   OPENSPEECH_PYTHON_BIN   - python executable (defaults to python3)
#
# Progress protocol: echo "OPENSPEECH_PHASE:{phase}:{progress}:{message}"

set -euo pipefail

ENGINE="${OPENSPEECH_ENGINE:-unknown}"
PIP_DEPS="${OPENSPEECH_PIP_DEPS:-}"
PYTHON="${OPENSPEECH_PYTHON_BIN:-python3}"

echo "OPENSPEECH_PHASE:check_deps:10:Checking dependencies for ${ENGINE}..."

# Check httpx (required by all cloud providers)
if ! "${PYTHON}" -c "import httpx" 2>/dev/null; then
    echo "OPENSPEECH_PHASE:install_httpx:20:Installing httpx..."
    "${PYTHON}" -m pip install httpx --quiet 2>&1
fi

# Install engine-specific pip dependencies
if [[ -n "${PIP_DEPS}" ]]; then
    TOTAL=$(echo "${PIP_DEPS}" | wc -w | tr -d ' ')
    IDX=0
    for dep in ${PIP_DEPS}; do
        IDX=$((IDX + 1))
        PROGRESS=$((30 + 60 * IDX / TOTAL))
        echo "OPENSPEECH_PHASE:install_dep:${PROGRESS}:Installing ${dep} (${IDX}/${TOTAL})..."
        if ! "${PYTHON}" -c "import ${dep}" 2>/dev/null; then
            "${PYTHON}" -m pip install "${dep}" --quiet 2>&1
        else
            echo "OPENSPEECH_PHASE:install_dep:${PROGRESS}:${dep} already installed, skipping."
        fi
    done
fi

# Verify imports
echo "OPENSPEECH_PHASE:verify:90:Verifying provider module can be imported..."
# The provider module name follows a pattern: openspeechapi.providers.{stt|tts}.{module}
# We just verify httpx is available since all cloud providers use it
"${PYTHON}" -c "import httpx; print('httpx OK')" 2>&1

echo "OPENSPEECH_PHASE:done:100:${ENGINE} installation complete."
