#!/usr/bin/env python3
"""Launch sherpa-onnx streaming server with auto-detected model arguments."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys


def _find_tokens(model_dir: Path) -> Path | None:
    for p in [model_dir / "tokens.txt", *model_dir.rglob("tokens.txt")]:
        if p.exists():
            return p
    return None


def _find_first(candidates: list[Path]) -> Path | None:
    for p in candidates:
        if p.exists():
            return p
    return None


def _detect_model_flags(model_dir: Path) -> list[str]:
    files = list(model_dir.rglob("*.onnx"))
    lower = {p: p.name.lower() for p in files}

    encoder = _find_first(
        [p for p, n in lower.items() if "encoder" in n and "paraformer" not in n]
    )
    decoder = _find_first([p for p, n in lower.items() if "decoder" in n and "paraformer" not in n])
    joiner = _find_first([p for p, n in lower.items() if "joiner" in n])
    if encoder and decoder and joiner:
        return [
            "--encoder",
            str(encoder),
            "--decoder",
            str(decoder),
            "--joiner",
            str(joiner),
        ]

    paraformer_encoder = _find_first([p for p, n in lower.items() if "paraformer" in n and "encoder" in n])
    paraformer_decoder = _find_first([p for p, n in lower.items() if "paraformer" in n and "decoder" in n])
    if paraformer_encoder and paraformer_decoder:
        return [
            "--paraformer-encoder",
            str(paraformer_encoder),
            "--paraformer-decoder",
            str(paraformer_decoder),
        ]

    zipformer2_ctc = _find_first([p for p, n in lower.items() if "zipformer2" in n and "ctc" in n])
    if zipformer2_ctc:
        return ["--zipformer2-ctc", str(zipformer2_ctc)]

    wenet_ctc = _find_first([p for p, n in lower.items() if "wenet" in n and "ctc" in n])
    if wenet_ctc:
        return ["--wenet-ctc", str(wenet_ctc)]

    raise RuntimeError(
        "Unable to detect sherpa model files. Expected transducer/paraformer/ctc ONNX files."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="OpenSpeechAPI sherpa-onnx launcher")
    parser.add_argument("--repo-dir", required=True, help="sherpa-onnx source dir")
    parser.add_argument("--model-dir", required=True, help="model directory")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=17000)
    parser.add_argument("--num-threads", type=int, default=2)
    parser.add_argument("--sample-rate", type=int, default=16000)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    repo_dir = Path(args.repo_dir).expanduser().resolve()
    model_dir = Path(args.model_dir).expanduser().resolve()
    script = repo_dir / "python-api-examples" / "streaming_server.py"
    if not script.exists():
        raise RuntimeError(f"sherpa streaming server script not found: {script}")
    if not model_dir.exists():
        raise RuntimeError(f"Model dir not found: {model_dir}")

    tokens = _find_tokens(model_dir)
    if tokens is None:
        raise RuntimeError(f"tokens.txt not found under model dir: {model_dir}")
    model_flags = _detect_model_flags(model_dir)

    cmd = [
        sys.executable,
        str(script),
        "--port",
        str(args.port),
        "--tokens",
        str(tokens),
        "--num-threads",
        str(args.num_threads),
        "--sample-rate",
        str(args.sample_rate),
        *model_flags,
    ]
    if args.debug:
        cmd.extend(["--debug", "1"])

    os.execv(sys.executable, cmd)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

