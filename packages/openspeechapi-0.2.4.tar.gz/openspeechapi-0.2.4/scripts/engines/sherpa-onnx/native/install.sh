#!/usr/bin/env bash
set -euo pipefail

echo "OPENSPEECH_PHASE:prepare_dirs:10:Preparing service directories..."
mkdir -p "${OPENSPEECH_SERVICE_DIR}"
mkdir -p "${OPENSPEECH_MODEL_DIR}"
mkdir -p "${OPENSPEECH_SERVICE_DIR}/run"
mkdir -p "${OPENSPEECH_REPO_DIR}"

if [[ -x "${OPENSPEECH_VENV_DIR}/bin/python" ]]; then
  VENV_VER="$("${OPENSPEECH_VENV_DIR}/bin/python" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  VENV_MAJOR="${VENV_VER%%.*}"
  VENV_MINOR="${VENV_VER##*.}"
  if [[ "${VENV_MAJOR}" -lt 3 || ( "${VENV_MAJOR}" -eq 3 && "${VENV_MINOR}" -lt 10 ) ]]; then
    echo "OPENSPEECH_PHASE:create_venv:26:Recreating incompatible virtualenv at ${OPENSPEECH_VENV_DIR} ..."
    rm -rf "${OPENSPEECH_VENV_DIR}"
  fi
fi

if [[ -x "${OPENSPEECH_VENV_DIR}/bin/python" ]]; then
  echo "OPENSPEECH_PHASE:create_venv:26:Virtualenv already exists: ${OPENSPEECH_VENV_DIR}"
else
  echo "OPENSPEECH_PHASE:create_venv:26:Creating virtualenv at ${OPENSPEECH_VENV_DIR} ..."
  "${OPENSPEECH_PYTHON_BIN}" -m venv "${OPENSPEECH_VENV_DIR}"
fi

echo "OPENSPEECH_PHASE:sync_repo:38:Syncing sherpa-onnx source ..."
REPO_URL="${OPENSPEECH_REPO_URL:-https://github.com/k2-fsa/sherpa-onnx.git}"
REPO_REF="${OPENSPEECH_REPO_REF:-master}"
if [[ -d "${OPENSPEECH_REPO_DIR}/.git" ]]; then
  git -C "${OPENSPEECH_REPO_DIR}" remote set-url origin "${REPO_URL}" || true
  git -C "${OPENSPEECH_REPO_DIR}" fetch --all --tags --prune
else
  rm -rf "${OPENSPEECH_REPO_DIR}"
  git clone "${REPO_URL}" "${OPENSPEECH_REPO_DIR}"
fi
if git -C "${OPENSPEECH_REPO_DIR}" show-ref --verify --quiet "refs/remotes/origin/${REPO_REF}"; then
  git -C "${OPENSPEECH_REPO_DIR}" checkout -B "${REPO_REF}" "origin/${REPO_REF}"
else
  git -C "${OPENSPEECH_REPO_DIR}" checkout "${REPO_REF}"
fi

echo "OPENSPEECH_PHASE:install_deps:50:Installing sherpa runtime dependencies..."
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install --upgrade pip setuptools wheel
"${OPENSPEECH_VENV_DIR}/bin/python" -m pip install --upgrade sherpa-onnx websockets numpy soundfile "huggingface_hub[cli]"

expand_path() {
  local p="$1"
  if [[ "$p" == ~* ]]; then
    printf "%s\n" "${HOME}${p:1}"
  else
    printf "%s\n" "$p"
  fi
}

echo "OPENSPEECH_PHASE:scan_local_models:58:Scanning local model paths..."
FOUND=""
IFS=':' read -r -a CANDIDATES <<< "${OPENSPEECH_EXISTING_MODEL_PATHS:-}"
for raw in "${CANDIDATES[@]}"; do
  [[ -z "${raw}" ]] && continue
  candidate="$(expand_path "${raw}")"
  if [[ -d "${candidate}" ]]; then
    FOUND="${candidate}"
    break
  fi
done

if [[ -n "${FOUND}" ]]; then
  echo "OPENSPEECH_PHASE:link_model:75:Linking existing model directory: ${FOUND}"
  ln -sfn "${FOUND}" "${OPENSPEECH_MODEL_DIR}/current"
  cat > "${OPENSPEECH_MODEL_DIR}/metadata.json" <<JSON
{"engine":"sherpa-onnx","source":"${FOUND}","mode":"linked"}
JSON
  echo "OPENSPEECH_PHASE:done:100:Install completed with local model linked."
  exit 0
fi

MODEL_REPO="${OPENSPEECH_MODEL_REPO:-}"
if [[ "${MODEL_REPO}" == "fishaudio/s2-pro" ]]; then
  MODEL_REPO=""
fi

if [[ -n "${MODEL_REPO}" ]]; then
  echo "OPENSPEECH_PHASE:download_model:68:Downloading model from Hugging Face repo: ${MODEL_REPO}"
  HF_BIN="${OPENSPEECH_HF_BIN:-}"
  if [[ -z "${HF_BIN}" ]]; then
    if command -v hf >/dev/null 2>&1; then
      HF_BIN="hf"
    elif command -v huggingface-cli >/dev/null 2>&1; then
      HF_BIN="huggingface-cli"
    else
      HF_BIN="${OPENSPEECH_VENV_DIR}/bin/hf"
    fi
  fi
  DOWNLOAD_DIR="${OPENSPEECH_MODEL_DIR}/downloads/$(echo "${MODEL_REPO}" | tr '/' '_')"
  mkdir -p "${DOWNLOAD_DIR}"
  if "${HF_BIN}" download --help 2>/dev/null | grep -q -- "--resume-download"; then
    "${HF_BIN}" download "${MODEL_REPO}" --repo-type model --local-dir "${DOWNLOAD_DIR}" --resume-download
  else
    "${HF_BIN}" download "${MODEL_REPO}" --repo-type model --local-dir "${DOWNLOAD_DIR}"
  fi
  echo "OPENSPEECH_PHASE:verify_model:92:Verifying downloaded model files..."
  if find "${DOWNLOAD_DIR}" -type f -name "*.onnx" | grep -q . && [[ -f "${DOWNLOAD_DIR}/tokens.txt" ]]; then
    ln -sfn "${DOWNLOAD_DIR}" "${OPENSPEECH_MODEL_DIR}/current"
    cat > "${OPENSPEECH_MODEL_DIR}/metadata.json" <<JSON
{"engine":"sherpa-onnx","source":"${MODEL_REPO}","mode":"downloaded"}
JSON
    echo "OPENSPEECH_PHASE:done:100:Install completed with downloaded model."
    exit 0
  fi
  echo "OPENSPEECH_PHASE:verify_model:95:Downloaded repo missing required files (need *.onnx + tokens.txt)."
fi

if [[ "${OPENSPEECH_SIMULATE_DOWNLOAD:-1}" == "1" ]]; then
  echo "OPENSPEECH_PHASE:simulate_download:68:No local model found, simulating download..."
  echo "OPENSPEECH_PHASE:simulate_download:82:Downloading model archives (simulated)..."
  sleep 0.2
  echo "OPENSPEECH_PHASE:simulate_download:92:Extracting and verifying files (simulated)..."
  sleep 0.2
  PLACEHOLDER="${OPENSPEECH_MODEL_DIR}/placeholder-sherpa-onnx"
  mkdir -p "${PLACEHOLDER}"
  echo "<unk> 0" > "${PLACEHOLDER}/tokens.txt"
  echo "simulated sherpa-onnx model placeholder" > "${PLACEHOLDER}/README.txt"
  ln -sfn "${PLACEHOLDER}" "${OPENSPEECH_MODEL_DIR}/current"
  cat > "${OPENSPEECH_MODEL_DIR}/metadata.json" <<JSON
{"engine":"sherpa-onnx","source":"simulated","mode":"placeholder"}
JSON
  echo "OPENSPEECH_PHASE:done:100:Install completed with simulated model placeholder."
  exit 0
fi

echo "OPENSPEECH_PHASE:failed:100:No local model found and simulation disabled."
exit 1
