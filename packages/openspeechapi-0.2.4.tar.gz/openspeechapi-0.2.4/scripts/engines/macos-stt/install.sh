#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BINARY_NAME="macos-stt-helper"
SWIFT_SOURCE="${SCRIPT_DIR}/macos_stt.swift"
BUNDLE_ID="com.openspeechapi.macos-stt-helper"

# .app bundle — the binary lives INSIDE here; TCC tracks it by bundle ID.
APP_BUNDLE="${SCRIPT_DIR}/MacOSSTTHelper.app"
APP_CONTENTS="${APP_BUNDLE}/Contents"
APP_MACOS="${APP_CONTENTS}/MacOS"
APP_BINARY="${APP_MACOS}/${BINARY_NAME}"

# --- Platform check ---
if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "ERROR: This tool only runs on macOS." >&2
    exit 1
fi

# --- Xcode CLI tools check ---
if ! xcode-select -p >/dev/null 2>&1; then
    echo "ERROR: Xcode Command Line Tools are not installed." >&2
    echo "Run: xcode-select --install" >&2
    exit 1
fi

# --- Create .app bundle structure ---
rm -rf "${APP_BUNDLE}"
mkdir -p "${APP_MACOS}"

# Info.plist with bundle ID and usage description
cat > "${APP_CONTENTS}/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleIdentifier</key>
  <string>${BUNDLE_ID}</string>
  <key>CFBundleName</key>
  <string>MacOS STT Helper</string>
  <key>CFBundleExecutable</key>
  <string>${BINARY_NAME}</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleVersion</key>
  <string>1.0</string>
  <key>LSUIElement</key>
  <true/>
  <key>NSSpeechRecognitionUsageDescription</key>
  <string>OpenSpeechAPI needs Speech Recognition to transcribe audio files.</string>
</dict>
</plist>
PLIST

# --- Compile directly into the .app bundle ---
echo "Compiling ${SWIFT_SOURCE} -> ${APP_BINARY} ..."
swiftc -o "${APP_BINARY}" "${SWIFT_SOURCE}" \
    -framework Speech -framework Foundation
chmod +x "${APP_BINARY}"

# --- Ad-hoc code sign the .app bundle ---
codesign --force --deep --sign - "${APP_BUNDLE}"

# --- Convenience symlink at the old location ---
ln -sf "${APP_BINARY}" "${SCRIPT_DIR}/${BINARY_NAME}"

echo ""
echo "Build complete!"
echo "  App bundle: ${APP_BUNDLE}"
echo "  Binary:     ${APP_BINARY}"
echo "  Symlink:    ${SCRIPT_DIR}/${BINARY_NAME}"
echo ""
echo "=== First-time setup ==="
echo "1. Grant Speech Recognition permission:"
echo "   open '${APP_BUNDLE}' --args --check"
echo "   Then approve the macOS permission dialog."
echo ""
echo "2. Verify:  '${APP_BINARY}' --check"
