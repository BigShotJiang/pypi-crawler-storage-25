import Foundation
import Speech

/// Minimal CLI wrapper around SFSpeechRecognizer.
/// Usage: macos-stt-helper --audio <path> [--language <code>]
///        macos-stt-helper --check [--language <code>]
/// Outputs JSON to stdout: {"text": "...", "confidence": 0.95, "language": "..."}
/// Check mode: {"status": "ok", "auth": "authorized", "available": true, "onDevice": true}
/// On error: {"error": "..."}

/// Write string to outputPath if set, otherwise print to stdout.
var outputPath: String?

func writeOutput(_ str: String) {
    if let path = outputPath {
        try? str.write(toFile: path, atomically: true, encoding: .utf8)
    } else {
        print(str)
    }
}

func printError(_ message: String) -> Never {
    let obj: [String: Any] = ["error": message]
    if let data = try? JSONSerialization.data(withJSONObject: obj),
       let str = String(data: data, encoding: .utf8) {
        writeOutput(str)
    } else {
        writeOutput("{\"error\": \"unknown\"}")
    }
    exit(1)
}

func printResult(text: String, confidence: Float, language: String) {
    let obj: [String: Any] = [
        "text": text,
        "confidence": confidence,
        "language": language
    ]
    if let data = try? JSONSerialization.data(withJSONObject: obj),
       let str = String(data: data, encoding: .utf8) {
        writeOutput(str)
    } else {
        printError("Failed to serialize result")
    }
}

func authStatusString(_ status: SFSpeechRecognizerAuthorizationStatus) -> String {
    switch status {
    case .authorized: return "authorized"
    case .denied: return "denied"
    case .restricted: return "restricted"
    case .notDetermined: return "notDetermined"
    @unknown default: return "unknown"
    }
}

/// Check authorization and recognizer availability without performing recognition.
func runCheck(language: String) -> Never {
    let status = SFSpeechRecognizer.authorizationStatus()
    let locale = Locale(identifier: language)
    let recognizer = SFSpeechRecognizer(locale: locale)

    let available = recognizer?.isAvailable ?? false
    let onDevice = recognizer?.supportsOnDeviceRecognition ?? false
    let authStr = authStatusString(status)

    if status == .denied || status == .restricted {
        let hint: String
        switch status {
        case .denied:
            hint = "Speech recognition permission denied. Open System Settings > Privacy & Security > Speech Recognition and enable this app."
        case .restricted:
            hint = "Speech recognition is restricted on this device."
        default:
            hint = "Unknown authorization state."
        }
        let obj: [String: Any] = [
            "status": "error",
            "auth": authStr,
            "available": available,
            "onDevice": onDevice,
            "error": hint
        ]
        if let data = try? JSONSerialization.data(withJSONObject: obj),
           let str = String(data: data, encoding: .utf8) {
            print(str)
        }
        exit(1)
    }

    // notDetermined from CLI is expected — TCC can't confirm CLI binary identity.
    // Report ok and let actual recognition attempt determine real auth.
    let obj: [String: Any] = [
        "status": "ok",
        "auth": authStr,
        "available": available,
        "onDevice": onDevice
    ]
    if let data = try? JSONSerialization.data(withJSONObject: obj),
       let str = String(data: data, encoding: .utf8) {
        print(str)
    }
    exit(0)
}

/// Request authorization interactively (must be launched via `open` as .app bundle).
/// Uses RunLoop to allow the system dialog to appear.
func runRequestAuth() -> Never {
    var finalStatus: SFSpeechRecognizerAuthorizationStatus = .notDetermined
    let semaphore = DispatchSemaphore(value: 0)

    SFSpeechRecognizer.requestAuthorization { status in
        finalStatus = status
        semaphore.signal()
    }

    // Pump RunLoop so the auth dialog can appear and be interacted with
    while semaphore.wait(timeout: .now()) == .timedOut {
        RunLoop.main.run(until: Date(timeIntervalSinceNow: 0.1))
    }

    let statusStr = authStatusString(finalStatus)
    let obj: [String: Any] = [
        "status": finalStatus == .authorized ? "ok" : "error",
        "auth": statusStr,
    ]
    if let data = try? JSONSerialization.data(withJSONObject: obj),
       let str = String(data: data, encoding: .utf8) {
        print(str)
    }
    exit(finalStatus == .authorized ? 0 : 1)
}

// --- Argument parsing ---
var audioPath: String?
var language = "en-US"
var checkMode = false
var requestAuthMode = false

var args = CommandLine.arguments.dropFirst()
while let arg = args.first {
    args = args.dropFirst()
    switch arg {
    case "--audio":
        guard let val = args.first else { printError("--audio requires a path") }
        audioPath = val
        args = args.dropFirst()
    case "--language":
        guard let val = args.first else { printError("--language requires a code") }
        language = val
        args = args.dropFirst()
    case "--output":
        guard let val = args.first else { printError("--output requires a path") }
        outputPath = val
        args = args.dropFirst()
    case "--check":
        checkMode = true
    case "--request-auth":
        requestAuthMode = true
    default:
        // Ignore NSApplication args injected by `open` (e.g. -psn_...)
        break
    }
}

// --- Request auth mode (only works when launched via `open` as .app) ---
if requestAuthMode {
    runRequestAuth()
}

// --- Check mode ---
if checkMode {
    runCheck(language: language)
}

// --- Default: if no --audio and no other mode, act as request-auth (for `open` launch) ---
if audioPath == nil && !checkMode && !requestAuthMode {
    runRequestAuth()
}

// --- Authorization check before recognition ---
// When launched via `open` as .app bundle, TCC recognizes the bundle ID.
// When launched directly from CLI, authorizationStatus() may return notDetermined
// even if the .app bundle has been authorized. Skip the pre-check in that case
// and let SFSpeechRecognizer attempt recognition — it will fail with a clear
// error from the framework if not authorized.
let authStatus = SFSpeechRecognizer.authorizationStatus()
if authStatus == .denied || authStatus == .restricted {
    let authStr = authStatusString(authStatus)
    printError("Speech recognition not authorized (status: \(authStr)). Grant permission in System Settings > Privacy & Security > Speech Recognition.")
}

guard let filePath = audioPath else {
    printError("--audio <path> is required")
}

let fileURL = URL(fileURLWithPath: filePath)
guard FileManager.default.fileExists(atPath: filePath) else {
    printError("Audio file not found: \(filePath)")
}

// --- Speech recognition ---
let locale = Locale(identifier: language)
guard let recognizer = SFSpeechRecognizer(locale: locale) else {
    printError("SFSpeechRecognizer not available for locale: \(language)")
}

guard recognizer.isAvailable else {
    printError("SFSpeechRecognizer is not available on this device")
}

let request = SFSpeechURLRecognitionRequest(url: fileURL)
request.shouldReportPartialResults = false
// Note: do NOT set requiresOnDeviceRecognition = true here.
// On-device models may not be downloaded yet, causing silent hangs.
// SFSpeechRecognizer will prefer on-device when available automatically.

var resultText = ""
var resultConfidence: Float = 0.0
var resultError: String?
var finished = false

recognizer.recognitionTask(with: request) { result, error in
    if let error = error {
        resultError = error.localizedDescription
        finished = true
        return
    }
    guard let result = result else { return }
    if result.isFinal {
        resultText = result.bestTranscription.formattedString
        let segments = result.bestTranscription.segments
        if !segments.isEmpty {
            let totalConfidence = segments.reduce(Float(0)) { $0 + $1.confidence }
            resultConfidence = totalConfidence / Float(segments.count)
        }
        finished = true
    }
}

// Pump the RunLoop so the recognition callback can be delivered on the main thread.
let deadline = Date(timeIntervalSinceNow: 60)
while !finished && Date() < deadline {
    RunLoop.main.run(until: Date(timeIntervalSinceNow: 0.1))
}

if !finished {
    printError("Recognition timed out after 60 seconds. This usually means the on-device speech model is not downloaded. Go to System Settings > Keyboard > Dictation and download the language model for '\(language)'.")
}

if let err = resultError {
    printError(err)
}

printResult(text: resultText, confidence: resultConfidence, language: language)
