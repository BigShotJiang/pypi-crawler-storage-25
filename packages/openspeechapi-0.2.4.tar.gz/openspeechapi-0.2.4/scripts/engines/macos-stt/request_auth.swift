/// Standalone authorization requester for macOS Speech Recognition.
/// Must be run inside an .app bundle (via `open MacOSSTTHelper.app --args --request-auth`)
/// to trigger the TCC permission dialog.
import Foundation
import Speech

let semaphore = DispatchSemaphore(value: 0)
var finalStatus: SFSpeechRecognizerAuthorizationStatus = .notDetermined

SFSpeechRecognizer.requestAuthorization { status in
    finalStatus = status
    semaphore.signal()
}

// Run the main RunLoop briefly to allow the authorization dialog to appear
DispatchQueue.global().async {
    _ = semaphore.wait(timeout: .now() + 60)

    let statusStr: String
    switch finalStatus {
    case .authorized: statusStr = "authorized"
    case .denied: statusStr = "denied"
    case .restricted: statusStr = "restricted"
    case .notDetermined: statusStr = "notDetermined"
    @unknown default: statusStr = "unknown"
    }

    let obj: [String: Any] = [
        "status": finalStatus == .authorized ? "ok" : "error",
        "auth": statusStr,
    ]
    if let data = try? JSONSerialization.data(withJSONObject: obj),
       let str = String(data: data, encoding: .utf8) {
        print(str)
    }
    exit(finalStatus == .authorized ? 0 : 1)
}

RunLoop.main.run(until: Date(timeIntervalSinceNow: 65))
