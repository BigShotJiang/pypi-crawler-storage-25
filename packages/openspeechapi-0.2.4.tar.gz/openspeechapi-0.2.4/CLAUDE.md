# 语音大模型统一接口项目规范

## 系统架构和整体规范
1. 当前系统为MacOS，对模型和引擎的选择，优先匹配macOS和mlx框架
2. 随时要确保前端页面和后台服务之间的状态是保持同步一致的，避免服务已经异常，但前台没有任何状态表现

## Agent 调度规则

**所有 Agent 工具调用必须加上 `mode: "bypassPermissions"`**，示例：

```json
{
  "subagent_type": "general-purpose",
  "mode": "bypassPermissions",
  "prompt": "..."
}
```

### Agent角色分工
1. 可选的Agent角色参考 [~/.claude/AGENTS.md](~/.claude/AGENTS.md)文件的描述。
2. 默认启动项目经理角色，项目经理仅负责项目当前进度的同步管理和任务调度分派，其他工作根据已设定的agent，按照需要选择合适的角色启动并进行工作分配。

## 功能实现规范

1. 每次对话提到问题bug或者功能点变化时，先进行问题分析和功能实现方案设计，并和用户确认后再执行实际开发修复工作。
2. 功能修复或者功能点更新完成后，同步检查是否需要更新对应的文档。

## Provider 开发规范

### STT 流式识别规范
所有声明了 `Capability.STREAMING` 的 STT Provider 必须遵循 [STT 流式识别开发规范](docs/architecture/stt-streaming-spec.md)，核心要求：

1. **`is_partial` 标记**：中间结果 `is_partial=True`，最终结果（VAD/用户停止）`is_partial=False`，服务端据此区分 `partial`/`final` 消息类型
2. **全文快照 yield**：每次 yield 的 `Transcription.text` 必须是完整文本快照（非增量片段），前端直接替换显示
3. **sender/receiver 并发模型**：使用 `_sender_stop` Event 协调、sender `ConnectionClosed` 容错、`send_task.cancel()` 防挂起、Queue sentinel `None` 保证退出
4. **前端自动停止**：收到 `final` 后自动停止录音释放麦克风，无需用户手动点击 Stop
5. **性能日志（里程碑计时）**：WS 连接耗时、首帧发送、首次响应（含协议元数据）、最终结果（含响应计数+文本预览）、流式完成总耗时
6. **批量模式帧间 pacing**：预录音频通过 WS 发送时需添加帧间延迟（~10ms），防止服务端读超时
7. **新增流式 STT Provider 时**，必须对照文档末尾的 Checklist 逐项确认

### field_options（下拉可选项）
每个 Provider 必须在类属性中定义 `field_options`，为所有枚举型参数提供完整的可选值列表。该属性被 Config 页面和 Lab 页面用于生成下拉选择框。

**规则：**
1. **所有具有固定可选值的 settings 字段**（如 model、voice、language、device、format 等）必须在 `field_options` 中列出
2. **布尔值、数值、自由文本字段**（如 speed、temperature、api_url）不需要列入
3. **Vendor 共享凭据字段**（如 api_key、api_secret）不应出现在 engine 的 `default_settings` 中，由 vendor 层注入
4. 新增或修改 Provider 时，必须同步更新 `field_options`，确保 UI 下拉选项与 API 文档一致
5. 定期检查各 Provider 的 `field_options` 是否与上游 API 保持同步

**示例：**
```python
class MyTTSProvider(TTSProvider):
    field_options = {
        "model": ["model-v1", "model-v2"],
        "voice": ["alice", "bob", "charlie"],
        "language": ["en-US", "zh-CN", "ja"],
    }
```

## 测试规范

### 核心要求

1. **UI E2E 测试（强制）**：所有界面功能必须具备从"前端页面操作"到"前端页面最终结果"的完整 E2E 测试用例
2. **GIVEN → WHEN → THEN → AND**：每个用例必须覆盖前置条件、页面操作、后端状态变更、前端结果验证
3. **新增/修改界面功能时必须同步新增/更新对应的 UI E2E 用例**

## 文档&同步规则

### 文档规范
**默认将项目过程和设计文档都存放于[docs/](docs/)目录下**

