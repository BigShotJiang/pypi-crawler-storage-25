#!/bin/bash
# 单次执行：杀死旧进程并重启 jar
# 用法: ./restart-jar.sh <jar文件路径>
# 示例: ./restart-jar.sh /Users/emile/Downloads/aibox-1.0.0-SNAPSHOT.jar

JAR_PATH="${1:?用法: $0 <jar文件路径>}"
STDOUT_LOG="${2:-/Users/emile/Downloads/aibox-script/aibox.log}"
LOG_FILE="${JAR_PATH%.*}-restart.log"

if [ ! -f "$JAR_PATH" ]; then
    echo "错误: jar 文件不存在: $JAR_PATH"
    exit 1
fi

JAR_NAME=$(basename "$JAR_PATH")
JAR_DIR=$(dirname "$JAR_PATH")

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# 杀死旧进程
pids=$(pgrep -f "$JAR_NAME")
if [ -n "$pids" ]; then
    log "发现进程 PID: $pids，正在终止..."
    kill $pids 2>/dev/null
    count=0
    while kill -0 $pids 2>/dev/null && [ $count -lt 10 ]; do
        sleep 1
        count=$((count + 1))
    done
    if kill -0 $pids 2>/dev/null; then
        log "进程未响应 SIGTERM，强制终止..."
        kill -9 $pids 2>/dev/null
    fi
    log "进程已终止"
else
    log "未发现运行中的 $JAR_NAME 进程"
fi

# 启动新进程
log "启动: java -jar $JAR_PATH"
cd "$JAR_DIR"
nohup java -jar "$JAR_PATH" >> "${JAR_PATH%.*}-stdout.log" 2>&1 &
log "进程已启动，PID: $!"
