"""End-to-end tests for OpenAI STT/TTS providers."""
import pytest

from tests.e2e.conftest import OPENAI_API_KEY, skip_no_openai
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, STTOptions
from openspeechapi.providers.stt.openai import OpenAISTT, OpenAISTTSettings
from openspeechapi.providers.tts.openai import OpenAITTS, OpenAITTSSettings


@skip_no_openai
class TestOpenAISTTE2E:
    @pytest.mark.asyncio
    async def test_transcribe_audio(self, sample_audio_data):
        stt = OpenAISTT(settings=OpenAISTTSettings(api_key=OPENAI_API_KEY))
        await stt.start()
        try:
            result = await stt.transcribe(sample_audio_data)
            assert result.text is not None
            assert len(result.text) > 0
        finally:
            await stt.stop()

    @pytest.mark.asyncio
    async def test_transcribe_with_language(self, sample_audio_data):
        stt = OpenAISTT(settings=OpenAISTTSettings(api_key=OPENAI_API_KEY))
        await stt.start()
        try:
            result = await stt.transcribe(sample_audio_data, STTOptions(language="en"))
            assert result.text is not None
            assert result.language == "en"
        finally:
            await stt.stop()


@skip_no_openai
class TestOpenAITTSE2E:
    @pytest.mark.asyncio
    async def test_synthesize_audio(self):
        tts = OpenAITTS(settings=OpenAITTSSettings(api_key=OPENAI_API_KEY))
        await tts.start()
        try:
            result = await tts.synthesize("Hello, this is a test.")
            assert isinstance(result, AudioData)
            assert len(result.data) > 0
        finally:
            await tts.stop()

    @pytest.mark.asyncio
    async def test_roundtrip_tts_then_stt(self):
        """Synthesize text, then transcribe it back — the crown jewel test."""
        tts = OpenAITTS(
            settings=OpenAITTSSettings(api_key=OPENAI_API_KEY, response_format="wav")
        )
        stt = OpenAISTT(settings=OpenAISTTSettings(api_key=OPENAI_API_KEY))
        await tts.start()
        await stt.start()
        try:
            audio = await tts.synthesize(
                "Hello world, this is a test of the speech system."
            )
            # Feed TTS output to STT
            transcription = await stt.transcribe(audio, STTOptions(language="en"))
            assert transcription.text is not None
            # Should contain key words (case insensitive)
            text_lower = transcription.text.lower()
            assert any(word in text_lower for word in ["hello", "test", "speech"])
        finally:
            await stt.stop()
            await tts.stop()

    @pytest.mark.asyncio
    async def test_stt_via_dispatcher(self, sample_audio_data, tmp_path):
        """Test OpenAI STT through the full ServiceDispatcher chain."""
        from textwrap import dedent

        from openspeechapi.core.registry import ProviderRegistry
        from openspeechapi.dispatch.dispatcher import ServiceDispatcher

        cfg = tmp_path / "providers.yaml"
        cfg.write_text(
            dedent(
                f"""\
            providers:
              openai:
                provider: openai-stt
                exec_mode: in_process
                settings:
                  api_key: {OPENAI_API_KEY}
        """
            )
        )

        registry = ProviderRegistry()
        registry.register("openai-stt", OpenAISTT)

        dispatcher = ServiceDispatcher.from_config(cfg, registry)
        await dispatcher.start()
        try:
            result = await dispatcher.stt.transcribe("openai", sample_audio_data)
            assert result is not None
            assert len(result.text) > 0
        finally:
            await dispatcher.stop()
