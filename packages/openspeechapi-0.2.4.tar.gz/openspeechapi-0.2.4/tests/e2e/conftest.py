"""E2E test configuration and shared fixtures."""
import os
from pathlib import Path

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData

# Skip conditions
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
HAS_OPENAI_KEY = bool(OPENAI_API_KEY)

try:
    import faster_whisper  # noqa: F401
    HAS_FASTER_WHISPER = True
except ImportError:
    HAS_FASTER_WHISPER = False

skip_no_openai = pytest.mark.skipif(not HAS_OPENAI_KEY, reason="OPENAI_API_KEY not set")
skip_no_faster_whisper = pytest.mark.skipif(
    not HAS_FASTER_WHISPER, reason="faster-whisper not installed"
)
skip_no_both = pytest.mark.skipif(
    not (HAS_OPENAI_KEY and HAS_FASTER_WHISPER),
    reason="Requires both OPENAI_API_KEY and faster-whisper",
)

FIXTURES_DIR = Path(__file__).parent.parent / "fixtures"


@pytest.fixture
def sample_audio_path():
    return FIXTURES_DIR / "hello.wav"


@pytest.fixture
def sample_audio_data(sample_audio_path):
    data = sample_audio_path.read_bytes()
    return AudioData(data=data, sample_rate=16000, channels=1, format=AudioFormat.WAV)
