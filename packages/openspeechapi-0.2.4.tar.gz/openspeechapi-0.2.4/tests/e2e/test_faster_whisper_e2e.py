"""End-to-end tests for faster-whisper STT provider."""
import pytest

from tests.e2e.conftest import skip_no_faster_whisper
from openspeechapi.core.models import Transcription
from openspeechapi.providers.stt.faster_whisper import FasterWhisperSTT, FasterWhisperSTTSettings


@skip_no_faster_whisper
class TestFasterWhisperE2E:
    @pytest.mark.asyncio
    async def test_transcribe_locally(self, sample_audio_data):
        """Direct provider test — runs in-process."""
        stt = FasterWhisperSTT(
            settings=FasterWhisperSTTSettings(model_size="tiny", device="auto")
        )
        await stt.start()
        try:
            result = await stt.transcribe(sample_audio_data)
            assert isinstance(result, Transcription)
            assert result.text is not None
            # For a tone WAV, text may be empty or contain hallucinated text - that's OK
            # The point is the flow works without errors
        finally:
            await stt.stop()

    @pytest.mark.asyncio
    @pytest.mark.timeout(120)
    async def test_via_subprocess_executor(self, sample_audio_data):
        """Critical test: validates subprocess IPC with real model."""
        from openspeechapi.dispatch.executors.subprocess_exec import SubprocessExecutor

        executor = SubprocessExecutor(restart_delay_s=0.5)
        await executor.start(
            FasterWhisperSTT, FasterWhisperSTTSettings(model_size="tiny", device="auto")
        )
        try:
            result = await executor.invoke("transcribe", audio=sample_audio_data)
            assert isinstance(result, Transcription)
            assert result.text is not None
        finally:
            await executor.stop()

    @pytest.mark.asyncio
    @pytest.mark.timeout(120)
    async def test_via_dispatcher(self, sample_audio_data, tmp_path):
        """Full config-driven flow with subprocess execution."""
        from textwrap import dedent

        from openspeechapi.core.registry import ProviderRegistry
        from openspeechapi.dispatch.dispatcher import ServiceDispatcher

        cfg = tmp_path / "providers.yaml"
        cfg.write_text(
            dedent(
                """\
            providers:
              local-stt:
                provider: faster-whisper
                exec_mode: subprocess
                settings:
                  model_size: tiny
                  device: auto
        """
            )
        )

        registry = ProviderRegistry()
        registry.register("faster-whisper", FasterWhisperSTT)

        dispatcher = ServiceDispatcher.from_config(cfg, registry)
        await dispatcher.start()
        try:
            result = await dispatcher.stt.transcribe("local-stt", sample_audio_data)
            assert result is not None
            assert isinstance(result, Transcription)
        finally:
            await dispatcher.stop()
