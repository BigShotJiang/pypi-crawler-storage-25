"""End-to-end fanout tests: OpenAI (cloud) + faster-whisper (local) concurrent dispatch."""
import os
from textwrap import dedent

import pytest

from tests.e2e.conftest import OPENAI_API_KEY, skip_no_both
from openspeechapi.core.models import Transcription
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.dispatch.fanout import CollectAll, FirstCompleted
from openspeechapi.observe.base import DispatchObserver
from openspeechapi.providers.stt.faster_whisper import FasterWhisperSTT
from openspeechapi.providers.stt.openai import OpenAISTT


@pytest.fixture
def fanout_dispatcher(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            f"""\
        providers:
          cloud-stt:
            provider: openai-stt
            exec_mode: in_process
            settings:
              api_key: {OPENAI_API_KEY}
          local-stt:
            provider: faster-whisper
            exec_mode: subprocess
            settings:
              model_size: tiny
              device: auto
    """
        )
    )
    registry = ProviderRegistry()
    registry.register("openai-stt", OpenAISTT)
    registry.register("faster-whisper", FasterWhisperSTT)
    return ServiceDispatcher.from_config(cfg, registry)


@skip_no_both
class TestFanOutE2E:
    @pytest.mark.asyncio
    @pytest.mark.timeout(120)
    async def test_first_completed(self, fanout_dispatcher, sample_audio_data):
        await fanout_dispatcher.start()
        try:
            result = await fanout_dispatcher.stt.fanout(
                ["cloud-stt", "local-stt"],
                sample_audio_data,
                strategy=FirstCompleted(),
            )
            assert isinstance(result, Transcription)
            assert result.text is not None
        finally:
            await fanout_dispatcher.stop()

    @pytest.mark.asyncio
    @pytest.mark.timeout(120)
    async def test_collect_all(self, fanout_dispatcher, sample_audio_data):
        await fanout_dispatcher.start()
        try:
            result = await fanout_dispatcher.stt.fanout(
                ["cloud-stt", "local-stt"],
                sample_audio_data,
                strategy=CollectAll(),
            )
            assert "cloud-stt" in result.successes
            assert "local-stt" in result.successes
            for name, transcription in result.successes.items():
                assert isinstance(transcription, Transcription)
        finally:
            await fanout_dispatcher.stop()

    @pytest.mark.asyncio
    @pytest.mark.timeout(120)
    async def test_with_observer(self, fanout_dispatcher, sample_audio_data):
        """Verify observer fires for both providers during real fanout."""
        invocations = []

        class TrackingObserver(DispatchObserver):
            async def on_invoke_start(self, ctx: InvokeContext) -> None:
                invocations.append(("start", ctx.provider_name))

            async def on_invoke_end(self, ctx: InvokeContext, result) -> None:
                invocations.append(("end", ctx.provider_name))

        fanout_dispatcher.add_observer(TrackingObserver())
        await fanout_dispatcher.start()
        try:
            await fanout_dispatcher.stt.fanout(
                ["cloud-stt", "local-stt"],
                sample_audio_data,
                strategy=CollectAll(),
            )
            # Observer should have seen start+end for both providers
            started = {name for action, name in invocations if action == "start"}
            ended = {name for action, name in invocations if action == "end"}
            assert "cloud-stt" in started or "local-stt" in started
        finally:
            await fanout_dispatcher.stop()
