"""UI E2E tests for WebUI capability flow."""
from __future__ import annotations

import socket
import threading
import time
from pathlib import Path
from textwrap import dedent
from urllib.request import urlopen

import pytest
import uvicorn

from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.server.app import create_app
from tests.conftest import FakeSTT, FakeTTS

try:
    from playwright.sync_api import sync_playwright

    HAS_PLAYWRIGHT = True
except Exception:
    HAS_PLAYWRIGHT = False


@pytest.mark.e2e
@pytest.mark.skipif(not HAS_PLAYWRIGHT, reason="playwright not installed")
def test_webui_tts_flow(tmp_path: Path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="lab"]')

            # GIVEN WebUI is loaded with fake providers
            expect_title = page.locator("h1")
            assert "Control Center" in expect_title.text_content()

            # WHEN user runs TTS from the page
            page.fill("#tts-text", "hello web ui")
            page.click("#tts-form button[type='submit']")

            # THEN frontend shows synthesis result
            page.wait_for_timeout(300)
            result = page.locator("#tts-result").text_content() or ""
            assert '"provider": "tts"' in result
            assert '"status": "done"' in result
            assert '"elapsed_ms":' in result

            # AND audio element is populated
            audio_src = page.locator("#tts-audio").get_attribute("src")
            assert audio_src is not None and len(audio_src) > 0
            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)


@pytest.mark.e2e
@pytest.mark.skip(reason="Engine Manager moved to Config page; engine-card elements removed")
def test_webui_engine_action_includes_native_root(tmp_path: Path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    captured: dict = {}
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()

            def _capture_engine_action(route, request):  # noqa: ANN001
                nonlocal captured
                captured = request.post_data_json or {}
                route.fulfill(
                    status=200,
                    content_type="application/json",
                    body=(
                        '{"task":{"task_id":"task-1","engine":"fish-speech","action":"start",'
                        '"runtime":"native","status":"queued","phase":"queued","progress":0,'
                        '"message":"queued","error":null,"started_at":"2026-01-01T00:00:00+00:00",'
                        '"updated_at":"2026-01-01T00:00:00+00:00","finished_at":null,"metadata":{}}}'
                    ),
                )

            page.route("**/v1/engines/actions", _capture_engine_action)
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="engines"]')

            # GIVEN native root field is visible with default value
            assert page.locator("#engine-install-dir").input_value() == "~/AI/services"

            # WHEN user triggers native start with a custom root
            page.select_option("#engine-runtime", "native")
            page.fill("#engine-install-dir", "~/AI/services-custom")
            page.click("button[data-action='start']")
            page.wait_for_timeout(300)

            # THEN request payload includes configured install_dir
            assert captured.get("runtime") == "native"
            assert captured.get("install_dir") == "~/AI/services-custom"
            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)


@pytest.mark.e2e
@pytest.mark.skipif(not HAS_PLAYWRIGHT, reason="playwright not installed")
def test_webui_stt_advanced_options_sent(tmp_path: Path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    captured_body = ""
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()

            def _capture_stt(route, request):  # noqa: ANN001
                nonlocal captured_body
                captured_body = request.post_data or ""
                route.fulfill(
                    status=200,
                    content_type="application/json",
                    body='{"text":"ok","language":"en","confidence":0.9,"words":[],"duration_ms":10,"provider":"stt"}',
                )

            page.route("**/v1/stt/transcribe", _capture_stt)
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="lab"]')
            page.fill("#stt-language", "en")
            # Open advanced options panel
            page.click(".lab-advanced summary")
            page.fill("#stt-model", "large-v3-turbo")
            page.fill("#stt-device", "mps")
            page.fill("#stt-beam-size", "8")
            page.set_input_files("#stt-file", {"name": "sample.wav", "mimeType": "audio/wav", "buffer": b"RIFF0000"})
            page.click("#stt-form button[type='submit']")
            page.wait_for_timeout(300)

            assert "name=\"language\"" in captured_body
            assert "name=\"model\"" in captured_body
            assert "name=\"device\"" in captured_body
            assert "name=\"beam_size\"" in captured_body
            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)


@pytest.mark.e2e
@pytest.mark.skipif(not HAS_PLAYWRIGHT, reason="playwright not installed")
def test_webui_stt_file_transcribe_e2e(tmp_path: Path):
    """E2E: upload a real WAV file via WebUI STT form → verify transcription result displayed."""
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    wav_path = Path(__file__).resolve().parents[1] / "fixtures" / "hello.wav"
    assert wav_path.exists(), f"Test fixture missing: {wav_path}"

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="lab"]')

            # GIVEN WebUI is loaded and STT form is visible in file mode
            assert page.locator("#stt-form").is_visible()
            assert page.locator("#stt-file").is_visible()

            # WHEN user uploads a real WAV audio file and submits the STT form
            page.set_input_files("#stt-file", str(wav_path))
            page.click("#stt-form button[type='submit']")

            # THEN the STT result area shows transcription output from the fake provider
            page.wait_for_function(
                'document.querySelector("#stt-result").textContent.includes("fake transcription")',
                timeout=5000,
            )
            result_text = page.locator("#stt-result").text_content() or ""
            assert "fake transcription" in result_text

            # AND result contains provider metadata
            assert '"provider"' in result_text

            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)


@pytest.mark.e2e
@pytest.mark.skipif(not HAS_PLAYWRIGHT, reason="playwright not installed")
def test_webui_stt_file_error_displayed(tmp_path: Path):
    """E2E: STT provider failure → error message displayed in WebUI."""
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings:
                  fail: true
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    wav_path = Path(__file__).resolve().parents[1] / "fixtures" / "hello.wav"

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="lab"]')

            # GIVEN STT provider is configured to fail
            # WHEN user uploads audio and submits
            page.set_input_files("#stt-file", str(wav_path))
            page.click("#stt-form button[type='submit']")

            # THEN the result area shows an error message (502 from the provider failure)
            page.wait_for_function(
                '(() => { const t = document.querySelector("#stt-result").textContent; return t.includes("error") || t.includes("failed") || t.includes("Error"); })()',
                timeout=5000,
            )
            result_text = page.locator("#stt-result").text_content() or ""
            assert "failed" in result_text.lower() or "error" in result_text.lower()

            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)


@pytest.mark.e2e
@pytest.mark.skipif(not HAS_PLAYWRIGHT, reason="playwright not installed")
def test_webui_stt_file_upload_various_formats(tmp_path: Path):
    """E2E: WebUI STT form successfully submits with different audio MIME types."""
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    captured_requests: list[str] = []
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()

            def _capture_stt(route, request):  # noqa: ANN001
                captured_requests.append(request.post_data or "")
                route.fulfill(
                    status=200,
                    content_type="application/json",
                    body='{"text":"fake transcription","language":"en","confidence":0.9,"words":[],"duration_ms":10,"provider":"stt"}',
                )

            page.route("**/v1/stt/transcribe", _capture_stt)
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="lab"]')

            # GIVEN WebUI is loaded with fake providers
            formats = [
                {"name": "test.mp3", "mimeType": "audio/mpeg", "buffer": b"ID3fake"},
                {"name": "test.ogg", "mimeType": "audio/ogg", "buffer": b"OggSfake"},
                {"name": "test.flac", "mimeType": "audio/flac", "buffer": b"fLaCfake"},
            ]

            for fmt in formats:
                # WHEN user uploads a file of each format and submits
                page.set_input_files("#stt-file", fmt)
                page.click("#stt-form button[type='submit']")

                # THEN the STT result area shows the fake transcription
                page.wait_for_function(
                    'document.querySelector("#stt-result").textContent.includes("fake transcription")',
                    timeout=5000,
                )
                result_text = page.locator("#stt-result").text_content() or ""
                assert "fake transcription" in result_text

            # AND all three requests were captured
            assert len(captured_requests) == 3

            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)


@pytest.mark.e2e
@pytest.mark.skipif(not HAS_PLAYWRIGHT, reason="playwright not installed")
def test_webui_stt_no_file_submit_blocked(tmp_path: Path):
    """E2E: submitting the STT form without selecting a file is blocked by HTML5 validation."""
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="lab"]')

            # GIVEN WebUI is loaded and no file is selected
            assert page.locator("#stt-form").is_visible()

            # WHEN user clicks submit without selecting a file
            page.click("#stt-form button[type='submit']")
            page.wait_for_timeout(300)

            # THEN the result area remains empty (HTML5 required validation blocks submission)
            result_text = page.locator("#stt-result").text_content() or ""
            assert result_text.strip() == ""

            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)


@pytest.mark.e2e
@pytest.mark.skipif(not HAS_PLAYWRIGHT, reason="playwright not installed")
def test_webui_live_stt_ws_flow(tmp_path: Path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(
        dedent(
            """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
            """
        )
    )
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = uvicorn.Server(uvicorn.Config(app=app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with urlopen(f"{base}/ui", timeout=1):
                break
        except Exception:
            time.sleep(0.1)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.add_init_script(
                """
                (() => {
                  const AC = window.AudioContext || window.webkitAudioContext;
                  navigator.mediaDevices = navigator.mediaDevices || {};
                  navigator.mediaDevices.getUserMedia = async () => {
                    const ctx = new AC();
                    const dst = ctx.createMediaStreamDestination();
                    const osc = ctx.createOscillator();
                    osc.connect(dst);
                    osc.start();
                    return dst.stream;
                  };

                  class FakeWebSocket {
                    static CONNECTING = 0;
                    static OPEN = 1;
                    static CLOSING = 2;
                    static CLOSED = 3;
                    constructor(url) {
                      this.url = url;
                      this.readyState = FakeWebSocket.CONNECTING;
                      setTimeout(() => {
                        this.readyState = FakeWebSocket.OPEN;
                        if (this.onopen) this.onopen();
                      }, 20);
                    }
                    send(data) {
                      if (typeof data === "string") {
                        try {
                          const msg = JSON.parse(data);
                          if (msg.type === "stop") {
                            setTimeout(() => {
                              if (this.onmessage) this.onmessage({ data: JSON.stringify({ type: "closed" }) });
                              this.readyState = FakeWebSocket.CLOSED;
                              if (this.onclose) this.onclose({});
                            }, 20);
                          }
                        } catch (_) {}
                        return;
                      }
                      if (!this._emittedPartial && data instanceof ArrayBuffer) {
                        this._emittedPartial = true;
                        setTimeout(() => {
                          if (this.onmessage) {
                            this.onmessage({ data: JSON.stringify({ type: "partial", text: "hello from ws", language: "en" }) });
                          }
                        }, 20);
                      }
                    }
                    close() {
                      this.readyState = FakeWebSocket.CLOSED;
                      if (this.onclose) this.onclose({});
                    }
                  }
                  window.WebSocket = FakeWebSocket;
                })();
                """
            )
            page.goto(f"{base}/ui", wait_until="networkidle")
            page.click('.tab-btn[data-tab="lab"]')

            # GIVEN live mode selected
            page.select_option("#stt-mode", "live")
            page.wait_for_timeout(100)

            # WHEN user starts live STT
            page.click("#stt-live-start")
            page.wait_for_timeout(500)

            # THEN page receives incremental text from WS stream
            stream_text = page.locator("#stt-stream-text").text_content() or ""
            assert "hello from ws" in stream_text

            # AND result includes WS transport metadata
            result = page.locator("#stt-result").text_content() or ""
            assert '"transport": "ws"' in result

            # WHEN user stops live STT
            page.click("#stt-live-stop")
            page.wait_for_timeout(200)

            # THEN live status reaches stopped
            status = (page.locator("#stt-live-status").text_content() or "").strip().lower()
            assert status == "stopped"
            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=5)
