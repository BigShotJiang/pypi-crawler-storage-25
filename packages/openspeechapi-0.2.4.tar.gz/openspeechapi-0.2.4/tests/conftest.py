"""Shared test fixtures for OpenSpeechAPI tests."""
from __future__ import annotations
from dataclasses import dataclass
from openspeechapi.core.base import STTProvider, TTSProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, STTOptions, TTSOptions, Transcription
from openspeechapi.core.settings import BaseSettings


@dataclass
class FakeSTTSettings(BaseSettings):
    model_size: str = "tiny"
    fail: bool = False


class FakeSTT(STTProvider):
    name = "fake-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = FakeSTTSettings
    capabilities = {Capability.BATCH}

    def __init__(self, settings: FakeSTTSettings | None = None):
        self.settings = settings or FakeSTTSettings()
        self._started = False

    async def start(self) -> None:
        self._started = True

    async def stop(self) -> None:
        self._started = False

    async def health_check(self) -> bool:
        return self._started

    async def transcribe(self, audio: AudioData, opts: STTOptions | None = None) -> Transcription:
        if self.settings.fail:
            raise RuntimeError("Fake STT error")
        return Transcription(text="fake transcription", confidence=0.95, language="en")

    async def transcribe_stream(self, stream):
        yield Transcription(text="chunk1")
        yield Transcription(text="chunk2")


@dataclass
class FakeTTSSettings(BaseSettings):
    voice: str = "default"


class FakeTTS(TTSProvider):
    name = "fake-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = FakeTTSSettings
    capabilities = {Capability.STREAMING}

    def __init__(self, settings: FakeTTSSettings | None = None):
        self.settings = settings or FakeTTSSettings()
        self._started = False

    async def start(self) -> None:
        self._started = True

    async def stop(self) -> None:
        self._started = False

    async def health_check(self) -> bool:
        return self._started

    async def synthesize(self, text: str, opts: TTSOptions | None = None) -> AudioData:
        return AudioData(data=b"fake_audio", sample_rate=16000, channels=1,
                        format=AudioFormat.PCM_16K, duration_ms=100)

    async def synthesize_stream(self, text: str, opts: TTSOptions | None = None):
        yield AudioChunk(data=b"chunk1", sequence=0)
        yield AudioChunk(data=b"chunk2", sequence=1, is_final=True)
