"""Tests for openspeechapi.dispatch.dispatcher — ServiceDispatcher."""
from __future__ import annotations
import pytest
from openspeechapi.core.enums import AudioFormat, ExecMode
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.exceptions import ProviderNotFoundError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def registry(fake_stt_cls, fake_tts_cls):
    """A registry pre-loaded with FakeSTT and FakeTTS."""
    reg = ProviderRegistry()
    reg.register("fake-stt", fake_stt_cls)
    reg.register("fake-tts", fake_tts_cls)
    return reg


@pytest.fixture()
def fake_stt_cls(request):
    """Return FakeSTT class from conftest via the fixture."""
    from tests.conftest import FakeSTT
    return FakeSTT


@pytest.fixture()
def fake_tts_cls(request):
    from tests.conftest import FakeTTS
    return FakeTTS


@pytest.fixture()
def config_yaml(tmp_path):
    """Write a minimal providers YAML and return its path."""
    content = """\
providers:
  stt1:
    provider: fake-stt
    exec_mode: in_process
    settings:
      model_size: tiny
  tts1:
    provider: fake-tts
    exec_mode: in_process
    settings:
      voice: default
"""
    p = tmp_path / "providers.yaml"
    p.write_text(content)
    return p


@pytest.fixture()
def audio_data():
    return AudioData(data=b"audio", sample_rate=16000, channels=1,
                     format=AudioFormat.PCM_16K, duration_ms=500)


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestServiceDispatcherCreation:
    def test_from_config_creates_dispatcher(self, config_yaml, registry):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        assert dispatcher is not None

    def test_list_engines_returns_configured_names(self, config_yaml, registry):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        engines = dispatcher.list_engines()
        assert "stt1" in engines
        assert "tts1" in engines

    def test_unknown_provider_in_config_raises(self, tmp_path, registry):
        content = """\
providers:
  ghost:
    provider: nonexistent-provider
    exec_mode: in_process
    settings: {}
"""
        p = tmp_path / "bad.yaml"
        p.write_text(content)
        with pytest.raises(ProviderNotFoundError):
            ServiceDispatcher.from_config(p, registry)

    def test_legacy_in_process_maps_to_remote_for_non_fish(self, config_yaml, registry):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        assert dispatcher._handles["stt1"].exec_mode == ExecMode.REMOTE
        assert dispatcher._handles["tts1"].exec_mode == ExecMode.REMOTE

    def test_legacy_in_process_maps_to_local_for_fish_speech(self, tmp_path, registry):
        content = """\
providers:
  tts_fish:
    provider: fish-speech
    exec_mode: in_process
    settings:
      api_url: http://127.0.0.1:8080
"""
        p = tmp_path / "fish.yaml"
        p.write_text(content)
        from openspeechapi.providers.tts.fish_speech import FishSpeechTTS

        registry.register("fish-speech", FishSpeechTTS)
        dispatcher = ServiceDispatcher.from_config(p, registry)
        assert dispatcher._handles["tts_fish"].exec_mode == ExecMode.LOCAL


# ---------------------------------------------------------------------------
# STT transcribe
# ---------------------------------------------------------------------------

class TestServiceDispatcherSTT:
    @pytest.mark.asyncio
    async def test_transcribe_returns_transcription(self, config_yaml, registry, audio_data):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        await dispatcher.start()
        try:
            result = await dispatcher.stt.transcribe("stt1", audio_data)
            assert isinstance(result, Transcription)
            assert result.text == "fake transcription"
        finally:
            await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_transcribe_unknown_provider_raises(self, config_yaml, registry, audio_data):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        await dispatcher.start()
        try:
            with pytest.raises(ProviderNotFoundError):
                await dispatcher.stt.transcribe("nonexistent", audio_data)
        finally:
            await dispatcher.stop()


# ---------------------------------------------------------------------------
# TTS synthesize
# ---------------------------------------------------------------------------

class TestServiceDispatcherTTS:
    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self, config_yaml, registry):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        await dispatcher.start()
        try:
            result = await dispatcher.tts.synthesize("tts1", "hello world")
            assert isinstance(result, AudioData)
            assert result.data == b"fake_audio"
        finally:
            await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_synthesize_unknown_provider_raises(self, config_yaml, registry):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        await dispatcher.start()
        try:
            with pytest.raises(ProviderNotFoundError):
                await dispatcher.tts.synthesize("nonexistent", "text")
        finally:
            await dispatcher.stop()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

class TestServiceDispatcherHealth:
    @pytest.mark.asyncio
    async def test_health_returns_true_after_use(self, config_yaml, registry, audio_data):
        """Providers become healthy after first use (lazy start)."""
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        await dispatcher.start()
        try:
            # Trigger lazy start via actual use
            await dispatcher.stt.transcribe("stt1", audio_data)
            await dispatcher.tts.synthesize("tts1", "hello")
            health = await dispatcher.health()
            assert isinstance(health, dict)
            assert health.get("stt1") is True
            assert health.get("tts1") is True
        finally:
            await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_health_before_use_returns_false(self, config_yaml, registry):
        """Lazy providers are not started yet, so health returns False."""
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        await dispatcher.start()
        try:
            health = await dispatcher.health()
            for v in health.values():
                assert v is False
        finally:
            await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_health_before_start_returns_false(self, config_yaml, registry):
        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        health = await dispatcher.health()
        for v in health.values():
            assert v is False


# ---------------------------------------------------------------------------
# FanOut transcribe
# ---------------------------------------------------------------------------

class TestServiceDispatcherFanOut:
    @pytest.fixture()
    def multi_stt_yaml(self, tmp_path):
        content = """\
providers:
  stt1:
    provider: fake-stt
    exec_mode: in_process
    settings:
      model_size: tiny
  stt2:
    provider: fake-stt
    exec_mode: in_process
    settings:
      model_size: small
"""
        p = tmp_path / "multi.yaml"
        p.write_text(content)
        return p

    @pytest.mark.asyncio
    async def test_fanout_transcribe_returns_result(self, multi_stt_yaml, registry, audio_data):
        dispatcher = ServiceDispatcher.from_config(multi_stt_yaml, registry)
        await dispatcher.start()
        try:
            result = await dispatcher.stt.fanout(["stt1", "stt2"], audio_data)
            # Default strategy is FirstCompleted — returns a Transcription
            assert isinstance(result, Transcription)
        finally:
            await dispatcher.stop()


# ---------------------------------------------------------------------------
# Observer management
# ---------------------------------------------------------------------------

class TestObserverManagement:
    def test_add_and_remove_observer(self, config_yaml, registry):
        from openspeechapi.observe.base import DispatchObserver

        class _Obs(DispatchObserver):
            pass

        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        observer = _Obs()
        dispatcher.add_observer(observer)
        assert observer in dispatcher._observer_mgr.list()
        dispatcher.remove_observer(observer)
        assert observer not in dispatcher._observer_mgr.list()

    def test_remove_nonexistent_observer_is_noop(self, config_yaml, registry):
        from openspeechapi.observe.base import DispatchObserver

        class _Obs(DispatchObserver):
            pass

        dispatcher = ServiceDispatcher.from_config(config_yaml, registry)
        dispatcher.remove_observer(_Obs())  # Should not raise
