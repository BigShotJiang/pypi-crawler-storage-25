"""Tests for openspeechapi.observe.latency — LatencyObserver."""
from __future__ import annotations
import pytest
from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.latency import LatencyObserver


def _make_ctx() -> InvokeContext:
    return InvokeContext(provider_name="stt1", method="transcribe", exec_mode=ExecMode.IN_PROCESS)


class TestLatencyObserverSamples:
    @pytest.mark.asyncio
    async def test_records_total_ms(self):
        obs = LatencyObserver()
        ctx = _make_ctx()
        ctx.record_end()
        await obs.on_invoke_end(ctx, result=None)
        assert len(obs.total_ms) == 1
        assert obs.total_ms[0] >= 0.0

    @pytest.mark.asyncio
    async def test_records_multiple_total_ms_samples(self):
        obs = LatencyObserver()
        for _ in range(4):
            ctx = _make_ctx()
            ctx.record_end()
            await obs.on_invoke_end(ctx, result=None)
        assert len(obs.total_ms) == 4

    @pytest.mark.asyncio
    async def test_records_ttfb_when_present(self):
        obs = LatencyObserver()
        ctx = _make_ctx()
        ctx.record_ttfb()
        ctx.record_end()
        await obs.on_invoke_end(ctx, result=None)
        assert len(obs.ttfb_ms) == 1
        assert obs.ttfb_ms[0] >= 0.0

    @pytest.mark.asyncio
    async def test_no_ttfb_when_not_recorded(self):
        obs = LatencyObserver()
        ctx = _make_ctx()
        ctx.record_end()
        await obs.on_invoke_end(ctx, result=None)
        assert len(obs.ttfb_ms) == 0

    @pytest.mark.asyncio
    async def test_accumulates_mixed_ttfb_samples(self):
        obs = LatencyObserver()
        # ctx1 without TTFB
        ctx1 = _make_ctx()
        ctx1.record_end()
        await obs.on_invoke_end(ctx1, result=None)
        # ctx2 with TTFB
        ctx2 = _make_ctx()
        ctx2.record_ttfb()
        ctx2.record_end()
        await obs.on_invoke_end(ctx2, result=None)
        assert len(obs.total_ms) == 2
        assert len(obs.ttfb_ms) == 1
