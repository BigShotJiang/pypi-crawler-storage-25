"""Tests for openspeechapi.utils.audio_converter.AudioConverter."""
from __future__ import annotations

import io
import struct
import wave
from unittest import mock

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData
from openspeechapi.utils.audio_converter import AudioConverter


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _make_pcm(sample_rate: int = 16000, channels: int = 1, n_frames: int = 160) -> bytes:
    """Generate silent 16-bit PCM frames."""
    return b"\x00\x00" * n_frames * channels


def _make_wav(sample_rate: int = 16000, channels: int = 1, n_frames: int = 160) -> bytes:
    """Generate a minimal WAV file with silence."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"\x00\x00" * n_frames * channels)
    return buf.getvalue()


def _float_to_extended(value: float) -> bytes:
    """Encode a float as 80-bit IEEE 754 extended (big-endian) for AIFF COMM."""
    if value == 0:
        return b"\x00" * 10
    import math
    sign = 0
    if value < 0:
        sign = 1
        value = -value
    exp = int(math.floor(math.log2(value)))
    mantissa = int((value / (2 ** exp)) * (1 << 63))
    exp_biased = exp + 16383
    result = bytearray(10)
    result[0] = (sign << 7) | ((exp_biased >> 8) & 0x7F)
    result[1] = exp_biased & 0xFF
    for i in range(2, 10):
        result[i] = (mantissa >> (8 * (9 - i))) & 0xFF
    return bytes(result)


def _make_aiff(sample_rate: int = 16000, channels: int = 1, n_frames: int = 160) -> bytes:
    """Generate a minimal AIFF file with silence (big-endian 16-bit)."""
    # Build COMM chunk
    sample_size = 16  # bits
    rate_ext = _float_to_extended(float(sample_rate))
    comm_data = struct.pack(">hIh", channels, n_frames, sample_size) + rate_ext
    comm_chunk = b"COMM" + struct.pack(">I", len(comm_data)) + comm_data

    # Build SSND chunk (offset=0, blockSize=0, then sample data)
    sample_data = b"\x00\x00" * n_frames * channels  # big-endian silence is same as LE
    ssnd_data = struct.pack(">II", 0, 0) + sample_data
    ssnd_chunk = b"SSND" + struct.pack(">I", len(ssnd_data)) + ssnd_data

    # Build FORM container
    body = b"AIFF" + comm_chunk + ssnd_chunk
    return b"FORM" + struct.pack(">I", len(body)) + body


# ---------------------------------------------------------------------------
# Format detection
# ---------------------------------------------------------------------------

class TestDetectFormat:
    def test_wav(self):
        data = _make_wav()
        assert AudioConverter.detect_format(data) == AudioFormat.WAV

    def test_aiff(self):
        data = _make_aiff()
        assert AudioConverter.detect_format(data) == AudioFormat.AIFF

    def test_flac(self):
        data = b"fLaC" + b"\x00" * 100
        assert AudioConverter.detect_format(data) == AudioFormat.FLAC

    def test_ogg(self):
        data = b"OggS" + b"\x00" * 100
        assert AudioConverter.detect_format(data) == AudioFormat.OGG

    def test_mp3_id3(self):
        data = b"ID3" + b"\x00" * 100
        assert AudioConverter.detect_format(data) == AudioFormat.MP3

    def test_mp3_sync(self):
        data = bytes([0xFF, 0xFB]) + b"\x00" * 100
        assert AudioConverter.detect_format(data) == AudioFormat.MP3

    def test_unknown_defaults_to_pcm(self):
        data = b"\x00\x01\x02\x03" * 10
        assert AudioConverter.detect_format(data) == AudioFormat.PCM_16K

    def test_empty_data(self):
        assert AudioConverter.detect_format(b"") == AudioFormat.PCM_16K


# ---------------------------------------------------------------------------
# to_wav
# ---------------------------------------------------------------------------

class TestToWav:
    def test_wav_passthrough(self):
        wav_data = _make_wav()
        audio = AudioData(data=wav_data, sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = AudioConverter.to_wav(audio)
        assert result.format == AudioFormat.WAV
        assert result.data[:4] == b"RIFF"

    def test_pcm_to_wav(self):
        pcm = _make_pcm(16000, 1, 160)
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = AudioConverter.to_wav(audio)
        assert result.format == AudioFormat.WAV
        assert result.data[:4] == b"RIFF"
        assert result.sample_rate == 16000

    def test_aiff_to_wav(self):
        aiff_data = _make_aiff(16000, 1, 160)
        audio = AudioData(data=aiff_data, sample_rate=16000, channels=1, format=AudioFormat.AIFF)
        result = AudioConverter.to_wav(audio)
        assert result.format == AudioFormat.WAV
        assert result.sample_rate == 16000

    def test_pcm_to_wav_with_resample(self):
        pcm = _make_pcm(44100, 1, 441)
        audio = AudioData(data=pcm, sample_rate=44100, channels=1, format=AudioFormat.PCM_44K)
        result = AudioConverter.to_wav(audio, target_rate=16000)
        assert result.format == AudioFormat.WAV
        assert result.sample_rate == 16000

    def test_wav_stereo_to_mono(self):
        wav_data = _make_wav(16000, 2, 160)
        audio = AudioData(data=wav_data, sample_rate=16000, channels=2, format=AudioFormat.WAV)
        result = AudioConverter.to_wav(audio, target_channels=1)
        assert result.channels == 1


# ---------------------------------------------------------------------------
# resample
# ---------------------------------------------------------------------------

class TestResample:
    def test_same_rate_passthrough(self):
        pcm = _make_pcm(16000, 1, 160)
        result = AudioConverter.resample(pcm, 16000, 16000)
        assert result == pcm

    def test_downsample(self):
        # 441 frames at 44100 Hz -> ~160 frames at 16000 Hz
        n = 441
        pcm = struct.pack(f"<{n}h", *([1000] * n))
        result = AudioConverter.resample(pcm, 44100, 16000)
        out_samples = len(result) // 2
        expected = int(n * 16000 / 44100)
        assert out_samples == expected

    def test_upsample(self):
        n = 160
        pcm = struct.pack(f"<{n}h", *([500] * n))
        result = AudioConverter.resample(pcm, 16000, 44100)
        out_samples = len(result) // 2
        expected = int(n * 44100 / 16000)
        assert out_samples == expected


# ---------------------------------------------------------------------------
# mix_to_mono
# ---------------------------------------------------------------------------

class TestMixToMono:
    def test_mono_passthrough(self):
        pcm = _make_pcm(16000, 1, 160)
        result = AudioConverter.mix_to_mono(pcm, 1)
        assert result == pcm

    def test_stereo_to_mono(self):
        # Two channels: L=1000, R=3000 -> mono=2000
        frames = 4
        interleaved = []
        for _ in range(frames):
            interleaved.extend([1000, 3000])
        pcm = struct.pack(f"<{frames * 2}h", *interleaved)
        result = AudioConverter.mix_to_mono(pcm, 2)
        out = struct.unpack(f"<{frames}h", result)
        assert all(s == 2000 for s in out)


# ---------------------------------------------------------------------------
# to_pcm16k
# ---------------------------------------------------------------------------

class TestToPcm16k:
    def test_passthrough(self):
        pcm = _make_pcm(16000, 1, 160)
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = AudioConverter.to_pcm16k(audio)
        assert result is audio

    def test_wav_to_pcm16k(self):
        wav_data = _make_wav(44100, 1, 441)
        audio = AudioData(data=wav_data, sample_rate=44100, channels=1, format=AudioFormat.WAV)
        result = AudioConverter.to_pcm16k(audio)
        assert result.format == AudioFormat.PCM_16K
        assert result.sample_rate == 16000
        assert result.channels == 1


# ---------------------------------------------------------------------------
# convert
# ---------------------------------------------------------------------------

class TestConvert:
    def test_same_format_passthrough(self):
        pcm = _make_pcm()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = AudioConverter.convert(audio, AudioFormat.PCM_16K)
        assert result is audio

    def test_pcm_to_wav(self):
        pcm = _make_pcm()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = AudioConverter.convert(audio, AudioFormat.WAV)
        assert result.format == AudioFormat.WAV

    def test_wav_to_pcm16k(self):
        wav = _make_wav()
        audio = AudioData(data=wav, sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = AudioConverter.convert(audio, AudioFormat.PCM_16K)
        assert result.format == AudioFormat.PCM_16K


# ---------------------------------------------------------------------------
# ffmpeg_available
# ---------------------------------------------------------------------------

class TestFfmpegAvailable:
    def test_ffmpeg_found(self):
        with mock.patch("shutil.which", return_value="/usr/bin/ffmpeg"):
            assert AudioConverter.ffmpeg_available() is True

    def test_ffmpeg_not_found(self):
        with mock.patch("shutil.which", return_value=None):
            assert AudioConverter.ffmpeg_available() is False


# ---------------------------------------------------------------------------
# convert to ffmpeg-dependent format without ffmpeg
# ---------------------------------------------------------------------------

class TestFfmpegRequired:
    def test_convert_to_mp3_without_ffmpeg_raises(self):
        pcm = _make_pcm()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        with mock.patch("shutil.which", return_value=None):
            with pytest.raises(RuntimeError, match="ffmpeg"):
                AudioConverter.convert(audio, AudioFormat.MP3)

    def test_convert_to_ogg_without_ffmpeg_raises(self):
        pcm = _make_pcm()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        with mock.patch("shutil.which", return_value=None):
            with pytest.raises(RuntimeError, match="ffmpeg"):
                AudioConverter.convert(audio, AudioFormat.OGG)

    def test_convert_to_flac_without_ffmpeg_raises(self):
        pcm = _make_pcm()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        with mock.patch("shutil.which", return_value=None):
            with pytest.raises(RuntimeError, match="ffmpeg"):
                AudioConverter.convert(audio, AudioFormat.FLAC)


# ---------------------------------------------------------------------------
# convert_stream (reserved)
# ---------------------------------------------------------------------------

class TestConvertStream:
    def test_raises_not_implemented(self):
        pcm = _make_pcm()
        audio = AudioData(data=pcm, sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        with pytest.raises(NotImplementedError):
            AudioConverter.convert_stream(audio, AudioFormat.WAV)
