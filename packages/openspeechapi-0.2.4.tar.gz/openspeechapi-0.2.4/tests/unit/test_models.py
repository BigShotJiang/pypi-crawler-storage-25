"""Tests for core data models."""
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import (
    AudioChunk,
    AudioData,
    STTOptions,
    TTSOptions,
    Transcription,
    Word,
)


class TestAudioData:
    def test_create_with_required_fields(self):
        audio = AudioData(data=b"raw", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        assert audio.data == b"raw"
        assert audio.sample_rate == 16000
        assert audio.channels == 1
        assert audio.format == AudioFormat.PCM_16K
        assert audio.duration_ms is None

    def test_create_with_duration(self):
        audio = AudioData(
            data=b"raw", sample_rate=16000, channels=1,
            format=AudioFormat.WAV, duration_ms=1500,
        )
        assert audio.duration_ms == 1500


class TestTranscription:
    def test_create_minimal(self):
        t = Transcription(text="hello")
        assert t.text == "hello"
        assert t.language is None
        assert t.confidence is None
        assert t.words is None
        assert t.duration_ms is None

    def test_create_full(self):
        words = [Word(text="hello", start_ms=0, end_ms=500, confidence=0.99)]
        t = Transcription(
            text="hello", language="en", confidence=0.95,
            words=words, duration_ms=500,
        )
        assert t.language == "en"
        assert len(t.words) == 1
        assert t.words[0].text == "hello"


class TestWord:
    def test_create(self):
        w = Word(text="hi", start_ms=0, end_ms=200, confidence=0.9)
        assert w.text == "hi"
        assert w.start_ms == 0
        assert w.end_ms == 200


class TestSTTOptions:
    def test_defaults(self):
        opts = STTOptions()
        assert opts.language is None
        assert opts.prompt is None
        assert opts.temperature is None

    def test_custom(self):
        opts = STTOptions(language="zh", temperature=0.2)
        assert opts.language == "zh"
        assert opts.temperature == 0.2


class TestTTSOptions:
    def test_defaults(self):
        opts = TTSOptions()
        assert opts.voice is None
        assert opts.speed == 1.0
        assert opts.output_format == AudioFormat.PCM_16K

    def test_custom(self):
        opts = TTSOptions(voice="Rachel", speed=1.5, output_format=AudioFormat.MP3)
        assert opts.voice == "Rachel"
        assert opts.speed == 1.5


class TestAudioChunk:
    def test_create(self):
        chunk = AudioChunk(data=b"chunk", sequence=0)
        assert chunk.data == b"chunk"
        assert chunk.sequence == 0
        assert chunk.is_final is False

    def test_final_chunk(self):
        chunk = AudioChunk(data=b"", sequence=5, is_final=True)
        assert chunk.is_final is True
