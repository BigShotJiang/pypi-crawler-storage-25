"""Tests for SubprocessExecutor.

These tests are inherently slower due to process spawning.
"""
from __future__ import annotations

import asyncio
import pytest

from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.core.enums import AudioFormat
from openspeechapi.dispatch.executors.subprocess_exec import SubprocessExecutor
from tests.conftest import FakeSTT, FakeSTTSettings, FakeTTS, FakeTTSSettings


@pytest.mark.asyncio
async def test_start_and_invoke():
    """start() + invoke() can call a provider method in the subprocess."""
    executor = SubprocessExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())

    audio = AudioData(data=b"audio", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
    result = await executor.invoke("transcribe", audio=audio)

    assert isinstance(result, Transcription)
    assert result.text == "fake transcription"
    assert result.confidence == pytest.approx(0.95)
    await executor.stop()


@pytest.mark.asyncio
async def test_health_check_after_start():
    """health_check() returns True when the worker is running."""
    executor = SubprocessExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())
    assert await executor.health_check() is True
    await executor.stop()


@pytest.mark.asyncio
async def test_health_check_before_start():
    """health_check() returns False before start."""
    executor = SubprocessExecutor()
    assert await executor.health_check() is False


@pytest.mark.asyncio
async def test_health_check_after_stop():
    """health_check() returns False after stop."""
    executor = SubprocessExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())
    await executor.stop()
    assert await executor.health_check() is False


@pytest.mark.asyncio
async def test_invoke_stream():
    """invoke_stream() streams chunks from the subprocess provider."""
    executor = SubprocessExecutor()
    await executor.start(FakeTTS, FakeTTSSettings())

    chunks = []
    async for chunk in executor.invoke_stream("synthesize_stream", text="hello"):
        chunks.append(chunk)

    assert len(chunks) == 2
    assert chunks[0].data == b"chunk1"
    assert chunks[1].data == b"chunk2"
    assert chunks[1].is_final is True
    await executor.stop()


@pytest.mark.asyncio
async def test_invoke_before_start_raises():
    """invoke() before start() raises RuntimeError."""
    executor = SubprocessExecutor()
    with pytest.raises(RuntimeError, match="Executor not started"):
        await executor.invoke("transcribe", audio=None)


@pytest.mark.asyncio
async def test_cleanup_on_stop():
    """stop() terminates the subprocess cleanly."""
    executor = SubprocessExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())
    proc = executor._process
    assert proc is not None
    assert proc.returncode is None

    await executor.stop()

    # After stop the process should have exited
    assert executor._process is None
    assert executor._writer is None


@pytest.mark.asyncio
async def test_restart_on_crash():
    """When the worker crashes, SubprocessExecutor restarts it automatically."""
    executor = SubprocessExecutor(restart_on_crash=True, restart_delay_s=0.1)
    await executor.start(FakeSTT, FakeSTTSettings())

    # Kill the worker process to simulate a crash
    proc = executor._process
    assert proc is not None
    proc.kill()
    await asyncio.sleep(0.2)  # Let the process actually die

    # The next invoke should detect the crash, restart, and succeed
    audio = AudioData(data=b"audio", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
    result = await executor.invoke("transcribe", audio=audio)
    assert isinstance(result, Transcription)
    assert result.text == "fake transcription"

    await executor.stop()


@pytest.mark.asyncio
async def test_no_restart_when_disabled():
    """When restart_on_crash=False and worker crashes, invoke() raises RuntimeError."""
    executor = SubprocessExecutor(restart_on_crash=False, restart_delay_s=0.0)
    await executor.start(FakeSTT, FakeSTTSettings())

    proc = executor._process
    assert proc is not None
    proc.kill()
    await asyncio.sleep(0.2)

    audio = AudioData(data=b"audio", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
    with pytest.raises(RuntimeError):
        await executor.invoke("transcribe", audio=audio)

    # Clean up
    executor._started = False
    await executor._kill_process()
    if executor._tmpdir:
        executor._tmpdir.cleanup()
        executor._tmpdir = None
