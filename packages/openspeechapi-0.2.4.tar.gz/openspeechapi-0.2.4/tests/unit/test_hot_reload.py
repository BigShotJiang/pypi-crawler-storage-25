"""Tests for ServiceDispatcher.reload_config() hot-reload logic."""
from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from tests.conftest import FakeSTT, FakeTTS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_registry() -> ProviderRegistry:
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    return registry


def write_config(path: Path, content: str) -> None:
    path.write_text(dedent(content))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def cfg_path(tmp_path):
    p = tmp_path / "providers.yaml"
    write_config(p, """\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
    """)
    return p


@pytest.fixture
def registry():
    return make_registry()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_reload_preserves_unchanged_provider(cfg_path, registry):
    """Reloading identical config leaves unchanged providers intact."""
    dispatcher = ServiceDispatcher.from_config(cfg_path, registry)
    await dispatcher.start()
    try:
        original_handle = dispatcher._handles["stt"]
        result = await dispatcher.reload_config(cfg_path, registry)
        assert "stt" in result["unchanged"]
        assert result["added"] == []
        assert result["removed"] == []
        assert result["updated"] == []
        # Same handle object should still be in place
        assert dispatcher._handles["stt"] is original_handle
    finally:
        await dispatcher.stop()


@pytest.mark.asyncio
async def test_reload_adds_new_provider(cfg_path, registry):
    """Reloading with a new provider entry adds it to the dispatcher."""
    dispatcher = ServiceDispatcher.from_config(cfg_path, registry)
    await dispatcher.start()
    try:
        # Add a tts provider to the config
        write_config(cfg_path, """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
        """)
        result = await dispatcher.reload_config(cfg_path, registry)
        assert "tts" in result["added"]
        assert "stt" in result["unchanged"]
        assert "tts" in dispatcher._handles
    finally:
        await dispatcher.stop()


@pytest.mark.asyncio
async def test_reload_removes_provider(cfg_path, registry):
    """Reloading with a provider removed stops and deregisters it."""
    # Start with both stt and tts
    write_config(cfg_path, """\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """)
    dispatcher = ServiceDispatcher.from_config(cfg_path, registry)
    await dispatcher.start()
    try:
        # Remove tts
        write_config(cfg_path, """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
        """)
        result = await dispatcher.reload_config(cfg_path, registry)
        assert "tts" in result["removed"]
        assert "stt" in result["unchanged"]
        assert "tts" not in dispatcher._handles
    finally:
        await dispatcher.stop()


@pytest.mark.asyncio
async def test_reload_updates_changed_settings(cfg_path, registry):
    """Reloading with changed settings marks provider as updated and rebuilds handle."""
    dispatcher = ServiceDispatcher.from_config(cfg_path, registry)
    await dispatcher.start()
    try:
        original_handle = dispatcher._handles["stt"]

        # Change a setting value
        write_config(cfg_path, """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings:
                  model_size: large
        """)
        result = await dispatcher.reload_config(cfg_path, registry)
        assert "stt" in result["updated"]
        assert result["unchanged"] == []
        # Handle should be a new object with updated settings
        new_handle = dispatcher._handles["stt"]
        assert new_handle is not original_handle
        assert new_handle.settings_dict == {"model_size": "large"}
    finally:
        await dispatcher.stop()


@pytest.mark.asyncio
async def test_reload_result_structure(cfg_path, registry):
    """reload_config always returns dict with all four keys."""
    dispatcher = ServiceDispatcher.from_config(cfg_path, registry)
    await dispatcher.start()
    try:
        result = await dispatcher.reload_config(cfg_path, registry)
        assert set(result.keys()) == {"added", "removed", "updated", "unchanged"}
        for v in result.values():
            assert isinstance(v, list)
    finally:
        await dispatcher.stop()


@pytest.mark.asyncio
async def test_reload_add_and_remove_simultaneously(cfg_path, registry):
    """Reload handles simultaneous add and remove correctly."""
    write_config(cfg_path, """\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """)
    dispatcher = ServiceDispatcher.from_config(cfg_path, registry)
    await dispatcher.start()
    try:
        # Replace tts with a different name for stt
        write_config(cfg_path, """\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              stt2:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
        """)
        result = await dispatcher.reload_config(cfg_path, registry)
        assert "stt2" in result["added"]
        assert "tts" in result["removed"]
        assert "stt" in result["unchanged"]
        assert "stt2" in dispatcher._handles
        assert "tts" not in dispatcher._handles
    finally:
        await dispatcher.stop()
