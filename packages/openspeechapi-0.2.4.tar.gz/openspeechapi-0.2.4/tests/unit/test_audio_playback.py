"""Tests for audio playback utility."""
from __future__ import annotations

import wave
from io import BytesIO

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData
from openspeechapi.utils.audio_playback import _scale_pcm16, _wav_bytes_from_audio, play_audio


def _pcm_audio() -> AudioData:
    return AudioData(
        data=b"\x00\x00\x10\x00\xf0\xff",
        sample_rate=16000,
        channels=1,
        format=AudioFormat.PCM_16K,
    )


def test_pcm_converts_to_wav_bytes() -> None:
    wav_bytes = _wav_bytes_from_audio(_pcm_audio())
    assert wav_bytes[:4] == b"RIFF"
    with wave.open(BytesIO(wav_bytes), "rb") as wf:
        assert wf.getframerate() == 16000
        assert wf.getnchannels() == 1


def test_scale_pcm16_changes_samples() -> None:
    data = b"\x10\x00\xf0\xff"
    scaled = _scale_pcm16(data, 2.0)
    assert scaled != data


def test_play_audio_validates_params() -> None:
    with pytest.raises(ValueError, match="volume must be > 0"):
        play_audio(_pcm_audio(), volume=0)
    with pytest.raises(ValueError, match="backend must be one of"):
        play_audio(_pcm_audio(), backend="invalid")
