"""Tests for docker pull progress parsing."""
from __future__ import annotations

from openspeechapi.local_engines.backends.docker_backend import DockerBackend


def test_extract_pull_progress_mb() -> None:
    line = "a8e4c6f30157: Downloading [=====> ]  150.3MB/3193.8MB"
    parsed = DockerBackend._extract_pull_progress(line)
    assert parsed is not None
    layer, cur, total = parsed
    assert layer == "a8e4c6f30157"
    assert cur > 150_000_000
    assert total > 3_000_000_000


def test_extract_pull_progress_ignores_non_progress() -> None:
    assert DockerBackend._extract_pull_progress("Digest: sha256:abc") is None


def test_extract_pull_status() -> None:
    parsed = DockerBackend._extract_pull_status("6033c0df0b30: Pulling fs layer")
    assert parsed == ("6033c0df0b30", "Pulling fs layer")


def test_format_bytes_human_readable() -> None:
    assert DockerBackend._format_bytes(0) == "0 B"
    assert DockerBackend._format_bytes(1024) == "1.0 KB"
