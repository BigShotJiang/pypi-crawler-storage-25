"""Tests for openspeechapi.observe.metrics — MetricsObserver."""
from __future__ import annotations
import pytest
from openspeechapi.core.enums import ExecMode
from openspeechapi.core.models import Transcription
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.metrics import MetricsObserver


def _make_ctx(provider: str = "stt1", method: str = "transcribe") -> InvokeContext:
    ctx = InvokeContext(provider_name=provider, method=method, exec_mode=ExecMode.IN_PROCESS)
    return ctx


class TestMetricsObserverInvocations:
    @pytest.mark.asyncio
    async def test_records_single_invocation(self):
        obs = MetricsObserver()
        ctx = _make_ctx()
        ctx.record_end()
        await obs.on_invoke_end(ctx, result=Transcription(text="hello"))
        m = obs.get("stt1", "transcribe")
        assert m is not None
        assert m.total_calls == 1
        assert len(m.durations_ms) == 1

    @pytest.mark.asyncio
    async def test_records_multiple_invocations(self):
        obs = MetricsObserver()
        for _ in range(3):
            ctx = _make_ctx()
            ctx.record_end()
            await obs.on_invoke_end(ctx, result=Transcription(text="x"))
        m = obs.get("stt1", "transcribe")
        assert m.total_calls == 3
        assert len(m.durations_ms) == 3

    @pytest.mark.asyncio
    async def test_records_error_count(self):
        obs = MetricsObserver()
        ctx = _make_ctx()
        await obs.on_invoke_error(ctx, error=RuntimeError("boom"))
        m = obs.get("stt1", "transcribe")
        assert m is not None
        assert m.error_count == 1

    @pytest.mark.asyncio
    async def test_records_ttfb_when_present(self):
        obs = MetricsObserver()
        ctx = _make_ctx()
        ctx.record_ttfb()
        ctx.record_end()
        await obs.on_invoke_end(ctx, result=Transcription(text="x"))
        m = obs.get("stt1", "transcribe")
        assert len(m.ttfb_ms) == 1
        assert m.ttfb_ms[0] >= 0.0

    @pytest.mark.asyncio
    async def test_no_ttfb_when_not_recorded(self):
        obs = MetricsObserver()
        ctx = _make_ctx()
        ctx.record_end()
        await obs.on_invoke_end(ctx, result=Transcription(text="x"))
        m = obs.get("stt1", "transcribe")
        assert len(m.ttfb_ms) == 0

    @pytest.mark.asyncio
    async def test_keys_are_per_provider_and_method(self):
        obs = MetricsObserver()
        ctx_stt = _make_ctx(provider="stt1", method="transcribe")
        ctx_stt.record_end()
        await obs.on_invoke_end(ctx_stt, result=None)

        ctx_tts = _make_ctx(provider="tts1", method="synthesize")
        ctx_tts.record_end()
        await obs.on_invoke_end(ctx_tts, result=None)

        assert obs.get("stt1", "transcribe") is not None
        assert obs.get("tts1", "synthesize") is not None
        assert obs.get("stt1", "transcribe").total_calls == 1
        assert obs.get("tts1", "synthesize").total_calls == 1

    def test_get_returns_none_for_unseen_key(self):
        obs = MetricsObserver()
        assert obs.get("unknown", "transcribe") is None
