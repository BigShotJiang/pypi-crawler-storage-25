"""Tests for openspeechapi.cli module."""
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

import pytest


PYTHON = sys.executable

SAMPLE_CONFIG = """\
providers:
  whisper_local:
    provider: whisper
    exec_mode: in_process
  google_stt:
    provider: google
    exec_mode: remote
"""

EMPTY_CONFIG = """\
providers: {}
"""


@pytest.fixture
def config_file(tmp_path: Path) -> Path:
    p = tmp_path / "providers.yaml"
    p.write_text(SAMPLE_CONFIG)
    return p


@pytest.fixture
def empty_config_file(tmp_path: Path) -> Path:
    p = tmp_path / "providers.yaml"
    p.write_text(EMPTY_CONFIG)
    return p


def run_cli(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [PYTHON, "-m", "openspeechapi.cli", *args],
        capture_output=True,
        text=True,
    )


class TestListCommand:
    def test_list_command_returns_zero(self, config_file: Path) -> None:
        result = run_cli("--config", str(config_file), "list")
        assert result.returncode == 0

    def test_list_command_shows_providers(self, config_file: Path) -> None:
        result = run_cli("--config", str(config_file), "list")
        assert "whisper_local" in result.stdout
        assert "google_stt" in result.stdout

    def test_list_command_shows_headers(self, config_file: Path) -> None:
        result = run_cli("--config", str(config_file), "list")
        assert "Name" in result.stdout
        assert "Provider" in result.stdout
        assert "ExecMode" in result.stdout

    def test_list_command_empty_providers(self, empty_config_file: Path) -> None:
        result = run_cli("--config", str(empty_config_file), "list")
        assert result.returncode == 1
        assert "Error:" in result.stderr

    def test_list_command_missing_config(self, tmp_path: Path) -> None:
        result = run_cli("--config", str(tmp_path / "missing.yaml"), "list")
        assert result.returncode == 1
        assert "Error:" in result.stderr


class TestCheckCommand:
    def test_check_command_returns_zero(self, config_file: Path) -> None:
        result = run_cli("--config", str(config_file), "check")
        assert result.returncode == 0

    def test_check_command_shows_ok_message(self, config_file: Path) -> None:
        result = run_cli("--config", str(config_file), "check")
        assert "Config OK" in result.stdout
        assert "2 engine(s)" in result.stdout

    def test_check_command_missing_config(self, tmp_path: Path) -> None:
        result = run_cli("--config", str(tmp_path / "missing.yaml"), "check")
        assert result.returncode == 1
        assert "Config error:" in result.stderr


class TestNoArgsShowsHelp:
    def test_no_args_shows_help(self) -> None:
        result = run_cli()
        # argparse prints help to stdout when print_help() is called
        assert "usage" in result.stdout.lower() or "usage" in result.stderr.lower()
        assert result.returncode == 0

    def test_help_flag(self) -> None:
        result = run_cli("--help")
        assert "usage" in result.stdout.lower()
