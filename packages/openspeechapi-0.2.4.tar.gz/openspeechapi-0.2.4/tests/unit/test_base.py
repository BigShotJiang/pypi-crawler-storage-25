"""Tests for provider base classes."""
from dataclasses import dataclass

import pytest

from openspeechapi.core.base import STTProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings


@dataclass
class FakeSTTSettings(BaseSettings):
    model_size: str = "tiny"


class FakeSTT(STTProvider):
    name = "fake-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    capabilities = {Capability.BATCH}

    def __init__(self, settings: FakeSTTSettings | None = None):
        self.settings = settings or FakeSTTSettings()

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    async def health_check(self) -> bool:
        return True

    async def transcribe(self, audio: AudioData, opts: STTOptions | None = None) -> Transcription:
        return Transcription(text="fake")

    async def transcribe_stream(self, stream):
        yield Transcription(text="chunk")


class TestSTTProvider:
    @pytest.mark.asyncio
    async def test_transcribe(self):
        stt = FakeSTT()
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await stt.transcribe(audio)
        assert result.text == "fake"

    def test_attributes(self):
        stt = FakeSTT()
        assert stt.name == "fake-stt"
        assert stt.provider_type == ProviderType.STT
        assert Capability.BATCH in stt.capabilities

    @pytest.mark.asyncio
    async def test_lifecycle(self):
        stt = FakeSTT()
        await stt.start()
        assert await stt.health_check() is True
        await stt.stop()


class TestTTSProviderListVoices:
    @pytest.mark.asyncio
    async def test_list_voices_default_empty(self):
        """TTSProvider.list_voices() should return empty list by default."""
        from tests.conftest import FakeTTS
        provider = FakeTTS()
        voices = await provider.list_voices()
        assert voices == []


class TestBaseSettings:
    def test_is_dataclass(self):
        s = FakeSTTSettings(model_size="large")
        assert s.model_size == "large"
