"""Tests for Executor ABC."""
from __future__ import annotations

import pytest

from openspeechapi.dispatch.executors.base import Executor


def test_executor_cannot_be_instantiated():
    """Executor is abstract and cannot be instantiated directly."""
    with pytest.raises(TypeError):
        Executor()  # type: ignore[abstract]


def test_executor_has_required_abstract_methods():
    """Executor defines the required abstract methods."""
    abstract_methods = getattr(Executor, "__abstractmethods__", set())
    assert "start" in abstract_methods
    assert "stop" in abstract_methods
    assert "invoke" in abstract_methods
    assert "invoke_stream" in abstract_methods
    assert "health_check" in abstract_methods


def test_executor_subclass_must_implement_all_methods():
    """A partial subclass without all methods cannot be instantiated."""

    class PartialExecutor(Executor):
        async def start(self, provider_cls, settings): ...
        async def stop(self): ...
        async def invoke(self, method, **kwargs): ...
        # Missing invoke_stream and health_check

    with pytest.raises(TypeError):
        PartialExecutor()  # type: ignore[abstract]


def test_executor_full_subclass_can_be_instantiated():
    """A complete subclass implementing all abstract methods can be instantiated."""

    class ConcreteExecutor(Executor):
        async def start(self, provider_cls, settings): ...
        async def stop(self): ...
        async def invoke(self, method, **kwargs): ...
        async def invoke_stream(self, method, **kwargs):
            yield  # pragma: no cover
        async def health_check(self): return True

    executor = ConcreteExecutor()
    assert isinstance(executor, Executor)
