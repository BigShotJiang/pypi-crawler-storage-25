"""Tests for openspeechapi.observe.base — DispatchObserver ABC and ObserverManager."""
from __future__ import annotations
from typing import Any
import pytest
from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.base import DispatchObserver, ObserverManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_ctx() -> InvokeContext:
    return InvokeContext(provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS)


class CountingObserver(DispatchObserver):
    def __init__(self) -> None:
        self.invoke_start_calls: int = 0
        self.invoke_end_calls: int = 0
        self.invoke_error_calls: int = 0
        self.stream_chunk_calls: int = 0
        self.provider_start_calls: int = 0
        self.provider_stop_calls: int = 0
        self.health_change_calls: int = 0

    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        self.invoke_start_calls += 1

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        self.invoke_end_calls += 1

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        self.invoke_error_calls += 1

    async def on_stream_chunk(self, ctx: InvokeContext, chunk: Any) -> None:
        self.stream_chunk_calls += 1

    async def on_provider_start(self, provider: str, exec_mode: ExecMode) -> None:
        self.provider_start_calls += 1

    async def on_provider_stop(self, provider: str) -> None:
        self.provider_stop_calls += 1

    async def on_health_change(self, provider: str, healthy: bool) -> None:
        self.health_change_calls += 1


class FailingObserver(DispatchObserver):
    """Always raises on every notification."""

    async def on_invoke_start(self, ctx: InvokeContext) -> None:
        raise RuntimeError("intentional failure")

    async def on_invoke_end(self, ctx: InvokeContext, result: Any) -> None:
        raise RuntimeError("intentional failure")

    async def on_invoke_error(self, ctx: InvokeContext, error: Exception) -> None:
        raise RuntimeError("intentional failure")


# ---------------------------------------------------------------------------
# DispatchObserver ABC
# ---------------------------------------------------------------------------

class TestDispatchObserver:
    def test_can_instantiate_concrete_subclass(self):
        obs = CountingObserver()
        assert isinstance(obs, DispatchObserver)

    @pytest.mark.asyncio
    async def test_base_noop_methods_do_not_raise(self):
        """The ABC default no-ops should be callable without raising."""
        # Create a subclass that doesn't override anything
        class MinimalObserver(DispatchObserver):
            pass

        obs = MinimalObserver()
        ctx = _make_ctx()
        await obs.on_invoke_start(ctx)
        await obs.on_invoke_end(ctx, result="x")
        await obs.on_invoke_error(ctx, error=ValueError("e"))
        await obs.on_stream_chunk(ctx, chunk=b"data")
        await obs.on_provider_start("prov", ExecMode.IN_PROCESS)
        await obs.on_provider_stop("prov")
        await obs.on_health_change("prov", True)


# ---------------------------------------------------------------------------
# ObserverManager — basic add/remove/list
# ---------------------------------------------------------------------------

class TestObserverManagerAddRemove:
    def test_add_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        assert obs in mgr.list()

    def test_remove_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        mgr.remove(obs)
        assert obs not in mgr.list()

    def test_list_returns_copy(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        lst = mgr.list()
        lst.clear()
        assert obs in mgr.list()  # Original unaffected


# ---------------------------------------------------------------------------
# ObserverManager — notification dispatch
# ---------------------------------------------------------------------------

class TestObserverManagerNotifications:
    @pytest.mark.asyncio
    async def test_notify_invoke_start_calls_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        ctx = _make_ctx()
        await mgr.notify_invoke_start(ctx)
        assert obs.invoke_start_calls == 1

    @pytest.mark.asyncio
    async def test_notify_invoke_end_calls_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        ctx = _make_ctx()
        await mgr.notify_invoke_end(ctx, result="done")
        assert obs.invoke_end_calls == 1

    @pytest.mark.asyncio
    async def test_notify_invoke_error_calls_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        ctx = _make_ctx()
        await mgr.notify_invoke_error(ctx, error=RuntimeError("oops"))
        assert obs.invoke_error_calls == 1

    @pytest.mark.asyncio
    async def test_notify_stream_chunk_calls_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        ctx = _make_ctx()
        await mgr.notify_stream_chunk(ctx, chunk=b"audio")
        assert obs.stream_chunk_calls == 1

    @pytest.mark.asyncio
    async def test_notify_provider_start_calls_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        await mgr.notify_provider_start("prov", ExecMode.IN_PROCESS)
        assert obs.provider_start_calls == 1

    @pytest.mark.asyncio
    async def test_notify_provider_stop_calls_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        await mgr.notify_provider_stop("prov")
        assert obs.provider_stop_calls == 1

    @pytest.mark.asyncio
    async def test_notify_health_change_calls_observer(self):
        mgr = ObserverManager()
        obs = CountingObserver()
        mgr.add(obs)
        await mgr.notify_health_change("prov", False)
        assert obs.health_change_calls == 1

    @pytest.mark.asyncio
    async def test_multiple_observers_all_notified(self):
        mgr = ObserverManager()
        obs1 = CountingObserver()
        obs2 = CountingObserver()
        mgr.add(obs1)
        mgr.add(obs2)
        ctx = _make_ctx()
        await mgr.notify_invoke_start(ctx)
        assert obs1.invoke_start_calls == 1
        assert obs2.invoke_start_calls == 1


# ---------------------------------------------------------------------------
# ObserverManager — error isolation
# ---------------------------------------------------------------------------

class TestObserverManagerErrorIsolation:
    @pytest.mark.asyncio
    async def test_failing_observer_does_not_propagate_error(self):
        mgr = ObserverManager()
        failing = FailingObserver()
        good = CountingObserver()
        mgr.add(failing)
        mgr.add(good)
        ctx = _make_ctx()
        # Should not raise even though FailingObserver raises
        await mgr.notify_invoke_start(ctx)
        # Good observer should still be called
        assert good.invoke_start_calls == 1

    @pytest.mark.asyncio
    async def test_auto_deregister_after_max_consecutive_errors(self):
        max_errors = 3
        mgr = ObserverManager(max_consecutive_errors=max_errors)
        failing = FailingObserver()
        mgr.add(failing)
        ctx = _make_ctx()

        for _ in range(max_errors):
            await mgr.notify_invoke_start(ctx)

        # Observer should be auto-removed after max_errors consecutive failures
        assert failing not in mgr.list()

    @pytest.mark.asyncio
    async def test_error_count_resets_on_success(self):
        """Observer stays registered if errors are non-consecutive."""
        max_errors = 3
        mgr = ObserverManager(max_consecutive_errors=max_errors)

        call_count = 0

        class SometimesFailingObserver(DispatchObserver):
            async def on_invoke_start(self, ctx: InvokeContext) -> None:
                nonlocal call_count
                call_count += 1
                # Fail on calls 1, 2, then succeed on call 3, then fail again
                if call_count in (1, 2, 4, 5):
                    raise RuntimeError("intermittent failure")

        obs = SometimesFailingObserver()
        mgr.add(obs)
        ctx = _make_ctx()

        # Calls 1, 2 fail → error_count = 2
        await mgr.notify_invoke_start(ctx)
        await mgr.notify_invoke_start(ctx)
        # Call 3 succeeds → error_count resets to 0
        await mgr.notify_invoke_start(ctx)
        # Calls 4, 5 fail again → error_count = 2 (not yet at max)
        await mgr.notify_invoke_start(ctx)
        await mgr.notify_invoke_start(ctx)

        # Should still be registered because errors were non-consecutive (reset happened)
        assert obs in mgr.list()
