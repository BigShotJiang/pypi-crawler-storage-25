"""Tests for the provider plugin mechanism (Task 6)."""
from __future__ import annotations

import sys
import textwrap
from dataclasses import dataclass
from pathlib import Path

import pytest

from openspeechapi.config import ProviderConfig
from openspeechapi.factory import _resolve_from_config, _ensure_plugins_dir


# ---------------------------------------------------------------------------
# ProviderConfig field defaults
# ---------------------------------------------------------------------------

class TestProviderConfigPluginFields:
    def test_module_defaults_to_none(self):
        cfg = ProviderConfig(provider="dummy", exec_mode="in_process")
        assert cfg.module is None

    def test_provider_class_defaults_to_none(self):
        cfg = ProviderConfig(provider="dummy", exec_mode="in_process")
        assert cfg.provider_class is None

    def test_module_and_class_can_be_set(self):
        cfg = ProviderConfig(
            provider="custom",
            exec_mode="in_process",
            module="my_plugins.tts",
            provider_class="MyTTS",
        )
        assert cfg.module == "my_plugins.tts"
        assert cfg.provider_class == "MyTTS"


# ---------------------------------------------------------------------------
# _resolve_from_config
# ---------------------------------------------------------------------------

class TestResolveFromConfig:
    def test_loads_external_provider_via_module_and_class(self, tmp_path):
        """Create a tiny module on disk and resolve it dynamically."""
        plugin_file = tmp_path / "fake_provider.py"
        plugin_file.write_text(textwrap.dedent("""\
            class FakeSettings:
                pass

            class FakeProvider:
                settings_cls = FakeSettings
        """))

        # Make the tmp directory importable
        sys.path.insert(0, str(tmp_path))
        try:
            cfg = ProviderConfig(
                provider="ignored",
                exec_mode="in_process",
                module="fake_provider",
                provider_class="FakeProvider",
            )
            provider_cls, settings_cls = _resolve_from_config(cfg)
            assert provider_cls.__name__ == "FakeProvider"
            assert settings_cls.__name__ == "FakeSettings"
        finally:
            sys.path.remove(str(tmp_path))
            # Clean up imported module
            sys.modules.pop("fake_provider", None)

    def test_fallback_to_provider_map(self):
        """When module/class are None, fall back to _PROVIDER_MAP."""
        cfg = ProviderConfig(
            provider="openai-tts",
            exec_mode="in_process",
        )
        provider_cls, settings_cls = _resolve_from_config(cfg)
        assert provider_cls.__name__ == "OpenAITTS"

    def test_unknown_provider_raises(self):
        cfg = ProviderConfig(
            provider="no-such-provider",
            exec_mode="in_process",
        )
        with pytest.raises(Exception):
            _resolve_from_config(cfg)


# ---------------------------------------------------------------------------
# _ensure_plugins_dir
# ---------------------------------------------------------------------------

class TestEnsurePluginsDir:
    def test_adds_plugins_dir_to_sys_path(self, tmp_path):
        plugins = tmp_path / "plugins"
        plugins.mkdir()

        _ensure_plugins_dir(project_root=tmp_path)
        assert str(plugins) in sys.path

        # Clean up
        sys.path.remove(str(plugins))

    def test_no_plugins_dir_no_error(self, tmp_path):
        """If there is no plugins/ directory, nothing happens and no error."""
        _ensure_plugins_dir(project_root=tmp_path)
        # Just verify it didn't raise

    def test_idempotent(self, tmp_path):
        plugins = tmp_path / "plugins"
        plugins.mkdir()

        _ensure_plugins_dir(project_root=tmp_path)
        _ensure_plugins_dir(project_root=tmp_path)
        count = sys.path.count(str(plugins))
        assert count == 1

        # Clean up
        sys.path.remove(str(plugins))
