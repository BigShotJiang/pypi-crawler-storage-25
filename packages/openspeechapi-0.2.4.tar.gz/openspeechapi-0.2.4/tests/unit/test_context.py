"""Tests for InvokeContext."""

from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext


class TestInvokeContext:
    def test_create_minimal(self):
        ctx = InvokeContext(
            provider_name="test",
            method="transcribe",
            exec_mode=ExecMode.IN_PROCESS,
        )
        assert ctx.request_id
        assert ctx.provider_name == "test"
        assert ctx.method == "transcribe"
        assert ctx.start_time_ns > 0
        assert ctx.ttfb_ns is None
        assert ctx.end_time_ns is None
        assert ctx.parent_id is None

    def test_record_ttfb(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
        )
        ctx.record_ttfb()
        assert ctx.ttfb_ns is not None
        assert ctx.ttfb_ns >= ctx.start_time_ns

    def test_record_end(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
        )
        ctx.record_end()
        assert ctx.end_time_ns is not None

    def test_elapsed_ms(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
        )
        ctx.record_end()
        assert ctx.elapsed_ms >= 0

    def test_metadata(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
            metadata={"key": "value"},
        )
        assert ctx.metadata["key"] == "value"

    def test_parent_id_for_fanout(self):
        ctx = InvokeContext(
            provider_name="test", method="transcribe", exec_mode=ExecMode.IN_PROCESS,
            parent_id="parent-123",
        )
        assert ctx.parent_id == "parent-123"
