"""Tests for persistent local engine task store."""
from __future__ import annotations

from pathlib import Path

from openspeechapi.local_engines.models import EngineAction, TaskStatus
from openspeechapi.local_engines.task_store import JsonTaskStore
from openspeechapi.local_engines.tasks import EngineTask


def test_save_get_and_list(tmp_path: Path) -> None:
    store = JsonTaskStore(root_dir=tmp_path / "tasks")
    t = EngineTask(
        engine="fish-speech",
        action=EngineAction.START,
        runtime="docker",
        status=TaskStatus.RUNNING,
        phase="start_container",
        message="starting",
        progress=30.0,
    )
    store.save(t)

    got = store.get(t.task_id)
    assert got is not None
    assert got.task_id == t.task_id
    assert got.engine == "fish-speech"

    lst = store.list(engine="fish-speech", limit=10)
    assert len(lst) == 1
    assert lst[0].task_id == t.task_id
