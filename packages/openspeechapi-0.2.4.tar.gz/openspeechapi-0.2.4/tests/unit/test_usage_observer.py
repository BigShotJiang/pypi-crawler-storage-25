"""Tests for openspeechapi.observe.usage — UsageObserver."""
from __future__ import annotations
import pytest
from openspeechapi.core.enums import AudioFormat, ExecMode
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.usage import UsageObserver


def _make_ctx(provider: str = "stt1", method: str = "transcribe", **meta) -> InvokeContext:
    ctx = InvokeContext(provider_name=provider, method=method, exec_mode=ExecMode.IN_PROCESS)
    ctx.metadata.update(meta)
    return ctx


def _audio(duration_ms: int) -> AudioData:
    return AudioData(data=b"x", sample_rate=16000, channels=1,
                     format=AudioFormat.PCM_16K, duration_ms=duration_ms)


class TestUsageObserverCallCount:
    @pytest.mark.asyncio
    async def test_increments_call_count(self):
        obs = UsageObserver()
        ctx = _make_ctx()
        await obs.on_invoke_end(ctx, result=Transcription(text="hello"))
        assert obs.call_count == 1

    @pytest.mark.asyncio
    async def test_increments_call_count_multiple(self):
        obs = UsageObserver()
        for _ in range(5):
            await obs.on_invoke_end(_make_ctx(), result=None)
        assert obs.call_count == 5


class TestUsageObserverAudioDuration:
    @pytest.mark.asyncio
    async def test_tracks_audio_duration_from_result(self):
        obs = UsageObserver()
        ctx = _make_ctx()
        await obs.on_invoke_end(ctx, result=_audio(duration_ms=500))
        assert obs.total_audio_duration_ms == 500

    @pytest.mark.asyncio
    async def test_accumulates_multiple_audio_durations(self):
        obs = UsageObserver()
        await obs.on_invoke_end(_make_ctx(), result=_audio(300))
        await obs.on_invoke_end(_make_ctx(), result=_audio(700))
        assert obs.total_audio_duration_ms == 1000

    @pytest.mark.asyncio
    async def test_no_audio_duration_when_result_has_none(self):
        obs = UsageObserver()
        ctx = _make_ctx()
        await obs.on_invoke_end(ctx, result=Transcription(text="hello"))  # no duration_ms
        assert obs.total_audio_duration_ms == 0

    @pytest.mark.asyncio
    async def test_no_audio_duration_when_result_is_none(self):
        obs = UsageObserver()
        ctx = _make_ctx()
        await obs.on_invoke_end(ctx, result=None)
        assert obs.total_audio_duration_ms == 0


class TestUsageObserverCharacterCount:
    @pytest.mark.asyncio
    async def test_tracks_character_count_from_metadata(self):
        obs = UsageObserver()
        ctx = _make_ctx(text="hello world")
        await obs.on_invoke_end(ctx, result=None)
        assert obs.total_characters == len("hello world")

    @pytest.mark.asyncio
    async def test_accumulates_character_counts(self):
        obs = UsageObserver()
        await obs.on_invoke_end(_make_ctx(text="hello"), result=None)
        await obs.on_invoke_end(_make_ctx(text="world!"), result=None)
        assert obs.total_characters == len("hello") + len("world!")

    @pytest.mark.asyncio
    async def test_no_character_count_without_text_metadata(self):
        obs = UsageObserver()
        ctx = _make_ctx()  # No text in metadata
        await obs.on_invoke_end(ctx, result=None)
        assert obs.total_characters == 0
