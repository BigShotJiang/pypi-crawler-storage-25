"""Tests for native backend helpers and status behavior."""
from __future__ import annotations

from pathlib import Path

from openspeechapi.local_engines.backends import native_backend
from openspeechapi.local_engines.backends.native_backend import NativeBackend
from openspeechapi.local_engines.engines.fish_speech import FISH_SPEECH_SPEC
from openspeechapi.local_engines.models import EngineSpec, RuntimeConfig


def test_native_root_default_when_install_dir_empty() -> None:
    backend = NativeBackend()
    cfg = RuntimeConfig(runtime="native", install_dir="")
    root = backend._native_root(cfg)
    assert str(root).endswith("/AI/services")


def test_service_dir_under_native_root(tmp_path: Path) -> None:
    backend = NativeBackend()
    cfg = RuntimeConfig(runtime="native", install_dir=str(tmp_path))
    service_dir = backend._service_dir(FISH_SPEECH_SPEC, cfg)
    assert service_dir == tmp_path / "fish-speech"


def test_start_cmd_uses_api_url_and_device(tmp_path: Path) -> None:
    backend = NativeBackend()
    cfg = RuntimeConfig(
        runtime="native",
        install_dir=str(tmp_path),
        api_url="http://127.0.0.1:8899",
    )
    venv_python = tmp_path / "fish-speech" / ".venv" / "bin" / "python"
    venv_python.parent.mkdir(parents=True, exist_ok=True)
    venv_python.write_text("#!/bin/sh\necho fake\n", encoding="utf-8")

    opts = backend._effective_options(FISH_SPEECH_SPEC, cfg)
    cmd = backend._start_cmd(FISH_SPEECH_SPEC, cfg, opts)
    cmd_str = " ".join(cmd)
    assert "--listen 127.0.0.1:8899" in cmd_str
    assert "--device mps" in cmd_str
    assert "tools/api_server.py" in cmd_str


def test_start_cmd_supports_custom_template(tmp_path: Path) -> None:
    backend = NativeBackend()
    spec = EngineSpec(name="whisperlivekit", default_runtime="native")
    cfg = RuntimeConfig(
        runtime="native",
        install_dir=str(tmp_path),
        api_url="http://127.0.0.1:12100",
    )
    venv_python = tmp_path / "whisperlivekit" / ".venv" / "bin" / "python"
    venv_python.parent.mkdir(parents=True, exist_ok=True)
    venv_python.write_text("#!/bin/sh\necho fake\n", encoding="utf-8")
    opts = {
        "native_model_dir": "models/whisperlivekit",
        "native_start_cmd": [
            "{venv_python}",
            "-m",
            "whisperlivekit",
            "serve",
            "--host",
            "{api_host}",
            "--port",
            "{api_port}",
            "--backend",
            "mlx-whisper",
        ],
    }
    cmd = backend._start_cmd(spec, cfg, opts)
    assert cmd[0] == str(venv_python)
    assert "--host" in cmd and "127.0.0.1" in cmd
    assert "--port" in cmd and "12100" in cmd


def test_native_status_returns_stopped_when_no_pid(tmp_path: Path) -> None:
    backend = NativeBackend()
    cfg = RuntimeConfig(runtime="native", install_dir=str(tmp_path))
    status = backend.status(FISH_SPEECH_SPEC, cfg)
    assert status.running is False
    assert status.healthy is False
    assert status.detail == "stopped"


def test_model_dir_resolves_relative_to_repo(tmp_path: Path) -> None:
    backend = NativeBackend()
    cfg = RuntimeConfig(runtime="native", install_dir=str(tmp_path))
    opts = {"native_model_dir": "checkpoints/s2-pro"}
    p = backend._model_dir(FISH_SPEECH_SPEC, cfg, opts)
    assert p == tmp_path / "fish-speech" / "src" / "checkpoints" / "s2-pro"


def test_model_ready_checks_required_files(tmp_path: Path) -> None:
    model_dir = tmp_path / "checkpoints" / "s2-pro"
    model_dir.mkdir(parents=True)
    assert NativeBackend._model_ready(model_dir) is False
    (model_dir / "codec.pth").write_bytes(b"x")
    assert NativeBackend._model_ready(model_dir) is False
    (model_dir / "model.safetensors.index.json").write_text("{}", encoding="utf-8")
    assert NativeBackend._model_ready(model_dir) is True


def test_resolve_script_path_relative() -> None:
    backend = NativeBackend()
    p = backend._resolve_script_path("scripts/engines/fish-speech/native/install.sh")
    assert p.name == "install.sh"
    assert p.exists() is True


def test_run_script_with_progress_parses_phase(tmp_path: Path) -> None:
    backend = NativeBackend()
    script = tmp_path / "install.sh"
    script.write_text(
        "#!/usr/bin/env bash\n"
        "set -e\n"
        "echo 'OPENSPEECH_PHASE:clone_repo:25:cloning'\n"
        "echo 'OPENSPEECH_PHASE:install_deps:58:deps'\n",
        encoding="utf-8",
    )
    events = []

    def _report(phase, message, progress):  # noqa: ANN001
        events.append((phase, message, progress))

    backend._run_script_with_progress(
        script,
        cwd=tmp_path,
        env={},
        report=_report,
    )
    assert ("clone_repo", "cloning", 25.0) in events
    assert ("install_deps", "deps", 58.0) in events


def test_sanitize_log_line_removes_ansi() -> None:
    backend = NativeBackend()
    s = backend._sanitize_log_line("\x1b[32mINFO\x1b[0m: loaded")
    assert s == "INFO: loaded"


def test_read_log_hint_reads_latest_line(tmp_path: Path) -> None:
    backend = NativeBackend()
    logf = tmp_path / "native.log"
    logf.write_text("line1\nline2\n", encoding="utf-8")
    cursor, hint = backend._read_log_hint(logf, 0)
    assert hint == "line2"
    assert cursor > 0


def test_summarize_log_hint_parses_tqdm_line() -> None:
    backend = NativeBackend()
    hint = " 73%|███████▎| 102M/139M [01:31<00:33, 1.19MiB/s]"
    msg, pct, eta = backend._summarize_log_hint(hint)
    assert msg == "download: 73.0% (102M/139M), 1.19MiB/s, ETA 00:33"
    assert pct == 73.0
    assert eta == 33


def test_summarize_log_hint_parses_labeled_tqdm_line() -> None:
    backend = NativeBackend()
    hint = "Fetching 4 files: 50%|█████| 2/4 [00:02<00:01, 1.06it/s]"
    msg, pct, eta = backend._summarize_log_hint(hint)
    assert msg == "Fetching 4 files: 50.0% (2/4), 1.06it/s, ETA 00:01"
    assert pct == 50.0
    assert eta == 1


def test_model_only_start_stop_status(tmp_path: Path) -> None:
    backend = NativeBackend()
    spec = EngineSpec(
        name="whisper",
        default_runtime="native",
        options={
            "native_model_only": True,
            "native_model_dir": "models/whisper",
            "native_model_marker": "current.pt",
        },
    )
    cfg = RuntimeConfig(runtime="native", install_dir=str(tmp_path))
    model_dir = tmp_path / "whisper" / "models" / "whisper"
    model_dir.mkdir(parents=True, exist_ok=True)
    (model_dir / "current.pt").write_text("x", encoding="utf-8")

    events = []

    def _report(phase, message, progress):  # noqa: ANN001
        events.append((phase, progress, message))

    backend.start(spec, cfg, _report)
    status_running = backend.status(spec, cfg)
    assert status_running.running is True
    assert status_running.healthy is True
    assert "model-only" in status_running.detail

    backend.stop(spec, cfg, _report)
    status_stopped = backend.status(spec, cfg)
    assert status_stopped.running is False
    assert status_stopped.healthy is True


def test_existing_model_paths_prefers_aim_then_fallback(monkeypatch) -> None:
    backend = NativeBackend()

    def _fake_resolve(**kwargs):  # noqa: ANN003, ANN202
        assert kwargs["model_ids"] == ["m1"]
        return ["/a/one", "/a/two"]

    monkeypatch.setattr(native_backend, "resolve_aim_model_paths", _fake_resolve)
    opts = {
        "native_use_aim": True,
        "native_aim_model_ids": ["m1"],
        "native_existing_model_paths": ["/a/two", "/b/three"],
    }
    got = backend._existing_model_paths(opts)
    assert got == "/a/one:/a/two:/b/three"


def test_ensure_aim_models_falls_back_when_aim_missing(monkeypatch) -> None:
    backend = NativeBackend()
    events: list[tuple[str, str, float]] = []

    def _report(phase, message, progress):  # noqa: ANN001
        events.append((phase, message, progress))

    monkeypatch.setattr(native_backend.shutil, "which", lambda name: None if name == "aim" else "/usr/bin/x")
    opts = {
        "native_use_aim": True,
        "native_aim_model_ids": ["m1"],
    }
    backend._ensure_aim_models(opts, _report)
    assert any("fallback" in msg.lower() for _, msg, _ in events)


def test_ensure_aim_models_downloads_when_missing(monkeypatch) -> None:
    backend = NativeBackend()
    events: list[tuple[str, str, float]] = []
    calls: list[tuple[str, str, str]] = []
    state = {"resolved": False}

    def _report(phase, message, progress):  # noqa: ANN001
        events.append((phase, message, progress))

    def _fake_resolve(**kwargs):  # noqa: ANN003, ANN202
        if state["resolved"]:
            return ["/aim/model/m1"]
        return []

    def _fake_download(source: str, model_id: str, category: str = ""):  # noqa: ANN001, ANN202
        calls.append((source, model_id, category))
        state["resolved"] = True
        return True, "ok"

    monkeypatch.setattr(native_backend.shutil, "which", lambda name: "/usr/bin/aim" if name == "aim" else "/usr/bin/x")
    monkeypatch.setattr(native_backend, "resolve_aim_model_paths", _fake_resolve)
    monkeypatch.setattr(backend, "_aim_download", _fake_download)

    opts = {
        "native_use_aim": True,
        "native_aim_model_ids": ["m1"],
        "native_aim_downloads": [
            {"model_id": "m1", "source": "hf:org/repo", "category": "asr"}
        ],
        "native_aim_provision_engine": "whisper",
        "native_aim_model_kind": "dir",
    }
    backend._ensure_aim_models(opts, _report)
    assert calls == [("hf:org/repo", "m1", "asr")]
    assert any("completed" in msg.lower() for _, msg, _ in events)
