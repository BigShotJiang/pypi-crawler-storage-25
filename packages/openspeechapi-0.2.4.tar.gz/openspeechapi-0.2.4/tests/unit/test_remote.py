"""Tests for RemoteExecutor."""
from __future__ import annotations

import pytest

from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.core.enums import AudioFormat
from openspeechapi.dispatch.executors.remote import RemoteExecutor
from tests.conftest import FakeSTT, FakeSTTSettings, FakeTTS, FakeTTSSettings


@pytest.mark.asyncio
async def test_start_and_invoke():
    """start() + invoke() delegates to the provider."""
    executor = RemoteExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())

    audio = AudioData(data=b"audio", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
    result = await executor.invoke("transcribe", audio=audio)

    assert isinstance(result, Transcription)
    assert result.text == "fake transcription"
    await executor.stop()


@pytest.mark.asyncio
async def test_health_check_after_start():
    """health_check() returns True when provider is started."""
    executor = RemoteExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())
    assert await executor.health_check() is True
    await executor.stop()


@pytest.mark.asyncio
async def test_health_check_before_start():
    """health_check() returns False before start."""
    executor = RemoteExecutor()
    assert await executor.health_check() is False


@pytest.mark.asyncio
async def test_health_check_after_stop():
    """health_check() returns False after stop."""
    executor = RemoteExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())
    await executor.stop()
    assert await executor.health_check() is False


@pytest.mark.asyncio
async def test_invoke_stream():
    """invoke_stream() yields items from the provider."""
    executor = RemoteExecutor()
    await executor.start(FakeTTS, FakeTTSSettings())

    chunks = []
    async for chunk in executor.invoke_stream("synthesize_stream", text="hello"):
        chunks.append(chunk)

    assert len(chunks) == 2
    assert chunks[0].data == b"chunk1"
    assert chunks[1].is_final is True
    await executor.stop()


@pytest.mark.asyncio
async def test_invoke_before_start_raises():
    """invoke() before start() raises RuntimeError."""
    executor = RemoteExecutor()
    with pytest.raises(RuntimeError, match="Executor not started"):
        await executor.invoke("transcribe", audio=None)


@pytest.mark.asyncio
async def test_stop_is_idempotent():
    """stop() can be called multiple times without error."""
    executor = RemoteExecutor()
    await executor.start(FakeSTT, FakeSTTSettings())
    await executor.stop()
    await executor.stop()
