"""Tests for engine subcommands in openspeechapi.cli."""
from __future__ import annotations

from openspeechapi.cli import main
from openspeechapi.local_engines.models import EngineStatus
from openspeechapi.local_engines.tasks import EngineTask
from openspeechapi.local_engines.models import EngineAction, TaskStatus


class _FakeTask:
    def __init__(self) -> None:
        self._task = EngineTask(
            engine="fish-speech",
            action=EngineAction.START,
            runtime="docker",
            task_id="task-123",
            status=TaskStatus.SUCCEEDED,
            phase="completed",
            message="done",
            progress=100.0,
        )

    @property
    def task_id(self):
        return self._task.task_id

    @property
    def status(self):
        return self._task.status

    @property
    def updated_at(self):
        return self._task.updated_at

    @property
    def action(self):
        return self._task.action

    @property
    def phase(self):
        return self._task.phase

    @property
    def progress(self):
        return self._task.progress

    @property
    def message(self):
        return self._task.message

    @property
    def engine(self):
        return self._task.engine

    def snapshot(self):
        return self._task.snapshot()


class _FakeEmitter:
    def subscribe(self, _task_id):  # noqa: D401 ANN001
        import queue

        q = queue.Queue()
        return q

    def unsubscribe(self, _task_id, q):  # noqa: ANN001
        return None


class _FakeManager:
    def __init__(self) -> None:
        self.emitter = _FakeEmitter()
        self._task = _FakeTask()

    def run_action_async(self, name, action, cfg):  # noqa: ANN001
        return self._task

    def status(self, name, cfg):  # noqa: ANN001
        return EngineStatus(
            engine=name,
            runtime=cfg.runtime,
            running=True,
            healthy=True,
            detail="ok",
        )

    def logs(self, name, cfg, lines=100):  # noqa: ANN001
        return "fake logs"

    def get_task(self, task_id):  # noqa: ANN001
        if task_id == self._task.task_id:
            return self._task
        return None

    def list_tasks(self, engine=None, limit=20):  # noqa: ANN001
        return [self._task]

    def cancel_task(self, task_id):  # noqa: ANN001
        if task_id == self._task.task_id:
            return self._task
        return None


def test_engine_status_command(monkeypatch, capsys) -> None:  # noqa: ANN001
    monkeypatch.setattr("openspeechapi.cli.EngineManager", _FakeManager)
    main(["engine", "status", "--name", "fish-speech", "--runtime", "docker"])
    out = capsys.readouterr().out
    assert "engine=fish-speech" in out
    assert "running=True" in out


def test_engine_logs_command(monkeypatch, capsys) -> None:  # noqa: ANN001
    monkeypatch.setattr("openspeechapi.cli.EngineManager", _FakeManager)
    main(["engine", "logs", "--name", "fish-speech", "--runtime", "docker"])
    out = capsys.readouterr().out
    assert "fake logs" in out


def test_engine_task_status_command(monkeypatch, capsys) -> None:  # noqa: ANN001
    monkeypatch.setattr("openspeechapi.cli.EngineManager", _FakeManager)
    main(["engine", "task", "status", "--task-id", "task-123"])
    out = capsys.readouterr().out
    assert "task_id=task-123" in out


def test_engine_task_list_command(monkeypatch, capsys) -> None:  # noqa: ANN001
    monkeypatch.setattr("openspeechapi.cli.EngineManager", _FakeManager)
    main(["engine", "task", "list", "--name", "fish-speech", "--limit", "5"])
    out = capsys.readouterr().out
    assert "fish-speech" in out


def test_engine_task_cancel_command(monkeypatch, capsys) -> None:  # noqa: ANN001
    monkeypatch.setattr("openspeechapi.cli.EngineManager", _FakeManager)
    main(["engine", "task", "cancel", "--task-id", "task-123"])
    out = capsys.readouterr().out
    assert "Cancellation requested: task-123" in out
