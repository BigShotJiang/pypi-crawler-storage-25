"""Tests for openspeechapi.dispatch.fanout — FanOut/FanIn strategies."""
from __future__ import annotations
import pytest
from openspeechapi.core.models import Transcription
from openspeechapi.dispatch.fanout import (
    CollectAll,
    CustomMerge,
    FanOutResult,
    FirstCompleted,
    HighestConfidence,
    fan_out,
)
from openspeechapi.exceptions import FanOutAllFailedError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _ok(value):
    return value


async def _fail(msg="error"):
    raise RuntimeError(msg)


# ---------------------------------------------------------------------------
# FirstCompleted
# ---------------------------------------------------------------------------

class TestFirstCompleted:
    @pytest.mark.asyncio
    async def test_returns_first_success(self):
        tasks = {
            "a": _ok(Transcription(text="a")),
            "b": _ok(Transcription(text="b")),
        }
        result = await fan_out(tasks, FirstCompleted())
        assert result.text in ("a", "b")

    @pytest.mark.asyncio
    async def test_returns_success_when_one_fails(self):
        tasks = {
            "fail": _fail(),
            "ok": _ok(Transcription(text="ok")),
        }
        result = await fan_out(tasks, FirstCompleted())
        assert result.text == "ok"

    @pytest.mark.asyncio
    async def test_raises_when_all_fail(self):
        tasks = {
            "a": _fail("err-a"),
            "b": _fail("err-b"),
        }
        with pytest.raises(FanOutAllFailedError) as exc_info:
            await fan_out(tasks, FirstCompleted())
        assert "a" in exc_info.value.errors or "b" in exc_info.value.errors

    @pytest.mark.asyncio
    async def test_single_success_task(self):
        tasks = {"only": _ok(Transcription(text="only"))}
        result = await fan_out(tasks, FirstCompleted())
        assert result.text == "only"


# ---------------------------------------------------------------------------
# HighestConfidence
# ---------------------------------------------------------------------------

class TestHighestConfidence:
    @pytest.mark.asyncio
    async def test_picks_highest_confidence(self):
        tasks = {
            "low": _ok(Transcription(text="low", confidence=0.5)),
            "high": _ok(Transcription(text="high", confidence=0.95)),
            "mid": _ok(Transcription(text="mid", confidence=0.7)),
        }
        result = await fan_out(tasks, HighestConfidence())
        assert result.confidence == 0.95
        assert result.text == "high"

    @pytest.mark.asyncio
    async def test_raises_when_all_fail(self):
        tasks = {
            "a": _fail(),
            "b": _fail(),
        }
        with pytest.raises(FanOutAllFailedError):
            await fan_out(tasks, HighestConfidence())

    @pytest.mark.asyncio
    async def test_ignores_errors_picks_from_successes(self):
        tasks = {
            "fail": _fail(),
            "ok": _ok(Transcription(text="ok", confidence=0.8)),
        }
        result = await fan_out(tasks, HighestConfidence())
        assert result.text == "ok"

    @pytest.mark.asyncio
    async def test_handles_none_confidence_as_zero(self):
        tasks = {
            "no_conf": _ok(Transcription(text="no_conf", confidence=None)),
            "with_conf": _ok(Transcription(text="with_conf", confidence=0.6)),
        }
        result = await fan_out(tasks, HighestConfidence())
        assert result.text == "with_conf"


# ---------------------------------------------------------------------------
# CollectAll
# ---------------------------------------------------------------------------

class TestCollectAll:
    @pytest.mark.asyncio
    async def test_collects_all_successes(self):
        tasks = {
            "a": _ok(Transcription(text="a")),
            "b": _ok(Transcription(text="b")),
        }
        result = await fan_out(tasks, CollectAll())
        assert isinstance(result, FanOutResult)
        assert set(result.successes.keys()) == {"a", "b"}
        assert result.errors == {}

    @pytest.mark.asyncio
    async def test_collects_mixed_successes_and_errors(self):
        tasks = {
            "ok": _ok(Transcription(text="ok")),
            "fail": _fail("oops"),
        }
        result = await fan_out(tasks, CollectAll())
        assert "ok" in result.successes
        assert "fail" in result.errors
        assert isinstance(result.errors["fail"], RuntimeError)

    @pytest.mark.asyncio
    async def test_all_failures_no_successes(self):
        tasks = {
            "a": _fail(),
            "b": _fail(),
        }
        result = await fan_out(tasks, CollectAll())
        assert result.successes == {}
        assert set(result.errors.keys()) == {"a", "b"}


# ---------------------------------------------------------------------------
# CustomMerge
# ---------------------------------------------------------------------------

class TestCustomMerge:
    @pytest.mark.asyncio
    async def test_custom_merge_function_called(self):
        received = {}

        async def my_merge(results):
            received.update(results)
            return "custom"

        tasks = {"x": _ok(42)}
        result = await fan_out(tasks, CustomMerge(my_merge))
        assert result == "custom"
        assert "x" in received
