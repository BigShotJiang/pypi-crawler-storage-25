"""Tests for YAML config loading."""
from pathlib import Path
from textwrap import dedent

import pytest

from openspeechapi.config import load_config, interpolate_env
from openspeechapi.exceptions import ConfigError


class TestInterpolateEnv:
    def test_simple_interpolation(self, monkeypatch):
        monkeypatch.setenv("MY_KEY", "secret123")
        assert interpolate_env("${MY_KEY}") == "secret123"

    def test_missing_var_raises(self):
        with pytest.raises(ConfigError, match="MY_MISSING"):
            interpolate_env("${MY_MISSING}")

    def test_escaped_dollar(self):
        assert interpolate_env("$$literal") == "$literal"

    def test_no_interpolation_needed(self):
        assert interpolate_env("plain_value") == "plain_value"

    def test_mixed_text_and_var(self, monkeypatch):
        monkeypatch.setenv("HOST", "localhost")
        assert interpolate_env("http://${HOST}:8080") == "http://localhost:8080"


class TestLoadConfig:
    def test_load_minimal_config(self, tmp_path):
        cfg_file = tmp_path / "providers.yaml"
        cfg_file.write_text(dedent("""\
            providers:
              fake-stt:
                provider: fake
                exec_mode: in_process
                settings:
                  model: tiny
        """))
        config = load_config(cfg_file)
        assert "fake-stt" in config.engines
        p = config.engines["fake-stt"]
        assert p.provider == "fake"
        assert p.exec_mode == "in_process"
        assert p.settings["model"] == "tiny"

    def test_load_with_env_var(self, tmp_path, monkeypatch):
        monkeypatch.setenv("API_KEY", "sk-test")
        cfg_file = tmp_path / "providers.yaml"
        cfg_file.write_text(dedent("""\
            providers:
              cloud:
                provider: openai
                exec_mode: in_process
                settings:
                  api_key: ${API_KEY}
        """))
        config = load_config(cfg_file)
        assert config.engines["cloud"].settings["api_key"] == "sk-test"

    def test_missing_file_raises(self):
        with pytest.raises(ConfigError, match="not found"):
            load_config(Path("/nonexistent/providers.yaml"))

    def test_load_with_filters(self, tmp_path):
        cfg_file = tmp_path / "providers.yaml"
        cfg_file.write_text(dedent("""\
            providers:
              stt-1:
                provider: fake
                exec_mode: in_process
                settings: {}
                filters:
                  - type: confidence
                    min: 0.8
        """))
        config = load_config(cfg_file)
        assert len(config.engines["stt-1"].filters) == 1
        assert config.engines["stt-1"].filters[0]["type"] == "confidence"
