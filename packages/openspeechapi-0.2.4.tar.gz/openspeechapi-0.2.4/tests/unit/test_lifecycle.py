"""Tests for provider lifecycle manager."""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock
from openspeechapi.dispatch.lifecycle import ProviderLifecycleManager, ProviderState


class FakeHandle:
    def __init__(self):
        self.provider_cls = MagicMock()
        self.provider_cls.settings_cls = MagicMock(return_value=MagicMock())
        self.executor = MagicMock()
        self.executor.start = AsyncMock()
        self.executor.stop = AsyncMock()
        self.settings_dict = {}


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_initial_state_is_registered(self):
        mgr = ProviderLifecycleManager()
        mgr.register("test", FakeHandle())
        assert mgr.get_state("test") == ProviderState.REGISTERED

    @pytest.mark.asyncio
    async def test_ensure_ready_starts_provider(self):
        mgr = ProviderLifecycleManager()
        handle = FakeHandle()
        mgr.register("test", handle)
        await mgr.ensure_ready("test")
        assert mgr.get_state("test") == ProviderState.READY
        handle.executor.start.assert_called_once()

    @pytest.mark.asyncio
    async def test_ensure_ready_idempotent(self):
        mgr = ProviderLifecycleManager()
        handle = FakeHandle()
        mgr.register("test", handle)
        await mgr.ensure_ready("test")
        await mgr.ensure_ready("test")
        assert handle.executor.start.call_count == 1  # only started once

    @pytest.mark.asyncio
    async def test_stop_provider(self):
        mgr = ProviderLifecycleManager()
        handle = FakeHandle()
        mgr.register("test", handle)
        await mgr.ensure_ready("test")
        await mgr.stop_provider("test")
        assert mgr.get_state("test") == ProviderState.STOPPED

    @pytest.mark.asyncio
    async def test_restart_after_stop(self):
        mgr = ProviderLifecycleManager()
        handle = FakeHandle()
        mgr.register("test", handle)
        await mgr.ensure_ready("test")
        await mgr.stop_provider("test")
        await mgr.ensure_ready("test")  # should restart
        assert handle.executor.start.call_count == 2

    @pytest.mark.asyncio
    async def test_unknown_provider_raises(self):
        mgr = ProviderLifecycleManager()
        from openspeechapi.exceptions import ProviderNotFoundError
        with pytest.raises(ProviderNotFoundError):
            await mgr.ensure_ready("nonexistent")

    @pytest.mark.asyncio
    async def test_idle_ttl_stops_provider(self):
        mgr = ProviderLifecycleManager()
        mgr._check_interval = 0.1  # fast check for testing
        handle = FakeHandle()
        mgr.register("test", handle, keepalive=1)  # 1 second TTL
        await mgr.ensure_ready("test")
        # Manually set last_used to the past
        import time
        mgr._entries["test"].last_used = time.monotonic() - 2
        mgr.start_idle_checker()
        await asyncio.sleep(0.3)  # let checker run
        assert mgr.get_state("test") == ProviderState.STOPPED
        await mgr.stop_all()

    @pytest.mark.asyncio
    async def test_keepalive_zero_never_stops(self):
        mgr = ProviderLifecycleManager()
        mgr._check_interval = 0.1
        handle = FakeHandle()
        mgr.register("test", handle, keepalive=0)
        await mgr.ensure_ready("test")
        import time
        mgr._entries["test"].last_used = time.monotonic() - 1000
        mgr.start_idle_checker()
        await asyncio.sleep(0.3)
        assert mgr.get_state("test") == ProviderState.READY
        await mgr.stop_all()

    @pytest.mark.asyncio
    async def test_touch_resets_timer(self):
        mgr = ProviderLifecycleManager()
        handle = FakeHandle()
        mgr.register("test", handle, keepalive=5)
        await mgr.ensure_ready("test")
        import time
        old_time = mgr._entries["test"].last_used
        await asyncio.sleep(0.01)
        mgr.touch("test")
        assert mgr._entries["test"].last_used > old_time

    def test_list_states(self):
        mgr = ProviderLifecycleManager()
        mgr.register("a", FakeHandle())
        mgr.register("b", FakeHandle())
        states = mgr.list_states()
        assert states == {"a": "registered", "b": "registered"}
