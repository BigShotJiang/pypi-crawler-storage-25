"""Tests for openspeechapi.observe.debug — DebugLogObserver (smoke tests)."""
from __future__ import annotations
import pytest
from openspeechapi.core.enums import ExecMode
from openspeechapi.dispatch.context import InvokeContext
from openspeechapi.observe.debug import DebugLogObserver


def _make_ctx() -> InvokeContext:
    return InvokeContext(provider_name="stt1", method="transcribe", exec_mode=ExecMode.IN_PROCESS)


class TestDebugLogObserverSmoke:
    @pytest.mark.asyncio
    async def test_on_invoke_start_does_not_raise(self):
        obs = DebugLogObserver()
        ctx = _make_ctx()
        await obs.on_invoke_start(ctx)

    @pytest.mark.asyncio
    async def test_on_invoke_end_does_not_raise(self):
        obs = DebugLogObserver()
        ctx = _make_ctx()
        ctx.record_end()
        await obs.on_invoke_end(ctx, result="some_result")

    @pytest.mark.asyncio
    async def test_on_invoke_error_does_not_raise(self):
        obs = DebugLogObserver()
        ctx = _make_ctx()
        await obs.on_invoke_error(ctx, error=RuntimeError("oops"))

    @pytest.mark.asyncio
    async def test_on_stream_chunk_does_not_raise(self):
        obs = DebugLogObserver()
        ctx = _make_ctx()
        await obs.on_stream_chunk(ctx, chunk=b"audio_bytes")

    @pytest.mark.asyncio
    async def test_on_provider_start_does_not_raise(self):
        obs = DebugLogObserver()
        await obs.on_provider_start("stt1", ExecMode.IN_PROCESS)

    @pytest.mark.asyncio
    async def test_on_provider_stop_does_not_raise(self):
        obs = DebugLogObserver()
        await obs.on_provider_stop("stt1")

    @pytest.mark.asyncio
    async def test_on_health_change_does_not_raise(self):
        obs = DebugLogObserver()
        await obs.on_health_change("stt1", True)
