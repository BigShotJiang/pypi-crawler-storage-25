"""Tests for openspeechapi.dispatch.filters — ResultFilter chain."""
from __future__ import annotations
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.dispatch.filters import (
    AudioFormatFilter,
    ConfidenceFilter,
    DurationFilter,
    FilterChain,
    LanguageFilter,
)


# ---------------------------------------------------------------------------
# ConfidenceFilter
# ---------------------------------------------------------------------------

class TestConfidenceFilter:
    def test_passes_result_above_threshold(self):
        f = ConfidenceFilter(min_confidence=0.8)
        result = Transcription(text="hello", confidence=0.95)
        assert f.should_pass(result) is True

    def test_passes_result_at_threshold(self):
        f = ConfidenceFilter(min_confidence=0.8)
        result = Transcription(text="hello", confidence=0.8)
        assert f.should_pass(result) is True

    def test_drops_result_below_threshold(self):
        f = ConfidenceFilter(min_confidence=0.8)
        result = Transcription(text="hello", confidence=0.5)
        assert f.should_pass(result) is False

    def test_passes_result_with_no_confidence(self):
        f = ConfidenceFilter(min_confidence=0.8)
        result = Transcription(text="hello", confidence=None)
        assert f.should_pass(result) is True

    def test_passes_object_without_confidence_attr(self):
        f = ConfidenceFilter(min_confidence=0.8)
        assert f.should_pass("plain string") is True

    def test_transform_returns_unchanged(self):
        f = ConfidenceFilter(min_confidence=0.8)
        result = Transcription(text="hi", confidence=0.9)
        assert f.transform(result) is result


# ---------------------------------------------------------------------------
# LanguageFilter
# ---------------------------------------------------------------------------

class TestLanguageFilter:
    def test_passes_allowed_language(self):
        f = LanguageFilter(allow=["en", "zh"])
        result = Transcription(text="hello", language="en")
        assert f.should_pass(result) is True

    def test_drops_disallowed_language(self):
        f = LanguageFilter(allow=["en"])
        result = Transcription(text="bonjour", language="fr")
        assert f.should_pass(result) is False

    def test_passes_when_language_is_none(self):
        f = LanguageFilter(allow=["en"])
        result = Transcription(text="unknown", language=None)
        assert f.should_pass(result) is True

    def test_passes_object_without_language_attr(self):
        f = LanguageFilter(allow=["en"])
        assert f.should_pass(42) is True


# ---------------------------------------------------------------------------
# DurationFilter
# ---------------------------------------------------------------------------

class TestDurationFilter:
    def test_passes_duration_above_minimum(self):
        f = DurationFilter(min_ms=100)
        result = Transcription(text="hi", duration_ms=500)
        assert f.should_pass(result) is True

    def test_passes_duration_at_minimum(self):
        f = DurationFilter(min_ms=100)
        result = Transcription(text="hi", duration_ms=100)
        assert f.should_pass(result) is True

    def test_drops_duration_below_minimum(self):
        f = DurationFilter(min_ms=100)
        result = Transcription(text="hi", duration_ms=50)
        assert f.should_pass(result) is False

    def test_passes_when_duration_is_none(self):
        f = DurationFilter(min_ms=100)
        result = Transcription(text="hi", duration_ms=None)
        assert f.should_pass(result) is True


# ---------------------------------------------------------------------------
# AudioFormatFilter
# ---------------------------------------------------------------------------

class TestAudioFormatFilter:
    def test_transform_unchanged_when_format_matches(self):
        f = AudioFormatFilter(target=AudioFormat.PCM_16K)
        audio = AudioData(data=b"x", sample_rate=16000, channels=1,
                          format=AudioFormat.PCM_16K, duration_ms=100)
        result = f.transform(audio)
        assert result is audio

    def test_transform_updates_format_when_different(self):
        f = AudioFormatFilter(target=AudioFormat.PCM_16K)
        audio = AudioData(data=b"x", sample_rate=16000, channels=1,
                          format=AudioFormat.WAV, duration_ms=100)
        result = f.transform(audio)
        assert result.format == AudioFormat.PCM_16K
        assert result.data == b"x"

    def test_transform_passthrough_non_audio(self):
        f = AudioFormatFilter(target=AudioFormat.PCM_16K)
        t = Transcription(text="hi")
        assert f.transform(t) is t

    def test_should_pass_always_true(self):
        f = AudioFormatFilter(target=AudioFormat.PCM_16K)
        assert f.should_pass("anything") is True


# ---------------------------------------------------------------------------
# FilterChain
# ---------------------------------------------------------------------------

class TestFilterChain:
    def test_empty_chain_returns_result_unchanged(self):
        chain = FilterChain([])
        t = Transcription(text="hi", confidence=0.5)
        assert chain.apply(t) is t

    def test_all_filters_pass_returns_result(self):
        chain = FilterChain([
            ConfidenceFilter(min_confidence=0.8),
            LanguageFilter(allow=["en"]),
        ])
        t = Transcription(text="hello", confidence=0.9, language="en")
        result = chain.apply(t)
        assert result is t

    def test_first_filter_drops_returns_none(self):
        chain = FilterChain([
            ConfidenceFilter(min_confidence=0.9),
            LanguageFilter(allow=["en"]),
        ])
        t = Transcription(text="hello", confidence=0.5, language="en")
        assert chain.apply(t) is None

    def test_second_filter_drops_returns_none(self):
        chain = FilterChain([
            ConfidenceFilter(min_confidence=0.8),
            LanguageFilter(allow=["en"]),
        ])
        t = Transcription(text="bonjour", confidence=0.9, language="fr")
        assert chain.apply(t) is None

    def test_transform_is_applied_through_chain(self):
        f = AudioFormatFilter(target=AudioFormat.PCM_16K)
        chain = FilterChain([f])
        audio = AudioData(data=b"x", sample_rate=16000, channels=1,
                          format=AudioFormat.WAV, duration_ms=100)
        result = chain.apply(audio)
        assert result.format == AudioFormat.PCM_16K
