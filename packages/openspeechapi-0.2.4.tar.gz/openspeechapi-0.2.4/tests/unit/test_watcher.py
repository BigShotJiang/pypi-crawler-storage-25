"""Tests for ConfigWatcher."""
from __future__ import annotations

import asyncio
import os
import time
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from openspeechapi.dispatch.watcher import ConfigWatcher


@pytest.fixture
def config_file(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text("providers: {}")
    return cfg


@pytest.mark.asyncio
async def test_watcher_detects_config_change(config_file):
    """Watcher calls on_reload when providers.yaml mtime increases."""
    callback = AsyncMock(return_value={"added": [], "removed": [], "updated": [], "unchanged": []})
    watcher = ConfigWatcher(config_file, on_reload=callback, debounce_s=0.0)
    watcher._poll_interval = 0.05

    watcher.start()
    try:
        # Bump mtime after watcher has recorded initial state
        await asyncio.sleep(0.01)
        new_mtime = time.time() + 1
        os.utime(config_file, (new_mtime, new_mtime))
        # Allow watcher to detect and call back
        await asyncio.sleep(0.3)
    finally:
        await watcher.stop()

    assert callback.await_count >= 1


@pytest.mark.asyncio
async def test_watcher_no_callback_when_unchanged(config_file):
    """Watcher does not call on_reload when file has not changed."""
    callback = AsyncMock(return_value={})
    watcher = ConfigWatcher(config_file, on_reload=callback, debounce_s=0.0)
    watcher._poll_interval = 0.05

    watcher.start()
    try:
        await asyncio.sleep(0.2)
    finally:
        await watcher.stop()

    callback.assert_not_awaited()


@pytest.mark.asyncio
async def test_watcher_debounces_rapid_changes(config_file):
    """Watcher makes a single callback even when file changes multiple times quickly."""
    call_times: list[float] = []

    async def slow_callback():
        call_times.append(time.monotonic())
        return {}

    watcher = ConfigWatcher(config_file, on_reload=slow_callback, debounce_s=0.05)
    watcher._poll_interval = 0.05

    watcher.start()
    try:
        await asyncio.sleep(0.01)
        # Trigger one change; the watcher will detect it and debounce
        new_mtime = time.time() + 1
        os.utime(config_file, (new_mtime, new_mtime))
        await asyncio.sleep(0.4)
    finally:
        await watcher.stop()

    # Should have been called at most twice (one poll cycle)
    assert len(call_times) <= 2


@pytest.mark.asyncio
async def test_watcher_detects_env_change(config_file):
    """Watcher calls on_reload when .env mtime increases."""
    env_file = config_file.parent / ".env"
    env_file.write_text("KEY=value")

    callback = AsyncMock(return_value={})
    watcher = ConfigWatcher(config_file, on_reload=callback, debounce_s=0.0)
    watcher._poll_interval = 0.05

    watcher.start()
    try:
        await asyncio.sleep(0.01)
        new_mtime = time.time() + 1
        os.utime(env_file, (new_mtime, new_mtime))
        await asyncio.sleep(0.3)
    finally:
        await watcher.stop()

    assert callback.await_count >= 1


@pytest.mark.asyncio
async def test_watcher_reloads_env_vars(config_file, tmp_path, monkeypatch):
    """Watcher re-reads .env vars into os.environ on change."""
    env_file = config_file.parent / ".env"
    env_file.write_text("HOT_RELOAD_TEST_VAR=initial")

    loaded_values: list[str] = []

    async def capture_env():
        loaded_values.append(os.environ.get("HOT_RELOAD_TEST_VAR", "<missing>"))
        return {}

    watcher = ConfigWatcher(config_file, on_reload=capture_env, debounce_s=0.0)
    watcher._poll_interval = 0.05

    watcher.start()
    try:
        await asyncio.sleep(0.01)
        # Rewrite .env with new value
        env_file.write_text("HOT_RELOAD_TEST_VAR=updated")
        new_mtime = time.time() + 1
        os.utime(env_file, (new_mtime, new_mtime))
        await asyncio.sleep(0.3)
    finally:
        await watcher.stop()
        # Cleanup
        os.environ.pop("HOT_RELOAD_TEST_VAR", None)

    assert len(loaded_values) >= 1
    assert loaded_values[-1] == "updated"


@pytest.mark.asyncio
async def test_watcher_stop_cancels_task(config_file):
    """Stopping the watcher cleanly cancels the background task."""
    callback = AsyncMock(return_value={})
    watcher = ConfigWatcher(config_file, on_reload=callback, debounce_s=0.0)
    watcher._poll_interval = 0.05

    watcher.start()
    task = watcher._task
    assert task is not None
    assert not task.done()

    await watcher.stop()

    assert watcher._task is None
    assert task.done()


@pytest.mark.asyncio
async def test_watcher_handles_reload_error(config_file, caplog):
    """Watcher logs errors from on_reload without crashing."""
    import logging

    async def failing_callback():
        raise RuntimeError("reload exploded")

    watcher = ConfigWatcher(config_file, on_reload=failing_callback, debounce_s=0.0)
    watcher._poll_interval = 0.05

    watcher.start()
    try:
        await asyncio.sleep(0.01)
        new_mtime = time.time() + 1
        os.utime(config_file, (new_mtime, new_mtime))
        # Give watcher time to hit the error and keep running
        await asyncio.sleep(0.3)
        # Task should still be alive (not crashed)
        assert watcher._task is not None
        assert not watcher._task.done()
    finally:
        await watcher.stop()
