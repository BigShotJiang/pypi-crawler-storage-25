"""Tests for openspeechapi.logging_config and openspeechapi.telemetry.perf."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
from loguru import logger as _host_logger

from openspeechapi.logging_config import (
    LogSettings,
    bind_context,
    configure_logging,
    ensure_configured,
    get_integration_tag,
    get_log_settings,
    get_request_id,
    integrate_with_host,
    is_host_managed,
    logger,
    openspeech_filter,
    openspeech_level_filter,
)
from openspeechapi.telemetry.perf import Event, PerfTimer, milestone, perf_enabled


@pytest.fixture(autouse=True)
def _reset_integration_state():
    """Ensure host-integration flags and sinks don't leak between tests."""
    from openspeechapi import logging_config as lc
    yield
    lc._INTEGRATION["tag"] = "openspeechapi"
    lc._INTEGRATION["level"] = None
    lc._INTEGRATION["host_managed"] = False
    lc._remove_os_sinks()
    _host_logger.remove()
    _host_logger.add(sys.stderr, level="DEBUG")


# ---------------------------------------------------------------------------
# configure_logging
# ---------------------------------------------------------------------------


def test_configure_logging_returns_settings(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENSPEECH_LOG_LEVEL", raising=False)
    monkeypatch.delenv("OPENSPEECH_LOG_FORMAT", raising=False)
    monkeypatch.delenv("OPENSPEECH_LOG_DIR", raising=False)
    monkeypatch.delenv("OPENSPEECH_LOG_PERF", raising=False)
    settings = configure_logging(
        level="DEBUG",
        format="json",
        log_dir=str(tmp_path),
        perf="verbose",
    )
    assert isinstance(settings, LogSettings)
    assert settings.level == "DEBUG"
    assert settings.format == "json"
    assert settings.perf == "verbose"
    assert settings.log_dir == tmp_path
    # Current global should match.
    assert get_log_settings().level == "DEBUG"


def test_configure_logging_env_fallback(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENSPEECH_LOG_LEVEL", "warning")
    monkeypatch.setenv("OPENSPEECH_LOG_FORMAT", "json")
    monkeypatch.setenv("OPENSPEECH_LOG_PERF", "off")
    monkeypatch.setenv("OPENSPEECH_LOG_DIR", str(tmp_path))
    s = configure_logging()
    assert s.level == "WARNING"
    assert s.format == "json"
    assert s.perf == "off"
    assert s.log_dir == tmp_path


def test_configure_logging_disable_file_output(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENSPEECH_LOG_DIR", raising=False)
    s = configure_logging(log_dir="")
    assert s.log_dir is None


# ---------------------------------------------------------------------------
# bind_context
# ---------------------------------------------------------------------------


def test_bind_context_sets_and_resets_request_id() -> None:
    assert get_request_id() is None
    with bind_context(request_id="rid-outer"):
        assert get_request_id() == "rid-outer"
        with bind_context(request_id="rid-inner"):
            assert get_request_id() == "rid-inner"
        assert get_request_id() == "rid-outer"
    assert get_request_id() is None


def test_bind_context_decorates_log_records(tmp_path: Path) -> None:
    configure_logging(level="DEBUG", format="json", log_dir=str(tmp_path))
    captured: list[dict] = []

    def _sink(message):
        captured.append(dict(message.record["extra"]))

    sink_id = logger.add(_sink, level="DEBUG")
    try:
        with bind_context(request_id="abc123", provider="foo-tts"):
            logger.info("hello")
    finally:
        logger.remove(sink_id)

    assert captured, "expected at least one captured record"
    last = captured[-1]
    assert last.get("request_id") == "abc123"
    assert last.get("provider") == "foo-tts"


# ---------------------------------------------------------------------------
# JSON file sink end-to-end
# ---------------------------------------------------------------------------


def test_jsonl_file_output_is_valid_json(tmp_path: Path) -> None:
    configure_logging(level="INFO", format="text", log_dir=str(tmp_path), perf="basic")
    with bind_context(request_id="req-file-1", provider="p1"):
        milestone(Event.WS_ACCEPT, scope="stt")
    # flush async sink
    logger.complete()
    log_file = tmp_path / "openspeechapi.jsonl"
    assert log_file.exists(), f"expected log file at {log_file}"
    lines = [ln for ln in log_file.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert lines, "no JSON lines written"
    records = [json.loads(ln) for ln in lines]
    # At least one record should carry event=ws.accept with the request_id.
    matches = [
        r for r in records
        if r.get("event") == "ws.accept" and r.get("request_id") == "req-file-1"
    ]
    assert matches, f"ws.accept not found in {records}"
    rec = matches[0]
    assert rec["provider"] == "p1"
    assert rec["level"] == "INFO"


# ---------------------------------------------------------------------------
# PerfTimer + perf_enabled gating
# ---------------------------------------------------------------------------


def test_perf_enabled_respects_global_level(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENSPEECH_LOG_PERF", raising=False)
    configure_logging(perf="off")
    assert perf_enabled("basic") is False
    assert perf_enabled("verbose") is False
    configure_logging(perf="basic")
    assert perf_enabled("basic") is True
    assert perf_enabled("verbose") is False
    configure_logging(perf="verbose")
    assert perf_enabled("basic") is True
    assert perf_enabled("verbose") is True


def test_perf_timer_emits_elapsed_ms(tmp_path: Path) -> None:
    configure_logging(level="INFO", format="json", log_dir=str(tmp_path), perf="basic")
    captured: list[dict] = []

    def _sink(message):
        captured.append(dict(message.record["extra"]))

    sink_id = logger.add(_sink, level="INFO")
    try:
        with PerfTimer(Event.DISPATCH_TOTAL, method="transcribe") as t:
            t.add(bytes=42)
            t.mark_ttfb()
    finally:
        logger.remove(sink_id)

    matches = [r for r in captured if r.get("event") == "dispatch.total"]
    assert matches, f"dispatch.total not found in {captured}"
    rec = matches[-1]
    assert "elapsed_ms" in rec
    assert rec["elapsed_ms"] >= 0
    assert rec.get("method") == "transcribe"
    assert rec.get("bytes") == 42
    assert "ttfb_ms" in rec


def test_perf_timer_off_level_suppresses_emit(tmp_path: Path) -> None:
    configure_logging(level="INFO", format="text", log_dir=str(tmp_path), perf="off")
    captured: list[dict] = []

    def _sink(message):
        captured.append(dict(message.record["extra"]))

    sink_id = logger.add(_sink, level="INFO")
    try:
        with PerfTimer(Event.DISPATCH_TOTAL, method="transcribe"):
            pass
        milestone(Event.WS_ACCEPT)
    finally:
        logger.remove(sink_id)
    events = [r.get("event") for r in captured]
    assert "dispatch.total" not in events
    assert "ws.accept" not in events


def test_perf_timer_captures_exception_info(tmp_path: Path) -> None:
    configure_logging(level="INFO", format="json", log_dir=str(tmp_path), perf="basic")
    captured: list[dict] = []

    def _sink(message):
        captured.append(dict(message.record["extra"]))

    sink_id = logger.add(_sink, level="INFO")
    try:
        with pytest.raises(RuntimeError):
            with PerfTimer(Event.DISPATCH_INVOKE_ERROR):
                raise RuntimeError("boom")
    finally:
        logger.remove(sink_id)
    matches = [r for r in captured if r.get("event") == "dispatch.invoke_error"]
    assert matches
    rec = matches[-1]
    assert rec.get("error_type") == "RuntimeError"
    assert "boom" in rec.get("error_message", "")


# ---------------------------------------------------------------------------
# Host integration — wallex-style piggybacking on an external loguru setup
# ---------------------------------------------------------------------------


def test_openspeech_records_carry_component_tag(tmp_path: Path) -> None:
    """Every record emitted through the shared ``logger`` carries the tag."""
    captured: list[dict] = []

    def _sink(message):
        captured.append(dict(message.record["extra"]))

    _host_logger.remove()
    sink_id = _host_logger.add(_sink, level="DEBUG")
    try:
        logger.info("hello")
        milestone(Event.WS_ACCEPT, scope="stt")
    finally:
        _host_logger.remove(sink_id)

    # Both records must carry component=openspeechapi (the default tag).
    tags = [rec.get("component") for rec in captured]
    assert tags, "no records captured"
    assert all(t == "openspeechapi" for t in tags), f"got tags={tags}"


def test_integrate_with_host_does_not_remove_host_sinks() -> None:
    """Host sinks are preserved; OS-owned sinks are dropped."""
    # Simulate a host application that registered its own sink before
    # OpenSpeechAPI was imported/configured.
    captured: list[tuple[str, str, str]] = []

    def _host_sink(message):
        extra = message.record["extra"]
        captured.append(
            (
                extra.get("component", ""),
                message.record["level"].name,
                message.record["message"],
            )
        )

    _host_logger.remove()
    host_sink_id = _host_logger.add(_host_sink, level="DEBUG")
    try:
        integrate_with_host(tag="wallex-os", level="INFO")
        assert is_host_managed() is True
        assert get_integration_tag() == "wallex-os"
        logger.info("from openspeechapi")
        _host_logger.info("from wallex")  # host record has no component tag
    finally:
        _host_logger.remove(host_sink_id)

    # OpenSpeechAPI record must show up with the new tag.
    assert ("wallex-os", "INFO", "from openspeechapi") in captured, captured
    # Host record still reaches host sink untouched (empty component).
    assert ("", "INFO", "from wallex") in captured, captured


def test_openspeech_level_filter_overrides_only_os_records() -> None:
    """Host records bypass the filter; OpenSpeechAPI records obey min_level."""
    captured: list[tuple[str, str, str]] = []

    def _sink(message):
        extra = message.record["extra"]
        captured.append(
            (
                extra.get("component", ""),
                message.record["level"].name,
                message.record["message"],
            )
        )

    _host_logger.remove()
    sink_id = _host_logger.add(
        _sink,
        level="DEBUG",
        filter=openspeech_level_filter("WARNING"),
    )
    try:
        integrate_with_host(tag="openspeechapi")
        logger.debug("os-debug")     # dropped (below WARNING)
        logger.warning("os-warn")    # kept
        _host_logger.debug("host-debug")  # kept (host bypasses OS filter)
        _host_logger.info("host-info")    # kept
    finally:
        _host_logger.remove(sink_id)

    messages = [m for (_tag, _lvl, m) in captured]
    assert "os-warn" in messages
    assert "os-debug" not in messages
    assert "host-debug" in messages
    assert "host-info" in messages


def test_openspeech_filter_accepts_only_os_records() -> None:
    """``openspeech_filter`` routes only OpenSpeechAPI records to a dedicated sink."""
    captured: list[str] = []

    def _sink(message):
        captured.append(message.record["message"])

    _host_logger.remove()
    sink_id = _host_logger.add(_sink, filter=openspeech_filter, level="DEBUG")
    try:
        integrate_with_host(tag="openspeechapi")
        logger.info("from-os")
        _host_logger.info("from-host")
    finally:
        _host_logger.remove(sink_id)

    assert "from-os" in captured
    assert "from-host" not in captured


def test_ensure_configured_noop_after_integrate_with_host() -> None:
    """After handing off to a host, ensure_configured() must not re-add sinks."""
    from openspeechapi import logging_config as lc

    integrate_with_host(tag="openspeechapi")
    before = list(lc._OS_SINK_IDS)
    ensure_configured()
    after = list(lc._OS_SINK_IDS)
    assert before == after
    assert is_host_managed() is True


def test_integrate_with_host_attach_sinks_keeps_os_console_sink(tmp_path: Path) -> None:
    """``attach_sinks=True`` keeps our sinks *in addition to* host sinks."""
    from openspeechapi import logging_config as lc

    _host_logger.remove()
    host_sink_id = _host_logger.add(sys.stderr, level="DEBUG")
    try:
        integrate_with_host(
            tag="openspeechapi",
            level="DEBUG",
            attach_sinks=True,
        )
        # At least the OS console sink should be registered in addition
        # to host's stderr sink.
        assert len(lc._OS_SINK_IDS) >= 1
        assert is_host_managed() is False
    finally:
        _host_logger.remove(host_sink_id)
        lc._remove_os_sinks()
