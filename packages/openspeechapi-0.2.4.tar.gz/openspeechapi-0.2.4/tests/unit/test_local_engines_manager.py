"""Tests for local engine manager task/progress behavior."""
from __future__ import annotations

import time

from openspeechapi.local_engines import EngineAction, EngineManager, RuntimeConfig
from openspeechapi.local_engines.models import EngineStatus, TaskStatus


class _FakeBackend:
    runtime_name = "docker"

    def install(self, spec, cfg, report):  # noqa: ANN001
        report("pull_image", "pulling", 40)
        report("done", "done", 100)

    def update(self, spec, cfg, report):  # noqa: ANN001
        report("update", "updating", 50)
        report("done", "done", 100)

    def start(self, spec, cfg, report):  # noqa: ANN001
        report("start_container", "starting", 70)
        report("ready", "healthy", 100)

    def stop(self, spec, cfg, report):  # noqa: ANN001
        report("stop_container", "stopping", 90)
        report("done", "stopped", 100)

    def status(self, spec, cfg):  # noqa: ANN001
        return EngineStatus(
            engine=spec.name,
            runtime="docker",
            running=True,
            healthy=True,
            detail="ok",
        )

    def logs(self, spec, cfg, lines=100):  # noqa: ANN001
        return "engine log line"


def test_run_action_emits_progress_and_succeeds() -> None:
    mgr = EngineManager()
    mgr._backends["docker"] = _FakeBackend()  # type: ignore[attr-defined]
    q = mgr.emitter.subscribe_all()

    task = mgr.run_action(
        "fish-speech",
        EngineAction.INSTALL,
        RuntimeConfig(runtime="docker"),
    )
    assert task.status == TaskStatus.SUCCEEDED
    assert task.progress == 100.0

    events = []
    while not q.empty():
        events.append(q.get_nowait())
    phases = [e.phase for e in events if e.action == "install"]
    assert "pull_image" in phases
    assert "completed" in phases


def test_status_and_logs() -> None:
    mgr = EngineManager()
    mgr._backends["docker"] = _FakeBackend()  # type: ignore[attr-defined]
    cfg = RuntimeConfig(runtime="docker")
    s = mgr.status("fish-speech", cfg)
    assert s.running is True
    assert "log" in mgr.logs("fish-speech", cfg)


def test_cancel_running_task() -> None:
    class _SlowBackend(_FakeBackend):
        def install(self, spec, cfg, report):  # noqa: ANN001
            for i in range(100):
                report("pull_image", f"pulling {i}", min(99.0, float(i)))
                time.sleep(0.01)

    mgr = EngineManager()
    mgr._backends["docker"] = _SlowBackend()  # type: ignore[attr-defined]
    task = mgr.run_action_async(
        "fish-speech",
        EngineAction.INSTALL,
        RuntimeConfig(runtime="docker"),
    )
    time.sleep(0.05)
    mgr.cancel_task(task.task_id)

    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        latest = mgr.get_task(task.task_id)
        if latest is not None and latest.status in {
            TaskStatus.SUCCEEDED,
            TaskStatus.FAILED,
            TaskStatus.CANCELLED,
        }:
            break
        time.sleep(0.02)

    latest = mgr.get_task(task.task_id)
    assert latest is not None
    assert latest.status == TaskStatus.CANCELLED
