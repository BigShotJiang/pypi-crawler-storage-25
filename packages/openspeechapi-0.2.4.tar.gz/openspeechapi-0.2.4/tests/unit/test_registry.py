"""Tests for provider registry."""
import pytest

from openspeechapi.core.enums import Capability, ProviderType
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.exceptions import ProviderNotFoundError


class FakeProviderCls:
    name = "fake-stt"
    provider_type = ProviderType.STT
    capabilities = {Capability.BATCH, Capability.MULTILINGUAL}


class FakeTTSCls:
    name = "fake-tts"
    provider_type = ProviderType.TTS
    capabilities = {Capability.STREAMING}


class TestProviderRegistry:
    def setup_method(self):
        self.registry = ProviderRegistry()

    def test_register_and_get(self):
        self.registry.register("fake-stt", FakeProviderCls)
        assert self.registry.get("fake-stt") is FakeProviderCls

    def test_get_not_found_raises(self):
        with pytest.raises(ProviderNotFoundError):
            self.registry.get("nonexistent")

    def test_lookup_by_type(self):
        self.registry.register("fake-stt", FakeProviderCls)
        self.registry.register("fake-tts", FakeTTSCls)
        stt_providers = self.registry.find_by_type(ProviderType.STT)
        assert len(stt_providers) == 1
        assert stt_providers[0][0] == "fake-stt"

    def test_lookup_by_capability(self):
        self.registry.register("fake-stt", FakeProviderCls)
        self.registry.register("fake-tts", FakeTTSCls)
        streaming = self.registry.find_by_capability(Capability.STREAMING)
        assert len(streaming) == 1
        assert streaming[0][0] == "fake-tts"

    def test_list_all(self):
        self.registry.register("a", FakeProviderCls)
        self.registry.register("b", FakeTTSCls)
        assert len(self.registry.list_all()) == 2

    def test_duplicate_register_overwrites(self):
        self.registry.register("fake-stt", FakeProviderCls)
        self.registry.register("fake-stt", FakeTTSCls)
        assert self.registry.get("fake-stt") is FakeTTSCls
