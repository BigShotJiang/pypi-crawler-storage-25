"""Tests for built-in local engine registry."""
from __future__ import annotations

from openspeechapi.local_engines.registry import default_engine_registry


def test_default_engine_registry_contains_stt_and_tts_engines() -> None:
    registry = default_engine_registry()
    assert "fish-speech" in registry
    assert "faster-whisper" in registry
    assert "whisper" in registry
    assert "whisperlivekit" in registry
    assert "sherpa-onnx" in registry
