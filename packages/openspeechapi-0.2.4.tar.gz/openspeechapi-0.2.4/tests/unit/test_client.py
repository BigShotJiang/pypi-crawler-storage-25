"""Tests for Python thin client."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from openspeechapi.client.client import Client
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, STTOptions, TTSOptions


class TestClientSTT:
    @pytest.mark.asyncio
    async def test_transcribe(self):
        client = Client("http://localhost:8600")
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "text": "hello world", "language": "en", "confidence": 0.95,
            "words": [], "duration_ms": None, "provider": "test",
        }
        client._http.post = AsyncMock(return_value=mock_resp)

        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = await client.stt.transcribe("test-stt", audio)
        assert result.text == "hello world"
        assert result.confidence == 0.95
        await client.close()

    @pytest.mark.asyncio
    async def test_fanout(self):
        client = Client("http://localhost:8600")
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "strategy": "collect_all",
            "successes": {"stt-1": {"text": "hi", "confidence": 0.9}},
            "errors": {},
        }
        client._http.post = AsyncMock(return_value=mock_resp)

        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = await client.stt.fanout(["stt-1"], audio, strategy="collect_all")
        assert "successes" in result
        await client.close()


class TestClientTTS:
    @pytest.mark.asyncio
    async def test_synthesize(self):
        client = Client("http://localhost:8600")
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.content = b"audio_bytes"
        mock_resp.headers = {"X-Sample-Rate": "24000", "X-Provider": "test"}
        client._http.post = AsyncMock(return_value=mock_resp)

        result = await client.tts.synthesize("test-tts", "hello")
        assert result.data == b"audio_bytes"
        assert result.sample_rate == 24000
        await client.close()


class TestClientManagement:
    @pytest.mark.asyncio
    async def test_health(self):
        client = Client("http://localhost:8600")
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"status": "ok", "engines": {"test": True}}
        client._http.get = AsyncMock(return_value=mock_resp)

        result = await client.health()
        assert result["status"] == "ok"
        await client.close()

    @pytest.mark.asyncio
    async def test_list_providers(self):
        client = Client("http://localhost:8600")
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"providers": [{"name": "test", "type": "stt"}]}
        client._http.get = AsyncMock(return_value=mock_resp)

        result = await client.list_providers()
        assert len(result) == 1
        await client.close()

    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with Client("http://localhost:8600") as client:
            assert client._http is not None
