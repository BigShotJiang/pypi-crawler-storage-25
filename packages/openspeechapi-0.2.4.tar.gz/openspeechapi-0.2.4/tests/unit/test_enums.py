"""Tests for core enums."""
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType


def test_provider_type_values():
    assert ProviderType.STT.value == "stt"
    assert ProviderType.TTS.value == "tts"
    assert ProviderType.BOTH.value == "both"


def test_exec_mode_values():
    assert ExecMode.IN_PROCESS.value == "in_process"
    assert ExecMode.LOCAL.value == "local"
    assert ExecMode.SUBPROCESS.value == "subprocess"
    assert ExecMode.REMOTE.value == "remote"


def test_audio_format_values():
    assert AudioFormat.PCM_16K is not None
    assert AudioFormat.WAV is not None
    assert AudioFormat.AIFF is not None
    assert AudioFormat.MP3 is not None
    assert AudioFormat.OGG is not None


def test_audio_format_aiff():
    assert AudioFormat.AIFF == "aiff"
    assert AudioFormat.AIFF.value == "aiff"


def test_capability_values():
    caps = {Capability.STREAMING, Capability.BATCH, Capability.MULTILINGUAL}
    assert len(caps) == 3


def test_capability_has_expected_members():
    expected = {"STREAMING", "BATCH", "MULTILINGUAL", "VOICE_CLONE", "EMOTION", "WORD_TIMESTAMPS"}
    actual = {c.name for c in Capability}
    assert expected.issubset(actual)
