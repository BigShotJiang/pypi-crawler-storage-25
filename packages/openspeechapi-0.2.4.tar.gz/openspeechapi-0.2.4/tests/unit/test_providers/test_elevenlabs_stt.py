"""Tests for ElevenLabs STT provider."""
from __future__ import annotations

import json
from dataclasses import dataclass

import pytest

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData
from openspeechapi.providers.stt.elevenlabs import ElevenLabsSTT, ElevenLabsSTTSettings


@dataclass
class _DummyResponse:
    status_code: int
    _json: dict
    text: str = ""

    def json(self) -> dict:
        return self._json


class _DummyClient:
    def __init__(self, response: _DummyResponse) -> None:
        self._response = response
        self.calls = []

    async def post(self, *args, **kwargs):  # noqa: ANN002, ANN003
        self.calls.append((args, kwargs))
        return self._response


class _MockWSConn:
    def __init__(self, messages: list[str]) -> None:
        self._messages = list(messages)
        self.sent: list[str] = []

    async def send(self, message: str) -> None:
        self.sent.append(message)

    def __aiter__(self):
        return self

    async def __anext__(self):
        if not self._messages:
            raise StopAsyncIteration
        return self._messages.pop(0)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):  # noqa: ANN001, ANN201
        return False


@pytest.mark.asyncio
async def test_transcribe_parses_text_language_and_words() -> None:
    provider = ElevenLabsSTT(
        ElevenLabsSTTSettings(
            api_key="test-key",
            model_id="scribe_v2",
            language_code="en",
            diarize=True,
        )
    )
    provider.set_http_client(
        _DummyClient(
            _DummyResponse(
                status_code=200,
                _json={
                    "language_code": "en",
                    "language_probability": 0.98,
                    "text": "Hello world",
                    "words": [
                        {"text": "Hello", "start": 0.0, "end": 0.5, "type": "word"},
                        {"text": "world", "start": 0.5, "end": 1.0, "type": "word"},
                    ],
                },
            )
        )
    )
    await provider.start()

    out = await provider.transcribe(
        AudioData(data=b"fake-wav", sample_rate=16000, channels=1, format=AudioFormat.WAV)
    )

    assert out.text == "Hello world"
    assert out.language == "en"
    assert out.confidence == pytest.approx(0.98)
    assert out.words is not None
    assert len(out.words) == 2
    assert out.words[0].text == "Hello"
    assert out.words[0].start_ms == 0
    assert out.words[0].end_ms == 500
    assert out.words[1].text == "world"
    assert out.words[1].start_ms == 500
    assert out.words[1].end_ms == 1000


@pytest.mark.asyncio
async def test_transcribe_raises_on_non_200() -> None:
    provider = ElevenLabsSTT(ElevenLabsSTTSettings(api_key="test-key"))
    provider.set_http_client(
        _DummyClient(
            _DummyResponse(status_code=401, _json={}, text="unauthorized")
        )
    )
    await provider.start()

    with pytest.raises(RuntimeError, match="ElevenLabs STT API error 401"):
        await provider.transcribe(
            AudioData(data=b"fake", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        )


@pytest.mark.asyncio
async def test_transcribe_sends_extended_params_and_supports_multichannel_response() -> None:
    dummy = _DummyClient(
        _DummyResponse(
            status_code=200,
            _json={
                "transcripts": [
                    {"channel_index": 0, "text": "Hello from channel A"},
                    {"channel_index": 1, "text": "Hi from channel B"},
                ]
            },
        )
    )
    provider = ElevenLabsSTT(
        ElevenLabsSTTSettings(
            api_key="test-key",
            model_id="scribe_v2",
            diarize=True,
            num_speakers=2,
            timestamps_granularity="character",
            use_multi_channel=True,
            no_verbatim=True,
            detect_speaker_roles=True,
        )
    )
    provider.set_http_client(dummy)
    await provider.start()

    out = await provider.transcribe(
        AudioData(data=b"fake-wav", sample_rate=16000, channels=2, format=AudioFormat.WAV)
    )

    assert out.text == "Hello from channel A\nHi from channel B"
    assert len(dummy.calls) == 1
    _, kwargs = dummy.calls[0]
    data = kwargs["data"]
    assert data["timestamps_granularity"] == "character"
    assert data["num_speakers"] == "2"
    assert data["use_multi_channel"] == "true"
    assert data["no_verbatim"] == "true"
    assert data["detect_speaker_roles"] == "true"


@pytest.mark.asyncio
async def test_transcribe_stream_parses_partial_and_committed_snapshots() -> None:
    provider = ElevenLabsSTT(
        ElevenLabsSTTSettings(
            api_key="test-key",
            realtime_model_id="scribe_v2_realtime",
            realtime_commit_strategy="vad",
        )
    )
    # Mark provider as started
    provider._client = object()  # type: ignore[assignment]

    ws_messages = [
        json.dumps({"message_type": "session_started", "session_id": "s1"}),
        json.dumps({"message_type": "partial_transcript", "text": "hello wor"}),
        json.dumps({
            "message_type": "committed_transcript_with_timestamps",
            "text": "hello world",
            "language_code": "en",
            "words": [
                {"type": "word", "text": "hello", "start": 0.0, "end": 0.4},
                {"type": "word", "text": "world", "start": 0.4, "end": 0.9},
            ],
        }),
    ]
    mock_conn = _MockWSConn(ws_messages)

    import websockets
    monkey = pytest.MonkeyPatch()
    monkey.setattr(websockets, "connect", lambda *args, **kwargs: mock_conn)
    try:
        async def _src():
            yield b"\x00\x00" * 160
            yield b"\x00\x00" * 160

        out = []
        async for t in provider.transcribe_stream(_src()):
            out.append(t)
    finally:
        monkey.undo()

    assert len(out) == 2
    assert out[0].is_partial is True
    assert out[0].text == "hello wor"
    assert out[1].is_partial is False
    assert out[1].text == "hello world"
    assert out[1].language == "en"
    assert out[1].words is not None
    assert len(out[1].words) == 2
