"""Tests for OpenAI TTS adapter."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import TTSOptions
from openspeechapi.providers.tts.openai import OpenAITTS, OpenAITTSSettings


# ---------------------------------------------------------------------------
# settings
# ---------------------------------------------------------------------------

def test_settings_defaults():
    s = OpenAITTSSettings()
    assert s.api_key == ""
    assert s.model == "tts-1"
    assert s.voice == "alloy"
    assert s.response_format == "pcm"


def test_settings_custom():
    s = OpenAITTSSettings(api_key="sk-x", model="tts-1-hd", voice="nova")
    assert s.api_key == "sk-x"
    assert s.model == "tts-1-hd"
    assert s.voice == "nova"


# ---------------------------------------------------------------------------
# metadata
# ---------------------------------------------------------------------------

def test_provider_metadata():
    p = OpenAITTS()
    assert p.name == "openai-tts"
    assert p.provider_type == ProviderType.TTS
    assert p.execution_mode == ExecMode.IN_PROCESS
    assert p.settings_cls is OpenAITTSSettings
    assert Capability.STREAMING in p.capabilities
    assert Capability.MULTILINGUAL in p.capabilities


# ---------------------------------------------------------------------------
# lifecycle
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_start_sets_client():
    p = OpenAITTS(OpenAITTSSettings(api_key="sk-test"))
    mock_client = MagicMock()
    mock_openai_module = MagicMock()
    mock_openai_module.AsyncOpenAI = MagicMock(return_value=mock_client)
    with patch.dict("sys.modules", {"openai": mock_openai_module}):
        await p.start()
    assert p._client is mock_client


@pytest.mark.asyncio
async def test_start_missing_openai():
    p = OpenAITTS()
    import sys
    original = sys.modules.get("openai")
    sys.modules["openai"] = None  # type: ignore[assignment]
    try:
        with pytest.raises(ImportError, match="pip install openspeechapi"):
            await p.start()
    finally:
        if original is None:
            sys.modules.pop("openai", None)
        else:
            sys.modules["openai"] = original


@pytest.mark.asyncio
async def test_stop_clears_client():
    p = OpenAITTS()
    p._client = MagicMock()
    await p.stop()
    assert p._client is None


@pytest.mark.asyncio
async def test_health_check_true_when_started():
    p = OpenAITTS()
    p.settings.api_key = "test-key"
    assert await p.health_check() is True


@pytest.mark.asyncio
async def test_health_check_false_when_not_started():
    p = OpenAITTS()
    assert await p.health_check() is False


# ---------------------------------------------------------------------------
# synthesize
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_synthesize_not_started_raises():
    p = OpenAITTS()
    with pytest.raises(RuntimeError, match="not started"):
        await p.synthesize("hello")


@pytest.mark.asyncio
async def test_synthesize_basic():
    p = OpenAITTS()
    mock_response = MagicMock()
    mock_response.content = b"\x00\x01\x02\x03"
    mock_client = MagicMock()
    mock_client.audio.speech.create = AsyncMock(return_value=mock_response)
    p._client = mock_client

    result = await p.synthesize("hello world")
    assert result.data == b"\x00\x01\x02\x03"
    mock_client.audio.speech.create.assert_awaited_once()


@pytest.mark.asyncio
async def test_synthesize_uses_opt_voice():
    p = OpenAITTS()
    mock_response = MagicMock()
    mock_response.content = b"audio"
    mock_client = MagicMock()
    mock_client.audio.speech.create = AsyncMock(return_value=mock_response)
    p._client = mock_client

    opts = TTSOptions(voice="shimmer")
    await p.synthesize("test", opts)
    call_kwargs = mock_client.audio.speech.create.call_args.kwargs
    assert call_kwargs["voice"] == "shimmer"


@pytest.mark.asyncio
async def test_synthesize_falls_back_to_settings_voice():
    p = OpenAITTS(OpenAITTSSettings(voice="echo"))
    mock_response = MagicMock()
    mock_response.content = b"audio"
    mock_client = MagicMock()
    mock_client.audio.speech.create = AsyncMock(return_value=mock_response)
    p._client = mock_client

    await p.synthesize("test")
    call_kwargs = mock_client.audio.speech.create.call_args.kwargs
    assert call_kwargs["voice"] == "echo"


# ---------------------------------------------------------------------------
# synthesize_stream
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_synthesize_stream_not_started_raises():
    p = OpenAITTS()

    with pytest.raises(RuntimeError, match="not started"):
        async for _ in p.synthesize_stream("hello"):
            pass


@pytest.mark.asyncio
async def test_synthesize_stream_yields_chunks():
    p = OpenAITTS()

    # Build an async context manager mock that yields byte chunks
    async def fake_iter_bytes(chunk_size=4096):
        for chunk in [b"chunk1", b"chunk2"]:
            yield chunk

    mock_streaming_resp = MagicMock()
    mock_streaming_resp.__aenter__ = AsyncMock(return_value=mock_streaming_resp)
    mock_streaming_resp.__aexit__ = AsyncMock(return_value=False)
    mock_streaming_resp.iter_bytes = fake_iter_bytes

    mock_client = MagicMock()
    mock_client.audio.speech.with_streaming_response.create.return_value = (
        mock_streaming_resp
    )
    p._client = mock_client

    chunks = []
    async for chunk in p.synthesize_stream("hello"):
        chunks.append(chunk)

    # two data chunks + one final sentinel
    assert len(chunks) == 3
    assert chunks[0].data == b"chunk1"
    assert chunks[1].data == b"chunk2"
    assert chunks[2].is_final is True
    assert chunks[2].data == b""
