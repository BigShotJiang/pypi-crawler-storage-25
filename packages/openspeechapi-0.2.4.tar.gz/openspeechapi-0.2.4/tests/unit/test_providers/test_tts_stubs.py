"""Tests for TTS provider stubs: FishSpeech, Piper, Coqui, CosyVoice, ElevenLabs, Minimax."""
from __future__ import annotations

import io
import json
import sys
import wave
from unittest.mock import AsyncMock, MagicMock

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.providers.tts.cosyvoice import CosyVoiceTTS, CosyVoiceTTSSettings
from openspeechapi.providers.tts.coqui import CoquiTTS, CoquiTTSSettings
from openspeechapi.providers.tts.elevenlabs import ElevenLabsTTS, ElevenLabsTTSSettings
from openspeechapi.providers.tts.fish_speech import FishSpeechTTS, FishSpeechTTSSettings
from openspeechapi.providers.tts.minimax import MinimaxTTS, MinimaxTTSSettings
from openspeechapi.providers.tts.piper import PiperTTS, PiperTTSSettings


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_wav_bytes(sample_rate: int = 22050) -> bytes:
    """Build a minimal valid WAV buffer."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"\x00\x00" * 100)
    return buf.getvalue()


# ===========================================================================
# FishSpeech
# ===========================================================================

class TestFishSpeechSettings:
    def test_defaults(self):
        s = FishSpeechTTSSettings()
        assert s.api_url == "http://localhost:8080"
        assert s.reference_audio is None
        assert s.latency == "balanced"
        assert s.use_memory_cache == "on"

    def test_custom(self):
        s = FishSpeechTTSSettings(api_url="http://localhost:9000", reference_audio="/ref.wav")
        assert s.api_url == "http://localhost:9000"
        assert s.reference_audio == "/ref.wav"


class TestFishSpeechTTS:
    def test_metadata(self):
        p = FishSpeechTTS()
        assert p.name == "fish-speech"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is FishSpeechTTSSettings
        assert Capability.STREAMING in p.capabilities
        assert Capability.VOICE_CLONE in p.capabilities

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = FishSpeechTTS()
        orig = sys.modules.get("httpx")
        sys.modules["httpx"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install openspeechapi"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("httpx", None)
            else:
                sys.modules["httpx"] = orig

    @pytest.mark.asyncio
    async def test_start_sets_client(self):
        p = FishSpeechTTS()
        mock_client_instance = MagicMock()
        mock_httpx = MagicMock()
        mock_httpx.AsyncClient = MagicMock(return_value=mock_client_instance)
        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "httpx", mock_httpx)
            await p.start()
        assert p._client is mock_client_instance

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = FishSpeechTTS()
        mock_client = AsyncMock()
        p._client = mock_client
        await p.stop()
        mock_client.aclose.assert_called_once()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = FishSpeechTTS()
        assert await p.health_check() is False
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        p._client = mock_client
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_synthesize_raises_not_started(self):
        p = FishSpeechTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self):
        from openspeechapi.core.models import AudioData

        p = FishSpeechTTS()
        wav_bytes = _make_wav_bytes(44100)
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.content = wav_bytes
        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        p._client = mock_client

        result = await p.synthesize("hello")
        assert isinstance(result, AudioData)
        assert result.data == wav_bytes
        assert result.format == AudioFormat.WAV
        assert result.sample_rate == 44100

    @pytest.mark.asyncio
    async def test_synthesize_sends_reference_audio(self):
        p = FishSpeechTTS(FishSpeechTTSSettings(reference_audio="/ref.wav"))
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.content = b"audio"
        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        p._client = mock_client

        await p.synthesize("hello")
        call_kwargs = mock_client.post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json") or call_kwargs[0][1]
        assert payload.get("reference_audio") == "/ref.wav"
        assert payload.get("latency") == "balanced"
        assert payload.get("use_memory_cache") == "on"

    @pytest.mark.asyncio
    async def test_synthesize_stream_raises_not_implemented(self):
        p = FishSpeechTTS()
        p._client = object()
        with pytest.raises(NotImplementedError):
            async for _ in p.synthesize_stream("hello"):
                pass


# ===========================================================================
# Piper
# ===========================================================================

class TestPiperSettings:
    def test_defaults(self):
        s = PiperTTSSettings()
        assert s.model_path == ""
        assert s.use_cuda is False

    def test_custom(self):
        s = PiperTTSSettings(model_path="/models/piper", use_cuda=True)
        assert s.model_path == "/models/piper"
        assert s.use_cuda is True


class TestPiperTTS:
    def test_metadata(self):
        p = PiperTTS()
        assert p.name == "piper"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is PiperTTSSettings
        assert Capability.BATCH in p.capabilities
        assert Capability.STREAMING not in p.capabilities

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = PiperTTS()
        orig = sys.modules.get("piper")
        sys.modules["piper"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install openspeechapi"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("piper", None)
            else:
                sys.modules["piper"] = orig

    @pytest.mark.asyncio
    async def test_start_sets_client(self):
        p = PiperTTS(PiperTTSSettings(model_path="/models/voice.onnx"))
        mock_voice = MagicMock()
        mock_piper_module = MagicMock()
        mock_piper_module.PiperVoice.load = MagicMock(return_value=mock_voice)
        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "piper", mock_piper_module)
            await p.start()
        assert p._client is mock_voice
        assert p._voice is mock_voice

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = PiperTTS()
        p._client = object()
        await p.stop()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = PiperTTS()
        assert await p.health_check() is False
        p._client = object()
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_synthesize_raises_not_started(self):
        p = PiperTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self):
        from openspeechapi.core.models import AudioData

        p = PiperTTS()
        # Mock voice with config.sample_rate
        mock_config = MagicMock()
        mock_config.sample_rate = 22050
        mock_voice = MagicMock()
        mock_voice.config = mock_config
        mock_voice.synthesize_stream_raw = MagicMock(
            return_value=iter([b"\x00\x00" * 100])
        )
        p._client = mock_voice
        p._voice = mock_voice

        result = await p.synthesize("hello world")
        assert isinstance(result, AudioData)
        assert result.format == AudioFormat.WAV
        assert result.sample_rate == 22050
        assert result.channels == 1
        # WAV header must be present
        assert result.data[:4] == b"RIFF"

    @pytest.mark.asyncio
    async def test_synthesize_stream_raises_not_implemented(self):
        p = PiperTTS()
        p._client = object()
        with pytest.raises(NotImplementedError):
            async for _ in p.synthesize_stream("hello"):
                pass


# ===========================================================================
# Coqui
# ===========================================================================

class TestCoquiSettings:
    def test_defaults(self):
        s = CoquiTTSSettings()
        assert "tacotron2" in s.model_name
        assert s.use_cuda is False

    def test_custom(self):
        s = CoquiTTSSettings(model_name="tts_models/multilingual/multi-dataset/xtts_v2")
        assert "xtts" in s.model_name


class TestCoquiTTS:
    def test_metadata(self):
        p = CoquiTTS()
        assert p.name == "coqui"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is CoquiTTSSettings
        assert Capability.VOICE_CLONE in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = CoquiTTS()
        # Coqui imports TTS.api; make that unavailable
        orig = sys.modules.get("TTS")
        orig_api = sys.modules.get("TTS.api")
        sys.modules["TTS"] = None  # type: ignore[assignment]
        sys.modules["TTS.api"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install openspeechapi"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("TTS", None)
            else:
                sys.modules["TTS"] = orig
            if orig_api is None:
                sys.modules.pop("TTS.api", None)
            else:
                sys.modules["TTS.api"] = orig_api

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = CoquiTTS()
        p._client = object()
        await p.stop()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = CoquiTTS()
        assert await p.health_check() is False
        p._client = object()
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_synthesize_raises_not_started(self):
        p = CoquiTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_raises_not_implemented(self):
        p = CoquiTTS()
        p._client = object()
        with pytest.raises(NotImplementedError):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_stream_raises_not_implemented(self):
        p = CoquiTTS()
        p._client = object()
        with pytest.raises(NotImplementedError):
            async for _ in p.synthesize_stream("hello"):
                pass


# ===========================================================================
# CosyVoice
# ===========================================================================

class TestCosyVoiceSettings:
    def test_defaults(self):
        s = CosyVoiceTTSSettings()
        assert s.model_dir == ""
        assert s.device == "auto"
        assert s.fp16 is False
        assert s.spk_id is None

    def test_custom(self):
        s = CosyVoiceTTSSettings(model_dir="/models/cosyvoice", fp16=True, spk_id="中文女")
        assert s.model_dir == "/models/cosyvoice"
        assert s.fp16 is True
        assert s.spk_id == "中文女"


class TestCosyVoiceTTS:
    def test_metadata(self):
        p = CosyVoiceTTS()
        assert p.name == "cosyvoice"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.SUBPROCESS
        assert p.settings_cls is CosyVoiceTTSSettings
        assert Capability.VOICE_CLONE in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = CosyVoiceTTS()
        orig = sys.modules.get("cosyvoice")
        orig_cli = sys.modules.get("cosyvoice.cli.cosyvoice")
        sys.modules["cosyvoice"] = None  # type: ignore[assignment]
        sys.modules["cosyvoice.cli.cosyvoice"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install openspeechapi"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("cosyvoice", None)
            else:
                sys.modules["cosyvoice"] = orig
            if orig_cli is None:
                sys.modules.pop("cosyvoice.cli.cosyvoice", None)
            else:
                sys.modules["cosyvoice.cli.cosyvoice"] = orig_cli

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = CosyVoiceTTS()
        p._client = object()
        await p.stop()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = CosyVoiceTTS()
        assert await p.health_check() is False
        p._client = object()
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_synthesize_raises_not_started(self):
        p = CosyVoiceTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self):
        from openspeechapi.core.models import AudioData

        p = CosyVoiceTTS(CosyVoiceTTSSettings(spk_id="中文女"))

        # Use a plain MagicMock as the tensor — torchaudio.save is also mocked
        fake_tensor = MagicMock()
        mock_model = MagicMock()
        mock_model.inference_sft = MagicMock(
            return_value=iter([{"tts_speech": fake_tensor}])
        )
        p._client = mock_model
        p._model = mock_model

        mock_torchaudio = MagicMock()

        def _fake_save(buf, tensor, sr, format):
            wav_bytes = _make_wav_bytes(sr)
            buf.write(wav_bytes)

        mock_torchaudio.save = _fake_save

        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "torchaudio", mock_torchaudio)
            result = await p.synthesize("你好世界")

        assert isinstance(result, AudioData)
        assert result.format == AudioFormat.WAV
        assert result.sample_rate == 22050
        assert result.channels == 1
        assert len(result.data) > 0

    @pytest.mark.asyncio
    async def test_synthesize_uses_default_spk_id(self):
        p = CosyVoiceTTS()  # spk_id is None → should use "中文女"
        fake_tensor = MagicMock()
        mock_model = MagicMock()
        mock_model.inference_sft = MagicMock(
            return_value=iter([{"tts_speech": fake_tensor}])
        )
        p._client = mock_model
        p._model = mock_model

        mock_torchaudio = MagicMock()

        def _fake_save(buf, tensor, sr, format):
            buf.write(_make_wav_bytes(sr))

        mock_torchaudio.save = _fake_save

        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "torchaudio", mock_torchaudio)
            await p.synthesize("hello")

        mock_model.inference_sft.assert_called_once_with("hello", "中文女")

    @pytest.mark.asyncio
    async def test_synthesize_stream_raises_not_implemented(self):
        p = CosyVoiceTTS()
        p._client = object()
        with pytest.raises(NotImplementedError):
            async for _ in p.synthesize_stream("hello"):
                pass


# ===========================================================================
# ElevenLabs
# ===========================================================================

class TestElevenLabsSettings:
    def test_defaults(self):
        s = ElevenLabsTTSSettings()
        assert s.api_key == ""
        assert s.model_id == "eleven_multilingual_v2"
        assert 0.0 <= s.stability <= 1.0

    def test_custom(self):
        s = ElevenLabsTTSSettings(api_key="el-x", voice_id="my-voice")
        assert s.api_key == "el-x"
        assert s.voice_id == "my-voice"


class TestElevenLabsTTS:
    def test_metadata(self):
        p = ElevenLabsTTS()
        assert p.name == "elevenlabs"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is ElevenLabsTTSSettings
        assert Capability.STREAMING in p.capabilities
        assert Capability.VOICE_CLONE in p.capabilities
        assert Capability.EMOTION in p.capabilities

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = ElevenLabsTTS()
        orig = sys.modules.get("elevenlabs")
        orig_client = sys.modules.get("elevenlabs.client")
        sys.modules["elevenlabs"] = None  # type: ignore[assignment]
        sys.modules["elevenlabs.client"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install openspeechapi"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("elevenlabs", None)
            else:
                sys.modules["elevenlabs"] = orig
            if orig_client is None:
                sys.modules.pop("elevenlabs.client", None)
            else:
                sys.modules["elevenlabs.client"] = orig_client

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = ElevenLabsTTS()
        p._client = object()
        await p.stop()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = ElevenLabsTTS()
        assert await p.health_check() is False
        p.settings.api_key = "test-key"
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_list_voices_maps_id_and_name(self):
        p = ElevenLabsTTS()

        class _Voice:
            def __init__(self, voice_id, name, category="premade", labels=None):
                self.voice_id = voice_id
                self.name = name
                self.category = category
                self.labels = labels or {}

        class _Resp:
            def __init__(self, voices):
                self.voices = voices

        mock_voices_api = MagicMock()
        mock_voices_api.get_all = AsyncMock(
            return_value=_Resp(
                [
                    _Voice("v1", "Rachel", labels={"language": "en"}),
                    _Voice("v2", "Lily", category="cloned"),
                ]
            )
        )
        mock_client = MagicMock()
        mock_client.voices = mock_voices_api
        p._client = mock_client

        voices = await p.list_voices()
        assert len(voices) == 2
        assert voices[0]["id"] in {"v1", "v2"}
        assert any(v["id"] == "v1" and v["name"] == "Rachel" for v in voices)
        assert any(v["id"] == "v2" and v["name"] == "Lily" for v in voices)

    @pytest.mark.asyncio
    async def test_synthesize_raises_not_started(self):
        p = ElevenLabsTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self):
        from openspeechapi.core.models import AudioData

        p = ElevenLabsTTS()

        async def _fake_chunks():
            yield b"chunk1"
            yield b"chunk2"

        mock_convert = MagicMock(return_value=_fake_chunks())
        mock_tts = MagicMock()
        mock_tts.convert = mock_convert
        mock_client = MagicMock()
        mock_client.text_to_speech = mock_tts
        p._client = mock_client

        result = await p.synthesize("hello")
        assert isinstance(result, AudioData)
        assert result.data == b"chunk1chunk2"
        assert result.format == AudioFormat.MP3
        assert result.sample_rate == 44100

    @pytest.mark.asyncio
    async def test_synthesize_stream_yields_chunks(self):
        from openspeechapi.core.models import AudioChunk

        p = ElevenLabsTTS()

        async def _fake_chunks():
            yield b"audio1"
            yield b"audio2"

        mock_convert = MagicMock(return_value=_fake_chunks())
        mock_tts = MagicMock()
        mock_tts.convert = mock_convert
        mock_client = MagicMock()
        mock_client.text_to_speech = mock_tts
        p._client = mock_client

        chunks = []
        async for chunk in p.synthesize_stream("hello"):
            chunks.append(chunk)

        assert len(chunks) == 3  # 2 data chunks + 1 final
        assert isinstance(chunks[0], AudioChunk)
        assert chunks[0].data == b"audio1"
        assert chunks[1].data == b"audio2"
        assert chunks[2].is_final is True
        assert chunks[2].data == b""

    @pytest.mark.asyncio
    async def test_synthesize_stream_ws_transport_yields_chunks(self):
        from openspeechapi.core.models import AudioChunk

        p = ElevenLabsTTS(ElevenLabsTTSSettings(stream_transport="ws"))
        p._client = object()

        class _MockWS:
            def __init__(self):
                self.sent = []
                self._msgs = [
                    json.dumps({"audio": "YXVkaW8x", "isFinal": False}),  # b"audio1"
                    json.dumps({"audio": "YXVkaW8y", "isFinal": True}),   # b"audio2"
                ]

            async def send(self, msg):
                self.sent.append(msg)

            def __aiter__(self):
                return self

            async def __anext__(self):
                if not self._msgs:
                    raise StopAsyncIteration
                return self._msgs.pop(0)

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

        mock_ws = _MockWS()
        with pytest.MonkeyPatch().context() as mp:
            import websockets

            mp.setattr(websockets, "connect", lambda *args, **kwargs: mock_ws)
            chunks = []
            async for chunk in p.synthesize_stream("hello"):
                chunks.append(chunk)

        assert len(chunks) == 3
        assert isinstance(chunks[0], AudioChunk)
        assert chunks[0].data == b"audio1"
        assert chunks[1].data == b"audio2"
        assert chunks[2].is_final is True
        assert chunks[2].data == b""
        sent = [json.loads(m) for m in mock_ws.sent]
        assert sent[-2] == {"text": "", "flush": True}
        assert sent[-1] == {"text": ""}

    @pytest.mark.asyncio
    async def test_synthesize_stream_ws_timeout_after_audio_treated_as_complete(self):
        p = ElevenLabsTTS(ElevenLabsTTSSettings(stream_transport="ws"))
        p._client = object()

        class _MockWS:
            def __init__(self):
                self.sent = []
                self._msgs = [
                    json.dumps({"audio": "YXVkaW8x", "isFinal": False}),  # b"audio1"
                    json.dumps({"error": "input_timeout_exceeded"}),
                ]

            async def send(self, msg):
                self.sent.append(msg)

            def __aiter__(self):
                return self

            async def __anext__(self):
                if not self._msgs:
                    raise StopAsyncIteration
                return self._msgs.pop(0)

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

        mock_ws = _MockWS()
        with pytest.MonkeyPatch().context() as mp:
            import websockets

            mp.setattr(websockets, "connect", lambda *args, **kwargs: mock_ws)
            chunks = []
            async for chunk in p.synthesize_stream("hello"):
                chunks.append(chunk)

        assert len(chunks) == 2
        assert chunks[0].data == b"audio1"
        assert chunks[1].is_final is True
        assert chunks[1].data == b""
        sent = [json.loads(m) for m in mock_ws.sent]
        assert sent[-2] == {"text": "", "flush": True}
        assert sent[-1] == {"text": ""}


# ===========================================================================
# Minimax
# ===========================================================================

class TestMinimaxSettings:
    def test_defaults(self):
        s = MinimaxTTSSettings()
        assert s.api_key == ""
        assert s.model == "speech-01"
        assert s.speed == 1.0
        assert s.pitch == 0

    def test_custom(self):
        s = MinimaxTTSSettings(api_key="mm-key", group_id="g123", speed=1.2)
        assert s.api_key == "mm-key"
        assert s.group_id == "g123"
        assert s.speed == 1.2


class TestMinimaxTTS:
    def test_metadata(self):
        p = MinimaxTTS()
        assert p.name == "minimax"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is MinimaxTTSSettings
        assert Capability.STREAMING in p.capabilities
        assert Capability.VOICE_CLONE not in p.capabilities

    @pytest.mark.asyncio
    async def test_start_sets_client(self):
        p = MinimaxTTS()
        mock_client_instance = MagicMock()
        mock_httpx = MagicMock()
        mock_httpx.AsyncClient = MagicMock(return_value=mock_client_instance)
        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "httpx", mock_httpx)
            await p.start()
        assert p._client is mock_client_instance

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = MinimaxTTS()
        mock_client = AsyncMock()
        p._client = mock_client
        await p.stop()
        mock_client.aclose.assert_called_once()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = MinimaxTTS()
        assert await p.health_check() is False
        p.settings.api_key = "test-key"
        p._client = object()
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_synthesize_raises_not_started(self):
        p = MinimaxTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self):
        import base64

        from openspeechapi.core.models import AudioData

        p = MinimaxTTS()
        fake_audio = base64.b64encode(b"fakemp3bytes").decode()
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json = MagicMock(
            return_value={"data": {"audio": fake_audio}}
        )
        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        p._client = mock_client

        result = await p.synthesize("hello")
        assert isinstance(result, AudioData)
        assert result.data == b"fakemp3bytes"
        assert result.format == AudioFormat.MP3
        assert result.sample_rate == 32000

    @pytest.mark.asyncio
    async def test_synthesize_stream_raises_not_implemented(self):
        p = MinimaxTTS()
        p._client = AsyncMock()
        with pytest.raises(NotImplementedError):
            async for _ in p.synthesize_stream("hello"):
                pass
