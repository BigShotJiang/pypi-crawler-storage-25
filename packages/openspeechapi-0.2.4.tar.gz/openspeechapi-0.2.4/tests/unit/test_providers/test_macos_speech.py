"""Unit tests for macOS native STT provider."""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.providers.stt.macos_speech import MacOSSpeechSettings, MacOSSpeechSTT


def _make_audio() -> AudioData:
    return AudioData(
        data=b"\x00" * 32,
        sample_rate=16000,
        channels=1,
        format=AudioFormat.PCM_16K,
    )


def _check_ok() -> dict:
    return {"status": "ok", "auth": "authorized", "available": True, "onDevice": True}


def _check_denied() -> dict:
    return {
        "status": "error",
        "auth": "denied",
        "available": True,
        "onDevice": True,
        "error": "Speech recognition permission denied.",
    }


class TestMacOSSpeechSettings:
    def test_defaults(self):
        s = MacOSSpeechSettings()
        assert s.language == "zh-CN"
        assert s.binary_path == ""

    def test_custom(self):
        s = MacOSSpeechSettings(language="en-US", binary_path="/usr/local/bin/macos-stt-helper")
        assert s.language == "en-US"
        assert s.binary_path == "/usr/local/bin/macos-stt-helper"


class TestMacOSSpeechSTT:
    def test_metadata(self):
        p = MacOSSpeechSTT()
        assert p.name == "macos-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is MacOSSpeechSettings
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    @pytest.mark.asyncio
    async def test_start_binary_found_and_authorized(self):
        p = MacOSSpeechSTT()
        with patch.object(type(p), "_DEFAULT_APP_BUNDLE", new_callable=lambda: property(lambda self: MagicMock())):
            pass
        # Simpler: directly set internals and mock _run_check
        p._app_bundle = MagicMock()
        p._binary = MagicMock()
        p._binary.exists.return_value = True
        with patch.object(p, "_run_check", return_value=_check_ok()), \
             patch.object(p, "_DEFAULT_APP_BUNDLE", MagicMock()):
            # Manually simulate start logic
            check = await p._run_check()
            assert check["status"] == "ok"
            p._auth_ok = True
            p._started = True
        assert p._started is True
        assert p._auth_ok is True

    @pytest.mark.asyncio
    async def test_start_binary_not_found(self):
        p = MacOSSpeechSTT()
        with patch("pathlib.Path.exists", return_value=False):
            with pytest.raises(RuntimeError, match="macos-stt binary not found"):
                await p.start()

    @pytest.mark.asyncio
    async def test_start_auth_denied(self):
        p = MacOSSpeechSTT()
        binary_mock = MagicMock()
        binary_mock.exists.return_value = True
        app_mock = MagicMock()
        app_mock.__truediv__ = lambda self, key: app_mock
        with patch.object(type(p), "_DEFAULT_APP_BUNDLE", new=app_mock), \
             patch("openspeechapi.providers.stt.macos_speech.Path") as MockPath, \
             patch.object(p, "_run_check", return_value=_check_denied()):
            # Make the binary path exist check pass
            MockPath.return_value.exists.return_value = True
            p._binary = binary_mock
            p._app_bundle = app_mock
            # Call start
            with pytest.raises(RuntimeError, match="not authorized"):
                await p.start()
        assert p._started is False

    @pytest.mark.asyncio
    async def test_health_check_started_and_authorized(self):
        p = MacOSSpeechSTT()
        p._started = True
        p._auth_ok = True
        p._binary = MagicMock()
        p._binary.exists.return_value = True
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_health_check_not_started_no_binary(self):
        p = MacOSSpeechSTT()
        with patch("pathlib.Path.exists", return_value=False):
            assert await p.health_check() is False

    @pytest.mark.asyncio
    async def test_health_check_binary_exists_before_start(self):
        p = MacOSSpeechSTT()
        with patch("pathlib.Path.exists", return_value=True):
            assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_transcribe_not_started(self):
        p = MacOSSpeechSTT()
        with pytest.raises(RuntimeError, match="not started"):
            await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_transcribe_returns_transcription(self):
        """Transcribe returns Transcription when helper succeeds."""
        p = MacOSSpeechSTT()
        p._started = True
        p._binary = MagicMock()
        p._app_bundle = MagicMock()

        result_data = {"text": "hello world", "confidence": 0.95, "language": "en-US"}

        with patch("openspeechapi.providers.stt.macos_speech.AudioConverter") as MockConverter, \
             patch.object(p, "_run_via_open", return_value=result_data):
            MockConverter.to_wav.return_value = AudioData(
                data=b"RIFF....WAVEfmt ",
                sample_rate=16000,
                channels=1,
                format=AudioFormat.WAV,
            )
            out = await p.transcribe(_make_audio(), STTOptions(language="en-US"))

        assert isinstance(out, Transcription)
        assert out.text == "hello world"
        assert out.confidence == 0.95
        assert out.language == "en-US"

    @pytest.mark.asyncio
    async def test_transcribe_helper_error(self):
        """Transcribe raises when helper returns error."""
        p = MacOSSpeechSTT()
        p._started = True
        p._binary = MagicMock()
        p._app_bundle = MagicMock()

        with patch("openspeechapi.providers.stt.macos_speech.AudioConverter") as MockConverter, \
             patch.object(p, "_run_via_open", return_value={"error": "Recognition failed"}):
            MockConverter.to_wav.return_value = AudioData(
                data=b"RIFF....WAVEfmt ",
                sample_rate=16000,
                channels=1,
                format=AudioFormat.WAV,
            )
            with pytest.raises(RuntimeError, match="Recognition failed"):
                await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_run_via_open_direct_execution(self):
        """_run_via_open uses direct execution when no output_file."""
        p = MacOSSpeechSTT()
        p._binary = MagicMock()
        p._binary.__str__ = MagicMock(return_value="/fake/bin")
        p._app_bundle = MagicMock()

        check_json = json.dumps(_check_ok())
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(check_json.encode(), b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            result = await p._run_via_open("--check")
        assert result["status"] == "ok"

    @pytest.mark.asyncio
    async def test_run_via_open_with_output_file(self, tmp_path):
        """_run_via_open uses open -W and reads from output file."""
        p = MacOSSpeechSTT()
        p._app_bundle = MagicMock()
        p._app_bundle.__str__ = MagicMock(return_value="/fake/App.app")

        out_file = tmp_path / "result.json"
        result_data = {"text": "hello", "confidence": 0.9, "language": "en"}

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))
        mock_proc.returncode = 0

        async def fake_exec(*args, **kwargs):
            # Simulate the binary writing to the output file
            out_file.write_text(json.dumps(result_data))
            return mock_proc

        with patch("asyncio.create_subprocess_exec", side_effect=fake_exec):
            result = await p._run_via_open(
                "--audio", "/tmp/test.wav",
                output_file=str(out_file),
            )
        assert result["text"] == "hello"

    @pytest.mark.asyncio
    async def test_run_via_open_output_file_missing(self):
        """_run_via_open returns error dict when output_file doesn't exist after process completes."""
        p = MacOSSpeechSTT()
        p._app_bundle = MagicMock()

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            result = await p._run_via_open(
                "--audio", "/tmp/test.wav",
                output_file="/tmp/nonexistent_output.json",
            )
        assert result["status"] == "error"

    @pytest.mark.asyncio
    async def test_run_via_open_invalid_json_in_output(self, tmp_path):
        """_run_via_open returns error dict with raw content when output file has invalid JSON."""
        p = MacOSSpeechSTT()
        p._app_bundle = MagicMock()

        out_file = tmp_path / "bad_result.json"
        out_file.write_text("not json at all")

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            result = await p._run_via_open(
                "--audio", "/tmp/test.wav",
                output_file=str(out_file),
            )
        assert result["status"] == "error"
        assert "not json at all" in result["error"]

    @pytest.mark.asyncio
    async def test_transcribe_cleans_tmp_files_on_error(self, tmp_path):
        """Temporary WAV and JSON files are cleaned up even when _run_via_open returns an error."""
        p = MacOSSpeechSTT()
        p._started = True
        p._binary = MagicMock()
        p._app_bundle = MagicMock()

        with patch("openspeechapi.providers.stt.macos_speech.AudioConverter") as MockConverter, \
             patch.object(p, "_run_via_open", return_value={"error": "some failure"}), \
             patch("tempfile.NamedTemporaryFile") as mock_tmpfile:
            MockConverter.to_wav.return_value = AudioData(
                data=b"RIFF....WAVEfmt ",
                sample_rate=16000,
                channels=1,
                format=AudioFormat.WAV,
            )
            # Create real temp files so we can verify cleanup
            wav_file = tmp_path / "test.wav"
            json_file = tmp_path / "test.json"
            wav_file.write_bytes(b"RIFF....WAVEfmt ")
            json_file.write_text("{}")

            mock_wav_ctx = MagicMock()
            mock_wav_ctx.__enter__ = MagicMock(return_value=mock_wav_ctx)
            mock_wav_ctx.__exit__ = MagicMock(return_value=False)
            mock_wav_ctx.name = str(wav_file)
            mock_wav_ctx.write = MagicMock()

            mock_json_ctx = MagicMock()
            mock_json_ctx.__enter__ = MagicMock(return_value=mock_json_ctx)
            mock_json_ctx.__exit__ = MagicMock(return_value=False)
            mock_json_ctx.name = str(json_file)

            mock_tmpfile.side_effect = [mock_wav_ctx, mock_json_ctx]

            with pytest.raises(RuntimeError, match="some failure"):
                await p.transcribe(_make_audio())

            # Verify temp files were cleaned up
            assert not wav_file.exists(), "WAV temp file should have been deleted"
            assert not json_file.exists(), "JSON temp file should have been deleted"

    def test_transcribe_stream_raises(self):
        p = MacOSSpeechSTT()
        with pytest.raises(NotImplementedError):
            p.transcribe_stream(AsyncMock())

    @pytest.mark.asyncio
    async def test_stop(self):
        p = MacOSSpeechSTT()
        p._started = True
        p._auth_ok = True
        p._binary = MagicMock()
        p._app_bundle = MagicMock()
        await p.stop()
        assert p._started is False
        assert p._auth_ok is False
        assert p._binary is None
        assert p._app_bundle is None
