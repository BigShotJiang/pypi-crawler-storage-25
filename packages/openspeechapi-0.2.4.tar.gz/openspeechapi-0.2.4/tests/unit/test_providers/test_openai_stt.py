"""Tests for OpenAI STT adapter."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions
from openspeechapi.providers.stt.openai import OpenAISTT, OpenAISTTSettings


# ---------------------------------------------------------------------------
# settings
# ---------------------------------------------------------------------------

def test_settings_defaults():
    s = OpenAISTTSettings()
    assert s.api_key == ""
    assert s.model == "whisper-1"


def test_settings_custom():
    s = OpenAISTTSettings(api_key="sk-test", model="whisper-2")
    assert s.api_key == "sk-test"
    assert s.model == "whisper-2"


# ---------------------------------------------------------------------------
# metadata
# ---------------------------------------------------------------------------

def test_provider_metadata():
    p = OpenAISTT()
    assert p.name == "openai-stt"
    assert p.provider_type == ProviderType.STT
    assert p.execution_mode == ExecMode.IN_PROCESS
    assert p.settings_cls is OpenAISTTSettings
    assert Capability.BATCH in p.capabilities
    assert Capability.MULTILINGUAL in p.capabilities


# ---------------------------------------------------------------------------
# lifecycle
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_start_sets_client():
    p = OpenAISTT(OpenAISTTSettings(api_key="sk-test"))
    mock_client = MagicMock()
    mock_openai_module = MagicMock()
    mock_openai_module.AsyncOpenAI = MagicMock(return_value=mock_client)
    with patch.dict("sys.modules", {"openai": mock_openai_module}):
        await p.start()
    assert p._client is mock_client


@pytest.mark.asyncio
async def test_start_missing_openai():
    p = OpenAISTT()
    import sys
    original = sys.modules.get("openai")
    sys.modules["openai"] = None  # type: ignore[assignment]
    try:
        with pytest.raises(ImportError, match="pip install openspeechapi"):
            await p.start()
    finally:
        if original is None:
            sys.modules.pop("openai", None)
        else:
            sys.modules["openai"] = original


@pytest.mark.asyncio
async def test_stop_clears_client():
    p = OpenAISTT()
    p._client = MagicMock()
    await p.stop()
    assert p._client is None


@pytest.mark.asyncio
async def test_health_check_true_when_started():
    p = OpenAISTT()
    p.settings.api_key = "test-key"
    assert await p.health_check() is True


@pytest.mark.asyncio
async def test_health_check_false_when_not_started():
    p = OpenAISTT()
    assert await p.health_check() is False


# ---------------------------------------------------------------------------
# transcribe
# ---------------------------------------------------------------------------

def _make_audio() -> AudioData:
    return AudioData(
        data=b"\x00" * 16,
        sample_rate=16000,
        channels=1,
        format=AudioFormat.WAV,
    )


@pytest.mark.asyncio
async def test_transcribe_not_started_raises():
    p = OpenAISTT()
    with pytest.raises(RuntimeError, match="not started"):
        await p.transcribe(_make_audio())


@pytest.mark.asyncio
async def test_transcribe_basic():
    p = OpenAISTT()
    mock_response = MagicMock()
    mock_response.text = "hello world"
    mock_client = MagicMock()
    mock_client.audio.transcriptions.create = AsyncMock(return_value=mock_response)
    p._client = mock_client

    result = await p.transcribe(_make_audio())
    assert result.text == "hello world"
    mock_client.audio.transcriptions.create.assert_awaited_once()


@pytest.mark.asyncio
async def test_transcribe_passes_opts():
    p = OpenAISTT()
    mock_response = MagicMock()
    mock_response.text = "bonjour"
    mock_client = MagicMock()
    mock_client.audio.transcriptions.create = AsyncMock(return_value=mock_response)
    p._client = mock_client

    opts = STTOptions(language="fr", prompt="translate", temperature=0.0)
    result = await p.transcribe(_make_audio(), opts)
    assert result.text == "bonjour"
    assert result.language == "fr"

    call_kwargs = mock_client.audio.transcriptions.create.call_args.kwargs
    assert call_kwargs["language"] == "fr"
    assert call_kwargs["prompt"] == "translate"
    assert call_kwargs["temperature"] == 0.0


# ---------------------------------------------------------------------------
# transcribe_stream
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_transcribe_stream_raises():
    p = OpenAISTT()
    p._client = MagicMock()

    async def dummy_stream():
        yield b""

    with pytest.raises(NotImplementedError):
        async for _ in p.transcribe_stream(dummy_stream()):
            pass
