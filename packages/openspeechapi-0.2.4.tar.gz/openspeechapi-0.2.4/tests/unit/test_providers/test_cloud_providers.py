"""Unit tests for cloud STT/TTS providers -- settings defaults and metadata."""
from __future__ import annotations

from openspeechapi.core.enums import Capability, ExecMode, ProviderType


# ---------------------------------------------------------------------------
# Google Cloud
# ---------------------------------------------------------------------------

class TestGoogleCloudSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.google_cloud import GoogleCloudSTT
        p = GoogleCloudSTT()
        assert p.name == "google-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.REMOTE
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.google_cloud import GoogleCloudSTTSettings
        s = GoogleCloudSTTSettings()
        assert s.api_key == ""
        assert s.model == "latest_long"
        assert s.language == "en-US"


class TestGoogleCloudTTS:
    def test_metadata(self):
        from openspeechapi.providers.tts.google_cloud import GoogleCloudTTS
        p = GoogleCloudTTS()
        assert p.name == "google-tts"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.REMOTE
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.tts.google_cloud import GoogleCloudTTSSettings
        s = GoogleCloudTTSSettings()
        assert s.api_key == ""
        assert s.language == "en-US"
        assert s.voice_name == "en-US-Standard-A"
        assert s.speaking_rate == 1.0


# ---------------------------------------------------------------------------
# Azure Speech
# ---------------------------------------------------------------------------

class TestAzureSpeechSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.azure_speech import AzureSpeechSTT
        p = AzureSpeechSTT()
        assert p.name == "azure-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.REMOTE
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.azure_speech import AzureSpeechSTTSettings
        s = AzureSpeechSTTSettings()
        assert s.subscription_key == ""
        assert s.region == "eastus"
        assert s.language == "en-US"


class TestAzureSpeechTTS:
    def test_metadata(self):
        from openspeechapi.providers.tts.azure_speech import AzureSpeechTTS
        p = AzureSpeechTTS()
        assert p.name == "azure-tts"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.REMOTE
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.tts.azure_speech import AzureSpeechTTSSettings
        s = AzureSpeechTTSSettings()
        assert s.subscription_key == ""
        assert s.region == "eastus"
        assert s.voice == "en-US-JennyNeural"
        assert s.language == "en-US"


# ---------------------------------------------------------------------------
# AssemblyAI
# ---------------------------------------------------------------------------

class TestAssemblyAISTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.assemblyai import AssemblyAISTT
        p = AssemblyAISTT()
        assert p.name == "assemblyai-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.REMOTE
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.assemblyai import AssemblyAISTTSettings
        s = AssemblyAISTTSettings()
        assert s.api_key == ""
        assert s.model == "best"
        assert s.language == "en"


# ---------------------------------------------------------------------------
# ElevenLabs
# ---------------------------------------------------------------------------

class TestElevenLabsSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.elevenlabs import ElevenLabsSTT
        p = ElevenLabsSTT()
        assert p.name == "elevenlabs-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.REMOTE
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.elevenlabs import ElevenLabsSTTSettings
        s = ElevenLabsSTTSettings()
        assert s.api_key == ""
        assert s.model_id == "scribe_v2"
        assert s.language_code == ""
        assert s.diarize is False
        assert s.tag_audio_events is True


# ---------------------------------------------------------------------------
# Volcengine (ByteDance)
# ---------------------------------------------------------------------------

class TestVolcengineSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.volcengine import VolcengineSTT
        p = VolcengineSTT()
        assert p.name == "volcengine-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.volcengine import VolcengineSTTSettings
        s = VolcengineSTTSettings()
        assert s.access_token == ""
        assert s.app_id == ""
        assert s.cluster == "volcengine_streaming_common"


class TestVolcengineTTS:
    def test_metadata(self):
        from openspeechapi.providers.tts.volcengine import VolcengineTTS
        p = VolcengineTTS()
        assert p.name == "volcengine-tts"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.tts.volcengine import VolcengineTTSSettings
        s = VolcengineTTSSettings()
        assert s.access_token == ""
        assert s.app_id == ""
        assert s.cluster == "volcano_tts"
        assert s.voice_type == "BV001_streaming"


# ---------------------------------------------------------------------------
# Alibaba Cloud (DashScope)
# ---------------------------------------------------------------------------

class TestAlibabaSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.alibaba import AlibabaSTT
        p = AlibabaSTT()
        assert p.name == "alibaba-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.alibaba import AlibabaSTTSettings
        s = AlibabaSTTSettings()
        assert s.api_key == ""
        assert s.model == "paraformer-v2"
        assert s.base_url == "https://dashscope.aliyuncs.com/compatible-mode/v1"


class TestAlibabaTTS:
    def test_metadata(self):
        from openspeechapi.providers.tts.alibaba import AlibabaTTS
        p = AlibabaTTS()
        assert p.name == "alibaba-tts"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.tts.alibaba import AlibabaTTSSettings
        s = AlibabaTTSSettings()
        assert s.api_key == ""
        assert s.model == "cosyvoice-v1"
        assert s.voice == "longxiaochun"
        assert s.base_url == "https://dashscope.aliyuncs.com/compatible-mode/v1"


# ---------------------------------------------------------------------------
# Tencent Cloud
# ---------------------------------------------------------------------------

class TestTencentSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.tencent import TencentSTT
        p = TencentSTT()
        assert p.name == "tencent-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.tencent import TencentSTTSettings
        s = TencentSTTSettings()
        assert s.secret_id == ""
        assert s.secret_key == ""
        assert s.engine_type == "16k_zh"
        assert s.region == "ap-guangzhou"


class TestTencentTTS:
    def test_metadata(self):
        from openspeechapi.providers.tts.tencent import TencentTTS
        p = TencentTTS()
        assert p.name == "tencent-tts"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.tts.tencent import TencentTTSSettings
        s = TencentTTSSettings()
        assert s.secret_id == ""
        assert s.secret_key == ""
        assert s.voice_type == 1001
        assert s.region == "ap-guangzhou"


# ---------------------------------------------------------------------------
# Baidu Cloud
# ---------------------------------------------------------------------------

class TestBaiduSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.baidu import BaiduSTT
        p = BaiduSTT()
        assert p.name == "baidu-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.baidu import BaiduSTTSettings
        s = BaiduSTTSettings()
        assert s.api_key == ""
        assert s.secret_key == ""
        assert s.dev_pid == 1537


class TestBaiduTTS:
    def test_metadata(self):
        from openspeechapi.providers.tts.baidu import BaiduTTS
        p = BaiduTTS()
        assert p.name == "baidu-tts"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.tts.baidu import BaiduTTSSettings
        s = BaiduTTSSettings()
        assert s.api_key == ""
        assert s.secret_key == ""
        assert s.per == 0
        assert s.spd == 5
        assert s.pit == 5
        assert s.vol == 5


# ---------------------------------------------------------------------------
# iFlytek
# ---------------------------------------------------------------------------

class TestIflytekSTT:
    def test_metadata(self):
        from openspeechapi.providers.stt.iflytek import IflytekSTT
        p = IflytekSTT()
        assert p.name == "iflytek-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.stt.iflytek import IflytekSTTSettings
        s = IflytekSTTSettings()
        assert s.app_id == ""
        assert s.api_key == ""
        assert s.api_secret == ""
        assert s.language == "zh_cn"


class TestIflytekTTS:
    def test_metadata(self):
        from openspeechapi.providers.tts.iflytek import IflytekTTS
        p = IflytekTTS()
        assert p.name == "iflytek-tts"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    def test_settings_defaults(self):
        from openspeechapi.providers.tts.iflytek import IflytekTTSSettings
        s = IflytekTTSSettings()
        assert s.app_id == ""
        assert s.api_key == ""
        assert s.api_secret == ""
        assert s.voice == "xiaoyan"
        assert s.speed == 50
