"""Tests for WhisperLiveKit STT provider."""
from __future__ import annotations

import json
import io
import sys
import asyncio
from unittest.mock import AsyncMock, MagicMock
import wave

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData
from openspeechapi.providers.stt.whisperlivekit import (
    WhisperLiveKitSTT,
    WhisperLiveKitSTTSettings,
)


def _make_audio() -> AudioData:
    return AudioData(
        data=b"\x00" * 64,
        sample_rate=16000,
        channels=1,
        format=AudioFormat.WAV,
    )


class TestWhisperLiveKitSettings:
    def test_defaults(self):
        s = WhisperLiveKitSTTSettings()
        assert s.api_url.startswith("http://")
        assert s.ws_path == "/asr"
        assert s.http_transcribe_path == "/v1/audio/transcriptions"
        assert s.model


class TestWhisperLiveKitProvider:
    @staticmethod
    def _make_wav_bytes(duration_s: float = 0.5, sr: int = 16000) -> bytes:
        n = int(duration_s * sr)
        out = io.BytesIO()
        with wave.open(out, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(b"\x00\x00" * n)
        return out.getvalue()

    def test_metadata(self):
        p = WhisperLiveKitSTT()
        assert p.name == "whisperlivekit-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.LOCAL
        assert Capability.STREAMING in p.capabilities
        assert Capability.BATCH in p.capabilities

    @pytest.mark.asyncio
    async def test_transcribe_raises_not_started(self):
        p = WhisperLiveKitSTT()
        with pytest.raises(RuntimeError, match="not started"):
            await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_transcribe_success(self):
        p = WhisperLiveKitSTT()
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json = MagicMock(
            return_value={"text": "hello", "language": "en", "confidence": 0.9, "duration_ms": 1234}
        )
        mock_client = MagicMock()
        mock_client.post = AsyncMock(return_value=mock_resp)
        p._client = mock_client

        out = await p.transcribe(_make_audio())
        assert out.text == "hello"
        assert out.language == "en"
        assert out.confidence == 0.9
        assert out.duration_ms == 1234

    @pytest.mark.asyncio
    async def test_transcribe_pads_short_wav_for_wlk(self):
        p = WhisperLiveKitSTT(WhisperLiveKitSTTSettings(min_audio_duration_ms=6000))
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json = MagicMock(return_value={"text": "ok"})
        mock_client = MagicMock()
        mock_client.post = AsyncMock(return_value=mock_resp)
        p._client = mock_client

        short_wav = self._make_wav_bytes(duration_s=0.6, sr=16000)
        out = await p.transcribe(
            AudioData(data=short_wav, sample_rate=16000, channels=1, format=AudioFormat.WAV)
        )
        assert out.text == "ok"

        call = mock_client.post.call_args
        sent_files = call.kwargs["files"]
        sent_bytes = sent_files["file"][1]
        assert isinstance(sent_bytes, (bytes, bytearray))
        assert len(sent_bytes) > len(short_wav)

    @pytest.mark.asyncio
    async def test_transcribe_stream_parses_deepgram_results(self):
        p = WhisperLiveKitSTT(WhisperLiveKitSTTSettings(ws_path="/v1/listen"))
        p._client = object()

        class _MockWS:
            def __init__(self):
                self.sent = []
                self._msgs = iter([
                    json.dumps(
                        {
                            "type": "Results",
                            "channel": {
                                "detected_language": "en",
                                "alternatives": [{"transcript": "hello world", "confidence": 0.98}],
                            },
                        }
                    )
                ])

            async def send(self, data):
                self.sent.append(data)

            async def recv(self):
                await asyncio.sleep(0)
                try:
                    return next(self._msgs)
                except StopIteration:
                    raise asyncio.TimeoutError()

        class _MockConn:
            async def __aenter__(self):
                self.ws = _MockWS()
                return self.ws

            async def __aexit__(self, exc_type, exc, tb):
                return False

        mock_websockets = MagicMock()
        mock_websockets.connect = MagicMock(return_value=_MockConn())
        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "websockets", mock_websockets)

            async def _src():
                yield b"\x00" * 10

            items = []
            async for t in p.transcribe_stream(_src()):
                items.append(t)
        assert len(items) == 1
        assert items[0].text == "hello world"
        assert items[0].language == "en"

    def test_build_ws_url_for_asr_mode(self):
        p = WhisperLiveKitSTT(WhisperLiveKitSTTSettings(api_url="http://127.0.0.1:12100", ws_path="/asr"))
        u = p._build_ws_url(model="openai/whisper-large-v3-turbo", language="en")
        assert u.startswith("ws://127.0.0.1:12100/asr?")
        assert "mode=diff" in u
        assert "language=en" in u

    def test_extract_asr_message_text_snapshot(self):
        p = WhisperLiveKitSTT()
        committed = []
        text = p._extract_asr_message_text(
            {
                "type": "snapshot",
                "lines": [
                    {"speaker": 0, "text": "hello"},
                    {"speaker": -2, "text": ""},
                ],
                "buffer_transcription": "world",
            },
            committed,
        )
        assert text == "hello world"

    def test_stabilize_asr_text_repetition(self):
        p = WhisperLiveKitSTT()
        raw = "HelloHelloHello ,,, 你好好好好 鍵鍵鍵鍵"
        out = p._stabilize_asr_text(raw)
        assert "HelloHello" not in out
        assert ",,," not in out
        assert "好好好好" not in out
