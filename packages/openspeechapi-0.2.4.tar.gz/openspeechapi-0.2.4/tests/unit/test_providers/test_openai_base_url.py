"""Test OpenAI providers base_url support."""
from __future__ import annotations

from openspeechapi.providers.stt.openai import OpenAISTTSettings
from openspeechapi.providers.tts.openai import OpenAITTSSettings


class TestOpenAIBaseUrl:
    def test_stt_settings_has_base_url(self):
        s = OpenAISTTSettings()
        assert s.base_url == ""

    def test_stt_settings_custom_base_url(self):
        s = OpenAISTTSettings(base_url="https://api.groq.com/openai/v1")
        assert s.base_url == "https://api.groq.com/openai/v1"

    def test_stt_settings_default_model(self):
        s = OpenAISTTSettings()
        assert s.model == "whisper-1"

    def test_stt_settings_default_api_key(self):
        s = OpenAISTTSettings()
        assert s.api_key == ""

    def test_tts_settings_has_base_url(self):
        s = OpenAITTSSettings()
        assert s.base_url == ""

    def test_tts_settings_custom_base_url(self):
        s = OpenAITTSSettings(base_url="https://api.siliconflow.cn/v1")
        assert s.base_url == "https://api.siliconflow.cn/v1"

    def test_tts_settings_default_model(self):
        s = OpenAITTSSettings()
        assert s.model == "tts-1"

    def test_tts_settings_default_voice(self):
        s = OpenAITTSSettings()
        assert s.voice == "alloy"

    def test_tts_settings_default_api_key(self):
        s = OpenAITTSSettings()
        assert s.api_key == ""

    def test_tts_settings_default_response_format(self):
        s = OpenAITTSSettings()
        assert s.response_format == "pcm"
