"""Tests for STT provider stubs: FasterWhisper, Whisper, Deepgram."""
from __future__ import annotations

import sys
from unittest.mock import AsyncMock, MagicMock

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions
from openspeechapi.providers.stt.deepgram import DeepgramSTT, DeepgramSTTSettings
from openspeechapi.providers.stt.faster_whisper import (
    FasterWhisperSTT,
    FasterWhisperSTTSettings,
)
from openspeechapi.providers.stt.whisper import WhisperSTT, WhisperSTTSettings


def _make_audio() -> AudioData:
    return AudioData(
        data=b"\x00" * 16,
        sample_rate=16000,
        channels=1,
        format=AudioFormat.WAV,
    )


# ===========================================================================
# FasterWhisper
# ===========================================================================

class TestFasterWhisperSettings:
    def test_defaults(self):
        s = FasterWhisperSTTSettings()
        assert s.model_size == "base"
        assert s.device == "auto"
        assert s.compute_type == "default"
        assert s.beam_size == 5

    def test_custom(self):
        s = FasterWhisperSTTSettings(model_size="large-v3", device="cuda")
        assert s.model_size == "large-v3"
        assert s.device == "cuda"


class TestFasterWhisperSTT:
    def test_metadata(self):
        p = FasterWhisperSTT()
        assert p.name == "faster-whisper"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.SUBPROCESS
        assert p.settings_cls is FasterWhisperSTTSettings
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities
        assert Capability.WORD_TIMESTAMPS in p.capabilities

    @pytest.mark.asyncio
    async def test_start_sets_client(self):
        p = FasterWhisperSTT()
        mock_module = MagicMock()
        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "faster_whisper", mock_module)
            await p.start()
        assert p._client is not None

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = FasterWhisperSTT()
        orig = sys.modules.get("faster_whisper")
        sys.modules["faster_whisper"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install openspeechapi"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("faster_whisper", None)
            else:
                sys.modules["faster_whisper"] = orig

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = FasterWhisperSTT()
        p._client = object()
        await p.stop()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = FasterWhisperSTT()
        assert await p.health_check() is False
        p._client = object()
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_transcribe_raises_not_started(self):
        p = FasterWhisperSTT()
        with pytest.raises(RuntimeError, match="not started"):
            await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_transcribe_raises_without_model(self):
        # _client set (passes the guard) but _model is None → AttributeError
        p = FasterWhisperSTT()
        p._client = object()
        with pytest.raises((AttributeError, RuntimeError, ImportError)):
            await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_transcribe_stream_raises_not_implemented(self):
        p = FasterWhisperSTT()
        p._client = object()

        async def dummy():
            yield b""

        with pytest.raises(NotImplementedError):
            async for _ in p.transcribe_stream(dummy()):
                pass

    @pytest.mark.asyncio
    async def test_transcribe_uses_beam_size_override(self):
        p = FasterWhisperSTT(FasterWhisperSTTSettings(beam_size=5))
        mock_info = MagicMock()
        mock_info.language = "en"
        mock_info.language_probability = 0.99
        mock_info.duration = 1.25
        mock_model = MagicMock()
        mock_model.transcribe = MagicMock(return_value=([], mock_info))
        mock_module = MagicMock()
        mock_module.WhisperModel = MagicMock(return_value=mock_model)
        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "faster_whisper", mock_module)
            p._client = mock_model
            p._model = mock_model
            out = await p.transcribe(_make_audio(), STTOptions(beam_size=9))
        kwargs = mock_model.transcribe.call_args.kwargs
        assert kwargs.get("beam_size") == 9
        assert out.duration_ms == 1250

    def test_resolve_model_dir_prefers_snapshot_when_needed(self, tmp_path):
        root = tmp_path / "models--foo"
        snap = root / "snapshots" / "abc123"
        snap.mkdir(parents=True)
        (snap / "model.bin").write_bytes(b"x")
        resolved = FasterWhisperSTT._resolve_model_dir(str(root))
        assert resolved == str(snap)


# ===========================================================================
# Whisper (local)
# ===========================================================================

class TestWhisperSettings:
    def test_defaults(self):
        s = WhisperSTTSettings()
        assert s.model_name == "base"
        assert s.device == "cpu"
        assert s.fp16 is False
        assert s.beam_size == 5

    def test_custom(self):
        s = WhisperSTTSettings(model_name="large", device="cuda", fp16=True)
        assert s.model_name == "large"
        assert s.fp16 is True


class TestWhisperSTT:
    def test_metadata(self):
        p = WhisperSTT()
        assert p.name == "whisper"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.SUBPROCESS
        assert p.settings_cls is WhisperSTTSettings
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities
        assert Capability.WORD_TIMESTAMPS not in p.capabilities

    @pytest.mark.asyncio
    async def test_start_sets_client(self):
        p = WhisperSTT()
        mock_model = MagicMock()
        mock_module = MagicMock()
        mock_module.load_model = MagicMock(return_value=mock_model)
        with pytest.MonkeyPatch().context() as mp:
            mp.setitem(sys.modules, "whisper", mock_module)
            await p.start()
        assert p._client is mock_model
        assert p._model is mock_model

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = WhisperSTT()
        orig = sys.modules.get("whisper")
        sys.modules["whisper"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install openspeechapi"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("whisper", None)
            else:
                sys.modules["whisper"] = orig

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = WhisperSTT()
        p._client = object()
        await p.stop()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = WhisperSTT()
        assert await p.health_check() is False
        p._client = object()
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_transcribe_raises_not_started(self):
        p = WhisperSTT()
        with pytest.raises(RuntimeError, match="not started"):
            await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_transcribe_returns_transcription(self):
        p = WhisperSTT()
        mock_model = MagicMock()
        mock_model.transcribe = MagicMock(
            return_value={
                "text": " hello world ",
                "language": "en",
                "segments": [
                    {
                        "end": 1.23,
                        "words": [
                            {"word": "hello", "start": 0.1, "end": 0.4, "probability": 0.91},
                            {"word": "world", "start": 0.5, "end": 0.9},
                        ],
                    }
                ],
            }
        )
        p._client = mock_model
        p._model = mock_model

        out = await p.transcribe(_make_audio(), STTOptions(language="en"))
        assert out.text == "hello world"
        assert out.language == "en"
        assert out.duration_ms == 1230
        assert out.words is not None
        assert out.words[0].text == "hello"
        assert out.words[0].start_ms == 100
        assert out.words[0].end_ms == 400

    @pytest.mark.asyncio
    async def test_transcribe_uses_beam_size_override(self):
        p = WhisperSTT(WhisperSTTSettings(beam_size=5))
        mock_model = MagicMock()
        mock_model.transcribe = MagicMock(
            return_value={"text": "ok", "language": "en", "segments": []}
        )
        p._client = mock_model
        p._model = mock_model

        await p.transcribe(_make_audio(), STTOptions(beam_size=11, fp16=True))
        kwargs = mock_model.transcribe.call_args.kwargs
        assert kwargs.get("beam_size") == 11
        assert kwargs.get("fp16") is True

    @pytest.mark.asyncio
    async def test_transcribe_stream_raises_not_implemented(self):
        p = WhisperSTT()
        p._client = object()

        async def dummy():
            yield b""

        with pytest.raises(NotImplementedError):
            async for _ in p.transcribe_stream(dummy()):
                pass


# ===========================================================================
# Deepgram
# ===========================================================================

class TestDeepgramSettings:
    def test_defaults(self):
        s = DeepgramSTTSettings()
        assert s.api_key == ""
        assert s.model == "nova-2"
        assert s.language == "en-US"
        assert s.punctuate is True
        assert s.smart_format is True

    def test_custom(self):
        s = DeepgramSTTSettings(api_key="dg-test", model="nova-3", language="fr")
        assert s.api_key == "dg-test"
        assert s.model == "nova-3"


class TestDeepgramSTT:
    def test_metadata(self):
        p = DeepgramSTT()
        assert p.name == "deepgram"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is DeepgramSTTSettings
        assert Capability.STREAMING in p.capabilities
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities

    @pytest.mark.asyncio
    async def test_start_creates_httpx_client(self):
        p = DeepgramSTT()
        await p.start()
        assert p._client is not None
        await p.stop()

    @pytest.mark.asyncio
    async def test_stop_clears_client(self):
        p = DeepgramSTT()
        await p.start()
        await p.stop()
        assert p._client is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = DeepgramSTT()
        assert await p.health_check() is False
        p.settings.api_key = "test-key"
        assert await p.health_check() is True

    @pytest.mark.asyncio
    async def test_transcribe_raises_not_started(self):
        p = DeepgramSTT()
        with pytest.raises(RuntimeError, match="not started"):
            await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_transcribe_returns_transcription(self):
        from openspeechapi.core.models import Transcription

        p = DeepgramSTT(DeepgramSTTSettings(api_key="test-key"))

        # Mock httpx response matching Deepgram REST API format
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": {
                "channels": [{
                    "alternatives": [{
                        "transcript": "hello",
                        "confidence": 0.98,
                        "words": [{"word": "hello", "start": 0.0, "end": 0.5, "confidence": 0.99}],
                    }],
                    "detected_language": "en",
                }]
            }
        }

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        p._client = mock_client

        result = await p.transcribe(_make_audio())

        assert isinstance(result, Transcription)
        assert result.text == "hello"
        assert result.confidence == 0.98
        assert result.language == "en"
        assert result.words is not None
        assert len(result.words) == 1
        assert result.words[0].text == "hello"

    @pytest.mark.asyncio
    async def test_transcribe_stream_yields_transcriptions(self):
        """transcribe_stream() uses websockets to stream audio and yield Transcription objects."""
        from openspeechapi.core.models import Transcription

        p = DeepgramSTT()
        p._client = object()  # just needs to be non-None

        # Fake message responses from Deepgram WebSocket
        import json
        fake_messages = [
            json.dumps({
                "type": "Results",
                "is_final": True,
                "channel": {
                    "alternatives": [{"transcript": "hello world", "confidence": 0.97}],
                    "detected_language": "en",
                },
            }),
            json.dumps({
                "type": "Results",
                "is_final": True,
                "channel": {
                    "alternatives": [{"transcript": "how are you", "confidence": 0.95}],
                    "detected_language": "en",
                },
            }),
        ]

        # Mock websocket connection
        mock_ws = MagicMock()
        mock_ws.send = AsyncMock()

        async def fake_ws_iter():
            for msg in fake_messages:
                yield msg

        mock_ws.__aiter__ = lambda self: fake_ws_iter()
        mock_ws.__aenter__ = AsyncMock(return_value=mock_ws)
        mock_ws.__aexit__ = AsyncMock(return_value=False)

        mock_connect = MagicMock(return_value=mock_ws)

        async def dummy_stream():
            yield b"\x00" * 320
            yield b"\x00" * 320

        results: list[Transcription] = []
        with pytest.MonkeyPatch().context() as mp:
            import websockets
            mp.setattr(websockets, "connect", mock_connect)
            async for t in p.transcribe_stream(dummy_stream()):
                results.append(t)

        assert len(results) == 2
        assert results[0].text == "hello world"
        assert results[0].confidence == 0.97
        assert results[0].language == "en"
        # Deepgram provider yields full-text snapshots (confirmed + latest).
        assert results[1].text == "hello world how are you"

    @pytest.mark.asyncio
    async def test_transcribe_stream_raises_not_started(self):
        """transcribe_stream() raises RuntimeError if provider not started."""
        p = DeepgramSTT()
        # _client is None (not started)

        async def dummy():
            yield b""

        with pytest.raises(RuntimeError, match="not started"):
            async for _ in p.transcribe_stream(dummy()):
                pass
