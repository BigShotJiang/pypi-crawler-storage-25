"""Unit tests for Sherpa-ONNX local STT provider."""
from __future__ import annotations

import sys
from unittest.mock import AsyncMock, MagicMock

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions
from openspeechapi.providers.stt.sherpa_onnx import SherpaOnnxSTT, SherpaOnnxSTTSettings


def _make_audio() -> AudioData:
    return AudioData(
        data=b"\x00" * 32,
        sample_rate=16000,
        channels=1,
        format=AudioFormat.PCM_16K,
    )


class TestSherpaOnnxSettings:
    def test_defaults(self):
        s = SherpaOnnxSTTSettings()
        assert s.api_url == "http://127.0.0.1:17000"
        assert s.ws_path == "/"
        assert s.language == "auto"
        assert s.retries == 0


class TestSherpaOnnxSTT:
    def test_metadata(self):
        p = SherpaOnnxSTT()
        assert p.name == "sherpa-onnx-stt"
        assert p.provider_type == ProviderType.STT
        assert p.execution_mode == ExecMode.LOCAL
        assert p.settings_cls is SherpaOnnxSTTSettings
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities
        assert Capability.STREAMING in p.capabilities

    @pytest.mark.asyncio
    async def test_start_missing_sdk(self):
        p = SherpaOnnxSTT()
        orig = sys.modules.get("httpx")
        sys.modules["httpx"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="Install httpx"):
                await p.start()
        finally:
            if orig is None:
                sys.modules.pop("httpx", None)
            else:
                sys.modules["httpx"] = orig

    @pytest.mark.asyncio
    async def test_health_check_and_transcribe(self):
        p = SherpaOnnxSTT()
        mock_client = MagicMock()
        mock_client.get = AsyncMock(return_value=MagicMock(status_code=200))
        p._client = mock_client
        p._transcribe_samples_via_ws = AsyncMock(return_value="hello world")

        assert await p.health_check() is True
        out = await p.transcribe(_make_audio(), STTOptions(language="en"))
        assert out.text == "hello world"
        assert out.language == "en"
        assert out.confidence is None
        assert isinstance(out.duration_ms, int)

    @pytest.mark.asyncio
    async def test_transcribe_raises_when_not_started(self):
        p = SherpaOnnxSTT()
        with pytest.raises(RuntimeError, match="not started"):
            await p.transcribe(_make_audio())

    @pytest.mark.asyncio
    async def test_pcm16_to_float32_bytes(self):
        p = SherpaOnnxSTT()
        data = b"\x00\x00\x00\x80"  # 0, -32768
        raw = p._pcm16_bytes_to_float32_bytes(data)
        assert isinstance(raw, (bytes, bytearray))
        assert len(raw) == 8
