"""Tests for the macOS native TTS provider (macos-say)."""
from __future__ import annotations

import io
import wave
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, TTSOptions
from openspeechapi.providers.tts.macos_say import MacOSSaySettings, MacOSSayTTS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_wav_bytes(sample_rate: int = 22050, n_frames: int = 100) -> bytes:
    """Build a minimal valid WAV buffer."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"\x00\x00" * n_frames)
    return buf.getvalue()


# ===========================================================================
# Settings
# ===========================================================================

class TestMacOSSaySettings:
    def test_defaults(self):
        s = MacOSSaySettings()
        assert s.default_voice == "Samantha"
        assert s.default_rate == 200

    def test_custom(self):
        s = MacOSSaySettings(default_voice="Alex", default_rate=150)
        assert s.default_voice == "Alex"
        assert s.default_rate == 150


# ===========================================================================
# Metadata
# ===========================================================================

class TestMacOSSayTTSMetadata:
    def test_metadata(self):
        p = MacOSSayTTS()
        assert p.name == "macos-say"
        assert p.provider_type == ProviderType.TTS
        assert p.execution_mode == ExecMode.IN_PROCESS
        assert p.settings_cls is MacOSSaySettings
        assert Capability.BATCH in p.capabilities
        assert Capability.MULTILINGUAL in p.capabilities
        assert Capability.STREAMING not in p.capabilities


# ===========================================================================
# Lifecycle
# ===========================================================================

class TestMacOSSayTTSLifecycle:
    @pytest.mark.asyncio
    async def test_start_success(self):
        p = MacOSSayTTS()
        with patch("openspeechapi.providers.tts.macos_say.shutil.which", return_value="/usr/bin/say"):
            await p.start()
        assert p._available is True

    @pytest.mark.asyncio
    async def test_start_failure_say_not_found(self):
        p = MacOSSayTTS()
        with patch("openspeechapi.providers.tts.macos_say.shutil.which", return_value=None):
            with pytest.raises(RuntimeError, match="say.*not found"):
                await p.start()
        assert p._available is False

    @pytest.mark.asyncio
    async def test_stop_clears_state(self):
        p = MacOSSayTTS()
        p._available = True
        p._voices_cache = [{"name": "Samantha"}]
        await p.stop()
        assert p._available is False
        assert p._voices_cache is None

    @pytest.mark.asyncio
    async def test_health_check(self):
        p = MacOSSayTTS()
        # Before start, health_check returns True if 'say' command exists (macOS)
        with patch("shutil.which", return_value=None):
            assert await p.health_check() is False
        p._available = True
        assert await p.health_check() is True


# ===========================================================================
# Synthesis
# ===========================================================================

class TestMacOSSayTTSSynthesize:
    @pytest.mark.asyncio
    async def test_synthesize_not_started(self):
        p = MacOSSayTTS()
        with pytest.raises(RuntimeError, match="not started"):
            await p.synthesize("hello")

    @pytest.mark.asyncio
    async def test_synthesize_returns_audio_data(self):
        p = MacOSSayTTS()
        p._available = True

        wav_bytes = _make_wav_bytes(22050, 200)

        # Mock _run_say to write WAV bytes (pretending they are AIFF output)
        # Instead, we mock AudioConverter.to_wav to return WAV directly
        async def fake_run_say(voice, rate, output_path, text):
            # Write a fake AIFF-like file; we'll mock the conversion
            from pathlib import Path
            Path(output_path).write_bytes(b"FORM\x00\x00\x00\x00AIFF")

        wav_audio = AudioData(
            data=wav_bytes,
            sample_rate=22050,
            channels=1,
            format=AudioFormat.WAV,
        )

        with patch.object(p, "_run_say", side_effect=fake_run_say):
            with patch(
                "openspeechapi.providers.tts.macos_say.AudioConverter.to_wav",
                return_value=wav_audio,
            ):
                result = await p.synthesize("hello world")

        assert isinstance(result, AudioData)
        assert result.format == AudioFormat.WAV
        assert result.sample_rate == 22050
        assert result.channels == 1
        assert result.duration_ms is not None
        assert result.duration_ms > 0
        assert result.data[:4] == b"RIFF"

    @pytest.mark.asyncio
    async def test_synthesize_uses_opts_voice_and_speed(self):
        p = MacOSSayTTS(MacOSSaySettings(default_voice="Samantha", default_rate=200))
        p._available = True

        wav_bytes = _make_wav_bytes()
        wav_audio = AudioData(
            data=wav_bytes, sample_rate=22050, channels=1, format=AudioFormat.WAV,
        )

        captured_args: dict = {}

        async def fake_run_say(voice, rate, output_path, text):
            captured_args["voice"] = voice
            captured_args["rate"] = rate
            from pathlib import Path
            Path(output_path).write_bytes(b"FORM\x00\x00\x00\x00AIFF")

        opts = TTSOptions(voice="Alex", speed=1.5)

        with patch.object(p, "_run_say", side_effect=fake_run_say):
            with patch(
                "openspeechapi.providers.tts.macos_say.AudioConverter.to_wav",
                return_value=wav_audio,
            ):
                await p.synthesize("test", opts)

        assert captured_args["voice"] == "Alex"
        assert captured_args["rate"] == 300  # 200 * 1.5

    @pytest.mark.asyncio
    async def test_synthesize_uses_default_voice_when_opts_none(self):
        p = MacOSSayTTS(MacOSSaySettings(default_voice="Victoria", default_rate=180))
        p._available = True

        wav_bytes = _make_wav_bytes()
        wav_audio = AudioData(
            data=wav_bytes, sample_rate=22050, channels=1, format=AudioFormat.WAV,
        )

        captured_args: dict = {}

        async def fake_run_say(voice, rate, output_path, text):
            captured_args["voice"] = voice
            captured_args["rate"] = rate
            from pathlib import Path
            Path(output_path).write_bytes(b"FORM\x00\x00\x00\x00AIFF")

        with patch.object(p, "_run_say", side_effect=fake_run_say):
            with patch(
                "openspeechapi.providers.tts.macos_say.AudioConverter.to_wav",
                return_value=wav_audio,
            ):
                await p.synthesize("test")

        assert captured_args["voice"] == "Victoria"
        assert captured_args["rate"] == 180  # 180 * 1.0

    @pytest.mark.asyncio
    async def test_synthesize_stream_yields_chunks(self):
        """synthesize_stream should batch-synthesize then yield chunks."""
        from openspeechapi.core.models import AudioChunk

        p = MacOSSayTTS()
        p._available = True

        wav_buf = io.BytesIO()
        with wave.open(wav_buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(22050)
            wf.writeframes(b"\x00\x00" * 100)
        fake_wav = wav_buf.getvalue()

        fake_result = AudioData(
            data=fake_wav,
            sample_rate=22050,
            channels=1,
            format=AudioFormat.WAV,
            duration_ms=100,
        )

        with patch.object(p, "synthesize", new_callable=AsyncMock, return_value=fake_result):
            chunks = []
            async for chunk in p.synthesize_stream("hello"):
                chunks.append(chunk)

        assert len(chunks) >= 2  # at least 1 data chunk + 1 final
        assert all(isinstance(c, AudioChunk) for c in chunks)
        assert chunks[-1].is_final is True
        assert chunks[-1].data == b""
        total_data = b"".join(c.data for c in chunks if c.data)
        assert len(total_data) > 0


# ===========================================================================
# Voice listing & parsing
# ===========================================================================

class TestMacOSSayTTSVoices:
    def test_parse_voices_output(self):
        output = (
            "Samantha            en_US    # Hello, my name is Samantha.\n"
            "Alex                en_US    # Most people recognize me by my voice.\n"
            "Ting-Ting           zh_CN    # 你好，我叫Ting-Ting。\n"
            "Kyoko               ja_JP    # こんにちは、私の名前はKyokoです。\n"
            "Yuna                ko_KR    # 안녕하세요. 제 이름은 Yuna입니다.\n"
            "Thomas              fr_FR    # Bonjour, je m'appelle Thomas.\n"
        )
        voices = MacOSSayTTS._parse_voices_output(output)

        assert len(voices) == 6

        # Check first voice
        assert voices[0]["name"] == "Samantha"
        assert voices[0]["language"] == "en_US"
        assert voices[0]["group"] == "English"
        assert "Samantha" in voices[0]["description"]

        # Check Chinese voice
        zh_voice = next(v for v in voices if v["name"] == "Ting-Ting")
        assert zh_voice["language"] == "zh_CN"
        assert zh_voice["group"] == "中文"

        # Check Japanese voice
        ja_voice = next(v for v in voices if v["name"] == "Kyoko")
        assert ja_voice["language"] == "ja_JP"
        assert ja_voice["group"] == "日本語"

        # Check Korean voice
        ko_voice = next(v for v in voices if v["name"] == "Yuna")
        assert ko_voice["language"] == "ko_KR"
        assert ko_voice["group"] == "한국어"

        # Check French voice
        fr_voice = next(v for v in voices if v["name"] == "Thomas")
        assert fr_voice["language"] == "fr_FR"
        assert fr_voice["group"] == "Français"

    def test_parse_voices_output_empty(self):
        assert MacOSSayTTS._parse_voices_output("") == []
        assert MacOSSayTTS._parse_voices_output("\n\n") == []

    def test_parse_voices_output_unknown_language(self):
        output = "VoiceX              xx_YY    # Test voice.\n"
        voices = MacOSSayTTS._parse_voices_output(output)
        assert len(voices) == 1
        assert voices[0]["group"] == "XX"  # falls back to uppercase prefix

    @pytest.mark.asyncio
    async def test_list_voices_calls_run_command(self):
        p = MacOSSayTTS()
        p._available = True

        sample_output = "Samantha            en_US    # Hello.\n"

        with patch.object(p, "_run_command", new_callable=AsyncMock, return_value=sample_output):
            voices = await p.list_voices()

        assert len(voices) == 1
        assert voices[0]["name"] == "Samantha"

    @pytest.mark.asyncio
    async def test_list_voices_caches_result(self):
        p = MacOSSayTTS()
        p._available = True

        sample_output = "Samantha            en_US    # Hello.\n"
        mock_run = AsyncMock(return_value=sample_output)

        with patch.object(p, "_run_command", mock_run):
            voices1 = await p.list_voices()
            voices2 = await p.list_voices()

        # _run_command should only be called once due to caching
        mock_run.assert_called_once()
        assert voices1 is voices2
