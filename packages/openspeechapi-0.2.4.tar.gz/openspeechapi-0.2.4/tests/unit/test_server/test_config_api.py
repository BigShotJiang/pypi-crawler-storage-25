"""Tests for config management API endpoints."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from textwrap import dedent
from pathlib import Path

from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.server.app import create_app
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def config_app(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings:
              model_size: tiny
              fail: false
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings:
              voice: default
    """))
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    return create_app(cfg, registry)


@pytest.fixture
def config_client(config_app):
    with TestClient(config_app) as c:
        yield c


class TestConfigAPI:
    def test_get_config(self, config_client):
        res = config_client.get("/v1/admin/config")
        assert res.status_code == 200
        data = res.json()
        assert "engines" in data
        assert "stt" in data["engines"]
        assert "tts" in data["engines"]
        # Verify provider names are present
        assert data["engines"]["stt"]["provider"] == "fake-stt"
        assert data["engines"]["tts"]["provider"] == "fake-tts"

    def test_get_config_includes_exec_mode(self, config_client):
        res = config_client.get("/v1/admin/config")
        assert res.status_code == 200
        data = res.json()
        assert data["engines"]["stt"]["exec_mode"] == "in_process"
        assert data["engines"]["tts"]["exec_mode"] == "in_process"

    def test_get_config_includes_settings(self, config_client):
        res = config_client.get("/v1/admin/config")
        assert res.status_code == 200
        data = res.json()
        stt_settings = data["engines"]["stt"]["settings"]
        assert stt_settings["model_size"] == "tiny"
        assert stt_settings["fail"] is False

    def test_get_config_masks_secrets(self, config_client):
        # The test fixture doesn't have api_key fields,
        # but we verify the endpoint works and returns sanitized settings
        res = config_client.get("/v1/admin/config")
        assert res.status_code == 200
        data = res.json()
        assert "settings" in data["engines"]["stt"]

    def test_get_provider_templates(self, config_client):
        res = config_client.get("/v1/admin/provider-templates")
        assert res.status_code == 200
        data = res.json()
        assert "templates" in data
        assert len(data["templates"]) > 0
        # Verify structure of each template
        for tpl in data["templates"]:
            assert "provider" in tpl
            assert "type" in tpl
            assert "defaults" in tpl

    def test_provider_templates_contain_known_providers(self, config_client):
        res = config_client.get("/v1/admin/provider-templates")
        assert res.status_code == 200
        data = res.json()
        provider_names = [t["provider"] for t in data["templates"]]
        # At least some of the cloud providers should be in the templates
        assert "fake-stt" in provider_names or len(provider_names) > 0

    def test_put_config_saves_and_reloads(self, config_client):
        new_config = {
            "engines": {
                "stt": {
                    "provider": "fake-stt",
                    "exec_mode": "in_process",
                    "settings": {"model_size": "large", "fail": False},
                },
                "tts": {
                    "provider": "fake-tts",
                    "exec_mode": "in_process",
                    "settings": {"voice": "new_voice"},
                },
            }
        }
        res = config_client.put("/v1/admin/config", json=new_config)
        assert res.status_code == 200
        data = res.json()
        assert data["status"] == "ok"

    def test_put_config_persists_changes(self, config_client, tmp_path):
        new_config = {
            "engines": {
                "stt": {
                    "provider": "fake-stt",
                    "exec_mode": "in_process",
                    "settings": {"model_size": "medium", "fail": False},
                },
                "tts": {
                    "provider": "fake-tts",
                    "exec_mode": "in_process",
                    "settings": {"voice": "updated_voice"},
                },
            }
        }
        res = config_client.put("/v1/admin/config", json=new_config)
        assert res.status_code == 200

        # Read back to verify persistence
        res2 = config_client.get("/v1/admin/config")
        assert res2.status_code == 200
        data = res2.json()
        assert data["engines"]["stt"]["settings"]["model_size"] == "medium"
        assert data["engines"]["tts"]["settings"]["voice"] == "updated_voice"

    def test_get_config_raw(self, config_client):
        res = config_client.get("/v1/admin/config/raw")
        assert res.status_code == 200
        data = res.json()
        # Old format: providers key contains engine configs
        assert "providers" in data
        # Raw endpoint returns unmasked data
        assert "stt" in data["providers"]
        assert "tts" in data["providers"]

    def test_get_config_raw_includes_settings(self, config_client):
        res = config_client.get("/v1/admin/config/raw")
        assert res.status_code == 200
        data = res.json()
        stt_cfg = data["providers"]["stt"]
        assert stt_cfg["provider"] == "fake-stt"
        assert stt_cfg["settings"]["model_size"] == "tiny"
