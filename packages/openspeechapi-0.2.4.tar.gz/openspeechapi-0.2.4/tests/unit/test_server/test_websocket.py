"""Tests for server WebSocket endpoints."""
import json
import pytest
from dataclasses import dataclass
from fastapi.testclient import TestClient
from textwrap import dedent

from openspeechapi.core.base import STTProvider
from openspeechapi.core.enums import AudioFormat, Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.core.settings import BaseSettings
from openspeechapi.server.app import create_app
from tests.conftest import FakeSTT, FakeTTS


@dataclass
class FakeStreamingSTTSettings(BaseSettings):
    pass


class FakeStreamingSTT(STTProvider):
    """Fake STT with STREAMING capability for testing real-time path."""
    name = "fake-streaming-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = FakeStreamingSTTSettings
    capabilities = {Capability.STREAMING, Capability.BATCH}

    def __init__(self, settings=None):
        self.settings = settings or FakeStreamingSTTSettings()
        self._started = False

    async def start(self) -> None:
        self._started = True

    async def stop(self) -> None:
        self._started = False

    async def health_check(self) -> bool:
        return self._started

    async def transcribe(self, audio: AudioData, opts: STTOptions | None = None) -> Transcription:
        return Transcription(text="batch transcription", confidence=0.9, language="en")

    async def transcribe_stream(self, stream):
        # Consume the stream and yield transcriptions
        async for _chunk in stream:
            pass
        yield Transcription(text="stream chunk 1", confidence=0.95, language="en")
        yield Transcription(text="stream chunk 2", confidence=0.93, language="en")


@pytest.fixture
def test_app(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    return create_app(cfg, registry)


@pytest.fixture
def streaming_test_app(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          streaming-stt:
            provider: fake-streaming-stt
            exec_mode: in_process
            settings: {}
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    registry = ProviderRegistry()
    registry.register("fake-streaming-stt", FakeStreamingSTT)
    registry.register("fake-tts", FakeTTS)
    return create_app(cfg, registry)


@pytest.fixture
def client(test_app):
    with TestClient(test_app) as c:
        yield c


@pytest.fixture
def streaming_client(streaming_test_app):
    with TestClient(streaming_test_app) as c:
        yield c


class TestSTTStream:
    def test_stt_stream_basic(self, client):
        """Batch-only provider uses accumulate-then-transcribe path."""
        with client.websocket_connect("/v1/stt/stream?provider=stt") as ws:
            ws.send_bytes(b"fake audio data")
            ws.send_text(json.dumps({"type": "stop"}))
            # First message is meta (streaming=false for batch providers)
            meta = ws.receive_json()
            assert meta["type"] == "meta"
            assert meta["streaming"] is False
            response = ws.receive_json()
            assert response["type"] == "final"
            assert response["text"] == "fake transcription"
            closed = ws.receive_json()
            assert closed["type"] == "closed"

    def test_stt_stream_real_streaming(self, streaming_client):
        """Streaming-capable provider uses real-time transcribe_stream() path."""
        with streaming_client.websocket_connect("/v1/stt/stream?provider=streaming-stt") as ws:
            ws.send_bytes(b"audio chunk 1")
            ws.send_bytes(b"audio chunk 2")
            ws.send_text(json.dumps({"type": "stop"}))
            # First message is meta (streaming=true for streaming providers)
            meta = ws.receive_json()
            assert meta["type"] == "meta"
            assert meta["streaming"] is True
            # Expect partial results
            partials = []
            while True:
                msg = ws.receive_json()
                if msg["type"] == "closed":
                    break
                assert msg["type"] == "partial"
                partials.append(msg["text"])
            assert len(partials) == 2
            assert partials[0] == "stream chunk 1"
            assert partials[1] == "stream chunk 2"


class TestTTSStream:
    def test_tts_stream_basic(self, client):
        with client.websocket_connect("/v1/tts/stream") as ws:
            ws.send_text(json.dumps({"text": "hello", "provider": "tts"}))
            # Receive binary audio chunks then done message
            chunks = []
            while True:
                msg = ws.receive()
                if "text" in msg:
                    data = json.loads(msg["text"])
                    if data.get("type") == "done":
                        break
                elif "bytes" in msg:
                    chunks.append(msg["bytes"])
            assert len(chunks) > 0
