"""Tests for server REST endpoints."""
import pytest
from fastapi.testclient import TestClient
from textwrap import dedent
from pathlib import Path

from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.local_engines.models import EngineStatus
from openspeechapi.server.app import create_app
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def test_app(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    return create_app(cfg, registry)


@pytest.fixture
def client(test_app):
    with TestClient(test_app) as c:
        yield c


@pytest.fixture
def failing_app(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings:
              fail: true
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    return create_app(cfg, registry)


@pytest.fixture
def failing_client(failing_app):
    with TestClient(failing_app) as c:
        yield c


class TestSTTRoutes:
    def test_transcribe(self, client):
        response = client.post(
            "/v1/stt/transcribe",
            files={"audio": ("test.wav", b"fake audio data", "audio/wav")},
            data={"provider": "stt"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["text"] == "fake transcription"
        assert data["provider"] == "stt"

    def test_transcribe_unknown_provider(self, client):
        response = client.post(
            "/v1/stt/transcribe",
            files={"audio": ("test.wav", b"data", "audio/wav")},
            data={"provider": "nonexistent"},
        )
        assert response.status_code == 404

    def test_transcribe_accepts_advanced_options(self, client):
        response = client.post(
            "/v1/stt/transcribe",
            files={"audio": ("test.wav", b"fake audio data", "audio/wav")},
            data={
                "provider": "stt",
                "language": "en",
                "model": "large-v3-turbo",
                "device": "mps",
                "beam_size": "8",
                "fp16": "true",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["provider"] == "stt"

    def test_fanout(self, client):
        response = client.post(
            "/v1/stt/transcribe/fanout",
            files={"audio": ("test.wav", b"data", "audio/wav")},
            data={"providers": "stt", "strategy": "collect_all"},
        )
        assert response.status_code == 200

    def test_fanout_invalid_strategy(self, client):
        response = client.post(
            "/v1/stt/transcribe/fanout",
            files={"audio": ("test.wav", b"data", "audio/wav")},
            data={"providers": "stt", "strategy": "invalid"},
        )
        assert response.status_code == 422

    def test_transcribe_empty_audio(self, client):
        response = client.post(
            "/v1/stt/transcribe",
            files={"audio": ("empty.wav", b"", "audio/wav")},
            data={"provider": "stt"},
        )
        assert response.status_code in (200, 502)
        if response.status_code == 200:
            data = response.json()
            assert data["text"] == "" or data["text"] is not None

    def test_transcribe_provider_failure_returns_502(self, failing_client):
        response = failing_client.post(
            "/v1/stt/transcribe",
            files={"audio": ("test.wav", b"fake audio data", "audio/wav")},
            data={"provider": "stt"},
        )
        assert response.status_code == 502
        assert "failed" in response.json()["detail"].lower()


class TestTTSRoutes:
    def test_synthesize(self, client):
        response = client.post(
            "/v1/tts/synthesize",
            json={"text": "hello", "provider": "tts"},
        )
        assert response.status_code == 200
        assert len(response.content) > 0
        assert response.headers["X-Provider"] == "tts"
        assert int(response.headers["X-Duration-Ms"]) >= 0
        assert int(response.headers["X-Elapsed-Ms"]) >= 0

    def test_synthesize_unknown_provider(self, client):
        response = client.post(
            "/v1/tts/synthesize",
            json={"text": "hello", "provider": "nonexistent"},
        )
        assert response.status_code == 404

    def test_voices_returns_empty_when_no_list_voices(self, client):
        """GET /v1/tts/{provider}/voices returns empty list when provider has no list_voices."""
        response = client.get("/v1/tts/tts/voices")
        assert response.status_code == 200
        data = response.json()
        assert data["voices"] == []

    def test_voices_unknown_provider_returns_404(self, client):
        """GET /v1/tts/{provider}/voices returns 404 for nonexistent provider."""
        response = client.get("/v1/tts/nonexistent/voices")
        assert response.status_code == 404


class TestManagement:
    def test_engines(self, client):
        response = client.get("/v1/engines")
        assert response.status_code == 200
        data = response.json()
        assert len(data["engines"]) == 2

    def test_health(self, client):
        response = client.get("/v1/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] in ("ok", "degraded")

    def test_metrics(self, client):
        response = client.get("/v1/metrics")
        assert response.status_code == 200

    def test_admin_reload_returns_diff_keys(self, client):
        """POST /v1/admin/reload returns added/removed/updated/unchanged."""
        response = client.post("/v1/admin/reload")
        assert response.status_code == 200
        data = response.json()
        assert set(data.keys()) == {"added", "removed", "updated", "unchanged"}

    def test_admin_reload_unchanged_on_identical_config(self, client, tmp_path):
        """Reloading with no config changes reports everything as unchanged."""
        response = client.post("/v1/admin/reload")
        assert response.status_code == 200
        data = response.json()
        assert data["added"] == []
        assert data["removed"] == []
        assert data["updated"] == []
        # Both configured providers should be unchanged
        assert set(data["unchanged"]) == {"stt", "tts"}

    def test_admin_reload_after_adding_provider(self, test_app, tmp_path):
        """Reloading after adding a provider to the config reports it as added."""
        from textwrap import dedent
        # Retrieve config path from app state and extend it
        config_path = test_app.state.config_path
        config_path.write_text(dedent("""\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
              tts:
                provider: fake-tts
                exec_mode: in_process
                settings: {}
              stt2:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
        """))
        with TestClient(test_app) as c:
            response = c.post("/v1/admin/reload")
        assert response.status_code == 200
        data = response.json()
        assert "stt2" in data["added"]

    def test_admin_states(self, client):
        """GET /v1/admin/states returns lifecycle state for each provider."""
        response = client.get("/v1/admin/states")
        assert response.status_code == 200
        data = response.json()
        assert "states" in data
        states = data["states"]
        # Both providers should have a state entry
        assert "stt" in states
        assert "tts" in states
        # Values should be valid state strings
        valid_states = {"registered", "starting", "ready", "stopped"}
        for state in states.values():
            assert state in valid_states


class _FakeTask:
    def __init__(self, task_id: str = "task-1") -> None:
        self.task_id = task_id

    def snapshot(self):
        return {
            "task_id": self.task_id,
            "engine": "fish-speech",
            "action": "start",
            "runtime": "docker",
            "status": "running",
            "phase": "start_container",
            "progress": 50.0,
            "message": "starting",
            "error": None,
            "started_at": "2026-01-01T00:00:00+00:00",
            "updated_at": "2026-01-01T00:00:00+00:00",
            "finished_at": None,
            "metadata": {},
        }


class _FakeEngineManager:
    def __init__(self) -> None:
        self._task = _FakeTask()
        self.emitter = _NoopEmitter()

    def run_action_async(self, engine, action, cfg):  # noqa: ANN001
        return self._task

    def get_task(self, task_id):  # noqa: ANN001
        if task_id != self._task.task_id:
            return None
        return self._task

    def list_tasks(self, engine=None, limit=20):  # noqa: ANN001
        return [self._task]

    def cancel_task(self, task_id):  # noqa: ANN001
        if task_id != self._task.task_id:
            return None
        return self._task

    def status(self, engine, cfg):  # noqa: ANN001
        return EngineStatus(
            engine=engine,
            runtime=cfg.runtime,
            running=True,
            healthy=True,
            detail="ok",
            metadata={"mode": cfg.runtime},
        )

    def logs(self, engine, cfg, lines=100):  # noqa: ANN001
        return f"{engine} log line ({lines})"


class _DoneTask(_FakeTask):
    def snapshot(self):
        data = super().snapshot()
        data["status"] = "succeeded"
        data["phase"] = "completed"
        data["progress"] = 100.0
        data["message"] = "done"
        data["finished_at"] = "2026-01-01T00:01:00+00:00"
        return data


class _DoneEngineManager(_FakeEngineManager):
    def __init__(self) -> None:
        self._task = _DoneTask()
        self.emitter = _NoopEmitter()


class _NoopEmitter:
    def subscribe(self, _task_id):  # noqa: ANN001
        import queue

        return queue.Queue()

    def unsubscribe(self, _task_id, _q):  # noqa: ANN001
        return None


class TestEngineManagement:
    def test_start_action(self, client):
        client.app.state.engine_manager = _FakeEngineManager()
        response = client.post(
            "/v1/engines/actions",
            json={
                "engine": "fish-speech",
                "action": "start",
                "runtime": "docker",
                "options": {},
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["task"]["task_id"] == "task-1"

    def test_get_task(self, client):
        client.app.state.engine_manager = _FakeEngineManager()
        response = client.get("/v1/engines/tasks/task-1")
        assert response.status_code == 200
        assert response.json()["task"]["status"] == "running"

    def test_list_tasks(self, client):
        client.app.state.engine_manager = _FakeEngineManager()
        response = client.get("/v1/engines/tasks?engine=fish-speech&limit=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data["tasks"]) == 1

    def test_stream_task_events(self, client):
        client.app.state.engine_manager = _DoneEngineManager()
        response = client.get("/v1/engines/tasks/task-1/events")
        assert response.status_code == 200
        assert "event: snapshot" in response.text
        assert "event: done" in response.text

    def test_cancel_task(self, client):
        client.app.state.engine_manager = _FakeEngineManager()
        response = client.post("/v1/engines/tasks/task-1/cancel")
        assert response.status_code == 200
        assert response.json()["task"]["task_id"] == "task-1"

    def test_engine_status(self, client):
        client.app.state.engine_manager = _FakeEngineManager()
        response = client.get("/v1/engines/status?engine=fish-speech&runtime=docker")
        assert response.status_code == 200
        data = response.json()
        assert data["running"] is True
        assert data["healthy"] is True

    def test_engine_logs(self, client):
        client.app.state.engine_manager = _FakeEngineManager()
        response = client.get("/v1/engines/logs?engine=fish-speech&runtime=docker&lines=12")
        assert response.status_code == 200
        assert "log line" in response.json()["logs"]


class TestWebUI:
    def test_ui_index(self, client):
        response = client.get("/ui")
        assert response.status_code == 200
        assert "OpenSpeechAPI Control Center" in response.text

    def test_ui_asset(self, client):
        response = client.get("/ui/styles.css")
        assert response.status_code == 200
        assert "font-family" in response.text
