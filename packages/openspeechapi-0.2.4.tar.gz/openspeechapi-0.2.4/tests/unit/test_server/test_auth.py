"""Tests for authentication middleware."""
import pytest
from fastapi.testclient import TestClient
from textwrap import dedent

from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.server.app import create_app
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def authed_app(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        server:
          auth:
            enabled: true
            api_keys:
              - test-key-123
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
    """))
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    return create_app(cfg, registry)


@pytest.fixture
def authed_client(authed_app):
    with TestClient(authed_app) as c:
        yield c


class TestAuth:
    def test_no_token_returns_401(self, authed_client):
        resp = authed_client.get("/v1/engines")
        assert resp.status_code == 401

    def test_invalid_token_returns_401(self, authed_client):
        resp = authed_client.get(
            "/v1/engines", headers={"Authorization": "Bearer wrong"}
        )
        assert resp.status_code == 401

    def test_valid_token_passes(self, authed_client):
        resp = authed_client.get(
            "/v1/engines", headers={"Authorization": "Bearer test-key-123"}
        )
        assert resp.status_code == 200

    def test_health_exempt_from_auth(self, authed_client):
        resp = authed_client.get("/v1/health")
        assert resp.status_code == 200

    def test_webui_exempt_from_auth(self, authed_client):
        resp = authed_client.get("/ui")
        assert resp.status_code == 200

    def test_no_auth_config_means_open(self, tmp_path):
        cfg = tmp_path / "providers.yaml"
        cfg.write_text(dedent("""\
            providers:
              stt:
                provider: fake-stt
                exec_mode: in_process
                settings: {}
        """))
        registry = ProviderRegistry()
        registry.register("fake-stt", FakeSTT)
        app = create_app(cfg, registry)
        with TestClient(app) as client:
            resp = client.get("/v1/engines")
            assert resp.status_code == 200
