"""Tests for AIM model path resolver."""
from __future__ import annotations

from pathlib import Path

from openspeechapi.local_engines import aim_resolver
from openspeechapi.local_engines.aim_resolver import resolve_aim_model_paths


def test_resolve_aim_model_paths_prefers_provision_then_canonical(monkeypatch, tmp_path: Path) -> None:
    def _fake_run(args: list[str]) -> str:  # noqa: ANN202
        if args == ["resolve", "whisper-large-v3-turbo", "--engine", "whisper", "--json"]:
            return (
                '{"id":"whisper-large-v3-turbo","path":"'
                + str(tmp_path / "AI" / "whisper" / "large-v3-turbo.pt")
                + '","resolved_file":"'
                + str(tmp_path / "AI" / "whisper" / "large-v3-turbo.pt")
                + '","engines":["whisper"],"format":"pt"}'
            )
        raise RuntimeError(f"unexpected args: {args}")

    monkeypatch.setattr(aim_resolver, "_run_aim", _fake_run)

    (tmp_path / "AI" / "whisper").mkdir(parents=True, exist_ok=True)
    (tmp_path / "AI" / "whisper" / "large-v3-turbo.pt").write_text("x", encoding="utf-8")
    got = resolve_aim_model_paths(
        model_ids=["whisper-large-v3-turbo"],
        provision_engine="whisper",
        kind="file",
    )
    assert got == [str(tmp_path / "AI" / "whisper" / "large-v3-turbo.pt")]


def test_resolve_aim_model_paths_for_dir_model(monkeypatch, tmp_path: Path) -> None:
    def _fake_run(args: list[str]) -> str:  # noqa: ANN202
        if args == ["resolve", "faster-whisper-large-v3-turbo", "--engine", "whisper", "--json"]:
            return (
                '{"id":"faster-whisper-large-v3-turbo","path":"'
                + str(tmp_path / "AI" / "store" / "asr" / "model" / "faster-whisper-large-v3-turbo")
                + '","resolved_file":null,"engines":["whisper"],"format":"ct2"}'
            )
        raise RuntimeError(f"unexpected args: {args}")

    monkeypatch.setattr(aim_resolver, "_run_aim", _fake_run)

    model_dir = tmp_path / "AI" / "store" / "asr" / "model" / "faster-whisper-large-v3-turbo"
    model_dir.mkdir(parents=True, exist_ok=True)
    got = resolve_aim_model_paths(
        model_ids=["faster-whisper-large-v3-turbo"],
        provision_engine="whisper",
        kind="dir",
    )
    assert got == [str(model_dir)]


def test_resolve_aim_model_paths_discovers_pt_inside_canonical_dir(monkeypatch, tmp_path: Path) -> None:
    def _fake_run(args: list[str]) -> str:  # noqa: ANN202
        if args == ["resolve", "whisper-large-v3", "--engine", "whisper", "--json"]:
            return (
                '{"id":"whisper-large-v3","path":"'
                + str(tmp_path / "AI" / "store" / "asr" / "model" / "whisper-large-v3")
                + '","resolved_file":null,"engines":["whisper"],"format":"pt"}'
            )
        raise RuntimeError(f"unexpected args: {args}")

    monkeypatch.setattr(aim_resolver, "_run_aim", _fake_run)

    model_dir = tmp_path / "AI" / "store" / "asr" / "model" / "whisper-large-v3"
    model_dir.mkdir(parents=True, exist_ok=True)
    model_file = model_dir / "large-v3.pt"
    model_file.write_text("x", encoding="utf-8")
    got = resolve_aim_model_paths(
        model_ids=["whisper-large-v3"],
        provision_engine="whisper",
        kind="file",
    )
    assert str(model_file) in got
