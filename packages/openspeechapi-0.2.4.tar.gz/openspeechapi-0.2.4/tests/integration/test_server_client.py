"""Integration tests: Server + Client full stack."""
import pytest
from textwrap import dedent
from pathlib import Path

import httpx

from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, STTOptions, TTSOptions
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.client.client import Client
from openspeechapi.server.app import create_app
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def app_and_registry(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    registry = ProviderRegistry()
    registry.register("fake-stt", FakeSTT)
    registry.register("fake-tts", FakeTTS)
    app = create_app(cfg, registry)
    return app


@pytest.fixture
async def client(app_and_registry):
    """Create a Client connected to the ASGI app (no real HTTP server needed)."""
    transport = httpx.ASGITransport(app=app_and_registry)
    http_client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

    c = Client.__new__(Client)
    c._base_url = "http://testserver"
    c._http = http_client

    from openspeechapi.client.client import _ClientSTT, _ClientTTS
    c.stt = _ClientSTT(c)
    c.tts = _ClientTTS(c)

    # Need to start dispatcher manually since lifespan doesn't run with ASGITransport
    await app_and_registry.state.dispatcher.start()

    yield c

    await app_and_registry.state.dispatcher.stop()
    await http_client.aclose()


class TestServerClientIntegration:
    @pytest.mark.asyncio
    async def test_stt_transcribe_via_client(self, client):
        """Client → Server → Dispatcher → FakeSTT → back to Client."""
        audio = AudioData(data=b"test audio", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = await client.stt.transcribe("stt", audio)
        assert result.text == "fake transcription"
        assert result.confidence == 0.95

    @pytest.mark.asyncio
    async def test_tts_synthesize_via_client(self, client):
        """Client → Server → Dispatcher → FakeTTS → back to Client."""
        result = await client.tts.synthesize("tts", "hello world")
        assert isinstance(result, AudioData)
        assert len(result.data) > 0

    @pytest.mark.asyncio
    async def test_stt_with_options(self, client):
        """Test STT options propagation through client → server."""
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = await client.stt.transcribe("stt", audio, STTOptions(language="en"))
        assert result.text == "fake transcription"

    @pytest.mark.asyncio
    async def test_fanout_via_client(self, client):
        """Client fanout → Server fanout endpoint."""
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        result = await client.stt.fanout(["stt"], audio, strategy="collect_all")
        assert "successes" in result
        assert "stt" in result["successes"]

    @pytest.mark.asyncio
    async def test_health_via_client(self, client):
        result = await client.health()
        assert result["status"] in ("ok", "degraded")

    @pytest.mark.asyncio
    async def test_list_engines_via_client(self, client):
        result = await client.list_engines()
        assert len(result) == 2
        names = {p["name"] for p in result}
        assert "stt" in names
        assert "tts" in names

    @pytest.mark.asyncio
    async def test_unknown_provider_returns_error(self, client):
        """Client should get an HTTP error for unknown provider."""
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.WAV)
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await client.stt.transcribe("nonexistent", audio)
        assert exc_info.value.response.status_code == 404
