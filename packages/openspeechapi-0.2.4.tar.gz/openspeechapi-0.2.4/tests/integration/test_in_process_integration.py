"""Integration test: full flow with InProcess execution."""
from textwrap import dedent
import pytest
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData, Transcription
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from tests.conftest import FakeSTT, FakeTTS


@pytest.fixture
def full_config(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
            filters:
              - type: confidence
                min: 0.5
          tts:
            provider: fake-tts
            exec_mode: in_process
            settings: {}
    """))
    return cfg


@pytest.fixture
def registry():
    r = ProviderRegistry()
    r.register("fake-stt", FakeSTT)
    r.register("fake-tts", FakeTTS)
    return r


class TestInProcessIntegration:
    @pytest.mark.asyncio
    async def test_full_stt_flow(self, full_config, registry):
        dispatcher = ServiceDispatcher.from_config(full_config, registry)
        await dispatcher.start()
        audio = AudioData(data=b"hello", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await dispatcher.stt.transcribe("stt", audio)
        assert result is not None
        assert isinstance(result, Transcription)
        assert result.text == "fake transcription"
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_full_tts_flow(self, full_config, registry):
        dispatcher = ServiceDispatcher.from_config(full_config, registry)
        await dispatcher.start()
        result = await dispatcher.tts.synthesize("tts", "Hello world")
        assert result is not None
        assert isinstance(result, AudioData)
        assert result.data == b"fake_audio"
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_health_check_all(self, full_config, registry):
        dispatcher = ServiceDispatcher.from_config(full_config, registry)
        await dispatcher.start()
        # Trigger lazy start by making a request
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        await dispatcher.stt.transcribe("stt", audio)
        await dispatcher.tts.synthesize("tts", "test")
        health = await dispatcher.health()
        assert all(health.values())
        await dispatcher.stop()
