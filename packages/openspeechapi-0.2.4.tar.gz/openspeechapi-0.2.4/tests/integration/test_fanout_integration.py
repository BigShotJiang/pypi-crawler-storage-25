"""Integration test: FanOut with multiple providers."""
from textwrap import dedent
import pytest
from openspeechapi.core.enums import AudioFormat
from openspeechapi.core.models import AudioData
from openspeechapi.core.registry import ProviderRegistry
from openspeechapi.dispatch.dispatcher import ServiceDispatcher
from openspeechapi.dispatch.fanout import CollectAll, FirstCompleted
from tests.conftest import FakeSTT


@pytest.fixture
def fanout_config(tmp_path):
    cfg = tmp_path / "providers.yaml"
    cfg.write_text(dedent("""\
        providers:
          stt-1:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
          stt-2:
            provider: fake-stt
            exec_mode: in_process
            settings: {}
    """))
    return cfg


@pytest.fixture
def registry():
    r = ProviderRegistry()
    r.register("fake-stt", FakeSTT)
    return r


class TestFanOutIntegration:
    @pytest.mark.asyncio
    async def test_fanout_first_completed(self, fanout_config, registry):
        dispatcher = ServiceDispatcher.from_config(fanout_config, registry)
        await dispatcher.start()
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await dispatcher.stt.fanout(["stt-1", "stt-2"], audio, strategy=FirstCompleted())
        assert result.text == "fake transcription"
        await dispatcher.stop()

    @pytest.mark.asyncio
    async def test_fanout_collect_all(self, fanout_config, registry):
        dispatcher = ServiceDispatcher.from_config(fanout_config, registry)
        await dispatcher.start()
        audio = AudioData(data=b"test", sample_rate=16000, channels=1, format=AudioFormat.PCM_16K)
        result = await dispatcher.stt.fanout(["stt-1", "stt-2"], audio, strategy=CollectAll())
        assert len(result.successes) == 2
        await dispatcher.stop()
