"""Workset model — named subsets of assets."""

from __future__ import annotations

from datetime import datetime
from typing import ClassVar

from pydantic import Field

from vd3storage.models.base import VD3Model, new_id, now_utc


class Workset(VD3Model):
    """A workset is a named subset of assets in the content database."""

    _csv_filename: ClassVar[str] = "worksets.csv"
    _primary_key: ClassVar[str] = "workset_id"

    workset_id: str = Field(default_factory=new_id)
    slug: str  # URL-safe identifier (unique)
    name: str  # Human-readable name
    description: str = ""
    created_at: datetime = Field(default_factory=now_utc)
    updated_at: datetime = Field(default_factory=now_utc)
