"""Asset model — global asset registry."""

from __future__ import annotations

import json
import warnings
from datetime import datetime
from typing import ClassVar

from pydantic import Field, field_validator

from vd3storage.models.base import VD3Model, new_id, now_utc


class Asset(VD3Model):
    """A video or image asset in the content database.

    Assets have a global identity (UUID + name + datasource) and metadata.
    Organization into worksets and packages is handled separately.
    """

    _csv_filename: ClassVar[str] = "assets.csv"
    _primary_key: ClassVar[str] = "asset_id"

    asset_id: str = Field(default_factory=new_id)
    name: str  # Original filename or user-provided name
    datasource: str  # Data source (required — where it came from, e.g., "dashcam-2024")
    asset_type: str = "video"  # "video" or "images"
    sensor_type: str = "unknown"
    sensor_mount: str = "unknown"
    camera_id: str = ""
    video_id: str = ""
    width: int = 0
    height: int = 0
    frame_count: int = 0
    nominal_fps: float = 0.0
    duration_ms: int = 0
    environment: str = "unknown"
    placement: str = "unknown"
    time_of_day: str = "unknown"
    spectrum: str = "unknown"
    codec: str = ""
    comments: str = ""
    source_hash: str = ""  # SHA-256 hash of the original source file
    media_path: str | None = None  # Relative path to media (video file or imageset directory)
    annotation_layers_json: str = "[]"  # Denormalized cache of annotation layers from metadata dir
    extra_json: str = "{}"  # Extensible JSON blob
    created_at: datetime = Field(default_factory=now_utc)
    updated_at: datetime = Field(default_factory=now_utc)

    @field_validator("extra_json")
    @classmethod
    def _validate_extra_json(cls, value: str) -> str:
        """Enforce the ``extra_json`` shape rule (§4.7 of the schema-cleanup plan).

        vd3 does not inspect the *contents* of any namespace — consumers own their
        own schemas. It enforces only structural shape:

        - Must be parseable JSON (reject non-JSON).
        - The root must be a JSON object (reject arrays/scalars at the root).
        - Every top-level key must hold an object, because top-level keys are
          namespace owners. Scalars or arrays at the top level mean a field has
          bypassed the namespace convention — warn so it's visible without
          breaking prototyping.

        No allowlist of namespace names. Picking a namespace is the consumer's
        responsibility; vd3 is general-purpose.
        """
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as e:
            raise ValueError(f"extra_json must be valid JSON: {e}") from e

        if not isinstance(parsed, dict):
            raise ValueError(f"extra_json root must be a JSON object, got {type(parsed).__name__}")

        flat_keys = [k for k, v in parsed.items() if not isinstance(v, dict)]
        if flat_keys:
            warnings.warn(
                f"extra_json top-level keys should hold objects (namespace owners); "
                f"found scalar/array values at: {flat_keys}. "
                f"Expected shape: {{'<namespace>': {{'{flat_keys[0]}': ...}}}}",
                UserWarning,
                stacklevel=2,
            )

        return value
