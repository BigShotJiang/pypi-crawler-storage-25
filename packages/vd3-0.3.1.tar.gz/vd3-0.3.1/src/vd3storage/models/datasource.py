"""Datasource model — sidecar metadata (description) for the implicit datasource string on assets."""

from __future__ import annotations

from datetime import datetime
from typing import ClassVar

from pydantic import Field

from vd3storage.models.base import VD3Model, now_utc


class Datasource(VD3Model):
    """Sidecar metadata for a datasource.

    Datasources are still referenced by name (a string column on Asset). This table
    just holds optional human-readable description for each datasource name; rows
    are created lazily when a description is set, and absence of a row is treated
    as an empty description.
    """

    _csv_filename: ClassVar[str] = "datasources.csv"
    _primary_key: ClassVar[str] = "name"

    name: str
    description: str = ""
    created_at: datetime = Field(default_factory=now_utc)
    updated_at: datetime = Field(default_factory=now_utc)
