"""WorksetAsset model — workset-asset membership with package organization."""

from __future__ import annotations

from datetime import datetime
from typing import ClassVar

from pydantic import Field

from vd3storage.models.base import VD3Model, now_utc


class WorksetAsset(VD3Model):
    """Many-to-many join: which assets belong to which worksets.

    Within a workset, assets are organized into packages (folders).
    """

    _csv_filename: ClassVar[str] = "workset_assets.csv"
    _primary_key: ClassVar[str] = "workset_id"  # Composite PK, but we need one for the ORM

    workset_id: str
    asset_id: str
    package: str = ""  # Package (folder) path within the workset, e.g., "training/urban"
    added_at: datetime = Field(default_factory=now_utc)
