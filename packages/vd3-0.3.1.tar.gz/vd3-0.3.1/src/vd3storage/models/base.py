"""Base model for all VD3 table models."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any, ClassVar, get_args, get_origin

from pydantic import BaseModel, ConfigDict


def new_id() -> str:
    """Generate a new UUID4 string."""
    return str(uuid.uuid4())


def now_utc() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(UTC)


# Mapping from Python types to DuckDB column types
_TYPE_MAP: dict[type, str] = {
    str: "VARCHAR",
    int: "BIGINT",
    float: "DOUBLE",
    bool: "BOOLEAN",
    datetime: "TIMESTAMP",
}


class VD3Model(BaseModel):
    """Base for all VD3 table models.

    Provides CSV filename mapping, primary key definition, and automatic
    DuckDB column type derivation from Pydantic field annotations.
    """

    model_config = ConfigDict(extra="forbid")

    # Subclasses must set these
    _csv_filename: ClassVar[str]
    _primary_key: ClassVar[str]

    @classmethod
    def csv_filename(cls) -> str:
        """Return the CSV filename for this model (e.g., 'assets.csv')."""
        return cls._csv_filename

    @classmethod
    def primary_key(cls) -> str:
        """Return the primary key column name."""
        return cls._primary_key

    @classmethod
    def duckdb_columns(cls) -> dict[str, str]:
        """Return {column_name: duckdb_type} for CREATE TABLE statements.

        Automatically derives DuckDB types from Pydantic field annotations.
        """
        columns: dict[str, str] = {}
        for field_name, field_info in cls.model_fields.items():
            annotation = field_info.annotation
            duckdb_type = _resolve_duckdb_type(annotation)
            columns[field_name] = duckdb_type
        return columns

    @classmethod
    def column_names(cls) -> list[str]:
        """Return ordered list of column names."""
        return list(cls.model_fields.keys())


def _resolve_duckdb_type(annotation: Any) -> str:
    """Resolve a Python type annotation to a DuckDB column type."""
    # Handle Optional types (Union[X, None])
    origin = get_origin(annotation)
    if origin is type(int | str):  # types.UnionType (X | Y)
        args = get_args(annotation)
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _TYPE_MAP.get(non_none[0], "VARCHAR")
        return "VARCHAR"

    # Direct type lookup
    if annotation in _TYPE_MAP:
        return _TYPE_MAP[annotation]

    return "VARCHAR"
