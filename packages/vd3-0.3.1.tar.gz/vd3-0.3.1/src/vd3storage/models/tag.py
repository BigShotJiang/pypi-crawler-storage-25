"""Tag model — flexible asset tagging."""

from __future__ import annotations

from typing import ClassVar

from pydantic import Field

from vd3storage.models.base import VD3Model, new_id


class Tag(VD3Model):
    """A tag applied to an asset."""

    _csv_filename: ClassVar[str] = "tags.csv"
    _primary_key: ClassVar[str] = "tag_id"

    tag_id: str = Field(default_factory=new_id)
    asset_id: str
    tag: str
