"""Build-time release configuration.

This file is modified by scripts/publish.sh before building.
Do not edit manually — changes will be overwritten during publish.
"""

TEST_RELEASE = False
