"""VD3Storage CLI."""

from vd3storage.cli.app import cli

__all__ = ["cli"]
