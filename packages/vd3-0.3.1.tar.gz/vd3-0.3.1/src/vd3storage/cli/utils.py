"""CLI utility helpers."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import typer

from vd3storage.cli.formatters import console

if TYPE_CHECKING:
    from vd3storage import VD3Storage


def open_storage(path: Path) -> VD3Storage:
    """Open a VD3Storage at the given path, with a friendly error if it's not a valid database.

    Returns a VD3Storage instance. Caller is responsible for closing it (or use as context manager).
    """
    from vd3storage import VD3Storage

    resolved = path.resolve()

    if not resolved.exists():
        console.print(f"[red]Directory not found:[/] {resolved}")
        console.print(f"\n[dim]To create a new content database, run:[/]  vd3 init {resolved}")
        raise typer.Exit(1)

    if not (resolved / "db" / "tables").exists():
        console.print(f"[red]Not a VD3 content database:[/] {resolved}")
        console.print("[dim]No 'db/tables/' directory found.[/]")
        console.print(f"\n[dim]To create a new content database here, run:[/]  vd3 init {resolved}")
        console.print("[dim]To use an existing database, run:[/]  vd3 info --path /path/to/your/database")
        raise typer.Exit(1)

    return VD3Storage(resolved)
