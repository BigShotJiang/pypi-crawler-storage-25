"""VD3Storage CLI — Typer application."""

import typer

from vd3storage.cli.commands.asset import asset_app
from vd3storage.cli.commands.datasource import datasource_app
from vd3storage.cli.commands.db import db_app
from vd3storage.cli.commands.layer import layer_app
from vd3storage.cli.commands.media import media_app
from vd3storage.cli.commands.workset import workset_app

app = typer.Typer(
    name="vd3",
    help="VD3Storage — DVC-backed media database for computer vision and ML developers",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)

app.add_typer(db_app, name="db")
app.add_typer(datasource_app, name="datasource")
app.add_typer(workset_app, name="workset")
app.add_typer(asset_app, name="asset")
app.add_typer(layer_app, name="layer")
app.add_typer(media_app, name="media")


def cli() -> None:
    from dotenv import find_dotenv, load_dotenv

    load_dotenv(find_dotenv(usecwd=True))
    app()
