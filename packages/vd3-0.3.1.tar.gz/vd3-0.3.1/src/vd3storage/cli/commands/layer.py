"""vd3 layer — manage annotation layers on an asset."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import typer

from vd3storage.cli.formatters import console

if TYPE_CHECKING:
    from vd3storage import VD3Storage
    from vd3storage.models.asset import Asset

layer_app = typer.Typer(name="layer", help="Manage annotation layers on assets", no_args_is_help=True)


def _resolve_asset(storage: VD3Storage, name_or_id: str) -> Asset:
    target = storage.get_asset_by_id(name_or_id)
    if target is not None:
        return target
    all_assets = storage.list_assets()
    matches = [a for a in all_assets if a.name == name_or_id]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        console.print(f"[red]Multiple assets named '{name_or_id}'. Use the asset ID instead.[/]")
        raise typer.Exit(1)
    console.print(f"[red]Asset '{name_or_id}' not found[/]")
    raise typer.Exit(1)


@layer_app.command("add-coco")
def layer_add_coco(
    asset: str = typer.Argument(..., help="Imageset asset name or ID"),
    layer: str = typer.Argument(..., help="Layer name (e.g. 'gt', 'det/yolo-v8')"),
    file: Path = typer.Argument(..., help="Path to the COCO JSON annotation file"),
    display_name: str = typer.Option("COCO Annotations", "--display-name", help="Human-readable layer name"),
    source: str = typer.Option("machine", "--source", help="Annotation source: 'human' or 'machine'"),
    reviewed_all: bool = typer.Option(
        False, "--reviewed-all", help="Mark every frame as reviewed (only valid with --source human)"
    ),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import COCO annotations into an existing imageset asset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = _resolve_asset(storage, asset)

        try:
            imported = storage.import_coco(
                target.asset_id,
                file,
                layer=layer,
                display_name=display_name,
                source=source,
                reviewed_all=reviewed_all,
            )
        except ValueError as e:
            console.print(f"[red]Error: {e}[/]")
            raise typer.Exit(1) from None

        frame_count = len(imported.get("frames", {}))
        total_anns = sum(len(objs) for objs in imported.get("frames", {}).values())
        console.print(
            f"[green]Imported COCO annotations:[/] {imported['layer']}: "
            f"{imported['display_name']} ({total_anns} annotations across {frame_count} frames)"
        )


@layer_app.command("add-vd3")
def layer_add_vd3(
    asset: str = typer.Argument(..., help="Asset name or ID"),
    layer: str = typer.Argument(..., help="Layer name prefix; prepended to every layer key in the file"),
    file: Path = typer.Argument(..., help="Path to the VD3 JSON result file"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import a VD3 JSON result file (detections + tracks) into an asset under a layer-name prefix."""
    from vd3storage.cli.utils import open_storage
    from vd3storage.importers.vd3json import parse_vd3_json
    from vd3storage.media.annotation_store import write_annotation_layer

    with open_storage(path) as storage:
        target = _resolve_asset(storage, asset)

        imported_layers = parse_vd3_json(file)
        if not imported_layers:
            console.print("[yellow]No layers in file[/]")
            return

        metadata_dir = storage._metadata_dir_for_asset(target)
        prefix = layer.rstrip("/")
        written: list[str] = []
        for il in imported_layers:
            new_key = f"{prefix}/{il.layer}" if prefix else il.layer
            write_annotation_layer(metadata_dir, new_key, il.display_name, il.layer_type, il.frames, source="machine")
            written.append(new_key)

        storage._update_annotation_layers_cache(target)

        console.print(f"[green]Imported {len(written)} annotation layer(s):[/]")
        for key in written:
            console.print(f"  {key}")
