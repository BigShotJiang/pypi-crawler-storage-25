"""vd3 media — manage DVC-tracked media files (pull, push, status, remote config)."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console

media_app = typer.Typer(name="media", help="Manage media files (pull, push, status, remote)", no_args_is_help=True)
remote_app = typer.Typer(name="remote", help="Configure remote storage backends", no_args_is_help=True)
media_app.add_typer(remote_app, name="remote")


@media_app.command("pull")
def pull_command(
    workset: str | None = typer.Option(None, "--workset", "-w", help="Pull assets in a workset"),
    asset: str | None = typer.Option(None, "--asset", "-a", help="Pull a specific asset (name or ID)"),
    datasource: str | None = typer.Option(None, "--datasource", "-d", help="Pull all assets in a datasource"),
    all_: bool = typer.Option(False, "--all", help="Pull all assets"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Fetch media files from remote storage."""
    from vd3storage.cli.utils import open_storage
    from vd3storage.dvc.manager import DVCNotConfiguredError

    with open_storage(path) as storage:
        try:
            if asset:
                target = storage.get_asset_by_id(asset)
                if target is None:
                    all_assets = storage.list_assets()
                    matches = [a for a in all_assets if a.name == asset]
                    if len(matches) == 1:
                        target = matches[0]
                    else:
                        console.print(f"[red]Asset '{asset}' not found[/]")
                        raise typer.Exit(1)
                storage.pull(asset_ids=[target.asset_id])
                console.print(f"[green]Pulled[/] {target.datasource}/{target.name}")
            elif workset:
                ws = storage.get_workset(workset)
                if ws is None:
                    console.print(f"[red]Workset '{workset}' not found[/]")
                    raise typer.Exit(1)
                storage.pull(workset_id=ws.workset_id)
                console.print(f"[green]Pulled assets for workset[/] [bold]{workset}[/]")
            elif datasource:
                storage.pull(datasource=datasource)
                console.print(f"[green]Pulled assets for datasource[/] [bold]{datasource}[/]")
            elif all_:
                storage.pull()
                console.print("[green]Pulled all assets[/]")
            else:
                console.print("[yellow]Specify --workset, --asset, --datasource, or --all[/]")
                raise typer.Exit(1)
        except DVCNotConfiguredError as e:
            console.print(f"[red]{e}[/]")
            raise typer.Exit(1) from None


@media_app.command("push")
def push_command(
    workset: str | None = typer.Option(None, "--workset", "-w", help="Push assets in a workset"),
    asset: str | None = typer.Option(None, "--asset", "-a", help="Push a specific asset (name or ID)"),
    datasource: str | None = typer.Option(None, "--datasource", "-d", help="Push all assets in a datasource"),
    all_: bool = typer.Option(False, "--all", help="Push all assets"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Push media files to remote storage."""
    from vd3storage.cli.utils import open_storage
    from vd3storage.dvc.manager import DVCNotConfiguredError

    with open_storage(path) as storage:
        try:
            if asset:
                target = storage.get_asset_by_id(asset)
                if target is None:
                    all_assets = storage.list_assets()
                    matches = [a for a in all_assets if a.name == asset]
                    if len(matches) == 1:
                        target = matches[0]
                    else:
                        console.print(f"[red]Asset '{asset}' not found[/]")
                        raise typer.Exit(1)
                storage.push(asset_ids=[target.asset_id])
                console.print(f"[green]Pushed[/] {target.datasource}/{target.name}")
            elif workset:
                ws = storage.get_workset(workset)
                if ws is None:
                    console.print(f"[red]Workset '{workset}' not found[/]")
                    raise typer.Exit(1)
                with console.status(f"Pushing workset '{workset}'..."):
                    storage.push(workset_id=ws.workset_id)
                console.print(f"[green]Pushed assets for workset[/] [bold]{workset}[/]")
            elif datasource:
                with console.status(f"Pushing datasource '{datasource}'..."):
                    storage.push(datasource=datasource)
                console.print(f"[green]Pushed assets for datasource[/] [bold]{datasource}[/]")
            elif all_:
                with console.status("Pushing..."):
                    storage.push()
                console.print("[green]Pushed all assets[/]")
            else:
                console.print("[yellow]Specify --workset, --asset, --datasource, or --all[/]")
                raise typer.Exit(1)
        except DVCNotConfiguredError as e:
            console.print(f"[red]{e}[/]")
            raise typer.Exit(1) from None


@media_app.command("status")
def status_command(
    list_all: bool = typer.Option(False, "--list", "-l", help="List every asset"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show which media files are locally available and synced to remote."""
    from collections import defaultdict

    from rich.table import Table

    from vd3storage.cli.utils import open_storage
    from vd3storage.dvc.manager import DVCManager

    with open_storage(path) as storage:
        assets = storage.list_assets()

        # Check cloud sync status
        mgr = DVCManager(storage.path)
        not_pushed: dict[str, str] = {}
        has_remote = mgr.has_remote()
        if has_remote:
            with console.status("Checking remote sync status..."):
                not_pushed = mgr.cloud_status()

        # Per-datasource counts
        ds_synced: dict[str, int] = defaultdict(int)
        ds_local_only: dict[str, int] = defaultdict(int)
        ds_remote_only: dict[str, int] = defaultdict(int)
        ds_no_media: dict[str, int] = defaultdict(int)

        asset_statuses: list[tuple[str, str, str]] = []
        total_synced = 0
        total_local_only = 0
        total_remote_only = 0

        for a in assets:
            local_exists = a.media_path and (storage.path / a.media_path).exists()
            has_dvc_pointer = a.media_path and (storage.path / f"{a.media_path}.dvc").exists()
            is_not_pushed = a.media_path and a.media_path in not_pushed

            if local_exists and has_remote and has_dvc_pointer and not is_not_pushed:
                ds_synced[a.datasource] += 1
                total_synced += 1
                asset_statuses.append((a.name, a.datasource, "[green]synced[/]"))
            elif local_exists and has_remote and is_not_pushed:
                ds_local_only[a.datasource] += 1
                total_local_only += 1
                asset_statuses.append((a.name, a.datasource, "[cyan]local (not pushed)[/]"))
            elif local_exists:
                ds_local_only[a.datasource] += 1
                total_local_only += 1
                label = "[cyan]local[/]" if not has_remote else "[cyan]local (untracked)[/]"
                asset_statuses.append((a.name, a.datasource, label))
            elif a.media_path:
                ds_remote_only[a.datasource] += 1
                total_remote_only += 1
                asset_statuses.append((a.name, a.datasource, "[yellow]remote-only[/]"))
            else:
                ds_no_media[a.datasource] += 1
                asset_statuses.append((a.name, a.datasource, "[dim]no media[/]"))

        # Summary line
        parts = [f"[bold]Total:[/] {len(assets)}"]
        if has_remote:
            parts.append(f"[green]Synced:[/] {total_synced}")
        if total_local_only:
            parts.append(f"[cyan]Local only:[/] {total_local_only}")
        if total_remote_only:
            parts.append(f"[yellow]Remote-only:[/] {total_remote_only}")
        console.print("  ".join(parts))

        # Per-datasource summary
        all_datasources = sorted({a.datasource for a in assets})
        if all_datasources:
            console.print()
            table = Table(title="By Datasource", show_lines=False)
            table.add_column("Datasource", style="bold")
            if has_remote:
                table.add_column("Synced", justify="right", style="green")
            table.add_column("Local only", justify="right", style="cyan")
            table.add_column("Remote-only", justify="right", style="yellow")
            table.add_column("No media", justify="right", style="dim")
            table.add_column("Total", justify="right")

            for ds in all_datasources:
                synced = ds_synced.get(ds, 0)
                local_only = ds_local_only.get(ds, 0)
                remote_only = ds_remote_only.get(ds, 0)
                no_media = ds_no_media.get(ds, 0)
                total = synced + local_only + remote_only + no_media
                row = [ds]
                if has_remote:
                    row.append(str(synced))
                row.extend([str(local_only), str(remote_only), str(no_media), str(total)])
                table.add_row(*row)

            console.print(table)

        # Per-asset listing (only with --list)
        if list_all and asset_statuses:
            console.print()
            detail = Table(title="All Assets", show_lines=False)
            detail.add_column("Name", style="bold")
            detail.add_column("Datasource", style="dim")
            detail.add_column("Status")

            for name, datasource, st in asset_statuses:
                detail.add_row(name, datasource, st)

            console.print(detail)


@remote_app.command("set")
def remote_set(
    url: str = typer.Argument(..., help="Remote URL (gs://..., s3://..., /local/path)"),
    name: str = typer.Option("storage", "--name", "-n", help="Remote name"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Set the remote storage URL. Replaces any existing remote."""
    from vd3storage.cli.utils import open_storage
    from vd3storage.dvc.manager import DVCManager

    with open_storage(path) as storage:
        mgr = DVCManager(storage.path)

        # Remove any existing remotes
        try:
            existing = mgr.list_remotes()
            for old_name in existing:
                mgr.remove_remote(old_name)
        except Exception:
            pass

        storage.add_remote(name, url, default=True)
        console.print(f"[green]Remote set:[/] [bold]{name}[/] -> {url}")


@remote_app.command("show")
def remote_show(
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show the configured remote."""
    from vd3storage.cli.utils import open_storage
    from vd3storage.dvc.manager import DVCManager

    with open_storage(path) as storage:
        mgr = DVCManager(storage.path)
        try:
            remotes = mgr.list_remotes()
        except Exception:
            console.print("[dim]No remote configured[/]")
            return

        if not remotes:
            console.print("[dim]No remote configured. Set one with:[/]  vd3 media remote set gs://bucket/path")
            return

        for name, url in remotes.items():
            console.print(f"[bold]{name}[/] -> {url}")
