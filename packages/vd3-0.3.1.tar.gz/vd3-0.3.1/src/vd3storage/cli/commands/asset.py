"""vd3 asset — operations on individual assets."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import typer

from vd3storage.cli.formatters import console, print_asset_detail, print_assets, print_layers_table

if TYPE_CHECKING:
    from vd3storage import VD3Storage
    from vd3storage.models.asset import Asset

asset_app = typer.Typer(name="asset", help="Operate on individual assets", no_args_is_help=True)


def _resolve_asset(storage: VD3Storage, name_or_id: str) -> Asset:
    """Resolve an asset by id or unique name; exit on miss/ambiguity."""
    target = storage.get_asset_by_id(name_or_id)
    if target is not None:
        return target
    all_assets = storage.list_assets()
    matches = [a for a in all_assets if a.name == name_or_id]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        console.print(f"[red]Multiple assets named '{name_or_id}'. Specify by ID:[/]")
        for m in matches:
            console.print(f"  {m.asset_id}  {m.datasource}/{m.name}")
        raise typer.Exit(1)
    console.print(f"[red]Asset '{name_or_id}' not found[/]")
    raise typer.Exit(1)


@asset_app.command("list")
def asset_list(
    paths: bool = typer.Option(False, "--paths", help="Print one media path per line (no table)"),
    filenames: bool = typer.Option(False, "--filenames", help="Print one filename per line (no table)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List every asset in the database (cross-container)."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        assets = storage.list_assets()
        if not assets:
            if not (paths or filenames):
                console.print("[dim]No assets found[/]")
            return
        print_assets(assets, paths=paths, filenames=filenames)


@asset_app.command("layers")
def asset_layers(
    name: str = typer.Argument(..., help="Asset name or ID"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List annotation layers on an asset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = _resolve_asset(storage, name)
        layers = storage.list_annotation_layers(target.asset_id)
        if not layers:
            console.print("[dim]No annotation layers[/]")
            return
        print_layers_table(layers)


@asset_app.command("show")
def asset_show(
    name: str = typer.Argument(..., help="Asset name or ID"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show detailed information about an asset."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = _resolve_asset(storage, name)
        layers = storage.list_annotation_layers(target.asset_id)
        print_asset_detail(target, layers)

        if target.media_path:
            available = storage.is_media_available(target.asset_id)
            if available:
                console.print("[green]Media: locally available[/]")
            else:
                console.print("[yellow]Media: not fetched (run 'vd3 media pull' to download)[/]")


@asset_app.command("remove")
def asset_remove(
    name: str = typer.Argument(..., help="Asset name or ID"),
    media: bool = typer.Option(False, "--media", help="Also delete the media file"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Delete an asset from the content database."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = _resolve_asset(storage, name)
        storage.delete_asset(target.asset_id, delete_media=media)
        console.print(f"[green]Deleted asset[/] [bold]{target.datasource}/{target.name}[/]")
        if media:
            console.print("[dim]Media file also deleted[/]")


@asset_app.command("export-frames")
def asset_export_frames(
    name: str = typer.Argument(..., help="Asset name or ID"),
    output: Path = typer.Option(..., "--output", "-o", help="Output directory"),
    format: str = typer.Option("jpeg", "--format", "-f", help="Image format (jpeg or png)"),
    start: int = typer.Option(0, "--start", help="Start frame/image number"),
    end: int | None = typer.Option(None, "--end", help="End frame/image number (exclusive)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Extract frames from a video or images from an imageset to image files."""
    import io

    from PIL import Image

    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        target = _resolve_asset(storage, name)

        output.mkdir(parents=True, exist_ok=True)
        ext = "jpg" if format.lower() == "jpeg" else format.lower()

        reader = (
            storage.open_imageset(target.asset_id)
            if target.asset_type == "imageset"
            else storage.open_video(target.asset_id)
        )
        with reader:
            count = 0
            for frame_num, frame_bytes in reader.iter_frames(start=start, end=end):
                img = Image.open(io.BytesIO(frame_bytes))
                out_path = output / f"{frame_num:06d}.{ext}"
                img.save(out_path)
                count += 1

            console.print(f"[green]Exported {count} frames to[/] {output}")
