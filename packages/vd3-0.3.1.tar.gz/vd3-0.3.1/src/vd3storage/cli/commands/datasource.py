"""vd3 datasource — manage datasources and their contained assets."""

from __future__ import annotations

import glob as globmod
import hashlib
from pathlib import Path
from typing import TYPE_CHECKING

import typer

from vd3storage.cli.formatters import console, print_asset_detail, print_assets, print_container_layers_table

if TYPE_CHECKING:
    from vd3storage import VD3Storage
    from vd3storage.models.asset import Asset

datasource_app = typer.Typer(
    name="datasource",
    help="Manage datasources and ingest assets into them",
    no_args_is_help=True,
)


def _resolve_video_paths(patterns: list[str]) -> list[Path]:
    paths: dict[Path, None] = {}
    for pattern in patterns:
        matches = sorted(globmod.glob(pattern, recursive=True))
        if not matches:
            console.print(f"[yellow]Warning: no files matched '{pattern}'[/]")
        for m in matches:
            p = Path(m)
            if p.is_file():
                paths[p] = None
    return list(paths)


def _find_existing_asset(storage: VD3Storage, video_path: Path) -> Asset | None:
    sha256 = hashlib.sha256()
    with open(video_path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            sha256.update(chunk)
    return storage.get_asset_by_hash(sha256.hexdigest())


@datasource_app.command("list")
def datasource_list(
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List all datasources in the content database."""
    from rich.table import Table

    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        rows = storage.list_datasources()
        if not rows:
            console.print("[dim]No datasources found[/]")
            return

        table = Table(title="Datasources")
        table.add_column("Datasource", style="bold")
        table.add_column("Description")
        table.add_column("Assets", justify="right")

        for row in rows:
            table.add_row(row["name"], row["description"] or "[dim]—[/]", str(row["asset_count"]))

        console.print(table)


@datasource_app.command("show")
def datasource_show(
    name: str = typer.Argument(..., help="Datasource name"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show datasource details and stats."""
    from rich.panel import Panel

    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        assets = storage.list_assets(datasource=name)
        description = storage.get_datasource_description(name)
        if not assets and not description:
            console.print(f"[red]Datasource '{name}' not found (no assets, no description)[/]")
            raise typer.Exit(1)

        videos = [a for a in assets if a.asset_type == "video"]
        imagesets = [a for a in assets if a.asset_type == "imageset"]

        lines = [
            f"[bold]Name:[/] {name}",
            f"[bold]Description:[/] {description or '[dim]—[/]'}",
            f"[bold]Assets:[/] {len(assets):,}",
            f"[bold]Videos:[/] {len(videos):,}",
            f"[bold]Imagesets:[/] {len(imagesets):,}",
        ]
        console.print(Panel("\n".join(lines), title=f"Datasource: {name}", border_style="cyan"))


@datasource_app.command("set-description")
def datasource_set_description(
    name: str = typer.Argument(..., help="Datasource name"),
    description: str = typer.Argument(..., help="Description text"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Set or update the description for a datasource."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        storage.set_datasource_description(name, description)
        console.print(f"[green]Set description for[/] [bold]{name}[/]")


@datasource_app.command("layers")
def datasource_layers(
    name: str = typer.Argument(..., help="Datasource name"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List annotation layers across all assets in a datasource."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        rows = storage.list_datasource_layers(name)
        if not rows:
            console.print("[dim]No annotation layers in this datasource[/]")
            return
        total = len(storage.list_assets(datasource=name))
        print_container_layers_table(rows, total, title=f"Layers in datasource {name}")


@datasource_app.command("assets")
def datasource_assets(
    name: str = typer.Argument(..., help="Datasource name"),
    paths: bool = typer.Option(False, "--paths", help="Print one media path per line (no table)"),
    filenames: bool = typer.Option(False, "--filenames", help="Print one filename per line (no table)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """List assets in a datasource."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        assets = storage.list_assets(datasource=name)
        if not assets:
            if not (paths or filenames):
                console.print("[dim]No assets found[/]")
            return
        print_assets(assets, paths=paths, filenames=filenames, show_datasource=False)


@datasource_app.command("add-video")
def datasource_add_video(
    datasource: str = typer.Argument(..., help="Datasource name"),
    files: list[str] = typer.Argument(..., help="Video file paths or glob patterns"),
    name: str | None = typer.Option(None, "--name", "-n", help="Asset name (defaults to filename, single file only)"),
    workset: str | None = typer.Option(None, "--workset", "-w", help="Add to workset (slug)"),
    package: str = typer.Option("", "--package", "-k", help="Package within workset"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite if duplicate video exists"),
    sensor_type: str = typer.Option("unknown", "--sensor-type", help="Sensor type"),
    environment: str = typer.Option("unknown", "--environment", help="Environment"),
    spectrum: str = typer.Option("unknown", "--spectrum", help="Sensor spectrum (visible, infrared, unknown)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import video files into the datasource. Supports glob patterns."""
    from rich.progress import Progress

    from vd3storage.cli.utils import open_storage

    video_paths = _resolve_video_paths(files)
    if not video_paths:
        console.print("[red]No video files found[/]")
        raise typer.Exit(1)

    if name and len(video_paths) > 1:
        console.print("[red]--name can only be used with a single file[/]")
        raise typer.Exit(1)

    with open_storage(path) as storage:
        ws = None
        if workset:
            ws = storage.get_workset(workset)
            if ws is None:
                console.print(f"[red]Workset '{workset}' not found[/]")
                console.print(f'[dim]Hint: create it first with:[/] vd3 workset create "{workset}"')
                raise typer.Exit(1)

        succeeded = 0
        linked = 0
        failed = 0
        with Progress(console=console) as progress:
            task = progress.add_task("Importing videos...", total=len(video_paths))

            for video_path in video_paths:
                progress.update(task, description=f"Importing {video_path.name}...")
                try:
                    asset = storage.import_video(
                        video_path,
                        datasource=datasource,
                        name=name,
                        force=force,
                        sensor_type=sensor_type,
                        environment=environment,
                        spectrum=spectrum,
                    )
                except FileNotFoundError as e:
                    console.print(f"[red]Skipping {video_path.name}: {e}[/]")
                    failed += 1
                    progress.advance(task)
                    continue
                except ValueError:
                    if ws:
                        existing = _find_existing_asset(storage, video_path)
                        if existing:
                            storage.add_asset_to_workset(ws.workset_id, existing.asset_id, package=package)
                            console.print(
                                f"[dim]Linked existing[/] [bold]{existing.datasource}/{existing.name}[/]"
                                f" [dim]to workset[/] [bold]{workset}[/]"
                            )
                            linked += 1
                            progress.advance(task)
                            continue
                    console.print(f"[dim]Skipping {video_path.name}: already imported[/]")
                    progress.advance(task)
                    continue

                if ws:
                    storage.add_asset_to_workset(ws.workset_id, asset.asset_id, package=package)

                succeeded += 1
                progress.advance(task)

                if len(video_paths) == 1:
                    layers = storage.list_annotation_layers(asset.asset_id)
                    print_asset_detail(asset, layers)

        if len(video_paths) == 1 and succeeded:
            console.print(f"\n[green]Imported {video_paths[0].name}[/]")
        else:
            parts = [f"[green]{succeeded} imported[/]"]
            if linked:
                parts.append(f"[blue]{linked} linked to workset[/]")
            if failed:
                parts.append(f"[red]{failed} failed[/]")
            console.print(f"\nDone: {', '.join(parts)} (of {len(video_paths)} files)")


@datasource_app.command("add-imageset")
def datasource_add_imageset(
    datasource: str = typer.Argument(..., help="Datasource name"),
    source: Path = typer.Argument(..., help="Directory of images or .tar archive"),
    name: str | None = typer.Option(None, "--name", "-n", help="Asset name (defaults to directory/archive name)"),
    workset: str | None = typer.Option(None, "--workset", "-w", help="Add to workset (slug)"),
    package: str = typer.Option("", "--package", "-k", help="Package within workset"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite if duplicate exists"),
    sensor_type: str = typer.Option("unknown", "--sensor-type", help="Sensor type"),
    environment: str = typer.Option("unknown", "--environment", help="Environment"),
    spectrum: str = typer.Option("unknown", "--spectrum", help="Sensor spectrum (visible, infrared, unknown)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import an imageset (directory of images or .tar archive) into the datasource."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = None
        if workset:
            ws = storage.get_workset(workset)
            if ws is None:
                console.print(f"[red]Workset '{workset}' not found[/]")
                console.print(f'[dim]Hint: create it first with:[/] vd3 workset create "{workset}"')
                raise typer.Exit(1)

        try:
            asset = storage.import_imageset(
                source,
                datasource=datasource,
                name=name,
                force=force,
                sensor_type=sensor_type,
                environment=environment,
                spectrum=spectrum,
            )
        except (ValueError, FileNotFoundError) as e:
            console.print(f"[red]Error: {e}[/]")
            raise typer.Exit(1) from None

        if ws:
            storage.add_asset_to_workset(ws.workset_id, asset.asset_id, package=package)

        layers = storage.list_annotation_layers(asset.asset_id)
        print_asset_detail(asset, layers)
        console.print(f"\n[green]Imported imageset with {asset.frame_count} images[/]")


@datasource_app.command("add-imageset-from-coco")
def datasource_add_imageset_from_coco(
    datasource: str = typer.Argument(..., help="Datasource name"),
    layer: str = typer.Argument(..., help="Layer name for the imported annotations (e.g. 'gt')"),
    file: Path = typer.Argument(..., help="Path to COCO JSON file (images resolved relative to its directory)"),
    image_root: Path | None = typer.Option(None, "--image-root", help="Base dir for image paths (default: JSON dir)"),
    name: str | None = typer.Option(None, "--name", "-n", help="Asset name (defaults to parent directory name)"),
    display_name: str = typer.Option("COCO Annotations", "--display-name", help="Human-readable layer name"),
    source: str = typer.Option("machine", "--source", help="Annotation source: 'human' or 'machine'"),
    reviewed_all: bool = typer.Option(
        False, "--reviewed-all", help="Mark every frame as reviewed (only valid with --source human)"
    ),
    workset: str | None = typer.Option(None, "--workset", "-w", help="Add to workset (slug)"),
    package: str = typer.Option("", "--package", "-k", help="Package within workset"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite if duplicate exists"),
    sensor_type: str = typer.Option("unknown", "--sensor-type", help="Sensor type"),
    environment: str = typer.Option("unknown", "--environment", help="Environment"),
    spectrum: str = typer.Option("unknown", "--spectrum", help="Sensor spectrum (visible, infrared, unknown)"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Import a COCO dataset as a new imageset plus annotation layer."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        ws = None
        if workset:
            ws = storage.get_workset(workset)
            if ws is None:
                console.print(f"[red]Workset '{workset}' not found[/]")
                console.print(f'[dim]Hint: create it first with:[/] vd3 workset create "{workset}"')
                raise typer.Exit(1)

        try:
            asset, ann_result = storage.import_coco_dataset(
                file,
                datasource=datasource,
                name=name,
                image_root=image_root,
                layer=layer,
                display_name=display_name,
                source=source,
                reviewed_all=reviewed_all,
                force=force,
                sensor_type=sensor_type,
                environment=environment,
                spectrum=spectrum,
            )
        except (ValueError, FileNotFoundError) as e:
            console.print(f"[red]Error: {e}[/]")
            raise typer.Exit(1) from None

        if ws:
            storage.add_asset_to_workset(ws.workset_id, asset.asset_id, package=package)

        layers = storage.list_annotation_layers(asset.asset_id)
        print_asset_detail(asset, layers)

        total_anns = sum(len(objs) for objs in ann_result.get("frames", {}).values())
        console.print(
            f"\n[green]Imported COCO dataset:[/] {asset.frame_count} images + "
            f"{total_anns} annotations ({ann_result['layer']})"
        )
