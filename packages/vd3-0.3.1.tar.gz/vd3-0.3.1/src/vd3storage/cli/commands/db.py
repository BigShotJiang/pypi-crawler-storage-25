"""vd3 db — administrative database commands (init, info, query)."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console, print_info_panel

db_app = typer.Typer(name="db", help="Initialize and inspect the content database", no_args_is_help=True)


@db_app.command("init")
def db_init(
    path: Path = typer.Argument(".", help="Path to create the content database (default: current directory)"),
    dev: bool = typer.Option(False, "--dev", help="Add local vd3storage source override for development"),
    no_git: bool = typer.Option(False, "--no-git", help="Skip git initialization"),
    no_dvc: bool = typer.Option(False, "--no-dvc", help="Skip DVC initialization"),
    force: bool = typer.Option(
        False, "--force", "-f", help="Reinitialize even if already initialized (destroys existing data)"
    ),
) -> None:
    """Initialize a new VD3 content database."""
    from vd3storage import VD3Storage
    from vd3storage.storage import AlreadyInitializedError

    try:
        storage = VD3Storage.init(path, git_init=not no_git, dvc_init=not no_dvc, dev=dev, force=force)
    except AlreadyInitializedError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1) from None

    console.print(f"[green]Created content database at[/] [bold]{storage.path}[/]")
    storage._engine.close()


@db_app.command("info")
def db_info(
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Show content database information."""
    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        print_info_panel(storage)


@db_app.command("query")
def db_query(
    sql: str = typer.Argument(..., help="SQL query to execute"),
    path: Path = typer.Option(".", "--path", "-p", envvar="VD3_DB", help="Path to the content database"),
) -> None:
    """Run a raw DuckDB SQL query against the CSV tables."""
    from rich.table import Table

    from vd3storage.cli.utils import open_storage

    with open_storage(path) as storage:
        try:
            rows = storage.execute_sql(sql)
        except Exception as e:
            console.print(f"[red]Query error:[/] {e}")
            raise typer.Exit(1) from None

        if not rows:
            console.print("[dim]No results[/]")
            return

        table = Table(show_lines=False)
        for col in rows[0]:
            table.add_column(col)

        for row in rows:
            table.add_row(*[str(v) for v in row.values()])

        console.print(table)
