"""DVC manager — wraps DVC CLI operations for managing large files.

Users interact with vd3 pull/push/status — never with DVC directly.
This module is an internal implementation detail.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


class DVCNotConfiguredError(RuntimeError):
    """Raised when DVC is not initialized or has no remote configured."""


class DVCManager:
    """Wraps DVC CLI operations for managing large files."""

    def __init__(self, repo_path: Path) -> None:
        self._repo_path = repo_path

    def init(self) -> None:
        """Initialize DVC in the repo (`dvc init`)."""
        self._run(["dvc", "init"])
        logger.info("Initialized DVC in %s", self._repo_path)

    def add(self, paths: Path | list[Path]) -> None:
        """Track file(s) with DVC (`dvc add <path> ...`).

        Creates .dvc pointer files and updates .gitignore.
        Accepts a single path or a list of paths (batched into one dvc call).
        """
        if isinstance(paths, Path):
            paths = [paths]
        if not paths:
            return
        rel_paths = [str(p.relative_to(self._repo_path) if p.is_absolute() else p) for p in paths]
        self._run(["dvc", "add", *rel_paths])
        logger.debug("DVC tracked %d files", len(rel_paths))

    def push(self, paths: list[Path] | None = None) -> None:
        """Push tracked files to DVC remote.

        Args:
            paths: If provided, push only these specific .dvc files.
                   If None, pushes all tracked files.
        """
        self._require_remote()
        cmd = ["dvc", "push"]
        if paths:
            for p in paths:
                rel = p.relative_to(self._repo_path) if p.is_absolute() else p
                cmd.append(str(rel))
        self._run(cmd)
        logger.info("DVC push complete")

    def pull(self, paths: list[Path] | None = None) -> None:
        """Pull tracked files from DVC remote.

        Args:
            paths: If provided, pull only these specific .dvc files.
                   If None, pulls all tracked files.
        """
        self._require_remote()
        cmd = ["dvc", "pull"]
        if paths:
            for p in paths:
                rel = p.relative_to(self._repo_path) if p.is_absolute() else p
                cmd.append(str(rel))
        self._run(cmd)
        logger.info("DVC pull complete")

    def is_available(self, file_path: Path) -> bool:
        """Check if a DVC-tracked file is locally available (not just the .dvc pointer).

        Returns True if the actual file exists on disk (not a symlink to missing content).
        """
        full_path = file_path if file_path.is_absolute() else self._repo_path / file_path

        # The file must exist and either be a regular file or a valid symlink
        if not full_path.exists():
            return False
        if full_path.is_symlink():
            # DVC uses symlinks by default — check the target exists
            return full_path.resolve().exists()
        return True

    def status(self) -> dict:
        """Show DVC status.

        Returns a dict with status information parsed from `dvc status`.
        """
        result = self._run(["dvc", "status"], check=False)
        return {"stdout": result.stdout, "returncode": result.returncode}

    def cloud_status(self) -> dict[str, str]:
        """Check which .dvc-tracked files are pushed to the remote.

        Returns a dict of {dvc_file: status} where status is "ok", "new", "deleted", etc.
        Files not in the returned dict are up to date on the remote.
        """
        if not self.has_remote():
            return {}
        result = self._run(["dvc", "status", "--cloud", "--json"], check=False)
        if result.returncode != 0 or not result.stdout.strip():
            return {}
        import json

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            logger.warning("Failed to parse dvc status --cloud output")
            return {}

        # Output format: {"file.dvc": [{"changed outs": {"file": "new"}}], ...}
        not_pushed: dict[str, str] = {}
        for _dvc_file, changes in data.items():
            for change in changes:
                if "changed outs" in change:
                    for out_path, status in change["changed outs"].items():
                        not_pushed[out_path] = status
        return not_pushed

    def add_remote(self, name: str, url: str, default: bool = True) -> None:
        """Add a DVC remote storage backend.

        Args:
            name: Remote name (e.g., "myremote").
            url: Remote URL (e.g., "s3://bucket/path", "/local/path").
            default: If True, set as the default remote.
        """
        cmd = ["dvc", "remote", "add"]
        if default:
            cmd.append("--default")
        cmd.extend([name, url])
        self._run(cmd)
        logger.info("Added DVC remote '%s' -> %s", name, url)

    def remove_remote(self, name: str) -> None:
        """Remove a DVC remote."""
        self._run(["dvc", "remote", "remove", name])
        logger.info("Removed DVC remote '%s'", name)

    def list_remotes(self) -> dict[str, str]:
        """List configured DVC remotes.

        Returns a dict of {name: url}.
        """
        result = self._run(["dvc", "remote", "list"], check=False)
        remotes: dict[str, str] = {}
        for line in result.stdout.strip().splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                remotes[parts[0]] = parts[1]
        return remotes

    def is_initialized(self) -> bool:
        """Check if DVC is initialized in the repo."""
        return (self._repo_path / ".dvc").is_dir()

    def has_remote(self) -> bool:
        """Check if at least one DVC remote is configured."""
        if not self.is_initialized():
            return False
        try:
            remotes = self.list_remotes()
            return len(remotes) > 0
        except Exception:
            return False

    def _require_remote(self) -> None:
        """Raise a clear error if DVC is not ready for push/pull."""
        if not self.is_initialized():
            raise DVCNotConfiguredError(
                "DVC is not initialized in this database. "
                "Run 'dvc init' inside the database directory, or use:\n"
                "  vd3 remote add myremote s3://YOUR_BUCKET_NAME/mydb-media/"
            )
        if not self.has_remote():
            raise DVCNotConfiguredError(
                "No DVC remote configured. Add one with:\n  vd3 remote add myremote s3://YOUR_BUCKET_NAME/mydb-media/"
            )

    def _run(self, cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
        """Run a DVC command."""
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, cwd=self._repo_path, capture_output=True, text=True)
        if check and result.returncode != 0:
            stderr = result.stderr.strip()
            raise RuntimeError(f"DVC command failed: {' '.join(cmd)}\n{stderr}")
        return result
