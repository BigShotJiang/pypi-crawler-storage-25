"""Imageset metadata — scan, read, and write imageset.json files."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import orjson
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# Image file extensions to scan for
IMAGE_EXTENSIONS = frozenset({".jpg", ".jpeg", ".png", ".webp", ".tiff", ".tif", ".bmp"})


class ImageInfo(BaseModel):
    """Metadata for a single image within an imageset."""

    filename: str
    width: int
    height: int
    extra: dict[str, Any] = {}


class ImagesetMetadata(BaseModel):
    """Metadata for an imageset, stored as imageset.json."""

    image_count: int
    images: list[ImageInfo]
    extra: dict[str, Any] = {}


def scan_imageset(directory: Path) -> ImagesetMetadata:
    """Scan a directory for image files and probe each for dimensions.

    Images are sorted alphabetically by filename. Only files with recognized
    image extensions are included.

    Args:
        directory: Path to directory containing image files.

    Returns:
        ImagesetMetadata with image list and dimensions.

    Raises:
        FileNotFoundError: If directory does not exist.
        ValueError: If no image files found.
    """
    from PIL import Image

    if not directory.exists():
        raise FileNotFoundError(f"Image directory not found: {directory}")
    if not directory.is_dir():
        raise ValueError(f"Not a directory: {directory}")

    # Recursively find all image files, sorted by relative path to preserve directory layout
    image_files: list[Path] = sorted(
        f for f in directory.rglob("*") if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS
    )

    if not image_files:
        raise ValueError(f"No image files found in {directory}")

    images: list[ImageInfo] = []
    for img_path in image_files:
        with Image.open(img_path) as img:
            w, h = img.size
        # Store path relative to the imageset root (preserves subdirectory structure)
        rel_path = str(img_path.relative_to(directory))
        images.append(ImageInfo(filename=rel_path, width=w, height=h))

    logger.info("Scanned %d images from %s", len(images), directory)

    return ImagesetMetadata(image_count=len(images), images=images)


def read_imageset_metadata(json_path: Path) -> ImagesetMetadata:
    """Read an imageset.json metadata file.

    Args:
        json_path: Path to the imageset.json file.

    Returns:
        ImagesetMetadata parsed from the file.

    Raises:
        FileNotFoundError: If the file does not exist.
    """
    if not json_path.exists():
        raise FileNotFoundError(f"Imageset metadata not found: {json_path}")
    data = orjson.loads(json_path.read_bytes())
    return ImagesetMetadata(**data)


def write_imageset_metadata(json_path: Path, metadata: ImagesetMetadata) -> None:
    """Write an ImagesetMetadata to an imageset.json file.

    Args:
        json_path: Where to write the file.
        metadata: The metadata to write.
    """
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_bytes(orjson.dumps(metadata.model_dump(), option=orjson.OPT_INDENT_2))
    logger.debug("Wrote imageset metadata to %s", json_path)
