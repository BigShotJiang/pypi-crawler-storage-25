"""Video metadata — probe, read, and write video.json files."""

from __future__ import annotations

import logging
from pathlib import Path

import orjson
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class VideoMetadata(BaseModel):
    """Metadata extracted from a video file, stored as video.json."""

    width: int
    height: int
    fps: float
    frame_count: int
    duration_ms: int
    codec: str = ""
    source_filename: str = ""
    source_hash: str = ""


def probe_video(video_path: Path) -> VideoMetadata:
    """Extract metadata from a video file using ffmpeg.probe().

    Args:
        video_path: Path to the video file.

    Returns:
        VideoMetadata with dimensions, fps, frame count, duration, codec.

    Raises:
        RuntimeError: If ffmpeg cannot probe the file.
    """
    import ffmpeg

    probe = ffmpeg.probe(str(video_path))
    video_stream = next(s for s in probe["streams"] if s["codec_type"] == "video")

    width = int(video_stream["width"])
    height = int(video_stream["height"])

    # Parse fps from r_frame_rate (e.g., "30/1" or "30000/1001")
    fps_parts = video_stream.get("r_frame_rate", "30/1").split("/")
    fps = float(fps_parts[0]) / float(fps_parts[1]) if len(fps_parts) == 2 else float(fps_parts[0])

    duration_s = float(probe["format"].get("duration", "0"))
    duration_ms = int(duration_s * 1000)

    # Frame count: try nb_frames, fall back to duration * fps
    nb_frames = video_stream.get("nb_frames")
    if nb_frames is not None and nb_frames != "N/A":
        frame_count = int(nb_frames)
    else:
        frame_count = int(duration_s * fps) if fps > 0 else 0

    codec = video_stream.get("codec_name", "")

    logger.info(
        "Probed %s: %dx%d @ %.2f fps, %d frames, %.1fs, codec=%s",
        video_path.name,
        width,
        height,
        fps,
        frame_count,
        duration_s,
        codec,
    )

    return VideoMetadata(
        width=width,
        height=height,
        fps=fps,
        frame_count=frame_count,
        duration_ms=duration_ms,
        codec=codec,
        source_filename=video_path.name,
    )


def read_video_metadata(json_path: Path) -> VideoMetadata:
    """Read a video.json metadata file.

    Args:
        json_path: Path to the video.json file.

    Returns:
        VideoMetadata parsed from the file.

    Raises:
        FileNotFoundError: If the file does not exist.
    """
    if not json_path.exists():
        raise FileNotFoundError(f"Video metadata not found: {json_path}")
    data = orjson.loads(json_path.read_bytes())
    return VideoMetadata(**data)


def write_video_metadata(json_path: Path, metadata: VideoMetadata) -> None:
    """Write a VideoMetadata to a video.json file.

    Args:
        json_path: Where to write the file.
        metadata: The metadata to write.
    """
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_bytes(orjson.dumps(metadata.model_dump(), option=orjson.OPT_INDENT_2))
    logger.debug("Wrote video metadata to %s", json_path)
