"""Imageset reader — image access from an imageset directory."""

from __future__ import annotations

import logging
from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING

from PIL import Image

if TYPE_CHECKING:
    from vd3storage.media.imageset_metadata import ImageInfo, ImagesetMetadata

logger = logging.getLogger(__name__)


class ImagesetReader:
    """Read images from an imageset directory.

    Provides indexed access to individual images within the set.
    """

    def __init__(self, media_dir: Path, metadata: ImagesetMetadata) -> None:
        """Open an imageset for reading.

        Args:
            media_dir: Path to the directory containing image files.
            metadata: Pre-loaded imageset metadata (image list with dimensions).
        """
        self._media_dir = media_dir
        self._metadata = metadata

        if not media_dir.exists():
            raise FileNotFoundError(f"Imageset directory not found: {media_dir}")
        if not media_dir.is_dir():
            raise ValueError(f"Imageset media path is not a directory: {media_dir}")

    @property
    def frame_count(self) -> int:
        return self._metadata.image_count

    @property
    def image_count(self) -> int:
        return self._metadata.image_count

    def get_image_info(self, frame_number: int) -> ImageInfo:
        """Get metadata for the image at the given index."""
        if frame_number < 0 or frame_number >= self._metadata.image_count:
            raise ValueError(f"Frame {frame_number} out of range [0, {self._metadata.image_count})")
        return self._metadata.images[frame_number]

    def get_frame(self, frame_number: int) -> bytes:
        """Read raw bytes of the image at the given index."""
        info = self.get_image_info(frame_number)
        img_path = self._media_dir / info.filename
        if not img_path.exists():
            raise FileNotFoundError(f"Image file not found: {img_path}")
        return img_path.read_bytes()

    def get_frame_image(self, frame_number: int) -> Image.Image:
        """Read the image at the given index as a PIL Image."""
        info = self.get_image_info(frame_number)
        img_path = self._media_dir / info.filename
        if not img_path.exists():
            raise FileNotFoundError(f"Image file not found: {img_path}")
        return Image.open(img_path).copy()

    def iter_frames(self, start: int = 0, end: int | None = None) -> Iterator[tuple[int, bytes]]:
        """Iterate over images as (index, raw_bytes) tuples."""
        if end is None:
            end = self._metadata.image_count
        for i in range(start, min(end, self._metadata.image_count)):
            yield i, self.get_frame(i)

    def close(self) -> None:
        """Close the reader (no-op, exists for API compatibility)."""

    def __enter__(self) -> ImagesetReader:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"ImagesetReader({self._media_dir.name}, {self._metadata.image_count} images)"
