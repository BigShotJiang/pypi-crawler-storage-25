"""Schema constants for VD3Storage media and metadata files."""

# Filename for per-video metadata JSON
VIDEO_METADATA_FILENAME = "video.json"

# Directory name for annotation layer JSON files
ANNOTATIONS_DIR = "annotations"
