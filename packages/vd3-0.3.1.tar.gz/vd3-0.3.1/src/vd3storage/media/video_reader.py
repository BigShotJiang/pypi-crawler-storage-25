"""Video reader — frame extraction from MP4 files via ffmpeg."""

from __future__ import annotations

import io
import logging
from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING

import ffmpeg
from PIL import Image

if TYPE_CHECKING:
    from vd3storage.media.video_metadata import VideoMetadata

logger = logging.getLogger(__name__)


class VideoReader:
    """Read video frames from an MP4 file using ffmpeg.

    Provides random-access frame extraction and sequential iteration.
    """

    def __init__(self, video_path: Path, metadata: VideoMetadata) -> None:
        """Open a video file for reading.

        Args:
            video_path: Path to the .mp4 file.
            metadata: Pre-loaded video metadata (fps, dimensions, frame count).
        """
        self._video_path = video_path
        self._metadata = metadata

        if not video_path.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")

    @property
    def frame_count(self) -> int:
        return self._metadata.frame_count

    @property
    def fps(self) -> float:
        return self._metadata.fps

    @property
    def width(self) -> int:
        return self._metadata.width

    @property
    def height(self) -> int:
        return self._metadata.height

    def get_frame(self, frame_number: int) -> bytes:
        """Extract a single frame as JPEG bytes.

        Uses ffmpeg to seek to the frame by timestamp and extract one frame.

        Args:
            frame_number: 0-based frame index.

        Returns:
            JPEG-encoded bytes of the frame.

        Raises:
            ValueError: If frame_number is out of range.
            RuntimeError: If ffmpeg fails to extract the frame.
        """
        if frame_number < 0 or frame_number >= self._metadata.frame_count:
            raise ValueError(f"Frame {frame_number} out of range [0, {self._metadata.frame_count})")

        timestamp = frame_number / self._metadata.fps if self._metadata.fps > 0 else 0

        try:
            out, _ = (
                ffmpeg.input(str(self._video_path), ss=timestamp)
                .output("pipe:", vframes=1, format="image2", vcodec="mjpeg", loglevel="error")
                .run(capture_stdout=True, capture_stderr=True)
            )
        except ffmpeg.Error as e:
            stderr = e.stderr.decode("utf-8", errors="replace") if e.stderr else "unknown error"
            raise RuntimeError(f"ffmpeg failed extracting frame {frame_number}: {stderr[:500]}") from e

        if not out:
            raise RuntimeError(f"ffmpeg returned empty output for frame {frame_number}")

        return out

    def get_frame_image(self, frame_number: int) -> Image.Image:
        """Extract a single frame as a PIL Image.

        Args:
            frame_number: 0-based frame index.

        Returns:
            PIL Image of the frame.
        """
        jpeg_bytes = self.get_frame(frame_number)
        return Image.open(io.BytesIO(jpeg_bytes))

    def iter_frames(self, start: int = 0, end: int | None = None) -> Iterator[tuple[int, bytes]]:
        """Iterate over frames as (frame_number, jpeg_bytes) tuples.

        Uses ffmpeg pipe for efficient sequential extraction.

        Args:
            start: First frame to extract (0-based).
            end: Exclusive end frame. None means all remaining frames.

        Yields:
            (frame_number, jpeg_bytes) for each frame in the range.
        """
        if end is None:
            end = self._metadata.frame_count

        start_time = start / self._metadata.fps if self._metadata.fps > 0 else 0
        num_frames = end - start

        if num_frames <= 0:
            return

        process = (
            ffmpeg.input(str(self._video_path), ss=start_time)
            .output("pipe:", format="image2pipe", vcodec="mjpeg", vframes=num_frames, loglevel="error")
            .run_async(pipe_stdout=True, pipe_stderr=True)
        )

        try:
            frame_idx = start
            for jpeg_bytes in _iter_jpeg_frames(process.stdout):
                yield frame_idx, jpeg_bytes
                frame_idx += 1
        finally:
            process.wait()

    def close(self) -> None:
        """Close the reader (no-op for file-based reader, exists for API compat)."""

    def __enter__(self) -> VideoReader:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"VideoReader({self._video_path.name}, {self._metadata.frame_count} frames)"


def _iter_jpeg_frames(pipe: io.BufferedReader) -> Iterator[bytes]:
    """Read JPEG frames from an mjpeg pipe stream.

    JPEG files start with 0xFFD8 and end with 0xFFD9.
    Yields complete JPEG frames as they are extracted.
    """
    buffer = bytearray()

    while True:
        chunk = pipe.read(65536)
        if not chunk:
            break
        buffer.extend(chunk)

        # Extract complete JPEG frames
        while True:
            # Find JPEG start marker
            start = buffer.find(b"\xff\xd8")
            if start == -1:
                buffer = buffer[-1:]  # Keep last byte in case it's 0xFF
                break

            # Find JPEG end marker after start
            end = buffer.find(b"\xff\xd9", start + 2)
            if end == -1:
                # Incomplete frame — wait for more data
                if start > 0:
                    buffer = buffer[start:]
                break

            # Extract complete JPEG frame (including end marker)
            frame = bytes(buffer[start : end + 2])
            yield frame
            buffer = buffer[end + 2 :]

    # Handle any remaining data as a final frame
    if len(buffer) > 2:
        start = buffer.find(b"\xff\xd8")
        if start != -1:
            yield bytes(buffer[start:])
