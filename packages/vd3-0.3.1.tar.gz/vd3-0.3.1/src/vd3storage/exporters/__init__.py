"""Exporters — convert VD3 annotation layers to external formats."""
