"""COCO annotation format importer — reads COCO JSON files into annotation layer data.

Supports standard COCO detection format:
{
    "images": [{"id": 1, "file_name": "img_001.jpg", "width": 640, "height": 480}, ...],
    "annotations": [{"id": 1, "image_id": 1, "category_id": 1, "bbox": [x, y, w, h], ...}, ...],
    "categories": [{"id": 1, "name": "person"}, ...]
}

Image matching: COCO image file_names are matched to imageset frame indices by:
1. Exact relative path match against imageset.json filenames
2. Fallback to basename-only match if unique within the imageset
"""

from __future__ import annotations

import logging
from collections import defaultdict
from pathlib import Path, PurePosixPath
from typing import Any

import orjson

from vd3storage.importers.vd3json import ImportedLayer
from vd3storage.media.imageset_metadata import ImagesetMetadata

logger = logging.getLogger(__name__)


def _build_filename_index(metadata: ImagesetMetadata) -> tuple[dict[str, int], dict[str, list[int]]]:
    """Build lookup tables from imageset metadata for matching COCO images.

    Returns:
        (full_path_index, basename_index):
        - full_path_index: maps normalized relative path -> frame index
        - basename_index: maps basename -> list of frame indices (for fallback matching)
    """
    full_path_index: dict[str, int] = {}
    basename_index: dict[str, list[int]] = defaultdict(list)

    for i, img in enumerate(metadata.images):
        # Normalize path separators for cross-platform matching
        normalized = str(PurePosixPath(img.filename))
        full_path_index[normalized] = i
        basename = PurePosixPath(img.filename).name
        basename_index[basename].append(i)

    return full_path_index, dict(basename_index)


def _resolve_image_to_frame(
    coco_file_name: str,
    full_path_index: dict[str, int],
    basename_index: dict[str, list[int]],
) -> int | None:
    """Match a COCO image file_name to an imageset frame index.

    Tries exact relative path match first, then falls back to basename match
    if the basename is unique in the imageset.

    Returns:
        Frame index, or None if no match found.
    """
    normalized = str(PurePosixPath(coco_file_name))

    # Try exact relative path match
    if normalized in full_path_index:
        return full_path_index[normalized]

    # Try basename-only match (must be unique)
    basename = PurePosixPath(coco_file_name).name
    candidates = basename_index.get(basename, [])
    if len(candidates) == 1:
        return candidates[0]

    return None


def parse_coco_json(
    coco_path: str | Path,
    metadata: ImagesetMetadata,
    layer: str = "gt",
    display_name: str = "COCO Annotations",
) -> ImportedLayer:
    """Parse a COCO JSON annotation file and map to imageset frame indices.

    Args:
        coco_path: Path to the COCO JSON file.
        metadata: Imageset metadata (used to resolve image filenames to frame indices).
        layer: Layer key for the imported annotations (e.g., "gt", "det/coco").
        display_name: Human-readable layer name.

    Returns:
        ImportedLayer with detection annotations mapped to frame indices.

    Raises:
        FileNotFoundError: If the COCO file doesn't exist.
        ValueError: If the file format is invalid or no images could be matched.
    """
    coco_path = Path(coco_path)
    if not coco_path.exists():
        raise FileNotFoundError(f"COCO JSON file not found: {coco_path}")

    data = orjson.loads(coco_path.read_bytes())

    if not isinstance(data, dict):
        raise ValueError(f"Invalid COCO format: expected a JSON object in {coco_path}")

    # Parse categories
    categories: dict[int, str] = {}
    for cat in data.get("categories", []):
        categories[cat["id"]] = cat["name"]

    # Parse images and build COCO image_id -> frame_index mapping
    full_path_index, basename_index = _build_filename_index(metadata)

    coco_id_to_frame: dict[int, int] = {}
    unmatched_images: list[str] = []
    for img in data.get("images", []):
        coco_image_id = img["id"]
        file_name = img["file_name"]
        frame_idx = _resolve_image_to_frame(file_name, full_path_index, basename_index)
        if frame_idx is not None:
            coco_id_to_frame[coco_image_id] = frame_idx
        else:
            unmatched_images.append(file_name)

    if not coco_id_to_frame:
        raise ValueError(
            f"No COCO images could be matched to the imageset. "
            f"Tried {len(data.get('images', []))} images. "
            f"Check that file_name values match the imageset filenames."
        )

    if unmatched_images:
        logger.warning(
            "%d of %d COCO images could not be matched: %s%s",
            len(unmatched_images),
            len(data.get("images", [])),
            ", ".join(unmatched_images[:5]),
            f" (and {len(unmatched_images) - 5} more)" if len(unmatched_images) > 5 else "",
        )

    # Parse annotations and group by frame
    frames: dict[int, list[dict[str, Any]]] = defaultdict(list)
    skipped = 0

    for ann in data.get("annotations", []):
        coco_image_id = ann["image_id"]
        frame_idx = coco_id_to_frame.get(coco_image_id)
        if frame_idx is None:
            skipped += 1
            continue

        category_id = ann.get("category_id")
        class_name = categories.get(category_id, f"category_{category_id}")

        # Convert COCO bbox [x, y, width, height] to VD3 bbox [xmin, ymin, xmax, ymax]
        coco_bbox = ann["bbox"]
        if not isinstance(coco_bbox, list) or len(coco_bbox) != 4:
            logger.warning("Skipping annotation %s: invalid bbox %s", ann.get("id"), coco_bbox)
            continue

        x, y, w, h = coco_bbox
        vd3_bbox = [x, y, x + w, y + h]

        obj: dict[str, Any] = {
            "class_name": class_name,
            "bbox": vd3_bbox,
        }

        # Preserve optional COCO fields
        if "score" in ann:
            obj["confidence"] = ann["score"]
        elif "confidence" in ann:
            obj["confidence"] = ann["confidence"]
        if "area" in ann:
            obj["area"] = ann["area"]
        if "iscrowd" in ann:
            obj["iscrowd"] = ann["iscrowd"]

        frames[frame_idx].append(obj)

    if skipped:
        logger.info("Skipped %d annotations for unmatched images", skipped)

    matched_images = len(coco_id_to_frame)
    total_annotations = sum(len(objs) for objs in frames.values())
    logger.info(
        "Parsed COCO: %d images matched, %d annotations across %d frames from %s",
        matched_images,
        total_annotations,
        len(frames),
        coco_path,
    )

    return ImportedLayer(
        layer=layer,
        display_name=display_name,
        layer_type="detections",
        frames=dict(frames),
    )
