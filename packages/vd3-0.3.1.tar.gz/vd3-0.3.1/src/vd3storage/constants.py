"""Constants and enumerations for VD3Storage."""

from enum import StrEnum


class AssetType(StrEnum):
    VIDEO = "video"
    IMAGESET = "imageset"


class SensorType(StrEnum):
    RGB = "rgb"
    THERMAL = "thermal"
    VARIOUS = "various"
    UNKNOWN = "unknown"


class SensorMount(StrEnum):
    STATIONARY = "stationary"
    MOVING = "moving"
    VARIOUS = "various"
    UNKNOWN = "unknown"


class Environment(StrEnum):
    URBAN = "urban"
    SUBURBAN = "suburban"
    RURAL = "rural"
    INDOOR = "indoor"
    PARKING = "parking"
    HIGHWAY = "highway"
    MARINE = "marine"
    AIRPORT = "airport"
    SKY = "sky"
    UNKNOWN = "unknown"


class Placement(StrEnum):
    OUTDOOR = "outdoor"
    INDOOR = "indoor"
    VARIOUS = "various"
    UNKNOWN = "unknown"


class TimeOfDay(StrEnum):
    """Lighting conditions the asset was captured under.

    ``DAWN_DUSK_CLOUDY`` is a single compound bucket: the heuristics that classify
    this field operate on low-contrast pixel distributions, which are indistinguishable
    between dawn, dusk, and overcast daylight. Three source scenarios, one label.
    """

    DAY = "day"
    NIGHT = "night"
    DAWN_DUSK_CLOUDY = "dawn_dusk_cloudy"
    UNKNOWN = "unknown"


class Spectrum(StrEnum):
    """Sensor spectrum the asset was captured in.

    Orthogonal to ``TimeOfDay``: visible-light footage can be recorded at night
    (with external illumination) and infrared footage can be recorded in daylight.
    """

    VISIBLE = "visible"
    INFRARED = "infrared"
    UNKNOWN = "unknown"


class LayerType(StrEnum):
    DETECTIONS = "detections"
    TRACKS = "tracks"
