"""Table manager — insert, update, delete, query for a single model type."""

from __future__ import annotations

from typing import TYPE_CHECKING, Generic, TypeVar

from vd3storage.models.base import VD3Model
from vd3storage.orm.query import Query

if TYPE_CHECKING:
    from vd3storage.orm.engine import Engine

T = TypeVar("T", bound=VD3Model)


class Table(Generic[T]):
    """Manages insert, update, delete, and query for a single model type."""

    def __init__(self, engine: Engine, model_cls: type[T]) -> None:
        self._engine = engine
        self._model_cls = model_cls
        self._table_name = model_cls.csv_filename().replace(".csv", "")
        self._dirty = False

    @property
    def is_dirty(self) -> bool:
        return self._dirty

    def insert(self, instance: T) -> T:
        """Insert a model instance as a new row."""
        data = instance.model_dump()
        columns = ", ".join(f'"{k}"' for k in data)
        placeholders = ", ".join(["?"] * len(data))
        sql = f"INSERT INTO {self._table_name} ({columns}) VALUES ({placeholders})"
        self._engine.execute(sql, list(data.values()))
        self._dirty = True
        return instance

    def insert_many(self, instances: list[T]) -> None:
        """Bulk insert multiple instances."""
        for instance in instances:
            self.insert(instance)

    def update(self, instance: T) -> None:
        """Update a row by primary key."""
        pk = self._model_cls.primary_key()
        data = instance.model_dump()
        pk_value = data.pop(pk)
        set_clause = ", ".join(f'"{k}" = ?' for k in data)
        sql = f'UPDATE {self._table_name} SET {set_clause} WHERE "{pk}" = ?'
        self._engine.execute(sql, list(data.values()) + [pk_value])
        self._dirty = True

    def query(self) -> Query[T]:
        """Get a query builder for this table."""
        return Query(self._engine, self._model_cls)

    def flush(self) -> None:
        """Write to CSV if dirty."""
        if self._dirty:
            self._engine.flush_table(self._model_cls)
            self._dirty = False

    def mark_dirty(self) -> None:
        """Mark this table as needing a flush."""
        self._dirty = True
