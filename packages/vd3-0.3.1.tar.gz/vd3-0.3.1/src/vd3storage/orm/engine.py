"""DuckDB engine — manages in-memory tables backed by CSV files."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import duckdb

from vd3storage.models.base import VD3Model

logger = logging.getLogger(__name__)

# Matches a standalone empty quoted field (`""`) sitting between commas or
# line boundaries. The lookarounds intentionally exclude `""` sequences that
# appear inside a larger quoted field — those are CSV-escaped literal quotes,
# not empty fields.
_EMPTY_QUOTED_FIELD_RE = re.compile(r'(^|,|\n)""(?=,|\n|$)')


def _sql_default(model_cls: type[VD3Model], field_name: str, duckdb_type: str) -> str:
    """Return a SQL literal for the Pydantic default value of a model field."""
    field_info = model_cls.model_fields.get(field_name)
    if field_info is not None and field_info.default is not None:
        val = field_info.default
        if isinstance(val, str):
            escaped = val.replace("'", "''")
            return f"'{escaped}'"
        if isinstance(val, bool):
            return "TRUE" if val else "FALSE"
        if isinstance(val, (int, float)):
            return str(val)

    # Fall back to type-based defaults
    type_defaults: dict[str, str] = {
        "VARCHAR": "''",
        "BIGINT": "0",
        "DOUBLE": "0.0",
        "BOOLEAN": "NULL",
        "TIMESTAMP": "NULL",
    }
    return type_defaults.get(duckdb_type, "NULL")


class Engine:
    """Manages a DuckDB in-memory connection with CSV-backed tables.

    CSV files are the source of truth. On register_table(), the CSV is loaded
    into an in-memory DuckDB table. On flush_table(), the in-memory table is
    written back to CSV.
    """

    def __init__(self, tables_dir: Path) -> None:
        self._tables_dir = tables_dir
        self._con = duckdb.connect(":memory:")
        self._registered: dict[str, type[VD3Model]] = {}

    @property
    def tables_dir(self) -> Path:
        return self._tables_dir

    def register_table(self, model_cls: type[VD3Model]) -> None:
        """Create or replace a DuckDB table from the CSV file for the given model.

        If the CSV file exists, loads it. Otherwise creates an empty table
        from the model's schema.
        """
        csv_path = self._tables_dir / model_cls.csv_filename()
        table_name = csv_path.stem

        # Always create table with explicit schema from model
        cols = model_cls.duckdb_columns()
        col_defs = ", ".join(f'"{name}" {dtype}' for name, dtype in cols.items())
        self._con.execute(f"CREATE OR REPLACE TABLE {table_name} ({col_defs})")

        if csv_path.exists() and csv_path.stat().st_size > 0:
            # Load data from CSV into the typed table, handling schema evolution
            logger.debug("Loading table '%s' from %s", table_name, csv_path)

            # Detect which columns actually exist in the CSV
            csv_cols_rel = self._con.execute(
                f"SELECT column_name FROM (DESCRIBE SELECT * FROM read_csv_auto('{csv_path}'))"
            ).fetchall()
            csv_col_names = {row[0] for row in csv_cols_rel}

            # Build SELECT expressions: use CSV column if present, otherwise use model default
            select_exprs = []
            for name, dtype in cols.items():
                if name in csv_col_names:
                    select_exprs.append(f'"{name}"')
                else:
                    default_val = _sql_default(model_cls, name, dtype)
                    select_exprs.append(f'{default_val} AS "{name}"')
                    logger.info("Table '%s': column '%s' not in CSV, using default %s", table_name, name, default_val)

            col_names = ", ".join(f'"{name}"' for name in cols)
            select_clause = ", ".join(select_exprs)
            self._con.execute(
                f"INSERT INTO {table_name} ({col_names}) SELECT {select_clause} FROM read_csv_auto('{csv_path}')"
            )
        else:
            logger.debug("Created empty table '%s'", table_name)

        self._registered[table_name] = model_cls

    def flush_table(self, model_cls: type[VD3Model]) -> None:
        """Write the in-memory DuckDB table back to its CSV file."""
        csv_path = self._tables_dir / model_cls.csv_filename()
        table_name = csv_path.stem
        logger.debug("Flushing table '%s' to %s", table_name, csv_path)
        self._con.execute(f"COPY {table_name} TO '{csv_path}' (HEADER, DELIMITER ',')")
        _normalize_empty_fields(csv_path)

    def execute(self, sql: str, params: list[Any] | None = None) -> duckdb.DuckDBPyConnection:
        """Execute a SQL statement and return the connection for result fetching."""
        if params:
            return self._con.execute(sql, params)
        return self._con.execute(sql)

    def close(self) -> None:
        """Close the DuckDB connection."""
        self._con.close()


def _normalize_empty_fields(csv_path: Path) -> None:
    """Rewrite ``,"",`` (and the line-boundary variants) to ``,,`` in-place.

    DuckDB's ``COPY ... TO`` writes empty STRING values as ``""`` and NULL as
    nothing. ``read_csv_auto`` then collapses both back to NULL on the next
    load — so the distinction is already lossy across a round-trip. To keep
    the on-disk CSV byte-stable across writes (and avoid spurious diffs when
    a row is touched), we canonicalize every empty field to the unquoted
    form.
    """
    text = csv_path.read_text()
    normalized = _EMPTY_QUOTED_FIELD_RE.sub(r"\1", text)
    if normalized != text:
        csv_path.write_text(normalized)
