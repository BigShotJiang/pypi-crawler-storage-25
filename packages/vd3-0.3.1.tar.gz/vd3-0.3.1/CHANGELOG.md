# Changelog

All notable changes to the `vd3` package are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
The project follows [Semantic Versioning](https://semver.org), with the 0.x
caveat described below.

## Versioning policy

While the package is in 0.x:

- **Minor** bumps (0.2 → 0.3) may contain breaking changes. Every such change
  is listed under a `### Breaking` heading in the release section below.
- **Patch** bumps (0.2.1 → 0.2.2) are backwards compatible: bug fixes, internal
  refactors, and additive changes only.

Once the package reaches 1.0, it will follow strict SemVer (MAJOR bumps for
breaking changes, MINOR for additive, PATCH for fixes).

**What counts as "the public API"** — for the purpose of deciding whether a
change is breaking — is defined in the "Versioning & stability" section of the
README.

**Deprecation policy.** When a public API needs to be removed or renamed, the
old form emits `DeprecationWarning` for at least one minor release before being
removed, and the removal is announced under `### Deprecated` in the release
that introduces the warning.

---

## [Unreleased]

_No changes yet._

## [0.3.1] — 2026-05-15

### Added

- `vd3 datasource set-description <name> <description>` and a `description` column
  on `vd3 datasource list` / line in `vd3 datasource show` (#295). Descriptions
  live in a new sidecar `datasources` CSV table; assets still reference
  datasources by string name and no migration to existing data is required.
- Library: `VD3Storage.list_datasources()`, `get_datasource_description(name)`,
  and `set_datasource_description(name, description)`.

### Changed

- `vd3 asset list` (and the workset/datasource asset listings that reuse the
  same renderer) no longer print `Sensor` and `Environment` columns (#298).
  The detail view (`vd3 asset show`) is unchanged and still surfaces both.
  The underlying `Asset` schema is unchanged; only the table renderer was
  trimmed.

### Schema

- Bumped `SCHEMA_VERSION` to 8 to record the new sidecar `datasources` table.
  Pre-v8 databases get the table created empty on first open with this
  version; no destructive migration is performed.

## [0.3.0] — 2026-05-15

### Breaking

- CLI restructured to a uniform noun-first hierarchy (#296). All commands now
  read `vd3 <noun> <verb> [args]`. Containers (`datasource`, `workset`) own
  ingest verbs and contained-asset listings; the `asset` noun is reserved for
  operations on a known asset. There are no compatibility aliases; every
  previous invocation has a one-to-one replacement.

| Old | New |
|---|---|
| `vd3 init [path]` | `vd3 db init [path]` |
| `vd3 info` | `vd3 db info` |
| `vd3 query "..."` | `vd3 db query "..."` |
| `vd3 list assets` | `vd3 asset list` |
| `vd3 list assets -w W` | `vd3 workset assets W` |
| `vd3 list assets -d D` | `vd3 datasource assets D` |
| `vd3 list datasources` | `vd3 datasource list` |
| `vd3 list layers -a A` | `vd3 asset layers A` |
| `vd3 show A` | `vd3 asset show A` |
| `vd3 remove A` | `vd3 asset remove A` |
| `vd3 add video FILES -d D` | `vd3 datasource add-video D FILES` |
| `vd3 add imageset PATH -d D` | `vd3 datasource add-imageset D PATH` |
| `vd3 add coco-dataset F -d D --image-root R --layer L` | `vd3 datasource add-imageset-from-coco D L F --image-root R` |
| `vd3 add coco F -a A --layer L` | `vd3 layer add-coco A L F` |
| `vd3 add result F -a A` | `vd3 layer add-vd3 A <layer-name> F` |
| `vd3 export frames A -o D` | `vd3 asset export-frames A -o D` |
| `vd3 workset add-asset W A` | `vd3 workset add W A` |
| `vd3 workset remove-asset W A` | `vd3 workset remove W A` |
| `vd3 workset show W` (metadata + assets) | `vd3 workset show W` (metadata only) + `vd3 workset assets W` |

- `vd3 workset show` no longer lists the assets contained in the workset; use
  the new `vd3 workset assets <slug>` for that. The `show` output still
  includes annotation-layer coverage and packages.
- `vd3 layer add-vd3 <asset> <layer-name> <vd3.json>` requires a `<layer-name>`
  positional that did not exist in `vd3 add result`. The value is used as a
  layer-key prefix prepended to every layer in the file (e.g. a file
  containing `det/yolo` imported under `run-1` becomes `run-1/det/yolo`),
  enabling repeated imports of the same algorithm's output into different
  namespaces.

### Added

- `vd3 datasource show <name>` (#295) — surface datasource stats (asset count,
  videos, imagesets).
- `vd3 datasource assets <name>` and `vd3 workset assets <name>` with
  `--paths` and `--filenames` modifiers (#294, #321). Default output is the
  rich table; `--paths` writes one media path per line, `--filenames` writes
  one filename per line. `vd3 asset list` accepts the same modifiers.
- `vd3 media push` accepts `--workset` / `--asset` / `--datasource` / `--all`
  to mirror `vd3 media pull`. The library `VD3Storage.push` method gains
  matching `workset_id=` and `datasource=` keyword arguments (additive).
- `vd3 workset layers <slug>` and `vd3 datasource layers <name>` list
  annotation layers aggregated across all assets in the container, with
  per-layer asset count and coverage. Mirrors the `<container> <contained>`
  pattern set by `assets`. The library gains `VD3Storage.list_datasource_layers`
  (`list_workset_layers` already existed).

### Changed

- Listing annotation layers on an asset moves from `vd3 layer list <asset>`
  to `vd3 asset layers <name>`, matching the container-contained pattern set
  by `workset assets` and `datasource assets`. The `layer` noun is now
  ingest-only (`add-coco`, `add-vd3`).
- `vd3 workset show` no longer renders the inline per-layer coverage table;
  use `vd3 workset layers <slug>` for that view. The metadata panel still
  carries the layer count, and packages are still shown inline.

## [0.2.2] — 2026-05-12

### Added
- CLI auto-loads a `.env` file from the current directory or nearest ancestor,
  so `VD3_DB` can be set per-project without `export`. Precedence:
  `--path` > shell-exported `VD3_DB` > `.env` `VD3_DB` > cwd.

## [0.2.1] — 2026-05

### Changed
- Reframed the project description as "DVC-backed media database for computer
  vision and ML developers" (no API changes).

### Added
- `publish.sh` tags real (non-test) releases as `vX.Y.Z` and pushes the tag.
- `--path` / `-p` on every CLI command now honors the `VD3_DB` environment
  variable when the flag is omitted.

## [0.2.0] — 2026-04

### Breaking
- Asset schema v7: dropped `weather_*` and `starred` columns from `Asset`.
- Annotation layers now require a `source` field (`"human"` or `"machine"`)
  and are schema-validated on write.
- Unprefixed tags (no `namespace:value` shape) now emit `DeprecationWarning`
  in `VD3Storage.add_tag`. Adopt the `namespace:value` convention to keep
  consumers of the same database from colliding on tag names.

### Added
- COCO import (`import_coco`, `import_coco_dataset`) and COCO export
  (`export_coco`) on `VD3Storage`, plus `vd3 add coco` / `vd3 add coco-dataset`
  CLI commands.
- `read_annotation_layer(asset_id, layer)` for reading a full annotation layer.
- Workset asset / package / layer statistics in `list_worksets_with_stats`
  and `list_workset_layers`, surfaced in `vd3 workset list` and
  `vd3 workset show`.
- Imageset asset type: directory-of-images or `.tar` archive as a first-class
  asset alongside videos (`import_imageset`, `vd3 add imageset`).
- `reviewed_frames` on annotation layers; `camera_id` and `video_id` columns
  on `Asset`.
- Asset schema v6: `spectrum` and `codec` columns.
- `extra_json` shape is validated on `Asset` write.
- `--force` flag on `vd3 init` with artifact detection before reinitializing.
- `vd3 init` with no path defaults to the current working directory.

## [0.1.0] — 2026-03

Initial published release. Provided the core `VD3Storage` API, the `vd3` CLI,
DVC-backed media tracking with S3 / GCS / Azure / GDrive / local backends, the
asset / workset / tag data model, and VD3 JSON result import.
