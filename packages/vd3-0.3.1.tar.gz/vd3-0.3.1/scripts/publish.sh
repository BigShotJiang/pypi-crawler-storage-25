#!/usr/bin/env bash
# Build and publish to PyPI.
#
# Usage:
#   ./scripts/publish.sh                    # publish to PyPI (interactive confirm)
#   ./scripts/publish.sh --test             # publish to Test PyPI
#   ./scripts/publish.sh --yes              # publish to PyPI without prompting
#   ./scripts/publish.sh --test --yes       # publish to Test PyPI without prompting
#   VD3_TEST=1 ./scripts/publish.sh         # publish to Test PyPI (env var)
#   VD3_YES=1 ./scripts/publish.sh          # skip confirmation (env var)
#
# Requires ~/.pypirc or TWINE_USERNAME/TWINE_PASSWORD env vars.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

# Load .env if present
if [[ -f .env ]]; then
    set -a
    source .env
    set +a
fi

REPO_FLAG=()
TEST_MODE=false
SKIP_CONFIRM=false

# Parse flags (any order)
for arg in "$@"; do
    case "$arg" in
        --test) TEST_MODE=true ;;
        --yes|-y) SKIP_CONFIRM=true ;;
        *) echo "Unknown argument: $arg" >&2; exit 2 ;;
    esac
done

# Environment-variable equivalents
[[ "${VD3_TEST:-}" == "1" ]] && TEST_MODE=true
[[ "${VD3_YES:-}" == "1" ]] && SKIP_CONFIRM=true

# Use project-level .pypirc if present, otherwise ~/.pypirc
if [[ -f .pypirc ]]; then
    REPO_FLAG+=(--config-file .pypirc)
fi

if [[ "$TEST_MODE" == true ]]; then
    REPO_FLAG+=(--repository testpypi)
    echo "Publishing to Test PyPI"
else
    echo "Publishing to PyPI"
fi

# Clean previous builds
rm -rf dist/

# Lint
echo "Running ruff..."
uv run ruff check src/

# Bake TEST_RELEASE flag and dev version for test publishes
RELEASE_FILE="src/vd3storage/_release.py"
PYPROJECT="pyproject.toml"
if [[ "$TEST_MODE" == true ]]; then
    sed -i 's/TEST_RELEASE = False/TEST_RELEASE = True/' "$RELEASE_FILE"
    # Append .devN timestamp to avoid version conflicts on Test PyPI
    DEV_SUFFIX=".dev$(date +%Y%m%d%H%M%S)"
    sed -i "s/^version = \"\(.*\)\"/version = \"\1${DEV_SUFFIX}\"/" "$PYPROJECT"
fi

# Build
echo "Building..."
uv run python -m build

# Restore modified files to default
git checkout -- "$RELEASE_FILE" "$PYPROJECT"

# Show what we built
echo ""
echo "Built:"
ls -lh dist/

# Confirm
PKG_INFO=$(uv run python -c "
import re, pathlib
whl = next(pathlib.Path('dist').glob('*.whl'))
m = re.match(r'(.+?)-(.+?)-.+\.whl', whl.name)
print(m.group(1), m.group(2))
")
PKG_NAME="${PKG_INFO% *}"
VERSION="${PKG_INFO#* }"
echo ""
if [[ "$SKIP_CONFIRM" == true ]]; then
    echo "Publishing ${PKG_NAME} v${VERSION} (--yes/VD3_YES set, skipping confirmation)"
else
    read -rp "Publish ${PKG_NAME} v${VERSION}? [y/N] " confirm
    if [[ "$confirm" != [yY] ]]; then
        echo "Aborted."
        exit 1
    fi
fi

# Upload (the ${arr[@]+"${arr[@]}"} idiom is safe under `set -u` when arr is empty)
uv run twine upload ${REPO_FLAG[@]+"${REPO_FLAG[@]}"} dist/*

echo ""
echo "Published ${PKG_NAME} v${VERSION}"

# Tag the release (skip in test mode — dev-suffixed versions aren't real releases)
if [[ "$TEST_MODE" == false ]]; then
    TAG="v${VERSION}"
    if git rev-parse "$TAG" >/dev/null 2>&1; then
        echo "Tag ${TAG} already exists; skipping tag creation."
    else
        git tag -a "$TAG" -m "Release ${TAG}"
        git push origin "$TAG"
        echo "Tagged and pushed ${TAG}"
    fi
fi
