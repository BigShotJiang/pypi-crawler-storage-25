"""Tests for the VD3 CLI (noun-first surface, 0.3.0+)."""

import subprocess
from pathlib import Path

import orjson
import pytest
from typer.testing import CliRunner

from vd3storage.cli.app import app

runner = CliRunner()


@pytest.fixture
def db_path(tmp_path) -> Path:
    """Create a temp content database for CLI tests."""
    db = tmp_path / "test-db"
    result = runner.invoke(app, ["db", "init", str(db), "--no-git", "--no-dvc"])
    assert result.exit_code == 0
    return db


@pytest.fixture
def sample_video(tmp_path) -> Path:
    """Create a small test video."""
    video_path = tmp_path / "test_input.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc=duration=0.5:size=64x48:rate=10",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(video_path),
        ],
        check=True,
        capture_output=True,
    )
    return video_path


class TestDbInit:
    def test_init(self, tmp_path):
        db = tmp_path / "new-db"
        result = runner.invoke(app, ["db", "init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 0
        assert "Created content database" in result.output
        assert (db / "db" / "tables" / "assets.csv").exists()

    def test_init_dev(self, tmp_path):
        db = tmp_path / "dev-db"
        result = runner.invoke(app, ["db", "init", str(db), "--no-git", "--no-dvc", "--dev"])
        assert result.exit_code == 0
        assert "[tool.uv.sources]" in (db / "pyproject.toml").read_text()

    def test_init_already_initialized(self, tmp_path):
        """Re-running init on same directory should fail with clear error."""
        db = tmp_path / "existing-db"
        result = runner.invoke(app, ["db", "init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 0

        result = runner.invoke(app, ["db", "init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 1
        assert "already initialized" in result.output

    def test_init_force(self, tmp_path):
        """--force should allow reinitializing."""
        db = tmp_path / "force-db"
        result = runner.invoke(app, ["db", "init", str(db), "--no-git", "--no-dvc"])
        assert result.exit_code == 0

        result = runner.invoke(app, ["db", "init", str(db), "--no-git", "--no-dvc", "--force"])
        assert result.exit_code == 0
        assert "Created content database" in result.output


class TestDbInfo:
    def test_info(self, db_path):
        result = runner.invoke(app, ["db", "info", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Assets" in result.output
        assert "Worksets" in result.output


class TestDatasourceAdd:
    def test_add_video(self, db_path, sample_video):
        result = runner.invoke(
            app,
            ["datasource", "add-video", "test-col", str(sample_video), "--path", str(db_path)],
        )
        assert result.exit_code == 0
        assert "Imported" in result.output

    def test_add_video_to_workset(self, db_path, sample_video):
        runner.invoke(app, ["workset", "create", "MyProject", "--path", str(db_path)])

        result = runner.invoke(
            app,
            [
                "datasource",
                "add-video",
                "test-col",
                str(sample_video),
                "--workset",
                "myproject",
                "--package",
                "training",
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0
        assert "test_in" in result.output


class TestLayerAdd:
    def test_add_vd3(self, db_path, sample_video, tmp_path):
        runner.invoke(
            app,
            ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)],
        )

        vd3_json = tmp_path / "results.vd3.json"
        vd3_json.write_bytes(
            orjson.dumps(
                {
                    "layers": [
                        {
                            "layer": "det/test",
                            "display_name": "Test Detections",
                            "layer_type": "detections",
                            "frames": {"0": [{"class_name": "x", "confidence": 0.9, "bbox": [1, 2, 3, 4]}]},
                        }
                    ]
                }
            )
        )

        result = runner.invoke(
            app,
            [
                "layer",
                "add-vd3",
                "test_input",
                "run-1",
                str(vd3_json),
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0
        assert "Imported 1 annotation" in result.output
        assert "run-1/det/test" in result.output


class TestAssetList:
    def test_list_assets(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["asset", "list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "test_in" in result.output
        assert "col1" in result.output

    def test_list_assets_omits_sensor_and_environment(self, db_path, sample_video):
        """MC-298: Sensor and Environment columns no longer appear in the asset list table."""
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["asset", "list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Sensor" not in result.output
        assert "Environment" not in result.output

    def test_list_assets_empty(self, db_path):
        result = runner.invoke(app, ["asset", "list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No assets" in result.output

    def test_list_assets_paths(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["asset", "list", "--paths", "--path", str(db_path)])
        assert result.exit_code == 0
        assert ".mp4" in result.output


class TestDatasource:
    def test_list_datasources(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "dashcam", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["datasource", "list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "dashcam" in result.output

    def test_show_datasource(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "dashcam", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["datasource", "show", "dashcam", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "dashcam" in result.output
        assert "Videos" in result.output

    def test_datasource_assets(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "dashcam", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["datasource", "assets", "dashcam", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "test_in" in result.output

    def test_datasource_layers_empty(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "dashcam", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["datasource", "layers", "dashcam", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No annotation layers" in result.output

    def test_set_description_round_trip(self, db_path, sample_video):
        """MC-295: set-description stores text that appears in `list` and `show`."""
        runner.invoke(app, ["datasource", "add-video", "dashcam", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(
            app,
            ["datasource", "set-description", "dashcam", "Forward-facing 2024 clips", "--path", str(db_path)],
        )
        assert result.exit_code == 0
        assert "Set description" in result.output

        list_result = runner.invoke(app, ["datasource", "list", "--path", str(db_path)])
        assert list_result.exit_code == 0
        assert "Forward-facing 2024 clips" in list_result.output

        show_result = runner.invoke(app, ["datasource", "show", "dashcam", "--path", str(db_path)])
        assert show_result.exit_code == 0
        assert "Forward-facing 2024 clips" in show_result.output

    def test_set_description_before_assets(self, db_path):
        """Description can be set on a datasource that has no assets yet."""
        result = runner.invoke(
            app,
            ["datasource", "set-description", "planned-ds", "Reserved for later import", "--path", str(db_path)],
        )
        assert result.exit_code == 0
        show_result = runner.invoke(app, ["datasource", "show", "planned-ds", "--path", str(db_path)])
        assert show_result.exit_code == 0
        assert "Reserved for later import" in show_result.output


class TestAssetLayers:
    def test_asset_layers(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["asset", "layers", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0


class TestAssetShow:
    def test_show(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["asset", "show", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "col1" in result.output
        assert "64x48" in result.output or "64" in result.output

    def test_show_not_found(self, db_path):
        result = runner.invoke(app, ["asset", "show", "nonexistent", "--path", str(db_path)])
        assert result.exit_code == 1


class TestDbQuery:
    def test_query(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["db", "query", "SELECT name, datasource FROM assets", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "test_input" in result.output


class TestAssetRemove:
    def test_remove(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        result = runner.invoke(app, ["asset", "remove", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Deleted" in result.output


class TestWorksetCommands:
    def test_workset_crud(self, db_path):
        result = runner.invoke(app, ["workset", "create", "My Project", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "my-project" in result.output

        result = runner.invoke(app, ["workset", "list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "my-project" in result.output

        result = runner.invoke(app, ["workset", "show", "my-project", "--path", str(db_path)])
        assert result.exit_code == 0

        result = runner.invoke(app, ["workset", "delete", "my-project", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Deleted" in result.output

    def test_workset_add_remove(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        runner.invoke(app, ["workset", "create", "MyProject", "--path", str(db_path)])

        result = runner.invoke(app, ["workset", "add", "myproject", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Added" in result.output

        result = runner.invoke(app, ["workset", "assets", "myproject", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "test_in" in result.output

        result = runner.invoke(app, ["workset", "remove", "myproject", "test_input", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Removed" in result.output

    def test_workset_layers_empty(self, db_path, sample_video):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        runner.invoke(app, ["workset", "create", "Empty", "--path", str(db_path)])
        runner.invoke(app, ["workset", "add", "empty", "test_input", "--path", str(db_path)])
        result = runner.invoke(app, ["workset", "layers", "empty", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No annotation layers" in result.output


class TestMediaStatus:
    def test_status(self, db_path):
        result = runner.invoke(app, ["media", "status", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Total" in result.output


class TestAssetExportFrames:
    def test_export_frames(self, db_path, sample_video, tmp_path):
        runner.invoke(app, ["datasource", "add-video", "col1", str(sample_video), "--path", str(db_path)])
        output_dir = tmp_path / "exported"
        result = runner.invoke(
            app,
            [
                "asset",
                "export-frames",
                "test_input",
                "--output",
                str(output_dir),
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output
        assert len(list(output_dir.glob("*.jpg"))) > 0
