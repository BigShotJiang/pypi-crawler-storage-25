"""Shared test fixtures."""

import pytest

from vd3storage import VD3Storage


@pytest.fixture
def tmp_storage(tmp_path):
    """Create a temporary VD3Storage content database."""
    storage = VD3Storage.init(tmp_path / "test-db", git_init=False, dvc_init=False)
    yield storage
    storage.save()
    storage._engine.close()
