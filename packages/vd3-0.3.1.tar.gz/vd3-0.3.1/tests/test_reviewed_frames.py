"""Tests for reviewed_frames support and the source-field schema in annotation layers."""

import subprocess
import warnings
from pathlib import Path

import orjson
import pytest

from vd3storage.media.annotation_store import (
    _check_layer_schema,
    list_annotation_layers,
    read_annotation_layer,
    write_annotation_layer,
)


@pytest.fixture
def sample_video(tmp_path) -> Path:
    """Create a small test video using ffmpeg."""
    video_path = tmp_path / "test_input.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc=duration=0.5:size=64x48:rate=10",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(video_path),
        ],
        check=True,
        capture_output=True,
    )
    return video_path


class TestWriteAnnotationLayerReviewedFrames:
    def test_with_reviewed_frames(self, tmp_path):
        """reviewed_frames should be written to the JSON output."""
        metadata_dir = tmp_path / "metadata"

        frames = {
            0: [{"class_name": "person", "bbox": [10, 20, 30, 40]}],
            5: [{"class_name": "vehicle", "bbox": [50, 60, 200, 300]}],
        }
        reviewed = [0, 1, 2, 3, 4, 5, 6, 7]

        json_path = write_annotation_layer(
            metadata_dir,
            "det/ground_truth",
            "Ground Truth",
            "detections",
            frames,
            reviewed_frames=reviewed,
            source="human",
        )

        data = orjson.loads(json_path.read_bytes())
        assert data["layer"] == "det/ground_truth"
        assert data["source"] == "human"
        assert data["reviewed_frames"] == [0, 1, 2, 3, 4, 5, 6, 7]
        assert len(data["frames"]) == 2
        assert "0" in data["frames"]
        assert "5" in data["frames"]

    def test_without_reviewed_frames(self, tmp_path):
        """When reviewed_frames is None, the field should be omitted."""
        metadata_dir = tmp_path / "metadata"

        frames = {0: [{"class_name": "person", "bbox": [10, 20, 30, 40]}]}

        json_path = write_annotation_layer(metadata_dir, "det/model", "Model", "detections", frames, source="machine")

        data = orjson.loads(json_path.read_bytes())
        assert "reviewed_frames" not in data
        assert data["source"] == "machine"
        assert data["frames"]["0"][0]["class_name"] == "person"

    def test_reviewed_frames_sorted(self, tmp_path):
        """reviewed_frames should be sorted in the output even if unsorted on input."""
        metadata_dir = tmp_path / "metadata"

        json_path = write_annotation_layer(
            metadata_dir,
            "det/ground_truth",
            "GT",
            "detections",
            {},
            reviewed_frames=[5, 1, 3, 0, 2],
            source="human",
        )

        data = orjson.loads(json_path.read_bytes())
        assert data["reviewed_frames"] == [0, 1, 2, 3, 5]

    def test_reviewed_frames_empty_list(self, tmp_path):
        """An empty reviewed_frames list should be written (distinct from None/omitted)."""
        metadata_dir = tmp_path / "metadata"

        json_path = write_annotation_layer(
            metadata_dir,
            "det/ground_truth",
            "GT",
            "detections",
            {},
            reviewed_frames=[],
            source="human",
        )

        data = orjson.loads(json_path.read_bytes())
        assert data["reviewed_frames"] == []


class TestSchemaValidation:
    """Schema rules enforced at write time. Violations raise ``ValueError``."""

    def test_missing_source_arg_raises(self, tmp_path):
        """Omitting source raises TypeError — it is a required keyword arg."""
        metadata_dir = tmp_path / "metadata"

        with pytest.raises(TypeError, match="source"):
            write_annotation_layer(metadata_dir, "det/m", "M", "detections", {})  # ty: ignore[missing-argument]

    def test_invalid_source_raises(self, tmp_path):
        """An out-of-enum source value raises ValueError."""
        metadata_dir = tmp_path / "metadata"

        with pytest.raises(ValueError, match="invalid source"):
            write_annotation_layer(metadata_dir, "det/m", "M", "detections", {}, source="bogus")

    def test_human_without_reviewed_frames_raises(self, tmp_path):
        """source='human' without reviewed_frames raises ValueError."""
        metadata_dir = tmp_path / "metadata"

        with pytest.raises(ValueError, match="reviewed_frames"):
            write_annotation_layer(metadata_dir, "det/gt", "GT", "detections", {}, source="human")

    def test_machine_with_reviewed_frames_raises(self, tmp_path):
        """source='machine' with reviewed_frames raises ValueError."""
        metadata_dir = tmp_path / "metadata"

        with pytest.raises(ValueError, match="reviewed_frames"):
            write_annotation_layer(
                metadata_dir,
                "det/m",
                "M",
                "detections",
                {},
                reviewed_frames=[0, 1],
                source="machine",
            )

    def test_ground_truth_reservation_raises(self, tmp_path):
        """A '*/ground_truth' layer with source != 'human' raises ValueError."""
        metadata_dir = tmp_path / "metadata"

        with pytest.raises(ValueError, match="reserved for human-reviewed"):
            write_annotation_layer(
                metadata_dir,
                "track/ground_truth",
                "GT",
                "tracks",
                {},
                source="machine",
            )

    def test_compliant_write_emits_no_warnings(self, tmp_path):
        """A compliant write produces zero warnings (sentinel for the schema rules)."""
        metadata_dir = tmp_path / "metadata"

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            write_annotation_layer(
                metadata_dir,
                "track/ground_truth",
                "GT",
                "tracks",
                {0: [{"class_name": "x", "bbox": [0, 0, 1, 1], "track_id": 1}]},
                reviewed_frames=[0, 1, 2],
                source="human",
            )
        assert w == [], [str(x.message) for x in w]

    def test_check_layer_schema_directly(self, tmp_path):
        """_check_layer_schema is the underlying validator; round-trip a few cases."""
        # Valid human GT
        assert (
            _check_layer_schema(
                {
                    "layer": "track/ground_truth",
                    "layer_type": "tracks",
                    "source": "human",
                    "reviewed_frames": [0, 1],
                }
            )
            == []
        )

        # Valid machine layer
        assert (
            _check_layer_schema(
                {
                    "layer": "det/yolov8n",
                    "layer_type": "detections",
                    "source": "machine",
                }
            )
            == []
        )

        # Invalid: machine with reviewed_frames
        issues = _check_layer_schema(
            {
                "layer": "det/yolov8n",
                "layer_type": "detections",
                "source": "machine",
                "reviewed_frames": [0],
            }
        )
        assert any("reviewed_frames" in i for i in issues)


class TestReadAnnotationLayerReviewedFrames:
    def test_read_preserves_reviewed_frames(self, tmp_path):
        """read_annotation_layer should return reviewed_frames if present."""
        metadata_dir = tmp_path / "metadata"

        write_annotation_layer(
            metadata_dir,
            "det/ground_truth",
            "Ground Truth",
            "detections",
            {0: [{"class_name": "person", "bbox": [10, 20, 30, 40]}]},
            reviewed_frames=[0, 1, 2],
            source="human",
        )

        data = read_annotation_layer(metadata_dir / "annotations" / "det--ground_truth.json")
        assert data["reviewed_frames"] == [0, 1, 2]
        assert data["source"] == "human"
        assert len(data["frames"]["0"]) == 1

    def test_read_without_reviewed_frames(self, tmp_path):
        """read_annotation_layer should not have reviewed_frames if it wasn't written."""
        metadata_dir = tmp_path / "metadata"

        write_annotation_layer(
            metadata_dir,
            "det/m",
            "M",
            "detections",
            {0: [{"class_name": "car", "bbox": [1, 2, 3, 4]}]},
            source="machine",
        )

        data = read_annotation_layer(metadata_dir / "annotations" / "det--m.json")
        assert "reviewed_frames" not in data
        assert data["source"] == "machine"


class TestListAnnotationLayersReviewedFrames:
    def test_includes_reviewed_frame_count(self, tmp_path):
        """list_annotation_layers should include reviewed_frame_count and source when present."""
        metadata_dir = tmp_path / "metadata"

        write_annotation_layer(
            metadata_dir,
            "det/ground_truth",
            "Ground Truth",
            "detections",
            {0: [{"class_name": "person", "bbox": [10, 20, 30, 40]}]},
            reviewed_frames=[0, 1, 2, 3, 4],
            source="human",
        )

        layers = list_annotation_layers(metadata_dir)
        assert len(layers) == 1
        assert layers[0]["layer"] == "det/ground_truth"
        assert layers[0]["frame_count"] == 5
        assert layers[0]["reviewed_frame_count"] == 5
        assert layers[0]["source"] == "human"

    def test_omits_reviewed_frame_count_when_absent(self, tmp_path):
        """list_annotation_layers should not include reviewed_frame_count for non-human layers."""
        metadata_dir = tmp_path / "metadata"

        write_annotation_layer(
            metadata_dir,
            "det/model",
            "Model",
            "detections",
            {0: [{"class_name": "car", "bbox": [1, 2, 3, 4]}]},
            source="machine",
        )

        layers = list_annotation_layers(metadata_dir)
        assert len(layers) == 1
        assert "reviewed_frame_count" not in layers[0]
        assert layers[0]["source"] == "machine"


class TestStorageAddAnnotationLayerReviewedFrames:
    def test_reviewed_frames_via_storage_api(self, tmp_storage, sample_video):
        """storage.add_annotation_layer() should pass reviewed_frames and source through."""
        asset = tmp_storage.import_video(sample_video, datasource="test")

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="det/ground_truth",
            display_name="Ground Truth",
            layer_type="detections",
            annotations={0: [{"class_name": "person", "bbox": [10, 20, 30, 40]}]},
            reviewed_frames=[0, 1, 2],
            source="human",
        )

        # Verify by reading the raw JSON
        metadata_dir = tmp_storage._metadata_dir_for_asset(asset)
        data = read_annotation_layer(metadata_dir / "annotations" / "det--ground_truth.json")
        assert data["reviewed_frames"] == [0, 1, 2]
        assert data["source"] == "human"

        # Verify layer list includes reviewed_frame_count and source
        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 1
        assert layers[0]["reviewed_frame_count"] == 3
        assert layers[0]["source"] == "human"

    def test_without_reviewed_frames_via_storage_api(self, tmp_storage, sample_video):
        """storage.add_annotation_layer() without reviewed_frames should work as before."""
        asset = tmp_storage.import_video(sample_video, datasource="test")

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="det/test",
            display_name="Test",
            layer_type="detections",
            annotations={0: [{"class_name": "car", "bbox": [1, 2, 3, 4]}]},
            source="machine",
        )

        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 1
        assert "reviewed_frame_count" not in layers[0]
        assert layers[0]["source"] == "machine"
