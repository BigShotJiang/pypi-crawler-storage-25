"""Tests for video reader, annotation store, and video import."""

import subprocess
from pathlib import Path

import orjson
import pytest

from vd3storage.media.annotation_store import (
    filename_to_layer,
    layer_to_filename,
    list_annotation_layers,
    read_annotation_layer,
    read_annotations_for_frame,
    write_annotation_layer,
)
from vd3storage.media.video_metadata import VideoMetadata, probe_video, read_video_metadata, write_video_metadata
from vd3storage.media.video_reader import VideoReader


@pytest.fixture
def sample_video(tmp_path) -> Path:
    """Create a small test video using ffmpeg (5 frames, 10fps, 64x48)."""
    video_path = tmp_path / "test_input.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc=duration=0.5:size=64x48:rate=10",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(video_path),
        ],
        check=True,
        capture_output=True,
    )
    assert video_path.exists()
    return video_path


class TestVideoMetadata:
    def test_probe_video(self, sample_video):
        metadata = probe_video(sample_video)
        assert metadata.width == 64
        assert metadata.height == 48
        assert metadata.fps > 0
        assert metadata.frame_count > 0
        assert metadata.duration_ms > 0
        assert metadata.codec != ""
        assert metadata.source_filename == "test_input.mp4"

    def test_write_and_read(self, tmp_path):
        metadata = VideoMetadata(
            width=1920,
            height=1080,
            fps=29.97,
            frame_count=9000,
            duration_ms=300000,
            codec="h264",
            source_filename="cam01.mp4",
            source_hash="abc123",
        )
        json_path = tmp_path / "video.json"
        write_video_metadata(json_path, metadata)
        assert json_path.exists()

        loaded = read_video_metadata(json_path)
        assert loaded.width == 1920
        assert loaded.height == 1080
        assert loaded.fps == 29.97
        assert loaded.frame_count == 9000
        assert loaded.codec == "h264"
        assert loaded.source_hash == "abc123"

    def test_read_nonexistent_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            read_video_metadata(tmp_path / "nonexistent.json")


class TestVideoReader:
    def test_read_frame(self, sample_video):
        metadata = probe_video(sample_video)
        with VideoReader(sample_video, metadata) as reader:
            assert reader.frame_count > 0
            assert reader.width == 64
            assert reader.height == 48
            assert reader.fps > 0

            data = reader.get_frame(0)
            assert isinstance(data, bytes)
            assert len(data) > 0
            # JPEG starts with FFD8
            assert data[:2] == b"\xff\xd8"

    def test_read_frame_image(self, sample_video):
        metadata = probe_video(sample_video)
        with VideoReader(sample_video, metadata) as reader:
            img = reader.get_frame_image(0)
            assert img.size == (64, 48)

    def test_read_out_of_range_raises(self, sample_video):
        metadata = probe_video(sample_video)
        with VideoReader(sample_video, metadata) as reader, pytest.raises(ValueError, match="out of range"):
            reader.get_frame(9999)

    def test_iter_frames(self, sample_video):
        metadata = probe_video(sample_video)
        with VideoReader(sample_video, metadata) as reader:
            frames = list(reader.iter_frames(start=0, end=3))
            assert len(frames) == 3
            assert frames[0][0] == 0
            assert frames[2][0] == 2
            # Each frame should be JPEG bytes
            for _, data in frames:
                assert data[:2] == b"\xff\xd8"


class TestAnnotationStore:
    def test_layer_to_filename(self):
        assert layer_to_filename("gt") == "gt.json"
        assert layer_to_filename("det/yolov8n") == "det--yolov8n.json"
        assert layer_to_filename("track/bytetrack") == "track--bytetrack.json"

    def test_filename_to_layer(self):
        assert filename_to_layer("gt.json") == "gt"
        assert filename_to_layer("det--yolov8n.json") == "det/yolov8n"
        assert filename_to_layer("track--bytetrack.json") == "track/bytetrack"

    def test_roundtrip(self):
        for layer in ["gt", "det/yolov8n", "track/bytetrack"]:
            assert filename_to_layer(layer_to_filename(layer)) == layer

    def test_write_and_read(self, tmp_path):
        metadata_dir = tmp_path / "metadata" / "videos" / "col1" / "cam01"

        annotations = {
            0: [{"class_name": "person", "track_id": 1, "bbox": [10, 20, 30, 40]}],
            1: [{"class_name": "person", "track_id": 1, "bbox": [11, 21, 31, 41]}],
        }

        json_path = write_annotation_layer(
            metadata_dir,
            layer="gt",
            display_name="Ground Truth",
            layer_type="tracks",
            frames=annotations,
            source="machine",
        )

        assert json_path.exists()
        data = read_annotation_layer(json_path)
        assert data["layer"] == "gt"
        assert data["display_name"] == "Ground Truth"
        assert data["layer_type"] == "tracks"
        assert len(data["frames"]) == 2
        assert data["frames"]["0"][0]["class_name"] == "person"

    def test_list_layers(self, tmp_path):
        metadata_dir = tmp_path / "asset1"

        write_annotation_layer(
            metadata_dir,
            layer="gt",
            display_name="Ground Truth",
            layer_type="tracks",
            frames={0: [{"class_name": "person", "track_id": 1, "bbox": [1, 2, 3, 4]}]},
            source="machine",
        )
        write_annotation_layer(
            metadata_dir,
            layer="det/yolov8n",
            display_name="YOLOv8n",
            layer_type="detections",
            frames={
                0: [{"class_name": "car", "confidence": 0.9, "bbox": [1, 2, 3, 4]}],
                1: [{"class_name": "car", "confidence": 0.8, "bbox": [5, 6, 7, 8]}],
            },
            source="machine",
        )

        layers = list_annotation_layers(metadata_dir)
        assert len(layers) == 2
        layer_names = {la["layer"] for la in layers}
        assert layer_names == {"gt", "det/yolov8n"}

        # Check frame counts
        gt = next(la for la in layers if la["layer"] == "gt")
        det = next(la for la in layers if la["layer"] == "det/yolov8n")
        assert gt["frame_count"] == 1
        assert det["frame_count"] == 2

    def test_list_layers_empty(self, tmp_path):
        assert list_annotation_layers(tmp_path / "nonexistent") == []

    def test_read_frame(self, tmp_path):
        metadata_dir = tmp_path / "asset1"
        write_annotation_layer(
            metadata_dir,
            layer="gt",
            display_name="GT",
            layer_type="tracks",
            frames={
                0: [{"class_name": "person", "track_id": 1, "bbox": [10, 20, 30, 40]}],
                1: [{"class_name": "car", "track_id": 2, "bbox": [50, 60, 70, 80]}],
            },
            source="machine",
        )

        ann = read_annotations_for_frame(metadata_dir, "gt", 0)
        assert ann is not None
        assert ann["frame_number"] == 0
        assert len(ann["objects"]) == 1
        assert ann["objects"][0]["class_name"] == "person"

        # Missing frame
        ann = read_annotations_for_frame(metadata_dir, "gt", 999)
        assert ann is None

        # Missing layer
        ann = read_annotations_for_frame(metadata_dir, "nonexistent", 0)
        assert ann is None


class TestStorageImportVideo:
    def test_import_video(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(sample_video, datasource="test-col")

        assert asset.name == "test_input"  # filename stem
        assert asset.datasource == "test-col"
        assert asset.asset_type == "video"
        assert asset.frame_count > 0
        assert asset.width == 64
        assert asset.height == 48
        assert asset.media_path == "db/media/videos/test-col/test_input.mp4"

        # Verify video file exists
        video_file = tmp_storage.path / asset.media_path
        assert video_file.exists()

        # Verify video.json exists
        metadata_dir = tmp_storage.db_dir / "metadata" / "videos" / "test-col" / "test_input"
        assert (metadata_dir / "video.json").exists()
        data = orjson.loads((metadata_dir / "video.json").read_bytes())
        assert data["width"] == 64
        assert data["height"] == 48

        # Verify frame access
        img = tmp_storage.get_frame_image(asset.asset_id, 0)
        assert img.size == (64, 48)

    def test_import_video_custom_name(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(sample_video, datasource="col1", name="my-video")
        assert asset.name == "my-video"
        assert asset.media_path == "db/media/videos/col1/my-video.mp4"

    def test_import_video_with_metadata(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(
            sample_video,
            datasource="col1",
            sensor_type="rgb",
            environment="urban",
        )
        assert asset.sensor_type == "rgb"
        assert asset.environment == "urban"

    def test_import_duplicate_raises(self, tmp_storage, sample_video):
        tmp_storage.import_video(sample_video, datasource="col1", name="dup")
        with pytest.raises(ValueError, match="already exists"):
            tmp_storage.import_video(sample_video, datasource="col1", name="dup")

    def test_import_nonexistent_raises(self, tmp_storage):
        with pytest.raises(FileNotFoundError):
            tmp_storage.import_video("/nonexistent.mp4", datasource="col1")

    def test_open_video(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(sample_video, datasource="col1")
        with tmp_storage.open_video(asset.asset_id) as reader:
            assert reader.frame_count == asset.frame_count
            assert reader.fps > 0
