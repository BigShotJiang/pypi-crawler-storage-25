"""Tests for VD3 JSON importer and annotation layer operations."""

import subprocess
from pathlib import Path

import orjson
import pytest

from vd3storage.importers.vd3json import parse_vd3_json


@pytest.fixture
def sample_video(tmp_path) -> Path:
    """Create a small test video using ffmpeg."""
    video_path = tmp_path / "test_input.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc=duration=0.5:size=64x48:rate=10",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            str(video_path),
        ],
        check=True,
        capture_output=True,
    )
    return video_path


@pytest.fixture
def vd3_json_file(tmp_path) -> Path:
    """Create a sample VD3 JSON result file with detections + tracks."""
    data = {
        "layers": [
            {
                "layer": "det/yolov8n",
                "display_name": "YOLOv8n Detections",
                "layer_type": "detections",
                "frames": {
                    "0": [
                        {"class_name": "person", "confidence": 0.92, "bbox": [10, 20, 30, 40]},
                        {"class_name": "vehicle", "confidence": 0.87, "bbox": [40, 30, 60, 50]},
                    ],
                    "1": [
                        {"class_name": "person", "confidence": 0.88, "bbox": [11, 21, 31, 41]},
                    ],
                },
            },
            {
                "layer": "track/bytetrack",
                "display_name": "ByteTrack",
                "layer_type": "tracks",
                "frames": {
                    "0": [
                        {"class_name": "person", "track_id": 1, "bbox": [10, 20, 30, 40]},
                    ],
                    "1": [
                        {"class_name": "person", "track_id": 1, "bbox": [11, 21, 31, 41]},
                    ],
                },
            },
        ]
    }
    path = tmp_path / "results.vd3.json"
    path.write_bytes(orjson.dumps(data))
    return path


class TestParseVD3Json:
    def test_parse_multi_layer(self, vd3_json_file):
        layers = parse_vd3_json(vd3_json_file)
        assert len(layers) == 2

        det = layers[0]
        assert det.layer == "det/yolov8n"
        assert det.display_name == "YOLOv8n Detections"
        assert det.layer_type == "detections"
        assert len(det.frames) == 2
        assert len(det.frames[0]) == 2  # 2 objects in frame 0
        assert det.frames[0][0]["class_name"] == "person"

        track = layers[1]
        assert track.layer == "track/bytetrack"
        assert track.layer_type == "tracks"
        assert track.frames[0][0]["track_id"] == 1

    def test_parse_nonexistent_raises(self):
        with pytest.raises(FileNotFoundError):
            parse_vd3_json("/nonexistent.vd3.json")

    def test_parse_invalid_format_raises(self, tmp_path):
        bad = tmp_path / "bad.json"
        bad.write_bytes(orjson.dumps({"not_layers": []}))
        with pytest.raises(ValueError, match="expected top-level 'layers'"):
            parse_vd3_json(bad)

    def test_parse_missing_class_name_raises(self, tmp_path):
        bad = tmp_path / "bad.json"
        bad.write_bytes(
            orjson.dumps(
                {
                    "layers": [
                        {
                            "layer": "test",
                            "layer_type": "detections",
                            "frames": {"0": [{"bbox": [1, 2, 3, 4]}]},
                        }
                    ]
                }
            )
        )
        with pytest.raises(ValueError, match="missing 'class_name'"):
            parse_vd3_json(bad)

    def test_parse_invalid_bbox_raises(self, tmp_path):
        bad = tmp_path / "bad.json"
        bad.write_bytes(
            orjson.dumps(
                {
                    "layers": [
                        {
                            "layer": "test",
                            "layer_type": "detections",
                            "frames": {"0": [{"class_name": "x", "bbox": [1, 2]}]},
                        }
                    ]
                }
            )
        )
        with pytest.raises(ValueError, match="bbox"):
            parse_vd3_json(bad)


class TestAddAnnotationLayer:
    def test_add_and_read_annotations(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(sample_video, datasource="col1")

        # Add ground truth annotations
        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="gt",
            display_name="Ground Truth",
            layer_type="tracks",
            annotations={
                0: [{"class_name": "person", "track_id": 1, "bbox": [10, 20, 30, 40]}],
                1: [{"class_name": "person", "track_id": 1, "bbox": [11, 21, 31, 41]}],
            },
            source="machine",
        )

        # Verify annotations are readable
        ann = tmp_storage.get_annotations(asset.asset_id, "gt", 0)
        assert ann is not None
        assert len(ann["objects"]) == 1
        assert ann["objects"][0]["class_name"] == "person"
        assert ann["objects"][0]["track_id"] == 1

    def test_list_annotation_layers(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(sample_video, datasource="col1")

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="gt",
            display_name="Ground Truth",
            layer_type="tracks",
            annotations={0: [{"class_name": "person", "track_id": 1, "bbox": [10, 20, 30, 40]}]},
            source="machine",
        )

        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 1
        assert layers[0]["layer"] == "gt"
        assert layers[0]["display_name"] == "Ground Truth"
        assert layers[0]["layer_type"] == "tracks"
        assert layers[0]["frame_count"] == 1

    def test_denormalized_cache_persists(self, tmp_storage, sample_video):
        """Verify that annotation_layers_json is persisted to CSV."""
        asset = tmp_storage.import_video(sample_video, datasource="col1")

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="det/yolov8n",
            display_name="YOLOv8n",
            layer_type="detections",
            annotations={0: [{"class_name": "car", "confidence": 0.9, "bbox": [1, 2, 3, 4]}]},
            source="machine",
        )

        # Save and reload
        tmp_storage.save()
        tmp_storage.reload()

        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 1
        assert layers[0]["layer"] == "det/yolov8n"

    def test_add_multiple_layers(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(sample_video, datasource="col1")

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="gt",
            display_name="Ground Truth",
            layer_type="tracks",
            annotations={0: [{"class_name": "person", "track_id": 1, "bbox": [10, 20, 30, 40]}]},
            source="machine",
        )

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="det/yolov8n",
            display_name="YOLOv8n",
            layer_type="detections",
            annotations={0: [{"class_name": "person", "confidence": 0.9, "bbox": [10, 20, 30, 40]}]},
            source="machine",
        )

        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 2
        layer_names = {la["layer"] for la in layers}
        assert layer_names == {"gt", "det/yolov8n"}

    def test_original_frames_preserved(self, tmp_storage, sample_video):
        """Adding annotations should not corrupt the video frames."""
        asset = tmp_storage.import_video(sample_video, datasource="col1")
        original_frame_count = asset.frame_count

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="gt",
            display_name="GT",
            layer_type="detections",
            annotations={0: [{"class_name": "x", "bbox": [1, 2, 3, 4]}]},
            source="machine",
        )

        # Verify frames still readable
        with tmp_storage.open_video(asset.asset_id) as reader:
            assert reader.frame_count == original_frame_count
            img = reader.get_frame_image(0)
            assert img.size[0] > 0


class TestImportResult:
    def test_import_vd3_json(self, tmp_storage, sample_video, vd3_json_file):
        asset = tmp_storage.import_video(sample_video, datasource="col1")

        imported = tmp_storage.import_result(asset.asset_id, vd3_json_file)
        assert len(imported) == 2

        # Verify both layers are readable
        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 2

        # Verify detection annotations
        ann = tmp_storage.get_annotations(asset.asset_id, "det/yolov8n", 0)
        assert ann is not None
        assert len(ann["objects"]) == 2
        assert ann["objects"][0]["confidence"] == 0.92

        # Verify track annotations
        ann = tmp_storage.get_annotations(asset.asset_id, "track/bytetrack", 0)
        assert ann is not None
        assert ann["objects"][0]["track_id"] == 1

    def test_import_nonexistent_result_raises(self, tmp_storage, sample_video):
        asset = tmp_storage.import_video(sample_video, datasource="col1")
        with pytest.raises(FileNotFoundError):
            tmp_storage.import_result(asset.asset_id, "/nonexistent.vd3.json")

    def test_import_result_nonexistent_asset_raises(self, tmp_storage, tmp_path):
        fake_json = tmp_path / "fake.vd3.json"
        fake_json.write_bytes(orjson.dumps({"layers": []}))
        with pytest.raises(ValueError, match="Asset not found"):
            tmp_storage.import_result("nonexistent-id", fake_json)
