"""Tests for VD3Storage — init, CRUD, persistence, worksets."""

import pytest

from vd3storage import VD3Storage
from vd3storage.storage import AlreadyInitializedError


class TestInit:
    def test_init_creates_structure(self, tmp_path):
        db_path = tmp_path / "test-db"
        storage = VD3Storage.init(db_path, git_init=False, dvc_init=False)

        assert (db_path / "db" / "tables" / "assets.csv").exists()
        assert (db_path / "db" / "tables" / "tags.csv").exists()
        assert (db_path / "db" / "tables" / "worksets.csv").exists()
        assert (db_path / "db" / "tables" / "workset_assets.csv").exists()
        assert (db_path / "db" / "tables" / ".schema_version").exists()
        assert (db_path / "db" / "media" / "videos").is_dir()
        assert (db_path / "db" / "media" / "imagesets").is_dir()
        assert (db_path / "db" / "metadata" / "videos").is_dir()
        assert (db_path / "db" / "metadata" / "imagesets").is_dir()
        assert (db_path / "pyproject.toml").exists()
        assert (db_path / ".gitignore").exists()
        assert (db_path / "README.md").exists()

        storage._engine.close()

    def test_init_dev_mode(self, tmp_path):
        db_path = tmp_path / "test-db"
        storage = VD3Storage.init(db_path, git_init=False, dvc_init=False, dev=True)

        pyproject = (db_path / "pyproject.toml").read_text()
        assert "[tool.uv.sources]" in pyproject
        assert "editable = true" in pyproject

        storage._engine.close()

    def test_open_existing(self, tmp_path):
        db_path = tmp_path / "test-db"
        s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
        s1.add_asset("cam01.mp4", "col1")
        s1.save()
        s1._engine.close()

        s2 = VD3Storage(db_path)
        assets = s2.list_assets()
        assert len(assets) == 1
        assert assets[0].name == "cam01.mp4"
        s2._engine.close()

    def test_init_existing_db_raises(self, tmp_path):
        """Re-initializing an existing database should raise AlreadyInitializedError."""
        db_path = tmp_path / "test-db"
        s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
        s1._engine.close()

        with pytest.raises(AlreadyInitializedError, match="already initialized"):
            VD3Storage.init(db_path, git_init=False, dvc_init=False)

    def test_init_existing_db_lists_artifacts(self, tmp_path):
        """Error message should list which artifacts already exist."""
        db_path = tmp_path / "test-db"
        s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
        s1._engine.close()

        with pytest.raises(AlreadyInitializedError, match="db/tables/"):
            VD3Storage.init(db_path, git_init=False, dvc_init=False)

    def test_init_existing_dvc_raises(self, tmp_path):
        """Directory with only .dvc/ should still be detected."""
        db_path = tmp_path / "test-db"
        db_path.mkdir()
        (db_path / ".dvc").mkdir()

        with pytest.raises(AlreadyInitializedError, match=".dvc/"):
            VD3Storage.init(db_path, git_init=False, dvc_init=False)

    def test_init_existing_git_raises_when_git_init_requested(self, tmp_path):
        """Directory with .git/ should be detected only when git_init=True."""
        db_path = tmp_path / "test-db"
        db_path.mkdir()
        (db_path / ".git").mkdir()

        with pytest.raises(AlreadyInitializedError, match=".git/"):
            VD3Storage.init(db_path, git_init=True, dvc_init=False)

    def test_init_existing_git_ignored_when_git_init_false(self, tmp_path):
        """Directory with .git/ should NOT be flagged when git_init=False."""
        db_path = tmp_path / "test-db"
        db_path.mkdir()
        (db_path / ".git").mkdir()

        storage = VD3Storage.init(db_path, git_init=False, dvc_init=False)
        storage._engine.close()

    def test_init_force_reinitializes(self, tmp_path):
        """--force should allow reinitializing an existing database."""
        db_path = tmp_path / "test-db"
        s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
        s1.add_asset("old_asset.mp4", "col1")
        s1.save()
        s1._engine.close()

        s2 = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
        assert len(s2.list_assets()) == 0
        s2._engine.close()

    def test_init_force_removes_dvc(self, tmp_path):
        """--force should remove existing .dvc/ directory."""
        db_path = tmp_path / "test-db"
        db_path.mkdir()
        dvc_dir = db_path / ".dvc"
        dvc_dir.mkdir()
        (dvc_dir / "config").write_text("[core]\n")

        storage = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
        assert not (db_path / ".dvc").exists()
        storage._engine.close()

    def test_init_force_preserves_git(self, tmp_path):
        """--force should NOT remove .git/ (too destructive)."""
        db_path = tmp_path / "test-db"
        db_path.mkdir()
        git_dir = db_path / ".git"
        git_dir.mkdir()
        (git_dir / "HEAD").write_text("ref: refs/heads/main\n")

        storage = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
        assert (db_path / ".git").exists()
        assert (db_path / ".git" / "HEAD").exists()
        storage._engine.close()

    def test_init_existing_pyproject_raises(self, tmp_path):
        """A pre-existing pyproject.toml should block init without --force."""
        db_path = tmp_path / "test-db"
        db_path.mkdir()
        (db_path / "pyproject.toml").write_text("[project]\nname = 'custom'\n")

        with pytest.raises(AlreadyInitializedError, match="pyproject.toml"):
            VD3Storage.init(db_path, git_init=False, dvc_init=False)

    def test_init_existing_gitignore_raises(self, tmp_path):
        """A pre-existing .gitignore should block init without --force."""
        db_path = tmp_path / "test-db"
        db_path.mkdir()
        (db_path / ".gitignore").write_text("*.log\n")

        with pytest.raises(AlreadyInitializedError, match=".gitignore"):
            VD3Storage.init(db_path, git_init=False, dvc_init=False)

    def test_init_force_overwrites_generated_files(self, tmp_path):
        """--force should remove and regenerate pyproject.toml, .gitignore, README.md, src/example.py."""
        db_path = tmp_path / "test-db"
        s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
        s1._engine.close()

        # Modify pyproject.toml to prove it gets regenerated
        pyproject = db_path / "pyproject.toml"
        pyproject.write_text("[project]\nname = 'tampered'\n")

        s2 = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
        s2._engine.close()

        # Should be regenerated, not the tampered version
        content = pyproject.read_text()
        assert "tampered" not in content
        assert "vd3" in content.lower()

    def test_open_nonexistent_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            VD3Storage(tmp_path / "does-not-exist")

    def test_open_invalid_raises(self, tmp_path):
        (tmp_path / "not-a-db").mkdir()
        with pytest.raises(ValueError, match="Not a valid"):
            VD3Storage(tmp_path / "not-a-db")


class TestAssetCRUD:
    def test_add_and_get(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024", sensor_type="rgb")
        found = tmp_storage.get_asset("dashcam-2024", "cam01.mp4")
        assert found is not None
        assert found.asset_id == asset.asset_id

    def test_get_by_id(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024")
        found = tmp_storage.get_asset_by_id(asset.asset_id)
        assert found is not None
        assert found.name == "cam01.mp4"

    def test_list_all(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_asset("cam02.mp4", "col2")
        assert len(tmp_storage.list_assets()) == 2

    def test_list_by_datasource(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_asset("cam02.mp4", "col2")
        assert len(tmp_storage.list_assets(datasource="col1")) == 1

    def test_update(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        asset.frame_count = 9000
        tmp_storage.update_asset(asset)
        found = tmp_storage.get_asset_by_id(asset.asset_id)
        assert found.frame_count == 9000

    def test_delete(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.delete_asset(asset.asset_id)
        assert tmp_storage.get_asset_by_id(asset.asset_id) is None

    def test_delete_nonexistent_raises(self, tmp_storage):
        with pytest.raises(ValueError, match="Asset not found"):
            tmp_storage.delete_asset("nonexistent-id")


class TestDatasourceDescription:
    def test_default_description_empty(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "dashcam")
        assert tmp_storage.get_datasource_description("dashcam") == ""

    def test_set_and_get(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "dashcam")
        tmp_storage.set_datasource_description("dashcam", "Forward-facing dashcam clips from 2024")
        assert tmp_storage.get_datasource_description("dashcam") == "Forward-facing dashcam clips from 2024"

    def test_set_overwrites_existing(self, tmp_storage):
        tmp_storage.set_datasource_description("dashcam", "first")
        tmp_storage.set_datasource_description("dashcam", "second")
        assert tmp_storage.get_datasource_description("dashcam") == "second"

    def test_set_before_any_asset_exists(self, tmp_storage):
        tmp_storage.set_datasource_description("future-ds", "Reserved for later imports")
        assert tmp_storage.get_datasource_description("future-ds") == "Reserved for later imports"

    def test_list_datasources_includes_description(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "dashcam")
        tmp_storage.add_asset("cam02.mp4", "dashcam")
        tmp_storage.add_asset("img01.jpg", "imageset-ds")
        tmp_storage.set_datasource_description("dashcam", "Forward-facing 2024")

        rows = tmp_storage.list_datasources()
        by_name = {r["name"]: r for r in rows}
        assert by_name["dashcam"]["description"] == "Forward-facing 2024"
        assert by_name["dashcam"]["asset_count"] == 2
        assert by_name["imageset-ds"]["description"] == ""
        assert by_name["imageset-ds"]["asset_count"] == 1

    def test_list_datasources_includes_described_but_unpopulated(self, tmp_storage):
        """A description set before any assets are added still surfaces in list_datasources."""
        tmp_storage.set_datasource_description("future-ds", "Reserved for later")
        rows = tmp_storage.list_datasources()
        by_name = {r["name"]: r for r in rows}
        assert by_name["future-ds"]["description"] == "Reserved for later"
        assert by_name["future-ds"]["asset_count"] == 0


class TestTags:
    def test_add_and_get_tags(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_tag(asset.asset_id, "split:training")
        tmp_storage.add_tag(asset.asset_id, "scene:urban")
        tags = tmp_storage.get_tags(asset.asset_id)
        assert set(tags) == {"split:training", "scene:urban"}

    def test_remove_tag(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_tag(asset.asset_id, "split:training")
        tmp_storage.remove_tag(asset.asset_id, "split:training")
        assert tmp_storage.get_tags(asset.asset_id) == []

    def test_delete_asset_removes_tags(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_tag(asset.asset_id, "split:training")
        tmp_storage.delete_asset(asset.asset_id)
        assert tmp_storage.get_tags(asset.asset_id) == []

    def test_unprefixed_tag_warns(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        with pytest.warns(DeprecationWarning, match="Unprefixed tag"):
            tmp_storage.add_tag(asset.asset_id, "training")
        # Warning is informational, not a reject — the tag still lands.
        assert tmp_storage.get_tags(asset.asset_id) == ["training"]

    def test_namespaced_tag_silent(self, tmp_storage):
        import warnings

        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        with warnings.catch_warnings():
            warnings.simplefilter("error")  # any warning fails the test
            tmp_storage.add_tag(asset.asset_id, "review:rejected")


class TestWorksets:
    def test_create_and_get(self, tmp_storage):
        ws = tmp_storage.create_workset("My Project")
        found = tmp_storage.get_workset("my-project")
        assert found is not None
        assert found.workset_id == ws.workset_id
        assert found.name == "My Project"

    def test_create_custom_slug(self, tmp_storage):
        ws = tmp_storage.create_workset("My Project", slug="custom-slug")
        assert ws.slug == "custom-slug"

    def test_create_duplicate_raises(self, tmp_storage):
        tmp_storage.create_workset("My Project", slug="my-project")
        with pytest.raises(ValueError, match="already exists"):
            tmp_storage.create_workset("Another", slug="my-project")

    def test_list(self, tmp_storage):
        tmp_storage.create_workset("Alpha")
        tmp_storage.create_workset("Beta")
        worksets = tmp_storage.list_worksets()
        assert len(worksets) == 2
        assert worksets[0].name == "Alpha"  # Ordered by name

    def test_delete(self, tmp_storage):
        ws = tmp_storage.create_workset("To Delete")
        tmp_storage.delete_workset(ws.workset_id)
        assert tmp_storage.get_workset("to-delete") is None


class TestWorksetAssets:
    def test_add_and_list(self, tmp_storage):
        ws = tmp_storage.create_workset("Project")
        a1 = tmp_storage.add_asset("cam01.mp4", "col1")
        a2 = tmp_storage.add_asset("cam02.mp4", "col1")
        tmp_storage.add_asset_to_workset(ws.workset_id, a1.asset_id, package="training")
        tmp_storage.add_asset_to_workset(ws.workset_id, a2.asset_id, package="evaluation")

        all_assets = tmp_storage.list_workset_assets(ws.workset_id)
        assert len(all_assets) == 2

        training = tmp_storage.list_workset_assets(ws.workset_id, package="training")
        assert len(training) == 1
        assert training[0].name == "cam01.mp4"

    def test_list_packages(self, tmp_storage):
        ws = tmp_storage.create_workset("Project")
        a1 = tmp_storage.add_asset("cam01.mp4", "col1")
        a2 = tmp_storage.add_asset("cam02.mp4", "col1")
        tmp_storage.add_asset_to_workset(ws.workset_id, a1.asset_id, package="training/urban")
        tmp_storage.add_asset_to_workset(ws.workset_id, a2.asset_id, package="evaluation")

        packages = tmp_storage.list_workset_packages(ws.workset_id)
        assert set(packages) == {"training/urban", "evaluation"}

    def test_remove_from_workset(self, tmp_storage):
        ws = tmp_storage.create_workset("Project")
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_asset_to_workset(ws.workset_id, asset.asset_id)
        tmp_storage.remove_asset_from_workset(ws.workset_id, asset.asset_id)
        assert len(tmp_storage.list_workset_assets(ws.workset_id)) == 0

    def test_delete_workset_removes_memberships(self, tmp_storage):
        ws = tmp_storage.create_workset("Project")
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_asset_to_workset(ws.workset_id, asset.asset_id)
        tmp_storage.delete_workset(ws.workset_id)
        # Asset still exists globally
        assert tmp_storage.get_asset_by_id(asset.asset_id) is not None

    def test_asset_in_multiple_worksets(self, tmp_storage):
        ws1 = tmp_storage.create_workset("Project A")
        ws2 = tmp_storage.create_workset("Project B")
        asset = tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_asset_to_workset(ws1.workset_id, asset.asset_id, package="training")
        tmp_storage.add_asset_to_workset(ws2.workset_id, asset.asset_id, package="eval/set1")

        assert len(tmp_storage.list_workset_assets(ws1.workset_id)) == 1
        assert len(tmp_storage.list_workset_assets(ws2.workset_id)) == 1


class TestPersistence:
    def test_save_and_reload(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.save()
        tmp_storage.reload()
        assert len(tmp_storage.list_assets()) == 1

    def test_context_manager(self, tmp_path):
        db_path = tmp_path / "ctx-db"
        VD3Storage.init(db_path, git_init=False, dvc_init=False)._engine.close()

        with VD3Storage(db_path) as storage:
            storage.add_asset("cam01.mp4", "col1")

        # Re-open and verify it was saved
        with VD3Storage(db_path) as storage:
            assert len(storage.list_assets()) == 1
