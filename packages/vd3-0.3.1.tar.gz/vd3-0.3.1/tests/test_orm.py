"""Tests for the DuckDB ORM layer."""

from vd3storage.models import Asset
from vd3storage.orm.engine import _EMPTY_QUOTED_FIELD_RE, _normalize_empty_fields


class TestEngine:
    def test_register_and_flush(self, tmp_storage):
        """Tables should be registered and flushable."""
        # The fixture already initialized tables
        csv_path = tmp_storage.tables_dir / "assets.csv"
        assert csv_path.exists()
        assert csv_path.stat().st_size > 0  # Has at least headers

    def test_execute_sql(self, tmp_storage):
        """Should be able to execute raw SQL."""
        result = tmp_storage.execute_sql("SELECT COUNT(*) AS cnt FROM assets")
        assert result == [{"cnt": 0}]

    def test_flush_writes_unquoted_empty_fields(self, tmp_storage):
        """Empty string fields should serialize as `,,`, not `,"",`.

        DuckDB's COPY writes empty strings as quoted empties and NULL as
        unquoted; read_csv_auto collapses both back to NULL on reload, so the
        on-disk distinction is meaningless. We normalize to unquoted to keep
        the CSV byte-stable across read/modify/write cycles.
        """
        # add_asset uses the model's "" defaults for camera_id, video_id, etc.
        tmp_storage.add_asset("clip1.mp4", "ds1")
        tmp_storage.save()
        csv_text = (tmp_storage.tables_dir / "assets.csv").read_text()
        # No standalone empty quoted fields anywhere in the output
        assert ',""' not in csv_text.replace(',""""', "")  # ignore JSON-internal `""""` escapes
        assert '"",' not in csv_text.replace('"""",', "")

    def test_flush_is_idempotent(self, tmp_storage):
        """Two consecutive flushes should produce identical bytes."""
        tmp_storage.add_asset("clip1.mp4", "ds1", camera_id="cam01")
        tmp_storage.add_asset("clip2.mp4", "ds1")  # leaves camera_id, etc. empty
        tmp_storage.save()
        first = (tmp_storage.tables_dir / "assets.csv").read_bytes()
        tmp_storage.save()
        second = (tmp_storage.tables_dir / "assets.csv").read_bytes()
        assert first == second


class TestNormalizeEmptyFields:
    """Direct tests for the post-COPY CSV normalizer."""

    def test_strips_standalone_empty_quoted_fields(self, tmp_path):
        csv = tmp_path / "x.csv"
        csv.write_text('a,b,c\n1,"",hello\n"",world,""\n')
        _normalize_empty_fields(csv)
        assert csv.read_text() == "a,b,c\n1,,hello\n,world,\n"

    def test_preserves_escaped_quotes_inside_quoted_fields(self, tmp_path):
        # A `""` pair inside a larger quoted field is a CSV-escaped literal
        # quote character, not an empty field. Field value `foo"bar` encodes
        # as `"foo""bar"` — the normalizer must leave it alone.
        csv = tmp_path / "x.csv"
        csv.write_text('a,b\n1,"foo""bar"\n')
        _normalize_empty_fields(csv)
        assert csv.read_text() == 'a,b\n1,"foo""bar"\n'

    def test_preserves_json_with_empty_string_values(self, tmp_path):
        # JSON like {"k":""} encodes to CSV as "{""k"":""""}" — the four-quote
        # run in the middle is two escape sequences, not an empty field.
        csv = tmp_path / "x.csv"
        csv.write_text('a,b\n1,"{""k"":""""}"\n')
        _normalize_empty_fields(csv)
        assert csv.read_text() == 'a,b\n1,"{""k"":""""}"\n'

    def test_no_op_when_already_normalized(self, tmp_path):
        # Don't rewrite the file if nothing changed — keeps mtime stable.
        csv = tmp_path / "x.csv"
        original = "a,b,c\n1,,hello\n,world,\n"
        csv.write_text(original)
        mtime_before = csv.stat().st_mtime_ns
        _normalize_empty_fields(csv)
        assert csv.read_text() == original
        assert csv.stat().st_mtime_ns == mtime_before

    def test_regex_rejects_partial_matches(self):
        """Sanity check on the boundary anchors."""
        # standalone empty fields → match
        assert _EMPTY_QUOTED_FIELD_RE.search(',"",') is not None
        assert _EMPTY_QUOTED_FIELD_RE.search('"",') is not None
        assert _EMPTY_QUOTED_FIELD_RE.search(',""') is not None
        # `""` inside a longer quoted field → no match
        assert _EMPTY_QUOTED_FIELD_RE.search('"foo""bar"') is None
        # 4-quote escape (literal `""` inside a quoted field) → no match
        assert _EMPTY_QUOTED_FIELD_RE.search('"{""k"":""""}"') is None


class TestTable:
    def test_insert_and_query(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024", sensor_type="rgb")
        found = tmp_storage.get_asset("dashcam-2024", "cam01.mp4")
        assert found is not None
        assert found.asset_id == asset.asset_id
        assert found.sensor_type == "rgb"

    def test_update(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024")
        asset.sensor_type = "thermal"
        tmp_storage.update_asset(asset)
        found = tmp_storage.get_asset("dashcam-2024", "cam01.mp4")
        assert found.sensor_type == "thermal"

    def test_delete(self, tmp_storage):
        asset = tmp_storage.add_asset("cam01.mp4", "dashcam-2024")
        tmp_storage.delete_asset(asset.asset_id)
        found = tmp_storage.get_asset("dashcam-2024", "cam01.mp4")
        assert found is None


class TestQuery:
    def test_filter(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "dashcam-2024", environment="urban")
        tmp_storage.add_asset("cam02.mp4", "dashcam-2024", environment="rural")
        tmp_storage.add_asset("cam03.mp4", "drone-2024", environment="urban")

        urban = tmp_storage.query(Asset).filter(environment="urban").all()
        assert len(urban) == 2

        dashcam = tmp_storage.query(Asset).filter(datasource="dashcam-2024").all()
        assert len(dashcam) == 2

    def test_filter_sql(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "col1", frame_count=100)
        tmp_storage.add_asset("cam02.mp4", "col1", frame_count=5000)
        tmp_storage.add_asset("cam03.mp4", "col1", frame_count=10000)

        large = tmp_storage.query(Asset).filter_sql('"frame_count" > ?', 1000).all()
        assert len(large) == 2

    def test_order_by(self, tmp_storage):
        tmp_storage.add_asset("bravo.mp4", "col1")
        tmp_storage.add_asset("alpha.mp4", "col1")
        tmp_storage.add_asset("charlie.mp4", "col1")

        assets = tmp_storage.query(Asset).order_by("name").all()
        assert [a.name for a in assets] == ["alpha.mp4", "bravo.mp4", "charlie.mp4"]

    def test_limit_offset(self, tmp_storage):
        for i in range(10):
            tmp_storage.add_asset(f"cam{i:02d}.mp4", "col1")

        page = tmp_storage.query(Asset).order_by("name").limit(3).offset(2).all()
        assert len(page) == 3
        assert page[0].name == "cam02.mp4"

    def test_count(self, tmp_storage):
        tmp_storage.add_asset("cam01.mp4", "col1")
        tmp_storage.add_asset("cam02.mp4", "col1")
        assert tmp_storage.query(Asset).count() == 2
        assert tmp_storage.query(Asset).filter(name="cam01.mp4").count() == 1
