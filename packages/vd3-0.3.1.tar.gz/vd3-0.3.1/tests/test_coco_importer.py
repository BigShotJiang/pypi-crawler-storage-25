"""Tests for COCO annotation importer."""

from pathlib import Path

import orjson
import pytest
from PIL import Image

from vd3storage.importers.coco import parse_coco_json
from vd3storage.media.imageset_metadata import scan_imageset


@pytest.fixture
def sample_images(tmp_path) -> Path:
    """Create a directory with 3 test images."""
    img_dir = tmp_path / "images"
    img_dir.mkdir()
    Image.new("RGB", (640, 480)).save(img_dir / "img_001.jpg")
    Image.new("RGB", (640, 480)).save(img_dir / "img_002.jpg")
    Image.new("RGB", (800, 600)).save(img_dir / "img_003.jpg")
    return img_dir


@pytest.fixture
def nested_images(tmp_path) -> Path:
    """Create a nested directory with images in subdirectories."""
    img_dir = tmp_path / "nested"
    img_dir.mkdir()
    (img_dir / "cam01").mkdir()
    (img_dir / "cam02").mkdir()
    Image.new("RGB", (640, 480)).save(img_dir / "cam01" / "frame_001.jpg")
    Image.new("RGB", (640, 480)).save(img_dir / "cam01" / "frame_002.jpg")
    Image.new("RGB", (800, 600)).save(img_dir / "cam02" / "frame_001.jpg")
    return img_dir


@pytest.fixture
def coco_json(tmp_path, sample_images) -> Path:
    """Create a COCO JSON file matching the sample_images fixture."""
    data = {
        "images": [
            {"id": 1, "file_name": "img_001.jpg", "width": 640, "height": 480},
            {"id": 2, "file_name": "img_002.jpg", "width": 640, "height": 480},
            {"id": 3, "file_name": "img_003.jpg", "width": 800, "height": 600},
        ],
        "annotations": [
            {"id": 1, "image_id": 1, "category_id": 1, "bbox": [10, 20, 100, 200]},
            {"id": 2, "image_id": 1, "category_id": 2, "bbox": [50, 60, 80, 90]},
            {"id": 3, "image_id": 2, "category_id": 1, "bbox": [15, 25, 110, 210], "score": 0.95},
            {"id": 4, "image_id": 3, "category_id": 3, "bbox": [0, 0, 50, 50], "iscrowd": 1},
        ],
        "categories": [
            {"id": 1, "name": "person"},
            {"id": 2, "name": "car"},
            {"id": 3, "name": "bicycle"},
        ],
    }
    path = tmp_path / "annotations.json"
    path.write_bytes(orjson.dumps(data))
    return path


class TestParseCoco:
    def test_basic_import(self, coco_json, sample_images):
        metadata = scan_imageset(sample_images)
        layer = parse_coco_json(coco_json, metadata)

        assert layer.layer == "gt"
        assert layer.display_name == "COCO Annotations"
        assert layer.layer_type == "detections"
        assert len(layer.frames) == 3  # 3 images with annotations

        # Frame 0 (img_001.jpg) should have 2 annotations
        assert len(layer.frames[0]) == 2
        assert layer.frames[0][0]["class_name"] == "person"
        assert layer.frames[0][1]["class_name"] == "car"

        # Frame 1 (img_002.jpg) should have 1 annotation with confidence
        assert len(layer.frames[1]) == 1
        assert layer.frames[1][0]["confidence"] == 0.95

    def test_bbox_conversion(self, coco_json, sample_images):
        """COCO [x, y, w, h] should convert to VD3 [xmin, ymin, xmax, ymax]."""
        metadata = scan_imageset(sample_images)
        layer = parse_coco_json(coco_json, metadata)

        # First annotation: COCO bbox [10, 20, 100, 200] -> VD3 [10, 20, 110, 220]
        bbox = layer.frames[0][0]["bbox"]
        assert bbox == [10, 20, 110, 220]

    def test_preserves_optional_fields(self, coco_json, sample_images):
        metadata = scan_imageset(sample_images)
        layer = parse_coco_json(coco_json, metadata)

        # Frame 2 has iscrowd field
        assert layer.frames[2][0].get("iscrowd") == 1

        # Frame 1 has score -> confidence
        assert layer.frames[1][0]["confidence"] == 0.95

    def test_custom_layer_name(self, coco_json, sample_images):
        metadata = scan_imageset(sample_images)
        layer = parse_coco_json(coco_json, metadata, layer="det/coco-v1", display_name="COCO v1 Detections")
        assert layer.layer == "det/coco-v1"
        assert layer.display_name == "COCO v1 Detections"

    def test_basename_matching(self, tmp_path, sample_images):
        """COCO file_names with paths should fall back to basename match."""
        metadata = scan_imageset(sample_images)

        # COCO references images with a path prefix that doesn't exist in the imageset
        data = {
            "images": [
                {"id": 1, "file_name": "some/path/img_001.jpg", "width": 640, "height": 480},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [10, 20, 30, 40]},
            ],
            "categories": [{"id": 1, "name": "person"}],
        }
        coco_path = tmp_path / "basename_test.json"
        coco_path.write_bytes(orjson.dumps(data))

        layer = parse_coco_json(coco_path, metadata)
        assert len(layer.frames) == 1
        assert 0 in layer.frames  # img_001.jpg is frame 0

    def test_relative_path_matching(self, tmp_path, nested_images):
        """COCO file_names with relative paths should match nested imageset structure."""
        metadata = scan_imageset(nested_images)

        data = {
            "images": [
                {"id": 1, "file_name": "cam01/frame_001.jpg", "width": 640, "height": 480},
                {"id": 2, "file_name": "cam02/frame_001.jpg", "width": 800, "height": 600},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [10, 20, 30, 40]},
                {"id": 2, "image_id": 2, "category_id": 1, "bbox": [50, 60, 70, 80]},
            ],
            "categories": [{"id": 1, "name": "person"}],
        }
        coco_path = tmp_path / "nested_test.json"
        coco_path.write_bytes(orjson.dumps(data))

        layer = parse_coco_json(coco_path, metadata)
        assert len(layer.frames) == 2

    def test_ambiguous_basename_skipped(self, tmp_path, nested_images):
        """Basename 'frame_001.jpg' exists in both cam01/ and cam02/ — should not match by basename."""
        metadata = scan_imageset(nested_images)

        # Reference by basename only — ambiguous because frame_001.jpg exists in two subdirs
        data = {
            "images": [
                {"id": 1, "file_name": "frame_001.jpg", "width": 640, "height": 480},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [10, 20, 30, 40]},
            ],
            "categories": [{"id": 1, "name": "person"}],
        }
        coco_path = tmp_path / "ambiguous.json"
        coco_path.write_bytes(orjson.dumps(data))

        # Should raise because the only image is unmatched
        with pytest.raises(ValueError, match="No COCO images could be matched"):
            parse_coco_json(coco_path, metadata)

    def test_no_images_matched_raises(self, tmp_path, sample_images):
        metadata = scan_imageset(sample_images)
        data = {
            "images": [{"id": 1, "file_name": "nonexistent.jpg", "width": 640, "height": 480}],
            "annotations": [],
            "categories": [],
        }
        coco_path = tmp_path / "no_match.json"
        coco_path.write_bytes(orjson.dumps(data))

        with pytest.raises(ValueError, match="No COCO images could be matched"):
            parse_coco_json(coco_path, metadata)

    def test_nonexistent_file_raises(self, sample_images):
        metadata = scan_imageset(sample_images)
        with pytest.raises(FileNotFoundError):
            parse_coco_json("/nonexistent.json", metadata)


class TestStorageImportCoco:
    def test_import_coco_to_imageset(self, tmp_storage, sample_images, coco_json):
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")

        result = tmp_storage.import_coco(asset.asset_id, coco_json)
        assert result["layer"] == "gt"
        assert result["layer_type"] == "detections"
        assert len(result["frames"]) == 3

        # Verify annotations are readable via standard API
        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 1
        assert layers[0]["layer"] == "gt"

        ann = tmp_storage.get_annotations(asset.asset_id, "gt", 0)
        assert ann is not None
        assert len(ann["objects"]) == 2

    def test_import_coco_custom_layer(self, tmp_storage, sample_images, coco_json):
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")
        result = tmp_storage.import_coco(asset.asset_id, coco_json, layer="det/coco", display_name="My COCO")
        assert result["layer"] == "det/coco"
        assert result["display_name"] == "My COCO"

    def test_import_coco_to_video_raises(self, tmp_storage, tmp_path, coco_json):
        """COCO import should only work on imageset assets."""
        import subprocess

        video_path = tmp_path / "test.mp4"
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-f",
                "lavfi",
                "-i",
                "testsrc=duration=0.5:size=64x48:rate=10",
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                str(video_path),
            ],
            check=True,
            capture_output=True,
        )
        asset = tmp_storage.import_video(video_path, datasource="ds1")

        with pytest.raises(ValueError, match="not an imageset"):
            tmp_storage.import_coco(asset.asset_id, coco_json)


class TestImportCocoDataset:
    """Tests for import_coco_dataset — imports images + annotations in one step."""

    def test_basic_import(self, tmp_storage, tmp_path):
        """Import COCO dataset: should create imageset + annotation layer."""
        # Create images
        img_dir = tmp_path / "my_dataset"
        img_dir.mkdir()
        Image.new("RGB", (640, 480)).save(img_dir / "img_001.jpg")
        Image.new("RGB", (640, 480)).save(img_dir / "img_002.jpg")

        # Create COCO JSON in the same directory
        coco_data = {
            "images": [
                {"id": 1, "file_name": "img_001.jpg", "width": 640, "height": 480},
                {"id": 2, "file_name": "img_002.jpg", "width": 640, "height": 480},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [10, 20, 100, 200]},
                {"id": 2, "image_id": 2, "category_id": 1, "bbox": [50, 60, 80, 90]},
            ],
            "categories": [{"id": 1, "name": "person"}],
        }
        coco_path = img_dir / "annotations.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        asset, ann_result = tmp_storage.import_coco_dataset(coco_path, datasource="ds1")

        # Name defaults to parent directory name
        assert asset.name == "my_dataset"
        assert asset.datasource == "ds1"
        assert asset.asset_type == "imageset"
        assert asset.frame_count == 2

        # Annotations imported
        assert ann_result["layer"] == "gt"
        assert len(ann_result["frames"]) == 2

        # Verify readable via standard API
        ann = tmp_storage.get_annotations(asset.asset_id, "gt", 0)
        assert ann is not None
        assert ann["objects"][0]["class_name"] == "person"

    def test_custom_name(self, tmp_storage, tmp_path):
        img_dir = tmp_path / "data"
        img_dir.mkdir()
        Image.new("RGB", (64, 48)).save(img_dir / "a.jpg")

        coco_data = {
            "images": [{"id": 1, "file_name": "a.jpg", "width": 64, "height": 48}],
            "annotations": [],
            "categories": [],
        }
        coco_path = img_dir / "coco.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        asset, _ = tmp_storage.import_coco_dataset(coco_path, datasource="ds1", name="custom-name")
        assert asset.name == "custom-name"

    def test_separate_image_root(self, tmp_storage, tmp_path):
        """Images in a different directory from the COCO JSON."""
        img_dir = tmp_path / "images"
        img_dir.mkdir()
        Image.new("RGB", (64, 48)).save(img_dir / "a.jpg")
        Image.new("RGB", (64, 48)).save(img_dir / "b.jpg")

        ann_dir = tmp_path / "annotations"
        ann_dir.mkdir()
        coco_data = {
            "images": [
                {"id": 1, "file_name": "a.jpg", "width": 64, "height": 48},
                {"id": 2, "file_name": "b.jpg", "width": 64, "height": 48},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [0, 0, 10, 10]},
            ],
            "categories": [{"id": 1, "name": "cat"}],
        }
        coco_path = ann_dir / "instances.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        asset, ann_result = tmp_storage.import_coco_dataset(coco_path, datasource="ds1", image_root=img_dir)
        assert asset.frame_count == 2
        assert len(ann_result["frames"]) == 1

    def test_images_subdir_fallback(self, tmp_storage, tmp_path):
        """Should find images in an 'images/' subdirectory next to the JSON file."""
        root = tmp_path / "coco_dataset"
        root.mkdir()
        (root / "images").mkdir()
        Image.new("RGB", (64, 48)).save(root / "images" / "a.jpg")
        Image.new("RGB", (64, 48)).save(root / "images" / "b.jpg")

        coco_data = {
            "images": [
                {"id": 1, "file_name": "a.jpg", "width": 64, "height": 48},
                {"id": 2, "file_name": "b.jpg", "width": 64, "height": 48},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [0, 0, 10, 10]},
            ],
            "categories": [{"id": 1, "name": "cat"}],
        }
        coco_path = root / "annotations.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        # Images are NOT next to the JSON, but in images/ subdir — should still resolve
        asset, ann_result = tmp_storage.import_coco_dataset(coco_path, datasource="ds1")
        assert asset.frame_count == 2
        assert len(ann_result["frames"]) == 1

    def test_nested_image_paths(self, tmp_storage, tmp_path):
        """COCO file_names with subdirectory paths."""
        root = tmp_path / "dataset"
        root.mkdir()
        (root / "train").mkdir()
        Image.new("RGB", (64, 48)).save(root / "train" / "001.jpg")
        Image.new("RGB", (64, 48)).save(root / "train" / "002.jpg")

        coco_data = {
            "images": [
                {"id": 1, "file_name": "train/001.jpg", "width": 64, "height": 48},
                {"id": 2, "file_name": "train/002.jpg", "width": 64, "height": 48},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [0, 0, 10, 10]},
            ],
            "categories": [{"id": 1, "name": "dog"}],
        }
        coco_path = root / "annotations.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        asset, ann_result = tmp_storage.import_coco_dataset(coco_path, datasource="ds1")
        assert asset.frame_count == 2

        # Verify the nested path is preserved
        media_dir = tmp_storage.path / asset.media_path
        assert (media_dir / "train" / "001.jpg").exists()
        assert (media_dir / "train" / "002.jpg").exists()

    def test_missing_images_warns(self, tmp_storage, tmp_path):
        """Should succeed with partial matches, just warn about missing."""
        img_dir = tmp_path / "partial"
        img_dir.mkdir()
        Image.new("RGB", (64, 48)).save(img_dir / "exists.jpg")

        coco_data = {
            "images": [
                {"id": 1, "file_name": "exists.jpg", "width": 64, "height": 48},
                {"id": 2, "file_name": "missing.jpg", "width": 64, "height": 48},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [0, 0, 10, 10]},
            ],
            "categories": [{"id": 1, "name": "x"}],
        }
        coco_path = img_dir / "ann.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        asset, _ = tmp_storage.import_coco_dataset(coco_path, datasource="ds1")
        assert asset.frame_count == 1  # Only the existing image

    def test_absolute_file_name_paths(self, tmp_storage, tmp_path):
        """COCO file_names that are absolute paths should still import.

        Regression: pathlib's `/` operator discards the left operand when
        joined with an absolute path, so `staging_dir / absolute_file_name`
        used to resolve back to the source file and raise SameFileError.
        """
        img_dir = tmp_path / "abs_images"
        img_dir.mkdir()
        Image.new("RGB", (64, 48)).save(img_dir / "a.jpg")
        Image.new("RGB", (64, 48)).save(img_dir / "b.jpg")

        ann_dir = tmp_path / "abs_annotations"
        ann_dir.mkdir()
        coco_data = {
            "images": [
                {"id": 1, "file_name": str(img_dir / "a.jpg"), "width": 64, "height": 48},
                {"id": 2, "file_name": str(img_dir / "b.jpg"), "width": 64, "height": 48},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1, "bbox": [0, 0, 10, 10]},
            ],
            "categories": [{"id": 1, "name": "thing"}],
        }
        coco_path = ann_dir / "instances.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        # image_root is irrelevant when paths are absolute, but pass the
        # image dir anyway to mirror real-world usage.
        asset, ann_result = tmp_storage.import_coco_dataset(coco_path, datasource="ds1", image_root=img_dir)
        assert asset.frame_count == 2
        assert len(ann_result["frames"]) == 1

        # Images land flat under the imageset (basename only, since the
        # absolute path has no meaningful relative structure to preserve).
        media_dir = tmp_storage.path / asset.media_path
        assert (media_dir / "a.jpg").exists()
        assert (media_dir / "b.jpg").exists()

    def test_no_images_found_raises(self, tmp_storage, tmp_path):
        img_dir = tmp_path / "empty"
        img_dir.mkdir()

        coco_data = {
            "images": [{"id": 1, "file_name": "nonexistent.jpg", "width": 64, "height": 48}],
            "annotations": [],
            "categories": [],
        }
        coco_path = img_dir / "ann.json"
        coco_path.write_bytes(orjson.dumps(coco_data))

        with pytest.raises(ValueError, match="No COCO images could be found"):
            tmp_storage.import_coco_dataset(coco_path, datasource="ds1")
