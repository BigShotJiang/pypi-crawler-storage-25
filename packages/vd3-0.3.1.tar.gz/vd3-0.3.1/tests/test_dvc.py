"""Tests for DVC manager and remote storage operations."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from vd3storage.dvc.manager import DVCManager


class TestDVCManager:
    def test_init(self, tmp_path):
        mgr = DVCManager(tmp_path)
        with patch.object(mgr, "_run") as mock_run:
            mgr.init()
            mock_run.assert_called_once_with(["dvc", "init"])

    def test_add(self, tmp_path):
        mgr = DVCManager(tmp_path)
        test_file = tmp_path / "media" / "videos" / "col1" / "test.mp4"
        test_file.parent.mkdir(parents=True)
        test_file.touch()

        with patch.object(mgr, "_run") as mock_run:
            mgr.add(test_file)
            mock_run.assert_called_once()
            cmd = mock_run.call_args[0][0]
            assert cmd[0:2] == ["dvc", "add"]

    def test_push_all(self, tmp_path):
        mgr = DVCManager(tmp_path)
        with patch.object(mgr, "_require_remote"), patch.object(mgr, "_run") as mock_run:
            mgr.push()
            mock_run.assert_called_once_with(["dvc", "push"])

    def test_push_specific(self, tmp_path):
        mgr = DVCManager(tmp_path)
        dvc_file = Path("db/media/videos/col1/test.mp4.dvc")
        with patch.object(mgr, "_require_remote"), patch.object(mgr, "_run") as mock_run:
            mgr.push([dvc_file])
            cmd = mock_run.call_args[0][0]
            assert cmd == ["dvc", "push", "db/media/videos/col1/test.mp4.dvc"]

    def test_pull_all(self, tmp_path):
        mgr = DVCManager(tmp_path)
        with patch.object(mgr, "_require_remote"), patch.object(mgr, "_run") as mock_run:
            mgr.pull()
            mock_run.assert_called_once_with(["dvc", "pull"])

    def test_pull_specific(self, tmp_path):
        mgr = DVCManager(tmp_path)
        dvc_file = Path("db/media/videos/col1/test.mp4.dvc")
        with patch.object(mgr, "_require_remote"), patch.object(mgr, "_run") as mock_run:
            mgr.pull([dvc_file])
            cmd = mock_run.call_args[0][0]
            assert cmd == ["dvc", "pull", "db/media/videos/col1/test.mp4.dvc"]

    def test_is_available_file_exists(self, tmp_path):
        mgr = DVCManager(tmp_path)
        test_file = tmp_path / "media" / "test.mp4"
        test_file.parent.mkdir(parents=True)
        test_file.write_bytes(b"data")
        assert mgr.is_available(test_file) is True

    def test_is_available_file_missing(self, tmp_path):
        mgr = DVCManager(tmp_path)
        assert mgr.is_available(tmp_path / "nonexistent.mp4") is False

    def test_is_available_relative_path(self, tmp_path):
        mgr = DVCManager(tmp_path)
        test_file = tmp_path / "media" / "test.mp4"
        test_file.parent.mkdir(parents=True)
        test_file.write_bytes(b"data")
        assert mgr.is_available(Path("media/test.mp4")) is True

    def test_add_remote(self, tmp_path):
        mgr = DVCManager(tmp_path)
        with patch.object(mgr, "_run") as mock_run:
            mgr.add_remote("myremote", "s3://bucket/path")
            cmd = mock_run.call_args[0][0]
            assert cmd == ["dvc", "remote", "add", "--default", "myremote", "s3://bucket/path"]

    def test_add_remote_non_default(self, tmp_path):
        mgr = DVCManager(tmp_path)
        with patch.object(mgr, "_run") as mock_run:
            mgr.add_remote("secondary", "/local/path", default=False)
            cmd = mock_run.call_args[0][0]
            assert cmd == ["dvc", "remote", "add", "secondary", "/local/path"]

    def test_list_remotes(self, tmp_path):
        mgr = DVCManager(tmp_path)
        mock_result = MagicMock()
        mock_result.stdout = "myremote\ts3://bucket/path\nsecondary\t/local/path\n"
        with patch.object(mgr, "_run", return_value=mock_result):
            remotes = mgr.list_remotes()
            assert remotes == {"myremote": "s3://bucket/path", "secondary": "/local/path"}

    def test_status(self, tmp_path):
        mgr = DVCManager(tmp_path)
        mock_result = MagicMock()
        mock_result.stdout = "data.dvc: changed"
        mock_result.returncode = 0
        with patch.object(mgr, "_run", return_value=mock_result):
            status = mgr.status()
            assert status["returncode"] == 0


class TestStorageRemoteOps:
    def test_is_media_available(self, tmp_storage):
        """Assets without video files should not be available."""
        asset = tmp_storage.add_asset("test.mp4", "col1", media_path="db/media/videos/col1/test.mp4")
        assert tmp_storage.is_media_available(asset.asset_id) is False

    def test_is_media_available_with_file(self, tmp_storage):
        """Assets with actual video files should be available."""
        video_path = "db/media/videos/col1/test.mp4"
        full_path = tmp_storage.path / video_path
        full_path.parent.mkdir(parents=True)
        full_path.write_bytes(b"fake video data")

        asset = tmp_storage.add_asset("test.mp4", "col1", media_path=video_path)
        assert tmp_storage.is_media_available(asset.asset_id) is True

    def test_remote_status(self, tmp_storage):
        tmp_storage.add_asset("a.mp4", "col1", media_path="db/media/videos/col1/a.mp4")
        tmp_storage.add_asset("b.mp4", "col1", media_path="db/media/videos/col1/b.mp4")

        # Create one actual file
        (tmp_storage.path / "db/media/videos/col1").mkdir(parents=True, exist_ok=True)
        (tmp_storage.path / "db/media/videos/col1/a.mp4").write_bytes(b"data")

        status = tmp_storage.remote_status()
        assert status["total_assets"] == 2
        assert status["available"] == 1
        assert status["unavailable"] == 1

    def test_resolve_dvc_files_by_datasource(self, tmp_storage):
        """Should resolve datasource filter to .dvc file paths."""
        tmp_storage.add_asset("a.mp4", "col1", media_path="db/media/videos/col1/a.mp4")

        # Create the .dvc pointer file
        dvc_path = tmp_storage.path / "db/media/videos/col1/a.mp4.dvc"
        dvc_path.parent.mkdir(parents=True)
        dvc_path.write_text("md5: abc123")

        files = tmp_storage._resolve_dvc_files(datasource="col1")
        assert len(files) == 1
        assert files[0].name == "a.mp4.dvc"

    def test_resolve_dvc_files_by_workset(self, tmp_storage):
        """Should resolve workset to .dvc file paths for its assets."""
        ws = tmp_storage.create_workset("Project")
        a1 = tmp_storage.add_asset("a.mp4", "col1", media_path="db/media/videos/col1/a.mp4")
        tmp_storage.add_asset("b.mp4", "col1", media_path="db/media/videos/col1/b.mp4")
        tmp_storage.add_asset_to_workset(ws.workset_id, a1.asset_id)

        # Create .dvc files for both
        (tmp_storage.path / "db/media/videos/col1").mkdir(parents=True, exist_ok=True)
        (tmp_storage.path / "db/media/videos/col1/a.mp4.dvc").write_text("md5: a")
        (tmp_storage.path / "db/media/videos/col1/b.mp4.dvc").write_text("md5: b")

        # Should only resolve the one in the workset
        files = tmp_storage._resolve_dvc_files(workset_id=ws.workset_id)
        assert len(files) == 1
        assert files[0].name == "a.mp4.dvc"
