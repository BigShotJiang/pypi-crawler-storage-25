"""Tests for VD3 data models."""

import warnings

import pytest

from vd3storage.models import Asset, Tag, Workset, WorksetAsset


class TestAssetModel:
    def test_create_with_defaults(self):
        asset = Asset(name="cam01.mp4", datasource="dashcam-2024")
        assert asset.name == "cam01.mp4"
        assert asset.datasource == "dashcam-2024"
        assert asset.asset_type == "video"
        assert asset.sensor_type == "unknown"
        assert len(asset.asset_id) == 36  # UUID format
        assert asset.frame_count == 0
        assert asset.annotation_layers_json == "[]"

    def test_create_with_all_fields(self):
        asset = Asset(
            name="cam01.mp4",
            datasource="dashcam-2024",
            asset_type="video",
            sensor_type="rgb",
            sensor_mount="moving",
            width=1920,
            height=1080,
            frame_count=9000,
            nominal_fps=30.0,
            duration_ms=300000,
            environment="urban",
            spectrum="infrared",
            codec="h264",
        )
        assert asset.width == 1920
        assert asset.spectrum == "infrared"
        assert asset.codec == "h264"

    def test_csv_filename(self):
        assert Asset.csv_filename() == "assets.csv"

    def test_primary_key(self):
        assert Asset.primary_key() == "asset_id"

    def test_duckdb_columns(self):
        cols = Asset.duckdb_columns()
        assert "asset_id" in cols
        assert cols["asset_id"] == "VARCHAR"
        assert cols["frame_count"] == "BIGINT"
        assert cols["nominal_fps"] == "DOUBLE"
        assert cols["spectrum"] == "VARCHAR"
        assert cols["codec"] == "VARCHAR"


class TestExtraJsonValidator:
    def test_default_empty_object_is_valid(self):
        asset = Asset(name="a.mp4", datasource="d")
        assert asset.extra_json == "{}"

    def test_namespaced_payload_is_valid(self):
        payload = '{"resideo": {"camera_type": "VX3", "scores": {"spectrum": 0.9}}}'
        with warnings.catch_warnings():
            warnings.simplefilter("error")  # fail the test if any warning is emitted
            asset = Asset(name="a.mp4", datasource="d", extra_json=payload)
        assert asset.extra_json == payload

    def test_multiple_namespaces_is_valid(self):
        payload = '{"ns_a": {"x": 1}, "ns_b": {"y": 2}}'
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            Asset(name="a.mp4", datasource="d", extra_json=payload)

    def test_scalar_at_top_level_warns(self):
        with pytest.warns(UserWarning, match="namespace owners"):
            Asset(name="a.mp4", datasource="d", extra_json='{"camera_type": "VX3"}')

    def test_array_at_top_level_warns(self):
        with pytest.warns(UserWarning, match="namespace owners"):
            Asset(name="a.mp4", datasource="d", extra_json='{"tags": [1, 2, 3]}')

    def test_mixed_namespaced_and_flat_warns_with_only_flat_key(self):
        with pytest.warns(UserWarning, match=r"\['top_level'\]"):
            Asset(name="a.mp4", datasource="d", extra_json='{"ns": {"ok": 1}, "top_level": "bad"}')

    def test_non_json_rejected(self):
        with pytest.raises(ValueError, match="must be valid JSON"):
            Asset(name="a.mp4", datasource="d", extra_json="not json")

    def test_json_array_root_rejected(self):
        with pytest.raises(ValueError, match="root must be a JSON object"):
            Asset(name="a.mp4", datasource="d", extra_json="[1, 2, 3]")

    def test_json_scalar_root_rejected(self):
        with pytest.raises(ValueError, match="root must be a JSON object"):
            Asset(name="a.mp4", datasource="d", extra_json='"hello"')


class TestTagModel:
    def test_create(self):
        tag = Tag(asset_id="abc-123", tag="training")
        assert tag.asset_id == "abc-123"
        assert tag.tag == "training"
        assert Tag.csv_filename() == "tags.csv"


class TestWorksetModel:
    def test_create(self):
        ws = Workset(name="My Project", slug="my-project")
        assert ws.name == "My Project"
        assert ws.slug == "my-project"
        assert ws.description == ""
        assert Workset.csv_filename() == "worksets.csv"


class TestWorksetAssetModel:
    def test_create(self):
        wa = WorksetAsset(workset_id="ws-1", asset_id="asset-1", package="training/urban")
        assert wa.package == "training/urban"
        assert WorksetAsset.csv_filename() == "workset_assets.csv"

    def test_default_package(self):
        wa = WorksetAsset(workset_id="ws-1", asset_id="asset-1")
        assert wa.package == ""
