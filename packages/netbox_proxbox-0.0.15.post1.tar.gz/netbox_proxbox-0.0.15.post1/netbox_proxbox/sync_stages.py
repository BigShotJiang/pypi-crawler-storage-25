"""Stage execution: batch sync, base/stage query params, and multi-stage orchestration."""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Callable
from typing import TYPE_CHECKING

from netbox_proxbox.choices import SyncTypeChoices
from netbox_proxbox.sync_types import (
    _format_seconds,
    _extract_backend_error_text,
    _format_stage_sync_error,
    _sync_stream_paths_for_stage,
    expanded_sync_stages,
    normalize_sync_types,
)
from netbox_proxbox.sync_params import (
    _normalize_batch_object_ids,
    _resolve_vm_batch_params,
    _resolve_vm_backup_batch_params,
    _resolve_vm_snapshot_batch_params,
    _resolve_storage_batch_params,
    _resolve_task_history_batch_params,
    _parse_description_metadata_setting,
    _proxbox_fetch_max_concurrency_setting,
    _use_guest_agent_interface_name_setting,
    _ignore_ipv6_link_local_addresses_setting,
    _primary_ip_preference_setting,
    _serialize_sync_params,
    effective_overwrites_for_endpoint,
)
from netbox_proxbox.sync_ownership import (
    _claim_rq_sync_ownership,
    _release_rq_sync_ownership,
)

if TYPE_CHECKING:
    from netbox_proxbox.jobs import ProxboxSyncJob

_HEARTBEAT_SECONDS = 20.0
_STAGE_RETRY_MAX = 2
_STAGE_RETRY_DELAY = 8.0

# Stages that are supplementary/optional: a failure logs a warning and the sync
# continues.  Required stages (devices, VMs, storage, interfaces, IPs) are NOT
# in this set and still abort the run on failure.
_SKIPPABLE_STAGES: frozenset[str] = frozenset(
    {
        SyncTypeChoices.VIRTUAL_MACHINES_BACKUPS,   # "vm-backups"
        SyncTypeChoices.VIRTUAL_MACHINES_SNAPSHOTS, # "vm-snapshots"
        SyncTypeChoices.TASK_HISTORY,               # "task-history"
    }
)


async def _run_batch_selected_sync(
    self: "ProxboxSyncJob",
    *,
    batch_object_type: str,
    batch_object_ids: list[str],
    netbox_branch_schema_id: str | None = None,
) -> dict[str, object]:
    """Run selected object syncs concurrently with asyncio.gather."""
    from virtualization.models import VirtualMachine

    from netbox_proxbox.models import (
        ProxmoxStorage,
        VMBackup,
        VMSnapshot,
        VMTaskHistory,
    )
    from netbox_proxbox.services.individual_sync import (
        sync_individual_with_dependencies,
    )

    model_map = {
        "virtual-machine": VirtualMachine.objects.select_related(
            "cluster", "device", "site", "role", "tenant", "platform"
        ),
        "vm-backup": VMBackup.objects.select_related(
            "virtual_machine", "proxmox_storage", "proxmox_storage__cluster"
        ),
        "vm-snapshot": VMSnapshot.objects.select_related(
            "virtual_machine", "proxmox_storage", "proxmox_storage__cluster"
        ),
        "proxmox-storage": ProxmoxStorage.objects.select_related("cluster"),
        "vm-task-history": VMTaskHistory.objects.select_related("virtual_machine"),
    }

    queryset = model_map.get(batch_object_type)
    if queryset is None:
        raise ValueError(f"Unsupported batch object type: {batch_object_type!r}")

    object_ids = _normalize_batch_object_ids(batch_object_ids)
    objects = list(queryset.filter(pk__in=object_ids))
    object_by_id = {str(getattr(obj, "pk", "")): obj for obj in objects}

    semaphore = asyncio.Semaphore(_proxbox_fetch_max_concurrency_setting())

    async def run_one(object_id: str) -> dict[str, object]:
        async with semaphore:
            obj = object_by_id.get(str(object_id))
            if obj is None:
                return {
                    "batch_object_type": batch_object_type,
                    "object_id": str(object_id),
                    "status": 404,
                    "error": "Selected object was not found.",
                }

            if batch_object_type == "virtual-machine":
                params = _resolve_vm_batch_params(obj)
            elif batch_object_type == "vm-backup":
                params = _resolve_vm_backup_batch_params(obj)
            elif batch_object_type == "vm-snapshot":
                params = _resolve_vm_snapshot_batch_params(obj)
            elif batch_object_type == "proxmox-storage":
                params = _resolve_storage_batch_params(obj)
            elif batch_object_type == "vm-task-history":
                params = _resolve_task_history_batch_params(obj)
            else:
                return {
                    "batch_object_type": batch_object_type,
                    "object_id": str(object_id),
                    "status": 422,
                    "error": f"Unsupported batch object type: {batch_object_type}",
                }

            if params.get("error"):
                return {
                    "batch_object_type": batch_object_type,
                    "object_id": str(object_id),
                    "status": int(params.get("status") or 422),
                    "error": str(params.get("error")),
                }

            path = str(params["path"])
            query_params = dict(params.get("query_params") or {})
            if netbox_branch_schema_id:
                query_params["netbox_branch_schema_id"] = str(netbox_branch_schema_id)

            def _call_sync() -> tuple[dict, int, list[dict]]:
                return sync_individual_with_dependencies(path, query_params)

            response, status, dependencies = await asyncio.to_thread(_call_sync)

            if batch_object_type == "virtual-machine" and 200 <= int(status) < 300:
                from netbox_proxbox.services.tenant_assignment import (
                    maybe_assign_tenant_from_regex,
                )

                def _post_sync_assign() -> None:
                    obj.refresh_from_db()
                    maybe_assign_tenant_from_regex(obj)

                await asyncio.to_thread(_post_sync_assign)

            return {
                "batch_object_type": batch_object_type,
                "object_id": str(object_id),
                "status": status,
                "response": response,
                "dependencies": dependencies,
                "error": response.get("error") if isinstance(response, dict) else None,
            }

    results = await asyncio.gather(*(run_one(object_id) for object_id in object_ids))
    succeeded = sum(1 for item in results if int(item.get("status", 500)) < 400)
    failed = len(results) - succeeded
    return {
        "batch_object_type": batch_object_type,
        "batch_object_label": batch_object_type.replace("-", " ").title(),
        "total": len(results),
        "succeeded": succeeded,
        "failed": failed,
        "results": results,
    }


def _build_base_query_params(
    proxmox_endpoint_ids: list[str] | None,
    netbox_endpoint_ids: list[str] | None,
) -> dict[str, str]:
    """Build base query parameters for sync stages.

    Overwrite flags resolve per-endpoint when exactly one Proxmox endpoint is in
    scope. Full syncs split multiple Proxmox endpoints into separate one-
    endpoint SSE requests before calling this helper, because the backend
    accepts one flat overwrite flag group per request. Direct helper calls
    without a concrete endpoint fall back to the global
    ``ProxboxPluginSettings`` singleton.
    """
    base_query: dict[str, str] = {}
    base_query["use_guest_agent_interface_name"] = (
        "true" if _use_guest_agent_interface_name_setting() else "false"
    )
    base_query["fetch_max_concurrency"] = str(_proxbox_fetch_max_concurrency_setting())
    base_query["ignore_ipv6_link_local_addresses"] = (
        "true" if _ignore_ipv6_link_local_addresses_setting() else "false"
    )
    base_query["primary_ip_preference"] = _primary_ip_preference_setting()
    base_query["parse_description_metadata"] = (
        "true" if _parse_description_metadata_setting() else "false"
    )

    single_endpoint_id = (
        proxmox_endpoint_ids[0]
        if proxmox_endpoint_ids and len(proxmox_endpoint_ids) == 1
        else None
    )
    overwrites = effective_overwrites_for_endpoint(single_endpoint_id)
    for name, value in overwrites.items():
        base_query[name] = "true" if value else "false"

    if proxmox_endpoint_ids:
        base_query["proxmox_endpoint_ids"] = ",".join(proxmox_endpoint_ids)
    if netbox_endpoint_ids:
        base_query["netbox_endpoint_ids"] = ",".join(netbox_endpoint_ids)
    return base_query


def _build_stage_query_params(
    base_query: dict[str, str],
    sync_type: str,
    target_vm_ids: list[str],
    disable_vm_network_on_vm_stage: bool = False,
) -> dict[str, str]:
    """Build query parameters for a specific sync stage."""
    query_params = dict(base_query)
    if sync_type == SyncTypeChoices.VIRTUAL_MACHINES_BACKUPS:
        query_params["delete_nonexistent_backup"] = "true"
    if sync_type == SyncTypeChoices.VIRTUAL_MACHINES_SNAPSHOTS:
        query_params["delete_nonexistent_snapshot"] = "true"
    if sync_type == SyncTypeChoices.VIRTUAL_MACHINES and disable_vm_network_on_vm_stage:
        # Full sync runs dedicated VM interface/IP stages; skip network work in VM stage.
        query_params["sync_vm_network"] = "false"
    if target_vm_ids:
        query_params["netbox_vm_ids"] = ",".join(target_vm_ids)
    return query_params


def _execute_stage_sync(
    job: "ProxboxSyncJob",
    sync_type: str,
    stream_path: str,
    query_params: dict[str, str] | None,
    on_frame: Callable[[str, dict[str, object]], None],
    endpoint_id: int | None = None,
) -> tuple[dict[str, object], float]:
    """Execute a single stage sync and return payload."""
    from netbox_proxbox.services import run_sync_stream

    job.logger.info(f"Starting stage: {sync_type} ({stream_path})")
    stage_started = time.monotonic()
    last_heartbeat = stage_started

    def _heartbeat() -> None:
        nonlocal last_heartbeat
        now = time.monotonic()
        if now - last_heartbeat < _HEARTBEAT_SECONDS:
            return
        elapsed = _format_seconds(now - stage_started)
        job.logger.info(
            f"Stage '{sync_type}' still running on '{stream_path}' (elapsed {elapsed})"
        )
        last_heartbeat = now

    def _on_frame_with_heartbeat(
        event: str,
        data: dict[str, object],
        forward: Callable[[str, dict[str, object]], None],
    ) -> None:
        forward(event, data)
        _heartbeat()

    last_payload: dict[str, object] = {}
    last_status: int = 0
    for _attempt in range(_STAGE_RETRY_MAX + 1):
        job.logger.info(f"Checking backend readiness for stage '{sync_type}'...")
        last_payload, last_status = run_sync_stream(
            stream_path,
            query_params=query_params,
            on_frame=lambda e, d: _on_frame_with_heartbeat(e, d, on_frame),
            endpoint_id=endpoint_id,
        )
        elapsed = _format_seconds(time.monotonic() - stage_started)
        job.job.save(update_fields=["log_entries"])

        if last_status < 400:
            stage_runtime = round(time.monotonic() - stage_started, 3)
            job.logger.info(
                f"Stage completed: {sync_type} ({stream_path}) HTTP {last_status} in {elapsed}"
            )
            return last_payload, stage_runtime

        if (last_status >= 500 or last_status == 429) and _attempt < _STAGE_RETRY_MAX:
            retry_detail = _extract_backend_error_text(last_payload) or str(
                last_payload
            )
            job.logger.warning(
                f"Stage {sync_type} failed (HTTP {last_status}): {retry_detail} "
                f"-- retrying in {_STAGE_RETRY_DELAY:.0f}s "
                f"(attempt {_attempt + 1}/{_STAGE_RETRY_MAX})"
            )
            job.job.save(update_fields=["log_entries"])
            time.sleep(_STAGE_RETRY_DELAY)
            continue

        # 4xx (not retryable) or all retries exhausted
        break

    detail = _extract_backend_error_text(last_payload) or str(last_payload)
    user_detail = _format_stage_sync_error(
        sync_type=sync_type,
        status=last_status,
        payload=last_payload,
    )
    if last_status in (503, 404) and "init_ok" in detail:
        job.logger.error(
            f"Backend not ready for stage '{sync_type}': {detail}. "
            "Check proxbox-api bootstrap logs and verify NetBox connectivity."
        )
    else:
        job.logger.error(f"Stage {sync_type} failed (HTTP {last_status}): {detail}")
    raise RuntimeError(user_detail)


def _proxmox_endpoint_scopes(
    proxmox_endpoint_ids: object,
) -> list[list[str]]:
    """Return one flat-query endpoint scope per backend SSE run."""
    requested: list[str] = []
    for value in list(proxmox_endpoint_ids or []):
        endpoint_id = str(value).strip()
        if not endpoint_id:
            continue
        try:
            int(endpoint_id)
        except (TypeError, ValueError):
            continue
        requested.append(endpoint_id)
    if requested:
        return [[endpoint_id] for endpoint_id in requested]

    try:
        from netbox_proxbox.models import ProxmoxEndpoint

        endpoint_ids = [
            str(pk) for pk in ProxmoxEndpoint.objects.values_list("pk", flat=True)
        ]
    except (ImportError, RuntimeError, AttributeError):
        endpoint_ids = []
    if not endpoint_ids:
        return [[]]
    return [[endpoint_id] for endpoint_id in endpoint_ids]


def _run_all_stages_sync(
    job: "ProxboxSyncJob",
    stages: list[str],
    params: dict[str, object],
    run_started: float,
) -> list[dict[str, object]]:
    """Run all sync stages in order and return stage results."""
    endpoint_scopes = _proxmox_endpoint_scopes(params.get("proxmox_endpoint_ids"))

    flush_interval = 2.0
    log_throttle = 1.5
    last_flush = time.monotonic()
    last_progress_log = time.monotonic()

    def on_frame(event: str, data: dict[str, object]) -> None:
        nonlocal last_flush, last_progress_log
        if event == "complete":
            return
        now = time.monotonic()
        line = json.dumps(data, default=str)
        if len(line) > 600:
            line = line[:600] + "…"
        if event == "error" or now - last_progress_log >= log_throttle:
            job.logger.info("[proxbox-stream] {}: {}".format(event, line))
            last_progress_log = now
        if now - last_flush >= flush_interval:
            job.job.save(update_fields=["log_entries"])
            last_flush = now

    stages_out: list[dict[str, object]] = []

    target_vm_ids = [str(x) for x in list(params.get("netbox_vm_ids") or []) if str(x)]
    fastapi_endpoint_id = params.get("fastapi_endpoint_id")
    netbox_branch_schema_id = params.get("netbox_branch_schema_id")
    disable_vm_network_on_vm_stage = SyncTypeChoices.VIRTUAL_MACHINES in stages and (
        SyncTypeChoices.VM_INTERFACES in stages
        or SyncTypeChoices.IP_ADDRESSES in stages
    )

    for endpoint_scope in endpoint_scopes:
        if endpoint_scope:
            job.logger.info(
                "Running SSE sync for Proxmox endpoint %s", endpoint_scope[0]
            )
        else:
            job.logger.info("Running SSE sync with no Proxmox endpoint filter")
        base_query = _build_base_query_params(
            endpoint_scope,
            params.get("netbox_endpoint_ids"),
        )
        if netbox_branch_schema_id:
            base_query["netbox_branch_schema_id"] = str(netbox_branch_schema_id)

        for st in stages:
            query_params = _build_stage_query_params(
                base_query,
                st,
                target_vm_ids,
                disable_vm_network_on_vm_stage=disable_vm_network_on_vm_stage,
            )
            stage_paths = _sync_stream_paths_for_stage(st, target_vm_ids)

            for stream_path in stage_paths:
                try:
                    payload, stage_runtime = _execute_stage_sync(
                        job, st, stream_path, query_params, on_frame, fastapi_endpoint_id
                    )
                except RuntimeError as exc:
                    if st in _SKIPPABLE_STAGES:
                        job.logger.warning(
                            "Optional stage '%s' failed and was skipped: %s", st, exc
                        )
                        job.job.save(update_fields=["log_entries"])
                        continue
                    raise
                response = payload.get("response") or {}
                stages_out.append(
                    {
                        "sync_type": st,
                        "runtime_seconds": stage_runtime,
                        "result_summary": {
                            "path": payload.get("path"),
                            "ok": response.get("ok"),
                        },
                    }
                )

    return stages_out
