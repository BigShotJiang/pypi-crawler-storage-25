# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["NamespaceRecallParams"]


class NamespaceRecallParams(TypedDict, total=False):
    namespace: str

    filters: object
    """Filter by attributes. Same syntax as the query endpoint."""

    include_ground_truth: bool
    """
    Include ground truth data (query vectors and true nearest neighbors) in the
    response.
    """

    num: int
    """The number of searches to run."""

    rank_by: object
    """The ranking function to evaluate recall for.

    If provided, `num` must be either null or 1.
    """

    top_k: int
    """Search for `top_k` nearest neighbors."""
