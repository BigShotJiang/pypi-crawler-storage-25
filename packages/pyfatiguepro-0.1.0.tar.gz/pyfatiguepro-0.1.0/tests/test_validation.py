import pandas as pd
from pyfatiguepro.validation import validation_report, ProprietaryDataValidator, DataProvenanceRegistry


def test_validation_report():
    r = validation_report([1000, 2000, 3000], [1100, 1900, 3100])
    assert r["MAPE_percent"] < 20


def test_prop_validator():
    df = pd.DataFrame({"stress_amplitude": [500], "cycles": [10000], "project": ["secret"]})
    v = ProprietaryDataValidator()
    assert v.validate_schema(df)
    anon = v.anonymize(df)
    assert anon["project"].iloc[0] != "secret"


def test_registry():
    reg = DataProvenanceRegistry()
    reg.add("x", "Ti64", "demo_synthetic", "generated", True)
    assert len(reg.to_frame()) == 1
