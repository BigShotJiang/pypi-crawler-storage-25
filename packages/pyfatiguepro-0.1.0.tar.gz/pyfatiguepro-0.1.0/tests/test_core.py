from pyfatiguepro.core import basquin_life, goodman_correction, gerber_correction, von_mises_stress


def test_basquin_positive():
    assert basquin_life(500, 1200, -0.08) > 0


def test_goodman_positive():
    assert goodman_correction(500, 50, 1000) > 500


def test_gerber_positive():
    assert gerber_correction(500, 50, 1000) > 500


def test_vm_positive():
    assert von_mises_stress(100, 50, 20, 10, 5, 3) > 0
