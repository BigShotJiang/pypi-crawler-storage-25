import pandas as pd
from pyfatiguepro.fea import FEAIngestor


def test_fea_ingestion():
    df = pd.DataFrame({
        "S11": [500], "S22": [100], "S33": [50],
        "S12": [10], "S23": [5], "S13": [3],
    })
    ing = FEAIngestor()
    out = ing.add_von_mises(df)
    assert "von_mises" in out.columns
    assert out["von_mises"].iloc[0] > 0
