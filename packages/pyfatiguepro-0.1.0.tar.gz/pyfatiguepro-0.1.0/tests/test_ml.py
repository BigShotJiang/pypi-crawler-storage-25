import numpy as np
import pandas as pd
from pyfatiguepro.validation import ProprietaryDataValidator
from pyfatiguepro.ml import FatigueMLPredictor


def test_ml_train_predict():
    n = 200
    rng = np.random.default_rng(1)
    stress = rng.uniform(300, 700, n)
    cycles = 1e7 * (stress / 300) ** -4
    df = pd.DataFrame({
        "material": ["Ti64"] * n,
        "stress_amplitude": stress,
        "temperature": rng.uniform(25, 500, n),
        "cycles": cycles,
    })
    v = ProprietaryDataValidator()
    df = v.clean_for_training(df)
    model = FatigueMLPredictor("rf")
    metrics = model.train(df, target_col="log_life")
    pred = model.predict({"material": "Ti64", "stress_amplitude": 500, "temperature": 100})
    assert pred[0] > 0
    assert "r2_log" in metrics
