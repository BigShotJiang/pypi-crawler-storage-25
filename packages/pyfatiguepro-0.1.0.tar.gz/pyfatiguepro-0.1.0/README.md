# PyFatiguePro

**Physics-informed fatigue-life prediction library for engineering and aeroengine alloys.**

PyFatiguePro combines classical fatigue mechanics, FEA result ingestion, proprietary experimental data validation, machine learning, SHAP explainability, uncertainty estimation, REST API deployment, Docker, tests, and CI/CD.

## Features

- Basquin S-N high-cycle fatigue model
- Coffin-Manson strain-life low-cycle fatigue model
- Paris Law crack-growth integration
- Goodman and Gerber mean-stress corrections
- Von Mises multiaxial stress calculation
- FEA CSV ingestion from Abaqus/ANSYS-style exports
- FEA hotspot feature extraction
- Proprietary-data validation and anonymization
- Dataset provenance registry
- Scalable ML training using Random Forest / HistGradientBoosting / GPR
- Batch prediction for large CSV files
- Uncertainty estimation
- SHAP explainability support
- Sensitivity analysis
- FastAPI REST API
- Docker deployment
- GitHub Actions CI/CD

## Data disclaimer

This package does not ship proprietary or unpublished fatigue datasets. It provides safe workflows to validate, anonymize, and train models on your own internal/proprietary fatigue-test data.

Synthetic examples are demonstration-only and must not be advertised as physical-test validation.

## Installation after PyPI upload

```bash
pip install pyfatiguepro
```

## Local development install

```bash
pip install -e ".[dev,explain]"
```

## Quick example

```python
from pyfatiguepro.core import fit_basquin, basquin_life

stress = [760, 700, 650, 600, 550]
cycles = [1e4, 3e4, 8e4, 2e5, 7e5]

fit = fit_basquin(stress, cycles)
print(fit)

predicted = basquin_life(625, fit["sigma_f_prime"], fit["b"])
print(predicted)
```

## Train demo model

```bash
python examples/train_demo.py
```

This creates `model.joblib`.

## Run API

```bash
uvicorn pyfatiguepro.api:app --host 0.0.0.0 --port 8002
```

Open:

```text
http://127.0.0.1:8002/docs
```

## Docker

```bash
docker build -t pyfatiguepro .
docker run -p 8002:8002 pyfatiguepro
```

## PyPI upload

```bash
python -m pip install --upgrade build twine
python -m build
twine check dist/*
twine upload --repository testpypi dist/*
twine upload dist/*
```

After successful real PyPI upload:

```bash
pip install pyfatiguepro
```
