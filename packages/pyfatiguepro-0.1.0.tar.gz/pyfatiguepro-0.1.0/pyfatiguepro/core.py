import numpy as np


def basquin_life(stress_amplitude, sigma_f_prime, b):
    """Cycles to failure from Basquin stress-life relation.

    sigma_a = sigma_f_prime * (2Nf)^b
    """
    stress_amplitude = np.asarray(stress_amplitude, dtype=float)
    stress_amplitude = np.maximum(stress_amplitude, 1e-12)
    return 0.5 * (stress_amplitude / sigma_f_prime) ** (1.0 / b)


def fit_basquin(stress_amplitude, cycles):
    """Fit Basquin model using log-linear S-N regression."""
    stress_amplitude = np.asarray(stress_amplitude, dtype=float)
    cycles = np.asarray(cycles, dtype=float)
    mask = np.isfinite(stress_amplitude) & np.isfinite(cycles) & (stress_amplitude > 0) & (cycles > 0)
    stress_amplitude = stress_amplitude[mask]
    cycles = cycles[mask]
    if len(cycles) < 3:
        raise ValueError("At least 3 valid S-N points are required to fit Basquin model.")
    x = np.log10(2.0 * cycles)
    y = np.log10(stress_amplitude)
    b, intercept = np.polyfit(x, y, 1)
    sigma_f_prime = 10.0 ** intercept
    pred = basquin_life(stress_amplitude, sigma_f_prime, b)
    return {
        "sigma_f_prime": float(sigma_f_prime),
        "b": float(b),
        "predicted_cycles": pred,
    }


def coffin_manson_life(strain_amplitude, sigma_f_prime, E, b, epsilon_f_prime, c):
    """Numerically invert Coffin-Manson-Basquin strain-life equation."""
    strain_amplitude = np.asarray(strain_amplitude, dtype=float)
    log_n = np.linspace(1, 10, 20000)
    reversals = 2.0 * (10.0 ** log_n)
    strain_curve = (sigma_f_prime / E) * reversals**b + epsilon_f_prime * reversals**c
    out = []
    for eps in strain_amplitude:
        if not np.isfinite(eps) or eps <= 0:
            out.append(np.nan)
            continue
        idx = np.argmin(np.abs(strain_curve - eps))
        out.append(10.0 ** log_n[idx])
    return np.asarray(out)


def paris_law_cycles(a0, ac, delta_sigma, Y, C, m, steps=5000):
    """Integrate Paris law da/dN = C(DeltaK)^m from a0 to ac."""
    if ac <= a0:
        raise ValueError("Critical crack length ac must be greater than initial crack length a0.")
    a = np.linspace(a0, ac, steps)
    delta_k = Y * delta_sigma * np.sqrt(np.pi * a)
    dadn = np.maximum(C * delta_k**m, 1e-30)
    return float(np.trapz(1.0 / dadn, a))


def goodman_correction(stress_amplitude, mean_stress, ultimate_strength):
    denominator = 1.0 - np.asarray(mean_stress, dtype=float) / ultimate_strength
    return np.asarray(stress_amplitude, dtype=float) / np.maximum(denominator, 1e-9)


def gerber_correction(stress_amplitude, mean_stress, ultimate_strength):
    denominator = 1.0 - (np.asarray(mean_stress, dtype=float) / ultimate_strength) ** 2
    return np.asarray(stress_amplitude, dtype=float) / np.maximum(denominator, 1e-9)


def von_mises_stress(s11, s22, s33, s12, s23, s13):
    return np.sqrt(
        0.5 * ((s11 - s22) ** 2 + (s22 - s33) ** 2 + (s33 - s11) ** 2)
        + 3.0 * (s12**2 + s23**2 + s13**2)
    )
