from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
from sklearn.impute import SimpleImputer
from sklearn.metrics import r2_score, mean_absolute_percentage_error
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

try:
    import shap
    SHAP_AVAILABLE = True
except Exception:
    SHAP_AVAILABLE = False


class FatigueMLPredictor:
    def __init__(self, model_type="rf", random_state=42):
        self.model_type = model_type
        self.random_state = random_state
        self.pipeline = None
        self.feature_names = None
        self.numeric_features = None
        self.categorical_features = None
        self.metadata = {}

    def _regressor(self):
        if self.model_type == "rf":
            return RandomForestRegressor(
                n_estimators=500,
                min_samples_leaf=2,
                random_state=self.random_state,
                n_jobs=-1,
            )
        if self.model_type == "hgb":
            return HistGradientBoostingRegressor(
                max_iter=500,
                learning_rate=0.04,
                random_state=self.random_state,
            )
        if self.model_type == "gpr":
            kernel = ConstantKernel(1.0) * RBF(1.0) + WhiteKernel()
            return GaussianProcessRegressor(kernel=kernel, normalize_y=True, random_state=self.random_state)
        raise ValueError("model_type must be one of: rf, hgb, gpr")

    def _build_preprocessor(self, X):
        self.numeric_features = list(X.select_dtypes(include=[np.number]).columns)
        self.categorical_features = list(X.select_dtypes(exclude=[np.number]).columns)
        transformers = []
        if self.numeric_features:
            transformers.append(("num", Pipeline([
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
            ]), self.numeric_features))
        if self.categorical_features:
            transformers.append(("cat", Pipeline([
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore")),
            ]), self.categorical_features))
        return ColumnTransformer(transformers=transformers, remainder="drop")

    def train(self, df, target_col="log_life", test_size=0.2, group_col=None):
        df = df.copy()
        if target_col not in df.columns:
            raise ValueError(f"Missing target column: {target_col}")
        y = df[target_col].astype(float)
        X = df.drop(columns=[target_col])
        if "cycles" in X.columns:
            X = X.drop(columns=["cycles"])
        self.feature_names = list(X.columns)
        if group_col and group_col in X.columns:
            groups = X[group_col].astype(str)
            splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=self.random_state)
            train_idx, test_idx = next(splitter.split(X, y, groups=groups))
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        else:
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=self.random_state
            )
        self.pipeline = Pipeline([
            ("preprocess", self._build_preprocessor(X_train)),
            ("model", self._regressor()),
        ])
        self.pipeline.fit(X_train, y_train)
        pred = self.pipeline.predict(X_test)
        mape = mean_absolute_percentage_error(10 ** y_test, 10 ** pred)
        metrics = {
            "r2_log": float(r2_score(y_test, pred)),
            "mape_cycles_fraction": float(mape),
            "mape_cycles_percent": float(100.0 * mape),
            "n_train": int(len(X_train)),
            "n_test": int(len(X_test)),
            "features": self.feature_names,
            "numeric_features": self.numeric_features,
            "categorical_features": self.categorical_features,
        }
        self.metadata = {"model_type": self.model_type, "metrics": metrics}
        return metrics

    def _as_frame(self, X):
        if isinstance(X, dict):
            X = pd.DataFrame([X])
        X = X.copy()
        for f in self.feature_names:
            if f not in X.columns:
                X[f] = np.nan
        return X[self.feature_names]

    def predict(self, X):
        if self.pipeline is None:
            raise RuntimeError("Model not trained or loaded.")
        X = self._as_frame(X)
        return 10 ** self.pipeline.predict(X)

    def predict_with_uncertainty(self, X):
        pred = self.predict(X)
        if self.model_type != "rf":
            return {"prediction": pred, "lower_95": pred * 0.8, "upper_95": pred * 1.2}
        X = self._as_frame(X)
        pre = self.pipeline.named_steps["preprocess"]
        rf = self.pipeline.named_steps["model"]
        Xp = pre.transform(X)
        tree_logs = np.asarray([tree.predict(Xp) for tree in rf.estimators_])
        mean = tree_logs.mean(axis=0)
        std = tree_logs.std(axis=0)
        return {
            "prediction": 10 ** mean,
            "lower_95": 10 ** (mean - 1.96 * std),
            "upper_95": 10 ** (mean + 1.96 * std),
        }

    def predict_batch_csv(self, input_csv, output_csv, chunksize=10000):
        input_csv = Path(input_csv)
        output_csv = Path(output_csv)
        first = True
        for chunk in pd.read_csv(input_csv, chunksize=chunksize):
            u = self.predict_with_uncertainty(chunk)
            chunk = chunk.copy()
            chunk["predicted_cycles"] = u["prediction"]
            chunk["lower_95_cycles"] = u["lower_95"]
            chunk["upper_95_cycles"] = u["upper_95"]
            chunk.to_csv(output_csv, mode="w" if first else "a", index=False, header=first)
            first = False
        return str(output_csv)

    def shap_values(self, X):
        if not SHAP_AVAILABLE:
            raise ImportError("Install with: pip install pyfatiguepro[explain]")
        if self.model_type != "rf":
            raise ValueError("SHAP TreeExplainer is implemented for rf model_type.")
        X = self._as_frame(X)
        Xp = self.pipeline.named_steps["preprocess"].transform(X)
        model = self.pipeline.named_steps["model"]
        explainer = shap.TreeExplainer(model)
        vals = explainer.shap_values(Xp)
        return {"shap_values": vals}

    def save(self, path):
        obj = {
            "pipeline": self.pipeline,
            "feature_names": self.feature_names,
            "numeric_features": self.numeric_features,
            "categorical_features": self.categorical_features,
            "metadata": self.metadata,
            "model_type": self.model_type,
            "random_state": self.random_state,
        }
        joblib.dump(obj, path)
        return str(path)

    @classmethod
    def load(cls, path):
        obj = joblib.load(path)
        inst = cls(model_type=obj.get("model_type", "rf"), random_state=obj.get("random_state", 42))
        inst.pipeline = obj["pipeline"]
        inst.feature_names = obj["feature_names"]
        inst.numeric_features = obj.get("numeric_features")
        inst.categorical_features = obj.get("categorical_features")
        inst.metadata = obj.get("metadata", {})
        return inst
