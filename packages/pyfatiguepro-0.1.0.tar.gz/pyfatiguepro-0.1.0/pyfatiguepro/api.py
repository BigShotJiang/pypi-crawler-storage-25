from pathlib import Path
from typing import Optional
import pandas as pd
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel
from .ml import FatigueMLPredictor

app = FastAPI(
    title="PyFatiguePro API",
    description="Fatigue-life prediction API for engineering alloys.",
    version="0.1.0",
)
MODEL_PATH = Path("model.joblib")
_model = None


def get_model():
    global _model
    if _model is None and MODEL_PATH.exists():
        _model = FatigueMLPredictor.load(MODEL_PATH)
    return _model


class FatigueInput(BaseModel):
    material: str = "Inconel718"
    stress_amplitude: float = 600.0
    mean_stress: float = 50.0
    temperature: float = 650.0
    R_ratio: float = 0.1
    frequency: float = 10.0
    grain_size: float = 15.0
    vm_max: Optional[float] = None
    vm_p95: Optional[float] = None
    Al: Optional[float] = None
    Ti: Optional[float] = None
    Ni: Optional[float] = None
    Cr: Optional[float] = None
    Fe: Optional[float] = None
    Co: Optional[float] = None
    Mo: Optional[float] = None
    Nb: Optional[float] = None


@app.get("/")
def home():
    return {"message": "PyFatiguePro API is running", "docs": "/docs"}


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": get_model() is not None}


@app.post("/predict")
def predict(data: FatigueInput):
    model = get_model()
    if model is None:
        return {"error": "No model.joblib found. Run examples/train_demo.py first."}
    x = pd.DataFrame([data.model_dump()])
    u = model.predict_with_uncertainty(x)
    return {
        "predicted_cycles": float(u["prediction"][0]),
        "lower_95_cycles": float(u["lower_95"][0]),
        "upper_95_cycles": float(u["upper_95"][0]),
    }


@app.post("/predict_csv")
async def predict_csv(file: UploadFile = File(...)):
    model = get_model()
    if model is None:
        return {"error": "No model.joblib found. Run examples/train_demo.py first."}
    input_path = Path("uploaded_for_prediction.csv")
    output_path = Path("predictions.csv")
    input_path.write_bytes(await file.read())
    model.predict_batch_csv(input_path, output_path, chunksize=10000)
    return FileResponse(output_path, filename="predictions.csv")
