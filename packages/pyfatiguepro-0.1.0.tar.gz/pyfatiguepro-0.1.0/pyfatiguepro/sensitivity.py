import numpy as np
import pandas as pd


def one_at_a_time_sensitivity(model, base_input, feature_ranges, steps=25):
    records = []
    for feature, bounds in feature_ranges.items():
        low, high = bounds
        for value in np.linspace(low, high, steps):
            sample = dict(base_input)
            sample[feature] = float(value)
            pred = float(np.asarray(model.predict(sample)).ravel()[0])
            records.append({"feature": feature, "value": float(value), "predicted_cycles": pred})
    return pd.DataFrame(records)
