from .core import fit_basquin, basquin_life
from .validation import validation_report


def benchmark_basquin(stress_amplitude, cycles, ml_predictions):
    fit = fit_basquin(stress_amplitude, cycles)
    base_pred = basquin_life(stress_amplitude, fit["sigma_f_prime"], fit["b"])
    return {
        "basquin_parameters": {"sigma_f_prime": fit["sigma_f_prime"], "b": fit["b"]},
        "basquin_metrics": validation_report(cycles, base_pred),
        "ml_metrics": validation_report(cycles, ml_predictions),
    }
