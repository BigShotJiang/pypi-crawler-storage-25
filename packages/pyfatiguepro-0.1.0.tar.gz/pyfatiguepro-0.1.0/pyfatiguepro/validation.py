import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error


def validation_report(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mask = np.isfinite(y_true) & np.isfinite(y_pred) & (y_true > 0) & (y_pred > 0)
    y_true = y_true[mask]
    y_pred = y_pred[mask]
    if len(y_true) == 0:
        raise ValueError("No valid positive y_true/y_pred pairs.")
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100.0
    return {
        "n": int(len(y_true)),
        "MAPE_percent": float(mape),
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "R2": float(r2_score(y_true, y_pred)) if len(y_true) > 1 else None,
        "target": "MAPE < 20% on held-out physical fatigue tests",
        "status": "PASS" if mape < 20.0 else "NEEDS_IMPROVEMENT",
    }


class DataProvenanceRegistry:
    def __init__(self):
        self.records = []

    def add(self, name, material, source_type, reference_or_owner, is_public, notes=""):
        allowed = {"peer_reviewed", "proprietary_experimental", "demo_synthetic", "internal_benchmark"}
        if source_type not in allowed:
            raise ValueError(f"source_type must be one of {allowed}")
        self.records.append({
            "name": name,
            "material": material,
            "source_type": source_type,
            "reference_or_owner": reference_or_owner,
            "is_public": bool(is_public),
            "notes": notes,
        })
        return self

    def to_frame(self):
        return pd.DataFrame(self.records)

    def save_json(self, path):
        Path(path).write_text(json.dumps(self.records, indent=2), encoding="utf-8")


class ProprietaryDataValidator:
    def __init__(self, required_columns=None):
        self.required_columns = required_columns or ["stress_amplitude", "cycles"]

    def validate_schema(self, df):
        missing = [c for c in self.required_columns if c not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        return True

    def quality_report(self, df):
        self.validate_schema(df)
        report = {
            "n_rows": int(len(df)),
            "n_columns": int(df.shape[1]),
            "duplicate_rows": int(df.duplicated().sum()),
            "missing_by_column": {k: int(v) for k, v in df.isna().sum().to_dict().items()},
            "numeric_columns": list(df.select_dtypes(include=[np.number]).columns),
        }
        if "cycles" in df.columns:
            cycles = pd.to_numeric(df["cycles"], errors="coerce")
            report["invalid_cycles"] = int(((cycles <= 0) | (~np.isfinite(cycles))).sum())
        if "stress_amplitude" in df.columns:
            stress = pd.to_numeric(df["stress_amplitude"], errors="coerce")
            report["invalid_stress_amplitude"] = int(((stress <= 0) | (~np.isfinite(stress))).sum())
        return report

    def anonymize(self, df, sensitive_columns=None, salt="pyfatiguepro"):
        df = df.copy()
        sensitive_columns = sensitive_columns or [
            "specimen_id", "project", "customer", "supplier", "batch_id", "heat_number", "program"
        ]
        for col in sensitive_columns:
            if col in df.columns:
                df[col] = df[col].astype(str).apply(
                    lambda x: hashlib.sha256((salt + x).encode()).hexdigest()[:16]
                )
        return df

    def clean_for_training(self, df, target_col="cycles", make_log_target=True):
        df = df.copy()
        self.validate_schema(df)
        df = df.drop_duplicates()
        numeric_cols = list(df.select_dtypes(include=[np.number]).columns)
        df[numeric_cols] = df[numeric_cols].replace([np.inf, -np.inf], np.nan)
        if target_col not in df.columns:
            raise ValueError(f"Missing target_col: {target_col}")
        df[target_col] = pd.to_numeric(df[target_col], errors="coerce")
        df = df[df[target_col] > 0]
        if make_log_target:
            df["log_life"] = np.log10(df[target_col])
        return df
