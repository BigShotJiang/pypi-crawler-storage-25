from pathlib import Path
import pandas as pd
from .core import von_mises_stress


class FEAIngestor:
    """Read FEA stress exports and generate fatigue-ready hotspot features."""

    STRESS_MAP = {
        "S11": "s11", "S22": "s22", "S33": "s33",
        "S12": "s12", "S23": "s23", "S13": "s13",
        "sigma_x": "s11", "sigma_y": "s22", "sigma_z": "s33",
        "tau_xy": "s12", "tau_yz": "s23", "tau_zx": "s13",
    }
    REQUIRED = ["s11", "s22", "s33", "s12", "s23", "s13"]

    def read_csv(self, path):
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(path)
        df = pd.read_csv(path)
        return self.normalize_columns(df)

    def normalize_columns(self, df):
        df = df.copy()
        rename = {c: self.STRESS_MAP[c] for c in df.columns if c in self.STRESS_MAP}
        return df.rename(columns=rename)

    def add_von_mises(self, df):
        df = self.normalize_columns(df)
        missing = [c for c in self.REQUIRED if c not in df.columns]
        if missing:
            raise ValueError(f"Missing FEA stress columns: {missing}")
        df = df.copy()
        df["von_mises"] = von_mises_stress(
            df["s11"], df["s22"], df["s33"], df["s12"], df["s23"], df["s13"]
        )
        return df

    def aggregate_hotspots(self, df, group_col=None, top_fraction=0.05):
        if not (0 < top_fraction <= 1):
            raise ValueError("top_fraction must be between 0 and 1.")
        df = self.add_von_mises(df) if "von_mises" not in df.columns else df.copy()
        if group_col and group_col in df.columns:
            return df.groupby(group_col).agg(
                vm_max=("von_mises", "max"),
                vm_mean=("von_mises", "mean"),
                vm_p95=("von_mises", lambda x: x.quantile(0.95)),
                vm_p99=("von_mises", lambda x: x.quantile(0.99)),
                n_points=("von_mises", "size"),
            ).reset_index()
        cutoff = df["von_mises"].quantile(1.0 - top_fraction)
        hot = df[df["von_mises"] >= cutoff]
        return pd.DataFrame([{
            "vm_max": float(hot["von_mises"].max()),
            "vm_mean": float(hot["von_mises"].mean()),
            "vm_p95": float(hot["von_mises"].quantile(0.95)),
            "vm_p99": float(hot["von_mises"].quantile(0.99)),
            "n_points": int(len(hot)),
        }])

    def merge_fea_with_tests(self, test_df, fea_features, key="specimen_id"):
        if key in test_df.columns and key in fea_features.columns:
            return test_df.merge(fea_features, on=key, how="left")
        raise ValueError(f"Merge key '{key}' must exist in both test_df and fea_features.")
