"""Packaged training implementation shared by the CLI and legacy script."""

import argparse
import json
import math
import os
import sys
from datetime import datetime

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from src.data.enhanced_splitting import EnhancedDataSplitter
from src.data.dataset import DataLoaderManager
from src.data.fusion_dataset import FusionPatientDataset
from src.data.preprocessing import resolve_axis_data_paths
from src.data.testset_export import export_prediction_ready_testset
from src.training.axis_trainer import AxisTrainer
from src.training.fusion_trainer import FusionTrainer, resolve_axis_checkpoints
from src.utils.config import load_config, runtime_config_display_sections
from src.utils.logger import get_logger
from src.utils.rich_display import print_rich_training_config, print_rich_training_results


def get_training_stage(args) -> str:
    return str(getattr(args, "stage", None) or "axis").strip().lower()


def get_training_axis(args) -> str | None:
    axis = getattr(args, "axis", None)
    if axis is None:
        return None
    return str(axis).strip().lower()


def _resolve_axis_stage_data_path(config, axis: str, override_path: str | None = None) -> str:
    if override_path:
        return override_path

    axis_data_paths = resolve_axis_data_paths(
        getattr(config.multi_axis, "axis_data_paths", {}),
        base_data_path=getattr(config.data, "data_path", None),
    )
    if axis not in axis_data_paths:
        raise ValueError(f"Axis {axis!r} is not configured in multi_axis.axis_data_paths")
    return axis_data_paths[axis]


def configure_stage_runtime(config, args):
    stage = get_training_stage(args)
    axis = get_training_axis(args)

    setattr(config.experiment, "runtime_stage", stage)
    setattr(config.experiment, "runtime_axis", axis)

    if stage == "fusion":
        config.multi_axis.enabled = True
    else:
        config.multi_axis.enabled = False
        if axis:
            config.multi_axis.active_axes = [axis]

    return stage, axis


def resolve_runtime_data_paths(config, args):
    stage, axis = configure_stage_runtime(config, args)

    if stage == "axis" and axis:
        data_path = _resolve_axis_stage_data_path(config, axis, getattr(args, "data_path", None))
    else:
        data_path = getattr(args, "data_path", None) or getattr(config.data, "data_path", None)

    label_path = getattr(args, "label_path", None) or getattr(config.data, "label_path", None)

    args.data_path = data_path
    args.label_path = label_path
    config.data.data_path = data_path
    config.data.label_path = label_path

    return stage, axis


def export_testset_snapshot(splitter, config, args, logger):
    experiment_dir = os.path.dirname(config.experiment.result_dir)
    test_labels = {
        patient_id: splitter.labels[patient_id]
        for patient_id in splitter.test_patients
        if patient_id in splitter.labels
    }
    active_axes = getattr(getattr(config, "multi_axis", None), "active_axes", ["x", "y", "z"])
    export_dir = export_prediction_ready_testset(
        experiment_dir=experiment_dir,
        experiment_name=config.experiment.name,
        test_patients=splitter.test_patients,
        labels=test_labels,
        organizer=splitter.organizer,
        source_data_path=args.data_path,
        active_axes=active_axes,
        logger=logger,
    )
    logger.info(f"测试集预测快照已导出到: {export_dir}")
    return export_dir


def _prepare_and_export_split(splitter: EnhancedDataSplitter, config, args, logger):
    split_method = "stratified"
    config.train_split.method = split_method

    # 检查是否使用CSV数据加载（仅stratified模式支持）
    csv_path = getattr(config.train_split, 'train_split_csv_path', None)
    use_csv = csv_path is not None and csv_path.strip() != ''

    # 检查是否使用CSV直接模式
    use_csv_direct = getattr(config.train_split, 'use_csv_direct', False)

    # 验证参数组合
    if use_csv_direct and not use_csv:
        raise ValueError("--use_csv_direct 需要 --train_split_csv 参数")

    if use_csv:
        logger.info("检测到CSV数据集配置")
        logger.info(f"CSV文件路径: {csv_path}")
        logger.info(f"CSV使用模式: {'直接使用' if use_csv_direct else '重新划分'}")

        try:
            if use_csv_direct:
                # 直接使用CSV划分，不重新分割
                result = splitter.load_all_splits_from_csv(csv_path, logger)

                # 复制原始CSV到结果目录
                import shutil
                original_csv_name = os.path.basename(csv_path)
                copied_csv_path = os.path.join(config.experiment.result_dir, f"original_{original_csv_name}")
                shutil.copy2(csv_path, copied_csv_path)
                logger.info(f"原始CSV文件已复制到: {copied_csv_path}")

                # 更新结果信息
                result['csv_info']['csv_path'] = csv_path
                result['csv_info']['copied_csv_path'] = copied_csv_path

                # 设置兼容参数
                total_patients = len(splitter.train_patients) + len(splitter.val_patients) + len(splitter.test_patients)
                split_params = {
                    'train_ratio': len(splitter.train_patients) / total_patients,
                    'val_ratio': len(splitter.val_patients) / total_patients,
                    'test_ratio': len(splitter.test_patients) / total_patients,
                    'random_seed': None
                }
            else:
                # 原有行为：加载train数据并重新分割
                train_patients = splitter.load_from_csv(csv_path, logger)

                csv_split_seed = getattr(config.train_split, 'csv_split_random_seed', 42)
                train_ratio = getattr(config.train_split, 'train_ratio', 0.8)
                val_ratio = getattr(config.train_split, 'val_ratio', 0.2)

                result = splitter.resplit_loaded_data(
                    train_patients=train_patients,
                    train_ratio=train_ratio,
                    val_ratio=val_ratio,
                    random_seed=csv_split_seed,
                    logger=logger
                )

                result['csv_info']['csv_path'] = csv_path

                split_params = {
                    'train_ratio': train_ratio,
                    'val_ratio': val_ratio,
                    'test_ratio': 0.0,
                    'random_seed': csv_split_seed
                }

            logger.info("CSV数据处理完成")
        except Exception as e:
            logger.error(f"CSV数据处理失败: {str(e)}")
            logger.info("回退到正常的数据集分割模式")
            use_csv = False
            use_csv_direct = False

    if not use_csv:
        # 正常的数据分割流程
        logger.info("使用正常的数据集分割流程")

        split_params = {
            'train_ratio': getattr(config.train_split, 'train_ratio', 0.8),
            'val_ratio': getattr(config.train_split, 'val_ratio', 0.1),
            'test_ratio': getattr(config.train_split, 'test_ratio', 0.1),
            'random_seed': getattr(config.train_split, 'random_seed', 42)
        }

        result = splitter.split_data(method=split_method, **split_params)

    # 导出分割信息到CSV
    if getattr(config.train_split, 'export_split_info', True):
        experiment_name = args.experiment_name or config.experiment.name
        split_filename = getattr(config.train_split, 'split_filename', 'train_split.csv')
        output_dir = config.experiment.result_dir

        if use_csv_direct:
            # 直接使用模式，使用复制的原始CSV
            logger.info("直接使用CSV模式，使用复制的原始CSV文件")
            original_csv_name = os.path.basename(csv_path)
            csv_path = os.path.join(output_dir, f"original_{original_csv_name}")
        else:
            csv_path = os.path.join(output_dir, split_filename)
            csv_path = splitter.export_split_to_csv(csv_path, experiment_name)
            logger.info(f"数据集划分信息已导出到: {csv_path}")

        # 如果使用了CSV加载，额外导出CSV加载信息
        if use_csv and 'csv_info' in result:
            csv_info_filename = f"csv_load_info_{experiment_name}.json"
            csv_info_path = os.path.join(output_dir, csv_info_filename)
            with open(csv_info_path, 'w', encoding='utf-8') as f:
                import json
                json.dump(result['csv_info'], f, indent=2, ensure_ascii=False, default=str)
            logger.info(f"CSV加载信息已导出到: {csv_info_path}")

        # 保存分割信息供预训练模型评估使用
        if use_csv and 'csv_info' in result:
            split_info_path = splitter.save_split_info(config.experiment.result_dir, config.experiment.name, is_csv_direct=use_csv_direct)
            logger.info(f"数据分割信息已保存到: {split_info_path}")

    export_testset_snapshot(splitter, config, args, logger)


def train_with_split(splitter: EnhancedDataSplitter, config, args, logger):
    """
    使用指定分割进行训练
    """
    _prepare_and_export_split(splitter, config, args, logger)

    return train_single_split(splitter, config, args, logger)


def _train_single_split_impl(
    splitter: EnhancedDataSplitter,
    config,
    args,
    logger,
    trainer_cls,
    *,
    result_type: str,
    stage_name: str,
    axis: str | None = None,
):
    logger.info(f"开始{stage_name}")

    # 获取内存预加载配置
    enable_memory_preload = getattr(config.data, 'enable_memory_preload', True)
    preload_batch_size = getattr(config.data, 'preload_batch_size', None)
    preload_verbose = getattr(config.data, 'preload_verbose', True)

    logger.info(f"内存预加载配置: {'启用' if enable_memory_preload else '禁用'}")
    if enable_memory_preload:
        logger.info(f"  预加载批次大小: {preload_batch_size if preload_batch_size else '全部加载'}")
        logger.info(f"  详细输出: {preload_verbose}")

    # 使用预分割的患者列表，避免重复分割
    pre_split_patients = {
        'train': splitter.train_patients,
        'val': splitter.val_patients,
        'test': splitter.test_patients
    }

    # 创建数据加载器（使用预分割的患者列表）
    data_manager = DataLoaderManager(
        data_path=args.data_path,
        label_path=args.label_path,
        batch_size=getattr(config.training, 'batch_size', 8),
        num_workers=getattr(config.training, 'num_workers', 4),
        pin_memory=getattr(config.data, 'pin_memory', True),
        patch_size=getattr(config.data, 'patch_size', [16, 16]),
        enable_memory_preload=enable_memory_preload,
        preload_batch_size=preload_batch_size,
        preload_verbose=preload_verbose,
        pre_split_patients=pre_split_patients  # 使用预分割的患者列表
    )

    # 打印分割统计信息
    dataset_info = data_manager.get_dataset_info()
    logger.info("数据集分割统计:")
    for split_name, stats in dataset_info.items():
        if stats['samples'] > 0:
            logger.info(f"  {split_name}: {stats['patients']} 患者, "
                       f"{stats['samples']} 样本, "
                       f"阳性 {stats['positive_samples']} ({stats['positive_samples']/stats['samples']:.2%}), "
                       f"阴性 {stats['negative_samples']} ({stats['negative_samples']/stats['samples']:.2%})")
        else:
            logger.info(f"  {split_name}: {stats['patients']} 患者, "
                       f"{stats['samples']} 样本, (空数据集)")

    # 获取数据加载器
    train_loader = data_manager.get_train_dataloader()
    val_loader = data_manager.get_val_dataloader()
    test_loader = data_manager.get_test_dataloader()

    # 创建训练器并训练
    # 优先使用命令行参数，如果没有提供（None）则使用配置文件中的值
    pre_model_path = args.pre_model if args.pre_model is not None else getattr(config.training, 'pretrained_model_path', None)
    load_weights_only = bool(args.load_weights_only or getattr(config.training, 'load_weights_only', False))
    strict_load = bool(args.strict_load or getattr(config.training, 'strict_load', False))

    freeze_layers, freeze_ratio = resolve_freeze_settings(config, args)

    trainer = trainer_cls(
        config,
        logger,
        pre_model_path=pre_model_path,
        load_weights_only=load_weights_only,
        strict_load=strict_load,
        freeze_layers=freeze_layers,
        freeze_ratio=freeze_ratio,
    )
    train_history, val_history = trainer.train(train_loader, val_loader)

    # 检查测试集有效性并进行测试
    test_metrics = {}

    # 对于stratified模式，如果配置了test_ratio: 0，直接跳过测试评估
    split_method = getattr(config.train_split, 'method', 'cv')
    test_ratio = getattr(config.train_split, 'test_ratio', 0)

    if split_method == 'stratified' and test_ratio == 0:
        logger.info("Stratified模式配置了test_ratio: 0，跳过测试评估")
        test_metrics = {
            'accuracy': float('nan'),
            'precision': float('nan'),
            'recall': float('nan'),
            'f1': float('nan'),
            'auc': float('nan'),
            'true_negative': 0,
            'false_positive': 0,
            'false_negative': 0,
            'true_positive': 0,
            'specificity': float('nan'),
            'sensitivity': float('nan'),
            'loss': float('nan')
        }
    else:
        try:
            # 检查测试集是否为空
            if len(test_loader.dataset) == 0:
                logger.warning("测试集为空，跳过测试评估")
                test_metrics = {
                    'accuracy': float('nan'),
                    'precision': float('nan'),
                    'recall': float('nan'),
                    'f1': float('nan'),
                    'auc': float('nan'),
                    'true_negative': 0,
                    'false_positive': 0,
                    'false_negative': 0,
                    'true_positive': 0,
                    'specificity': float('nan'),
                    'sensitivity': float('nan'),
                    'loss': float('nan')
                }
            else:
                # 检查测试集标签分布
                test_labels = [sample[1] for sample in test_loader.dataset.samples]
                unique_labels = set(test_labels)
                if len(unique_labels) <= 1:
                    logger.warning(f"测试集只包含单一类别: {list(unique_labels)}，测试结果可能不可靠")
                    logger.warning("建议重新分配数据集，确保测试集包含正负两类样本")

                # 进行测试评估
                test_metrics = trainer.evaluate(test_loader)

        except Exception as e:
            logger.error(f"测试评估失败: {str(e)}")
            logger.warning("使用默认的测试指标")
            test_metrics = {
                'accuracy': float('nan'),
                'precision': float('nan'),
                'recall': float('nan'),
                'f1': float('nan'),
                'auc': float('nan'),
                'true_negative': 0,
                'false_positive': 0,
                'false_negative': 0,
                'true_positive': 0,
                'specificity': float('nan'),
                'sensitivity': float('nan'),
                'loss': float('nan')
            }

    logger.info(f"{stage_name}完成!")
    if any(not str(v).startswith('nan') and v != 0 for v in test_metrics.values()):
        logger.info(f"测试结果: {test_metrics}")
    else:
        logger.warning("测试集评估无效或失败")

    result = {
        'type': result_type,
        'test_metrics': test_metrics,
        'train_history': train_history,
        'val_history': val_history,
    }
    if axis is not None:
        result['axis'] = axis
    return result


def train_single_split(splitter: EnhancedDataSplitter, config, args, logger):
    """
    单次分割训练
    """
    from src.training.trainer import Trainer

    return _train_single_split_impl(
        splitter,
        config,
        args,
        logger,
        Trainer,
        result_type='single_split',
        stage_name='单次分割训练',
    )


def train_axis(splitter: EnhancedDataSplitter, config, args, logger, axis: str):
    axis = axis.strip().lower()
    config.multi_axis.enabled = False
    config.multi_axis.active_axes = [axis]
    args.data_path = _resolve_axis_stage_data_path(config, axis, getattr(args, "data_path", None))
    config.data.data_path = args.data_path

    _prepare_and_export_split(splitter, config, args, logger)

    return _train_single_split_impl(
        splitter,
        config,
        args,
        logger,
        AxisTrainer,
        result_type='axis',
        stage_name=f'轴向训练({axis})',
        axis=axis,
    )


def train_fusion(splitter: EnhancedDataSplitter, config, args, logger):
    logger.info("开始融合阶段训练")
    config.multi_axis.enabled = True

    _prepare_and_export_split(splitter, config, args, logger)

    active_axes = list(getattr(config.multi_axis, "active_axes", ["x", "y", "z"]))
    axis_checkpoint_paths = resolve_axis_checkpoints(
        save_dir=config.experiment.save_dir,
        experiment_name=config.experiment.name,
        overrides={
            axis: getattr(args, f"axis_checkpoint_{axis}", None)
            for axis in active_axes
        },
        active_axes=active_axes,
    )

    dataset_kwargs = {
        "axis_data_paths": config.multi_axis.axis_data_paths,
        "label_path": args.label_path,
        "active_axes": active_axes,
    }
    train_dataset = FusionPatientDataset(patient_ids=splitter.train_patients, **dataset_kwargs)
    val_dataset = FusionPatientDataset(patient_ids=splitter.val_patients, **dataset_kwargs)
    test_dataset = FusionPatientDataset(patient_ids=splitter.test_patients, **dataset_kwargs)

    trainer = FusionTrainer(config=config, axis_checkpoint_paths=axis_checkpoint_paths, logger=logger)
    train_history, val_history = trainer.train(train_dataset, val_dataset)

    if len(test_dataset) > 0:
        test_metrics = trainer.evaluate(test_dataset)
    else:
        test_metrics = {
            "accuracy": float("nan"),
            "precision": float("nan"),
            "recall": float("nan"),
            "f1": float("nan"),
            "auc": float("nan"),
            "loss": float("nan"),
        }

    return {
        "type": "fusion",
        "train_history": train_history,
        "val_history": val_history,
        "test_metrics": test_metrics,
        "axis_checkpoint_paths": axis_checkpoint_paths,
        "final_summary": "",
    }


def dispatch_training(splitter, config, args, logger):
    stage = get_training_stage(args)
    axis = get_training_axis(args)

    if stage == "fusion":
        return train_fusion(splitter, config, args, logger)
    if stage == "axis" and axis is not None:
        return train_axis(splitter, config, args, logger, axis=axis)
    return train_with_split(splitter, config, args, logger)


def build_parser():
    parser = argparse.ArgumentParser(description="ViT医学影像分类 - stage-aware 训练入口")
    parser.add_argument("--stage", type=str, default="axis", choices=["axis", "fusion"], help="训练阶段")
    parser.add_argument("--axis", type=str, default=None, choices=["x", "y", "z"], help="axis 阶段训练轴")
    parser.add_argument("--data_path", type=str, default=None, help="数据路径覆盖项")
    parser.add_argument("--label_path", type=str, default=None, help="标签文件路径覆盖项")
    parser.add_argument("--config_path", type=str, default="configs/", help="配置文件路径")
    parser.add_argument("--experiment_name", type=str, default=None, help="实验名称（覆盖配置文件）")
    parser.add_argument("--random_seed", type=int, default=None, help="随机种子（覆盖配置文件）")
    parser.add_argument("--epochs", type=int, default=None, help="训练轮数（覆盖配置文件）")
    parser.add_argument("--batch_size", type=int, default=None, help="批次大小（覆盖配置文件）")
    parser.add_argument("--device", type=str, default=None, help="训练设备（覆盖配置文件）")
    parser.add_argument("--verbose", action="store_true", help="显示详细终端日志；未指定时仅保留 tqdm 动态进度。")
    parser.add_argument(
        "--resume",
        action="store_true",
        default=False,
        help="恢复训练，默认从 latest_model.pth 继续。",
    )
    parser.add_argument("--disable_memory_preload", action="store_true", default=False, help="禁用默认启用的内存预加载")
    parser.add_argument("--preload_batch_size", type=int, default=None, help="预加载批次大小（覆盖配置文件）")
    parser.add_argument(
        "--train_split_csv",
        type=str,
        default=None,
        help="指定预先划分好的数据集CSV文件路径，仅保留 stratified 主线",
    )
    parser.add_argument("--csv_split_seed", type=int, default=None, help="CSV数据重新划分的随机种子")
    parser.add_argument(
        "--use_csv_direct",
        action="store_true",
        help="直接使用CSV文件中的数据集划分，不进行重新划分（需要与 --train_split_csv 一起使用）",
    )
    parser.add_argument("--pre_model", type=str, default=None, help="预训练模型路径，支持 .pth/checkpoint")
    parser.add_argument("--axis_checkpoint_x", type=str, default=None, help="fusion 阶段 x 轴 checkpoint 覆盖项")
    parser.add_argument("--axis_checkpoint_y", type=str, default=None, help="fusion 阶段 y 轴 checkpoint 覆盖项")
    parser.add_argument("--axis_checkpoint_z", type=str, default=None, help="fusion 阶段 z 轴 checkpoint 覆盖项")
    parser.add_argument("--freeze_layers", type=str, default=None, help="指定冻结的层")
    parser.add_argument("--freeze_ratio", type=float, default=None, help="按比例冻结层，0-1之间")
    parser.add_argument("--load_weights_only", action="store_true", default=False, help="仅加载模型权重")
    parser.add_argument("--strict_load", action="store_true", default=False, help="严格加载预训练权重")
    return parser


def parse_args(argv=None):
    return build_parser().parse_args(argv)


def normalize_args(raw_args):
    if isinstance(raw_args, argparse.Namespace):
        return raw_args
    if isinstance(raw_args, dict):
        defaults = vars(parse_args([]))
        defaults.update(raw_args)
        return argparse.Namespace(**defaults)
    if raw_args is None:
        return parse_args()
    return parse_args(raw_args)


def print_training_config_snapshot(config):
    line = "=" * 80
    print(line)
    print("TRAINING CONFIG")
    print(line)
    display_sections = runtime_config_display_sections(config)
    for section_name, section_items in display_sections.items():
        print(section_name)
        if isinstance(section_items, dict):
            for key, value in section_items.items():
                print(f"  {key}: {value}")
        print("-" * 80)


def resolve_runtime_output_settings(config, args):
    progress_enabled = bool(getattr(getattr(config, "monitoring", None), "verbose", False))
    console_verbose = bool(getattr(args, "verbose", False))
    training_config = getattr(config, "training", None)
    common_training = getattr(training_config, "common", training_config)
    device = str(getattr(common_training, "device", "")).lower()

    if console_verbose and hasattr(config, "monitoring"):
        config.monitoring.verbose = True
        progress_enabled = True

    if hasattr(config, "monitoring"):
        setattr(config.monitoring, "console_verbose", console_verbose)

    if hasattr(config, "data") and hasattr(config.data, "preload_verbose"):
        config.data.preload_verbose = console_verbose
    if hasattr(config, "data") and hasattr(config.data, "pin_memory") and device.startswith("cpu"):
        config.data.pin_memory = False

    return progress_enabled, console_verbose


def resolve_freeze_settings(config, args):
    configured_freeze_method = getattr(config.training, 'freeze_method', 'none')
    configured_freeze_layers = getattr(config.training, 'freeze_layers', '') or None
    configured_freeze_ratio = getattr(config.training, 'freeze_ratio', None)

    if args.freeze_layers is not None:
        return args.freeze_layers, None
    if args.freeze_ratio is not None:
        return None, args.freeze_ratio
    if configured_freeze_method == 'layers':
        return configured_freeze_layers, None
    if configured_freeze_method == 'ratio':
        return None, configured_freeze_ratio
    return None, None


def apply_training_overrides(config, args):
    stage, axis = configure_stage_runtime(config, args)
    common_training = getattr(config.training, "common", config.training)
    stage_training = getattr(config.training, stage, config.training)

    if hasattr(args, "data_path") and args.data_path:
        config.data.data_path = args.data_path
    if hasattr(args, "label_path") and args.label_path:
        config.data.label_path = args.label_path
    if args.experiment_name:
        config.experiment.name = args.experiment_name
    config.train_split.method = "stratified"
    if args.random_seed is not None:
        config.train_split.random_seed = args.random_seed
    if args.epochs is not None:
        stage_training.epochs = args.epochs
    if args.batch_size is not None:
        stage_training.batch_size = args.batch_size
    if args.device:
        common_training.device = args.device
    if hasattr(config, "monitoring") and args.verbose:
        config.monitoring.verbose = True

    if args.disable_memory_preload:
        config.data.enable_memory_preload = False
    elif not hasattr(config.data, "enable_memory_preload"):
        config.data.enable_memory_preload = True
    if args.preload_batch_size is not None:
        config.data.preload_batch_size = args.preload_batch_size

    if args.train_split_csv:
        config.train_split.train_split_csv_path = args.train_split_csv
    if args.csv_split_seed is not None:
        config.train_split.csv_split_random_seed = args.csv_split_seed
    if args.use_csv_direct:
        config.train_split.use_csv_direct = True

    if stage == "axis":
        if args.pre_model:
            stage_training.pretrained_model_path = args.pre_model
        if args.freeze_layers:
            stage_training.freeze_layers = args.freeze_layers
        if args.freeze_ratio is not None:
            stage_training.freeze_ratio = args.freeze_ratio
        if args.load_weights_only:
            stage_training.load_weights_only = True
        if args.strict_load:
            stage_training.strict_load = True

    # Loss function overrides
    loss_config = getattr(stage_training, "loss", None)
    if hasattr(args, "loss_type") and args.loss_type:
        if not loss_config:
            loss_config = {}
            stage_training.loss = loss_config
        loss_config["type"] = args.loss_type
    if hasattr(args, "focal_alpha") and args.focal_alpha is not None:
        if not loss_config:
            loss_config = {}
            stage_training.loss = loss_config
        loss_config["focal_alpha"] = args.focal_alpha
    if hasattr(args, "focal_gamma") and args.focal_gamma is not None:
        if not loss_config:
            loss_config = {}
            stage_training.loss = loss_config
        loss_config["focal_gamma"] = args.focal_gamma
    if hasattr(args, "label_smoothing") and args.label_smoothing is not None:
        if not loss_config:
            loss_config = {}
            stage_training.loss = loss_config
        loss_config["label_smoothing"] = args.label_smoothing
    if hasattr(args, "pos_weight") and args.pos_weight is not None:
        if not loss_config:
            loss_config = {}
            stage_training.loss = loss_config
        loss_config["pos_weight"] = args.pos_weight


def prepare_experiment_directories(config):
    if not hasattr(config.experiment, 'name') or not config.experiment.name:
        config.experiment.name = f"vit_experiment_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    base_experiment_dir = os.path.join(config.experiment.save_dir, config.experiment.name)
    runtime_stage = getattr(config.experiment, "runtime_stage", "axis")
    runtime_axis = getattr(config.experiment, "runtime_axis", None)

    if runtime_stage == "fusion":
        experiment_dir = os.path.join(base_experiment_dir, "fusion")
    elif runtime_axis:
        experiment_dir = os.path.join(base_experiment_dir, f"axis-{runtime_axis}")
    else:
        experiment_dir = base_experiment_dir

    experiment_logs_dir = os.path.join(experiment_dir, 'logs')
    experiment_checkpoints_dir = os.path.join(experiment_dir, 'checkpoints')
    experiment_results_dir = os.path.join(experiment_dir, 'results')

    os.makedirs(experiment_logs_dir, exist_ok=True)
    os.makedirs(experiment_checkpoints_dir, exist_ok=True)
    os.makedirs(experiment_results_dir, exist_ok=True)

    config.experiment.log_dir = experiment_logs_dir
    config.experiment.checkpoint_dir = experiment_checkpoints_dir
    config.experiment.result_dir = experiment_results_dir
    return experiment_dir


_METRIC_ALIASES = {
    "val_loss": "loss",
    "val_auc": "auc",
    "val_accuracy": "accuracy",
    "val_f1": "f1",
    "predict_accuracy": "predict_accuracy",
}


def _is_finite_metric(value) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return math.isfinite(float(value))


def _resolve_summary_metric(metrics, metric_name: str):
    if metric_name in metrics and _is_finite_metric(metrics[metric_name]):
        return float(metrics[metric_name])

    alias = _METRIC_ALIASES.get(metric_name, metric_name)
    value = metrics.get(alias)
    if _is_finite_metric(value):
        return float(value)
    return None


def _build_final_metric_summary(config, results) -> list[str]:
    summary_lines = []
    model_selection = getattr(config.monitoring, "model_selection", {}) or {}
    if not isinstance(model_selection, dict):
        model_selection = dict(model_selection)
    selection_metric = model_selection.get("metric", "predict_accuracy")
    selection_mode = model_selection.get("mode", "max")

    val_history = results.get("val_history", []) or []
    best_epoch = None
    best_value = None
    for epoch_index, metrics in enumerate(val_history, start=1):
        if not isinstance(metrics, dict):
            continue
        current_value = _resolve_summary_metric(metrics, selection_metric)
        if current_value is None:
            continue
        if best_value is None:
            best_epoch = epoch_index
            best_value = current_value
            continue
        if selection_mode == "min":
            if current_value < best_value:
                best_epoch = epoch_index
                best_value = current_value
        elif current_value > best_value:
            best_epoch = epoch_index
            best_value = current_value

    if best_value is not None and best_epoch is not None:
        summary_lines.append(f"最佳验证指标: {selection_metric}={best_value:.4f} (Epoch {best_epoch})")

    test_metrics = results.get("test_metrics", {}) or {}
    metric_parts = []
    for metric_name in ("predict_accuracy", "accuracy", "precision", "recall", "f1", "auc", "loss"):
        metric_value = _resolve_summary_metric(test_metrics, metric_name)
        if metric_value is None:
            continue
        metric_parts.append(f"{metric_name}={metric_value:.4f}")
    if metric_parts:
        summary_lines.append("测试指标: " + ", ".join(metric_parts))

    return summary_lines


def execute_train_args(raw_args):
    args = normalize_args(raw_args)
    logger = None

    try:
        config = load_config(args.config_path)
        apply_training_overrides(config, args)
        _, console_verbose = resolve_runtime_output_settings(config, args)
        stage, _ = resolve_runtime_data_paths(config, args)
        experiment_dir = prepare_experiment_directories(config)

        logger = get_logger(
            config.experiment.name,
            config.experiment.log_dir,
            console=console_verbose and stage != "fusion",
        )

        print_rich_training_config(config)

        import time
        start_time = time.time()
        splitter = EnhancedDataSplitter(args.data_path, args.label_path, config)
        results = dispatch_training(splitter, config, args, logger)
        duration = time.time() - start_time

        final_results_file = os.path.join(config.experiment.result_dir, 'final_results.json')
        with open(final_results_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False, default=str)

        if stage == "fusion":
            final_summary = results.get("final_summary", "")
            if final_summary:
                print(final_summary)
            print(f"final_results: {os.path.abspath(final_results_file)}")
            logger.flush()
            return 0

        print_rich_training_results(config, results, duration)
        logger.flush()
        return 0
    except Exception as e:
        if logger:
            logger.error(f"训练过程中发生错误: {str(e)}")
            logger.flush()
        print(f"训练过程中发生错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


def main(argv=None):
    try:
        return execute_train_args(parse_args(argv))
    except Exception as exc:
        print(f"训练过程中发生错误: {exc}")
        import traceback
        traceback.print_exc()
        return 1
