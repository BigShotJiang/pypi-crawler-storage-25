"""Tests for whitelist-driven config display sections."""
import pytest
from src.utils.config import Config, runtime_config_display_sections


@pytest.fixture
def test_config():
    return Config("configs/test")


@pytest.fixture
def test_config_fusion(test_config):
    test_config.experiment.runtime_stage = "fusion"
    return test_config


class TestDisplaySectionWhitelist:
    def test_model_config_only_shows_whitelisted_fields(self, test_config):
        sections = runtime_config_display_sections(test_config)
        model = sections["MODEL CONFIG"]
        expected_keys = {
            "name", "ndim", "input_shape", "patch_size", "num_classes",
            "dim", "depth", "heads", "mlp_dim", "channels", "dim_head",
            "dropout", "emb_dropout", "rope_min_freq", "rope_max_freq", "rope_p_zero_freqs",
        }
        assert set(model.keys()) == expected_keys

    def test_data_config_only_shows_whitelisted_fields(self, test_config):
        sections = runtime_config_display_sections(test_config)
        data = sections["DATA CONFIG"]
        expected_keys = {"pin_memory", "enable_memory_preload", "preload_batch_size", "preload_verbose"}
        assert set(data.keys()) == expected_keys

    def test_training_config_merges_common_and_axis_stage(self, test_config):
        sections = runtime_config_display_sections(test_config)
        training = sections["TRAINING CONFIG"]
        assert "device" in training
        assert "num_workers" in training
        assert "epochs" in training
        assert "learning_rate" in training
        assert "batch_size" in training
        assert "freeze_encoders" not in training

    def test_training_config_fusion_stage_includes_freeze_encoders(self, test_config_fusion):
        sections = runtime_config_display_sections(test_config_fusion)
        training = sections["TRAINING CONFIG"]
        assert "freeze_encoders" in training

    def test_multi_axis_config_flattens_nested_objects(self, test_config):
        sections = runtime_config_display_sections(test_config)
        ma = sections["MULTI-AXIS CONFIG"]
        assert "patient_pooling" not in ma
        assert "weighted_vote" not in ma
        assert "fusion_head" not in ma
        assert "patient_pooling.image_feature_pooling" in ma
        assert "patient_pooling.image_probability_pooling" in ma
        assert "weighted_vote.enabled" in ma
        assert "weighted_vote.weights" in ma
        assert "fusion_head.enabled" in ma
        assert "fusion_head.type" in ma
        assert "fusion_head.hidden_dim" in ma
        assert "fusion_head.dropout" in ma

    def test_experiment_config_has_expected_fields(self, test_config):
        sections = runtime_config_display_sections(test_config)
        exp = sections["EXPERIMENT CONFIG"]
        expected_keys = {
            "name", "version", "save_dir", "log_dir", "checkpoint_dir", "result_dir",
            "log_every_n_steps", "val_check_interval", "save_top_k",
        }
        assert set(exp.keys()) == expected_keys

    def test_monitoring_config_structure(self, test_config):
        sections = runtime_config_display_sections(test_config)
        mon = sections["MONITORING CONFIG"]
        assert "early_stopping" in mon
        assert "model_selection" in mon
        assert "verbose" in mon
