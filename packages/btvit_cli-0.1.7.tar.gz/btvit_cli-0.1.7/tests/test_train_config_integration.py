from __future__ import annotations

import json
from argparse import Namespace
from pathlib import Path
from types import SimpleNamespace
import textwrap

import pytest
import torch

from src.cli import train_impl as train_module
from src.training.trainer import Trainer
from src.utils.config import Config


def write_yaml(path: Path, content: str) -> None:
    path.write_text(textwrap.dedent(content).strip() + "\n", encoding="utf-8")


def make_config_dir(tmp_path: Path, training_content: str, monitoring_content: str | None = None) -> Path:
    config_dir = tmp_path / "configs"
    config_dir.mkdir()

    write_yaml(
        config_dir / "model_config.yaml",
        """
        model:
          name: ViTND
          ndim: 2
          input_shape: [16, 16]
          patch_size: [16, 16]
          num_classes: 1
          dim: 8
          depth: 1
          heads: 1
          mlp_dim: 16
          channels: 1
          dim_head: 8
          dropout: 0.1
          emb_dropout: 0.1
          rope_min_freq: 1.0
          rope_max_freq: 10000.0
          rope_p_zero_freqs: 0.0
        """,
    )
    write_yaml(
        config_dir / "data_config.yaml",
        """
        data:
          pin_memory: false
          enable_memory_preload: false
          preload_batch_size: 2
          preload_verbose: false
        """,
    )
    write_yaml(config_dir / "training_config.yaml", training_content)
    write_yaml(
        config_dir / "experiment_config.yaml",
        """
        name: test_exp
        version: "0.1.0"
        save_dir: experiments
        log_dir: experiments/logs
        checkpoint_dir: experiments/checkpoints
        result_dir: experiments/results
        log_every_n_steps: 5
        val_check_interval: 1.0
        save_top_k: 1
        """,
    )
    write_yaml(
        config_dir / "multi_axis_config.yaml",
        """
        multi_axis:
          axis_data_paths:
            x: dataset/data-x
            y: dataset/data-y
            z: dataset/data-z
          active_axes: [x, y]
          patient_pooling:
            image_feature_pooling: mean
            image_probability_pooling: mean
          weighted_vote:
            enabled: true
            weights:
              x: 0.6
              y: 0.4
          fusion_head:
            enabled: true
            type: linear
            hidden_dim: 64
            dropout: 0.1
        """,
    )
    write_yaml(
        config_dir / "monitoring_config.yaml",
        monitoring_content
        or """
        monitoring:
          axis:
            early_stopping:
              enabled: false
              metric: val_loss
              mode: min
              patience: 3
              min_delta: 0.05
            model_selection:
              metric: val_loss
              mode: min
          fusion:
            early_stopping:
              enabled: true
              metric: val_auc
              mode: max
              patience: 4
              min_delta: 0.01
            model_selection:
              metric: val_auc
              mode: max
          prediction:
            weighted_vote_threshold: 0.35
            fusion_nn_threshold: 0.45
          verbose: true
        """,
    )
    return config_dir


def make_runtime_config(tmp_path: Path) -> SimpleNamespace:
    experiment_dir = tmp_path / "experiment"
    log_dir = experiment_dir / "logs"
    checkpoint_dir = experiment_dir / "checkpoints"
    result_dir = experiment_dir / "results"
    log_dir.mkdir(parents=True)
    checkpoint_dir.mkdir(parents=True)
    result_dir.mkdir(parents=True)

    return SimpleNamespace(
        model=SimpleNamespace(
            name="ViTND",
            input_shape=[16, 16],
            patch_size=[16, 16],
            num_classes=1,
            dim=8,
            depth=1,
            heads=1,
            mlp_dim=16,
            channels=1,
            dim_head=8,
            dropout=0.1,
            emb_dropout=0.1,
            rope_min_freq=1.0,
            rope_max_freq=10000.0,
            rope_p_zero_freqs=0.0,
        ),
        data=SimpleNamespace(
            data_path="dataset/data",
            label_path="dataset/label.csv",
            pin_memory=False,
            enable_memory_preload=False,
            preload_batch_size=None,
            preload_verbose=False,
        ),
        training=SimpleNamespace(
            epochs=4,
            learning_rate=0.123,
            weight_decay=0.01,
            optimizer="AdamW",
            scheduler="CosineAnnealingLR",
            scheduler_params={"T_max": 7, "eta_min": 9.0e-5},
            device="cpu",
            batch_size=2,
            num_workers=0,
            mixed_precision=False,
            gradient_clip_val=0.0,
            accumulate_grad_batches=2,
            debug_logging=False,
            pretrained_model_path="configured-pretrained.pth",
            load_weights_only=True,
            strict_load=True,
            freeze_method="layers",
            freeze_layers="patch_embedding",
            freeze_ratio=0.25,
            finetune_lr_scale=0.5,
            use_differential_lr=False,
            common=SimpleNamespace(
                device="cpu",
                num_workers=0,
                mixed_precision=False,
                gradient_clip_val=0.0,
                accumulate_grad_batches=2,
                debug_logging=False,
                pretrained_model_path="configured-pretrained.pth",
                load_weights_only=True,
                strict_load=True,
                freeze_method="layers",
                freeze_layers="patch_embedding",
                freeze_ratio=0.25,
                finetune_lr_scale=0.5,
                use_differential_lr=False,
                epochs=4,
                learning_rate=0.123,
                weight_decay=0.01,
                optimizer="AdamW",
                scheduler="CosineAnnealingLR",
                scheduler_params={"T_max": 7, "eta_min": 9.0e-5},
                batch_size=2,
            ),
        ),
        experiment=SimpleNamespace(
            name="runtime-exp",
            version="0.1.0",
            save_dir=str(experiment_dir),
            log_dir=str(log_dir),
            checkpoint_dir=str(checkpoint_dir),
            result_dir=str(result_dir),
            log_every_n_steps=1,
            val_check_interval=1.0,
            save_top_k=1,
        ),
        monitoring=SimpleNamespace(
            early_stopping={
                "enabled": False,
                "metric": "val_loss",
                "mode": "min",
                "patience": 3,
                "min_delta": 0.05,
            },
            model_selection={
                "metric": "val_loss",
                "mode": "min",
            },
            predict_threshold=0.35,
            verbose=True,
        ),
        multi_axis=SimpleNamespace(
            enabled=True,
            axis_data_paths={"x": "dataset/data-x", "y": "dataset/data-y"},
            active_axes=["x", "y"],
            voting_weights={"x": 0.6, "y": 0.4},
        ),
        train_split=SimpleNamespace(
            method="stratified",
            train_ratio=0.7,
            val_ratio=0.2,
            test_ratio=0.1,
            random_seed=7,
            export_split_info=True,
            split_filename="custom_split.csv",
            train_split_csv_path="preset.csv",
            csv_split_random_seed=19,
            use_csv_direct=True,
        ),
    )


class DummyLogger:
    def __init__(self):
        self.messages = []
        self.log_file = "dummy.log"

    def info(self, message):
        self.messages.append(("info", str(message)))

    def warning(self, message):
        self.messages.append(("warning", str(message)))

    def error(self, message):
        self.messages.append(("error", str(message)))

    def debug(self, message):
        self.messages.append(("debug", str(message)))

    def log_model_summary(self, model):
        self.messages.append(("summary", type(model).__name__))

    def log_config(self, config):
        self.messages.append(("config", getattr(config.experiment, "name", "unknown")))

    def flush(self):
        pass

    def close(self):
        pass


class DummyTensorBoardLogger:
    def __init__(self, *args, **kwargs):
        pass

    def log_graph(self, *args, **kwargs):
        pass

    def log_images(self, *args, **kwargs):
        pass

    def log_patches_as_grid(self, *args, **kwargs):
        pass

    def log_histogram(self, *args, **kwargs):
        pass

    def log_scalars(self, *args, **kwargs):
        pass

    def log_learning_rate(self, *args, **kwargs):
        pass

    def log_model_stats(self, *args, **kwargs):
        pass

    def close(self):
        pass


class DummySingleAxisModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.patch_embedding = torch.nn.Linear(1, 1)
        self.transformer = SimpleNamespace(layers=torch.nn.ModuleList([torch.nn.Linear(1, 1)]))
        self.mlp_head = torch.nn.Sequential(torch.nn.Identity(), torch.nn.Linear(1, 1))

    def forward(self, x):
        flat = x.reshape(x.shape[0], -1).mean(dim=1, keepdim=True)
        return self.mlp_head(flat)

    def save_initialization(self, path):
        torch.save({"ok": True}, path)


def test_directory_training_config_supports_stage_blocks_and_dual_output_sections(tmp_path):
    config_dir = make_config_dir(
        tmp_path,
        """
        training:
          common:
            device: cpu
            num_workers: 0
            mixed_precision: false
            gradient_clip_val: 0.0
            accumulate_grad_batches: 2
          axis:
            epochs: 6
            learning_rate: 0.123
            weight_decay: 0.02
            optimizer: AdamW
            scheduler: CosineAnnealingLR
            scheduler_params:
              T_max: 7
              eta_min: 9.0e-5
            batch_size: 4
          fusion:
            epochs: 3
            learning_rate: 0.01
            weight_decay: 0.0
            optimizer: AdamW
            scheduler: CosineAnnealingLR
            scheduler_params:
              T_max: 3
              eta_min: 1.0e-6
            batch_size: 2
            freeze_encoders: true

        train_split:
          method: stratified
          train_ratio: 0.7
          val_ratio: 0.2
          test_ratio: 0.1
          random_seed: 7
          export_split_info: true
          split_filename: custom_split.csv
          train_split_csv_path: preset.csv
          csv_split_random_seed: 19
          use_csv_direct: true
        """,
    )

    config = Config(str(config_dir))

    assert config.training.common.device == "cpu"
    assert config.training.axis.learning_rate == pytest.approx(0.123)
    assert config.training.axis.scheduler_params == {"T_max": 7, "eta_min": 9.0e-5}
    assert config.training.fusion.freeze_encoders is True
    assert config.multi_axis.weighted_vote.weights == {"x": 0.6, "y": 0.4}
    assert config.multi_axis.fusion_head.type == "linear"
    assert config.monitoring.prediction.weighted_vote_threshold == pytest.approx(0.35)
    assert config.monitoring.prediction.fusion_nn_threshold == pytest.approx(0.45)
    assert config.train_split.export_split_info is True
    assert config.train_split.split_filename == "custom_split.csv"
    assert config.train_split.train_split_csv_path == "preset.csv"
    assert config.train_split.csv_split_random_seed == 19
    assert config.train_split.use_csv_direct is True


def test_apply_training_overrides_preserves_yaml_verbose_when_cli_not_set(tmp_path):
    config = make_runtime_config(tmp_path)
    config.monitoring.verbose = True
    args = Namespace(
        experiment_name=None,
        random_seed=None,
        epochs=None,
        batch_size=None,
        device=None,
        verbose=False,
        disable_memory_preload=False,
        preload_batch_size=None,
        train_split_csv=None,
        csv_split_seed=None,
        use_csv_direct=False,
        pre_model=None,
        freeze_layers=None,
        freeze_ratio=None,
        load_weights_only=False,
        strict_load=False,
    )

    train_module.apply_training_overrides(config, args)

    assert config.monitoring.verbose is True


def test_execute_train_args_prints_config_before_training_dispatch(tmp_path, monkeypatch, capsys):
    config = make_runtime_config(tmp_path)
    config.monitoring.verbose = True
    experiment_dir = Path(config.experiment.save_dir)

    monkeypatch.setattr(train_module, "load_config", lambda _: config)
    monkeypatch.setattr(train_module, "prepare_experiment_directories", lambda _: str(experiment_dir))
    monkeypatch.setattr(train_module, "get_logger", lambda *args, **kwargs: DummyLogger())
    monkeypatch.setattr(train_module, "EnhancedDataSplitter", lambda *args, **kwargs: object())

    def fake_dispatch_training(splitter, cfg, args, logger):
        print("DISPATCH_CALLED")
        return {"status": "ok"}

    monkeypatch.setattr(train_module, "dispatch_training", fake_dispatch_training)

    exit_code = train_module.execute_train_args(
        {
            "config_path": str(tmp_path / "unused"),
            "data_path": "dataset/data",
            "label_path": "dataset/label.csv",
            "verbose": True,
        }
    )

    captured = capsys.readouterr().out

    assert exit_code == 0
    assert "TRAINING CONFIG" in captured
    assert captured.index("TRAINING CONFIG") < captured.index("DISPATCH_CALLED")


def test_train_single_split_prefers_yaml_freeze_and_weight_loading_when_cli_omitted(tmp_path, monkeypatch):
    config = make_runtime_config(tmp_path)
    logger = DummyLogger()
    captured = {}

    class DummyDataManager:
        def __init__(self, *args, **kwargs):
            self.dataset = SimpleNamespace(samples=[("img.png", 1)])

        def get_dataset_info(self):
            return {
                "train": {"patients": 1, "samples": 1, "positive_samples": 1, "negative_samples": 0},
                "val": {"patients": 1, "samples": 1, "positive_samples": 1, "negative_samples": 0},
                "test": {"patients": 1, "samples": 1, "positive_samples": 1, "negative_samples": 0},
            }

        def get_train_dataloader(self):
            return [("train",)]

        def get_val_dataloader(self):
            return [("val",)]

        def get_test_dataloader(self):
            return SimpleNamespace(dataset=self.dataset)

    class DummyTrainer:
        def __init__(self, cfg, logger, **kwargs):
            captured["kwargs"] = kwargs

        def train(self, train_loader, val_loader):
            return [], []

        def evaluate(self, test_loader):
            return {}

    monkeypatch.setattr(train_module, "DataLoaderManager", DummyDataManager)
    monkeypatch.setattr("src.training.trainer.Trainer", DummyTrainer)

    args = Namespace(
        data_path="dataset/data",
        label_path="dataset/label.csv",
        pre_model=None,
        load_weights_only=False,
        strict_load=False,
        freeze_layers=None,
        freeze_ratio=None,
    )
    splitter = SimpleNamespace(train_patients=["p1"], val_patients=["p2"], test_patients=["p3"])

    train_module.train_single_split(splitter, config, args, logger)

    assert captured["kwargs"]["pre_model_path"] == "configured-pretrained.pth"
    assert captured["kwargs"]["load_weights_only"] is True
    assert captured["kwargs"]["strict_load"] is True
    assert captured["kwargs"]["freeze_layers"] == "patch_embedding"
    assert captured["kwargs"]["freeze_ratio"] is None


def test_train_single_split_uses_yaml_freeze_ratio_when_configured(tmp_path, monkeypatch):
    config = make_runtime_config(tmp_path)
    config.training.freeze_method = "ratio"
    config.training.freeze_layers = ""
    config.training.freeze_ratio = 0.25
    logger = DummyLogger()
    captured = {}

    class DummyDataManager:
        def __init__(self, *args, **kwargs):
            self.dataset = SimpleNamespace(samples=[("img.png", 1)])

        def get_dataset_info(self):
            return {
                "train": {"patients": 1, "samples": 1, "positive_samples": 1, "negative_samples": 0},
                "val": {"patients": 1, "samples": 1, "positive_samples": 1, "negative_samples": 0},
                "test": {"patients": 1, "samples": 1, "positive_samples": 1, "negative_samples": 0},
            }

        def get_train_dataloader(self):
            return [("train",)]

        def get_val_dataloader(self):
            return [("val",)]

        def get_test_dataloader(self):
            return SimpleNamespace(dataset=self.dataset)

    class DummyTrainer:
        def __init__(self, cfg, logger, **kwargs):
            captured["kwargs"] = kwargs

        def train(self, train_loader, val_loader):
            return [], []

        def evaluate(self, test_loader):
            return {}

    monkeypatch.setattr(train_module, "DataLoaderManager", DummyDataManager)
    monkeypatch.setattr("src.training.trainer.Trainer", DummyTrainer)

    args = Namespace(
        data_path="dataset/data",
        label_path="dataset/label.csv",
        pre_model=None,
        load_weights_only=False,
        strict_load=False,
        freeze_layers=None,
        freeze_ratio=None,
    )
    splitter = SimpleNamespace(train_patients=["p1"], val_patients=["p2"], test_patients=["p3"])

    train_module.train_single_split(splitter, config, args, logger)

    assert captured["kwargs"]["freeze_layers"] is None
    assert captured["kwargs"]["freeze_ratio"] == pytest.approx(0.25)


def test_trainer_uses_monitoring_for_early_stopping_and_model_selection(tmp_path, monkeypatch):
    config = make_runtime_config(tmp_path)
    logger = DummyLogger()

    monkeypatch.setattr("src.training.trainer.create_vit_model", lambda cfg: DummySingleAxisModel())
    monkeypatch.setattr("src.training.trainer.TensorBoardLogger", DummyTensorBoardLogger)
    monkeypatch.setattr(Trainer, "_calculate_pos_weight", lambda self: None)
    monkeypatch.setattr(Trainer, "_log_model_graph", lambda self: None)

    trainer = Trainer(config, logger=logger)

    assert trainer.early_stopping.mode == "min"
    assert trainer.early_stopping.patience == 3
    assert trainer.early_stopping.min_delta == pytest.approx(0.05)
    assert trainer.best_val_metric == float("inf")


def test_trainer_uses_differential_lr_when_finetuning_enabled(tmp_path, monkeypatch):
    config = make_runtime_config(tmp_path)
    config.training.use_differential_lr = True
    config.training.finetune_lr_scale = 0.5
    logger = DummyLogger()

    monkeypatch.setattr("src.training.trainer.create_vit_model", lambda cfg: DummySingleAxisModel())
    monkeypatch.setattr("src.training.trainer.TensorBoardLogger", DummyTensorBoardLogger)
    monkeypatch.setattr(Trainer, "_calculate_pos_weight", lambda self: None)
    monkeypatch.setattr(Trainer, "_log_model_graph", lambda self: None)

    trainer = Trainer(config, logger=logger, pre_model_path="configured-pretrained.pth", load_weights_only=True)

    lrs = sorted(group["lr"] for group in trainer.optimizer.param_groups)

    assert lrs == [pytest.approx(0.0615), pytest.approx(0.123)]


def test_trainer_respects_validation_interval(tmp_path, monkeypatch):
    config = make_runtime_config(tmp_path)
    config.training.epochs = 3
    config.experiment.val_check_interval = 2.0
    logger = DummyLogger()
    validate_calls = []

    monkeypatch.setattr("src.training.trainer.create_vit_model", lambda cfg: DummySingleAxisModel())
    monkeypatch.setattr("src.training.trainer.TensorBoardLogger", DummyTensorBoardLogger)
    monkeypatch.setattr(Trainer, "_calculate_pos_weight", lambda self: None)
    monkeypatch.setattr(Trainer, "_log_model_graph", lambda self: None)
    monkeypatch.setattr(Trainer, "_log_dataset_samples", lambda self, data_loader, epoch: None)
    monkeypatch.setattr(Trainer, "train_epoch", lambda self, loader, epoch=0, tracker=None: {"loss": 1.0})

    def fake_validate(self, loader, tracker=None):
        validate_calls.append("val")
        return {"loss": 0.5, "auc": 0.8, "accuracy": 0.7, "f1": 0.6}

    monkeypatch.setattr(Trainer, "validate_epoch", fake_validate)
    monkeypatch.setattr(Trainer, "save_checkpoint", lambda self, epoch, val_metric, is_best=False: None)

    trainer = Trainer(config, logger=logger)
    trainer.train([1], [1])

    assert len(validate_calls) == 2


def test_trainer_prunes_epoch_checkpoints_with_save_top_k(tmp_path, monkeypatch):
    config = make_runtime_config(tmp_path)
    config.experiment.save_top_k = 1
    logger = DummyLogger()

    monkeypatch.setattr("src.training.trainer.create_vit_model", lambda cfg: DummySingleAxisModel())
    monkeypatch.setattr("src.training.trainer.TensorBoardLogger", DummyTensorBoardLogger)
    monkeypatch.setattr(Trainer, "_calculate_pos_weight", lambda self: None)
    monkeypatch.setattr(Trainer, "_log_model_graph", lambda self: None)

    trainer = Trainer(config, logger=logger)
    trainer.save_checkpoint(epoch=1, val_metric=0.8, is_best=True)
    trainer.save_checkpoint(epoch=2, val_metric=0.9, is_best=True)

    checkpoint_files = sorted(Path(config.experiment.checkpoint_dir).glob("checkpoint_epoch_*.pth"))

    assert [path.name for path in checkpoint_files] == ["checkpoint_epoch_2.pth"]


def test_execute_train_args_writes_final_results_json(tmp_path, monkeypatch):
    config = make_runtime_config(tmp_path)
    experiment_dir = Path(config.experiment.save_dir)

    monkeypatch.setattr(train_module, "load_config", lambda _: config)
    monkeypatch.setattr(train_module, "prepare_experiment_directories", lambda _: str(experiment_dir))
    monkeypatch.setattr(train_module, "get_logger", lambda *args, **kwargs: DummyLogger())
    monkeypatch.setattr(train_module, "EnhancedDataSplitter", lambda *args, **kwargs: object())
    monkeypatch.setattr(train_module, "dispatch_training", lambda *args, **kwargs: {"status": "ok"})

    exit_code = train_module.execute_train_args(
        {
            "config_path": str(tmp_path / "unused"),
            "data_path": "dataset/data",
            "label_path": "dataset/label.csv",
        }
    )

    final_results_file = experiment_dir / "results" / "final_results.json"

    assert exit_code == 0
    assert json.loads(final_results_file.read_text(encoding="utf-8")) == {"status": "ok"}
