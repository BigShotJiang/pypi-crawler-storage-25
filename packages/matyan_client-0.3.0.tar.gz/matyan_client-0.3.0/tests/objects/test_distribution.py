"""Tests for matyan_client.objects.Distribution."""

from __future__ import annotations

import builtins
from typing import TYPE_CHECKING, Any, cast

import numpy as np
import pytest

from matyan_client.objects.distribution import _MAX_BIN_COUNT, Distribution, _to_list

if TYPE_CHECKING:
    from collections.abc import Sequence


class TestDistribution:
    def test_from_samples_with_numpy(self) -> None:

        d = Distribution(samples=np.array([1, 2, 3, 4, 5]), bin_count=3)  # ty:ignore[invalid-argument-type]
        assert d.bin_count == 3
        assert len(d.weights) == 3
        assert sum(d.weights) == 5
        lo, hi = d.range
        assert lo <= 1.0
        assert hi >= 5.0

    def test_from_samples_without_numpy(self, monkeypatch: pytest.MonkeyPatch) -> None:

        real_import = builtins.__import__

        def _no_numpy(name: str, *args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
            if name == "numpy":
                msg = "no numpy"
                raise ImportError(msg)
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", _no_numpy)
        d = Distribution(samples=[1.0, 2.0, 3.0, 4.0, 5.0], bin_count=3)
        assert d.bin_count == 3
        assert len(d.weights) == 3
        assert sum(d.weights) == 5

    def test_from_histogram(self) -> None:
        d = Distribution(hist=[10, 20, 30], bin_range=(0.0, 3.0))
        assert d.weights == [10, 20, 30]
        assert d.range == (0.0, 3.0)
        assert d.bin_count == 3

    def test_from_histogram_classmethod(self) -> None:
        d = Distribution.from_histogram([5, 5], (0.0, 1.0))
        assert d.weights == [5, 5]

    def test_from_samples_classmethod(self) -> None:
        d = Distribution.from_samples([1, 2, 3])
        assert d.bin_count == 64

    def test_no_args_raises(self) -> None:
        with pytest.raises(ValueError, match="Provide either"):
            Distribution()

    def test_bin_count_clamped(self) -> None:
        d = Distribution(samples=list(range(100)), bin_count=_MAX_BIN_COUNT + 100)
        assert d.bin_count == _MAX_BIN_COUNT

    def test_identical_samples(self) -> None:
        d = Distribution(samples=[5.0, 5.0, 5.0], bin_count=4)
        assert sum(d.weights) == 3

    def test_json(self) -> None:
        d = Distribution(hist=[1, 2], bin_range=(0.0, 1.0))
        j = d.json()
        assert j["type"] == "distribution"
        assert j["bin_count"] == 2
        assert j["range"] == [0.0, 1.0]
        assert j["data"] == [1, 2]

    def test_repr(self) -> None:
        d = Distribution(hist=[1], bin_range=(0.0, 1.0))
        assert "Distribution" in repr(d)

    def test_to_list_plain(self) -> None:
        assert _to_list([1, 2, 3]) == [1, 2, 3]

    def test_to_list_numpy(self) -> None:
        arr = np.array([1, 2, 3])
        assert _to_list(cast("Sequence[int | float]", arr)) == [1, 2, 3]
