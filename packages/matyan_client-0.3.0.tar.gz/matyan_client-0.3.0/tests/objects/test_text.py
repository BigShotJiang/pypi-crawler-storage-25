"""Tests for matyan_client.objects.Text."""

from __future__ import annotations

from matyan_client.objects.text import Text


class TestText:
    def test_constructor(self) -> None:
        t = Text("hello world")
        assert t.data == "hello world"

    def test_non_string_coerced(self) -> None:
        t = Text(42)  # type: ignore[arg-type]
        assert t.data == "42"

    def test_json(self) -> None:
        t = Text("sample")
        j = t.json()
        assert j == {"type": "text", "data": "sample"}

    def test_repr_short(self) -> None:
        t = Text("short")
        assert repr(t) == "Text('short')"

    def test_repr_truncated(self) -> None:
        long_text = "x" * 100
        t = Text(long_text)
        r = repr(t)
        assert "..." in r
        assert len(r) < 100
