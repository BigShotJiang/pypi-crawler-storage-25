"""Tests for matyan_client.objects.Audio."""

from __future__ import annotations

import base64
import io
from pathlib import Path

import numpy as np
import pytest

from matyan_client.objects.audio import Audio


class TestAudio:
    def test_from_bytes(self) -> None:
        data = b"RIFF\x00\x00\x00\x00WAVEfmt "
        a = Audio(data, format_="wav", caption="test")
        assert a.caption == "test"
        assert a.format == "wav"

    def test_from_file_path_str(self, tmp_path: Path) -> None:
        p = tmp_path / "clip.mp3"
        p.write_bytes(b"fakeaudio")
        a = Audio(str(p))
        assert a.format == "mp3"
        j = a.json()
        assert base64.b64decode(j["data"]) == b"fakeaudio"

    def test_from_file_path_pathlib(self, tmp_path: Path) -> None:
        p = tmp_path / "clip.wav"
        p.write_bytes(b"wavdata")

        a = Audio(Path(str(p)))
        assert a.format == "wav"

    def test_from_io_stream(self) -> None:
        buf = io.BytesIO(b"streamdata")
        a = Audio(buf, format_="ogg")
        j = a.json()
        assert base64.b64decode(j["data"]) == b"streamdata"

    def test_from_numpy_int16(self) -> None:
        arr = np.array([0, 1000, -1000, 32767], dtype=np.int16)
        a = Audio(arr, rate=16000)
        assert a.format == "wav"
        j = a.json()
        raw = base64.b64decode(j["data"])
        assert raw[:4] == b"RIFF"
        assert raw[8:12] == b"WAVE"
        assert j["rate"] == 16000

    def test_from_numpy_float_normalization(self) -> None:
        arr = np.array([0.0, 0.5, -0.5, 1.0], dtype=np.float32)
        a = Audio(arr, rate=22050)
        assert a.format == "wav"
        j = a.json()
        raw = base64.b64decode(j["data"])
        assert raw[:4] == b"RIFF"

    def test_from_numpy_stereo(self) -> None:
        arr = np.zeros((100, 2), dtype=np.int16)
        a = Audio(arr, rate=44100)
        j = a.json()
        raw = base64.b64decode(j["data"])
        assert raw[:4] == b"RIFF"

    def test_from_numpy_zero_peak(self) -> None:
        arr = np.array([0.0, 0.0, 0.0], dtype=np.float64)
        a = Audio(arr)
        assert a.format == "wav"

    def test_unsupported_type(self) -> None:
        with pytest.raises(TypeError, match="Unsupported audio type"):
            Audio(12345)  # ty:ignore[invalid-argument-type]

    def test_json_keys(self) -> None:
        a = Audio(b"data", format_="flac", caption="c")
        j = a.json()
        assert set(j.keys()) == {"type", "data", "format", "caption", "rate"}
        assert j["type"] == "audio"
        assert j["caption"] == "c"

    def test_repr(self) -> None:
        a = Audio(b"x", caption="c")
        r = repr(a)
        assert "Audio" in r
        assert "size=1" in r

    def test_format_from_path_extension(self, tmp_path: Path) -> None:
        p = tmp_path / "clip.flac"
        p.write_bytes(b"flacdata")
        a = Audio(str(p))
        assert a.format == "flac"

    def test_explicit_format_overrides(self) -> None:
        a = Audio(b"data", format_="ogg")
        assert a.format == "ogg"
