"""Shared fixtures for matyan-client tests."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock, patch

import pytest

from matyan_client.run import Run, _global_cache

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

# ruff: noqa: SLF001


@pytest.fixture(autouse=True)
def _clear_global_cache() -> Generator[None]:
    """Ensure the global write cache is clean between tests."""
    _global_cache.clear()
    yield
    _global_cache.clear()


@pytest.fixture(autouse=True)
def _clear_run_instances() -> Generator[None]:
    """Prevent Run instances from leaking between tests."""
    Run._instances.clear()
    yield
    Run._instances.clear()


@pytest.fixture
def mock_ws() -> MagicMock:
    """Return a MagicMock pretending to be WsTransport."""
    ws = MagicMock()
    ws.connected = True
    ws.close = MagicMock()
    ws.send = MagicMock()
    ws.send_create_run = MagicMock()
    ws.send_log_metric = MagicMock()
    ws.send_log_hparams = MagicMock()
    ws.send_log_custom_object = MagicMock()
    ws.send_set_run_property = MagicMock()
    ws.send_add_tag = MagicMock()
    ws.send_remove_tag = MagicMock()
    ws.send_finish_run = MagicMock()
    ws.send_log_terminal_line = MagicMock()
    ws.send_log_record = MagicMock()
    ws.wait_for_flush = MagicMock(return_value=True)
    return ws


@pytest.fixture
def mock_http() -> MagicMock:
    """Return a MagicMock pretending to be HttpTransport."""
    http = MagicMock()
    http.get_run_info = MagicMock(return_value={"params": {}, "traces": {}, "props": {}})
    http.close = MagicMock()
    http.presign_artifact = MagicMock(return_value={"upload_url": "http://s3/presigned", "s3_key": "k"})
    return http


@pytest.fixture
def make_run(
    mock_ws: MagicMock,
    mock_http: MagicMock,
) -> Callable[..., tuple[Run, MagicMock, MagicMock]]:
    """Factory that creates a Run with mocked transports.

    Returns ``(run, mock_ws, mock_http)`` for assertion convenience.
    """  # noqa: D401

    def _factory(run_hash: str = "test-run-hash", **kwargs: Any) -> tuple[Run, MagicMock, MagicMock]:  # noqa: ANN401
        kwargs.setdefault("read_only", False)
        kwargs.setdefault("capture_terminal_logs", False)
        kwargs.setdefault("system_tracking_interval", None)
        kwargs.setdefault("log_system_params", False)

        with (
            patch("matyan_client.run.WsTransport", return_value=mock_ws),
            patch("matyan_client.run.HttpTransport", return_value=mock_http),
            patch("matyan_client.run._BlobUploader") as mock_blob_cls,
        ):
            mock_blob = MagicMock()
            mock_blob.submit = MagicMock(return_value="test-run-hash/artifact")
            mock_blob.shutdown = MagicMock()
            mock_blob_cls.return_value = mock_blob
            run = __import__("matyan_client.run", fromlist=["Run"]).Run(
                run_hash=run_hash,
                **kwargs,
            )
            run._blob_uploader = mock_blob
            return run, mock_ws, mock_http

    return _factory
