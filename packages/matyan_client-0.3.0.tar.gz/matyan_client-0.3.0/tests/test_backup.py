"""Tests for matyan_client.backup — client-side backup via REST API."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

from matyan_api_models.backup import BackupManifest
from matyan_api_models.context import context_to_id

from matyan_client.backup import (
    _build_run_meta,
    _build_traces_and_contexts,
    _export_entities,
    _export_logs,
    _export_metrics,
    run_backup,
)
from matyan_client.restore import restore_reingest

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_MOCK_RUN_INFO = {
    "params": {"hparams": {"lr": 0.01, "batch_size": 32}},
    "traces": {
        "metric": [
            {"name": "loss", "context": {}, "last_value": 0.5},
            {"name": "acc", "context": {"subset": "train"}, "last_value": 0.9},
        ],
        "images": [],
        "texts": [],
        "distributions": [],
        "audios": [],
        "figures": [],
    },
    "props": {
        "name": "Test Run",
        "description": "A test run",
        "active": False,
        "archived": False,
        "experiment": {"id": "exp-1", "name": "baseline"},
        "creation_time": 1700000000.0,
        "end_time": 1700001000.0,
        "tags": [],
    },
    "artifacts": [],
}

_MOCK_METRIC_BATCH = [
    {"name": "loss", "context": {}, "iters": [0, 1, 2], "values": [1.0, 0.7, 0.5]},
    {"name": "acc", "context": {"subset": "train"}, "iters": [0, 1, 2], "values": [0.1, 0.5, 0.9]},
]


def _mock_http() -> MagicMock:
    http = MagicMock()
    http.search_runs.return_value = [{"hash": "abc123"}]
    http.get_run_info.return_value = _MOCK_RUN_INFO
    http.get_run_metric_batch.return_value = _MOCK_METRIC_BATCH
    http.get_run_logs.return_value = [(0, "line 0"), (1, "line 1")]
    http.get_run_log_records.return_value = (2, [(0, {"message": "record-0", "log_level": "INFO"})])
    http.list_experiments.return_value = [{"id": "exp-1", "name": "baseline"}]
    http.list_tags.return_value = [{"id": "tag-1", "name": "v1", "color": "blue"}]
    http.search_sequence.return_value = []
    http.get_blob_batch.return_value = {}
    http.close.return_value = None
    return http


# ---------------------------------------------------------------------------
# Unit tests for individual helpers
# ---------------------------------------------------------------------------


class TestBuildRunMeta:
    def test_basic(self) -> None:
        props = _MOCK_RUN_INFO["props"]
        meta = _build_run_meta(props)
        assert meta["name"] == "Test Run"
        assert meta["description"] == "A test run"
        assert meta["active"] is False
        assert meta["is_archived"] is False
        assert meta["experiment_name"] == "baseline"
        assert meta["experiment_id"] == "exp-1"
        assert meta["created_at"] == 1700000000.0
        assert meta["finalized_at"] == 1700001000.0

    def test_no_experiment(self) -> None:
        props = {"name": "Solo", "experiment": None}
        meta = _build_run_meta(props)
        assert "experiment_name" not in meta

    def test_active_no_end_time(self) -> None:
        props = {"name": "Active", "active": True, "end_time": None}
        meta = _build_run_meta(props)
        assert meta["active"] is True
        assert "finalized_at" not in meta


class TestBuildTracesAndContexts:
    def test_metric_traces(self) -> None:
        overview = _MOCK_RUN_INFO["traces"]
        traces, contexts = _build_traces_and_contexts(overview)
        assert len(traces) == 2

        loss_trace = next(t for t in traces if t["name"] == "loss")
        assert loss_trace["dtype"] == "float"
        assert loss_trace["context_id"] == 0

        acc_trace = next(t for t in traces if t["name"] == "acc")
        train_ctx = {"subset": "train"}
        assert acc_trace["context_id"] == context_to_id(train_ctx)
        assert str(acc_trace["context_id"]) in contexts
        assert contexts[str(acc_trace["context_id"])] == train_ctx

    def test_empty_overview(self) -> None:
        traces, contexts = _build_traces_and_contexts({})
        assert traces == []
        assert contexts == {}


class TestExportMetrics:
    def test_basic(self) -> None:
        http = _mock_http()
        traces = [
            {"name": "loss", "context_id": 0, "dtype": "float"},
            {"name": "acc", "context_id": context_to_id({"subset": "train"}), "dtype": "float"},
        ]
        contexts = {"0": {}, str(context_to_id({"subset": "train"})): {"subset": "train"}}
        records = _export_metrics(http, "abc", traces, contexts)
        assert len(records) == 6
        assert all(r["ctx_id"] in (0, context_to_id({"subset": "train"})) for r in records)

    def test_no_metric_traces(self) -> None:
        http = _mock_http()
        records = _export_metrics(http, "abc", [], {})
        assert records == []
        http.get_run_metric_batch.assert_not_called()


class TestExportLogs:
    def test_fetches_logs_and_log_records(self) -> None:
        http = _mock_http()
        traces: list[dict] = []
        contexts: dict[str, dict] = {}
        records, extra_traces = _export_logs(http, "abc", traces, contexts)
        assert len(records) == 3
        log_recs = [r for r in records if r["name"] == "logs"]
        assert len(log_recs) == 2
        lr_recs = [r for r in records if r["name"] == "__log_records"]
        assert len(lr_recs) == 1
        assert len(extra_traces) == 2
        assert "0" in contexts

    def test_no_logs(self) -> None:
        http = _mock_http()
        http.get_run_logs.return_value = []
        http.get_run_log_records.return_value = (0, [])
        records, extra = _export_logs(http, "abc", [], {})
        assert records == []
        assert extra == []


class TestExportEntities:
    def test_writes_entities_file(self, tmp_path: Path) -> None:
        http = _mock_http()
        counts = _export_entities(http, tmp_path)
        assert counts == {"experiment": 1, "tag": 1}

        entities_path = tmp_path / "entities.jsonl"
        assert entities_path.exists()
        lines = [json.loads(line) for line in entities_path.read_text().strip().split("\n")]
        assert len(lines) == 2
        assert lines[0]["entity_type"] == "experiment"
        assert lines[1]["entity_type"] == "tag"


# ---------------------------------------------------------------------------
# Integration-style backup test
# ---------------------------------------------------------------------------


class TestRunBackup:
    @patch("matyan_client.backup.HttpTransport")
    def test_full_backup(self, mock_http_cls: MagicMock, tmp_path: Path) -> None:
        http = _mock_http()
        mock_http_cls.return_value = http

        result = run_backup(str(tmp_path), backend_url="http://test:53800")

        assert result.run_count == 1
        assert result.sequence_records > 0

        backup_dirs = [d for d in tmp_path.iterdir() if d.is_dir() and d.name.startswith("matyan-backup-")]
        assert len(backup_dirs) == 1
        backup_dir = backup_dirs[0]

        manifest = BackupManifest.read(backup_dir)
        assert manifest.run_count == 1
        assert "abc123" in manifest.run_hashes

        run_dir = backup_dir / "runs" / "abc123"
        assert (run_dir / "run.json").exists()
        assert (run_dir / "attrs.json").exists()
        assert (run_dir / "traces.json").exists()
        assert (run_dir / "contexts.json").exists()
        assert (run_dir / "sequences.jsonl").exists()

        meta = json.loads((run_dir / "run.json").read_text())
        assert meta["name"] == "Test Run"
        assert meta["experiment_name"] == "baseline"

        attrs = json.loads((run_dir / "attrs.json").read_text())
        assert attrs["hparams"]["lr"] == 0.01

        traces = json.loads((run_dir / "traces.json").read_text())
        assert any(t["name"] == "loss" for t in traces)
        assert any(t["name"] == "logs" for t in traces)
        assert any(t["name"] == "__log_records" for t in traces)

        contexts = json.loads((run_dir / "contexts.json").read_text())
        assert "0" in contexts

        seq_lines = [
            json.loads(line) for line in (run_dir / "sequences.jsonl").read_text().strip().split("\n") if line.strip()
        ]
        assert len(seq_lines) == result.sequence_records
        metric_recs = [r for r in seq_lines if r["name"] == "loss"]
        assert len(metric_recs) == 3

        errors = manifest.validate(backup_dir)
        assert errors == []

    @patch("matyan_client.backup.HttpTransport")
    def test_backup_no_runs(self, mock_http_cls: MagicMock, tmp_path: Path) -> None:
        http = _mock_http()
        http.search_runs.return_value = []
        mock_http_cls.return_value = http

        result = run_backup(str(tmp_path), backend_url="http://test:53800")
        assert result.run_count == 0

    @patch("matyan_client.backup.HttpTransport")
    def test_backup_with_run_filter(self, mock_http_cls: MagicMock, tmp_path: Path) -> None:
        http = _mock_http()
        mock_http_cls.return_value = http

        result = run_backup(
            str(tmp_path),
            backend_url="http://test:53800",
            run_hashes=["abc123"],
        )
        assert result.run_count == 1
        http.search_runs.assert_not_called()

    @patch("matyan_client.backup.HttpTransport")
    def test_backup_with_experiment_filter(self, mock_http_cls: MagicMock, tmp_path: Path) -> None:
        http = _mock_http()
        mock_http_cls.return_value = http

        run_backup(str(tmp_path), backend_url="http://test:53800", experiment="baseline")
        http.search_runs.assert_called_once()
        query = http.search_runs.call_args[1].get(
            "query",
            http.search_runs.call_args[0][0] if http.search_runs.call_args[0] else "",
        )
        assert "baseline" in query

    @patch("matyan_client.backup.HttpTransport")
    def test_backup_compress(self, mock_http_cls: MagicMock, tmp_path: Path) -> None:
        http = _mock_http()
        mock_http_cls.return_value = http

        result = run_backup(str(tmp_path), backend_url="http://test:53800", compress=True)
        assert result.backup_path is not None
        assert result.backup_path.suffix == ".gz"
        assert result.backup_path.exists()

    @patch("matyan_client.backup.HttpTransport")
    def test_backup_with_blobs(self, mock_http_cls: MagicMock, tmp_path: Path) -> None:
        http = _mock_http()
        http.search_sequence.return_value = [
            {
                "hash": "abc123",
                "traces": [
                    {
                        "name": "imgs",
                        "context": {},
                        "values": [
                            {"caption": "test", "blob_uri": "enc-uri-1", "format": "png"},
                        ],
                        "iters": [0],
                    },
                ],
            },
        ]
        http.get_blob_batch.return_value = {"enc-uri-1": b"\x89PNG-fake-data"}

        info_with_images = {
            **_MOCK_RUN_INFO,
            "traces": {
                **_MOCK_RUN_INFO["traces"],
                "images": [{"name": "imgs", "context": {}}],
            },
        }
        http.get_run_info.return_value = info_with_images
        mock_http_cls.return_value = http

        result = run_backup(str(tmp_path), backend_url="http://test:53800")
        assert result.blob_count == 1
        assert result.blob_bytes == len(b"\x89PNG-fake-data")

        backup_dirs = [d for d in tmp_path.iterdir() if d.is_dir() and d.name.startswith("matyan-backup-")]
        backup_dir = backup_dirs[0]
        run_dir = backup_dir / "runs" / "abc123"
        blobs_dir = run_dir / "blobs"
        assert blobs_dir.exists()
        blob_files = list(blobs_dir.rglob("*"))
        assert len(blob_files) == 1
        assert blob_files[0].read_bytes() == b"\x89PNG-fake-data"


class TestBackupRestoreRoundTrip:
    """Verify that a client backup can be dry-run restored."""

    @patch("matyan_client.backup.HttpTransport")
    def test_dry_run_restore(self, mock_http_cls: MagicMock, tmp_path: Path) -> None:
        http = _mock_http()
        mock_http_cls.return_value = http

        result = run_backup(str(tmp_path), backend_url="http://test:53800")
        assert result.backup_path is not None

        restore_result = restore_reingest(str(result.backup_path), dry_run=True)
        assert restore_result.runs_processed == 1
        assert restore_result.sequence_records_sent == result.sequence_records
        assert restore_result.entities_processed == 2
