"""Tests for the matyan-client status CLI command."""

from __future__ import annotations

import httpx
import respx
from click.testing import CliRunner

from matyan_client.cli import main

BACKEND_URL = "http://backend-status.test"
FRONTIER_URL = "http://frontier-status.test"


@respx.mock
def test_status_command_shows_ok_when_services_reachable() -> None:
    """Status command prints OK and versions when backend and frontier respond."""
    respx.get(f"{BACKEND_URL}/api/v1/rest/version/").mock(
        return_value=httpx.Response(200, json={"version": "0.1.0", "component": "backend", "fdb_api_version": 730}),
    )
    respx.get(f"{FRONTIER_URL}/api/v1/rest/version/").mock(
        return_value=httpx.Response(200, json={"version": "0.1.0", "component": "frontier"}),
    )
    runner = CliRunner()
    result = runner.invoke(main, ["status", "--backend-url", BACKEND_URL, "--frontier-url", FRONTIER_URL])
    assert result.exit_code == 0
    assert "Matyan components" in result.output
    assert "Backend" in result.output
    assert "OK" in result.output
    assert "Frontier" in result.output
    assert "Client" in result.output
    assert "0.1.0" in result.output
    assert "(local)" in result.output


@respx.mock
def test_status_command_shows_unreachable_when_backend_fails() -> None:
    """Status command prints unreachable for backend when request fails."""
    respx.get(f"{BACKEND_URL}/api/v1/rest/version/").mock(side_effect=httpx.ConnectError("offline"))
    respx.get(f"{FRONTIER_URL}/api/v1/rest/version/").mock(
        return_value=httpx.Response(200, json={"version": "0.1.0", "component": "frontier"}),
    )
    runner = CliRunner()
    result = runner.invoke(main, ["status", "--backend-url", BACKEND_URL, "--frontier-url", FRONTIER_URL])
    assert result.exit_code == 0
    assert "unreachable" in result.output
    assert "Backend" in result.output
    assert "-" in result.output
