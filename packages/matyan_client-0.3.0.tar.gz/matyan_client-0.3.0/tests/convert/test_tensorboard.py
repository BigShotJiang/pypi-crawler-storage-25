"""Tests for the TensorBoard-to-Matyan backup converter."""

from __future__ import annotations

import json
import struct
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
from matyan_api_models.backup import BackupManifest

from matyan_client.convert.tensorboard import (
    _add_trace,
    _coerce_hparam,
    _dir_name_to_hash,
    _encode_wav,
    _extract_hparams,
    _sanitize_tag,
    _try_parse_literal,
    _unflatten_slash_keys,
    convert_tensorboard,
)

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Unit tests for small helpers
# ---------------------------------------------------------------------------


class TestDirNameToHash:
    def test_deterministic(self) -> None:
        assert _dir_name_to_hash("run0") == _dir_name_to_hash("run0")

    def test_different_inputs(self) -> None:
        assert _dir_name_to_hash("run0") != _dir_name_to_hash("run1")

    def test_length(self) -> None:
        assert len(_dir_name_to_hash("run0")) == 16


class TestSanitizeTag:
    def test_simple(self) -> None:
        assert _sanitize_tag("loss") == "loss"

    def test_slash(self) -> None:
        assert _sanitize_tag("train/loss") == "train_loss"

    def test_special_chars(self) -> None:
        result = _sanitize_tag("metrics:accuracy (val)")
        assert "/" not in result
        assert ":" not in result


class TestAddTrace:
    def test_adds_new(self) -> None:
        traces: list[dict] = []
        _add_trace(traces, "loss", "float", 0.5, 10)
        assert len(traces) == 1
        assert traces[0] == {"name": "loss", "context_id": 0, "dtype": "float", "last": 0.5, "last_step": 10}

    def test_updates_existing(self) -> None:
        traces: list[dict] = [{"name": "loss", "context_id": 0, "dtype": "float", "last": 1.0, "last_step": 5}]
        _add_trace(traces, "loss", "float", 0.3, 10)
        assert len(traces) == 1
        assert traces[0]["last"] == 0.3
        assert traces[0]["last_step"] == 10

    def test_no_duplicate_different_dtype(self) -> None:
        traces: list[dict] = []
        _add_trace(traces, "output", "float", 0.5, 10)
        _add_trace(traces, "output", "text", None, 5)
        assert len(traces) == 2


class TestEncodeWav:
    def test_produces_wav_bytes(self) -> None:
        waveform = np.sin(np.linspace(0, 2 * np.pi, 100))
        wav_bytes = _encode_wav(waveform, 22050)
        assert wav_bytes[:4] == b"RIFF"
        assert b"WAVE" in wav_bytes[:12]

    def test_multichannel_flattened(self) -> None:
        waveform = np.zeros((2, 50))
        wav_bytes = _encode_wav(waveform, 16000)
        assert wav_bytes[:4] == b"RIFF"


class TestUnflattenSlashKeys:
    def test_no_slashes(self) -> None:
        assert _unflatten_slash_keys({"lr": 0.001, "bs": 32}) == {"lr": 0.001, "bs": 32}

    def test_simple_nesting(self) -> None:
        result = _unflatten_slash_keys({"a/b": 1, "a/c": 2})
        assert result == {"a": {"b": 1, "c": 2}}

    def test_deep_nesting(self) -> None:
        result = _unflatten_slash_keys({"x/y/z": 42})
        assert result == {"x": {"y": {"z": 42}}}

    def test_mixed_flat_and_nested(self) -> None:
        result = _unflatten_slash_keys({"lr": 0.01, "arch/backbone": "resnet", "arch/head": "fc"})
        assert result == {"lr": 0.01, "arch": {"backbone": "resnet", "head": "fc"}}

    def test_empty(self) -> None:
        assert _unflatten_slash_keys({}) == {}

    def test_leaf_conflict_promoted_to_dict(self) -> None:
        result = _unflatten_slash_keys({"a": 1, "a/b": 2})
        assert result == {"a": {"": 1, "b": 2}}


class TestTryParseLiteral:
    def test_plain_string_unchanged(self) -> None:
        assert _try_parse_literal("hello") == "hello"

    def test_empty_string(self) -> None:
        assert _try_parse_literal("") == ""

    def test_python_list(self) -> None:
        assert _try_parse_literal("[1, 2, 3]") == [1, 2, 3]

    def test_python_list_with_strings(self) -> None:
        assert _try_parse_literal("['a', 'b']") == ["a", "b"]

    def test_python_mixed_list(self) -> None:
        result = _try_parse_literal("[16, 'M', 32, 'M']")
        assert result == [16, "M", 32, "M"]

    def test_python_none_in_list(self) -> None:
        assert _try_parse_literal("[None, 1]") == [None, 1]

    def test_json_list(self) -> None:
        assert _try_parse_literal('[1, 2, "three"]') == [1, 2, "three"]

    def test_json_dict(self) -> None:
        assert _try_parse_literal('{"a": 1}') == {"a": 1}

    def test_python_tuple(self) -> None:
        assert _try_parse_literal("(1, 2, 3)") == (1, 2, 3)

    def test_nested_list(self) -> None:
        assert _try_parse_literal("[[1, 2], [3, 4]]") == [[1, 2], [3, 4]]

    def test_invalid_syntax_returns_string(self) -> None:
        val = "[not valid python"
        assert _try_parse_literal(val) == val

    def test_number_string_not_parsed(self) -> None:
        assert _try_parse_literal("42") == "42"

    def test_whitespace_stripped(self) -> None:
        assert _try_parse_literal("  [1, 2]  ") == [1, 2]


class TestCoerceHparam:
    def test_bool_kept(self) -> None:
        assert _coerce_hparam(True) is True

    def test_int_kept(self) -> None:
        assert _coerce_hparam(42) == 42

    def test_plain_string_kept(self) -> None:
        assert _coerce_hparam("resnet50") == "resnet50"

    def test_string_list_parsed(self) -> None:
        assert _coerce_hparam("[8, 16, 32]") == [8, 16, 32]

    def test_string_dict_parsed(self) -> None:
        assert _coerce_hparam('{"key": "val"}') == {"key": "val"}

    def test_python_repr_list_parsed(self) -> None:
        assert _coerce_hparam("[16, 'M', 32]") == [16, "M", 32]

    def test_nan_returns_none(self) -> None:
        assert _coerce_hparam(float("nan")) is None

    def test_numpy_int(self) -> None:
        assert _coerce_hparam(np.int64(7)) == 7

    def test_native_list_passthrough(self) -> None:
        assert _coerce_hparam([1, 2]) == [1, 2]


class TestExtractHparams:
    def test_empty(self) -> None:
        assert _extract_hparams(pd.DataFrame()) == {}

    def test_basic(self) -> None:
        df = pd.DataFrame({"tag": ["lr", "batch_size"], "value": [0.001, 32.0]})
        result = _extract_hparams(df)
        assert result == {"lr": 0.001, "batch_size": 32.0}

    def test_nan_skipped(self) -> None:
        df = pd.DataFrame({"tag": ["lr", "empty"], "value": [0.001, float("nan")]})
        result = _extract_hparams(df)
        assert "empty" not in result

    def test_string_values(self) -> None:
        df = pd.DataFrame({"tag": ["model"], "value": ["resnet50"]})
        result = _extract_hparams(df)
        assert result["model"] == "resnet50"

    def test_slash_separated_tags_unflattened(self) -> None:
        df = pd.DataFrame(
            {
                "tag": ["optimizer/type", "optimizer/lr", "arch/backbone/name", "batch_size"],
                "value": ["adam", 0.001, "resnet50", 32.0],
            },
        )
        result = _extract_hparams(df)
        assert result == {
            "optimizer": {"type": "adam", "lr": 0.001},
            "arch": {"backbone": {"name": "resnet50"}},
            "batch_size": 32.0,
        }


# ---------------------------------------------------------------------------
# Integration tests via mocked SummaryReader
# ---------------------------------------------------------------------------


def _make_mock_reader(
    scalars: pd.DataFrame | None = None,
    tensors: pd.DataFrame | None = None,
    hparams: pd.DataFrame | None = None,
    text: pd.DataFrame | None = None,
    histograms: pd.DataFrame | None = None,
    images: pd.DataFrame | None = None,
    audio: pd.DataFrame | None = None,
) -> MagicMock:
    mock = MagicMock()
    mock.scalars = scalars if scalars is not None else pd.DataFrame()
    mock.tensors = tensors if tensors is not None else pd.DataFrame()
    mock.hparams = hparams if hparams is not None else pd.DataFrame()
    mock.text = text if text is not None else pd.DataFrame()
    mock.histograms = histograms if histograms is not None else pd.DataFrame()
    mock.images = images if images is not None else pd.DataFrame()
    mock.audio = audio if audio is not None else pd.DataFrame()
    return mock


def _read_json(path: Path) -> Any:  # noqa: ANN401
    return json.loads(path.read_text())


def _read_jsonl(path: Path) -> list[dict]:
    records = []
    with path.open() as f:
        for line in f:
            stripped = line.strip()
            if stripped:
                records.append(json.loads(stripped))
    return records


def _create_tb_input_dir(tmp_path: Path, run_names: list[str] | None = None) -> Path:
    """Create a directory tree that _discover_run_dirs will find as TensorBoard runs.

    Creates tb_input/run0/events.out.tfevents.dummy (and optionally run1, ...).
    Returns the path to the input directory (tmp_path / "tb_input").
    """
    if run_names is None:
        run_names = ["run0"]
    input_dir = tmp_path / "tb_input"
    for name in run_names:
        run_dir = input_dir / name
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "events.out.tfevents.dummy").write_bytes(b"")
    return input_dir


class TestConvertScalars:
    def test_basic_scalar_conversion(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0, 1, 2],
                "tag": ["loss", "loss", "loss"],
                "value": [2.0, 1.5, 1.0],
                "wall_time": [1000.0, 1001.0, 1002.0],
                "dir_name": ["run0", "run0", "run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        assert result.is_dir()
        manifest = BackupManifest.read(result)
        assert manifest.run_count == 1
        assert len(manifest.run_hashes) == 1

        run_hash = manifest.run_hashes[0]
        run_dir = result / "runs" / run_hash

        meta = _read_json(run_dir / "run.json")
        assert meta["name"] == "run0"
        assert meta["active"] is False
        assert meta["created_at"] == 1000.0
        assert meta["finalized_at"] == 1002.0

        traces = _read_json(run_dir / "traces.json")
        assert len(traces) == 1
        assert traces[0]["name"] == "loss"
        assert traces[0]["dtype"] == "float"
        assert traces[0]["last"] == 1.0
        assert traces[0]["last_step"] == 2

        contexts = _read_json(run_dir / "contexts.json")
        assert contexts == {"0": {}}

        records = _read_jsonl(run_dir / "sequences.jsonl")
        assert len(records) == 3
        assert records[0]["value"] == 2.0
        assert records[0]["time"] == 1000.0


class TestConvertText:
    def test_text_events(self, tmp_path: Path) -> None:
        text = pd.DataFrame(
            {
                "step": [0, 1],
                "tag": ["predictions", "predictions"],
                "value": ["hello world", "foo bar"],
                "wall_time": [1000.0, 1001.0],
                "dir_name": ["run0", "run0"],
            },
        )
        mock_reader = _make_mock_reader(text=text)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        run_hash = BackupManifest.read(result).run_hashes[0]
        traces = _read_json(result / "runs" / run_hash / "traces.json")
        assert traces[0]["dtype"] == "text"

        records = _read_jsonl(result / "runs" / run_hash / "sequences.jsonl")
        assert records[0]["value"] == {"type": "text", "data": "hello world"}


class TestConvertHistograms:
    def test_histogram_events(self, tmp_path: Path) -> None:
        counts = np.array([0.0, 5.0, 10.0, 3.0])
        limits = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
        histograms = pd.DataFrame(
            {
                "step": [0],
                "tag": ["weights"],
                "counts": [counts],
                "limits": [limits],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(histograms=histograms)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        run_hash = BackupManifest.read(result).run_hashes[0]
        traces = _read_json(result / "runs" / run_hash / "traces.json")
        assert traces[0]["dtype"] == "distribution"

        records = _read_jsonl(result / "runs" / run_hash / "sequences.jsonl")
        val = records[0]["value"]
        assert val["type"] == "distribution"
        assert val["bin_count"] == 4
        assert val["range"] == [-2.0, 2.0]
        assert val["dtype"] == "float64"

        blob_hex = val["data"]
        blob_bytes = bytes.fromhex(blob_hex)
        unpacked = struct.unpack(f"<{len(counts)}d", blob_bytes)
        np.testing.assert_array_almost_equal(unpacked, counts)


class TestConvertImages:
    def test_image_events(self, tmp_path: Path) -> None:
        img_arr = np.zeros((10, 10, 3), dtype=np.uint8)
        img_arr[..., 0] = 255
        images = pd.DataFrame(
            {
                "step": [0],
                "tag": ["my_image"],
                "value": [img_arr],
                "wall_time": [1000.0],
                "width": [10],
                "height": [10],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(images=images)
        input_dir = _create_tb_input_dir(tmp_path)

        with (
            patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader),
            patch("matyan_client.convert.tensorboard._has_tensorflow", return_value=True),
        ):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        manifest = BackupManifest.read(result)
        assert manifest.blob_count == 1
        assert manifest.include_blobs is True

        run_hash = manifest.run_hashes[0]
        run_dir = result / "runs" / run_hash

        traces = _read_json(run_dir / "traces.json")
        assert any(t["dtype"] == "image" for t in traces)

        records = _read_jsonl(run_dir / "sequences.jsonl")
        val = records[0]["value"]
        assert val["type"] == "image"
        assert val["format"] == "png"
        assert val["width"] == 10
        assert val["height"] == 10
        assert "s3_key" in val

        blob_path = run_dir / "blobs" / "seq" / "my_image" / "0.png"
        assert blob_path.exists()
        png_bytes = blob_path.read_bytes()
        assert png_bytes[:4] == b"\x89PNG"


class TestConvertAudio:
    def test_audio_events(self, tmp_path: Path) -> None:
        waveform = np.sin(np.linspace(0, 2 * np.pi, 100))
        audio = pd.DataFrame(
            {
                "step": [0],
                "tag": ["my_audio"],
                "value": [waveform],
                "wall_time": [1000.0],
                "sample_rate": [22050],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(audio=audio)
        input_dir = _create_tb_input_dir(tmp_path)

        with (
            patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader),
            patch("matyan_client.convert.tensorboard._has_tensorflow", return_value=True),
        ):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        manifest = BackupManifest.read(result)
        assert manifest.blob_count == 1

        run_hash = manifest.run_hashes[0]
        run_dir = result / "runs" / run_hash

        traces = _read_json(run_dir / "traces.json")
        assert any(t["dtype"] == "audio" for t in traces)

        records = _read_jsonl(run_dir / "sequences.jsonl")
        val = records[0]["value"]
        assert val["type"] == "audio"
        assert val["format"] == "wav"
        assert "s3_key" in val

        blob_path = run_dir / "blobs" / "seq" / "my_audio" / "0.wav"
        assert blob_path.exists()
        assert blob_path.read_bytes()[:4] == b"RIFF"


class TestConvertHparams:
    def test_hparams_in_attrs(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0],
                "tag": ["loss"],
                "value": [1.0],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        hparams = pd.DataFrame(
            {
                "tag": ["lr", "batch_size"],
                "value": [0.001, 32.0],
                "dir_name": ["run0", "run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars, hparams=hparams)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        run_hash = BackupManifest.read(result).run_hashes[0]
        attrs = _read_json(result / "runs" / run_hash / "attrs.json")
        assert "hparams" in attrs
        assert attrs["hparams"]["lr"] == 0.001
        assert attrs["hparams"]["batch_size"] == 32.0

    def test_slash_hparams_nested_in_attrs(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0],
                "tag": ["loss"],
                "value": [1.0],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        hparams = pd.DataFrame(
            {
                "tag": ["optimizer/type", "optimizer/lr", "arch/backbone"],
                "value": ["adam", 0.001, "resnet"],
                "dir_name": ["run0", "run0", "run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars, hparams=hparams)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        run_hash = BackupManifest.read(result).run_hashes[0]
        attrs = _read_json(result / "runs" / run_hash / "attrs.json")
        assert attrs["hparams"]["optimizer"]["type"] == "adam"
        assert attrs["hparams"]["optimizer"]["lr"] == 0.001
        assert attrs["hparams"]["arch"]["backbone"] == "resnet"


class TestMultiRun:
    def test_two_runs(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0, 0],
                "tag": ["loss", "loss"],
                "value": [2.0, 3.0],
                "wall_time": [1000.0, 1000.0],
                "dir_name": ["run0", "run1"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path, run_names=["run0", "run1"])

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        manifest = BackupManifest.read(result)
        assert manifest.run_count == 2
        assert len(manifest.run_hashes) == 2
        for rh in manifest.run_hashes:
            assert (result / "runs" / rh / "run.json").exists()


class TestExperimentAssignment:
    def test_creates_entities_file(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0],
                "tag": ["loss"],
                "value": [1.0],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(
                str(input_dir),
                str(tmp_path),
                experiment="my-experiment",
                workers=1,
            )

        entities = _read_jsonl(result / "entities.jsonl")
        assert len(entities) == 1
        assert entities[0]["entity_type"] == "experiment"
        assert entities[0]["data"]["name"] == "my-experiment"

        run_hash = BackupManifest.read(result).run_hashes[0]
        meta = _read_json(result / "runs" / run_hash / "run.json")
        assert meta["experiment_id"] is not None

        manifest = BackupManifest.read(result)
        assert manifest.entity_counts.get("experiment") == 1


class TestManifestCorrectness:
    def test_manifest_fields(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0],
                "tag": ["loss"],
                "value": [1.0],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        manifest = BackupManifest.read(result)
        assert manifest.format_version == 1
        assert manifest.run_count == 1
        assert manifest.created_at != ""
        assert manifest.filters["source"] == "tensorboard"

    def test_validation_passes(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0],
                "tag": ["loss"],
                "value": [1.0],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        manifest = BackupManifest.read(result)
        errors = manifest.validate(result)
        assert errors == []


class TestGracefulDegradation:
    def test_empty_images_audio(self, tmp_path: Path) -> None:
        """Converter works when images/audio DataFrames are empty (no TF)."""
        scalars = pd.DataFrame(
            {
                "step": [0],
                "tag": ["loss"],
                "value": [1.0],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        manifest = BackupManifest.read(result)
        assert manifest.blob_count == 0
        assert manifest.include_blobs is False

    def test_scalars_only(self, tmp_path: Path) -> None:
        """Works with only scalar data."""
        scalars = pd.DataFrame(
            {
                "step": [0, 1],
                "tag": ["acc", "acc"],
                "value": [0.5, 0.9],
                "wall_time": [1000.0, 1001.0],
                "dir_name": ["run0", "run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(str(input_dir), str(tmp_path), workers=1)

        manifest = BackupManifest.read(result)
        assert manifest.run_count == 1
        errors = manifest.validate(result)
        assert errors == []


class TestCompression:
    def test_compress_produces_tarball(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0],
                "tag": ["loss"],
                "value": [1.0],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        mock_reader = _make_mock_reader(scalars=scalars)
        input_dir = _create_tb_input_dir(tmp_path)

        with patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader):
            result = convert_tensorboard(
                str(input_dir),
                str(tmp_path),
                compress=True,
                workers=1,
            )

        assert result.suffix == ".gz"
        assert result.exists()


class TestAllEventTypes:
    """End-to-end test with all event types in a single run."""

    def test_all_types_combined(self, tmp_path: Path) -> None:
        scalars = pd.DataFrame(
            {
                "step": [0, 1],
                "tag": ["loss", "loss"],
                "value": [2.0, 1.0],
                "wall_time": [1000.0, 1001.0],
                "dir_name": ["run0", "run0"],
            },
        )
        text = pd.DataFrame(
            {
                "step": [0],
                "tag": ["log"],
                "value": ["started training"],
                "wall_time": [1000.0],
                "dir_name": ["run0"],
            },
        )
        counts = np.array([0.0, 5.0, 10.0])
        limits = np.array([-1.0, 0.0, 1.0, 2.0])
        histograms = pd.DataFrame(
            {
                "step": [0],
                "tag": ["weights"],
                "counts": [counts],
                "limits": [limits],
                "wall_time": [1000.5],
                "dir_name": ["run0"],
            },
        )
        img_arr = np.zeros((8, 8, 3), dtype=np.uint8)
        images = pd.DataFrame(
            {
                "step": [0],
                "tag": ["sample"],
                "value": [img_arr],
                "wall_time": [1000.0],
                "width": [8],
                "height": [8],
                "dir_name": ["run0"],
            },
        )
        waveform = np.sin(np.linspace(0, 2 * np.pi, 50))
        audio = pd.DataFrame(
            {
                "step": [0],
                "tag": ["clip"],
                "value": [waveform],
                "wall_time": [1000.0],
                "sample_rate": [16000],
                "dir_name": ["run0"],
            },
        )
        hparams = pd.DataFrame(
            {
                "tag": ["lr"],
                "value": [0.01],
                "dir_name": ["run0"],
            },
        )

        mock_reader = _make_mock_reader(
            scalars=scalars,
            text=text,
            histograms=histograms,
            images=images,
            audio=audio,
            hparams=hparams,
        )
        input_dir = _create_tb_input_dir(tmp_path)

        with (
            patch("matyan_client.convert.tensorboard.SummaryReader", return_value=mock_reader),
            patch("matyan_client.convert.tensorboard._has_tensorflow", return_value=True),
        ):
            result = convert_tensorboard(
                str(input_dir),
                str(tmp_path),
                experiment="combined",
                workers=1,
            )

        manifest = BackupManifest.read(result)
        assert manifest.run_count == 1
        assert manifest.blob_count == 2
        assert manifest.entity_counts.get("experiment") == 1
        assert manifest.validate(result) == []

        run_hash = manifest.run_hashes[0]
        run_dir = result / "runs" / run_hash

        traces = _read_json(run_dir / "traces.json")
        dtypes = {t["dtype"] for t in traces}
        assert "float" in dtypes
        assert "text" in dtypes
        assert "distribution" in dtypes
        assert "image" in dtypes
        assert "audio" in dtypes

        attrs = _read_json(run_dir / "attrs.json")
        assert attrs["hparams"]["lr"] == 0.01

        records = _read_jsonl(run_dir / "sequences.jsonl")
        assert len(records) == 6
