"""Minimal Fast.ai training with Matyan and maximal tracking.

MatyanCallback logs metrics and config; a custom callback holds a reference to
MatyanCallback and calls shared helpers in after_epoch (once) and file artifact at end.

Usage:
    pip install matyan-client[fastai] numpy plotly fastai
    python examples/fastai_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from fastai.learner import Callback
from fastai.metrics import accuracy
from fastai.tabular.all import TabularDataLoaders, tabular_learner
from fastcore.basics import store_attr

from matyan_client.adapters.fastai import MatyanCallback

EPOCHS = 2


class MaximalTrackingCallback(Callback):
    """Calls shared tracking helpers after first epoch."""

    def __init__(self, matyan_callback: MatyanCallback) -> None:
        store_attr("matyan_callback")
        self._did_helpers = False

    def after_epoch(self) -> None:
        run = self.matyan_callback.experiment
        if self._did_helpers:
            return
        self._did_helpers = True
        track_log_messages(run)
        track_sample_images(run, step=self.epoch, count=2)
        track_sample_distribution(run, "sample_dist", step=self.epoch)
        track_text(run, "note", "Fast.ai maximal tracking example", step=self.epoch)
        track_audio_sample(run, "tones", step=self.epoch)
        if getattr(self, "recorder", None) and getattr(self.recorder, "values", None):
            vals = (
                self.recorder.values.to_numpy()
                if hasattr(self.recorder.values, "to_numpy")
                else list(self.recorder.values)
            )
            if vals:
                track_loss_figure(run, vals, vals, step=self.epoch)
        track_file_artifact(run, "fastai_artifact.txt")
        run.log_info("Fast.ai training finished.")


def main() -> None:
    np.random.seed(42)
    n = 100
    df = pd.DataFrame(
        np.random.randn(n, 5).astype("float32"),
        columns=["x0", "x1", "x2", "x3", "x4"],
    )
    df["y"] = (df["x0"] > 0).astype(int)

    dls = TabularDataLoaders.from_df(
        df,
        y_names="y",
        cont_names=["x0", "x1", "x2", "x3", "x4"],
    )
    learn = tabular_learner(dls, layers=[10, 10], metrics=accuracy)
    matyan_callback = MatyanCallback(experiment_name="fastai-maximal")
    helper_callback = MaximalTrackingCallback(matyan_callback)
    learn.fit(EPOCHS, cbs=[matyan_callback, helper_callback])


if __name__ == "__main__":
    main()
