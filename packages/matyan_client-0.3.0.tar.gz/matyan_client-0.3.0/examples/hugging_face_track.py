"""Minimal Hugging Face Trainer run with Matyan and maximal tracking.

MatyanCallback logs metrics; a custom TrainerCallback holds a reference to
MatyanCallback and in on_train_end calls shared helpers (before MatyanCallback
closes the run). Register helper callback before MatyanCallback so it runs first.

Usage:
    pip install matyan-client[hugging_face] numpy plotly transformers datasets
    python examples/hugging_face_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from datasets import load_dataset
from transformers import AutoModelForSequenceClassification, AutoTokenizer, Trainer, TrainingArguments
from transformers.trainer_callback import TrainerCallback

from matyan_client.adapters.hugging_face import MatyanCallback


class MaximalTrackingCallback(TrainerCallback):
    """Calls shared tracking helpers in on_train_end. Register before MatyanCallback."""

    def __init__(self, matyan_callback: MatyanCallback) -> None:
        self._matyan = matyan_callback

    def on_train_end(self, args, state, control, **kwargs) -> None:
        if not state.is_world_process_zero:
            return
        run = self._matyan.experiment
        track_log_messages(run)
        track_sample_images(run, step=0, count=2)
        track_sample_distribution(run, "sample_dist", step=0)
        track_text(run, "note", "Hugging Face maximal tracking example", step=0)
        track_audio_sample(run, "tones", step=0)
        track_loss_figure(
            run,
            [0.8, 0.6, 0.5],
            [0.82, 0.62, 0.52],
            step=0,
        )
        track_file_artifact(run, "hugging_face_artifact.txt")
        run.log_info("Hugging Face training finished.")


def main() -> None:
    # Minimal glue-style NER or text classification
    dataset = load_dataset("imdb", split="train[:80]")

    model_name = "distilbert-base-uncased"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)

    def tokenize(examples):
        out = tokenizer(examples["text"], truncation=True, max_length=64, padding="max_length")
        out["label"] = examples["label"]
        return out

    tokenized = dataset.map(tokenize, batched=True, remove_columns=dataset.column_names)
    tokenized.set_format("torch", columns=["input_ids", "attention_mask", "label"])

    with tempfile.TemporaryDirectory() as tmp_dir:
        training_args = TrainingArguments(
            output_dir=tmp_dir,
            num_train_epochs=1,
            per_device_train_batch_size=4,
            report_to=[],
        )
        matyan_callback = MatyanCallback(experiment="hugging_face-maximal")
        helper_callback = MaximalTrackingCallback(matyan_callback)

        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=tokenized,
            callbacks=[
                helper_callback,
                matyan_callback,
            ],  # Helper must run before MatyanCallback so run is still open in on_train_end.
        )
        trainer.train()


if __name__ == "__main__":
    main()
