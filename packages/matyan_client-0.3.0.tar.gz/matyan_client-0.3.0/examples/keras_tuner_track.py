"""Minimal Keras Tuner run with Matyan and maximal tracking.

MatyanCallback logs trial hyperparameters and batch metrics; we use a custom
callback that holds a reference to MatyanCallback and calls shared helpers
in on_epoch_begin or on_epoch_end when the run is available.

Usage:
    pip install matyan-client[keras_tuner] numpy plotly keras keras-tuner
    python examples/keras_tuner_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from keras import Sequential, layers
from keras import callbacks as keras_callbacks
from keras_tuner import RandomSearch

from matyan_client.adapters.keras_tuner import MatyanCallback

MAX_TRIALS = 2
EPOCHS = 1
BATCH_SIZE = 32


def build_model(hp) -> Sequential:  # noqa: ANN001
    model = Sequential(
        [
            layers.Input(shape=(10,)),
            layers.Dense(hp.Int("units", 8, 16), activation="relu"),
            layers.Dense(1, activation="sigmoid"),
        ],
    )
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


class HelperCallback(keras_callbacks.Callback):
    """Calls shared tracking helpers when the trial run is available."""

    def __init__(self, matyan_callback: MatyanCallback) -> None:
        super().__init__()
        self._matyan = matyan_callback
        self._did_helpers = False

    def on_epoch_end(self, epoch: int, logs: dict | None = None) -> None:
        run = self._matyan.experiment
        if run is None or self._did_helpers:
            return
        self._did_helpers = True
        track_log_messages(run)
        track_sample_images(run, step=epoch, count=2)
        track_sample_distribution(run, "sample_dist", step=epoch)
        track_text(run, "note", "Keras Tuner maximal tracking example", step=epoch)
        track_audio_sample(run, "tones", step=epoch)
        if logs:
            track_loss_figure(
                run,
                [logs.get("loss", 0.5)],
                [logs.get("val_loss", 0.5)],
                step=epoch,
            )
        track_file_artifact(run, "keras_tuner_artifact.txt")


def main() -> None:
    np.random.seed(42)
    X = np.random.randn(100, 10).astype("float32")
    y = (X[:, 0] > 0).astype("float32")

    tuner = RandomSearch(
        build_model,
        objective="val_loss",
        max_trials=MAX_TRIALS,
        executions_per_trial=1,
    )
    matyan_callback = MatyanCallback(tuner=tuner, experiment="keras-tuner-maximal")
    helper_callback = HelperCallback(matyan_callback)
    tuner.search(
        X,
        y,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        validation_split=0.2,
        callbacks=[matyan_callback, helper_callback],
    )


if __name__ == "__main__":
    main()
