"""Train a small MNIST autoencoder with PyTorch Lightning, logging to Matyan.

Exercises all major tracking features:
  - scalar metrics (train/val/test loss)
  - hyperparameters (via save_hyperparameters)
  - images (sample reconstructions)
  - text (per-epoch summaries)
  - distributions (encoder weight histograms)
  - figures (plotly loss curve)
  - structured log messages (log_info / log_warning)
  - system params (automatic via log_system_params=True)
  - file artifacts (run.log_artifact via shared helper)

Usage:
    # Make sure the Matyan stack is running (backend + frontier + workers)
    pip install torch torchvision lightning matyan-client plotly
    python examples/pytorch_lightning_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from typing_extensions import override

# Allow importing shared helpers when run as script from repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from typing import TYPE_CHECKING

import lightning.pytorch as pl
import numpy as np
import plotly.graph_objects as go
import torch
from _tracking_helpers import track_file_artifact, track_log_messages
from torch import nn, optim, utils
from torchvision.datasets import MNIST
from torchvision.transforms import ToTensor

from matyan_client.adapters.pytorch_lightning import MatyanLogger
from matyan_client.objects import Audio, Distribution, Figure, Image, Text

if TYPE_CHECKING:
    from matyan_client import Run

BATCH_SIZE = 64
MAX_EPOCHS = 3
LR = 1e-3
LATENT_DIM = 16


class LitAutoEncoder(pl.LightningModule):
    @override
    def __init__(self, latent_dim: int = LATENT_DIM, lr: float = LR) -> None:
        super().__init__()
        self.save_hyperparameters()
        self.encoder = nn.Sequential(
            nn.Linear(28 * 28, 128),
            nn.ReLU(),
            nn.Linear(128, latent_dim),
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 28 * 28),
        )
        self._epoch_train_losses: list[float] = []
        self._epoch_val_losses: list[float] = []

    def _shared_step(self, batch: tuple[torch.Tensor, torch.Tensor]) -> torch.Tensor:
        x, _ = batch
        x = x.view(x.size(0), -1)
        z = self.encoder(x)
        x_hat = self.decoder(z)
        return nn.functional.mse_loss(x_hat, x)

    @override
    def training_step(self, batch: tuple[torch.Tensor, torch.Tensor], batch_idx: int) -> torch.Tensor:
        loss = self._shared_step(batch)
        self.log("train_loss", loss, prog_bar=True)
        return loss

    @override
    def validation_step(self, batch: tuple[torch.Tensor, torch.Tensor], batch_idx: int) -> None:
        loss = self._shared_step(batch)
        self.log("val_loss", loss, prog_bar=True)

    @override
    def test_step(self, batch: tuple[torch.Tensor, torch.Tensor], batch_idx: int) -> None:
        loss = self._shared_step(batch)
        self.log("test_loss", loss, prog_bar=True)

    def configure_optimizers(self) -> optim.Optimizer:
        return optim.Adam(self.parameters(), lr=self.hparams.lr)


def _get_run(logger: MatyanLogger) -> Run:
    """Access the underlying matyan Run from the logger."""
    return logger.experiment


def _track_reconstructions(run: Run, model: LitAutoEncoder, dataset: MNIST, epoch: int) -> None:
    """Track sample input/reconstruction image pairs."""
    model.eval()
    with torch.no_grad():
        for i in range(3):
            img_tensor, label = dataset[i]
            flat = img_tensor.view(1, -1)
            recon = model.decoder(model.encoder(flat)).view(28, 28)
            recon_np = (recon.clamp(0, 1) * 255).byte().numpy()
            run.track(
                Image(recon_np, caption=f"digit {label}, epoch {epoch}"),
                name="reconstructions",
                step=epoch * 3 + i,
                context={"subset": "val"},
            )


def _track_weight_distributions(run: Run, model: LitAutoEncoder, epoch: int) -> None:
    """Track encoder weight distributions."""
    for name, param in model.encoder.named_parameters():
        if "weight" in name:
            run.track(
                Distribution(param.detach().cpu().numpy().ravel().tolist()),
                name=f"weights/{name}",
                step=epoch,
            )


def _track_text_summary(run: Run, epoch: int, train_loss: float, val_loss: float) -> None:
    """Track a per-epoch text summary."""
    run.track(
        Text(f"Epoch {epoch}: train_loss={train_loss:.5f}, val_loss={val_loss:.5f}"),
        name="epoch_summaries",
        step=epoch,
    )


def _track_audio_samples(run: Run, epoch: int) -> None:
    """Track synthetic audio clips generated from numpy sine waves."""
    rate = 22050
    duration = 0.3
    t = np.linspace(0, duration, int(rate * duration), dtype=np.float32)
    freqs = [261.63, 329.63, 392.00]  # C4, E4, G4
    for i, freq in enumerate(freqs):
        wave = np.sin(2 * np.pi * freq * t)
        run.track(
            Audio(wave, format_="wav", caption=f"{freq:.0f}Hz, epoch {epoch}", rate=rate),
            name="audio_tones",
            step=epoch * len(freqs) + i,
        )


def _track_loss_figure(run: Run, train_losses: list[float], val_losses: list[float]) -> None:
    """Track a plotly figure of the training curve."""
    fig = go.Figure()
    epochs = list(range(len(train_losses)))
    fig.add_trace(go.Scatter(x=epochs, y=train_losses, mode="lines+markers", name="train"))
    fig.add_trace(go.Scatter(x=epochs, y=val_losses, mode="lines+markers", name="val"))
    fig.update_layout(title="Loss Curve", xaxis_title="Epoch", yaxis_title="MSE Loss")
    run.track(Figure(fig), name="loss_curve", step=0)


class CustomCallback(pl.Callback):
    """Callback that logs custom objects at epoch boundaries."""

    def __init__(self, matyan_logger: MatyanLogger, train_set: MNIST) -> None:
        super().__init__()
        self._matyan_logger = matyan_logger
        self._train_set = train_set
        self._train_losses: list[float] = []
        self._val_losses: list[float] = []

    def on_train_epoch_end(self, trainer: pl.Trainer, pl_module: LitAutoEncoder) -> None:
        epoch = trainer.current_epoch
        run = _get_run(self._matyan_logger)

        train_loss = trainer.callback_metrics.get("train_loss")
        if train_loss is not None:
            self._train_losses.append(train_loss.item())

        run.log_info(f"Completed training epoch {epoch}")

    def on_validation_epoch_end(
        self,
        trainer: pl.Trainer,
        pl_module: LitAutoEncoder,
    ) -> None:
        if trainer.sanity_checking:
            return

        epoch = trainer.current_epoch
        run = _get_run(self._matyan_logger)

        val_loss = trainer.callback_metrics.get("val_loss")
        if val_loss is not None:
            self._val_losses.append(val_loss.item())

        _track_reconstructions(run, pl_module, self._train_set, epoch)
        _track_weight_distributions(run, pl_module, epoch)
        _track_audio_samples(run, epoch)

        if self._train_losses and self._val_losses:
            _track_text_summary(run, epoch, self._train_losses[-1], self._val_losses[-1])

        run.log_info(f"Epoch {epoch} val_loss={val_loss.item():.5f}" if val_loss else f"Epoch {epoch} done")

    def on_train_end(self, trainer: pl.Trainer, pl_module: LitAutoEncoder) -> None:
        run = _get_run(self._matyan_logger)
        if self._train_losses and self._val_losses:
            _track_loss_figure(run, self._train_losses, self._val_losses)
        track_log_messages(run)
        track_file_artifact(run)
        run.log_info("Training finished")

    def on_test_end(self, trainer: pl.Trainer, pl_module: LitAutoEncoder) -> None:
        run = _get_run(self._matyan_logger)
        test_loss = trainer.callback_metrics.get("test_loss", "N/A")
        run.log_info(f"Final test_loss={test_loss}")


def main() -> None:
    data_dir = os.path.join(os.getcwd(), "data")

    train_set = MNIST(data_dir, train=True, download=True, transform=ToTensor())
    train_set, val_set = utils.data.random_split(train_set, [55000, 5000])
    test_set = MNIST(data_dir, train=False, download=True, transform=ToTensor())

    train_loader = utils.data.DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True, num_workers=2)
    val_loader = utils.data.DataLoader(val_set, batch_size=BATCH_SIZE, num_workers=2)
    test_loader = utils.data.DataLoader(test_set, batch_size=BATCH_SIZE, num_workers=2)

    matyan_logger = MatyanLogger(
        experiment="mnist-autoencoder",
        run_name="lightning-demo",
    )

    model = LitAutoEncoder(latent_dim=LATENT_DIM, lr=LR)

    callback = CustomCallback(matyan_logger, train_set.dataset)

    trainer = pl.Trainer(
        max_epochs=MAX_EPOCHS,
        logger=matyan_logger,
        callbacks=[callback],
        enable_checkpointing=False,
    )

    trainer.fit(model, train_dataloaders=train_loader, val_dataloaders=val_loader)
    trainer.test(model, dataloaders=test_loader)

    matyan_logger.finalize()


if __name__ == "__main__":
    main()
