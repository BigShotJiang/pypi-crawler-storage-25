#!/usr/bin/env bash
# Run all adapter example scripts one by one.
# Stops on first failure (set -e).
# Usage: from repo root, run:
#   bash examples/run_all_examples.sh
# Or: cd examples && bash run_all_examples.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR"

EXAMPLES=(
  pytorch_lightning_track.py
  keras_track.py
  tensorflow_track.py
  xgboost_track.py
  lightgbm_track.py
  catboost_track.py
  optuna_track.py
  keras_tuner_track.py
  prophet_track.py
  sb3_track.py
  fastai_track.py
  mxnet_track.py
  pytorch_ignite_track.py
  hugging_face_track.py
)

for name in "${EXAMPLES[@]}"; do
  path="$SCRIPT_DIR/$name"
  if [[ ! -f "$path" ]]; then
    echo "[SKIP] $name (file not found)"
    continue
  fi
  echo "--- Running $name ---"
  python "$path"
  r=$?
  if [[ $r -eq 123 ]] && [[ "$name" == "mxnet_track.py" ]]; then
    echo "[SKIP] $name (MXNet unavailable on this system)"
  elif [[ $r -ne 0 ]]; then
    exit $r
  fi
  echo ""
done

echo "All examples completed successfully."
