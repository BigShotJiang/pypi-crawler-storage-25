"""Minimal CatBoost training with Matyan and maximal tracking.

MatyanLogger parses training output and logs metrics; after fit() we use
logger.experiment to call shared helpers for images, text, distributions,
figures, audio, log messages, and file artifacts.

Usage:
    pip install matyan-client[catboost] numpy plotly
    python examples/catboost_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from catboost import CatBoostClassifier, Pool

from matyan_client.adapters.catboost import MatyanLogger

N_ITERATIONS = 4


def main() -> None:
    np.random.seed(42)
    n = 200
    X = np.random.randn(n, 4).astype("float32")
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    train_pool = Pool(X, label=y)

    matyan_logger = MatyanLogger(experiment="catboost-maximal")
    model = CatBoostClassifier(
        iterations=N_ITERATIONS,
        verbose=10,
    )
    model.fit(train_pool, log_cout=matyan_logger)

    run = matyan_logger.experiment
    run["hparams.iterations"] = N_ITERATIONS
    track_log_messages(run)
    track_sample_images(run, step=0, count=2)
    track_sample_distribution(run, "sample_dist", step=0)
    track_text(run, "note", "CatBoost maximal tracking example", step=0)
    track_audio_sample(run, "tones", step=0)
    track_loss_figure(
        run,
        [0.65 - i * 0.1 for i in range(4)],
        [0.67 - i * 0.1 for i in range(4)],
        step=0,
    )
    track_file_artifact(run, "catboost_artifact.txt")
    run.log_info("CatBoost training finished.")


if __name__ == "__main__":
    main()
