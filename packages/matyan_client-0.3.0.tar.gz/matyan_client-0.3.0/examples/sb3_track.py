"""Minimal Stable-Baselines3 training with Matyan and maximal tracking.

MatyanCallback logs config and metrics; a custom BaseCallback holds a reference
to MatyanCallback and calls shared helpers in _on_training_end.

Usage:
    pip install matyan-client[sb3] numpy plotly stable-baselines3
    python examples/sb3_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import DummyVecEnv

from matyan_client.adapters.sb3 import MatyanCallback

TOTAL_TIMESTEPS = 500


class MaximalTrackingCallback(BaseCallback):
    """Calls shared tracking helpers at training end."""

    def __init__(self, matyan_callback: MatyanCallback, verbose: int = 0) -> None:
        super().__init__(verbose)
        self._matyan = matyan_callback

    def _on_step(self) -> bool:
        return True

    def _on_training_end(self) -> None:
        run = self._matyan.experiment
        track_log_messages(run)
        track_sample_images(run, step=0, count=2)
        track_sample_distribution(run, "sample_dist", step=0)
        track_text(run, "note", "SB3 maximal tracking example", step=0)
        track_audio_sample(run, "tones", step=0)
        track_loss_figure(
            run,
            [0.8 - i * 0.1 for i in range(3)],
            [0.82 - i * 0.1 for i in range(3)],
            step=0,
        )
        track_file_artifact(run, "sb3_artifact.txt")
        run.log_info("SB3 training finished.")


def main() -> None:
    env = make_vec_env("CartPole-v1", n_envs=1, vec_env_cls=DummyVecEnv)
    matyan_callback = MatyanCallback(experiment_name="sb3-maximal")
    helper_callback = MaximalTrackingCallback(matyan_callback)
    model = PPO("MlpPolicy", env, verbose=0)
    model.learn(
        total_timesteps=TOTAL_TIMESTEPS,
        callback=[matyan_callback, helper_callback],
    )
    env.close()


if __name__ == "__main__":
    main()
