"""Minimal XGBoost training with Matyan and maximal tracking.

MatyanCallback logs evaluation metrics; after train() a custom callback runs
before the MatyanCallback closes the run and calls shared helpers for
images, text, distributions, figures, audio, log messages, and file artifacts.

Usage:
    pip install matyan-client[xgboost] numpy plotly
    python examples/xgboost_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)
from xgboost import DMatrix, train
from xgboost.callback import TrainingCallback

from matyan_client.adapters.xgboost import MatyanCallback

N_ROUNDS = 4


class MaximalTrackingCallback(TrainingCallback):
    """Runs before MatyanCallback.after_training so the run is still open."""

    def __init__(self, matyan_callback: MatyanCallback) -> None:
        self._matyan = matyan_callback

    def after_training(self, model):
        run = self._matyan.experiment
        run["hparams.n_rounds"] = N_ROUNDS
        track_log_messages(run)
        track_sample_images(run, step=0, count=2)
        track_sample_distribution(run, "sample_dist", step=0)
        track_text(run, "note", "XGBoost maximal tracking example", step=0)
        track_audio_sample(run, "tones", step=0)
        track_loss_figure(
            run,
            [0.5 - i * 0.05 for i in range(4)],
            [0.52 - i * 0.05 for i in range(4)],
            step=0,
        )
        track_file_artifact(run, "xgboost_artifact.txt")
        return model


def main() -> None:
    np.random.seed(42)
    n = 200
    X = np.random.randn(n, 4).astype("float32")
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    dtrain = DMatrix(X, label=y)
    evals = [(dtrain, "train")]

    matyan_callback = MatyanCallback(experiment="xgboost-maximal")
    helper_callback = MaximalTrackingCallback(matyan_callback)
    # Helper must run before MatyanCallback so run is still open when we log.
    callbacks = [helper_callback, matyan_callback]

    train(
        {"max_depth": 2, "eta": 0.3, "objective": "binary:logistic"},
        dtrain,
        num_boost_round=N_ROUNDS,
        evals=evals,
        callbacks=callbacks,
    )


if __name__ == "__main__":
    main()
