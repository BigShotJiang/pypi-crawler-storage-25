"""Minimal TensorFlow (tf.keras) training with Matyan, logging maximal data types.

Same pattern as Keras: MatyanCallback logs scalars/metrics; custom callback
uses shared helpers for images, text, distributions, figures, audio,
log messages, and file artifacts.

Usage:
    pip install matyan-client[tensorflow] numpy plotly
    python examples/tensorflow_track.py

Environment variables (optional):
    MATYAN_BACKEND_URL   default http://localhost:53800
    MATYAN_FRONTIER_URL  default http://localhost:53801
"""

from __future__ import annotations

import sys
from pathlib import Path

import keras
from keras import Sequential, callbacks, layers
from typing_extensions import override

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
from _tracking_helpers import (
    track_audio_sample,
    track_file_artifact,
    track_log_messages,
    track_loss_figure,
    track_sample_distribution,
    track_sample_images,
    track_text,
)

from matyan_client.adapters.tensorflow import MatyanCallback

EPOCHS = 2
BATCH_SIZE = 128


def get_model() -> Sequential:
    model = Sequential(
        [
            layers.Input(shape=(28, 28, 1)),
            layers.Flatten(),
            layers.Dense(64, activation="relu"),
            layers.Dense(10, activation="softmax"),
        ],
    )
    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


class MaximalTrackingCallback(callbacks.Callback):
    """Calls shared tracking helpers at epoch end and train end."""

    def __init__(self, matyan_callback: MatyanCallback) -> None:
        super().__init__()
        self._matyan_callback = matyan_callback
        self._train_losses: list[float] = []
        self._val_losses: list[float] = []

    def on_epoch_end(self, epoch: int, logs: dict | None = None) -> None:
        run = self._matyan_callback.experiment
        if epoch == 0:
            track_log_messages(run)
            run["hparams.batch_size"] = BATCH_SIZE
            run["hparams.epochs"] = EPOCHS
        track_sample_images(run, step=epoch, count=2)
        track_sample_distribution(run, "weights_sample", step=epoch)
        track_text(run, "epoch_note", f"Epoch {epoch} completed.", step=epoch)
        track_audio_sample(run, "tones", step=epoch)
        if logs:
            tl = logs.get("loss")
            vl = logs.get("val_loss")
            if tl is not None:
                self._train_losses.append(float(tl))
            if vl is not None:
                self._val_losses.append(float(vl))
            if self._train_losses and self._val_losses:
                track_loss_figure(
                    run,
                    self._train_losses,
                    self._val_losses,
                    step=epoch,
                )

    @override
    def on_train_end(self, logs: dict | None = None) -> None:
        run = self._matyan_callback.experiment
        if self._train_losses and self._val_losses:
            track_loss_figure(
                run,
                self._train_losses,
                self._val_losses,
                step=EPOCHS,
            )
        track_file_artifact(run, "tensorflow_artifact.txt")
        run.log_info("TensorFlow training finished.")


def main() -> None:
    (x_train, y_train), (x_val, y_val) = keras.datasets.mnist.load_data()
    x_train = np.expand_dims(x_train.astype("float32") / 255.0, -1)
    x_val = np.expand_dims(x_val.astype("float32") / 255.0, -1)

    model = get_model()
    matyan_callback = MatyanCallback(experiment="tensorflow-maximal")
    custom_callback = MaximalTrackingCallback(matyan_callback)

    model.fit(
        x_train,
        y_train,
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        validation_data=(x_val, y_val),
        callbacks=[matyan_callback, custom_callback],
    )

    matyan_callback.close()


if __name__ == "__main__":
    main()
