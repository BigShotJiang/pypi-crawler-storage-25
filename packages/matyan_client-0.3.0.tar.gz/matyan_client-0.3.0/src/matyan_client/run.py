"""Aim-compatible Run class for experiment tracking.

This module provides the main :class:`Run` type used to create and manage
experiment runs. It preserves the original Aim SDK public API while routing
data through the matyan infrastructure: frontier WebSocket for ingestion
(metrics, params, custom objects) and backend REST for metadata (tags,
experiment, run props). Use :class:`Run` to track metrics, hyperparameters,
artifacts, and log records; use :class:`~matyan_client.repo.Repo` to query
runs and manage the repository.
"""

from __future__ import annotations

import base64
import contextlib
import inspect
import json
import tempfile
import time
import uuid
import weakref
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar

import httpx
from loguru import logger

from ._blob_uploader import BlobUploader as _BlobUploader
from ._cache import WriteCache
from ._resource_tracker import ResourceTracker as _ResourceTracker
from ._system_params import collect_system_params
from .config import SETTINGS
from .transport.http import HttpTransport
from .transport.ws import WsTransport

if TYPE_CHECKING:
    import os
    from collections.abc import Iterator

    from ._types import AimObject, Context

_global_cache = WriteCache()


class Run:
    """A single experiment run.

    Tracks metrics, hyperparameters, custom objects (images, audio, etc.),
    and log records. Data is sent to the frontier via WebSocket (ingestion)
    and to the backend via REST (metadata). Call :meth:`close` when the run
    is finished so that the run is marked finalized and the write cache is
    cleared.

    :param run_hash: Existing run hash to resume, or None to create a new run.
    :param repo: Backend URL; also used as frontier URL if frontier_url is not set.
    :param frontier_url: Frontier WebSocket URL for ingestion (metrics, params, blobs).
    :param read_only: If True, no tracking or writes; used for query-only run handles.
    :param experiment: Experiment name to associate with the run.
    :param force_resume: If True, allow resuming a run that may already exist.
    :param system_tracking_interval: Seconds between system metric samples; None to disable.
    :param log_system_params: If True, log system params (env, packages, git) at init.
    :param capture_terminal_logs: If True, capture and send stdout/stderr to the UI.

    Usage::

        run = Run(experiment="baseline")
        run["hparams"] = {"lr": 0.01, "batch_size": 32}
        for step in range(100):
            run.track(loss, name="loss", step=step, context={"subset": "train"})
        run.close()
    """

    _instances: ClassVar[list[Run]] = []

    def __init__(
        self,
        run_hash: str | None = None,
        *,
        repo: str | None = None,
        frontier_url: str | None = None,
        read_only: bool = False,
        experiment: str | None = None,
        force_resume: bool = False,
        system_tracking_interval: float | None = None,
        log_system_params: bool | None = False,
        capture_terminal_logs: bool | None = True,
    ) -> None:
        self._hash = run_hash or uuid.uuid4().hex
        self._read_only = read_only
        self._experiment: str | None = experiment
        self._name: str | None = None
        self._description: str | None = None
        self._archived = False
        self._creation_time = datetime.now(timezone.utc).timestamp()
        self._end_time: float | None = None
        self._active = True
        self._closed = False

        backend_url = repo or SETTINGS.backend_url
        frontier_url = frontier_url or repo or SETTINGS.frontier_url

        self._http = HttpTransport(backend_url)
        self._ws: WsTransport | None = None
        self._blob_uploader: _BlobUploader | None = None
        self._step_counters: dict[str, int] = {}

        if not read_only:
            self._ws = WsTransport(frontier_url, self._hash)
            self._ws.send_create_run(force_resume=force_resume)
            self._blob_uploader = _BlobUploader(self._http, frontier_url, self._hash, ws=self._ws)

            if experiment:
                self._ws.send_set_run_property(experiment=experiment)

            if log_system_params:
                self["__system_params"] = collect_system_params()

        self._resource_tracker = None
        needs_stats = not read_only and _ResourceTracker.check_interval(system_tracking_interval, warn=False)
        needs_logs = bool(capture_terminal_logs) and not read_only
        if needs_stats or needs_logs:
            self._resource_tracker = _ResourceTracker(
                track_fn=self._track_system_metric,
                interval=system_tracking_interval if needs_stats else None,
                capture_logs=needs_logs,
                send_terminal_line_fn=self._send_terminal_line if needs_logs else None,
            )
            self._resource_tracker.start()

        self._finalizer = weakref.finalize(self, self._weak_cleanup, self._hash)
        self._instances.append(self)

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    @property
    def hash(self) -> str:
        """Unique run identifier (hex string)."""
        return self._hash

    # ------------------------------------------------------------------
    # Properties (getter / setter)  # noqa: ERA001
    # ------------------------------------------------------------------

    @property
    def name(self) -> str | None:
        """Human-readable run name."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value
        _global_cache.set(self._hash, "__props__.name", value)
        if not self._read_only and self._ws:
            self._ws.send_set_run_property(name=value)

    @property
    def description(self) -> str | None:
        """Optional run description."""
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        self._description = value
        _global_cache.set(self._hash, "__props__.description", value)
        if not self._read_only and self._ws:
            self._ws.send_set_run_property(description=value)

    @property
    def archived(self) -> bool:
        """Whether the run is archived (hidden from default views)."""
        return self._archived

    @archived.setter
    def archived(self, value: bool) -> None:
        self._archived = value
        _global_cache.set(self._hash, "__props__.archived", value)
        if not self._read_only and self._ws:
            self._ws.send_set_run_property(archived=value)

    @property
    def experiment(self) -> str | None:
        """Experiment name this run belongs to."""
        return self._experiment

    @experiment.setter
    def experiment(self, value: str | None) -> None:
        self._experiment = value
        _global_cache.set(self._hash, "__props__.experiment", value)
        if not self._read_only and self._ws and value is not None:
            self._ws.send_set_run_property(experiment=value)

    @property
    def tags(self) -> list[str]:
        """Tag names attached to this run (fetched from the backend)."""
        try:
            info = self._http.get_run_info(self._hash)
            return [t.get("name", "") for t in info.get("props", {}).get("tags", [])]
        except httpx.HTTPError:
            logger.debug("Failed to fetch tags from backend", run_id=self._hash)
            return []

    @property
    def creation_time(self) -> float:
        """Unix timestamp when the run was created."""
        return self._creation_time

    @property
    def created_at(self) -> datetime:
        """Creation time as a timezone-aware datetime (UTC)."""
        return datetime.fromtimestamp(self._creation_time, tz=timezone.utc)

    @property
    def end_time(self) -> float | None:
        """Unix timestamp when the run was finalized, or None if still active."""
        return self._end_time

    @property
    def finalized_at(self) -> datetime | None:
        """Finalization time as a timezone-aware datetime (UTC), or None if still active."""
        return datetime.fromtimestamp(self._end_time, tz=timezone.utc) if self._end_time else None

    @property
    def duration(self) -> float | None:
        """Seconds between creation and finalization, or None if the run is still active."""
        if self._end_time is not None:
            return self._end_time - self._creation_time
        return None

    @property
    def active(self) -> bool:
        """True until :meth:`close` is called."""
        return self._active

    @property
    def props(self) -> dict:
        """Full run props (name, description, experiment, tags, etc.) from the backend."""
        try:
            info = self._http.get_run_info(self._hash)
            return info.get("props", {})
        except httpx.HTTPError:
            logger.debug("Failed to fetch props from backend", run_id=self._hash)
            return {}

    @property
    def artifacts(self) -> list[dict]:
        """List metadata for all artifacts attached to this run (fetched from the backend)."""
        try:
            info = self._http.get_run_info(self._hash)
            return info.get("artifacts", [])
        except httpx.HTTPError:
            logger.debug("Failed to fetch artifacts from backend", run_id=self._hash)
            return []

    # ------------------------------------------------------------------
    # Dictionary interface (__setitem__ / __getitem__)
    # ------------------------------------------------------------------

    def __setitem__(self, key: str, val: AimObject) -> None:
        """Set a run attribute (e.g. hyperparameters) by key.

        Values are cached locally and sent to the frontier. Use dotted keys
        for nested structure (e.g. ``"hparams.lr"``).

        :param key: Attribute name or dotted path (e.g. ``hparams``, ``hparams.lr``).
        :param val: Value to set (must be JSON-serializable or an Aim custom object).
        """
        _global_cache.set(self._hash, key, val)
        if not self._read_only and self._ws:
            self._ws.send_log_hparams(_nest_key(key, val))

    def __getitem__(self, key: str) -> Any:  # noqa: ANN401
        """Get a run attribute by key; checks write cache then backend.

        :param key: Attribute name or dotted path (e.g. ``hparams``, ``hparams.lr``).
        :returns: The value for that key.
        :raises KeyError: If the key is not found in cache or backend.
        """
        if _global_cache.has(self._hash, key):
            return _global_cache.get(self._hash, key)

        try:
            info = self._http.get_run_info(self._hash)
            params = info.get("params", {})
            return _resolve_dotted(params, key)
        except httpx.HTTPError:
            msg = f"Key {key!r} not found for run {self._hash}"
            raise KeyError(msg) from None

    def __delitem__(self, key: str) -> None:
        """Clear a run attribute from the local write cache (does not sync to backend)."""
        _global_cache.set(self._hash, key, None)

    def set(self, key: str, val: AimObject) -> None:
        """Alias for ``self[key] = val``; set a run attribute by key."""
        self[key] = val

    def get(self, key: str, default: Any = None) -> Any:  # noqa: ANN401
        """Get a run attribute by key, or return default if not found."""
        try:
            return self[key]
        except KeyError:
            return default

    # ------------------------------------------------------------------
    # Tracking
    # ------------------------------------------------------------------

    def track(
        self,
        value: Any,  # noqa: ANN401
        name: str | None = None,
        step: int | None = None,
        epoch: int | None = None,
        *,
        context: Context | None = None,
    ) -> None:
        """Log a scalar or custom object for the given metric name and step.

        Scalars are sent as metrics; objects with a ``json()`` method (e.g.
        :class:`~matyan_client.objects.Image`, :class:`~matyan_client.objects.Audio`)
        are serialized and uploaded (blobs go to blob storage via presigned URL). If step
        is omitted, an auto-incrementing step per (name, context) is used.

        :param value: Metric value (float) or a custom object (Image, Text, etc.).
        :param name: Metric or sequence name (required).
        :param step: Step index; if None, auto-incremented per name/context.
        :param epoch: Optional epoch index for grouping steps.
        :param context: Optional context dict to distinguish sequences (e.g. subset).
        :raises RuntimeError: If the run is read-only or WebSocket is not initialized.
        :raises ValueError: If name is not provided.
        """
        if self._read_only:
            msg = "Cannot track on a read-only run"
            raise RuntimeError(msg)

        if isinstance(value, dict) and name is None:
            for k, v in value.items():
                self.track(v, name=k, step=step, epoch=epoch, context=context)
            return

        if name is None:
            msg = "metric `name` is required"
            raise ValueError(msg)

        if self._ws is None:
            msg = "WebSocket transport not initialized"
            raise RuntimeError(msg)

        if step is None:
            ctx_key = json.dumps(context, sort_keys=True) if context else ""
            counter_key = f"{name}:{ctx_key}"
            step = self._step_counters.get(counter_key, 0)
            self._step_counters[counter_key] = step + 1

        if hasattr(value, "json") and callable(value.json):
            serialized = value.json()
            dtype = serialized.get("type", type(value).__name__)
            metadata = self._upload_blob_if_needed(serialized, name, step)
            self._ws.send_log_custom_object(
                name=name,
                value=metadata,
                step=step,
                epoch=epoch,
                context=context,
                dtype=dtype,
            )
        else:
            self._ws.send_log_metric(
                name=name,
                value=float(value),
                step=step,
                epoch=epoch,
                context=context,
                dtype=type(value).__name__,
            )

    def _upload_blob_if_needed(self, serialized: dict, name: str, step: int) -> dict:
        """Submit Image/Audio blobs to blob storage and return metadata (s3_key) for the payload.

        :param serialized: JSON-serialized custom object (may contain base64 ``data``).
        :param name: Sequence name for the artifact path.
        :param step: Step index for the artifact path.
        :returns: Same dict with ``data`` replaced by ``s3_key`` for image/audio types.
        """
        obj_type = serialized.get("type", "")
        if obj_type not in ("image", "audio") or "data" not in serialized:
            return serialized

        raw_bytes = base64.b64decode(serialized["data"])
        fmt = serialized.get("format", "bin").lower()
        content_type = _CONTENT_TYPES.get(obj_type, {}).get(fmt, "application/octet-stream")
        artifact_path = f"seq/{name}/{step}.{fmt}"

        metadata = {k: v for k, v in serialized.items() if k != "data"}
        if self._blob_uploader is not None:
            s3_key = self._blob_uploader.submit(raw_bytes, artifact_path, content_type)
        else:
            s3_key = f"{self._hash}/{artifact_path}"
        metadata["s3_key"] = s3_key
        return metadata

    # ------------------------------------------------------------------
    # Tags
    # ------------------------------------------------------------------

    def add_tag(self, value: str) -> None:
        """Attach a tag to this run (sent via WebSocket or REST).

        :param value: Tag name to add.
        """
        if self._read_only:
            return
        if self._ws:
            self._ws.send_add_tag(value)
        else:
            self._http.add_tag_to_run(self._hash, value)

    def remove_tag(self, tag_name: str) -> None:
        """Remove a tag from this run by name (sent via WebSocket or REST).

        :param tag_name: Tag name to remove.
        """
        if self._read_only:
            return
        if self._ws:
            self._ws.send_remove_tag(tag_name)
        else:
            try:
                info = self._http.get_run_info(self._hash)
                tags = info.get("props", {}).get("tags", [])
                for t in tags:
                    if t.get("name") == tag_name:
                        self._http.remove_tag_from_run(self._hash, t["id"])
                        return
            except httpx.HTTPError:
                logger.warning("Failed to remove tag from run", tag=tag_name, run_id=self._hash)

    # ------------------------------------------------------------------
    # Logging (structured log records)
    # ------------------------------------------------------------------

    def _log_message(self, level: int, msg: str, **params: Any) -> None:  # noqa: ANN401
        """Send a structured log record to the frontier (used by log_info/log_warning/etc.)."""
        if self._read_only or self._ws is None:
            return

        frame = inspect.currentframe()
        logger_info: list | None = None
        if frame and frame.f_back and frame.f_back.f_back:
            caller = frame.f_back.f_back
            logger_info = [caller.f_code.co_filename, caller.f_lineno]

        self._ws.send_log_record(
            message=msg,
            level=level,
            timestamp=time.time(),
            logger_info=logger_info,
            extra_args=params or None,
        )

    def log_info(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        """Log an info-level message and optional structured fields for this run."""
        self._log_message(20, msg, **kwargs)

    def log_warning(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        """Log a warning-level message and optional structured fields for this run."""
        self._log_message(30, msg, **kwargs)

    def log_error(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        """Log an error-level message and optional structured fields for this run."""
        self._log_message(40, msg, **kwargs)

    def log_debug(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        """Log a debug-level message and optional structured fields for this run."""
        self._log_message(10, msg, **kwargs)

    # ------------------------------------------------------------------
    # Artifacts
    # ------------------------------------------------------------------

    def log_artifact(self, path: str, name: str | None = None) -> None:
        """Upload a single artifact file via presigned blob upload URL (non-blocking).

        Requires an active WebSocket connection to the frontier; blob notification
        is sent via WebSocket after upload. Open this run with read_only=False
        and a frontier URL to upload artifacts.

        :param path: Local file path to upload.
        :param name: Optional artifact name/path in the run; defaults to the filename.
        :raises RuntimeError: If the run has no WebSocket (e.g. read_only or no frontier).
        """
        if self._blob_uploader is None:
            msg = (
                "Artifact upload requires an active WebSocket connection to the frontier; "
                "blob notification is sent via WebSocket. Open this run with read_only=False "
                "and a frontier URL to upload artifacts."
            )
            raise RuntimeError(msg)
        artifact_path = name or Path(path).name
        data = Path(path).read_bytes()
        self._blob_uploader.submit(data, artifact_path, "application/octet-stream")

    def log_artifacts(self, path: str, name: str | None = None) -> None:
        """Upload all files under a directory as artifacts (recursive).

        :param path: Local directory path to upload.
        :param name: Optional prefix for artifact names; each file path is relative to the directory.
        """
        base = Path(path)
        for f in base.rglob("*"):
            if f.is_file():
                rel = str(f.relative_to(base))
                prefix = f"{name}/{rel}" if name else rel
                self.log_artifact(str(f), name=prefix)

    def get_artifact(self, name: str) -> bytes:
        return self._http.get_artifact(self._hash, name)

    def download_artifact(self, name: str, dest: str | os.PathLike) -> None:
        """Download a single artifact to the local filesystem.

        :param name: Artifact path/name in the run.
        :param dest: Local file path where it should be saved.
        """
        self._http.download_artifact(self._hash, name, dest)

    def download_artifacts(self, dest_dir: str | os.PathLike) -> list[Path]:
        """Download all artifacts into a directory (unpacks the ZIP from backend)."""
        dest = Path(dest_dir)
        dest.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp_path = tmp.name
        self._http.download_all_artifacts(self._hash, tmp_path)
        try:
            with zipfile.ZipFile(tmp_path, "r") as zf:
                zf.extractall(path=dest)
                return [dest / name for name in zf.namelist()]
        finally:
            Path(tmp_path).unlink()

    # ------------------------------------------------------------------
    # Sequences / metrics (read)  # noqa: ERA001
    # ------------------------------------------------------------------

    def metrics(self) -> list[dict]:
        """Return an overview of all tracked metrics for this run.

        :returns: List of trace info dicts (name, context, etc.) for metric sequences.
        """
        try:
            info = self._http.get_run_info(self._hash)
            return info.get("traces", {}).get("metric", [])
        except httpx.HTTPError:
            logger.debug("Failed to fetch metrics from backend", run_id=self._hash)
            return []

    def get_metric(self, name: str, context: Context | None = None) -> dict | None:
        """Return trace info for a single metric by name and optional context.

        :param name: Metric sequence name.
        :param context: Optional context dict to match (e.g. subset).
        :returns: Trace info dict if found, else None.
        """
        for m in self.metrics():
            if m.get("name") == name and m.get("context", {}) == (context or {}):
                return m
        return None

    def iter_metrics_info(self) -> Iterator[tuple[str, dict, Run]]:
        """Yield (metric name, context dict, self) for each metric trace.

        :returns: Iterator of (name, context, run) tuples.
        """
        for m in self.metrics():
            yield m.get("name", ""), m.get("context", {}), self

    def collect_sequence_info(
        self,
        sequence_types: str | tuple[str, ...] = (),
    ) -> dict[str, list]:
        """Fetch trace overview for the given sequence types from the backend.

        :param sequence_types: Single type or tuple (e.g. ``"metric"``, ``("metric", "images")``); empty means all.
        :returns: Dict mapping bucket name to list of trace info dicts (e.g. ``{"metric": [...]}``).
        """
        seq = (sequence_types,) if isinstance(sequence_types, str) else tuple(sequence_types)
        try:
            info = self._http.get_run_info(self._hash, sequence=seq)
            return info.get("traces", {})
        except httpx.HTTPError:
            logger.debug("Failed to fetch sequence info from backend", run_id=self._hash)
            return {}

    # ------------------------------------------------------------------
    # Internal helpers for ResourceTracker callbacks
    # ------------------------------------------------------------------

    def _track_system_metric(self, value: float, name: str, context: dict | None = None) -> None:
        """Track a single system-resource metric (callback for ResourceTracker)."""
        if self._read_only or self._ws is None:
            return
        self.track(value, name=name, context=context)

    def _send_terminal_line(self, line: str, step: int) -> None:
        """Send a captured terminal line to the frontier (callback for ResourceTracker)."""
        if self._read_only or self._ws is None:
            return
        self._ws.send_log_terminal_line(line, step)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Finalize the run, flush pending data, and release resources.

        Marks the run as inactive, sends finish to the frontier, stops the
        resource tracker and blob uploader, and clears the write cache. Safe
        to call multiple times; subsequent calls are no-ops.
        """
        if self._closed:
            return
        self._closed = True
        self._active = False
        self._end_time = datetime.now(timezone.utc).timestamp()

        if self._resource_tracker is not None:
            self._resource_tracker.stop()
            self._resource_tracker = None

        if self._blob_uploader is not None:
            self._blob_uploader.shutdown()
            self._blob_uploader = None

        if self._ws:
            self._ws.send_finish_run()
            self._ws.close()
            self._ws = None

        self._http.close()
        self._finalizer.detach()  # prevent double-clear if GC fires after close()
        _global_cache.clear(self._hash)

        with contextlib.suppress(ValueError):
            self._instances.remove(self)

    @staticmethod
    def _weak_cleanup(run_hash: str) -> None:
        """Clear write cache for a run when the Run instance is garbage-collected."""
        logger.debug("GC cleanup for run {}", run_hash)
        _global_cache.clear(run_hash)

    def __repr__(self) -> str:
        """Return a short string representation of the run (hash and experiment)."""
        return f"Run(hash={self._hash!r}, experiment={self._experiment!r})"

    def __del__(self) -> None:
        """On GC, close the run if it was not closed explicitly."""
        if not self._closed:
            with contextlib.suppress(Exception):
                self.close()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


_CONTENT_TYPES: dict[str, dict[str, str]] = {
    "image": {
        "png": "image/png",
        "jpeg": "image/jpeg",
        "jpg": "image/jpeg",
        "gif": "image/gif",
        "bmp": "image/bmp",
        "webp": "image/webp",
    },
    "audio": {
        "wav": "audio/wav",
        "mp3": "audio/mpeg",
        "flac": "audio/flac",
        "ogg": "audio/ogg",
    },
}


def _nest_key(key: str, val: Any) -> dict:  # noqa: ANN401
    """Build a nested dict from a dotted key and value.

    :param key: Dotted path (e.g. ``hparams.lr``).
    :param val: Value to place at the leaf.
    :returns: Nested dict (e.g. ``{"hparams": {"lr": 0.01}}``).
    """
    parts = key.split(".")
    result = val
    for part in reversed(parts):
        result = {part: result}
    return result


def _resolve_dotted(d: dict, key: str) -> Any:  # noqa: ANN401
    """Resolve a dotted key from a nested dict.

    :param d: Nested dictionary.
    :param key: Dotted path (e.g. ``hparams.lr``).
    :returns: Value at the path.
    :raises KeyError: If any segment of the path is missing.
    """
    parts = key.split(".")
    current = d
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            msg = f"Key {key!r} not found"
            raise KeyError(msg)
    return current
