"""Fast.ai callback that logs training metrics and config to Matyan."""

from __future__ import annotations

import json
from typing import Any

from loguru import logger

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL


def _json_safe(value: Any) -> Any:  # noqa: ANN401
    """Return a JSON-serializable version for WebSocket payloads."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    try:
        json.dumps(value)
    except (TypeError, ValueError):
        return str(value)
    else:
        return value


try:
    from fastai.callback.hook import total_params
    from fastai.learner import Callback
    from fastcore.basics import detuplify, ignore_exceptions, store_attr
except ImportError as _exc:
    msg = "This adapter requires fastai. Install with: pip install fastai"
    raise RuntimeError(msg) from _exc


class MatyanCallback(Callback):
    def __init__(
        self,
        repo: str | None = None,
        experiment_name: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        store_attr()
        self.repo = repo
        self.experiment_name = experiment_name
        self.system_tracking_interval = system_tracking_interval
        self.log_system_params = log_system_params
        self.capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        assert self._run is not None  # setup() always sets _run
        return self._run

    def setup(self, args: dict[str, Any] | None = None) -> None:
        if not self._run:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self.repo,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self.repo,
                    experiment=self.experiment_name,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
                self._run_hash = self._run.hash

        if args:
            try:
                for key, value in args.items():
                    self._run[key] = _json_safe(value)
            except Exception:  # noqa: BLE001
                logger.opt(exception=True).warning("Could not log config parameters")

    def before_fit(self) -> None:
        if not self._run:
            configs = self._gather_args()
            formatted = self._format_config(configs)
            self.setup(formatted)

    def after_batch(self) -> None:
        context = {"subset": "train"} if self.training else {"subset": "val"}
        run = self.experiment
        run.track(self.loss.item(), name="train_loss", step=self.train_iter, context=context)
        for i, h in enumerate(self.opt.hypers):
            for k, v in h.items():
                run.track(v, f"{k}_{i}", step=self.train_iter, context=context)

    def before_epoch(self) -> None:
        for metric in self.metrics:
            metric.reset()

    def after_epoch(self) -> None:
        run = self.experiment
        names = getattr(self.recorder, "metric_names", []) or []
        log = getattr(self.recorder, "log", []) or []
        for name, value in zip(names, log, strict=False):
            if name not in ("train_loss", "epoch", "time") and value is not None:
                run.track(value, name=name)

    def __del__(self) -> None:
        if self._run is not None:
            self._run.close()

    # ------------------------------------------------------------------
    # Config gathering helpers
    # ------------------------------------------------------------------

    def _gather_args(self) -> dict[str, Any]:
        cb_args = {f"{cb}": getattr(cb, "__stored_args__", True) for cb in self.cbs if cb != self}
        args: dict[str, Any] = {"Learner": self.learn, **cb_args}

        try:
            n_inp = self.dls.train.n_inp
            args["n_inp"] = n_inp
            xb = self.dls.valid.one_batch()[:n_inp]
            args.update(
                {
                    f"input {n + 1} dim {i + 1}": d
                    for n in range(n_inp)
                    for i, d in enumerate(list(detuplify(xb[n]).shape))
                },
            )
        except Exception:  # noqa: BLE001
            logger.warning("Failed to gather input dimensions")

        with ignore_exceptions():
            args["batch_size"] = self.dls.bs
            args["batch_per_epoch"] = len(self.dls.train)
            args["model_parameters"] = total_params(self.model)[0]
            args["device"] = self.dls.device.type
            args["frozen"] = bool(self.opt.frozen_idx)
            args["frozen_idx"] = self.opt.frozen_idx
            args["dataset", "tfms"] = f"{self.dls.dataset.tfms}"
            args["dls", "after_item"] = f"{self.dls.after_item}"
            args["dls", "before_batch"] = f"{self.dls.before_batch}"
            args["dls", "after_batch"] = f"{self.dls.after_batch}"
        return args

    @classmethod
    def _format_config(cls, config: dict[str, Any]) -> dict[str, Any]:
        for key, value in config.items():
            if isinstance(value, dict):
                config[key] = cls._format_config(value)
            else:
                config[key] = cls._format_config_value(value)
        return config

    @classmethod
    def _format_config_value(cls, value: Any) -> Any:  # noqa: ANN401
        if isinstance(value, list):
            return [cls._format_config_value(item) for item in value]
        if hasattr(value, "__stored_args__"):
            return {**cls._format_config(value.__stored_args__), "_name": value}
        return value
