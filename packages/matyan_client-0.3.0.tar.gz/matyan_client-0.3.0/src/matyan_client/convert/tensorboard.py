"""Convert TensorBoard event logs to a Matyan-compatible backup archive."""

from __future__ import annotations

import ast
import hashlib
import io
import json
import os
import re
import shutil
import struct
import tarfile
import uuid
import wave
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, NamedTuple

import click
import numpy as np
import pandas as pd
from matyan_api_models.backup import BackupManifest
from PIL import Image
from tbparse import SummaryReader
from tqdm import tqdm


class _RunResult(NamedTuple):
    dir_name: str
    run_hash: str
    blob_count: int
    blob_bytes: int
    record_count: int
    trace_count: int


def convert_tensorboard(
    input_dir: str,
    output_path: str,
    *,
    experiment: str | None = None,
    compress: bool = False,
    workers: int | None = None,
) -> Path:
    """Read TensorBoard logs from *input_dir* and produce a Matyan backup archive."""
    click.echo("Discovering TensorBoard runs...")
    run_dirs = _discover_run_dirs(Path(input_dir))

    if not run_dirs:
        click.echo("No TensorBoard runs found in the input directory.")
        return Path(output_path)

    has_tf = _has_tensorflow()
    if not has_tf:
        click.echo(
            "WARNING: TensorFlow not installed. Image and audio events will be skipped. "
            "Install with: uv sync --extra convert",
        )

    max_workers = min(workers or os.cpu_count() or 1, len(run_dirs))
    click.echo(f"Found {len(run_dirs)} run(s), using {max_workers} worker(s)")

    timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d-%H%M%S")
    backup_dir = Path(output_path) / f"matyan-tb-import-{timestamp}"
    backup_dir.mkdir(parents=True, exist_ok=True)
    (backup_dir / "runs").mkdir(exist_ok=True)

    exp_id = None
    if experiment:
        exp_id = _write_experiment_entity(backup_dir, experiment)

    input_path = Path(input_dir)
    jobs: list[tuple[Path, str, str]] = []
    for run_path in run_dirs:
        dir_name = run_path.relative_to(input_path).as_posix()
        if dir_name == ".":
            dir_name = run_path.name or "."
        run_hash = _dir_name_to_hash(dir_name)
        jobs.append((run_path, dir_name, run_hash))

    results: list[_RunResult] = []

    if max_workers == 1:
        for run_path, dir_name, run_hash in tqdm(jobs, desc="runs", unit="run"):
            r = _convert_run_worker(run_path, dir_name, run_hash, backup_dir, exp_id, has_tf)
            tqdm.write(f"  {r.dir_name} -> {r.run_hash} ({r.record_count} records, {r.trace_count} traces)")
            results.append(r)
    else:
        with ProcessPoolExecutor(max_workers=max_workers) as pool:
            future_to_hash = {
                pool.submit(_convert_run_worker, rp, dn, rh, backup_dir, exp_id, has_tf): rh for rp, dn, rh in jobs
            }
            with tqdm(total=len(jobs), desc="runs", unit="run") as pbar:
                for fut in as_completed(future_to_hash):
                    r = fut.result()
                    tqdm.write(
                        f"  {r.dir_name} -> {r.run_hash} ({r.record_count} records, {r.trace_count} traces)",
                    )
                    results.append(r)
                    pbar.update(1)

    run_hashes = [r.run_hash for r in results]
    total_blob_count = sum(r.blob_count for r in results)
    total_blob_bytes = sum(r.blob_bytes for r in results)

    manifest = BackupManifest(
        created_at=datetime.now(tz=timezone.utc).isoformat(),
        run_count=len(run_hashes),
        run_hashes=run_hashes,
        entity_counts={"experiment": 1} if experiment else {},
        blob_count=total_blob_count,
        blob_bytes=total_blob_bytes,
        filters={"source": "tensorboard", "input_dir": input_dir},
        include_blobs=total_blob_count > 0,
    )
    manifest.write(backup_dir)

    click.echo(
        f"\nConversion complete: {len(run_hashes)} run(s), {total_blob_count} blob(s) ({total_blob_bytes:,} bytes)",
    )

    return _finalise(backup_dir, compress)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_EMPTY_CTX_ID = 0

_EXTRA_COLUMNS = {"dir_name", "wall_time", "width", "height", "sample_rate"}


def _discover_run_dirs(input_dir: Path) -> list[Path]:
    """Find directories containing ``events.out.tfevents.*`` files.

    Returns a sorted list of unique parent directories.  This is a fast
    filesystem-only walk — no event file parsing.
    """
    event_files = list(input_dir.rglob("events.out.tfevents.*"))
    if not event_files:
        return []
    return sorted({f.parent for f in event_files})


def _has_tensorflow() -> bool:
    try:
        import tensorflow as tf  # noqa: F401, PLC0415  # ty:ignore[unresolved-import]
    except Exception:  # noqa: BLE001
        return False
    return True


def _convert_run_worker(
    run_path: Path,
    dir_name: str,
    run_hash: str,
    backup_dir: Path,
    exp_id: str | None,
    has_tf: bool,
) -> _RunResult:
    """Top-level entry point for each worker process."""
    extra = _EXTRA_COLUMNS.copy()
    event_types: set[str] | None = None
    if not has_tf:
        event_types = {"scalars", "tensors", "hparams", "text", "histograms"}
        extra -= {"width", "height", "sample_rate"}

    reader = SummaryReader(str(run_path), extra_columns=extra, event_types=event_types)

    scalars_df = _safe_read(reader, "scalars")
    tensors_df = _safe_read(reader, "tensors")
    hparams_df = _safe_read(reader, "hparams")
    text_df = _safe_read(reader, "text")
    histograms_df = _safe_read(reader, "histograms")
    images_df = _safe_read(reader, "images") if has_tf else pd.DataFrame()
    audio_df = _safe_read(reader, "audio") if has_tf else pd.DataFrame()

    run_dir = backup_dir / "runs" / run_hash
    run_dir.mkdir(parents=True, exist_ok=True)
    blobs_dir = run_dir / "blobs"

    records: list[dict] = []
    traces: list[dict] = []
    wall_times: list[float] = []

    _process_scalars(scalars_df, records, traces, wall_times)
    _process_scalars(tensors_df, records, traces, wall_times)
    _process_text(text_df, records, traces, wall_times)
    _process_histograms(histograms_df, records, traces, wall_times)

    img_blobs, img_bytes = _process_images(images_df, run_hash, blobs_dir, records, traces, wall_times)
    aud_blobs, aud_bytes = _process_audio(audio_df, run_hash, blobs_dir, records, traces, wall_times)

    hparams = _extract_hparams(hparams_df)

    first_ts, last_ts = _time_bounds(wall_times)
    meta = _build_run_meta(dir_name, first_ts, last_ts, experiment_id=exp_id)
    attrs: dict[str, Any] = {}
    if hparams:
        attrs["hparams"] = hparams

    _write_run_files(run_dir, meta, attrs, traces, records)

    return _RunResult(
        dir_name=dir_name,
        run_hash=run_hash,
        blob_count=img_blobs + aud_blobs,
        blob_bytes=img_bytes + aud_bytes,
        record_count=len(records),
        trace_count=len(traces),
    )


def _safe_read(reader: Any, attr: str) -> pd.DataFrame:  # noqa: ANN401
    """Read a DataFrame property from SummaryReader, returning empty on error."""
    try:
        df = getattr(reader, attr)
    except Exception:  # noqa: BLE001
        return pd.DataFrame()
    else:
        return df if df is not None else pd.DataFrame()


def _dir_name_to_hash(dir_name: str) -> str:
    return hashlib.sha256(dir_name.encode()).hexdigest()[:16]


def _sanitize_tag(tag: str) -> str:
    """Make a TensorBoard tag safe for use as a filesystem path component."""
    return re.sub(r"[^\w.\-]", "_", tag)


def _time_bounds(wall_times: list[float]) -> tuple[float, float]:
    if not wall_times:
        now = datetime.now(tz=timezone.utc).timestamp()
        return now, now
    return min(wall_times), max(wall_times)


def _build_run_meta(
    dir_name: str,
    first_ts: float,
    last_ts: float,
    *,
    experiment_id: str | None = None,
) -> dict:
    return {
        "name": dir_name,
        "description": "Imported from TensorBoard",
        "created_at": first_ts,
        "updated_at": last_ts,
        "finalized_at": last_ts,
        "is_archived": False,
        "active": False,
        "experiment_id": experiment_id,
        "client_start_ts": first_ts,
        "duration": max(0.0, last_ts - first_ts),
    }


def _add_trace(traces: list[dict], name: str, dtype: str, last: Any, last_step: int | None) -> None:  # noqa: ANN401
    """Append a trace entry if one with the same (name, dtype) doesn't already exist."""
    for t in traces:
        if t["name"] == name and t["dtype"] == dtype:
            if last_step is not None and (t["last_step"] is None or last_step > t["last_step"]):
                t["last"] = last
                t["last_step"] = last_step
            return
    traces.append(
        {
            "name": name,
            "context_id": _EMPTY_CTX_ID,
            "dtype": dtype,
            "last": last,
            "last_step": last_step,
        },
    )


# ---------------------------------------------------------------------------
# Per-type converters
# ---------------------------------------------------------------------------


def _process_scalars(
    df: pd.DataFrame,
    records: list[dict],
    traces: list[dict],
    wall_times: list[float],
) -> None:
    if df.empty:
        return
    for _, row in df.iterrows():
        tag = row["tag"]
        step = int(row["step"])
        value = float(row["value"])
        rec: dict[str, Any] = {"ctx_id": _EMPTY_CTX_ID, "name": tag, "step": step, "value": value}
        if "wall_time" in df.columns and pd.notna(row.get("wall_time")):
            wt = float(row["wall_time"])
            rec["time"] = wt
            wall_times.append(wt)
        records.append(rec)
        _add_trace(traces, tag, "float", value, step)


def _process_text(
    df: pd.DataFrame,
    records: list[dict],
    traces: list[dict],
    wall_times: list[float],
) -> None:
    if df.empty:
        return
    for _, row in df.iterrows():
        tag = row["tag"]
        step = int(row["step"])
        value = {"type": "text", "data": str(row["value"])}
        rec: dict[str, Any] = {"ctx_id": _EMPTY_CTX_ID, "name": tag, "step": step, "value": value}
        if "wall_time" in df.columns and pd.notna(row.get("wall_time")):
            wt = float(row["wall_time"])
            rec["time"] = wt
            wall_times.append(wt)
        records.append(rec)
        _add_trace(traces, tag, "text", None, step)


def _process_histograms(
    df: pd.DataFrame,
    records: list[dict],
    traces: list[dict],
    wall_times: list[float],
) -> None:
    if df.empty:
        return
    for _, row in df.iterrows():
        tag = row["tag"]
        step = int(row["step"])
        counts = np.asarray(row["counts"], dtype=np.float64)
        limits = np.asarray(row["limits"], dtype=np.float64)

        bin_count = len(counts)
        lo = float(limits[0]) if len(limits) > 0 else 0.0
        hi = float(limits[-1]) if len(limits) > 0 else 0.0
        blob = struct.pack(f"<{bin_count}d", *counts.tolist())

        value: dict[str, Any] = {
            "type": "distribution",
            "bin_count": bin_count,
            "range": [lo, hi],
            "dtype": "float64",
            "data": blob,
        }
        rec: dict[str, Any] = {"ctx_id": _EMPTY_CTX_ID, "name": tag, "step": step, "value": value}
        if "wall_time" in df.columns and pd.notna(row.get("wall_time")):
            wt = float(row["wall_time"])
            rec["time"] = wt
            wall_times.append(wt)
        records.append(rec)
        _add_trace(traces, tag, "distribution", None, step)


def _process_images(
    df: pd.DataFrame,
    run_hash: str,
    blobs_dir: Path,
    records: list[dict],
    traces: list[dict],
    wall_times: list[float],
) -> tuple[int, int]:
    """Convert image events to PNG blobs and sequence records."""
    if df.empty:
        return 0, 0

    blob_count = 0
    blob_bytes = 0

    for _, row in df.iterrows():
        tag = row["tag"]
        step = int(row["step"])
        safe_tag = _sanitize_tag(tag)
        img_arr = row["value"]

        buf = io.BytesIO()
        img = Image.fromarray(np.asarray(img_arr, dtype=np.uint8))
        img.save(buf, format="PNG")
        png_bytes = buf.getvalue()

        w, h = img.size
        s3_key = f"{run_hash}/seq/{safe_tag}/{step}.png"
        blob_path = blobs_dir / "seq" / safe_tag / f"{step}.png"
        blob_path.parent.mkdir(parents=True, exist_ok=True)
        blob_path.write_bytes(png_bytes)
        blob_count += 1
        blob_bytes += len(png_bytes)

        value: dict[str, Any] = {
            "type": "image",
            "format": "png",
            "width": w,
            "height": h,
            "caption": f"{tag} step {step}",
            "s3_key": s3_key,
        }
        rec: dict[str, Any] = {"ctx_id": _EMPTY_CTX_ID, "name": safe_tag, "step": step, "value": value}
        if "wall_time" in df.columns and pd.notna(row.get("wall_time")):
            wt = float(row["wall_time"])
            rec["time"] = wt
            wall_times.append(wt)
        records.append(rec)
        _add_trace(traces, safe_tag, "image", None, step)

    return blob_count, blob_bytes


def _process_audio(
    df: pd.DataFrame,
    run_hash: str,
    blobs_dir: Path,
    records: list[dict],
    traces: list[dict],
    wall_times: list[float],
) -> tuple[int, int]:
    """Convert audio events to WAV blobs and sequence records."""
    if df.empty:
        return 0, 0

    blob_count = 0
    blob_bytes = 0

    for _, row in df.iterrows():
        tag = row["tag"]
        step = int(row["step"])
        safe_tag = _sanitize_tag(tag)
        waveform = np.asarray(row["value"])

        sample_rate = 22050
        if "sample_rate" in df.columns and pd.notna(row.get("sample_rate")):
            sample_rate = int(row["sample_rate"])

        wav_bytes = _encode_wav(waveform, sample_rate)

        s3_key = f"{run_hash}/seq/{safe_tag}/{step}.wav"
        blob_path = blobs_dir / "seq" / safe_tag / f"{step}.wav"
        blob_path.parent.mkdir(parents=True, exist_ok=True)
        blob_path.write_bytes(wav_bytes)
        blob_count += 1
        blob_bytes += len(wav_bytes)

        value: dict[str, Any] = {
            "type": "audio",
            "format": "wav",
            "caption": f"{tag} step {step}",
            "s3_key": s3_key,
        }
        rec: dict[str, Any] = {"ctx_id": _EMPTY_CTX_ID, "name": safe_tag, "step": step, "value": value}
        if "wall_time" in df.columns and pd.notna(row.get("wall_time")):
            wt = float(row["wall_time"])
            rec["time"] = wt
            wall_times.append(wt)
        records.append(rec)
        _add_trace(traces, safe_tag, "audio", None, step)

    return blob_count, blob_bytes


def _encode_wav(waveform: np.ndarray, sample_rate: int) -> bytes:
    """Encode a numpy waveform array to WAV (16-bit PCM) bytes."""
    if waveform.ndim > 1:
        waveform = waveform.flatten()

    peak = np.max(np.abs(waveform)) if waveform.size > 0 else 1.0
    normalised = waveform / peak if peak > 0 else waveform
    int16_data = (normalised * 32767).astype(np.int16)

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(int16_data.tobytes())
    return buf.getvalue()


# ---------------------------------------------------------------------------
# HParams extraction
# ---------------------------------------------------------------------------


def _extract_hparams(df: pd.DataFrame) -> dict[str, Any]:
    if df.empty:
        return {}
    flat: dict[str, Any] = {}
    if "tag" in df.columns and "value" in df.columns:
        for _, row in df.iterrows():
            key = str(row["tag"])
            val = row["value"]
            if isinstance(val, float) and pd.isna(val):
                continue
            flat[key] = _coerce_hparam(val)
    return _unflatten_slash_keys(flat)


def _unflatten_slash_keys(flat: dict[str, Any]) -> dict[str, Any]:
    """Convert ``{"a/b/c": 1, "a/b/d": 2}`` into ``{"a": {"b": {"c": 1, "d": 2}}}``.

    Keys without slashes are kept as-is.  When a prefix conflicts (one tag
    treats a path segment as a leaf while another treats it as an inner node),
    the leaf value is stored under a ``""`` key inside the dict.
    """
    root: dict[str, Any] = {}
    for key, val in flat.items():
        parts = key.split("/") if "/" in key else [key]
        node = root
        for segment in parts[:-1]:
            child = node.get(segment)
            if child is None:
                child = {}
                node[segment] = child
            elif not isinstance(child, dict):
                child = {"": child}
                node[segment] = child
            node = child
        last = parts[-1]
        existing = node.get(last)
        if isinstance(existing, dict):
            existing[""] = val
        else:
            node[last] = val
    return root


def _coerce_hparam(val: Any) -> Any:  # noqa: ANN401
    """Coerce hparam values to JSON-serialisable types.

    Strings that look like Python literals (lists, dicts, tuples) are parsed
    back into native objects so the UI can display them structurally.
    """
    if isinstance(val, (bool, int, list, dict, tuple)):
        return val
    if isinstance(val, str):
        return _try_parse_literal(val)
    if isinstance(val, float):
        return None if pd.isna(val) else val
    if isinstance(val, np.integer):
        return int(val)
    if isinstance(val, np.floating):
        return float(val)
    return str(val)


def _try_parse_literal(val: str) -> Any:  # noqa: ANN401
    """Try to recover a Python literal (list, dict, tuple) from a string.

    Frameworks often serialize structured hparam values via ``str()`` before
    logging to TensorBoard (which only supports scalar types).  This function
    reverses that by trying ``ast.literal_eval`` first (handles Python reprs
    like ``[16, 'M', 32]``, ``None``, ``True``), then ``json.loads`` as
    fallback (handles strict JSON).  Returns the original string on failure.
    """
    stripped = val.strip()
    if not stripped or stripped[0] not in ("[", "{", "("):
        return val
    try:
        parsed = ast.literal_eval(stripped)
    except (ValueError, SyntaxError):
        pass
    else:
        if isinstance(parsed, (list, dict, tuple)):
            return parsed
        return val
    try:
        parsed = json.loads(stripped)
    except (json.JSONDecodeError, ValueError):
        return val
    else:
        if isinstance(parsed, (list, dict)):
            return parsed
        return val


# ---------------------------------------------------------------------------
# File writers
# ---------------------------------------------------------------------------


def _json_default(obj: object) -> str:
    if isinstance(obj, bytes):
        return obj.hex()
    if isinstance(obj, datetime):
        return obj.isoformat()
    msg = f"Object of type {type(obj).__name__} is not JSON serializable"
    raise TypeError(msg)


def _write_run_files(
    run_dir: Path,
    meta: dict,
    attrs: dict,
    traces: list[dict],
    records: list[dict],
) -> None:
    (run_dir / "run.json").write_text(
        json.dumps(meta, default=_json_default, ensure_ascii=False) + "\n",
    )
    (run_dir / "attrs.json").write_text(
        json.dumps(attrs, default=_json_default, ensure_ascii=False) + "\n",
    )
    (run_dir / "traces.json").write_text(
        json.dumps(traces, default=_json_default, ensure_ascii=False) + "\n",
    )
    (run_dir / "contexts.json").write_text(
        json.dumps({str(_EMPTY_CTX_ID): {}}, ensure_ascii=False) + "\n",
    )
    with (run_dir / "sequences.jsonl").open("w") as f:
        for rec in records:
            f.write(json.dumps(rec, default=_json_default, ensure_ascii=False) + "\n")


def _write_experiment_entity(backup_dir: Path, experiment_name: str) -> str:
    exp_id = uuid.uuid4().hex[:8]
    entities_path = backup_dir / "entities.jsonl"
    record = {
        "entity_type": "experiment",
        "data": {
            "id": exp_id,
            "name": experiment_name,
            "description": "Imported from TensorBoard",
            "is_archived": False,
            "created_at": datetime.now(tz=timezone.utc).timestamp(),
            "updated_at": datetime.now(tz=timezone.utc).timestamp(),
        },
    }
    with entities_path.open("w") as f:
        f.write(json.dumps(record, default=_json_default, ensure_ascii=False) + "\n")
    return exp_id


def _finalise(backup_dir: Path, compress: bool) -> Path:
    if not compress:
        click.echo(f"Backup directory: {backup_dir}")
        return backup_dir

    archive_path = backup_dir.with_suffix(".tar.gz")
    click.echo(f"Compressing to {archive_path}...")
    with tarfile.open(archive_path, "w:gz") as tar:
        tar.add(backup_dir, arcname=backup_dir.name)
    shutil.rmtree(backup_dir)
    click.echo(f"Archive: {archive_path}")
    return archive_path
