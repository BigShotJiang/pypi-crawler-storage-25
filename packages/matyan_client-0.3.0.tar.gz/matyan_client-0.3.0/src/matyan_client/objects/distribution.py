"""Distribution custom object for tracking histograms with :meth:`Run.track`."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from collections.abc import Sequence

_MAX_BIN_COUNT = 512


class Distribution:
    """A tracked distribution (histogram) value for use with :meth:`Run.track`.

    Can be created from raw samples (binned automatically) or from a
    pre-computed histogram with a bin range. Use :meth:`from_histogram` or
    :meth:`from_samples` for explicit factory methods.

    :param samples: Raw sample values to bin into a histogram; omit if using hist/bin_range.
    :param bin_count: Number of bins when building from samples (capped at 512).
    :param hist: Pre-computed bin counts (use with bin_range).
    :param bin_range: (low, high) range for the histogram (use with hist).
    :raises ValueError: If neither (samples) nor (hist and bin_range) are provided.

    Usage::

        run.track(Distribution(samples), name="weights", step=0)
        run.track(Distribution.from_histogram(hist, bin_range), name="grads")
    """

    _weights: list[float | int]
    _bin_count: int
    _range: tuple[float, float]

    def __init__(
        self,
        samples: Sequence[float | int] | None = None,
        bin_count: int = 64,
        *,
        hist: Sequence[float | int] | None = None,
        bin_range: tuple[float, float] | None = None,
    ) -> None:

        if hist is not None and bin_range is not None:
            self._weights = _to_list(hist)
            self._bin_count = len(self._weights)
            self._range = tuple(bin_range)
        elif samples is not None:
            self._from_samples(samples, min(bin_count, _MAX_BIN_COUNT))
        else:
            msg = "Provide either `samples` or both `hist` and `bin_range`"
            raise ValueError(msg)

    def _from_samples(self, samples: Sequence[float | int], bin_count: int) -> None:
        """Compute histogram from sample values (numpy if available, else pure Python)."""
        try:
            import numpy as np  # noqa: PLC0415
        except ImportError:
            flat = list(samples)
            lo, hi = min(flat), max(flat)
            self._range = (float(lo), float(hi))
            self._bin_count = bin_count
            width = (hi - lo) / bin_count if hi != lo else 1.0
            counts: list[float | int] = cast("list[float | int]", [0] * bin_count)
            for v in flat:
                idx = min(int((v - lo) / width), bin_count - 1)
                counts[idx] += 1
            self._weights = counts
            return

        arr = np.asarray(samples).ravel()
        hist, edges = np.histogram(arr, bins=bin_count)
        self._weights = _to_list(hist)
        self._range = (float(edges[0]), float(edges[-1]))
        self._bin_count = bin_count

    @classmethod
    def from_histogram(cls, hist: Sequence[float | int], bin_range: tuple[float, float]) -> Distribution:
        """Build a distribution from pre-computed bin counts and range.

        :param hist: Sequence of bin counts (or weights).
        :param bin_range: (low, high) range of the histogram.
        """
        return cls(hist=hist, bin_range=bin_range)

    @classmethod
    def from_samples(cls, samples: Sequence[float | int], bin_count: int = 64) -> Distribution:
        """Build a distribution by binning raw samples.

        :param samples: Raw sample values.
        :param bin_count: Number of bins (capped at 512).
        """
        return cls(samples=samples, bin_count=bin_count)

    @property
    def bin_count(self) -> int:
        """Number of bins in the histogram."""
        return self._bin_count

    @property
    def range(self) -> tuple[float, float]:
        """(low, high) range of the histogram."""
        return self._range

    @property
    def weights(self) -> list[float | int]:
        """Bin counts (or weights) for each bin."""
        return self._weights

    def json(self) -> dict:
        """Return a dict suitable for serialization (type, bin_count, range, data)."""
        return {
            "type": "distribution",
            "bin_count": self._bin_count,
            "range": list(self._range),
            "data": self._weights,
        }

    def __repr__(self) -> str:
        """Short string representation (bin count and range)."""
        return f"Distribution(bins={self._bin_count}, range={self._range})"


def _to_list(obj: Any) -> list[float | int]:  # noqa: ANN401
    """Convert a sequence (or numpy array with tolist) to a Python list."""
    to_list = getattr(obj, "tolist", None)
    if to_list is not None:
        return cast("list[float | int]", to_list())
    return list(cast("list[float | int]", obj))
