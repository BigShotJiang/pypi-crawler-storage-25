"""Text custom object for tracking with :meth:`Run.track`."""

from __future__ import annotations


class Text:
    """A tracked text value for use with :meth:`Run.track`.

    :param text: The string content to log.

    Usage::

        run.track(Text("prediction: cat"), name="predictions", step=0)
    """

    def __init__(self, text: str) -> None:
        self._data = str(text)

    @property
    def data(self) -> str:
        """The text content."""
        return self._data

    def json(self) -> dict:
        """Return a dict suitable for serialization (type and data)."""
        return {"type": "text", "data": self._data}

    def __repr__(self) -> str:
        """Short string representation (first 60 chars of content)."""
        snippet = self._data[:60] + "..." if len(self._data) > 60 else self._data
        return f"Text({snippet!r})"
