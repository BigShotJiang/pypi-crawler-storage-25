#!/usr/bin/env python3
"""Smoke test for matyan_client SDK.

Requires:
  - matyan-backend  running on :53800
  - matyan-frontier running on :53801
  - ingestion worker running

Usage:
    cd matyan-client
    uv run python scripts/smoke_client.py
"""

from __future__ import annotations

import math
import time

import httpx
from loguru import logger

from matyan_client import Repo, Run, Text

BACKEND = "http://localhost:53800"
FRONTIER = "http://localhost:53801"
STEP_COUNT = 200


def main() -> None:
    run_hash: str | None = None
    client = httpx.Client(base_url=BACKEND, timeout=10)

    try:
        logger.info("=== Smoke test: matyan_client SDK ===")

        # -------------------------------------------------------------- create
        run = Run(experiment="smoke-test-exp")
        run_hash = run.hash
        logger.info("Created run {}", run_hash)
        logger.info("WS connected: {}", run._ws.connected if run._ws else False)

        # ---------------------------------------------------------- hyperparams
        run["hparams"] = {"lr": 0.001, "batch_size": 64, "optimizer": "adam"}
        logger.info("Set hparams via __setitem__")

        # ------------------------------------------------------------ set props
        run.name = "smoke-run"
        run.description = "End-to-end SDK smoke test"
        logger.info("Set name={}, description={}", run.name, run.description)

        # ---------------------------------------------------------------- track
        t0 = time.monotonic()
        for step in range(STEP_COUNT):
            loss = 1.0 / (step + 1) + 0.01 * math.sin(step)
            acc = 1.0 - loss
            run.track(loss, name="loss", step=step, context={"subset": "train"})
            run.track(acc, name="accuracy", step=step, context={"subset": "train"})
        enqueue_elapsed = time.monotonic() - t0

        logger.info(
            "Enqueued {} steps of loss & accuracy in {:.3f}s ({:.0f} msg/s)",
            STEP_COUNT,
            enqueue_elapsed,
            (STEP_COUNT * 2) / max(enqueue_elapsed, 0.001),
        )

        # ----------------------------------------------------------- text object
        run.track(Text("sample prediction"), name="predictions", step=0)
        logger.info("Tracked a Text object")

        # ----------------------------------------------------------------- tags
        run.add_tag("smoke-test")
        logger.info("Added tag 'smoke-test'")

        # ------------------------------------------------- wait for flush + close
        logger.info("Pending before flush: {}", run._ws.pending if run._ws else 0)
        if run._ws:
            flushed = run._ws.wait_for_flush(timeout=15)
            logger.info("Flushed: {} (pending={})", flushed, run._ws.pending)
            logger.info("WS stats: {}", run._ws.stats)

        run.close()
        logger.info("Run closed")

        # --------------------------------------------------- verify via backend
        logger.info("Waiting 3s for ingestion pipeline…")
        time.sleep(3)

        resp = client.get(f"/api/v1/rest/runs/{run_hash}/info/")
        if resp.status_code == 200:
            info = resp.json()
            logger.info("Backend returned run info:")
            logger.info("  props: {}", info.get("props", {}))
            logger.info("  params keys: {}", list(info.get("params", {}).keys()))
            traces = info.get("traces", {})
            metric_names = [t.get("name") for t in traces.get("metric", [])]
            logger.info("  metric traces: {}", metric_names)
        else:
            logger.warning("Backend returned {} for run info", resp.status_code)

        # --------------------------------------------------------- repo queries
        repo = Repo(BACKEND)
        all_runs = repo.list_all_runs()
        logger.info("Repo.list_all_runs(): {} run(s)", len(all_runs))
        repo.close()

        logger.info("=== Smoke test complete ===")

    finally:
        _cleanup(client, run_hash)
        client.close()


def _cleanup(client: httpx.Client, run_hash: str | None) -> None:
    """Delete the smoke-test run, tag, and experiment created during the test."""
    logger.info("=== Cleanup ===")

    if run_hash:
        resp = client.delete(f"/api/v1/rest/runs/{run_hash}/")
        logger.info("Delete run {}: {}", run_hash, resp.status_code)

    try:
        tags = client.get("/api/v1/rest/tags/").json()
        for tag in tags:
            if tag.get("name") == "smoke-test":
                resp = client.delete(f"/api/v1/rest/tags/{tag['id']}/")
                logger.info("Delete tag 'smoke-test' ({}): {}", tag["id"], resp.status_code)
    except Exception:  # noqa: BLE001
        logger.warning("Could not clean up tags")

    try:
        experiments = client.get("/api/v1/rest/experiments/").json()
        for exp in experiments:
            if exp.get("name") == "smoke-test-exp":
                resp = client.delete(f"/api/v1/rest/experiments/{exp['id']}/")
                logger.info("Delete experiment 'smoke-test-exp' ({}): {}", exp["id"], resp.status_code)
    except Exception:  # noqa: BLE001
        logger.warning("Could not clean up experiments")

    logger.info("=== Cleanup done ===")


if __name__ == "__main__":
    main()
