from __future__ import annotations

from logging import getLogger
from typing import Any

log = getLogger(__name__)


def apply_dataset_ctor_compat_patch() -> None:
    """Patch xarray Dataset ctor to accept Dataset positional input.

    Some linopy versions call ``xarray.Dataset(existing_dataset)``. Newer xarray
    rejects this with:
    ``TypeError: Passing a Dataset as data_vars to the Dataset constructor ...``.
    This shim maps that positional Dataset into ``data_vars/coords/attrs``.
    """
    if getattr(apply_dataset_ctor_compat_patch, "_patched", False):
        return

    try:
        import xarray as xr
    except Exception:
        return

    dataset_cls = xr.Dataset
    original_init = dataset_cls.__init__

    # Guard against double-patching across multiple imports/process hooks.
    if getattr(original_init, "_eta_incerto_dataset_ctor_compat", False):
        apply_dataset_ctor_compat_patch._patched = True
        return

    def _patched_init(self, data_vars: Any = None, coords: Any = None, attrs: Any = None) -> None:
        if isinstance(data_vars, xr.Dataset):
            source = data_vars
            if coords is None:
                coords = source.coords
            if attrs is None:
                attrs = source.attrs
            data_vars = dict(source.data_vars)
        original_init(self, data_vars=data_vars, coords=coords, attrs=attrs)

    _patched_init._eta_incerto_dataset_ctor_compat = True
    dataset_cls.__init__ = _patched_init
    apply_dataset_ctor_compat_patch._patched = True
    log.info("Applied xarray Dataset constructor compatibility patch for linopy.")
