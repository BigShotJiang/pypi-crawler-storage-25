from __future__ import annotations

from logging import getLogger
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, RootModel

log = getLogger(__name__)


class ConfigEvaluateVariant(BaseModel):
    """
    Per-variant evaluation configuration, e.g.

    "evaluate": {
        "variant_one": {...},
        "variant_two": {...}
    }
    """

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    # parallelization
    n_jobs: int = -1
    backend: str = "loky"
    parallel_strategy: Literal["safe", "aggressive", "sequential_fallback"] = Field(
        default="safe",
        description=(
            "How to interpret high parallelism requests. "
            "'safe' caps workers to avoid memory pressure; "
            "'aggressive' honors requested workers as much as possible; "
            "'sequential_fallback' forces single-worker evaluation after vectorized failures."
        ),
    )
    max_parallel_workers: int | None = Field(
        default=None,
        ge=1,
        description=(
            "Upper bound for workers in antifragile evaluation. If None, strategy-dependent defaults are used."
        ),
    )
    n_workers: int | None = Field(
        default=None,
        description="Optional process count for pymoo elementwise parallelization.",
    )
    vectorized: bool = Field(
        default=False,
        description="Use vectorized model evaluation for PCE training if supported (one build+solve per xi-batch).",
    )
    vectorized_batch_size: int | None = Field(
        default=None,
        description="When vectorized=True, cap batch size per vectorized build+solve (e.g. 64). None = full batch.",
    )
    vectorized_parallel_chunks: bool = Field(
        default=False,
        description=(
            "When vectorized=True and batches are split, allow parallel chunk execution. "
            "Default False to reduce peak memory for process-based backends."
        ),
    )

    # Optional solver overrides for PCE training (many MILP solves per evaluation)
    solver_mipgap_override: float | None = Field(
        default=None,
        description="Override mipgap for PCE training solves only (e.g. 0.08 to 0.10 for faster solves).",
    )
    solver_timelimit_override: float | None = Field(
        default=None,
        description="Per-solve time limit [s] for PCE training; hard instances may be suboptimal.",
    )

    # PCE / quadrature
    pce_order: int
    pce_rule: str
    pce_fit_method: Literal["full", "stepwise_sparse"] = Field(
        default="full",
        description=(
            "PCE regression strategy. 'full' fits all basis terms via Chaospy regression; "
            "'stepwise_sparse' performs forward sparse term selection and returns dense coefficients."
        ),
    )
    pce_sample_factor: int = Field(
        default=4,
        ge=1,
        description="PCE training samples = max(pce_sample_factor * len(poly_exp), 1).\
            Lower = faster, coarser surrogate.",
    )
    stepwise_max_iterations: int | None = Field(
        default=None,
        ge=1,
        description="Max forward-selection iterations for stepwise_sparse; None = capped by basis size.",
    )
    stepwise_max_terms: int | None = Field(
        default=None,
        ge=1,
        description="Upper bound for selected polynomial terms in stepwise_sparse; None = basis size.",
    )
    stepwise_min_improvement: float = Field(
        default=0.0,
        ge=0.0,
        description="Minimum RMSE improvement required to accept a newly selected term.",
    )
    stepwise_refit_final_model: bool = Field(
        default=True,
        description="If True, refit OLS on the final active set after forward selection.",
    )
    stepwise_score_metric: Literal["t_stat", "rmse"] = Field(
        default="t_stat",
        description=(
            "Candidate ranking in stepwise_sparse: 't_stat' uses |coef|/sqrt(var_coef) proxy, "
            "'rmse' ranks by best in-sample RMSE."
        ),
    )
    stepwise_sample_factor_multiplier: float = Field(
        default=0.5,
        gt=0.0,
        description=(
            "When pce_fit_method='stepwise_sparse', effective sample factor is "
            "max(1, round(pce_sample_factor * stepwise_sample_factor_multiplier))."
        ),
    )
    pce_loo_initial_generation_enabled: bool = Field(
        default=False,
        description=(
            "If True, compute exact leave-one-out RMSE on the PCE training sample when pymoo's algorithm.n_gen "
            "matches pce_loo_initial_generation_n_gen (expensive: O(n) refits per objective evaluation). "
            "Requires sequential elementwise evaluation; may break if pymoo problem parallelization passes "
            "unpicklable kwargs."
        ),
    )
    pce_loo_initial_generation_n_gen: int = Field(
        default=1,
        ge=1,
        description=(
            "Run LOO only for this pymoo generation index. Default 1 = initial population under pymoo 0.6+ "
            "(first evaluated batch before n_gen increments)."
        ),
    )
    quad_order: int
    quad_rule: str

    # statistics
    stat_n_mc: int
    stat_omega: float
    omega_mode: Literal["fixed", "quantile", "median_anchor"] = Field(
        default="fixed",
        description=(
            "UPR omega strategy: fixed uses stat_omega as-is; "
            "quantile derives omega from sampled objective values; "
            "median_anchor sets omega=median(y)+omega_anchor_shift."
        ),
    )
    omega_quantile: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Quantile level used when omega_mode='quantile'.",
    )
    omega_anchor_shift: float = Field(
        default=0.0,
        description="Additive shift used when omega_mode='median_anchor'.",
    )
    stat_rule: str

    objective_stat_mode: Literal["mc_median_skew_upr", "pce_mean_var_upr"] = Field(
        default="mc_median_skew_upr",
        description=(
            "After PCE fit: mc_median_skew_upr = feasible MC on surrogate (median, skew, UPR); "
            "pce_mean_var_upr = mean & variance (nominal chaospy or feasible MC) plus UPR."
        ),
    )
    moment_reference: Literal["nominal", "feasible"] = Field(
        default="nominal",
        description=(
            "For pce_mean_var_upr: nominal = E/Var of the PCE under the configured joint dist; "
            "feasible = sample mean/var of PCE outputs on feasible xi (same support as training)."
        ),
    )

    independence_diagnostics_enabled: bool = Field(
        default=False,
        description="If True, write Pearson correlation matrix of xi samples to HDF5 (independence/ group).",
    )
    independence_sample_space: Literal["feasible", "nominal"] = Field(
        default="feasible",
        description="Sample ensemble for correlation: feasible (post-rejection) vs nominal joint draws.",
    )
    independence_n_samples: int | None = Field(
        default=None,
        ge=2,
        description="Sample count for correlation; default max(256, 2 * stat_n_mc) when None.",
    )
    independence_max_abs_corr_threshold: float = Field(
        default=0.25,
        ge=0.0,
        le=1.0,
        description="Max |rho_ij| off-diagonal; above => status above_threshold (audit flag).",
    )
    independence_rng_seed: int | None = Field(
        default=42,
        description="RNG seed for nominal-space draws only; None = nondeterministic.",
    )

    sobol_diagnostics_enabled: bool = Field(
        default=False,
        description=(
            "If True, compute Sobol' indices (first/total) from the PCE regression coefficients "
            "for each saved Pareto design and write them under HDF5 group sobol/."
        ),
    )
    sobol_max_pareto_points: int = Field(
        default=5,
        ge=1,
        description="Cap Pareto designs for which Sobol' diagnostics are computed (each triggers a PCE refit).",
    )

    marginal_diagnostics_enabled: bool = Field(
        default=False,
        description=(
            "If True, write per-input marginal PDF/CDF curves (and optional feasible histogram) under marginals/."
        ),
    )
    marginal_plot_grid_points: int = Field(
        default=256,
        ge=8,
        description="Number of points on the inverse-CDF grid for stored pdf/cdf curves.",
    )
    marginal_hist_n_samples: int | None = Field(
        default=None,
        ge=1,
        description="If set, draw this many feasible xi samples and store a histogram density overlay per marginal.",
    )
    marginal_hist_bins: int = Field(
        default=40,
        ge=4,
        description="Histogram bin count for marginal_hist_n_samples.",
    )

    # feasibility / rejection sampling controls
    feasibility_hot_idx: int
    feasibility_cold_idx: int
    feasibility_warm_idx: int | None = None  # only used for variants that need it
    feasibility_dt_min: float = Field(..., description="Minimum temperature difference [K].")
    feasibility_batch_size: int = 256
    feasibility_max_rounds: int = 200


class ConfigEvaluate(RootModel[dict[str, ConfigEvaluateVariant]]):
    """
    Root 'evaluate' section:
      evaluate: dict[str, ConfigEvaluateVariant]
    """

    def for_variant(self, variant: str) -> ConfigEvaluateVariant:
        try:
            return self.root[variant]
        except KeyError as e:
            raise KeyError(f"No evaluate config found for variant '{variant}'.") from e
