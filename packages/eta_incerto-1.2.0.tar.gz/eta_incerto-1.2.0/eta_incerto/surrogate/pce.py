"""Polynomial chaos expansion: basis generation, regression fitting, and prediction.

Provenance notes
----------------
The explicit design-matrix/OLS utilities mirror mathematical scaffolding used in
``C:/Git/Dissertation/bib/antifragile/pce.py`` and ``C:/Git/RHEIA/rheia/UQ/pce.py``.
The sparse forward-selection policy follows the stepwise sparse-PCE direction
described in Abraham et al. (2017), as referenced by the antifragile paper.
"""

from __future__ import annotations

from typing import Any, Literal

import numpy as np
from chaospy import (
    fit_regression as _fit_regression,
    generate_expansion as _generate_expansion,
)
from chaospy.distributions.baseclass import Distribution
from numpy import asarray


def generate_polynomial_expansion(order: int, dist: Distribution) -> Any:
    return _generate_expansion(order=int(order), dist=dist)


def training_sample_count(poly_expansion: Any, factor: int) -> int:
    """Training samples = max(factor * n_basis, 1)."""
    factor = int(factor)
    return max(factor * len(poly_expansion), 1)


def _design_matrix(poly_expansion: Any, samples: np.ndarray) -> np.ndarray:
    samples = np.asarray(samples, dtype=float)
    if samples.ndim != 2:
        raise ValueError(f"samples must be 2D (n_dim, n_samples), got {samples.shape}")
    basis_eval = np.asarray(poly_expansion(*samples), dtype=float)
    if basis_eval.ndim == 1:
        basis_eval = basis_eval.reshape(1, -1)
    if basis_eval.shape[0] != len(poly_expansion):
        basis_eval = basis_eval.reshape(len(poly_expansion), samples.shape[1])
    return np.asarray(basis_eval.T, dtype=float)


def _ols_solution(x_mat: np.ndarray, y_vec: np.ndarray) -> tuple[np.ndarray, np.ndarray, float, float]:
    x = np.asarray(x_mat, dtype=float)
    y = np.asarray(y_vec, dtype=float).ravel()
    coeffs, *_ = np.linalg.lstsq(x, y, rcond=None)
    y_hat = x @ coeffs
    residual = y - y_hat
    rss = float(np.dot(residual, residual))
    rmse = float(np.sqrt(max(rss, 0.0) / max(1, y.size)))
    return coeffs, y_hat, rss, rmse


def _score_stepwise_candidate(
    score_metric: Literal["t_stat", "rmse"],
    *,
    n_samples: int,
    n_cols: int,
    x_try: np.ndarray,
    coef_try: np.ndarray,
    rss_try: float,
    rmse_try: float,
) -> float:
    if score_metric == "rmse":
        return -float(rmse_try)

    # Abraham-style stepwise proxy: rank by coefficient significance.
    dof = max(1, n_samples - n_cols)
    sigma2 = float(rss_try) / float(dof)
    try:
        inv_xtx = np.linalg.pinv(x_try.T @ x_try)
        var_last = float(max(inv_xtx[-1, -1] * sigma2, 1e-18))
        return abs(float(coef_try[-1])) / float(np.sqrt(var_last))
    except Exception:
        return -np.inf


def _stepwise_sparse_coefficients(
    poly_expansion: Any,
    samples: np.ndarray,
    responses: Any,
    *,
    max_iterations: int | None,
    max_terms: int | None,
    min_improvement: float,
    refit_final_model: bool,
    score_metric: Literal["t_stat", "rmse"],
) -> np.ndarray:
    """Forward sparse term selection on a fixed polynomial basis.

    Candidate ranking uses either an in-sample RMSE objective or a significance-like
    proxy ``|coef| / sqrt(var_coef)`` based on an OLS covariance approximation.
    """
    y = np.asarray(responses, dtype=float).ravel()
    if y.size < 2:
        dense = np.zeros((len(poly_expansion),), dtype=float)
        if y.size == 1:
            dense[0] = float(y[0])
        return dense

    a_full = _design_matrix(poly_expansion, samples)
    n_samples, n_basis = a_full.shape
    if n_basis <= 0:
        return np.zeros((0,), dtype=float)

    max_terms_eff = int(n_basis if max_terms is None else max(1, min(int(max_terms), n_basis)))
    max_iter_eff = int(max_terms_eff if max_iterations is None else max(1, min(int(max_iterations), n_basis)))
    min_improvement = float(max(0.0, min_improvement))

    selected: list[int] = [0]
    remaining = [idx for idx in range(n_basis) if idx not in selected]

    x_sel = a_full[:, selected]
    _coef, _y_hat, _prev_rss, prev_rmse = _ols_solution(x_sel, y)

    for _ in range(max_iter_eff):
        if not remaining or len(selected) >= max_terms_eff:
            break
        best_idx: int | None = None
        best_score = -np.inf
        best_rmse = np.inf
        best_coef = None

        for cand in remaining:
            cols = [*selected, cand]
            x_try = a_full[:, cols]
            coef_try, _y_hat_try, rss_try, rmse_try = _ols_solution(x_try, y)
            score = _score_stepwise_candidate(
                score_metric,
                n_samples=n_samples,
                n_cols=len(cols),
                x_try=x_try,
                coef_try=coef_try,
                rss_try=rss_try,
                rmse_try=rmse_try,
            )

            if (score > best_score) or (np.isclose(score, best_score) and rmse_try < best_rmse):
                best_score = float(score)
                best_idx = int(cand)
                best_rmse = float(rmse_try)
                best_coef = np.asarray(coef_try, dtype=float)

        if best_idx is None or best_coef is None:
            break

        improvement = float(prev_rmse - best_rmse)
        if selected and improvement < min_improvement:
            break

        selected.append(best_idx)
        remaining.remove(best_idx)
        prev_rmse = best_rmse

    # Always fit coefficients for the final active set; keep flag for API compatibility.
    _ = refit_final_model
    x_final = a_full[:, selected]
    coef_sel, *_ = _ols_solution(x_final, y)

    dense = np.zeros((n_basis,), dtype=float)
    dense[np.asarray(selected, dtype=int)] = np.asarray(coef_sel, dtype=float)
    return dense


def _polynomial_model_from_coefficients(poly_expansion: Any, coefficients: np.ndarray) -> Any:
    coeffs = np.asarray(coefficients, dtype=float).ravel()
    model = None
    for idx, coef in enumerate(coeffs):
        if abs(float(coef)) <= 1e-15:
            continue
        term = float(coef) * poly_expansion[idx]
        model = term if model is None else model + term
    if model is None:
        model = float(coeffs[0]) * poly_expansion[0] if coeffs.size else 0.0
    return model


def fit_pce_regression(
    poly_expansion: Any,
    samples: np.ndarray,
    responses: Any,
    *,
    method: Literal["full", "stepwise_sparse"] = "full",
    stepwise_config: dict[str, Any] | None = None,
) -> Any:
    """Fit PCE via regression; samples are (n_dim, n_samples) chaospy layout."""
    if method == "full":
        return _fit_regression(poly_expansion, samples, responses)

    cfg = dict(stepwise_config or {})
    coeffs = _stepwise_sparse_coefficients(
        poly_expansion,
        samples,
        responses,
        max_iterations=cfg.get("max_iterations"),
        max_terms=cfg.get("max_terms"),
        min_improvement=float(cfg.get("min_improvement", 0.0)),
        refit_final_model=bool(cfg.get("refit_final_model", True)),
        score_metric=str(cfg.get("score_metric", "t_stat")).lower(),  # type: ignore[arg-type]
    )
    return _polynomial_model_from_coefficients(poly_expansion, coeffs)


def fit_pce_regression_with_coefficients(
    poly_expansion: Any,
    samples: np.ndarray,
    responses: Any,
    *,
    method: Literal["full", "stepwise_sparse"] = "full",
    stepwise_config: dict[str, Any] | None = None,
) -> tuple[Any, np.ndarray]:
    """Same as :func:`fit_pce_regression` but also return regression coefficients (for Sobol' indices)."""
    if method == "full":
        model, coeffs = _fit_regression(poly_expansion, samples, responses, retall=True)
        return model, np.asarray(coeffs, dtype=float)

    cfg = dict(stepwise_config or {})
    coeffs = _stepwise_sparse_coefficients(
        poly_expansion,
        samples,
        responses,
        max_iterations=cfg.get("max_iterations"),
        max_terms=cfg.get("max_terms"),
        min_improvement=float(cfg.get("min_improvement", 0.0)),
        refit_final_model=bool(cfg.get("refit_final_model", True)),
        score_metric=str(cfg.get("score_metric", "t_stat")).lower(),  # type: ignore[arg-type]
    )
    return _polynomial_model_from_coefficients(poly_expansion, coeffs), np.asarray(coeffs, dtype=float)


def predict_pce(pce_model: Any, evaluation_points: np.ndarray) -> np.ndarray:
    """Evaluate fitted PCE at chaospy-layout points (n_dim, n_points)."""
    return asarray(pce_model(*evaluation_points), dtype=float)
