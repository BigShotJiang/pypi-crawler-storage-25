"""Manifest parsers for all supported ecosystems."""
from __future__ import annotations

import json
import re
from typing import List, Optional, Set, Tuple

Dep = Tuple[str, str]  # (name, version)

ECOSYSTEM_MAP = {
    "requirements.txt": "PyPI",
    "Pipfile.lock": "PyPI",
    "setup.cfg": "PyPI",
    "package.json": "npm",
    "package-lock.json": "npm",
    "yarn.lock": "npm",
    "go.mod": "Go",
    "go.sum": "Go",
    "Cargo.toml": "crates.io",
    "Cargo.lock": "crates.io",
    "Gemfile.lock": "RubyGems",
    "composer.json": "Packagist",
    "composer.lock": "Packagist",
}


def detect_ecosystem(filename: str, content: str) -> str:
    """Auto-detect ecosystem from filename or content patterns."""
    fname = filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    if fname in ECOSYSTEM_MAP:
        return ECOSYSTEM_MAP[fname]

    if '"dependencies"' in content or '"devDependencies"' in content:
        return "npm"
    if "require (" in content or "module " in content:
        return "Go"
    if re.search(r"^\w[\w\-\.]*==", content, re.MULTILINE):
        return "PyPI"
    if "[dependencies]" in content or "[package]" in content:
        return "crates.io"
    return "PyPI"


# ---------------------------------------------------------------------------
# Python
# ---------------------------------------------------------------------------

def parse_requirements_txt(content: str) -> List[Dep]:
    deps: List[Dep] = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        m = re.match(r"^([a-zA-Z0-9_\-\.]+)\s*[=~!><]=?\s*(\d[^\s,;#]*)", line)
        if m:
            deps.append((m.group(1).lower(), m.group(2)))
    return deps


def parse_pipfile_lock(content: str) -> List[Dep]:
    deps: List[Dep] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps
    for section in ("default", "develop"):
        for name, info in data.get(section, {}).items():
            ver = info.get("version", "").lstrip("=")
            if name and ver:
                deps.append((name.lower(), ver))
    return deps


# ---------------------------------------------------------------------------
# JavaScript / Node
# ---------------------------------------------------------------------------

def parse_package_json(content: str) -> List[Dep]:
    deps: List[Dep] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps
    for section in ("dependencies", "devDependencies", "peerDependencies"):
        for name, ver in data.get(section, {}).items():
            deps.append((name, re.sub(r"^[\^~>=<\s]+", "", ver)))
    return deps


def parse_package_lock_json(content: str) -> List[Dep]:
    deps: List[Dep] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps

    # v2/v3: "packages" dict (keys are node_modules paths)
    packages = data.get("packages", {})
    if packages:
        for path, info in packages.items():
            if not path:
                continue
            name = info.get("name") or path.rsplit("node_modules/", 1)[-1]
            ver = info.get("version", "")
            if name and ver:
                deps.append((name, ver))
        return deps

    # v1: recursive "dependencies" dict
    def _walk(deps_dict: dict) -> None:
        for name, info in deps_dict.items():
            ver = info.get("version", "")
            if name and ver:
                deps.append((name, ver))
            if "dependencies" in info:
                _walk(info["dependencies"])

    _walk(data.get("dependencies", {}))
    return deps


def parse_yarn_lock(content: str) -> List[Dep]:
    deps: List[Dep] = []
    current_name: Optional[str] = None
    for line in content.splitlines():
        if not line or line.startswith("#"):
            continue
        if not line.startswith(" ") and line.endswith(":"):
            first_entry = line.rstrip(":").split(",")[0].strip().strip('"')
            at_idx = first_entry.rfind("@")
            current_name = first_entry[:at_idx] if at_idx > 0 else None
            continue
        if current_name is not None:
            stripped = line.strip()
            if stripped.startswith("version "):
                ver = stripped.split('"')[1] if '"' in stripped else stripped.split()[1]
                deps.append((current_name, ver))
                current_name = None
    return deps


# ---------------------------------------------------------------------------
# Go
# ---------------------------------------------------------------------------

def parse_go_mod(content: str) -> List[Dep]:
    deps: List[Dep] = []
    in_require = False
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("require ("):
            in_require = True
            continue
        if line == ")" and in_require:
            in_require = False
            continue
        if in_require:
            parts = line.split()
            if len(parts) >= 2 and not parts[0].startswith("//"):
                deps.append((parts[0], parts[1].lstrip("v")))
        elif line.startswith("require "):
            parts = line.split()
            if len(parts) >= 3:
                deps.append((parts[1], parts[2].lstrip("v")))
    return deps


def parse_go_sum(content: str) -> List[Dep]:
    deps: List[Dep] = []
    seen: Set[Tuple[str, str]] = set()
    for line in content.splitlines():
        parts = line.strip().split()
        if len(parts) < 2:
            continue
        name = parts[0]
        ver_part = parts[1]
        if "/go.mod" in ver_part:
            continue
        ver = ver_part.lstrip("v")
        key = (name, ver)
        if key not in seen:
            seen.add(key)
            deps.append(key)
    return deps


# ---------------------------------------------------------------------------
# Rust
# ---------------------------------------------------------------------------

def parse_cargo_toml(content: str) -> List[Dep]:
    deps: List[Dep] = []
    in_deps = False
    for line in content.splitlines():
        s = line.strip()
        if s in ("[dependencies]", "[dev-dependencies]", "[build-dependencies]"):
            in_deps = True
            continue
        if s.startswith("[") and in_deps:
            in_deps = False
            continue
        if in_deps and "=" in s:
            # Simple: name = "version"
            m = re.match(r'^([a-zA-Z0-9_\-]+)\s*=\s*"([^"]*)"', s)
            if m:
                deps.append((m.group(1), m.group(2)))
                continue
            # Inline table: name = { version = "1.0", ... }
            m = re.match(r'^([a-zA-Z0-9_\-]+)\s*=\s*\{.*version\s*=\s*"([^"]*)"', s)
            if m:
                deps.append((m.group(1), m.group(2)))
    return deps


def parse_cargo_lock(content: str) -> List[Dep]:
    deps: List[Dep] = []
    name = ""
    version = ""
    for line in content.splitlines():
        s = line.strip()
        if s == "[[package]]":
            if name and version:
                deps.append((name, version))
            name = ""
            version = ""
            continue
        m = re.match(r'^name\s*=\s*"([^"]+)"', s)
        if m:
            name = m.group(1)
            continue
        m = re.match(r'^version\s*=\s*"([^"]+)"', s)
        if m:
            version = m.group(1)
    if name and version:
        deps.append((name, version))
    return deps


# ---------------------------------------------------------------------------
# Ruby
# ---------------------------------------------------------------------------

def parse_gemfile_lock(content: str) -> List[Dep]:
    deps: List[Dep] = []
    in_specs = False
    for line in content.splitlines():
        if line.strip() == "specs:":
            in_specs = True
            continue
        if in_specs:
            m = re.match(r"^\s{4}(\S+)\s+\(([^)]+)\)", line)
            if m:
                deps.append((m.group(1), m.group(2)))
            elif not line.startswith(" "):
                in_specs = False
    return deps


# ---------------------------------------------------------------------------
# PHP
# ---------------------------------------------------------------------------

def parse_composer_json(content: str) -> List[Dep]:
    deps: List[Dep] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps
    for section in ("require", "require-dev"):
        for name, ver in data.get(section, {}).items():
            if name == "php" or name.startswith("ext-"):
                continue
            deps.append((name, re.sub(r"^[\^~>=<\s]+", "", ver)))
    return deps


def parse_composer_lock(content: str) -> List[Dep]:
    deps: List[Dep] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps
    for section in ("packages", "packages-dev"):
        for pkg in data.get(section, []):
            name = pkg.get("name", "")
            ver = pkg.get("version", "").lstrip("v")
            if name and ver:
                deps.append((name, ver))
    return deps


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

_ECOSYSTEM_PARSERS = {
    "PyPI": parse_requirements_txt,
    "npm": parse_package_json,
    "Go": parse_go_mod,
    "crates.io": parse_cargo_toml,
    "Packagist": parse_composer_json,
    "RubyGems": parse_gemfile_lock,
}

_FILE_PARSERS = {
    "requirements.txt": parse_requirements_txt,
    "Pipfile.lock": parse_pipfile_lock,
    "setup.cfg": parse_requirements_txt,
    "package.json": parse_package_json,
    "package-lock.json": parse_package_lock_json,
    "yarn.lock": parse_yarn_lock,
    "go.mod": parse_go_mod,
    "go.sum": parse_go_sum,
    "Cargo.toml": parse_cargo_toml,
    "Cargo.lock": parse_cargo_lock,
    "Gemfile.lock": parse_gemfile_lock,
    "composer.json": parse_composer_json,
    "composer.lock": parse_composer_lock,
}


def parse(content: str, ecosystem: str, filename: str = "") -> List[Dep]:
    """Parse manifest content, return list of (name, version) tuples."""
    fname = filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1] if filename else ""
    parser = _FILE_PARSERS.get(fname) or _ECOSYSTEM_PARSERS.get(ecosystem, parse_requirements_txt)
    return [(n, v) for n, v in parser(content) if n and v]


_MANIFEST_NAMES = [
    "requirements.txt", "Pipfile.lock", "package.json", "package-lock.json",
    "yarn.lock", "go.mod", "Cargo.toml", "Cargo.lock", "Gemfile.lock",
    "composer.json", "composer.lock",
]

_SKIP_DIRS = {"node_modules", ".git", "venv", ".venv", "__pycache__", ".tox", "dist", "build"}


def find_manifest(directory: str = ".") -> Optional[str]:
    """Walk current dir for the first recognized manifest file."""
    import os

    for name in _MANIFEST_NAMES:
        path = os.path.join(directory, name)
        if os.path.isfile(path):
            return path
    return None


def find_all_manifests(directory: str = ".") -> List[str]:
    """Recursively find all recognized manifest files, skipping common junk dirs."""
    import os

    found: List[str] = []
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in _SKIP_DIRS]
        for name in files:
            if name in _MANIFEST_NAMES:
                found.append(os.path.join(root, name))
    return sorted(found)
