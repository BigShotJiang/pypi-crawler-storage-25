"""SARIF v2.1.0 output formatter for pinaka-scan."""
from __future__ import annotations

import json
from typing import Any, Dict, List

from . import __version__
from .scanner import ScanResult, Vuln

SARIF_SCHEMA = "https://docs.oasis-open.org/sarif/sarif/v2.1.0/errata01/os/schemas/sarif-schema-2.1.0.json"

_SEVERITY_TO_LEVEL = {
    "CRITICAL": "error",
    "HIGH": "error",
    "MEDIUM": "warning",
    "LOW": "note",
    "UNKNOWN": "note",
}


def _build_rule(vuln: Vuln) -> Dict[str, Any]:
    """Build a SARIF rule descriptor from a Vuln."""
    rule: Dict[str, Any] = {
        "id": vuln.vuln_id,
        "shortDescription": {"text": f"{vuln.severity} vulnerability in {vuln.package}@{vuln.version}"},
        "helpUri": vuln.url,
    }
    if vuln.summary:
        rule["fullDescription"] = {"text": vuln.summary}
    return rule


def _build_result(vuln: Vuln, manifest_path: str) -> Dict[str, Any]:
    """Build a SARIF result object from a Vuln."""
    location = vuln.source_file or manifest_path
    result: Dict[str, Any] = {
        "ruleId": vuln.vuln_id,
        "level": _SEVERITY_TO_LEVEL.get(vuln.severity, "note"),
        "message": {
            "text": f"{vuln.severity} — {vuln.package}@{vuln.version}: {vuln.summary}",
        },
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {"uri": location},
                    "region": {"startLine": 1},
                },
            }
        ],
    }

    props: Dict[str, Any] = {}
    if vuln.score is not None:
        props["cvssScore"] = vuln.score
    if vuln.fixed_version:
        props["fixedVersion"] = vuln.fixed_version
    if vuln.aliases:
        props["aliases"] = vuln.aliases
    if props:
        result["properties"] = props

    return result


def to_sarif(result: ScanResult, manifest_path: str = "") -> Dict[str, Any]:
    """Convert a ScanResult into a SARIF v2.1.0 document."""
    seen_rules: Dict[str, Dict[str, Any]] = {}
    results: List[Dict[str, Any]] = []

    for vuln in result.vulns:
        if vuln.vuln_id not in seen_rules:
            seen_rules[vuln.vuln_id] = _build_rule(vuln)
        results.append(_build_result(vuln, manifest_path))

    return {
        "$schema": SARIF_SCHEMA,
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "pinaka-scan",
                        "version": __version__,
                        "informationUri": "https://github.com/0xParth/pinaka-scan",
                        "rules": list(seen_rules.values()),
                    }
                },
                "results": results,
            }
        ],
    }


def output_sarif(result: ScanResult, manifest_path: str = "") -> None:
    """Print SARIF JSON to stdout."""
    print(json.dumps(to_sarif(result, manifest_path), indent=2))
