"""CLI entry point for pinaka-scan."""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List, Optional, Set

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from . import __version__
from .parsers import detect_ecosystem, find_all_manifests, find_manifest, parse
from .scanner import ScanResult, Vuln, scan, version_key
from .sarif import output_sarif

console = Console()

SEVERITY_STYLE = {
    "CRITICAL": "bold red",
    "HIGH": "bold bright_red",
    "MEDIUM": "bold yellow",
    "LOW": "bold green",
    "UNKNOWN": "dim",
}

BANNER = r"""[bold bright_magenta]
    ____  _             __            _____
   / __ \(_)___  ____ _/ /______ _   / ___/_________ _____
  / /_/ / / __ \/ __ `/ //_/ __ `/   \__ \/ ___/ __ `/ __ \
 / ____/ / / / / /_/ / ,< / /_/ /   ___/ / /__/ /_/ / / / /
/_/   /_/_/ /_/\__,_/_/|_|\__,_/   /____/\___/\__,_/_/ /_/
[/]
[dim]Free dependency vulnerability scanner — powered by OSV.dev[/]
[dim]https://pinaka.sh[/]
"""


# ---------------------------------------------------------------------------
# .pinaka-ignore
# ---------------------------------------------------------------------------

def _load_ignore_file(path: str) -> Set[str]:
    """Read a .pinaka-ignore file and return the set of IDs to suppress."""
    ids: Set[str] = set()
    if not os.path.isfile(path):
        return ids
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                ids.add(line)
    return ids


def _apply_ignore(vulns: List[Vuln], ignore_ids: Set[str]) -> tuple:
    """Filter vulns against ignore set. Returns (kept, ignored_count)."""
    if not ignore_ids:
        return vulns, 0
    kept: List[Vuln] = []
    ignored = 0
    for v in vulns:
        all_ids = {v.vuln_id} | set(v.aliases)
        if all_ids & ignore_ids:
            ignored += 1
        else:
            kept.append(v)
    return kept, ignored


# ---------------------------------------------------------------------------
# Output renderers
# ---------------------------------------------------------------------------

def _render_results(result: ScanResult, verbose: bool = False, ignored_count: int = 0) -> None:
    """Pretty-print scan results to terminal."""
    console.print()

    if result.error:
        console.print(f"[red]Error:[/] {result.error}")
        return

    counts = result.counts
    total_vulns = len(result.vulns)

    parts = []
    parts.append(f"[bold]Ecosystem:[/] {result.ecosystem}")
    parts.append(f"[bold]Packages scanned:[/] {result.total_deps}")
    parts.append(f"[bold]Vulnerable packages:[/] {result.vulnerable_count}")
    parts.append("")
    if counts["critical"]:
        parts.append(f"  [bold red]● {counts['critical']} Critical[/]")
    if counts["high"]:
        parts.append(f"  [bold bright_red]● {counts['high']} High[/]")
    if counts["medium"]:
        parts.append(f"  [bold yellow]● {counts['medium']} Medium[/]")
    if counts["low"]:
        parts.append(f"  [bold green]● {counts['low']} Low[/]")

    border = "red" if counts["critical"] else "yellow" if counts["high"] else "green"
    console.print(Panel(
        "\n".join(parts),
        title=f"[bold]{total_vulns} vulnerabilit{'y' if total_vulns == 1 else 'ies'} found[/]" if total_vulns else "[bold green]No vulnerabilities found[/]",
        border_style=border if total_vulns else "green",
        padding=(1, 2),
    ))

    if total_vulns == 0 and ignored_count == 0:
        console.print("[green]✓[/] All dependencies passed.\n")
        return

    if total_vulns > 0:
        table = Table(show_header=True, header_style="bold", border_style="dim", pad_edge=False)
        table.add_column("Severity", width=10)
        table.add_column("Package", min_width=20)
        table.add_column("ID", min_width=16)
        table.add_column("Fix", min_width=10)
        if verbose:
            table.add_column("Summary", max_width=60)

        for v in result.vulns:
            style = SEVERITY_STYLE.get(v.severity, "")
            sev_text = Text(v.severity, style=style)
            pkg_label = f"{v.package}@{v.version}"
            if v.source_file:
                pkg_label += f" ({v.source_file})"

            cves = [a for a in v.aliases if a.startswith("CVE-")]
            id_text = cves[0] if cves else v.vuln_id

            fix_text = Text(v.fixed_version or "—", style="green" if v.fixed_version else "dim")

            row: list = [sev_text, pkg_label, id_text, fix_text]
            if verbose:
                row.append(v.summary[:80])
            table.add_row(*row)

        console.print(table)
        console.print()

    if result.query_errors:
        console.print(
            f"[yellow]⚠ {len(result.query_errors)} package(s) could not be queried[/]"
        )
        console.print()

    if ignored_count:
        console.print(f"[dim]{ignored_count} vulnerabilit{'y' if ignored_count == 1 else 'ies'} ignored via .pinaka-ignore[/]")
        console.print()

    fixable = [v for v in result.vulns if v.fixed_version]
    if fixable:
        console.print("[bold]Suggested fixes:[/]")
        pkg_fixes: dict = {}
        for v in fixable:
            pkg_fixes.setdefault(v.package, []).append(v.fixed_version)
        for pkg in sorted(pkg_fixes):
            best = max(pkg_fixes[pkg], key=version_key)
            console.print(f"  [green]↑[/] {pkg} → [bold]{best}[/]")
        console.print()


def _output_json(result: ScanResult, ignored_count: int = 0) -> None:
    """Output results as JSON for CI/piping."""
    data = {
        "ecosystem": result.ecosystem,
        "total_dependencies": result.total_deps,
        "vulnerable_count": result.vulnerable_count,
        "total_vulns": len(result.vulns),
        "summary": result.counts,
        "vulnerabilities": [
            {
                "package": v.package,
                "version": v.version,
                "vuln_id": v.vuln_id,
                "aliases": v.aliases,
                "summary": v.summary,
                "severity": v.severity,
                "score": v.score,
                "fixed_version": v.fixed_version,
                "url": v.url,
                **({"source_file": v.source_file} if v.source_file else {}),
            }
            for v in result.vulns
        ],
    }
    if result.error:
        data["error"] = result.error
    if result.query_errors:
        data["query_errors"] = result.query_errors
    if ignored_count:
        data["ignored_count"] = ignored_count
    print(json.dumps(data, indent=2))


# ---------------------------------------------------------------------------
# Single-file scan helper
# ---------------------------------------------------------------------------

def _scan_file(
    filepath: str,
    ecosystem_override: Optional[str],
    quiet: bool = False,
) -> ScanResult:
    """Parse and scan a single manifest file. Returns ScanResult."""
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    filename = os.path.basename(filepath)
    ecosystem = ecosystem_override or detect_ecosystem(filename, content)

    if not quiet:
        console.print(f"[bold]Scanning:[/] {filepath}")
        console.print(f"[bold]Ecosystem:[/] {ecosystem}")
        console.print()

    deps = parse(content, ecosystem, filename)

    if not deps:
        return ScanResult(ecosystem=ecosystem, total_deps=0, error=f"No versioned dependencies found in {filepath}")

    if not quiet:
        console.print(f"[dim]Querying OSV.dev for {len(deps)} packages...[/]")

    result = scan(deps, ecosystem)

    # Tag vulns with source file for recursive mode
    for v in result.vulns:
        v.source_file = filepath

    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv: Optional[list] = None) -> None:
    parser = argparse.ArgumentParser(
        prog="pinaka-scan",
        description="Free dependency vulnerability scanner — powered by OSV.dev",
    )
    parser.add_argument(
        "file",
        nargs="?",
        help="Path to manifest file (auto-detected if omitted)",
    )
    parser.add_argument(
        "-e", "--ecosystem",
        choices=["PyPI", "npm", "Go", "crates.io", "RubyGems", "Packagist"],
        help="Override ecosystem detection",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output results as JSON (for CI pipelines)",
    )
    parser.add_argument(
        "--sarif",
        action="store_true",
        dest="sarif_output",
        help="Output results as SARIF v2.1.0 (for GitHub Security tab)",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show vulnerability summaries in table",
    )
    parser.add_argument(
        "-d", "--dir",
        default=".",
        help="Directory to scan (default: current dir)",
    )
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Recursively scan all manifest files in directory tree",
    )
    parser.add_argument(
        "--ignore-file",
        default=".pinaka-ignore",
        help="Path to ignore file (default: .pinaka-ignore)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--fail-on",
        choices=["critical", "high", "medium", "low", "any"],
        default="any",
        help="Exit 1 only if vulns at this severity or above are found (default: any)",
    )

    args = parser.parse_args(argv)
    machine_output = args.json_output or args.sarif_output

    if not machine_output:
        console.print(BANNER)

    # ── Resolve files ─────────────────────────────────────────────────
    filepaths: List[str] = []

    if args.file:
        filepaths = [args.file]
    elif args.recursive:
        filepaths = find_all_manifests(args.dir)
        if not filepaths:
            msg = f"No manifest files found in {args.dir} (recursive)"
            if machine_output:
                print(json.dumps({"error": msg}))
            else:
                console.print(f"[red]{msg}[/]")
            sys.exit(1)
    else:
        found = find_manifest(args.dir)
        if not found:
            if not machine_output:
                console.print("[red]No manifest file found.[/] Specify a file or run in a project directory.")
                console.print("[dim]Supported: requirements.txt, package.json, go.mod, Cargo.toml, Gemfile.lock, composer.json[/]")
            else:
                print(json.dumps({"error": "No manifest file found"}))
            sys.exit(1)
        filepaths = [found]

    for fp in filepaths:
        if not os.path.isfile(fp):
            msg = f"File not found: {fp}"
            if machine_output:
                print(json.dumps({"error": msg}))
            else:
                console.print(f"[red]{msg}[/]")
            sys.exit(1)

    # ── Scan all files ────────────────────────────────────────────────
    all_vulns: List[Vuln] = []
    all_errors: List[str] = []
    total_deps = 0
    ecosystems: Set[str] = set()

    for fp in filepaths:
        result = _scan_file(fp, args.ecosystem, quiet=machine_output)
        total_deps += result.total_deps
        all_vulns.extend(result.vulns)
        all_errors.extend(result.query_errors)
        if result.ecosystem:
            ecosystems.add(result.ecosystem)
        if result.error and not machine_output:
            console.print(f"[yellow]⚠ {result.error}[/]")

    eco_label = ", ".join(sorted(ecosystems)) if ecosystems else "unknown"
    combined = ScanResult(
        ecosystem=eco_label,
        total_deps=total_deps,
        vulns=all_vulns,
        query_errors=all_errors,
    )
    combined.vulns.sort(key=lambda v: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}.get(v.severity, 99))

    # ── Apply ignore file ─────────────────────────────────────────────
    ignore_ids = _load_ignore_file(args.ignore_file)
    combined.vulns, ignored_count = _apply_ignore(combined.vulns, ignore_ids)

    # ── Output ────────────────────────────────────────────────────────
    manifest_path = filepaths[0] if len(filepaths) == 1 else args.dir

    if args.sarif_output:
        output_sarif(combined, manifest_path)
    elif args.json_output:
        _output_json(combined, ignored_count)
    else:
        _render_results(combined, verbose=args.verbose, ignored_count=ignored_count)

    # ── Exit code ─────────────────────────────────────────────────────
    if combined.error:
        sys.exit(2)

    if not combined.vulns:
        sys.exit(0)

    fail_map = {"critical": 0, "high": 1, "medium": 2, "low": 3, "any": 4}
    threshold = fail_map.get(args.fail_on, 4)
    severity_levels = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    worst = min(severity_levels.get(v.severity, 99) for v in combined.vulns)

    if worst <= threshold:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
