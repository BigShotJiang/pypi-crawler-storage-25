"""pinaka-scan — Free dependency vulnerability scanner powered by OSV.dev."""
__version__ = "0.3.0"
