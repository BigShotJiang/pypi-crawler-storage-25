"""Core scanner — queries OSV.dev and structures results."""
from __future__ import annotations

import math
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

import requests

OSV_QUERY_URL = "https://api.osv.dev/v1/query"
OSV_BATCH_URL = "https://api.osv.dev/v1/querybatch"
OSV_TIMEOUT = 30
BATCH_SIZE = 1000
MAX_WORKERS = 10

SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}

_SHA_RE = re.compile(r"^[0-9a-f]{7,40}$")

# CVSS v3.x metric value tables (FIRST specification)
_CVSS3_AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}
_CVSS3_AC = {"L": 0.77, "H": 0.44}
_CVSS3_PR_U = {"N": 0.85, "L": 0.62, "H": 0.27}
_CVSS3_PR_C = {"N": 0.85, "L": 0.68, "H": 0.50}
_CVSS3_UI = {"N": 0.85, "R": 0.62}
_CVSS3_CIA = {"H": 0.56, "L": 0.22, "N": 0.0}

_SEVERITY_NORMALIZE = {"MODERATE": "MEDIUM"}


@dataclass
class Vuln:
    package: str
    version: str
    vuln_id: str
    aliases: List[str]
    summary: str
    severity: str
    score: Optional[float]
    fixed_version: Optional[str]
    url: str
    source_file: str = ""


@dataclass
class ScanResult:
    ecosystem: str
    total_deps: int
    vulns: List[Vuln] = field(default_factory=list)
    error: Optional[str] = None
    query_errors: List[str] = field(default_factory=list)

    @property
    def vulnerable_count(self) -> int:
        return len({v.package for v in self.vulns})

    @property
    def counts(self) -> Dict[str, int]:
        c = {"critical": 0, "high": 0, "medium": 0, "low": 0, "unknown": 0}
        for v in self.vulns:
            key = v.severity.lower()
            c[key] = c.get(key, 0) + 1
        return c


# ---------------------------------------------------------------------------
# CVSS v3.1 base score calculator
# ---------------------------------------------------------------------------

def _cvss_v3_base_score(vector: str) -> Optional[float]:
    """Calculate CVSS v3.0/v3.1 base score from a vector string.

    Implements the FIRST specification:
    https://www.first.org/cvss/v3.1/specification-document
    """
    m = re.match(
        r"CVSS:3\.[01]/AV:([NALP])/AC:([LH])/PR:([NLH])/UI:([NR])"
        r"/S:([UC])/C:([HLN])/I:([HLN])/A:([HLN])",
        vector,
    )
    if not m:
        return None

    av, ac, pr, ui, s, c, i, a = m.groups()
    scope_changed = s == "C"

    iss = 1.0 - (1.0 - _CVSS3_CIA[c]) * (1.0 - _CVSS3_CIA[i]) * (1.0 - _CVSS3_CIA[a])

    if iss <= 0:
        return 0.0

    exploitability = (
        8.22
        * _CVSS3_AV[av]
        * _CVSS3_AC[ac]
        * (_CVSS3_PR_C if scope_changed else _CVSS3_PR_U)[pr]
        * _CVSS3_UI[ui]
    )

    if scope_changed:
        impact = 7.52 * (iss - 0.029) - 3.25 * (iss * 0.9731 - 0.02) ** 13
    else:
        impact = 6.42 * iss

    if impact <= 0:
        return 0.0

    if scope_changed:
        base = min(1.08 * (impact + exploitability), 10.0)
    else:
        base = min(impact + exploitability, 10.0)

    return math.ceil(base * 10) / 10


def _parse_cvss_score(vector: str) -> Optional[float]:
    """Extract numeric score from a CVSS vector string or plain number."""
    if not vector:
        return None
    try:
        return float(vector)
    except ValueError:
        pass
    if vector.startswith("CVSS:3."):
        return _cvss_v3_base_score(vector)
    return None


# ---------------------------------------------------------------------------
# Severity & fix extraction
# ---------------------------------------------------------------------------

def _extract_severity(vuln: Dict[str, Any]) -> Tuple[str, Optional[float]]:
    """Extract severity label and optional CVSS score from an OSV record."""
    v3_score: Optional[float] = None
    v4_score: Optional[float] = None

    for entry in vuln.get("severity", []):
        entry_type = entry.get("type", "")
        if entry_type == "CVSS_V3":
            v3_score = _parse_cvss_score(entry.get("score", ""))
        elif entry_type == "CVSS_V4":
            v4_score = _parse_cvss_score(entry.get("score", ""))

    score = v4_score if v4_score is not None else v3_score

    if score is not None:
        if score >= 9.0:
            return "CRITICAL", score
        if score >= 7.0:
            return "HIGH", score
        if score >= 4.0:
            return "MEDIUM", score
        return "LOW", score

    for field_name in ("database_specific", "ecosystem_specific"):
        raw = vuln.get(field_name, {}).get("severity", "")
        if raw:
            label = _SEVERITY_NORMALIZE.get(raw.upper(), raw.upper())
            if label in SEVERITY_ORDER:
                return label, None

    return "UNKNOWN", None


# ---------------------------------------------------------------------------
# Version comparison
# ---------------------------------------------------------------------------

def version_key(v: str) -> Tuple:
    """Sortable key for version strings (exported for use by cli.py)."""
    parts: List[Tuple[int, Any]] = []
    for part in re.split(r"[.\-+]", v):
        try:
            parts.append((0, int(part)))
        except ValueError:
            parts.append((1, part))
    return tuple(parts)


def _best_fix_version(fixes: List[str], current_version: str) -> Optional[str]:
    """Pick the lowest fix version > current_version. Falls back to highest."""
    current_key = version_key(current_version)
    candidates = [f for f in fixes if version_key(f) > current_key]
    if candidates:
        return min(candidates, key=version_key)
    return max(fixes, key=version_key) if fixes else None


# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------

def _collect_ecosystem_fixes(records: List[Dict[str, Any]], pkg: str) -> List[str]:
    """Collect all ECOSYSTEM-range fix versions from a list of OSV records."""
    fixes: List[str] = []
    for record in records:
        for aff in record.get("affected", []):
            aff_name = aff.get("package", {}).get("name", "")
            if aff_name.lower() != pkg.lower() and aff_name != pkg:
                continue
            for rng in aff.get("ranges", []):
                if rng.get("type") != "ECOSYSTEM":
                    continue
                for ev in rng.get("events", []):
                    fixed = ev.get("fixed")
                    if fixed and not _SHA_RE.match(fixed):
                        fixes.append(fixed)
    return fixes


def _dedup_records(
    raw_vulns: List[Dict[str, Any]], pkg_name: str, pkg_version: str,
) -> List[Vuln]:
    """Deduplicate OSV records that refer to the same CVE via union-find."""
    if not raw_vulns:
        return []

    n = len(raw_vulns)
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    id_to_idx: Dict[str, int] = {}
    for i, v in enumerate(raw_vulns):
        all_ids = [v.get("id", "")] + v.get("aliases", [])
        for vid in all_ids:
            if not vid:
                continue
            if vid in id_to_idx:
                union(i, id_to_idx[vid])
            else:
                id_to_idx[vid] = i

    groups: Dict[int, List[int]] = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)

    return [
        _merge_group([raw_vulns[i] for i in indices], pkg_name, pkg_version)
        for indices in groups.values()
    ]


def _merge_group(
    records: List[Dict[str, Any]], pkg_name: str, pkg_version: str,
) -> Vuln:
    """Merge a group of OSV records (same underlying CVE) into one Vuln."""
    all_ids: Set[str] = set()
    for r in records:
        rid = r.get("id", "")
        if rid:
            all_ids.add(rid)
        all_ids.update(r.get("aliases", []))

    cves = sorted(i for i in all_ids if i.startswith("CVE-"))
    ghsas = sorted(i for i in all_ids if i.startswith("GHSA-"))
    vuln_id = cves[0] if cves else ghsas[0] if ghsas else records[0].get("id", "UNKNOWN")
    aliases = sorted(all_ids - {vuln_id})

    best_sev: str = "UNKNOWN"
    best_score: Optional[float] = None
    for r in records:
        sev, score = _extract_severity(r)
        if score is not None:
            if best_score is None or score > best_score:
                best_sev, best_score = sev, score
        elif best_score is None and SEVERITY_ORDER.get(sev, 99) < SEVERITY_ORDER.get(best_sev, 99):
            best_sev = sev

    summary = ""
    for r in records:
        s = r.get("summary", "")
        if len(s) > len(summary):
            summary = s
    if not summary:
        for r in records:
            d = r.get("details", "")
            if d:
                summary = d[:250]
                break
    summary = summary[:250] if summary else "No description available"

    fixes = _collect_ecosystem_fixes(records, pkg_name)
    fixed_version = _best_fix_version(fixes, pkg_version) if fixes else None

    return Vuln(
        package=pkg_name,
        version=pkg_version,
        vuln_id=vuln_id,
        aliases=aliases,
        summary=summary,
        severity=best_sev,
        score=best_score,
        fixed_version=fixed_version,
        url=f"https://osv.dev/vulnerability/{vuln_id}",
    )


# ---------------------------------------------------------------------------
# OSV.dev queries
# ---------------------------------------------------------------------------

def _query_one(
    name: str, version: str, ecosystem: str,
) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    """Query OSV for a single package. Returns (vulns, error_message)."""
    try:
        resp = requests.post(
            OSV_QUERY_URL,
            json={"package": {"name": name, "ecosystem": ecosystem}, "version": version},
            timeout=OSV_TIMEOUT,
            headers={"Content-Type": "application/json"},
        )
        resp.raise_for_status()
        return resp.json().get("vulns", []), None
    except requests.RequestException as exc:
        return [], f"{type(exc).__name__}: {exc}"


def _batch_triage(
    deps: List[Tuple[str, str]], ecosystem: str,
) -> Tuple[Set[int], List[str]]:
    """Batch-query OSV to identify which dep indices have known vulns."""
    vuln_indices: Set[int] = set()
    errors: List[str] = []

    for offset in range(0, len(deps), BATCH_SIZE):
        chunk = deps[offset: offset + BATCH_SIZE]
        queries = [
            {"package": {"name": n, "ecosystem": ecosystem}, "version": v}
            for n, v in chunk
        ]
        try:
            resp = requests.post(
                OSV_BATCH_URL,
                json={"queries": queries},
                timeout=OSV_TIMEOUT,
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
            for i, result in enumerate(resp.json().get("results", [])):
                if result.get("vulns"):
                    vuln_indices.add(offset + i)
        except requests.RequestException as exc:
            errors.append(f"Batch query failed: {exc}")
            for i in range(len(chunk)):
                vuln_indices.add(offset + i)

    return vuln_indices, errors


def scan(deps: List[Tuple[str, str]], ecosystem: str) -> ScanResult:
    """Query OSV.dev for a list of (name, version) tuples. Returns ScanResult."""
    result = ScanResult(ecosystem=ecosystem, total_deps=len(deps))

    if not deps:
        result.error = "No dependencies with version pins found."
        return result

    vuln_indices, batch_errors = _batch_triage(deps, ecosystem)
    result.query_errors.extend(batch_errors)

    if not vuln_indices:
        return result

    targets = [(deps[i][0], deps[i][1]) for i in sorted(vuln_indices) if i < len(deps)]
    pkg_vulns: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}

    with ThreadPoolExecutor(max_workers=min(MAX_WORKERS, len(targets))) as pool:
        futures = {
            pool.submit(_query_one, name, ver, ecosystem): (name, ver)
            for name, ver in targets
        }
        for future in as_completed(futures):
            name, ver = futures[future]
            try:
                vulns, err = future.result()
                if err:
                    result.query_errors.append(f"{name}@{ver}: {err}")
                if vulns:
                    pkg_vulns[(name, ver)] = vulns
            except Exception as exc:
                result.query_errors.append(f"{name}@{ver}: {exc}")

    for (name, ver), raw_vulns in pkg_vulns.items():
        result.vulns.extend(_dedup_records(raw_vulns, name, ver))

    result.vulns.sort(key=lambda v: SEVERITY_ORDER.get(v.severity, 99))
    return result
