"""Tests for .pinaka-ignore support."""
import os

from pinaka_scan.cli import _apply_ignore, _load_ignore_file
from pinaka_scan.scanner import Vuln


def _vuln(vuln_id: str, aliases: list = None) -> Vuln:
    return Vuln("pkg", "1.0", vuln_id, aliases or [], "desc", "HIGH", 7.0, None, "")


def test_load_ignore_file(tmp_path) -> None:
    ignore = tmp_path / ".pinaka-ignore"
    ignore.write_text("# comment\nCVE-2023-111\n\nGHSA-xxxx\n")
    ids = _load_ignore_file(str(ignore))
    assert ids == {"CVE-2023-111", "GHSA-xxxx"}


def test_load_ignore_file_missing() -> None:
    ids = _load_ignore_file("/nonexistent/.pinaka-ignore")
    assert ids == set()


def test_apply_ignore_by_vuln_id() -> None:
    vulns = [_vuln("CVE-2023-111"), _vuln("CVE-2023-222")]
    kept, ignored = _apply_ignore(vulns, {"CVE-2023-111"})
    assert len(kept) == 1
    assert kept[0].vuln_id == "CVE-2023-222"
    assert ignored == 1


def test_apply_ignore_by_alias() -> None:
    vulns = [_vuln("GHSA-aaaa", aliases=["CVE-2023-111"])]
    kept, ignored = _apply_ignore(vulns, {"CVE-2023-111"})
    assert len(kept) == 0
    assert ignored == 1


def test_apply_ignore_empty_set() -> None:
    vulns = [_vuln("CVE-1"), _vuln("CVE-2")]
    kept, ignored = _apply_ignore(vulns, set())
    assert len(kept) == 2
    assert ignored == 0


def test_apply_ignore_no_match() -> None:
    vulns = [_vuln("CVE-2023-111")]
    kept, ignored = _apply_ignore(vulns, {"CVE-9999"})
    assert len(kept) == 1
    assert ignored == 0
