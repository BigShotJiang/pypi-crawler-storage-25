"""Tests for recursive scanning."""
import os

from pinaka_scan.parsers import find_all_manifests, find_manifest


def test_find_all_manifests(tmp_path) -> None:
    (tmp_path / "requirements.txt").write_text("flask==2.0\n")
    sub = tmp_path / "frontend"
    sub.mkdir()
    (sub / "package.json").write_text('{"dependencies": {"express": "4.18.0"}}')
    deep = tmp_path / "services" / "api"
    deep.mkdir(parents=True)
    (deep / "go.mod").write_text("module example.com\nrequire github.com/gin-gonic/gin v1.9.1\n")

    found = find_all_manifests(str(tmp_path))
    basenames = [os.path.basename(f) for f in found]
    assert "requirements.txt" in basenames
    assert "package.json" in basenames
    assert "go.mod" in basenames
    assert len(found) == 3


def test_find_all_manifests_skips_node_modules(tmp_path) -> None:
    (tmp_path / "package.json").write_text('{"dependencies": {}}')
    nm = tmp_path / "node_modules" / "express"
    nm.mkdir(parents=True)
    (nm / "package.json").write_text('{"dependencies": {}}')

    found = find_all_manifests(str(tmp_path))
    assert len(found) == 1


def test_find_all_manifests_skips_venv(tmp_path) -> None:
    (tmp_path / "requirements.txt").write_text("flask==2.0\n")
    venv = tmp_path / ".venv" / "lib"
    venv.mkdir(parents=True)
    (venv / "requirements.txt").write_text("pip==23.0\n")

    found = find_all_manifests(str(tmp_path))
    assert len(found) == 1


def test_find_all_manifests_empty(tmp_path) -> None:
    found = find_all_manifests(str(tmp_path))
    assert found == []


def test_find_manifest_still_works(tmp_path) -> None:
    (tmp_path / "go.mod").write_text("module example.com\n")
    result = find_manifest(str(tmp_path))
    assert result is not None
    assert result.endswith("go.mod")
