"""Tests for pinaka_scan.cli."""
import json
from unittest.mock import patch

import pytest

from pinaka_scan.cli import main
from pinaka_scan.scanner import ScanResult, Vuln


def test_version_flag(capsys: pytest.CaptureFixture) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    assert "pinaka-scan" in capsys.readouterr().out


def test_missing_file_exits_1() -> None:
    with pytest.raises(SystemExit) as exc:
        main(["nonexistent_file.txt"])
    assert exc.value.code == 1


def test_no_manifest_found_exits_1(tmp_path: str) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["-d", str(tmp_path)])
    assert exc.value.code == 1


def test_clean_scan_exits_0(tmp_path: str) -> None:
    req = tmp_path / "requirements.txt"  # type: ignore[operator]
    req.write_text("myprivatepkg==99.99.99\n")

    clean = ScanResult(ecosystem="PyPI", total_deps=1)

    with patch("pinaka_scan.cli.scan", return_value=clean):
        with pytest.raises(SystemExit) as exc:
            main([str(req)])
        assert exc.value.code == 0


def test_vulns_found_exits_1(tmp_path: str) -> None:
    req = tmp_path / "requirements.txt"  # type: ignore[operator]
    req.write_text("django==3.2.0\n")

    result = ScanResult(ecosystem="PyPI", total_deps=1, vulns=[
        Vuln("django", "3.2.0", "CVE-2021-12345", [], "SQL injection", "CRITICAL", 9.8, "3.2.5", ""),
    ])

    with patch("pinaka_scan.cli.scan", return_value=result):
        with pytest.raises(SystemExit) as exc:
            main([str(req)])
        assert exc.value.code == 1


def test_fail_on_critical_skips_high(tmp_path: str) -> None:
    req = tmp_path / "requirements.txt"  # type: ignore[operator]
    req.write_text("django==3.2.0\n")

    result = ScanResult(ecosystem="PyPI", total_deps=1, vulns=[
        Vuln("django", "3.2.0", "CVE-2021-99999", [], "DoS", "HIGH", 7.5, "3.2.5", ""),
    ])

    with patch("pinaka_scan.cli.scan", return_value=result):
        with pytest.raises(SystemExit) as exc:
            main([str(req), "--fail-on", "critical"])
        assert exc.value.code == 0


def test_json_output_valid(tmp_path: str, capsys: pytest.CaptureFixture) -> None:
    req = tmp_path / "requirements.txt"  # type: ignore[operator]
    req.write_text("flask==2.2.0\n")

    result = ScanResult(ecosystem="PyPI", total_deps=1, vulns=[
        Vuln("flask", "2.2.0", "CVE-2023-30861", ["GHSA-xxxx"], "Session cookie issue", "HIGH", 7.5, "2.3.2", ""),
    ])

    with patch("pinaka_scan.cli.scan", return_value=result):
        with pytest.raises(SystemExit):
            main([str(req), "--json"])

    out = capsys.readouterr().out
    data = json.loads(out)
    assert data["total_vulns"] == 1
    assert data["vulnerabilities"][0]["vuln_id"] == "CVE-2023-30861"
