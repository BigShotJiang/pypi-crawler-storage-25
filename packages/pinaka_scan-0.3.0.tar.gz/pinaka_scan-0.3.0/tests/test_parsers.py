"""Tests for pinaka_scan.parsers."""
from pinaka_scan.parsers import (
    detect_ecosystem,
    parse,
    parse_cargo_lock,
    parse_cargo_toml,
    parse_composer_json,
    parse_composer_lock,
    parse_gemfile_lock,
    parse_go_mod,
    parse_go_sum,
    parse_package_json,
    parse_package_lock_json,
    parse_pipfile_lock,
    parse_requirements_txt,
    parse_yarn_lock,
)


# ---------------------------------------------------------------------------
# Ecosystem detection
# ---------------------------------------------------------------------------

def test_detect_ecosystem_by_filename() -> None:
    assert detect_ecosystem("requirements.txt", "") == "PyPI"
    assert detect_ecosystem("package.json", "") == "npm"
    assert detect_ecosystem("go.mod", "") == "Go"
    assert detect_ecosystem("Cargo.toml", "") == "crates.io"
    assert detect_ecosystem("Gemfile.lock", "") == "RubyGems"
    assert detect_ecosystem("composer.json", "") == "Packagist"


def test_detect_ecosystem_by_content() -> None:
    assert detect_ecosystem("deps.txt", '"dependencies": {}') == "npm"
    assert detect_ecosystem("deps.txt", "module example.com/foo") == "Go"
    assert detect_ecosystem("deps.txt", "flask==2.0.0\n") == "PyPI"
    assert detect_ecosystem("deps.txt", "[dependencies]\nfoo = \"1.0\"") == "crates.io"


# ---------------------------------------------------------------------------
# Python parsers
# ---------------------------------------------------------------------------

def test_parse_requirements_txt() -> None:
    content = """\
flask==2.2.0
requests>=2.28.0
# comment
-r base.txt
numpy~=1.21.0
"""
    deps = parse_requirements_txt(content)
    assert ("flask", "2.2.0") in deps
    assert ("requests", "2.28.0") in deps
    assert ("numpy", "1.21.0") in deps
    assert len(deps) == 3


def test_parse_pipfile_lock() -> None:
    content = """\
{
    "_meta": {},
    "default": {
        "flask": {"version": "==2.2.0"},
        "requests": {"version": "==2.28.1"}
    },
    "develop": {
        "pytest": {"version": "==7.4.0"}
    }
}
"""
    deps = parse_pipfile_lock(content)
    assert ("flask", "2.2.0") in deps
    assert ("requests", "2.28.1") in deps
    assert ("pytest", "7.4.0") in deps


# ---------------------------------------------------------------------------
# npm parsers
# ---------------------------------------------------------------------------

def test_parse_package_json() -> None:
    content = """\
{
    "dependencies": {
        "express": "^4.18.0",
        "lodash": "~4.17.21"
    },
    "devDependencies": {
        "jest": ">=29.0.0"
    }
}
"""
    deps = parse_package_json(content)
    assert ("express", "4.18.0") in deps
    assert ("lodash", "4.17.21") in deps
    assert ("jest", "29.0.0") in deps


def test_parse_package_lock_json_v3() -> None:
    content = """\
{
    "lockfileVersion": 3,
    "packages": {
        "": {"name": "myapp"},
        "node_modules/express": {"version": "4.18.2"},
        "node_modules/lodash": {"version": "4.17.21"}
    }
}
"""
    deps = parse_package_lock_json(content)
    assert ("express", "4.18.2") in deps
    assert ("lodash", "4.17.21") in deps
    assert len(deps) == 2


def test_parse_package_lock_json_v1() -> None:
    content = """\
{
    "lockfileVersion": 1,
    "dependencies": {
        "express": {"version": "4.18.2"},
        "body-parser": {
            "version": "1.20.0",
            "dependencies": {
                "debug": {"version": "2.6.9"}
            }
        }
    }
}
"""
    deps = parse_package_lock_json(content)
    assert ("express", "4.18.2") in deps
    assert ("body-parser", "1.20.0") in deps
    assert ("debug", "2.6.9") in deps


def test_parse_yarn_lock() -> None:
    content = """\
# yarn lockfile v1

"@babel/core@^7.0.0":
  version "7.23.0"
  resolved "https://registry.yarnpkg.com/..."

express@^4.18.0:
  version "4.18.2"
  resolved "https://registry.yarnpkg.com/..."
"""
    deps = parse_yarn_lock(content)
    assert ("@babel/core", "7.23.0") in deps
    assert ("express", "4.18.2") in deps


# ---------------------------------------------------------------------------
# Go parsers
# ---------------------------------------------------------------------------

def test_parse_go_mod() -> None:
    content = """\
module example.com/mymod

go 1.21

require (
\tgolang.org/x/crypto v0.17.0
\tgithub.com/gin-gonic/gin v1.9.1
)

require github.com/stretchr/testify v1.8.4
"""
    deps = parse_go_mod(content)
    assert ("golang.org/x/crypto", "0.17.0") in deps
    assert ("github.com/gin-gonic/gin", "1.9.1") in deps
    assert ("github.com/stretchr/testify", "1.8.4") in deps


def test_parse_go_sum() -> None:
    content = """\
golang.org/x/crypto v0.17.0 h1:abc123=
golang.org/x/crypto v0.17.0/go.mod h1:def456=
github.com/gin-gonic/gin v1.9.1 h1:xyz=
"""
    deps = parse_go_sum(content)
    assert ("golang.org/x/crypto", "0.17.0") in deps
    assert ("github.com/gin-gonic/gin", "1.9.1") in deps
    assert len(deps) == 2  # go.mod entry deduplicated


# ---------------------------------------------------------------------------
# Rust parsers
# ---------------------------------------------------------------------------

def test_parse_cargo_toml_simple() -> None:
    content = """\
[package]
name = "myapp"
version = "0.1.0"

[dependencies]
serde = "1.0"
tokio = "1.28"

[dev-dependencies]
criterion = "0.5"
"""
    deps = parse_cargo_toml(content)
    assert ("serde", "1.0") in deps
    assert ("tokio", "1.28") in deps
    assert ("criterion", "0.5") in deps


def test_parse_cargo_toml_inline_table() -> None:
    content = """\
[dependencies]
serde = { version = "1.0", features = ["derive"] }
tokio = { version = "1.28", features = ["full"] }
simple = "0.5"
"""
    deps = parse_cargo_toml(content)
    assert ("serde", "1.0") in deps
    assert ("tokio", "1.28") in deps
    assert ("simple", "0.5") in deps


def test_parse_cargo_lock() -> None:
    content = """\
[[package]]
name = "serde"
version = "1.0.193"

[[package]]
name = "tokio"
version = "1.35.0"
"""
    deps = parse_cargo_lock(content)
    assert ("serde", "1.0.193") in deps
    assert ("tokio", "1.35.0") in deps


# ---------------------------------------------------------------------------
# Ruby
# ---------------------------------------------------------------------------

def test_parse_gemfile_lock() -> None:
    content = """\
GEM
  remote: https://rubygems.org/
  specs:
    actioncable (7.0.8)
    rails (7.0.8)
      actioncable (= 7.0.8)

PLATFORMS
  ruby
"""
    deps = parse_gemfile_lock(content)
    assert ("actioncable", "7.0.8") in deps
    assert ("rails", "7.0.8") in deps


# ---------------------------------------------------------------------------
# PHP
# ---------------------------------------------------------------------------

def test_parse_composer_json() -> None:
    content = """\
{
    "require": {
        "php": ">=8.1",
        "laravel/framework": "^10.0",
        "ext-json": "*"
    },
    "require-dev": {
        "phpunit/phpunit": "^10.0"
    }
}
"""
    deps = parse_composer_json(content)
    names = [d[0] for d in deps]
    assert "laravel/framework" in names
    assert "phpunit/phpunit" in names
    assert "php" not in names
    assert "ext-json" not in names


def test_parse_composer_lock() -> None:
    content = """\
{
    "packages": [
        {"name": "laravel/framework", "version": "v10.0.0"},
        {"name": "guzzlehttp/guzzle", "version": "v7.8.0"}
    ],
    "packages-dev": [
        {"name": "phpunit/phpunit", "version": "v10.5.0"}
    ]
}
"""
    deps = parse_composer_lock(content)
    assert ("laravel/framework", "10.0.0") in deps
    assert ("guzzlehttp/guzzle", "7.8.0") in deps
    assert ("phpunit/phpunit", "10.5.0") in deps


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def test_parse_dispatches_by_filename() -> None:
    plock = '{"default": {"flask": {"version": "==2.0"}}}'
    deps = parse(plock, "PyPI", "Pipfile.lock")
    assert ("flask", "2.0") in deps


def test_parse_falls_back_to_ecosystem() -> None:
    content = "flask==2.0.0\n"
    deps = parse(content, "PyPI")
    assert ("flask", "2.0.0") in deps
