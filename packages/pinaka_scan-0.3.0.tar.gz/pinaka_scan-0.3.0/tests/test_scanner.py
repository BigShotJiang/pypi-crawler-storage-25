"""Tests for pinaka_scan.scanner."""
from unittest.mock import patch

from pinaka_scan.scanner import (
    ScanResult,
    Vuln,
    _cvss_v3_base_score,
    _dedup_records,
    _extract_severity,
    _merge_group,
    _parse_cvss_score,
    version_key,
    _best_fix_version,
    _collect_ecosystem_fixes,
)


# ---------------------------------------------------------------------------
# CVSS v3.1 calculator
# ---------------------------------------------------------------------------

def test_cvss_v3_critical() -> None:
    vector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
    score = _cvss_v3_base_score(vector)
    assert score is not None
    assert score == 9.8


def test_cvss_v3_high() -> None:
    vector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H"
    score = _cvss_v3_base_score(vector)
    assert score is not None
    assert 7.0 <= score < 9.0


def test_cvss_v3_medium() -> None:
    vector = "CVSS:3.1/AV:N/AC:L/PR:H/UI:N/S:U/C:H/I:N/A:N"
    score = _cvss_v3_base_score(vector)
    assert score is not None
    assert 4.0 <= score < 7.0


def test_cvss_v3_scope_changed() -> None:
    vector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H"
    score = _cvss_v3_base_score(vector)
    assert score is not None
    assert score == 10.0


def test_cvss_v3_zero_impact() -> None:
    vector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:N"
    score = _cvss_v3_base_score(vector)
    assert score == 0.0


def test_cvss_v3_invalid_vector() -> None:
    assert _cvss_v3_base_score("not-a-vector") is None
    assert _cvss_v3_base_score("CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N") is None


def test_parse_cvss_score_numeric() -> None:
    assert _parse_cvss_score("9.8") == 9.8
    assert _parse_cvss_score("7.5") == 7.5


def test_parse_cvss_score_vector() -> None:
    score = _parse_cvss_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H")
    assert score == 9.8


def test_parse_cvss_score_empty() -> None:
    assert _parse_cvss_score("") is None
    assert _parse_cvss_score(None) is None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Severity extraction
# ---------------------------------------------------------------------------

def test_extract_severity_from_cvss() -> None:
    vuln = {
        "severity": [
            {"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}
        ]
    }
    sev, score = _extract_severity(vuln)
    assert sev == "CRITICAL"
    assert score == 9.8


def test_extract_severity_from_database_specific() -> None:
    vuln = {"database_specific": {"severity": "HIGH"}}
    sev, score = _extract_severity(vuln)
    assert sev == "HIGH"
    assert score is None


def test_extract_severity_moderate_normalized() -> None:
    vuln = {"database_specific": {"severity": "MODERATE"}}
    sev, _ = _extract_severity(vuln)
    assert sev == "MEDIUM"


def test_extract_severity_unknown_fallback() -> None:
    vuln = {}
    sev, score = _extract_severity(vuln)
    assert sev == "UNKNOWN"
    assert score is None


# ---------------------------------------------------------------------------
# Version comparison
# ---------------------------------------------------------------------------

def test_version_key_ordering() -> None:
    versions = ["1.2.3", "1.10.0", "1.2.10", "2.0.0"]
    assert sorted(versions, key=version_key) == ["1.2.3", "1.2.10", "1.10.0", "2.0.0"]


def test_best_fix_version() -> None:
    fixes = ["2.2.28", "3.2.5", "3.2.14", "4.0.4"]
    assert _best_fix_version(fixes, "3.2.0") == "3.2.5"


def test_best_fix_version_fallback() -> None:
    fixes = ["1.0.1", "1.0.2"]
    assert _best_fix_version(fixes, "2.0.0") == "1.0.2"


# ---------------------------------------------------------------------------
# Fix collection
# ---------------------------------------------------------------------------

def test_collect_ecosystem_fixes() -> None:
    records = [
        {
            "affected": [{
                "package": {"name": "django"},
                "ranges": [
                    {
                        "type": "ECOSYSTEM",
                        "events": [{"introduced": "3.2"}, {"fixed": "3.2.5"}],
                    },
                    {
                        "type": "GIT",
                        "events": [{"fixed": "abc123def456"}],
                    },
                ],
            }]
        }
    ]
    fixes = _collect_ecosystem_fixes(records, "django")
    assert fixes == ["3.2.5"]


def test_collect_ecosystem_fixes_filters_shas() -> None:
    records = [
        {
            "affected": [{
                "package": {"name": "django"},
                "ranges": [{
                    "type": "ECOSYSTEM",
                    "events": [{"fixed": "abcdef1234567890abcdef1234567890abcdef12"}],
                }],
            }]
        }
    ]
    fixes = _collect_ecosystem_fixes(records, "django")
    assert fixes == []


# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------

def test_dedup_merges_ghsa_and_pysec() -> None:
    ghsa = {
        "id": "GHSA-xxxx-xxxx-xxxx",
        "aliases": ["CVE-2023-12345", "PYSEC-2023-100"],
        "severity": [
            {"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}
        ],
        "database_specific": {"severity": "CRITICAL"},
        "summary": "A critical vulnerability",
        "affected": [{
            "package": {"name": "django"},
            "ranges": [{"type": "ECOSYSTEM", "events": [{"introduced": "3.2"}, {"fixed": "3.2.14"}]}],
        }],
    }
    pysec = {
        "id": "PYSEC-2023-100",
        "aliases": ["CVE-2023-12345", "GHSA-xxxx-xxxx-xxxx"],
        "severity": [],
        "database_specific": {},
        "summary": "",
        "affected": [{
            "package": {"name": "django"},
            "ranges": [{"type": "ECOSYSTEM", "events": [{"introduced": "3.2"}, {"fixed": "3.2.14"}]}],
        }],
    }

    vulns = _dedup_records([ghsa, pysec], "django", "3.2.0")
    assert len(vulns) == 1

    v = vulns[0]
    assert v.vuln_id == "CVE-2023-12345"
    assert v.severity == "CRITICAL"
    assert v.score == 9.8
    assert v.fixed_version == "3.2.14"
    assert "GHSA-xxxx-xxxx-xxxx" in v.aliases
    assert "PYSEC-2023-100" in v.aliases


def test_dedup_keeps_distinct_cves() -> None:
    vuln_a = {
        "id": "GHSA-aaaa",
        "aliases": ["CVE-2023-111"],
        "severity": [],
        "database_specific": {"severity": "HIGH"},
        "summary": "Vuln A",
        "affected": [],
    }
    vuln_b = {
        "id": "GHSA-bbbb",
        "aliases": ["CVE-2023-222"],
        "severity": [],
        "database_specific": {"severity": "LOW"},
        "summary": "Vuln B",
        "affected": [],
    }

    vulns = _dedup_records([vuln_a, vuln_b], "pkg", "1.0.0")
    assert len(vulns) == 2


# ---------------------------------------------------------------------------
# ScanResult properties
# ---------------------------------------------------------------------------

def test_scan_result_counts() -> None:
    result = ScanResult(ecosystem="PyPI", total_deps=5, vulns=[
        Vuln("a", "1.0", "CVE-1", [], "", "CRITICAL", 9.8, None, ""),
        Vuln("b", "1.0", "CVE-2", [], "", "HIGH", 7.5, None, ""),
        Vuln("c", "1.0", "CVE-3", [], "", "MEDIUM", 5.0, None, ""),
        Vuln("d", "1.0", "CVE-4", [], "", "LOW", 2.0, None, ""),
    ])
    assert result.counts == {"critical": 1, "high": 1, "medium": 1, "low": 1, "unknown": 0}
    assert result.vulnerable_count == 4
