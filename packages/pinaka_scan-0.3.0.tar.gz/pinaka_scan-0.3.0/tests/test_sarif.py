"""Tests for SARIF output."""
from pinaka_scan.sarif import to_sarif
from pinaka_scan.scanner import ScanResult, Vuln


def _make_result() -> ScanResult:
    return ScanResult(
        ecosystem="PyPI",
        total_deps=3,
        vulns=[
            Vuln("django", "3.2.0", "CVE-2022-28346", ["GHSA-xxxx"], "SQL injection", "CRITICAL", 9.8, "3.2.13", "https://osv.dev/vulnerability/CVE-2022-28346"),
            Vuln("flask", "2.2.0", "CVE-2023-30861", [], "Session cookie issue", "HIGH", 7.5, "2.3.2", "https://osv.dev/vulnerability/CVE-2023-30861"),
        ],
    )


def test_sarif_schema_version() -> None:
    doc = to_sarif(_make_result(), "requirements.txt")
    assert doc["version"] == "2.1.0"
    assert "$schema" in doc


def test_sarif_has_runs() -> None:
    doc = to_sarif(_make_result(), "requirements.txt")
    assert len(doc["runs"]) == 1
    run = doc["runs"][0]
    assert run["tool"]["driver"]["name"] == "pinaka-scan"


def test_sarif_rules_match_results() -> None:
    doc = to_sarif(_make_result(), "requirements.txt")
    run = doc["runs"][0]
    rules = run["tool"]["driver"]["rules"]
    results = run["results"]
    assert len(rules) == 2
    assert len(results) == 2
    rule_ids = {r["id"] for r in rules}
    assert "CVE-2022-28346" in rule_ids
    assert "CVE-2023-30861" in rule_ids


def test_sarif_severity_mapping() -> None:
    doc = to_sarif(_make_result(), "requirements.txt")
    results = doc["runs"][0]["results"]
    assert results[0]["level"] == "error"  # CRITICAL
    assert results[1]["level"] == "error"  # HIGH


def test_sarif_medium_is_warning() -> None:
    result = ScanResult(ecosystem="PyPI", total_deps=1, vulns=[
        Vuln("pkg", "1.0", "CVE-X", [], "desc", "MEDIUM", 5.0, None, ""),
    ])
    doc = to_sarif(result, "req.txt")
    assert doc["runs"][0]["results"][0]["level"] == "warning"


def test_sarif_low_is_note() -> None:
    result = ScanResult(ecosystem="PyPI", total_deps=1, vulns=[
        Vuln("pkg", "1.0", "CVE-Y", [], "desc", "LOW", 2.0, None, ""),
    ])
    doc = to_sarif(result, "req.txt")
    assert doc["runs"][0]["results"][0]["level"] == "note"


def test_sarif_artifact_location() -> None:
    doc = to_sarif(_make_result(), "requirements.txt")
    loc = doc["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["artifactLocation"]
    assert loc["uri"] == "requirements.txt"


def test_sarif_source_file_override() -> None:
    result = ScanResult(ecosystem="PyPI", total_deps=1, vulns=[
        Vuln("pkg", "1.0", "CVE-Z", [], "desc", "HIGH", 7.0, None, "", source_file="sub/requirements.txt"),
    ])
    doc = to_sarif(result, ".")
    loc = doc["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["artifactLocation"]
    assert loc["uri"] == "sub/requirements.txt"


def test_sarif_properties() -> None:
    doc = to_sarif(_make_result(), "requirements.txt")
    props = doc["runs"][0]["results"][0]["properties"]
    assert props["cvssScore"] == 9.8
    assert props["fixedVersion"] == "3.2.13"
    assert "GHSA-xxxx" in props["aliases"]


def test_sarif_empty_results() -> None:
    result = ScanResult(ecosystem="PyPI", total_deps=5)
    doc = to_sarif(result, "req.txt")
    assert doc["runs"][0]["results"] == []
    assert doc["runs"][0]["tool"]["driver"]["rules"] == []
