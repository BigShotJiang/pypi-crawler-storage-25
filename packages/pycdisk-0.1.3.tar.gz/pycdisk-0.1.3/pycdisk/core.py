from . import _core

class PyCDisk:
    def __init__(self):
        self._manager = _core.DiskManager()

    def list_disks(self):
        """Возвращает список доступных физических дисков."""
        return self._manager.list_disks()

    def initialize(self, disk_number: int, scheme: str = "GPT"):
        """Инициализирует диск с выбранной схемой (MBR или GPT)."""
        s = _core.PartitionScheme.GPT if scheme.upper() == "GPT" else _core.PartitionScheme.MBR
        return self._manager.initialize_disk(disk_number, s)

    def create_partition(self, disk_number: int, size_gb: float):
        """Создает раздел указанного размера в ГБ."""
        size_bytes = int(size_gb * 1024 * 1024 * 1024)
        return self._manager.create_partition(disk_number, size_bytes)

    def burn_iso(self, disk_number: int, iso_path: str, target: str = "UEFI"):
        """Записывает ISO образ на диск с учетом целевой системы (BIOS или UEFI)."""
        t = _core.TargetSystem.UEFI if target.upper() == "UEFI" else _core.TargetSystem.BIOS
        return self._manager.write_iso(disk_number, iso_path, t)
