"""flopsindex consumer SDK — read-side client for the FLOPS API.

Architecture:
  - All methods are synchronous (most consumers are scripts /
    notebooks / finance pipelines, not async services). An async
    wrapper can be added in v0.2 without breaking the sync surface.
  - HTTP via stdlib `urllib` so the SDK has ZERO third-party
    dependencies for the basic read path. `httpx` would be nicer
    but locks consumers into a specific async runtime.
  - API key resolved from constructor → FLOPSINDEX_API_KEY env var.
  - Public-surface methods (price / timeseries / search / methodology)
    work without an API key.
  - Partner-tier methods (catalog / compute_margin / recompute_audit /
    indices) require an API key; raise FlopsAuthError if missing.
"""
from __future__ import annotations

import json
import logging
import os
import time
import urllib.parse
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional, Union

from flopsindex.exceptions import (
    FlopsAuthError,
    FlopsError,
    FlopsNotFoundError,
    FlopsRateLimitError,
    FlopsServerError,
)

logger = logging.getLogger("flopsindex")

_DEFAULT_BASE_URL = "https://app.flopsindex.com"
_DEFAULT_TIMEOUT = 30
_USER_AGENT_TEMPLATE = "flopsindex/{version} (+https://flopsindex.com)"


class Client:
    """The FLOPS API consumer client.

    Most users want the no-arg form::

        from flopsindex import Client
        c = Client()  # FLOPSINDEX_API_KEY from env

    Override base_url to hit a staging instance::

        c = Client(base_url="https://staging.flopsindex.com")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: int = _DEFAULT_TIMEOUT,
        user_agent: Optional[str] = None,
    ):
        self._api_key = api_key or os.environ.get("FLOPSINDEX_API_KEY")
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        # Lazy import to avoid circular ref
        from flopsindex import __version__ as _v
        self._user_agent = user_agent or _USER_AGENT_TEMPLATE.format(version=_v)

    # -----------------------------------------------------------------
    # PUBLIC (auth-free) — works without an API key
    # -----------------------------------------------------------------

    def price(self, index_id: str) -> Dict[str, Any]:
        """Latest published price for one SPOT index. Auth-free.

        Returns ``{index_id, value, unit, ts, tier, confidence,
        verify_url, citation_url}``.

        Raises FlopsNotFoundError if the slug is unknown or is not on
        the public spot surface (forwards / derived stay partner-tier).
        """
        return self._get(f"/v1/price/{urllib.parse.quote(index_id, safe='')}",
                         require_auth=False)

    def timeseries(self, index_id: str, range: str = "7d") -> Dict[str, Any]:
        """Decimated timeseries (≤200 points). Auth-free.

        ``range`` ∈ {"24h", "7d", "30d", "90d", "1y"}.
        """
        return self._get(
            f"/v1/ts/{urllib.parse.quote(index_id, safe='')}",
            params={"range": range}, require_auth=False,
        )

    def search(self, q: str, limit: int = 10) -> Dict[str, Any]:
        """Natural-language → canonical index_id. Auth-free.

        Returns ``{q, count, results: [{index_id, family,
        citation_url}, ...]}``.
        """
        return self._get("/v1/search",
                         params={"q": q, "limit": str(limit)},
                         require_auth=False)

    def methodology(
        self, slug: str, version: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Versioned methodology document (with parsed frontmatter).

        Auth-free. If ``version`` is None, returns the version history
        list. Otherwise returns the doc with body_md + frontmatter.

        ``slug`` is the lower-kebab methodology_id (e.g. "flci-h100",
        "itpi-canonical", "flops-h100-od").
        """
        if version is None:
            return self._get(
                f"/v1/methodology/{urllib.parse.quote(slug)}/versions",
                require_auth=False)
        return self._get(
            f"/v1/methodology/{urllib.parse.quote(slug)}/"
            f"{urllib.parse.quote(version)}.json",
            require_auth=False)

    def methodologies(self) -> Dict[str, Any]:
        """List every published methodology + active version. Auth-free."""
        return self._get("/v1/methodology", require_auth=False)

    def verify(self, index_id: str, value: float) -> Dict[str, Any]:
        """Verify whether the given value matches our latest published
        tick for the index_id (within tolerance). Auth-free citation
        check. Raises on non-2xx upstream — use ``verify_handshake`` if
        you want a defensive envelope instead."""
        return self._get(
            "/v1/verify",
            params={"index_id": index_id, "value": str(value)},
            require_auth=False)

    def verify_handshake(
        self,
        index_id: str,
        value: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Defensive verify — returns either the canonical record OR a
        structured ``{ok: false, reason, upstream_status}`` envelope on
        any non-2xx response. Never raises for HTTP errors.

        This is the citation handshake idiom Track D promotes::

            tick = client.price("FLCI-H100")
            check = client.verify_handshake("FLCI-H100", tick["value"])
            if check.get("ok") is False:
                # upstream broken / endpoint pending — caller decides
                ...
            elif check.get("verified"):
                cite(tick, source_url=check["source_url"])

        Mirrors the MCP server's ``_defensive_get`` shape so an agent
        switching between MCP and direct SDK gets the same error envelope.

        ``value`` is optional — omit to ask "what's the latest tick"
        without committing a value to verify against.
        """
        params: Dict[str, str] = {"index_id": index_id}
        if value is not None:
            params["value"] = str(value)
        url = self._base_url + "/v1/verify?" + urllib.parse.urlencode(params)
        headers = {"User-Agent": self._user_agent, "Accept": "application/json"}
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                body = resp.read().decode("utf-8")
                try:
                    return json.loads(body)
                except ValueError:
                    return {"ok": False, "reason": "invalid_json",
                            "upstream_status": resp.status, "url": url}
        except urllib.error.HTTPError as e:
            code = e.code
            if code in (401, 403):
                return {"ok": False, "reason": "auth_required",
                        "upstream_status": code, "url": url}
            if code == 404:
                return {"ok": False, "reason": "endpoint_pending",
                        "upstream_status": code, "url": url}
            if code >= 500:
                return {"ok": False, "reason": "upstream_http_error",
                        "upstream_status": code, "url": url}
            return {"ok": False, "reason": "client_error",
                    "upstream_status": code, "url": url}
        except urllib.error.URLError as exc:
            return {"ok": False, "reason": "network_error",
                    "url": url, "detail": str(exc.reason)[:300]}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "reason": "network_error",
                    "url": url, "detail": str(exc)[:300]}

    # -----------------------------------------------------------------
    # PARTNER-TIER (X-FLOPS-Api-Key required)
    # -----------------------------------------------------------------

    def catalog(self) -> Dict[str, Any]:
        """Full index catalog with methodology_version stamps + tier
        labels. Partner-tier — requires API key.

        For an auth-free subset filtered to spot only, use the public
        catalog mirror at GET /v2/catalog/public (no SDK method —
        agents discover via /llms.txt).
        """
        return self._get("/v1/catalog", require_auth=True)

    def index_current(self, index_id: str) -> Dict[str, Any]:
        """Partner-tier per-index lookup with full envelope (value,
        as_of, num_sources, data_tier, methodology_version,
        verify_url). Returns 404 for unknown index_ids; differs from
        ``price()`` in that the partner-tier surface knows about
        non-spot families (forwards, derived, etc.) too."""
        return self._get(
            f"/v1/indices/{urllib.parse.quote(index_id, safe='')}/current",
            require_auth=True)

    def index_history(
        self, index_id: str, limit: int = 24,
    ) -> Dict[str, Any]:
        """Partner-tier per-index history. ``limit`` capped at 720."""
        return self._get(
            f"/v1/indices/{urllib.parse.quote(index_id, safe='')}/history",
            params={"limit": str(min(limit, 720))},
            require_auth=True)

    def compute_margin(
        self, sku: str, region: str = "us_east",
        pue: float = 1.3, kwh_source: str = "live_lmp",
        kwh_override: Optional[float] = None,
        rack_amortization: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Compute-margin endpoint (Tier 2 #5). Partner-tier.

        Returns the full margin decomposition:
          {price, power_cost, rack_amortization, margin, margin_pct,
          inputs: {chip_power_kw, pue, kwh_source, kwh_usd, ...}}
        """
        params = {"sku": sku, "region": region,
                  "pue": str(pue), "kwh_source": kwh_source}
        if kwh_override is not None:
            params["kwh_override"] = str(kwh_override)
        if rack_amortization is not None:
            params["rack_amortization"] = str(rack_amortization)
        return self._get("/v1/derived/compute-margin",
                         params=params, require_auth=True)

    def recompute_audit(
        self,
        methodology_id: Optional[str] = None,
        index_id: Optional[str] = None,
        status: Optional[str] = None,
        since_hours: int = 168,
        limit: int = 100,
    ) -> Dict[str, Any]:
        """Recompute audit receipts (Tier 2 #4). Partner-tier.

        Returns ``{count, receipts: [...]}`` with each receipt
        carrying methodology_version, window, shipped vs recomputed
        values, variance_bps, inputs_hash + receipt_hash for
        external citation.
        """
        params: Dict[str, str] = {"since_hours": str(since_hours),
                                  "limit": str(limit)}
        if methodology_id:
            params["methodology_id"] = methodology_id
        if index_id:
            params["index_id"] = index_id
        if status:
            params["status"] = status
        return self._get("/v1/audit/recompute",
                         params=params, require_auth=True)

    def gpu_capex(self, sku: Optional[str] = None) -> Dict[str, Any]:
        """Per-SKU GPU module reference price — 3-tier LIVE cascade.

        Cascade per SKU:
          T2 LIVE_USASPENDING — federal procurement median (real new),
                                preferred when >=3 awards in 180d
          T1 LIVE_EBAY_X1.15  — eBay completed-listings trimmed-median × 1.15
          T3 SEED             — quarterly reference fallback

        Returns the single-SKU envelope (price_usd, tier, source,
        effective, secondary_market_range_usd, plus live_observations +
        also_seed when LIVE). With ``sku=None`` returns the full seed
        map with meta.live_api_status.

        No auth required. Methodology:
        https://app.flopsindex.com/methodology/GPU_CAPEX_LIVE_METHODOLOGY.md

        NOTE: there is no public LIVE MSRP API for datacenter GPUs —
        NVIDIA/AMD/Huawei are channel-priced through OEMs. The LIVE
        tiers here are federal-procurement (T2) or secondary-market ×
        markup (T1), not chip-new MSRP.
        """
        if sku:
            return self._get(f"/v1/refdata/gpu-capex/{sku}", require_auth=False)
        return self._get("/v1/refdata/gpu-capex", require_auth=False)

    def gpu_capex_observations(
        self,
        sku: str,
        limit: int = 50,
    ) -> Dict[str, Any]:
        """Audit-trail surface — raw gpu_capex_observations rows for a SKU.

        Returns the rows that feed the LIVE-tier cascade — partners +
        auditors can drill from a published LIVE value back to the
        underlying federal-contract / eBay-listing records.

        Returns ``{sku, count, limit, rows, by_source, methodology}``.
        Limit clamped server-side to [1, 500]. No auth required;
        503 if migration 012 hasn't been applied to this Neon branch.
        """
        return self._get(
            f"/v1/refdata/gpu-capex/{sku}/observations",
            params={"limit": str(int(limit))},
            require_auth=False,
        )

    # -----------------------------------------------------------------
    # HTTP plumbing
    # -----------------------------------------------------------------

    def _get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, str]] = None,
        require_auth: bool = False,
    ) -> Dict[str, Any]:
        url = self._base_url + path
        if params:
            url += "?" + urllib.parse.urlencode(params)

        headers = {"User-Agent": self._user_agent, "Accept": "application/json"}
        if require_auth:
            if not self._api_key:
                raise FlopsAuthError(
                    f"{path} requires an API key. Set FLOPSINDEX_API_KEY "
                    f"or pass api_key= to Client()."
                )
            headers["X-FLOPS-Api-Key"] = self._api_key
        elif self._api_key:
            # Send the key on public paths too — gives the server
            # higher rate-limit allowance for keyed callers.
            headers["X-FLOPS-Api-Key"] = self._api_key

        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body)
        except urllib.error.HTTPError as e:
            self._raise_for_status(e.code, e.read().decode("utf-8", "replace"),
                                   e.headers)
        except urllib.error.URLError as e:
            raise FlopsError(f"network error: {e.reason}")
        # unreachable
        raise FlopsError(f"unexpected: {path}")

    def _raise_for_status(
        self, status_code: int, body: str, headers,
    ) -> None:
        try:
            detail = json.loads(body)
        except Exception:
            detail = body
        msg = f"HTTP {status_code}"
        if isinstance(detail, dict) and "detail" in detail:
            msg += f": {detail['detail']}"
        if status_code in (401, 403):
            raise FlopsAuthError(msg, status_code=status_code, detail=detail)
        if status_code == 404:
            raise FlopsNotFoundError(msg, status_code=status_code, detail=detail)
        if status_code == 429:
            retry_after = 60
            try:
                retry_after = int(headers.get("Retry-After", "60"))
            except (ValueError, TypeError, AttributeError):
                pass
            raise FlopsRateLimitError(msg, retry_after_seconds=retry_after,
                                      status_code=status_code, detail=detail)
        if 500 <= status_code < 600:
            raise FlopsServerError(msg, status_code=status_code, detail=detail)
        raise FlopsError(msg, status_code=status_code, detail=detail)
