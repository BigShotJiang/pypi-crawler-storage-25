"""flopsindex — Python SDK for the FLOPS Compute Intelligence API.

```python
from flopsindex import Client

c = Client()  # auth from FLOPSINDEX_API_KEY env var
tick = c.price("FLCI-H100")              # current price
hist = c.timeseries("FLCI-H100", "7d")  # 7-day decimated timeseries
matches = c.search("h100 spot")          # NL → index_id
catalog = c.catalog()                    # full catalog (partner-tier)
doc = c.methodology("flci-h100", "v0.9") # raw methodology markdown
margin = c.compute_margin(sku="h100_sxm5", region="us_west")
```

The public surface is auth-free (price / timeseries / search /
methodology) — those work without an API key. catalog +
compute_margin + recompute_audit need a key.

Set the key via:
  - `FLOPSINDEX_API_KEY` env var (recommended)
  - `Client(api_key="flops_xxx")` constructor
"""
from flopsindex.client import Client
from flopsindex.exceptions import (
    FlopsError,
    FlopsAuthError,
    FlopsNotFoundError,
    FlopsRateLimitError,
)

__version__ = "0.6.0"
__all__ = [
    "Client",
    "FlopsError",
    "FlopsAuthError",
    "FlopsNotFoundError",
    "FlopsRateLimitError",
    "__version__",
]
