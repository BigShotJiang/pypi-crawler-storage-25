from dataclasses import dataclass


@dataclass
class CoordinatesBean:
	lon: float
	lat: float
