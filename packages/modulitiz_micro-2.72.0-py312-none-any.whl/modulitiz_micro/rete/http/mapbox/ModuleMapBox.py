from modulitiz_micro.rete.http.mapbox.inner.directions.ModuleMapBoxDirections import ModuleMapBoxDirections


class ModuleMapBox(object):
	"""
	Docs: https://docs.mapbox.com/api/guides/
	"""
	
	T="pk.eyJ1IjoiZ2F4ZWs5ODk5OCIsImEiOiJjbW9qdDA0bnEwMmY5MnFzYnZyZDEwOWk3In0.iN8xqP-JQZ0hYjbTA0xL6Q"
	
	def __init__(self,*args,**kwargs):
		self.directions=ModuleMapBoxDirections(*args,**kwargs)
