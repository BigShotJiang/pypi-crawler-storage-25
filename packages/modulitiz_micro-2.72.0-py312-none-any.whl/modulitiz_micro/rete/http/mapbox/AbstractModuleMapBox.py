import json
from abc import ABC
from abc import abstractmethod

from modulitiz_micro.exceptions.http.ExceptionHttpGeneric import ExceptionHttpGeneric
from modulitiz_micro.rete.http.ModuloHttp import ModuloHttp
from modulitiz_nano.files.ModuloLogging import ModuloLogging


class AbstractModuleMapBox(ABC):
	BASE_URL="https://api.mapbox.com/"
	
	def __init__(self, contextUrl:str,token:str,logger:ModuloLogging):
		self.contextUrl=contextUrl
		self._token = token
		self._logger=logger
		url=f"{self.BASE_URL}{contextUrl}?access_token={token}"
		self._moduleHttp=ModuloHttp(url,logger,False)
		self.countRequestsTotal=0
	
	@abstractmethod
	def get(self,*_args,**_kwargs) -> dict:
		"""
		Stub
		"""
	
	def _get(self,postData:dict)->dict:
		"""
		Can't use cache because input type dict is not hashable
		"""
		responseBean=self._moduleHttp.doPost(postData,False,0)
		if responseBean.status!=ModuloHttp.STATUS_OK:
			raise ExceptionHttpGeneric()
		responseText=responseBean.responseBody.decode()
		self.countRequestsTotal+=1
		return json.loads(responseText)
