from typing import override

from modulitiz_micro.rete.http.mapbox.AbstractModuleMapBox import AbstractModuleMapBox
from modulitiz_micro.rete.http.mapbox.inner.directions.beans.HighTrafficPointBean import HighTrafficPointBean
from modulitiz_micro.util.beans.CoordinatesBean import CoordinatesBean
from modulitiz_nano.ModuloListe import ModuloListe


class ModuleMapBoxDirections(AbstractModuleMapBox):
	"""
	Docs: https://docs.mapbox.com/api/navigation/directions/
	"""
	
	def __init__(self,*args,**kwargs):
		super().__init__("directions/v5/mapbox/driving-traffic",*args,**kwargs)
	
	@override
	def get(self,coordinates:list[CoordinatesBean])->dict:
		coordinatesStr=";".join(["%f,%f"%(x.lon,x.lat) for x in coordinates])
		return self._get({
			"geometries":"geojson",
			"coordinates":coordinatesStr,
			"annotations":"congestion_numeric,closure",
			"overview":"full"
		})
	
	@staticmethod
	def getWaypointNames(response: dict) -> list[str]:
		return [x["name"] for x in response["waypoints"]]
	
	@staticmethod
	def getFirstRoute(response:dict)->dict:
		return response["routes"][0]
	
	@classmethod
	def getCoordinates(cls,response:dict)->list[CoordinatesBean]:
		return [CoordinatesBean(*x) for x in cls.getFirstRoute(response)["geometry"]["coordinates"]]
	
	@classmethod
	def getHighTrafficPoints(cls,response: dict,congestionPercMin:int) -> list[HighTrafficPointBean]:
		"""
		:param response: response object
		:param congestionPercMin: Minumum percentage to be considered a high traffic point
		"""
		route=cls.getFirstRoute(response)
		points=ModuloListe.affianca(cls.getCoordinates(response),route["legs"][0]["annotation"]["congestion_numeric"])
		highTrafficPoints=[]
		for point in points:
			congestionPerc=point[1]
			if congestionPerc is not None and congestionPerc>=congestionPercMin:
				highTrafficPoints.append(HighTrafficPointBean(point[0],congestionPerc))
		return highTrafficPoints
