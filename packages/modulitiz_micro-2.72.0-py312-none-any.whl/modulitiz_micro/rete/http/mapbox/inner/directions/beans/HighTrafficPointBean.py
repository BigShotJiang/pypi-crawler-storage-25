from modulitiz_micro.util.beans.CoordinatesBean import CoordinatesBean


class HighTrafficPointBean(object):
	def __init__(self,coordinates:CoordinatesBean,congestionPerc:int):
		self.coordinates=coordinates
		self.congestionPerc=congestionPerc
