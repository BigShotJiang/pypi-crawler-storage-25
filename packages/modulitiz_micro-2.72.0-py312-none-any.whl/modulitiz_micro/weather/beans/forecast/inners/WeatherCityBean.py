from modulitiz_micro.util.beans.CoordinatesBean import CoordinatesBean


class WeatherCityBean(object):
	def __init__(self,data: dict):
		self.id: int=data["id"]
		self.name: str=data["name"]
		self.coord = CoordinatesBean(**data["coord"])
		self.country: str=data["country"]
		self.population: int=data["population"]
		self.timezone: int=data["timezone"]
		self.sunrise: int=data["sunrise"]
		self.sunset: int=data["sunset"]
