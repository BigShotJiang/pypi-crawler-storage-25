import requests
import random
from fake_useragent import UserAgent
from typing import Optional

ua = UserAgent()

_CHROME = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
}

_FIREFOX = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}

_PROFILES = {"chrome": _CHROME, "firefox": _FIREFOX}

_LANGUAGES = [
    "en-US,en;q=0.9", "tr-TR,tr;q=0.9",
    "de-DE,de;q=0.9", "fr-FR,fr;q=0.9",
    "ru-RU,ru;q=0.9", "az-AZ,az;q=0.9",
]

class AntiDetectSession(requests.Session):
    """
    ZARION Anti-Detect Session — bot algılanmasını zorlaştırır.
    - Gerçekçi tarayıcı header rotasyonu
    - Proxy entegrasyonu
    - İstek arası delay
    """

    def __init__(self, browser: str = "chrome", rotate_headers: bool = True,
                 proxy_manager=None, request_delay: float = 0.0):
        super().__init__()
        self.browser = browser if browser in _PROFILES else "chrome"
        self.rotate_headers = rotate_headers
        self.proxy_manager = proxy_manager
        self.request_delay = request_delay
        self._apply_profile()

    def _apply_profile(self):
        profile = _PROFILES[self.browser].copy()
        profile["User-Agent"] = ua.chrome if self.browser == "chrome" else ua.firefox
        profile["Accept-Language"] = random.choice(_LANGUAGES)
        self.headers.update(profile)

    def request(self, method: str, url: str, **kwargs):
        if self.rotate_headers:
            self._apply_profile()
        if self.proxy_manager and "proxies" not in kwargs:
            proxy = self.proxy_manager.rotate()
            if proxy:
                kwargs["proxies"] = proxy
        if self.request_delay > 0:
            import time
            time.sleep(self.request_delay + random.uniform(0, self.request_delay * 0.5))
        kwargs.setdefault("timeout", 15)
        return super().request(method, url, **kwargs)

    def __repr__(self):
        return f"<AntiDetectSession browser={self.browser} rotate={self.rotate_headers}>"
