import logging
import sys
from colorama import Fore, Style, init

init(autoreset=True)
_LOGGER = None

class _ColorFormatter(logging.Formatter):
    COLORS = {
        logging.DEBUG:    Fore.CYAN,
        logging.INFO:     Fore.GREEN,
        logging.WARNING:  Fore.YELLOW,
        logging.ERROR:    Fore.RED,
        logging.CRITICAL: Fore.MAGENTA,
    }
    def format(self, record):
        color = self.COLORS.get(record.levelno, "")
        return f"{color}{super().format(record)}{Style.RESET_ALL}"

def setup_logging(level: str = "INFO", log_file: str = None) -> logging.Logger:
    global _LOGGER
    logger = logging.getLogger("zarion")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.handlers.clear()
    fmt = "[%(asctime)s] [%(levelname)s] %(message)s"
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(_ColorFormatter(fmt, "%H:%M:%S"))
    logger.addHandler(ch)
    if log_file:
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter(fmt, "%H:%M:%S"))
        logger.addHandler(fh)
    _LOGGER = logger
    return logger

def _get_logger():
    global _LOGGER
    if _LOGGER is None:
        _LOGGER = setup_logging()
    return _LOGGER

def log_info(msg: str):  _get_logger().info(msg)
def log_error(msg: str): _get_logger().error(msg)
def log_warn(msg: str):  _get_logger().warning(msg)
def log_debug(msg: str): _get_logger().debug(msg)
