import requests
import random
import threading
from typing import List, Optional, Dict

class ProxyManager:
    """
    ZARION Proxy Yöneticisi — VU_JX özel
    - Round-robin / rastgele rotasyon
    - Sağlık kontrolü
    - Kara liste
    """

    def __init__(self, proxies: Optional[List[str]] = None, test_url: str = "https://httpbin.org/ip"):
        self._proxies: List[str] = proxies or []
        self._blacklist: set = set()
        self._lock = threading.Lock()
        self._index = 0
        self.test_url = test_url

    def add(self, proxy: str):
        with self._lock:
            if proxy not in self._proxies:
                self._proxies.append(proxy)

    def add_bulk(self, proxies: List[str]):
        for p in proxies:
            self.add(p)

    def remove(self, proxy: str):
        with self._lock:
            self._proxies = [p for p in self._proxies if p != proxy]

    def blacklist(self, proxy: str):
        with self._lock:
            self._blacklist.add(proxy)
            self._proxies = [p for p in self._proxies if p != proxy]

    def rotate(self) -> Optional[Dict]:
        with self._lock:
            active = [p for p in self._proxies if p not in self._blacklist]
            if not active:
                return None
            proxy = active[self._index % len(active)]
            self._index += 1
            return {"http": proxy, "https": proxy}

    def random_proxy(self) -> Optional[Dict]:
        with self._lock:
            active = [p for p in self._proxies if p not in self._blacklist]
            if not active:
                return None
            proxy = random.choice(active)
            return {"http": proxy, "https": proxy}

    def check(self, proxy: str, timeout: int = 5) -> bool:
        try:
            r = requests.get(self.test_url, proxies={"http": proxy, "https": proxy}, timeout=timeout)
            return r.status_code == 200
        except Exception:
            return False

    def health_check_all(self, timeout: int = 5) -> Dict[str, bool]:
        results = {}
        for proxy in list(self._proxies):
            ok = self.check(proxy, timeout)
            results[proxy] = ok
            if not ok:
                self.blacklist(proxy)
        return results

    @property
    def count(self) -> int:
        return len([p for p in self._proxies if p not in self._blacklist])

    def __repr__(self):
        return f"<ProxyManager proxies={self.count} blacklisted={len(self._blacklist)}>"
