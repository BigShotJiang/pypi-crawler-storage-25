import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from typing import Tuple

def _make_key(key: bytes) -> bytes:
    return (key + b"\x00" * 32)[:32]

def encrypt_aes(data: str, key: bytes) -> str:
    """AES-256-GCM şifreleme. Döner: base64 string."""
    key = _make_key(key)
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, data.encode(), None)
    return base64.b64encode(nonce + ct).decode()

def decrypt_aes(token: str, key: bytes) -> str:
    """AES-256-GCM şifre çözme."""
    key = _make_key(key)
    raw = base64.b64decode(token)
    nonce, ct = raw[:12], raw[12:]
    return AESGCM(key).decrypt(nonce, ct, None).decode()

def generate_keypair(key_size: int = 2048) -> Tuple[bytes, bytes]:
    """RSA anahtar çifti üretir. Döner: (private_pem, public_pem)"""
    priv = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
    private_pem = priv.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    public_pem = priv.public_key().public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem

def rsa_encrypt(data: str, public_pem: bytes) -> str:
    pub = serialization.load_pem_public_key(public_pem)
    ct = pub.encrypt(data.encode(), padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(), label=None,
    ))
    return base64.b64encode(ct).decode()

def rsa_decrypt(token: str, private_pem: bytes) -> str:
    priv = serialization.load_pem_private_key(private_pem, password=None)
    return priv.decrypt(base64.b64decode(token), padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(), label=None,
    )).decode()
