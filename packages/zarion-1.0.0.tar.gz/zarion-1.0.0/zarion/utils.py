import os
import hashlib
import uuid
import threading
import queue
import httpx
import string
import random
import base64
from colorama import Fore, Style, init
from pyfiglet import Figlet
from fake_useragent import UserAgent
try:
    from cfonts import render as cfont_render
except ImportError:
    cfont_render = None

init(autoreset=True)
ua = UserAgent()

_COLOR_MAP = {
    "green":   Fore.GREEN,
    "red":     Fore.RED,
    "blue":    Fore.BLUE,
    "yellow":  Fore.YELLOW,
    "cyan":    Fore.CYAN,
    "magenta": Fore.MAGENTA,
    "white":   Fore.WHITE,
}

def random_user_agent(browser: str = "random") -> str:
    return {"chrome": ua.chrome, "firefox": ua.firefox,
            "safari": ua.safari, "edge": ua.edge}.get(browser, ua.random)

def colored_print(text: str, color: str = "green", bold: bool = False):
    c = _COLOR_MAP.get(color.lower(), Fore.WHITE)
    prefix = "\033[1m" if bold else ""
    print(f"{prefix}{c}{text}{Style.RESET_ALL}")

def figlet_font(text: str, font: str = "slant") -> str:
    return Figlet(font=font).renderText(text)

def cfont_text(text: str, font: str = "block", colors: list = None) -> str:
    if cfont_render is None:
        return text
    return cfont_render(text, font=font, colors=colors or ["cyan", "white"])

def banner(text: str, color: str = "cyan", font: str = "slant"):
    art = figlet_font(text, font)
    print(f"{_COLOR_MAP.get(color, Fore.WHITE)}{art}{Style.RESET_ALL}")

def md5_hash(text: str) -> str:
    return hashlib.md5(text.encode()).hexdigest()

def sha256_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()

def sha512_hash(text: str) -> str:
    return hashlib.sha512(text.encode()).hexdigest()

def generate_uuid(short: bool = False) -> str:
    u = str(uuid.uuid4())
    return u.replace("-", "") if short else u

def random_string(length: int = 16, charset: str = "alphanumeric") -> str:
    sets = {
        "alphanumeric": string.ascii_letters + string.digits,
        "letters":      string.ascii_letters,
        "digits":       string.digits,
        "hex":          string.hexdigits[:16],
        "symbols":      string.ascii_letters + string.digits + "!@#$%^&*",
    }
    chars = sets.get(charset, string.ascii_letters + string.digits)
    return "".join(random.choice(chars) for _ in range(length))

def b64_encode(text: str) -> str:
    return base64.b64encode(text.encode()).decode()

def b64_decode(text: str) -> str:
    return base64.b64decode(text.encode()).decode()
