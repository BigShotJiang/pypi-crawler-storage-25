__version__ = "1.0.0"
__author__  = "VU_JX"
__telegram__ = "@VU_JX"
