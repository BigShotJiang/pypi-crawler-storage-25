import json
import os
import time
import threading
from typing import Any, Optional

class CacheDB:
    """
    ZARION Cache DB — TTL destekli in-memory + dosya cache.
    - Thread-safe
    - Namespace desteği
    - JSON diske yazma/okuma
    """

    def __init__(self, path: Optional[str] = None, default_ttl: int = 300):
        self._store: dict = {}
        self._lock = threading.Lock()
        self._path = path
        self.default_ttl = default_ttl
        if path and os.path.exists(path):
            self._load()

    def set(self, key: str, value: Any, ttl: Optional[int] = None, namespace: str = "default"):
        expire_at = time.time() + (ttl if ttl is not None else self.default_ttl)
        with self._lock:
            self._store[f"{namespace}:{key}"] = {"value": value, "expire_at": expire_at}
        if self._path:
            self._save()

    def get(self, key: str, namespace: str = "default") -> Optional[Any]:
        ns_key = f"{namespace}:{key}"
        with self._lock:
            entry = self._store.get(ns_key)
            if not entry:
                return None
            if time.time() > entry["expire_at"]:
                del self._store[ns_key]
                return None
            return entry["value"]

    def delete(self, key: str, namespace: str = "default"):
        with self._lock:
            self._store.pop(f"{namespace}:{key}", None)
        if self._path:
            self._save()

    def flush(self, namespace: Optional[str] = None):
        with self._lock:
            if namespace:
                keys = [k for k in self._store if k.startswith(f"{namespace}:")]
                for k in keys:
                    del self._store[k]
            else:
                self._store.clear()
        if self._path:
            self._save()

    def cleanup(self):
        now = time.time()
        with self._lock:
            for k in [k for k, v in self._store.items() if now > v["expire_at"]]:
                del self._store[k]

    def keys(self, namespace: str = "default") -> list:
        prefix = f"{namespace}:"
        with self._lock:
            return [k[len(prefix):] for k in self._store if k.startswith(prefix)]

    def _save(self):
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(self._store, f, ensure_ascii=False, indent=2)

    def _load(self):
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                self._store = json.load(f)
        except Exception:
            self._store = {}

    def __repr__(self):
        return f"<CacheDB keys={len(self._store)} path={self._path}>"
