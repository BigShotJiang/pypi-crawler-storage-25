"""
███████╗ █████╗ ██████╗ ██╗ ██████╗ ███╗   ██╗
╚══███╔╝██╔══██╗██╔══██╗██║██╔═══██╗████╗  ██║
  ███╔╝ ███████║██████╔╝██║██║   ██║██╔██╗ ██║
 ███╔╝  ██╔══██║██╔══██╗██║██║   ██║██║╚██╗██║
███████╗██║  ██║██║  ██║██║╚██████╔╝██║ ╚████║
╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝ ╚═════╝ ╚═╝  ╚═══╝

ZARION v1.0.0 — Telegram: @VU_JX
"""

from .http import (
    ZarionSession,
    get, post, put, delete, head, patch, request,
    async_get, async_post, async_request, async_batch,
    cache_session, rate_limited_request,
    Request, Response, PreparedRequest,
    RequestException, HTTPError, ConnectionError, Timeout, TooManyRedirects,
    status_codes,
)
from .utils import (
    colored_print, figlet_font, cfont_text, banner,
    random_user_agent, random_string,
    generate_uuid, md5_hash, sha256_hash, sha512_hash,
    b64_encode, b64_decode,
    os, uuid, hashlib, threading, queue, httpx,
)
from .proxy import ProxyManager
from .crypto import encrypt_aes, decrypt_aes, generate_keypair, rsa_encrypt, rsa_decrypt
from .fingerprint import AntiDetectSession
from .database import CacheDB
from .logging import setup_logging, log_info, log_error, log_warn, log_debug
from .version import __version__, __author__, __telegram__
_session = ZarionSession()
get    = _session.get
post   = _session.post
put    = _session.put
delete = _session.delete

__all__ = [
    "ZarionSession", "AntiDetectSession",
    "get", "post", "put", "delete", "head", "patch", "request",
    "async_get", "async_post", "async_request", "async_batch",
    "cache_session", "rate_limited_request",
    "Request", "Response", "PreparedRequest",
    "RequestException", "HTTPError", "ConnectionError", "Timeout",
    "status_codes",
    "ProxyManager",
    "encrypt_aes", "decrypt_aes", "generate_keypair", "rsa_encrypt", "rsa_decrypt",
    "colored_print", "figlet_font", "cfont_text", "banner",
    "random_user_agent", "random_string",
    "generate_uuid", "md5_hash", "sha256_hash", "sha512_hash",
    "b64_encode", "b64_decode",
    "os", "uuid", "hashlib", "threading", "queue", "httpx",
    "CacheDB",
    "setup_logging", "log_info", "log_error", "log_warn", "log_debug",
    "__version__", "__author__", "__telegram__",
]
