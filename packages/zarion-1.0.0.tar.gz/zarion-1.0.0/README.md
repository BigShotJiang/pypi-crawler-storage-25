# ZARION v1.0.0
**Telegram:** [@VU_JX](https://t.me/VU_JX)

---

## Kurulum

```bash
pip install ZARION
```

---

## Modüller

| Modül | Açıklama |
|---|---|
| `ZarionSession` | Retry + timeout + UA rotasyonu ile HTTP session |
| `AntiDetectSession` | Bot algılanmasını zorlaştıran gelişmiş session |
| `ProxyManager` | Proxy listesi, rotasyon, sağlık kontrolü |
| `CacheDB` | TTL destekli in-memory + dosya cache |
| `encrypt_aes` / `decrypt_aes` | AES-256-GCM şifreleme |
| `generate_keypair` / `rsa_encrypt` / `rsa_decrypt` | RSA şifreleme |
| `async_get` / `async_post` / `async_batch` | Paralel async HTTP |
| `rate_limited_request` | Rate-limited istek (15/dk) |
| `cache_session` | Yanıtları önbellekleyen session |

---

## Kullanım

```python
import zarion as zr

# Banner
zr.banner("ZARION", color="cyan")

# Basit istek
resp = zr.get("https://httpbin.org/get")
print(resp.json())

# JSON kısayolu
session = zr.ZarionSession()
data = session.get_json("https://httpbin.org/json")

# Anti-detect
anti = zr.AntiDetectSession(browser="chrome", request_delay=1.0)
resp = anti.get("https://httpbin.org/headers")

# Proxy yönetimi
pm = zr.ProxyManager()
pm.add("http://1.2.3.4:8080")
anti = zr.AntiDetectSession(proxy_manager=pm)

# Paralel async istek
import asyncio
results = asyncio.run(zr.async_batch([
    {"method": "GET", "url": "https://httpbin.org/get"},
    {"method": "GET", "url": "https://httpbin.org/ip"},
]))

# AES şifreleme
token = zr.encrypt_aes("gizli veri", b"anahtarim")
plain = zr.decrypt_aes(token, b"anahtarim")

# RSA şifreleme
priv, pub = zr.generate_keypair()
token = zr.rsa_encrypt("mesaj", pub)
plain = zr.rsa_decrypt(token, priv)

# Cache DB
db = zr.CacheDB(path="cache.json", default_ttl=600)
db.set("user:1", {"name": "VU_JX"}, ttl=60)
print(db.get("user:1"))

# Loglama
zr.setup_logging("DEBUG", log_file="zarion.log")
zr.log_info("Başladı")
zr.log_error("Hata!")

# Yardımcılar
print(zr.random_user_agent("chrome"))
print(zr.random_string(32, "hex"))
print(zr.sha256_hash("zarion"))
print(zr.b64_encode("VU_JX"))
print(zr.generate_uuid(short=True))
```

---

*ZARION — @VU_JX*
