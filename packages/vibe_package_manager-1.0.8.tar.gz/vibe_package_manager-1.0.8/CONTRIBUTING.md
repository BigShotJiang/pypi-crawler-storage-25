# Contributing to Vibe Package Manager

感谢您对 Vibe Package Manager 项目的关注！我们欢迎所有形式的贡献。

## 如何贡献

### 报告 Bug

如果您发现了 Bug，请：

1. 检查 [Issues](https://github.com/YOUR_USERNAME/vibe_package_manager/issues) 确认问题尚未被报告
2. 创建新的 Issue，使用 Bug 报告模板
3. 提供详细信息：
   - Bug 描述
   - 复现步骤
   - 预期行为
   - 实际行为
   - 环境信息（操作系统、Python 版本等）
   - 相关日志或截图

### 提出功能建议

如果您有功能建议，请：

1. 检查 [Issues](https://github.com/YOUR_USERNAME/vibe_package_manager/issues) 确认建议尚未被提出
2. 创建新的 Issue，使用功能建议模板
3. 提供详细信息：
   - 功能描述
   - 使用场景
   - 预期效果
   - 可能的实现方案

### 提交代码

#### 开发环境设置

```bash
# 1. Fork 并克隆仓库
git clone https://github.com/YOUR_USERNAME/vibe_package_manager.git
cd vibe_package_manager

# 2. 创建虚拟环境
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate

# 3. 安装依赖
pip install -r requirements.txt
pip install pytest pytest-cov black flake8 mypy

# 4. 运行测试
pytest

# 5. 代码格式化
black src/ main.py

# 6. 代码检查
flake8 src/ main.py

# 7. 类型检查
mypy src/
```

#### 开发流程

1. **创建功能分支**
   ```bash
   git checkout -b feature/your-feature-name
   # 或
   git checkout -b fix/your-bug-fix
   ```

2. **进行更改**
   - 遵循现有代码风格
   - 添加必要的测试
   - 更新相关文档

3. **提交更改**
   ```bash
   git add .
   git commit -m "feat: add new feature"
   ```

   提交信息遵循 [约定式提交](https://www.conventionalcommits.org/) 规范：
   - `feat:` 新功能
   - `fix:` Bug 修复
   - `docs:` 文档更新
   - `style:` 代码格式调整
   - `refactor:` 代码重构
   - `test:` 测试相关
   - `chore:` 构建/工具链相关

4. **推送到你的 Fork**
   ```bash
   git push origin feature/your-feature-name
   ```

5. **创建 Pull Request**
   - 在 GitHub 上创建 PR
   - 填写 PR 模板
   - 等待代码审查

#### 代码规范

- **Python 代码风格**：遵循 [PEP 8](https://www.python.org/dev/peps/pep-0008/)
- **类型提示**：为公共函数添加类型提示
- **文档字符串**：为公共函数编写文档字符串（遵循 Google 风格）
- **测试覆盖率**：确保新功能有相应的测试
- **提交信息**：使用约定式提交格式

#### 代码审查

所有 Pull Request 都需要经过代码审查。审查者会检查：

- 代码质量和风格
- 测试覆盖率
- 文档完整性
- 向后兼容性
- 安全性问题

请保持耐心，积极响应审查意见。

### 改进文档

文档改进也是重要的贡献！您可以：

- 修正错误或不清晰的内容
- 添加使用示例
- 翻译文档到其他语言
- 改进文档结构

## 行为准则

### 我们的承诺

为了营造一个开放和友好的环境，我们承诺：

- **尊重**：尊重不同的观点和经验
- **包容**：欢迎并包容所有参与者
- **友善**：以友善和建设性的方式交流
- **协作**：优先考虑社区的最佳利益

### 不被接受的行为

- 使用性化的语言或图像
- 人身攻击或侮辱性评论
- 公开或私下的骚扰
- 未经许可发布他人的私人信息
- 其他不专业或不恰当的行为

### 报告不当行为

如果遇到不当行为，请通过以下方式联系维护者：
- 提交 Issue
- 发送邮件至项目维护者

## 开发指南

### 项目结构

```
vibe_package_manager/
├── main.py                      # 主程序入口
├── src/                         # 源代码
│   ├── config_parser.py         # 配置解析
│   ├── version_utils.py         # 版本工具
│   ├── skill_sync.py            # SKILL 同步
│   ├── subagent_sync.py         # SubAgent 同步
│   └── mcp_installer.py         # MCP 安装
├── tests/                       # 测试文件
├── examples/                    # 示例文件
└── docs/                        # 文档
```

### 添加新功能

1. 在 `src/` 中添加新模块
2. 编写相应的测试（在 `tests/` 中）
3. 更新文档
4. 提交 Pull Request

### 修复 Bug

1. 找到 Bug 的位置
2. 编写测试用例复现 Bug
3. 修复 Bug
4. 确保所有测试通过
5. 更新相关文档
6. 提交 Pull Request

## 发布流程

### 版本号规范

遵循 [语义化版本 2.0.0](https://semver.org/lang/zh-CN/)：

- **主版本号**：不兼容的 API 修改
- **次版本号**：向下兼容的功能性新增
- **修订号**：向下兼容的问题修正

### 发布步骤

1. 更新版本号（在 `src/__init__.py` 中）
2. 更新 CHANGELOG.md
3. 创建 Git 标签
4. 创建 GitHub Release
5. 发布到 PyPI（如适用）

## 获取帮助

如果您在贡献过程中遇到问题：

- 查看 [README.md](README.md)
- 查看 [QUICKSTART.md](QUICKSTART.md)
- 提交 Issue
- 参与 [Discussions](https://github.com/YOUR_USERNAME/vibe_package_manager/discussions)

## 致谢

感谢所有为本项目做出贡献的开发者！

您的贡献让 Vibe Package Manager 变得更好！