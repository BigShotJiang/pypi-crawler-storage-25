"""HTTP client wrapper for vpm backend calls.

All HTTP traffic to the vpm backend must go through this module so that
shared concerns — SSL verification, default headers, timeouts, proxy
fallback — stay in one place.

SSL verification is disabled to accommodate backends served with
self-signed certificates.

Two-stage send strategy (mirrors compass-code-review.sh pre-push hook):

1. First attempt bypasses proxies and sends directly (``--noproxy '*'``
   equivalent), since the backend is typically an internal host.
2. On *any* failure — transport error **or** non-2xx HTTP response —
   fall back to the system default network config (honors HTTP_PROXY /
   HTTPS_PROXY), in case direct access is blocked and a proxy is
   actually required.
"""

import json
import platform
import ssl
import urllib.error
import urllib.request
from typing import Any, Dict, Optional, Tuple

from . import __version__
from .constants import CLIENT_SOURCE, REPORT_HTTP_TIMEOUT

_SSL_CONTEXT = ssl._create_unverified_context()


class _NoProxyHandler(urllib.request.ProxyHandler):
    """ProxyHandler that short-circuits env-based proxying.

    ``ProxyHandler({})`` with an empty dict gets silently discarded by
    ``build_opener`` (OpenerDirector skips handlers whose only method is
    ``proxy_open``), leaving the default env-reading ProxyHandler absent
    but also leaving no explicit opt-out marker. This subclass defines
    real ``http_open``/``https_open`` methods that return ``None`` so the
    opener moves on to the default HTTP(S)Handler without any proxy.
    """

    def __init__(self) -> None:
        super().__init__(proxies={})

    def http_open(self, req: urllib.request.Request) -> None:
        return None

    def https_open(self, req: urllib.request.Request) -> None:
        return None


def _build_opener(bypass_proxy: bool) -> urllib.request.OpenerDirector:
    handlers: list = [urllib.request.HTTPSHandler(context=_SSL_CONTEXT)]
    if bypass_proxy:
        handlers.append(_NoProxyHandler())
    return urllib.request.build_opener(*handlers)


_DEFAULT_OPENER = _build_opener(bypass_proxy=False)
_NOPROXY_OPENER = _build_opener(bypass_proxy=True)


def default_headers() -> Dict[str, str]:
    """Return the standard client-identification headers."""
    return {
        "X-Client-Source": CLIENT_SOURCE,
        "X-Client-Version": __version__,
        "X-Client-Os": platform.system().lower(),
    }


class HttpError(Exception):
    """Raised for any non-2xx response or transport failure."""

    def __init__(self, message: str, status: Optional[int] = None, body: str = ""):
        super().__init__(message)
        self.status = status
        self.body = body


def _send(
    opener: urllib.request.OpenerDirector,
    req: urllib.request.Request,
    timeout: float,
) -> Tuple[int, bytes]:
    try:
        with opener.open(req, timeout=timeout) as resp:
            status = getattr(resp, "status", resp.getcode())
            body = resp.read()
            if status >= 400:
                raise HttpError(
                    f"HTTP {status}",
                    status=status,
                    body=body.decode("utf-8", "replace"),
                )
            return status, body
    except urllib.error.HTTPError as e:
        err_body = ""
        try:
            err_body = e.read().decode("utf-8", "replace")
        except Exception:
            pass
        raise HttpError(
            f"HTTP {e.code}: {e.reason}", status=e.code, body=err_body
        ) from e
    except urllib.error.URLError as e:
        raise HttpError(f"URL error: {e.reason}") from e


def request(
    method: str,
    url: str,
    *,
    json_body: Optional[Any] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = REPORT_HTTP_TIMEOUT,
) -> Tuple[int, bytes]:
    """Send an HTTP request and return ``(status, body_bytes)``.

    Two-stage strategy mirroring compass-code-review.sh:

    1. First attempt bypasses proxies and sends directly (equivalent
       to curl ``--noproxy '*'``), since the backend is an internal
       host that typically doesn't need a proxy.
    2. On *any* failure — transport error or non-2xx HTTP response —
       fall back to the system default network config (honors
       HTTP_PROXY / HTTPS_PROXY), in case direct access is blocked
       and a proxy is actually required.

    If both attempts fail the second error is raised.
    """
    merged_headers = default_headers()
    merged_headers["Accept"] = "application/json"
    if json_body is not None:
        merged_headers["Content-Type"] = "application/json"
    if headers:
        merged_headers.update(headers)

    data: Optional[bytes] = None
    if json_body is not None:
        data = json.dumps(json_body, ensure_ascii=False).encode("utf-8")

    req = urllib.request.Request(
        url, data=data, headers=merged_headers, method=method.upper()
    )

    # Stage 1: bypass proxy and send directly (internal hosts don't
    # need a proxy; avoids wasting time on a broken proxy timeout)
    try:
        return _send(_NOPROXY_OPENER, req, timeout)
    except HttpError as first_err:
        # Stage 2: fall back to system default network config (honors
        # HTTP_PROXY / HTTPS_PROXY) in case direct access is blocked
        try:
            return _send(_DEFAULT_OPENER, req, timeout)
        except HttpError as second_err:
            raise second_err from first_err


def get(url: str, **kwargs: Any) -> Tuple[int, bytes]:
    return request("GET", url, **kwargs)


def post(url: str, **kwargs: Any) -> Tuple[int, bytes]:
    return request("POST", url, **kwargs)
