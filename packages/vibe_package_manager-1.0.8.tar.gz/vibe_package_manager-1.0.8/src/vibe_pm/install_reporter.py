"""Install telemetry reporter for vpm."""

import threading
from typing import List, Optional

from . import http_client
from .constants import get_report_install_endpoint


class InstallReporter:
    """Collects installed package paths and reports them to a backend.

    Designed to never break vpm install: any network/HTTP error is caught,
    printed as a warning, and swallowed.
    """

    def __init__(
        self,
        endpoint: Optional[str] = None,
        debug_mode: bool = False,
        enabled: bool = True,
    ):
        # If caller passes an explicit endpoint, use it; otherwise resolve
        # from constants (which honors env var overrides).
        self.endpoint = endpoint or get_report_install_endpoint()
        self.debug_mode = debug_mode
        self.enabled = enabled
        self._items: List[str] = []
        self._seen: set = set()

    def _debug_log(self, message: str) -> None:
        if self.debug_mode:
            print(f"[DEBUG] [InstallReporter] {message}")

    def add(self, path: str) -> None:
        """Queue a single path."""
        if not self.enabled or not path:
            return
        if path in self._seen:
            return
        self._seen.add(path)
        self._items.append(path)
        self._debug_log(f"Queued path: {path}")

    def add_skill(self, skill_name: str, skill_path: Optional[str] = None) -> None:
        """Queue a SKILL install record using the manifest ``path`` field."""
        if not skill_path:
            return
        self.add(skill_path.strip("/").replace("\\", "/"))

    def add_mcp(self, mcp_name: str) -> None:
        """Queue an MCP install record."""
        self.add(mcp_name)

    def add_subagent(
        self,
        subagent_name: str,
        md_filenames: List[str],
        subagent_path: Optional[str] = None,
    ) -> None:
        """Queue a SubAgent install record using the manifest ``path`` field."""
        if not subagent_path:
            return
        self.add(subagent_path.strip("/").replace("\\", "/"))

    def flush(self) -> None:
        """POST collected items to the report endpoint. Never raises."""
        if not self.enabled:
            self._debug_log("Reporter disabled, skipping flush")
            return
        if not self._items:
            self._debug_log("No items to report, skipping flush")
            return

        payload = {"items": [{"path": p} for p in self._items]}

        self._debug_log(
            f"Reporting {len(self._items)} item(s) to {self.endpoint}"
        )
        self._debug_log(f"Body: {payload}")

        try:
            status, _ = http_client.post(self.endpoint, json_body=payload)
            self._debug_log(f"Report status: {status}")
        except http_client.HttpError as e:
            print(f"Warning: install report failed: {e}")
            if e.body:
                self._debug_log(f"HTTPError body: {e.body}")
        except Exception as e:
            print(f"Warning: install report failed: {e}")
        finally:
            self._items.clear()
            self._seen.clear()

    def flush_async(self) -> None:
        """Fire-and-forget flush on a daemon thread.

        Telemetry must never block or fail the install. Using a daemon
        thread means if the process exits before the HTTP call returns,
        the thread is dropped silently — acceptable for best-effort
        reporting.
        """
        if not self.enabled or not self._items:
            self._debug_log("flush_async: nothing to send")
            return
        t = threading.Thread(
            target=self.flush, name="vpm-install-reporter", daemon=True
        )
        t.start()
        self._debug_log("flush_async: spawned background reporter thread")
