"""Global constants and runtime-overridable settings for vpm.

All values here can be overridden via environment variables, so users
can point vpm at a different backend without editing code.
"""

import os


# ---------------------------------------------------------------------------
# Backend host & API version
# ---------------------------------------------------------------------------

# Default backend host (scheme + host + port, no trailing slash).
DEFAULT_BACKEND_HOST = "https://u4-ai-hub.alibaba.net"
# DEFAULT_BACKEND_HOST = "http://127.0.0.1:8080"

# Default API version segment used in URL paths (e.g. "v1" -> "/api/v1/...").
DEFAULT_API_VERSION = "v1"

# Resolved at import time, but each accessor below re-reads env vars so
# tests / runtime overrides take effect without re-importing.

def get_backend_host() -> str:
    """Return the backend host, honoring VPM_BACKEND_HOST."""
    return os.environ.get("VPM_BACKEND_HOST", DEFAULT_BACKEND_HOST).rstrip("/")


def get_api_version() -> str:
    """Return the API version segment, honoring VPM_API_VERSION."""
    return os.environ.get("VPM_API_VERSION", DEFAULT_API_VERSION).strip("/")


def build_api_url(*path_segments: str) -> str:
    """Compose a full API URL from host + /api/<version>/ + segments.

    Example:
        build_api_url("files", "report-install")
        -> "http://127.0.0.1:8080/api/v1/files/report-install"
    """
    host = get_backend_host()
    version = get_api_version()
    tail = "/".join(seg.strip("/") for seg in path_segments if seg)
    return f"{host}/api/{version}/{tail}"


# ---------------------------------------------------------------------------
# Endpoint paths (everything after /api/<version>/)
# ---------------------------------------------------------------------------

REPORT_INSTALL_PATH_SEGMENTS = ("files", "report-install")


def get_report_install_endpoint() -> str:
    """Full URL for the install-report endpoint.

    Resolution order (first wins):
      1. VPM_REPORT_ENDPOINT (full URL override — useful for tests)
      2. VPM_BACKEND_HOST + VPM_API_VERSION + default path
      3. DEFAULT_BACKEND_HOST + DEFAULT_API_VERSION + default path
    """
    full_override = os.environ.get("VPM_REPORT_ENDPOINT")
    if full_override:
        return full_override
    return build_api_url(*REPORT_INSTALL_PATH_SEGMENTS)


# ---------------------------------------------------------------------------
# HTTP client identification headers
# ---------------------------------------------------------------------------

CLIENT_SOURCE = "vpm"


# ---------------------------------------------------------------------------
# Network timeouts (seconds)
# ---------------------------------------------------------------------------

REPORT_HTTP_TIMEOUT = 5
