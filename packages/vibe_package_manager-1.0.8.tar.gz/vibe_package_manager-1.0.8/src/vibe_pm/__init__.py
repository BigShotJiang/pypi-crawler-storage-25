"""Vibe Package Manager - A package manager for AI coding assistants."""

import tomllib
from pathlib import Path

# Hardcoded version - must be updated when releasing new version
# This ensures 'vpm -v' returns correct version even after installation
__version__ = "1.0.8"


def _get_version() -> str:
    """
    Get the version of Vibe Package Manager.

    Returns:
        Version string - always returns the hardcoded __version__
        to ensure 'vpm -v' shows the correct version immediately after update.
        This avoids issues where pip metadata may be outdated.
    """
    # Always use hardcoded version as the single source of truth
    # This ensures 'vpm -v' returns correct version immediately after code update
    # without requiring pip reinstall
    return __version__
__all__ = ["main"]

from .cli import main
