# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial release of Vibe Package Manager
- SKILL synchronization from Git repositories
- SubAgent synchronization from Git repositories
- MCP installation via commands
- Version compatibility checking with caret (^) notation support
- Configuration file validation
- Multi-agent support (Claude, iFlow)
- Comprehensive documentation

### Features
- **Version Management**: Track and manage versions of SKILLs and SubAgents
- **Dependency Resolution**: Support for semantic versioning with caret (^) notation
- **Multi-Agent Support**: Sync to multiple agents from a single configuration
- **Git Integration**: Clone and sync packages from Git repositories
- **MCP Installation**: Execute installation commands for MCP servers
- **Validation**: Validate configuration files and check version compatibility

### Documentation
- README.md with complete usage guide
- QUICKSTART.md for getting started quickly
- Example SKILL and SubAgent files
- JSON Schema for configuration validation
- Comprehensive open source guidelines

## [1.0.0] - 2026-03-19

### Added
- Initial public release
- Core package management functionality
- CLI interface with sync and validate commands
- Support for SKILL, SubAgent, and MCP dependencies
- Git repository cloning and synchronization
- Version compatibility validation
- Configuration file validation
- Comprehensive error handling and reporting

### Documentation
- Complete README with usage examples
- Quick start guide
- Open source contribution guidelines
- Code of conduct
- Security policy

---

## Version Format

- **[Unreleased]**: Changes planned for the next release
- **[X.Y.Z]**: Released versions

## Change Types

- **Added**: New features
- **Changed**: Changes in existing functionality
- **Deprecated**: Soon-to-be removed features
- **Removed**: Removed features
- **Fixed**: Bug fixes
- **Security**: Security vulnerability fixes