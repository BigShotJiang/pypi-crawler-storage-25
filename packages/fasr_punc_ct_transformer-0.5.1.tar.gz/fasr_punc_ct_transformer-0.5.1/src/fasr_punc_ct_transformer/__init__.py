from fasr_punc_ct_transformer.models.pun import CTTransformerForPunc

__all__ = [
    "CTTransformerForPunc",
]
