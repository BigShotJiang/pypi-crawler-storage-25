# fasr-punc-ct-transformer

基于 CT-Transformer 的标点恢复模型插件，为 fasr 提供中英文混合标点恢复能力。

## 安装

```bash
pip install fasr-punc-ct-transformer
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `ct_transformer` | `CTTransformerForPunc` | `iic/punc_ct-transformer_zh-cn-common-vocab272727-pytorch` | CT-Transformer 标点恢复，支持中英文混合 |

模型权重默认从 ModelScope 自动下载。

## 使用方式

### 在流水线中使用

标点模型通常作为 `sentencizer` 组件在流水线末端使用：

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="paraformer")
    .add_pipe("sentencizer", model="ct_transformer")
)
```

### 单独使用模型

模型实例化时会自动执行 `download_checkpoint()` + `load_checkpoint()`：

```python
from fasr.config import registry

model = registry.punc_models.get("ct_transformer")()
spans = model.restore("今天天气真好我想出去玩你觉得呢")
for span in spans:
    print(span.text)  # 带标点的句子

# 使用自定义权重目录
model.load_checkpoint("/path/to/custom/ct_transformer")
```

## 运行期 / 会话参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint` | `str \| None` | `"iic/punc_ct-transformer_zh-cn-common-vocab272727-pytorch"` | 远程 repo_id；非空时实例化会自动下载 |
| `cache_dir` | `str \| Path \| None` | `None` | 缓存目录，`None` 使用 `fasr.utils.get_cache_dir()` |
| `endpoint` | `Literal["modelscope", "huggingface", "hf-mirror"]` | `"modelscope"` | 下载端点 |
| `disable_update` | `bool` | `True` | 禁用 FunASR 自动更新检查 |
| `disable_log` | `bool` | `True` | 禁用 FunASR 日志输出 |
| `disable_pbar` | `bool` | `True` | 禁用进度条 |

## 依赖

- `fasr`
- `funasr`
- Python 3.10–3.12
