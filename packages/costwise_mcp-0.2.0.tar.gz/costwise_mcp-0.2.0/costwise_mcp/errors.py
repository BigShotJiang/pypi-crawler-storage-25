"""CostWise MCP SDK Error definitions."""


class CostWiseError(Exception):
    """Base exception for CostWise MCP SDK."""
    pass


class PolicyViolationError(CostWiseError):
    """Raised when a request violates a team policy."""

    def __init__(self, team: str, reason: str, decision=None):
        self.team = team
        self.reason = reason
        self.decision = decision
        super().__init__(f"Policy violation for team '{team}': {reason}")


class BudgetExceededError(PolicyViolationError):
    """Raised when a team's budget is exceeded."""

    def __init__(self, team: str, current_spend: float, budget_limit: float, decision=None):
        self.current_spend = current_spend
        self.budget_limit = budget_limit
        super().__init__(
            team=team,
            reason=f"Monthly budget exceeded (${current_spend:.2f} / ${budget_limit:.2f})",
            decision=decision,
        )


class ModelBlockedError(PolicyViolationError):
    """Raised when a model is blocked for a team."""

    def __init__(self, team: str, model: str, alternative: str = None, decision=None):
        self.blocked_model = model
        self.alternative = alternative
        msg = f"Model '{model}' is blocked"
        if alternative:
            msg += f". Alternative: '{alternative}'"
        super().__init__(team=team, reason=msg, decision=decision)


class TierRestrictionError(PolicyViolationError):
    """Raised when a model's tier exceeds the team's allowed tier."""

    def __init__(self, team: str, model: str, model_tier: int, max_tier: int, decision=None):
        self.model_tier = model_tier
        self.max_tier = max_tier
        tier_names = {1: "premium", 2: "standard", 3: "budget"}
        super().__init__(
            team=team,
            reason=f"Model '{model}' is tier {model_tier} ({tier_names.get(model_tier, 'unknown')}) "
                   f"but team is restricted to tier {max_tier}+ ({tier_names.get(max_tier, 'unknown')})",
            decision=decision,
        )


class InvalidAPIKeyError(CostWiseError):
    """Raised when the API key is invalid or expired."""
    pass


class RateLimitError(CostWiseError):
    """Raised when the rate limit is exceeded."""

    def __init__(self, retry_after: int = 10):
        self.retry_after = retry_after
        super().__init__(f"Rate limit exceeded. Retry after {retry_after} seconds.")
