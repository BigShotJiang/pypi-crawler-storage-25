# psi-agent

psi-agent 是一个以**可移植性**和**组件化**为核心理念的 agent 框架。

> **OpenSpec CLI**: If the `openspec` command is not available, use `npx @fission-ai/openspec@latest <command>` as fallback.

## 核心理念

**可移植性**：用户只需复制 workspace 目录本身，即可完成 agent 的移植。

**组件化**：agent 由独立组件拼装而成，各组件通过 Unix socket 进行 IPC 通信，确保松耦合。

## 组件架构

psi-agent 分为四类组件：

| 组件类型 | 命名模式 | 职责 |
|---------|---------|------|
| psi-ai-* | `psi-ai-<provider>` | LLM 提供商适配，封装不同提供商接口 |
| psi-session | `psi-session` | Agent 运行循环，处理消息和 tool/skill 调用 |
| psi-channel-* | `psi-channel-<platform>` | 消息通道，连接具体平台（telegram, feishu, TUI 等） |
| psi-workspace-* | `psi-workspace-<mode>` | Workspace 打包/挂载管理 |

### psi-ai-* 组件

LLM 调用桥梁，封装不同提供商（openai-completion, anthropic-messages 等）。

职责：
- 监听 session 发来的 AI 请求
- 转发请求给底层 LLM 提供商
- 返回 LLM 响应给 session

接口：
- 协议：HTTP over Unix socket
- API 标准：OpenAI chat completion 格式
- session 作为 client，psi-ai-* 作为 server

### psi-session 组件

Agent 核心运行循环。

职责：
- 从 channel 接收用户消息
- 调用 psi-ai-* 进行思考
- 根据 workspace 中定义的 tools 执行动作
- 输出最终回复给 channel

Agent 流程：
- 用户消息直接传给 LLM
- tools 通过 API tools 字段传递给 LLM
- skills 的 description 放在 system prompt 中
- LLM 可调用阅读类 tool 查看 skill 详情

**Workspace 热重载：**

psi-session 支持运行时热重载 workspace 文件变更：

- **检测时机**：每次处理用户消息前
- **检测方式**：MD5 文件哈希比较
- **检测范围**：
  - `tools/*.py` — 工具文件
  - `skills/*/SKILL.md` — 技能文件
  - `schedules/*/TASK.md` — 定时任务文件
- **变更响应**：
  - 工具变更：更新工具注册表
  - 技能/定时任务变更：重新构建系统提示词
  - 定时任务变更：更新定时执行器

**限制**：`systems/system.py` 不支持热重载，修改后需重启 session。

接口：
- 与 channel：HTTP over Unix socket，OpenAI chat completion 协议
- 与 psi-ai-*：HTTP over Unix socket，OpenAI chat completion 协议
- channel 只收发最终 message，tool calling 和 thinking 局限于 session 内部

### psi-channel-* 组件

消息通道适配器，连接具体平台。

职责：
- 将用户输入转发给 session
- 将 session 输出发送到平台

示例：psi-channel-tui（终端界面）、psi-channel-telegram、psi-channel-feishu

接口：
- 协议：HTTP over Unix socket
- session 作为 server，channel 作为 client
- 只传递最终 message，不暴露 tool calling 过程

### psi-workspace-* 组件

Workspace 管理器，提供五个独立的 CLI 工具：

| 组件 | 职责 |
|------|------|
| psi-workspace-pack | 将 workspace 目录打包成 squashfs 镜像 |
| psi-workspace-unpack | 将 squashfs 镜像解压成目录 |
| psi-workspace-mount | 将 squashfs 镜像挂载成 overlayfs |
| psi-workspace-umount | 卸载已挂载的 workspace |
| psi-workspace-snapshot | 创建 workspace 快照 |

**注意：这些组件需要 root 权限执行 mount/umount 操作。**

#### Squashfs 镜像结构

```
workspace.squashfs
├── manifest.json          # 元信息配置
├── <uuid-1>/              # 基础层（第一次 pack 的目录内容）
├── <uuid-2>/              # 第一次 snapshot 添加的层
├── <uuid-3>/              # 第二次 snapshot 添加的层
└── ...
```

#### Manifest.json 结构

```json
{
  "layers": {
    "<uuid-1>": { "tag": "v1.0" },
    "<uuid-2>": { "parent": "<uuid-1>", "tag": "v1.1" },
    "<uuid-3>": { "parent": "<uuid-2>" }
  },
  "default": "<uuid-3>"
}
```

**字段说明：**
- `layers`: 所有层的定义，key 为 UUID
  - `parent`: 可选，父层 UUID（根层无 parent）
  - `tag`: 可选，人类可读的标签
- `default`: 默认挂载的层 UUID

#### CLI 使用示例

**打包 workspace：**
```bash
sudo psi-workspace-pack --input ./workspace --output ./workspace.squashfs --tag v1.0
```

**挂载 workspace：**
```bash
sudo psi-workspace-mount --input ./workspace.squashfs --output ./mounted-workspace
# 或指定特定层
sudo psi-workspace-mount --input ./workspace.squashfs --output ./mounted-workspace --layer v1.0
```

**创建快照：**
```bash
sudo psi-workspace-snapshot --input ./workspace.squashfs --mount-point ./mounted-workspace --tag v1.1
```

**卸载 workspace：**
```bash
sudo psi-workspace-umount --mount-point ./mounted-workspace
```

**解压 squashfs：**
```bash
psi-workspace-unpack --input ./workspace.squashfs --output ./extracted-workspace
```

## Workspace 结构

workspace 目录定义了一个 agent 的所有信息。用户只需复制此目录即可完成移植。

```
workspace/
|- tools/
|  |- *.py
|- skills/
|  |- */SKILL.md
|- schedules/
|  |- */TASK.md
|- systems/
   |- system.py
```

### tools/ 目录

每个 `.py` 文件定义一个 tool。

**规范：**
- 文件名：`<tool_name>.py`（如 `read.py`）
- 入口函数：`async def tool(...) -> ...`（必须是 async）
- 函数签名：使用类型注解和默认值定义参数
- 文档字符串：使用统一格式描述函数作用、参数含义、返回值含义
- session 启动时扫描 tools/ 目录并加载

**示例：**

```python
# tools/read.py
import anyio

async def tool(file_path: str) -> str:
    """Read file content asynchronously.

    Args:
        file_path: Path to the file to read.

    Returns:
        File content as string.
    """
    # 使用 anyio 异步读取
    async with await anyio.open_file(file_path) as f:
        return await f.read()
```

传递给 psi-ai-* 时使用 OpenAI tool call 规范。

### skills/ 目录

每个子目录定义一个 skill，遵循 Claude Code 习惯。

**规范：**
- 目录结构：`skills/<skill_name>/`
- 入口文件：`SKILL.md`
- meta 信息：使用 YAML frontmatter 格式

**SKILL.md 示例：**

```markdown
---
name: example-skill
description: A brief description of what this skill does.
---

Skill instructions here...
```

- session 启动时扫描 skills/ 目录
- skills 的 description 放入 system prompt
- LLM 可调用阅读类 tool 查看 skill 详情

### schedules/ 目录

定时任务定义。

**规范：**
- 目录结构：`schedules/<task_name>/`
- 入口文件：`TASK.md`
- meta 信息：使用 YAML frontmatter，包含 `cron` 字段

**TASK.md 示例：**

```markdown
---
name: daily-summary
description: Generate daily summary
cron: "0 9 * * *"  # 9am daily
---

Task instructions here...
```

**注意：记忆系统不内置实现，用户可在 workspace 中自行实现（通过 schedule + system prompt 特殊处理）。**

### systems/ 目录

系统配置。

**规范：**
- 文件：`systems/system.py`
- 必要函数：
  - `async def build_system_prompt() -> str` — 构造系统 prompt，自动扫描 skills/ 目录
  - `async def compact_history(history: list[dict[str, str]], max_tokens: int = 4000) -> list[dict[str, str]]` — 压缩过长对话历史

**build_system_prompt() 行为：**
- 扫描 `workspace/skills/` 目录下的所有 SKILL.md 文件
- 解析 YAML frontmatter 提取 description 字段
- 将所有 skill description 组合成 system prompt 返回
- 使用异步 IO 进行文件读取

**compact_history() 行为：**
- 接收对话历史和最大 token 限制
- 当历史超过限制时，使用 LLM 摘要压缩旧消息
- 返回压缩后的消息列表，保留近期上下文

**完整实现示例：** 参见 `examples/a-simple-bash-only-workspace/systems/system.py`。

## 编码规范

### Python 版本

使用 Python 3.14 或更高版本，尽可能使用现代特性。

### 代码风格

- 类型注解：所有函数必须使用类型注解
- 命名约定：
  - 函数/变量：snake_case
  - 类：PascalCase
  - 常量：UPPER_SNAKE_CASE
- 工具：
  - `ruff check` — lint
  - `ruff format` — format
  - `ty check` — typing 检查
- 质量检查：所有代码必须通过 format、lint、typing 和 test 才算完成

### Async 接口规范

**所有接口函数必须是 async：**

- workspace 中的 `tool()` 函数 — 必须是 async
- `build_system_prompt()` — 必须是 async
- `compact_history()` — 必须是 async

**所有 IO 操作必须使用 async 生态方法：**

- **文件系统**：使用 `anyio.open_file()` 或 `anyio.Path`（跨 async 框架抽象）
- **网络请求**：使用 `aiohttp.ClientSession`（统一 HTTP 客户端）
- **子进程**：使用 `asyncio.create_subprocess_exec` 或 `asyncio.create_subprocess_shell`（不是 `subprocess.run`）

**禁止使用 `pathlib.Path` 进行文件 IO 操作** — 所有文件操作方法（`read_text()`, `exists()`, `iterdir()` 等）都是同步的，会阻塞事件循环。必须使用 `anyio.Path` 的 async 方法：`await anyio.Path(path).read_text()`、`await anyio.Path(path).exists()`、`async for p in anyio.Path(path).iterdir()` 等。`pathlib.Path` 可用于类型注解和路径拼接（无 IO 操作时）。

示例：

```python
# 正确 ✓ - async tool with anyio.Path
async def tool(file_path: str) -> str:
    path = anyio.Path(file_path)
    if not await path.exists():
        return "File not found"
    content = await path.read_text()
    return content

# 错误 ✗ - 同步 pathlib.Path
def tool(file_path: str) -> str:
    path = Path(file_path)
    if not path.exists():  # 阻塞!
        return "File not found"
    content = path.read_text()  # 阻塞!
    return content

# 正确 ✓ - async tool
async def tool(command: str, timeout: int = 30) -> str:
    process = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await asyncio.wait_for(
        process.communicate(),
        timeout=timeout,
    )
    ...

# 错误 ✗ - 同步 subprocess
def tool(command: str) -> str:
    result = subprocess.run(command, ...)  # 阻塞!
```

### Import 顺序规范

import 语句按以下顺序排列，每组内按字母排序：

1. **stdlib**：Python 标准库模块
2. **third-party**：第三方库（如 aiohttp, anyio, loguru）
3. **local**：本项目内部模块

示例：

```python
# stdlib
import json
from collections.abc import AsyncGenerator
from typing import Any

# third-party
import aiohttp
import anyio
from loguru import logger

# local
from psi_agent.ai.openai_completions.config import OpenAICompletionsConfig
```

此规范符合 ruff isort（`I` 规则）。

### 类型注解规范

**所有 Python 文件必须以 `from __future__ import annotations` 开头**（在模块文档字符串之后）。

这确保：
- 现代 PEP 604 联合语法 (`X | Y`) 在所有上下文中可用
- 前向引用无需字符串引用
- 与未来 Python 版本的行为一致

使用 Python 3.14+ 现代语法：

- **可选类型**：使用 `X | None` 而非 `Optional[X]`
- **联合类型**：使用 `X | Y` 而非 `Union[X, Y]`
- **泛型**：使用 `list[X]`, `dict[K, V]` 而非 `List[X], Dict[K, V]`

示例：

```python
# 正确 ✓
from __future__ import annotations

def func(data: dict[str, Any] | None) -> list[str]:
    ...

# 错误 ✗
from typing import Optional, List, Dict, Union

def func(data: Optional[Dict[str, Any]]) -> List[str]:
    ...
```

### 文档字符串规范

使用 **Google style docstring** 格式。

**函数文档字符串：**

```python
def function(arg1: str, arg2: int) -> bool:
    """简短描述（一行）。

    详细描述（可选，多行）。

    Args:
        arg1: 第一个参数的描述。
        arg2: 第二个参数的描述。

    Returns:
        返回值的描述。

    Raises:
        ValueError: 可能抛出的异常描述。
    """
```

**模块文档字符串：**

```python
"""模块简短描述。

可选的详细描述。
"""
```

**类文档字符串：**

```python
class MyClass:
    """类简短描述。

    详细描述（可选）。

    Attributes:
        attr1: 属性描述。
    """
```

### Async 上下文管理器规范

实现 `__aenter__` 和 `__aexit__` 时：

- `__aenter__`：初始化资源，返回 self
- `__aexit__`：关闭资源，将资源变量设为 `None`，记录日志

示例：

```python
class MyClient:
    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def __aenter__(self) -> MyClient:
        self._session = aiohttp.ClientSession()
        logger.debug("Initialized client session")
        return self

    async def __aexit__(self, _exc_type: Any, _exc_val: Any, _exc_tb: Any) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None
            logger.debug("Closed client session")
```

### 错误处理规范

处理可能失败的异步操作（如网络请求）：

- 使用 `try-except` 捕获异常
- 使用 `loguru` 记录错误（ERROR 级别）
- 返回包含 `error` 和 `status_code` 的 dict

示例：

```python
async def request(url: str) -> dict[str, Any]:
    try:
        async with self._session.post(url) as response:
            if response.status != 200:
                text = await response.text()
                logger.error(f"Request failed: {response.status}")
                return {"error": text, "status_code": response.status}
            return await response.json()
    except aiohttp.ClientConnectorError as e:
        logger.error(f"Connection failed: {e}")
        return {"error": "Connection failed", "status_code": 500}
    except asyncio.TimeoutError as e:
        logger.error(f"Request timeout: {e}")
        return {"error": "Request timeout", "status_code": 500}
```

### 防御性编程规范

**外部数据处理原则：**

所有来自外部源（LLM 响应、用户输入、API 响应）的数据字段都可能为 `null` 或缺失。代码必须在操作前验证字段值。

**Null 检查模式：**

```python
# 正确 ✓ - 使用 dict.get() 检查 null
if data.get("field") is not None:
    result += data["field"]

# 正确 ✓ - 字符串切片前检查
content = delta.get("content")
if content is not None:
    logger.debug(f"Content: {content[:100]}...")

# 错误 ✗ - 假设字段非 null
result += data["field"]  # 可能 TypeError

# 错误 ✗ - "key" in dict 不检查 null 值
if "field" in data:  # data["field"] 可能是 None
    result += data["field"]
```

**适用场景：**
- Streaming delta 字段处理（content、tool_calls、arguments 等）
- LLM 响应解析
- 用户输入验证
- 外部 API 响应处理

**核心规则：** 在字符串拼接 (`+=`)、切片 (`[:]`)、迭代等操作前，必须确认值非 `None`。

### 日志规范

- 使用 **loguru** 进行日志记录
- 在所有关键操作处添加日志：
  - 函数入口/出口
  - 请求接收/转发/响应
  - 错误和异常
  - 配置加载
- 日志级别使用：
  - `DEBUG`：详细调试信息（请求body、响应内容等）
  - `INFO`：正常操作信息（启动、请求接收、连接建立等）
  - `WARNING`：可恢复的问题
  - `ERROR`：错误和异常

**日志粒度标准：**

- **DEBUG 级别**：记录所有组件间通信、组件与外部系统通信的输入输出，包括 HTTP 请求/响应体、工具调用参数和结果、定时任务执行内容、工作区变更检测详情、命令执行详情。敏感数据（API key、token、password）必须掩码为 `***`。
- **INFO 级别**：记录重要生命周期事件和操作摘要，包括组件启动/关闭、请求接收/响应发送、工具加载/更新/移除、定时任务启动/完成、工作区操作。保持各组件粒度一致，不记录完整请求体。

### CLI 规范

- 使用 **tyro** 实现所有命令行接口
- tyro 应该是 Python API 的直接封装：
  - 先定义 Python API 函数（带完整类型注解）
  - 使用 `tyro.cli()` 从函数签名自动生成 CLI
  - 保持 Python API 和 CLI 完全一致
- 示例：

```python
# Python API
def run(
    session_socket: str,
    model: str,
    api_key: str,
    base_url: str = "https://api.openai.com/v1",
) -> None:
    """Run the OpenAI completions server."""
    ...

# CLI 入口
def main() -> None:
    tyro.cli(run)
```

### 测试规范

- 所有 Python API 必须编写单元测试
- 测试放在 `tests/` 目录，结构与 `src/` 对应
- 使用 pytest 作为测试框架
- 测试覆盖：
  - 配置解析
  - API 请求/响应
  - 错误处理
  - 核心逻辑

### Package 结构

- 包名：`psi-agent`
- 源码目录：`src/psi_agent/`
- 子包结构：
  - `psi_agent.ai.*` — psi-ai-* 组件
  - `psi_agent.session` — psi-session 组件
  - `psi_agent.channel.*` — psi-channel-* 组件
  - `psi_agent.workspace.*` — psi-workspace-* 组件

### tool 函数规范

workspace 中 tools 目录下的工具函数规范：

- 入口函数名：`tool`（必须是 async）
- 使用类型注解定义参数类型
- 使用默认值定义可选参数
- 文档字符串描述函数、参数、返回值（Google style）

示例：

```python
# tools/read.py
import anyio

async def tool(file_path: str) -> str:
    """Read file content asynchronously.

    Args:
        file_path: Path to the file to read.

    Returns:
        File content as string.
    """
    async with await anyio.open_file(file_path) as f:
        return await f.read()
```

## 开发工作流

### 包管理

使用 `uv` 管理 Python 包。

### 启动命令示例

psi-agent 提供两种 CLI 接口：

1. **子命令接口（推荐）**：`psi-agent <组件> <子命令>`
2. **独立命令**：`psi-<组件>-<子命令>`

> **开发时运行方式**：在开发过程中，使用 `uv run psi-agent ...` 来运行命令。安装后可直接使用 `psi-agent ...`。

启动 session：

```bash
uv run psi-agent session \
  --workspace ./workspace \
  --channel-socket ./channel.sock \
  --ai-socket ./ai.sock
```

启动 AI 组件（OpenRouter 示例）：

```bash
uv run psi-agent ai openai-completions \
  --session-socket ./ai.sock \
  --model tencent/hy3-preview:free \
  --api-key sk-or-v1-xxxxxx \
  --base-url https://openrouter.ai/api/v1
```

启动 channel（REPL 示例）：

```bash
uv run psi-agent channel repl \
  --session-socket ./channel.sock
```

## Git 工作流规范

### 分支管理

> **⚠️ 禁止直接在 main 分支上工作**
>
> 所有变更必须在 feature 分支上进行，通过 Pull Request 合并到 main。
>
> **正确流程：**
> 1. 从 main 创建 feature 分支：`git checkout -b <feature-name>`
> 2. 在 feature 分支上进行开发和提交
> 3. 推送 feature 分支：`git push -u origin <feature-name>`
> 4. 创建 Pull Request
> 5. 等待 CI 通过后合并
>
> **禁止事项：**
> - 禁止直接在 main 分支上提交
> - 禁止直接 push 到 main 分支
> - 禁止绕过 PR 流程

### OpenSpec 归档

> **⚠️ 重要：OpenSpec 归档目录必须提交到 Git**
>
> 使用 OpenSpec 工作流完成变更后，**必须**将归档目录（`openspec/changes/archive/YYYY-MM-DD-<change-name>/`）连同代码变更一起提交到 Git。这些归档文件记录了变更动机、设计决策和实现步骤，是项目历史的重要组成部分。
>
> **提交前检查清单：**
> 1. 运行 `git status` 检查是否有未跟踪的 `openspec/changes/` 目录
> 2. 确保所有 `openspec/changes/archive/` 目录已添加到暂存区
> 3. 确保新的 `openspec/specs/` 目录（如有）已添加到暂存区
>
> **禁止遗漏归档目录的提交。**

### Git 提交格式