import os

from textual.app import App, ComposeResult
from textual.containers import Vertical
from textual.events import Resize
from textual.widgets import Footer, Static, TextArea

from .lifecycle import clear_tui, install_tui_cleanup_handlers
from .log import SelectableRichLog
from .style import CHAT_CSS
from .transcript import TranscriptRenderer


def composer_height(text):
    useful_lines = max(1, min(10, str(text or "").count("\n") + 1))
    return useful_lines + 2


class AgentTextualApp(App):
    CSS = CHAT_CSS
    TITLE = "Codex Agent"
    BINDINGS = [
        ("ctrl+c", "interrupt", "Interrupt"),
        ("ctrl+l", "clear", "Clear"),
        ("ctrl+q", "quit", "Quit"),
        ("ctrl+s", "submit", "Submit"),
        ("alt+enter", "submit", "Submit"),
        ("ctrl+enter", "submit", "Submit"),
        ("f2", "submit", "Submit"),
    ]

    def __init__(self, chat, mouse_mode_hint, **kwargs):
        super().__init__(**kwargs)
        self.chat = chat
        self.mouse_mode_hint = mouse_mode_hint
        self.transcript_renderer = None
        self._live_delta_flush_scheduled = False

    def compose(self) -> ComposeResult:
        with Vertical(id="main"):
            yield SelectableRichLog(
                id="conversation",
                wrap=True,
                highlight=False,
                markup=True,
                on_scroll_top=self.load_older_transcript,
                on_resize=lambda: self.handle_terminal_resize(log_resized=True),
                right_padding=6,
            )
            yield Static("", id="status")
            yield TextArea(
                "",
                placeholder=f"> message  -  Enter = newline  -  Ctrl+S/F2 = send  -  {self.mouse_mode_hint}",
                id="input",
                show_line_numbers=False,
                soft_wrap=True,
            )
        yield Footer()

    def on_mount(self):
        self.chat.app = self
        self.transcript_renderer = TranscriptRenderer(self.chat, self)
        install_tui_cleanup_handlers()
        self.chat.attach()
        self.chat.client.start_events()
        self.refresh_status()
        self.resize_input()
        self.query_one("#input", TextArea).focus()
        self.write_info(f"Codex Agent client ready - {self.mouse_mode_hint}")

    def on_resize(self, event: Resize):
        self.handle_terminal_resize()

    def handle_terminal_resize(self, *, log_resized=False):
        if getattr(self, "transcript_renderer", None) is None:
            return
        log = self.query_one("#conversation", SelectableRichLog)
        if not log_resized:
            log.invalidate_layout()
        self.render_transcript(keep_scroll=True)
        self.resize_input()
        self.refresh_status()

    def on_unmount(self):
        clear_tui(pid=os.getpid())

    def action_quit(self):
        clear_tui(pid=os.getpid())
        self.chat.client.stop(timeout=0.2)
        self.exit()

    def action_submit(self):
        input_widget = self.query_one("#input", TextArea)
        prompt = input_widget.text
        command = prompt.strip().lower()
        if not command:
            return
        if command in ["exit", "quit", "/exit", "/quit"]:
            self.exit()
            return
        if command == "/clear":
            input_widget.load_text("")
            self.action_clear()
            return
        input_widget.load_text("")
        self.refresh_status()
        self.run_worker(lambda: self._submit_prompt(prompt), thread=True)

    def action_clear(self):
        self.chat.transcript.clear()
        self.query_one("#conversation", SelectableRichLog).clear()
        self.write_info("screen cleared - session history preserved")
        self.refresh_status()

    def action_interrupt(self):
        if self.screen.get_selected_text():
            self.screen.action_copy_text()
            return
        result = self.chat.client.interrupt("keyboard_interrupt")
        self.write_error(f"interrupt requested - {result.error}" if result.get("error") else "interrupt requested")

    def on_text_area_changed(self, event: TextArea.Changed):
        if event.text_area.id == "input":
            self.resize_input()

    def resize_input(self):
        input_widget = self.query_one("#input", TextArea)
        input_widget.styles.height = composer_height(input_widget.text)

    def _submit_prompt(self, prompt):
        try:
            self.chat.client.submit_prompt(prompt)
        except Exception as exc:
            self.call_from_thread(self.write_error, str(exc))
        finally:
            self.call_from_thread(self.refresh_status)

    def render_transcript(self, *, keep_scroll=False):
        self.transcript_renderer.render(keep_scroll=keep_scroll)

    def begin_transcript_batch(self):
        self.transcript_renderer.begin_batch()

    def end_transcript_batch(self):
        self.transcript_renderer.end_batch()

    def load_older_transcript(self):
        self.transcript_renderer.load_older()

    def write_user(self, prompt):
        self.chat.transcript.append_user(prompt, self.chat.username())
        self.render_transcript()

    def ensure_agent_role(self, name=None):
        if self.chat.transcript.ensure_agent(name or self.chat.agent_name()):
            self.render_transcript()

    def write_agent_start(self, name):
        self.chat.begin_turn_rendering()

    def start_agent_step(self):
        self.chat.transcript.begin_step()
        self.render_transcript()

    def write_agent_delta(self, delta):
        self.ensure_agent_role()
        previous_text = self.chat.transcript.agent_buffer
        self.chat.transcript.apply_agent_delta(delta)
        self.chat.transcript.step_had_content = True
        if not self.transcript_renderer.update_last_agent(delta, previous_text):
            self.render_transcript()

    def schedule_agent_delta_flush(self):
        if self._live_delta_flush_scheduled:
            return
        self._live_delta_flush_scheduled = True
        self.set_timer(self.chat.live_delta.interval, self.flush_agent_delta)

    def flush_agent_delta(self):
        self._live_delta_flush_scheduled = False
        delta = self.chat.live_delta.pop()
        if delta:
            self.write_agent_delta(delta)

    def write_tool(self, name, call_id=None, status=None):
        self.flush_agent_delta()
        self.ensure_agent_role()
        self.chat.transcript.append_tool(name, call_id=call_id, status=status)
        self.render_transcript()

    def write_slash_command(self, name, args="", status=None):
        self.flush_agent_delta()
        self.ensure_agent_role()
        self.chat.transcript.append_slash_command(name, args=args, status=status)
        self.render_transcript()

    def end_agent_step(self):
        self.flush_agent_delta()
        self.chat.transcript.end_step()
        self.render_transcript()

    def write_info(self, text):
        self.chat.transcript.append_info(text)
        self.render_transcript()

    def write_error(self, text):
        self.chat.transcript.append_error(text)
        self.render_transcript()

    def refresh_status(self):
        self.query_one("#status", Static).update(self.chat.status_renderable())
