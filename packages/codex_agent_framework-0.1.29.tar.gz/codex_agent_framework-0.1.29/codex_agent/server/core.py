import json
import os
import queue
import threading
import time
import uuid
from collections import deque

from modict import modict

from ..agent import Agent
from ..agent_runtime import AgentRuntime
from ..event import Event
from ..message import DeveloperMessage
from ..sessions import AgentSession
from ..service import pop_restart_wakeup, restart_server_service, write_restart_wakeup
from ..utils import ensure_runtime_dir, runtime_join
from ..tui import clear_tui, current_tui, open_tui_terminal, terminate_tui



SERVER_CONFIG_FILE = "server-config.json"
SERVER_EVENTS_FILE = "server-events.jsonl"

def server_events_file():
    return runtime_join(SERVER_EVENTS_FILE)

def server_config_file():
    return runtime_join(SERVER_CONFIG_FILE)

def load_server_config():
    ensure_runtime_dir()
    path = server_config_file()
    if not os.path.isfile(path):
        return modict()
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return modict()
    return modict(data or {})

def save_server_config(config=None, **kwargs):
    ensure_runtime_dir()
    data = modict(config or {})
    data.update(kwargs)
    path = server_config_file()
    tmp_path = f"{path}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)
    return data

def remembered_server_session():
    config = load_server_config()
    session_id = config.get("current_session_id")
    if not session_id:
        return None
    return session_id if AgentSession.can_load(session_id) else None

def create_server_agent(**agent_kwargs):
    if "session" not in agent_kwargs:
        agent_kwargs["session"] = remembered_server_session() or "latest"
    return Agent(**agent_kwargs)

class AgentServer:
    """Thin REST/SSE bridge over one long-lived Agent instance.

    The server deliberately keeps the Python Agent API shape visible: most
    methods return the same modict/dict-backed objects that direct Python code
    would receive.
    """

    def __init__(self, runtime: AgentRuntime, *, max_events: int = 1000):
        if runtime is None:
            raise ValueError("AgentServer requires an AgentRuntime")
        self.runtime = runtime
        self.max_events = max_events
        self.events = deque(maxlen=max_events)
        self.event_lock = threading.Lock()
        self.persistence_lock = threading.Lock()
        self.event_sequence = 0
        self.current_turn_events = []
        self.turn_replay_active = False
        self.restore_persisted_turn_events()
        self.subscribers = {}
        self.subscriber_lock = threading.Lock()
        self.shutdown_requested = threading.Event()
        self.restart_lock = threading.Lock()
        self.pending_restart = None
        self.runtime.on_event(self._on_agent_event)
        self.runtime.on_event(self._handle_runtime_side_effects)
        self.persist_current_session()

    def start(self):
        self.runtime.start()
        self.persist_current_session()
        self.consume_restart_wakeup()
        return self
    def persist_current_session(self):
        if not self.current_session_id:
            return load_server_config()
        config = load_server_config()
        if config.get("current_session_id") == self.current_session_id:
            return config
        config.current_session_id = self.current_session_id
        config.updated_at = time.time()
        return save_server_config(config)

    def stop(self, timeout=None):
        self.close_subscribers("server shutdown")
        self.runtime.stop(timeout=timeout)
        return self

    @property
    def busy(self):
        return self.runtime.busy

    @property
    def current_turn_id(self):
        return self.runtime.current_turn_id

    @property
    def current_session_id(self):
        return self.runtime.current_session_id

    def restore_persisted_turn_events(self):
        path = server_events_file()
        if not os.path.isfile(path):
            return []
        restored = []
        try:
            with open(path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        restored.append(modict(json.loads(line)))
                    except json.JSONDecodeError:
                        continue
        except OSError:
            return []
        if not restored:
            return []
        with self.event_lock:
            self.current_turn_events = restored
            self.turn_replay_active = self.turn_events_are_active(restored)
            self.events.extend(restored)
            self.event_sequence = max(
                [self.event_sequence]
                + [int(event.get("sequence") or 0) for event in restored]
            )
        return restored

    def write_persisted_turn_events(self, events=None):
        ensure_runtime_dir()
        path = server_events_file()
        tmp_path = f"{path}.tmp"
        events = list(self.current_turn_events if events is None else events)
        with self.persistence_lock:
            with open(tmp_path, "w", encoding="utf-8") as f:
                for event in events:
                    f.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")
            os.replace(tmp_path, path)
        return len(events)

    def append_persisted_turn_event(self, payload):
        ensure_runtime_dir()
        with self.persistence_lock:
            with open(server_events_file(), "a", encoding="utf-8") as f:
                f.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")

    def _on_agent_event(self, event):
        self.publish(self.event_payload(event))

    def _handle_runtime_side_effects(self, event):
        event_type = event.get("type") if isinstance(event, (dict, modict)) else getattr(event, "type", "")
        if event_type == "assistant_turn_end_event":
            self._on_assistant_turn_end(event)
        elif event_type == "session_loaded_event":
            self._on_session_loaded(event)

    def _on_assistant_turn_end(self, event):
        self.trigger_pending_restart()
    def _on_session_loaded(self, event):
        self.persist_current_session()

    def event_payload(self, event):
        if isinstance(event, Event):
            payload = event.copy()
        elif isinstance(event, (dict, modict)):
            payload = modict(event)
        else:
            payload = modict(type=type(event).__name__, value=str(event))
        payload.setdefault("type", getattr(event, "type", type(event).__name__))
        return payload

    def publish(self, payload):
        payload = modict(payload)
        persist_mode = None
        persist_events = None
        with self.event_lock:
            self.event_sequence += 1
            payload.setdefault("id", str(uuid.uuid4()))
            payload.setdefault("sequence", self.event_sequence)
            if self.current_session_id and not payload.get("session_id"):
                payload.session_id = self.current_session_id
            self.events.append(payload)
            if payload.get("type") == "assistant_turn_start_event":
                self.current_turn_events = [payload]
                self.turn_replay_active = True
                persist_mode = "rewrite"
                persist_events = list(self.current_turn_events)
            elif self.current_turn_events and self.turn_replay_active:
                self.current_turn_events.append(payload)
                persist_mode = "append"
                if payload.get("type") in ("assistant_turn_end_event", "assistant_turn_error_event"):
                    self.turn_replay_active = False
        if persist_mode == "rewrite":
            self.write_persisted_turn_events(persist_events)
        elif persist_mode == "append":
            self.append_persisted_turn_event(payload)
        with self.subscriber_lock:
            subscribers = list(self.subscribers)
        for subscriber in subscribers:
            subscriber.put(payload)
        return payload

    def replay_events(self, before_sequence=None, session_id=None):
        """Return the latest known turn for TUI bootstrap.

        The turn buffer is cleared only when a new turn starts, so an idle TUI
        still replays the previous completed turn.
        """
        session_id = session_id or self.current_session_id
        with self.event_lock:
            events = list(self.current_turn_events)
        if session_id is not None and not self.events_belong_to_session(events, session_id):
            events = []
        if before_sequence is not None:
            before_sequence = int(before_sequence)
            events = [event for event in events if int(event.get("sequence") or 0) <= before_sequence]
        return modict(events=events)

    def events_belong_to_session(self, events, session_id):
        if not events:
            return True
        session_id = str(session_id)
        for event in events:
            event_session_id = event.get("session_id")
            if event_session_id is not None:
                return str(event_session_id) == session_id
        return False

    def event_belongs_to_session(self, event, session_id):
        if session_id is None:
            return True
        event_session_id = event.get("session_id")
        return event_session_id is not None and str(event_session_id) == str(session_id)

    def turn_events_are_active(self, events):
        for event in reversed(events):
            event_type = event.get("type")
            if event_type in ("assistant_turn_end_event", "assistant_turn_error_event"):
                return False
            if event_type == "assistant_turn_start_event":
                return True
        return False

    def prune_subscribers(self):
        for subscriber, state in list(self.subscribers.items()):
            if not state.thread.is_alive():
                self.subscribers.pop(subscriber, None)
        return len(self.subscribers)

    def subscriber_count(self):
        if not self.subscriber_lock.acquire(timeout=0.05):
            return len(self.subscribers)
        try:
            self.prune_subscribers()
            return len(self.subscribers)
        finally:
            self.subscriber_lock.release()

    def close_subscribers(self, reason="server shutdown"):
        self.shutdown_requested.set()
        with self.subscriber_lock:
            subscribers = list(self.subscribers)
        for subscriber in subscribers:
            subscriber.put(modict(type="server_shutdown", reason=reason))

    def replace_subscribers(self, reason="subscription replaced"):
        if not self.subscribers:
            return
        for subscriber in list(self.subscribers):
            subscriber.put(modict(type="server_shutdown", reason=reason))
        self.subscribers.clear()

    def subscribe(self, after_sequence=None, client_pid=None):
        after_sequence = int(after_sequence) if after_sequence is not None else None
        client_pid = int(client_pid) if client_pid is not None else None
        subscriber, replay = self.open_subscription(after_sequence=after_sequence, client_pid=client_pid)
        return self.subscription_stream(subscriber, replay)

    def open_subscription(self, after_sequence=None, client_pid=None):
        if not self.subscriber_lock.acquire(timeout=1.0):
            raise RuntimeError("event subscription manager is busy")
        try:
            self.shutdown_requested.clear()
            self.prune_subscribers()
            self.ensure_subscription_allowed(client_pid)
            self.replace_subscribers(reason="subscription replaced")
            subscriber = queue.Queue()
            self.subscribers[subscriber] = modict(
                thread=threading.current_thread(),
                started_at=time.time(),
                client_pid=client_pid,
            )
            return subscriber, self.subscription_replay(after_sequence)
        finally:
            self.subscriber_lock.release()

    def ensure_subscription_allowed(self, client_pid=None):
        tui = current_tui()
        if self.subscribers and tui and client_pid != int(tui.get("pid") or -1):
            raise RuntimeError("an event client is already connected")

    def subscription_replay(self, after_sequence=None):
        with self.event_lock:
            replay_before_sequence = self.event_sequence
            session_id = self.current_session_id
            missed_events = [
                event for event in self.events
                if after_sequence is not None
                and int(event.get("sequence") or 0) > after_sequence
                and int(event.get("sequence") or 0) <= replay_before_sequence
                and self.event_belongs_to_session(event, session_id)
            ]
        return modict(
            after_sequence=after_sequence,
            before_sequence=replay_before_sequence,
            session_id=session_id,
            events=missed_events,
        )

    def subscription_started_event(self, replay):
        return modict(
            type="server_subscribed",
            id=str(uuid.uuid4()),
            busy=self.busy,
            session_id=replay.session_id,
            replay_before_sequence=replay.before_sequence,
            after_sequence=replay.after_sequence,
            replayed_events=len(replay.events),
        )

    def subscription_stream(self, subscriber, replay):
        try:
            yield self.subscription_started_event(replay)
            yield from replay.events
            while True:
                try:
                    payload = subscriber.get(timeout=0.25)
                except queue.Empty:
                    if self.shutdown_requested.is_set():
                        break
                    payload = modict(type="server_ping")
                yield payload
                if payload.get("type") == "server_shutdown":
                    break
        finally:
            self.close_subscription(subscriber)

    def close_subscription(self, subscriber):
        if not self.subscriber_lock.acquire(timeout=1.0):
            return
        try:
            self.subscribers.pop(subscriber, None)
        finally:
            self.subscriber_lock.release()

    def status(self):
        status = self.runtime.get_status()
        activity = status.get("activity") or {}
        stale_timeout = activity.get("stall_timeout") or 120
        status.update(
            busy=self.busy,
            current_turn_id=self.current_turn_id,
            subscribers=self.subscriber_count(),
            event_backlog=len(self.events),
            event_stream=self.event_stream_status(stale_timeout=stale_timeout),
        )
        self.persist_current_session()
        return status

    def event_stream_status(self, stale_timeout=120):
        with self.event_lock:
            active = bool(self.turn_replay_active)
            current_turn_events = list(self.current_turn_events)
            source_events = current_turn_events if current_turn_events else list(self.events)
            last_event = next(
                (event for event in reversed(source_events) if event.get("type") != "status_updated_event"),
                None,
            )
        last_timestamp = self.event_timestamp(last_event)
        now = time.time()
        return modict(
            active=active,
            last_event_type=last_event.get("type") if last_event else None,
            last_event_sequence=last_event.get("sequence") if last_event else None,
            last_event_timestamp=last_event.get("timestamp") if last_event else None,
            idle_seconds=(now - last_timestamp) if last_timestamp is not None else None,
            current_turn_event_count=len(current_turn_events),
            stale=bool(self.busy and active and last_timestamp is not None and now - last_timestamp > float(stale_timeout)),
            stale_timeout=float(stale_timeout),
        )

    def event_timestamp(self, event):
        if not event:
            return None
        value = event.get("timestamp")
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            try:
                return time.mktime(time.strptime(value.split(".")[0], "%Y%m%dT%H%M%S"))
            except ValueError:
                return None
        return None

    def config(self):
        return self.runtime.config()

    def update_config(self, values=None, save=True, **kwargs):
        return self.runtime.update_config(values, save=save, **kwargs)

    def session(self):
        return self.runtime.session()

    def sessions(self):
        return self.runtime.sessions()

    def messages(self):
        return self.runtime.messages()

    def tools(self):
        return self.runtime.tools()

    def tui(self):
        return current_tui() or modict()

    def open_tui(self, base_url="http://127.0.0.1:8765"):
        tui = current_tui()
        if tui:
            return modict(opened=False, already_open=True, tui=tui)
        process = open_tui_terminal(base_url=base_url)
        if process is None:
            raise RuntimeError("no supported terminal emulator was found")
        return modict(opened=True, terminal_pid=process.pid, base_url=str(base_url).rstrip("/"))

    def close_tui(self):
        tui = current_tui()
        if not tui:
            return modict(closed=False, reason="no active TUI")
        terminate_tui(tui.pid)
        clear_tui(pid=tui.pid)
        return modict(closed=True, pid=tui.pid)

    def wakeups(self, include_done=True):
        return self.runtime.wakeups(include_done=include_done)

    def consume_restart_wakeup(self):
        payload = pop_restart_wakeup()
        if not payload:
            return None
        prompt = payload.get("prompt")
        title = payload.get("title") or "post-restart wakeup"
        if not prompt or not str(prompt).strip():
            return None
        wakeup_prompt = (
            f"Post-restart wakeup ({title}).\n"
            "The agent server has restarted and found a persisted restart wakeup request.\n"
            f"Original prompt:\n{prompt}"
        )
        result = self.runtime.submit_message(DeveloperMessage(content=wakeup_prompt))
        turn_id = result.get("turn_id")
        return modict(triggered=True, title=title, future_id=turn_id)

    def restart(self, prompt=None, title="post-restart wakeup", delay_seconds=0.5):
        wakeup_persisted = bool(prompt and str(prompt).strip())
        if wakeup_persisted:
            write_restart_wakeup(prompt=prompt, title=title)
        with self.restart_lock:
            already_pending = self.pending_restart is not None
            self.pending_restart = modict(
                service="codex-agent.service",
                wakeup_persisted=wakeup_persisted,
                requested_at=time.time(),
                delay_seconds=float(delay_seconds or 0),
            )
        if not self.busy:
            self.trigger_pending_restart()
        return modict(
            restarting=True,
            restart_pending=True,
            already_pending=already_pending,
            wakeup_persisted=wakeup_persisted,
            service="codex-agent.service",
        )

    def trigger_pending_restart(self):
        with self.restart_lock:
            pending = self.pending_restart
            self.pending_restart = None
        if not pending:
            return None

        def target():
            time.sleep(float(pending.get("delay_seconds") or 0))
            restart_server_service()

        threading.Thread(target=target, name="agent-server-restart", daemon=True).start()
        return pending

    def schedule_wakeup(self, **kwargs):
        return self.runtime.schedule_wakeup(**kwargs)

    def cancel_wakeup(self, job_id):
        return self.runtime.cancel_wakeup(job_id)

    def delete_wakeup(self, job_id):
        return self.runtime.delete_wakeup(job_id)

    def start_new_session(self):
        self.require_idle()
        session = self.runtime.start_new_session()
        self.persist_current_session()
        return session

    def load_session(self, session_id):
        self.require_idle()
        session = self.runtime.load_session(session_id)
        self.persist_current_session()
        return session

    def delete_session(self, session_id):
        self.require_idle()
        result = self.runtime.delete_session(session_id)
        self.persist_current_session()
        return result

    def navigate_session(self, direction):
        self.require_idle()
        session = self.runtime.navigate_session(direction)
        self.persist_current_session()
        return session

    def interrupt(self, reason="api"):
        try:
            result = modict(self.runtime.interrupt(reason) or {})
        except Exception as exc:
            return modict(interrupted=False, interrupt_requested=True, error=str(exc))
        return result

    def submit_prompt(self, prompt: str):
        return self.runtime.submit_prompt(prompt)

    def require_idle(self):
        if self.busy:
            raise RuntimeError("agent is busy")
