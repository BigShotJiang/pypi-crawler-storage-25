"""Built-in Python REPL plugin."""

import os
import sys

from pynteract import Shell

from ...plugin import Plugin
from ...tool import tool


class PythonPlugin(Plugin):
    name = "python"
    description = "Run Python code in a persistent interactive shell."
    prefix_tools = False
    system_prompt = """
# Python Tool

Via the `python` tool you may execute Python code in a persistent interactive session.
In that Python shell, the name `agent` is automatically injected and points to your current Agent instance. You may use it for self-reference or inspection, or to call tools and Agent methods programmatically when useful.

Pass raw Python source code to the tool, not JSON, quotes, or a markdown code fence.
Use discernment before running code that could compromise sensitive data or system integrity.
"""

    def __init__(self, agent):
        super().__init__(agent)
        shell = Shell(silent=True)
        shell.update_namespace(
            agent=agent,
            os=os,
            sys=sys,
            python_executable=sys.executable,
        )
        self.shell = shell

    @tool(name="python", tool_type="custom")
    def python(self, content=None):
        """
        Runs Python code in the interactive shell. Pass raw Python source code,
        not JSON, quotes, or a markdown code fence.
        """
        if self.shell is not None and content:
            hook = self.agent.run_hook("shell.python.before", content=content)
            content = hook.payload.content
            response = self.shell.run(content)
            if response.exception:
                exception = response.exception
                return f"**{type(exception).__name__}**: {str(exception)}\n```\n{exception.enriched_traceback_string}\n```"

            output = ""
            if response.stdout:
                output += f"stdout:\n{response.stdout}"
            if response.result:
                output += f"result:\n{str(response.result)}"
            return output

        return "Shell not initialized. Cannot run code."
