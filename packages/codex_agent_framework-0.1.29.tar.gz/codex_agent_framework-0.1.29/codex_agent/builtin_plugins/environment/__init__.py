"""Built-in runtime environment plugin."""

from datetime import datetime
import os

from modict import modict

from ...plugin import Plugin
from ...provider import provider
from ...tool import tool


class EnvironmentPlugin(Plugin):
    name = "environment"
    description = "Runtime environment information plus loaded/loadable plugin introspection and controls."
    system_prompt = """
# Runtime Environment

Your agent's workfolder is located at: <<agent.config.workfolder>> (Use it to store files you generate or download)
Agent runtime dir: <<agent.config.runtime_dir>>
Agent source dir: <<agent.config.source_dir>>
Platform: <<agent.config.platform>>
"""

    @provider
    def date_and_time(self):
        now = datetime.now().astimezone()
        return f"Current date and time: {now.strftime('%Y-%m-%d %H:%M:%S %Z%z')}"

    @provider
    def cwd(self):
        return f"Current working directory: {os.getcwd()}"

    def plugin_catalog(self):
        return self.agent.plugins_manager.plugin_infos()

    def plugin_public_info(self, info):
        return modict(
            name=info.name,
            kind=info.kind,
            loaded=info.loaded,
            enabled=info.enabled,
            loadable=info.loadable,
            requires_openai=info.requires_openai,
            description=info.description,
            path=info.path,
            requirements_file=info.get("requirements_file"),
            requirements=list(info.get("requirements") or []),
        )

    @provider
    def plugins_status(self):
        """Describe currently loaded and loadable plugins."""
        infos = sorted(self.plugin_catalog(), key=lambda item: (item.kind, item.name))
        if not infos:
            return "Plugins: no loadable plugin discovered."

        lines = ["Plugins loaded/loadable:"]
        for info in infos:
            state = "loaded" if info.loaded else "available"
            if not info.enabled:
                state = f"{state}, disabled by startup config"
            if not info.loadable:
                state = f"{state}, not loadable"
            description = f" — {info.description}" if info.description else ""
            lines.append(f"- {info.name} ({info.kind}, {state}){description}")
        lines.append("Plugin tools: environment_list_plugins, environment_load_plugin, environment_unload_plugin, environment_reload_plugin.")
        return "\n".join(lines)

    @tool
    def list_plugins(self):
        """
        description: List loaded and loadable plugins with descriptions and state.
        parameters: {}
        required: []
        """
        return [self.plugin_public_info(info) for info in self.plugin_catalog()]

    @tool
    def load_plugin(self, name: str, kind: str = "auto"):
        """
        description: Load a builtin or runtime plugin dynamically by name.
        parameters:
          name:
            type: string
            description: Plugin name, runtime plugin file path, or runtime plugin module stem.
          kind:
            type: string
            enum: [auto, builtin, runtime]
            description: Plugin source kind. Use auto to prefer a discovered builtin/runtime match.
            default: auto
        required: [name]
        """
        kind = str(kind or "auto")
        if name == self.name:
            return {"status": "loaded", "plugin": name, "message": "environment plugin is already loaded"}
        before = set(self.agent.plugins)
        if kind == "builtin":
            loaded = self.agent.load_builtin_plugin(name)
        elif kind == "runtime":
            loaded = self.agent.load_runtime_plugin(name)
        elif kind == "auto":
            info = self.agent.plugins_manager.plugin_info(name)
            if info is None:
                raise ValueError(f"Unknown plugin: {name}")
            if info.loaded:
                return {"status": "loaded", "plugin": info.name, "message": "plugin already loaded"}
            if not info.loadable:
                raise RuntimeError(f"Plugin {info.name!r} is not loadable")
            if info.kind == "builtin":
                loaded = self.agent.load_builtin_plugin(info.name)
            elif info.kind == "runtime":
                loaded = self.agent.load_runtime_plugin(info.path or info.name)
            else:
                raise ValueError(f"Unsupported plugin kind: {info.kind}")
        else:
            raise ValueError("kind must be one of: auto, builtin, runtime")
        loaded_names = [plugin.name for plugin in loaded]
        return {"status": "loaded", "plugins": loaded_names, "new_plugins": sorted(set(self.agent.plugins) - before)}

    @tool
    def unload_plugin(self, name: str):
        """
        description: Unload a currently loaded plugin dynamically.
        parameters:
          name:
            type: string
            description: Loaded plugin name to unload.
        required: [name]
        """
        if name == self.name:
            raise ValueError("The environment plugin cannot unload itself because it owns this control surface")
        result = self.agent.unload_plugin(name)
        if result is None:
            return {"status": "not_loaded", "plugin": name}
        removed = {key: sorted(value.keys()) if hasattr(value, "keys") else len(value) for key, value in result.removed.items()}
        return {"status": "unloaded", "plugin": name, "removed": removed}

    @tool
    def reload_plugin(self, name: str):
        """
        description: Reload a currently loaded plugin dynamically.
        parameters:
          name:
            type: string
            description: Loaded plugin name to reload.
        required: [name]
        """
        if name == self.name:
            raise ValueError("The environment plugin cannot reload itself because it owns this control surface")
        plugin = self.agent.reload_plugin(name)
        return {"status": "reloaded", "plugin": plugin.name}
