import asyncio
import html
import logging
import re
from dataclasses import dataclass, field

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import BotCommand, CallbackQuery, FSInputFile, InlineKeyboardMarkup, MenuButtonCommands, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from grabber.core.bot.config import BotSettings, get_settings
from grabber.core.bot.infrastructure.asset_files import AssetFileService
from grabber.core.bot.usecases.source_posting import SourcePostingRequest, SourcePostingUseCase
from grabber.core.extractor.constants import QUERY_MAPPING
from grabber.core.extractor.infrastructure.checkpoints import build_checkpoint_service
from grabber.core.extractor.infrastructure.checkpoints.url_normalizer import normalize_source_url
from grabber.core.extractor.sources.fapello.notifications import (
    FapelloNotificationAuthError,
)
from grabber.core.extractor.sources.fapello.notifications import (
    retrieve_image_urls as retrieve_fapello_image_urls,
)
from grabber.core.extractor.sources.fapello.notifications import (
    retrieve_profile_urls as retrieve_fapello_profile_urls,
)
from grabber.core.extractor.sources.fapello.search import (
    FapelloSearchAuthError,
)
from grabber.core.extractor.sources.fapello.search import (
    format_search_results as format_fapello_search_results,
)
from grabber.core.extractor.sources.fapello.search import (
    search_models as search_fapello_models,
)
from grabber.core.extractor.sources.picazor.notifications import (
    PicazorNotificationAuthError,
)
from grabber.core.extractor.sources.picazor.notifications import (
    retrieve_album_urls as retrieve_picazor_album_urls,
)
from grabber.core.extractor.sources.picazor.notifications import (
    retrieve_profile_urls as retrieve_picazor_profile_urls,
)
from grabber.core.settings import CHECKPOINT_FILE_PATH

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
ASSET_PAGE_SIZE = 10
TELEGRAM_SAFE_TEXT_LIMIT = 3900
TELEGRAM_MESSAGE_MAX_LEN = 4000
TRUNCATED_PREVIEW_NOTE = "\n\nPreview truncated. Full file sent as a document below."


def _split_text(text: str, max_len: int = TELEGRAM_MESSAGE_MAX_LEN) -> list[str]:
    lines = text.splitlines(keepends=True)
    chunks: list[str] = []
    current = ""
    for line in lines:
        if len(current) + len(line) > max_len:
            if current:
                chunks.append(current.rstrip())
            current = line
        else:
            current += line
    if current.strip():
        chunks.append(current.rstrip())
    return chunks or [""]


class UrlExtractor:
    URL_RE = re.compile(r"https?://\S+")

    @classmethod
    def extract(cls, text: str) -> list[str]:
        if not text:
            return []

        urls = cls.URL_RE.findall(text)
        seen = set()
        unique_urls: list[str] = []
        for url in urls:
            if url in seen:
                continue
            seen.add(url)
            unique_urls.append(url)

        return unique_urls


@dataclass(slots=True)
class PendingNotificationState:
    waiting_for_number: set[int] = field(default_factory=set)
    pending_provider: dict[int, str] = field(default_factory=dict)
    pending_mode: dict[int, str] = field(default_factory=dict)

    def set_provider(self, user_id: int, provider: str) -> None:
        self.pending_provider[user_id] = provider

    def set_mode(self, user_id: int, mode: str) -> None:
        self.pending_mode[user_id] = mode
        self.waiting_for_number.add(user_id)

    def is_waiting_for_number(self, user_id: int) -> bool:
        return user_id in self.waiting_for_number

    def get_provider(self, user_id: int) -> str | None:
        return self.pending_provider.get(user_id)

    def get_mode(self, user_id: int) -> str | None:
        return self.pending_mode.get(user_id)

    def clear(self, user_id: int) -> None:
        self.pending_provider.pop(user_id, None)
        self.pending_mode.pop(user_id, None)
        self.waiting_for_number.discard(user_id)


class ChannelKeyboardFactory:
    def __init__(self, channels: dict[str, str]) -> None:
        self.channels = channels

    def build(self) -> InlineKeyboardMarkup:
        keyboard = InlineKeyboardBuilder()
        for channel_name in self.channels:
            keyboard.button(text=channel_name, callback_data=f"ch:{channel_name}")
        keyboard.adjust(2)
        return keyboard.as_markup()


@dataclass(slots=True)
class PendingPostingState:
    pending_links: dict[int, list[str]] = field(default_factory=dict)
    waiting_for_pages: set[int] = field(default_factory=set)
    pending_max_pages: dict[int, int] = field(default_factory=dict)

    def queue_links(self, user_id: int, links: list[str]) -> list[str]:
        queued = self.pending_links.get(user_id, [])
        queued.extend(links)
        self.pending_links[user_id] = queued
        return queued

    def pop_links(self, user_id: int) -> list[str] | None:
        return self.pending_links.pop(user_id, None)

    def mark_waiting_for_pages(self, user_id: int) -> None:
        self.waiting_for_pages.add(user_id)

    def is_waiting_for_pages(self, user_id: int) -> bool:
        return user_id in self.waiting_for_pages

    def set_max_pages(self, user_id: int, max_pages: int) -> None:
        self.pending_max_pages[user_id] = max_pages
        self.waiting_for_pages.discard(user_id)

    def get_max_pages(self, user_id: int) -> int | None:
        return self.pending_max_pages.get(user_id)

    def clear(self, user_id: int) -> None:
        self.pending_links.pop(user_id, None)
        self.pending_max_pages.pop(user_id, None)
        self.waiting_for_pages.discard(user_id)


class InteractivePostingBot:
    def __init__(
        self,
        settings: BotSettings | None = None,
        source_posting_usecase: SourcePostingUseCase | None = None,
        asset_file_service: AssetFileService | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.source_posting_usecase = source_posting_usecase or SourcePostingUseCase()
        self.url_extractor = UrlExtractor()
        self.state = PendingPostingState()
        self.keyboard_factory = ChannelKeyboardFactory(self.settings.channels)
        self.checkpoint_service = build_checkpoint_service()
        self.asset_file_service = asset_file_service or AssetFileService()

        self.notif_state = PendingNotificationState()

        self.bot = Bot(
            self.settings.bot_token,
            default=DefaultBotProperties(parse_mode="HTML"),
        )
        self.dispatcher = Dispatcher()
        self.router = Router()
        self.dispatcher.include_router(self.router)
        self._register_handlers()

    def _register_handlers(self) -> None:
        self.router.message(Command("start"))(self.start_cmd)
        self.router.message(Command("post"))(self.post_cmd)
        self.router.message(Command("entities"))(self.entities_cmd)
        self.router.message(Command("assets"))(self.assets_cmd)
        self.router.message(Command("notifications"))(self.notifications_cmd)
        self.router.message(Command("search"))(self.search_cmd)
        self.router.message(Command("checkpoint_inspect"))(self.checkpoint_inspect_cmd)
        self.router.message(Command("checkpoint_clear"))(self.checkpoint_clear_cmd)
        self.router.message(F.text & F.text.regexp(r"^\s*(?:\d+|All|all|\*)\s*$"))(self.on_pages_input)
        self.router.message(F.text.func(lambda text: text and "http" in text))(self.on_text_with_links)
        self.router.callback_query(F.data.startswith("asset:"))(self.on_asset_callback)
        self.router.callback_query(F.data.startswith("notif:"))(self.on_notification_callback)
        self.router.callback_query(F.data.startswith("ch:"))(self.on_channel_choice)

    async def start_cmd(self, message: Message) -> None:
        await message.reply(
            "Send me links (pages or direct image URLs). Then pick a channel and I'll post everything there.\n"
            "Supported entities list:\n"
            "- /entities\n"
            "Notifications:\n"
            "- /notifications\n"
            "Search:\n"
            "- /search fapello &lt;query&gt;\n"
            "Asset browser:\n"
            "- /assets\n"
            "Checkpoint helpers:\n"
            "- /checkpoint_inspect &lt;url&gt;\n"
            "- /checkpoint_clear &lt;url&gt;"
        )

    @staticmethod
    def _build_entities_text() -> str:
        websites = "All websites supported:\n"
        entities = sorted(QUERY_MAPPING.keys())
        for entity in entities:
            websites += f"\t- {entity}\n"
        return websites

    async def entities_cmd(self, message: Message) -> None:
        await message.reply(self._build_entities_text())

    async def notifications_cmd(self, message: Message) -> None:
        await message.reply(
            "Choose a notifications provider:",
            reply_markup=self._build_notification_provider_keyboard(),
        )

    async def search_cmd(self, message: Message) -> None:
        raw = (message.text or "").split(maxsplit=2)
        if len(raw) < 3:
            await message.reply("Usage: <code>/search fapello &lt;query&gt;</code>")
            return

        provider = raw[1].lower()
        query = raw[2].strip()

        if provider != "fapello":
            await message.reply(
                f"Unsupported search provider: <code>{html.escape(provider)}</code>\nSupported: <code>fapello</code>"
            )
            return
        if not query:
            await message.reply("Usage: <code>/search fapello &lt;query&gt;</code>")
            return

        await message.reply(f"Searching Fapello for <b>{html.escape(query)}</b>…")
        try:
            results = await asyncio.to_thread(search_fapello_models, query)
        except FapelloSearchAuthError as exc:
            await message.reply(f"Auth error: <code>{html.escape(str(exc))}</code>")
            return
        except Exception as exc:
            logger.exception("Fapello search failed for query: %s", query)
            await message.reply(f"Search failed: <code>{html.escape(str(exc))}</code>")
            return

        if not results:
            await message.reply("No results found.")
            return

        text = format_fapello_search_results(results)
        for chunk in _split_text(text):
            await message.reply(chunk, parse_mode=None)

    def _build_notification_provider_keyboard(self) -> InlineKeyboardMarkup:
        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="Fapello", callback_data="notif:provider:fapello")
        keyboard.button(text="Picazor", callback_data="notif:provider:picazor")
        keyboard.adjust(2)
        return keyboard.as_markup()

    def _build_notification_mode_keyboard(self, provider: str) -> InlineKeyboardMarkup:
        keyboard = InlineKeyboardBuilder()
        if provider == "fapello":
            keyboard.button(text="Images", callback_data=f"notif:mode:{provider}:images")
            keyboard.button(text="Profiles", callback_data=f"notif:mode:{provider}:profiles")
        elif provider == "picazor":
            keyboard.button(text="Albums", callback_data=f"notif:mode:{provider}:albums")
            keyboard.button(text="Profiles", callback_data=f"notif:mode:{provider}:profiles")
        keyboard.adjust(2)
        return keyboard.as_markup()

    async def on_notification_callback(self, callback: CallbackQuery) -> None:
        if not callback.data:
            await callback.answer("Invalid action.", show_alert=True)
            return

        parts = callback.data.split(":")
        if len(parts) < 2 or parts[0] != "notif":
            await callback.answer("Invalid action.", show_alert=True)
            return

        action = parts[1]
        if action == "provider":
            await self._handle_notif_provider(callback, parts)
        elif action == "mode":
            await self._handle_notif_mode(callback, parts)
        else:
            await callback.answer("Unknown action.", show_alert=True)

    async def _handle_notif_provider(self, callback: CallbackQuery, parts: list[str]) -> None:
        if len(parts) != 3:
            await callback.answer("Invalid provider action.", show_alert=True)
            return
        provider = parts[2]
        if provider not in ("fapello", "picazor"):
            await callback.answer("Unsupported provider.", show_alert=True)
            return
        user_id = callback.from_user.id
        self.notif_state.set_provider(user_id, provider)
        if callback.message:
            await callback.message.edit_text(
                f"Provider: <b>{provider}</b>\nChoose mode:",
                reply_markup=self._build_notification_mode_keyboard(provider),
            )
        await callback.answer()

    async def _handle_notif_mode(self, callback: CallbackQuery, parts: list[str]) -> None:
        if len(parts) != 4:
            await callback.answer("Invalid mode action.", show_alert=True)
            return
        provider = parts[2]
        mode = parts[3]
        user_id = callback.from_user.id
        self.notif_state.set_provider(user_id, provider)
        self.notif_state.set_mode(user_id, mode)
        if callback.message:
            await callback.message.edit_text(
                f"Provider: <b>{provider}</b> | Mode: <b>{mode}</b>\nHow many? Send a number."
            )
        await callback.answer()

    async def _handle_notification_number(self, message: Message, user_id: int) -> None:
        raw = (message.text or "").strip()
        try:
            number = int(raw)
        except ValueError:
            await message.reply("Send a valid number.")
            return
        if number <= 0:
            await message.reply("Number must be positive.")
            return

        provider = self.notif_state.get_provider(user_id)
        mode = self.notif_state.get_mode(user_id)
        self.notif_state.clear(user_id)

        if not provider or not mode:
            await message.reply("Session expired. Start again with /notifications.")
            return

        await message.reply(f"Fetching {number} <b>{mode}</b> notifications from <b>{provider}</b>…")
        try:
            urls = await asyncio.to_thread(self._fetch_notification_urls, provider, mode, number)
        except (FapelloNotificationAuthError, PicazorNotificationAuthError) as exc:
            await message.reply(f"Auth error: <code>{html.escape(str(exc))}</code>")
            return
        except Exception as exc:
            logger.exception("Notification fetch failed: provider=%s mode=%s", provider, mode)
            await message.reply(f"Failed to fetch notifications: <code>{html.escape(str(exc))}</code>")
            return

        if not urls:
            await message.reply("No notifications found.")
            return

        text = "\n".join(urls)
        for chunk in _split_text(text):
            await message.reply(chunk, parse_mode=None)

    @staticmethod
    def _fetch_notification_urls(provider: str, mode: str, number: int) -> list[str]:
        if provider == "fapello":
            if mode == "profiles":
                return retrieve_fapello_profile_urls(number)
            return retrieve_fapello_image_urls(number)
        if provider == "picazor":
            if mode == "profiles":
                return retrieve_picazor_profile_urls(number)
            return retrieve_picazor_album_urls(number)
        raise ValueError(f"Unsupported provider: {provider}")

    def _build_asset_type_keyboard(self) -> InlineKeyboardMarkup:
        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="TXT files", callback_data="asset:type:txt")
        keyboard.button(text="JSON files", callback_data="asset:type:json")
        keyboard.adjust(2)
        return keyboard.as_markup()

    def _build_asset_list_keyboard(self, file_type: str, page: int, total_files: int) -> InlineKeyboardMarkup:
        files = self.asset_file_service.list_files(file_type)
        page = self._normalize_asset_page(page, len(files))
        start = page * ASSET_PAGE_SIZE
        end = min(start + ASSET_PAGE_SIZE, len(files))

        keyboard = InlineKeyboardBuilder()
        for global_index, file_path in enumerate(files[start:end], start=start):
            keyboard.button(
                text=file_path.name,
                callback_data=f"asset:show:{file_type}:{global_index}:{page}",
            )

        if page > 0:
            keyboard.button(text="Prev", callback_data=f"asset:list:{file_type}:{page - 1}")
        if end < total_files:
            keyboard.button(text="Next", callback_data=f"asset:list:{file_type}:{page + 1}")
        keyboard.button(text="Back", callback_data="asset:type:menu")

        keyboard.adjust(1)
        return keyboard.as_markup()

    @staticmethod
    def _normalize_asset_page(page: int, total_files: int) -> int:
        if total_files <= 0:
            return 0
        max_page = (total_files - 1) // ASSET_PAGE_SIZE
        return max(0, min(page, max_page))

    async def assets_cmd(self, message: Message) -> None:
        await message.reply(
            "Choose which assets you want to browse:\n"
            "- TXT files from <code>assets/txt</code>\n"
            "- JSON files from <code>assets/json</code>",
            reply_markup=self._build_asset_type_keyboard(),
        )

    async def _show_asset_file_list(self, callback: CallbackQuery, file_type: str, page: int) -> bool:
        files = self.asset_file_service.list_files(file_type)
        page = self._normalize_asset_page(page, len(files))
        if callback.message is None:
            return True

        if not files:
            await callback.message.edit_text(
                f"No <code>.{file_type}</code> files found in <code>assets/{file_type}</code>.",
                reply_markup=self._build_asset_type_keyboard(),
            )
            return True

        total_pages = ((len(files) - 1) // ASSET_PAGE_SIZE) + 1
        start = page * ASSET_PAGE_SIZE
        end = min(start + ASSET_PAGE_SIZE, len(files))
        listing = "\n".join(
            f"{idx + 1}. <code>{html.escape(path.name)}</code>"
            for idx, path in enumerate(files[start:end], start=start)
        )
        await callback.message.edit_text(
            f"<b>{file_type.upper()} assets</b>\nPage <b>{page + 1}</b>/<b>{total_pages}</b>\n\n{listing}",
            reply_markup=self._build_asset_list_keyboard(file_type=file_type, page=page, total_files=len(files)),
        )
        return True

    @staticmethod
    def _fit_raw_preview(raw_text: str, max_chars: int) -> str:
        if max_chars <= 0:
            return ""
        return raw_text[:max_chars]

    def _build_asset_content_text(
        self,
        file_type: str,
        file_name: str,
        file_size: int,
        formatted_content: str,
    ) -> tuple[str, bool]:
        header = f"File: {file_name}\nType: {file_type.upper()} | Size: {file_size} bytes\n\n"
        full_text = f"{header}{formatted_content}"
        if len(full_text) <= TELEGRAM_SAFE_TEXT_LIMIT:
            return full_text, False

        max_preview_chars = TELEGRAM_SAFE_TEXT_LIMIT - len(header) - len(TRUNCATED_PREVIEW_NOTE)
        preview_raw = self._fit_raw_preview(formatted_content, max_preview_chars)
        preview_text = f"{header}{preview_raw}{TRUNCATED_PREVIEW_NOTE}"
        return preview_text, True

    def _build_asset_back_keyboard(self, file_type: str, page: int) -> InlineKeyboardMarkup:
        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="Back to list", callback_data=f"asset:list:{file_type}:{page}")
        keyboard.adjust(1)
        return keyboard.as_markup()

    async def _show_asset_content(
        self,
        callback: CallbackQuery,
        file_type: str,
        index: int,
        page: int,
    ) -> tuple[bool, str | None]:
        file_path = self.asset_file_service.get_file_by_index(file_type, index)
        if file_path is None:
            return False, "File index out of range."
        if not file_path.exists():
            await self._show_asset_file_list(callback, file_type=file_type, page=page)
            return False, "File no longer exists. List refreshed."
        if callback.message is None:
            return True, None

        raw_content = self.asset_file_service.read_text(file_path)
        formatted_content = self.asset_file_service.format_content(file_type=file_type, raw_text=raw_content)
        content_text, is_truncated = self._build_asset_content_text(
            file_type=file_type,
            file_name=file_path.name,
            file_size=file_path.stat().st_size,
            formatted_content=formatted_content,
        )
        await callback.message.edit_text(
            content_text,
            reply_markup=self._build_asset_back_keyboard(file_type=file_type, page=page),
            parse_mode=None,
        )

        if is_truncated:
            await callback.message.answer_document(
                document=FSInputFile(str(file_path)),
                caption=f"Full file: {file_path.name}",
            )

        return True, None

    @staticmethod
    def _is_supported_asset_type(file_type: str) -> bool:
        return file_type in AssetFileService.FILE_TYPES

    async def _handle_asset_type_action(self, callback: CallbackQuery, parts: list[str]) -> None:
        if len(parts) != 3:
            await callback.answer("Invalid asset type action.", show_alert=True)
            return

        if parts[2] == "menu":
            if callback.message:
                await callback.message.edit_text(
                    "Choose which assets you want to browse:",
                    reply_markup=self._build_asset_type_keyboard(),
                )
            await callback.answer()
            return

        file_type = parts[2].lower()
        if not self._is_supported_asset_type(file_type):
            await callback.answer("Unknown file type.", show_alert=True)
            return

        await self._show_asset_file_list(callback, file_type=file_type, page=0)
        await callback.answer()

    async def _handle_asset_list_action(self, callback: CallbackQuery, parts: list[str]) -> None:
        if len(parts) != 4:
            await callback.answer("Invalid list action.", show_alert=True)
            return

        file_type = parts[2].lower()
        if not self._is_supported_asset_type(file_type):
            await callback.answer("Unknown file type.", show_alert=True)
            return

        page = int(parts[3])
        await self._show_asset_file_list(callback, file_type=file_type, page=page)
        await callback.answer()

    async def _handle_asset_show_action(self, callback: CallbackQuery, parts: list[str]) -> None:
        if len(parts) != 5:
            await callback.answer("Invalid file selection.", show_alert=True)
            return

        file_type = parts[2].lower()
        if not self._is_supported_asset_type(file_type):
            await callback.answer("Unknown file type.", show_alert=True)
            return

        file_index = int(parts[3])
        page = int(parts[4])
        shown, error = await self._show_asset_content(callback, file_type=file_type, index=file_index, page=page)
        if not shown:
            await callback.answer(error or "Invalid asset request.", show_alert=True)
            return

        await callback.answer()

    async def on_asset_callback(self, callback: CallbackQuery) -> None:
        if not callback.data:
            await callback.answer("Invalid asset action.", show_alert=True)
            return

        parts = callback.data.split(":")
        if len(parts) < 2 or parts[0] != "asset":
            await callback.answer("Invalid asset action.", show_alert=True)
            return

        action = parts[1].lower()
        handler_by_action = {
            "type": self._handle_asset_type_action,
            "list": self._handle_asset_list_action,
            "show": self._handle_asset_show_action,
        }
        handler = handler_by_action.get(action)
        if handler is None:
            await callback.answer("Unknown asset action.", show_alert=True)
            return

        try:
            await handler(callback, parts)
        except ValueError:
            await callback.answer("Invalid asset request.", show_alert=True)
        except Exception:
            logger.exception("Asset callback failed for payload: %s", callback.data)
            await callback.answer("Failed to load asset content.", show_alert=True)

    async def checkpoint_inspect_cmd(self, message: Message) -> None:
        raw = (message.text or "").split(maxsplit=1)
        if len(raw) < 2:
            await message.reply("Usage: <code>/checkpoint_inspect &lt;url&gt;</code>")
            return

        source_url = raw[1].strip()
        source_key = normalize_source_url(source_url)
        info = self.checkpoint_service.inspect(source_url)
        await message.reply(
            f"Checkpoint info:\n"
            f"- source_key: <code>{source_key}</code>\n"
            f"- seen_count: <b>{info.get('seen_count', 0)}</b>\n"
            f"- recent_count: <b>{info.get('recent_count', 0)}</b>\n"
            f"- updated_at: <code>{info.get('updated_at')}</code>"
        )

    async def checkpoint_clear_cmd(self, message: Message) -> None:
        raw = (message.text or "").split(maxsplit=1)
        if len(raw) < 2:
            await message.reply("Usage: <code>/checkpoint_clear &lt;url&gt;</code>")
            return

        source_url = raw[1].strip()
        source_key = normalize_source_url(source_url)
        self.checkpoint_service.clear(source_url)
        await message.reply(f"Cleared checkpoint for:\n<code>{source_key}</code>")

    async def _queue_urls_and_ask_pages(self, message: Message, urls: list[str]) -> None:
        if message.from_user is None:
            await message.reply("Could not identify user.")
            return

        user_id = message.from_user.id
        queued = self.state.queue_links(user_id, urls)
        logger.info("User %s queued %s links", user_id, len(queued))

        self.state.mark_waiting_for_pages(user_id)
        await message.reply(
            f"Got {len(urls)} link(s). How many pages should I use? Send a number (e.g., 5) or type 'all'."
        )

    async def post_cmd(self, message: Message) -> None:
        raw = (message.text or "").split(maxsplit=1)
        if len(raw) < 2:
            await message.reply("Usage: <code>/post &lt;links...&gt;</code>")
            return

        urls = self.url_extractor.extract(raw[1])
        if not urls:
            await message.reply("I didn't find any links in your message.")
            return

        await self._queue_urls_and_ask_pages(message, urls)

    async def on_pages_input(self, message: Message) -> None:
        if message.from_user is None:
            await message.reply("Could not identify user.")
            return

        user_id = message.from_user.id

        if self.notif_state.is_waiting_for_number(user_id):
            await self._handle_notification_number(message, user_id)
            return

        if not self.state.is_waiting_for_pages(user_id):
            return

        input_text = (message.text or "").strip().lower()
        max_pages = 8000 if input_text in {"all", "*"} else int(input_text)

        self.state.set_max_pages(user_id, max_pages)
        await message.reply(
            f"Great — I'll use {max_pages} page(s). Now choose a channel to post:",
            reply_markup=self.keyboard_factory.build(),
        )

    async def on_text_with_links(self, message: Message) -> None:
        urls = self.url_extractor.extract(message.text or "")
        if not urls:
            return

        await self._queue_urls_and_ask_pages(message, urls)

    def _resolve_channel(self, payload: str) -> tuple[str | None, str]:
        if payload in self.settings.channels:
            return self.settings.channels[payload], payload

        for channel_name, channel_id in self.settings.channels.items():
            if payload == channel_id:
                return channel_id, channel_name

        return None, payload

    async def on_channel_choice(self, callback: CallbackQuery) -> None:
        if not callback.data:
            await callback.answer("Invalid channel selection.", show_alert=True)
            return

        payload = callback.data.split(":", 1)[1]
        channel_id, display_name = self._resolve_channel(payload)

        if not channel_id:
            await callback.answer("Unknown channel.", show_alert=True)
            return

        user_id = callback.from_user.id
        urls = self.state.pending_links.get(user_id)
        if not urls:
            await callback.answer("No links queued. Send links first.", show_alert=True)
            return

        await callback.answer("Posting…")
        try:
            await self.source_posting_usecase.run(
                SourcePostingRequest(
                    sources=urls,
                    channel=channel_id,
                    max_pages=self.state.get_max_pages(user_id) or 500,
                )
            )
        except Exception as exc:
            if callback.message:
                await callback.message.edit_text(f"Failed to post to <b>{display_name}</b>.\n<code>{exc}</code>")
            self.state.clear(user_id)
            return

        posted = len(urls)
        max_pages = self.state.get_max_pages(user_id)
        self.state.clear(user_id)

        if callback.message:
            await callback.message.edit_text(f"Posted {posted} link(s) to {display_name} with {max_pages} pages.")
        try:
            await callback.answer("Done.")
        except TelegramBadRequest:
            logger.info("Skipped callback final answer because query expired")

    @staticmethod
    def _build_menu_commands() -> list[BotCommand]:
        return [
            BotCommand(command="start", description="Show bot usage and commands"),
            BotCommand(command="post", description="Post links to a selected channel"),
            BotCommand(command="entities", description="List all supported websites/entities"),
            BotCommand(command="notifications", description="Fetch notifications from Fapello or Picazor"),
            BotCommand(command="search", description="Search Fapello models by name"),
            BotCommand(command="assets", description="Browse TXT/JSON files from assets"),
            BotCommand(command="checkpoint_inspect", description="Inspect checkpoint state for a URL"),
            BotCommand(command="checkpoint_clear", description="Clear checkpoint state for a URL"),
        ]

    async def _configure_telegram_ui(self) -> None:
        try:
            await self.bot.set_my_commands(self._build_menu_commands())
            await self.bot.set_chat_menu_button(menu_button=MenuButtonCommands())
            logger.info("Bot command menu configured")
        except Exception:
            logger.exception("Failed to configure bot command menu")

    async def run(self) -> None:
        await self._configure_telegram_ui()
        logger.info(
            "Interactive bot starting | checkpoint_enabled=%s backend=jsonl checkpoint_file=%s",
            self.checkpoint_service.enabled,
            CHECKPOINT_FILE_PATH,
        )
        await self.dispatcher.start_polling(self.bot)


async def main() -> None:
    app = InteractivePostingBot()
    await app.run()


if __name__ == "__main__":
    asyncio.run(main())
