# SPDX-License-Identifier: MIT
"""Filesystem safety checks before destructive operations."""

from __future__ import annotations

import contextlib
import sys
from dataclasses import dataclass
from pathlib import Path


class UnsafePathError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class PathSafety:
    path: Path
    exists: bool
    is_file: bool
    is_dir: bool
    is_symlink: bool
    is_mount: bool
    is_windows_reparse_point: bool
    hardlink_count: int
    size: int | None


def inspect_path(path: Path) -> PathSafety:
    is_symlink = path.is_symlink()
    exists = path.exists() or is_symlink
    is_mount = False
    with contextlib.suppress(OSError, NotImplementedError):
        is_mount = path.is_mount()
    hardlink_count = 0
    size: int | None = None
    if exists and not is_symlink:
        with contextlib.suppress(OSError):
            stat = path.stat()
            hardlink_count = stat.st_nlink
            size = stat.st_size
    return PathSafety(
        path=path,
        exists=exists,
        is_file=path.is_file() and not is_symlink,
        is_dir=path.is_dir() and not is_symlink,
        is_symlink=is_symlink,
        is_mount=is_mount,
        is_windows_reparse_point=_is_windows_reparse_point(path) if exists else False,
        hardlink_count=hardlink_count,
        size=size,
    )


def ensure_safe_write_path(path: Path, *, operation: str) -> None:
    ensure_safe_parent_chain(path, operation=operation)
    safety = inspect_path(path)
    _raise_if_redirecting(safety, operation=operation)
    if safety.exists and not safety.is_file:
        raise UnsafePathError(f"{operation} refused for non-regular file: {path}")


def ensure_safe_unlink_path(path: Path, *, operation: str) -> None:
    ensure_safe_parent_chain(path, operation=operation)
    safety = inspect_path(path)
    _raise_if_redirecting(safety, operation=operation)
    if safety.exists and not safety.is_file:
        raise UnsafePathError(f"{operation} refused for non-regular file: {path}")


def ensure_safe_move_source(path: Path, *, operation: str, allow_dir: bool = True) -> None:
    ensure_safe_parent_chain(path, operation=operation)
    safety = inspect_path(path)
    _raise_if_redirecting(safety, operation=operation)
    if safety.exists and not allow_dir and not safety.is_file:
        raise UnsafePathError(f"{operation} refused for non-regular file: {path}")
    if safety.hardlink_count > 1 and safety.is_file:
        raise UnsafePathError(f"{operation} refused for hardlinked file: {path}")


def ensure_safe_rmtree_path(path: Path, *, operation: str) -> None:
    ensure_safe_parent_chain(path, operation=operation)
    safety = inspect_path(path)
    _raise_if_redirecting(safety, operation=operation)
    if safety.exists and not safety.is_dir:
        raise UnsafePathError(f"{operation} refused for non-directory path: {path}")


def ensure_safe_parent_chain(path: Path, *, operation: str) -> None:
    current = path.parent.absolute()
    anchor = Path(current.anchor)
    while True:
        if current == anchor or current == current.parent:
            return
        safety = inspect_path(current)
        if safety.exists and (safety.is_symlink or safety.is_windows_reparse_point):
            raise UnsafePathError(f"{operation} refused because parent path redirects elsewhere: {current}")
        current = current.parent


def _raise_if_redirecting(safety: PathSafety, *, operation: str) -> None:
    if safety.is_symlink:
        raise UnsafePathError(f"{operation} refused for symlink path: {safety.path}")
    if safety.is_windows_reparse_point:
        raise UnsafePathError(f"{operation} refused for Windows reparse point: {safety.path}")
    if safety.is_mount:
        raise UnsafePathError(f"{operation} refused for mount point: {safety.path}")


def _is_windows_reparse_point(path: Path) -> bool:
    if sys.platform != "win32":
        return False
    with contextlib.suppress(OSError, AttributeError):
        return bool(path.stat().st_file_attributes & 0x400)
    return False
