# SPDX-License-Identifier: MIT
"""Atomic filesystem writes."""

from __future__ import annotations

import tempfile
from pathlib import Path
from stat import S_IMODE


def atomic_write_text(path: Path, content: str, *, newline: str | None = None) -> None:
    if newline == "":
        atomic_write_bytes(path, content.encode("utf-8"))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    existing_mode = _existing_permissions(path)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline=newline,
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(content)
        handle.flush()
        temp_path = Path(handle.name)
    if existing_mode is not None:
        temp_path.chmod(existing_mode)
    temp_path.replace(path)


def atomic_write_bytes(path: Path, content: bytes, *, permissions: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing_mode = _existing_permissions(path)
    mode = permissions if permissions is not None else existing_mode
    with tempfile.NamedTemporaryFile(
        mode="wb",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(content)
        handle.flush()
        temp_path = Path(handle.name)
    if mode is not None:
        temp_path.chmod(mode)
    temp_path.replace(path)


def _existing_permissions(path: Path) -> int | None:
    if not path.exists() or path.is_symlink():
        return None
    return S_IMODE(path.stat().st_mode)
