# SPDX-License-Identifier: MIT
"""Global transaction log for topology-changing wt operations."""

from __future__ import annotations

import json
import sqlite3
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from platformdirs import user_data_path

from worktree_py.state import utc_now

SCHEMA_VERSION = 3
BUSY_TIMEOUT_MS = 30_000
TERMINAL_STATES = {"committed", "rolled_back"}


class TransactionBusy(RuntimeError):
    """Raised when another topology transaction owns a repository lock."""


@dataclass(frozen=True)
class Transaction:
    id: str
    kind: str
    repo_path: str
    state: str
    manifest: dict[str, Any]


@dataclass(frozen=True)
class OperationLock:
    repo_path: str
    tx_id: str
    kind: str
    acquired_at: str


@dataclass(frozen=True)
class TopologyPlan:
    id: str
    kind: str
    repo_path: str
    state: str
    plan: dict[str, Any]


def db_path() -> Path:
    return user_data_path("worktree-py") / "transactions.db"


@contextmanager
def connect(*, immediate: bool = False) -> Iterator[sqlite3.Connection]:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path, isolation_level=None, timeout=BUSY_TIMEOUT_MS / 1000) as conn:
        conn.row_factory = sqlite3.Row
        configure(conn)
        migrate(conn)
        if immediate:
            conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except Exception:
            if immediate:
                conn.rollback()
            raise
        else:
            if immediate:
                conn.commit()


def configure(conn: sqlite3.Connection) -> None:
    conn.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS}")
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")


def migrate(conn: sqlite3.Connection) -> None:
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
            """
        )
        row = conn.execute("SELECT value FROM schema_meta WHERE key = 'schema_version'").fetchone()
        version = int(row["value"]) if row is not None else 0
        if version > SCHEMA_VERSION:
            raise RuntimeError(f"transactions.db schema version {version} is newer than this wt supports")
        if version < 1:
            apply_schema_v1(conn)
            version = 1
        if version < 2:
            apply_schema_v2(conn)
            version = 2
        if version < 3:
            apply_schema_v3(conn)
            version = 3
        conn.execute(
            "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('schema_version', ?)",
            (str(version),),
        )
    except Exception:
        conn.rollback()
        raise
    else:
        conn.commit()


def apply_schema_v1(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE transactions (
            id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            repo_path TEXT NOT NULL,
            state TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            manifest_json TEXT NOT NULL
        )
        """
    )
    conn.execute("CREATE INDEX idx_transactions_repo_kind ON transactions(repo_path, kind, state)")
    conn.execute(
        """
        CREATE TABLE transaction_steps (
            tx_id TEXT NOT NULL,
            step_order INTEGER NOT NULL,
            name TEXT NOT NULL,
            state TEXT NOT NULL,
            forward_json TEXT NOT NULL,
            rollback_json TEXT NOT NULL,
            error TEXT,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (tx_id, step_order),
            FOREIGN KEY (tx_id) REFERENCES transactions(id)
        )
        """
    )


def apply_schema_v2(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS operation_locks (
            repo_path TEXT PRIMARY KEY,
            tx_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            acquired_at TEXT NOT NULL,
            FOREIGN KEY (tx_id) REFERENCES transactions(id)
        )
        """
    )


def apply_schema_v3(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS topology_plans (
            id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            repo_path TEXT NOT NULL,
            state TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            plan_json TEXT NOT NULL
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_topology_plans_repo_kind ON topology_plans(repo_path, kind, state)")


def begin(kind: str, repo_path: Path, manifest: dict[str, Any]) -> Transaction:
    tx_id = uuid.uuid4().hex
    now = utc_now()
    repo = str(repo_path)
    with connect(immediate=True) as conn:
        try:
            conn.execute(
                """
                INSERT INTO transactions (id, kind, repo_path, state, created_at, updated_at, manifest_json)
                VALUES (?, ?, ?, 'running', ?, ?, ?)
                """,
                (tx_id, kind, repo, now, now, json.dumps(manifest, sort_keys=True)),
            )
            conn.execute(
                """
                INSERT INTO operation_locks (repo_path, tx_id, kind, acquired_at)
                VALUES (?, ?, ?, ?)
                """,
                (repo, tx_id, kind, now),
            )
        except sqlite3.IntegrityError as exc:
            lock = lock_for_repo(conn, repo_path)
            if lock is None:
                raise
            raise TransactionBusy(
                f"{repo_path} is locked by {lock.kind} transaction {lock.tx_id}; "
                "finish recovery or clear the transaction before starting another topology operation"
            ) from exc
    return Transaction(id=tx_id, kind=kind, repo_path=str(repo_path), state="running", manifest=manifest)


def save_plan(kind: str, repo_path: Path, plan: dict[str, Any]) -> TopologyPlan:
    plan_id = uuid.uuid4().hex
    now = utc_now()
    with connect(immediate=True) as conn:
        conn.execute(
            """
            INSERT INTO topology_plans (id, kind, repo_path, state, created_at, updated_at, plan_json)
            VALUES (?, ?, ?, 'planned', ?, ?, ?)
            """,
            (plan_id, kind, str(repo_path), now, now, json.dumps(plan, sort_keys=True)),
        )
    return TopologyPlan(id=plan_id, kind=kind, repo_path=str(repo_path), state="planned", plan=plan)


def get_plan(plan_id: str) -> TopologyPlan | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM topology_plans WHERE id = ?", (plan_id,)).fetchone()
    return _row_to_plan(row) if row is not None else None


def latest_plan_for_repo(
    kind: str,
    repo_path: Path,
    states: tuple[str, ...] = ("planned", "applied", "failed"),
) -> TopologyPlan | None:
    placeholders = ", ".join("?" for _ in states)
    with connect() as conn:
        row = conn.execute(
            f"""
            SELECT *
            FROM topology_plans
            WHERE kind = ? AND repo_path = ? AND state IN ({placeholders})
            ORDER BY updated_at DESC
            LIMIT 1
            """,
            (kind, str(repo_path), *states),
        ).fetchone()
    return _row_to_plan(row) if row is not None else None


def mark_plan_applied(plan_id: str) -> None:
    now = utc_now()
    with connect(immediate=True) as conn:
        conn.execute(
            "UPDATE topology_plans SET state = 'applied', updated_at = ? WHERE id = ?",
            (now, plan_id),
        )


def mark_plan_failed(plan_id: str) -> None:
    now = utc_now()
    with connect(immediate=True) as conn:
        conn.execute(
            "UPDATE topology_plans SET state = 'failed', updated_at = ? WHERE id = ?",
            (now, plan_id),
        )


def add_step(
    tx_id: str,
    order: int,
    name: str,
    *,
    forward: dict[str, Any] | None = None,
    rollback: dict[str, Any] | None = None,
) -> None:
    now = utc_now()
    with connect(immediate=True) as conn:
        conn.execute(
            """
            INSERT OR REPLACE INTO transaction_steps (
                tx_id, step_order, name, state, forward_json, rollback_json, error, updated_at
            )
            VALUES (?, ?, ?, 'planned', ?, ?, NULL, ?)
            """,
            (
                tx_id,
                order,
                name,
                json.dumps(forward or {}, sort_keys=True),
                json.dumps(rollback or {}, sort_keys=True),
                now,
            ),
        )


def mark_step(tx_id: str, order: int, state: str, error: str | None = None) -> None:
    now = utc_now()
    with connect(immediate=True) as conn:
        conn.execute(
            "UPDATE transaction_steps SET state = ?, error = ?, updated_at = ? WHERE tx_id = ? AND step_order = ?",
            (state, error, now, tx_id, order),
        )


def set_state(tx_id: str, state: str) -> None:
    now = utc_now()
    with connect(immediate=True) as conn:
        conn.execute("UPDATE transactions SET state = ?, updated_at = ? WHERE id = ?", (state, now, tx_id))
        if state in TERMINAL_STATES:
            conn.execute("DELETE FROM operation_locks WHERE tx_id = ?", (tx_id,))


def get(tx_id: str) -> Transaction | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM transactions WHERE id = ?", (tx_id,)).fetchone()
    return _row_to_tx(row) if row is not None else None


def latest_for_repo(kind: str, repo_path: Path, states: tuple[str, ...] = ("running", "failed")) -> Transaction | None:
    placeholders = ", ".join("?" for _ in states)
    with connect() as conn:
        row = conn.execute(
            f"""
            SELECT *
            FROM transactions
            WHERE kind = ? AND repo_path = ? AND state IN ({placeholders})
            ORDER BY updated_at DESC
            LIMIT 1
            """,
            (kind, str(repo_path), *states),
        ).fetchone()
    return _row_to_tx(row) if row is not None else None


def completed_steps(tx_id: str) -> set[str]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT name FROM transaction_steps WHERE tx_id = ? AND state = 'done'",
            (tx_id,),
        ).fetchall()
    return {str(row["name"]) for row in rows}


def step_states(tx_id: str) -> dict[str, str]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT name, state FROM transaction_steps WHERE tx_id = ?",
            (tx_id,),
        ).fetchall()
    return {str(row["name"]): str(row["state"]) for row in rows}


def lock_for_repo(conn: sqlite3.Connection, repo_path: Path) -> OperationLock | None:
    row = conn.execute("SELECT * FROM operation_locks WHERE repo_path = ?", (str(repo_path),)).fetchone()
    if row is None:
        return None
    return OperationLock(
        repo_path=str(row["repo_path"]),
        tx_id=str(row["tx_id"]),
        kind=str(row["kind"]),
        acquired_at=str(row["acquired_at"]),
    )


def _row_to_tx(row: sqlite3.Row) -> Transaction:
    return Transaction(
        id=str(row["id"]),
        kind=str(row["kind"]),
        repo_path=str(row["repo_path"]),
        state=str(row["state"]),
        manifest=json.loads(str(row["manifest_json"])),
    )


def _row_to_plan(row: sqlite3.Row) -> TopologyPlan:
    return TopologyPlan(
        id=str(row["id"]),
        kind=str(row["kind"]),
        repo_path=str(row["repo_path"]),
        state=str(row["state"]),
        plan=json.loads(str(row["plan_json"])),
    )
