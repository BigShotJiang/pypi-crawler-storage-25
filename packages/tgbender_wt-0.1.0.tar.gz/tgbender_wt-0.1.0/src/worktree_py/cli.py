# SPDX-License-Identifier: MIT
"""Command entry point for wt."""

from collections.abc import Callable
from typing import Annotated

import typer

from worktree_py import core

app = typer.Typer(add_completion=False, help="Git worktree manager using a bare repository layout.")
stash_app = typer.Typer(
    help="Manage wt named stashes backed by .wt/repo.db.",
    invoke_without_command=True,
    no_args_is_help=False,
)
config_app = typer.Typer(help="Inspect and edit worktree-py configuration.")
app.add_typer(stash_app, name="stash")
app.add_typer(config_app, name="config")


@app.callback()
def callback() -> None:
    """Manage Git worktrees with a .bare repository layout."""


def _handle[**P, T](func: Callable[P, T], *args: P.args, **kwargs: P.kwargs) -> T:
    try:
        return func(*args, **kwargs)
    except core.WtError as exc:
        core.console.print(f"[red]error:[/red] {exc}")
        raise typer.Exit(1) from exc


RemoteOpt = Annotated[
    list[str] | None,
    typer.Option("--remote", "-r", help="Remote name from config, or name=url. May be provided multiple times."),
]


@stash_app.callback(invoke_without_command=True)
def stash_default_command(
    ctx: typer.Context,
    name: Annotated[str | None, typer.Option("--name", "-n", help="Name for bare `wt stash` auto-save.")] = None,
    message: Annotated[
        str | None, typer.Option("--message", "-m", help="Longer stash message for bare `wt stash` auto-save.")
    ] = None,
    tag: Annotated[
        list[str] | None, typer.Option("--tag", "-t", help="Searchable tag for bare `wt stash`. May be repeated.")
    ] = None,
    tracked_only: Annotated[
        bool, typer.Option("--tracked-only", help="Do not include untracked or ignored files in bare `wt stash`.")
    ] = False,
) -> None:
    if ctx.invoked_subcommand is not None:
        return
    stash_id = _handle(core.stash_save, name, not tracked_only, message, tags=tag or [])
    typer.echo(stash_id)


@app.command("clone", help="Clone a remote repository into the wt bare layout. Alias: c.")
def clone_command(
    url: Annotated[str, typer.Argument(help="Git remote URL to clone.")],
    remote: RemoteOpt = None,
    own: Annotated[bool, typer.Option("--own", help="Keep origin as the canonical owned remote.")] = False,
) -> None:
    path = _handle(core.clone, url, remote or [], own)
    typer.echo(path)


@app.command("c", help="Alias for clone.")
def clone_alias(
    url: str,
    remote: RemoteOpt = None,
    own: Annotated[bool, typer.Option("--own")] = False,
) -> None:
    clone_command(url, remote, own)


@app.command("new", help="Create a new empty wt project. Alias: n.")
def new_command(
    name: Annotated[str, typer.Argument(help="Project directory name.")],
    remote: RemoteOpt = None,
) -> None:
    path = _handle(core.new, name, remote or [])
    typer.echo(path)


@app.command("n", help="Alias for new.")
def new_alias(name: str, remote: RemoteOpt = None) -> None:
    new_command(name, remote)


@app.command("add", help="Add a branch worktree, optionally creating the branch. Alias: a.")
def add_command(
    branch: Annotated[str | None, typer.Argument(help="Branch name. Omit to prompt interactively.")] = None,
    create: Annotated[bool, typer.Option("--branch", "-b", help="Create the branch.")] = False,
    start_point: Annotated[str | None, typer.Argument(help="Optional start point when using -b.")] = None,
) -> None:
    path = _handle(core.add, branch, create, start_point)
    typer.echo(path)


@app.command("a", help="Alias for add.")
def add_alias(
    branch: str | None = None,
    create: Annotated[bool, typer.Option("--branch", "-b")] = False,
    start_point: str | None = None,
) -> None:
    add_command(branch, create, start_point)


@app.command("remove", help="Remove a branch worktree. Alias: r.")
def remove_command(
    target_branch: Annotated[
        str | None, typer.Argument(help="Branch name. Omit to select interactively.", metavar="BRANCH")
    ] = None,
    delete_branch: Annotated[
        bool, typer.Option("--branch", "-b", help="Delete the branch after removing the worktree.")
    ] = False,
    force: Annotated[
        bool, typer.Option("--force", "-f", help="Auto-stash dirty changes without prompting, then remove.")
    ] = False,
    discard: Annotated[
        bool, typer.Option("--discard", "--no-save", help="Discard dirty changes instead of saving a wt stash.")
    ] = False,
) -> None:
    _handle(core.remove, target_branch, delete_branch, force, stash=False, discard=discard)


@app.command("r", help="Alias for remove.")
def remove_alias(
    target_branch: Annotated[
        str | None, typer.Argument(help="Branch name. Omit to select interactively.", metavar="BRANCH")
    ] = None,
    delete_branch: Annotated[bool, typer.Option("--branch", "-b")] = False,
    force: Annotated[bool, typer.Option("--force", "-f")] = False,
    discard: Annotated[bool, typer.Option("--discard", "--no-save")] = False,
) -> None:
    remove_command(target_branch, delete_branch, force, discard)


@app.command("list", help="List managed worktrees. Alias: l.")
def list_command() -> None:
    _handle(core.list_worktrees)


@app.command("l", help="Alias for list.")
def list_alias() -> None:
    list_command()


@app.command("fetch", help="Fetch and prune configured remotes. Alias: f.")
def fetch_command() -> None:
    code = _handle(core.fetch)
    raise typer.Exit(int(code))


@app.command("f", help="Alias for fetch.")
def fetch_alias() -> None:
    fetch_command()


@app.command("init", help="Convert a normal clone into the wt bare layout.")
def init_command(
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Print planned actions without changing files.")] = False,
    yes: Annotated[bool, typer.Option("-y", "--yes", help="Do not prompt before converting.")] = False,
    plan: Annotated[
        bool, typer.Option("--plan", help="Persist and print a topology plan without applying it.")
    ] = False,
    apply: Annotated[bool, typer.Option("--apply", help="Apply the latest persisted topology plan.")] = False,
    apply_plan: Annotated[str | None, typer.Option("--apply-plan", help="Apply a persisted topology plan id.")] = None,
) -> None:
    _handle(core.init_layout, dry_run, yes, save_plan=plan, apply_plan=apply_plan, apply_latest=apply)


@app.command("deinit", help="Convert a single-worktree wt project back to a normal Git checkout.")
def deinit_command(
    branch: Annotated[str | None, typer.Argument(help="Branch to keep. Defaults to bare HEAD branch.")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Print planned actions without changing files.")] = False,
    yes: Annotated[bool, typer.Option("-y", "--yes", help="Do not prompt before converting.")] = False,
    stash_dirty: Annotated[
        bool, typer.Option("--stash-dirty", help="Save dirty worktrees into wt-managed stashes before converting.")
    ] = False,
    remove_extra: Annotated[
        bool, typer.Option("--remove-extra", help="Preserve and unregister non-selected worktrees.")
    ] = False,
    plan: Annotated[
        bool, typer.Option("--plan", help="Persist and print a topology plan without applying it.")
    ] = False,
    apply: Annotated[bool, typer.Option("--apply", help="Apply the latest persisted topology plan.")] = False,
    apply_plan: Annotated[str | None, typer.Option("--apply-plan", help="Apply a persisted topology plan id.")] = None,
) -> None:
    path = _handle(
        core.deinit_layout,
        branch,
        dry_run,
        yes,
        stash_dirty=stash_dirty,
        remove_extra=remove_extra,
        save_plan=plan,
        apply_plan=apply_plan,
        apply_latest=apply,
    )
    typer.echo(path)


@app.command("abort", help="Abort and restore the latest incomplete wt operation.")
def abort_command() -> None:
    path = _handle(core.abort_latest)
    typer.echo(path)


@app.command("doctor", help="Check wt project layout, worktrees, and state DB.")
def doctor_command() -> None:
    code = _handle(core.doctor)
    raise typer.Exit(int(code))


@config_app.command("init", help="Create a config file.")
def config_init_command(
    scope: Annotated[str, typer.Option("--scope", "-s", help="Config scope: global, tracked, or local.")] = "global",
    force: Annotated[bool, typer.Option("--force", "-f", help="Overwrite an existing config file.")] = False,
) -> None:
    path = _handle(core.config_init, scope, force)
    typer.echo(path)


@config_app.command("path", help="Print a config path.")
def config_path_command(
    scope: Annotated[str, typer.Option("--scope", "-s", help="Config scope: global, tracked, or local.")] = "global",
) -> None:
    path = _handle(core.config_path_for_scope, scope)
    typer.echo(path)


@config_app.command("sources", help="Show config sources used for the current context.")
def config_sources_command() -> None:
    _handle(core.config_sources)


@config_app.command("show", help="Show effective merged config.")
def config_show_command() -> None:
    _handle(core.config_show)


@config_app.command("get", help="Print an effective config value by dotted key.")
def config_get_command(key: Annotated[str, typer.Argument(help="Dotted config key.")]) -> None:
    _handle(core.config_get, key)


@config_app.command("set", help="Set a config value by dotted key.")
def config_set_command(
    key: Annotated[str, typer.Argument(help="Dotted config key.")],
    value: Annotated[str, typer.Argument(help="TOML value, or a string if not valid TOML.")],
    scope: Annotated[str, typer.Option("--scope", "-s", help="Config scope: global, tracked, or local.")] = "global",
) -> None:
    path = _handle(core.config_set, scope, key, value)
    typer.echo(path)


@stash_app.command("save", help="Save current worktree changes as a named wt stash.")
def stash_save_command(
    name: Annotated[str | None, typer.Argument(help="Human-friendly stash name. Defaults to current branch.")] = None,
    include_untracked: Annotated[
        bool, typer.Option("--include-untracked", "-u", help="Include untracked files in the stash.")
    ] = False,
    message: Annotated[str | None, typer.Option("--message", "-m", help="Longer stash message.")] = None,
    tag: Annotated[list[str] | None, typer.Option("--tag", "-t", help="Searchable tag. May be repeated.")] = None,
) -> None:
    stash_id = _handle(core.stash_save, name, include_untracked, message, tags=tag or [])
    typer.echo(stash_id)


@stash_app.command("list", help="List wt stashes.")
def stash_list_command(
    include_dropped: Annotated[bool, typer.Option("--all", "-a", help="Include dropped stashes.")] = False,
    query: Annotated[
        str | None, typer.Option("--query", "-q", help="Search names, ids, branch, messages, tags.")
    ] = None,
    branch: Annotated[str | None, typer.Option("--branch", "-b", help="Filter by branch.")] = None,
    tag: Annotated[str | None, typer.Option("--tag", "-t", help="Filter by tag.")] = None,
) -> None:
    _handle(core.stash_list, include_dropped, query=query, branch=branch, tag=tag)


@stash_app.command("search", help="Search wt stashes by metadata.")
def stash_search_command(
    query: Annotated[str, typer.Argument(help="Text to search in id, name, branch, message, status, tags, source.")],
    include_dropped: Annotated[bool, typer.Option("--all", "-a", help="Include dropped stashes.")] = False,
    branch: Annotated[str | None, typer.Option("--branch", "-b", help="Filter by branch.")] = None,
    tag: Annotated[str | None, typer.Option("--tag", "-t", help="Filter by tag.")] = None,
) -> None:
    _handle(core.stash_search, query, include_dropped=include_dropped, branch=branch, tag=tag)


@stash_app.command("show", help="Show stash details.")
def stash_show_command(selector: Annotated[str, typer.Argument(help="Stash id, id prefix, or unique name.")]) -> None:
    _handle(core.stash_show, selector)


@stash_app.command("apply", help="Apply a wt stash to the current worktree.")
def stash_apply_command(
    selector: Annotated[str, typer.Argument(help="Stash id, id prefix, or unique name.")],
    dropped: Annotated[bool, typer.Option("--dropped", help="Allow applying a dropped stash by id.")] = False,
) -> None:
    _handle(core.stash_apply, selector, pop=False, recover_dropped=dropped)


@stash_app.command("pop", help="Apply and drop a wt stash.")
def stash_pop_command(
    selector: Annotated[str, typer.Argument(help="Stash id, id prefix, or unique name.")],
    dropped: Annotated[bool, typer.Option("--dropped", help="Allow popping a dropped stash by id.")] = False,
) -> None:
    _handle(core.stash_apply, selector, pop=True, recover_dropped=dropped)


@stash_app.command("drop", help="Drop a wt stash.")
def stash_drop_command(selector: Annotated[str, typer.Argument(help="Stash id, id prefix, or unique name.")]) -> None:
    _handle(core.stash_drop, selector)


def main() -> None:
    app()
