# SPDX-License-Identifier: MIT
"""SQLite-backed project state for wt."""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

SCHEMA_VERSION = 5
BUSY_TIMEOUT_MS = 30_000


@dataclass(frozen=True)
class StashRecord:
    id: str
    name: str
    branch: str | None
    base_commit: str
    stash_ref: str
    worktree_path: str | None
    message: str | None
    include_untracked: bool
    status_summary: str
    tags: str
    source: str
    created_at: str
    applied_at: str | None
    dropped_at: str | None


@dataclass(frozen=True)
class WorktreeSnapshot:
    path: str
    branch: str | None
    head: str | None
    git_file: str | None
    git_dir: str | None
    common_dir: str | None
    index_path: str | None
    hooks_path: str | None
    hooks_path_config: str | None
    is_current: bool
    is_dirty: bool
    captured_at: str


@dataclass(frozen=True)
class DoctorFinding:
    severity: str
    code: str
    message: str
    path: str | None
    captured_at: str


@dataclass(frozen=True)
class StashFile:
    stash_id: str
    original_path: str
    kind: str
    algo: str | None
    digest: str | None
    size: int | None
    mode: int | None
    mtime: float | None


@dataclass(frozen=True)
class StashPatch:
    stash_id: str
    path: str
    algo: str
    digest: str
    size: int
    created_at: str


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def db_path(project_root: Path) -> Path:
    return project_root / ".wt" / "repo.db"


@contextmanager
def connect(project_root: Path, *, immediate: bool = False) -> Iterator[sqlite3.Connection]:
    path = db_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path, isolation_level=None, timeout=BUSY_TIMEOUT_MS / 1000) as conn:
        conn.row_factory = sqlite3.Row
        configure(conn)
        migrate(conn)
        if immediate:
            conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except Exception:
            if immediate:
                conn.rollback()
            raise
        else:
            if immediate:
                conn.commit()


def configure(conn: sqlite3.Connection) -> None:
    conn.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS}")
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")


def migrate(conn: sqlite3.Connection) -> None:
    try:
        conn.execute("BEGIN IMMEDIATE")
        migrate_body(conn)
    except Exception:
        conn.rollback()
        raise
    else:
        conn.commit()


def migrate_body(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
        """
    )
    version_row = conn.execute("SELECT value FROM schema_meta WHERE key = 'schema_version'").fetchone()
    version = int(version_row["value"]) if version_row is not None else 0
    if version > SCHEMA_VERSION:
        raise RuntimeError(f"repo.db schema version {version} is newer than this wt supports")
    if version < 1:
        conn.execute(
            """
            CREATE TABLE stashes (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                branch TEXT,
                base_commit TEXT NOT NULL,
                stash_ref TEXT NOT NULL UNIQUE,
                worktree_path TEXT,
                message TEXT,
                include_untracked INTEGER NOT NULL CHECK (include_untracked IN (0, 1)),
                status_summary TEXT NOT NULL,
                created_at TEXT NOT NULL,
                applied_at TEXT,
                dropped_at TEXT
            )
            """
        )
        conn.execute("CREATE INDEX idx_stashes_branch ON stashes(branch)")
        conn.execute("CREATE INDEX idx_stashes_created_at ON stashes(created_at)")
        conn.execute("CREATE INDEX idx_stashes_dropped_at ON stashes(dropped_at)")
        conn.execute(
            "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )
        version = 1
    if version < 2:
        columns = {str(row["name"]) for row in conn.execute("PRAGMA table_info(stashes)").fetchall()}
        if "tags" not in columns:
            conn.execute("ALTER TABLE stashes ADD COLUMN tags TEXT NOT NULL DEFAULT ''")
        if "source" not in columns:
            conn.execute("ALTER TABLE stashes ADD COLUMN source TEXT NOT NULL DEFAULT 'manual'")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_stashes_source ON stashes(source)")
        conn.execute(
            "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )
        version = 2
    if version < 3:
        conn.execute(
            """
            CREATE TABLE worktree_snapshots (
                path TEXT PRIMARY KEY,
                branch TEXT,
                head TEXT,
                git_file TEXT,
                git_dir TEXT,
                common_dir TEXT,
                index_path TEXT,
                hooks_path TEXT,
                hooks_path_config TEXT,
                is_current INTEGER NOT NULL CHECK (is_current IN (0, 1)),
                is_dirty INTEGER NOT NULL CHECK (is_dirty IN (0, 1)),
                captured_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX idx_worktree_snapshots_branch ON worktree_snapshots(branch)")
        conn.execute(
            """
            CREATE TABLE doctor_findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                severity TEXT NOT NULL,
                code TEXT NOT NULL,
                message TEXT NOT NULL,
                path TEXT,
                captured_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX idx_doctor_findings_code ON doctor_findings(code)")
        conn.execute("CREATE INDEX idx_doctor_findings_captured_at ON doctor_findings(captured_at)")
        conn.execute(
            "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )
        version = 3
    if version < 4:
        conn.execute(
            """
            CREATE TABLE cas_objects (
                algo TEXT NOT NULL,
                digest TEXT NOT NULL,
                size INTEGER NOT NULL,
                path TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY (algo, digest)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE stash_files (
                stash_id TEXT NOT NULL,
                original_path TEXT NOT NULL,
                kind TEXT NOT NULL,
                algo TEXT,
                digest TEXT,
                size INTEGER,
                mode INTEGER,
                mtime REAL,
                PRIMARY KEY (stash_id, original_path),
                FOREIGN KEY (stash_id) REFERENCES stashes(id)
            )
            """
        )
        conn.execute("CREATE INDEX idx_stash_files_digest ON stash_files(algo, digest)")
        conn.execute(
            "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )
        version = 4
    if version < 5:
        conn.execute(
            """
            CREATE TABLE stash_patches (
                stash_id TEXT PRIMARY KEY,
                path TEXT NOT NULL,
                algo TEXT NOT NULL,
                digest TEXT NOT NULL,
                size INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (stash_id) REFERENCES stashes(id)
            )
            """
        )
        conn.execute("CREATE INDEX idx_stash_patches_digest ON stash_patches(algo, digest)")
        conn.execute(
            "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )


def insert_stash(conn: sqlite3.Connection, record: StashRecord) -> None:
    conn.execute(
        """
        INSERT INTO stashes (
            id, name, branch, base_commit, stash_ref, worktree_path, message, include_untracked, status_summary,
            tags, source, created_at, applied_at, dropped_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            record.id,
            record.name,
            record.branch,
            record.base_commit,
            record.stash_ref,
            record.worktree_path,
            record.message,
            int(record.include_untracked),
            record.status_summary,
            record.tags,
            record.source,
            record.created_at,
            record.applied_at,
            record.dropped_at,
        ),
    )


def list_stashes(conn: sqlite3.Connection, *, include_dropped: bool = False) -> list[StashRecord]:
    where = "" if include_dropped else "WHERE dropped_at IS NULL"
    rows = conn.execute(
        f"""
        SELECT *
        FROM stashes
        {where}
        ORDER BY created_at DESC, id DESC
        """
    ).fetchall()
    return [_row_to_stash(row) for row in rows]


def search_stashes(
    conn: sqlite3.Connection,
    *,
    query: str | None = None,
    branch: str | None = None,
    tag: str | None = None,
    include_dropped: bool = False,
) -> list[StashRecord]:
    clauses: list[str] = []
    params: list[str] = []
    if not include_dropped:
        clauses.append("dropped_at IS NULL")
    if query:
        clauses.append(
            """
            (
                id LIKE ?
                OR name LIKE ?
                OR branch LIKE ?
                OR message LIKE ?
                OR status_summary LIKE ?
                OR tags LIKE ?
                OR source LIKE ?
            )
            """
        )
        like = f"%{query}%"
        params.extend([like, like, like, like, like, like, like])
    if branch:
        clauses.append("branch = ?")
        params.append(branch)
    if tag:
        clauses.append("tags LIKE ?")
        params.append(f"%{tag}%")
    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = conn.execute(
        f"""
        SELECT *
        FROM stashes
        {where}
        ORDER BY created_at DESC, id DESC
        """,
        params,
    ).fetchall()
    return [_row_to_stash(row) for row in rows]


def find_stash(conn: sqlite3.Connection, selector: str) -> StashRecord | None:
    row = conn.execute("SELECT * FROM stashes WHERE id = ?", (selector,)).fetchone()
    if row is not None:
        return _row_to_stash(row)
    rows = conn.execute(
        """
        SELECT *
        FROM stashes
        WHERE dropped_at IS NULL AND name = ?
        ORDER BY created_at DESC, id DESC
        """,
        (selector,),
    ).fetchall()
    if len(rows) == 1:
        return _row_to_stash(rows[0])
    prefix_rows = conn.execute(
        """
        SELECT *
        FROM stashes
        WHERE dropped_at IS NULL AND id LIKE ?
        ORDER BY created_at DESC, id DESC
        """,
        (f"{selector}%",),
    ).fetchall()
    if len(prefix_rows) == 1:
        return _row_to_stash(prefix_rows[0])
    return None


def count_named_stashes(conn: sqlite3.Connection, name: str) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS count FROM stashes WHERE dropped_at IS NULL AND name = ?",
        (name,),
    ).fetchone()
    return int(row["count"]) if row is not None else 0


def mark_applied(conn: sqlite3.Connection, stash_id: str) -> None:
    conn.execute("UPDATE stashes SET applied_at = ? WHERE id = ?", (utc_now(), stash_id))


def mark_dropped(conn: sqlite3.Connection, stash_id: str) -> None:
    conn.execute("UPDATE stashes SET dropped_at = ? WHERE id = ?", (utc_now(), stash_id))


def insert_cas_object(
    conn: sqlite3.Connection,
    *,
    algo: str,
    digest: str,
    size: int,
    path: str,
) -> None:
    conn.execute(
        """
        INSERT OR IGNORE INTO cas_objects (algo, digest, size, path, created_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (algo, digest, size, path, utc_now()),
    )


def insert_stash_file(conn: sqlite3.Connection, file: StashFile) -> None:
    conn.execute(
        """
        INSERT INTO stash_files (stash_id, original_path, kind, algo, digest, size, mode, mtime)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (file.stash_id, file.original_path, file.kind, file.algo, file.digest, file.size, file.mode, file.mtime),
    )


def list_stash_files(conn: sqlite3.Connection, stash_id: str) -> list[StashFile]:
    rows = conn.execute(
        """
        SELECT *
        FROM stash_files
        WHERE stash_id = ?
        ORDER BY original_path
        """,
        (stash_id,),
    ).fetchall()
    return [
        StashFile(
            stash_id=str(row["stash_id"]),
            original_path=str(row["original_path"]),
            kind=str(row["kind"]),
            algo=str(row["algo"]) if row["algo"] is not None else None,
            digest=str(row["digest"]) if row["digest"] is not None else None,
            size=int(row["size"]) if row["size"] is not None else None,
            mode=int(row["mode"]) if row["mode"] is not None else None,
            mtime=float(row["mtime"]) if row["mtime"] is not None else None,
        )
        for row in rows
    ]


def list_all_stash_files(conn: sqlite3.Connection) -> list[StashFile]:
    rows = conn.execute(
        """
        SELECT *
        FROM stash_files
        ORDER BY stash_id, original_path
        """
    ).fetchall()
    return [
        StashFile(
            stash_id=str(row["stash_id"]),
            original_path=str(row["original_path"]),
            kind=str(row["kind"]),
            algo=str(row["algo"]) if row["algo"] is not None else None,
            digest=str(row["digest"]) if row["digest"] is not None else None,
            size=int(row["size"]) if row["size"] is not None else None,
            mode=int(row["mode"]) if row["mode"] is not None else None,
            mtime=float(row["mtime"]) if row["mtime"] is not None else None,
        )
        for row in rows
    ]


def insert_stash_patch(conn: sqlite3.Connection, patch: StashPatch) -> None:
    conn.execute(
        """
        INSERT INTO stash_patches (stash_id, path, algo, digest, size, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (patch.stash_id, patch.path, patch.algo, patch.digest, patch.size, patch.created_at),
    )


def get_stash_patch(conn: sqlite3.Connection, stash_id: str) -> StashPatch | None:
    row = conn.execute("SELECT * FROM stash_patches WHERE stash_id = ?", (stash_id,)).fetchone()
    return _row_to_patch(row) if row is not None else None


def list_all_stash_patches(conn: sqlite3.Connection) -> list[StashPatch]:
    rows = conn.execute(
        """
        SELECT *
        FROM stash_patches
        ORDER BY stash_id
        """
    ).fetchall()
    return [_row_to_patch(row) for row in rows]


def replace_doctor_state(
    conn: sqlite3.Connection,
    snapshots: list[WorktreeSnapshot],
    findings: list[DoctorFinding],
) -> None:
    conn.execute("DELETE FROM worktree_snapshots")
    conn.execute("DELETE FROM doctor_findings")
    conn.executemany(
        """
        INSERT INTO worktree_snapshots (
            path, branch, head, git_file, git_dir, common_dir, index_path, hooks_path, hooks_path_config,
            is_current, is_dirty, captured_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                snapshot.path,
                snapshot.branch,
                snapshot.head,
                snapshot.git_file,
                snapshot.git_dir,
                snapshot.common_dir,
                snapshot.index_path,
                snapshot.hooks_path,
                snapshot.hooks_path_config,
                int(snapshot.is_current),
                int(snapshot.is_dirty),
                snapshot.captured_at,
            )
            for snapshot in snapshots
        ],
    )
    conn.executemany(
        """
        INSERT INTO doctor_findings (severity, code, message, path, captured_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        [
            (finding.severity, finding.code, finding.message, finding.path, finding.captured_at)
            for finding in findings
        ],
    )


def _row_to_stash(row: sqlite3.Row) -> StashRecord:
    return StashRecord(
        id=str(row["id"]),
        name=str(row["name"]),
        branch=str(row["branch"]) if row["branch"] is not None else None,
        base_commit=str(row["base_commit"]),
        stash_ref=str(row["stash_ref"]),
        worktree_path=str(row["worktree_path"]) if row["worktree_path"] is not None else None,
        message=str(row["message"]) if row["message"] is not None else None,
        include_untracked=bool(row["include_untracked"]),
        status_summary=str(row["status_summary"]),
        tags=str(row["tags"]),
        source=str(row["source"]),
        created_at=str(row["created_at"]),
        applied_at=str(row["applied_at"]) if row["applied_at"] is not None else None,
        dropped_at=str(row["dropped_at"]) if row["dropped_at"] is not None else None,
    )


def _row_to_patch(row: sqlite3.Row) -> StashPatch:
    return StashPatch(
        stash_id=str(row["stash_id"]),
        path=str(row["path"]),
        algo=str(row["algo"]),
        digest=str(row["digest"]),
        size=int(row["size"]),
        created_at=str(row["created_at"]),
    )
