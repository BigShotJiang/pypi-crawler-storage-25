# SPDX-License-Identifier: MIT
"""Core implementation for the wt command."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tomllib
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import tomlkit
import typer
from platformdirs import user_config_path, user_data_path
from rich.console import Console
from rich.table import Table

from worktree_py import state, transactions
from worktree_py.atomic import atomic_write_bytes, atomic_write_text
from worktree_py.fs_safety import (
    UnsafePathError,
    ensure_safe_move_source,
    ensure_safe_parent_chain,
    ensure_safe_rmtree_path,
    ensure_safe_unlink_path,
    ensure_safe_write_path,
)
from worktree_py.path_policy import PathPolicyError, portable_key, validate_portable_path

console = Console(stderr=True)
stdout_console = Console()
ORPHAN_START_POINT = "__wt_orphan__"


class WtError(RuntimeError):
    """Expected command failure with a human-readable message."""


def require_safe(action: Callable[[], object]) -> None:
    try:
        action()
    except (UnsafePathError, PathPolicyError) as exc:
        raise WtError(str(exc)) from exc


def safe_unlink(path: Path, *, operation: str) -> None:
    require_safe(lambda: ensure_safe_unlink_path(path, operation=operation))
    path.unlink()


def safe_write_path(path: Path, *, operation: str) -> None:
    require_safe(lambda: ensure_safe_write_path(path, operation=operation))


def safe_rmtree(path: Path, *, operation: str) -> None:
    require_safe(lambda: ensure_safe_rmtree_path(path, operation=operation))
    shutil.rmtree(path)


def safe_move(source: Path, destination: Path, *, operation: str) -> None:
    if source.is_symlink():
        require_safe(lambda: ensure_safe_parent_chain(source, operation=operation))
    else:
        require_safe(lambda: ensure_safe_move_source(source, operation=operation))
    require_safe(lambda: ensure_safe_parent_chain(destination, operation=operation))
    shutil.move(str(source), str(destination))


@dataclass(frozen=True)
class Config:
    branch_path_style: str = "nested"
    flat_separator: str = "_"
    default_remotes: str = "prompt"
    remotes: dict[str, str] | None = None
    data: dict[str, Any] | None = None
    sources: tuple[Path, ...] = ()


@dataclass(frozen=True)
class ConfigDefaults:
    branch_path_style: str = "nested"
    flat_separator: str = "_"
    default_remotes: str = "prompt"


@dataclass(frozen=True)
class Project:
    root: Path

    @property
    def bare(self) -> Path:
        return self.root / ".bare"

    @property
    def wt_dir(self) -> Path:
        return self.root / ".wt"


@dataclass(frozen=True)
class Worktree:
    path: Path
    head: str | None
    branch: str | None
    bare: bool = False


@dataclass(frozen=True)
class RemoveDecision:
    remove_force: bool
    stash_name: str | None = None
    stash_message: str | None = None
    stash_tags: tuple[str, ...] = ()
    include_untracked: bool = True


def run_git(
    args: list[str],
    *,
    cwd: Path | None = None,
    project: Project | None = None,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    if project is not None:
        env["GIT_DIR"] = str(project.bare)
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        env=env,
        check=False,
        text=True,
        capture_output=True,
    )
    if check and result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or "git command failed"
        raise WtError(detail)
    return result


def global_config_path() -> Path:
    return user_config_path("worktree-py") / "config.toml"


def bare_local_config_path(project: Project) -> Path:
    return project.wt_dir / "config.toml"


def tracked_project_config_path(project: Project) -> Path:
    return project.root / ".wt.toml"


def default_config_data() -> dict[str, Any]:
    defaults = ConfigDefaults()
    return {
        "branch_path_style": defaults.branch_path_style,
        "flat_separator": defaults.flat_separator,
        "default_remotes": defaults.default_remotes,
        "normal": {
            "enabled": True,
            "worktree_root_style": "sibling-dash",
            "worktree_root": "${repo_parent}/${repo_name}-worktrees",
            "state_dir": ".git/worktree-py",
        },
        "bare": {"state_dir": ".wt"},
        "stash": {"auto_include_untracked_on_remove": True, "default_tags": ["auto"]},
        "doctor": {"record_snapshots": True, "warn_git_stash": True, "warn_precommit": True},
        "hooks": {"trust_mode": "prompt"},
        "remotes": {},
    }


def deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in overlay.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_toml_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as fp:
        return tomllib.load(fp)


def config_from_data(data: dict[str, Any], sources: list[Path]) -> Config:
    remotes = data.get("remotes") or {}
    return Config(
        branch_path_style=str(data.get("branch_path_style", "nested")),
        flat_separator=str(data.get("flat_separator", "_")),
        default_remotes=str(data.get("default_remotes", "prompt")),
        remotes={str(k): str(v) for k, v in remotes.items()},
        data=data,
        sources=tuple(sources),
    )


def load_effective_config(project: Project | None = None) -> Config:
    data = default_config_data()
    sources: list[Path] = []
    global_path = global_config_path()
    if global_path.exists():
        data = deep_merge(data, load_toml_file(global_path))
        sources.append(global_path)
    if project is not None:
        tracked_path = tracked_project_config_path(project)
        if tracked_path.exists():
            data = deep_merge(data, load_toml_file(tracked_path))
            sources.append(tracked_path)
        local_path = bare_local_config_path(project)
        if local_path.exists():
            data = deep_merge(data, load_toml_file(local_path))
            sources.append(local_path)
    return config_from_data(data, sources)


def load_global_config() -> Config:
    return load_effective_config()


def load_project_config(project: Project) -> dict[str, Any]:
    return load_effective_config(project).data or {}


def config_path_for_scope(scope: str, project: Project | None = None) -> Path:
    if scope == "global":
        return global_config_path()
    if project is None:
        project = find_project()
    if scope == "tracked":
        return tracked_project_config_path(project)
    if scope == "local":
        return bare_local_config_path(project)
    raise WtError(f"unknown config scope: {scope}")


def config_init(scope: str, force: bool = False) -> Path:
    path = config_path_for_scope(scope)
    if path.exists() and not force:
        raise WtError(f"config already exists: {path}")
    plan = save_internal_plan(
        "config-init",
        config_plan_repo_path(path),
        {
            "version": 1,
            "kind": "config-init",
            "scope": scope,
            "path": str(path),
            "force": force,
            "existed": path.exists(),
            "actions": ["create config file"],
        },
    )
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = default_config_data() if scope == "global" else {}
        text = tomlkit.dumps(data) if data else "# worktree-py local config\n"
        require_safe(lambda: ensure_safe_write_path(path, operation="config init"))
        atomic_write_text(path, text)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)
    return path


def config_sources() -> None:
    project = find_project(Path.cwd()) if is_inside_wt_project(Path.cwd()) else None
    effective = load_effective_config(project)
    table = Table(title="Config Sources")
    table.add_column("Order", justify="right")
    table.add_column("Path")
    table.add_row("0", "built-in defaults")
    for index, source in enumerate(effective.sources, start=1):
        table.add_row(str(index), str(source))
    stdout_console.print(table)


def is_inside_wt_project(path: Path) -> bool:
    try:
        find_project(path)
    except WtError:
        return False
    return True


def config_show() -> None:
    project = find_project(Path.cwd()) if is_inside_wt_project(Path.cwd()) else None
    data = load_effective_config(project).data or {}
    stdout_console.print(tomlkit.dumps(data).rstrip())


def config_get(key: str) -> None:
    project = find_project(Path.cwd()) if is_inside_wt_project(Path.cwd()) else None
    data = load_effective_config(project).data or {}
    value = get_nested_config_value(data, key)
    if value is None:
        raise WtError(f"config key not found: {key}")
    if isinstance(value, (dict, list)):
        stdout_console.print(tomlkit.dumps({"value": value}).removeprefix("value = ").rstrip())
    else:
        stdout_console.print(str(value))


def config_set(scope: str, key: str, value: str) -> Path:
    path = config_path_for_scope(scope)
    plan = save_internal_plan(
        "config-set",
        config_plan_repo_path(path),
        {
            "version": 1,
            "kind": "config-set",
            "scope": scope,
            "path": str(path),
            "key": key,
            "value": value,
            "existed": path.exists(),
            "actions": ["set config value"],
        },
    )
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        document = tomlkit.parse(path.read_text(encoding="utf-8")) if path.exists() else tomlkit.document()
        set_nested_toml_value(document, key, parse_config_value(value))
        require_safe(lambda: ensure_safe_write_path(path, operation="config set"))
        atomic_write_text(path, tomlkit.dumps(document))
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)
    return path


def config_plan_repo_path(path: Path) -> Path:
    try:
        return find_project(Path.cwd()).root
    except WtError:
        return path.parent


def get_nested_config_value(data: dict[str, Any], key: str) -> Any | None:
    current: Any = data
    for part in key.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


def parse_config_value(value: str) -> Any:
    try:
        parsed = tomlkit.parse(f"value = {value}\n")
        return parsed["value"]
    except Exception:
        return value


def set_nested_toml_value(document: Any, key: str, value: Any) -> None:
    parts = key.split(".")
    current = document
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = tomlkit.table()
        current = current[part]
    current[parts[-1]] = value


def derive_project_name(url: str) -> str:
    clean = url.split("?", 1)[0].split("#", 1)[0].rstrip("/")
    parsed = urlparse(clean)
    path = parsed.path if parsed.scheme else clean
    name = Path(path).name
    if name.endswith(".git"):
        name = name[:-4]
    if not name:
        raise WtError(f"could not derive project name from {url!r}")
    return name


def find_project(start: Path | None = None) -> Project:
    current = (start or Path.cwd()).resolve()
    candidates = [current, *current.parents]
    for path in candidates:
        if (path / ".bare" / "HEAD").exists():
            return Project(path)
        git_file = path / ".git"
        if git_file.is_file():
            try:
                contents = git_file.read_text(encoding="utf-8").strip()
            except OSError:
                continue
            if contents == "gitdir: ./.bare" and (path / ".bare").exists():
                return Project(path)
    raise WtError("not inside a wt project")


def write_git_pointer(root: Path) -> None:
    path = root / ".git"
    require_safe(lambda: ensure_safe_write_path(path, operation="write git pointer"))
    atomic_write_text(path, "gitdir: ./.bare\n")


def ensure_state(project: Project) -> None:
    with state.connect(project.root):
        pass


def templates_dir(project: Project) -> Path:
    return project.wt_dir / "templates"


def cas_root(project: Project) -> Path:
    return project.wt_dir / "objects" / "sha256"


def patches_dir(project: Project) -> Path:
    return project.wt_dir / "patches"


def branch_path(branch: str, config: Config) -> Path:
    try:
        validate_portable_path(branch)
    except PathPolicyError as exc:
        raise WtError(f"invalid branch path {branch!r}: {exc}") from exc
    if branch.startswith("/") or branch in {"", ".", ".."}:
        raise WtError(f"invalid branch path: {branch!r}")
    if any(part in {"", ".", ".."} for part in Path(branch).parts):
        raise WtError(f"branch maps to an unsafe path: {branch!r}")
    if config.branch_path_style == "flat":
        flat = branch.replace("/", config.flat_separator)
        try:
            validate_portable_path(flat)
        except PathPolicyError as exc:
            raise WtError(f"branch maps to unsafe path {flat!r}: {exc}") from exc
        return Path(flat)
    if config.branch_path_style != "nested":
        raise WtError(f"unsupported branch_path_style: {config.branch_path_style}")
    return Path(branch)


def parse_remote_specs(remote_specs: list[str], config: Config, project_name: str) -> list[tuple[str, str]]:
    remotes: list[tuple[str, str]] = []
    configured = config.remotes or {}
    for spec in remote_specs:
        if "=" in spec:
            name, url = spec.split("=", 1)
        else:
            name = spec
            if name not in configured:
                raise WtError(f"unknown remote {name!r}; use name=url or add it to config")
            url = configured[name]
        remotes.append((name, url.replace("${project}", project_name)))
    return remotes


def default_branch_from_bare(project: Project) -> str:
    result = run_git(["symbolic-ref", "--short", "HEAD"], project=project, check=False)
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    result = run_git(["branch", "--format=%(refname:short)"], project=project, check=False)
    branches = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    if branches:
        return branches[0]
    return "main"


def init_default_branch() -> str:
    result = run_git(["config", "--get", "init.defaultBranch"], check=False)
    return result.stdout.strip() if result.returncode == 0 and result.stdout.strip() else "main"


def worktrees(project: Project) -> list[Worktree]:
    result = run_git(["worktree", "list", "--porcelain"], project=project)
    entries: list[Worktree] = []
    current: dict[str, str | bool] = {}
    for line in [*result.stdout.splitlines(), ""]:
        if not line:
            if "worktree" in current:
                path = Path(str(current["worktree"])).resolve()
                entries.append(
                    Worktree(
                        path=path,
                        head=str(current["HEAD"]) if "HEAD" in current else None,
                        branch=str(current["branch"]).removeprefix("refs/heads/") if "branch" in current else None,
                        bare=bool(current.get("bare", False)),
                    )
                )
            current = {}
            continue
        if line == "bare":
            current["bare"] = True
            continue
        key, _, value = line.partition(" ")
        current[key] = value
    return entries


def find_worktree_for_branch(project: Project, branch: str) -> Worktree | None:
    for wt in worktrees(project):
        if wt.branch == branch:
            return wt
    return None


def current_branch(cwd: Path) -> str | None:
    result = run_git(["branch", "--show-current"], cwd=cwd, check=False)
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    return None


def current_managed_worktree(project: Project, cwd: Path) -> Path | None:
    resolved = cwd.resolve()
    for wt in worktrees(project):
        if wt.bare:
            continue
        try:
            resolved.relative_to(wt.path)
        except ValueError:
            continue
        return wt.path
    return None


def current_worktree_branch(project: Project, worktree_path: Path | None) -> str | None:
    if worktree_path is None:
        return None
    for wt in worktrees(project):
        if not wt.bare and wt.path == worktree_path:
            return wt.branch
    return None


def branch_exists(project: Project, branch: str) -> bool:
    result = run_git(["show-ref", "--verify", "--quiet", f"refs/heads/{branch}"], project=project, check=False)
    return result.returncode == 0


def remote_branch_matches(project: Project, branch: str) -> list[str]:
    result = run_git(["for-each-ref", "--format=%(refname:short)", "refs/remotes"], project=project, check=False)
    suffix = f"/{branch}"
    return [line.strip() for line in result.stdout.splitlines() if line.strip().endswith(suffix)]


def ensure_target_available(project: Project, target: Path) -> None:
    target = target.resolve()
    require_safe(lambda: ensure_safe_parent_chain(target, operation="create worktree"))
    try:
        target.relative_to(project.root.resolve())
    except ValueError as exc:
        raise WtError(f"target path escapes project root: {target}") from exc
    if target == project.bare.resolve() or target == project.wt_dir.resolve():
        raise WtError(f"target path conflicts with wt metadata: {target}")
    if target.exists():
        raise WtError(f"target path already exists: {target}")
    if target.parent.exists():
        for child in target.parent.iterdir():
            if portable_key(child.name) == portable_key(target.name):
                raise WtError(f"target path collides on case-insensitive filesystems: {child} vs {target}")
    for wt in worktrees(project):
        if wt.bare:
            continue
        if wt.path == target or wt.path in target.parents or target in wt.path.parents:
            raise WtError(f"target path conflicts with registered worktree: {wt.path}")


def is_dirty(path: Path) -> bool:
    result = run_git(["status", "--porcelain"], cwd=path, check=False)
    return bool(result.stdout.strip())


def status_summary(path: Path) -> str:
    result = run_git(["status", "--porcelain"], cwd=path, check=False)
    return result.stdout.strip()


def ignored_files(worktree: Path) -> list[Path]:
    result = run_git(
        ["ls-files", "--others", "--ignored", "--exclude-standard", "-z"],
        cwd=worktree,
        check=False,
    )
    if result.returncode != 0 or not result.stdout:
        return []
    files: list[Path] = []
    for raw_path in result.stdout.split("\0"):
        if not raw_path:
            continue
        path = worktree / raw_path
        if path.is_dir():
            files.extend(child for child in path.rglob("*") if child.is_file())
        elif path.is_file():
            files.append(path)
    return files


def stashable_summary(worktree: Path, include_untracked: bool) -> str:
    parts = [status_summary(worktree)]
    if include_untracked:
        parts.extend(f"!! {path.relative_to(worktree)}" for path in ignored_files(worktree))
    return "\n".join(part for part in parts if part).strip()


def has_stashable_changes(worktree: Path, include_untracked: bool) -> bool:
    return bool(stashable_summary(worktree, include_untracked))


def git_common_dir(repo: Path) -> Path:
    result = run_git(["rev-parse", "--git-common-dir"], cwd=repo)
    path = Path(result.stdout.strip())
    return path if path.is_absolute() else (repo / path).resolve()


def git_path(repo: Path, pathspec: str) -> Path | None:
    result = run_git(["rev-parse", "--git-path", pathspec], cwd=repo, check=False)
    if result.returncode != 0 or not result.stdout.strip():
        return None
    path = Path(result.stdout.strip())
    return path if path.is_absolute() else (repo / path).resolve()


def git_dir(repo: Path) -> Path | None:
    result = run_git(["rev-parse", "--git-dir"], cwd=repo, check=False)
    if result.returncode != 0 or not result.stdout.strip():
        return None
    path = Path(result.stdout.strip())
    return path if path.is_absolute() else (repo / path).resolve()


def git_config_get(repo: Path, key: str) -> str | None:
    result = run_git(["config", "--get", key], cwd=repo, check=False)
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def clean_empty_parents(path: Path, stop: Path) -> None:
    current = path.parent
    while current != stop and stop in current.parents:
        try:
            current.rmdir()
        except OSError:
            return
        current = current.parent


def configured_remote_names(project: Project) -> list[str]:
    result = run_git(["remote"], project=project, check=False)
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def configure_remotes(project: Project, remotes: list[tuple[str, str]], *, own: bool) -> None:
    if not remotes:
        return
    existing = set(configured_remote_names(project))
    if own:
        for name, url in remotes:
            if name in existing:
                run_git(["remote", "set-url", name, url], project=project)
            else:
                run_git(["remote", "add", name, url], project=project)
        return
    if "origin" in existing and "upstream" not in existing:
        run_git(["remote", "rename", "origin", "upstream"], project=project)
        existing.remove("origin")
        existing.add("upstream")
    for name, url in remotes:
        if name in existing:
            run_git(["remote", "set-url", name, url], project=project)
        else:
            run_git(["remote", "add", name, url], project=project)


def fetch_remotes(project: Project, *, show_success: bool = True) -> int:
    names = configured_remote_names(project)
    if not names:
        console.print("[yellow]no remotes configured[/yellow]")
        return 0
    failures = 0
    for name in names:
        result = run_git(["fetch", "--prune", name], project=project, check=False)
        if result.returncode == 0:
            if show_success and result.stdout.strip():
                typer.echo(result.stdout.rstrip())
            if show_success and result.stderr.strip():
                typer.echo(result.stderr.rstrip())
        else:
            failures += 1
            console.print(f"[yellow]fetch failed for {name}:[/yellow] {result.stderr.strip() or result.stdout.strip()}")
    if failures == len(names):
        return 1
    return 0


def clone(url: str, remote_specs: list[str], own: bool) -> Path:
    config = load_global_config()
    project_name = derive_project_name(url)
    root = (Path.cwd() / project_name).resolve()
    if root.exists():
        raise WtError(f"target project already exists: {root}")
    plan = save_internal_plan(
        "clone",
        root,
        {
            "version": 1,
            "kind": "clone",
            "url": url,
            "root": str(root),
            "remote_specs": remote_specs,
            "own": own,
            "actions": ["create project root", "clone bare repository", "create default branch worktree"],
        },
    )
    try:
        root.mkdir(parents=True)
        run_git(["clone", "--bare", url, str(root / ".bare")])
        write_git_pointer(root)
        project = Project(root)
        ensure_state(project)
        configure_remotes(project, parse_remote_specs(remote_specs, config, project_name), own=own)
        fetch_remotes(project, show_success=False)
        branch = default_branch_from_bare(project)
        target = root / branch_path(branch, config)
        run_git(["worktree", "add", str(target), branch], project=project)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)
    return target


def new(name: str, remote_specs: list[str]) -> Path:
    config = load_global_config()
    root = (Path.cwd() / name).resolve()
    if root.exists():
        raise WtError(f"target project already exists: {root}")
    branch = init_default_branch()
    target = root / branch_path(branch, config)
    plan = save_internal_plan(
        "new",
        root,
        {
            "version": 1,
            "kind": "new",
            "name": name,
            "root": str(root),
            "branch": branch,
            "target": str(target),
            "remote_specs": remote_specs,
            "actions": ["create project root", "initialize bare repository", "create orphan initial worktree"],
        },
    )
    try:
        root.mkdir(parents=True)
        run_git(["init", "--bare", str(root / ".bare")])
        write_git_pointer(root)
        project = Project(root)
        ensure_state(project)
        run_git(["symbolic-ref", "HEAD", f"refs/heads/{branch}"], project=project)
        configure_remotes(project, parse_remote_specs(remote_specs, config, name), own=True)
        run_git(["worktree", "add", "--orphan", "-b", branch, str(target)], project=project)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)
    return target


def add(branch: str | None, create: bool, start_point: str | None, cwd: Path | None = None) -> Path:
    project = find_project(cwd)
    if branch is None:
        branch, create, start_point = prompt_add_args(project, create, start_point, cwd or Path.cwd())
    config = load_effective_config(project)
    existing = find_worktree_for_branch(project, branch)
    if existing is not None:
        if existing.path.exists():
            return existing.path
        raise WtError(f"stale worktree registration for {branch}; run: git --git-dir {project.bare} worktree prune")
    target = project.root / branch_path(branch, config)
    ensure_target_available(project, target)
    source = current_managed_worktree(project, cwd or Path.cwd())
    plan_start_point = start_point
    if start_point == ORPHAN_START_POINT:
        plan_start_point = None
    if (
        create
        and plan_start_point is None
        and start_point != ORPHAN_START_POINT
        and (source_branch := current_branch(cwd or Path.cwd()))
        and branch_exists(project, source_branch)
    ):
        plan_start_point = source_branch
    plan = save_internal_plan(
        "add",
        project.root,
        {
            "version": 1,
            "kind": "add",
            "root": str(project.root),
            "branch": branch,
            "create": create,
            "start_point": plan_start_point,
            "target": str(target),
            "template_paths": template_plan_paths(project),
            "source_worktree": str(source) if source is not None else None,
            "actions": ["create or checkout worktree", "apply templates", "run configured hooks"],
        },
    )
    if not create and not branch_exists(project, branch):
        matches = remote_branch_matches(project, branch)
        if len(matches) == 0:
            transactions.mark_plan_failed(plan.id)
            raise WtError(f"branch {branch!r} does not exist locally or on a remote")
        if len(matches) > 1:
            transactions.mark_plan_failed(plan.id)
            raise WtError(f"branch {branch!r} exists on multiple remotes: {', '.join(matches)}")
        remote_branch = matches[0]
    else:
        remote_branch = None
    try:
        if remote_branch is not None:
            run_git(["branch", "--track", branch, remote_branch], project=project)
        args = ["worktree", "add"]
        if create:
            start_point = plan_start_point
            if start_point:
                args.extend(["-b", branch])
            else:
                args.extend(["--orphan", "-b", branch])
            args.append(str(target))
            if start_point:
                args.append(start_point)
        else:
            args.append(str(target))
            args.append(branch)
        run_git(args, project=project)
        apply_templates(project, target)
        if source is not None:
            run_hooks(project, source, target)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)
    return target


def prompt_add_args(
    project: Project,
    create: bool,
    start_point: str | None,
    cwd: Path,
) -> tuple[str, bool, str | None]:
    branch = typer.prompt("Branch name").strip()
    if not branch:
        raise WtError("branch name is required")
    if not create and not branch_exists(project, branch) and not remote_branch_matches(project, branch):
        create = typer.confirm(f"Branch {branch!r} does not exist. Create it?", default=True)
    if create and start_point is None:
        start_point = prompt_start_point(project, cwd)
    return branch, create, start_point


def prompt_start_point(project: Project, cwd: Path) -> str | None:
    choices = recent_start_points(project, cwd)
    if not choices:
        return None
    console.print("Start point:")
    for index, choice in enumerate(choices, start=1):
        console.print(f"  {index}. {choice}")
    console.print("  0. orphan branch")
    answer = str(typer.prompt("Choose start point", default="1")).strip()
    if answer in {"", "1"}:
        return choices[0]
    if answer == "0":
        return ORPHAN_START_POINT
    if answer.isdigit() and 1 <= int(answer) <= len(choices):
        return choices[int(answer) - 1]
    return answer


def recent_start_points(project: Project, cwd: Path, limit: int = 8) -> list[str]:
    candidates: list[str] = []
    current = current_branch(cwd)
    if current and branch_exists(project, current):
        candidates.append(current)
    result = run_git(
        ["for-each-ref", "--sort=-committerdate", "--format=%(refname:short)", f"--count={limit * 2}", "refs/heads"],
        project=project,
        check=False,
    )
    if result.returncode == 0:
        candidates.extend(line.strip() for line in result.stdout.splitlines() if line.strip())
    seen: set[str] = set()
    ordered: list[str] = []
    for candidate in candidates:
        if candidate not in seen:
            seen.add(candidate)
            ordered.append(candidate)
        if len(ordered) >= limit:
            break
    return ordered


def template_plan_paths(project: Project) -> list[str]:
    source = templates_dir(project)
    if not source.exists():
        return []
    if not source.is_dir():
        raise WtError(f"template path is not a directory: {source}")
    return sorted(str(path.relative_to(source)) for path in source.rglob("*") if path.is_file() or path.is_symlink())


def apply_templates(project: Project, target: Path) -> None:
    source = templates_dir(project)
    if not source.exists():
        return
    if not source.is_dir():
        raise WtError(f"template path is not a directory: {source}")
    for item in source.rglob("*"):
        relative = item.relative_to(source)
        destination = target / relative
        if item.is_symlink():
            if destination.exists() or destination.is_symlink():
                console.print(f"[yellow]template skipped existing path:[/yellow] {destination}")
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            safe_write_path(destination, operation="apply template")
            destination.symlink_to(item.readlink(), target_is_directory=item.is_dir())
            continue
        if item.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            continue
        if destination.exists():
            console.print(f"[yellow]template skipped existing path:[/yellow] {destination}")
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        safe_write_path(destination, operation="apply template")
        shutil.copy2(item, destination)


def remove(
    branch: str | None,
    delete_branch: bool,
    force: bool,
    cwd: Path | None = None,
    *,
    stash: bool = False,
    discard: bool = False,
    interactive: bool = True,
) -> None:
    project = find_project(cwd)
    if branch is None:
        branch = select_worktree_branch(project, cwd or Path.cwd())
    wt = find_worktree_for_branch(project, branch)
    if wt is None:
        raise WtError(f"no worktree found for branch {branch!r}")
    here = (cwd or Path.cwd()).resolve()
    try:
        here.relative_to(wt.path)
    except ValueError:
        pass
    else:
        raise WtError("refusing to remove the worktree containing the current directory")
    delete_branch_ref = delete_branch and branch_exists(project, branch)
    if delete_branch:
        head = default_branch_from_bare(project)
        if branch == head:
            raise WtError(f"refusing to delete bare repository HEAD branch {branch!r}")
    remove_force = force
    stash_plan: dict[str, Any] | None = None
    dirty_or_ignored = has_stashable_changes(wt.path, include_untracked=True)
    if dirty_or_ignored:
        if discard:
            remove_force = True
        elif force or stash:
            stash_plan = {
                "name": default_stash_name(branch),
                "message": f"auto-saved before removing worktree {branch}",
                "tags": ["auto", "remove", branch],
                "include_untracked": True,
            }
            remove_force = True
        elif interactive:
            decision = handle_dirty_remove_prompt(wt, branch)
            remove_force = decision.remove_force
            if decision.stash_name is not None:
                stash_plan = {
                    "name": decision.stash_name,
                    "message": decision.stash_message,
                    "tags": list(decision.stash_tags),
                    "include_untracked": decision.include_untracked,
                }
        else:
            raise WtError(f"worktree is dirty: {wt.path}; pass -f to auto-stash or --discard to throw changes away")
    plan = save_internal_plan(
        "remove",
        project.root,
        {
            "version": 1,
            "kind": "remove",
            "root": str(project.root),
            "branch": branch,
            "path": str(wt.path),
            "delete_branch": delete_branch,
            "delete_branch_ref": delete_branch_ref,
            "remove_force": remove_force,
            "discard": discard,
            "stash": stash_plan,
            "dirty": dirty_or_ignored,
            "actions": ["optionally stash dirty worktree", "remove worktree", "optionally delete branch"],
        },
    )
    try:
        if stash_plan is not None:
            stash_id = stash_save_from_worktree(
                project,
                wt.path,
                name=str(stash_plan["name"]),
                include_untracked=bool(stash_plan["include_untracked"]),
                message=str(stash_plan["message"]),
                tags=[str(tag) for tag in stash_plan["tags"]],
                source="remove",
            )
            console.print(f"[green]saved wt stash:[/green] {stash_id}")
        args = ["worktree", "remove"]
        if remove_force:
            args.append("--force")
        args.append(str(wt.path))
        run_git(args, project=project)
        clean_empty_parents(wt.path, project.root)
        if delete_branch_ref:
            run_git(["branch", "-D" if remove_force else "-d", branch], project=project)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)


def select_worktree_branch(project: Project, cwd: Path) -> str:
    current = current_managed_worktree(project, cwd)
    choices = [wt for wt in worktrees(project) if not wt.bare and wt.branch is not None and wt.path != current]
    if not choices:
        raise WtError("no removable worktrees found")

    table = Table(title=f"Select Worktree To Remove: {project.root.name}")
    table.add_column("#", justify="right")
    table.add_column("Branch")
    table.add_column("Path")
    table.add_column("Status")
    for index, wt in enumerate(choices, start=1):
        rel = wt.path.relative_to(project.root) if wt.path.is_relative_to(project.root) else wt.path
        marker = "current" if current == wt.path else ("dirty" if is_dirty(wt.path) else "clean")
        table.add_row(str(index), wt.branch or "", str(rel), marker)
    stdout_console.print(table)

    while True:
        raw = typer.prompt("Remove worktree #, or c to cancel", default="c").strip().lower()
        if raw in {"c", "cancel", "q", "quit"}:
            raise typer.Exit(1)
        try:
            selected = int(raw)
        except ValueError:
            console.print("[yellow]enter a number from the table, or c to cancel[/yellow]")
            continue
        if 1 <= selected <= len(choices):
            branch = choices[selected - 1].branch
            if branch is None:
                raise WtError("selected worktree is detached")
            return branch
        console.print("[yellow]selection out of range[/yellow]")


def list_worktrees() -> None:
    project = find_project()
    table = Table(title=f"Worktrees: {project.root.name}")
    table.add_column("Path")
    table.add_column("Branch")
    table.add_column("HEAD")
    table.add_column("Status")
    for wt in worktrees(project):
        if wt.bare:
            continue
        rel = wt.path.relative_to(project.root) if wt.path.is_relative_to(project.root) else wt.path
        table.add_row(
            str(rel),
            wt.branch or "(detached)",
            (wt.head or "")[:8],
            "dirty" if is_dirty(wt.path) else "clean",
        )
    stdout_console.print(table)


def fetch() -> int:
    project = find_project()
    plan = save_internal_plan(
        "fetch",
        project.root,
        {
            "version": 1,
            "kind": "fetch",
            "root": str(project.root),
            "remotes": configured_remote_names(project),
            "actions": ["fetch and prune configured remotes"],
        },
    )
    try:
        code = fetch_remotes(project)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    if code == 0:
        transactions.mark_plan_applied(plan.id)
    else:
        transactions.mark_plan_failed(plan.id)
    return code


def save_internal_plan(kind: str, repo_path: Path, plan: dict[str, Any]) -> transactions.TopologyPlan:
    return transactions.save_plan(kind, repo_path, plan)


def handle_dirty_remove_prompt(wt: Worktree, branch: str) -> RemoveDecision:
    console.print(f"[yellow]worktree has changes:[/yellow] {wt.path}")
    console.print(status_summary(wt.path))
    action = typer.prompt("Action: stash, discard, cancel", default="stash").strip().lower()
    if action in {"cancel", "c", "abort", "a", "no", "n"}:
        raise typer.Exit(1)
    if action in {"discard", "d", "force", "f"}:
        if not typer.confirm("Discard these changes and remove the worktree?", default=False):
            raise typer.Exit(1)
        return RemoveDecision(remove_force=True)
    if action not in {"stash", "s", "save"}:
        raise WtError(f"unknown action: {action}")
    default_name = default_stash_name(branch)
    name = typer.prompt("Stash name", default=default_name).strip() or default_name
    message = typer.prompt("Message", default=f"auto-saved before removing worktree {branch}").strip()
    tag_text = typer.prompt("Tags, comma-separated", default=f"auto,remove,{branch}").strip()
    include_untracked = typer.confirm("Include untracked files?", default=True)
    tags = [tag.strip() for tag in tag_text.split(",") if tag.strip()]
    return RemoveDecision(
        remove_force=True,
        stash_name=name,
        stash_message=message,
        stash_tags=tuple(tags),
        include_untracked=include_untracked,
    )


def default_stash_name(branch: str | None) -> str:
    stamp = state.utc_now().replace(":", "").replace("+00:00", "Z")
    return f"{branch or 'detached'}-{stamp}"


def stash_save(
    name: str | None,
    include_untracked: bool,
    message: str | None,
    cwd: Path | None = None,
    *,
    tags: list[str] | None = None,
) -> str:
    project = find_project(cwd)
    worktree = current_managed_worktree(project, cwd or Path.cwd())
    if worktree is None:
        raise WtError("wt stash save must be run from inside a managed worktree")
    return stash_save_from_worktree(
        project,
        worktree,
        name=name,
        include_untracked=include_untracked,
        message=message,
        tags=tags or [],
        source="manual",
    )


def stash_save_from_worktree(
    project: Project,
    worktree: Path,
    *,
    name: str | None,
    include_untracked: bool,
    message: str | None,
    tags: list[str],
    source: str,
) -> str:
    summary = stashable_summary(worktree, include_untracked)
    if not summary:
        raise WtError("worktree has no changes to stash")
    branch = current_branch(worktree)
    base_commit = run_git(["rev-parse", "HEAD"], cwd=worktree).stdout.strip()
    stash_id = uuid.uuid4().hex[:12]
    stash_name = name or branch or stash_id
    stash_ref = f"refs/wt-stash/{stash_id}"
    stash_message = message or stash_name
    plan = save_internal_plan(
        "stash-save",
        project.root,
        {
            "version": 1,
            "kind": "stash-save",
            "root": str(project.root),
            "worktree": str(worktree),
            "stash_id": stash_id,
            "name": stash_name,
            "branch": branch,
            "base_commit": base_commit,
            "include_untracked": include_untracked,
            "message": message,
            "tags": tags,
            "source": source,
            "status_summary": summary,
            "actions": [
                "store tracked patch backup in wt storage",
                "store large untracked files in CAS",
                "create Git stash commit",
                "write stash metadata",
            ],
        },
    )
    try:
        patch = store_tracked_patch(project, stash_id, worktree)
        cas_files = store_large_untracked_files(project, stash_id, worktree) if include_untracked else []
        stash_commit = base_commit
        if stashable_summary(worktree, include_untracked):
            args = ["stash", "push", "--message", stash_message]
            if include_untracked:
                args.append("--all")
            result = run_git(args, cwd=worktree, check=False)
            if result.returncode != 0:
                raise WtError(result.stderr.strip() or result.stdout.strip() or "git stash failed")
            if "No local changes to save" not in result.stdout:
                stash_commit = run_git(["rev-parse", "stash@{0}"], cwd=worktree).stdout.strip()
                run_git(["stash", "drop", "stash@{0}"], cwd=worktree)
        run_git(["update-ref", stash_ref, stash_commit], project=project)
        with state.connect(project.root, immediate=True) as conn:
            if state.count_named_stashes(conn, stash_name) > 0:
                console.print(
                    f"[yellow]stash name {stash_name!r} is not unique; use the id to select it precisely[/yellow]"
                )
            state.insert_stash(
                conn,
                state.StashRecord(
                    id=stash_id,
                    name=stash_name,
                    branch=branch,
                    base_commit=base_commit,
                    stash_ref=stash_ref,
                    worktree_path=str(worktree),
                    message=message,
                    include_untracked=include_untracked,
                    status_summary=summary,
                    tags=",".join(tags),
                    source=source,
                    created_at=state.utc_now(),
                    applied_at=None,
                    dropped_at=None,
                ),
            )
            for file in cas_files:
                state.insert_stash_file(conn, file)
            if patch is not None:
                state.insert_stash_patch(conn, patch)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)
    return stash_id


def store_tracked_patch(project: Project, stash_id: str, worktree: Path) -> state.StashPatch | None:
    result = run_git(["diff", "--binary", "HEAD"], cwd=worktree, check=False)
    if result.returncode != 0:
        raise WtError(result.stderr.strip() or "git diff --binary HEAD failed")
    content = result.stdout.encode("utf-8")
    if not content:
        return None
    digest = hashlib.sha256(content).hexdigest()
    relative = Path("patches") / f"{stash_id}.patch"
    path = project.wt_dir / relative
    safe_write_path(path, operation="write tracked patch backup")
    atomic_write_bytes(path, content, permissions=0o600)
    return state.StashPatch(
        stash_id=stash_id,
        path=str(relative),
        algo="sha256",
        digest=digest,
        size=len(content),
        created_at=state.utc_now(),
    )


def untracked_files(worktree: Path) -> list[Path]:
    result = run_git(["status", "--porcelain", "-z"], cwd=worktree, check=False)
    if result.returncode != 0 or not result.stdout:
        return []
    files: list[Path] = []
    for entry in result.stdout.split("\0"):
        if not entry or not entry.startswith("?? "):
            continue
        path = worktree / entry[3:]
        if path.is_dir():
            files.extend(child for child in path.rglob("*") if child.is_file())
        elif path.is_file():
            files.append(path)
    return files


def stashable_untracked_files(worktree: Path) -> list[Path]:
    paths = {path.resolve(): path for path in [*untracked_files(worktree), *ignored_files(worktree)]}
    return list(paths.values())


def store_large_untracked_files(
    project: Project,
    stash_id: str,
    worktree: Path,
    threshold_bytes: int = 4 * 1024 * 1024,
) -> list[state.StashFile]:
    stored: list[state.StashFile] = []
    for path in stashable_untracked_files(worktree):
        size = path.stat().st_size
        if size <= threshold_bytes:
            continue
        digest = hash_file(path)
        object_path = cas_root(project) / digest[:2] / digest
        object_path.parent.mkdir(parents=True, exist_ok=True)
        if not object_path.exists():
            temp_path = object_path.with_suffix(".tmp")
            safe_write_path(object_path, operation="write CAS object")
            shutil.copy2(path, temp_path)
            temp_path.replace(object_path)
        stat_result = path.stat()
        stored.append(
            state.StashFile(
                stash_id=stash_id,
                original_path=str(path.relative_to(worktree)),
                kind="cas",
                algo="sha256",
                digest=digest,
                size=size,
                mode=stat_result.st_mode,
                mtime=stat_result.st_mtime,
            )
        )
        safe_unlink(path, operation="stash CAS large file")
        console.print(f"[green]stored large file in wt CAS:[/green] {path.relative_to(worktree)}")
    return stored


def hash_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def stash_list(
    include_dropped: bool = False,
    *,
    query: str | None = None,
    branch: str | None = None,
    tag: str | None = None,
) -> None:
    project = find_project()
    ensure_state(project)
    table = Table(title=f"Stashes: {project.root.name}")
    table.add_column("ID")
    table.add_column("Name")
    table.add_column("Branch")
    table.add_column("Base")
    table.add_column("Created")
    table.add_column("Flags")
    table.add_column("Source")
    table.add_column("Tags")
    with state.connect(project.root) as conn:
        records = state.search_stashes(
            conn,
            query=query,
            branch=branch,
            tag=tag,
            include_dropped=include_dropped,
        )
    for record in records:
        flags = []
        if record.include_untracked:
            flags.append("untracked")
        if record.applied_at:
            flags.append("applied")
        if record.dropped_at:
            flags.append("dropped")
        table.add_row(
            record.id,
            record.name,
            record.branch or "",
            record.base_commit[:8],
            record.created_at,
            ", ".join(flags),
            record.source,
            record.tags,
        )
    stdout_console.print(table)


def stash_search(
    query: str,
    *,
    include_dropped: bool = False,
    branch: str | None = None,
    tag: str | None = None,
) -> None:
    stash_list(include_dropped=include_dropped, query=query, branch=branch, tag=tag)


def stash_show(selector: str) -> None:
    project = find_project()
    record = resolve_stash(project, selector)
    result = run_git(["stash", "show", "--stat", record.stash_ref], project=project, check=False)
    stdout_console.print(result.stdout.rstrip() or record.status_summary)


def stash_apply(selector: str, *, pop: bool, recover_dropped: bool = False, cwd: Path | None = None) -> None:
    project = find_project(cwd)
    worktree = current_managed_worktree(project, cwd or Path.cwd())
    if worktree is None:
        raise WtError("wt stash apply must be run from inside a managed worktree")
    record = resolve_stash(project, selector)
    if record.dropped_at is not None and not recover_dropped:
        raise WtError(f"stash {record.id} has been dropped; use `wt stash apply {record.id} --dropped` to recover it")
    if record.applied_at is not None and not recover_dropped:
        raise WtError(f"stash {record.id} has already been applied; use `wt stash drop {record.id}` to drop it")
    stash_commit = run_git(["rev-parse", record.stash_ref], project=project).stdout.strip()
    plan = save_internal_plan(
        "stash-pop" if pop else "stash-apply",
        project.root,
        {
            "version": 1,
            "kind": "stash-pop" if pop else "stash-apply",
            "root": str(project.root),
            "worktree": str(worktree),
            "stash_id": record.id,
            "stash_ref": record.stash_ref,
            "base_commit": record.base_commit,
            "stash_commit": stash_commit,
            "pop": pop,
            "recover_dropped": recover_dropped,
            "actions": ["apply Git stash ref", "restore CAS files", "update stash metadata"],
        },
    )
    try:
        if stash_commit != record.base_commit:
            result = run_git(["stash", "apply", record.stash_ref], cwd=worktree, check=False)
            if result.returncode != 0:
                raise WtError(result.stderr.strip() or result.stdout.strip() or "git stash apply failed")
        restore_cas_files(project, record.id, worktree)
        with state.connect(project.root, immediate=True) as conn:
            state.mark_applied(conn, record.id)
            if pop:
                state.mark_dropped(conn, record.id)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)


def restore_cas_files(project: Project, stash_id: str, worktree: Path) -> None:
    with state.connect(project.root) as conn:
        files = state.list_stash_files(conn, stash_id)
    for file in files:
        if file.kind != "cas" or file.algo != "sha256" or file.digest is None:
            continue
        source = cas_root(project) / file.digest[:2] / file.digest
        if not source.exists():
            raise WtError(f"CAS object is missing for {file.original_path}: {file.digest}")
        if hash_file(source) != file.digest:
            raise WtError(f"CAS object checksum mismatch for {file.original_path}: {file.digest}")
        destination = worktree / file.original_path
        if destination.exists():
            raise WtError(f"refusing to overwrite existing file while restoring CAS object: {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        safe_write_path(destination, operation="restore CAS object")
        shutil.copy2(source, destination)
        if file.mode is not None:
            os.chmod(destination, file.mode)
        if file.mtime is not None:
            os.utime(destination, (file.mtime, file.mtime))


def stash_drop(selector: str) -> None:
    project = find_project()
    record = resolve_stash(project, selector)
    if record.dropped_at is not None:
        return
    plan = save_internal_plan(
        "stash-drop",
        project.root,
        {
            "version": 1,
            "kind": "stash-drop",
            "root": str(project.root),
            "stash_id": record.id,
            "stash_ref": record.stash_ref,
            "actions": ["hide stash from default listings", "keep backend ref and CAS recoverable"],
        },
    )
    try:
        with state.connect(project.root, immediate=True) as conn:
            state.mark_dropped(conn, record.id)
    except Exception:
        transactions.mark_plan_failed(plan.id)
        raise
    transactions.mark_plan_applied(plan.id)


def resolve_stash(project: Project, selector: str) -> state.StashRecord:
    with state.connect(project.root) as conn:
        record = state.find_stash(conn, selector)
        if record is not None:
            return record
        duplicate_count = state.count_named_stashes(conn, selector)
    if duplicate_count > 1:
        raise WtError(f"stash name {selector!r} is ambiguous; use the stash id")
    raise WtError(f"stash not found: {selector}")


def doctor() -> int:
    project = find_project()
    findings: list[state.DoctorFinding] = []
    snapshots: list[state.WorktreeSnapshot] = []
    captured_at = state.utc_now()

    def add_finding(severity: str, code: str, message: str, path: Path | None = None) -> None:
        findings.append(
            state.DoctorFinding(
                severity=severity,
                code=code,
                message=message,
                path=str(path) if path is not None else None,
                captured_at=captured_at,
            )
        )
        style = "red" if severity == "error" else "yellow"
        console.print(f"[{style}]{code}:[/{style}] {message}")

    if not project.bare.exists():
        add_finding("error", "missing-bare", f"missing bare repository: {project.bare}", project.bare)
    git_file = project.root / ".git"
    if not git_file.is_file() or git_file.read_text(encoding="utf-8").strip() != "gitdir: ./.bare":
        add_finding("error", "invalid-root-git", "invalid .git pointer; expected: gitdir: ./.bare", git_file)
    ensure_state(project)
    db_file = state.db_path(project.root)
    console.print(f"[green]state db:[/green] {db_file}")
    seen_paths: dict[Path, str] = {}
    config = load_effective_config(project)
    current = current_managed_worktree(project, Path.cwd())
    for wt in worktrees(project):
        if wt.bare or wt.branch is None:
            continue
        expected = (project.root / branch_path(wt.branch, config)).resolve()
        if wt.path != expected:
            add_finding("warning", "path-mismatch", f"branch {wt.branch} is at {wt.path}, expected {expected}", wt.path)
        if not wt.path.exists():
            add_finding("warning", "missing-worktree", f"registered worktree path is missing: {wt.path}", wt.path)
        if wt.path in seen_paths:
            add_finding("error", "duplicate-worktree-path", f"duplicate worktree path: {wt.path}", wt.path)
        seen_paths[wt.path] = wt.branch
        snapshots.append(inspect_worktree(project, wt, current, captured_at, add_finding))
    with state.connect(project.root, immediate=True) as conn:
        for record in state.list_stashes(conn, include_dropped=False):
            result = run_git(["show-ref", "--verify", "--quiet", record.stash_ref], project=project, check=False)
            if result.returncode != 0:
                add_finding(
                    "warning",
                    "missing-stash-ref",
                    f"stash metadata points at missing ref: {record.id} {record.stash_ref}",
                )
        for file in state.list_all_stash_files(conn):
            if file.kind != "cas" or file.algo != "sha256" or file.digest is None:
                continue
            object_path = cas_root(project) / file.digest[:2] / file.digest
            if not object_path.exists():
                add_finding(
                    "error",
                    "missing-cas-object",
                    f"CAS object is missing for stash {file.stash_id}: {file.original_path}",
                    object_path,
                )
            elif hash_file(object_path) != file.digest:
                add_finding(
                    "error",
                    "corrupt-cas-object",
                    f"CAS object checksum mismatch for stash {file.stash_id}: {file.original_path}",
                    object_path,
                )
        for patch in state.list_all_stash_patches(conn):
            if patch.algo != "sha256":
                add_finding("error", "unknown-patch-algo", f"unknown patch digest algorithm for stash {patch.stash_id}")
                continue
            patch_path = project.wt_dir / patch.path
            if not patch_path.exists():
                add_finding(
                    "error",
                    "missing-stash-patch",
                    f"tracked patch backup is missing for stash {patch.stash_id}",
                    patch_path,
                )
            elif patch_path.stat().st_size != patch.size:
                add_finding(
                    "error",
                    "corrupt-stash-patch",
                    f"tracked patch backup size mismatch for stash {patch.stash_id}",
                    patch_path,
                )
            elif hash_file(patch_path) != patch.digest:
                add_finding(
                    "error",
                    "corrupt-stash-patch",
                    f"tracked patch backup checksum mismatch for stash {patch.stash_id}",
                    patch_path,
                )
        stash_worktree = next((snapshot.path for snapshot in snapshots if Path(snapshot.path).exists()), None)
        normal_stash = run_git(["stash", "list"], cwd=Path(stash_worktree), check=False) if stash_worktree else None
        if normal_stash is not None and normal_stash.returncode == 0 and normal_stash.stdout.strip():
            add_finding(
                "warning",
                "normal-git-stash",
                "normal Git stash has entries; wt-managed stashes are tracked separately",
            )
        plan = save_internal_plan(
            "doctor",
            project.root,
            {
                "version": 1,
                "kind": "doctor",
                "root": str(project.root),
                "snapshot_count": len(snapshots),
                "finding_count": len(findings),
                "actions": ["replace doctor snapshots and findings in repo state DB"],
            },
        )
        try:
            state.replace_doctor_state(conn, snapshots, findings)
        except Exception:
            transactions.mark_plan_failed(plan.id)
            raise
        transactions.mark_plan_applied(plan.id)
    issue_count = sum(1 for finding in findings if finding.severity in {"error", "warning"})
    if issue_count == 0:
        console.print("[green]doctor found no issues[/green]")
    else:
        console.print(f"[yellow]recorded {issue_count} doctor finding(s) in .wt/repo.db[/yellow]")
    return 1 if any(finding.severity == "error" for finding in findings) else 0


def inspect_worktree(
    project: Project,
    wt: Worktree,
    current: Path | None,
    captured_at: str,
    add_finding: Any,
) -> state.WorktreeSnapshot:
    git_file = wt.path / ".git"
    git_file_text: str | None = None
    if not git_file.is_file():
        add_finding("error", "missing-worktree-git", f"worktree .git file is missing: {git_file}", git_file)
    else:
        git_file_text = git_file.read_text(encoding="utf-8").strip()
        if not git_file_text.startswith("gitdir: "):
            add_finding(
                "error",
                "invalid-worktree-git",
                f"worktree .git file is not a gitdir pointer: {git_file}",
                git_file,
            )

    resolved_git_dir = git_dir(wt.path)
    if resolved_git_dir is None or not resolved_git_dir.exists():
        add_finding("error", "missing-git-dir", f"worktree git dir does not exist for {wt.path}", wt.path)
    resolved_common_dir: Path | None = None
    common_result = run_git(["rev-parse", "--git-common-dir"], cwd=wt.path, check=False)
    if common_result.returncode == 0 and common_result.stdout.strip():
        raw_common = Path(common_result.stdout.strip())
        resolved_common_dir = raw_common if raw_common.is_absolute() else (wt.path / raw_common).resolve()
        if resolved_common_dir != project.bare.resolve():
            add_finding(
                "error",
                "wrong-common-dir",
                f"worktree common dir is {resolved_common_dir}, expected {project.bare.resolve()}",
                wt.path,
            )
    else:
        add_finding("error", "missing-common-dir", f"could not resolve git common dir for {wt.path}", wt.path)

    index_path = git_path(wt.path, "index")
    if index_path is None:
        add_finding("error", "missing-index-path", f"could not resolve git index path for {wt.path}", wt.path)
    hooks_path = git_path(wt.path, "hooks")
    hooks_config = git_config_get(wt.path, "core.hooksPath")
    if hooks_config:
        hook_dir = Path(hooks_config)
        hook_dir = hook_dir if hook_dir.is_absolute() else (wt.path / hook_dir).resolve()
        if not hook_dir.exists():
            add_finding("warning", "missing-hooks-path", f"configured hooks path does not exist: {hook_dir}", hook_dir)
    precommit_config = wt.path / ".pre-commit-config.yaml"
    precommit_hook = git_path(wt.path, "hooks/pre-commit")
    if precommit_config.exists() and (precommit_hook is None or not precommit_hook.exists()):
        add_finding(
            "warning",
            "missing-pre-commit-hook",
            f"pre-commit config exists but hook is missing for {wt.path}",
            wt.path,
        )
    if precommit_hook is not None and precommit_hook.exists() and not os.access(precommit_hook, os.X_OK):
        add_finding(
            "warning",
            "pre-commit-not-executable",
            f"pre-commit hook is not executable: {precommit_hook}",
            precommit_hook,
        )

    return state.WorktreeSnapshot(
        path=str(wt.path),
        branch=wt.branch,
        head=wt.head,
        git_file=git_file_text,
        git_dir=str(resolved_git_dir) if resolved_git_dir is not None else None,
        common_dir=str(resolved_common_dir) if resolved_common_dir is not None else None,
        index_path=str(index_path) if index_path is not None else None,
        hooks_path=str(hooks_path) if hooks_path is not None else None,
        hooks_path_config=hooks_config,
        is_current=current == wt.path,
        is_dirty=is_dirty(wt.path) if wt.path.exists() else False,
        captured_at=captured_at,
    )


def hook_permission_key(project: Project) -> str:
    return str(project.root.resolve())


def hooks_allowed(project: Project) -> bool:
    data_dir = user_data_path("worktree-py")
    path = data_dir / "hook-dirs.toml"
    key = hook_permission_key(project)
    if path.exists():
        with path.open("rb") as fp:
            data = tomllib.load(fp)
        if key in data.get("allowed", []):
            return True
        if key in data.get("denied", []):
            return False
    answer = typer.confirm(f"Run configured wt hooks for {project.root}?", default=False)
    data_dir.mkdir(parents=True, exist_ok=True)
    allowed: list[str] = []
    denied: list[str] = []
    if path.exists():
        with path.open("rb") as fp:
            data = tomllib.load(fp)
        allowed = [str(v) for v in data.get("allowed", [])]
        denied = [str(v) for v in data.get("denied", [])]
    (allowed if answer else denied).append(key)
    lines = ["allowed = [", *[f'  "{v}",' for v in sorted(set(allowed))], "]", "denied = ["]
    lines.extend(f'  "{v}",' for v in sorted(set(denied)))
    lines.append("]")
    require_safe(lambda: ensure_safe_write_path(path, operation="write hook permissions"))
    atomic_write_text(path, "\n".join(lines) + "\n")
    return answer


def run_hooks(project: Project, source: Path, target: Path) -> None:
    config = load_project_config(project)
    hooks = config.get("hooks") or {}
    hook_actions = {key: hooks.get(key, []) for key in ("copy", "symlink", "run")}
    if not any(hook_actions.values()) or not hooks_allowed(project):
        return
    for item in hook_actions["copy"]:
        src = source / str(item)
        dst = target / str(item)
        if not src.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            safe_write_path(dst, operation="copy hook file")
            shutil.copy2(src, dst)
    for item in hook_actions["symlink"]:
        src = source / str(item)
        dst = target / str(item)
        if not src.exists() or dst.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        safe_write_path(dst, operation="symlink hook file")
        dst.symlink_to(src, target_is_directory=src.is_dir())
    for command in hook_actions["run"]:
        result = subprocess.run(str(command), cwd=target, shell=True, text=True)
        if result.returncode != 0:
            raise WtError(f"hook command failed: {command}")


def init_layout(
    dry_run: bool,
    yes: bool,
    *,
    save_plan: bool = False,
    apply_plan: str | None = None,
    apply_latest: bool = False,
) -> None:
    root = Path.cwd().resolve()
    git_file = root / ".git"
    if (root / ".bare").exists() or (git_file.is_file() and git_file.read_text().strip() == "gitdir: ./.bare"):
        raise WtError("repository already uses wt bare layout")
    if not (root / ".git").is_dir():
        raise WtError("wt init must be run from the root of a normal clone")
    if run_git(["rev-parse", "--is-inside-work-tree"], cwd=root, check=False).returncode != 0:
        raise WtError("not a git repository")
    git_root = Path(run_git(["rev-parse", "--show-toplevel"], cwd=root).stdout.strip()).resolve()
    if git_root != root:
        raise WtError("wt init must be run from the repository root")
    if run_git(["diff", "--quiet"], cwd=root, check=False).returncode != 0:
        raise WtError("refusing to init with unstaged tracked changes")
    if run_git(["diff", "--cached", "--quiet"], cwd=root, check=False).returncode != 0:
        raise WtError("refusing to init with staged changes")
    existing = run_git(["worktree", "list", "--porcelain"], cwd=root).stdout
    if existing.count("worktree ") > 1:
        raise WtError("refusing to init a repository that already has worktrees")
    branch = current_branch(root) or init_default_branch()
    config = load_global_config()
    target = root / branch_path(branch, config)
    preflight_init_layout(root, target)
    actions = [
        f"move {root / '.git'} to {root / '.bare'}",
        f"write {root / '.git'} pointer",
        f"create initial worktree at {target}",
    ]
    plan_data = init_plan_data(root, branch, target, actions)
    if apply_plan is not None and apply_latest:
        raise WtError("pass either --apply or --apply-plan, not both")
    if apply_latest:
        apply_plan = latest_plan_id("init", root)
    if apply_plan is not None:
        validate_topology_plan(apply_plan, "init", root, plan_data)
    elif save_plan:
        topology_plan = transactions.save_plan("init", root, plan_data)
        print_topology_plan(topology_plan)
        return
    for action in actions:
        console.print(action)
    if dry_run:
        return
    if target.exists():
        raise WtError(f"target worktree path already exists: {target}")
    if not yes and not typer.confirm("Convert this repository to wt bare layout?", default=False):
        raise typer.Exit(1)
    plan_id = apply_plan or transactions.save_plan("init", root, plan_data).id
    try:
        tmp = root / ".wt-init-preserve"
        if tmp.exists():
            raise WtError(f"temporary path already exists: {tmp}")
        write_init_manifest(root, branch, target, tmp)
        fail_init_after("manifest")
        tmp.mkdir()
        preserved: list[Path] = []
        for child in root.iterdir():
            if child.name in {".git", ".wt-init-preserve", ".wt-init.json"}:
                continue
            safe_move(child, tmp / child.name, operation="stage init files")
            preserved.append(tmp / child.name)
        fail_init_after("staged")
        safe_move(root / ".git", root / ".bare", operation="move git directory to bare")
        write_git_pointer(root)
        fail_init_after("git-moved")
        ensure_state(Project(root))
        run_git(["config", "--bool", "core.bare", "true"], project=Project(root))
        run_git(["worktree", "add", str(target), branch], project=Project(root))
        fail_init_after("worktree-added")
        for item in preserved:
            safe_move(item, target / item.name, operation="restore init staged files")
        tmp.rmdir()
        (root / ".wt-init.json").unlink(missing_ok=True)
    except Exception as exc:
        transactions.mark_plan_failed(plan_id)
        raise WtError(f"{exc}\nrecovery: run `wt abort` from {root}") from exc
    transactions.mark_plan_applied(plan_id)


def init_plan_data(root: Path, branch: str, target: Path, actions: list[str]) -> dict[str, Any]:
    return {
        "version": 1,
        "kind": "init",
        "root": str(root),
        "branch": branch,
        "target": str(target),
        "actions": actions,
    }


def preflight_init_layout(root: Path, target: Path) -> None:
    if (root / ".wt-init.json").exists():
        raise WtError("incomplete wt init detected; run: wt abort")
    if (root / ".bare").exists():
        raise WtError("refusing to init when .bare already exists")
    if (root / ".wt").exists():
        raise WtError("refusing to init when .wt already exists")
    tmp = root / ".wt-init-preserve"
    if tmp.exists():
        raise WtError(f"temporary path already exists: {tmp}")
    if target.exists():
        raise WtError(f"target worktree path already exists: {target}")
    common_dir = git_common_dir(root)
    active_states = {
        "MERGE_HEAD": "merge",
        "REBASE_HEAD": "rebase",
        "CHERRY_PICK_HEAD": "cherry-pick",
        "REVERT_HEAD": "revert",
        "BISECT_LOG": "bisect",
    }
    for marker, label in active_states.items():
        if (common_dir / marker).exists():
            raise WtError(f"refusing to init during an active {label}")
    if (common_dir / "rebase-merge").exists() or (common_dir / "rebase-apply").exists():
        raise WtError("refusing to init during an active rebase")
    sparse = run_git(["config", "--bool", "core.sparseCheckout"], cwd=root, check=False)
    if sparse.returncode == 0 and sparse.stdout.strip().lower() == "true":
        raise WtError("refusing to init a sparse checkout")
    if (root / ".gitmodules").exists() or run_git(["submodule", "status"], cwd=root, check=False).stdout.strip():
        raise WtError("refusing to init a repository with submodules")
    nested_git = [
        path
        for path in root.rglob(".git")
        if path != root / ".git" and ".git" not in path.relative_to(root).parts[:-1]
    ]
    if nested_git:
        raise WtError(f"refusing to init with nested git repository: {nested_git[0].parent}")


def deinit_layout(
    branch: str | None,
    dry_run: bool,
    yes: bool,
    *,
    stash_dirty: bool = False,
    remove_extra: bool = False,
    save_plan: bool = False,
    apply_plan: str | None = None,
    apply_latest: bool = False,
) -> Path:
    project = find_project()
    cwd = Path.cwd().resolve()
    current_worktree = current_managed_worktree(project, cwd)
    selected_branch = branch or current_worktree_branch(project, current_worktree) or default_branch_from_bare(project)
    non_bare = [wt for wt in worktrees(project) if not wt.bare]
    selected = next((wt for wt in non_bare if wt.branch == selected_branch), None)
    if selected is None:
        raise WtError(f"no worktree found for selected branch {selected_branch!r}")
    extras = [wt for wt in non_bare if wt.path != selected.path]
    if extras and not remove_extra:
        raise WtError("refusing to deinit with multiple worktrees; pass --remove-extra to preserve and unregister them")
    if selected.branch != selected_branch:
        raise WtError(f"only worktree branch is {selected.branch!r}, not {selected_branch!r}")
    if not selected.path.exists():
        raise WtError(f"selected worktree path is missing: {selected.path}")
    dirty_worktrees = [wt for wt in non_bare if wt.path.exists() and is_dirty(wt.path)]
    dirty_selected = selected in dirty_worktrees
    if dirty_selected and not stash_dirty:
        raise WtError(f"refusing to deinit dirty selected worktree: {selected.path}")
    if dirty_worktrees and not stash_dirty:
        raise WtError(f"refusing to deinit dirty worktree: {dirty_worktrees[0].path}")
    root_children = {child.name for child in project.root.iterdir()}
    allowed = {".bare", ".git", ".wt", ".wt.toml", selected.path.relative_to(project.root).parts[0]}
    allowed.update(wt.path.relative_to(project.root).parts[0] for wt in extras if project.root in wt.path.parents)
    unexpected = sorted(root_children - allowed)
    if unexpected:
        raise WtError(f"refusing to deinit with unexpected project-root paths: {', '.join(unexpected)}")
    actions = [
        *[f"save dirty worktree {wt.branch} into wt stash metadata" for wt in dirty_worktrees if stash_dirty],
        *[f"preserve and unregister extra worktree {wt.branch} at {wt.path}" for wt in extras],
        f"convert {project.bare} to normal .git directory",
        f"move files from {selected.path} to {project.root}",
        "move wt local state from .wt to .git/worktree-py",
        f"remove empty worktree path {selected.path}",
    ]
    preserved_root = project.root.parent / f"{project.root.name}-preserved-worktrees"
    normal_state = project.root / ".git" / "worktree-py"
    plan_data = deinit_plan_data(
        project,
        selected,
        selected_branch,
        extras,
        dirty_worktrees,
        stash_dirty,
        remove_extra,
        preserved_root,
        normal_state,
        actions,
    )
    if apply_plan is not None and apply_latest:
        raise WtError("pass either --apply or --apply-plan, not both")
    if apply_latest:
        apply_plan = latest_plan_id("deinit", project.root)
    if apply_plan is not None:
        validate_topology_plan(apply_plan, "deinit", project.root, plan_data)
    elif save_plan:
        topology_plan = transactions.save_plan("deinit", project.root, plan_data)
        print_topology_plan(topology_plan)
        return project.root
    for action in actions:
        console.print(action)
    if dry_run:
        return project.root
    prompt = (
        f"Convert branch {selected_branch!r} into the normal checkout at {project.root}?"
        if current_worktree is not None and branch is None
        else "Convert this wt project back to a normal Git checkout?"
    )
    if not yes and not typer.confirm(prompt, default=False):
        raise typer.Exit(1)
    plan_id = apply_plan or transactions.save_plan("deinit", project.root, plan_data).id
    manifest = {
        "version": 1,
        "plan_id": plan_id,
        "root": str(project.root),
        "selected_path": str(selected.path),
        "selected_branch": selected.branch,
        "preserved_root": str(preserved_root),
        "normal_state": str(normal_state),
    }
    try:
        tx = transactions.begin("deinit", project.root, manifest)
    except transactions.TransactionBusy as exc:
        raise WtError(str(exc)) from exc
    write_deinit_pointer(project.root, tx.id)
    for order, name in (
        (10, "stash-dirty"),
        (20, "preserve-extra"),
        (30, "move-git"),
        (40, "move-selected"),
        (50, "move-state"),
        (60, "cleanup-selected"),
        (70, "reset-index"),
    ):
        transactions.add_step(tx.id, order, name)
    try:
        mark_deinit_step_done(
            tx.id,
            10,
            "stash-dirty",
            lambda: deinit_stash_dirty(project, dirty_worktrees, stash_dirty),
        )
        mark_deinit_step_done(
            tx.id,
            20,
            "preserve-extra",
            lambda: deinit_preserve_extras(project, extras, preserved_root),
        )
        mark_deinit_step_done(tx.id, 30, "move-git", lambda: deinit_move_git(project))
        mark_deinit_step_done(
            tx.id,
            40,
            "move-selected",
            lambda: deinit_move_selected_files(project.root, selected.path),
        )
        mark_deinit_step_done(tx.id, 50, "move-state", lambda: deinit_move_state(project.root, normal_state))
        mark_deinit_step_done(
            tx.id,
            60,
            "cleanup-selected",
            lambda: deinit_cleanup_selected(project.root, selected.path),
        )
        mark_deinit_step_done(tx.id, 70, "reset-index", lambda: run_git(["reset", "--mixed", "HEAD"], cwd=project.root))
    except Exception as exc:
        transactions.set_state(tx.id, "failed")
        raise WtError(f"{exc}\nrecovery: run `wt abort` from {project.root}") from exc
    transactions.set_state(tx.id, "committed")
    transactions.mark_plan_applied(plan_id)
    deinit_pointer_path(project.root).unlink(missing_ok=True)
    return project.root


def deinit_plan_data(
    project: Project,
    selected: Worktree,
    selected_branch: str,
    extras: list[Worktree],
    dirty_worktrees: list[Worktree],
    stash_dirty: bool,
    remove_extra: bool,
    preserved_root: Path,
    normal_state: Path,
    actions: list[str],
) -> dict[str, Any]:
    return {
        "version": 1,
        "kind": "deinit",
        "root": str(project.root),
        "selected_branch": selected_branch,
        "selected_path": str(selected.path),
        "extra_paths": [str(wt.path) for wt in extras],
        "dirty_paths": [str(wt.path) for wt in dirty_worktrees],
        "stash_dirty": stash_dirty,
        "remove_extra": remove_extra,
        "preserved_root": str(preserved_root),
        "normal_state": str(normal_state),
        "actions": actions,
    }


def validate_topology_plan(plan_id: str, kind: str, root: Path, current_plan: dict[str, Any]) -> None:
    plan = transactions.get_plan(plan_id)
    if plan is None:
        raise WtError(f"topology plan not found: {plan_id}")
    if plan.kind != kind:
        raise WtError(f"topology plan {plan_id} is for {plan.kind}, not {kind}")
    if plan.repo_path != str(root):
        raise WtError(f"topology plan {plan_id} is for {plan.repo_path}, not {root}")
    if plan.state != "planned":
        raise WtError(f"topology plan {plan_id} is {plan.state}, not planned")
    if plan.plan != current_plan:
        raise WtError("topology plan no longer matches the current repository state; create a new plan")


def latest_plan_id(kind: str, root: Path) -> str:
    plan = transactions.latest_plan_for_repo(kind, root, states=("planned",))
    if plan is None:
        raise WtError(f"no planned {kind} operation found for {root}")
    return plan.id


def print_topology_plan(plan: transactions.TopologyPlan) -> None:
    stdout_console.print(f"plan {plan.id}")
    for action in plan.plan.get("actions", []):
        stdout_console.print(f"  {action}")


def abort_latest(cwd: Path | None = None) -> Path:
    start = (cwd or Path.cwd()).resolve()
    roots: list[Path] = []
    try:
        roots.append(find_project(start).root)
    except WtError:
        roots.append(start)
    roots.extend(parent for parent in start.parents if parent not in roots)
    for root in roots:
        if deinit_pointer_path(root).exists():
            abort_deinit_layout(root)
            return root
        if (root / ".wt-init.json").exists():
            abort_init_layout(root)
            return root
        tx = transactions.latest_for_repo("deinit", root)
        if tx is not None:
            abort_deinit_layout(root)
            return root
    raise WtError("no incomplete wt operation found to abort")


def deinit_stash_dirty(project: Project, dirty_worktrees: list[Worktree], stash_dirty: bool) -> None:
    for wt in dirty_worktrees:
        if stash_dirty:
            confirm_large_stash(wt.path)
            stash_id = stash_save_from_worktree(
                project,
                wt.path,
                name=default_stash_name(wt.branch),
                include_untracked=True,
                message=f"auto-saved before deinit from worktree {wt.branch}",
                tags=["auto", "deinit", wt.branch or "detached"],
                source="deinit",
            )
            console.print(f"[green]saved wt stash:[/green] {stash_id}")
        else:
            raise WtError(f"refusing to deinit dirty worktree: {wt.path}")


def deinit_preserve_extras(project: Project, extras: list[Worktree], preserved_root: Path) -> None:
    for wt in extras:
        preserve_extra_worktree(project, wt, preserved_root)


def deinit_move_git(project: Project) -> None:
    root_git_file = project.root / ".git"
    if root_git_file.exists():
        safe_unlink(root_git_file, operation="remove git pointer")
    safe_move(project.bare, project.root / ".git", operation="convert bare repo to git directory")
    run_git(["config", "--bool", "core.bare", "false"], cwd=project.root)
    run_git(["config", "--unset", "core.worktree"], cwd=project.root, check=False)


def deinit_move_selected_files(root: Path, selected_path: Path) -> None:
    for item in selected_path.iterdir():
        if item.name == ".git":
            continue
        destination = root / item.name
        if destination.exists():
            raise WtError(f"destination already exists during deinit: {destination}")
        safe_move(item, destination, operation="move selected worktree files")


def deinit_move_state(root: Path, normal_state: Path) -> None:
    local_state = root / ".wt"
    if local_state.exists():
        if normal_state.exists():
            raise WtError(f"normal wt state directory already exists: {normal_state}")
        safe_move(local_state, normal_state, operation="move wt state to normal repo")


def deinit_cleanup_selected(root: Path, selected_path: Path) -> None:
    git_worktrees = root / ".git" / "worktrees"
    if git_worktrees.exists():
        safe_rmtree(git_worktrees, operation="remove git worktree admin")
    safe_rmtree(selected_path, operation="remove selected worktree path")
    clean_empty_parents(selected_path, root)


def mark_deinit_step_done(tx_id: str, order: int, name: str, action: Callable[[], object]) -> None:
    try:
        transactions.mark_step(tx_id, order, "running")
        action()
    except Exception as exc:
        transactions.mark_step(tx_id, order, "failed", str(exc))
        raise
    transactions.mark_step(tx_id, order, "done")
    fail_deinit_after(name)


def deinit_pointer_path(root: Path) -> Path:
    return root / ".wt-deinit.json"


def write_deinit_pointer(root: Path, tx_id: str) -> None:
    path = deinit_pointer_path(root)
    require_safe(lambda: ensure_safe_write_path(path, operation="write deinit pointer"))
    atomic_write_text(path, json.dumps({"version": 1, "kind": "deinit", "tx_id": tx_id}, indent=2) + "\n")


def read_deinit_tx(root: Path) -> transactions.Transaction:
    path = deinit_pointer_path(root)
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        tx_id = str(data.get("tx_id", ""))
        tx = transactions.get(tx_id)
        if tx is None:
            raise WtError(f"deinit transaction {tx_id} was not found in {transactions.db_path()}")
        return tx
    tx = transactions.latest_for_repo("deinit", root)
    if tx is None:
        raise WtError("no incomplete wt deinit transaction found")
    return tx


def fail_deinit_after(step: str) -> None:
    if os.environ.get("WT_DEINIT_FAIL_AFTER") == step:
        raise WtError(f"simulated wt deinit failure after {step}")


def abort_deinit_layout(root: Path) -> None:
    tx = read_deinit_tx(root)
    manifest = tx.manifest
    if int(manifest.get("version", 0)) != 1:
        raise WtError("unsupported wt deinit transaction manifest version")
    step_states = transactions.step_states(tx.id)
    touched = {name for name, state_name in step_states.items() if state_name in {"done", "running", "failed"}}
    selected_path = Path(str(manifest["selected_path"]))
    normal_state = Path(str(manifest["normal_state"]))
    if "cleanup-selected" in touched:
        raise WtError(
            "cannot safely abort after selected worktree cleanup; inspect the checkout manually. "
            f"transaction: {tx.id}"
        )
    if "move-state" in touched:
        rollback_deinit_state(root, normal_state)
    if "move-selected" in touched:
        rollback_deinit_selected_files(root, selected_path)
    if "move-git" in touched:
        rollback_deinit_git(root)
    transactions.set_state(tx.id, "rolled_back")
    deinit_pointer_path(root).unlink(missing_ok=True)
    console.print("[green]aborted incomplete wt deinit[/green]")


def rollback_deinit_state(root: Path, normal_state: Path) -> None:
    local_state = root / ".wt"
    if normal_state.exists():
        if local_state.exists():
            raise WtError(f"cannot abort wt deinit; local state already exists: {local_state}")
        safe_move(normal_state, local_state, operation="rollback deinit state")


def rollback_deinit_selected_files(root: Path, selected_path: Path) -> None:
    selected_path.mkdir(parents=True, exist_ok=True)
    ignored = {".git", ".bare", ".wt", ".wt.toml", ".wt-deinit.json"}
    for item in list(root.iterdir()):
        if item.name in ignored or item == selected_path or selected_path in item.parents:
            continue
        destination = selected_path / item.name
        if destination.exists():
            raise WtError(f"cannot abort wt deinit; destination already exists: {destination}")
        safe_move(item, destination, operation="rollback selected files")


def rollback_deinit_git(root: Path) -> None:
    normal_git = root / ".git"
    bare_git = root / ".bare"
    if normal_git.is_dir():
        if bare_git.exists():
            raise WtError(f"cannot abort wt deinit; .bare already exists: {bare_git}")
        safe_move(normal_git, bare_git, operation="rollback git directory")
        write_git_pointer(root)
        run_git(["config", "--bool", "core.bare", "true"], project=Project(root), check=False)
    elif normal_git.is_file() and bare_git.is_dir():
        return
    else:
        raise WtError("cannot abort wt deinit; neither .git directory nor .bare directory is present")


def dirty_file_sizes(worktree: Path) -> list[tuple[Path, int]]:
    result = run_git(["status", "--porcelain", "-z"], cwd=worktree, check=False)
    if result.returncode != 0 or not result.stdout:
        return []
    entries = result.stdout.split("\0")
    paths: list[Path] = []
    index = 0
    while index < len(entries):
        entry = entries[index]
        index += 1
        if not entry:
            continue
        status = entry[:2]
        raw_path = entry[3:]
        if status[0] in {"R", "C"} and index < len(entries):
            raw_path = entries[index]
            index += 1
        path = worktree / raw_path
        if path.exists() and path.is_file():
            paths.append(path)
    return [(path, path.stat().st_size) for path in paths]


def confirm_large_stash(worktree: Path, cutoff_bytes: int = 4 * 1024 * 1024) -> None:
    large = [(path, size) for path, size in dirty_file_sizes(worktree) if size > cutoff_bytes]
    if not large:
        return
    console.print(f"[yellow]large files detected before stashing {worktree}:[/yellow]")
    for path, size in large:
        console.print(f"  {path.relative_to(worktree)} ({size / 1024 / 1024:.1f} MiB)")
    if not typer.confirm("Stash these large files into Git objects?", default=False):
        raise typer.Exit(1)


def preserve_extra_worktree(project: Project, wt: Worktree, preserved_root: Path) -> None:
    preserved_root.mkdir(parents=True, exist_ok=True)
    relative = wt.path.relative_to(project.root)
    destination = preserved_root / Path(*relative.parts)
    if destination.exists():
        raise WtError(f"preserved worktree destination already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    safe_move(wt.path, destination, operation="preserve extra worktree")
    run_git(["worktree", "prune"], project=project)
    clean_empty_parents(wt.path, project.root)
    console.print(f"[green]preserved extra worktree:[/green] {destination}")


def write_init_manifest(root: Path, branch: str, target: Path, tmp: Path) -> None:
    manifest = {
        "version": 1,
        "branch": branch,
        "root": str(root),
        "target": str(target),
        "staging": str(tmp),
    }
    path = root / ".wt-init.json"
    require_safe(lambda: ensure_safe_write_path(path, operation="write init manifest"))
    atomic_write_text(path, json.dumps(manifest, indent=2, sort_keys=True) + "\n")


def read_init_manifest(root: Path) -> dict[str, str]:
    path = root / ".wt-init.json"
    if not path.exists():
        raise WtError("no incomplete wt init manifest found")
    data = json.loads(path.read_text(encoding="utf-8"))
    if int(data.get("version", 0)) != 1:
        raise WtError("unsupported wt init manifest version")
    return {str(key): str(value) for key, value in data.items()}


def fail_init_after(step: str) -> None:
    if os.environ.get("WT_INIT_FAIL_AFTER") == step:
        raise WtError(f"simulated wt init failure after {step}")


def abort_init_layout(root: Path) -> None:
    manifest = read_init_manifest(root)
    staging = Path(manifest["staging"])
    target = Path(manifest["target"])
    if (root / ".git").is_file() and (root / ".bare").is_dir():
        safe_unlink(root / ".git", operation="abort init remove git pointer")
        safe_move(root / ".bare", root / ".git", operation="abort init restore git directory")
    if target.exists():
        result = run_git(["worktree", "remove", "--force", str(target)], cwd=root, check=False)
        if result.returncode != 0 and target.exists():
            safe_rmtree(target, operation="abort init remove worktree")
        clean_empty_parents(target, root)
    if staging.exists():
        for item in staging.iterdir():
            destination = root / item.name
            if destination.exists():
                raise WtError(f"cannot abort wt init; destination already exists: {destination}")
            safe_move(item, destination, operation="abort init restore staged files")
        staging.rmdir()
    wt_dir = root / ".wt"
    if wt_dir.exists():
        safe_rmtree(wt_dir, operation="abort init remove state")
    (root / ".wt-init.json").unlink(missing_ok=True)
    console.print("[green]aborted incomplete wt init[/green]")
