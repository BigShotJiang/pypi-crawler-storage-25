# SPDX-License-Identifier: MIT
"""Python Git worktree manager using a bare repository layout."""

__all__ = ["__version__"]
__version__ = "0.1.0"
