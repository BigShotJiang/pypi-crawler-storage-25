from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np
import rasterio
from rasterio.transform import from_origin

from inference.export_cesium_globe_assets import (
    ARGO_SAMPLE_LOCATION_PROPERTY_KEYS,
    ARGO_POINT_PROPERTY_KEYS,
    DEFAULT_CAMERA_HEIGHT,
    DEFAULT_CAMERA_LAT,
    DEFAULT_CAMERA_LON,
    DEFAULT_RCLONE_SYNC_SCOPE,
    FULL_SAMPLE_PROPERTY_KEYS,
    _build_parser,
    _build_gdal2tiles_command,
    _estimate_native_zoom_level,
    _read_raster_metadata,
    _resolve_depth_export_artifacts,
    _resolve_rclone_sync_source,
    _rewrite_argo_sample_locations_geojson,
    _rewrite_geojson,
    _sync_with_rclone,
    build_globe_config,
)


class TestCesiumGlobeAssets(unittest.TestCase):
    def test_read_raster_metadata_uses_exported_bounds(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tif_path = Path(tmp_dir) / "prediction.tif"
            with rasterio.open(
                tif_path,
                "w",
                driver="GTiff",
                height=2,
                width=3,
                count=1,
                dtype="float32",
                crs="EPSG:4326",
                transform=from_origin(10.0, 20.0, 0.5, 1.0),
            ) as ds:
                ds.write(np.ones((1, 2, 3), dtype=np.float32))
                ds.update_tags(source="DepthDif global weekly inference export")

            metadata = _read_raster_metadata(tif_path)

        self.assertAlmostEqual(metadata["west"], 10.0, places=6)
        self.assertAlmostEqual(metadata["east"], 11.5, places=6)
        self.assertAlmostEqual(metadata["north"], 20.0, places=6)
        self.assertAlmostEqual(metadata["south"], 18.0, places=6)
        self.assertEqual(metadata["credit"], "DepthDif global weekly inference export")
        self.assertAlmostEqual(
            metadata["default_camera_destination"]["lon"],
            DEFAULT_CAMERA_LON,
            places=6,
        )
        self.assertAlmostEqual(
            metadata["default_camera_destination"]["lat"],
            DEFAULT_CAMERA_LAT,
            places=6,
        )
        self.assertEqual(
            metadata["default_camera_destination"]["height"], DEFAULT_CAMERA_HEIGHT
        )

    def test_build_globe_config_preserves_expected_urls_and_bounds(self) -> None:
        template = {
            "selected_date": None,
            "prediction_tiles_url": None,
            "ground_truth_tiles_url": None,
            "depth_levels": [],
            "argo_sample_locations_url": None,
            "argo_points_url": None,
            "patch_splits_url": None,
            "full_sample_points_url": None,
            "west": -180.0,
            "south": -90.0,
            "east": 180.0,
            "north": 90.0,
            "default_camera_destination": {"lon": 0.0, "lat": 0.0, "height": 1.0},
            "credits": {},
        }
        bounds = {
            "west": 1.0,
            "south": 2.0,
            "east": 3.0,
            "north": 4.0,
            "default_camera_destination": {"lon": 2.0, "lat": 3.0, "height": 5000.0},
        }

        config = build_globe_config(
            selected_date=20260105,
            prediction_tiles_url="./prediction_tiles",
            ground_truth_tiles_url="./ground_truth_tiles",
            depth_levels=[
                {
                    "label": "Surface",
                    "requested_depth_m": 0.0,
                    "actual_depth_m": 0.5,
                    "channel_index": 0,
                    "prediction_tiles_url": "./prediction_tiles_surface",
                    "ground_truth_tiles_url": "./ground_truth_tiles_surface",
                }
            ],
            argo_sample_locations_url="./argo_sample_locations.geojson",
            argo_points_url="./argo_points.geojson",
            patch_splits_url="./patch_splits.geojson",
            full_sample_points_url="./full_sample_locations.geojson",
            bounds=bounds,
            prediction_credit="Prediction source",
            ground_truth_credit="Ground truth source",
            points_credit="Observed Argo points",
            patch_splits_credit="Train/val patch split grid",
            full_sample_points_credit="Random full-depth profile locations",
            color_scale_min_c=0.0,
            color_scale_max_c=30.0,
            color_palette="temperature_blue_red",
            template=template,
        )

        self.assertEqual(config["selected_date"], 20260105)
        self.assertEqual(config["prediction_tiles_url"], "./prediction_tiles")
        self.assertEqual(config["ground_truth_tiles_url"], "./ground_truth_tiles")
        self.assertEqual(config["depth_levels"][0]["label"], "Surface")
        self.assertEqual(
            config["depth_levels"][0]["prediction_tiles_url"],
            "./prediction_tiles_surface",
        )
        self.assertEqual(
            config["argo_sample_locations_url"], "./argo_sample_locations.geojson"
        )
        self.assertEqual(config["argo_points_url"], "./argo_points.geojson")
        self.assertEqual(config["patch_splits_url"], "./patch_splits.geojson")
        self.assertEqual(
            config["full_sample_points_url"], "./full_sample_locations.geojson"
        )
        self.assertEqual(config["west"], 1.0)
        self.assertEqual(config["south"], 2.0)
        self.assertEqual(config["east"], 3.0)
        self.assertEqual(config["north"], 4.0)
        self.assertEqual(config["color_scale_min_c"], 0.0)
        self.assertEqual(config["color_scale_max_c"], 30.0)
        self.assertEqual(config["color_palette"], "temperature_blue_red")
        self.assertEqual(config["credits"]["prediction"], "Prediction source")
        self.assertEqual(config["credits"]["ground_truth"], "Ground truth source")
        self.assertEqual(config["credits"]["points"], "Observed Argo points")
        self.assertEqual(
            config["credits"]["patch_splits"], "Train/val patch split grid"
        )
        self.assertEqual(
            config["credits"]["full_sample_points"],
            "Random full-depth profile locations",
        )

    def test_template_is_valid_json(self) -> None:
        template_path = Path("inference/transforms/globe-config.template.json")
        with template_path.open("r", encoding="utf-8") as f:
            template = json.load(f)

        self.assertIn("prediction_tiles_url", template)
        self.assertIn("depth_levels", template)
        self.assertIn("argo_sample_locations_url", template)
        self.assertIn("patch_splits_url", template)
        self.assertIn("full_sample_points_url", template)
        self.assertIn("default_camera_destination", template)
        self.assertIn("color_scale_min_c", template)

    def test_standalone_globe_page_uses_full_window_root_shell(self) -> None:
        html = Path("docs/globe/index.html").read_text(encoding="utf-8")
        css = Path("docs/stylesheets/globe.css").read_text(encoding="utf-8")
        loader = Path("docs/javascripts/load-cesium-globe.js").read_text(
            encoding="utf-8"
        )
        globe_script = Path("docs/javascripts/cesium-globe.js").read_text(
            encoding="utf-8"
        )
        default_config = json.loads(
            Path("docs/globe/globe-config.json").read_text(encoding="utf-8")
        )

        self.assertIn('class="standalone-globe-root"', html)
        self.assertIn('id="globe-depth-level-ticks"', html)
        self.assertIn("ARGO Locations", html)
        self.assertIn('loading="lazy"', html)
        self.assertIn(".standalone-globe-root,", css)
        self.assertIn("box-sizing: border-box;", css)
        self.assertIn('document.querySelectorAll("script[src]")', loader)
        self.assertIn('new URL("/javascripts/", document.baseURI)', loader)
        self.assertIn("function resolveConfigUrl()", globe_script)
        self.assertIn(
            "new URL(configParam, window.location.href).toString()", globe_script
        )
        self.assertIn("Full Sample #", globe_script)
        self.assertIn("depth_levels", default_config)

    def test_sync_with_rclone_warns_when_missing(self) -> None:
        with mock.patch(
            "inference.export_cesium_globe_assets.shutil.which", return_value=None
        ):
            ok, message = _sync_with_rclone(
                Path("inference/outputs/example/globe"), "r2:bucket/path"
            )

        self.assertFalse(ok)
        self.assertIn("rclone was not found", message)

    def test_sync_with_rclone_streams_progress(self) -> None:
        with (
            mock.patch(
                "inference.export_cesium_globe_assets.shutil.which",
                return_value="/usr/bin/rclone",
            ),
            mock.patch(
                "inference.export_cesium_globe_assets.subprocess.run"
            ) as run_mock,
        ):
            ok, message = _sync_with_rclone(
                Path("inference/outputs/example/globe"), "r2:bucket/path"
            )

        self.assertTrue(ok)
        self.assertIn("completed successfully", message)
        run_mock.assert_called_once_with(
            [
                "/usr/bin/rclone",
                "sync",
                "--progress",
                "inference/outputs/example/globe",
                "r2:bucket/path",
            ],
            check=True,
            text=True,
        )

    def test_resolve_rclone_sync_source_uses_globe_dir_for_globe_scope(self) -> None:
        run_dir = Path("inference/outputs/inference_production")
        globe_dir = run_dir / "globe"

        source, label = _resolve_rclone_sync_source(
            run_dir=run_dir,
            globe_dir=globe_dir,
            sync_scope="globe",
        )

        self.assertEqual(source, globe_dir)
        self.assertEqual(label, "globe assets")

    def test_resolve_rclone_sync_source_uses_run_dir_for_run_scope(self) -> None:
        run_dir = Path("inference/outputs/inference_production")
        globe_dir = run_dir / "globe"

        source, label = _resolve_rclone_sync_source(
            run_dir=run_dir,
            globe_dir=globe_dir,
            sync_scope="run",
        )

        self.assertEqual(source, run_dir)
        self.assertEqual(label, "run directory")

    def test_build_gdal2tiles_command_uses_nearest_neighbor_and_respects_extra_zoom_levels(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tif_path = Path(tmp_dir) / "prediction.tif"
            output_dir = Path(tmp_dir) / "tiles"
            with rasterio.open(
                tif_path,
                "w",
                driver="GTiff",
                height=128,
                width=256,
                count=1,
                dtype="float32",
                crs="EPSG:4326",
                transform=from_origin(-180.0, 90.0, 360.0 / 256.0, 180.0 / 128.0),
            ) as ds:
                ds.write(np.ones((1, 128, 256), dtype=np.float32))

            with mock.patch(
                "inference.export_cesium_globe_assets.shutil.which",
                return_value="/usr/bin/gdal2tiles.py",
            ):
                command = _build_gdal2tiles_command(
                    tif_path,
                    output_dir,
                    extra_zoom_levels=1,
                )

        self.assertEqual(command[0], "/usr/bin/gdal2tiles.py")
        self.assertIn("-r", command)
        self.assertIn("near", command)
        self.assertIn("-z", command)
        self.assertIn("0-1", command)

    def test_build_parser_defaults_to_zero_extra_zoom_levels(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["--run-dir", "inference/outputs/example"])

        self.assertEqual(args.extra_zoom_levels, 0)
        self.assertEqual(args.rclone_sync_scope, DEFAULT_RCLONE_SYNC_SCOPE)

    def test_resolve_depth_export_artifacts_uses_run_summary_depth_exports(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            run_dir = Path(tmp_dir)
            prediction_surface = (
                run_dir / "global_top_band_20260105_prediction_surface.tif"
            )
            prediction_100m = run_dir / "global_top_band_20260105_prediction_100m.tif"
            ground_truth_surface = (
                run_dir / "global_top_band_20260105_glorys_surface.tif"
            )
            for path in (prediction_surface, prediction_100m, ground_truth_surface):
                path.write_text("placeholder", encoding="utf-8")

            depth_exports = _resolve_depth_export_artifacts(
                run_dir=run_dir,
                run_summary={
                    "depth_exports": [
                        {
                            "suffix": "surface",
                            "label": "Surface",
                            "requested_depth_m": 0.0,
                            "actual_depth_m": 0.5,
                            "channel_index": 0,
                            "prediction_tif_path": prediction_surface.name,
                            "ground_truth_tif_path": ground_truth_surface.name,
                        },
                        {
                            "suffix": "100m",
                            "label": "100m",
                            "requested_depth_m": 100.0,
                            "actual_depth_m": 97.0,
                            "channel_index": 1,
                            "prediction_tif_path": prediction_100m.name,
                            "ground_truth_tif_path": None,
                        },
                    ]
                },
                prediction_path=prediction_surface,
                ground_truth_path=ground_truth_surface,
            )

        self.assertEqual(
            [item["suffix"] for item in depth_exports], ["surface", "100m"]
        )
        self.assertEqual(depth_exports[0]["prediction_path"], prediction_surface)
        self.assertEqual(depth_exports[0]["ground_truth_path"], ground_truth_surface)
        self.assertIsNone(depth_exports[1]["ground_truth_path"])
        self.assertEqual(depth_exports[1]["channel_index"], 1)

    def test_estimate_native_zoom_level_matches_global_point_one_degree_raster(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tif_path = Path(tmp_dir) / "global_0p1deg.tif"
            with rasterio.open(
                tif_path,
                "w",
                driver="GTiff",
                height=1800,
                width=3600,
                count=1,
                dtype="float32",
                crs="EPSG:4326",
                transform=from_origin(-180.0, 90.0, 0.1, 0.1),
            ) as ds:
                ds.write(np.ones((1, 1800, 3600), dtype=np.float32))

            zoom_level = _estimate_native_zoom_level(tif_path)

        self.assertEqual(zoom_level, 4)

    def test_rewrite_geojson_rounds_coordinates_and_drops_unused_point_properties(
        self,
    ) -> None:
        payload = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "id": "argo-1",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [12.1234567, -45.7654321],
                    },
                    "properties": {"profile_id": 7, "temperature": 18.4},
                }
            ],
        }

        with tempfile.TemporaryDirectory() as tmp_dir:
            source_path = Path(tmp_dir) / "source.geojson"
            destination_path = Path(tmp_dir) / "rewritten.geojson"
            source_path.write_text(json.dumps(payload), encoding="utf-8")

            _rewrite_geojson(
                source_path,
                destination_path,
                allowed_property_keys=(),
            )

            rewritten = json.loads(destination_path.read_text(encoding="utf-8"))

        feature = rewritten["features"][0]
        self.assertEqual(feature["id"], "argo-1")
        self.assertEqual(feature["geometry"]["coordinates"], [12.1235, -45.7654])
        self.assertNotIn("properties", feature)

    def test_rewrite_geojson_keeps_argo_point_popup_properties(self) -> None:
        payload = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [12.1234567, -45.7654321],
                    },
                    "properties": {
                        "date": 20260105,
                        "patch_id": "patch-7",
                        "export_index": 11,
                        "pixel_row": 2,
                        "pixel_col": 3,
                        "temperature": 18.4,
                    },
                }
            ],
        }

        with tempfile.TemporaryDirectory() as tmp_dir:
            source_path = Path(tmp_dir) / "source.geojson"
            destination_path = Path(tmp_dir) / "rewritten.geojson"
            source_path.write_text(json.dumps(payload), encoding="utf-8")

            _rewrite_geojson(
                source_path,
                destination_path,
                allowed_property_keys=ARGO_POINT_PROPERTY_KEYS,
            )

            rewritten = json.loads(destination_path.read_text(encoding="utf-8"))

        self.assertEqual(
            rewritten["features"][0]["properties"],
            {
                "date": 20260105,
                "patch_id": "patch-7",
                "export_index": 11,
                "pixel_row": 2,
                "pixel_col": 3,
            },
        )
        self.assertNotIn("temperature", rewritten["features"][0]["properties"])

    def test_rewrite_geojson_keeps_only_required_popup_and_split_properties(
        self,
    ) -> None:
        payload = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [1.123456, 2.654321],
                                [3.123456, 4.654321],
                                [5.123456, 6.654321],
                                [1.123456, 2.654321],
                            ]
                        ],
                    },
                    "properties": {
                        "split": "train",
                        "unused": "value",
                    },
                },
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [-10.123456, 44.987654],
                    },
                    "properties": {
                        "date": 20260105,
                        "graph_png_path": "graphs/example.png",
                        "location_id": "sample-17",
                        "patch_id": "patch-3",
                        "pixel_row": 9,
                        "pixel_col": 11,
                        "extra": "drop-me",
                    },
                },
            ],
        }

        with tempfile.TemporaryDirectory() as tmp_dir:
            source_path = Path(tmp_dir) / "source.geojson"
            patch_destination_path = Path(tmp_dir) / "patch.geojson"
            full_sample_destination_path = Path(tmp_dir) / "full_sample.geojson"
            source_path.write_text(json.dumps(payload), encoding="utf-8")

            _rewrite_geojson(
                source_path,
                patch_destination_path,
                allowed_property_keys=("split",),
            )
            _rewrite_geojson(
                source_path,
                full_sample_destination_path,
                allowed_property_keys=FULL_SAMPLE_PROPERTY_KEYS,
            )

            rewritten_patch = json.loads(
                patch_destination_path.read_text(encoding="utf-8")
            )
            rewritten_full_sample = json.loads(
                full_sample_destination_path.read_text(encoding="utf-8")
            )

        self.assertEqual(
            rewritten_patch["features"][0]["properties"],
            {"split": "train"},
        )
        self.assertEqual(
            rewritten_patch["features"][0]["geometry"]["coordinates"][0][0],
            [1.1235, 2.6543],
        )
        self.assertEqual(
            rewritten_full_sample["features"][1]["properties"],
            {
                "date": 20260105,
                "graph_png_path": "graphs/example.png",
                "location_id": "sample-17",
                "patch_id": "patch-3",
                "pixel_row": 9,
                "pixel_col": 11,
            },
        )
        self.assertEqual(
            rewritten_full_sample["features"][1]["geometry"]["coordinates"],
            [-10.1235, 44.9877],
        )

    def test_rewrite_argo_sample_locations_geojson_merges_marker_types_without_duplicates(
        self,
    ) -> None:
        argo_payload = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [10.123456, -20.654321],
                    },
                    "properties": {
                        "date": 20260105,
                        "patch_id": "patch-1",
                        "export_index": 4,
                        "pixel_row": 5,
                        "pixel_col": 6,
                    },
                },
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [15.987654, -30.123456],
                    },
                    "properties": {
                        "date": 20260105,
                        "patch_id": "patch-2",
                        "export_index": 8,
                        "pixel_row": 7,
                        "pixel_col": 9,
                    },
                },
            ],
        }
        full_sample_payload = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [15.9876544, -30.1234564],
                    },
                    "properties": {
                        "date": 20260105,
                        "graph_png_path": "graphs/full_sample_001.png",
                        "location_id": "full_sample_001",
                        "patch_id": "patch-2",
                        "pixel_row": 7,
                        "pixel_col": 9,
                    },
                }
            ],
        }

        with tempfile.TemporaryDirectory() as tmp_dir:
            argo_source_path = Path(tmp_dir) / "argo.geojson"
            full_sample_source_path = Path(tmp_dir) / "full_sample.geojson"
            destination_path = Path(tmp_dir) / "combined.geojson"
            argo_source_path.write_text(json.dumps(argo_payload), encoding="utf-8")
            full_sample_source_path.write_text(
                json.dumps(full_sample_payload), encoding="utf-8"
            )

            _rewrite_argo_sample_locations_geojson(
                destination_path,
                points_path=argo_source_path,
                full_sample_points_path=full_sample_source_path,
            )

            combined = json.loads(destination_path.read_text(encoding="utf-8"))

        self.assertEqual(len(combined["features"]), 2)
        argo_feature = combined["features"][0]
        full_sample_feature = combined["features"][1]
        self.assertEqual(
            argo_feature["properties"],
            {
                "date": 20260105,
                "patch_id": "patch-1",
                "export_index": 4,
                "pixel_row": 5,
                "pixel_col": 6,
                "marker_kind": "argo",
                "has_full_depth_graph": False,
            },
        )
        self.assertEqual(
            full_sample_feature["properties"],
            {
                "date": 20260105,
                "graph_png_path": "graphs/full_sample_001.png",
                "location_id": "full_sample_001",
                "patch_id": "patch-2",
                "pixel_row": 7,
                "pixel_col": 9,
                "marker_kind": "full_depth_profile",
                "has_full_depth_graph": True,
            },
        )
        self.assertEqual(
            full_sample_feature["geometry"]["coordinates"],
            [15.9877, -30.1235],
        )
        self.assertIn("marker_kind", ARGO_SAMPLE_LOCATION_PROPERTY_KEYS)
        self.assertIn("has_full_depth_graph", ARGO_SAMPLE_LOCATION_PROPERTY_KEYS)


if __name__ == "__main__":
    unittest.main()
