"""Tests for sync runners."""
