"""Single-file helper for extracting container metadata as template variables."""

import logging
import typing as t

import flywheel
from dotty_dict import Dotty

log = logging.getLogger(__name__)


def get_container_metadata(  # noqa PLR0913 (too many arguments)
    client: flywheel.Client,
    file_id: str,
    proj_vars: t.Optional[list] = None,
    subj_vars: t.Optional[list] = None,
    sess_vars: t.Optional[list] = None,
    acq_vars: t.Optional[list] = None,
) -> dict:
    """Fetch metadata from a file's parent containers.

    Returns a flat dict with underscore keys matching the clean_jinja
    transformation (e.g., ``subject.info.site_id`` ->
    ``subject_info_site_id``).

    Args:
        client: Flywheel SDK client
        file_id: The file_id of the input file
        proj_vars: Variables prefixed with ``project.``
        subj_vars: Variables prefixed with ``subject.``
        sess_vars: Variables prefixed with ``session.``
        acq_vars: Variables prefixed with ``acquisition.``

    Returns:
        dict with underscore keys mapped to metadata values
    """
    proj_vars = proj_vars or []
    subj_vars = subj_vars or []
    sess_vars = sess_vars or []
    acq_vars = acq_vars or []

    fw_file = client.get_file(file_id)
    parents = fw_file.parents
    updates = {}

    if proj_vars:
        project = client.get_project(parents["project"])
        _extract_vars(project.to_dict(), proj_vars, "project", updates)

    if subj_vars:
        sub_id = parents["subject"]
        if sub_id is None:
            raise ValueError(
                "Template contains subject.* variables but the input file "
                "does not have a subject container parent. Variables cannot be resolved: "
                f"{subj_vars}"
            )
        subject = client.get_subject(sub_id)
        _extract_vars(subject.to_dict(), subj_vars, "subject", updates)

    if sess_vars:
        ses_id = parents["session"]
        if ses_id is None:
            raise ValueError(
                "Template contains session.* variables but the input file "
                "does not have a session container parent. Variables cannot be resolved: "
                f"{sess_vars}"
            )
        session = client.get_session(ses_id)
        _extract_vars(session.to_dict(), sess_vars, "session", updates)

    if acq_vars:
        acq_id = parents["acquisition"]
        if acq_id is None:
            raise ValueError(
                "Template contains acquisition.* variables but the input file "
                "does not have an acquisition container parent. Variables cannot be resolved: "
                f"{acq_vars}"
            )
        acquisition = client.get_acquisition(acq_id)
        _extract_vars(acquisition.to_dict(), acq_vars, "acquisition", updates)

    return updates


def _extract_vars(
    container_dict: dict,
    variables: list,
    prefix: str,
    updates: dict,
) -> None:
    """Extract variable values from a container dict using Dotty.

    Args:
        container_dict: The container's dict representation
        variables: Dotted variable names (e.g., ``subject.info.X``)
        prefix: Container prefix to strip (e.g., ``subject``)
        updates: Dict to populate with underscore-keyed results
    """
    dotty = Dotty(container_dict)
    for var in variables:
        dotty_path = var.removeprefix(f"{prefix}.")
        val = dotty.get(dotty_path)
        if val is not None:
            key = var.replace(".", "_")
            updates[key] = val
        else:
            log.warning(
                f"No value found for '{var}' in {prefix} "
                "container. Variable will not be resolved."
            )
