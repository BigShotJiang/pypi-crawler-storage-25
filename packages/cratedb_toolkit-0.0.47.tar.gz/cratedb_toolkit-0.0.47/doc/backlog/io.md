# Backlog for `ctk {load,save}`

## General
- ingestr: Educate about batch size (`page_size`)
- ingestr: More parameters for Kinesis
  - https://getbruin.com/docs/ingestr/commands/ingest.html
  - https://getbruin.com/docs/ingestr/supported-sources/kinesis.html
  - ```python
    # incremental_strategy="delete+insert",
    # mask=["temperature:noise:0.35", "temperature:round:100"],
    # full_refresh=True,
    # progress="interactive",  # log, interactive
    ```

## Apache Iceberg

- Exercise access with Iceberg REST catalogs
  https://altinity.com/blog/introducing-altinity-ice-a-simple-toolset-for-iceberg-rest-catalogs

- Exercise end-to-end integration with e.g. Google Cloud
  https://opensource.googleblog.com/2026/01/explore-public-datasets-with-apache-iceberg-and-biglake.html
  https://cloud.google.com/blog/products/data-analytics/announcing-bigquery-tables-for-apache-iceberg

- Verify on Windows
  Example: `--conf spark.sql.catalog.my_catalog.warehouse=file:///D:/sparksetup/iceberg/spark_warehouse`
  https://medium.com/itversity/iceberg-catalogs-a-guide-for-data-engineers-a6190c7bf381

- Compression!

- Auth!
  https://github.com/apache/iceberg/issues/13550

- Can the postgresql catalog implementation be used with CrateDB?

- Verify with other catalogs: https://py.iceberg.apache.org/configuration/#common-integrations-examples
