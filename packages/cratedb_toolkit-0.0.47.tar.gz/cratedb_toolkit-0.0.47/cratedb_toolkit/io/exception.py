class SkipAdapterException(Exception):
    pass
