# AskRow — Simple, Safe User Input for Python

[![PyPI Version](https://img.shields.io/pypi/v/askrow-py)](https://pypi.org/project/askrow-py/)
[![Python Versions](https://img.shields.io/pypi/pyversions/askrow-py)](https://pypi.org/project/askrow-py/)

AskRow is a beginner-friendly Python library that makes handling user input easy, clean, and reliable. It replaces Python's built-in `input()` with a smarter, more structured approach that automatically validates data, handles errors, and ensures users provide the correct input without writing repetitive code.

## Installation

```bash
pip install askrow-py
```

## Features

- **Type-safe input** - Get integers, floats, text, booleans with automatic type conversion
- **Built-in validation** - Validate ranges, length, patterns, and email formats
- **Automatic retry** - Re-prompts users when invalid input is entered
- **Clear error messages** - Friendly, human-readable error messages
- **Simple API** - Minimal, intuitive design for beginners
- **Password input** - Hidden password entry
- **Choice menus** - Select from a list of options
- **Form builder** - Collect multiple fields at once
- **Confirm dialogs** - Yes/No confirmation and value matching
- **File picker** - Validate file paths with extensions

## Quick Start

```python
from askrow_py import ask

age = ask.int("Enter your age: ", min_value=0, max_value=120)
name = ask.text("Enter your name: ", min_length=1, max_length=50)
email = ask.email("Enter your email: ")
is_student = ask.bool("Are you a student? (yes/no): ")
```

## API Reference

### ask.text(prompt, min_length, max_length, pattern, required)

Get text input with optional validation.

```python
name = ask.text("Enter your name: ", min_length=2, max_length=50)
```

### ask.int(prompt, min_value, max_value)

Get integer input with optional range validation.

```python
age = ask.int("Enter your age: ", min_value=0, max_value=120)
score = ask.int("Enter your score: ", min_value=0, max_value=100)
```

### ask.float(prompt, min_value, max_value)

Get float input with optional range validation.

```python
price = ask.float("Enter price: ", min_value=0.0)
height = ask.float("Enter height (cm): ", min_value=0, max_value=300)
```

### ask.bool(prompt, true_values, false_values)

Get boolean input with customizable true/false values.

```python
is_active = ask.bool("Is active? (yes/no): ")
```

### ask.email(prompt)

Get validated email address.

```python
email = ask.email("Enter your email: ")
```

### ask.password(prompt, min_length, max_length)

Get hidden password input.

```python
password = ask.password("Enter password: ", min_length=8)
```

### ask.choice(prompt, options, case_sensitive)

Select from a list of options.

```python
color = ask.choice("Choose color: ", options=["red", "green", "blue"])
day = ask.choice("Choose day: ", options=["Monday", "Tuesday", "Wednesday"])
```

### ask.confirm(prompt, default) or ask.confirm(prompt, match=value)

Get yes/no confirmation OR confirm if input matches a value.

```python
# Yes/No confirmation
if ask.confirm("Delete file?", default=False):
    print("File deleted")

# Password confirmation (match two inputs)
password = ask.password("Enter password: ", min_length=8)
confirm = ask.confirm("Confirm password: ", match=password)
```

### ask.menu(prompt, options)

Display a numbered menu and get user selection.

```python
choice = ask.menu("Select option:", ["Create Project", "Run App", "Exit"])
print(f"You chose: {choice}")
```

### ask.file(prompt, exists, extensions, must_be_file, must_be_dir)

Get file path with validation.

```python
file_path = ask.file("Select file:", exists=True, extensions=[".json", ".txt"])
```

### ask.form(fields)

Collect multiple fields in a single form.

```python
user = ask.form([
    {"name": "name", "type": "text", "message": "Name:"},
    {"name": "age", "type": "int", "message": "Age:"},
    {"name": "email", "type": "email", "message": "Email:"},
    {"name": "password", "type": "password", "message": "Password:"}
])
print(user)  # {"name": "John", "age": 25, "email": "john@example.com", "password": "..."}
```

## License

MIT License