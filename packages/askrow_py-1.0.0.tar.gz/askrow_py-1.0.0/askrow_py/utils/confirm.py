from typing import List, Optional, Union


def _prompt(message: str) -> str:
    return input(message)


def _error(message: str) -> None:
    import sys
    print(f"Error: {message}", file=sys.stderr)


class AskConfirm:
    def confirm(
        self,
        prompt: str,
        default: bool = False,
        yes_values: Optional[List[str]] = None,
        no_values: Optional[List[str]] = None,
        match: Optional[str] = None,
        match_error: str = "Values do not match. Please try again.",
    ) -> Union[bool, str]:
        if match is not None:
            while True:
                value = _prompt(prompt).strip()
                if value == match:
                    return value
                _error(match_error)

        if yes_values is None:
            yes_values = ["yes", "y", "true", "t", "1"]
        if no_values is None:
            no_values = ["no", "n", "false", "f", "0"]

        default_str = "[Y/n]" if default else "[y/N]"
        prompt_with_default = f"{prompt} {default_str}: "

        while True:
            value = _prompt(prompt_with_default).strip().lower()

            if not value:
                return default

            if value in yes_values:
                return True
            elif value in no_values:
                return False
            else:
                _error(f"Please enter: {', '.join(yes_values + no_values)}")