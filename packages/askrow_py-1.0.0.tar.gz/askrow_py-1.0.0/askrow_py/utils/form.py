from typing import Dict, List


def _error(message: str) -> None:
    import sys
    print(f"Error: {message}", file=sys.stderr)


class AskForm:
    def form(
        self,
        fields: List[Dict[str, any]],
        stop_on_cancel: bool = True,
    ) -> Dict[str, any]:
        result = {}

        for field in fields:
            name = field.get("name")
            field_type = field.get("type", "text")
            message = field.get("message", f"Enter {name}: ")

            try:
                if field_type == "text":
                    value = self.text(message)
                elif field_type == "int":
                    value = self.int(message)
                elif field_type == "float":
                    value = self.float(message)
                elif field_type == "bool":
                    value = self.bool(message)
                elif field_type == "email":
                    value = self.email(message)
                elif field_type == "password":
                    value = self.password(message)
                elif field_type == "choice":
                    options = field.get("options", [])
                    value = self.choice(message, options)
                else:
                    value = self.text(message)

                if stop_on_cancel and not value:
                    break

                result[name] = value
            except Exception:
                if stop_on_cancel:
                    break
                result[name] = None

        return result