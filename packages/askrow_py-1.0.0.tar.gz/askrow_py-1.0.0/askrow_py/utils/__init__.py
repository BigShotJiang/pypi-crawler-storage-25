from .core import AskCore
from .confirm import AskConfirm
from .menu import AskMenu
from .file import AskFile
from .form import AskForm


class Ask(AskCore, AskConfirm, AskMenu, AskFile, AskForm):
    pass


ask = Ask()

__all__ = ["ask"]