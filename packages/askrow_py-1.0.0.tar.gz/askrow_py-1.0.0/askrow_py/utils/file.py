import os
from typing import List, Optional


def _prompt(message: str) -> str:
    return input(message)


def _error(message: str) -> None:
    import sys
    print(f"Error: {message}", file=sys.stderr)


class AskFile:
    def file(
        self,
        prompt: str,
        exists: bool = False,
        extensions: Optional[List[str]] = None,
        must_be_file: bool = True,
        must_be_dir: bool = False,
        invalid_error: str = "Invalid file path.",
    ) -> str:
        while True:
            value = _prompt(prompt).strip()

            if not value:
                _error("Path cannot be empty.")
                continue

            path = os.path.abspath(value)

            if must_be_file and not os.path.isfile(path):
                if exists and not os.path.exists(path):
                    _error("File does not exist.")
                    continue

            if must_be_dir and not os.path.isdir(path):
                _error("Path is not a directory.")
                continue

            if extensions:
                if not any(path.endswith(ext) for ext in extensions):
                    _error(f"File must have one of these extensions: {', '.join(extensions)}")
                    continue

            return path