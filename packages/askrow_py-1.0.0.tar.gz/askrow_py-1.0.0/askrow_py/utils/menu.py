from typing import List


def _prompt(message: str) -> str:
    return input(message)


def _error(message: str) -> None:
    import sys
    print(f"Error: {message}", file=sys.stderr)


class AskMenu:
    def menu(
        self,
        prompt: str,
        options: List[str],
        start_index: int = 1,
    ) -> str:
        print(prompt)
        for i, option in enumerate(options, start=start_index):
            print(f"  {i}. {option}")

        while True:
            value = _prompt("Enter choice: ").strip()

            try:
                index = int(value)
                if start_index <= index < start_index + len(options):
                    return options[index - start_index]
                _error(f"Please enter a number between {start_index} and {start_index + len(options) - 1}")
            except ValueError:
                _error("Please enter a valid number.")