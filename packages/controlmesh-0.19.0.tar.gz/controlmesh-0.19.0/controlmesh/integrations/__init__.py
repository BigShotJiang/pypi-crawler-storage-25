"""Optional external integration adapters."""

