"""Bundled ControlMesh plugins."""
