"""Pine Labs Agent Toolkit — payment APIs as tools for AI agent frameworks.

This is the top-level package. Framework adapters live in subpackages:

* :mod:`pinelabs_agent_toolkit.openai` — OpenAI Chat Completions + Agents SDK
* :mod:`pinelabs_agent_toolkit.langchain` — LangChain ``StructuredTool``
* :mod:`pinelabs_agent_toolkit.pydantic_ai` — Pydantic AI ``Tool``
* :mod:`pinelabs_agent_toolkit.crewai` — CrewAI ``BaseTool`` subclasses
* :mod:`pinelabs_agent_toolkit.anthropic` — Anthropic Messages tool blocks

Each adapter's framework dependency is optional — install the matching extra
(e.g. ``pip install 'pinelabs-agent-toolkit[openai]'``).
"""
from .shared import (
    ALL_TOOLS,
    Pinelabs,
    PinelabsClientOptions,
    PinelabsEnvironment,
    ToolDefinition,
    pinelabs_environment,
)

__all__ = [
    "ALL_TOOLS",
    "Pinelabs",
    "PinelabsClientOptions",
    "PinelabsEnvironment",
    "ToolDefinition",
    "pinelabs_environment",
]

__version__ = "0.1.0"
