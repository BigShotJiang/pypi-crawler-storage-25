"""OpenAI adapter for the Pine Labs Agent Toolkit.

Exposes Pine Labs payment APIs in two shapes:

* :meth:`PinelabsAgentToolkit.get_tools` — Chat Completions ``tools`` array.
* :meth:`PinelabsAgentToolkit.get_agent_tools` — OpenAI Agents SDK
  ``FunctionTool`` list (loaded lazily so the agents extra is optional).

Example
-------
.. code-block:: python

    from pinelabs_agent_toolkit.openai import PinelabsAgentToolkit
    from pinelabs_agent_toolkit.shared import pinelabs_environment

    toolkit = PinelabsAgentToolkit(
        environment=pinelabs_environment["UAT"],
        client_id="<client-id>",
        client_secret="<client-secret>",
    )

    import openai
    client = openai.OpenAI()
    messages = [{"role": "user", "content": "Create a 500 INR order."}]
    while True:
        resp = client.chat.completions.create(
            model="gpt-4o", messages=messages, tools=toolkit.get_tools(),
        )
        msg = resp.choices[0].message
        messages.append(msg)
        if not msg.tool_calls:
            break
        for call in msg.tool_calls:
            out = toolkit.handle_tool_call(call.function.name, call.function.arguments)
            messages.append({"role": "tool", "tool_call_id": call.id, "content": out})
"""
from __future__ import annotations

import json
from typing import Any, List

from ..shared import ALL_TOOLS, Pinelabs, ToolDefinition


class PinelabsAgentToolkit:
    """Pine Labs tools for OpenAI Chat Completions and Agents SDK."""

    def __init__(
        self,
        *,
        environment: str,
        client_id: str,
        client_secret: str,
    ) -> None:
        self._client = Pinelabs(
            environment=environment,
            client_id=client_id,
            client_secret=client_secret,
        )
        self._tools: List[ToolDefinition] = list(ALL_TOOLS)

    # ─── Chat Completions ──────────────────────────────────────────────

    def get_tools(self) -> List[dict]:
        """Return Pine Labs operations as Chat Completions tool dicts."""
        return [
            {
                "type": "function",
                "function": {
                    "name": td.name,
                    "description": td.description,
                    "parameters": _json_schema(td),
                },
            }
            for td in self._tools
        ]

    def handle_tool_call(self, name: str, arguments: Any) -> str:
        """Run a tool by name with raw arguments (str, dict, or pydantic)."""
        td = _find(self._tools, name)
        payload = arguments
        if isinstance(arguments, str):
            payload = json.loads(arguments) if arguments.strip() else {}
        return td.execute(self._client, payload or {})

    # ─── OpenAI Agents SDK ─────────────────────────────────────────────

    def get_agent_tools(self) -> List[Any]:
        """Return Pine Labs operations as ``agents.FunctionTool`` instances.

        Requires the optional ``openai-agents`` package — install with
        ``pip install 'pinelabs-agent-toolkit[openai]'``.
        """
        try:
            from agents import FunctionTool  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover — import-guarded path
            raise ImportError(
                "openai-agents is not installed. Run "
                "`pip install 'pinelabs-agent-toolkit[openai]'`."
            ) from exc

        client = self._client
        out: List[Any] = []
        for td in self._tools:
            out.append(_build_function_tool(FunctionTool, td, client))
        return out


def _json_schema(td: ToolDefinition) -> dict:
    schema = td.parameters.model_json_schema(by_alias=True)
    # Strip the ``title`` pydantic always emits — OpenAI's strict-mode
    # validator complains when a top-level title is present alongside
    # ``additionalProperties: false``.
    schema.pop("title", None)
    return schema


def _find(tools: List[ToolDefinition], name: str) -> ToolDefinition:
    for td in tools:
        if td.name == name:
            return td
    raise KeyError(f"Unknown Pine Labs tool: {name!r}")


def _build_function_tool(FunctionTool: Any, td: ToolDefinition, client: Pinelabs) -> Any:
    async def _on_invoke(_ctx: Any, input_str: str) -> str:
        payload = json.loads(input_str) if input_str else {}
        return td.execute(client, payload)

    return FunctionTool(
        name=td.name,
        description=td.description,
        params_json_schema=_json_schema(td),
        on_invoke_tool=_on_invoke,
    )
