import os
import subprocess
import tempfile
from pathlib import Path

# Scene-change threshold (0.0–1.0).
# 0.15 works well for screen recordings where UI transitions are subtle
# (taps, slides, content changes). Lower = more frames captured.
SCENE_THRESHOLD = float(os.getenv("SCENE_THRESHOLD", "0.15"))

# Fall back to fps-based extraction when scene detection yields fewer
# than this many frames (e.g. very short or mostly-static recordings).
MIN_SCENE_FRAMES = int(os.getenv("MIN_SCENE_FRAMES", "3"))

# Videos larger than this (MB) are compressed before frame extraction.
# Keeps processing fast and avoids Supabase storage limits on upload.
COMPRESS_THRESHOLD_MB = float(os.getenv("COMPRESS_THRESHOLD_MB", "50"))
FFMPEG_TIMEOUT_SECONDS = int(os.getenv("FFMPEG_TIMEOUT_SECONDS", "600"))


def compress_video(input_path: str) -> tuple[str, bool]:
    """Compress a video to a temp file if it exceeds COMPRESS_THRESHOLD_MB.

    Downscales to max 1280px wide, H.264 CRF 28, 30fps cap — sufficient
    quality for frame extraction. Returns (path_to_use, was_compressed).
    Caller is responsible for deleting the temp file if was_compressed=True.
    """
    size_mb = os.path.getsize(input_path) / (1024 * 1024)
    if size_mb <= COMPRESS_THRESHOLD_MB:
        return input_path, False

    print(f"[ffmpeg] video is {size_mb:.1f} MB — compressing before extraction")
    tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
    tmp.close()

    cmd = [
        "ffmpeg", "-i", input_path,
        "-vf", "scale='min(1280,iw)':-2",
        "-c:v", "libx264", "-crf", "28", "-preset", "fast",
        "-r", "30",
        "-an",           # strip audio — not needed for frame extraction
        "-y", tmp.name,
        "-loglevel", "error",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=FFMPEG_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        os.unlink(tmp.name)
        print(f"[warn] compression timed out after {FFMPEG_TIMEOUT_SECONDS}s, using original")
        return input_path, False
    if result.returncode != 0:
        os.unlink(tmp.name)
        print(f"[warn] compression failed, using original: {result.stderr.strip()}")
        return input_path, False

    compressed_mb = os.path.getsize(tmp.name) / (1024 * 1024)
    print(f"[ffmpeg] compressed {size_mb:.1f} MB → {compressed_mb:.1f} MB")
    return tmp.name, True


def extract_frames(input_path: str, output_dir: str, fps: int = 1) -> list[str]:
    """Extract frames using scene-change detection with fps fallback.

    Captures only frames where the screen meaningfully changes — typically
    5-15x fewer frames than 1fps for screen recordings. Falls back to
    fps-based extraction when scene detection yields too few frames.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Scene-change extraction — write directly to output_dir
    cmd_scene = [
        "ffmpeg", "-i", input_path,
        "-vf", f"select=gt(scene\\,{SCENE_THRESHOLD}),scale=1280:-2",
        "-vsync", "vfr",
        "-q:v", "2",
        f"{output_dir}/frame_%04d.jpg",
        "-y", "-loglevel", "error",
    ]
    try:
        result = subprocess.run(cmd_scene, capture_output=True, text=True, timeout=FFMPEG_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        result = None
        print(f"[warn] scene detection timed out after {FFMPEG_TIMEOUT_SECONDS}s, falling back to 1fps")
    if result is None or result.returncode != 0:
        exit_code = "timeout" if result is None else result.returncode
        stderr = "" if result is None else result.stderr.strip()
        print(f"[warn] scene detection failed (exit {exit_code}), falling back to 1fps: {stderr}")
    else:
        frames = sorted(str(f) for f in Path(output_dir).glob("frame_*.jpg"))
        if len(frames) >= MIN_SCENE_FRAMES:
            return frames

    # Fallback: clear any partial scene output and run 1fps extraction
    for f in Path(output_dir).glob("frame_*.jpg"):
        f.unlink()

    cmd_fps = [
        "ffmpeg", "-i", input_path,
        "-vf", f"fps={fps}",
        "-q:v", "2",
        f"{output_dir}/frame_%04d.jpg",
        "-y", "-loglevel", "error",
    ]
    try:
        result = subprocess.run(cmd_fps, capture_output=True, text=True, timeout=FFMPEG_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"ffmpeg timed out after {FFMPEG_TIMEOUT_SECONDS}s during fallback extraction") from exc
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg failed: {result.stderr}")
    return sorted(str(f) for f in Path(output_dir).glob("frame_*.jpg"))
