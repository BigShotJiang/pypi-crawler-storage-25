from setuptools import setup


setup(
    name="openclaw-etg-pomme-native-runtime",
    version="1.0.1",
    description="Compiled runtime for the Pomme ExteraGram plugin.",
    author="openclaw",
    packages=["openclaw_etg_pomme_native_runtime"],
    package_dir={"": "src"},
    include_package_data=True,
    package_data={"openclaw_etg_pomme_native_runtime": ["pomme_native.so"]},
    zip_safe=False,
)
