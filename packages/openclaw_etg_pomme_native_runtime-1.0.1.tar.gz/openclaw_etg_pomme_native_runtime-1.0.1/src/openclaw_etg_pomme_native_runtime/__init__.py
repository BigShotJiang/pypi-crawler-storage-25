import importlib.util
import os
import sys


def _load_pomme_native():
    module_name = "pomme_native"
    cached = sys.modules.get(module_name)
    if cached is not None:
        return cached

    path = os.path.join(os.path.dirname(__file__), "pomme_native.so")
    if not os.path.exists(path):
        raise ImportError("bundled pomme_native.so not found")

    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError("extension loader is unavailable for bundled pomme_native.so")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module


_native_module = _load_pomme_native()
PommePlugin = _native_module.PommePlugin

