"""laslibrary

A python library for finding las files, reading them with lasfile, and viewing
information about their condition and contents.
"""

import lasfile as lf
import pandas as pd
import pathlib
import os


class LASLibrary():
    """
    A class for finding las files, reading them with lasfile, and viewing
    information about their condition and contents.

    Attributes:
        folders: list of folders to search for las files.
        files: a dictionary of las files, with the path as the key and the
            lasfile object as the value.
        files_df: pandas dataframe with information about the las files.
    Methods:
        add_folder: adds a folder to the list of folders to search for las
            files.
        remove_folder: removes a folder from the list of folders to search for
            las files, if it exists, also removes the las files from the files
            dictionary and files_df.
        find_las_files: searches the folders for las files and returns a
            dictionary of lasfiles.
        read_las_files: reads the las files and returns a dictionary of
            lasfiles.
    """

    def __init__(self):
        self.folders = []
        self.files = {}
        self.files_df = pd.DataFrame()
        # add the columns to the files_df
        self.files_df['path'] = None
        self.files_df['file_name'] = None
        self.files_df['file_size'] = None
        self.files_df['loaded'] = None
        self.files_df['critical_errors'] = None
        self.files_df['minor_errors'] = None
        self.files_df['api'] = None
        self.files_df['uwi'] = None
        self.files_df['well_name'] = None
        self.files_df['log_date'] = None
        self.files_df['top_depth'] = None
        self.files_df['bottom_depth'] = None
        self.files_df['mnemonics'] = None

    def __str__(self):
        return (f"laslibrary object with {len(self.files)} las files from "
                f"{len(self.folders)} folders.")

    def __repr__(self):
        return (f"laslibrary object with {len(self.files)} las files from "
                f"{len(self.folders)} folders.")

    def __len__(self):
        return len(self.files)

    def __iter__(self):
        return iter(self.files)

    def __next__(self):
        return next(self.files)

    def add_folder(self, folder, find_las=True, read_las=False):
        # add the folder to the folders list
        if folder not in self.folders:
            self.folders.append(folder)
        # find the las files in the folder
        if find_las:
            print(f"Finding las files in {folder}")
            self.find_las_files(folder)
        # read the las files
        if read_las:
            print(f"Reading las files in {folder}")
            self.read_las_files(folder)

    def remove_folder(self, folder):
        if folder in self.folders:
            # remove the folder from the folders list
            self.folders.remove(folder)
            # remove the las files from the files dictionary
            for file in self.files:
                if file.startswith(folder):
                    del self.files[file]
            # remove the las files from the files_df
            self.files_df = self.files_df[
                ~self.files_df['path'].str.startswith(folder)]

    def find_las_files(
        self,
        folder=None,
        search_subfolders=True,
        read_las=False
    ):
        # if folder is not None, search for las files in all folders
        if folder is None:
            for folder in self.folders:
                if search_subfolders:
                    for file in pathlib.Path(folder).glob('**/*.las'):
                        # If the path is not found in the files dictionary
                        # keys, add it
                        if file not in self.files:
                            # If read_las is True, read the las file and add
                            # it to the dictionary
                            if read_las:
                                self.files[file] = lf.read(file)
                            # If read_las is False, add the path to the
                            # dictionary with a value of None
                            else:
                                self.files[file] = None
                else:
                    for file in pathlib.Path(folder).glob('*.las'):
                        # If the path is not found in the files dictionary
                        # keys, add it
                        if file not in self.files:
                            # If read_las is True, read the las file and add it
                            # to the dictionary
                            if read_las:
                                self.files[file] = lf.read(file)
                            # If read_las is False, add the path to the
                            # dictionary with a value of None
                            else:
                                self.files[file] = None
        # if folder is not None, search for las files in the specified folder
        else:
            if search_subfolders:
                for file in pathlib.Path(folder).glob('**/*.las'):
                    # If the path is not found in the files dictionary keys,
                    # add it
                    if file not in self.files:
                        # If read_las is True, read the las file and add it to
                        # the dictionary
                        if read_las:
                            self.files[file] = lf.read(file)
                        # If read_las is False, add the path to the dictionary
                        # with a value of None
                        else:
                            self.files[file] = None
            else:
                for file in pathlib.Path(folder).glob('*.las'):
                    # If the path is not found in the files dictionary keys,
                    # add it
                    if file not in self.files:
                        # If read_las is True, read the las file and add it to
                        # the dictionary
                        if read_las:
                            self.files[file] = lf.read(file)
                        # If read_las is False, add the path to the dictionary
                        # with a value of None
                        else:
                            self.files[file] = None

    def add_file_to_df(self, file):
        # check if the file is already in the files_df and if so, remove
        # that row
        if file in self.files_df.index:
            self.files_df = self.files_df.drop(file)
        # add the information to the files_df
        self.files_df.loc[file, 'path'] = file
        # get the file name from the path
        self.files_df.loc[file, 'file_name'] = (
            file.name)  # Using Path.name instead of split
        # get the file size
        self.files_df.loc[file, 'file_size'] = (
            file.stat().st_size)
        # get the loaded status
        self.files_df.loc[file, 'loaded'] = True
        # get the critical errors
        self.files_df.loc[file, 'critical_errors'] = (
            lf.error_check(
                self.files[file],
                critical_only=True
            ))
        # get the minor errors
        self.files_df.loc[file, 'minor_errors'] = (
            lf.error_check(
                self.files[file],
                critical_only=False
            ))
        # get the api
        self.files_df.loc[file, 'api'] = self.files[file].get_api()
        self.files_df.loc[file, 'uwi'] = self.files[file].get_api()
        if hasattr(self.files[file], 'well'):
            # get the well name from the row of the well df where mnemonic
            # is WELL
            well_df = self.files[file].well.df
            well_rows = well_df[well_df['mnemonic'] == 'WELL']
            self.files_df.loc[file, 'well_name'] = well_rows['value'].values[0]

            # get the log date from the row of the well df where mnemonic
            # is DATE
            date_rows = well_df[well_df['mnemonic'] == 'DATE']
            self.files_df.loc[file, 'log_date'] = date_rows['value'].values[0]
        # get the mnemonics
        if hasattr(self.files[file], 'data'):
            if hasattr(self.files[file].data, 'df'):
                self.files_df.at[file, 'mnemonics'] = (
                    list(self.files[file].data.df.columns)
                )
            else:
                # If there's no data.df, set mnemonics to an empty list
                self.files_df.at[file, 'mnemonics'] = []
        else:
            self.files_df.at[file, 'mnemonics'] = []

    def read_las_files(self, folder=None, reread=False):
        # If folder is not None, read the las files in the specified folder
        if folder is not None:
            print(f"Reading las files in {folder}")
            for file in self.files:
                if file.startswith(folder):
                    # if the las file path key has a value of None, read the
                    # las file and add it to the dictionary
                    if self.files[file] is None:
                        self.files[file] = lf.read(file)
                        self.add_file_to_df(file)
                    elif reread:
                        self.files[file] = lf.read(file)
                        self.add_file_to_df(file)
        # If folder is None, read the las files in all folders
        else:
            print(f"Reading las files in all {len(self.folders)} folders")
            for file in self.files:
                # if the las file path key has a value of None, read the
                # las file and add it to the dictionary
                if self.files[file] is None:
                    self.files[file] = lf.read(file)
                    self.add_file_to_df(file)
                elif reread:
                    self.files[file] = lf.read(file)
                    self.add_file_to_df(file)

    def get_critical_error_count(self):
        # count files that fail critical error checks (False means errors found)
        return (
            self.files_df['critical_errors']
            .eq(False)
            .sum()
        )

    def get_minor_error_count(self):
        # count files that fail minor error checks (False means errors found)
        return (
            self.files_df['minor_errors']
            .eq(False)
            .sum()
        )

    def rename(self, in_place=True, output_folder=None):
        """
        Rename .las files using the format "API_Mnemonics.las".

        Args:
            in_place: If True, rename files in their original location.
                If False, copy files to output_folder with new names.
            output_folder: Required when in_place is False. The folder
                where renamed files will be copied.

        Returns:
            A dictionary mapping old file paths to new file paths.
        """
        if not in_place and output_folder is None:
            raise ValueError(
                "output_folder must be provided when in_place is False"
            )

        # Check if files need to be read (api and mnemonics not populated)
        if self.files_df['api'].isna().all() or self.files_df['mnemonics'].isna().all():
            print("Reading las files to get API and mnemonics data...")
            self.read_las_files()

        renamed_files = {}
        renamed_count = 0
        failed_files = []

        for file in self.files_df.index:
            api = self.files_df.loc[file, 'api']
            mnemonics = self.files_df.loc[file, 'mnemonics']

            # Handle missing API or mnemonics
            if api is None or (isinstance(api, float) and pd.isna(api)):
                api = "UNKNOWN"
            else:
                # API is an APINumber object, use unformatted_14_digit attribute
                api = api.unformatted_14_digit

            if mnemonics is None or (isinstance(mnemonics, float) and pd.isna(mnemonics)):
                mnemonics_str = "UNKNOWN"
            elif isinstance(mnemonics, list):
                # Filter out depth mnemonics (DEPT, DEPTH)
                filtered_mnemonics = [m for m in mnemonics if m.upper() not in ('DEPT', 'DEPTH')]
                mnemonics_str = '_'.join(filtered_mnemonics)
            else:
                mnemonics_str = str(mnemonics)

            # Sanitize filename to remove invalid Windows characters
            # Remove: < > : " / \ | ? * and control characters
            invalid_chars = r'[<>:"/\\|?*\x00-\x1f]'
            import re
            api = re.sub(invalid_chars, '', api)
            mnemonics_str = re.sub(invalid_chars, '', mnemonics_str)

            # Also remove any leading/trailing dots or spaces
            api = api.strip('. ')
            mnemonics_str = mnemonics_str.strip('. ')

            # Ensure we have something valid
            if not api:
                api = "UNKNOWN"
            if not mnemonics_str:
                mnemonics_str = "UNKNOWN"

            # Construct new filename
            new_name = f"{api}_{mnemonics_str}.las"

            # Truncate if path exceeds Windows limit (260 chars)
            # Leave room for the path prefix
            max_filename_len = 200  # Conservative limit for filename
            if len(new_name) > max_filename_len:
                # Truncate the mnemonics part, keeping the API number
                available_len = max_filename_len - len(api) - 5  # -5 for "_.las"
                if available_len > 10:
                    mnemonics_str = mnemonics_str[:available_len]
                    new_name = f"{api}_{mnemonics_str}.las"

            if in_place:
                new_path = pathlib.Path(file.parent) / new_name
            else:
                # Make output_folder relative to the original file's location
                output_path = file.parent / output_folder
                output_path.mkdir(parents=True, exist_ok=True)
                new_path = output_path / new_name

            if in_place:
                # Rename file in place
                if os.path.exists(file):
                    try:
                        file.rename(new_path)
                        # Update the files dictionary and dataframe
                        del self.files[file]
                        self.files[new_path] = self.files.pop(file)
                        self.files_df.loc[new_path] = self.files_df.loc[file]
                        self.files_df.drop(file, inplace=True)
                        self.files_df.index = self.files_df.index.delete(
                            self.files_df.index.get_loc(file)
                        )
                        self.files_df.index = self.files_df.index.insert(
                            self.files_df.index.get_loc(file), new_path
                        )
                    except Exception as e:
                        print(f"Warning: Error renaming {file.name}: {e}")
                        failed_files.append((file, str(e)))
                else:
                    failed_files.append((file, "File not found"))
            else:
                # Copy file to output folder
                import shutil
                if os.path.exists(file):
                    try:
                        shutil.copy2(file, new_path)
                    except Exception as e:
                        failed_files.append((file, str(e)))
                else:
                    failed_files.append((file, "File not found"))

            renamed_files[file] = new_path
            renamed_count += 1

        print(f"Renamed {renamed_count} files")
        if failed_files:
            print(f"\nFailed files ({len(failed_files)}):")
            for f, error in failed_files:
                print(f"  - {f}: {error}")

        return renamed_files
