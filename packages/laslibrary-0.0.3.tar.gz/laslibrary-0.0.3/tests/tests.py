def test():
    assert True