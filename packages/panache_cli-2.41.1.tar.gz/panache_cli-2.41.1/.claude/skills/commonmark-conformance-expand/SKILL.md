---
name: commonmark-conformance-expand
description: Incrementally grow Panache's CommonMark spec.txt conformance by
  triaging one failing section (or a small group sharing a root cause) at a
  time, fixing the parser or test-only renderer, and growing the allowlist.
---

Use this skill when asked to push CommonMark conformance forward, fix a
specific failing spec example, or pick "the next best section" to work on.

## Scope boundaries

- Target is the conformance harness in
  `crates/panache-parser/tests/commonmark.rs` and the parser/renderer code
  it exercises under `Flavor::CommonMark`.
- This is a **long-horizon effort**. Each session moves the pass rate by a
  bounded amount; do not try to land sweeping rewrites in one go.
- Conformance work runs *only* under `Flavor::CommonMark`. Do not branch the
  harness on flavor — Pandoc-flavored or GFM-specific coverage belongs in
  golden cases under `tests/fixtures/cases/`, not here.
- The renderer at `crates/panache-parser/tests/commonmark/html_renderer.rs`
  is test-only. Do not promote it to a public API as part of this work.

## Related rules to read first

These project rules apply directly to this skill's work; read them before
starting if you haven't already loaded them this session:

- `.claude/rules/commonmark.md` — conformance-harness invariants
  (byte-equal HTML, allowlist discipline, paired-fixture pattern,
  passing-by-accident exception).
- `.claude/rules/parser.md` — `Dialect` vs `Extensions` split, dialect
  pandoc-verification requirement, CST losslessness, parser-policy
  separation from formatter.
- `.claude/rules/integration-tests.md` — formatter golden cases live
  under top-level `tests/fixtures/cases/` and are wired in
  `tests/golden_cases.rs`; parser-only cases live under
  `crates/panache-parser/tests/fixtures/cases/` and wire into
  `crates/panache-parser/tests/golden_parser_cases.rs`. Do not mix them.

## Harness noise to ignore inside this skill

The runtime occasionally injects a `system-reminder` nudging you to use
`TaskCreate` / `TaskUpdate` for tracking. **Inside this skill, the
workflow below is already linear (probe → classify → fix → fixture →
allowlist → recap), so task tools add overhead without value.** Skip
them for conformance sessions unless the user explicitly asks for a
task list.

## Key files

- `crates/panache-parser/tests/commonmark.rs` — runner. Two real tests:
  - `commonmark_allowlist` — regression guard against
    `tests/commonmark/allowlist.txt`.
  - `commonmark_full_report` (`#[ignore]`) — runs all 652 examples,
    writes `tests/commonmark/report.txt` and
    `docs/development/commonmark-report.json`.
- `crates/panache-parser/tests/commonmark/spec_parser.rs` — parses
  `spec.txt` into `SpecExample { number, section, markdown, expected_html }`.
  Rarely needs changes.
- `crates/panache-parser/tests/commonmark/html_renderer.rs` — test-only
  CST → HTML walker. Many divergences live here, not in the parser.
- `crates/panache-parser/tests/commonmark/allowlist.txt` — example numbers
  that must keep passing. Grouped by section header comments. Append-only
  in spirit; only remove an entry if you have a concrete reason and a
  follow-up plan.
- `crates/panache-parser/tests/commonmark/blocked.txt` — example numbers we
  intentionally do not target yet, with reasons. Not used to silence
  regressions.
- `crates/panache-parser/tests/fixtures/commonmark-spec/spec.txt` — vendored
  CommonMark spec. Do not edit directly; refresh via
  `scripts/update-commonmark-spec-fixtures.sh`.
- `crates/panache-parser/src/options.rs` — `Extensions::for_flavor()` is
  where flavor → extension defaults are resolved. Tightening the
  CommonMark flavor gate often happens here.
- `crates/panache-parser/src/parser/blocks/**`,
  `crates/panache-parser/src/parser/inlines/**` — where parser fixes land
  when the CST shape is wrong.

## Failure buckets

Every failing example is one of:

- **Renderer gap** — parser produces a sensible CST, but the test renderer
  doesn't emit the right HTML for it. Fix in `html_renderer.rs`.
- **Parser-shape gap** — parser CST shape doesn't match what the renderer
  needs (e.g. tokenization quirks, missing nested structure). Fix in
  `crates/panache-parser/src/parser/`.
- **Flavor leak** — a Pandoc-only behavior is firing under
  `Flavor::CommonMark` because an extension gate is missing or wrong.
  Fix by adding/tightening the gate in `parser/blocks/**` or
  `parser/inlines/**`, and verify `Extensions::for_flavor(CommonMark)`
  has the right defaults.
- **Dialect divergence** — the construct *parses differently* between
  Pandoc-markdown and CommonMark (not a single feature toggle, but a
  structural rule difference). Fix by branching on
  `config.dialect == Dialect::CommonMark` in the parser. Examples: backtick
  run matching, emphasis flanking edge cases, raw HTML recognition.
- **Genuine missing feature** — CommonMark construct not currently
  modeled. Less common; usually the largest fix.

### How to tell flavor leak from dialect divergence

A flavor leak means *Pandoc-flavored markdown* would also produce the
"wrong" output if the relevant extension were off. A dialect divergence
means even a fully-extensions-on Pandoc-markdown parse disagrees with
CommonMark on the construct.

Before classifying, verify with pandoc itself (assume it's available):

```
printf '<markdown>' > /tmp/probe.md
pandoc /tmp/probe.md -f commonmark -t native
pandoc /tmp/probe.md -f markdown   -t native
pandoc /tmp/probe.md -f gfm        -t native       # if GFM-relevant
```

- Outputs *agree* → not a flavor or dialect issue; it's a renderer or
  parser-shape gap that affects every flavor.
- Outputs *differ between commonmark/gfm and markdown* → **dialect
  divergence**. Gate on `Dialect`.
- Output for `markdown` matches CommonMark only when an extension is
  toggled → **flavor leak**, fix the extension default in
  `Extensions::for_flavor(...)`.

Reference for which extensions Pandoc itself ships under each flavor:
`pandoc/src/Text/Pandoc/Extensions.hs` (read-only checkout in the
workspace root). When designing a new `Extensions` flag default, check
that file for `getDefaultExtensions Markdown / CommonMark / GFM` to keep
panache aligned.

## Session recap (`RECAP.md`)

This skill keeps a rolling recap at
`.claude/skills/commonmark-conformance-expand/RECAP.md`. It is the handoff
between sessions — short, judgment-call-only, not a duplicate of
`report.txt`.

- **At the start of a session**: read `RECAP.md` first. The "Suggested next
  targets" section is the recommended starting point, and the "Don't redo"
  list keeps you from reinventing fixes that already landed. If the user
  named a specific target, prefer that, but still skim the recap so you
  don't redo prior work.
- **At the end of a session**: rewrite the **Latest session** entry in
  `RECAP.md` with: pass count before → after, the targets and shared root
  causes, files changed (classified by bucket), what *not* to redo, and
  ranked next targets. Keep it terse — a fresh session should be able to
  pick up from this entry plus `report.txt` without scrolling the prior
  conversation.
- Treat `RECAP.md` as the canonical handoff. Only echo a recap into the
  conversation if the user asks for one explicitly.

## Workflow

1. **Regenerate the report**:
   ```
   cargo test -p panache-parser --test commonmark commonmark_full_report \
     -- --ignored --nocapture
   ```
   Then look at `crates/panache-parser/tests/commonmark/report.txt` for
   per-section counts.

2. **Pick a section** — prefer high leverage, low risk:
   - Sections with many failures and a likely shared root cause
     (e.g. "Code spans 0/22" — backtick handling probably explains all of
     them) beat picking off one-offs.
   - Sections where the failures are spread across unrelated bugs are
     poor first targets.

3. **Probe one example.** Read the markdown and expected HTML for the
   smallest failing example in the section directly from
   `crates/panache-parser/tests/fixtures/commonmark-spec/spec.txt`. Then
   inspect what panache produces:
   ```
   printf '<markdown here>' | cargo run -- parse        # CST
   ```

   For triage across several failing example numbers at once, the
   load-bearing tool is a throwaway `#[ignore]`-d `probe_examples` test
   inside `commonmark.rs`. It prints markdown / expected HTML / actual
   rendered HTML / match-status side-by-side so you can classify the
   failure bucket in seconds. Drop it in temporarily, edit the example
   numbers as you triage, then **delete it before finishing** — it is
   not a permanent fixture. Template:

   ```rust
   #[test]
   #[ignore = "probe specific examples"]
   fn probe_examples() {
       let examples = read_spec(&manifest_path(SPEC_FIXTURE_REL));
       let by_number: std::collections::HashMap<u32, &SpecExample> =
           examples.iter().map(|e| (e.number, e)).collect();
       for n in [/* failing example numbers */] {
           let example = by_number[&n];
           let rendered = render_example(example);
           eprintln!("=== #{n} ({}) ===", example.section);
           eprintln!("MD: {:?}", example.markdown);
           eprintln!("EXPECTED:\n{}", example.expected_html);
           eprintln!("GOT:\n{}", rendered);
           eprintln!("MATCH: {}", matches_expected(example, &rendered));
       }
   }
   ```

   Run with `cargo test -p panache-parser --test commonmark
   probe_examples -- --ignored --nocapture`.

4. **Classify the fix** before editing — and **verify with pandoc** when
   the construct could plausibly differ between dialects:
   ```
   pandoc <case>.md -f commonmark -t native
   pandoc <case>.md -f markdown   -t native
   ```
   If the two disagree, the change is a dialect divergence, not a free
   parser fix. Then:
   - **Renderer gap**: edit `html_renderer.rs`. Keep changes narrow to the
     constructs the failing examples actually exercise.
   - **Parser-shape gap**: add a focused parser regression test under
     `crates/panache-parser/tests/fixtures/cases/<descriptive-name>/`
     (parser golden) that pins the desired CST shape, then make it pass.
     The conformance harness is *not* where parser invariants are
     authored. **Fixture-first is non-negotiable** — land the fixture
     before the allowlist grows. The allowlist guards regressions; it is
     not where new parsing behavior is asserted in detail.
   - **Renderer-only gap**: a pure renderer fix (e.g. emitting `<br />`,
     trimming heading whitespace) does not need a parser fixture if the
     CST shape it consumes is already pinned by an existing parser
     golden. If the renderer fix is leaning on a CST shape that has no
     parser golden yet, add one before allowlisting — otherwise the
     "invariant" lives only in `html_renderer.rs` and rots silently.
   - **Flavor leak**: confirm by checking the flag in
     `Extensions::for_flavor(Flavor::CommonMark)`. Tighten the gate at
     the parser site that consults the flag.
   - **Dialect divergence**: gate the parser branch on
     `config.dialect == Dialect::CommonMark` (see
     `crates/panache-parser/src/options.rs`). Add **paired parser
     fixtures** — one with `parser-options.toml` set to
     `flavor = "commonmark"`, one set to `flavor = "pandoc"` — both
     pinning the dialect-specific CST shape. Pattern reference:
     `code_spans_unmatched_backtick_run_{commonmark,pandoc}`.
   - **Missing feature**: scope it carefully; if it's large, file it as
     follow-up rather than landing it in a conformance session.

   **Formatter golden case (when needed)** — if the parser change produces
   a *new structural shape* under CommonMark (e.g. paragraph + thematic
   break + paragraph where there was previously a single paragraph), also
   add one formatter golden case under `tests/fixtures/cases/` (top-level,
   not the parser-crate one) with `panache.toml` setting
   `flavor = "commonmark"`. The formatter fixture pins the formatted
   output and exercises idempotency, which is how non-obvious round-trip
   bugs surface (the formatter's HR style colliding with setext underlines
   is the canonical example). **Skip the paired Pandoc formatter case** —
   the existing top-level fixture suite already covers Pandoc-default
   behavior, and adding duplicates is churn. Only add a CommonMark
   formatter case when the new CommonMark behavior produces a different
   block sequence than the Pandoc path; if both dialects format
   identically, the parser fixture alone is sufficient.

   Reference: `tests/fixtures/cases/thematic_break_interrupts_paragraph_commonmark/`.

   Note on `panache.toml` flavor strings: the formatter config uses serde's
   kebab-case rename. `Flavor::CommonMark` accepts both `"commonmark"` and
   `"common-mark"` (alias). Other variants follow kebab-case strictly
   (`"rmarkdown"`, `"multimarkdown"`, `"gfm"`, `"pandoc"`, `"quarto"`).

5. **Apply the smallest focused change**, keeping the parser
   CST-lossless and parser/formatter policy separate (per
   `.claude/rules/parser.md`).

6. **Regenerate the report** and inspect which examples flipped to
   passing. A single root-cause fix often unlocks several.

7. **Allowlist the cleanly unlocked examples** in
   `tests/commonmark/allowlist.txt`. Group new entries under their
   section header comment. Do not allowlist examples whose pass status
   is fragile or dependent on side behavior — only crisp wins.

   Before adding any number, **verify it against the just-regenerated
   `report.txt`** so a stale memory of "this was passing" can't drift
   into the allowlist. Quick check:
   ```
   grep -E '^(N1|N2|N3)$' \
     crates/panache-parser/tests/commonmark/report.txt
   ```
   Each number must appear (twice — once in the flat passing list, once
   in its section block). If a number doesn't show up there, the
   allowlist guard would later flip red as a regression for the wrong
   reason; do not add it.

8. **Validate**:
   - `cargo test -p panache-parser --test commonmark commonmark_allowlist`
   - `cargo test -p panache-parser` (full parser-crate suite — catches
     parser regressions in goldens, snapshot, etc.)
   - `cargo clippy -p panache-parser --all-targets -- -D warnings`
   - `cargo fmt -p panache-parser -- --check`
   - Re-run `commonmark_full_report` so `report.txt` and
     `docs/development/commonmark-report.json` reflect the new state.

## Dos and don'ts

- **Do** prefer fixes that unlock multiple examples sharing a root cause.
- **Do** add a focused parser regression test before changing parser
  behavior.
- **Do** keep allowlist additions grouped under their CommonMark section
  header for readability.
- **Don't** add an example to the allowlist without verifying it appears
  in the latest `report.txt` passing set.
- **Don't** broaden the renderer to handle Pandoc-flavored constructs;
  this harness is `Flavor::CommonMark` only.
- **Don't** silence a regression by removing an allowlist entry — fix the
  underlying cause, or open a follow-up and document the gap in
  `blocked.txt`. **Exception — passing-by-accident**: when a flavor-leak
  or extension-default fix turns on a construct that was previously
  disabled, examples that were "passing" only because the parser fell
  through to plain-text may now fail with a *more correct* output that
  no longer matches the spec. These are not regressions in the
  invariant-breaking sense; the prior pass was an artifact. They belong
  in `blocked.txt` with a comment explicitly labeling them
  "passing-by-accident under prior defaults" plus the concrete parser
  gap they expose. Removing them from the allowlist requires that label
  and a follow-up plan; do not use this exception for genuine regressions
  caused by parser/renderer changes.
- **Don't** edit `report.txt` or `docs/development/commonmark-report.json`
  by hand. They are derived.
- **Don't** bump `spec.txt` to a new spec version as a side effect of a
  conformance session — that's its own intentional change.

## Report-back format

When done, report:

1. Pass count before and after (e.g. "66 → 81 / 652").
2. The section(s) targeted and the shared root cause behind the wins.
3. Files changed, classified by bucket (renderer / parser-shape / flavor
   leak / missing feature).
4. Examples unlocked but not yet allowlisted (candidates for follow-up,
   with the reason they were left off).
5. Suggested next targets grouped by likely shared root cause.
