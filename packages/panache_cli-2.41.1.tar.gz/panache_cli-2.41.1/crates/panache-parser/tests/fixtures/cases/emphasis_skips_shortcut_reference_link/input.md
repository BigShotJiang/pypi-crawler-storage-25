[foo*]: /url

*[foo*]
