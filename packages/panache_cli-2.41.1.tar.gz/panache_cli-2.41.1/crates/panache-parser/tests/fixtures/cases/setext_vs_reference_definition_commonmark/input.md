[foo]: /url
===
[foo]
