>>> foo
> bar
>>baz
