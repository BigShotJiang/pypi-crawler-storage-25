[foo [bar](/uri)](/uri)
