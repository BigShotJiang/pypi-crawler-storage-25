[foo]:
/url

[foo]
