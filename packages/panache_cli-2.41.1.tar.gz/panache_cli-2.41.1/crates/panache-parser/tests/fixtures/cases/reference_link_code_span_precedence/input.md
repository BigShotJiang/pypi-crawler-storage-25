[foo`][ref]`

[ref]: /uri
