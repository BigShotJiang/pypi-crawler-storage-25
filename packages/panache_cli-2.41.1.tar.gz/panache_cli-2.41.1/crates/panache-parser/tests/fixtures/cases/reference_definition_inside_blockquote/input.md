[foo]

> [foo]: /url
