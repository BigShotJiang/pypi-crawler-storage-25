****foo*

____foo_
