[
foo
]: /url
bar
