::: {#tbl:panel layout.nrow="1"}
  : My Caption {#tbl:foo-1}

  | Col1 | Col2 | Col3 |
  | ---- | ---- | ---- |
  | A    | B    | C    |
  | E    | F    | G    |
  | A    | G    | G    |

  : My Caption2 {#tbl:foo-2}

  | Col1 | Col2 | Col3 |
  | ---- | ---- | ---- |
  | A    | B    | C    |
  | E    | F    | G    |
  | A    | G    | G    |

Caption
:::
