[link](<foo(and(bar)>)
