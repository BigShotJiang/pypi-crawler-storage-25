Foo
[bar]: /baz

[bar]
