A simple bullet list:

* First item
* Second item with a longer line that might need wrapping if it gets too long
* Third item

Another list with different marker:

- Item one
- Item two

-   A function has a name, it takes a number of arguments (possibly zero), 
and when called it evaluates its body and returns a value.
-   The function returns the value of the last expression in the body except 
when the body contains an explicit return statement.
-   Formal arguments can be given default values when the function is 
implemented, and arguments can be passed to the function by position as well 
as by name.
-   Functions should do a single well defined computation and be well tested.

A list needs a blankline before. This is not a list:
- One
- Two

This is one list:

1.  one
2.  two

1.  uno
2.  dos

If you need to have two consecutive lists,
you can separate them with a comment:

1.  one
2.  two

<!-- -->

1.  uno
2.  dos

+	this is a list item
	indented with tabs

+   this is a list item
    indented with spaces

	+	this is an example list item
		indented with tabs
	
	+   this is an example list item
	    indented with spaces
