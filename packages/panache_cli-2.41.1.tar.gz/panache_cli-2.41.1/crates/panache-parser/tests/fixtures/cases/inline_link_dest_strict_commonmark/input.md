[link](/my uri)
