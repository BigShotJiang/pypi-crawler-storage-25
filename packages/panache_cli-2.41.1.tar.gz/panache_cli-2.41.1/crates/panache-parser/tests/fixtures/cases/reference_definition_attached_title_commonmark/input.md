[foo]: <bar>(baz)

[foo]
