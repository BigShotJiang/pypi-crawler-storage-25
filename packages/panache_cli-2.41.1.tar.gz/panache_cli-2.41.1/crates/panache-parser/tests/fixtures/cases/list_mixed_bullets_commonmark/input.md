- foo
- bar
+ baz
