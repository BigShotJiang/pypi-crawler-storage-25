this is ~~struck~~ out
