use `printf("hi")` here
