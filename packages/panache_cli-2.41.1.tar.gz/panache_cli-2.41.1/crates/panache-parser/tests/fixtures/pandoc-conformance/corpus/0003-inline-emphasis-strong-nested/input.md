***both*** styles
