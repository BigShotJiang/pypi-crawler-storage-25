from django.contrib import messages
from django.core.exceptions import BadRequest, PermissionDenied
from django.shortcuts import render


def error_400(request):
    raise BadRequest("Bad request: invalid data.")


def error_403(request):
    raise PermissionDenied("You are not allowed to access this.")


def error_500(request):
    raise Exception("This is a 500 error")


def message_warning(request):
    messages.warning(
        request,
        "Operation completed successfully.",
        extra_tags="update",
    )
    return render(request, "base.html")
