#include "object_types.h"

GameObject::GameObject(float x, float y, float w, float h, ObjectType t, int id) 
    : x(x), y(y), width(w), height(h), vel_x(0), vel_y(0), type(t), id(id) {}

void GameObject::set_position(float nx, float ny) {
    x = nx;
    y = ny;
}

void GameObject::set_velocity(float vx, float vy) {
    vel_x = vx;
    vel_y = vy;
}

bool GameObject::is_player() const { return type == PLAYER; }
bool GameObject::is_item() const { return type == ITEM; }
bool GameObject::is_gui() const { return type == GUI; }
bool GameObject::is_object() const { return type == OBJECT; }

bool GameObject::check_collision(float ox, float oy, float ow, float oh) const {
    return x < ox + ow && x + width > ox && y < oy + oh && y + height > oy;
}
