#include "physics.h"

PhysicsEngine::PhysicsEngine() : gravity(9.8f) {}

void PhysicsEngine::apply_gravity(GameObject* obj, float delta_time) {
    obj->vel_y += gravity * delta_time;
}

void PhysicsEngine::apply_velocity(GameObject* obj, float delta_time) {
    obj->x += obj->vel_x * delta_time;
    obj->y += obj->vel_y * delta_time;
}

void PhysicsEngine::apply_custom_force(GameObject* obj, float fx, float fy) {
    obj->vel_x += fx;
    obj->vel_y += fy;
}

bool PhysicsEngine::check_boundary(GameObject* obj, float world_width, float world_height) {
    return obj->x >= 0 && obj->y >= 0 && 
           obj->x + obj->width <= world_width && 
           obj->y + obj->height <= world_height;
}

GameObject* PhysicsEngine::check_collision_with(GameObject* obj, const std::vector<GameObject*>& objects) {
    for (auto* other : objects) {
        if (other != obj && obj->check_collision(other->x, other->y, other->width, other->height)) {
            return other;
        }
    }
    return nullptr;
}
