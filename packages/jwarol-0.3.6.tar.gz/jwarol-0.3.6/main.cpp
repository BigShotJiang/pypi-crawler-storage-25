#include <windows.h>
#include <GL/gl.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <vector>
#include <string>
#include "object_types.h"
#include "physics.h"
#include "texture.h"

namespace py = pybind11;

class Engine {
    HWND hwnd;
    HDC hdc;
    HGLRC hrc;
    bool running;
    PhysicsEngine physics;
    TextureManager tex_manager;
    std::vector<GameObject*> objects;
    int next_id;

public:
    Engine() : hwnd(NULL), hdc(NULL), hrc(NULL), running(false), next_id(0) {}

    bool init(int width, int height, std::string title) {
        HINSTANCE hInstance = GetModuleHandle(NULL);
        WNDCLASS wc = {};
        wc.lpfnWndProc = DefWindowProc;
        wc.hInstance = hInstance;
        wc.lpszClassName = "JwarolEngine";
        wc.hCursor = LoadCursor(NULL, IDC_ARROW);
        RegisterClass(&wc);

        hwnd = CreateWindowEx(0, wc.lpszClassName, title.c_str(),
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, width, height,
            NULL, NULL, hInstance, NULL);

        if (!hwnd) return false;

        hdc = GetDC(hwnd);
        PIXELFORMATDESCRIPTOR pfd = { sizeof(PIXELFORMATDESCRIPTOR), 1 };
        pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
        pfd.iPixelType = PFD_TYPE_RGBA;
        pfd.cColorBits = 32;
        int format = ChoosePixelFormat(hdc, &pfd);
        SetPixelFormat(hdc, format, &pfd);
        hrc = wglCreateContext(hdc);
        wglMakeCurrent(hdc, hrc);
        running = true;
        glOrtho(0, width, height, 0, -1, 1);
        return true;
    }

    int create_object(float x, float y, float w, float h, int type) {
        GameObject* obj = new GameObject(x, y, w, h, (ObjectType)type, next_id);
        objects.push_back(obj);
        return next_id++;
    }

    void set_position(int id, float x, float y) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                obj->set_position(x, y);
                return;
            }
        }
    }

    void set_velocity(int id, float vx, float vy) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                obj->set_velocity(vx, vy);
                return;
            }
        }
    }

    void apply_gravity(int id, float delta_time) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                physics.apply_gravity(obj, delta_time);
                return;
            }
        }
    }

    void apply_velocity(int id, float delta_time) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                physics.apply_velocity(obj, delta_time);
                return;
            }
        }
    }

    void apply_force(int id, float fx, float fy) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                physics.apply_custom_force(obj, fx, fy);
                return;
            }
        }
    }

    bool is_key_pressed(int key_code) {
        return (GetAsyncKeyState(key_code) & 0x8000) != 0;
    }

    void move_object(int id, float dx, float dy, float speed) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                obj->set_velocity(dx * speed, dy * speed);
                return;
            }
        }
    }

    bool is_object(int id, int type) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                return (int)obj->type == type;
            }
        }
        return false;
    }

    bool check_collision(int id1, int id2) {
        GameObject* obj1 = nullptr;
        GameObject* obj2 = nullptr;
        for (auto* obj : objects) {
            if (obj->id == id1) obj1 = obj;
            if (obj->id == id2) obj2 = obj;
        }
        if (obj1 && obj2) {
            return obj1->check_collision(obj2->x, obj2->y, obj2->width, obj2->height);
        }
        return false;
    }

    bool is_open() {
        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) running = false;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        if (!IsWindow(hwnd)) running = false;
        return running;
    }

    void clear(float r, float g, float b) {
        glClearColor(r, g, b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
    }

    void draw_rect(int id, float r, float g, float b) {
        for (auto* obj : objects) {
            if (obj->id == id) {
                glBegin(GL_QUADS);
                glColor3f(r, g, b);
                glVertex2f(obj->x, obj->y);
                glVertex2f(obj->x + obj->width, obj->y);
                glVertex2f(obj->x + obj->width, obj->y + obj->height);
                glVertex2f(obj->x, obj->y + obj->height);
                glEnd();
            }
        }
    }

    void update() { SwapBuffers(hdc); }

    void close() {
        for (auto* obj : objects) delete obj;
        objects.clear();
        wglMakeCurrent(NULL, NULL);
        wglDeleteContext(hrc);
        ReleaseDC(hwnd, hdc);
        DestroyWindow(hwnd);
    }
};

PYBIND11_MODULE(jwarol, m) {
    py::class_<Engine>(m, "Engine")
        .def(py::init<>())
        .def("init", &Engine::init)
        .def("create_object", &Engine::create_object)
        .def("set_position", &Engine::set_position)
        .def("set_velocity", &Engine::set_velocity)
        .def("apply_gravity", &Engine::apply_gravity)
        .def("apply_velocity", &Engine::apply_velocity)
        .def("apply_force", &Engine::apply_force)
        .def("is_key_pressed", &Engine::is_key_pressed)
        .def("move_object", &Engine::move_object)
        .def("is_object", &Engine::is_object)
        .def("check_collision", &Engine::check_collision)
        .def("is_open", &Engine::is_open)
        .def("clear", &Engine::clear)
        .def("draw_rect", &Engine::draw_rect)
        .def("update", &Engine::update)
        .def("close", &Engine::close);

    py::enum_<ObjectType>(m, "ObjectType")
        .value("OBJECT", OBJECT)
        .value("PLAYER", PLAYER)
        .value("ITEM", ITEM)
        .value("GUI", GUI)
        .export_values();
}