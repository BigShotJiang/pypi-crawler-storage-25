# Jwarol Engine

2D игровой движок для Python на C++ и pybind11. **Полностью автономный** — не нужно подключать другие библиотеки для ходьбы, физики и управления.

## Установка

```bash
pip install jwarol==0.3.5
```

## Быстрый старт

```python
import jwarol

engine = jwarol.Engine()
engine.init(800, 600, "My Game")
player = engine.create_object(100, 100, 50, 50, jwarol.ObjectType.PLAYER)

while engine.is_open():
    engine.clear(0.2, 0.2, 0.2)
    engine.draw_rect(player, 0.0, 1.0, 0.0)
    engine.update()

engine.close()
```

## API Справочник

### Типы объектов

```python
jwarol.ObjectType.OBJECT  # Обычный объект
jwarol.ObjectType.PLAYER  # Игрок
jwarol.ObjectType.ITEM    # Предмет
jwarol.ObjectType.GUI     # Интерфейс
```

### Коды клавиш (Windows)

```python
# Стрелки
jwarol.VK_LEFT     # 37
jwarol.VK_UP        # 38
jwarol.VK_RIGHT     # 39
jwarol.VK_DOWN      # 40

# WASD
jwarol.VK_W         # 87
jwarol.VK_A         # 65
jwarol.VK_S         # 83
jwarol.VK_D         # 68

# Пробел
jwarol.VK_SPACE     # 32
```

### Методы Engine

| Метод | Описание |
|--------|----------|
| `init(w, h, title)` | Создание окна |
| `create_object(x, y, w, h, type)` | Создание объекта, возврат ID |
| `set_position(id, x, y)` | Установка позиции |
| `set_velocity(id, vx, vy)` | Установка скорости |
| `apply_gravity(id, dt)` | Гравитация (увеличивает vel_y) |
| `apply_velocity(id, dt)` | Движение по vel_x/vel_y |
| `apply_force(id, fx, fy)` | Применение силы |
| **`is_key_pressed(keycode)`** | **Проверка нажатия клавиши (встроенная)** |
| **`move_object(id, dx, dy, speed)`** | **Простое движение (встроенное)** |
| `is_object(id, type)` | Проверка типа |
| `check_collision(id1, id2)` | Проверка коллизии |
| `is_open()` | Окно открыто? |
| `clear(r, g, b)` | Очистка экрана |
| `draw_rect(id, r, g, b)` | Отрисовка |
| `update()` | Обновление экрана |
| `close()` | Закрытие |

## Примеры использования

### Пример 1: Платформер (автономный, только jwarol)

```python
import jwarol
import time

engine = jwarol.Engine()
engine.init(800, 600, "Platformer - No Extra Libs")

# Объекты
player = engine.create_object(100, 300, 40, 60, jwarol.ObjectType.PLAYER)
ground = engine.create_object(0, 550, 800, 50, jwarol.ObjectType.OBJECT)
platform = engine.create_object(300, 400, 200, 20, jwarol.ObjectType.OBJECT)

gravity = 0.5
jump_force = -12
speed = 5
on_ground = False

while engine.is_open():
    engine.clear(0.4, 0.6, 1.0)  # Небо
    
    # Гравитация
    engine.apply_gravity(player, gravity)
    
    # Управление (встроенное, не нужен pygame или другие библиотеки)
    if engine.is_key_pressed(jwarol.VK_LEFT):
        engine.move_object(player, -1, 0, speed)
    if engine.is_key_pressed(jwarol.VK_RIGHT):
        engine.move_object(player, 1, 0, speed)
    if engine.is_key_pressed(jwarol.VK_SPACE) and on_ground:
        engine.set_velocity(player, 0, jump_force)
        on_ground = False
    
    # Движение
    engine.apply_velocity(player, 1.0)
    
    # Коллизии с землей
    if engine.check_collision(player, ground):
        engine.set_velocity(player, 0, 0)
        on_ground = True
    
    # Платформа
    if engine.check_collision(player, platform):
        engine.set_velocity(player, 0, 0)
    
    # Отрисовка
    engine.draw_rect(player, 0.0, 1.0, 0.0)   # Игрок
    engine.draw_rect(ground, 0.0, 0.5, 0.0)    # Земля
    engine.draw_rect(platform, 0.5, 0.3, 0.1) # Платформа
    
    engine.update()
    time.sleep(0.016)

engine.close()
```

### Пример 2: Top-down шутер (автономный)

```python
import jwarol
import time

engine = jwarol.Engine()
engine.init(800, 600, "Top-Down - No Extra Libs")

player = engine.create_object(400, 300, 40, 40, jwarol.ObjectType.PLAYER)
enemy = engine.create_object(200, 200, 40, 40, jwarol.ObjectType.OBJECT)
wall = engine.create_object(300, 250, 200, 20, jwarol.ObjectType.OBJECT)

speed = 4

while engine.is_open():
    engine.clear(0.1, 0.1, 0.1)
    
    # Управление WASD (встроенное)
    dx, dy = 0.0, 0.0
    if engine.is_key_pressed(jwarol.VK_W): dy = -1
    if engine.is_key_pressed(jwarol.VK_S): dy = 1
    if engine.is_key_pressed(jwarol.VK_A): dx = -1
    if engine.is_key_pressed(jwarol.VK_D): dx = 1
    
    engine.move_object(player, dx, dy, speed)
    engine.apply_velocity(player, 1.0)
    
    # Коллизии
    if engine.check_collision(player, wall):
        print("Hit wall!")
    if engine.check_collision(player, enemy):
        print("Hit enemy!")
    
    # Отрисовка
    engine.draw_rect(player, 0.0, 1.0, 0.0)
    engine.draw_rect(enemy, 1.0, 0.0, 0.0)
    engine.draw_rect(wall, 0.5, 0.5, 0.5)
    
    engine.update()
    time.sleep(0.016)

engine.close()
```

### Пример 3: Свободный полет (космос)

```python
import jwarol
import time

engine = jwarol.Engine()
engine.init(800, 600, "Space Flight")

ship = engine.create_object(400, 300, 60, 30, jwarol.ObjectType.PLAYER)

while engine.is_open():
    engine.clear(0.0, 0.0, 0.1)  # Космос
    
    # Управление (без гравитации)
    if engine.is_key_pressed(jwarol.VK_UP):
        engine.apply_force(ship, 0, -0.3)
    if engine.is_key_pressed(jwarol.VK_DOWN):
        engine.apply_force(ship, 0, 0.3)
    if engine.is_key_pressed(jwarol.VK_LEFT):
        engine.apply_force(ship, -0.3, 0)
    if engine.is_key_pressed(jwarol.VK_RIGHT):
        engine.apply_force(ship, 0.3, 0)
    
    # Торможение
    engine.apply_force(ship, -0.05, -0.05)
    
    # Движение
    engine.apply_velocity(ship, 1.0)
    
    engine.draw_rect(ship, 0.0, 1.0, 1.0)
    engine.update()
    time.sleep(0.016)

engine.close()
```

## Философия движка

**Полностью автономный:**
- ✅ Не нужен pygame для клавиш
- ✅ Не нужны дополнительные библиотеки для движения
- ✅ Встроенная проверка нажатий `is_key_pressed()`
- ✅ Простое движение `move_object()`

**Инструменты, а не правила:**
- Гравитация есть? Применяй когда нужно
- Нужен платформер? Используй гравитацию + прыжки
- Нужен вид сверху? Не используй гравитацию
- Нужен космос? Создавай свои силы

## Планы развития

- [ ] `get_position(id)` — получение координат
- [ ] `load_texture(id, path)` — загрузка текстур
- [ ] `draw_texture(id, tex_id)` — отрисовка с текстурой
- [ ] Камера (следование за игроком)
- [ ] Звук
- [ ] Анимации
- [ ] Tilemap

## Лицензия

MIT License — см. [LICENSE](LICENSE)

## Автор

**ruslan**

## Ссылки

- PyPI: https://pypi.org/project/jwarol/0.3.5/
- Issues: https://github.com/ruslan/jwarol/issues
