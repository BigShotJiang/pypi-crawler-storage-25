from setuptools import setup
from pybind11.setup_helpers import Pybind11Extension, build_ext

ext_modules = [
    Pybind11Extension(
        "jwarol",
        ["main.cpp", "object_types.cpp", "physics.cpp", "texture.cpp"],
        libraries=["user32", "gdi32", "opengl32"],
    ),
]

setup(
    name="jwarol",
    version="0.3.6",
    author="ruslan",
    author_email="ruslan@example.com",
    description="2D game engine for Python with physics, collision detection, and texture support",
    long_description="A 2D game engine built with C++ and pybind11, featuring object type system, physics engine, and OpenGL rendering",
    long_description_content_type="text/markdown",
    url="https://github.com/ruslan/jwarol",
    license="MIT",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)