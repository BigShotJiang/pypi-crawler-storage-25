#include "texture.h"
#include <windows.h>
#include <GL/gl.h>

Texture::Texture() : id(0), width(0), height(0) {}

bool Texture::load(const std::string& path) {
    return true;
}

void Texture::bind() {}
void Texture::unbind() {}

Texture* TextureManager::load_texture(const std::string& path) {
    Texture* tex = new Texture();
    tex->load(path);
    return tex;
}

void TextureManager::cleanup() {}
