# src/SVALint/__main__.py

def main():
    print("SVALint running...")
    # Here you can call your existing CLI parser
    import argparse
    from .asfigo_linter import AsFigoLinter  # example

    parser = argparse.ArgumentParser(description="SVALint CLI")
    parser.add_argument("-t", "--test", required=True, help="Test file")
    args = parser.parse_args()

    run_linter(args.test)


if __name__ == "__main__":
    main()
