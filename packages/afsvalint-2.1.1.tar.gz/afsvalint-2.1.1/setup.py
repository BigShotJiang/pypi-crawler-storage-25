from setuptools import setup, find_packages

setup(
    name="afsvalint",
    version="2.1.1",
    description="SystemVerilog Assertion Linter",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    url="https://github.com/AsFigo/SVALint",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.8",
    install_requires=[
        "anytree",
        "tomli",
        "python-string-utils"
    ],
    entry_points={
        "console_scripts": [
            "svalint = SVALint.__main__:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
