# 🧡 Amber - 人格工坊

[![Version](https://img.shields.io/badge/Version-0.1.0-green.svg)]()
[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/License-GPL3.0-green.svg)](LICENSE)

**让任何人都能用自然语言创造有灵魂、会记忆、能理解、有底线的数字人格。**

## ✨ 特性

- 🎭 **三种创建模式** - 智能模式/AI脑补/专家问卷
- 🧠 **有情绪** - 会开心、会难过、会记仇、会原谅
- 📝 **会记忆** - 记住你说过的话，形成态度
- 🛡️ **有底线** - 话题边界，不可逾越
- 🤝 **开源协作** - Fork、改进、PR，像GitHub一样
- 🔒 **隐私保护** - 参数层与记忆层分离

### 提示：人格市场仅为示例，无明显实际功能，仅支持局域网。

## 🚀 快速开始

```bash
# 安装
#注意是 pyamber, 不是amber
pip install pyamber

# 创建人格（智能模式）
amber create "傲娇的高中生，嘴硬心软"

# 运行对话
amber run 浅浅

# 创建面试官（服务型人格）
amber create "技术面试官" --type service

# 快速模式（AI直接脑补）
amber create "温柔咖啡师" --quick
```

## 📖 文档

| 文档 | 说明 |
|------|------|
| [安装指南](docs/installation.md) | 安装和配置 |
| [快速开始](docs/quickstart.md) | 5分钟上手 |
| [CLI命令](docs/commands.md) | 完整命令参考 |
| [人格创建](docs/creation.md) | 三种创建模式详解 |
| [对话交互](docs/conversation.md) | 如何与人格对话 |
| [记忆系统](docs/memory.md) | 记忆的工作原理 |
| [情绪系统](docs/emotion.md) | 情绪变化机制 |
| [边界系统](docs/boundaries.md) | 话题边界控制 |
| [Fork协作](docs/fork.md) | 像GitHub一样协作 |
| [版权保护](docs/security.md) | 签名、水印、防盗版 |
| [Web界面](docs/web.md) | 图形化问卷 |
| [API参考](docs/api.md) | 编程接口 |
| [示例代码](docs/examples.md) | 代码示例 |
| [常见问题](docs/faq.md) | FAQ |
| [更新日志](docs/changelog.md) | 查看完整 [更新日志] |

## 🎯 三种创建模式

| 模式 | 命令 | 说明 |
|------|------|------|
| 智能模式 | `amber create "描述"` | 基础问卷 + AI问题 + 自定义 |
| 快速模式 | `amber create "描述" --quick` | AI直接脑补，无问卷 |
| 专家模式 | `amber create --expert` | 25题基础问卷 |

## 💬 示例对话

```bash
$ amber run 林夏

你: 你好
林夏: 嗯。想喝什么？

你: 推荐一下
林夏: 今天有耶加雪菲。酸的，不苦。

你: 你真温柔
林夏: [沉默 2秒]
林夏: ...
```

## 🔧 配置LLM（推荐）

```bash
# Windows PowerShell
$env:AMBER_LLM_PROVIDER="deepseek"
$env:AMBER_LLM_API_KEY="your-api-key"

# Linux/Mac
export AMBER_LLM_PROVIDER="deepseek"
export AMBER_LLM_API_KEY="your-api-key"
```

## 📦 依赖

- Python 3.10+
- click>=8.0.0
- numpy>=1.24.0
- pyyaml>=6.0
- cryptography>=41.0.0

## 📄 许可证

GPL-3.0

## 👤 作者

GraceFox - 948743980@qq.com
## 🙏 致谢

感谢以下工具和服务：

- [DeepSeek](https://deepseek.com/) - 提供代码补全、文档撰写和技术支持