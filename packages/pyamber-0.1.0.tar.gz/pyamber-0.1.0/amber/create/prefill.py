"""
AI关键词提取和问卷预填
"""

from typing import Dict, List, Any
import re


class PrefillEngine:
    """预填引擎"""
    
    def __init__(self):
        self._init_patterns()
    
    def _init_patterns(self):
        """初始化匹配模式"""
        self.patterns = {
            # 年龄模式
            "age": {
                r"(\d+)[岁|年]": lambda m: self._map_age(int(m.group(1))),
                r"少年": "18-22",
                r"青年": "23-27",
                r"中年": "36-45",
            },
            # 角色模式
            "role": {
                r"咖啡|店主|服务员|店员": "服务人员",
                r"老师|教师|教授": "白领",
                r"学生|同学": "学生",
                r"画家|音乐|艺术": "艺术家",
                r"面试|HR|招聘": "其他",
            },
            # 性格模式
            "social": {
                r"外向|开朗|活泼|热情": "外向",
                r"内向|安静|沉默|寡言": "内向",
                r"社恐|极度内向": "极度内向",
            },
            "emotion_express": {
                r"外放|直接|豪爽": "外放",
                r"内敛|含蓄|温柔": "内敛",
                r"高冷|冷漠|冷淡": "压抑",
            },
            "empathy": {
                r"温柔|体贴|善解人意|共情": "较强",
                r"冷漠|无情|冷酷": "较弱",
            },
            "talk_volume": {
                r"话痨|话多|啰嗦": "话多",
                r"沉默|话少|寡言": "话少",
            },
        }
    
    def _map_age(self, age: int) -> str:
        """映射年龄到年龄段"""
        if age < 18:
            return "18-22"
        elif age < 23:
            return "18-22"
        elif age < 28:
            return "23-27"
        elif age < 36:
            return "28-35"
        elif age < 46:
            return "36-45"
        else:
            return "45+"
    
    def prefill(self, description: str) -> Dict[str, str]:
        """
        根据描述预填问卷
        
        Args:
            description: 用户描述
            
        Returns:
            预填的答案字典
        """
        results = {}
        
        for field, patterns in self.patterns.items():
            for pattern, value in patterns.items():
                if isinstance(value, str):
                    if re.search(pattern, description, re.IGNORECASE):
                        results[field] = value
                        break
                elif callable(value):
                    match = re.search(pattern, description, re.IGNORECASE)
                    if match:
                        results[field] = value(match)
                        break
        
        return results
    
    def extract_traits(self, description: str) -> List[str]:
        """提取人格特质"""
        traits = []
        
        trait_keywords = {
            "温柔": "gentle",
            "活泼": "lively", 
            "傲娇": "tsundere",
            "高冷": "cold",
            "热情": "warm",
            "专业": "professional",
            "幽默": "humorous",
            "严肃": "serious",
        }
        
        for keyword, trait in trait_keywords.items():
            if keyword in description:
                traits.append(trait)
        
        return traits


def prefill_questionnaire(description: str) -> Dict[str, str]:
    """预填问卷"""
    engine = PrefillEngine()
    return engine.prefill(description)


def extract_traits(description: str) -> List[str]:
    """提取人格特质"""
    engine = PrefillEngine()
    return engine.extract_traits(description)
