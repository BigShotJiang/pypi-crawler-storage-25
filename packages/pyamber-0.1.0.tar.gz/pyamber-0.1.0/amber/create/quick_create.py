"""
快速创建 - 纯AI推断，无需确认
"""

from typing import Dict, Any, Optional
from datetime import datetime


def quick_create(description: str, 
                 personality_type: str = "independent",
                 service_ratio: float = 0.5) -> Optional[Dict[str, Any]]:
    """
    快速创建人格 - 5秒生成
    
    Args:
        description: 用户描述
        personality_type: 人格类型
        service_ratio: 服务比例
        
    Returns:
        创建结果
    """
    print(f"⚡ 快速生成中...")
    
    # 基于描述快速生成参数
    params = generate_quick_params(description, personality_type, service_ratio)
    
    # 生成名称
    name = generate_quick_name(description)
    params["identity"]["name"] = name
    
    # 添加元数据
    params["version"] = "1.0"
    params["created_at"] = datetime.now().isoformat()
    params["metadata"] = {
        "creation_mode": "quick",
        "original_description": description
    }
    
    # 保存
    data_dir = f"./data/personas/{name}"
    os.makedirs(data_dir, exist_ok=True)
    
    from amber.formats.amber_format import save_amber
    amber_path = os.path.join(data_dir, f"{name}.amber")
    save_amber(params, amber_path)
    
    from amber.formats.memory_format import create_empty_memory, save_memory
    memory = create_empty_memory("1.0", personality_type)
    memory_path = os.path.join(data_dir, f"{name}.memory")
    save_memory(memory, memory_path)
    
    print(f"✅ 人格 '{name}' 创建成功! (快速模式)")
    
    return {"name": name, "params": params}


def generate_quick_params(description: str, 
                          personality_type: str,
                          service_ratio: float) -> Dict[str, Any]:
    """快速生成参数"""
    
    params = {
        "identity": {
            "name": "",
            "description": description,
            "age": 25,
            "gender": "neutral"
        },
        "personality_type": {
            "type": personality_type,
            "service_ratio": service_ratio if personality_type == "mixed" else (0.0 if personality_type == "independent" else 1.0)
        },
        "stats": {
            "int": 1.0,
            "eq": 1.0,
            "con": 1.0
        },
        "emotion": {
            "base": {"pleasure": 0.3, "activation": 0.5, "trust": 0.4},
            "sensitivity": {"pleasure": 1.0, "trust": 1.0}
        },
        "speech": {
            "style": "normal",
            "min_length": 10,
            "max_length": 90,
            "temperature": 0.7
        },
        "boundaries": {
            "reject_when": ["被连续否定3次"],
            "silence_when": ["被凶", "被问隐私"],
            "topic_blacklist": ["医疗建议", "法律咨询"]
        }
    }
    
    # 根据描述调整参数
    if "温柔" in description:
        params["stats"]["eq"] = 1.2
        params["emotion"]["base"]["pleasure"] = 0.4
        params["speech"]["temperature"] = 0.6
    
    if "傲娇" in description:
        params["stats"]["eq"] = 0.8
        params["emotion"]["base"]["pleasure"] = 0.2
        params["speech"]["style"] = "tsundere"
        params["boundaries"]["silence_when"].append("被夸")
    
    if "面试" in description:
        params["stats"]["int"] = 1.3
        params["stats"]["eq"] = 0.8
        params["speech"]["style"] = "professional"
        params["speech"]["temperature"] = 0.6
        params["boundaries"]["topic_blacklist"] = ["闲聊", "天气"]
    
    if "英语" in description or "老师" in description:
        params["stats"]["int"] = 1.2
        params["stats"]["eq"] = 1.1
        params["speech"]["style"] = "patient"
        params["speech"]["temperature"] = 0.65
    
    return params


def generate_quick_name(description: str) -> str:
    """快速生成名称"""
    name_map = {
        "咖啡": "林夏",
        "温柔": "小暖", 
        "面试": "张老师",
        "英语": "Ms. Wang",
        "老师": "王老师",
        "傲娇": "浅浅",
        "助手": "小助",
        "客服": "客服小安",
    }
    
    for keyword, name in name_map.items():
        if keyword in description:
            return name
    
    return "新人格"


import os
