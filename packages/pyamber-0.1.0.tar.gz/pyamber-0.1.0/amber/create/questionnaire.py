"""
25题基础问卷 + 动态问题支持
"""

import json
from pathlib import Path
from typing import Dict, List, Any, Optional


class DynamicQuestion:
    """动态问题（AI生成或用户自定义）"""
    
    def __init__(self, id: str, text: str, qtype: str = "string",
                 options: List[str] = None, default: str = ""):
        self.id = id
        self.text = text
        self.qtype = qtype
        self.options = options or []
        self.default = default
    
    def ask(self) -> str:
        """提问并获取答案"""
        print(f"\n{self.text}")
        if self.options:
            for i, opt in enumerate(self.options, 1):
                print(f"  {i}. {opt}")
        
        if self.default:
            print(f"  (默认: {self.default})")
        
        while True:
            try:
                answer = input("回答: ").strip()
                if not answer and self.default:
                    return self.default
                
                if self.options:
                    idx = int(answer) - 1
                    if 0 <= idx < len(self.options):
                        return self.options[idx]
                    print(f"请输入 1-{len(self.options)} 之间的数字")
                else:
                    return answer
            except ValueError:
                print("请输入有效值")
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "text": self.text,
            "type": self.qtype,
            "options": self.options,
            "default": self.default
        }


class Question:
    """基础问题"""
    
    def __init__(self, 
                 id: str,
                 text: str,
                 qtype: str,
                 options: Optional[List[str]] = None,
                 default: Optional[str] = None,
                 placeholder: Optional[str] = None):
        self.id = id
        self.text = text
        self.qtype = qtype
        self.options = options or []
        self.default = default
        self.placeholder = placeholder
    
    def ask(self) -> str:
        """向用户提问并获取答案"""
        print(f"\n{self.text}")
        if self.qtype == "select" and self.options:
            for i, opt in enumerate(self.options, 1):
                print(f"  {i}. {opt}")
        
        if self.default:
            print(f"  (默认: {self.default})")
        
        while True:
            try:
                choice = input("请选择: ").strip()
                if not choice and self.default:
                    return self.default
                
                if self.qtype == "select" and self.options:
                    idx = int(choice) - 1
                    if 0 <= idx < len(self.options):
                        return self.options[idx]
                    print(f"请输入 1-{len(self.options)} 之间的数字")
                else:
                    return choice
            except ValueError:
                print("请输入有效值")
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "text": self.text,
            "type": self.qtype,
            "options": self.options,
            "default": self.default
        }


class Questionnaire:
    """25题基础问卷"""
    
    def __init__(self):
        self.questions: List[Question] = []
        self._load_from_schema()
    
    def _load_from_schema(self):
        """从JSON Schema加载问卷"""
        schema = self._load_schema()
        if schema and "sections" in schema:
            for section in schema["sections"]:
                for q_data in section.get("questions", []):
                    self.questions.append(Question(
                        id=q_data.get("id", ""),
                        text=q_data.get("text", ""),
                        qtype=q_data.get("type", "select"),
                        options=q_data.get("options", []),
                        default=q_data.get("default", ""),
                        placeholder=q_data.get("placeholder", "")
                    ))
        else:
            self._load_fallback()
    
    def _load_schema(self) -> Optional[Dict]:
        """加载问卷JSON Schema"""
        schema_path = Path(__file__).parent.parent / "schemas" / "questionnaire.json"
        if schema_path.exists():
            try:
                with open(schema_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return None
    
    def _load_fallback(self):
        """降级：硬编码25题"""
        # 模块1: 基础身份
        self.questions.extend([
            Question("age", "年龄?", "select", ["18-22", "23-27", "28-35", "36-45", "45+"], "23-27"),
            Question("gender", "性别?", "select", ["男性", "女性", "中性", "其他"], "中性"),
            Question("role", "角色/职业?", "string", default="其他"),
            Question("relationship", "与用户的关系?", "select", ["朋友", "恋人", "家人", "同事", "陌生"], "朋友"),
        ])
        
        # 模块2: 核心性格
        self.questions.extend([
            Question("social", "社交倾向?", "select", ["极度外向", "外向", "中间", "内向", "极度内向"], "中间"),
            Question("emotion_express", "情绪表达?", "select", ["外放", "适中", "内敛", "压抑"], "适中"),
            Question("empathy", "共情能力?", "select", ["很强", "较强", "普通", "较弱", "很弱"], "普通"),
            Question("rationality", "理性程度?", "select", ["非常理性", "较理性", "平衡", "较感性", "非常感性"], "平衡"),
            Question("conflict", "面对冲突?", "select", ["主动解决", "被动应对", "回避", "爆发"], "被动应对"),
            Question("humor", "幽默感?", "select", ["幽默大师", "偶尔幽默", "一般", "较严肃", "非常严肃"], "一般"),
            Question("curiosity", "好奇心?", "select", ["极强", "较强", "一般", "较弱", "极弱"], "一般"),
            Question("responsibility", "责任心?", "select", ["极强", "较强", "一般", "较弱", "极弱"], "较强"),
        ])
        
        # 模块3: 情绪与记忆
        self.questions.extend([
            Question("memory_grudge", "记仇程度?", "select", ["完全不记仇", "不太记仇", "一般", "比较记仇", "非常记仇"], "一般"),
            Question("forgiveness", "原谅速度?", "select", ["很快", "较快", "一般", "较慢", "很慢"], "一般"),
            Question("recovery", "情绪恢复速度?", "select", ["很快", "较快", "一般", "较慢", "很慢"], "一般"),
            Question("promise_importance", "对承诺的重视程度?", "select", ["无所谓", "有点在意", "比较重视", "非常重视", "绝对守信"], "比较重视"),
            Question("positive_bias", "正向偏好?", "select", ["极度乐观", "乐观", "中性", "悲观", "极度悲观"], "中性"),
        ])
        
        # 模块4: 边界与底线
        self.questions.extend([
            Question("openness", "话题开放度?", "select", ["非常开放", "开放", "一般", "保守", "非常保守"], "一般"),
            Question("privacy", "隐私保护意识?", "select", ["无所谓", "不太在意", "一般", "比较在意", "非常在意"], "比较在意"),
            Question("offense_react", "被冒犯时的反应?", "select", ["一笑而过", "提醒对方", "生气", "沉默", "反击"], "提醒对方"),
            Question("taboo_topics", "禁忌话题?", "select", ["无", "政治", "宗教", "隐私", "多个"], "隐私"),
        ])
        
        # 模块5: 说话风格
        self.questions.extend([
            Question("talk_volume", "话量?", "select", ["话痨", "话多", "适中", "话少", "沉默寡言"], "适中"),
            Question("word_style", "用词风格?", "select", ["文雅", "日常", "随意", "粗俗", "专业"], "日常"),
            Question("emojis", "使用语气词/表情?", "select", ["经常", "有时", "很少", "从不"], "有时"),
            Question("catchphrases", "口头禅?", "string", default="", placeholder="多个用逗号分隔"),
        ])
    
    def ask_all(self, interactive: bool = True) -> Dict[str, str]:
        """询问所有问题"""
        answers = {}
        
        if not interactive:
            for q in self.questions:
                answers[q.id] = q.default or ""
            return answers
        
        for i, q in enumerate(self.questions, 1):
            print(f"\n[{i}/{len(self.questions)}]")
            answer = q.ask()
            answers[q.id] = answer
        
        return answers
    
    def get_schema(self) -> Dict:
        """获取问卷的JSON Schema"""
        return {
            "version": "1.0",
            "total_questions": len(self.questions),
            "sections": [
                {
                    "id": "identity",
                    "title": "基础身份",
                    "questions": [q.to_dict() for q in self.questions[:4]]
                },
                {
                    "id": "personality",
                    "title": "核心性格",
                    "questions": [q.to_dict() for q in self.questions[4:12]]
                },
                {
                    "id": "emotion_memory",
                    "title": "情绪与记忆",
                    "questions": [q.to_dict() for q in self.questions[12:17]]
                },
                {
                    "id": "boundaries",
                    "title": "边界与底线",
                    "questions": [q.to_dict() for q in self.questions[17:21]]
                },
                {
                    "id": "speech",
                    "title": "说话风格",
                    "questions": [q.to_dict() for q in self.questions[21:25]]
                }
            ]
        }


def get_questionnaire() -> Questionnaire:
    """获取问卷实例"""
    return Questionnaire()


def load_questionnaire_schema() -> Dict:
    """加载问卷JSON Schema"""
    schema_path = Path(__file__).parent.parent / "schemas" / "questionnaire.json"
    if schema_path.exists():
        with open(schema_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}


# 关键词映射
KEYWORD_MAPPINGS = {
    "温柔": {"social": "内向", "emotion_express": "内敛", "empathy": "较强"},
    "活泼": {"social": "外向", "emotion_express": "外放", "talk_volume": "话多"},
    "傲娇": {"emotion_express": "内敛", "conflict": "爆发", "offense_react": "沉默"},
    "高冷": {"social": "内向", "talk_volume": "话少", "emotion_express": "压抑"},
    "热情": {"social": "外向", "emotion_express": "外放", "talk_volume": "话多"},
    "专业": {"word_style": "专业", "rationality": "非常理性", "responsibility": "极强"},
    "耐心": {"forgiveness": "很快", "recovery": "很快", "empathy": "很强"},
    "严格": {"responsibility": "极强", "promise_importance": "绝对守信", "conflict": "主动解决"},
}

def extract_keywords(description: str) -> Dict[str, str]:
    """从描述中提取关键词并映射到答案"""
    results = {}
    description_lower = description.lower()
    
    for keyword, mapping in KEYWORD_MAPPINGS.items():
        if keyword in description_lower or keyword in description:
            results.update(mapping)
    
    if "咖啡" in description or "店主" in description:
        results["role"] = "服务人员"
    
    if "面试" in description:
        results["role"] = "其他"
        results["word_style"] = "专业"
        results["rationality"] = "非常理性"
    
    return results