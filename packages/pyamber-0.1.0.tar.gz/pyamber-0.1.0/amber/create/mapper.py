"""
问卷答案 → 人格参数映射
"""

from typing import Dict, Any


class ParameterMapper:
    """参数映射器"""
    
    def __init__(self):
        self._init_mappings()
    
    def _init_mappings(self):
        """初始化映射表"""
        self.mappings = {
            # 社交倾向
            "social": {
                "极度外向": {"stats": {"activation_base": 0.3, "pleasure_base": 0.2}, "silence_frequency": -2},
                "外向": {"stats": {"activation_base": 0.1}, "silence_frequency": -1},
                "中间": {},
                "内向": {"stats": {"activation_base": -0.2}, "silence_frequency": 1},
                "极度内向": {"stats": {"activation_base": -0.3}, "silence_frequency": 2},
            },
            # 情绪表达
            "emotion_express": {
                "外放": {"emotion_amplitude": 0.3},
                "适中": {},
                "内敛": {"emotion_amplitude": -0.2},
                "压抑": {"emotion_amplitude": -0.3, "silence_frequency": 1},
            },
            # 共情能力
            "empathy": {
                "很强": {"eq": 0.3, "emotion_sensitivity": 0.2},
                "较强": {"eq": 0.15},
                "普通": {},
                "较弱": {"eq": -0.15},
                "很弱": {"eq": -0.3},
            },
            # 记仇程度
            "memory_grudge": {
                "完全不记仇": {"memory_retention": 0.5, "trust_decay_rate": -0.2},
                "不太记仇": {"memory_retention": 0.75, "trust_decay_rate": -0.1},
                "一般": {},
                "比较记仇": {"memory_retention": 1.5, "trust_decay_rate": 0.2},
                "非常记仇": {"memory_retention": 2.0, "trust_decay_rate": 0.3},
            },
            # 原谅速度
            "forgiveness": {
                "很快": {"trust_recovery_rate": 0.3},
                "较快": {"trust_recovery_rate": 0.15},
                "一般": {},
                "较慢": {"trust_recovery_rate": -0.15},
                "很慢": {"trust_recovery_rate": -0.3},
            },
            # 话量
            "talk_volume": {
                "话痨": {"speech_min_length": 50, "silence_frequency": -3},
                "话多": {"speech_min_length": 30, "silence_frequency": -1},
                "适中": {},
                "话少": {"speech_max_length": 50, "silence_frequency": 1},
                "沉默寡言": {"speech_max_length": 30, "silence_frequency": 2},
            },
            # 用词风格
            "word_style": {
                "文雅": {"speech_temperature": 0.5},
                "日常": {"speech_temperature": 0.7},
                "随意": {"speech_temperature": 0.9},
                "粗俗": {"speech_temperature": 1.0},
                "专业": {"speech_temperature": 0.6},
            },
            # 话题开放度
            "openness": {
                "非常开放": {"boundary_strictness": 0.2},
                "开放": {"boundary_strictness": 0.4},
                "一般": {"boundary_strictness": 0.6},
                "保守": {"boundary_strictness": 0.8},
                "非常保守": {"boundary_strictness": 1.0},
            },
        }
    
    def map(self, answers: Dict[str, str]) -> Dict[str, Any]:
        """
        将答案映射为参数
        
        Args:
            answers: 答案字典
            
        Returns:
            参数字典
        """
        params = {
            "identity": {},
            "stats": {"int": 1.0, "eq": 1.0, "con": 1.0},
            "emotion": {
                "base": {"pleasure": 0.3, "activation": 0.5, "trust": 0.4},
                "sensitivity": {"pleasure": 1.0, "trust": 1.0}
            },
            "speech": {
                "style": "normal",
                "min_length": 10,
                "max_length": 90,
                "temperature": 0.7,
                "catchphrases": []
            },
            "boundaries": {
                "reject_when": [],
                "silence_when": [],
                "topic_blacklist": []
            },
            "memory_schema": {
                "max_facts": 500,
                "retention_days": 30,
                "forget_rate": 0.05
            }
        }
        
        # 映射身份信息
        if "age" in answers:
            age_map = {"18-22": 20, "23-27": 25, "28-35": 30, "36-45": 40, "45+": 50}
            params["identity"]["age"] = age_map.get(answers["age"], 25)
        
        if "gender" in answers:
            gender_map = {"男性": "male", "女性": "female", "中性": "neutral"}
            params["identity"]["gender"] = gender_map.get(answers["gender"], "neutral")
        
        if "role" in answers:
            params["identity"]["role"] = answers["role"]
        
        if "relationship" in answers:
            params["identity"]["relationship"] = answers["relationship"]
        
        # 映射核心属性
        for q_id, answer in answers.items():
            if q_id in self.mappings and answer in self.mappings[q_id]:
                mapping = self.mappings[q_id][answer]
                
                # 应用属性修改
                if "stats" in mapping:
                    for stat, delta in mapping["stats"].items():
                        if stat in params["stats"]:
                            params["stats"][stat] += delta
                        else:
                            params["stats"][stat] = 1.0 + delta
                
                # 应用情绪修改
                if "emotion_amplitude" in mapping:
                    params["emotion"]["sensitivity"]["pleasure"] += mapping["emotion_amplitude"]
                
                if "emotion_sensitivity" in mapping:
                    params["emotion"]["sensitivity"]["trust"] += mapping["emotion_sensitivity"]
                
                # 应用记忆修改
                if "memory_retention" in mapping:
                    params["memory_schema"]["max_facts"] = int(500 * mapping["memory_retention"])
                
                if "trust_decay_rate" in mapping:
                    params["emotion"]["trust_decay_rate"] = mapping["trust_decay_rate"]
                
                # 应用说话风格
                if "speech_min_length" in mapping:
                    params["speech"]["min_length"] = mapping["speech_min_length"]
                if "speech_max_length" in mapping:
                    params["speech"]["max_length"] = mapping["speech_max_length"]
                if "speech_temperature" in mapping:
                    params["speech"]["temperature"] = mapping["speech_temperature"]
                
                if "silence_frequency" in mapping:
                    # 影响沉默频率
                    pass
        
        # 确保数值在合理范围内
        for stat in ["int", "eq", "con"]:
            params["stats"][stat] = max(0.3, min(1.5, params["stats"][stat]))
        
        for key in ["pleasure", "activation", "trust"]:
            params["emotion"]["base"][key] = max(0.0, min(1.0, params["emotion"]["base"][key]))
        
        return params
    
    def infer_type(self, answers: Dict[str, str]) -> str:
        """推断人格类型"""
        # 基于答案推断是独立人格还是服务型人格
        role = answers.get("role", "")
        relationship = answers.get("relationship", "")
        
        # 服务型角色
        service_roles = ["白领", "服务人员"]
        service_relationships = ["同事"]
        
        if role in service_roles or relationship in service_relationships:
            return "service"
        
        # 独立型关系
        independent_relationships = ["朋友", "恋人", "家人"]
        if relationship in independent_relationships:
            return "independent"
        
        return "independent"  # 默认独立人格


def map_answers_to_params(answers: Dict[str, str]) -> Dict[str, Any]:
    """将答案映射为人格参数"""
    mapper = ParameterMapper()
    return mapper.map(answers)


def infer_personality_type(answers: Dict[str, str]) -> str:
    """推断人格类型"""
    mapper = ParameterMapper()
    return mapper.infer_type(answers)
