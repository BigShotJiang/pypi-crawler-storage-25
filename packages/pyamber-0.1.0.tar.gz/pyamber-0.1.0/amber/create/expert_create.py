"""
专家创建 - 直接回答25题问卷
"""

from typing import Dict, Any, Optional
from datetime import datetime

from amber.create.questionnaire import Questionnaire
from amber.create.mapper import map_answers_to_params, infer_personality_type
from amber.formats.amber_format import save_amber
from amber.formats.memory_format import create_empty_memory, save_memory


def expert_create(personality_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    专家模式创建 - 直接回答25题问卷
    
    Args:
        personality_type: 指定人格类型（可选）
        
    Returns:
        创建结果
    """
    print("\n🎯 专家模式 - 请回答以下25个问题")
    print("=" * 50)
    
    # 获取问卷
    q = Questionnaire()
    
    # 收集答案
    answers = q.ask_all(interactive=True)
    
    # 映射为参数
    params = map_answers_to_params(answers)
    
    # 推断或使用指定的人格类型
    if personality_type:
        params["personality_type"] = {
            "type": personality_type,
            "service_ratio": 1.0 if personality_type == "service" else 0.0
        }
    else:
        inferred_type = infer_personality_type(answers)
        params["personality_type"] = {
            "type": inferred_type,
            "service_ratio": 1.0 if inferred_type == "service" else 0.0
        }
        print(f"\n📊 推断人格类型: {inferred_type}")
    
    # 生成名称
    name = generate_expert_name(answers)
    params["identity"]["name"] = name
    
    # 添加元数据
    params["version"] = "1.0"
    params["created_at"] = datetime.now().isoformat()
    params["metadata"] = {
        "creation_mode": "expert",
        "answers_summary": {k: v for k, v in list(answers.items())[:10]}
    }
    
    # 确认生成
    print("\n" + "=" * 50)
    print("即将生成人格:")
    print(f"  名称: {name}")
    print(f"  类型: {params['personality_type']['type']}")
    print(f"  角色: {params['identity'].get('role', '未指定')}")
    
    confirm = input("\n确认生成? (y/n): ").strip().lower()
    if confirm != 'y':
        print("取消创建")
        return None
    
    # 保存
    data_dir = f"./data/personas/{name}"
    os.makedirs(data_dir, exist_ok=True)
    
    amber_path = os.path.join(data_dir, f"{name}.amber")
    save_amber(params, amber_path)
    
    memory = create_empty_memory(params["version"], params["personality_type"]["type"])
    memory_path = os.path.join(data_dir, f"{name}.memory")
    save_memory(memory, memory_path)
    
    print(f"\n✅ 人格 '{name}' 创建成功!")
    print(f"   位置: {data_dir}")
    
    return {"name": name, "params": params}


def generate_expert_name(answers: Dict[str, str]) -> str:
    """根据答案生成名称"""
    role = answers.get("role", "")
    
    if role == "服务人员":
        return "小助手"
    elif role == "白领":
        return "职场伙伴"
    elif role == "学生":
        return "同学"
    elif role == "艺术家":
        return "艺艺"
    else:
        return "新人格"


import os
