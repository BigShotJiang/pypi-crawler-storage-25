"""
参数验证器
"""

from typing import Dict, Any, List, Tuple


class ParameterValidator:
    """参数验证器"""
    
    def validate(self, params: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        验证参数
        
        Args:
            params: 参数字典
            
        Returns:
            (是否有效, 错误列表)
        """
        errors = []
        
        # 验证必需字段
        required_fields = ["identity", "stats", "emotion", "speech"]
        for field in required_fields:
            if field not in params:
                errors.append(f"缺少必需字段: {field}")
        
        # 验证stats
        if "stats" in params:
            stats = params["stats"]
            for stat in ["int", "eq", "con"]:
                if stat in stats:
                    value = stats[stat]
                    if not (0.3 <= value <= 1.5):
                        errors.append(f"stats.{stat} 应在 0.3-1.5 之间，当前值: {value}")
        
        # 验证emotion
        if "emotion" in params:
            emotion = params["emotion"]
            if "base" in emotion:
                for dim in ["pleasure", "activation", "trust"]:
                    if dim in emotion["base"]:
                        value = emotion["base"][dim]
                        if not (0.0 <= value <= 1.0):
                            errors.append(f"emotion.base.{dim} 应在 0.0-1.0 之间，当前值: {value}")
        
        # 验证speech
        if "speech" in params:
            speech = params["speech"]
            if "temperature" in speech:
                temp = speech["temperature"]
                if not (0.0 <= temp <= 2.0):
                    errors.append(f"speech.temperature 应在 0.0-2.0 之间，当前值: {temp}")
        
        return len(errors) == 0, errors
    
    def sanitize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """清理和修正参数"""
        # 确保stats在范围内
        if "stats" in params:
            for stat in ["int", "eq", "con"]:
                if stat in params["stats"]:
                    params["stats"][stat] = max(0.3, min(1.5, params["stats"][stat]))
        
        # 确保emotion在范围内
        if "emotion" in params:
            if "base" in params["emotion"]:
                for dim in ["pleasure", "activation", "trust"]:
                    if dim in params["emotion"]["base"]:
                        params["emotion"]["base"][dim] = max(0.0, min(1.0, params["emotion"]["base"][dim]))
        
        # 确保temperature在范围内
        if "speech" in params and "temperature" in params["speech"]:
            params["speech"]["temperature"] = max(0.0, min(2.0, params["speech"]["temperature"]))
        
        return params


def validate_params(params: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """验证参数"""
    validator = ParameterValidator()
    return validator.validate(params)


def sanitize_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """清理参数"""
    validator = ParameterValidator()
    return validator.sanitize(params)
