"""
智能创建 - AI生成针对性问题 + 基础问卷
"""

import os
import json
import re
from typing import Dict, Any, Optional, List
from datetime import datetime

from amber.create.questionnaire import Questionnaire, DynamicQuestion
from amber.create.mapper import map_answers_to_params
from amber.formats.amber_format import save_amber
from amber.formats.memory_format import create_empty_memory, save_memory
from amber.utils.llm_client import get_client


def smart_create(description: str,
                 personality_type: str = "independent",
                 service_ratio: float = 0.5,
                 interactive: bool = True) -> Optional[Dict[str, Any]]:
    """
    智能创建人格 - AI生成针对性问题，用户填写问卷
    
    模式:
        interactive=True: 显示基础问卷 + AI生成问题 + 用户自定义补充
        interactive=False: 纯AI脑补，不显示任何问题
    """
    print(f"\n🔍 分析描述: {description}")
    
    llm = get_client()
    
    # 快速模式：纯AI脑补，不显示问卷
    if not interactive:
        print("⚡ 快速模式：AI直接脑补人格...")
        return _ai_only_create(description, personality_type, service_ratio, llm)
    
    # 智能模式：生成问题让用户填写
    print("📝 智能模式：生成针对性问题...")
    
    # 1. 加载基础问卷（25题）
    base_questions = Questionnaire()
    
    # 2. AI生成25个针对性问题
    ai_questions = []
    if llm.is_available():
        print("🤖 AI正在生成针对性问题...")
        try:
            ai_questions = _generate_ai_questions(llm, description)
            print(f"   ✓ 生成了 {len(ai_questions)} 个针对性问题")
        except Exception as e:
            print(f"   ⚠️ AI问题生成失败: {e}")
    
    # 3. 用户自定义补充问题
    custom_questions = []
    print("\n💬 你可以补充自定义问题（输入空行结束）:")
    while True:
        custom = input("补充问题: ").strip()
        if not custom:
            break
        custom_questions.append(DynamicQuestion(
            id=f"custom_{len(custom_questions)}",
            text=custom,
            qtype="string"
        ))
    
    # 4. 收集所有答案
    all_answers = {}
    
    # 4.1 基础问卷
    print("\n" + "=" * 60)
    print("📋 第一部分：基础信息（25题）")
    print("=" * 60)
    base_answers = base_questions.ask_all(interactive=True)
    all_answers.update(base_answers)
    
    # 4.2 AI生成问题
    if ai_questions:
        print("\n" + "=" * 60)
        print("🧠 第二部分：AI根据你的描述生成的问题")
        print("=" * 60)
        for i, q in enumerate(ai_questions, 1):
            print(f"\n[{i}/25]")
            answer = q.ask()
            all_answers[q.id] = answer
    
    # 4.3 用户自定义问题
    if custom_questions:
        print("\n" + "=" * 60)
        print("💡 第三部分：你补充的问题")
        print("=" * 60)
        for i, q in enumerate(custom_questions, 1):
            print(f"\n[{i}]")
            answer = q.ask()
            all_answers[q.id] = answer
    
    # 5. 生成名称
    name = _suggest_name(llm, description, all_answers) if llm.is_available() else None
    if not name:
        name = _fallback_name(description)
    
    # 用户确认名称
    user_name = input(f"\n📝 建议名称: {name}\n请输入名称（回车使用建议）: ").strip()
    if user_name:
        name = user_name
    
    # 6. 映射为基础参数
    params = map_answers_to_params(all_answers)
    
    # 7. 用AI答案增强参数（如果有）
    if ai_answers := {k: v for k, v in all_answers.items() if k.startswith("ai_")}:
        params = _enhance_with_ai_answers(params, ai_answers)
    
    # 8. 设置人格类型
    if personality_type == "mixed":
        params["personality_type"] = {
            "type": "mixed",
            "service_ratio": service_ratio
        }
    else:
        params["personality_type"] = {
            "type": personality_type,
            "service_ratio": 0.0 if personality_type == "independent" else 1.0
        }
    
    # 9. 设置名称和描述
    params["identity"]["name"] = name
    params["identity"]["description"] = description
    params["version"] = "1.0"
    params["created_at"] = datetime.now().isoformat()
    params["metadata"] = {
        "creation_mode": "smart",
        "original_description": description,
        "llm_assisted": llm.is_available(),
        "ai_questions_count": len(ai_questions),
        "custom_questions_count": len(custom_questions)
    }
    
    # 10. 添加签名
    if "signature" not in params:
        params["signature"] = {}
    params["signature"]["creator_id"] = os.environ.get("AMBER_USER", "anonymous")
    params["signature"]["created_at"] = datetime.now().isoformat()
    params["signature"]["license"] = "CC-BY-NC-ND-4.0"
    
    # 11. 保存
    data_dir = f"./data/personas/{name}"
    os.makedirs(data_dir, exist_ok=True)
    
    amber_path = os.path.join(data_dir, f"{name}.amber")
    save_amber(params, amber_path)
    
    memory = create_empty_memory(params["version"], personality_type)
    memory_path = os.path.join(data_dir, f"{name}.memory")
    save_memory(memory, memory_path)
    
    print(f"\n✅ 人格 '{name}' 创建成功!")
    print(f"   类型: {personality_type}")
    print(f"   运行: amber run {name}")
    
    return {"name": name, "params": params}


def _ai_only_create(description: str, personality_type: str, 
                    service_ratio: float, llm) -> Dict[str, Any]:
    """纯AI脑补模式 - 不显示任何问题"""
    
    if llm.is_available():
        print("🤖 AI正在脑补人格细节...")
        try:
            params = _llm_generate_full_params(llm, description)
            print("   ✓ AI脑补完成")
        except Exception as e:
            print(f"   ⚠️ AI脑补失败: {e}，使用默认参数")
            params = _get_default_params()
    else:
        print("   ⚠️ LLM不可用，使用默认参数")
        params = _get_default_params()
    
    # 生成名称
    name = _suggest_name(llm, description, {}) if llm.is_available() else None
    if not name:
        name = _fallback_name(description)
    
    # 设置参数
    params["identity"]["name"] = name
    params["identity"]["description"] = description
    params["personality_type"] = {
        "type": personality_type,
        "service_ratio": 0.0 if personality_type == "independent" else 1.0
    }
    params["version"] = "1.0"
    params["created_at"] = datetime.now().isoformat()
    params["metadata"] = {
        "creation_mode": "ai_only",
        "original_description": description,
        "llm_assisted": llm.is_available()
    }
    
    if "signature" not in params:
        params["signature"] = {}
    params["signature"]["creator_id"] = os.environ.get("AMBER_USER", "anonymous")
    params["signature"]["created_at"] = datetime.now().isoformat()
    params["signature"]["license"] = "CC-BY-NC-ND-4.0"
    
    # 保存
    data_dir = f"./data/personas/{name}"
    os.makedirs(data_dir, exist_ok=True)
    
    amber_path = os.path.join(data_dir, f"{name}.amber")
    save_amber(params, amber_path)
    
    memory = create_empty_memory(params["version"], personality_type)
    memory_path = os.path.join(data_dir, f"{name}.memory")
    save_memory(memory, memory_path)
    
    print(f"\n✅ 人格 '{name}' 创建成功!")
    print(f"   类型: {personality_type}")
    print(f"   运行: amber run {name}")
    
    return {"name": name, "params": params}


def _generate_ai_questions(llm, description: str) -> List:
    """AI生成25个针对性问题"""
    prompt = f"""根据以下人格描述，生成25个针对性问题，用于深入了解这个人格。

描述: {description}

要求:
1. 问题要针对这个特定角色，不要通用问题
2. 每个问题应该能揭示角色的独特性格
3. 问题格式: 简单的问句

返回格式（JSON数组）:
["问题1", "问题2", ...]

只返回JSON数组，不要其他内容。"""

    response = llm.chat([
        {"role": "system", "content": "你是人格设计师。生成针对性的问题。"},
        {"role": "user", "content": prompt}
    ], temperature=0.7, max_tokens=1500)
    
    json_match = re.search(r'\[.*\]', response, re.DOTALL)
    if json_match:
        questions = json.loads(json_match.group())
        return [DynamicQuestion(id=f"ai_{i}", text=q, qtype="string") 
                for i, q in enumerate(questions[:25])]
    return []


def _llm_generate_full_params(llm, description: str) -> Dict:
    """AI直接生成完整人格参数（脑补模式）"""
    prompt = f"""根据以下人格描述，生成完整的人格参数。

描述: {description}

返回JSON格式:
{{
    "identity": {{"role": "角色", "age": 年龄}},
    "stats": {{"int": 智商0.3-1.5, "eq": 情商0.3-1.5, "con": 体质0.3-1.5}},
    "emotion": {{"base": {{"pleasure": 0-1, "activation": 0-1, "trust": 0-1}}}},
    "speech": {{"style": "风格", "temperature": 0-2, "catchphrases": ["口头禅"]}},
    "boundaries": {{"topic_blacklist": ["禁忌话题"]}}
}}

只返回JSON。"""

    response = llm.chat([
        {"role": "system", "content": "你是人格参数专家。"},
        {"role": "user", "content": prompt}
    ], temperature=0.5, max_tokens=1000)
    
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        return json.loads(json_match.group())
    return _get_default_params()


def _get_default_params() -> Dict:
    """默认参数"""
    return {
        "identity": {"role": "未知", "age": 25},
        "stats": {"int": 1.0, "eq": 1.0, "con": 1.0},
        "emotion": {"base": {"pleasure": 0.3, "activation": 0.5, "trust": 0.4}},
        "speech": {"style": "normal", "temperature": 0.7, "catchphrases": []},
        "boundaries": {"topic_blacklist": []}
    }


def _enhance_with_ai_answers(params: Dict, ai_answers: Dict) -> Dict:
    """用AI问题答案增强参数"""
    # 将AI答案合并到params中作为额外字段
    params["ai_insights"] = ai_answers
    return params


def _suggest_name(llm, description: str, answers: Dict) -> str:
    """建议名称"""
    prompt = f"为以下人格建议一个2-3字的中文名:\n{description}\n只返回名字:"
    
    try:
        response = llm.chat([
            {"role": "user", "content": prompt}
        ], temperature=0.7, max_tokens=20)
        name = response.strip()
        if 2 <= len(name) <= 4:
            return name
    except Exception:
        pass
    return ""


def _fallback_name(description: str) -> str:
    """备用名称"""
    mapping = {
        "咖啡": "林夏", "温柔": "小暖", "面试": "张老师",
        "英语": "MsWang", "傲娇": "浅浅", "助手": "小助"
    }
    for k, v in mapping.items():
        if k in description:
            return v
    return "新人格"