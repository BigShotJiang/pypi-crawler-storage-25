"""
amber create 命令实现 - 支持三种模式
"""

import click
from pathlib import Path

from amber.create.smart_create import smart_create
from amber.create.quick_create import quick_create
from amber.create.expert_create import expert_create


@click.command()
@click.argument("description", required=False)
@click.option("--type", "personality_type", type=click.Choice(["independent", "service", "mixed"]), 
              default="independent", help="人格类型")
@click.option("--service-ratio", type=float, default=0.5, help="服务比例 (0-1, 仅mixed类型)")
@click.option("--quick", is_flag=True, help="快速模式：纯AI脑补，不显示问卷")
@click.option("--expert", is_flag=True, help="专家模式：显示完整25题基础问卷")
@click.option("--interactive", is_flag=True, help="智能模式：基础问卷+AI问题+自定义补充")
@click.option("--template", help="使用模板创建")
@click.option("--license", default="CC-BY-NC-ND-4.0", help="许可证")
@click.option("--save-as", help="保存文件名")
def create(description, personality_type, service_ratio, quick, expert, 
           interactive, template, license, save_as):
    """
    创建人格 - 三种模式
    
    智能模式 (默认): 基础问卷 + AI生成25个针对性问题 + 用户自定义补充
    快速模式 (--quick): 纯AI脑补，不显示任何问题
    专家模式 (--expert): 只显示25题基础问卷
    
    示例:
        amber create "傲娇的高中生"                    # 智能模式
        amber create "温柔的咖啡师" --quick            # 快速模式
        amber create --expert                         # 专家模式
        amber create --template interviewer           # 使用模板
    """
    if template:
        click.echo(f"使用模板: {template}")
        from amber.templates.loader import load_template
        template_data = load_template(template)
        if template_data:
            description = template_data.get("description", "")
            personality_type = template_data.get("type", personality_type)
    
    # 确定交互模式
    if expert:
        click.echo("🎯 专家模式 - 只显示25题基础问卷")
        result = expert_create()
    elif quick:
        click.echo("⚡ 快速模式 - AI直接脑补")
        result = smart_create(description, personality_type, service_ratio, interactive=False)
    else:
        click.echo("🧠 智能模式 - 基础问卷 + AI问题 + 自定义补充")
        result = smart_create(description, personality_type, service_ratio, interactive=True)
    
    if result:
        name = save_as or result.get("name", "新人格")
        click.echo(f"✅ 人格 '{name}' 创建成功！")
        click.echo(f"   类型: {personality_type}")
        click.echo(f"   运行: amber run {name}")
    else:
        click.echo("❌ 创建失败")