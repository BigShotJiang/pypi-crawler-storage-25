"""
CLI主入口 - click命令组定义
"""

import click
from pathlib import Path

from amber.cli.commands.create import create
from amber.cli.commands.run import run
from amber.cli.commands.list import list_personas
from amber.cli.commands.info import info
from amber.cli.commands.delete import delete
from amber.cli.commands.edit import edit
from amber.cli.commands.fork import fork
from amber.cli.commands.pr import pr
from amber.cli.commands.export import export
from amber.cli.commands.import_cmd import import_persona
from amber.cli.commands.memory import memory
from amber.cli.commands.verify import verify
from amber.cli.commands.detect import detect
from amber.cli.commands.convert import convert
from amber.cli.commands.update import update
from amber.cli.commands.templates import templates
from amber.cli.commands.lineage import lineage
from amber.cli.commands.sync import sync
from amber.cli.commands.release import release
from amber.cli.commands.rollback import rollback
from amber.cli.commands.search import search
from amber.cli.commands.download import download
from amber.cli.commands.publish import publish


@click.group()
@click.version_option(version="0.1.0")
def cli():
    """
    Amber - 人格工坊
    
    让任何人都能用自然语言创造有灵魂、会记忆、能理解、有底线的数字人格。
    """
    pass


# 注册所有命令
cli.add_command(create)
cli.add_command(run)
cli.add_command(list_personas)
cli.add_command(info)
cli.add_command(delete)
cli.add_command(edit)
cli.add_command(fork)
cli.add_command(pr)
cli.add_command(export)
cli.add_command(import_persona)
cli.add_command(memory)
cli.add_command(verify)
cli.add_command(detect)
cli.add_command(convert)
cli.add_command(update)
cli.add_command(templates)
cli.add_command(lineage)
cli.add_command(sync)
cli.add_command(release)
cli.add_command(rollback)
cli.add_command(search)
cli.add_command(download)
cli.add_command(publish)


if __name__ == "__main__":
    cli()
