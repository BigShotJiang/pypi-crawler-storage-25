"""
FastAPI主应用
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from amber.web.api import personas, users, search, download

app = FastAPI(
    title="Amber API",
    description="人格工坊 API",
    version="0.1.0"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(personas.router, prefix="/api/personas", tags=["personas"])
app.include_router(users.router, prefix="/api/users", tags=["users"])
app.include_router(search.router, prefix="/api/search", tags=["search"])
app.include_router(download.router, prefix="/api/download", tags=["download"])

# 静态文件
static_path = Path(__file__).parent / "static"
if static_path.exists():
    app.mount("/", StaticFiles(directory=str(static_path), html=True), name="static")


@app.get("/")
async def root():
    return {"message": "Amber API", "version": "0.1.0"}


@app.get("/health")
async def health():
    return {"status": "healthy"}


def create_app() -> FastAPI:
    """创建应用实例"""
    return app
