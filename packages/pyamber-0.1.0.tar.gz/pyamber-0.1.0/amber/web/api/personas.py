"""
人格CRUD API
"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from pathlib import Path
import yaml
import os
from datetime import datetime

router = APIRouter()


class PersonaCreate(BaseModel):
    """创建人格请求"""
    name: str
    description: str
    personality_type: str = "independent"
    service_ratio: float = 0.5


class QuestionnaireCreate(BaseModel):
    """问卷创建人格请求"""
    name: str
    answers: Dict[str, str]
    personality_type: str = "independent"


class PersonaResponse(BaseModel):
    """人格响应"""
    name: str
    type: str
    description: str
    download_count: int
    fork_count: int
    creator: str


@router.get("/", response_model=List[PersonaResponse])
async def list_personas(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    type: Optional[str] = None
):
    """列出人格"""
    personas_dir = Path("./data/personas")
    
    if not personas_dir.exists():
        return []
    
    result = []
    for persona_dir in personas_dir.iterdir():
        if not persona_dir.is_dir():
            continue
        
        amber_file = persona_dir / f"{persona_dir.name}.amber"
        if not amber_file.exists():
            continue
        
        with open(amber_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        ptype = data.get("personality_type", {}).get("type", "unknown")
        if type and ptype != type:
            continue
        
        result.append(PersonaResponse(
            name=persona_dir.name,
            type=ptype,
            description=data.get("identity", {}).get("description", ""),
            download_count=0,
            fork_count=0,
            creator=data.get("signature", {}).get("creator_id", "unknown")
        ))
    
    return result[skip:skip+limit]


@router.get("/{name}")
async def get_persona(name: str):
    """获取人格详情"""
    amber_file = Path(f"./data/personas/{name}/{name}.amber")
    
    if not amber_file.exists():
        raise HTTPException(status_code=404, detail="Persona not found")
    
    with open(amber_file, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    return data


@router.post("/")
async def create_persona(request: PersonaCreate):
    """创建人格"""
    from amber.create.smart_create import smart_create
    
    result = smart_create(
        request.description,
        request.personality_type,
        request.service_ratio,
        interactive=False
    )
    
    if result:
        return {"success": True, "name": result["name"]}
    else:
        raise HTTPException(status_code=500, detail="Creation failed")


@router.post("/create-with-questionnaire")
async def create_with_questionnaire(request: QuestionnaireCreate):
    """通过问卷创建人格"""
    from amber.create.mapper import map_answers_to_params
    from amber.formats.amber_format import save_amber
    from amber.formats.memory_format import create_empty_memory
    
    try:
        # 映射答案为参数
        params = map_answers_to_params(request.answers)
        
        # 设置名称
        name = request.name
        params["identity"]["name"] = name
        params["identity"]["description"] = f"通过Web问卷创建的人格"
        
        # 设置人格类型
        params["personality_type"] = {
            "type": request.personality_type,
            "service_ratio": 0.0 if request.personality_type == "independent" else 1.0
        }
        
        # 添加元数据
        params["version"] = "1.0"
        params["created_at"] = datetime.now().isoformat()
        params["metadata"] = {
            "creation_mode": "web_questionnaire",
            "llm_assisted": False
        }
        
        # 添加签名
        if "signature" not in params:
            params["signature"] = {}
        params["signature"]["creator_id"] = "web_user"
        params["signature"]["created_at"] = datetime.now().isoformat()
        params["signature"]["license"] = "CC-BY-NC-ND-4.0"
        
        # 保存文件
        data_dir = Path(f"./data/personas/{name}")
        data_dir.mkdir(parents=True, exist_ok=True)
        
        amber_path = data_dir / f"{name}.amber"
        save_amber(params, str(amber_path))
        
        memory = create_empty_memory(params["version"], request.personality_type)
        memory_path = data_dir / f"{name}.memory"
        
        from amber.formats.memory_format import save_memory
        save_memory(memory, str(memory_path))
        
        return {
            "success": True,
            "name": name,
            "personality_type": request.personality_type,
            "role": params.get("identity", {}).get("role", ""),
            "persona": params
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{name}")
async def delete_persona(name: str):
    """删除人格"""
    import shutil
    persona_dir = Path(f"./data/personas/{name}")
    
    if not persona_dir.exists():
        raise HTTPException(status_code=404, detail="Persona not found")
    
    shutil.rmtree(persona_dir)
    
    return {"success": True}