"""
Amber - 人格工坊
"""

__version__ = "0.1.0"
__author__ = "GraceFox"

from amber.core.persona import Persona
from amber.core.response import Response

__all__ = ["Persona", "Response"]
