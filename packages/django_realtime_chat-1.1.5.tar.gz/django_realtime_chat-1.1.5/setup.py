from setuptools import setup, find_packages

setup(
    name="django-realtime-chat",
    version="1.1.5",
    description="Plugin Django de chat temps réel via WebSocket (Django Channels)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Armand Kouassi (krak225)",
    python_requires=">=3.9",
    packages=find_packages(),
    include_package_data=True,   # inclut les fichiers listés dans MANIFEST.in
    install_requires=[
        "Django>=4.0",
        "channels>=4.0",
        "channels-redis>=4.0",
        "djangorestframework>=3.14",
        "djangorestframework-simplejwt>=5.0",
    ],
    classifiers=[
        "Framework :: Django",
        "Programming Language :: Python :: 3",
    ],
)
