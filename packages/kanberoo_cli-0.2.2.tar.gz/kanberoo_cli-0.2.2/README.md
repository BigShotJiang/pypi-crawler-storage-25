# `kanberoo-cli` has been renamed

This package has been renamed to [`kanbaroo-cli`](https://pypi.org/project/kanbaroo-cli/). The name is a portmanteau of `kangaroo` + `kanban`; the middle letter should have been `a` from the start.

## What to install

```
pip install kanbaroo-cli
```

## Compatibility

This `kanberoo-cli` package remains on PyPI as a version-`0.2.2` compatibility stub that transitively installs `kanbaroo-cli==0.2.2`. `pip install kanberoo-cli` still works; the canonical name going forward is `kanbaroo-cli`. Please update your requirements files and scripts.

## Links

- New package: https://pypi.org/project/kanbaroo-cli/
- GitHub: https://github.com/areese801/kanbaroo
