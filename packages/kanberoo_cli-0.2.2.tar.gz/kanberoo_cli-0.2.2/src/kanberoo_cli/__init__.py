"""
This package has been renamed to kanbaroo-cli.

Install kanbaroo-cli instead: pip install kanbaroo-cli
"""

import warnings

warnings.warn(
    "The 'kanberoo-cli' package has been renamed to 'kanbaroo-cli'. "
    "Please update your installation: pip install kanbaroo-cli",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.2"
