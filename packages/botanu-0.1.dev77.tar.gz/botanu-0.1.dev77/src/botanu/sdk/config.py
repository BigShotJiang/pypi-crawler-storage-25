# SPDX-FileCopyrightText: 2026 The Botanu Authors
# SPDX-License-Identifier: Apache-2.0

"""Configuration for Botanu SDK.

The SDK is intentionally minimal on the hot path. Heavy non-content
processing happens in the OpenTelemetry Collector:

- **SDK responsibility**: generate run_id, propagate context, in-process PII
  scrub on captured content (see :mod:`botanu.sdk.pii`)
- **Collector responsibility**: vendor detection, attribute enrichment, and
  belt-and-suspenders PII regex on everything else

Configuration precedence (highest to lowest):
1. Code arguments (explicit values passed to BotanuConfig)
2. Environment variables (BOTANU_*, OTEL_*)
3. YAML config file (botanu.yaml or specified path)
4. Built-in defaults
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, urlunparse

logger = logging.getLogger(__name__)


_BOTANU_HOST_SUFFIXES = (".botanu.ai",)
_BOTANU_DEV_HOSTS = frozenset({"localhost", "127.0.0.1", "::1", "0.0.0.0"})  # noqa: S104
_SENSITIVE_HEADER_NAMES = frozenset({"authorization", "x-api-key", "botanu-api-key"})


def _is_botanu_trusted_endpoint(endpoint: Optional[str]) -> bool:
    """Return True iff the endpoint host is botanu-owned or a local dev host.

    Used to gate attachment of the botanu API key bearer token to outbound
    OTLP exports. Attaching the key to an attacker-controlled endpoint (e.g.
    via `OTEL_EXPORTER_OTLP_ENDPOINT=https://attacker.example.com`) would
    hand over tenant credentials.
    """
    if not endpoint:
        return False
    try:
        parsed = urlparse(endpoint)
    except (ValueError, AttributeError):
        return False
    host = (parsed.hostname or "").lower()
    if not host:
        return False
    if host in _BOTANU_DEV_HOSTS:
        return True
    return any(host == suffix.lstrip(".") or host.endswith(suffix) for suffix in _BOTANU_HOST_SUFFIXES)


def _redact_url_credentials(url: Optional[str]) -> Optional[str]:
    """Strip `user:pass@` from a URL so it is safe to log."""
    if not url:
        return url
    try:
        parsed = urlparse(url)
    except (ValueError, AttributeError):
        return url
    if not (parsed.username or parsed.password):
        return url
    host = parsed.hostname or ""
    if parsed.port:
        host = f"{host}:{parsed.port}"
    redacted = parsed._replace(netloc=host)
    return urlunparse(redacted)


def _redact_headers(headers: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
    """Return a copy of headers with sensitive values replaced by `***`."""
    if not headers:
        return headers
    out: Dict[str, str] = {}
    for key, value in headers.items():
        if key.lower() in _SENSITIVE_HEADER_NAMES:
            out[key] = "***"
        else:
            out[key] = value
    return out


@dataclass
class BotanuConfig:
    """Configuration for Botanu SDK and OpenTelemetry.

    The SDK is a thin wrapper on OpenTelemetry. In-process PII scrubbing
    runs on captured content via :mod:`botanu.sdk.pii`; cardinality limits
    and vendor enrichment are handled by the OTel Collector.

    Typically configured via environment variables (no hardcoded values)::

        >>> # Reads from OTEL_SERVICE_NAME, OTEL_EXPORTER_OTLP_ENDPOINT, etc.
        >>> config = BotanuConfig()

        >>> # Or load from YAML
        >>> config = BotanuConfig.from_yaml("config/botanu.yaml")
    """

    # Service identification
    service_name: Optional[str] = None
    service_version: Optional[str] = None
    service_namespace: Optional[str] = None
    deployment_environment: Optional[str] = None

    # Resource detection
    auto_detect_resources: bool = True

    # OTLP exporter configuration
    otlp_endpoint: Optional[str] = None
    otlp_headers: Optional[Dict[str, str]] = None

    # Span export configuration
    # Large queue prevents span loss under burst traffic.
    # At ~1KB/span, 65536 spans ≈ 64MB memory ceiling.
    max_export_batch_size: int = 512
    max_queue_size: int = 65536
    schedule_delay_millis: int = 5000
    export_timeout_millis: int = 30000

    # Content capture for eval — 0.10 default (~10% sample). Pre-2026-04-24
    # this defaulted to 0.0, which meant the default install silently
    # produced no judgeable content: set_input_content / set_output_content
    # no-op'd, the L2 judge returned empty test cases, and eval rollups
    # stayed pending forever. Customers had to read the docs AND flip a
    # config flag before the "SDK in, eval out" loop worked at all.
    #
    # 0.10 is what the configuration docs recommend for production; it's
    # enough traffic for the judge to have real cases while keeping PII
    # exposure + storage cost bounded. Three PII-defense layers still
    # fire on every captured attribute:
    #   1. SDK in-process scrub (pii_scrub_enabled — default True below)
    #   2. Collector credential-regex scrub on content attribute prefixes
    #   3. Evaluator Presidio NER pass before judge calls
    # Set to 1.0 for sandbox/shadow, 0.0 to fully disable (e.g. HIPAA
    # where any content capture is a legal hazard).
    content_capture_rate: float = 0.10

    # In-process PII scrubbing — runs on text passed to set_input_content /
    # set_output_content / set_retrieval_content before the span attribute is
    # written. Default ON: safer for customers who enable content_capture_rate
    # without reading the docs.
    pii_scrub_enabled: bool = True
    pii_scrub_disable_patterns: Optional[List[str]] = None
    pii_scrub_custom_patterns: Optional[Dict[str, str]] = None
    pii_scrub_use_presidio: bool = False
    pii_scrub_replacement: str = "[REDACTED]"

    # Resource-cost inference — default ON. When True, enable() attaches the
    # ResourceEnricher SpanProcessor which reads OTel semconv attributes
    # (db.system, http.*.body.size, aws.service, …) and writes the botanu-
    # namespaced `botanu.cloud_provider` + `botanu.bytes_transferred` that
    # the cost worker uses to price non-LLM spans. Without this, S3/DynamoDB/
    # egress all price to $0. Disable only for compliance-sensitive
    # deployments that must emit zero inferred metadata.
    auto_instrument_resources: bool = True

    # Auto-instrumentation packages to enable
    auto_instrument_packages: List[str] = field(
        default_factory=lambda: [
            # HTTP clients
            "requests",
            "httpx",
            "urllib3",
            "aiohttp_client",
            # Web frameworks
            "fastapi",
            "flask",
            "django",
            "starlette",
            # Databases
            "sqlalchemy",
            "psycopg2",
            "asyncpg",
            "pymongo",
            "redis",
            # Messaging
            "celery",
            "kafka_python",
            # gRPC
            "grpc",
            # GenAI / AI
            "openai_v2",
            "anthropic",
            "vertexai",
            "google_genai",
            "langchain",
            # Runtime
            "logging",
        ]
    )

    # Config file path (for tracking where config was loaded from)
    _config_file: Optional[str] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        """Apply environment variable defaults.

        Precedence: BOTANU_* > OTEL_* > defaults
        """
        if self.service_name is None:
            self.service_name = os.getenv(
                "BOTANU_SERVICE_NAME",
                os.getenv("OTEL_SERVICE_NAME", "unknown_service"),
            )

        if self.service_version is None:
            self.service_version = os.getenv("OTEL_SERVICE_VERSION")

        if self.service_namespace is None:
            self.service_namespace = os.getenv("OTEL_SERVICE_NAMESPACE")

        env_auto_detect = os.getenv("BOTANU_AUTO_DETECT_RESOURCES")
        if env_auto_detect is not None:
            self.auto_detect_resources = env_auto_detect.lower() in ("true", "1", "yes")

        if self.deployment_environment is None:
            self.deployment_environment = os.getenv(
                "BOTANU_ENVIRONMENT",
                os.getenv("OTEL_DEPLOYMENT_ENVIRONMENT", "production"),
            )

        botanu_api_key = os.getenv("BOTANU_API_KEY")

        if self.otlp_endpoint is None:
            botanu_endpoint = os.getenv("BOTANU_COLLECTOR_ENDPOINT")
            if botanu_endpoint:
                self.otlp_endpoint = botanu_endpoint
            else:
                env_endpoint = (
                    os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT")
                    or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")
                )
                if env_endpoint:
                    self.otlp_endpoint = env_endpoint
                elif botanu_api_key:
                    # API key implies Botanu Cloud — gateway routes by key prefix
                    self.otlp_endpoint = "https://ingest.botanu.ai"
                else:
                    self.otlp_endpoint = "http://localhost:4318"

        if self.otlp_endpoint and (urlparse(self.otlp_endpoint).username or urlparse(self.otlp_endpoint).password):
            # Embedded credentials in the URL would be logged verbatim elsewhere
            # and bypass our header redaction. Strip them and require explicit
            # `otlp_headers=` if the customer actually wanted auth.
            logger.critical(
                "Botanu SDK: OTLP endpoint contained embedded credentials. "
                "Stripping credentials from the URL. Pass secrets via "
                "otlp_headers= or BOTANU_API_KEY instead."
            )
            self.otlp_endpoint = _redact_url_credentials(self.otlp_endpoint)

        if self.otlp_headers is None and botanu_api_key:
            if _is_botanu_trusted_endpoint(self.otlp_endpoint):
                self.otlp_headers = {"Authorization": f"Bearer {botanu_api_key}"}
            else:
                # SSRF guard: a BOTANU_API_KEY paired with an untrusted endpoint
                # (typically set via OTEL_EXPORTER_OTLP_ENDPOINT) would send the
                # tenant's bearer token to that endpoint — full tenant takeover
                # if the endpoint is attacker-controlled. Refuse to attach the
                # key; spans still flow to the configured endpoint, but without
                # botanu credentials.
                logger.critical(
                    "Botanu SDK: BOTANU_API_KEY is set but the OTLP endpoint "
                    "(%s) is not a botanu-owned host. Refusing to send the API "
                    "key to an untrusted destination. Spans will be exported "
                    "without botanu authentication. Fix: point OTEL_EXPORTER_"
                    "OTLP_ENDPOINT at ingest.botanu.ai, or unset BOTANU_API_KEY "
                    "if you did not intend to authenticate to botanu.",
                    urlparse(self.otlp_endpoint).hostname or "unknown",
                )

        # Export tuning via env vars
        env_queue_size = os.getenv("BOTANU_MAX_QUEUE_SIZE")
        if env_queue_size:
            try:
                self.max_queue_size = int(env_queue_size)
            except ValueError:
                pass

        env_batch_size = os.getenv("BOTANU_MAX_EXPORT_BATCH_SIZE")
        if env_batch_size:
            try:
                self.max_export_batch_size = int(env_batch_size)
            except ValueError:
                pass

        env_export_timeout = os.getenv("BOTANU_EXPORT_TIMEOUT_MILLIS")
        if env_export_timeout:
            try:
                self.export_timeout_millis = int(env_export_timeout)
            except ValueError:
                pass

        env_content_rate = os.getenv("BOTANU_CONTENT_CAPTURE_RATE")
        if env_content_rate is not None:
            try:
                self.content_capture_rate = max(0.0, min(1.0, float(env_content_rate)))
            except ValueError:
                pass

        env_pii_enabled = os.getenv("BOTANU_PII_SCRUB_ENABLED")
        if env_pii_enabled is not None:
            self.pii_scrub_enabled = env_pii_enabled.lower() in ("true", "1", "yes")

        env_pii_disable = os.getenv("BOTANU_PII_SCRUB_DISABLE_PATTERNS")
        if env_pii_disable is not None:
            self.pii_scrub_disable_patterns = [
                name.strip() for name in env_pii_disable.split(",") if name.strip()
            ]

        env_pii_presidio = os.getenv("BOTANU_PII_SCRUB_USE_PRESIDIO")
        if env_pii_presidio is not None:
            self.pii_scrub_use_presidio = env_pii_presidio.lower() in ("true", "1", "yes")

        env_pii_replacement = os.getenv("BOTANU_PII_SCRUB_REPLACEMENT")
        if env_pii_replacement is not None:
            self.pii_scrub_replacement = env_pii_replacement

    # ------------------------------------------------------------------
    # YAML loading
    # ------------------------------------------------------------------

    @classmethod
    def from_yaml(cls, path: Optional[str] = None) -> BotanuConfig:
        """Load configuration from a YAML file.

        Supports environment variable interpolation using ``${VAR_NAME}`` syntax.

        Args:
            path: Path to YAML config file.

        Raises:
            FileNotFoundError: If config file doesn't exist.
            ValueError: If YAML is malformed.
        """
        if path is None:
            raise FileNotFoundError("No config file path provided")

        resolved = Path(path)
        if not resolved.exists():
            raise FileNotFoundError(f"Config file not found: {resolved}")

        try:
            import yaml  # type: ignore[import-untyped]
        except ImportError as err:
            raise ImportError("PyYAML required for YAML config. Install with: pip install pyyaml") from err

        with open(resolved) as fh:
            raw_content = fh.read()

        content = _interpolate_env_vars(raw_content)

        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError as exc:
            raise ValueError(f"Invalid YAML in {resolved}: {exc}") from exc

        if data is None:
            data = {}

        return cls._from_dict(data, config_file=str(resolved))

    @classmethod
    def from_file_or_env(cls, path: Optional[str] = None) -> BotanuConfig:
        """Load config from file if exists, otherwise use environment variables.

        Search order:
        1. Explicit *path* argument
        2. ``BOTANU_CONFIG_FILE`` env var
        3. ``./botanu.yaml``
        4. ``./config/botanu.yaml``
        5. Falls back to env-only config
        """
        search_paths: List[Path] = []

        if path:
            search_paths.append(Path(path))

        env_path = os.getenv("BOTANU_CONFIG_FILE")
        if env_path:
            search_paths.append(Path(env_path))

        search_paths.extend(
            [
                Path("botanu.yaml"),
                Path("botanu.yml"),
                Path("config/botanu.yaml"),
                Path("config/botanu.yml"),
            ]
        )

        for candidate in search_paths:
            if candidate.exists():
                logger.info("Loading config from: %s", candidate)
                return cls.from_yaml(str(candidate))

        logger.debug("No config file found, using environment variables only")
        return cls()

    @classmethod
    def _from_dict(
        cls,
        data: Dict[str, Any],
        config_file: Optional[str] = None,
    ) -> BotanuConfig:
        """Create config from dictionary (parsed YAML)."""
        service = data.get("service", {})
        otlp = data.get("otlp", {})
        export = data.get("export", {})
        resource = data.get("resource", {})
        eval_cfg = data.get("eval", {})
        pii_cfg = eval_cfg.get("pii", {}) if isinstance(eval_cfg, dict) else {}
        auto_packages = data.get("auto_instrument_packages")

        return cls(
            service_name=service.get("name"),
            service_version=service.get("version"),
            service_namespace=service.get("namespace"),
            deployment_environment=service.get("environment"),
            auto_detect_resources=resource.get("auto_detect", True),
            otlp_endpoint=otlp.get("endpoint"),
            otlp_headers=otlp.get("headers"),
            max_export_batch_size=export.get("batch_size", 512),
            max_queue_size=export.get("queue_size", 65536),
            schedule_delay_millis=export.get("delay_ms", 5000),
            export_timeout_millis=export.get("export_timeout_ms", 30000),
            content_capture_rate=max(0.0, min(1.0, float(eval_cfg.get("content_capture_rate", 0.10)))),
            pii_scrub_enabled=bool(pii_cfg.get("enabled", True)),
            pii_scrub_disable_patterns=pii_cfg.get("disable_patterns"),
            pii_scrub_custom_patterns=pii_cfg.get("custom_patterns"),
            pii_scrub_use_presidio=bool(pii_cfg.get("use_presidio", False)),
            pii_scrub_replacement=str(pii_cfg.get("replacement", "[REDACTED]")),
            auto_instrument_packages=(auto_packages if auto_packages else BotanuConfig().auto_instrument_packages),
            _config_file=config_file,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Export configuration as dictionary. Sensitive header values are redacted."""
        return {
            "service": {
                "name": self.service_name,
                "version": self.service_version,
                "namespace": self.service_namespace,
                "environment": self.deployment_environment,
            },
            "resource": {
                "auto_detect": self.auto_detect_resources,
            },
            "otlp": {
                "endpoint": _redact_url_credentials(self.otlp_endpoint),
                "headers": _redact_headers(self.otlp_headers),
            },
            "export": {
                "batch_size": self.max_export_batch_size,
                "queue_size": self.max_queue_size,
                "delay_ms": self.schedule_delay_millis,
                "export_timeout_ms": self.export_timeout_millis,
            },
            "eval": {
                "content_capture_rate": self.content_capture_rate,
                "pii": {
                    "enabled": self.pii_scrub_enabled,
                    "disable_patterns": self.pii_scrub_disable_patterns,
                    # Don't serialize custom regex bodies — they may be proprietary
                    # business rules the customer doesn't want round-tripped through
                    # logs. Expose only the count.
                    "custom_pattern_count": len(self.pii_scrub_custom_patterns or {}),
                    "use_presidio": self.pii_scrub_use_presidio,
                    "replacement": self.pii_scrub_replacement,
                },
            },
            "auto_instrument_packages": self.auto_instrument_packages,
        }

    def __repr__(self) -> str:
        # Dataclass default __repr__ would print raw otlp_headers (which contain
        # the BOTANU_API_KEY bearer token) and endpoint URLs with embedded
        # credentials. DEBUG logging of config objects would then leak secrets.
        redacted_headers = _redact_headers(self.otlp_headers)
        redacted_endpoint = _redact_url_credentials(self.otlp_endpoint)
        return (
            f"BotanuConfig(service_name={self.service_name!r}, "
            f"deployment_environment={self.deployment_environment!r}, "
            f"otlp_endpoint={redacted_endpoint!r}, "
            f"otlp_headers={redacted_headers!r}, "
            f"content_capture_rate={self.content_capture_rate!r}, "
            f"pii_scrub_enabled={self.pii_scrub_enabled!r}, "
            f"pii_scrub_use_presidio={self.pii_scrub_use_presidio!r})"
        )


def _interpolate_env_vars(content: str) -> str:
    """Interpolate ``${VAR_NAME}`` and ``${VAR_NAME:-default}`` in *content*."""
    pattern = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")

    def _replace(match: re.Match) -> str:  # type: ignore[type-arg]
        var_name = match.group(1)
        default = match.group(2)
        value = os.getenv(var_name)
        if value is not None:
            return value
        if default is not None:
            return default
        return match.group(0)

    return pattern.sub(_replace, content)
