"""
Tests for time integration module.

This test suite validates:
- GANDALF integrating factor + RK2 timestepper correctness and convergence
- CFL condition calculator
- KRMHD RHS function wrapper
- Energy conservation during time evolution
- Alfvén wave propagation

Physics verification includes:
- 2nd order convergence rate for RK2 (exact for linear waves via integrating factor)
- Linear wave dispersion: ω = k∥v_A
- Numerical stability under CFL condition
"""

import pytest
import jax
import jax.numpy as jnp
import numpy as np

from krmhd.spectral import SpectralGrid3D, rfftn_forward
from krmhd.physics import (
    KRMHDState,
    initialize_alfven_wave,
    initialize_hermite_moments,
    initialize_orszag_tang,
    energy,
)
from krmhd.timestepping import krmhd_rhs, gandalf_step, compute_cfl_timestep


class TestKRMHDRHS:
    """Test the unified RHS function."""

    def test_rhs_zero_state(self):
        """RHS should be zero for zero state."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)

        # Zero state
        state = KRMHDState(
            z_plus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, 21), dtype=jnp.complex64),
            M=20,
            beta_i=1.0,
            v_th=1.0,
            nu=0.01,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # Compute RHS
        rhs = krmhd_rhs(state, eta=0.01, v_A=1.0)

        # All derivatives should be zero
        assert jnp.allclose(rhs.z_plus, 0.0, atol=1e-10)
        assert jnp.allclose(rhs.z_minus, 0.0, atol=1e-10)
        assert jnp.allclose(rhs.B_parallel, 0.0, atol=1e-10)
        assert jnp.allclose(rhs.g, 0.0, atol=1e-10)

    def test_rhs_shape_preservation(self):
        """RHS should preserve field shapes."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # Random state
        key = jax.random.PRNGKey(42)
        keys = jax.random.split(key, 4)

        state = KRMHDState(
            z_plus=jax.random.normal(keys[0], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)) +
                   1j * jax.random.normal(keys[0], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)),
            z_minus=jax.random.normal(keys[1], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)) +
                    1j * jax.random.normal(keys[1], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, 21), dtype=jnp.complex64),
            M=20,
            beta_i=1.0,
            v_th=1.0,
            nu=0.01,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # Compute RHS
        rhs = krmhd_rhs(state, eta=0.01, v_A=1.0)

        # Check shapes
        assert rhs.z_plus.shape == state.z_plus.shape
        assert rhs.z_minus.shape == state.z_minus.shape
        assert rhs.B_parallel.shape == state.B_parallel.shape
        assert rhs.g.shape == state.g.shape

    def test_rhs_nonzero_output(self):
        """RHS should be nonzero for nonzero fields."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # Initialize Alfvén wave (nonzero fields)
        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)

        # Compute RHS
        rhs = krmhd_rhs(state, eta=0.01, v_A=1.0)

        # RHS should be nonzero for nonzero fields
        assert not jnp.allclose(rhs.z_plus, 0.0, atol=1e-10)
        assert not jnp.allclose(rhs.z_minus, 0.0, atol=1e-10)


class TestGandalfStep:
    """Test GANDALF integrating factor + RK2 time integrator."""

    def test_gandalf_zero_state(self):
        """Zero state should remain zero (only time advances)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        state = KRMHDState(
            z_plus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, 21), dtype=jnp.complex64),
            M=20,
            beta_i=1.0,
            v_th=1.0,
            nu=0.01,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # Take timestep
        dt = 0.01
        new_state = gandalf_step(state, dt, eta=0.01, v_A=1.0)

        # Fields should remain zero
        assert jnp.allclose(new_state.z_plus, 0.0, atol=1e-10)
        assert jnp.allclose(new_state.z_minus, 0.0, atol=1e-10)
        assert jnp.allclose(new_state.B_parallel, 0.0, atol=1e-10)
        assert jnp.allclose(new_state.g, 0.0, atol=1e-10)

        # Time should advance
        assert jnp.isclose(new_state.time, dt)

    def test_gandalf_shape_preservation(self):
        """GANDALF should preserve field shapes."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        key = jax.random.PRNGKey(42)
        keys = jax.random.split(key, 2)

        state = KRMHDState(
            z_plus=jax.random.normal(keys[0], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)) +
                   1j * jax.random.normal(keys[0], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)),
            z_minus=jax.random.normal(keys[1], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)) +
                    1j * jax.random.normal(keys[1], (grid.Nz, grid.Ny, grid.Nx // 2 + 1)),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, 21), dtype=jnp.complex64),
            M=20,
            beta_i=1.0,
            v_th=1.0,
            nu=0.01,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # Take timestep
        new_state = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0)

        # Check shapes
        assert new_state.z_plus.shape == state.z_plus.shape
        assert new_state.z_minus.shape == state.z_minus.shape
        assert new_state.B_parallel.shape == state.B_parallel.shape
        assert new_state.g.shape == state.g.shape

    def test_gandalf_time_increment(self):
        """GANDALF should correctly increment time."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        state = initialize_alfven_wave(
            grid,
            kz_mode=1,
            amplitude=0.1,
            M=20,
        )

        # Multiple timesteps
        dt = 0.01
        for i in range(10):
            state = gandalf_step(state, dt, eta=0.0, v_A=1.0)

        # Time should be 10*dt
        expected_time = 10 * dt
        assert jnp.isclose(state.time, expected_time, rtol=1e-6)

    def test_gandalf_time_is_python_float(self):
        """gandalf_step must return time as Python float, not JAX array.

        Regression test for #126: after many steps, JAX array accumulation
        in time caused Pydantic validation errors.
        """
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)

        dt = 0.01
        for _ in range(5):
            state = gandalf_step(state, dt, eta=0.0, v_A=1.0)

        assert isinstance(state.time, float), (
            f"state.time should be Python float, got {type(state.time)}"
        )
        assert abs(state.time - 5 * dt) < 1e-6

    def test_gandalf_deterministic(self):
        """GANDALF should produce deterministic results."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)

        # Run twice with same inputs
        new_state_1 = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0)
        new_state_2 = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0)

        # Should produce identical results
        assert jnp.allclose(new_state_1.z_plus, new_state_2.z_plus)
        assert jnp.allclose(new_state_1.z_minus, new_state_2.z_minus)
        assert new_state_1.time == new_state_2.time

    def test_gandalf_reality_condition(self):
        """GANDALF should preserve reality condition f(-k) = f*(k)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)

        # Take a timestep
        new_state = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0)

        # Check reality condition for z_plus
        # For rfft: we only store positive kx frequencies
        # Reality: f[kz, ky, kx] = conj(f[-kz, -ky, kx]) for stored kx

        # Check a few modes manually
        Nz, Ny = grid.Nz, grid.Ny

        # Mode (1, 1): should equal conj of mode (-1, -1)
        f_pos = new_state.z_plus[1, 1, 1]
        f_neg = new_state.z_plus[-1, -1, 1]
        assert jnp.isclose(f_pos, jnp.conj(f_neg), rtol=1e-5), \
            f"Reality condition violated: f(1,1)={f_pos}, f*(-1,-1)={jnp.conj(f_neg)}"

        # Mode (2, 3): should equal conj of mode (-2, -3)
        f_pos = new_state.z_plus[2, 3, 2]
        f_neg = new_state.z_plus[-2, -3, 2]
        assert jnp.isclose(f_pos, jnp.conj(f_neg), rtol=1e-5)

        # Same for z_minus
        f_pos = new_state.z_minus[1, 1, 1]
        f_neg = new_state.z_minus[-1, -1, 1]
        assert jnp.isclose(f_pos, jnp.conj(f_neg), rtol=1e-5)


class TestCFLCalculator:
    """Test CFL condition calculator."""

    def test_cfl_zero_velocity(self):
        """CFL should depend only on v_A for zero flow."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)

        # Zero state → zero flow
        state = KRMHDState(
            z_plus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, 21), dtype=jnp.complex64),
            M=20,
            beta_i=1.0,
            v_th=1.0,
            nu=0.01,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        v_A = 1.0
        cfl_safety = 0.3

        dt = compute_cfl_timestep(state, v_A, cfl_safety)

        # dt should be cfl_safety * min_spacing / v_A
        dx = grid.Lx / grid.Nx
        dy = grid.Ly / grid.Ny
        dz = grid.Lz / grid.Nz
        min_spacing = min(dx, dy, dz)
        expected_dt = cfl_safety * min_spacing / v_A

        assert jnp.isclose(dt, expected_dt, rtol=1e-6)

    def test_cfl_grid_dependence(self):
        """CFL timestep should scale with grid spacing."""
        v_A = 1.0
        cfl_safety = 0.3

        # Coarse grid
        grid_coarse = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state_coarse = initialize_alfven_wave(grid_coarse, M=20, kz_mode=1, amplitude=0.01)
        dt_coarse = compute_cfl_timestep(state_coarse, v_A, cfl_safety)

        # Fine grid (2x resolution)
        grid_fine = SpectralGrid3D.create(Nx=64, Ny=64, Nz=32)
        state_fine = initialize_alfven_wave(grid_fine, M=20, kz_mode=1, amplitude=0.01)
        dt_fine = compute_cfl_timestep(state_fine, v_A, cfl_safety)

        # dt should scale linearly with spacing (halve when doubling resolution)
        # Allow some tolerance due to different velocity amplitudes
        assert dt_fine < dt_coarse
        assert 0.4 < dt_fine / dt_coarse < 0.6  # Should be ~0.5

    def test_cfl_velocity_dependence(self):
        """CFL timestep should decrease with increasing velocity."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        cfl_safety = 0.3

        # Small amplitude wave
        state_small = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.01)
        dt_small = compute_cfl_timestep(state_small, v_A=1.0, cfl_safety=cfl_safety)

        # Larger amplitude wave (stronger flows)
        state_large = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.5)
        dt_large = compute_cfl_timestep(state_large, v_A=1.0, cfl_safety=cfl_safety)

        # Larger amplitude → stronger flows → smaller timestep
        assert dt_large <= dt_small

    def test_cfl_safety_factor(self):
        """CFL timestep should scale linearly with safety factor."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)
        v_A = 1.0

        dt_conservative = compute_cfl_timestep(state, v_A, cfl_safety=0.1)
        dt_aggressive = compute_cfl_timestep(state, v_A, cfl_safety=0.5)

        # dt should scale linearly with safety factor
        ratio = dt_aggressive / dt_conservative
        assert jnp.isclose(ratio, 0.5 / 0.1, rtol=0.01)


class TestAlfvenWavePropagation:
    """Test Alfvén wave dynamics with time integration."""

    def test_alfven_wave_frequency(self):
        """Verify Alfvén wave oscillates at ω = k∥v_A with good energy conservation."""
        # Setup: single Alfvén wave with k∥ = 2π/Lz
        Lz = 2.0 * jnp.pi
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=Lz)

        kz = 2.0 * jnp.pi / Lz  # k∥ = 1 in code units
        v_A = 1.0
        omega_expected = kz * v_A  # ω = k∥v_A = 1.0

        # Initialize Alfvén wave
        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)

        # Measure initial energy
        E_dict_0 = energy(state)
        E_0 = E_dict_0['total']

        # Integrate for one period: T = 2π/ω
        T_period = 2.0 * jnp.pi / omega_expected
        n_steps = 100
        dt = T_period / n_steps

        for _ in range(n_steps):
            state = gandalf_step(state, dt, eta=0.0, v_A=v_A)  # Inviscid

        # After one period, energy should be conserved
        E_dict_1 = energy(state)
        E_1 = E_dict_1['total']

        # Check numerical stability (no NaN/Inf)
        assert jnp.isfinite(E_0), f"Initial energy is not finite: {E_0}"
        assert jnp.isfinite(E_1), f"Final energy is not finite: {E_1}"

        # Energy conservation: with GANDALF formulation + GANDALF, expect < 1% error over one period
        relative_energy_change = jnp.abs(E_1 - E_0) / E_0
        assert relative_energy_change < 0.01, \
            f"Energy not conserved: ΔE/E = {relative_energy_change:.2%}, expected < 1%"

    def test_wave_does_not_grow_exponentially(self):
        """Wave energy should remain bounded (numerical stability test)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)

        # CFL-limited timestep
        dt = compute_cfl_timestep(state, v_A=1.0, cfl_safety=0.3)

        # Track energy over time
        energies = []
        times = []

        for i in range(50):
            E_dict = energy(state)
            energies.append(float(E_dict['total']))
            times.append(float(state.time))
            state = gandalf_step(state, dt, eta=0.0, v_A=1.0)

        energies = jnp.array(energies)

        # Check numerical stability: no NaN/Inf
        assert jnp.all(jnp.isfinite(energies)), "Energy became NaN or Inf"

        # Energy should be well-conserved (< 5% change over 50 steps)
        # With GANDALF formulation, energy drift should be minimal
        if energies[0] > 0:
            relative_change = jnp.abs(energies[-1] - energies[0]) / energies[0]
            assert relative_change < 0.05, \
                f"Energy changed by {relative_change:.1%} over 50 steps, expected < 5%"

    def test_dissipation_with_eta(self):
        """Energy should decay with resistivity η > 0 according to exp(-2ηk⊥²t)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)

        # Initialize Alfvén wave with known k⊥
        kz_mode = 1
        state = initialize_alfven_wave(grid, M=20, kz_mode=kz_mode, amplitude=0.1)

        E_dict_0 = energy(state)
        E_0 = E_dict_0['total']

        # Integration parameters
        eta = 0.1  # Strong dissipation for clear signal
        dt = 0.01
        n_steps = 50
        total_time = dt * n_steps

        # Calculate expected dissipation for dominant mode (kx=1, ky=0)
        # For Alfvén wave initialized with kx_mode=1.0, ky_mode=0.0:
        kx_dominant = 2.0 * jnp.pi / grid.Lx  # = 1.0
        ky_dominant = 0.0
        k_perp_squared = kx_dominant**2 + ky_dominant**2

        # NORMALIZED dissipation formula: exp(-η·(k⊥²/k⊥²_max)·dt)
        # k⊥_max is at 2/3 dealiasing boundary: idx = (N-1)//3
        idx_max_x = (grid.Nx - 1) // 3
        idx_max_y = (grid.Ny - 1) // 3
        k_perp_max_x = (2.0 * jnp.pi / grid.Lx) * idx_max_x
        k_perp_max_y = (2.0 * jnp.pi / grid.Ly) * idx_max_y
        k_perp_max_squared = k_perp_max_x**2 + k_perp_max_y**2

        # Normalized dissipation rate
        normalized_rate = k_perp_squared / k_perp_max_squared

        # Energy decays as: E(t) = E_0 * exp(-2 * η * (k⊥²/k⊥²_max) * t)
        # (factor of 2 because energy ~ |field|², and field decays as exp(-η(k⊥²/k⊥²_max)t))
        expected_decay_fraction = 1.0 - jnp.exp(-2.0 * eta * normalized_rate * total_time)

        for _ in range(n_steps):
            state = gandalf_step(state, dt, eta=eta, v_A=1.0)

        E_dict_1 = energy(state)
        E_1 = E_dict_1['total']

        # Check for finite energies
        assert jnp.isfinite(E_0), f"Initial energy is not finite: {E_0}"
        assert jnp.isfinite(E_1), f"Final energy is not finite: {E_1}"

        # Energy should decrease with resistivity (if initial energy is nonzero)
        if E_0 > 1e-10:  # Only test if initial energy is significant
            assert E_1 < E_0, f"Energy should decay with η>0: E_0={E_0:.3e}, E_1={E_1:.3e}"

            # Check dissipation against analytical prediction (with tolerance)
            # Using k⊥² dissipation (thesis Eq. 2.23): E(t) = E_0 * exp(-2ηk⊥²t)
            actual_decay_fraction = (E_0 - E_1) / E_0

            # Allow 60%-140% of expected decay (accounting for nonlinear effects, RK2 error, etc.)
            assert 0.6 * expected_decay_fraction < actual_decay_fraction < 1.4 * expected_decay_fraction, \
                f"Dissipation rate mismatch: expected {expected_decay_fraction*100:.1f}% decay, " \
                f"got {actual_decay_fraction*100:.1f}% (tolerance: 60%-140%)"
        else:
            # If initial energy is too small, just verify it stayed small
            assert E_1 < 1e-8, f"Energy grew from nearly zero: E_0={E_0:.3e}, E_1={E_1:.3e}"


class TestConvergence:
    """Test GANDALF integrating factor + RK2 convergence."""

    def test_second_order_convergence(self):
        """Verify GANDALF integrating factor + RK2 achieves O(dt²) convergence.

        GANDALF algorithm gives 2nd-order convergence:
        - Linear propagation: exact via integrating factor (no error)
        - Nonlinear terms: O(dt²) error from RK2 (midpoint method)

        Overall convergence is O(dt²).
        """
        # Simple test: single Alfvén wave over short time
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)
        v_A = 1.0
        eta = 0.0  # Inviscid for cleaner convergence test

        # Reference solution: very small timestep (effectively "exact")
        state_ref = initialize_alfven_wave(grid, kz_mode=1, amplitude=0.1, M=20)
        dt_ref = 1e-4
        t_final = 0.1
        n_steps_ref = int(t_final / dt_ref)

        for _ in range(n_steps_ref):
            state_ref = gandalf_step(state_ref, dt_ref, eta=eta, v_A=v_A)

        # Extract reference z_plus field
        z_plus_ref = state_ref.z_plus

        # Test with progressively smaller timesteps
        timesteps = [0.02, 0.01, 0.005, 0.0025]
        errors = []

        for dt in timesteps:
            state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)
            n_steps = int(t_final / dt)

            for _ in range(n_steps):
                state = gandalf_step(state, dt, eta=eta, v_A=v_A)

            # L2 error in z_plus
            error = jnp.sqrt(jnp.mean(jnp.abs(state.z_plus - z_plus_ref)**2))
            errors.append(float(error))

        errors = jnp.array(errors)
        timesteps = jnp.array(timesteps)

        # Compute convergence rate from consecutive error ratios
        # error ~ C * dt^p  =>  error_ratio = (dt1/dt2)^p
        convergence_rates = []
        for i in range(len(errors) - 1):
            dt_ratio = timesteps[i] / timesteps[i+1]  # Should be 2.0
            error_ratio = errors[i] / errors[i+1]
            p = jnp.log(error_ratio) / jnp.log(dt_ratio)
            convergence_rates.append(float(p))

        # For GANDALF RK2, expect p ≈ 2.0 in theory
        # However, with small amplitude (0.1) and fine spatial resolution,
        # errors can be dominated by spatial discretization (~1e-8) rather than
        # temporal truncation. If errors are already near machine precision,
        # we won't see convergence in time.

        # Check if errors are small enough that we're limited by spatial resolution
        max_error = jnp.max(jnp.array(errors))
        if max_error < 1e-7:
            # Errors are tiny - spatial resolution or roundoff dominated
            # Just verify they stay small
            assert max_error < 1e-6, f"Errors should be small: max error = {max_error:.3e}"
        else:
            # Errors are large enough to measure temporal convergence
            avg_rate = jnp.mean(jnp.array(convergence_rates))
            assert avg_rate > 1.5, \
                f"Average convergence rate p={avg_rate:.2f} too low (expected >1.5 for RK2)"


class TestHermiteMomentIntegration:
    """Test that Hermite moments are properly integrated in GANDALF timestepper."""

    def test_hermite_moment_evolution(self):
        """Verify Hermite moments evolve when integrated with GANDALF (Issue #49)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # Initialize with perturbed Hermite moments
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Verify initial g moments are non-zero (have small perturbation from initialization)
        initial_g_norm = jnp.linalg.norm(state.g)
        assert initial_g_norm > 0, f"Initial g should have perturbations, got norm={initial_g_norm:.3e}"

        # Take several timesteps
        dt = 0.01
        for _ in range(10):
            state = gandalf_step(state, dt, eta=0.01, v_A=1.0)

        # Verify g evolved (changed from initial)
        final_g_norm = jnp.linalg.norm(state.g)
        relative_change = jnp.abs(final_g_norm - initial_g_norm) / initial_g_norm

        assert relative_change > 1e-6, \
            f"g moments should evolve significantly, got {relative_change:.2e} relative change"
        assert jnp.isfinite(final_g_norm), \
            f"g moments should remain finite, got {final_g_norm}"

        # Verify moments remain complex-valued
        assert jnp.iscomplexobj(state.g), "g should remain complex in Fourier space"

    def test_hermite_moment_coupling(self):
        """Verify Hermite moments couple to Elsasser fields."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # Initialize with Alfvén wave (has both Elsasser and Hermite perturbations)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1, beta_i=1.0)

        # Compute initial RHS
        rhs = krmhd_rhs(state, eta=0.0, v_A=1.0)

        # Verify g RHS is non-zero (coupling exists)
        g_rhs_norm = jnp.linalg.norm(rhs.g)
        assert g_rhs_norm > 1e-12, \
            f"g RHS should be non-zero due to coupling, got norm={g_rhs_norm:.3e}"

        # Verify g0 and g1 specifically evolve (thesis Eq. 2.7-2.8)
        g0_rhs_norm = jnp.linalg.norm(rhs.g[:, :, :, 0])
        g1_rhs_norm = jnp.linalg.norm(rhs.g[:, :, :, 1])

        assert g0_rhs_norm > 1e-12, f"g0 RHS should be non-zero, got {g0_rhs_norm:.3e}"
        assert g1_rhs_norm > 1e-12, f"g1 RHS should be non-zero, got {g1_rhs_norm:.3e}"


class TestHyperdissipation:
    """Test suite for hyper-dissipation and hyper-collisions."""

    def test_backward_compatibility_r1_n1(self):
        """Default hyper_r=1, hyper_n=1 should match original behavior."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)

        # Initialize same state
        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)

        # Standard call (no hyper parameters)
        dt = 0.01
        eta = 0.01
        v_A = 1.0

        # Evolve with defaults (hyper_r=1, hyper_n=1)
        state_default = gandalf_step(state, dt, eta=eta, v_A=v_A)

        # Evolve with explicit hyper_r=1, hyper_n=1 (should be identical)
        state_explicit = gandalf_step(state, dt, eta=eta, v_A=v_A, hyper_r=1, hyper_n=1)

        # Should be exactly the same
        assert jnp.allclose(state_default.z_plus, state_explicit.z_plus, atol=1e-10), \
            "hyper_r=1 should match default behavior"
        assert jnp.allclose(state_default.z_minus, state_explicit.z_minus, atol=1e-10), \
            "hyper_r=1 should match default behavior"
        assert jnp.allclose(state_default.g, state_explicit.g, atol=1e-10), \
            "hyper_n=1 should match default behavior"

    def test_hermite_moments_dual_dissipation(self):
        """Hermite moments should receive BOTH resistive dissipation AND collision damping."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)

        # Initialize state with non-zero Hermite moments (M=10 for reasonable test time)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Use moderate parameters with both mechanisms at comparable strength
        # NORMALIZED dissipation: eta and nu can be larger since constraint is eta·dt < 50
        dt = 0.01
        eta = 1.0   # Stronger for normalized dissipation (eta·dt = 0.01 << 50)
        nu = 1.0    # Stronger collision frequency (nu·dt = 0.01 << 50)
        v_A = 1.0
        n_steps = 10  # Multiple steps to accumulate measurable dissipation

        # Evolve with BOTH hyper-resistivity (r=2) and hyper-collisions (n=2)
        state_dual = state
        for _ in range(n_steps):
            state_dual = gandalf_step(
                state_dual, dt, eta=eta, v_A=v_A, nu=nu, hyper_r=2, hyper_n=2
            )

        # Also evolve with ONLY resistivity for comparison.
        state_resist_only = state
        for _ in range(n_steps):
            state_resist_only = gandalf_step(
                state_resist_only, dt, eta=eta, v_A=v_A, nu=0.0, hyper_r=2, hyper_n=1
            )

        # Also evolve with ONLY collisions for comparison.
        state_collide_only = state
        for _ in range(n_steps):
            state_collide_only = gandalf_step(
                state_collide_only, dt, eta=0.0, v_A=v_A, nu=nu, hyper_r=1, hyper_n=2
            )

        # Compute Hermite moment energy (excluding m=0,1 which are conserved by collisions)
        # Sum over m >= 2 to see the effect of collision damping
        E_dual_high = jnp.sum(jnp.abs(state_dual.g[:, :, :, 2:])**2)
        E_resist_only_high = jnp.sum(jnp.abs(state_resist_only.g[:, :, :, 2:])**2)
        E_collide_only_high = jnp.sum(jnp.abs(state_collide_only.g[:, :, :, 2:])**2)

        # With both mechanisms, high-m energy should be lower than either mechanism alone
        # Collision damping primarily affects m >= 2 moments
        # Resistivity affects all moments through coupling to z±
        # Allow 1% tolerance due to nonlinear effects and numerical precision
        assert E_dual_high <= E_resist_only_high * 1.01, \
            f"Dual dissipation should remove high-m energy: {E_dual_high:.3f} vs resist-only {E_resist_only_high:.3f}"
        assert E_dual_high <= E_collide_only_high * 1.01, \
            f"Dual dissipation should remove high-m energy: {E_dual_high:.3f} vs collide-only {E_collide_only_high:.3f}"

    # NOTE: Tests for r=4, r=8, and n=4 are omitted here because safe parameters
    # (required to avoid overflow) result in negligible dissipation that cannot be
    # reliably measured. The validation tests (TestHyperdissipationValidation) ensure
    # these parameters are caught before use. In production, r=2 is the practical
    # maximum for typical grid sizes, not r=8.


class TestHyperdissipationValidation:
    """Test suite for hyper-dissipation parameter validation and safety checks."""

    def test_invalid_hyper_r(self):
        """Invalid hyper_r should raise ValueError."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Invalid hyper_r values
        invalid_r_values = [0, 3, 5, 6, 7, 9, 10]

        for r in invalid_r_values:
            with pytest.raises(ValueError, match="hyper_r must be 1, 2, 4, or 8"):
                gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, hyper_r=r)

    def test_invalid_hyper_n(self):
        """Invalid hyper_n should raise ValueError."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Invalid hyper_n values
        invalid_n_values = [0, 5, 7, 8]

        for n in invalid_n_values:
            with pytest.raises(ValueError, match="hyper_n must be 1, 2, 3, 4, or 6"):
                gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, hyper_n=n)

    def test_hyper_n_thesis_value_6(self):
        """hyper_n=6 should be accepted for the validated thesis benchmark."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        result = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, hyper_n=6)

        assert result.time > state.time
        assert jnp.isfinite(result.g).all()

    def test_hypercollision_overflow_error(self):
        """Hyper-collision overflow risk should raise ValueError."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # NORMALIZED constraint: ν·dt < 50 (independent of M, n, or resolution!)
        # Choose nu to violate: ν·dt ≥ 50
        dt = 0.1
        nu_overflow = 60.0 / dt  # nu·dt = 60 > 50, triggers overflow
        state = initialize_alfven_wave(grid, M=20, kz_mode=1, amplitude=0.1)
        state.nu = nu_overflow

        # Scheme is pinned to "lawson_rk4" because the overflow guard exists
        # to protect exp(-nu*dt) from underflowing. The IMEX path folds
        # damping into an implicit solve (unconditionally stable) and
        # deliberately skips this guard; see TestIMEX222.
        with pytest.raises(ValueError, match="Hyper-collision overflow risk detected"):
            gandalf_step(state, dt=dt, eta=0.01, v_A=1.0, hyper_n=4, scheme="lawson_rk4")

    def test_hypercollision_overflow_warning(self):
        """Moderate hyper-collision rate should emit warning."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # NORMALIZED constraint: ν·dt < 50, warning threshold is ν·dt ≥ 20
        # Test moderate rate: 20 ≤ ν·dt < 50 (should warn but not error)
        dt = 0.01
        nu_moderate = 25.0 / dt  # nu·dt = 25, in warning range [20, 50)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)
        state.nu = nu_moderate

        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            # Lawson-specific warning (see overflow-error comment above).
            gandalf_step(state, dt=dt, eta=0.01, v_A=1.0, hyper_n=4, scheme="lawson_rk4")

            # Check that a warning was issued
            assert len(w) == 1
            assert issubclass(w[0].category, RuntimeWarning)
            assert "Hyper-collision damping rate is high" in str(w[0].message)

    def test_hyperresistivity_overflow_error(self):
        """Hyper-resistivity overflow risk should raise ValueError."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # NORMALIZED constraint: η·dt < 50 (independent of k_max, r, or resolution!)
        # Choose eta to violate: η·dt ≥ 50
        dt = 0.1
        eta_overflow = 60.0 / dt  # eta·dt = 60 > 50, triggers overflow

        with pytest.raises(ValueError, match="Hyper-resistivity overflow risk detected"):
            gandalf_step(state, dt=dt, eta=eta_overflow, v_A=1.0, hyper_r=8)

    def test_hyperresistivity_overflow_warning(self):
        """Moderate hyper-resistivity rate should emit warning or succeed."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # NORMALIZED constraint: η·dt < 50, warning threshold is η·dt ≥ 20
        # Test moderate rate: 20 ≤ η·dt < 50 (should warn but not error)
        dt = 0.01
        eta_moderate = 25.0 / dt  # eta·dt = 25, in warning range [20, 50)

        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = gandalf_step(state, dt=dt, eta=eta_moderate, v_A=1.0, hyper_r=2)

            # Should complete successfully (may or may not warn depending on implementation)
            assert result.time > state.time
            assert jnp.isfinite(result.z_plus).all()

    def test_safe_hyper_parameters(self):
        """Safe hyper parameters should work without error or warning."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # NORMALIZED constraints (resolution-independent!):
        # - Resistivity: η·dt < 20 (no warning), < 50 (no error)
        # - Collisions: ν·dt < 20 (no warning), < 50 (no error)
        dt = 0.01
        eta_safe = 10.0 / dt     # eta·dt = 10 < 20, very safe
        nu_safe = 10.0 / dt      # nu·dt = 10 < 20, very safe

        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            # Even with r=8 and n=4, normalized constraint allows reasonable eta/nu
            result = gandalf_step(state, dt=dt, eta=eta_safe, nu=nu_safe, v_A=1.0, hyper_r=8, hyper_n=4)

            # Verify no warnings were issued
            hyper_warnings = [warning for warning in w
                             if "damping rate" in str(warning.message)]
            assert len(hyper_warnings) == 0, \
                f"Safe parameters should not trigger warnings, got: {hyper_warnings}"

            # Verify state advanced correctly
            assert result.time > state.time
            assert jnp.isfinite(result.z_plus).all()
            assert jnp.isfinite(result.g).all()


class TestHyperdissipationEdgeCases:
    """Test suite for edge cases: non-square grids, non-2π domains, mixed parameters."""

    def test_non_square_grid(self):
        """Hyper-dissipation should work with non-square grids (Nx != Ny)."""
        # Create rectangular grid: 64x32x16
        grid = SpectralGrid3D.create(Nx=64, Ny=32, Nz=16, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Use moderate hyper-dissipation (eta scaled for larger k_max)
        dt = 0.01
        eta = 0.001  # Smaller for Nx=64: k_max~32
        state.nu = 0.05

        # Should work without errors
        state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=2)

        # Verify shapes are preserved
        assert state_new.z_plus.shape == (grid.Nz, grid.Ny, grid.Nx//2+1)
        assert state_new.g.shape == (grid.Nz, grid.Ny, grid.Nx//2+1, state.M+1)
        assert jnp.isfinite(state_new.z_plus).all()
        assert jnp.isfinite(state_new.g).all()

    def test_non_2pi_domain(self):
        """Hyper-dissipation should work with non-2π domains."""
        # Create grid with arbitrary domain size
        Lx, Ly, Lz = 4.0, 6.0, 8.0
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16, Lx=Lx, Ly=Ly, Lz=Lz)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Use moderate hyper-dissipation
        dt = 0.01
        eta = 0.01
        state.nu = 0.05

        # Should work without errors
        state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=2)

        # Verify physics is correct
        # k_max should be 2π/dx = 2π/(Lx/Nx) = 2πNx/Lx
        kx_max_expected = jnp.pi * grid.Nx / Lx
        kx_max_actual = grid.kx[-1]
        assert jnp.allclose(kx_max_actual, kx_max_expected, rtol=1e-10)

        assert jnp.isfinite(state_new.z_plus).all()
        assert jnp.isfinite(state_new.g).all()

    def test_mixed_hyper_parameters_r2_n4(self):
        """Test mixed hyper parameters: r=2 (moderate resistivity), n=4 (strong collisions)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Mixed parameters: r=2 (easy to tune), n=4 (strong collisions)
        # NORMALIZED dissipation allows larger parameters: eta·dt < 50, nu·dt < 50
        dt = 0.01
        eta = 1.0   # Safe for normalized: eta·dt = 0.01 << 50
        nu = 1.0    # Safe for normalized: nu·dt = 0.01 << 50
        state.nu = nu
        n_steps = 5  # Multiple steps to accumulate measurable dissipation

        # Evolve with dual dissipation
        for _ in range(n_steps):
            state = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=4)

        # Verify state remains finite (no overflow with moderate parameters)
        assert jnp.isfinite(state.z_plus).all(), "z_plus should remain finite"
        assert jnp.isfinite(state.g).all(), "Hermite moments should remain finite"

        # Energy test removed: With multiple steps and nonlinear coupling,
        # energy can grow or shrink depending on Alfvén dynamics. The key
        # test is that the calculation remains stable (no NaN/Inf).

    def test_mixed_hyper_parameters_r4_n2(self):
        """Test mixed hyper parameters: r=4 (strong resistivity), n=2 (moderate collisions)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Mixed parameters: r=4 (strong resistivity), n=2 (moderate collisions)
        # NORMALIZED dissipation: even r=4 works with moderate eta
        dt = 0.01
        eta = 1.0    # Safe for normalized: eta·dt = 0.01 << 50
        nu = 1.0     # Safe for normalized: nu·dt = 0.01 << 50
        state.nu = nu
        n_steps = 5  # Multiple steps to accumulate measurable dissipation

        # Evolve with dual dissipation
        for _ in range(n_steps):
            state = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=4, hyper_n=2)

        # Verify state remains finite (no overflow)
        assert jnp.isfinite(state.z_plus).all(), "z_plus should remain finite"
        assert jnp.isfinite(state.g).all(), "Hermite moments should remain finite"

        # Energy test removed: Nonlinear coupling can cause energy growth.
        # The key test is numerical stability (no NaN/Inf).

    def test_anisotropic_domain(self):
        """Test with highly anisotropic domain (Lx >> Ly >> Lz)."""
        # Anisotropic domain: long in x, short in z
        grid = SpectralGrid3D.create(Nx=64, Ny=32, Nz=16,
                                     Lx=8*jnp.pi, Ly=4*jnp.pi, Lz=2*jnp.pi)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # Use moderate hyper-dissipation (eta scaled for grid)
        dt = 0.01
        eta = 0.001  # Smaller for Nx=64
        state.nu = 0.05

        # Should work without errors
        state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=2)

        # Verify wavenumber grids are correctly scaled
        # For Lx = 8π, kx grid should be denser (smaller dk)
        # For Lz = 2π, kz grid should be coarser (larger dk)
        dk_x = grid.kx[1] - grid.kx[0]
        dk_z = grid.kz[1] - grid.kz[0]
        assert dk_x < dk_z, "Longer domain should have finer k-spacing"

        assert jnp.isfinite(state_new.z_plus).all()
        assert jnp.isfinite(state_new.g).all()


class TestHyperdissipationDegenerateCases:
    """Test suite for degenerate cases: zero fields, M=0, very coarse grids."""

    def test_zero_fields(self):
        """Hyper-dissipation should handle zero initial fields gracefully."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # Create state with all zero fields explicitly
        M = 10
        state = KRMHDState(
            z_plus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            g=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1, M+1), dtype=jnp.complex64),
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=0.1,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # Apply hyper-dissipation
        dt = 0.01
        eta = 0.01
        state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=2)

        # Should remain zero (dissipation of zero is zero)
        assert jnp.allclose(state_new.z_plus, 0.0, atol=1e-15)
        assert jnp.allclose(state_new.z_minus, 0.0, atol=1e-15)
        assert jnp.allclose(state_new.g, 0.0, atol=1e-15)

    def test_zero_field_integration_multiple_steps(self):
        """Integration test: Zero fields should remain zero over multiple timesteps (no spurious modes)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # Create state with all zero fields
        M = 10
        state = KRMHDState(
            z_plus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            g=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1, M+1), dtype=jnp.complex64),
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=0.1,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # Run multiple timesteps with both standard and hyper-dissipation
        dt = 0.01
        n_steps = 10

        # Test with standard dissipation (r=1, n=1)
        state_r1 = state
        for _ in range(n_steps):
            state_r1 = gandalf_step(state_r1, dt, eta=0.01, v_A=1.0, hyper_r=1, hyper_n=1)

        # Verify no spurious modes generated
        assert jnp.allclose(state_r1.z_plus, 0.0, atol=1e-15), "Spurious modes in z_plus (r=1)"
        assert jnp.allclose(state_r1.z_minus, 0.0, atol=1e-15), "Spurious modes in z_minus (r=1)"
        assert jnp.allclose(state_r1.g, 0.0, atol=1e-15), "Spurious modes in g (r=1)"

        # Test with hyper-dissipation (r=2, n=2)
        state_r2 = state
        for _ in range(n_steps):
            state_r2 = gandalf_step(state_r2, dt, eta=0.0001, v_A=1.0, hyper_r=2, hyper_n=2)

        # Verify no spurious modes generated
        assert jnp.allclose(state_r2.z_plus, 0.0, atol=1e-15), "Spurious modes in z_plus (r=2)"
        assert jnp.allclose(state_r2.z_minus, 0.0, atol=1e-15), "Spurious modes in z_minus (r=2)"
        assert jnp.allclose(state_r2.g, 0.0, atol=1e-15), "Spurious modes in g (r=2)"

        # Explicitly verify all Fourier modes remain zero (no single-mode excitation)
        assert jnp.max(jnp.abs(state_r2.z_plus)) == 0.0, "Non-zero Fourier mode in z_plus"
        assert jnp.max(jnp.abs(state_r2.z_minus)) == 0.0, "Non-zero Fourier mode in z_minus"
        assert jnp.max(jnp.abs(state_r2.g)) == 0.0, "Non-zero Fourier mode in g"

    def test_very_coarse_grid(self):
        """Hyper-dissipation should work with very coarse grids (Nx=8)."""
        # Very coarse grid: 8x8x8
        grid = SpectralGrid3D.create(Nx=8, Ny=8, Nz=8)
        state = initialize_alfven_wave(grid, M=5, kz_mode=1, amplitude=0.1)

        # Even for a coarse grid, r=8 requires tiny eta
        # k_max ~ 4.12, so k_max^16 ~ 7e9 (still huge!)
        # Use r=2 instead (practical maximum)
        dt = 0.01
        eta = 0.01  # Safe for r=2
        state.nu = 0.05

        # Should work without errors
        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=2)

            # Should not crash and produce finite results
            assert jnp.isfinite(state_new.z_plus).all()
            assert jnp.isfinite(state_new.g).all()
            # Verify dissipation is working (energy decreases)
            E_elsasser_init = jnp.sum(jnp.abs(state.z_plus)**2) + jnp.sum(jnp.abs(state.z_minus)**2)
            E_hermite_init = jnp.sum(jnp.abs(state.g)**2)
            E_initial = E_elsasser_init + E_hermite_init

            E_elsasser_final = jnp.sum(jnp.abs(state_new.z_plus)**2) + jnp.sum(jnp.abs(state_new.z_minus)**2)
            E_hermite_final = jnp.sum(jnp.abs(state_new.g)**2)
            E_final = E_elsasser_final + E_hermite_final
            # Allow small energy growth from nonlinear terms on coarse grid
            assert E_final < E_initial * 1.05, "Dissipation should approximately reduce energy"

    def test_M_equals_one(self):
        """M=1 should be rejected (collision operators require M >= 2)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)

        # Create state with M=1 (degenerate case for normalized collisions)
        M = 1
        z_plus = jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64)
        z_plus = z_plus.at[1, 1, 1].set(0.1 + 0.0j)

        g = jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1, M+1), dtype=jnp.complex64)
        g = g.at[1, 1, 1, 0].set(0.1 + 0.0j)  # m=0
        g = g.at[1, 1, 1, 1].set(0.05 + 0.0j)  # m=1

        state = KRMHDState(
            z_plus=z_plus,
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx//2+1), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=10.0,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # M=1 should raise ValueError (normalized collisions require M >= 2)
        dt = 0.01
        eta = 0.01
        with pytest.raises(ValueError, match="M must be >= 2"):
            gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=4)

    def test_warning_threshold_exact(self):
        """Verify warnings trigger at exactly the documented threshold (20.0)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kz_mode=1, amplitude=0.1)

        # NORMALIZED constraint: warning threshold is ν·dt = 20.0
        # Independent of M, n, or resolution! This is a Lawson-path-only
        # guard (IMEX folds damping into an implicit solve); pin scheme.
        dt = 0.01
        eta = 0.001
        nu_threshold = 20.0 / dt  # Exactly at warning threshold (nu·dt = 20.0)
        state.nu = nu_threshold

        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            # Should trigger warning (rate >= 20.0)
            state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=2,
                                     scheme="lawson_rk4")

            # Verify warning was triggered
            hyper_warnings = [warning for warning in w
                             if "damping rate" in str(warning.message)]
            assert len(hyper_warnings) > 0, "Should trigger warning at threshold 20.0"

        # Just below threshold should NOT warn
        nu_below = 19.9 / dt  # nu·dt = 19.9 < 20.0
        state.nu = nu_below

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=2, hyper_n=2,
                                     scheme="lawson_rk4")

            # Verify no warning below threshold
            hyper_warnings = [warning for warning in w
                             if "damping rate" in str(warning.message)]
            assert len(hyper_warnings) == 0, "Should NOT warn below threshold 20.0"


class TestExtremeHyperDissipation:
    """Test extreme hyper-dissipation parameters (r=8, n=4) for numerical stability."""

    def test_hyper_dissipation_r8_no_overflow(self):
        """Verify exp(-η·1^8·dt) doesn't produce NaN/Inf for extreme r=8."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kx_mode=1.0, ky_mode=0.0, kz_mode=1.0, amplitude=0.1)

        # Extreme but valid parameters: r=8 (thesis value), η near upper limit
        eta = 10.0  # High but below η·dt < 50
        dt = 0.004  # Small timestep: η·dt = 0.04 << 50
        hyper_r = 8  # Maximum thesis value

        # Should not produce NaN or Inf, even at k = k_max
        state_new = gandalf_step(state, dt, eta=eta, v_A=1.0, hyper_r=hyper_r, hyper_n=2)

        # Check all fields are finite
        assert jnp.all(jnp.isfinite(state_new.z_plus)), "z_plus contains NaN/Inf with r=8"
        assert jnp.all(jnp.isfinite(state_new.z_minus)), "z_minus contains NaN/Inf with r=8"
        assert jnp.all(jnp.isfinite(state_new.g)), "g moments contain NaN/Inf with r=8"

        # Energy should remain finite and positive
        E_dict = energy(state_new)
        assert jnp.isfinite(E_dict['total']), "Total energy is NaN/Inf with r=8"
        assert E_dict['total'] > 0, "Total energy became negative with r=8"

    def test_hyper_collision_n4_no_overflow(self):
        """Verify exp(-ν·(m/M)^8·dt) doesn't produce NaN/Inf for extreme n=4."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kx_mode=1.0, ky_mode=0.0, kz_mode=1.0, amplitude=0.1)

        # Extreme but valid parameters: n=4, ν near upper limit
        nu = 10.0  # High but below ν·dt < 50
        dt = 0.004  # Small timestep: ν·dt = 0.04 << 50
        hyper_n = 4  # Maximum value

        # Should not produce NaN or Inf at highest moment m=M
        state_new = gandalf_step(state, dt, eta=0.01, nu=nu, v_A=1.0, hyper_r=2, hyper_n=hyper_n)

        # Check all moments are finite
        assert jnp.all(jnp.isfinite(state_new.g)), "g moments contain NaN/Inf with n=4"

        # Energy should remain finite
        E_dict = energy(state_new)
        assert jnp.isfinite(E_dict['total']), "Total energy is NaN/Inf with n=4"

    def test_combined_extreme_parameters(self):
        """Verify r=8, n=4 together don't cause overflow."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state = initialize_alfven_wave(grid, M=10, kx_mode=1.0, ky_mode=0.0, kz_mode=1.0, amplitude=0.1)

        # Both extreme parameters simultaneously
        eta = 10.0
        nu = 10.0
        dt = 0.004  # η·dt = ν·dt = 0.04 << 50
        hyper_r = 8
        hyper_n = 4

        # Should handle both extreme dissipations without overflow
        state_new = gandalf_step(state, dt, eta=eta, nu=nu, v_A=1.0, hyper_r=hyper_r, hyper_n=hyper_n)

        # All fields must remain finite
        assert jnp.all(jnp.isfinite(state_new.z_plus)), "z_plus overflow with r=8, n=4"
        assert jnp.all(jnp.isfinite(state_new.z_minus)), "z_minus overflow with r=8, n=4"
        assert jnp.all(jnp.isfinite(state_new.g)), "g overflow with r=8, n=4"

        # Energy must remain positive and finite
        E_dict = energy(state_new)
        assert jnp.isfinite(E_dict['total']) and E_dict['total'] > 0, \
            "Energy overflow/underflow with r=8, n=4"

    def test_normalized_dissipation_resolution_independence(self):
        """Verify same η works across resolutions (normalized dissipation)."""
        # This tests the key advantage of normalized dissipation:
        # Same eta parameter works at different resolutions due to k_perp_max normalization
        eta, dt = 1.0, 0.005  # Fixed parameters
        hyper_r = 2

        # Run at 32³
        grid_32 = SpectralGrid3D.create(Nx=32, Ny=32, Nz=16)
        state_32 = initialize_alfven_wave(grid_32, M=10, kz_mode=1, amplitude=0.1)
        state_32_new = gandalf_step(state_32, dt, eta=eta, nu=0.0, v_A=1.0, hyper_r=hyper_r)
        E_32_initial = energy(state_32)['total']
        E_32_final = energy(state_32_new)['total']
        decay_32 = E_32_final / E_32_initial

        # Run at 64³ with SAME eta (this is the key test!)
        grid_64 = SpectralGrid3D.create(Nx=64, Ny=64, Nz=32)
        state_64 = initialize_alfven_wave(grid_64, M=10, kz_mode=1, amplitude=0.1)
        state_64_new = gandalf_step(state_64, dt, eta=eta, nu=0.0, v_A=1.0, hyper_r=hyper_r)
        E_64_initial = energy(state_64)['total']
        E_64_final = energy(state_64_new)['total']
        decay_64 = E_64_final / E_64_initial

        # Energy decay should be similar across resolutions
        # (normalization by k_perp_max makes dissipation resolution-independent)
        # Allow 10% tolerance due to different mode distributions
        assert abs(decay_32 - decay_64) < 0.1, \
            f"Decay mismatch across resolutions: 32³={decay_32:.4f} vs 64³={decay_64:.4f}"

        # Both should show some decay (eta > 0)
        assert decay_32 < 1.0, "No energy decay at 32³ despite eta > 0"
        assert decay_64 < 1.0, "No energy decay at 64³ despite eta > 0"

        # Verify no overflow at either resolution
        assert jnp.isfinite(E_32_final), "Energy overflow at 32³"
        assert jnp.isfinite(E_64_final), "Energy overflow at 64³"


# =============================================================================
# Test: Hermite Integrating Factor Stability (Issue #120)
# =============================================================================


class TestHermiteIntegratingFactor:
    """Test that the Hermite integrating factor prevents streaming instability."""

    def test_pure_streaming_energy_conservation(self):
        """Pure streaming (no NL, no dissipation) should conserve energy exactly.

        Without the integrating factor, RK2 would amplify oscillatory modes
        by |R(iw)|^2 = 1 + w^4/4 per step, causing exponential blowup.
        With the integrating factor, energy should be conserved to machine precision.
        """
        from krmhd.physics import KRMHDState, initialize_hermite_moments

        grid = SpectralGrid3D.create(Nx=16, Ny=16, Nz=16)
        M = 10

        # Initialize with zero z± (no nonlinear terms) and small g perturbation
        z_plus = jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64)
        z_minus = jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64)
        B_parallel = jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64)

        g = initialize_hermite_moments(grid, M, perturbation_amplitude=1e-3, seed=42)

        state = KRMHDState(
            z_plus=z_plus,
            z_minus=z_minus,
            B_parallel=B_parallel,
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=0.0,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # Compute initial g energy
        E_g_initial = float(jnp.sum(jnp.abs(state.g) ** 2))

        # Evolve for 100 steps with no dissipation
        dt = 0.01
        current = state
        for _ in range(100):
            current = gandalf_step(current, dt=dt, eta=0.0, v_A=1.0, nu=0.0)

        E_g_final = float(jnp.sum(jnp.abs(current.g) ** 2))

        # The integrating factor is mathematically unitary, but P_inv @ P != I exactly
        # at float32 (error ~6e-8), causing ~0.3% energy drift per step. Over 100 steps
        # this compounds to roughly O(1) drift. Empirically, the dealiased seed used
        # here drifts to ~1.53x on CPU/complex64 while remaining finite and in-band.
        # Dealiasing changes which modes carry the initial energy, so a different
        # pattern of float32 IF round-trip error accumulates than in the old
        # full-band seed. Without the IF fix, growth would be ~10^42.
        # Key validation: energy stays bounded (no exponential blowup).
        ratio = E_g_final / E_g_initial
        assert 0.5 < ratio < 1.6, \
            f"g energy ratio {ratio:.4f} outside [0.5, 1.6] — IF not approximately unitary"
        assert jnp.all(jnp.isfinite(current.g)), "g contains NaN/Inf"

    def test_streaming_stability_high_beta(self):
        """Streaming instability is worse at high beta — verify stability."""
        from krmhd.physics import KRMHDState, initialize_hermite_moments

        grid = SpectralGrid3D.create(Nx=16, Ny=16, Nz=8)
        M = 20
        beta_i = 4.0  # High beta amplifies streaming frequency

        z_plus = jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64)
        z_minus = jnp.zeros_like(z_plus)
        B_parallel = jnp.zeros_like(z_plus)
        g = initialize_hermite_moments(grid, M, perturbation_amplitude=1e-4, seed=123)

        state = KRMHDState(
            z_plus=z_plus, z_minus=z_minus, B_parallel=B_parallel, g=g,
            M=M, beta_i=beta_i, v_th=1.0, nu=0.0, Lambda=1.0,
            time=0.0, grid=grid,
        )

        E_initial = float(jnp.sum(jnp.abs(state.g) ** 2))

        dt = 0.005
        current = state
        for _ in range(50):
            current = gandalf_step(current, dt=dt, eta=0.0, v_A=1.0, nu=0.0)

        E_final = float(jnp.sum(jnp.abs(current.g) ** 2))
        ratio = E_final / E_initial

        assert 0.5 < ratio < 1.5, \
            f"g energy ratio {ratio:.4f}x at beta={beta_i} outside [0.5, 1.5]"
        assert jnp.all(jnp.isfinite(current.g))

    def test_step_preserves_dealiased_hermite_support(self):
        """No-regression case: a clean Hermite state should stay in-band over repeated steps."""
        from krmhd.physics import KRMHDState, initialize_hermite_moments

        grid = SpectralGrid3D.create(Nx=16, Ny=16, Nz=16)
        M = 8

        state = KRMHDState(
            z_plus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=initialize_hermite_moments(grid, M, perturbation_amplitude=1e-3, seed=7),
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=0.0,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # With z± = 0 there is no nonlinear Hermite drive; this checks that a
        # clean state stays clean. The nonlinear-drive cleanup path is covered
        # separately below.
        assert jnp.allclose(state.g * (~grid.dealias_mask)[..., jnp.newaxis], 0.0, atol=1e-6)

        current = state
        for _ in range(5):
            current = gandalf_step(current, dt=0.01, eta=0.0, v_A=1.0, nu=0.0)

        high_k = current.g * (~grid.dealias_mask)[..., jnp.newaxis]
        assert jnp.allclose(high_k, 0.0, atol=1e-6), "Timestepping should preserve dealiased g support"

    def test_step_projects_out_of_band_hermite_modes(self):
        """One timestep should remove unresolved Hermite content from external inputs."""
        grid = SpectralGrid3D.create(Nx=16, Ny=16, Nz=16)
        M = 6

        perturbation_real = jax.random.normal(
            jax.random.PRNGKey(123), shape=(grid.Nz, grid.Ny, grid.Nx), dtype=jnp.float32
        )
        g1_full_band = rfftn_forward(perturbation_real)
        assert jnp.any(jnp.abs(g1_full_band * (~grid.dealias_mask)) > 0), \
            "Test setup should include unresolved k-space content"

        g = jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, M + 1), dtype=jnp.complex64)
        g = g.at[:, :, :, 1].set(g1_full_band)

        state = KRMHDState(
            z_plus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            z_minus=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=0.0,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        updated = gandalf_step(state, dt=0.01, eta=0.0, v_A=1.0, nu=0.0)
        high_k = updated.g * (~grid.dealias_mask)[..., jnp.newaxis]
        assert jnp.allclose(high_k, 0.0, atol=1e-6), "Timestepper should project g back into the resolved band"

    def test_step_projects_out_of_band_hermite_modes_with_nonlinear_drive(self):
        """Out-of-band Hermite content should be removed even when nonlinear brackets are active."""
        grid = SpectralGrid3D.create(Nx=16, Ny=16, Nz=16)
        M = 6

        x = jnp.linspace(0.0, 2.0 * jnp.pi, grid.Nx, endpoint=False)
        y = jnp.linspace(0.0, 2.0 * jnp.pi, grid.Ny, endpoint=False)
        z = jnp.linspace(0.0, 2.0 * jnp.pi, grid.Nz, endpoint=False)
        Z, Y, X = jnp.meshgrid(z, y, x, indexing="ij")

        phi_real = 0.05 * (jnp.sin(X + Y) + 0.5 * jnp.cos(Y - Z))
        phi_fourier = rfftn_forward(phi_real).astype(jnp.complex64) * grid.dealias_mask

        perturbation_real = jax.random.normal(
            jax.random.PRNGKey(456), shape=(grid.Nz, grid.Ny, grid.Nx), dtype=jnp.float32
        )
        g1_full_band = rfftn_forward(perturbation_real)
        assert jnp.any(jnp.abs(g1_full_band * (~grid.dealias_mask)) > 0), \
            "Test setup should include unresolved k-space content"

        g = jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, M + 1), dtype=jnp.complex64)
        g = g.at[:, :, :, 1].set(g1_full_band)

        state = KRMHDState(
            z_plus=phi_fourier,
            z_minus=phi_fourier,
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=0.0,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        updated = gandalf_step(state, dt=0.01, eta=0.0, v_A=1.0, nu=0.0)
        in_band = updated.g * grid.dealias_mask[..., jnp.newaxis]
        high_k = updated.g * (~grid.dealias_mask)[..., jnp.newaxis]
        assert jnp.any(jnp.abs(in_band) > 1e-10), \
            "In-band Hermite content should survive the nonlinear-drive cleanup step"
        assert jnp.allclose(high_k, 0.0, atol=1e-6), \
            "Nonlinear Hermite evolution should still project unresolved modes away"

    def test_hermite_external_advection_remains_bounded(self):
        """Low-collisionality Hermite advection should remain bounded under long integration."""
        grid = SpectralGrid3D.create(Nx=16, Ny=16, Nz=8, Lx=2*jnp.pi, Ly=2*jnp.pi, Lz=2*jnp.pi)
        M = 8

        x = jnp.linspace(0.0, 2.0 * jnp.pi, grid.Nx, endpoint=False)
        y = jnp.linspace(0.0, 2.0 * jnp.pi, grid.Ny, endpoint=False)
        z = jnp.linspace(0.0, 2.0 * jnp.pi, grid.Nz, endpoint=False)
        Z, Y, X = jnp.meshgrid(z, y, x, indexing="ij")

        # Use identical z± so Psi = 0 and g is externally advected by Phi without
        # passive-sector back reaction. The mixed kz dependence keeps Phi from
        # being trivially steady, which is where the old midpoint Hermite update
        # exhibited strong long-time growth.
        phi_real = 0.2 * (jnp.sin(X + Y) + 0.5 * jnp.cos(Y - Z))
        phi = rfftn_forward(phi_real).astype(jnp.complex64) * grid.dealias_mask

        g1_real = 1e-3 * (jnp.cos(2.0 * X - Y + Z) + 0.5 * jnp.sin(X - 2.0 * Y + Z))
        g1 = rfftn_forward(g1_real).astype(jnp.complex64) * grid.dealias_mask

        g = jnp.zeros((grid.Nz, grid.Ny, grid.Nx // 2 + 1, M + 1), dtype=jnp.complex64)
        g = g.at[:, :, :, 1].set(g1)

        state = KRMHDState(
            z_plus=phi,
            z_minus=phi,
            B_parallel=jnp.zeros_like(phi),
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=0.0,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        current = state
        for _ in range(200):
            current = gandalf_step(current, dt=0.1, eta=0.0, v_A=1.0, nu=0.0)

        ratio = float(jnp.sum(jnp.abs(current.g) ** 2) / jnp.sum(jnp.abs(state.g) ** 2))
        assert ratio < 2.0, f"Hermite energy grew too much under external advection: {ratio:.3f}"
        assert jnp.all(jnp.isfinite(current.g)), "Hermite moments contain NaN/Inf after long advection run"


class TestM0RMHDOnly:
    """Tests for pure fluid RMHD runs with M=0 (Issue #132)."""

    def test_m0_gandalf_step_runs(self):
        """gandalf_step should succeed with M=0 and nu=0."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=4, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_alfven_wave(grid, M=0, amplitude=0.1)
        new_state = gandalf_step(state, dt=0.01, eta=0.0, v_A=1.0, nu=0.0)
        assert jnp.all(jnp.isfinite(new_state.z_plus))
        assert jnp.all(jnp.isfinite(new_state.z_minus))

    def test_m0_g_remains_zero(self):
        """Hermite moments should remain identically zero for M=0 runs."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=4, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_alfven_wave(grid, M=0, amplitude=0.1)
        new_state = gandalf_step(state, dt=0.01, eta=0.0, v_A=1.0, nu=0.0)
        assert jnp.allclose(new_state.g, 0.0), "g should remain zero for M=0"

    def test_m0_energy_conservation(self):
        """M=0 inviscid Orszag-Tang run should conserve energy."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=2, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_orszag_tang(grid, M=0)
        E0 = energy(state)["total"]
        assert E0 > 0, "Initial energy should be nonzero for Orszag-Tang"

        current = state
        for _ in range(10):
            current = gandalf_step(current, dt=0.001, eta=0.0, v_A=1.0, nu=0.0)

        E_final = energy(current)["total"]
        rel_err = abs(float(E_final - E0)) / float(E0)
        assert rel_err < 1e-2, f"Energy not conserved for M=0: relative error {rel_err:.2e}"

    def test_m0_with_nu_raises(self):
        """M=0 with nu > 0 should raise ValueError."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=4, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_alfven_wave(grid, M=0, amplitude=0.1)
        with pytest.raises(ValueError, match="M must be >= 2 when collisions are enabled"):
            gandalf_step(state, dt=0.01, eta=0.0, v_A=1.0, nu=0.1)

    def test_m0_with_resistivity(self):
        """M=0 with eta > 0 (resistive fluid RMHD) should work."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=4, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_alfven_wave(grid, M=0, amplitude=0.1)
        new_state = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, nu=0.0)
        assert jnp.all(jnp.isfinite(new_state.z_plus))
        assert jnp.all(jnp.isfinite(new_state.z_minus))

    def test_m0_with_hyper_resistivity(self):
        """M=0 with hyper-resistivity (r>1) should work."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=4, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_alfven_wave(grid, M=0, amplitude=0.1)
        new_state = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, nu=0.0, hyper_r=2)
        assert jnp.all(jnp.isfinite(new_state.z_plus))
        assert jnp.all(jnp.isfinite(new_state.z_minus))

    def test_m1_nu0_runs(self):
        """M=1 with nu=0 should run (degenerate but allowed for fluid-only use)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=4, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_alfven_wave(grid, M=1, amplitude=0.1)
        new_state = gandalf_step(state, dt=0.01, eta=0.0, v_A=1.0, nu=0.0)
        assert jnp.all(jnp.isfinite(new_state.z_plus))
        assert jnp.all(jnp.isfinite(new_state.z_minus))

    def test_m1_with_nu_raises(self):
        """M=1 with nu > 0 should raise ValueError (same as M=0)."""
        grid = SpectralGrid3D.create(Nx=32, Ny=32, Nz=4, Lx=1.0, Ly=1.0, Lz=1.0)
        state = initialize_alfven_wave(grid, M=1, amplitude=0.1)
        with pytest.raises(ValueError, match="M must be >= 2 when collisions are enabled"):
            gandalf_step(state, dt=0.01, eta=0.0, v_A=1.0, nu=0.1)


class TestIMEX222:
    """IMEX-RK222 Hermite integrator (Issue #137)."""

    @staticmethod
    def _make_random_state(Nx=16, Ny=16, Nz=8, M=6, seed=0, z_amp=0.1, g_amp=0.05,
                           nu=1.0, beta_i=1.0, Lambda=1.0):
        grid = SpectralGrid3D.create(Nx=Nx, Ny=Ny, Nz=Nz, Lx=1.0, Ly=1.0, Lz=1.0)
        Nxh = Nx // 2 + 1

        key = jax.random.PRNGKey(seed)
        k1, k2, k3 = jax.random.split(key, 3)

        def random_complex(key, shape, scale):
            kr, ki = jax.random.split(key)
            re = jax.random.normal(kr, shape)
            im = jax.random.normal(ki, shape)
            return scale * (re + 1j * im).astype(jnp.complex64)

        z_plus = random_complex(k1, (Nz, Ny, Nxh), z_amp)
        z_minus = random_complex(k2, (Nz, Ny, Nxh), z_amp)
        g = random_complex(k3, (Nz, Ny, Nxh, M + 1), g_amp)
        # Zero out the k=0 mode to stay in the physical subspace
        z_plus = z_plus.at[0, 0, 0].set(0.0)
        z_minus = z_minus.at[0, 0, 0].set(0.0)
        g = g.at[0, 0, 0, :].set(0.0)

        state = KRMHDState(
            z_plus=z_plus,
            z_minus=z_minus,
            B_parallel=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=beta_i,
            v_th=1.0,
            nu=nu,
            Lambda=Lambda,
            time=0.0,
            grid=grid,
        )
        return state

    def test_imex222_runs_and_is_finite(self):
        """Basic smoke test: IMEX scheme completes a step and produces finite output."""
        state = self._make_random_state()
        new = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, scheme="imex_rk222")
        assert jnp.all(jnp.isfinite(new.z_plus))
        assert jnp.all(jnp.isfinite(new.z_minus))
        assert jnp.all(jnp.isfinite(new.g))

    def test_imex222_invalid_scheme_raises(self):
        """Unknown scheme kwarg raises."""
        state = self._make_random_state()
        with pytest.raises(ValueError, match="scheme must be"):
            gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, scheme="bogus")

    def test_imex222_nontrivial_vA_matches_lawson(self):
        """z+/z- Elsasser phase and nonlinear coupling at v_A=2.0 must match
        the Lawson path over a long trajectory (T=1.0 ~ one parallel Alfven
        crossing time). Locks down the claim that both schemes use the same
        Elsasser integrating-factor convention end-to-end, not just for the
        first few short steps where an O(v_A*kz*dt^2) discrepancy would be
        below tolerance.
        """
        state0 = self._make_random_state(M=3, nu=0.0, z_amp=0.02, g_amp=0.01)
        v_A = 2.0
        dt = 0.005
        n_steps = 200  # T = 1.0, ~ one parallel Alfven crossing
        state_l = state0
        state_i = state0
        for _ in range(n_steps):
            state_l = gandalf_step(state_l, dt=dt, eta=0.0, v_A=v_A,
                                   nu=0.0, scheme="lawson_rk4")
            state_i = gandalf_step(state_i, dt=dt, eta=0.0, v_A=v_A,
                                   nu=0.0, scheme="imex_rk222")
        diff_plus = float(jnp.max(jnp.abs(state_l.z_plus - state_i.z_plus)))
        diff_minus = float(jnp.max(jnp.abs(state_l.z_minus - state_i.z_minus)))
        # Tight tolerance over a long trajectory: if either scheme silently
        # mishandled v_A, the divergence would grow to O(v_A*kz*T*<nl>) ~ 1e-2+.
        assert diff_plus < 5e-4, f"z_plus divergence at v_A={v_A} over T={n_steps*dt}: {diff_plus}"
        assert diff_minus < 5e-4, f"z_minus divergence at v_A={v_A} over T={n_steps*dt}: {diff_minus}"

    def test_imex222_fluid_limit_regression(self):
        """M=2, nu=0, eta=0: IMEX z+/z- trajectory matches Lawson path closely.

        The IMEX scheme only touches the g-advance; the Elsasser step is
        deliberately bit-identical. With M=2 and no collisions the residual
        difference comes purely from complex64 roundoff in the two paths'
        different Hermite arithmetic, so a tolerance of ~1e-5 is appropriate.
        """
        # M=2 with nu=0 runs both schemes without collisions.
        state0 = self._make_random_state(M=2, nu=0.0, z_amp=0.01, g_amp=0.01)
        state_l = state0
        state_i = state0
        for _ in range(20):
            state_l = gandalf_step(state_l, dt=0.005, eta=0.0, v_A=1.0,
                                   nu=0.0, scheme="lawson_rk4")
            state_i = gandalf_step(state_i, dt=0.005, eta=0.0, v_A=1.0,
                                   nu=0.0, scheme="imex_rk222")
        diff_plus = float(jnp.max(jnp.abs(state_l.z_plus - state_i.z_plus)))
        diff_minus = float(jnp.max(jnp.abs(state_l.z_minus - state_i.z_minus)))
        assert diff_plus < 1e-4, f"z_plus divergence: {diff_plus}"
        assert diff_minus < 1e-4, f"z_minus divergence: {diff_minus}"

    def test_imex222_pure_streaming_stable_large_dt(self):
        """Pure streaming test: z+/z-=0, g nonzero. IMEX stays bounded at dt
        well past what a streaming-CFL guard would permit.

        Scheme bound: the streaming matrix has max eigenvalue ~ sqrt(2M/Lambda).
        IMEX should remain numerically stable at large dt because streaming is
        implicit; the ratio of energies after 50 steps should stay O(1).
        """
        Nx = Ny = 16
        Nz = 16
        M = 32
        grid = SpectralGrid3D.create(Nx=Nx, Ny=Ny, Nz=Nz, Lx=1.0, Ly=1.0, Lz=1.0)
        key = jax.random.PRNGKey(5)
        kr, ki = jax.random.split(key)
        shape = (Nz, Ny, Nx // 2 + 1, M + 1)
        g = (0.01 * (jax.random.normal(kr, shape) + 1j * jax.random.normal(ki, shape))
             ).astype(jnp.complex64)
        g = g.at[0, 0, 0, :].set(0.0)

        state = KRMHDState(
            z_plus=jnp.zeros((Nz, Ny, Nx // 2 + 1), dtype=jnp.complex64),
            z_minus=jnp.zeros((Nz, Ny, Nx // 2 + 1), dtype=jnp.complex64),
            B_parallel=jnp.zeros((Nz, Ny, Nx // 2 + 1), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=1.0,
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )

        # A deliberately large dt: the implicit scheme must remain bounded.
        dt = 0.5
        E0 = float(jnp.sum(jnp.abs(state.g) ** 2))
        s = state
        for _ in range(50):
            s = gandalf_step(s, dt=dt, eta=0.0, v_A=1.0, scheme="imex_rk222")
        assert jnp.all(jnp.isfinite(s.g))
        E = float(jnp.sum(jnp.abs(s.g) ** 2))
        # Damping makes energy monotone non-increasing (D is negative semidefinite on
        # m>=2, streaming is skew-Hermitian). Require energy to stay bounded above.
        assert E <= E0 * 1.01, f"Energy grew: E0={E0}, E={E}"
        # And bounded below by machine precision (not all energy should vanish in 50 steps
        # unless ν·dt·n is huge).
        assert E > 1e-20

    def test_imex222_hypercollision_overflow_disabled(self):
        """IMEX path accepts large nu*dt without raising (unconditionally stable).
        Lawson path still raises on the same input.
        """
        state = self._make_random_state(M=4, nu=200.0)  # nu*dt = 2.0 with dt=0.01 is fine
        # Bump to trigger the Lawson guard (nu*dt >= 50): dt=0.3, nu=200 -> nu*dt=60.
        dt = 0.3
        # Lawson must raise
        with pytest.raises(ValueError, match="Hyper-collision overflow"):
            gandalf_step(state, dt=dt, eta=0.01, v_A=1.0, nu=200.0, scheme="lawson_rk4")
        # IMEX must not raise — solve is unconditionally stable; collision is implicit.
        new = gandalf_step(state, dt=dt, eta=0.01, v_A=1.0, nu=200.0, scheme="imex_rk222")
        assert jnp.all(jnp.isfinite(new.g))

    def test_imex222_damping_bypasses_m0_m1(self):
        """At kz=0, L reduces to diag(D) with D[0]=D[1]=0 and D[m]<0 for m>=2.
        Pass a g with support only at kz=0 (the zonal mean) and verify that
        strong collisional damping (nu=10) decays m>=2 while leaving m=0 and
        m=1 untouched — the conservation property that motivated the m>=2
        mask in _damping_diag.

        Note: this only tests the damping path. kz=0 slices are not physically
        meaningful (they live at the k=0 Fourier mode which is itself zeroed
        elsewhere by physics), but the IMEX operator is well-defined there
        and isolates the damping invariant cleanly.
        """
        Nx = Ny = 8
        Nz = 4
        M = 4
        grid = SpectralGrid3D.create(Nx=Nx, Ny=Ny, Nz=Nz, Lx=1.0, Ly=1.0, Lz=1.0)
        Nxh = Nx // 2 + 1
        g = jnp.zeros((Nz, Ny, Nxh, M + 1), dtype=jnp.complex64)
        # Put nonzero amplitude in all m, at a nonzero k_perp but kz=0:
        g = g.at[0, 1, 1, :].set(1.0 + 0.5j)

        state = KRMHDState(
            z_plus=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            z_minus=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            B_parallel=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=10.0,
            Lambda=1.5,
            time=0.0,
            grid=grid,
        )

        m0_init = complex(state.g[0, 1, 1, 0])
        m1_init = complex(state.g[0, 1, 1, 1])
        m4_init = complex(state.g[0, 1, 1, M])

        s = state
        for _ in range(5):
            s = gandalf_step(s, dt=0.1, eta=0.0, v_A=1.0, scheme="imex_rk222")

        m0_final = complex(s.g[0, 1, 1, 0])
        m1_final = complex(s.g[0, 1, 1, 1])
        m4_final = complex(s.g[0, 1, 1, M])

        # m=0, m=1 should be unchanged (D is zero there; L at kz=0 is diag D)
        assert abs(m0_final - m0_init) < 1e-5
        assert abs(m1_final - m1_init) < 1e-5
        # m=M should decay under nu=10, dt=0.1, n_steps=5 -> total damping ~0.5 per step
        assert abs(m4_final) < 0.5 * abs(m4_init), (
            f"m=M not damped: before={m4_init}, after={m4_final}"
        )

    def test_imex222_hyper_r_path(self):
        """Smoke test hyper_r=2 on the IMEX path. The post-step resistive
        damping factor is scheme-independent, but the IMEX code path has its
        own k_perp_max_squared / hyper_r exponent calculation; this locks
        it down against regressions in that branch."""
        state = self._make_random_state(M=4, nu=1.0, z_amp=0.02, g_amp=0.01)
        # hyper_r=2 is moderate hyper-resistivity; eta must satisfy eta*dt < 50
        # (normalized resistivity guard).
        s = state
        for _ in range(10):
            s = gandalf_step(s, dt=0.01, eta=0.5, v_A=1.0, nu=1.0,
                             hyper_r=2, hyper_n=2, scheme="imex_rk222")
        assert jnp.all(jnp.isfinite(s.z_plus))
        assert jnp.all(jnp.isfinite(s.z_minus))
        assert jnp.all(jnp.isfinite(s.g))
        # High-k modes should be damped by the hyper-resistive exp() factor.
        assert float(jnp.max(jnp.abs(s.g))) <= float(jnp.max(jnp.abs(state.g))) * 2.0

    def test_imex222_minimum_M_with_streaming_and_damping(self):
        """M=2 is the smallest system for which collisional damping is even
        defined (conservation carves out m=0,1 so M>=2 to have a damped m).
        Exercise BOTH branches of L simultaneously — nonzero streaming (from
        nonzero kz in a 3D grid) and nonzero nu — and verify the trajectory
        stays finite over a longer window than the short smoke tests."""
        grid = SpectralGrid3D.create(Nx=16, Ny=16, Nz=8, Lx=1.0, Ly=1.0, Lz=1.0)
        Nxh = grid.Nx // 2 + 1
        M = 2

        key = jax.random.PRNGKey(31)
        k1, k2, k3 = jax.random.split(key, 3)

        def rand_complex(k, shape, scale):
            kr, ki = jax.random.split(k)
            return (scale * (jax.random.normal(kr, shape)
                             + 1j * jax.random.normal(ki, shape))).astype(jnp.complex64)

        z_plus = rand_complex(k1, (grid.Nz, grid.Ny, Nxh), 0.05)
        z_minus = rand_complex(k2, (grid.Nz, grid.Ny, Nxh), 0.05)
        g = rand_complex(k3, (grid.Nz, grid.Ny, Nxh, M + 1), 0.02)
        z_plus = z_plus.at[0, 0, 0].set(0.0)
        z_minus = z_minus.at[0, 0, 0].set(0.0)
        g = g.at[0, 0, 0, :].set(0.0)

        state = KRMHDState(
            z_plus=z_plus,
            z_minus=z_minus,
            B_parallel=jnp.zeros((grid.Nz, grid.Ny, Nxh), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=1.0,
            v_th=1.0,
            nu=1.5,         # nonzero damping  -> D branch of L active
            Lambda=1.0,
            time=0.0,
            grid=grid,
        )
        # 3D grid with Nz=8 gives nonzero kz, so the streaming branch of L
        # is also active at every step.
        s = state
        for _ in range(100):
            s = gandalf_step(s, dt=0.01, eta=0.005, v_A=1.0, nu=1.5,
                             scheme="imex_rk222")
        assert jnp.all(jnp.isfinite(s.z_plus))
        assert jnp.all(jnp.isfinite(s.z_minus))
        assert jnp.all(jnp.isfinite(s.g))
        # m=M=2 should have been damped; max|g| should be bounded.
        assert float(jnp.max(jnp.abs(s.g))) < 10.0

    def test_imex222_zpm_parity_with_nu_positive(self):
        """z+/z- evolution must be bit-identical across schemes irrespective
        of nu: nu only affects g (damping, via D-inside-L on IMEX or via the
        post-step exponential on Lawson). A divergence here would signal a
        silent cross-contamination of nu into the z+/- path."""
        state0 = self._make_random_state(M=4, nu=2.5, z_amp=0.02, g_amp=0.01)
        dt = 0.005
        state_l = state0
        state_i = state0
        for _ in range(50):
            state_l = gandalf_step(state_l, dt=dt, eta=0.0, v_A=1.0,
                                   nu=2.5, scheme="lawson_rk4")
            state_i = gandalf_step(state_i, dt=dt, eta=0.0, v_A=1.0,
                                   nu=2.5, scheme="imex_rk222")
        diff_plus = float(jnp.max(jnp.abs(state_l.z_plus - state_i.z_plus)))
        diff_minus = float(jnp.max(jnp.abs(state_l.z_minus - state_i.z_minus)))
        assert diff_plus < 5e-4, f"z_plus parity broken at nu=2.5: {diff_plus}"
        assert diff_minus < 5e-4, f"z_minus parity broken at nu=2.5: {diff_minus}"

    def test_imex222_bparallel_parity_with_lawson(self):
        """B_parallel is a passive-slot pass-through in both schemes today
        (Issue #7). Verify both paths leave it bit-identical so a future
        slow-mode evolution lands in both schemes at once, not silently one
        at a time."""
        state0 = self._make_random_state(M=3, nu=0.0, z_amp=0.02, g_amp=0.01)
        # Seed B_parallel with a nonzero pattern so pass-through is observable.
        key = jax.random.PRNGKey(99)
        kr, ki = jax.random.split(key)
        Bp_shape = state0.B_parallel.shape
        Bp = (0.05 * (jax.random.normal(kr, Bp_shape)
                     + 1j * jax.random.normal(ki, Bp_shape))).astype(jnp.complex64)
        state0 = state0.model_copy(update={"B_parallel": Bp})

        state_l = gandalf_step(state0, dt=0.01, eta=0.01, v_A=1.0,
                               nu=0.0, scheme="lawson_rk4")
        state_i = gandalf_step(state0, dt=0.01, eta=0.01, v_A=1.0,
                               nu=0.0, scheme="imex_rk222")
        # Both paths pass fields.B_parallel through unchanged.
        assert jnp.array_equal(state_l.B_parallel, state0.B_parallel)
        assert jnp.array_equal(state_i.B_parallel, state0.B_parallel)

    def test_imex222_adaptive_dt_rebuilds_operator(self):
        """Changing dt between calls must trigger a fresh L/LU factorization.
        Exercises the "no stale cache" path if/when caching is added (#139).
        Today no cache exists — this is a defensive smoke test."""
        state = self._make_random_state(M=4, nu=1.0, z_amp=0.01, g_amp=0.01)
        # Two calls with different dt; both must produce finite output and
        # neither should crash due to a dt-dependent factorization mismatch.
        s1 = gandalf_step(state, dt=0.01, eta=0.01, v_A=1.0, scheme="imex_rk222")
        s2 = gandalf_step(s1,    dt=0.005, eta=0.01, v_A=1.0, scheme="imex_rk222")
        s3 = gandalf_step(s2,    dt=0.02, eta=0.01, v_A=1.0, scheme="imex_rk222")
        for s in (s1, s2, s3):
            assert jnp.all(jnp.isfinite(s.g))
            assert jnp.all(jnp.isfinite(s.z_plus))
            assert jnp.all(jnp.isfinite(s.z_minus))
        # And the effective times advance correctly.
        assert s3.time == pytest.approx(state.time + 0.01 + 0.005 + 0.02, abs=1e-6)

    def test_imex222_order_of_accuracy_with_damping(self):
        """Same manufactured-solution approach as the pure-streaming test,
        but with nu > 0 so the damping operator D (diag, negative-semidef
        on m>=2) is folded into L. Verifies the implicit damping branch
        is also 2nd-order accurate."""
        import numpy as np
        from krmhd.hermite import compute_streaming_matrix, _damping_diag

        Nx = Ny = 8
        Nz = 4
        M = 4
        beta_i = 1.0
        Lambda = 1.5
        nu = 2.0
        grid = SpectralGrid3D.create(Nx=Nx, Ny=Ny, Nz=Nz, Lx=1.0, Ly=1.0, Lz=1.0)

        Nxh = Nx // 2 + 1
        g = np.zeros((Nz, Ny, Nxh, M + 1), dtype=np.complex64)
        kz_idx = 1
        g[kz_idx, 0, 0, 0] = 1.0
        g[kz_idx, 0, 0, 1] = 0.5j
        g[kz_idx, 0, 0, 2] = 0.2
        g = jnp.asarray(g)

        state = KRMHDState(
            z_plus=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            z_minus=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            B_parallel=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=beta_i,
            v_th=1.0,
            nu=nu,
            Lambda=Lambda,
            time=0.0,
            grid=grid,
        )

        # Exact linear operator = -i sqrt(beta_i) kz T + nu * diag(D) (hyper_n=1).
        T_mat = compute_streaming_matrix(M, Lambda)
        D_diag = nu * _damping_diag(M, hyper_n=1)
        kz_val = float(np.asarray(grid.kz)[kz_idx])
        L0 = -1j * np.sqrt(beta_i) * kz_val * T_mat + np.diag(D_diag)
        T_final = 1.0

        from scipy.linalg import expm
        g_init = np.asarray(g[kz_idx, 0, 0, :])
        g_exact = expm(L0 * T_final) @ g_init

        errs = []
        dts = [0.1, 0.05, 0.025]
        for dt in dts:
            n_steps = int(round(T_final / dt))
            s = state
            for _ in range(n_steps):
                s = gandalf_step(s, dt=dt, eta=0.0, v_A=1.0, nu=nu,
                                 hyper_n=1, scheme="imex_rk222")
            g_num = np.asarray(s.g[kz_idx, 0, 0, :])
            errs.append(np.linalg.norm(g_num - g_exact))

        log_dts = np.log(dts)
        log_errs = np.log(errs)
        slope = np.polyfit(log_dts, log_errs, 1)[0]
        # ARS(2,2,2) is 2nd order. The floor 1.7 (not 1.9) absorbs float32 LU
        # roundoff, which starts to flatten the curve at the smallest dt; see
        # test_imex_solve_roundtrip for the complex64 residual magnitude.
        assert slope >= 1.7, (
            f"IMEX damped-convergence slope too low: {slope:.2f}, errs={errs}"
        )

    def test_imex222_order_of_accuracy_pure_streaming(self):
        """Manufactured linear test: with z+/z-=0, eta=0, nu=0 and all k_perp=0
        modes zeroed, the g-advance reduces to exp(-i*sqrt(beta_i)*kz*T*t).
        ARS(2,2,2) is 2nd-order accurate on linear problems; verify slope ~ 2.
        """
        import numpy as np
        from krmhd.hermite import compute_streaming_matrix

        Nx = Ny = 8
        Nz = 4
        M = 4
        beta_i = 1.0
        Lambda = 1.5  # Lambda>1 → T nonsymmetric but real eigenvalues
        grid = SpectralGrid3D.create(Nx=Nx, Ny=Ny, Nz=Nz, Lx=1.0, Ly=1.0, Lz=1.0)

        # Put energy on a single kz mode only; isolate the linear problem.
        Nxh = Nx // 2 + 1
        g = np.zeros((Nz, Ny, Nxh, M + 1), dtype=np.complex64)
        kz_idx = 1
        g[kz_idx, 0, 0, 0] = 1.0
        g[kz_idx, 0, 0, 1] = 0.5j
        g = jnp.asarray(g)

        state = KRMHDState(
            z_plus=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            z_minus=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            B_parallel=jnp.zeros((Nz, Ny, Nxh), dtype=jnp.complex64),
            g=g,
            M=M,
            beta_i=beta_i,
            v_th=1.0,
            nu=0.0,
            Lambda=Lambda,
            time=0.0,
            grid=grid,
        )

        # Exact solution at time T via matrix exponential
        T_mat = compute_streaming_matrix(M, Lambda)
        kz_val = float(np.asarray(grid.kz)[kz_idx])
        L0 = -1j * np.sqrt(beta_i) * kz_val * T_mat  # D=0, nu=0
        T_final = 1.0  # 1 unit of τ_A

        # Exact reference via matrix exponential: g(T) = exp(L0 * T) @ g(0).
        from scipy.linalg import expm
        g_init = np.asarray(g[kz_idx, 0, 0, :])
        g_exact = expm(L0 * T_final) @ g_init

        errs = []
        dts = [0.1, 0.05, 0.025]
        for dt in dts:
            n_steps = int(round(T_final / dt))
            s = state
            for _ in range(n_steps):
                s = gandalf_step(s, dt=dt, eta=0.0, v_A=1.0, nu=0.0,
                                 scheme="imex_rk222")
            g_num = np.asarray(s.g[kz_idx, 0, 0, :])
            errs.append(np.linalg.norm(g_num - g_exact))

        # Slope from log-log: expect ~2 (ARS(2,2,2) is 2nd-order)
        log_dts = np.log(dts)
        log_errs = np.log(errs)
        slope = np.polyfit(log_dts, log_errs, 1)[0]
        # ARS(2,2,2) is 2nd order. Floor at 1.7 (not 1.9) because at small dt
        # the complex64 LU residual (~3e-7, see test_imex_solve_roundtrip) is
        # comparable to the scheme's truncation error, flattening the slope.
        assert slope >= 1.7, (
            f"IMEX convergence slope too low: {slope:.2f}, errs={errs}"
        )
