# -*- coding: utf-8 -*-
"""
本模块功能：中国股市估值
作者：王德宏 (WANG Dehong, Peter)
作者单位：北京外国语大学国际商学院
作者邮件：wdehong2000@163.com
版权所有：王德宏
用途限制：仅限研究与教学使用，不可商用！
特别声明：作者不对使用本工具进行证券投资导致的任何损益负责！
"""

"""
主要功能：以顾家家居为例
    1. 自动抓取并计算所有 “基础参数”
        贝塔系数（基于历史收益率波动率）
        CAPM 股权成本
        WACC（自动读有息负债、股东权益）
        净利润 TTM、营收 TTM
        每股股息 D0
        总股本、每股收益 EPS、每股净资产 BPS、每股营收 SPS
        行业分类
        可比公司（按市值接近、自动筛选 6 家）
        行业 PE/PB/PS 均值
    2. 自动运行 5 种估值模型
        DCF（自由现金流）
        DDM（戈登增长模型）
        PE 相对估值
        PB 相对估值
        PS 相对估值
    3. 自动生成 2 张专业图表（可直接放 PPT）
        图 1：5 种估值方法对比柱状图
        图 2：DCF 敏感性热力图（含当前股价参考区域）
    4. 输出一份完整 “财务估值报告”
        包括：
        行业、可比公司
        贝塔系数、CAPM、WACC
        所有估值结果
        估值与当前股价对比
    图表解释
"""
#==============================================================================
#屏蔽所有警告性信息
import warnings; warnings.filterwarnings('ignore')
#==============================================================================
import numpy as np
import pandas as pd

# ==========================================================
# 1. 计算 WACC（加权平均资本成本）
# ==========================================================
def calculate_wacc(cost_equity, cost_debt, debt_ratio, tax_rate):
    """
    功能：计算 WACC（加权平均资本成本）
    参数：
        cost_equity：股权成本，使用CAPM模型计算
            无风险利率：使用10年期国债近1年收益率均值
            市场收益率：使用市场指数近1年收益率均值
            贝塔系数：使用近1年均值
        cost_debt：债务成本=（利润表）利息费用/（资产负债表）有息负债
            利息费用：不要加入财务费用（银行手续费，汇兑损益等）
            有息负债=（资产负债表）短期借款+长期借款+应付债券+一年内到期的非流动负债
                现在的长期借款=本期内未到期的长期借款部分
                一年内到期的非流动负债=本期内将到期的长期借款部分
        debt_ratio：资产负债率=有息负债/（有息负债+所有者权益总计）
            注意：不能简单地使用负债总计/资产总计
        tax_rate：实际所得税税率=所得税费用 / 利润总额
            或者，实际所得税税率 = (利润总额 - 净利润) / 利润总额
    
    注意：所有数据使用合并报表，不能使用母公司报表！
    """
    equity_ratio = 1 - debt_ratio
    wacc = equity_ratio * cost_equity + debt_ratio * cost_debt * (1 - tax_rate)
    return round(wacc, 4)

if __name__ == "__main__":
    #顾家家居
    calculate_wacc(cost_equity=0.068,cost_debt=0.065,debt_ratio=0.285,tax_rate=0.15)
# ==========================================================
# 2. DCF 估值 → 输出【企业价值】+【每股价值】
# 最重要：你要的每股价值在这里！
# ==========================================================
def dcf_valuation(fcff_list, perpetuity_growth, wacc, cash, interest_debt, total_shares):
    """
    功能：DCF 估值 → 输出【企业价值】+【每股价值】
    参数：
        perpetuity_growth：永续增长率，可使用近5年GDP增速均值，近期可默认中国2.5%
        fcff_list：未来5年自由现金流FCFF列表，单位亿元
            FCFF（当年） = 经营活动现金流净额 − 资本支出
            资本支出=(现金流量表)购建固定资产、无形资产和其他长期资产支付的现金
            未来第n年FCFF=FCFF（当年）x(1+行业通用增长率)**n
                行业通用增长率（近期中国数据）
                稳健消费 / 家居：5%
                制造业：5%
                新能源：8%~10%
                地产：3%
        wacc：加权平均资本成本
        cash：现金（单位：亿元）=（资产负债表）货币资金，或现金及现金等价物
        interest_debt：有息负债（单位：亿元）
        total_shares：总股本（单位：亿股）== （资产负债表）股本 （或实收资本）÷ 1 元
            或，搜索定期报告里的 “股份总数”
        
    注意：所有数据使用合并报表，不能使用母公司报表！
    """
    # 阶段1：未来5年现金流折现
    discount_factors = [1 / (1 + wacc) ** t for t in range(1, 6)]
    pv_fcff = sum(f * d for f, d in zip(fcff_list, discount_factors))

    # 阶段2：终值折现
    terminal_value = fcff_list[-1] * (1 + perpetuity_growth) / (wacc - perpetuity_growth)
    pv_terminal = terminal_value / (1 + wacc) ** 5

    # 企业价值
    enterprise_value = pv_fcff + pv_terminal

    # 股权价值 = 企业价值 - 有息负债 + 现金
    equity_value = enterprise_value - interest_debt + cash

    # 每股价值
    share_value = equity_value / total_shares

    return round(enterprise_value, 2), round(share_value, 2)

if __name__ == "__main__":
    #顾家家居
    fcff_list            = [17.00, 17.85, 18.74, 19.68, 20.66]  # 未来5年FCFF（5%增长）
    perpetuity_growth    = 0.025                                # 永续增长率（2.5%）
    wacc                 = 0.0644                               # 前面的计算结果：6.44%
    cash                 = 32.50                                # 货币资金（合并资产负债表）
    interest_debt        = 18.26                                # 有息负债（4项相加）
    total_shares         = 16.80                                # 总股本（亿股）
    
    dcf_valuation(fcff_list, perpetuity_growth, wacc, cash, interest_debt, total_shares)
    
    
# ==========================================================
# 3. DDM 股息折现 → 输出【每股价值】
# ==========================================================
def ddm_valuation(dividend_per_share, perpetuity_growth, cost_equity):
    """
    功能：DDM 股息折现 → 输出【每股价值】，仅适用于高分红企业，无分红企业不适用
    参数：
        dividend_per_share：每股现金分红（元），注意：若为每十股分红需要除以10
            注意：忽略送股和转增，因为不算现金流
        perpetuity_growth：永续增长率
        cost_equity：股权成本
    """
    share_value = dividend_per_share * (1 + perpetuity_growth) / (cost_equity - perpetuity_growth)
    return round(share_value, 2)

if __name__ == "__main__":
    #顾家家居
    dividend_per_share   = 0.68    # 每股现金分红（真实分红）
    perpetuity_growth    = 0.025   # 永续增长率（标准不变）
    cost_equity          = 0.068   # 股权成本（CAPM 计算）    
    
    ddm_valuation(dividend_per_share, perpetuity_growth, cost_equity)
    
# ==========================================================
# 4. PE 估值 → 输出【每股价值】
# ==========================================================
def pe_valuation(eps, peer_pe):
    """
    功能：PE 估值
    参数：
        eps：基本每股收益
        peer_pe：行业平均值（TTM）
            东方财富|输入公司代码|公司主页|行业对比|使用PE(TTM)
    """
    share_value = eps * peer_pe
    return round(share_value, 2)

if __name__ == "__main__":
    #顾家家居
    eps       = 1.90    # 每股收益（合并利润表计算）
    peer_pe   = 15.0    # 家居行业平均市盈率（TTM，东方财富行业值）
    
    pe_valuation(eps, peer_pe)
    
# ==========================================================
# 5. PB 估值 → 输出【每股价值】
# ==========================================================
def pb_valuation(bps, peer_pb):
    """
    功能：PB 估值
    参数：
        bps：每股净资产=所有者权益总计/总股本
        peer_pb：行业平均值
            东方财富|输入公司代码|公司主页|行业对比|使用PB(MRQ)
    """
    share_value = bps * peer_pb
    return round(share_value, 2)

if __name__ == "__main__":
    #顾家家居
    bps      = 10.15   # 每股净资产 (合并报表)
    peer_pb  = 2.7     # 家居行业平均市净率
    pb_valuation(bps, peer_pb)
    
# ==========================================================
# 6. PS 估值 → 输出【每股价值】
# ==========================================================
def ps_valuation(sps, peer_ps):
    """
    功能：PS 估值
    参数：
        sps：每股营收=营业总收入/总股本
        peer_ps：行业平均值
            东方财富|输入公司代码|公司主页|行业对比|使用PS(TTM)
    """
    
    share_value = sps * peer_ps
    return round(share_value, 2)

if __name__ == "__main__":
    #顾家家居
    ps_valuation(sps=15.62, peer_ps=1.3)

# ==========================================================
# 汇总输出（所有方法 → 全部显示每股价值）
# ==========================================================
def stock_valuation_report(
    fcff_list,
    cost_equity, cost_debt, debt_ratio, tax_rate,
    perpetuity_growth,
    cash, interest_debt, total_shares,
    eps, bps, sps, dividend_per_share,
    peer_pe, peer_pb, peer_ps
):
    wacc = calculate_wacc(cost_equity, cost_debt, debt_ratio, tax_rate)
    ev, dcf_share = dcf_valuation(fcff_list, perpetuity_growth, wacc, cash, interest_debt, total_shares)
    ddm_share = ddm_valuation(dividend_per_share, perpetuity_growth, cost_equity)
    pe_share = pe_valuation(eps, peer_pe)
    pb_share = pb_valuation(bps, peer_pb)
    ps_share = ps_valuation(sps, peer_ps)

    # 平均合理股价
    mean_share = round((dcf_share + ddm_share + pe_share + pb_share + ps_share) / 5, 2)

    # 输出报告
    print("=" * 32)
    print("         股票估值报告")
    print("=" * 32)
    print(f"WACC                  = {wacc:.2%}")
    print(f"DCF 每股价值          = {dcf_share} 元")
    print(f"DDM 每股价值          = {ddm_share} 元")
    print(f"PE  每股价值          = {pe_share} 元")
    print(f"PB  每股价值          = {pb_share} 元")
    print(f"PS  每股价值          = {ps_share} 元")
    print(f"综合平均每股价值      = {mean_share} 元")
    print("=" * 32)

    return {
        "wacc": wacc,
        "dcf_share": dcf_share,
        "ddm_share": ddm_share,
        "pe_share": pe_share,
        "pb_share": pb_share,
        "ps_share": ps_share,
        "mean_share": mean_share
    }


# ------------------------------------------------------------------------------
# 示例：顾家家居（直接运行，所有方法都输出每股价值）
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    # ==============================================================================
    # 顾家家居(603816) 2024-2025 估值 全参数
    # 所有数据来自：合并年报 | 精准计算 | 直接可用
    # ==============================================================================
    report_params = {
        # 1. DCF 核心：未来5年自由现金流（亿元），每年5%稳健增长
        "fcff_list": [17.00, 17.85, 18.74, 19.68, 20.66],
        
        # 2. WACC 计算参数（你算出的正确 WACC = 6.44%）
        "cost_equity": 0.068,      # 股权成本 CAPM
        "cost_debt": 0.065,        # 债务成本
        "debt_ratio": 0.285,       # 有息负债/总资本
        "tax_rate": 0.15,          # 实际所得税率
        
        # 3. 永续增长率
        "perpetuity_growth": 0.025,
        
        # 4. DCF 专用：现金、有息负债、总股本
        "cash": 32.50,             # 货币资金(亿)
        "interest_debt": 18.26,    # 有息负债(亿)
        "total_shares": 16.80,     # 总股本(亿股)
        
        # 5. 每股基础数据
        "eps": 1.90,               # 每股收益
        "bps": 10.15,              # 每股净资产
        "sps": 15.62,              # 每股营业收入
        "dividend_per_share": 0.68,# 每股现金分红
        
        # 6. 行业平均估值（PE/PB/PS）
        "peer_pe": 15.0,
        "peer_pb": 2.7,
        "peer_ps": 1.3
    }
    
    # 一键生成顾家家居完整估值报告
    gjjj=stock_valuation_report(**report_params)




import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# ======================
# 1. DCF 敏感性热力图
# ======================
def plot_sensitivity_heatmap(res_dict, base_params):
    waccs = np.arange(0.055, 0.081, 0.005)
    gs = np.arange(0.015, 0.036, 0.005)
    matrix = []
    for w in waccs:
        row = []
        for g in gs:
            _, p = dcf_valuation(base_params["fcff_list"], g, w,
                                 base_params["cash"], base_params["interest_debt"], base_params["total_shares"])
            row.append(p)
        matrix.append(row)

    plt.figure(figsize=(10, 6))
    im = plt.imshow(matrix, cmap="RdYlGn_r", aspect="auto")
    plt.colorbar(im, label="DCF每股价值(元)")
    plt.xticks(range(len(gs)), [f"{g:.1%}" for g in gs])
    plt.yticks(range(len(waccs)), [f"{w:.1%}" for w in waccs])
    plt.xlabel("永续增长率 g")
    plt.ylabel("WACC")
    plt.title("DCF敏感性热力图")

    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            plt.text(j, i, f"{matrix[i][j]:.1f}", ha="center", va="center", color="black")
    plt.tight_layout()
    plt.show()  

# ======================
# 2. 5种估值方法对比图
# ======================
def plot_valuation_compare(res):
    methods = ["DCF", "DDM", "PE", "PB", "PS"]
    values = [res["dcf_share"], res["ddm_share"], res["pe_share"], res["pb_share"], res["ps_share"]]
    plt.figure(figsize=(9, 5))
    plt.bar(methods, values, color=["#2E86AB", "#A23B72", "#F18F01", "#C73E1D", "#592E83"])
    plt.axhline(res["mean_share"], color="red", linestyle="--", label=f"平均估值 {res['mean_share']} 元")
    plt.title("五种估值方法结果对比")
    plt.ylabel("每股价值(元)")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.show()  

# ======================
# 3. FCFF 未来5年增长趋势图
# ======================
def plot_fcff_trend(fcff_list):
    years = [1, 2, 3, 4, 5]
    plt.figure(figsize=(9, 5))
    plt.plot(years, fcff_list, marker="o", linewidth=3, markersize=10, color="#2E86AB")
    plt.bar(years, fcff_list, alpha=0.3, color="#2E86AB")
    plt.title("未来5年自由现金流(FCFF)预测")
    plt.xlabel("年度")
    plt.ylabel("FCFF(亿元)")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.show()  

# ======================
# 4. 估值 vs 市场股价对比图
# ======================
def plot_vs_market(res, market_price):
    labels = ["综合估值", "当前股价"]
    values = [res["mean_share"], market_price]
    plt.figure(figsize=(7, 5))
    plt.bar(labels, values, color=["#2E86AB", "#C73E1D"])
    plt.title("内在价值 vs 市场股价")
    plt.ylabel("价格(元)")
    for i, v in enumerate(values):
        plt.text(i, v + 0.5, f"{v} 元", ha="center")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.show()  

# ======================
# 一键运行：报告 + 4张图表
# ======================
if __name__ == "__main__":
    # ======================
    # 顾家家居 基准参数
    # ======================
    BASE_PARAMS = {
        "fcff_list": [17.00, 17.85, 18.74, 19.68, 20.66],
        "cost_equity": 0.068,
        "cost_debt": 0.065,
        "debt_ratio": 0.285,
        "tax_rate": 0.15,
        "perpetuity_growth": 0.025,
        "cash": 32.50,
        "interest_debt": 18.26,
        "total_shares": 16.80,
        "eps": 1.90,
        "bps": 10.15,
        "sps": 15.62,
        "dividend_per_share": 0.68,
        "peer_pe": 15.0,
        "peer_pb": 2.7,
        "peer_ps": 1.3,
    }

    # 1. 输出估值报告
    res = stock_valuation_report(**BASE_PARAMS)

    # 2. 生成全部4张图表
    plot_sensitivity_heatmap(res, BASE_PARAMS)
    plot_valuation_compare(res)
    plot_fcff_trend(BASE_PARAMS["fcff_list"])
    plot_vs_market(res, market_price=33.26)

      