import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.user  # noqa: F401
import app.models.api_key  # noqa: F401
import app.models.project  # noqa: F401
import app.models.organization  # noqa: F401
import app.models.membership  # noqa: F401

from app.database import Base, get_db
from app.main import app as fastapi_app

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(fastapi_app)


def _register_and_login(client: TestClient, email: str, password: str = "TestPassword123!") -> tuple[int, dict[str, str]]:
    register_resp = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password},
    )
    assert register_resp.status_code == 201
    user_id = register_resp.json()["id"]

    login_resp = client.post(
        "/api/v1/auth/login",
        json={"email": email, "password": password},
    )
    assert login_resp.status_code == 200
    token = login_resp.json()["access_token"]
    return user_id, {"Authorization": f"Bearer {token}"}


def _create_project(client: TestClient) -> int:
    resp = client.post(
        "/api/v1/projects/",
        json={
            "name": "RBAC Project",
            "aut_base_url": "https://example.com",
        },
    )
    assert resp.status_code == 201
    return resp.json()["id"]


class TestOrganizationEndpoints:
    def test_jwt_create_and_list_organizations(self, client: TestClient):
        _, headers = _register_and_login(client, "org-admin@example.com")

        create_resp = client.post(
            "/api/v1/organizations",
            headers=headers,
            json={"name": "Acme QA", "description": "Org for QA"},
        )
        assert create_resp.status_code == 201

        list_resp = client.get("/api/v1/organizations", headers=headers)
        assert list_resp.status_code == 200
        assert len(list_resp.json()) == 1
        assert list_resp.json()[0]["name"] == "Acme QA"

    def test_api_key_scope_enforced_on_organizations(self, client: TestClient):
        _, headers = _register_and_login(client, "api-key-org@example.com")

        create_key_resp = client.post(
            "/api/v1/auth/api-keys",
            headers=headers,
            json={"name": "Org Writer", "scopes": ["org:write"]},
        )
        assert create_key_resp.status_code == 201
        key_data = create_key_resp.json()
        auth_header = {"Authorization": f"Bearer {key_data['id']}:{key_data['secret_key']}"}

        create_org = client.post(
            "/api/v1/organizations",
            headers=auth_header,
            json={"name": "Scoped Org", "description": "Scoped create"},
        )
        assert create_org.status_code == 201

        list_orgs_forbidden = client.get("/api/v1/organizations", headers=auth_header)
        assert list_orgs_forbidden.status_code == 403

    def test_duplicate_organization_name_returns_400(self, client: TestClient):
        _, headers = _register_and_login(client, "org-dup@example.com")

        first = client.post(
            "/api/v1/organizations",
            headers=headers,
            json={"name": "Duplicate Org", "description": "first"},
        )
        assert first.status_code == 201

        second = client.post(
            "/api/v1/organizations",
            headers=headers,
            json={"name": "Duplicate Org", "description": "second"},
        )
        assert second.status_code == 400


class TestProjectMembersRBAC:
    @pytest.mark.parametrize(
        "role,expected_put,expected_delete",
        [
            ("owner", 200, 204),
            ("admin", 200, 204),
            ("member", 403, 403),
            ("viewer", 403, 403),
        ],
    )
    def test_role_matrix_for_member_management(
        self,
        client: TestClient,
        role: str,
        expected_put: int,
        expected_delete: int,
    ):
        owner_id, owner_headers = _register_and_login(client, "owner@example.com")
        actor_id, actor_headers = _register_and_login(client, f"actor-{role}@example.com")
        target_id, _ = _register_and_login(client, f"target-{role}@example.com")

        project_id = _create_project(client)

        bootstrap_owner = client.put(
            f"/api/v1/projects/{project_id}/members/{owner_id}",
            headers=owner_headers,
            json={"role": "owner", "is_active": True},
        )
        assert bootstrap_owner.status_code == 200

        add_actor = client.put(
            f"/api/v1/projects/{project_id}/members/{actor_id}",
            headers=owner_headers,
            json={"role": role, "is_active": True},
        )
        assert add_actor.status_code == 200

        list_resp = client.get(
            f"/api/v1/projects/{project_id}/members",
            headers=actor_headers,
        )
        assert list_resp.status_code == 200

        mutate_resp = client.put(
            f"/api/v1/projects/{project_id}/members/{target_id}",
            headers=actor_headers,
            json={"role": "viewer", "is_active": True},
        )
        assert mutate_resp.status_code == expected_put

        if expected_put == 200:
            delete_resp = client.delete(
                f"/api/v1/projects/{project_id}/members/{target_id}",
                headers=actor_headers,
            )
            assert delete_resp.status_code == expected_delete
        else:
            # Non-manager roles should not be able to delete members either.
            delete_resp = client.delete(
                f"/api/v1/projects/{project_id}/members/{owner_id}",
                headers=actor_headers,
            )
            assert delete_resp.status_code == expected_delete

    def test_project_members_requires_scoped_api_key(self, client: TestClient):
        owner_id, owner_headers = _register_and_login(client, "owner-api-key@example.com")
        project_id = _create_project(client)

        bootstrap_owner = client.put(
            f"/api/v1/projects/{project_id}/members/{owner_id}",
            headers=owner_headers,
            json={"role": "owner", "is_active": True},
        )
        assert bootstrap_owner.status_code == 200

        create_key_resp = client.post(
            "/api/v1/auth/api-keys",
            headers=owner_headers,
            json={"name": "Read members", "scopes": ["members:read"]},
        )
        assert create_key_resp.status_code == 201
        key_data = create_key_resp.json()

        key_headers = {"Authorization": f"Bearer {key_data['id']}:{key_data['secret_key']}"}
        list_resp = client.get(f"/api/v1/projects/{project_id}/members", headers=key_headers)
        assert list_resp.status_code == 200

        put_resp = client.put(
            f"/api/v1/projects/{project_id}/members/{owner_id}",
            headers=key_headers,
            json={"role": "owner", "is_active": True},
        )
        assert put_resp.status_code == 403

    def test_list_members_forbidden_for_non_member(self, client: TestClient):
        owner_id, owner_headers = _register_and_login(client, "owner-forbidden@example.com")
        _, outsider_headers = _register_and_login(client, "outsider@example.com")
        project_id = _create_project(client)

        bootstrap_owner = client.put(
            f"/api/v1/projects/{project_id}/members/{owner_id}",
            headers=owner_headers,
            json={"role": "owner", "is_active": True},
        )
        assert bootstrap_owner.status_code == 200

        forbidden = client.get(
            f"/api/v1/projects/{project_id}/members",
            headers=outsider_headers,
        )
        assert forbidden.status_code == 403

    def test_list_members_missing_project_returns_404(self, client: TestClient):
        _, headers = _register_and_login(client, "owner-missing-project@example.com")
        resp = client.get("/api/v1/projects/99999/members", headers=headers)
        assert resp.status_code == 404

    def test_delete_missing_member_returns_404(self, client: TestClient):
        owner_id, owner_headers = _register_and_login(client, "owner-delete-missing@example.com")
        project_id = _create_project(client)

        bootstrap_owner = client.put(
            f"/api/v1/projects/{project_id}/members/{owner_id}",
            headers=owner_headers,
            json={"role": "owner", "is_active": True},
        )
        assert bootstrap_owner.status_code == 200

        delete_missing = client.delete(
            f"/api/v1/projects/{project_id}/members/99999",
            headers=owner_headers,
        )
        assert delete_missing.status_code == 404

    def test_upsert_existing_member_updates_role(self, client: TestClient):
        owner_id, owner_headers = _register_and_login(client, "owner-update-member@example.com")
        actor_id, _ = _register_and_login(client, "actor-update-member@example.com")
        project_id = _create_project(client)

        bootstrap_owner = client.put(
            f"/api/v1/projects/{project_id}/members/{owner_id}",
            headers=owner_headers,
            json={"role": "owner", "is_active": True},
        )
        assert bootstrap_owner.status_code == 200

        add_actor = client.put(
            f"/api/v1/projects/{project_id}/members/{actor_id}",
            headers=owner_headers,
            json={"role": "viewer", "is_active": True},
        )
        assert add_actor.status_code == 200
        assert add_actor.json()["role"] == "viewer"

        update_actor = client.put(
            f"/api/v1/projects/{project_id}/members/{actor_id}",
            headers=owner_headers,
            json={"role": "admin", "is_active": True},
        )
        assert update_actor.status_code == 200
        assert update_actor.json()["role"] == "admin"
