import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.user  # noqa: F401
import app.models.api_key  # noqa: F401
import app.models.project  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.execution_job  # noqa: F401

from app.main import app as fastapi_app
from app.database import Base, get_db
from app.models.execution_job import ExecutionJob, ExecutionJobStatus, can_transition
from app.models.generated_script import GeneratedScript, ScriptStatus
from app.models.membership import ProjectMembership, Role

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(fastapi_app)


def _register_and_login(client: TestClient, email: str, password: str = "TestPassword123!") -> tuple[int, dict[str, str]]:
    register_resp = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password},
    )
    assert register_resp.status_code == 201
    user_id = register_resp.json()["id"]

    login_resp = client.post(
        "/api/v1/auth/login",
        json={"email": email, "password": password},
    )
    assert login_resp.status_code == 200
    token = login_resp.json()["access_token"]
    return user_id, {"Authorization": f"Bearer {token}"}


def _create_scoped_api_key(client: TestClient, owner_headers: dict[str, str], scopes: list[str]) -> dict[str, str]:
    resp = client.post(
        "/api/v1/auth/api-keys",
        headers=owner_headers,
        json={"name": "Execution Key", "scopes": scopes},
    )
    assert resp.status_code == 201
    key = resp.json()
    return {"Authorization": f"Bearer {key['id']}:{key['secret_key']}"}


def _create_project_with_script(client: TestClient, owner_id: int, owner_headers: dict[str, str]) -> tuple[int, int]:
    project_resp = client.post(
        "/api/v1/projects/",
        json={"name": "Exec Project", "aut_base_url": "https://example.com"},
    )
    assert project_resp.status_code == 201
    project_id = project_resp.json()["id"]

    db = TestingSessionLocal()
    db.add(ProjectMembership(project_id=project_id, user_id=owner_id, role=Role.owner, is_active=True))
    db.commit()

    tc_resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/",
        json={"title": "TC-Exec", "format": "step_based", "content": "Step 1"},
    )
    assert tc_resp.status_code == 201
    tc_id = tc_resp.json()["id"]

    script = GeneratedScript(
        project_id=project_id,
        test_case_id=tc_id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content="print('ok')",
    )
    db.add(script)
    db.commit()
    db.refresh(script)
    script_id = script.id
    db.close()
    return project_id, script_id


class _DummyTaskState:
    def __init__(self, state: str, result=None):
        self.state = state
        self.result = result


def test_execution_run_and_status_with_api_key_scopes(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner@example.com")
    _, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-123")
    monkeypatch.setattr(
        "app.routers.execution.celery_app.AsyncResult",
        lambda task_id: _DummyTaskState("SUCCESS", {"status": "success", "script_id": script_id}),
    )

    run_resp = client.post(
        "/api/v1/execution/run",
        headers=key_headers,
        json={"script_id": script_id, "execution_env": {"browser": "chromium"}},
    )
    assert run_resp.status_code == 202
    payload = run_resp.json()
    assert payload["status"] == "pending"
    assert payload["celery_task_id"] == "task-123"

    status_resp = client.get(f"/api/v1/execution/status/{payload['id']}", headers=key_headers)
    assert status_resp.status_code == 200
    assert status_resp.json()["status"] == "completed"
    assert status_resp.json()["result_payload"]["status"] == "success"


def test_execution_run_idempotency_key_returns_existing_job(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-idem@example.com")
    _, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])

    calls = {"count": 0}

    def _enqueue(*args, **kwargs):
        calls["count"] += 1
        return "task-idem"

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", _enqueue)

    headers = {**key_headers, "Idempotency-Key": "idem-123"}
    first = client.post("/api/v1/execution/run", headers=headers, json={"script_id": script_id, "execution_env": {}})
    second = client.post("/api/v1/execution/run", headers=headers, json={"script_id": script_id, "execution_env": {}})

    assert first.status_code == 202
    assert second.status_code == 202
    assert first.json()["id"] == second.json()["id"]
    assert calls["count"] == 1


def test_execution_abort_requires_manager_role(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner2@example.com")
    viewer_id, viewer_headers = _register_and_login(client, "exec-viewer@example.com")
    project_id, script_id = _create_project_with_script(client, owner_id, owner_headers)

    db = TestingSessionLocal()
    db.add(ProjectMembership(project_id=project_id, user_id=viewer_id, role=Role.viewer, is_active=True))
    db.commit()
    db.close()

    owner_key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])
    viewer_key_headers = _create_scoped_api_key(client, viewer_headers, ["execution:write", "execution:read"])

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-abort")
    monkeypatch.setattr("app.routers.execution.celery_app.control.revoke", lambda *args, **kwargs: None)

    run_resp = client.post(
        "/api/v1/execution/run",
        headers=owner_key_headers,
        json={"script_id": script_id, "execution_env": {}},
    )
    assert run_resp.status_code == 202
    job_id = run_resp.json()["id"]

    forbidden = client.post(f"/api/v1/execution/abort/{job_id}", headers=viewer_key_headers)
    assert forbidden.status_code == 403

    allowed = client.post(f"/api/v1/execution/abort/{job_id}", headers=owner_key_headers)
    assert allowed.status_code == 200
    assert allowed.json()["status"] == "cancelled"


def test_execution_status_requires_read_scope(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner3@example.com")
    _, script_id = _create_project_with_script(client, owner_id, owner_headers)

    write_only_headers = _create_scoped_api_key(client, owner_headers, ["execution:write"])

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-scope")

    run_resp = client.post(
        "/api/v1/execution/run",
        headers=write_only_headers,
        json={"script_id": script_id, "execution_env": {}},
    )
    assert run_resp.status_code == 202

    status_resp = client.get(f"/api/v1/execution/status/{run_resp.json()['id']}", headers=write_only_headers)
    assert status_resp.status_code == 403


def test_execution_run_rejects_unready_script(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner4@example.com")
    project_id, script_id = _create_project_with_script(client, owner_id, owner_headers)

    db = TestingSessionLocal()
    script = db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
    script.status = ScriptStatus.pending
    db.commit()
    db.close()

    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])
    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-never")

    resp = client.post(
        "/api/v1/execution/run",
        headers=key_headers,
        json={"script_id": script_id, "execution_env": {}},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["message"] == "Script is not ready to run"


def test_execution_status_not_found(client: TestClient):
    _, owner_headers = _register_and_login(client, "exec-owner5@example.com")
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:read"])
    resp = client.get("/api/v1/execution/status/99999", headers=key_headers)
    assert resp.status_code == 404


def test_execution_run_rejects_missing_script(client: TestClient):
    _, owner_headers = _register_and_login(client, "exec-owner6@example.com")
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])
    resp = client.post("/api/v1/execution/run", headers=key_headers, json={"script_id": 99999, "execution_env": {}})
    assert resp.status_code == 404


def test_execution_status_started_revoked_failure_paths(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner7@example.com")
    _, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-state")

    run_resp = client.post(
        "/api/v1/execution/run",
        headers=key_headers,
        json={"script_id": script_id, "execution_env": {}},
    )
    assert run_resp.status_code == 202
    job_id = run_resp.json()["id"]

    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", lambda task_id: _DummyTaskState("STARTED"))
    started = client.get(f"/api/v1/execution/status/{job_id}", headers=key_headers)
    assert started.status_code == 200
    assert started.json()["status"] == "running"

    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", lambda task_id: _DummyTaskState("REVOKED"))
    revoked = client.get(f"/api/v1/execution/status/{job_id}", headers=key_headers)
    assert revoked.status_code == 200
    assert revoked.json()["status"] == "cancelled"

    db = TestingSessionLocal()
    job = db.query(ExecutionJob).filter(ExecutionJob.id == job_id).first()
    job.status = ExecutionJobStatus.running
    db.commit()
    db.close()

    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", lambda task_id: _DummyTaskState("FAILURE", RuntimeError("boom")))
    failed = client.get(f"/api/v1/execution/status/{job_id}", headers=key_headers)
    assert failed.status_code == 200
    assert failed.json()["status"] == "failed"
    assert "boom" in failed.json()["error_message"]


def test_execution_status_success_non_dict_result(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner8@example.com")
    _, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-result")
    run_resp = client.post(
        "/api/v1/execution/run",
        headers=key_headers,
        json={"script_id": script_id, "execution_env": {}},
    )
    assert run_resp.status_code == 202
    job_id = run_resp.json()["id"]

    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", lambda task_id: _DummyTaskState("SUCCESS", "ok-text"))
    resp = client.get(f"/api/v1/execution/status/{job_id}", headers=key_headers)
    assert resp.status_code == 200
    assert resp.json()["result_payload"] == {"result": "ok-text"}


def test_execution_abort_terminal_state_returns_unchanged(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner9@example.com")
    _, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])
    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-final")

    run_resp = client.post(
        "/api/v1/execution/run",
        headers=key_headers,
        json={"script_id": script_id, "execution_env": {}},
    )
    assert run_resp.status_code == 202
    job_id = run_resp.json()["id"]

    db = TestingSessionLocal()
    job = db.query(ExecutionJob).filter(ExecutionJob.id == job_id).first()
    job.status = ExecutionJobStatus.completed
    db.commit()
    db.close()

    resp = client.post(f"/api/v1/execution/abort/{job_id}", headers=key_headers)
    assert resp.status_code == 200
    assert resp.json()["status"] == "completed"


def test_enqueue_helper_and_transition_guard(monkeypatch):
    class _Result:
        id = "task-enqueued"

    monkeypatch.setattr("app.routers.execution.execute_script.delay", lambda *args, **kwargs: _Result())

    from app.routers.execution import _enqueue_execution_task

    task_id = _enqueue_execution_task(1, {}, 1)
    assert task_id == "task-enqueued"
    assert can_transition(ExecutionJobStatus.pending, ExecutionJobStatus.pending) is True
    assert can_transition(ExecutionJobStatus.completed, ExecutionJobStatus.running) is False


def test_sync_execution_job_state_branches():
    from app.tasks import _sync_execution_job_state
    from app.models.user import User
    from app.models.project import Project
    from app.models.test_case import TestCase

    db = TestingSessionLocal()
    user = User(email="sync-job@example.com", hashed_password="hash", is_active=True)
    db.add(user)
    db.commit()
    db.refresh(user)

    project = Project(name="Sync Project", aut_base_url="https://example.com")
    db.add(project)
    db.commit()
    db.refresh(project)

    tc = TestCase(project_id=project.id, title="Sync TC", format="step_based", content="step")
    db.add(tc)
    db.commit()
    db.refresh(tc)

    script = GeneratedScript(
        project_id=project.id,
        test_case_id=tc.id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content="print('ok')",
    )
    db.add(script)
    db.commit()
    db.refresh(script)

    job = ExecutionJob(
        project_id=project.id,
        script_id=script.id,
        test_case_id=tc.id,
        created_by_user_id=user.id,
        status=ExecutionJobStatus.pending,
        request_payload={"script_id": script.id, "execution_env": {}},
    )
    db.add(job)
    db.commit()
    db.refresh(job)

    _sync_execution_job_state(db, None, ExecutionJobStatus.running)
    _sync_execution_job_state(db, 999999, ExecutionJobStatus.running)
    _sync_execution_job_state(db, job.id, ExecutionJobStatus.running)
    _sync_execution_job_state(db, job.id, ExecutionJobStatus.cancelled)

    db.refresh(job)
    assert job.status == ExecutionJobStatus.cancelled
    assert job.cancelled_at is not None

    _sync_execution_job_state(db, job.id, ExecutionJobStatus.completed, result_payload={"status": "ok"})
    db.refresh(job)
    assert job.status == ExecutionJobStatus.cancelled
    assert job.result_payload is None

    db.close()


def test_sync_execution_job_state_completed_and_failed_paths():
    from app.tasks import _sync_execution_job_state
    from app.models.user import User
    from app.models.project import Project
    from app.models.test_case import TestCase

    db = TestingSessionLocal()
    user = User(email="sync-job2@example.com", hashed_password="hash", is_active=True)
    db.add(user)
    db.commit()
    db.refresh(user)

    project = Project(name="Sync Project 2", aut_base_url="https://example.com")
    db.add(project)
    db.commit()
    db.refresh(project)

    tc = TestCase(project_id=project.id, title="Sync TC 2", format="step_based", content="step")
    db.add(tc)
    db.commit()
    db.refresh(tc)

    script = GeneratedScript(
        project_id=project.id,
        test_case_id=tc.id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content="print('ok')",
    )
    db.add(script)
    db.commit()
    db.refresh(script)

    completed_job = ExecutionJob(
        project_id=project.id,
        script_id=script.id,
        test_case_id=tc.id,
        created_by_user_id=user.id,
        status=ExecutionJobStatus.running,
        request_payload={"script_id": script.id, "execution_env": {}},
    )
    failed_job = ExecutionJob(
        project_id=project.id,
        script_id=script.id,
        test_case_id=tc.id,
        created_by_user_id=user.id,
        status=ExecutionJobStatus.running,
        request_payload={"script_id": script.id, "execution_env": {}},
    )
    db.add_all([completed_job, failed_job])
    db.commit()
    db.refresh(completed_job)
    db.refresh(failed_job)

    _sync_execution_job_state(
        db,
        completed_job.id,
        ExecutionJobStatus.completed,
        result_payload={"status": "ok"},
    )
    _sync_execution_job_state(
        db,
        failed_job.id,
        ExecutionJobStatus.failed,
        error_message="failed-run",
    )

    db.refresh(completed_job)
    db.refresh(failed_job)
    assert completed_job.completed_at is not None
    assert completed_job.result_payload == {"status": "ok"}
    assert failed_job.completed_at is not None
    assert failed_job.error_message == "failed-run"
    db.close()


def test_execution_status_pending_and_no_membership_forbidden(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "exec-owner10@example.com")
    outsider_id, outsider_headers = _register_and_login(client, "exec-outsider@example.com")
    project_id, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:write", "execution:read"])
    outsider_key_headers = _create_scoped_api_key(client, outsider_headers, ["execution:read"])

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *args, **kwargs: "task-pending")
    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", lambda task_id: _DummyTaskState("PENDING"))

    run_resp = client.post(
        "/api/v1/execution/run",
        headers=key_headers,
        json={"script_id": script_id, "execution_env": {}},
    )
    assert run_resp.status_code == 202
    job_id = run_resp.json()["id"]

    pending_status = client.get(f"/api/v1/execution/status/{job_id}", headers=key_headers)
    assert pending_status.status_code == 200
    assert pending_status.json()["status"] == "pending"

    forbidden = client.get(f"/api/v1/execution/status/{job_id}", headers=outsider_key_headers)
    assert forbidden.status_code == 403

    db = TestingSessionLocal()
    db.query(ProjectMembership).filter(
        ProjectMembership.project_id == project_id,
        ProjectMembership.user_id == owner_id,
    ).delete()
    db.commit()
    db.close()

    no_members_status = client.get(f"/api/v1/execution/status/{job_id}", headers=key_headers)
    assert no_members_status.status_code == 200


def test_apply_status_from_celery_direct_path(monkeypatch):
    from app.routers.execution import _apply_status_from_celery
    from app.models.user import User
    from app.models.project import Project
    from app.models.test_case import TestCase

    db = TestingSessionLocal()
    user = User(email="apply-status@example.com", hashed_password="hash", is_active=True)
    db.add(user)
    db.commit()
    db.refresh(user)

    project = Project(name="Apply Status Project", aut_base_url="https://example.com")
    db.add(project)
    db.commit()
    db.refresh(project)

    tc = TestCase(project_id=project.id, title="Apply TC", format="step_based", content="step")
    db.add(tc)
    db.commit()
    db.refresh(tc)

    script = GeneratedScript(
        project_id=project.id,
        test_case_id=tc.id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content="print('ok')",
    )
    db.add(script)
    db.commit()
    db.refresh(script)

    job = ExecutionJob(
        project_id=project.id,
        script_id=script.id,
        test_case_id=tc.id,
        created_by_user_id=user.id,
        status=ExecutionJobStatus.pending,
        celery_task_id="task-direct",
        request_payload={"script_id": script.id, "execution_env": {}},
    )
    db.add(job)
    db.commit()
    db.refresh(job)

    calls = {"count": 0}

    def _async_result(task_id):
        calls["count"] += 1
        return _DummyTaskState("PENDING")

    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", _async_result)
    _apply_status_from_celery(job, db)
    db.refresh(job)
    assert calls["count"] == 1
    assert job.status == ExecutionJobStatus.pending
    db.close()


def test_apply_status_from_celery_returns_when_no_task_id(monkeypatch):
    from app.routers.execution import _apply_status_from_celery
    from app.models.user import User
    from app.models.project import Project
    from app.models.test_case import TestCase

    db = TestingSessionLocal()
    user = User(email="apply-status-guard@example.com", hashed_password="hash", is_active=True)
    db.add(user)
    db.commit()
    db.refresh(user)

    project = Project(name="Apply Guard Project", aut_base_url="https://example.com")
    db.add(project)
    db.commit()
    db.refresh(project)

    tc = TestCase(project_id=project.id, title="Apply Guard TC", format="step_based", content="step")
    db.add(tc)
    db.commit()
    db.refresh(tc)

    script = GeneratedScript(
        project_id=project.id,
        test_case_id=tc.id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content="print('ok')",
    )
    db.add(script)
    db.commit()
    db.refresh(script)

    job = ExecutionJob(
        project_id=project.id,
        script_id=script.id,
        test_case_id=tc.id,
        created_by_user_id=user.id,
        status=ExecutionJobStatus.pending,
        celery_task_id=None,
        request_payload={"script_id": script.id, "execution_env": {}},
    )
    db.add(job)
    db.commit()
    db.refresh(job)

    calls = {"count": 0}

    def _async_result(task_id):
        calls["count"] += 1
        return _DummyTaskState("SUCCESS", {"status": "success"})

    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", _async_result)
    _apply_status_from_celery(job, db)
    db.refresh(job)
    assert calls["count"] == 0
    assert job.status == ExecutionJobStatus.pending
    db.close()
