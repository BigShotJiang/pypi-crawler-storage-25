import logging
import threading
import time
from contextlib import asynccontextmanager
from pathlib import Path
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app import __version__
from app.config import settings
from app.llm.provider import get_llm_diagnostics
from app.routers import (
    analytics,
    api_key,
    auth,
    bulk_jobs,
    demo,
    execution,
    organizations,
    projects,
    reports,
    scripts,
    test_cases,
)

logging.basicConfig(level=logging.DEBUG if settings.DEBUG else logging.INFO)
logger = logging.getLogger(__name__)

static_dir = Path(__file__).resolve().parent / "static"
_RATE_LIMIT_BUCKETS: dict[str, tuple[int, float]] = {}
_RATE_LIMIT_LOCK = threading.Lock()


def _client_ip(request: Request) -> str:
    forwarded_for = request.headers.get("x-forwarded-for", "")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _is_exempt_path(path: str) -> bool:
    for exempt in settings.rate_limit_exempt_paths_list:
        if path == exempt or path.startswith(exempt):
            return True
    return False


def _check_rate_limit(key: str, now: float) -> tuple[bool, int, int]:
    window_seconds = max(1, settings.RATE_LIMIT_WINDOW_SECONDS)
    max_requests = max(1, settings.RATE_LIMIT_REQUESTS)
    window_start = now - window_seconds
    with _RATE_LIMIT_LOCK:
        current_count, reset_at = _RATE_LIMIT_BUCKETS.get(key, (0, now + window_seconds))
        if reset_at <= now:
            current_count = 0
            reset_at = now + window_seconds
        current_count += 1
        _RATE_LIMIT_BUCKETS[key] = (current_count, reset_at)

    remaining = max(0, max_requests - current_count)
    retry_after = max(0, int(reset_at - now))
    return current_count <= max_requests, remaining, retry_after


def _security_audit(event: str, request: Request, status_code: int, request_id: str) -> None:
    if not settings.SECURITY_AUDIT_LOG_ENABLED:
        return
    logger.info(
        "security_audit event=%s request_id=%s method=%s path=%s status=%s ip=%s user_agent=%s",
        event,
        request_id,
        request.method,
        request.url.path,
        status_code,
        _client_ip(request),
        request.headers.get("user-agent", "unknown"),
    )


@asynccontextmanager
async def lifespan(_: FastAPI):
    diagnostics = get_llm_diagnostics()
    logger.info(
        "Runtime LLM default: provider=%s model=%s api_key_env=%s api_key_present=%s api_key=%s",
        diagnostics["provider"],
        diagnostics["model"],
        diagnostics["api_key_env"],
        diagnostics["api_key_present"],
        diagnostics["api_key_masked"],
    )
    yield

app = FastAPI(
    title=settings.APP_NAME,
    description=(
        "Enterprise-grade Agentic AI system that converts functional test cases "
        "into high-quality automation scripts."
    ),
    version=__version__,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _error_envelope(request: Request, code: str, message: str, context: dict | None = None, status_code: int = 500) -> JSONResponse:
    request_id = getattr(request.state, "request_id", None) or request.headers.get("X-Request-ID", "unknown")
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "code": code,
                "message": message,
                "context": context or {},
                "request_id": request_id,
            }
        },
        headers={"X-Request-ID": request_id},
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse:
    code = {
        400: "bad_request",
        401: "unauthorized",
        403: "forbidden",
        404: "not_found",
        409: "conflict",
        422: "unprocessable_entity",
        429: "rate_limit_exceeded",
        500: "internal_server_error",
        503: "service_unavailable",
        504: "gateway_timeout",
    }.get(exc.status_code, f"http_{exc.status_code}")
    return _error_envelope(request, code, str(exc.detail), status_code=exc.status_code)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return _error_envelope(
        request,
        "validation_error",
        "Request validation failed",
        context={"errors": exc.errors()},
        status_code=422,
    )


@app.middleware("http")
async def apply_security_controls(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    request.state.request_id = request_id
    path = request.url.path
    now = time.time()

    if not _is_exempt_path(path):
        key = f"{_client_ip(request)}:{path}"
        allowed, remaining, retry_after = _check_rate_limit(key, now)
        if not allowed:
            _security_audit("rate_limit_block", request, 429, request_id)
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded", "request_id": request_id},
                headers={
                    "X-Request-ID": request_id,
                    "X-RateLimit-Limit": str(max(1, settings.RATE_LIMIT_REQUESTS)),
                    "X-RateLimit-Remaining": "0",
                    "Retry-After": str(retry_after),
                },
            )

    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id

    if not _is_exempt_path(path):
        response.headers["X-RateLimit-Limit"] = str(max(1, settings.RATE_LIMIT_REQUESTS))
        response.headers["X-RateLimit-Remaining"] = str(response.headers.get("X-RateLimit-Remaining", ""))
        if not response.headers["X-RateLimit-Remaining"]:
            key = f"{_client_ip(request)}:{path}"
            with _RATE_LIMIT_LOCK:
                count, _ = _RATE_LIMIT_BUCKETS.get(key, (0, now))
            response.headers["X-RateLimit-Remaining"] = str(max(0, max(1, settings.RATE_LIMIT_REQUESTS) - count))

    if path.startswith("/api/v1/auth") or path.startswith("/api/v1/execution"):
        if response.status_code >= 400 or request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            _security_audit("security_sensitive_request", request, response.status_code, request_id)

    return response

app.include_router(projects.router, prefix="/api/v1")
app.include_router(test_cases.router, prefix="/api/v1")
app.include_router(scripts.router, prefix="/api/v1")
app.include_router(bulk_jobs.router, prefix="/api/v1")
app.include_router(analytics.router, prefix="/api/v1")
app.include_router(analytics.insights_router, prefix="/api/v1")
app.include_router(demo.router, prefix="/api/v1")
app.include_router(auth.router, prefix="/api/v1")
app.include_router(api_key.router, prefix="/api/v1")
app.include_router(organizations.router, prefix="/api/v1")
app.include_router(execution.router, prefix="/api/v1")
app.include_router(reports.router, prefix="/api/v1")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/api/v1/runtime/llm", tags=["Runtime"])
def runtime_llm():
    default_diagnostics = get_llm_diagnostics()
    return {
        "default_provider": default_diagnostics["provider"],
        "default_model": default_diagnostics["model"],
        "provider_diagnostics": {
            provider: get_llm_diagnostics(provider) for provider in ["openai", "openrouter", "gemini", "ollama", "bedrock"]
        },
    }


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(static_dir / "index.html")


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "app": settings.APP_NAME}
