from celery import Celery
from app.config import settings

# Initialize Celery app
celery_app = Celery(
    settings.APP_NAME,
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

# Configure Celery
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=settings.CELERY_TASK_HARD_TIMEOUT,
    task_soft_time_limit=settings.CELERY_TASK_TIMEOUT,
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
)


@celery_app.task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def debug_task(self):
    """Test task to verify Celery is working."""
    print(f"Request: {self.request!r}")
    return "Celery is working!"
