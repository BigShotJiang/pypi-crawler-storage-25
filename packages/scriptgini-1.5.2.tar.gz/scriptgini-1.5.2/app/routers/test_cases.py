from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.project import Project
from app.models.test_case import TestCase
from app.schemas.test_case import TestCaseCreate, TestCaseUpdate, TestCaseResponse

router = APIRouter(prefix="/projects/{project_id}/test-cases", tags=["Test Cases"])


def _get_project_or_404(project_id: int, db: Session) -> Project:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.post("/", response_model=TestCaseResponse, status_code=status.HTTP_201_CREATED)
def create_test_case(project_id: int, payload: TestCaseCreate, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    tc = TestCase(project_id=project_id, **payload.model_dump())
    db.add(tc)
    db.commit()
    db.refresh(tc)
    return tc


@router.get("/", response_model=list[TestCaseResponse])
def list_test_cases(project_id: int, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    return db.query(TestCase).filter(TestCase.project_id == project_id).offset(skip).limit(limit).all()


@router.get("/{tc_id}", response_model=TestCaseResponse)
def get_test_case(project_id: int, tc_id: int, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    tc = db.query(TestCase).filter(TestCase.project_id == project_id, TestCase.id == tc_id).first()
    if not tc:
        raise HTTPException(status_code=404, detail="Test case not found")
    return tc


@router.patch("/{tc_id}", response_model=TestCaseResponse)
def update_test_case(project_id: int, tc_id: int, payload: TestCaseUpdate, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    tc = db.query(TestCase).filter(TestCase.project_id == project_id, TestCase.id == tc_id).first()
    if not tc:
        raise HTTPException(status_code=404, detail="Test case not found")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(tc, field, value)
    db.commit()
    db.refresh(tc)
    return tc


@router.delete("/{tc_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_test_case(project_id: int, tc_id: int, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    tc = db.query(TestCase).filter(TestCase.project_id == project_id, TestCase.id == tc_id).first()
    if not tc:
        raise HTTPException(status_code=404, detail="Test case not found")
    db.delete(tc)
    db.commit()
