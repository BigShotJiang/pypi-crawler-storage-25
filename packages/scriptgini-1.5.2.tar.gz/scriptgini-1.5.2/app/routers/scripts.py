import ast
import difflib
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
import logging
import os
import shlex
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.config import settings
from app.models.project import Project
from app.models.test_case import TestCase
from app.models.generated_script import GeneratedScript, ScriptStatus
from app.models.script_run import ScriptRun, ScriptRunStatus
from app.schemas.generated_script import GenerateScriptRequest, GeneratedScriptResponse, ScriptRunResponse
from app.schemas.script_revision import (
    RefactorScriptRequest,
    RefactorScriptResponse,
    ScriptDiffResponse,
    ScriptRevisionResponse,
    ScriptVersionHistoryResponse,
)
from app.models.script_revision import ScriptRevision, RevisionChangeType
from app.agents.script_gini_agent import run_agent
from app.llm.provider import LLMProvider, get_llm_diagnostics
from app.services.git_export import export_generated_script
from app.tasks import process_script_generation_job

logger = logging.getLogger(__name__)

_ALLOWED_IMPORT_ROOTS = {
    "collections",
    "dataclasses",
    "datetime",
    "decimal",
    "functools",
    "itertools",
    "json",
    "math",
    "pathlib",
    "playwright",
    "pytest",
    "random",
    "re",
    "selenium",
    "string",
    "time",
    "traceback",
    "typing",
    "urllib",
    "uuid",
}
_BLOCKED_BUILTIN_CALLS = {"exec", "eval", "compile", "__import__", "open", "input"}
_BLOCKED_ATTRIBUTE_CALLS = {
    "__subclasses__",
    "connect",
    "execv",
    "execve",
    "kill",
    "listen",
    "popen",
    "recv",
    "send",
    "spawnv",
    "spawnve",
    "startfile",
    "system",
}
_BLOCKED_SYMBOL_NAMES = {
    "__builtins__",
    "__globals__",
    "__loader__",
    "__spec__",
}
_BLOCKED_STRING_TOKENS = {
    "__builtins__",
    "__globals__",
    "__import__",
    "__loader__",
    "__spec__",
    "__subclasses__",
}
_MAX_OUTPUT_CHARS = 20_000


def _run_agent_with_deadline(**kwargs) -> dict:
    executor = ThreadPoolExecutor(max_workers=1)
    future = executor.submit(run_agent, **kwargs)
    try:
        return future.result(timeout=settings.SCRIPT_GENERATION_TIMEOUT_SECONDS)
    except FutureTimeoutError as exc:
        future.cancel()
        raise TimeoutError(
            "Script generation exceeded "
            f"{settings.SCRIPT_GENERATION_TIMEOUT_SECONDS}s deadline. "
            "Try a smaller model or increase SCRIPT_GENERATION_TIMEOUT_SECONDS in .env."
        ) from exc
    finally:
        executor.shutdown(wait=False, cancel_futures=True)

router = APIRouter(
    prefix="/projects/{project_id}/test-cases/{tc_id}/scripts",
    tags=["Scripts"],
)


def _looks_like_connection_error(message: str | None) -> bool:
    if not message:
        return False
    lowered = message.lower()
    indicators = (
        "connection error",
        "api connection",
        "connection refused",
        "failed to connect",
        "max retries exceeded",
        "name resolution",
        "temporary failure in name resolution",
        "timed out",
    )
    return any(token in lowered for token in indicators)


def _is_ollama_reachable() -> bool:
    parsed = urlparse(settings.OLLAMA_BASE_URL)
    host = parsed.hostname or "localhost"
    port = parsed.port or 11434
    try:
        with socket.create_connection((host, port), timeout=1.5):
            return True
    except OSError:
        return False


def _provider_readiness(provider: LLMProvider) -> tuple[bool, str]:
    if provider == "openai":
        if not settings.OPENAI_API_KEY.strip():
            return False, "OpenAI API key is missing. Set OPENAI_API_KEY in .env."
        return True, "OpenAI provider is configured."

    if provider == "openrouter":
        if not settings.OPENROUTER_API_KEY.strip():
            return False, "OpenRouter API key is missing. Set OPENROUTER_API_KEY in .env."
        return True, "OpenRouter provider is configured."

    if provider == "gemini":
        if not settings.GOOGLE_API_KEY.strip():
            return False, "Google API key is missing. Set GOOGLE_API_KEY in .env."
        return True, "Gemini provider is configured."

    if provider == "bedrock":
        if not settings.AWS_REGION_NAME.strip():
            return False, "AWS region is missing. Set AWS_REGION_NAME in .env."
        return True, "Bedrock provider appears configured."

    if provider == "ollama":
        if _is_ollama_reachable():
            return True, "Ollama service is reachable."
        return False, (
            "Ollama is not reachable at "
            f"{settings.OLLAMA_BASE_URL}. Start Ollama (for example: 'ollama serve') or choose a cloud provider with API key."
        )

    return False, f"Unknown provider: {provider}"


@router.get("/providers/{provider}/ready")
def provider_ready(project_id: int, tc_id: int, provider: LLMProvider, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    ok, detail = _provider_readiness(provider)
    return {"ready": ok, "detail": detail}


def _get_project_or_404(project_id: int, db: Session) -> Project:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


def _get_tc_or_404(project_id: int, tc_id: int, db: Session) -> TestCase:
    tc = db.query(TestCase).filter(TestCase.project_id == project_id, TestCase.id == tc_id).first()
    if not tc:
        raise HTTPException(status_code=404, detail="Test case not found")
    return tc


def _get_script_or_404(project_id: int, tc_id: int, script_id: int, db: Session) -> GeneratedScript:
    script = db.query(GeneratedScript).filter(
        GeneratedScript.id == script_id,
        GeneratedScript.project_id == project_id,
        GeneratedScript.test_case_id == tc_id,
    ).first()
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    return script


def _run_python_script(script_content: str) -> dict:
    _validate_script_safety(script_content)

    start_time = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="scriptgini-run-") as temp_dir:
        script_path = Path(temp_dir) / "generated_scenario.py"
        script_path.write_text(script_content, encoding="utf-8")
        command = _build_script_command(script_path, script_content)

        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            cwd=temp_dir,
            timeout=settings.SCRIPT_EXECUTION_TIMEOUT_SECONDS,
            env=_build_restricted_env(),
        )

    duration = time.perf_counter() - start_time
    return {
        "success": result.returncode == 0,
        "exit_code": result.returncode,
        "stdout": result.stdout[:_MAX_OUTPUT_CHARS],
        "stderr": result.stderr[:_MAX_OUTPUT_CHARS],
        "duration_seconds": round(duration, 2),
        "command": shlex.join(command),
    }


def _build_script_command(script_path: Path, script_content: str) -> list[str]:
    if _uses_pytest_playwright(script_content):
        command = [
            sys.executable,
            "-I",
            "-B",
            "-m",
            "pytest",
            script_path.name,
            "-s",
            "--browser",
            "chromium",
        ]
        if settings.PLAYWRIGHT_RUN_HEADED:
            command.append("--headed")
        return command
    return [sys.executable, "-I", "-B", str(script_path)]


def _uses_pytest_playwright(script_content: str) -> bool:
    try:
        tree = ast.parse(script_content)
    except SyntaxError:
        return False

    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
            arg_names = {arg.arg for arg in node.args.args}
            if {"page", "browser", "context"} & arg_names:
                return True
    return False


def _build_restricted_env() -> dict:
    allowed_exact = settings.execution_env_allowed_keys_set
    allowed_prefixes = settings.execution_env_allowed_prefixes_tuple
    env = {}
    for key, value in os.environ.items():
        if key in allowed_exact or key.startswith(allowed_prefixes):
            env[key] = value
    env["PLAYWRIGHT_HEADLESS"] = "0" if settings.PLAYWRIGHT_RUN_HEADED else "1"
    env["PYTHONNOUSERSITE"] = "1"
    return env


def _validate_script_safety(script_content: str) -> None:
    try:
        tree = ast.parse(script_content)
    except SyntaxError as exc:
        raise ValueError(f"Generated script has syntax issues: {exc}") from exc

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root not in _ALLOWED_IMPORT_ROOTS:
                    raise ValueError(f"Disallowed import detected: {root}")
        if isinstance(node, ast.ImportFrom):
            module_root = (node.module or "").split(".")[0]
            if module_root and module_root not in _ALLOWED_IMPORT_ROOTS:
                raise ValueError(f"Disallowed import detected: {module_root}")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in _BLOCKED_BUILTIN_CALLS:
                raise ValueError(f"Unsafe builtin call detected: {node.func.id}")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr in _BLOCKED_ATTRIBUTE_CALLS:
                raise ValueError(f"Unsafe runtime call detected: {node.func.attr}")
        if isinstance(node, ast.Name) and node.id in _BLOCKED_SYMBOL_NAMES:
            raise ValueError(f"Unsafe symbol usage detected: {node.id}")
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if node.value in _BLOCKED_STRING_TOKENS:
                raise ValueError(f"Unsafe introspection token detected: {node.value}")


def _create_script_run(db: Session, script: GeneratedScript, run_result: dict, status: ScriptRunStatus) -> ScriptRun:
    run_record = ScriptRun(
        script_id=script.id,
        project_id=script.project_id,
        test_case_id=script.test_case_id,
        status=status,
        success=run_result["success"],
        exit_code=run_result["exit_code"],
        stdout=run_result.get("stdout") or "",
        stderr=run_result.get("stderr") or "",
        duration_seconds=run_result["duration_seconds"],
        command=run_result["command"],
    )
    db.add(run_record)
    db.commit()
    db.refresh(run_record)
    return run_record


def _run_generation(script_id: int, project_id: int | Project, tc_id: int | TestCase, request_data: dict | object):
    """Background task: invoke the LangGraph agent and persist the result."""
    from app.database import SessionLocal

    resolved_project_id = project_id.id if isinstance(project_id, Project) else int(project_id)
    resolved_tc_id = tc_id.id if isinstance(tc_id, TestCase) else int(tc_id)
    resolved_request_data = request_data.model_dump() if hasattr(request_data, "model_dump") else request_data

    db = SessionLocal()
    try:
        script_record = db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
        if not script_record:
            return

        project = db.query(Project).filter(Project.id == resolved_project_id).first()
        tc = db.query(TestCase).filter(TestCase.id == resolved_tc_id, TestCase.project_id == resolved_project_id).first()
        if not project or not tc:
            script_record.status = ScriptStatus.failed
            script_record.error_message = "Project or test case not found"
            db.commit()
            return

        script_record.status = ScriptStatus.generating
        db.commit()

        request_framework = resolved_request_data.get("framework")
        framework = request_framework or project.default_framework.value
        llm_provider = resolved_request_data["llm_provider"]
        llm_model = resolved_request_data.get("llm_model")
        diagnostics = get_llm_diagnostics(llm_provider, llm_model)
        logger.info(
            "Script generation start: script_id=%s provider=%s model=%s api_key_env=%s api_key_present=%s api_key=%s",
            script_id,
            diagnostics["provider"],
            diagnostics["model"],
            diagnostics["api_key_env"],
            diagnostics["api_key_present"],
            diagnostics["api_key_masked"],
        )
        result = _run_agent_with_deadline(
            test_case_title=tc.title,
            test_case_content=tc.content,
            preconditions=tc.preconditions or "",
            test_data_hints=tc.test_data_hints or "",
            aut_base_url=project.aut_base_url,
            framework=framework,
            auth_hints=project.auth_hints or "",
            llm_provider=llm_provider,
            llm_model=llm_model,
        )

        if result.get("error") and llm_provider == "gemini" and "model was not found" in str(result.get("error")).lower():
            logger.warning(
                "Gemini model was not found for script_id=%s with model=%s. Retrying once with gemini-flash-latest.",
                script_id,
                llm_model or settings.GEMINI_MODEL,
            )
            fallback_result = _run_agent_with_deadline(
                test_case_title=tc.title,
                test_case_content=tc.content,
                preconditions=tc.preconditions or "",
                test_data_hints=tc.test_data_hints or "",
                aut_base_url=project.aut_base_url,
                framework=framework,
                auth_hints=project.auth_hints or "",
                llm_provider="gemini",
                llm_model="gemini-flash-latest",
            )
            if fallback_result.get("error"):
                result["error"] = (
                    f"{result.get('error')} | Gemini fallback failed: {fallback_result.get('error')}"
                )
            else:
                result = fallback_result
                script_record.llm_model = "gemini-flash-latest"

        if result.get("error") and _looks_like_connection_error(result.get("error")) and llm_provider != "ollama":
            logger.warning(
                "Primary provider '%s' failed with connection error for script_id=%s. Retrying once with Ollama.",
                llm_provider,
                script_id,
            )
            try:
                fallback_diagnostics = get_llm_diagnostics("ollama", None)
                logger.info(
                    "Fallback provider pick: script_id=%s provider=%s model=%s api_key_env=%s api_key_present=%s api_key=%s",
                    script_id,
                    fallback_diagnostics["provider"],
                    fallback_diagnostics["model"],
                    fallback_diagnostics["api_key_env"],
                    fallback_diagnostics["api_key_present"],
                    fallback_diagnostics["api_key_masked"],
                )
                fallback_result = _run_agent_with_deadline(
                    test_case_title=tc.title,
                    test_case_content=tc.content,
                    preconditions=tc.preconditions or "",
                    test_data_hints=tc.test_data_hints or "",
                    aut_base_url=project.aut_base_url,
                    framework=framework,
                    auth_hints=project.auth_hints or "",
                    llm_provider="ollama",
                    llm_model=None,
                )
                if fallback_result.get("error"):
                    result["error"] = (
                        f"{result.get('error')} | Ollama fallback failed: {fallback_result.get('error')}"
                    )
                else:
                    result = fallback_result
                    script_record.llm_provider = "ollama"
                    script_record.llm_model = ""
            except Exception as fallback_exc:
                result["error"] = f"{result.get('error')} | Ollama fallback exception: {fallback_exc}"

        script_record.script_content = result["script"]
        script_record.error_message = result.get("error")
        script_record.token_usage = result.get("token_usage")
        script_record.status = ScriptStatus.failed if result.get("error") else ScriptStatus.completed
        db.commit()
    except Exception as exc:
        logger.exception("Script generation failed for script_id=%s", script_id)
        script_record = db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
        if script_record:
            script_record.status = ScriptStatus.failed
            script_record.error_message = str(exc)
            db.commit()
    finally:
        db.close()


@router.post("/generate", response_model=GeneratedScriptResponse, status_code=status.HTTP_202_ACCEPTED)
def generate_script(
    project_id: int,
    tc_id: int,
    payload: GenerateScriptRequest,
    db: Session = Depends(get_db),
):
    """Kick off async script generation. Poll GET /scripts/{id} for the result."""
    project = _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)

    framework = (payload.framework or project.default_framework).value
    script_record = GeneratedScript(
        project_id=project_id,
        test_case_id=tc_id,
        framework=framework,
        llm_provider=payload.llm_provider,
        llm_model=payload.llm_model or "",
        status=ScriptStatus.pending,
    )
    db.add(script_record)
    db.commit()
    db.refresh(script_record)

    try:
        process_script_generation_job.delay(
            script_record.id,
            project_id,
            tc_id,
            payload.model_dump(),
        )
    except Exception as exc:
        logger.exception("Failed to enqueue generation task for script_id=%s", script_record.id)
        script_record.status = ScriptStatus.failed
        script_record.error_message = f"Queue enqueue failed: {exc}"
        db.commit()
        raise HTTPException(status_code=503, detail="Failed to enqueue script generation") from exc

    return script_record


@router.get("/", response_model=list[GeneratedScriptResponse])
def list_scripts(
    project_id: int,
    tc_id: int,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
):
    _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    return (
        db.query(GeneratedScript)
        .filter(GeneratedScript.test_case_id == tc_id)
        .order_by(GeneratedScript.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.get("/{script_id}", response_model=GeneratedScriptResponse)
def get_script(project_id: int, tc_id: int, script_id: int, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    return _get_script_or_404(project_id, tc_id, script_id, db)


@router.get("/{script_id}/runs", response_model=list[ScriptRunResponse])
def list_script_runs(project_id: int, tc_id: int, script_id: int, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    _get_script_or_404(project_id, tc_id, script_id, db)
    return (
        db.query(ScriptRun)
        .filter(ScriptRun.script_id == script_id)
        .order_by(ScriptRun.created_at.desc(), ScriptRun.id.desc())
        .all()
    )


@router.post("/{script_id}/run", response_model=ScriptRunResponse)
def run_script(project_id: int, tc_id: int, script_id: int, db: Session = Depends(get_db)):
    project = _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    script = _get_script_or_404(project_id, tc_id, script_id, db)

    if script.framework != "playwright_python":
        raise HTTPException(
            status_code=400,
            detail="Only playwright_python scripts can be executed from the UI",
        )

    if script.status != ScriptStatus.completed or not script.script_content:
        raise HTTPException(status_code=400, detail="Script is not ready to run")

    try:
        run_result = _run_python_script(script.script_content)
        run_status = ScriptRunStatus.completed if run_result["success"] else ScriptRunStatus.failed
        return _create_script_run(db, script, run_result, run_status)
    except ValueError as exc:
        run_result = {
            "success": False,
            "exit_code": 2,
            "stdout": "",
            "stderr": str(exc),
            "duration_seconds": 0.0,
            "command": f"{sys.executable} generated_scenario.py",
        }
        return _create_script_run(db, script, run_result, ScriptRunStatus.failed)
    except subprocess.TimeoutExpired as exc:
        run_result = {
            "success": False,
            "exit_code": 124,
            "stdout": exc.stdout or "",
            "stderr": (exc.stderr or "") + f"\nScript execution timed out after {exc.timeout} seconds",
            "duration_seconds": float(exc.timeout),
            "command": f"{sys.executable} generated_scenario.py",
        }
        return _create_script_run(db, script, run_result, ScriptRunStatus.timed_out)


@router.post("/{script_id}/github-export")
def github_export_script(project_id: int, tc_id: int, script_id: int, db: Session = Depends(get_db)):
    project = _get_project_or_404(project_id, db)
    tc = _get_tc_or_404(project_id, tc_id, db)
    script = _get_script_or_404(project_id, tc_id, script_id, db)

    if script.status != ScriptStatus.completed or not script.script_content:
        raise HTTPException(status_code=400, detail="Script must be completed before GitHub export")

    if not settings.AUTO_EXPORT_GIT_ENABLED:
        raise HTTPException(status_code=400, detail="GitHub export is disabled. Set AUTO_EXPORT_GIT_ENABLED=true in .env")

    try:
        export_path = export_generated_script(
            project_name=project.name,
            test_case_title=tc.title,
            script_id=script.id,
            framework=script.framework,
            llm_provider=script.llm_provider,
            llm_model=script.llm_model or "runtime-default",
            script_content=script.script_content,
        )
    except Exception as exc:
        logger.exception("GitHub export failed for script_id=%s", script_id)
        raise HTTPException(status_code=500, detail=f"GitHub export failed: {exc}") from exc

    if not export_path:
        raise HTTPException(status_code=500, detail="GitHub export did not produce an output path")

    return {
        "exported": True,
        "path": export_path,
        "repository": settings.AUTO_EXPORT_GIT_REPO_URL,
        "branch": settings.AUTO_EXPORT_GIT_BRANCH,
    }


@router.delete("/{script_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_script(project_id: int, tc_id: int, script_id: int, db: Session = Depends(get_db)):
    _get_project_or_404(project_id, db)
    script = _get_script_or_404(project_id, tc_id, script_id, db)
    db.delete(script)
    db.commit()


# ---------------------------------------------------------------------------
# Sprint 6: Script lifecycle – refactor, version history, diff, rollback
# ---------------------------------------------------------------------------

def _next_revision_number(db: Session, script_id: int) -> int:
    from sqlalchemy import func as sqla_func
    max_rev = db.query(sqla_func.max(ScriptRevision.revision_number)).filter(
        ScriptRevision.script_id == script_id
    ).scalar()
    return (max_rev or 0) + 1


def _snapshot_revision(
    db: Session,
    script: GeneratedScript,
    change_type: RevisionChangeType,
    change_summary: str | None = None,
) -> ScriptRevision:
    rev_num = _next_revision_number(db, script.id)
    revision = ScriptRevision(
        script_id=script.id,
        project_id=script.project_id,
        test_case_id=script.test_case_id,
        revision_number=rev_num,
        script_content=script.script_content or "",
        change_type=change_type,
        change_summary=change_summary,
    )
    db.add(revision)
    db.commit()
    db.refresh(revision)
    return revision


@router.post("/{script_id}/refactor", response_model=RefactorScriptResponse)
def refactor_script(
    project_id: int,
    tc_id: int,
    script_id: int,
    payload: RefactorScriptRequest,
    db: Session = Depends(get_db),
):
    """Submit an error log; the LLM heals the script and saves a new revision."""
    project = _get_project_or_404(project_id, db)
    tc = _get_tc_or_404(project_id, tc_id, db)
    script = _get_script_or_404(project_id, tc_id, script_id, db)

    if not script.script_content:
        raise HTTPException(status_code=400, detail="Script has no content to refactor")

    llm_provider: str = payload.llm_provider or script.llm_provider
    llm_model: str | None = payload.llm_model or script.llm_model or None

    healing_prompt_suffix = (
        f"\n\nThe script above failed with the following error log:\n{payload.error_log}\n\n"
        "Please fix the script so it passes. Return only the corrected Python script."
    )
    combined_content = (tc.content or "") + healing_prompt_suffix

    try:
        result = _run_agent_with_deadline(
            test_case_title=tc.title,
            test_case_content=combined_content,
            preconditions=tc.preconditions or "",
            test_data_hints=tc.test_data_hints or "",
            aut_base_url=project.aut_base_url,
            framework=script.framework,
            auth_hints=project.auth_hints or "",
            llm_provider=llm_provider,
            llm_model=llm_model,
        )
    except TimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Refactor agent failed: {exc}") from exc

    if result.get("error") and not result.get("script"):
        raise HTTPException(status_code=500, detail=f"Refactor failed: {result['error']}")

    new_content = result.get("script") or script.script_content
    script.script_content = new_content
    script.status = ScriptStatus.completed
    db.commit()

    summary = f"Refactored to fix: {payload.error_log[:120]}"
    revision = _snapshot_revision(db, script, RevisionChangeType.refactored, summary)

    return RefactorScriptResponse(
        script_id=script.id,
        revision_id=revision.id,
        revision_number=revision.revision_number,
        script_content=new_content,
        change_summary=summary,
    )


@router.get("/{script_id}/version-history", response_model=ScriptVersionHistoryResponse)
def get_version_history(
    project_id: int,
    tc_id: int,
    script_id: int,
    db: Session = Depends(get_db),
):
    _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    _get_script_or_404(project_id, tc_id, script_id, db)

    revisions = (
        db.query(ScriptRevision)
        .filter(ScriptRevision.script_id == script_id)
        .order_by(ScriptRevision.revision_number.asc())
        .all()
    )
    return ScriptVersionHistoryResponse(
        script_id=script_id,
        total_revisions=len(revisions),
        revisions=[ScriptRevisionResponse.model_validate(r) for r in revisions],
    )


@router.get("/{script_id}/version-history/{revision_id}/diff", response_model=ScriptDiffResponse)
def get_revision_diff(
    project_id: int,
    tc_id: int,
    script_id: int,
    revision_id: int,
    db: Session = Depends(get_db),
):
    """Return a unified diff between the revision just before `revision_id` and `revision_id`."""
    _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    _get_script_or_404(project_id, tc_id, script_id, db)

    target = db.query(ScriptRevision).filter(
        ScriptRevision.id == revision_id,
        ScriptRevision.script_id == script_id,
    ).first()
    if not target:
        raise HTTPException(status_code=404, detail="Revision not found")

    # Find the revision immediately before target
    prev = (
        db.query(ScriptRevision)
        .filter(
            ScriptRevision.script_id == script_id,
            ScriptRevision.revision_number < target.revision_number,
        )
        .order_by(ScriptRevision.revision_number.desc())
        .first()
    )
    from_content = prev.script_content if prev else ""
    from_rev = prev.revision_number if prev else 0

    diff_lines = list(
        difflib.unified_diff(
            from_content.splitlines(keepends=True),
            target.script_content.splitlines(keepends=True),
            fromfile=f"revision-{from_rev}",
            tofile=f"revision-{target.revision_number}",
        )
    )
    return ScriptDiffResponse(
        script_id=script_id,
        from_revision=from_rev,
        to_revision=target.revision_number,
        from_content=from_content,
        to_content=target.script_content,
        diff_lines=diff_lines,
    )


@router.post("/{script_id}/rollback/{revision_id}", response_model=GeneratedScriptResponse)
def rollback_script(
    project_id: int,
    tc_id: int,
    script_id: int,
    revision_id: int,
    db: Session = Depends(get_db),
):
    """Restore a script to a previously saved revision and record a rolled_back snapshot."""
    _get_project_or_404(project_id, db)
    _get_tc_or_404(project_id, tc_id, db)
    script = _get_script_or_404(project_id, tc_id, script_id, db)

    target = db.query(ScriptRevision).filter(
        ScriptRevision.id == revision_id,
        ScriptRevision.script_id == script_id,
    ).first()
    if not target:
        raise HTTPException(status_code=404, detail="Revision not found")

    script.script_content = target.script_content
    script.status = ScriptStatus.completed
    db.commit()

    _snapshot_revision(
        db,
        script,
        RevisionChangeType.rolled_back,
        f"Rolled back to revision {target.revision_number}",
    )
    db.refresh(script)
    return script
