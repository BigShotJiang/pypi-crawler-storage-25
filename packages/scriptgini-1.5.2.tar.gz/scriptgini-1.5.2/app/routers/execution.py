from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from app.celery_app import celery_app
from app.database import get_db
from app.models.execution_job import ExecutionJob, ExecutionJobStatus, can_transition
from app.models.generated_script import GeneratedScript, ScriptStatus
from app.schemas.execution import ExecutionJobResponse, ExecutionRunRequest
from app.services import rbac as rbac_service
from app.services.auth_dependencies import require_auth_with_scopes
from app.tasks import execute_script

router = APIRouter(prefix="/execution", tags=["Execution"])


def _get_job_or_404(job_id: int, db: Session) -> ExecutionJob:
    job = db.query(ExecutionJob).filter(ExecutionJob.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Execution job not found")
    return job


def _ensure_project_access(db: Session, project_id: int, user_id: int, require_manager: bool = False) -> None:
    rbac_service.ensure_project_exists(db, project_id)
    existing_members = rbac_service.list_project_members(db, project_id)
    if not existing_members:
        return

    membership = rbac_service.get_user_project_membership(db, project_id, user_id)
    if membership is None or membership.role not in rbac_service.READ_ROLES:
        raise HTTPException(status_code=403, detail="Insufficient project role")

    if require_manager and membership.role not in rbac_service.MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Insufficient project role")


def _apply_status_from_celery(job: ExecutionJob, db: Session) -> None:
    if not job.celery_task_id or job.status not in {ExecutionJobStatus.pending, ExecutionJobStatus.running}:
        return

    task_result = celery_app.AsyncResult(job.celery_task_id)
    state = task_result.state

    if state == "PENDING":
        return

    if state == "STARTED" and can_transition(job.status, ExecutionJobStatus.running):
        job.status = ExecutionJobStatus.running
        if job.started_at is None:
            job.started_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(job)
        return

    if state == "SUCCESS" and can_transition(job.status, ExecutionJobStatus.completed):
        job.status = ExecutionJobStatus.completed
        job.completed_at = datetime.now(timezone.utc)
        if job.started_at is None:
            job.started_at = job.completed_at
        result = task_result.result
        job.result_payload = result if isinstance(result, dict) else {"result": str(result)}
        db.commit()
        db.refresh(job)
        return

    if state == "REVOKED" and can_transition(job.status, ExecutionJobStatus.cancelled):
        job.status = ExecutionJobStatus.cancelled
        job.cancelled_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(job)
        return

    if state == "FAILURE" and can_transition(job.status, ExecutionJobStatus.failed):
        job.status = ExecutionJobStatus.failed
        job.completed_at = datetime.now(timezone.utc)
        job.error_message = str(task_result.result)
        db.commit()
        db.refresh(job)


def _enqueue_execution_task(script_id: int, execution_env: dict[str, str], job_id: int) -> str:
    async_result = execute_script.delay(script_id, execution_env, job_id)
    return async_result.id


@router.post("/run", response_model=ExecutionJobResponse, status_code=status.HTTP_202_ACCEPTED)
def run_execution_job(
    payload: ExecutionRunRequest,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    current_user=Depends(require_auth_with_scopes({"execution:write"})),
    db: Session = Depends(get_db),
):
    script = db.query(GeneratedScript).filter(GeneratedScript.id == payload.script_id).first()
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    if script.status != ScriptStatus.completed or not script.script_content:
        raise HTTPException(status_code=400, detail="Script is not ready to run")

    _ensure_project_access(db, script.project_id, current_user.id)

    if idempotency_key:
        existing_job = (
            db.query(ExecutionJob)
            .filter(ExecutionJob.idempotency_key == idempotency_key, ExecutionJob.created_by_user_id == current_user.id)
            .first()
        )
        if existing_job:
            _ensure_project_access(db, existing_job.project_id, current_user.id)
            return existing_job

    job = ExecutionJob(
        project_id=script.project_id,
        script_id=script.id,
        test_case_id=script.test_case_id,
        created_by_user_id=current_user.id,
        status=ExecutionJobStatus.pending,
        idempotency_key=idempotency_key,
        request_payload=payload.model_dump(),
    )
    db.add(job)
    db.commit()
    db.refresh(job)

    job.celery_task_id = _enqueue_execution_task(script.id, payload.execution_env, job.id)
    db.commit()
    db.refresh(job)
    return job


@router.get("/status/{job_id}", response_model=ExecutionJobResponse)
def get_execution_job_status(
    job_id: int,
    current_user=Depends(require_auth_with_scopes({"execution:read"})),
    db: Session = Depends(get_db),
):
    job = _get_job_or_404(job_id, db)
    _ensure_project_access(db, job.project_id, current_user.id)
    _apply_status_from_celery(job, db)
    return job


@router.post("/abort/{job_id}", response_model=ExecutionJobResponse)
def abort_execution_job(
    job_id: int,
    current_user=Depends(require_auth_with_scopes({"execution:write"})),
    db: Session = Depends(get_db),
):
    job = _get_job_or_404(job_id, db)
    _ensure_project_access(db, job.project_id, current_user.id, require_manager=True)

    if job.status in {ExecutionJobStatus.completed, ExecutionJobStatus.failed, ExecutionJobStatus.cancelled}:
        return job

    if job.celery_task_id:
        celery_app.control.revoke(job.celery_task_id, terminate=True)

    if can_transition(job.status, ExecutionJobStatus.cancelled):
        job.status = ExecutionJobStatus.cancelled
        job.cancelled_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(job)

    return job
