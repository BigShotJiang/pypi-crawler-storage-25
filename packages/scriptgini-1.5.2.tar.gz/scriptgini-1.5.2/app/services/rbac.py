from sqlalchemy.orm import Session

from app.models.membership import ProjectMembership, Role, OrganizationMembership
from app.models.organization import Organization
from app.models.project import Project


MANAGER_ROLES = {Role.owner, Role.admin}
READ_ROLES = {Role.owner, Role.admin, Role.member, Role.viewer}


def create_organization(db: Session, user_id: int, name: str, description: str | None = None) -> Organization:
    organization = Organization(name=name, description=description, created_by_user_id=user_id)
    db.add(organization)
    db.flush()

    owner_membership = OrganizationMembership(
        organization_id=organization.id,
        user_id=user_id,
        role=Role.owner,
        is_active=True,
    )
    db.add(owner_membership)
    db.commit()
    db.refresh(organization)
    return organization


def list_user_organizations(db: Session, user_id: int) -> list[Organization]:
    return (
        db.query(Organization)
        .join(OrganizationMembership, OrganizationMembership.organization_id == Organization.id)
        .filter(
            OrganizationMembership.user_id == user_id,
            OrganizationMembership.is_active.is_(True),
        )
        .all()
    )


def get_user_project_membership(db: Session, project_id: int, user_id: int) -> ProjectMembership | None:
    return (
        db.query(ProjectMembership)
        .filter(
            ProjectMembership.project_id == project_id,
            ProjectMembership.user_id == user_id,
            ProjectMembership.is_active.is_(True),
        )
        .first()
    )


def ensure_project_exists(db: Session, project_id: int) -> Project:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="Project not found")
    return project


def list_project_members(db: Session, project_id: int) -> list[ProjectMembership]:
    return (
        db.query(ProjectMembership)
        .filter(ProjectMembership.project_id == project_id)
        .order_by(ProjectMembership.id.asc())
        .all()
    )


def upsert_project_member(
    db: Session,
    project_id: int,
    user_id: int,
    role: Role,
    is_active: bool,
) -> ProjectMembership:
    membership = (
        db.query(ProjectMembership)
        .filter(
            ProjectMembership.project_id == project_id,
            ProjectMembership.user_id == user_id,
        )
        .first()
    )

    if membership is None:
        membership = ProjectMembership(
            project_id=project_id,
            user_id=user_id,
            role=role,
            is_active=is_active,
        )
        db.add(membership)
    else:
        membership.role = role
        membership.is_active = is_active

    db.commit()
    db.refresh(membership)
    return membership


def remove_project_member(db: Session, project_id: int, user_id: int) -> bool:
    membership = (
        db.query(ProjectMembership)
        .filter(
            ProjectMembership.project_id == project_id,
            ProjectMembership.user_id == user_id,
        )
        .first()
    )
    if not membership:
        return False

    db.delete(membership)
    db.commit()
    return True
