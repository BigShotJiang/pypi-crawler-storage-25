""" memorph-bin-win32-x64-msvc """


def main() -> None:
    print("  memorph-bin-win32-x64-msvc  ")
