# pop 框架小红书宣传帖 x3（作者视角）

---

## 帖子 1：创作初衷型 — "我为什么要造这个轮子"

**标题：** 被LangChain逼疯后，我花了几个月写了一个2500行的Agent框架

**正文：**

先说结论：我开源了一个叫 **pop** 的AI Agent框架，今天正式发布1.0。

写它的原因很简单——我受够了。

去年用LangChain给公司搭一个Agent原型，光是理解StateGraph、RunnableSequence、ChannelWrite这些概念就花了两天。代码写完四十多行，回头一看，真正跟业务相关的不到十行，剩下全是在伺候框架。

我就想：一个Agent的本质不就是"模型+工具+循环"吗？为什么要搞这么复杂？

于是我开始写pop。给自己定了几条死规矩：

- 5行代码必须能跑起来一个完整的Agent
- 整个框架代码量不能超过3000行，任何人一下午能读完
- 运行时只允许依赖2个包（httpx + pydantic），多一个都不行
- 国内模型必须原生支持，不能让用户自己去对接

现在的结果：

```python
from pop import Agent, tool

@tool
def search(query: str) -> str:
    return web_search(query)

agent = Agent(model="deepseek:deepseek-chat", tools=[search])
result = agent.run("今天AI圈发生了什么？")
```

没有StateGraph。没有RunnableSequence。没有ChannelWrite。
就是这么几行，一个能用工具的Agent就跑起来了。

框架内置了8家大模型适配：OpenAI、Anthropic、Gemini、DeepSeek、Grok (xAI)、Kimi、MiniMax、智谱GLM。切换模型就改一个字符串，不用装任何额外的包。

多Agent协作我也做了——handoff任务分发、pipeline流水线、debate多Agent辩论、fan_out并行处理——但这些都是你需要的时候才引入，不会一上来就甩你一脸概念。

我给它跑了benchmark：框架开销比LangChain快约300倍，导入速度快约7000倍。数据和脚本都在仓库里，欢迎来质疑。

MIT协议，完全开源，没有任何商业绑定。

GitHub: github.com/WYSIATI/pop
安装: `pip install pop-framework`

造轮子不是目的，解决问题才是。如果你也觉得现有的Agent框架太重了，试试pop，然后告诉我哪里还不够好。

**#开源项目 #AI Agent #Python #大模型开发 #DeepSeek #程序员日常 #独立开发者**

---

## 帖子 2：技术理念型 — "2500行代码够写一个生产级Agent框架吗"

**标题：** 我用2500行代码写了一个Agent框架，支持8家大模型，2个依赖

**正文：**

做pop的时候，朋友说我疯了："LangChain那么大的团队、那么多代码，你一个人写个框架能打？"

我的回答是：不是代码越多越好。

pop整个框架约2500行Python代码。这不是因为功能少，而是因为我逼自己把每个概念都压缩到最简。

核心只有5个概念：

**Agent** — 模型+工具+指令，就是一个能干活的角色
**@tool** — 装饰器定义工具，框架自动提取参数类型和描述
**Runner** — 控制执行循环（用不用都行，Agent.run()内部自带）
**Memory** — 对话记忆，支持内存和文件持久化
**Patterns** — 多Agent协作模式：handoff / pipeline / debate / fan_out / orchestrate

没了。不需要理解adapter、chain、runnable、callback、serializer这些中间层。

我特别在意的几个设计决策：

**1. 零额外依赖安装**
8家大模型（OpenAI / Anthropic / Gemini / DeepSeek / Grok / Kimi / MiniMax / GLM）全部内置，用哪个改字符串就行。不需要 `pip install langchain-openai` 再 `pip install langchain-anthropic` 再...

**2. 渐进式复杂度**
简单需求就用简单写法。你只是想调一次API？不用Agent：
```python
from pop import chat
response = chat("deepseek:deepseek-chat", "用一句话解释量子计算")
```
需要工具调用？上Agent。需要多Agent？引入handoff。需要流式？加个stream参数。复杂度是你自己选择引入的，不是框架强塞给你的。

**3. 对国内开发者友好**
DeepSeek、Kimi、MiniMax、智谱GLM——这四家是我第一批适配的。不是后加的，不是"社区贡献的"，是我自己一行一行写的适配代码。因为我自己就在用。

仓库里有完整的benchmark脚本，导入时间、框架开销、代码行数对比都可以自己复现。

GitHub: github.com/WYSIATI/pop
MIT开源，`pip install pop-framework`

如果你读过源码觉得哪里可以更简，欢迎来提PR。这个框架不是要做大而全，而是要在"够用"和"简洁"之间找到那条线。

**#开源框架 #Agent开发 #Python #极简主义 #AI架构 #技术分享 #大模型**

---

## 帖子 3：实战演示型 — "看我现场搭一个多Agent系统"

**标题：** 十几行代码搭一个能自动分流的多Agent客服系统，手把手演示

**正文：**

今天用我自己写的pop框架，现场演示搭一个智能客服系统。

需求很简单：用户发消息进来，系统自动判断是账单问题还是技术问题，然后转给对应的专家Agent处理。

先定义两个工具：
```python
from pop import Agent, tool, handoff

@tool
def lookup_invoice(invoice_id: str) -> str:
    """根据ID查询发票信息"""
    return db.query(invoice_id)

@tool
def check_logs(error_code: str) -> str:
    """查询系统日志定位错误"""
    return logs.search(error_code)
```

然后创建两个专家Agent：
```python
billing = Agent(
    model="deepseek:deepseek-chat",
    tools=[lookup_invoice],
    instructions="你负责处理账单和支付相关问题",
)

tech = Agent(
    model="deepseek:deepseek-chat",
    tools=[check_logs],
    instructions="你负责技术支持和故障排查",
)
```

最后一个分流Agent，用handoff串起来：
```python
triage = Agent(
    model="deepseek:deepseek-chat",
    tools=[
        handoff(billing, when="账单或支付问题"),
        handoff(tech, when="技术问题或报错"),
    ],
)

result = triage.run("我被重复扣款了")
# -> 自动路由到billing agent处理
```

完事了。认真的，就这些。

用户说"我被重复扣款了"，triage自动识别这是账单问题，handoff给billing agent，billing调用lookup_invoice去查数据库，然后返回结果。整个过程对用户透明。

这就是我设计pop时最在意的事——**你的代码应该长得跟你的思路一样**。想法是"分流到对应专家"，代码就该直接表达"分流到对应专家"，中间不需要经过三层抽象和五个配置文件。

如果还需要对话记忆，加两行：
```python
from pop import MemoryStore
triage = Agent(..., memory=MemoryStore())
```

需要流式输出？run改成stream：
```python
async for event in triage.stream("我的服务器报500了"):
    print(event)
```

这就是渐进式复杂度——你的需求有多复杂，代码就有多复杂，不多不少。

GitHub: github.com/WYSIATI/pop
安装: `pip install pop-framework`
MIT开源，欢迎Star和Issue

**#AI Agent #多Agent系统 #智能客服 #DeepSeek #Python教程 #开源项目 #技术干货**

---

## 帖子 4：Coding Agent视角 — "让AI自己写Agent代码"

**标题：** 我写了一个专门给Claude/Cursor用的Agent框架，AI写Agent代码的效率直接起飞

**正文：**

分享一个我做pop框架时的核心设计思路，可能跟你见过的所有Agent框架都不一样：

**pop不只是给人写的，它是给coding agent写的。**

什么意思？现在越来越多人用Claude、Cursor、Copilot来写代码。你跟AI说"帮我搭一个能查天气的Agent"，AI去翻LangChain的文档，一堆抽象层、一堆继承关系、一堆隐式约定——AI也懵。

所以我在pop的仓库里放了一个文件叫 **SKILLS.md**。

这个文件不是给人看的README，而是专门为coding agent写的完整API指南。一个文件，从安装到工具定义到多Agent模式到流式事件到Memory，所有你能用到的东西全在里面，带完整代码示例。

你在Cursor或Claude Code里直接说："读一下SKILLS.md，然后帮我搭一个多Agent客服系统"——AI读完这一个文件，就能直接开始写，不需要再去翻三十个文档页面。

这背后的逻辑是：

**1. 整个API只有5个核心概念**
Agent、@tool、Runner、Memory、Patterns。AI不需要理解几十个类和它们之间的继承关系，五个概念就是全部。

**2. 命名即语义**
`handoff(billing, when="账单问题")` —— 不管是人还是AI，看一眼就知道这行代码在干什么。不需要查文档才能理解 `ChannelWrite` 或 `RunnablePassthrough` 是什么意思。

**3. 一个文件搞定所有import**
```python
from pop import (
    Agent, tool, Runner, run,
    handoff, pipeline, orchestrate, debate, fan_out,
    chain, route, parallel,
    chat, model,
)
```
所有东西都从 `pop` 导入，AI不需要猜"这个函数在哪个子模块里"。

**4. 类型完备，AI能自动推断**
`@tool` 装饰器自动从函数签名和docstring生成JSON Schema。AI写一个带类型标注的函数，加个 `@tool` 就完事了，不需要手动定义schema。

实际效果：我现在做项目，基本都是在Cursor里说一句话，AI读SKILLS.md然后直接帮我生成整个Agent系统。从工具定义到多Agent编排到流式输出，一气呵成，几乎不用手动改。

这才是2026年Agent框架该有的样子——**不只是人能用，AI也要能用得顺手。**

GitHub: github.com/WYSIATI/pop
安装: `pip install pop-framework`

试试把SKILLS.md丢给你的coding agent，看看它写出来的代码质量。我觉得你会惊喜。

**#AI Agent #Cursor #Claude #Copilot #Coding Agent #开源框架 #AI编程 #程序员效率**

---

### 发布建议

| 帖子 | 角度 | 适合场景 | 预期互动 |
|------|------|----------|----------|
| 帖子1 | 创作故事 | 首发帖，建立人设和信任 | 评论共鸣、收藏 |
| 帖子2 | 技术理念 | 技术社区传播，吸引高质量关注 | 转发、讨论 |
| 帖子3 | 实战教程 | 降低尝试门槛，引导实际使用 | 收藏、提问 |
| 帖子4 | Coding Agent | 切中AI编程热点，差异化传播 | 转发、尝试 |

**配图建议：** 代码截图用深色主题（VS Code / Cursor），贴一张终端运行截图增加真实感，benchmark对比可以做成简洁的卡片图。
