"""Module containing utility methods to support playlist2podcast."""

from pathlib import Path
from typing import Annotated

import msgspec
import msgspec.json
import msgspec.toml
from cyclopts import App
from cyclopts import Parameter

from playlist2podcast.playlist_2_podcast import Config

app = App()


@app.default
def convert_json_to_toml(
    *,
    json_config_path: Annotated[
        Path,
        Parameter(help="Path to old style JSON configuration file"),
    ],
    toml_config_path: Annotated[
        Path,
        Parameter(help="Path to new style TOML configuration file"),
    ],
) -> None:
    """Convert old JSON based configuration to new TOML based configuration."""
    with json_config_path.open("r") as json_file:
        toml_config = msgspec.json.decode(json_file.read(), type=Config)

    with toml_config_path.open("wb") as toml_config_file:
        toml_config_file.write(msgspec.toml.encode(toml_config))


def convert_to_toml() -> None:
    """Start config converter."""
    app()
