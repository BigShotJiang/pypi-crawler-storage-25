# Tribulnation Hibachi SDK

> An SDK to connect Hibachi with the Tribulnation ecosystem.

🚧 Under construction.