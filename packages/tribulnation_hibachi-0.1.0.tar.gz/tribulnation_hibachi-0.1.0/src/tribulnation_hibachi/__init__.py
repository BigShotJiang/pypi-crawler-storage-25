"""
### Tribulnation Hibachi
> An SDK to connect Hibachi with the Tribulnation ecosystem.

- Details
"""