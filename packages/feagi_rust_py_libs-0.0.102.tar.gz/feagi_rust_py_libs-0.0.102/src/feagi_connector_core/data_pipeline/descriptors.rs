// Only numbers, aren't worth porting
