"""Telegram client connection management."""
