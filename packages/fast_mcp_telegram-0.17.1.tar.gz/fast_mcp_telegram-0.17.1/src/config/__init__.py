"""Configuration and settings management."""
