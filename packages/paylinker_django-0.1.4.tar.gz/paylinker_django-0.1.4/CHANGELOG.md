# Changelog

All notable changes to **paylinker-django** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.4] - 2026-05-25

### Fixed
- `DjangoPaymeTransactionHandler.check_transaction` now returns `perform_time=0`
  when `state=-1` (CANCELLED_BEFORE_PERFORM). Per Payme spec, `perform_time`
  must be 0 for a transaction that was never performed before cancellation.
- `create_transaction` now checks for an existing active transaction
  (`state=CREATED`) for the same order before creating a new one, returning
  error `-31099` ("Order already pending payment") as required by Payme spec.

## [0.1.3] - 2026-05-23

### Fixed
- `DjangoPaymeTransactionHandler._get_transaction` no longer calls
  `select_for_update()` unconditionally. It now accepts a `for_update` flag
  (default `False`) and only acquires a row lock when called from
  `perform_transaction` and `cancel_transaction` (both wrapped in
  `@transaction.atomic`). Calling it from `check_transaction` (no active
  transaction) previously raised `TransactionManagementError`.

### Migrations
- `0002` — renames the `ProviderTransaction` composite index to a shorter name
  to stay within database identifier limits.

## [0.1.2] - 2026-05-17

### Fixed
- `DjangoClickOrderValidator.check_duplicate` now only matches completed
  transactions (`state=1`). Previously it matched prepared-but-not-completed
  records (`state=0`), causing `_handle_complete` to skip `on_complete`
  entirely and leave payments permanently pending.
- `DjangoClickOrderValidator.on_prepare` now uses `get_or_create` instead of
  `create`, so a resent Prepare request returns the same `prepare_id` without
  raising `IntegrityError` (the model has a unique constraint on
  `provider + external_id`).

## [0.1.1] - 2026-05-11

### Changed
- Removed the `django<6.0` upper bound from install requirements.
  The package now declares `django>=4.2` so installations on projects
  pinning Django 6.x are no longer blocked by a dependency conflict.

## [0.1.0] - 2026-05-08

### Added
- Initial release.
- Reusable Django app (`paylinker_django`) integrating the
  [`paylinker`](https://pypi.org/project/paylinker/) core SDK.
- `ProviderTransaction` model + initial migration tracking Payme/Click
  transaction lifecycle, decoupled from any project's Order model.
- `DjangoPaymeTransactionHandler` — implements paylinker's full
  `TransactionHandler` protocol with idempotent state transitions.
- `DjangoClickOrderValidator` — implements paylinker's `OrderValidator`
  protocol with `select_for_update` locking on prepare/complete/cancel.
- Webhook views (`payme_webhook`, `click_webhook`) plus URL include
  (`paylinker_django.urls`).
- Single-dict `PAYLINKER` settings API with helper accessors
  (`get_payme_config`, `get_click_config`, `get_handler_class`).
- Django admin registration for `ProviderTransaction`.
- PEP 561 typing (`py.typed`).

[Unreleased]: https://github.com/tohirbek/paylinker-django/compare/v0.1.4...HEAD
[0.1.4]: https://github.com/tohirbek/paylinker-django/compare/v0.1.3...v0.1.4
[0.1.3]: https://github.com/tohirbek/paylinker-django/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/tohirbek/paylinker-django/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/tohirbek/paylinker-django/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/tohirbek/paylinker-django/releases/tag/v0.1.0