"""Regression tests for DjangoPaymeTransactionHandler."""
import pytest
from paylinker.providers.payme.rpc_handler import PaymeError
from paylinker_django.handlers.payme import DjangoPaymeTransactionHandler
from paylinker_django.models import ProviderTransaction


class _Handler(DjangoPaymeTransactionHandler):
    def validate_order(self, order_id: str, amount_tiyin: int) -> None:
        pass

    def on_payment_performed(self, provider_tx: ProviderTransaction) -> None:
        pass

    def on_payment_cancelled(self, provider_tx, reason, was_performed) -> None:
        pass


ACCOUNT = {"order_id": "order-99"}


@pytest.fixture
def handler(settings):
    settings.PAYLINKER = {
        "PAYME": {"merchant_id": "test", "merchant_key": "key"},
        "CLICK": {"merchant_id": 1, "service_id": 2, "secret_key": "s"},
        "ACCOUNT_FIELD": "order_id",
    }
    return _Handler()


@pytest.mark.django_db
def test_create_transaction_returns_error_when_order_pending(handler):
    """CreateTransaction must return -31099 if the order already has an active transaction."""
    handler.create_transaction("payme-tx-1", 1_000_000_000, 100_000, ACCOUNT)

    with pytest.raises(PaymeError) as exc_info:
        handler.create_transaction("payme-tx-2", 1_000_000_001, 100_000, ACCOUNT)

    assert exc_info.value.code == -31099


@pytest.mark.django_db
def test_create_transaction_idempotent_same_payme_id(handler):
    """Resending CreateTransaction with the same payme_id must succeed (idempotent)."""
    result1 = handler.create_transaction("payme-tx-3", 1_000_000_000, 100_000, ACCOUNT)
    result2 = handler.create_transaction("payme-tx-3", 1_000_000_000, 100_000, ACCOUNT)
    assert result1.transaction == result2.transaction


@pytest.mark.django_db
def test_create_transaction_allowed_after_cancellation(handler):
    """After cancellation a new CreateTransaction for the same order must succeed."""
    handler.create_transaction("payme-tx-4", 1_000_000_000, 100_000, ACCOUNT)
    handler.cancel_transaction("payme-tx-4", reason=1)

    result = handler.create_transaction("payme-tx-5", 1_000_000_001, 100_000, ACCOUNT)
    assert result.state == 1


@pytest.mark.django_db
def test_check_transaction_perform_time_zero_when_cancelled_before_perform(handler):
    """CheckTransaction must return perform_time=0 for state=-1 (cancelled before perform)."""
    handler.create_transaction("payme-tx-6", 1_000_000_000, 100_000, ACCOUNT)
    handler.cancel_transaction("payme-tx-6", reason=3)

    result = handler.check_transaction("payme-tx-6")
    assert result.state == -1
    assert result.perform_time == 0
    assert result.cancel_time > 0
    assert result.reason == 3


@pytest.mark.django_db
def test_check_transaction_perform_time_nonzero_when_cancelled_after_perform(handler):
    """CheckTransaction must return real perform_time for state=-2 (cancelled after perform)."""
    handler.create_transaction("payme-tx-7", 1_000_000_000, 100_000, ACCOUNT)
    handler.perform_transaction("payme-tx-7")
    handler.cancel_transaction("payme-tx-7", reason=3)

    result = handler.check_transaction("payme-tx-7")
    assert result.state == -2
    assert result.perform_time > 0
    assert result.cancel_time > 0
    assert result.reason == 3