import os

import streamlit as st
from groq import Groq
from gtts import gTTS
import io
def create_vai(api_key, title):
    client = Groq(api_key=api_key)



    st.title(title)

    i1 = st.audio_input("Speak anything")

    if i1:
        # 1. Transcribe Audio (Speech-to-Text) using Whisper on Groq
        audio_bytes = i1.read()
        transcription = client.audio.transcriptions.create(
            file=("audio.wav", audio_bytes),
            model="whisper-large-v3",  # High-speed transcription model
            response_format="text"
        )
        st.write(f"**You said:** {transcription}")

        # 2. Get AI Response using Llama 3
        # 2. Get AI Response using the latest Llama 3.1 model
        chat_completion = client.chat.completions.create(
            messages=[
                {"role": "user", "content": transcription}
            ],
            model="llama-3.1-8b-instant",  # Updated to the current supported model
        )

        ai_text = chat_completion.choices[0].message.content
        st.write(f"**AI Response:** {ai_text}")

        # 3. Text-to-Speech (TTS)
        tts = gTTS(text=ai_text, lang='en')
        audio_fp = io.BytesIO()
        tts.write_to_fp(audio_fp)

        st.audio(audio_fp, format="audio/mp3")