"""
Workflow builder: generic factory from WorkflowDefinition to WorkflowOrchestrator.

Replaces all domain-specific build_workflow() variants with a single
adapter-agnostic factory that takes explicit registries.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from atomicguard.application.action_pair import ActionPair
from atomicguard.application.workflow import StepCallback, WorkflowOrchestrator
from atomicguard.domain.prompts import PromptTemplate
from atomicguard.guards.composite import CompositeGuard

if TYPE_CHECKING:
    from atomicguard.application.workflow import StepCallback
    from atomicguard.domain.interfaces import (
        ArtifactDAGInterface,
        GeneratorInterface,
        GuardInterface,
    )
    from atomicguard.domain.models import (
        ActionPairDefinition,
        APContextEntry,
        WorkflowDefinition,
    )

logger = logging.getLogger(__name__)


def build_orchestrator(
    definition: WorkflowDefinition,
    ap_context: dict[str, APContextEntry],
    generator_registry: dict[str, GeneratorInterface],
    guard_registry: dict[str, GuardInterface],
    artifact_dag: ArtifactDAGInterface,
    step_callback: StepCallback | None = None,
) -> WorkflowOrchestrator:
    """Build a configured WorkflowOrchestrator from a definition and registries.

    This is the single generic factory that replaces every domain-specific
    ``build_workflow()`` variant.  The caller (CLI adapter, web adapter, gym)
    provides the registries; this function does the AP-assembly loop.

    Args:
        definition: Declarative workflow specification.
        ap_context: Prompt template context keyed by ``ap_id``.
        generator_registry: Map of generator name → concrete instance.
        guard_registry: Map of guard name → concrete instance.
        artifact_dag: Artifact storage implementation.
        step_callback: Optional callback passed to the orchestrator
            (see ``WorkflowOrchestrator.__init__``).

    Returns:
        A fully configured ``WorkflowOrchestrator`` ready to ``execute()``.

    Raises:
        KeyError: If a generator or guard referenced by the definition
            is not found in the provided registries.
    """
    orchestrator = WorkflowOrchestrator(
        artifact_dag,
        rmax=definition.rmax,
        constraints=definition.constraints,
        step_callback=step_callback,
    )

    for ap_def in definition.action_pairs:
        generator = _resolve_generator(ap_def, generator_registry)
        guard = _resolve_guard(ap_def, guard_registry)
        template = _build_prompt_template(ap_context.get(ap_def.ap_id))

        action_pair = ActionPair(
            generator=generator,
            guard=guard,
            prompt_template=template,
        )

        orchestrator.add_step(
            guard_id=ap_def.ap_id,
            action_pair=action_pair,
            requires=ap_def.requires,
            r_patience=ap_def.r_patience,
            e_max=ap_def.e_max,
            escalate_feedback_to=ap_def.escalate_feedback_to,
            escalate_feedback_by_guard=(
                ap_def.escalate_feedback_by_guard
                if ap_def.escalate_feedback_by_guard
                else None
            ),
            group=ap_def.group or None,
            artifact_type=ap_def.artifact_type or None,
            goal=ap_def.goal,
        )

    return orchestrator


def _resolve_generator(
    ap_def: ActionPairDefinition,
    registry: dict[str, GeneratorInterface],
) -> GeneratorInterface:
    """Look up the generator for an action pair definition.

    Raises:
        KeyError: If the generator name is not in the registry.
    """
    name = ap_def.generator
    if name not in registry:
        available = ", ".join(sorted(registry)) or "(none)"
        raise KeyError(
            f"Generator '{name}' required by AP '{ap_def.ap_id}' "
            f"not found in registry. Available: {available}"
        )
    return registry[name]


def _resolve_guard(
    ap_def: ActionPairDefinition,
    registry: dict[str, GuardInterface],
) -> GuardInterface:
    """Resolve guard(s) for an action pair definition.

    Handles both single guards (``ap_def.guard``) and composite guards
    (``ap_def.guards`` list).

    Raises:
        KeyError: If any guard name is not in the registry.
    """
    # Composite guards: ap_def.guards is a list of guard names
    if ap_def.guards:
        guard_names = _parse_guard_names(ap_def.guards)
        if len(guard_names) == 1:
            return _get_guard(guard_names[0], ap_def.ap_id, registry)
        sub_guards = [_get_guard(name, ap_def.ap_id, registry) for name in guard_names]
        return CompositeGuard(*sub_guards)

    # Single guard
    if ap_def.guard:
        return _get_guard(ap_def.guard, ap_def.ap_id, registry)

    raise KeyError(f"AP '{ap_def.ap_id}' has neither 'guard' nor 'guards' defined.")


def _parse_guard_names(guards: object) -> list[str]:
    """Extract guard names from the guards field.

    The field can be a list of strings or a CompositeGuardSpec dict
    with a ``guards`` key containing a list of guard name strings
    or dicts with a ``guard`` key.
    """
    if isinstance(guards, list):
        result = []
        for item in guards:
            if isinstance(item, str):
                result.append(item)
            elif isinstance(item, dict) and "guard" in item:
                result.append(item["guard"])
            else:
                result.append(str(item))
        return result

    if isinstance(guards, dict) and "guards" in guards:
        return _parse_guard_names(guards["guards"])

    return [str(guards)]


def _get_guard(
    name: str,
    ap_id: str,
    registry: dict[str, GuardInterface],
) -> GuardInterface:
    """Look up a single guard by name.

    Raises:
        KeyError: If the guard name is not in the registry.
    """
    if name not in registry:
        available = ", ".join(sorted(registry)) or "(none)"
        raise KeyError(
            f"Guard '{name}' required by AP '{ap_id}' "
            f"not found in registry. Available: {available}"
        )
    return registry[name]


def _build_prompt_template(
    ctx: APContextEntry | None,
) -> PromptTemplate:
    """Build a PromptTemplate from an APContextEntry.

    If no context entry exists, returns a minimal template.
    """
    if ctx is None:
        return PromptTemplate(role="", constraints="", task="")

    return PromptTemplate(
        role=ctx.role,
        constraints=ctx.constraints,
        task=ctx.task,
        feedback_wrapper=ctx.feedback_wrapper or None,
        escalation_feedback_wrapper=ctx.escalation_feedback_wrapper or None,
        feedback_mode=ctx.feedback_mode or "inline",
    )
