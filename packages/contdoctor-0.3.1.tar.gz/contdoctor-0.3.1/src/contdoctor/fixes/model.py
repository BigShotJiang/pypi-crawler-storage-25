"""Model-related auto-fixes: warmup, reload (unload + warmup).

``fix_warmup_model`` does a post-warmup ``/api/ps`` verify so the runner
doesn't accept a model that loaded onto CPU as "fixed". When the verify
flags ``gpu_pct < 95``, the fix returns False and the recursive loop
either retries via ``fix_reload_model`` or surfaces the
``ollama_num_gpu_insufficient`` symptom (Modelfile-level remediation).
"""

import json
import time

from contdoctor.core.http import http_get, http_post_json
from contdoctor.core.symbols import S_FAIL, S_FIX, S_OK, S_WARN

# Below this percentage we treat the model as "ran on CPU"; same threshold
# as ``check_model_loaded`` so the diagnostic and the fix agree.
GPU_PCT_OK_THRESHOLD = 95


def _gpu_pct(model: str) -> int | None:
    """Read ``gpu_pct`` for ``model`` from ``/api/ps``. None on any failure."""
    status, body = http_get("/api/ps", timeout=3)
    if status != 200 or not body:
        return None
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        return None
    target = next((m for m in data.get("models", []) if m.get("name") == model), None)
    if not target:
        return None
    size = target.get("size", 0)
    size_vram = target.get("size_vram", 0)
    if not size:
        return 0
    return int(round(100 * size_vram / size))


def fix_warmup_model(model: str) -> bool:
    print(f"  {S_FIX} {model} warmup (60s timeout)…")
    status, body = http_post_json(
        "/api/generate",
        {"model": model, "prompt": "ok", "stream": False,
         "options": {"num_predict": 1}},
        timeout=60,
    )
    if status != 200:
        print(f"  {S_FAIL} warmup başarısız (status={status}, err={body})")
        return False

    pct = _gpu_pct(model)
    if pct is None:
        # Couldn't introspect — be optimistic, the warmup HTTP succeeded.
        print(f"  {S_OK} model yüklendi (gpu_pct doğrulanamadı)")
        return True
    if pct < GPU_PCT_OK_THRESHOLD:
        print(
            f"  {S_WARN} model yüklendi ama %{pct} GPU — kalan kısım CPU'da. "
            f"Modelfile-düzeyi GPU layer remediation gerekli."
        )
        return False
    print(f"  {S_OK} model yüklendi, %{pct} GPU")
    return True


def fix_reload_model(model: str) -> bool:
    print(f"  {S_FIX} {model} unload ediliyor…")
    http_post_json(
        "/api/generate",
        {"model": model, "prompt": "", "stream": False, "keep_alive": 0},
        timeout=10,
    )
    time.sleep(2)
    return fix_warmup_model(model)


__all__ = ["GPU_PCT_OK_THRESHOLD", "fix_warmup_model", "fix_reload_model"]
