"""Auto-fixes — only safe operations: env vars, ollama restart, warmup, reload.

``print_remediation`` is a deliberately *non-fix* action: it prints
copy-paste instructions to stdout and returns True without changing any
state. Banka rule: doctor sandbox dışına müdahale etmez.
"""

from contdoctor.fixes.model import fix_reload_model, fix_warmup_model
from contdoctor.fixes.ollama import (
    fix_restart_ollama,
    fix_set_ollama_num_gpu,
    fix_start_ollama,
)
from contdoctor.fixes.remediation import print_remediation

# Names referenced from YAML knowledge (`fix.action`) MUST be exported here.
FIX_ACTIONS = {
    "fix_start_ollama": fix_start_ollama,
    "fix_restart_ollama": fix_restart_ollama,
    "fix_set_ollama_num_gpu": fix_set_ollama_num_gpu,
    "fix_warmup_model": fix_warmup_model,
    "fix_reload_model": fix_reload_model,
    "print_remediation": print_remediation,
}

__all__ = [
    "fix_start_ollama",
    "fix_restart_ollama",
    "fix_set_ollama_num_gpu",
    "fix_warmup_model",
    "fix_reload_model",
    "print_remediation",
    "FIX_ACTIONS",
]
