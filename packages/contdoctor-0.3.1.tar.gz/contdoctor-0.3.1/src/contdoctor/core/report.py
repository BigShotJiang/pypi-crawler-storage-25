"""Human-readable and JSON reporting helpers."""

from typing import List

from contdoctor.core.result import CheckResult
from contdoctor.core.symbols import BOLD, RESET, S_FIX


def print_human_report(results: List[CheckResult], verbose: bool = False) -> None:
    print()
    print(f"{BOLD}🩺 Cont Doctor — Sağlık Taraması{RESET}")
    print("─" * 70)
    for r in results:
        name = r.name if len(r.name) <= 32 else r.name[:29] + "..."
        print(f"  {r.symbol} {name:<32s} {r.message}")
        if r.diagnosis:
            for line in r.diagnosis.rstrip().splitlines():
                print(f"      › {line}")
        if verbose and r.details:
            for k, v in r.details.items():
                print(f"      {k} = {v}")
    print("─" * 70)
    counts = {"ok": 0, "warn": 0, "fail": 0}
    for r in results:
        counts[r.status] += 1
    print(f"  Özet: {counts['ok']} OK · {counts['warn']} uyarı · {counts['fail']} hata")
    fixable = [r for r in results if r.fix_action or r.fix_label]
    if fixable:
        print()
        print(f"{BOLD}{S_FIX} Otomatik düzeltilebilir:{RESET}")
        for r in fixable:
            label = r.fix_label or "(YAML)"
            print(f"    [{r.name}] {label}")
            if r.fallback_fix_label:
                print(f"      ↳ fallback: {r.fallback_fix_label}")
        print()
        print("  Uygulamak için: contdoctor --fix")


def results_to_json(results: List[CheckResult]) -> list:
    """Build the JSON-serialisable payload for ``--json`` mode."""
    return [
        {
            "name": r.name,
            "status": r.status,
            "message": r.message,
            "fix_label": r.fix_label,
            "fallback_fix_label": r.fallback_fix_label,
            "details": r.details,
            "diagnosis": r.diagnosis,
            "matched_symptoms": list(r.matched_symptoms),
        }
        for r in results
    ]


__all__ = ["print_human_report", "results_to_json"]
