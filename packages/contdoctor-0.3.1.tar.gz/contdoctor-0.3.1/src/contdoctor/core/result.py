"""CheckResult dataclass — the unit of every diagnostic."""

from dataclasses import dataclass, field
from typing import Callable, Optional

from contdoctor.core.symbols import S_FAIL, S_OK, S_WARN


@dataclass
class CheckResult:
    name: str
    status: str  # "ok" | "warn" | "fail"
    message: str
    fix_label: Optional[str] = None
    fix_action: Optional[Callable[[], bool]] = None
    details: dict = field(default_factory=dict)
    diagnosis: Optional[str] = None
    matched_symptoms: list = field(default_factory=list)
    # Sprint 5.1 failover chain: when ``fix_action`` (typically Python-side)
    # returns False, the runner invokes ``fallback_fix_action`` (typically a
    # YAML ``print_remediation`` closure). Sprint 1 "additive" semantics
    # preserved — fallback is set only when a Python-side fix already exists.
    fallback_fix_label: Optional[str] = None
    fallback_fix_action: Optional[Callable[[], bool]] = None

    @property
    def symbol(self) -> str:
        return {"ok": S_OK, "warn": S_WARN, "fail": S_FAIL}[self.status]


__all__ = ["CheckResult"]
