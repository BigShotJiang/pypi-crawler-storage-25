"""Check orchestrator: CHECKS dict, GATES dict, run_checks()."""

from typing import List, Optional

from contdoctor.checks import (
    check_binary_path,
    check_codent_version,
    check_contdoctor_version,
    check_disk_space,
    check_glibc,
    check_gpu,
    check_model_loaded,
    check_model_registered,
    check_model_responds,
    check_network_isolation,
    check_ollama_api,
    check_ollama_env,
    check_ollama_installed,
    check_ollama_process,
    check_ollama_version,
    check_python_env,
)
from contdoctor.core.result import CheckResult
from contdoctor.core.symbols import S_WARN

# Sıralama önemli: alt katmandan üste — donanım → process → API → model →
# system → deployment. Deployment check'leri runtime check'lerinden gate'siz
# bağımsız (GATES dict'inde yok).
CHECKS = {
    "gpu":                 (lambda a: check_gpu()),
    "ollama_bin":          (lambda a: check_ollama_installed()),
    "ollama_ver":          (lambda a: check_ollama_version()),
    "ollama_proc":         (lambda a: check_ollama_process()),
    "ollama_env":          (lambda a: check_ollama_env()),
    "ollama_api":          (lambda a: check_ollama_api()),
    "model_reg":           (lambda a: check_model_registered(a.model)),
    "model_loaded":        (lambda a: check_model_loaded(a.model)),
    "model_responds":      (lambda a: check_model_responds(a.model)),
    "disk":                (lambda a: check_disk_space()),
    "glibc":               (lambda a: check_glibc()),
    "network":             (lambda a: check_network_isolation()),
    "python":              (lambda a: check_python_env()),
    "contdoctor_version":  (lambda a: check_contdoctor_version()),
    "codent_version":      (lambda a: check_codent_version()),
    "binary_path":         (lambda a: check_binary_path()),
}

# Triage: alt katman fail ise üst katmanı koşmanın anlamı yok.
GATES = {
    "ollama_api":     ["ollama_proc"],
    "model_reg":      ["ollama_api"],
    "model_loaded":   ["ollama_api", "model_reg"],
    "model_responds": ["ollama_api", "model_reg", "model_loaded"],
}


def run_checks(args, names: List[str], symptoms: Optional[list] = None) -> List[CheckResult]:
    """Run the requested checks, applying YAML symptom enrichment after each.

    ``symptoms`` is the loaded list of :class:`Symptom` objects (None or empty
    means: no enrichment). The matcher itself is imported lazily to keep the
    runner usable in tests that don't touch knowledge.
    """
    results: List[CheckResult] = []
    by_name: dict[str, CheckResult] = {}
    apply_symptoms = None
    if symptoms:
        from contdoctor.knowledge.matcher import apply_symptoms as _apply

        apply_symptoms = _apply

    for key in names:
        if key not in CHECKS:
            print(f"{S_WARN} bilinmeyen check key: {key}")
            continue
        gates = GATES.get(key, [])
        blocked_by = next(
            (g for g in gates if g in by_name and by_name[g].status != "ok"),
            None,
        )
        if blocked_by:
            r = CheckResult(key, "warn", f"atlandı (önkoşul ok değil: {blocked_by})")
        else:
            try:
                r = CHECKS[key](args)
            except Exception as e:  # noqa: BLE001
                r = CheckResult(key, "fail", f"check exception: {type(e).__name__}: {e}")
        if apply_symptoms is not None:
            r = apply_symptoms(r, symptoms, key)
        results.append(r)
        by_name[key] = r
    return results


__all__ = ["CHECKS", "GATES", "run_checks"]
