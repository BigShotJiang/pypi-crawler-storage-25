"""argparse entry point — preserves the prototype's flags and exit codes."""

import argparse
import json
import sys
from typing import List

from contdoctor.checks.model import DEFAULT_MODEL
from contdoctor.core.report import print_human_report, results_to_json
from contdoctor.core.result import CheckResult
from contdoctor.core.runner import CHECKS, run_checks
from contdoctor.core.symbols import BOLD, RESET, S_FAIL, S_FIX, S_INFO, S_OK, S_WARN
from contdoctor.knowledge import KnowledgeError, default_symptoms


MAX_FIX_ITERATIONS = 5


def _apply_fixes(results: List[CheckResult]) -> None:
    """Run each result's ``fix_action``. If it returns False (or raises)
    and a ``fallback_fix_action`` is set, run the fallback as well —
    Sprint 5.1 failover chain so YAML ``print_remediation`` instructions
    actually surface when a Python-side fix can't resolve the issue.
    """
    for r in results:
        if not r.fix_action:
            continue
        print(f"\n{S_FIX} {BOLD}[{r.name}]{RESET} {r.fix_label or ''}")
        primary_ok = False
        try:
            primary_ok = bool(r.fix_action())
        except Exception as e:  # noqa: BLE001
            print(f"  {S_FAIL} fix exception: {type(e).__name__}: {e}")
        if primary_ok:
            print(f"  → {S_OK} düzeltildi")
            continue
        if r.fallback_fix_action is None:
            print(f"  → {S_FAIL} başarısız")
            continue
        print(
            f"  → {S_FAIL} Python fix başarısız, fallback uygulanıyor: "
            f"{r.fallback_fix_label or ''}"
        )
        try:
            fb_ok = bool(r.fallback_fix_action())
            print(f"  → {S_OK if fb_ok else S_FAIL} fallback "
                  f"{'uygulandı' if fb_ok else 'başarısız'}")
        except Exception as e:  # noqa: BLE001
            print(f"  → {S_FAIL} fallback exception: {type(e).__name__}: {e}")


def _fixable_set(results: List[CheckResult]) -> frozenset:
    """Identifier set of currently auto-fixable check names — used to
    detect lack of progress between iterations."""
    return frozenset(r.name for r in results if r.fix_action)


def _recursive_fix_loop(
    args, names: List[str], symptoms, initial_results: List[CheckResult]
):
    """Apply fixes until convergence (no fixable results) or a stop
    condition kicks in. Returns ``(final_results, exit_code)``.

    Stop conditions:
      * fixed-point: nothing left to fix → exit 0/1/2 by status.
      * no progress: same fixable set two turns in a row → break, stderr.
      * max iterations: ``MAX_FIX_ITERATIONS`` reached → break, stderr.
    """
    results = initial_results
    prev_fix_set: frozenset | None = None

    for iteration in range(1, MAX_FIX_ITERATIONS + 1):
        fix_set = _fixable_set(results)
        if not fix_set:
            if iteration == 1:
                print(f"\n{S_INFO} otomatik düzeltilebilir bir şey yok")
            else:
                print(f"\n{S_OK} {BOLD}fixed-point — tüm fix'ler uygulandı{RESET}")
            print_human_report(results, verbose=args.verbose)
            return results, _exit_code_from_results(results)

        if fix_set == prev_fix_set:
            print_human_report(results, verbose=args.verbose)
            sys.stderr.write(
                f"\n{S_WARN} fix'ler {len(fix_set)} sorunu çözmedi: "
                f"{', '.join(sorted(fix_set))}\n"
                "Manuel müdahale gerekli — diagnosis ve steps yukarıdaki raporda.\n"
            )
            return results, 2

        if iteration > 1:
            print_human_report(results, verbose=args.verbose)
        print(
            f"\n{BOLD}{S_FIX} iterasyon {iteration}/{MAX_FIX_ITERATIONS}: "
            f"{len(fix_set)} fix uygulanıyor…{RESET}"
        )
        _apply_fixes(results)
        prev_fix_set = fix_set
        print(f"\n{S_INFO} yeniden tarama…")
        results = run_checks(args, names, symptoms=symptoms)

    # MAX_FIX_ITERATIONS aşıldı.
    print_human_report(results, verbose=args.verbose)
    sys.stderr.write(
        f"\n{S_WARN} {MAX_FIX_ITERATIONS} iterasyondan sonra fixed-point'e "
        f"ulaşılamadı.\n"
    )
    return results, 2


def _exit_code_from_results(results: List[CheckResult]) -> int:
    if any(r.status == "fail" for r in results):
        return 2
    if any(r.status == "warn" for r in results):
        return 1
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="contdoctor",
        description="Cont Doctor — banka için lokal teşhis ve fix.",
        epilog="Check key'leri: " + ", ".join(CHECKS.keys()),
    )
    parser.add_argument(
        "--fix", action="store_true", help="otomatik düzeltilebilen sorunları düzelt"
    )
    parser.add_argument(
        "--json", action="store_true", help="makine-okunur çıktı (CI/parse)"
    )
    parser.add_argument(
        "--only", default="", help="virgülle ayrılmış check key'leri"
    )
    parser.add_argument(
        "--skip", default="", help="atlanacak check key'leri"
    )
    parser.add_argument(
        "--model", default=DEFAULT_MODEL, help=f"hedef model (default: {DEFAULT_MODEL})"
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    try:
        symptoms = default_symptoms()
    except KnowledgeError as e:
        print(f"contdoctor: knowledge load error: {e}", file=sys.stderr)
        sys.exit(3)

    if args.only:
        names = [x.strip() for x in args.only.split(",") if x.strip()]
    else:
        names = list(CHECKS.keys())
    if args.skip:
        skip = {x.strip() for x in args.skip.split(",")}
        names = [n for n in names if n not in skip]

    results = run_checks(args, names, symptoms=symptoms)

    if args.json:
        print(json.dumps(results_to_json(results), indent=2, ensure_ascii=False))
        sys.exit(2 if any(r.status == "fail" for r in results) else 0)

    print_human_report(results, verbose=args.verbose)

    exit_code = 0
    if any(r.status == "fail" for r in results):
        exit_code = 2
    elif any(r.status == "warn" for r in results):
        exit_code = 1

    if args.fix:
        results, exit_code = _recursive_fix_loop(args, names, symptoms, results)

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
