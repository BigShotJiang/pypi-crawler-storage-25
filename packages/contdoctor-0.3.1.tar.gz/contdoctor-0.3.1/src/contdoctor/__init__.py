"""contdoctor — local diagnostic + auto-fix tool for the Cont Hive."""

__version__ = "0.3.1"

__all__ = ["__version__"]
