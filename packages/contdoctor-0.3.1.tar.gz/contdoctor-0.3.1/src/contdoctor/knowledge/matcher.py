"""Symptom → CheckResult eşleme. Eval YOK; deklaratif op set'i.

After a match, ``diagnosis`` and any ``fix.steps`` strings are run through
``str.format_map`` with a context built from ``result.details`` plus a few
top-level fields. Missing placeholders silently resolve to ``""`` — never
``KeyError``.
"""

from __future__ import annotations

import re
from typing import Any, Callable, List

from contdoctor.core.result import CheckResult
from contdoctor.fixes import FIX_ACTIONS, print_remediation
from contdoctor.knowledge.schema import Op, Symptom

_MISSING = object()


def _resolve_field(result: CheckResult, path: str):
    """Dot notation lookup. Missing path → ``_MISSING`` sentinel.

    Top-level keys map to dataclass attributes (``status``, ``message``,
    ``name``, ``details``); nested keys reach into ``result.details``.
    """
    head, _, rest = path.partition(".")
    if head == "":
        return _MISSING
    if rest == "":
        return getattr(result, head, _MISSING)
    obj: Any = getattr(result, head, _MISSING)
    if obj is _MISSING:
        return _MISSING
    for part in rest.split("."):
        if isinstance(obj, dict):
            if part not in obj:
                return _MISSING
            obj = obj[part]
        else:
            return _MISSING
    return obj


def _evaluate(value: Any, op: Op, expected: Any) -> bool:
    if op is Op.IS_ABSENT:
        return value is _MISSING or value is None
    if value is _MISSING:
        return False
    if op is Op.IS_PRESENT:
        return value is not None
    if op is Op.IS_EMPTY:
        return value == "" or value is None
    if op is Op.EQUALS:
        return value == expected
    if op is Op.IN_LIST:
        try:
            return value in expected
        except TypeError:
            return False
    if op is Op.CONTAINS_SUBSTRING:
        if isinstance(value, str) and isinstance(expected, str):
            return expected in value
        if isinstance(value, list):
            return any(isinstance(item, str) and expected in item for item in value)
        return False
    if op is Op.MATCHES_REGEX:
        if not isinstance(value, str) or not isinstance(expected, str):
            return False
        return re.search(expected, value) is not None
    if op is Op.GT:
        try:
            return value > expected  # type: ignore[operator]
        except TypeError:
            return False
    if op is Op.LT:
        try:
            return value < expected  # type: ignore[operator]
        except TypeError:
            return False
    return False


class _Defaulting(dict):
    """str.format_map mapping that returns ``""`` for missing keys."""
    def __missing__(self, key):  # type: ignore[override]
        return ""


def _build_context(result: CheckResult) -> dict:
    """Flatten ``result.details`` into a format() context.

    Each ``details[X]`` is exposed twice — as ``X`` (short) and
    ``details_X`` (qualified) — so symptom authors can write whichever
    reads better. Top-level CheckResult fields are also exposed.
    """
    ctx: dict = {}
    for k, v in (result.details or {}).items():
        ctx[k] = v
        ctx[f"details_{k}"] = v
    ctx["status"] = result.status
    ctx["name"] = result.name
    ctx["message"] = result.message
    return ctx


def _interpolate(template: str, context: dict) -> str:
    if not isinstance(template, str):
        return str(template)
    try:
        return template.format_map(_Defaulting(context))
    except (IndexError, ValueError):
        return template


def _make_remediation_callable(
    steps: tuple, label: str | None, context: dict
) -> Callable[[], bool]:
    rendered_steps = [_interpolate(s, context) for s in steps]
    rendered_label = _interpolate(label, context) if label else None
    return lambda: print_remediation(rendered_steps, label=rendered_label)


def apply_symptoms(
    result: CheckResult,
    symptoms: List[Symptom],
    check_key: str,
) -> CheckResult:
    """Mutate-in-place: enrich ``result`` with diagnosis / fix from matching rules.

    Sprint 5.1 failover semantics:
      * ``diagnosis`` only set if the result has none yet (Python > YAML).
      * ``matched_symptoms`` records every match.
      * If the result has no Python-side ``fix_action`` yet, the YAML
        symptom's fix becomes the **primary** fix (Sprint 1 behaviour).
      * If a Python-side ``fix_action`` already exists, the YAML symptom's
        fix is attached as ``fallback_fix_action`` instead — invoked only
        when the primary fix returns False.

    For ``print_remediation`` actions, a closure captures interpolated
    steps + label so the runner's no-arg fix-callable contract still holds.
    """
    context_cached: dict | None = None
    for sym in symptoms:
        if sym.check != check_key:
            continue
        value = _resolve_field(result, sym.match.field)
        if not _evaluate(value, sym.match.op, sym.match.value):
            continue
        if context_cached is None:
            context_cached = _build_context(result)
        if sym.id not in result.matched_symptoms:
            result.matched_symptoms.append(sym.id)
        if result.diagnosis is None and sym.diagnosis:
            result.diagnosis = _interpolate(sym.diagnosis.rstrip(), context_cached)

        sym_label = (
            _interpolate(sym.fix.label, context_cached) if sym.fix.label else None
        )
        sym_callable = _resolve_fix_callable(sym, context_cached)

        if result.fix_action is None:
            # No Python-side fix yet → YAML fix is the primary.
            if result.fix_label is None and sym_label:
                result.fix_label = sym_label
            if sym_callable is not None:
                result.fix_action = sym_callable
        else:
            # Python-side fix already exists → YAML fix becomes fallback.
            # First-match-wins so two YAML rules don't fight over the slot.
            if result.fallback_fix_action is None and sym_callable is not None:
                result.fallback_fix_action = sym_callable
                result.fallback_fix_label = sym_label
    return result


def _resolve_fix_callable(sym: Symptom, context: dict):
    """Build the no-arg callable backing this symptom's ``fix.action``."""
    if not sym.fix.action:
        return None
    if sym.fix.action == "print_remediation" and sym.fix.steps:
        return _make_remediation_callable(sym.fix.steps, sym.fix.label, context)
    return FIX_ACTIONS.get(sym.fix.action)


__all__ = ["apply_symptoms"]
