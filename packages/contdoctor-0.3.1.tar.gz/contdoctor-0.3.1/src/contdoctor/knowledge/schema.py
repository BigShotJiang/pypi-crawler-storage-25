"""Dataclasses backing a single ``symptoms.yaml`` rule."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, Tuple


class Op(str, Enum):
    EQUALS = "equals"
    IN_LIST = "in_list"
    CONTAINS_SUBSTRING = "contains_substring"
    MATCHES_REGEX = "matches_regex"
    GT = "gt"
    LT = "lt"
    IS_EMPTY = "is_empty"
    IS_PRESENT = "is_present"
    IS_ABSENT = "is_absent"


ALLOWED_OPS = {op.value for op in Op}
ALLOWED_SEVERITIES = {"ok", "warn", "fail"}


@dataclass(frozen=True)
class Match:
    field: str
    op: Op
    value: Any = None  # not required for is_empty / is_present / is_absent


# Fix actions that take a list of remediation steps (not auto-applied — they
# print copy-paste instructions to stdout). The loader requires ``fix.steps``
# for these and rejects ``fix.steps`` for any other action.
STEPS_REQUIRED_ACTIONS = {"print_remediation"}


@dataclass(frozen=True)
class Fix:
    action: Optional[str] = None
    label: Optional[str] = None
    steps: Optional[Tuple[str, ...]] = None  # only for STEPS_REQUIRED_ACTIONS


@dataclass(frozen=True)
class Symptom:
    id: str
    category: str
    severity: str  # one of ALLOWED_SEVERITIES
    check: str  # CHECKS-dict key (validated at load time)
    match: Match
    diagnosis: str
    fix: Fix = field(default_factory=Fix)
    date_added: Optional[str] = None
    references: tuple = ()
    superseded_by: Optional[str] = None


__all__ = [
    "Op",
    "ALLOWED_OPS",
    "ALLOWED_SEVERITIES",
    "STEPS_REQUIRED_ACTIONS",
    "Match",
    "Fix",
    "Symptom",
]
