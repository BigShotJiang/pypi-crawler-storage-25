"""Ollama-related checks: binary, version, process, env, API."""

import json
import os
import re
import shutil
from pathlib import Path

from contdoctor.core.http import OLLAMA_HOST, http_get
from contdoctor.core.proc import pgrep, port_open
from contdoctor.core.result import CheckResult
from contdoctor.fixes.ollama import fix_restart_ollama, fix_set_ollama_num_gpu, fix_start_ollama

# Bilinen problemli Ollama versiyonları (regression olanlar)
KNOWN_BAD_OLLAMA = {
    "0.20.3": "GPU layer auto-detection regressed — OLLAMA_NUM_GPU=999 zorla gerekli",
}

# GPU discovery'yi zehirleyen env var'lar
POISON_ENV_VARS = {
    "OLLAMA_LLM_LIBRARY": "GPU discovery'yi bozar; unset edilmeli",
    "CUDA_VISIBLE_DEVICES": "boş set edilmişse GPU gizlenir",  # özel kontrol var
}


def check_ollama_installed() -> CheckResult:
    binary = shutil.which("ollama")
    if not binary:
        return CheckResult("Ollama binary", "fail", "ollama PATH'te yok")
    return CheckResult("Ollama binary", "ok", binary, details={"path": binary})


def check_ollama_version() -> CheckResult:
    from contdoctor.core.proc import run

    rc, out, _ = run(["ollama", "--version"], timeout=5)
    if rc != 0:
        return CheckResult("Ollama versiyon", "fail", "ollama --version başarısız")
    m = re.search(r"(\d+\.\d+\.\d+)", out)
    if not m:
        return CheckResult("Ollama versiyon", "warn", f"parse edilemedi: {out.strip()}")
    version = m.group(1)
    details = {"version": version}
    if version in KNOWN_BAD_OLLAMA:
        return CheckResult(
            "Ollama versiyon",
            "warn",
            f"v{version} — {KNOWN_BAD_OLLAMA[version]}",
            details=details,
        )
    return CheckResult("Ollama versiyon", "ok", f"v{version}", details=details)


def check_ollama_process() -> CheckResult:
    pids = pgrep("ollama serve")
    p_open = port_open("127.0.0.1", 11434)

    if not pids and not p_open:
        return CheckResult(
            "Ollama process",
            "fail",
            "ollama serve çalışmıyor, port 11434 kapalı",
            fix_label="ollama serve başlat",
            fix_action=fix_start_ollama,
        )
    if not pids and p_open:
        return CheckResult(
            "Ollama process",
            "warn",
            "port 11434 açık ama 'ollama serve' process yok (farklı bir process mi dinliyor?)",
            details={"port_open": True, "pids": []},
        )
    if pids and not p_open:
        return CheckResult(
            "Ollama process",
            "fail",
            f"ollama serve var (PID {pids}) ama port 11434 dinlemiyor",
            fix_label="zombie ollama'yı kill et ve yeniden başlat",
            fix_action=lambda p=pids: fix_restart_ollama(p),
            details={"pids": pids, "port_open": False},
        )
    extra = f" (+{len(pids)-1} ek process)" if len(pids) > 1 else ""
    return CheckResult(
        "Ollama process",
        "ok",
        f"PID {pids[0]}, port 11434 açık" + extra,
        details={"pids": pids, "port_open": True},
    )


def check_ollama_env() -> CheckResult:
    """OLLAMA_NUM_GPU + poison env vars (shell + ollama serve process'i)."""
    issues: list = []
    fixable = False

    shell_val = os.environ.get("OLLAMA_NUM_GPU")
    proc_val = None
    pids = pgrep("ollama serve")
    for pid in pids:
        try:
            env_text = Path(f"/proc/{pid}/environ").read_text(errors="replace")
            for kv in env_text.split("\x00"):
                if kv.startswith("OLLAMA_NUM_GPU="):
                    proc_val = kv.split("=", 1)[1]
                    break
            if proc_val is not None:
                break
        except (OSError, PermissionError):
            pass

    if not shell_val and proc_val is None:
        issues.append("OLLAMA_NUM_GPU set değil (Ollama 0.20.3'te model GPU'ya yüklenmeyebilir)")
        fixable = True

    poison_found: list = []
    for var, why in POISON_ENV_VARS.items():
        v = os.environ.get(var)
        if var == "CUDA_VISIBLE_DEVICES":
            if v == "":
                poison_found.append(f"{var} (boş — GPU gizleniyor)")
        elif v is not None:
            poison_found.append(f"{var}={v} ({why})")

    if poison_found:
        issues.append("zehirli env var: " + "; ".join(poison_found))

    details = {
        "OLLAMA_NUM_GPU_shell": shell_val,
        "OLLAMA_NUM_GPU_process": proc_val,
        "poison": poison_found,
    }

    if not issues:
        src = "process" if proc_val and not shell_val else "shell"
        return CheckResult(
            "Env değişkenleri",
            "ok",
            f"OLLAMA_NUM_GPU={shell_val or proc_val} ({src}), zehirli var yok",
            details=details,
        )

    return CheckResult(
        "Env değişkenleri",
        "warn",
        " | ".join(issues),
        fix_label="OLLAMA_NUM_GPU=999 ile ollama serve'i yeniden başlat" if fixable else None,
        fix_action=fix_set_ollama_num_gpu if fixable else None,
        details=details,
    )


def check_ollama_api() -> CheckResult:
    status, body = http_get("/api/tags", timeout=3)
    if status is None:
        return CheckResult("Ollama API", "fail", f"{OLLAMA_HOST}/api/tags ulaşılamıyor: {body}")
    if status != 200:
        return CheckResult("Ollama API", "fail", f"HTTP {status}")
    try:
        data = json.loads(body or "{}")
        models = [m.get("name") for m in data.get("models", [])]
    except (json.JSONDecodeError, AttributeError):
        return CheckResult("Ollama API", "warn", f"yanıt parse edilemedi: {(body or '')[:80]}")
    return CheckResult(
        "Ollama API",
        "ok",
        f"{len(models)} model kayıtlı",
        details={"models": models},
    )


__all__ = [
    "KNOWN_BAD_OLLAMA",
    "POISON_ENV_VARS",
    "check_ollama_installed",
    "check_ollama_version",
    "check_ollama_process",
    "check_ollama_env",
    "check_ollama_api",
]
