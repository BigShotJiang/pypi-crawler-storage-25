"""Built-in deterministic checks (13 of them)."""

from contdoctor.checks.deployment import (
    check_binary_path,
    check_codent_version,
    check_contdoctor_version,
)
from contdoctor.checks.gpu import check_gpu
from contdoctor.checks.model import (
    check_model_loaded,
    check_model_registered,
    check_model_responds,
)
from contdoctor.checks.network import check_network_isolation
from contdoctor.checks.ollama import (
    check_ollama_api,
    check_ollama_env,
    check_ollama_installed,
    check_ollama_process,
    check_ollama_version,
)
from contdoctor.checks.system import check_disk_space, check_glibc, check_python_env

__all__ = [
    "check_gpu",
    "check_ollama_installed",
    "check_ollama_version",
    "check_ollama_process",
    "check_ollama_env",
    "check_ollama_api",
    "check_model_registered",
    "check_model_loaded",
    "check_model_responds",
    "check_disk_space",
    "check_glibc",
    "check_network_isolation",
    "check_python_env",
    "check_contdoctor_version",
    "check_codent_version",
    "check_binary_path",
]
