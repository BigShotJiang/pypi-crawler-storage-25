"""Sprint 5.1 — fix failover chain (Python primary → YAML fallback).

When a Python-side ``fix_action`` returns False, the runner must invoke
``fallback_fix_action`` (typically a YAML ``print_remediation`` closure)
so the user actually sees the manual remediation instructions.
"""

from __future__ import annotations

import json

import pytest

from contdoctor.cli import _apply_fixes
from contdoctor.core.report import results_to_json
from contdoctor.core.result import CheckResult
from contdoctor.knowledge import default_symptoms, load_symptoms_from_string
from contdoctor.knowledge.matcher import apply_symptoms


# ── Matcher: Python fix → YAML becomes fallback ──────────────────────


def test_matcher_yaml_attached_as_fallback_when_python_fix_present():
    """Sprint 1: YAML fix doesn't overwrite a Python fix.
    Sprint 5.1: but it MUST be attached as fallback."""
    yaml_text = """\
version: 1
symptoms:
  - id: needs_remediation
    category: deployment
    severity: warn
    triggered_by:
      check: model_loaded
      match:
        field: details.gpu_pct
        op: lt
        value: 95
    diagnosis: "x"
    fix:
      action: print_remediation
      label: "Modelfile patch"
      steps:
        - "ollama show {model_name} --modelfile"
"""
    syms = load_symptoms_from_string(yaml_text)
    sentinel = lambda: True
    r = CheckResult(
        name="Model yüklü",
        status="fail",
        message="…",
        details={"gpu_pct": 40, "model_name": "cont-local:latest"},
        fix_label="unload + reload",
        fix_action=sentinel,
    )
    apply_symptoms(r, syms, "model_loaded")
    # Python fix wins primary slot.
    assert r.fix_action is sentinel
    assert r.fix_label == "unload + reload"
    # YAML fix is now in the fallback slot.
    assert callable(r.fallback_fix_action)
    assert r.fallback_fix_label == "Modelfile patch"


def test_matcher_yaml_remains_primary_when_no_python_fix():
    """Backward compat: if there's no Python fix, YAML fix is primary
    (Sprint 1 behaviour)."""
    yaml_text = """\
version: 1
symptoms:
  - id: yaml_primary
    category: deployment
    severity: warn
    triggered_by:
      check: codent_version
      match:
        field: details.compatible
        op: equals
        value: false
    diagnosis: "x"
    fix:
      action: print_remediation
      label: "remediation"
      steps:
        - "step 1"
"""
    syms = load_symptoms_from_string(yaml_text)
    r = CheckResult(
        name="Codent versiyon",
        status="fail",
        message="…",
        details={"compatible": False},
    )
    apply_symptoms(r, syms, "codent_version")
    assert callable(r.fix_action)
    assert r.fix_label == "remediation"
    assert r.fallback_fix_action is None
    assert r.fallback_fix_label is None


def test_matcher_first_fallback_wins():
    """If two YAML rules match the same check while a Python fix exists,
    only the first one populates the fallback slot."""
    yaml_text = """\
version: 1
symptoms:
  - id: first_rule
    category: x
    severity: warn
    triggered_by:
      check: model_loaded
      match: { field: details.gpu_pct, op: lt, value: 95 }
    diagnosis: "first"
    fix:
      action: print_remediation
      label: "first fallback"
      steps: ["step-a"]
  - id: second_rule
    category: x
    severity: warn
    triggered_by:
      check: model_loaded
      match: { field: details.gpu_pct, op: lt, value: 50 }
    diagnosis: "second"
    fix:
      action: print_remediation
      label: "second fallback"
      steps: ["step-b"]
"""
    syms = load_symptoms_from_string(yaml_text)
    r = CheckResult(
        name="Model yüklü",
        status="fail",
        message="…",
        details={"gpu_pct": 30, "model_name": "x"},
        fix_action=lambda: True,
        fix_label="python fix",
    )
    apply_symptoms(r, syms, "model_loaded")
    assert r.fallback_fix_label == "first fallback"
    assert r.matched_symptoms == ["first_rule", "second_rule"]


# ── _apply_fixes: failover invocation ────────────────────────────────


def test_python_fix_succeeds_fallback_not_invoked(capsys):
    fallback_calls = []
    r = CheckResult(
        name="X", status="fail", message="…",
        fix_label="primary", fix_action=lambda: True,
        fallback_fix_label="fallback",
        fallback_fix_action=lambda: fallback_calls.append(1) or True,
    )
    _apply_fixes([r])
    out = capsys.readouterr().out
    assert fallback_calls == []
    assert "düzeltildi" in out
    assert "fallback" not in out.lower()


def test_python_fix_fails_fallback_invoked(capsys):
    fallback_calls = []
    r = CheckResult(
        name="Model yüklü", status="fail", message="…",
        fix_label="unload + GPU'ya yeniden yükle",
        fix_action=lambda: False,
        fallback_fix_label="Modelfile düzeyinde GPU layer'ı zorla",
        fallback_fix_action=lambda: fallback_calls.append(1) or True,
    )
    _apply_fixes([r])
    out = capsys.readouterr().out
    assert fallback_calls == [1]
    assert "Python fix başarısız" in out
    assert "Modelfile" in out
    assert "fallback uygulandı" in out


def test_python_fix_raises_fallback_invoked(capsys):
    fallback_calls = []

    def raising_fix():
        raise RuntimeError("kaboom")

    r = CheckResult(
        name="X", status="fail", message="…",
        fix_label="primary",
        fix_action=raising_fix,
        fallback_fix_label="fb",
        fallback_fix_action=lambda: fallback_calls.append(1) or True,
    )
    _apply_fixes([r])
    out = capsys.readouterr().out
    assert fallback_calls == [1]
    assert "fix exception" in out
    assert "fallback uygulandı" in out


def test_no_fallback_when_unset(capsys):
    """No fallback set → "başarısız" message, no fallback line."""
    r = CheckResult(
        name="X", status="fail", message="…",
        fix_label="primary", fix_action=lambda: False,
    )
    _apply_fixes([r])
    out = capsys.readouterr().out
    assert "başarısız" in out
    assert "fallback" not in out.lower()


# ── End-to-end: real default symptoms scenario ───────────────────────


def test_end_to_end_modelfile_remediation_surfaces(capsys):
    """Real-world Sprint 5.1 scenario: model_loaded with gpu_pct=0,
    Python reload fix returns False → ollama_num_gpu_insufficient
    print_remediation must run as fallback and show Modelfile steps."""
    r = CheckResult(
        name="Model yüklü",
        status="fail",
        message="cont-local:latest yüklü, %0 GPU",
        details={
            "gpu_pct": 0,
            "size": 1, "size_vram": 0,
            "model_name": "cont-local:latest",
        },
        fix_label="unload + GPU'ya yeniden yükle",
        fix_action=lambda: False,  # simulates Sprint 5 fix_reload_model post-warmup verify failure
    )
    apply_symptoms(r, default_symptoms(), "model_loaded")
    assert r.fallback_fix_action is not None
    _apply_fixes([r])
    out = capsys.readouterr().out
    assert "Python fix başarısız" in out
    assert "Modelfile" in out
    assert "ollama show cont-local:latest --modelfile" in out
    assert "PARAMETER num_gpu 999" in out
    assert "ollama create cont-local:latest" in out
    assert "fallback uygulandı" in out


# ── JSON + human report exposure ─────────────────────────────────────


def test_json_output_includes_fallback_fix_label():
    r = CheckResult(
        name="X", status="fail", message="…",
        fix_label="primary",
        fix_action=lambda: True,
        fallback_fix_label="manual remediation",
        fallback_fix_action=lambda: True,
    )
    payload = results_to_json([r])[0]
    assert "fallback_fix_label" in payload
    assert payload["fallback_fix_label"] == "manual remediation"
    # JSON-serialisable.
    json.dumps(payload)


def test_json_output_fallback_null_when_unset():
    r = CheckResult(name="X", status="ok", message="…")
    payload = results_to_json([r])[0]
    assert payload["fallback_fix_label"] is None


def test_human_report_shows_fallback_line(capsys):
    from contdoctor.core.report import print_human_report

    r = CheckResult(
        name="Model yüklü", status="fail", message="…",
        fix_label="reload",
        fix_action=lambda: True,
        fallback_fix_label="Modelfile patch",
        fallback_fix_action=lambda: True,
    )
    print_human_report([r])
    out = capsys.readouterr().out
    assert "Otomatik düzeltilebilir" in out
    assert "[Model yüklü] reload" in out
    assert "↳ fallback: Modelfile patch" in out
