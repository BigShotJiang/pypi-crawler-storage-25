"""Sprint 5 — recursive ``--fix`` loop and CPU fallback verification.

The recursive loop is exercised by patching ``cli.run_checks`` to return a
hand-built sequence of CheckResult lists (turn 1, turn 2, ...). Each turn's
fixable set drives one iteration; the test verifies the stop condition.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from contdoctor import cli as cli_mod
from contdoctor.cli import (
    MAX_FIX_ITERATIONS,
    _exit_code_from_results,
    _fixable_set,
    _recursive_fix_loop,
)
from contdoctor.core.result import CheckResult


def _r(name: str, status: str, *, fixable: bool = False, label: str | None = None):
    """CheckResult helper. ``fixable=True`` attaches a no-op fix_action."""
    action = (lambda: True) if fixable else None
    return CheckResult(
        name=name,
        status=status,
        message=f"{name}-msg",
        fix_label=label or (f"fix-{name}" if fixable else None),
        fix_action=action,
    )


def _make_args(verbose: bool = False) -> SimpleNamespace:
    return SimpleNamespace(model="cont-local:latest", verbose=verbose)


# ── Recursive loop convergence ───────────────────────────────────────


def test_fix_converges_first_iteration(monkeypatch, capsys):
    """If the initial scan has nothing fixable, loop short-circuits."""
    initial = [_r("python", "ok"), _r("glibc", "ok")]
    monkeypatch.setattr(cli_mod, "run_checks", lambda *a, **k: initial)
    final, code = _recursive_fix_loop(_make_args(), ["python", "glibc"], [], initial)
    assert code == 0
    assert final is initial
    out = capsys.readouterr().out
    assert "otomatik düzeltilebilir bir şey yok" in out


def test_fix_converges_second_iteration(monkeypatch, capsys):
    """Sertan's scenario: turn 1 has a fix, turn 2 has another (warmup),
    turn 3 is clean → loop converges in 2 fix passes."""
    turn1 = [_r("Ollama process", "fail", fixable=True)]
    turn2_after_fix = [_r("Ollama process", "ok"), _r("Model yüklü", "warn", fixable=True)]
    turn3_clean = [_r("Ollama process", "ok"), _r("Model yüklü", "ok")]
    sequence = iter([turn2_after_fix, turn3_clean])
    monkeypatch.setattr(cli_mod, "run_checks", lambda *a, **k: next(sequence))

    final, code = _recursive_fix_loop(_make_args(), ["x"], [], turn1)
    assert code == 0
    out = capsys.readouterr().out
    assert "iterasyon 1" in out
    assert "iterasyon 2" in out
    assert "fixed-point" in out


def test_fix_no_progress_breaks_loop(monkeypatch, capsys):
    """If turn 2 produces the same fixable set as turn 1 (fix didn't take
    effect), break the loop with stderr — don't loop infinitely."""
    stuck_results = [_r("Ollama process", "fail", fixable=True)]
    monkeypatch.setattr(cli_mod, "run_checks", lambda *a, **k: stuck_results)
    final, code = _recursive_fix_loop(_make_args(), ["x"], [], stuck_results)
    assert code == 2
    err = capsys.readouterr().err
    assert "çözmedi" in err
    assert "Ollama process" in err


def test_fix_max_iter_safety(monkeypatch, capsys):
    """Pathological case: the fixable set keeps changing so no-progress
    never trips. The loop must still bail at MAX_FIX_ITERATIONS."""
    # Each turn's fixable set is unique → no-progress never triggers.
    sequences = iter([
        [_r(f"check-{i}", "fail", fixable=True)] for i in range(MAX_FIX_ITERATIONS + 2)
    ])
    monkeypatch.setattr(cli_mod, "run_checks", lambda *a, **k: next(sequences))
    initial = [_r("check-init", "fail", fixable=True)]
    final, code = _recursive_fix_loop(_make_args(), ["x"], [], initial)
    assert code == 2
    err = capsys.readouterr().err
    assert f"{MAX_FIX_ITERATIONS} iterasyondan sonra" in err


def test_fixable_set_helper():
    results = [_r("a", "ok"), _r("b", "fail", fixable=True), _r("c", "warn", fixable=True)]
    assert _fixable_set(results) == frozenset({"b", "c"})


def test_exit_code_from_results():
    assert _exit_code_from_results([_r("a", "ok")]) == 0
    assert _exit_code_from_results([_r("a", "ok"), _r("b", "warn")]) == 1
    assert _exit_code_from_results([_r("a", "warn"), _r("b", "fail")]) == 2


# ── CPU fallback: warmup post-verify + symptom + placeholder ─────────


def test_fix_warmup_returns_false_when_gpu_pct_low(monkeypatch, capsys):
    """Sprint 5: HTTP 200 yetmez; gpu_pct < 95 → False."""
    from contdoctor.fixes import model as fix_mod

    monkeypatch.setattr(
        fix_mod, "http_post_json",
        lambda *a, **k: (200, '{"response": "ok"}'),
    )
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: 40)
    rc = fix_mod.fix_warmup_model("cont-local:latest")
    assert rc is False
    out = capsys.readouterr().out
    assert "%40 GPU" in out


def test_fix_warmup_returns_true_when_gpu_pct_ok(monkeypatch, capsys):
    from contdoctor.fixes import model as fix_mod

    monkeypatch.setattr(
        fix_mod, "http_post_json",
        lambda *a, **k: (200, '{"response": "ok"}'),
    )
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: 100)
    rc = fix_mod.fix_warmup_model("cont-local:latest")
    assert rc is True


def test_fix_warmup_optimistic_when_introspect_fails(monkeypatch):
    """If /api/ps can't be read, fall back to "HTTP 200 → success" — we
    already know the warmup call succeeded."""
    from contdoctor.fixes import model as fix_mod

    monkeypatch.setattr(
        fix_mod, "http_post_json",
        lambda *a, **k: (200, '{"response": "ok"}'),
    )
    monkeypatch.setattr(fix_mod, "_gpu_pct", lambda model: None)
    assert fix_mod.fix_warmup_model("cont-local:latest") is True


def test_ollama_num_gpu_insufficient_symptom_triggers(monkeypatch):
    """Build a synthetic model_loaded result with gpu_pct=40 and apply
    the default symptoms; ``ollama_num_gpu_insufficient`` must match and
    its print_remediation steps must interpolate {model_name}."""
    from contdoctor.knowledge import default_symptoms
    from contdoctor.knowledge.matcher import apply_symptoms

    r = CheckResult(
        name="Model yüklü",
        status="fail",
        message="cont-local:latest yüklü, %40 GPU — CPU'ya kaymış",
        details={
            "gpu_pct": 40,
            "size": 1_000_000,
            "size_vram": 400_000,
            "context": 4096,
            "model_name": "cont-local:latest",
        },
    )
    apply_symptoms(r, default_symptoms(), "model_loaded")
    assert "ollama_num_gpu_insufficient" in r.matched_symptoms
    assert callable(r.fix_action)


def test_print_remediation_includes_model_name(monkeypatch, capsys):
    """The fix_action closure must render {model_name} in the printed
    Modelfile remediation steps."""
    from contdoctor.knowledge import default_symptoms
    from contdoctor.knowledge.matcher import apply_symptoms

    r = CheckResult(
        name="Model yüklü",
        status="fail",
        message="…",
        details={
            "gpu_pct": 30,
            "size": 1, "size_vram": 0, "context": 4096,
            "model_name": "my-special-model:7b",
        },
    )
    apply_symptoms(r, default_symptoms(), "model_loaded")
    rc = r.fix_action()
    assert rc is True  # print_remediation always returns True
    out = capsys.readouterr().out
    assert "my-special-model:7b" in out
    assert "ollama show my-special-model:7b --modelfile" in out
    assert "ollama create my-special-model:7b" in out


def test_check_model_loaded_includes_model_name_in_details(monkeypatch):
    """Sprint 5: details.model_name must be set so the symptom step
    interpolation has a value."""
    from contdoctor.checks import model as check_mod

    fake_body = (
        '{"models": [{"name": "abc:latest", "size": 1000, "size_vram": 200, '
        '"context_length": 8192}]}'
    )
    monkeypatch.setattr(check_mod, "http_get", lambda *a, **k: (200, fake_body))
    r = check_mod.check_model_loaded("abc:latest")
    assert r.details["model_name"] == "abc:latest"
    assert r.details["gpu_pct"] == 20  # 200/1000
