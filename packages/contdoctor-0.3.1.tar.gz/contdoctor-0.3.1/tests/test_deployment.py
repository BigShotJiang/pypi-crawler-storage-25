"""Sprint 3 — deployment checks + compat matrix + print_remediation + YAML."""

from __future__ import annotations

import importlib.metadata as _metadata
import textwrap
from unittest.mock import patch

import pytest

from contdoctor import __version__ as CONTDOCTOR_VERSION
from contdoctor.checks import deployment as dep
from contdoctor.fixes import FIX_ACTIONS, print_remediation
from contdoctor.knowledge import load_symptoms_from_string
from contdoctor.knowledge.compat import (
    CompatError,
    is_codent_compatible,
    load_compat,
    min_codent_for,
)
from contdoctor.knowledge.loader import KnowledgeError
from contdoctor.knowledge.matcher import apply_symptoms
from contdoctor.core.result import CheckResult


# ── Compat matrix ──────────────────────────────────────────────────


def test_compat_matrix_loads():
    entries = load_compat()
    # 3 rows after Sprint 3.1: codent 0.4.1↔0.1.x, 0.4.1↔0.2.x, 0.4.2↔0.2.x
    assert len(entries) >= 3
    assert entries[0].codent_min == "0.4.1"
    assert "0.1.0" in entries[0].contdoctor_compatible_with


def test_compat_compatible_codent_returns_true():
    """Sprint 3 contdoctor (0.2.0) ↔ Sprint 3 codent (0.4.2) → ok."""
    ok, note = is_codent_compatible("0.4.2", "0.2.0")
    assert ok is True


def test_compat_drift_uses_mock_matrix():
    """Drift detection still works; the live matrix has no drift in stable
    state but the algorithm must surface it when an entry rejects the
    installed contdoctor and no other eligible row accepts it."""
    from contdoctor.knowledge.compat import CompatEntry
    mock_entries = [
        CompatEntry(
            codent_min="1.0.0",
            contdoctor_compatible_with=">=0.1.0,<0.2.0",
            note="hypothetical drift",
        ),
    ]
    ok, reason = is_codent_compatible("1.0.0", "0.5.0", entries=mock_entries)
    assert ok is False
    assert reason and "0.5.0" in reason and "expects" in reason


def test_compat_multi_row_same_codent_min_either_matches():
    """Two rows with the same codent_min: the algorithm must accept the
    contdoctor version if EITHER row's range allows it. Covers Sprint
    3.1's "codent 0.4.1 + contdoctor 0.1.x or 0.2.x" expression."""
    ok_old, _ = is_codent_compatible("0.4.1", "0.1.5")  # row 1
    ok_new, _ = is_codent_compatible("0.4.1", "0.2.0")  # row 2
    assert ok_old is True
    assert ok_new is True


def test_compat_codent_older_than_earliest_returns_false():
    ok, reason = is_codent_compatible("0.3.0", "0.2.0")
    assert ok is False
    assert reason and "earliest" in reason


def test_min_codent_for_returns_smallest_match():
    # contdoctor 0.2.0 fits both the 0.4.1↔0.2.x row and the 0.4.2↔0.2.x
    # row → smallest codent_min that admits 0.2.0 is 0.4.1.
    assert min_codent_for("0.2.0") == "0.4.1"
    # contdoctor 0.1.5 fits only the 0.4.1↔0.1.x row.
    assert min_codent_for("0.1.5") == "0.4.1"


# ── Deployment checks ──────────────────────────────────────────────


def test_check_contdoctor_version_returns_own_version():
    r = dep.check_contdoctor_version()
    assert r.status == "ok"
    assert r.details["version"] == CONTDOCTOR_VERSION
    assert CONTDOCTOR_VERSION in r.message


def test_check_codent_version_compatible(monkeypatch):
    """Mock codent at 0.4.2 → contdoctor 0.2.0 should be compatible."""
    monkeypatch.setattr(dep._metadata, "version", lambda name: "0.4.2")
    r = dep.check_codent_version()
    assert r.status == "ok"
    assert r.details["compatible"] is True
    assert r.details["codent_version"] == "0.4.2"


def test_codent_0_4_1_with_contdoctor_0_2_0_compatible(monkeypatch):
    """Sprint 3.1: codent 0.4.1 prod ↔ contdoctor 0.2.0 → ok, no drift.

    Compat.yaml's third row was added to express that the Sprint 2 proxy
    is version-independent, so a 0.4.1 prod box running 0.2.0 contdoctor
    is functionally compatible.
    """
    monkeypatch.setattr(dep._metadata, "version", lambda name: "0.4.1")
    r = dep.check_codent_version()
    assert r.status == "ok"
    assert r.details["compatible"] is True
    assert r.details["codent_version"] == "0.4.1"
    # Apply the default symptoms — the drift symptom must NOT match.
    from contdoctor.knowledge import default_symptoms
    from contdoctor.knowledge.matcher import apply_symptoms
    apply_symptoms(r, default_symptoms(), "codent_version")
    assert "codent_version_drift" not in r.matched_symptoms


def test_check_codent_version_incompatible_returns_fail(monkeypatch):
    """Drift logic still works when matrix actually rejects the install.

    Force a synthetic incompatibility by mocking the loaded matrix to a
    single row whose range excludes the installed contdoctor. This isolates
    the *algorithm* from the (currently drift-free) shipped matrix.
    """
    from contdoctor.knowledge import compat as _compat
    from contdoctor.knowledge.compat import CompatEntry
    monkeypatch.setattr(dep._metadata, "version", lambda name: "0.4.1")
    mock_entries = [
        CompatEntry(
            codent_min="0.4.1",
            contdoctor_compatible_with=">=99.0.0",
            note="synthetic — installed contdoctor too old",
        )
    ]
    # is_codent_compatible() and min_codent_for() both default to load_compat()
    # when entries=None — patch the module-level loader the helpers actually
    # call, not the symbol re-exported in deployment.py.
    monkeypatch.setattr(_compat, "load_compat", lambda: mock_entries)
    r = dep.check_codent_version()
    assert r.status == "fail"
    assert r.details["compatible"] is False


def test_check_codent_version_codent_not_installed_returns_warn(monkeypatch):
    def raise_not_found(name):
        raise _metadata.PackageNotFoundError(name)
    monkeypatch.setattr(dep._metadata, "version", raise_not_found)
    r = dep.check_codent_version()
    assert r.status == "warn"
    assert r.details["codent_installed"] is False


def test_check_binary_path_no_shadow(monkeypatch, tmp_path):
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    cont = bin_dir / "cont"
    cont.write_text("#!/bin/sh\n")
    cont.chmod(0o755)
    monkeypatch.setenv("PATH", str(bin_dir))
    monkeypatch.setattr(dep.sys, "executable", str(bin_dir / "python"))
    r = dep.check_binary_path()
    assert r.details["shadow_count"] == 1
    # Same venv (binary in same dir as python executable) → ok.
    assert r.status == "ok"


def test_check_binary_path_with_shadow(monkeypatch, tmp_path):
    a = tmp_path / "a"
    b = tmp_path / "b"
    a.mkdir()
    b.mkdir()
    for p in (a, b):
        cont = p / "cont"
        cont.write_text("#!/bin/sh\n")
        cont.chmod(0o755)
    monkeypatch.setenv("PATH", f"{a}{':'}{b}")
    monkeypatch.setattr(dep.sys, "executable", str(a / "python"))
    r = dep.check_binary_path()
    assert r.details["shadow_count"] == 2
    assert r.status == "warn"
    assert "2 adet" in r.message


# ── print_remediation ──────────────────────────────────────────────


def test_print_remediation_basic_steps(capsys):
    rc = print_remediation(["echo hi", "true"])
    assert rc is True
    out = capsys.readouterr().out
    assert "echo hi" in out
    assert "true" in out
    # Each step prefixed with "  $ "
    assert "  $ echo hi" in out


def test_print_remediation_context_substitution(capsys):
    print_remediation(
        ["pip install codent>={min}", "ls {path}"],
        context={"min": "0.4.2", "path": "/wheels"},
        label="Upgrade codent",
    )
    out = capsys.readouterr().out
    assert "pip install codent>=0.4.2" in out
    assert "ls /wheels" in out
    assert "Upgrade codent" in out


def test_print_remediation_missing_key_silently_empty(capsys):
    print_remediation(["foo {bar} baz"], context={})
    out = capsys.readouterr().out
    # missing key → empty string, not KeyError
    assert "foo  baz" in out


def test_print_remediation_registered_in_fix_actions():
    assert FIX_ACTIONS["print_remediation"] is print_remediation


# ── YAML loader extension ──────────────────────────────────────────


def test_yaml_loader_accepts_print_remediation_action():
    yaml_text = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: needs_remediation
            category: deployment
            severity: warn
            triggered_by:
              check: codent_version
              match:
                field: details.compatible
                op: equals
                value: false
            diagnosis: "x"
            fix:
              action: print_remediation
              label: "do this"
              steps:
                - "pip install codent"
        """
    )
    syms = load_symptoms_from_string(yaml_text)
    assert syms[0].fix.action == "print_remediation"
    assert syms[0].fix.steps == ("pip install codent",)


def test_yaml_loader_rejects_print_remediation_without_steps():
    yaml_text = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: missing_steps
            category: deployment
            severity: warn
            triggered_by:
              check: codent_version
              match:
                field: status
                op: equals
                value: ok
            diagnosis: x
            fix:
              action: print_remediation
              label: "do this"
        """
    )
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_text)
    assert "requires 'steps'" in str(exc.value)


def test_yaml_loader_rejects_steps_on_non_remediation_action():
    yaml_text = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: bogus_steps
            category: ollama_version
            severity: warn
            triggered_by:
              check: ollama_ver
              match:
                field: details.version
                op: equals
                value: "0.20.3"
            diagnosis: x
            fix:
              action: fix_set_ollama_num_gpu
              steps:
                - "shouldn't be here"
        """
    )
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_text)
    assert "does not accept 'steps'" in str(exc.value)


def test_yaml_loader_rejects_empty_steps_list():
    yaml_text = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: empty_steps
            category: deployment
            severity: warn
            triggered_by:
              check: codent_version
              match:
                field: status
                op: equals
                value: ok
            diagnosis: x
            fix:
              action: print_remediation
              steps: []
        """
    )
    with pytest.raises(KnowledgeError) as exc:
        load_symptoms_from_string(yaml_text)
    assert "non-empty" in str(exc.value)


# ── End-to-end matcher with print_remediation symptom ──────────────


def test_drift_symptom_matches_and_attaches_remediation_callable(capsys):
    """codent_version_drift should match a fail-result and produce a
    callable fix that, when invoked, prints interpolated steps."""
    yaml_text = textwrap.dedent(
        """\
        version: 1
        symptoms:
          - id: codent_version_drift
            category: deployment
            severity: fail
            triggered_by:
              check: codent_version
              match:
                field: details.compatible
                op: equals
                value: false
            diagnosis: |
              Codent uyumsuz. {compat_note}
            fix:
              action: print_remediation
              label: "Codent'i güncelle"
              steps:
                - "pip install --upgrade 'codent>={min_codent_version}'"
        """
    )
    syms = load_symptoms_from_string(yaml_text)
    r = CheckResult(
        name="Codent versiyon",
        status="fail",
        message="drift",
        details={
            "compatible": False,
            "compat_note": "test note",
            "min_codent_version": "0.4.2",
        },
    )
    apply_symptoms(r, syms, "codent_version")
    assert "codent_version_drift" in r.matched_symptoms
    assert r.diagnosis and "test note" in r.diagnosis
    assert callable(r.fix_action)
    # Invoking the fix prints the interpolated step.
    rc = r.fix_action()
    assert rc is True
    out = capsys.readouterr().out
    assert "codent>=0.4.2" in out


# ── Backward compat: Sprint 1 symptoms still work ──────────────────


def test_sprint1_symptoms_still_load_unchanged():
    """Default symptoms.yaml ships Sprint-1 + Sprint-3 rules; the older
    rules must still parse and have no steps field."""
    from contdoctor.knowledge import default_symptoms
    syms = default_symptoms()
    by_id = {s.id: s for s in syms}
    s1 = by_id["ollama_0_20_3_gpu_regression"]
    s2 = by_id["ollama_llm_library_poison"]
    assert s1.fix.steps is None
    assert s2.fix.steps is None
    assert s1.fix.action == "fix_set_ollama_num_gpu"
