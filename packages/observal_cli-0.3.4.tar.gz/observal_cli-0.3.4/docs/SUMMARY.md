# Summary

* [Welcome](README.md)

## Getting Started

* [Installation](getting-started/installation.md)
* [Quickstart](getting-started/quickstart.md)
* [Core Concepts](getting-started/core-concepts.md)

## Use Cases

* [Overview](use-cases/README.md)
* [Observe MCP traffic](use-cases/observe-mcp-traffic.md)
* [Share agent configs across IDEs](use-cases/share-agent-configs.md)
* [Evaluate and compare agents](use-cases/evaluate-agents.md)
* [Debug agent failures](use-cases/debug-agent-failures.md)
* [Run a team-wide agent registry](use-cases/team-registry.md)

## CLI Reference

* [Overview](cli/README.md)
* [observal auth](cli/auth.md)
* [observal config](cli/config.md)
* [observal scan](cli/scan.md)
* [observal pull](cli/pull.md)
* [observal registry](cli/registry.md)
* [observal agent](cli/agent.md)
* [observal ops](cli/ops.md)
* [observal admin](cli/admin.md)
* [observal doctor](cli/doctor.md)
* [observal profile](cli/profile.md)
* [observal self](cli/self.md)

## Self-Hosting

* [Overview](self-hosting/README.md)
* [Requirements](self-hosting/requirements.md)
* [Docker Compose setup](self-hosting/docker-compose.md)
* [Configuration](self-hosting/configuration.md)
* [Ports and volumes](self-hosting/ports-and-volumes.md)
* [Databases](self-hosting/databases.md)
* [Authentication and SSO](self-hosting/authentication.md)
* [Evaluation engine](self-hosting/evaluation-engine.md)
* [Telemetry pipeline](self-hosting/telemetry-pipeline.md)
* [Upgrades](self-hosting/upgrades.md)
* [Backup and restore](self-hosting/backup-and-restore.md)
* [Troubleshooting](self-hosting/troubleshooting.md)

## Integrations

* [Overview](integrations/README.md)
* [Claude Code](integrations/claude-code.md)
* [Kiro CLI](integrations/kiro.md)
* [Cursor](integrations/cursor.md)
* [Gemini CLI](integrations/gemini-cli.md)
* [VS Code](integrations/vscode.md)
* [Codex CLI](integrations/codex-cli.md)

## Concepts

* [Overview](concepts/README.md)
* [Data model](concepts/data-model.md)
* [Evaluation engine](concepts/evaluation.md)
* [Shim vs proxy](concepts/shim-vs-proxy.md)

## Reference

* [Environment variables](reference/environment-variables.md)
* [API endpoints](reference/api-endpoints.md)
* [Hooks specification](reference/hooks-spec.md)
* [Config files](reference/config-files.md)
