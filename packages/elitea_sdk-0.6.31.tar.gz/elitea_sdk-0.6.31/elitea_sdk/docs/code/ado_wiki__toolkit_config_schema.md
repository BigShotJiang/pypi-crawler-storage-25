# ado_wiki - toolkit_config_schema

**Toolkit**: `ado_wiki`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsWikiToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in AzureDevOpsApiWrapper.model_construct().get_available_tools()}
        m = create_model(
            name_alias,
            ado_configuration=(AdoConfiguration, Field(description=get_credentials_tooltip("Azure DevOps"), json_schema_extra={'configuration_types': ['ado']})),
            project=(str, Field(description="ADO project name")),
            default_wiki_identifier=(Optional[str], Field(default=None, description="Default Wiki Identifier (Wiki ID or wiki name). If provided, this identifier will be used when tools are invoked without explicitly specifying a wiki identifier.")),
            # indexer settings
            pgvector_configuration=(Optional[PgVectorConfiguration], Field(default=None,
                                                                           description=PGVECTOR_CONFIGURATION_TOOLTIP, json_schema_extra={'configuration_types': ['pgvector']})),
            # embedder settings
            embedding_model=(Optional[str], Field(default=None, description=EMBEDDING_MODEL_TOOLTIP, json_schema_extra={'configuration_model': 'embedding'})),
            selected_tools=(List[Literal[tuple(selected_tools)]],
                            Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__={
                'json_schema_extra': {
                    'metadata': {
                        "label": "ADO wiki",
                        "icon_url": "ado-wiki-icon.svg",
                        "categories": ["documentation"],
                        "extra_categories": ["knowledge base", "documentation management", "wiki"],
                        "sections": {
                            "auth": {
                                "required": True,
                                "subsections": [
                                    {
                                        "name": "Token",
                                        "fields": ["token"]
                                    }
                                ]
                            }
                        },
                        "configuration_group": {
                            "name": "ado",
                        }
                    }
                }
            }
        )

        @check_connection_response
        def check_connection(self):
            ado_config = self.ado_configuration
            if not ado_config:
                raise ValueError("ADO configuration is required")
            project = self.project
            if not project:
                raise ValueError("ADO project is required")
            token = ado_config.token.get_secret_value() if ado_config.token else ""
            response = requests.get(
                f'{ado_config.organization_url}/{project}/_apis/wiki/wikis?api-version=7.0',
                headers={'Authorization': f'Bearer {token}'},
                timeout=5
            )
            return response

        m.check_connection = check_connection
        return m
```
