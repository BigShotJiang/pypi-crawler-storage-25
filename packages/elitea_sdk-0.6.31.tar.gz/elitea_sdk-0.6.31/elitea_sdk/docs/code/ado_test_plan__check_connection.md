# ado_test_plan - check_connection

**Toolkit**: `ado_test_plan`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsPlansToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            ado_config = self.ado_configuration
            if not ado_config:
                raise ValueError("ADO configuration is required")
            project = self.project
            if not project:
                raise ValueError("ADO project is required")
            token = ado_config.token.get_secret_value() if ado_config.token else ""
            response = requests.get(
                f'{ado_config.organization_url}/{project}/_apis/testplan/plans?api-version=7.0',
                headers={'Authorization': f'Bearer {token}'},
                timeout=5
            )
            return response
```
