# munimind-mcp

MCP server for [MuniMind](https://munimind.com) — query 2,500+ NYC civic
datasets directly from Claude Desktop, Claude Code, or Cursor. More cities
shipping soon on the same schema.

## What you can do

Once installed, ask Claude natural-language questions that route through
MuniMind's API:

- *"List all MuniMind datasets about housing violations."*
- *"Show me the schema for NYC's HPD violations dataset."*
- *"How many DOB violations were issued in Queens in 2024?"* (runs SQL)
- *"What's the ownership history for BBL 1000010010?"* (Answers API)
- *"Preview the first 20 rows of the NYC taxi zones dataset."*
- *"/analyze_property 1000010010"* (curated prompt — chains multiple tools)

## Install

```bash
pip install munimind-mcp
```

Or via `uv` (recommended — MCP clients use `uvx`):

```bash
uvx munimind-mcp
```

## Get an API key

1. Go to <https://munimind.com/developers>
2. Sign up — **first 5,000 credits are free, no credit card.**
3. Create an API key in the developer dashboard
4. Copy the key (starts with `mm_live_`)

## Configure your MCP client

### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS)
or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "munimind": {
      "command": "uvx",
      "args": ["munimind-mcp"],
      "env": {
        "MUNIMIND_API_KEY": "mm_live_..."
      }
    }
  }
}
```

Restart Claude Desktop.

### Claude Code

```bash
claude mcp add munimind uvx munimind-mcp -e MUNIMIND_API_KEY=mm_live_...
```

### Cursor

Add to `.cursor/mcp.json` in your workspace or `~/.cursor/mcp.json` globally:

```json
{
  "mcpServers": {
    "munimind": {
      "command": "uvx",
      "args": ["munimind-mcp"],
      "env": { "MUNIMIND_API_KEY": "mm_live_..." }
    }
  }
}
```

### Auto-discovery

Any client that supports the [2026 `.well-known/mcp.json` spec](https://modelcontextprotocol.io)
can auto-discover MuniMind via:

```bash
curl https://api.munimind.com/.well-known/mcp.json
```

## What's included (v0.3)

### 7 tools

| Tool | Description | Credit cost |
|------|-------------|-------------|
| `list_datasets` | Browse the public catalog (optionally filter by city, keyword) | 0 |
| `describe_dataset` | Full metadata + schema for one dataset | 0 |
| `preview_dataset` | First 100 rows of a dataset | 0 |
| `query_dataset` | Run SQL against DuckLake-backed datasets (supports time-travel + Parquet) | dynamic (~1 credit / 10 MB scanned) |
| `property_summary` | Per-property summary via the Answers API | 1 |
| `property_intelligence` | Full property dossier — risk, flood, environmental, ownership | 5 |
| `owner_portfolio` | Cross-property analysis for an owner / LLC | 10 |

### 6 curated prompts

Claude Desktop surfaces these in its slash-menu. Each prompt is a multi-step
workflow that chains tools end-to-end.

- `/analyze_property` — full diligence on one property
- `/investigate_owner` — map a portfolio, detect shell-LLC links
- `/area_development_scan` — permits + BSA/LPC/CPC cases + lobbying in an area
- `/meeting_digest` — summarize CPC/BSA/LPC/council activity
- `/precedent_search` — find similar BSA/LPC/CPC decisions
- `/suggest_sql` — turn a plain-English question into a DuckLake SQL query
  (NL2SQL via your client's LLM — zero server-side inference cost)

### 4 resources

MCP resources are context your client reads *without spending a tool call*.

- `munimind://catalog` — full dataset catalog
- `munimind://schemas/index` — every queryable schema
- `munimind://schemas/{slug}` — column-level schema for a dataset
- `munimind://city/{city}/stats` — per-city rollup

## Environment variables

| Name | Required | Default | Notes |
|------|----------|---------|-------|
| `MUNIMIND_API_KEY` | yes | — | Your API key from the developer dashboard |
| `MUNIMIND_API_BASE_URL` | no | `https://api.munimind.com` | Override for staging / self-hosted |

## License

MIT

## Links

- **Docs**: <https://munimind.com/developers/mcp>
- **Interactive API reference**: <https://munimind.com/developers/reference>
- **In-browser SQL playground**: <https://munimind.com/developers/playground>
- **Issues**: <https://github.com/munimind/munimind-mcp/issues>
