"""MuniMind MCP server — tools, prompts, and resources for civic data.

Exposes three MCP surfaces:
  - Tools: list_datasets, describe_dataset, preview_dataset, query_dataset,
           property_summary, property_intelligence, owner_portfolio
  - Prompts: analyze_property, investigate_owner, area_development_scan,
             meeting_digest, precedent_search
  - Resources: munimind://catalog, munimind://schemas/{slug},
               munimind://city/{city}/stats

Auth via `MUNIMIND_API_KEY` env var. All paid tool calls meter normally
against the key's credit balance.
"""

from __future__ import annotations

import asyncio
import json
import os
from typing import Any
from urllib.parse import unquote

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    GetPromptResult,
    Prompt,
    PromptArgument,
    PromptMessage,
    Resource,
    TextContent,
    Tool,
)
from pydantic import AnyUrl


API_BASE = os.environ.get("MUNIMIND_API_BASE_URL", "https://api.munimind.com").rstrip("/")
API_KEY = os.environ.get("MUNIMIND_API_KEY")

NO_KEY_HINT = (
    "Missing MUNIMIND_API_KEY. Sign up at https://munimind.com/developers, "
    "create an API key, then add it to your MCP client's env. See the "
    "munimind-mcp README for examples."
)


server: Server = Server("munimind")
_client: httpx.AsyncClient | None = None


def _http_client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(
            base_url=API_BASE,
            timeout=60.0,
            headers={"User-Agent": "munimind-mcp/0.2"},
        )
    return _client


def _auth_headers() -> dict[str, str]:
    if not API_KEY:
        return {}
    return {"X-API-Key": API_KEY}


async def _get(path: str, params: dict | None = None) -> dict:
    client = _http_client()
    r = await client.get(path, params=params, headers=_auth_headers())
    r.raise_for_status()
    return r.json()


async def _post(path: str, body: dict) -> dict:
    client = _http_client()
    r = await client.post(path, json=body, headers=_auth_headers())
    r.raise_for_status()
    return r.json()


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="list_datasets",
            description=(
                "List MuniMind's public civic datasets. Free — no auth needed. "
                "Filter by city ('nyc', 'nashville') or keyword search."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "City ID filter, e.g. 'nyc'"},
                    "q": {"type": "string", "description": "Keyword search across slug + description"},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
                },
            },
        ),
        Tool(
            name="describe_dataset",
            description="Get full metadata + column schema for a dataset by slug.",
            inputSchema={
                "type": "object",
                "properties": {
                    "slug": {"type": "string", "description": "Dataset slug, e.g. 'nyc.taxi_zones'"},
                },
                "required": ["slug"],
            },
        ),
        Tool(
            name="preview_dataset",
            description="First 100 rows of a dataset. Free — no credits needed.",
            inputSchema={
                "type": "object",
                "properties": {
                    "slug": {"type": "string", "description": "Dataset slug"},
                },
                "required": ["slug"],
            },
        ),
        Tool(
            name="query_dataset",
            description=(
                "Run a SQL SELECT against MuniMind's DuckLake-backed datasets. "
                "Reference tables as lake.main.\"{slug_with_double_underscores}\", "
                "e.g. lake.main.\"nyc__taxi_zones\". Cost scales with bytes "
                "scanned (~10 MB = 1 credit). Requires API key. "
                "Supports DuckLake time-travel via `as_of` (ISO timestamp) and "
                "Parquet output via `format='parquet'`."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "sql": {
                        "type": "string",
                        "description": "Single SELECT statement. Joins, aggregations, windows allowed.",
                    },
                    "as_of": {
                        "type": "string",
                        "description": "Optional ISO-8601 timestamp for DuckLake time-travel. Resolves lake.main.* refs to the catalog state at that point in time.",
                    },
                    "format": {
                        "type": "string",
                        "enum": ["json", "parquet"],
                        "default": "json",
                        "description": "Response format. 'parquet' returns Arrow-compatible binary.",
                    },
                },
                "required": ["sql"],
            },
        ),
        Tool(
            name="property_summary",
            description=(
                "Summary for a specific property (BBL, APN, or address). Uses the "
                "Answers API — 1 credit per call."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "property_id": {"type": "string", "description": "BBL, APN, or address"},
                    "city": {"type": "string", "default": "nyc"},
                },
                "required": ["property_id"],
            },
        ),
        Tool(
            name="property_intelligence",
            description=(
                "Full property dossier: zoning, violations, permits, ownership, "
                "deeds, risk score. Uses the Answers API — 5 credits per call."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "property_id": {"type": "string"},
                    "city": {"type": "string", "default": "nyc"},
                },
                "required": ["property_id"],
            },
        ),
        Tool(
            name="owner_portfolio",
            description=(
                "Cross-property analysis for an owner (LLC or person). Returns "
                "all properties owned, aggregate stats. 10 credits per call."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "owner_name": {"type": "string"},
                    "city": {"type": "string", "default": "nyc"},
                },
                "required": ["owner_name"],
            },
        ),
    ]


# ---------------------------------------------------------------------------
# Tool execution
# ---------------------------------------------------------------------------


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    try:
        if name == "list_datasets":
            data = await _get(
                "/api/v1/data/catalog",
                params={
                    k: v for k, v in {
                        "city": arguments.get("city"),
                        "q": arguments.get("q"),
                        "limit": arguments.get("limit", 50),
                    }.items()
                    if v is not None
                },
            )
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

        if name == "describe_dataset":
            slug = arguments["slug"]
            data = await _get(f"/api/v1/data/catalog/{slug}")
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

        if name == "preview_dataset":
            slug = arguments["slug"]
            data = await _get(f"/api/v1/data/catalog/{slug}/preview")
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

        if name == "query_dataset":
            if not API_KEY:
                return [TextContent(type="text", text=NO_KEY_HINT)]
            body = {"sql": arguments["sql"]}
            if arguments.get("as_of"):
                body["as_of"] = arguments["as_of"]
            if arguments.get("format"):
                body["format"] = arguments["format"]
            data = await _post("/api/v1/data/query", body)
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

        if name == "property_summary":
            if not API_KEY:
                return [TextContent(type="text", text=NO_KEY_HINT)]
            pid = arguments["property_id"]
            data = await _get(f"/api/v1/property/{pid}/summary")
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

        if name == "property_intelligence":
            if not API_KEY:
                return [TextContent(type="text", text=NO_KEY_HINT)]
            pid = arguments["property_id"]
            data = await _get(f"/api/v1/property/{pid}/intelligence")
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

        if name == "owner_portfolio":
            if not API_KEY:
                return [TextContent(type="text", text=NO_KEY_HINT)]
            name_arg = arguments["owner_name"]
            data = await _get(f"/api/v1/owner/{name_arg}/portfolio")
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

        return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except httpx.HTTPStatusError as e:
        code = e.response.status_code
        body = e.response.text[:500]
        if code == 401:
            return [TextContent(
                type="text",
                text="401 Unauthorized — check MUNIMIND_API_KEY is set and active. " + NO_KEY_HINT,
            )]
        if code == 402:
            return [TextContent(
                type="text",
                text="402 Payment Required — insufficient credits. Upgrade your plan or top up at https://munimind.com/billing",
            )]
        if code == 429:
            return [TextContent(
                type="text",
                text="429 Rate Limited — slow down, or upgrade your tier for higher limits.",
            )]
        return [TextContent(type="text", text=f"HTTP {code}: {body}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error calling {name}: {type(e).__name__}: {e}")]


# ---------------------------------------------------------------------------
# Prompts — curated templates surfaced by Claude Desktop's slash-menu.
# ---------------------------------------------------------------------------


@server.list_prompts()
async def list_prompts() -> list[Prompt]:
    return [
        Prompt(
            name="analyze_property",
            description="Full diligence on a specific property: zoning, violations, permits, ownership history, active cases, and a plain-English risk summary.",
            arguments=[
                PromptArgument(
                    name="property_id",
                    description="BBL (NYC: 10-digit), APN (Nashville), or street address",
                    required=True,
                ),
                PromptArgument(
                    name="city",
                    description="City slug: 'nyc' or 'nashville'. Defaults to 'nyc'.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="investigate_owner",
            description="Map an owner's portfolio: every property controlled by this LLC/person, shell-company links, violation patterns, and flipping behavior.",
            arguments=[
                PromptArgument(
                    name="owner_name",
                    description="LLC name or personal name as it appears on deeds",
                    required=True,
                ),
                PromptArgument(
                    name="city",
                    description="City slug: 'nyc' or 'nashville'. Defaults to 'nyc'.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="area_development_scan",
            description="Snapshot of development activity in a neighborhood or bbox: active permits, recent zoning actions, BSA/LPC cases, lobbying filings.",
            arguments=[
                PromptArgument(
                    name="area",
                    description="Neighborhood name (e.g. 'Williamsburg') or bbox 'minLng,minLat,maxLng,maxLat'",
                    required=True,
                ),
                PromptArgument(
                    name="city",
                    description="City slug: 'nyc' or 'nashville'. Defaults to 'nyc'.",
                    required=False,
                ),
                PromptArgument(
                    name="lookback_days",
                    description="How far back to search. Defaults to 90.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="meeting_digest",
            description="Summarize public-meeting activity (CPC, BSA, LPC, council) for a city over a date range. Surfaces controversial items, approvals, and pending appeals.",
            arguments=[
                PromptArgument(
                    name="city",
                    description="City slug: 'nyc' or 'nashville'. Defaults to 'nyc'.",
                    required=False,
                ),
                PromptArgument(
                    name="start_date",
                    description="Start of date range (YYYY-MM-DD). Defaults to 30 days ago.",
                    required=False,
                ),
                PromptArgument(
                    name="end_date",
                    description="End of date range (YYYY-MM-DD). Defaults to today.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="precedent_search",
            description="Find BSA/LPC/CPC decisions similar to a proposed zoning case. Returns matches with outcome, commissioners, and reasoning.",
            arguments=[
                PromptArgument(
                    name="case_description",
                    description="Plain-English description of the proposed case (use, site, variance sought, etc.)",
                    required=True,
                ),
                PromptArgument(
                    name="city",
                    description="City slug: 'nyc' or 'nashville'. Defaults to 'nyc'.",
                    required=False,
                ),
            ],
        ),
        Prompt(
            name="suggest_sql",
            description="Turn a plain-English question into a DuckLake SQL query. Server ships the relevant schemas; the client's LLM writes + runs the SQL — zero server-side inference cost.",
            arguments=[
                PromptArgument(
                    name="question",
                    description="The question in plain English. E.g. 'HPD violations by borough in the last 30 days'.",
                    required=True,
                ),
                PromptArgument(
                    name="city",
                    description="City slug: 'nyc' or 'nashville'. Defaults to 'nyc'.",
                    required=False,
                ),
            ],
        ),
    ]


@server.get_prompt()
async def get_prompt(name: str, arguments: dict[str, str] | None) -> GetPromptResult:
    args = arguments or {}
    city = args.get("city") or "nyc"

    if name == "analyze_property":
        pid = args.get("property_id", "<property_id>")
        text = (
            f"Analyze property {pid} in {city}. Perform this sequence:\n\n"
            f"1. Call tool `property_intelligence` with property_id={pid}, city={city}.\n"
            f"2. If ownership is an LLC, follow up with `owner_portfolio` on the primary LLC.\n"
            f"3. For any active DOB/HPD violations, pull `query_dataset` details (use "
            f"lake.main.\"nyc__dob_violations\" + lake.main.\"nyc__hpd_violations\" as needed).\n"
            f"4. Summarize in plain English: zoning classification + overlays, violation "
            f"severity, permit activity, ownership stability, flip risk, and any active "
            f"BSA/LPC cases.\n"
            f"5. End with a 1-5 risk score + 2-sentence 'so what' for a lender or buyer."
        )

    elif name == "investigate_owner":
        owner = args.get("owner_name", "<owner_name>")
        text = (
            f"Investigate owner '{owner}' in {city}. Perform:\n\n"
            f"1. Call tool `owner_portfolio` with owner_name={owner}, city={city}.\n"
            f"2. For each property in the portfolio, sample `property_summary` on a few "
            f"representative addresses.\n"
            f"3. Use `query_dataset` over lake.main.\"nyc__nys_dos_corporations\" (NYC) to "
            f"find related LLC filings by matching address/agent/officer.\n"
            f"4. Run lake.main.\"nyc__deed_extractions\" to surface rapid flips "
            f"(purchase + sale within 90 days) and straw-buyer chains.\n"
            f"5. Summarize: portfolio size, violation rate vs city avg, concentration by "
            f"borough, shell-company indicators, and any legal-entity red flags."
        )

    elif name == "area_development_scan":
        area = args.get("area", "<area>")
        lookback = args.get("lookback_days", "90")
        text = (
            f"Scan development activity in {area} ({city}) over the last {lookback} days. Perform:\n\n"
            f"1. If {area} is a bbox, parse coordinates; otherwise resolve to a neighborhood polygon.\n"
            f"2. `query_dataset` over lake.main.\"nyc__dob_permits\" for active building permits.\n"
            f"3. `query_dataset` over lake.main.\"nyc__bsa_decisions\" + lake.main.\"nyc__lpc_decisions\" "
            f"for recent rulings in the area.\n"
            f"4. `query_dataset` over lake.main.\"nyc__lobbying_activity\" for filings referencing the "
            f"same BBLs.\n"
            f"5. Summarize: net new square footage approved, top 3 most active developers, hottest "
            f"block, pending cases worth watching."
        )

    elif name == "meeting_digest":
        start = args.get("start_date", "30 days ago")
        end = args.get("end_date", "today")
        text = (
            f"Summarize public-meeting activity in {city} from {start} to {end}. Perform:\n\n"
            f"1. `query_dataset` over lake.main.\"nyc__legistar_matters\" + "
            f"lake.main.\"nyc__legistar_events\" to find matters heard in the window.\n"
            f"2. `query_dataset` over lake.main.\"nyc__bsa_decisions\" + lake.main.\"nyc__lpc_decisions\" "
            f"+ lake.main.\"nyc__cpc_decisions\" for regulatory actions.\n"
            f"3. Group by body (CPC, BSA, LPC, Council), then by outcome (Approved / Denied / Deferred).\n"
            f"4. Surface: controversial items (dissent >2 votes), developers appearing >1x, BBLs with "
            f"multiple actions, high-dollar awards.\n"
            f"5. End with 'what to watch next' — pending appeals and scheduled hearings in the next "
            f"30 days."
        )

    elif name == "suggest_sql":
        question = args.get("question", "<question>")
        # Pull a fresh slice of the catalog so the LLM has real dataset slugs
        # to pick from. Keywords from the question filter the set.
        keywords = [w.lower() for w in question.replace(",", " ").split() if len(w) > 3]
        try:
            cat = await _get(
                "/api/v1/data/catalog",
                params={"city": city, "q": " ".join(keywords[:3]) or None, "limit": 20},
            )
            datasets = cat.get("datasets", [])
        except Exception:
            datasets = []

        catalog_hint = "\n".join(
            f"  - {d.get('slug')}: {d.get('api_description') or 'no description'}"
            for d in datasets[:15]
        ) or "  (no direct catalog matches — use list_datasets yourself)"

        text = (
            f"The user asked: {question!r}\n\n"
            f"Your job: produce a DuckLake SQL query that answers this question, "
            f"execute it with the `query_dataset` tool, then summarize the result.\n\n"
            f"Steps:\n"
            f"1. Review the catalog matches below (for city='{city}'). If none look right, "
            f"call `list_datasets(q='...')` yourself.\n"
            f"2. Call `describe_dataset(slug=...)` on the 1-3 most promising datasets to "
            f"learn their column names + types.\n"
            f"3. Write a SQL query referencing tables as "
            f"`lake.main.\"<slug_with_double_underscores>\"` — e.g. `nyc.hpd_violations` "
            f"becomes `lake.main.\"nyc__hpd_violations\"`.\n"
            f"4. Prefer GROUP BY + date filters to keep scans small (credits scale with "
            f"bytes scanned).\n"
            f"5. Call `query_dataset(sql=...)`. If bytes_scanned is large, add a LIMIT or "
            f"WHERE clause and retry.\n"
            f"6. Summarize results in plain English. Cite the datasets used.\n\n"
            f"Candidate datasets (keyword-filtered from /catalog):\n{catalog_hint}\n\n"
            f"Conventions:\n"
            f"  - Table names: lake.main.\"nyc__<name>\" (double-underscore slug)\n"
            f"  - Time-travel: add `as_of='<ISO timestamp>'` for historical state\n"
            f"  - Output: `format='parquet'` if you want Arrow-native bytes back\n"
            f"  - Errors on credits → tell the user to upgrade at /pricing"
        )

    elif name == "precedent_search":
        case_desc = args.get("case_description", "<case_description>")
        text = (
            f"Find precedent decisions similar to this case in {city}: \n\n"
            f"CASE: {case_desc}\n\n"
            f"Perform:\n"
            f"1. Extract key facets: use type, variance type (area/use/special permit), zoning district, "
            f"site constraints.\n"
            f"2. `query_dataset` over lake.main.\"nyc__bsa_decisions\" + "
            f"lake.main.\"nyc__lpc_decisions\" + lake.main.\"nyc__cpc_decisions\" with WHERE clauses on "
            f"the extracted facets. Use ILIKE on decision_text for conceptual matches.\n"
            f"3. Rank by similarity (matching facets + recency).\n"
            f"4. For the top 5 matches, pull the full decision text and summarize reasoning + outcome.\n"
            f"5. Conclude: which precedents are most favorable vs most damaging, and the commissioner "
            f"patterns (who voted yes/no on similar cases)."
        )

    else:
        text = f"Unknown prompt: {name}"

    return GetPromptResult(
        description=f"MuniMind curated workflow: {name}",
        messages=[
            PromptMessage(role="user", content=TextContent(type="text", text=text)),
        ],
    )


# ---------------------------------------------------------------------------
# Resources — static/semi-static context Claude can read without burning tools.
# ---------------------------------------------------------------------------


@server.list_resources()
async def list_resources() -> list[Resource]:
    resources: list[Resource] = [
        Resource(
            uri=AnyUrl("munimind://catalog"),
            name="Dataset catalog",
            description="All public MuniMind civic datasets — slug, city, row count, byte size, description.",
            mimeType="application/json",
        ),
        Resource(
            uri=AnyUrl("munimind://city/nyc/stats"),
            name="NYC city stats",
            description="Top-level NYC rollup: parcel count, active zoning cases, YTD violations, active permits.",
            mimeType="application/json",
        ),
        Resource(
            uri=AnyUrl("munimind://city/nashville/stats"),
            name="Nashville city stats",
            description="Top-level Nashville rollup: parcel count, active BZA cases, YTD permits, strp activity.",
            mimeType="application/json",
        ),
        Resource(
            uri=AnyUrl("munimind://schemas/index"),
            name="Schema index",
            description="List of every dataset slug that has a queryable schema. Use munimind://schemas/{slug} to read one.",
            mimeType="application/json",
        ),
    ]
    return resources


@server.read_resource()
async def read_resource(uri: AnyUrl) -> str:
    raw = str(uri)
    if not raw.startswith("munimind://"):
        raise ValueError(f"Unsupported resource scheme: {uri}")

    path = raw[len("munimind://"):]
    parts = [unquote(p) for p in path.strip("/").split("/")]

    if parts == ["catalog"]:
        data = await _get("/api/v1/data/catalog", params={"limit": 500})
        return json.dumps(data, indent=2, default=str)

    if parts == ["schemas", "index"]:
        data = await _get("/api/v1/data/catalog", params={"limit": 500})
        slugs = [d.get("slug") for d in data.get("datasets", []) if d.get("slug")]
        return json.dumps({"count": len(slugs), "slugs": slugs}, indent=2)

    if len(parts) == 2 and parts[0] == "schemas":
        slug = parts[1]
        data = await _get(f"/api/v1/data/catalog/{slug}/schema")
        return json.dumps(data, indent=2, default=str)

    if len(parts) == 3 and parts[0] == "city" and parts[2] == "stats":
        city = parts[1]
        catalog = await _get("/api/v1/data/catalog", params={"city": city, "limit": 500})
        datasets = catalog.get("datasets", [])
        total_rows = sum((d.get("row_count") or 0) for d in datasets)
        total_bytes = sum((d.get("byte_size") or 0) for d in datasets)
        return json.dumps({
            "city": city,
            "dataset_count": len(datasets),
            "total_rows": total_rows,
            "total_bytes": total_bytes,
            "datasets_preview": [
                {"slug": d.get("slug"), "rows": d.get("row_count"), "last_updated": d.get("last_updated")}
                for d in datasets[:25]
            ],
        }, indent=2, default=str)

    raise ValueError(f"Unknown resource: {uri}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


async def _run():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main():
    """CLI entry point. Invoked by MCP clients via the `munimind-mcp` command."""
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
