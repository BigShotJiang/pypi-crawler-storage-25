"""munimind-mcp — MCP server for MuniMind civic data APIs."""

__version__ = "0.1.0"
