# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] — 2025-XX-XX

### Added
- Initial release
- **Converter** (`cmslh5-convert`): extract mesh, elements, physical groups, and physics fields from COMSOL `.mph` to `.cmslh5`
- **Parallel extraction** (`--workers N`): distribute field extraction across multiple COMSOL worker processes for large models (millions of nodes)
- **Selective field extraction** (`--fields`): extract only the fields you need
- **Reader** (`CmslH5Reader`): read nodes, elements, studies, fields from `.cmslh5`
- **Line extraction**: sample fields along parametric curves with temporal and spatial interpolation
- **Point probes**: evaluate any component at any point and time
- **Time history**: full time series at monitoring points
- **Multi-component extraction**: multiple fields along the same line in one call
- **Comparison** (`compare_files`): diff two `.cmslh5` files field-by-field
- **Statistics** (`stats`): `time_average`, `time_rms`, `time_min_max`, `fft_at_point`, `field_statistics`
- **Export** (`export`): `to_csv`, `line_to_csv`, `to_vtk`
- **ParaView plugin**: native reader with study selection, animation bar, domain colouring
- Shared internal modules (`_fields`, `_interp`, `_expr`) so converter and reader stay in sync
- Test suite with synthetic fixture
- Documentation: README, user guide, API reference
