"""Tests for cmslh5.reader using the synthetic fixture."""

import pytest
import numpy as np
from pathlib import Path

FIXTURE = Path(__file__).parent / 'fixtures' / 'small_test.cmslh5'


@pytest.fixture(scope='module')
def reader():
    if not FIXTURE.exists():
        pytest.skip(f'Fixture not found: {FIXTURE}. Run: python tests/fixtures/generate_fixture.py')
    from cmslh5 import CmslH5Reader
    r = CmslH5Reader(str(FIXTURE))
    yield r
    r.close()


class TestMesh:
    def test_node_count(self, reader): assert reader.n_nodes() == 1000
    def test_node_shape(self, reader):
        c = reader.nodes(); assert c.shape == (1000, 3); assert c.dtype == np.float64
    def test_bbox(self, reader):
        bmin, bmax = reader.bbox()
        assert np.all(bmin >= 0.0); assert np.all(bmax <= 1.0)
    def test_domain_legend(self, reader):
        dl = reader.domain_legend(); assert 1 in dl; assert dl[1] == 'TestDomain'


class TestStudies:
    def test_count(self, reader): assert len(reader.studies()) == 1
    def test_metadata(self, reader):
        s = reader.studies()[0]
        assert s['label'] == 'Test Study'; assert s['n_timesteps'] == 11
    def test_times(self, reader):
        t = reader.get_times(); assert len(t) == 11; assert np.isclose(t[-1], 1.0)
    def test_fields(self, reader):
        s = reader.studies()[0]
        for f in ['Temperature', 'Pressure', 'Velocity']: assert f in s['fields']


class TestComponents:
    def test_resolve_T(self):
        from cmslh5 import resolve_component
        f, c, i = resolve_component('T'); assert f == 'Temperature'
    def test_resolve_alias(self):
        from cmslh5 import resolve_component
        f, c, i = resolve_component('temperature'); assert c == 'T'
    def test_unknown_raises(self):
        from cmslh5 import resolve_component
        with pytest.raises(KeyError): resolve_component('nonexistent')


class TestNodalField:
    def test_exact(self, reader):
        v, u, m = reader.get_nodal_field('T', 0.0)
        assert v.shape == (1000,); assert m == 'exact'
    def test_interpolated(self, reader):
        v, u, m = reader.get_nodal_field('T', 0.05); assert 'interpolated' in m
    def test_clamped(self, reader):
        v, u, m = reader.get_nodal_field('T', -1.0); assert 'clamped' in m


class TestLine:
    def test_basic(self, reader):
        r = reader.extract_along_line('T', 0.5, 's', '0.5', '0.5', n_points=50)
        assert r['values'].shape == (50,); assert r['unit'] == 'K'
    def test_arc_monotonic(self, reader):
        r = reader.extract_along_line('T', 0.0, 's', '0.5', '0.5', n_points=100)
        assert np.all(np.diff(r['arc_length']) >= 0)


class TestMultiComponent:
    def test_multi(self, reader):
        r = reader.extract_components_along_line(['T','p','vx'], 0.5, 's', '0.5', '0.5', n_points=30)
        assert 'T' in r['data']; assert r['data']['T']['values'].shape == (30,)


class TestProbe:
    def test_probe(self, reader):
        r = reader.probe_point('T', 0.0, [0.5, 0.5, 0.5])
        assert 'value' in r; assert r['unit'] == 'K'


class TestTimeHistory:
    def test_history(self, reader):
        r = reader.extract_time_history('T', [0.5, 0.5, 0.5])
        assert r['times'].shape == (11,); assert r['values'].shape == (11,)


class TestExpressions:
    def test_constant(self):
        from cmslh5 import eval_parametric
        assert np.allclose(eval_parametric('0.5', np.linspace(0,1,10)), 0.5)
    def test_trig(self):
        from cmslh5 import eval_parametric
        s = np.linspace(0,1,100)
        assert np.allclose(eval_parametric('sin(2*pi*s)', s), np.sin(2*np.pi*s))
    def test_invalid(self):
        from cmslh5 import eval_parametric
        with pytest.raises(ValueError): eval_parametric('import os', np.linspace(0,1,10))


class TestSummary:
    def test_returns_string(self, reader):
        s = reader.summary(); assert isinstance(s, str); assert 'Nodes' in s
