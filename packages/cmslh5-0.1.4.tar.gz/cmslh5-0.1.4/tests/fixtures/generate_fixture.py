"""Generate a small synthetic .cmslh5 file for unit tests."""

import numpy as np
import h5py
from pathlib import Path

OUTPUT = Path(__file__).parent / 'small_test.cmslh5'

def main():
    N, E, T = 1000, 500, 11
    np.random.seed(42)
    coords = np.random.rand(N, 3).astype(np.float32)
    conn = np.random.randint(0, N, size=(E, 4)).astype(np.int32)
    times = np.linspace(0.0, 1.0, T)
    x = coords[:, 0]
    r2 = (coords[:, 1] - 0.5)**2 + (coords[:, 2] - 0.5)**2
    compress = dict(compression='gzip', compression_opts=4, shuffle=True)

    T_field = np.zeros((N, 1, T), np.float32)
    P_field = np.zeros((N, 1, T), np.float32)
    V_field = np.zeros((N, 3, T), np.float32)
    for ti in range(T):
        T_field[:, 0, ti] = 300 + 50*x + 10*np.sin(2*np.pi*times[ti])
        P_field[:, 0, ti] = 101325 - 1000*x + 500*np.cos(2*np.pi*times[ti])
        V_field[:, 0, ti] = np.maximum(0, 1 - 16*r2)

    with h5py.File(str(OUTPUT), 'w') as hf:
        hf.attrs['file_format'] = 'cmslh5-1.0'
        mg = hf.create_group('Model')
        ng = mg.create_group('Nodes')
        ng.create_dataset('Id', data=np.arange(1,N+1,dtype=np.int32), **compress)
        ng.create_dataset('Coordinates', data=coords, **compress)
        eg = mg.create_group('Elements')
        eg.create_dataset('Id', data=np.arange(1,E+1,dtype=np.int32), **compress)
        eg.create_dataset('Type', data=np.array(['tet']*E, dtype=hdf5plugin if False else h5py.string_dtype()), **compress)
        eg.create_dataset('NumNodes', data=np.full(E,4,np.int32), **compress)
        eg.create_dataset('Connectivity', data=conn, **compress)
        eg.create_dataset('DomainId', data=np.ones(E,np.int32), **compress)
        eg.create_dataset('DomainName', data=np.array(['TestDomain']*E, h5py.string_dtype()), **compress)
        leg = eg.create_group('DomainLegend')
        leg.create_dataset('Id', data=np.array([1],np.int32))
        leg.create_dataset('Name', data=np.array(['TestDomain'], h5py.string_dtype()))
        mg.create_group('Physical_Groups')
        ag = hf.create_group('Analysis')
        sg = ag.create_group('1_Test_Study')
        sg.attrs['comsol_study_tag'] = 'std1'
        sg.attrs['comsol_study_label'] = 'Test Study'
        sg.attrs['n_timesteps'] = T
        sg.attrs['is_time_dependent'] = 1
        sg.attrs['sol_tag'] = 'sol1'
        sg.create_dataset('Times', data=times.astype(np.float64), **compress)
        for name, data, comps, unit in [
            ('Temperature', T_field, ['T'], 'K'),
            ('Pressure', P_field, ['p'], 'Pa'),
            ('Velocity', V_field, ['vx','vy','vz'], 'm/s')]:
            ds = sg.create_dataset(name, data=data, **compress)
            ds.attrs['components'] = comps; ds.attrs['unit'] = unit
    print(f'Created {OUTPUT}  ({OUTPUT.stat().st_size/1024:.1f} KB)')

if __name__ == '__main__':
    main()
