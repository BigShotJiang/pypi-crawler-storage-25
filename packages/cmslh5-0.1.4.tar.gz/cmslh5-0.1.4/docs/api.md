# API Reference

## `cmslh5.CmslH5Reader`

Main class for reading `.cmslh5` files.

### Constructor

```python
CmslH5Reader(path: str)
```

Opens the HDF5 file. Use as a context manager or call `.close()` manually.

### Mesh access

| Method | Returns | Description |
|## `cmslh5-convert` CLI

```
cmslh5-convert MODEL_FILE [OPTIONS]

positional:
  MODEL_FILE                     Path to COMSOL .mph file

output:
  -o, --output OUTPUT_FILE       Output .cmslh5 path
  --solved-save SOLVED_MPH       Where to save solved .mph

mode:
  --extract-results              Skip meshing/solving; extract from solved model

solver:
  --cores N                      CPU cores for COMSOL solver
  --studies TAG [TAG ...]        Restrict to specific study tags
  --fields FIELD [FIELD ...]     Fields to extract (e.g. Temperature Pressure)

performance:
  --chunk-size N                 Nodes per CutPoint3D chunk (default: 200000)
  --workers N                    Parallel worker processes for extraction (default: 1)

model:
  --comp COMP_TAG                Component tag (default: comp1)
  --mesh-tag MESH_TAG            Specific mesh sequence to use

server:
  --start-server / --no-start-server
  --host HOST                    COMSOL server host (default: localhost)
  --port PORT                    COMSOL server port (default: 2036)
```

### Parallel mode (`--workers`)

When `--workers N` with N > 1 is specified:

1. The master process writes `/Model` (nodes, elements, physical groups) as usual.
2. The node range `[0, N_nodes)` is partitioned into `N` equal slices.
3. `N` worker processes are spawned via `multiprocessing.get_context('spawn').Pool`.
4. Each worker calls `mph.start()`, loads the `.mph`, extracts its node slice, writes to a temporary HDF5.
5. The master reads all temporary files and merges them into `/Analysis` of the final `.cmslh5`.
6. Temporary files are deleted.

Workers use Python's `spawn` context to avoid JVM fork issues.

---|---|---|
| `nodes()` | `(N, 3) float64` | Mesh node coordinates |
| `n_nodes()` | `int` | Number of nodes |
| `bbox()` | `(min_xyz, max_xyz)` | Bounding box |
| `connectivity()` | `(N_elem, max_npe) int32` | Element connectivity (padded with -1) |
| `element_types()` | `ndarray` of strings | Element type per element |
| `domain_legend()` | `{int: str}` | Domain ID → name mapping |
| `physical_groups()` | `list[str]` | Physical group names |

### Study access

| Method | Returns | Description |
|---|---|---|
| `studies()` | `list[dict]` | Metadata for all studies |
| `get_times(study=None)` | `(T,) float64` | Stored timestep values |

### Field extraction

#### `extract_along_line()`

```python
result = reader.extract_along_line(
    component: str,       # 'T', 'p', 'vx', 'vy', 'vz', 'ux', ...
    time: float,          # physical time (interpolated if needed)
    x_expr: str,          # x(s) expression, s ∈ [0, 1]
    y_expr: str,          # y(s)
    z_expr: str,          # z(s)
    n_points: int = 200,  # sample points along line
    study=None,           # study index, name, or None (first)
    k: int = 8,           # IDW neighbours
    idw_power: float = 2.0,
) -> dict
```

Returns dict with keys: `arc_length`, `coords`, `values`, `s_param`, `component`, `field`, `unit`, `time`, `time_method`, `study`, `expressions`.

#### `extract_components_along_line()`

```python
result = reader.extract_components_along_line(
    components: list[str],  # ['vx', 'vy', 'vz', 'p']
    time, x_expr, y_expr, z_expr, n_points, study, k, idw_power
) -> dict
```

Returns dict with keys: `arc_length`, `coords`, `s_param`, `time`, `time_methods`, `study`, `expressions`, `data`.

`result['data']` is `{comp_name: {'values': array, 'unit': str, 'field': str}}`.

#### `probe_point()`

```python
result = reader.probe_point(
    component: str,
    time: float,
    point: [x, y, z],
    study=None, k=8, idw_power=2.0,
) -> dict
```

Returns: `value`, `unit`, `component`, `field`, `time`, `time_method`, `nearest_node_idx`, `nearest_distance`, `nearest_coords`.

#### `extract_time_history()`

```python
result = reader.extract_time_history(
    component: str,
    point: [x, y, z],
    study=None, k=8, idw_power=2.0,
) -> dict
```

Returns: `times`, `values`, `unit`, `component`, `field`, `nearest_node_idx`, `nearest_distance`.

#### `get_nodal_field()`

```python
values, unit, time_method = reader.get_nodal_field(
    component: str,
    time: float,
    study=None,
)
```

Returns `(N_nodes,)` array at all mesh nodes. No spatial interpolation.

#### `summary()`

```python
reader.summary() -> str
```

Human-readable overview of the file contents.

---

## `cmslh5.compare`

### `compare_files()`

```python
from cmslh5 import compare_files

result = compare_files(
    path_a: str,
    path_b: str,
    components: list[str] = None,  # None = auto-discover
    time: float = None,            # None = last timestep
    study=None,
    atol: float = 1e-6,
    rtol: float = 1e-4,
) -> dict
```

Returns: `mesh_match`, `n_nodes_a`, `n_nodes_b`, `time`, `fields`, `all_match`, `summary`.

---

## `cmslh5.stats`

### `time_average()`

```python
values, unit = time_average(reader, component, t_start=None, t_end=None, study=None)
```

Returns `(N_nodes,)` time-averaged values.

### `time_rms()`

```python
values, unit = time_rms(reader, component, t_start=None, t_end=None, study=None)
```

### `time_min_max()`

```python
result = time_min_max(reader, component, study=None)
```

Returns dict: `min_value`, `min_node`, `min_time`, `max_value`, `max_node`, `max_time`, `unit`.

### `fft_at_point()`

```python
result = fft_at_point(reader, component, point, study=None, k=8, idw_power=2.0)
```

Returns: `frequencies`, `amplitudes`, `dominant_freq`, `dominant_amplitude`, `dt`, `unit`.

### `field_statistics()`

```python
result = field_statistics(reader, component, time, study=None)
```

Returns: `min`, `max`, `mean`, `std`, `median`, `p5`, `p95`, `n_nodes`, `unit`.

---

## `cmslh5.export`

### `to_csv()`

```python
from cmslh5.export import to_csv
to_csv(reader, output_path, components=['T', 'p'], time=1.0, study=None)
```

### `line_to_csv()`

```python
from cmslh5.export import line_to_csv
line_to_csv(output_path, result)  # result from extract_along_line or extract_components_along_line
```

### `to_vtk()`

```python
from cmslh5.export import to_vtk
to_vtk(reader, output_path, time=1.0, components=None, study=None)
```

Requires `meshio`.

---

## Standalone functions

### `resolve_component(name)`

```python
from cmslh5 import resolve_component
field, comp, idx = resolve_component('vx')
# ('Velocity', 'vx', 0)
```

### `available_components()`

```python
from cmslh5 import available_components
print(available_components())
# {'Displacement': ['ux', 'uy', 'uz'], 'Pressure': ['p'], ...}
```

### `generate_line_points(x_expr, y_expr, z_expr, n_points)`

```python
from cmslh5 import generate_line_points
coords, arc_length, s_values = generate_line_points(
    '0.01', '0.0', 's * 4.0', n_points=300)
```

### `eval_parametric(expr, s)`

```python
from cmslh5 import eval_parametric
import numpy as np
s = np.linspace(0, 1, 100)
x = eval_parametric('0.5 * sin(2*pi*s)', s)
```
