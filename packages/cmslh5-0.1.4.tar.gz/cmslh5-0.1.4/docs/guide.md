# User Guide

## Overview

The `cmslh5` workflow has two stages:

1. **Convert** (once, on COMSOL server): `.mph` → `.cmslh5`
2. **Analyse** (anywhere, no COMSOL): read, interpolate, compare, export

```
┌──────────────┐     cmslh5-convert     ┌──────────────┐
│  COMSOL .mph │ ───────────────────────>│   .cmslh5    │
│  (proprietary│                         │  (open HDF5) │
│   + license) │                         │              │
└──────────────┘                         └──────┬───────┘
                                                │
                          ┌─────────────────────┼─────────────────────┐
                          │                     │                     │
                     ┌────▼─────┐         ┌─────▼────┐         ┌─────▼────┐
                     │  Python  │         │ ParaView │         │   Any    │
                     │  scripts │         │  plugin  │         │ HDF5     │
                     │ (cmslh5) │         │          │         │ reader   │
                     └──────────┘         └──────────┘         └──────────┘
```

---

## Stage 1: Conversion

### Basic usage

```bash
# From an unsolved model: mesh → solve → extract
cmslh5-convert Model_Definition_Pipe_Flow.mph --cores 8

# From an already-solved model: extract only
cmslh5-convert Results_Pipe_Flow.mph --extract-results
```

### Selective field extraction

If you only need temperature and pressure (saves time and disk space):

```bash
cmslh5-convert Results_Model.mph --extract-results --fields Temperature Pressure
```

### Connecting to a running COMSOL server

```bash
cmslh5-convert model.mph --no-start-server --host localhost --port 2036
```

### Parallel extraction for large models

For models with millions of nodes, the field extraction phase (CutPoint3D creation + EvalPoint evaluation) dominates runtime. The `--workers` flag distributes this across multiple independent COMSOL processes:

```bash
# 4 parallel workers
cmslh5-convert Results_Model.mph --extract-results --workers 4
```

#### How it works

```
Master process                    Worker 1           Worker 2           Worker 3           Worker 4
──────────────                    ────────           ────────           ────────           ────────
1. Load model
2. Write mesh + elements
3. Spawn workers ──────────────> Start COMSOL       Start COMSOL       Start COMSOL       Start COMSOL
                                 Load .mph          Load .mph          Load .mph          Load .mph
                                 Extract nodes      Extract nodes      Extract nodes      Extract nodes
                                 [0, 250k)          [250k, 500k)       [500k, 750k)       [750k, 1M)
                                 Write temp.h5      Write temp.h5      Write temp.h5      Write temp.h5
4. Merge temp files ◄──────────  Done               Done               Done               Done
5. Write final .cmslh5
```

Each worker:
1. Starts its own COMSOL server via `mph.start()`
2. Loads the same `.mph` file
3. Extracts fields for its assigned node range
4. Writes results to a temporary HDF5 in `/tmp`
5. Shuts down its COMSOL server

The master then merges all temporary files by slicing each worker's data into the correct row range of the final `.cmslh5`.

#### Resource requirements

Each worker runs a full COMSOL JVM, so plan accordingly:

| Workers | RAM needed | COMSOL licenses | Best for |
|---|---|---|---|
| 1 | 32–64 GB | 1 | < 500k nodes |
| 2 | 48–96 GB | 2 | 500k–2M nodes |
| 4 | 96–128 GB | 4 | 2M–5M nodes |
| 8 | 192+ GB | 8 | > 5M nodes |

Set JVM heap per worker (total RAM / workers, minus overhead):

```bash
# 128 GB server with 4 workers → 24 GB each
export _JAVA_OPTIONS='-Xmx24G'
cmslh5-convert Results_Model.mph --extract-results --workers 4 --chunk-size 500000
```

#### When NOT to use parallel mode

- **Solving** (not yet solved models): the solver itself is already parallelised via `--cores`. Use `--workers` only for the extraction phase with `--extract-results`.
- **Low node count** (< 200k): startup overhead of additional COMSOL servers outweighs the parallelism benefit.
- **Limited RAM**: each worker needs enough heap for CutPoint spatial search. If you see `OutOfMemoryError`, reduce workers or chunk size.
- **Single COMSOL license**: each worker consumes a license token.

### Large models — general tips

```bash
# Increase JVM heap before running
export _JAVA_OPTIONS='-Xmx64G'

# Use larger chunks if you have RAM (reduces CutPoint creation overhead)
cmslh5-convert model.mph --extract-results --chunk-size 500000

# Combine parallel workers with selective fields to minimise time
cmslh5-convert model.mph --extract-results --workers 4 --fields Temperature Pressure
```

---

## Stage 2: Reading and Analysis

### Opening a file

```python
from cmslh5 import CmslH5Reader

# As a context manager (auto-closes)
with CmslH5Reader('Results.cmslh5') as reader:
    print(reader.summary())

# Or manage lifetime manually
reader = CmslH5Reader('Results.cmslh5')
# ... use reader ...
reader.close()
```

### Understanding the data layout

```python
reader = CmslH5Reader('Results.cmslh5')

# Mesh geometry
coords = reader.nodes()          # (N, 3) float64
n = reader.n_nodes()             # int
bmin, bmax = reader.bbox()       # bounding box

# Studies and fields
for s in reader.studies():
    print(f'Study: {s["label"]}')
    print(f'  Timesteps: {s["n_timesteps"]}')
    print(f'  Fields: {s["fields"]}')
    print(f'  Time range: {s["times"][0]} to {s["times"][-1]}')
```

### Temporal interpolation

When you request `time=0.75` but the stored timesteps are `[0.0, 0.5, 1.0, 1.5, ...]`, the library automatically interpolates linearly between `t=0.5` and `t=1.0`:

```python
result = reader.extract_along_line(component='T', time=0.75, ...)
print(result['time_method'])
# → 'interpolated between t=0.5 and t=1'
```

If time is outside the stored range, it clamps to the nearest boundary.

### Defining lines with parametric expressions

Lines are defined by three expressions in a parameter `s` ∈ [0, 1]:

```python
# Straight lines
x_expr='s * L'          # x from 0 to L
y_expr='0.0'            # constant
z_expr='0.0'

# Lines that don't start at zero
z_expr='1.5 + s * 2.5'  # z from 1.5 to 4.0

# Curved paths
x_expr='R * cos(2*pi*s)'
y_expr='R * sin(2*pi*s)'
z_expr='0.5'

# Available math functions:
# sin, cos, tan, sqrt, abs, exp, log, log10,
# arctan, arcsin, arccos, atan2, min, max, pi
```

### Spatial interpolation

The sample points on a line generally don't coincide with mesh nodes. The library uses inverse-distance weighting (IDW) from the `k` nearest mesh nodes:

```python
result = reader.extract_along_line(
    component='T', time=1.0,
    x_expr='s*0.5', y_expr='0', z_expr='0',
    k=8,             # 8 nearest neighbours (default)
    idw_power=2.0,   # standard IDW (default)
)
```

Higher `k` = smoother but slower. Higher `idw_power` = more local (nearest node dominates).

---

## Plotting examples

The library returns raw numpy arrays, so use any plotting tool:

### matplotlib

```python
import matplotlib.pyplot as plt
from cmslh5 import CmslH5Reader

reader = CmslH5Reader('Results.cmslh5')

# Single component along a line
result = reader.extract_along_line(
    component='T', time=1.0,
    x_expr='s*0.5', y_expr='0', z_expr='0',
    n_points=500,
)

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(result['coords'][:, 0], result['values'])
ax.set_xlabel('x [m]')
ax.set_ylabel(f'T [{result["unit"]}]')
ax.set_title(f'Temperature along centreline at t={result["time"]} s')
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('centreline_T.png', dpi=150)
```

### Multiple components

```python
result = reader.extract_components_along_line(
    components=['vx', 'vy', 'vz'],
    time=1.0,
    x_expr='s*0.5', y_expr='0', z_expr='0',
)

x = result['coords'][:, 0]

fig, axes = plt.subplots(3, 1, figsize=(10, 10), sharex=True)
for ax, comp in zip(axes, ['vx', 'vy', 'vz']):
    d = result['data'][comp]
    ax.plot(x, d['values'])
    ax.set_ylabel(f'{comp} [{d["unit"]}]')
    ax.grid(True, alpha=0.3)
axes[-1].set_xlabel('x [m]')
plt.tight_layout()
plt.show()
```

### Radial profiles

```python
# Velocity profile across pipe diameter at x=0.25
result = reader.extract_along_line(
    component='vx', time=1.0,
    x_expr='0.25',
    y_expr='-0.025 + s * 0.05',   # y from -R to +R
    z_expr='0.0',
    n_points=200,
)

r = result['coords'][:, 1]  # radial coordinate
plt.plot(r * 1000, result['values'])  # r in mm
plt.xlabel('r [mm]')
plt.ylabel(f'vx [{result["unit"]}]')
```

### FFT spectrum

```python
from cmslh5.stats import fft_at_point

fft = fft_at_point(reader, 'p', point=[0.25, 0.01, 0.0])

plt.semilogy(fft['frequencies'], fft['amplitudes'])
plt.xlabel('Frequency [Hz]')
plt.ylabel(f'Amplitude [{fft["unit"]}]')
plt.axvline(fft['dominant_freq'], color='r', ls='--',
            label=f'f_dom = {fft["dominant_freq"]:.1f} Hz')
plt.legend()
```

---

## Regression testing with compare

```python
from cmslh5 import compare_files

# After re-running a simulation with different settings
diff = compare_files(
    'baseline.cmslh5',
    'modified.cmslh5',
    components=['T', 'p', 'vx'],
    time=2.0,
    atol=1e-4,     # absolute tolerance
    rtol=1e-3,     # relative tolerance
)

print(diff['summary'])
assert diff['all_match'], "Regression detected!"
```

---

## ParaView plugin

### Installation

```bash
# Install h5py for ParaView's Python
pvpython -m pip install h5py

# Load the plugin
# ParaView → Tools → Manage Plugins → Load New
# Navigate to: src/cmslh5/paraview/plugin.py
# Tick "Auto Load"
```

### Usage

1. File → Open → select `.cmslh5` file
2. The **Study Name** dropdown selects which study to visualise
3. The animation bar shows all timesteps for the selected study
4. Use **Coloring → DomainId** (Cell Data) with a Distinct Colors map for domain colouring
5. The **Physical Group** dropdown lets you view boundary groups

---

## Tips for large datasets

### Conversion speed

The extraction bottleneck is the CutPoint3D spatial search inside COMSOL's JVM. The three levers are:

| Lever | Flag | Effect |
|---|---|---|
| Chunk size | `--chunk-size 500000` | Fewer chunks = fewer CutPoint create/destroy cycles |
| Workers | `--workers 4` | Parallelise across independent COMSOL processes |
| Selective fields | `--fields Temperature Pressure` | Skip fields you don't need |

A realistic large-model invocation:

```bash
export _JAVA_OPTIONS='-Xmx24G'
cmslh5-convert Results_5M_Node_Model.mph \
    --extract-results \
    --workers 4 \
    --chunk-size 500000 \
    --fields Velocity Pressure Temperature
```

### Memory (reading)

The reader loads field data on demand. When you call `extract_along_line`, only the requested component and timesteps are read from disk. The full dataset is never loaded into memory.

However, `get_nodal_field()` returns an (N_nodes,) array, which for 10M nodes × float64 = 80 MB per call. For very large models, prefer the line-extraction workflow.

### KD-tree

The spatial index (KD-tree) is built lazily on the first call to `extract_along_line`, `probe_point`, or `extract_time_history`. For 1M+ nodes this takes 2-5 seconds but is then cached for the lifetime of the reader.

### Disk space

Typical sizes for the `.cmslh5` file:

| Nodes | Fields | Timesteps | Approx. size |
|---|---|---|---|
| 100k | 3 (vel, pres, temp) | 100 | ~200 MB |
| 500k | 3 | 100 | ~1 GB |
| 1M | 3 | 200 | ~4 GB |
| 5M | 6 (all fields) | 100 | ~15 GB |
