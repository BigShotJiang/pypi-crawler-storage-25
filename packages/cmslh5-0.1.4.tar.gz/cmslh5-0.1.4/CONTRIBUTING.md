# Contributing to cmslh5

Thanks for your interest in contributing. This document covers how to set up a development environment, the project conventions, and how to submit changes.

## Development setup

```bash
git clone https://github.com/smartgeomechanics/cmslh5.git
cd cmslh5
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

This installs the package in editable mode with all optional dependencies including test tools.

## Running tests

```bash
pytest                     # all tests
pytest tests/test_reader.py  # single file
pytest -x                  # stop on first failure
pytest --cov=cmslh5        # with coverage
```

### Test data

Tests use a small synthetic `.cmslh5` fixture in `tests/fixtures/`. To regenerate it:

```bash
python tests/fixtures/generate_fixture.py
```

Do not commit large simulation files. The fixture should be under 1 MB.

## Code style

We use [ruff](https://docs.astral.sh/ruff/) for linting:

```bash
ruff check src/ tests/
ruff format src/ tests/
```

Key conventions:
- Line length: 100 characters
- Type hints on public API methods
- Docstrings on all public functions (NumPy style)
- No wildcard imports

## Project structure

```
src/cmslh5/
├── _fields.py    ← single source of truth for field/component definitions
├── _interp.py    ← spatial and temporal interpolation (shared)
├── _expr.py      ← parametric expression evaluator (shared)
├── _console.py   ← coloured logging helpers (converter only)
├── _hdf5.py      ← compression settings, element writer (converter only)
├── reader.py     ← public: CmslH5Reader
├── convert.py    ← public: .mph → .cmslh5 (includes parallel worker_func)
├── compare.py    ← public: diff two files
├── stats.py      ← public: time_average, fft, etc.
├── export.py     ← public: to_csv, to_vtk
├── cli/          ← console entry points
└── paraview/     ← ParaView plugin (standalone)
```

### Parallel extraction architecture

The `--workers N` mode in `convert.py` uses `multiprocessing.get_context('spawn').Pool`. Key design decisions:

- **spawn, not fork**: COMSOL's JVM cannot survive `fork()`. The `spawn` context starts fresh Python processes.
- **`worker_func` at module level**: Python's `spawn` pickles the target function, which requires it to be importable at module scope (not a nested function or lambda).
- **Each worker starts its own COMSOL server**: workers are fully independent. They load the `.mph`, extract their node slice, write a temporary HDF5, then shut down.
- **Master merges by row slicing**: the master opens each temporary file and copies `data[start:end, :, :]` into the final `.cmslh5`. This is safe because each worker processes a non-overlapping contiguous node range.

### Adding a new field

If COMSOL adds a new physics field you want to support:

1. Edit `src/cmslh5/_fields.py` — add an entry to `FIELD_CONFIGS`
2. The component map and reader pick it up automatically
3. Add a test in `tests/test_fields.py`

### Adding a new analysis function

1. Add it to `src/cmslh5/stats.py` (or create a new module if it's a distinct category)
2. Re-export from `__init__.py` if it's a primary API function
3. Add tests
4. Document in README

## Submitting changes

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make your changes
4. Run tests: `pytest`
5. Run linter: `ruff check src/ tests/`
6. Commit with a clear message
7. Push and open a Pull Request

## Reporting issues

Please include:
- Python version (`python --version`)
- cmslh5 version (`python -c "import cmslh5; print(cmslh5.__version__)"`)
- COMSOL version (if conversion-related)
- Minimal reproduction steps
- Full traceback

## Dependency policy

The core package (`reader`, `compare`, `stats`, `export`) must never depend on `mph` or COMSOL. This is the key design constraint — users should be able to read and analyse `.cmslh5` files on any machine without a COMSOL license.

Heavy dependencies go behind optional extras:
- `mph` → `[convert]`
- `matplotlib` → `[plot]`
- `meshio` → imported at call time with a clear error message
