"""
Safe parametric expression evaluator for line/curve definitions.
"""

import numpy as np
from typing import Tuple


def eval_parametric(expr: str, s: np.ndarray) -> np.ndarray:
    ns = {
        's': s, 'pi': np.pi,
        'sin': np.sin, 'cos': np.cos, 'tan': np.tan,
        'sqrt': np.sqrt, 'abs': np.abs,
        'exp': np.exp, 'log': np.log, 'log10': np.log10,
        'arctan': np.arctan, 'arcsin': np.arcsin, 'arccos': np.arccos,
        'atan2': np.arctan2, 'min': np.minimum, 'max': np.maximum,
    }
    try:
        result = eval(expr, {"__builtins__": {}}, ns)
    except Exception as exc:
        raise ValueError(f'Cannot evaluate "{expr}": {exc}') from exc
    result = np.asarray(result, dtype=np.float64)
    if result.ndim == 0:
        result = np.full_like(s, float(result))
    return result


def generate_line_points(x_expr: str, y_expr: str, z_expr: str,
                         n_points: int = 200
                         ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    s = np.linspace(0.0, 1.0, n_points)
    coords = np.column_stack([
        eval_parametric(x_expr, s),
        eval_parametric(y_expr, s),
        eval_parametric(z_expr, s),
    ])
    diffs = np.diff(coords, axis=0)
    seg = np.sqrt(np.sum(diffs ** 2, axis=1))
    arc = np.zeros(n_points)
    arc[1:] = np.cumsum(seg)
    return coords, arc, s
