"""
Interpolation routines shared across reader, stats, and export.
"""

import numpy as np
from typing import Tuple


def interpolate_spatial_idw(tree, node_values: np.ndarray,
                            query_coords: np.ndarray,
                            k: int = 8, power: float = 2.0) -> np.ndarray:
    dists, idxs = tree.query(query_coords, k=k)
    nonzero = dists[dists > 0]
    cap = float(nonzero.min()) * 1e-6 if len(nonzero) > 0 else 1e-30
    dists = np.maximum(dists, cap)
    w = 1.0 / (dists ** power)
    w /= w.sum(axis=1, keepdims=True)
    return np.sum(w * node_values[idxs], axis=1)


def interpolate_temporal(times: np.ndarray, field_2d: np.ndarray,
                         t: float) -> Tuple[np.ndarray, str]:
    tol = 1e-12 * max(1.0, abs(t))
    idx = int(np.argmin(np.abs(times - t)))

    if np.abs(times[idx] - t) < tol:
        return field_2d[:, idx].astype(np.float64), 'exact'

    if t <= times[0]:
        return field_2d[:, 0].astype(np.float64), f'clamped to t_min={times[0]:.6g}'
    if t >= times[-1]:
        return field_2d[:, -1].astype(np.float64), f'clamped to t_max={times[-1]:.6g}'

    ir = int(np.searchsorted(times, t))
    il = ir - 1
    alpha = (t - times[il]) / (times[ir] - times[il])
    vals = (field_2d[:, il].astype(np.float64) * (1.0 - alpha)
            + field_2d[:, ir].astype(np.float64) * alpha)
    return vals, f'interpolated between t={times[il]:.6g} and t={times[ir]:.6g}'
