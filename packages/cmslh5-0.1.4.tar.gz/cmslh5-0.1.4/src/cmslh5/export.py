"""
cmslh5.export — Export .cmslh5 data to external formats.
"""

import csv
import numpy as np
from typing import List, Optional, Union
from cmslh5.reader import CmslH5Reader
from cmslh5._fields import COMSOL_VTK_MAP


def to_csv(reader, output_path, components, time, study=None):
    coords = reader.nodes()
    n = len(coords)
    headers = ['node_id', 'x', 'y', 'z']
    columns, units = [], []
    for comp in components:
        vals, unit, _ = reader.get_nodal_field(comp, time, study)
        columns.append(vals); headers.append(comp); units.append(unit)
    with open(output_path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow([f'# time={time}'] + [f'{c}[{u}]' for c, u in zip(components, units)])
        w.writerow(headers)
        for i in range(n):
            row = [i+1, f'{coords[i,0]:.8g}', f'{coords[i,1]:.8g}', f'{coords[i,2]:.8g}']
            for col in columns: row.append(f'{col[i]:.8g}')
            w.writerow(row)
    print(f'Exported {n:,} nodes to {output_path}')


def line_to_csv(output_path, result):
    with open(output_path, 'w', newline='') as f:
        w = csv.writer(f)
        if 'data' in result:
            comp_names = sorted(result['data'].keys())
            w.writerow(['s', 'arc_length', 'x', 'y', 'z'] + comp_names)
            for i in range(len(result['arc_length'])):
                row = [f'{result["s_param"][i]:.8g}', f'{result["arc_length"][i]:.8g}',
                       f'{result["coords"][i,0]:.8g}', f'{result["coords"][i,1]:.8g}',
                       f'{result["coords"][i,2]:.8g}']
                for cn in comp_names: row.append(f'{result["data"][cn]["values"][i]:.8g}')
                w.writerow(row)
        else:
            comp = result.get('component', 'value')
            w.writerow(['s', 'arc_length', 'x', 'y', 'z', comp])
            for i in range(len(result['values'])):
                w.writerow([f'{result["s_param"][i]:.8g}', f'{result["arc_length"][i]:.8g}',
                            f'{result["coords"][i,0]:.8g}', f'{result["coords"][i,1]:.8g}',
                            f'{result["coords"][i,2]:.8g}', f'{result["values"][i]:.8g}'])
    print(f'Exported to {output_path}')


def to_vtk(reader, output_path, time, components=None, study=None):
    try:
        import meshio
    except ImportError:
        raise ImportError("VTK export requires meshio: pip install meshio")
    coords = reader.nodes()
    conn = reader.connectivity()
    etypes = reader.element_types()
    vtk_map = {'tet':'tetra','tet2':'tetra10','tri':'triangle','tri2':'triangle6',
               'hex':'hexahedron','quad':'quad','prism':'wedge','edg':'line'}
    cells = []
    for etype in sorted(set(t.decode() if isinstance(t,bytes) else str(t) for t in etypes)):
        mt = vtk_map.get(etype.lower())
        if mt is None: continue
        entry = COMSOL_VTK_MAP.get(etype.lower())
        npe = entry[2] if entry else 0
        if npe == 0: continue
        mask = np.array([(t.decode() if isinstance(t,bytes) else str(t))==etype for t in etypes])
        cells.append((mt, conn[mask, :npe]))
    if components is None:
        sinfo = reader._resolve_study(study)
        components = []
        for fi in sinfo['field_info'].values(): components.extend(fi['components'])
    pd = {}
    for comp in components:
        try:
            vals, _, _ = reader.get_nodal_field(comp, time, study)
            pd[comp] = vals
        except Exception: pass
    meshio.Mesh(points=coords, cells=cells, point_data=pd).write(output_path)
    print(f'Exported to {output_path}')
