"""
cmslh5 — Read, write, and analyse COMSOL HDF5 result files (.cmslh5)
=====================================================================

Core (always available):
    from cmslh5 import CmslH5Reader
    from cmslh5 import available_components, resolve_component
    from cmslh5 import generate_line_points

Conversion (requires `pip install cmslh5[convert]`):
    from cmslh5 import convert

Comparison:
    from cmslh5 import compare_files

Export:
    from cmslh5.export import to_vtk, to_csv

Statistics:
    from cmslh5.stats import time_average, fft_at_point
"""

from cmslh5._version import __version__

from cmslh5.reader import (
    CmslH5Reader,
    available_components,
    resolve_component,
)
from cmslh5._expr import (
    eval_parametric,
    generate_line_points,
)
from cmslh5._interp import (
    interpolate_spatial_idw,
    interpolate_temporal,
)

from cmslh5.compare import compare_files


def convert(model_path, output=None, **kwargs):
    """
    Convert a COMSOL .mph file to .cmslh5.

    Requires `pip install cmslh5[convert]` (mph package + COMSOL license).
    All kwargs are forwarded to the underlying comsol_to_hdf5() function.
    """
    try:
        from cmslh5.convert import comsol_to_hdf5, build_default_paths
    except ImportError as exc:
        raise ImportError(
            "Conversion requires the 'mph' package.\n"
            "Install: pip install cmslh5[convert]"
        ) from exc
    output_hdf5, solved_save = build_default_paths(model_path, output)
    return comsol_to_hdf5(model_path=model_path, output_hdf5=output_hdf5,
                          solved_save_path=solved_save, **kwargs)


__all__ = [
    "__version__",
    "CmslH5Reader",
    "available_components",
    "resolve_component",
    "eval_parametric",
    "generate_line_points",
    "interpolate_spatial_idw",
    "interpolate_temporal",
    "compare_files",
    "convert",
]
