"""
cmslh5.compare — Compare two .cmslh5 files field-by-field.
"""

import numpy as np
from typing import Dict, List, Optional, Union
from cmslh5.reader import CmslH5Reader
from cmslh5._interp import interpolate_temporal


def compare_files(path_a, path_b, components=None, time=None, study=None, atol=1e-6, rtol=1e-4):
    ra = CmslH5Reader(path_a)
    rb = CmslH5Reader(path_b)
    try:
        coords_a = ra.nodes()
        coords_b = rb.nodes()
        mesh_match = (coords_a.shape == coords_b.shape and np.allclose(coords_a, coords_b, atol=1e-10))
        if time is None:
            time = float(ra.get_times(study)[-1])
        if components is None:
            sa = ra._resolve_study(study)
            sb = rb._resolve_study(study)
            common = set(sa['fields']) & set(sb['fields'])
            components = []
            for fname, fi in sa['field_info'].items():
                if fname in common:
                    components.extend(fi['components'])
        field_results = {}
        for comp in components:
            try:
                vals_a, _, _ = ra.get_nodal_field(comp, time, study)
                vals_b, _, _ = rb.get_nodal_field(comp, time, study)
            except (KeyError, ValueError) as exc:
                field_results[comp] = {'error': str(exc), 'match': False}
                continue
            sa = dict(min=float(np.nanmin(vals_a)), max=float(np.nanmax(vals_a)),
                      mean=float(np.nanmean(vals_a)), std=float(np.nanstd(vals_a)))
            sb = dict(min=float(np.nanmin(vals_b)), max=float(np.nanmax(vals_b)),
                      mean=float(np.nanmean(vals_b)), std=float(np.nanstd(vals_b)))
            if mesh_match and len(vals_a) == len(vals_b):
                diff = np.abs(vals_a - vals_b)
                scale = np.maximum(np.abs(vals_a), np.abs(vals_b))
                scale = np.where(scale > 0, scale, 1.0)
                max_abs = float(np.nanmax(diff))
                mean_abs = float(np.nanmean(diff))
                max_rel = float(np.nanmax(diff / scale))
                rms = float(np.sqrt(np.nanmean(diff ** 2)))
                match = bool(np.allclose(vals_a, vals_b, atol=atol, rtol=rtol))
            else:
                max_abs = abs(sa['max'] - sb['max'])
                mean_abs = abs(sa['mean'] - sb['mean'])
                max_rel = max_abs / max(abs(sa['max']), 1e-30)
                rms = float('nan')
                match = (max_rel < rtol)
            field_results[comp] = dict(max_abs_diff=max_abs, mean_abs_diff=mean_abs,
                                       max_rel_diff=max_rel, rms_diff=rms, match=match,
                                       stats_a=sa, stats_b=sb)
        all_match = all(r.get('match', False) for r in field_results.values())
        lines = [f'Comparing: {path_a}  vs  {path_b}', f'Time: {time:.6g} s',
                 f'Mesh match: {mesh_match}  (A={len(coords_a):,}, B={len(coords_b):,})', '']
        for comp, res in field_results.items():
            if 'error' in res:
                lines.append(f'  {comp:8s}  ERROR: {res["error"]}')
            else:
                st = 'PASS' if res['match'] else 'FAIL'
                lines.append(f'  {comp:8s}  {st}  max_abs={res["max_abs_diff"]:.4g}  max_rel={res["max_rel_diff"]:.4g}  rms={res["rms_diff"]:.4g}')
        lines += ['', f'Overall: {"ALL PASS" if all_match else "DIFFERENCES FOUND"}']
        return dict(mesh_match=mesh_match, n_nodes_a=len(coords_a), n_nodes_b=len(coords_b),
                    time=time, fields=field_results, all_match=all_match, summary='\n'.join(lines))
    finally:
        ra.close()
        rb.close()
