"""
Console entry point for cmslh5-convert.
"""

import sys


def main():
    try:
        from cmslh5.convert import main as convert_main
    except ImportError as exc:
        print(
            "cmslh5-convert requires the 'mph' package and a COMSOL installation.\n"
            "Install: pip install cmslh5[convert]\n"
            f"\nImport error: {exc}",
            file=sys.stderr,
        )
        sys.exit(1)
    convert_main()


if __name__ == '__main__':
    main()
