"""
Shared field configuration and component mapping.

Used by both the converter (which fields to extract from COMSOL) and the
reader (which component names map to which HDF5 dataset + column index).
"""

from typing import Dict, List, Tuple

FIELD_CONFIGS = [
    dict(name='Displacement',
         candidates=[['solid.u', 'solid.v', 'solid.w'],
                     ['solid.disp', 'solid.disp', 'solid.disp']],
         components=['ux', 'uy', 'uz'],
         unit='m'),
    dict(name='Velocity',
         candidates=[['spf.u', 'spf.v', 'spf.w'],
                     ['u', 'v', 'w']],
         components=['vx', 'vy', 'vz'],
         unit='m/s'),
    dict(name='Pressure',
         candidates=[['p'], ['spf.p']],
         components=['p'],
         unit='Pa'),
    dict(name='Temperature',
         candidates=[['T'], ['ht.T']],
         components=['T'],
         unit='K'),
    dict(name='Stress',
         candidates=[['solid.sx', 'solid.sy', 'solid.sz',
                      'solid.sxy', 'solid.sxz', 'solid.syz']],
         components=['sx', 'sy', 'sz', 'sxy', 'sxz', 'syz'],
         unit='Pa'),
    dict(name='Strain',
         candidates=[['solid.eX', 'solid.eY', 'solid.eZ',
                      'solid.eXY', 'solid.eXZ', 'solid.eYZ']],
         components=['exx', 'eyy', 'ezz', 'exy', 'exz', 'eyz'],
         unit='1'),
]

COMPONENT_MAP: Dict[str, Tuple[str, int]] = {}
for _fc in FIELD_CONFIGS:
    for _i, _comp in enumerate(_fc['components']):
        COMPONENT_MAP[_comp] = (_fc['name'], _i)

COMPONENT_ALIASES = {
    't': 'T', 'temp': 'T', 'temperature': 'T',
    'pressure': 'p', 'press': 'p',
}

COMSOL_VTK_MAP = {
    'vtx':   (1,  'VTK_VERTEX',                1),
    'edg':   (3,  'VTK_LINE',                  2),
    'edg2':  (21, 'VTK_QUADRATIC_EDGE',        3),
    'tri':   (5,  'VTK_TRIANGLE',              3),
    'tri2':  (22, 'VTK_QUADRATIC_TRIANGLE',    6),
    'quad':  (9,  'VTK_QUAD',                  4),
    'quad2': (23, 'VTK_QUADRATIC_QUAD',        8),
    'tet':   (10, 'VTK_TETRA',                 4),
    'tet2':  (24, 'VTK_QUADRATIC_TETRA',      10),
    'prism': (13, 'VTK_WEDGE',                 6),
    'hex':   (12, 'VTK_HEXAHEDRON',            8),
    'hex2':  (25, 'VTK_QUADRATIC_HEXAHEDRON', 20),
}


def resolve_component(name: str) -> Tuple[str, str, int]:
    if name in COMPONENT_MAP:
        field, idx = COMPONENT_MAP[name]
        return field, name, idx
    alias = COMPONENT_ALIASES.get(name.lower())
    if alias and alias in COMPONENT_MAP:
        field, idx = COMPONENT_MAP[alias]
        return field, alias, idx
    for key, (field, idx) in COMPONENT_MAP.items():
        if key.lower() == name.lower():
            return field, key, idx
    raise KeyError(
        f'Unknown component "{name}". '
        f'Available: {sorted(COMPONENT_MAP.keys())}')


def available_components() -> Dict[str, List[str]]:
    by_field: Dict[str, List[str]] = {}
    for comp, (field, _) in COMPONENT_MAP.items():
        by_field.setdefault(field, []).append(comp)
    return {f: sorted(cs) for f, cs in sorted(by_field.items())}
