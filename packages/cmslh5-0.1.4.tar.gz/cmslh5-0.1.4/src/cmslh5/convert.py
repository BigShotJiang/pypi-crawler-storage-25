def worker_func(args):
    import mph, h5py, numpy as np
    # Reconnect to COMSOL server in each process
    client = mph.start()
    model = client.load(str(args['model_path']))
    java = model.java
    with h5py.File(args['temp_h5_path'], 'w') as hf_worker:
        analysis_grp = hf_worker.create_group('Analysis')
        write_analysis_group(model, java, args['study_info_list'],
                            analysis_grp, args['coords'],
                            chunk_size=args['chunk_size'])
    try:
        client.clear()
    except Exception:
        pass  # Suppress disconnect/cleanup errors
    return True

import os
if '_JAVA_OPTIONS' not in os.environ:
    os.environ['_JAVA_OPTIONS'] = '-Xmx64G'

"""
cmslh5.convert
==============
Extract mesh geometry, physical groups, and physics results from a COMSOL
Multiphysics (.mph) model file into a structured HDF5 archive (.cmslh5).

Auto-detection
--------------
The module automatically detects whether the model already contains solved
results.  If results are present it extracts directly; otherwise it meshes
all sequences, runs all studies (or the ones you specify), saves the solved
.mph, then extracts.

Output HDF5 structure
---------------------
/Model/
    Nodes/
        Id              int32   [N_nodes]
        Coordinates     float32 [N_nodes, 3]
    Elements/
        Id, Type, NumNodes, Connectivity, DomainId, DomainName, DomainLegend/
    Physical_Groups/
        {DIM}D_{label}/
            Id, Type, NumNodes, Connectivity

/Analysis/
    {idx}_{StudyLabel}/
        Times           float64 [T]
        Velocity        float32 [N, 3, T]
        Pressure        float32 [N, 1, T]
        Temperature     float32 [N, 1, T]
        Displacement    float32 [N, 3, T]
        Stress          float32 [N, 6, T]
        Strain          float32 [N, 6, T]

Usage
-----
    python3 -m cmslh5.convert_cli model.mph
    python3 -m cmslh5.convert_cli model.mph -o out.cmslh5 --cores 8
    python3 -m cmslh5.convert_cli model.mph --no-start-server --host localhost --port 2036

Dependencies
------------
    pip install mph h5py numpy
"""

import argparse
import sys
import time
import re
import traceback
import threading
import shutil
import tempfile
import mph
import numpy as np
import h5py
from pathlib import Path
from collections import defaultdict
from datetime import timedelta

from cmslh5._fields import FIELD_CONFIGS, COMSOL_VTK_MAP as _COMSOL_VTK_MAP

# =============================================================================
# Global compression settings
# =============================================================================
_HDF5_COMPRESS = dict(compression='gzip', compression_opts=4, shuffle=True)

# =============================================================================
# Expression result cache (avoids re-evaluation of the same expression)
# =============================================================================

class ExpressionCache:
    """Cache evaluated expressions to avoid re-evaluation."""
    def __init__(self, max_size=100):
        self.cache = {}
        self.hits = 0
        self.misses = 0

    def get(self, expr):
        """Returns cached result or None."""
        if expr in self.cache:
            self.hits += 1
            return self.cache[expr]
        self.misses += 1
        return None

    def put(self, expr, data):
        """Store expression result."""
        self.cache[expr] = data

    def clear(self):
        """Clear cache between studies."""
        self.cache.clear()
        self.hits = 0
        self.misses = 0

    def stats(self):
        total = self.hits + self.misses
        return {'hits': self.hits, 'misses': self.misses, 'total': total,
                'hit_rate': (self.hits/total*100) if total > 0 else 0}

_expression_cache = ExpressionCache()


def discover_field_expressions(java, sol_tag):
    """
    Use xmeshInfo().fieldNames() to get the active DOF field names from the
    solver. Returns empty dict if xmeshInfo is unavailable.
    """
    try:
        xmi = java.sol(sol_tag).xmeshInfo()
        raw_names = list(xmi.fieldNames())
        raw_ndofs = list(xmi.fieldNDofs())
        return {name: ndof for name, ndof in zip(raw_names, raw_ndofs) if ndof > 0}
    except BaseException:
        return {}


def has_solved_results(java):
    """Return True if the model has at least one solver with results."""
    try:
        sol_tags = java_to_list_1d(java.sol().tags())
    except BaseException:
        return False

    for stag in sol_tags:
        try:
            sol = java.sol(stag)
        except BaseException:
            continue
        # Check 1: inner solution count (time-dependent / parametric)
        try:
            n = int(sol.getInnerSolNum())
            if n > 0:
                return True
        except BaseException:
            pass
        # Check 2: getPVals — non-empty means time/param steps stored
        try:
            pv = java_to_list_1d(sol.getPVals())
            if pv:
                return True
        except BaseException:
            pass
        # Check 3: isEmpty() — False means data present
        try:
            if not bool(sol.isEmpty()):
                return True
        except BaseException:
            pass
    return False

# =============================================================================
# Element dimension keywords
# =============================================================================
VOLUME_ELEM_KEYWORDS  = ('tet', 'hex', 'prism', 'pyr', 'wedge')
SURFACE_ELEM_KEYWORDS = ('tri', 'quad')
LINE_ELEM_KEYWORDS    = ('edg', 'edge')
POINT_ELEM_KEYWORDS   = ('vtx', 'pnt', 'vertex', 'point')
DIM_PREFIX            = {3: '3D', 2: '2D', 1: '1D', 0: '0D'}

# =============================================================================
# Console helpers
# =============================================================================
_USE_COLOUR = sys.stdout.isatty() and sys.platform != 'win32'
_W = 68

def _c(code, t):
    return f"\033[{code}m{t}\033[0m" if _USE_COLOUR else t

def _bold(t):   return _c('1',     t)
def _green(t):  return _c('1;32', t)
def _yellow(t): return _c('1;33', t)
def _cyan(t):   return _c('1;36', t)
def _red(t):    return _c('1;31', t)
def _dim(t):    return _c('2',    t)

def _banner():
    print(flush=True)
    print(_bold('=' * _W), flush=True)
    print(_bold(_cyan('  COMSOL -> HDF5 Extractor'.center(_W))), flush=True)
    print(_bold('=' * _W), flush=True)
    print(flush=True)

def _section(title):
    print(flush=True)
    print(_bold(_cyan(f'  [{title}]')), flush=True)
    print(_dim('  ' + '-' * (_W - 2)), flush=True)

def _step(msg, indent=4):
    print(' ' * indent + msg, flush=True)

def _warn(msg):
    print('  ' + _yellow('WARN') + '  ' + msg, flush=True)

def _err(msg):
    print('  ' + _red('ERR') + '  ' + msg, flush=True)

def _estimate(lbl, hint):
    print(_dim(f'    ~ Expected: {lbl}  ({hint})'), flush=True)

def _ok(msg, elapsed=None):
    suf = _dim(f'  ({_fmt_time(elapsed)})') if elapsed is not None else ''
    print('  ' + _green('OK') + '  ' + msg + suf, flush=True)

def _fmt_time(s):
    if s < 0.01:
        return '<0.01 s'
    if s < 60:
        return f'{s:.1f} s'
    td  = timedelta(seconds=int(s))
    h, rem = divmod(td.seconds + td.days * 86400, 3600)
    m, sec = divmod(rem, 60)
    parts = []
    if h:
        parts.append(f'{h}h')
    if m:
        parts.append(f'{m}m')
    parts.append(f'{sec}s')
    return ' '.join(parts)

def _summary_table(rows):
    if not rows:
        return
    w = max(len(r[0]) for r in rows)
    print(flush=True)
    print(_bold('  Summary'), flush=True)
    print(_dim('  ' + '-' * (_W - 2)), flush=True)
    for lbl, val in rows:
        print(f'  {lbl:<{w}}  :  {_bold(str(val))}', flush=True)
    print(flush=True)

def _final_banner(path, elapsed):
    print(flush=True)
    print(_bold('=' * _W), flush=True)
    print(_green('  Extraction complete'.center(_W)), flush=True)
    print(_bold('=' * _W), flush=True)
    sz = Path(path).stat().st_size / 1_048_576 if Path(path).exists() else 0
    print(f'  Output : {_bold(path)}', flush=True)
    print(f'  Size   : {sz:.2f} MB', flush=True)
    print(f'  Time   : {_fmt_time(elapsed)}', flush=True)
    print(_bold('=' * _W), flush=True)
    print(flush=True)

# =============================================================================
# Utility helpers
# =============================================================================

def dim_of_etype(s):
    s = s.lower()
    if any(k in s for k in POINT_ELEM_KEYWORDS):   return 0
    if any(k in s for k in LINE_ELEM_KEYWORDS):    return 1
    if any(k in s for k in SURFACE_ELEM_KEYWORDS): return 2
    if any(k in s for k in VOLUME_ELEM_KEYWORDS):  return 3
    return -1

def java_to_list_1d(java_arr):
    return [java_arr[i] for i in range(int(java_arr.length))]

def sanitize(name):
    s = re.sub(r'[^\w\-.]', '_', str(name))
    s = re.sub(r'_+', '_', s).strip('_')
    return s or 'unnamed'

# =============================================================================
# ElemBucket
# =============================================================================

class ElemBucket:
    def __init__(self):
        self.ids        = []
        self.types      = []
        self.numnodes   = []
        self.conn_raw   = []
        self.entity_ids = []

    def add(self, eid, etype, conn, entity=-1):
        self.ids.append(eid)
        self.types.append(etype)
        self.numnodes.append(len(conn))
        self.conn_raw.append(conn)
        self.entity_ids.append(entity)

    def __len__(self):
        return len(self.ids)

    def to_arrays(self):
        if not self.ids:
            return (
                np.array([], np.int32),
                np.array([], h5py.string_dtype()),
                np.array([], np.int32),
                np.empty((0, 0), np.int32),
                np.array([], np.int32),
            )
        max_npe  = max(self.numnodes)
        n        = len(self.ids)
        conn_arr = np.full((n, max_npe), -1, dtype=np.int32)
        # Vectorised fill: group indices by nodes-per-element so each group
        # can be assigned as a single numpy operation.  Elements arrive
        # type-by-type from extract_all_elements, so groups are almost always
        # contiguous — the fast slice-assignment path dominates.
        npe_arr = np.asarray(self.numnodes, dtype=np.int32)
        for npe_val in np.unique(npe_arr):
            npe   = int(npe_val)
            where = np.where(npe_arr == npe)[0]
            s, e  = int(where[0]), int(where[-1]) + 1
            if e - s == len(where):          # contiguous block (fast path)
                conn_arr[s:e, :npe] = self.conn_raw[s:e]
            else:                             # scattered (rare, slow path)
                conn_arr[where, :npe] = np.array(
                    [self.conn_raw[i] for i in where], dtype=np.int32)
        return (
            np.array(self.ids,        np.int32),
            np.array(self.types,      h5py.string_dtype()),
            np.array(self.numnodes,   np.int32),
            conn_arr,
            np.array(self.entity_ids, np.int32),
        )

# =============================================================================
# HDF5 element group writer
# =============================================================================

def write_elem_group(grp, bucket, domain_id_map=None):
    ids, types, numnodes, conn, entity_ids = bucket.to_arrays()

    grp.create_dataset('Id',       data=ids,      **_HDF5_COMPRESS)
    grp.create_dataset('Type',     data=types,    **_HDF5_COMPRESS)
    grp.create_dataset('NumNodes', data=numnodes, **_HDF5_COMPRESS)

    ds = grp.create_dataset('Connectivity', data=conn, **_HDF5_COMPRESS)
    ds.attrs['padding_value'] = -1
    ds.attrs['index_base']    = 0
    ds.attrs['node_order']    = 'mesh'
    ds.attrs['note']          = (
        'Rows padded to max NumNodes with -1. '
        'Indices are 0-based positions into Nodes/Coordinates (mesh order). '
        'Node ordering is COMSOL-native (parametric u,v,w order). '
        'Readers must apply COMSOL->VTK permutations for quad/prism/hex: '
        'quad->[0,1,3,2], prism->[0,2,1,3,5,4], hex->[0,1,2,3,4,7,6,5]. '
        'tet and tri match VTK directly.')

    # Annotate each unique element type with its VTK equivalent
    if len(ids) > 0:
        types_present = set(
            t.decode() if isinstance(t, bytes) else str(t) for t in types)
        vtk_ids   = []
        vtk_names = []
        for t in sorted(types_present):
            entry = _COMSOL_VTK_MAP.get(t.lower())
            if entry:
                vtk_ids.append(entry[0])
                vtk_names.append(f'{t}->{entry[1]}')
        if vtk_ids:
            ds.attrs['vtk_type_ids']   = np.array(vtk_ids, np.int32)
            ds.attrs['vtk_type_names'] = '; '.join(vtk_names)

    if domain_id_map is not None and len(ids) > 0:
        n            = len(ids)
        dom_id_arr   = np.full(n, -1, np.int32)
        dom_name_arr = np.empty(n, dtype=object)

        for i, ent in enumerate(entity_ids):
            entry = domain_id_map.get(int(ent))
            if entry is not None:
                dom_id_arr[i]   = entry[0]
                dom_name_arr[i] = entry[1]
            else:
                dom_name_arr[i] = f'Unknown_entity_{ent}'

        d1 = grp.create_dataset('DomainId', data=dom_id_arr, **_HDF5_COMPRESS)
        d1.attrs['note'] = 'Integer domain ID per element. See DomainLegend.'

        d2 = grp.create_dataset(
            'DomainName',
            data=dom_name_arr.astype(h5py.string_dtype()),
            **_HDF5_COMPRESS)
        d2.attrs['note'] = 'Human-readable domain label per element.'

        seen = {}
        for did, dname in zip(dom_id_arr, dom_name_arr):
            if did not in seen:
                seen[did] = dname

        leg_ids   = np.array(sorted(seen.keys()), np.int32)
        leg_names = np.array([seen[k] for k in leg_ids], h5py.string_dtype())
        leg = grp.create_group('DomainLegend')
        leg.attrs['note'] = 'Unique domain IDs and names in this group.'
        leg.create_dataset('Id',   data=leg_ids,   **_HDF5_COMPRESS)
        leg.create_dataset('Name', data=leg_names, **_HDF5_COMPRESS)
        _step(f'DomainId/DomainName: {len(leg_ids)} unique domains')

# =============================================================================
# COMSOL entity name resolution
# =============================================================================

def build_entity_name_map(java, comp_tag):
    name_map = {}
    comp     = java.component(comp_tag)

    try:
        sel_tags = java_to_list_1d(comp.selection().tags())
        _step(f'Found {len(sel_tags)} named selection(s)')
        for stag in sel_tags:
            try:
                sel   = comp.selection(stag)
                label = str(sel.label()).strip() or str(stag)
                for dim in (3, 2, 1, 0):
                    try:
                        for ent in sel.entities(dim):
                            key = (dim, int(ent))
                            if key not in name_map:
                                name_map[key] = label
                                _step(
                                    f'{DIM_PREFIX[dim]} entity {int(ent)}'
                                    f' -> "{label}"', 6)
                    except Exception:
                        pass
            except Exception:
                pass
    except Exception as exc:
        _warn(f'comp.selection(): {exc}')

    try:
        for gtag in java_to_list_1d(comp.geom().tags()):
            try:
                for ftag in java_to_list_1d(
                        comp.geom(gtag).feature().tags()):
                    try:
                        feat  = comp.geom(gtag).feature(ftag)
                        label = str(feat.label()).strip()
                        if not label:
                            continue
                        for dim in (3, 2, 1, 0):
                            try:
                                for ent in feat.selection().entities(dim):
                                    key = (dim, int(ent))
                                    if key not in name_map:
                                        name_map[key] = label
                            except Exception:
                                pass
                    except Exception:
                        pass
            except Exception:
                pass
    except Exception as exc:
        _warn(f'Geometry feature labels: {exc}')

    return name_map


def make_group_name(dim, entity, name_map, used_names):
    raw  = name_map.get((dim, entity), f'Entity_{entity}')
    base = f"{DIM_PREFIX[dim]}_{sanitize(raw)}"
    name = base
    if name in used_names:
        name = f'{base}_e{entity}'
    used_names.add(name)
    return name

# =============================================================================
# Model loading helpers
# =============================================================================

def _apply_cores_to_study(java, stag, cores):
    for ftag in java_to_list_1d(java.study(stag).feature().tags()):
        feat = java.study(stag).feature(ftag)
        for prop in ('ngen', 'nthread', 'numthreads', 'cores'):
            try:
                feat.set(prop, str(cores))
            except Exception:
                pass


def _study_sol_tag_hint(java, study_tag):
    """Best-effort mapping from study tag to solver tag."""
    try:
        for ftag in java_to_list_1d(java.study(study_tag).feature().tags()):
            try:
                s = str(java.study(study_tag).feature(ftag).getString('sol'))
                if s and s.lower() not in ('none', ''):
                    return s
            except BaseException:
                pass
    except BaseException:
        pass
    return None


def _parse_tlist_count(tlist_raw):
    if not tlist_raw:
        return None
    s = str(tlist_raw).strip()
    m = re.match(r'^range\(([^,]+),([^,]+),([^\)]+)\)$', s)
    if m:
        try:
            a = float(m.group(1).strip())
            h = float(m.group(2).strip())
            b = float(m.group(3).strip())
            if h == 0:
                return None
            n = int(round((b - a) / h)) + 1
            return n if n > 0 else None
        except BaseException:
            return None
    parts = [p for p in re.split(r'[\s,]+', s) if p]
    return len(parts) if len(parts) > 1 else None


def _estimate_study_steps(java, stag):
    """Estimate expected step count from study time/parameter lists."""
    best = None
    try:
        for ftag in java_to_list_1d(java.study(stag).feature().tags()):
            feat = java.study(stag).feature(ftag)
            for prop in ('tlist', 'plist', 'plistarr'):
                try:
                    n = _parse_tlist_count(feat.getString(prop))
                    if n is not None:
                        best = max(best or 0, n)
                except BaseException:
                    pass
    except BaseException:
        pass
    return best


def _run_study_with_progress(model, java, stag):
    """Run one study and print a live progress bar."""
    expected = _estimate_study_steps(java, stag)
    sol_tag = _study_sol_tag_hint(java, stag)
    done_box = {'done': False, 'err': None}

    def _worker():
        try:
            model.java.study(stag).run()
        except BaseException as exc:
            done_box['err'] = exc
        finally:
            done_box['done'] = True

    th = threading.Thread(target=_worker, daemon=True)
    th.start()
    t0 = time.time()
    frames = ['|', '/', '-', '\\']
    frame_i = 0

    while not done_box['done']:
        steps = 0
        try:
            tags = [sol_tag] if sol_tag else [str(t) for t in java_to_list_1d(java.sol().tags())]
            for t in tags:
                if not t:
                    continue
                try:
                    s = java.sol(t)
                    try:
                        steps = max(steps, int(s.getInnerSolNum()))
                    except BaseException:
                        pass
                    try:
                        steps = max(steps, len(java_to_list_1d(s.getPVals())))
                    except BaseException:
                        pass
                except BaseException:
                    pass
        except BaseException:
            pass

        if expected and expected > 0:
            frac = min(1.0, steps / float(expected))
            filled = int(frac * 24)
            bar = '#' * filled + '-' * (24 - filled)
            pct = int(frac * 100)
            line = (f'    progress [{bar}] {pct:3d}%  '
                    f'steps={steps}/{expected}  elapsed={_fmt_time(time.time()-t0)}')
        else:
            frame = frames[frame_i % len(frames)]
            frame_i += 1
            filled = min(steps, 24)
            bar = '#' * filled + '-' * (24 - filled)
            line = (f'    progress {frame} [{bar}]  '
                    f'steps={steps}  elapsed={_fmt_time(time.time()-t0)}')

        sys.stdout.write('\r' + line)
        sys.stdout.flush()
        time.sleep(1.0)

    th.join()
    sys.stdout.write('\r' + ' ' * 120 + '\r')
    sys.stdout.flush()
    if done_box['err'] is not None:
        raise RuntimeError(str(done_box['err']))


def mesh_solve_save(model, save_path, comp_tag,
                    cores=None, study_tags_filter=None):
    _section('MESHING')
    mesh_tags = java_to_list_1d(
        model.java.component(comp_tag).mesh().tags())
    if not mesh_tags:
        raise RuntimeError(f'No mesh sequences found under "{comp_tag}".')
    _estimate('seconds to minutes', 'depends on geometry and element size')
    t_mesh = time.time()
    for mtag in mesh_tags:
        _step(f'Building mesh "{mtag}" ...')
        tm = time.time()
        model.java.component(comp_tag).mesh(mtag).run()
        _ok(f'Mesh "{mtag}" complete', elapsed=time.time() - tm)
    _ok(f'All meshes built ({len(mesh_tags)} total)',
        elapsed=time.time() - t_mesh)

    _section('SOLVING')
    all_tags = java_to_list_1d(model.java.study().tags())
    if not all_tags:
        raise RuntimeError('No studies found in model.')
    run_tags = study_tags_filter or all_tags
    if study_tags_filter:
        missing = [t for t in study_tags_filter if t not in all_tags]
        if missing:
            raise ValueError(
                f'Study tags not found: {missing}. '
                f'Available: {all_tags}')
    _step(f'Studies to run : {run_tags}')
    if cores:
        _step(f'CPU cores      : {cores}')
    _estimate('minutes to hours', 'depends on mesh, physics, time steps')
    t_solve = time.time()
    for stag in run_tags:
        if cores:
            _apply_cores_to_study(model.java, stag, cores)
        _step(f'Running study "{stag}" ...')
        ts = time.time()
        _run_study_with_progress(model, model.java, stag)
        _ok(f'Study "{stag}" finished', elapsed=time.time() - ts)
    _ok('All studies complete', elapsed=time.time() - t_solve)

    _section('SAVING SOLVED MODEL')
    ts = time.time()
    # Ensure mesh data is embedded in the saved file by enabling "savemesh"
    # on every mesh sequence under the component.
    try:
        for mtag in mesh_tags:
            try:
                model.java.component(comp_tag).mesh(mtag).set('savemesh', True)
            except Exception:
                pass
    except Exception:
        pass
    # Use COMSOL's native Java save so all data (mesh + solution) is written.
    try:
        model.java.setFilePath(str(Path(save_path).resolve()))
        model.java.save()
    except Exception:
        model.save(str(Path(save_path)))
    sz = Path(save_path).stat().st_size / 1_048_576
    _ok(f'Saved -> {Path(save_path).resolve()}  ({sz:.1f} MB)',
        elapsed=time.time() - ts)
    return model

# =============================================================================
# Physics classification
# =============================================================================

def classify_physics(java, comp_tag):
    domain_3d, domain_2d, domain_1d, domain_0d = set(), set(), set(), set()
    for phys_tag in java_to_list_1d(java.physics().tags()):
        phys       = java.physics(phys_tag)
        p3, p2, p1, p0 = set(), set(), set(), set()
        for feat_tag in java_to_list_1d(phys.feature().tags()):
            feat = phys.feature(feat_tag)
            for dim, bkt in ((3, p3), (2, p2), (1, p1), (0, p0)):
                try:
                    ents = feat.selection().entities(dim)
                    if ents:
                        bkt.update(int(e) for e in ents)
                except Exception:
                    pass
        if p3:
            domain_3d.update(p3)
            _step(f'[vol]   "{phys_tag}" -> {len(p3)} 3-D entities')
        elif p2:
            domain_2d.update(p2)
            _step(f'[shell] "{phys_tag}" -> {len(p2)} 2-D entities')
        elif p1:
            domain_1d.update(p1)
            _step(f'[line]  "{phys_tag}" -> {len(p1)} 1-D entities')
        elif p0:
            domain_0d.update(p0)
            _step(f'[point] "{phys_tag}" -> {len(p0)} 0-D entities')
        else:
            _warn(f'Physics "{phys_tag}": no entities found — skipped')
    return domain_3d, domain_2d, domain_1d, domain_0d

# =============================================================================
# Mesh data helpers
# =============================================================================

def _read_vertex(md, label):
    raw     = md.getVertex()
    n_dim   = int(raw.length)
    n_nodes = int(raw[0].length)
    _step(f'{label}  getVertex() shape: [{n_dim}][{n_nodes}]')
    if n_nodes == 0:
        raise ValueError('Mesh data object reports zero nodes.')
    coords = np.empty((n_nodes, 3), dtype=np.float64)
    for d in range(n_dim):
        row = raw[d]
        for i in range(n_nodes):
            coords[i, d] = float(row[i])
    if n_dim == 2:
        coords[:, 2] = 0.0
    return coords, md


def _mesh_tags_for_component(comp, mesh_tag_hint=None):
    all_tags = java_to_list_1d(comp.mesh().tags())
    if mesh_tag_hint:
        return [mesh_tag_hint]
    return all_tags


def _try_mesh_data_paths(java, comp, mtags):
    last_err = None

    for mtag in mtags:
        mnode = comp.mesh(mtag)
        try:
            _step(f'Mesh "{mtag}": '
                  f'{int(mnode.stat().getNumVertex())} vertices')
        except BaseException:
            pass
        try:
            coords, md = _read_vertex(mnode.data(), f'mesh("{mtag}").data()')
            return coords, md, None
        except BaseException as exc:
            last_err = exc
            _step(f'Path 1 mesh("{mtag}").data(): {exc}')

    try:
        for mtag in java_to_list_1d(java.mesh().tags()):
            try:
                mesh_obj = java.mesh(mtag)
                coords, _ = _read_vertex(mesh_obj, f'java.mesh("{mtag}")')
                md = mesh_obj
                return coords, md, None
            except BaseException as exc:
                last_err = exc
                _step(f'Path 2 java.mesh("{mtag}"): {exc}')
    except BaseException as exc:
        last_err = exc
        _step(f'Path 2 java.mesh(): {exc}')

    try:
        for stag in java_to_list_1d(java.sol().tags()):
            try:
                return _read_vertex(java.sol(stag).data(),
                                    f'sol("{stag}").data()')
            except BaseException as exc:
                last_err = exc
                _step(f'Path 3 sol("{stag}").data(): {exc}')
    except BaseException as exc:
        last_err = exc
        _step(f'Path 3 java.sol(): {exc}')

    try:
        for dtag in java_to_list_1d(java.result().dataset().tags()):
            try:
                return _read_vertex(
                    java.result().dataset(dtag).getMesh(),
                    f'dataset("{dtag}").getMesh()')
            except BaseException as exc:
                last_err = exc
                _step(f'Path 4 dataset("{dtag}").getMesh(): {exc}')
    except BaseException as exc:
        last_err = exc
        _step(f'Path 4 result.dataset(): {exc}')

    return None, None, last_err


def _rebuild_component_meshes(comp, mtags):
    _warn('Loaded model exposes empty mesh data; rebuilding mesh sequences once before retrying.')
    for mtag in mtags:
        _step(f'Rebuilding mesh "{mtag}" for readback ...')
        t0 = time.time()
        comp.mesh(mtag).run()
        _ok(f'Mesh "{mtag}" rebuilt', elapsed=time.time() - t0)


def get_mesh_data(java, comp_tag, mesh_tag_hint=None):
    comp  = java.component(comp_tag)
    mtags = _mesh_tags_for_component(comp, mesh_tag_hint)

    coords, md, last_err = _try_mesh_data_paths(java, comp, mtags)
    if coords is not None:
        return coords, md

    _rebuild_component_meshes(comp, mtags)
    coords, md, retry_err = _try_mesh_data_paths(java, comp, mtags)
    if coords is not None:
        return coords, md

    err = retry_err or last_err
    if err is not None:
        raise RuntimeError(f'All mesh data paths failed. Last error: {err}')
    raise RuntimeError('All mesh data paths failed.')

# =============================================================================
# Element extraction
# =============================================================================

def extract_all_elements(md, domain_3d, domain_2d, domain_1d, domain_0d):
    domain_sets = {3: domain_3d, 2: domain_2d, 1: domain_1d, 0: domain_0d}
    dom_bucket  = ElemBucket()
    dom_eid     = 1
    non_phys    = {d: defaultdict(ElemBucket) for d in (3, 2, 1, 0)}
    np_eids     = {d: defaultdict(lambda: 1)  for d in (3, 2, 1, 0)}

    types_java = md.getTypes()
    n_types    = int(types_java.length)
    _step(f'Element types ({n_types}): '
          f'{[str(types_java[i]) for i in range(n_types)]}')

    for ti in range(n_types):
        etype     = types_java[ti]
        etype_str = str(etype)
        dim       = dim_of_etype(etype_str.lower())
        if dim < 0:
            _step(f'{etype_str:20s}  -> skipped (unrecognised type)')
            continue

        elems_java = md.getElem(etype)
        ents_java  = md.getElemEntity(etype)
        npe        = int(elems_java.length)
        n_elems    = int(elems_java[0].length)
        dom_set    = domain_sets[dim]
        n_dom      = 0
        n_non      = 0

        for ei in range(n_elems):
            ent  = int(ents_java[ei])
            conn = [int(elems_java[ni][ei]) for ni in range(npe)]
            if ent in dom_set:
                dom_bucket.add(dom_eid, etype_str, conn, entity=ent)
                dom_eid += 1
                n_dom   += 1
            else:
                bkt = non_phys[dim][ent]
                bkt.add(np_eids[dim][ent], etype_str, conn)
                np_eids[dim][ent] += 1
                n_non += 1

        _step(f'{etype_str:20s}  dim={dim}  total={n_elems:8d}  '
              f'domain={n_dom:8d}  non-domain={n_non:8d}')

    if len(dom_bucket) == 0:
        _warn('Domain filter kept nothing -> falling back to ALL volume elements')
        dom_eid = 1
        for ti in range(n_types):
            etype     = types_java[ti]
            etype_str = str(etype)
            if dim_of_etype(etype_str.lower()) == 3:
                elems_java = md.getElem(etype)
                npe        = int(elems_java.length)
                n_elems    = int(elems_java[0].length)
                for ei in range(n_elems):
                    conn = [int(elems_java[ni][ei]) for ni in range(npe)]
                    dom_bucket.add(dom_eid, etype_str, conn)
                    dom_eid += 1
        _warn(f'Fallback kept {len(dom_bucket)} volume elements')

    return dom_bucket, non_phys

# =============================================================================
# Study / solution discovery
# =============================================================================

def _sol_tag_for_study(java, study_tag, sol_tags_all, study_idx):
    try:
        for ftag in java_to_list_1d(java.study(study_tag).feature().tags()):
            try:
                s = str(java.study(study_tag).feature(ftag).getString('sol'))
                if s and s.lower() not in ('none', ''):
                    return s
            except Exception:
                pass
    except Exception:
        pass
    if study_idx < len(sol_tags_all):
        return str(sol_tags_all[study_idx])
    return None


def _times_from_sol(java, sol_tag):
    if not sol_tag:
        return np.array([0.0], float)
    try:
        sol = java.sol(sol_tag)
        try:
            pv = java_to_list_1d(sol.getPVals())
            if pv:
                arr = np.array([float(v) for v in pv], float)
                if arr.size > 0:
                    return arr
        except Exception:
            pass
        try:
            n = int(sol.getInnerSolNum())
            if n > 1:
                return np.arange(float(n))
        except Exception:
            pass
    except Exception:
        pass
    return np.array([0.0], float)


def build_study_info(java):
    study_tags   = java_to_list_1d(java.study().tags())
    n_studies    = len(study_tags)
    sol_tags_all = []
    try:
        sol_tags_all = java_to_list_1d(java.sol().tags())
    except Exception:
        pass

    pad       = len(str(n_studies))
    info_list = []
    for i, stag in enumerate(study_tags):
        try:
            label = str(java.study(stag).label()).strip()
        except Exception:
            label = ''
        if not label:
            label = str(stag)
        sol_tag   = _sol_tag_for_study(java, str(stag), sol_tags_all, i)
        times     = _times_from_sol(java, sol_tag)
        hdf5_name = f"{str(i + 1).zfill(pad)}_{sanitize(label)}"
        T         = len(times)
        kind      = 'time-dependent' if T > 1 else 'stationary'
        info_list.append(dict(
            index=i + 1, tag=str(stag), label=label,
            hdf5_name=hdf5_name, sol_tag=sol_tag,
            outer_idx=i, times=times))
        _step(f'Study {i+1}: "{label}"  '
              f'[tag={stag}  sol={sol_tag}  T={T}  {kind}]  '
              f'-> "{hdf5_name}"')
    return info_list

# =============================================================================
# CutPoint dataset creation
# =============================================================================

def create_cutpoint_dataset(model, java, coords, base_dataset='dset1'):
    """
    Create a CutPoint3D dataset at every mesh node coordinate.

    The COMSOL Java API requires two arguments:
        datasets.create(tag_name, type_string)

    A millisecond timestamp is appended to the tag to avoid collisions.
    Coordinates are written with 15 significant figures so COMSOL's
    nearest-node snap does not move points to the wrong node.
    """
    N      = len(coords)
    cp_tag = f'cpt_mesh_{int(time.time() * 1000) % 1000000}'
    _step(f'Creating CutPoint3D dataset "{cp_tag}" '
          f'for {N:,} mesh nodes (base: "{base_dataset}") ...')
    t0 = time.time()

    datasets = model.java.result().dataset()
    cp       = datasets.create(cp_tag, 'CutPoint3D')
    cp.set('pointx', ' '.join(f'{v:.15g}' for v in coords[:, 0]))
    cp.set('pointy', ' '.join(f'{v:.15g}' for v in coords[:, 1]))
    cp.set('pointz', ' '.join(f'{v:.15g}' for v in coords[:, 2]))
    cp.set('data', base_dataset)

    _ok(f'CutPoint3D "{cp_tag}" created ({N:,} points)',
        elapsed=time.time() - t0)
    return cp_tag

# =============================================================================
# Field evaluation via Java EvalPoint (works with runtime-created datasets)
# =============================================================================

def _derive_expr_list(expr_list, suffix):
    out = []
    for expr in expr_list:
        if '.' in expr:
            head, tail = expr.split('.', 1)
            out.append(f'{head}{suffix}.{tail}')
        else:
            out.append(f'{expr}{suffix}')
    return out


def _packed_vector_base(expr):
    parts = expr.split('.')
    if not parts:
        return None
    if parts[-1] not in {'u', 'v', 'w'}:
        return None
    parts[-1] = 'u'
    return '.'.join(parts)


def _expr_matches_active_dofs(expr, active_names):
    if expr in active_names:
        return True
    packed_base = _packed_vector_base(expr)
    return packed_base in active_names if packed_base else False


_COMP_NS_RE = re.compile(r'^comp\d+\.')

def _field_available_in_solution(field_config, active_dofs):
    if not active_dofs:
        return True

    # Include both 'comp1.u' and bare 'u' so candidates without the
    # component-namespace prefix (u, v, w, p, T ...) still match.
    active_names = {str(k) for k in active_dofs.keys()}
    active_names |= {_COMP_NS_RE.sub('', n) for n in active_names}
    n_comp = len(field_config['components'])
    candidate_groups = [
        list(expr_list)
        for expr_list in field_config['candidates']
        if len(expr_list) == n_comp
    ]

    for expr_list in candidate_groups:
        if all(_expr_matches_active_dofs(expr, active_names) for expr in expr_list):
            return True

    for suffix in ('2', '3'):
        for expr_list in candidate_groups:
            alt_expr = _derive_expr_list(expr_list, suffix)
            if all(_expr_matches_active_dofs(expr, active_names) for expr in alt_expr):
                return True

    return False


def _run_with_timeout(func, timeout_sec, desc='operation'):
    """Run func() in a thread with a timeout. Returns (result, error_str)."""
    result_box = [None]
    error_box = [None]
    def _worker():
        try:
            result_box[0] = func()
        except Exception as exc:
            error_box[0] = str(exc)
    t = threading.Thread(target=_worker, daemon=True)
    t.start()
    t.join(timeout=timeout_sec)
    if t.is_alive():
        return None, f'{desc} timed out after {timeout_sec}s'
    if error_box[0] is not None:
        return None, error_box[0]
    return result_box[0], None


def _java_matrix_to_numpy_optimized(raw_java, n_rows, n_cols):
    """
    ULTRA-OPTIMIZED: Zero-copy transfer from Java RAM to NumPy C-RAM.
    Bypasses all Python for-loops for instant matrix conversion.
    """
    try:
        # Fast Path: Tell NumPy to ingest the JPype array directly.
        # Cast straight to float32 to instantly halve the RAM footprint.
        return np.array(raw_java, dtype=np.float32)
    except Exception:
        # Safe Fallback (for older JPype versions):
        # Extract rows natively and vstack. Still significantly faster than nested loops.
        return np.vstack([np.array(raw_java[i], dtype=np.float32) for i in range(n_rows)])


def evaluate_field_at_cutpoint(java, cp_tag, expressions, times, expected_nodes,
                               per_expr_timeout=120, use_cache=True):
    """
    Evaluate scalar expressions at all CutPoint coordinates for every time step
    using the COMSOL Java EvalPoint numerical feature.

    Returns (data, None) where data is float64 (N_nodes, N_comp, T) on success,
    or (None, error_str) on failure.
    """
    T         = len(times)
    comp_arrs = []
    num_tag   = f'pev_{int(time.time() * 1000) % 1000000}'
    num       = None
    n_cached  = 0
    n_evaluated = 0

    try:
        num = java.result().numerical().create(num_tag, 'EvalPoint')
        num.set('data', cp_tag)

        for expr in expressions:
            # OPTIMIZATION 2: Check cache first
            if use_cache:
                cached = _expression_cache.get(expr)
                if cached is not None:
                    _step(f'    "{expr}" (cached)', 6)
                    comp_arrs.append(cached)
                    n_cached += 1
                    continue

            t_expr = time.time()
            num.set('expr', expr)
            n_evaluated += 1

            try:
                raw_java, timeout_err = _run_with_timeout(
                    lambda: num.getReal(), per_expr_timeout,
                    desc=f'getReal() for "{expr}"')
                if timeout_err:
                    return None, timeout_err
            except Exception as exc:
                return None, f'getReal() failed for "{expr}": {exc}'

            try:
                n_rows = len(raw_java)
                n_cols = int(raw_java[0].length) if n_rows > 0 else 0
            except Exception as exc:
                return None, f'Unexpected getReal() layout for "{expr}": {exc}'

            if n_rows == 0 or n_cols == 0:
                return None, f'Empty result matrix for "{expr}"'

            try:
                if n_rows == expected_nodes and n_cols == T:
                    comp = _java_matrix_to_numpy_optimized(raw_java, n_rows, n_cols)
                elif n_rows == T and n_cols == expected_nodes:
                    comp = _java_matrix_to_numpy_optimized(raw_java, n_rows, n_cols).T
                elif T == 1 and n_rows == expected_nodes:
                    comp = np.array([
                        float(raw_java[i][0]) for i in range(n_rows)
                    ], dtype=np.float64).reshape(expected_nodes, 1)
                elif T == 1 and n_cols == expected_nodes:
                    comp = np.array([
                        float(raw_java[0][j]) for j in range(n_cols)
                    ], dtype=np.float64).reshape(expected_nodes, 1)
                else:
                    return None, (
                        f'Unexpected matrix shape for "{expr}": '
                        f'rows={n_rows}, cols={n_cols}, '
                        f'expected_nodes={expected_nodes}, T={T}')
            except Exception as exc:
                return None, f'Matrix conversion failed for "{expr}": {exc}'

            # Store in cache for future use
            if use_cache:
                _expression_cache.put(expr, comp)

            comp_arrs.append(comp)

    finally:
        if num is not None:
            try:
                java.result().numerical().remove(num_tag)
            except Exception:
                pass

        # Print cache stats if helpful
        if False and use_cache and (n_cached + n_evaluated) > 1:
            cache_stats = _expression_cache.stats()
            if cache_stats['total'] > 0 and cache_stats['hit_rate'] > 0:
                _step(f'    Cache: {cache_stats["hits"]}/{cache_stats["total"]} hits ({cache_stats["hit_rate"]:.0f}%)', 6)

    try:
        return np.stack(comp_arrs, axis=1), None
    except Exception as exc:
        return None, f'Component stack failed: {exc}'

# =============================================================================
# Domain ID map
# =============================================================================

def build_domain_id_map(domain_3d, domain_2d, domain_1d, domain_0d, name_map):
    domain_id_map = {}
    current_id    = 1
    for dim, dom_set in [(3, domain_3d), (2, domain_2d),
                         (1, domain_1d),  (0, domain_0d)]:
        for ent in sorted(dom_set):
            label = name_map.get((dim, ent), f'Domain_entity_{ent}')
            domain_id_map[ent] = (current_id, label)
            _step(f'Domain {current_id:3d}  entity={ent}  '
                  f'dim={dim}  label="{label}"')
            current_id += 1
    return domain_id_map

# =============================================================================
# Module-level helpers for chunked streaming evaluation
# =============================================================================

def _find_sol_dataset(java, sol_tag):
    """Return the dataset tag linked to sol_tag, falling back to dset1."""
    try:
        ds_tags = java_to_list_1d(java.result().dataset().tags())
    except BaseException:
        return 'dset1'
    linked = None
    first_dset = None
    for t in ds_tags:
        ts = str(t)
        if first_dset is None and 'dset' in ts.lower():
            first_dset = ts
        try:
            val = str(java.result().dataset(ts).getString('sol'))
            if val == sol_tag:
                linked = ts
                break
        except BaseException:
            pass
    return linked or first_dset or 'dset1'


def _eval_exprs_via_num(num, expressions, expected_nodes, T,
                        label='', indent=8):
    """
    Evaluate ``expressions`` through an already-created EvalPoint feature
    ``num`` (caller is responsible for setting num.set('data', cp_tag)).

    Returns (data, None) with data shape (expected_nodes, n_comp, T) float64,
    or (None, error_str) on any failure.
    """
    comp_arrs = []
    for expr in expressions:
        t_expr = time.time()
        sys.stdout.write(' ' * indent + f'{label}  evaluating "{expr}" ...')
        sys.stdout.flush()
        try:
            num.set('expr', expr)
            raw_java = num.getReal()
        except BaseException as exc:
            sys.stdout.write(f'  FAILED\n')
            sys.stdout.flush()
            return None, f'getReal() failed for "{expr}": {exc}'
        try:
            n_rows = len(raw_java)
            n_cols = int(raw_java[0].length) if n_rows > 0 else 0
        except BaseException as exc:
            sys.stdout.write(f'  FAILED\n')
            sys.stdout.flush()
            return None, f'Unexpected getReal() layout for "{expr}": {exc}'
        if n_rows == 0 or n_cols == 0:
            sys.stdout.write(f'  FAILED (empty)\n')
            sys.stdout.flush()
            return None, f'Empty result matrix for "{expr}"'
        try:
            if n_rows == expected_nodes and n_cols == T:
                comp = _java_matrix_to_numpy_optimized(raw_java, n_rows, n_cols)
            elif n_rows == T and n_cols == expected_nodes:
                comp = _java_matrix_to_numpy_optimized(raw_java, n_rows, n_cols).T
            elif T == 1 and n_rows == expected_nodes:
                comp = np.array(
                    [float(raw_java[i][0]) for i in range(n_rows)],
                    dtype=np.float64).reshape(expected_nodes, 1)
            elif T == 1 and n_cols == expected_nodes:
                comp = np.array(
                    [float(raw_java[0][j]) for j in range(n_cols)],
                    dtype=np.float64).reshape(expected_nodes, 1)
            else:
                sys.stdout.write(f'  FAILED (shape mismatch)\n')
                sys.stdout.flush()
                return None, (
                    f'Unexpected matrix shape for "{expr}": '
                    f'rows={n_rows}, cols={n_cols}, '
                    f'nodes={expected_nodes}, T={T}')
        except BaseException as exc:
            sys.stdout.write(f'  FAILED\n')
            sys.stdout.flush()
            return None, f'Matrix conversion failed for "{expr}": {exc}'
        sys.stdout.write(f'  OK  ({_fmt_time(time.time() - t_expr)})\n')
        sys.stdout.flush()
        comp_arrs.append(comp)
    try:
        return np.stack(comp_arrs, axis=1), None
    except BaseException as exc:
        return None, f'Component stack failed: {exc}'


def _evaluate_chunk_all_fields(java, coords_chunk, field_configs, times, sol_ds,
                               chunk_label='', space_dim=3):
    """
    Streaming Chunk -> All Fields -> Destroy evaluator.

    For one coordinate chunk this function:
      1. Creates exactly ONE CutPoint3D at the chunk coordinates.
      2. Creates exactly ONE EvalPoint linked to it.
      3. Evaluates EVERY field config through that single EvalPoint.
      4. Unconditionally calls .remove() on the EvalPoint then the CutPoint.

    This is the critical pattern that avoids repeated expensive spatial
    searches and keeps the JVM heap from bloating.

    Returns dict: {fname: (data_or_None, err_or_None, matched_expr_or_None,
                           comps, unit, n_comp)}
    where data is float64 of shape (N_chunk, n_comp, T).
    """
    N_chunk = len(coords_chunk)
    T       = len(times)
    ts      = int(time.time() * 1000) % 100_000_000
    cp_tag  = f'cpt_c_{ts}'
    num_tag = f'pev_c_{ts}'
    num     = None
    results = {}
    lbl     = f'[{chunk_label}]  ' if chunk_label else ''

    try:
        # --- One CutPoint (2D or 3D) for the entire chunk ---
        cp_type = 'CutPoint3D' if space_dim == 3 else 'CutPoint2D'
        t_cp = time.time()
        _step(f'{lbl}Creating {cp_type} for {N_chunk:,} nodes ...', 8)
        cp = java.result().dataset().create(cp_tag, cp_type)
        cp.set('pointx', ' '.join(f'{v:.15g}' for v in coords_chunk[:, 0]))
        cp.set('pointy', ' '.join(f'{v:.15g}' for v in coords_chunk[:, 1]))
        if space_dim == 3:
            cp.set('pointz', ' '.join(f'{v:.15g}' for v in coords_chunk[:, 2]))
        cp.set('data', sol_ds)
        _step(f'{lbl}{cp_type} ready  ({_fmt_time(time.time() - t_cp)})', 8)

        # --- One EvalPoint reused for every field ---
        num = java.result().numerical().create(num_tag, 'EvalPoint')
        num.set('data', cp_tag)

        for fc in field_configs:
            fname  = fc['name']
            comps  = fc['components']
            unit   = fc['unit']
            n_comp = len(comps)
            data   = None
            err    = None
            matched_expr = None
            tried  = []
            t_field = time.time()
            _step(f'{lbl}Field: {fname} ...', 8)

            for expr_list in fc['candidates']:
                if len(expr_list) != n_comp:
                    continue
                tried.append(expr_list)
                data, err = _eval_exprs_via_num(num, expr_list, N_chunk, T,
                                                label=fname, indent=10)
                if data is not None:
                    matched_expr = expr_list
                    break

            if data is None:
                for suffix in ('2', '3'):
                    for expr_list in tried:
                        alt  = _derive_expr_list(expr_list, suffix)
                        data, err = _eval_exprs_via_num(num, alt, N_chunk, T,
                                                        label=fname, indent=10)
                        if data is not None:
                            matched_expr = alt
                            break
                    if data is not None:
                        break

            if data is not None:
                _step(f'{lbl}  {fname} done  ({_fmt_time(time.time() - t_field)})', 8)
            else:
                _step(f'{lbl}  {fname} not available: {err}', 8)

            results[fname] = (data, err, matched_expr, comps, unit, n_comp)

    except BaseException as exc:
        for fc in field_configs:
            if fc['name'] not in results:
                results[fc['name']] = (
                    None, f'Chunk setup failed: {exc}',
                    None, fc['components'], fc['unit'], len(fc['components']))

    finally:
        # Always destroy EvalPoint first, then CutPoint3D
        if num is not None:
            try:
                java.result().numerical().remove(num_tag)
            except BaseException:
                pass
        try:
            java.result().dataset().remove(cp_tag)
        except BaseException:
            pass

    return results


def _prioritize_candidates(field_configs, active_dofs):
    """
    Return copies of field_configs with DOF-matching candidate expression
    lists moved to the front so the probe tries the right expressions first.
    """
    if not active_dofs:
        return field_configs
    active_names = {str(k) for k in active_dofs.keys()}
    active_names |= {_COMP_NS_RE.sub('', n) for n in active_names}
    result = []
    for fc in field_configs:
        n_comp = len(fc['components'])
        matching = []
        non_matching = []
        seen = set()

        def _append_unique(target, expr_list):
            key = tuple(expr_list)
            if key not in seen:
                target.append(list(expr_list))
                seen.add(key)

        for expr_list in fc['candidates']:
            if len(expr_list) != n_comp:
                continue
            if all(_expr_matches_active_dofs(e, active_names) for e in expr_list):
                _append_unique(matching, expr_list)
                continue
            # If a suffixed variant matches the active DOFs, probe that derived
            # expression directly instead of retrying the known-missing base form.
            derived_match = None
            for suffix in ('2', '3'):
                alt = _derive_expr_list(expr_list, suffix)
                if all(_expr_matches_active_dofs(e, active_names) for e in alt):
                    derived_match = alt
                    break
            if derived_match is not None:
                _append_unique(matching, derived_match)
            else:
                _append_unique(non_matching, expr_list)
        result.append(dict(fc, candidates=matching + non_matching))
    return result


# =============================================================================
# Analysis group writer
# =============================================================================

def write_analysis_group(model, java, study_info_list, analysis_grp, coords,
                         chunk_size=200_000, fields_to_extract=None, space_dim=3):
    N = len(coords)
    for info in study_info_list:
        grp_name = info['hdf5_name']
        sol_tag  = info['sol_tag']
        label    = info['label']
        times    = info['times']
        T        = len(times)
        is_td    = T > 1
        kind     = 'time-dependent' if is_td else 'stationary'
        _step(f'Study: "{label}"  ->  "{grp_name}"')
        sg = analysis_grp.create_group(grp_name)
        sg.attrs['comsol_study_tag']   = info['tag']
        sg.attrs['comsol_study_label'] = label
        if sol_tag is None:
            _warn(f'No solution tag for "{label}" — skipped')
            sg.attrs['status'] = 'no_solution'
            continue
        n_chunks = -(-N // chunk_size)   # ceiling division
        _step(f'Solution tag   : {sol_tag}', 6)
        _step(f'Time steps     : {T}  ({kind})', 6)
        _step(f'Nodes          : {N:,}', 6)
        _step(f'Chunk size     : {chunk_size:,}  ({n_chunks} chunk(s))', 6)
        if is_td:
            _step(f't range        : [{times[0]:.4g}, {times[-1]:.4g}] s', 6)
        sg.attrs['n_timesteps']       = T
        sg.attrs['is_time_dependent'] = int(is_td)
        sg.attrs['sol_tag']           = sol_tag
        sg.attrs['node_order']        = 'mesh'
        td = sg.create_dataset('Times', data=times.astype(np.float64),
                               **_HDF5_COMPRESS)
        td.attrs['unit']       = 's'
        td.attrs['shape_desc'] = f'(N_timesteps={T})'
        # ---- Active DOF discovery ------------------------------------------------
        active_dofs   = discover_field_expressions(java, sol_tag)
        field_configs = FIELD_CONFIGS
        if fields_to_extract is not None:
            field_configs = [fc for fc in FIELD_CONFIGS if fc['name'] in fields_to_extract]
        if active_dofs:
            _step(f'Active DOF fields: {list(active_dofs.keys())}', 6)
            active_fc  = []
            skipped_fc = []
            for fc in field_configs:
                (active_fc if _field_available_in_solution(fc, active_dofs)
                 else skipped_fc).append(fc)
            field_configs = active_fc
            if field_configs:
                _step(f'Fields to extract: {[f["name"] for f in field_configs]}', 6)
            if skipped_fc:
                _step(f'Skipping inactive: {[f["name"] for f in skipped_fc]}', 6)
        if not field_configs:
            _warn(f'No active field configs for "{label}" — skipped')
            sg.attrs['status'] = 'no_active_fields'
            continue
        # ---- Resolve base solution dataset tag ----------------------------------
        all_ds_tags = []
        try:
            all_ds_tags = [str(t) for t in
                           java_to_list_1d(java.result().dataset().tags())
                           if 'dset' in str(t).lower()]
        except BaseException:
            pass
        sol_ds = _find_sol_dataset(java, sol_tag)
        _step(f'Base dataset   : {sol_ds}  (candidates: {all_ds_tags})', 6)
        retry_ds_list = [sol_ds] + [d for d in all_ds_tags if d != sol_ds]

        chunk_starts = list(range(0, N, chunk_size))

        # =========================================================================
        # PROBE: evaluate chunk 0 to discover which field expressions work
        # =========================================================================
        t_probe   = time.time()
        probe_end = min(chunk_size, N)
        _step(f'Probing chunk 1/{n_chunks} ({probe_end:,} nodes) ...', 6)
        # Sort candidates so DOF-matching expressions are tried first in the probe
        probe_configs = _prioritize_candidates(field_configs, active_dofs)
        probe_results = _evaluate_chunk_all_fields(
            java, coords[0:probe_end], probe_configs, times, sol_ds,
            chunk_label=f'probe 1/{n_chunks}', space_dim=space_dim)

        # Retry probe with alternate datasets if nothing worked
        if all(v[0] is None for v in probe_results.values()) and len(retry_ds_list) > 1:
            for alt_ds in retry_ds_list[1:]:
                _step(f'Probe: no fields from "{sol_ds}" — retrying with "{alt_ds}"', 6)
                probe_results = _evaluate_chunk_all_fields(
                    java, coords[0:probe_end], probe_configs, times, alt_ds,
                    chunk_label=f'probe-retry/{alt_ds}', space_dim=space_dim)
                if any(v[0] is not None for v in probe_results.values()):
                    sol_ds = alt_ds
                    _step(f'Probe: fields found using dataset "{sol_ds}"', 6)
                    break

        _ok(f'Probe chunk done', elapsed=time.time() - t_probe)

        # Collect working fields: pinned matched expression from probe
        # working: {fname -> (matched_expr, comps, unit, n_comp, probe_data)}
        working = {}
        for fname, (data, err, matched_expr, comps, unit, n_comp) in probe_results.items():
            if data is not None:
                working[fname] = (matched_expr, comps, unit, n_comp, data)
            else:
                _step(f'  {fname:20s}: not available in probe ({err})', 6)
        del probe_results   # free RAM immediately

        if not working:
            _warn(f'No fields could be extracted for "{label}" — skipped')
            sg.attrs['status'] = 'no_fields_extracted'
            continue

        # =========================================================================
        # PRE-ALLOCATE empty HDF5 datasets on disk for every working field
        # =========================================================================
        hdf5_ds = {}
        for fname, (matched_expr, comps, unit, n_comp, _) in working.items():
            # Keep HDF5 chunk geometry independent of extraction chunk size:
            # use full-node slabs along axis 0.
            h5_chunk = (N, n_comp, min(T, 50))

            # Use float16 for Temperature, float32 for others
            if fname == 'Temperature':
                dtype = 'float16'
                dtype_note = 'float16'
            else:
                dtype = 'float32'
                dtype_note = 'float32'

            ds = sg.create_dataset(
                fname,
                shape=(N, n_comp, T),
                dtype=dtype,
                chunks=h5_chunk,
                **_HDF5_COMPRESS
            )
            ds.attrs['components'] = comps
            ds.attrs['unit']       = unit
            ds.attrs['node_order'] = 'mesh'
            ds.attrs['dtype_note'] = dtype_note
            ds.attrs['shape_desc'] = (
                f'(N_nodes={N}, N_components={n_comp}, N_timesteps={T})')
            hdf5_ds[fname] = ds
            expr_str = ', '.join(matched_expr) if matched_expr else '?'
            _step(f'  Pre-alloc {fname:<16} ({N:,}, {n_comp}, {T})'
                  f'  exprs=[{expr_str}]  unit={unit} dtype={dtype}', 6)

        # =========================================================================
        # Write probe chunk (chunk 0) — data already in memory
        # =========================================================================
        for fname, (matched_expr, comps, unit, n_comp, probe_data) in working.items():
            t_write = time.time()
            sys.stdout.write(' ' * 8 + f'Writing probe {fname} to HDF5 ...')
            sys.stdout.flush()
            if fname == 'Temperature':
                hdf5_ds[fname][0:probe_end, :, :] = probe_data.astype(np.float16)
            else:
                hdf5_ds[fname][0:probe_end, :, :] = probe_data.astype(np.float32)
            sys.stdout.write(f'  OK  ({_fmt_time(time.time() - t_write)})\n')
            sys.stdout.flush()
            del probe_data   # free immediately
        # Strip probe_data from working dict; keep only metadata
        working = {fname: (me, c, u, n)
                   for fname, (me, c, u, n, _pd) in working.items()}

        # =========================================================================
        # STREAM remaining chunks directly to disk
        # =========================================================================
        failed_fields = set()
        for ci, start_idx in enumerate(chunk_starts[1:], 2):
            end_idx = min(start_idx + chunk_size, N)
            N_chunk = end_idx - start_idx
            t_chunk = time.time()
            _step(f'Chunk {ci}/{n_chunks}: nodes [{start_idx:,}–{end_idx:,})'
                  f' ({N_chunk:,} nodes) ...', 6)

            # Pin the matched expression from the probe — no candidate hunting
            active_configs = [
                dict(fc, candidates=[working[fc['name']][0]])
                for fc in field_configs
                if fc['name'] in working and fc['name'] not in failed_fields
            ]
            chunk_results = _evaluate_chunk_all_fields(
                java, coords[start_idx:end_idx],
                active_configs, times, sol_ds,
                chunk_label=f'{ci}/{n_chunks}', space_dim=space_dim)

            for fname, (data, err, _, comps, unit, n_comp) in chunk_results.items():
                if fname in failed_fields:
                    continue
                if data is None:
                    _warn(f'Chunk {ci}: {fname} failed ({err})'
                          f' — field will be incomplete')
                    failed_fields.add(fname)
                    continue
                t_write = time.time()
                sys.stdout.write(' ' * 8 + f'Writing {fname} to HDF5 ...')
                sys.stdout.flush()
                if fname == 'Temperature':
                    hdf5_ds[fname][start_idx:end_idx, :, :] = data.astype(np.float16)
                else:
                    hdf5_ds[fname][start_idx:end_idx, :, :] = data.astype(np.float32)
                sys.stdout.write(f'  OK  ({_fmt_time(time.time() - t_write)})\n')
                sys.stdout.flush()
            del chunk_results   # aggressive RAM cleanup
            _ok(f'Chunk {ci}/{n_chunks} written', elapsed=time.time() - t_chunk)

        # =========================================================================
        # Summary for this study
        # =========================================================================
        n_written = len(working) - len(failed_fields)
        if failed_fields:
            _warn(f'Fields with incomplete data (chunk failures): '
                  f'{sorted(failed_fields)}')
        _ok(f'{n_written}/{len(field_configs)} fields written for "{label}"')

# =============================================================================
# HDF5 writer
# =============================================================================

def write_hdf5(output_path, model, java, study_info_list,
               coords, dom_bucket, non_phys, name_map,
               domain_3d, domain_2d, domain_1d, domain_0d,
               comp_tag='comp1', chunk_size=200_000, workers=1, model_path=None, fields_to_extract=None,
               space_dim=3):
    """
    Write the complete .cmslh5 file in mesh order throughout.
    Field alignment is guaranteed by CutPoint evaluation at mesh node coords.

    The HDF5 file is first written to a local /tmp staging path (which
    supports flock-based file locking) and then moved to the requested
    output_path.  This avoids BlockingIOError/EAGAIN on network or
    FUSE-mounted filesystems such as Box Drive.
    """
    n_nodes = len(coords)
    t_write = time.time()
    n_domain_elems = len(dom_bucket)   # capture before dom_bucket is freed

    _step('Building domain ID map ...')
    domain_id_map = build_domain_id_map(
        domain_3d, domain_2d, domain_1d, domain_0d, name_map)
    _step('Domain ID map built.')

    # Stage to a local temp file so HDF5 file-locking works even when
    # output_path is on a network / FUSE filesystem (Box, NFS, sshfs ...).
    tmp_fd, tmp_path = tempfile.mkstemp(suffix='.cmslh5.tmp', dir='/tmp')
    os.close(tmp_fd)   # h5py opens by name; close the raw fd immediately
    _step(f'Staging HDF5 to local temp: {tmp_path}')

    import multiprocessing as mp
    try:
        with h5py.File(tmp_path, 'w', libver='latest') as hf:
            hf.attrs['file_format'] = 'cmslh5-1.0'
            hf.attrs['created_by']  = 'comsol_to_hdf5.py'
            hf.attrs['node_order']  = 'mesh'

            model_grp = hf.create_group('Model')

            # /Model/Nodes
            t0 = time.time()
            ng = model_grp.create_group('Nodes')
            id_ds = ng.create_dataset('Id',
                              data=np.arange(1, n_nodes + 1, dtype=np.int32),
                              **_HDF5_COMPRESS)
            id_ds.attrs['note'] = '1-based node label; use position index (0-based) for Connectivity lookups.'
            ds = ng.create_dataset('Coordinates',
                                   data=coords.astype(np.float32),
                                   **_HDF5_COMPRESS)
            ds.attrs['columns']    = ['x', 'y', 'z']
            ds.attrs['node_order'] = 'mesh'
            ds.attrs['dtype_note'] = 'float32; sufficient for FEM post-processing'
            _step(f'/Model/Nodes -> {n_nodes:,} nodes  (mesh order)  [{_fmt_time(time.time()-t0)}]')

            # /Model/Elements
            _step('Writing /Model/Elements ...')
            t0 = time.time()
            eg = model_grp.create_group('Elements')
            n_domain_elems = len(dom_bucket)
            write_elem_group(eg, dom_bucket, domain_id_map=domain_id_map)
            _step(f'/Model/Elements -> {n_domain_elems:,} domain elements  [{_fmt_time(time.time()-t0)}]')
            dom_bucket = None   # release ~3-4 GB of Python lists before Analysis

            # /Model/Physical_Groups
            _step('Writing /Model/Physical_Groups ...')
            t0         = time.time()
            pg         = model_grp.create_group('Physical_Groups')
            used_names = set()
            total_np   = 0
            n_groups   = 0
            for dim in (3, 2, 1, 0):
                for entity in sorted(non_phys[dim].keys()):
                    bkt      = non_phys[dim][entity]
                    grp_name = make_group_name(dim, entity, name_map, used_names)
                    raw_lbl  = name_map.get((dim, entity), f'Entity_{entity}')
                    grp      = pg.create_group(grp_name)
                    grp.attrs['dim']          = dim
                    grp.attrs['entity_id']    = entity
                    grp.attrs['comsol_label'] = raw_lbl
                    write_elem_group(grp, bkt)
                    total_np += len(bkt)
                    n_groups += 1
            _step(f'/Model/Physical_Groups -> '
                  f'{n_groups} groups, {total_np:,} non-domain elements  [{_fmt_time(time.time()-t0)}]')
            non_phys = None   # release boundary-element data before Analysis

            # /Analysis
            _step('Writing /Analysis ...')
            analysis_grp = hf.create_group('Analysis')
            # Multiprocessing logic for field extraction
            if workers > 1:
                _step(f'Using {workers} parallel workers for field extraction.')
                # Partition node indices
                node_ranges = []
                per_worker = n_nodes // workers
                for i in range(workers):
                    start = i * per_worker
                    end = (i + 1) * per_worker if i < workers - 1 else n_nodes
                    node_ranges.append((start, end))

                # Prepare args for each worker
                import uuid
                temp_h5_paths = [f"/tmp/comsol_worker_{uuid.uuid4().hex}.h5" for _ in range(workers)]
                worker_args = []
                for i, (start, end) in enumerate(node_ranges):
                    worker_args.append(dict(
                        model_path=model_path,
                        study_info_list=study_info_list,
                        coords=coords[start:end],
                        chunk_size=chunk_size,
                        temp_h5_path=temp_h5_paths[i],
                        worker_idx=i,
                        total_workers=workers
                    ))

                # Launch workers
                with mp.get_context('spawn').Pool(workers) as pool:
                    pool.map(worker_func, worker_args)

                # Pre-allocate full datasets in the master process
                # Use the first worker's file to discover structure
                with h5py.File(temp_h5_paths[0], 'r') as probe_src:
                    for study in probe_src['Analysis']:
                        if study not in analysis_grp:
                            analysis_grp.create_group(study)
                        for dset in probe_src['Analysis'][study]:
                            # Use actual shape from worker file unless node-major (first dim matches chunk size)
                            dtype = probe_src['Analysis'][study][dset].dtype
                            # Gather all shapes from workers
                            shapes = []
                            for temp_path, (start, end) in zip(temp_h5_paths, node_ranges):
                                with h5py.File(temp_path, 'r') as src:
                                    data = src['Analysis'][study][dset]
                                    shapes.append(data.shape)
                            # If all shapes have same first dim and sum to n_nodes, treat as node-major
                            first_dims = [s[0] for s in shapes if len(s) > 0]
                            is_node_major = (
                                len(first_dims) == len(shapes)
                                and sum(first_dims) == n_nodes
                                and all(len(s) == len(shapes[0]) for s in shapes)
                            )
                            if is_node_major:
                                # Use (n_nodes, ...) for node-major
                                max_shape = list(shapes[0])
                                max_shape[0] = n_nodes
                                for s in shapes:
                                    for axis in range(1, len(s)):
                                        if s[axis] > max_shape[axis]:
                                            max_shape[axis] = s[axis]
                            else:
                                # Use shape from first worker (should be same for all non-node-major)
                                max_shape = list(shapes[0])
                            if dset not in analysis_grp[study]:
                                ds = analysis_grp[study].create_dataset(
                                    dset, shape=tuple(max_shape), dtype=dtype, **_HDF5_COMPRESS)
                                # Copy attrs from probe_src
                                for k, v in probe_src['Analysis'][study][dset].attrs.items():
                                    ds.attrs[k] = v

                # Insert each worker's chunk into the correct slice
                for widx, (temp_path, (start, end)) in enumerate(zip(temp_h5_paths, node_ranges)):
                    with h5py.File(temp_path, 'r') as src:
                        for study in src['Analysis']:
                            for dset in src['Analysis'][study]:
                                data = src['Analysis'][study][dset][...]
                                target = analysis_grp[study][dset]
                                # Only merge node-major datasets (first dim matches chunk size)
                                if data.ndim == 1:
                                    # Only write 1D datasets (like Times) from the first worker
                                    if widx == 0:
                                        target[...] = data
                                elif data.shape[0] == (end - start):
                                    # Node-major: merge along axis 0
                                    if data.ndim == 2:
                                        target[start:end, :] = data
                                    elif data.ndim == 3:
                                        target[start:end, :, :] = data
                                    else:
                                        target[start:end] = data
                                else:
                                    # If not node-major and not 1D, only write from first worker
                                    if widx == 0:
                                        target[...] = data
                    os.remove(temp_path)
                _ok('All worker outputs merged.')
            else:
                write_analysis_group(model, java, study_info_list,
                                    analysis_grp, coords,
                                    chunk_size=chunk_size, fields_to_extract=fields_to_extract,
                                    space_dim=space_dim)

        # Move the finished temp file to the final destination.
        _step(f'Moving staged file -> {output_path} ...')
        t0 = time.time()
        shutil.move(tmp_path, output_path)
        _ok(f'Moved to {output_path}', elapsed=time.time() - t0)

    except BaseException:
        # Clean up the temp file on any error so /tmp doesn't accumulate.
        try:
            Path(tmp_path).unlink(missing_ok=True)
        except Exception:
            pass
        raise

    _ok('HDF5 file written', elapsed=time.time() - t_write)

    # Try to print HDF5 structure, but don't fail if there's an I/O error
    try:
        _print_hdf5_tree(output_path)
    except Exception as e:
        _step(f'  (skipped HDF5 structure display due to I/O error: {e})', 6)

    return dict(
        n_nodes=n_nodes,
        n_domain_elements=n_domain_elems,
        n_physical_groups=n_groups,
        n_non_domain_elements=total_np,
        n_studies=len(study_info_list),
    )

# =============================================================================
# HDF5 tree printer
# =============================================================================

_SKIP_ATTRS = {'note', 'dtype_note'}
_MAX_ATTR_LEN = 60

def _fmt_attrs(raw: dict) -> str:
    """Return a condensed one-line attribute string, dropping noisy keys."""
    kept = {}
    for k, v in raw.items():
        if k in _SKIP_ATTRS:
            continue
        s = str(v)
        kept[k] = s if len(s) <= _MAX_ATTR_LEN else s[:_MAX_ATTR_LEN - 1] + '...'
    return f'  {kept}' if kept else ''

def _print_hdf5_tree(path):
    top_groups = []
    with h5py.File(path, 'r') as hf:
        for key in hf.keys():
            obj = hf[key]
            if isinstance(obj, h5py.Group):
                children = ', '.join(obj.keys())
                top_groups.append(f'{key}  ({children})')
            else:
                top_groups.append(key)

    print()
    _step('HDF5 top-level structure:')
    for line in top_groups:
        _step(line, 6)

# =============================================================================
# CLI
# =============================================================================

def build_parser():
    p = argparse.ArgumentParser(
        prog='cmslh5-convert',
        description=(
            'Extract COMSOL .mph results to a structured .cmslh5 file.\n\n'
            'Default mode: mesh, run studies, save solved .mph, then extract.\n'
            'With --extract-results: skip meshing/solving and extract directly\n'
            'from an already-solved model.'),
        formatter_class=argparse.RawDescriptionHelpFormatter)

    p.add_argument('model', metavar='MODEL_FILE',
                   help='Path to COMSOL .mph file.')
    p.add_argument('-o', '--output', metavar='OUTPUT_FILE', default=None,
                   help='Output .cmslh5 path (default: Results_<stem>.cmslh5).')
    p.add_argument('--solved-save', metavar='SOLVED_MPH', default=None,
                   help='Where to save solved .mph when meshing+solving '
                        '(default: Results_<stem>.mph).')

    sg = p.add_argument_group('Solver options (used only when model is not yet solved)')
    sg.add_argument('--cores',   metavar='N',   type=int, default=None,
                    help='CPU cores for COMSOL solver.')
    sg.add_argument('--studies', metavar='TAG', nargs='+', default=None,
                    help='Restrict solving to specific study tags.')

    srv = p.add_argument_group('COMSOL server')
    srv.add_argument('--start-server',    dest='start_server',
                     action='store_true',  default=True)
    srv.add_argument('--no-start-server', dest='start_server',
                     action='store_false')
    srv.add_argument('--host', metavar='HOST', default='localhost')
    srv.add_argument('--port', metavar='PORT', type=int, default=2036)

    mg = p.add_argument_group('Model options')
    mg.add_argument('--comp',     metavar='COMP_TAG', default='comp1')
    mg.add_argument('--mesh-tag', metavar='MESH_TAG', default=None)
    mg.add_argument('--extract-results', dest='extract_results',
                    action='store_true', default=False,
                    help='Extract directly from an already-solved model; do '
                        'not mesh, solve, or save a solved .mph.')
    mg.add_argument('--chunk-size', dest='chunk_size', metavar='N',
                    type=int, default=200_000,
                    help='Nodes per CutPoint3D chunk during field extraction '
                         '(default: 200000). Raise to 250000 with 64 GB JVM '
                         'RAM; lower if you hit OutOfMemoryError.')
    mg.add_argument('--workers', dest='workers', metavar='N', type=int, default=1,
                   help='Number of parallel worker processes for field extraction (default: 1, i.e., sequential).')
    mg.add_argument('--fields', metavar='FIELD', nargs='+', default=None,
                   help='Names of fields to extract (e.g., --fields Temperature Pressure). Default: all.')
    return p

# =============================================================================
# Path helpers
# =============================================================================

_STRIP_PREFIXES = ('Model_Definition_', 'Model_', 'model_definition_', 'model_')


def build_default_paths(model_path, output=None):
    """
    Derive default output paths from a model file path.

    Strips common definition prefixes from the model stem so that e.g.
    ``Model_Definition_FluidFlow.mph`` yields ``Results_FluidFlow`` rather
    than ``Results_Model_Definition_FluidFlow``.

    Parameters
    ----------
    model_path : str or Path
        Path to the COMSOL .mph model file.
    output : str or None
        Explicit output .cmslh5 path.  When None the path is derived
        automatically.

    Returns
    -------
    output_hdf5 : str
        Path for the output .cmslh5 file.
    solved_save : str
        Path for the solved .mph file (empty string when ``output`` is given
        and no separate solved-save path was requested).
    """
    model_stem = Path(model_path).stem
    clean_stem = model_stem
    for pfx in _STRIP_PREFIXES:
        if clean_stem.startswith(pfx):
            clean_stem = clean_stem[len(pfx):]
            break
    if output is not None:
        output_hdf5 = output
        solved_save = ''
    else:
        output_hdf5 = f'Results_{clean_stem}.cmslh5'
        solved_save = f'Results_{clean_stem}.mph'
    if not output_hdf5.endswith('.cmslh5'):
        output_hdf5 = str(Path(output_hdf5).with_suffix('.cmslh5'))
    return output_hdf5, solved_save

# =============================================================================
# Core pipeline
# =============================================================================

def comsol_to_hdf5(model_path, output_hdf5, solved_save_path='',
                   comp_tag='comp1', mesh_tag_hint=None,
                   start_server=True, host='localhost', port=2036,
                   cores=None, study_tags_filter=None,
                   force_extract=False, chunk_size=200_000, workers=1,
                   fields_to_extract=None):
    model_file = Path(model_path)
    if not model_file.exists():
        _err(f'File not found: {model_path}')
        return False

    t_total = time.time()

    _section('COMSOL SERVER')
    if start_server:
        _step(f'Starting COMSOL server '
              f'(cores: {cores if cores else "auto"}) ...')
        _estimate('5-30 seconds', 'JVM startup')
        ts     = time.time()
        client = mph.start(cores=cores) if cores else mph.start()
        _ok('COMSOL server running', elapsed=time.time() - ts)
    else:
        _step(f'Connecting to {host}:{port} ...')
        ts     = time.time()
        client = mph.Client(host=host, port=port)
        _ok(f'Connected to {host}:{port}', elapsed=time.time() - ts)

    stats = {}
    try:
        _section('LOADING MODEL')
        _step(f'Loading file: {model_file.name}')
        t0    = time.time()
        model = client.load(str(model_file))
        _ok('Model loaded', elapsed=time.time() - t0)

        java = model.java

        if force_extract:
            _step('--extract-results set: extracting directly without meshing or solving.')
        else:
            _step('Default mode: meshing, solving, saving solved model, then extracting.')
            mesh_solve_save(
                model, solved_save_path, comp_tag,
                cores=cores, study_tags_filter=study_tags_filter)

        _section('RESOLVING ENTITY NAMES')
        t0       = time.time()
        name_map = build_entity_name_map(java, comp_tag)
        _ok(f'Resolved {len(name_map)} (dim, entity) pairs',
            elapsed=time.time() - t0)

        _section('MAPPING STUDIES TO RESULT DATASETS')
        t0         = time.time()
        study_info = build_study_info(java)
        _ok(f'{len(study_info)} study/studies found',
            elapsed=time.time() - t0)

        _section('CLASSIFYING PHYSICS')
        t0 = time.time()
        domain_3d, domain_2d, domain_1d, domain_0d = \
            classify_physics(java, comp_tag)
        _ok('Physics domain entities resolved', elapsed=time.time() - t0)
        _step(f'3-D domain entities: {sorted(domain_3d)}')
        _step(f'2-D domain entities: {sorted(domain_2d)}')
        _step(f'1-D domain entities: {sorted(domain_1d)}')
        _step(f'0-D domain entities: {sorted(domain_0d)}')

        _section('READING MESH NODES')
        _estimate('seconds', 'scales with node count')
        t0         = time.time()
        coords, md = get_mesh_data(java, comp_tag, mesh_tag_hint)
        space_dim = 2 if np.all(coords[:, 2] == 0.0) else 3
        _ok(f'{len(coords):,} nodes read ({space_dim}D)', elapsed=time.time() - t0)

        _section('EXTRACTING ELEMENTS')
        _estimate('seconds to minutes', 'scales with element count')
        t0                   = time.time()
        dom_bucket, non_phys = extract_all_elements(
            md, domain_3d, domain_2d, domain_1d, domain_0d)
        _ok('Element extraction complete', elapsed=time.time() - t0)

        _section('WRITING HDF5 OUTPUT')
        _step(f'Output file: {output_hdf5}')
        _estimate('seconds to minutes',
                  'scales with nodes, fields, time steps')
        stats = write_hdf5(
            output_hdf5, model, java, study_info,
            coords, dom_bucket, non_phys, name_map,
            domain_3d, domain_2d, domain_1d, domain_0d,
            comp_tag=comp_tag, chunk_size=chunk_size, workers=workers,
            model_path=model_path, fields_to_extract=fields_to_extract,
            space_dim=space_dim)

        sz = Path(output_hdf5).stat().st_size / 1_048_576
        _summary_table([
            ('Model file',          model_path),
            ('Output file',         output_hdf5),
            ('Output size',         f'{sz:.2f} MB'),
            ('Component',           comp_tag),
            ('Nodes',               f'{stats.get("n_nodes", 0):,}'),
            ('Domain elements',     f'{stats.get("n_domain_elements", 0):,}'),
            ('Physical groups',     f'{stats.get("n_physical_groups", 0):,}'),
            ('Non-domain elements', f'{stats.get("n_non_domain_elements", 0):,}'),
            ('Studies',             f'{stats.get("n_studies", 0)}'),
            ('Fields configured',   str(len(FIELD_CONFIGS))),
            ('Total elapsed',       _fmt_time(time.time() - t_total)),
        ])
        _final_banner(output_hdf5, time.time() - t_total)
        return True

    except Exception as exc:
        _err(f'{exc}')
        traceback.print_exc()
        return False

    finally:
        _section('SHUTDOWN')
        _step('Closing COMSOL server ...')
        try:
            client.clear()
        except Exception:
            pass  # Suppress disconnect/cleanup errors
        _ok('Server closed')

# =============================================================================
# Entry point
# =============================================================================

def main():
    parser = build_parser()
    args   = parser.parse_args()

    if args.extract_results:
        # Use the input file stem directly; no .mph resave needed.
        model_stem  = Path(args.model).stem
        output_hdf5 = args.output or f'{model_stem}.cmslh5'
        solved_save = args.solved_save or ''
    else:
        output_hdf5, solved_save = build_default_paths(args.model, args.output)
        if args.solved_save:
            solved_save = args.solved_save

    if not output_hdf5.endswith('.cmslh5'):
        output_hdf5 = str(Path(output_hdf5).with_suffix('.cmslh5'))

    _banner()
    mode = 'extract-only' if args.extract_results else 'mesh-solve-extract'
    rows = [
        ('Model file',  args.model),
        ('Mode',        mode),
        ('Output file', output_hdf5),
        ('Component',   args.comp),
    ]
    if solved_save:
        rows.append(('Solved save', solved_save))
    if args.mesh_tag:
        rows.append(('Mesh tag', args.mesh_tag))
    if args.cores:
        rows.append(('Cores', str(args.cores)))
    if args.studies:
        rows.append(('Studies', ' '.join(args.studies)))

    # Show parallel/sequential configuration
    if args.workers and args.workers > 1:
        rows.append(('Execution', f'parallel ({args.workers} workers)'))
    else:
        rows.append(('Execution', 'sequential'))

    rows.append(('Chunk size', f'{args.chunk_size:,}'))
    rows.append(('Server', 'managed (auto-start)' if args.start_server
                 else f'{args.host}:{args.port} (external)'))

    print(_bold('  Configuration'))
    print(_dim('  ' + '-' * (_W - 2)))
    w = max(len(r[0]) for r in rows)
    for lbl, val in rows:
        print(f'  {lbl:<{w}}  :  {val}')
    print()

    success = comsol_to_hdf5(
        model_path        = args.model,
        output_hdf5       = output_hdf5,
        solved_save_path  = solved_save,
        comp_tag          = args.comp,
        mesh_tag_hint     = args.mesh_tag,
        start_server      = args.start_server,
        host              = args.host,
        port              = args.port,
        cores             = args.cores,
        study_tags_filter = args.studies,
        force_extract     = args.extract_results,
        chunk_size        = args.chunk_size,
        workers           = args.workers,
        fields_to_extract = args.fields,
    )
    sys.exit(0 if success else 1)
