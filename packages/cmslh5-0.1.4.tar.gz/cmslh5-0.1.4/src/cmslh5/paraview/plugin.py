"""
ParaView Python plugin for .cmslh5 files.

Copy your existing cmslh5_pvplugin.py here.
No changes needed — ParaView loads it by file path.

Installation:
  pvpython -m pip install h5py
  ParaView > Tools > Manage Plugins > Load New > select this file
"""
