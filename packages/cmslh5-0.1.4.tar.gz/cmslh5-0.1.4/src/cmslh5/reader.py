"""
cmslh5.reader — High-level reader for .cmslh5 files.

No COMSOL dependency.  Requires only h5py, numpy, scipy.
"""

import numpy as np
import h5py
from pathlib import Path
from typing import Optional, Union, List, Tuple, Dict

from cmslh5._fields import resolve_component, available_components, COMPONENT_MAP
from cmslh5._interp import interpolate_spatial_idw, interpolate_temporal
from cmslh5._expr import generate_line_points


class CmslH5Reader:

    def __init__(self, path: str):
        self.path = Path(path)
        if not self.path.exists():
            raise FileNotFoundError(f'{self.path} not found')
        self._hf: Optional[h5py.File] = h5py.File(str(self.path), 'r')
        self._coords: Optional[np.ndarray] = None
        self._kdtree = None
        self._study_cache: Optional[List[dict]] = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        if self._hf is not None:
            self._hf.close()
            self._hf = None

    def _ensure_open(self):
        if self._hf is None:
            raise RuntimeError('File is closed.')

    def nodes(self) -> np.ndarray:
        self._ensure_open()
        if self._coords is None:
            self._coords = np.array(self._hf['Model/Nodes/Coordinates'], dtype=np.float64)
        return self._coords

    def n_nodes(self) -> int:
        return self._hf['Model/Nodes/Coordinates'].shape[0]

    def bbox(self) -> Tuple[np.ndarray, np.ndarray]:
        c = self.nodes()
        return c.min(axis=0), c.max(axis=0)

    def connectivity(self) -> np.ndarray:
        self._ensure_open()
        return np.array(self._hf['Model/Elements/Connectivity'])

    def element_types(self) -> np.ndarray:
        self._ensure_open()
        return np.array(self._hf['Model/Elements/Type'])

    def domain_legend(self) -> Dict[int, str]:
        self._ensure_open()
        leg = self._hf.get('Model/Elements/DomainLegend')
        if leg is None:
            return {}
        ids = np.array(leg['Id'])
        names = np.array(leg['Name'])
        return {int(i): (n.decode() if isinstance(n, bytes) else str(n))
                for i, n in zip(ids, names)}

    def physical_groups(self) -> List[str]:
        self._ensure_open()
        pg = self._hf.get('Model/Physical_Groups')
        return list(pg.keys()) if pg else []

    def _get_kdtree(self):
        if self._kdtree is None:
            from scipy.spatial import cKDTree
            self._kdtree = cKDTree(self.nodes())
        return self._kdtree

    def studies(self) -> List[dict]:
        self._ensure_open()
        if self._study_cache is not None:
            return self._study_cache
        ag = self._hf.get('Analysis')
        if ag is None:
            self._study_cache = []
            return []
        result = []
        for i, key in enumerate(sorted(ag.keys())):
            sg = ag[key]
            times = np.array(sg['Times']) if 'Times' in sg else np.array([0.0])
            fields = [k for k in sg.keys() if k != 'Times']
            _lbl = sg.attrs.get('comsol_study_label', key)
            label = _lbl.decode() if isinstance(_lbl, bytes) else str(_lbl)
            is_td = bool(sg.attrs.get('is_time_dependent', len(times) > 1))
            field_info = {}
            for fname in fields:
                ds = sg[fname]
                comps = list(ds.attrs.get('components', []))
                unit = str(ds.attrs.get('unit', ''))
                field_info[fname] = {'components': comps, 'unit': unit, 'shape': ds.shape}
            result.append(dict(
                index=i, hdf5_name=key, label=label,
                n_timesteps=len(times), is_time_dependent=is_td,
                fields=fields, field_info=field_info, times=times))
        self._study_cache = result
        return result

    def _resolve_study(self, study: Union[int, str, None] = None) -> dict:
        studies = self.studies()
        if not studies:
            raise ValueError('No studies in file.')
        if study is None:
            return studies[0]
        if isinstance(study, int):
            idx = study if study >= 0 else len(studies) + study
            if 0 <= idx < len(studies):
                return studies[idx]
            raise IndexError(f'Study index {study} out of range.')
        for s in studies:
            if study in s['hdf5_name'] or study in s['label']:
                return s
        raise ValueError(f'Study "{study}" not found.')

    def _read_component_raw(self, component, study=None):
        self._ensure_open()
        field_name, comp_name, comp_idx = resolve_component(component)
        sinfo = self._resolve_study(study)
        sg = self._hf[f'Analysis/{sinfo["hdf5_name"]}']
        times = np.array(sg['Times'], dtype=np.float64)
        if field_name not in sg:
            avail = [k for k in sg.keys() if k != 'Times']
            raise KeyError(f'Field "{field_name}" (for "{component}") not in study "{sinfo["label"]}". Available: {avail}')
        ds = sg[field_name]
        unit = str(ds.attrs.get('unit', ''))
        data = np.array(ds[:, comp_idx, :], dtype=np.float64)
        return data, times, unit, field_name, comp_name

    def get_nodal_field(self, component, time, study=None):
        data_2d, times, unit, _, _ = self._read_component_raw(component, study)
        vals, method = interpolate_temporal(times, data_2d, time)
        return vals, unit, method

    def get_times(self, study=None):
        return self._resolve_study(study)['times'].copy()

    def extract_along_line(self, component, time, x_expr, y_expr, z_expr,
                           n_points=200, study=None, k=8, idw_power=2.0):
        data_2d, times, unit, field_name, comp_name = self._read_component_raw(component, study)
        sinfo = self._resolve_study(study)
        node_values, time_method = interpolate_temporal(times, data_2d, time)
        line_coords, arc_length, s_values = generate_line_points(x_expr, y_expr, z_expr, n_points)
        values = interpolate_spatial_idw(self._get_kdtree(), node_values, line_coords, k=k, power=idw_power)
        return dict(arc_length=arc_length, coords=line_coords, values=values,
                    s_param=s_values, component=comp_name, field=field_name,
                    unit=unit, time=time, time_method=time_method,
                    study=sinfo['label'], expressions={'x': x_expr, 'y': y_expr, 'z': z_expr})

    def probe_point(self, component, time, point, study=None, k=8, idw_power=2.0):
        pt = np.asarray(point, dtype=np.float64).reshape(1, 3)
        data_2d, times, unit, field_name, comp_name = self._read_component_raw(component, study)
        node_values, time_method = interpolate_temporal(times, data_2d, time)
        tree = self._get_kdtree()
        dist, idx = tree.query(pt.squeeze())
        val = interpolate_spatial_idw(tree, node_values, pt, k=k, power=idw_power)
        return dict(value=float(val[0]), unit=unit, component=comp_name,
                    field=field_name, time=time, time_method=time_method,
                    nearest_node_idx=int(idx), nearest_distance=float(dist),
                    nearest_coords=self.nodes()[idx].copy())

    def extract_time_history(self, component, point, study=None, k=8, idw_power=2.0):
        pt = np.asarray(point, dtype=np.float64).reshape(1, 3)
        data_2d, times, unit, field_name, comp_name = self._read_component_raw(component, study)
        tree = self._get_kdtree()
        dist, idx = tree.query(pt.squeeze())
        values = np.empty(len(times))
        for ti in range(len(times)):
            values[ti] = interpolate_spatial_idw(tree, data_2d[:, ti], pt, k=k, power=idw_power)[0]
        return dict(times=times, values=values, unit=unit, component=comp_name,
                    field=field_name, nearest_node_idx=int(idx), nearest_distance=float(dist))

    def extract_components_along_line(self, components, time, x_expr, y_expr, z_expr,
                                      n_points=200, study=None, k=8, idw_power=2.0):
        line_coords, arc_length, s_values = generate_line_points(x_expr, y_expr, z_expr, n_points)
        tree = self._get_kdtree()
        sinfo = self._resolve_study(study)
        comp_data = {}
        time_methods = {}
        for comp in components:
            data_2d, times, unit, field_name, comp_name = self._read_component_raw(comp, study)
            node_values, t_method = interpolate_temporal(times, data_2d, time)
            values = interpolate_spatial_idw(tree, node_values, line_coords, k=k, power=idw_power)
            comp_data[comp_name] = {'values': values, 'unit': unit, 'field': field_name}
            time_methods[comp_name] = t_method
        return dict(arc_length=arc_length, coords=line_coords, s_param=s_values,
                    time=time, time_methods=time_methods, study=sinfo['label'],
                    expressions={'x': x_expr, 'y': y_expr, 'z': z_expr}, data=comp_data)

    def summary(self):
        self._ensure_open()
        c = self.nodes()
        bmin, bmax = c.min(axis=0), c.max(axis=0)
        lines = [f'File    : {self.path.name}', f'Size    : {self.path.stat().st_size / 1_048_576:.1f} MB',
                 '', 'Mesh:', f'  Nodes       : {len(c):,}',
                 f'  BBox min    : [{bmin[0]:.6g}, {bmin[1]:.6g}, {bmin[2]:.6g}]',
                 f'  BBox max    : [{bmax[0]:.6g}, {bmax[1]:.6g}, {bmax[2]:.6g}]']
        if 'Model/Elements/Type' in self._hf:
            et = np.array(self._hf['Model/Elements/Type'])
            utypes = sorted(set(t.decode() if isinstance(t, bytes) else str(t) for t in et))
            lines.append(f'  Elements    : {len(et):,}  ({", ".join(utypes)})')
        dl = self.domain_legend()
        if dl:
            lines.append(f'  Domains     : {len(dl)}')
            for did, dn in sorted(dl.items()):
                lines.append(f'    {did:3d} : {dn}')
        pg = self.physical_groups()
        if pg:
            lines.append(f'  Phys groups : {len(pg)}')
        studies = self.studies()
        lines += ['', f'Studies: {len(studies)}']
        for s in studies:
            kind = 'time-dep' if s['is_time_dependent'] else 'stationary'
            lines.append(f'  [{s["index"]}] "{s["label"]}"  ({kind}, T={s["n_timesteps"]})')
            if s['is_time_dependent']:
                lines.append(f'       t : [{s["times"][0]:.6g} .. {s["times"][-1]:.6g}] s')
            for fname, fi in s['field_info'].items():
                cstr = ', '.join(fi['components'])
                lines.append(f'       {fname:16s}  [{cstr}]  unit={fi["unit"]}  shape={fi["shape"]}')
        lines += ['', 'Available components:']
        for field, comps in available_components().items():
            lines.append(f'  {field:16s}: {", ".join(comps)}')
        return '\n'.join(lines)
