"""
cmslh5.stats — Statistical analysis and reduction of time-dependent fields.
"""

import numpy as np
from typing import Union, Optional, Tuple
from cmslh5.reader import CmslH5Reader
from cmslh5._interp import interpolate_spatial_idw


def time_average(reader, component, t_start=None, t_end=None, study=None):
    data_2d, times, unit, _, _ = reader._read_component_raw(component, study)
    mask = np.ones(len(times), dtype=bool)
    if t_start is not None: mask &= times >= t_start
    if t_end is not None: mask &= times <= t_end
    if not mask.any(): raise ValueError(f'No timesteps in [{t_start}, {t_end}]')
    return data_2d[:, mask].mean(axis=1).astype(np.float64), unit


def time_rms(reader, component, t_start=None, t_end=None, study=None):
    data_2d, times, unit, _, _ = reader._read_component_raw(component, study)
    mask = np.ones(len(times), dtype=bool)
    if t_start is not None: mask &= times >= t_start
    if t_end is not None: mask &= times <= t_end
    subset = data_2d[:, mask].astype(np.float64)
    return np.sqrt(np.mean(subset ** 2, axis=1)), unit


def time_min_max(reader, component, study=None):
    data_2d, times, unit, _, comp_name = reader._read_component_raw(component, study)
    flat = data_2d.astype(np.float64)
    idx_min = np.unravel_index(np.argmin(flat), flat.shape)
    idx_max = np.unravel_index(np.argmax(flat), flat.shape)
    return dict(min_value=float(flat[idx_min]), min_node=int(idx_min[0]),
                min_time=float(times[idx_min[1]]), max_value=float(flat[idx_max]),
                max_node=int(idx_max[0]), max_time=float(times[idx_max[1]]),
                unit=unit, component=comp_name)


def fft_at_point(reader, component, point, study=None, k=8, idw_power=2.0):
    th = reader.extract_time_history(component, point, study=study, k=k, idw_power=idw_power)
    times, values = th['times'], th['values']
    if len(times) < 3: raise ValueError('Need at least 3 timesteps for FFT.')
    dt = np.mean(np.diff(times))
    n = len(values)
    fft_vals = np.fft.rfft(values - values.mean())
    freqs = np.fft.rfftfreq(n, d=dt)
    amplitudes = 2.0 * np.abs(fft_vals) / n
    idx_dom = np.argmax(amplitudes[1:]) + 1 if len(amplitudes) > 1 else 0
    return dict(frequencies=freqs, amplitudes=amplitudes,
                dominant_freq=float(freqs[idx_dom]), dominant_amplitude=float(amplitudes[idx_dom]),
                dt=float(dt), unit=th['unit'], component=th['component'])


def field_statistics(reader, component, time, study=None):
    vals, unit, method = reader.get_nodal_field(component, time, study)
    finite = vals[np.isfinite(vals)]
    return dict(min=float(np.min(finite)), max=float(np.max(finite)),
                mean=float(np.mean(finite)), std=float(np.std(finite)),
                median=float(np.median(finite)), p5=float(np.percentile(finite, 5)),
                p95=float(np.percentile(finite, 95)), n_nodes=len(vals),
                n_finite=len(finite), unit=unit, time=time, time_method=method)
