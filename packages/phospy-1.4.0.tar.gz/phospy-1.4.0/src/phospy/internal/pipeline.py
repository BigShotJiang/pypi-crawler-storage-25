from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING

import pandas as pd

from ..activities.analysis import KinaseActivityAnalyzer
from ..activities.results import KinaseActivityResult
from ..api.contracts import DatasetLoadOptions, KinaseActivityConfig
from ..api.orchestration import KinaseOrchestrationService
from ..datasets.loaders import DatasetLoader
from ..datasets.models import PhosphoDataset
from ..errors import RequestValidationError, TableSchemaError
from ..io import load_pred_mat
from ..io.publishing import OutputPublisher, RunManifestWriter
from ..io.writers import CoreOutputWriter, KinaseActivityWriter
from ..preprocessing.core import CorePreprocessingConfig, CoreProcessingResult
from ..validation.requests.pipeline import (
    CorePipelineRequest,
    PipelineInputs,
    build_pipeline_inputs,
    validate_pipeline_construction_request,
)

if TYPE_CHECKING:
    from ..prediction.results import PredMatResult


@dataclass(slots=True)
class PipelineOutputs:
    core: CoreProcessingResult
    kinase_activity: KinaseActivityResult | None = None


def _load_pred_mat_for_request(request: CorePipelineRequest) -> pd.DataFrame | None:
    if request.pred_mat_path is None:
        return None
    try:
        return load_pred_mat(request.pred_mat_path)
    except TableSchemaError:
        raise
    except (
        OSError,
        UnicodeError,
        pd.errors.ParserError,
        pd.errors.EmptyDataError,
    ) as error:
        msg = (
            f"Invalid core pipeline request: pred_mat_path: "
            f"unable to read pred_mat ({request.pred_mat_path}): {error}"
        )
        raise RequestValidationError(msg) from error


def build_pipeline_inputs_from_request(request: CorePipelineRequest) -> PipelineInputs:
    validated_inputs = DatasetLoader(schema=request.dataset_schema).load(
        request.total_path,
        request.phospho_path,
        phospho_encoding=request.phospho_encoding,
    )
    dataset = PhosphoDataset.from_loaded_inputs(
        validated_inputs,
        comparisons=request.comparisons,
    )
    return build_pipeline_inputs(
        dataset=dataset,
        pred_mat=_load_pred_mat_for_request(request),
        localization_threshold=request.localization_threshold,
        min_observed=request.min_observed,
        max_unmatched_fraction=request.max_unmatched_fraction,
        total_sentinel=request.total_sentinel,
        phospho_sentinel=request.phospho_sentinel,
        site_matrix_policy=request.site_matrix_policy,
        kinase_activity_threshold=request.kinase_activity_threshold,
        kinase_activity_min_substrates=request.kinase_activity_min_substrates,
        kinase_activity_top_n_substrates=request.kinase_activity_top_n_substrates,
    )


def _run_pipeline_request(
    *,
    request: PipelineInputs,
    kinase_activity_analyzer: KinaseActivityAnalyzer,
    orchestration: KinaseOrchestrationService | None = None,
) -> PipelineOutputs:
    orchestrator = (
        KinaseOrchestrationService() if orchestration is None else orchestration
    )
    core, kinase_activity = orchestrator.run_pipeline_runtime(
        request=request,
        kinase_activity_analyzer=kinase_activity_analyzer,
    )
    return PipelineOutputs(core=core, kinase_activity=kinase_activity)


def _publish_pipeline_outputs(
    *,
    outdir: str | Path,
    outputs: PipelineOutputs,
    preprocessing_config: CorePreprocessingConfig,
    manifest_writer: RunManifestWriter,
    output_publisher: OutputPublisher,
) -> None:
    target_dir = Path(outdir)
    parent_dir = target_dir.parent
    parent_dir.mkdir(parents=True, exist_ok=True)

    with TemporaryDirectory(
        dir=parent_dir,
        prefix=f".{target_dir.name}.tmp-",
    ) as staging_dir_str:
        staging_dir = Path(staging_dir_str)
        CoreOutputWriter().write(outputs.core, staging_dir)
        if outputs.kinase_activity is not None:
            KinaseActivityWriter().write(outputs.kinase_activity, staging_dir)
        manifest_writer.write(
            outdir=staging_dir,
            core=outputs.core,
            kinase_activity=outputs.kinase_activity,
            preprocessing_config=preprocessing_config,
        )
        output_publisher.publish(
            staging_dir=staging_dir,
            target_dir=target_dir,
        )


class PipelineRunner:
    """Internal file-first orchestration for CLI and package internals."""

    def __init__(
        self,
        dataset: PhosphoDataset,
        pred_mat: pd.DataFrame | PredMatResult | None = None,
        preprocessing_config: CorePreprocessingConfig | None = None,
        activity_config: KinaseActivityConfig | None = None,
        *,
        manifest_writer: RunManifestWriter | None = None,
        output_publisher: OutputPublisher | None = None,
    ) -> None:
        resolved_activity_config = KinaseActivityConfig.from_value(activity_config)
        request = validate_pipeline_construction_request(
            dataset=dataset,
            pred_mat=pred_mat,
            preprocessing_config=preprocessing_config,
            kinase_activity_threshold=resolved_activity_config.threshold,
            kinase_activity_min_substrates=resolved_activity_config.min_substrates,
            kinase_activity_top_n_substrates=resolved_activity_config.top_n_substrates,
        )
        self._initialize_from_inputs(
            request=request,
            manifest_writer=manifest_writer,
            output_publisher=output_publisher,
        )

    def _initialize_from_inputs(
        self,
        *,
        request: PipelineInputs,
        manifest_writer: RunManifestWriter | None = None,
        output_publisher: OutputPublisher | None = None,
    ) -> None:
        self.request = request
        self.dataset = request.dataset
        self.pred_mat = request.pred_mat
        self.preprocessing_config = request.preprocessing_config
        self.kinase_activity_analyzer = KinaseActivityAnalyzer()
        self._orchestration = KinaseOrchestrationService()
        self.manifest_writer = manifest_writer or RunManifestWriter()
        self.output_publisher = output_publisher or OutputPublisher()

    @classmethod
    def _from_inputs(
        cls,
        request: PipelineInputs,
        *,
        manifest_writer: RunManifestWriter | None = None,
        output_publisher: OutputPublisher | None = None,
    ) -> PipelineRunner:
        instance = cls.__new__(cls)
        instance._initialize_from_inputs(
            request=request,
            manifest_writer=manifest_writer,
            output_publisher=output_publisher,
        )
        return instance

    @classmethod
    def from_files(
        cls,
        total_path: str | Path,
        phospho_path: str | Path,
        pred_mat_path: str | Path | None = None,
        dataset_options: DatasetLoadOptions | None = None,
        preprocessing_config: CorePreprocessingConfig | None = None,
        activity_config: KinaseActivityConfig | None = None,
        *,
        manifest_writer: RunManifestWriter | None = None,
        output_publisher: OutputPublisher | None = None,
    ) -> PipelineRunner:
        resolved_dataset_options = DatasetLoadOptions.from_value(dataset_options)
        resolved_preprocessing_config = (
            CorePreprocessingConfig()
            if preprocessing_config is None
            else preprocessing_config
        )
        resolved_activity_config = KinaseActivityConfig.from_value(activity_config)
        request = CorePipelineRequest.validate_request(
            total_path=Path(total_path),
            phospho_path=Path(phospho_path),
            pred_mat_path=Path(pred_mat_path) if pred_mat_path is not None else None,
            phospho_encoding=resolved_dataset_options.phospho_encoding,
            schema=resolved_dataset_options.schema,
            comparisons=resolved_dataset_options.comparisons,
            localization_threshold=resolved_preprocessing_config.localization_threshold,
            min_observed=resolved_preprocessing_config.min_observed,
            total_sentinel=resolved_preprocessing_config.total_sentinel,
            phospho_sentinel=resolved_preprocessing_config.phospho_sentinel,
            max_unmatched_fraction=resolved_preprocessing_config.max_unmatched_fraction,
            site_matrix_policy=resolved_preprocessing_config.site_matrix_policy,
            kinase_activity_threshold=resolved_activity_config.threshold,
            kinase_activity_min_substrates=resolved_activity_config.min_substrates,
            kinase_activity_top_n_substrates=resolved_activity_config.top_n_substrates,
        )
        return cls._from_inputs(
            build_pipeline_inputs_from_request(request),
            manifest_writer=manifest_writer,
            output_publisher=output_publisher,
        )

    def run(self, outdir: str | Path | None = None) -> PipelineOutputs:
        outputs = _run_pipeline_request(
            request=self.request,
            kinase_activity_analyzer=self.kinase_activity_analyzer,
            orchestration=self._orchestration,
        )

        if outdir is not None:
            _publish_pipeline_outputs(
                outdir=outdir,
                outputs=outputs,
                preprocessing_config=self.preprocessing_config,
                manifest_writer=self.manifest_writer,
                output_publisher=self.output_publisher,
            )

        return outputs
