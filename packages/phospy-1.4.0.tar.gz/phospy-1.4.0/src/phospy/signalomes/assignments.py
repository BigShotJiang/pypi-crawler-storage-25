from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

import numpy as np
import pandas as pd

from ..errors import InputCompatibilityError
from ..internal.types import (
    SIGNALOME_ASSIGNMENT_POLICIES,
    SIGNALOME_ASSIGNMENT_POLICY_CUTOFF_BINARY,
    SIGNALOME_ASSIGNMENT_POLICY_WEIGHTED_TOP,
    SignalomeAssignmentPolicy,
)
from .constants import (
    KINASE_COLUMN,
    MODULE_ID_COLUMN,
    PROTEIN_ID_COLUMN,
    SHARE_PERCENT_COLUMN,
    SITE_ID_COLUMN,
    TOP_KINASE_CANDIDATES_COLUMN,
    TOP_KINASE_IS_AMBIGUOUS_COLUMN,
    TOP_KINASE_TIE_COUNT_COLUMN,
    TOP_KINASE_WEIGHTS_COLUMN,
    TOP_SCORE_COLUMN,
    WEIGHT_COLUMN,
)
from .results import ExpandedSignalome
from .serialization import normalize_top_kinase_weights
from .site_ids import (
    parse_supported_signalome_site_ids,
    protein_id_from_supported_signalome_site_id,
    resolve_signalome_site_to_protein,
)

__all__ = [
    "build_expanded_signalomes",
    "build_kinase_module_relationship_table",
    "build_protein_assignment_table",
    "build_signalome_module_table",
    "build_site_assignments",
    "derive_protein_modules",
    "parse_supported_site_ids",
    "protein_id_from_supported_site_id",
    "resolve_site_to_protein",
    "select_kinase_substrates",
]


@dataclass(frozen=True, slots=True)
class _TopKinaseAssignments:
    top_scores: pd.Series
    top_kinase_candidates: list[tuple[str, ...]]
    top_kinase_weights: list[tuple[tuple[str, float], ...]]
    top_kinase_tie_count: np.ndarray


def _as_unique_string_index(
    index: pd.Index,
    *,
    context: str,
    label: str,
) -> pd.Index:
    resolved_index = pd.Index(index.astype(str), name=label)
    if resolved_index.has_duplicates:
        duplicates = sorted(
            {str(site_id) for site_id in resolved_index[resolved_index.duplicated()]}
        )
        preview = ", ".join(duplicates[:3])
        suffix = "..." if len(duplicates) > 3 else ""
        msg = f"{context} contains duplicate {label} values: {preview}{suffix}"
        raise InputCompatibilityError(msg)
    return resolved_index


def _as_unique_string_series_index(
    series: pd.Series,
    *,
    context: str,
    label: str,
) -> pd.Series:
    resolved = series.copy()
    resolved.index = _as_unique_string_index(
        resolved.index,
        context=context,
        label=label,
    )
    return resolved


def resolve_site_to_protein(
    *,
    site_ids: Sequence[str],
    site_to_protein: Mapping[str, str] | pd.Series | None,
) -> pd.Series:
    """Resolve aligned phosphosite IDs to validated protein IDs."""

    return resolve_signalome_site_to_protein(
        site_ids=site_ids,
        site_to_protein=site_to_protein,
        missing_mapping_context=(
            "site_to_protein must define a protein ID for every signalome site. "
            "Missing mappings for"
        ),
        invalid_mapping_context=(
            "site_to_protein must map every signalome site to a non-empty protein "
            "ID. Invalid mappings for"
        ),
        invalid_site_id_context=(
            "Signalome construction requires either an explicit site_to_protein "
            "mapping or phosphosite identifiers in canonical 'ENTITY;SITE;' "
            "format. Invalid site IDs"
        ),
    )


def parse_supported_site_ids(site_ids: Sequence[str]) -> pd.Series:
    """Parse supported phosphosite identifiers into protein IDs."""

    return parse_supported_signalome_site_ids(
        site_ids,
        invalid_site_id_context=(
            "Signalome construction requires either an explicit site_to_protein "
            "mapping or phosphosite identifiers in canonical 'ENTITY;SITE;' "
            "format. Invalid site IDs"
        ),
    )


def protein_id_from_supported_site_id(site_id: object) -> str | None:
    """Extract a protein ID from a canonical ``ENTITY;SITE;`` site ID."""

    return protein_id_from_supported_signalome_site_id(site_id)


def derive_protein_modules(
    *,
    site_clusters: pd.Series,
    site_to_protein: pd.Series,
) -> pd.Series:
    """Collapse site clusters into protein-level module assignments."""

    aligned_site_to_protein = site_to_protein.loc[site_clusters.index.astype(str)]
    proteins = pd.Index(aligned_site_to_protein.tolist(), dtype=object)
    membership = pd.crosstab(site_clusters, proteins)
    membership = (membership > 0).astype(int)

    assignments: dict[str, int] = {}
    pattern_to_module: dict[tuple[int, ...], int] = {}
    next_module_id = 1

    for protein in membership.columns:
        pattern = tuple(int(value) for value in membership.loc[:, protein].tolist())
        if pattern not in pattern_to_module:
            pattern_to_module[pattern] = next_module_id
            next_module_id += 1
        assignments[str(protein)] = pattern_to_module[pattern]

    protein_modules = pd.Series(assignments, dtype=int, name=MODULE_ID_COLUMN)
    protein_modules.index.name = PROTEIN_ID_COLUMN
    return protein_modules


def build_site_assignments(
    *,
    pred_mat: pd.DataFrame,
    protein_modules: pd.Series,
    site_to_protein: pd.Series,
) -> pd.DataFrame:
    """Build the site-level assignment table from prediction outputs.

    Tied top-kinase assignments are preserved as weighted multi-assignments.
    Kinases sharing the top score for a site receive equal fractional weight in
    ``top_kinase_weights`` as ordered ``(kinase, weight)`` tuples (e.g. two-way
    tie -> ``(("A", 0.5), ("B", 0.5))``), while the full tie set remains
    available in ``top_kinase_candidates``.
    """

    site_index, protein_ids, resolved_protein_modules = _resolve_site_assignment_inputs(
        pred_mat=pred_mat,
        protein_modules=protein_modules,
        site_to_protein=site_to_protein,
    )
    module_ids = protein_ids.map(resolved_protein_modules).astype(int)
    top_assignments = _extract_top_kinase_assignments(
        sorted_pred_mat=_sort_prediction_columns(pred_mat),
        site_index=site_index,
    )
    return _build_site_assignment_frame(
        site_index=site_index,
        protein_ids=protein_ids,
        module_ids=module_ids,
        top_assignments=top_assignments,
    )


def _resolve_site_assignment_inputs(
    *,
    pred_mat: pd.DataFrame,
    protein_modules: pd.Series,
    site_to_protein: pd.Series,
) -> tuple[pd.Index, pd.Series, pd.Series]:
    if pred_mat.shape[1] == 0:
        msg = "pred_mat must contain at least one kinase column"
        raise InputCompatibilityError(msg)

    site_index = _as_unique_string_index(
        pred_mat.index,
        context="pred_mat",
        label=SITE_ID_COLUMN,
    )
    resolved_site_to_protein = _as_unique_string_series_index(
        site_to_protein,
        context="site_to_protein",
        label=SITE_ID_COLUMN,
    ).astype(str)
    _validate_site_to_protein_coverage(
        site_index=site_index,
        resolved_site_to_protein=resolved_site_to_protein,
    )
    protein_ids = resolved_site_to_protein.loc[site_index]

    resolved_protein_modules = _as_unique_string_series_index(
        protein_modules,
        context="protein_modules",
        label=PROTEIN_ID_COLUMN,
    ).astype(int)
    _validate_protein_module_coverage(
        protein_ids=protein_ids,
        resolved_protein_modules=resolved_protein_modules,
    )
    return site_index, protein_ids, resolved_protein_modules


def _validate_site_to_protein_coverage(
    *,
    site_index: pd.Index,
    resolved_site_to_protein: pd.Series,
) -> None:
    missing_site_ids = sorted(
        {
            site_id
            for site_id in site_index
            if site_id not in resolved_site_to_protein.index
        }
    )
    if not missing_site_ids:
        return
    preview = ", ".join(missing_site_ids[:3])
    suffix = "..." if len(missing_site_ids) > 3 else ""
    msg = (
        "site_to_protein must define a protein ID for every pred_mat site. "
        f"Missing mappings for: {preview}{suffix}"
    )
    raise InputCompatibilityError(msg)


def _validate_protein_module_coverage(
    *,
    protein_ids: pd.Series,
    resolved_protein_modules: pd.Series,
) -> None:
    missing_protein_ids = sorted(
        {
            str(protein_id)
            for protein_id in protein_ids.tolist()
            if str(protein_id) not in resolved_protein_modules.index
        }
    )
    if not missing_protein_ids:
        return
    preview = ", ".join(missing_protein_ids[:3])
    suffix = "..." if len(missing_protein_ids) > 3 else ""
    msg = (
        "protein_modules must define module IDs for every protein mapped "
        f"from pred_mat sites. Missing proteins: {preview}{suffix}"
    )
    raise InputCompatibilityError(msg)


def _sort_prediction_columns(pred_mat: pd.DataFrame) -> pd.DataFrame:
    sorted_kinase_columns = sorted(str(kinase) for kinase in pred_mat.columns)
    return pred_mat.loc[:, sorted_kinase_columns]


def _extract_top_kinase_assignments(
    *,
    sorted_pred_mat: pd.DataFrame,
    site_index: pd.Index,
) -> _TopKinaseAssignments:
    top_scores = sorted_pred_mat.max(axis=1).astype(float)
    top_score_mask = sorted_pred_mat.eq(top_scores, axis=0)
    top_score_mask_values = top_score_mask.to_numpy(dtype=bool, copy=False)
    top_kinase_names = top_score_mask.columns.to_numpy(dtype=object, copy=False)

    top_kinase_tie_count = top_score_mask_values.sum(axis=1).astype(int)
    zero_tie_mask = top_kinase_tie_count == 0
    if zero_tie_mask.any():
        zero_tie_sites = sorted(site_index[zero_tie_mask].tolist())
        preview = ", ".join(zero_tie_sites[:3])
        suffix = "..." if len(zero_tie_sites) > 3 else ""
        msg = (
            "pred_mat contains phosphosite rows with no top-kinase assignment "
            f"(all scores missing). Offending site IDs: {preview}{suffix}"
        )
        raise InputCompatibilityError(msg)

    top_kinase_candidates: list[tuple[str, ...]] = []
    top_kinase_weights: list[tuple[tuple[str, float], ...]] = []
    for mask_row, tie_count in zip(
        top_score_mask_values, top_kinase_tie_count, strict=True
    ):
        tied_kinases = tuple(str(kinase) for kinase in top_kinase_names[mask_row])
        weight = 1.0 / float(tie_count)
        top_kinase_candidates.append(tied_kinases)
        top_kinase_weights.append(tuple((kinase, weight) for kinase in tied_kinases))

    return _TopKinaseAssignments(
        top_scores=top_scores,
        top_kinase_candidates=top_kinase_candidates,
        top_kinase_weights=top_kinase_weights,
        top_kinase_tie_count=top_kinase_tie_count,
    )


def _build_site_assignment_frame(
    *,
    site_index: pd.Index,
    protein_ids: pd.Series,
    module_ids: pd.Series,
    top_assignments: _TopKinaseAssignments,
) -> pd.DataFrame:
    site_assignments = pd.DataFrame(
        {
            PROTEIN_ID_COLUMN: protein_ids.to_numpy(dtype=object, copy=False),
            MODULE_ID_COLUMN: module_ids.to_numpy(dtype=int, copy=False),
            TOP_KINASE_CANDIDATES_COLUMN: top_assignments.top_kinase_candidates,
            TOP_KINASE_WEIGHTS_COLUMN: top_assignments.top_kinase_weights,
            TOP_KINASE_TIE_COUNT_COLUMN: top_assignments.top_kinase_tie_count,
            TOP_KINASE_IS_AMBIGUOUS_COLUMN: top_assignments.top_kinase_tie_count > 1,
            TOP_SCORE_COLUMN: top_assignments.top_scores.to_numpy(
                dtype=float, copy=False
            ),
        },
        index=site_index,
    )
    return site_assignments.astype(
        {
            PROTEIN_ID_COLUMN: str,
            MODULE_ID_COLUMN: int,
            TOP_KINASE_TIE_COUNT_COLUMN: int,
            TOP_KINASE_IS_AMBIGUOUS_COLUMN: bool,
            TOP_SCORE_COLUMN: float,
        }
    )


def build_protein_assignment_table(*, site_assignments: pd.DataFrame) -> pd.DataFrame:
    """Build the protein-level assignment table from site assignments."""

    protein_assignments = (
        site_assignments.groupby(PROTEIN_ID_COLUMN, sort=True)
        .agg(
            module_id=(MODULE_ID_COLUMN, "first"),
            site_count=(MODULE_ID_COLUMN, "size"),
        )
        .astype({MODULE_ID_COLUMN: int, "site_count": int})
        .sort_index()
    )
    protein_assignments.index.name = PROTEIN_ID_COLUMN
    return protein_assignments


def select_kinase_substrates(
    *,
    pred_mat: pd.DataFrame,
    cutoff: float,
) -> dict[str, tuple[str, ...]]:
    """Select site substrates per kinase from the prediction matrix."""

    kinase_names = pred_mat.columns.astype(str).to_numpy(dtype=object, copy=False)
    site_ids = pred_mat.index.astype(str).to_numpy(dtype=object, copy=False)
    substrate_mask = pred_mat.to_numpy(dtype=float, copy=False) > cutoff

    return {
        str(kinase): tuple(site_ids[substrate_mask[:, position]].tolist())
        for position, kinase in enumerate(kinase_names)
    }


def build_signalome_module_table(
    *,
    site_assignments: pd.DataFrame,
    kinase_substrates: Mapping[str, Sequence[str]],
    assignment_policy: SignalomeAssignmentPolicy = (
        SIGNALOME_ASSIGNMENT_POLICY_CUTOFF_BINARY
    ),
) -> pd.DataFrame:
    """Build the wide module-by-kinase signalome table.

    ``assignment_policy`` controls attribution semantics:

    - ``cutoff_binary``: count each protein once for kinases with at least one
      substrate above ``signalome_cutoff`` (existing behaviour).
    - ``weighted_top``: propagate ``top_kinase_weights`` from site assignments
      as fractional protein contributions per module.
    """

    module_ids = sorted(
        {int(value) for value in site_assignments[MODULE_ID_COLUMN].tolist()}
    )
    kinase_names = list(kinase_substrates)
    module_index = pd.Index(module_ids, name=MODULE_ID_COLUMN)
    kinase_index = pd.Index(kinase_names, name=KINASE_COLUMN)

    protein_to_module = (
        site_assignments.loc[:, [PROTEIN_ID_COLUMN, MODULE_ID_COLUMN]]
        .drop_duplicates(subset=[PROTEIN_ID_COLUMN])
        .set_index(PROTEIN_ID_COLUMN)
        .loc[:, MODULE_ID_COLUMN]
        .astype(int)
    )

    if assignment_policy == SIGNALOME_ASSIGNMENT_POLICY_CUTOFF_BINARY:
        module_table = _build_cutoff_binary_module_table(
            site_assignments=site_assignments,
            protein_to_module=protein_to_module,
            kinase_index=kinase_index,
            module_index=module_index,
            kinase_substrates=kinase_substrates,
        )
    elif assignment_policy == SIGNALOME_ASSIGNMENT_POLICY_WEIGHTED_TOP:
        module_table = _build_weighted_top_module_table(
            site_assignments=site_assignments,
            protein_to_module=protein_to_module,
            kinase_index=kinase_index,
            module_index=module_index,
        )
    else:
        allowed = ", ".join(f"'{value}'" for value in SIGNALOME_ASSIGNMENT_POLICIES)
        msg = f"assignment_policy must be one of: {allowed}"
        raise InputCompatibilityError(msg)

    row_totals = module_table.sum(axis=1)
    non_zero = row_totals > 0
    if non_zero.any():
        module_table.loc[non_zero] = (
            module_table.loc[non_zero].div(
                row_totals.loc[non_zero],
                axis=0,
            )
            * 100.0
        )

    return module_table.round(3)


def _build_cutoff_binary_module_table(
    *,
    site_assignments: pd.DataFrame,
    protein_to_module: pd.Series,
    kinase_index: pd.Index,
    module_index: pd.Index,
    kinase_substrates: Mapping[str, Sequence[str]],
) -> pd.DataFrame:
    substrate_rows = [
        {KINASE_COLUMN: str(kinase), SITE_ID_COLUMN: str(site_id)}
        for kinase, substrates in kinase_substrates.items()
        for site_id in substrates
    ]
    if not substrate_rows:
        return pd.DataFrame(0.0, index=module_index, columns=kinase_index).round(3)

    substrate_table = pd.DataFrame.from_records(substrate_rows)
    substrate_table = substrate_table.astype({KINASE_COLUMN: str, SITE_ID_COLUMN: str})
    substrate_table = substrate_table.drop_duplicates(
        subset=[KINASE_COLUMN, SITE_ID_COLUMN]
    )

    site_to_protein = site_assignments.loc[:, [PROTEIN_ID_COLUMN]].copy()
    site_to_protein.index = pd.Index(
        site_to_protein.index.astype(str), name=SITE_ID_COLUMN
    )
    site_to_protein[PROTEIN_ID_COLUMN] = site_to_protein[PROTEIN_ID_COLUMN].astype(str)

    protein_hits = substrate_table.join(site_to_protein, on=SITE_ID_COLUMN, how="left")
    protein_hits = protein_hits.dropna(subset=[PROTEIN_ID_COLUMN])
    protein_hits = protein_hits.drop_duplicates(
        subset=[KINASE_COLUMN, PROTEIN_ID_COLUMN]
    )
    protein_hits = protein_hits.join(
        protein_to_module.rename(MODULE_ID_COLUMN),
        on=PROTEIN_ID_COLUMN,
        how="inner",
    )

    if protein_hits.empty:
        return pd.DataFrame(0.0, index=module_index, columns=kinase_index).round(3)

    counts = (
        protein_hits.groupby([MODULE_ID_COLUMN, KINASE_COLUMN], sort=True)
        .size()
        .astype(float)
        .unstack(fill_value=0.0)
    )
    module_table = counts.reindex(
        index=module_index,
        columns=kinase_index,
        fill_value=0.0,
    )
    return module_table.astype(float)


def _build_weighted_top_module_table(
    *,
    site_assignments: pd.DataFrame,
    protein_to_module: pd.Series,
    kinase_index: pd.Index,
    module_index: pd.Index,
) -> pd.DataFrame:
    weighted_rows: list[dict[str, object]] = []
    required_columns = {PROTEIN_ID_COLUMN, TOP_KINASE_WEIGHTS_COLUMN}
    missing_columns = sorted(required_columns.difference(site_assignments.columns))
    if missing_columns:
        missing = ", ".join(missing_columns)
        msg = (
            "site_assignments must include columns required for weighted_top "
            f"assignment_policy: {missing}"
        )
        raise InputCompatibilityError(msg)
    site_payload = site_assignments.loc[
        :, [PROTEIN_ID_COLUMN, TOP_KINASE_WEIGHTS_COLUMN]
    ]
    for row in site_payload.itertuples(index=False):
        protein_id = str(row.protein_id)
        if protein_id not in protein_to_module.index:
            continue
        module_id = int(protein_to_module.loc[protein_id])
        try:
            normalized_weights = normalize_top_kinase_weights(row.top_kinase_weights)
        except (TypeError, ValueError) as error:
            msg = (
                "site_assignments['top_kinase_weights'] must contain mappings, "
                "JSON objects, or (kinase, weight) sequences"
            )
            raise InputCompatibilityError(msg) from error
        for kinase, weight in normalized_weights:
            if kinase not in kinase_index:
                continue
            weighted_rows.append(
                {
                    MODULE_ID_COLUMN: module_id,
                    KINASE_COLUMN: kinase,
                    PROTEIN_ID_COLUMN: protein_id,
                    WEIGHT_COLUMN: float(weight),
                }
            )

    if not weighted_rows:
        return pd.DataFrame(0.0, index=module_index, columns=kinase_index).round(3)

    weighted_hits = pd.DataFrame.from_records(weighted_rows)
    weighted_hits = weighted_hits.astype(
        {
            MODULE_ID_COLUMN: int,
            KINASE_COLUMN: str,
            PROTEIN_ID_COLUMN: str,
            WEIGHT_COLUMN: float,
        }
    )

    protein_level_weights = (
        weighted_hits.groupby(
            [MODULE_ID_COLUMN, KINASE_COLUMN, PROTEIN_ID_COLUMN],
            sort=True,
        )[WEIGHT_COLUMN]
        .max()
        .astype(float)
        .reset_index()
    )
    counts = (
        protein_level_weights.groupby([MODULE_ID_COLUMN, KINASE_COLUMN], sort=True)[
            WEIGHT_COLUMN
        ]
        .sum()
        .astype(float)
        .unstack(fill_value=0.0)
    )
    module_table = counts.reindex(
        index=module_index,
        columns=kinase_index,
        fill_value=0.0,
    )
    return module_table.astype(float)


def build_kinase_module_relationship_table(
    *,
    module_table: pd.DataFrame,
) -> pd.DataFrame:
    """Build the long kinase-to-module relationship table."""

    try:
        relationships = (
            module_table.stack(future_stack=True)
            .rename(SHARE_PERCENT_COLUMN)
            .reset_index()
        )
    except TypeError:
        relationships = (
            module_table.stack(dropna=False).rename(SHARE_PERCENT_COLUMN).reset_index()
        )

    relationships = relationships.loc[relationships[SHARE_PERCENT_COLUMN] > 0.0]
    relationships.columns = [MODULE_ID_COLUMN, KINASE_COLUMN, SHARE_PERCENT_COLUMN]
    relationships = relationships.astype(
        {
            MODULE_ID_COLUMN: int,
            KINASE_COLUMN: str,
            SHARE_PERCENT_COLUMN: float,
        }
    )
    relationships = relationships.sort_values(
        [MODULE_ID_COLUMN, SHARE_PERCENT_COLUMN, KINASE_COLUMN],
        ascending=[True, False, True],
        kind="stable",
    ).reset_index(drop=True)
    return relationships


def build_expanded_signalomes(
    *,
    kinases_of_interest: Sequence[str],
    kinase_network: Mapping[str, Sequence[str]],
    kinase_substrates: Mapping[str, Sequence[str]],
    signalome_modules: pd.DataFrame,
    site_assignments: pd.DataFrame,
    expression_matrix: pd.DataFrame,
    min_kinase_module_share_percent: float,
) -> dict[str, ExpandedSignalome]:
    """Build expanded kinase-specific signalome views."""

    expanded: dict[str, ExpandedSignalome] = {}
    available_sites = site_assignments.index.astype(str)
    site_positions = {
        str(site_id): position for position, site_id in enumerate(available_sites)
    }
    site_module_ids = site_assignments.loc[:, MODULE_ID_COLUMN].to_numpy(
        dtype=int, copy=False
    )
    signalome_module_values = signalome_modules.to_numpy(dtype=float, copy=False)
    signalome_module_ids = signalome_modules.index.to_numpy(dtype=int, copy=False)
    signalome_kinase_positions = {
        str(kinase): position
        for position, kinase in enumerate(signalome_modules.columns.astype(str))
    }

    for kinase in kinases_of_interest:
        linked_kinases = tuple(dict.fromkeys((kinase, *kinase_network.get(kinase, ()))))
        kinase_position = signalome_kinase_positions[str(kinase)]
        regulated_module_ids_array = signalome_module_ids[
            signalome_module_values[:, kinase_position]
            > min_kinase_module_share_percent
        ]
        regulated_module_ids = tuple(
            int(module_id) for module_id in regulated_module_ids_array
        )

        substrate_positions = np.fromiter(
            (
                site_positions[str(site_id)]
                for linked_kinase in linked_kinases
                for site_id in kinase_substrates.get(linked_kinase, ())
                if str(site_id) in site_positions
            ),
            dtype=int,
        )
        if substrate_positions.size > 0:
            unique_substrate_positions = np.unique(substrate_positions)
            selected_positions = unique_substrate_positions[
                np.isin(
                    site_module_ids[unique_substrate_positions],
                    regulated_module_ids_array,
                )
            ]
        else:
            selected_positions = np.asarray([], dtype=int)

        expanded[kinase] = ExpandedSignalome(
            kinase=kinase,
            linked_kinases=linked_kinases,
            regulated_module_ids=regulated_module_ids,
            expression_matrix=expression_matrix.take(selected_positions),
            site_assignments=site_assignments.take(selected_positions),
        )

    return expanded
