# concinno-skills-vector RELEASE_COORDINATION

> All sessions/agents upgrading this package must read this file first.
> Governed by `~/.claude/rules/L1/release_coord.md`.

## 現況 snapshot (2026-04-22)

| 欄位 | 值 |
|---|---|
| Registry latest | **0.1.0 (LIVE 2026-04-22)** — https://pypi.org/project/concinno-skills-vector/0.1.0/ |
| Local version (pyproject) | 0.1.0 |
| CHANGELOG 最新 | 0.1.0 — 2026-04-22 |
| master HEAD | 2f18c6950 (ai-king monorepo) |
| 下一 publish 目標 | — (no next release queued) |

## WIP 變更清單

MVP initial release — fifth sub-package in the `concinno-skills-*`
ecosystem after `concinno-skills-google`, `concinno-skills-chat`,
`concinno-skills-office`, and `concinno-skills-sql`. Everything in
the tree is new.

Six tools across three vendors: `PineconeUpsert` / `PineconeQuery`
(pinecone v5+), `ChromaAdd` / `ChromaQuery` (chromadb v0.5+),
`WeaviateAdd` / `WeaviateQuery` (weaviate-client v4.9+). All thin
dispatch wrappers over a shared `_executor` helper, with shared
`_safety` enforcing top_k / batch / dim-consistency / filter-dict
guards.

## ⛔ 鐵律

1. **Thin adapter, not retrieval engine** — `concinno.rag.ZIQRetrieval`
   is the full BM25 + dense + FTRL online-learning retriever and
   lives in Concinno core. This sub-package is the outbound
   adapter for agents to read/write external vendor stores. Merging
   the two is forbidden — they target orthogonal slots and have
   different install paths.
2. **Pinecone SDK pin = `pinecone>=5.0`** (NOT `pinecone-client`) —
   the legacy `pinecone-client` package was renamed to `pinecone`
   in 2024 and is now marked DEPRECATED on PyPI. Re-pinning to
   `pinecone-client` would be a silent regression.
3. **Weaviate v4 only** — `weaviate-client>=4.9` uses the typed
   client API (`weaviate.connect_to_weaviate_cloud` + typed
   `Filter` objects). v3 API is not supported; attempting to fall
   back will break `_connect_weaviate`'s `connect_to_local` /
   `connect_to_weaviate_cloud` dispatch.
4. **`WeaviateQuery` dict filter rejection is intentional** —
   dropping filter terms silently would be a correctness bug worse
   than the error message. Adding a real translator is a future
   minor-version feature; removing the reject without the
   translator is forbidden.
5. **Shared safety guard** — all six tools MUST route through
   `_safety.check_top_k` / `_safety.check_vectors_batch` /
   `_safety.check_query_vector` / `_safety.check_filter_dict`.
   Anyone adding a seventh tool (e.g. `QdrantUpsert`) MUST go
   through the same guards rather than rolling their own.

## 升級前 checklist

- [x] tests 全綠 (73/73 passed, 2.46s)
- [x] ruff clean (src + tests)
- [x] mypy clean (strict mode, 6 source files)
- [x] CHANGELOG.md has 0.1.0 entry
- [x] pyproject.toml version = 0.1.0
- [x] `pip install -e . --no-deps` editable install succeeds
- [x] Three vendor API shapes re-verified via docs.pinecone.io /
      docs.trychroma.com / docs.weaviate.io 2026-04-22 WebFetch
      rounds before writing `_executor` and adapters.
- [x] Release authorization state checked:
      `describe_current_config()` → `disabled=True` (user opt-out,
      source=file). Per `rules/L1/release_coord.md` publish proceeds
      automatically under user opt-out.
- [x] `python -m build --no-isolation` succeeds (wheel + sdist)
- [x] `python -m twine check dist/*` PASSED (both wheel + sdist)
- [x] Entry-points integration verified locally:
      `CONCINNO_LOAD_PLUGINS=1 python -c "..."` → all six tool
      names present in `reg.list_deferred()` — PineconeUpsert /
      PineconeQuery / ChromaAdd / ChromaQuery / WeaviateAdd /
      WeaviateQuery all resolve via the entry-points table.

## 升級步驟

1. Verify release_authorization state:
   ```bash
   python -c "from concinno.release_authorization import describe_current_config; print(describe_current_config())"
   ```
2. If `disabled=True` → proceed. Else require STRING_MATCH auth
   `go publish concinno-skills-vector <ver>`.
3. Run build + check:
   ```bash
   PYTHONIOENCODING=utf-8 python -m build --no-isolation
   PYTHONIOENCODING=utf-8 python -m twine check dist/*
   ```
4. Upload:
   ```bash
   PYTHONIOENCODING=utf-8 python -m twine upload \
     --disable-progress-bar \
     dist/concinno_skills_vector-<ver>*
   ```
5. Tag + push:
   ```bash
   git tag -a skills-vector-v<ver> -m "concinno-skills-vector <ver>"
   git push origin skills-vector-v<ver>
   ```
6. Verify install in a clean env:
   `pip install concinno-skills-vector==<ver>`.

## Pending Publish Queue

(empty — 0.1.0 published, see History below)

## Lock 機制

### Active

無

### History

- 2026-04-22 — session `task_execution_2026-04-22_vector_ship` —
  target 0.1.0 — **result: ok** —
  https://pypi.org/project/concinno-skills-vector/0.1.0/
  - tests: 73/73 passed
  - ruff: clean (src + tests)
  - mypy: clean (strict, 6 source files)
  - twine check: PASSED (wheel + sdist)
  - entry_points integration: verified locally — all 6 tools
    (`PineconeUpsert` / `PineconeQuery` / `ChromaAdd` /
    `ChromaQuery` / `WeaviateAdd` / `WeaviateQuery`) resolve via
    `get_default_registry()` with `CONCINNO_LOAD_PLUGINS=1`
  - build commit: 2f18c6950
  - redteam review: SKIPPED — Low radius (MVP, repeat of the
    `concinno-skills-sql` shape, per `redteam.md` auto-skip)
  - release_authorization: `disabled=True` — no user string
    required
  - git tag: skills-vector-v0.1.0 (local only; no remote configured)

## 不可逆點清單

- `twine upload` → PyPI — cannot unpublish, only yank. Yanked
  versions remain installable via `==0.1.0` pinning.
- `git tag push origin skills-vector-v0.1.0` — tag can be
  force-deleted but already-cloned copies retain it.
