"""concinno_skills_vector.chroma — Chroma add + query Tools.

@module chroma
@responsibility Implement the Concinno :class:`Tool` protocol for
    adding vectors to and querying vectors from a Chroma collection.
    Supports both :class:`chromadb.HttpClient` (remote) and
    :class:`chromadb.PersistentClient` (local persistent). The local
    path mirrors ``concinno.rag.ZIQRetrieval``'s own Chroma usage so
    agents can reuse Chroma-backed state across skill and tool paths.
@dependencies chromadb>=0.5 (Apache-2.0).
@exports ChromaAdd, ChromaQuery

API surface verified against docs.trychroma.com 2026-04-22:

- ``chromadb.HttpClient(host=, port=, ssl=)`` → remote.
- ``chromadb.PersistentClient(path=)`` → local embedded.
- ``client.get_or_create_collection(name=)`` returns a Collection.
- ``collection.add(ids=, embeddings=[[...]], metadatas=[{...}])``
  accepts pre-computed vectors directly (skip auto-embedding).
- ``collection.query(query_embeddings=[[...]], n_results=N,
  where={...})`` returns a parallel-list response
  ``{"ids": [[...]], "distances": [[...]], "metadatas": [[...]]}``.

Concurrency
-----------
``is_concurrency_safe = False``. Chroma collection handles carry
in-memory state; serial dispatch keeps contract simple.
"""

from __future__ import annotations

from typing import Any

from concinno_skills_vector._executor import (
    collect_query_matches,
    missing_driver,
    wrap_error,
)
from concinno_skills_vector._safety import (
    check_filter_dict,
    check_nonempty_str,
    check_query_vector,
    check_top_k,
    check_vectors_batch,
)


def _build_chroma_client(kwargs: dict[str, Any], tool_name: str) -> Any:
    """Construct a chromadb client from the tool's kwargs.

    Supports three mutually-exclusive shapes:

    1. ``chroma_persist_dir`` → local :class:`PersistentClient`.
    2. ``chroma_host`` + ``chroma_port`` → remote
       :class:`HttpClient`.
    3. neither → :class:`EphemeralClient` (in-memory), intended
       for smoke tests.

    Returns ``(client, None)`` on success or ``(None, error_dict)``.
    """
    try:
        import chromadb
    except ImportError as exc:
        return None, missing_driver(
            tool_name, f"chromadb ({exc})", "pip install 'chromadb>=0.5'"
        )

    persist = kwargs.get("chroma_persist_dir")
    host = kwargs.get("chroma_host")
    port = kwargs.get("chroma_port")

    if persist is not None and host is not None:
        return None, {
            "error": (
                f"{tool_name}: specify either chroma_persist_dir "
                "(local) OR chroma_host+chroma_port (remote), not both"
            )
        }

    try:
        if persist is not None:
            if not isinstance(persist, str) or not persist:
                return None, {
                    "error": "chroma_persist_dir must be a non-empty string"
                }
            client = chromadb.PersistentClient(path=persist)
        elif host is not None:
            if not isinstance(host, str) or not host:
                return None, {
                    "error": "chroma_host must be a non-empty string"
                }
            if port is None:
                port = 8000
            if not isinstance(port, int) or isinstance(port, bool):
                return None, {"error": "chroma_port must be an integer"}
            ssl = bool(kwargs.get("chroma_ssl", False))
            client = chromadb.HttpClient(host=host, port=port, ssl=ssl)
        else:
            client = chromadb.EphemeralClient()
    except Exception as exc:  # noqa: BLE001
        return None, wrap_error(exc, tool_name, "client init")

    return client, None


class ChromaAdd:
    """Add (upsert) vectors into a Chroma collection.

    Params accepted via ``call(**kwargs)``:
        action (str):   must be ``"add"``.
        collection (str):  Collection name (auto-created if absent).
        vectors (list[list[float]]): Batch of pre-computed embeddings.
        ids (list[str]): One id per vector.
        metadata (list[dict] | None): Optional per-row metadata.
        chroma_persist_dir (str | None): Local embedded-mode path.
        chroma_host (str | None): Remote HTTP host.
        chroma_port (int | None): Remote HTTP port (default 8000).
        chroma_ssl (bool | None): Whether to use HTTPS (default False).

    Returns:
        ``{"ok": True, "added": N}`` on success,
        ``{"error": "..."}`` on failure.
    """

    name: str = "chroma_add"
    description: str = (
        "Add vectors to a Chroma collection (local persistent dir or "
        "remote HTTP). Params: action='add', collection, vectors "
        "(list[list[float]], same dim, batch <=10000), ids (list[str]), "
        "metadata (list[dict], optional), chroma_persist_dir OR "
        "chroma_host+chroma_port."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        if kwargs.get("action") != "add":
            return {"error": "action must be 'add'"}

        collection_name = check_nonempty_str(
            kwargs.get("collection"), "collection"
        )
        if isinstance(collection_name, dict):
            return collection_name

        ids_raw = kwargs.get("ids")
        if ids_raw is None:
            return {"error": "ids is required for Chroma add"}
        metadata_raw = kwargs.get("metadata")

        vec_check = check_vectors_batch(
            kwargs.get("vectors"), ids=ids_raw, metadata=metadata_raw
        )
        if isinstance(vec_check, dict):
            return vec_check
        vectors: list[list[float]] = vec_check
        ids: list[str] = ids_raw

        client, err = _build_chroma_client(kwargs, "ChromaAdd")
        if err is not None:
            return err

        try:
            coll = client.get_or_create_collection(name=collection_name)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "ChromaAdd", "collection handle")

        add_kwargs: dict[str, Any] = {
            "ids": ids,
            "embeddings": vectors,
        }
        if metadata_raw is not None:
            add_kwargs["metadatas"] = metadata_raw

        try:
            coll.add(**add_kwargs)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "ChromaAdd", "add")

        return {"ok": True, "added": len(vectors)}


class ChromaQuery:
    """Query a Chroma collection with a single vector.

    Params accepted via ``call(**kwargs)``:
        action (str):   must be ``"query"``.
        collection (str):  Collection name.
        vector (list[float]): Query vector.
        top_k (int):    Max results (default 10, max 1000).
        filter (dict | None): ``where`` metadata filter.
        chroma_persist_dir / chroma_host / chroma_port / chroma_ssl:
            Same selection rules as :class:`ChromaAdd`.

    Returns:
        ``{"matches": [{"id", "score", "metadata"}, ...]}`` on success,
        ``{"error": "..."}`` on failure. ``score`` is the Chroma
        distance (smaller = closer) — the tool passes it through as-is
        without flipping to a similarity so the caller's threshold
        logic is explicit.
    """

    name: str = "chroma_query"
    description: str = (
        "Query a Chroma collection by vector. "
        "Params: action='query', collection, vector (list[float]), "
        "top_k (<=1000), filter (dict, optional), "
        "chroma_persist_dir OR chroma_host+chroma_port."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        if kwargs.get("action") != "query":
            return {"error": "action must be 'query'"}

        collection_name = check_nonempty_str(
            kwargs.get("collection"), "collection"
        )
        if isinstance(collection_name, dict):
            return collection_name

        vec_check = check_query_vector(kwargs.get("vector"))
        if isinstance(vec_check, dict):
            return vec_check
        query_vector: list[float] = vec_check[0]

        top_k_check = check_top_k(kwargs.get("top_k"))
        if isinstance(top_k_check, dict):
            return top_k_check
        top_k: int = top_k_check

        filter_check = check_filter_dict(kwargs.get("filter"))
        if isinstance(filter_check, dict) and "error" in filter_check:
            return filter_check
        filt: dict[str, Any] = filter_check

        client, err = _build_chroma_client(kwargs, "ChromaQuery")
        if err is not None:
            return err

        try:
            coll = client.get_or_create_collection(name=collection_name)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "ChromaQuery", "collection handle")

        query_kwargs: dict[str, Any] = {
            "query_embeddings": [query_vector],
            "n_results": top_k,
        }
        if filt:
            query_kwargs["where"] = filt

        try:
            resp = coll.query(**query_kwargs)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "ChromaQuery", "query")

        # Chroma returns parallel lists of length 1 (one query vector).
        # Transpose to the unified ``[{"id", "score", "metadata"}, ...]``
        # shape that the caller sees from all three vendors.
        ids_list = (resp.get("ids") or [[]])[0]
        dist_list = (resp.get("distances") or [[]])[0]
        md_list = (resp.get("metadatas") or [[]])[0]
        zipped: list[dict[str, Any]] = []
        for i, id_ in enumerate(ids_list):
            zipped.append(
                {
                    "id": id_,
                    "score": dist_list[i] if i < len(dist_list) else None,
                    "metadata": (md_list[i] if i < len(md_list) else None)
                    or {},
                }
            )
        return {"matches": collect_query_matches(zipped)}


__all__ = ["ChromaAdd", "ChromaQuery"]
