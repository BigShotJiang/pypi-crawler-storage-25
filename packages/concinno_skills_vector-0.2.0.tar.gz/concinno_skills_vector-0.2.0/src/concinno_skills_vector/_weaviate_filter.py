"""concinno_skills_vector._weaviate_filter — MongoDB→Weaviate translator.

@module _weaviate_filter
@responsibility Translate MongoDB-style dict filters (``{"field": v}``,
    ``{"field": {"$op": v}}``, ``{"$and": [...]}``, ``{"$or": [...]}``)
    into Weaviate v4 typed ``Filter`` objects.

    The ``Filter`` class is taken as a parameter so the caller controls
    lazy-import timing (matches the pattern in
    :func:`weaviate_tool._connect_weaviate` — vendor SDK is only
    imported inside the tool ``call``, never at module load time).

Supported operators
-------------------
Scalar (``{"field": v}``) → ``.equal(v)`` (implicit $eq).

Comparison dict shapes under a field:

==========  =======================================================
$eq         ``.equal(v)``
$ne         ``.not_equal(v)``
$gt         ``.greater_than(v)``
$gte        ``.greater_or_equal(v)``
$lt         ``.less_than(v)``
$lte        ``.less_or_equal(v)``
$in         ``.contains_any([...])``
==========  =======================================================

Compound operators at the top or nested level:

==========  =======================================================
$and        ``Filter.all_of([translate(d1), translate(d2), ...])``
$or         ``Filter.any_of([translate(d1), translate(d2), ...])``
==========  =======================================================

Multiple top-level fields in the same dict imply **AND**:

    ``{"category": "books", "price": {"$gte": 100}}`` →
    ``Filter.all_of([by("category").equal("books"),
                     by("price").greater_or_equal(100)])``

Unsupported / rejected
----------------------
- ``$not`` — Weaviate v4 has ``Filter.not_`` but nesting semantics
  differ from MongoDB's; we refuse to guess rather than mistranslate.
  Callers who need negation should use ``$ne`` at the field level or
  call the SDK directly.
- ``$nin`` / ``$regex`` / ``$exists`` / ``$type`` — not present in
  the v4 Filter surface; raise ValueError with the offending operator.
- Unknown top-level keys (``$weird``, ``{field: {"$foo": v}}``) →
  raise ValueError so the WeaviateQuery caller surfaces a clean
  ``{"error": "..."}`` instead of silently dropping filter terms.
- Empty dict ``{}`` → ValueError. The caller should treat "no filter"
  as ``None``, not ``{}``. ``WeaviateQuery.call`` already passes only
  truthy ``filt`` to us; the guard here is defensive.

Design notes
------------
- Dispatch is flat (no recursion into nested field dicts) — Weaviate
  v4 property references are single-level per filter. Nested compound
  operators DO recurse via ``Filter.all_of`` / ``Filter.any_of``.
- Date / datetime values pass through untouched — the ``Filter``
  object accepts Python ``datetime.datetime`` natively. Callers must
  supply tz-aware datetimes if their schema uses ``DATE`` properties.
"""

from __future__ import annotations

from typing import Any

# MongoDB → Weaviate v4 by_property method name mapping.
# Scalar ``{"field": v}`` implicit $eq is handled separately below.
_FIELD_OPS: dict[str, str] = {
    "$eq": "equal",
    "$ne": "not_equal",
    "$gt": "greater_than",
    "$gte": "greater_or_equal",
    "$lt": "less_than",
    "$lte": "less_or_equal",
    "$in": "contains_any",
}

# Top-level compound operators that take a list of sub-filters.
_COMPOUND_OPS: dict[str, str] = {
    "$and": "all_of",
    "$or": "any_of",
}

# Operators we explicitly refuse with a helpful message (vs "unknown").
_UNSUPPORTED_FIELD_OPS: frozenset[str] = frozenset(
    {"$not", "$nin", "$regex", "$exists", "$type", "$size", "$mod"}
)
_UNSUPPORTED_TOP_OPS: frozenset[str] = frozenset({"$not", "$nor"})


def translate_filter(filt: dict[str, Any], Filter: Any) -> Any:
    """Convert a MongoDB-style dict filter to a Weaviate v4 ``Filter``.

    Parameters
    ----------
    filt:
        The input filter dict. Must be non-empty; a truly absent
        filter should be passed to Weaviate as ``filters=None``, not
        routed through this function.
    Filter:
        The class imported from :mod:`weaviate.classes.query`. Taken
        as a parameter so the caller owns the lazy-import timing —
        this mirrors :func:`weaviate_tool._connect_weaviate`.

    Returns
    -------
    A Weaviate typed filter object (opaque — construct via
    ``Filter.by_property(...)`` / ``Filter.all_of([...])`` /
    ``Filter.any_of([...])``).

    Raises
    ------
    ValueError
        On empty dict, unknown operator, malformed comparison dict,
        non-list arg to $and/$or/$in, or any unsupported operator.
    """
    if not isinstance(filt, dict):
        raise ValueError(
            f"filter must be a dict, got {type(filt).__name__}"
        )
    if not filt:
        raise ValueError(
            "filter dict is empty; pass filters=None for no filter"
        )

    # Top-level compound operator → single-key dispatch.
    # Mixing compound with field keys at the same level is rejected —
    # ``{"$and": [...], "category": "books"}`` is ambiguous, caller
    # should wrap the field term into the $and list explicitly.
    compound_keys = [k for k in filt if k.startswith("$")]
    field_keys = [k for k in filt if not k.startswith("$")]

    if compound_keys and field_keys:
        raise ValueError(
            "filter mixes compound operators and field keys at the "
            "same level; wrap field terms inside $and/$or instead"
        )

    if len(compound_keys) > 1:
        raise ValueError(
            f"filter has multiple top-level $ operators "
            f"{sorted(compound_keys)}; use $and/$or to combine them"
        )

    if compound_keys:
        op = compound_keys[0]
        if op in _UNSUPPORTED_TOP_OPS:
            raise ValueError(
                f"unsupported top-level operator {op!r}; Weaviate v4 "
                "has Filter.not_ but MongoDB nesting semantics differ "
                "— use $ne at field level or the Weaviate SDK directly"
            )
        if op not in _COMPOUND_OPS:
            raise ValueError(
                f"unknown top-level operator {op!r}; supported: "
                f"{sorted(_COMPOUND_OPS)}"
            )
        sub = filt[op]
        if not isinstance(sub, list) or not sub:
            raise ValueError(
                f"{op} expects a non-empty list of sub-filters, got "
                f"{type(sub).__name__}"
            )
        translated = [translate_filter(child, Filter) for child in sub]
        method = getattr(Filter, _COMPOUND_OPS[op])
        return method(translated)

    # Implicit AND across multiple field terms at the same level.
    field_filters = [
        _translate_field(field, filt[field], Filter)
        for field in field_keys
    ]
    if len(field_filters) == 1:
        return field_filters[0]
    return Filter.all_of(field_filters)


def _translate_field(field: str, spec: Any, Filter: Any) -> Any:
    """Translate a single ``{field: spec}`` clause.

    ``spec`` is either a scalar (implicit $eq) or a single-key dict
    like ``{"$gte": 100}`` / ``{"$in": [...]}``.
    """
    prop = Filter.by_property(field)

    # Scalar / list / tuple → implicit $eq.
    # Dict is the operator form; everything else is direct equality.
    if not isinstance(spec, dict):
        return prop.equal(spec)

    if not spec:
        raise ValueError(
            f"field {field!r} has empty operator dict; use "
            f'{{"$eq": value}} or a direct scalar'
        )

    if len(spec) > 1:
        # Multiple operators on one field → AND them together at the
        # Weaviate layer. This mirrors how MongoDB semantics combine
        # multiple keys in a single field clause.
        sub_filters = [
            _apply_field_op(prop, op, val, field)
            for op, val in spec.items()
        ]
        return Filter.all_of(sub_filters)

    (op, val), = spec.items()
    return _apply_field_op(prop, op, val, field)


def _apply_field_op(
    prop: Any, op: str, val: Any, field_name: str
) -> Any:
    """Apply a single ``$op: val`` to an already-built
    ``Filter.by_property(field)`` handle.
    """
    if op in _UNSUPPORTED_FIELD_OPS:
        raise ValueError(
            f"unsupported operator {op!r} on field {field_name!r}; "
            "supported: " + ", ".join(sorted(_FIELD_OPS))
        )
    if op not in _FIELD_OPS:
        raise ValueError(
            f"unknown operator {op!r} on field {field_name!r}; "
            f"supported: {sorted(_FIELD_OPS)}"
        )
    if op == "$in" and (not isinstance(val, list) or not val):
        raise ValueError(
            f"$in on field {field_name!r} expects a non-empty "
            f"list, got {type(val).__name__}"
        )
    method = getattr(prop, _FIELD_OPS[op])
    return method(val)


__all__ = ["translate_filter"]
