"""concinno_skills_vector.pinecone — Pinecone upsert + query Tools.

@module pinecone
@responsibility Implement the Concinno :class:`Tool` protocol for
    upserting vectors to and querying vectors from a remote Pinecone
    index. Uses the v5+ SDK surface
    (``pinecone.Pinecone(api_key=...)`` → ``pc.Index(name=...)``).
@dependencies pinecone>=5.0 (Apache-2.0).
@exports PineconeUpsert, PineconeQuery

Scope
-----
Thin adapter layer. Concinno core ships :class:`ZIQRetrieval` with
FTRL online-learning routing; this module is the outbound-to-vendor
slot for agents that already use Pinecone as their vector store.

API surface verified against docs.pinecone.io 2026-04-22:

- ``pinecone.Pinecone(api_key=...)`` returns the client handle.
- ``pc.Index(name=<index_name>)`` → per-index handle.
- Upsert shape: ``index.upsert(vectors=[{"id", "values", "metadata"}],
  namespace=...)``.
- Query shape: ``index.query(vector=[...], top_k=N, filter={...},
  include_metadata=True, namespace=...)``.

Concurrency
-----------
``is_concurrency_safe = False``. The pinecone client pools per-host
connections; serial dispatch keeps the tool contract simple.
"""

from __future__ import annotations

from typing import Any

from concinno_skills_vector._executor import (
    collect_query_matches,
    missing_driver,
    wrap_error,
)
from concinno_skills_vector._safety import (
    check_filter_dict,
    check_nonempty_str,
    check_query_vector,
    check_top_k,
    check_vectors_batch,
)


class PineconeUpsert:
    """Upsert a batch of vectors into a Pinecone index.

    Params accepted via ``call(**kwargs)``:
        action (str):    must be ``"upsert"`` (reserved for future
                         multi-action expansion).
        api_key (str):   Pinecone API key.
        index (str):     Index name.
        vectors (list[list[float]]): Batch of vectors (same dim).
        ids (list[str]): One id per vector (required — Pinecone
                         demands an id per record).
        metadata (list[dict] | None): Optional per-row metadata.
        namespace (str | None): Optional Pinecone namespace.

    Returns:
        ``{"ok": True, "upserted": N}`` on success,
        ``{"error": "..."}`` on failure.
    """

    name: str = "pinecone_upsert"
    description: str = (
        "Upsert vectors into a Pinecone index. "
        "Params: action='upsert', api_key, index, vectors "
        "(list[list[float]], same dim, batch <=10000), ids "
        "(list[str]), metadata (list[dict], optional), namespace "
        "(optional)."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        if kwargs.get("action") != "upsert":
            return {"error": "action must be 'upsert'"}

        api_key = check_nonempty_str(kwargs.get("api_key"), "api_key")
        if isinstance(api_key, dict):
            return api_key
        index_name = check_nonempty_str(kwargs.get("index"), "index")
        if isinstance(index_name, dict):
            return index_name

        ids_raw = kwargs.get("ids")
        if ids_raw is None:
            return {"error": "ids is required for Pinecone upsert"}

        metadata_raw = kwargs.get("metadata")
        vec_check = check_vectors_batch(
            kwargs.get("vectors"), ids=ids_raw, metadata=metadata_raw
        )
        if isinstance(vec_check, dict):
            return vec_check
        vectors: list[list[float]] = vec_check
        ids: list[str] = ids_raw  # validated in check_vectors_batch

        namespace = kwargs.get("namespace")
        if namespace is not None and not isinstance(namespace, str):
            return {"error": "namespace must be a string when provided"}

        try:
            from pinecone import Pinecone
        except ImportError as exc:
            return missing_driver(
                "PineconeUpsert",
                f"pinecone ({exc})",
                "pip install 'pinecone>=5.0'",
            )

        try:
            pc = Pinecone(api_key=api_key)
        except Exception as exc:  # noqa: BLE001 — vendor SDK can raise many types
            return wrap_error(exc, "PineconeUpsert", "client init")

        try:
            idx = pc.Index(name=index_name)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "PineconeUpsert", "index handle")

        records: list[dict[str, Any]] = []
        for i, vec in enumerate(vectors):
            rec: dict[str, Any] = {"id": ids[i], "values": vec}
            if metadata_raw is not None:
                rec["metadata"] = metadata_raw[i]
            records.append(rec)

        try:
            upsert_kwargs: dict[str, Any] = {"vectors": records}
            if namespace is not None:
                upsert_kwargs["namespace"] = namespace
            resp = idx.upsert(**upsert_kwargs)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "PineconeUpsert", "upsert")

        # Response shape varies by SDK version: dict-like
        # ``{"upserted_count": N}`` or object with .upserted_count.
        count: Any
        if isinstance(resp, dict):
            count = resp.get("upserted_count", len(records))
        else:
            count = getattr(resp, "upserted_count", len(records))
        return {"ok": True, "upserted": count}


class PineconeQuery:
    """Query a Pinecone index with a single vector.

    Params accepted via ``call(**kwargs)``:
        action (str):     must be ``"query"``.
        api_key (str):    Pinecone API key.
        index (str):      Index name.
        vector (list[float]): Query vector.
        top_k (int):      Max results (default 10, max 1000).
        filter (dict | None): Metadata filter (Pinecone JSON shape,
                              e.g. ``{"genre": {"$eq": "comedy"}}``).
        namespace (str | None): Optional Pinecone namespace.

    Returns:
        ``{"matches": [{"id", "score", "metadata"}, ...]}`` on success,
        ``{"error": "..."}`` on failure.
    """

    name: str = "pinecone_query"
    description: str = (
        "Query a Pinecone index by vector. "
        "Params: action='query', api_key, index, vector (list[float]), "
        "top_k (<=1000), filter (dict, optional), namespace (optional)."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        if kwargs.get("action") != "query":
            return {"error": "action must be 'query'"}

        api_key = check_nonempty_str(kwargs.get("api_key"), "api_key")
        if isinstance(api_key, dict):
            return api_key
        index_name = check_nonempty_str(kwargs.get("index"), "index")
        if isinstance(index_name, dict):
            return index_name

        vec_check = check_query_vector(kwargs.get("vector"))
        if isinstance(vec_check, dict):
            return vec_check
        query_vector: list[float] = vec_check[0]

        top_k_check = check_top_k(kwargs.get("top_k"))
        if isinstance(top_k_check, dict):
            return top_k_check
        top_k: int = top_k_check

        filter_check = check_filter_dict(kwargs.get("filter"))
        if isinstance(filter_check, dict) and "error" in filter_check:
            return filter_check
        filt: dict[str, Any] = filter_check

        namespace = kwargs.get("namespace")
        if namespace is not None and not isinstance(namespace, str):
            return {"error": "namespace must be a string when provided"}

        try:
            from pinecone import Pinecone
        except ImportError as exc:
            return missing_driver(
                "PineconeQuery",
                f"pinecone ({exc})",
                "pip install 'pinecone>=5.0'",
            )

        try:
            pc = Pinecone(api_key=api_key)
            idx = pc.Index(name=index_name)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "PineconeQuery", "client init")

        query_kwargs: dict[str, Any] = {
            "vector": query_vector,
            "top_k": top_k,
            "include_metadata": True,
        }
        if filt:
            query_kwargs["filter"] = filt
        if namespace is not None:
            query_kwargs["namespace"] = namespace

        try:
            resp = idx.query(**query_kwargs)
        except Exception as exc:  # noqa: BLE001
            return wrap_error(exc, "PineconeQuery", "query")

        # Response shape: dict-like ``{"matches": [...]}`` or object
        # with .matches attr. Both are handled by ``collect_query_matches``.
        raw_matches: Any
        if isinstance(resp, dict):
            raw_matches = resp.get("matches", [])
        else:
            raw_matches = getattr(resp, "matches", [])
        return {"matches": collect_query_matches(raw_matches)}


__all__ = ["PineconeQuery", "PineconeUpsert"]
