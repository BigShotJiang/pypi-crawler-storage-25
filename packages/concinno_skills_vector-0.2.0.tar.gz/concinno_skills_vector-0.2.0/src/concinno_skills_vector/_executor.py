"""concinno_skills_vector._executor — shared vendor-client call flow.

@module _executor
@responsibility All six tools share the same error-wrap shape and the
    same lazy vendor-import pattern. A missing driver package surfaces as
    a friendly ``{"error": "..."}`` payload instead of a raw
    ``ModuleNotFoundError`` that would bubble to the agent and poison
    its next turn.

Why a separate module
---------------------
Each vendor client (``pinecone`` / ``chromadb`` / ``weaviate``) has its
own init surface and is only lazy-imported inside the dispatch call.
Centralising the ``{"error":…}`` shape here means the three adapter
files read the same way and reviewers can diff them quickly — same
philosophy as the ``concinno-skills-sql._executor`` that this module
is modelled on.

Safety contract enforced by caller
----------------------------------
Each tool class is expected to have already run the relevant
:mod:`_safety` guards (``check_top_k`` / ``check_vectors_batch`` /
``check_query_vector`` / ``check_filter_dict``) before reaching here.
This module does not re-run them; it assumes a pre-validated payload.

Error wrap
----------
All vendor exceptions (auth failed, index not found, network, …)
surface as ``{"error": "<ToolName>: <phase>: <first line>"}``. We
trim the traceback because dumping full vendor SDK tracebacks into
the LLM context window is almost never useful.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("concinno_skills_vector._executor")


def first_line(exc: BaseException) -> str:
    """Return the first non-empty line of ``str(exc)``.

    Keeps vendor SDK tracebacks out of the agent's context.
    """
    text = str(exc)
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return text or exc.__class__.__name__


def wrap_error(
    exc: BaseException, tool_name: str, phase: str
) -> dict[str, str]:
    """Produce the standard ``{"error": "..."}`` payload + log at WARNING.

    All three vendors' tools share this helper so the agent-visible
    error shape is consistent.
    """
    msg = first_line(exc)
    logger.warning("%s %s failed: %s", tool_name, phase, msg)
    return {"error": f"{tool_name}: {phase}: {msg}"}


def missing_driver(
    tool_name: str, module_name: str, install_hint: str
) -> dict[str, str]:
    """Friendly error when a vendor SDK is missing.

    The concinno-skills-vector package already pins all three vendor
    SDKs as hard dependencies so this is only reached if a downstream
    consumer installed with ``--no-deps``. We still surface clearly.
    """
    return {
        "error": (
            f"{tool_name}: {module_name} not installed. "
            f"Run: {install_hint}"
        )
    }


def collect_query_matches(raw_matches: Any) -> list[dict[str, Any]]:
    """Normalise a vendor-specific query response into the agent-
    visible ``[{"id", "score", "metadata"}, ...]`` shape.

    Handles the three response shapes we encounter:

    - Pinecone: ``response["matches"]`` of ``{"id", "score",
      "metadata"}`` dicts (or ``ScoredVector`` objects with those
      attrs).
    - Chroma: parallel-list shape ``{"ids": [[...]], "distances":
      [[...]], "metadatas": [[...]]}`` — the tool wrapper transposes
      this before calling us; we receive the already-zipped list.
    - Weaviate: ``response.objects`` list of ``Object`` with
      ``uuid`` / ``metadata.distance`` / ``properties`` — again
      transposed in the tool wrapper.

    Input here is always the already-zipped ``list[dict]`` shape; we
    only add defensive defaults. Kept as a helper so all three tools
    converge on the same public contract.
    """
    out: list[dict[str, Any]] = []
    for m in raw_matches or []:
        if isinstance(m, dict):
            out.append(
                {
                    "id": m.get("id"),
                    "score": m.get("score"),
                    "metadata": m.get("metadata") or {},
                }
            )
        else:
            # Object-style access (pinecone ScoredVector).
            out.append(
                {
                    "id": getattr(m, "id", None),
                    "score": getattr(m, "score", None),
                    "metadata": getattr(m, "metadata", None) or {},
                }
            )
    return out


__all__ = [
    "collect_query_matches",
    "first_line",
    "missing_driver",
    "wrap_error",
]
