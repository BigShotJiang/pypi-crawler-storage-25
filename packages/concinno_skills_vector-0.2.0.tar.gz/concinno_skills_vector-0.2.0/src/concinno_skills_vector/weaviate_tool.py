"""concinno_skills_vector.weaviate_tool — Weaviate add + query Tools.

@module weaviate_tool
@responsibility Implement the Concinno :class:`Tool` protocol for
    inserting vectors into and querying vectors from a Weaviate v4
    collection. Uses the *v4* typed client API (not legacy v3) —
    ``weaviate.connect_to_weaviate_cloud`` / ``.connect_to_local``,
    ``client.collections.get(name)``,
    ``collection.batch.fixed_size()`` context manager,
    ``collection.query.near_vector(...)``.
@dependencies weaviate-client>=4.9 (BSD-3).
@exports WeaviateAdd, WeaviateQuery

Module is named ``weaviate_tool`` rather than ``weaviate`` so that
``from concinno_skills_vector.weaviate_tool import …`` does not
shadow a ``from weaviate import …`` vendor-SDK import inside the
same file. This matches the defensive pattern Concinno's own
``rag.py`` uses for ChromaDB (lazy + aliased import).

API surface verified against docs.weaviate.io + official client
docs 2026-04-22:

- Connect (cloud): ``weaviate.connect_to_weaviate_cloud(
  cluster_url=..., auth_credentials=Auth.api_key(...))`` →
  client; ``client.close()`` required.
- Connect (local): ``weaviate.connect_to_local()``.
- Collection handle: ``client.collections.get(name)``.
- Batch add with pre-computed vectors:
  ``with collection.batch.fixed_size(batch_size=200) as batch:
      batch.add_object(properties={...}, vector=[...])``.
- Query by vector: ``collection.query.near_vector(near_vector=[...],
  limit=N, return_metadata=MetadataQuery(distance=True))``.
  Response objects expose ``.uuid``, ``.properties``,
  ``.metadata.distance``.

Concurrency
-----------
``is_concurrency_safe = False``. Weaviate v4 clients hold gRPC and
HTTP connections; serial dispatch + ``client.close()`` per call
keeps sockets from leaking.
"""

from __future__ import annotations

import contextlib
from typing import Any

from concinno_skills_vector._executor import (
    collect_query_matches,
    missing_driver,
    wrap_error,
)
from concinno_skills_vector._safety import (
    check_filter_dict,
    check_nonempty_str,
    check_query_vector,
    check_top_k,
    check_vectors_batch,
)


def _connect_weaviate(kwargs: dict[str, Any], tool_name: str) -> Any:
    """Construct a weaviate v4 client from the tool's kwargs.

    Two mutually-exclusive shapes:

    1. ``weaviate_url`` (+ optional ``weaviate_api_key``) → cloud.
    2. neither → ``connect_to_local()``.

    Returns ``(client, None)`` on success or ``(None, error_dict)``.

    Caller MUST call ``client.close()`` when done — we don't wrap in
    a context manager here because the add/query workflow interleaves
    with collection handles and batch managers.
    """
    try:
        import weaviate
        from weaviate.classes.init import Auth
    except ImportError as exc:
        return None, missing_driver(
            tool_name,
            f"weaviate-client ({exc})",
            "pip install 'weaviate-client>=4.9'",
        )

    url = kwargs.get("weaviate_url")
    api_key = kwargs.get("weaviate_api_key")

    try:
        if url is not None:
            if not isinstance(url, str) or not url:
                return None, {
                    "error": "weaviate_url must be a non-empty string"
                }
            if api_key is not None:
                if not isinstance(api_key, str) or not api_key:
                    return None, {
                        "error": (
                            "weaviate_api_key must be a non-empty string"
                            " when provided"
                        )
                    }
                client = weaviate.connect_to_weaviate_cloud(
                    cluster_url=url,
                    auth_credentials=Auth.api_key(api_key),
                )
            else:
                client = weaviate.connect_to_weaviate_cloud(cluster_url=url)
        else:
            client = weaviate.connect_to_local()
    except Exception as exc:  # noqa: BLE001
        return None, wrap_error(exc, tool_name, "client init")

    return client, None


def _safe_close(client: Any) -> None:
    """Best-effort close for a weaviate v4 client.

    Weaviate v4 requires explicit close; we swallow any close-time
    exception so the primary return value is not masked by a
    shutdown error.
    """
    with contextlib.suppress(Exception):
        client.close()


class WeaviateAdd:
    """Insert vectors into a Weaviate v4 collection using the batch
    context manager.

    Params accepted via ``call(**kwargs)``:
        action (str):   must be ``"add"``.
        collection (str):  Collection name (must already exist in
                           Weaviate; this tool does NOT create schema —
                           use Weaviate's admin API for that).
        vectors (list[list[float]]): Batch of pre-computed embeddings.
        ids (list[str]): One id per vector (passed to
                         ``batch.add_object(uuid=...)``). Strings must
                         be valid UUIDs in Weaviate's model, but we
                         accept any non-empty string and surface any
                         server-side validation error back to the
                         caller.
        metadata (list[dict] | None): One properties-dict per vector.
                                      Required if the collection has
                                      non-nullable properties.
        weaviate_url (str | None): Weaviate Cloud cluster URL. If
                                   omitted, falls back to
                                   ``connect_to_local()``.
        weaviate_api_key (str | None): API key for cloud auth.

    Returns:
        ``{"ok": True, "added": N, "failed": M}`` on success,
        ``{"error": "..."}`` on failure. ``M > 0`` indicates some
        per-object failures — details are not surfaced here to keep
        the LLM payload bounded; consult the weaviate server logs.
    """

    name: str = "weaviate_add"
    description: str = (
        "Insert vectors into a Weaviate v4 collection via the batch "
        "context manager. Params: action='add', collection, vectors "
        "(list[list[float]], same dim, batch <=10000), ids (list[str]), "
        "metadata (list[dict], optional), weaviate_url (optional; omit "
        "for local), weaviate_api_key (optional)."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        if kwargs.get("action") != "add":
            return {"error": "action must be 'add'"}

        collection_name = check_nonempty_str(
            kwargs.get("collection"), "collection"
        )
        if isinstance(collection_name, dict):
            return collection_name

        ids_raw = kwargs.get("ids")
        if ids_raw is None:
            return {"error": "ids is required for Weaviate add"}
        metadata_raw = kwargs.get("metadata")

        vec_check = check_vectors_batch(
            kwargs.get("vectors"), ids=ids_raw, metadata=metadata_raw
        )
        if isinstance(vec_check, dict):
            return vec_check
        vectors: list[list[float]] = vec_check
        ids: list[str] = ids_raw

        client, err = _connect_weaviate(kwargs, "WeaviateAdd")
        if err is not None:
            return err

        try:
            coll = client.collections.get(collection_name)
        except Exception as exc:  # noqa: BLE001
            _safe_close(client)
            return wrap_error(exc, "WeaviateAdd", "collection handle")

        failed = 0
        try:
            with coll.batch.fixed_size(batch_size=200) as batch:
                for i, vec in enumerate(vectors):
                    props = (
                        metadata_raw[i] if metadata_raw is not None else {}
                    )
                    batch.add_object(
                        properties=props,
                        vector=vec,
                        uuid=ids[i],
                    )
            # After the context exits, collection.batch.failed_objects
            # holds per-object errors (list). We only surface the count.
            failed_objs = getattr(coll.batch, "failed_objects", None) or []
            failed = len(failed_objs)
        except Exception as exc:  # noqa: BLE001
            _safe_close(client)
            return wrap_error(exc, "WeaviateAdd", "batch add")

        _safe_close(client)
        return {
            "ok": True,
            "added": len(vectors) - failed,
            "failed": failed,
        }


class WeaviateQuery:
    """Query a Weaviate v4 collection with a single vector.

    Params accepted via ``call(**kwargs)``:
        action (str):    must be ``"query"``.
        collection (str):  Collection name.
        vector (list[float]): Query vector.
        top_k (int):     Max results (default 10, max 1000).
        filter (dict | None): Metadata filter in MongoDB-style dict
                              form. Translated to Weaviate v4 typed
                              ``Filter`` object via
                              :mod:`concinno_skills_vector._weaviate_filter`.
                              Supported ops: ``$eq`` / ``$ne`` /
                              ``$gt`` / ``$gte`` / ``$lt`` / ``$lte`` /
                              ``$in`` on fields; ``$and`` / ``$or``
                              as compound operators. Scalar values
                              use implicit ``$eq``. Multiple
                              top-level fields imply AND.
                              ``$not`` / ``$nin`` / ``$regex`` are
                              not supported — use the Weaviate SDK
                              directly for those cases.
                              Empty / ``None`` filter is fine.
        weaviate_url (str | None): Weaviate Cloud cluster URL.
        weaviate_api_key (str | None): API key for cloud auth.

    Returns:
        ``{"matches": [{"id", "score", "metadata"}, ...]}`` on success,
        ``{"error": "..."}`` on failure. ``score`` is the Weaviate
        distance (smaller = closer, same convention as Chroma).
    """

    name: str = "weaviate_query"
    description: str = (
        "Query a Weaviate v4 collection by vector. "
        "Params: action='query', collection, vector (list[float]), "
        "top_k (<=1000), filter (MongoDB-style dict, optional — "
        "supports $eq/$ne/$gt/$gte/$lt/$lte/$in on fields and "
        "$and/$or as compound operators; scalars imply $eq; "
        "multiple top-level fields imply AND), "
        "weaviate_url (optional; omit for local), weaviate_api_key "
        "(optional)."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        if kwargs.get("action") != "query":
            return {"error": "action must be 'query'"}

        collection_name = check_nonempty_str(
            kwargs.get("collection"), "collection"
        )
        if isinstance(collection_name, dict):
            return collection_name

        vec_check = check_query_vector(kwargs.get("vector"))
        if isinstance(vec_check, dict):
            return vec_check
        query_vector: list[float] = vec_check[0]

        top_k_check = check_top_k(kwargs.get("top_k"))
        if isinstance(top_k_check, dict):
            return top_k_check
        top_k: int = top_k_check

        filter_check = check_filter_dict(kwargs.get("filter"))
        if isinstance(filter_check, dict) and "error" in filter_check:
            return filter_check
        filt: dict[str, Any] = filter_check

        try:
            from weaviate.classes.query import Filter, MetadataQuery
        except ImportError as exc:
            return missing_driver(
                "WeaviateQuery",
                f"weaviate-client ({exc})",
                "pip install 'weaviate-client>=4.9'",
            )

        weaviate_filter: Any = None
        if filt:
            from concinno_skills_vector._weaviate_filter import (
                translate_filter,
            )

            try:
                weaviate_filter = translate_filter(filt, Filter)
            except ValueError as exc:
                return {"error": f"WeaviateQuery filter: {exc}"}

        client, err = _connect_weaviate(kwargs, "WeaviateQuery")
        if err is not None:
            return err

        try:
            coll = client.collections.get(collection_name)
        except Exception as exc:  # noqa: BLE001
            _safe_close(client)
            return wrap_error(exc, "WeaviateQuery", "collection handle")

        try:
            resp = coll.query.near_vector(
                near_vector=query_vector,
                limit=top_k,
                filters=weaviate_filter,
                return_metadata=MetadataQuery(distance=True),
            )
        except Exception as exc:  # noqa: BLE001
            _safe_close(client)
            return wrap_error(exc, "WeaviateQuery", "query")

        zipped: list[dict[str, Any]] = []
        for obj in getattr(resp, "objects", None) or []:
            md = getattr(obj, "metadata", None)
            distance = getattr(md, "distance", None) if md is not None else None
            zipped.append(
                {
                    "id": str(getattr(obj, "uuid", "")),
                    "score": distance,
                    "metadata": dict(getattr(obj, "properties", None) or {}),
                }
            )
        _safe_close(client)
        return {"matches": collect_query_matches(zipped)}


__all__ = ["WeaviateAdd", "WeaviateQuery"]
