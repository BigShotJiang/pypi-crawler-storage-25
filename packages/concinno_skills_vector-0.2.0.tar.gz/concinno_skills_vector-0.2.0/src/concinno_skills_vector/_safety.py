"""concinno_skills_vector._safety — shared vector-DB input guard.

@module _safety
@responsibility Central safety-check module used by every vector-DB tool
    (``PineconeUpsert`` / ``PineconeQuery`` / ``ChromaAdd`` /
    ``ChromaQuery`` / ``WeaviateAdd`` / ``WeaviateQuery``).

    Four separable checks:

    1. :func:`check_top_k` — clamp ``top_k`` at 1000 so a bad query
       does not pull a whole index into the agent's context window.
    2. :func:`check_vectors_batch` — cap ``vectors`` batch at
       10_000 rows (one-call upload ceiling; use pagination for
       larger jobs).
    3. :func:`check_vector_dim_consistency` — enforce a single
       dimensionality per batch (first row defines dim, rest must
       match). Mixed-dim batches are the classic index-poisoning
       footgun.
    4. :func:`check_filter_json_only` — reject non-dict / non-JSON
       filter bodies. Weaviate v4 has a native ``Filter`` object and
       Pinecone / Chroma accept JSON dicts; we normalise on "dict
       only" at the tool layer so no side-channel scripting can ride
       in via string filters.

The checks live here (not duplicated in each tool) for the same reason
the SQL sibling centralises them — one audit point, one rule-set.

Safety rationale
----------------
Vector DBs do not have a "DDL" keyword to firewall. The realistic
agent footguns are:

- Unbounded ``top_k`` (explodes token budget).
- Giant batch upload (driver-side OOM on the vendor).
- Mixed-dimension vectors (corrupts the index — vendor accepts one
  dim per name and rejects later batches with no rollback).
- String / script filter injection (Pinecone accepts JSON only but
  a sloppy agent could template a string; Weaviate Filter DSL is a
  typed object that ``json.dumps`` must refuse).

We do not pretend to validate the vector values themselves (floats
in [-1, 1], L2-normalised, etc.) — that is the caller's embedding
model concern, not a runtime guard.
"""

from __future__ import annotations

from typing import TypeAlias

# Return-type shape shared with the tool modules. Narrowing via
# ``isinstance(..., dict)`` in the tool ``call``.
SafeIntResult: TypeAlias = "int | dict[str, str]"
SafeVectorsResult: TypeAlias = "list[list[float]] | dict[str, str]"
SafeDictResult: TypeAlias = "dict[str, object] | dict[str, str]"


# Hard caps. These mirror the SQL sibling's row-limit philosophy —
# one-call ceilings to keep LLM context bounded. Agents that want
# larger jobs must paginate explicitly.
MAX_TOP_K: int = 1000
DEFAULT_TOP_K: int = 10
MAX_VECTORS_BATCH: int = 10_000


def check_top_k(raw: object) -> SafeIntResult:
    """Clamp the ``top_k`` kwarg for a vector query.

    Missing → :data:`DEFAULT_TOP_K` (10).
    Int in ``[1, MAX_TOP_K]`` → passthrough.
    Otherwise → ``{"error": "..."}``.
    """
    if raw is None:
        return DEFAULT_TOP_K
    if not isinstance(raw, int) or isinstance(raw, bool):
        return {"error": "top_k must be an integer when provided"}
    if raw <= 0:
        return {"error": "top_k must be a positive integer"}
    if raw > MAX_TOP_K:
        return {
            "error": (
                f"top_k {raw} exceeds MAX_TOP_K={MAX_TOP_K}. "
                "Issue multiple queries with different filters to "
                "page the result set."
            )
        }
    return raw


def check_vectors_batch(
    vectors: object,
    ids: object | None = None,
    metadata: object | None = None,
) -> SafeVectorsResult:
    """Validate a batch upload payload.

    Rules:
        1. ``vectors`` is a non-empty list of lists-of-numbers
           (tuples accepted, coerced to list).
        2. Batch size <= :data:`MAX_VECTORS_BATCH`.
        3. All rows share the same length (dimension). First row
           defines the dim; mismatches reject with the offending row
           index.
        4. Each row contains only ``int`` / ``float`` (``bool`` is
           rejected — a common agent mistake).
        5. If ``ids`` is provided, its length must match. Strings
           only.
        6. If ``metadata`` is provided, its length must match. Each
           element must be a dict (Pinecone / Weaviate accept JSON-
           serialisable property maps; Chroma does too).

    Returns the normalised ``list[list[float]]`` on success or
    ``{"error": "..."}`` on failure.
    """
    if not isinstance(vectors, list) or not vectors:
        return {"error": "vectors must be a non-empty list of numeric lists"}
    if len(vectors) > MAX_VECTORS_BATCH:
        return {
            "error": (
                f"vectors batch size {len(vectors)} exceeds "
                f"MAX_VECTORS_BATCH={MAX_VECTORS_BATCH}. Split into "
                "multiple upsert calls."
            )
        }

    dim: int | None = None
    normalised: list[list[float]] = []
    for idx, row in enumerate(vectors):
        if not isinstance(row, (list, tuple)) or not row:
            return {
                "error": (
                    f"vectors[{idx}] must be a non-empty list of numbers"
                )
            }
        coerced: list[float] = []
        for j, val in enumerate(row):
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                return {
                    "error": (
                        f"vectors[{idx}][{j}] must be int/float, got "
                        f"{type(val).__name__}"
                    )
                }
            coerced.append(float(val))
        if dim is None:
            dim = len(coerced)
        elif len(coerced) != dim:
            return {
                "error": (
                    f"vector dimension mismatch at vectors[{idx}]: "
                    f"expected dim={dim} (from vectors[0]), got "
                    f"{len(coerced)}. Mixed-dim batches corrupt the "
                    "index; rebuild the batch with a single dim."
                )
            }
        normalised.append(coerced)

    if ids is not None:
        if not isinstance(ids, list) or len(ids) != len(normalised):
            return {
                "error": (
                    f"ids must be a list with len={len(normalised)} "
                    "matching vectors, or omitted"
                )
            }
        for k, id_ in enumerate(ids):
            if not isinstance(id_, str) or not id_:
                return {"error": f"ids[{k}] must be a non-empty string"}

    if metadata is not None:
        if not isinstance(metadata, list) or len(metadata) != len(normalised):
            return {
                "error": (
                    f"metadata must be a list with len={len(normalised)} "
                    "matching vectors, or omitted"
                )
            }
        for k, md in enumerate(metadata):
            if not isinstance(md, dict):
                return {
                    "error": (
                        f"metadata[{k}] must be a dict (JSON-"
                        "serialisable property map)"
                    )
                }

    return normalised


def check_query_vector(raw: object) -> SafeVectorsResult:
    """Validate a single query vector.

    Returns ``[[...]]`` (list wrapped) on success — shape matches
    :func:`check_vectors_batch` so downstream code can share the
    ``list[list[float]]`` contract. ``{"error": "..."}`` on failure.
    """
    if not isinstance(raw, (list, tuple)) or not raw:
        return {"error": "vector must be a non-empty list of numbers"}
    coerced: list[float] = []
    for j, val in enumerate(raw):
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            return {
                "error": (
                    f"vector[{j}] must be int/float, got "
                    f"{type(val).__name__}"
                )
            }
        coerced.append(float(val))
    return [coerced]


def check_filter_dict(raw: object) -> SafeDictResult:
    """Validate a filter body.

    ``None`` → ``{}`` (passthrough as empty filter).
    ``dict`` → passthrough (caller is responsible for vendor-specific
    key shapes like ``{"$eq": ...}``).
    Anything else → reject. String / bytes / callables cannot ride
    in as filter — Pinecone's metadata filter grammar is JSON only,
    and Weaviate's typed Filter objects are assembled by the tool
    wrapper from the dict we accept here.
    """
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        return {
            "error": (
                f"filter must be a dict or None, got "
                f"{type(raw).__name__}. String filters / embedded "
                "scripts are rejected — Pinecone accepts JSON; "
                "Weaviate Filter objects are built by the tool."
            )
        }
    return raw


def check_nonempty_str(raw: object, field: str) -> str | dict[str, str]:
    """Validate a required non-empty string kwarg."""
    if not isinstance(raw, str) or not raw.strip():
        return {"error": f"{field} must be a non-empty string"}
    return raw


__all__ = [
    "DEFAULT_TOP_K",
    "MAX_TOP_K",
    "MAX_VECTORS_BATCH",
    "SafeDictResult",
    "SafeIntResult",
    "SafeVectorsResult",
    "check_filter_dict",
    "check_nonempty_str",
    "check_query_vector",
    "check_top_k",
    "check_vectors_batch",
]
