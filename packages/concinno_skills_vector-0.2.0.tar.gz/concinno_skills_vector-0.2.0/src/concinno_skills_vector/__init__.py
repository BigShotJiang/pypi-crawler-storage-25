"""concinno-skills-vector — Remote vector DB skills for Concinno.

Opt-in plugin package. When installed alongside ``concinno>=2.15.1`` and
the consumer env sets ``CONCINNO_LOAD_PLUGINS=1``, the tools here
auto-mount into :class:`concinno.tools.registry.ToolRegistry` via the
``[project.entry-points."concinno.tools"]`` table in ``pyproject.toml``.

MVP surface
-----------
- :class:`PineconeUpsert` / :class:`PineconeQuery` — Pinecone v5+
  SDK (``pinecone`` package; ``pinecone-client`` was renamed in
  2024 and is deprecated).
- :class:`ChromaAdd` / :class:`ChromaQuery` — Chroma 0.5+ via
  local :class:`chromadb.PersistentClient` or remote
  :class:`chromadb.HttpClient`.
- :class:`WeaviateAdd` / :class:`WeaviateQuery` — Weaviate 4.9+
  typed client (``weaviate-client``); v3 legacy API is not
  supported.

Scope separation from Concinno core
-----------------------------------
Concinno core ships :class:`concinno.rag.ZIQRetrieval` — a full
retrieval stack (BM25 + dense embedding + FTRL online learning).
The tools in this sub-package are **thin adapters** for agents that
need to read from or write to an *external* Pinecone / Chroma /
Weaviate deployment. The two can coexist in the same registry.

Differentiation vs LangChain retrievers: Concinno ZIQ is the full
retrieval engine with FTRL online-learning route — LangChain
retrievers have no equivalent self-adapting router. This sub-package
only handles the narrow "talk to vendor X" contract; the intelligent
routing lives in Concinno core.

Safety
------
All tools route through :mod:`concinno_skills_vector._safety`:

1. ``check_top_k`` — cap ``top_k`` at 1000 so a bad query does not
   pull a whole index into the agent's context window.
2. ``check_vectors_batch`` — cap batch at 10_000 rows + enforce
   per-batch vector-dimension consistency (first row defines dim,
   rest must match) + reject ``bool`` entries.
3. ``check_query_vector`` — same value checks for a single query
   vector.
4. ``check_filter_dict`` — reject non-dict filters; Pinecone /
   Chroma accept JSON dicts, Weaviate's typed ``Filter`` DSL is
   not translatable from an untyped dict so we error out early.

Credentials
-----------
No credentials are stored. Callers pass ``api_key`` / ``weaviate_url``
/ ``chroma_host`` + ``chroma_port`` or ``chroma_persist_dir`` per
call, which is the realistic shape for agents that juggle multiple
vector stores. Consumers wanting indirection can resolve upstream
via env expansion or Concinno's ``CredentialStore``.

License notes
-------------
- ``pinecone`` — Apache-2.0.
- ``chromadb`` — Apache-2.0.
- ``weaviate-client`` — BSD-3-Clause.

All three are permissive; no LGPL transitive concerns (unlike the
``concinno-skills-sql`` ``psycopg[binary]`` path).
"""

from __future__ import annotations

from concinno_skills_vector.chroma import ChromaAdd, ChromaQuery
from concinno_skills_vector.pinecone import PineconeQuery, PineconeUpsert
from concinno_skills_vector.weaviate_tool import WeaviateAdd, WeaviateQuery

__version__ = "0.2.0"
__all__ = [
    "ChromaAdd",
    "ChromaQuery",
    "PineconeQuery",
    "PineconeUpsert",
    "WeaviateAdd",
    "WeaviateQuery",
    "__version__",
]
