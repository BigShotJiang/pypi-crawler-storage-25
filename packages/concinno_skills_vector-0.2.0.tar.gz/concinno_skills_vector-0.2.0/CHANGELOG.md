# Changelog

All notable changes to `concinno-skills-vector` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project adheres to Semantic Versioning.

## [0.2.0] - 2026-04-23

### Added

- `WeaviateQuery` now accepts MongoDB-style dict filters and
  translates them server-side to Weaviate v4's typed ``Filter`` DSL.
  Supported operators:
  - Field-level: `$eq` (implicit for scalars), `$ne`, `$gt`, `$gte`,
    `$lt`, `$lte`, `$in`.
  - Compound: `$and`, `$or` (can nest arbitrarily).
  - Implicit AND across multiple top-level fields in the same dict.
  - Multiple operators on one field auto-AND (e.g.
    `{"price": {"$gte": 10, "$lt": 100}}`).
- New module `concinno_skills_vector._weaviate_filter` with
  `translate_filter(filt, Filter)`. The `Filter` class is taken as
  a parameter so the caller owns lazy-import timing (same pattern
  as `_connect_weaviate`).
- Explicit error paths for unsupported operators: `$not` / `$nin` /
  `$regex` / `$exists` / `$type` / `$size` / `$mod` / `$nor` surface
  as `{"error": "WeaviateQuery filter: unsupported operator ..."}`
  rather than silently dropping filter terms.

### Changed

- `WeaviateQuery.description` updated to document the supported
  MongoDB-style dict grammar (previously said "must be empty/None").
- `WeaviateQuery` now imports `Filter` alongside `MetadataQuery` from
  `weaviate.classes.query` — the `ImportError` guard covers both.
- Backward compatible: empty / absent filter still passes
  `filters=None` to `near_vector`; existing 0.1.0 callers with no
  filter unaffected.

### Tests

- 97 unit tests pass (up from 73):
  - 24 new tests in `tests/test_weaviate_filter.py` — 21 unit
    tests covering the translation matrix (all 7 field ops, both
    compound ops, implicit AND, multi-op field, nested AND/OR,
    rejection paths) + 3 integration tests through
    `WeaviateQuery.call`.
  - Existing `test_weaviate.py` updated: the dict-filter rejection
    test now exercises an unsupported operator (`$regex`) rather
    than the old "dict rejected wholesale" behaviour; the mock
    `weaviate.classes.query` stub now provides a `Filter` class.

## [0.1.0] - 2026-04-22

### Added

- Initial release. Fifth sub-package in the `concinno-skills-*`
  ecosystem after `concinno-skills-google`, `concinno-skills-chat`,
  `concinno-skills-office`, and `concinno-skills-sql`. Exercises the
  `[project.entry-points."concinno.tools"]` discovery path with six
  tools across three vendors.
- `PineconeUpsert` + `PineconeQuery` — upsert and query a Pinecone
  v5+ index via the official `pinecone` SDK (Apache-2.0). Uses the
  new `pinecone.Pinecone(api_key=...)` / `pc.Index(name=...)` surface;
  the legacy `pinecone-client` (2024 rename) is not supported.
- `ChromaAdd` + `ChromaQuery` — add and query a Chroma collection
  via `chromadb>=0.5` (Apache-2.0). Supports both local
  `chromadb.PersistentClient(path=...)` and remote
  `chromadb.HttpClient(host=..., port=..., ssl=...)`.
- `WeaviateAdd` + `WeaviateQuery` — insert and query a Weaviate v4
  typed-client collection via `weaviate-client>=4.9` (BSD-3). Uses
  `collection.batch.fixed_size()` context manager for batch add,
  `collection.query.near_vector()` for query; v3 legacy API is not
  supported. `client.close()` is called in a `finally`-equivalent
  `contextlib.suppress` so sockets don't leak.
- Shared `_safety` module enforcing:
  - `top_k` cap (`DEFAULT_TOP_K=10`, `MAX_TOP_K=1000`);
  - `vectors` batch cap (`MAX_VECTORS_BATCH=10_000`);
  - vector dimension consistency (first row defines dim, all
    subsequent rows must match);
  - `bool` rejection inside numeric vectors (a common agent
    mistake);
  - per-row `ids` (non-empty strings) and `metadata` (dicts) length
    matching;
  - filter body must be a `dict` or `None` — strings / scripts
    rejected.
- Shared `_executor` module with vendor-agnostic
  `{"error": "<ToolName>: <phase>: <first line>"}` wrapping and a
  unified `collect_query_matches` helper that normalises the three
  vendors' response shapes (Pinecone dict / object ; Chroma parallel
  lists ; Weaviate `response.objects` attr-style) into a single
  `[{"id", "score", "metadata"}, ...]` contract visible to the LLM.

### Scope separation

- Concinno core's `concinno.rag.ZIQRetrieval` (BM25 + dense +
  FTRL online-learning router) remains the **full retrieval
  engine**. This sub-package is a **thin outbound adapter** for
  agents that already use Pinecone / Chroma / Weaviate as their
  vector store.
- `WeaviateQuery` rejects non-empty dict filters with a clear
  message — Weaviate's typed `Filter` DSL cannot be translated
  faithfully from an untyped dict and we don't want to lie by
  silently dropping filter terms. Callers needing server-side
  filtering should use the Weaviate SDK directly for that call.

### Tests

- 73 unit tests, all passing:
  - 28 for `_safety` guards (top_k / vectors_batch / query_vector /
    filter / nonempty_str);
  - 16 for the two Pinecone tools (monkey-patched vendor import);
  - 15 for the two Chroma tools (real roundtrip via
    `PersistentClient` + `tmp_path` fixture);
  - 14 for the two Weaviate tools (full stub of `weaviate` /
    `weaviate.classes.init` / `weaviate.classes.query` in
    `sys.modules`).
- Real end-to-end Chroma add+query is exercised because `chromadb`
  is zero-network — an agent installing the package can execute the
  test path without any external service.
