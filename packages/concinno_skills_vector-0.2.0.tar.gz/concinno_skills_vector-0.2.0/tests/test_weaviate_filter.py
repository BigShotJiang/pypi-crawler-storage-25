"""Unit tests for concinno_skills_vector._weaviate_filter.

The translator is handed a ``Filter`` class (the caller controls the
import). We use ``unittest.mock.MagicMock`` to record the method chain
so these tests run without the vendor SDK installed — same pattern
as test_weaviate.py.

Also includes two integration-style tests that run through
``WeaviateQuery.call`` to confirm translated filters reach the
``near_vector`` call and that malformed dicts surface a clean error
dict (not an exception).
"""

from __future__ import annotations

import sys
import types
from typing import Any
from unittest.mock import MagicMock

import pytest

from concinno_skills_vector import WeaviateQuery
from concinno_skills_vector._weaviate_filter import translate_filter

# ── Scalar / comparison operators ────────────────────────────────


def test_scalar_implicit_eq() -> None:
    """``{"field": value}`` → ``.equal(value)``."""
    MockFilter = MagicMock()
    translate_filter({"category": "books"}, MockFilter)
    MockFilter.by_property.assert_called_once_with("category")
    MockFilter.by_property.return_value.equal.assert_called_once_with("books")


def test_explicit_eq() -> None:
    """``{"$eq": v}`` goes through the same ``.equal(v)`` path."""
    MockFilter = MagicMock()
    translate_filter({"category": {"$eq": "books"}}, MockFilter)
    MockFilter.by_property.return_value.equal.assert_called_once_with("books")


def test_ne() -> None:
    MockFilter = MagicMock()
    translate_filter({"status": {"$ne": "archived"}}, MockFilter)
    MockFilter.by_property.return_value.not_equal.assert_called_once_with(
        "archived"
    )


def test_gt() -> None:
    MockFilter = MagicMock()
    translate_filter({"price": {"$gt": 100}}, MockFilter)
    MockFilter.by_property.return_value.greater_than.assert_called_once_with(
        100
    )


def test_gte() -> None:
    MockFilter = MagicMock()
    translate_filter({"price": {"$gte": 100}}, MockFilter)
    by_prop = MockFilter.by_property.return_value
    by_prop.greater_or_equal.assert_called_once_with(100)


def test_lt() -> None:
    MockFilter = MagicMock()
    translate_filter({"price": {"$lt": 100}}, MockFilter)
    MockFilter.by_property.return_value.less_than.assert_called_once_with(100)


def test_lte() -> None:
    MockFilter = MagicMock()
    translate_filter({"price": {"$lte": 100}}, MockFilter)
    MockFilter.by_property.return_value.less_or_equal.assert_called_once_with(
        100
    )


def test_in() -> None:
    """``$in`` → ``.contains_any([...])``."""
    MockFilter = MagicMock()
    translate_filter(
        {"category": {"$in": ["books", "movies"]}}, MockFilter
    )
    MockFilter.by_property.return_value.contains_any.assert_called_once_with(
        ["books", "movies"]
    )


# ── Compound operators ───────────────────────────────────────────


def test_and() -> None:
    """``$and`` → ``Filter.all_of([...])`` with recursion into children."""
    MockFilter = MagicMock()
    translate_filter(
        {
            "$and": [
                {"category": "books"},
                {"price": {"$gte": 100}},
            ]
        },
        MockFilter,
    )
    # all_of was called once at the top level.
    MockFilter.all_of.assert_called_once()
    # Each child triggered a by_property call.
    assert MockFilter.by_property.call_count == 2
    calls = [c.args[0] for c in MockFilter.by_property.call_args_list]
    assert "category" in calls
    assert "price" in calls


def test_or() -> None:
    """``$or`` → ``Filter.any_of([...])``."""
    MockFilter = MagicMock()
    translate_filter(
        {
            "$or": [
                {"status": "draft"},
                {"status": "review"},
            ]
        },
        MockFilter,
    )
    MockFilter.any_of.assert_called_once()


def test_implicit_and_multifield() -> None:
    """``{"f1": v1, "f2": v2}`` → ``Filter.all_of([by(f1).eq(v1), by(f2).eq(v2)])``."""
    MockFilter = MagicMock()
    translate_filter(
        {"category": "books", "price": {"$gte": 100}}, MockFilter
    )
    MockFilter.all_of.assert_called_once()
    assert MockFilter.by_property.call_count == 2


def test_nested_or_and() -> None:
    """Deeply nested $or containing an $and branch — recursion invariant."""
    MockFilter = MagicMock()
    translate_filter(
        {
            "$or": [
                {"cat": "a"},
                {
                    "$and": [
                        {"cat": "b"},
                        {"price": {"$gte": 10}},
                    ]
                },
            ]
        },
        MockFilter,
    )
    MockFilter.any_of.assert_called_once()
    MockFilter.all_of.assert_called_once()
    assert MockFilter.by_property.call_count == 3


# ── Rejection paths ──────────────────────────────────────────────


def test_unsupported_regex_raises() -> None:
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match=r"\$regex"):
        translate_filter({"field": {"$regex": ".*"}}, MockFilter)


def test_unknown_top_level_operator() -> None:
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match=r"\$weird"):
        translate_filter({"$weird": [1, 2]}, MockFilter)


def test_not_rejected_explicitly() -> None:
    """$not is refused rather than guessed at (docs this limit)."""
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match=r"\$not"):
        translate_filter({"field": {"$not": {"$eq": "x"}}}, MockFilter)


def test_empty_dict_raises() -> None:
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match="empty"):
        translate_filter({}, MockFilter)


def test_mixed_compound_and_field() -> None:
    """{"$and": [...], "field": v} is ambiguous — reject."""
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match="mixes"):
        translate_filter(
            {"$and": [{"x": 1}], "category": "books"}, MockFilter
        )


def test_and_expects_list() -> None:
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match=r"\$and expects"):
        translate_filter({"$and": {"x": 1}}, MockFilter)


def test_in_expects_nonempty_list() -> None:
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match=r"\$in"):
        translate_filter({"cat": {"$in": []}}, MockFilter)


def test_non_dict_input() -> None:
    MockFilter = MagicMock()
    with pytest.raises(ValueError, match="must be a dict"):
        translate_filter("not-a-dict", MockFilter)  # type: ignore[arg-type]


# ── Multiple operators on same field ─────────────────────────────


def test_multi_op_one_field_is_anded() -> None:
    """``{"price": {"$gte": 10, "$lt": 100}}`` → AND of gte + lt."""
    MockFilter = MagicMock()
    translate_filter({"price": {"$gte": 10, "$lt": 100}}, MockFilter)
    # Two ops on one field → Filter.all_of of two sub-filters.
    MockFilter.all_of.assert_called_once()
    by_prop = MockFilter.by_property.return_value
    by_prop.greater_or_equal.assert_called_once_with(10)
    by_prop.less_than.assert_called_once_with(100)


# ── Integration through WeaviateQuery.call ───────────────────────


class _FakeMetadata:
    def __init__(self, distance: float) -> None:
        self.distance = distance


class _FakeObject:
    def __init__(
        self, uuid: str, properties: dict[str, Any], distance: float
    ) -> None:
        self.uuid = uuid
        self.properties = properties
        self.metadata = _FakeMetadata(distance)


class _FakeResp:
    def __init__(self, objects: list[_FakeObject]) -> None:
        self.objects = objects


class _RecordingQuery:
    """Captures ``near_vector`` kwargs so the test can inspect
    ``filters=...``."""

    def __init__(self) -> None:
        self.last_kwargs: dict[str, Any] = {}

    def near_vector(self, **kwargs: Any) -> _FakeResp:
        self.last_kwargs = kwargs
        return _FakeResp(
            [_FakeObject("550e8400-e29b-41d4-a716-446655440000", {}, 0.1)]
        )


class _FakeCollection:
    def __init__(self) -> None:
        self.query = _RecordingQuery()


class _FakeCollections:
    def __init__(self) -> None:
        self._coll = _FakeCollection()

    def get(self, name: str) -> _FakeCollection:  # noqa: ARG002
        return self._coll


class _FakeClient:
    def __init__(self) -> None:
        self.collections = _FakeCollections()
        self.closed = False

    def close(self) -> None:
        self.closed = True


def _install_weaviate_mock_with_filter(
    monkeypatch: pytest.MonkeyPatch,
) -> tuple[_FakeClient, MagicMock]:
    """Install a weaviate mock with a MagicMock Filter class.

    Returns (fake_client, MockFilter) so the test can assert both
    that ``near_vector`` received a filters= value and that
    ``Filter.by_property`` / method calls happened as expected.
    """
    fake_client = _FakeClient()
    mock_filter = MagicMock(name="Filter")

    def _connect_cloud(**kwargs: Any) -> _FakeClient:  # noqa: ARG001
        return fake_client

    def _connect_local(**kwargs: Any) -> _FakeClient:  # noqa: ARG001
        return fake_client

    class _Auth:
        @staticmethod
        def api_key(key: str) -> str:
            return f"auth:{key}"

    class _MetadataQuery:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    weaviate_mod = types.ModuleType("weaviate")
    weaviate_mod.connect_to_weaviate_cloud = _connect_cloud  # type: ignore[attr-defined]
    weaviate_mod.connect_to_local = _connect_local  # type: ignore[attr-defined]
    classes_mod = types.ModuleType("weaviate.classes")
    init_mod = types.ModuleType("weaviate.classes.init")
    init_mod.Auth = _Auth  # type: ignore[attr-defined]
    query_mod = types.ModuleType("weaviate.classes.query")
    query_mod.Filter = mock_filter  # type: ignore[attr-defined]
    query_mod.MetadataQuery = _MetadataQuery  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "weaviate", weaviate_mod)
    monkeypatch.setitem(sys.modules, "weaviate.classes", classes_mod)
    monkeypatch.setitem(sys.modules, "weaviate.classes.init", init_mod)
    monkeypatch.setitem(sys.modules, "weaviate.classes.query", query_mod)
    return fake_client, mock_filter


def test_weaviate_query_accepts_dict_filter(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """End-to-end: dict filter reaches near_vector as translated object."""
    fake_client, mock_filter = _install_weaviate_mock_with_filter(
        monkeypatch
    )

    out = WeaviateQuery().call(
        action="query",
        collection="Article",
        vector=[0.1, 0.2],
        top_k=5,
        filter={"category": "books", "price": {"$gte": 100}},
        weaviate_url="https://cluster.example.net",
        weaviate_api_key="wk",
    )
    assert "matches" in out
    # The near_vector call received a non-None filters kwarg.
    near_kwargs = fake_client.collections._coll.query.last_kwargs  # noqa: SLF001
    assert "filters" in near_kwargs
    assert near_kwargs["filters"] is not None
    # Filter.all_of was invoked for the implicit AND.
    mock_filter.all_of.assert_called_once()
    # by_property saw both fields.
    called_fields = [
        c.args[0] for c in mock_filter.by_property.call_args_list
    ]
    assert "category" in called_fields
    assert "price" in called_fields
    assert fake_client.closed is True


def test_weaviate_query_invalid_filter_returns_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Bad dict → clean ``{"error": "..."}`` (not raised exception)."""
    _install_weaviate_mock_with_filter(monkeypatch)

    out = WeaviateQuery().call(
        action="query",
        collection="Article",
        vector=[0.1, 0.2],
        filter={"field": {"$regex": ".*"}},
        weaviate_url="https://cluster.example.net",
        weaviate_api_key="wk",
    )
    assert "error" in out
    assert "$regex" in out["error"]


def test_weaviate_query_none_filter_passes_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """No filter → near_vector sees filters=None (backward compat)."""
    fake_client, _ = _install_weaviate_mock_with_filter(monkeypatch)

    out = WeaviateQuery().call(
        action="query",
        collection="Article",
        vector=[0.1],
        weaviate_url="https://cluster.example.net",
        weaviate_api_key="wk",
    )
    assert "matches" in out
    near_kwargs = fake_client.collections._coll.query.last_kwargs  # noqa: SLF001
    assert near_kwargs["filters"] is None
