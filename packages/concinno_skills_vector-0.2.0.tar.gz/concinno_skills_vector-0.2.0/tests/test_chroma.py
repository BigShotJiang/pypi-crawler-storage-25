"""Unit tests for concinno_skills_vector.chroma.

Chroma is the one vendor whose SDK is zero-network and can run in
an ephemeral in-memory mode. We exercise a real add+query roundtrip
against ``chromadb.EphemeralClient`` (no Docker, no HTTP) so the
happy path is end-to-end verified, not just mocked. Validation-only
paths stay mock-free since they never reach the vendor.
"""

from __future__ import annotations

from typing import Any

import pytest

pytest.importorskip("chromadb")

from concinno_skills_vector import ChromaAdd, ChromaQuery  # noqa: E402

# ── Protocol surface ─────────────────────────────────────────────


def test_chroma_add_protocol() -> None:
    assert ChromaAdd.name == "chroma_add"
    assert ChromaAdd.is_concurrency_safe is False
    assert "Chroma" in ChromaAdd.description


def test_chroma_query_protocol() -> None:
    assert ChromaQuery.name == "chroma_query"
    assert ChromaQuery.is_concurrency_safe is False


# ── Action validation ─────────────────────────────────────────────


def test_chroma_add_wrong_action() -> None:
    out = ChromaAdd().call(action="query")
    assert "error" in out
    assert "add" in out["error"]


def test_chroma_query_wrong_action() -> None:
    out = ChromaQuery().call(action="add")
    assert "error" in out


# ── Required kwargs ───────────────────────────────────────────────


def test_chroma_add_missing_collection() -> None:
    out = ChromaAdd().call(action="add")
    assert "error" in out
    assert "collection" in out["error"]


def test_chroma_add_missing_ids() -> None:
    out = ChromaAdd().call(
        action="add", collection="c", vectors=[[1.0]]
    )
    assert "error" in out
    assert "ids" in out["error"]


def test_chroma_add_bad_vectors() -> None:
    out = ChromaAdd().call(
        action="add", collection="c", vectors=[], ids=[]
    )
    assert "error" in out
    assert "non-empty" in out["error"]


# ── Client-build validation ───────────────────────────────────────


def test_chroma_both_local_and_remote_rejected() -> None:
    out = ChromaAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0]],
        ids=["a"],
        chroma_persist_dir="/tmp/x",
        chroma_host="localhost",
    )
    assert "error" in out
    assert "either" in out["error"].lower()


def test_chroma_bad_host_type() -> None:
    out = ChromaAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0]],
        ids=["a"],
        chroma_host=123,
    )
    assert "error" in out
    assert "chroma_host" in out["error"]


def test_chroma_bad_persist_dir_type() -> None:
    out = ChromaAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0]],
        ids=["a"],
        chroma_persist_dir=42,
    )
    assert "error" in out
    assert "chroma_persist_dir" in out["error"]


def test_chroma_bad_port_type() -> None:
    out = ChromaAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0]],
        ids=["a"],
        chroma_host="localhost",
        chroma_port="not-an-int",
    )
    assert "error" in out
    assert "chroma_port" in out["error"]


# ── Query validation ──────────────────────────────────────────────


def test_chroma_query_missing_vector() -> None:
    out = ChromaQuery().call(action="query", collection="c")
    assert "error" in out
    assert "vector" in out["error"]


def test_chroma_query_top_k_overflow() -> None:
    out = ChromaQuery().call(
        action="query",
        collection="c",
        vector=[0.1],
        top_k=9999,
    )
    assert "error" in out
    assert "MAX_TOP_K" in out["error"]


# ── Real end-to-end via PersistentClient ────────────────────────


def test_chroma_add_real_client_via_persist_dir(
    tmp_path: Any,
) -> None:
    """Verify end-to-end add + query using PersistentClient + tmp_path.

    Two separate tool calls share state through the on-disk store,
    matching how an agent actually uses the tool.
    """
    persist = str(tmp_path / "chromadb")

    add_out = ChromaAdd().call(
        action="add",
        collection="roundtrip",
        vectors=[[1.0, 0.0], [0.0, 1.0]],
        ids=["p-1", "p-2"],
        metadata=[{"kind": "a"}, {"kind": "b"}],
        chroma_persist_dir=persist,
    )
    assert add_out == {"ok": True, "added": 2}, add_out

    q_out = ChromaQuery().call(
        action="query",
        collection="roundtrip",
        vector=[1.0, 0.0],
        top_k=2,
        chroma_persist_dir=persist,
    )
    assert "error" not in q_out, q_out
    assert "matches" in q_out
    assert len(q_out["matches"]) == 2
    # The nearest match is the identity vector.
    assert q_out["matches"][0]["id"] == "p-1"
    assert q_out["matches"][0]["metadata"] == {"kind": "a"}
    # Chroma distance: identical vector → 0 (or near-zero).
    assert q_out["matches"][0]["score"] is not None


def test_chroma_missing_driver(monkeypatch: pytest.MonkeyPatch) -> None:
    """If ``chromadb`` can't import, ChromaAdd surfaces a clean error."""
    import sys

    monkeypatch.setitem(sys.modules, "chromadb", None)
    out = ChromaAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0]],
        ids=["a"],
    )
    assert "error" in out
    assert "chromadb" in out["error"].lower()
