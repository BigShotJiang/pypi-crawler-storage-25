"""Unit tests for concinno_skills_vector._safety.

Exercises all four shared guards:

1. ``check_top_k`` — default / clamp / reject.
2. ``check_vectors_batch`` — dim mismatch / cap / type / ids / metadata.
3. ``check_query_vector`` — type + shape coercion.
4. ``check_filter_dict`` — None / dict / reject string.
"""

from __future__ import annotations

from concinno_skills_vector._safety import (
    DEFAULT_TOP_K,
    MAX_TOP_K,
    MAX_VECTORS_BATCH,
    check_filter_dict,
    check_nonempty_str,
    check_query_vector,
    check_top_k,
    check_vectors_batch,
)

# ── check_top_k ───────────────────────────────────────────────────


def test_top_k_default() -> None:
    assert check_top_k(None) == DEFAULT_TOP_K


def test_top_k_valid() -> None:
    assert check_top_k(5) == 5
    assert check_top_k(MAX_TOP_K) == MAX_TOP_K


def test_top_k_overflow() -> None:
    out = check_top_k(MAX_TOP_K + 1)
    assert isinstance(out, dict)
    assert "MAX_TOP_K" in out["error"]


def test_top_k_non_positive() -> None:
    for bad in (0, -1):
        out = check_top_k(bad)
        assert isinstance(out, dict)
        assert "positive" in out["error"]


def test_top_k_wrong_type() -> None:
    for bad in (3.14, "5", True, [5]):
        out = check_top_k(bad)
        assert isinstance(out, dict)
        assert "integer" in out["error"]


# ── check_vectors_batch ───────────────────────────────────────────


def test_vectors_batch_ok() -> None:
    vectors = [[1.0, 2.0], [3.0, 4.0]]
    out = check_vectors_batch(vectors, ids=["a", "b"])
    assert out == [[1.0, 2.0], [3.0, 4.0]]


def test_vectors_batch_coerces_ints() -> None:
    out = check_vectors_batch([[1, 2, 3]], ids=["a"])
    assert out == [[1.0, 2.0, 3.0]]


def test_vectors_batch_empty() -> None:
    out = check_vectors_batch([])
    assert isinstance(out, dict)
    assert "non-empty" in out["error"]


def test_vectors_batch_not_list() -> None:
    out = check_vectors_batch("not a list")
    assert isinstance(out, dict)


def test_vectors_batch_overflow() -> None:
    big = [[1.0]] * (MAX_VECTORS_BATCH + 1)
    out = check_vectors_batch(big, ids=["a"] * len(big))
    assert isinstance(out, dict)
    assert "MAX_VECTORS_BATCH" in out["error"]


def test_vectors_batch_dim_mismatch() -> None:
    out = check_vectors_batch(
        [[1.0, 2.0], [3.0, 4.0, 5.0]], ids=["a", "b"]
    )
    assert isinstance(out, dict)
    assert "dimension mismatch" in out["error"]


def test_vectors_batch_bool_rejected() -> None:
    out = check_vectors_batch([[True, False]], ids=["a"])
    assert isinstance(out, dict)
    assert "int/float" in out["error"]


def test_vectors_batch_ids_len_mismatch() -> None:
    out = check_vectors_batch([[1.0], [2.0]], ids=["only-one"])
    assert isinstance(out, dict)
    assert "ids" in out["error"]


def test_vectors_batch_ids_not_str() -> None:
    out = check_vectors_batch([[1.0]], ids=[123])
    assert isinstance(out, dict)
    assert "non-empty string" in out["error"]


def test_vectors_batch_metadata_len_mismatch() -> None:
    out = check_vectors_batch(
        [[1.0], [2.0]], ids=["a", "b"], metadata=[{"k": "v"}]
    )
    assert isinstance(out, dict)
    assert "metadata" in out["error"]


def test_vectors_batch_metadata_not_dict() -> None:
    out = check_vectors_batch(
        [[1.0]], ids=["a"], metadata=["not-a-dict"]
    )
    assert isinstance(out, dict)
    assert "dict" in out["error"]


# ── check_query_vector ────────────────────────────────────────────


def test_query_vector_ok() -> None:
    out = check_query_vector([0.1, 0.2, 0.3])
    assert out == [[0.1, 0.2, 0.3]]


def test_query_vector_tuple_accepted() -> None:
    out = check_query_vector((1.0, 2.0))
    assert out == [[1.0, 2.0]]


def test_query_vector_empty() -> None:
    out = check_query_vector([])
    assert isinstance(out, dict)
    assert "non-empty" in out["error"]


def test_query_vector_bool_rejected() -> None:
    out = check_query_vector([True, 1])
    assert isinstance(out, dict)
    assert "int/float" in out["error"]


def test_query_vector_string_rejected() -> None:
    out = check_query_vector([0.1, "not-a-num"])
    assert isinstance(out, dict)


# ── check_filter_dict ─────────────────────────────────────────────


def test_filter_none_is_empty() -> None:
    assert check_filter_dict(None) == {}


def test_filter_dict_passthrough() -> None:
    f = {"category": {"$eq": "book"}}
    assert check_filter_dict(f) == f


def test_filter_string_rejected() -> None:
    out = check_filter_dict("category:book")
    assert isinstance(out, dict) and "error" in out
    assert "dict" in out["error"]


def test_filter_list_rejected() -> None:
    out = check_filter_dict([("category", "book")])
    assert isinstance(out, dict) and "error" in out


# ── check_nonempty_str ────────────────────────────────────────────


def test_nonempty_str_ok() -> None:
    assert check_nonempty_str("hello", "field") == "hello"


def test_nonempty_str_empty_rejected() -> None:
    out = check_nonempty_str("", "api_key")
    assert isinstance(out, dict)
    assert "api_key" in out["error"]


def test_nonempty_str_wrong_type() -> None:
    out = check_nonempty_str(None, "index")
    assert isinstance(out, dict)
    assert "index" in out["error"]
