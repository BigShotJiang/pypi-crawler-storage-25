"""Unit tests for concinno_skills_vector.pinecone.

We exercise the tool's ``call(**kwargs)`` validation paths using only
the shared ``_safety`` guards — no real Pinecone connection is made.
Happy-path tests monkeypatch the lazy vendor import inside the
call-site module so they do not require the vendor SDK installed.
"""

from __future__ import annotations

from typing import Any

import pytest

from concinno_skills_vector import PineconeQuery, PineconeUpsert

# ── Protocol surface ─────────────────────────────────────────────


def test_pinecone_upsert_protocol() -> None:
    assert PineconeUpsert.name == "pinecone_upsert"
    assert PineconeUpsert.is_concurrency_safe is False
    assert "Pinecone" in PineconeUpsert.description


def test_pinecone_query_protocol() -> None:
    assert PineconeQuery.name == "pinecone_query"
    assert PineconeQuery.is_concurrency_safe is False
    assert "Pinecone" in PineconeQuery.description


# ── Action validation ─────────────────────────────────────────────


def test_pinecone_upsert_wrong_action() -> None:
    out = PineconeUpsert().call(action="query")
    assert "error" in out
    assert "upsert" in out["error"]


def test_pinecone_query_wrong_action() -> None:
    out = PineconeQuery().call(action="upsert")
    assert "error" in out
    assert "query" in out["error"]


# ── Required kwargs ───────────────────────────────────────────────


def test_pinecone_upsert_missing_api_key() -> None:
    out = PineconeUpsert().call(action="upsert")
    assert "error" in out
    assert "api_key" in out["error"]


def test_pinecone_upsert_missing_index() -> None:
    out = PineconeUpsert().call(action="upsert", api_key="k")
    assert "error" in out
    assert "index" in out["error"]


def test_pinecone_upsert_missing_ids() -> None:
    out = PineconeUpsert().call(
        action="upsert", api_key="k", index="i", vectors=[[1.0]]
    )
    assert "error" in out
    assert "ids" in out["error"]


def test_pinecone_upsert_bad_vectors() -> None:
    out = PineconeUpsert().call(
        action="upsert",
        api_key="k",
        index="i",
        vectors="not-a-list",
        ids=["a"],
    )
    assert "error" in out
    assert "vectors" in out["error"]


def test_pinecone_upsert_dim_mismatch() -> None:
    out = PineconeUpsert().call(
        action="upsert",
        api_key="k",
        index="i",
        vectors=[[1.0, 2.0], [3.0]],
        ids=["a", "b"],
    )
    assert "error" in out
    assert "dimension" in out["error"]


def test_pinecone_upsert_bad_namespace() -> None:
    out = PineconeUpsert().call(
        action="upsert",
        api_key="k",
        index="i",
        vectors=[[1.0]],
        ids=["a"],
        namespace=123,
    )
    assert "error" in out
    assert "namespace" in out["error"]


# ── Query validation ──────────────────────────────────────────────


def test_pinecone_query_missing_vector() -> None:
    out = PineconeQuery().call(action="query", api_key="k", index="i")
    assert "error" in out
    assert "vector" in out["error"]


def test_pinecone_query_bad_top_k() -> None:
    out = PineconeQuery().call(
        action="query",
        api_key="k",
        index="i",
        vector=[0.1],
        top_k=9999,
    )
    assert "error" in out
    assert "MAX_TOP_K" in out["error"]


def test_pinecone_query_bad_filter_string() -> None:
    out = PineconeQuery().call(
        action="query",
        api_key="k",
        index="i",
        vector=[0.1],
        filter="unsafe",
    )
    assert "error" in out


# ── Happy-path dispatch (monkeypatched vendor) ───────────────────


class _FakeIndex:
    """Stand-in for pinecone Index. Captures upsert/query kwargs."""

    def __init__(self) -> None:
        self.upsert_calls: list[dict[str, Any]] = []
        self.query_calls: list[dict[str, Any]] = []

    def upsert(self, **kwargs: Any) -> dict[str, Any]:
        self.upsert_calls.append(kwargs)
        return {"upserted_count": len(kwargs["vectors"])}

    def query(self, **kwargs: Any) -> dict[str, Any]:
        self.query_calls.append(kwargs)
        return {
            "matches": [
                {"id": "a", "score": 0.9, "metadata": {"k": "v"}},
                {"id": "b", "score": 0.7, "metadata": {"k": "w"}},
            ]
        }


class _FakePinecone:
    def __init__(self, api_key: str = "") -> None:
        self.api_key = api_key
        self.index = _FakeIndex()

    def Index(self, name: str) -> _FakeIndex:  # noqa: N802 — SDK API
        return self.index


def test_pinecone_upsert_dispatch(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify dispatch reaches ``index.upsert(vectors=[{...}], namespace=)``.

    Patches ``pinecone.Pinecone`` at the vendor module level so the
    inner lazy import inside ``PineconeUpsert.call`` picks up our
    fake.
    """
    fake_mod = pytest.importorskip  # sentinel — avoid pytest warn on empty importorskip
    del fake_mod  # unused; we really just want to proceed if pytest exists

    import sys
    import types

    mod = types.ModuleType("pinecone")
    mod.Pinecone = _FakePinecone  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "pinecone", mod)

    out = PineconeUpsert().call(
        action="upsert",
        api_key="pk",
        index="my-index",
        vectors=[[0.1, 0.2], [0.3, 0.4]],
        ids=["id-1", "id-2"],
        metadata=[{"t": "a"}, {"t": "b"}],
        namespace="prod",
    )
    assert out == {"ok": True, "upserted": 2}


def test_pinecone_query_dispatch(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verify query dispatch reaches ``index.query(...)`` + returns
    the unified ``{"matches": ...}`` shape."""
    import sys
    import types

    mod = types.ModuleType("pinecone")
    mod.Pinecone = _FakePinecone  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "pinecone", mod)

    out = PineconeQuery().call(
        action="query",
        api_key="pk",
        index="my-index",
        vector=[0.1, 0.2],
        top_k=2,
        filter={"genre": {"$eq": "comedy"}},
        namespace="prod",
    )
    assert "matches" in out
    assert len(out["matches"]) == 2
    assert out["matches"][0]["id"] == "a"
    assert out["matches"][0]["score"] == 0.9
    assert out["matches"][0]["metadata"] == {"k": "v"}


def test_pinecone_missing_driver(monkeypatch: pytest.MonkeyPatch) -> None:
    """If ``pinecone`` isn't installed, surface a clean error."""
    import sys

    monkeypatch.setitem(sys.modules, "pinecone", None)
    out = PineconeUpsert().call(
        action="upsert",
        api_key="k",
        index="i",
        vectors=[[1.0]],
        ids=["a"],
    )
    assert "error" in out
    assert "pinecone" in out["error"].lower()
