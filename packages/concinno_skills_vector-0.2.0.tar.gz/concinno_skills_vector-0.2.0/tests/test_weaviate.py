"""Unit tests for concinno_skills_vector.weaviate_tool.

Weaviate v4 typed client is the vendor SDK. We monkeypatch the whole
``weaviate`` module + ``weaviate.classes.init`` + ``weaviate.classes.query``
so tests run without the SDK installed — same pattern as
test_pinecone.py.
"""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from concinno_skills_vector import WeaviateAdd, WeaviateQuery

# ── Protocol surface ─────────────────────────────────────────────


def test_weaviate_add_protocol() -> None:
    assert WeaviateAdd.name == "weaviate_add"
    assert WeaviateAdd.is_concurrency_safe is False
    assert "Weaviate" in WeaviateAdd.description


def test_weaviate_query_protocol() -> None:
    assert WeaviateQuery.name == "weaviate_query"
    assert WeaviateQuery.is_concurrency_safe is False


# ── Action validation ─────────────────────────────────────────────


def test_weaviate_add_wrong_action() -> None:
    out = WeaviateAdd().call(action="query")
    assert "error" in out
    assert "add" in out["error"]


def test_weaviate_query_wrong_action() -> None:
    out = WeaviateQuery().call(action="add")
    assert "error" in out


# ── Required kwargs ───────────────────────────────────────────────


def test_weaviate_add_missing_collection() -> None:
    out = WeaviateAdd().call(action="add")
    assert "error" in out
    assert "collection" in out["error"]


def test_weaviate_add_missing_ids() -> None:
    out = WeaviateAdd().call(
        action="add", collection="c", vectors=[[1.0]]
    )
    assert "error" in out
    assert "ids" in out["error"]


def test_weaviate_add_bad_vectors_len() -> None:
    out = WeaviateAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0, 2.0], [3.0]],
        ids=["a", "b"],
    )
    assert "error" in out
    assert "dimension" in out["error"]


def test_weaviate_add_bad_url_type(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``weaviate_url`` type-check runs inside ``_connect_weaviate``
    which needs the vendor SDK imported first; install a minimal
    stub before exercising the guard."""
    _install_weaviate_mock(monkeypatch)
    out = WeaviateAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0]],
        ids=["a"],
        weaviate_url=123,
    )
    assert "error" in out
    assert "weaviate_url" in out["error"]


# ── Query validation ──────────────────────────────────────────────


def test_weaviate_query_missing_vector() -> None:
    out = WeaviateQuery().call(action="query", collection="c")
    assert "error" in out
    assert "vector" in out["error"]


def test_weaviate_query_invalid_filter_operator_rejected(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """WeaviateQuery rejects unsupported dict filter operators with a
    clean error message — as of 0.2.0 valid MongoDB-style dicts are
    translated to Weaviate Filter DSL; only unsupported operators
    like ``$regex`` surface as ``{"error": "..."}``."""
    _install_weaviate_mock(monkeypatch)
    out = WeaviateQuery().call(
        action="query",
        collection="c",
        vector=[0.1],
        filter={"field": {"$regex": ".*"}},
    )
    assert "error" in out
    assert "$regex" in out["error"]


# ── Mocked vendor SDK — happy path ───────────────────────────────


class _FakeBatchCtx:
    def __init__(self) -> None:
        self.added: list[tuple[Any, ...]] = []

    def __enter__(self) -> _FakeBatchCtx:
        return self

    def __exit__(self, *_: Any) -> None:
        pass

    def add_object(
        self,
        properties: Any = None,
        vector: Any = None,
        uuid: Any = None,
    ) -> None:
        self.added.append((properties, vector, uuid))


class _FakeBatch:
    def __init__(self) -> None:
        self.ctx = _FakeBatchCtx()
        self.failed_objects: list[Any] = []

    def fixed_size(self, batch_size: int = 200) -> _FakeBatchCtx:  # noqa: ARG002
        return self.ctx


class _FakeMetadata:
    def __init__(self, distance: float) -> None:
        self.distance = distance


class _FakeObject:
    def __init__(self, uuid: str, properties: dict[str, Any], distance: float) -> None:
        self.uuid = uuid
        self.properties = properties
        self.metadata = _FakeMetadata(distance)


class _FakeQueryResp:
    def __init__(self, objects: list[_FakeObject]) -> None:
        self.objects = objects


class _FakeCollectionQuery:
    def near_vector(self, **kwargs: Any) -> _FakeQueryResp:
        assert "near_vector" in kwargs
        assert "limit" in kwargs
        return _FakeQueryResp(
            [
                _FakeObject(
                    "550e8400-e29b-41d4-a716-446655440000",
                    {"title": "Alpha"},
                    0.12,
                ),
                _FakeObject(
                    "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
                    {"title": "Beta"},
                    0.34,
                ),
            ]
        )


class _FakeCollection:
    def __init__(self) -> None:
        self.batch = _FakeBatch()
        self.query = _FakeCollectionQuery()


class _FakeCollections:
    def __init__(self) -> None:
        self._coll = _FakeCollection()

    def get(self, name: str) -> _FakeCollection:  # noqa: ARG002
        return self._coll


class _FakeClient:
    def __init__(self) -> None:
        self.collections = _FakeCollections()
        self.closed = False

    def close(self) -> None:
        self.closed = True


def _install_weaviate_mock(monkeypatch: pytest.MonkeyPatch) -> _FakeClient:
    """Install a full ``weaviate`` module stub in ``sys.modules``.

    Returns the fake client that will be handed out by
    ``connect_to_weaviate_cloud`` / ``connect_to_local`` so tests
    can inspect ``client.closed`` after the tool call.
    """
    fake_client = _FakeClient()

    class _Auth:
        @staticmethod
        def api_key(key: str) -> str:
            return f"auth:{key}"

    def _connect_cloud(**kwargs: Any) -> _FakeClient:  # noqa: ARG001
        return fake_client

    def _connect_local(**kwargs: Any) -> _FakeClient:  # noqa: ARG001
        return fake_client

    weaviate_mod = types.ModuleType("weaviate")
    weaviate_mod.connect_to_weaviate_cloud = _connect_cloud  # type: ignore[attr-defined]
    weaviate_mod.connect_to_local = _connect_local  # type: ignore[attr-defined]

    classes_mod = types.ModuleType("weaviate.classes")
    init_mod = types.ModuleType("weaviate.classes.init")
    init_mod.Auth = _Auth  # type: ignore[attr-defined]
    query_mod = types.ModuleType("weaviate.classes.query")

    class _MetadataQuery:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    class _Filter:
        """Minimal Filter stand-in. ``by_property``/``all_of``/``any_of``
        return sentinel objects so translate_filter can chain on them
        without crashing; unit tests for translation semantics live in
        test_weaviate_filter.py using MagicMock."""

        class _FieldHandle:
            def __init__(self, field: str) -> None:
                self.field = field

            def equal(self, v: Any) -> Any:
                return ("eq", self.field, v)

            def not_equal(self, v: Any) -> Any:
                return ("ne", self.field, v)

            def greater_than(self, v: Any) -> Any:
                return ("gt", self.field, v)

            def greater_or_equal(self, v: Any) -> Any:
                return ("gte", self.field, v)

            def less_than(self, v: Any) -> Any:
                return ("lt", self.field, v)

            def less_or_equal(self, v: Any) -> Any:
                return ("lte", self.field, v)

            def contains_any(self, v: Any) -> Any:
                return ("in", self.field, tuple(v))

        @staticmethod
        def by_property(name: str) -> Any:
            return _Filter._FieldHandle(name)

        @staticmethod
        def all_of(items: list[Any]) -> Any:
            return ("and", tuple(items))

        @staticmethod
        def any_of(items: list[Any]) -> Any:
            return ("or", tuple(items))

    query_mod.MetadataQuery = _MetadataQuery  # type: ignore[attr-defined]
    query_mod.Filter = _Filter  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "weaviate", weaviate_mod)
    monkeypatch.setitem(sys.modules, "weaviate.classes", classes_mod)
    monkeypatch.setitem(sys.modules, "weaviate.classes.init", init_mod)
    monkeypatch.setitem(sys.modules, "weaviate.classes.query", query_mod)
    return fake_client


def test_weaviate_add_dispatch_cloud(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Cloud path (weaviate_url + api_key) reaches batch.add_object."""
    fake_client = _install_weaviate_mock(monkeypatch)

    out = WeaviateAdd().call(
        action="add",
        collection="Article",
        vectors=[[0.1, 0.2], [0.3, 0.4]],
        ids=[
            "550e8400-e29b-41d4-a716-446655440000",
            "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
        ],
        metadata=[{"title": "A"}, {"title": "B"}],
        weaviate_url="https://cluster.example.net",
        weaviate_api_key="wk",
    )
    assert out == {"ok": True, "added": 2, "failed": 0}
    # Ensure client was closed after the call.
    assert fake_client.closed is True
    # The batch context captured both add_object calls.
    added = fake_client.collections._coll.batch.ctx.added  # noqa: SLF001
    assert len(added) == 2
    assert added[0][0] == {"title": "A"}
    assert added[0][1] == [0.1, 0.2]
    assert added[0][2] == "550e8400-e29b-41d4-a716-446655440000"


def test_weaviate_add_dispatch_local(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Local path (no weaviate_url) uses connect_to_local."""
    fake_client = _install_weaviate_mock(monkeypatch)

    out = WeaviateAdd().call(
        action="add",
        collection="Article",
        vectors=[[0.1]],
        ids=["550e8400-e29b-41d4-a716-446655440000"],
        metadata=[{"t": "x"}],
    )
    assert out["ok"] is True
    assert out["added"] == 1
    assert fake_client.closed is True


def test_weaviate_query_dispatch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """near_vector dispatch returns the unified ``{"matches": ...}``
    shape with id / score / metadata per object."""
    fake_client = _install_weaviate_mock(monkeypatch)

    out = WeaviateQuery().call(
        action="query",
        collection="Article",
        vector=[0.1, 0.2],
        top_k=2,
        weaviate_url="https://cluster.example.net",
        weaviate_api_key="wk",
    )
    assert "matches" in out
    assert len(out["matches"]) == 2
    assert out["matches"][0]["id"] == "550e8400-e29b-41d4-a716-446655440000"
    assert out["matches"][0]["score"] == 0.12
    assert out["matches"][0]["metadata"] == {"title": "Alpha"}
    assert fake_client.closed is True


def test_weaviate_missing_driver(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If ``weaviate`` isn't installed, surface a clean error."""
    monkeypatch.setitem(sys.modules, "weaviate", None)
    monkeypatch.setitem(sys.modules, "weaviate.classes", None)
    monkeypatch.setitem(sys.modules, "weaviate.classes.init", None)
    out = WeaviateAdd().call(
        action="add",
        collection="c",
        vectors=[[1.0]],
        ids=["550e8400-e29b-41d4-a716-446655440000"],
    )
    assert "error" in out
    assert "weaviate" in out["error"].lower()
