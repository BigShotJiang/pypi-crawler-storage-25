from typing import Dict, Optional

import numpy as np

from PAOFLOW.DataController import DataController
from PAOFLOW.transport.io.input_parameters import ConductorData
from PAOFLOW.transport.utils.converters import (
    cartesian_to_crystal,
)


def parse_header(data_controller: DataController) -> Dict:
    _, attr = data_controller.data_dicts()
    return {
        'nbnds': attr['nbnds'],
        'nkpnts': attr['nkpnts'],
        'nspin': attr['nspin'],
        'nawf': attr['nawf'],
        'nelec': attr['nelec'],
        'efermi': attr['Efermi'],
        'energy_units': attr.get('energy_units', 'eV'),
    }


def parse_kpoints(data_controller: DataController) -> Dict:
    arry, attr = data_controller.data_dicts()

    kpts = arry['kpnts'].T

    wk = arry['kpnts_wght']
    wk = wk / np.sum(wk)

    alat = float(attr['alat'])

    bvec = arry['b_vectors'] * (2.0 * np.pi / alat)

    vkpts_cartesian = kpts * (2.0 * np.pi / alat)  # bohr^-1
    vkpts_crystal = cartesian_to_crystal(vkpts_cartesian, bvec)

    return {
        'kpts': kpts,
        'wk': wk,
        'vkpts_cartesian': vkpts_cartesian,
        'vkpts_crystal': vkpts_crystal,
    }


def parse_eigenvalues(data_controller: DataController) -> np.ndarray:
    arry, _ = data_controller.data_dicts()
    eigvals = arry['my_eigsmat']
    return eigvals


def parse_projections(data_controller: DataController) -> np.ndarray:
    arry, _ = data_controller.data_dicts()
    proj = arry['U'].swapaxes(0, 1)

    return proj


def parse_overlaps(
    yaml_data: ConductorData, data_controller: DataController
) -> Optional[np.ndarray]:
    do_overlap_transformation = yaml_data.atomic_proj.do_overlap_transformation
    if not do_overlap_transformation:
        return None
    else:
        arry, _ = data_controller.data_dicts()
        overlap = arry['Sks']
        return overlap
