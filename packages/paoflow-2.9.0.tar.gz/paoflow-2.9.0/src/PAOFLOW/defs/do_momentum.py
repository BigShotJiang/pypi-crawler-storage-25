def do_momentum(data_controller):
    import numpy as np

    from .perturb_split import perturb_split

    arry, attr = data_controller.data_dicts()

    nktot, _, nawf, nawf, nspin = arry['dHksp'].shape

    arry['pksp'] = np.zeros_like(arry['dHksp'])

    for ispin in range(nspin):
        for ik in range(nktot):
            for l in range(3):
                arry['pksp'][ik, l, :, :, ispin], _ = perturb_split(
                    arry['dHksp'][ik, l, :, :, ispin],
                    arry['dHksp'][ik, l, :, :, ispin],
                    arry['v_k'][ik, :, :, ispin],
                    arry['degen'][ispin][ik],
                )
                #  impose hermiticity
                arry['pksp'][ik, l, :, :, ispin] = (
                    arry['pksp'][ik, l, :, :, ispin] + np.conj(arry['pksp'][ik, l, :, :, ispin].T)
                ) / 2.0
            #  arry['pksp'][ik,l,attr['bnd']:,attr['bnd']:,ispin] = 0.0

    # for ispin in range(nspin):
    #   for ik in range(nktot):
    #     for l in range(3):
    #        arry['pksp'][ik,l,:,:,ispin] = arry['v_k'][ik,:,:,ispin]@arry['dHksp'][ik,l,:,:,ispin]@ \
    #                                       np.conj(arry['v_k'][ik,:,:,ispin]).T
