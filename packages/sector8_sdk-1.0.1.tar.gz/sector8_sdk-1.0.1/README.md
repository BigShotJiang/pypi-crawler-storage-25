﻿# Sector8 SDK

[![PyPI version](https://badge.fury.io/py/sector8-sdk.svg)](https://badge.fury.io/py/sector8-sdk)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Python SDK for sending AI telemetry and security events to Sector8.

Sector8 is an execution-boundary security platform for AI systems. The production Guard Module is live at `https://sdkapi.sector8.ai`.

## What this package is for

Use `sector8-sdk` when you want to:
- send telemetry for LLM calls to Sector8
- emit threat alerts and incident logs from your application
- install the Sector8 MCP guard helper into a local project

This package is intentionally simple. The paid wedge is the live guard and decision service, not a large client-side framework.

## Installation

```bash
pip install sector8-sdk
```

Optional extras:

```bash
pip install sector8-sdk[openai]
pip install sector8-sdk[anthropic]
pip install sector8-sdk[google]
pip install sector8-sdk[all]
```

## Quick start

Set your credentials:

```bash
export SECTOR8_API_KEY="your-api-key"
export SECTOR8_CLIENT_ID="your-client-id"
export SECTOR8_BASE_URL="https://sdkapi.sector8.ai"
```

Send telemetry:

```python
import sector8

client = sector8.setup(
    api_key="your-api-key",
    client_id="your-client-id",
)

client.log_llm_call(
    provider="openai",
    model="gpt-4o",
    tokens=150,
    cost=0.003,
    latency_ms=800,
    prompt="Summarize this contract.",
    completion="Here is the summary...",
)
```

You can also call the async methods directly:

```python
import asyncio
import sector8


async def main() -> None:
    client = sector8.setup(api_key="your-api-key", client_id="your-client-id")
    await client.save_telemetry(
        provider="openai",
        model="gpt-4o",
        prompt="Classify this email",
        completion="Likely phishing",
        tokens_used=240,
        latency_ms=620,
        cost=0.0048,
        success=True,
        metadata={"route": "inbound-mail"},
    )
    await client.close()


asyncio.run(main())
```

## Threat alerts and incidents

```python
import sector8

client = sector8.setup(api_key="your-api-key", client_id="your-client-id")
client.alert_threat("prompt_injection", severity="High", description="Jailbreak attempt detected")
client.log_incident("Sensitive file request denied", severity="high", classification="policy_deny")
```

## MCP guard helper

This package also ships a small CLI for installing the Sector8 guard MCP entry into a project:

```bash
sector8-guard install
sector8-guard version
```

The installer writes `.claude/settings.json` entries that point at the repo-local MCP stdio server and pass through:
- `SECTOR8_API_KEY`
- `SECTOR8_CLIENT_ID`

## Runtime endpoints used by this SDK

- Production API: `https://sdkapi.sector8.ai`
- Telemetry ingest: `POST /api/v1/telemetry`
- Threat alerts: `POST /api/v1/threat-alerts`
- Incident logs: `POST /api/v1/incident-logs`

## Secure host configuration

The SDK trusts only `https://*.sector8.ai` by default.

- plain HTTP is rejected by default
- arbitrary non-Sector8 hosts are rejected by default
- local or mock testing requires explicit opt-in

```python
client = sector8.setup(
    api_key="your-api-key",
    base_url="http://localhost:9876",
    allow_unsafe_base_url=True,
)
```

Use `allow_unsafe_base_url=True` only for deliberate local or test use.

## Links

- Homepage: `https://sector8.ai`
- Production API: `https://sdkapi.sector8.ai`
- Dashboard: `https://app.sector8.ai`
- Repository: `https://github.com/advicebytes/Sector8-MVP`

## Development notes

This package targets Python 3.8+ and is published as `sector8-sdk` on PyPI.
