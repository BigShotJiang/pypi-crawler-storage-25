"""
Test suite for Sector8 Simple Client
"""

import pytest
import os
from unittest.mock import patch, MagicMock
from sector8.simple_client import Sector8SimpleClient


class TestSector8SimpleClient:
    """Test cases for Sector8SimpleClient"""

    def test_client_initialization_with_api_key(self):
        """Test client initialization with API key"""
        client = Sector8SimpleClient(api_key="test-key", client_id="test-client")
        assert client.api_key == "test-key"
        assert client.client_id == "test-client"

    def test_client_initialization_from_env(self):
        """Test client initialization from environment variables"""
        # Simple client requires API key as parameter, not from env
        client = Sector8SimpleClient(api_key="env-key-123456789", client_id="env-client")
        assert client.api_key == "env-key-123456789"
        assert client.client_id == "env-client"

    def test_client_initialization_missing_api_key(self):
        """Test client initialization fails without API key"""
        from sector8.errors import ConfigurationError
        with pytest.raises(ConfigurationError):
            Sector8SimpleClient(api_key="")

    @patch('sector8.simple_client.aiohttp.ClientSession')
    def test_log_llm_call_success(self, mock_session_class):
        """Test successful LLM call logging"""
        # Mock the session and its methods
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        
        client = Sector8SimpleClient(api_key="test-key")
        
        # Call method and verify no exception (method returns None)
        result = client.log_llm_call("openai", "gpt-4", tokens=100, cost=0.002)
        assert result is None  # Method doesn't return anything

    @patch('sector8.simple_client.aiohttp.ClientSession')
    def test_alert_threat_success(self, mock_session_class):
        """Test successful threat alert"""
        # Mock the session and its methods
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        
        client = Sector8SimpleClient(api_key="test-key")
        result = client.alert_threat("prompt_injection", severity="high")
        
        assert result is None  # Method doesn't return anything

    @patch('sector8.simple_client.aiohttp.ClientSession')
    def test_log_incident_success(self, mock_session_class):
        """Test successful incident logging"""
        # Mock the session and its methods
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        
        client = Sector8SimpleClient(api_key="test-key")
        result = client.log_incident("Rate limit exceeded", severity="medium")
        
        assert result is None  # Method doesn't return anything

    def test_api_key_validation_in_constructor(self):
        """Test API key validation during initialization"""
        from sector8.errors import ConfigurationError
        
        # Valid API key formats should work
        client1 = Sector8SimpleClient(api_key="sk-test123")
        assert client1.api_key == "sk-test123"
        
        client2 = Sector8SimpleClient(api_key="test-key-123456789")
        assert client2.api_key == "test-key-123456789"
        
        # Invalid API key formats should raise error
        with pytest.raises(ConfigurationError):
            Sector8SimpleClient(api_key="short")
        
        with pytest.raises(ConfigurationError):
            Sector8SimpleClient(api_key="")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])