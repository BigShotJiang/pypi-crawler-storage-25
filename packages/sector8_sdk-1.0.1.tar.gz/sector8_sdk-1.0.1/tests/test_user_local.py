#!/usr/bin/env python3
"""
Test SDK against local backend
"""
import asyncio
import sys
import os

# Add the SDK to path for testing
sys.path.insert(0, r'C:\Sector 8\sector8-sdk\src')

from sector8 import setup

async def test_local_api():
    """Test SDK against local backend"""
    print("Testing SDK against local backend (localhost:8000)...")
    
    try:
        # Use local backend
        client = setup(
            api_key="sk-test-key-for-demo-purposes-12345",
            base_url="http://localhost:8000",
            allow_unsafe_base_url=True,
        )
        print("SUCCESS: SDK initialized with local backend")
        
        # Test telemetry endpoint
        result = await client.save_telemetry(
            provider="openai",
            model="gpt-4",
            prompt="Hello, how are you?",
            completion="I'm doing well, thank you!",
            tokens_used=25,
            latency_ms=450,
            cost=0.001
        )
        print("SUCCESS: Telemetry posted:", result)
        
        await client.close()
        print("SUCCESS: Test completed")
        
    except Exception as e:
        print(f"API RESPONSE: {type(e).__name__}: {e}")
        print("(Expected if backend is not running)")

if __name__ == "__main__":
    asyncio.run(test_local_api())
