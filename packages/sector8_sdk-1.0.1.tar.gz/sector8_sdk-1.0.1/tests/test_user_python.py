#!/usr/bin/env python3
"""
Test Python SDK from user perspective
"""
import asyncio
import sys
import os

# Add the SDK to path for testing
sys.path.insert(0, r'C:\Sector 8\sector8-sdk\src')

from sector8 import setup

async def test_python_sdk():
    """Test Python SDK like a real user would"""
    print("Python Testing Python SDK from user perspective...")
    
    # Test API key validation first
    try:
        # This should fail with invalid key
        client = setup(api_key="invalid-key")
        print("ERROR: API key validation not working - accepted invalid key")
    except Exception as e:
        print("SUCCESS: API key validation working:", str(e))
    
    # Test with valid format (but potentially fake key for testing)
    try:
        client = setup(api_key="sk-test-key-for-demo-purposes-12345")
        print("SUCCESS: SDK initialization successful")
        
        # Test telemetry tracking
        result = await client.save_telemetry(
            provider="openai",
            model="gpt-4",
            prompt="Hello, how are you?",
            completion="I'm doing well, thank you!",
            tokens_used=25,
            latency_ms=450,
            cost=0.001
        )
        print("SUCCESS: Telemetry call completed:", result)
        
        # Test threat alert
        alert_result = await client.save_threat_alert(
            threat_type="prompt_injection",
            severity="Medium",
            status="detected",
            description="Test threat detection"
        )
        print("SUCCESS: Threat alert call completed:", alert_result)
        
        await client.close()
        print("SUCCESS: Client cleanup successful")
        
    except Exception as e:
        print(f"API RESPONSE: {type(e).__name__}: {e}")
        print("(This is expected if using test API key)")

if __name__ == "__main__":
    asyncio.run(test_python_sdk())