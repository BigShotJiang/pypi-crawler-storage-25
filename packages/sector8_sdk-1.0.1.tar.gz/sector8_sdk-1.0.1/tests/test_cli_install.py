import json
import platform
from pathlib import Path

import pytest

from sector8.cli import build_entry, cmd_install


def _settings_path(root: Path) -> Path:
    return root / ".claude" / "settings.json"


def test_install_creates_settings(tmp_path, monkeypatch):
    (tmp_path / ".git").mkdir()
    monkeypatch.chdir(tmp_path)

    result = cmd_install()

    assert result == 0
    settings = json.loads(_settings_path(tmp_path).read_text(encoding="utf-8"))
    assert "sector8-guard" in settings["mcpServers"]
    entry = settings["mcpServers"]["sector8-guard"]
    assert "SECTOR8_API_KEY" in entry["env"]
    if platform.system() == "Windows" and (tmp_path / "scripts" / "run_sector8_guard_mcp.cmd").exists():
        assert entry["args"] == []
    else:
        assert entry["command"] == "python"


def test_install_preserves_existing_keys(tmp_path, monkeypatch):
    (tmp_path / ".git").mkdir()
    (tmp_path / ".claude").mkdir()
    existing = {"mcpServers": {"other-server": {"command": "foo"}}, "theme": "dark"}
    _settings_path(tmp_path).write_text(json.dumps(existing), encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    result = cmd_install()

    assert result == 0
    settings = json.loads(_settings_path(tmp_path).read_text(encoding="utf-8"))
    assert settings["theme"] == "dark"
    assert "other-server" in settings["mcpServers"]
    assert "sector8-guard" in settings["mcpServers"]


def test_install_conflict_overwrite(tmp_path, monkeypatch):
    (tmp_path / ".git").mkdir()
    (tmp_path / ".claude").mkdir()
    original = {
        "mcpServers": {
            "sector8-guard": {"command": "old-command", "args": []},
        }
    }
    _settings_path(tmp_path).write_text(json.dumps(original), encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("builtins.input", lambda prompt="": "y")

    result = cmd_install()

    assert result == 0
    settings = json.loads(_settings_path(tmp_path).read_text(encoding="utf-8"))
    assert settings["mcpServers"]["sector8-guard"] != original["mcpServers"]["sector8-guard"]


def test_install_conflict_abort(tmp_path, monkeypatch):
    (tmp_path / ".git").mkdir()
    (tmp_path / ".claude").mkdir()
    original = {
        "mcpServers": {
            "sector8-guard": {"command": "old-command", "args": []},
        }
    }
    _settings_path(tmp_path).write_text(json.dumps(original), encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("builtins.input", lambda prompt="": "n")

    result = cmd_install()

    assert result == 0
    settings = json.loads(_settings_path(tmp_path).read_text(encoding="utf-8"))
    assert settings == original


def test_build_entry_prefers_windows_wrapper(monkeypatch, tmp_path):
    monkeypatch.setattr("sector8.cli.platform.system", lambda: "Windows")
    (tmp_path / "scripts").mkdir()
    (tmp_path / "scripts" / "run_sector8_guard_mcp.cmd").write_text("@echo off\n", encoding="utf-8")

    entry = build_entry(tmp_path)

    assert entry["command"] == "scripts\\run_sector8_guard_mcp.cmd"
    assert entry["args"] == []
