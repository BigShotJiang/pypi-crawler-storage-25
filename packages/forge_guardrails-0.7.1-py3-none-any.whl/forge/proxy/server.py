"""Raw asyncio HTTP server for the proxy.

No framework dependencies — uses asyncio.start_server directly.
Handles routing, request queuing (single-GPU serialization), health
checks, SSE streaming, and client disconnect detection.
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from typing import Any

from forge.clients.base import LLMClient
from forge.context.manager import ContextManager
from forge.proxy.handler import handle_chat_completions

logger = logging.getLogger("forge.proxy")

# Maximum request body size (16 MB)
_MAX_BODY = 16 * 1024 * 1024


@dataclass
class _QueueItem:
    """A request waiting to be processed by the inference worker."""

    body: dict[str, Any]
    protocol: str = "openai"
    future: asyncio.Future = field(default_factory=lambda: asyncio.get_event_loop().create_future())
    cancelled: bool = False


class HTTPServer:
    """Raw asyncio HTTP server with OpenAI-compatible routing."""

    def __init__(
        self,
        client: LLMClient,
        context_manager: ContextManager,
        host: str = "127.0.0.1",
        port: int = 8081,
        serialize_requests: bool = True,
        max_retries: int = 3,
        rescue_enabled: bool = True,
    ) -> None:
        self._client = client
        self._context_manager = context_manager
        self._host = host
        self._port = port
        self._max_retries = max_retries
        self._rescue_enabled = rescue_enabled
        self._server: asyncio.Server | None = None
        self._serialize = serialize_requests
        self._queue: asyncio.Queue[_QueueItem] = asyncio.Queue()
        self._worker_task: asyncio.Task | None = None

    async def start(self) -> None:
        """Start listening for connections."""
        if self._serialize:
            self._worker_task = asyncio.create_task(self._inference_worker())
        self._server = await asyncio.start_server(
            self._handle_connection, self._host, self._port,
        )
        logger.info("Proxy listening on %s:%d", self._host, self._port)

    async def stop(self) -> None:
        """Stop the server."""
        if self._worker_task is not None:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
            self._worker_task = None
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None

    async def _inference_worker(self) -> None:
        """Single worker that pulls requests off the queue and processes them.

        Ensures only one inference runs at a time (single-GPU constraint).
        """
        while True:
            item = await self._queue.get()
            try:
                if item.cancelled or item.future.cancelled():
                    logger.info("   Skipping cancelled request")
                    continue
                result = await self._run_handler(item.body, item.protocol)
                if not item.future.done():
                    item.future.set_result(result)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if not item.future.done():
                    item.future.set_result(exc)
            finally:
                self._queue.task_done()

    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Handle a single HTTP connection."""
        try:
            # Read request line
            request_line = await asyncio.wait_for(
                reader.readline(), timeout=30.0,
            )
            if not request_line:
                return

            request_str = request_line.decode("utf-8", errors="replace").strip()
            parts = request_str.split(" ", 2)
            if len(parts) < 2:
                await self._send_error(writer, 400, "Bad request")
                return

            method, raw_path = parts[0], parts[1]
            logger.info(">> %s %s", method, raw_path)
            # Strip the query string before routing. Real clients append
            # query params (e.g. Claude Code POSTs /v1/messages?beta=true);
            # exact-matching the raw target would 404 every such request.
            path = raw_path.split("?", 1)[0]

            # Read headers
            headers = await self._read_headers(reader)
            content_length = int(headers.get("content-length", "0"))

            # Read body
            body_bytes = b""
            if content_length > 0:
                if content_length > _MAX_BODY:
                    await self._send_error(writer, 413, "Request too large")
                    return
                body_bytes = await asyncio.wait_for(
                    reader.readexactly(content_length), timeout=60.0,
                )

            # Route
            if method == "GET" and path == "/health":
                await self._handle_health(writer)
            elif method == "GET" and path == "/v1/models":
                await self._handle_models(writer)
            elif method == "POST" and path == "/v1/chat/completions":
                await self._handle_completions(writer, body_bytes, protocol="openai")
            elif method == "POST" and path == "/v1/messages":
                await self._handle_completions(writer, body_bytes, protocol="anthropic")
            elif method == "OPTIONS":
                await self._send_cors_preflight(writer)
            else:
                await self._send_error(writer, 404, "Not found")

        except (asyncio.TimeoutError, asyncio.IncompleteReadError, ConnectionError):
            pass
        except Exception:
            logger.exception("Unhandled error in connection handler")
            try:
                await self._send_error(writer, 500, "Internal server error")
            except Exception:
                pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _read_headers(self, reader: asyncio.StreamReader) -> dict[str, str]:
        """Read HTTP headers until blank line."""
        headers: dict[str, str] = {}
        while True:
            line = await asyncio.wait_for(reader.readline(), timeout=30.0)
            decoded = line.decode("utf-8", errors="replace").strip()
            if not decoded:
                break
            if ":" in decoded:
                key, value = decoded.split(":", 1)
                headers[key.strip().lower()] = value.strip()
        return headers

    async def _handle_health(self, writer: asyncio.StreamWriter) -> None:
        """GET /health — returns OK."""
        body = json.dumps({"status": "ok"})
        await self._send_json(writer, 200, body)

    async def _handle_models(self, writer: asyncio.StreamWriter) -> None:
        """GET /v1/models — returns a minimal model list."""
        body = json.dumps({
            "object": "list",
            "data": [{"id": "forge", "object": "model"}],
        })
        await self._send_json(writer, 200, body)

    async def _handle_completions(
        self,
        writer: asyncio.StreamWriter,
        body_bytes: bytes,
        protocol: str = "openai",
    ) -> None:
        """POST /v1/chat/completions (or /v1/messages) — the main proxy endpoint."""
        try:
            body = json.loads(body_bytes)
        except json.JSONDecodeError:
            await self._send_error(writer, 400, "Invalid JSON")
            return

        is_stream = body.get("stream", False)
        msg_count = len(body.get("messages", []))
        tool_count = len(body.get("tools", []))
        logger.info(
            "   proto=%s stream=%s messages=%d tools=%d model=%s",
            protocol, is_stream, msg_count, tool_count, body.get("model", "?"),
        )

        if self._serialize:
            # Queue the request and wait for the worker to process it
            item = _QueueItem(body=body, protocol=protocol)
            queue_depth = self._queue.qsize()
            if queue_depth > 0:
                logger.info("   Queued (depth=%d)", queue_depth + 1)

            # For streaming requests, send SSE headers immediately so the
            # client knows we're alive while waiting in the queue
            if is_stream:
                await self._send_sse_header(writer)

            self._queue.put_nowait(item)

            # Wait for result, monitoring for client disconnect
            result = await self._await_with_disconnect(item, writer)
        else:
            if is_stream:
                await self._send_sse_header(writer)
            result = await self._run_handler(body, protocol)

        if result is None:
            # Client disconnected
            logger.info("<< Client disconnected, discarding result")
            return

        if isinstance(result, Exception):
            error_msg = str(result)
            logger.info("<< ERROR: %s", error_msg[:120])
            if is_stream:
                await self._send_sse_body(writer, [{"error": error_msg}], protocol=protocol)
            else:
                await self._send_error(writer, 502, error_msg)
            return

        if is_stream:
            logger.info("<< SSE %d events", len(result))
            await self._send_sse_body(writer, result, protocol=protocol)
        else:
            logger.info("<< JSON 200")
            await self._send_json(writer, 200, json.dumps(result))

    async def _await_with_disconnect(
        self,
        item: _QueueItem,
        writer: asyncio.StreamWriter,
    ) -> dict[str, Any] | list[dict[str, Any]] | Exception | None:
        """Wait for a queued item's result, checking for client disconnect.

        Returns None if the client disconnected.
        """
        while not item.future.done():
            if writer.is_closing():
                item.cancelled = True
                logger.info("   Client disconnected, cancelling queued request")
                return None
            try:
                await asyncio.wait_for(
                    asyncio.shield(item.future), timeout=1.0,
                )
            except asyncio.TimeoutError:
                continue
        return item.future.result()

    async def _run_handler(
        self, body: dict[str, Any], protocol: str = "openai",
    ) -> dict[str, Any] | list[dict[str, Any]] | Exception:
        """Run the handler, catching errors."""
        try:
            return await handle_chat_completions(
                body=body,
                client=self._client,
                context_manager=self._context_manager,
                max_retries=self._max_retries,
                rescue_enabled=self._rescue_enabled,
                protocol=protocol,
            )
        except Exception as exc:
            logger.exception("Handler error")
            return exc

    async def _send_json(
        self, writer: asyncio.StreamWriter, status: int, body: str,
    ) -> None:
        """Send a JSON HTTP response."""
        response = (
            f"HTTP/1.1 {status} {_status_text(status)}\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(body.encode())}\r\n"
            f"Connection: close\r\n"
            f"Access-Control-Allow-Origin: *\r\n"
            f"\r\n"
            f"{body}"
        )
        writer.write(response.encode())
        await writer.drain()

    async def _send_sse_header(self, writer: asyncio.StreamWriter) -> None:
        """Send SSE response headers immediately (before body is ready)."""
        header = (
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: text/event-stream\r\n"
            "Cache-Control: no-cache\r\n"
            "Transfer-Encoding: chunked\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "Connection: keep-alive\r\n"
            "\r\n"
        )
        writer.write(header.encode())
        await writer.drain()

    async def _send_sse_body(
        self,
        writer: asyncio.StreamWriter,
        events: list[dict[str, Any]],
        protocol: str = "openai",
    ) -> None:
        """Send SSE event data and terminator. Headers must already be sent.

        OpenAI wire format: ``data: {json}\\n\\n`` per event, terminated by
        ``data: [DONE]\\n\\n``.

        Anthropic wire format: ``event: <type>\\ndata: {json}\\n\\n`` per
        event (type read from the event's top-level ``type`` field). No
        ``[DONE]`` terminator — the ``message_stop`` event ends the stream.
        """
        for event in events:
            if writer.is_closing():
                return
            if protocol == "anthropic":
                event_type = event.get("type", "")
                payload = f"event: {event_type}\ndata: {json.dumps(event)}\n\n".encode()
            else:
                payload = f"data: {json.dumps(event)}\n\n".encode()
            writer.write(f"{len(payload):x}\r\n".encode() + payload + b"\r\n")
            await writer.drain()

        if protocol == "openai":
            done = b"data: [DONE]\n\n"
            writer.write(f"{len(done):x}\r\n".encode() + done + b"\r\n")

        # Terminating zero-length chunk
        writer.write(b"0\r\n\r\n")
        await writer.drain()
        logger.info("<< SSE complete (%s)", protocol)

    async def _send_error(
        self, writer: asyncio.StreamWriter, status: int, message: str,
    ) -> None:
        """Send an error JSON response."""
        body = json.dumps({"error": {"message": message, "type": "proxy_error"}})
        await self._send_json(writer, status, body)

    async def _send_cors_preflight(self, writer: asyncio.StreamWriter) -> None:
        """Handle CORS preflight."""
        response = (
            "HTTP/1.1 204 No Content\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
            "Access-Control-Allow-Headers: Content-Type, Authorization\r\n"
            "Connection: close\r\n"
            "\r\n"
        )
        writer.write(response.encode())
        await writer.drain()


def _status_text(code: int) -> str:
    """HTTP status code to text."""
    return {
        200: "OK",
        204: "No Content",
        400: "Bad Request",
        404: "Not Found",
        413: "Payload Too Large",
        500: "Internal Server Error",
        502: "Bad Gateway",
    }.get(code, "Error")
