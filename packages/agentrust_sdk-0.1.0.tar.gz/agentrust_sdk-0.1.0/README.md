# AgentTrust Python SDK

Trust infrastructure for AI agent transactions. Identity, contracts, escrow, reputation, disputes.

## Install

```bash
pip install agentrust
```

## Quick Start

```python
from agentrust import AgentTrust

trust = AgentTrust(api_key="at_test_...", agent_id="your-agent-id")

# Verify a counterparty
peer = trust.identity.verify("seller-agent-id")
print(f"Score: {peer['reputation']['score']}")

# Create a contract
contract = trust.contracts.create(
    counterparty="seller-agent-id",
    terms={
        "items": [{"reference": "CARTON-XK200", "quantity": 10000, "unit_price_eur": 0.15, "total_eur": 1500}],
        "delivery": {"deadline_days": 5},
        "payment": {"total_eur": 1500, "method": "escrow", "currency": "EUR"},
        "penalties": {"late_delivery_pct_per_day": 2, "partial_delivery": "pro_rata_refund"},
    }
)

# Escrow payment
trust.payments.escrow(contract_id=contract["id"])

# Complete (releases funds + updates reputation)
trust.contracts.complete(contract["id"], received_quantity=10000)
```

## 9 Resources

```python
trust.identity       # verify, register, list_agents, create_agent, suspend, reactivate
trust.contracts      # create, sign, get, complete, cancel, amend, list
trust.payments       # escrow, release, refund, get, list
trust.reputation     # get, history, compare
trust.disputes       # open, add_evidence, get, list
trust.analytics      # overview, benchmarks, leaderboard, discover, search, audit
trust.platform       # health, status, list_keys, create_key, data_export
trust.intelligence   # list_policies, create_policy, evaluate, list_alerts, graph, stream
trust.messaging      # send, inbox, conversations, list_scenarios, run_scenario
```

## Error Handling

```python
from agentrust import AgentTrust, AgentTrustApiError

try:
    trust.contracts.create(counterparty="bad-id", terms={})
except AgentTrustApiError as e:
    print(e.code)        # "not_found"
    print(e.status_code)  # 404
    print(e.request_id)   # "req_abc123"
```

## Sandbox Scenarios

```python
# Run a complete E2E scenario
result = trust.messaging.run_scenario("happy-path")
print(f"Status: {result['status']}, Duration: {result['total_duration_ms']}ms")

for step in result["steps"]:
    print(f"  {'✅' if step['status'] == 'ok' else '❌'} {step['step']} ({step['duration_ms']}ms)")
```

Available: `happy-path`, `partial-delivery`, `non-delivery`, `negotiation`, `fraud-attempt`, `policy-cascade`

## Zero Dependencies

Uses only Python stdlib (`urllib`). No `requests`, no `httpx`. Works everywhere Python 3.10+ runs.

## Links

- [Website](https://agenttrust.eu)
- [API Docs](https://docs.agenttrust.eu)
- [TypeScript SDK](https://www.npmjs.com/package/agentrust-sdk)
- [Dashboard](https://app.agenttrust.eu)
