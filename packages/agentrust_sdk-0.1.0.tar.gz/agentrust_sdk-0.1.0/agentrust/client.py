"""AgentTrust client — the main entry point for the SDK."""

from __future__ import annotations

from .http import HttpClient
from .resources import (, ProtocolsResource, VerificationResource
    DeliverablesResource,
    EcosystemResource,
    RfqResource,
    IdentityResource,
    ContractsResource,
    PaymentsResource,
    ReputationResource,
    DisputesResource,
    AnalyticsResource,
    PlatformResource,
    IntelligenceResource,
    MessagingResource,
)

DEFAULT_BASE_URL = "https://ksxkgxdwyppngyvawyuq.supabase.co/functions/v1"


class AgentTrust:
    """AgentTrust client — trust infrastructure for AI agent transactions.

    Usage::

        from agentrust import AgentTrust

        trust = AgentTrust(api_key="at_test_...", agent_id="your-agent-id")

        # Verify a counterparty
        peer = trust.identity.verify("seller-agent-id")

        # Create a contract
        contract = trust.contracts.create(
            counterparty="seller-agent-id",
            terms={
                "items": [{"reference": "ITEM-001", "quantity": 100, "unit_price_eur": 10, "total_eur": 1000}],
                "delivery": {"deadline_days": 5},
                "payment": {"total_eur": 1000, "method": "escrow", "currency": "EUR"},
            }
        )

        # Escrow payment
        trust.payments.escrow(contract_id=contract["id"])

        # Complete (releases funds + updates reputation)
        trust.contracts.complete(contract["id"], received_quantity=100)
    """

    def __init__(
        self,
        api_key: str,
        agent_id: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        if not agent_id:
            raise ValueError("agent_id is required")

        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            agent_id=agent_id,
            timeout=timeout,
            max_retries=max_retries,
        )

        self.identity = IdentityResource(self._http)
        self.contracts = ContractsResource(self._http)
        self.payments = PaymentsResource(self._http)
        self.reputation = ReputationResource(self._http)
        self.disputes = DisputesResource(self._http)
        self.analytics = AnalyticsResource(self._http)
        self.platform = PlatformResource(self._http)
        self.intelligence = IntelligenceResource(self._http)
        self.messaging = MessagingResource(self._http)
        self.deliverables = DeliverablesResource(self._http)
        self.rfq = RfqResource(self._http)
        self.ecosystem = EcosystemResource(self._http)
        self.protocols_api = ProtocolsResource(self._http)
        self.verification = VerificationResource(self._http)

    def __repr__(self) -> str:
        return f"AgentTrust(base_url={self._http.base_url!r})"
