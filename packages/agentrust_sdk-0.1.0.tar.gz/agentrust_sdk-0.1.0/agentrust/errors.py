"""AgentTrust error classes."""


class AgentTrustError(Exception):
    """Base error for AgentTrust SDK."""
    pass


class AgentTrustApiError(AgentTrustError):
    """Raised when the API returns an error response (4xx/5xx)."""

    def __init__(self, message: str, code: str, status_code: int, request_id: str | None = None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.request_id = request_id

    def __repr__(self) -> str:
        return f"AgentTrustApiError(code={self.code!r}, status={self.status_code}, message={str(self)!r})"


class AgentTrustNetworkError(AgentTrustError):
    """Raised on network/connection failures."""

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message)
        self.cause = cause
