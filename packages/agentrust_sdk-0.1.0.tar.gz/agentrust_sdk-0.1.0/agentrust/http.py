"""Internal HTTP client with retry logic."""

from __future__ import annotations

import time
import json
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from .errors import AgentTrustApiError, AgentTrustNetworkError
from .version import __version__


def _snake_to_camel(obj: Any) -> Any:
    """Convert snake_case keys to camelCase (for SDK → API compatibility)."""
    if isinstance(obj, dict):
        return {k: _snake_to_camel(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_snake_to_camel(v) for v in obj]
    return obj


class HttpClient:
    """Zero-dependency HTTP client using urllib."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        agent_id: str,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.agent_id = agent_id
        self.timeout = timeout
        self.max_retries = max_retries

    def _headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "X-Api-Key": self.api_key,
            "X-Agent-Id": self.agent_id,
            "User-Agent": f"agentrust-python/{__version__}",
        }

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{self.base_url}{path}"
        if params:
            qs = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
            if qs:
                url = f"{url}?{qs}"
        return self._request("GET", url)

    def post(self, path: str, body: Any = None) -> Any:
        url = f"{self.base_url}{path}"
        return self._request("POST", url, body)

    def patch(self, path: str, body: Any = None) -> Any:
        url = f"{self.base_url}{path}"
        return self._request("PATCH", url, body)

    def delete(self, path: str) -> Any:
        url = f"{self.base_url}{path}"
        return self._request("DELETE", url)

    def _request(self, method: str, url: str, body: Any = None) -> Any:
        last_error: Exception | None = None
        data_bytes = json.dumps(body).encode() if body is not None else None

        for attempt in range(self.max_retries + 1):
            try:
                req = Request(url, data=data_bytes, headers=self._headers(), method=method)
                with urlopen(req, timeout=self.timeout) as resp:
                    response_data = json.loads(resp.read().decode())
                    return response_data

            except HTTPError as e:
                try:
                    error_body = json.loads(e.read().decode())
                except Exception:
                    error_body = {}

                err_info = error_body.get("error", {})
                api_error = AgentTrustApiError(
                    message=err_info.get("message", f"HTTP {e.code}"),
                    code=err_info.get("code", "unknown_error"),
                    status_code=e.code,
                    request_id=err_info.get("request_id"),
                )

                # Don't retry client errors (4xx) except 429
                if 400 <= e.code < 500 and e.code != 429:
                    raise api_error

                last_error = api_error

            except (URLError, TimeoutError, OSError) as e:
                last_error = AgentTrustNetworkError(str(e), cause=e)

            # Exponential backoff
            if attempt < self.max_retries:
                time.sleep(0.5 * (2 ** attempt))

        if last_error:
            raise last_error
        raise AgentTrustNetworkError("Request failed after retries")
