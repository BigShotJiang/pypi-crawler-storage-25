"""AgentTrust LangChain integration — use AgentTrust as a LangChain tool.

Usage:
    from agentrust.integrations.langchain import get_agentrust_tools

    tools = get_agentrust_tools(api_key="at_test_...", agent_id="your-agent-id")
    # Returns a list of LangChain Tool objects ready to use in an agent
"""

from __future__ import annotations

from typing import Any
try:
    from langchain_core.tools import Tool
except ImportError:
    raise ImportError("pip install langchain-core to use the LangChain integration")

from agentrust import AgentTrust


def get_agentrust_tools(api_key: str, agent_id: str, base_url: str | None = None) -> list[Tool]:
    """Create LangChain tools from AgentTrust SDK.

    Returns a list of Tool objects that can be passed to any LangChain agent.
    """
    kwargs: dict[str, Any] = {"api_key": api_key, "agent_id": agent_id}
    if base_url:
        kwargs["base_url"] = base_url
    trust = AgentTrust(**kwargs)

    return [
        Tool(
            name="agentrust_verify_identity",
            description="Verify the identity and trust score of an AI agent or company. Input: agent_id string.",
            func=lambda agent_id: str(trust.identity.verify(agent_id)),
        ),
        Tool(
            name="agentrust_create_contract",
            description="Create a machine-readable contract with a counterparty. Input: JSON string with 'counterparty' (agent_id) and 'terms' (items, delivery, payment, penalties).",
            func=lambda params: str(trust.contracts.create(**__import__("json").loads(params))),
        ),
        Tool(
            name="agentrust_sign_contract",
            description="Sign a proposed contract. Input: contract_id string.",
            func=lambda contract_id: str(trust.contracts.sign(contract_id)),
        ),
        Tool(
            name="agentrust_escrow_payment",
            description="Create an escrow payment for a contract. Input: contract_id string.",
            func=lambda contract_id: str(trust.payments.escrow(contract_id)),
        ),
        Tool(
            name="agentrust_complete_contract",
            description="Mark a contract as completed (releases escrow). Input: JSON with 'contract_id' and optional 'received_quantity'.",
            func=lambda params: str(trust.contracts.complete(**__import__("json").loads(params))),
        ),
        Tool(
            name="agentrust_get_reputation",
            description="Get the trust score and reputation details of an agent. Input: agent_id string.",
            func=lambda agent_id: str(trust.reputation.get(agent_id)),
        ),
        Tool(
            name="agentrust_discover_suppliers",
            description="Search for suppliers on the AgentTrust network. Input: JSON with optional 'category', 'item', 'max_price', 'min_score'.",
            func=lambda params: str(trust.analytics.discover(**__import__("json").loads(params)) if params and params.strip().startswith("{") else trust.analytics.discover(item=params)),
        ),
        Tool(
            name="agentrust_open_dispute",
            description="Open a dispute on a contract. Input: JSON with 'contract_id', 'reason', and optional 'evidence'.",
            func=lambda params: str(trust.disputes.open(**__import__("json").loads(params))),
        ),
        Tool(
            name="agentrust_evaluate_policies",
            description="Evaluate smart policies and anomaly detection for a potential transaction. Input: JSON with 'counterparty_company_id', 'amount', optional 'items'.",
            func=lambda params: str(trust.intelligence.evaluate(**__import__("json").loads(params))),
        ),
        Tool(
            name="agentrust_send_message",
            description="Send a negotiation message to another agent. Input: JSON with 'to_agent_id', 'content', optional 'message_type' (text/proposal/counter_offer/accept/reject).",
            func=lambda params: str(trust.messaging.send(**__import__("json").loads(params))),
        ),
        Tool(
            name="agentrust_create_rfq",
            description="Create a Request for Quotation for multi-supplier bidding. Input: JSON with 'title', 'items', 'deadline'.",
            func=lambda params: str(trust.analytics.overview() if params == "overview" else __import__("json").loads("not implemented")),
        ),
        Tool(
            name="agentrust_network_overview",
            description="Get network overview: total companies, agents, contracts, volume, average trust score.",
            func=lambda _: str(trust.analytics.overview()),
        ),
    ]
