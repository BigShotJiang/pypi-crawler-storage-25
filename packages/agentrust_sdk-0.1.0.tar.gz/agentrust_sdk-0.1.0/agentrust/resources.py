"""AgentTrust API resources."""

from __future__ import annotations

from typing import Any

from .http import HttpClient


class IdentityResource:
    """Identity verification and agent management."""

    def __init__(self, http: HttpClient):
        self._http = http

    def verify(self, agent_id: str) -> dict[str, Any]:
        """Verify an agent's identity and reputation."""
        return self._http.get(f"/identity/v1/verify/{agent_id}")

    def register(self, name: str, email: str, country: str = "FR", agent_name: str = "agent-01", **kwargs) -> dict[str, Any]:
        """Register a new company and first agent."""
        return self._http.post("/identity/v1/register", {"name": name, "email": email, "country": country, "agent_name": agent_name, **kwargs})

    def verify_company(self, identifier: str, country: str = "FR") -> dict[str, Any]:
        """Verify a company against government databases."""
        return self._http.post("/identity/v1/verify-company", {"identifier": identifier, "country": country})

    def list_agents(self) -> dict[str, Any]:
        """List agents for your company."""
        return self._http.get("/identity/v1/agents")

    def create_agent(self, name: str, **kwargs) -> dict[str, Any]:
        """Create a new agent under your company."""
        return self._http.post("/identity/v1/agents", {"name": name, **kwargs})

    def suspend(self, agent_id: str, reason: str = "suspended") -> dict[str, Any]:
        """Suspend an agent."""
        return self._http.post(f"/identity/v1/agents/{agent_id}/suspend", {"reason": reason})

    def reactivate(self, agent_id: str) -> dict[str, Any]:
        """Reactivate a suspended agent."""
        return self._http.post(f"/identity/v1/agents/{agent_id}/reactivate", {})


class ContractsResource:
    """Machine-readable contracts between agents."""

    def __init__(self, http: HttpClient):
        self._http = http

    def create(self, counterparty: str, terms: dict[str, Any], **kwargs) -> dict[str, Any]:
        """Create a new contract (status: proposed)."""
        return self._http.post("/contracts/v1", {"counterparty": counterparty, "terms": terms, **kwargs})

    def sign(self, contract_id: str) -> dict[str, Any]:
        """Sign a proposed contract."""
        return self._http.post(f"/contracts/v1/{contract_id}/sign", {})

    def get(self, contract_id: str) -> dict[str, Any]:
        """Get contract details."""
        return self._http.get(f"/contracts/v1/{contract_id}")

    def complete(self, contract_id: str, delivery_confirmed: bool = True, received_quantity: int | None = None, **kwargs) -> dict[str, Any]:
        """Mark a contract as completed. Triggers escrow release + reputation update."""
        body: dict[str, Any] = {"delivery_confirmed": delivery_confirmed, **kwargs}
        if received_quantity is not None:
            body["received_quantity"] = received_quantity
        return self._http.post(f"/contracts/v1/{contract_id}/complete", body)

    def cancel(self, contract_id: str, reason: str = "cancelled") -> dict[str, Any]:
        """Cancel a contract."""
        return self._http.post(f"/contracts/v1/{contract_id}/cancel", {"reason": reason})

    def amend(self, contract_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        """Propose an amendment to an active contract."""
        return self._http.post(f"/contracts/v1/{contract_id}/amend", changes)

    def list(self, status: str | None = None, limit: int = 50) -> dict[str, Any]:
        """List contracts with optional filters."""
        return self._http.get("/contracts/v1", {"status": status, "limit": limit})


class PaymentsResource:
    """Escrow payment management."""

    def __init__(self, http: HttpClient):
        self._http = http

    def escrow(self, contract_id: str, **kwargs) -> dict[str, Any]:
        """Create an escrow payment for a contract."""
        return self._http.post("/payments/v1/escrow", {"contract_id": contract_id, **kwargs})

    def release(self, payment_id: str) -> dict[str, Any]:
        """Release escrowed funds to the seller."""
        return self._http.post(f"/payments/v1/{payment_id}/release", {})

    def refund(self, payment_id: str, amount_eur: float | None = None) -> dict[str, Any]:
        """Refund escrowed funds (partial or full)."""
        body: dict[str, Any] = {}
        if amount_eur is not None:
            body["amount_eur"] = amount_eur
        return self._http.post(f"/payments/v1/{payment_id}/refund", body)

    def get(self, payment_id: str) -> dict[str, Any]:
        """Get payment details."""
        return self._http.get(f"/payments/v1/{payment_id}")

    def list(self, limit: int = 50) -> dict[str, Any]:
        """List payments."""
        return self._http.get("/payments/v1", {"limit": limit})


class ReputationResource:
    """Trust score and reputation data."""

    def __init__(self, http: HttpClient):
        self._http = http

    def get(self, agent_id: str) -> dict[str, Any]:
        """Get reputation score and details for an agent."""
        return self._http.get(f"/reputation/v1/{agent_id}")

    def history(self, agent_id: str) -> dict[str, Any]:
        """Get reputation history for an agent."""
        return self._http.get(f"/reputation/v1/{agent_id}/history")

    def compare(self, agent_ids: list[str]) -> dict[str, Any]:
        """Compare reputation of multiple agents."""
        return self._http.get("/reputation/v1/compare", {"agents": ",".join(agent_ids)})


class DisputesResource:
    """Dispute resolution."""

    def __init__(self, http: HttpClient):
        self._http = http

    def open(self, contract_id: str, reason: str, evidence: dict[str, Any] | None = None) -> dict[str, Any]:
        """Open a dispute on a contract."""
        body: dict[str, Any] = {"contract_id": contract_id, "reason": reason}
        if evidence:
            body["evidence"] = evidence
        return self._http.post("/disputes/v1/open", body)

    def add_evidence(self, dispute_id: str, evidence: dict[str, Any]) -> dict[str, Any]:
        """Add evidence to an existing dispute."""
        return self._http.post(f"/disputes/v1/{dispute_id}/evidence", evidence)

    def get(self, dispute_id: str) -> dict[str, Any]:
        """Get dispute details."""
        return self._http.get(f"/disputes/v1/{dispute_id}")

    def list(self, limit: int = 50) -> dict[str, Any]:
        """List disputes."""
        return self._http.get("/disputes/v1", {"limit": limit})


class AnalyticsResource:
    """Network analytics and supplier discovery."""

    def __init__(self, http: HttpClient):
        self._http = http

    def overview(self) -> dict[str, Any]:
        """Get network overview (companies, agents, volume, avg trust)."""
        return self._http.get("/analytics/v1/overview")

    def benchmarks(self) -> dict[str, Any]:
        """Get price benchmarks across the network."""
        return self._http.get("/analytics/v1/benchmarks")

    def leaderboard(self) -> dict[str, Any]:
        """Get top companies by trust score."""
        return self._http.get("/analytics/v1/leaderboard")

    def discover(self, **kwargs) -> dict[str, Any]:
        """Discover suppliers on the network."""
        return self._http.get("/analytics/v1/discover", kwargs)

    def search(self, query: str) -> dict[str, Any]:
        """Full-text search across contracts and catalog."""
        return self._http.get("/analytics/v1/search", {"q": query})

    def audit(self, format: str = "json") -> dict[str, Any]:
        """Export audit trail."""
        return self._http.get("/analytics/v1/audit", {"format": format})


class PlatformResource:
    """Platform health, API keys, webhooks."""

    def __init__(self, http: HttpClient):
        self._http = http

    def health(self) -> dict[str, Any]:
        """Check API health."""
        return self._http.get("/platform/v1/health")

    def status(self) -> dict[str, Any]:
        """Get platform status and metrics."""
        return self._http.get("/platform/v1/status")

    def list_keys(self) -> dict[str, Any]:
        """List API keys."""
        return self._http.get("/platform/v1/keys")

    def create_key(self, name: str, scopes: list[str] | None = None) -> dict[str, Any]:
        """Create a new API key."""
        body: dict[str, Any] = {"name": name}
        if scopes:
            body["scopes"] = scopes
        return self._http.post("/platform/v1/keys", body)

    def data_export(self) -> dict[str, Any]:
        """GDPR Article 20 data portability export."""
        return self._http.get("/platform/v1/data-export")


class IntelligenceResource:
    """Smart policies, anomaly detection, trust graph, event stream."""

    def __init__(self, http: HttpClient):
        self._http = http

    def list_policies(self) -> dict[str, Any]:
        """List all policies for your company."""
        return self._http.get("/intelligence/v1/policies")

    def create_policy(self, name: str, rule_type: str, conditions: dict[str, Any], action: str = "block", **kwargs) -> dict[str, Any]:
        """Create a new policy rule."""
        return self._http.post("/intelligence/v1/policies", {"name": name, "rule_type": rule_type, "conditions": conditions, "action": action, **kwargs})

    def delete_policy(self, policy_id: str) -> dict[str, Any]:
        """Delete a policy."""
        return self._http.delete(f"/intelligence/v1/policies/{policy_id}")

    def evaluate(self, counterparty_company_id: str, amount: float, items: list[dict] | None = None, **kwargs) -> dict[str, Any]:
        """Evaluate all policies + anomaly detection for a potential transaction."""
        body: dict[str, Any] = {"counterparty_company_id": counterparty_company_id, "amount": amount, **kwargs}
        if items:
            body["items"] = items
        return self._http.post("/intelligence/v1/evaluate", body)

    def list_alerts(self, severity: str | None = None, acknowledged: bool | None = None) -> dict[str, Any]:
        """List anomaly alerts."""
        params: dict[str, Any] = {}
        if severity:
            params["severity"] = severity
        if acknowledged is not None:
            params["acknowledged"] = str(acknowledged).lower()
        return self._http.get("/intelligence/v1/alerts", params)

    def acknowledge_alert(self, alert_id: str) -> dict[str, Any]:
        """Acknowledge an anomaly alert."""
        return self._http.post(f"/intelligence/v1/alerts/{alert_id}/acknowledge", {})

    def graph(self) -> dict[str, Any]:
        """Get trust graph (outgoing + incoming relationships)."""
        return self._http.get("/intelligence/v1/graph")

    def stream(self, limit: int = 50, unread: bool = False) -> dict[str, Any]:
        """Get event stream."""
        params: dict[str, Any] = {"limit": limit}
        if unread:
            params["unread"] = "true"
        return self._http.get("/intelligence/v1/stream", params)


class MessagingResource:
    """Agent-to-agent messaging and sandbox scenarios."""

    def __init__(self, http: HttpClient):
        self._http = http

    def send(self, to_agent_id: str, content: str, message_type: str = "text", **kwargs) -> dict[str, Any]:
        """Send a message to another agent."""
        return self._http.post("/messaging/v1/send", {"to_agent_id": to_agent_id, "content": content, "message_type": message_type, **kwargs})

    def inbox(self) -> dict[str, Any]:
        """Get unread messages."""
        return self._http.get("/messaging/v1/inbox")

    def conversations(self) -> dict[str, Any]:
        """List conversations."""
        return self._http.get("/messaging/v1/conversations")

    def get_conversation(self, conversation_id: str) -> dict[str, Any]:
        """Get conversation messages."""
        return self._http.get(f"/messaging/v1/conversations/{conversation_id}")

    def list_scenarios(self) -> dict[str, Any]:
        """List available sandbox scenarios."""
        return self._http.get("/messaging/v1/scenarios")

    def run_scenario(self, slug: str, **kwargs) -> dict[str, Any]:
        """Run a sandbox scenario end-to-end."""
        return self._http.post(f"/messaging/v1/scenarios/{slug}/run", kwargs or {})


class DeliverablesResource:
    """Service/freelance contract milestones."""

    def __init__(self, http: HttpClient):
        self._http = http

    def add(self, contract_id: str, title: str, amount_eur: float | None = None, **kwargs) -> dict[str, Any]:
        """Add a milestone/deliverable to a service contract."""
        body = {"title": title, **kwargs}
        if amount_eur is not None:
            body["amount_eur"] = amount_eur
        return self._http.post(f"/deliverables/v1/{contract_id}/add", body)

    def list(self, contract_id: str) -> dict[str, Any]:
        """List all deliverables for a contract with completion summary."""
        return self._http.get(f"/deliverables/v1/{contract_id}")

    def submit(self, contract_id: str, deliverable_id: str, evidence: dict | None = None) -> dict[str, Any]:
        """Seller submits a deliverable with evidence (e.g., Figma link, commit SHA)."""
        return self._http.post(f"/deliverables/v1/{contract_id}/{deliverable_id}/submit", {"evidence": evidence or {}})

    def approve(self, contract_id: str, deliverable_id: str) -> dict[str, Any]:
        """Buyer approves a submitted deliverable. Auto-completes contract when all approved."""
        return self._http.post(f"/deliverables/v1/{contract_id}/{deliverable_id}/approve", {})

    def reject(self, contract_id: str, deliverable_id: str, reason: str | None = None) -> dict[str, Any]:
        """Buyer rejects a submitted deliverable."""
        return self._http.post(f"/deliverables/v1/{contract_id}/{deliverable_id}/reject", {"reason": reason})


class RfqResource:
    """Request for Quotation — multi-supplier bidding."""

    def __init__(self, http: HttpClient):
        self._http = http

    def create(self, title: str, items: list, deadline: str, **kwargs) -> dict[str, Any]:
        """Create a new RFQ for multi-supplier bidding."""
        return self._http.post("/analytics/v1/rfq", {"title": title, "items": items, "deadline": deadline, **kwargs})

    def list(self, status: str | None = None) -> dict[str, Any]:
        """List your RFQs."""
        return self._http.get("/analytics/v1/rfq", {"status": status} if status else None)

    def list_open(self) -> dict[str, Any]:
        """Browse open RFQs from the network."""
        return self._http.get("/analytics/v1/rfq/open")

    def respond(self, rfq_id: str, proposed_terms: dict, total_price_eur: float, delivery_days: int | None = None, notes: str | None = None) -> dict[str, Any]:
        """Submit a response/bid to an open RFQ."""
        body = {"proposed_terms": proposed_terms, "total_price_eur": total_price_eur}
        if delivery_days is not None:
            body["delivery_days"] = delivery_days
        if notes:
            body["notes"] = notes
        return self._http.post(f"/analytics/v1/rfq/{rfq_id}/respond", body)

    def responses(self, rfq_id: str) -> dict[str, Any]:
        """List responses to your RFQ (sorted by price)."""
        return self._http.get(f"/analytics/v1/rfq/{rfq_id}/responses")


class EcosystemResource:
    """Protocol integrations, payment rails, country verifications."""

    def __init__(self, http: HttpClient):
        self._http = http

    def protocols(self) -> dict[str, Any]:
        """List supported protocol integrations (MCP, ACP, A2A, Visa TAP, x402, etc.)."""
        return self._http.get("/analytics/v1/protocols")

    def payment_rails(self) -> dict[str, Any]:
        """List supported payment rails (Stripe, SEPA, ACH, USDC, Virtual Cards)."""
        return self._http.get("/analytics/v1/rails")

    def countries(self) -> dict[str, Any]:
        """List supported country verification sources."""
        return self._http.get("/analytics/v1/countries")


class ProtocolsResource:
    """Multi-protocol compatibility: KYA, ACP, A2A, AP2, Visa TAP, x402, Open Banking."""

    def __init__(self, http: HttpClient):
        self._http = http

    # KYA — Digital Agent Passports
    def get_passport(self, agent_id: str) -> dict[str, Any]:
        """Get KYA Digital Agent Passport for an agent (W3C VC compatible)."""
        return self._http.get(f"/protocols/v1/passport/{agent_id}")

    def verify_passport_number(self, passport_number: str) -> dict[str, Any]:
        """Verify a passport by ATP-XXXX number."""
        return self._http.get(f"/protocols/v1/passport/by-number/{passport_number}")

    # ACP — OpenAI + Stripe
    def acp_session(self, session_id: str, buyer_intent: dict) -> dict[str, Any]:
        """Create Agentic Commerce Protocol (OpenAI+Stripe) session."""
        return self._http.post("/protocols/v1/acp/session", {"session_id": session_id, "buyer_intent": buyer_intent})

    def acp_complete(self, session_id: str, contract_id: str | None = None, escrow_id: str | None = None) -> dict[str, Any]:
        """Complete an ACP checkout session with linked contract/escrow."""
        return self._http.post(f"/protocols/v1/acp/session/{session_id}/complete", {"contract_id": contract_id, "escrow_id": escrow_id})

    # A2A — Google Agent-to-Agent
    def a2a_interact(self, intent: str, to_agent_id: str | None = None, payload: dict | None = None) -> dict[str, Any]:
        """Create A2A (Google) cross-agent interaction."""
        body = {"intent": intent, "payload": payload or {}}
        if to_agent_id:
            body["to_agent_id"] = to_agent_id
        return self._http.post("/protocols/v1/a2a/interact", body)

    def a2a_inbox(self) -> dict[str, Any]:
        """Get A2A interactions received by your agent."""
        return self._http.get("/protocols/v1/a2a/inbox")

    # AP2 — Google Agent Payments Protocol
    def ap2_mandate(self, mandate_type: str, authorized_amount_eur: float, **kwargs) -> dict[str, Any]:
        """Issue AP2 payment mandate (W3C Verifiable Credential compatible)."""
        return self._http.post("/protocols/v1/ap2/mandate", {"mandate_type": mandate_type, "authorized_amount_eur": authorized_amount_eur, **kwargs})

    def ap2_verify(self, mandate_id: str) -> dict[str, Any]:
        """Verify an AP2 mandate validity."""
        return self._http.post(f"/protocols/v1/ap2/verify/{mandate_id}", {})

    # Visa TAP
    def visa_tap_verify(self, merchant_id: str, user_presence: str, commerce_intent: dict) -> dict[str, Any]:
        """Request Visa Trusted Agent Protocol verification token."""
        return self._http.post("/protocols/v1/visa-tap/verify", {"merchant_id": merchant_id, "user_presence": user_presence, "commerce_intent": commerce_intent})

    def visa_tap_check(self, token: str) -> dict[str, Any]:
        """Check validity of a Visa TAP token."""
        return self._http.get(f"/protocols/v1/visa-tap/check/{token}")

    # x402 — Coinbase stablecoin
    def x402_session(self, amount_usdc: float, recipient_wallet: str, chain: str = "base", **kwargs) -> dict[str, Any]:
        """Create x402 HTTP 402 Payment Required session for USDC."""
        return self._http.post("/protocols/v1/x402/session", {"amount_usdc": amount_usdc, "recipient_wallet": recipient_wallet, "chain": chain, **kwargs})

    def x402_confirm(self, session_id: str, tx_hash: str) -> dict[str, Any]:
        """Confirm x402 payment with on-chain transaction hash."""
        return self._http.post(f"/protocols/v1/x402/confirm/{session_id}", {"tx_hash": tx_hash})

    # Open Banking — SEPA PSD2/DSP3
    def open_banking_initiate(self, payment_amount_eur: float, iban_creditor: str, reference: str, provider: str = "truelayer", **kwargs) -> dict[str, Any]:
        """Initiate Open Banking SEPA payment (PSD2/DSP3)."""
        return self._http.post("/protocols/v1/open-banking/initiate", {"payment_amount_eur": payment_amount_eur, "iban_creditor": iban_creditor, "reference": reference, "provider": provider, **kwargs})

    def open_banking_confirm(self, consent_id: str) -> dict[str, Any]:
        """Confirm Open Banking consent after user authorization."""
        return self._http.post(f"/protocols/v1/open-banking/confirm/{consent_id}", {})

    # Directory — public listing
    def directory(self) -> dict[str, Any]:
        """Public registry of all protocols, rails, countries, and usage stats."""
        return self._http.get("/protocols/v1/directory")


class VerificationResource:
    """Real-time government database verification (SEC EDGAR, GLEIF, VIES, Companies House, etc.)."""

    def __init__(self, http: HttpClient):
        self._http = http

    def verify_us(self, identifier: str) -> dict[str, Any]:
        """Verify US company via SEC EDGAR. Accepts CIK, ticker, or company name."""
        return self._http.get(f"/verification/US", {"id": identifier})

    def verify_uk(self, company_number: str) -> dict[str, Any]:
        """Verify UK company via Companies House."""
        return self._http.get(f"/verification/UK", {"id": company_number})

    def verify_fr(self, siret_or_siren: str) -> dict[str, Any]:
        """Verify French company via annuaire-entreprises.data.gouv.fr."""
        return self._http.get(f"/verification/FR", {"id": siret_or_siren})

    def verify_eu(self, vat_number: str) -> dict[str, Any]:
        """Verify EU VAT number via VIES (ec.europa.eu)."""
        return self._http.get(f"/verification/EU", {"id": vat_number})

    def verify_ch(self, company_name: str) -> dict[str, Any]:
        """Verify Swiss company via Zefix."""
        return self._http.get(f"/verification/CH", {"id": company_name})

    def verify_lei(self, lei: str) -> dict[str, Any]:
        """Verify Legal Entity Identifier via GLEIF (global)."""
        return self._http.get(f"/verification/LEI", {"id": lei})

    def verify(self, country: str, identifier: str) -> dict[str, Any]:
        """Generic verification — country: US, UK, FR, EU, CH, DE, LEI."""
        return self._http.get(f"/verification/{country.upper()}", {"id": identifier})
