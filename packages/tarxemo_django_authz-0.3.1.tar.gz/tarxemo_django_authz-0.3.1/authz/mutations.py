import graphene
from django.db import transaction
from django.contrib.auth import get_user_model
from tarxemo_django_graphene_utils import (
    build_error, 
    build_success_response,
    to_graphene
)

from authz.models import Permission, Role, UIElement
from authz.services import (
    assign_role, revoke_role, grant_permission, deny_permission, revoke_user_permission,
    get_user_ui_elements, sync_ui_element
)
from authz.utils import validate_permission_code
from authz.dto.types import (
    PermissionInput, PermissionUpdateInput, PermissionSingleDTO,
    RoleInput, RoleUpdateInput, RoleSingleDTO,
    AssignRoleInput, RevokeRoleInput, StandardResponseType,
    GrantPermissionInput, DenyPermissionInput, RevokeUserPermissionInput,
    UIElementInput, UIElementUpdateInput, UIElementSingleDTO,
    SyncUIElementInput, SyncUIElementDTO, SyncUIElementDataType, 
    UIElementSingleDataType, LoginInput, LoginDataType, LoginResponseType,
    RefreshTokenInput, RefreshTokenDataType, RefreshTokenResponseType,
    LogoutInput, CheckOrCreatePermissionInput, CheckOrCreatePermissionDataType, 
    CheckOrCreatePermissionDTO, PermissionSingleDataType, RoleSingleDataType,
    PermissionType, RoleType, UIElementType, UserType
)

User = get_user_model()

# -----------------------------------------------------------------------------
# Permission Mutations
# -----------------------------------------------------------------------------

class CreatePermission(graphene.Mutation):
    class Arguments:
        input = PermissionInput(required=True)
    
    Output = PermissionSingleDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return PermissionSingleDTO(response=build_error("Permission denied"))
            
            validate_permission_code(input.code)
            
            if Permission.objects.filter(code=input.code).exists():
                 return PermissionSingleDTO(response=build_error("Permission code already exists"))
            
            permission = Permission.objects.create(
                code=input.code,
                description=input.description or ""
            )
            
            return PermissionSingleDTO(
                data=PermissionSingleDataType(permission=to_graphene(permission, PermissionType)),
                response=build_success_response("Permission created successfully")
            )
        except Exception as e:
            return PermissionSingleDTO(response=build_error(str(e)))

class UpdatePermission(graphene.Mutation):
    class Arguments:
        input = PermissionUpdateInput(required=True)
        
    Output = PermissionSingleDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return PermissionSingleDTO(response=build_error("Permission denied"))
            
            try:
                permission = Permission.objects.get(id=input.id)
            except Permission.DoesNotExist:
                return PermissionSingleDTO(response=build_error("Permission not found"))
            
            if input.description is not None:
                permission.description = input.description
            
            if input.is_active is not None:
                permission.is_active = input.is_active
                
            permission.save()
            
            return PermissionSingleDTO(
                data=PermissionSingleDataType(permission=to_graphene(permission, PermissionType)),
                response=build_success_response("Permission updated successfully")
            )
        except Exception as e:
            return PermissionSingleDTO(response=build_error(str(e)))

class DeletePermission(graphene.Mutation):
    class Arguments:
        id = graphene.ID(required=True)
        
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, id):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                return StandardResponseType(response=build_error("Permission denied"))
                
            Permission.objects.filter(id=id).delete()
            return StandardResponseType(response=build_success_response("Permission deleted successfully"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

# -----------------------------------------------------------------------------
# Role Mutations
# -----------------------------------------------------------------------------

class CreateRole(graphene.Mutation):
    class Arguments:
        input = RoleInput(required=True)
        
    Output = RoleSingleDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return RoleSingleDTO(response=build_error("Permission denied"))
            
            if Role.objects.filter(name=input.name).exists():
                 return RoleSingleDTO(response=build_error("Role name already exists"))
            
            role = Role.objects.create(
                name=input.name,
                description=input.description or ""
            )
            
            if input.permission_codes:
                for code in input.permission_codes:
                    role.add_permission(code)
            
            return RoleSingleDTO(
                data=RoleSingleDataType(role=to_graphene(role, RoleType)),
                response=build_success_response("Role created successfully")
            )
        except Exception as e:
            return RoleSingleDTO(response=build_error(str(e)))

class UpdateRole(graphene.Mutation):
    class Arguments:
        input = RoleUpdateInput(required=True)
        
    Output = RoleSingleDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return RoleSingleDTO(response=build_error("Permission denied"))
            
            try:
                role = Role.objects.get(id=input.id)
            except Role.DoesNotExist:
                return RoleSingleDTO(response=build_error("Role not found"))
            
            if input.name:
                if Role.objects.filter(name=input.name).exclude(id=input.id).exists():
                    return RoleSingleDTO(response=build_error("Role name already exists"))
                role.name = input.name
                
            if input.description is not None:
                role.description = input.description
                
            if input.is_active is not None:
                role.is_active = input.is_active

            if input.permission_codes is not None:
                role.permissions.clear()
                for code in input.permission_codes:
                    role.add_permission(code)
                
            role.save()
            
            return RoleSingleDTO(
                data=RoleSingleDataType(role=to_graphene(role, RoleType)),
                response=build_success_response("Role updated successfully")
            )
        except Exception as e:
            return RoleSingleDTO(response=build_error(str(e)))

class DeleteRole(graphene.Mutation):
    class Arguments:
        id = graphene.ID(required=True)
        
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, id):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                return StandardResponseType(response=build_error("Permission denied"))
                
            Role.objects.filter(id=id).delete()
            return StandardResponseType(response=build_success_response("Role deleted successfully"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

# -----------------------------------------------------------------------------
# Assignment Mutations
# -----------------------------------------------------------------------------

class AssignRole(graphene.Mutation):
    class Arguments:
        input = AssignRoleInput(required=True)
        
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return StandardResponseType(response=build_error("Permission denied"))
            
            target_user = User.objects.get(id=input.user_id)
            assign_role(target_user, input.role_name, created_by=user)
            
            return StandardResponseType(response=build_success_response("Role assigned successfully"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

class RevokeRole(graphene.Mutation):
    class Arguments:
        input = RevokeRoleInput(required=True)
        
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return StandardResponseType(response=build_error("Permission denied"))
            
            target_user = User.objects.get(id=input.user_id)
            if revoke_role(target_user, input.role_name):
                return StandardResponseType(response=build_success_response("Role revoked successfully"))
            return StandardResponseType(response=build_error("Role assignment not found"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

class GrantPermission(graphene.Mutation):
    class Arguments:
        input = GrantPermissionInput(required=True)
    
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return StandardResponseType(response=build_error("Permission denied"))
            
            target_user = User.objects.get(id=input.user_id)
            grant_permission(target_user, input.permission_code, created_by=user)
            
            return StandardResponseType(response=build_success_response("Permission granted successfully"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

class DenyPermission(graphene.Mutation):
    class Arguments:
        input = DenyPermissionInput(required=True)
    
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return StandardResponseType(response=build_error("Permission denied"))
            
            target_user = User.objects.get(id=input.user_id)
            deny_permission(target_user, input.permission_code, created_by=user)
            
            return StandardResponseType(response=build_success_response("Permission denied successfully"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

class RevokeUserPermission(graphene.Mutation):
    class Arguments:
        input = RevokeUserPermissionInput(required=True)
        
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                 return StandardResponseType(response=build_error("Permission denied"))
            
            target_user = User.objects.get(id=input.user_id)
            if revoke_user_permission(target_user, input.permission_code):
                 return StandardResponseType(response=build_success_response("Permission override revoked successfully"))
            return StandardResponseType(response=build_error("Permission override not found"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

# -----------------------------------------------------------------------------
# Auth & Dynamic Permission Mutations
# -----------------------------------------------------------------------------

class LoginUser(graphene.Mutation):
    class Arguments:
        input = LoginInput(required=True)
    
    Output = LoginResponseType
    
    def mutate(self, info, input):
        try:
            from django.contrib.auth import authenticate
            from rest_framework_simplejwt.tokens import RefreshToken as SimpleJWTRefreshToken
            
            user_obj = User.objects.filter(email=input.email).first() or User.objects.filter(username=input.email).first()
            if not user_obj:
                return LoginResponseType(response=build_error("Invalid credentials"))
            
            user = authenticate(username=user_obj.username, password=input.password)
            if not user:
                return LoginResponseType(response=build_error("Invalid credentials"))
            
            if not user.is_active:
                return LoginResponseType(response=build_error("Account is inactive"))
            
            refresh = SimpleJWTRefreshToken.for_user(user)
            user_data = UserType(
                id=user.id,
                username=user.username,
                email=user.email,
                first_name=getattr(user, 'first_name', ''),
                last_name=getattr(user, 'last_name', ''),
                is_active=user.is_active,
                is_superuser=user.is_superuser
            )
            
            return LoginResponseType(
                data=LoginDataType(
                    user=user_data,
                    access_token=str(refresh.access_token),
                    refresh_token=str(refresh),
                    authorized_ui_elements=get_user_ui_elements(user)
                ),
                response=build_success_response("Login successful")
            )
        except Exception as e:
            return LoginResponseType(response=build_error(str(e)))

class RefreshToken(graphene.Mutation):
    class Arguments:
        input = RefreshTokenInput(required=True)
    
    Output = RefreshTokenResponseType
    
    def mutate(self, info, input):
        try:
            from rest_framework_simplejwt.tokens import RefreshToken as SimpleJWTRefreshToken
            refresh = SimpleJWTRefreshToken(input.refresh_token)
            
            user_id = refresh.get('user_id')
            user = User.objects.filter(id=user_id).first()
            
            return RefreshTokenResponseType(
                data=RefreshTokenDataType(
                    access_token=str(refresh.access_token),
                    authorized_ui_elements=get_user_ui_elements(user) if user else []
                ),
                response=build_success_response("Token refreshed successfully")
            )
        except Exception as e:
            return RefreshTokenResponseType(response=build_error(str(e)))

class LogoutUser(graphene.Mutation):
    class Arguments:
        input = LogoutInput(required=True)
    
    Output = StandardResponseType
    
    def mutate(self, info, input):
        try:
            from rest_framework_simplejwt.tokens import RefreshToken as SimpleJWTRefreshToken
            SimpleJWTRefreshToken(input.refresh_token).blacklist()
            return StandardResponseType(response=build_success_response("Logout successful"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

class CheckOrCreatePermission(graphene.Mutation):
    class Arguments:
        input = CheckOrCreatePermissionInput(required=True)
    
    Output = CheckOrCreatePermissionDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            permission, created = Permission.objects.get_or_create(
                code=input.permission_code,
                defaults={'description': input.description or f"Auto-generated for UI element: {input.permission_code}"}
            )
            
            from authz.engine import authorize
            return CheckOrCreatePermissionDTO(
                data=CheckOrCreatePermissionDataType(
                    permission=to_graphene(permission, PermissionType),
                    is_authorized=authorize(user, input.permission_code)
                ),
                response=build_success_response(f"Permission {'created and ' if created else ''}checked successfully")
            )
        except Exception as e:
            return CheckOrCreatePermissionDTO(response=build_error(str(e)))

# -----------------------------------------------------------------------------
# UI Visibility Mutations
# -----------------------------------------------------------------------------

class CreateUIElement(graphene.Mutation):
    class Arguments:
        input = UIElementInput(required=True)
    
    Output = UIElementSingleDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                return UIElementSingleDTO(response=build_error("Permission denied"))
            
            ui_element = sync_ui_element(
                identifier=input.identifier,
                permission_codes=input.permission_codes,
                description=input.description
            )
            return UIElementSingleDTO(
                data=UIElementSingleDataType(ui_element=to_graphene(ui_element, UIElementType)),
                response=build_success_response("UI Element created successfully")
            )
        except Exception as e:
            return UIElementSingleDTO(response=build_error(str(e)))

class UpdateUIElement(graphene.Mutation):
    class Arguments:
        input = UIElementUpdateInput(required=True)
    
    Output = UIElementSingleDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                return UIElementSingleDTO(response=build_error("Permission denied"))
            
            if input.id:
                ui_element = UIElement.objects.get(id=input.id)
            elif input.identifier:
                ui_element = UIElement.objects.get(identifier=input.identifier)
            else:
                return UIElementSingleDTO(response=build_error("ID or identifier required"))
            
            if input.identifier: ui_element.identifier = input.identifier
            if input.description is not None: ui_element.description = input.description
            if input.is_active is not None: ui_element.is_active = input.is_active
            
            ui_element.save()
            
            if input.permission_codes is not None:
                ui_element.permissions.clear()
                for code in input.permission_codes:
                    perm, _ = Permission.objects.get_or_create(
                        code=code, defaults={'description': f"Auto-generated for UI element: {ui_element.identifier}"}
                    )
                    ui_element.permissions.add(perm)
                    
            return UIElementSingleDTO(
                data=UIElementSingleDataType(ui_element=to_graphene(ui_element, UIElementType)),
                response=build_success_response("UI Element updated successfully")
            )
        except Exception as e:
            return UIElementSingleDTO(response=build_error(str(e)))

class DeleteUIElement(graphene.Mutation):
    class Arguments:
        id = graphene.ID(required=True)
    
    Output = StandardResponseType
    
    @transaction.atomic
    def mutate(self, info, id):
        try:
            user = info.context.user
            if not user.is_authenticated or not user.is_superuser:
                return StandardResponseType(response=build_error("Permission denied"))
            UIElement.objects.filter(id=id).delete()
            return StandardResponseType(response=build_success_response("UI Element deleted successfully"))
        except Exception as e:
            return StandardResponseType(response=build_error(str(e)))

class SyncUIElement(graphene.Mutation):
    class Arguments:
        input = SyncUIElementInput(required=True)
    
    Output = SyncUIElementDTO
    
    @transaction.atomic
    def mutate(self, info, input):
        try:
            ui_element = sync_ui_element(
                identifier=input.identifier,
                permission_codes=input.permission_codes,
                description=input.description
            )
            
            user = info.context.user
            return SyncUIElementDTO(
                data=SyncUIElementDataType(
                    ui_element=to_graphene(ui_element, UIElementType),
                    is_authorized=input.identifier in get_user_ui_elements(user)
                ),
                response=build_success_response("UI element synced and checked")
            )
        except Exception as e:
            return SyncUIElementDTO(response=build_error(str(e)))

class BulkSyncUIElements(graphene.Mutation):
    class Arguments:
        inputs = graphene.List(graphene.NonNull(SyncUIElementInput), required=True)
    
    Output = BulkSyncUIElementDTO
    
    @transaction.atomic
    def mutate(self, info, inputs):
        try:
            user = info.context.user
            authorized_elements = get_user_ui_elements(user)
            results = []
            
            for item in inputs:
                ui_element = sync_ui_element(
                    identifier=item.identifier,
                    permission_codes=item.permission_codes,
                    description=item.description
                )
                results.append(SyncUIElementDataType(
                    ui_element=to_graphene(ui_element, UIElementType),
                    is_authorized=item.identifier in authorized_elements
                ))
                
            return BulkSyncUIElementDTO(
                data=BulkSyncUIElementDataType(results=results),
                response=build_success_response(f"Bulk sync of {len(inputs)} elements complete")
            )
        except Exception as e:
            return BulkSyncUIElementDTO(response=build_error(str(e)))

class AuthzMutation(graphene.ObjectType):
    create_permission = CreatePermission.Field()
    update_permission = UpdatePermission.Field()
    delete_permission = DeletePermission.Field()
    create_role = CreateRole.Field()
    update_role = UpdateRole.Field()
    delete_role = DeleteRole.Field()
    assign_role = AssignRole.Field()
    revoke_role = RevokeRole.Field()
    grant_permission = GrantPermission.Field()
    deny_permission = DenyPermission.Field()
    revoke_user_permission = RevokeUserPermission.Field()
    check_or_create_permission = CheckOrCreatePermission.Field()
    create_ui_element = CreateUIElement.Field()
    update_ui_element = UpdateUIElement.Field()
    delete_ui_element = DeleteUIElement.Field()
    sync_ui_element = SyncUIElement.Field()
    bulk_sync_ui_elements = BulkSyncUIElements.Field()
    login_user = LoginUser.Field()
    refresh_token = RefreshToken.Field()
    logout_user = LogoutUser.Field()

