import graphene
from tarxemo_django_graphene_utils import BaseResponseDTO

# -----------------------------------------------------------------------------
# Base Object Types
# -----------------------------------------------------------------------------

class PermissionType(graphene.ObjectType):
    """Graphene type for Permission model."""
    id = graphene.ID()
    code = graphene.String()
    description = graphene.String()
    is_active = graphene.Boolean()
    created_at = graphene.DateTime()
    updated_at = graphene.DateTime()

class RoleType(graphene.ObjectType):
    """Graphene type for Role model."""
    id = graphene.ID()
    name = graphene.String()
    description = graphene.String()
    is_active = graphene.Boolean()
    created_at = graphene.DateTime()
    updated_at = graphene.DateTime()
    permission_codes = graphene.List(graphene.String)

    def resolve_permission_codes(self, info):
        # Optimized to use prefetched data if available
        if hasattr(self, 'permissions'):
            return [p.code for p in self.permissions.all()]
        return self.get_permission_codes()

class UserRoleType(graphene.ObjectType):
    """Graphene type for UserRole model."""
    id = graphene.ID()
    role = graphene.Field(RoleType)
    user_id = graphene.ID()
    created_at = graphene.DateTime()

class UserPermissionType(graphene.ObjectType):
    """Graphene type for UserPermission model."""
    id = graphene.ID()
    permission = graphene.Field(PermissionType)
    user_id = graphene.ID()
    allow = graphene.Boolean()
    created_at = graphene.DateTime()

class UIElementType(graphene.ObjectType):
    """Graphene type for UIElement model."""
    id = graphene.ID()
    identifier = graphene.String()
    description = graphene.String()
    permissions = graphene.List(PermissionType)
    permission_codes = graphene.List(graphene.String)
    is_active = graphene.Boolean()
    created_at = graphene.DateTime()
    updated_at = graphene.DateTime()

    def resolve_permission_codes(self, info):
        if hasattr(self, 'permissions'):
            return [p.code for p in self.permissions.all()]
        return self.permissions.values_list('code', flat=True)

# -----------------------------------------------------------------------------
# Inputs
# -----------------------------------------------------------------------------

class PermissionInput(graphene.InputObjectType):
    code = graphene.String(required=True)
    description = graphene.String()

class PermissionUpdateInput(graphene.InputObjectType):
    id = graphene.ID(required=True)
    description = graphene.String()
    is_active = graphene.Boolean()

class RoleInput(graphene.InputObjectType):
    name = graphene.String(required=True)
    description = graphene.String()
    permission_codes = graphene.List(graphene.String)

class RoleUpdateInput(graphene.InputObjectType):
    id = graphene.ID(required=True)
    name = graphene.String()
    description = graphene.String()
    permission_codes = graphene.List(graphene.String)
    is_active = graphene.Boolean()

class AssignRoleInput(graphene.InputObjectType):
    user_id = graphene.ID(required=True)
    role_name = graphene.String(required=True)

class RevokeRoleInput(graphene.InputObjectType):
    user_id = graphene.ID(required=True)
    role_name = graphene.String(required=True)

class GrantPermissionInput(graphene.InputObjectType):
    user_id = graphene.ID(required=True)
    permission_code = graphene.String(required=True)

class DenyPermissionInput(graphene.InputObjectType):
    user_id = graphene.ID(required=True)
    permission_code = graphene.String(required=True)

class RevokeUserPermissionInput(graphene.InputObjectType):
    user_id = graphene.ID(required=True)
    permission_code = graphene.String(required=True)

class LoginInput(graphene.InputObjectType):
    email = graphene.String(required=True)
    password = graphene.String(required=True)

class RefreshTokenInput(graphene.InputObjectType):
    refresh_token = graphene.String(required=True)

class LogoutInput(graphene.InputObjectType):
    refresh_token = graphene.String(required=True)

class CheckOrCreatePermissionInput(graphene.InputObjectType):
    permission_code = graphene.String(required=True)
    description = graphene.String()

class UIElementInput(graphene.InputObjectType):
    identifier = graphene.String(required=True)
    permission_codes = graphene.List(graphene.String)
    description = graphene.String()

class UIElementUpdateInput(graphene.InputObjectType):
    id = graphene.ID()
    identifier = graphene.String()
    permission_codes = graphene.List(graphene.String)
    description = graphene.String()
    is_active = graphene.Boolean()

class SyncUIElementInput(graphene.InputObjectType):
    identifier = graphene.String(required=True)
    permission_codes = graphene.List(graphene.String)
    description = graphene.String()

# -----------------------------------------------------------------------------
# Extra Data Types
# -----------------------------------------------------------------------------

class UserAuthorizationDetailsType(graphene.ObjectType):
    """Comprehensive authorization details for a user."""
    roles = graphene.List(RoleType)
    explicit_permissions = graphene.List(UserPermissionType)
    all_permission_codes = graphene.List(graphene.String)

class UIElementSingleDataType(graphene.ObjectType):
    ui_element = graphene.Field(UIElementType)

class PermissionSingleDataType(graphene.ObjectType):
    permission = graphene.Field(PermissionType)

class RoleSingleDataType(graphene.ObjectType):
    role = graphene.Field(RoleType)

class UserType(graphene.ObjectType):
    """Generic User representation."""
    id = graphene.ID()
    username = graphene.String()
    email = graphene.String()
    first_name = graphene.String()
    last_name = graphene.String()
    is_active = graphene.Boolean()
    is_superuser = graphene.Boolean()

class LoginDataType(graphene.ObjectType):
    user = graphene.Field(UserType)
    access_token = graphene.String()
    refresh_token = graphene.String()
    authorized_ui_elements = graphene.List(graphene.String)

class RefreshTokenDataType(graphene.ObjectType):
    access_token = graphene.String()
    authorized_ui_elements = graphene.List(graphene.String)

class CheckOrCreatePermissionDataType(graphene.ObjectType):
    permission = graphene.Field(PermissionType)
    is_authorized = graphene.Boolean()

class SyncUIElementDataType(graphene.ObjectType):
    ui_element = graphene.Field(UIElementType)
    is_authorized = graphene.Boolean()

# -----------------------------------------------------------------------------
# Standard DTOs
# -----------------------------------------------------------------------------

class StandardResponseType(BaseResponseDTO):
    """Standard response with just success/error message."""
    data = graphene.String(required=False)

class PermissionSingleDTO(BaseResponseDTO):
    data = graphene.Field(PermissionSingleDataType)

class PermissionListDTO(BaseResponseDTO):
    data = graphene.List(PermissionType)

class RoleSingleDTO(BaseResponseDTO):
    data = graphene.Field(RoleSingleDataType)

class RoleListDTO(BaseResponseDTO):
    data = graphene.List(RoleType)

class UIElementSingleDTO(BaseResponseDTO):
    data = graphene.Field(UIElementSingleDataType)

class UIElementListDTO(BaseResponseDTO):
    data = graphene.List(UIElementType)

class UserAuthorizationDetailsDTO(BaseResponseDTO):
    data = graphene.Field(UserAuthorizationDetailsType)

class LoginResponseType(BaseResponseDTO):
    data = graphene.Field(LoginDataType)

class RefreshTokenResponseType(BaseResponseDTO):
    data = graphene.Field(RefreshTokenDataType)

class CheckOrCreatePermissionDTO(BaseResponseDTO):
    data = graphene.Field(CheckOrCreatePermissionDataType)

class SyncUIElementDTO(BaseResponseDTO):
    data = graphene.Field(SyncUIElementDataType)

class BulkSyncUIElementDataType(graphene.ObjectType):
    results = graphene.List(SyncUIElementDataType)

class BulkSyncUIElementDTO(BaseResponseDTO):
    data = graphene.Field(BulkSyncUIElementDataType)
