import logging
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from rest_framework_simplejwt.tokens import UntypedToken
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError

logger = logging.getLogger(__name__)

class AuthzJWTAuthenticationMiddleware:
    """
    Middleware for handling JWT authentication in Graphene queries/mutations.
    Extracts user from 'Authorization: Bearer <token>' header.
    """

    def resolve(self, next, root, info, **kwargs):
        # In Graphene, info.context is usually the Django request object
        request = info.context
        
        # Check if we already have a user (from standard Django middleware)
        if hasattr(request, 'user') and request.user.is_authenticated:
            return next(root, info, **kwargs)

        auth_header = request.headers.get("Authorization", "")
        user = AnonymousUser()

        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split("Bearer ")[1]
            try:
                # Validate token
                validated_token = UntypedToken(token)

                # Get user from token
                User = get_user_model()
                user_id = validated_token.get("user_id") or validated_token.get("sub")
                if user_id:
                    user_obj = User.objects.filter(id=user_id).first()
                    if user_obj:
                        user = user_obj
                    else:
                        logger.warning(f"Authz: No user found with id {user_id} from token.")
            except (InvalidToken, TokenError) as e:
                logger.debug(f"Authz: JWT token is invalid or expired: {e}")
            except Exception as e:
                logger.error(f"Authz: Unexpected error decoding JWT: {str(e)}")

        # Attach user back to request and context
        request.user = user
        if hasattr(info, 'context'):
            info.context.user = user
             
        return next(root, info, **kwargs)
