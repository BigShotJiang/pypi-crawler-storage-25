import graphene
from django.db.models import Q
from django.contrib.auth import get_user_model
from tarxemo_django_graphene_utils import (
    build_success_response, 
    build_error,
    get_paginated_and_non_paginated_data,
    to_graphene,
    auto_optimize,
    build_paged_list,
    build_single_object,
    BaseFilterInput
)

from authz.models import Permission, Role, UserRole, UserPermission, UIElement
from authz.dto.types import (
    PermissionListDTO, RoleListDTO, RoleSingleDTO,
    UserAuthorizationDetailsDTO, UserAuthorizationDetailsType,
    UIElementListDTO, UIElementSingleDTO, UIElementSingleDataType,
    RoleSingleDataType, PermissionType, RoleType, UIElementType,
    UserPermissionType
)

User = get_user_model()

class AuthzFilterInput(BaseFilterInput):
    """Extended filter for Authz queries."""
    pass

class AuthzQuery(graphene.ObjectType):
    
    permissions = graphene.Field(
        PermissionListDTO,
        filters=AuthzFilterInput()
    )
    
    roles = graphene.Field(
        RoleListDTO,
        filters=AuthzFilterInput()
    )
    
    role = graphene.Field(
        RoleSingleDTO,
        id=graphene.ID(required=True)
    )
    
    user_authorization_details = graphene.Field(
        UserAuthorizationDetailsDTO,
        user_id=graphene.ID(required=True)
    )
    
    ui_elements = graphene.Field(
        UIElementListDTO,
        filters=AuthzFilterInput()
    )
    
    ui_element = graphene.Field(
        UIElementSingleDTO,
        id=graphene.ID(),
        identifier=graphene.String()
    )

    authorized_ui_elements = graphene.List(graphene.String)

    def resolve_authorized_ui_elements(self, info):
        try:
            user = info.context.user
            if not user.is_authenticated:
                return []
            from authz.services import get_user_ui_elements
            return get_user_ui_elements(user)
        except Exception:
            return []

    def resolve_permissions(self, info, filters=None):
        user = info.context.user
        if not user.is_authenticated or not user.is_superuser:
            return PermissionListDTO(response=build_error("Permission denied"))
        
        return get_paginated_and_non_paginated_data(
            model_or_queryset=Permission.objects.filter(is_active=True),
            filtering_object=filters or {},
            graphene_type=PermissionType
        )

    def resolve_roles(self, info, filters=None):
        user = info.context.user
        if not user.is_authenticated or not user.is_superuser:
            return RoleListDTO(response=build_error("Permission denied"))
        
        # Determine requested fields for optimization
        # For simplicity, we always prefetch permissions if requested in query
        qs = Role.objects.filter(is_active=True)
        qs = auto_optimize(qs, ['permissions'])
        
        return get_paginated_and_non_paginated_data(
            model_or_queryset=qs,
            filtering_object=filters or {},
            graphene_type=RoleType
        )
            
    def resolve_role(self, info, id):
        user = info.context.user
        if not user.is_authenticated or not user.is_superuser:
            return RoleSingleDTO(response=build_error("Permission denied"))
        
        try:
            role = Role.objects.prefetch_related('permissions').get(id=id)
            return {
                "response": build_success_response(),
                "data": RoleSingleDataType(role=to_graphene(role, RoleType))
            }
        except Role.DoesNotExist:
            return RoleSingleDTO(response=build_error("Role not found"))

    def resolve_user_authorization_details(self, info, user_id):
        actor = info.context.user
        if not actor.is_authenticated:
            return UserAuthorizationDetailsDTO(response=build_error("Authentication required"))
        
        if str(actor.id) != str(user_id) and not actor.is_superuser:
            return UserAuthorizationDetailsDTO(response=build_error("Permission denied"))
            
        try:
            target_user = User.objects.get(id=user_id)
            
            # Optimized FETCH using prefetching and selection
            user_roles_qs = UserRole.objects.filter(user=target_user).select_related('role')
            user_roles_qs = auto_optimize(user_roles_qs, ['role__permissions'])
            
            user_perms_qs = UserPermission.objects.filter(user=target_user).select_related('permission')
            
            from authz.engine import get_user_permission_codes
            all_codes = list(get_user_permission_codes(target_user))
            
            details = UserAuthorizationDetailsType(
                roles=[to_graphene(ur.role, RoleType) for ur in user_roles_qs],
                explicit_permissions=[to_graphene(up, UserPermissionType) for up in user_perms_qs],
                all_permission_codes=all_codes
            )
            
            return UserAuthorizationDetailsDTO(
                data=details,
                response=build_success_response("User authorization details fetched")
            )
        except Exception as e:
            return UserAuthorizationDetailsDTO(response=build_error(str(e)))

    def resolve_ui_elements(self, info, filters=None):
        user = info.context.user
        if not user.is_authenticated or not user.is_superuser:
            return UIElementListDTO(response=build_error("Permission denied"))
        
        qs = UIElement.objects.all()
        qs = auto_optimize(qs, ['permissions'])
        
        return get_paginated_and_non_paginated_data(
            model_or_queryset=qs,
            filtering_object=filters or {},
            graphene_type=UIElementType
        )

    def resolve_ui_element(self, info, id=None, identifier=None):
        user = info.context.user
        if not user.is_authenticated or not user.is_superuser:
            return UIElementSingleDTO(response=build_error("Permission denied"))
        
        try:
            if id:
                ui_element = UIElement.objects.prefetch_related('permissions').get(id=id)
            elif identifier:
                ui_element = UIElement.objects.prefetch_related('permissions').get(identifier=identifier)
            else:
                return UIElementSingleDTO(response=build_error("ID or identifier required"))
                
            return {
                "response": build_success_response(),
                "data": UIElementSingleDataType(ui_element=to_graphene(ui_element, UIElementType))
            }
        except UIElement.DoesNotExist:
            return UIElementSingleDTO(response=build_error("UI element not found"))
