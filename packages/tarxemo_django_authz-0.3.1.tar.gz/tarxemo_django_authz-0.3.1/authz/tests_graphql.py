import json
from django.test import TestCase, RequestFactory
from django.contrib.auth import get_user_model
from graphene.test import Client
import graphene

from authz.schema import AuthzQuery, AuthzMutation
from authz.models import Permission, Role, UserRole

User = get_user_model()

class TestSchema(AuthzQuery, AuthzMutation, graphene.ObjectType):
    pass

schema = graphene.Schema(query=TestSchema, mutation=TestSchema)

class GraphQLTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_superuser(username='admin', password='password')
        self.client = Client(schema)
        self.factory = RequestFactory()
        
    def execute_query(self, query, variables=None):
        request = self.factory.get('/')
        request.user = self.user
        return self.client.execute(query, variable_values=variables, context_value=request)

    def test_create_permission(self):
        mutation = """
            mutation CreatePermission($input: PermissionInput!) {
                createPermission(input: $input) {
                    response {
                        message
                    }
                    data {
                        permission {
                            code
                            description
                        }
                    }
                }
            }
        """
        variables = {
            "input": {
                "code": "test.permission",
                "description": "Test Permission"
            }
        }
        
        result = self.execute_query(mutation, variables)
        if 'errors' in result:
            print(result['errors'])
        self.assertEqual(result['data']['createPermission']['response']['message'], "Permission created successfully")
        self.assertEqual(result['data']['createPermission']['data']['permission']['code'], "test.permission")
        self.assertTrue(Permission.objects.filter(code="test.permission").exists())

    def test_create_role(self):
        # First create a permission
        Permission.objects.create(code="role.view")  # Fixed validation error
        
        mutation = """
            mutation CreateRole($input: RoleInput!) {
                createRole(input: $input) {
                    response {
                        message
                    }
                    data {
                        role {
                            name
                            permissionCodes
                        }
                    }
                }
            }
        """
        variables = {
            "input": {
                "name": "Test Role",
                "permissionCodes": ["role.view"]
            }
        }
        
        result = self.execute_query(mutation, variables)
        if 'errors' in result:
            print(result['errors'])
            
        self.assertEqual(result['data']['createRole']['response']['message'], "Role created successfully")
        self.assertEqual(result['data']['createRole']['data']['role']['name'], "Test Role")
        self.assertIn("role.view", result['data']['createRole']['data']['role']['permissionCodes'])

    def test_assign_role(self):
        target_user = User.objects.create_user(username='target')
        Role.objects.create(name="AssignedRole")
        
        mutation = """
            mutation AssignRole($input: AssignRoleInput!) {
                assignRole(input: $input) {
                    response {
                        message
                    }
                }
            }
        """
        variables = {
            "input": {
                "userId": str(target_user.id),
                "roleName": "AssignedRole"
            }
        }
        
        result = self.execute_query(mutation, variables)
        if 'errors' in result:
            print(result['errors'])
        self.assertEqual(result['data']['assignRole']['response']['message'], "Role assigned successfully")
        self.assertTrue(UserRole.objects.filter(user=target_user, role__name="AssignedRole").exists())

    def test_query_permissions(self):
        Permission.objects.create(code="app.read")
        Permission.objects.create(code="app.write")
        
        query = """
            query {
                permissions {
                    data {
                        code
                    }
                    response {
                        message
                    }
                }
            }
        """
        
        result = self.execute_query(query)
        if 'errors' in result:
            print(result['errors'])
        self.assertEqual(result['data']['permissions']['response']['message'], "Permissions fetched successfully")
        codes = [p['code'] for p in result['data']['permissions']['data']]
        self.assertIn("app.read", codes)
        self.assertIn("app.write", codes)

    def test_check_or_create_permission(self):
        mutation = """
            mutation CheckOrCreatePermission($input: CheckOrCreatePermissionInput!) {
                checkOrCreatePermission(input: $input) {
                    response {
                        message
                    }
                    data {
                        permission {
                            code
                        }
                        isAuthorized
                    }
                }
            }
        """
        variables = {
            "input": {
                "permissionCode": "ui.button.delete",
                "description": "Delete button visibility"
            }
        }
        
        result = self.execute_query(mutation, variables)
        if 'errors' in result:
             print(result['errors'])
            
        self.assertEqual(result['data']['checkOrCreatePermission']['response']['message'], "Permission created and checked successfully")
        self.assertEqual(result['data']['checkOrCreatePermission']['data']['permission']['code'], "ui.button.delete")
        self.assertTrue(result['data']['checkOrCreatePermission']['data']['isAuthorized'])
        self.assertTrue(Permission.objects.filter(code="ui.button.delete").exists())

    def test_sync_ui_element(self):
        mutation = """
            mutation SyncUIElement($input: SyncUIElementInput!) {
                syncUiElement(input: $input) {
                    response {
                        message
                    }
                    data {
                        uiElement {
                            identifier
                        }
                        isAuthorized
                    }
                }
            }
        """
        variables = {
            "input": {
                "identifier": "main.delete_btn",
                "permissionCodes": ["posts.delete"],
                "description": "Main delete button"
            }
        }
        
        result = self.execute_query(mutation, variables)
        if 'errors' in result:
             print(result['errors'])
             
        self.assertEqual(result['data']['syncUiElement']['data']['uiElement']['identifier'], "main.delete_btn")
        self.assertTrue(result['data']['syncUiElement']['data']['isAuthorized'])
        self.assertTrue(Permission.objects.filter(code="posts.delete").exists())

    def test_login_user_with_ui_elements(self):
        # Create a UI element and a user with permission to see it
        from authz.models import UIElement, Permission
        perm = Permission.objects.create(code="ui.view_reports")
        UIElement.objects.create(identifier="reports_btn").permissions.add(perm)
        
        # Test user
        user = User.objects.create_user(username='staff', password='password123', email='staff@example.com')
        from authz.services import grant_permission
        grant_permission(user, "ui.view_reports")
        
        mutation = """
            mutation LoginUser($input: LoginInput!) {
                loginUser(input: $input) {
                    response {
                        message
                    }
                    data {
                        accessToken
                        authorizedUiElements
                        user {
                            username
                        }
                    }
                }
            }
        """
        variables = {
            "input": {
                "email": "staff@example.com",
                "password": "password123"
            }
        }
        
        result = self.execute_query(mutation, variables)
        if 'errors' in result:
             print(result['errors'])
             
        self.assertEqual(result['data']['loginUser']['response']['message'], "Login successful")
        self.assertIn("reports_btn", result['data']['loginUser']['data']['authorizedUiElements'])
