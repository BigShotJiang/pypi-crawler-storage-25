# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""Unit tests for the bump_deps module."""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from airbyte_ops_mcp.airbyte_repo.bump_deps import (
    DepsError,
    bump_deps,
)


def _make_connector(
    tmpdir: str,
    connector_name: str,
    *,
    has_lock: bool = True,
) -> Path:
    """Create a minimal connector directory with pyproject.toml and optional lock file."""
    connector = Path(tmpdir) / "airbyte-integrations" / "connectors" / connector_name
    connector.mkdir(parents=True)
    (connector / "pyproject.toml").write_text(
        '[tool.poetry]\nname = "test"\nversion = "0.1.0"\n'
        '\n[tool.poetry.dependencies]\npython = "^3.9"\n'
        'airbyte-cdk = ">=7.0,<8.0"\nrequests = "*"\npydantic = "^2.0"\n'
    )
    if has_lock:
        (connector / "poetry.lock").write_text("# lock content v1\n")
    return connector


# ---------------------------------------------------------------------------
# Non-Poetry connectors are a no-op
# ---------------------------------------------------------------------------


@pytest.mark.unit
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps._detect_connector_language")
def test_manifest_only_is_noop(mock_lang):
    mock_lang.return_value = "manifest-only"
    with tempfile.TemporaryDirectory() as tmpdir:
        connector = Path(tmpdir) / "airbyte-integrations" / "connectors" / "source-test"
        connector.mkdir(parents=True)
        result = bump_deps(tmpdir, "source-test")

    assert result.updated is False
    assert "does not use Poetry" in result.message


@pytest.mark.unit
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps._detect_connector_language")
def test_java_is_noop(mock_lang):
    mock_lang.return_value = "java"
    with tempfile.TemporaryDirectory() as tmpdir:
        connector = Path(tmpdir) / "airbyte-integrations" / "connectors" / "source-test"
        connector.mkdir(parents=True)
        result = bump_deps(tmpdir, "source-test")

    assert result.updated is False


# ---------------------------------------------------------------------------
# Missing poetry.lock returns early
# ---------------------------------------------------------------------------


@pytest.mark.unit
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps._detect_connector_language")
def test_no_lock_file_returns_early(mock_lang):
    mock_lang.return_value = "python"
    with tempfile.TemporaryDirectory() as tmpdir:
        _make_connector(tmpdir, "source-test", has_lock=False)
        result = bump_deps(tmpdir, "source-test")

    assert result.updated is False
    assert "No poetry.lock" in result.message


# ---------------------------------------------------------------------------
# Dry run reports correct files
# ---------------------------------------------------------------------------


@pytest.mark.unit
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps._detect_connector_language")
def test_dry_run_reports_lock_file(mock_lang):
    mock_lang.return_value = "python"
    with tempfile.TemporaryDirectory() as tmpdir:
        _make_connector(tmpdir, "source-test")
        result = bump_deps(tmpdir, "source-test", dry_run=True)

    assert result.dry_run is True
    assert len(result.files_modified) == 1
    assert "poetry.lock" in result.files_modified[0]
    assert "source-test" in result.files_modified[0]


# ---------------------------------------------------------------------------
# Actual update detects changes vs no-changes
# ---------------------------------------------------------------------------


@pytest.mark.unit
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps._detect_connector_language")
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps.subprocess.run")
def test_update_detects_no_change(mock_run, mock_lang):
    """When poetry update succeeds but lock file content is unchanged -> updated=False."""
    mock_lang.return_value = "python"
    mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0)

    with tempfile.TemporaryDirectory() as tmpdir:
        _make_connector(tmpdir, "source-test")
        result = bump_deps(tmpdir, "source-test")

    assert result.updated is False
    assert "already up to date" in result.message


@pytest.mark.unit
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps._detect_connector_language")
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps.subprocess.run")
def test_update_detects_real_change(mock_run, mock_lang):
    """When poetry update modifies the lock file -> updated=True."""
    mock_lang.return_value = "python"

    def _fake_poetry_update(*args, **kwargs):
        # Simulate poetry modifying the lock file
        lock_path = Path(kwargs["cwd"]) / "poetry.lock"
        lock_path.write_text("# lock content v2 (updated)\n")
        return subprocess.CompletedProcess(args=[], returncode=0)

    mock_run.side_effect = _fake_poetry_update

    with tempfile.TemporaryDirectory() as tmpdir:
        _make_connector(tmpdir, "source-test")
        result = bump_deps(tmpdir, "source-test")

    assert result.updated is True
    assert len(result.files_modified) == 1
    # Verify poetry update --lock is called without package filters
    call_args = mock_run.call_args[0][0]
    assert call_args == ["poetry", "update", "--lock"]


# ---------------------------------------------------------------------------
# Subprocess failure raises DepsError
# ---------------------------------------------------------------------------


@pytest.mark.unit
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps._detect_connector_language")
@patch("airbyte_ops_mcp.airbyte_repo.bump_deps.subprocess.run")
def test_poetry_failure_raises(mock_run, mock_lang):
    mock_lang.return_value = "python"
    mock_run.side_effect = subprocess.CalledProcessError(1, "poetry", stderr="boom")

    with tempfile.TemporaryDirectory() as tmpdir:
        _make_connector(tmpdir, "source-test")
        with pytest.raises(DepsError, match="failed"):
            bump_deps(tmpdir, "source-test")
