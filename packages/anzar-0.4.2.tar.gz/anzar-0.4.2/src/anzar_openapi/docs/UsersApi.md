# anzar_openapi.UsersApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**find_user**](UsersApi.md#find_user) | **GET** /user | Get current User


# **find_user**
> User find_user()

Get current User

Returns the currently authenticated user's data. Requires a valid Bearer token.

### Example

* Api Key Authentication (session_auth):
* Bearer (JWT) Authentication (bearer_auth):

```python
import anzar_openapi
from anzar_openapi.models.user import User
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: session_auth
configuration.api_key['session_auth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['session_auth'] = 'Bearer'

# Configure Bearer authorization (JWT): bearer_auth
configuration = anzar_openapi.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.UsersApi(api_client)

    try:
        # Get current User
        api_response = api_instance.find_user()
        print("The response of UsersApi->find_user:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UsersApi->find_user: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**User**](User.md)

### Authorization

[session_auth](../README.md#session_auth), [bearer_auth](../README.md#bearer_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | User Found |  -  |
**401** | invalid request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

