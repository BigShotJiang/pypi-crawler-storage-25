# DatabaseDriver


## Enum

* `SQLITE` (value: `'SQLite'`)

* `POSTGRESQL` (value: `'PostgreSQL'`)

* `MONGODB` (value: `'MongoDB'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


