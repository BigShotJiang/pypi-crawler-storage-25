# ResetLink


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_at** | **datetime** |  | 
**link** | **str** |  | 

## Example

```python
from anzar_openapi.models.reset_link import ResetLink

# TODO update the JSON string below
json = "{}"
# create an instance of ResetLink from a JSON string
reset_link_instance = ResetLink.from_json(json)
# print the JSON string representation of the object
print(ResetLink.to_json())

# convert the object into a dict
reset_link_dict = reset_link_instance.to_dict()
# create an instance of ResetLink from a dict
reset_link_from_dict = ResetLink.from_dict(reset_link_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


