# anzar_openapi.AuthApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_session**](AuthApi.md#get_session) | **GET** /auth/session | Get current session
[**login**](AuthApi.md#login) | **POST** /auth/login | User login
[**logout**](AuthApi.md#logout) | **POST** /auth/logout | Logout
[**refresh_token**](AuthApi.md#refresh_token) | **POST** /auth/refresh-token | Refresh access token
[**register**](AuthApi.md#register) | **POST** /auth/register | Register a new user
[**render_reset_form**](AuthApi.md#render_reset_form) | **GET** /auth/password/reset | Render password reset form
[**request_password_reset**](AuthApi.md#request_password_reset) | **POST** /auth/password/forgot | Request a password reset
[**submit_new_password**](AuthApi.md#submit_new_password) | **POST** /auth/password/reset | Submit new password


# **get_session**
> Session get_session()

Get current session

Returns the currently authenticated user's session data. Requires a valid Bearer token.

### Example

* Api Key Authentication (session_auth):
* Bearer (JWT) Authentication (bearer_auth):

```python
import anzar_openapi
from anzar_openapi.models.session import Session
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: session_auth
configuration.api_key['session_auth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['session_auth'] = 'Bearer'

# Configure Bearer authorization (JWT): bearer_auth
configuration = anzar_openapi.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)

    try:
        # Get current session
        api_response = api_instance.get_session()
        print("The response of AuthApi->get_session:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthApi->get_session: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**Session**](Session.md)

### Authorization

[session_auth](../README.md#session_auth), [bearer_auth](../README.md#bearer_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Session data returned |  -  |
**401** | Unauthorized — missing or invalid token |  -  |
**403** | Account suspended or unverified |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **login**
> AuthResponse login(login_request)

User login

Authenticates a user with email and password.

**Session strategy**: Returns a session cookie (`id`) managed by the server.
**JWT strategy**: Returns `access` and `refresh` in the response body.

### Example


```python
import anzar_openapi
from anzar_openapi.models.auth_response import AuthResponse
from anzar_openapi.models.login_request import LoginRequest
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)
    login_request = anzar_openapi.LoginRequest() # LoginRequest | User login credentials

    try:
        # User login
        api_response = api_instance.login(login_request)
        print("The response of AuthApi->login:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthApi->login: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **login_request** | [**LoginRequest**](LoginRequest.md)| User login credentials | 

### Return type

[**AuthResponse**](AuthResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | User logged successfully |  * Set-Cookie - Session cookie (session strategy only). HttpOnly, Secure, SameSite&#x3D;Strict. Format: id&#x3D;&lt;session_id&gt;; HttpOnly; Secure; SameSite&#x3D;Strict <br>  |
**400** | Invalid request |  -  |
**401** | Invalid credentials |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **logout**
> logout(refresh_token_request)

Logout

Invalidates the current session and refresh token. The client should discard stored tokens.

### Example

* Api Key Authentication (session_auth):
* Bearer (JWT) Authentication (bearer_auth):

```python
import anzar_openapi
from anzar_openapi.models.refresh_token_request import RefreshTokenRequest
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: session_auth
configuration.api_key['session_auth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['session_auth'] = 'Bearer'

# Configure Bearer authorization (JWT): bearer_auth
configuration = anzar_openapi.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)
    refresh_token_request = anzar_openapi.RefreshTokenRequest() # RefreshTokenRequest | 

    try:
        # Logout
        api_instance.logout(refresh_token_request)
    except Exception as e:
        print("Exception when calling AuthApi->logout: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **refresh_token_request** | [**RefreshTokenRequest**](RefreshTokenRequest.md)|  | 

### Return type

void (empty response body)

### Authorization

[session_auth](../README.md#session_auth), [bearer_auth](../README.md#bearer_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Logged out successfully |  -  |
**400** | invalid request |  -  |
**401** | Unauthorized |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **refresh_token**
> AuthResponse refresh_token(refresh_token_request)

Refresh access token

Issues a new access token using a valid refresh token. Rotate refresh tokens on each call.

### Example

* Api Key Authentication (session_auth):
* Bearer (JWT) Authentication (bearer_auth):

```python
import anzar_openapi
from anzar_openapi.models.auth_response import AuthResponse
from anzar_openapi.models.refresh_token_request import RefreshTokenRequest
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: session_auth
configuration.api_key['session_auth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['session_auth'] = 'Bearer'

# Configure Bearer authorization (JWT): bearer_auth
configuration = anzar_openapi.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)
    refresh_token_request = anzar_openapi.RefreshTokenRequest() # RefreshTokenRequest | 

    try:
        # Refresh access token
        api_response = api_instance.refresh_token(refresh_token_request)
        print("The response of AuthApi->refresh_token:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthApi->refresh_token: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **refresh_token_request** | [**RefreshTokenRequest**](RefreshTokenRequest.md)|  | 

### Return type

[**AuthResponse**](AuthResponse.md)

### Authorization

[session_auth](../README.md#session_auth), [bearer_auth](../README.md#bearer_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | New token issued |  -  |
**400** | invalid request |  -  |
**401** | Refresh token invalid or expired |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **register**
> AuthResponse register(register_request)

Register a new user

Creates a new user account with email and password.

**Session strategy**: Returns a session cookie (`id`) managed by the server.
**JWT strategy**: Returns `access` and `refresh` in the response body.

### Example


```python
import anzar_openapi
from anzar_openapi.models.auth_response import AuthResponse
from anzar_openapi.models.register_request import RegisterRequest
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)
    register_request = anzar_openapi.RegisterRequest() # RegisterRequest | User register credentials

    try:
        # Register a new user
        api_response = api_instance.register(register_request)
        print("The response of AuthApi->register:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthApi->register: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **register_request** | [**RegisterRequest**](RegisterRequest.md)| User register credentials | 

### Return type

[**AuthResponse**](AuthResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | User registerd successfully |  * Set-Cookie - Session cookie (session strategy only). HttpOnly, Secure, SameSite&#x3D;Strict. Format: id&#x3D;&lt;session_id&gt;; HttpOnly; Secure; SameSite&#x3D;Strict <br>  |
**400** | Invalid request |  -  |
**401** | Invalid credentials |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **render_reset_form**
> str render_reset_form(token)

Render password reset form

Validates the reset token from the email link and renders the password reset form.

### Example


```python
import anzar_openapi
from anzar_openapi.models.token_query import TokenQuery
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)
    token = anzar_openapi.TokenQuery() # TokenQuery | Password reset token

    try:
        # Render password reset form
        api_response = api_instance.render_reset_form(token)
        print("The response of AuthApi->render_reset_form:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthApi->render_reset_form: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | [**TokenQuery**](.md)| Password reset token | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/html, application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Reset form rendered |  -  |
**400** | invalid request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **request_password_reset**
> ResetLink request_password_reset(email_request)

Request a password reset

Sends a password reset link to the provided email address if an account exists.

### Example


```python
import anzar_openapi
from anzar_openapi.models.email_request import EmailRequest
from anzar_openapi.models.reset_link import ResetLink
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)
    email_request = anzar_openapi.EmailRequest() # EmailRequest | Email address to send the reset link to

    try:
        # Request a password reset
        api_response = api_instance.request_password_reset(email_request)
        print("The response of AuthApi->request_password_reset:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthApi->request_password_reset: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email_request** | [**EmailRequest**](EmailRequest.md)| Email address to send the reset link to | 

### Return type

[**ResetLink**](ResetLink.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Reset email sent if account exists |  -  |
**400** | invalid request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_new_password**
> submit_new_password(reset_password_request)

Submit new password

Submits a new password using a valid reset token. Invalidates the token after use.

### Example


```python
import anzar_openapi
from anzar_openapi.models.reset_password_request import ResetPasswordRequest
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.AuthApi(api_client)
    reset_password_request = anzar_openapi.ResetPasswordRequest() # ResetPasswordRequest | Reset token and the new password

    try:
        # Submit new password
        api_instance.submit_new_password(reset_password_request)
    except Exception as e:
        print("Exception when calling AuthApi->submit_new_password: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **reset_password_request** | [**ResetPasswordRequest**](ResetPasswordRequest.md)| Reset token and the new password | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**302** | Redirect to success page |  * Location - Redirect URL <br>  |
**400** | invalid request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

