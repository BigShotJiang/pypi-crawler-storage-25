# SameSiteConfig


## Enum

* `STRICT` (value: `'Strict'`)

* `LAX` (value: `'Lax'`)

* `NONE` (value: `'None'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


