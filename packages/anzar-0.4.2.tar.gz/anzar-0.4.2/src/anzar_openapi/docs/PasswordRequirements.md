# PasswordRequirements


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_length** | **int** |  | [optional] [default to 128]
**min_length** | **int** |  | [optional] [default to 8]
**require_number** | **bool** |  | [optional] [default to False]
**require_special_char** | **bool** |  | [optional] [default to False]
**require_uppercase** | **bool** |  | [optional] [default to False]

## Example

```python
from anzar_openapi.models.password_requirements import PasswordRequirements

# TODO update the JSON string below
json = "{}"
# create an instance of PasswordRequirements from a JSON string
password_requirements_instance = PasswordRequirements.from_json(json)
# print the JSON string representation of the object
print(PasswordRequirements.to_json())

# convert the object into a dict
password_requirements_dict = password_requirements_instance.to_dict()
# create an instance of PasswordRequirements from a dict
password_requirements_from_dict = PasswordRequirements.from_dict(password_requirements_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


