# CorsConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allow_credentials** | **bool** |  | [optional] [default to True]
**allowed_headers** | **List[str]** |  | [optional] [default to [authorization, content-type, accept, accept-language, Content-Language]]
**allowed_methods** | **List[str]** |  | [optional] [default to [GET, POST, PUT, DELETE, OPTIONS]]
**allowed_origins** | **List[str]** |  | [optional] [default to [localhost:3000]]
**enabled** | **bool** |  | [optional] [default to True]
**max_age** | **int** |  | [optional] [default to 3600]

## Example

```python
from anzar_openapi.models.cors_config import CorsConfig

# TODO update the JSON string below
json = "{}"
# create an instance of CorsConfig from a JSON string
cors_config_instance = CorsConfig.from_json(json)
# print the JSON string representation of the object
print(CorsConfig.to_json())

# convert the object into a dict
cors_config_dict = cors_config_instance.to_dict()
# create an instance of CorsConfig from a dict
cors_config_from_dict = CorsConfig.from_dict(cors_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


