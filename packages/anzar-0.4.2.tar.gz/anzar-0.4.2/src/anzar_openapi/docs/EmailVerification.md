# EmailVerification


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_redirect** | **str** |  | [optional] 
**required** | **bool** |  | [optional] [default to False]
**success_redirect** | **str** |  | [optional] 
**token_expires_in** | **int** |  | [optional] [default to 1800]

## Example

```python
from anzar_openapi.models.email_verification import EmailVerification

# TODO update the JSON string below
json = "{}"
# create an instance of EmailVerification from a JSON string
email_verification_instance = EmailVerification.from_json(json)
# print the JSON string representation of the object
print(EmailVerification.to_json())

# convert the object into a dict
email_verification_dict = email_verification_instance.to_dict()
# create an instance of EmailVerification from a dict
email_verification_from_dict = EmailVerification.from_dict(email_verification_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


