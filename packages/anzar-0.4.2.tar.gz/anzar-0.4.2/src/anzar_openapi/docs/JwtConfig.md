# JwtConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token_expires_in** | **int** |  | [optional] [default to 900]
**algorithm** | [**AlgorithmConfig**](AlgorithmConfig.md) |  | [optional] 
**audience** | **str** |  | [optional] [default to 'web-app']
**issuer** | **str** |  | [optional] [default to 'http://locahost:3000']
**refresh_token_expires_in** | **int** |  | [optional] [default to 604800]

## Example

```python
from anzar_openapi.models.jwt_config import JwtConfig

# TODO update the JSON string below
json = "{}"
# create an instance of JwtConfig from a JSON string
jwt_config_instance = JwtConfig.from_json(json)
# print the JSON string representation of the object
print(JwtConfig.to_json())

# convert the object into a dict
jwt_config_dict = jwt_config_instance.to_dict()
# create an instance of JwtConfig from a dict
jwt_config_from_dict = JwtConfig.from_dict(jwt_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


