# HttpsConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cert_path** | **str** |  | [optional] 
**enabled** | **bool** |  | [optional] [default to False]
**key_path** | **str** |  | [optional] 
**port** | **int** |  | [optional] [default to 3000]

## Example

```python
from anzar_openapi.models.https_config import HttpsConfig

# TODO update the JSON string below
json = "{}"
# create an instance of HttpsConfig from a JSON string
https_config_instance = HttpsConfig.from_json(json)
# print the JSON string representation of the object
print(HttpsConfig.to_json())

# convert the object into a dict
https_config_dict = https_config_instance.to_dict()
# create an instance of HttpsConfig from a dict
https_config_from_dict = HttpsConfig.from_dict(https_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


