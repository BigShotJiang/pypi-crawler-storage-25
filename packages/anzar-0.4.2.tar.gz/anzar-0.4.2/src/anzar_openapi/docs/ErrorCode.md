# ErrorCode


## Enum

* `INVALIDTOKEN` (value: `'InvalidToken'`)

* `TOKENNOTFOUND` (value: `'TokenNotFound'`)

* `TOKENEXPIRED` (value: `'TokenExpired'`)

* `TOKENALREADYUSED` (value: `'TokenAlreadyUsed'`)

* `TOKENCREATIONFAILED` (value: `'TokenCreationFailed'`)

* `TOKENREVOCATIONFAILED` (value: `'TokenRevocationFailed'`)

* `ACCOUNTNOTVERIFIED` (value: `'AccountNotVerified'`)

* `INVALIDCREDENTIALS` (value: `'InvalidCredentials'`)

* `MISSINGCREDENTIALS` (value: `'MissingCredentials'`)

* `ACCOUNTSUSPENDED` (value: `'AccountSuspended'`)

* `USERNOTFOUND` (value: `'UserNotFound'`)

* `RATELIMITEXCEEDED` (value: `'RateLimitExceeded'`)

* `EMAILSENDFAILED` (value: `'EmailSendFailed'`)

* `TLSCONFIG` (value: `'TlsConfig'`)

* `HASHINGFAILURE` (value: `'HashingFailure'`)

* `MALFORMEDDATA` (value: `'MalformedData'`)

* `DATABASEERROR` (value: `'DatabaseError'`)

* `INVALIDREQUEST` (value: `'InvalidRequest'`)

* `UNSUPPORTEDMEDIATYPE` (value: `'UnsupportedMediaType'`)

* `BADREQUEST` (value: `'BadRequest'`)

* `INTERNALSERVERERROR` (value: `'InternalServerError'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


