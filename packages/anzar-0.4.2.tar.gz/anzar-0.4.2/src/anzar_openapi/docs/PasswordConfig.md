# PasswordConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requirements** | [**PasswordRequirements**](PasswordRequirements.md) |  | [optional] 
**reset** | [**PasswordReset**](PasswordReset.md) |  | [optional] 
**security** | [**PasswordSecurity**](PasswordSecurity.md) |  | [optional] 

## Example

```python
from anzar_openapi.models.password_config import PasswordConfig

# TODO update the JSON string below
json = "{}"
# create an instance of PasswordConfig from a JSON string
password_config_instance = PasswordConfig.from_json(json)
# print the JSON string representation of the object
print(PasswordConfig.to_json())

# convert the object into a dict
password_config_dict = password_config_instance.to_dict()
# create an instance of PasswordConfig from a dict
password_config_from_dict = PasswordConfig.from_dict(password_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


