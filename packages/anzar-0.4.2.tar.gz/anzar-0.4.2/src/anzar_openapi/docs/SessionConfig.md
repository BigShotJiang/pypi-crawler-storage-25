# SessionConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**http_only** | **bool** |  | [optional] [default to True]
**max_age** | **int** |  | [optional] [default to 3600]
**name** | **str** |  | [optional] [default to 'id']
**same_site** | [**SameSiteConfig**](SameSiteConfig.md) |  | [optional] 
**secure** | **bool** |  | [optional] [default to True]

## Example

```python
from anzar_openapi.models.session_config import SessionConfig

# TODO update the JSON string below
json = "{}"
# create an instance of SessionConfig from a JSON string
session_config_instance = SessionConfig.from_json(json)
# print the JSON string representation of the object
print(SessionConfig.to_json())

# convert the object into a dict
session_config_dict = session_config_instance.to_dict()
# create an instance of SessionConfig from a dict
session_config_from_dict = SessionConfig.from_dict(session_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


