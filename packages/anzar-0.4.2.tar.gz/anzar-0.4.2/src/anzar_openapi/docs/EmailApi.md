# anzar_openapi.EmailApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**verify_email**](EmailApi.md#verify_email) | **GET** /email | Verify user email


# **verify_email**
> verify_email(token)

Verify user email

Validates the email token and update the user account.

### Example


```python
import anzar_openapi
from anzar_openapi.models.token_query import TokenQuery
from anzar_openapi.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = anzar_openapi.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with anzar_openapi.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = anzar_openapi.EmailApi(api_client)
    token = anzar_openapi.TokenQuery() # TokenQuery | Email Verification Token

    try:
        # Verify user email
        api_instance.verify_email(token)
    except Exception as e:
        print("Exception when calling EmailApi->verify_email: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | [**TokenQuery**](.md)| Email Verification Token | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**302** | Redirect to success page |  * Location - Redirect URL <br>  |
**400** | invalid request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

