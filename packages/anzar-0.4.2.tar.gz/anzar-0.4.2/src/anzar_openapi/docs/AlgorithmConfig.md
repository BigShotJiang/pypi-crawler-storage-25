# AlgorithmConfig


## Enum

* `HS256` (value: `'HS256'`)

* `HS384` (value: `'HS384'`)

* `HS512` (value: `'HS512'`)

* `ES256` (value: `'ES256'`)

* `ES384` (value: `'ES384'`)

* `RS256` (value: `'RS256'`)

* `RS384` (value: `'RS384'`)

* `RS512` (value: `'RS512'`)

* `PS256` (value: `'PS256'`)

* `PS384` (value: `'PS384'`)

* `PS512` (value: `'PS512'`)

* `EDDSA` (value: `'EdDSA'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


