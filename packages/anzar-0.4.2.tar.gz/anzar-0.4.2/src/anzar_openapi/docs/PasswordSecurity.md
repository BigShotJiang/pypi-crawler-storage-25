# PasswordSecurity


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lockout_duration** | **int** |  | [optional] [default to 1800]
**max_failed_attempts** | **int** |  | [optional] [default to 5]

## Example

```python
from anzar_openapi.models.password_security import PasswordSecurity

# TODO update the JSON string below
json = "{}"
# create an instance of PasswordSecurity from a JSON string
password_security_instance = PasswordSecurity.from_json(json)
# print the JSON string representation of the object
print(PasswordSecurity.to_json())

# convert the object into a dict
password_security_dict = password_security_instance.to_dict()
# create an instance of PasswordSecurity from a dict
password_security_from_dict = PasswordSecurity.from_dict(password_security_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


