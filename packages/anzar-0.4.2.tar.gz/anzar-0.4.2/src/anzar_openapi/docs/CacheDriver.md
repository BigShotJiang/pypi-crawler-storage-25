# CacheDriver


## Enum

* `MEMCACHED` (value: `'MemCached'`)

* `REDIS` (value: `'Redis'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


