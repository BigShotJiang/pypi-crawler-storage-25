# TokenQuery


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **str** |  | 

## Example

```python
from anzar_openapi.models.token_query import TokenQuery

# TODO update the JSON string below
json = "{}"
# create an instance of TokenQuery from a JSON string
token_query_instance = TokenQuery.from_json(json)
# print the JSON string representation of the object
print(TokenQuery.to_json())

# convert the object into a dict
token_query_dict = token_query_instance.to_dict()
# create an instance of TokenQuery from a dict
token_query_from_dict = TokenQuery.from_dict(token_query_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


