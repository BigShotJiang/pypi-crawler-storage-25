# AnzarConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**app** | [**App**](App.md) |  | 
**auth** | [**Authentication**](Authentication.md) |  | [optional] 
**database** | [**Database**](Database.md) |  | 
**security** | [**Security**](Security.md) |  | 
**server** | [**Server**](Server.md) |  | [optional] 

## Example

```python
from anzar_openapi.models.anzar_configuration import AnzarConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AnzarConfiguration from a JSON string
anzar_configuration_instance = AnzarConfiguration.from_json(json)
# print the JSON string representation of the object
print(AnzarConfiguration.to_json())

# convert the object into a dict
anzar_configuration_dict = anzar_configuration_instance.to_dict()
# create an instance of AnzarConfiguration from a dict
anzar_configuration_from_dict = AnzarConfiguration.from_dict(anzar_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


