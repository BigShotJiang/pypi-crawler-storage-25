from anzar.adapters.memory_storage import MemoryStorage
from anzar.adapters.base_storage import BaseStorage


def __getattr__(name):
    if name == "RedisStorage":
        from anzar.adapters.redis_storage import RedisStorage

        return RedisStorage
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["BaseStorage", "MemoryStorage", "RedisStorage"]
