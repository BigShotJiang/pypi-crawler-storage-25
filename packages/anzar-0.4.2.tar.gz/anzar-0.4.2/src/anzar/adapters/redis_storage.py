from anzar_openapi.models import SessionTokens
from anzar.adapters.base_storage import BaseStorage

try:
    from redis import Redis
except ImportError:
    raise ImportError(
        "Redis support requires the 'redis' extra. \n"
        "Install it with: \n"
        " pip install anzar[redis] \n"
        "or with: \n"
        " uv add anzar[redis]"
    )


ACCESS = "accessToken"
REFRESH = "refreshToken"
COOKIE = "cookie"


class RedisStorage(BaseStorage):
    def __init__(self, redis: Redis):
        self.redis = redis

    def get_token(self) -> str | None:
        from typing import cast

        return cast(str | None, self.redis.get(ACCESS))

    def get_refresh_token(self) -> str | None:
        from typing import cast

        return cast(str | None, self.redis.get(REFRESH))

    def on_token_refresh(self, tokens: SessionTokens) -> None:
        self.redis.set(ACCESS, tokens.access)
        self.redis.set(REFRESH, tokens.refresh)

    def on_session_expired(self) -> None:
        self.redis.delete(ACCESS)
        self.redis.delete(REFRESH)

    def on_logout(self) -> None:
        self.redis.delete(ACCESS)
        self.redis.delete(REFRESH)
        self.redis.delete(COOKIE)

    def get_cookie(self) -> str | None:
        from typing import cast

        return cast(str | None, self.redis.get(COOKIE))

    def store_cookie(self, cookie: str) -> None:
        self.redis.set(COOKIE, cookie)
