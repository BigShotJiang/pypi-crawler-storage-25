from anzar_openapi.models import SessionTokens
from abc import abstractmethod, ABC


class BaseStorage(ABC):
    @abstractmethod
    def get_token(self) -> str | None:
        pass

    @abstractmethod
    def get_refresh_token(self) -> str | None:
        pass

    @abstractmethod
    def on_token_refresh(self, tokens: SessionTokens) -> None:
        pass

    @abstractmethod
    def on_session_expired(self) -> None:
        pass

    @abstractmethod
    def on_logout(self) -> None:
        pass

    @abstractmethod
    def get_cookie(self) -> str | None:
        pass

    @abstractmethod
    def store_cookie(self, cookie: str) -> str | None:
        pass
