from anzar_openapi.models import SessionTokens
from anzar.adapters.base_storage import BaseStorage


class MemoryStorage(BaseStorage):
    def __init__(self, access: str | None = None, refresh: str | None = None):
        self.access_token = access
        self.refresh_token = refresh
        self.cookie = None

    def get_token(self) -> str | None:
        return self.access_token

    def get_refresh_token(self) -> str | None:
        return self.refresh_token

    def on_token_refresh(self, tokens: SessionTokens) -> None:
        self.access_token = tokens.access
        self.refresh_token = tokens.refresh

    def on_session_expired(self) -> None:
        self.access_token = None
        self.refresh_token = None

    def on_logout(self) -> None:
        self.access_token = None
        self.refresh_token = None
        self.cookie = None

    def get_cookie(self) -> str | None:
        return self.cookie

    def store_cookie(self, cookie: str) -> str | None:
        self.cookie = cookie
