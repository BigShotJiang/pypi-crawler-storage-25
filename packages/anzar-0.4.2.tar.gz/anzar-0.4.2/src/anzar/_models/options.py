from anzar.adapters.base_storage import BaseStorage
from dataclasses import dataclass


@dataclass
class SdkOptions:
    storage: BaseStorage
