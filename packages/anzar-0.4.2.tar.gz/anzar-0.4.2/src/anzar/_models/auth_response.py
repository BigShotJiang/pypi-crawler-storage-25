from dataclasses import dataclass
from anzar_openapi import User, Verification


@dataclass
class AuthResult:
    user: User
    verification: Verification | None
