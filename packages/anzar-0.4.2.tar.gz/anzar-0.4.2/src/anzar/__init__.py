from anzar._models.options import SdkOptions
from anzar.adapters.memory_storage import MemoryStorage
from anzar.api.auth import AuthModule
from anzar.api.interceptor import Interceptor

from anzar_openapi import (
    ApiClient,
    AuthApi,
    Configuration,
    EmailApi,
    UsersApi,
    AnzarConfiguration,
    AuthStrategy,
)


# import logging
# import http.client

DEFAULT_OPTIONS = SdkOptions(storage=MemoryStorage())

# http.client.HTTPConnection.debuglevel = 1
# logging.basicConfig(level=logging.DEBUG)


class Anzar:
    def __init__(
        self, anzar_config: AnzarConfiguration, options: SdkOptions = DEFAULT_OPTIONS
    ):
        self._config = anzar_config
        self._options = options

        self._configuration = Configuration(host=anzar_config.app.url)
        self._client = self._build_client()

        self._auth_api = AuthApi(self._client)
        self._users_api = UsersApi(self._client)
        self._email_api = EmailApi(self._client)

        self.Auth = AuthModule(
            self._auth_api,
            self._users_api,
            self._config,
            self._options,
        )
        self.User = self._users_api
        self.Email = self._email_api

    def _build_client(self) -> ApiClient:
        cookie = self._options.storage.get_cookie()
        cookie_name = (
            self._config.auth.session.name
            if self._config.auth
            and self._config.auth.session
            and self._config.auth.session.name
            else "id"
        )

        if self._config.auth and self._config.auth.strategy == AuthStrategy.JWT:
            client = Interceptor(self._options, self._configuration)
            client.base_path = self._config.app.url
            client.cookie = f"{cookie_name}={cookie}"
            return client

        return ApiClient(
            configuration=self._configuration, cookie=f"{cookie_name}={cookie}"
        )


__all__ = ["Anzar"]
