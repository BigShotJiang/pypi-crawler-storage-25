from __future__ import annotations

import logging
from functools import wraps
from typing import Callable

import jwt
from flask import g, jsonify, request

from anzar_openapi.models import AnzarConfiguration, Role

logger = logging.getLogger(__name__)

_DEFAULT_ALGORITHM = "HS256"
_DEFAULT_AUDIENCE = "web-app"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_algorithm(configuration: AnzarConfiguration) -> str:
    """Return the JWT algorithm from config, falling back to the default."""
    if (
        configuration.auth
        and configuration.auth.jwt
        and configuration.auth.jwt.algorithm
    ):
        return configuration.auth.jwt.algorithm
    return _DEFAULT_ALGORITHM


def _get_audience(configuration: AnzarConfiguration) -> str:
    """Return the JWT audience from config, falling back to the default."""
    if (
        configuration.auth
        and configuration.auth.jwt
        and configuration.auth.jwt.audience
    ):
        return configuration.auth.jwt.audience
    return _DEFAULT_AUDIENCE


def _extract_bearer_token() -> str | None:
    """Extract the Bearer token from the Authorization header, or return None."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None
    token = auth_header.removeprefix("Bearer ").strip()
    return token or None


def _decode_token(
    token: str,
    configuration: AnzarConfiguration,
) -> tuple[dict, None] | tuple[None, tuple]:
    """
    Decode and validate a JWT token.

    Returns ``(payload, None)`` on success, or ``(None, (error_response, status_code))``
    on failure so callers can return the error directly.
    """
    algorithm = _get_algorithm(configuration)
    audience = _get_audience(configuration)

    try:
        payload = jwt.decode(
            token,
            key=configuration.security.secret_key,
            algorithms=[algorithm],
            audience=audience,
        )
        return payload, None

    except jwt.ExpiredSignatureError:
        logger.warning("JWT validation failed: token has expired")
        return None, (jsonify({"error": "Token has expired"}), 401)

    except jwt.InvalidTokenError as exc:
        logger.warning("JWT validation failed: %s", exc)
        return None, (jsonify({"error": "Invalid token"}), 403)


# ---------------------------------------------------------------------------
# Public decorators
# ---------------------------------------------------------------------------


def require_auth(configuration: AnzarConfiguration) -> Callable:
    """
    Decorator that requires a valid JWT in the Authorization header.

    On success, sets ``flask.g.user_id`` to the ``sub`` claim of the token.
    """

    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):

            token = _extract_bearer_token()
            if not token:
                return jsonify({"error": "No token provided"}), 401

            payload, error = _decode_token(token, configuration)
            if error is not None:
                return error

            assert payload is not None
            g.user_id = payload.get("sub", "")
            return f(*args, **kwargs)

        return decorated

    return decorator


def requires_role(role: Role, configuration: AnzarConfiguration):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            token = _extract_bearer_token()
            if not token:
                return jsonify({"error": "No token provided"}), 401

            payload, error = _decode_token(token, configuration)
            if error is not None:
                return error

            assert payload is not None
            if payload.get("role") != role:
                logger.warning(
                    "Access denied: required role %r, got %r",
                    role,
                    payload.get("role"),
                )
                return jsonify({"error": "Forbidden"}), 403

            g.user_id = payload.get("sub", "")
            return f(*args, **kwargs)

        return decorated

    return decorator
