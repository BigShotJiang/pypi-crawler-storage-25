import re
from anzar._models.auth_response import AuthResult
from .._models.options import SdkOptions

from anzar_openapi import AuthApi, UsersApi, ResetLink, AnzarConfiguration

from anzar_openapi.exceptions import ApiException
from anzar_openapi.models import (
    AuthResponse,
    LoginRequest,
    RegisterRequest,
    RefreshTokenRequest,
    EmailRequest,
    Session,
    AuthStrategy,
)


class AuthModule:
    def __init__(
        self,
        auth_api: AuthApi,
        users_api: UsersApi,
        config: AnzarConfiguration,
        options: SdkOptions,
    ):
        self.auth_api = auth_api
        self.users_api = users_api
        self.config = config
        self.options = options

    def _extract_cookie(self, response) -> str | None:
        cookie_name = (
            self.config.auth.session.name
            if self.config.auth
            and self.config.auth.session
            and self.config.auth.session.name
            else "id"
        )

        set_cookie = (
            response.headers.get("set-cookie", f"{cookie_name}=XX")
            if response.headers
            else f"{cookie_name}=XX"
        )

        match_obj = re.search(rf"{re.escape(cookie_name)}=([^;]+)", set_cookie)
        if match_obj is None:
            return None

        return match_obj.group(1)

    def _default_auth_strategy(self) -> AuthStrategy | None:
        return self.config.auth.strategy if self.config.auth else AuthStrategy.SESSION

    def login(self, body: LoginRequest) -> AuthResult:
        response = self.auth_api.login_with_http_info(body)
        auth_response: AuthResponse = response.data

        if auth_response.tokens:
            self.options.storage.on_token_refresh(auth_response.tokens)

        session_id = self._extract_cookie(response)
        if session_id:
            self.options.storage.store_cookie(session_id)

        return AuthResult(
            user=auth_response.user, verification=auth_response.verification
        )

    def register(self, body: RegisterRequest) -> AuthResult:
        response = self.auth_api.register_with_http_info(body)
        auth_response: AuthResponse = response.data

        if auth_response.tokens:
            self.options.storage.on_token_refresh(auth_response.tokens)

        session_id = self._extract_cookie(response)
        if session_id:
            self.options.storage.store_cookie(session_id)

        return AuthResult(
            user=auth_response.user, verification=auth_response.verification
        )

    def logout(self) -> None:
        refresh_token: str | None = self.options.storage.get_refresh_token()
        refresh_token: str = refresh_token if refresh_token else ""

        self.auth_api.logout(RefreshTokenRequest(refresh_token=refresh_token))
        self.options.storage.on_logout()

    def reset_password(self, body: EmailRequest) -> ResetLink:
        response = self.auth_api.request_password_reset(body)
        return response

    def is_authenticated(self) -> bool:
        try:
            user = self.users_api.find_user()
            return bool(user and user.username)
        except ApiException as e:
            if e.status == 401:
                return False
            raise

    def session(self) -> Session:
        if self._default_auth_strategy() == AuthStrategy.JWT:
            raise ValueError("session() is only available with Session auth strategy")

        return self.auth_api.get_session()
