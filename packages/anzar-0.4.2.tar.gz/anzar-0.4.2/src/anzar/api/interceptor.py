from anzar_openapi.rest import RESTResponse
import requests
from anzar.types import SdkOptions
from urllib.parse import urlparse
from anzar_openapi import ApiClient, Configuration
from anzar_openapi.models import AuthResponse


class Interceptor(ApiClient):
    def __init__(self, options: SdkOptions, configuration: Configuration):
        super().__init__(configuration)
        self.options = options
        self.base_path: str = "localhost:3000"
        self.REFRESH_URI = "/auth/refresh-token"
        self.excluded_uri = [self.REFRESH_URI, "/auth/login", "/auth/register"]

    def call_api(self, *args, **kwargs):
        path = args[1] if len(args) > 0 else None
        resource_path = urlparse(path).path
        is_endpoint_excluded = resource_path in self.excluded_uri

        access_token: str | None = self.options.storage.get_token()
        if not is_endpoint_excluded and access_token:
            args[2]["authorization"] = f"Bearer {access_token}"

        response = super().call_api(*args, **kwargs)
        if response.status != 401 or is_endpoint_excluded:
            return response

        return self._handle_token_refresh(response, args, kwargs)

    def _handle_token_refresh(self, original_response: RESTResponse, args, kwargs):
        refresh_token = self.options.storage.get_refresh_token()
        if not refresh_token:
            return original_response

        try:
            original_response = requests.post(
                f"{self.base_path}{self.REFRESH_URI}",
                json={"refresh_token": refresh_token},
            )
            original_response.raise_for_status()
            auth_response = AuthResponse(**original_response.json())
        except Exception as _:
            self.options.storage.on_session_expired()
            return original_response

        if not auth_response.tokens:
            return original_response

        self.options.storage.on_token_refresh(auth_response.tokens)
        self.configuration.access_token = auth_response.tokens.access
        args[2]["authorization"] = f"Bearer {auth_response.tokens.access}"

        # Retry the call once NOTE maybe add original_response.read()
        return super().call_api(*args, **kwargs)
