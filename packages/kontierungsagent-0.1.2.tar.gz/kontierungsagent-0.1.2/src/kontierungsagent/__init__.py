#!/usr/bin/env python3
"""
Kontierungsagent — Zero-Setup MCP-Client via uvx
=================================================
HTTP-MCP-Proxy zum Render Cloud Server.
Reiner API-Key, kein Google-Auth.

Kunden-Config (Claude Desktop / Cursor):
{
  "mcpServers": {
    "kontierungsagent": {
      "command": "uvx",
      "args": ["kontierungsagent"],
      "env": {
        "KONT_API_KEY": "key-vom-anbieter"
      }
    }
  }
}
"""

import os
import sys
import json
import asyncio
import urllib.request
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

# ── Konfiguration ─────────────────────────────────────────────────
SERVER_URL = os.environ.get("KONT_URL", "https://kontierungsagent-v3.onrender.com/mcp")
API_KEY = os.environ.get("KONT_API_KEY", "")

proxy = Server("kontierungsagent")


def call_server(method: str, params: dict | None = None) -> dict:
    """JSON-RPC HTTP POST zum Cloud-Server."""
    body = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params:
        body["params"] = params

    req = urllib.request.Request(
        SERVER_URL,
        data=json.dumps(body).encode("utf-8"),
        headers={"X-API-Key": API_KEY, "Content-Type": "application/json"},
        method="POST",
    )
    
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": str(e)}}


async def run():
    if not API_KEY:
        print("❌ KONT_API_KEY nicht gesetzt!", file=sys.stderr)
        sys.exit(1)

    @proxy.list_tools()
    async def list_tools():
        result = call_server("tools/list")
        if "result" in result:
            return [Tool(name=t["name"], description=t["description"],
                         inputSchema=t.get("inputSchema", {"type": "object", "properties": {}}))
                    for t in result["result"].get("tools", [])]
        return []

    @proxy.call_tool()
    async def call_tool(name: str, arguments: dict):
        result = call_server("tools/call", {"name": name, "arguments": arguments})
        if "result" in result:
            return [TextContent(type="text", text=c.get("text", ""))
                    for c in result["result"].get("content", [])]
        return [TextContent(type="text", text=f"❌ {result.get('error', {}).get('message', 'Fehler')}")]

    options = proxy.create_initialization_options()
    async with stdio_server() as (read, write):
        await proxy.run(read, write, options, raise_exceptions=True)


def main():
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"❌ Fehler: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
