# Kontierungsagent v3 — Direct-Context (RAG-Less)

> Ein hocheffizienter, RAG-freier Buchhaltungs-Kontierungsagent für die deutsche SKR03-Kontierung mit Google Gemini 3.5 Flash.

Dieses Projekt folgt dem KISS-Prinzip (Keep It Simple, Stupid). Statt komplexer RAG-Infrastrukturen (Vektordatenbanken, Embeddings, SQLite-Indexierung) lädt dieses Tool das komplette, strukturierte Kontierungs-Wiki direkt in das großzügige Kontextfenster von Gemini 3.5 Flash. Das führt zu maximaler Präzision, voller Kontextsensitivität und extrem schnellen Antwortzeiten – ganz ohne Indexierungsaufwand.

## Architektur

```
raw/           ← Layer 1: Unveränderte Quellen (Lehrbuch-PDFs, Dumps)
  lehrbuch/    ←   Lehrbuch-Beispiele (Rohdaten)
  docs/        ←   SKR03/04, Kontierungsrichtlinien
  belege/      ←   Echte Belege (anonymisiert)
wiki/          ← Layer 2: Strukturiertes Wissen
  rules/       ←   Extraktionsregeln (z.B. "Tankquittung → Konto 4530")
  beispiele/   ←   Synthetische Beispiele aus Regeln generiert
  mappings/    ←   Kategorie → Konto Mappings
schema/        ← Layer 3: CLAUDE.md = Schema + Spielregeln für LLM
cli/           ← CLI-Tool (Direct-Context): "python3 cli/kontier.py <Belegtext>"
```

## Features

- **RAG-Less (Direct-Context):** Kein Overhead durch Embedding-Modelle, Vektor-Suchen oder SQLite-Datenbanken. Das gesamte Wiki wird direkt geladen.
- **Kontextsensitiv:** Gemini versteht die Buchungsregeln und Beispiele im vollen Kontext des Wikis.
- **Transparente Begründungen:** Der Agent liefert die passende Regelnummer (z.B. `KFZ-001`), das SKR03-Konto, den korrekten Vorsteuersatz (19% / 7% / steuerfrei) und vergleicht den Beleg mit passenden Beispielen.
- **Minimalistische Abhängigkeiten:** Extrem leichtgewichtig – benötigt nur `google-generativeai` und `rich` für die Terminal-Formatierung.

## Setup & Installation

1. **Abhängigkeiten installieren:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Gemini API-Key einrichten:**
   Setze deine `GEMINI_API_KEY` Umgebungsvariable:
   ```bash
   export GEMINI_API_KEY="dein-api-key"
   ```

## Nutzung

Führe das Hauptskript einfach mit dem zu prüfenden Belegtext aus:

```bash
python3 cli/kontier.py "Tankrechnung Aral 85,30€"
```

Der Agent analysiert den Beleg in Echtzeit und gibt das Ergebnis formatiert im Terminal aus:
- **Konto:** z.B. **4530 — Laufende Kfz-Betriebskosten**
- **Regel:** z.B. **KFZ-001**
- **Vorsteuer:** z.B. **19%**
- **Begründung & Beispiele**

## Status

- [x] Projektstruktur
- [x] Schema (CLAUDE.md)
- [x] Direct-Context CLI (`cli/kontier.py`)
- [x] RAG-Infrastruktur bereinigt (sentence-transformers / SQLite entfernt)
- [ ] Lehrbuch-Daten einpflegen
- [ ] Regeln extrahieren (LLM)
- [ ] Synthetische Beispiele generieren
