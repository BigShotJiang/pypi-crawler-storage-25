"""Mixin providing schema/property resolution helpers for QuestraData."""

from __future__ import annotations

from typing import Any

from .inventory_registry import (
    InventoryRegistry,
    InventorySchema,
    normalize_system_key,
    resolve_field_name,
)


class _SchemaResolutionMixin:
    """Schema and property resolution methods extracted from QuestraData."""

    _registry: InventoryRegistry

    @staticmethod
    def _remap_response(
        items: list[dict[str, Any]],
        name_mapping: dict[str, str],
    ) -> list[dict[str, Any]]:
        """Replace fieldName keys in response items with original property names.

        Recursively remaps nested dicts (e.g. TimeSeries sub-objects).
        System fields (``_id``, ``_rowVersion``) are not in ``name_mapping``
        and pass through unchanged.

        Args:
            items: GraphQL response items with fieldName keys.
            name_mapping: ``fieldName → original name`` mapping from schema.

        Returns:
            Items with original property names as keys.
        """

        def remap(item: dict[str, Any]) -> dict[str, Any]:
            return {
                name_mapping.get(k, k): (
                    remap(v)
                    if isinstance(v, dict)
                    else [remap(x) if isinstance(x, dict) else x for x in v]
                    if isinstance(v, list)
                    else v
                )
                for k, v in item.items()
            }

        return [remap(item) for item in items]

    def _get_nested_schema(
        self,
        inventory_name_for_schema: str,
        namespace_name: str | None,
    ) -> InventorySchema | None:
        """Get nested inventory schema with case-insensitive inventory fallback."""
        try:
            return self._registry.get(inventory_name_for_schema, namespace_name)
        except ValueError:
            pass

        # Fall back to case-insensitive inventory name lookup in the same namespace.
        self._registry.load_all()
        candidate = inventory_name_for_schema.lower()
        ns_key = namespace_name or ""
        for cache_key in self._registry.cached_keys:
            key_ns, _, key_inventory = cache_key.partition("::")
            if key_ns == ns_key and key_inventory.lower() == candidate:
                return self._registry.get(key_inventory, namespace_name)
        return None

    def _resolve_property_segments(
        self,
        segments: list[str],
        current_schema: InventorySchema,
        namespace_name: str | None,
    ) -> str:
        """Resolve each path segment to authoritative fieldNames."""
        # System fields (starting with _) are not in the schema; normalize directly.
        if segments[0].startswith("_"):
            resolved_field = normalize_system_key(segments[0])
            if len(segments) == 1:
                return resolved_field
            # System fields have no nested sub-schemas; keep trailing segments.
            return f"{resolved_field}.{'.'.join(segments[1:])}"

        resolved_field = resolve_field_name(segments[0], current_schema)
        if len(segments) == 1:
            return resolved_field

        # Scalar/Timeseries fields do not provide nested schema metadata.
        # Keep trailing segments as provided (e.g. "messwerte_temperatur.id").
        if resolved_field in current_schema.field_types:
            return f"{resolved_field}.{'.'.join(segments[1:])}"

        next_inventory_name = current_schema.name_mapping.get(
            resolved_field, resolved_field
        )
        nested_schema = self._get_nested_schema(next_inventory_name, namespace_name)
        if nested_schema is None:
            return f"{resolved_field}.{'.'.join(segments[1:])}"

        return (
            f"{resolved_field}."
            f"{self._resolve_property_segments(segments[1:], nested_schema, namespace_name)}"
        )

    def _canonicalize_property_segments(
        self,
        segments: list[str],
        current_schema: InventorySchema,
        namespace_name: str | None,
    ) -> str:
        """Canonicalize each path segment to schema property names."""
        # System fields (starting with _) are not in the schema; normalize directly.
        if segments[0].startswith("_"):
            canonical_name = normalize_system_key(segments[0])
            if len(segments) == 1:
                return canonical_name
            # System fields have no nested sub-schemas; keep trailing segments.
            return f"{canonical_name}.{'.'.join(segments[1:])}"

        resolved_field = resolve_field_name(segments[0], current_schema)
        canonical_name = current_schema.name_mapping.get(resolved_field, resolved_field)
        if len(segments) == 1:
            return canonical_name

        # Scalar/Timeseries fields do not provide nested schema metadata.
        # Keep trailing segments as provided for header readability.
        if resolved_field in current_schema.field_types:
            return f"{canonical_name}.{'.'.join(segments[1:])}"

        nested_schema = self._get_nested_schema(canonical_name, namespace_name)
        if nested_schema is None:
            return f"{canonical_name}.{'.'.join(segments[1:])}"

        return (
            f"{canonical_name}."
            f"{self._canonicalize_property_segments(segments[1:], nested_schema, namespace_name)}"
        )

    def _map_property_path(
        self,
        property_path: str,
        schema: InventorySchema,
        namespace_name: str | None,
    ) -> tuple[str, str]:
        """Map user property path to query field path and canonical path."""
        segments = property_path.split(".")
        query_path = self._resolve_property_segments(segments, schema, namespace_name)
        canonical_path = self._canonicalize_property_segments(
            segments, schema, namespace_name
        )
        return query_path, canonical_path

    def _validate_and_resolve_properties(
        self,
        properties: list[str],
        schema: InventorySchema,
        inventory_name: str,
        namespace_name: str | None = None,
    ) -> tuple[list[str], InventorySchema]:
        """Resolve user-supplied property names to fieldNames, with auto-refresh.

        Dot-notation properties have all segments resolved recursively via
        sub-inventory schemas from the registry (if available).

        Args:
            properties: User-supplied property names (may use original names).
            schema: Current inventory schema.
            inventory_name: Inventory name (for cache refresh if needed).
            namespace_name: Optional namespace qualifier.

        Returns:
            Tuple of ``(resolved_field_names, schema)`` where schema may be
            refreshed if the first resolution attempt failed.

        Raises:
            ValueError: If a property cannot be resolved even after schema refresh.
        """

        def _resolve_segments(segments: list[str], s: InventorySchema) -> str:
            return self._resolve_property_segments(segments, s, namespace_name)

        def _resolve_list(props: list[str], s: InventorySchema) -> list[str]:
            return [_resolve_segments(prop.split("."), s) for prop in props]

        try:
            return _resolve_list(properties, schema), schema
        except ValueError:
            # Schema might be stale – refresh and retry once
            self._registry.refresh(inventory_name, namespace_name)
            schema = self._registry.get(inventory_name, namespace_name)

        # Second attempt with refreshed schema – ValueError propagates cleanly (no chaining)
        return _resolve_list(properties, schema), schema
