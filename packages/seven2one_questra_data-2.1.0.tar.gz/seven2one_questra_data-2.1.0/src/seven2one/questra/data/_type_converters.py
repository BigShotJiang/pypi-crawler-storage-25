"""Shared parser functions for GraphQL scalar type conversion."""

from datetime import time
from decimal import Decimal


def _parse_time(v: str | time) -> time:
    """Parse server TimeOnly format 'HH:mm:ss.fff' to datetime.time.

    The server sends TimeSpan scalars as 'HH:mm:ss.fff' (3 ms digits).
    Python's time.fromisoformat() requires 0 or 6 fractional digits.
    """
    if isinstance(v, time):
        return v
    if "." in v:
        base, ms = v.rsplit(".", 1)
        v = f"{base}.{ms.ljust(6, '0')}"
    return time.fromisoformat(v)


def _parse_decimal(v: str | float | int | Decimal) -> Decimal:
    """Convert string-serialized GraphQL Decimal scalar to decimal.Decimal."""
    return Decimal(str(v))


def _parse_int_string(v: str | int) -> int:
    """Convert string-serialized GraphQL Long/UInt scalar to int."""
    return int(v)
