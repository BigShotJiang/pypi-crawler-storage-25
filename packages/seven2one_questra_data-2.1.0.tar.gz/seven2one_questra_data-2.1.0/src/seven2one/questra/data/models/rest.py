"""REST API models - Re-exports from generated REST models."""

from __future__ import annotations

# For compatibility - QuotationsPayload and TimeSeriesDataPayload are not generated
# These are manually defined as wrappers, as they are not in the Swagger schema
from dataclasses import dataclass, field

# Re-exports from generated.rest_models
from ..generated.rest_models import (
    ErrorPayload,
    ErrorsPayload,
    File,
    Quotations,
    QuotationValue,
    ServiceVersion,
    SetTimeSeriesDataInput,
    TimeSeriesData,
    TimeSeriesPayload,
    TimeSeriesValue,
)


@dataclass
class QuotationsPayload:
    """
    Quotations payload.

    Attributes:
        items: List of quotations
    """

    items: list[Quotations] = field(default_factory=list)


@dataclass
class TimeSeriesDataPayload:
    """
    Time series data payload.

    Attributes:
        data: List of time series data
        truncated: True if the server returned an ``ErrorsPayload`` indicating
            that the global 180 000-value limit was reached and some series
            are missing from the response.
    """

    data: list[TimeSeriesData] = field(default_factory=list)
    truncated: bool = False


__all__ = [
    "ErrorPayload",
    "ErrorsPayload",
    "File",
    "Quotations",
    "QuotationsPayload",
    "QuotationValue",
    "ServiceVersion",
    "SetTimeSeriesDataInput",
    "TimeSeriesData",
    "TimeSeriesDataPayload",
    "TimeSeriesValue",
    "TimeSeriesPayload",
]
