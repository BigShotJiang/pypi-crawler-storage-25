"""FileUpload wrapper for automatic file upload in create_items()/update_items()."""

from __future__ import annotations

import mimetypes
from dataclasses import dataclass, field
from pathlib import Path
from typing import BinaryIO


@dataclass
class FileUpload:
    """Wraps a file for automatic upload in ``create_items()``/``update_items()``.

    ``create_items()`` and ``update_items()`` detect ``FileUpload`` values on FILE
    properties, upload the file, and replace the value with the returned ``int`` ID.
    Pass an ``int`` directly to reuse an already-uploaded file without re-uploading.

    Args:
        file_data: File path (``str``/``Path``) or open binary file object (``BinaryIO``).
        filename: Sent to the server. Auto-derived from path when ``None``.
        content_type: MIME type. Auto-detected via ``mimetypes`` from path/filename;
            falls back to ``"application/octet-stream"``.

    Example:
        ```python
        {"Document": FileUpload("/path/to/report.pdf")}
        {
            "Document": FileUpload(
                buf, filename="scan.pdf", content_type="application/pdf"
            )
        }
        {"Document": 42}  # reuse existing file ID
        ```
    """

    file_data: str | Path | BinaryIO
    filename: str | None = field(default=None)
    content_type: str | None = field(default=None)

    def resolve_filename(self) -> str:
        """Return the filename to send to the server.

        Returns:
            The explicit ``filename`` if set, otherwise the basename of the path.

        Raises:
            ValueError: If ``file_data`` is a file object and ``filename`` is not set.
        """
        if self.filename is not None:
            return self.filename
        if isinstance(self.file_data, (str, Path)):
            return Path(self.file_data).name
        raise ValueError(
            "FileUpload.filename must be provided when file_data is a file object."
        )

    def resolve_content_type(self) -> str:
        """Return the MIME type to send to the server.

        Returns:
            The explicit ``content_type`` if set, otherwise auto-detected from the
            filename or path; falls back to ``"application/octet-stream"``.
        """
        if self.content_type is not None:
            return self.content_type
        try:
            name = self.resolve_filename()
        except ValueError:
            return "application/octet-stream"
        mime, _ = mimetypes.guess_type(name)
        return mime or "application/octet-stream"
