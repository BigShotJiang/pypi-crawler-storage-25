"""Pagination utilities for Questra Data."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from typing import Any, Generic, TypeVar

T = TypeVar("T")


class PagedIterator(Generic[T]):
    """Generic iterator for automatic pagination of API responses.

    Loads pages lazily on demand and iterates efficiently over items
    using index-based access (O(1) per item).

    Examples:
        ```python
        # With dict-based response (inventory.list)
        iterator = PagedIterator(
            fetch_page=lambda after: self._client.inventory.list(
                inventory_name=name, properties=props, first=100, after=after
            ),
            extract_items=lambda result: result.get("nodes", []),
            has_next_page=lambda result: result.get("pageInfo", {}).get(
                "hasNextPage", False
            ),
            get_cursor=lambda result: result.get("pageInfo", {}).get("endCursor"),
        )

        for item in iterator:
            print(item)
        ```
    """

    def __init__(
        self,
        fetch_page: Callable[[str | None], Any],
        extract_items: Callable[[Any], list[T]],
        has_next_page: Callable[[Any], bool],
        get_cursor: Callable[[Any], str | None],
    ):
        """Initialize paged iterator.

        Args:
            fetch_page: Fetches a page. Receives cursor (or None), returns page result.
            extract_items: Extracts items from a page result.
            has_next_page: Returns True if more pages exist.
            get_cursor: Returns the next pagination cursor from a page result.
        """
        self._fetch_page = fetch_page
        self._extract_items = extract_items
        self._has_next_page = has_next_page
        self._get_cursor = get_cursor

        self._current_items: list[T] = []
        self._index = 0
        self._cursor: str | None = None
        self._exhausted = False

    def __iter__(self) -> Iterator[T]:
        return self

    def __next__(self) -> T:
        if self._index < len(self._current_items):
            item = self._current_items[self._index]
            self._index += 1
            return item

        if self._exhausted:
            raise StopIteration

        page_result = self._fetch_page(self._cursor)
        self._current_items = self._extract_items(page_result)

        if not self._current_items:
            self._exhausted = True
            raise StopIteration

        if not self._has_next_page(page_result):
            self._exhausted = True
        else:
            self._cursor = self._get_cursor(page_result)

        self._index = 0
        item = self._current_items[self._index]
        self._index += 1
        return item


def dict_response_iterator(
    fetch_page: Callable[[str | None], dict[str, Any]],
) -> PagedIterator[Any]:
    """Create an iterator for dict-based responses with ``pageInfo``/``nodes``.

    Args:
        fetch_page: Function that fetches a page dict. Receives a cursor
            (or None for the first page) and returns a dict with ``nodes``
            and ``pageInfo`` keys.

    Returns:
        Iterator over items in the ``nodes`` list.

    Examples:
        ```python
        iterator = dict_response_iterator(
            fetch_page=lambda after: self._client.inventory.list(
                inventory_name=name, first=100, after=after
            ),
        )
        for item in iterator:
            print(item)
        ```
    """
    return PagedIterator(
        fetch_page=fetch_page,
        extract_items=lambda result: result.get("nodes", []),
        has_next_page=lambda result: result.get("pageInfo", {}).get(
            "hasNextPage", False
        ),
        get_cursor=lambda result: result.get("pageInfo", {}).get("endCursor"),
    )
