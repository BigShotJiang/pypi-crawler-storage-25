"""Mixin providing item preprocessing helpers for QuestraData."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from .inventory_registry import InventorySchema, resolve_field_name
from .models.inputs import (
    BoolProperty,
    DateProperty,
    DateTimeOffsetProperty,
    DateTimeProperty,
    DecimalProperty,
    FileProperty,
    GuidProperty,
    IntProperty,
    InventoryProperty,
    LongProperty,
    StringProperty,
    TimeProperty,
    TimeSeriesProperty,
)
from .raw_client import _QuestraDataCore

logger = logging.getLogger(__name__)


class _ItemHelpersMixin:
    """Item preprocessing methods extracted from QuestraData."""

    _client: _QuestraDataCore
    _registry: Any  # InventoryRegistry — avoid circular import at runtime

    def _execute_mutation_chunked(
        self,
        operation: Callable[
            [str, list[dict[str, Any]], str | None], list[dict[str, Any]]
        ],
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None,
        max_items_per_request: int,
    ) -> list[dict[str, Any]]:
        total_batches = -(-len(items) // max_items_per_request)
        logger.info(
            "Sending mutation items: %d items in %d batch(es) of max %d.",
            len(items),
            total_batches,
            max_items_per_request,
        )

        if len(items) <= max_items_per_request:
            return operation(inventory_name, items, namespace_name)

        results: list[dict[str, Any]] = []
        for i in range(0, len(items), max_items_per_request):
            batch = items[i : i + max_items_per_request]
            batch_nr = i // max_items_per_request + 1
            logger.info(
                "Sending mutation batch %d/%d (%d items)",
                batch_nr,
                total_batches,
                len(batch),
            )
            results.extend(operation(inventory_name, batch, namespace_name))

        return results

    def _normalize_properties(
        self,
        properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ],
    ) -> list[InventoryProperty]:
        normalized: list[InventoryProperty] = []
        for prop in properties:
            if isinstance(prop, InventoryProperty):
                normalized.append(prop)
            else:
                # Specialized property classes all have to_inventory_property()
                normalized.append(prop.to_inventory_property())  # type: ignore[union-attr]
        return normalized

    def _auto_create_timeseries(
        self,
        items: list[dict[str, Any]],
        schema: InventorySchema,
        inventory_name: str,
        namespace_name: str | None,
        max_ids_per_request: int = 100,
    ) -> None:
        """Auto-create TimeSeries objects for TIME_SERIES properties with None values.

        Mutates *items* in-place, replacing ``None`` values with the newly
        created TimeSeries IDs and integer string/int values with ``int(id)``.

        Args:
            items: Items list to mutate.
            schema: Inventory schema (provides ``timeseries_field_names``).
            inventory_name: Inventory name for TimeSeries creation.
            namespace_name: Optional namespace qualifier.
            max_ids_per_request: Maximum timeseries objects per mutation
                request. Default: 100.

        Raises:
            ValueError: For invalid TimeSeries property values.
        """
        from .models.inputs import CreateTimeSeriesInput

        timeseries_to_create: list[CreateTimeSeriesInput] = []
        timeseries_mapping: dict[tuple[int, str], int] = {}

        for item_idx, item in enumerate(items):
            for item_key in list(item.keys()):
                if item_key.startswith("_"):
                    continue
                try:
                    fn = resolve_field_name(item_key, schema)
                except ValueError:
                    continue
                if fn not in schema.timeseries_field_names:
                    continue

                item_value = item[item_key]
                original_name = schema.name_mapping.get(fn, fn)

                if item_value is None:
                    ts_input = CreateTimeSeriesInput(
                        inventory_name=inventory_name,
                        property_name=original_name,
                        namespace_name=namespace_name,
                    )
                    timeseries_mapping[(item_idx, item_key)] = len(timeseries_to_create)
                    timeseries_to_create.append(ts_input)
                elif isinstance(item_value, (str, int)):
                    items[item_idx][item_key] = int(item_value)
                    logger.debug(
                        f"Using existing TimeSeries ID {item_value} for "
                        f"item {item_idx}, property {item_key}"
                    )
                else:
                    raise ValueError(
                        f"Invalid TimeSeries value for item {item_idx}, "
                        f"property {item_key}: {item_value!r}. "
                        f"Expected None (auto-create) or string/int (existing ID)."
                    )

        if timeseries_to_create:
            logger.info(f"Creating {len(timeseries_to_create)} TimeSeries via GraphQL")
            ts_results = []
            for _i in range(0, len(timeseries_to_create), max_ids_per_request):
                ts_results.extend(
                    self._client.mutations.create_timeseries(
                        timeseries_to_create[_i : _i + max_ids_per_request]
                    )
                )
            for (item_idx, prop_key), ts_idx in timeseries_mapping.items():
                ts_id = ts_results[ts_idx].id
                items[item_idx][prop_key] = ts_id
                logger.debug(
                    f"Assigned TimeSeries ID {ts_id} to item {item_idx}, "
                    f"property {prop_key}"
                )

    def _auto_upload_files(
        self,
        items: list[dict[str, Any]],
        schema: InventorySchema,
        inventory_name: str,
        namespace_name: str | None,
    ) -> None:
        """Upload files for FILE properties containing a ``FileUpload`` value.

        Mutates *items* in-place. ``FileUpload`` → replaced with ``int`` file ID.
        ``int`` values (existing IDs) are left unchanged.

        Args:
            items: Items list to mutate.
            schema: Inventory schema (provides ``file_field_names``).
            inventory_name: Inventory name for upload name construction.
            namespace_name: Optional namespace qualifier.

        Raises:
            ValueError: If a FILE property value is neither ``FileUpload`` nor ``int``.
        """
        from pathlib import Path
        from typing import BinaryIO

        from .models.file_upload import FileUpload

        uploads: list[tuple[int, str, FileUpload]] = []

        for item_idx, item in enumerate(items):
            for item_key in list(item.keys()):
                if item_key.startswith("_"):
                    continue
                try:
                    fn = resolve_field_name(item_key, schema)
                except ValueError:
                    continue
                if fn not in schema.file_field_names:
                    continue

                item_value = item[item_key]
                if isinstance(item_value, FileUpload):
                    uploads.append((item_idx, item_key, item_value))
                elif isinstance(item_value, int):
                    logger.debug(
                        f"Using existing file ID {item_value} for item {item_idx}, "
                        f"property {item_key}"
                    )
                elif item_value is None:
                    raise ValueError(
                        f"FILE property '{item_key}' in item {item_idx} is None. "
                        f"Use FileUpload(...) or pass an existing file ID as int."
                    )
                else:
                    raise ValueError(
                        f"Invalid FILE property value for item {item_idx}, "
                        f"property '{item_key}': {item_value!r}. "
                        f"Expected FileUpload(...) or int."
                    )

        if not uploads:
            return

        files_list: list[tuple[str, str | Path | BinaryIO, str, str]] = []
        for _, item_key, fu in uploads:
            fn = resolve_field_name(item_key, schema)
            original_name = schema.name_mapping.get(fn, fn)
            upload_name = (
                f"{namespace_name}__{inventory_name}.{original_name}"
                if namespace_name
                else f"{inventory_name}.{original_name}"
            )
            files_list.append(
                (
                    upload_name,
                    fu.file_data,
                    fu.resolve_filename(),
                    fu.resolve_content_type(),
                )
            )

        logger.info(
            f"Uploading {len(files_list)} file(s) for inventory '{inventory_name}'"
        )
        file_ids = self._client.files.upload(files_list)

        for (item_idx, item_key, _), file_id in zip(uploads, file_ids):
            items[item_idx][item_key] = file_id
            logger.debug(
                f"Assigned file ID {file_id} to item {item_idx}, property '{item_key}'"
            )
