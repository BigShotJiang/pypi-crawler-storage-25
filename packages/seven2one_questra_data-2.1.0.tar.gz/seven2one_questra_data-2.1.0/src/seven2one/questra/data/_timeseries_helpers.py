"""Pure helper functions for timeseries chunking and merging."""

from __future__ import annotations

from .models.rest import SetTimeSeriesDataInput, TimeSeriesData, TimeSeriesDataPayload

# Backend-Limits (konfigurierbar — per Parameter in list_timeseries_values() überschreibbar)
TIMESERIES_MAX_CHUNK_DEPTH: int = 20


def _merge_timeseries_payloads(
    left: TimeSeriesDataPayload,
    right: TimeSeriesDataPayload,
) -> TimeSeriesDataPayload:
    """Merge two TimeSeriesDataPayload objects, deduplicating values by timestamp."""
    merged: dict[int, TimeSeriesData] = {}

    for payload in (left, right):
        for ts_data in payload.data:
            ts_id = ts_data.time_series_id
            if ts_id is None:
                continue
            if ts_id not in merged:
                merged[ts_id] = ts_data
            else:
                existing = merged[ts_id]
                combined = (existing.values or []) + (ts_data.values or [])
                seen: set[str] = set()
                deduped = []
                for v in sorted(combined, key=lambda x: x.time):
                    key = v.time.isoformat()
                    if key not in seen:
                        seen.add(key)
                        deduped.append(v)
                merged[ts_id] = existing.model_copy(update={"values": deduped})

    return TimeSeriesDataPayload(data=list(merged.values()))


def _chunk_timeseries_inputs(
    data_inputs: list[SetTimeSeriesDataInput],
    max_series_per_request: int,
    max_values_per_request: int,
) -> list[list[SetTimeSeriesDataInput]]:
    """Split data_inputs into batches respecting server write limits.

    Args:
        data_inputs: List of timeseries inputs to split.
        max_series_per_request: Maximum number of timeseries per batch.
        max_values_per_request: Maximum total values per batch.

    Returns:
        List of batches, each respecting both limits.
    """
    batches: list[list[SetTimeSeriesDataInput]] = []
    current_batch: list[SetTimeSeriesDataInput] = []
    current_value_count = 0

    for data_input in data_inputs:
        n_values = len(data_input.values)

        # Single timeseries exceeds max_values: split its values across separate batches
        if n_values > max_values_per_request:
            if current_batch:
                batches.append(current_batch)
                current_batch = []
                current_value_count = 0
            for i in range(0, n_values, max_values_per_request):
                chunk_values = data_input.values[i : i + max_values_per_request]
                batches.append([data_input.model_copy(update={"values": chunk_values})])
            continue

        would_exceed_series = len(current_batch) + 1 > max_series_per_request
        would_exceed_values = current_value_count + n_values > max_values_per_request

        if current_batch and (would_exceed_series or would_exceed_values):
            batches.append(current_batch)
            current_batch = []
            current_value_count = 0

        current_batch.append(data_input)
        current_value_count += n_values

    if current_batch:
        batches.append(current_batch)

    return batches
