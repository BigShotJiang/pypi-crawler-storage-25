"""REST operations for System endpoints."""

from __future__ import annotations

import logging
from collections.abc import Callable

logger = logging.getLogger(__name__)

from ..models.rest import ServiceVersion


class SystemOperations:
    """REST operations for System endpoints."""

    def __init__(self, rest_get_func: Callable):
        """
        Initialize System operations.

        Args:
            rest_get_func: GET request function
        """
        self._get = rest_get_func
        logger.debug("SystemOperations initialized")

    def get_version(self) -> ServiceVersion:
        """
        Retrieve the service version via REST.

        Returns:
            ServiceVersion: Object with ``version`` and ``informational_version``
        """
        logger.debug("Getting service version via REST")
        result = self._get("/version")
        version = ServiceVersion.model_validate(result)
        logger.info(f"Retrieved service version. version={version.version}")
        return version
