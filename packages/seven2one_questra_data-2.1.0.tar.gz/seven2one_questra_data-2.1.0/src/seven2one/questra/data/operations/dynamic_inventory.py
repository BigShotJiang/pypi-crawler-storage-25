"""Dynamic inventory operations for Questra Data."""

from __future__ import annotations

import decimal
import logging
import uuid
from collections.abc import Callable
from datetime import date, datetime, time
from typing import Any
from uuid import UUID

from .._type_converters import _parse_time
from ..inventory_registry import (
    InventoryRegistry,
    InventorySchema,
    normalize_system_key,
    resolve_field_name,
)

logger = logging.getLogger(__name__)


def _convert_value_for_gql_type(value: Any, *, gql_type: str | None = None) -> Any:
    """Convert Python values to GraphQL-compatible types based on schema type.

    Conversion is driven by the GraphQL type from schema when specified.
    Falls back to Python type-based conversion only when gql_type is unknown/None.

    GraphQL type conversions:
    - Long: converted to string (GraphQL Long scalar requires string)
    - Int: converted to integer
    - Float: converted to float
    - Decimal: converted to string (GraphQL Decimal scalar requires string)
    - String: converted to string (datetime/date/time use isoformat)
    - Boolean: converted to boolean
    - ID: converted to string
    - DateTime/Date/Time: use isoformat if Python type, else string
    - UUID: converted to string

    Args:
        value: Any value (int, float, datetime, dict, list, etc.)
        gql_type: GraphQL type from schema (e.g., "Long", "Int", "String", "Float")

    Returns:
        Value converted according to GraphQL type requirements
    """
    if value is None:
        return None

    # Handle collections first (recursive)
    if isinstance(value, list):
        return [_convert_value_for_gql_type(item, gql_type=gql_type) for item in value]

    if isinstance(value, dict):
        return {key: _convert_value_for_gql_type(val) for key, val in value.items()}

    # GQL-type-driven conversion when type is specified
    if gql_type == "Long":
        return str(value)
    elif gql_type == "Int":
        if isinstance(value, bool):
            return value  # Keep bools as-is (bool is subclass of int)
        return int(value)
    elif gql_type == "Float":
        if isinstance(value, bool):
            return value  # Keep bools as-is
        return float(value)
    elif gql_type == "String":
        if isinstance(value, (datetime, date, time)):
            return value.isoformat()
        return str(value)
    elif gql_type == "Boolean":
        return bool(value)
    elif gql_type == "ID":
        return str(value)
    elif gql_type == "Decimal":
        return str(value)
    elif gql_type == "DateTime":
        if isinstance(value, datetime):
            return value.isoformat()
        return str(value)
    elif gql_type == "Date":
        if isinstance(value, (datetime, date)):
            return value.isoformat() if isinstance(value, date) else str(value)
        return str(value)
    elif gql_type == "TimeSpan":
        if isinstance(value, time):
            ms = value.microsecond // 1000
            return f"{value.hour:02d}:{value.minute:02d}:{value.second:02d}.{ms:03d}"
        return str(value)
    elif gql_type == "UUID":
        return str(value)

    # Fallback for unknown gql_type or None: Python type-based conversion
    if isinstance(value, bool):
        return value
    elif isinstance(value, datetime):
        return value.isoformat()
    elif isinstance(value, date):
        return value.isoformat()
    elif isinstance(value, time):
        return value.isoformat()
    elif isinstance(value, UUID):
        return str(value)

    # All other types (int, float, str) unchanged
    return value


# GraphQL types for system fields that require type conversion on deserialization.
# _rowVersion is Int! (native JSON number) — no conversion needed.
_SYSTEM_FIELD_GQL_TYPES: dict[str, str] = {
    "_id": "Long",
    "_insertedBy": "UUID",
    "_updatedBy": "UUID",
    "_insertedAt": "DateTime",
    "_updatedAt": "DateTime",
}


def _convert_value_from_gql_type(
    value: object, *, gql_type: str | None = None
) -> object:
    """Convert GraphQL response values to proper Python types at the transport boundary."""
    if value is None:
        return None
    if gql_type in ("Long", "UInt"):
        return int(value)  # type: ignore[arg-type]
    elif gql_type == "Decimal":
        return decimal.Decimal(str(value))
    elif gql_type == "DateTime":
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    elif gql_type == "Date":
        return date.fromisoformat(str(value))
    elif gql_type == "TimeSpan":
        return _parse_time(value)  # type: ignore[arg-type]
    elif gql_type == "UUID":
        return uuid.UUID(str(value))
    return value


def _resolve_and_convert_items(
    items: list[dict[str, Any]],
    schema: InventorySchema,
) -> list[dict[str, Any]]:
    """Resolve user-supplied keys case-insensitively and convert values for GraphQL.

    System fields (starting with ``_``) are normalised to their canonical casing
    (e.g. ``_Id`` → ``_id``, ``_RowVersion`` → ``_rowVersion``).

    Args:
        items: Items with arbitrary property names.
        schema: Inventory schema for name resolution.

    Returns:
        Items with resolved fieldName keys and type-converted values.
    """
    result: list[dict[str, Any]] = []
    for item in items:
        resolved: dict[str, Any] = {}
        for key, value in item.items():
            if key.startswith("_"):
                fn = normalize_system_key(key)
            else:
                fn = resolve_field_name(key, schema)
            gql_type = schema.field_types.get(fn) or _SYSTEM_FIELD_GQL_TYPES.get(fn)
            # Relation FK fields (_<name>Id) are Long scalars — must be serialized as strings.
            if gql_type is None and fn.startswith("_") and fn.lower().endswith("id"):
                gql_type = "Long"
            resolved[fn] = _convert_value_for_gql_type(value, gql_type=gql_type)
        result.append(resolved)
    return result


# Case-insensitive lookup for known sub-fields of TimeSeries system types.
# Covers _TimeSeries__PayloadType and _Interval__Type fields.
# Maps lower(fieldName) → canonical GraphQL fieldName.
_TS_SUBFIELD_LOWER_TO_CANONICAL: dict[str, str] = {
    f.lower(): f
    for f in [
        # _TimeSeries__PayloadType
        "id",
        "createdBy",
        "createdAt",
        "alteredBy",
        "alteredAt",
        "interval",
        "valueAlignment",
        "valueAvailability",
        "unit",
        "timeZone",
        "defaultAggregation",
        "startOfTime",
        "auditEnabled",
        "quotationEnabled",
        "defaultQuotationBehavior",
        # _Interval__Type
        "timeUnit",
        "multiplier",
    ]
}


def _canonical_subfield(part: str) -> str:
    """Return the canonical GraphQL field name for a TimeSeries sub-field.

    Checks the known case-insensitive lookup table first; falls back to
    lowercasing the first character (GraphQL camelCase convention).
    System fields (starting with ``_``) are normalized via ``normalize_system_key``.
    """
    if part.startswith("_"):
        return normalize_system_key(part)
    canonical = _TS_SUBFIELD_LOWER_TO_CANONICAL.get(part.lower())
    if canonical is not None:
        return canonical
    return part[0].lower() + part[1:] if part else part


def _build_nested_field_selection(
    property_name: str,
    schema: InventorySchema,
) -> str:
    """Convert dot-notation property to nested GraphQL field selection.

    The root property is resolved via the schema (case-insensitive).
    System fields (starting with _) pass through unchanged.
    Sub-properties are resolved case-insensitively against known TimeSeries
    system type fields; unknown sub-fields fall back to lowercasing the first char.

    Args:
        property_name: Property name, possibly with dot notation.
        schema: Inventory schema for root property resolution.

    Returns:
        GraphQL field selection string,
        e.g. "bodyBattery { id }" for "BodyBattery.id".
    """
    parts = property_name.split(".")

    if parts[0].startswith("_"):
        root = normalize_system_key(parts[0])
    else:
        root = resolve_field_name(parts[0], schema)

    if len(parts) == 1:
        return root

    sub_parts = [_canonical_subfield(p) for p in parts[1:]]
    result = root
    for part in sub_parts:
        result = f"{result} {{ {part}"
    result += " }" * (len(parts) - 1)
    return result


class DynamicInventoryOperations:
    """Dynamic operations for inventory data.

    After creating an inventory, GraphQL operations are auto-generated:

    Queries:
    - namespace__InventoryName: Query items with pagination

    Mutations:
    - namespace__insertInventoryName: Create items
    - namespace__updateInventoryName: Update items
    - namespace__deleteInventoryName: Delete items

    Methods follow Python CRUD naming conventions:
    - create(): Create new items
    - list(): List/query items
    - update(): Update existing items
    - delete(): Delete items
    """

    def __init__(self, execute_func: Callable[..., Any]) -> None:
        """Initialize the dynamic Inventory operations.

        Args:
            execute_func: Function to execute GraphQL operations.
        """
        self._execute = execute_func
        self._registry = InventoryRegistry(execute_func)
        logger.debug("DynamicInventoryOperations initialized")

    def _validate_insert_items(
        self,
        items: list[dict[str, Any]],
        schema: InventorySchema,
    ) -> None:
        """Validate items for insert against schema.

        Property names are resolved case-insensitively via the schema.
        Unknown properties produce a warning; missing required fields raise.

        Args:
            items: List of items to validate.
            schema: Inventory schema with required fields and name mapping.

        Raises:
            ValueError: If required fields are missing in any item.
        """
        for idx, item in enumerate(items):
            resolved_fns: set[str] = set()
            for key in item.keys():
                if key.startswith("_"):
                    resolved_fns.add(key)
                    # _{fieldName}Id satisfies the 1:n relation field requirement.
                    if key.endswith("Id"):
                        relation_fn_lower = key[1:-2].lower()
                        for fn in schema.required_fields:
                            if fn.lower() == relation_fn_lower:
                                resolved_fns.add(fn)
                    continue
                try:
                    resolved_fns.add(resolve_field_name(key, schema))
                except ValueError:
                    logger.warning(f"Item {idx}: Unknown field '{key}' will be ignored")

            missing = schema.required_fields - resolved_fns
            if missing:
                missing_names = sorted(
                    schema.name_mapping.get(fn, fn) for fn in missing
                )
                raise ValueError(
                    f"Item {idx}: Missing required fields: {missing_names}"
                )

    def _validate_mutation_items(self, items: list[dict[str, Any]]) -> None:
        """Validate items have required fields for update/delete.

        Args:
            items: List of items to validate.

        Raises:
            ValueError: If _id or _rowVersion is missing.
        """
        for idx, item in enumerate(items):
            keys_lower = {k.lower() for k in item if isinstance(k, str)}
            if "_id" not in keys_lower:
                raise ValueError(f"Item {idx}: Missing required field '_id'")
            if "_rowversion" not in keys_lower:
                raise ValueError(f"Item {idx}: Missing required field '_rowVersion'")

    def list(
        self,
        inventory_name: str,
        namespace_name: str | None = None,
        properties: list[str] | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, Any]] | None = None,
        first: int | None = None,
        after: str | None = None,
        last: int | None = None,
        before: str | None = None,
    ) -> dict[str, Any]:
        """List items from a dynamic inventory.

        Args:
            inventory_name: Inventory name.
            schema: Inventory schema (provides field and type names).
            namespace_name: Optional namespace qualifier.
            properties: Properties to query (default: ["_id", "_rowVersion"]).
                Supports dot notation for nested properties:
                - Simple: "name", "email"
                - Nested: "bodyBattery.id", "bodyBattery.interval.timeUnit"
            where: Filter conditions.
            order: Sort specification.
            first: Page size from the beginning.
            after: Forward pagination cursor.
            last: Page size from the end.
            before: Backward pagination cursor.

        Returns:
            Dict with pageInfo and nodes/edges.
        """
        schema = self._registry.get(inventory_name, namespace_name)
        field_name = schema.select_field_name
        type_name = schema.type_name

        if not properties:
            properties = ["_id", "_rowVersion"]

        normalized_fields = [
            _build_nested_field_selection(prop, schema) for prop in properties
        ]
        fields_str = "\n                    ".join(normalized_fields)

        logger.debug(
            f"Listing items from dynamic inventory. field_name={field_name}, "
            f"type_name={type_name}, properties={properties}, where={where}, order={order}"
        )

        query = f"""
            query ListInventory(
                $where: {type_name}__FilterInputType
                $order: [{type_name}__SortInputType!]
                $first: Int
                $after: String
                $last: Int
                $before: String
            ) {{
                {field_name}(
                    where: $where
                    order: $order
                    first: $first
                    after: $after
                    last: $last
                    before: $before
                ) {{
                    pageInfo {{
                        hasNextPage
                        hasPreviousPage
                        startCursor
                        endCursor
                    }}
                    nodes {{
                        {fields_str}
                    }}
                }}
            }}
        """

        variables = {
            "where": where,
            "order": order,
            "first": first,
            "after": after,
            "last": last,
            "before": before,
        }

        result = self._execute(query, variables)
        data = result[field_name]

        def _deserialize_item(
            item: dict[str, Any], item_schema: InventorySchema
        ) -> None:
            """Convert string-serialized scalars in an item dict (recursive for nested objects)."""
            for sys_field, gql_type in _SYSTEM_FIELD_GQL_TYPES.items():
                if sys_field in item:
                    item[sys_field] = _convert_value_from_gql_type(
                        item[sys_field], gql_type=gql_type
                    )
            for fn, raw_value in item.items():
                if fn.startswith("_"):
                    continue
                if isinstance(raw_value, dict):
                    _deserialize_item(raw_value, item_schema)
                else:
                    gql_type = item_schema.field_types.get(fn)
                    if gql_type:
                        item[fn] = _convert_value_from_gql_type(
                            raw_value, gql_type=gql_type
                        )

        # Schema-driven deserialization: convert property values to correct Python types
        for item in data.get("nodes", []):
            _deserialize_item(item, schema)

        logger.info(
            f"Listed {len(data.get('nodes', []))} items from {field_name}. "
            f"has_next_page={data.get('pageInfo', {}).get('hasNextPage')}"
        )

        return data

    def create(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
        validate: bool = True,
    ) -> list[dict[str, Any]]:
        """Create new items in a dynamic inventory.

        Args:
            inventory_name: Inventory name.
            items: Items to create; property keys are resolved case-insensitively.
            schema: Inventory schema.
            namespace_name: Optional namespace qualifier.
            validate: Perform schema validation (default: True).

        Returns:
            Created items with _id, _rowVersion, _existed.

        Raises:
            ValueError: If validation fails.
        """
        schema = self._registry.get(inventory_name, namespace_name)
        if validate:
            self._validate_insert_items(items, schema)

        field_name = schema.insert_field_name
        type_name = schema.type_name

        logger.debug(
            f"Creating items in dynamic inventory. field_name={field_name}, "
            f"type_name={type_name}, num_items={len(items)}, validated={validate}"
        )

        mutation = f"""
            mutation CreateInventory(
                $input: [{type_name}__InsertInputType!]!
            ) {{
                {field_name}(input: $input) {{
                    items {{
                        _id
                        _rowVersion
                        _existed
                    }}
                }}
            }}
        """

        resolved_items = _resolve_and_convert_items(items, schema)
        result = self._execute(mutation, {"input": resolved_items})
        created_items: list[dict[str, Any]] = result[field_name]["items"]

        for item in created_items:
            item["_id"] = int(item["_id"])

        logger.info(
            f"Created {len(created_items)} items in {field_name}. "
            f"num_new={sum(1 for i in created_items if not i.get('_existed', False))}"
        )
        return created_items

    def update(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
        validate: bool = True,
    ) -> list[dict[str, Any]]:
        """Update items in a dynamic inventory.

        Args:
            inventory_name: Inventory name.
            items: Items to update (must include _id and _rowVersion).
            schema: Inventory schema.
            namespace_name: Optional namespace qualifier.
            validate: Validate _id/_rowVersion presence (default: True).

        Returns:
            Updated items with _id, _rowVersion, _existed.

        Raises:
            ValueError: If validation fails.
        """
        schema = self._registry.get(inventory_name, namespace_name)
        if validate:
            self._validate_mutation_items(items)

        field_name = schema.update_field_name
        type_name = schema.type_name

        logger.debug(
            f"Updating items in dynamic inventory. field_name={field_name}, "
            f"type_name={type_name}, num_items={len(items)}, validated={validate}"
        )

        mutation = f"""
            mutation UpdateInventory(
                $input: [{type_name}__UpdateInputType!]!
            ) {{
                {field_name}(input: $input) {{
                    items {{
                        _id
                        _rowVersion
                        _existed
                    }}
                }}
            }}
        """

        resolved_items = _resolve_and_convert_items(items, schema)
        result = self._execute(mutation, {"input": resolved_items})
        updated_items: list[dict[str, Any]] = result[field_name]["items"]

        for item in updated_items:
            item["_id"] = int(item["_id"])

        logger.info(
            f"Updated {len(updated_items)} items in {field_name}. "
            f"num_found={sum(1 for i in updated_items if i.get('_existed', False))}"
        )
        return updated_items

    def delete(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
        validate: bool = True,
    ) -> list[dict[str, Any]]:
        """Delete items from a dynamic inventory.

        Args:
            inventory_name: Inventory name.
            items: Items to delete (must include _id and _rowVersion).
            schema: Inventory schema.
            namespace_name: Optional namespace qualifier.
            validate: Validate _id/_rowVersion presence (default: True).

        Returns:
            Deleted items with _id, _rowVersion, _existed.

        Raises:
            ValueError: If validation fails.
        """
        schema = self._registry.get(inventory_name, namespace_name)
        if validate:
            self._validate_mutation_items(items)

        field_name = schema.delete_field_name
        type_name = schema.type_name

        logger.debug(
            f"Deleting items from dynamic inventory. field_name={field_name}, "
            f"type_name={type_name}, num_items={len(items)}, validated={validate}"
        )

        mutation = f"""
            mutation DeleteInventory(
                $input: [{type_name}__DeleteInputType!]!
            ) {{
                {field_name}(input: $input) {{
                    items {{
                        _id
                        _rowVersion
                        _existed
                    }}
                }}
            }}
        """

        result = self._execute(
            mutation, {"input": _resolve_and_convert_items(items, schema)}
        )
        deleted_items: list[dict[str, Any]] = result[field_name]["items"]

        for item in deleted_items:
            item["_id"] = int(item["_id"])

        logger.info(
            f"Deleted {len(deleted_items)} items from {field_name}. "
            f"num_found={sum(1 for i in deleted_items if i.get('_existed', False))}"
        )
        return deleted_items
