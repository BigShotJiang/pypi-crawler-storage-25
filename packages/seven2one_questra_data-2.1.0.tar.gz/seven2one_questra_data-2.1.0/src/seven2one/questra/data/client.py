"""
QuestraData client for Questra Data.

Provides a simplified interface for common operations,
without the user needing to know the internal details (GraphQL vs REST).
"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from datetime import datetime
from typing import TYPE_CHECKING, Any

logger = logging.getLogger(__name__)
from seven2one.questra.authentication import QuestraAuthentication

from ._item_helpers import _ItemHelpersMixin
from ._schema_helpers import _SchemaResolutionMixin
from ._timeseries_helpers import (
    TIMESERIES_MAX_CHUNK_DEPTH,
    _chunk_timeseries_inputs,
    _merge_timeseries_payloads,
)
from .exceptions import QuestraError
from .inventory_registry import resolve_field_name
from .managers import CatalogManager
from .models import (
    Aggregation,
    BackgroundJobResult,
    ConflictAction,
    Inventory,
    NamedItemResult,
    Namespace,
    Quality,
    QuotationBehavior,
    Role,
    SystemInfo,
    TimeUnit,
    TimeZone,
    Unit,
)
from .models.inputs import (
    BoolProperty,
    DateProperty,
    DateTimeOffsetProperty,
    DateTimeProperty,
    DecimalProperty,
    FileProperty,
    GuidProperty,
    IntProperty,
    InventoryProperty,
    InventoryRelation,
    LongProperty,
    StringProperty,
    TimeProperty,
    TimeSeriesProperty,
)
from .models.rest import SetTimeSeriesDataInput, TimeSeriesDataPayload, TimeSeriesValue
from .models.system import ServiceVersion
from .pagination import PagedIterator
from .raw_client import _QuestraDataCore
from .results import (
    PagedQueryResult,
    QueryResult,
    TimeSeriesResult,
    _CaseInsensitiveDict,
)

# Optional pandas Integration
if TYPE_CHECKING:
    import pandas as pd

try:
    import pandas as pd

    _PANDAS_AVAILABLE = True
except ImportError:
    _PANDAS_AVAILABLE = False


class QuestraData(_SchemaResolutionMixin, _ItemHelpersMixin):
    """Data client for Questra Data.

    Provides a simplified, type-safe interface for interacting with the Questra
    Data service without requiring knowledge of the underlying GraphQL or REST
    implementation details. For advanced use cases, raw API access is available
    via the [`raw`][seven2one.questra.data.QuestraData.raw] property.

    Args:
        graphql_url: GraphQL endpoint URL
        auth_client: Authenticated QuestraAuthentication instance
        rest_base_url: REST API base URL (auto-derived if not provided)

    Environment Variables:
        QUESTRA_DATA_URL: Fallback for ``graphql_url`` if not passed explicitly.

    Example:
        ```python
        from seven2one.questra.authentication import QuestraAuthentication
        from seven2one.questra.data import QuestraData

        auth = QuestraAuthentication(...)
        client = QuestraData(
            graphql_url="https://example.com/data/graphql", auth_client=auth
        )
        ```
    """

    def __init__(
        self,
        graphql_url: str | None = None,
        *,
        auth_client: QuestraAuthentication,
        rest_base_url: str | None = None,
    ):
        logger.info(f"Initializing QuestraData. graphql_url={graphql_url}")

        # Create _QuestraDataCore client (advanced operations)
        self._client = _QuestraDataCore(
            graphql_url=graphql_url,
            auth_client=auth_client,
            rest_base_url=rest_base_url,
        )

        # Initialize internal managers (for code organization)
        self._catalog_manager = CatalogManager(self._client)
        self._registry = self._client.inventory._registry

        logger.info("QuestraData initialized successfully")

    # ===== Time Series Operations =====

    def _get_timeseries_data_chunked(
        self,
        timeseries_ids: list[int],
        from_time: datetime,
        to_time: datetime,
        time_unit: TimeUnit | None,
        multiplier: int | None,
        aggregation: Aggregation | None,
        time_zone: str | None,
        exclude_qualities: list[Quality] | None,
        max_values_per_request: int,
        unit: str | None = None,
        quotation_time: datetime | None = None,
        quotation_exactly_at: bool = False,
        quotation_behavior: QuotationBehavior | None = None,
        depth: int = 0,
    ) -> TimeSeriesDataPayload:
        """Fetch timeseries data with salvage + re-fetch + bisection on server limit."""
        if depth > TIMESERIES_MAX_CHUNK_DEPTH:
            raise QuestraError(
                f"Timeseries chunking: max recursion depth {TIMESERIES_MAX_CHUNK_DEPTH} exceeded. "
                f"Window [{from_time}, {to_time}] still truncated after salvage attempts."
            )

        result = self._client.timeseries.get_data(
            time_series_ids=timeseries_ids,
            from_time=from_time,
            to_time=to_time,
            time_unit=time_unit,
            multiplier=multiplier if time_unit else None,
            aggregation=aggregation,
            unit=unit,
            time_zone=time_zone,
            exclude_qualities=exclude_qualities,
            quotation_time=quotation_time,
            quotation_exactly_at=quotation_exactly_at,
            quotation_behavior=quotation_behavior,
        )

        # ── Branch A: server signalled truncation via ErrorsPayload ──
        if result.truncated:
            returned_ids = {ts.time_series_id for ts in result.data}
            missing_ids = [id_ for id_ in timeseries_ids if id_ not in returned_ids]

            if missing_ids and returned_ids:
                # Branch A1: salvage returned series, re-fetch only missing ones
                logger.debug(
                    "Truncated: %d returned, %d missing → re-fetching missing IDs at depth %d",
                    len(returned_ids),
                    len(missing_ids),
                    depth,
                )
                rest = self._get_timeseries_data_chunked(
                    missing_ids,
                    from_time,
                    to_time,
                    time_unit,
                    multiplier,
                    aggregation,
                    time_zone,
                    exclude_qualities,
                    max_values_per_request,
                    unit,
                    quotation_time,
                    quotation_exactly_at,
                    quotation_behavior,
                    depth + 1,
                )
                return _merge_timeseries_payloads(result, rest)
            else:
                # Branch A2: bisect the time window.
                # Either all IDs were returned (single series exceeds limit alone),
                # or nothing was returned (first series already exceeds limit).
                # In both cases re-fetching with the same window would loop — must shrink it.
                logger.debug(
                    "Truncated, %d returned / %d missing → bisecting time window [%s, %s] at depth %d",
                    len(returned_ids),
                    len(missing_ids),
                    from_time,
                    to_time,
                    depth,
                )
                mid = from_time + (to_time - from_time) / 2
                left = self._get_timeseries_data_chunked(
                    timeseries_ids,
                    from_time,
                    mid,
                    time_unit,
                    multiplier,
                    aggregation,
                    time_zone,
                    exclude_qualities,
                    max_values_per_request,
                    unit,
                    quotation_time,
                    quotation_exactly_at,
                    quotation_behavior,
                    depth + 1,
                )
                right = self._get_timeseries_data_chunked(
                    timeseries_ids,
                    mid,
                    to_time,
                    time_unit,
                    multiplier,
                    aggregation,
                    time_zone,
                    exclude_qualities,
                    max_values_per_request,
                    unit,
                    quotation_time,
                    quotation_exactly_at,
                    quotation_behavior,
                    depth + 1,
                )
                return _merge_timeseries_payloads(left, right)

        # ── Branch B: safety net — total values hit limit without ErrorsPayload ──
        total = sum(len(ts_data.values or []) for ts_data in result.data)
        if total >= max_values_per_request:
            logger.debug(
                "Total values %d >= limit %d (no ErrorsPayload) → bisecting window [%s, %s] at depth %d",
                total,
                max_values_per_request,
                from_time,
                to_time,
                depth,
            )
            mid = from_time + (to_time - from_time) / 2
            left = self._get_timeseries_data_chunked(
                timeseries_ids,
                from_time,
                mid,
                time_unit,
                multiplier,
                aggregation,
                time_zone,
                exclude_qualities,
                max_values_per_request,
                unit,
                quotation_time,
                quotation_exactly_at,
                quotation_behavior,
                depth + 1,
            )
            right = self._get_timeseries_data_chunked(
                timeseries_ids,
                mid,
                to_time,
                time_unit,
                multiplier,
                aggregation,
                time_zone,
                exclude_qualities,
                max_values_per_request,
                unit,
                quotation_time,
                quotation_exactly_at,
                quotation_behavior,
                depth + 1,
            )
            return _merge_timeseries_payloads(left, right)

        return result

    def _send_timeseries_data_chunked(
        self,
        data_inputs: list[SetTimeSeriesDataInput],
        max_series_per_request: int,
        max_values_per_request: int,
    ) -> None:
        """Chunk and send timeseries write data respecting server limits."""
        batches = _chunk_timeseries_inputs(
            data_inputs, max_series_per_request, max_values_per_request
        )
        total_values = sum(len(di.values) for di in data_inputs)

        logger.info(
            "Sending timeseries data: %d timeseries, %d values in %d batch(es)",
            len(data_inputs),
            total_values,
            len(batches),
        )

        for i, batch in enumerate(batches):
            batch_values = sum(len(di.values) for di in batch)
            logger.info(
                "Sending write batch %d/%d: %d timeseries, %d values",
                i + 1,
                len(batches),
                len(batch),
                batch_values,
            )
            self._client.timeseries.set_data(batch)

    def list_timeseries_values(
        self,
        inventory_name: str,
        timeseries_properties: str | list[str],
        from_time: datetime,
        to_time: datetime,
        namespace_name: str | None = None,
        properties: list[str] | None = None,
        where: dict[str, Any] | None = None,
        aggregation: Aggregation | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int | None = None,
        unit: str | None = None,
        exclude_qualities: list[Quality] | None = None,
        time_zone: str | None = None,
        max_values_per_request: int = 180_000,
        max_ids_per_request: int = 100,
    ) -> TimeSeriesResult:
        """Retrieve time series values for inventory items, with optional item filtering and value aggregation.

        Args:
            inventory_name: Name of inventory
            timeseries_properties: Property name(s) containing time series
            from_time: Start timestamp
            to_time: End timestamp
            namespace_name: Optional namespace filter
            properties: Additional item properties to include
            where: GraphQL filter conditions for inventory items. Operators depend on property type:
                - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                  `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - Numeric properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            aggregation: Optional data aggregation
            time_unit: Time interval unit for aggregation
            multiplier: Multiplier for time_unit
            unit: Target unit for value conversion (e.g. "kWh").
            exclude_qualities: Quality flags to exclude
            time_zone: Timezone for timestamps
            max_values_per_request: Global server limit for total values per request.
                Override when backend is configured differently. Default: 180_000.
            max_ids_per_request: Max timeseries IDs per request.
                Override when backend is configured differently. Default: 100.

        Returns:
            TimeSeriesResult with item and time series data

        Example:
            ```python
            from datetime import datetime, timedelta

            # Get time series values for all items
            end = datetime.now()
            start = end - timedelta(days=7)
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
            )

            # Filter by sensor status
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
                where={"status": {"eq": "active"}},
            )

            # Filter by location pattern
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties=["temperature", "humidity"],
                from_time=start,
                to_time=end,
                where={"location": {"startsWith": "building-A"}},
                properties=["name", "location"],
            )

            # Complex filter with multiple conditions
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
                where={
                    "and": [{"type": {"eq": "indoor"}}, {"floor": {"gte": 1, "lte": 3}}]
                },
            )

            # With aggregation
            from seven2one.questra.data import Aggregation, TimeUnit

            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
                where={"location": {"contains": "room"}},
                aggregation=Aggregation.AVERAGE,
                time_unit=TimeUnit.HOUR,
                multiplier=1,
            )
            ```
        """
        _agg_params = {
            "aggregation": aggregation,
            "time_unit": time_unit,
            "multiplier": multiplier,
        }
        _provided = [name for name, val in _agg_params.items() if val is not None]
        if _provided and len(_provided) < 3:
            _missing = [name for name, val in _agg_params.items() if val is None]
            raise ValueError(
                f"aggregation, time_unit, and multiplier must all be provided together. "
                f"Missing: {', '.join(_missing)}"
            )

        ts_properties = (
            [timeseries_properties]
            if isinstance(timeseries_properties, str)
            else timeseries_properties
        )

        logger.info(
            f"Listing timeseries values from inventory. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_properties={ts_properties}, properties={properties}"
        )

        # Step 1: Lade Inventory Items with Timeseries properties and normal properties
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_names = {tp: resolve_field_name(tp, schema) for tp in ts_properties}
        ts_fields = set(ts_field_names.values())
        query_properties = ["_id", "_rowVersion"]

        # Collect Timeseries subfields (z.B. "messwerte_temperatur.timeZone")
        ts_subfields = {ts_field: set() for ts_field in ts_fields}

        # Collect requested properties for DataFrame output and timeseries subfields for query
        item_properties: list[str] = []
        if properties:
            for prop in properties:
                query_prop, canonical_prop = self._map_property_path(
                    prop, schema, namespace_name
                )

                # Check whether it is a nested Timeseries Property
                is_ts_subfield = False
                if "." in prop:
                    root_prop, subfield = prop.split(".", 1)
                    try:
                        resolved_root = resolve_field_name(root_prop, schema)
                    except ValueError:
                        resolved_root = None

                    if resolved_root in ts_subfields:
                        ts_subfields[resolved_root].add(subfield)
                        item_properties.append(canonical_prop)
                        is_ts_subfield = True

                if not is_ts_subfield:
                    # _id is always the DataFrame column key – skip to avoid duplicate level
                    if query_prop.lower() == "_id":
                        continue
                    query_properties.append(query_prop)
                    item_properties.append(canonical_prop)

        # Add Timeseries Properties with ihren Subfeldern hinzu
        for fn in ts_fields:
            # Always query .id (for time series data)
            ts_subfields[fn].add("id")

            # Add all subfields as nested Properties hinzu
            for subfield in ts_subfields[fn]:
                query_properties.append(f"{fn}.{subfield}")

        items = list(
            PagedIterator(
                fetch_page=lambda after: self._client.inventory.list(
                    inventory_name=inventory_name,
                    namespace_name=namespace_name,
                    properties=query_properties,
                    where=where,
                    first=max_ids_per_request,
                    after=after,
                ),
                extract_items=lambda result: result.get("nodes", []),
                has_next_page=lambda result: result.get("pageInfo", {}).get(
                    "hasNextPage", False
                ),
                get_cursor=lambda result: result.get("pageInfo", {}).get("endCursor"),
            )
        )
        logger.debug(f"Found {len(items)} items with TimeSeries properties")

        if not items:
            logger.warning(f"No items found in {inventory_name}")
            return TimeSeriesResult({}, self, properties=item_properties or None)

        # Step 2: Extrahiere Timeseries IDs and create Mapping
        # Format: ts_id -> (item_id, property_name)
        ts_to_item_mapping = {}
        timeseries_ids = []

        for item in items:
            item_id = int(item["_id"])
            for field in ts_properties:
                normalized_field = ts_field_names[field]
                ts_data = item.get(normalized_field)
                if ts_data and isinstance(ts_data, dict) and "id" in ts_data:
                    # GraphQL returns IDs as strings, REST API uses integers
                    # Convert to int for consistent mapping
                    ts_id = int(ts_data["id"])
                    ts_to_item_mapping[ts_id] = {
                        "item_id": item_id,
                        "property_name": schema.name_mapping.get(
                            normalized_field, normalized_field
                        ),
                    }
                    timeseries_ids.append(ts_id)

        if not timeseries_ids:
            logger.warning("No TimeSeries IDs found in items")
            return TimeSeriesResult({}, self, properties=item_properties or None)

        logger.debug(f"Extracted {len(timeseries_ids)} TimeSeries IDs")

        # Step 3: Lade time series values
        # Default: only exclude MISSING
        if exclude_qualities is None:
            exclude_qualities = [Quality.MISSING]

        # Chunk IDs into batches, then apply time-window bisection per batch
        id_batches = [
            timeseries_ids[i : i + max_ids_per_request]
            for i in range(0, len(timeseries_ids), max_ids_per_request)
        ]
        logger.debug(
            "Fetching timeseries data: %d IDs in %d batch(es)",
            len(timeseries_ids),
            len(id_batches),
        )
        batch_results = [
            self._get_timeseries_data_chunked(
                timeseries_ids=batch,
                from_time=from_time,
                to_time=to_time,
                time_unit=time_unit,
                multiplier=multiplier,
                aggregation=aggregation,
                unit=unit,
                time_zone=time_zone,
                exclude_qualities=exclude_qualities,
                max_values_per_request=max_values_per_request,
            )
            for batch in id_batches
        ]
        # Merge batches — different IDs per batch, so only concatenation needed
        ts_result = TimeSeriesDataPayload(
            data=[ts for batch in batch_results for ts in batch.data]
        )

        # Step 4: Combine Results
        # Uniform structure: ALWAYS with "timeseries" dict
        # Rename item keys from GraphQL fieldName → canonical name (from inventory registry)
        item_index = {
            int(item["_id"]): _CaseInsensitiveDict(
                {schema.name_mapping.get(k, k): v for k, v in item.items()}
            )
            for item in items
        }
        result_dict: dict[int, _CaseInsensitiveDict] = {}

        for ts_data in ts_result.data:
            ts_id = ts_data.time_series_id
            if ts_id not in ts_to_item_mapping:
                continue

            mapping = ts_to_item_mapping[ts_id]
            item_id = mapping["item_id"]
            property_name = mapping["property_name"]

            # Initialize item entry if needed
            if item_id not in result_dict:
                result_dict[item_id] = _CaseInsensitiveDict(
                    {
                        "item": item_index[item_id],
                        "timeseries": {},
                    }
                )

            # Store TimeSeries data ALWAYS under timeseries[property_name]
            result_dict[item_id]["timeseries"][property_name] = {
                "timeseries_id": ts_id,
                "values": ts_data.values,
                "unit": ts_data.unit,
                "interval": ts_data.interval,
                "time_zone": ts_data.time_zone,
            }

        logger.info(f"Listed timeseries values for {len(result_dict)} items")
        return TimeSeriesResult(result_dict, self, properties=item_properties or None)

    def _convert_timeseries_to_dataframe(
        self,
        result: Mapping[int, dict],
        properties: list[str] | None = None,
    ) -> pd.DataFrame:
        if not _PANDAS_AVAILABLE:
            raise ImportError("pandas is required for DataFrame conversion")

        # Collect all data and item information
        # {(property, unit, item_id): {time: value}}
        data_dict = {}
        # {item_id: {property_name: field_value}}
        item_properties_dict = {}

        def get_nested_value(d: dict, path: str):
            """Extract value from nested dict using dot notation."""
            keys = path.split(".")
            value = d
            for key in keys:
                if isinstance(value, dict):
                    value = value.get(key)
                else:
                    return None
            return value

        for item_id, data in result.items():
            # Collect normal properties for this item
            if properties:
                item_properties_dict[item_id] = {}
                for field in properties:
                    # Support nested properties (e.g. "messwerte_temperatur.timeZone")
                    item_properties_dict[item_id][field] = get_nested_value(
                        data["item"], field
                    )

            # Unitliche Struktur: IMMER data["timeseries"]
            for property_name, ts_data in data["timeseries"].items():
                values = ts_data["values"]
                unit = ts_data.get("unit") or ""

                key = (property_name, unit, item_id)
                data_dict[key] = {
                    ts_value.time: float(ts_value.value) for ts_value in values
                }

        if not data_dict:
            # Leerer DataFrame
            return pd.DataFrame()  # type: ignore

        # Create DataFrame from dict
        # Collect columns as List of Tuples (property_name, unit, item_id)
        columns_list = []
        series_data: list[tuple[list, list]] = []

        detected_tz = None
        for (property_name, unit, item_id), time_values in data_dict.items():
            columns_list.append((property_name, unit, item_id))
            times = list(time_values.keys())
            vals = list(time_values.values())
            series_data.append((times, vals))
            if detected_tz is None and times:
                detected_tz = getattr(times[0], "tzinfo", None)

        # Build Series with a consistent tz so pandas can align them.
        # Empty time_values produce a tz-naive DatetimeIndex by default which
        # causes "Cannot join tz-naive with tz-aware DatetimeIndex" when mixed
        # with non-empty tz-aware series in pd.DataFrame().
        series_list = []
        for times, vals in series_data:
            if times:
                idx: pd.DatetimeIndex = pd.DatetimeIndex(times)
            elif detected_tz is not None:
                idx = pd.DatetimeIndex([], tz=detected_tz)
            else:
                idx = pd.DatetimeIndex([])
            series_list.append(pd.Series(vals, index=idx))  # type: ignore

        if not columns_list:
            return pd.DataFrame()  # type: ignore

        # Create DataFrame with MultiIndex columns
        df = pd.DataFrame(dict(enumerate(series_list)))  # type: ignore
        df.index = pd.to_datetime(df.index)
        df.index.name = "time"
        df = df.sort_index()

        # Check ob all Units per Timeseries-Field gleich sind
        # If yes, we can simplify the unit level
        field_units = {}
        for ts_field, unit, item in columns_list:
            if ts_field not in field_units:
                field_units[ts_field] = set()
            field_units[ts_field].add(unit)

        # If all TimeSeries properties have only a single unit, simplify
        all_single_unit = all(len(units) == 1 for units in field_units.values())

        # Create MultiIndex with normalen properties as Spalten-Ebenen
        if properties and item_properties_dict:
            # Extend columns_list with field values
            # Struktur: (ts_field, unit, field1_value, field2_value, ..., item_id)
            extended_columns = []
            for ts_field, unit, item_id in columns_list:
                # Get field values for this Item
                field_values = []
                if item_id in item_properties_dict:
                    for field in properties:
                        field_values.append(item_properties_dict[item_id].get(field))
                else:
                    field_values = [None] * len(properties)

                # Baue Spalten-Tuple
                if all_single_unit:
                    # (ts_field [unit], field1, field2, ..., item_id)
                    ts_field_with_unit = f"{ts_field} [{unit}]" if unit else ts_field
                    extended_columns.append(
                        (ts_field_with_unit, *field_values, item_id)
                    )
                else:
                    # (ts_field, unit, field1, field2, ..., item_id)
                    extended_columns.append((ts_field, unit, *field_values, item_id))

            # Create names for the MultiIndex-Ebenen
            if all_single_unit:
                column_names = ["Timeseries-Field [Unit]"] + properties + ["_Id"]
            else:
                column_names = ["Timeseries-Field", "Unit"] + properties + ["_Id"]

            df.columns = pd.MultiIndex.from_tuples(  # type: ignore
                extended_columns, names=column_names
            )
        else:
            # No normalen properties: like vorher
            if all_single_unit:
                # Vereinfachter MultiIndex: Timeseries-Field and Item-ID
                # Unit is combined with field in the first level
                simplified_columns = []
                for ts_field, unit, item in columns_list:
                    ts_field_with_unit = f"{ts_field} [{unit}]" if unit else ts_field
                    simplified_columns.append((ts_field_with_unit, item))

                df.columns = pd.MultiIndex.from_tuples(  # type: ignore
                    simplified_columns, names=["Timeseries-Field [Unit]", "_Id"]
                )
            else:
                # Voller MultiIndex: Timeseries-Field, Unit, Item-ID
                df.columns = pd.MultiIndex.from_tuples(  # type: ignore
                    columns_list, names=["Timeseries-Field", "Unit", "_Id"]
                )

        return df

    def save_timeseries_values(
        self,
        inventory_name: str,
        timeseries_property: str,
        item_id: int,
        values: list[TimeSeriesValue],
        namespace_name: str | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int = 1,
        unit: str | None = None,
        time_zone: str | None = None,
        max_series_per_request: int = 100,
        max_values_per_request: int = 36_000,
    ) -> None:
        """Save time series values for a single inventory item.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            item_id: Item ID
            values: Time series values to save
            namespace_name: Optional namespace
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit
            unit: Measurement unit
            time_zone: Timezone for values
            max_series_per_request: Maximum timeseries per write request (default: 100).
            max_values_per_request: Maximum total values per write request (default: 36000).
        """
        logger.info(
            f"Saving timeseries values for single item. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, item_id={item_id}, value_count={len(values)}"
        )

        # Delegiere to Bulk-Methode
        self.save_timeseries_values_bulk(
            inventory_name=inventory_name,
            timeseries_properties=timeseries_property,
            item_values={item_id: values},
            namespace_name=namespace_name,
            time_unit=time_unit,
            multiplier=multiplier,
            unit=unit,
            time_zone=time_zone,
            max_series_per_request=max_series_per_request,
            max_values_per_request=max_values_per_request,
        )

    def save_timeseries_values_bulk(
        self,
        inventory_name: str,
        timeseries_properties: str | list[str],
        item_values: dict[int, list[TimeSeriesValue]]
        | dict[int, dict[str, list[TimeSeriesValue]]],
        namespace_name: str | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int = 1,
        unit: str | None = None,
        time_zone: str | None = None,
        max_series_per_request: int = 100,
        max_values_per_request: int = 36_000,
    ) -> None:
        """Save time series values for multiple inventory items in a single batch operation.

        The structure of ``item_values`` depends on how many timeseries properties are given:

        - **Single property** (``timeseries_properties`` is a ``str`` or single-element list):
          Map each item ID to a flat ``list[TimeSeriesValue]``.
        - **Multiple properties** (``timeseries_properties`` is a list with ≥ 2 entries):
          Map each item ID to a ``dict[property_name, list[TimeSeriesValue]]``, where
          each key is one of the property names passed in ``timeseries_properties``.

        Args:
            inventory_name: Name of inventory.
            timeseries_properties: Property name(s) containing time series data.
                Pass a single string for one property, or a list of strings for multiple.
            item_values: Dict mapping item IDs (int) to their time series values.
                Single-property mode: ``{item_id: [TimeSeriesValue(...), ...]}``.
                Multi-property mode:  ``{item_id: {"prop_a": [...], "prop_b": [...]}}``.
            namespace_name: Optional namespace override.
            time_unit: Time interval unit (e.g. ``TimeUnit.HOUR``).
            multiplier: Multiplier for ``time_unit`` (default: 1).
            unit: Measurement unit string (e.g. ``"°C"``).
            time_zone: IANA timezone name for the values (e.g. ``"Europe/Berlin"``).
            max_series_per_request: Maximum timeseries per write request (default: 100).
            max_values_per_request: Maximum total values per write request (default: 36000).

        Examples:
            Single timeseries property — item ID is the dict key, values are a flat list:

            ```python
            from datetime import datetime, timezone
            from seven2one.questra.data.generated.rest_models import TimeSeriesValue

            t1 = datetime(2025, 1, 1, 0, 0, tzinfo=timezone.utc)
            t2 = datetime(2025, 1, 1, 1, 0, tzinfo=timezone.utc)

            client.save_timeseries_values_bulk(
                inventory_name="WeatherStation",
                timeseries_properties="temperature",
                item_values={
                    101: [
                        TimeSeriesValue(time=t1, value=12.3),
                        TimeSeriesValue(time=t2, value=13.1),
                    ],
                    102: [
                        TimeSeriesValue(time=t1, value=9.8),
                        TimeSeriesValue(time=t2, value=10.2),
                    ],
                },
                unit="°C",
                time_zone="Europe/Berlin",
            )
            ```

            Multiple timeseries properties — the inner dict key selects the property:

            ```python
            client.save_timeseries_values_bulk(
                inventory_name="WeatherStation",
                timeseries_properties=["temperature", "humidity"],
                item_values={
                    101: {
                        "temperature": [TimeSeriesValue(time=t1, value=12.3)],
                        "humidity": [TimeSeriesValue(time=t1, value=68.0)],
                    },
                    102: {
                        "temperature": [TimeSeriesValue(time=t1, value=9.8)],
                        "humidity": [TimeSeriesValue(time=t1, value=72.5)],
                    },
                },
            )
            ```
        """
        ts_properties = (
            [timeseries_properties]
            if isinstance(timeseries_properties, str)
            else timeseries_properties
        )

        logger.info(
            f"Saving timeseries values for inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, item_count={len(item_values)}, timeseries_properties={ts_properties}"
        )

        if not item_values:
            logger.warning("No item values provided")
            return

        # Step 1: Lade Inventory Items with Timeseries properties
        # Note: _id verwendet lowercase Filter (eq, in) statt _eq, _in
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_names = {tp: resolve_field_name(tp, schema) for tp in ts_properties}
        item_ids = list(item_values.keys())

        # Create properties list with all Timeseries-properties
        properties = ["_id"]
        for field in ts_properties:
            fn = ts_field_names[field]
            properties.append(f"{fn}.id")

        items = []
        for _chunk_start in range(0, len(item_ids), max_series_per_request):
            _id_chunk = item_ids[_chunk_start : _chunk_start + max_series_per_request]
            _chunk_where = {"_id": {"in": [str(x) for x in _id_chunk]}}
            _chunk_result = self._client.inventory.list(
                inventory_name=inventory_name,
                namespace_name=namespace_name,
                properties=properties,
                where=_chunk_where,
                first=len(_id_chunk),
            )
            items.extend(_chunk_result.get("nodes", []))
        logger.debug(f"Found {len(items)} items")

        # Step 2: Erstelle SetTimeSeriesDataInput for all Timeseries-properties
        from .models import Interval

        data_inputs = []

        # Check whether we are with multiple Timeseries-properties arbeiten
        is_multi_field = len(ts_properties) > 1

        for item in items:
            item_id = int(item["_id"])
            item_value_data = item_values.get(item_id)

            if not item_value_data:
                continue

            # Verarbeite jedes Timeseries-Field
            for field in ts_properties:
                normalized_field = ts_field_names[field]
                ts_data = item.get(normalized_field)

                if not ts_data or not isinstance(ts_data, dict) or "id" not in ts_data:
                    logger.warning(
                        f"Item {item_id} has no valid TimeSeries field '{field}' "
                        f"(field: '{normalized_field}')"
                    )
                    continue

                # GraphQL returns IDs as strings, REST API uses integers
                ts_id = int(ts_data["id"])

                # Get Werte basierend auf Modus (single vs. multi field)
                if is_multi_field:
                    # Multi-Field-Modus: item_value_data ist Dict[str, list[TimeSeriesValue]]
                    if not isinstance(item_value_data, dict):
                        expected_fields = ", ".join(
                            f'"{p}": [...]' for p in ts_properties
                        )
                        raise ValueError(
                            f"Item {item_id}: Multi-field mode requires dict structure.\n"
                            f"Expected: {{{expected_fields}}}\n"
                            f"Got {type(item_value_data).__name__}: {item_value_data!r}"
                        )
                    values = item_value_data.get(field, [])
                else:
                    # Single-Field-Modus: item_value_data ist list[TimeSeriesValue]
                    if isinstance(item_value_data, dict):
                        hint_props = ", ".join(f'"{k}"' for k in item_value_data.keys())
                        raise ValueError(
                            f"Item {item_id}: Single-field mode requires list structure.\n"
                            f"Expected: [TimeSeriesValue(...), ...]\n"
                            f"Got dict with keys: {list(item_value_data.keys())}\n"
                            f"Hint: For multiple properties, pass them as list: "
                            f"timeseries_properties=[{hint_props}]"
                        )
                    values = item_value_data

                if values:
                    data_input = SetTimeSeriesDataInput(
                        time_series_id=ts_id,
                        values=values,
                        interval=Interval(time_unit=time_unit, multiplier=multiplier)
                        if time_unit
                        else None,
                        unit=unit,
                        time_zone=time_zone,
                        quotation_time=None,
                    )
                    data_inputs.append(data_input)

        # Step 3: Speichere values via REST API
        if data_inputs:
            self._send_timeseries_data_chunked(
                data_inputs, max_series_per_request, max_values_per_request
            )
            total_values = sum(len(di.values) for di in data_inputs)
            logger.info(
                f"Saved {total_values} values for {len(data_inputs)} TimeSeries"
            )
        else:
            logger.warning("No valid data inputs created")

    # ===== Quotation Operations =====

    def list_quotation_timestamps(
        self,
        inventory_name: str,
        timeseries_property: str,
        from_time: datetime,
        to_time: datetime,
        namespace_name: str | None = None,
        where: dict[str, Any] | None = None,
        aggregated: bool = False,
    ) -> dict[int, list[datetime]] | list[datetime]:
        """List the quotation timestamps available for a time series property within a given time range.

                Args:
                    inventory_name: Name of inventory
                    timeseries_property: Time series property name
                    from_time: Start timestamp
                    to_time: End timestamp
                    namespace_name: Optional namespace
                    where: GraphQL filter conditions for inventory items. Operators depend on property type:
                        - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                          `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                        - Numeric properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                          `ngte`, `lt`, `nlt`, `lte`, `nlte`
                        - Root level: `and`, `or`
                    aggregated: If True, return unique timestamps across all items

                Returns:
                    Dict mapping item IDs to timestamps, or list of unique timestamps if aggregated

                Example:
                    ```python
                    from datetime import datetime, timedelta

                    # List all available quotation timestamps
                    end = datetime.now()
                    start = end - timedelta(days=30)
                    timestamps = client.list_quotation_timestamps(
                        inventory_name="Products",
                        timeseries_property="price_history",
                        from_time=start,
                        to_time=end,
                    )
        # Returns: {42: [datetime1, datetime2], 43: [...]}

                    # Get aggregated timestamps across all items
                    all_timestamps = client.list_quotation_timestamps(
                        inventory_name="Products",
                        timeseries_property="price_history",
                        from_time=start,
                        to_time=end,
                        aggregated=True,
                    )
                    # Returns: [datetime1, datetime2, datetime3, ...]

                    # Filter by product category
                    timestamps = client.list_quotation_timestamps(
                        inventory_name="Products",
                        timeseries_property="price_history",
                        from_time=start,
                        to_time=end,
                        where={"category": {"eq": "electronics"}},
                    )

                    # Filter by multiple categories
                    timestamps = client.list_quotation_timestamps(
                        inventory_name="Products",
                        timeseries_property="price_history",
                        from_time=start,
                        to_time=end,
                        where={"category": {"in": ["electronics", "appliances"]}},
                    )

                    # Complex filter
                    timestamps = client.list_quotation_timestamps(
                        inventory_name="Products",
                        timeseries_property="price_history",
                        from_time=start,
                        to_time=end,
                        where={
                            "and": [
                                {"category": {"eq": "electronics"}},
                                {"brand": {"startsWith": "Premium"}},
                            ]
                        },
                        aggregated=True,
                    )
                    ```
        """
        logger.info(
            f"Listing quotation timestamps. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, aggregated={aggregated}"
        )

        # Step 1: Lade Inventory Items with Timeseries Property
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_name = resolve_field_name(timeseries_property, schema)
        properties = ["_id", f"{ts_field_name}.id"]

        items = list(
            PagedIterator(
                fetch_page=lambda after: self._client.inventory.list(
                    inventory_name=inventory_name,
                    namespace_name=namespace_name,
                    properties=properties,
                    where=where,
                    first=1000,
                    after=after,
                ),
                extract_items=lambda result: result.get("nodes", []),
                has_next_page=lambda result: result.get("pageInfo", {}).get(
                    "hasNextPage", False
                ),
                get_cursor=lambda result: result.get("pageInfo", {}).get("endCursor"),
            )
        )
        logger.debug(f"Found {len(items)} items with TimeSeries property")

        if not items:
            logger.warning(f"No items found in {inventory_name}")
            return [] if aggregated else {}

        # Step 2: Extrahiere Timeseries IDs
        timeseries_ids = []
        ts_to_item_mapping = {}

        normalized_field = ts_field_name

        for item in items:
            item_id = int(item["_id"])
            ts_data = item.get(normalized_field)
            if ts_data and isinstance(ts_data, dict) and "id" in ts_data:
                # GraphQL returns IDs as strings, REST API uses integers
                # Convert to int for consistent mapping
                ts_id = int(ts_data["id"])
                timeseries_ids.append(ts_id)
                ts_to_item_mapping[ts_id] = item_id

        if not timeseries_ids:
            logger.warning("No TimeSeries IDs found in items")
            return [] if aggregated else {}

        logger.debug(f"Extracted {len(timeseries_ids)} TimeSeries IDs")

        # Step 3: Lade quotations
        try:
            quotations_result = self._client.timeseries.get_quotations(
                time_series_ids=timeseries_ids,
                from_time=from_time,
                to_time=to_time,
                aggregated=aggregated,
            )
        except Exception as e:
            # REST API kann Fehler zurückgeben, wenn z.B. keine Quotations vorhanden sind
            logger.warning(f"Failed to get quotations: {e}. Returning empty result.")
            return [] if aggregated else {}

        # Step 4: Verarbeite Ergebnisse
        if aggregated:
            # Aggregated: Sammle all unique quotation timestamps
            all_timestamps = set()
            for quotations in quotations_result.items:
                if quotations.values:
                    for quot_value in quotations.values:
                        all_timestamps.add(quot_value.time)

            result_list = sorted(list(all_timestamps))
            logger.info(
                f"Found {len(result_list)} unique quotation timestamps (aggregated)"
            )
            return result_list
        else:
            # Pro Item: Mapping Item-ID -> Notierungs-Zeitstempel
            item_quotations = {}
            for quotations in quotations_result.items:
                ts_id = quotations.time_series_id
                if ts_id in ts_to_item_mapping and quotations.values:
                    item_id = ts_to_item_mapping[ts_id]
                    timestamps = [quot_value.time for quot_value in quotations.values]
                    item_quotations[item_id] = sorted(timestamps)

            logger.info(f"Found quotations for {len(item_quotations)} items")
            return item_quotations

    def list_quotation_values(
        self,
        inventory_name: str,
        timeseries_property: str,
        from_time: datetime,
        to_time: datetime,
        quotation_time: datetime | None = None,
        quotation_behavior: QuotationBehavior = QuotationBehavior.LATEST,
        quotation_exactly_at: bool = False,
        namespace_name: str | None = None,
        where: dict[str, Any] | None = None,
        properties: list[str] | None = None,
        aggregation: Aggregation | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int | None = None,
        unit: str | None = None,
        exclude_qualities: list[Quality] | None = None,
        time_zone: str | None = None,
        max_values_per_request: int = 180_000,
        max_ids_per_request: int = 100,
    ) -> dict[int, dict]:
        """Retrieve time series values for inventory items at a specific quotation timestamp.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            from_time: Start timestamp
            to_time: End timestamp
            quotation_time: Optional specific quotation timestamp
            quotation_behavior: How to select quotation if not exact
            quotation_exactly_at: Require exact quotation match
            namespace_name: Optional namespace
            where: GraphQL filter conditions for inventory items. Operators depend on property type:
                - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                  `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - Numeric properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            properties: Additional item properties to include
            aggregation: Optional data aggregation
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit
            unit: Target unit for value conversion (e.g. "kWh").
            exclude_qualities: Quality flags to exclude
            time_zone: Timezone for timestamps
            max_values_per_request: Global server limit for total values per request.
                Override when backend is configured differently. Default: 180_000.
            max_ids_per_request: Max timeseries IDs per request.
                Override when backend is configured differently. Default: 100.

        Returns:
            Dict mapping item IDs to item and time series data

        Example:
            ```python
            from datetime import datetime, timedelta
            from seven2one.questra.data import QuotationBehavior

            # Get latest quotation for all items
            end = datetime.now()
            start = end - timedelta(days=7)
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
            )
            # Returns: {"item_id": {"item": {...}, "timeseries": {...}}}

            # Get specific quotation
            quot_time = datetime(2026, 1, 15, 12, 0, 0)
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                quotation_time=quot_time,
                quotation_exactly_at=True,
            )

            # Get quotation with fallback behavior
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                quotation_time=quot_time,
                quotation_behavior=QuotationBehavior.PREVIOUS,
            )

            # Filter by product category
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"category": {"eq": "electronics"}},
                properties=["name", "category", "brand"],
            )

            # Filter by price range (numeric property)
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"base_price": {"gte": 100, "lte": 500}},
            )

            # Complex filter with multiple conditions
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={
                    "and": [
                        {"category": {"eq": "electronics"}},
                        {
                            "or": [
                                {"brand": {"startsWith": "Premium"}},
                                {"brand": {"eq": "Luxury"}},
                            ]
                        },
                    ]
                },
                quotation_time=quot_time,
            )

            # With aggregation (hourly averages)
            from seven2one.questra.data import Aggregation, TimeUnit

            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"category": {"in": ["electronics", "appliances"]}},
                aggregation=Aggregation.AVERAGE,
                time_unit=TimeUnit.HOUR,
                multiplier=1,
            )
            ```
        """
        _agg_params = {
            "aggregation": aggregation,
            "time_unit": time_unit,
            "multiplier": multiplier,
        }
        _provided = [name for name, val in _agg_params.items() if val is not None]
        if _provided and len(_provided) < 3:
            _missing = [name for name, val in _agg_params.items() if val is None]
            raise ValueError(
                f"aggregation, time_unit, and multiplier must all be provided together. "
                f"Missing: {', '.join(_missing)}"
            )

        logger.info(
            f"Getting quotation data. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, quotation_time={quotation_time}, quotation_behavior={quotation_behavior}"
        )

        # Step 1: Lade Inventory Items with Timeseries Property
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_name = resolve_field_name(timeseries_property, schema)
        query_properties = ["_id", "_rowVersion"]

        # Add Timeseries Property hinzu
        query_properties.append(f"{ts_field_name}.id")

        # Add additional properties
        if properties:
            for prop in properties:
                if prop not in query_properties:
                    query_properties.append(prop)

        items = list(
            PagedIterator(
                fetch_page=lambda after: self._client.inventory.list(
                    inventory_name=inventory_name,
                    namespace_name=namespace_name,
                    properties=query_properties,
                    where=where,
                    first=max_ids_per_request,
                    after=after,
                ),
                extract_items=lambda result: result.get("nodes", []),
                has_next_page=lambda result: result.get("pageInfo", {}).get(
                    "hasNextPage", False
                ),
                get_cursor=lambda result: result.get("pageInfo", {}).get("endCursor"),
            )
        )
        logger.debug(f"Found {len(items)} items with TimeSeries property")

        if not items:
            logger.warning(f"No items found in {inventory_name}")
            return {}

        # Step 2: Extrahiere Timeseries IDs
        normalized_field = ts_field_name
        timeseries_ids = []
        ts_to_item_mapping = {}

        for item in items:
            item_id = int(item["_id"])
            ts_data = item.get(normalized_field)
            if ts_data and isinstance(ts_data, dict) and "id" in ts_data:
                # GraphQL returns IDs as strings, REST API uses integers
                # Convert to int for consistent mapping
                ts_id = int(ts_data["id"])
                ts_to_item_mapping[ts_id] = item_id
                timeseries_ids.append(ts_id)

        if not timeseries_ids:
            logger.warning("No TimeSeries IDs found in items")
            return {}

        logger.debug(f"Extracted {len(timeseries_ids)} TimeSeries IDs")

        # Step 3: Lade time series values with Quotation
        # Default: only exclude MISSING
        if exclude_qualities is None:
            exclude_qualities = [Quality.MISSING]

        # Chunk IDs into batches, then apply time-window bisection per batch
        id_batches = [
            timeseries_ids[i : i + max_ids_per_request]
            for i in range(0, len(timeseries_ids), max_ids_per_request)
        ]
        logger.debug(
            "Fetching quotation timeseries data: %d IDs in %d batch(es)",
            len(timeseries_ids),
            len(id_batches),
        )
        batch_results = [
            self._get_timeseries_data_chunked(
                timeseries_ids=batch,
                from_time=from_time,
                to_time=to_time,
                time_unit=time_unit,
                multiplier=multiplier,
                aggregation=aggregation,
                time_zone=time_zone,
                exclude_qualities=exclude_qualities,
                max_values_per_request=max_values_per_request,
                unit=unit,
                quotation_time=quotation_time,
                quotation_exactly_at=quotation_exactly_at,
                quotation_behavior=quotation_behavior,
            )
            for batch in id_batches
        ]
        ts_result = TimeSeriesDataPayload(
            data=[ts for batch in batch_results for ts in batch.data]
        )

        # Step 4: Combine Results
        item_index = {int(item["_id"]): item for item in items}
        result_dict = {}

        for ts_data in ts_result.data:
            ts_id = ts_data.time_series_id
            if ts_id not in ts_to_item_mapping:
                continue

            item_id = ts_to_item_mapping[ts_id]

            # Initialize item entry if needed
            if item_id not in result_dict:
                result_dict[item_id] = {
                    "item": item_index[item_id],
                    "quotation_time": None,  # Set as needed
                    "timeseries": {},
                }

            # Speichere Timeseries Daten
            result_dict[item_id]["timeseries"][timeseries_property] = {
                "timeseries_id": ts_id,
                "values": ts_data.values,
                "unit": ts_data.unit,
                "interval": ts_data.interval,
                "time_zone": ts_data.time_zone,
            }

            # TODO: quotation_time extract from Response if available
            # Currently the API does not return the actually used quotation

        logger.info(f"Loaded quotation data for {len(result_dict)} items")
        return result_dict

    def save_quotation_values(
        self,
        inventory_name: str,
        timeseries_property: str,
        item_id: int,
        values: list[TimeSeriesValue],
        quotation_time: datetime,
        namespace_name: str | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int = 1,
        unit: str | None = None,
        time_zone: str | None = None,
        max_values_per_request: int = 36_000,
    ) -> None:
        """Save time series values for a single inventory item under a specific quotation timestamp.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            item_id: Item ID
            values: Time series values to save
            quotation_time: Quotation timestamp
            namespace_name: Optional namespace
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit
            unit: Measurement unit
            time_zone: Timezone for values
            max_values_per_request: Maximum total values per write request (default: 36000).
        """
        logger.info(
            f"Saving quotation data for single item. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, item_id={item_id}, quotation_time={quotation_time}, value_count={len(values)}"
        )

        # Step 1: Lade Item mit Timeseries Property
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_name = resolve_field_name(timeseries_property, schema)
        where = {"_id": {"eq": str(item_id)}}
        properties = ["_id", f"{ts_field_name}.id"]

        result = self._client.inventory.list(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            properties=properties,
            where=where,
            first=1,
        )

        items = result.get("nodes", [])
        if not items:
            raise ValueError(f"Item with ID {item_id} not found in {inventory_name}")

        item = items[0]
        ts_data = item.get(ts_field_name)

        if not ts_data or not isinstance(ts_data, dict) or "id" not in ts_data:
            raise ValueError(
                f"Item {item_id} has no valid TimeSeries property '{timeseries_property}' "
                f"(field: '{ts_field_name}')"
            )

        # GraphQL returns IDs as strings, REST API uses integers
        ts_id = int(ts_data["id"])
        logger.debug(f"Found TimeSeries ID {ts_id} for item {item_id}")

        # Step 2: Erstelle SetTimeSeriesDataInput with quotation
        from .models import Interval

        data_input = SetTimeSeriesDataInput(
            time_series_id=ts_id,
            values=values,
            interval=Interval(time_unit=time_unit, multiplier=multiplier)
            if time_unit
            else None,
            unit=unit,
            time_zone=time_zone,
            quotation_time=quotation_time,  # ← Notierungs-Zeitstempel!
        )

        # Step 3: Speichere values via REST API
        self._send_timeseries_data_chunked(
            [data_input],
            max_series_per_request=1,
            max_values_per_request=max_values_per_request,
        )
        logger.info(
            f"Saved {len(values)} values with quotation_time={quotation_time} for TimeSeries {ts_id}"
        )

    def compare_quotations(
        self,
        inventory_name: str,
        timeseries_property: str,
        item_id: int,
        quotation_times: list[datetime],
        from_time: datetime,
        to_time: datetime,
        namespace_name: str | None = None,
        aggregation: Aggregation | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int | None = None,
    ) -> pd.DataFrame:
        """Compare time series values across multiple quotation timestamps for a single item.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            item_id: Item ID to compare
            quotation_times: List of quotation timestamps to compare
            from_time: Start timestamp
            to_time: End timestamp
            namespace_name: Optional namespace
            aggregation: Optional data aggregation
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit

        Returns:
            pandas DataFrame with quotation comparison

        Raises:
            ImportError: If pandas is not installed
        """
        if not _PANDAS_AVAILABLE:
            raise ImportError(
                "pandas is required for DataFrame output. "
                "Install with: pip install seven2one-questra-data[pandas]"
            )

        if not quotation_times:
            raise ValueError("At least one quotation_time is required")

        logger.info(
            f"Comparing quotations. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, item_id={item_id}, quotation_count={len(quotation_times)}"
        )

        # Load Daten for each quotation
        all_data = {}
        for quot_time in quotation_times:
            logger.debug(f"Loading data for quotation {quot_time}")
            data = self.list_quotation_values(
                inventory_name=inventory_name,
                timeseries_property=timeseries_property,
                from_time=from_time,
                to_time=to_time,
                quotation_time=quot_time,
                quotation_exactly_at=True,  # Exakt diese Notierung
                namespace_name=namespace_name,
                where={"_id": {"eq": str(item_id)}},
                aggregation=aggregation,
                time_unit=time_unit,
                multiplier=multiplier,
            )

            # Extract values for this item
            if item_id in data:
                item_data = data[item_id]
                if timeseries_property in item_data["timeseries"]:
                    ts_values = item_data["timeseries"][timeseries_property]["values"]
                    all_data[quot_time] = ts_values
                else:
                    logger.warning(
                        f"No data for quotation {quot_time} and property {timeseries_property}"
                    )
                    all_data[quot_time] = []
            else:
                logger.warning(f"No data for quotation {quot_time} and item {item_id}")
                all_data[quot_time] = []

        # Create DataFrame with MultiIndex columns
        # Format: (quotation_time, "value") and (quotation_time, "quality")
        data_dict = {}

        for quot_time, values in all_data.items():
            # Column for values
            value_series = pd.Series(  # type: ignore
                {val.time: float(val.value) for val in values},
                name=(quot_time, "value"),
            )
            data_dict[(quot_time, "value")] = value_series

            # Column for quality
            quality_series = pd.Series(  # type: ignore
                {
                    val.time: val.quality.value if val.quality else None
                    for val in values
                },
                name=(quot_time, "quality"),
            )
            data_dict[(quot_time, "quality")] = quality_series

        # Create DataFrame
        df = pd.DataFrame(data_dict)  # type: ignore
        df.index.name = "time"
        df = df.sort_index()

        # Set MultiIndex for columns
        df.columns = pd.MultiIndex.from_tuples(  # type: ignore
            df.columns, names=["quotation_time", "metric"]
        )

        logger.info(f"Created comparison DataFrame with {len(df)} rows")
        return df

    # ===== Inventory Operations =====

    def list_items(
        self,
        inventory_name: str,
        properties: list[str] | None = None,
        namespace_name: str | None = None,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[dict[str, Any]]:
        """Iterate over all items from the given inventory with automatic pagination.

        Args:
            inventory_name: Name of inventory
            properties: Properties to retrieve (defaults to _id and _rowVersion)
            namespace_name: Optional namespace filter
            where: GraphQL filter conditions. Operators depend on property type:
                - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                  `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - Numeric properties (Int, Long): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`,
                  `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - UUID properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
                Note: Negated operators (prefixed with 'n') negate the condition.
            order: Sort order (list of dicts, e.g. ``[{"name": "ASC"}]``)
            page_size: Number of items per page

        Yields:
            Item dicts with canonical property names as keys.

        Example:
            ```python
            # Iterate over all items
            for item in client.list_items(
                "Sensors", properties=["_id", "name", "status"]
            ):
                print(item)

            # Collect all items into a list
            all_items = list(client.list_items("Sensors"))

            # Filter by exact value
            for item in client.list_items(
                "Sensors", where={"status": {"eq": "active"}}
            ):
                print(item)

            # Filter by value list
            for item in client.list_items(
                "Sensors", where={"type": {"in": ["temperature", "humidity"]}}
            ):
                print(item)

            # Exclude values
            for item in client.list_items(
                "Sensors", where={"status": {"nin": ["inactive", "deleted"]}}
            ):
                print(item)

            # Filter by string pattern
            for item in client.list_items(
                "Sensors", where={"name": {"startsWith": "sensor-"}}
            ):
                print(item)

            # Numeric comparison
            for item in client.list_items(
                "Sensors", where={"temperature": {"gte": 20, "lte": 25}}
            ):
                print(item)

            # Complex filter with AND
            for item in client.list_items(
                "Sensors",
                where={
                    "and": [
                        {"status": {"eq": "active"}},
                        {"location": {"contains": "building-A"}},
                    ]
                },
            ):
                print(item)

            # Take only the first 10 items (stops fetching after first page if page_size >= 10)
            from itertools import islice

            first_10 = list(islice(client.list_items("Sensors"), 10))
            ```
        """
        logger.info(
            f"Listing inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}"
        )

        if properties is None:
            properties = ["_id", "_rowVersion"]

        schema = self._registry.get(inventory_name, namespace_name)
        resolved_properties, schema = self._validate_and_resolve_properties(
            properties, schema, inventory_name, namespace_name
        )
        name_mapping = schema.name_mapping

        return PagedQueryResult(
            PagedIterator(
                fetch_page=lambda after: self._client.inventory.list(
                    inventory_name=inventory_name,
                    namespace_name=namespace_name,
                    properties=resolved_properties,
                    where=where,
                    order=order,
                    first=page_size,
                    after=after,
                ),
                extract_items=lambda result: [
                    _CaseInsensitiveDict(item)
                    for item in self._remap_response(
                        result.get("nodes", []), name_mapping
                    )
                ],
                has_next_page=lambda result: result.get("pageInfo", {}).get(
                    "hasNextPage", False
                ),
                get_cursor=lambda result: result.get("pageInfo", {}).get("endCursor"),
            )
        )

    def create_items(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
        max_items_per_request: int = 20_000,
        max_ids_per_request: int = 100,
    ) -> QueryResult[dict[str, Any]]:
        """Create one or more items in the given inventory.

        **Automatic time series creation:** For every TIME_SERIES property in
        the inventory schema, the value in each item dict controls the
        behaviour:

        - ``None`` – a new TimeSeries object is created automatically and its
          ID is written back into the item dict before the inventory mutation
          is sent.
        - ``str`` or ``int`` – interpreted as an existing TimeSeries ID; the
          value is kept as-is (normalised to ``int``).
        - Any other type – raises ``ValueError``.

        If the inventory has no TIME_SERIES properties, this step is skipped
        entirely.

        Note:
            The returned dicts contain only ``_id``, ``_rowVersion``, and
            ``_existed``.  Original property values are **not** reflected in
            the return value.  Merge them with the input dicts when you need
            the full item representation.

        Args:
            inventory_name: Name of inventory
            items: List of item dicts to create.  For TIME_SERIES properties
                set the value to ``None`` to auto-create a new TimeSeries, or
                pass an existing TimeSeries ID (``str`` or ``int``) to reuse it.
                For FILE properties pass a :class:`FileUpload` instance to upload
                automatically, or an existing file ID (``int``) to reuse.
            namespace_name: Optional namespace
            max_items_per_request: Maximum items per mutation request. Items
                are split into sequential batches when this limit is exceeded.
                Defaults to 20,000 (server default limit).

        Returns:
            QueryResult of created items, each containing only ``_id``,
            ``_rowVersion``, and ``_existed``.  Keys are accessible
            case-insensitively (e.g. ``item["_rowversion"]``).

        Raises:
            ValueError: If a TIME_SERIES property value is not ``None``,
                ``str``, or ``int``.

        Example:
            ```python
            # Auto-create time series (None → new TimeSeries ID written back in-place)
            items = [
                {"name": "Sensor A", "temperature": None},
                {"name": "Sensor B", "temperature": None},
            ]
            created = client.create_items("Sensors", items)

            # Merge IDs with original data if the full representation is needed
            for original, result in zip(items, created):
                original["_id"] = result["_id"]
                original["_rowVersion"] = result["_rowVersion"]

            # FILE property: FileUpload handles upload automatically
            created = client.create_items(
                "MyInventory",
                [{"name": "Doc A", "Document": FileUpload("/path/to/file.pdf")}],
                namespace_name="MyNamespace",
            )
            # Reuse existing file by ID
            created = client.create_items(
                "MyInventory",
                [{"name": "Doc A", "Document": 42}],
                namespace_name="MyNamespace",
            )
            ```
        """
        logger.info(
            f"Creating inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, item_count={len(items)}"
        )

        schema = self._registry.get(inventory_name, namespace_name)
        if schema.file_field_names:
            self._auto_upload_files(items, schema, inventory_name, namespace_name)
        if schema.timeseries_field_names:
            self._auto_create_timeseries(
                items, schema, inventory_name, namespace_name, max_ids_per_request
            )

        result = self._execute_mutation_chunked(
            operation=lambda inv, itms, ns: self._client.inventory.create(
                inventory_name=inv,
                namespace_name=ns,
                items=itms,
            ),
            inventory_name=inventory_name,
            items=items,
            namespace_name=namespace_name,
            max_items_per_request=max_items_per_request,
        )
        logger.info(f"Created {len(result)} items in {inventory_name}")
        return QueryResult(result)

    def update_items(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
        max_items_per_request: int = 20_000,
    ) -> QueryResult[dict[str, Any]]:
        """Update one or more existing items in the given inventory.

        System keys (``_id``, ``_rowVersion``) are accepted in any casing
        and normalised automatically, so ``_Id``/``_RowVersion`` work as well.

        Args:
            inventory_name: Name of inventory
            items: List of items with ``_id`` and ``_rowVersion``
                (any casing accepted).  For TIME_SERIES properties pass
                ``None`` to remove the TimeSeries reference from the item
                (the TimeSeries object itself is not deleted, only the link),
                or a TimeSeries ID (``str`` or ``int``) to point to a different
                TimeSeries.  For FILE properties pass a :class:`FileUpload`
                instance to upload automatically, or an existing file ID
                (``int``) to reuse.
            namespace_name: Optional namespace
            max_items_per_request: Maximum items per mutation request. Items
                are split into sequential batches when this limit is exceeded.
                Defaults to 20,000 (server default limit).

        Note:
            The behaviour of ``None`` for TIME_SERIES properties differs
            between :meth:`create_items` and :meth:`update_items`:

            - :meth:`create_items` – ``None`` **auto-creates** a new TimeSeries
              object and stores its ID on the item.
            - :meth:`update_items` – ``None`` **removes** the existing TimeSeries
              reference from the item (sets the field to ``null``).

        Returns:
            QueryResult of updated items, each containing only ``_id``,
            ``_rowVersion``, and ``_existed``.  Keys are accessible
            case-insensitively.

        Example:
            ```python
            # Update a scalar property
            client.update_items(
                "MyInventory",
                [{"_id": 1, "_rowVersion": 1, "name": "New Name"}],
            )

            # TIME_SERIES property: remove the TimeSeries reference from an item
            client.update_items(
                "MyInventory",
                [{"_id": 1, "_rowVersion": 1, "measurement": None}],
            )

            # TIME_SERIES property: reassign to an existing TimeSeries
            client.update_items(
                "MyInventory",
                [{"_id": 1, "_rowVersion": 1, "measurement": 9876543210}],
            )

            # FILE property: upload a new file automatically
            client.update_items(
                "MyInventory",
                [
                    {
                        "_id": 1,
                        "_rowVersion": 1,
                        "Document": FileUpload("/path/to/new.pdf"),
                    }
                ],
            )

            # FILE property: reuse an already-uploaded file by ID
            client.update_items(
                "MyInventory",
                [{"_id": 1, "_rowVersion": 1, "Document": 42}],
            )
            ```
        """
        logger.info(
            f"Updating inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, item_count={len(items)}"
        )

        schema = self._registry.get(inventory_name, namespace_name)
        if schema.file_field_names:
            self._auto_upload_files(items, schema, inventory_name, namespace_name)

        result = self._execute_mutation_chunked(
            operation=lambda inv, itms, ns: self._client.inventory.update(
                inventory_name=inv,
                namespace_name=ns,
                items=itms,
            ),
            inventory_name=inventory_name,
            items=items,
            namespace_name=namespace_name,
            max_items_per_request=max_items_per_request,
        )
        logger.info(f"Updated {len(result)} items in {inventory_name}")
        return QueryResult(result)

    def delete_items(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
        max_items_per_request: int = 20_000,
    ) -> QueryResult[dict[str, Any]]:
        """Delete one or more items from the given inventory.

        Args:
            inventory_name: Name of inventory
            items: List of dicts, each with ``_id`` and ``_rowVersion``.
                Key casing is normalized (case-insensitive).
                Items returned by :meth:`list_items` can be passed directly.
            namespace_name: Optional namespace
            max_items_per_request: Maximum items per mutation request. Items
                are split into sequential batches when this limit is exceeded.
                Defaults to 20,000 (server default limit).

        Returns:
            QueryResult of deleted items, each containing only ``_id``,
            ``_rowVersion``, and ``_existed``.

        Raises:
            ValueError: If ``_id`` or ``_rowVersion`` is missing from any item.

        Example:
            ```python
            # Delete items returned directly from list_items()
            items = client.list_items("Sensors", where={"status": {"eq": "inactive"}})
            client.delete_items("Sensors", list(items))

            # Delete a specific item by ID and rowVersion
            client.delete_items(
                "Sensors",
                [{"_id": 42, "_rowVersion": 3}],
            )

            # Extra properties are stripped automatically — passing full item dicts is safe
            full_items = client.list_items(
                "Sensors", properties=["_id", "_rowVersion", "name"]
            )
            client.delete_items("Sensors", list(full_items))
            ```
        """
        logger.info(
            f"Deleting inventory items. inventory_name={inventory_name}, "
            f"namespace_name={namespace_name}, item_count={len(items)}"
        )

        # DeleteInputType only accepts _id and _rowVersion; strip all other fields.
        # Key lookup is case-insensitive so items from list_items() work directly.
        delete_inputs: list[dict[str, Any]] = []
        for item in items:
            entry: dict[str, Any] = {}
            for key, value in item.items():
                lower = key.lower()
                if lower == "_id":
                    entry["_id"] = value
                elif lower == "_rowversion":
                    entry["_rowVersion"] = value
            delete_inputs.append(entry)

        result = self._execute_mutation_chunked(
            operation=lambda inv, itms, ns: self._client.inventory.delete(
                inventory_name=inv,
                namespace_name=ns,
                items=itms,
            ),
            inventory_name=inventory_name,
            items=delete_inputs,
            namespace_name=namespace_name,
            max_items_per_request=max_items_per_request,
        )

        logger.info(f"Deleted {len(result)} items from {inventory_name}")
        return QueryResult(result)

    def create_namespace(
        self,
        name: str,
        description: str | None = None,
        if_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Create a namespace to logically group inventories and items.

        Args:
            name: Namespace name
            description: Optional description
            if_exists: Action if namespace already exists

        Returns:
            NamedItemResult indicating creation status
        """
        logger.info(f"Creating namespace. name={name}")

        result = self._client.mutations.create_namespace(
            namespace_name=name,
            description=description,
            if_exists=if_exists,
        )

        logger.info(f"Namespace created: {name}, existed={result.existed}")
        return result

    def delete_namespace(
        self,
        name: str,
        if_not_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Delete a namespace.

        Args:
            name: Namespace name
            if_not_exists: Action if namespace doesn't exist

        Returns:
            NamedItemResult indicating deletion status
        """
        logger.info(f"Deleting namespace. name={name}")

        result = self._client.mutations.drop_namespace(
            namespace_name=name,
            if_not_exists=if_not_exists,
        )

        logger.info(f"Namespace deleted: {name}, existed={result.existed}")
        return result

    def create_inventory(
        self,
        name: str,
        properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ],
        namespace_name: str | None = None,
        description: str | None = None,
        enable_audit: bool = False,
        relations: list[InventoryRelation] | None = None,
        if_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Create a new inventory with the given properties and optional configuration.

        Args:
            name: Inventory name
            properties: List of inventory properties
            namespace_name: Optional namespace
            description: Optional description
            enable_audit: Enable audit logging
            relations: Optional inventory relations
            if_exists: Action if inventory already exists

        Returns:
            NamedItemResult indicating creation status
        """
        logger.info(f"Creating inventory. name={name}, namespace_name={namespace_name}")

        normalized_properties = self._normalize_properties(properties)

        result = self._client.mutations.create_inventory(
            inventory_name=name,
            properties=normalized_properties,
            namespace_name=namespace_name,
            description=description,
            enable_audit=enable_audit,
            relations=relations,
            if_exists=if_exists,
        )

        logger.info(f"Inventory created: {name}, existed={result.existed}")
        return result

    def update_inventory(
        self,
        inventory_name: str,
        namespace_name: str | None = None,
        add_properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ]
        | None = None,
        alter_properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ]
        | None = None,
        drop_properties: list[str] | None = None,
        add_relations: list[InventoryRelation] | None = None,
        drop_relations: list[str] | None = None,
        alter_relations: list[InventoryRelation] | None = None,
        new_inventory_name: str | None = None,
        description: str | None = None,
        enable_audit: bool | None = None,
        if_not_exists: ConflictAction = ConflictAction.RAISE_ERROR,
    ) -> BackgroundJobResult:
        """Alter the schema of an existing inventory (add, modify, or drop properties and relations).

        Changes are applied asynchronously — the returned job ID can be used to track
        completion.

        Args:
            inventory_name: Name of the inventory to alter
            namespace_name: Optional namespace
            add_properties: Properties to add
            alter_properties: Properties to alter
            drop_properties: Property names to drop
            add_relations: Relations to add
            drop_relations: Relation names to drop
            alter_relations: Relations to alter
            new_inventory_name: Rename inventory to this name
            description: New description
            enable_audit: Enable or disable audit
            if_not_exists: Behavior when inventory does not exist

        Returns:
            BackgroundJobResult with the background job ID
        """
        logger.info(
            f"Updating inventory. inventory_name={inventory_name}, namespace_name={namespace_name}"
        )

        normalized_add = (
            self._normalize_properties(add_properties) if add_properties else None
        )
        normalized_alter = (
            self._normalize_properties(alter_properties) if alter_properties else None
        )

        result = self._client.mutations.start_alter_inventory(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            add_properties=normalized_add,
            alter_properties=normalized_alter,
            drop_properties=drop_properties,
            add_relations=add_relations,
            drop_relations=drop_relations,
            alter_relations=alter_relations,
            new_inventory_name=new_inventory_name,
            description=description,
            enable_audit=enable_audit,
            if_not_exists=if_not_exists,
        )

        logger.info(
            f"Inventory update job started. inventory_name={inventory_name}, background_job_id={result.background_job_id}"
        )
        return result

    def delete_inventory(
        self,
        inventory_name: str,
        namespace_name: str | None = None,
        if_not_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Delete an inventory.

        Args:
            inventory_name: Name of inventory to delete
            namespace_name: Optional namespace
            if_not_exists: Action if inventory doesn't exist

        Returns:
            NamedItemResult indicating deletion status
        """
        logger.info(
            f"Deleting inventory. inventory_name={inventory_name}, namespace_name={namespace_name}"
        )

        result = self._client.mutations.delete_inventory(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            if_not_exists=if_not_exists,
        )

        logger.info(f"Inventory deleted: {inventory_name}, existed={result.existed}")
        return result

    def get_version(self) -> ServiceVersion:
        """Return the version of the connected Questra Data service."""
        return self._catalog_manager.get_version()

    def get_system_info(self) -> SystemInfo:
        """Return version and configuration details of the connected Questra Data service."""
        return self._catalog_manager.get_system_info()

    def list_namespaces(self) -> QueryResult[Namespace]:
        """Return all namespaces defined in the Questra Data service."""
        namespaces = self._catalog_manager.list_namespaces()
        return QueryResult(namespaces)

    def list_roles(self) -> QueryResult[Role]:
        """Return all roles available for managing inventory access permissions."""
        roles = self._catalog_manager.list_roles()
        return QueryResult(roles)

    def list_units(self) -> QueryResult[Unit]:
        """Return all measurement units available for annotating time series values."""
        units = self._catalog_manager.list_units()
        return QueryResult(units)

    def list_time_zones(self) -> QueryResult[TimeZone]:
        """Return all time zones supported by the service for use in time series operations."""
        time_zones = self._catalog_manager.list_time_zones()
        return QueryResult(time_zones)

    def list_inventories(
        self,
        namespace_name: str | None = None,
        inventory_names: list[str] | None = None,
    ) -> QueryResult[Inventory]:
        """List inventories, optionally filtered by namespace or name.

        Args:
            namespace_name: Optional namespace filter
            inventory_names: Optional inventory name filter

        Returns:
            QueryResult containing inventories
        """
        logger.info(f"Listing inventories. namespace_name={namespace_name}")

        where = {}
        if namespace_name:
            where["namespaceNames"] = [namespace_name]
        if inventory_names:
            where["inventoryNames"] = inventory_names

        inventories = self._client.queries.get_inventories(
            where=where if where else None
        )
        return QueryResult(inventories)

    # ===== Direct Access to raw client =====

    @property
    def raw(self) -> _QuestraDataCore:
        """Exposes the full low-level API surface for advanced use cases not covered by the `QuestraData` methods."""
        return self._client

    def is_authenticated(self) -> bool:
        """Return whether the underlying authentication client currently holds a valid token."""
        return self._client.is_authenticated()

    def __repr__(self) -> str:
        auth_status = (
            "authenticated" if self.is_authenticated() else "not authenticated"
        )
        return f"QuestraData(url='{self._client.graphql_url}', status='{auth_status}')"
