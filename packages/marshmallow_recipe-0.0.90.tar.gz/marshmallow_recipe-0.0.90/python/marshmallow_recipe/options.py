import collections.abc
import dataclasses
import enum

from .missing import MISSING
from .naming_case import NamingCase
from .utils import validate_decimal_places

_OPTIONS_KEY = "__marshmallow_recipe_options__"


class NoneValueHandling(enum.StrEnum):
    IGNORE = enum.auto()
    INCLUDE = enum.auto()


@dataclasses.dataclass(kw_only=True, slots=True, frozen=True)
class DataclassOptions:
    none_value_handling: NoneValueHandling | None = None
    naming_case: NamingCase | None = None
    decimal_places: int | None = MISSING
    title: str | None = None
    description: str | None = None


def options[T](
    *,
    none_value_handling: NoneValueHandling | None = None,
    naming_case: NamingCase | None = None,
    decimal_places: int | None = MISSING,
    title: str | None = None,
    description: str | None = None,
) -> collections.abc.Callable[[type[T]], type[T]]:
    validate_decimal_places(decimal_places)

    def wrap(cls: type[T]) -> type[T]:
        setattr(
            cls,
            _OPTIONS_KEY,
            DataclassOptions(
                none_value_handling=none_value_handling,
                naming_case=naming_case,
                decimal_places=decimal_places,
                title=title,
                description=description,
            ),
        )
        return cls

    return wrap


def try_get_options_for(type: type) -> DataclassOptions | None:
    return getattr(type, _OPTIONS_KEY, None)
