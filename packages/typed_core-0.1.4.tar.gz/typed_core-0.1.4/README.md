# Typed Core

> Shared core types and utilities for Typed Clients