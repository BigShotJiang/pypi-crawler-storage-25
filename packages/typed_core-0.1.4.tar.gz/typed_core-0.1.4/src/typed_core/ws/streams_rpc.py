from typing_extensions import Literal, TypedDict, AsyncIterable, TypeVar, Generic, Any
from abc import abstractmethod
from dataclasses import dataclass, field
import asyncio

from typed_core.util import Stream
from .socket import Socket

Request = TypeVar('Request', default=Any)
Reply = TypeVar('Reply', default=Any)
Notification = TypeVar('Notification', default=Any)
SubscriptionParams = TypeVar('SubscriptionParams', default=Any)
SubscriptionReply = TypeVar('SubscriptionReply', default=Any)
UnsubscriptionReply = TypeVar('UnsubscriptionReply', default=Any)

class Response(TypedDict, Generic[Reply]):
  kind: Literal['response']
  id: int
  response: Reply

class Subscription(TypedDict, Generic[Notification]):
  kind: Literal['subscription']
  channel: str
  notification: Notification

Message = Response[Reply] | Subscription[Notification]

@dataclass
class StreamsRpc(Socket, Generic[Request, Reply, Notification, SubscriptionParams, SubscriptionReply, UnsubscriptionReply]):
  """Multiplexed request/response and streams socket client, via message and channel IDs.
  
  Features:
  - Internal ID management
  - `rpc_request` for RPC request/response agnostic to IDs
  - `subscribe` for subscribing to a channel. Returns a stream with a handle to unsubscribe.

  #### Note: each channel can be subscribed to only once.

  Requires implementing:
  - `rpc_send` to send an identified request to the server
  - `request_subscription` to request a subscription to a channel
  - `request_unsubscription` to request an unsubscription from a channel
  - `parse_msg` to parse a message into a response/subscription
  """
  replies: dict[int, asyncio.Future[Reply]] = field(default_factory=dict, init=False, repr=False)
  counter: int = field(default=0, init=False, repr=False)
  subscriptions: dict[str, asyncio.Queue[Notification]] = field(default_factory=dict, init=False, repr=False)

  @abstractmethod
  async def rpc_send(self, id: int, req: Request, /):
    ...

  @abstractmethod
  async def request_subscription(self, channel: str, params: SubscriptionParams | None = None) -> SubscriptionReply:
    ...

  @abstractmethod
  async def request_unsubscription(self, channel: str, params: SubscriptionParams | None = None) -> UnsubscriptionReply:
    ...

  @abstractmethod
  def parse_msg(self, msg: str | bytes, /) -> Message[Reply, Notification] | None:
    ...

  async def rpc_request(self, request: Request) -> Reply:
    id = self.counter
    self.counter += 1
    self.replies[id] = asyncio.Future()
    await self.rpc_send(id, request)
    response = await self.wait(self.replies[id])
    del self.replies[id]
    return response
    
  def on_msg(self, msg: str | bytes):
    res = self.parse_msg(msg)
    if res is None:
      return
    elif res['kind'] == 'response':
      self.replies[res['id']].set_result(res['response'])
    elif res['kind'] == 'subscription':
      if (q := self.subscriptions.get(res['channel'])) is not None:
        q.put_nowait(res['notification'])
    else:
      raise ValueError(f'Invalid message: {res}')

  async def subscribe(self, channel: str, params: SubscriptionParams | None = None) -> Stream[Notification, SubscriptionReply, UnsubscriptionReply]:
    if channel in self.subscriptions:
      raise ValueError(f'Channel {channel} already subscribed')

    self.subscriptions[channel] = queue = asyncio.Queue()
    reply = await self.request_subscription(channel, params)

    unsubscribed = asyncio.Future()

    async def stream() -> AsyncIterable[Notification]:
      while True:
        done, _ = await self.wait(
          asyncio.wait([unsubscribed, asyncio.create_task(queue.get())], return_when='FIRST_COMPLETED')
        )
        if unsubscribed in done:
          break
        else:
          yield await next(iter(done))

    async def unsubscribe() -> UnsubscriptionReply :
      del self.subscriptions[channel]
      return await self.request_unsubscription(channel, params)

    return Stream(reply, stream(), unsubscribe)