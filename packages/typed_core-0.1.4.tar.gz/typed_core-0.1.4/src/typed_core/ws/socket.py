from typing_extensions import Awaitable, TypeVar
from abc import ABC, abstractmethod
import asyncio
from dataclasses import dataclass, field
from datetime import timedelta
import logging
import websockets

from typed_core.exceptions import NetworkError

T = TypeVar('T')

logger = logging.getLogger(__name__)

@dataclass
class Context:
  ws: websockets.ClientConnection
  listener: asyncio.Task
  pinger: asyncio.Task

@dataclass
class Socket(ABC):
  """Base WebSocket client.
  
  Features:
  - Connection handling
  - Optional periodic pinging
  - Message listener
  - Error propagation via `.wait(...)`

  Requires implementing:
  - `on_msg`: handle incoming messages.
  - `ping`: if you the server requires some custom pinging mechanism

  ### Error Propagation

  The websocket connection could fail without you knowing.
  To avoid that happening, you can ensure they are propagated by using `.wait(...)`.

  **Example**:

  ```python
  future = asyncio.Future()

  class MySocket(Socket):
    def on_msg(self, msg: str | bytes):
      future.set_result(msg)

  async with MySocket('wss://example.com') as ws:
    result = await ws.wait(future)
  ```

  If you awaited directly and an exception happened, you would wait forever.
  
  This way, if an error happens, a `NetworkError` will be raised.
  """
  url: str
  timeout: timedelta = field(kw_only=True, default=timedelta(seconds=10))
  ping_interval: timedelta = field(kw_only=True, default=timedelta(hours=24))
  ctx_future: asyncio.Future[Context] = field(default_factory=asyncio.Future, init=False)
  open_lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)
  close_lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)

  @abstractmethod
  def on_msg(self, msg: str | bytes):
    ...

  async def ping(self):
    """Ping the server.
    
    If implemented, this is called periodically by the pinger task.
    """
    raise NotImplementedError

  async def pinger(self):
    while True:
      await asyncio.sleep(self.ping_interval.total_seconds())
      try:
        await self.ping()
      except NotImplementedError:
        ...

  @property
  async def ctx(self) -> Context:
    return await self.open()
  
  @property
  async def ws(self) -> websockets.ClientConnection:
    return (await self.ctx).ws
  
  async def __aenter__(self):
    await self.open()
    return self
  
  async def __aexit__(self, exc_type, exc_value, traceback):
    await self.close(await self.ctx, exc_type, exc_value, traceback)
  
  async def force_open(self):
    async def connect():
      try:
        return await websockets.connect(self.url, open_timeout=self.timeout.total_seconds())
      except websockets.exceptions.WebSocketException as e:
        raise NetworkError(f'Failed to connect to {self.url}') from e
      
    ws = await connect()
    logger.info('Connected!')
    return Context(
      ws=ws,
      listener=asyncio.create_task(self.listener()),
      pinger=asyncio.create_task(self.pinger()),
    )
  
  async def open(self):
    if self.open_lock.locked() or self.ctx_future.done():
      ctx = await self.ctx_future
      if ctx.ws.state == websockets.State.CLOSED:
        await self.close(ctx)
        return await self.open()

    async with self.open_lock:
      logger.info('Connecting...')
      ctx = await self.force_open()
      self.ctx_future.set_result(ctx)
      return ctx

  async def force_close(self, ctx: Context, exc_type=None, exc_value=None, traceback=None):
    ctx.listener.cancel()
    ctx.pinger.cancel()
    await ctx.ws.__aexit__(exc_type, exc_value, traceback)

  async def close(self, ctx: Context, exc_type=None, exc_value=None, traceback=None):
    if not self.close_lock.locked():
      async with self.close_lock:
        await self.force_close(ctx, exc_type, exc_value, traceback)
        del self.ctx_future
        self.ctx_future = asyncio.Future()

  async def listener(self):
    ws = await self.ws
    while True:
      try:
        msg = await ws.recv()
        logger.debug('Received: %s', msg)
        self.on_msg(msg)
      except websockets.exceptions.WebSocketException as e:
        logger.error('Error receiving message: %s', e)
        raise NetworkError('Error receiving message') from e

  async def wait(self, fut: Awaitable[T]) -> T:
    """Wait for a future to complete, propagating any exceptions in the background tasks."""
    async def coro():
      return await fut
    task = asyncio.create_task(coro())
    ctx = await self.ctx
    done, _ = await asyncio.wait([task, ctx.listener, ctx.pinger], return_when='FIRST_COMPLETED')
    if ctx.listener in done:
      if (exc := ctx.listener.exception()) is not None:
        raise exc
      else:
        raise asyncio.CancelledError('Listener task got cancelled')
    elif ctx.pinger in done:
      if (exc := ctx.pinger.exception()) is not None:
        raise exc
      else:
        raise asyncio.CancelledError('Pinger task got cancelled')
    return task.result()
