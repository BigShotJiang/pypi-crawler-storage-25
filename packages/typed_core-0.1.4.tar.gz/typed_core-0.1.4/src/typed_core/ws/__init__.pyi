"""WebSocket base classes for various kinds of communication protocols.

- `Socket`: minimal client, handling connection, pinging, and listening.
- `SerialRpc`: serial request/response client.
- `Rpc`: multiplexed request/response client, via message IDs.
- `Streams`: multiplex subscribe/stream client (supports multiple concurrent subscriptions).
- `StreamsRpc`: multiplexed request/response and streams socket client, via message and channel IDs.
"""
from .socket import Socket
from .rpc import Rpc
from .streams import Streams
from .streams_rpc import StreamsRpc

__all__ = [
  'Socket',
  'Rpc',
  'Streams',
  'StreamsRpc',
]