from typing_extensions import TypedDict, AsyncIterable, TypeVar, Generic, Any
from abc import abstractmethod
from dataclasses import dataclass, field
import asyncio

from typed_core.util import Stream
from .socket import Socket

Notification = TypeVar('Notification', default=Any)
SubscriptionParams = TypeVar('SubscriptionParams', default=Any)
SubscriptionReply = TypeVar('SubscriptionReply', default=Any)
UnsubscriptionReply = TypeVar('UnsubscriptionReply', default=Any)

class Subscription(TypedDict, Generic[Notification]):
  channel: str
  notification: Notification

@dataclass
class Streams(Socket, Generic[Notification, SubscriptionParams, SubscriptionReply, UnsubscriptionReply]):
  """Multiplex subscribe/stream client (supports multiple concurrent subscriptions).
  
  Features:
  - Subscriptions management
  - `subscribe` to subscribe to a channel. Returns a stream with a handle to unsubscribe.

  Requires implementing:
  - `request_subscription` to request a subscription to a channel
  - `request_unsubscription` to request an unsubscription from a channel
  - `parse_msg` to parse a message into a subscription
  """
  subscriptions: dict[str, asyncio.Queue[Notification]] = field(default_factory=dict, init=False, repr=False)

  @abstractmethod
  async def request_subscription(self, channel: str, params: SubscriptionParams | None = None) -> SubscriptionReply:
    ...

  @abstractmethod
  async def request_unsubscription(self, channel: str, params: SubscriptionParams | None = None) -> UnsubscriptionReply:
    ...

  @abstractmethod
  def parse_msg(self, msg: str | bytes) -> Subscription[Notification] | None:
    ...

  async def __aexit__(self, exc_type, exc_value, traceback):
    await super().__aexit__(exc_type, exc_value, traceback)
    self.subscriptions.clear()

  def on_msg(self, msg: str | bytes):
    res = self.parse_msg(msg)
    if res is not None:
      if (q := self.subscriptions.get(res['channel'])) is not None:
        q.put_nowait(res['notification'])

  async def subscribe(self, channel: str, params: SubscriptionParams | None = None) -> Stream[Notification, SubscriptionReply, UnsubscriptionReply]:
    if channel in self.subscriptions:
      raise ValueError(f'Channel {channel} already subscribed')

    self.subscriptions[channel] = queue = asyncio.Queue()
    reply = await self.wait(self.request_subscription(channel, params))

    unsubscribed = asyncio.Future()

    async def stream() -> AsyncIterable[Notification]:
      while True:
        done, _ = await self.wait(
          asyncio.wait([unsubscribed, asyncio.create_task(queue.get())], return_when='FIRST_COMPLETED')
        )
        if unsubscribed in done:
          break
        else:
          yield await next(iter(done))

    async def unsubscribe() -> UnsubscriptionReply :
      del self.subscriptions[channel]
      unsubscribed.set_result(None)
      return await self.wait(self.request_unsubscription(channel, params))

    return Stream(reply, stream(), unsubscribe)