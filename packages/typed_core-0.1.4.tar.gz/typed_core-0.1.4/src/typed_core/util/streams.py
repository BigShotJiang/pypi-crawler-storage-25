from typing_extensions import AsyncIterable, Generic, Awaitable, Callable, TypeVar, Any
from dataclasses import dataclass, field, replace

T = TypeVar('T', default=Any)
Notification = TypeVar('Notification', default=Any)
SubscriptionReply = TypeVar('SubscriptionReply', default=Any)
UnsubscriptionReply = TypeVar('UnsubscriptionReply', default=Any)

@dataclass
class Stream(AsyncIterable[Notification], Generic[Notification, SubscriptionReply, UnsubscriptionReply]):
  """Represents a subscription to a stream.
  
  Usage:

  ```python
  print(stream.reply)
  async for msg in stream:
    ...
  await stream.unsubscribe()
  ```
  """
  reply: SubscriptionReply
  stream: AsyncIterable[Notification]
  unsubscribe: Callable[[], Awaitable[UnsubscriptionReply]]

  def __aiter__(self):
    return self.stream.__aiter__()

  def map(self, f: Callable[[Notification], T]) -> 'Stream[T, SubscriptionReply, UnsubscriptionReply]':
    async def stream() -> AsyncIterable[T]:
      async for msg in self.stream:
        yield f(msg)
    return replace(self, stream=stream()) # type: ignore

  def filter(self, f: Callable[[Notification], bool]) -> 'Stream[Notification, SubscriptionReply, UnsubscriptionReply]':
    async def stream() -> AsyncIterable[Notification]:
      async for msg in self.stream:
        if f(msg):
          yield msg
    return replace(self, stream=stream())

