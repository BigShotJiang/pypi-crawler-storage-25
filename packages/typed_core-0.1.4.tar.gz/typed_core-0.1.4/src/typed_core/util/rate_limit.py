from dataclasses import dataclass, field
import asyncio
import time
from collections import deque

@dataclass
class RateLimit:
  """Rate limit to `max_calls` per `period`
  
  Usage:

  ```
  limiter = RateLimit(5) # 5 calls/second
  for i in range(50):
    async with limiter:
      ... # do stuff, at most 5 times/second
  """
  max_calls: int
  period: float = field(kw_only=True, default=1)
  times: deque[float] = field(default_factory=deque, init=False)
  lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)

  async def acquire(self) -> None:
    async with self.lock:
      now = time.monotonic()
      # Drop expired timestamps
      while self.times and self.times[0] <= now - self.period:
        self.times.popleft()
      if len(self.times) >= self.max_calls:
        wait = self.period - (now - self.times[0])
        await asyncio.sleep(wait)
        now = time.monotonic()
        while self.times and self.times[0] <= now - self.period:
          self.times.popleft()
      self.times.append(now)
  
  async def __aenter__(self):
    await self.acquire()
    return self

  async def __aexit__(self, exc_type, exc_val, exc_tb):
    ...