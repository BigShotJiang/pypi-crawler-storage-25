"""Tests for Difflicious."""
