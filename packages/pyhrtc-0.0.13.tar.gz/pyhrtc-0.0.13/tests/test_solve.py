"""Test cases for solving SMTI instances."""

from pyhrtc.fileio import read_hrtc
from pyhrtc.models import MAX_SMTI_IP, MAX_HRTC_IP
from pyhrtc.basics import Agent, Couple, Instance


def test_solve():
    """Solve simple instance"""
    instance = read_hrtc("tests/testfiles/smti-simple.instance")
    model = MAX_SMTI_IP(instance)
    matching = model.solve()
    assert len(matching) == 3
    instance = read_hrtc("tests/testfiles/smti-nocomplete.instance")
    model = MAX_SMTI_IP(instance)
    matching = model.solve()
    assert len(matching) == 2


def test_dummy_variables_simple():
    """Solve simple instance using dummy variables"""
    instance = read_hrtc("tests/testfiles/smti-simple.instance")
    model = MAX_SMTI_IP(instance)
    model.dummy_variables = True
    matching = model.solve()
    assert len(matching) == 3


def test_grp_solve():
    """Solve GRP instances"""
    instance = read_hrtc("tests/testfiles/smti-grp-simple.instance")
    model = MAX_SMTI_IP(instance)
    matching = model.solve()
    assert len(matching) == 3
    instance = read_hrtc("tests/testfiles/smti-grp-simple.instance")
    model = MAX_SMTI_IP(instance)
    model.dummy_variables = True
    matching = model.solve()
    assert len(matching) == 3


def test_grp_thresholds():
    """Solve GRP instances with thresholding"""
    instance = read_hrtc("tests/testfiles/smti-grp-thresholds.instance")
    model = MAX_SMTI_IP(instance)
    matching = model.solve()
    assert len(matching) == 3
    instance = read_hrtc("tests/testfiles/smti-grp-thresholds.instance")
    instance.threshold(80)
    model = MAX_SMTI_IP(instance)
    matching = model.solve()
    assert len(matching) == 2
    instance = read_hrtc("tests/testfiles/smti-grp-thresholds.instance")
    instance.threshold(80)
    model = MAX_SMTI_IP(instance)
    model.weighted = True
    matching = model.solve()
    assert len(matching) == 2


def test_grp_solve_weighted():
    """Solve GRP instances"""
    instance = read_hrtc("tests/testfiles/smti-grp-diff-maxweight.instance")
    model = MAX_SMTI_IP(instance)
    matching = model.solve()
    assert len(matching) == 4
    instance = read_hrtc("tests/testfiles/smti-grp-diff-maxweight.instance")
    instance.threshold(5)
    model = MAX_SMTI_IP(instance)
    model.weighted = True
    matching = model.solve()
    assert len(matching) == 3


def test_hrtc_simple():
    def mk_agent(ident, prefs, capacity=1):
        a = Agent(ident, capacity=capacity)
        a.preferences = prefs
        return a

    left = [
        mk_agent("A", [["h2"], ["h1"]]),
        mk_agent("B", [["h1"], ["h2"]]),
    ]
    right = [
        mk_agent("h1", [["A"], ["B"]], capacity=2),
        mk_agent("h2", [["B"], ["A"]], capacity=2),
    ]
    i = Instance()
    for l in left:
        i.add_agent_left(l)
    for r in right:
        i.add_agent_right(r)
    model = MAX_HRTC_IP(i)
    match = model.solve()
    assert match["A"] == "h2"
    assert match["B"] == "h1"


def test_hrtc_simple_stability():
    def mk_agent(ident, prefs, capacity=1):
        a = Agent(ident, capacity=capacity)
        a.preferences = prefs
        return a

    left = [
        mk_agent("A", [["h1"]]),
        mk_agent("B", [["h1"]]),
    ]
    right = [
        mk_agent("h1", [["A"], ["B"]], capacity=1),
    ]
    i = Instance()
    for l in left:
        i.add_agent_left(l)
    for r in right:
        i.add_agent_right(r)
    model = MAX_HRTC_IP(i)
    match = model.solve()
    assert match["A"] == "h1"
    assert "B" not in match


def test_hrtc_solve_splittable():
    def mk_agent(ident, prefs, capacity=1):
        a = Agent(ident, capacity=capacity)
        a.preferences = prefs
        return a

    def mk_pair(ident_a, ident_b, prefs):
        a = Agent(ident_a)
        b = Agent(ident_b)
        c = Couple(a, b)
        c.preferences = prefs
        return c

    left = [
        mk_pair("A", "a", [["h1,h1"], ["h1,N"], ["N,h1"]]),
        mk_agent("B", [["h1"]]),
    ]
    right = [
        mk_agent("h1", [["A"], ["a"], ["B"]], capacity=2),
        mk_agent(
            "N",
            [
                [
                    "A",
                    "a",
                ]
            ],
            capacity=3,
        ),
    ]
    i = Instance()
    for l in left:
        i.add_agent_left(l)
    for r in right:
        i.add_agent_right(r)
    model = MAX_HRTC_IP(i, right_weights={"N": 0})
    match = model.solve()
    print(match)
    assert match["A"] == "h1"
    assert match["a"] == "h1"
    assert "B" not in match


def test_hrtc_solve_unsplittable():
    def mk_agent(ident, prefs, capacity=1):
        a = Agent(ident, capacity=capacity)
        a.preferences = prefs
        return a

    def mk_pair(ident_a, ident_b, prefs):
        a = Agent(ident_a)
        b = Agent(ident_b)
        c = Couple(a, b)
        c.preferences = prefs
        return c

    left = [
        mk_pair("A", "a", [["h1,h1"]]),
        mk_agent("B", [["h1"]]),
    ]
    right = [
        mk_agent("h1", [["A", "B"], ["a"]], capacity=2),
    ]
    i = Instance()
    for l in left:
        i.add_agent_left(l)
    for r in right:
        i.add_agent_right(r)
    model = MAX_HRTC_IP(i, right_weights={"N": 0})
    match = model.solve()
    print(match)
    assert match["B"] == "h1"
    assert "A" not in match
    assert "a" not in match


def test_hrtc_solve_extra_prefs():
    def mk_agent(ident, prefs, capacity=1):
        a = Agent(ident, capacity=capacity)
        a.preferences = prefs
        return a

    def mk_pair(ident_a, ident_b, prefs):
        a = Agent(ident_a)
        b = Agent(ident_b)
        c = Couple(a, b)
        c.preferences = prefs
        return c

    left = [
        mk_pair("A", "a", [["h1,h1"]]),
        mk_agent("B", [["h1"]]),
    ]
    right = [
        mk_agent("h1", [["A", "B"], ["a"]], capacity=2),
        mk_agent("N", [["A", "B"], ["a"]], capacity=1),
    ]
    i = Instance()
    for l in left:
        i.add_agent_left(l)
    for r in right:
        i.add_agent_right(r)
    model = MAX_HRTC_IP(i, right_weights={"N": 0})
    match = model.solve()
    print(match)
    assert match["B"] == "h1"
    assert "A" not in match
    assert "a" not in match
