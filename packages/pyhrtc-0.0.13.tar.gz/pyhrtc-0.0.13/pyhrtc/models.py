"""Various IP models for HRTC and variants."""

from collections import defaultdict

from pulp import LpProblem, LpMaximize, LpVariable, lpSum, LpStatusOptimal, HiGHS, LpSolver  # type: ignore

from pyhrtc.basics import Instance, Agent
from pyhrtc.weightedinstance import WeightedInstance


class MAX_SMTI_IP(LpProblem):
    """An IP model to find a maximum cardinality stable matching."""

    def __init__(self, instance, name=None):
        if instance.number_of_couples_left() != 0:
            raise Exception("This model does not support couples")
        if name is None:
            name = "SMTI"
        super().__init__(name, LpMaximize)
        self._instance = instance
        self._built = False
        self._cardinality_restriction = None

        """Map from each variable name (as a string) to the actual variable object.
        _variables_lr is a map such that _variables_lr[left][right] gives the
        variable where Agent left is assigned to Agent right
        _variables_rl is a map such that _variables_rl[right][left] gives the
        variable where Agent right is assigned to Agent left
        """
        self._variables_lr = None
        self._variables_rl = None

        self._use_dummy = False
        """Maps the y variables, the dummy binary variables from Chapter 5 of paper.
        """
        self._variables_yl = None
        self._variables_yr = None

        """Should we find a maximum weight matching, or maximum size?"""
        self._weighted = False

    @property
    def dummy_variables(self):
        """Are dummy variables used in this model."""
        return self._use_dummy

    @dummy_variables.setter
    def dummy_variables(self, choice):
        """Enable (or disable) the use of dummy variables. Note that this only
        makes sense before building or solving.
        """
        if self._built:
            raise Exception("Cannot modify model after it is built")
        self._use_dummy = choice

    @property
    def weighted(self):
        """Are we finding a maximum weight matching"""
        return self._weighted

    @weighted.setter
    def weighted(self, choice):
        """Enable (or disable) the search for a maximum weight stable matching."""
        if self._built:
            raise Exception("Cannot modify model after it is built")
        if choice and not isinstance(self._instance, WeightedInstance):
            raise Exception(
                "Cannot find a maximum weight stable matching if "
                "the instance is not weighted"
            )
        self._weighted = choice

    @property
    def cardinality_restriction(self):
        """Are we looking for a matching of a specific, known size?"""
        return self._cardinality_restriction

    @cardinality_restriction.setter
    def cardinality_restriction(self, value):
        """Add a constraint to only search for matchings of the given size."""
        self._cardinality_restriction = value

    def _make_variables(self):
        """Makes the variables"""
        if self._variables_lr is not None:
            return
        self._variables_lr = {}
        self._variables_rl = {}
        for left in self._instance.single_agents_left:
            self._variables_lr[left.ident] = {}
            for right in left.acceptable_agents():
                name = f"x_{left.ident}_{right}"
                variable = LpVariable(name, cat="Binary")
                self._variables_lr[left.ident][right] = variable
                if right not in self._variables_rl:
                    self._variables_rl[right] = {}
                self._variables_rl[right][left.ident] = variable

    def _make_capacity_constraints(self):
        """Makes the constraints for capacities."""
        for left in self._instance.single_agents_left:
            self += (
                lpSum(self._variables_lr[left.ident].values()) <= 1,
                f"left_{left.ident}_capacity",
            )
        for right in self._instance.single_agents_right:
            # If right.ident isn't in here, then this right agent has no
            # preferences.
            if right.ident not in self._variables_rl:
                continue
            self += (
                lpSum(self._variables_rl[right.ident].values()) <= 1,
                f"right_{right.ident}_capacity",
            )

    def _make_dummy_stability_constraints(self):
        """Makes a variable variable for each agent and each rank k in their
        preferences, which will be 1 if and only if the agent is matched with
        another agent of rank k or less.
        """
        if self._variables_yl is not None:
            return
        self._variables_yl = {}
        self._variables_yr = {}
        for left in self._instance.single_agents_left:
            self._variables_yl[left.ident] = {}
            name = f"y_l_{left.ident}_1"
            self._variables_yl[left.ident][1] = LpVariable(name, cat="Binary")
            sum_left = []
            for right_id in left.preferences[0]:
                sum_left.append(self._variables_lr[left.ident][right_id])
            self += lpSum(sum_left) == self._variables_yl[left.ident][1]
            for k, tie_group in enumerate(left.preferences[1:], start=2):
                name = f"y_l_{left.ident}_{k}"
                self._variables_yl[left.ident][k] = LpVariable(name, cat="Binary")
                sum_left = []
                for right_id in tie_group:
                    sum_left.append(self._variables_lr[left.ident][right_id])
                self += (
                    lpSum(sum_left) + self._variables_yl[left.ident][k - 1]
                    == self._variables_yl[left.ident][k]
                )
        for right in self._instance.single_agents_right:
            self._variables_yr[right.ident] = {}
            name = f"y_r_{right.ident}_1"
            self._variables_yr[right.ident][1] = LpVariable(name, cat="Binary")
            sum_right = []
            for left_id in right.preferences[0]:
                sum_right.append(self._variables_lr[left_id][right.ident])
            self += lpSum(sum_right) == self._variables_yr[right.ident][1]
            for k, tie_group in enumerate(right.preferences[1:], start=2):
                name = f"y_r_{right.ident}_{k}"
                self._variables_yr[right.ident][k] = LpVariable(name, cat="Binary")
                sum_right = []
                for left_id in tie_group:
                    sum_right.append(self._variables_lr[left_id][right.ident])
                self += (
                    lpSum(sum_right) + self._variables_yr[right.ident][k - 1]
                    == self._variables_yr[right.ident][k]
                )
        for left in self._instance.single_agents_left:
            for k, tie_group in enumerate(left.preferences[1:], start=2):
                for right_id in tie_group:
                    right = self._instance.single_agent_right(right_id)
                    rank = right.rank_of(left.ident)
                    self += (
                        1 - self._variables_yl[left.ident][k]
                        <= self._variables_yr[right_id][rank]
                    )

    def _make_stability_constraints(self):
        """Makes the stability constraints."""
        for left in self._instance.single_agents_left:
            for right_id in left.acceptable_agents():
                right = self._instance.single_agent_right(right_id)
                xiq = lpSum(
                    self._variables_lr[left.ident][other]
                    for other in left.as_good_as(right.ident)
                )
                xpj = lpSum(
                    self._variables_rl[right.ident][other]
                    for other in right.as_good_as(left.ident)
                )
                self += 1 - xiq <= xpj, f"{left.ident}.{right.ident}.stability"

    def _add_dummy_card_constraint(self):
        """Make a cardinality constraint obased on the dummy variables."""
        constraint = []
        for left in self._instance.single_agents_left:
            max_group = len(left.preferences)
            constraint.append(self._variables_yl[left.ident][max_group])
        self += (lpSum(constraint) == self._cardinality_restriction, f"card-constraint")

    def _make_dummy_card_objective(self):
        """Make an objective based on the xij variables."""
        objective = []
        for left in self._instance.single_agents_left:
            max_group = len(left.preferences)
            objective.append(self._variables_yl[left.ident][max_group])
        self += lpSum(objective)

    def _make_card_objective(self):
        """Make an objective based on the xij variables."""
        objective = []
        for left in self._instance.single_agents_left:
            for right in left.acceptable_agents():
                if self.weighted:
                    objective.append(
                        left.weight_of(right) * self._variables_lr[left.ident][right]
                    )
                else:
                    objective.append(self._variables_lr[left.ident][right])
                objective.append(self._variables_lr[left.ident][right])
        self += lpSum(objective)

    def build_model(self):
        """Build the model."""
        if self._built:
            return
        self._make_variables()
        self._make_capacity_constraints()
        if self._use_dummy:
            self._make_dummy_stability_constraints()
            if not self.weighted:
                self._make_dummy_card_objective()
            else:
                if self._cardinality_restriction is not None:
                    self._add_dummy_card_constraint()
                self._make_regular_objective()
        else:
            self._make_stability_constraints()
            self._make_card_objective()
        self._built = True

    def solve(self):
        """Solves the problem, and returns the matching. The matching is a map
        such that matching[left] = right if and only if left is matched to
        right.
        """
        self.build_model()
        super().solve()
        if self.status != LpStatusOptimal:
            raise Exception("Not optimal solution.")
        matching = {}
        for left in self._instance.single_agents_left:
            for right in left.acceptable_agents():
                # Because some solvers sometimes return "close to 1" instead of
                # 1, even for binary values, we just get close.
                if self._variables_lr[left.ident][right].varValue >= 0.95:
                    matching[left.ident] = right
        return matching


class MAX_HRTC_IP(LpProblem):
    """An IP model to find a maximum cardinality stable matching in HRTC."""

    def __init__(
        self,
        instance: Instance,
        left_weights: dict[str, float] = {},
        right_weights: dict[str, float] = {},
        name: str | None = None,
        solver: LpSolver | None = None,
    ):
        if name is None:
            name = "HRTC"
        if solver is None:
            self._solver = HiGHS(msg=False)
        super().__init__(name, LpMaximize)
        self._instance = instance
        self._built = False

        """Map from each variable name (as a string) to the actual variable object.
        Left is only individual doctors (even those in couples).
        _variables_lr is a map such that _variables_lr[left][right] gives the
        variable where Agent left is assigned to Agent right
        _variables_rl is a map such that _variables_rl[right][left] gives the
        variable where Agent right is assigned to Agent left
        """
        self._variables_lr: dict[str, dict[str, LpVariable]] = defaultdict(dict)
        self._variables_rl: dict[str, dict[str, LpVariable]] = defaultdict(dict)

        """Map from each couple name (as a string) and hospital to the actual
        variable object. Left is couples, right is hospital.
        """
        self._variables_ylr: dict[str, dict[str, LpVariable]] = defaultdict(dict)

        """Map from each agent name (as a string) and rank number to the
        corresponding variable object.
        """

        self._variables_ws: dict[str, dict[str, LpVariable]] = defaultdict(dict)
        self._variables_wc: dict[str, dict[str, LpVariable]] = defaultdict(dict)
        self._variables_wh: dict[str, dict[str, LpVariable]] = defaultdict(dict)

        """Alpha1 and alpha2 variables."""
        self._alphaone: dict[str, dict[int, dict[int, LpVariable]]] = defaultdict(
            lambda: defaultdict(dict)
        )
        self._alphatwo: dict[str, dict[int, dict[int, LpVariable]]] = defaultdict(
            lambda: defaultdict(dict)
        )

        """Should we find a maximum weight matching, or maximum size?"""
        self._left_weights: dict[str, float] = left_weights
        self._right_weights: dict[str, float] = right_weights

    def right_weight_of(self, agent: Agent | str) -> float:
        if isinstance(agent, Agent):
            ident = agent.ident
        else:
            ident = agent
        if ident in self._right_weights:
            return self._right_weights[ident]
        return 1

    def left_weight_of(self, agent: Agent | str) -> float:
        if isinstance(agent, Agent):
            ident = agent.ident
        else:
            ident = agent
        if ident in self._left_weights:
            return self._left_weights[ident]
        return 1

    @property
    def weighted(self):
        """Are we finding a maximum weight matching"""
        return len(self._weights) > 0

    def _make_variables(self):
        """Makes the variables"""
        if self._variables_lr:
            return
        for left in self._instance.single_agents_left:
            for rankno, rank in enumerate(left.preferences):
                name = f"ws_{left.ident}_{rankno}"
                variable = LpVariable(name, cat="Binary")
                self._variables_ws[left.ident][rankno] = variable
                for right in rank:
                    name = f"x_{left.ident}_{right}"
                    variable = LpVariable(name, cat="Binary")
                    self._variables_lr[left.ident][right] = variable
                    self._variables_rl[right][left.ident] = variable
        for couple in self._instance.couples_left:
            for rankno, rank in enumerate(couple.preferences):
                name = f"wc_{couple.split_ident()}_{rankno}"
                variable = LpVariable(name, cat="Binary")
                self._variables_wc[couple.ident][rankno] = variable
                for prefno, right in enumerate(rank):
                    name = f"y_{couple.split_ident()}_{right}"
                    variable = LpVariable(name, cat="Binary")
                    self._variables_ylr[couple.ident][right] = variable
                    # Split agents
                    one, two = right.split(",")
                    name = f"x_{couple.first.ident}_{one}"
                    variable = LpVariable(name, cat="Binary")
                    self._variables_lr[couple.first.ident][one] = variable
                    self._variables_rl[one][couple.first.ident] = variable
                    name = f"x_{couple.second.ident}_{two}"
                    variable = LpVariable(name, cat="Binary")
                    self._variables_lr[couple.second.ident][two] = variable
                    self._variables_rl[two][couple.second.ident] = variable
                    if one != two:
                        name = f"alpha1_{couple.split_ident()}_{rankno}_{prefno}"
                        variable = LpVariable(name, cat="Binary")
                        self._alphaone[couple.ident][rankno][prefno] = variable
                        name = f"alpha2_{couple.split_ident()}_{rankno}_{prefno}"
                        variable = LpVariable(name, cat="Binary")
                        self._alphatwo[couple.ident][rankno][prefno] = variable
        for hospital in self._instance.single_agents_right:
            for rankno, rank in enumerate(hospital.preferences):
                name = f"wh_{hospital.ident}_{rankno}"
                variable = LpVariable(
                    name, cat="Integer", lowBound=0, upBound=hospital.capacity
                )
                self._variables_wh[hospital.ident][rankno] = variable

    def _make_capacity_constraints(self):
        """Makes the constraints for capacities."""
        # Constraints 7 (agents not in couples)
        for left in self._instance.single_agents_left:
            # If left.ident isn't in here, then this left agent has no
            # preferences.
            if left.ident not in self._variables_lr:
                continue
            self += (
                lpSum(self._variables_lr[left.ident].values()) <= 1,
                f"left_{left.ident}_capacity",
            )
        # Constraints 7 (agents in couples)
        for couple in self._instance.couples_left:
            for agent in [couple.first, couple.second]:
                # If left.ident isn't in here, then this left agent has no
                # preferences.
                if agent.ident not in self._variables_lr:
                    continue
                self += (
                    lpSum(self._variables_lr[agent.ident].values()) <= 1,
                    f"left_couple_{agent.ident}_capacity",
                )
        # Constraints 8
        for right in self._instance.single_agents_right:
            # If right.ident isn't in here, then this right agent has no
            # preferences.
            if right.ident not in self._variables_rl:
                continue
            self += (
                lpSum(self._variables_rl[right.ident].values()) <= right.capacity,
                f"right_{right.ident}_capacity",
            )

    def _make_y_linking_constraints(self) -> None:
        # If couple (d1,d2) are assigned to (h1, h2)
        # sum over all preferences of couple
        #   where first hospital is j
        #   get y value ylr[couple.ident][pref_pair]
        #   sum over all = x[d1][j]
        """Makes the linking constraints for the y-variables."""
        for couple in self._instance.couples_left:
            first_lists: dict[str, list[str]] = defaultdict(list)
            second_lists: dict[str, list[str]] = defaultdict(list)
            for rank in couple.preferences:
                for pref_pair in rank:
                    one, two = pref_pair.split(",")
                    first_lists[one].append(
                        self._variables_ylr[couple.ident][pref_pair]
                    )
                    second_lists[two].append(
                        self._variables_ylr[couple.ident][pref_pair]
                    )
            for hospital, varlist in first_lists.items():
                self += (
                    lpSum(varlist) == self._variables_lr[couple.first.ident][hospital],
                    f"y_9_link_S_{couple.first.ident}_H_{hospital}",
                )
            for hospital, varlist in second_lists.items():
                self += (
                    lpSum(varlist) == self._variables_lr[couple.second.ident][hospital],
                    f"y_10_link_S_{couple.second.ident}_H_{hospital}",
                )

    def _make_w_linking_constraints(self):
        """Makes the linking constraints for the w-variables."""
        for left in self._instance.single_agents_left:
            # Skip agent with no preferences
            if not left.preferences:
                continue
            self += (
                lpSum(
                    self._variables_lr[left.ident][right]
                    for right in left.preferences[0]
                )
                == self._variables_ws[left.ident][0],
                f"wil_23_linking_L_{left.ident}_l0",
            )
            for rankno, rank in enumerate(left.preferences):
                if rankno == 0:
                    continue
                self += (
                    lpSum(self._variables_lr[left.ident][right] for right in rank)
                    + self._variables_ws[left.ident][rankno - 1]
                    == self._variables_ws[left.ident][rankno],
                    f"wil_24_linking_L_{left.ident}_l{rankno}",
                )
        for left in self._instance.couples_left:
            # Skip agent with no preferences
            if not left.preferences:
                continue
            self += (
                lpSum(
                    self._variables_ylr[left.ident][right]
                    for right in left.preferences[0]
                )
                == self._variables_wc[left.ident][0],
                f"wil_25_linking_LC_{left.split_ident()}_l0",
            )
            for rankno, rank in enumerate(left.preferences):
                if rankno == 0:
                    continue
                self += (
                    lpSum(self._variables_ylr[left.ident][right] for right in rank)
                    + self._variables_wc[left.ident][rankno - 1]
                    == self._variables_wc[left.ident][rankno],
                    f"wil_26_linking_LC_{left.split_ident()}_l{rankno}",
                )
        for right in self._instance.single_agents_right:
            # Skip agent with no preferences
            if not right.preferences:
                continue
            self += (
                lpSum(
                    self._variables_rl[right.ident][left]
                    for left in right.preferences[0]
                )
                == self._variables_wh[right.ident][0],
                f"wil_27_linking_R_{right.ident}_l0",
            )
            for rankno, rank in enumerate(right.preferences):
                if rankno == 0:
                    continue
                self += (
                    lpSum(self._variables_rl[right.ident][left] for left in rank)
                    + self._variables_wh[right.ident][rankno - 1]
                    == self._variables_wh[right.ident][rankno],
                    f"wil_28_linking_R_{right.ident}_l{rankno}",
                )

    def _make_stability_constraints_s1(self):
        for left in self._instance.single_agents_left:
            for rankno, rank in enumerate(left.preferences):
                for hosp in rank:
                    actual_hosp = self._instance.single_agent_right(hosp)
                    self += (
                        actual_hosp.capacity
                        * (1 - self._variables_ws[left.ident][rankno])
                        <= self._variables_wh[hosp][actual_hosp.rank_of(left) - 1],
                        f"S1_29_stab_L_{left.ident}_H_{hosp}",
                    )

    def _make_stability_constraints_s2_kpr(self):
        for left in self._instance.couples_left:
            for rankno, rank in enumerate(left.preferences):
                for prefno, hosp_pair in enumerate(rank):
                    hosp_a, hosp_b = hosp_pair.split(",")
                    if hosp_a == hosp_b:
                        continue
                    actual_hosp_a = self._instance.single_agent_right(hosp_a)
                    actual_hosp_b = self._instance.single_agent_right(hosp_b)
                    d1, d2 = left.first, left.second
                    r1 = actual_hosp_a.rank_of(d1) - 1
                    r2 = actual_hosp_b.rank_of(d2) - 1
                    self += (
                        actual_hosp_a.capacity
                        * (
                            1
                            - self._variables_wc[left.ident][rankno]
                            - self._alphaone[left.ident][rankno][prefno]
                        )
                        <= self._variables_wh[hosp_a][r1]
                        - self._variables_lr[d1.ident][hosp_a],
                        f"S2_stab_1_C_{left.split_ident()}_r_{rankno}_p_{prefno}_H_{hosp_a}",
                    )
                    self += (
                        actual_hosp_b.capacity
                        * (
                            1
                            - self._variables_wc[left.ident][rankno]
                            - self._alphatwo[left.ident][rankno][prefno]
                        )
                        <= self._variables_wh[hosp_b][r2]
                        - self._variables_lr[d2.ident][hosp_b],
                        f"S2_stab_2_C_{left.split_ident()}_r_{rankno}_p_{prefno}__H_{hosp_b}",
                    )
                    self += (
                        self._alphatwo[left.ident][rankno][prefno]
                        <= 1 - self._variables_lr[d1.ident][hosp_a],
                        f"S2_stab_alphatwo_{left.split_ident()}_{rankno}_{prefno}",
                    )
                    self += (
                        self._alphaone[left.ident][rankno][prefno]
                        <= 1 - self._variables_lr[d2.ident][hosp_b],
                        f"S2_stab_alphaone_{left.split_ident()}_{rankno}_{prefno}",
                    )
                    self += (
                        self._alphaone[left.ident][rankno][prefno]
                        + self._alphatwo[left.ident][rankno][prefno]
                        <= 1,
                        f"S2_stab_alphaone_alpha_two_{left.split_ident()}_{rankno}_{prefno}",
                    )

    def _make_stability_constraints_s3_kpr(self):
        for left in self._instance.couples_left:
            for rankno, rank in enumerate(left.preferences):
                for hosp_pair in rank:
                    hosp_a, hosp_b = hosp_pair.split(",")
                    if hosp_a != hosp_b:
                        continue
                    hosp = hosp_a
                    actual_hosp = self._instance.single_agent_right(hosp)
                    d1, d2 = left.first, left.second
                    r1 = actual_hosp.rank_of(d1) - 1
                    r2 = actual_hosp.rank_of(d2) - 1
                    if r1 > r2:
                        d2, d1 = d1, d2
                        r2, r1 = r1, r2
                    self += (
                        actual_hosp.capacity
                        * (1 - self._variables_wc[left.ident][rankno])
                        - (1 - self._variables_lr[d1.ident][hosp])
                        <= (
                            self._variables_wh[hosp][r2]
                            - self._variables_lr[d2.ident][hosp]
                        ),
                        f"S3_stab_C_{left.split_ident()}_H_{hosp}",
                    )

    def _make_card_objective(self):
        """Make an objective based on the xij variables."""
        objective = []
        for left, vardict in self._variables_lr.items():
            for right, var in vardict.items():
                objective.append(
                    var * self.left_weight_of(left) * self.right_weight_of(right)
                )
        self += lpSum(objective)

    def build_model(self):
        """Build the model."""
        if self._built:
            return
        self._make_variables()
        self._make_capacity_constraints()
        self._make_y_linking_constraints()
        self._make_w_linking_constraints()
        self._make_stability_constraints_s1()
        self._make_stability_constraints_s2_kpr()
        self._make_stability_constraints_s3_kpr()
        self._make_card_objective()
        self._built = True

    def solve(self):
        """Solves the problem, and returns the matching. The matching is a map
        such that matching[left] = right if and only if left is matched to
        right.
        """
        self._instance.clean()
        self.build_model()
        super().solve(self._solver)
        if self.status != LpStatusOptimal:
            raise Exception(f"Not optimal solution: {self.status}.")
        matching = {}
        for left in self._instance.single_agents_left:
            for right in left.acceptable_agents():
                # Because some solvers sometimes return "close to 1" instead of
                # 1, even for binary values, we just get close.
                if self._variables_lr[left.ident][right].varValue >= 0.95:
                    matching[left.ident] = right

        for couple in self._instance.couples_left:
            for right_pair in couple.acceptable_agents():
                right_a, right_b = right_pair.split(",")
                # Because some solvers sometimes return "close to 1" instead of
                # 1, even for binary values, we just get close.
                if self._variables_lr[couple.first.ident][right_a].varValue >= 0.95:
                    matching[couple.first.ident] = right_a
                if self._variables_lr[couple.second.ident][right_b].varValue >= 0.95:
                    matching[couple.second.ident] = right_b
        return matching
