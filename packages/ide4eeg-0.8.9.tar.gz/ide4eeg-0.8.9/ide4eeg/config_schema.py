"""Lightweight runtime validation for IDE4EEG TOML configs.

Scoped to the **boundary** — i.e. the two places we read user-provided
TOML (``gui_config.load_toml`` and ``input.input.read_config_file``).
Internal pipeline code continues to consume plain ``dict`` and stays
duck-typed, matching the dict-as-document philosophy that the rest of
the codebase already follows.

The validator's job is to catch the failure modes that have actually
bitten users:

1. **Typos in top-level keys** (``"filer"`` instead of ``"filters"``).
   These silently get ignored by deep-merge and the user spends an hour
   wondering why their filter settings have no effect.

2. **Wrong type for a known section** — e.g. ``filters = "iir"`` instead
   of ``[filters]\\n method = "iir"``.

Strategy: warn loudly, don't block.  TOML loading remains lenient so
forward-compatible configs (e.g. keys introduced in a future version)
still load on the current version.  Truly malformed TOML still raises
from ``tomllib`` upstream — we only validate the parsed dict shape.

Sub-section schemas are deliberately NOT enforced here.  Each leaf
default fills in via :func:`gui_config.check_and_prepare_config` or
the equivalent fall-throughs in :mod:`input.input`, and a stricter
schema layer would duplicate that work + invent migration headaches.
Lift to per-section schemas only if users start typo'ing sub-keys.
"""
from __future__ import annotations

import dataclasses
import difflib
import logging
from typing import Any, Iterable

logger = logging.getLogger(__name__)


class ConfigIsExamplesManifestError(ValueError):
    """The TOML file looks like the examples manifest, not a config.

    Raised by :func:`validate_config` when the file at the path
    handed to ``ide4eeg`` is the per-example ``example.toml``
    manifest (``[[configs]]`` array of ``{file, label}`` pairs) and
    not the actual pipeline config it points to.  The CLI / GUI
    catch this to print a clean remediation message before the
    pipeline can crash on a manifest's foreign top-level keys.
    """


def is_examples_manifest(cfg: dict[str, Any]) -> bool:
    """True iff *cfg* matches the shape of an example.toml manifest.

    Strong signature: presence of a ``configs`` array of dicts each
    containing a ``file`` key (paths to the real pipeline configs).
    The other manifest fields (``title``, ``description``, ``data``,
    ``docs``, ``reference`` as a free-form string) overlap too much
    with what a careless user might put in a real config; the
    ``configs`` array is the unambiguous marker.
    """
    configs = cfg.get("configs")
    if not isinstance(configs, list) or not configs:
        return False
    return all(
        isinstance(c, dict) and "file" in c for c in configs)


def _format_manifest_remediation(cfg: dict[str, Any],
                                 source: str) -> str:
    """Build the error message the CLI / GUI will surface."""
    import os
    files = [c.get("file") for c in cfg.get("configs", [])
             if isinstance(c, dict) and "file" in c]
    base = os.path.dirname(source) if source != "<config>" else ""
    title = cfg.get("title", "this example")
    listed = "\n".join(
        f"  - {os.path.join(base, f) if base else f}"
        for f in files) if files else "  (no config files listed)"
    return (
        f"'{source}' is the examples manifest for {title!r}, not a "
        f"pipeline config.  Open one of the configs it references "
        f"instead:\n{listed}")


@dataclasses.dataclass(frozen=True)
class ConfigIssue:
    """One validation finding.

    Attributes
    ----------
    severity :
        A standard :mod:`logging` level constant (``logging.WARNING``
        or ``logging.ERROR``).  Stored as the int directly so the
        dispatch loop can call ``logger.log(severity, ...)`` without
        a string-equality branch.
    key_path :
        Dot-separated path to the offending key in the config dict.
    message :
        Human-readable explanation of what's wrong.
    """
    severity: int
    key_path: str
    message: str

    def __str__(self) -> str:
        return (f"[{logging.getLevelName(self.severity).lower()}] "
                f"{self.key_path}: {self.message}")


def _suggest(unknown: str, known: Iterable[str]) -> str | None:
    """Return the closest known key to *unknown*, if any are similar."""
    matches = difflib.get_close_matches(unknown, list(known), n=1, cutoff=0.7)
    return matches[0] if matches else None


# Keys that USED to be valid but were intentionally removed.  When a
# stale user / example config still carries them, the validator's
# default "unknown top-level key — likely a typo" message is misleading
# (the user didn't typo, we dropped the key).  Map them to a tailored
# explanation so the log line is actionable.
DEPRECATED_TOP_LEVEL_KEYS: dict[str, str] = {
    "use_mne_viewer":
        "deprecated in 0.8.5 — Svarog is preferred automatically when "
        "its jar is installed; the MNE viewer is the automatic fallback "
        "when not.  Safe to remove from your config.",
    "prepare_tf_statistics":
        "deferred to _unreleased/ — TF-statistics analysis is "
        "pending a GUI panel before re-release.  Safe to remove "
        "from your config; the feature will return as a TOML key in "
        "a future version once the panel ships.",
    "prepare_statistics":
        "removed — superseded by per-feature analysis flags "
        "(prepare_eeg_profiles, prepare_connectivity_analysis, "
        "prepare_dipole_fitting, prepare_mp_filter).  Safe to remove.",
    "prepare_frequency_analysis":
        "removed — superseded by mne_catalog entries for spectra and "
        "time-frequency analyses (e.g. psd_topomap, tfr_morlet).  Safe "
        "to remove from your config.",
    "tf_statistics":
        "deferred — see prepare_tf_statistics.  Safe to remove from "
        "your config.",
}


def validate_config(
    config: dict[str, Any], *, source: str = "<config>",
) -> list[ConfigIssue]:
    """Validate a loaded TOML dict against the canonical config shape.

    Imports :data:`gui_config.DEFAULT_CONFIG` lazily to avoid a hard
    import cycle with the GUI layer.

    Parameters
    ----------
    config :
        Parsed TOML config (the dict ``tomllib.load`` returns).
    source :
        Human-readable origin, used in log lines.  Typically the TOML
        file path.

    Returns
    -------
    List of :class:`ConfigIssue` — empty when the config validates cleanly.
    """
    from .gui_config import DEFAULT_CONFIG

    # Manifest-vs-config UX guard.  When a user passes an example
    # dir's ``example.toml`` to ``ide4eeg`` (a natural first guess --
    # the per-example dir has both ``example.toml`` and
    # ``config_<name>.toml``), validate_config would otherwise spew
    # ~7 unknown-top-level-key warnings and then the pipeline would
    # crash deeper in.  Detect the manifest shape up front, raise a
    # specific exception, let the entry points print a clean message.
    if is_examples_manifest(config):
        raise ConfigIsExamplesManifestError(
            _format_manifest_remediation(config, source))

    # Skip validation when the cfg is a runtime-serialized snapshot --
    # the GUI dumps the in-memory cfg to a temp TOML at pipeline launch
    # (see gui.py: tempfile.NamedTemporaryFile + dump_toml) and main.py
    # reads it back through this same load path.  By that point the cfg
    # holds runtime sections that aren't in DEFAULT_CONFIG (mne_catalog,
    # amplitude_*, etc.); validating them would spam warnings the user
    # never typed.  The presence of any _pipeline_* runtime pin is the
    # tell that this is internal, not user-facing.
    if any(key.startswith("_pipeline_") for key in config):
        return []

    issues: list[ConfigIssue] = []
    known_keys = set(DEFAULT_CONFIG.keys())

    # Runtime-injected metadata is allowed at top level even though it
    # isn't in DEFAULT_CONFIG (run_file derives _input_dir etc.).  Don't
    # warn on these.
    for key, val in config.items():
        if key.startswith("_"):
            continue
        if key not in known_keys:
            # Deprecated-key messaging wins over the generic "looks
            # like a typo" hint — the user didn't typo, we dropped
            # the key, and the migration note is more useful than a
            # difflib suggestion.
            if key in DEPRECATED_TOP_LEVEL_KEYS:
                issues.append(ConfigIssue(
                    logging.WARNING, key,
                    DEPRECATED_TOP_LEVEL_KEYS[key]))
                continue
            hint = _suggest(key, known_keys)
            tail = f" (did you mean {hint!r}?)" if hint else ""
            issues.append(ConfigIssue(
                logging.WARNING, key,
                f"unknown top-level key — likely a typo{tail}"))
            continue
        default = DEFAULT_CONFIG[key]
        # Type-shape check: when the default is a dict, the user's
        # value must also be a dict — catches `filters = "iir"` mistakes
        # where someone forgets the [filters] section header.
        if isinstance(default, dict) and not isinstance(val, dict):
            issues.append(ConfigIssue(
                logging.WARNING, key,
                f"expected a [section] (dict), got "
                f"{type(val).__name__} — write `[{key}]` and indent "
                f"the keys underneath"))

    for issue in issues:
        logger.log(issue.severity, "Config %s: %s", source, issue)

    return issues
