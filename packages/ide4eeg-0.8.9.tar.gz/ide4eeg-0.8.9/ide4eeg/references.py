"""Scientific references for IDE4EEG pipeline methods.

Maps pipeline step keys to citation entries.  Used by docstrings,
GUI Help panel, and exported reports.
"""

# Each entry: key → dict with authors, title, journal, year, volume,
#             pages, doi, url, and steps (list of pipeline steps it covers).

REFERENCES = {

    # ── Sleep staging ────────────────────────────────────────────────
    "malinowska2009_staging": {
        "authors": ("Malinowska U, Klekowicz H, Wakarow A, "
                    "Niemcewicz S, Durka PJ"),
        "title": ("Fully Parametric Sleep Staging Compatible "
                   "with the Classical Criteria"),
        "journal": "Neuroinformatics",
        "year": 2009,
        "volume": "7",
        "pages": "245-253",
        "doi": "10.1007/s12021-009-9059-9",
        "url": "https://link.springer.com/article/10.1007/s12021-009-9059-9",
        "steps": ["sleep_staging"],
    },

    # ── EEG profiles (FASP-based structure detection) ────────────────
    "malinowska2013_profiles": {
        "authors": ("Malinowska U, Chatelle C, Bruno MA, "
                    "Noirhomme Q, Laureys S, Durka PJ"),
        "title": ("Electroencephalographic profiles for differentiation "
                   "of disorders of consciousness"),
        "journal": "BioMedical Engineering OnLine",
        "year": 2013,
        "volume": "12",
        "pages": "109",
        "doi": "10.1186/1475-925X-12-109",
        "url": "https://link.springer.com/article/10.1186/1475-925X-12-109",
        "steps": ["eeg_profiles"],
    },

    # ── EEG artifact detection ───────────────────────────────────────
    "klekowicz2009_artifacts": {
        "authors": ("Klekowicz H, Malinowska U, Piotrowska AJ, "
                    "Wolynczyk-Gmaj D, Niemcewicz S, Durka PJ"),
        "title": ("On the Robust Parametric Detection of EEG Artifacts "
                   "in Polysomnographic Recordings"),
        "journal": "Neuroinformatics",
        "year": 2009,
        "volume": "7",
        "pages": "147-160",
        "doi": "10.1007/s12021-009-9045-2",
        "url": "https://link.springer.com/article/10.1007/s12021-009-9045-2",
        "steps": ["artifacts"],
    },

    # ── Matching Pursuit (algorithm) ─────────────────────────────────
    "mallat1993_mp": {
        "authors": "Mallat SG, Zhang Z",
        "title": ("Matching Pursuits with Time-Frequency "
                   "Dictionaries"),
        "journal": "IEEE Transactions on Signal Processing",
        "year": 1993,
        "volume": "41(12)",
        "pages": "3397-3415",
        "doi": "10.1109/78.258082",
        "url": "https://ieeexplore.ieee.org/document/258082",
        "steps": ["mp_decomposition", "mp_filter", "mp_analysis"],
    },

    # ── Multivariate MP + empi / Svarog ──────────────────────────────
    "kus2013_mmp": {
        "authors": "Kus R, Rozanski PT, Durka PJ",
        "title": ("Multivariate matching pursuit in optimal Gabor "
                   "dictionaries: theory and software with interface "
                   "for EEG/MEG via Svarog"),
        "journal": "BioMedical Engineering OnLine",
        "year": 2013,
        "volume": "12",
        "pages": "94",
        "doi": "10.1186/1475-925X-12-94",
        "url": "https://link.springer.com/article/10.1186/1475-925X-12-94",
        "steps": ["mp_decomposition", "mp_analysis"],
    },

    # ── empi — GPU-accelerated MP implementation ─────────────────────
    "rozanski2024_empi": {
        "authors": "Rozanski PT",
        "title": ("empi: GPU-Accelerated Matching Pursuit "
                   "with Continuous Dictionaries"),
        "journal": "ACM Transactions on Mathematical Software",
        "year": 2024,
        "volume": "50(3)",
        "pages": "17",
        "doi": "10.1145/3674832",
        "url": "https://dl.acm.org/doi/10.1145/3674832",
        "steps": ["mp_decomposition", "mp_filter", "mp_analysis"],
    },

    # ── empi — PhD thesis ──────────────────────────────────────────
    "rozanski2024_thesis": {
        "authors": "Rozanski PT",
        "title": ("Heterogeniczna implementacja matching pursuit "
                   "z symulacja ciagłej przestrzeni parametrow"),
        "journal": "PhD thesis, University of Warsaw",
        "year": 2024,
        "volume": "",
        "pages": "",
        "doi": None,
        "url": "https://www.mimuw.edu.pl/media/uploads/doctorates/thesis-piotr-rozanski.pdf",
        "steps": ["mp_decomposition", "mp_filter", "mp_analysis"],
    },

    # ── Multivariate Autoregressive models & connectivity ────────────
    "kaminski1991_mvar": {
        "authors": "Kamiński M, Blinowska KJ",
        "title": ("A new method of the description of the information "
                  "flow in the brain structures"),
        "journal": "Biological Cybernetics",
        "year": 1991,
        "volume": "65",
        "pages": "203-210",
        "doi": "10.1007/BF00198091",
        "url": "https://doi.org/10.1007/BF00198091",
        "steps": ["connectivity_analysis"],
    },

    "baccala2001_pdc": {
        "authors": "Baccalá LA, Sameshima K",
        "title": ("Partial directed coherence: a new concept in "
                  "neural structure determination"),
        "journal": "Biological Cybernetics",
        "year": 2001,
        "volume": "84",
        "pages": "463-474",
        "doi": "10.1007/PL00007990",
        "url": "https://doi.org/10.1007/PL00007990",
        "steps": ["connectivity_analysis"],
    },

    "blinowska2004_info": {
        "authors": "Blinowska KJ, Kuś R, Kamiński M",
        "title": ("Granger causality and information flow in "
                  "multivariate processes"),
        "journal": "Physical Review E",
        "year": 2004,
        "volume": "70",
        "pages": "050902",
        "doi": "10.1103/PhysRevE.70.050902",
        "url": "https://doi.org/10.1103/PhysRevE.70.050902",
        "steps": ["connectivity_analysis"],
    },

    # ── Dipole fitting ─────────────────────────────────────────────────
    "scherg1990_dipole": {
        "authors": "Scherg M",
        "title": ("Fundamentals of dipole source potential analysis"),
        "journal": ("Auditory Evoked Magnetic Fields and Electric "
                    "Potentials. Adv Audiol"),
        "year": 1990,
        "volume": "6",
        "pages": "40-69",
        "doi": None,
        "url": None,
        "steps": ["dipole_fitting"],
    },

    "durka2018_mpdip": {
        "authors": "Durka PJ",
        "title": ("Matching Pursuit Dipole Fitting for EEG source "
                   "localization"),
        "journal": "University of Warsaw",
        "year": 2018,
        "volume": "",
        "pages": "",
        "doi": None,
        "url": None,
        "steps": ["dipole_fitting"],
    },

    # ── Cluster permutation test ─────────────────────────────────────
    "maris2007_cluster": {
        "authors": "Maris E, Oostenveld R",
        "title": ("Nonparametric statistical testing of EEG- "
                   "and MEG-data"),
        "journal": "Journal of Neuroscience Methods",
        "year": 2007,
        "volume": "164(1)",
        "pages": "177-190",
        "doi": "10.1016/j.jneumeth.2007.03.024",
        "url": "https://pubmed.ncbi.nlm.nih.gov/17517438/",
        "steps": ["cluster_test"],
    },

    # ── MNE-Python ───────────────────────────────────────────────────
    "gramfort2014_mne": {
        "authors": ("Gramfort A, Luessi M, Larson E, Engemann DA, "
                    "Strohmeier D, Brodbeck C, Parkkonen L, "
                    "Hamalainen MS"),
        "title": "MNE software for processing MEG and EEG data",
        "journal": "NeuroImage",
        "year": 2014,
        "volume": "86",
        "pages": "446-460",
        "doi": "10.1016/j.neuroimage.2013.10.027",
        "url": "https://pubmed.ncbi.nlm.nih.gov/24161808/",
        "steps": ["resample", "montage", "filtering", "baseline",
                  "ica", "bad_channels", "chosen_channels",
                  "time_analysis"],
    },

}


# ── Convenience helpers ──────────────────────────────────────────────

def refs_for_step(step_key):
    """Return list of reference dicts applicable to *step_key*."""
    return [r for r in REFERENCES.values() if step_key in r["steps"]]


def format_citation(ref):
    """One-line citation string:  Authors (Year). Title. Journal Vol:Pages."""
    parts = [
        ref["authors"],
        f"({ref['year']})",
        f"{ref['title']}.",
        ref["journal"],
        ref.get("volume", ""),
    ]
    if ref.get("pages"):
        parts[-1] += f":{ref['pages']}"
    if ref.get("doi"):
        parts.append(f"DOI: {ref['doi']}")
    elif ref.get("url"):
        parts.append(ref["url"])
    return " ".join(p for p in parts if p)


def format_all():
    """Return sorted multi-line string of all references."""
    lines = []
    for key in sorted(REFERENCES):
        lines.append(f"[{key}] {format_citation(REFERENCES[key])}")
    return "\n".join(lines)
