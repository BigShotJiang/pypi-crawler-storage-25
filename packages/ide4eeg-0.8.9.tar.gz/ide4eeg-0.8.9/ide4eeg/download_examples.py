"""Download and discover example data for IDE4EEG.

Each example is published as a GitLab Generic Package containing its
manifest (``example.toml``), pipeline configs, signal files, and any
auxiliary data.  Downloads extract into ``~/IDE4EEG_examples/<name>/``
-- a plain home-directory folder, NOT under ``~/.obci/``, so the
pipeline's "output dir = parent of input file" default produces
``~/IDE4EEG_examples/<name>/IDE4EEG_OUT_*/`` instead of polluting
the OBCI runtime-cache tree.  The same path applies to source / pip
wheel / .exe / .app installs.

Adding a new example:

  1. Author the manifest + configs in ``<repo>/examples/<name>/``.
  2. Build a zip of that directory plus the signal files::

         cd examples/<name> && \
             cp /path/to/signal_files . && \
             zip /tmp/data.zip *

  3. Upload to GitLab Generic Packages as
     ``examples-<name>/v<N>.<M>``::

         glab api projects/fuw_software%2Fide4eeg/packages/generic/\
             examples-<name>/v<N>.<M>/data.zip \
             --method PUT --input /tmp/data.zip

  4. Append the example to ``_AVAILABLE_EXAMPLES`` below with its
     package coordinates and zip sha256.

Usage (CLI)::

    python -m ide4eeg.download_examples              # all examples
    python -m ide4eeg.download_examples dipole_spindles

Usage (Python)::

    from ide4eeg.download_examples import (
        download_examples, find_examples, AVAILABLE_EXAMPLES)
    download_examples()
    for path, meta, ok in find_examples():
        print(path, meta["title"], "downloaded" if ok else "missing")
"""

import hashlib
import logging
import os
import tempfile
import urllib.request
import zipfile
from pathlib import Path

logger = logging.getLogger(__name__)


_PACKAGE_URL_TEMPLATE = (
    "https://gitlab.com/api/v4/projects/fuw_software%2Fide4eeg/"
    "packages/generic/{package}/{version}/data.zip"
)


#: One entry per example.  ``package`` + ``version`` resolve to a
#: Generic Package zip URL; ``sha256`` is the zip's content hash and
#: catches corrupted downloads / wrong-version uploads.  Bump the
#: version when the zip content changes.
AVAILABLE_EXAMPLES = {
    "dipole_spindles": {
        "package": "examples-dipole_spindles",
        "version": "v1.6.1",
        "sha256": "a9857b2078030d08a3088f803951605f266c75b7042b83e6c99e9d67a59f0f67",
    },
}


# Examples live at the top of the user's home directory, NOT under
# ``~/.obci/``.  Reason: the pipeline's default ``output_path = parent
# of input file`` would otherwise write ``IDE4EEG_OUT_*`` directories
# back under ``~/.obci/``, mixing user-generated artifacts with the
# read-mostly runtime caches that tree is supposed to hold.  Pre-2026-05
# installs that wrote to ``~/.obci/ide4eeg/examples/`` are migrated
# in :func:`ide4eeg.download_tools.migrate_legacy_paths`.
_EXAMPLES_DIR = Path.home() / "IDE4EEG_examples"


# ── Discovery ──────────────────────────────────────────────────────────

def find_examples(examples_dir=None):
    """Discover example directories containing ``example.toml``.

    Parameters
    ----------
    examples_dir : str or Path or None
        Root examples directory.  Defaults to ``_EXAMPLES_DIR``.

    Returns
    -------
    list of (str, dict, bool)
        Each entry is ``(directory_path, metadata_dict, is_downloaded)``.
        Sorted by manifest ``order`` (default 99) then by title.
    """
    import tomllib

    root = Path(examples_dir) if examples_dir else _EXAMPLES_DIR
    if not root.is_dir():
        return []

    results = []
    for child in sorted(root.iterdir()):
        meta_path = child / "example.toml"
        if not meta_path.is_file():
            continue
        with open(meta_path, "rb") as f:
            meta = tomllib.load(f)
        downloaded = example_is_downloaded(str(child), meta)
        results.append((str(child), meta, downloaded))

    results.sort(key=lambda r: (r[1].get("order", 99), r[1].get("title", "")))
    return results


def example_is_downloaded(example_dir, meta):
    """Check whether the manifest's declared data files exist on disk.

    Recognises both the new ``[data] files = [...]`` schema and the
    legacy top-level ``data_files = [...]``.
    """
    files = meta.get("data", {}).get("files", meta.get("data_files", []))
    for fname in files:
        if not os.path.isfile(os.path.join(example_dir, fname)):
            return False
    return True


# ── Download ───────────────────────────────────────────────────────────

def _hash_file(path, algo="sha256", chunk_size=1 << 20):
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _safe_extract(zf, target):
    """Extract *zf* into *target*, refusing absolute paths and '..' traversal."""
    target = Path(target).resolve()
    for info in zf.infolist():
        if info.filename.startswith("/") or ".." in info.filename:
            raise ValueError(f"Unsafe path in zip: {info.filename}")
        dest = (target / info.filename).resolve()
        if not str(dest).startswith(str(target) + os.sep) and dest != target:
            raise ValueError(f"Path escapes target: {info.filename}")
        zf.extract(info, target)


def download_example(name, target_dir=None, progress_callback=None):
    """Download and extract a single example into ``<target_dir>/<name>/``.

    Parameters
    ----------
    name : str
        Key in :data:`AVAILABLE_EXAMPLES`.
    target_dir : str or Path or None
        Defaults to ``_EXAMPLES_DIR``.
    progress_callback : callable or None
        Called with ``(bytes_done, bytes_total)``; *total* may be 0.

    Returns
    -------
    Path
        The extracted example directory.
    """
    if name not in AVAILABLE_EXAMPLES:
        raise KeyError(
            f"Unknown example {name!r}; known: "
            f"{sorted(AVAILABLE_EXAMPLES)}")
    spec = AVAILABLE_EXAMPLES[name]
    url = _PACKAGE_URL_TEMPLATE.format(
        package=spec["package"], version=spec["version"])

    target = Path(target_dir) if target_dir else _EXAMPLES_DIR
    example_dir = target / name
    example_dir.mkdir(parents=True, exist_ok=True)

    logger.info("Downloading %s from %s", name, url)
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        with urllib.request.urlopen(url) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            done = 0
            with open(tmp_path, "wb") as f:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if progress_callback:
                        progress_callback(done, total)

        actual = _hash_file(tmp_path)
        expected = spec["sha256"]
        if actual != expected:
            raise ValueError(
                f"sha256 mismatch for {name} {spec['version']}: "
                f"expected {expected}, got {actual}.  The Generic "
                f"Package zip on GitLab differs from what this client "
                f"expects — re-publish or update AVAILABLE_EXAMPLES.")

        logger.info("Verified %s (%d bytes), extracting...", name, done)
        with zipfile.ZipFile(tmp_path) as zf:
            _safe_extract(zf, example_dir)

        logger.info("Example %r saved under %s", name, example_dir)
        return example_dir
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


def download_examples(names=None, target_dir=None, progress_callback=None):
    """Download every example (or a subset) into ``target_dir``.

    Parameters
    ----------
    names : iterable of str or None
        Names to download.  ``None`` means all entries in
        :data:`AVAILABLE_EXAMPLES`.
    target_dir : str or Path or None
        Defaults to ``_EXAMPLES_DIR``.
    progress_callback : callable or None
        Receives ``(name, bytes_done, bytes_total)`` so the caller can
        render a per-example progress bar.

    Returns
    -------
    list of Path
        Extracted example directories.
    """
    todo = list(names) if names is not None else list(AVAILABLE_EXAMPLES)
    extracted = []
    for name in todo:
        if progress_callback:
            cb = lambda d, t, _n=name: progress_callback(_n, d, t)
        else:
            cb = None
        extracted.append(download_example(
            name, target_dir=target_dir, progress_callback=cb))
    return extracted


# ── CLI entry point ────────────────────────────────────────────────────

def _cli_main():
    """CLI: ``python -m ide4eeg.download_examples [name ...]``."""
    import sys
    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s: %(message)s")

    names = sys.argv[1:] or None

    def _progress(name, done, total):
        if total > 0:
            pct = done * 100 / total
            mb = done / 1_048_576
            print(f"\r  {name}: {pct:5.1f}%  ({mb:.1f} MB)",
                  end="", flush=True)

    try:
        paths = download_examples(names=names, progress_callback=_progress)
        print()
        if paths:
            from ide4eeg import OUTPUT_DIR_PREFIX
            print(f"Examples saved under: {_EXAMPLES_DIR}")
            print(f"Pipeline outputs for these examples will land in "
                  f"`<example>/{OUTPUT_DIR_PREFIX}<config>/` next to "
                  f"the signal files.")
            for path in paths:
                print("  →", path)
        print("Done.")
    except Exception as e:
        print()
        logger.error("Download failed: %s", e)
        raise SystemExit(1)


if __name__ == "__main__":
    _cli_main()
