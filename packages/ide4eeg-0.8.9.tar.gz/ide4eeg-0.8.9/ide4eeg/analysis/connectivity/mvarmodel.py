# -*- coding: utf-8 -*-

import logging

import numpy as np
from .mvar.fitting import *


# Module-level sentinel: emit at most one warning per
# (criterion, chosen, p_max) tuple per process.  Without this,
# bootstrap / surrogate / short-time loops produce hundreds of
# identical "MVAR boundary hit" warnings that drown the log.
_ORDER_WARN_SEEN = set()


def _warn_order_choice(crit, criterion_name):
    """Warn when the auto-chosen MVAR order is unreliable.

    Two failure modes the user should know about:
      1. Boundary hit — the criterion picked order=1 or order=p_max,
         meaning the search range was too narrow; the true optimum is
         likely outside and the user should re-run with a wider p_max.
      2. Degenerate scores — every value in ``crit`` is non-finite or
         identical (within float tolerance), which typically means
         the data is rank-deficient and ``slogdet`` returned -inf for
         every fit; the chosen order is effectively arbitrary.
    """
    p_max = len(crit)
    if not np.all(np.isfinite(crit)) or np.allclose(crit, crit[0]):
        key = ("degenerate", criterion_name, p_max)
        if key not in _ORDER_WARN_SEEN:
            _ORDER_WARN_SEEN.add(key)
            logging.warning(
                "Connectivity: MVAR %s scores are degenerate "
                "(non-finite or identical across orders 1..%d) — the "
                "auto-chosen order is unreliable, likely due to a "
                "rank-deficient signal.",
                criterion_name, p_max)
        return
    chosen = int(np.argmin(crit)) + 1
    if chosen == 1 or chosen == p_max:
        key = ("boundary", criterion_name, chosen, p_max)
        if key not in _ORDER_WARN_SEEN:
            _ORDER_WARN_SEEN.add(key)
            logging.warning(
                "Connectivity: MVAR %s picked order=%d (search range "
                "was 1..%d) — boundary hit suggests the true optimum "
                "is outside this range; consider re-running with a "
                "larger p_max.",
                criterion_name, chosen, p_max)


class Mvar(object):
    """
    Static class *Mvar* to multivariete autoregressive model
    fitting. Possible methods are in *fitting_algorithms* where key is
    acronym of algorithm and value is a function from *mvar.fitting*.
    """

    fit_dict = fitting_algorithms

    @classmethod
    def fit(cls, data, order=None, method='yw'):
        """
        Mvar model fitting.
        Args:
          *data* : numpy.array
              array with data shaped (k, N), k - channels nr,
              N-data points)
          *order* = None : int
              model order, when default None it estimates order using
              akaike order criteria.
          *method* = 'yw': str
              name of mvar fitting algorithm, default Yule-Walker
              all avaiable methods you can find in *fitting_algorithms*
        Returns:
          *Av* : numpy.array
              model coefficients (kXkXorder)
          *Vf* : numpy.array
              reflection matrix (kXk)
        """
        if order is None:
            order, crit_val = cls.order_hq(data, p_max=None, method=method)
        return cls.fit_dict[method](data, order)

    @classmethod
    def order_akaike(cls, data, p_max=None, method='yw'):
        """
        Akaike criterion of MVAR order estimation.

        Args:
          *data* : numpy.array
              multichannel data in shape (k, n) for one trial case and
              (k, n, tr) for multitrial
              k - nr of channels, n -data points, tr - nr of trials
          *p_max* = 5 : int
              maximal model order
          *method* = 'yw' : str
              name of the mvar calculation method
        Returns:
          *best_order* : int
              minimum of *crit* array
          *crit* : numpy.array
              order criterion values for each value of order *p*
              starting from 1
        References:
        .. [1] Blinowska K. J., Zygierewicz J., (2012) Practical
               biomedical signal analysis using MATLAB.
               Boca Raton: Taylor & Francis.
        """
        if data.ndim > 2:
            chn, N, _ = data.shape
        else:
            chn, N = data.shape
        if p_max is None:
            p_max = 5  # change to some criterion for max
        crit = np.zeros(p_max)
        for p in range(p_max):
            (a_coef, v_r) = cls.fit(data, p+1, method)
            _sign, _logdet = np.linalg.slogdet(v_r)
            crit[p] = N*_logdet+2.*((p+1)*chn*(1+chn))
        _warn_order_choice(crit, "Akaike")
        return np.argmin(crit)+1, crit

    @classmethod
    def order_hq(cls, data, p_max=None, method='yw'):
        """
        Hannan-Quin criterion of MVAR order estimation.

        Args:
          *data* : numpy.array
              multichannel data in shape (k, n) for one trial case and
              (k, n, tr) for multitrial
              k - nr of channels, n -data points, tr - nr of trials
          *p_max* = 5 : int
              maximal model order
          *method* = 'yw' : str
              name of the mvar calculation method
        Returns:
          *best_order* : int
              minimum of *crit* array
          *crit* : numpy.array
              order criterion values for each value of order *p*
              starting from 1
        References:
        .. [1] Blinowska K. J., Zygierewicz J., (2012) Practical
               biomedical signal analysis using MATLAB.
               Boca Raton: Taylor & Francis.
        """
        if data.ndim > 2:
            chn, N, _ = data.shape
        else:
            chn, N = data.shape
        if p_max is None:
            p_max = 5
        crit = np.zeros(p_max)
        for p in range(p_max):
            (a_coef, v_r) = cls.fit(data, p+1, method)
            _sign, _logdet = np.linalg.slogdet(v_r)
            crit[p] = _logdet+2.*np.log(np.log(N))*(p+1)*chn**2/N
        _warn_order_choice(crit, "Hannan-Quinn")
        return np.argmin(crit)+1, crit

    @classmethod
    def order_schwartz(cls, data, p_max=None, method='yw'):
        """
        Schwartz criterion of MVAR order estimation.

        Args:
          *data* : numpy.array
              multichannel data in shape (k, n) for one trial case and
              (k, n, tr) for multitrial
              k - nr of channels, n -data points, tr - nr of trials
          *p_max* = 5 : int
              maximal model order
          *method* = 'yw' : str
              name of the mvar calculation method
        Returns:
          *best_order* : int
              minimum of *crit* array
          *crit* : numpy.array
              order criterion values for each value of order *p*
              starting from 1
        References:
        .. [1] Blinowska K. J., Zygierewicz J., (2012) Practical
               biomedical signal analysis using MATLAB.
               Boca Raton: Taylor & Francis.
        """
        if data.ndim > 2:
            chn, N, _ = data.shape
        else:
            chn, N = data.shape
        if p_max is None:
            p_max = 5
        crit = np.zeros(p_max)
        for p in range(p_max):
            (a_coef, v_r) = cls.fit(data, p+1, method)
            _sign, _logdet = np.linalg.slogdet(v_r)
            crit[p] = _logdet+np.log(N)*(p+1)*chn**2/N
        _warn_order_choice(crit, "Schwartz")
        return np.argmin(crit)+1, crit

    @classmethod
    def order_fpe(cls, data, p_max=None, method='yw'):
        """
        Final Prediction Error criterion of MVAR order estimation.
        (not recommended)
        Args:
          *data* : numpy.array
              multichannel data in shape (k, n) for one trial case and
              (k, n, tr) for multitrial
              k - nr of channels, n -data points, tr - nr of trials
          *p_max* = 5 : int
              maximal model order
          *method* = 'yw' : str
              name of the mvar calculation method
        Returns:
          *best_order* : int
              minimum of *crit* array
          *crit* : numpy.array
              order criterion values for each value of order *p*
              starting from 1
        References:
        .. [1] Akaike H, (1970), Statistical predictor identification,
               Ann. Inst. Statist. Math., 22 203–217.
        """
        if data.ndim > 2:
            chn, N, _ = data.shape
        else:
            chn, N = data.shape
        if p_max is None:
            p_max = 5
        crit = np.zeros(p_max)
        for p in range(p_max):
            (a_coef, v_r) = cls.fit(data, p+1, method)
            crit[p] = np.linalg.det(v_r) + chn*np.log((N+chn*(p+1)+1)/(N-chn*(p+1)-1))
        _warn_order_choice(crit, "FPE")
        return np.argmin(crit)+1, crit
