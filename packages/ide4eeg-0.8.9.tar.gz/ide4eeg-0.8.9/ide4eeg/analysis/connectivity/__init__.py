# -*- coding: utf-8 -*-
"""Brain connectivity analysis based on ConnectiviPy.

Original authors: Dominik Krzemiński, Maciej Kamiński (University of Warsaw).
Developed during Google Summer of Code 2015 under the International
Neuroinformatics Coordinating Facility (INCF).
https://github.com/dokato/connectivipy
Integrated into IDE4EEG for EEG connectivity estimation.
"""

from .data import Data
from .conn import conn_estim_dc
from .mvarmodel import Mvar
from .mvar.fitting import mvar_gen, mvar_gen_inst, fitting_algorithms

__all__ = [
    "Data", "conn_estim_dc", "Mvar",
    "mvar_gen", "mvar_gen_inst", "fitting_algorithms",
]
