"""Core dipole fitting routines.

Adapted from mp-dip by Marian Dovgialo and Piotr Biegański:
  - multivariate_atom_analysis.py  (amplitude_signs, example_to_dipole)
  - cortical_distance.py           (calculate_cortical_distance)
"""

import logging
import os
import sqlite3
from joblib import Parallel, delayed
from ide4eeg.utils.parallel import timed_parallel_block
import numpy as np
from ide4eeg.analysis.dipole.lut import get_lut
from ide4eeg.analysis.mp_analysis import atom_p2p_uV


try:
    import mne
    from mne import fit_dipole, create_info, EvokedArray, make_ad_hoc_cov
    _HAS_MNE = True
except ImportError:
    _HAS_MNE = False

try:
    import nibabel
    from scipy.spatial import KDTree
    _HAS_NIBABEL = True
except ImportError:
    _HAS_NIBABEL = False


def _ensure_fsaverage(fs_dir):
    """Resolve fsaverage directory, downloading if needed with logging.

    On first run this hits the MNE CDN; on no-network the underlying
    ``mne.datasets.fetch_fsaverage`` raises ``urllib.error.URLError``
    or ``RuntimeError``.  Re-raise as a ``RuntimeError`` with an
    actionable remediation hint so the user can see *why* their dipole
    or source-estimation analysis failed.
    """
    if fs_dir is not None:
        return fs_dir
    if not _HAS_MNE:
        return None
    logging.info("Fetching fsaverage template brain "
                 "(will download ~30 MB on first run)...")
    try:
        path = mne.datasets.fetch_fsaverage(verbose="ERROR")
    except Exception as exc:
        raise RuntimeError(
            "Failed to fetch fsaverage template brain. This is the "
            "first network call for dipole / source-estimation "
            "analyses; ~30 MB is downloaded into ~/mne_data/ on "
            "first run.\n\n"
            f"Underlying error: {exc.__class__.__name__}: {exc}\n\n"
            "Workarounds:\n"
            "  - Retry once you have network access.\n"
            "  - If a previous run was interrupted, delete the\n"
            "    partial cache at ~/mne_data/MNE-fsaverage-data/\n"
            "    and retry.\n"
            "  - Set dipole_fitting.fsaverage_dir to a manually-\n"
            "    placed FreeSurfer subjects-dir to bypass the\n"
            "    download entirely."
        ) from exc
    logging.info("fsaverage ready: %s", path)
    return path


# ── Atom reading ────────────────────────────────────────────────────────


def read_macroatoms(book_path, n_channels):
    """Read MMP atoms from an empi book and group into macroatoms.

    A *macroatom* groups all channels for the same (segment, iteration).

    Parameters
    ----------
    book_path : str
        Path to empi SQLite ``.db`` file.
    n_channels : int
        Number of channels in the decomposition.

    Returns
    -------
    macroatoms : list of dict
        Each dict has keys: segment_id, iteration, channels (list of
        per-channel dicts with amplitude, f_Hz, phase, scale_s, t0_s,
        energy, channel_id).
    segment_length : float
        Segment length in seconds (from book metadata).
    """
    conn = sqlite3.connect(book_path)
    conn.row_factory = sqlite3.Row

    try:
        seg_len = float(conn.execute(
            "SELECT segment_length_s FROM segments LIMIT 1"
        ).fetchone()[0])
    except (TypeError, sqlite3.OperationalError):
        seg_len = 0.0

    rows = conn.execute(
        "SELECT channel_id, iteration, energy, amplitude, "
        "t0_s, scale_s, f_Hz, phase, segment_id "
        "FROM atoms WHERE envelope='gauss' "
        "ORDER BY segment_id, iteration, channel_id"
    ).fetchall()
    conn.close()

    # Group by (segment_id, iteration)
    groups = {}
    for r in rows:
        key = (r["segment_id"], r["iteration"])
        if key not in groups:
            groups[key] = []
        groups[key].append({
            "channel_id": r["channel_id"],
            "amplitude": r["amplitude"],
            "energy": r["energy"],
            "f_Hz": r["f_Hz"],
            "phase": r["phase"],
            "scale_s": r["scale_s"],
            "t0_s": r["t0_s"] + seg_len * r["segment_id"],
        })

    macroatoms = []
    for (seg_id, iteration), channels in sorted(groups.items()):
        if len(channels) != n_channels:
            continue
        channels.sort(key=lambda c: c["channel_id"])
        macroatoms.append({
            "segment_id": seg_id,
            "iteration": iteration,
            "channels": channels,
        })

    return macroatoms, seg_len


# ── Amplitude sign determination ────────────────────────────────────────


def _weighted_circmean(angles, weights):
    """Weighted circular mean: atan2(Σ wᵢ sin(θᵢ), Σ wᵢ cos(θᵢ))."""
    return np.arctan2(
        np.sum(weights * np.sin(angles)),
        np.sum(weights * np.cos(angles)))


def amplitude_signs(amplitudes, phases):
    """Determine sign of each channel's contribution to a macroatom.

    Uses the weighted circular mean of phases to find the dominant
    oscillation direction, then assigns +1/-1 to each channel based
    on which side of the perpendicular it falls on.

    Parameters
    ----------
    amplitudes : ndarray, shape (n_channels,)
    phases : ndarray, shape (n_channels,)

    Returns
    -------
    signs : ndarray of +1/-1, shape (n_channels,)
    """
    weights = amplitudes / np.sum(amplitudes) * len(amplitudes)
    dominant = _weighted_circmean(phases, weights)
    separating = (dominant + np.pi / 2) % (2 * np.pi)
    rotated = (phases - separating) % (2 * np.pi)
    signs = np.where((rotated > 0) & (rotated <= np.pi), 1, -1)
    return signs


# ── Single macroatom → dipole ──────────────────────────────────────────


def fit_macroatom_dipole(macroatom, ch_names, sfreq,
                         ref_channel="average",
                         montage="standard_1005",
                         fs_dir=None):
    """Fit a single dipole to one macroatom.

    Parameters
    ----------
    macroatom : dict
        As returned by ``read_macroatoms``.
    ch_names : list of str
        EEG channel names matching channel_id order.
    sfreq : float
        Sampling frequency in Hz.
    ref_channel : str
        Reference channel(s), comma-separated, or ``"average"``.
    montage : str
        MNE montage name (default: ``"standard_1005"``).
    fs_dir : str or None
        Path to fsaverage directory.  If None, downloaded via
        ``mne.datasets.fetch_fsaverage()``.

    Returns
    -------
    result : dict or None
        Keys: pos (3,), gof (float), amplitude (float),
        ori (3,), frequency, scale, t0.
        None if fitting fails.
    """
    if not _HAS_MNE:
        logging.error("Dipole fitting requires MNE-Python.")
        return None

    if fs_dir is None:
        fs_dir = _ensure_fsaverage(fs_dir)

    bem_file = os.path.join(fs_dir, "bem",
                            "fsaverage-5120-5120-5120-bem-sol.fif")
    trans_file = os.path.join(fs_dir, "bem", "fsaverage-trans.fif")

    if not os.path.isfile(bem_file) or not os.path.isfile(trans_file):
        logging.error("fsaverage BEM/trans files not found in %s", fs_dir)
        return None

    channels = macroatom["channels"]
    amplitudes = np.array([c["amplitude"] for c in channels])
    phases = np.array([c["phase"] for c in channels])

    # Determine reference channels to add
    if ref_channel == "average":
        ref_channels = []
    else:
        ref_channels = [r.strip() for r in ref_channel.split(",")
                        if r.strip()]
    missing = [r for r in ref_channels if r not in ch_names]
    all_ch = list(ch_names) + missing

    info = create_info(all_ch, sfreq, ch_types="eeg", verbose="CRITICAL")
    # MNE fit_dipole requires a device-to-head transform; for EEG-only
    # data an identity transform is appropriate.
    info["dev_head_t"] = mne.transforms.Transform("meg", "head")

    signs = amplitude_signs(amplitudes, phases)
    n_missing = len(missing)
    data = np.concatenate([
        amplitudes * signs,
        np.zeros(n_missing)
    ])[:, None] * 1e-6  # convert µV to V

    evoked = EvokedArray(data, info, verbose="CRITICAL")

    if len(ref_channels) == 0:
        evoked.set_eeg_reference("average", verbose="CRITICAL")
    else:
        evoked.set_eeg_reference(ref_channels, verbose="CRITICAL")

    evoked.set_montage(montage, on_missing="warn", verbose="CRITICAL")
    cov = make_ad_hoc_cov(info)

    try:
        dip, _ = fit_dipole(evoked, cov, bem_file,
                            trans=trans_file, verbose="CRITICAL",
                            min_dist=0, tol=5e-3)
    except Exception as exc:
        logging.debug("Dipole fit failed for iteration %d: %s",
                      macroatom["iteration"], exc)
        return None

    # Use the strongest channel for frequency/scale metadata
    strongest = int(np.argmax(amplitudes))
    ch = channels[strongest]

    return {
        "pos": dip.pos[0],
        "gof": dip.gof[0],
        "amplitude": dip.amplitude[0] * 1e9,  # nAm
        "ori": dip.ori[0],
        "frequency": ch["f_Hz"],
        "scale": ch["scale_s"],
        "t0": ch["t0_s"],
        "segment_id": macroatom["segment_id"],
        "iteration": macroatom["iteration"],
    }


# ── Batch fitting ───────────────────────────────────────────────────────

def fitting_func(macroatom, ch_names, sfreq, ref_channel, montage, fs_dir, min_gof):
    result = fit_macroatom_dipole(
        macroatom, ch_names, sfreq,
        ref_channel=ref_channel,
        montage=montage,
        fs_dir=fs_dir)
    if result is not None and result["gof"] >= min_gof:
        return result


def fit_all_dipoles(book_path, ch_names, sfreq,
                    n_book_channels=None,
                    keep_channel_indices=None,
                    ref_channel="average",
                    montage="standard_1005",
                    max_iterations=None,
                    min_gof=0.0,
                    fs_dir=None,
                    progress_callback=None,
                    picked_atoms=None,
                    freq_range=None,
                    scale_range=None,
                    amp_range=None,
                    cancel_event=None):
    """Fit dipoles to all macroatoms in an MMP book.

    Parameters
    ----------
    book_path : str
    ch_names : list of str
        EEG channel names to use for fitting (after filtering).
    sfreq : float
    n_book_channels : int or None
        Total number of channels in the book.  If None, defaults to
        ``len(ch_names)`` (all channels are EEG).
    keep_channel_indices : list of int or None
        Indices (into the book's channel list) to keep for fitting.
        If None, all channels are kept.
    ref_channel : str
    montage : str
    max_iterations : int or None
        Only fit the first N iterations per segment.
    min_gof : float
        Minimum goodness-of-fit to include in results.
    fs_dir : str or None
    progress_callback : callable or None
        Called with (current, total) for progress reporting.
    picked_atoms : list of dict or None
        If given, only fit macroatoms whose (segment_id, iteration)
        matches one of the picked atoms. Overrides freq/scale filters.
    freq_range : tuple of (min, max) or None
        Filter atoms by frequency. 0 = no limit on that end.
    scale_range : tuple of (min, max) or None
        Filter atoms by scale. 0 = no limit on that end.
    amp_range: tuple of (min, max) or None
        Filter atoms by amplitude. 0 = no limit on that end.

    Returns
    -------
    results : list of dict
        One dict per successfully fitted macroatom.
    """
    # Read channel_count + scale_to_uV from book metadata in one pass.
    # scale_to_uV: 1.0 for µV-native books (IDE4EEG ≥ 0.8.7), 1e6 for
    # legacy V-scale books — without this read, amp_range filters
    # silently drop every atom from old books.
    try:
        with sqlite3.connect(book_path) as _conn:
            _meta = dict(_conn.execute(
                "SELECT param, value FROM metadata"))
        if n_book_channels is None:
            n_book_channels = int(_meta.get("channel_count",
                                            len(ch_names)))
        scale_to_uV = float(_meta.get("scale_to_uV", 1.0))
    except (sqlite3.Error, ValueError):
        if n_book_channels is None:
            n_book_channels = len(ch_names)
        scale_to_uV = 1.0
    macroatoms, _ = read_macroatoms(book_path, n_book_channels)

    # Strip non-EEG channels from each macroatom
    if keep_channel_indices is not None:
        keep_set = set(keep_channel_indices)
        for ma in macroatoms:
            ma["channels"] = [c for c in ma["channels"]
                              if c["channel_id"] in keep_set]

    if max_iterations:
        macroatoms = [m for m in macroatoms
                      if m["iteration"] < max_iterations]

    # Apply atom selection: picked atoms override frequency/scale filters
    if picked_atoms:
        picked_keys = {(a.get("segment_id", 0), a["iteration"])
                       for a in picked_atoms}
        macroatoms = [m for m in macroatoms
                      if (m["segment_id"], m["iteration"]) in picked_keys]
        logging.info("Filtered to %d macroatoms from manual selection.",
                     len(macroatoms))
    else:
        # Apply frequency/scale filters using the strongest channel's params
        def _dominant(m):
            """Get f_Hz and scale_s from the strongest channel."""
            chs = m.get("channels", [])
            if not chs:
                return 0.0, 0.0
            best = max(chs, key=lambda c: abs(c.get("amplitude", 0)))
            return (best.get("f_Hz", 0.0),
                    best.get("scale_s", 0.0),
                    atom_p2p_uV(best, scale_to_uV))

        if freq_range:
            fmin, fmax = freq_range
            if fmin > 0:
                macroatoms = [m for m in macroatoms
                              if _dominant(m)[0] >= fmin]
            if fmax > 0:
                macroatoms = [m for m in macroatoms
                              if _dominant(m)[0] <= fmax]
        if scale_range:
            smin, smax = scale_range
            if smin > 0:
                macroatoms = [m for m in macroatoms
                              if _dominant(m)[1] >= smin]
            if smax > 0:
                macroatoms = [m for m in macroatoms
                              if _dominant(m)[1] <= smax]
        if amp_range:
            amin, amax = amp_range
            if amin > 0:
                macroatoms = [m for m in macroatoms
                              if _dominant(m)[2] >= amin]
            if amax > 0:
                macroatoms = [m for m in macroatoms
                              if _dominant(m)[2] <= amax]

    # Pre-resolve fsaverage once (avoids repeated fetch per atom)
    if fs_dir is None:
        fs_dir = _ensure_fsaverage(fs_dir)

    results = []
    total = len(macroatoms)
    logging.info("Fitting dipoles to %d macroatoms...", total)
    log_step = max(1, total // 20)  # log every ~5%

    with timed_parallel_block("dipole-fit", cancel_event):
        parallel_gen = Parallel(return_as="generator", verbose=0)(
            delayed(fitting_func)(
                ma, ch_names, sfreq, ref_channel, montage,
                fs_dir, min_gof
            )
            for ma in macroatoms
        )
        try:
            for i, result in enumerate(parallel_gen):
                if cancel_event is not None and cancel_event.is_set():
                    raise InterruptedError("Dipole fit cancelled byb user")
                if progress_callback:
                    progress_callback(i, total)
                if i % log_step == 0 or i == total - 1:
                    logging.info(
                        "Dipole fitting: %d/%d (%.0f%%), %d fitted so far",
                        i + 1, total, (i + 1) / total * 100, len(results))
                if result is not None:
                    results.append(result)
        except Exception as exc:
            logging.error("Dipole fitting failed: %s", exc)
            raise exc
        finally:
            try:
                parallel_gen.close()
            except:
                pass


    logging.info("Fitted %d dipoles (of %d macroatoms, min GOF=%.0f%%)",
                 len(results), total, min_gof)
    return results


# ── Cortical distance (optional, requires nibabel) ──────────────────────


def _load_cortical_voxels(fs_dir):
    """Load cortical voxel positions from fsaverage parcellation.

    Returns
    -------
    cortex_positions : ndarray, shape (N, 3)
        MNI coordinates of cortical voxels.
    kdtree : KDTree
    """
    if not _HAS_NIBABEL:
        raise ImportError("nibabel required for cortical distance")

    subjects_dir = os.path.join(fs_dir, "..")
    parc_path = os.path.join(
        subjects_dir, "fsaverage", "mri", "aparc.a2005s+aseg.mgz")

    if not os.path.isfile(parc_path):
        raise FileNotFoundError(f"Parcellation not found: {parc_path}")

    lut_inv = get_lut()

    parc_img = nibabel.load(parc_path)
    parc_data = parc_img.get_fdata()

    cortical_keys = [k for k in lut_inv.keys() if k.startswith("ctx-")]
    cortical_keys += ["Left-Cerebral-Cortex", "Right-Cerebral-Cortex"]
    cortex_values = [lut_inv[k] for k in cortical_keys
                        if k in lut_inv]

    mask = np.isin(parc_data, cortex_values)
    cortex_ijk = np.argwhere(mask)

    if cortex_ijk.size == 0:
        # FreeSurferColorLUT.txt is missing from the MNE-downloaded
        # fsaverage — fall back to using all non-zero parcellation
        # voxels as an approximation of the cortical surface.
        logging.warning(
            "No cortical labels found in parcellation "
            "(FreeSurferColorLUT.txt may be missing). "
            "Falling back to all labelled voxels.")
        mask = parc_data > 0
        cortex_ijk = np.argwhere(mask)
        if cortex_ijk.size == 0:
            raise FileNotFoundError(
                "Parcellation contains no labelled voxels")

    vox2ras = parc_img.header.get_vox2ras_tkr()
    cortex_mni = mne.transforms.apply_trans(vox2ras, cortex_ijk)

    return cortex_mni, KDTree(cortex_mni)


def _fsaverage_transform(fs_dir=None):
    """Return ``(transform, subjects_dir)`` for the fsaverage template.

    Shared by :func:`compute_cortical_distances` and
    :func:`visualize._head_to_mni` so the 3-line ``fs_dir`` →
    ``subjects_dir`` → ``mne.read_trans`` pattern lives in one place.
    """
    if fs_dir is None:
        fs_dir = _ensure_fsaverage(fs_dir)
    subjects_dir = os.path.join(fs_dir, "..")
    trans_path = os.path.join(fs_dir, "bem", "fsaverage-trans.fif")
    transform = mne.read_trans(trans_path, return_all=False)
    return transform, subjects_dir


def compute_cortical_distances(results, fs_dir=None):
    """Add cortical distance to each dipole result.

    Modifies *results* in-place, adding key ``cortex_dist_mm``.

    Parameters
    ----------
    results : list of dict
        From ``fit_all_dipoles``.
    fs_dir : str or None
    """
    if not _HAS_NIBABEL:
        logging.warning(
            "nibabel not installed — skipping cortical distance.")
        return

    if fs_dir is None:
        fs_dir = _ensure_fsaverage(fs_dir)

    try:
        cortex_mni, kdtree = _load_cortical_voxels(fs_dir)
    except (FileNotFoundError, ImportError) as exc:
        logging.warning("Cannot compute cortical distance: %s", exc)
        return

    transform, subjects_dir = _fsaverage_transform(fs_dir)

    positions = np.array([r["pos"] for r in results])
    if positions.size == 0:
        return

    mni_pos = mne.head_to_mni(
        positions, "fsaverage", transform,
        subjects_dir=subjects_dir, verbose=None)

    dists, indices = kdtree.query(mni_pos)

    # Sign: negative = inside cortex (dipole closer to center than cortex)
    dip_dist_center = np.linalg.norm(mni_pos, axis=1)
    cortex_nn = cortex_mni[indices]
    cortex_dist_center = np.linalg.norm(cortex_nn, axis=1)
    sign = np.sign(cortex_dist_center - dip_dist_center)
    sign[sign == 0] = 1

    for i, r in enumerate(results):
        r["cortex_dist_mm"] = float(dists[i] * sign[i])
