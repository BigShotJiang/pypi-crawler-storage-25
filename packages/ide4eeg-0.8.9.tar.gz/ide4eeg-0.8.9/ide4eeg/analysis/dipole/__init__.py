"""Dipole fitting for Multivariate Matching Pursuit atoms.

Fits equivalent current dipoles to MMP macroatoms using MNE-Python
and the fsaverage template brain.  Optionally computes the distance
from each fitted dipole to the nearest cortical voxel.

Adapted from mp-dip (Piotr Durka, University of Warsaw).
"""
