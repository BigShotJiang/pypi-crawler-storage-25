"""Advanced dipole visualization with brain template overlays.

Produces publication-quality scatter plots of dipole positions on
anatomical brain projections (axial, coronal, sagittal), optionally
color-coded by frequency or structure type.

Brain images from the Julich-Brain Cytoarchitectonic Atlas (v2.9),
Amunts et al. (2021), licensed CC BY-NC-SA 4.0.

Adapted from mp-dip by Marian Dovgialo and Piotr Biegański.
"""

import logging
import os

import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
import numpy as np
from typing import Literal

from .fitting import _ensure_fsaverage


_HAS_MNE = False
try:
    import mne
    _HAS_MNE = True
except ImportError:
    pass


def _head_to_mni(positions, fs_dir=None):
    """Convert MNE HEAD positions (meters) to MNI coordinates (mm).

    Uses the fsaverage HEAD→MRI transform and FreeSurfer's MRI→MNI
    mapping.  Returns an (N, 3) ndarray in MNI mm.
    """
    from .fitting import _fsaverage_transform
    transform, subjects_dir = _fsaverage_transform(fs_dir)
    return mne.head_to_mni(
        np.atleast_2d(positions), "fsaverage", transform,
        subjects_dir=subjects_dir, verbose=False)


def export_dipoles_connectivis(results, dat_path, fs_dir=None):
    """Export dipole results to ConnectiVIS .dat format.

    Dipole positions are converted from MNE HEAD coordinates
    (meters) to MNI coordinates (mm) — the same coordinate
    system used by the fsaverage brain PLY exported by
    :func:`export_fsaverage_brain_ply`.  ConnectiVIS renders
    both in the same space, so dipoles land on the correct
    anatomical locations.
    """
    if not results:
        return

    positions = np.array([r["pos"] for r in results])
    mni_positions = _head_to_mni(positions, fs_dir)

    lines = ["0.0"]
    for r, mni_pos in zip(results, mni_positions):
        px, py, pz = mni_pos
        ori = r["ori"]
        dir_scale = max(min(r["amplitude"] * 2, 3), 1)
        dx = ori[0] * dir_scale
        dy = ori[1] * dir_scale
        dz = ori[2] * dir_scale
        color = "0xAAFFCC00"
        lines.append(f"{px:.4f} {py:.4f} {pz:.4f} "
                     f"{dx:.4f} {dy:.4f} {dz:.4f} {color}")

    with open(dat_path, "w") as f:
        f.write("\r\n".join(lines) + "\r\n")
    logging.info("Dipole connectivis: %d dipoles in MNI mm → %s",
                 len(results), dat_path)


from ide4eeg.download_tools import CONNECTIVIS_DIR as _CONNECTIVIS_DIR
_CONNECTIVIS_DIR = str(_CONNECTIVIS_DIR)


def _cached_fsaverage_ply(name, export_fn, **kwargs):
    """Return the path to a cached fsaverage PLY in ~/.obci/connectivis/.

    Exports the file on first call; subsequent calls return the
    cached path immediately.
    """
    os.makedirs(_CONNECTIVIS_DIR, exist_ok=True)
    path = os.path.join(_CONNECTIVIS_DIR, name)
    if not os.path.isfile(path):
        export_fn(path, **kwargs)
    return path


def fsaverage_brain_ply_path(fs_dir=None, atlas="aparc"):
    """Return the cached fsaverage brain PLY path, exporting if needed."""
    return _cached_fsaverage_ply(
        f"fsaverage_brain_{atlas}.ply",
        export_fsaverage_brain_ply, fs_dir=fs_dir, atlas=atlas)


def fsaverage_head_ply_path(fs_dir=None):
    """Return the cached fsaverage head PLY path, exporting if needed."""
    return _cached_fsaverage_ply(
        "fsaverage_head.ply",
        export_fsaverage_head_ply, fs_dir=fs_dir)


def export_fsaverage_brain_ply(ply_path, fs_dir=None, atlas="aparc"):
    """Export fsaverage pial surface as a PLY with per-vertex colors.

    The PLY file contains both hemispheres of the fsaverage pial
    surface (folded cortex), colored by the Desikan-Killiany
    (``aparc``) or Destrieux (``aparc.a2009s``) parcellation atlas.
    Coordinates are in FreeSurfer/MNI space (mm) — the same system
    used by :func:`export_dipoles_connectivis`.

    Parameters
    ----------
    ply_path : str
        Output file path.
    fs_dir : str or None
        fsaverage directory.  Auto-fetched if None.
    atlas : str
        ``"aparc"`` (36 regions) or ``"aparc.a2009s"`` (76 regions).
    """
    import nibabel.freesurfer as nfs

    if fs_dir is None:
        fs_dir = _ensure_fsaverage(None)

    all_verts = []
    all_faces = []
    all_colors = []
    vert_offset = 0

    for hemi in ("lh", "rh"):
        surf_path = os.path.join(fs_dir, "surf", f"{hemi}.pial")
        annot_path = os.path.join(fs_dir, "label", f"{hemi}.{atlas}.annot")

        verts, faces = nfs.read_geometry(surf_path)
        labels, ctab, names = nfs.read_annot(annot_path)

        colors = np.full((len(verts), 3), 180, dtype=np.uint8)
        valid = (labels >= 0) & (labels < len(ctab))
        colors[valid] = ctab[labels[valid], :3]

        all_verts.append(verts)
        all_faces.append(faces + vert_offset)
        all_colors.append(colors)
        vert_offset += len(verts)

    verts = np.vstack(all_verts)
    faces = np.vstack(all_faces)
    colors = np.vstack(all_colors)

    _write_ply(ply_path, verts, faces, colors)
    logging.info(
        "Exported fsaverage brain PLY: %d vertices, %d faces, "
        "atlas=%s → %s", len(verts), len(faces), atlas, ply_path)


def _write_ply(ply_path, verts, faces, colors):
    """Write a binary PLY with per-vertex RGB.

    All three surface exports (brain, head, etc.) share this writer.
    Coordinates are written as-is — the caller is responsible for
    ensuring a consistent coordinate frame (MNI mm for fsaverage).
    """
    n_verts = len(verts)
    n_faces = len(faces)
    with open(ply_path, "wb") as f:
        header = (
            f"ply\n"
            f"format binary_little_endian 1.0\n"
            f"element vertex {n_verts}\n"
            f"property float x\n"
            f"property float y\n"
            f"property float z\n"
            f"property uchar red\n"
            f"property uchar green\n"
            f"property uchar blue\n"
            f"element face {n_faces}\n"
            f"property list uchar int vertex_indices\n"
            f"end_header\n"
        )
        f.write(header.encode("ascii"))
        vert_data = np.empty(n_verts,
                             dtype=[("xyz", "<f4", 3), ("rgb", "u1", 3)])
        vert_data["xyz"] = verts.astype("<f4")
        vert_data["rgb"] = colors.astype(np.uint8)
        f.write(vert_data.tobytes())
        face_data = np.empty(n_faces,
                             dtype=[("n", "u1"), ("idx", "<i4", 3)])
        face_data["n"] = 3
        face_data["idx"] = faces.astype("<i4")
        f.write(face_data.tobytes())


def export_fsaverage_head_ply(ply_path, fs_dir=None,
                               color=(220, 200, 180)):
    """Export fsaverage outer skin surface as a PLY.

    The head surface is in the same coordinate frame (FreeSurfer
    surface RAS / MNI mm for fsaverage) as the brain PLY and the
    dipole .dat, so ConnectiVIS renders everything consistently.

    Parameters
    ----------
    ply_path : str
        Output file path.
    fs_dir : str or None
        fsaverage directory.  Auto-fetched if None.
    color : tuple of int
        Uniform RGB skin color (default: warm flesh tone).
    """
    import nibabel.freesurfer as nfs

    if fs_dir is None:
        fs_dir = _ensure_fsaverage(None)

    # The BEM surfaces (outer_skin.surf, lh.seghead) are featureless
    # smooth ellipsoids — fsaverage is a 40-subject average where
    # individual facial features are literally averaged out.  The
    # marching-cubes approach captures some geometry but produces a
    # noisy surface with internal-tissue artefacts.
    #
    # For now, export lh.seghead as the best available option.
    # ConnectiVIS can fall back to its built-in AC3D head (which
    # has a face with nose/ears/neck) when --head-model is not
    # passed or when the PLY is unsatisfactory.
    for candidate in ("surf/lh.seghead", "bem/outer_skin.surf"):
        path = os.path.join(fs_dir, candidate)
        if os.path.isfile(path):
            verts, faces = nfs.read_geometry(path)
            break
    else:
        logging.error("No head surface found in %s", fs_dir)
        return

    colors = np.full((len(verts), 3), color, dtype=np.uint8)
    _write_ply(ply_path, verts, faces, colors)
    logging.info(
        "Exported fsaverage head PLY: %d vertices, %d faces → %s",
        len(verts), len(faces), ply_path)


def export_electrodes_dat(info, dat_path, fs_dir=None):
    """Export electrode positions in MNI mm to an ASCII .dat file.

    Reads the electrode positions from ``info['dig']`` (or
    ``info['chs']`` as fallback), converts from MNE HEAD
    coordinates (meters) to MNI mm via :func:`_head_to_mni`,
    and writes one line per electrode: ``name x y z``.

    The output is in the same coordinate frame as the brain PLY,
    head PLY, and dipole .dat — all MNI mm for fsaverage.

    Parameters
    ----------
    info : mne.Info
        The signal's info dict (must have a montage applied).
    dat_path : str
        Output file path.
    fs_dir : str or None
        fsaverage directory.
    """
    montage = info.get("dig")
    if not montage:
        logging.warning("No digitisation points in info — "
                        "skipping electrode export.")
        return

    eeg_picks = mne.pick_types(info, eeg=True, exclude=[])
    ch_names = []
    ch_positions = []
    for idx in eeg_picks:
        loc = info["chs"][idx]["loc"][:3]
        if np.any(np.isnan(loc)) or np.allclose(loc, 0):
            continue
        ch_names.append(info["ch_names"][idx])
        ch_positions.append(loc)

    if not ch_positions:
        logging.warning("No EEG channel positions found — "
                        "skipping electrode export.")
        return

    positions = np.array(ch_positions)
    mni_positions = _head_to_mni(positions, fs_dir)

    lines = [f"# Electrode positions in MNI mm (fsaverage)"]
    for name, pos in zip(ch_names, mni_positions):
        lines.append(f"{name} {pos[0]:.2f} {pos[1]:.2f} {pos[2]:.2f}")

    with open(dat_path, "w") as f:
        f.write("\n".join(lines) + "\n")
    logging.info("Exported %d electrode positions → %s",
                 len(ch_names), dat_path)


def plot_dipole_gof_histogram(results, save_path):
    """Plot histogram of dipole goodness-of-fit values."""
    gofs = [r["gof"] for r in results]

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(gofs, bins=50, color="#89b4fa", edgecolor="none", alpha=0.9)
    ax.set_xlabel("Goodness of Fit [%]")
    ax.set_ylabel("Count")
    ax.set_title(f"Dipole GOF distribution ({len(results)} dipoles)")
    ax.axvline(x=np.median(gofs), color="red", linestyle="--",
               label=f"median = {np.median(gofs):.1f}%")
    ax.legend()
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)


def scatter_3d(results, color_by: Literal['frequency', 'gof', 'amplitude'], save_path, fs_dir=None):
    if fs_dir is None:
        fs_dir = _ensure_fsaverage(fs_dir)

    subjects_dir = os.path.join(fs_dir, "..")
    trans_path = os.path.join(fs_dir, "bem", "fsaverage-trans.fif")
    transform = mne.read_trans(trans_path, return_all=False)

    dip_positions = np.array([i['pos']for i in results])
    dip_orientations = np.array([i['ori']for i in results])
    dip_gofs = np.array([i['gof']for i in results])
    dip_amps = np.array([i['amplitude']for i in results])
    times = np.zeros(len(dip_positions))
    dipoles = [mne.Dipole(times[i, None],
                          pos=dip_positions[i, None],
                          amplitude=dip_amps[i, None],
                          ori=dip_orientations[i, None],
                          gof=dip_gofs[i, None]) for i in range(len(times))]
    cmap = cm.viridis
    colored = [i[color_by] for i in results]
    minf = min(colored)
    maxf = max(colored)
    norm = Normalize(vmin=minf, vmax=maxf)
    colors = cmap(norm(colored))
    colors[:, 3] = 0.7
    mappable = ScalarMappable(norm=norm, cmap=cmap)
    mappable.set_array([])

    fig = mne.viz.plot_dipole_locations(dipoles, trans=transform, subject='fsaverage', subjects_dir=subjects_dir,
                                        mode='outlines', color=colors, width=0.015, scale=0.001, show=False)
    fig.set_size_inches((10, 5.5))

    cb_ax = fig.add_subplot(20, 4, 80)
    if color_by == 'frequency':
        label = "Frequency [Hz]"
    elif color_by == 'gof':
        label = "GoF [%]"
    else:
        label = "Amplitude [nAm]"

    plt.colorbar(mappable, cax=cb_ax, orientation='horizontal', label=label)
    plt.savefig(save_path, dpi=150)
    plt.close(fig)
