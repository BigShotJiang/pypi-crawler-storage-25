"""MNE analysis catalog — batch execution of MNE-Python functions.

Provides a catalog of MNE analysis/plotting functions that can be
executed within the IDE4EEG pipeline without custom wrapper code.
Each entry is a descriptor that specifies what to call, on what data,
and how to save the output.

The catalog is explicitly labeled as MNE's code — IDE4EEG provides
the data and calls MNE as documented.  We do not modify the algorithms.

Adding a new analysis = adding a dict entry to MNE_CATALOG.
"""

# Author: Piotr Durka / Claude, 2026

import logging
import os

import matplotlib.pyplot as plt
import numpy as np

from . import _safe_tag


# ── Catalog ──────────────────────────────────────────────────────────

# Each param dict supports an optional ``advanced: bool`` field
# (default False).  Advanced params render in a collapsed
# "Advanced" disclosure under the entry's main param row; their
# open/closed state persists per-entry in TOML under the
# ``mne_advanced_open`` table.

# Shared param spec for the "Save CSV" advanced toggle on every
# PSD-producing entry.  Each entry should splat this in via
# ``**_PSD_SAVE_CSV_PARAM`` rather than duplicating the dict literal.
_PSD_SAVE_CSV_PARAM = {
    "key": "save_csv", "label": "Save CSV", "type": "bool",
    "default": False, "advanced": True,
    "tooltip":
        "Also export the spectrum to a .csv file alongside\n"
        "the plot.",
}

# Y-axis scale choice for line-plot PSD entries (psd_multitaper,
# psd_welch).  ``Spectrum.plot()`` supports both ``dB`` and
# ``amplitude`` so the full three-way choice is available.
_PSD_SCALE_PLOT_PARAM = {
    "key": "scale", "label": "Scale", "type": "choice",
    "choices": ["dB", "power", "amplitude"],
    "default": "dB",
    "tooltip":
        "Y-axis scale:\n"
        "  dB        — log power (10·log10 µV²/Hz), typical PSD\n"
        "  power     — linear power (µV²/Hz)\n"
        "  amplitude — linear amplitude (µV/√Hz)",
}

# Color-scale choice for topographic PSD entries (psd_topomap,
# psd_topo).  ``plot_topomap`` and ``plot_topo`` don't have an
# ``amplitude`` parameter, so only the two-way choice is offered.
_PSD_SCALE_TOPO_PARAM = {
    "key": "scale", "label": "Scale", "type": "choice",
    "choices": ["dB", "power"],
    "default": "dB",
    "tooltip":
        "Color scale:\n"
        "  dB    — log power (10·log10 µV²/Hz)\n"
        "  power — linear power (µV²/Hz)",
}

MNE_CATALOG = [

    # ── ERP ──────────────────────────────────────────────────────
    {"id": "erp_butterfly", "name": "ERP butterfly", "category": "ERP",
     "description": "Grand-average ERP with spatial colors (one line per channel).",
     "input": "epochs", "requires": [], "params": [],
     "doc_url": "https://mne.tools/stable/generated/mne.Evoked.html#mne.Evoked.plot"},
    {"id": "erp_image", "name": "ERP image (per channel)", "category": "ERP",
     "description": "Heatmap of single-trial ERPs sorted by amplitude.",
     "input": "epochs", "requires": [], "params": [],
     "doc_url": "https://mne.tools/stable/generated/mne.Epochs.html#mne.Epochs.plot_image"},
    {"id": "erp_joint", "name": "ERP joint (topos at peaks)", "category": "ERP",
     "description": "Grand-average ERP with topographic maps at peak latencies.",
     "input": "epochs", "requires": ["montage"], "params": [],
     "doc_url": "https://mne.tools/stable/generated/mne.Evoked.html#mne.Evoked.plot_joint"},
    {"id": "erp_topomap", "name": "ERP topomap series", "category": "ERP",
     "description": "Sequence of topographic maps at evenly spaced time points.",
     "input": "epochs", "requires": ["montage"],
     "params": [
         {"key": "n_times", "label": "N time points", "type": "int",
          "default": 10, "tooltip": "Number of evenly spaced topomap snapshots."},
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.Evoked.html#mne.Evoked.plot_topomap"},
    {"id": "gfp", "name": "Global field power", "category": "ERP",
     "description": "GFP (std across channels) over time for each condition.",
     "input": "epochs", "requires": [], "params": [],
     "doc_url": "https://mne.tools/stable/auto_tutorials/evoked/30_eeg_erp.html"},
    {"id": "cluster_permutation", "name": "Cluster permutation test", "category": "ERP",
     "description": "Spatio-temporal cluster permutation test between conditions "
                    "(requires 2+ event types).",
     "input": "epochs", "requires": ["multi_tag"],
     "params": [
         {"key": "step_down_p", "label": "Step-down p", "type": "float",
          "default": 0.05, "tooltip": "P-value threshold for step-down-in-jumps."},
         {"key": "n_permutations", "label": "N permutations", "type": "int",
          "default": 1024, "tooltip": "Number of permutations (more = slower but more accurate)."},
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.stats.spatio_temporal_cluster_test.html"},

    # ── Spectra ─────────────────────────────────────────────────
    {"id": "psd_topomap", "name": "PSD topomap", "category": "Spectra",
     "description": "Topographic maps of power.  Default 5 bands "
                    "(delta/theta/alpha/beta/gamma); custom bands via "
                    "Advanced.",
     "input": "both", "requires": ["montage"],
     "params": [
         {"key": "bands", "label": "Bands (Hz)", "type": "str",
          "default": "", "advanced": True,
          "tooltip":
              "Optional. Comma-separated min-max pairs, e.g.\n"
              "'1-4,4-8,8-12,12-30,30-50'. Empty = MNE default bands."},
         _PSD_SCALE_TOPO_PARAM,
         {"key": "normalize", "label": "Relative power", "type": "bool",
          "default": False, "advanced": True,
          "tooltip":
              "Normalize each band by total power across all bands\n"
              "(plots relative rather than absolute power)."},
         _PSD_SAVE_CSV_PARAM,
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.time_frequency.EpochsSpectrum.html#mne.time_frequency.EpochsSpectrum.plot_topomap"},
    {"id": "psd_multitaper", "name": "PSD multitaper", "category": "Spectra",
     "description": "Power spectral density using multitaper method.",
     "input": "both", "requires": [],
     "params": [
         {"key": "fmin", "label": "Freq min [Hz]", "type": "float",
          "default": 0,
          "tooltip": "Lower frequency bound.  0 = DC."},
         {"key": "fmax", "label": "Freq max [Hz]", "type": "float",
          "default": 0,
          "tooltip": "Upper frequency bound.  0 = Nyquist."},
         _PSD_SCALE_PLOT_PARAM,
         {"key": "bandwidth", "label": "Bandwidth [Hz]", "type": "float",
          "default": 0, "advanced": True,
          "tooltip":
              "Frequency smoothing in Hz (multitaper bandwidth).\n"
              "0 = MNE default (uses ~4× frequency resolution)."},
         {"key": "tmin", "label": "Time min [s]", "type": "float",
          "default": 0, "advanced": True,
          "tooltip":
              "Crop epochs to start at this time relative to event\n"
              "onset.  0 = start of epoch."},
         {"key": "tmax", "label": "Time max [s]", "type": "float",
          "default": 0, "advanced": True,
          "tooltip":
              "Crop epochs to end at this time.  0 = end of epoch."},
         {"key": "xscale", "label": "Freq axis", "type": "choice",
          "choices": ["linear", "log"], "default": "linear",
          "advanced": True,
          "tooltip": "Scale of the frequency axis on the plot."},
         {"key": "average", "label": "Average channels", "type": "bool",
          "default": False, "advanced": True,
          "tooltip":
              "If checked, plot one mean line across channels\n"
              "instead of one line per channel."},
         {"key": "ci", "label": "Conf. interval", "type": "choice",
          "choices": ["sd", "range", "off"], "default": "sd",
          "advanced": True,
          "tooltip":
              "Confidence band (only when 'Average channels' is on).\n"
              "  sd: ±1 SD across channels\n"
              "  range: min-max across channels\n"
              "  off: no band"},
         _PSD_SAVE_CSV_PARAM,
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.time_frequency.EpochsSpectrum.html#mne.time_frequency.EpochsSpectrum.plot"},
    {"id": "psd_welch", "name": "PSD Welch", "category": "Spectra",
     "description": "Power spectral density using Welch's method "
                    "(channel-overlay plot).",
     "input": "both", "requires": [],
     "params": [
         {"key": "fmin", "label": "Freq min [Hz]", "type": "float",
          "default": 0,
          "tooltip": "Lower frequency bound.  0 = DC."},
         {"key": "fmax", "label": "Freq max [Hz]", "type": "float",
          "default": 0,
          "tooltip": "Upper frequency bound.  0 = Nyquist."},
         _PSD_SCALE_PLOT_PARAM,
         {"key": "n_per_seg", "label": "Segment len", "type": "int",
          "default": 0, "advanced": True,
          "tooltip":
              "Welch segment length in samples.  0 = MNE default\n"
              "(256 or signal length, whichever is smaller)."},
         {"key": "n_overlap", "label": "Overlap", "type": "int",
          "default": 0, "advanced": True,
          "tooltip":
              "Welch segment overlap in samples.  0 = no overlap."},
         {"key": "average", "label": "Average channels", "type": "bool",
          "default": False, "advanced": True,
          "tooltip":
              "Plot one mean line across channels instead of one\n"
              "line per channel."},
         {"key": "xscale", "label": "Freq axis", "type": "choice",
          "choices": ["linear", "log"], "default": "linear",
          "advanced": True,
          "tooltip": "Scale of the frequency axis on the plot."},
         _PSD_SAVE_CSV_PARAM,
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.time_frequency.EpochsSpectrum.html#mne.time_frequency.EpochsSpectrum.plot"},
    {"id": "psd_topo", "name": "PSD per-channel (sensor layout)",
     "category": "Spectra",
     "description": "Per-channel PSD laid out at sensor positions on "
                    "a head map.",
     "input": "both", "requires": ["montage"],
     "params": [
         {"key": "fmin", "label": "Freq min [Hz]", "type": "float",
          "default": 0,
          "tooltip": "Lower frequency bound.  0 = DC."},
         {"key": "fmax", "label": "Freq max [Hz]", "type": "float",
          "default": 0,
          "tooltip": "Upper frequency bound.  0 = Nyquist."},
         _PSD_SCALE_TOPO_PARAM,
         _PSD_SAVE_CSV_PARAM,
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.time_frequency.Spectrum.html#mne.time_frequency.Spectrum.plot_topo"},

    # ── Time-frequency ───────────────────────────────────────────
    {"id": "tfr_morlet", "name": "TFR Morlet wavelet", "category": "Time-frequency",
     "description": "Time-frequency representation using Morlet wavelets (MNE).",
     "input": "epochs", "requires": [],
     "params": [
         {"key": "freq_min", "label": "Freq min [Hz]", "type": "float",
          "default": 1, "tooltip": "Minimum frequency."},
         {"key": "freq_max", "label": "Freq max [Hz]", "type": "float",
          "default": 50, "tooltip": "Maximum frequency (0 = Nyquist/2)."},
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.time_frequency.tfr_morlet.html"},
    {"id": "tfr_multitaper", "name": "TFR multitaper", "category": "Time-frequency",
     "description": "Time-frequency representation using multitaper method.",
     "input": "epochs", "requires": [],
     "params": [
         {"key": "freq_min", "label": "Freq min [Hz]", "type": "float",
          "default": 1, "tooltip": "Minimum frequency."},
         {"key": "freq_max", "label": "Freq max [Hz]", "type": "float",
          "default": 50, "tooltip": "Maximum frequency (0 = Nyquist/2)."},
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.time_frequency.tfr_multitaper.html"},
    {"id": "erds_topomap", "name": "ERD/S topomap", "category": "Time-frequency",
     "description": "Topographic maps of event-related (de)synchronization.",
     "input": "epochs", "requires": ["montage"],
     "params": [
         {"key": "freq_min", "label": "Freq min [Hz]", "type": "float",
          "default": 1, "tooltip": "Minimum frequency."},
         {"key": "freq_max", "label": "Freq max [Hz]", "type": "float",
          "default": 50, "tooltip": "Maximum frequency."},
     ],
     "doc_url": "https://mne.tools/stable/auto_examples/time_frequency/time_frequency_erds.html"},

    # ── Spatial ───────────────────────────────────────────────────
    {"id": "evoked_topomap_anim", "name": "Evoked topomap series", "category": "Spatial",
     "description": "Topographic maps at evenly spaced time points.",
     "input": "epochs", "requires": ["montage"],
     "params": [
         {"key": "n_times", "label": "N time points", "type": "int",
          "default": 10, "tooltip": "Number of topomap snapshots."},
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.Evoked.html#mne.Evoked.plot_topomap"},
    {"id": "channel_locations", "name": "Channel locations", "category": "Spatial",
     "description": "2D plot of electrode positions on the head.",
     "input": "both", "requires": ["montage"], "params": [],
     "doc_url": "https://mne.tools/stable/generated/mne.io.Raw.html#mne.io.Raw.plot_sensors"},

    # ── Comparison & Quality ─────────────────────────────────────
    {"id": "compare_evokeds", "name": "Compare evokeds", "category": "Comparison",
     "description": "Overlay grand-average ERPs for all conditions with confidence intervals.",
     "input": "epochs", "requires": ["multi_tag"], "params": [
         {"key": "ci", "label": "CI (%)", "type": "float",
          "default": 95, "tooltip": "Confidence interval width (0 = no CI)."},
     ],
     "doc_url": "https://mne.tools/stable/generated/mne.viz.plot_compare_evokeds.html"},
    {"id": "drop_log", "name": "Drop log", "category": "Comparison",
     "description": "Bar chart showing why each epoch was rejected (amplitude, flat, user).",
     "input": "epochs", "requires": [], "params": [],
     "doc_url": "https://mne.tools/stable/generated/mne.Epochs.html#mne.Epochs.plot_drop_log"},
    # NOTE: psd_bands_topomap was folded into psd_topomap (Spectra
    # category) on 2026-05-01.  Custom bands now live there as an
    # optional advanced parameter.  Old TOML configs are migrated by
    # `_migrate_legacy_psd_bands_topomap` in gui.py.

    # NOTE: Statistics category was folded into _unreleased/ on
    # 2026-05-01.  The two entries (`cluster_1samp`, `linear_regression`)
    # plus their handlers and the `Statistics` `_cat_help` block now
    # live in `_unreleased/statistics.py` and
    # `_unreleased/statistics_wiring.md`.  Restoration is mechanical;
    # see the wiring doc.

    # ── Evoked (extra) ───────────────────────────────────────────
    {"id": "evoked_image", "name": "Evoked image (channels x time)", "category": "ERP",
     "description": "Heatmap of the grand-average ERP: channels on y-axis, "
                    "time on x-axis. Shows spatial-temporal structure.",
     "input": "epochs", "requires": [], "params": [],
     "doc_url": "https://mne.tools/stable/generated/mne.Evoked.html#mne.Evoked.plot_image"},
    {"id": "compare_per_channel", "name": "Compare evokeds (per channel)", "category": "ERP",
     "description": "Overlay all conditions per channel in a subplot grid.",
     "input": "epochs", "requires": ["multi_tag"], "params": [],
     "doc_url": "https://mne.tools/stable/generated/mne.viz.plot_compare_evokeds.html"},

    # ── Source estimation ─────────────────────────────────────────
    {"id": "erp_dipole_fit", "name": "ERP dipole fit",
     "category": "Source estimation",
     "description": "Fit equivalent current dipoles to the averaged "
                    "ERP at each time point (mne.fit_dipole). Produces "
                    "brain cross-section plots and ConnectiVIS 3D "
                    "export. Requires FreeSurfer reconstruction or "
                    "fsaverage (auto-downloaded).",
     "input": "epochs", "requires": ["montage"],
     "params": [
         {"key": "time_min", "label": "Time min [s]", "type": "float",
          "default": 0.0,
          "tooltip": "Start of the time window to fit (seconds\n"
                     "relative to event). 0 = event onset."},
         {"key": "time_max", "label": "Time max [s]", "type": "float",
          "default": 0.0,
          "tooltip": "End of the time window. 0 = use the full\n"
                     "epoch. Cropping to a peak window (e.g.\n"
                     "0.07–0.12 for N100) speeds up fitting\n"
                     "and focuses on the component of interest."},
         {"key": "min_gof", "label": "Min GOF [%]", "type": "float",
          "default": 50,
          "tooltip": "Minimum goodness-of-fit (%). Dipoles below\n"
                     "this are excluded from the output. Default\n"
                     "50 — typical for EEG (lower than MEG due\n"
                     "to lower spatial resolution)."},
         {"key": "min_dist", "label": "Min dist to BEM [mm]",
          "type": "float", "default": 5.0, "advanced": True,
          "tooltip":
              "Minimum distance (mm) the dipole is forced to keep\n"
              "from the inner skull surface. Smaller = closer to\n"
              "cortex, larger = more conservative. MNE default\n"
              "is 5 mm."},
         {"key": "pos", "label": "Fixed position [mm]", "type": "str",
          "default": "", "advanced": True,
          "tooltip":
              "Optional. 'x,y,z' in head-coordinate millimetres to\n"
              "constrain the dipole to a fixed location (only the\n"
              "orientation + amplitude are then fit). Empty =\n"
              "free-fit position (default MNE behaviour)."},
     ],
     "doc_url": "https://mne.tools/stable/auto_tutorials/inverse/20_dipole_fit.html"},

    {"id": "mne_inverse",
     "name": "MNE / dSPM / sLORETA / eLORETA inverse",
     "category": "Source estimation",
     "description": "Distributed source estimation via MNE's "
                    "minimum-norm family. Computes a forward solution + "
                    "inverse operator from epochs, applies it to the "
                    "averaged ERP, and saves the source estimate (.h5) "
                    "plus a 3D PyVista screenshot per condition. "
                    "Per-vertex output; set n_peaks > 0 to also export "
                    "the N strongest vertices as a dipoles CSV that "
                    "ConnectiVIS reads natively.",
     "input": "epochs", "requires": ["montage"],
     "params": [
         {"key": "method", "label": "Method", "type": "choice",
          "choices": ["MNE", "dSPM", "sLORETA", "eLORETA"],
          "default": "dSPM",
          "tooltip":
              "Inverse method:\n"
              "  MNE      — minimum-norm estimate (raw current).\n"
              "  dSPM     — dynamic SPM (noise-normalised, units of σ).\n"
              "  sLORETA  — standardised low-resolution tomography.\n"
              "  eLORETA  — exact LORETA (zero-localisation-error)."},
         {"key": "snr", "label": "SNR", "type": "float",
          "default": 3.0,
          "tooltip":
              "Signal-to-noise ratio used to compute λ² = 1/SNR².\n"
              "Higher SNR = less regularisation = sharper but\n"
              "noisier sources. MNE default 3.0."},
         {"key": "loose", "label": "Loose orientation", "type": "float",
          "default": 0.2, "advanced": True,
          "tooltip":
              "Source orientation constraint (0..1):\n"
              "  0   — fixed (normal-to-cortex only)\n"
              "  0.2 — loosely free (default, recommended for EEG)\n"
              "  1   — fully free (3 components per source)."},
         {"key": "depth", "label": "Depth weighting",
          "type": "float", "default": 0.8, "advanced": True,
          "tooltip":
              "Depth-weighting exponent (0..1). 0 = none, 0.8 =\n"
              "MNE default (compensates for the bias against deep\n"
              "sources)."},
         {"key": "spacing", "label": "Source spacing",
          "type": "choice", "advanced": True,
          "choices": ["oct4", "oct5", "oct6", "ico4", "ico5"],
          "default": "ico4",
          "tooltip":
              "Source-space subdivision. 'ico4' (~2.5k vertices)\n"
              "is the default — fast and adequate for EEG.\n"
              "'oct6' (~8k) matches MNE tutorials but is slower."},
         {"key": "n_peaks", "label": "ConnectiVIS peaks",
          "type": "int", "default": 0, "advanced": True,
          "tooltip":
              "If >0, extract the N strongest cortical vertices\n"
              "from each condition's source estimate and export\n"
              "them as a dipoles CSV that ConnectiVIS reads\n"
              "natively. Lossy (collapses the smooth distribution\n"
              "to N point sources) but useful for 3D inspection.\n"
              "0 = off (default; .h5 + PNG screenshot only)."},
     ],
     "doc_url": "https://mne.tools/stable/auto_tutorials/inverse/30_mne_dspm_loreta.html"},

    {"id": "lcmv_beamformer", "name": "LCMV beamformer",
     "category": "Source estimation",
     "description": "Linearly Constrained Minimum-Variance beamformer "
                    "(mne.beamformer.make_lcmv + apply_lcmv). Computes a "
                    "data covariance from the post-stimulus window and "
                    "applies a unit-noise-gain filter to each cortical "
                    "vertex. Saves source estimate (.h5) plus a 3D "
                    "PyVista screenshot per condition.",
     "input": "epochs", "requires": ["montage"],
     "params": [
         {"key": "reg", "label": "Regularisation", "type": "float",
          "default": 0.05,
          "tooltip":
              "Tikhonov regularisation of the data covariance.\n"
              "Higher = smoother sources, less sensitive to noise.\n"
              "MNE tutorial default 0.05."},
         {"key": "pick_ori", "label": "Pick orientation",
          "type": "choice", "advanced": True,
          "choices": ["max-power", "normal", "vector"],
          "default": "max-power",
          "tooltip":
              "How to combine the 3 source orientations per vertex:\n"
              "  max-power — orientation that maximises power\n"
              "  normal    — radial-only (cortical normal)\n"
              "  vector    — keep all 3 components."},
         {"key": "weight_norm", "label": "Weight normalisation",
          "type": "choice", "advanced": True,
          "choices": ["unit-noise-gain", "nai", "none"],
          "default": "unit-noise-gain",
          "tooltip":
              "Beamformer weight normalisation:\n"
              "  unit-noise-gain — equal noise sensitivity per vertex\n"
              "  nai             — neural activity index\n"
              "  none            — raw scalar beamformer."},
         {"key": "spacing", "label": "Source spacing",
          "type": "choice", "advanced": True,
          "choices": ["oct4", "oct5", "oct6", "ico4", "ico5"],
          "default": "ico4",
          "tooltip":
              "Source-space subdivision. 'ico4' (~2.5k vertices)\n"
              "is the default — fast and adequate for EEG."},
         {"key": "n_peaks", "label": "ConnectiVIS peaks",
          "type": "int", "default": 0, "advanced": True,
          "tooltip":
              "If >0, extract the N strongest cortical vertices\n"
              "from each condition's beamformer output and export\n"
              "them as a dipoles CSV that ConnectiVIS reads\n"
              "natively. Lossy but useful for 3D inspection.\n"
              "0 = off (default; .h5 + PNG screenshot only)."},
     ],
     "doc_url": "https://mne.tools/stable/auto_tutorials/inverse/50_beamformer_lcmv.html"},

    {"id": "mxne", "name": "MxNE / iRMxNE (sparse)",
     "category": "Source estimation",
     "description": "Sparse source estimation via mixed-norm "
                    "regularisation (mne.inverse_sparse.mixed_norm). "
                    "Returns a handful of focal sources rather than a "
                    "smooth distribution — exported as dipoles.csv "
                    "(directly viewable in ConnectiVIS, same format as "
                    "ERP dipole fit).",
     "input": "epochs", "requires": ["montage"],
     "params": [
         {"key": "alpha", "label": "Sparsity α", "type": "float",
          "default": 80.0,
          "tooltip":
              "Sparsity / regularisation strength (% of α_max).\n"
              "Higher α = fewer, more focal sources. 50–90 is a\n"
              "typical range for ERP data."},
         {"key": "depth", "label": "Depth weighting",
          "type": "float", "default": 0.9, "advanced": True,
          "tooltip":
              "Depth-weighting exponent (0..1). MxNE biases\n"
              "towards superficial sources; depth=0.9 partially\n"
              "compensates."},
         {"key": "loose", "label": "Loose orientation",
          "type": "float", "default": 0.2, "advanced": True,
          "tooltip":
              "Source orientation constraint (0..1).\n"
              "Same convention as the MNE inverse entry."},
         {"key": "n_mxne_iter", "label": "Re-weighted iters",
          "type": "int", "default": 1, "advanced": True,
          "tooltip":
              "1 = vanilla MxNE. ≥2 enables iterative\n"
              "re-weighted MxNE (iRMxNE), which produces even\n"
              "sparser solutions at the cost of a few extra solves."},
         {"key": "spacing", "label": "Source spacing",
          "type": "choice", "advanced": True,
          "choices": ["oct4", "oct5", "oct6", "ico4", "ico5"],
          "default": "ico4",
          "tooltip":
              "Source-space subdivision. 'ico4' (~2.5k vertices)\n"
              "is the default — fast and adequate for EEG."},
     ],
     "doc_url": "https://mne.tools/stable/auto_examples/inverse/mixed_norm_inverse.html"},
]


# ── Optional package detection ───────────────────────────────────────

def _check_optional_pkg(pkg_name):
    """Check if an optional package is importable."""
    try:
        __import__(pkg_name)
        return True
    except ImportError:
        return False


# ── Executor ─────────────────────────────────────────────────────────

def run_mne_catalog(selected_ids, rest, epochs, config, output_dir,
                    file_name):
    """Run selected MNE catalog analyses.

    Parameters
    ----------
    selected_ids : list of str
        IDs from MNE_CATALOG to execute.
    rest : mne.Epochs or None
    epochs : mne.Epochs or None
    config : dict
    output_dir : str
    file_name : str

    Returns
    -------
    n_ok : int
        Number of successfully completed analyses.
    """
    import mne
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    base = os.path.splitext(file_name)[0]

    # Output directories: MNE/ for MNE-Python analyses.
    # Optional-package entries (e.g. an external-tool wrapper) get
    # routed to a sibling directory named after their ``optional_pkg``.
    _out_dirs = {}
    def _get_out_dir(entry):
        pkg = entry.get("optional_pkg")
        subdir = pkg if pkg else "MNE"
        if subdir not in _out_dirs:
            d = os.path.join(output_dir, subdir)
            os.makedirs(d, exist_ok=True)
            _out_dirs[subdir] = d
        return _out_dirs[subdir]

    catalog_map = {e["id"]: e for e in MNE_CATALOG}
    n_ok = 0

    # Cancel helper — read once, close over the event
    cancel = config.get("_cancel_event")
    def _check_cancel():
        if cancel is not None and cancel.is_set():
            logging.info("MNE catalog cancelled by user.")
            raise InterruptedError("MNE catalog cancelled by user")

    # Pre-load EEG data once per source (avoid N copies for N analyses).
    # Skip empty Epochs — MNE's pick() raises on empty objects with
    # an opaque message; the downstream loop already treats a missing
    # cache entry as "no matching data" and skips affected analyses.
    _eeg_cache = {}
    for label, src in [("rest", rest), ("epochs", epochs)]:
        if src is None:
            continue
        if len(src) == 0:
            logging.warning(
                "MNE catalog: %s Epochs object is empty — every "
                "epoch was dropped during preprocessing. Check "
                "Epochs.drop_log or your PTP rejection thresholds, "
                "trim window, and event selection. Skipping all "
                "analyses that would consume %s data.",
                label, label)
            continue
        _eeg_cache[label] = src.copy().load_data().pick("eeg")

    for aid in selected_ids:
        _check_cancel()
        entry = catalog_map.get(aid)
        if not entry:
            logging.warning("MNE catalog: unknown analysis '%s'", aid)
            continue

        data_labels = []
        if entry["input"] in ("rest", "both") and "rest" in _eeg_cache:
            data_labels.append("rest")
        if entry["input"] in ("epochs", "both") and "epochs" in _eeg_cache:
            data_labels.append("epochs")
        if not data_labels:
            logging.info("MNE catalog: skipping '%s' (no matching data)",
                         entry["name"])
            continue

        out_dir = _get_out_dir(entry)
        for data_label in data_labels:
            _check_cancel()
            try:
                _run_one(entry, _eeg_cache[data_label], data_label,
                         base, out_dir, config)
                n_ok += 1
            except InterruptedError:
                # Let cancellation propagate; otherwise the broad
                # Exception catch below would swallow it and the
                # loop would keep spawning further analyses.
                raise
            except Exception as e:
                logging.error("MNE catalog: '%s' failed: %s",
                              entry["name"], e)

    logging.info("MNE catalog: %d/%d analyses completed.",
                 n_ok, len(selected_ids))
    return n_ok


def _run_one(entry, eeg, data_label, base, mne_dir, config):
    """Execute a single catalog entry on pre-loaded EEG data."""
    aid = entry["id"]
    fn = _DISPATCH.get(aid)
    if fn is None:
        logging.warning("MNE catalog: no handler for '%s'", aid)
        return
    params = config.get("mne_params", {}).get(aid, {})
    fn(eeg, data_label, base, mne_dir, config, params)


# ── Shared catalog helpers ───────────────────────────────────────────


def _optional_kwargs(params, allowed_keys, cast=float):
    """Return a kwargs dict ready to splat into a catalog MNE call.

    Picks the relevant keys from the user's catalog `params` dict,
    drops empty / zero / unparsable values (catalog defaults use 0
    to mean "MNE default — leave it out"), and returns a dict ready
    for ``**kwargs``-style unpacking.

    *cast* is the type to coerce values to.  `float` (the default)
    suits time-domain and bandwidth params; pass `int` for sample
    counts (`n_per_seg`, `n_overlap`).  `cast` is applied through
    ``cast(float(v))`` so that QLineEdit-stringified ints
    (``"256.0"``) coerce cleanly.
    """
    out = {}
    for k in allowed_keys:
        if k in params:
            v = params[k]
            try:
                v = cast(float(v))
            except (TypeError, ValueError):
                v = None
            if v is not None and v != 0:
                out[k] = v
    return out


def _parse_fmin_fmax(params, sfreq):
    """Translate ``params['fmin']`` / ``params['fmax']`` into a
    ``(fmin, fmax)`` pair, with 0 meaning "MNE default": fmin → 0
    (DC), fmax → Nyquist (sfreq / 2)."""
    fmin = float(params.get("fmin", 0) or 0)
    fmax = float(params.get("fmax", 0) or 0) or sfreq / 2
    return fmin, fmax


def _scale_kwargs(params, supports_amplitude):
    """Translate the `scale` choice param into Spectrum-plot kwargs.

    `Spectrum.plot()` supports both `dB` and `amplitude`; the topo
    variants (`plot_topomap`, `plot_topo`) only have `dB` — the
    `supports_amplitude` flag selects between the two surfaces.

    "dB" / missing → empty dict (let MNE default kick in: dB=True).
    "power"        → {"dB": False}.
    "amplitude"    → {"dB": False, "amplitude": True} on plot();
                     {"dB": False} on topo (silent fallback).
    """
    scale = params.get("scale")
    if scale == "power":
        return {"dB": False}
    if scale == "amplitude":
        return ({"dB": False, "amplitude": True} if supports_amplitude
                else {"dB": False})
    return {}


def _spectrum_plot_kwargs_from_params(params):
    """Translate catalog plot-related params (`scale`, `xscale`,
    `average`, `ci`) into kwargs for `Spectrum.plot()`.  Always
    includes ``show=False``; the rest are added only when the user
    explicitly set them (so MNE defaults shine through when
    omitted)."""
    out = {"show": False}
    out.update(_scale_kwargs(params, supports_amplitude=True))
    if params.get("xscale"):
        out["xscale"] = str(params["xscale"])
    if params.get("average"):
        out["average"] = True
    ci = params.get("ci")
    if ci == "off":
        out["ci"] = None
    elif ci in ("sd", "range"):
        out["ci"] = ci
    return out


def _parse_bands(bands_str):
    """Parse a "min-max,min-max,..." bands string into MNE's expected
    `{name: (fmin, fmax)}` dict.  Returns None on empty / malformed
    input (caller should fall back to MNE's default bands)."""
    if not bands_str or not str(bands_str).strip():
        return None
    band_names = ["delta", "theta", "alpha", "beta", "gamma"]
    try:
        out = {}
        for i, b in enumerate(str(bands_str).split(",")):
            lo, hi = b.strip().split("-")
            name = band_names[i] if i < len(band_names) else f"band{i+1}"
            out[name] = (float(lo), float(hi))
        return out or None
    except (ValueError, IndexError):
        return None


def _maybe_save_csv(spec, params, mne_dir, base, aid, tag):
    """If params['save_csv'] is truthy, dump the Spectrum to CSV
    alongside its plot."""
    if not params.get("save_csv", False):
        return
    try:
        df = spec.to_data_frame()
        parts = [base, "MNE", aid]
        if tag:
            parts.append(_safe_tag(tag))
        path = os.path.join(mne_dir, "___".join(parts) + ".csv")
        df.to_csv(path, index=False)
        logging.info("MNE: saved %s", os.path.basename(path))
    except Exception as e:
        logging.warning("MNE %s CSV write failed: %s", aid, e)


# ── Individual analysis handlers ─────────────────────────────────────

def _save(fig, mne_dir, base, aid, tag="", suffix=""):
    """Save figure and close."""
    parts = [base, "MNE", aid]
    if tag:
        parts.append(_safe_tag(tag))
    if suffix:
        parts.append(suffix)
    fname = "___".join(parts) + ".png"
    fig.savefig(os.path.join(mne_dir, fname), dpi=150,
                bbox_inches="tight")
    plt.close(fig)
    logging.info("MNE: saved %s", fname)


def _erp_butterfly(eeg, data_label, base, mne_dir, config, params):
    for tag in eeg.event_id:
        evoked = eeg[tag].average()
        fig = evoked.plot(spatial_colors=True, show=False)
        fig.suptitle(f"ERP: {tag} ({len(eeg[tag])} epochs)")
        _save(fig, mne_dir, base, "erp_butterfly", tag)


def _erp_image(eeg, data_label, base, mne_dir, config, params):
    for tag in eeg.event_id:
        for ch in eeg.info["ch_names"][:]:
            try:
                figs = eeg[tag].plot_image(
                    picks=ch,
                    title=f"{tag} ({len(eeg[tag])}): {ch}",
                    show=False)
                fig = figs[0] if isinstance(figs, (list, tuple)) else figs
                _save(fig, mne_dir, base, "erp_image", tag, ch)
            except Exception as e:
                logging.warning("MNE erp_image %s/%s: %s", tag, ch, e)


def _erp_joint(eeg, data_label, base, mne_dir, config, params):
    for tag in eeg.event_id:
        evoked = eeg[tag].average()
        try:
            fig = evoked.plot_joint(show=False)
            _save(fig, mne_dir, base, "erp_joint", tag)
        except Exception as e:
            logging.warning("MNE erp_joint: %s", e)


def _erp_topomap(eeg, data_label, base, mne_dir, config, params):
    n_times = int(params.get("n_times", 10))
    for tag in eeg.event_id:
        evoked = eeg[tag].average()
        try:
            times = np.linspace(evoked.times[0], evoked.times[-1],
                                n_times)
            fig = evoked.plot_topomap(times=times, show=False)
            _save(fig, mne_dir, base, "erp_topomap", tag)
        except Exception as e:
            logging.warning("MNE erp_topomap: %s", e)


def _gfp(eeg, data_label, base, mne_dir, config, params):
    for tag in eeg.event_id:
        evoked = eeg[tag].average()
        gfp = np.std(evoked.data, axis=0)
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(evoked.times, gfp * 1e6, color="#4a90d9", linewidth=1.5)
        ax.set_xlabel("Time [s]")
        ax.set_ylabel("GFP [\u00b5V]")
        ax.set_title(f"Global Field Power: {tag} ({len(eeg[tag])} epochs)")
        ax.grid(True, alpha=0.3)
        ax.axvline(0, color="gray", linestyle="--", alpha=0.5)
        fig.tight_layout()
        _save(fig, mne_dir, base, "gfp", tag)


def _psd_topomap(eeg, data_label, base, mne_dir, config, params):
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    bands = _parse_bands(params.get("bands", ""))
    plot_kwargs = {"show": False}
    plot_kwargs.update(_scale_kwargs(params, supports_amplitude=False))
    if bands is not None:
        plot_kwargs["bands"] = bands
    if params.get("normalize", False):
        plot_kwargs["normalize"] = True
    for tag in eeg.event_id:
        try:
            spec = eeg[tag].compute_psd(n_jobs=n_jobs)
            fig = spec.plot_topomap(**plot_kwargs)
            if isinstance(fig, (list, tuple)):
                fig = fig[0]
            _save(fig, mne_dir, base, "psd_topomap", tag)
            _maybe_save_csv(spec, params, mne_dir, base,
                            "psd_topomap", tag)
        except Exception as e:
            logging.warning("MNE psd_topomap: %s", e)


def _psd_multitaper(eeg, data_label, base, mne_dir, config, params):
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    fmin, fmax = _parse_fmin_fmax(params, eeg.info["sfreq"])
    psd_kwargs = {
        "method": "multitaper",
        "n_jobs": n_jobs,
        "fmin": fmin,
        "fmax": fmax,
    }
    psd_kwargs.update(_optional_kwargs(
        params, ["tmin", "tmax", "bandwidth"]))
    plot_kwargs = _spectrum_plot_kwargs_from_params(params)
    for tag in eeg.event_id:
        try:
            spec = eeg[tag].compute_psd(**psd_kwargs)
            fig = spec.plot(**plot_kwargs)
            fig.suptitle(f"PSD multitaper: {tag}")
            _save(fig, mne_dir, base, "psd_multitaper", tag)
            _maybe_save_csv(spec, params, mne_dir, base,
                            "psd_multitaper", tag)
        except Exception as e:
            logging.warning("MNE psd_multitaper: %s", e)


def _psd_welch(eeg, data_label, base, mne_dir, config, params):
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    fmin, fmax = _parse_fmin_fmax(params, eeg.info["sfreq"])
    psd_kwargs = {
        "method": "welch",
        "n_jobs": n_jobs,
        "fmin": fmin,
        "fmax": fmax,
    }
    psd_kwargs.update(_optional_kwargs(
        params, ["n_per_seg", "n_overlap"], cast=int))
    plot_kwargs = _spectrum_plot_kwargs_from_params(params)
    for tag in eeg.event_id:
        try:
            spec = eeg[tag].compute_psd(**psd_kwargs)
            fig = spec.plot(**plot_kwargs)
            fig.suptitle(f"PSD Welch: {tag}")
            _save(fig, mne_dir, base, "psd_welch", tag)
            _maybe_save_csv(spec, params, mne_dir, base,
                            "psd_welch", tag)
        except Exception as e:
            logging.warning("MNE psd_welch: %s", e)


def _psd_topo(eeg, data_label, base, mne_dir, config, params):
    """Per-channel PSD laid out at sensor positions.

    Built from `mne.viz.iter_topography` rather than
    `Spectrum.plot_topo()` so each channel gets its own axes — needed
    to add visible channel-name labels (plot_topo uses unified=True
    and renders every mini-plot inside one big axes, leaving no
    handle to label individual cells in static PNG output).
    """
    import mne
    import matplotlib.pyplot as plt
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    fmin, fmax = _parse_fmin_fmax(params, eeg.info["sfreq"])
    use_dB = _scale_kwargs(
        params, supports_amplitude=False).get("dB", True)
    y_label = "dB" if use_dB else "Power"
    for tag in eeg.event_id:
        try:
            spec = eeg[tag].compute_psd(
                n_jobs=n_jobs, fmin=fmin, fmax=fmax)
            psds, freqs = spec.get_data(return_freqs=True)
            # Average over epochs if EpochsSpectrum (3-D).
            if psds.ndim == 3:
                psds = psds.mean(axis=0)
            if use_dB:
                psds = 10.0 * np.log10(np.maximum(psds, 1e-30))
            fig = plt.figure(figsize=(10, 8), facecolor="white")
            for ax, ch_idx in mne.viz.iter_topography(
                    spec.info, fig=fig,
                    fig_facecolor="white",
                    axis_facecolor="whitesmoke",
                    axis_spinecolor="lightgrey"):
                ax.plot(freqs, psds[ch_idx],
                        color="blue", linewidth=0.7)
                ax.set_title(spec.info["ch_names"][ch_idx],
                             fontsize=7, color="dimgrey", pad=1)
            fig.suptitle(
                f"PSD per channel: {tag} ({y_label})",
                fontsize=10, y=0.995)
            _save(fig, mne_dir, base, "psd_topo", tag)
            _maybe_save_csv(spec, params, mne_dir, base,
                            "psd_topo", tag)
        except Exception as e:
            logging.warning("MNE psd_topo: %s", e)


def _compute_tfr(eeg, params, method, aid, base, mne_dir,
                 plot_type="plot", n_jobs=1):
    """Shared TFR computation for morlet, multitaper, and ERD/S topomap."""
    import mne
    fmin = float(params.get("freq_min", 1))
    fmax = float(params.get("freq_max", 0)) or eeg.info["sfreq"] / 2
    tfr_fn = (mne.time_frequency.tfr_morlet if method == "morlet"
              else mne.time_frequency.tfr_multitaper)
    for tag in eeg.event_id:
        freqs = np.arange(max(1, fmin), min(fmax, eeg.info["sfreq"] / 2), 1)
        n_cycles = freqs / 2.0
        try:
            power = tfr_fn(eeg[tag], freqs=freqs, n_cycles=n_cycles,
                           return_itc=False, average=True,
                           n_jobs=n_jobs)
            if plot_type == "topomap":
                fig = power.plot_topomap(show=False)
                if isinstance(fig, (list, tuple)):
                    fig = fig[0]
                _save(fig, mne_dir, base, aid, tag)
            else:
                fig = power.plot(show=False)
                if isinstance(fig, (list, tuple)):
                    for i, f in enumerate(fig):
                        _save(f, mne_dir, base, aid, tag,
                              eeg.info["ch_names"][i])
                else:
                    _save(fig, mne_dir, base, aid, tag)
        except Exception as e:
            logging.warning("MNE %s: %s", aid, e)


def _tfr_morlet(eeg, data_label, base, mne_dir, config, params):
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    _compute_tfr(eeg, params, "morlet", "tfr_morlet", base, mne_dir,
                 n_jobs=n_jobs)


def _tfr_multitaper(eeg, data_label, base, mne_dir, config, params):
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    _compute_tfr(eeg, params, "multitaper", "tfr_multitaper", base, mne_dir,
                 n_jobs=n_jobs)


def _erds_topomap(eeg, data_label, base, mne_dir, config, params):
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    _compute_tfr(eeg, params, "morlet", "erds_topomap", base, mne_dir,
                 plot_type="topomap", n_jobs=n_jobs)


def _evoked_topomap_anim(eeg, data_label, base, mne_dir, config, params):
    n_times = int(params.get("n_times", 10))
    for tag in eeg.event_id:
        evoked = eeg[tag].average()
        try:
            times = np.linspace(evoked.times[0], evoked.times[-1], n_times)
            fig = evoked.plot_topomap(times=times, show=False)
            _save(fig, mne_dir, base, "evoked_topomap_series", tag)
        except Exception as e:
            logging.warning("MNE evoked_topomap: %s", e)


def _channel_locations(eeg, data_label, base, mne_dir, config, params):
    try:
        fig = eeg.plot_sensors(show=False, show_names=True)
        _save(fig, mne_dir, base, "channel_locations", data_label)
    except Exception as e:
        logging.warning("MNE channel_locations: %s", e)


def _cluster_permutation(eeg, data_label, base, mne_dir, config, params):
    import mne
    tags = list(eeg.event_id.keys())
    if len(tags) < 2:
        # WARNING (was INFO) — the user explicitly selected this
        # entry, so them not getting any output should be visible.
        logging.warning(
            "MNE cluster_permutation requires 2+ event types but "
            "got %d ('%s').  Skipping the test.  Either select an "
            "event-locked recording with multiple conditions or "
            "remove cluster_permutation from the catalog selection.",
            len(tags), ", ".join(tags) if tags else "(none)")
        return

    step_down_p = float(params.get("step_down_p", 0.05))
    n_permutations = int(params.get("n_permutations", 1024))
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    # Sanity check: if n_permutations × step_down_p < 1 the test can't
    # resolve the requested p-level (best achievable is ≥ 1/n_perm).
    # MNE doesn't enforce this; raise the perm count with a warning.
    min_needed = max(1024, int(2 / max(step_down_p, 1e-9)))
    if n_permutations < min_needed:
        logging.warning(
            "MNE cluster_permutation: n_permutations=%d is too low "
            "for step_down_p=%g (need ≥ ~%d to resolve that level). "
            "Raising to %d.",
            n_permutations, step_down_p, min_needed, min_needed)
        n_permutations = min_needed

    # Test all pairwise combinations
    for i, t1 in enumerate(tags):
        for t2 in tags[i + 1:]:
            try:
                d1 = eeg[t1].get_data().transpose(0, 2, 1)
                d2 = eeg[t2].get_data().transpose(0, 2, 1)
                t_obs, clusters, p_values, h0 = \
                    mne.stats.spatio_temporal_cluster_test(
                        [d1, d2], out_type="mask",
                        step_down_p=step_down_p,
                        n_permutations=n_permutations,
                        n_jobs=n_jobs)

                # Plot significant clusters
                sig = np.where(p_values < 0.05)[0]
                evk1 = eeg[t1].average()
                evk2 = eeg[t2].average()

                fig, axes = plt.subplots(2, 1, figsize=(12, 8),
                                         sharex=True)
                axes[0].plot(evk1.times, evk1.data.T * 1e6,
                             alpha=0.5, linewidth=0.5)
                axes[0].plot(evk1.times, evk1.data.mean(0) * 1e6,
                             color="blue", linewidth=2, label=t1)
                axes[0].plot(evk2.times, evk2.data.mean(0) * 1e6,
                             color="red", linewidth=2, label=t2)
                axes[0].set_ylabel("Amplitude [\u00b5V]")
                axes[0].legend()
                axes[0].set_title(
                    f"Cluster permutation: {t1} vs {t2} "
                    f"({len(sig)} sig. clusters)")

                # Show cluster masks
                mask = np.zeros_like(t_obs, dtype=bool)
                for ci in sig:
                    mask |= clusters[ci]
                axes[1].imshow(mask.T, aspect="auto",
                               extent=[evk1.times[0], evk1.times[-1],
                                       0, len(eeg.info["ch_names"])],
                               cmap="RdBu_r", origin="lower")
                axes[1].set_ylabel("Channel")
                axes[1].set_xlabel("Time [s]")
                axes[1].set_title(
                    f"Significant clusters (p < 0.05)")
                fig.tight_layout()
                _save(fig, mne_dir, base, "cluster_perm",
                      f"{t1}_vs_{t2}")

                # Save cluster details to text
                txt_path = os.path.join(
                    mne_dir,
                    f"{base}___MNE___cluster_perm___{t1}_vs_{t2}.txt")
                with open(txt_path, "w") as f:
                    f.write(f"Cluster permutation test: {t1} vs {t2}\n")
                    f.write(f"n_permutations: {n_permutations}\n")
                    f.write(f"step_down_p: {step_down_p}\n\n")
                    for ci, pv in enumerate(p_values):
                        f.write(f"Cluster {ci}: p = {pv:.6f}"
                                f" {'***' if pv < 0.001 else '**' if pv < 0.01 else '*' if pv < 0.05 else ''}\n")
                logging.info("MNE cluster_perm: %s vs %s — %d clusters, "
                             "%d significant", t1, t2, len(p_values),
                             len(sig))
            except Exception as e:
                logging.error("MNE cluster_permutation %s vs %s: %s",
                              t1, t2, e)


def _compare_evokeds(eeg, data_label, base, mne_dir, config, params):
    import mne
    tags = list(eeg.event_id.keys())
    if len(tags) < 2:
        logging.info("MNE compare_evokeds: need 2+ conditions")
        return
    ci = float(params.get("ci", 95)) / 100.0
    evokeds = {tag: eeg[tag].average() for tag in tags}
    try:
        fig = mne.viz.plot_compare_evokeds(
            evokeds, show=False, ci=ci if ci > 0 else False)
        if isinstance(fig, (list, tuple)):
            fig = fig[0]
        _save(fig, mne_dir, base, "compare_evokeds")
    except Exception as e:
        logging.warning("MNE compare_evokeds: %s", e)


def _drop_log(eeg, data_label, base, mne_dir, config, params):
    try:
        fig = eeg.plot_drop_log(show=False)
        _save(fig, mne_dir, base, "drop_log")
    except Exception as e:
        logging.warning("MNE drop_log: %s", e)


def _evoked_image(eeg, data_label, base, mne_dir, config, params):
    for tag in eeg.event_id:
        evoked = eeg[tag].average()
        try:
            fig = evoked.plot_image(show=False)
            if isinstance(fig, (list, tuple)):
                fig = fig[0]
            _save(fig, mne_dir, base, "evoked_image", tag)
        except Exception as e:
            logging.warning("MNE evoked_image %s: %s", tag, e)


def _compare_per_channel(eeg, data_label, base, mne_dir, config, params):
    import mne
    tags = list(eeg.event_id.keys())
    if len(tags) < 2:
        logging.info("MNE compare_per_channel: need 2+ conditions")
        return
    evokeds = {tag: eeg[tag].average() for tag in tags}
    ch_names = eeg.info["ch_names"]
    ncols = min(4, len(ch_names))
    nrows = int(np.ceil(len(ch_names) / ncols))
    fig, axes = plt.subplots(nrows, ncols,
                              figsize=(4 * ncols, 3 * nrows),
                              sharex=True, squeeze=False)
    colors = ["#4a90d9", "#e6553a", "#2ca02c", "#9467bd", "#e6a700",
              "#17becf", "#d62728", "#8c564b", "#7f7f7f", "#bcbd22"]
    for i, ch in enumerate(ch_names):
        ax = axes[i // ncols, i % ncols]
        for ti, tag in enumerate(tags):
            ev = evokeds[tag]
            ch_idx = ev.info["ch_names"].index(ch)
            ax.plot(ev.times, ev.data[ch_idx] * 1e6,
                    color=colors[ti % len(colors)],
                    linewidth=1, label=tag)
        ax.set_title(ch, fontsize=9)
        ax.axvline(0, color="gray", linestyle="--", alpha=0.4)
        ax.grid(True, alpha=0.2)
        if i == 0:
            ax.legend(fontsize=6)
    for j in range(len(ch_names), nrows * ncols):
        axes[j // ncols, j % ncols].set_visible(False)
    fig.supxlabel("Time [s]")
    fig.supylabel("Amplitude [\u00b5V]")
    fig.suptitle(f"Evoked comparison: {' vs '.join(tags)}", fontsize=11)
    fig.tight_layout()
    _save(fig, mne_dir, base, "compare_per_channel")


def _parse_dipole_pos(s):
    """Parse a comma-separated 'x,y,z' string (mm) → (x,y,z) in metres.

    Returns ``None`` on parse failure (the caller falls back to the
    free-fit default of MNE's ``fit_dipole``).
    """
    try:
        parts = [float(p.strip()) for p in s.split(",")]
        if len(parts) != 3:
            return None
        return tuple(p / 1000.0 for p in parts)
    except (ValueError, AttributeError):
        return None


def _resolve_inverse_setup(config, label):
    """Resolve the BEM solution + HEAD→MRI transform for a source-
    space analysis.  Shared by every entry that needs an MNE forward
    model: ``erp_dipole_fit``, MNE/dSPM/sLORETA/eLORETA, LCMV, MxNE.

    ``label`` is the human-readable analysis name used in error
    messages (e.g. ``"ERP dipole fit"``, ``"MNE inverse"``).

    Returns
    -------
    (fs_dir, subject, subjects_dir, bem_file, trans_file, is_fsaverage)
        Tuple on success.  ``None`` on failure (error already logged).
    """
    from .dipole.fitting import _ensure_fsaverage

    dip_cfg = config.get("dipole_fitting", {})
    fs_dir = dip_cfg.get("fsaverage_dir", "").strip() or None
    fs_dir = _ensure_fsaverage(fs_dir)
    is_fsaverage = os.path.basename(fs_dir) == "fsaverage"

    subjects_dir = os.path.join(fs_dir, "..")
    subject = os.path.basename(fs_dir)
    bem_dir = os.path.join(fs_dir, "bem")
    # Try the canonical fsaverage names first, then fall back to a
    # glob so subject-specific reconstructions with names like
    # ``SUBJ01-bem-sol.fif`` or ``SUBJ01-bem.fif`` (output of
    # mne.make_bem_solution) are also picked up.
    bem_candidates = [
        os.path.join(bem_dir, f"{subject}-5120-5120-5120-bem-sol.fif"),
        os.path.join(bem_dir, f"{subject}-5120-bem-sol.fif"),
    ]
    bem_file = next((f for f in bem_candidates if os.path.isfile(f)), None)
    if bem_file is None and os.path.isdir(bem_dir):
        import glob
        for pat in ("*-bem-sol.fif", "*-bem.fif"):
            matches = sorted(glob.glob(os.path.join(bem_dir, pat)))
            if matches:
                bem_file = matches[0]
                break
    if bem_file is None:
        logging.error("%s: no BEM solution in %s", label, bem_dir)
        return None

    trans_candidates = [
        os.path.join(fs_dir, "bem", f"{subject}-trans.fif"),
        dip_cfg.get("trans_path", ""),
    ]
    inp = config.get("input_path", "")
    if inp:
        inp_dir = os.path.dirname(inp)
        for f in os.listdir(inp_dir) if os.path.isdir(inp_dir) else []:
            if f.endswith("-trans.fif"):
                trans_candidates.append(os.path.join(inp_dir, f))
    trans_file = next(
        (f for f in trans_candidates if f and os.path.isfile(f)), None)
    if trans_file is None:
        logging.error(
            "%s: no trans file found. Set dipole_fitting.trans_path "
            "or place *-trans.fif next to the input file.",
            label)
        return None

    return fs_dir, subject, subjects_dir, bem_file, trans_file, is_fsaverage


def _erp_dipole_fit(eeg, data_label, base, mne_dir, config, params):
    """Classical ERP dipole fitting — MNE tutorial standard.

    Averages epochs per condition, computes noise covariance from the
    baseline, fits one dipole per time sample via mne.fit_dipole, and
    produces brain cross-section plots + ConnectiVIS 3D exports.

    Reference: https://mne.tools/stable/auto_tutorials/inverse/20_dipole_fit.html
    """
    import mne
    from .dipole.visualize import (
        _head_to_mni, export_electrodes_dat,
        export_fsaverage_brain_ply, export_fsaverage_head_ply,
        fsaverage_brain_ply_path)

    setup = _resolve_inverse_setup(config, "ERP dipole fit")
    if setup is None:
        return
    fs_dir, subject, subjects_dir, bem_file, trans_file, is_fsaverage = setup

    time_min = float(params.get("time_min", 0))
    time_max = float(params.get("time_max", 0))
    min_gof = float(params.get("min_gof", 50))
    min_dist = float(params.get("min_dist", 5.0))
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)
    pos_str = params.get("pos", "").strip()
    pos = _parse_dipole_pos(pos_str) if pos_str else None

    dip_dir = os.path.join(mne_dir, "erp_dipole_fit")
    os.makedirs(dip_dir, exist_ok=True)

    all_results = []
    cancel = config.get("_cancel_event")

    for tag in eeg.event_id:
        # Cancel check before each fit — each can take tens of
        # seconds and MNE spawns its own workers, so without this
        # Stop has no effect across event types.
        if cancel is not None and cancel.is_set():
            logging.info("ERP dipole fit cancelled by user.")
            raise InterruptedError("ERP dipole fit cancelled by user")

        evoked = eeg[tag].average()

        # Crop to time window if specified
        if time_max > time_min:
            evoked = evoked.crop(tmin=time_min, tmax=time_max)

        # Noise covariance from the baseline period
        cov = mne.compute_covariance(
            eeg[tag], tmax=0, method="auto", verbose=False)

        # Fit dipoles — the core MNE tutorial call
        logging.info("ERP dipole fit: fitting %s (%d time points, "
                     "%d channels)...", tag, len(evoked.times),
                     len(evoked.ch_names))
        try:
            dip, residual = mne.fit_dipole(
                evoked, cov, bem_file, trans=trans_file,
                min_dist=min_dist, pos=pos, n_jobs=n_jobs,
                verbose=False)
        except InterruptedError:
            raise
        except Exception as exc:
            logging.error("ERP dipole fit failed for %s: %s", tag, exc)
            continue

        # Filter by GOF
        good = dip.gof >= min_gof
        n_good = int(np.sum(good))
        logging.info("ERP dipole fit: %s — %d/%d time points with "
                     "GOF >= %.0f%%", tag, n_good, len(dip.times),
                     min_gof)

        if n_good == 0:
            logging.warning("ERP dipole fit: no dipoles above "
                            "%.0f%% GOF for %s", min_gof, tag)
            continue

        # MNE's own cross-section plots
        try:
            fig = dip.plot_locations(
                trans_file, subject, subjects_dir,
                mode="outlines", show=False)
            fig.suptitle(f"ERP dipoles: {tag} (GOF >= {min_gof:.0f}%)")
            _save(fig, dip_dir, base, "erp_dipole_fit", tag,
                  "outlines")
        except Exception as exc:
            logging.warning("Dipole outlines plot failed: %s", exc)

        # Collect results for ConnectiVIS export
        for i in range(len(dip.times)):
            if dip.gof[i] >= min_gof:
                all_results.append({
                    "pos": dip.pos[i],
                    "ori": dip.ori[i],
                    "gof": dip.gof[i],
                    "amplitude": dip.amplitude[i] * 1e9,
                    "time": dip.times[i],
                    "condition": tag,
                })

    if not all_results:
        logging.warning("ERP dipole fit: no dipoles passed the "
                        "GOF filter across all conditions.")
        return

    # MNI mm coordinates for ConnectiVIS (same conversion as
    # dipole_analysis.py; ERP dipoles are also in HEAD metres).
    has_mni = False
    try:
        positions = np.array([r["pos"] for r in all_results])
        mni_positions = _head_to_mni(positions, fs_dir)
        for r, mni in zip(all_results, mni_positions):
            r["mni_x_mm"] = mni[0]
            r["mni_y_mm"] = mni[1]
            r["mni_z_mm"] = mni[2]
        has_mni = True
    except (ImportError, OSError, RuntimeError) as exc:
        logging.warning("ERP dipole fit: MNI conversion failed, "
                        "CSV will lack mni columns: %s", exc)

    # ConnectiVIS companion files (brain PLY, head PLY, electrodes)
    try:
        if is_fsaverage:
            fsaverage_brain_ply_path(fs_dir=fs_dir)
        else:
            export_fsaverage_brain_ply(
                os.path.join(dip_dir, f"{base}___brain.ply"),
                fs_dir=fs_dir)
            export_fsaverage_head_ply(
                os.path.join(dip_dir, f"{base}___head.ply"),
                fs_dir=fs_dir)
        export_electrodes_dat(
            eeg.info,
            os.path.join(dip_dir, f"{base}___electrodes.dat"),
            fs_dir=fs_dir)
    except Exception as exc:
        logging.error("ConnectiVIS export failed: %s", exc)

    # CSV — ConnectiVIS reads this directly (no .dat needed)
    try:
        import csv
        fieldnames = [
            "condition", "time_s", "pos_x", "pos_y", "pos_z",
            "ori_x", "ori_y", "ori_z", "gof_pct", "amplitude_nAm"]
        if has_mni:
            fieldnames.extend(["mni_x_mm", "mni_y_mm", "mni_z_mm"])
        csv_path = os.path.join(
            dip_dir, f"{base}___erp_dipoles.csv")
        with open(csv_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for r in all_results:
                row = {
                    "condition": r["condition"],
                    "time_s": f"{r['time']:.4f}",
                    "pos_x": f"{r['pos'][0]:.6f}",
                    "pos_y": f"{r['pos'][1]:.6f}",
                    "pos_z": f"{r['pos'][2]:.6f}",
                    "ori_x": f"{r['ori'][0]:.6f}",
                    "ori_y": f"{r['ori'][1]:.6f}",
                    "ori_z": f"{r['ori'][2]:.6f}",
                    "gof_pct": f"{r['gof']:.1f}",
                    "amplitude_nAm": f"{r['amplitude']:.2f}",
                }
                if has_mni:
                    row["mni_x_mm"] = f"{r['mni_x_mm']:.4f}"
                    row["mni_y_mm"] = f"{r['mni_y_mm']:.4f}"
                    row["mni_z_mm"] = f"{r['mni_z_mm']:.4f}"
                w.writerow(row)
        logging.info("ERP dipoles CSV: %s (%d dipoles)",
                     csv_path, len(all_results))
    except Exception as exc:
        logging.error("ERP dipoles CSV failed: %s", exc)

    logging.info("ERP dipole fit: %d dipoles total across %d conditions",
                 len(all_results), len(eeg.event_id))


def _build_forward_solution(info, trans, fs_dir, subject, spacing, n_jobs):
    """Build source space + forward solution.  Shared by every
    distributed-source entry (MNE family, LCMV, MxNE).

    Mirrors the MNE inverse tutorial:
    https://mne.tools/stable/auto_tutorials/inverse/30_mne_dspm_loreta.html
    """
    import mne
    subjects_dir = os.path.join(fs_dir, "..")
    src = mne.setup_source_space(
        subject, spacing=spacing, subjects_dir=subjects_dir,
        verbose=False)
    bem_candidates = [
        os.path.join(fs_dir, "bem", f"{subject}-5120-5120-5120-bem-sol.fif"),
        os.path.join(fs_dir, "bem", f"{subject}-5120-bem-sol.fif"),
    ]
    bem_file = next((f for f in bem_candidates if os.path.isfile(f)), None)
    fwd = mne.make_forward_solution(
        info, trans=trans, src=src, bem=bem_file,
        eeg=True, mindist=5.0, n_jobs=n_jobs, verbose=False)
    return fwd


def _save_stc_screenshot(stc, fs_dir, dip_dir, base, tag, method_label):
    """Save a 3D PyVista screenshot of a SourceEstimate to PNG.

    Tries offscreen rendering; falls back to a no-op if PyVista or
    its 3D context isn't available (logs a warning so the user knows
    only the .h5 was saved).
    """
    import mne
    try:
        # Force offscreen so the call doesn't pop a window during a
        # background pipeline run.  Some backends raise on offscreen;
        # if so we just skip the screenshot.
        mne.viz.set_3d_options(antialias=False)
    except Exception:
        pass
    try:
        subject = os.path.basename(fs_dir)
        subjects_dir = os.path.join(fs_dir, "..")
        peak_time, _ = stc.get_peak()
        brain = stc.plot(
            subject=subject, subjects_dir=subjects_dir,
            hemi="both", initial_time=peak_time,
            time_viewer=False, show_traces=False,
            background="white", foreground="black",
            verbose=False)
        png_path = os.path.join(
            dip_dir,
            f"{base}___MNE___{_safe_tag(tag)}___{method_label}.png")
        brain.save_image(png_path)
        brain.close()
        logging.info("Source estimate screenshot: %s", png_path)
    except Exception as exc:
        logging.warning(
            "Source estimate screenshot for %s/%s failed (PyVista "
            "may need a working 3D context): %s",
            tag, method_label, exc)


def _save_stc(stc, dip_dir, base, tag, method_label):
    """Save a SourceEstimate as ``*-stc.h5`` for later replay in MNE."""
    h5_path = os.path.join(
        dip_dir,
        f"{base}___{_safe_tag(tag)}___{method_label}-stc.h5")
    try:
        stc.save(h5_path, ftype="h5", overwrite=True, verbose=False)
        logging.info("Source estimate saved: %s", h5_path)
    except Exception as exc:
        logging.warning("Source estimate .h5 save failed: %s", exc)


def _stc_peaks_to_dipole_rows(stc, fs_dir, n_peaks, tag):
    """Turn a SourceEstimate's top-N peak vertices into the same
    dipole-row dict format used by ``_erp_dipole_fit``.  Lets MxNE's
    sparse output reuse the existing ConnectiVIS CSV writer.
    """
    import mne
    subject = os.path.basename(fs_dir)
    subjects_dir = os.path.join(fs_dir, "..")
    # Vertex magnitudes: max over time for each vertex.
    data = np.abs(stc.data)
    if data.size == 0:
        return []
    vert_mag = data.max(axis=1)
    if not np.any(vert_mag > 0):
        return []
    n = min(n_peaks, int((vert_mag > 0).sum()))
    top_idx = np.argsort(vert_mag)[-n:][::-1]
    # Map flat vertex indices into (hemi, vertex_id) pairs.
    n_lh = len(stc.vertices[0])
    rows = []
    for flat_i in top_idx:
        if flat_i < n_lh:
            hemi_i, vert_id = 0, stc.vertices[0][flat_i]
        else:
            hemi_i, vert_id = 1, stc.vertices[1][flat_i - n_lh]
        # MNI position via FreeSurfer surface RAS → MNI.
        pos_mni = mne.vertex_to_mni(
            int(vert_id), hemi_i, subject=subject,
            subjects_dir=subjects_dir, verbose=False)
        # Approx HEAD-coord position: use MNI/1000 (m) as a stand-in.
        # ConnectiVIS uses MNI mm columns directly; the HEAD-coord
        # columns are decorative for this output type.
        pos_head = np.array(pos_mni) / 1000.0
        rows.append({
            "pos": pos_head,
            "ori": np.zeros(3),  # MxNE doesn't yield a single ori
            "gof": 100.0,        # not applicable; placeholder
            "amplitude": float(vert_mag[flat_i]),
            "time": float(stc.times[int(np.argmax(np.abs(stc.data[flat_i])))]),
            "condition": tag,
            "mni_x_mm": float(pos_mni[0]),
            "mni_y_mm": float(pos_mni[1]),
            "mni_z_mm": float(pos_mni[2]),
        })
    return rows


def _export_connectivis_scene(eeg_info, fs_dir, out_dir, base, label):
    """Write the ConnectiVIS scene companion files (brain PLY, head
    PLY, electrodes DAT) next to a dipoles CSV.  ``label`` is used
    only in the failure log (e.g. ``"MxNE"``, ``"MNE inverse"``).
    """
    from .dipole.visualize import (
        export_electrodes_dat,
        export_fsaverage_brain_ply, export_fsaverage_head_ply,
        fsaverage_brain_ply_path)
    is_fsaverage = os.path.basename(fs_dir) == "fsaverage"
    try:
        if is_fsaverage:
            fsaverage_brain_ply_path(fs_dir=fs_dir)
        else:
            export_fsaverage_brain_ply(
                os.path.join(out_dir, f"{base}___brain.ply"),
                fs_dir=fs_dir)
            export_fsaverage_head_ply(
                os.path.join(out_dir, f"{base}___head.ply"),
                fs_dir=fs_dir)
        export_electrodes_dat(
            eeg_info,
            os.path.join(out_dir, f"{base}___electrodes.dat"),
            fs_dir=fs_dir)
    except Exception as exc:
        logging.error("%s: ConnectiVIS scene export failed: %s",
                      label, exc)


def _write_source_dipoles_csv(rows, dip_dir, base, suffix):
    """Write a dipoles CSV in the same format ``_erp_dipole_fit``
    uses, so ConnectiVIS picks it up via the existing convention.
    """
    import csv
    fieldnames = [
        "condition", "time_s", "pos_x", "pos_y", "pos_z",
        "ori_x", "ori_y", "ori_z", "gof_pct", "amplitude_nAm",
        "mni_x_mm", "mni_y_mm", "mni_z_mm"]
    csv_path = os.path.join(dip_dir, f"{base}___{suffix}_dipoles.csv")
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({
                "condition": r["condition"],
                "time_s": f"{r['time']:.4f}",
                "pos_x": f"{r['pos'][0]:.6f}",
                "pos_y": f"{r['pos'][1]:.6f}",
                "pos_z": f"{r['pos'][2]:.6f}",
                "ori_x": f"{r['ori'][0]:.6f}",
                "ori_y": f"{r['ori'][1]:.6f}",
                "ori_z": f"{r['ori'][2]:.6f}",
                "gof_pct": f"{r['gof']:.1f}",
                "amplitude_nAm": f"{r['amplitude']:.4g}",
                "mni_x_mm": f"{r.get('mni_x_mm', 0):.4f}",
                "mni_y_mm": f"{r.get('mni_y_mm', 0):.4f}",
                "mni_z_mm": f"{r.get('mni_z_mm', 0):.4f}",
            })
    logging.info("%s dipoles CSV: %s (%d rows)",
                 suffix, csv_path, len(rows))


def _mne_inverse(eeg, data_label, base, mne_dir, config, params):
    """Distributed source estimation via the MNE/dSPM/sLORETA/eLORETA
    minimum-norm family.

    Reference:
    https://mne.tools/stable/auto_tutorials/inverse/30_mne_dspm_loreta.html
    """
    import mne
    from mne.minimum_norm import make_inverse_operator, apply_inverse

    setup = _resolve_inverse_setup(config, "MNE inverse")
    if setup is None:
        return
    fs_dir, subject, subjects_dir, bem_file, trans_file, _ = setup

    method = params.get("method", "dSPM")
    snr = float(params.get("snr", 3.0))
    lambda2 = 1.0 / max(snr, 1e-3) ** 2
    loose = float(params.get("loose", 0.2))
    depth = float(params.get("depth", 0.8))
    spacing = params.get("spacing", "ico4")
    n_peaks = int(params.get("n_peaks", 0))
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)

    out_dir = os.path.join(mne_dir, "mne_inverse")
    os.makedirs(out_dir, exist_ok=True)

    fwd = _build_forward_solution(
        eeg.info, trans_file, fs_dir, subject, spacing, n_jobs)

    all_rows = []
    for tag in eeg.event_id:
        # Per-tag try/except — one bad condition (singular noise_cov,
        # too few epochs, etc.) shouldn't abort every subsequent tag.
        try:
            evoked = eeg[tag].average()
            noise_cov = mne.compute_covariance(
                eeg[tag], tmax=0., method="auto", verbose=False)
            inv = make_inverse_operator(
                evoked.info, fwd, noise_cov, loose=loose, depth=depth,
                verbose=False)
            stc = apply_inverse(
                evoked, inv, lambda2=lambda2, method=method,
                pick_ori=None, verbose=False)
            _save_stc(stc, out_dir, base, tag, method)
            _save_stc_screenshot(stc, fs_dir, out_dir, base, tag, method)
            if n_peaks > 0:
                all_rows.extend(_stc_peaks_to_dipole_rows(
                    stc, fs_dir, n_peaks=n_peaks, tag=tag))
        except Exception as exc:
            logging.error("MNE inverse (%s) failed for '%s': %s",
                          method, tag, exc, exc_info=True)
            continue

    if all_rows:
        _export_connectivis_scene(
            eeg.info, fs_dir, out_dir, base, "MNE inverse")
        _write_source_dipoles_csv(
            all_rows, out_dir, base, f"mne_inverse_{method.lower()}")

    logging.info("MNE inverse (%s): %d conditions written to %s",
                 method, len(eeg.event_id), out_dir)


def _lcmv_beamformer(eeg, data_label, base, mne_dir, config, params):
    """Linearly Constrained Minimum-Variance beamformer.

    Reference:
    https://mne.tools/stable/auto_tutorials/inverse/50_beamformer_lcmv.html
    """
    import mne
    from mne.beamformer import make_lcmv, apply_lcmv

    setup = _resolve_inverse_setup(config, "LCMV beamformer")
    if setup is None:
        return
    fs_dir, subject, subjects_dir, bem_file, trans_file, _ = setup

    reg = float(params.get("reg", 0.05))
    pick_ori = params.get("pick_ori", "max-power")
    weight_norm = params.get("weight_norm", "unit-noise-gain")
    if weight_norm == "none":
        weight_norm = None
    spacing = params.get("spacing", "ico4")
    n_peaks = int(params.get("n_peaks", 0))
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)

    out_dir = os.path.join(mne_dir, "lcmv_beamformer")
    os.makedirs(out_dir, exist_ok=True)

    fwd = _build_forward_solution(
        eeg.info, trans_file, fs_dir, subject, spacing, n_jobs)

    all_rows = []
    for tag in eeg.event_id:
        # Per-tag try/except — one bad condition (singular data_cov,
        # rank-deficient signal, etc.) shouldn't abort every
        # subsequent tag.
        try:
            evoked = eeg[tag].average()
            noise_cov = mne.compute_covariance(
                eeg[tag], tmax=0., method="auto", verbose=False)
            # Data covariance from the post-stimulus window (matches
            # the MNE LCMV tutorial's signal-covariance pattern).
            data_cov = mne.compute_covariance(
                eeg[tag], tmin=0., method="empirical", verbose=False)
            filters = make_lcmv(
                evoked.info, fwd, data_cov, reg=reg,
                noise_cov=noise_cov, pick_ori=pick_ori,
                weight_norm=weight_norm, verbose=False)
            stc = apply_lcmv(evoked, filters, verbose=False)
            _save_stc(stc, out_dir, base, tag, "LCMV")
            _save_stc_screenshot(stc, fs_dir, out_dir, base, tag, "LCMV")
            if n_peaks > 0:
                all_rows.extend(_stc_peaks_to_dipole_rows(
                    stc, fs_dir, n_peaks=n_peaks, tag=tag))
        except Exception as exc:
            logging.error("LCMV beamformer failed for '%s': %s",
                          tag, exc, exc_info=True)
            continue

    if all_rows:
        _export_connectivis_scene(
            eeg.info, fs_dir, out_dir, base, "LCMV beamformer")
        _write_source_dipoles_csv(all_rows, out_dir, base, "lcmv")

    logging.info("LCMV beamformer: %d conditions written to %s",
                 len(eeg.event_id), out_dir)


def _mxne(eeg, data_label, base, mne_dir, config, params):
    """Sparse source estimation via mixed-norm regularisation (MxNE).
    Sparse output is written as a dipoles CSV that ConnectiVIS reads
    natively.

    Reference:
    https://mne.tools/stable/auto_examples/inverse/mixed_norm_inverse.html
    """
    import mne
    from mne.inverse_sparse import mixed_norm

    setup = _resolve_inverse_setup(config, "MxNE")
    if setup is None:
        return
    fs_dir, subject, subjects_dir, bem_file, trans_file, _ = setup

    alpha = float(params.get("alpha", 80.0))
    depth = float(params.get("depth", 0.9))
    loose = float(params.get("loose", 0.2))
    n_mxne_iter = int(params.get("n_mxne_iter", 1))
    spacing = params.get("spacing", "ico4")
    n_jobs = config.get("parallelism", {}).get("n_jobs", 1)

    out_dir = os.path.join(mne_dir, "mxne")
    os.makedirs(out_dir, exist_ok=True)

    fwd = _build_forward_solution(
        eeg.info, trans_file, fs_dir, subject, spacing, n_jobs)

    all_rows = []
    for tag in eeg.event_id:
        evoked = eeg[tag].average()
        noise_cov = mne.compute_covariance(
            eeg[tag], tmax=0., method="auto", verbose=False)
        try:
            stc = mixed_norm(
                evoked, fwd, noise_cov, alpha=alpha, loose=loose,
                depth=depth, n_mxne_iter=n_mxne_iter,
                return_residual=False, verbose=False)
        except Exception as exc:
            logging.error("MxNE failed for %s: %s", tag, exc)
            continue
        _save_stc(stc, out_dir, base, tag, "MxNE")
        _save_stc_screenshot(stc, fs_dir, out_dir, base, tag, "MxNE")
        # Export every non-zero source as a dipole row — MxNE's
        # output is sparse by construction (often <20 vertices).
        n_active = int((np.abs(stc.data).max(axis=1) > 0).sum()) or 1
        all_rows.extend(_stc_peaks_to_dipole_rows(
            stc, fs_dir, n_peaks=n_active, tag=tag))

    if not all_rows:
        logging.warning("MxNE: no active sources across any condition.")
        return

    _export_connectivis_scene(
        eeg.info, fs_dir, out_dir, base, "MxNE")
    _write_source_dipoles_csv(all_rows, out_dir, base, "mxne")
    logging.info("MxNE: %d active sources total across %d conditions",
                 len(all_rows), len(eeg.event_id))


# ── Dispatch table ───────────────────────────────────────────────────
# Defined at module scope (after all handler functions) so tests and
# other consumers can introspect the routing without parsing source
# code.  Keep in sync with the catalog `id` values above.
_DISPATCH = {
    "erp_butterfly": _erp_butterfly,
    "erp_image": _erp_image,
    "erp_joint": _erp_joint,
    "erp_topomap": _erp_topomap,
    "gfp": _gfp,
    "psd_topomap": _psd_topomap,
    "psd_multitaper": _psd_multitaper,
    "psd_welch": _psd_welch,
    "psd_topo": _psd_topo,
    "tfr_morlet": _tfr_morlet,
    "tfr_multitaper": _tfr_multitaper,
    "erds_topomap": _erds_topomap,
    "evoked_topomap_anim": _evoked_topomap_anim,
    "channel_locations": _channel_locations,
    "cluster_permutation": _cluster_permutation,
    "compare_evokeds": _compare_evokeds,
    "drop_log": _drop_log,
    "evoked_image": _evoked_image,
    "compare_per_channel": _compare_per_channel,
    "erp_dipole_fit": _erp_dipole_fit,
    "mne_inverse": _mne_inverse,
    "lcmv_beamformer": _lcmv_beamformer,
    "mxne": _mxne,
}
