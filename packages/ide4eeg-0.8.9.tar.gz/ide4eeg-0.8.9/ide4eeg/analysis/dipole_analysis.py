### Piotr Biegański

"""Dipole fitting analysis for IDE4EEG.

Fits equivalent current dipoles to Multivariate Matching Pursuit
(MMP) macroatoms using the fsaverage template brain via MNE-Python.
Requires a preprocessing MMP book (.db) produced by empi.

Adapted from mp-dip by Marian Dovgialo and Piotr Biegański
"""



import csv
import logging
import os
import sqlite3

import matplotlib.pyplot as plt
import numpy as np

from .dipole.fitting import (
    fit_all_dipoles,
    compute_cortical_distances,
    _HAS_MNE,
    _HAS_NIBABEL,
)
from .dipole.visualize import (
    plot_dipole_gof_histogram,
    fsaverage_brain_ply_path, export_fsaverage_brain_ply,
    export_fsaverage_head_ply, export_electrodes_dat, scatter_3d)


def _find_mmp_book(config, path):
    """Locate an MMP book, validating that it is multivariate.

    Checks ``_mp_book_path`` from config first, then falls back to
    scanning the ``mp_decomposition/`` output directory for MMP books.

    Returns
    -------
    book_path : str or None
        Path to a valid MMP book, or None if not found.
    error : str or None
        Human-readable error message if no valid book was found.
    """
    book_path = config.get("_mp_book_path", "")

    # Fallback: scan output directories for .db files.
    # The book lives in preprocessing/mp_decomposition/ but `path` is the
    # analysis output dir — check both the sibling preprocessing dir and
    # the analysis dir itself.
    if not book_path or not os.path.isfile(book_path):
        search_dirs = [
            os.path.join(path, "mp_decomposition"),
            os.path.join(os.path.dirname(path), "preprocessing",
                         "mp_decomposition"),
        ]
        for mp_dir in search_dirs:
            if not os.path.isdir(mp_dir):
                continue
            dbs = [f for f in os.listdir(mp_dir) if f.endswith(".db")]
            # Dipole fitting requires MMP1 (constant phase)
            mmp_dbs = [f for f in dbs if "_mmp1.db" in f]
            if mmp_dbs:
                book_path = os.path.join(mp_dir, sorted(mmp_dbs)[-1])
                break
            elif dbs:
                book_path = os.path.join(mp_dir, sorted(dbs)[-1])
                break

    if not book_path or not os.path.isfile(book_path):
        return None, (
            "No MP book (.db) found. "
            "Run MP decomposition with MMP1 algorithm first.")

    # Validate: must be MMP, not SMP
    algorithm = ""
    try:
        with sqlite3.connect(book_path) as conn:
            row = conn.execute(
                "SELECT value FROM metadata WHERE param='algorithm'"
            ).fetchone()
            if row:
                algorithm = row[0].upper()
    except sqlite3.Error as e:
        logging.warning("Dipole: could not read book metadata: %s", e)

    if algorithm and algorithm != "MMP1":
        return None, (
            f"Book '{os.path.basename(book_path)}' uses {algorithm} "
            f"decomposition. Dipole fitting requires MMP1 (constant "
            f"phase) — re-run MP decomposition with algorithm set "
            f"to MMP1.")

    return book_path, None


def dipole_analysis(rest, epochs, config, path, file_name):
    """Run dipole fitting analysis on MMP decomposition results.

    Parameters
    ----------
    rest : mne.Epochs or None
        Clean rest segments (used for channel names / sfreq).
    epochs : mne.Epochs or None
        Clean epochs (used for channel names / sfreq).
    config : dict
        Pipeline configuration.
    path : str
        Output directory.
    file_name : str
        Base file name for output files.
    """
    if not _HAS_MNE:
        logging.error("Dipole fitting requires MNE-Python. Skipping.")
        return

    dip_cfg = config.get("dipole_fitting", {})

    book_path, book_error = _find_mmp_book(config, path)
    if book_error:
        logging.error("Dipole fitting: %s", book_error)
        return

    # Always read the book's channel list — this is the ground truth for
    # what was decomposed.  Use MNE data only for sfreq when available.
    data = rest if rest is not None else epochs
    montage_name = dip_cfg.get("montage", "standard_1005")

    from .mp_analysis import read_book_channel_names
    all_ch_names = read_book_channel_names(book_path)
    try:
        with sqlite3.connect(book_path) as conn:
            row = conn.execute(
                "SELECT value FROM metadata "
                "WHERE param='sampling_frequency_Hz'").fetchone()
        book_sfreq = float(row[0]) if row else 0
    except (sqlite3.Error, ValueError):
        book_sfreq = 0

    if data is not None:
        sfreq = data.info["sfreq"]
        # Build EEG mask from MNE channel types if book channels match data
        data_ch_names = list(data.info["ch_names"])
        data_ch_types = dict(zip(data_ch_names, data.get_channel_types()))
        eeg_mask = [data_ch_types.get(c, "") == "eeg" for c in all_ch_names]
        # If no channel matched as EEG (e.g. book channels not in data),
        # fall back to montage
        if not any(eeg_mask):
            eeg_mask = None
    else:
        sfreq = book_sfreq
        eeg_mask = None

    if not all_ch_names or not sfreq:
        logging.error("Dipole fitting: book lacks channel/sfreq metadata "
                      "and no MNE data available.")
        return

    # Fall back to montage-based EEG identification
    if eeg_mask is None:
        try:
            import mne
            mtg = mne.channels.make_standard_montage(montage_name)
            montage_chs = set(mtg.ch_names)
            eeg_mask = [c in montage_chs for c in all_ch_names]
        except Exception:
            eeg_mask = [True] * len(all_ch_names)

    # Build set of channels to exclude: non-EEG + user-specified ignored
    ignored = set()
    ignored_raw = dip_cfg.get("ignored_channels", "")
    if ignored_raw:
        if isinstance(ignored_raw, list):
            ignored = {c.strip() for c in ignored_raw if c.strip()}
        else:
            ignored = {c.strip() for c in str(ignored_raw).split(",")
                       if c.strip()}
    unknown_ignored = ignored - set(all_ch_names)
    if unknown_ignored:
        logging.warning(
            "Dipole fitting: ignored_channels contains names not in book "
            "(%s) — they will have no effect: %s",
            os.path.basename(book_path),
            ", ".join(sorted(unknown_ignored)))

    keep_indices = []
    keep_names = []
    dropped_non_eeg = []
    dropped_ignored = []
    for i, (name, is_eeg) in enumerate(zip(all_ch_names, eeg_mask)):
        if not is_eeg:
            dropped_non_eeg.append(name)
        elif name in ignored:
            dropped_ignored.append(name)
        else:
            keep_indices.append(i)
            keep_names.append(name)

    if dropped_non_eeg:
        logging.info("Dipole fitting: excluded %d non-EEG channel(s): %s",
                     len(dropped_non_eeg), ", ".join(dropped_non_eeg))
    if dropped_ignored:
        logging.info("Dipole fitting: excluded %d user-ignored channel(s): %s",
                     len(dropped_ignored), ", ".join(dropped_ignored))

    ch_names = keep_names
    if not ch_names:
        logging.error("Dipole fitting: no EEG channels left.")
        return

    out_dir = os.path.join(path, "dipole_analysis")
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(file_name)[0]

    ref_channel = dip_cfg.get("ref_channel", "average")
    montage = montage_name
    max_iterations = int(dip_cfg.get("max_iterations", 0)) or None
    min_gof = float(dip_cfg.get("min_gof", 0))
    compute_cortex = dip_cfg.get("cortical_distance", False)
    fs_dir = dip_cfg.get("fsaverage_dir", "") or None

    # Atom filtering criteria (frequency/scale bounds, 0 = no limit)
    freq_min = float(dip_cfg.get("freq_min", 0))
    freq_max = float(dip_cfg.get("freq_max", 0))
    scale_min = float(dip_cfg.get("scale_min", 0))
    scale_max = float(dip_cfg.get("scale_max", 0))
    amp_min = float(dip_cfg.get("amp_min", 0))
    amp_max = float(dip_cfg.get("amp_max", 0))

    logging.info(
        "Dipole fitting: %d EEG channels (of %d total), book=%s, ref=%s",
        len(ch_names), len(all_ch_names),
        os.path.basename(book_path), ref_channel)

    # Use manually picked atoms from BookViewer if available
    picked_atoms = dip_cfg.get("_picked_atoms")
    if picked_atoms:
        logging.info("Dipole fitting: using %d manually selected atoms.",
                     len(picked_atoms))

    # Apply per-module worker override if set (cpu_workers > 0),
    # otherwise inherit from the global parallelism.n_jobs.
    # fit_all_dipoles uses joblib.Parallel without n_jobs=, so it
    # reads the process-wide joblib.parallel_config default.
    import joblib
    dip_workers = int(dip_cfg.get("cpu_workers", 0))
    if dip_workers > 0:
        _ctx = joblib.parallel_config(n_jobs=dip_workers)
    else:
        from contextlib import nullcontext
        _ctx = nullcontext()

    with _ctx:
        results = fit_all_dipoles(
            book_path, ch_names, sfreq,
            n_book_channels=len(all_ch_names),
            keep_channel_indices=keep_indices,
            ref_channel=ref_channel,
            montage=montage,
            max_iterations=max_iterations,
            min_gof=min_gof,
            fs_dir=fs_dir,
            picked_atoms=picked_atoms,
            freq_range=(freq_min, freq_max) if freq_min or freq_max else None,
            scale_range=(scale_min, scale_max) if scale_min or scale_max else None,
            amp_range=(amp_min, amp_max) if amp_min or amp_max else None,
            cancel_event=config.get("_cancel_event"))

    if not results:
        logging.warning("Dipole fitting: no dipoles fitted.")
        return

    # Cortical distance (optional)
    if compute_cortex and _HAS_NIBABEL:
        compute_cortical_distances(results, fs_dir=fs_dir)

    # MNI mm coordinates for the CSV (and ConnectiVIS).
    # pos_x/y/z are in MNE HEAD metres; mni_x/y/z_mm are in MNI mm —
    # the same coordinate frame used by the brain/head PLY and
    # electrodes.dat exports, ready for 3D rendering.
    try:
        from .dipole.visualize import _head_to_mni
        positions = np.array([r["pos"] for r in results])
        mni_positions = _head_to_mni(positions, fs_dir)
        for r, mni in zip(results, mni_positions):
            r["mni_x_mm"] = mni[0]
            r["mni_y_mm"] = mni[1]
            r["mni_z_mm"] = mni[2]
    except (ImportError, OSError, RuntimeError) as exc:
        logging.warning("Dipole: MNI coordinate conversion failed, "
                        "CSV will not contain mni columns: %s", exc)

    # Write CSV
    csv_path = os.path.join(out_dir, f"{base}___dipoles.csv")
    _write_dipole_csv(results, csv_path)

    # Export ConnectiVIS files — all in surface RAS mm.
    # For fsaverage: brain PLY cached in ~/.obci/connectivis/,
    #   head PLY skipped (featureless — ConnectiVIS uses its
    #   built-in AC3D head with face instead).
    # For subject-specific: brain + head PLYs written per-run
    #   to the output dir (subject's own anatomy with real face).
    if fs_dir is None:
        from .dipole.fitting import _ensure_fsaverage
        fs_dir = _ensure_fsaverage(None)
    is_fsaverage = os.path.basename(fs_dir or "") == "fsaverage"
    try:
        # Legacy .dat export removed — ConnectiVIS now reads
        # ___dipoles.csv directly (richer: GOF, amplitude, frequency).
        if is_fsaverage:
            fsaverage_brain_ply_path(fs_dir=fs_dir)
        else:
            export_fsaverage_brain_ply(
                os.path.join(out_dir, f"{base}___brain.ply"),
                fs_dir=fs_dir)
            export_fsaverage_head_ply(
                os.path.join(out_dir, f"{base}___head.ply"),
                fs_dir=fs_dir)
        signal_info = (rest.info if rest is not None
                       else epochs.info if epochs is not None
                       else None)
        if signal_info is not None:
            export_electrodes_dat(
                signal_info,
                os.path.join(out_dir, f"{base}___electrodes.dat"),
                fs_dir=fs_dir)
    except Exception as exc:
        logging.error("Dipole: ConnectiVIS export failed: %s",
                      exc, exc_info=True)

    plot_dipole_gof_histogram(
        results,
        os.path.join(out_dir, f"{base}___dipole_gof.png"))

    if _HAS_NIBABEL:
        for color_by in ['frequency', 'gof', 'amplitude']:
            scatter_3d(results,
                    color_by,
                    os.path.join(out_dir, f"{base}___dipole_brain_{color_by}.png"),
                    fs_dir)
    else:
        logging.warning("Plotting the dipoles position require nibabel.")

    logging.info("Dipole analysis: %d dipoles saved to %s",
                 len(results), out_dir)


def _write_dipole_csv(results, csv_path):
    """Write dipole fitting results to CSV."""
    if not results:
        return

    fieldnames = [
        "segment_id", "iteration", "t0_s",
        "frequency_Hz", "scale_s",
        "pos_x", "pos_y", "pos_z",
        "ori_x", "ori_y", "ori_z",
        "gof_pct", "amplitude_nAm",
    ]
    if "cortex_dist_mm" in results[0]:
        fieldnames.insert(-1, "cortex_dist_mm")
    # MNI mm appended at the end — keeps existing column indices stable.
    has_mni = "mni_x_mm" in results[0]
    if has_mni:
        fieldnames.extend(["mni_x_mm", "mni_y_mm", "mni_z_mm"])

    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            row = {
                "segment_id": r["segment_id"],
                "iteration": r["iteration"],
                "t0_s": f"{r['t0']}",
                "frequency_Hz": f"{r['frequency']}",
                "scale_s": f"{r['scale']}",
                "pos_x": f"{r['pos'][0]}",
                "pos_y": f"{r['pos'][1]}",
                "pos_z": f"{r['pos'][2]}",
                "ori_x": f"{r['ori'][0]}",
                "ori_y": f"{r['ori'][1]}",
                "ori_z": f"{r['ori'][2]}",
                "gof_pct": f"{r['gof']}",
                "amplitude_nAm": f"{r['amplitude']}",
            }
            if "cortex_dist_mm" in r:
                row["cortex_dist_mm"] = f"{r['cortex_dist_mm']}"
            if has_mni:
                row["mni_x_mm"] = f"{r['mni_x_mm']:.4f}"
                row["mni_y_mm"] = f"{r['mni_y_mm']:.4f}"
                row["mni_z_mm"] = f"{r['mni_z_mm']:.4f}"
            writer.writerow(row)

    logging.info("Dipole CSV: %s", csv_path)
