"""Analysis orchestrator for IDE4EEG.

Dispatches time-domain and time-frequency analyses based on config flags.
"""

# Author: Szymon Bocian, 2023

from .eeg_profiles import eeg_profiles
from .connectivity_analysis import connectivity_analysis
from .dipole_analysis import dipole_analysis

import logging
import matplotlib.pyplot as plt

def analysis(rest, rest_clean, epochs, epochs_clean, data, config, path, tags_desc_id, file_name):
    '''
    Preparing analysis and plots for the prepared epochs.

    .. note::
       Forces the matplotlib backend to ``Agg`` for the duration of
       the run.  This function executes in the GUI's analysis worker
       thread, and a Qt backend in a worker thread segfaults on Linux
       inside ``plt.subplots`` (X11/Cocoa GUI calls are not thread-
       safe).  Helpers downstream (eeg_profiles, connectivity, dipole,
       mne_catalog and their plot helpers) inherit the Agg state via
       matplotlib's global rcParams, so per-helper Agg preambles are
       unnecessary.  See ``preprocessing.preprocessing`` for the
       symmetric entry point on the preprocessing side.

    Parameters
    ----------
    rest: mne.epochs.Epochs or None
        Prepared rest segments from the signal. If None, REST path wasn't prepare in config file.
    rest_clean: mne.epochs.Epochs or None
        Prepared rest segments from the signal without segments with artifacts. If None, REST path wasn't
        prepare in config file.
    epochs: mne.epochs.Epochs or None
        Prepared epochs from the signal. If None, EPOCHS path wasn't prepare in config file.
    epochs_clean: mne.epochs.Epochs or None
        Prepared epochs from the signal without epochs with artifacts. If None, REST path wasn't
        prepare in config file.
    data: pandas.core.frame.DataFrame
        Dataframe with basic information about tags.
    config: dict
        Dictionary of configuration variables.
    path: str
        Path to the output directory.
    tags_desc_id: dict
        Dictionary of the names of prepared tags and their values in the prepared STIM signal.
    file_name: str
        Name of the file with raw signal.
    '''
    import matplotlib
    matplotlib.use("Agg")

    cancel = config.get("_cancel_event")

    def _check_cancel():
        if cancel is not None and cancel.is_set():
            logging.info("Analysis cancelled by user.")
            raise InterruptedError("Analysis cancelled by user")

    if config.get("prepare_eeg_profiles"):
        _check_cancel()
        logging.info("Preparing EEG profiles.")
        eeg_profiles(rest_clean, epochs_clean, config, path, file_name)

    if config.get("prepare_connectivity_analysis"):
        _check_cancel()
        logging.info("Preparing connectivity analysis.")
        connectivity_analysis(rest_clean, epochs_clean, config, path, file_name)

    if config.get("prepare_dipole_fitting"):
        _check_cancel()
        logging.info("Preparing dipole fitting analysis.")
        dipole_analysis(rest_clean, epochs_clean, config, path, file_name)

    # MNE catalog analyses
    mne_ids = config.get("mne_catalog", [])
    if mne_ids:
        _check_cancel()
        logging.info("Running MNE catalog analyses (%d selected).",
                     len(mne_ids))
        from .mne_catalog import run_mne_catalog
        run_mne_catalog(mne_ids, rest_clean, epochs_clean, config,
                        path, file_name)

    plt.close("all")