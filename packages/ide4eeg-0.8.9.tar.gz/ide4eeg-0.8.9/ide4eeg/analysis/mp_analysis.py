### Piotr Durka

"""Matching Pursuit analysis via empi.

Runs the empi decomposition on EEG segments, reads atom parameters
from the resulting SQLite database, generates Wigner time-frequency
energy maps, and optionally reconstructs signals from atoms matching
user-specified criteria (nonlinear filtering).
"""

# Author: Piotr Durka, 2026

import logging
import os
import re
import sqlite3
import subprocess
import tempfile

import numpy as np
import matplotlib.pyplot as plt

from . import _safe_tag


#: Matching-Pursuit algorithms supported by empi. Single source of truth
#: for the algorithm name (the empi flag), human-readable description, and
#: whether the algorithm is multichannel ("MMP" variants). The GUI combo
#: box, config save/load, MMP-only book filter, and the empi command-line
#: builder all derive from this dict.
#:
#: Order is the GUI combo display order. The first entry is the default.
MP_ALGORITHMS = {
    "smp":  {"label": "monovariate",                "multichannel": False},
    "mmp1": {"label": "multivariate, constant phase", "multichannel": True},
    "mmp3": {"label": "multivariate, variable phase", "multichannel": True},
}


def mp_algorithm_choices():
    """Return ``[(name, "name — label"), ...]`` for GUI combo population.

    The display string is what the combo shows; the name is what gets
    written to config and passed to empi.
    """
    return [(name, f"{name} \u2014 {meta['label']}")
            for name, meta in MP_ALGORITHMS.items()]


def mp_multichannel_algorithm_names():
    """Return the set of algorithm names whose ``multichannel`` flag is True.

    Used by the "MMP-only" book filter — books decomposed with these
    algorithms can be opened in multichannel viewers.
    """
    return {name for name, meta in MP_ALGORITHMS.items()
            if meta["multichannel"]}


def parse_mp_algorithm_label(label, default="smp"):
    """Extract the algorithm name from a combo box display label.

    Combo labels look like ``"mmp1 — multivariate, constant phase"``
    (see :func:`mp_algorithm_choices`). The first whitespace-delimited
    token is the algorithm name. Returns ``default`` if the parsed
    token isn't a known algorithm.
    """
    if not label:
        return default
    name = label.split()[0].lower()
    return name if name in MP_ALGORITHMS else default


def mp_analysis(rest, epochs, config, path, file_name):
    """Run Matching Pursuit analysis on rest and/or epoch data.

    If a preprocessing book (``.db``) exists (produced by
    ``mp_decompose``), atoms are read from it instead of re-running
    empi.  Otherwise falls back to decomposing the ERP per tag/channel.

    Parameters
    ----------
    rest : mne.Epochs or None
        Clean rest segments.
    epochs : mne.Epochs or None
        Clean epochs.
    config : dict
        Configuration dictionary.
    path : str
        Output directory.
    file_name : str
        Input file name (used in plot titles and filenames).
    """
    mp_path = os.path.join(path, "mp_analysis")
    os.makedirs(mp_path, exist_ok=True)

    mp_cfg = config.get("matching_pursuit", {})

    # Inherit the default worker count from parallelism.n_jobs so
    # empi uses the same parallelism knob as everything else by
    # default. An explicit matching_pursuit.cpu_workers still wins —
    # see the resolution comment in _build_empi_cmd.
    from ide4eeg.utils.parallel import resolve_n_jobs
    mp_cfg.setdefault("_default_workers", resolve_n_jobs(config))

    # ── Check for preprocessing book ─────────────────────────────────
    book_path = config.get("_mp_book_path")
    if book_path and os.path.isfile(book_path):
        logging.info("MP analysis: using preprocessing book %s", book_path)
        _analyze_from_book(rest, epochs, config, mp_cfg,
                           book_path, mp_path, file_name)
        return

    # ── Fallback: run empi directly on ERPs ──────────────────────────
    empi_path = mp_cfg.get("empi_path", "")
    if not empi_path or not os.path.isfile(empi_path):
        logging.error(
            "empi binary not found at '%s'. Skipping MP analysis.", empi_path)
        return

    sfreq = config["sfreq"]

    if rest is not None:
        _analyze_data_fresh(rest, sfreq, mp_cfg, empi_path, mp_path,
                            file_name, 0.0)

    if epochs is not None:
        t_offset = config.get("epochs", {}).get("start_offset", 0.0)
        _analyze_data_fresh(epochs, sfreq, mp_cfg, empi_path, mp_path,
                            file_name, t_offset)


def _analyze_from_book(rest, epochs, config, mp_cfg,
                       book_path, mp_path, file_name):
    """Generate analysis outputs from an existing preprocessing book.

    Reads per-segment, per-channel atoms from the book and produces:

    1. **Averaged Wigner maps** — time-frequency energy density
       averaged across all segments, per channel.
    2. **Atom statistics CSV** — per-channel summary of atom
       parameters (frequency, scale, energy, amplitude) across epochs.
    3. **Atom parameter histograms** — distribution of frequency,
       scale and energy across all epochs for each channel.
    4. **Reconstruction plots** — if reconstruction criteria are set,
       original vs filtered signal comparison with residual.
    """
    sfreq = config["sfreq"]
    base = os.path.splitext(file_name)[0]
    freq_max = mp_cfg.get("gabor_freq_max", 0) or sfreq / 2
    recon_cfg = mp_cfg.get("reconstruction", {})

    # Read book metadata for channel names
    try:
        with sqlite3.connect(book_path) as conn:
            meta = dict(conn.execute("SELECT param, value FROM metadata"))
        n_segments = int(meta.get("segment_count", 1))
        n_book_channels = int(meta.get("channel_count", 1))
        book_ch_names = meta.get("channel_names", "").split(",")
        if len(book_ch_names) != n_book_channels:
            book_ch_names = [f"Ch{i}" for i in range(n_book_channels)]
        scale_to_uV = float(meta.get("scale_to_uV", 1.0))
    except sqlite3.Error as e:
        logging.error("Cannot read book metadata: %s", e)
        return

    # Collect all atom stats for the CSV summary
    csv_rows = []

    # Process each data set (rest or epochs)
    for data, data_label, time_offset in [
        (rest, "rest", 0.0),
        (epochs, "epochs",
         config.get("epochs", {}).get("start_offset", 0.0)),
    ]:
        if data is None or len(data) == 0:
            continue

        data.load_data()
        data_picks = _pick_data_channels(data)
        signals = data.get_data(picks=data_picks)
        n_ep, n_ch, n_samples = signals.shape
        erp = np.mean(signals, axis=0)
        time = np.arange(n_samples) / sfreq + time_offset

        for ch_idx, ch_name in enumerate(data_picks):
            # Match channel to book channel index
            if ch_name in book_ch_names:
                book_ch_idx = book_ch_names.index(ch_name)
            elif ch_idx < n_book_channels:
                book_ch_idx = ch_idx
            else:
                continue

            # ── Collect atoms from all segments ───────────────────
            all_atoms = []
            wigner_avg = None
            for seg_id in range(n_segments):
                atoms = read_mp_results(book_path, seg_id, book_ch_idx)
                if not atoms:
                    continue
                all_atoms.extend(atoms)
                w, t_bins, f_bins = compute_wigner_map(
                    atoms, n_samples, sfreq,
                    time_offset=time_offset, freq_max=freq_max)
                if wigner_avg is None:
                    wigner_avg = w
                else:
                    wigner_avg += w
            if wigner_avg is not None and n_segments > 0:
                wigner_avg /= n_segments

            if not all_atoms:
                logging.warning(
                    "No atoms in book for channel %s", ch_name)
                continue

            # ── 1. Averaged Wigner map ────────────────────────────
            signal = erp[ch_idx]
            _plot_wigner(
                wigner_avg, t_bins, f_bins, time, signal,
                f"MP Wigner map: {data_label} ({n_ep} ep, "
                f"{len(all_atoms)} atoms) {ch_name}",
                os.path.join(
                    mp_path,
                    f"{base}___MP_wigner_{data_label}_{ch_name}.png"))

            # ── 2. Atom statistics for CSV ────────────────────────
            freqs = np.array([a["f_Hz"] for a in all_atoms
                              if a["f_Hz"] is not None], dtype=float)
            scales = np.array([a["scale_s"] for a in all_atoms
                               if a["scale_s"] is not None], dtype=float)
            energies = np.array([a["energy"] for a in all_atoms
                                 if a["energy"] is not None], dtype=float)
            amplitudes = np.array([a["amplitude"] for a in all_atoms
                                   if a["amplitude"] is not None], dtype=float)

            # Convert to µV units for reporting
            s2 = scale_to_uV ** 2
            csv_rows.append({
                "channel": ch_name,
                "mode": data_label,
                "n_segments": n_segments,
                "n_atoms": len(all_atoms),
                "atoms_per_segment": len(all_atoms) / max(n_segments, 1),
                "freq_mean": _safe_stat(np.mean, freqs),
                "freq_std": _safe_stat(np.std, freqs),
                "freq_median": _safe_stat(np.median, freqs),
                "scale_mean": _safe_stat(np.mean, scales),
                "scale_std": _safe_stat(np.std, scales),
                "energy_mean": _safe_stat(np.mean, energies * s2),
                "energy_std": _safe_stat(np.std, energies * s2),
                "energy_total": _safe_stat(np.sum, energies * s2),
                "amplitude_mean": _safe_stat(np.mean, amplitudes * scale_to_uV),
                "amplitude_std": _safe_stat(np.std, amplitudes * scale_to_uV),
            })

            # ── 3. Atom parameter histograms ──────────────────────
            _plot_atom_histograms(
                freqs, scales, energies,
                f"Atom distributions: {data_label} {ch_name} "
                f"({len(all_atoms)} atoms, {n_segments} segments)",
                os.path.join(
                    mp_path,
                    f"{base}___MP_atoms_{data_label}_{ch_name}.png"),
                sfreq, scale_to_uV=scale_to_uV)

            # ── 4. Reconstruction plots ───────────────────────────
            if _has_reconstruction_criteria(recon_cfg):
                # scale_uV=scale_to_uV: amp_min/amp_max are user-facing
                # µV bounds; without this, µV-native books (≥0.8.7)
                # multiply atom amplitudes by 1e6 inside filter_atoms
                # and `amp_max` drops every atom.  Same class of bug
                # as the dipole/fitting.py fix in ca9e82f.
                filtered = filter_atoms(all_atoms, recon_cfg,
                                        scale_uV=scale_to_uV)
                if filtered:
                    reconstruction = reconstruct_signal(
                        filtered, n_samples, sfreq)
                    reconstruction /= max(n_segments, 1)
                    w_filt, _, _ = compute_wigner_map(
                        filtered, n_samples, sfreq,
                        time_offset=time_offset, freq_max=freq_max)
                    w_filt /= max(n_segments, 1)
                    criteria_str = _describe_criteria(recon_cfg)
                    _plot_reconstruction(
                        w_filt, t_bins, f_bins, time, signal,
                        reconstruction,
                        f"MP reconstruction: {data_label} {ch_name} "
                        f"({len(filtered)}/{len(all_atoms)} atoms) "
                        f"\u2014 {criteria_str}",
                        os.path.join(
                            mp_path,
                            f"{base}___MP_recon_{data_label}_{ch_name}.png"))

    # ── Write CSV summary ─────────────────────────────────────────
    if csv_rows:
        _write_atom_stats_csv(
            csv_rows,
            os.path.join(mp_path, f"{base}___MP_atom_stats.csv"))

    logging.info("MP analysis outputs saved to %s", mp_path)


def _analyze_data_fresh(data, sfreq, mp_cfg, empi_path, mp_path,
                        file_name, time_offset):
    """Decompose ERPs via empi and visualize (no preprocessing book)."""
    if len(data) == 0:
        logging.warning("Empty Epochs object — skipping MP analysis.")
        return

    base = os.path.splitext(file_name)[0]
    freq_max = mp_cfg.get("gabor_freq_max", 0) or sfreq / 2
    recon_cfg = mp_cfg.get("reconstruction", {})

    for tag in data.event_id.keys():
        subset = data[tag]
        if len(subset) == 0:
            logging.warning("No segments for tag '%s' — skipping.", tag)
            continue
        subset.load_data()
        data_picks = _pick_data_channels(subset)
        signals = subset.get_data(picks=data_picks)
        n_epochs, n_channels, n_samples = signals.shape

        erp = np.mean(signals, axis=0)  # (n_channels, n_samples)
        time = np.arange(n_samples) / sfreq + time_offset

        for ch_idx, ch_name in enumerate(data_picks):
            signal = erp[ch_idx]

            logging.info("MP decomposition: %s channel %s", tag, ch_name)
            atoms = run_empi_ephemeral(signal, sfreq, empi_path, mp_cfg)

            if not atoms:
                logging.warning("No atoms found for %s %s", tag, ch_name)
                continue

            wigner, t_bins, f_bins = compute_wigner_map(
                atoms, n_samples, sfreq,
                time_offset=time_offset, freq_max=freq_max)

            _plot_wigner(
                wigner, t_bins, f_bins, time, signal,
                f"MP Wigner map: {tag} ({n_epochs}) {ch_name}",
                os.path.join(mp_path,
                             f"{base}___MP_wigner_{_safe_tag(tag)}_{ch_name}.png"))

            if _has_reconstruction_criteria(recon_cfg):
                # Default `scale_uV=1e6` is correct here: the fresh
                # ephemeral empi run feeds the signal in V (see
                # run_empi_ephemeral above), so returned atom amps
                # are V-scale.  Don't pass `scale_to_uV` from the
                # book metadata path — `_analyze_data_fresh` doesn't
                # read a book.
                filtered = filter_atoms(atoms, recon_cfg)
                if filtered:
                    reconstruction = reconstruct_signal(
                        filtered, n_samples, sfreq)
                    w_filt, _, _ = compute_wigner_map(
                        filtered, n_samples, sfreq,
                        time_offset=time_offset, freq_max=freq_max)
                    criteria_str = _describe_criteria(recon_cfg)
                    _plot_reconstruction(
                        w_filt, t_bins, f_bins, time, signal, reconstruction,
                        f"MP reconstruction: {tag} {ch_name} "
                        f"({len(filtered)}/{len(atoms)} atoms) "
                        f"— {criteria_str}",
                        os.path.join(mp_path,
                                     f"{base}___MP_recon_{_safe_tag(tag)}_{ch_name}.png"))


def _safe_stat(func, arr):
    """Apply a NumPy stat function, returning 0.0 for empty arrays."""
    return float(func(arr)) if len(arr) else 0.0


def _pick_data_channels(data):
    """Return non-STIM channel names from an MNE Epochs/Raw object."""
    ch_types = data.get_channel_types()
    picks = [ch for ch, ct in zip(data.info["ch_names"], ch_types)
             if ct != "stim"]
    return picks or list(data.info["ch_names"])


def _build_empi_cmd(empi_path, input_path, output_path,
                    sfreq, n_channels, mp_cfg):
    """Build the empi command-line argument list.

    Factored out so both ``run_empi`` and ``run_empi_ephemeral`` can
    share the same flag logic.

    Returns
    -------
    cmd : list of str
    """
    cmd = [empi_path, input_path, output_path]
    cmd += ["-c", str(n_channels)]
    cmd += ["-f", str(sfreq)]

    iterations = mp_cfg.get("iterations", 0)
    if iterations:
        cmd += ["-i", str(int(iterations))]

    # cfg stores the explained fraction (0.95 = 95% explained); empi's
    # -r flag expects the remaining fraction.  At 1.0 (100%) the user
    # wants to stop only at the iteration cap — pass a tiny residual so
    # empi doesn't reject -r 0.
    explained = float(mp_cfg.get("explained_energy", 0.99))
    residual = max(1e-12, 1.0 - explained)
    cmd += ["-r", f"{residual:.6g}"]

    optimization = mp_cfg.get("optimization", "global")
    cmd += ["-o", optimization]

    energy_error = mp_cfg.get("energy_error", 0.01)
    cmd += ["--energy-error", str(energy_error)]

    # Always include delta and gabor atoms
    cmd += ["--delta"]
    cmd += ["--gabor"]

    # Segment size (used when multiple epochs are concatenated)
    seg_size = mp_cfg.get("_segment_size", 0)
    if seg_size:
        cmd += ["--segment-size", str(int(seg_size))]

    # Algorithm: SMP is the empi default (no flag); MMP variants are
    # passed as --<name>. Validated against MP_ALGORITHMS so a typo in
    # the config or future algorithm addition fails loudly here rather
    # than silently producing a bad book.
    algorithm = mp_cfg.get("algorithm", "smp").lower()
    if algorithm not in MP_ALGORITHMS:
        raise ValueError(
            f"Unknown MP algorithm {algorithm!r}; "
            f"expected one of {sorted(MP_ALGORITHMS)}")
    if MP_ALGORITHMS[algorithm]["multichannel"]:
        cmd += [f"--{algorithm}"]

    # Parallelism: each empi worker handles a separate segment; ``1``
    # thread per worker is optimal for Gabor dictionary matching (it's
    # not BLAS-heavy). Resolution order for the worker count:
    #   1. ``matching_pursuit.cpu_workers`` in config, if > 0 — a
    #      user-specified override. This escape hatch matters because
    #      empi's cost model differs from joblib's: empi workers share
    #      memory in one C++ process (~100 MB total), so power users
    #      who know empi is RAM-cheaper may reasonably ask for more
    #      workers here than in ``parallelism.n_jobs``.
    #   2. ``mp_cfg["_default_workers"]`` — injected by the top-level
    #      caller (``mp_analysis`` in analysis, ``mp_decompose`` in
    #      preprocessing) from ``resolve_n_jobs(config)``. Gives MP
    #      the same value as ``parallelism.n_jobs`` by default, unifying
    #      the parallelism knob.
    #   3. ``1`` as the final fallback for tests and callers that did
    #      not inject anything (mirrors MNE's default).
    #
    # See CONTRIBUTING.md §"Parallelism" — Exceptions.
    workers = int(mp_cfg.get("cpu_workers", 0))
    if workers <= 0:
        workers = max(1, int(mp_cfg.get("_default_workers", 1)))
    cmd += ["--cpu-workers", str(workers), "--cpu-threads", "1"]

    return cmd


def _run_empi_subprocess(cmd, empi_path, timeout=600,
                         progress_callback=None, cancel_event=None):
    """Execute the empi binary, optionally streaming progress.

    Uses a pseudo-terminal (pty) so that empi line-buffers its output,
    allowing real-time progress updates instead of block-buffered bursts.

    Parameters
    ----------
    cmd : list of str
    empi_path : str
    timeout : int
    progress_callback : callable or None
        Called with an int 0–100 whenever empi reports progress.
    cancel_event : threading.Event or None
        If set, the empi process is killed and the function returns
        a cancellation error.

    Returns
    -------
    success : bool
        True if empi exited with code 0.
    error_detail : str or None
        Descriptive error string on failure, None on success.
    """
    _PROGRESS_RE = re.compile(r"(\d+)%")
    _SEGMENT_RE = re.compile(
        r"finished (\d+) out of (\d+) segments")

    logging.info("Running empi: %s", " ".join(cmd))
    output_lines = []
    _last_seg = [0]  # track last reported segment
    _last_pct = [-1]  # track last reported percentage

    def _read_lines(source):
        """Iterate lines from a file-like source, handling cancellation."""
        for line in source:
            if cancel_event is not None and cancel_event.is_set():
                proc.kill()
                proc.wait()
                logging.info("empi cancelled by user")
                return False
            line = line.strip()
            if not line:
                continue
            m = _PROGRESS_RE.search(line)
            if m:
                pct = int(m.group(1))
                if progress_callback:
                    progress_callback(pct)
                if pct > _last_pct[0]:
                    _last_pct[0] = pct
                    ms = _SEGMENT_RE.search(line)
                    if ms:
                        done, total = int(ms.group(1)), int(ms.group(2))
                        logging.info("MP decomposition: %d%% "
                                     "(segment %d / %d)",
                                     pct, done, total)
                    else:
                        logging.info("MP decomposition: %d%%", pct)
            else:
                output_lines.append(line)
                logging.debug("empi: %s", line)
        return True

    try:
        # Try pty for real-time progress (Unix only; forces line buffering)
        try:
            import pty as _pty
            master_fd, slave_fd = _pty.openpty()
            try:
                proc = subprocess.Popen(
                    cmd, stdout=slave_fd, stderr=slave_fd, close_fds=True)
            except Exception:
                os.close(master_fd)
                os.close(slave_fd)
                raise
            os.close(slave_fd)
            master_file = os.fdopen(master_fd, "r", errors="replace")
            try:
                ok = _read_lines(master_file)
            except OSError:
                ok = True  # EIO when child exits on some systems
            finally:
                master_file.close()
        except (ImportError, OSError):
            # Fallback for Windows or pty failure: pipe with line buffering
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1)
            ok = _read_lines(proc.stdout)

        if ok is False:
            return False, "Cancelled by user"

        proc.wait(timeout=timeout)
        if proc.returncode != 0:
            detail = "\n".join(output_lines) if output_lines \
                else f"exit code {proc.returncode}"
            logging.error("empi failed (code %d): %s",
                          proc.returncode, detail)
            return False, f"empi failed (code {proc.returncode}): {detail}"
    except subprocess.TimeoutExpired:
        proc.kill()
        logging.error("empi timed out after %ds", timeout)
        return False, f"empi timed out after {timeout}s"
    except FileNotFoundError:
        logging.error("empi binary not found: %s", empi_path)
        return False, f"empi binary not found: {empi_path}"
    return True, None


def run_empi_ephemeral(signal, sfreq, empi_path, mp_cfg):
    """Run empi on a single-channel signal and return atom list.

    Uses a temporary directory that is cleaned up after reading.

    Parameters
    ----------
    signal : ndarray, shape (n_samples,)
        Signal values (volts).
    sfreq : float
        Sampling frequency in Hz.
    empi_path : str
        Path to empi binary.
    mp_cfg : dict
        Matching pursuit configuration.

    Returns
    -------
    atoms : list of dict
        Each dict has keys: iteration, amplitude, energy, f_Hz,
        phase, scale_s, t0_s, t0_abs_s, envelope.
    """
    with tempfile.TemporaryDirectory(prefix="ide4eeg_mp_") as tmpdir:
        input_path = os.path.join(tmpdir, "signal.bin")
        output_path = os.path.join(tmpdir, "result.db")

        signal.astype(np.float32).tofile(input_path)
        cmd = _build_empi_cmd(empi_path, input_path, output_path,
                              sfreq, 1, mp_cfg)

        ok, detail = _run_empi_subprocess(cmd, empi_path)
        if not ok:
            logging.error("empi: %s", detail)
            return []

        return read_mp_results(output_path)


def run_empi(signals, sfreq, empi_path, mp_cfg, output_db,
             extra_metadata=None, progress_callback=None,
             cancel_event=None):
    """Run empi and save results to a .db file.

    Supports multi-channel input for MMP decompositions.

    Parameters
    ----------
    signals : ndarray, shape (n_channels, n_samples) or (n_samples,)
        Signal values.  For SMP each channel is decomposed
        independently; for MMP all channels are decomposed jointly.
    sfreq : float
        Sampling frequency in Hz.
    empi_path : str
        Path to empi binary.
    mp_cfg : dict
        Matching pursuit configuration (including ``algorithm``).
    output_db : str
        Path where the persistent ``.db`` file will be saved.
    extra_metadata : dict or None
        Additional key-value pairs to INSERT into the metadata table
        after empi finishes (e.g. ``signal_unit``, ``scale_to_uV``,
        ``channel_names``).
    progress_callback : callable or None
        Called with an int 0–100 whenever empi reports progress.

    Returns
    -------
    success : bool
    error_detail : str or None
        Descriptive error string on failure, None on success.
    """
    signals = np.atleast_2d(signals)
    n_channels, n_samples = signals.shape

    with tempfile.TemporaryDirectory(prefix="ide4eeg_mp_") as tmpdir:
        input_path = os.path.join(tmpdir, "signal.bin")

        # empi expects interleaved channels: ch0_s0 ch1_s0 ch0_s1 ...
        # i.e. column-major (Fortran order) when channels are rows.
        signals.astype(np.float32).T.tofile(input_path)

        cmd = _build_empi_cmd(empi_path, input_path, output_db,
                              sfreq, n_channels, mp_cfg)

        ok, detail = _run_empi_subprocess(
            cmd, empi_path, progress_callback=progress_callback,
            cancel_event=cancel_event)
        if not ok:
            return False, detail

    # Inject extra metadata (safe — unknown keys ignored by readers)
    if extra_metadata:
        try:
            with sqlite3.connect(output_db) as conn:
                cur = conn.cursor()
                for key, value in extra_metadata.items():
                    cur.execute(
                        "INSERT OR REPLACE INTO metadata (param, value) "
                        "VALUES (?, ?)", [key, str(value)])
        except sqlite3.Error as e:
            logging.warning("Could not write extra metadata: %s", e)

    return True, None


def read_mp_results(db_path, segment_id=0, channel_id=0):
    """Read atom parameters from empi SQLite output.

    Parameters
    ----------
    db_path : str
        Path to the SQLite database produced by empi.
    segment_id : int
        Segment index (default 0).
    channel_id : int
        Channel index (default 0).

    Returns
    -------
    atoms : list of dict
    """
    atoms = []
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM atoms WHERE segment_id=? AND channel_id=? "
                "ORDER BY iteration",
                [segment_id, channel_id])
            for row in cursor:
                atoms.append({
                    "iteration": row["iteration"],
                    "amplitude": row["amplitude"],
                    "energy": row["energy"],
                    "f_Hz": row["f_Hz"],
                    "phase": row["phase"],
                    "scale_s": row["scale_s"],
                    "t0_s": row["t0_s"],
                    "t0_abs_s": row["t0_abs_s"],
                    "envelope": row["envelope"],
                })
    except sqlite3.Error as e:
        logging.error("Error reading MP results: %s", e)

    logging.debug("Read %d atoms from %s", len(atoms), db_path)
    return atoms


def read_book_channel_names(db_path):
    """Return the list of channel names stored in an empi .db book.

    Reads ``channel_names`` from the ``metadata`` table (comma-joined).
    Falls back to ``["Ch0", "Ch1", …]`` when the field is absent (books
    produced before metadata injection was added).

    Parameters
    ----------
    db_path : str
        Path to a ``*.db`` SQLite book produced by empi.

    Returns
    -------
    list of str
        Channel names in book order.  Empty list if the file cannot be
        opened or has no channel information at all.
    """
    try:
        with sqlite3.connect(db_path) as conn:
            row = conn.execute(
                "SELECT value FROM metadata WHERE param='channel_names'"
            ).fetchone()
            n_row = conn.execute(
                "SELECT value FROM metadata WHERE param='channel_count'"
            ).fetchone()
    except sqlite3.Error as e:
        logging.warning("read_book_channel_names: cannot open %s: %s",
                        db_path, e)
        return []
    if row and row[0]:
        names = [c.strip() for c in row[0].split(",") if c.strip()]
        if names:
            return names
    n_ch = int(n_row[0]) if n_row else 0
    return [f"Ch{i}" for i in range(n_ch)]


def gabor(t, amplitude, t0, f0, scale, phase=0.0):
    """Generate a Gabor atom (Gaussian-windowed sinusoid).

    Parameters
    ----------
    t : ndarray
        Time points in seconds.
    amplitude : float
    t0 : float
        Center time in seconds.
    f0 : float
        Frequency in Hz.
    scale : float
        Width (standard deviation of the Gaussian envelope) in seconds.
    phase : float
        Phase in radians.

    Returns
    -------
    ndarray
    """
    return amplitude * np.exp(-np.pi * ((t - t0) / scale) ** 2) \
        * np.cos(2 * np.pi * f0 * (t - t0) + phase)


def reconstruct_signal(atoms, n_samples, sfreq):
    """Reconstruct signal from a list of atoms.

    Parameters
    ----------
    atoms : list of dict
    n_samples : int
    sfreq : float

    Returns
    -------
    signal : ndarray, shape (n_samples,)
    """
    t = np.arange(n_samples) / sfreq
    signal = np.zeros(n_samples)

    for atom in atoms:
        if atom.get("envelope", "gauss") != "gauss":
            continue
        if any(atom.get(k) is None for k in
               ("amplitude", "t0_s", "f_Hz", "scale_s", "phase")):
            continue
        signal += gabor(t, atom["amplitude"], atom["t0_s"],
                        atom["f_Hz"], atom["scale_s"], atom["phase"])

    return signal


def compute_wigner_map(atoms, n_samples, sfreq,
                       n_time_bins=256, n_freq_bins=256,
                       time_offset=0.0, freq_max=None):
    """Compute Wigner time-frequency energy density from MP atoms.

    Each Gabor atom contributes a 2D Gaussian blob centered at
    (t0, f0) with widths determined by its scale parameter.
    This is the auto-term of the Wigner-Ville distribution.

    Parameters
    ----------
    atoms : list of dict
    n_samples : int
    sfreq : float
    n_time_bins : int
    n_freq_bins : int
    time_offset : float
        Shift for the time axis (e.g. epoch start_offset).
    freq_max : float or None
        Upper frequency limit (default: Nyquist).

    Returns
    -------
    wigner : ndarray, shape (n_freq_bins, n_time_bins)
    t_bins : ndarray
    f_bins : ndarray
    """
    if freq_max is None:
        freq_max = sfreq / 2

    duration = n_samples / sfreq
    t_bins = np.linspace(time_offset, time_offset + duration, n_time_bins)
    f_bins = np.linspace(0, freq_max, n_freq_bins)

    wigner = np.zeros((n_freq_bins, n_time_bins))

    for atom in atoms:
        if atom.get("envelope", "gauss") != "gauss":
            continue

        energy = atom.get("energy", atom["amplitude"] ** 2)
        t0 = atom["t0_s"]
        f0 = atom["f_Hz"]
        s = atom["scale_s"]

        if s <= 0 or energy <= 0:
            continue

        # Wigner-Ville auto-term for a Gabor atom:
        # W(t,f) proportional to exp(-2pi((t-t0)/s)^2) * exp(-2pi*s^2*(f-f0)^2)
        # Weighted by atom energy (not amplitude²) to correctly represent
        # signal energy density in the time-frequency plane.
        time_gauss = np.exp(-2 * np.pi * ((t_bins - time_offset - t0) / s) ** 2)
        freq_gauss = np.exp(-2 * np.pi * (s * (f_bins - f0)) ** 2)

        wigner += energy * np.outer(freq_gauss, time_gauss)

    return wigner, t_bins, f_bins


def atom_p2p_uV(atom, scale_uV=1e6):
    """Peak-to-peak amplitude of a Gabor atom in \u00b5V.

    ``atom["amplitude"]`` from the book is the Gabor envelope amplitude
    in the book's native unit (V for FIF inputs).  Peak-to-peak is twice
    the envelope.  All GUI/config amplitude bounds in IDE4EEG follow the
    peak-to-peak convention \u2014 same as artifact rejection, slope
    thresholds, etc.

    Parameters
    ----------
    atom : dict
        Atom dict with key ``amplitude``.
    scale_uV : float
        Multiplier to convert envelope amplitude to \u00b5V (1e6 for V,
        1.0 if the book already stores \u00b5V).

    Returns
    -------
    float
        Peak-to-peak amplitude in \u00b5V.
    """
    return 2.0 * abs(atom.get("amplitude") or 0.0) * scale_uV


def filter_atoms(atoms, recon_cfg, scale_uV=1e6):
    """Filter atoms by AtomFilterTable criteria.

    Parameters
    ----------
    atoms : list of dict
    recon_cfg : dict
        Keys: freq_min, freq_max, time_min, time_max,
        min_energy, max_iterations, amp_min, amp_max,
        scale_min, scale_max.  ``amp_min``/``amp_max`` are
        peak-to-peak \u00b5V.
    scale_uV : float
        Multiplier to convert envelope amplitude to \u00b5V (1e6 for V).

    Returns
    -------
    filtered : list of dict
    """
    freq_min = recon_cfg.get("freq_min", 0)
    freq_max = recon_cfg.get("freq_max", 0)
    time_min = recon_cfg.get("time_min", 0)
    time_max = recon_cfg.get("time_max", 0)
    min_energy = recon_cfg.get("min_energy", 0)
    max_iter = recon_cfg.get("max_iterations", 0)
    amp_min = recon_cfg.get("amp_min", 0)
    amp_max = recon_cfg.get("amp_max", 0)
    scale_min = recon_cfg.get("scale_min", 0)
    scale_max = recon_cfg.get("scale_max", 0)

    filtered = []
    for atom in atoms:
        f = atom.get("f_Hz")
        t = atom.get("t0_s")
        e = atom.get("energy")
        s = atom.get("scale_s")
        if freq_min and (f is None or f < freq_min):
            continue
        if freq_max and (f is None or f > freq_max):
            continue
        if time_min and (t is None or t < time_min):
            continue
        if time_max and (t is None or t > time_max):
            continue
        if min_energy and (e is None or e < min_energy):
            continue
        # iteration is 0-indexed, so >= max_iter excludes it
        if max_iter and atom["iteration"] >= max_iter:
            continue
        if scale_min and (s is None or s < scale_min):
            continue
        if scale_max and (s is None or s > scale_max):
            continue
        if amp_min or amp_max:
            p2p = atom_p2p_uV(atom, scale_uV=scale_uV)
            if amp_min and p2p < amp_min:
                continue
            if amp_max and p2p > amp_max:
                continue
        filtered.append(atom)

    return filtered


_RECON_KEYS = ("freq_min", "freq_max", "time_min", "time_max",
               "min_energy", "max_iterations",
               "amp_min", "amp_max", "scale_min", "scale_max")


def _has_reconstruction_criteria(recon_cfg):
    """Check if any reconstruction filter is set."""
    return bool(recon_cfg) and any(recon_cfg.get(k, 0) for k in _RECON_KEYS)


def _describe_criteria(recon_cfg):
    """Build a human-readable description of the filter criteria."""
    parts = []
    if recon_cfg.get("freq_min"):
        parts.append(f"f\u2265{recon_cfg['freq_min']}Hz")
    if recon_cfg.get("freq_max"):
        parts.append(f"f\u2264{recon_cfg['freq_max']}Hz")
    if recon_cfg.get("time_min"):
        parts.append(f"t\u2265{recon_cfg['time_min']}s")
    if recon_cfg.get("time_max"):
        parts.append(f"t\u2264{recon_cfg['time_max']}s")
    if recon_cfg.get("min_energy"):
        parts.append(f"E\u2265{recon_cfg['min_energy']}")
    if recon_cfg.get("max_iterations"):
        parts.append(f"iter<{recon_cfg['max_iterations']}")
    if recon_cfg.get("amp_min"):
        parts.append(f"a\u2265{recon_cfg['amp_min']}\u00b5V")
    if recon_cfg.get("amp_max"):
        parts.append(f"a\u2264{recon_cfg['amp_max']}\u00b5V")
    if recon_cfg.get("scale_min"):
        parts.append(f"s\u2265{recon_cfg['scale_min']}s")
    if recon_cfg.get("scale_max"):
        parts.append(f"s\u2264{recon_cfg['scale_max']}s")
    return ", ".join(parts) if parts else "all atoms"


def _write_atom_stats_csv(rows, csv_path):
    """Write atom parameter summary to a CSV file.

    Parameters
    ----------
    rows : list of dict
        Each dict has keys: channel, mode, n_segments, n_atoms,
        atoms_per_segment, freq_mean, freq_std, freq_median,
        scale_mean, scale_std, energy_mean, energy_std,
        energy_total, amplitude_mean, amplitude_std.
    csv_path : str
        Output file path.
    """
    import csv
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v)
                             for k, v in row.items()})
    logging.info("Atom stats CSV: %s", csv_path)


def _plot_atom_histograms(freqs, scales, energies, title, save_path,
                          sfreq, scale_to_uV=1.0):
    """Plot histograms of atom frequency, scale, and energy.

    Parameters
    ----------
    freqs : ndarray
        Atom frequencies in Hz.
    scales : ndarray
        Atom scales in seconds.
    energies : ndarray
        Atom energies (in signal units²).
    title : str
        Figure title.
    save_path : str
        Output file path.
    sfreq : float
        Sampling frequency (for x-axis limit on frequency plot).
    scale_to_uV : float
        Multiplier to convert signal amplitude to µV (e.g. 1e6 for V→µV).
    """
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    axes[0].hist(freqs, bins=50, color="#89b4fa", edgecolor="none",
                 alpha=0.9)
    axes[0].set_xlabel("Frequency [Hz]")
    axes[0].set_ylabel("Count")
    axes[0].set_xlim(0, sfreq / 2)
    axes[0].set_title("Frequency distribution")

    axes[1].hist(scales * 1000, bins=50, color="#a6e3a1", edgecolor="none",
                 alpha=0.9)
    axes[1].set_xlabel("Scale [ms]")
    axes[1].set_ylabel("Count")
    axes[1].set_title("Scale distribution")

    # Energy is amplitude² × scale → scale by scale_to_uV² for µV² units
    energies_disp = energies * scale_to_uV ** 2
    energy_unit = "µV²" if scale_to_uV > 1 else "a.u."
    axes[2].hist(energies_disp, bins=50, color="#f9e2af", edgecolor="none",
                 alpha=0.9)
    axes[2].set_xlabel(f"Energy [{energy_unit}]")
    axes[2].set_ylabel("Count")
    axes[2].set_title("Energy distribution")

    fig.suptitle(title, fontsize=11)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)


def _plot_wigner(wigner, t_bins, f_bins, time, signal, title, save_path):
    """Plot Wigner map with signal overlay below."""
    fig, axes = plt.subplots(
        2, 1, figsize=(12, 8),
        gridspec_kw={"height_ratios": [3, 1]})

    im = axes[0].pcolormesh(
        t_bins, f_bins, wigner, shading='gouraud', cmap='jet')
    axes[0].set_ylabel("Frequency [Hz]")
    axes[0].set_title(title)
    plt.colorbar(im, ax=axes[0], label="Energy density")

    axes[1].plot(time, signal * 1e6, 'k', lw=0.8)
    axes[1].set_xlabel("Time [s]")
    axes[1].set_ylabel(r"Potential [$\mu V$]")
    axes[1].set_xlim(time[0], time[-1])

    plt.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)


def _plot_reconstruction(wigner, t_bins, f_bins, time, original,
                         reconstruction, title, save_path):
    """Plot filtered Wigner map, original vs reconstruction, and residual."""
    fig, axes = plt.subplots(
        3, 1, figsize=(12, 10),
        gridspec_kw={"height_ratios": [3, 1, 1]})

    im = axes[0].pcolormesh(
        t_bins, f_bins, wigner, shading='gouraud', cmap='jet')
    axes[0].set_ylabel("Frequency [Hz]")
    axes[0].set_title(title)
    plt.colorbar(im, ax=axes[0], label="Energy density")

    axes[1].plot(time, original * 1e6, 'k', lw=0.8, label="Original")
    axes[1].plot(time, reconstruction * 1e6, 'r', lw=0.8,
                 label="Reconstruction")
    axes[1].set_ylabel(r"Potential [$\mu V$]")
    axes[1].legend(loc="upper right", fontsize=8)
    axes[1].set_xlim(time[0], time[-1])

    residual = original - reconstruction
    axes[2].plot(time, residual * 1e6, 'b', lw=0.8)
    axes[2].set_xlabel("Time [s]")
    axes[2].set_ylabel(r"Residual [$\mu V$]")
    axes[2].set_xlim(time[0], time[-1])

    plt.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)
