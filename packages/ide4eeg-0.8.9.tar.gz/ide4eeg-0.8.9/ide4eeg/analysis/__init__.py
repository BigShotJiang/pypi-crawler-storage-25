def _safe_tag(tag):
    """Sanitize a tag name for use in file paths (replace '/' with '_')."""
    return tag.replace("/", "_")
