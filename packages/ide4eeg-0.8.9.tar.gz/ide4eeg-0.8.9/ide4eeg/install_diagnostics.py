"""Diagnose video-stack Python dependencies without installing them.

The video-processing pipeline (facetag — InsightFace face detection
+ L2CS-Net eye gaze) needs a stack of seven Python packages on top
of the core install: ``cv2`` / ``av`` / ``imageio`` /
``insightface`` / ``onnxruntime`` are always required, and
``torch`` / ``l2cs`` power the default L2CS-Net gaze backend.
``torch`` and ``l2cs`` are loaded lazily — they're only needed
when ``facetag_gaze_method == "l2cs"`` (the default), so the
diagnostic distinguishes them from the core via an internal
``Pkg.optional`` flag.  That flag is a *code* concept, never a
user-facing label.
None of these install reliably on every (Python, OS, arch) cell —
some have wheel gaps (Intel Mac + Py3.14 has no ``onnxruntime`` cp314
wheel) and some need a C compiler (Linux + Py3.14 has no
``insightface`` cp314 wheel and falls back to sdist build).

This module is the **diagnostic-only first slice** of the planned
in-app install panel.  It probes the current process to see which
packages are importable, looks up the platform cell in a table of
known issues, and returns a structured plan plus formatted
remediation text.  It deliberately does NOT run ``pip install`` —
that lands in a later slice once we've validated the table against
real users on real cells.

Public API:

- :func:`detect_video_stack` — cheap import-availability probe
- :func:`plan_install` — categorise into have / missing / blocked
- :func:`format_diagnostic` — human-readable text for dialogs / logs

The cell-issues table (:data:`_KNOWN_ISSUES`) is the seed for the
known-issues docs section in :file:`USER_MANUAL.md`.  When new
wheels ship and a cell flips from blocked to clean, prune the
entry here and update the manual.
"""

from __future__ import annotations

import importlib.util
import os
import platform
import sys
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Pkg:
    """One package in the video stack."""
    import_name: str
    pip_spec: str
    purpose: str
    optional: bool = False


@dataclass(frozen=True)
class CellIssue:
    """A known wheel-availability or build-tooling issue affecting
    one package on one (OS, arch, Python) cell."""
    pkg: str
    blocker: str
    remediation: str


@dataclass(frozen=True)
class ActionPlan:
    """Categorised view of the video stack on the current cell."""
    have: tuple[Pkg, ...] = field(default_factory=tuple)
    missing: tuple[Pkg, ...] = field(default_factory=tuple)
    blocked: tuple[tuple[Pkg, CellIssue], ...] = field(default_factory=tuple)

    @property
    def all_clear(self) -> bool:
        return not self.missing and not self.blocked


VIDEO_STACK: tuple[Pkg, ...] = (
    Pkg("cv2", "opencv-contrib-python-headless",
        "OpenCV — face detection / image preprocessing"),
    Pkg("av", "av>=14.0",
        "PyAV — video file decoding (libavcodec)"),
    Pkg("imageio", "imageio[pyav]",
        "imageio — frame iteration helpers"),
    Pkg("insightface", "insightface",
        "InsightFace — face detection / identity"),
    Pkg("onnxruntime", "onnxruntime",
        "ONNX Runtime — InsightFace model inference"),
    Pkg("torch", "torch",
        "PyTorch — L2CS-Net gaze inference",
        optional=True),
    Pkg("l2cs", "l2cs @ git+https://github.com/Ahmednull/L2CS-Net.git@main",
        "L2CS-Net — default eye-gaze backend",
        optional=True),
)


_INTEL_MAC_PY314_ONNXRUNTIME = CellIssue(
    pkg="onnxruntime",
    blocker=(
        "onnxruntime has no Python 3.14 wheel for Intel Macs "
        "(macOS x86_64).  The Apple Silicon, Linux, and Windows "
        "wheels exist starting at 1.24, but x86_64 macOS does not."
    ),
    remediation=(
        "Install Python 3.13 alongside the current interpreter "
        "and recreate the virtualenv:\n"
        "  brew install python@3.13\n"
        "  /opt/homebrew/bin/python3.13 -m venv .venv\n"
        "  source .venv/bin/activate\n"
        "  pip install -r requirements.txt\n"
        "Apple Silicon Macs have working Python 3.14 wheels and "
        "do not need this workaround."
    ),
)

_LINUX_PY314_INSIGHTFACE = CellIssue(
    pkg="insightface",
    blocker=(
        "insightface (and the transitive dependency stringzilla, "
        "via albumentations) ship no Python 3.14 wheels for Linux "
        "yet, so pip falls back to building from sdist — which "
        "needs a C/C++ compiler."
    ),
    remediation=(
        "Install build-essential, then retry:\n"
        "  sudo apt install build-essential   # Debian / Ubuntu\n"
        "  sudo dnf groupinstall 'Development Tools'   # Fedora\n"
        "Alternatively, recreate the venv with Python 3.13, "
        "which has wheels and avoids the build entirely."
    ),
)

# Predicate-based: each entry's (platform, arch, py_minor) is matched
# against the live cell; ``None`` is a wildcard.  First match wins
# for any given (cell, package) pair.
_KNOWN_ISSUES: tuple[tuple[str | None, str | None, int | None, CellIssue], ...] = (
    ("darwin", "x86_64", 14, _INTEL_MAC_PY314_ONNXRUNTIME),
    ("linux", None,      14, _LINUX_PY314_INSIGHTFACE),
)


def detect_video_stack() -> dict[str, bool]:
    """Return ``{import_name: importable}`` for every video-stack package.

    Uses :func:`importlib.util.find_spec` so torch / onnxruntime are
    not actually imported (each costs 1–3 s on first import and is
    unnecessary just to populate a status dialog).

    Survives a pip-uninstall in the same Python process: when a
    module is already cached in ``sys.modules``, ``find_spec``
    would return the cached spec without consulting the filesystem
    (so the diagnostic would lie after Uninstall).  We can't
    sidestep that by popping the module — re-importing torch in
    the same process double-registers its singleton TORCH_LIBRARY
    bindings and crashes — so instead we check whether the cached
    module's ``__file__`` still exists on disk.  If pip removed
    it, the package is effectively gone even though the live
    reference is still held.
    """
    importlib.invalidate_caches()
    result: dict[str, bool] = {}
    for pkg in VIDEO_STACK:
        result[pkg.import_name] = _is_pkg_importable(pkg.import_name)
    return result


def _is_pkg_importable(name: str) -> bool:
    """Whether ``name`` is currently importable, accounting for
    already-cached modules whose backing files may have been
    removed by pip-uninstall.

    For an unloaded module: fall through to ``find_spec`` (fresh
    PathFinder lookup, no caching surprises).

    For a loaded module: check whether the file backing
    ``__file__`` still exists.  Modules without a ``__file__``
    (built-ins, namespace packages) are treated as importable.
    """
    mod = sys.modules.get(name)
    if mod is not None:
        path = getattr(mod, "__file__", None)
        if path is None:
            return True
        return os.path.exists(path)
    return importlib.util.find_spec(name) is not None


def cell_issues(
    platform_: str | None = None,
    machine: str | None = None,
    py_minor: int | None = None,
) -> list[CellIssue]:
    """Return :class:`CellIssue` entries that apply to this cell.

    All three coordinates default to the current process.  Tests
    pass synthetic values to exercise specific cells.
    """
    if platform_ is None:
        platform_ = sys.platform
    if machine is None:
        machine = platform.machine()
    if py_minor is None:
        py_minor = sys.version_info.minor
    return [
        issue for p, a, py, issue in _KNOWN_ISSUES
        if (p is None or p == platform_)
        and (a is None or a == machine)
        and (py is None or py == py_minor)
    ]


def plan_install(
    detection: dict[str, bool] | None = None,
    *,
    platform_: str | None = None,
    machine: str | None = None,
    py_minor: int | None = None,
) -> ActionPlan:
    """Categorise every video-stack package into have / missing / blocked.

    Parameters mirror :func:`cell_issues` for tests.
    """
    if detection is None:
        detection = detect_video_stack()
    issues_by_pkg = {
        i.pkg: i for i in cell_issues(platform_, machine, py_minor)
    }
    have, missing, blocked = [], [], []
    for pkg in VIDEO_STACK:
        if detection.get(pkg.import_name):
            have.append(pkg)
        elif pkg.import_name in issues_by_pkg:
            blocked.append((pkg, issues_by_pkg[pkg.import_name]))
        else:
            missing.append(pkg)
    return ActionPlan(
        have=tuple(have),
        missing=tuple(missing),
        blocked=tuple(blocked),
    )


def format_diagnostic(plan: ActionPlan, *, header: str = "Video stack status") -> str:
    """Render an :class:`ActionPlan` as multi-line text.

    Suitable for an error-dialog body or for the Run-tab log.  ASCII
    markers only — `[ok]` / `[--]` / `[!!]` — to keep the output
    grep-friendly and avoid platform-font surprises.
    """
    lines = [header, "=" * len(header), ""]
    if plan.have:
        lines.append("Installed:")
        for pkg in plan.have:
            lines.append(f"  [ok] {pkg.purpose}")
        lines.append("")
    if plan.missing:
        lines.append("Missing (clean install possible):")
        for pkg in plan.missing:
            lines.append(f"  [--] {pkg.purpose}")
            lines.append(f"       pip install {pkg.pip_spec}")
        lines.append("")
    if plan.blocked:
        lines.append("Missing (blocked by platform issue):")
        for pkg, issue in plan.blocked:
            lines.append(f"  [!!] {pkg.purpose}")
            lines.append(f"       {issue.blocker}")
            for ln in issue.remediation.splitlines():
                lines.append(f"       {ln}")
        lines.append("")
    if plan.all_clear:
        lines.append("Video stack is fully installed.")
    return "\n".join(lines).rstrip() + "\n"


if __name__ == "__main__":
    # `python -m ide4eeg.install_diagnostics` prints the live
    # diagnostic.  Useful for headless boxes, CI, and debugging
    # without launching the GUI.
    sys.stdout.write(format_diagnostic(plan_install()))
