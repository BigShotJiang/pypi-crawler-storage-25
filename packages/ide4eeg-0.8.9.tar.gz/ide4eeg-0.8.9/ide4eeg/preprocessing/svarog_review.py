"""Manual review of bad channels / bad epochs via Svarog.

IDE4EEG's pipeline normally pops up MNE's interactive browser on
the GUI main thread for manual bad-channel review.  Svarog provides
a richer alternative: launched as a separate process, it shows the
signal with a selection UI, writes the user's choices to a tag
file, and exits.  This module handles the IDE4EEG half of the
protocol — writing the input signal, invoking Svarog, parsing the
output.

Protocol
--------

    java -jar <svarog.jar> <signal.fif> \\
         --select-mode bad_channels \\
         --output <out.tag> \\
         [--preselect <init.tag>]

* Exit code 0 + output file present  →  user saved, output file
  contains one tag per bad channel (``name`` = channel name,
  ``channelNumber`` = 0-based index, point tag).
* Non-zero exit OR output file missing  →  user cancelled or the
  subprocess failed; the caller should fall back to whatever
  default behaviour applies (keep auto-detected bads, or retry
  via MNE, etc.).

``--preselect`` loads an initial selection — typically the
auto-detected bad channels — so the user sees them pre-marked and
can accept or edit.

This module is deliberately thin: no GUI imports, just
``subprocess`` + ``obci_readmanager`` tag I/O + ``mne`` for
saving the temp FIF.  It runs in whatever thread the pipeline
calls it from.
"""

import logging
import os
import shutil
import subprocess
import tempfile

from ide4eeg._appcds import appcds_flags

logger = logging.getLogger(__name__)


def review_bad_channels_via_svarog(
        signal,
        svarog_jar,
        *,
        preselected_bads=None,
        timeout_s=3600,
        java_path="java",
        extra_args=None,
        subprocess_runner=subprocess.run,
):
    """Prompt the user to mark bad channels in Svarog.

    Parameters
    ----------
    signal : mne.io.Raw
        The signal to display.  Saved to a temp FIF before launch.
    svarog_jar : str
        Path to the Svarog jar file.
    preselected_bads : list[str] or None
        Channel names to pre-mark as bad.  Typically the output of
        the automatic bad-channel detector, so the user sees those
        highlighted and can accept / edit.
    timeout_s : int
        Maximum seconds to wait for Svarog.  Default 1 hour.
    java_path : str
        ``java`` binary to invoke.
    extra_args : list[str] or None
        Additional CLI args forwarded to Svarog (e.g. ``--channel``,
        ``--page-size``).
    subprocess_runner : callable
        Seam for tests.  ``subprocess.run``-compatible signature;
        must return an object with a ``returncode`` attribute.

    Returns
    -------
    list[str] or None
        Channel names the user marked as bad.  Empty list if the
        user saved with no selection.  ``None`` if the user
        cancelled, timed out, the subprocess failed, or the output
        tag file couldn't be parsed.
    """
    if not svarog_jar or not os.path.isfile(svarog_jar):
        logger.warning("Svarog jar not found: %s", svarog_jar)
        return None

    work_dir = tempfile.mkdtemp(prefix="svarog_review_")
    try:
        signal_path = os.path.join(work_dir, "signal-raw.fif")
        signal.save(signal_path, overwrite=True, verbose=False)
        output_path = os.path.join(work_dir, "selected-bads.tag")

        cmd = [java_path, *appcds_flags(svarog_jar, java_path),
               "-jar", svarog_jar, signal_path,
               "--select-mode", "bad_channels",
               "--output", output_path,
               "--nosplash"]
        if preselected_bads:
            preselect_path = os.path.join(work_dir, "preselect.tag")
            _write_channel_tag_file(
                preselect_path, preselected_bads, signal.info["ch_names"])
            cmd.extend(["--preselect", preselect_path])
        if extra_args:
            cmd.extend(extra_args)

        logger.info("Launching Svarog for bad-channel review: %s",
                    " ".join(cmd))
        try:
            result = subprocess_runner(
                cmd, timeout=timeout_s, check=False)
        except subprocess.TimeoutExpired:
            logger.warning("Svarog review timed out after %ds", timeout_s)
            return None
        except (OSError, FileNotFoundError) as e:
            logger.warning("Svarog launch failed: %s", e)
            return None

        rc = getattr(result, "returncode", None)
        if rc != 0:
            logger.info("Svarog exited with code %s — treating as cancel",
                        rc)
            return None
        if not os.path.isfile(output_path):
            logger.info("Svarog didn't write %s — treating as cancel",
                        output_path)
            return None

        try:
            bads = _read_channel_tag_file(output_path)
        except Exception as e:
            logger.warning("Failed to parse Svarog output %s: %s",
                           output_path, e)
            return None

        # Filter to channels actually in the signal — defence against
        # Svarog writing stale indices after some live rename.
        ch_names = set(signal.info["ch_names"])
        bads = [b for b in bads if b in ch_names]
        logger.info("Svarog review returned %d bad channels: %s",
                    len(bads), bads)
        return bads
    finally:
        try:
            shutil.rmtree(work_dir)
        except OSError:
            pass


def review_bad_epochs_via_svarog(
        epochs,
        svarog_jar,
        *,
        preselected_rejections=None,
        timeout_s=3600,
        java_path="java",
        extra_args=None,
        subprocess_runner=subprocess.run,
):
    """Prompt the user to mark epochs for rejection in Svarog.

    Mirror of :func:`review_bad_channels_via_svarog` for the
    bad-epochs case.  The epochs object is saved to a temp
    ``-epo.fif``, Svarog opens it with
    ``--select-mode bad_epochs``, the user toggles which epochs
    to reject, and on save the output tag file contains one
    entry per rejected epoch (``desc.idx`` carries the integer
    index; 0-based into the Epochs object the caller passed).

    Parameters
    ----------
    epochs : mne.Epochs
        The epoched signal ready for manual review (typically
        already PTP-cleaned by ``remove_bad_segments``).
    svarog_jar : str
        Path to the Svarog jar file.
    preselected_rejections : iterable of int or None
        Epoch indices to pre-mark as rejected (e.g. for a
        re-entry after a prior review).  Defaults to empty.
    timeout_s : int
        Maximum seconds to wait for Svarog.  Default 1 hour.
    java_path : str
        ``java`` binary to invoke.
    extra_args : list[str] or None
        Additional CLI args forwarded to Svarog.
    subprocess_runner : callable
        Seam for tests.  ``subprocess.run``-compatible; returns
        an object with ``returncode``.

    Returns
    -------
    set[int] or None
        Epoch indices to reject.  Empty set if the user saved
        with no rejections.  ``None`` on cancel, timeout,
        launch failure, or corrupt output.
    """
    if not svarog_jar or not os.path.isfile(svarog_jar):
        logger.warning("Svarog jar not found: %s", svarog_jar)
        return None

    work_dir = tempfile.mkdtemp(prefix="svarog_review_epochs_")
    try:
        epochs_path = os.path.join(work_dir, "signal-epo.fif")
        epochs.save(epochs_path, overwrite=True, verbose=False)
        output_path = os.path.join(work_dir, "selected-rejections.tag")

        cmd = [java_path, *appcds_flags(svarog_jar, java_path),
               "-jar", svarog_jar, epochs_path,
               "--select-mode", "bad_epochs",
               "--output", output_path,
               "--nosplash"]
        if preselected_rejections:
            preselect_path = os.path.join(work_dir, "preselect.tag")
            _write_epoch_tag_file(
                preselect_path, preselected_rejections, epochs)
            cmd.extend(["--preselect", preselect_path])
        if extra_args:
            cmd.extend(extra_args)

        logger.info("Launching Svarog for bad-epoch review: %s",
                    " ".join(cmd))
        try:
            result = subprocess_runner(
                cmd, timeout=timeout_s, check=False)
        except subprocess.TimeoutExpired:
            logger.warning("Svarog review timed out after %ds", timeout_s)
            return None
        except (OSError, FileNotFoundError) as e:
            logger.warning("Svarog launch failed: %s", e)
            return None

        rc = getattr(result, "returncode", None)
        if rc != 0:
            logger.info("Svarog exited with code %s — treating as cancel",
                        rc)
            return None
        if not os.path.isfile(output_path):
            logger.info("Svarog didn't write %s — treating as cancel",
                        output_path)
            return None

        try:
            rejections = _read_epoch_tag_file(output_path)
        except Exception as e:
            logger.warning("Failed to parse Svarog output %s: %s",
                           output_path, e)
            return None

        # Filter to valid epoch indices — defence against a stale
        # tag file referring to epochs that don't exist in this set.
        n_epochs = len(epochs)
        rejections = {i for i in rejections if 0 <= i < n_epochs}
        logger.info("Svarog review returned %d rejected epoch(s): %s",
                    len(rejections), sorted(rejections))
        return rejections
    finally:
        try:
            shutil.rmtree(work_dir)
        except OSError:
            pass


def _write_epoch_tag_file(path, indices, epochs):
    """Write a Svarog .tag file marking the given epochs as rejected.

    One tag per index.  ``name`` = event label (for readability when
    inspecting the file); ``desc.idx`` = integer index (the actual
    payload).  ``position`` / ``length`` are the epoch's time window
    relative to the signal start — useful for Svarog's UI to anchor
    the tag on the timeline.  Indices outside ``len(epochs)`` are
    silently skipped.
    """
    from obci_readmanager.signal_processing.tags.tags_file_writer import (
        TagsFileWriter)
    writer = TagsFileWriter(path)
    n = len(epochs)
    sfreq = epochs.info["sfreq"]
    # Event ID → label (inverse of epochs.event_id)
    id_to_label = {v: k for k, v in (epochs.event_id or {}).items()}
    # Epoch onsets in seconds (from the Epochs.events array, which
    # records sample indices into the ORIGINAL signal).
    onsets_s = epochs.events[:, 0] / sfreq if len(epochs.events) else []
    tmin = float(getattr(epochs, "tmin", 0.0))
    tmax = float(getattr(epochs, "tmax", 0.0))
    duration = max(tmax - tmin, 0.0)
    for idx in indices:
        idx = int(idx)
        if not (0 <= idx < n):
            continue
        event_id = int(epochs.events[idx, 2]) if idx < len(epochs.events) else 0
        label = id_to_label.get(event_id, "reject")
        start = float(onsets_s[idx]) + tmin if idx < len(onsets_s) else 0.0
        writer.tag_received({
            "channelNumber": -1,
            "start_timestamp": start,
            "end_timestamp": start + duration,
            "name": label,
            "desc": {"typ": "reject_epoch", "idx": str(idx)},
        })
    writer.finish_saving(0.0)


def _read_epoch_tag_file(path):
    """Return rejected epoch indices from a Svarog tag file.

    Reads the ``idx`` child element of each ``<tag>`` entry and
    coerces to int; tags without a valid numeric ``idx`` are
    skipped.  Returns a set (order doesn't matter for epoch
    rejection).

    ``TagsFileReader`` nests all child-element data under
    ``tag["desc"]``, not at the top level — that's where the
    ``<idx>`` payload ends up after parsing.
    """
    import xml.etree.ElementTree as ET
    ET.parse(path)  # raises ParseError on malformed XML
    from obci_readmanager.signal_processing.tags.tags_file_reader import (
        TagsFileReader)
    reader = TagsFileReader(path)
    tags = reader.get_tags()
    rejections = set()
    for tag in tags or ():
        desc = tag.get("desc") or {}
        raw = desc.get("idx")
        if raw is None:
            continue
        try:
            rejections.add(int(str(raw).strip()))
        except (TypeError, ValueError):
            continue
    return rejections


def _write_channel_tag_file(path, channel_names, all_channel_names):
    """Write a Svarog .tag file marking given channels as bad.

    One tag per channel: ``name`` = channel name, ``channelNumber``
    = 0-based index, point tag (duration 0).  Channels not found in
    *all_channel_names* are silently skipped.
    """
    from obci_readmanager.signal_processing.tags.tags_file_writer import (
        TagsFileWriter)
    name_to_idx = {n: i for i, n in enumerate(all_channel_names)}
    writer = TagsFileWriter(path)
    for ch_name in channel_names:
        idx = name_to_idx.get(ch_name)
        if idx is None:
            continue
        writer.tag_received({
            "channelNumber": idx,
            "start_timestamp": 0.0,
            "end_timestamp": 0.0,
            "name": ch_name,
            "desc": {"typ": "bad_channel"},
        })
    writer.finish_saving(0.0)


def _read_channel_tag_file(path):
    """Return bad-channel names from a Svarog tag file.

    Uses the tag's ``name`` field as the channel name (what Svarog
    writes on the bad-channel selection path).  Order is preserved
    by first appearance; duplicates are removed.

    The XML is validated with ``xml.etree`` before handing off to
    ``TagsFileReader``, which otherwise silently treats a corrupt
    file as empty — we want to distinguish corrupt from "user saved
    with no selection".
    """
    import xml.etree.ElementTree as ET
    ET.parse(path)  # raises ParseError on malformed XML
    from obci_readmanager.signal_processing.tags.tags_file_reader import (
        TagsFileReader)
    reader = TagsFileReader(path)
    tags = reader.get_tags()
    names = []
    seen = set()
    for tag in tags or ():
        name = (tag.get("name") or "").strip()
        if not name or name in seen:
            continue
        names.append(name)
        seen.add(name)
    return names


def _render_topomaps_inline(ica, out_dir):
    """Render one ``comp_<idx>.png`` per ICA component into *out_dir*.

    Uses ``ica.plot_components(picks=[idx], show=False)`` per component
    — the default ``plot_components`` packs up to 20 per figure,
    which would break the comp_<idx>.png naming convention.

    **Thread safety caveat**: matplotlib from a background thread on
    macOS (even with Agg backend) can segfault when Qt owns the main
    event loop.  The GUI wraps this via ``topomap_renderer=`` so the
    actual drawing runs on the Qt main thread.  Direct callers (CLI,
    tests, scripts without a Qt app) can call this inline safely.
    """
    import matplotlib.pyplot as plt
    n_components = int(ica.n_components_)
    for idx in range(n_components):
        fig = ica.plot_components(picks=[idx], show=False)
        if isinstance(fig, list):
            fig = fig[0]
        try:
            fig.savefig(
                os.path.join(out_dir, f"comp_{idx}.png"), dpi=80)
        finally:
            plt.close(fig)


def review_ica_via_svarog(
        raw,
        ica,
        svarog_jar,
        *,
        preselected=None,
        timeout_s=3600,
        java_path="java",
        extra_args=None,
        subprocess_runner=subprocess.run,
        topomap_renderer=None,
):
    """Prompt the user to mark ICA components for exclusion in Svarog.

    Mirror of :func:`review_bad_channels_via_svarog` for the
    ICA-component case.  Pre-renders the input Svarog needs:

    1. ``sources-raw.fif``: the projected component sources
       (``ica.get_sources(raw)``), saved as a regular FIF — Svarog
       displays them with its standard signal-trace machinery,
       channels labeled ``ICA000``, ``ICA001``, ...
    2. ``topomaps/comp_<idx>.png``: per-component topomap PNGs
       rendered via ``ica.plot_components(picks=[idx], show=False)``.
       Pre-rendering avoids porting MNE's topomap pipeline to Java.

    Then launches Svarog with ``--select-mode ica_components``,
    parses the output tag file (one ``<tag>`` per excluded
    component, payload in ``<idx>``), and returns the list.

    Parameters
    ----------
    raw : mne.io.Raw
        The signal the ICA was fit on.  Used to compute the source
        projections.
    ica : mne.preprocessing.ICA
        The fitted ICA object.  ``ica.exclude`` is not consulted
        here — pass the auto-detected set as *preselected*.
    svarog_jar : str
        Path to the Svarog jar file.
    preselected : iterable of int or None
        Component indices to pre-mark as excluded (typically the
        auto-detected set from ICLabel + EOG/ECG/muscle correlation).
    timeout_s : int
        Maximum seconds to wait for Svarog.  Default 1 hour.
    java_path : str
        ``java`` binary to invoke.
    extra_args : list[str] or None
        Additional CLI args forwarded to Svarog.
    subprocess_runner : callable
        Seam for tests.  ``subprocess.run``-compatible; returns
        an object with ``returncode``.

    Returns
    -------
    list[int] or None
        Component indices to exclude.  Empty list if the user
        saved with no selection.  ``None`` on cancel, timeout,
        launch failure, or corrupt output.
    """
    if not svarog_jar or not os.path.isfile(svarog_jar):
        logger.warning("Svarog jar not found: %s", svarog_jar)
        return None

    work_dir = tempfile.mkdtemp(prefix="svarog_ica_review_")
    try:
        sources_path = os.path.join(work_dir, "sources-raw.fif")
        ica.get_sources(raw).save(
            sources_path, overwrite=True, verbose=False)

        topomaps_dir = os.path.join(work_dir, "topomaps")
        os.makedirs(topomaps_dir, exist_ok=True)
        # Delegate rendering via the optional topomap_renderer hook
        # so the GUI can bounce it onto the Qt main thread
        # (matplotlib + worker thread segfaults on macOS even with
        # Agg).  CLI / test callers get the inline default.
        n_components = int(ica.n_components_)
        render = topomap_renderer or _render_topomaps_inline
        render(ica, topomaps_dir)

        output_path = os.path.join(work_dir, "excluded.tag")
        cmd = [java_path, *appcds_flags(svarog_jar, java_path),
               "-jar", svarog_jar, sources_path,
               "--select-mode", "ica_components",
               "--output", output_path,
               "--ica-topomaps", topomaps_dir,
               "--nosplash"]
        if preselected:
            preselect_path = os.path.join(work_dir, "preselect.tag")
            _write_component_tag_file(preselect_path, preselected)
            cmd.extend(["--preselect", preselect_path])
        if extra_args:
            cmd.extend(extra_args)

        logger.info("Launching Svarog for ICA review: %s", " ".join(cmd))
        try:
            result = subprocess_runner(
                cmd, timeout=timeout_s, check=False)
        except subprocess.TimeoutExpired:
            logger.warning("Svarog ICA review timed out after %ds",
                           timeout_s)
            return None
        except (OSError, FileNotFoundError) as e:
            logger.warning("Svarog launch failed: %s", e)
            return None

        rc = getattr(result, "returncode", None)
        if rc != 0:
            logger.info("Svarog exited with code %s — treating as cancel",
                        rc)
            return None
        if not os.path.isfile(output_path):
            logger.info("Svarog didn't write %s — treating as cancel",
                        output_path)
            return None

        try:
            indices = _read_component_tag_file(output_path)
        except Exception as e:
            logger.warning("Failed to parse Svarog output %s: %s",
                           output_path, e)
            return None

        # Filter to valid component indices — defence against a
        # stale tag file referring to components that don't exist.
        excludes = sorted(i for i in indices if 0 <= i < n_components)
        logger.info("Svarog ICA review returned %d excluded component(s): %s",
                    len(excludes), excludes)
        return excludes
    finally:
        try:
            shutil.rmtree(work_dir)
        except OSError:
            pass


def _write_component_tag_file(path, indices):
    """Write a Svarog .tag file marking the given ICA components for
    exclusion.

    One tag per index.  ``name`` = ``ICA<idx>`` (cosmetic);
    ``desc.idx`` = integer index (the actual payload).
    ``position`` / ``length`` are zero — ICA exclusion has no time
    anchor.  Mirror of :func:`_write_epoch_tag_file`; only the
    ``typ`` value differs (``exclude_component`` vs ``reject_epoch``).
    """
    from obci_readmanager.signal_processing.tags.tags_file_writer import (
        TagsFileWriter)
    writer = TagsFileWriter(path)
    for idx in indices:
        idx = int(idx)
        writer.tag_received({
            "channelNumber": -1,
            "start_timestamp": 0.0,
            "end_timestamp": 0.0,
            "name": f"ICA{idx:03d}",
            "desc": {"typ": "exclude_component", "idx": str(idx)},
        })
    writer.finish_saving(0.0)


def _read_component_tag_file(path):
    """Return excluded ICA component indices from a Svarog tag file.

    Reads the ``idx`` child of each ``<tag>`` whose ``typ`` is
    ``exclude_component`` and coerces to int; tags without a valid
    numeric ``idx`` or with a different type are skipped.  Returns
    a list (order preserved by first appearance; duplicates
    dropped).

    XML is validated via ``xml.etree`` first to distinguish a
    corrupt file from "user saved with no selection".
    """
    import xml.etree.ElementTree as ET
    ET.parse(path)  # raises ParseError on malformed XML
    from obci_readmanager.signal_processing.tags.tags_file_reader import (
        TagsFileReader)
    reader = TagsFileReader(path)
    tags = reader.get_tags()
    out = []
    seen = set()
    for tag in tags or ():
        desc = tag.get("desc") or {}
        if desc.get("typ") != "exclude_component":
            continue
        idx_raw = desc.get("idx")
        if idx_raw is None:
            continue
        try:
            idx = int(str(idx_raw).strip())
        except (TypeError, ValueError):
            continue
        if idx in seen:
            continue
        out.append(idx)
        seen.add(idx)
    return out
