"""Matching Pursuit preprocessing steps for IDE4EEG.

Provides two pipeline steps:

- **mp_decompose** — run MP decomposition on the preprocessed signal,
  producing a persistent ``.db`` book file.
- **mp_filter** — reconstruct the signal from a subset of atoms
  (nonlinear filtering), replacing the Raw data in-place.

Both functions operate on the pipeline *state* dict used by
``preprocessing.py``'s step registry.

References:

  Mallat SG, Zhang Z (1993) "Matching Pursuits with Time-Frequency
  Dictionaries." IEEE Trans Signal Process 41(12):3397-3415.
  https://doi.org/10.1109/78.258082

  Kus R, Rozanski PT, Durka PJ (2013) "Multivariate matching pursuit
  in optimal Gabor dictionaries." BioMed Eng OnLine 12:94.
  https://doi.org/10.1186/1475-925X-12-94

  Rozanski PT (2024) "empi: GPU-Accelerated Matching Pursuit with
  Continuous Dictionaries." ACM Trans Math Softw 50(3):17.
  https://doi.org/10.1145/3674832

  Rozanski PT (2024) "Heterogeniczna implementacja matching pursuit
  z symulacja ciagłej przestrzeni parametrow." PhD thesis,
  University of Warsaw.
  https://www.mimuw.edu.pl/media/uploads/doctorates/thesis-piotr-rozanski.pdf
"""

# Author: Piotr Durka / Claude, 2026

import glob
import hashlib
import json
import logging
import os
import sqlite3

import mne
import numpy as np

from .channels_and_signal import (get_segment_params,
                                    get_segment_events,
                                    _stim_channel_names)
from .preprocessing import strip_runtime_fields


# ── MP book reuse — hash & auto-discovery ────────────────────────────
#
# When ``mp_decomposition`` runs we stamp a hash of the MP-relevant
# config into the book's SQLite ``metadata`` table.  When the step is
# *disabled* in step_order, the preprocessing preamble auto-discovers
# an existing book on disk and verifies the hash still matches —
# reusing the book if it does, halting with a clear error if it
# doesn't, soft-warning if the book predates hash stamping.
#
# Scope of the hash: every preprocessing config section that could
# influence what data MP sees, minus ``epochs`` (postamble — runs
# after MP) and ``mp_filter`` (configures reconstruction, not the
# decomposition).  Plus an identity tuple for the input file (name
# + size + mtime) so re-recorded data invalidates books from prior
# recordings.

_MP_HASH_KEYS = (
    "preprocessing",  # step_order — reordering invalidates
    "trim_start", "trim_end",
    "resample_freq",
    "segmentation", "rest", "events_desc_id",
    "choosing_channels",
    "bad_channels",
    "montage", "re_reference",
    "filters",
    "ICA_EOG",
    "artifacts",
    "matching_pursuit",
    # NOT included:
    #   epochs    — postamble; runs after MP, can't affect MP input
    #   mp_filter — same; configures reconstruction, not decomposition
)

# Fields inside ``matching_pursuit`` that don't affect the
# decomposition output — strip before hashing so editing them doesn't
# spuriously invalidate the book hash and force an empi rerun.
# ``filter`` (mp_filter parameters) is reconstruction-only: it picks
# atoms from an already-decomposed book, so users can iterate on
# filter settings without paying the empi cost again.
_MP_CFG_RUNTIME_FIELDS = (
    "empi_path", "_default_workers", "_segment_size", "outputs",
    "cpu_workers", "filter",
)


def canonical_input_path(config):
    """Resolve the input file path most likely to match the runner's
    view of it.  Prefers ``_input_dir`` / ``_input_file_name`` (set by
    the runner before each file's run), falls back to splitting
    ``input_path`` so callers from outside the runner's loop also get
    a real path instead of ``os.path.join("", "")``."""
    inp = config.get("input_path", "") or ""
    return os.path.join(
        config.get("_input_dir", "") or os.path.dirname(inp),
        config.get("_input_file_name", "") or os.path.basename(inp))


def pin_mp_book_hash(config, *, force=False):
    """Pin ``config["_mp_book_hash"]`` if missing (or always when
    *force* is True).  Guarded so the expensive ``_compute_mp_book_hash``
    (an ``os.stat`` on the input + JSON serialization) doesn't run
    when a pin is already present."""
    if not force and "_mp_book_hash" in config:
        return
    config["_mp_book_hash"] = _compute_mp_book_hash(
        config, canonical_input_path(config))


def _compute_mp_book_hash(config, input_file_path=None):
    """Return a short stable digest of MP-relevant config + input file.

    Parameters
    ----------
    config : dict
        Pipeline config (post-load, pre-mutation).
    input_file_path : str or None
        Absolute path to the source EEG file.  When the file exists,
        its (basename, size, mtime_ns) are folded into the hash so
        re-recording over the same name produces a fresh hash.

    Returns
    -------
    str
        16-character hex digest (blake2b, 8 bytes).  Not cryptographic
        — collision probability is fine for cache invalidation.
    """
    relevant = {k: config[k] for k in _MP_HASH_KEYS if k in config}
    # Two-pass strip: shared UI-drawer fields (save / save_plots /
    # save_tag) across every block, then MP-book-specific runtime
    # fields (cpu_workers / filter / empi_path / ...) on the
    # matching_pursuit block alone.  Don't fold the latter into
    # _STEP_HASH_RUNTIME_FIELDS — only the *book* hash ignores them;
    # the per-step hash for mp_decomposition keeps the conservative
    # behaviour.
    strip_runtime_fields(relevant)
    if "matching_pursuit" in relevant:
        mp_cfg = dict(relevant["matching_pursuit"])
        for k in _MP_CFG_RUNTIME_FIELDS:
            mp_cfg.pop(k, None)
        relevant["matching_pursuit"] = mp_cfg
    if input_file_path and os.path.isfile(input_file_path):
        st = os.stat(input_file_path)
        relevant["_input_file"] = {
            "name": os.path.basename(input_file_path),
            "size": st.st_size,
            "mtime_ns": st.st_mtime_ns,
        }
    blob = json.dumps(relevant, sort_keys=True, default=str)
    return hashlib.blake2b(blob.encode(), digest_size=8).hexdigest()


def _read_book_hash(book_path):
    """Return the ``_input_hash`` stored in *book_path*, or None.

    Returns ``None`` for: missing file, unreadable SQLite, or a book
    that predates hash stamping (no row in the metadata table).
    """
    if not os.path.isfile(book_path):
        return None
    try:
        with sqlite3.connect(book_path) as conn:
            row = conn.execute(
                "SELECT value FROM metadata "
                "WHERE param = '_input_hash'").fetchone()
        return row[0] if row else None
    except sqlite3.Error:
        return None


def _read_book_channels(book_path):
    """Return list of channel names stored in *book_path*'s metadata.

    Returns ``[]`` for missing file, unreadable SQLite, or absent
    ``channel_names`` row (very old books).
    """
    if not os.path.isfile(book_path):
        return []
    try:
        with sqlite3.connect(book_path) as conn:
            row = conn.execute(
                "SELECT value FROM metadata "
                "WHERE param = 'channel_names'").fetchone()
        if row and row[0]:
            return [c.strip() for c in row[0].split(",") if c.strip()]
    except sqlite3.Error:
        pass
    return []


def _required_consumer_channels(config):
    """Return ``{consumer_label: channel_name}`` for enabled consumers
    that need a specific named channel from the MP book.

    Only includes consumers whose channel is set explicitly in config.
    Empty/missing channel = the consumer hasn't picked one yet (a
    separate preflight catches that); we don't raise here on its
    behalf.
    """
    needs = {}
    if config.get("prepare_eeg_profiles"):
        ch = config.get("eeg_profiles", {}).get("channel", "")
        if isinstance(ch, str) and ch.strip():
            needs["EEG Profiles"] = ch.strip()
    return needs


def _book_hash_status(book_path, expected_hash):
    """Classify an on-disk MP book against the expected hash.

    Returns
    -------
    status : str
        ``"absent"`` (no file), ``"legacy"`` (file exists, no hash
        stamped), ``"match"`` (stamped hash equals *expected_hash*),
        or ``"mismatch"`` (stamped hash differs).  A truncated or
        otherwise unreadable .db is reported as ``"absent"`` so
        ``mp_decompose`` re-runs empi instead of trusting a corrupt
        cache.
    stored : str or None
        The stamped hash, or ``None`` for absent/legacy.
    """
    if not os.path.isfile(book_path):
        return "absent", None
    # Smoke-test that the SQLite file is at least structurally valid
    # — a prior interrupted write can leave a truncated .db whose
    # hash row exists but whose binary structure is corrupt.
    # ``sqlite_master`` is the schema table that always exists, so
    # this query passes for legacy / minimal books and only fails
    # on actual file corruption (raising sqlite3.DatabaseError).
    try:
        import sqlite3
        with sqlite3.connect(book_path) as _conn:
            _conn.execute(
                "SELECT name FROM sqlite_master LIMIT 1").fetchone()
    except sqlite3.DatabaseError as exc:
        logging.warning(
            "MP book at %s is unreadable (%s) — treating as absent "
            "and re-running empi.", book_path, exc)
        return "absent", None
    stored = _read_book_hash(book_path)
    if stored is None:
        return "legacy", None
    if stored == expected_hash:
        return "match", stored
    return "mismatch", stored


def _resolve_existing_book_path(config, path, file_name):
    """Find an MP book on disk for *file_name* in *path*'s mp_decomposition/.

    Uses the same naming convention as ``mp_decompose`` writes
    (``book_<base>_<suffix>.db``).  Heuristic for choosing among
    multiple candidates:

    * 0 candidates → return ``None``.
    * 1 candidate  → return it (hash check happens upstream).
    * >1 candidates → return the one whose hash matches
      ``config["_mp_book_hash"]``; if zero or multiple match,
      return ``None`` (ambiguous — caller will fall through to the
      "no book" branch and analysis will use the ephemeral path).
    """
    mp_dir = os.path.join(path, "mp_decomposition")
    if not os.path.isdir(mp_dir):
        return None
    base = os.path.splitext(file_name)[0]
    candidates = sorted(
        glob.glob(os.path.join(mp_dir, f"book_{base}_*.db")))
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    expected_hash = config.get("_mp_book_hash")
    if not expected_hash:
        return None
    matches = [c for c in candidates
               if _read_book_hash(c) == expected_hash]
    return matches[0] if len(matches) == 1 else None


def _lookup_existing_book(config, path, file_name):
    """Resolve and classify the on-disk MP book for ``file_name``.

    Returns ``(status, book_path, stored, expected)`` where
    ``status`` is ``"absent"`` / ``"legacy"`` / ``"match"`` / ``"mismatch"``,
    ``book_path`` is ``None`` for absent and otherwise the resolved
    path, ``stored`` is the on-disk stamped hash (or None), and
    ``expected`` is the hash compared against (or ``None`` when no
    book was found — callers don't consume it on the absent branch).
    The expected hash is computed lazily so first-run paths skip the
    ``os.stat`` on the input file when no book is on disk anyway.
    """
    book_path = _resolve_existing_book_path(config, path, file_name)
    if book_path is None:
        return "absent", None, None, None
    expected = config.get("_mp_book_hash") or _compute_mp_book_hash(
        config, canonical_input_path(config))
    status, stored = _book_hash_status(book_path, expected)
    return status, book_path, stored, expected


def try_reuse_existing_mp_book(state):
    """Auto-discovery preamble for the disabled-MP-step path.

    Called from ``preprocessing.preprocessing()`` when
    ``mp_decomposition`` is absent from ``step_order``.  Sets
    ``config["_mp_book_path"]`` if a usable book is found, raises
    ``RuntimeError`` on a hash mismatch (so silent staleness can never
    reach analysis), and is a no-op when no book exists.

    Short-circuits to a no-op when no enabled analysis actually needs
    a book — otherwise we'd halt or warn about an existing book that
    nothing in the current run is going to read.

    Returns
    -------
    state : dict
        Same state, possibly with ``config["_mp_book_path"]`` set.
    """
    cfg = state["config"]
    # No book consumers enabled → the book on disk (if any) is
    # irrelevant to this run.  Don't read its hash, don't warn, don't
    # halt on mismatch.
    from ..main import mp_consumers_from_cfg
    if not mp_consumers_from_cfg(cfg):
        return state
    status, book_path, stored, expected_hash = _lookup_existing_book(
        cfg, state["path"], state["file_name"])
    if status == "absent":
        return state
    if status == "mismatch":
        raise RuntimeError(
            "MP decomposition is disabled, but the existing book at\n"
            f"  {book_path}\n"
            "was produced with a different configuration. Either:\n"
            "  • Check the MP decomposition step to recompute, or\n"
            "  • Restore the upstream parameters that produced this "
            "book.\n"
            f"Stored hash:  {stored}\n"
            f"Current hash: {expected_hash}")

    # Even when the MP config (and therefore the hash) matches, the
    # book may not contain a channel that an enabled DOWNSTREAM
    # analysis explicitly requires (e.g. ``eeg_profiles.channel``).
    # Catch that here — failing at preflight beats failing two minutes
    # later inside ``eeg_profiles()`` after preprocessing has run.
    needs = _required_consumer_channels(cfg)
    if needs:
        book_channels = _read_book_channels(book_path)
        missing = {label: ch for label, ch in needs.items()
                   if ch not in book_channels}
        if missing:
            lines = "\n".join(f"  • {label} needs '{ch}'"
                              for label, ch in missing.items())
            book_list = ", ".join(book_channels) if book_channels \
                else "(none recorded)"
            raise RuntimeError(
                "Existing MP book at\n"
                f"  {book_path}\n"
                f"contains channels [{book_list}] but enabled\n"
                "analyses require channels not in the book:\n"
                f"{lines}\n\n"
                "Either set the analysis channel to one in the book, "
                "or check MP Decomposition AND update "
                "matching_pursuit.channels to include the required "
                "channel(s) — this will rewrite the book.")

    cfg["_mp_book_path"] = book_path
    if status == "match":
        logging.info(
            "MP: reusing existing book (hash match): %s", book_path)
    else:  # legacy
        logging.warning(
            "MP: reusing book without hash (predates this feature) "
            "— cannot verify freshness: %s", book_path)
    return state


def mp_decompose(state, progress_callback=None, cancel_event=None):
    """Run MP decomposition on the current signal.

    Uses event markers (STIM channel) to determine segment boundaries,
    then runs empi per segment.  For SMP each channel is decomposed
    independently; for MMP all data channels are decomposed jointly.

    Results are saved to a persistent ``.db`` book in the output
    directory.  The path is stored in
    ``state["config"]["_mp_book_path"]``.

    Extra metadata (signal_unit, scale_to_uV, channel_names, …) is
    injected into the book so that downstream consumers (analysis,
    BookViewer) can display proper units without guessing.

    Parameters
    ----------
    state : dict
        Pipeline state with keys: signal, config, tags_desc_id,
        path, file_name, etc.
    progress_callback : callable or None, optional
        Called with percentage (0–100) during empi execution.
    cancel_event : threading.Event or None, optional
        If set, the empi subprocess is killed and a RuntimeError
        is raised.

    Returns
    -------
    state : dict
        Updated state (config gains ``_mp_book_path``).
    """
    from ..analysis.mp_analysis import run_empi

    signal = state["signal"]
    config = state["config"]
    tags_desc_id = state["tags_desc_id"]
    path = state["path"]
    file_name = state["file_name"]

    mp_cfg = config.get("matching_pursuit", {})

    # Freshness check: if a book on disk already matches the current
    # MP config, skip empi entirely.  Mismatch / legacy / absent fall
    # through to the empi path below, which rewrites the book.
    status, existing_book, stored, expected_hash = _lookup_existing_book(
        config, path, file_name)
    if status == "match":
        config["_mp_book_path"] = existing_book
        logging.info(
            "MP Decomposition: reusing existing book (hash match), "
            "skipping empi: %s", existing_book)
        return state
    if existing_book is not None:
        logging.debug(
            "MP Decomposition: existing book at %s won't be reused "
            "(status=%s, stored=%r, expected=%r) — running empi to "
            "rewrite it.",
            existing_book, status, stored, expected_hash)
    else:
        logging.debug(
            "MP Decomposition: no existing book in %s — running empi.",
            os.path.join(path, "mp_decomposition"))

    # Inherit default worker count from parallelism.n_jobs — see
    # _build_empi_cmd in mp_analysis for the full resolution order.
    from ide4eeg.utils.parallel import resolve_n_jobs
    mp_cfg.setdefault("_default_workers", resolve_n_jobs(config))

    empi_path = mp_cfg.get("empi_path", "")
    if not empi_path or not os.path.isfile(empi_path):
        # Auto-detect from standard locations
        from ide4eeg.gui_config import _find_empi
        empi_path = _find_empi() or ""
    if not empi_path or not os.path.isfile(empi_path):
        raise RuntimeError(
            f"empi binary not found at '{empi_path}'. "
            "Please set the correct path in MP configuration.")

    sfreq = signal.info["sfreq"]

    # ── Determine data channels ─────────────────────────────────────
    ch_types = signal.get_channel_types()
    ch_type_map = dict(zip(signal.info["ch_names"], ch_types))
    algorithm = mp_cfg.get("algorithm", "smp").lower()
    sel_channels = mp_cfg.get("channels", "")

    if sel_channels:
        # User-specified channel list (applies to both SMP and MMP)
        if isinstance(sel_channels, list):
            sel_list = [c.strip() for c in sel_channels if c.strip()]
        else:
            sel_list = [c.strip() for c in str(sel_channels).split(",")
                        if c.strip()]
        all_names = set(signal.info["ch_names"])
        available = [c for c in sel_list if c in all_names]
        dropped = [c for c in sel_list if c not in all_names]
        if dropped:
            logging.warning(
                "MP: skipping %d channel(s) not in the current "
                "signal (dropped by an earlier step?): %s",
                len(dropped), ", ".join(dropped))
        if not available:
            raise RuntimeError(
                "No selected MP channels remain after earlier "
                "preprocessing steps dropped them. Available: "
                + ", ".join(signal.info["ch_names"]))
        data_ch_names = available
    elif algorithm in ("mmp1", "mmp3"):
        # MMP default: EEG channels only (exclude stim, eog, emg, ecg, misc)
        eeg_types = {"eeg"}
        data_ch_names = [ch for ch, ct in ch_type_map.items()
                         if ct in eeg_types]
        if not data_ch_names:
            # Fallback: all non-stim channels
            data_ch_names = [ch for ch, ct in ch_type_map.items()
                             if ct != "stim"]
        logging.info("MMP: using %d EEG channels (of %d total)",
                     len(data_ch_names), len(signal.info["ch_names"]))
    else:
        # SMP default: EEG channels only (exclude stim, eog, emg, ecg, misc)
        _eeg_only = {"eeg"}
        data_ch_names = [ch for ch, ct in ch_type_map.items()
                         if ct in _eeg_only]
        if not data_ch_names:
            # Fallback: all data channels, filtered by type so every
            # stim-type channel (legacy snapshots may carry two —
            # STIM + STIM_rest) is excluded without naming them.
            _exclude = {"stim", "eog", "emg", "ecg", "misc"}
            data_ch_names = [ch for ch, ct in ch_type_map.items()
                             if ct not in _exclude]

    # ── Find segment boundaries from STIM channel ────────────────────
    params = get_segment_params(config)
    tmin, tmax = params["tmin"], params["tmax"]
    mode = params["mode"]

    # window_length=0 in rest mode means use the whole signal
    if mode == "rest" and tmax == 0:
        tmax = signal.times[-1]

    # Mode-aware event lookup via get_segment_events().  Rest mode
    # reads REST annotations (synthetic window onsets attached by
    # _add_rest_markers); event-locked mode reads the original STIM
    # channel (file-derived events).
    events = get_segment_events(signal, config)
    if len(events) == 0:
        raise RuntimeError(
            f"No segment-boundary events found. Cannot determine "
            f"MP decomposition windows in {mode} mode.")

    if mode == "rest":
        event_ids = [tags_desc_id.get("rest")]
    else:
        event_ids = [v for k, v in tags_desc_id.items() if k != "rest"]

    logging.debug(
        "MP events: mode=%s, tags_desc_id=%s, event_ids=%s, "
        "raw events=%d, unique event codes=%s",
        mode, tags_desc_id, event_ids, len(events),
        np.unique(events[:, 2]).tolist() if len(events) > 0 else [])

    event_mask = np.isin(events[:, 2], event_ids)
    events = events[event_mask]

    if len(events) == 0:
        # Include diagnostic info in the error message
        stim_names = _stim_channel_names(signal.info)
        stim_ch_name = stim_names[0] if stim_names else None
        if stim_ch_name is not None:
            stim_data = signal.get_data(picks=[stim_ch_name]).flatten()
            n_nonzero = int(np.sum(stim_data != 0))
            unique_vals = np.unique(stim_data[stim_data != 0]).tolist()
            stim_diag = (f"STIM channel {stim_ch_name!r} has "
                         f"{n_nonzero} non-zero samples, "
                         f"unique values: {unique_vals[:20]}")
        else:
            stim_diag = "No STIM channel found in signal"
        raise RuntimeError(
            f"No matching events for MP decomposition.\n"
            f"Mode: {mode}, expected event IDs: {event_ids}\n"
            f"{stim_diag}\n"
            f"tags_desc_id: {tags_desc_id}")

    # ── Prepare output ───────────────────────────────────────────────
    mp_dir = os.path.join(path, "mp_decomposition")
    os.makedirs(mp_dir, exist_ok=True)
    base = os.path.splitext(file_name)[0]
    # Naming convention:
    #   SMP, 1 channel:  book_{base}_{ChannelName}.db
    #   SMP, N channels: book_{base}_smp.db
    #   MMP:             book_{base}_{mmp1|mmp3}.db
    if algorithm == "smp":
        if len(data_ch_names) == 1:
            # Sanitize channel name for filesystem use: keep alphanumerics and
            # a few safe punctuation chars, replace everything else with '-'.
            raw = data_ch_names[0]
            ch_suffix = "".join(c if (c.isalnum() or c in "._-")
                                else "-" for c in raw)
            ch_suffix = ch_suffix.strip("-") or "ch"
        else:
            ch_suffix = "smp"
        book_path = os.path.join(mp_dir, f"book_{base}_{ch_suffix}.db")
    else:
        book_path = os.path.join(mp_dir, f"book_{base}_{algorithm}.db")

    # ── Extract epoch windows and write a combined signal file ───────
    n_seg_samples = int(round((tmax - tmin) * sfreq))
    tmin_samples = int(round(tmin * sfreq))

    # MNE returns biopotential channels in V (SI).  Convert to µV at the
    # empi boundary so atom amplitudes baked into the .db are µV-native
    # — matches Svarog's display convention and obviates the need for a
    # per-reader scale_to_uV multiplier.  Older V-scale .db files
    # (pre-2026-05-15) still read correctly via the metadata multiplier
    # in mp_analysis.py:162.
    raw_data = signal.get_data(picks=data_ch_names) * 1e6  # V → µV
    n_channels = len(data_ch_names)
    first_samp = signal.first_samp  # offset after crop()

    # Build a multi-segment signal array: concatenate all epochs
    # empi processes segments via --segment-size
    segments_data = []
    epoch_offsets = []

    for ev in events:
        onset_sample = ev[0] - first_samp  # convert to array index
        start = onset_sample + tmin_samples
        stop = start + n_seg_samples
        # Clamp to signal bounds
        if start < 0 or stop > raw_data.shape[1]:
            logging.warning(
                "Segment at sample %d out of bounds, skipping.", onset_sample)
            continue
        segments_data.append(raw_data[:, start:stop])
        epoch_offsets.append(onset_sample / sfreq + tmin)

    if not segments_data:
        raise RuntimeError(
            "No valid segments for MP decomposition. "
            "All segments were out of signal bounds.")

    n_segments = len(segments_data)
    # Concatenate all segments along the time axis: (n_ch, n_seg * n_samples).
    # The interleaved layout for empi is handled by run_empi.
    combined = np.concatenate(segments_data, axis=1)  # (n_ch, n_seg*n_samples)

    from datetime import datetime
    logging.info(
        "MP decomposition: %d segments × %d channels × %d samples, "
        "algorithm=%s. Started: %s",
        n_segments, n_channels,
        n_seg_samples, mp_cfg.get("algorithm", "smp"),
        datetime.now().strftime("%H:%M:%S"))

    # Add segment-size to mp_cfg for this run
    run_cfg = dict(mp_cfg)
    run_cfg["_segment_size"] = n_seg_samples

    # ── Extra metadata for the book ──────────────────────────────────
    # signal_unit / scale_to_uV: atoms in the .db are µV-native since
    # 2026-05-15 (the V→µV conversion happens at line 597 above).  The
    # stamp stays for backward-compat with readers that still apply it
    # — for new books the 1.0 multiplier is a no-op.
    #
    # ``_input_hash``: pinned in ``preprocessing()`` from the
    # USER-level config (pre-mutation) so that a re-run with
    # mp_decomposition disabled can verify the book on disk still
    # matches the requested config.  Falls back to a live recompute
    # for callers that bypass the preprocessing preamble.
    book_hash = (
        config.get("_mp_book_hash")
        or _compute_mp_book_hash(config, canonical_input_path(config)))
    extra_meta = {
        "signal_unit": "uV",
        "scale_to_uV": "1.0",
        "channel_names": ",".join(data_ch_names),
        "algorithm": algorithm.upper(),
        "analysis_mode": mode,
        "source_file": file_name,
        "epoch_offsets": ",".join(f"{t:.6f}" for t in epoch_offsets),
        "segment_tmin": str(tmin),
        "segment_tmax": str(tmax),
        "_input_hash": book_hash,
    }

    # ── Run empi ─────────────────────────────────────────────────────
    success, error_detail = run_empi(
        combined, sfreq, empi_path, run_cfg, book_path,
        extra_metadata=extra_meta,
        progress_callback=progress_callback,
        cancel_event=cancel_event)

    if success:
        config["_mp_book_path"] = book_path
        logging.info("MP book saved to %s", book_path)
    else:
        msg = error_detail or "unknown error"
        logging.error("MP decomposition failed: %s", msg)
        raise RuntimeError(f"MP decomposition failed: {msg}")

    # ── Optional statistics reports ──────────────────────────────────
    mp_outputs = mp_cfg.get("outputs", {})
    if any(mp_outputs.get(k) for k in ("atom_stats_csv", "atom_histograms")):
        _generate_mp_reports(
            book_path, state, mp_cfg, mp_outputs, mp_dir, file_name)

    return state


def _generate_mp_reports(book_path, state, mp_cfg, mp_outputs,
                         mp_dir, file_name):
    """Generate optional statistics reports after MP decomposition."""
    from ..analysis.mp_analysis import (
        read_mp_results, _plot_atom_histograms,
        _write_atom_stats_csv)

    import sqlite3
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    config = state["config"]
    sfreq = config["sfreq"]
    base = os.path.splitext(file_name)[0]

    # Read book metadata
    try:
        conn = sqlite3.connect(book_path)
        meta = dict(conn.execute("SELECT param, value FROM metadata"))
        n_segments = int(meta.get("segment_count", 1))
        n_book_channels = int(meta.get("channel_count", 1))
        scale_to_uV = float(meta.get("scale_to_uV", 1.0))
        book_ch_names = meta.get("channel_names", "").split(",")
        if len(book_ch_names) != n_book_channels:
            book_ch_names = [f"Ch{i}" for i in range(n_book_channels)]
        conn.close()
    except sqlite3.Error as e:
        logging.error("Cannot read book metadata for reports: %s", e)
        return

    # Pick non-stim channels from the pipeline signal
    signal = state["signal"]
    ch_types = signal.get_channel_types()
    data_ch_names = [ch for ch, ct in zip(signal.info["ch_names"], ch_types)
                     if ct != "stim"]

    csv_rows = []

    for ch_idx, ch_name in enumerate(data_ch_names):
        if ch_name in book_ch_names:
            book_ch_idx = book_ch_names.index(ch_name)
        elif ch_idx < n_book_channels:
            book_ch_idx = ch_idx
        else:
            continue

        all_atoms = []
        for seg_id in range(n_segments):
            atoms = read_mp_results(book_path, seg_id, book_ch_idx)
            if not atoms:
                continue
            all_atoms.extend(atoms)

        if not all_atoms:
            continue

        # Atom statistics CSV
        if mp_outputs.get("atom_stats_csv"):
            freqs = np.array([a["f_Hz"] for a in all_atoms
                              if a["f_Hz"] is not None], dtype=float)
            scales = np.array([a["scale_s"] for a in all_atoms
                               if a["scale_s"] is not None], dtype=float)
            energies = np.array([a["energy"] for a in all_atoms
                                 if a["energy"] is not None], dtype=float)
            amplitudes = np.array([a["amplitude"] for a in all_atoms
                                   if a["amplitude"] is not None], dtype=float)
            def _safe_mean(a):
                return float(np.mean(a)) if len(a) > 0 else 0.0

            def _safe_std(a):
                return float(np.std(a)) if len(a) > 0 else 0.0

            # Convert to µV units for reporting
            s2 = scale_to_uV ** 2
            csv_rows.append({
                "channel": ch_name,
                "n_segments": n_segments,
                "n_atoms": len(all_atoms),
                "atoms_per_segment": len(all_atoms) / max(n_segments, 1),
                "freq_mean": _safe_mean(freqs),
                "freq_std": _safe_std(freqs),
                "freq_median": float(np.median(freqs)) if len(freqs) > 0 else 0.0,
                "scale_mean": _safe_mean(scales),
                "scale_std": _safe_std(scales),
                "energy_mean": _safe_mean(energies * s2),
                "energy_std": _safe_std(energies * s2),
                "energy_total": float(np.sum(energies * s2)) if len(energies) > 0 else 0.0,
                "amplitude_mean": _safe_mean(amplitudes * scale_to_uV),
                "amplitude_std": _safe_std(amplitudes * scale_to_uV),
            })

        # Atom histograms
        if mp_outputs.get("atom_histograms"):
            freqs = np.array([a["f_Hz"] for a in all_atoms
                              if a["f_Hz"] is not None], dtype=float)
            scales = np.array([a["scale_s"] for a in all_atoms
                               if a["scale_s"] is not None], dtype=float)
            energies = np.array([a["energy"] for a in all_atoms
                                 if a["energy"] is not None], dtype=float)
            _plot_atom_histograms(
                freqs, scales, energies,
                f"Atom distributions: {ch_name} "
                f"({len(all_atoms)} atoms, {n_segments} segments)",
                os.path.join(mp_dir,
                             f"{base}___MP_atoms_{ch_name}.png"),
                sfreq, scale_to_uV=scale_to_uV)

    if csv_rows and mp_outputs.get("atom_stats_csv"):
        _write_atom_stats_csv(
            csv_rows,
            os.path.join(mp_dir, f"{base}___MP_atom_stats.csv"))

    plt.close("all")
    logging.info("MP reports saved to %s", mp_dir)


def mp_filter(state):
    """Nonlinear filter: reconstruct signal from an atom subset.

    Reads the book produced by ``mp_decompose``, applies filter
    criteria from ``config["matching_pursuit"]["filter"]``, and
    reconstructs the signal from matching (mode="keep") or
    non-matching (mode="remove") atoms.  The Raw data in
    ``state["signal"]`` is replaced per epoch window.

    Parameters
    ----------
    state : dict
        Pipeline state.  Requires ``config["_mp_book_path"]`` to
        be set by a prior ``mp_decompose`` step.

    Returns
    -------
    state : dict
        Updated state with filtered signal.

    Notes
    -----
    If the book file does not exist, returns state unchanged with a warning.
    """
    from ..analysis.mp_analysis import (
        read_mp_results, filter_atoms, reconstruct_signal,
        read_book_channel_names)

    config = state["config"]
    signal = state["signal"]
    tags_desc_id = state["tags_desc_id"]

    book_path = config.get("_mp_book_path")
    if not book_path or not os.path.isfile(book_path):
        logging.warning(
            "MP Filter: no book found (mp_decompose must run first).")
        return state

    filter_cfg = config.get("matching_pursuit", {}).get("filter", {})
    filter_mode = filter_cfg.get("mode", "keep")

    # Check if any filter criteria are set
    has_criteria = any(
        filter_cfg.get(k, 0)
        for k in ("freq_min", "freq_max", "time_min", "time_max",
                   "min_energy", "max_iterations",
                   "amp_min", "amp_max", "scale_min", "scale_max"))
    if not has_criteria:
        logging.info(
            "MP Filter: no filter criteria set, signal unchanged.")
        return state

    # Read scale_to_uV from book metadata so amp_min/amp_max user
    # bounds (in µV) are applied correctly to the atom amplitudes
    # in the book's native unit.  Default 1.0 for µV-native books
    # (≥ 0.8.7); legacy V-scale books carry 1e6 in the metadata
    # field.  Without this, amp filters silently drop every atom
    # on µV-native books.  See ca9e82f (dipole/fitting.py) for
    # the analogous fix in the dipole pipeline.
    try:
        with sqlite3.connect(book_path) as _conn:
            _meta = dict(_conn.execute(
                "SELECT param, value FROM metadata"))
        scale_to_uV = float(_meta.get("scale_to_uV", 1.0))
    except (sqlite3.Error, ValueError):
        scale_to_uV = 1.0

    sfreq = signal.info["sfreq"]

    # ── Determine data channels ──────────────────────────────────────
    # Use the book's channel list as the authoritative source: it records
    # exactly which channels were decomposed.  channel_id in the atoms
    # table is the 0-based index into that list, so we must iterate in
    # the same order.  Fall back to all non-STIM signal channels only for
    # old books that pre-date the channel_names metadata field.
    book_ch_names = read_book_channel_names(book_path)
    sig_ch_names = signal.info["ch_names"]
    if book_ch_names:
        data_ch_names = [ch for ch in book_ch_names if ch in sig_ch_names]
        if not data_ch_names:
            logging.warning(
                "MP Filter: none of the book channels (%s) found in signal "
                "— falling back to all non-STIM channels.",
                ", ".join(book_ch_names))
    if not book_ch_names or not data_ch_names:
        ch_types = signal.get_channel_types()
        data_ch_names = [ch for ch, ct in zip(sig_ch_names, ch_types)
                         if ct != "stim"]

    # ── Find segment boundaries (same logic as mp_decompose) ─────────
    params = get_segment_params(config)
    tmin, tmax = params["tmin"], params["tmax"]
    mode = params["mode"]

    # Mode-aware event lookup via get_segment_events().  Rest mode
    # reads REST annotations; event-locked mode reads the STIM
    # channel.
    events = get_segment_events(signal, config)
    if len(events) == 0:
        logging.warning("MP Filter: no segment-boundary events in "
                        "%s mode.", mode)
        return state

    if mode == "rest":
        event_ids = [tags_desc_id.get("rest")]
    else:
        event_ids = [v for k, v in tags_desc_id.items() if k != "rest"]
    event_mask = np.isin(events[:, 2], event_ids)
    events = events[event_mask]

    n_seg_samples = int(round((tmax - tmin) * sfreq))
    tmin_samples = int(round(tmin * sfreq))

    raw_data = signal.get_data()  # full data including STIM
    first_samp = signal.first_samp
    data_ch_indices = [signal.info["ch_names"].index(ch)
                       for ch in data_ch_names]

    n_replaced = 0

    for seg_idx, ev in enumerate(events):
        onset_sample = ev[0] - first_samp  # convert to array index
        start = onset_sample + tmin_samples
        stop = start + n_seg_samples

        if start < 0 or stop > raw_data.shape[1]:
            continue

        for book_ch_idx, ch_idx in enumerate(data_ch_indices):
            atoms = read_mp_results(book_path,
                                    segment_id=seg_idx,
                                    channel_id=book_ch_idx)
            if not atoms:
                logging.debug(
                    "No atoms for segment %d, channel %d — skipping.",
                    seg_idx, book_ch_idx)
                continue

            filtered = filter_atoms(atoms, filter_cfg,
                                    scale_uV=scale_to_uV)

            if filter_mode == "keep":
                # Reconstruct from matching atoms only
                use_atoms = filtered
            else:
                # Reconstruct from non-matching atoms (remove matched)
                filtered_iters = {a["iteration"] for a in filtered}
                use_atoms = [a for a in atoms
                             if a["iteration"] not in filtered_iters]

            recon = reconstruct_signal(use_atoms, n_seg_samples, sfreq)
            raw_data[ch_idx, start:stop] = recon
            n_replaced += 1

    # Write modified data back into the Raw object
    if n_replaced > 0:
        new_info = signal.info.copy()
        state["signal"] = mne.io.RawArray(raw_data, new_info,
                                          verbose=False)
        logging.info(
            "MP Filter: replaced %d channel-segments (mode=%s).",
            n_replaced, filter_mode)
    else:
        logging.warning("MP Filter: no segments were filtered.")

    return state
