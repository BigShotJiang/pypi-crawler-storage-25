"""Preprocessing orchestrator for IDE4EEG.

Coordinates the full preprocessing pipeline via a configurable step
registry.  Steps can be reordered in ``config.toml``; ordering
constraints (hard and soft) are also config-driven.

The pipeline has three sections::

    PREAMBLE  (fixed, always runs)
    └── build_event_dict  — filter events_desc_id to user's selection
                            (pure config op, no signal touching)

    REORDERABLE STEPS  (user picks order & enabled/disabled)
    ├── trim              — crop to [trim_start, trim_end]
    ├── resample          — downsample to target frequency
    ├── bad_channels      — auto-detect noisy / flat / uncorrelated channels
    ├── montage           — electrode layout + optional re-reference
    ├── filter_signal     — band-pass / stop-band FIR filters
    ├── ica               — ICA-based ocular artifact removal
    ├── select_channels   — manual channel selection / exclusion
    ├── mp_decomposition  — Matching Pursuit atom decomposition (empi)
    ├── mp_filter         — nonlinear MP-based signal reconstruction
    └── detect_artifacts  — amplitude / slope / muscle / video artifact scoring

    LATE PREAMBLE  (fixed, runs after the reorderable loop)
    └── add_rest_markers  — rest mode only: attach REST annotations
                            for synthetic rest-window onsets (the
                            original STIM channel is never touched,
                            and the signal stays lazy because
                            set_annotations is pure metadata). Runs
                            *after* the reorderable loop so the
                            synthetic windows span the signal in its
                            final processed coordinate system (post
                            trim, post resample, etc.).

    POSTAMBLE  (fixed, always runs)
    ├── cut_segments          — slice continuous signal into Epochs
    ├── remove_bad_segments   — drop artifact-marked + PTP-rejected epochs
    ├── check_segments        — optional interactive manual review
    ├── save_segments         — write clean Epochs to _clean-epo.fif
    └── prepare_dataframe     — per-segment statistics summary

The preamble must run first because every downstream step depends on
the tag metadata and (in rest mode) the REST annotations it attaches.
The postamble must run last because it converts the continuous signal
into the Epochs objects that all analysis methods consume.

Step order and constraints are read from ``config["preprocessing"]``.
Legacy configs without a ``step_order`` key fall back to the order
implied by the old ``prepare_eeg_artifacts`` / ``prepare_ica`` flags.

Note
----
The original pipeline maintained two parallel signal paths (filtered
for segmentation, unfiltered for artifact detection).  The reorderable
pipeline uses a single signal path — researchers control methodology
by choosing step placement (e.g. place ``artifacts`` before
``filtering`` to detect on unfiltered data).
"""

# Author: Szymon Bocian, 2022
# Refactored: Piotr Durka / Claude, 2026

import dataclasses
import logging
import os
import re
from collections.abc import Callable

import mne
import numpy as np

from .channels_and_signal import (_resample_signal,
                                  _trim_signal,
                                  _select_channels,
                                  _set_montage,
                                  _set_reference,
                                  _filter_signal,
                                  _build_event_dict,
                                  _add_rest_markers,
                                  _maybe_add_rest_markers,
                                  _refresh_channel_metadata,
                                  _find_bad_channels,
                                  get_segmentation_mode)
from .ica import fit_and_apply_ica
from .artifacts import _detect_eeg_artifacts, _detect_gaze_artifacts
from .rest_and_epochs import (_dirty_segment_ids,
                              _cut_segments,
                              _remove_bad_segments,
                              _save_segments,
                              _check_segments,
                              _prepare_dataframe)


# ── Step wrappers ────────────────────────────────────────────────────
#
# Each wrapper takes a *state* dict and returns it (mutated).
# The state dict carries:
#   signal, config, tags_desc_id, path, file_name,
#   ica, artifacts, dirty_ids


def _step_resample(state):
    state["signal"] = _resample_signal(state["signal"], state["config"])
    return state


def _step_bad_channels(state):
    state["config"] = _find_bad_channels(
        state["signal"], state["config"], state["tags_desc_id"],
        state["path"], state["file_name"])
    state["signal"].info["bads"] = (
        state["config"]["choosing_channels"]["bad_channels"])
    state["signal"].pick(picks=None, exclude="bads")
    return state


def _step_montage(state):
    state["signal"] = _set_montage(
        state["signal"], state["config"])
    return state


def _step_reference(state):
    state["signal"] = _set_reference(
        state["signal"], state["config"])
    return state


def _step_filtering(state):
    """Run a single filter block.

    Multi-instance step (Phase 2): step_order tokens of the form
    ``"filtering:<id>"`` select which filter config to apply.  When
    no ID is present (legacy single-filter form), uses the flat
    ``cfg["filters"]`` dict.
    """
    cfg = state["config"]
    step_id = state.pop("_current_step_id", "")
    filters_root = cfg.get("filters", {})
    # Detect flat (legacy) vs ID-keyed (Phase 2) layout by looking
    # for filter parameter keys at the top level.
    is_flat = any(
        k in filters_root
        for k in ("highpass_freq", "lowpass_freq",
                  "notch_freq", "method"))
    if is_flat:
        filter_cfg = filters_root
    elif step_id and isinstance(filters_root, dict) \
            and step_id in filters_root:
        filter_cfg = filters_root[step_id]
    elif isinstance(filters_root, dict) and filters_root:
        # ID not provided but a dict-of-dicts exists — use the first
        # entry (deterministic for round-trips of single-filter
        # configs that already migrated).
        filter_cfg = next(iter(filters_root.values()))
    else:
        filter_cfg = {}
    sliced_cfg = dict(cfg, filters=filter_cfg)
    state["signal"] = _filter_signal(
        state["signal"], sliced_cfg, state["path"])
    return state


def _step_ica(state):
    state["signal"] = fit_and_apply_ica(
        state["signal"], state["config"],
        state["path"], state["file_name"])
    return state


def _step_chosen_channels(state):
    results = _select_channels(
        [state["signal"]], state["tags_desc_id"], state["config"])
    state["signal"] = results[0]
    return state


def _step_eeg_artifacts(state):
    """Run EEG-based artifact detection (slopes/outliers/muscles/amplitude).

    Merges results into the cumulative ``artifacts_occurrence`` /
    ``artifacts_description`` shared with ``_step_gaze_artifacts``.
    ``bad_event_positions`` is computed once in the postamble (after
    ``_add_rest_markers`` has attached REST annotations) rather than
    here — see _dirty_segment_ids in rest_and_epochs.py.
    """
    occ, desc = _detect_eeg_artifacts(
        state["signal"], state["config"],
        state["path"], state["file_name"])
    state.setdefault("artifacts_occurrence", {}).update(occ)
    state.setdefault("artifacts_description", []).extend(desc)
    return state


def _step_gaze_artifacts(state):
    """Run video-based not-looking detection.

    Merges results into the cumulative ``artifacts_occurrence`` /
    ``artifacts_description``; ``bad_event_positions`` is recomputed
    in the postamble (same reason as :func:`_step_eeg_artifacts`).
    """
    occ, desc = _detect_gaze_artifacts(
        state["signal"], state["config"],
        state["path"], state["file_name"])
    state.setdefault("artifacts_occurrence", {}).update(occ)
    state.setdefault("artifacts_description", []).extend(desc)
    return state


def _step_mp_decomposition(state):
    from .mp_preprocessing import mp_decompose
    # Optional progress callback wired in from the GUI (when present
    # in ``manual_hooks``); CLI runs without it and mp_decompose just
    # logs progress lines instead.
    progress_cb = (state["config"].get("_manual_hooks") or {}).get(
        "mp_progress")
    return mp_decompose(state,
                        progress_callback=progress_cb,
                        cancel_event=state.get("_cancel_event"))


def _step_mp_filter(state):
    from .mp_preprocessing import mp_filter
    return mp_filter(state)


def _step_trim(state):
    state["signal"], state["config"] = _trim_signal(
        state["signal"], state["config"])
    return state


def _split_step_id(step):
    """Split a step_order token into (base_name, instance_id).

    Phase 2 multi-instance steps use ``"<base>:<id>"`` to namespace
    multiple blocks of the same step type (currently only
    ``"filtering"``).  Legacy bare names (no colon) yield an empty
    ``id``, which means "use the flat / legacy config layout".
    """
    base, _, sid = step.partition(":")
    return base, sid


# ── Step registry ────────────────────────────────────────────────────
#
# One declarative entry per preprocessing step.  Adding a new step
# means filling out a single StepDef -- the per-step "lookup tables"
# (`_STEP_SAVE_MAP`, `_STEP_CONFIG_DEPS`, `STEP_LABELS`) are derived
# views over this dict.  Before this consolidation they were three
# parallel dicts, and a new step that landed in two but not the third
# silently did the wrong thing (e.g. forgot in `_STEP_SAVE_MAP` → no
# snapshot; forgot in `_STEP_CONFIG_DEPS` → snapshot never invalidated
# when its config changed).

@dataclasses.dataclass(frozen=True)
class StepDef:
    """Everything the orchestrator needs to run one preprocessing step.

    Attributes
    ----------
    handler :
        ``_step_X(state) -> state``.  Mutates / returns the pipeline
        state dict; see existing ``_step_*`` functions.
    label :
        Display name (log lines, GUI panel headers).
    config_deps :
        Top-level config keys whose values affect this step's output.
        Used by ``_compute_step_hash`` to build the Merkle chain so
        editing a key only invalidates the snapshots for the step that
        consumes it and everything downstream.  Note: the
        ``"preprocessing"`` block (step_order, hard/soft constraints,
        enabled flags) is added automatically by ``_compute_step_hash``
        and doesn't need listing.
    save_section :
        Config section that carries the ``save`` toggle for this step
        (e.g. ``[filters]`` -> ``"filters"``).  ``None`` for steps
        whose output is metadata-only (montage) or non-FIF (the .db
        book for mp_decomposition).
    save_suffix :
        FIF filename infix used by ``_save_step_signal_if_requested``.
        ``None`` iff ``save_section`` is ``None``.
    """
    handler: Callable[[dict], dict]
    label: str
    config_deps: tuple[str, ...]
    save_section: str | None = None
    save_suffix: str | None = None


STEP_REGISTRY: dict[str, StepDef] = {
    "trim": StepDef(
        _step_trim, "Trim signal",
        config_deps=("trim_start", "trim_end"),
        save_section="trim", save_suffix="trimmed"),
    "resample": StepDef(
        _step_resample, "Resample",
        config_deps=("resample_freq",),
        save_section="resample", save_suffix="resampled"),
    "bad_channels": StepDef(
        _step_bad_channels, "Bad Channels",
        config_deps=("bad_channels", "choosing_channels"),
        save_section="bad_channels", save_suffix="bad-marked"),
    # ``montage`` deliberately has no save_section: ``_set_montage``
    # writes 3-D electrode coordinates into ``info["chs"]`` only —
    # sample values unchanged, so a snapshot would byte-duplicate the
    # previous step's output.  GUI shows the head-diagram instead.
    "montage": StepDef(
        _step_montage, "Montage",
        config_deps=("montage", "electrodes_layout")),
    # ``re_reference`` is a top-level string/list (e.g. "average" or
    # ["M1", "M2"]); the save flag lives in a sibling ``[reference]``
    # section to avoid clashing with the scalar.
    "reference": StepDef(
        _step_reference, "Reference",
        config_deps=("reference", "re_reference"),
        save_section="reference", save_suffix="rereferenced"),
    "filtering": StepDef(
        _step_filtering, "Filtering",
        config_deps=("filters",),
        save_section="filters", save_suffix="filtered"),
    "ica": StepDef(
        _step_ica, "ICA (EOG)",
        config_deps=("ICA_EOG",),
        save_section="ICA_EOG", save_suffix="ica-cleaned"),
    "chosen_channels": StepDef(
        _step_chosen_channels, "Chosen Channels",
        config_deps=("choosing_channels",),
        save_section="choosing_channels", save_suffix="selected"),
    # mp_decomposition's output is the .db book, not a FIF; tracked
    # via `_mp_book_path` runtime state.  No save_section here.
    "mp_decomposition": StepDef(
        _step_mp_decomposition, "MP Decomposition",
        config_deps=("matching_pursuit",)),
    "mp_filter": StepDef(
        _step_mp_filter, "MP Filter",
        config_deps=("matching_pursuit",),
        save_section="mp_filter", save_suffix="mp-filtered"),
    "eeg_artifacts": StepDef(
        _step_eeg_artifacts, "EEG Artifact Detection",
        config_deps=("artifacts",
                     "amplitude_max_threshold",
                     "amplitude_time_threshold",
                     "amplitude_nchan_threshold"),
        save_section="artifacts", save_suffix="eeg-artifacts-marked"),
    "gaze_artifacts": StepDef(
        _step_gaze_artifacts, "Gaze (not-looking) Detection",
        config_deps=("gaze", "video_path",
                     "video_reference_dir", "video_exclude_dir",
                     "facetag_frame_skip", "facetag_detection_skip",
                     "facetag_downscale", "facetag_max_angle",
                     "facetag_ref_use_roi", "facetag_face_tolerance",
                     "facetag_min_interval",
                     "facetag_no_face_is_artifact",
                     "facetag_tracking_adapt_rate",
                     "facetag_position_weight",
                     "facetag_size_weight",
                     "facetag_switch_resistance",
                     "facetag_backend", "facetag_gaze_method",
                     "facetag_gaze_smoothing", "facetag_det_size"),
        save_section="gaze", save_suffix="gaze-marked"),
}

# ── Derived lookup tables (don't edit directly — edit STEP_REGISTRY) ─

STEP_LABELS = {name: sd.label for name, sd in STEP_REGISTRY.items()}

DEFAULT_STEP_ORDER = [
    "trim", "chosen_channels", "resample", "bad_channels", "montage",
    "reference", "filtering", "ica", "eeg_artifacts", "gaze_artifacts",
]

# Map pipeline step name → (config section, output filename suffix).
# Consumed by _save_step_signal_if_requested + the GUI's eye-button
# viewer to decide whether to write / look for a step snapshot.
_STEP_SAVE_MAP = {
    name: (sd.save_section, sd.save_suffix)
    for name, sd in STEP_REGISTRY.items()
    if sd.save_section is not None
}


# Top-level config keys that influence the signal during preprocessing.
# Used by ``_compute_preprocessing_hash`` to hash the saved-step FIFs
# for staleness detection in the GUI's eye-button viewer.
#
# Retained as the legacy whole-config hash scope; per-step hashes
# (``_STEP_CONFIG_DEPS`` + ``_compute_step_hash``) supersede this for
# step-snapshot freshness, but the whole-config helper is still used
# in places that need a single coarse digest of the entire pipeline
# config (e.g. ``_compute_mp_book_hash`` upstream).
_HASHED_CONFIG_KEYS = (
    "preprocessing", "trim_start", "trim_end", "resample_freq",
    "segmentation", "rest", "events_desc_id", "choosing_channels",
    "bad_channels", "montage", "re_reference", "reference",
    "filters", "ICA_EOG", "artifacts", "matching_pursuit", "epochs",
)


# Per-step config dependencies — used by ``_compute_step_hash`` to
# build a Merkle-style cumulative hash chain so editing a config key
# only invalidates the snapshots for the step that consumes it and
# everything downstream, not every snapshot in the pipeline.
#
# Each entry maps a pipeline step *base* name (after stripping the
# Phase 2 ``":<id>"`` suffix) to the list of top-level config keys
# whose value is part of that step's input.  Every step also
# implicitly depends on the upstream step's hash (provided by the
# chain) and on the ``"preprocessing"`` block (step_order, enabled
# flags, hard/soft constraints — reordering or disabling a step
# changes what came before it).  The ``"preprocessing"`` block is
# added automatically by ``_compute_step_hash`` so it doesn't have
# to be repeated in every entry below.
#
# Judgment calls (see report):
#   * ``choosing_channels`` is consumed by both ``bad_channels`` and
#     ``chosen_channels`` — list it on both.  Listing it on one only
#     would let an edit to ``type_overrides`` (used by both) silently
#     skip invalidating the other.
#   * ``segmentation`` / ``rest`` / ``epochs`` / ``events_desc_id``
#     don't directly affect any reorderable step's signal output —
#     they're consumed by the postamble's cut_segments.  They're not
#     part of any per-step hash; the postamble doesn't write a
#     snapshot, so there's nothing to invalidate.
#   * ``matching_pursuit`` covers both mp_decomposition and mp_filter
#     (the empi book the latter consumes is keyed off the former's
#     atoms), but only mp_filter is in ``_STEP_SAVE_MAP``.  Listed on
#     mp_filter only.
_STEP_CONFIG_DEPS = {
    name: list(sd.config_deps) for name, sd in STEP_REGISTRY.items()
}

# Format of the FIF ``info["description"]`` marker that step-snapshots
# carry.  Keep ``_SNAPSHOT_MARKER_RE`` in lockstep with the format
# string so ``_stamp_signal_description`` can strip a prior marker
# before writing a fresh one.
_SNAPSHOT_MARKER_FMT = "after {step} [cfg:{cfg_hash}]"
_SNAPSHOT_MARKER_RE = r"\s*·?\s*after \S+ \[cfg:[0-9a-f]+\]"


def _stamp_signal_description(signal, step_name, cfg_hash):
    """Set ``signal.info['description']`` to the snapshot marker.

    Strips any prior marker this function left so descriptions don't
    accumulate across repeated saves, then appends the new one (joined
    to any pre-existing non-marker description with '·').  Mutates in
    place — the caller owns signal lifetime and decides when to copy.
    """
    import re
    marker = _SNAPSHOT_MARKER_FMT.format(step=step_name, cfg_hash=cfg_hash)
    existing = signal.info.get("description") or ""
    cleaned = re.sub(_SNAPSHOT_MARKER_RE, "", existing).strip()
    signal.info["description"] = (
        f"{cleaned} · {marker}" if cleaned else marker)


# Top-level runtime-injected keys that callers (GUI / CLI / programmatic)
# must NOT carry across runs.  The hash pins (``_pipeline_*``,
# ``_mp_book_*``) are scoped to a single launch -- reusing them on the
# next run is the staleness-bug class from issue #21 (a stale pin pinned
# against an earlier step_order makes the runner's coverage check fire
# on every later run).  Strip in:
#   * GUI ``_collect_config`` -- after deep-merging
#     ``self.config_data`` (which was loaded from a previously-saved
#     TOML).  Catches the leaked pin in the GUI's launch path.
#   * GUI ``_save_config_to_output`` -- so future auto-saved TOMLs
#     never leak the pin in the first place.
#   * Runner ``main()`` -- post ``read_config_file``, gated by
#     ``_preserve_runtime_pin_keys`` so the eye-button truncated path
#     can opt INTO preserving its user-level pre-pin across the worker
#     thread's TOML roundtrip.  CLI / programmatic ``run_file`` /
#     normal GUI Run button all want the strip (default).
_RUNTIME_TOP_LEVEL_KEYS = (
    "_pipeline_config_hash",
    "_pipeline_step_hashes",
    "_mp_book_hash",
    "_mp_book_path",
    "_pending_view_step_key",
    "_input_dir",
    "_input_file_name",
    "_cancel_event",
    "_manual_hooks",
)


def strip_runtime_top_level_keys(cfg):
    """Remove runtime-injected top-level keys from *cfg*, in place.

    Used at GUI/CLI config-load / config-save boundaries so the pin
    fields (``_pipeline_config_hash``, ``_pipeline_step_hashes``,
    ``_mp_book_hash``) never leak between runs as stale state.  See
    ``_RUNTIME_TOP_LEVEL_KEYS`` for the full list and issue #21 for the
    motivating regression.
    """
    for k in _RUNTIME_TOP_LEVEL_KEYS:
        cfg.pop(k, None)


# Per-block runtime-only fields that don't influence signal output —
# stripped before hashing so flipping them (drawer save, plot save,
# .tag save) doesn't invalidate downstream snapshots and force a
# re-run.  Keep in sync with the GUI checkboxes that write these keys.
_STEP_HASH_RUNTIME_FIELDS = {
    "trim":              ("save",),
    "resample":          ("save",),
    "bad_channels":      ("save", "save_plots"),
    "reference":         ("save",),
    "filters":           ("save",),
    "ICA_EOG":           ("save", "save_components_audit"),
    "artifacts":         ("save", "save_plots", "save_tag"),
    "gaze":              ("save", "save_tag"),
    "matching_pursuit":  ("save",),
    "choosing_channels": ("save",),
}


def strip_runtime_fields(relevant):
    """Remove runtime-only keys from each block of a hash subset, in
    place.  Used by :func:`_compute_preprocessing_hash`,
    :func:`_step_relevant_subset`, and ``mp_preprocessing.
    _compute_mp_book_hash`` so all three honour the same
    save/save_plots/save_tag exclusion table.
    """
    for key, runtime in _STEP_HASH_RUNTIME_FIELDS.items():
        block = relevant.get(key)
        if isinstance(block, dict):
            relevant[key] = {
                k: v for k, v in block.items() if k not in runtime}


def _assert_no_bound_methods_in_hash_scope(relevant):
    """Invariant #1 (see project_staleness_hash.md, lesson 1).

    ``hashlib.blake2b(json.dumps(relevant, default=str))`` would happily
    serialize a bound method as ``"<bound method ...>"`` — the hash
    would land in the same shape but the value flows downstream through
    ``deepcopy(config)`` (e.g. _run_truncated_pipeline scratch cfg),
    which walks ``method.__self__`` -- typically a QMainWindow whose
    Qt-owned children blow up the deepcopy with arbitrary errors.

    Fail loud here with a precise location rather than let the eventual
    deepcopy explode opaquely.  Bound methods belong in ``_``-prefixed
    runtime keys (``_manual_hooks``) that are excluded from the hash
    scope and from deepcopy via ``_diff_config`` / scratch-cfg helpers.
    """
    def _scan(node, path):
        if hasattr(node, "__self__") and callable(node):
            raise TypeError(
                f"Bound method found in hash scope at {path}: {node!r}. "
                f"Move to a `_`-prefixed runtime key (e.g. "
                f"`_manual_hooks`) so it stays out of the deepcopy + "
                f"hash path. See project_staleness_hash.md lesson 1.")
        if isinstance(node, dict):
            for k, v in node.items():
                _scan(v, f"{path}.{k}" if path else k)
        elif isinstance(node, (list, tuple)):
            for i, v in enumerate(node):
                _scan(v, f"{path}[{i}]")
    for k, v in relevant.items():
        _scan(v, k)


def _check_step_hash_pin_coverage(config):
    """Invariant: pre-pinned step hashes cover every runner step.

    If the GUI pre-pinned ``_pipeline_step_hashes`` (typical eye-button
    flow), the dict must hold an entry for every step in
    ``effective_step_order(config)``.  A missing entry would silently
    fall back to live recompute against an already-mutating config
    (lesson 2, ``project_staleness_hash.md``).

    No-op when no pin is present — programmatic callers (run_file) are
    allowed to skip per-step pinning entirely.

    Raises
    ------
    RuntimeError
        With the sorted list of missing step names and a pointer to the
        memo.  Surfaced eagerly at runner entry so the failure mode is
        loud rather than a silently-stale snapshot.
    """
    pinned_steps = config.get("_pipeline_step_hashes")
    if not isinstance(pinned_steps, dict):
        return
    runner_steps = set(effective_step_order(config))
    missing = runner_steps - set(pinned_steps)
    if missing:
        raise RuntimeError(
            f"Step hash pin from caller is missing entries for "
            f"steps the runner will execute: {sorted(missing)}.  "
            f"Pin via `_compute_step_hashes(cfg, effective_step_"
            f"order(cfg))` BEFORE the runner sees the cfg, or "
            f"don't pre-pin and let the runner self-pin.  See "
            f"project_staleness_hash.md lesson 3.")


def _compute_preprocessing_hash(config):
    """Return a short stable digest of preprocessing-relevant config.

    Not cryptographic — a coarse hash over every key in
    ``_HASHED_CONFIG_KEYS``.  Used by callers that need a single
    digest of the whole preprocessing config (e.g. the MP book hash
    upstream).  Step-snapshot staleness uses the finer-grained
    ``_compute_step_hash`` helper instead — see its docstring for the
    granular invalidation rationale.
    """
    import hashlib
    import json
    relevant = {k: config[k] for k in _HASHED_CONFIG_KEYS if k in config}
    strip_runtime_fields(relevant)
    _assert_no_bound_methods_in_hash_scope(relevant)
    blob = json.dumps(relevant, sort_keys=True, default=str)
    return hashlib.blake2b(blob.encode(), digest_size=8).hexdigest()


def _step_relevant_subset(step_token, config):
    """Return the slice of *config* that *step_token* depends on.

    *step_token* is a ``step_order`` entry — either a bare base name
    (e.g. ``"resample"``) or a Phase-2 multi-instance form
    (``"filtering:<id>"``).  Multi-instance filtering returns just the
    one filter block keyed by ``<id>`` (or the whole flat block in
    the legacy single-filter layout); two filter blocks therefore
    don't perturb each other's per-step hashes.

    Always includes the ``"preprocessing"`` block (step_order,
    enabled_steps, constraints) — reordering or disabling a step
    changes what came *before* it, so its snapshot must invalidate
    on a step_order edit even if its own deps are unchanged.

    Steps with no entry in ``_STEP_CONFIG_DEPS`` (unknown / future
    steps) hash only the ``"preprocessing"`` block and the upstream
    chain — coarse but safe.
    """
    step_base, step_id = _split_step_id(step_token)
    deps = _STEP_CONFIG_DEPS.get(step_base, [])
    subset = {}
    if "preprocessing" in config:
        subset["preprocessing"] = config["preprocessing"]
    for key in deps:
        if key not in config:
            continue
        if (step_base == "filtering" and key == "filters"
                and step_id):
            # Phase-2 multi-instance: only this filter block's config
            # is in scope.  ``filters[<id>]`` shape is the modern
            # dict-of-dicts layout; flat layout (legacy single-filter)
            # falls back to the whole block — there's only one filter
            # so there's nothing to isolate.
            filters_root = config.get("filters", {}) or {}
            is_flat = any(
                k in filters_root
                for k in ("highpass_freq", "lowpass_freq",
                          "notch_freq", "method"))
            if (not is_flat and isinstance(filters_root, dict)
                    and step_id in filters_root):
                subset[f"filters:{step_id}"] = filters_root[step_id]
                continue
        subset[key] = config[key]
    strip_runtime_fields(subset)
    return subset


def _compute_step_hash(step_name, config, step_order):
    """Cumulative per-step hash for snapshot staleness detection.

    Per-step hashes form a Merkle-style chain over *step_order*::

        step_hash(K) = blake2b(
            canonical(step_K_relevant_config_subset)
            + step_hash(K-1)   # or '' if K is the first step
        )

    so editing a config key only invalidates the snapshot for the
    step that consumes it and every downstream step — not every
    snapshot in the pipeline.

    Parameters
    ----------
    step_name : str
        Pipeline step token, optionally with a ``:<id>`` suffix
        (Phase-2 multi-instance steps).  Must appear in *step_order*;
        if not, returns the empty string (caller must treat that as
        "no resumable snapshot").
    config : dict
        The pipeline config dict, in the same shape consumed by the
        step itself.
    step_order : list[str]
        Ordered pipeline step tokens, exactly as written in
        ``config["preprocessing"]["step_order"]`` after the runner has
        applied any enabled-step filtering.

    Returns
    -------
    str
        16-character hex digest, or ``""`` when *step_name* is not in
        *step_order* (signals that no snapshot makes sense for it).
    """
    import hashlib
    import json
    if step_name not in step_order:
        return ""
    upstream = ""
    for tok in step_order:
        subset = _step_relevant_subset(tok, config)
        blob = json.dumps(subset, sort_keys=True, default=str)
        digest = hashlib.blake2b(
            blob.encode() + upstream.encode(), digest_size=8).hexdigest()
        if tok == step_name:
            return digest
        upstream = digest
    return ""  # unreachable — guarded by the membership check above


def _compute_step_hashes(config, step_order):
    """Compute the full per-step hash dict for *step_order*.

    Convenience wrapper for callers (notably the GUI) that need to
    pin every step's hash in one pass before pipeline mutation.
    Returns a dict ``{step_token: hash_hex}`` with one entry per
    token in *step_order*; tokens not in ``_STEP_SAVE_MAP`` still
    receive an entry (their hash contributes to downstream chains
    even when they don't write a snapshot).
    """
    import hashlib
    import json
    hashes = {}
    upstream = ""
    for tok in step_order:
        subset = _step_relevant_subset(tok, config)
        blob = json.dumps(subset, sort_keys=True, default=str)
        digest = hashlib.blake2b(
            blob.encode() + upstream.encode(), digest_size=8).hexdigest()
        hashes[tok] = digest
        upstream = digest
    return hashes


def _resolve_step_hash(step_name, config, step_order=None):
    """Look up the per-step hash for *step_name*, pinned or live.

    Honors the same write-side / read-side contract as
    ``_pipeline_config_hash`` did before:

      * ``config["_pipeline_step_hashes"][step_name]`` (pinned by the
        GUI BEFORE pipeline mutation) wins when present.
      * Otherwise, recompute live against *step_order* (or the
        config-stored order when *step_order* is None).

    Returns ``""`` (which never matches a real digest) when
    *step_name* is not in step_order or step_order is missing.

    *step_order* should be the **effective** order the runner
    iterates (after disabled-step filtering), so write-side and
    read-side digests match.  Use ``effective_step_order(config)`` to
    get it from a config dict.
    """
    pinned = config.get("_pipeline_step_hashes")
    if isinstance(pinned, dict) and step_name in pinned:
        return pinned[step_name]
    if step_order is None:
        step_order = effective_step_order(config)
    if not step_order:
        return ""
    return _compute_step_hash(step_name, config, step_order)


def effective_step_order(config):
    """Return the step_order the pipeline actually iterates.

    Mirrors the filtering ``preprocessing()`` applies just before its
    step loop: legacy ``re_reference`` injection, GUI-side
    ``enabled_steps``, top-level ``prepare_mp_filter`` /
    ``prepare_*_artifacts`` flags, and (only when both
    ``prepare_eeg_artifacts`` and ``prepare_video_artifacts`` are
    false) the ``artifacts`` drop.

    Used by ``_compute_step_hash`` callers (both write-side and
    read-side) so the cumulative chain hashes the same sequence of
    steps the runner will execute.  Live recomputes via
    ``_compute_step_hash`` would otherwise risk drifting away from
    the pinned values when the GUI filters disabled steps before
    pinning while the runner filters again locally — keeping the two
    in lockstep is the whole point of this helper.
    """
    preproc_cfg = config.get("preprocessing", {}) or {}
    step_order = list(
        preproc_cfg.get("step_order", _derive_step_order(config)) or [])

    # Phase 1 split: re_reference legacy injection.
    rr = config.get("re_reference")
    has_reref = rr not in (None, "", [], "None")
    if (has_reref and "reference" not in step_order
            and "montage" in step_order):
        idx = step_order.index("montage")
        step_order = list(step_order)
        step_order.insert(idx + 1, "reference")

    _ENABLED_TO_STEPS = {
        "trim": {"trim"},
        "resample": {"resample"},
        "bad_channels": {"bad_channels"},
        "signal_setup": {"montage", "reference"},
        "filtering": {"filtering"},
        "ica": {"ica"},
        "select": {"chosen_channels"},
    }
    enabled_steps = preproc_cfg.get("enabled_steps")
    if enabled_steps:
        disabled = set()
        for gui_key, pipeline_names in _ENABLED_TO_STEPS.items():
            if not enabled_steps.get(gui_key, True):
                disabled |= pipeline_names
        # Match the runner's exact-name comparison so write-side
        # (runner) and read-side (this helper, called by the GUI's
        # _view_step_result) agree on the effective step_order.
        step_order = [s for s in step_order if s not in disabled]

    if not config.get("prepare_mp_filter", False):
        step_order = [s for s in step_order if s != "mp_filter"]
    return step_order


def _save_step_signal_if_requested(state, step_name):
    """Save the signal after a step if ``config[<section>]["save"]`` is True.

    Writes ``<file_base>-<suffix>-raw.fif`` to
    ``preprocessing_output/saved_steps/``.  Annotating steps (bad
    channels, artifacts) save the signal with updated
    ``info['bads']`` / annotations; modifying steps save the
    transformed samples.
    """
    # Phase 2 multi-instance: step_name may carry an ":<id>" suffix.
    # Strip it for the registry lookup and stamp the id into the
    # output filename so multiple blocks of the same step produce
    # distinct snapshots.
    step_base, step_id = _split_step_id(step_name)
    entry = _STEP_SAVE_MAP.get(step_base)
    if entry is None:
        return
    section, suffix = entry
    cfg = state["config"]
    section_cfg = cfg.get(section, {}) or {}
    if step_id and isinstance(section_cfg, dict) and step_id in section_cfg:
        # Per-instance save flag (e.g. cfg["filters"][<id>]["save"])
        save_flag = section_cfg[step_id].get("save", False)
    else:
        save_flag = section_cfg.get("save", False)
    if not save_flag:
        return
    signal = state.get("signal")
    path = state.get("path")
    if signal is None or not path:
        return
    out_dir = os.path.join(path, "saved_steps")
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(state["file_name"])[0]
    file_suffix = f"{suffix}-{step_id}" if step_id else suffix
    out_path = os.path.join(out_dir, f"{base}-{file_suffix}-raw.fif")
    try:
        # Prefer the precomputed per-step hash the GUI injects via
        # ``_pipeline_step_hashes`` — it reflects the user's GUI
        # state BEFORE pipeline side effects (e.g. auto-detected bad
        # channels being appended to choosing_channels.bad_channels
        # during the bad_channels step).  Recomputing here would
        # include those mutations and diverge from the GUI-time hash,
        # causing the staleness check to thrash.  Fall back to a live
        # recompute for programmatic run_file callers.
        cfg_hash = _resolve_step_hash(
            step_name, cfg, state.get("_step_order"))
        if not cfg_hash:
            # Legacy callers (and tests) that pin _pipeline_config_hash
            # directly — keep accepting that as the per-step value too,
            # so a snapshot written under the old whole-config regime
            # at least round-trips with itself within a single run.
            cfg_hash = (cfg.get("_pipeline_config_hash")
                        or _compute_preprocessing_hash(cfg))
        # Skip the write if an existing snapshot already carries the
        # same [cfg:<hash>] marker — contents would be byte-identical.
        # Cheap read_info metadata-only check; corrupt / unreadable
        # files fall through to the normal overwrite path.
        if os.path.isfile(out_path):
            try:
                import re
                existing_info = mne.io.read_info(out_path, verbose=False)
                existing_desc = existing_info.get("description") or ""
                m = re.search(r"\[cfg:([0-9a-f]+)\]", existing_desc)
                if m and m.group(1) == cfg_hash:
                    logging.info(
                        f"{step_name} snapshot already fresh at "
                        f"{out_path}, skipping save")
                    return
            except Exception:
                pass
        signal_to_save = signal.copy()
        _stamp_signal_description(signal_to_save, step_name, cfg_hash)
        signal_to_save.save(out_path, overwrite=True)
        logging.info(f"Saved {step_name} signal to {out_path}")
    except Exception as e:
        # Surface as ERROR (not WARNING) — disk full / read-only
        # mount used to be a quiet warning that the View-Step-Result
        # button later turned into a confusing "snapshot still
        # stale" loop-guard message.  ERROR with the path name puts
        # the underlying I/O failure at the top of the run log so
        # the user can act on it immediately.
        logging.error(
            f"Failed to save {step_name} snapshot to {out_path}: "
            f"{type(e).__name__}: {e}")


# Steps that mutate ``state`` beyond ``state["signal"]`` and whose
# side-effects on ``state`` aren't recoverable from a saved FIF.
# The artifact steps populate ``state["artifacts_occurrence"]``,
# which the postamble feeds into ``_dirty_segment_ids`` ->
# ``_remove_bad_segments``.  Resume-from-snapshot must not skip
# these — if they're still in step_order, the resume point has to
# land *before* the first one.
_STATE_POPULATING_STEPS = frozenset({"eeg_artifacts", "gaze_artifacts"})


def _find_resume_point(step_order, config, path, file_name):
    """Walk *step_order* end → start, find the latest fresh snapshot.

    A snapshot is "fresh" when its FIF carries the marker
    ``[cfg:<hash>]`` matching the current per-step cumulative hash
    for that step (pinned in ``config["_pipeline_step_hashes"]`` by
    ``preprocessing()``, or recomputed live).  Returns
    ``(resume_idx, signal)`` so the runner can load *signal* and
    skip ``step_order[: resume_idx + 1]``; returns ``(None, None)``
    when no usable snapshot is found.

    Per-step hashes (vs. the old whole-config hash) make this fire
    far more often: editing a downstream config key — say,
    ``epochs.start_offset`` consumed only by ``cut_segments`` — no
    longer invalidates the upstream ``trim``/``resample``/...
    snapshots, so we resume from there instead of re-running.

    The search is bounded above by the first ``_STATE_POPULATING_STEPS``
    member in ``step_order`` — we cannot reconstruct
    ``state["artifacts_occurrence"]`` from a saved signal alone, so
    resuming past such a step would silently break the postamble.

    Corrupt or unreadable FIFs fall through to the next candidate
    rather than aborting; if every candidate fails, the caller runs
    the full pipeline.
    """
    base = os.path.splitext(file_name)[0]
    saved_dir = os.path.join(path, "saved_steps")
    if not os.path.isdir(saved_dir):
        return None, None

    # Cap the search at the first state-populating step still in
    # step_order; everything past that must run live.
    cap = len(step_order)
    for i, step in enumerate(step_order):
        step_base, _ = _split_step_id(step)
        if step_base in _STATE_POPULATING_STEPS:
            cap = i
            break

    # ``_force_rerun_steps`` lets callers (typically the GUI eye
    # button on a manual-review step) demand fresh execution of a
    # specific step.  Cap the resume search to *before* the earliest
    # forced step so the runner can't skip it via a stale snapshot.
    forced = set(config.get("_force_rerun_steps") or ())
    if forced:
        for i, step in enumerate(step_order):
            step_base, _ = _split_step_id(step)
            if step_base in forced and i < cap:
                cap = i
                break

    for i in range(min(cap, len(step_order)) - 1, -1, -1):
        step = step_order[i]
        step_base, step_id = _split_step_id(step)
        entry = _STEP_SAVE_MAP.get(step_base)
        if entry is None:
            continue
        _, suffix = entry
        file_suffix = f"{suffix}-{step_id}" if step_id else suffix
        snap_path = os.path.join(
            saved_dir, f"{base}-{file_suffix}-raw.fif")
        if not os.path.isfile(snap_path):
            continue
        # Per-step hash — recomputed (or read from the pinned dict)
        # for this specific step, not a whole-config digest.  Pass
        # the runner's effective step_order through so live recomputes
        # match the same chain the runner walked.
        expected_hash = _resolve_step_hash(step, config, step_order)
        if not expected_hash:
            # Legacy single-pin fallback for callers that haven't
            # migrated yet (kept for backward compat with the old
            # ``_pipeline_config_hash`` contract).
            expected_hash = (config.get("_pipeline_config_hash")
                             or _compute_preprocessing_hash(config))
        try:
            signal = mne.io.read_raw_fif(
                snap_path, preload=False, verbose=False)
            desc = signal.info.get("description") or ""
            m = re.search(r"\[cfg:([0-9a-f]+)\]", desc)
            if m and m.group(1) == expected_hash:
                logging.info(
                    f"Resuming pipeline from fresh snapshot at "
                    f"step '{step}' ({snap_path})")
                return i, signal
        except Exception as e:
            logging.warning(
                f"Snapshot at {snap_path} unreadable ({e}); "
                f"falling through to earlier snapshots")
            continue
    return None, None


# Constraints, rationales, and ConstraintViolation are defined in
# the lightweight constraints module (no MNE/numpy deps) so
# gui_config.py can import them without slowing GUI cold-start.
# Re-exported here for backward compatibility — existing imports
# like `from ide4eeg.preprocessing.preprocessing import
# DEFAULT_HARD_CONSTRAINTS` keep working.
from .constraints import (  # noqa: F401
    ConstraintViolation,
    DATA_DEPENDENCIES,
    DEFAULT_HARD_CONSTRAINTS,
    DEFAULT_SOFT_CONSTRAINTS,
    HARD_CONSTRAINT_RATIONALES,
    SOFT_CONSTRAINT_RATIONALES,
)


def validate_step_order(step_order, hard_constraints=None,
                        soft_constraints=None):
    """Check *step_order* against ordering constraints.

    Parameters
    ----------
    step_order : list[str]
        Ordered step names.
    hard_constraints : list[[str, str]] or None
        Each pair ``[a, b]`` means *a* must come before *b*.
        Defaults to ``DEFAULT_HARD_CONSTRAINTS``.
    soft_constraints : list[[str, str]] or None
        Same format; violations produce warnings, not errors.
        Defaults to ``DEFAULT_SOFT_CONSTRAINTS``.

    Returns
    -------
    is_valid : bool
        True if no hard constraints are violated.
    errors : list[ConstraintViolation]
        Hard-constraint violations.  Each element is a str subclass
        that also exposes ``severity``, ``before``, ``after``, and
        ``rationale`` attributes — existing callers that just format
        the string keep working; the GUI reads the attributes to
        drive highlighting and the modal.
    warnings : list[ConstraintViolation]
        Soft-constraint violations, same shape as ``errors``.
    """
    if hard_constraints is None:
        hard_constraints = DEFAULT_HARD_CONSTRAINTS
    if soft_constraints is None:
        soft_constraints = DEFAULT_SOFT_CONSTRAINTS

    # Phase 2 multi-instance: collect every position of each base
    # step name (a step like "filtering" can appear multiple times
    # as "filtering:<id>").  A constraint "a before b" is violated
    # if ANY position of a comes after ANY position of b — i.e.
    # max(a-positions) > min(b-positions).
    positions_by_base = {}
    for i, step in enumerate(step_order):
        base, _ = _split_step_id(step)
        positions_by_base.setdefault(base, []).append(i)

    def _violates(a, b):
        ap = positions_by_base.get(a, [])
        bp = positions_by_base.get(b, [])
        if not ap or not bp:
            return False
        return max(ap) > min(bp)

    errors, warnings = [], []

    for a, b in hard_constraints:
        if _violates(a, b):
            la = STEP_LABELS.get(a, a)
            lb = STEP_LABELS.get(b, b)
            rationale = HARD_CONSTRAINT_RATIONALES.get((a, b), "")
            errors.append(ConstraintViolation(
                f"'{la}' must come before '{lb}'",
                severity="hard", before=a, after=b,
                rationale=rationale))

    for a, b in soft_constraints:
        if _violates(a, b):
            la = STEP_LABELS.get(a, a)
            lb = STEP_LABELS.get(b, b)
            rationale = SOFT_CONSTRAINT_RATIONALES.get((a, b), "")
            warnings.append(ConstraintViolation(
                f"'{la}' usually comes before '{lb}'",
                severity="soft", before=a, after=b,
                rationale=rationale))

    return len(errors) == 0, errors, warnings


# ── Legacy backward compatibility ────────────────────────────────────

def _derive_step_order(config):
    """Derive step order from legacy config flags.

    Called when ``config["preprocessing"]["step_order"]`` is absent,
    so that old config files still work without modification.
    """
    if config.get("prepare_mp_decomposition"):
        logging.error(
            "Config uses 'prepare_mp_decomposition' which is no longer "
            "supported. Add 'mp_decomposition' to "
            "preprocessing.step_order instead. Skipping MP "
            "decomposition for this run.")
    # Trim used to be a fixed preamble step — legacy configs never
    # listed it.  It now lives in the reorderable set, so fold it in
    # at the front for any derived order.
    steps = ["trim"]
    if config.get("prepare_eeg_artifacts"):
        steps.extend([
            "resample", "bad_channels", "montage",
            "filtering",
        ])
        if config.get("prepare_ica"):
            steps.append("ica")
        steps.append("chosen_channels")
        steps.append("eeg_artifacts")
    if config.get("prepare_video_artifacts"):
        steps.append("gaze_artifacts")
    # ``prepare_mp_decomposition`` was deleted — legacy configs that
    # want MP must opt in via ``preprocessing.step_order`` explicitly.
    if config.get("prepare_mp_filter"):
        steps.append("mp_filter")
    return steps


# ── Stage 5: step_entry rule dispatcher ──────────────────────────────

def _run_stage5_step_entry_rules(state, step_base):
    """Dispatch Stage 5 ``step_entry`` rules just before *step_base* runs.

    Builds a fresh :class:`ide4eeg.validators.State` snapshot from the
    runner's live ``state["config"]`` and ``state["signal"]``, then
    calls :func:`ide4eeg.validators.run_at` with
    ``fire_point="step_entry"`` and ``step_name=step_base``.  Rules
    that key off ``state.current_step == step_base`` see the right
    context; rules that don't filter by step see every step entry.

    Severity mapping (mirrors :func:`main._run_stage5_preflight_rules_cli`):

    * ``error``    -> :class:`ValueError` (aborts the pipeline).
    * ``warning``  -> :func:`logging.warning` (continues).
    * ``info`` / ``hint``  -> dropped (no per-step UI surface yet).

    Best-effort: an exception inside the dispatcher itself (e.g. a
    State capture bug, a registry import failure) must NOT crash the
    pipeline -- those are framework bugs and the user's pipeline run
    is unrelated.  Rule-emitted :class:`ValueError` *does* propagate;
    it's the framework's job to surface configuration errors.
    """
    try:
        # Force-import the rule registry so explicit imports run their
        # side effects.  Same rationale as the GUI / CLI preflights;
        # subsequent calls are no-ops.
        import ide4eeg.validators.hard  # noqa: F401
        from ide4eeg.validators import run_at
        from ide4eeg.validators._state import capture_from_cfg_and_info

        signal = state.get("signal")
        ch_names: tuple[str, ...] | None = None
        ch_types: dict[str, str] | None = None
        sfreq: float | None = None
        duration: float | None = None
        if signal is not None:
            names = list(getattr(signal, "ch_names", []) or [])
            if names:
                ch_names = tuple(names)
                ch_types = {
                    n: mne.channel_type(signal.info, i)
                    for i, n in enumerate(names)
                }
            sfreq = float(signal.info.get("sfreq")) if signal.info.get(
                "sfreq") else None
            try:
                duration = float(signal.times[-1]) if len(signal.times) else None
            except Exception:
                duration = None

        snapshot = capture_from_cfg_and_info(
            state["config"], fire_point="step_entry",
            ch_names=ch_names,
            ch_types=ch_types,
            sfreq=sfreq,
            duration=duration,
            probe_tools=False,
        )
        warnings_collected: list[str] = []
        for issue in run_at("step_entry", snapshot, step_name=step_base):
            if issue.severity == "error":
                raise ValueError(
                    f"{issue.field_path}: {issue.message}")
            if issue.severity == "warning":
                warnings_collected.append(
                    f"{issue.field_path}: {issue.message}")
        for w in warnings_collected:
            logging.warning(w)
    except ValueError:
        raise
    except Exception:
        import traceback
        traceback.print_exc()


# ── Main entry point ─────────────────────────────────────────────────

def preprocessing(signal, config, path, events_desc_id, file_name):
    """Run the full preprocessing pipeline.

    Parameters
    ----------
    signal : mne.io.RawArray
        Signal in MNE Raw format.
    config : dict
        Configuration variables (read from TOML).
    path : str
        Path to the output directory.
    events_desc_id : dict
        Event names → STIM channel values.
    file_name : str
        Name of the raw signal file (without extension).

    Returns
    -------
    rest, rest_clean : mne.Epochs or None
        Rest segments (all / clean).  None when mode is "epochs".
    epochs, epochs_clean : mne.Epochs or None
        Event-related epochs (all / clean).  None when mode is "rest".
    tags_desc_id : dict
        Updated event mapping (includes "rest" if applicable).
    data : pandas.DataFrame
        Per-segment statistics.
    config : dict
        Updated configuration (with runtime metadata).

    Notes
    -----
    Forces the matplotlib backend to ``Agg`` for the duration of the
    run.  This function executes in the GUI's pipeline worker thread,
    and a Qt backend in a worker thread segfaults on Linux inside
    ``plt.subplots`` (X11/Cocoa GUI calls are not thread-safe).
    Downstream preprocessing helpers (ICA audit, artifacts, MP
    decomposition, SVAROG-review topomap renderer) inherit the Agg
    state via matplotlib's global rcParams.  Mirrors the symmetric
    setup in ``analysis.analysis``.
    """
    import matplotlib
    matplotlib.use("Agg")

    # ── Pin freshness hashes (BEFORE pipeline mutation) ──────────────
    #
    # The pipeline mutates hashed config sections during normal
    # operation (auto-detected bads append to choosing_channels.bad_
    # channels; ICA populates ICA_EOG.bad_sources).  Recomputing either
    # hash mid-pipeline would drift away from the GUI-time / TOML-time
    # value that step-snapshot FIFs and MP books should be tagged
    # with, breaking the staleness check.
    #
    # ``setdefault`` so that callers that already pinned (the GUI's
    # ``_launch_pipeline`` / ``_run_truncated_pipeline``) keep their
    # pre-pinned value; programmatic and CLI callers get a fresh pin
    # here.  Both hashes are intentionally derived from the user-level
    # config (pre-mutation) — this is the lesson from the
    # bad-channels-mutation drift bug; see ``project_staleness_hash``
    # auto-memory.
    if "_pipeline_config_hash" not in config:
        config["_pipeline_config_hash"] = _compute_preprocessing_hash(
            config)
    from .mp_preprocessing import pin_mp_book_hash
    pin_mp_book_hash(config)
    _check_step_hash_pin_coverage(config)

    # Early preamble: build the event_id dict (pure config op, no
    # signal touch) and seed channel metadata that in-loop steps
    # consume.  The metadata is refreshed again in the late preamble
    # after the step loop has dropped or added channels.
    tags_desc_id = _build_event_dict(config, events_desc_id)
    _refresh_channel_metadata(config, signal)

    # Pre-resolve rest.window_length so in-loop steps (notably
    # ``artifacts`` → ``_dirty_segment_ids``) can read a concrete tmax
    # before ``_add_rest_markers`` runs at the end of the step loop.
    # If the user left window_length unset and requested whole-signal
    # mode, fall back to the current (pre-loop) signal duration — it's
    # at most an over-estimate by however much trim/resample will crop,
    # and the final ``_add_rest_markers`` pass will clamp it to the
    # actual post-processing signal length.
    if get_segmentation_mode(config) == "rest":
        rest_cfg = config.setdefault("rest", {})
        wl = rest_cfg.get("window_length")
        whole = rest_cfg.get("whole_signal", not wl)
        if whole or wl in (None, "", 0):
            rest_cfg["window_length"] = float(
                signal.times[-1] if signal.n_times > 1 else 0.0)

    # ── Build pipeline state ─────────────────────────────────────────

    state = {
        "signal": signal,
        "config": config,
        "tags_desc_id": tags_desc_id,
        "path": path,
        "file_name": file_name,
        "ica": None,
        "artifacts_occurrence": {},
        "artifacts_description": [],
        "_cancel_event": config.get("_cancel_event"),
    }

    # ── REORDERABLE STEPS (user-configurable) ────────────────────────
    # These are the main signal-processing steps whose order and
    # enabled/disabled state the user controls via the Preprocessing tab.
    # Each step is a function registered in STEP_REGISTRY.

    preproc_cfg = config.get("preprocessing", {})
    step_order = preproc_cfg.get("step_order",
                                 _derive_step_order(config))

    # Phase 1 split (2026-04-28): re-referencing used to live inside
    # the "montage" step.  Legacy configs with ``re_reference`` set
    # but no ``"reference"`` in step_order get the new step injected
    # right after ``"montage"`` so old TOMLs keep working.
    rr = config.get("re_reference")
    has_reref = rr not in (None, "", [], "None")
    if (has_reref and "reference" not in step_order
            and "montage" in step_order):
        idx = step_order.index("montage")
        step_order = list(step_order)
        step_order.insert(idx + 1, "reference")
        logging.info(
            "Auto-inserted 'reference' step after 'montage' for "
            "legacy compatibility (re_reference=%r).", rr)

    hard = preproc_cfg.get("hard_constraints", DEFAULT_HARD_CONSTRAINTS)
    soft = preproc_cfg.get("soft_constraints", DEFAULT_SOFT_CONSTRAINTS)

    valid, errors, warnings = validate_step_order(step_order, hard, soft)
    if not valid:
        for e in errors:
            logging.error(f"Step order constraint violation: {e}")
        raise ValueError(
            "Invalid preprocessing step order: " + "; ".join(errors))
    for w in warnings:
        logging.warning(f"Step order warning: {w}")

    # Filter out steps the user has disabled in the GUI.
    # GUI checkbox keys map to one or more pipeline step names:
    _ENABLED_TO_STEPS = {
        "trim": {"trim"},
        "resample": {"resample"},
        "bad_channels": {"bad_channels"},
        "signal_setup": {"montage", "reference"},
        "filtering": {"filtering"},
        "ica": {"ica"},
        "select": {"chosen_channels"},
    }

    enabled_steps = preproc_cfg.get("enabled_steps")
    if enabled_steps:
        disabled = set()
        for gui_key, pipeline_names in _ENABLED_TO_STEPS.items():
            if not enabled_steps.get(gui_key, True):
                disabled |= pipeline_names
        step_order = [s for s in step_order if s not in disabled]

    # Also filter steps controlled by their own top-level config flags.
    # ``prepare_mp_decomposition`` was deleted in the MP-book-reuse
    # change — disable MP by removing it from ``step_order`` instead
    # (the GUI does this when its checkbox is unchecked).
    if not config.get("prepare_mp_filter", False):
        step_order = [s for s in step_order if s != "mp_filter"]

    # Pin per-step cumulative hashes against the *effective*
    # step_order — the same one the loop below iterates.  ``setdefault``
    # so GUI callers that pinned upstream keep their values; CLI /
    # programmatic callers get a fresh pin here.  Step-snapshot save
    # and resume both prefer the pinned dict, so mid-pipeline
    # mutations (auto-detected bads, ICA component flags) don't drift
    # the digest away from the user-facing pre-mutation value.
    config.setdefault("_pipeline_step_hashes",
                      _compute_step_hashes(config, step_order))
    # Stash the effective step_order in state so step wrappers (and
    # _save_step_signal_if_requested) can hand it to _resolve_step_hash
    # without re-deriving it from config.
    state["_step_order"] = step_order

    # MP-book auto-discovery (disabled-step branch).  When
    # mp_decomposition is NOT in step_order, look for an existing book
    # on disk and reuse it if its hash matches the current config —
    # letting users iterate on downstream analyses without paying for
    # empi every time.  Mismatch → halt with a clear error; legacy
    # book (no stamp) → reuse with a soft warning.  See USER_MANUAL.md
    # § 4.16 for the user-facing decision matrix.
    if "mp_decomposition" not in step_order:
        from .mp_preprocessing import try_reuse_existing_mp_book
        state = try_reuse_existing_mp_book(state)

    # MP decomposition needs REST annotations for segment boundaries
    # in rest mode, but rest markers are normally added in the late
    # preamble (after the step loop).  When MP is in the step order,
    # add rest markers early so it can find them.  The late preamble
    # re-adds them (idempotent — old REST annotations are stripped
    # before the new ones are attached) with the final
    # post-processing coordinate system.
    if ("mp_decomposition" in step_order
            and get_segmentation_mode(config) == "rest"):
        state["signal"] = _maybe_add_rest_markers(
            state["signal"], config)

    # Resume-from-snapshot: scan saved_steps/ for the latest step
    # whose snapshot's [cfg:<hash>] matches the current config.  When
    # found, swap state["signal"] for the snapshot and skip every
    # earlier step.  Bounded above by _STATE_POPULATING_STEPS — see
    # _find_resume_point for the correctness rationale.
    resume_idx, resume_signal = _find_resume_point(
        step_order, config, path, file_name)
    if resume_signal is not None:
        state["signal"] = resume_signal

    if not step_order:
        # Legitimate use case (raw passthrough to postamble) but worth
        # surfacing — users sometimes get here by disabling everything
        # in the GUI without realising it stops at trim/cut/save.
        logging.info(
            "All preprocessing steps are disabled — passing the raw "
            "signal directly to the postamble (cut_segments / "
            "save_segments).")
    else:
        # Catch duplicates that would silently apply a step twice.
        # Multi-instance step ids (e.g. "filtering:hp" + "filtering:lp")
        # are legitimate; only flag exact-string duplicates.
        from collections import Counter
        counts = Counter(step_order)
        dups = [s for s, c in counts.items() if c > 1]
        if dups:
            raise ValueError(
                f"Duplicate steps in step_order: {dups}.  Each step "
                f"id (including the optional ':<id>' suffix for "
                f"multi-instance filtering) must appear at most "
                f"once.  Remove the duplicate or assign distinct "
                f"ids.")

    cancel = config.get("_cancel_event")
    for i, step_name in enumerate(step_order):
        if resume_idx is not None and i <= resume_idx:
            continue
        if cancel is not None and cancel.is_set():
            logging.info("Preprocessing cancelled by user.")
            raise InterruptedError("Preprocessing cancelled by user")
        # Phase 2 multi-instance: step_order tokens may carry an
        # ":<id>" suffix (e.g. "filtering:a3f2") so multiple blocks
        # of the same step can sit at different positions.  Split
        # the suffix off for registry lookup and pass the id into
        # the step via state["_current_step_id"].
        step_base, step_id = _split_step_id(step_name)
        entry = STEP_REGISTRY.get(step_base)
        if entry is None:
            # Fail loud rather than silently skip — typo'd step names
            # used to drop the step and let the run continue, so a
            # user with `step_order = ["filterning"]` got unfiltered
            # output that looked plausible but was scientifically
            # wrong.  Listing the known steps in the error helps the
            # user spot the typo or recognise that their step has
            # been retired into _unreleased/.
            known = sorted(STEP_REGISTRY.keys())
            raise ValueError(
                f"Unknown preprocessing step {step_name!r}.  Known "
                f"steps: {', '.join(known)}.  If this step used to "
                f"work, it may have been moved to _unreleased/ — "
                f"check git tag 'unreleased/<name>' or remove it "
                f"from `step_order`.")
        func, label = entry.handler, entry.label
        if step_id:
            logging.info(f"{label} ({step_id})")
            state["_current_step_id"] = step_id
        else:
            logging.info(label)
            state.pop("_current_step_id", None)
        _run_stage5_step_entry_rules(state, step_base)
        state = func(state)
        _save_step_signal_if_requested(state, step_name)

    # Late preamble: rest markers run after the loop so synthetic
    # window pulses land in the final processed signal's coordinate
    # system (post trim, resample, filter, etc.).  Metadata refresh
    # depends on the final continuous signal going into cut_segments.
    signal = state["signal"]
    config = state["config"]

    signal = _maybe_add_rest_markers(signal, config)
    _refresh_channel_metadata(config, signal)

    mode = get_segmentation_mode(config)
    if mode == "epochs":
        # Single O(n_samples) pass: find which selected event IDs
        # appear at least once in the STIM channel.
        stim_data = signal.get_data(picks="STIM")[0]
        present_ids = set(np.unique(stim_data).astype(int).tolist())
        n_found_types = sum(
            1 for eid in tags_desc_id.values() if int(eid) in present_ids)
        logging.info(
            "Event-locked: %d of %d selected event types present "
            "in STIM.", n_found_types, len(tags_desc_id))

    state["signal"] = signal
    state["config"] = config

    # ── POSTAMBLE (always runs, fixed order) ─────────────────────────
    # Slices the (now cleaned) continuous signal into discrete segments
    # — either fixed-length rest windows or event-locked epochs — then
    # rejects bad segments, optionally lets the user review them, and
    # saves the result as MNE Epochs (.fif).  Every analysis method
    # (ERP, spectra, connectivity, …) operates on the Epochs produced
    # here, so this section is not optional.
    #
    #   cut_segments        — extract Epochs from the continuous signal
    #   remove_bad_segments — drop artifact-marked + PTP-rejected segments
    #   check_segments      — optional interactive manual review
    #   save_segments       — write clean Epochs to _clean-epo.fif
    #   prepare_dataframe   — per-segment statistics summary

    signal = state["signal"]
    config = state["config"]
    tags_desc_id = state["tags_desc_id"]

    segments, seg_events = _cut_segments(signal, config, tags_desc_id)

    # Validate non-empty before the postamble runs — over-aggressive
    # trim windows or ICA + chosen_channels combinations can produce
    # zero-event / zero-channel signals where MNE's Epochs would
    # silently produce empty output and downstream analyses crash
    # with opaque NaN errors.
    if len(segments) == 0:
        raise ValueError(
            "cut_segments produced zero epochs.  Likely causes: "
            "trim window too narrow, no events matched the "
            "selected event IDs, or all-channels were dropped by "
            "earlier steps.  Re-check trim/select/event configuration."
        )

    # Score events by artifact contamination once the final
    # artifact mask is assembled AND REST annotations have been
    # attached by the late preamble.  Doing it here (rather than in
    # the artifacts step) is what makes rest-mode artifact
    # rejection actually drop segments instead of being a no-op.
    # When no artifact step ran ``artifacts_occurrence`` is empty
    # and _dirty_segment_ids cheaply returns [].
    bad_event_positions = _dirty_segment_ids(
        signal, config,
        state.get("artifacts_occurrence", {}),
        state.get("tags_desc_id"))

    segments_clean, dirty_ids = _remove_bad_segments(
        segments, bad_event_positions, config)

    segments_clean, dirty_ids = _check_segments(
        segments_clean, segments, dirty_ids, config)

    _save_segments(segments_clean, tags_desc_id, config, path,
                   file_name + "_clean")

    data = _prepare_dataframe(
        seg_events, dirty_ids, tags_desc_id,
        state.get("artifacts_occurrence", {}), signal.info, config)

    # Reconstruct the 4-tuple for backward compat with analysis/plots
    mode = get_segmentation_mode(config)
    if mode == "rest":
        rest, rest_clean = segments, segments_clean
        epochs, epochs_clean = None, None
    else:
        rest, rest_clean = None, None
        epochs, epochs_clean = segments, segments_clean

    return rest, rest_clean, epochs, epochs_clean, tags_desc_id, data, config
