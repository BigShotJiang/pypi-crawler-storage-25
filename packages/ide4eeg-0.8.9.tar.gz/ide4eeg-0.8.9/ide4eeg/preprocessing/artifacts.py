"""EEG artifact detection for polysomnographic / EEG recordings.

Adapted from https://gitlab.com/BudzikFUW/budzik-analiza-py-3.git
(helper_functions/artifacts_mark.py, artifact_reject, helper_functions.py).

Based on:

  Klekowicz H, Malinowska U, Piotrowska AJ, Wolynczyk-Gmaj D,
  Niemcewicz S, Durka PJ (2009) "On the Robust Parametric Detection
  of EEG Artifacts in Polysomnographic Recordings."
  Neuroinformatics 7:147-160.
  https://doi.org/10.1007/s12021-009-9045-2
"""
import shutil

import numpy as np
import matplotlib.pyplot as plt
import scipy.signal as ss
import mne
import os
import logging
import json
from joblib import Parallel, delayed
from obci_readmanager.signal_processing.tags.tags_file_writer import TagsFileWriter

from .channels_and_signal import (Power, get_segment_params,
                                    get_segment_events,
                                    _append_annotations)

VIDEO_EXTENSIONS = (".mp4", ".mkv", ".avi", ".mov", ".wmv")

artifact_labels = ["arbitrary", "median", "std"]


# Marcin Pietrzak 2017-03-01 based on Klekowicz et al. DOI 10.1007/s12021-009-9045-2 from helper_functions\artifacts_mark.py and helper_functions\artifact_reject

def amplitude_artifacts(signal, config):
    """Detect high-amplitude segments across channels.

    Marks samples where too many channels exceed the amplitude threshold,
    then smooths and expands those bad regions.

    Parameters
    ----------
    signal : mne.io.array.array.RawArray
        Signal in mne Raw format (already trimmed).
    config : dict
        Dictionary of configuration variables.

    Returns
    -------
    artifacts_description : list
        Tag-format descriptions of detected amplitude artifacts.
    artifacts_occurrence : dict
        ``{"amplitude": mask}`` where mask is [n_channels, n_samples] binary.
    """
    from ide4eeg.utils.parallel import resolve_n_jobs
    _art_n_jobs = resolve_n_jobs(config)
    # .filter() requires preloaded data; ``.copy()`` returns a lazy
    # view, so chain ``.load_data()`` before filtering.  When the
    # artifacts step runs on its own (e.g. only the Gaze panel
    # checked) no upstream step has preloaded yet — without this
    # explicit load, MNE raises "inst.filter requires raw data to
    # be loaded".  The copy keeps the load isolated to a throwaway
    # clone, so the upstream signal stays lazy.
    numpy_signal_eeg = signal.copy().load_data().filter(
        l_freq=config["amplitude_l_freq"],
        h_freq=config["amplitude_h_freq"],
        n_jobs=_art_n_jobs,
    ).pick(picks="eeg").get_data()

    signal_abs = np.abs(numpy_signal_eeg)
    numpy_signal = signal.get_data()
    # Artifact scoring looks up segment boundaries via
    # get_segment_events(): rest mode pulls them from REST
    # annotations, event-locked mode from the STIM channel.  Empty
    # events array → "no segment anchors", handled gracefully by the
    # scoring loop below.
    _seg_events = get_segment_events(signal, config)
    n_samples = numpy_signal.shape[1]
    n_eeg = numpy_signal_eeg.shape[0]

    time_thr_n = int(config["amplitude_time_threshold"] * signal.info["sfreq"])

    params = get_segment_params(config)
    start_n = int(signal.info["sfreq"] * params["tmin"])
    stop_n = int(signal.info["sfreq"] * params["tmax"])

    # Threshold: too many channels exceed amplitude_max_threshold
    picked_signal_max = np.sum(
        signal_abs > config["amplitude_max_threshold"], axis=0
    ) < n_eeg * config["amplitude_nchan_threshold"]
    # picked_signal_max: True = good, False = bad

    # Smooth: ignore short bad blips (too brief to be real artifacts)
    first_probe = True
    start = 0
    for i in range(len(picked_signal_max)):
        stop = i
        if not picked_signal_max[i]:
            if first_probe:
                start = i
                first_probe = False
        else:
            if stop - start < 2 * time_thr_n:
                picked_signal_max[start:stop] = True
            first_probe = True

    # Expand bad regions by time_thr_n on each side
    for i in np.argwhere(np.diff(picked_signal_max) != 0).flatten():
        lo = max(0, i - time_thr_n)
        hi = min(n_samples, i + time_thr_n)
        picked_signal_max[lo:hi] = False

    # Mark segments containing bad samples
    stim_positions = _seg_events[:, 0] if len(_seg_events) else np.zeros(0, dtype=int)
    for i in stim_positions:
        seg_start = i + start_n
        seg_stop = i + stop_n + 1
        if seg_start < 0 or seg_stop > n_samples:
            continue
        if np.sum(picked_signal_max[seg_start:seg_stop]) < stop_n - start_n:
            picked_signal_max[seg_start:seg_stop] = False

    # Convert to artifact mask: broadcast across channels, 1 = artifact
    bad_mask_1d = ~picked_signal_max
    artifact_mask = np.tile(bad_mask_1d.astype(int), (n_eeg, 1))

    # Build description tags
    artifacts_description = []
    sfreq = signal.info["sfreq"]
    in_bad = False
    bad_start = 0
    for i in range(n_samples):
        if bad_mask_1d[i]:
            if not in_bad:
                bad_start = i
                in_bad = True
        else:
            if in_bad:
                artifacts_description.append({
                    "channelNumber": -1,
                    "start_timestamp": bad_start / sfreq,
                    "end_timestamp": i / sfreq,
                    "name": "amplitude",
                    "desc": {"typ": "amplitude_threshold"},
                })
                in_bad = False
    if in_bad:
        artifacts_description.append({
            "channelNumber": -1,
            "start_timestamp": bad_start / sfreq,
            "end_timestamp": n_samples / sfreq,
            "name": "amplitude",
            "desc": {"typ": "amplitude_threshold"},
        })

    return artifacts_description, {"amplitude": artifact_mask}


def _attach_bad_annotations(signal, descriptions, trim_offset):
    """Attach ``BAD_<name>`` annotations to *signal* for each detection.

    Detection ``descriptions`` carry absolute (post-trim) timestamps;
    MNE annotations expect signal-relative onsets, so subtract the
    trim offset.  Mutates *signal* in place — caller owns lifetime.
    """
    if not descriptions:
        return
    rel_onsets = np.array([
        max(0.0, float(a["start_timestamp"]) - trim_offset)
        for a in descriptions])
    durations = np.array([
        max(0.0, float(a["end_timestamp"])
            - float(a["start_timestamp"]))
        for a in descriptions])
    descs = [f"BAD_{a.get('name', 'artifact')}"
             for a in descriptions]
    _append_annotations(signal, rel_onsets, durations, descs)


def _detect_eeg_artifacts(signal, config, path, file_name):
    """EEG-based artifact detection (slopes / outliers / muscles / amplitude).

    Returns
    -------
    occurrence : dict
        ``{"slopes": mask, "outliers": mask, "muscles": mask, "amplitude": mask}``
        — each mask is ``[n_channels, n_samples]`` binary.
    descriptions : list[dict]
        Per-artifact tag dicts with absolute (post-trim) timestamps.
    """
    # Drawer "save" controls the snapshot only; the per-detector
    # plot folder and the Svarog .tag have their own body checkboxes
    # so they can be kept independently of each other and of the
    # snapshot.
    art_cfg = config.get("artifacts", {})
    save_plots = art_cfg.get("save_plots", False)
    save_tag = art_cfg.get("save_tag", False)
    art_root = os.path.join(path, "artifacts_detection")
    os.makedirs(art_root, exist_ok=True)
    art_path = os.path.join(art_root, "found_artifacts")
    os.makedirs(art_path, exist_ok=True)

    occurrence = {}
    descriptions = []
    try:
        numpy_signal_channels = signal.get_data()[
            mne.pick_types(signal.info, eeg=True, exclude="bads"), :]
        signal_info = signal.info

        # RM artifact detection (slopes / outliers / muscles)
        art_det_kargs = config["artifacts"]["rejection_parameters"]
        art_enable = config.get("artifacts", {})
        if not art_enable.get("enable_slopes", True):
            art_det_kargs = dict(art_det_kargs,
                                 SlopesAbsThr=np.inf, SlopesStdThr=np.inf,
                                 SlopesMedThr=np.inf)
        if not art_enable.get("enable_outliers", True):
            art_det_kargs = dict(art_det_kargs,
                                 OutliersAbsThr=np.inf, OutliersStdThr=np.inf,
                                 OutliersMedThr=np.inf)
        if not art_enable.get("enable_muscles", True):
            art_det_kargs = dict(art_det_kargs,
                                 MusclesAbsThr=np.inf, MusclesStdThr=np.inf,
                                 MusclesMedThr=np.inf)

        from ide4eeg.utils.parallel import resolve_n_jobs
        _n_jobs = resolve_n_jobs(config)
        art_desc, art_occ = RM_ArtifactDetection(
            numpy_signal_channels, signal_info,
            art_det_kargs, art_path, n_jobs=_n_jobs)
        descriptions.extend(art_desc)
        occurrence.update(art_occ)

        # Amplitude thresholding
        if (config.get("artifacts", {}).get("enable_amplitude", True)
                and config.get("amplitude_max_threshold") is not None
                and config.get("amplitude_time_threshold") is not None):
            amp_desc, amp_occ = amplitude_artifacts(signal, config)
            descriptions.extend(amp_desc)
            occurrence.update(amp_occ)

        # Offset to absolute (original-recording) time
        trim_offset = float(config.get("_trim_start", 0.0))
        for art in descriptions:
            art["start_timestamp"] += trim_offset
            art["end_timestamp"] += trim_offset

        _attach_bad_annotations(signal, descriptions, trim_offset)
        # .tag (BrainTech XML) + rejection-thresholds JSON go into
        # ``art_root`` directly so the ``found_artifacts`` rmtree
        # below (which kills only the per-detector plots) leaves
        # them intact.  Skipped entirely when save_tag is off.
        if save_tag:
            ArtTagsSaver(art_root, descriptions,
                         config["artifacts"]["rejection_parameters"],
                         file_name)
    finally:
        if not save_plots:
            shutil.rmtree(art_path, ignore_errors=True)
        try:
            os.rmdir(art_root)
        except OSError:
            pass

    return occurrence, descriptions


def _detect_gaze_artifacts(signal, config, path, file_name):
    """Video-based not-looking detection.

    Returns
    -------
    occurrence : dict
        ``{"not_looking": mask}`` (or empty when video / reference faces
        aren't available — the function logs and returns gracefully).
    descriptions : list[dict]
        Per-interval tag dicts with absolute (post-trim) timestamps.
    """
    # Drawer "save" controls the snapshot only; the Svarog .tag is
    # gated by the separate "save_tag" body checkbox.
    save_tag = config.get("gaze", {}).get("save_tag", False)
    art_root = os.path.join(path, "artifacts_detection")
    os.makedirs(art_root, exist_ok=True)

    occurrence = {}
    descriptions = []
    try:
        from .facetag import facetag_video
        path_to_video = config.get("video_path", "").strip() or None
        if path_to_video and not os.path.exists(path_to_video):
            logging.warning(
                "Configured video_path does not exist: %s. "
                "Falling back to auto-discovery.", path_to_video)
            path_to_video = None

        if path_to_video is None:
            original_name = config.get("_input_file_name", file_name)
            video_stem = original_name.split(".")[0]
            input_dir = config.get("_input_dir", path)
            for ext in VIDEO_EXTENSIONS:
                for search_dir in [input_dir, path]:
                    candidate = os.path.join(search_dir, video_stem + ext)
                    if os.path.exists(candidate):
                        path_to_video = candidate
                        break
                if path_to_video:
                    break

        reference_dir = config.get("video_reference_dir", "")

        if path_to_video is None:
            logging.warning(
                "Video for %s not found (tried %s). "
                "Video artifact detection skipped.",
                os.path.join(path, file_name),
                ", ".join(VIDEO_EXTENSIONS))
            return occurrence, descriptions
        if not reference_dir or not os.path.isdir(reference_dir):
            logging.warning(
                "video_reference_dir is not set or does not exist (%s). "
                "Video artifact detection skipped.", reference_dir)
            return occurrence, descriptions

        signal_info = signal.info
        n_channels = mne.pick_types(
            signal_info, eeg=True, exclude="bads").shape[0]
        output_shape = [n_channels, signal.n_times]

        def _video_progress(current, total, current_time, not_looking,
                            face_box=None):
            pct = current / total * 100 if total else 0
            tag = "NOT LOOKING" if not_looking else "looking"
            logging.info(
                "FaceTag: %d/%d frames (%.0f%%) – %.1fs – %s",
                current, total, pct, current_time, tag)

        exclude_dir = config.get("video_exclude_dir", "") or None
        video_tags_occurrence, video_tags_description, _ = facetag_video(
            path_to_video,
            reference_dir=reference_dir,
            output_shape=output_shape,
            progress_callback=_video_progress,
            frame_skip=config.get("facetag_frame_skip", 1),
            downscale=config.get("facetag_downscale", 1.0),
            start_time=config.get("_trim_start", 0.0),
            end_time=config.get("_trim_end"),
            max_angle=config.get("facetag_max_angle", 10.0),
            ref_use_roi=config.get("facetag_ref_use_roi", False),
            face_tolerance=config.get("facetag_face_tolerance", 0.6),
            min_interval=config.get("facetag_min_interval", 0.0),
            no_face_is_artifact=config.get("facetag_no_face_is_artifact", True),
            backend_name=config.get("facetag_backend", "insightface"),
            tracking_adapt_rate=config.get("facetag_tracking_adapt_rate", 0.15),
            position_weight=config.get("facetag_position_weight", 0.4),
            size_weight=config.get("facetag_size_weight", 0.2),
            switch_resistance=config.get("facetag_switch_resistance", 0.25),
            insightface_det_size=config.get("facetag_det_size", 0),
            exclude_dir=exclude_dir,
            gaze_method=config.get("facetag_gaze_method", "l2cs"),
            gaze_smoothing=config.get("facetag_gaze_smoothing", 0.3),
            insightface_processing_skip=config.get(
                "facetag_detection_skip", 3),
            cancel_event=config.get("_cancel_event"),
        )
        descriptions.extend(video_tags_description)
        occurrence["not_looking"] = video_tags_occurrence

        # --- Save outputs ---
        # .tag (BrainTech XML, for Svarog) is opt-in — skip the
        # write when the user didn't tick the body checkbox so we
        # don't create-then-delete on every run.  The review JSON
        # below is the canonical state and is always written.
        if save_tag:
            video_art_path = os.path.join(art_root, "video_artifacts")
            os.makedirs(video_art_path, exist_ok=True)
            video_writer = TagsFileWriter(os.path.join(
                video_art_path, f"{file_name}___video_artifacts.tag"))
            for tag in video_tags_description:
                video_writer.tag_received(tag)
            video_writer.finish_saving(0.0)
            logging.info("Saved .tag to %s", video_art_path)

        # Review-window JSON in the per-recording output dir
        # (always saved — canonical review state).
        try:
            import datetime
            from .facetag.review_window import (
                NotLookingInterval, ReviewData, review_json_path)
            intervals = [
                NotLookingInterval(
                    start_sec=float(t["start_timestamp"]),
                    end_sec=float(t["end_timestamp"]),
                    status="accepted")
                for t in video_tags_description]
            review_json = review_json_path(
                path, path_to_video,
                config.get("facetag_gaze_method", "l2cs"))
            ReviewData(
                path_to_video, reference_dir, intervals,
                datetime.datetime.now().isoformat()
            ).save(review_json)
            logging.info("Saved review JSON to %s", review_json)
        except Exception as e:
            logging.warning("Failed to save review JSON: %s", e)

        # Gaze tags are already in absolute (post-trim) time —
        # no offset needed before annotation attachment.
        trim_offset = float(config.get("_trim_start", 0.0))
        _attach_bad_annotations(signal, video_tags_description, trim_offset)
    finally:
        try:
            os.rmdir(art_root)
        except OSError:
            pass

    return occurrence, descriptions

def RM_ArtifactDetection(numpy_signal_channels, signal_info, ArtDet_kargs=None, outpath="", n_jobs=1):
    '''
    Marcin Pietrzak 2017 from helper_functions\\artifacts_mark.py.

    Finding artifacts.

    Parameters
    ----------
    numpy_signal_channels: numpy.array
        EEG signal in numpy.array.
    signal_info: mne.Info
        Info of signal.
    ArtDet_kargs: dict
        Dictionary of essentials values of artifact detection.
    outpath: str
        Path for plots.

    Returns
    -------
    artifacts_description: list
        Full description of detected artifacts prepared for .tag format.
    artifacts_occurrence: dict
        Keys are names of artifacts, values are matrices of occurred artifacts in the specific channel and time.
        Each matrix has the shape of [number of channels, duration of signal] with two variables {0, 1}. 1 means that
        the artifact occurred in this specific point of time and space.
'''

    if ArtDet_kargs is None:
        ArtDet_kargs = {}

    # tested channels
    ch_2be_tested = list(np.array(signal_info["ch_names"])[mne.pick_types(signal_info, eeg=True)]) # because we are after dropping bad channels and we want pnlu eeg

    # filters for non-muscle artifacts
    filters = [[1., 0.5, 3, 6.97, "butter"],
               [30, 60, 3, 12.4, "butter"],
               [[47.5, 52.5], [49.9, 50.1], 3, 25, "cheby2"]]

    # filters for muscle artifacts
    line_fs = [50.]
    filters_muscle = []
    for line_f in line_fs:
        filters_muscle.append([[line_f - 2.5, line_f + 2.5], [line_f - 0.1, line_f + 0.1], 3.0, 25., "cheby2"])

    forget = ArtDet_kargs.get('forget', 2.)

    try:
        #widnows
        SlopeWindow = ArtDet_kargs['SlopeWindow']
        MusclesWindow = ArtDet_kargs['MusclesWindow']
        OutliersMergeWin = ArtDet_kargs['OutliersMergeWin']
        MusclesFreqRange = ArtDet_kargs['MusclesFreqRange']

        # Slope threshold
        SlopesAbsThr = ArtDet_kargs['SlopesAbsThr']
        SlopesStdThr = ArtDet_kargs['SlopesStdThr']
        SlopesMedThr = ArtDet_kargs['SlopesMedThr']
        SlopesThrs = (SlopesAbsThr, SlopesStdThr, SlopesMedThr)

        # Outlires threshold
        OutliersAbsThr = ArtDet_kargs['OutliersAbsThr']
        OutliersStdThr = ArtDet_kargs['OutliersStdThr']
        OutliersMedThr = ArtDet_kargs['OutliersMedThr']
        OutliersThrs = (OutliersAbsThr, OutliersStdThr, OutliersMedThr)

        # Muscle threshold
        MusclesAbsThr = ArtDet_kargs['MusclesAbsThr']
        MusclesStdThr = ArtDet_kargs['MusclesStdThr']
        MusclesMedThr = ArtDet_kargs['MusclesMedThr']
        MusclesThrs = (MusclesAbsThr, MusclesStdThr, MusclesMedThr)
    except KeyError:
        raise KeyError("MISSING METAPARAMETERS: Provide proper dictionary in segment artifacts.rejection_parameters of "
                 "config file. It should contain: SlopeWindow, MusclesWindow, OutliersMergeWin, MusclesFreqRange_start, "
                 "MusclesFreqRange_stop, SlopesAbsThr, SlopesStdThr, SlopesMedThr, "
                 "OutliersAbsThr, OutliersStdThr, OutliersMedThr, MusclesAbsThr, MusclesStdThr, "
                 "MusclesMedThr.")

    return _detect_artifacts_raw(numpy_signal_channels, signal_info, ch_2be_tested, filters, filters_muscle,
                            forget, OutliersMergeWin, SlopeWindow, MusclesWindow, MusclesFreqRange, SlopesThrs,
                            OutliersThrs, MusclesThrs, outpath, n_jobs=n_jobs)


def _detect_artifacts_raw(numpy_signal_channels, signal_info, channels, filters, filters_muscle, forget,
                          OutliersMergeWin, SlopeWindow, MusclesWindow, MusclesFreqRange, SlopesThrs, OutliersThrs,
                          MusclesThrs, outpath="", n_jobs=1):
    '''
    Marcin Pietrzak 2017 from helper_functions\artifacts_mark.py.

    Finding artifacts.

    Parameters
    ----------
    numpy_signal_channels: numpy.array
        EEG signal in numpy.array.
    signal_info: mne.Info
        Info of signal.
    channels: list
        List of tested channels (not "bad" channels).
    filters: list
        List of lists contain essential values to create filters for all artifacts.
    filters_muscle: list
        List of lists contain essential values to create filters for muscle artifacts.
    forget: float
        Duration (in seconds) of fragments in the beginning and ending of signal for which we aren't save the tags.
    OutliersMergeWin: float
        Length of window (in seconds) in which we connect nearest areas in outliers artifact.
    SlopeWindow: float
        Length of window (in seconds) in which we are searching slopes.
    MusclesWindow: float
        Length of window (in seconds) in which we are searching slows.
    MusclesFreqRange: list
        Two-element list with start and end frequency in which band we are searching muscle artifacts.
    SlopesThrs: list
        Three-element list with thresholds (absolute, standard deviation and median) for slopes artifacts.
    SlowsThrs:
        Three-element list with thresholds (absolute, standard deviation and median) for slows artifacts.
    OutliersThrs:
        Three-element list with thresholds (absolute, standard deviation and median) for outliers artifacts.
    MusclesThrs:
        Three-element list with thresholds (absolute, standard deviation and median) for muscles artifacts.
    outpath: str
        Path for plots.

    Returns
    -------
    artifacts_description: list
        Full description of detected artifacts prepared for .tag format (list of dicts).
    artifacts_occurrence: dict
        Keys are names of artifacts, values are matrices of occurred artifacts in the specific channel and time.
        Each matrix has the shape of [number of channels, duration of signal] with two variables {0, 1}. 1 means that
        the artifact occurred in this specific point of time and space.
'''

    SlopesAbsThr, SlopesStdThr, SlopesMedThr = SlopesThrs
    OutliersAbsThr, OutliersStdThr, OutliersMedThr = OutliersThrs
    MusclesAbsThr, MusclesStdThr, MusclesMedThr = MusclesThrs

    Fs = signal_info["sfreq"]

    artifacts_description = []
    artifacts_occurrence = {}

    # Gate each detector on whether ANY of its three thresholds is
    # finite — when the user unchecks the detector in the GUI, the
    # caller sets all three (Abs / Std / Med) to ``np.inf``.  Skipping
    # the detector entirely is much cheaper than running it with
    # never-tripping thresholds: the per-channel inner loops scan the
    # full signal regardless of what the comparison resolves to.
    def _enabled(thrs):
        return any(np.isfinite(t) for t in thrs)

    #outliers
    if _enabled(OutliersThrs):
        bad_samples, thresholds = outliers(numpy_signal_channels.copy(), signal_info, channels, filters, StdThr=OutliersStdThr, AbsThr=OutliersAbsThr,
                                           MedThr=OutliersMedThr,
                                           outpath=outpath, n_jobs=n_jobs)  # detect outlier artifacts
        bad_samples = ForgetBirthAndDeath(bad_samples, Fs, forget)  # discard detections at signal start/end
        bad_samples = ArtTagsWriter(bad_samples, Fs, signal_info["ch_names"], MergWin=OutliersMergeWin, ArtName="outlier",
                                  Thresholds=thresholds)
        artifacts_description.extend(bad_samples[0])
        artifacts_occurrence["outliers"] = bad_samples[1]

    #slopes
    if _enabled(SlopesThrs):
        bad_samples, thresholds = P2P(numpy_signal_channels.copy(), signal_info, channels, SlopeWindow, filters, StdThr=SlopesStdThr, AbsThr=SlopesAbsThr,
                                      MedThr=SlopesMedThr,
                                      kind='slopes', outpath=outpath, n_jobs=n_jobs)  # detect spikes and steep slopes
        bad_samples = ForgetBirthAndDeath(bad_samples, Fs, forget)  # discard detections at signal start/end
        bad_samples = ArtTagsWriter(bad_samples, Fs, signal_info["ch_names"], MergWin=SlopeWindow, ArtName="slope", Thresholds=thresholds)
        artifacts_description.extend(bad_samples[0])
        artifacts_occurrence["slopes"] = bad_samples[1]

    #muscles
    if _enabled(MusclesThrs):
        bad_samples, thresholds = muscles(numpy_signal_channels.copy(), signal_info, channels, MusclesWindow, MusclesFreqRange, filters_muscle,
                                          StdThr=MusclesStdThr, AbsThr=MusclesAbsThr,
                                          MedThr=MusclesMedThr, outpath=outpath, n_jobs=n_jobs)  # detect muscle artifacts
        bad_samples = ForgetBirthAndDeath(bad_samples, Fs, forget)  # discard detections at signal start/end
        bad_samples = ArtTagsWriter(bad_samples, Fs, signal_info["ch_names"], MergWin=MusclesWindow, ArtName="muscle", Thresholds=thresholds)
        artifacts_description.extend(bad_samples[0])
        artifacts_occurrence["muscles"] = bad_samples[1]

    return artifacts_description, artifacts_occurrence

def _outliers_one_channel(ch, c, StdThr, AbsThr, MedThr, outpath):
    # `c` may arrive as a read-only mmap view when joblib's loky
    # backend serialises the parent array to workers — assignment
    # (not in-place -=) gives us a fresh writable array.
    c = c - c.mean()

    C = c.copy()
    s = np.inf
    while C.std() < s:
        s = C.std()
        C = C[np.abs(C) < StdThr * s + np.median(C)]

    C_abs = np.abs(C)
    Thresholds = (AbsThr*10**-6, MedThr * np.median(C_abs), StdThr * s + np.median(C_abs))

    Threshold = min(Thresholds)
    ThresholdType = ['abs', 'med', 'std'][np.argmin(Thresholds)]

    logging.debug("{:>4}(outliers) - abs: {:.3g}, med: {:.3g}, std: {:.3g}, chosen: {}".format(
        *(ch,) + Thresholds + (ThresholdType,)))
    if Threshold <= 0:
        raise ValueError("Threshold = {}\nYou must give some threshold in range (0,+oo)!".format(Threshold))

    c_abs = np.abs(c)
    bad = (c_abs > Threshold) * c_abs

    if outpath:
        fig, ax = plt.subplots(dpi=1000)
        bins = max(20, c_abs.size // 1000)
        c_abs[c_abs > 3 * Threshold] = 3 * Threshold
        ax.hist(c_abs, bins=bins)
        mx = ax.get_ylim()[1]
        for i in range(3):
            if Thresholds[i] < np.inf:
                ax.plot([Thresholds[i], Thresholds[i]], [0, mx],
                        label=artifact_labels[i])
        ax.plot([Threshold], [mx], "o", label=ThresholdType)
        ax.set_title("{} for {}".format("Outliers", ch))
        ax.set_xlabel(r"Potential $[V]$")
        ax.set_ylabel("Frequency")
        ax.legend()
        fig.savefig(os.path.join(outpath, f"outliers_{ch}.png"))
        plt.close(fig)

    return ch, bad, (Threshold, ThresholdType), Thresholds


def outliers(numpy_signal_channels, signal_info, channels, filters=None, StdThr=np.inf, AbsThr=np.inf, MedThr=np.inf,
             full_output=False, outpath="", n_jobs=1):
    '''
    Marcin Pietrzak 2017 from helper_functions\artifacts_mark.py.

    Finding outliers.

    Parameters
    ----------
    numpy_signal_channels: numpy.array
        EEG signal in numpy.array.
    signal_info: mne.Info
        Info of signal.
    channels: list
        List of channels.
    filters: list
        List of lists contain essential values to create filters for all artifacts.
    StdThr: float
        Multiply of std threshold.
    AbsThr: float
        Absolute threshold.
    MedThr: float
        Multiply of median threshold.
    full_output: bool
        If True, returns bad_samples and AllThresholdsDict, else bad_samples and ThresholdsDict.
    outpath: str
        Path to directory with signal.

    Returns
    -------
    bad_samples: dict
        Samples over the selected threshold for each channel.
    ThresholdsDict: dict
        Type and value of select threshold for each channel.
    AllThresholdsDict: dict
        Values of all prepared thresholds for each channel.
    '''
    # TODO: could test for Gaussianity — a non-Gaussian channel may
    # indicate non-stationary properties (e.g. electrode came loose)

    if filters is None:
        filters = []
    for filter in filters:
        logging.info("Filtering... %s", filter)
        numpy_signal_channels = mgr_filter(numpy_signal_channels, signal_info, filter[0], filter[1], filter[2],
                                           filter[3], filter[4])

    bad_samples = dict()
    ThresholdsDict = dict()  # contains selected threshold and its value
    AllThresholdsDict = dict()  # contains all thresholds with values

    # Each worker receives only its own channel slice (cheap to pickle)
    # and runs the full per-channel computation + optional plotting.
    results = Parallel(n_jobs=n_jobs)(
        delayed(_outliers_one_channel)(
            ch, numpy_signal_channels[ch_idx, :].copy(),
            StdThr, AbsThr, MedThr, outpath,
        )
        for ch_idx, ch in enumerate(channels)
    )
    for ch, bad, thr_info, all_thr in results:
        bad_samples[ch] = bad
        ThresholdsDict[ch] = thr_info
        AllThresholdsDict[ch] = all_thr

    if full_output:
        return bad_samples, AllThresholdsDict
    else:
        return bad_samples, ThresholdsDict


def _p2p_one_channel(ch, c, width, StdThr, AbsThr, MedThr, kind, outpath):
    mm = MiniMax(c, width)
    mm_2 = MiniMax(np.roll(c, -width // 2), width)

    MM = np.concatenate([mm, mm_2])
    if outpath:
        mm_for_hist = MM.copy()
    s = np.inf
    while MM.std() < s:
        s = MM.std()
        MM = MM[MM < StdThr * s + np.median(MM)]

    Thresholds = (AbsThr*10**-6, MedThr * np.median(MM), StdThr * s + np.median(MM))
    Threshold = min(Thresholds)
    ThresholdType = ['abs', 'med', 'std'][np.argmin(Thresholds)]
    logging.info("{:>4}({}) - abs: {:.3g}, med: {:.3g}, std: {:.3g}, chosen: {}".format(
        *(ch, kind) + Thresholds + (ThresholdType,)))

    if Threshold <= 0:
        raise ValueError("Threshold = {}\nYou must give some threshold in range (0,+oo)!".format(Threshold))
    bad_segment = mm * (mm > Threshold)
    bad_segment_2 = mm_2 * (mm_2 > Threshold)

    bad = np.max(
        [BadSeg2BadSamp(bad_segment, width, c.size),
         BadSeg2BadSamp(bad_segment_2, width, c.size, width // 2)],
        axis=0)

    if outpath:
        fig, ax = plt.subplots(dpi=1000)
        bins = max(20, mm_for_hist.size // 100)
        mm_for_hist[mm_for_hist > 3 * Threshold] = 3 * Threshold
        ax.hist(mm_for_hist, bins=bins)
        mx = ax.get_ylim()[1]
        for i in range(3):
            if Thresholds[i] < np.inf:
                ax.plot([Thresholds[i], Thresholds[i]], [0, mx], label=artifact_labels[i])
        ax.plot([Threshold], [mx], "o", label=ThresholdType)
        ax.set_title("{} for {}".format(kind, ch))
        ax.set_xlabel(r"Potential $[V]$")
        ax.set_ylabel("Frequency")
        ax.legend()
        fig.savefig(os.path.join(outpath, "{}_{}.png".format(kind, ch)))
        plt.close(fig)

    return ch, bad, (Threshold, ThresholdType), Thresholds


def P2P(numpy_signal_channels, signal_info, channels, width, filters=None, StdThr=np.inf, AbsThr=np.inf, MedThr=np.inf,
        kind='P2P', full_output=False, outpath="", n_jobs=1):
    '''
    Marcin Pietrzak 2017 from helper_functions\artifacts_mark.py.

    Subtracting min and max value in all signal bands from the width parameter and finding artifacts with this
    peak-to-peak value.

    Parameters
    ----------
    numpy_signal_channels: numpy.array
        EEG signal in numpy.array.
    signal_info: mne.Info
        Info of signal.
    channels: list
        List of channels.
    width: float
        Width (in seconds) of window.
    filters: list
        List of lists contain essential values to create filters for all artifacts.
    StdThr: float
        Multiply of std threshold.
    AbsThr: float
        Absolute threshold.
    MedThr: float
        Multiply of median threshold.
    kind: str
        Kind of the artifact (for example slow or slope).
    full_output: bool
        If True, returns bad_samples and AllThresholdsDict, else bad_samples and ThresholdsDict.
    outpath: str
        Path to directory with signal.

    Returns
    -------
    bad_samples: dict
        Samples over the selected threshold for each channel.
    ThresholdsDict: dict
        Type and value of select threshold for each channel.
    AllThresholdsDict: dict
        Values of all prepared thresholds for each channel.
    '''

    if filters is None:
        filters = []
    for filter in filters:
        logging.info("Filtering... %s", filter)
        numpy_signal_channels = mgr_filter(numpy_signal_channels, signal_info, filter[0], filter[1], filter[2],
                                           filter[3], filter[4])

    Fs = signal_info["sfreq"]
    width = int(width * Fs)
    bad_samples = dict()
    ThresholdsDict = dict() # contains selected threshold and its value
    AllThresholdsDict = dict() # contains all thresholds with values

    results = Parallel(n_jobs=n_jobs)(
        delayed(_p2p_one_channel)(
            ch, numpy_signal_channels[ch_idx, :].copy(),
            width, StdThr, AbsThr, MedThr, kind, outpath,
        )
        for ch_idx, ch in enumerate(channels)
    )
    for ch, bad, thr_info, all_thr in results:
        bad_samples[ch] = bad
        ThresholdsDict[ch] = thr_info
        AllThresholdsDict[ch] = all_thr

    if full_output:
        return bad_samples, AllThresholdsDict
    else:
        return bad_samples, ThresholdsDict


def _muscles_one_channel(ch, c, width, rng, Fs, StdThr, AbsThr, MedThr, outpath):
    # See _outliers_one_channel: `c` may be read-only under loky.
    c = c - c.mean()

    Pmsc, freqs = Power(c, width, rng, Fs)
    Pmsc_2, freqs = Power(np.roll(c, -width // 2), width, rng, Fs)

    PP = np.concatenate([Pmsc, Pmsc_2])
    if outpath:
        pp_for_hist = PP.copy()
    s = np.inf
    while PP.std() < s:
        s = PP.std()
        PP = PP[PP < StdThr * s + np.median(PP)]

    Thresholds = (AbsThr * 1e-12, MedThr * np.median(PP), StdThr * s + np.median(PP))
    Threshold = min(Thresholds)
    ThresholdType = ['abs', 'med', 'std'][np.argmin(Thresholds)]
    logging.info("{:>4}(muscles) - abs: {:.3g}, med: {:.3g}, std: {:.3g}, chosen: {}".format(
        *(ch,) + Thresholds + (ThresholdType,)))

    if Threshold <= 0:
        raise ValueError("Threshold = {}\nYou must give some threshold in range (0,+oo)!".format(Threshold))

    bad_segment = Pmsc * (Pmsc > Threshold)
    bad_segment_2 = Pmsc_2 * (Pmsc_2 > Threshold)

    bad = np.max(
        [BadSeg2BadSamp(bad_segment, width, c.size),
         BadSeg2BadSamp(bad_segment_2, width, c.size, width // 2)],
        axis=0)

    if outpath:
        fig, ax = plt.subplots(dpi=1000)
        bins = max(20, pp_for_hist.size // 100)
        pp_for_hist[pp_for_hist > 3 * Threshold] = 3 * Threshold
        ax.hist(pp_for_hist, bins=bins)
        mx = ax.get_ylim()[1]
        for i in range(3):
            if Thresholds[i] < np.inf:
                ax.plot([Thresholds[i], Thresholds[i]], [0, mx], label=artifact_labels[i])
        ax.plot([Threshold], [mx], "o", label=ThresholdType)
        ax.set_title("{} for {}".format("Muscles", ch))
        ax.set_xlabel(r"Power $[V^2]$")
        ax.set_ylabel("Frequency")
        ax.legend()
        fig.savefig(os.path.join(outpath, f"muscles_{ch}.png"))
        plt.close(fig)

    return ch, bad, (Threshold, ThresholdType), Thresholds


def muscles(numpy_signal_channels, signal_info, channels, width, rng, filters=None, StdThr=np.inf, AbsThr=np.inf,
            MedThr=np.inf, full_output=False, outpath="", n_jobs=1):
    '''
    Marcin Pietrzak 2017 from helper_functions\artifacts_mark.py.

    Finding muscle artifacts.

    Parameters
    ----------
    numpy_signal_channels: numpy.array
        EEG signal in numpy.array.
    signal_info: mne.Info
        Info of signal.
    channels: list
        List of channels.
    filters: list
        List of lists contain essential values to create filters for all artifacts.
    StdThr: float
        Multiply of std threshold.
    AbsThr: float
        Absolute threshold.
    MedThr: float
        Multiply of median threshold.
    full_output: bool
        If True, returns bad_samples and AllThresholdsDict, else bad_samples and ThresholdsDict.
    outpath: str
        Path to directory with signal.

    Returns
    -------
    bad_samples: dict
        Samples over the selected threshold for each channel.
    ThresholdsDict: dict
        Type and value of select threshold for each channel.
    AllThresholdsDict: dict
        Values of all prepared thresholds for each channel.
    '''

    if filters is None:
        filters = []
    for filter in filters:
        logging.info("Filtering... %s", filter)
        numpy_signal_channels = mgr_filter(numpy_signal_channels, signal_info, filter[0], filter[1], filter[2],
                                           filter[3], filter[4])

    Fs = signal_info["sfreq"]
    width = int(width * Fs)
    bad_samples = dict()
    ThresholdsDict = dict()  # contains selected threshold and its value
    AllThresholdsDict = dict()  # contains all thresholds with values

    results = Parallel(n_jobs=n_jobs)(
        delayed(_muscles_one_channel)(
            ch, numpy_signal_channels[ch_idx, :].copy(),
            width, rng, Fs, StdThr, AbsThr, MedThr, outpath,
        )
        for ch_idx, ch in enumerate(channels)
    )
    for ch, bad, thr_info, all_thr in results:
        bad_samples[ch] = bad
        ThresholdsDict[ch] = thr_info
        AllThresholdsDict[ch] = all_thr

    if full_output:
        return bad_samples, AllThresholdsDict
    else:
        return bad_samples, ThresholdsDict

def ForgetBirthAndDeath(bs, Fs, forget = 1.):
    '''
    Marcin Pietrzak 2017 from helper_functions\artifacts_mark.py.

    Deleting artifact variables on the begining and ending.

    Parameters
    ----------
    bs: dict
        Dict of detected artifacts on the specific channels.
    Fs: float
        Sampling frequency.
    forget: float
        How long (in seconds) we will delete possible artifacts at the beginning and end.

    Returns
    -------
    bs: dict
        Dict of detected artifacts on the specific channels without beginning and ending points.
    '''
    for ch in bs:
        bs[ch][:int(Fs * forget)] = 0.0
        bs[ch][-int(Fs * forget):] = 0.0
    return bs

def ArtTagsWriter(bad_samples, Fs, doc_channels, MergWin, ArtName='artifact', Thresholds=np.inf, MinDuration=0.03):
    '''
    Marcin Pietrzak 2017 from helper_functions\\artifacts_mark.py.

    Binding nearest points detected as artifacts.

    Parameters
    ----------
    bad_samples: dict
        Dictionary of detected artifacts on the specific channels.
    Fs: float
        Sampling frequency.
    doc_channels: list of str
        Channel names of the document Svarog will display the
        tag against — i.e. ``signal.ch_names`` of the saved
        ``-raw.fif``.  Each tag's ``channelNumber`` is the index
        of its channel in this list.  MUST be the post-drop list
        (the saved file's channel order), not the original input
        file's pre-drop channel set: when ``chosen_channels``
        reduces 23 channels to 5, a tag with channelNumber=7
        crashes Svarog with IndexOutOfBoundsException on paint.

    MergWin: float
        Length of window (in seconds) for checking nearest artifacts to connect.
    ArtName: str
        Name of artifact.
    Thresholds: dict or np.inf
        Type and value of select threshold for each channel.
    MinDuration: float
        Minimal length of detected artifact.

    Returns
    -------
    artifacts_description: list
        Full description of detected artifacts prepared for .tag format (list of dicts).
    artifacts_occurrence: dict
        Keys are names of artifacts, values are matrices of occurred artifacts in the specific channel and time.
        Each matrix has the shape of [number of channels, duration of signal] with two variables {0, 1}. 1 means that
        the artifact occurred in this specific point of time and space.
    '''

    artifacts_description = [] #all informations for file with .tag format

    if not bad_samples:
        return artifacts_description, np.empty((0, 0))

    artifacts_occurrence = np.zeros((len(bad_samples), len(next(iter(bad_samples.values()))))) #matrix of 0 and 1, where 1 means artifact

    for ch_idx, ch in enumerate(bad_samples):
        if Thresholds == np.inf:
            threshold, threshold_type = np.inf, 'art'  # default
        else:
            threshold, threshold_type = Thresholds[ch]

        bads = bad_samples[ch]

        start = stop = 0.
        artifact = False
        value = -np.inf
        for i in range(bads.size):
            if bads[i]:
                if bads[i] > value:
                    value = bads[i]
                stop = i
                if not artifact:
                    start = i
                    artifact = True
            elif artifact:
                if i - stop > MergWin * Fs:
                    if stop - start < int(
                            MinDuration * Fs):  # symmetrically expand tag so it's not shorter than MinDuration
                        Ext = int(MinDuration * Fs) - stop + start
                        stop += Ext / 2
                        start = max(0, start - Ext / 2)
                    tag_all = {'channelNumber': "{}".format(doc_channels.index(ch)), 'start_timestamp': 1. * start / Fs, 'name': ArtName,
                           'end_timestamp': 1. * stop / Fs,
                           'desc': {'ch': ch, 'thr': "{:2.2}".format(threshold * 10**-6), 'val': "{:2.2}".format(value * 10**-6),
                                    'typ': threshold_type}}

                    artifacts_description.append(tag_all)
                    artifacts_occurrence[ch_idx, int(start):int(stop) + 1] = 1
                    value = -np.inf
                    artifact = False

        # Flush any pending artifact at end of channel
        if artifact:
            if stop - start < int(MinDuration * Fs):
                Ext = int(MinDuration * Fs) - stop + start
                stop += Ext / 2
                start = max(0, start - Ext / 2)
            tag_all = {'channelNumber': "{}".format(doc_channels.index(ch)),
                       'start_timestamp': 1. * start / Fs, 'name': ArtName,
                       'end_timestamp': 1. * stop / Fs,
                       'desc': {'ch': ch, 'thr': "{:2.2}".format(threshold * 10**-6),
                                'val': "{:2.2}".format(value * 10**-6),
                                'typ': threshold_type}}
            artifacts_description.append(tag_all)
            artifacts_occurrence[ch_idx, int(start):int(stop) + 1] = 1

    return artifacts_description, artifacts_occurrence


def ArtTagsSaver(artifacts_file_path, tags, rej_dict, file_name):
    '''
    Saving artifacts to .tag file.

    Parameters
    ----------
    artifacts_file_path: str
        Path to the directory for data about artifacts.
    tags: list
        Full description of detected artifacts prepared for .tag format.
    rej_dict: dict

    '''

    try:
        os.makedirs(os.path.dirname(artifacts_file_path))
    except OSError:
        pass

    writer = TagsFileWriter(os.path.join(artifacts_file_path, f"{file_name}___artifacts.tag"))
    for tag in tags:
        writer.tag_received(tag)
    writer.finish_saving(0.0)

    with open(os.path.join(artifacts_file_path, f"{file_name}____artifact_rej_dict.json"), 'w') as f:
        json.dump(rej_dict, f, indent=4, sort_keys=True)


def MiniMax(s, w):
    '''
    Marcin Pietrzak 2017 from helper_functions\artifacts_mark.py.

    Substract min and max value in the all parts of divided signal by w variable.

    Parameters
    ----------
    s: list or np.array
        Values of signal.
    w: float
        Width (in seconds) of window.

    Returns
    -------
    mm: np.array
        Array of the all min-to-max values in the all parts of signal divided by widnow.
    '''
    mm = []
    for i in range(0, s.size, w):
        m = s[i:i + w].max() - s[i:i + w].min()
        mm.append(m)
    return np.array(mm)

def BadSeg2BadSamp(bad_segments, width, size, shift = 0):
    y = np.zeros(size, dtype = bad_segments.dtype)
    for i in range(bad_segments.size):
        y[i * width + shift:(i + 1) * width + shift] = bad_segments[i]
    return y

def mgr_filter(numpy_signal_channels, signal_info, wp, ws, gpass, gstop, ftype):
    """Filter signals using IIR design with SOS output for stability.

    Parameters
    ----------
    numpy_signal_channels : numpy.ndarray
        EEG signal array (n_channels, n_samples).
    signal_info : mne.Info
        Signal info (for sampling frequency).
    wp, ws : float or list
        Passband/stopband edge frequencies in Hz.
    gpass : float
        Maximum passband ripple in dB.
    gstop : float
        Minimum stopband attenuation in dB.
    ftype : str
        IIR filter type (``"butter"``, ``"cheby2"``, etc.).

    Returns
    -------
    numpy_signal_channels : numpy.ndarray
        Filtered signal.
    """
    fs = float(signal_info['sfreq'])
    nyq = fs / 2.0

    # Validate: skip if frequencies exceed Nyquist
    freqs = [wp, ws] if not isinstance(wp, list) else wp + ws
    if any(f >= nyq for f in (freqs if isinstance(freqs, list) else [freqs])):
        logging.warning("Filter frequency %.1f Hz exceeds Nyquist (%.0f Hz) "
                        "at fs=%.0f Hz. Skipped.", max(freqs), nyq, fs)
        return numpy_signal_channels

    sos = ss.iirdesign(wp, ws, gpass, gstop, analog=0, ftype=ftype,
                       output='sos', fs=fs)
    for i in range(int(numpy_signal_channels.shape[0])):
        numpy_signal_channels[i, :] = ss.sosfiltfilt(
            sos, numpy_signal_channels[i] - np.mean(numpy_signal_channels[i]))
    return numpy_signal_channels
