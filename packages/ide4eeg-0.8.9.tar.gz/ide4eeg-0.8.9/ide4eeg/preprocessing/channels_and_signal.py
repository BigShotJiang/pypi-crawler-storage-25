"""Channel selection, filtering, ICA/EOG removal, and re-referencing.

Contains the core signal-processing steps between raw loading and
artifact detection: resampling, montage setup, bandpass/bandstop
filtering, ICA decomposition, bad-channel detection via band-power
and correlation, and signal-trimming around events.
"""

# Author: Szymon Bocian, 2022

import logging
import shutil
import mne
import numpy as np
import pandas as pd
import scipy.signal as ss
import os
import matplotlib.pyplot as plt

from .. import NATIVE_POSITIONS_SENTINEL
from ..plots.plots import plot_BandPower, plot_correlation_matrix


def _stim_channel_names(info):
    """Return the names of every channel of type ``'stim'`` in *info*.

    Today the rest-mode preamble attaches REST annotations rather
    than synthesising a second stim channel, so a fresh signal will
    typically have just the file reader's ``STIM``.  Older saved
    snapshots may still carry an additional ``STIM_rest`` channel;
    this helper handles both uniformly via channel type.
    """
    return [c for i, c in enumerate(info["ch_names"])
            if mne.channel_type(info, i) == "stim"]


def get_segmentation_mode(config):
    """Return the active segmentation mode — ``"rest"`` or ``"epochs"``.

    Single source of truth for the mode lookup.  Reads
    ``config["segmentation"]["mode"]``.  Every place in the pipeline
    that needs to branch on segmentation mode (cut_segments, MP,
    artifact scoring, dataframe formatting) should call this helper
    rather than reading the config dict by path; this makes the mode
    location a single point of change if we ever reorganise the
    config schema again.
    """
    return config.get("segmentation", {}).get("mode", "rest")


def get_segment_events(signal, config, warn_if_missing=False):
    """Return the events array for the active segmentation mode.

    Single source of truth for "give me segment-boundary events" used
    by :func:`_cut_segments`, the MP decomposition / filter passes,
    and artifact scoring.

    - **Rest mode** reads ``REST`` annotations attached by
      :func:`_add_rest_markers`.  Pure metadata operation — no signal
      data is touched.
    - **Event-locked mode** reads file-derived events from the
      original ``STIM`` channel via :func:`mne.find_events`.
    - **Legacy fallback** (saved snapshots from before 2026-04 carry
      a ``STIM_rest`` channel and no annotations): rest mode falls
      back to ``find_events(stim_channel="STIM_rest")``.

    Returns
    -------
    events : numpy.ndarray of shape (n_events, 3)
        MNE-style events array.  Empty (shape ``(0, 3)``) when the
        signal has no events of the expected kind — callers handle
        that gracefully.
    """
    if get_segmentation_mode(config) == "rest":
        descs = (set(signal.annotations.description)
                 if len(signal.annotations) else set())
        if REST_ANNOT in descs:
            events, _ = mne.events_from_annotations(
                signal,
                event_id={REST_ANNOT: REST_EVENT_ID},
                verbose=False)
            return events
        if STIM_REST_CHANNEL in signal.info["ch_names"]:
            return mne.find_events(
                signal, stim_channel=STIM_REST_CHANNEL,
                initial_event=True, shortest_event=1, verbose=False)
        # Rest mode but no REST annotations and no STIM_rest channel.
        # Two scenarios:
        #   (a) Called BEFORE the late-preamble's _add_rest_markers
        #       run (e.g. from the artifacts step's event-aware
        #       gating).  Markers will be attached later — silent
        #       early return is correct.
        #   (b) Called from the postamble's cut_segments AFTER
        #       _add_rest_markers, but no markers ended up attached
        #       (e.g. user flipped to rest mode on a stale snapshot).
        #       That's the case worth warning about.
        # Distinguish via the ``warn_if_missing`` kwarg — only the
        # postamble passes True.
        if warn_if_missing:
            logging.warning(
                "Rest mode is active but the signal carries neither "
                "REST annotations nor a STIM_rest channel — no "
                "segments will be cut.  Re-run from preamble or "
                "check [rest].window_length / mode toggling.")
        return np.zeros((0, 3), dtype=int)
    if "STIM" not in signal.info["ch_names"]:
        return np.zeros((0, 3), dtype=int)
    return mne.find_events(signal, stim_channel="STIM",
                           shortest_event=1, verbose=False)


def _refresh_channel_metadata(config, signal):
    """Write current signal metadata into ``config``.

    Populates ``config["sfreq"]`` and
    ``config["choosing_channels"]["all_channels_names" / "all_channels_types"]``
    from the given signal.  Called twice by
    :func:`ide4eeg.preprocessing.preprocessing.preprocessing`:
    once before the reorderable step loop (so in-loop steps see a
    best-effort snapshot) and once after (so postamble consumers see
    the final channel set after any drop / resample / montage).
    """
    config["sfreq"] = signal.info["sfreq"]
    config.setdefault("choosing_channels", {})
    config["choosing_channels"]["all_channels_names"] = signal.info["ch_names"]
    config["choosing_channels"]["all_channels_types"] = [
        mne.channel_type(signal.info, i)
        for i in range(len(signal.info["ch_names"]))]


def _maybe_add_rest_markers(signal, config):
    """Call :func:`_add_rest_markers` iff segmentation mode is rest.

    Handful of callers (the main pipeline preamble plus the GUI step
    workers that run the preamble sequence manually) all need the same
    "rest mode? attach REST annotations" idiom.  Centralising it here
    keeps :func:`get_segmentation_mode` as the single source of truth
    for the mode lookup.
    """
    if get_segmentation_mode(config) == "rest":
        return _add_rest_markers(signal, config)
    return signal


def _resample_signal(signal, config):
    '''
    Resample signal.

    Parameters
    ----------
    signal: mne.io.array.array.RawArray
        Signal in mne Raw format.
    config: dict
        Dictionary of configuration variables.

    Returns
    -------
    signal: mne.io.array.array.RawArray
        Signal in mne Raw format with new sampling frequency.
    '''

    target = config.get("resample_freq", 0)
    if target and target > 0 and signal.info["sfreq"] != target:
        logging.info("Resampling from %.0f Hz to %.0f Hz.",
                     signal.info["sfreq"], target)
        config["sfreq"] = target
        from ide4eeg.utils.parallel import (
            resolve_n_jobs, timed_parallel_block)
        n_jobs = resolve_n_jobs(config)
        with timed_parallel_block("resample", config.get("_cancel_event")):
            return signal.copy().load_data().resample(
                sfreq=target, n_jobs=n_jobs)
    else:
        logging.info("Keeping original sampling rate: %.0f Hz.",
                     signal.info["sfreq"])
        config["sfreq"] = signal.info["sfreq"]
        return signal.copy()


def _select_channels(signals, tags_desc_id, config):
    '''
    Select and drop channels.

    Parameters
    ----------
    signals: list
        List of signals in mne Raw format (mne.io.array.array.RawArray) with the same info (so with the same channels).
    tags_desc_id: dict
        Dictionary of the names of prepared tags and their values in the new STIM signal.
    config: dict
        Dictionary of configuration variables.

    Returns
    -------
    signals: list
        List of signals in mne Raw format (mne.io.array.array.RawArray) with chosen channels.
    '''

    signals = [signal.copy() for signal in signals]

    logging.info(f"Data was provided with these channels: {', '.join(signals[0].info['ch_names'])}.")

    # Stim channels are never user-selectable — downstream
    # get_segment_events resolves them based on the active mode.
    # Filter by channel type so legacy snapshots that still carry
    # a STIM_rest channel are handled the same as the modern
    # single-STIM layout.
    stim_chs = _stim_channel_names(signals[0].info)

    # ----selected channels----
    # list of selected channels
    if isinstance(config["choosing_channels"]["selected_channels"], list):
        avail = set(signals[0].info["ch_names"])
        requested = config["choosing_channels"]["selected_channels"]
        missing = [ch for ch in requested if ch not in avail]
        if missing:
            logging.warning(
                "Selected channels not found in signal and will be "
                "ignored: %s.  Likely a typo or a name that doesn't "
                "match the file's actual channels (%s ...).",
                missing,
                ", ".join(signals[0].info["ch_names"][:5]))
        config["choosing_channels"]["selected_channels"] = [
            ch for ch in requested if ch in avail]
        for stim_ch in stim_chs:
            if stim_ch not in config["choosing_channels"]["selected_channels"]:
                config["choosing_channels"]["selected_channels"].append(stim_ch)

    # all selected channels
    elif config["choosing_channels"]["selected_channels"] in ["all", "every"]:
        config["choosing_channels"]["selected_channels"] = [ch for ch in signals[0].info["ch_names"]]

    # None selected channels — default to all channels
    elif config["choosing_channels"]["selected_channels"] in [None, "", "None", "none"]:
        logging.warning("You must choose at least one channel. In the next step we will choose all channels.")
        config["choosing_channels"]["selected_channels"] = [ch for ch in signals[0].info["ch_names"]]
        for stim_ch in stim_chs:
            if stim_ch not in config["choosing_channels"]["selected_channels"]:
                config["choosing_channels"]["selected_channels"].append(stim_ch)

    logging.info(f"Selected channels are: {', '.join(config['choosing_channels']['selected_channels']) if isinstance(config['choosing_channels']['selected_channels'], list) else config['choosing_channels']['selected_channels']}.")


    # ----dropped channels----
    # list of dropped channels
    if isinstance(config["choosing_channels"]["dropped_channels"], list):
        avail = set(signals[0].info["ch_names"])
        requested = config["choosing_channels"]["dropped_channels"]
        missing = [ch for ch in requested if ch not in avail]
        if missing:
            logging.warning(
                "Dropped channels not found in signal and will be "
                "ignored: %s.",
                missing)
        config["choosing_channels"]["dropped_channels"] = [
            ch for ch in requested if ch in avail]
        config["choosing_channels"]["dropped_channels"] = [
            ch for ch in config["choosing_channels"]["dropped_channels"]
            if ch not in stim_chs]

    # None dropped channels
    elif config["choosing_channels"]["dropped_channels"] in [None, "", "None", "none"]:
        config["choosing_channels"]["dropped_channels"] = []

    # all dropped channels
    elif config["choosing_channels"]["dropped_channels"] in ["all", "every"]:
        logging.warning("You can't dropped all channels. None of channels will be dropped.")
        config["choosing_channels"]["dropped_channels"] = []

    logging.info(f"Dropped channels are: {', '.join(config['choosing_channels']['dropped_channels'])}.")

    # ----final channels----
    config["choosing_channels"]["selected_channels_final"] = [ch for ch in signals[0].info['ch_names'] if ch in config["choosing_channels"]["selected_channels"] and ch not in config["choosing_channels"]["dropped_channels"]]
    config["choosing_channels"]["dropped_channels_final"] = [ch for ch in signals[0].info["ch_names"] if ch in config["choosing_channels"]["dropped_channels"] or ch not in config["choosing_channels"]["selected_channels_final"]]

    if config["choosing_channels"]["check_final_channels"]:
        signals[0].info["bads"].extend(config["choosing_channels"]["dropped_channels_final"])
        # For the interactive preview, overlay events from the primary
        # STIM channel (the file's original event markers, if any).
        # Synthetic rest-window onsets live in REST annotations and
        # are picked up by cut_segments, not shown in this preview.
        primary_stim = "STIM" if "STIM" in signals[0].info["ch_names"] else None
        if primary_stim:
            overlay_events = mne.find_events(
                signals[0], stim_channel=primary_stim, shortest_event=1,
                verbose=False)
        else:
            overlay_events = np.empty((0, 3), dtype=int)
        signals[0].plot(events=overlay_events,
                        event_id=tags_desc_id, block=True)

        config["choosing_channels"]["dropped_channels_final"] = signals[0].info["bads"]
        config["choosing_channels"]["dropped_channels_final"] = [
            ch for ch in config["choosing_channels"]["dropped_channels_final"]
            if ch not in stim_chs]

        config["choosing_channels"]["selected_channels_final"] = [ch for ch in config["choosing_channels"]["selected_channels_final"] if ch not in config["choosing_channels"]["dropped_channels_final"] and ch in signals[0].info['ch_names']]
        for stim_ch in stim_chs:
            if stim_ch not in config["choosing_channels"]["selected_channels_final"]:
                config["choosing_channels"]["selected_channels_final"].append(stim_ch)

        signals[0].info["bads"] = []

    signals = [signal.drop_channels(config["choosing_channels"]["dropped_channels_final"]) for signal in signals]
    logging.info(f"Final channels are: {', '.join(config['choosing_channels']['selected_channels_final'])}.")


    return signals



# ---------------------------------------------------------------------------
# Automatic filter design
# ---------------------------------------------------------------------------

def design_iir_filter(filter_type, freq_hz, fs, gpass=3, gstop=None):
    """Design an IIR filter in SOS format for the given sampling rate.

    Parameters
    ----------
    filter_type : str
        ``"highpass"``, ``"lowpass"``, or ``"notch"``.
    freq_hz : float
        Cutoff frequency (highpass/lowpass) or center frequency (notch)
        in Hz.
    fs : float
        Sampling rate in Hz.
    gpass : float
        Maximum passband ripple in dB (default 3).
    gstop : float or None
        Minimum stopband attenuation in dB.  If None, uses defaults:
        10 dB for highpass/lowpass, 25 dB for notch.

    Returns
    -------
    sos : ndarray or None
        Second-order sections array.  None if the filter cannot be
        designed (frequency too close to Nyquist).
    info : dict
        ``wp``, ``ws``, ``ftype``, ``order`` for logging/display.
    """
    nyq = fs / 2.0

    if freq_hz <= 0:
        return None, {}

    if filter_type == "highpass":
        if freq_hz >= nyq:
            logging.warning("Highpass %.1f Hz impossible at fs=%.0f Hz "
                            "(Nyquist=%.0f Hz). Skipped.",
                            freq_hz, fs, nyq)
            return None, {}
        wp = freq_hz
        ws = freq_hz / 2.0
        ftype = "butter"
        gstop = gstop or 10

    elif filter_type == "lowpass":
        if freq_hz >= nyq:
            logging.warning("Lowpass %.1f Hz impossible at fs=%.0f Hz "
                            "(Nyquist=%.0f Hz). Skipped.",
                            freq_hz, fs, nyq)
            return None, {}
        wp = freq_hz
        ws = min(freq_hz * 2.0, nyq * 0.95)
        ftype = "butter"
        gstop = gstop or 12

    elif filter_type == "notch":
        if freq_hz >= nyq * 0.95:
            logging.warning("Notch %.0f Hz too close to Nyquist (%.0f Hz) "
                            "at fs=%.0f Hz. Skipped.",
                            freq_hz, nyq, fs)
            return None, {}
        wp = [freq_hz - 2.5, freq_hz + 2.5]
        ws = [freq_hz - 0.1, freq_hz + 0.1]
        # Clamp edges to valid range
        if wp[0] <= 0:
            wp[0] = 0.1
        if ws[0] <= 0:
            ws[0] = 0.05
        if wp[1] >= nyq:
            wp[1] = nyq * 0.98
        ftype = "cheby2"
        gstop = gstop or 25

    else:
        raise ValueError(f"Unknown filter type: {filter_type}")

    try:
        sos = ss.iirdesign(wp, ws, gpass, gstop,
                           ftype=ftype, output="sos", fs=fs)
        # Determine resulting order from SOS shape
        order = sos.shape[0] * 2
        info = {"wp": wp, "ws": ws, "ftype": ftype, "order": order,
                "gpass": gpass, "gstop": gstop}
        return sos, info
    except Exception as e:
        logging.error("Filter design failed (%s %.1f Hz, fs=%.0f): %s",
                      filter_type, freq_hz, fs, e)
        return None, {}


def _has_native_eeg_positions(signal):
    """True if every EEG channel already carries a valid 3D location.

    Checks ``info["chs"][i]["loc"][:3]`` for each EEG channel — valid
    means non-NaN, non-all-zero.  MNE sample FIFs and some BrainVision
    files ship real digitized positions here; blindly applying a
    standard_XYZ montage would blank those out (no name match for
    "EEG 001", on_missing="warn" → NaN locs), breaking every
    location-dependent step downstream (topomap, dipole fit, ...).
    """
    eeg_picks = mne.pick_types(signal.info, eeg=True, exclude=[])
    if len(eeg_picks) == 0:
        return False
    for i in eeg_picks:
        loc = signal.info["chs"][i]["loc"][:3]
        if not np.all(np.isfinite(loc)) or not np.any(loc):
            return False
    return True


def _set_montage(signal, config):
    '''
    Apply an electrode-position montage to *signal*.

    Phase 1 (2026-04) split: re-referencing now lives in a separate
    pipeline step (:func:`_set_reference`), so this function only
    handles electrode positions.  Legacy ``step_order`` entries with
    ``"montage"`` but no ``"reference"`` are auto-migrated by the
    pipeline driver.

    Parameters
    ----------
    signal: mne.io.array.array.RawArray
        Signal in mne Raw format.
    config: dict
        Dictionary of configuration variables.

    Returns
    -------
    signal: mne.io.array.array.RawArray
        Signal with the montage applied.
    '''

    signal = signal.copy()
    # set_montage is metadata-only and works lazily, but downstream
    # steps (filter, ICA, reference) all need preloaded data and
    # this is the natural point to materialise it once.
    signal.load_data()

    # Bail early when there are no EEG channels left (e.g. user
    # dropped them all in chosen_channels or only had EOG/misc to
    # begin with).  set_montage with zero EEG picks emits a series
    # of confusing warnings and downstream plot_topomap then fails
    # with "no EEG channels" — better to skip and document.
    if len(mne.pick_types(signal.info, eeg=True, exclude=[])) == 0:
        logging.warning(
            "Montage step skipped — no EEG-typed channels in the "
            "current signal.  Downstream topomaps and 3D viz will "
            "be unavailable until EEG channels are restored.")
        return signal

    layout = config.get("electrodes_layout")
    if _has_native_eeg_positions(signal):
        # File already provides real positions for every EEG channel
        # (e.g. MNE sample FIF with "EEG 001"... naming + digitized
        # coords).  Keep them — standard_1020 matches by name and
        # would silently blank these out.
        n_eeg = len(mne.pick_types(signal.info, eeg=True, exclude=[]))
        logging.info(
            f"Keeping native electrode positions from file "
            f"({n_eeg} EEG channels have valid 3D locations); "
            f"skipping standard montage application.")
        config["electrodes_layout"] = NATIVE_POSITIONS_SENTINEL
        return signal

    if layout == NATIVE_POSITIONS_SENTINEL:
        # Config requests native but signal doesn't have positions
        # (e.g. GUI locked this on a FIF, then user edited the TOML
        # and pointed at a BrainTech file).  Fall back cleanly.
        logging.warning(
            f"electrodes_layout='{NATIVE_POSITIONS_SENTINEL}' "
            f"requested, but this signal has no native positions. "
            f"Falling back to standard_1020.")
        layout = "standard_1020"
    elif layout in ["None", None, ""]:
        layout = "standard_1020"
    try:
        signal.set_montage(layout, on_missing="warn")
    except Exception:
        raise Exception("WRONG MONTAGE: Pick montage provided by MNE (more: https://mne.tools/dev/auto_tutorials/intro/40_sensor_locations.html#sphx-glr-auto-tutorials-intro-40-sensor-locations-py).")
    config["electrodes_layout"] = layout
    logging.info(
        f"Picked electrodes layout is {config['electrodes_layout']}.")
    return signal


def _set_reference(signal, config):
    '''
    Apply an EEG reference scheme to *signal*.

    Reorderable step (Phase 1 split, 2026-04): used to live inside
    :func:`_set_montage`; now a standalone step that can be moved
    independently in ``step_order``.

    Reads ``config["re_reference"]``:

    * ``None`` / empty → no reference change (raw recording reference).
    * ``"average"`` / ``"CAR"`` → common average reference.
    * ``"REST"`` → REST (Yao 2001) infinity reference.
    * Anything else → list / comma-string of channel names; their
      mean becomes the reference and they are added to ``info["bads"]``
      so subsequent steps (and channel filters) ignore them.
    '''
    rr = config.get("re_reference")
    if rr in (None, "", [], "None"):
        logging.info("Re-reference: keeping raw signal reference.")
        return signal

    signal = signal.copy()
    # set_eeg_reference (any path) writes channel data in place.
    signal.load_data()

    if rr in ("average", "mean", "all", "CAR", "car"):
        logging.info("Re-reference: Common Average Reference (CAR).")
        return signal.set_eeg_reference(ref_channels="average")

    if rr in ("REST", "rest", "infinity"):
        logging.info("Re-reference: REST (Reference Electrode "
                     "Standardization Technique, infinity reference).")
        # MNE's set_eeg_reference("REST") requires a precomputed
        # Forward solution.  Build one on the fly using a 4-layer
        # sphere head model — sufficient for the standard REST
        # workflow (Yao 2001 was derived against a sphere model).
        # Wrap in a try/except so a missing montage surfaces as a
        # clear actionable error rather than MNE's "fit headshape
        # without digitization" / forward-is-None message stack.
        try:
            sphere = mne.make_sphere_model("auto", "auto", signal.info)
            src = mne.setup_volume_source_space(
                sphere=sphere, exclude=30.0, pos=15.0)
            fwd = mne.make_forward_solution(
                signal.info, trans=None, src=src, bem=sphere,
                meg=False, eeg=True, verbose=False)
        except Exception as e:
            raise RuntimeError(
                "REST re-reference needs electrode positions on EEG "
                "channels. Enable the Montage step before Reference, "
                "or pick a different reference (CAR / linked "
                f"mastoids / custom channels). Underlying error: {e}"
            ) from e
        return signal.set_eeg_reference("REST", forward=fwd)

    ch_ref = [ch for ch in rr if
              ch not in signal.info["bads"]
              and ch in signal.info["ch_names"]]
    if not ch_ref:
        logging.warning(
            "Re-reference: none of the requested channels (%r) match "
            "the signal — leaving the recording reference unchanged.",
            rr)
        return signal
    signal.set_eeg_reference(ref_channels=ch_ref)
    signal.info["bads"].extend(ch_ref)
    cc = config.setdefault("choosing_channels", {})
    if "bad_channels" in cc:
        cc["bad_channels"].extend(ch_ref)
    else:
        cc["bad_channels"] = list(ch_ref)
    signal.pick(picks=None, exclude="bads")
    logging.info(f"Re-reference channels: {', '.join(ch_ref)}")
    return signal


def get_segment_params(config):
    """Extract segment windowing params from the active mode's config section.

    Parameters
    ----------
    config : dict
        Dictionary of configuration variables.

    Returns
    -------
    params : dict
        Keys: tmin, tmax, baseline, check, mode, reject_dict, flat_dict.
    """
    mode = get_segmentation_mode(config)
    if mode == "rest":
        section = config["rest"]
        reject_raw = section.get("reject_dict")
        flat_raw = section.get("flat_dict")
        return dict(
            tmin=0,
            tmax=section["window_length"],
            baseline=None,
            check=section.get("check_rest", True),
            mode="rest",
            reject_dict=None if reject_raw in ["None", None, "", {}, []] else reject_raw,
            flat_dict=None if flat_raw in ["None", None, "", {}, []] else flat_raw,
        )
    else:
        section = config["epochs"]
        baseline = section.get("epochs_baseline")
        if isinstance(baseline, str) and baseline.lower() in ("none", ""):
            baseline = None
        elif isinstance(baseline, list):
            baseline = tuple(
                None if (isinstance(i, str) and i.lower() in ("none", ""))
                else float(i) if isinstance(i, str) else i
                for i in baseline)
        reject_raw = section.get("reject_dict")
        flat_raw = section.get("flat_dict")
        return dict(
            tmin=section["start_offset"],
            tmax=section["stop_offset"],
            baseline=baseline,
            check=section.get("check_epochs", True),
            mode="epochs",
            reject_dict=None if reject_raw in ["None", None, "", {}, []] else reject_raw,
            flat_dict=None if flat_raw in ["None", None, "", {}, []] else flat_raw,
        )


#: Integer event ID used by :func:`get_segment_events` for rest-window
#: onsets.  Maps the symbolic ``REST`` annotation description to a
#: stable integer code so downstream Epochs / events arrays can use it.
REST_EVENT_ID = 1

#: Annotation description used by :func:`_add_rest_markers` for synthetic
#: rest-window onsets.  :func:`get_segment_events` looks for this string
#: in ``signal.annotations.description`` to recover events in rest mode.
REST_ANNOT = "REST"

#: Legacy name of the synthetic STIM channel that older versions used
#: (before 2026-04) to encode rest-window onsets.  Annotations replaced
#: it (no preload required for ``set_annotations``), but the constant is
#: kept so :func:`get_segment_events` can fall back to reading old saved
#: snapshots that still carry a STIM_rest channel.
STIM_REST_CHANNEL = "STIM_rest"


def _build_event_dict(config, events_desc_id):
    """Build the ``tags_desc_id`` event mapping from config.

    Pure function — does not touch a signal.  Separates the "what event
    names am I interested in?" decision (config-driven) from the "where
    in the signal are the synthetic markers?" decision (signal-driven,
    done by :func:`_add_rest_markers`).

    **Rest mode** returns ``{"rest": REST_EVENT_ID}``.  The event
    positions are attached as ``REST`` annotations by
    :func:`_add_rest_markers`; ``_cut_segments`` reads them via
    :func:`get_segment_events` when ``segmentation.mode == "rest"``.

    **Event-locked mode** filters *events_desc_id* down to the events
    the user selected in the GUI, or resolves the legacy ``AUTO`` /
    manual tag-group formats.  Raises :class:`ValueError` when the file
    has no events, or when no selection matches.  Three tag config
    formats are supported:

    * **GUI "selected" format** (preferred): flat list of event names →
      ``{"pic_face": 1, "beep": 2}``
    * **Legacy AUTO**: discovers target / nontarget by substring →
      ``{"target/pic_face": 1, "nontarget/beep": 2}``
    * **Legacy manual**: user-defined tag groups in TOML →
      ``{"visual/pic_face": 1, "auditory/beep": 2}``

    Parameters
    ----------
    config : dict
        Configuration variables (TOML contents).
    events_desc_id : dict
        ``{name: int_id}`` mapping from the file reader.

    Returns
    -------
    dict
        ``tags_desc_id`` consumed by ``_cut_segments`` and downstream
        analyses.
    """
    mode = get_segmentation_mode(config)

    if mode == "rest":
        return {"rest": REST_EVENT_ID}

    if mode != "epochs":
        raise ValueError(
            "Set segmentation.mode to 'rest' or 'epochs'.")

    # ── Event-locked mode ───────────────────────────────────────────
    if not events_desc_id:
        raise ValueError(
            "Event-locked analysis requires event markers, but the "
            "input file contains no events. Use timed-windows mode "
            "for continuous recordings without event marks.")

    epoch_tags = config.get("epochs", {}).get("tags", {})
    tags_desc_id = {}

    # New format: flat list of selected event names (from GUI)
    if "selected" in epoch_tags:
        selected = epoch_tags["selected"]
        if not selected:
            raise ValueError(
                "No events selected for epoch analysis. "
                "Check at least one event in the event list.")
        for event_name in selected:
            if event_name in events_desc_id:
                tags_desc_id[event_name] = events_desc_id[event_name]
            else:
                logging.warning(
                    "Selected event '%s': not in file. "
                    "Available: %s",
                    event_name, list(events_desc_id.keys()))

    # Legacy AUTO: discover target / nontarget from event names
    elif epoch_tags.get("AUTO", False):
        epoch_tags = {"target": [], "nontarget": []}
        for event in events_desc_id:
            if "nontarget" in event:
                epoch_tags["nontarget"].append(event)
            elif "target" in event:
                epoch_tags["target"].append(event)
        if not epoch_tags["target"]:
            raise ValueError(
                "AUTO tag detection found no events matching 'target'. "
                "Define tags manually in the config.")
        if not epoch_tags["nontarget"]:
            raise ValueError(
                "AUTO tag detection found no events matching 'nontarget'. "
                "Define tags manually in the config.")
        config["epochs"]["tags"] = epoch_tags
        # Build hierarchical event_id from AUTO-discovered tags
        for tag_group, event_list in epoch_tags.items():
            for event_name in event_list:
                if event_name in events_desc_id:
                    tags_desc_id[f"{tag_group}/{event_name}"] = (
                        events_desc_id[event_name])

    else:
        # Legacy manual format: {"target": ["ev1", "ev2"], ...}
        epoch_tags.pop("AUTO", None)
        for tag_group, event_list in epoch_tags.items():
            if isinstance(event_list, str):
                event_list = [event_list]
            for event_name in event_list:
                if event_name in events_desc_id:
                    eid = events_desc_id[event_name]
                    tags_desc_id[f"{tag_group}/{event_name}"] = eid
                else:
                    logging.warning(
                        "Tag '%s/%s': no matching event in file. "
                        "Available events: %s",
                        tag_group, event_name,
                        list(events_desc_id.keys()))

    if not tags_desc_id:
        raise ValueError(
            f"No events matched the configured tags. "
            f"File events: {list(events_desc_id.keys())}. "
            f"Config tags: {dict(epoch_tags)}.")

    return tags_desc_id


def _append_annotations(signal, rel_onsets, durations, descriptions):
    """Append annotations to *signal* using cropped-signal-relative onsets.

    Encapsulates the ``orig_time`` / ``first_time`` shift so callers
    don't have to re-derive it: when ``signal.annotations.orig_time``
    is set (typical — MNE copies it from ``meas_date``), MNE
    interprets onsets as absolute timestamps, so a cropped signal
    needs ``signal.first_time`` added.  When ``orig_time`` is None,
    onsets are already first-samp-relative.

    Mutates ``signal.annotations`` in place via ``set_annotations``.
    """
    rel_onsets = np.asarray(rel_onsets, dtype=float)
    durations = np.asarray(durations, dtype=float)
    if rel_onsets.size == 0:
        return
    existing = signal.annotations
    onsets = (rel_onsets + signal.first_time
              if existing.orig_time is not None
              else rel_onsets)
    new = mne.Annotations(
        onset=onsets, duration=durations,
        description=list(descriptions),
        orig_time=existing.orig_time)
    signal.set_annotations(existing + new)


def _add_rest_markers(signal, config):
    """Annotate the signal with synthetic ``REST`` window onsets.

    Called by the pipeline preamble **after** :func:`_trim_signal` when
    ``segmentation.mode == "rest"``.  Because trim runs first,
    ``config["rest"]["rest_duration"]`` is interpreted in the **trimmed**
    signal's coordinate system (t=0 = start of the trimmed signal).

    The function is strictly **additive**: it appends ``REST``
    annotations to ``signal.annotations`` and leaves channel data
    untouched (in particular, the ``STIM`` channel is preserved
    bit-for-bit).  Annotations don't require ``signal.load_data()``,
    so the preamble stays lazy end-to-end — a major win on long
    recordings (a multi-hour 32-channel signal would otherwise need
    several gigabytes resident before the first reorderable step).

    ``_cut_segments`` and the MP / artifacts consumers use
    :func:`get_segment_events` to obtain the event array; in rest mode
    that helper calls :func:`mne.events_from_annotations` against these
    REST annotations.

    Parameters
    ----------
    signal : mne.io.Raw
        Trimmed signal with an existing ``STIM`` channel (guaranteed by
        the file readers in :mod:`ide4eeg.input.input`).  May be lazy.
    config : dict
        Configuration variables.  ``config["rest"]["window_length"]``
        and ``config["rest"]["whole_signal"]`` may be overwritten with
        clamped values when the user's request exceeds the trimmed
        signal length.

    Returns
    -------
    mne.io.Raw
        The input signal with REST annotations appended.
    """
    sfreq = signal.info["sfreq"]
    n_samples = signal.n_times
    signal_duration = signal.times[-1] if n_samples > 1 else 0.0

    rd_start = float(config["rest"]["rest_duration"][0] or 0)
    rd_end = config["rest"]["rest_duration"][1]
    if rd_end == "" or rd_end is None:
        rd_end = signal_duration
    rd_end = float(rd_end)

    rd_start = max(0.0, min(rd_start, signal_duration))
    rd_end = max(rd_start, min(rd_end, signal_duration))

    start_n = int(round(rd_start * sfreq))
    stop_n = int(round(rd_end * sfreq))

    wl = config["rest"]["window_length"]
    whole = config["rest"].get("whole_signal", not wl)
    if whole or not wl:
        wl = (stop_n - start_n - 1) / sfreq if sfreq else 0.0
        config["rest"]["window_length"] = wl
    window_n = int(round(wl * sfreq))

    available_n = stop_n - start_n
    if 0 < available_n < window_n:
        orig_wl = wl
        window_n = max(1, available_n - 1)
        wl = window_n / sfreq
        config["rest"]["window_length"] = wl
        logging.info(
            "Rest window_length (%.1fs) exceeds signal (%.1fs). "
            "Adjusted to %.2fs.", orig_wl, available_n / sfreq, wl)

    n_windows = (stop_n - start_n) // window_n if window_n > 0 else 0
    if n_windows > 0:
        positions = start_n + np.arange(n_windows) * window_n
        # Strip any pre-existing REST annotations before appending —
        # makes the step idempotent under the truncated-pipeline path
        # where the same signal may be re-annotated.
        existing = signal.annotations
        keep = [i for i, d in enumerate(existing.description)
                if d != REST_ANNOT]
        signal.set_annotations(
            existing[keep] if keep
            else mne.Annotations([], [], [], orig_time=existing.orig_time))
        rel_onsets = positions / sfreq
        _append_annotations(
            signal, rel_onsets,
            np.zeros_like(rel_onsets),
            [REST_ANNOT] * len(rel_onsets))

    logging.info(
        "Timed windows: %d rest segments of %.1f s annotated as "
        "%r (STIM channel unchanged).", n_windows, wl, REST_ANNOT)
    return signal


def _trim_signal(signal, config):
    """Crop signal to [trim_start, trim_end]. Mode-agnostic.

    Parameters
    ----------
    signal : mne.io.array.array.RawArray
        Signal in mne Raw format.
    config : dict
        Dictionary of configuration variables.

    Returns
    -------
    signal : mne.io.array.array.RawArray
        Cropped signal.
    config : dict
        Updated config with ``_trim_start`` and ``_trim_end`` metadata.
    """
    trim_start = float(config.get("trim_start", 0.0) or 0.0)
    trim_end = config.get("trim_end", None)
    if trim_end in ("", "None"):
        trim_end = None

    # Backward compat: resolve ignore_before → trim_start
    ignore_before = float(config.get("ignore_before", 0.0) or 0.0)
    if ignore_before > 0 and trim_start == 0.0:
        trim_start = ignore_before

    # Backward compat: resolve ignore_after → trim_end
    ignore_after = float(config.get("ignore_after", 0.0) or 0.0)
    if ignore_after > 0 and trim_end is None:
        trim_end = signal.times[-1] - ignore_after

    # Clamp to signal bounds
    sig_end = signal.times[-1]
    trim_start = max(0.0, min(trim_start, sig_end))
    if trim_end is not None:
        trim_end = float(trim_end)
    if trim_end is None or trim_end > sig_end:
        trim_end = sig_end
    trim_end = max(trim_start, trim_end)

    if trim_start > 0 or trim_end < sig_end:
        logging.info(
            f"Trimming signal to [{trim_start:.2f}, {trim_end:.2f}] s "
            f"(original: [0, {sig_end:.2f}] s).")
        signal = signal.copy().crop(tmin=trim_start, tmax=trim_end)

    config["_trim_start"] = trim_start
    config["_trim_end"] = trim_end
    return signal, config

def channel_correlation(signal, path, file_name, config):
    """Find bad channels via inter-channel correlation analysis."""

    signal = signal.copy()
    from ide4eeg.utils.parallel import resolve_n_jobs
    _ncorr_n_jobs = resolve_n_jobs(config)
    # filter + pick are in-place; after this chain `signal` itself is
    # the filtered EEG-only Raw, so the channel name list is just
    # `signal.info["ch_names"]` — the previous `signal.pick(picks="eeg")
    # .info["ch_names"]` was a redundant second pick.
    numpy_signal_eeg = signal.filter(
        l_freq=config["amplitude_l_freq"],
        h_freq=config["amplitude_h_freq"],
        n_jobs=_ncorr_n_jobs,
    ).pick(picks="eeg").get_data()  # searching for bad segments in 1-40 Hz in EEG

    channels_names = signal.info["ch_names"]

    if len(channels_names) < 2:
        logging.warning("Correlation-based detection skipped: need at least 2 EEG channels.")
        return []

    correlation_window = np.sort(config["choosing_channels"]["correlation_window"])  # thresholds for correlation like [0.6, 0.9]

    corr = np.corrcoef(numpy_signal_eeg)  # correlation matrix between signals
    corr_abs = np.abs(corr)  # absolute value of correlation
    corr_abs[np.diag_indices_from(corr_abs)] = np.nan  # exclude diagonal from bad-channel search

    corr_bad_x, corr_bad_y = np.nonzero(np.logical_or(corr_abs <= correlation_window[0], corr_abs >= correlation_window[1])) # bad channels

    corr_count = np.bincount(corr_bad_x, minlength=len(channels_names))
    correlation_badch_threshold = config["choosing_channels"]["correlation_badch_threshold"] * len(channels_names)
    bad_channels = [channels_names[i] for i in np.where(corr_count >= correlation_badch_threshold)[0]]

    corr[np.triu_indices_from(corr)] = None  # deleting upper triangle of correlation matrix for aesthetic purposes
    corr_abs[np.triu_indices_from(corr_abs)] = None  # deleting upper triangle of absolute correlation matrix for red dots coordinates
    corr_bad_y, corr_bad_x = np.nonzero(np.logical_or(corr_abs <= correlation_window[0], corr_abs >= correlation_window[1]))  # red dots coordinates

    plot_correlation_matrix(corr, corr_bad_x, corr_bad_y, channels_names, bad_channels, correlation_window, path, file_name) # plot correlation
    return bad_channels

def Power(channel_signal, width, band, Fs):
    '''
    Marian Dovgialo 2019 from helper_functions/helper_functions.py

    Finding the estimated power of signal s in the defined frequency band.

    Parameters
    ----------
    channel_signal: list
        List of the potentials from one channel from the signal.
    width: int
        The duration of the window (not in time, it the points).
    band: list
        Two-element list with the beginning and end of the frequency band.
    Fs: float
        Frequency sampling of the signal s.

    Returns
    -------
    ps: list
        List of the estimated power for frequencies from band [freq[a], freq[b]].
    freq[a]: float
         The beginning of the frequency band of the estimated power.
    freq[b]: float
         The end of the frequency band of the estimated power.
    '''

    ps = []
    freq = np.fft.rfftfreq(width, 1. / Fs)
    a = np.argmin(np.abs(band[0] - freq))
    b = np.argmin(np.abs(band[1] - freq))
    if a == b:
        logging.warning("In this range {} is only one frequency {}".format(band, freq[a]))

    window = ss.windows.hann(width)
    for i in range(0, channel_signal.size // width * width, width):
        f = np.fft.rfft(window * channel_signal[i:i + width], norm="ortho")
        p = np.mean(np.abs(f[a:b + 1]) ** 2)
        ps.append(p)

    ps = np.array(ps)
    return ps, (freq[a], freq[b])


def BandPower(signal, width=2., band=None, thrs_type="-", thrs=None, path="\\", file_name="signal"):
    """
    Marian Dovgialo 2019 from https://gitlab.com/BudzikFUW/budzik-analiza-py-3.git helper_functions/helper_functions.py

    Function will cut windows from signal and estimated power for specified frequency band for every channel. After this
    it will find how many points crossed thresholds (sum of number of points which crossed thrs[1] and doubled number of
    points which crossed thrs[2]). If number of this points are higher than 20% of all points, channel will be classified
    as "bad". In the next step function will find automatic threshold which depends on number of points which crossed
    thrs for all channels. Finally, when number of points which crossed thrs for specific channel is greater than
    automatic threshold, then this channel will be classified as "bad" (if it wasn't classified in the first time).

    The function will draw estimated power for windows with thresholds too. The color of hotizontal lines are:
        * green -> thrs[0]
        * yellow -> thrs[1]
        * red -> thrs[2]
    The face color of the plot will be:
        * green -> all points are below/above thrs[0]
        * white -> number of points, that crossed thresholds, is smaller than 10%
        * yellow -> number of points, that crossed thresholds, is between 10% and 20%
        * red -> number of points, that crossed thresholds, is greater than 20%
        * orange -> number of points, that crossed thresholds, is greater than the automated threshold

    Parameters
    ----------
    signal: mne.io.array.array.RawArray
        Signal in mne Raw format.
    width: float
        Function will cut windows from signal with this width (in seconds) and calculate spectral density for them.
    band: list
        List with two floats/integers representing frequency band for the noise.
    thrs_type: str
        Funtion check two possible types:
            "+" -> power above thrs will be classified as "good" (the more points above thrs[0], the better)
            "-" -> power below thrs will be classified as "good" (the more points below thrs[0], the better)
    thrs: list
        List with three floats/integers (in μV^2) for thresholds to calculate which channel has too much noise. So if
        thrs_type is:
            "+" -> then thrs[0] > thrs[1] > thrs[2]
            "-" -> then thrs[0] < thrs[1] < thrs[2]
    path: str
        Path to the output directory.
    file_name: str
        Name of the file with raw signal.

    Returns
    -------
    Pgs: dict
        Estimated power from windows for channels - {"ch1": [...], "ch2": [...], ...}.
    BadChannels: list
        List of the channels which classified as "bad".
    """
    if band is None:
        band = [49.5, 50.5]
    if thrs is None:
        thrs = [1e5, 1e6, 1e7]
    thrs = np.array(thrs)
    Fs = signal.info["sfreq"]
    width = int(width * Fs) + 1
    numpy_signal_channels = signal.get_data(picks=["eeg"])
    T = np.arange(0, numpy_signal_channels.shape[1] / Fs, 1. * width / Fs)
    channels = [signal.info["ch_names"][i] for i in mne.pick_types(signal.info, eeg=True)]
    plt_facecolor = None

    A = []
    Pgs = dict()
    for ch, channel in enumerate(channels):
        c = numpy_signal_channels[ch, :]
        Pg, RealBand = Power(c, width, band, Fs)
        # MNE returns volts (SI); thresholds (and badchs_params) are
        # in µV² per the docstring contract. Convert once at the
        # boundary so plots and comparisons line up with the config.
        Pg = Pg * 1e12

        Pgs[channel] = Pg
        A.append(Pg)
    A = np.array(A)

    ymax = np.max((np.max(A), thrs[2])) * 2.
    ymin = np.min((np.min(A), thrs[0])) / 2.
    if ymax > 10 * max(thrs):
        ymax = 10 * max(thrs)

    BadScore = {}
    BadChannels = set()

    for ch, channel in enumerate(channels):
        Pg = Pgs[channel]

        if thrs_type == "-":  # below is good
            BadScore[channel] = np.sum(Pg > thrs[1]) + 2 * np.sum(Pg > thrs[2])

            if BadScore[channel] > 0.1 * Pg.size:
                plt_facecolor = (0.95, 0.95, 0.65)  # yellow
            if BadScore[channel] > 0.2 * Pg.size:
                plt_facecolor = (1.00, 0.70, 0.70)  # pink
                BadChannels.add(channel)
            if Pg.max() < thrs[0]:
                plt_facecolor = (0.80, 1.00, 0.80)  # green

        if thrs_type == "+":  # above is good
            BadScore[channel] = np.sum(Pg < thrs[1]) + 2 * np.sum(Pg < thrs[2])

            if BadScore[channel] > 0.1 * Pg.size:
                plt_facecolor = (0.95, 0.95, 0.65)  # yellow
            if BadScore[channel] > 0.2 * Pg.size:
                plt_facecolor = (1.00, 0.70, 0.70)  # pink
                BadChannels.add(channel)
            if Pg.min() > thrs[0]:
                plt_facecolor = (0.80, 1.00, 0.80)  # green


    BS_list = np.array(list(BadScore.values()))

    Thr = np.inf
    s_rel = 4
    thr = np.median(BS_list) + s_rel * np.std(BS_list[BS_list < Thr], ddof=1)
    while thr < Thr:
        Thr = thr
        thr = np.median(BS_list) + s_rel * np.std(BS_list[BS_list < Thr], ddof=1)

    # Clamp threshold to [20%, 60%] of segment count
    if Thr < 0.2 * Pg.size:
        Thr = 0.2 * Pg.size
    if Thr > 0.6 * Pg.size:
        Thr = 0.6 * Pg.size

    for channel in channels:
        plt_facecolor = None
        if BadScore[channel] > Thr:
            plt_facecolor = (1.00, 0.60, 0.40)  # orange — auto-detected bad
            BadChannels.add(channel)

        plot_BandPower(T[:Pgs[channel].size], Pgs[channel], thrs, channel, band, width/Fs, ymin, ymax, plt_facecolor, path, file_name)

    badscore_info = pd.DataFrame({"channels": channels,
                     "bad_samples [%]": [BadScore[channel]/Pgs[channel].size * 100 for channel in channels],
                     "bad_channel": ["*" if channel in BadChannels else "" for channel in channels]
                     })
    with open(os.path.join(path, f"{file_name}___{band[0]}_{band[1]}Hz_{width/Fs}s.txt"), 'a') as f:
        f.write(f"n_windows = {Pg.size}\nauto_threshold = {Thr/Pg.size}\n\n")
        f.write(badscore_info.to_string(header=True, index=False))

    return Pgs, BadChannels


def ValidateChannels_Noise(signal, width, band, thresholds_type, thresholds, path, file_name):
    '''
    Marcin Pietrzak 2017-03-01 based on Klekowicz et al. DOI 10.1007/s12021-009-9045-2 from
    https://gitlab.com/BudzikFUW/budzik-analiza-py-3.git helper_functions\artifacts_mark.py

    Function finds bad channels with calculating power in the band and classifying bad channels. From budzik-analiza
    params for checking channels for noise are:
        width = 1.0
        band = [52, 98]
        thresholds_type = "-"
        thresholds = [2e1, 2e2, 2e3]

    Parameters
    ----------
    signal: mne.io.array.array.RawArray
        Signal in mne Raw format.
    width: float
        Function will cut windows from signal with this width and calculate spectral density for them.
    band: list
        List with two floats/integers representing frequency band for the noise.
    thresholds_type: str
        "+" (power above thresholds will be classified as good) or "-" (power below thresholds will be classified as good).
    thresholds: list
        List with three floats/integers (in μV^2) for thresholds to calculate which channel has too much noise.
    path: str
        Path to the output directory.
    file_name: str
        Name of the file with raw signal.

    Returns
    -------
    bad_channels: list
        List of the channels which classified as "bad".
    '''

    _, bad_channels = BandPower(signal, width, band, thresholds_type, thresholds, path, file_name)

    return bad_channels


def _find_bad_channels(signal, config, tags_desc_id, path, file_name):
    """
    Finding bad channels with ValidateChannels_Noise function.

    Parameters
    ----------
    signal: mne.io.array.array.RawArray
        Signal in mne Raw format which is raw (without any preprocessing like filtering or montage).
    config: dict
        Dictionary of configuration variables.
    tags_desc_id: dict
        Dictionary of the names of prepared tags and their values in the new STIM signal.
    path: str
        Path to the output directory.
    file_name: str
        Name of the file with raw signal.

    Returns
    -------
    config: dict
        Dictionary of configuration variables with found bad channels.
    """

    # Detection helpers write plots to bch_path. Use the real output
    # folder (predictable location during execution) and remove it at
    # the end if the user didn't request the save.  Drawer "save"
    # controls the snapshot only; plots use "save_plots".
    save_plots = config.get("bad_channels", {}).get("save_plots", False)
    bch_path = os.path.join(path, "bad_channels_detection")
    os.makedirs(bch_path, exist_ok=True)

    try:
        signal = signal.copy()
        # Detectors below filter / FFT / correlate the EEG channels —
        # all require preloaded data.  Load once here so the detectors
        # share one in-memory copy instead of each forcing its own.
        signal.load_data()

        bad_channels = []
        if "bad_channels" not in config["choosing_channels"]:
            config["choosing_channels"]["bad_channels"] = []
        else:
            config["choosing_channels"]["bad_channels"] = [ch for ch in config["choosing_channels"]["bad_channels"] if ch in signal.info["ch_names"]]

        if config["choosing_channels"]["choose_bad_channels"] in ["auto", "both"]:

            # searching bad channels with noise
            noise_channels = []
            for badchs_method in config["choosing_channels"]["badchs_params"].keys():
                noise_channels_method = ValidateChannels_Noise(signal,
                                                        config["choosing_channels"]["badchs_params"][badchs_method][0],
                                                        config["choosing_channels"]["badchs_params"][badchs_method][1],
                                                        config["choosing_channels"]["badchs_params"][badchs_method][2],
                                                        config["choosing_channels"]["badchs_params"][badchs_method][3],
                                                        bch_path, file_name)
                noise_channels.extend(noise_channels_method)

            bad_channels.extend(noise_channels)
            logging.info(f"Channels with too much noise are: {', '.join(noise_channels)}")

            # searching bad channels with correlation
            # 2026-05-13: gate switched from "if correlation_window
            # key present" to an explicit enable_correlation bool.
            # The presence-based gate leaked when _collect_config's
            # deep-merge from self.config_data carried a stale
            # correlation_window forward across GUI sessions.  The
            # explicit boolean is robust to that pattern and aligns
            # with how every other feature toggle is gated.  See
            # check_and_prepare_config for the one-line shim that
            # auto-enables for pre-migration TOMLs.
            if config["choosing_channels"].get("enable_correlation", False):
                corr_channels = channel_correlation(signal, bch_path, file_name, config)
                bad_channels.extend(corr_channels)
                logging.info(f"Channels with bad correlation: {', '.join(corr_channels)}")
            else:
                logging.info("Correlation-based detection disabled.")

            if len(bad_channels) > 0:
                bad_channels = list(set(bad_channels))
                config["choosing_channels"]["bad_channels"].extend(bad_channels)

        if config["choosing_channels"]["choose_bad_channels"] in ["manually", "manual", "both"]:
            # Apply a visualization-only common-average reference for
            # the review window when the user hasn't configured one.
            # Raw unreferenced data can look unreadable in Svarog/MNE;
            # CAR makes channel-to-channel comparison easy.  This
            # MUST be applied to a copy — the previous Cz-reference
            # implementation mutated ``signal`` in place, which made
            # Cz look flat in the review (Cz − Cz = 0) AND leaked the
            # reference choice into downstream steps until the
            # canonical Reference step re-referenced again.
            if config["re_reference"] in ["", [], None, "None", "none"]:
                review_signal = signal.copy().set_eeg_reference(
                    "average", verbose=False)
            else:
                review_signal = signal
            review_signal.info['bads'].extend(bad_channels)
            # Preselect prior config marks so the review UI shows them
            # pre-highlighted and they survive when the user accepts
            # without changes.  Without this, the post-review copy-back
            # of review_signal.info["bads"] into config would wipe the
            # stored list.
            review_signal.info['bads'] = list(
                set(review_signal.info['bads'])
                | set(config["choosing_channels"].get("bad_channels", [])))
            scalings = dict(mag=1e-12, grad=4e-11, eeg=30e-6, eog=150e-6, ecg=5e-4, emg=1e-3, ref_meg=1e-12, misc=1e-3, stim=1, resp=1, chpi=1e-4, whitened=1e2)
            # Event overlay reads from the file's primary STIM channel
            # (real hardware / annotation events).  Synthetic
            # rest-window onsets live in REST annotations and feed
            # cut_segments, not this preview.
            primary_stim = "STIM" if "STIM" in review_signal.info["ch_names"] else None
            if primary_stim:
                overlay_events = mne.find_events(
                    review_signal, stim_channel=primary_stim,
                    shortest_event=1, verbose=False)
            else:
                overlay_events = np.empty((0, 3), dtype=int)
            # Interactive plot must run on the GUI main thread on macOS
            # (NSWindow crash otherwise). The GUI injects a hook via
            # config["_manual_hooks"]["bad_channels"]; CLI keeps the
            # direct in-process plot.
            hook = (config.get("_manual_hooks") or {}).get("bad_channels")
            if hook is not None:
                user_bads = list(hook(review_signal, overlay_events,
                                      tags_desc_id, scalings) or [])
            else:
                review_signal.plot(events=overlay_events,
                            event_id=tags_desc_id, block=True,
                            highpass=1,
                            lowpass=40, scalings=scalings)
                # MNE's plot edits review_signal.info["bads"] in place
                # — its final state IS the user's reviewed list.
                user_bads = list(review_signal.info["bads"])
            # Stim-type channels can never be marked bad.
            stim_chs = set(_stim_channel_names(signal.info))
            user_bads = [b for b in user_bads if b not in stim_chs]
            # User's review is authoritative — replace, don't union
            # with the auto-detected list.  Without this, un-marks in
            # Svarog/MNE silently drop because the auto-detected
            # name is already in signal.info["bads"] / bad_channels.
            # Copy the result back onto the real signal — review_signal
            # was a CAR-referenced copy used only for visualization.
            signal.info["bads"] = list(user_bads)
            config["choosing_channels"]["bad_channels"] = list(user_bads)

        stim_chs = _stim_channel_names(signal.info)
        config["choosing_channels"]["bad_channels"] = [
            ch for ch in config["choosing_channels"]["bad_channels"]
            if ch not in stim_chs]

        logging.info(f"Final bad channels are: {', '.join(config['choosing_channels']['bad_channels'])}.")
    finally:
        # Remove plots folder if user didn't request save (runs even on error)
        if not save_plots:
            shutil.rmtree(bch_path, ignore_errors=True)

    return config

def _filter_signal(signal, config, path):
    """Filter the signal using IIR or FIR filters.

    Filter cutoffs are specified in Hz via ``config["filters"]``:

    - ``highpass_freq`` — highpass cutoff in Hz (0 = off)
    - ``lowpass_freq``  — lowpass cutoff in Hz (0 = off)
    - ``notch_freq``    — notch center frequency in Hz (0 = off)
    - ``method``        — ``"iir"`` (default) or ``"fir"`` (MNE)

    IIR filters use ``scipy.signal.iirdesign`` with SOS output for
    numerical stability, applied zero-phase via ``sosfiltfilt``.
    Transition bandwidths are computed automatically from the cutoffs.
    Note that the forward+backward pass squares the magnitude response
    (a -3 dB design becomes -6 dB at cutoff) and doubles the effective
    filter order; filter-response plots show the single-pass design.

    FIR filters delegate to ``mne.filter.filter_data`` with automatic
    filter length and transition bandwidth.

    Parameters
    ----------
    signal : mne.io.Raw
        Signal in MNE Raw format.
    config : dict
        Configuration with ``filters`` sub-dict.
    path : str
        Output directory (for filter response plots).

    Returns
    -------
    signal : mne.io.Raw
        Filtered signal.
    """
    filt = config["filters"]
    method = filt.get("method", "iir").lower()
    show = filt.get("show_filt", False)
    save = filt.get("plot_filt", False)

    if save and not os.path.isdir(os.path.join(path, "filters_plot")):
        os.makedirs(os.path.join(path, "filters_plot"), exist_ok=True)

    signal = signal.copy()
    sfreq = signal.info["sfreq"]

    hp_freq = float(filt.get("highpass_freq", 0))
    lp_freq = float(filt.get("lowpass_freq", 0))
    notch_freq = float(filt.get("notch_freq", 0))

    if method == "fir":
        # --- FIR path: delegate to MNE ---
        # MNE's Raw.filter modifies data in place; the IIR path below
        # has its own load_data(), but the FIR path must do its own
        # too or it raises on lazy raws.
        signal.load_data()
        from ide4eeg.utils.parallel import (
            resolve_n_jobs, timed_parallel_block)
        n_jobs = resolve_n_jobs(config)
        cancel_event = config.get("_cancel_event")
        l_freq = hp_freq if hp_freq > 0 else None
        h_freq = lp_freq if lp_freq > 0 else None
        if l_freq is not None or h_freq is not None:
            with timed_parallel_block("FIR filter", cancel_event):
                signal.filter(l_freq, h_freq, method="fir",
                              fir_design="firwin", phase="zero",
                              n_jobs=n_jobs, verbose=False)
            logging.info("FIR filter: HP=%s LP=%s Hz",
                         l_freq or "off", h_freq or "off")
        if notch_freq > 0:
            with timed_parallel_block("FIR notch", cancel_event):
                signal.notch_filter(notch_freq, method="fir",
                                    n_jobs=n_jobs, verbose=False)
            logging.info("FIR notch: %.0f Hz", notch_freq)
        return signal

    # --- IIR path: design + sosfiltfilt channel-by-channel in-place ---
    # Filtering the entire (n_eeg, n_samples) array at once requires ~3x
    # the array size in RAM (original + sosfiltfilt internal copy + result).
    # For long recordings (e.g. 9 h PSG at 500 Hz = 17 M samples, 21 ch)
    # this exceeds available memory.  Instead we filter one channel at a
    # time on the Raw object's own data buffer — peak overhead is just one
    # 1-D array of n_samples per worker.  Channels are parallelized across
    # threads: sosfiltfilt releases the GIL and each thread writes to a
    # disjoint row of ``data``, so threading is safe and skips the
    # per-worker pickling cost of process backends.
    signal.load_data()
    data = signal._data  # (n_channels, n_samples) — mutable view
    ch_types = signal.get_channel_types()
    eeg_idx = [i for i, t in enumerate(ch_types) if t == "eeg"]

    applied = []
    filters = []  # list of (sos, label, info_update_key, info_update_val)

    # Highpass
    if hp_freq > 0:
        sos, info = design_iir_filter("highpass", hp_freq, sfreq)
        if sos is not None:
            filters.append((sos, f"HP {hp_freq} Hz (order {info['order']})",
                            "highpass", hp_freq))
            _plot_filter_response(sos, sfreq, f"highpass_{hp_freq}Hz",
                                  path, show, save)

    # Lowpass
    if lp_freq > 0:
        sos, info = design_iir_filter("lowpass", lp_freq, sfreq)
        if sos is not None:
            filters.append((sos, f"LP {lp_freq} Hz (order {info['order']})",
                            "lowpass", lp_freq))
            _plot_filter_response(sos, sfreq, f"lowpass_{lp_freq}Hz",
                                  path, show, save)

    # Notch
    if notch_freq > 0:
        sos, info = design_iir_filter("notch", notch_freq, sfreq)
        if sos is not None:
            filters.append((sos,
                            f"Notch {notch_freq} Hz (order {info['order']})",
                            None, None))
            _plot_filter_response(sos, sfreq, f"notch_{notch_freq}Hz",
                                  path, show, save)

    # Apply each filter channel-by-channel in-place
    from ide4eeg.utils.parallel import (
        resolve_n_jobs, timed_parallel_block)
    from joblib import Parallel, delayed
    n_jobs = resolve_n_jobs(config)
    cancel_event = config.get("_cancel_event")

    def _sosfiltfilt_inplace(row_idx, sos_mat):
        data[row_idx] = ss.sosfiltfilt(sos_mat, data[row_idx])

    for sos, label, info_key, info_val in filters:
        with timed_parallel_block(f"IIR filter ({label})", cancel_event):
            # return_as="generator" avoids materialising a results list;
            # workers write in place and yield None per channel.
            for _ in Parallel(
                n_jobs=n_jobs, backend="threading", return_as="generator"
            )(delayed(_sosfiltfilt_inplace)(i, sos) for i in eeg_idx):
                pass
        if info_key is not None:
            signal.info._unlocked = True
            signal.info[info_key] = info_val
        applied.append(label)

    if applied:
        logging.info("IIR filters applied (SOS, zero-phase): %s",
                     ", ".join(applied))
    else:
        logging.info("No filters applied.")

    return signal


def _plot_filter_response(sos, sfreq, name, path, show, save):
    """Show/save filter frequency response via mne.viz.plot_filter."""
    if not show and not save:
        return
    try:
        fig = mne.viz.plot_filter(
            dict(sos=sos), sfreq, show=show, title=name)
        if save:
            fig.set_dpi(200)
            fig.savefig(os.path.join(path, "filters_plot", name + ".png"))
        plt.close(fig)
    except Exception as e:
        logging.warning("Could not plot filter %s: %s", name, e)

