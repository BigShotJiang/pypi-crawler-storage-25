"""Gaze estimation from InsightFace 5-point landmarks.

Uses the keypoints that InsightFace already computes during face
detection (left eye, right eye, nose tip, left mouth, right mouth)
to compute a nose-to-eyes gaze vector.  No additional model or
dependency is required.

Limitations compared to L2CS-Net:

- Only 5 landmarks — less precise for head pose.
- 2D keypoints only — the 3D vector is approximated by projecting
  the 2D displacement onto a unit sphere.
- No blink detection — ``eyes_closed`` is always False.
- No temporal smoothing — may have more frame-to-frame jitter.
- Best suited for near-frontal faces.
"""

try:
    import cv2
except ImportError:
    cv2 = None
import numpy as np


_VIDEO_STACK_HINT = (
    "Facetag features require the video stack — install via "
    "`pip install ide4eeg[video]` or use the full .exe variant.")


def _extract_vector_from_kps(kps, img_shape):
    """Compute a nose-to-eyes unit vector from InsightFace 5-point keypoints.

    Parameters
    ----------
    kps : numpy.ndarray
        Shape ``(5, 2)`` — left eye, right eye, nose tip, left mouth,
        right mouth — in pixel coordinates.
    img_shape : tuple
        ``(height, width, ...)`` of the source image.

    Returns
    -------
    numpy.ndarray or None
        3-element unit vector ``[x, y, z]``, or None if landmarks are
        degenerate (collapsed eyes, extreme angle).
    """
    eye_centre = (kps[0] + kps[1]) / 2.0
    displacement = eye_centre - kps[2]  # nose → eyes, in pixels

    # Normalise by inter-eye distance (face-intrinsic scale)
    inter_eye_dist = np.linalg.norm(kps[1] - kps[0])
    if inter_eye_dist < 1.0:
        return None  # degenerate detection

    nx = displacement[0] / inter_eye_dist
    ny = displacement[1] / inter_eye_dist

    # Project 2D to 3D unit sphere
    r2 = nx * nx + ny * ny
    if r2 >= 1.0:
        return None  # extreme angle, unreliable
    nz = np.sqrt(1.0 - r2)

    vec = np.array([nx, ny, nz])
    return vec / np.linalg.norm(vec)


def _detect_and_get_kps(img):
    """Run InsightFace on a BGR image, return (kps, img_shape) or (None, None).

    Handles tightly-cropped images by padding and retrying.
    """
    if cv2 is None:
        raise ImportError(_VIDEO_STACK_HINT)
    from . import insightface_backend

    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    faces = insightface_backend._analyze(rgb)

    if not faces:
        # Pad and retry (matches encode_faces pattern)
        h, w = img.shape[:2]
        pad = max(h, w) // 3
        padded_rgb = cv2.copyMakeBorder(
            rgb, pad, pad, pad, pad,
            cv2.BORDER_CONSTANT, value=(128, 128, 128))
        insightface_backend._last_result = None
        faces = insightface_backend._analyze(padded_rgb)
        if not faces:
            return None, None
        return faces[0].kps, padded_rgb.shape

    return faces[0].kps, img.shape


# ---- Public API (same interface as l2cs_gaze.py) -------------------------

def nose_eyes_vector(img):
    """Return a unit vector from nose to eye-centre, or None.

    Parameters
    ----------
    img : numpy.ndarray
        BGR image.

    Returns
    -------
    numpy.ndarray or None
        3-element unit vector, or None if no face detected.
    """
    kps, shape = _detect_and_get_kps(img)
    if kps is None:
        return None
    return _extract_vector_from_kps(kps, shape)


def analyze_gaze(img, timestamp_ms=0):
    """Analyse gaze in a video frame.

    Parameters
    ----------
    img : numpy.ndarray
        BGR image.
    timestamp_ms : int
        Ignored (API compatibility).

    Returns
    -------
    vector : numpy.ndarray or None
        Nose-to-eyes unit vector, or None if no face detected.
    eyes_closed : bool
        Always False (InsightFace has no blink detection).
    """
    kps, shape = _detect_and_get_kps(img)
    if kps is None:
        return None, False
    return _extract_vector_from_kps(kps, shape), False


def reset_video_state():
    """No-op — InsightFace has no temporal state to reset."""
    pass
