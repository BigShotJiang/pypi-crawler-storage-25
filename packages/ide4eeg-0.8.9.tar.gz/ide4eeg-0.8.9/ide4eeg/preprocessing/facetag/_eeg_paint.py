"""Shared EEG-canvas painting code for the trim and gaze-review widgets.

Both ``trim_window_qt.py`` and ``review_window_qt.py`` paint stacked
EEG channels with the same theme-aware palette, label gutter and
~N-second paged window.  Centralising the canvas + palette here
prevents the two surfaces from drifting (e.g. one widget gaining a
single-color trace while the other stays on the rainbow palette).

Module is private (``_eeg_paint``) — only the two facetag windows
should import from it.
"""
from typing import Optional

import numpy as np

from PySide6.QtCore import Qt, QRectF, Signal
from PySide6.QtGui import (QColor, QFont, QFontMetrics, QMouseEvent,
                            QPainter, QPainterPath, QPen)
from PySide6.QtWidgets import QApplication, QSizePolicy, QWidget


# Two palettes; the active one is chosen per-paint from the
# ``QApplication.palette().window()`` lightness so widgets track the
# app-level theme switch in ``gui.py::_set_theme``.  Trim accents
# (TRIM_FILL / TRIM_BD) stay constant in both modes — the contrast
# pops on either background.
PALETTE_DARK = {
    "bg":     "#1e1e2e",
    "trace":  "#ffffff",
    "cursor": "#ffffff",
    "tick":   "#6c7086",
    "label":  "#f9e2af",   # Catppuccin yellow — pops vs white traces
}
PALETTE_LIGHT = {
    "bg":     "#ffffff",
    "trace":  "#000000",
    "cursor": "#000000",
    "tick":   "#888888",
    "label":  "#1e6091",   # navy — pops vs black traces
}

#: Pink shading for trimmed-out regions (alpha applied at draw time).
TRIM_FILL = "#f38ba8"

#: Amber dashed line marking the trim boundary.
TRIM_BD = "#f9e2af"

#: Neutral grey for preview-strip traces — de-emphasised vs the
#: detail canvas's white/black trace, readable on both themes.
STRIP_TRACE = "#888888"


def active_palette():
    """Return the palette dict matching the current app theme.

    Reads ``QApplication.palette().window().lightness()`` so widgets
    respond both to the user's choice in ``gui.py::_set_theme`` and
    to OS-level light/dark switches when the app is in "system" mode.
    Falls back to dark when no QApplication exists (e.g. during early
    imports), matching the codebase's historical default.
    """
    app = QApplication.instance()
    if app is None:
        return PALETTE_DARK
    return PALETTE_LIGHT if app.palette().window().color().lightness() > 128 \
        else PALETTE_DARK


def fmt_time(t):
    """Format ``t`` (seconds) as ``MM:SS.ss`` for time-axis ticks."""
    m = int(t) // 60
    s = t - m * 60
    return f"{m:02d}:{s:05.2f}"


# Reserved height (px) for the annotation strip at the top of the
# canvas and the time-axis strip at the bottom.  Trace area is the
# canvas height minus these two rows.  Sized to comfortably hold
# the 10pt Menlo labels used by ``_paint_axis_strips``.
_AXIS_TOP = 18
_AXIS_BOTTOM = 22


def _sanitise_ann_desc(raw):
    """Reduce an MNE annotation description to a short readable label.

    Some pipeline steps store an event-tag block as a JSON object in
    the description (e.g.
    ``{"name": "white", "channels": "", ...}``) — rendered verbatim
    they're noise, especially when several overlap on the canvas.
    Unwrap obvious JSON to just its ``name`` field; pass through
    plain text unchanged.
    """
    if not raw:
        return ""
    s = raw.strip()
    if s.startswith("{") and s.endswith("}"):
        import json
        try:
            obj = json.loads(s)
        except (ValueError, TypeError):
            return s
        if isinstance(obj, dict):
            for key in ("name", "label", "description", "desc"):
                v = obj.get(key)
                if isinstance(v, str) and v:
                    return v
            return ""  # JSON dict but no usable name — drop label
    return s


def _elide_to_width(text, font_metrics, width_px):
    """Truncate *text* with an ellipsis so it fits in *width_px*.

    Returns the empty string when even ``"…"`` wouldn't fit, so the
    caller can skip drawing entirely instead of rendering a
    half-character glyph.
    """
    if not text:
        return ""
    if font_metrics.horizontalAdvance(text) <= width_px:
        return text
    ellipsis = "…"
    if font_metrics.horizontalAdvance(ellipsis) > width_px:
        return ""
    truncated = text
    while truncated and font_metrics.horizontalAdvance(
            truncated + ellipsis) > width_px:
        truncated = truncated[:-1]
    return (truncated + ellipsis) if truncated else ellipsis


def _axis_palette(pal):
    """Tinted variant of *pal* for the dedicated label rows.  Same
    palette spec, slightly different background so the rows are
    visually distinct from the trace area without losing theme
    cohesion.
    """
    bg = QColor(pal["bg"])
    # Pull each channel ~10% toward grey so the strip reads as
    # separate without a hard border.
    bg.setRgb(
        bg.red() + (96 - bg.red()) // 10,
        bg.green() + (96 - bg.green()) // 10,
        bg.blue() + (96 - bg.blue()) // 10,
        bg.alpha())
    return bg


def label_left_margin(font_metrics, ch_names):
    """Return a left-edge pixel offset wide enough to fit the longest
    channel label in *ch_names* — at minimum 2 ems.

    Both EEG canvases reserve this gutter so labels sit at ``x=4`` in
    the leftmost area without overlapping the trace plotting region.
    """
    em = font_metrics.horizontalAdvance("M")
    longest = max((font_metrics.horizontalAdvance(n) for n in ch_names),
                  default=0)
    return max(2 * em, longest + 4)


# ------------------------------------------------------------------
# Paged EEG canvas — shared between trim and gaze-review widgets.
# ------------------------------------------------------------------

class EegPagedCanvas(QWidget):
    """Stacked-channel EEG canvas painting one ``window_sec`` window
    at a time, centred on ``cursor_time``.

    Two loading paths:

    - :meth:`load_lazy` — keeps an MNE ``Raw`` handle and pulls one
      window at a time via ``raw.get_data(start=ss, stop=se)``.  Use
      this for files (multi-hour recordings) where keeping the entire
      signal in RAM would be wasteful or impossible.
    - :meth:`load` — store the full numpy array.  Useful for tests
      with small synthetic signals.

    Subclasses or instances override :meth:`paint_underlay` to draw
    extra background decorations (e.g. the gaze viewer's accepted /
    rejected interval shading).  The base class handles the trim
    shading + boundary lines from ``trim_start``/``trim_end`` — leave
    those at their defaults if your widget doesn't have a single crop
    region.

    Annotations (``raw.annotations`` or ``annotations=`` to ``load``)
    are painted as a single-accent overlay: vertical line at each
    onset, translucent band over each non-zero duration, description
    text near the top.
    """
    clicked = Signal(float)

    def __init__(self, parent=None, window_sec=20.0):
        super().__init__(parent)
        self.setMinimumSize(500, 250)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.window_sec = float(window_sec)
        # Lazy-mode state (raw handle + picks): the canvas fetches one
        # window at a time via `_window_data` to keep memory bounded
        # on multi-hour recordings.
        self._raw = None
        self._picks: list = []
        self._window_cache: dict = {}  # (ss, se, dc_remove) → ndarray
        # Eager-mode state — kept as a fallback for tests / in-memory.
        self.data: Optional[np.ndarray] = None
        self.sfreq, self.duration, self.cursor_time = 500.0, 0.0, 0.0
        # Absolute-time offset of the loaded data: ``raw.first_time``
        # for snapshots saved mid-pipeline (e.g. a trimmed snapshot
        # taken from samples [400 s, 460 s] of the original recording
        # has ``first_time=400.0``).  Cursors / intervals on this canvas
        # operate in the same absolute coordinate system, so the data
        # fetch subtracts ``first_time`` to map back to the snapshot's
        # local 0..duration sample axis.  Defaults to 0 for raw
        # recordings — the trim window is unaffected.
        self.first_time = 0.0
        self.ch_names: list = []
        self.trim_start = 0.0
        self.trim_end: Optional[float] = None  # None = end of signal
        self.amp_scale = 1.0
        self.dc_remove = True
        # Annotations: stored as 3 parallel arrays for cheap masking.
        self._ann_onset: Optional[np.ndarray] = None
        self._ann_duration: Optional[np.ndarray] = None
        self._ann_desc: Optional[np.ndarray] = None
        # Drag-pan state: when a left-button press starts an
        # interactive scroll, _drag_start_t records the cursor time
        # at button-down so subsequent moves can map pixel-deltas
        # onto seconds-deltas relative to the press point.
        self._drag_start_t: Optional[float] = None
        self._drag_start_x: float = 0.0
        # Whether a press should be treated as a "scroll start" vs a
        # plain "seek to this point".  We only know that once the
        # mouse moves more than a few pixels, so the press records
        # both the candidate seek-time AND the pan baseline; the
        # final decision happens in mouseMoveEvent / mouseReleaseEvent.
        self._press_t: Optional[float] = None

    # -- Loading paths -------------------------------------------------

    def load_lazy(self, raw, picks, sfreq, ch_names):
        """Lazy mode — keep the MNE Raw handle and slice on demand."""
        self._raw = raw
        self._picks = list(picks)
        self.data = None
        self.sfreq = float(sfreq)
        self.ch_names = list(ch_names)
        self.duration = (raw.n_times / self.sfreq) if raw is not None else 0.0
        self.first_time = float(raw.first_time) if raw is not None else 0.0
        self._window_cache.clear()
        self._set_annotations(getattr(raw, "annotations", None))
        self.update()

    def load(self, data, sfreq, ch_names, annotations=None):
        """Eager mode — store the full array."""
        self._raw = None
        self._picks = []
        self.data = data
        self.sfreq = float(sfreq)
        self.ch_names = list(ch_names)
        self.first_time = 0.0
        self.duration = data.shape[1] / sfreq
        self._window_cache.clear()
        self._set_annotations(annotations)
        self.update()

    def _set_annotations(self, ann):
        """Cache annotations as numpy arrays for fast visible-range masking."""
        if ann is None or len(ann) == 0:
            self._ann_onset = None
            self._ann_duration = None
            self._ann_desc = None
            return
        self._ann_onset = np.asarray(ann.onset, dtype=float)
        self._ann_duration = np.asarray(ann.duration, dtype=float)
        self._ann_desc = np.asarray(ann.description, dtype=object)

    def _apply_dc(self):
        """Invalidate cached windows when DC removal toggles."""
        self._window_cache.clear()
        self.update()

    def _window_data(self, ss, se):
        """Return the (n_picks, se-ss) sample slice for [ss, se).

        Caches the last 4 windows so back-and-forth scrolling is
        instant.  DC removal is applied per-slice when enabled — for
        a 20 s × 16-channel slice the highpass costs ~1 ms, far less
        than pre-filtering the entire recording.
        """
        if ss >= se:
            return None
        key = (ss, se, self.dc_remove)
        if key in self._window_cache:
            return self._window_cache[key]
        if self._raw is not None and self._picks:
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                data = self._raw.get_data(
                    picks=self._picks, start=ss, stop=se)
        elif self.data is not None:
            data = self.data[:, ss:se].copy()
        else:
            return None
        if self.dc_remove and data.shape[1] > 0:
            from scipy.signal import butter, sosfiltfilt
            if self.sfreq > 1.0 and data.shape[1] > int(3 * self.sfreq):
                sos = butter(2, 0.5 / (self.sfreq / 2),
                             btype="high", output="sos")
                data = sosfiltfilt(sos, data, axis=1)
            else:
                data = data - data.mean(axis=1, keepdims=True)
        self._window_cache[key] = data
        if len(self._window_cache) > 4:
            self._window_cache.pop(next(iter(self._window_cache)))
        return data

    # -- Hook -----------------------------------------------------

    def paint_underlay(self, painter, t0, t1, x_left, w, h, tx,
                       y_top=0):
        """Override to draw extra shading behind traces.

        Default: no-op.  Called after bg + trim shading, before
        traces and annotations.  ``tx`` is a callable mapping a time
        in [t0, t1] to a pixel x-coordinate respecting the label
        gutter; ``x_left`` is the left edge of the trace area;
        ``y_top`` is the y-coordinate where the trace area starts
        (above the bottom axis strip), and ``h`` is the trace area's
        height — paint within ``[y_top, y_top + h]`` so the shading
        doesn't bleed into the reserved annotation / time-axis
        strips.
        """
        return

    # -- Paint ----------------------------------------------------

    def paintEvent(self, event):  # noqa: N802
        pal = active_palette()
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(pal["bg"]))
        dur = self.duration
        if dur <= 0:
            p.setPen(QColor(pal["tick"])); p.setFont(QFont("Helvetica", 14))
            p.drawText(w // 2 - 60, h // 2, "Loading EEG..."); p.end(); return

        # Reserved strips: annotations at the top, time-axis ticks
        # at the bottom.  Channel labels live in the left gutter.
        # Trace area is whatever's left in the middle.  Larger font
        # (Menlo 10pt vs the prior 8pt) — the labels were chronically
        # unreadable when drawn on top of the traces.
        label_font = QFont("Menlo", 10)
        fm = QFontMetrics(label_font)
        x_left = label_left_margin(fm, self.ch_names)
        trace_top = _AXIS_TOP
        trace_h = max(1, h - _AXIS_TOP - _AXIS_BOTTOM)
        hw = self.window_sec / 2
        t0 = self.cursor_time - hw
        t1 = self.cursor_time + hw
        plot_w = max(1, w - x_left)

        def _tx(t):
            return x_left + (t - t0) / (t1 - t0) * plot_w \
                if t1 != t0 else x_left

        # ``trim_end=None`` means "to the end of the loaded data".
        # For snapshots with ``first_time != 0`` (e.g. trimmed pipeline
        # output starting at video time 400 s), the end-of-data is
        # ``first_time + duration``, not just ``duration`` — otherwise
        # default trim-shading covers the entire visible window.
        te = (self.trim_end if self.trim_end is not None
              else self.first_time + dur)
        # Trim shading — clipped to the trace area only so it doesn't
        # bleed into the axis strips.
        if self.trim_start > t0:
            c = QColor(TRIM_FILL); c.setAlpha(50)
            x_end = _tx(min(self.trim_start, t1))
            if x_end > x_left:
                p.fillRect(QRectF(x_left, trace_top,
                                  x_end - x_left, trace_h), c)
        if te < t1:
            c = QColor(TRIM_FILL); c.setAlpha(50)
            x_start = _tx(max(te, t0))
            if x_start < w:
                p.fillRect(QRectF(x_start, trace_top,
                                  w - x_start, trace_h), c)

        # Subclass overlays (gaze: accepted/rejected interval shading).
        # Pass trace-area dimensions so subclasses don't paint into
        # the reserved label strips.
        self.paint_underlay(p, t0, t1, x_left, w, trace_h, _tx,
                            y_top=trace_top)

        # Annotations: drawn into the reserved top strip, where the
        # description text doesn't fight the signal traces.
        self._paint_annotations(p, t0, t1, x_left, w, h, _tx, pal,
                                trace_top=trace_top, trace_h=trace_h)

        # EEG traces — fetch one window at a time.  Sample indices are
        # raw-relative (snapshots saved with non-zero first_samp need
        # the offset subtracted), but the display x-axis stays in
        # absolute coordinates so the cursor matches video time.
        if self.ch_names and (self._raw is not None or self.data is not None):
            n_total = (self._raw.n_times if self._raw is not None
                       else (self.data.shape[1] if self.data is not None else 0))
            ss = max(0, int((t0 - self.first_time) * self.sfreq))
            se = min(n_total, int((t1 - self.first_time) * self.sfreq))
            data_window = self._window_data(ss, se)
            if data_window is not None and data_window.shape[1] > 0:
                nch = data_window.shape[0]
                chh = trace_h / max(1, nch)
                n = data_window.shape[1]
                step = max(1, n // (plot_w * 2))
                sub_idx = np.arange(0, n, step)
                abs_idx = ss + sub_idx
                times = abs_idx / self.sfreq + self.first_time
                xs = x_left + (times - t0) / (t1 - t0) * plot_w
                sub = data_window[:, sub_idx]
                stds = [sub[ci].std() for ci in range(nch)]
                stds_nonzero = [s for s in stds if s > 1e-12]
                global_sd = float(np.median(stds_nonzero)) \
                    if stds_nonzero else 1.0
                for ci in range(nch):
                    yc = trace_top + chh * (ci + 0.5)
                    samp = sub[ci].copy()
                    samp -= samp.mean()
                    ys = yc - samp * (chh * 0.35 * self.amp_scale / global_sd)
                    self._draw_trace(p, xs, ys, pal["trace"])
                # Channel labels in the left gutter — vertically
                # centred on each strip, in the bigger font.  Out of
                # the trace area entirely, so high-amplitude signals
                # can't occlude them.
                p.setPen(QColor(pal["label"]))
                p.setFont(label_font)
                for ci in range(nch):
                    yc = trace_top + chh * (ci + 0.5)
                    label = (self.ch_names[ci] if ci < len(self.ch_names)
                             else f"ch{ci}")
                    p.drawText(2, int(yc + fm.ascent() / 2 - 1), label)

        # Trim boundary lines (only when in window)
        for edge in (self.trim_start, te):
            if t0 < edge < t1:
                p.setPen(QPen(QColor(TRIM_BD), 2, Qt.DashLine))
                p.drawLine(int(_tx(edge)), trace_top,
                           int(_tx(edge)), trace_top + trace_h)

        # Cursor — at window centre when cursor is inside the
        # absolute-time data range [first_time, first_time + dur].
        if (self.first_time <= self.cursor_time <= self.first_time + dur
                and t0 <= self.cursor_time <= t1):
            p.setPen(QPen(QColor(pal["cursor"]), 1, Qt.DashLine))
            p.drawLine(int(_tx(self.cursor_time)), 0,
                       int(_tx(self.cursor_time)), h)

        # Bottom axis strip — tinted background + tick lines + time
        # labels in the bigger font.  Decoupled from the trace area
        # so dense traces no longer eat the readout.
        axis_bg = _axis_palette(pal)
        p.fillRect(QRectF(0, h - _AXIS_BOTTOM, w, _AXIS_BOTTOM), axis_bg)
        # Hairline separator above the bottom axis row.
        p.setPen(QPen(QColor(pal["tick"]), 1))
        p.drawLine(0, h - _AXIS_BOTTOM, w, h - _AXIS_BOTTOM)
        p.setPen(QColor(pal["label"]))
        p.setFont(label_font)
        span = t1 - t0
        st = span / 8
        for nice in (0.1, 0.2, 0.5, 1, 2, 5, 10, 30, 60):
            if nice >= st: st = nice; break
        t = int(t0 / st) * st
        ascent = fm.ascent()
        text_y = h - _AXIS_BOTTOM + ascent + 3
        while t <= t1:
            if t >= 0:
                tx = int(_tx(t))
                # Tick mark across the trace bottom + into the axis row.
                p.setPen(QPen(QColor(pal["tick"]), 1))
                p.drawLine(tx, h - _AXIS_BOTTOM - 3,
                           tx, h - _AXIS_BOTTOM + 3)
                # Time label centred under the tick.
                p.setPen(QColor(pal["label"]))
                label = fmt_time(t)
                lw = fm.horizontalAdvance(label)
                p.drawText(tx - lw // 2, text_y, label)
            t += st
        p.end()

    def _paint_annotations(self, p, t0, t1, x_left, w, h, tx, pal,
                           trace_top=0, trace_h=None):
        """Paint annotations whose [onset, onset+duration] overlaps
        the visible window — translucent band on the trace area for
        non-zero duration, vertical tick at onset, description label
        in the reserved top strip (so the text doesn't fight the
        signal traces).

        Descriptions that look like serialised dicts (e.g. an event
        tag block written into the MNE description as JSON) are
        unwrapped to just their ``name`` field; anything still too
        long is truncated to fit the available space between
        consecutive labels.
        """
        if self._ann_onset is None or self._ann_onset.size == 0:
            return
        if trace_h is None:
            trace_h = h - trace_top
        onsets = self._ann_onset
        durs = self._ann_duration
        descs = self._ann_desc
        ends = onsets + durs
        visible = (ends >= t0) & (onsets <= t1)
        if not visible.any():
            return
        accent = QColor(pal["label"])
        span_fill = QColor(accent); span_fill.setAlpha(40)
        # Annotation label font sized to fit the top strip; tick line
        # spans both the strip and the trace area so the user can
        # tell exactly where the onset lands relative to the signal.
        ann_font = QFont("Menlo", 9)
        fm = QFontMetrics(ann_font)
        p.setFont(ann_font)
        text_y = fm.ascent() + 2
        # First pass: collect visible (x, desc) pairs so we can
        # decide which labels actually have room to render.
        items = []
        for i in np.where(visible)[0]:
            o = float(onsets[i])
            d = float(durs[i])
            desc = _sanitise_ann_desc(
                str(descs[i]) if descs is not None else "")
            x0 = max(x_left, tx(max(o, t0)))
            x1 = min(w, tx(min(o + d, t1))) if d > 0 else x0
            if d > 0 and x1 > x0:
                p.fillRect(QRectF(x0, trace_top, x1 - x0, trace_h),
                           span_fill)
            if t0 <= o <= t1:
                p.setPen(QPen(accent, 1, Qt.SolidLine))
                p.drawLine(int(x0), 0, int(x0), trace_top + trace_h)
                items.append((int(x0), desc))
        # Second pass: draw labels, suppressing any whose left edge
        # falls within a small "gutter" of the previously-drawn
        # label.  Also truncate each desc to fit the available width
        # before the next label starts.
        items.sort(key=lambda it: it[0])
        gap = fm.horizontalAdvance("M") * 2
        last_right = -10**9
        for idx, (x, desc) in enumerate(items):
            label_x = x + 2
            if label_x < last_right + gap:
                # Too close to the previous label — skip text but
                # the tick line is already drawn so the position is
                # still visible.
                continue
            next_x = items[idx + 1][0] if idx + 1 < len(items) else w
            avail = max(8, next_x - label_x - 2)
            text = _elide_to_width(desc, fm, avail)
            if not text:
                continue
            p.setPen(accent)
            p.drawText(label_x, text_y, text)
            last_right = label_x + fm.horizontalAdvance(text)

    @staticmethod
    def _draw_trace(p, xs, ys, color):
        if len(xs) < 2: return
        p.setPen(QPen(QColor(color), 1))
        path = QPainterPath(); path.moveTo(float(xs[0]), float(ys[0]))
        for i in range(1, len(xs)):
            path.lineTo(float(xs[i]), float(ys[i]))
        p.drawPath(path)

    def _x_to_time(self, x):
        """Map a pixel x coordinate to a time on the visible window.

        Returns ``None`` when *x* falls in the left label gutter.
        """
        fm = QFontMetrics(QFont("Menlo", 10))
        x_left = label_left_margin(fm, self.ch_names)
        if x < x_left:
            return None
        plot_w = max(1, self.width() - x_left)
        hw = self.window_sec / 2
        t0 = self.cursor_time - hw
        t1 = self.cursor_time + hw
        t = t0 + (x - x_left) / plot_w * (t1 - t0)
        return max(self.first_time,
                   min(t, self.first_time + self.duration))

    def mousePressEvent(self, event: QMouseEvent):  # noqa: N802
        if self.duration <= 0 or event.button() != Qt.LeftButton:
            return
        x = event.position().x()
        t = self._x_to_time(x)
        if t is None:
            return  # click in the label gutter — ignore
        # Record both the click target and the pan baseline.  The
        # mouseMoveEvent below decides between "click-to-seek" and
        # "drag-to-pan" based on whether the cursor moves >3 px.
        self._press_t = t
        self._drag_start_t = self.cursor_time
        self._drag_start_x = x

    def mouseMoveEvent(self, event: QMouseEvent):  # noqa: N802
        # Pan only after a left-press; ignore plain hover.
        if self._drag_start_t is None or self.duration <= 0:
            return
        if not (event.buttons() & Qt.LeftButton):
            return
        x = event.position().x()
        # Don't start panning until the cursor's moved enough to
        # distinguish from a plain click — keeps single-pixel jitter
        # from turning every click into a pan.
        if abs(x - self._drag_start_x) < 3:
            return
        # Pan: each pixel of horizontal movement maps to one
        # seconds-per-pixel of the visible window.  Negative because
        # dragging right should bring earlier time into view (i.e.
        # cursor_time decreases).
        fm = QFontMetrics(QFont("Menlo", 10))
        x_left = label_left_margin(fm, self.ch_names)
        plot_w = max(1, self.width() - x_left)
        sec_per_px = self.window_sec / plot_w
        new_t = self._drag_start_t - (x - self._drag_start_x) * sec_per_px
        new_t = max(self.first_time,
                    min(new_t, self.first_time + self.duration))
        # Suppress the click-to-seek that mouseReleaseEvent would
        # otherwise fire on this gesture.
        self._press_t = None
        self.clicked.emit(new_t)

    def mouseReleaseEvent(self, event: QMouseEvent):  # noqa: N802
        if event.button() != Qt.LeftButton:
            return
        # On a release without a drag, fire the click-to-seek using
        # the time recorded at press.  ``_press_t`` is None when the
        # press already turned into a pan in mouseMoveEvent above.
        if self._press_t is not None:
            self.clicked.emit(self._press_t)
        self._press_t = None
        self._drag_start_t = None

    def wheelEvent(self, event):  # noqa: N802
        """Mouse-wheel scrolling pans the time cursor.

        One notch (120 angle-delta units) ≈ 1/8th of the visible
        window — matches the natural feel of a paged-canvas scroll
        without overshooting on touchpads, which deliver many
        smaller events per swipe.
        """
        if self.duration <= 0:
            return
        delta = event.angleDelta().y()
        if delta == 0:
            return
        step = self.window_sec * (delta / 120.0) / 8.0
        new_t = self.cursor_time - step
        new_t = max(self.first_time,
                    min(new_t, self.first_time + self.duration))
        self.clicked.emit(new_t)
        event.accept()
