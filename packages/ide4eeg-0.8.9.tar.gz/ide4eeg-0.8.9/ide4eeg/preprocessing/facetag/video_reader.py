"""Video reader with cv2 -> imageio -> PyAV fallback.

Provides both random-access seeking (for the frame picker) and efficient
sequential iteration (for the processing pipeline).
"""
# Author: Piotr Durka, 2026

import contextlib
import os
import sys


@contextlib.contextmanager
def _suppress_stderr():
    """Temporarily suppress stderr at the file-descriptor level."""
    stderr_fd = sys.stderr.fileno()
    saved = os.dup(stderr_fd)
    devnull = os.open(os.devnull, os.O_WRONLY)
    try:
        os.dup2(devnull, stderr_fd)
        os.close(devnull)
        yield
    finally:
        os.dup2(saved, stderr_fd)
        os.close(saved)


IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".bmp")


def video_info(path):
    """Return (fps, total_frames, width, height) for a video file.

    Tries cv2, then imageio, then PyAV.  Returns ``None`` on failure.
    """
    # cv2
    try:
        import cv2
        with _suppress_stderr():
            cap = cv2.VideoCapture(path)
            if cap.isOpened():
                n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                if n > 0:
                    info = (cap.get(cv2.CAP_PROP_FPS) or 30.0, n,
                            int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                            int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
                    cap.release()
                    return info
            cap.release()
    except Exception:
        pass
    # imageio
    try:
        import imageio.v3 as iio
        props = iio.improps(path, plugin="pyav")
        n = getattr(props, "n_images", 0) or 0
        if n > 0:
            frame0 = iio.imread(path, index=0, plugin="pyav")
            h, w = frame0.shape[:2]
            fps = getattr(props, "fps", 30.0) or 30.0
            return (fps, n, w, h)
    except Exception:
        pass
    # PyAV
    try:
        import av
        container = av.open(path)
        stream = container.streams.video[0]
        fps = float(stream.average_rate)
        if stream.duration and stream.time_base:
            duration = float(stream.duration * stream.time_base)
        else:
            duration = float(container.duration / av.time_base)
        info = (fps, max(1, int(duration * fps)),
                stream.codec_context.width, stream.codec_context.height)
        container.close()
        return info
    except Exception:
        return None


class VideoReader:
    """Reads video frames using cv2 if possible, falling back to
    imageio (with bundled ffmpeg) or PyAV.

    Attributes
    ----------
    total_frames : int
    fps : float
    width : int
    height : int
    """

    def __init__(self, path):
        self._path = path
        self._backend = None
        self._cv_cap = None
        self._av_container = None
        self._av_stream = None
        self._iio_reader = None
        self.total_frames = 0
        self.fps = 0.0
        self.width = 0
        self.height = 0

        # Try cv2 first
        try:
            import cv2
            with _suppress_stderr():
                cap = cv2.VideoCapture(path)
                opened = cap.isOpened()
                if opened and int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) > 0:
                    self._backend = "cv2"
                    self._cv_cap = cap
                    self.total_frames = int(
                        cap.get(cv2.CAP_PROP_FRAME_COUNT))
                    self.fps = cap.get(cv2.CAP_PROP_FPS)
                    self.width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                    self.height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                    return
                cap.release()
        except Exception:
            pass

        # Try imageio (ships its own ffmpeg binary)
        try:
            import imageio.v3 as iio
            props = iio.improps(path, plugin="pyav")
            n = getattr(props, "n_images", 0) or 0
            if n > 0:
                frame0 = iio.imread(path, index=0, plugin="pyav")
                h, w = frame0.shape[:2]
                self._backend = "imageio"
                self.total_frames = n
                self.fps = getattr(props, "fps", 30.0) or 30.0
                self.width = w
                self.height = h
                return
        except Exception:
            pass

        # Fall back to PyAV
        import av
        container = av.open(path)
        stream = container.streams.video[0]
        fps = float(stream.average_rate)
        if stream.duration and stream.time_base:
            duration = float(stream.duration * stream.time_base)
        else:
            duration = float(container.duration / av.time_base)
        self._backend = "av"
        self._av_container = container
        self._av_stream = stream
        self.fps = fps
        self.width = stream.codec_context.width
        self.height = stream.codec_context.height
        self.total_frames = max(1, int(duration * fps))

    @staticmethod
    def _suppress_ffmpeg_log():
        try:
            import av
            av.logging.set_level(av.logging.FATAL)
        except ImportError:
            pass

    @staticmethod
    def _restore_ffmpeg_log():
        try:
            import av
            av.logging.set_level(av.logging.WARNING)
        except ImportError:
            pass

    def read_frame(self, frame_num):
        """Seek to a specific frame and read it.
        Returns a BGR numpy array, or None.
        """
        if self._backend == "cv2":
            import cv2
            self._cv_cap.set(cv2.CAP_PROP_POS_FRAMES, frame_num)
            ret, frame = self._cv_cap.read()
            return frame if ret else None
        elif self._backend == "imageio":
            import imageio.v3 as iio
            import cv2
            try:
                rgb = iio.imread(self._path, index=frame_num,
                                 plugin="pyav")
                return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            except Exception:
                return None
        elif self._backend == "av":
            target_sec = frame_num / self.fps
            target_ts = int(target_sec / self._av_stream.time_base)
            self._av_container.seek(target_ts, stream=self._av_stream)
            for frame in self._av_container.decode(video=0):
                return frame.to_ndarray(format="bgr24")
        return None

    def frames(self, start_frame=0):
        """Yield frames sequentially as BGR numpy arrays."""
        if self._backend == "cv2":
            import cv2
            if start_frame > 0:
                self._suppress_ffmpeg_log()
            self._cv_cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
            first = True
            while True:
                ret, frame = self._cv_cap.read()
                if not ret:
                    break
                if first and start_frame > 0:
                    self._restore_ffmpeg_log()
                    first = False
                yield frame
        elif self._backend == "imageio":
            import imageio.v3 as iio
            import cv2
            for i, rgb in enumerate(iio.imiter(self._path,
                                                plugin="pyav")):
                if i < start_frame:
                    continue
                yield cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        elif self._backend == "av":
            import av
            container = av.open(self._path)
            try:
                if start_frame > 0:
                    self._suppress_ffmpeg_log()
                    target_sec = start_frame / self.fps
                    stream = container.streams.video[0]
                    target_ts = int(target_sec / stream.time_base)
                    container.seek(target_ts, stream=stream)
                first = True
                for frame in container.decode(video=0):
                    if first and start_frame > 0:
                        self._restore_ffmpeg_log()
                        first = False
                    yield frame.to_ndarray(format="bgr24")
            finally:
                if start_frame > 0 and first:
                    self._restore_ffmpeg_log()
                container.close()

    def release(self):
        """Release the underlying video capture resources."""
        if self._cv_cap is not None:
            self._cv_cap.release()
        if self._av_container is not None:
            self._av_container.close()
