"""Gaze estimation via L2CS-Net — the default eye-gaze backend.

The InsightFace head-pose backend in
``insightface_gaze.py`` is the limited fallback for when
L2CS-Net isn't installed; it measures where the head is
pointing, not where the eyes are looking.

L2CS-Net predicts per-eye yaw/pitch angles from a face crop using a
ResNet50 backbone trained on the Gaze360 dataset (3.92° mean error on
MPIIGaze).  The angles are converted to a 3-D unit vector so that the
existing angle comparison in ``ReferenceData.check_gaze`` works unchanged.

Model weights (~96 MB) auto-download from the IDE4EEG GitLab Releases
asset on first use via stdlib ``urllib.request``; see
``_download_weights``.  Requires: ``pip install l2cs`` (PyTorch +
torchvision + timm).

Upstream weights provenance + licence
-------------------------------------

The ``L2CSNet_gaze360.pkl`` file is mirrored from the L2CS-Net
project (https://github.com/Ahmednull/L2CS-Net), MIT-licensed,
© 2022 Ahmed Abdelrahman.  Trained on the Gaze360 dataset
(Kellnhofer et al., ICCV 2019, http://gaze360.csail.mit.edu/).
The full upstream MIT notice is shipped beside the ``.pkl`` at
``L2CSNet_gaze360.LICENSE`` in the same directory.

Public entry points:

- ``analyze_gaze(img, timestamp_ms)`` — L2CS-Net gaze, no blink detection.
- ``nose_eyes_vector(img)`` — for reference photo loading.
"""
# Author: Piotr Durka, 2026

import logging
import os
import subprocess
import sys
import threading
import urllib.error
import urllib.request

# Process-wide lock around the L2CS weights download.  Prevents two
# concurrent invocations (e.g. preflight + first Gaze click) from
# both starting urlretrieve on the same .part file, where the
# first's os.replace consumes the file and the second crashes on
# rename.  See bug reported on the 0.8.8 macOS DMG.
_DOWNLOAD_LOCK = threading.Lock()

try:
    import cv2
except ImportError:
    cv2 = None
import numpy as np

logger = logging.getLogger(__name__)


_VIDEO_STACK_HINT = (
    "Facetag features require the video stack — install via "
    "`pip install ide4eeg[video]` or use the full .exe variant.")

# Direct asset URL on GitLab Releases.  Stable & predictable because
# the release was created with ``direct_asset_path=/L2CSNet_gaze360.pkl``
# under the ``l2cs-weights-v1`` tag — no auth, no rate limit, no
# folder-layout drift.  Bump the tag if a different upstream version
# is mirrored.
_WEIGHTS_URL = (
    "https://gitlab.com/fuw_software/ide4eeg/-/releases/"
    "l2cs-weights-v1/downloads/L2CSNet_gaze360.pkl"
)

# Optional override — when set (e.g. via tests), the loader and the
# existence-check both consult this path instead of the canonical
# ``~/.obci/ide4eeg/models/L2CSNet_gaze360.pkl`` location.
_weights_override = None


def set_weights_path(path):
    """Override the weights file location; pass ``None`` to clear."""
    global _weights_override
    _weights_override = path or None


def weights_path():
    """Absolute path where the L2CS weights are (or will be) stored.

    Returns the user override if set, otherwise the canonical
    ``~/.obci/ide4eeg/models/L2CSNet_gaze360.pkl`` location (single
    source of truth, defined in :mod:`ide4eeg.download_tools`).
    """
    if _weights_override:
        return _weights_override
    from ide4eeg.download_tools import canonical_l2cs_weights_path
    return canonical_l2cs_weights_path()


def weights_present():
    """True iff the weights file is already on disk."""
    return os.path.isfile(weights_path())


_model = None
_transform = None


def _download_weights(target_dir=None):
    """Download L2CS-Net weights if not already present.

    Pulls the ~96 MB ``L2CSNet_gaze360.pkl`` from the IDE4EEG
    GitLab Releases asset (MIT-mirrored from upstream — see the
    module docstring) using stdlib ``urllib.request``.  No third-party
    download library, no Drive rate limit, no folder-layout drift.
    Writes atomically via a sibling ``.part`` file so an interrupted
    download cannot leave a half-written .pkl that later loads as a
    corrupt checkpoint.

    Parameters
    ----------
    target_dir : str or None
        Directory to write the weights file into.  Default is the
        canonical ``~/.obci/ide4eeg/models/`` location (defined in
        :mod:`ide4eeg.download_tools`).

    Returns
    -------
    str
        Absolute path to the downloaded (or pre-existing) weights
        file.
    """
    if target_dir is None:
        dest = weights_path()
        dest_dir = os.path.dirname(dest)
    else:
        dest_dir = target_dir
        dest = os.path.join(dest_dir, os.path.basename(weights_path()))
    if os.path.isfile(dest):
        return dest
    os.makedirs(dest_dir, exist_ok=True)

    # Process-wide lock: prevents two concurrent invocations from
    # racing to download into the same ``.part`` -- if both
    # ``urlretrieve`` calls run, the first one's ``os.replace`` would
    # consume the file out from under the second, leaving the second
    # raise OSError("No such file or directory: '...pkl.part' -> ...").
    # Bug reported on the 0.8.8 macOS DMG.
    with _DOWNLOAD_LOCK:
        # Re-check inside the lock: another caller may have finished
        # while we were waiting.
        if os.path.isfile(dest):
            return dest

        logger.info(
            "Downloading L2CS-Net weights from %s ...", _WEIGHTS_URL)
        tmp = dest + ".part"
        # Clean up any stale .part from a prior interrupted attempt
        # so urlretrieve writes a fresh file (won't trip the size
        # sanity check below from a half-finished previous run).
        try:
            os.unlink(tmp)
        except OSError:
            pass
        try:
            urllib.request.urlretrieve(_WEIGHTS_URL, tmp)
        except urllib.error.HTTPError as exc:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            fname = os.path.basename(dest)
            raise FileNotFoundError(
                f"Could not fetch '{fname}' from\n  {_WEIGHTS_URL}\n"
                f"({exc.code} {exc.reason}). Download it manually from:\n"
                f"  {_WEIGHTS_URL}\n"
                f"and save it to:\n  {dest}"
            ) from exc
        except urllib.error.URLError as exc:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            fname = os.path.basename(dest)
            raise FileNotFoundError(
                f"Network error fetching '{fname}' from\n  "
                f"{_WEIGHTS_URL}\n({exc.reason}). Download it manually "
                f"from:\n  {_WEIGHTS_URL}\nand save it to:\n  {dest}"
            ) from exc

        # Defensive: urlretrieve has been observed to return cleanly
        # but with no file on disk in some macOS + Python 3.13
        # configurations (likely a XProtect / quarantine interaction
        # on freshly-installed DMG bundles).  Verify before rename
        # so the user gets a clear remediation message instead of a
        # cryptic OSError out of os.replace.
        if not os.path.isfile(tmp):
            # Another process may have raced us; if so the final
            # file exists and we're done.
            if os.path.isfile(dest):
                return dest
            fname = os.path.basename(dest)
            raise FileNotFoundError(
                f"Download of '{fname}' completed without error but "
                f"no file landed at:\n  {tmp}\n"
                f"This usually means macOS Gatekeeper / XProtect "
                f"quarantined the .pkl as it landed, or a concurrent "
                f"call consumed the temporary file.  Download it "
                f"manually from:\n  {_WEIGHTS_URL}\nand save it to:"
                f"\n  {dest}"
            )
        # Catch 0-byte / truncated responses (urlretrieve doesn't
        # always raise ContentTooShortError on premature EOF).
        # Real weights are ~91 MB; anything under 1 MB is clearly
        # broken.
        size = os.path.getsize(tmp)
        if size < 1_000_000:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            fname = os.path.basename(dest)
            raise FileNotFoundError(
                f"Download of '{fname}' produced a suspiciously small "
                f"file ({size} bytes from {_WEIGHTS_URL}).  Expected "
                f"~91 MB.  Network likely failed mid-stream.  "
                f"Retry, or download manually from:\n  {_WEIGHTS_URL}"
                f"\nand save it to:\n  {dest}"
            )
        os.replace(tmp, dest)
    return dest


def _get_model():
    """Lazily load the L2CS-Net model (ResNet50 + Gaze360 weights)."""
    global _model, _transform
    if _model is not None:
        return _model, _transform

    if cv2 is None:
        raise ImportError(_VIDEO_STACK_HINT)
    import torch
    from torchvision import transforms

    # Honour user override (set via the GUI Config tab); fall back to
    # canonical location.  When the override points at a missing file,
    # download into that path's parent directory so the user's chosen
    # location stays the source of truth.  An empty dirname (a typo'd
    # bare filename) would otherwise drop the 96 MB blob into cwd —
    # refuse instead so the user fixes the path.
    wpath = weights_path()
    if not os.path.isfile(wpath):
        target_dir = os.path.dirname(wpath)
        if not target_dir:
            raise FileNotFoundError(
                f"L2CS weights path '{wpath}' has no directory "
                "component; provide a full path or clear the override.")
        wpath = _download_weights(target_dir=target_dir)

    # Import L2CS model via the getArch helper
    from l2cs import getArch
    model = getArch("ResNet50", 90)

    state = torch.load(wpath, map_location="cpu", weights_only=False)
    model.load_state_dict(state)
    model.eval()
    _model = model

    _transform = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((448, 448)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        ),
    ])
    return _model, _transform


def _angles_to_vector(yaw_deg, pitch_deg):
    """Convert yaw/pitch (degrees) to a 3-D unit vector.

    Convention: +X = right, +Y = down, +Z = forward (into the screen).
    """
    yaw = np.radians(yaw_deg)
    pitch = np.radians(pitch_deg)
    x = -np.sin(yaw) * np.cos(pitch)
    y = -np.sin(pitch)
    z = np.cos(yaw) * np.cos(pitch)
    vec = np.array([x, y, z], dtype=np.float64)
    norm = np.linalg.norm(vec)
    if norm == 0:
        return None
    return vec / norm


def _predict(face_bgr):
    """Run L2CS-Net on a BGR face crop and return (yaw_deg, pitch_deg)."""
    if cv2 is None:
        raise ImportError(_VIDEO_STACK_HINT)
    import torch

    model, transform = _get_model()
    face_rgb = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2RGB)
    tensor = transform(face_rgb).unsqueeze(0)  # [1, 3, 448, 448]

    with torch.no_grad():
        gaze_yaw, gaze_pitch = model(tensor)

    # Softmax → weighted sum → degrees
    idx_tensor = torch.arange(90, dtype=torch.float32)

    yaw_softmax = torch.softmax(gaze_yaw, dim=1)
    pitch_softmax = torch.softmax(gaze_pitch, dim=1)

    yaw_deg = float(torch.sum(yaw_softmax * idx_tensor, dim=1)) * 4.0 - 180.0
    pitch_deg = float(torch.sum(pitch_softmax * idx_tensor, dim=1)) * 4.0 - 180.0

    return yaw_deg, pitch_deg


# ---- Public API ----------------------------------------------------------

def nose_eyes_vector(img):
    """Return a gaze unit vector for a reference photo, or None.

    Uses L2CS-Net to estimate gaze angles, then converts to a 3-D unit
    vector compatible with the nose-to-eyes convention.

    Raises
    ------
    ImportError
        If L2CS-Net or its dependencies (torch) cannot be imported.
    """
    yaw, pitch = _predict(img)
    return _angles_to_vector(yaw, pitch)


def analyze_gaze(img, timestamp_ms=0):
    """Estimate gaze direction from a face crop using L2CS-Net only.

    Parameters
    ----------
    img : numpy.ndarray
        BGR face crop.
    timestamp_ms : int
        Ignored (kept for API compatibility).

    Returns
    -------
    vector : numpy.ndarray or None
        3-D gaze unit vector, or None if estimation fails.
    eyes_closed : bool
        Always False (no blink detection in this mode).
    """
    try:
        yaw, pitch = _predict(img)
    except ImportError:
        raise
    except Exception as e:
        logger.debug("L2CS-Net gaze estimation failed: %s", e)
        return None, False
    return _angles_to_vector(yaw, pitch), False


def reset_video_state():
    """No-op — L2CS-Net has no inter-frame state to reset."""
    pass
