"""Face-recognition-based video artifact tagging.

Pipeline (per frame):

1. **Read frame** — OpenCV ``VideoReader``, optionally downscaled.
2. **Detect faces** — InsightFace RetinaFace.
3. **Encode faces** — 512-d ArcFace identity vector.
4. **Match to subject** (``ReferenceData._score_candidate``):
   - encoding distance to subject reference photos,
   - exclude gate — reject faces closer to exclude refs (e.g. mother),
   - tolerance hard gate — reject unknowns,
   - adaptive encoding + spatial/size/switch tracking.
5. **Gaze check** (``ReferenceData.check_gaze``, configurable backend):
   - *insightface*: nose-to-eyes vector from 5-point landmarks,
   - *l2cs*: L2CS-Net ResNet50 eye gaze (3.92° accuracy),
   - angle comparison against reference gaze vectors.
6. **Output** — per-frame booleans → not-looking intervals → EEG sample mask.

Two libraries handle different tasks:

- **InsightFace** — face identity (*who*) and head orientation gaze.
- **L2CS-Net** — learned eye gaze direction (*where looking*).

Produces a per-sample binary artifact matrix (``not_looking``) and
tag descriptions compatible with the ide4eeg artifact pipeline.
"""
# Author: Piotr Durka, 2026

import logging
import queue
import threading

import numpy as np
from tqdm import tqdm


def facetag_video(video_path, reference_dir, output_shape=None,
                  frame_rate=None, output_path=None,
                  progress_callback=None,
                  frame_skip=1,  downscale=1.0,
                  start_time=0.0, end_time=None,
                  interval_callback=None,
                  max_angle=10.0, ref_use_roi=False,
                  face_tolerance=0.6, min_interval=0.0,
                  no_face_is_artifact=True,
                  backend_name="insightface",
                  tracking_adapt_rate=0.15, position_weight=0.4,
                  size_weight=0.2, switch_resistance=0.25,
                  insightface_det_size=0,
                  exclude_dir=None,
                  gaze_method="insightface",
                  gaze_smoothing=0.3,
                  insightface_processing_skip=3,
                  cancel_event=None):
    """Process *video_path* using reference photos in *reference_dir*.

    Parameters
    ----------
    video_path : str
        Path to the video file (.mp4, .mkv, …).
    reference_dir : str
        Directory containing reference photos of the subject looking at
        the camera (3-5 images).
    output_shape : tuple (n_channels, n_samples) or None
        If given, the per-frame boolean result is interpolated to match
        the EEG sample count and broadcast across channels.
    frame_rate : float or None
        Override the video frame rate.  When *None* the rate is read
        from the video metadata.
    output_path : str or None
        Path for an XML tag file (legacy).  Currently unused but kept
        for API compatibility.
    progress_callback : callable or None
        If given, called periodically with
        ``(processed_count, frames_to_process, current_time, not_looking)``
        to report progress.
    frame_skip : int
        Process every Nth frame (default 1 = every frame).  Skipped
        frames inherit the result of the last processed frame.  Values
        of 3-5 give a good speed/accuracy trade-off.
    downscale : float
        Resize factor applied before face detection (default 1.0 = full
        resolution).  Use 0.5 for half resolution.  Smaller values are
        faster but may miss small faces.
    start_time : float
        Start processing at this time (seconds).  Frames before this
        point are skipped.  Default 0.0 (beginning).
    end_time : float or None
        Stop processing at this time (seconds).  When *None* the entire
        video is processed.
    interval_callback : callable or None
        If given, called with (start_sec, end_sec) each time a complete
        not-looking interval is detected.  Allows live reporting of
        intervals before processing finishes.
    max_angle : float
        Maximum acceptable gaze deviation in degrees from the reference
        vectors.  Default 10.0.
    ref_use_roi : bool
        If True, compute reference gaze vectors from the cropped face
        region instead of the full photo.  Default False.
    face_tolerance : float
        Maximum distance for face encoding match (default 0.6).
        Lower = stricter matching of detected faces to references.
    min_interval : float
        Minimum duration (seconds) for a not-looking interval.
        Shorter intervals are discarded.  Default 0.0 (keep all).
    no_face_is_artifact : bool
        If True (default), frames where no face is detected are
        classified as "not looking".  If False, they inherit the
        previous frame's state.
    backend_name : str
        Face detection/encoding backend: ``"insightface"``.
    exclude_dir : str or None
        Directory with photos of faces to exclude (e.g. mother).
        Faces closer to an exclude reference than to the subject are
        rejected.  None or empty disables exclusion.
    gaze_method : str
        Gaze estimation backend: ``"insightface"`` (default, head
        orientation from 5-point keypoints, no blink),
        ``"l2cs"`` (L2CS-Net eye gaze).
    gaze_smoothing : float
        EMA temporal smoothing alpha (0-1). 0 = off, 0.3 = default.
    cancel_event : threading.Event or None
        If set during processing, the frame loop bails out and raises
        ``InterruptedError`` so the pipeline's Stop button can interrupt
        a long video without waiting for the whole pass to finish.

    Returns
    -------
    result : numpy.ndarray or list[bool]
        If *output_shape* is given: ``[n_channels, n_samples]`` binary
        matrix (1 = not looking).  Otherwise a list of booleans, one
        per frame.
    tags_description : list[dict]
        Tag dicts suitable for the ide4eeg artifact tag writer.
    video_stats : dict
        Summary statistics: ``total_frames``, ``fps``,
        ``not_looking_count``, ``frames_of_interest`` (per-frame bool
        list).
    """
    import sys
    if 'cv2' not in sys.modules:
        logging.info(
            "Video artifact detection: loading OpenCV, InsightFace. "
            "First load may take a moment.")

    logging.info("Loading video processing libraries...")
    import cv2
    from .reference import ReferenceData, get_backend
    from .video_reader import VideoReader
    logging.info("Video libraries loaded.")
    backend = get_backend(backend_name)
    # Configure InsightFace detection resolution
    if backend_name == "insightface":
        from .insightface_backend import set_det_size
        set_det_size(insightface_det_size)
    logging.info("Loading reference data from %s (backend: %s)",
                 reference_dir, backend_name)
    ref = ReferenceData.load_dir(reference_dir, use_roi=ref_use_roi,
                                 backend=backend, exclude_dir=exclude_dir,
                                 gaze_method=gaze_method,
                                 gaze_smoothing=gaze_smoothing)
    ref.max_angle = max_angle
    ref.face_tolerance = face_tolerance
    ref._ADAPTIVE_ALPHA = float(tracking_adapt_rate)
    ref._SPATIAL_WEIGHT = float(position_weight)
    ref._SIZE_WEIGHT = float(size_weight)
    ref._SWITCH_PENALTY = float(switch_resistance)

    reader = VideoReader(video_path)
    if frame_rate is None:
        frame_rate = reader.fps
    total_frames = reader.total_frames
    ms_per_frame = 1000.0 / frame_rate

    frame_skip = max(1, int(frame_skip))
    downscale = max(0.1, min(1.0, float(downscale)))

    accel_parts = []
    if frame_skip > 1:
        accel_parts.append(f"every {frame_skip} frames")
    if downscale < 1.0:
        accel_parts.append(f"{downscale:.0%} resolution")

    # Frame range to process
    start_frame = max(0, int(start_time * frame_rate))
    if end_time is not None:
        end_frame = min(total_frames, int(end_time * frame_rate))
    else:
        end_frame = total_frames
    frames_to_process = max(0, end_frame - start_frame)

    if start_frame > 0 or end_frame < total_frames:
        accel_parts.append(
            f"frames {start_frame}–{end_frame} of {total_frames}")
    if accel_parts:
        logging.info("FaceTag acceleration: %s", ", ".join(accel_parts))

    frames_of_interest = []  # True = NOT looking (artifact)
    tag_bounds = []
    area_of_interest = False  # current state
    last_result = no_face_is_artifact  # default when no face detected

    logging.info(
        "Processing video: %d frames at %.2f fps (range %d–%d)",
        total_frames, frame_rate, start_frame, end_frame,
    )

    frame_number = start_frame
    processed_count = 0

    # Producer/consumer pipeline. A daemon thread pulls frames from the
    # reader into a bounded queue; the main thread consumes them and does
    # detection + state tracking. Both sides release the GIL (ffmpeg/
    # OpenCV decode and numpy/ONNX inference), so total per-frame cost
    # becomes max(decode, inference) instead of sum. Typical speedup is
    # 1.2-1.5x on the CPU baseline, more when inference shrinks under a
    # GPU provider.
    _decode_q = queue.Queue(maxsize=16)  # bounded backpressure
    _decode_stop = threading.Event()

    def _decode_worker():
        try:
            for frame in reader.frames(start_frame=start_frame):
                if _decode_stop.is_set():
                    break
                _decode_q.put(frame)
        finally:
            _decode_q.put(None)  # sentinel

    _decode_thread = threading.Thread(
        target=_decode_worker, daemon=True, name="FacetagDecode")
    _decode_thread.start()

    try:
        with tqdm(total=frames_to_process,
                  desc="FaceTag", unit="frames") as pbar:
            while True:
                # Honour the pipeline's Stop button: the outer loop in
                # preprocessing.py only checks cancel between steps, so
                # without this the user would have to wait out the whole
                # video.  ``Event.is_set()`` is a cheap atomic read; the
                # ``finally`` block below tears down the decode thread.
                if cancel_event is not None and cancel_event.is_set():
                    logging.info("FaceTag cancelled by user.")
                    raise InterruptedError(
                        "Video artifact detection cancelled by user")

                frame = _decode_q.get()
                if frame is None:
                    break

                if frame_number >= end_frame:
                    break

                is_processed = processed_count % frame_skip == 0
                last_face_box = None
                if is_processed:
                    # Process this frame
                    det_frame = frame
                    if downscale < 1.0:
                        det_frame = cv2.resize(
                            frame, None, fx=downscale, fy=downscale,
                            interpolation=cv2.INTER_AREA)
                    found, looking, face_box = ref.check_looking(det_frame, insightface_processing_skip, frame_number)
                    if found:
                        last_result = not looking
                        # Scale box back to original frame coordinates
                        if face_box is not None and downscale < 1.0:
                            t, r, b, l = face_box
                            face_box = (int(t / downscale),
                                        int(r / downscale),
                                        int(b / downscale),
                                        int(l / downscale))
                        last_face_box = face_box
                    elif no_face_is_artifact:
                        last_result = True  # no face → not looking
                    # else: keep last_result (inherit previous state)

                not_looking = last_result
                frames_of_interest.append(not_looking)

                if area_of_interest != not_looking:
                    tag_bounds.append(frame_number)
                    area_of_interest = not_looking
                    # Report completed interval (not_looking just ended)
                    if (interval_callback and not not_looking
                            and len(tag_bounds) >= 2):
                        iv_start = tag_bounds[-2] * ms_per_frame / 1000.0
                        iv_end = tag_bounds[-1] * ms_per_frame / 1000.0
                        interval_callback(iv_start, iv_end)

                frame_number += 1
                processed_count += 1
                pbar.update(1)
                # Skipped frames have no fresh face_box and inherit
                # not_looking — silence the callback so the GUI doesn't
                # render "looking"/"not looking" on frames we never
                # inspected.
                if progress_callback and is_processed:
                    current_time = frame_number / frame_rate
                    progress_callback(processed_count, frames_to_process,
                                      current_time, not_looking,
                                      face_box=last_face_box)
    finally:
        _decode_stop.set()
        # Drain the queue so the worker doesn't block on a full put()
        # after we stop consuming.
        try:
            while True:
                _decode_q.get_nowait()
        except queue.Empty:
            pass
        _decode_thread.join(timeout=2.0)

    reader.release()

    # Reset gaze backend state between videos
    from .reference import _get_gaze_module
    _get_gaze_module(gaze_method).reset_video_state()

    # Close any open interval
    if len(tag_bounds) % 2 != 0:
        tag_bounds.append(frame_number)

    # Build tag descriptions
    tags = [
        (tag_bounds[i] * ms_per_frame, tag_bounds[i + 1] * ms_per_frame)
        for i in range(0, len(tag_bounds), 2)
    ]

    # Filter by minimum interval duration
    if min_interval > 0:
        tags = [(s, e) for s, e in tags
                if (e - s) / 1000.0 >= min_interval]

    tags_description = []
    for start_ms, stop_ms in tags:
        tags_description.append({
            "channels_number": -1,
            "start_timestamp": start_ms / 1000.0,
            "name": "not_looking",
            "end_timestamp": stop_ms / 1000.0,
            "desc": {"typ": "video"},
        })

    logging.info(
        "FaceTag done: %d/%d frames not-looking, %d tag intervals",
        sum(frames_of_interest), len(frames_of_interest), len(tags),
    )
    # Diagnostic: surface how many find_face calls actually ran
    # InsightFace inference vs short-circuited via the per-frame
    # cache. When the gaze window appears to "skip" detection
    # (270 fps, 0 detections), this line tells us whether the loop
    # is hitting the cache short-circuit on every frame.
    logging.info(
        "FaceTag diag: %d find_face calls (%d ran inference, "
        "%d cached, %d returned no face)",
        ref._diag_calls_total, ref._diag_calls_inference,
        ref._diag_calls_total - ref._diag_calls_inference,
        ref._diag_no_face,
    )

    video_stats = {
        "total_frames": len(frames_of_interest),
        "fps": frame_rate,
        "not_looking_count": sum(frames_of_interest),
        "frames_of_interest": frames_of_interest,
    }

    if output_shape is not None:
        return (
            _interpolate_result(frames_of_interest, output_shape),
            tags_description,
            video_stats,
        )
    return frames_of_interest, tags_description, video_stats


def _interpolate_result(frames_of_interest, output_shape):
    """Resample per-frame booleans to match the EEG sample count."""
    n_channels, n_samples = output_shape
    n_frames = len(frames_of_interest)
    if n_frames == 0:
        return np.zeros(output_shape)

    arr = np.array(frames_of_interest, dtype=float)
    # Stretch to n_samples using nearest-neighbour interpolation
    indices = np.round(
        np.linspace(0, n_frames - 1, n_samples)
    ).astype(int)
    row = arr[indices]
    return np.tile(row, (n_channels, 1))
