"""Qt6 face selection window for reference/exclude photos.

Port of ``AutoDetectWindow`` to PySide6/Qt6.  Scrub through a video,
click on detected faces to save cropped reference/exclude photos.
"""
# Author: Piotr Durka, 2026

import logging, os, threading

try:
    from PySide6.QtCore import Qt, QTimer, Signal, QObject
    from PySide6.QtGui import QImage, QPixmap, QPainter, QPen, QColor, QFont
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
        QPushButton, QSlider, QLineEdit, QFileDialog, QMessageBox,
        QScrollArea, QSizePolicy, QApplication)
    _HAS_QT = True
except ImportError:
    _HAS_QT = False

from .video_reader import VideoReader

log = logging.getLogger(__name__)

DISPLAY_WIDTH = 640
THUMB_SIZE = 80
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
MIN_FACE_SIZE = 60
BOX_COLORS = [(255,0,0),(0,255,0),(0,0,255),(255,255,0),(255,0,255),(0,255,255)]

# Catppuccin Mocha palette (matches review_window_qt.py)
_BG, _SURFACE0, _OVERLAY0 = "#1e1e2e", "#313244", "#6c7086"
_TEXT, _SUBTEXT = "#cdd6f4", "#a6adc8"
_BLUE, _RED = "#89b4fa", "#f38ba8"

_QSS = f"""
QMainWindow, QWidget {{ background: {_BG}; color: {_TEXT}; }}
QLabel {{ color: {_TEXT}; }}
QPushButton {{
    background: {_SURFACE0}; color: {_TEXT}; border: 1px solid {_OVERLAY0};
    border-radius: 4px; padding: 4px 10px;
}}
QPushButton:hover {{ background: {_OVERLAY0}; }}
QPushButton:disabled {{ color: {_OVERLAY0}; }}
QSlider::groove:horizontal {{
    background: {_SURFACE0}; height: 6px; border-radius: 3px;
}}
QSlider::handle:horizontal {{
    background: {_BLUE}; width: 14px; margin: -4px 0; border-radius: 7px;
}}
QLineEdit {{
    background: {_SURFACE0}; color: {_TEXT}; border: 1px solid {_OVERLAY0};
    border-radius: 3px; padding: 2px 4px;
}}
QScrollArea {{ border: none; }}
"""


def _get_backend_lazy(name):
    """Import face backend on demand; return None if unavailable."""
    try:
        from .reference import get_backend
        return get_backend(name)
    except ImportError as exc:
        log.warning("Face backend unavailable: %s", exc)
        return None


class _ScanSignals(QObject):
    """Thread-safe signals for face scan progress."""
    found = Signal(float)       # face found at time t
    progress = Signal(str)      # status text
    finished = Signal(str)      # done message (or empty on success)


class AutoDetectWindowQt(QMainWindow):
    """Qt6 window: scrub video, click on a face to save a reference photo."""

    def __init__(self, parent=None, video_path="", save_dir="",
                 title="Select reference faces",
                 backend_name="insightface", det_size=0,
                 face_tolerance=0.6, on_done=None,
                 keep_existing=False,
                 trim_start=0.0, trim_end=None):
        if not _HAS_QT:
            raise ImportError("PySide6 is required for AutoDetectWindowQt")
        super().__init__(parent)
        self.video_path = video_path
        # save_dir is canonically the per-recording
        # ``IDE4EEG_OUT_*/preprocessing/{reference,exclude}_faces/``
        # path, set by the GUI's _open_face_picker.  No fallback to
        # ``<video_dir>/refs/`` — that path was removed when face
        # folders moved into the per-recording results dir.
        if not save_dir:
            raise ValueError(
                "AutoDetectWindowQt requires save_dir; the GUI must "
                "resolve the canonical per-recording location before "
                "opening the picker.")
        self.save_dir = save_dir
        self._title, self._backend_name = title, backend_name
        self._det_size, self._face_tolerance = det_size, face_tolerance
        self._on_done_cb = on_done
        # Restrict the picker to the trimmed range so reference photos
        # come from the same time window the detection pass will scan.
        # Resolved against video duration in _deferred_load_video.
        self._trim_start = max(0.0, float(trim_start or 0.0))
        self._trim_end = float(trim_end) if trim_end not in (None, "") else None
        self._t_min, self._t_max = 0.0, 0.0  # set after video opens
        self._scan_sig = _ScanSignals()
        self._scan_sig.found.connect(lambda t: (
            self._seek(t), self._finish_scan(None)))
        self._scan_sig.progress.connect(
            lambda s: self._status_label.setText(s)
            if hasattr(self, "_status_label") else None)
        self._scan_sig.finished.connect(self._finish_scan)

        self._face_backend = None  # loaded lazily
        self._accepted: list[tuple[str, tuple]] = []
        self._thumb_pixmaps: list[QPixmap] = []
        self._resize_ratio = 1.0
        self._current_boxes: list[tuple] = []
        self._current_frame_num = 0
        self._seeking, self._scan_cancel = False, False
        self._detect_timer = QTimer(self)
        self._detect_timer.setSingleShot(True)
        self._detect_timer.timeout.connect(self._deferred_detect)
        # Placeholders — real values populated by _deferred_load_video
        # after the window is visible. Opening the video and reading the
        # first frame can take 0.5–5 s on large files, so we defer it
        # past show() to avoid a blank unresponsive window.
        self.reader, self.fps, self.duration = None, 30.0, 0.0

        self.setWindowTitle(title)
        self.setStyleSheet(_QSS)
        self.setAttribute(Qt.WA_DeleteOnClose)

        # Pre-populate accepted list from existing reference images (fast
        # directory listing, safe to do before show()).
        self._keep_existing = keep_existing
        if keep_existing and os.path.isdir(self.save_dir):
            existing = [f for f in os.listdir(self.save_dir)
                        if os.path.splitext(f)[1].lower() in IMAGE_EXTENSIONS]
            for f in existing:
                self._accepted.append(
                    (os.path.join(self.save_dir, f), (0, 0, 0, 0)))

        self._build_ui()
        # Initial geometry: the video QLabel is empty until
        # ``_deferred_load_video`` paints the first frame, so without
        # an explicit size Qt's sizeHint() shrinks to the controls
        # alone — which on Linux/X11 has been observed to clip the
        # thumbnail strip + Save-dir row + Done button until the
        # user manually drags the window larger.  Pin a reasonable
        # default that fits the 640-px video frame plus all the
        # surrounding widgets in 4:3 or 16:9.
        self.setMinimumWidth(DISPLAY_WIDTH + 40)
        self.resize(DISPLAY_WIDTH + 60, 820)
        if self._accepted:
            self._saved_label.setText(
                f"Saved: {len(self._accepted)} face(s)")
            self._update_thumbs()
        self._status_label.setText("Loading video...")
        # Defer slow VideoReader open + first-frame read until after
        # show() paints. _deferred_load_video also schedules the
        # InsightFace detection pass (another 5–15 s on first call).
        QTimer.singleShot(10, self._deferred_load_video)

    # ── Deferred video load ───────────────────────────────────────────

    def _deferred_load_video(self):
        """Open the video and load the first frame after the window is visible.

        Runs on the Qt event loop 10 ms after ``__init__`` returns, so the
        user sees the window immediately with a "Loading video..." status
        instead of waiting 0.5–5 s in a blocked main thread. After the
        video metadata is populated and the first frame is rendered, this
        method chains into the existing 50 ms ``QTimer.singleShot`` that
        triggers the InsightFace lazy-load on the first detect call.
        """
        try:
            self.reader = VideoReader(self.video_path)
        except Exception as exc:
            QMessageBox.critical(
                self, "Error",
                f"Cannot open video:\n{self.video_path}\n\n{exc}")
            self.close()
            return
        if self.reader.total_frames < 1:
            QMessageBox.critical(self, "Error", "Video has no frames.")
            self.reader.release()
            self.reader = None
            self.close()
            return

        self.fps = self.reader.fps
        self.duration = self.reader.total_frames / self.fps
        # Resolve trim against actual video duration. trim_end=None
        # means "to end". If the trim window is empty or invalid (start
        # past video end, end before start) we fall back to the full
        # video to avoid trapping the user with an unusable picker.
        t_max = (min(self.duration, self._trim_end)
                 if self._trim_end is not None else self.duration)
        t_min = min(self._trim_start, self.duration)
        if t_max <= t_min:
            t_min, t_max = 0.0, self.duration
        self._t_min, self._t_max = t_min, t_max
        self._slider.setMinimum(int(t_min * 1000))
        self._slider.setMaximum(max(int(t_min * 1000) + 1,
                                    int(t_max * 1000)))
        self._duration_label.setText(
            self._fmt_duration(self.duration, t_max - t_min))
        # Show the first frame without detection, then detect after
        # the window is visible (InsightFace model load takes ~5-15s
        # on first call and blocks the event loop).
        self._seek(t_min, detect=False)
        self._status_label.setText(
            "Loading face detection model (first time may take a few seconds)...")
        QTimer.singleShot(50, lambda: self._show_frame(
            self._current_frame_num, detect=True))

    # ── Existing files ────────────────────────────────────────────────

    def _check_existing_files(self):
        """Prompt user if save directory already has images."""
        if not os.path.isdir(self.save_dir):
            return
        existing = [f for f in os.listdir(self.save_dir)
                    if os.path.splitext(f)[1].lower() in IMAGE_EXTENSIONS]
        if not existing:
            return
        dlg = QMessageBox(self.parent() or self)
        dlg.setIcon(QMessageBox.Question)
        dlg.setWindowTitle("Existing files")
        dlg.setText(
            f"The save directory already contains {len(existing)} image(s):\n"
            f"{self.save_dir}")
        btn_delete = dlg.addButton("Delete && start fresh",
                                    QMessageBox.YesRole)
        btn_keep = dlg.addButton("Keep && add more",
                                  QMessageBox.NoRole)
        btn_cancel = dlg.addButton("Cancel", QMessageBox.RejectRole)
        dlg.exec()
        clicked = dlg.clickedButton()
        if clicked == btn_cancel:
            self.save_dir = ""; return
        if clicked == btn_delete:
            for f in existing:
                os.remove(os.path.join(self.save_dir, f))
        elif clicked == btn_keep:
            # Pre-populate accepted list with existing files
            for f in existing:
                fp = os.path.join(self.save_dir, f)
                self._accepted.append((fp, (0, 0, 0, 0)))

    # ── UI ────────────────────────────────────────────────────────────

    def _build_ui(self):
        cw = QWidget(); self.setCentralWidget(cw)
        ml = QVBoxLayout(cw); ml.setContentsMargins(8,8,8,8); ml.setSpacing(4)

        # Hint
        hr = QHBoxLayout()
        self._duration_label = QLabel(
            self._fmt_duration(self.duration, self.duration))
        self._duration_label.setFont(QFont("Helvetica", 11))
        hr.addWidget(self._duration_label)
        is_excl = "xclude" in self._title.lower()
        ht = ("   Select faces to EXCLUDE from analysis" if is_excl
              else "   Select frames where the subject is LOOKING AT THE CAMERA")
        hl = QLabel(ht)
        hl.setStyleSheet(f"color: {_RED if is_excl else _BLUE}; "
                         "font-weight: bold; font-size: 11pt;")
        hr.addWidget(hl); hr.addStretch(); ml.addLayout(hr)

        # Video frame
        self._image_label = QLabel()
        self._image_label.setStyleSheet("background-color: black;")
        self._image_label.setAlignment(Qt.AlignCenter)
        self._image_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._image_label.mousePressEvent = self._on_image_click
        ml.addWidget(self._image_label, alignment=Qt.AlignCenter)

        # Timeline
        tl = QHBoxLayout()
        for txt, tip, cb in [
            ("<<", "Previous frame with a face", lambda: self._find_face(-1)),
            ("<",  "Back 1 frame",               lambda: self._step_frames(-1))]:
            b = QPushButton(txt); b.setFixedWidth(40); b.setToolTip(tip)
            b.clicked.connect(cb); tl.addWidget(b)
        self._slider = QSlider(Qt.Horizontal)
        self._slider.setMinimum(0)
        self._slider.setMaximum(max(1, int(self.duration * 1000)))
        self._slider.valueChanged.connect(self._on_slider)
        tl.addWidget(self._slider, stretch=1)
        for txt, tip, cb in [
            (">",  "Forward 1 frame",          lambda: self._step_frames(1)),
            (">>", "Next frame with a face",   lambda: self._find_face(1))]:
            b = QPushButton(txt); b.setFixedWidth(40); b.setToolTip(tip)
            b.clicked.connect(cb); tl.addWidget(b)
        self._time_label = QLabel("00:00.00")
        self._time_label.setFixedWidth(90); self._time_label.setFont(QFont("Menlo", 11))
        tl.addWidget(self._time_label); ml.addLayout(tl)

        # Status (fixed height to avoid layout jump when Cancel appears)
        status_w = QWidget()
        status_w.setFixedHeight(30)
        sr = QHBoxLayout(status_w)
        sr.setContentsMargins(0, 0, 0, 0)
        self._status_label = QLabel(
            "Find a frame where the subject is looking at the camera, "
            "then click on their face")
        self._status_label.setStyleSheet(f"color: {_SUBTEXT};")
        sr.addWidget(self._status_label, stretch=1)
        self._cancel_btn = QPushButton("Cancel scan")
        self._cancel_btn.setFixedWidth(100)
        self._cancel_btn.clicked.connect(self._cancel_face_scan)
        self._cancel_btn.setVisible(False)
        sr.addWidget(self._cancel_btn)
        ml.addWidget(status_w)

        # Saved count
        self._saved_label = QLabel("Saved: 0 face(s)")
        self._saved_label.setStyleSheet(
            f"font-weight: bold; font-size: 12pt; color: {_TEXT};")
        ml.addWidget(self._saved_label)

        # Thumbnail strip
        ts = QScrollArea(); ts.setWidgetResizable(True)
        ts.setFixedHeight(THUMB_SIZE + 20)
        ts.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._thumb_container = QWidget()
        self._thumb_layout = QHBoxLayout(self._thumb_container)
        self._thumb_layout.setContentsMargins(0,0,0,0); self._thumb_layout.setSpacing(4)
        self._thumb_layout.addStretch()
        ts.setWidget(self._thumb_container); ml.addWidget(ts)

        # Directory row
        dr = QHBoxLayout(); dr.addWidget(QLabel("Save dir:"))
        self._dir_edit = QLineEdit(self.save_dir)
        self._dir_edit.setMinimumWidth(300); dr.addWidget(self._dir_edit, stretch=1)
        bc = QPushButton("Change..."); bc.clicked.connect(self._change_dir)
        dr.addWidget(bc)
        bu = QPushButton("Undo last"); bu.setToolTip("Remove the last saved face")
        bu.clicked.connect(self._undo_last); dr.addWidget(bu)
        ml.addLayout(dr)

        # Done
        bot = QHBoxLayout(); bot.addStretch()
        bd = QPushButton("Done"); bd.setToolTip("Close (faces are saved on click)")
        bd.clicked.connect(self._on_done); bot.addWidget(bd)
        ml.addLayout(bot)

    # ── Helpers ───────────────────────────────────────────────────────

    @staticmethod
    def _fmt_duration(total, clipped):
        def _mmss(s):
            m = int(s) // 60; return f"{m}:{s - m*60:05.2f}"
        if clipped < total:
            return f"Duration: {_mmss(total)} total, {_mmss(clipped)} after trim"
        return f"Duration: {_mmss(total)}"

    @staticmethod
    def _fmt_time(t):
        m = int(t) // 60; return f"{m:02d}:{t - m*60:05.2f}"

    def _ensure_backend(self):
        """Lazy-load the face detection backend."""
        if self._face_backend is None:
            self._status_label.setText(
                "Loading face detection model (first time may take a few seconds)...")
            QApplication.processEvents()
            self._face_backend = _get_backend_lazy(self._backend_name)
            if self._face_backend is None:
                self._status_label.setText(
                    "Face detection backend not available (insightface)")
                return False
            if self._backend_name == "insightface" and self._det_size:
                try:
                    from .insightface_backend import set_det_size
                    set_det_size(self._det_size)
                except Exception:
                    pass
        return True

    # ── Video display / seeking ───────────────────────────────────────

    def _frame_to_qpixmap(self, frame_rgb, boxes=None, highlight_idx=None):
        """Convert RGB frame with optional face boxes to QPixmap."""
        import cv2
        h, w = frame_rgb.shape[:2]
        dw = DISPLAY_WIDTH; dh = int(h * dw / w)
        self._resize_ratio = dw / w
        resized = cv2.resize(frame_rgb, (dw, dh), interpolation=cv2.INTER_AREA)
        qimg = QImage(resized.data, dw, dh, 3*dw, QImage.Format_RGB888)
        pm = QPixmap.fromImage(qimg)
        draw = boxes if boxes is not None else self._current_boxes
        if draw:
            p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
            r = self._resize_ratio
            for i, (top, right, bottom, left) in enumerate(draw):
                c = QColor(*BOX_COLORS[1 if i == highlight_idx else i % len(BOX_COLORS)])
                p.setPen(QPen(c, 4 if i == highlight_idx else 3))
                p.drawRect(int(left*r), int(top*r),
                           int((right-left)*r), int((bottom-top)*r))
            p.end()
        return pm

    def _detect_faces(self, frame_rgb):
        """Run face detection and update _current_boxes."""
        if not self._ensure_backend():
            self._current_boxes = []; return
        locs = self._face_backend.detect_faces(frame_rgb, upsample=1)
        self._current_boxes = [
            (t, r, b, l) for t, r, b, l in locs
            if (b-t) >= MIN_FACE_SIZE and (r-l) >= MIN_FACE_SIZE]

    def _show_frame(self, frame_num, highlight_idx=None, detect=True):
        """Display frame with optional face detection."""
        import cv2
        if self.reader is None: return
        frame_num = max(0, min(frame_num, self.reader.total_frames - 1))
        self._current_frame_num = frame_num
        bgr = self.reader.read_frame(frame_num)
        if bgr is None: return
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        if detect and highlight_idx is None:
            self._detect_faces(rgb)
        elif not detect:
            self._current_boxes = []
        pm = self._frame_to_qpixmap(rgb, highlight_idx=highlight_idx)
        self._image_label.setPixmap(pm)
        self._image_label.setFixedSize(pm.width(), pm.height())
        if highlight_idx is None and detect:
            n = len(self._current_boxes)
            self._status_label.setText(
                f"{n} face(s) detected \u2014 click on the subject" if n
                else "No faces detected in this frame")

    def _seek(self, t, detect=True):
        """Seek to time *t* seconds, clamped to the trimmed range."""
        if self._seeking: return
        self._seeking = True
        try:
            t = max(self._t_min, min(t, self._t_max))
            self._show_frame(int(t * self.fps), detect=detect)
            self._time_label.setText(self._fmt_time(t))
            self._slider.blockSignals(True)
            self._slider.setValue(int(t * 1000))
            self._slider.blockSignals(False)
            if not detect:
                self._detect_timer.start(300)
        finally:
            self._seeking = False

    def _deferred_detect(self):
        self._current_boxes = []
        self._show_frame(self._current_frame_num, detect=True)

    def _step_frames(self, n):
        f_min = int(self._t_min * self.fps)
        f_max = min(int(self._t_max * self.fps),
                    self.reader.total_frames - 1)
        f = max(f_min, min(self._current_frame_num + n, f_max))
        self._seek(f / self.fps)

    def _on_slider(self, value):
        self._seek(value / 1000.0, detect=False)

    # ── Face scan (find next/prev frame with a face) ──────────────────

    def _find_face(self, direction):
        """Scan for next frame with a detected face in background."""
        if not self._ensure_backend(): return
        f_min = int(self._t_min * self.fps)
        f_max = min(int(self._t_max * self.fps),
                    self.reader.total_frames - 1)
        start = self._current_frame_num + direction
        end = (f_max + 1) if direction > 0 else (f_min - 1)
        if start < f_min or start > f_max:
            self._status_label.setText(
                "Already at the edge of the trimmed range"); return
        self._scan_cancel = False
        self._status_label.setText("Scanning for face\u2026 (0 frames checked)")
        self._cancel_btn.setVisible(True)

        sig = self._scan_sig

        def _bg():
            import cv2, logging as _log
            try:
                sr = VideoReader(self.video_path)
            except Exception as exc:
                sig.finished.emit(f"Cannot open video: {exc}")
                return
            be = self._face_backend
            try:
                if direction > 0:
                    fn = start
                    for cnt, bgr in enumerate(sr.frames(start), 1):
                        if fn >= end:
                            sig.finished.emit(
                                "No face found in trimmed range")
                            return
                        if self._scan_cancel:
                            sig.finished.emit("Scan cancelled")
                            return
                        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
                        for top, right, bottom, left in be.detect_faces(
                                rgb, upsample=1):
                            if ((bottom - top) >= MIN_FACE_SIZE
                                    and (right - left) >= MIN_FACE_SIZE):
                                sig.found.emit(fn / self.fps)
                                return
                        fn += 1
                        sig.progress.emit(
                            f"Scanning\u2026 {cnt} frames "
                            f"/ {fn / self.fps:.1f}s")
                else:
                    for cnt, fn in enumerate(
                            range(start, end, direction), 1):
                        if self._scan_cancel:
                            sig.finished.emit("Scan cancelled")
                            return
                        bgr = sr.read_frame(fn)
                        if bgr is None:
                            continue
                        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
                        for top, right, bottom, left in be.detect_faces(
                                rgb, upsample=1):
                            if ((bottom - top) >= MIN_FACE_SIZE
                                    and (right - left) >= MIN_FACE_SIZE):
                                sig.found.emit(fn / self.fps)
                                return
                        sig.progress.emit(
                            f"Scanning\u2026 {cnt} frames "
                            f"/ {fn / self.fps:.1f}s")
                sig.finished.emit("No face found")
            except Exception as exc:
                _log.error("Face scan error: %s", exc, exc_info=True)
                sig.finished.emit(f"Scan error: {exc}")
            finally:
                sr.release()
        threading.Thread(target=_bg, daemon=True).start()

    def _cancel_face_scan(self):
        self._scan_cancel = True

    def _finish_scan(self, msg):
        self._cancel_btn.setVisible(False)
        if msg: self._status_label.setText(msg)

    # ── Click on face -> save ─────────────────────────────────────────

    def _on_image_click(self, event):
        """Handle click on the video frame to select a face."""
        if not self._current_boxes:
            self._status_label.setText(
                "No faces detected \u2014 try a different frame"); return
        pos = event.position() if hasattr(event, 'position') else event.pos()
        ox, oy = pos.x() / self._resize_ratio, pos.y() / self._resize_ratio
        PAD, best_idx, best_d = 30, None, float("inf")
        for i, (top, right, bottom, left) in enumerate(self._current_boxes):
            if not (left-PAD <= ox <= right+PAD and top-PAD <= oy <= bottom+PAD):
                continue
            d = (ox - (left+right)/2)**2 + (oy - (top+bottom)/2)**2
            if d < best_d: best_d, best_idx = d, i
        if best_idx is None:
            self._status_label.setText("Click closer to a face bounding box")
            return
        self._save_face(self._current_boxes[best_idx])
        self._show_frame(self._current_frame_num, highlight_idx=best_idx)

    def _save_face(self, face_box):
        """Save a cropped face image to the save directory."""
        import cv2
        save_dir = self._dir_edit.text().strip()
        if not save_dir:
            QMessageBox.critical(self, "Error", "No save directory specified.")
            return
        os.makedirs(save_dir, exist_ok=True)
        fn = self._current_frame_num
        bgr = self.reader.read_frame(fn)
        if bgr is None:
            self._status_label.setText("Failed to read frame"); return
        top, right, bottom, left = face_box
        h, w = bgr.shape[:2]
        py, px = int((bottom-top)*0.3), int((right-left)*0.3)
        crop = bgr[max(0,top-py):min(h,bottom+py),
                    max(0,left-px):min(w,right+px)]
        fp = os.path.join(save_dir, f"frame_{fn:06d}.jpg")
        cv2.imwrite(fp, crop)
        self._accepted.append((fp, face_box))
        n = len(self._accepted)
        self._saved_label.setText(f"Saved: {n} face(s)")
        self._status_label.setText(
            f"Saved frame {fn} \u2014 {max(0,3-n)} more recommended"
            if n < 3 else f"Saved frame {fn}")
        self._update_thumbs()

    # ── Thumbnail strip ───────────────────────────────────────────────

    def _update_thumbs(self):
        """Rebuild the thumbnail preview strip."""
        import cv2
        while self._thumb_layout.count() > 1:
            item = self._thumb_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        self._thumb_pixmaps.clear()
        for i, (path, _) in enumerate(self._accepted):
            if not os.path.isfile(path): continue
            try:
                img = cv2.imread(path)
                if img is None: continue
                rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                h, w = rgb.shape[:2]
                tw = max(1, int(w * THUMB_SIZE / h))
                res = cv2.resize(rgb, (tw, THUMB_SIZE), interpolation=cv2.INTER_AREA)
                qimg = QImage(res.data, tw, THUMB_SIZE, 3*tw, QImage.Format_RGB888)
                pm = QPixmap.fromImage(qimg); self._thumb_pixmaps.append(pm)
                lbl = QLabel(); lbl.setPixmap(pm)
                lbl.setStyleSheet(f"border: 2px solid {_OVERLAY0}; border-radius: 3px;")
                lbl.setCursor(Qt.PointingHandCursor)
                lbl.setToolTip(f"{os.path.basename(path)}\nClick to remove")
                lbl.mousePressEvent = lambda ev, j=i: self._remove_thumb(j)
                self._thumb_layout.insertWidget(self._thumb_layout.count()-1, lbl)
            except Exception:
                pass

    def _remove_thumb(self, index):
        if 0 <= index < len(self._accepted):
            path, _ = self._accepted.pop(index)
            if os.path.isfile(path): os.remove(path)
            self._saved_label.setText(f"Saved: {len(self._accepted)} face(s)")
            self._status_label.setText(f"Removed {os.path.basename(path)}")
            self._update_thumbs()

    # ── Undo / Done / Close ───────────────────────────────────────────

    def _undo_last(self):
        if not self._accepted:
            self._status_label.setText("Nothing to undo"); return
        path, _ = self._accepted.pop()
        if os.path.isfile(path): os.remove(path)
        self._saved_label.setText(f"Saved: {len(self._accepted)} face(s)")
        self._status_label.setText("Last face removed")
        self._update_thumbs()

    def _change_dir(self):
        p = QFileDialog.getExistingDirectory(self, "Select save directory",
                                             self._dir_edit.text())
        if p: self.save_dir = p; self._dir_edit.setText(p)

    def _on_done(self):
        sd = self._dir_edit.text().strip()
        if self._on_done_cb and self._accepted: self._on_done_cb(sd)
        self.close()

    def closeEvent(self, event):  # noqa: N802
        self._scan_cancel = True; self._detect_timer.stop()
        if self.reader: self.reader.release(); self.reader = None
        super().closeEvent(event)
