"""Facetag review data model and BrainTech reader.

Pure data classes and utility shared by review_window_qt and the GUI.
"""
# Author: Piotr Durka, 2026

import json
import os
from dataclasses import dataclass, field
from typing import List


# ---------------------------------------------------------------------------
# BrainTech .raw reader (delegates to obci_readmanager)
# ---------------------------------------------------------------------------

def _read_braintech_raw(filepath):
    """Read a BrainTech .raw/.xml pair into an MNE RawArray.

    Returns an mne.io.RawArray or None on failure.  Uses ReadManager
    from obci_readmanager for consistency with the main pipeline.
    The .tag file is loaded when present, skipped when missing.
    """
    base, ext = os.path.splitext(filepath)
    if ext.lower() != ".raw":
        return None
    xml_path = base + ".xml"
    if not os.path.isfile(xml_path) or not os.path.isfile(filepath):
        return None

    try:
        from obci_readmanager.signal_processing.read_manager import ReadManager

        tag_path = base + ".tag"
        if os.path.isfile(tag_path):
            rm = ReadManager(xml_path, filepath, tag_path)
        else:
            rm = ReadManager(xml_path, filepath)
        return rm.get_mne_raw()
    except Exception:
        return None


def review_json_path(output_dir, video_path, gaze_method):
    """Canonical path for the gaze review JSON.

    Lives in the preprocessing output dir so the review state
    travels with the per-recording results instead of polluting
    the video file's directory.  Keyed by the video's basename +
    detection backend (multiple backends can each have their own
    review state for the same video).
    """
    import os
    video_stem = os.path.splitext(os.path.basename(video_path))[0]
    return os.path.join(
        output_dir,
        f"{video_stem}_facetag_{gaze_method}_review.json")


def find_review_json(output_dir, video_path, gaze_method):
    """Locate the canonical review JSON for *video_path* / *gaze_method*.

    Returns the path if it exists, otherwise ``None``.  Only the
    per-recording preproc-dir location is checked — JSONs at the
    pre-2026-05-02 ``<video_dir>/<stem>_facetag_*.json`` location
    are no longer found automatically.
    """
    import os
    if not output_dir:
        return None
    candidate = review_json_path(output_dir, video_path, gaze_method)
    return candidate if os.path.isfile(candidate) else None


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class NotLookingInterval:
    """A time interval where the subject was not looking at the screen."""

    start_sec: float
    end_sec: float
    status: str = "accepted"  # "accepted" or "rejected"

    @property
    def duration(self):
        """Return the interval duration in seconds."""
        return self.end_sec - self.start_sec


@dataclass
class ReviewData:
    """Serialisable container for facetag review results."""

    video_path: str
    reference_dir: str
    intervals: List[NotLookingInterval] = field(default_factory=list)
    computed_at: str = ""

    def to_dict(self):
        """Convert to a JSON-serialisable dictionary."""
        return {
            "video_path": self.video_path,
            "reference_dir": self.reference_dir,
            "computed_at": self.computed_at,
            "intervals": [
                {"start_sec": iv.start_sec, "end_sec": iv.end_sec,
                 "status": iv.status}
                for iv in self.intervals
            ],
        }

    @classmethod
    def from_dict(cls, d):
        """Reconstruct from a dictionary (inverse of ``to_dict``)."""
        intervals = [
            NotLookingInterval(**iv) for iv in d.get("intervals", [])
        ]
        return cls(
            video_path=d["video_path"],
            reference_dir=d["reference_dir"],
            intervals=intervals,
            computed_at=d.get("computed_at", ""),
        )

    def save(self, path):
        """Write the review data to a JSON file."""
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path):
        """Load review data from a JSON file."""
        with open(path) as f:
            return cls.from_dict(json.load(f))
