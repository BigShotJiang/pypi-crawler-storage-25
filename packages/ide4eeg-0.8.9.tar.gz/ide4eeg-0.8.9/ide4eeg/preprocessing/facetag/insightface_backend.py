"""InsightFace backend for face detection, encoding, and comparison.

Face detection and identity encoding using InsightFace (ArcFace +
RetinaFace).  Requires ``pip install insightface onnxruntime``.

Model files (~200 MB) are downloaded automatically on first use to
``~/.obci/ide4eeg/insightface/models/buffalo_l/`` — IDE4EEG sets the
``FaceAnalysis(root=...)`` argument so InsightFace's per-user cache
lands inside our consolidated ``~/.obci/ide4eeg/`` tree instead of
the upstream default ``~/.insightface/``.  See
:func:`ide4eeg.download_tools.migrate_legacy_paths` for the one-time
move of pre-existing models from the upstream path.
"""
# Author: Piotr Durka, 2026

import logging

try:
    import cv2
except ImportError:
    cv2 = None
import numpy as np

logger = logging.getLogger(__name__)


_VIDEO_STACK_HINT = (
    "Facetag features require the video stack — install via "
    "`pip install ide4eeg[video]` or use the full .exe variant.")

# --- Lazy-loaded globals ---
_app = None
_last_result = None  # (image_id, faces) — avoids re-running on same image
_det_size = (0, 0)   # (0,0) = use input image size (full resolution)


def set_det_size(size):
    """Set the detection resolution for InsightFace.

    Parameters
    ----------
    size : int
        Detection resolution.  The input frame is resized to
        ``(size, size)`` before face detection.  Use 0 for full
        input resolution (best quality, slower).  Common values:
        640 (default InsightFace), 320 (fast), 0 (full resolution).

    Must be called before the first detection call.  If the app
    is already initialised with a different size, it is re-created.
    """
    global _det_size, _app
    s = max(0, int(size))
    new_size = (s, s) if s > 0 else (0, 0)
    if new_size != _det_size:
        _det_size = new_size
        _app = None  # force re-init on next call


def _get_app():
    """Return the InsightFace FaceAnalysis app, initialising on first call."""
    global _app
    if _app is not None:
        return _app

    from insightface.app import FaceAnalysis

    det = _det_size if _det_size != (0, 0) else (640, 640)
    logger.info("Initialising InsightFace (buffalo_l, det_size=%dx%d) …",
                det[0], det[1])
    # Intersect our preference list with what this onnxruntime build
    # actually exposes. Passing a provider that isn't compiled in makes
    # ORT print a noisy `*** EP Error ***` block to stderr per session
    # (× 5 InsightFace models). Users with stock onnxruntime on Apple
    # Silicon get CoreML (Neural Engine); Linux/Windows users opt into
    # GPU by installing onnxruntime-gpu or onnxruntime-directml — no
    # IDE4EEG code changes needed. Everyone else falls through to CPU.
    # FaceAnalysis(...) auto-downloads the ~200 MB buffalo_l models on
    # first use.  We pass root=<our consolidated dir> so the cache
    # lands inside ~/.obci/ide4eeg/insightface/ instead of upstream's
    # default ~/.insightface/.  Wrap so a no-network first run, an
    # interrupted earlier download (corrupt onnx), or a GPU-provider
    # load failure surfaces as a clear RuntimeError instead of
    # crashing the artifacts step with whatever error the
    # transitively-deepest layer raises.
    from ide4eeg.download_tools import INSIGHTFACE_ROOT
    insightface_root = str(INSIGHTFACE_ROOT)
    INSIGHTFACE_ROOT.mkdir(parents=True, exist_ok=True)
    import onnxruntime as ort
    preferred = [
        "CUDAExecutionProvider",      # NVIDIA GPU (Linux/Windows,
                                      #   requires onnxruntime-gpu)
        "CoreMLExecutionProvider",    # Apple Silicon Neural Engine
                                      #   (auto on macOS arm64)
        "DirectMLExecutionProvider",  # Windows DirectX 12 GPU
                                      #   (requires onnxruntime-directml)
        "CPUExecutionProvider",       # always-on fallback
    ]
    available = set(ort.get_available_providers())
    providers = [p for p in preferred if p in available] \
        or ["CPUExecutionProvider"]
    try:
        _app = FaceAnalysis(
            name="buffalo_l",
            root=insightface_root,
            providers=providers)
        _app.prepare(ctx_id=-1, det_size=det)
    except Exception as exc:
        _app = None  # don't cache a broken instance
        raise RuntimeError(
            "Failed to initialise InsightFace face-detection backend. "
            f"First-run downloads ~200 MB into {insightface_root}/"
            "models/.\n\n"
            f"Underlying error: {exc.__class__.__name__}: {exc}\n\n"
            "Workarounds:\n"
            "  - Retry once you have network access.\n"
            "  - If a previous download was interrupted, delete\n"
            f"    {insightface_root}/models/buffalo_l/ and retry.\n"
            "  - Disable video artifact detection in the GUI to\n"
            "    bypass facetag entirely."
        ) from exc
    logger.info("InsightFace ready")
    try:
        # Log which providers ORT has compiled in and which one
        # InsightFace's detection model actually activated, so users
        # can verify their GPU is being picked up.
        logger.info("ONNXRuntime available providers: %s",
                    ", ".join(ort.get_available_providers()))
        det_model = _app.models.get("detection") if hasattr(
            _app, "models") else None
        if det_model is not None and hasattr(det_model, "session"):
            used = det_model.session.get_providers()
            logger.info("InsightFace detection session using: %s",
                        used[0] if used else "unknown")
    except Exception as e:
        logger.debug("Provider detection logging failed: %s", e)
    return _app


def _analyze(rgb_image):
    """Run InsightFace analysis, caching the result per image object.

    InsightFace performs detection + alignment + encoding in one pass.
    Caching avoids repeating work when ``detect_faces`` and
    ``encode_faces`` are called on the same image sequentially.
    """
    if cv2 is None:
        raise ImportError(_VIDEO_STACK_HINT)
    global _last_result
    img_id = rgb_image.ctypes.data
    if _last_result is not None and _last_result[0] == img_id:
        # Same buffer address — check shape and a content sample match
        prev_id, prev_faces, prev_shape, prev_sample = _last_result
        if prev_shape == rgb_image.shape and np.array_equal(
                prev_sample, rgb_image[0, :8]):
            return prev_faces

    app = _get_app()
    # InsightFace expects BGR
    bgr = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)
    faces = app.get(bgr)

    _last_result = (img_id, faces, rgb_image.shape, rgb_image[0, :8].copy())
    return faces


def _bbox_to_tuple(bbox):
    """Convert InsightFace bbox [x1, y1, x2, y2] to (top, right, bottom, left)."""
    x1, y1, x2, y2 = bbox
    return (int(y1), int(x2), int(y2), int(x1))


# --- Public API ---


def detect_faces(rgb_image, upsample=1):
    """Detect face locations in an RGB image.

    Parameters
    ----------
    rgb_image : numpy.ndarray
        RGB image (H x W x 3, uint8).
    upsample : int
        Ignored (kept for API compatibility).

    Returns
    -------
    list of tuple
        Each element is ``(top, right, bottom, left)``.
    """
    faces = _analyze(rgb_image)
    return [_bbox_to_tuple(f.bbox) for f in faces]


def detect_faces_with_kps(rgb_image):
    """Detect faces and return bounding boxes + 5-point keypoints.

    Returns ``(locations, keypoints_list)`` where *keypoints_list*
    is a parallel list of ``(5, 2)`` ndarrays (left_eye, right_eye,
    nose, left_mouth, right_mouth).  Reuses the same InsightFace
    pass as ``detect_faces`` — no extra inference.
    """
    faces = _analyze(rgb_image)
    locs = [_bbox_to_tuple(f.bbox) for f in faces]
    kps_list = [f.kps for f in faces]
    return locs, kps_list


def encode_faces(rgb_image, face_locations=None):
    """Compute face encodings for faces in an RGB image.

    Parameters
    ----------
    rgb_image : numpy.ndarray
        RGB image (H x W x 3, uint8).
    face_locations : list of tuple or None
        When given and no faces are detected automatically (e.g.
        tightly cropped reference photos), the image is padded and
        re-analysed.  Useful for tightly cropped reference photos.

    Returns
    -------
    list of numpy.ndarray
        Each element is a 512-d float32 array (L2-normalised).
    """
    if cv2 is None:
        raise ImportError(_VIDEO_STACK_HINT)
    faces = _analyze(rgb_image)
    if faces:
        return [np.array(f.normed_embedding, dtype=np.float64)
                for f in faces]
    # No faces detected.  If face_locations were provided (cropped
    # reference image), pad the image and retry so InsightFace's
    # detector can find the face.
    if face_locations is not None:
        h, w = rgb_image.shape[:2]
        pad = max(h, w) // 3
        padded = cv2.copyMakeBorder(
            rgb_image, pad, pad, pad, pad,
            cv2.BORDER_CONSTANT, value=(128, 128, 128))
        global _last_result
        _last_result = None  # invalidate cache
        faces = _analyze(padded)
        if faces:
            return [np.array(f.normed_embedding, dtype=np.float64)
                    for f in faces]
    return []


def compare_faces(known_encodings, encoding, tolerance=0.6):
    """Compare a face encoding against a list of known encodings.

    Uses cosine distance (1 − dot product) since InsightFace embeddings
    are L2-normalised.

    Parameters
    ----------
    known_encodings : list of numpy.ndarray
        Reference 512-d encodings.
    encoding : numpy.ndarray
        Single 512-d encoding to compare.
    tolerance : float
        Maximum cosine distance to consider a match.

    Returns
    -------
    list of bool
        ``True`` for each known encoding within *tolerance*.
    """
    distances = face_distances(known_encodings, encoding)
    return [bool(d <= tolerance) for d in distances]


def face_distances(known_encodings, encoding):
    """Compute cosine distances between a face encoding and known encodings.

    Parameters
    ----------
    known_encodings : list of numpy.ndarray
        Reference 512-d encodings.
    encoding : numpy.ndarray
        Single 512-d encoding to compare.

    Returns
    -------
    numpy.ndarray
        Array of float distances in [0, 2].
    """
    if len(known_encodings) == 0:
        return np.empty(0)
    known = np.array(known_encodings)
    sims = known @ encoding
    return 1.0 - sims


def load_image(path):
    """Load an image file as an RGB numpy array.

    Parameters
    ----------
    path : str
        Path to the image file.

    Returns
    -------
    numpy.ndarray
        RGB image (H x W x 3, uint8).
    """
    if cv2 is None:
        raise ImportError(_VIDEO_STACK_HINT)
    bgr = cv2.imread(path)
    if bgr is None:
        raise FileNotFoundError(f"Cannot load image: {path}")
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
