"""Qt6 Review Video Artifacts window.

Port of the Tkinter ReviewVideoArtifactsWindow to PySide6/Qt6.
Shows video frames and EEG waveforms side-by-side with not_looking
intervals highlighted.  The user can scrub through time and
accept/reject individual intervals.
"""
# Author: Piotr Durka, 2026
import datetime, logging, os, threading
from typing import List, Optional
import numpy as np

try:
    from PySide6.QtCore import Qt, QTimer, Signal, QObject, QRectF
    from PySide6.QtGui import (QImage, QPixmap, QPen, QColor, QFont)
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
        QPushButton, QSlider, QProgressBar, QTableWidget,
        QTableWidgetItem, QHeaderView, QAbstractItemView,
        QFileDialog, QMessageBox, QSplitter, QCheckBox,
        QSizePolicy, QMenu, QApplication)
    _HAS_QT = True
except ImportError:
    _HAS_QT = False

from .review_window import NotLookingInterval, ReviewData, _read_braintech_raw
from .video_reader import VideoReader
from ._eeg_paint import EegPagedCanvas, TRIM_BD, fmt_time
# EegStripQt — whole-recording compressed timeline widget shared with
# the Preview & Trim window so this window has the same navigation
# affordances (envelope strip + amplitude / DC controls).
from .trim_window_qt import EegStripQt

# Surface color for the trim status-label widget background — kept
# local because it's UI styling for a non-canvas widget.
_SURFACE0 = "#313244"
# Interval-shading accents used by the canvas's underlay hook.  Pink
# matches the trim shading in the trim window; gray distinguishes
# rejected ("discarded") intervals.
_IV_COLOR, _DIS_COLOR = "#f38ba8", "#585b70"
# Paged-view half-window for the gaze canvas — 8 seconds wide.
_WIN_SEC = 8.0


class _Signals(QObject):
    eeg_loaded = Signal(object, object, float, list)  # raw, picks, sfreq, names
    # Envelope, duration_s — emitted after the background min/max loop
    # finishes building the preview-strip data.  Mirrors the trim
    # window's signal so the same envelope-builder code can be reused.
    eeg_strip_loaded = Signal(object, float)
    # current_chunk, total_chunks — drives the EEG-load progress bar
    # while the envelope is building.
    eeg_strip_progress = Signal(int, int)
    eeg_error = Signal(str)
    progress = Signal(int, int, float, bool, object)
    interval = Signal(float, float)
    done = Signal(list)
    error = Signal(str)
    cancelled = Signal()


class EegCanvasQt(EegPagedCanvas):
    """Gaze-review EEG canvas — paged 8 s window with accepted /
    rejected / trim interval shading drawn behind the traces.

    All paint logic (theme palette, label gutter, lazy windowing,
    annotation overlay) is inherited from
    :class:`~_eeg_paint.EegPagedCanvas`; this subclass only adds the
    review-specific underlay.
    """

    def __init__(self, parent=None):
        super().__init__(parent, window_sec=_WIN_SEC)
        self.setMinimumSize(500, 300)
        self.intervals: List[NotLookingInterval] = []

    def draw(self, current_time, intervals):
        """Set cursor + intervals and trigger a repaint.  Mirrors the
        old eager-canvas API so the window code doesn't change."""
        self.cursor_time = float(current_time)
        self.intervals = list(intervals)
        self.update()

    def paint_underlay(self, p, t0, t1, x_left, w, h, tx, y_top=0):
        """Paint accepted/rejected/trim interval shading + dashed
        trim boundaries within the trace area only — the base canvas
        passes ``(y_top, h)`` so we don't bleed into the reserved
        annotation / time-axis strips."""
        # Translucent shading rectangles
        for iv in self.intervals:
            if iv.end_sec < t0 or iv.start_sec > t1:
                continue
            x0 = max(x_left, tx(max(iv.start_sec, t0)))
            x1 = min(w, tx(min(iv.end_sec, t1)))
            if x1 <= x0:
                continue
            if iv.status == "accepted":
                c = QColor(_IV_COLOR)        # pink — not-looking, kept
            else:                            # "discarded" or "trim"
                c = QColor(_DIS_COLOR)       # gray
            c.setAlpha(64)
            p.fillRect(QRectF(x0, y_top, x1 - x0, h), c)
        # Dashed boundary lines for trim regions only
        for iv in self.intervals:
            if iv.status != "trim":
                continue
            for edge in (iv.start_sec, iv.end_sec):
                if t0 < edge < t1:
                    p.setPen(QPen(QColor(TRIM_BD), 2, Qt.DashLine))
                    p.drawLine(int(tx(edge)), y_top,
                               int(tx(edge)), y_top + h)


class ReviewVideoArtifactsWindowQt(QMainWindow):
    """Qt6 window for reviewing facetag not_looking intervals."""
    VIDEO_WIDTH = 480

    def __init__(self, parent=None, video_path="", reference_dir="",
                 eeg_path=None, on_close=None,
                 ignore_before=0.0, ignore_after=0.0, trim_end=None,
                 frame_skip=1, downscale=1.0, results_json=None,
                 max_angle=10.0, ref_use_roi=False,
                 face_tolerance=0.6, min_interval=0.0,
                 no_face_is_artifact=True, backend_name="insightface",
                 tracking_adapt_rate=0.15, position_weight=0.4,
                 size_weight=0.2, switch_resistance=0.25,
                 insightface_det_size=0, auto_run=False,
                 exclude_dir="", gaze_method="insightface",
                 gaze_smoothing=0.3, output_dir=""):
        super().__init__(parent)
        self.video_path, self.reference_dir = video_path, reference_dir
        # Per-recording preproc output dir for the canonical
        # ``_facetag_<backend>_review.json`` path.  Required when the
        # window is opened from the GUI (``IDE4EEG_OUT_*/preprocessing/``
        # supplied by ``_fallback_preproc_path``).  When empty (e.g.
        # ad-hoc launch via ``__main__``) the window falls back to
        # writing the JSON next to the video file.
        self._output_dir = output_dir
        self.eeg_path, self._on_close_cb = eeg_path, on_close
        self.ignore_before = max(0.0, float(ignore_before))
        self.ignore_after = max(0.0, float(ignore_after))
        self._trim_end = trim_end
        self.frame_skip = max(1, int(frame_skip))
        self.downscale = max(0.1, min(1.0, float(downscale)))
        self.max_angle, self.ref_use_roi = float(max_angle), bool(ref_use_roi)
        self.face_tolerance = float(face_tolerance)
        self.min_interval = float(min_interval)
        self.no_face_is_artifact = bool(no_face_is_artifact)
        self.backend_name = backend_name
        self.tracking_adapt_rate = float(tracking_adapt_rate)
        self.position_weight = float(position_weight)
        self.size_weight, self.switch_resistance = float(size_weight), float(switch_resistance)
        self.insightface_det_size = int(insightface_det_size)
        self.exclude_dir = exclude_dir or ""
        self.gaze_method, self.gaze_smoothing = gaze_method, float(gaze_smoothing)
        self.reader: Optional[VideoReader] = None
        self.current_time, self.duration, self.fps = 0.0, 0.0, 30.0
        self.intervals: List[NotLookingInterval] = []
        self._seeking, self._closed = False, False
        self._compute_cancel: Optional[threading.Event] = None
        _gl = {"insightface": "InsightFace (head orientation)",
               "l2cs": "L2CS-Net (eye gaze)"}
        self.setWindowTitle(f"Review Video Artifacts \u2014 {_gl.get(self.gaze_method, self.gaze_method)}")
        self.setMinimumSize(1000, 700)
        self._sig = _Signals()
        self._sig.eeg_loaded.connect(self._on_eeg_loaded)
        self._sig.eeg_strip_loaded.connect(self._on_eeg_strip_loaded)
        self._sig.eeg_strip_progress.connect(self._on_eeg_strip_progress)
        self._sig.eeg_error.connect(lambda m: self.statusBar().showMessage(f"EEG: {m}"))
        self._sig.progress.connect(self._on_progress)
        self._sig.interval.connect(self._on_interval)
        self._sig.done.connect(self._on_done)
        self._sig.error.connect(self._on_error)
        self._sig.cancelled.connect(self._on_cancelled)
        self._build_ui(); self._open_video()
        if eeg_path: self._load_eeg_bg(eeg_path)
        loaded = False
        if results_json and os.path.isfile(results_json):
            try:
                rd = ReviewData.load(results_json)
                self.intervals = rd.intervals; self._refresh_table()
                self.eeg_canvas.draw(self.current_time, self._all_ivs())
                self.statusBar().showMessage(
                    f"Loaded {len(self.intervals)} interval(s) from {os.path.basename(results_json)}")
                loaded = True
            except Exception as e:
                self.statusBar().showMessage(f"Could not load results: {e}")
        if auto_run and not loaded:
            QTimer.singleShot(300, self._compute_now)

    def _build_ui(self):
        cw = QWidget(); self.setCentralWidget(cw)
        ml = QVBoxLayout(cw); ml.setContentsMargins(4,4,4,4); ml.setSpacing(4)
        # Top: video + table
        sp = QSplitter(Qt.Horizontal)
        vc = QWidget(); vv = QVBoxLayout(vc); vv.setContentsMargins(0,0,0,0)
        self.video_label = QLabel()
        self.video_label.setFixedSize(self.VIDEO_WIDTH, 360)
        self.video_label.setStyleSheet("background-color:black;")
        self.video_label.setAlignment(Qt.AlignCenter); vv.addWidget(self.video_label)
        self._trim_lbl = QLabel()
        self._trim_lbl.setStyleSheet(f"color:{TRIM_BD};background:{_SURFACE0};padding:4px;")
        self._trim_lbl.setVisible(False); vv.addWidget(self._trim_lbl); vv.addStretch()
        sp.addWidget(vc)
        tc = QWidget(); tv = QVBoxLayout(tc); tv.setContentsMargins(0,0,0,0)
        tl = QLabel("Not-Looking Intervals"); tl.setStyleSheet("font-weight:bold;"); tv.addWidget(tl)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Start","End","Duration","Status"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.doubleClicked.connect(self._on_dblclick)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._ctx_menu); tv.addWidget(self.table)
        ib = QHBoxLayout()
        for txt, st in [("Confirm Artifact","accepted"),("Dismiss Detection","rejected")]:
            b = QPushButton(txt); b.clicked.connect(lambda _,s=st: self._set_status(s)); ib.addWidget(b)
        bg = QPushButton("Go to Interval"); bg.clicked.connect(self._jump_sel); ib.addWidget(bg)
        ib.addStretch(); tv.addLayout(ib)
        sp.addWidget(tc); sp.setStretchFactor(0,0); sp.setStretchFactor(1,1)
        ml.addWidget(sp)
        # EEG canvas — click / drag-pan / mouse-wheel scroll all
        # emit `clicked(t)` which we route through `_seek` so the
        # video frame, slider, strip cursor and time label all stay
        # in lockstep with whatever the user just dialled in.
        self.eeg_canvas = EegCanvasQt(self); ml.addWidget(self.eeg_canvas, stretch=1)
        self.eeg_canvas.clicked.connect(self._seek)
        self.eeg_canvas.setToolTip(
            "Drag horizontally to pan, mouse-wheel to scroll, "
            "click to seek.\nVideo frame and EEG canvas stay in "
            "sync.")
        # Whole-recording preview strip — same compressed-timeline
        # widget as the Preview & Trim window.  Click anywhere to seek;
        # cursor follows the canvas / slider position.
        self.eeg_strip = EegStripQt(self)
        self.eeg_strip.clicked.connect(self._seek)
        self.eeg_strip.setToolTip(
            "Min/max envelope of the full recording.\n"
            "Click anywhere to seek.")
        ml.addWidget(self.eeg_strip)
        # Timeline
        tl2 = QHBoxLayout()
        for txt, dt in [("<<",-5),("<",-1)]:
            b = QPushButton(txt); b.setFixedWidth(40); b.clicked.connect(lambda _,d=dt: self._step(d)); tl2.addWidget(b)
        self.slider = QSlider(Qt.Horizontal); self.slider.setMinimum(0); self.slider.setMaximum(1000)
        self.slider.valueChanged.connect(self._on_slider); tl2.addWidget(self.slider, stretch=1)
        for txt, dt in [(">",1),(">>",5)]:
            b = QPushButton(txt); b.setFixedWidth(40); b.clicked.connect(lambda _,d=dt: self._step(d)); tl2.addWidget(b)
        self.time_label = QLabel("00:00.00"); self.time_label.setFixedWidth(90)
        self.time_label.setFont(QFont("Menlo",11)); tl2.addWidget(self.time_label)
        tl2.addSpacing(12)
        # Amplitude controls — same affordance as the trim window
        amp_dn = QPushButton("–"); amp_dn.setFixedWidth(28)
        amp_dn.setToolTip("Decrease amplitude")
        amp_dn.clicked.connect(lambda: self._set_amp(0.5))
        tl2.addWidget(amp_dn)
        self._amp_label = QLabel("1.0×")
        self._amp_label.setFixedWidth(40)
        self._amp_label.setAlignment(Qt.AlignCenter)
        tl2.addWidget(self._amp_label)
        amp_up = QPushButton("+"); amp_up.setFixedWidth(28)
        amp_up.setToolTip("Increase amplitude")
        amp_up.clicked.connect(lambda: self._set_amp(2.0))
        tl2.addWidget(amp_up)
        tl2.addSpacing(12)
        # DC removal toggle — same affordance as the trim window
        self._dc_check = QCheckBox("DC removal")
        self._dc_check.setChecked(True)
        self._dc_check.setToolTip(
            "Subtract per-channel mean (removes DC offset)")
        self._dc_check.stateChanged.connect(self._on_dc_toggle)
        tl2.addWidget(self._dc_check)
        self._fullres = QCheckBox("Full res")
        self._fullres.toggled.connect(lambda: self._seek(self.current_time)); tl2.addWidget(self._fullres)
        ml.addLayout(tl2)
        # EEG-load progress bar (hidden once envelope finishes)
        self._eeg_load_prog = QProgressBar()
        self._eeg_load_prog.setRange(0, 100)
        self._eeg_load_prog.setFixedHeight(14)
        self._eeg_load_prog.hide()
        ml.addWidget(self._eeg_load_prog)
        # Bottom buttons
        bot = QHBoxLayout()
        bl = QPushButton("Load Previous Results"); bl.clicked.connect(self._load_results); bot.addWidget(bl)
        self.compute_btn = QPushButton("Run Detection"); self.compute_btn.clicked.connect(self._compute_now); bot.addWidget(self.compute_btn)
        bs = QPushButton("Save Changes"); bs.clicked.connect(self._save_overrides); bot.addWidget(bs)
        bot.addStretch()
        bc = QPushButton("Close"); bc.clicked.connect(self.close); bot.addWidget(bc)
        ml.addLayout(bot)
        # Progress bar (hidden)
        self._prog_w = QWidget(); pl = QHBoxLayout(self._prog_w); pl.setContentsMargins(0,0,0,0)
        self._prog_bar = QProgressBar(); self._prog_bar.setRange(0,100); pl.addWidget(self._prog_bar, stretch=1)
        self._prog_lbl = QLabel(""); self._prog_lbl.setFixedWidth(140); pl.addWidget(self._prog_lbl)
        self._prog_w.setVisible(False); ml.addWidget(self._prog_w)
        self.statusBar().showMessage("Ready")

    # --- Video ---
    def _open_video(self):
        try:
            self.reader = VideoReader(self.video_path)
            self.fps = self.reader.fps
            self.duration = self.reader.total_frames / self.fps
            if self._trim_end is not None and self.duration > 0:
                self.ignore_after = max(0.0, self.duration - float(self._trim_end))
            self.slider.setMaximum(int(self.duration * 1000))
            if self.ignore_before > 0 or self.ignore_after > 0:
                cs, ce = self.ignore_before, self.duration - self.ignore_after
                self._trim_lbl.setText(f"Active: {fmt_time(cs)} \u2013 {fmt_time(ce)}  |  grey=trimmed, pink=not-looking")
                self._trim_lbl.setVisible(True)
            self._seek(self.ignore_before)
        except Exception as e:
            self.statusBar().showMessage(f"Video error: {e}")

    def _show_frame(self, frame_num, face_box=None, not_looking=None):
        if not self.reader: return
        frame_num = max(0, min(frame_num, self.reader.total_frames - 1))
        bgr = self.reader.read_frame(frame_num)
        if bgr is None: return
        if face_box is not None:
            import cv2
            top, right, bottom, left = face_box
            clr = (0,0,255) if not_looking else (0,255,0)
            cv2.rectangle(bgr, (left,top), (right,bottom), clr, 2)
            cv2.putText(bgr, "NOT LOOKING" if not_looking else "LOOKING",
                        (left, max(top-8,12)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, clr, 2)
        rgb = bgr[:,:,::-1].copy(); h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch*w, QImage.Format_RGB888)
        pm = QPixmap.fromImage(qimg)
        if not self._fullres.isChecked():
            pm = pm.scaledToWidth(self.VIDEO_WIDTH, Qt.SmoothTransformation)
        self.video_label.setFixedSize(pm.width(), pm.height())
        self.video_label.setPixmap(pm)

    # --- Trim / intervals helpers ---
    def _trim_ivs(self):
        t = []
        if self.ignore_before > 0 and self.duration > 0:
            t.append(NotLookingInterval(0.0, min(self.ignore_before, self.duration), status="trim"))
        if self.ignore_after > 0 and self.duration > 0:
            t.append(NotLookingInterval(max(0.0, self.duration-self.ignore_after), self.duration, status="trim"))
        return t

    def _all_ivs(self):
        return self._trim_ivs() + self.intervals

    # --- Seeking ---
    def _seek(self, t):
        if self._seeking: return
        self._seeking = True
        try:
            t = max(0.0, min(t, self.duration)); self.current_time = t
            self._show_frame(int(t * self.fps))
            self.eeg_canvas.draw(t, self._all_ivs())
            self.time_label.setText(fmt_time(t))
            self.slider.setValue(int(t * 1000)); self._hl_iv(t)
            self.eeg_strip.set_cursor(t)
        finally:
            self._seeking = False

    def _hl_iv(self, t):
        for i, iv in enumerate(self.intervals):
            if iv.start_sec <= t <= iv.end_sec:
                self.table.selectRow(i); self.table.scrollTo(self.table.model().index(i,0)); return
        self.table.clearSelection()

    def _step(self, d): self._seek(self.current_time + d)

    def _on_slider(self, v):
        if self._seeking: return
        self._seeking = True
        try:
            t = max(0.0, min(v / 1000.0, self.duration)); self.current_time = t
            self._show_frame(int(t * self.fps))
            self.time_label.setText(fmt_time(t))
            self.eeg_canvas.draw(t, self._all_ivs()); self._hl_iv(t)
            self.eeg_strip.set_cursor(t)
        finally:
            self._seeking = False

    # --- Amplitude / DC ---
    def _set_amp(self, factor):
        self.eeg_canvas.amp_scale *= factor
        self._amp_label.setText(f"{self.eeg_canvas.amp_scale:.1f}×")
        self.eeg_canvas.update()

    def _on_dc_toggle(self, state):
        self.eeg_canvas.dc_remove = bool(state)
        self.eeg_canvas._apply_dc()
        self.eeg_canvas.update()

    # --- Interval table ---
    def _refresh_table(self):
        self.table.setRowCount(len(self.intervals))
        for i, iv in enumerate(self.intervals):
            self.table.setItem(i, 0, QTableWidgetItem(fmt_time(iv.start_sec)))
            self.table.setItem(i, 1, QTableWidgetItem(fmt_time(iv.end_sec)))
            self.table.setItem(i, 2, QTableWidgetItem(f"{iv.duration:.2f}s"))
            si = QTableWidgetItem(iv.status)
            si.setBackground(QColor(_IV_COLOR if iv.status == "accepted" else _DIS_COLOR))
            self.table.setItem(i, 3, si)

    def _on_dblclick(self, idx):
        r = idx.row()
        if 0 <= r < len(self.intervals): self._seek(self.intervals[r].start_sec)

    def _jump_sel(self):
        rows = self.table.selectionModel().selectedRows()
        if rows and 0 <= rows[0].row() < len(self.intervals):
            self._seek(self.intervals[rows[0].row()].start_sec)

    def _set_status(self, status):
        for idx in self.table.selectionModel().selectedRows():
            r = idx.row()
            if 0 <= r < len(self.intervals): self.intervals[r].status = status
        self._refresh_table(); self.eeg_canvas.draw(self.current_time, self._all_ivs())

    def _ctx_menu(self, pos):
        m = QMenu(self)
        aa = m.addAction("Accept (confirm artifact)")
        ar = m.addAction("Reject (dismiss detection)"); m.addSeparator()
        ad = m.addAction("Delete interval"); m.addSeparator()
        ag = m.addAction("Go to interval")
        act = m.exec(self.table.viewport().mapToGlobal(pos))
        if act == aa: self._set_status("accepted")
        elif act == ar: self._set_status("rejected")
        elif act == ad:
            for r in sorted([i.row() for i in self.table.selectionModel().selectedRows()], reverse=True):
                if 0 <= r < len(self.intervals): del self.intervals[r]
            self._refresh_table(); self.eeg_canvas.draw(self.current_time, self._all_ivs())
        elif act == ag: self._jump_sel()

    # --- EEG loading (lazy via the canvas's MNE Raw handle) ---
    def _load_eeg_bg(self, eeg_path):
        self.statusBar().showMessage("Loading EEG..."); sig = self._sig
        def worker():
            try:
                import mne, os
                raw = None
                ext = os.path.splitext(eeg_path)[1].lower()
                try:
                    if ext == ".raw":
                        from ...input.input import read_file
                        raw, _ = read_file(eeg_path)
                    elif ext == ".vhdr":
                        raw = mne.io.read_raw_brainvision(
                            eeg_path, preload=False, verbose=False)
                    elif ext == ".fif":
                        raw = mne.io.read_raw_fif(
                            eeg_path, preload=False, verbose=False)
                    elif ext == ".edf":
                        raw = mne.io.read_raw_edf(
                            eeg_path, preload=False, verbose=False)
                    elif ext == ".bdf":
                        raw = mne.io.read_raw_bdf(
                            eeg_path, preload=False, verbose=False)
                    elif ext == ".set":
                        raw = mne.io.read_raw_eeglab(
                            eeg_path, preload=False, verbose=False)
                    else:
                        raw = mne.io.read_raw(
                            eeg_path, preload=False, verbose=False)
                except Exception:
                    pass
                if raw is None:
                    sig.eeg_error.emit("Could not read EEG file"); return
                picks, names = [], []
                for i, ch in enumerate(raw.info["ch_names"]):
                    cl = ch.lower()
                    if not any(x in cl for x in (
                            "stim", "eog", "emg", "ecg", "misc",
                            "resp", "trigger", "status")):
                        picks.append(i); names.append(ch)
                if not picks:
                    picks = list(range(min(16, len(raw.info["ch_names"]))))
                    names = [raw.info["ch_names"][i] for i in picks]
                if len(picks) > 16:
                    s = len(picks) // 16
                    picks, names = picks[::s][:16], names[::s][:16]
                # Emit raw handle + picks immediately so the canvas
                # comes up before the envelope loop finishes.
                n_total = raw.n_times
                sfreq = raw.info["sfreq"]
                duration_s = n_total / sfreq
                sig.eeg_loaded.emit(raw, picks, sfreq, names)
                # Build the min/max envelope for the preview strip.
                # Same chunked reduction as the trim window — bounded
                # peak working memory ~25 MB, faithful to slow drift
                # across the whole recording.
                import warnings
                W = 1000  # envelope columns; cached pixmap re-renders on resize
                n_picks = len(picks)
                samples_per_col = n_total // W
                envelope = None
                if samples_per_col >= 1 and n_picks > 0:
                    envelope = np.empty((n_picks, W, 2), dtype=np.float32)
                    max_chunk_samples = max(
                        1, (25 * 1024 * 1024) // (8 * n_picks))
                    cols_per_chunk = max(1, min(
                        W, max_chunk_samples // max(1, samples_per_col)))
                    n_chunks = (W + cols_per_chunk - 1) // cols_per_chunk
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        for c in range(n_chunks):
                            col0 = c * cols_per_chunk
                            col1 = min(col0 + cols_per_chunk, W)
                            s0 = col0 * samples_per_col
                            s1 = col1 * samples_per_col
                            chunk = raw.get_data(
                                picks=picks, start=s0, stop=s1)
                            actual_cols = col1 - col0
                            chunk = chunk[:, :actual_cols * samples_per_col]
                            chunk = chunk.reshape(
                                n_picks, actual_cols, samples_per_col)
                            envelope[:, col0:col1, 0] = chunk.min(axis=2)
                            envelope[:, col0:col1, 1] = chunk.max(axis=2)
                            sig.eeg_strip_progress.emit(c + 1, n_chunks)
                sig.eeg_strip_loaded.emit(envelope, duration_s)
            except Exception as e: sig.eeg_error.emit(str(e))
        threading.Thread(target=worker, daemon=True).start()

    def _on_eeg_loaded(self, raw, picks, sfreq, names):
        self.eeg_canvas.load_lazy(raw, picks, sfreq, names)
        self.eeg_canvas.draw(self.current_time, self._all_ivs())
        self.statusBar().showMessage(
            f"EEG loaded: {len(names)} ch at {sfreq:.0f} Hz — "
            f"strip filling in background")

    def _on_eeg_strip_loaded(self, envelope, duration_s):
        """Populate the preview strip once the envelope loop finishes."""
        self._eeg_load_prog.hide()
        strip_dur = self.duration if self.duration > 0 else duration_s
        if envelope is not None:
            self.eeg_strip.load(envelope, strip_dur)
        self.eeg_strip.set_cursor(self.current_time)
        # Trim shading on the strip mirrors the canvas's ignore_before
        # / ignore_after.  ``trim_end`` is the right edge of the
        # active segment (None means "to end of recording").
        ts = self.ignore_before
        te = (self.duration - self.ignore_after) if self.ignore_after > 0 else None
        self.eeg_strip.set_trim(ts, te)
        if envelope is None:
            self.statusBar().showMessage(
                "EEG strip skipped (recording too short)")
        else:
            # Clear the "strip filling in background" message left
            # over from _on_eeg_loaded — without this the user sees
            # a stale "filling…" notice indefinitely after the
            # background strip computation has actually finished.
            self.statusBar().showMessage("Ready", 3000)

    def _on_eeg_strip_progress(self, current, total):
        if total <= 0:
            return
        self._eeg_load_prog.setRange(0, total)
        self._eeg_load_prog.setValue(current)
        self._eeg_load_prog.show()

    # --- Compute facetag ---
    def _compute_now(self):
        if not self.reference_dir or not os.path.isdir(self.reference_dir):
            QMessageBox.critical(self, "Error", "Reference directory not set or not found."); return
        self.compute_btn.setEnabled(False)
        # The first run takes 5-15s before the first frame ships
        # (gaze backend has to load model weights + build the CUDA /
        # ONNX session, all in the worker thread before any progress
        # callback fires).  Flip the bar to indeterminate "busy" mode
        # with a hint label so the dialog isn't visibly stuck at 0%;
        # _on_progress flips it back to determinate on the first
        # frame callback.
        self._prog_w.setVisible(True)
        self._prog_bar.setRange(0, 0)
        self._prog_lbl.setText("Loading model…")
        self.statusBar().showMessage(
            "Loading gaze model… (first run takes a few seconds)")
        self.intervals.clear(); self._refresh_table()
        ib, ia = self.ignore_before, self.ignore_after
        end_limit = self.duration - ia if ia > 0 else self.duration
        logging.info("FaceTag: ref=%s skip=%d ds=%.2f range=%.1f-%.1fs",
                     self.reference_dir, self.frame_skip, self.downscale, ib, end_limit)
        self._compute_cancel = threading.Event(); sig, cancel = self._sig, self._compute_cancel
        def on_prog(cur, tot, ct=0.0, nl=False, fb=None, face_box=None):
            if cancel.is_set(): raise InterruptedError
            sig.progress.emit(cur, tot, ct, nl, face_box or fb)
        def on_iv(s, e): sig.interval.emit(s, e)
        def worker():
            try:
                from . import facetag_video
                _r, tags, _st = facetag_video(
                    self.video_path, self.reference_dir,
                    progress_callback=on_prog, interval_callback=on_iv,
                    frame_skip=self.frame_skip, downscale=self.downscale,
                    start_time=ib, end_time=end_limit,
                    max_angle=self.max_angle, ref_use_roi=self.ref_use_roi,
                    face_tolerance=self.face_tolerance, min_interval=self.min_interval,
                    no_face_is_artifact=self.no_face_is_artifact,
                    backend_name=self.backend_name,
                    tracking_adapt_rate=self.tracking_adapt_rate,
                    position_weight=self.position_weight,
                    size_weight=self.size_weight, switch_resistance=self.switch_resistance,
                    insightface_det_size=self.insightface_det_size,
                    exclude_dir=self.exclude_dir or None,
                    gaze_method=self.gaze_method, gaze_smoothing=self.gaze_smoothing)
                ivs = [NotLookingInterval(t["start_timestamp"], t["end_timestamp"])
                       for t in tags if t["end_timestamp"] > t["start_timestamp"]]
                sig.done.emit(ivs)
            except InterruptedError: sig.cancelled.emit()
            except Exception as e: logging.exception("Facetag failed"); sig.error.emit(str(e))
        threading.Thread(target=worker, daemon=True).start()

    def _on_progress(self, cur, tot, ct, nl, fb):
        if self._closed: return
        # First callback: flip from "Loading model\u2026" indeterminate
        # busy bar back to determinate percentage display.
        if self._prog_bar.maximum() == 0:
            self._prog_bar.setRange(0, 100)
        pct = cur/tot*100 if tot else 0
        self._prog_bar.setValue(int(pct))
        self._prog_lbl.setText(f"{cur}/{tot} ({pct:.0f}%)")
        self.statusBar().showMessage(f"Computing... {cur}/{tot} \u2014 {'NOT LOOKING' if nl else 'looking'}")
        try:
            self._show_frame(int(ct*self.fps), face_box=fb, not_looking=nl)
            self.current_time = ct; self.eeg_canvas.draw(ct, self._all_ivs())
            self.time_label.setText(fmt_time(ct))
            self._seeking = True; self.slider.setValue(int(ct*1000)); self._seeking = False
            self.eeg_strip.set_cursor(ct)
        except Exception as e: logging.debug("FaceTag display: %s", e)

    def _on_interval(self, ss, es):
        iv = NotLookingInterval(ss, es); self.intervals.append(iv)
        r = self.table.rowCount(); self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(fmt_time(ss)))
        self.table.setItem(r, 1, QTableWidgetItem(fmt_time(es)))
        self.table.setItem(r, 2, QTableWidgetItem(f"{iv.duration:.2f}s"))
        si = QTableWidgetItem(iv.status); si.setBackground(QColor(_IV_COLOR))
        self.table.setItem(r, 3, si)

    def _on_done(self, intervals):
        self.compute_btn.setEnabled(True); self._prog_w.setVisible(False)
        self.intervals = intervals; self._refresh_table(); self._seek(self.ignore_before)
        n = len(self.intervals)
        try:
            jp = self._json_path()
            ReviewData(self.video_path, self.reference_dir, self.intervals,
                       datetime.datetime.now().isoformat()).save(jp)
            self._save_tags(os.path.splitext(jp)[0] + ".tag")
            self.statusBar().showMessage(f"Done: {n} intervals \u2014 saved to {os.path.basename(jp)}")
        except Exception as e:
            logging.warning("FaceTag: auto-save failed: %s", e)
            self.statusBar().showMessage(f"Done: {n} intervals (save failed: {e})")

    def _on_error(self, msg):
        self.compute_btn.setEnabled(True); self._prog_w.setVisible(False)
        self.statusBar().showMessage(f"Error: {msg}"); QMessageBox.critical(self, "Compute Error", msg)

    def _on_cancelled(self):
        self.compute_btn.setEnabled(True); self._prog_w.setVisible(False)
        self.statusBar().showMessage("Detection cancelled")

    # --- Load / Save ---
    def _json_path(self):
        """Canonical path for the review JSON.

        Always uses the per-recording preproc output dir supplied by
        the GUI (``output_dir`` ctor arg).  Raises ``ValueError`` if
        ``output_dir`` is empty — the ad-hoc ``__main__`` launch must
        pass one explicitly; legacy next-to-video JSONs are no longer
        auto-located.
        """
        from .review_window import review_json_path
        if not self._output_dir:
            raise ValueError(
                "ReviewVideoArtifactsWindowQt requires output_dir for "
                "JSON save/load — the canonical per-recording preproc "
                "dir.  Legacy next-to-video JSONs are no longer "
                "supported.")
        return review_json_path(
            self._output_dir, self.video_path, self.backend_name)

    def _load_results(self):
        dp = self._json_path()
        path, _ = QFileDialog.getOpenFileName(self, "Load results", os.path.dirname(dp),
                                               "JSON (*.json);;All (*.*)")
        if not path: return
        try:
            rd = ReviewData.load(path); self.intervals = rd.intervals
            self._refresh_table(); self.eeg_canvas.draw(self.current_time, self._all_ivs())
            self.statusBar().showMessage(f"Loaded {len(self.intervals)} intervals from {os.path.basename(path)}")
        except Exception as e: QMessageBox.critical(self, "Load Error", str(e))

    def _save_overrides(self):
        dp = self._json_path()
        path, _ = QFileDialog.getSaveFileName(self, "Save results", dp, "JSON (*.json);;All (*.*)")
        if not path: return
        try:
            ReviewData(self.video_path, self.reference_dir, self.intervals,
                       datetime.datetime.now().isoformat()).save(path)
            self._save_tags(os.path.splitext(path)[0] + ".tag")
            self.statusBar().showMessage(f"Saved to {os.path.basename(path)} + .tag")
        except Exception as e: QMessageBox.critical(self, "Save Error", str(e))

    def _save_tags(self, tag_path):
        from obci_readmanager.signal_processing.tags.tags_file_writer import TagsFileWriter
        w = TagsFileWriter(tag_path)
        if self.ignore_before > 0 and self.duration > 0:
            w.tag_received({"channelNumber":-1, "start_timestamp":0.0,
                            "end_timestamp":min(self.ignore_before, self.duration),
                            "name":"ignored", "desc":{"typ":"user_trim"}})
        if self.ignore_after > 0 and self.duration > 0:
            w.tag_received({"channelNumber":-1, "start_timestamp":max(0.0, self.duration-self.ignore_after),
                            "end_timestamp":self.duration, "name":"ignored", "desc":{"typ":"user_trim"}})
        for iv in self.intervals:
            if iv.status == "accepted":
                w.tag_received({"channelNumber":-1, "start_timestamp":iv.start_sec,
                                "end_timestamp":iv.end_sec, "name":"not_looking", "desc":{"typ":"video"}})
        w.finish_saving(0.0)

    def closeEvent(self, event):  # noqa: N802
        self._closed = True
        if self._compute_cancel: self._compute_cancel.set()
        if self.reader: self.reader.release()
        if self._on_close_cb: self._on_close_cb()
        event.accept()


if __name__ == "__main__":
    import sys
    if not _HAS_QT: print("PySide6 required"); sys.exit(1)
    app = QApplication.instance() or QApplication(sys.argv)
    if len(sys.argv) < 3:
        print("Usage: review_window_qt.py <video> <ref_dir> [eeg]"); sys.exit(1)
    kw = {"eeg_path": sys.argv[3]} if len(sys.argv) >= 4 else {}
    win = ReviewVideoArtifactsWindowQt(None, sys.argv[1], sys.argv[2], **kw)
    win.show(); sys.exit(app.exec())
