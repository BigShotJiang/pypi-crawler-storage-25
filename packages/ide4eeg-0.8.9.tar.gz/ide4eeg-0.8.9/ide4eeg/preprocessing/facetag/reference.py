"""Reference face data for subject identification and gaze checking.

Holds subject face encodings (identity) and gaze vectors loaded from
reference photos.  At runtime, ``find_face`` uses the InsightFace backend
for face detection and identity matching, while ``check_gaze`` delegates
to the selected gaze backend (InsightFace or L2CS-Net) for gaze direction.
"""
# Author: Piotr Durka, 2026

import os
import warnings

try:
    import cv2
except ImportError:
    cv2 = None
import numpy as np


_VIDEO_STACK_HINT = (
    "Facetag features require the video stack — install via "
    "`pip install ide4eeg[video]` or use the full .exe variant.")


# Recommended face_tolerance (InsightFace cosine distance)
BACKEND_DEFAULTS = {
    "insightface": {"face_tolerance": 0.4},
}


def get_backend(name="insightface"):
    """Return the face-detection backend module.

    Parameters
    ----------
    name : str
        ``"insightface"`` (only supported backend).

    Raises
    ------
    ImportError
        If the required package is not installed.
    """
    try:
        import insightface as _if  # noqa: F401
    except ImportError:
        raise ImportError(
            "InsightFace backend requires 'insightface' and "
            "'onnxruntime'.\n"
            "Install with: pip install insightface onnxruntime")
    from . import insightface_backend
    return insightface_backend


def _get_gaze_module(method="insightface"):
    """Return the gaze estimation module for *method*.

    Parameters
    ----------
    method : str
        ``"insightface"`` (default) or ``"l2cs"``.
        Unknown values fall back to InsightFace.
    """
    if method == "l2cs":
        # Probe BOTH deps upfront so a missing one produces the
        # canonical "use the Config tab Download button" message
        # instead of bubbling up from a deep call inside l2cs_gaze
        # (e.g. ``from l2cs import getArch`` in ``_get_model``).
        from ide4eeg.download_tools import (
            L2CS_GIT_URL, l2cs_missing_deps)
        missing = l2cs_missing_deps()
        if missing:
            raise ImportError(
                "L2CS gaze backend requires "
                + " + ".join(missing) + " (not installed).\n"
                "GUI: click 'Download recent' next to "
                "'L2CS-Net (gaze detection)' on the Config tab.\n"
                f"CLI: pip install torch \"{L2CS_GIT_URL}\"")
        from . import l2cs_gaze
        return l2cs_gaze
    from . import insightface_gaze
    return insightface_gaze

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


class ReferenceData:
    """Subject face encodings, gaze vectors, and optional exclude encodings.

    Face matching pipeline (per frame, in ``find_face`` → ``check_looking``):

    1. Backend detects faces and computes identity encodings.
    2. ``_score_candidate`` selects the best match:
       - exclude gate (``_exclude_distance`` ≤ ``_static_distance`` → reject),
       - tolerance hard gate (unknown face → reject),
       - adaptive encoding + spatial/size/switch tracking.
    3. ``check_gaze`` passes the matched face ROI to the selected gaze
       backend (InsightFace or L2CS-Net):
       - eyes closed → assume "looking" (gaze vector unreliable),
       - otherwise compare gaze vector against reference vectors.
    """

    def __init__(self, encodings, vectors, max_angle=10.0,
                 face_tolerance=0.6, backend=None,
                 tracking_adapt_rate=0.15, position_weight=0.4,
                 size_weight=0.2, switch_resistance=0.25,
                 exclude_encodings=None, gaze_method="insightface",
                 gaze_smoothing=0.3):
        self.encodings = encodings
        self.vectors = vectors
        self.baseline_vector = np.mean(self.vectors, axis=0)
        self.max_angle = max_angle
        self.face_tolerance = face_tolerance
        self._backend = backend if backend is not None else get_backend()
        self._gaze_module = _get_gaze_module(gaze_method)
        # Tracking parameters
        self._ADAPTIVE_ALPHA = float(tracking_adapt_rate)
        self._SPATIAL_WEIGHT = float(position_weight)
        self._SIZE_WEIGHT = float(size_weight)
        self._SWITCH_PENALTY = float(switch_resistance)
        # Gaze smoothing (EMA): 0 = off, 1 = use only current frame
        self._gaze_smoothing = max(0.0, min(1.0, float(gaze_smoothing)))
        self._smoothed_vector = None
        # Tracking state
        self._last_location = None
        self._last_kps = None
        self._last_face_size = None
        self._adaptive_enc = None  # running-average encoding
        self._frame_count = 0      # for periodic re-anchor
        self._REANCHOR_EVERY = 30   # re-check static refs every N frames
        self._DRIFT_CAP = face_tolerance * 1.2  # max adaptive drift
        self._exclude_encodings = exclude_encodings or []
        self._gaze_timestamp_ms = 0   # monotonic counter for VIDEO mode
        # Diagnostic counters (drained by facetag_video at end of run).
        # Track find_face entries vs how many actually ran InsightFace
        # detection — when the two diverge wildly, the per-frame cache
        # short-circuit is firing more than expected.
        self._diag_calls_total = 0
        self._diag_calls_inference = 0
        self._diag_no_face = 0

    def _static_distance(self, encoding):
        """Min distance from *encoding* to the original static references."""
        d = self._backend.face_distances(self.encodings, encoding)
        return float(np.min(d)) if len(d) else float("inf")

    def _exclude_distance(self, encoding):
        """Min distance from *encoding* to the exclude reference encodings."""
        if not self._exclude_encodings:
            return float("inf")
        d = self._backend.face_distances(self._exclude_encodings, encoding)
        return float(np.min(d)) if len(d) else float("inf")

    def _score_candidate(self, location, encoding, use_adaptive=True):
        """Compute a match score for a candidate face (lower = better).

        Returns (score, static_dist) or (inf, inf) if the candidate
        doesn't pass the hard gate.
        """
        static_dist = self._static_distance(encoding)

        # Exclude gate — reject faces closer to exclude refs than subject
        if self._exclude_encodings:
            exclude_dist = self._exclude_distance(encoding)
            if exclude_dist <= static_dist:
                return float("inf"), static_dist

        # Hard gate uses STATIC references only — the adaptive encoding
        # must never let a wrong person pass the gate
        if static_dist > self.face_tolerance:
            return float("inf"), static_dist

        # Adaptive distance (may pull the score down for tracked face)
        if use_adaptive and self._adaptive_enc is not None:
            adaptive_dist = float(np.linalg.norm(
                self._adaptive_enc - encoding))
            min_dist = min(static_dist, adaptive_dist)
        else:
            min_dist = static_dist

        score = min_dist
        t, r, b, l = location

        # Spatial continuity penalty
        if self._last_location is not None:
            lt, lr, lb, ll = self._last_location
            last_cx, last_cy = (ll + lr) / 2, (lt + lb) / 2
            cx, cy = (l + r) / 2, (t + b) / 2
            face_size = max(lb - lt, lr - ll, 1)
            spatial_dist = (((cx - last_cx) ** 2 +
                             (cy - last_cy) ** 2) ** 0.5
                            / face_size)
            score += self._SPATIAL_WEIGHT * min(spatial_dist, 3.0)

            # Switch penalty (hysteresis)
            if spatial_dist > 0.5:
                score += self._SWITCH_PENALTY

        # Size consistency penalty
        if self._last_face_size is not None:
            cur_size = max(b - t, r - l, 1)
            size_ratio = max(cur_size, self._last_face_size) / max(
                min(cur_size, self._last_face_size), 1)
            score += self._SIZE_WEIGHT * min(size_ratio - 1.0, 1.0)

        return score, static_dist

    def find_face(self, frame, insightface_processing_skip=1, frame_number=None):
        """Return the face location (top, right, bottom, left) of the
        reference subject in *frame*, or None.

        Combines encoding distance, spatial continuity, size consistency,
        and switch hysteresis to robustly track the target.

        Two safeguards prevent locking onto the wrong person:

        * **Drift cap** — the adaptive encoding is only updated when it
          stays close to the original static references.  If it drifts
          too far it is reset.
        * **Periodic re-anchor** — every N frames the tracker compares
          the current match against static references only (ignoring
          the adaptive encoding).  If a different face is a better
          static match, the tracker switches back.
        """
        self._frame_count += 1
        self._diag_calls_total += 1

        current_frame_idx = frame_number if frame_number is not None else self._frame_count

        # Run inference every Nth call.  Using ``self._frame_count`` (a
        # call counter that always cycles 1,2,...,N-1,0,1,...) instead
        # of ``current_frame_idx`` is critical: when the absolute video
        # frame number is misaligned modulo ``insightface_processing_skip``
        # (e.g. start_frame=4000 with skip=3 → 4000%3=1, so EVERY call
        # lands at idx≡1 mod 3 and never crosses zero), the modulo on
        # the absolute frame number would short-circuit to the cache
        # forever after the first call.  ``_frame_count`` always wraps
        # through zero so the threshold actually fires every Nth call.
        if (insightface_processing_skip > 1
                and self._frame_count % insightface_processing_skip != 0
                and self._last_location is not None):
            return self._last_location

        self._diag_calls_inference += 1
        if cv2 is None:
            raise ImportError(_VIDEO_STACK_HINT)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        detect_with_kps = getattr(
            self._backend, "detect_faces_with_kps", None)
        if detect_with_kps is not None:
            locations, kps_list = detect_with_kps(rgb_frame)
        else:
            locations = self._backend.detect_faces(rgb_frame)
            kps_list = [None] * len(locations)
        encodings = self._backend.encode_faces(rgb_frame, locations)

        if not locations:
            self._last_location = None
            self._last_kps = None
            self._diag_no_face += 1
            return None

        # --- Periodic re-anchor: use only static references -----------

        is_reanchor_frame = (current_frame_idx % self._REANCHOR_EVERY) < insightface_processing_skip
        
        reanchor = (is_reanchor_frame and self._adaptive_enc is not None)

        best_location = None
        best_encoding = None
        best_kps = None
        best_score = float("inf")
        best_static_dist = float("inf")

        for location, encoding, kps in zip(locations, encodings, kps_list):
            score, static_dist = self._score_candidate(
                location, encoding, use_adaptive=not reanchor)
            if score < best_score:
                best_score = score
                best_location = location
                best_encoding = encoding
                best_kps = kps
                best_static_dist = static_dist

        # If re-anchoring found a face whose static distance is much
        # better than the adaptive encoding's static distance, reset
        # tracking to follow the better static match.
        if reanchor and best_encoding is not None:
            adaptive_static = self._static_distance(self._adaptive_enc)
            if best_static_dist < adaptive_static - 0.05:
                # The best static match is clearly better — reset
                self._adaptive_enc = best_encoding.copy()

        # --- Update tracking state ------------------------------------
        if best_location is not None:
            self._last_location = best_location
            self._last_kps = best_kps
            t, r, b, l = best_location
            self._last_face_size = max(b - t, r - l)

            # Update adaptive encoding only if it hasn't drifted too far
            if self._adaptive_enc is None:
                self._adaptive_enc = best_encoding.copy()
            else:
                candidate = ((1 - self._ADAPTIVE_ALPHA) * self._adaptive_enc
                             + self._ADAPTIVE_ALPHA * best_encoding)
                # Check drift from static references
                drift = self._static_distance(candidate)
                if drift <= self._DRIFT_CAP:
                    self._adaptive_enc = candidate
                # else: skip update, keep adaptive closer to references
        else:
            self._last_location = None
            self._last_kps = None

        return best_location

    def check_gaze(self, roi, face_kps=None, frame_shape=None):
        """Return True if the gaze vector in *roi* is within MAX_ANGLE
        of any reference vector.

        When *face_kps* (5-point landmarks from the detection pass)
        and *frame_shape* are provided AND the gaze backend is
        InsightFace, the gaze vector is computed directly from the
        keypoints — **skipping the second ONNX inference** that
        ``analyze_gaze`` would otherwise perform.  L2CS-Net always
        runs its own ResNet50 on the ROI regardless.
        """
        # Fast path: reuse keypoints from the detection pass
        if face_kps is not None and frame_shape is not None:
            from .insightface_gaze import _extract_vector_from_kps
            gaze_mod_name = getattr(
                self._gaze_module, "__name__", "")
            if "insightface" in gaze_mod_name:
                current_vector = _extract_vector_from_kps(
                    face_kps, frame_shape)
                eyes_closed = False
            else:
                self._gaze_timestamp_ms += 33
                current_vector, eyes_closed = (
                    self._gaze_module.analyze_gaze(
                        roi, self._gaze_timestamp_ms))
        else:
            self._gaze_timestamp_ms += 33
            current_vector, eyes_closed = (
                self._gaze_module.analyze_gaze(
                    roi, self._gaze_timestamp_ms))
        if eyes_closed:
            return True
        if current_vector is None:
            return False

        # Apply EMA smoothing if enabled (0 < alpha < 1)
        alpha = self._gaze_smoothing
        if 0 < alpha < 1.0:
            if self._smoothed_vector is None:
                self._smoothed_vector = current_vector / np.linalg.norm(
                    current_vector)
            else:
                self._smoothed_vector = (
                    alpha * current_vector
                    + (1.0 - alpha) * self._smoothed_vector)
                norm = np.linalg.norm(self._smoothed_vector)
                if norm > 0:
                    self._smoothed_vector /= norm
            current_vector = self._smoothed_vector

        dots = np.clip(self.vectors @ current_vector, -1.0, 1.0)
        return bool(np.any(np.degrees(np.arccos(dots)) < self.max_angle))

    def is_looking(self, frame):
        """Return True if the reference subject is looking at camera."""
        found, looking = self.check_looking(frame)
        return looking

    def check_looking(self, frame, insightface_processing_skip=1, frame_number=None):
        """Check whether the subject is looking at the camera.

        Returns
        -------
        (found, looking, face_box) : (bool, bool, tuple or None)
            *found* is True when the reference face was detected.
            *looking* is True when the face was found **and** gaze
            is within ``max_angle`` of the reference vectors.
            *face_box* is ``(top, right, bottom, left)`` of the matched
            face, or None if not found.
        """
        loc = self.find_face(frame, insightface_processing_skip, frame_number)
        if loc is None:
            return False, False, None
        top, right, bottom, left = loc
        h, w = frame.shape[:2]
        top = max(0, top)
        left = max(0, left)
        bottom = min(h, bottom)
        right = min(w, right)
        if top >= bottom or left >= right:
            return False, False, None
        roi = frame[top:bottom, left:right]
        looking = self.check_gaze(
            roi, face_kps=self._last_kps, frame_shape=frame.shape)
        return True, looking, (top, right, bottom, left)

    @staticmethod
    def load_encodings_only(directory, backend=None):
        """Load face encodings from *directory* (no gaze vectors).

        Used for exclude-reference directories where only identity
        matching is needed.

        Returns a list of encoding arrays, or an empty list if
        *directory* is empty or None.
        """
        if not directory or not os.path.isdir(directory):
            return []
        if backend is None:
            backend = get_backend()

        encodings = []
        for filename in sorted(os.listdir(directory)):
            if os.path.splitext(filename)[1].lower() not in IMAGE_EXTENSIONS:
                continue
            path = os.path.join(directory, filename)
            image = backend.load_image(path)
            encs = backend.encode_faces(image)
            if len(encs) > 1:
                warnings.warn(
                    f"Skipping exclude photo with multiple faces: {filename}")
                continue
            if encs:
                encodings.append(encs[0])
            else:
                # Try whole-image encoding for tightly cropped faces
                h, w = image.shape[:2]
                encs = backend.encode_faces(image, [(0, w, h, 0)])
                if encs:
                    encodings.append(encs[0])
                else:
                    warnings.warn(
                        f"Cannot encode exclude photo: {filename}")
        return encodings

    @staticmethod
    def load_dir(directory, use_roi=False, backend=None, exclude_dir=None,
                 gaze_method="insightface", gaze_smoothing=0.3):
        """Load reference images from *directory* and return a
        ReferenceData instance.

        Parameters
        ----------
        directory : str
            Directory containing reference photos.
        use_roi : bool
            If True, compute gaze vectors from the cropped face region
            instead of the full photo.  Uses the same input format as
            runtime detection for consistency.
        backend : module or None
            Face detection/encoding backend.  Defaults to InsightFace.
        exclude_dir : str or None
            Directory containing photos of faces to exclude (e.g.
            mother).  Detected faces closer to an exclude encoding
            than to the subject are rejected.
        gaze_method : str
            Gaze backend: ``"insightface"`` (default) or ``"l2cs"``.
        """
        if cv2 is None:
            raise ImportError(_VIDEO_STACK_HINT)
        if backend is None:
            backend = get_backend()

        gaze_mod = _get_gaze_module(gaze_method)

        def get_encoding(path):
            """Return a face encoding for the single face in *path*.

            If no face is detected (e.g. tightly cropped reference),
            the whole image is treated as the face region.
            """
            image = backend.load_image(path)
            encs = backend.encode_faces(image)
            if len(encs) > 1:
                raise ValueError(
                    f"multiple faces found on reference photo: {path}"
                )
            if encs:
                return encs[0]
            # No face detected — image is likely an already-cropped face.
            # Use the whole image as the face region.
            h, w = image.shape[:2]
            whole_face = [(0, w, h, 0)]  # (top, right, bottom, left)
            encs = backend.encode_faces(image, whole_face)
            if not encs:
                raise ValueError(
                    f"cannot encode face in reference photo: {path}")
            return encs[0]

        def get_vector(path):
            """Return a gaze vector for the face in *path*."""
            image = cv2.imread(path)
            if not use_roi:
                return gaze_mod.nose_eyes_vector(image)
            # Detect face and crop to ROI for consistency with runtime
            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            locations = backend.detect_faces(rgb)
            if not locations:
                # Already-cropped face — use whole image as ROI
                return gaze_mod.nose_eyes_vector(image)
            top, right, bottom, left = locations[0]
            h, w = image.shape[:2]
            roi = image[max(0, top):min(h, bottom),
                        max(0, left):min(w, right)]
            if roi.size == 0:
                return None
            return gaze_mod.nose_eyes_vector(roi)

        encodings = []
        vectors = []
        skipped = []
        for filename in sorted(os.listdir(directory)):
            if os.path.splitext(filename)[1].lower() not in IMAGE_EXTENSIONS:
                continue
            path = os.path.join(directory, filename)
            try:
                enc = get_encoding(path)
                vec = get_vector(path)
            except ValueError:
                skipped.append(filename)
                continue
            if vec is None:
                skipped.append(filename)
                continue
            encodings.append(enc)
            vectors.append(vec)

        if not encodings:
            raise ValueError(
                f"No usable reference photos found in {directory}. "
                f"All {len(skipped)} image(s) were skipped "
                "(no face or multiple faces detected)."
            )

        if skipped:
            warnings.warn(
                f"Skipped {len(skipped)} reference photo(s) with "
                f"no/multiple faces: {', '.join(skipped)}"
            )

        exclude_encodings = ReferenceData.load_encodings_only(
            exclude_dir, backend=backend)

        return ReferenceData(encodings, vectors, backend=backend,
                             exclude_encodings=exclude_encodings,
                             gaze_method=gaze_method,
                             gaze_smoothing=gaze_smoothing)
