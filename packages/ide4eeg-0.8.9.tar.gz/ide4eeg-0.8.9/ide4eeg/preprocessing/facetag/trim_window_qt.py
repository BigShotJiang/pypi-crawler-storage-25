"""Qt6 Signal Trim / Ignore Window.

Port of the Tkinter TrimWindow to PySide6/Qt6.  Shows an EEG overview
of the full recording with trim markers and an optional side-by-side
video frame.  The user clicks on the EEG plot or enters values to set
the trim start/end, then clicks Apply.
"""
# Author: Piotr Durka, 2026

import logging, os, threading
from typing import Optional
import numpy as np

try:
    from PySide6.QtCore import Qt, QRectF, QObject, Signal
    from PySide6.QtGui import (QImage, QPixmap, QPainter, QPen, QColor,
                                QFont, QFontMetrics, QPainterPath,
                                QMouseEvent, QResizeEvent)
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
        QPushButton, QLineEdit, QSlider, QSizePolicy, QCheckBox,
        QProgressBar, QApplication)
    _HAS_QT = True
except ImportError:
    _HAS_QT = False

from .video_reader import VideoReader
from ._eeg_paint import (
    EegPagedCanvas, STRIP_TRACE, TRIM_BD, TRIM_FILL,
    active_palette, fmt_time)

logger = logging.getLogger(__name__)

# Paged-view half-window for the trim canvas — 20 seconds wide.
_WINDOW_SEC = 20.0


class _Signals(QObject):
    """Thread-safe signals for background EEG loading."""
    # raw_handle, picks, sfreq, names.  Detail canvas slices the raw
    # handle on demand for full-resolution windows; emitted as soon
    # as channels are chosen so the canvas comes up without waiting
    # for the strip's envelope loop.
    eeg_loaded = Signal(object, object, float, list)
    # envelope, duration_s — fired later, after the background loop
    # finishes building the preview strip's min/max array.
    eeg_strip_loaded = Signal(object, float)
    eeg_error = Signal(str)
    eeg_progress = Signal(int, int)  # (current_chunk, total_chunks)


# ------------------------------------------------------------------
# EEG overview widget — paged detail canvas with trim shading.
# Implementation lives in `_eeg_paint.py` so the gaze-review window
# can share the same paging + theme machinery.
# ------------------------------------------------------------------

class EegOverviewQt(EegPagedCanvas):
    """Trim-window detail canvas — a paged EEG view with trim shading
    and boundary lines.  All paint logic comes from
    :class:`EegPagedCanvas`; this subclass only fixes the window length
    at 20 seconds and exists for back-compat naming."""

    def __init__(self, parent=None):
        super().__init__(parent, window_sec=_WINDOW_SEC)


# ------------------------------------------------------------------
# Whole-recording preview strip
# ------------------------------------------------------------------

class EegStripQt(QWidget):
    """Whole-recording overview strip.  Paints a min/max envelope of
    the full recording, plus cursor and trim shading.  Click anywhere
    to set the cursor.

    The envelope reduces each pixel column to (min, max) over a
    contiguous slice of the recording — faithful to slow drift (no
    probe-gap aliasing) and shows bursts at their actual time.

    Complements ``EegOverviewQt``: that widget paints a ~20 s detail
    window; this strip gives at-a-glance "where am I in the whole
    recording, and where are the trim points" orientation.
    """
    clicked = Signal(float)  # time in seconds

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(70)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        # Shape (n_picks, n_cols, 2): last dim is (min, max).
        self.envelope: Optional[np.ndarray] = None
        self.duration = 0.0
        self.cursor_time = 0.0
        self.trim_start = 0.0
        self.trim_end: Optional[float] = None
        # Pre-rendered envelope, invalidated on resize/load.  Lets
        # paintEvent skip ~16k QPainterPath segments per cursor move.
        self._cached: Optional[QPixmap] = None

    def load(self, envelope, duration):
        """Populate the strip with a min/max envelope (shape
        ``(n_picks, n_cols, 2)``) and the recording duration."""
        self.envelope = envelope
        self.duration = float(duration) if duration else 0.0
        self._cached = None
        self.update()

    def set_cursor(self, t):
        self.cursor_time = float(t); self.update()

    def set_trim(self, start, end):
        self.trim_start = float(start) if start is not None else 0.0
        self.trim_end = float(end) if end is not None else None
        self.update()

    def resizeEvent(self, event: QResizeEvent):  # noqa: N802
        self._cached = None
        super().resizeEvent(event)

    def _render_envelope(self) -> Optional[QPixmap]:
        """Render the envelope into a transparent-background pixmap.
        Drawn once per (load, resize); reused for every paint."""
        env = self.envelope
        if env is None or env.ndim != 3 or env.shape[1] < 1 or env.shape[2] != 2:
            return None
        w, h = self.width(), self.height()
        if w <= 0 or h <= 0:
            return None
        pm = QPixmap(w, h)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing, True)
        n_ch, n_cols, _ = env.shape
        margin = 2
        avail = max(1, h - 2 * margin)
        lane_h = avail / max(1, n_ch)
        xs = np.linspace(0.0, float(w), n_cols)
        if lane_h >= 3.0:
            # Per-channel center via mean of (min, max); shared scale
            # via median std across channels (robust to a noisy lead).
            flat = env.reshape(n_ch, -1)
            means = flat.mean(axis=1)
            stds = flat.std(axis=1)
            stds_nz = stds[stds > 1e-12]
            global_sd = float(np.median(stds_nz)) if stds_nz.size else 1.0
            scale = lane_h * 0.4 / global_sd
            p.setPen(QPen(QColor(STRIP_TRACE), 1))
            for ci in range(n_ch):
                yc = margin + lane_h * (ci + 0.5)
                y_top = yc - (env[ci, :, 1] - means[ci]) * scale
                y_bot = yc - (env[ci, :, 0] - means[ci]) * scale
                path = QPainterPath()
                for col in range(n_cols):
                    x = float(xs[col])
                    path.moveTo(x, float(y_top[col]))
                    path.lineTo(x, float(y_bot[col]))
                p.drawPath(path)
        else:
            # Lane too short: collapse to peak-to-peak across channels.
            ptp = env[:, :, 1] - env[:, :, 0]
            amp = np.median(ptp, axis=0)
            amp_max = float(amp.max()) if amp.size else 0.0
            if amp_max > 1e-12:
                yc = h / 2.0
                half = (h - 2 * margin) * 0.45
                ys = yc - (amp / amp_max) * half
                EegOverviewQt._draw_trace(p, xs, ys, STRIP_TRACE)
        p.end()
        return pm

    def paintEvent(self, event):  # noqa: N802
        pal = active_palette()
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(pal["bg"]))
        dur = self.duration
        if dur <= 0 or w <= 0:
            p.end(); return

        def _tx(t): return t / dur * w

        # Trim shading — visible across the whole recording duration
        te = self.trim_end if self.trim_end is not None else dur
        if self.trim_start > 0:
            c = QColor(TRIM_FILL); c.setAlpha(50)
            x_end = _tx(min(self.trim_start, dur))
            if x_end > 0:
                p.fillRect(QRectF(0, 0, x_end, h), c)
        if te < dur:
            c = QColor(TRIM_FILL); c.setAlpha(50)
            x_start = _tx(max(te, 0.0))
            if x_start < w:
                p.fillRect(QRectF(x_start, 0, w - x_start, h), c)

        # Envelope — cached pixmap, re-rendered on load/resize only.
        if self._cached is None or self._cached.size() != self.size():
            self._cached = self._render_envelope()
        if self._cached is not None:
            p.drawPixmap(0, 0, self._cached)

        # Trim boundary lines — dashed, like the detail view
        for edge in (self.trim_start, te):
            if 0 <= edge <= dur:
                x = int(_tx(edge))
                p.setPen(QPen(QColor(TRIM_BD), 2, Qt.DashLine))
                p.drawLine(x, 0, x, h)

        # Cursor — solid 2 px so it stays visible against the envelope.
        if 0 <= self.cursor_time <= dur:
            x = int(_tx(self.cursor_time))
            p.setPen(QPen(QColor(pal["cursor"]), 2))
            p.drawLine(x, 0, x, h)
        p.end()

    def mousePressEvent(self, event: QMouseEvent):  # noqa: N802
        if self.duration > 0 and event.button() == Qt.LeftButton:
            t = event.position().x() / self.width() * self.duration
            self.clicked.emit(max(0.0, min(t, self.duration)))


# ------------------------------------------------------------------
# Main window
# ------------------------------------------------------------------

class TrimWindowQt(QMainWindow):
    """Qt6 window for setting start/end trim points on a recording."""
    VIDEO_WIDTH = 480

    def __init__(self, parent=None, eeg_path="", video_path=None,
                 trim_start=0.0, trim_end=None, on_apply=None):
        super().__init__(parent)
        self.eeg_path, self.video_path = eeg_path, video_path or ""
        self.on_apply = on_apply
        self.reader: Optional[VideoReader] = None
        self.duration, self.fps, self.current_time = 0.0, 30.0, 0.0
        self._seeking = False
        title = "Preview & Trim Signal"
        if eeg_path:
            title = f"{title} — {os.path.basename(eeg_path)}"
        self.setWindowTitle(title)
        self.setMinimumSize(900, 550)
        self._sig = _Signals()
        self._sig.eeg_loaded.connect(self._on_eeg_loaded)
        self._sig.eeg_strip_loaded.connect(self._on_eeg_strip_loaded)
        self._sig.eeg_error.connect(lambda m: self.statusBar().showMessage(f"EEG: {m}"))
        self._sig.eeg_progress.connect(self._on_eeg_progress)
        self._has_video = bool(self.video_path)
        self._build_ui()
        self._start_edit.setText(f"{trim_start:.1f}")
        if trim_end is not None: self._end_edit.setText(f"{trim_end:.1f}")
        if self._has_video: self._open_video()
        if eeg_path: self._load_eeg_bg(eeg_path)

    def _build_ui(self):
        cw = QWidget(); self.setCentralWidget(cw)
        ml = QVBoxLayout(cw); ml.setContentsMargins(6, 6, 6, 6); ml.setSpacing(4)
        # Top: video (optional) + EEG overview
        top = QHBoxLayout()
        if self._has_video:
            self.video_label = QLabel()
            self.video_label.setFixedSize(self.VIDEO_WIDTH, 360)
            self.video_label.setStyleSheet("background-color:black;")
            self.video_label.setAlignment(Qt.AlignCenter)
            top.addWidget(self.video_label)
        else:
            self.video_label = None
        self.eeg_overview = EegOverviewQt(self)
        self.eeg_overview.clicked.connect(self._on_eeg_click)
        self.eeg_overview.setToolTip(
            "Drag horizontally to pan, mouse-wheel to scroll, "
            "click to seek.")
        top.addWidget(self.eeg_overview, stretch=1)
        ml.addLayout(top, stretch=1)
        # Whole-recording preview strip — clusters with the slider as
        # navigation controls.  Strip = spatial context across the
        # full recording; slider = keyboard-friendly fine seek.
        self.eeg_strip = EegStripQt(self)
        self.eeg_strip.clicked.connect(self._seek)
        self.eeg_strip.setToolTip(
            "Min/max envelope of the full recording.\n"
            "\n"
            "Each pixel column reduces a contiguous slice of the\n"
            "recording (duration / strip-width samples) to its\n"
            "(min, max) per channel, drawn as a vertical bar.\n"
            "Every sample is read, so slow drift and bursts\n"
            "appear at their true location.\n"
            "\n"
            "Loaded in the background in ~25 MB chunks so the\n"
            "detail canvas above stays responsive. Click\n"
            "anywhere to seek.")
        ml.addWidget(self.eeg_strip)
        # Timeline slider
        tl = QHBoxLayout()
        for txt, dt in [("<<", -5), ("<", -1)]:
            b = QPushButton(txt); b.setFixedWidth(40)
            b.clicked.connect(lambda _, d=dt: self._step(d)); tl.addWidget(b)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setMinimum(0); self.slider.setMaximum(1000)
        self.slider.valueChanged.connect(self._on_slider)
        tl.addWidget(self.slider, stretch=1)
        for txt, dt in [(">", 1), (">>", 5)]:
            b = QPushButton(txt); b.setFixedWidth(40)
            b.clicked.connect(lambda _, d=dt: self._step(d)); tl.addWidget(b)
        self.time_label = QLabel("00:00.00")
        self.time_label.setFixedWidth(90); self.time_label.setFont(QFont("Menlo", 11))
        tl.addWidget(self.time_label)
        tl.addSpacing(12)
        # Amplitude controls
        amp_dn = QPushButton("\u2013"); amp_dn.setFixedWidth(28)
        amp_dn.setToolTip("Decrease amplitude")
        amp_dn.clicked.connect(lambda: self._set_amp(0.5))
        tl.addWidget(amp_dn)
        self._amp_label = QLabel("1.0\u00d7")
        self._amp_label.setFixedWidth(40); self._amp_label.setAlignment(Qt.AlignCenter)
        tl.addWidget(self._amp_label)
        amp_up = QPushButton("+"); amp_up.setFixedWidth(28)
        amp_up.setToolTip("Increase amplitude")
        amp_up.clicked.connect(lambda: self._set_amp(2.0))
        tl.addWidget(amp_up)
        tl.addSpacing(12)
        self._dc_check = QCheckBox("DC removal")
        self._dc_check.setChecked(True)
        self._dc_check.setToolTip(
            "Subtract per-channel mean (removes DC offset)")
        self._dc_check.stateChanged.connect(self._on_dc_toggle)
        tl.addWidget(self._dc_check)
        ml.addLayout(tl)
        # Loading progress bar (hidden when done)
        self._load_prog = QProgressBar()
        self._load_prog.setRange(0, 100)
        self._load_prog.setFixedHeight(14)
        self._load_prog.hide()
        ml.addWidget(self._load_prog)
        # Trim controls
        tf = QHBoxLayout()
        self._dur_label = QLabel(""); self._dur_label.setStyleSheet("font-size:13px;")
        tf.addWidget(self._dur_label, stretch=1)
        tf.addWidget(QLabel("Trim start:"))
        self._start_edit = QLineEdit("0.0"); self._start_edit.setFixedWidth(70)
        self._start_edit.editingFinished.connect(self._on_trim_edited); tf.addWidget(self._start_edit)
        tf.addWidget(QLabel("s"))
        b = QPushButton("Set to current"); b.clicked.connect(self._set_start_trim); tf.addWidget(b)
        tf.addWidget(QLabel("   Trim end:"))
        self._end_edit = QLineEdit(""); self._end_edit.setFixedWidth(70)
        self._end_edit.setPlaceholderText("(end)")
        self._end_edit.editingFinished.connect(self._on_trim_edited); tf.addWidget(self._end_edit)
        tf.addWidget(QLabel("s"))
        b = QPushButton("Set to current"); b.clicked.connect(self._set_end_trim); tf.addWidget(b)
        b = QPushButton("Whole signal"); b.clicked.connect(self._set_whole_signal); tf.addWidget(b)
        ml.addLayout(tf)
        # Bottom buttons
        bot = QHBoxLayout(); bot.addStretch()
        b = QPushButton("Cancel"); b.clicked.connect(self.close); bot.addWidget(b)
        b = QPushButton("Apply"); b.clicked.connect(self._apply); bot.addWidget(b)
        ml.addLayout(bot)
        self.statusBar().showMessage("Ready")

    # --- Video ---
    def _open_video(self):
        try:
            self.reader = VideoReader(self.video_path)
            self.fps = self.reader.fps
            self.duration = self.reader.total_frames / self.fps
            self.slider.setMaximum(int(self.duration * 1000))
            self._update_duration_label(); self._seek(0)
        except Exception as e:
            self.statusBar().showMessage(f"Video error: {e}")

    def _show_frame(self, frame_num):
        if not self.reader or not self.video_label: return
        frame_num = max(0, min(frame_num, self.reader.total_frames - 1))
        bgr = self.reader.read_frame(frame_num)
        if bgr is None: return
        rgb = bgr[:, :, ::-1].copy(); h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        pm = QPixmap.fromImage(qimg).scaledToWidth(self.VIDEO_WIDTH, Qt.SmoothTransformation)
        self.video_label.setFixedSize(pm.width(), pm.height())
        self.video_label.setPixmap(pm)

    # --- Seeking ---
    def _seek(self, t):
        if self._seeking: return
        self._seeking = True
        try:
            t = max(0.0, min(t, self.duration)); self.current_time = t
            self._show_frame(int(t * self.fps))
            self.eeg_overview.cursor_time = t; self.eeg_overview.update()
            self.eeg_strip.set_cursor(t)
            self.time_label.setText(fmt_time(t)); self.slider.setValue(int(t * 1000))
        finally:
            self._seeking = False

    def _step(self, delta): self._seek(self.current_time + delta)

    def _on_slider(self, v):
        if self._seeking: return
        self._seek(max(0.0, min(v / 1000.0, self.duration)))

    def _on_eeg_click(self, t): self._seek(t)

    def _on_eeg_progress(self, current, total):
        self._load_prog.setRange(0, total)
        self._load_prog.setValue(current)
        self._load_prog.show()
        self.statusBar().showMessage(
            f"Loading EEG overview... {current}/{total} chunks")

    # --- Amplitude / DC ---
    def _set_amp(self, factor):
        self.eeg_overview.amp_scale *= factor
        self._amp_label.setText(f"{self.eeg_overview.amp_scale:.1f}\u00d7")
        self.eeg_overview.update()

    def _on_dc_toggle(self, state):
        self.eeg_overview.dc_remove = bool(state)
        self.eeg_overview._apply_dc()
        self.eeg_overview.update()

    # --- Trim controls ---
    def _parse_start(self):
        try: return max(0.0, float(self._start_edit.text()))
        except ValueError: return 0.0

    def _parse_end(self):
        txt = self._end_edit.text().strip()
        if not txt: return None
        try: return max(0.0, float(txt))
        except ValueError: return None

    def _sync_trim_to_overview(self):
        ts, te = self._parse_start(), self._parse_end()
        self.eeg_overview.trim_start = ts
        self.eeg_overview.trim_end = te
        self.eeg_overview.update()
        self.eeg_strip.set_trim(ts, te)
        self._update_duration_label()

    def _on_trim_edited(self): self._sync_trim_to_overview()

    def _set_start_trim(self):
        self._start_edit.setText(f"{self.current_time:.1f}")
        self._sync_trim_to_overview()
        self.statusBar().showMessage(f"Start trim set to {fmt_time(self.current_time)}")

    def _set_end_trim(self):
        self._end_edit.setText(f"{self.current_time:.1f}")
        self._sync_trim_to_overview()
        self.statusBar().showMessage(f"End trim set to {fmt_time(self.current_time)}")

    def _set_whole_signal(self):
        self._start_edit.setText("0.0"); self._end_edit.setText("")
        self._sync_trim_to_overview()
        self.statusBar().showMessage("Trim cleared -- using whole signal")

    def _update_duration_label(self):
        if self.duration <= 0: return
        ts, te = self._parse_start(), self._parse_end()
        te_val = te if te is not None else self.duration
        clipped = max(0.0, te_val - ts)
        if ts > 0 or te is not None:
            self._dur_label.setText(
                f"Duration: {fmt_time(self.duration)} total, {fmt_time(clipped)} after trim")
        else:
            self._dur_label.setText(f"Duration: {fmt_time(self.duration)}")

    # --- EEG loading (background thread) ---
    def _load_eeg_bg(self, eeg_path):
        self.statusBar().showMessage("Loading EEG overview..."); sig = self._sig
        def worker():
            try:
                import mne, os
                raw = None
                ext = os.path.splitext(eeg_path)[1].lower()
                # Use MNE lazy loading (preload=False) for standard formats
                try:
                    if ext == ".raw":
                        from ...input.input import read_file
                        raw, _ = read_file(eeg_path)
                    elif ext == ".vhdr":
                        raw = mne.io.read_raw_brainvision(eeg_path, preload=False, verbose=False)
                    elif ext == ".fif":
                        raw = mne.io.read_raw_fif(eeg_path, preload=False, verbose=False)
                    elif ext == ".edf":
                        raw = mne.io.read_raw_edf(eeg_path, preload=False, verbose=False)
                    elif ext == ".bdf":
                        raw = mne.io.read_raw_bdf(eeg_path, preload=False, verbose=False)
                    elif ext == ".set":
                        raw = mne.io.read_raw_eeglab(eeg_path, preload=False, verbose=False)
                    else:
                        raw = mne.io.read_raw(eeg_path, preload=False, verbose=False)
                except Exception:
                    pass
                if raw is None:
                    sig.eeg_error.emit("Could not read EEG file"); return
                # Pick up to 16 EEG channels for overview
                picks, names = [], []
                for i, ch in enumerate(raw.info["ch_names"]):
                    cl = ch.lower()
                    if not any(x in cl for x in (
                            "stim", "eog", "emg", "ecg", "misc",
                            "resp", "trigger", "status")):
                        picks.append(i); names.append(ch)
                if not picks:
                    picks = list(range(min(16, len(raw.info["ch_names"]))))
                    names = [raw.info["ch_names"][i] for i in picks]
                if len(picks) > 16:
                    s = len(picks) // 16
                    picks, names = picks[::s][:16], names[::s][:16]
                # Emit raw handle + picks immediately so the detail
                # canvas can come up and start slicing on demand —
                # don't make the user wait for the envelope loop.
                n_total = raw.n_times
                sfreq = raw.info["sfreq"]
                duration_s = n_total / sfreq
                sig.eeg_loaded.emit(raw, picks, sfreq, names)
                # Build a min/max envelope for the preview strip.
                # Reads the picked channels in contiguous chunks
                # (sequential I/O, ~25 MB peak transient) and reduces
                # each pixel column to (min, max).  Faithful to slow
                # drift across the whole recording — no probe-gap
                # aliasing, peaks land at their actual time.
                import warnings
                W = 1000  # envelope columns; cached pixmap re-renders on resize
                n_picks = len(picks)
                samples_per_col = n_total // W
                envelope = None
                if samples_per_col >= 1 and n_picks > 0:
                    envelope = np.empty((n_picks, W, 2), dtype=np.float32)
                    # Bound peak transient working memory ~25 MB.
                    max_chunk_samples = max(
                        1, (25 * 1024 * 1024) // (8 * n_picks))
                    cols_per_chunk = max(1, min(
                        W, max_chunk_samples // max(1, samples_per_col)))
                    n_chunks = (W + cols_per_chunk - 1) // cols_per_chunk
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        for c in range(n_chunks):
                            col0 = c * cols_per_chunk
                            col1 = min(col0 + cols_per_chunk, W)
                            s0 = col0 * samples_per_col
                            s1 = col1 * samples_per_col
                            chunk = raw.get_data(
                                picks=picks, start=s0, stop=s1)
                            actual_cols = col1 - col0
                            chunk = chunk[:, :actual_cols * samples_per_col]
                            chunk = chunk.reshape(
                                n_picks, actual_cols, samples_per_col)
                            envelope[:, col0:col1, 0] = chunk.min(axis=2)
                            envelope[:, col0:col1, 1] = chunk.max(axis=2)
                            sig.eeg_progress.emit(c + 1, n_chunks)
                sig.eeg_strip_loaded.emit(envelope, duration_s)
            except Exception as e: sig.eeg_error.emit(str(e))
        threading.Thread(target=worker, daemon=True).start()

    def _on_eeg_loaded(self, raw, picks, sfreq, names):
        self.eeg_overview.load_lazy(raw, picks, sfreq, names)
        n_total = raw.n_times if raw is not None else 0
        if self.duration <= 0 and n_total > 0:
            self.duration = n_total / sfreq
            self.slider.setMaximum(int(self.duration * 1000))
        self._sync_trim_to_overview(); self._seek(0)
        self.statusBar().showMessage(
            f"EEG loaded: {len(names)} channels — "
            f"strip filling in background")

    def _on_eeg_strip_loaded(self, envelope, duration_s):
        """Populate the preview strip once the background envelope
        loop finishes — keeps the detail canvas responsive while the
        strip's min/max envelope builds."""
        self._load_prog.hide()
        strip_dur = self.duration if self.duration > 0 else duration_s
        self.eeg_strip.load(envelope, strip_dur)
        self.statusBar().showMessage("EEG ready")

    # --- Apply / Close ---
    def _apply(self):
        start, end = self._parse_start(), self._parse_end()
        if self.on_apply: self.on_apply(start, end)
        self.close()

    def closeEvent(self, event):  # noqa: N802
        if self.reader: self.reader.release()
        event.accept()
