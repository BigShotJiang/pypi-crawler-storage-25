"""ICA-based artifact correction for IDE4EEG (Phase 4 redesign).

Fits an ICA decomposition on a 1 Hz high-passed copy of the signal,
labels every component with MNE-ICALabel (with ``find_bads_*`` and
interactive review as alternatives), removes the artefact components,
and emits an audit tree.  Picard is the default algorithm; Infomax
and FastICA remain as selectable alternatives.

Scientific backing:

- Picard (Ablin, Cardoso & Gramfort 2018): same maximum-likelihood
  objective as extended-Infomax, 3–10× faster convergence on EEG-
  scale data.
- Winkler et al. 2015: a 1 Hz high-pass before ICA markedly improves
  decomposition quality.  The high-pass is applied to a copy used
  only for fitting, so the analysis signal keeps whatever filter the
  user chose.
- Pion-Tonachini et al. 2019 (ICLabel): ML classifier over seven
  artefact / brain classes, ~90% accuracy against expert labels.

Design decisions and defaults are documented in
``project_ica_redesign.md`` in project memory (Phase 4 spec).
"""

# Author: IDE4EEG team, 2026

import logging
import os

import mne
import numpy as np
from threadpoolctl import threadpool_limits


#: When ``decim > 1`` the ICA fit operates on every N-th sample.  The
#: default is 1 (no subsampling) — users opt into the speed knob via
#: the GUI advanced field and must know that decim without an anti-alias
#: filter is only safe when the fit-time high-pass already band-limits
#: the data.  See the tooltip on the GUI ``decim`` field.
DEFAULT_DECIM = 1

#: ICLabel keeps components labelled as any of these classes.  The
#: default set keeps ``brain`` (obviously) and ``other`` (low-confidence
#: components the classifier isn't sure about — conservative default).
#: User-overridable via the GUI class-checkbox group.
DEFAULT_ICLABEL_KEEP = ("brain", "other")

#: Peak-to-peak rejection threshold in microvolts.  Segments with any
#: channel exceeding this are dropped before ICA sees them.  0 disables.
DEFAULT_REJECT_UV = 500.0

#: Default Winkler high-pass cutoff in Hz for the ICA-fit copy.
#: Applied via ``raw.copy().filter(l_freq=…, h_freq=None)``.
DEFAULT_FIT_HIGHPASS_HZ = 1.0

#: Default random state for ICA fits.  User-selectable.
DEFAULT_RANDOM_STATE = 42

#: MNE-ICALabel lives behind this import path.  It is a hard
#: dependency in ``requirements.txt`` — when the default selector is
#: used and the import fails, the step raises a clear error.
_ICLABEL_IMPORT_ERROR = None
try:
    from mne_icalabel import label_components as _iclabel_label_components
except ImportError as _e:  # pragma: no cover — import path
    _ICLABEL_IMPORT_ERROR = _e
    _iclabel_label_components = None


class ICAFailureError(RuntimeError):
    """Raised when the ICA step cannot produce a usable decomposition.

    Covers: Picard non-convergence, ICLabel flagging every component,
    missing ``mne_icalabel`` when the user selected it, etc.  The GUI
    catches this and shows a modal error; batch runners log and skip
    the file.
    """


# ── Public entry point ──────────────────────────────────────────────


def fit_and_apply_ica(signal, config, path, file_name):
    """Run the full ICA step: fit, label, remove, audit.

    Parameters
    ----------
    signal : mne.io.Raw
        The signal as it arrives from the previous preprocessing step.
        Not mutated — the cleaned signal is returned as a new object.
    config : dict
        Pipeline configuration.  Reads from ``config["ICA_EOG"]``.
    path : str
        Output directory.  Audit artefacts land in
        ``<path>/artifacts_detection/ICA_EOG/`` when ``save`` is true.
    file_name : str
        Input file stem, used as a prefix in audit file names.

    Returns
    -------
    mne.io.Raw
        The input signal with artefact components projected out.
    """
    cfg = config.get("ICA_EOG", {})
    manual_hook = (config.get("_manual_hooks") or {}).get("ica")

    fit_copy = _prepare_fit_signal(signal, cfg)
    ica = _fit_ica(fit_copy, cfg)
    bads = _label_components(signal, fit_copy, ica, cfg,
                             manual_hook=manual_hook)
    bads_list = sorted(bads)
    n_total = int(getattr(ica, "n_components_", 0))
    if bads_list:
        logging.info(
            "ICA: excluding %d/%d component(s): %s",
            len(bads_list), n_total,
            ", ".join(f"IC{i}" for i in bads_list))
    else:
        logging.info("ICA: excluding 0/%d components (none selected)",
                     n_total)
    cleaned = _apply_and_audit(
        signal, fit_copy, ica, bads, cfg, path, file_name)

    config.setdefault("ICA_EOG", {})["bad_sources"] = list(bads)
    return cleaned


# ── Stage 1: fit-time signal preparation ────────────────────────────


def _prepare_fit_signal(raw, cfg):
    """Return an EEG-only copy of *raw*, high-passed for ICA fitting.

    Drops bad channels and non-EEG channels (EOG goes to the
    selection stage, not into the decomposition), then applies the
    Winkler high-pass.  The original *raw* is not modified.
    """
    fit_copy = raw.copy()
    fit_copy.pick(picks="eeg", exclude="bads")
    fit_copy.load_data()

    hp = float(cfg.get("fit_highpass_hz", DEFAULT_FIT_HIGHPASS_HZ) or 0.0)
    if hp > 0:
        fit_copy.filter(l_freq=hp, h_freq=None, verbose=False)
    return fit_copy


# ── Stage 2: the fit itself ─────────────────────────────────────────


def _resolve_n_components(fit_copy, cfg):
    """Resolve ``n_components`` from config against the fit-copy rank.

    - ``"rank"`` (default): data-computed rank via
      ``mne.compute_rank(fit_copy)``.  Catches average-reference and
      interpolated-channel rank loss because MNE runs an SVD rather
      than trusting the info's projection count.
    - ``int``: use as-is.
    - ``float`` in (0, 1]: fraction of EEG channels.
    """
    raw_cfg = cfg.get("n_components", "rank")
    if isinstance(raw_cfg, int):
        return raw_cfg
    if isinstance(raw_cfg, float) and 0.0 < raw_cfg <= 1.0:
        return max(1, int(round(raw_cfg * len(fit_copy.ch_names))))
    if raw_cfg != "rank":
        logging.warning(
            "ICA_EOG.n_components=%r not recognised; falling back to 'rank'.",
            raw_cfg)
    rank_dict = mne.compute_rank(fit_copy, verbose=False)
    return max(1, int(rank_dict.get("eeg", len(fit_copy.ch_names))))


def _resolve_fit_params(method):
    """Return method-appropriate ``fit_params`` for ``ICA.__init__``."""
    if method == "picard":
        return dict(ortho=False, extended=True)
    if method == "infomax":
        return dict(extended=True)
    return {}  # fastica has no useful fit_params


def _resolve_reject(cfg):
    """Translate ``reject_uv`` from the config into MNE's reject dict."""
    reject_uv = cfg.get("reject_uv", DEFAULT_REJECT_UV)
    try:
        reject_uv = float(reject_uv)
    except (TypeError, ValueError):
        reject_uv = 0.0
    if reject_uv <= 0:
        return None
    return dict(eeg=reject_uv * 1e-6)


def _fit_ica(fit_copy, cfg):
    """Fit an ICA decomposition on *fit_copy* using the config knobs."""
    method = cfg.get("method", "picard")
    n_components = _resolve_n_components(fit_copy, cfg)
    random_state = int(cfg.get("random_state", DEFAULT_RANDOM_STATE))
    max_iter = cfg.get("max_iter", "auto")
    fit_params = _resolve_fit_params(method)
    decim = int(cfg.get("decim", DEFAULT_DECIM) or 1)
    reject = _resolve_reject(cfg)

    logging.info(
        "ICA: method=%s, n_components=%d, random_state=%d, decim=%d, "
        "reject_uv=%s",
        method, n_components, random_state, decim,
        (reject["eeg"] * 1e6) if reject else "disabled")

    ica = mne.preprocessing.ICA(
        method=method,
        n_components=n_components,
        random_state=random_state,
        max_iter=max_iter,
        fit_params=fit_params,
        verbose=False,
    )

    # Temporarily release the repo-wide BLAS thread cap so Picard's
    # numpy/BLAS inner loop can parallelise across cores when ICA runs
    # at the top level.  When the surrounding pipeline is already
    # running inside an outer joblib.Parallel block, the outer cap is
    # preserved (threadpool_limits(None) means "don't set a new cap";
    # the outer's cap is already active).  See decision 8 in the spec.
    try:
        with threadpool_limits(limits=None):
            ica.fit(fit_copy, reject=reject, decim=decim, verbose=False)
    except Exception as e:
        raise ICAFailureError(
            f"Picard/{method} fit failed: {type(e).__name__}: {e}"
        ) from e
    return ica


# ── Stage 3: component labelling / selection ────────────────────────


def _label_components(raw, fit_copy, ica, cfg, manual_hook=None):
    """Dispatch to the configured component selector.

    Returns a sorted list of integer indices of components to remove.
    """
    selector = cfg.get("selector", "iclabel")
    bads = set()

    if selector in ("iclabel", "both"):
        bads |= _select_iclabel(raw, ica, cfg)
        if selector == "iclabel":
            return sorted(bads)

    if selector in ("find_bads", "both"):
        bads |= _select_find_bads(raw, ica, cfg)

    if selector == "manual" or selector == "both":
        bads = _select_manual(raw, ica, sorted(bads),
                              manual_hook=manual_hook)

    if selector not in ("iclabel", "find_bads", "manual", "both"):
        raise ICAFailureError(
            f"Unknown ICA_EOG.selector={selector!r}; "
            f"expected one of iclabel / find_bads / manual / both.")

    return sorted(bads)


def _select_iclabel(raw, ica, cfg):
    """Run MNE-ICALabel and return the set of components to remove.

    The classifier expects average-referenced, 1–100 Hz band-limited
    data.  Both the re-reference and the band-pass are applied to a
    **copy** used only for classification — the original signal's
    reference and filter state are preserved.  This is decision 6 in
    the Phase 4 spec (flagged for follow-up).
    """
    if _iclabel_label_components is None:
        raise ICAFailureError(
            "ICA_EOG.selector='iclabel' but mne_icalabel is not "
            f"installed ({_ICLABEL_IMPORT_ERROR}).  Either install "
            "mne-icalabel + onnxruntime, or switch "
            "ICA_EOG.selector to 'find_bads' / 'manual'.")

    classify_copy = raw.copy().load_data()
    classify_copy.set_eeg_reference(
        "average", projection=False, verbose=False)
    # ICLabel was trained on 1–100 Hz band-limited data; anything
    # outside that band biases the classifier.  Filter the classify-
    # copy to hit the training distribution.  If the signal is
    # already high-pass filtered above 1 Hz or its Nyquist is below
    # 100 Hz, mne.filter.filter_data gracefully clamps the cutoffs.
    sfreq = classify_copy.info["sfreq"]
    l_freq = 1.0 if classify_copy.info["highpass"] < 1.0 else None
    h_freq = 100.0 if sfreq / 2 > 100.0 else None
    if l_freq is not None or h_freq is not None:
        classify_copy.filter(l_freq=l_freq, h_freq=h_freq, verbose=False)

    try:
        result = _iclabel_label_components(
            classify_copy, ica, method="iclabel")
    except Exception as e:
        raise ICAFailureError(
            f"ICLabel classification failed: {type(e).__name__}: {e}"
        ) from e

    labels = list(result["labels"])
    probs = np.asarray(result["y_pred_proba"])
    # Sanity-check the classifier output before iterating — an
    # empty labels list combined with probs.shape[0] == 0 used to
    # quietly produce bads={} ("nothing is artefact"), so the user
    # would think ICA cleaned the data when in fact the model
    # returned nothing.  This is unusual (typically caused by a
    # corrupt onnx model or a non-EEG signal slipped through pre-
    # checks) but worth surfacing rather than silently passing.
    if len(labels) == 0 or len(labels) != ica.n_components_:
        raise ICAFailureError(
            f"ICLabel returned an unexpected number of labels "
            f"({len(labels)} vs {ica.n_components_} components). "
            f"Possible causes: corrupt mne-icalabel model file, "
            f"signal incompatible with ICLabel's training "
            f"distribution, or a version mismatch.")
    # Stash on the ICA object so _write_classification_csv can pick
    # them up later — the audit CSV reads via getattr() to stay decoupled.
    ica._ica_classification_labels = labels
    ica._ica_classification_probs = probs
    keep = set(cfg.get("iclabel_keep", list(DEFAULT_ICLABEL_KEEP)))
    min_p = float(cfg.get("iclabel_min_prob", 0.0))

    bads = set()
    for i, cls in enumerate(labels):
        max_p = float(probs[i].max()) if probs.ndim > 1 else float(probs[i])
        if cls not in keep and max_p >= min_p:
            bads.add(i)

    if len(bads) == ica.n_components_:
        # Build a diagnostic summary so the user can see what happened.
        from collections import Counter
        cls_counts = Counter(labels)
        summary = ", ".join(f"{cls}: {n}" for cls, n in
                            cls_counts.most_common())
        raise ICAFailureError(
            f"ICLabel flagged every component as artefact "
            f"({ica.n_components_} components: {summary}; "
            f"kept classes: {sorted(keep)}).  "
            f"Common causes: wrong channel types (non-EEG channels "
            f"typed as EEG), missing or wrong montage, too few "
            f"channels, or very noisy data.  Check the raw data, "
            f"the montage step, and the channel type assignments "
            f"in the Input tab.")

    logging.info(
        "ICLabel: removing %d of %d components; kept classes %s",
        len(bads), ica.n_components_, sorted(keep))
    return bads


def _select_find_bads(raw, ica, cfg):
    """Use ``find_bads_eog`` / ``_ecg`` / ``_muscle`` heuristics."""
    bads = set()
    for ch in cfg.get("find_bads_eog_ch", []):
        if ch in raw.ch_names and ch not in raw.info["bads"]:
            try:
                eog_idx, _ = ica.find_bads_eog(raw, ch_name=ch, verbose=False)
                bads.update(eog_idx)
            except Exception as e:
                logging.warning(
                    "find_bads_eog(%s) failed: %s", ch, e)

    if cfg.get("find_bads_ecg", True):
        try:
            ecg_idx, _ = ica.find_bads_ecg(raw, method="ctps", verbose=False)
            bads.update(ecg_idx)
        except Exception as e:
            logging.warning("find_bads_ecg failed: %s", e)

    if cfg.get("find_bads_muscle", True):
        try:
            mus_idx, _ = ica.find_bads_muscle(raw, verbose=False)
            bads.update(mus_idx)
        except Exception as e:
            logging.warning("find_bads_muscle failed: %s", e)

    logging.info("find_bads: removing %d components", len(bads))
    return bads


def _select_manual(raw, ica, preselected, manual_hook=None):
    """Open an interactive ``plot_sources`` window for the user.

    *preselected* is seeded into ``ica.exclude`` before the plot opens
    so the user sees (and can override) whatever the automatic stages
    flagged.

    When *manual_hook* is set (GUI mode), it is called with
    ``(raw, ica)`` on the GUI main thread and must return the final
    set of excluded component indices. Without a hook (CLI), the
    plot opens in-process with ``block=True``.
    """
    ica.exclude = list(preselected)
    if manual_hook is not None:
        exclude = manual_hook(raw, ica)
        ica.exclude = list(exclude)
    else:
        ica.plot_sources(raw, block=True)
    return set(ica.exclude)


# ── Stage 4: apply + audit tree ─────────────────────────────────────


def _apply_and_audit(raw, fit_copy, ica, bads, cfg, path, file_name):
    """Apply the unmixing with *bads* excluded and write audit files.

    Returns the cleaned signal.  Audit outputs (topomap PNGs,
    classification CSV, ica.fif model, mne.Report HTML) are written
    when ``config["ICA_EOG"]["save_components_audit"]`` is true.
    The cleaned-signal snapshot is gated separately by the panel's
    🗄️ drawer toggle (``config["ICA_EOG"]["save"]``) and is written
    by the step orchestrator's ``_save_step_signal_if_requested``.
    """
    ica.exclude = list(bads)
    # ica.apply rewrites the raw's data buffer in-place, so the
    # underlying signal must be preloaded.  raw.copy() inherits the
    # lazy state of its source after the readmanager deepcopy fix
    # (was silently preloaded before that), so call load_data()
    # explicitly here.
    cleaned = ica.apply(raw.copy().load_data(), exclude=ica.exclude)

    if not cfg.get("save_components_audit", False):
        return cleaned

    out_dir = os.path.join(path, "artifacts_detection", "ICA_EOG")
    os.makedirs(out_dir, exist_ok=True)

    n_comp = int(ica.n_components_)

    # MNE's plot_properties emits a multi-line INFO block per component
    # (RawArray creation, multitaper DPSS, event finding, epoch build).
    # For 20+ components that floods the log.  Suppress INFO/WARNING
    # from MNE across the whole audit block — real errors still surface.
    import matplotlib.pyplot as _plt
    with mne.utils.use_log_level("ERROR"):
        # Per-component topomaps (one figure per N components, fast).
        try:
            figs = ica.plot_components(res=128, show=False)
            figs = figs if isinstance(figs, list) else [figs]
            for i, fig in enumerate(figs):
                suffix = f"_{i}" if len(figs) > 1 else ""
                fig.savefig(os.path.join(
                    out_dir, f"{file_name}_ICA_topomap{suffix}.png"))
                _plt.close(fig)
        except Exception as e:
            logging.warning("ICA topomap plotting failed: %s", e)

        # Per-component property plots.  We loop one component at a time
        # rather than calling plot_properties(picks=np.arange(n)) in bulk
        # so we can emit IDE4EEG progress lines mid-run — otherwise the
        # pipeline looks frozen for tens of seconds while MNE spins.
        logging.info(
            "ICA audit: generating property plots for %d components...",
            n_comp)
        n_saved = 0
        for i in range(n_comp):
            try:
                # reject=None: we already rejected at fit time via
                # ica.reject_; MNE's reject='auto' path has an OOB bug
                # (epoch_var indexed by original-signal indices) that
                # fires whenever any 2-sec window was dropped.
                prop_figs = ica.plot_properties(
                    fit_copy, picks=[i], show=False, verbose=False,
                    reject=None)
            except Exception as e:
                logging.warning(
                    "ICA property plotting failed at component %d: %s", i, e)
                continue
            for fig in prop_figs:
                fig.savefig(os.path.join(
                    out_dir, f"{file_name}_ICA_properties_{i}.png"))
                _plt.close(fig)
                n_saved += 1
            # Periodic progress: every 5 components, plus the final one.
            if (i + 1) % 5 == 0 or (i + 1) == n_comp:
                logging.info("ICA audit: component %d/%d", i + 1, n_comp)
        logging.info("ICA audit: done (%d figures saved)", n_saved)

        # Classification CSV (component, class, prob, kept/removed)
        try:
            _write_classification_csv(
                ica, bads, cfg, os.path.join(
                    out_dir, f"{file_name}_ica_classification.csv"))
        except Exception as e:
            logging.warning("ICA classification CSV write failed: %s", e)

        # Serialised ICA object
        try:
            ica.save(os.path.join(out_dir, f"{file_name}-ica.fif"),
                     overwrite=True)
        except Exception as e:
            logging.warning("ICA .fif save failed: %s", e)

        # mne.Report tying everything together
        try:
            report = mne.Report(title=f"ICA report — {file_name}")
            # n_jobs=1: add_ica dispatches via a local closure that
            # joblib's loky backend can't pickle on Windows when
            # parallelism.n_jobs > 1.
            report.add_ica(
                ica=ica, title="ICA decomposition", inst=fit_copy,
                n_jobs=1)
            report.save(
                os.path.join(out_dir, f"{file_name}_ica_report.html"),
                overwrite=True, open_browser=False)
        except Exception as e:
            logging.warning("mne.Report generation failed: %s", e)

    return cleaned


def _write_classification_csv(ica, bads, cfg, out_path):
    """Write a per-component classification table to *out_path*."""
    import csv
    bads_set = set(bads)
    header = ["component", "label", "max_prob", "status"]
    rows = []

    labels = getattr(ica, "_ica_classification_labels", None)
    probs = getattr(ica, "_ica_classification_probs", None)

    for i in range(ica.n_components_):
        label = labels[i] if labels is not None else ""
        if probs is not None:
            max_p = float(np.asarray(probs[i]).max())
        else:
            max_p = ""
        status = "removed" if i in bads_set else "kept"
        rows.append([i, label, max_p, status])

    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)
