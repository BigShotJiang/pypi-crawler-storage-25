"""File loading and format detection for IDE4EEG.

Reads TOML configuration, discovers signal files in a directory, and
loads EEG data from BrainTech (.raw), BrainVision (.vhdr), FIF (.fif),
EEGLAB (.set), EDF (.edf), and BDF (.bdf) formats into MNE RawArray objects.
"""

# Author: Szymon Bocian, 2022

import os

import logging
import tomllib
import mne
from obci_readmanager.signal_processing.read_manager import ReadManager
import numpy as np

from .. import OUTPUT_DIR_PREFIX

#: Signal file extensions IDE4EEG knows how to load. Single source of
#: truth — the format dispatch in :func:`load_signal` and any GUI code
#: that needs to recognize signal files should reference this tuple.
SIGNAL_EXTENSIONS = (".raw", ".vhdr", ".fif", ".set", ".edf", ".bdf")

#: BrainTech ``<eegSystemSymbol>`` → IDE4EEG montage-combo display name.
#: Anything not in this map yields no hint (e.g. ``EEG GENERIC``,
#: empty/missing element, or future symbols we haven't taught the GUI
#: about). Requires readmanager >= 1.6.0, which exposes the symbol via
#: ``rm.get_param("eeg_system_symbol")``.
_BRAINTECH_SYSTEM_TO_GUI_MONTAGE = {
    "EEG_10_20": "10-20",
    "EEG_10_10": "10-10",
    "EEG_10_05": "10-05",
}

#: Format for synthesised event labels covering raw integer pulses in
#: OBCI_STIM that aren't bound to a named tag.  Same string is parsed
#: in gui.py to enumerate "(code N)" entries — keep the two in sync.
UNNAMED_CODE_LABEL = "(code {})"


def _resolve_braintech_montage_hint(rm):
    """Return a Montage-combo display name based on the BrainTech XML
    ``<eegSystemSymbol>``, or ``None`` if no usable hint is present.

    Defensive: missing element, empty element (the readmanager 1.6
    reader can crash on self-closing tags via ``firstChild.nodeValue``
    on ``None``), and unrecognised symbols all degrade silently to
    ``None``.
    """
    try:
        symbol = rm.get_param("eeg_system_symbol")
    except Exception:
        return None
    if not symbol:
        return None
    return _BRAINTECH_SYSTEM_TO_GUI_MONTAGE.get(symbol.strip())


# ---------------------------------------------------------------------
# Channel type inference
# ---------------------------------------------------------------------
#
# IDE4EEG's channel-typing policy delegates all name-based decisions to
# readmanager's ``chtype_heuristic`` (readmanager >= 1.4.0). Readmanager
# emits the full 7-type MNE vocabulary (eog/emg/ecg/bio/stim/eeg/misc)
# via substring rules + tokenised 10-05 position lookup — see the
# ``chtype_heuristic`` docstring in the readmanager package for the
# complete decision order.
#
# IDE4EEG's overlay adds only one piece of policy on top: we respect any
# *specific* type the file-format reader assigned (e.g. FIF metadata,
# BrainVision header, EEGLAB chanlocs). Only channels whose initial
# type is the ambiguous MNE default ``"eeg"`` (or missing) get handed
# to readmanager for a name-based decision. Channels already typed as
# ``"misc"`` by a reader are treated as "deliberately unclassified" and
# left alone — this matters for FIF files whose authors explicitly
# flagged a channel as misc to exclude it from EEG analysis.
#
# The ``_refine_channel_types`` helper applies the overlay to every
# channel of a loaded MNE Raw, centralising the ``raw.set_channel_types``
# plumbing and suppressing MNE's harmless "unit changed" warning.

from obci_readmanager.signal_processing.mne_utils.utils import (
    chtype_heuristic as _readmanager_chtype_heuristic,
)


#: MNE reader types that count as "ambiguous default" and should be
#: delegated to readmanager's name-based heuristic. Everything else is
#: treated as authoritative and returned unchanged by the overlay.
#:
#: ``"eeg"`` is in this set because MNE's EDF/BDF reader defaults every
#: channel to ``"eeg"`` regardless of the name — so a literal ``"eeg"``
#: from those readers is not authoritative, it's the permissive default.
#:
#: ``"misc"`` is NOT in this set: after readmanager 1.4.0 emits specific
#: types for channels it can identify, ``"misc"`` from any source means
#: "deliberately unclassified" and should be respected.
_DELEGABLE_CHANNEL_TYPES = {None, "", "eeg"}


def _classify_channel_type(name, initial_type="eeg"):
    """Refine a channel type using readmanager's ``chtype_heuristic``.

    Respects any specific type the file-format reader already assigned.
    Only the ambiguous default ``"eeg"`` (MNE EDF/BDF fall-through) is
    eligible for name-based refinement via
    :func:`obci_readmanager.signal_processing.mne_utils.utils.chtype_heuristic`.

    Parameters
    ----------
    name : str
        Channel name as it appears in ``raw.info["ch_names"]``.
    initial_type : str, optional
        The type the file reader assigned. Default ``"eeg"`` matches
        MNE's EDF/BDF default. Pass whatever the reader returned;
        non-generic types are returned unchanged.

    Returns
    -------
    str
        Either ``initial_type`` unchanged (specific reader types respected),
        or the result of ``readmanager.chtype_heuristic(name)`` (for
        generic inputs).

    Examples
    --------
    >>> _classify_channel_type("Fp1", "eeg")
    'eeg'
    >>> _classify_channel_type("EOG Left Horiz", "eeg")  # EDF default
    'eog'
    >>> _classify_channel_type("ECG ECGI", "eeg")
    'ecg'
    >>> _classify_channel_type("Resp Thermistor", "eeg")
    'bio'
    >>> _classify_channel_type("Fp1", "misc")  # FIF deliberately misc — respect it
    'misc'
    >>> _classify_channel_type("F3", "eog")  # Reader said eog — respect it
    'eog'
    >>> _classify_channel_type("EEG 001", "eeg")  # MNE sample: heuristic says misc, trust reader
    'eeg'
    """
    if initial_type not in _DELEGABLE_CHANNEL_TYPES:
        return initial_type
    refined = _readmanager_chtype_heuristic(name)
    # The heuristic returns ``'misc'`` as a "no positive match" fallback
    # (unrecognised substrings + no 10-20 position match).  When the
    # reader had already typed the channel as ``'eeg'`` — as MNE does
    # for FIF files with channels like ``"EEG 001"`` that don't follow
    # the 10-20 naming convention — demoting to ``'misc'`` silently
    # strips every EEG channel from the pipeline and breaks
    # re-reference, ICA, etc.  Only override when the heuristic has
    # concrete evidence for a specific non-EEG type.
    if refined == "misc" and initial_type == "eeg":
        return "eeg"
    return refined


def _refine_channel_types(raw):
    """Apply :func:`_classify_channel_type` to every channel of an MNE
    Raw object in-place, calling ``raw.set_channel_types`` only for
    channels whose type actually changes.

    Safe to call on any Raw produced by any file-format reader or by
    readmanager. Returns the same Raw for convenience.

    Suppresses MNE's ``RuntimeWarning`` about channel units implicitly
    changing when a channel is promoted from ``misc`` (unit NA) to a
    specific type (unit V) — the data is unchanged, only the assumed
    unit metadata, and that's exactly what we're doing on purpose.
    """
    import warnings
    current = raw.get_channel_types()
    updates = {}
    for name, t in zip(raw.ch_names, current):
        refined = _classify_channel_type(name, t)
        if refined != t:
            updates[name] = refined
    if updates:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message=r"The unit for channel\(s\).*has changed",
                category=RuntimeWarning,
            )
            raw.set_channel_types(updates, verbose=False)
    return raw


def _apply_type_overrides(raw, overrides):
    """Apply user-specified channel type overrides to an MNE Raw.

    Overrides always win — they're the user's final word after both
    the file reader's initial typing and the ``_refine_channel_types``
    overlay. Unknown channel names are logged and skipped (not an
    error — the user may have loaded a different file than the one
    whose overrides were saved in the config).

    Parameters
    ----------
    raw : mne.io.BaseRaw
        The already-loaded Raw to mutate in place.
    overrides : dict
        ``{channel_name: mne_type}`` — values should be valid MNE
        channel-type strings (``'eeg'``, ``'eog'``, ``'emg'``,
        ``'ecg'``, ``'bio'``, ``'stim'``, ``'misc'``, etc.).

    Returns
    -------
    mne.io.BaseRaw
        The same Raw, for chaining.
    """
    if not overrides:
        return raw
    import warnings
    valid_updates = {}
    for name, new_type in overrides.items():
        if name in raw.ch_names:
            valid_updates[name] = new_type
        else:
            logging.info(
                "type_overrides: channel %r not in file, skipping", name)
    if valid_updates:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message=r"The unit for channel\(s\).*has changed",
                category=RuntimeWarning,
            )
            raw.set_channel_types(valid_updates, verbose=False)
    return raw


# --- Config files ---
def read_config_file(config_path):
    '''
    Reads toml config file.

    Parameters
    ----------
    config_path: str
        Path to the toml config file.

    Returns
    -------
    config: dict
        The config dictionary with necessary variables.
    '''

    with open(config_path, "rb") as f:
        config = convert_strings(tomllib.load(f))
    # Surface typos / wrong-shape sections via a single logger call
    # before defaults are filled in.  Same hook as the GUI's load_toml;
    # batch mode (`ide4eeg --run`) routes here.  Advisory only.
    from ..config_schema import validate_config
    validate_config(config, source=str(config_path))
    config = check_and_prepare_config(config)  # preparing default variables if they are not specified in original config

    return config


def convert_strings(config):
    '''
    Converts strings "None", "True" and "False" to the None and bool type.
    Converts strings "inf", "np.inf", "oo" and "+oo" to the np.inf.
    Converts paths with '\\' to '/' and removes spaces in paths.
    Converts strings with commas to lists of strings.
    
    Parameters
    ----------
    config: dict
        Dictionary of configuration variables.

    Returns
    -------
    config: dict
        Dictionary of configuration variables with correct types.
    '''

    for var in config:
        if isinstance(config[var], dict):
            config[var] = convert_strings(config[var])
        elif isinstance(config[var], str):
            if config[var] in ["inf", "np.inf", "oo", "+oo"]:
                config[var] = np.inf
            elif config[var] == "None":
                config[var] = None
            elif config[var] == "True":
                config[var] = True
            elif config[var] == "False":
                config[var] = False
            elif var.endswith("_path"):
                # Path values — only normalise backslashes, never split.
                config[var] = config[var].replace("\\", "/")
            elif "," in config[var]:
                config[var] = [s.strip() for s in config[var].split(",")
                               if s.strip()]
            elif "\\" in config[var]:
                config[var] = config[var].replace("\\", "/")
            else:
                # Strip incidental whitespace from bare scalars —
                # `re_reference = " M1"` would otherwise keep the
                # leading space and silently fail exact channel-name
                # matches downstream.  Path values are handled in the
                # branch above, so this can't strip them.
                config[var] = config[var].strip()

    return config


def check_and_prepare_config(config):
    '''
    Checking existence of specific keys in config dictionary.

    Parameters
    ----------
    config: dict
        Dictionary of configuration variables.

    Returns
    -------
    config: dict
        Dictionary of configuration variables with correct types.
    '''


    # Default artifact-rejection thresholds (used by preprocessing/artifacts.py).
    # Three threshold types per artifact: absolute, std-multiple, median-multiple.
    rejection_parameters = {
        'SlopeWindow': 0.0704,  # [s] window width for slopes and outliers
        'MusclesWindow': 0.5,  # [s] window width for muscles

        'OutliersMergeWin': .1,  # [s] width window where we are connect points classified as outliers in groups

        'MusclesFreqRange': [40, 90],  # [Hz, Hz] frequencies for muscles detection

        'SlopesAbsThr': 150,  # [µV] absolute value of amplitude peak-to-peak in SlopeWindow
        'SlopesStdThr': 7,  # peak-to-peak in window as multiple of the standard deviation
        'SlopesMedThr': 6,  # peak-to-peak in window as multiple of the median

        'OutliersAbsThr': 150,  # [µV] absolute value of amplitude
        'OutliersStdThr': 7,  # peak-to-peak in window as multiple of the standard deviation
        'OutliersMedThr': 13,  # peak-to-peak in window as multiple of the median

        'MusclesAbsThr': .150,  # [µV²] absolute value of the mean of spectral density for point in the MusclesFreqRange
        'MusclesStdThr': 7,  # amplitude as multiple of the standard deviation
        'MusclesMedThr': 5,  # amplitude as multiple of the median
    }

    # -- Populate config defaults for keys the user may omit --

    # [Hz] resampling frequency
    if "resample_freq" not in config.keys():
        config["resample_freq"] = 512

    # [s] absolute start time for signal trimming (crop before this time)
    if "trim_start" not in config:
        config["trim_start"] = 0.0

    # [s or None] absolute end time for signal trimming (crop after this time);
    # None means keep to the end of the signal
    if "trim_end" not in config:
        config["trim_end"] = None

    # Backward compatibility: convert old ignore_before/ignore_after to trim_start/trim_end
    if config.get("ignore_before", 0.0) and config["trim_start"] == 0.0:
        config["trim_start"] = float(config["ignore_before"])
    # ignore_after needs signal duration — resolved at runtime in trim_signal()

    # Deprecated: cover_time and threshold_time are no longer used.
    # They previously removed gaps between event groups, creating temporal
    # discontinuities. Trimming is now handled by trim_start/trim_end.
    if config.get("cover_time") is not None or config.get("threshold_time") is not None:
        logging.warning(
            "cover_time and threshold_time are deprecated and ignored. "
            "Use trim_start / trim_end to crop the signal instead.")
    config.setdefault("cover_time", None)
    config.setdefault("threshold_time", None)

    # [V] checking signal above of the threshold and cut it out of the signal - amplitude bad segment classification
    if "amplitude_max_threshold" not in config.keys():
        config["amplitude_max_threshold"] = 150e-6

    # how many channels should be above threshold to classified as bad segment?
    if "amplitude_nchan_threshold" not in config.keys():
        config["amplitude_nchan_threshold"] = 0.33

    # [s] how much signal should we take around segment which is above threshold?
    if "amplitude_time_threshold" not in config.keys():
        config["amplitude_time_threshold"] = 0.02

    # [Hz] lowpass filter frequency for bad segment classification
    if "amplitude_l_freq" not in config.keys():
        config["amplitude_l_freq"] = 1

    # [Hz] highpass filter frequency for bad segment classification
    if "amplitude_h_freq" not in config.keys():
        config["amplitude_h_freq"] = 40

    # -- Channel-quality parameters (see ValidateChannels_Noise) --

    # "name": [width, band, thresholds_type, thresholds]
    #     width [s] -> width of window to cut signal for segments
    #     band [Hz, Hz] -> frequency band where program will search for bad channels
    #     thresholds_type -> "+" (power above thresholds will be classified as good) or
    #                        "-" (power below thresholds will be classified as good)
    #     thresholds [μV^2, μV^2, μV^2] -> three threshold necessary to find bad channels to check power of
    #                                      cut segments from signal
    config.setdefault("choosing_channels", {})
    if "badchs_params" not in config["choosing_channels"].keys():
        config["choosing_channels"]["badchs_params"] = {"slow_oscillations": [1, [2, 10], "-", [1e3, 1e4, 1e5]],
                                                        "noise_power": [1, [52, 98], "-", [2e1, 2e2, 2e3]]}

    # correlation out of this window will be classified as bad
    # 2026-05-13: schema migration — older TOMLs used "correlation_window"
    # presence as the on/off toggle for correlation-based bad-channel
    # detection.  The new schema has an explicit `enable_correlation`
    # boolean (DEFAULT_CONFIG ships it `False`).  Auto-promote any
    # pre-migration TOML that had `correlation_window` set but lacks
    # the boolean, preserving the legacy "presence == enabled"
    # semantics on load.
    cc = config["choosing_channels"]
    if "correlation_window" in cc and "enable_correlation" not in cc:
        cc["enable_correlation"] = True
        logging.info("Migrated config: correlation_window presence "
                     "→ enable_correlation=True")
    cc.setdefault("enable_correlation", False)
    cc.setdefault("correlation_window", [0.75, 0.975])
    cc.setdefault("correlation_badch_threshold", 0.95)


    # -- Backward compat: rename misspelled config keys from older versions --
    bcp = config.get("choosing_channels", {}).get("badchs_params", {})
    if "slow_oscilations" in bcp:
        bcp["slow_oscillations"] = bcp.pop("slow_oscilations")
        logging.info("Migrated config key: slow_oscilations → slow_oscillations")

    # -- Resolve filter config -----------------------------------------------
    # Two layouts to support:
    #   - Flat (legacy single filter): cfg["filters"] = {"highpass_freq": ...}
    #   - Multi-instance (Phase 2):   cfg["filters"] = {"<id>": {...}, ...}
    # Inject flat defaults ONLY in the flat case — otherwise the
    # _step_filtering dispatch's `is_flat` heuristic flips and silently
    # zeroes out the per-block filter values (the bug that made the
    # Filters step a no-op for multi-instance configs).
    filt = config.setdefault("filters", {})
    is_multi = (
        isinstance(filt, dict)
        and any(isinstance(v, dict) for v in filt.values())
    )
    if not is_multi:
        filt.setdefault("highpass_freq", 0)
        filt.setdefault("lowpass_freq", 0)
        filt.setdefault("notch_freq", 0)
        filt.setdefault("method", "iir")


    # -- Segmentation mode defaults --
    from ide4eeg.preprocessing.channels_and_signal import get_segmentation_mode
    mode = get_segmentation_mode(config)
    if mode == "rest":
        rest = config.setdefault("rest", {})
        rest.setdefault("rest_duration", [0, ""])
        rest.setdefault("window_length", 20)
    elif mode == "epochs":
        epochs = config.setdefault("epochs", {})
        epochs.setdefault("tags", {"selected": []})
        epochs.setdefault("start_offset", -0.3)
        epochs.setdefault("stop_offset", 0.7)

    # -- Artifact rejection defaults --
    config.setdefault("artifacts", {})
    config["artifacts"].setdefault("artifact_threshold", 0.3)
    if "rejection_parameters" not in config["artifacts"].keys():
        config["artifacts"]["rejection_parameters"] = rejection_parameters


    # -- ICA defaults -- Phase 4 redesign: Picard + ICLabel, see
    #    project_ica_redesign.md for the full spec.
    config.setdefault("ICA_EOG", {})
    config["ICA_EOG"].setdefault("method", "picard")
    config["ICA_EOG"].setdefault("random_state", 42)
    config["ICA_EOG"].setdefault("fit_highpass_hz", 1.0)
    config["ICA_EOG"].setdefault("decim", 1)
    config["ICA_EOG"].setdefault("reject_uv", 500.0)
    config["ICA_EOG"].setdefault("n_components", "rank")
    config["ICA_EOG"].setdefault("selector", "iclabel")
    config["ICA_EOG"].setdefault("iclabel_keep", ["brain", "other"])
    config["ICA_EOG"].setdefault("iclabel_min_prob", 0.0)
    config["ICA_EOG"].setdefault("find_bads_eog_ch", ["Fp1", "Fp2", "Fpz"])
    config["ICA_EOG"].setdefault("find_bads_ecg", True)
    config["ICA_EOG"].setdefault("find_bads_muscle", True)


    # -- Epoch rejection defaults --
    config.setdefault("epochs", {})
    # reject dictionary, if peak-to-peak of min-max in epoch is greater than value in reject_dict, then epoch will be rejected
    if "reject_dict" not in config["epochs"].keys():
        config["epochs"]["reject_dict"] = dict(eeg=500e-6)

    # reject dictionary, if peak-to-peak of min-max in epoch is smaller than value in reject_dict, then epoch will be rejected
    if "flat_dict" not in config["epochs"].keys():
        config["epochs"]["flat_dict"] = dict(eeg=1e-6)


    _validate_config(config)
    return config


def _validate_config(config):
    """Validate and clamp user-provided config values.

    Issues warnings for out-of-range values and clamps them to safe
    defaults so the pipeline doesn't crash on invalid input.
    """

    def _clamp(section, key, lo, hi, default, label=None):
        """Clamp config[section][key] to [lo, hi], warn if changed."""
        if isinstance(section, str):
            d = config.get(section, {})
            val = d.get(key)
        else:
            d = section
            val = d.get(key)
        if val is None:
            return
        try:
            val = float(val)
        except (ValueError, TypeError):
            logging.warning("%s: non-numeric value %r, using default %s.",
                            label or key, val, default)
            d[key] = default
            return
        if val < lo or val > hi:
            clamped = max(lo, min(hi, val))
            logging.warning("%s = %s is out of range [%s, %s], "
                            "clamped to %s.",
                            label or key, val, lo, hi, clamped)
            d[key] = clamped

    # -- Amplitude thresholds --
    _clamp(config, "amplitude_max_threshold",
           0, 1e-2, 150e-6, "amplitude_max_threshold")
    _clamp(config, "amplitude_nchan_threshold",
           0, 1.0, 0.33, "amplitude_nchan_threshold")
    _clamp(config, "amplitude_time_threshold",
           0, 10.0, 0.02, "amplitude_time_threshold")

    # amplitude filter band: l_freq < h_freq
    l_freq = config.get("amplitude_l_freq", 1)
    h_freq = config.get("amplitude_h_freq", 40)
    if l_freq >= h_freq:
        logging.warning("amplitude_l_freq (%s) >= amplitude_h_freq (%s), "
                        "resetting to [1, 40] Hz.", l_freq, h_freq)
        config["amplitude_l_freq"] = 1
        config["amplitude_h_freq"] = 40

    # -- Artifact threshold --
    _clamp(config.setdefault("artifacts", {}), "artifact_threshold",
           0, 1.0, 0.3, "artifacts.artifact_threshold")

    # -- Filter frequencies (must be >= 0) --
    # Multi-filter form (Phase 2): validate each sub-block separately.
    # Flat form (legacy): validate top-level keys.
    filt = config.setdefault("filters", {})
    _filter_blocks = (
        list(filt.values())
        if isinstance(filt, dict)
        and any(isinstance(v, dict) for v in filt.values())
        else [filt]
    )
    for block in _filter_blocks:
        if not isinstance(block, dict):
            continue
        for fk in ("highpass_freq", "lowpass_freq", "notch_freq"):
            v = block.get(fk)
            if v is not None:
                try:
                    v = float(v)
                except (ValueError, TypeError):
                    v = 0
                if v < 0:
                    logging.warning("filters.%s = %s is negative, set to 0.",
                                    fk, v)
                    block[fk] = 0
        # highpass must be < lowpass (when both are set and > 0)
        hp = block.get("highpass_freq", 0)
        lp = block.get("lowpass_freq", 0)
        if hp and lp and hp >= lp:
            logging.warning("highpass_freq (%s) >= lowpass_freq (%s), "
                            "disabling both.", hp, lp)
            block["highpass_freq"] = 0
            block["lowpass_freq"] = 0

    # -- Trim: start < end --
    ts = config.get("trim_start", 0)
    te = config.get("trim_end")
    if ts is not None and te is not None:
        try:
            if float(ts) >= float(te):
                logging.warning("trim_start (%s) >= trim_end (%s), "
                                "resetting trim_start to 0.", ts, te)
                config["trim_start"] = 0.0
        except (ValueError, TypeError):
            pass

    # -- Rest window --
    rest = config.setdefault("rest", {})
    wl = rest.get("window_length")
    if wl is not None:
        try:
            if float(wl) <= 0:
                logging.warning("rest.window_length (%s) <= 0, "
                                "set to 5.", wl)
                rest["window_length"] = 5
        except (ValueError, TypeError):
            pass

    # -- Epochs: start_offset < stop_offset --
    epochs = config.setdefault("epochs", {})
    so = epochs.get("start_offset")
    eo = epochs.get("stop_offset")
    if so is not None and eo is not None:
        try:
            if float(so) >= float(eo):
                logging.warning("epochs.start_offset (%s) >= "
                                "stop_offset (%s), resetting to "
                                "[-0.3, 0.7].", so, eo)
                epochs["start_offset"] = -0.3
                epochs["stop_offset"] = 0.7
        except (ValueError, TypeError):
            pass

    # -- Sleep staging: epoch_length > 0 --
    ss = config.setdefault("sleep_staging", {})
    el = ss.get("epoch_length")
    if el is not None:
        try:
            if float(el) <= 0:
                logging.warning("sleep_staging.epoch_length (%s) <= 0, "
                                "set to 20.", el)
                ss["epoch_length"] = 20
        except (ValueError, TypeError):
            pass

# --- Signal files ---
def find_file_paths(dirpath):
    '''
    Searching signals in directory.

    Parameters
    ----------
    dirpath: str
        Path of the directory where program will be searching for signals.

    Returns
    -------
    list_of_filepaths: list
        List with paths to the signals found in the input directory.
    '''

    file_extension = [".raw", ".vhdr", ".fif", ".set", ".edf", ".bdf"]  # formats of the files
    list_of_filepaths = []

    for root, _, files in os.walk(dirpath):
        for file in files:
            if os.path.splitext(file)[1] in file_extension:
                # skip files inside IDE4EEG/P3ACE output directories
                full = os.path.join(root, file)
                if (OUTPUT_DIR_PREFIX not in full
                        and "P3ACE_output__" not in full
                        and "P3ACE_OUT_" not in full):
                    list_of_filepaths.append(os.path.join(root, file))

    return list_of_filepaths


def braintech_format(name):
    '''
    Read file for .raw, .xml and .tag formats provided by BrainTech.

    Parameters
    ----------
    name: str
        Path with name of the file (without .raw format) to the file with .raw.

    Returns
    -------
    mne_signal: mne.io.array.array.RawArray
        The read signal from the mne object with STIM channel. The STIM has occurrence of the events.
    events_desc_id: dict
        Dictionary of the names of the events and their indexes in the STIM channel - this is necessary for mapping
        events the STIM channel. The dict looks like this: {'event_name_1': 1, 'event_name_2': 2, ...}.
    '''

    tag_path = name + '.tag'
    tag_source = tag_path if os.path.isfile(tag_path) else ''
    tag_error = None

    if not tag_source:
        logging.info(f"No .tag file found for {name} — "
                     "only resting-state analysis will be available.")

    # Read with tag file; if the tag is corrupt, retry without it
    # so the signal is still usable for resting-state analysis.
    logging.getLogger("tags_file_reader").setLevel(logging.CRITICAL)
    try:
        raw = ReadManager(name + '.xml', name + '.raw', tag_source)
        raw = braintech__prepare_tags(raw)
    except Exception as exc:
        if tag_source:
            tag_error = str(exc)
            logging.warning(
                "Tag file %s is unreadable (%s). "
                "Continuing without events — only resting-state "
                "analysis will be available.", tag_path, tag_error)
            raw = ReadManager(name + '.xml', name + '.raw', '')
        else:
            raise
    finally:
        logging.getLogger("tags_file_reader").setLevel(logging.NOTSET)

    # readmanager>=1.5 returns a lazy BaseRaw subclass with preload=False
    # — pages samples from disk on demand, essential for multi-hour
    # recordings.  The pin in requirements.txt guarantees this kwarg.
    try:
        mne_signal = raw.get_mne_raw(preload=False)
    except IndexError:
        raise RuntimeError(
            f"Could not read signal: file appears to have no data "
            f"samples. Check if the file is complete/not corrupted.")

    if "OBCI_STIM" in mne_signal.info["ch_names"]:
        mne.rename_channels(mne_signal.info, {"OBCI_STIM": "STIM"})

    _refine_channel_types(mne_signal)

    if tag_error:
        events_desc_id = {}
    else:
        try:
            events_desc_id = _normalize_obci_event_keys(
                raw.mne_events()[1])
        except Exception as exc:
            logging.warning(
                "Failed to extract events from %s: %s. "
                "Continuing without events.", tag_path, exc)
            events_desc_id = {}

    # Extend events_desc_id with synthesised "(code N)" entries for
    # codes present in OBCI_STIM but not bound to a named OBCI tag.
    # These are typically button-box codes, sync pulses, or raw
    # amplifier markers the experiment software wrote directly to the
    # STIM channel.  Without this extension the GUI cannot let the
    # user epoch on them and _build_event_dict can't translate the
    # synthesised "(code N)" labels into integer codes.
    try:
        named_codes = set(events_desc_id.values())
        for code in _scan_stim_unique_codes(mne_signal).keys():
            if code not in named_codes:
                events_desc_id[UNNAMED_CODE_LABEL.format(code)] = code
    except Exception as exc:
        logging.warning(
            "Failed to scan STIM for unnamed codes in %s: %s",
            name, exc)

    return mne_signal, events_desc_id


def _scan_stim_unique_codes(mne_signal):
    """Return ``{int_code: count}`` for non-zero codes in the STIM /
    OBCI_STIM channel of *mne_signal* (a Raw, possibly preload=False).

    Used to surface integer pulses written into the STIM channel
    that aren't bound to symbolic tag names — typically button-box
    codes, sync markers, or raw stimulus codes the experiment
    software wrote alongside the named tags.  The GUI shows these
    as ``"(code N)"`` entries in the events panel so the user can
    epoch on them too.

    Cheap even for multi-hour recordings: pulls one int channel
    from disk via ``get_data(picks=...)``.  Returns an empty dict
    on any failure (no STIM channel, unreadable, etc.).
    """
    stim_name = None
    for n in ("OBCI_STIM", "STIM"):
        if n in mne_signal.info["ch_names"]:
            stim_name = n
            break
    if stim_name is None:
        return {}
    try:
        stim_data = mne_signal.get_data(picks=stim_name)[0].astype(int)
    except Exception:
        return {}
    nonzero = stim_data[stim_data > 0]
    if nonzero.size == 0:
        return {}
    codes, counts = np.unique(nonzero, return_counts=True)
    return {int(c): int(n) for c, n in zip(codes, counts)}


def _normalize_obci_event_keys(events_desc_id):
    """Strip OBCI's JSON-serialized tag wrapper from event names.

    The OBCI ReadManager exposes event keys as full JSON dicts like
    ``'{"name": "red_bl1", "channels": "", "desc": {}}'``.  Replace each
    key with just the ``name`` field so the user's config tags
    (``"red_bl1"``) match the file events.  Keys that aren't JSON or
    don't carry a ``name`` are left alone.
    """
    import json as _json
    normalized = {}
    for key, eid in events_desc_id.items():
        skey = str(key)
        new_key = skey
        if skey.startswith("{"):
            try:
                parsed = _json.loads(skey)
                if isinstance(parsed, dict) and parsed.get("name"):
                    new_key = parsed["name"]
            except (ValueError, TypeError):
                pass
        normalized[new_key] = eid
    return normalized


def _append_synthetic_stim(mne_signal, annot_events=None):
    """Append a ``STIM``-typed channel to *mne_signal* in place.

    Parameters
    ----------
    mne_signal : mne.io.Raw
        Signal to append to.  Loaded into memory if not already.
    annot_events : numpy.ndarray or None
        Events array from :func:`mne.events_from_annotations` — shape
        ``(n, 3)`` where column 0 is sample index and column 2 is the
        integer event ID.  When ``None`` or empty, an all-zero STIM
        channel is added (used by readers for files with no events).

    Returns
    -------
    mne.io.Raw
        The same signal with a new ``"STIM"`` channel (type ``"stim"``).

    Notes
    -----
    Every file reader in this module (``brainvision_format``,
    ``eeglab_format``, ``edf_format``, ``bdf_format``, and
    ``fif_format`` cases (a) and (b)) shares the same idiom: build a
    ``(1, n_times)`` zero array, write pulses at annotation samples,
    wrap it in a ``RawArray`` of type ``"stim"``, and append via
    ``add_channels``.  This helper is the single place that lives.
    """
    stim = np.zeros((1, mne_signal.n_times))
    if annot_events is not None and len(annot_events):
        stim[0, annot_events[:, 0]] = annot_events[:, 2]
    stim_raw = mne.io.RawArray(
        stim,
        mne.create_info(["STIM"], mne_signal.info["sfreq"], ["stim"]),
    )
    mne_signal.load_data().add_channels([stim_raw], force_update_info=True)
    return mne_signal


def brainvision_format(name):
    '''
    Read file for .vhdr, .vmrk and .eeg formats provided by BrainVision.

    Parameters
    ----------
    name: str
        Path with name of the file (without .vhdr) to the file with .vhdr.

    Returns
    -------
    mne_signal: mne.io.array.array.RawArray
        The read signal from the mne object with STIM channel. The STIM has occurrence of the events.
    events_desc_id: dict
        Dictionary of the names of the events and their indexes in the STIM channel - this is necessary for mapping
        events the STIM channel. The dict looks like this: {'event_name_1': 1, 'event_name_2': 2, ...}.
    '''

    mne_signal = mne.io.read_raw_brainvision(name + '.vhdr')
    annot_events, events_desc_id = mne.events_from_annotations(mne_signal)
    _append_synthetic_stim(mne_signal, annot_events)
    _refine_channel_types(mne_signal)

    return mne_signal, events_desc_id


def _check_stim_annotations_consistency(mne_signal, events_desc_id,
                                         annot_events):
    """Cross-check annotations against a native STIM channel.

    Called by :func:`fif_format` when a FIF file carries both an
    annotation layer and a native STIM channel.  Native STIM is
    authoritative for event sample positions — ``_cut_segments`` later
    reads events with
    :func:`mne.find_events` on ``STIM``, so any event ID referenced by
    annotations but missing from native STIM will silently fail to be
    epoched at cut time.  This function surfaces that mismatch early as
    a warning.

    The function also augments *events_desc_id* so that events present
    in native STIM but absent from annotations get a numeric-string
    fallback name (``"42"`` for ID 42), keeping the downstream contract
    simple: every ID in native STIM has a name in the returned dict.

    Parameters
    ----------
    mne_signal : mne.io.Raw
        The loaded (data in memory) FIF signal.
    events_desc_id : dict
        ``{name: int_id}`` mapping built from annotations.
    annot_events : numpy.ndarray, shape ``(n, 3)``
        Events array from :func:`mne.events_from_annotations`.

    Returns
    -------
    dict
        Possibly augmented *events_desc_id*.
    """
    try:
        native_events = mne.find_events(
            mne_signal, stim_channel="STIM", shortest_event=1,
            verbose=False)
    except ValueError:
        # find_events raises on some empty / malformed STIM channels.
        # Without native events, nothing to cross-check.
        return events_desc_id

    if len(native_events) == 0:
        # STIM channel present but empty — annotations drive everything
        # downstream, nothing to warn about.
        return events_desc_id

    annot_ids = set(int(i) for i in annot_events[:, 2]) \
        if len(annot_events) else set()
    native_ids = set(int(i) for i in native_events[:, 2])

    missing_from_stim = annot_ids - native_ids
    if missing_from_stim:
        orphan_names = sorted(
            n for n, i in events_desc_id.items()
            if int(i) in missing_from_stim)
        logging.warning(
            "FIF file has STIM channel and annotations that disagree: "
            "annotation IDs %s (names: %s) are not present in the "
            "native STIM channel. STIM is authoritative for event "
            "sample positions; events referenced only by annotations "
            "will NOT be found at epoch time.",
            sorted(missing_from_stim), orphan_names)

    extra_in_stim = native_ids - annot_ids
    if extra_in_stim:
        logging.warning(
            "FIF file has STIM channel and annotations that disagree: "
            "native STIM channel has event IDs %s not referenced by "
            "annotations. These events will be available under "
            "numeric-string fallback names.",
            sorted(extra_in_stim))
        for eid in extra_in_stim:
            fallback = str(eid)
            if fallback not in events_desc_id:
                events_desc_id[fallback] = int(eid)

    return events_desc_id


def fif_format(name):
    '''
    Read file for .fif format.

    Parameters
    ----------
    name: str
        Path with name of the file (without .fif) to the file with .fif.

    Returns
    -------
    mne_signal: mne.io.array.array.RawArray
        The read signal from the mne object with STIM channel. The STIM has occurrence of the events.
    events_desc_id: dict
        Dictionary of the names of the events and their indexes in the STIM channel - this is necessary for mapping
        events the STIM channel. The dict looks like this: {'event_name_1': 1, 'event_name_2': 2, ...}.

    Notes
    -----
    Invariants:

    - The returned signal always has a ``STIM`` channel, even if empty.
      Downstream code can safely do ``ch_names.index("STIM")``.
    - When both annotations and a native STIM channel are present,
      :func:`_check_stim_annotations_consistency` cross-checks them
      and warns on mismatch.  Native STIM is authoritative for sample
      positions (downstream ``find_events`` reads from it); annotations
      only supply descriptive names.
    '''

    mne_signal = mne.io.read_raw_fif(name + ".fif")

    # Prefer annotations (carry descriptive event names like "target");
    # fall back to STIM channel if no annotations exist.
    has_annotations = (len(mne_signal.annotations) > 0
                       and any(a["description"] not in ("BAD_", "EDGE")
                               for a in mne_signal.annotations))
    has_native_stim = "STIM" in mne_signal.info["ch_names"]

    # Some FIF files (e.g. MNE sample) have stim-type channels with
    # non-standard names like "STI 014".  Find the most informative
    # one (most unique event IDs) and rename it to "STIM".
    if not has_native_stim and not has_annotations:
        stim_picks = mne.pick_types(mne_signal.info, stim=True)
        if len(stim_picks) > 0:
            mne_signal.load_data()
            best_ch = None
            best_n = 0
            for idx in stim_picks:
                ch_name = mne_signal.ch_names[idx]
                try:
                    ev = mne.find_events(
                        mne_signal, stim_channel=ch_name,
                        shortest_event=1, verbose=False)
                    n_unique = len(set(ev[:, 2])) if len(ev) else 0
                    if n_unique > best_n:
                        best_n = n_unique
                        best_ch = ch_name
                except Exception:
                    pass
            if best_ch and best_n > 0:
                mne.rename_channels(
                    mne_signal.info, {best_ch: "STIM"})
                has_native_stim = True
                logging.info(
                    "Renamed stim channel '%s' → 'STIM' "
                    "(%d event types found).", best_ch, best_n)

    if has_annotations:
        annot_events, events_desc_id = mne.events_from_annotations(
            mne_signal)
        if not has_native_stim:
            _append_synthetic_stim(mne_signal, annot_events)
        else:
            mne_signal.load_data()
            events_desc_id = _check_stim_annotations_consistency(
                mne_signal, events_desc_id, annot_events)
    elif has_native_stim:
        mne_signal.load_data()
        events = mne.find_events(mne_signal, stim_channel="STIM",
                                 shortest_event=1)
        event_ids = sorted(set(events[:, 2])) if len(events) else []
        events_desc_id = {str(eid): eid for eid in event_ids}
    else:
        events_desc_id = {}
        _append_synthetic_stim(mne_signal, annot_events=None)

    _refine_channel_types(mne_signal)
    return mne_signal, events_desc_id


def eeglab_format(name):
    '''
    Read file for .set format.

    Parameters
    ----------
    name: str
        Path with name of the file (without .set) to the file with .set.

    Returns
    -------
    mne_signal: mne.io.array.array.RawArray
        The read signal from the mne object with STIM channel. The STIM has occurrence of the events.
    events_desc_id: dict
        Dictionary of the names of the events and their indexes in the STIM channel - this is necessary for mapping
        events the STIM channel. The dict looks like this: {'event_name_1': 1, 'event_name_2': 2, ...}.
    '''

    mne_signal = mne.io.read_raw_eeglab(name + ".set")
    annot_events, events_desc_id = mne.events_from_annotations(mne_signal)
    _append_synthetic_stim(mne_signal, annot_events)
    _refine_channel_types(mne_signal)

    return mne_signal, events_desc_id


def edf_format(name):
    '''
    Read file for .edf (European Data Format).

    Parameters
    ----------
    name: str
        Path with name of the file (without .edf) to the file with .edf.

    Returns
    -------
    mne_signal: mne.io.array.array.RawArray
        The read signal from the mne object with STIM channel. The STIM has occurrence of the events.
    events_desc_id: dict
        Dictionary of the names of the events and their indexes in the STIM channel - this is necessary for mapping
        events the STIM channel. The dict looks like this: {'event_name_1': 1, 'event_name_2': 2, ...}.
    '''

    logging.info("Reading EDF file: %s.edf", name)
    mne_signal = mne.io.read_raw_edf(name + ".edf", preload=False)
    annot_events, events_desc_id = mne.events_from_annotations(mne_signal)
    logging.info("Loading EDF data into memory (%d channels, %.0f s)...",
                 len(mne_signal.ch_names), mne_signal.times[-1])
    _append_synthetic_stim(mne_signal, annot_events)
    _refine_channel_types(mne_signal)

    return mne_signal, events_desc_id


def bdf_format(name):
    '''
    Read file for .bdf (BioSemi Data Format).

    Parameters
    ----------
    name: str
        Path with name of the file (without .bdf) to the file with .bdf.

    Returns
    -------
    mne_signal: mne.io.array.array.RawArray
        The read signal from the mne object with STIM channel. The STIM has occurrence of the events.
    events_desc_id: dict
        Dictionary of the names of the events and their indexes in the STIM channel - this is necessary for mapping
        events the STIM channel. The dict looks like this: {'event_name_1': 1, 'event_name_2': 2, ...}.
    '''

    logging.info("Reading BDF file: %s.bdf", name)
    mne_signal = mne.io.read_raw_bdf(name + ".bdf", preload=False)
    annot_events, events_desc_id = mne.events_from_annotations(mne_signal)
    logging.info("Loading BDF data into memory (%d channels, %.0f s)...",
                 len(mne_signal.ch_names), mne_signal.times[-1])
    _append_synthetic_stim(mne_signal, annot_events)
    _refine_channel_types(mne_signal)

    return mne_signal, events_desc_id


def read_file_info(filepath):
    """Read only metadata (no data loading) for GUI display.

    Returns dict with keys: ch_names, sfreq, duration, n_channels,
    ch_types, events, or None on failure.
    """
    import mne
    name, ext = os.path.splitext(filepath)
    try:
        if ext == ".raw":
            # BrainTech: read only metadata from .xml/.tag (no data load)
            from obci_readmanager.signal_processing.read_manager import ReadManager
            xml_path = name + ".xml"
            tag_path = name + ".tag"
            tag_src = tag_path if os.path.isfile(tag_path) else ""
            tag_error = None
            logging.getLogger("tags_file_reader").setLevel(logging.CRITICAL)
            try:
                rm = ReadManager(xml_path, name + ".raw", tag_src)
            except Exception as exc:
                if tag_src:
                    tag_error = str(exc)
                    logging.warning(
                        "Tag file %s unreadable: %s", tag_path, exc)
                    rm = ReadManager(xml_path, name + ".raw", "")
                else:
                    raise
            finally:
                logging.getLogger("tags_file_reader").setLevel(
                    logging.NOTSET)
            n_ch = int(rm.get_param("number_of_channels"))
            sfreq = float(rm.get_param("sampling_frequency"))
            ch_names = rm.get_param("channels_names")
            if isinstance(ch_names, str):
                ch_names = [c.strip() for c in ch_names.split(";") if c.strip()]
            # Compute duration from .raw file size (XML sampleCount is
            # unreliable — can be total-across-channels or stale).
            sample_type = rm.get_param("sample_type") if hasattr(
                rm, "get_param") else "FLOAT"
            bytes_per_sample = 8 if "DOUBLE" in str(sample_type).upper() else 4
            raw_path = name + ".raw"
            raw_bytes = os.path.getsize(raw_path)
            samples_per_ch = raw_bytes // (bytes_per_sample * n_ch)
            duration = samples_per_ch / sfreq if sfreq > 0 else 0
            # Events from tags (named only — OBCI tag dictionary)
            events_desc = {}
            try:
                for tag in rm.get_tags():
                    tn = tag.get("name", "") if isinstance(tag, dict) else getattr(tag, "name", "")
                    if tn:
                        events_desc[tn] = events_desc.get(tn, 0) + 1
            except Exception:
                pass
            # Codes present in OBCI_STIM but not bound to named tags
            # — surfaced to the GUI as "(code N)" entries so the user
            # can see / epoch on them.  Cheap (single int channel).
            unnamed_codes = {}
            try:
                if not tag_error:
                    events_desc_id = _normalize_obci_event_keys(
                        rm.mne_events()[1])
                    named_codes = set(events_desc_id.values())
                else:
                    named_codes = set()
                mne_meta = rm.get_mne_raw(preload=False)
                for code, cnt in _scan_stim_unique_codes(mne_meta).items():
                    if code not in named_codes:
                        unnamed_codes[code] = cnt
            except Exception as exc:
                logging.warning(
                    "Could not scan STIM for unnamed codes in %s: %s",
                    name, exc)
            # Channel types: _classify_channel_type delegates to
            # readmanager's chtype_heuristic for generic inputs, so
            # calling it with an empty initial type (the metadata
            # path has no pre-existing type info) gives us the full
            # readmanager classification. The synthetic STIM channel
            # appended below is typed as 'stim' directly.
            ch_types = [_classify_channel_type(cn, "")
                        for cn in ch_names] + ["stim"]
            result = {
                "ch_names": ch_names + ["STIM"],
                "sfreq": sfreq,
                "duration": duration,
                "n_channels": n_ch + 1,
                "ch_types": ch_types,
                "events": events_desc,
                "unnamed_codes": unnamed_codes,
                "raw_bytes": raw_bytes,
                # BrainTech .raw files never carry electrode positions
                "has_native_positions": False,
                # ...but the XML may name the cap layout
                # (eegSystemSymbol). Used by the GUI to prefill the
                # Montage dropdown — None when missing or unmapped.
                "montage_hint": _resolve_braintech_montage_hint(rm),
            }
            if tag_error:
                result["tag_error"] = tag_error
            return result
        # For standard MNE formats, read without preload
        raw = None
        if ext == ".vhdr":
            raw = mne.io.read_raw_brainvision(name + ".vhdr",
                                               preload=False, verbose=False)
        elif ext == ".fif":
            raw = mne.io.read_raw_fif(filepath, preload=False, verbose=False)
        elif ext == ".set":
            raw = mne.io.read_raw_eeglab(filepath, preload=False, verbose=False)
        elif ext == ".edf":
            raw = mne.io.read_raw_edf(filepath, preload=False, verbose=False)
        elif ext == ".bdf":
            raw = mne.io.read_raw_bdf(filepath, preload=False, verbose=False)
        if raw is None:
            return None
        # Extract events from annotations or native stim channels
        events_desc = {}
        if raw.annotations:
            for desc in set(raw.annotations.description):
                if desc and desc.strip():
                    events_desc[desc] = len(
                        [a for a in raw.annotations
                         if a["description"] == desc])
        if not events_desc:
            stim_picks = mne.pick_types(raw.info, stim=True)
            if len(stim_picks) > 0:
                try:
                    stim_raw = raw.copy().pick(stim_picks).load_data()
                    best_desc = {}
                    for ch_name in stim_raw.ch_names:
                        ev = mne.find_events(
                            stim_raw, stim_channel=ch_name,
                            shortest_event=1, verbose=False)
                        if len(ev) == 0:
                            continue
                        desc = {}
                        for eid in sorted(set(ev[:, 2])):
                            desc[str(eid)] = int(sum(ev[:, 2] == eid))
                        if len(desc) > len(best_desc):
                            best_desc = desc
                    events_desc = best_desc
                except Exception:
                    pass
        # Apply the name-substring overlay. Critical for EDF/BDF, where
        # mne.io.read_raw_edf defaults every channel to "eeg" regardless
        # of the name (EDF has no standard channel-type field). Harmless
        # for FIF/EEGLAB/BV where MNE returns authoritative types:
        # _classify_channel_type respects any non-generic initial type.
        raw_types = raw.get_channel_types()
        ch_types = [_classify_channel_type(n, t)
                    for n, t in zip(raw.ch_names, raw_types)]
        # Share the same validity check used by _set_montage so the
        # GUI's prefill/lock decision matches the pipeline's skip
        # decision exactly.
        from ide4eeg.preprocessing.channels_and_signal import (
            _has_native_eeg_positions)
        try:
            has_native_positions = _has_native_eeg_positions(raw)
        except Exception:
            has_native_positions = False
        return {
            "ch_names": list(raw.ch_names),
            "sfreq": raw.info["sfreq"],
            "duration": raw.times[-1] if raw.n_times > 0 else 0,
            "n_channels": len(raw.ch_names),
            "ch_types": ch_types,
            "events": events_desc,
            "raw_bytes": raw.n_times * len(raw.ch_names) * 8,
            "has_native_positions": has_native_positions,
        }
    except Exception as e:
        # Re-raise on Windows-frozen builds so the GUI's Signal Info
        # panel can show the actual failure (NSWindow / PyInstaller
        # frozen apps run with no stdout/stderr, so the previous
        # `logging.warning(...); return None` route hid the cause).
        # The GUI worker (see ``_read_signal_info``) catches and
        # surfaces ``str(e)`` directly.
        logging.warning("read_file_info failed: %s", e, exc_info=True)
        raise


def _detect_format_by_magic(filepath):
    """Sniff the first few bytes to detect a misnamed file.  Returns
    a canonical extension (``.fif`` / ``.set`` / ``.edf`` / ``.bdf``)
    when the magic bytes disagree with the actual extension, else
    ``None``.

    Used as a hint to the user — we don't auto-redirect because that
    would mask configuration mistakes; instead the caller logs a
    warning suggesting the right extension.
    """
    try:
        with open(filepath, "rb") as f:
            head = f.read(16)
    except (OSError, IOError):
        return None
    if len(head) < 8:
        return None
    # MNE FIF starts with magic 0x000... + tag 100.  The first 4
    # bytes are ``0x00 0x00 0x01 0x0a`` (FIFF_FILE_ID tag for v1.0).
    # Accept anything starting with two NULs and a small int (the FIF
    # signature is more permissive in practice).
    if head[:4] == b"\x00\x00\x01\x0a":
        return ".fif"
    # MATLAB .mat (EEGLAB .set is a .mat file) — magic is "MATLAB"
    # at byte 0 (level-5 .mat).
    if head[:6] == b"MATLAB":
        return ".set"
    # EDF / EDF+ / BDF: the first 8 bytes are the EDF version code.
    # Standard EDF: ASCII "0       " (digit 0 padded with spaces).
    # BDF: byte 0 is 0xff, then "BIOSEMI".
    if head[:8] == b"0       ":
        return ".edf"
    if head[:1] == b"\xff" and b"BIOSEMI" in head[:8]:
        return ".bdf"
    return None


def _validate_signal(signal):
    """Sanity-check a freshly-read MNE Raw against scenarios that
    would otherwise cause confusing downstream errors:

    - sample rate must be finite + positive (zero / NaN / absurd
      values silently break resampling and STFT/wavelet bins).
    - at least one channel.
    - duplicate channel names break dict-keyed channel lookups.
    - at least one EEG-typed channel (the whole pipeline is
      EEG-centric; pure EOG / misc datasets crash later in
      pick_types or set_montage with opaque MNE errors).
    """
    if signal is None:
        return None
    sfreq = float(signal.info.get("sfreq") or 0)
    if not (np.isfinite(sfreq) and 0 < sfreq < 1e5):
        raise ValueError(
            f"Input has invalid sample rate sfreq={sfreq!r} — "
            f"expected a finite value in (0, 100000) Hz.")
    if len(signal.ch_names) == 0:
        raise ValueError("Input has zero channels.")
    if len(set(signal.ch_names)) != len(signal.ch_names):
        from collections import Counter
        dups = [n for n, c in Counter(signal.ch_names).items() if c > 1]
        raise ValueError(
            f"Input has duplicate channel names: {dups}.  Rename "
            f"or drop the duplicates before re-running.")
    eeg_picks = mne.pick_types(signal.info, eeg=True)
    if len(eeg_picks) == 0:
        logging.warning(
            "Input has no EEG-typed channels — the pipeline is "
            "EEG-centric and downstream steps (montage, filtering, "
            "ICA, analyses) will likely fail.  Use the GUI's "
            "channel-type override panel or [choosing_channels."
            "type_overrides] in TOML to mark EEG channels.")
    return signal


def read_file(filepath):
    '''
    Reads file with specific formats.

    Parameters
    ----------
    filepath: str
        Path to the file with signal.

    Returns
    -------
    signal_events: list
        Returns the list with signal in MNE format and events. If format of the file wasn't provide or something
        is wrong with files, function returns [None, None].
    '''

    name, ext = os.path.splitext(filepath)

    # Cross-check the extension against the actual file magic bytes.
    # `.fif` that's actually `.set` (or vice versa) used to crash with
    # an obscure MNE error deep inside the format reader; warn here
    # instead so the user can rename and retry.
    if os.path.isfile(filepath):
        sniffed = _detect_format_by_magic(filepath)
        if sniffed is not None and sniffed != ext.lower():
            logging.warning(
                "File %s has extension %s but its magic bytes look "
                "like %s — the format reader will likely fail.  "
                "Either rename the file or convert it to its "
                "declared format.",
                filepath, ext, sniffed)

    # BrainTech
    if ext == ".raw":
        if not os.path.isfile(name + '.raw') or not os.path.isfile(name + '.xml'):
            logging.warning(f"\nFile {name} will not be analysed because the desired formats cannot be found. "
                  f"For BrainTech signal you have to provide files with formats: .raw and .xml "
                  f"(.tag is optional — without it only resting-state analysis is available). "
                  f"Please check whether the files are in the right place and whether they contain any typos "
                  f"(each file should be named the same).\n")
            return [None, None]
        else:
            sig, ev = braintech_format(name)
            return [_validate_signal(sig), ev]

    # Brain Vision
    elif ext == ".vhdr":
        if not os.path.isfile(name + '.vhdr') or not os.path.isfile(name + '.vmrk') or not os.path.isfile(
                name + '.eeg'):
            logging.warning(f"\nFile {name} will not be analysed because the desired formats cannot be found. "
                  f"For Brain Vision signal you have to provide files with this formats: .vhdr, .vmrk and .eeg. "
                  f"Please check whether the files are in the right place and whether they contain any typos "
                  f"(each file should be named the same).\n")
            return [None, None]
        else:
            sig, ev = brainvision_format(name)
            return [_validate_signal(sig), ev]

    # FIF
    elif ext == ".fif":
        sig, ev = fif_format(name)
        return [_validate_signal(sig), ev]

    # EEGLAB
    elif ext == ".set":
        sig, ev = eeglab_format(name)
        return [_validate_signal(sig), ev]

    # EDF
    elif ext == ".edf":
        sig, ev = edf_format(name)
        return [_validate_signal(sig), ev]

    # BDF
    elif ext == ".bdf":
        sig, ev = bdf_format(name)
        return [_validate_signal(sig), ev]

    else:
        logging.warning(f"\nThe format of the file {filepath} is not provided. File will not be analysed.\n")
        return [None, None]

# --- Helper functions ---
def braintech__prepare_tags(rm):
    '''
    Checking tags for Read Manager signal and moves them.

    Parameters
    ----------
    rm: obci_readmanager.signal_processing.read_manager.ReadManager
        Signal in Read Manager type.

    Returns
    -------
    rm: obci_readmanager.signal_processing.read_manager.ReadManager
        Signal in Read Manager type.
    '''
    shift_tags_rel = 0
    tag_correction_chnls = []
    correction_window = (-0.1, 0.3)
    tag_offset = 0.0
    correction_reverse = False
    correction_thr = None

    if shift_tags_rel != 0:
        braintech__shift_tags_relatively_to_signal_beginnig(rm, shift_tags_rel)

    if tag_correction_chnls:
        braintech__align_tags(rm, tag_correction_chnls,
                              start_offset=correction_window[0],
                              duration=correction_window[1],
                              thr=correction_thr,
                              reverse=correction_reverse,
                              offset=tag_offset)

    return rm


def braintech__shift_tags_relatively_to_signal_beginnig(rm, shift):
    '''
    Marian Dovgialo 2019 from https://gitlab.com/BudzikFUW/budzik-analiza-py-3.git helper_functions/helper_functions.py

    Moves all tags in the rm by some relative length. Each tag is moved by different amount dependent on its position - 
    the further from the beginning of the signal, the more it is shifted.

    Parameters
    ----------
    rm: obci_readmanager.signal_processing.read_manager.ReadManager
        Signal in Read Manager type.
    shift: float
        Shift value.
    '''

    tags = rm.get_tags()
    for tag in tags:
        tag['start_timestamp'] *= 1 + shift
        tag['end_timestamp'] *= 1 + shift
    rm.set_tags(tags)


def braintech__align_tags(rm, tag_correction_chnls, start_offset=-0.1, duration=0.3, thr=None, reverse=False, offset=0):
    '''
    Marian Dovgialo 2019 from https://gitlab.com/BudzikFUW/budzik-analiza-py-3.git helper_functions/helper_functions.py

    Aligns tags in read manager to start of sudden change std => 3 in either tag_correction_chnls list searches for that
    in window [start_offset+tag_time; tag_time+duration]. If no such change occures - does nothing to the tag.

    Parameters
    ----------
    rm: obci_readmanager.signal_processing.read_manager.ReadManager
        Signal in Read Manager type.
    tag_correction_chnls: list
        List of the channles to correct tags.
    start_offset: float
        Start of the tag.
    duration: float
        Duration of the tag.
    thr: float or None
        Threshold to check sudden changes. If None, thr = 3*std + mean.
    reverse: bool
        Searches for end of stimulation.
    offset: float
        Offset in seconds to add forcibly.
    '''
    tags = rm.get_tags()
    Fs = float(rm.get_param('sampling_frequency'))
    trigger_chnl = np.zeros(int(rm.get_param('number_of_samples')))
    for tag_correction_chnl in tag_correction_chnls:
        trigger_chnl += np.abs(rm.get_channel_samples(tag_correction_chnl))
    if not thr:
        thr = 3 * np.std(trigger_chnl) + np.mean(trigger_chnl)
        maksimum = trigger_chnl.max()
        if thr > 0.5 * maksimum:
            thr = 0.5 * maksimum

    for tag in tags:
        start = int((tag['start_timestamp'] + start_offset) * Fs)
        end = int((tag['start_timestamp'] + start_offset + duration) * Fs)
        try:
            if reverse:
                trig_pos_s_r = np.argmax(np.flipud(trigger_chnl[start:end] > thr))
                trig_pos_s = (end - start - 1) - trig_pos_s_r
            else:
                trig_pos_s = np.argmax(
                    trigger_chnl[start:end] > thr)  # will find first True, or first False if no Trues
        except ValueError:
            tag['start_timestamp'] += offset
            tag['end_timestamp'] += offset
            continue
        if trigger_chnl[start + trig_pos_s] > thr:
            trig_pos_t = trig_pos_s * 1.0 / Fs
            tag_change = trig_pos_t + start_offset
            tag['start_timestamp'] += tag_change
            tag['end_timestamp'] += tag_change
        tag['start_timestamp'] += offset
        tag['end_timestamp'] += offset
    rm.set_tags(tags)


