"""Module entry point: ``python -m ide4eeg`` delegates to the CLI.

Equivalent to running the installed ``ide4eeg`` console script (also
defined in pyproject.toml as the ``[project.gui-scripts]`` entry).
The two paths share the same dispatcher so behaviour is identical.
"""

from ide4eeg.cli import main

if __name__ == "__main__":
    main()
