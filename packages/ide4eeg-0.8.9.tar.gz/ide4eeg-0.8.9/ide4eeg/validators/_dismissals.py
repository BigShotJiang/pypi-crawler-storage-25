"""Per-rule dismissal persistence — Stage 5 follow-up.

Stores ``{rule_id: dismissed_at_iso}`` in a small JSON file under
``~/.obci/ide4eeg/stage5_dismissed.json``.  When a user clicks "don't
show this again" on a Stage 5 badge, the rule's id lands in this
file; subsequent ``run_at(..., respect_dismissals=True)`` calls skip
it.

Scope of suppression
--------------------
The dismissal is honoured only at ``field_edit`` and ``signal_load``
fire-points (the "inline IDE feel" surfaces).  At ``pre_launch``,
dismissals are ignored on purpose: the user clicking *Run Pipeline*
should always see every issue the rule layer can produce, even ones
they previously asked us to stop showing inline.  Otherwise a user
could silently bypass a hard error by dismissing it once weeks ago.

API surface
-----------
:func:`is_dismissed`, :func:`dismiss`, :func:`undismiss`,
:func:`dismissed_ids`, :func:`clear_all` (for tests).
"""
from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

logger = logging.getLogger(__name__)


_DEFAULT_PATH = Path.home() / ".obci" / "ide4eeg" / "stage5_dismissed.json"

# Allow tests / packaging to redirect the dismissals store.  We keep a
# module-level override that ``set_storage_path`` mutates -- avoids
# threading a path argument through every consumer.
_storage_path: Path = _DEFAULT_PATH

# All public mutators take this lock so concurrent dismiss/undismiss
# calls don't race on the JSON file.  Reads (is_dismissed) are
# lock-free for speed; staleness on rare race is acceptable.
_lock = threading.Lock()

# In-memory cache, populated lazily.  ``None`` means "not yet
# loaded"; an empty set means "loaded, nothing dismissed".
_cache: set[str] | None = None


def set_storage_path(path: Path | str | None) -> None:
    """Override the storage path.  Pass ``None`` to reset to default.

    Tests: call with a ``tmp_path``-based path to keep dismissals
    isolated.  Also clears the in-memory cache so the next read sees
    the new path's contents.
    """
    global _storage_path, _cache
    _storage_path = Path(path) if path else _DEFAULT_PATH
    _cache = None


def _load() -> set[str]:
    """Populate ``_cache`` from disk if not already loaded."""
    global _cache
    if _cache is not None:
        return _cache
    if not _storage_path.is_file():
        _cache = set()
        return _cache
    try:
        with _storage_path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            _cache = set(data.keys())
        else:
            # Tolerate a bare list shape as well.
            _cache = set(data) if isinstance(data, list) else set()
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning(
            "stage5 dismissals: couldn't read %s (%s) -- starting "
            "with empty set", _storage_path, exc)
        _cache = set()
    return _cache


def _save(rule_id_to_ts: dict[str, str]) -> None:
    """Write the full mapping to disk atomically."""
    _storage_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _storage_path.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(rule_id_to_ts, fh, indent=2, sort_keys=True)
    os.replace(tmp, _storage_path)


def _load_with_timestamps() -> dict[str, str]:
    """Like :func:`_load` but returns the timestamp dict, not just
    the id set.  Used by mutators that need to write the full file
    back."""
    if not _storage_path.is_file():
        return {}
    try:
        with _storage_path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
        if isinstance(data, list):
            # Migrate bare-list shape -> dict on next save.
            return {str(k): "" for k in data}
    except (OSError, json.JSONDecodeError):
        pass
    return {}


def is_dismissed(rule_id: str) -> bool:
    """True iff ``rule_id`` is in the dismissal set.

    Lock-free: ``_load`` is cheap after the first call (just a
    cache hit).  A concurrent ``dismiss``/``undismiss`` may see a
    stale answer for ~one call, which is acceptable for the inline
    feedback use case.
    """
    return rule_id in _load()


def dismissed_ids() -> frozenset[str]:
    """Snapshot of the dismissal set, immutable for the caller."""
    return frozenset(_load())


def dismiss(rule_id: str) -> None:
    """Add ``rule_id`` to the dismissal set and persist to disk."""
    global _cache
    with _lock:
        existing = _load_with_timestamps()
        existing[rule_id] = datetime.now(timezone.utc).isoformat(
            timespec="seconds")
        _save(existing)
        _cache = set(existing.keys())


def undismiss(rule_id: str) -> None:
    """Remove ``rule_id`` from the dismissal set.  No-op if absent."""
    global _cache
    with _lock:
        existing = _load_with_timestamps()
        if rule_id not in existing:
            return
        del existing[rule_id]
        _save(existing)
        _cache = set(existing.keys())


def clear_all() -> None:
    """Wipe the dismissal store -- TESTS / settings 'Restore all'."""
    global _cache
    with _lock:
        if _storage_path.is_file():
            try:
                _storage_path.unlink()
            except OSError:
                pass
        _cache = set()


def clear_cache_for_testing() -> None:
    """Drop the in-memory cache so the next read reloads from disk.

    Tests that switch storage paths or write the dismissals file
    out-of-band should call this rather than mutating ``_cache``
    directly -- keeps the internal representation private.
    """
    global _cache
    _cache = None


def filter_issues(
    issues: Iterable, *, dismissed: Iterable[str] | None = None
):
    """Yield ``issues`` minus any whose ``rule_id`` is dismissed.

    Pass ``dismissed`` explicitly to override the disk-backed set
    (used for testing).  Issues with no ``rule_id`` (defensive
    fallback for hand-constructed Issue objects) pass through.
    """
    blocked = (frozenset(dismissed) if dismissed is not None
               else dismissed_ids())
    for issue in issues:
        if getattr(issue, "rule_id", None) in blocked:
            continue
        yield issue


__all__ = [
    "set_storage_path",
    "is_dismissed",
    "dismissed_ids",
    "dismiss",
    "undismiss",
    "clear_all",
    "clear_cache_for_testing",
    "filter_issues",
]
