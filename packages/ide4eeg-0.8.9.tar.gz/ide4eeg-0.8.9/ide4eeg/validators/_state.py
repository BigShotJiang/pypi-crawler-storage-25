"""Build an :class:`ide4eeg.validators.State` snapshot.

The single source of truth for "what state does this rule see at this
fire-point?"  Two construction paths — ``capture_from_gui`` for the
GUI (reads ``_cached_*`` attributes from the main window) and
``capture_from_cfg_and_info`` for the CLI / batch / test contexts.
Both return a fully populated, immutable :class:`State` instance.

Cross-mode parity: both constructors set the same fields from
semantically equivalent sources.  The widget-state vs TOML-state
divergence is intentional — the GUI captures *uncommitted live edit*
state at the fire-point moment; the CLI captures the *as-loaded* TOML
state.  Rules see whichever the current entry-point built.
"""
from __future__ import annotations

import hashlib
import logging
import os
import types
from typing import Any, Mapping

from . import FirePoint, State

logger = logging.getLogger(__name__)


def compose_event_names(events_dict: Mapping | None,
                        unnamed_codes: Mapping | None) -> frozenset[str]:
    """Build the set of event labels offered by the Events picker.

    Named events appear under their key; unnamed integer codes are
    rendered with the same template the GUI's
    :data:`ide4eeg.input.input.UNNAMED_CODE_LABEL` uses, so a rule's
    comparison against ``epochs.tags.selected`` works for both
    sources.  Imports the constant locally to avoid pulling the input
    module at validators-package load time.

    Parameters
    ----------
    events_dict :
        Mapping of named events (``{name: code}``).  ``None``/empty
        means "reader didn't report any named events".
    unnamed_codes :
        Mapping (typically by integer code) of unnamed event codes.

    Returns
    -------
    frozenset[str]
        Labels in the union of named keys and the formatted unnamed
        codes.  Empty when both inputs are empty.
    """
    from ide4eeg.input.input import UNNAMED_CODE_LABEL
    names: set[str] = set((events_dict or {}).keys())
    for k in (unnamed_codes or {}):
        try:
            names.add(UNNAMED_CODE_LABEL.format(int(k)))
        except (TypeError, ValueError):
            continue
    return frozenset(names)


# ---------------------------------------------------------------------
# Snapshot fingerprint — used to drop superseded async-fire-point issues
# ---------------------------------------------------------------------

def _fingerprint(cfg: Mapping[str, Any],
                 ch_names: tuple[str, ...] | None,
                 sfreq: float | None,
                 fire_point: FirePoint) -> str:
    """Stable id for a snapshot, used to drop stale issues.

    Deliberately cheap — not a content hash of the cfg.  Just enough
    to distinguish "this is from before signal-load" from "this is
    from after signal-load".

    .. note::

       The dispatcher (:func:`ide4eeg.validators.run_at`) stamps the
       snapshot's fingerprint onto every emitted :class:`Issue` via
       its ``snapshot_id`` field, so a renderer COULD filter out
       issues from a superseded async signal-load round (e.g. a
       ``field_edit`` issue stamped before ``_on_signal_info_ready``
       finished should be dropped when a fresher ``signal_load``
       issue arrives).  As of 2026-05-16, no consumer actually
       performs this filtering -- the stamp is there waiting for a
       renderer to act on it.  In practice the race hasn't surfaced
       because Qt's event-queue ordering keeps dispatches close to
       in-order on the main thread and ChannelStatusBadge paints
       only the latest ``show_issues()`` content.  Wire the
       consumer-side filter the first time a flicker is observed.
    """
    h = hashlib.blake2b(digest_size=8)
    h.update(fire_point.encode())
    h.update(b"\x00")
    if ch_names is not None:
        h.update(",".join(ch_names).encode())
    h.update(b"\x00")
    if sfreq is not None:
        h.update(f"{sfreq:.6f}".encode())
    h.update(b"\x00")
    # Cfg identity (not content) — two captures of the same cfg dict
    # share the same id, captures from different dicts differ.
    h.update(str(id(cfg)).encode())
    return h.hexdigest()


# ---------------------------------------------------------------------
# Hash-slice extraction — read-only views of cfg["_pipeline_*"]
# ---------------------------------------------------------------------

def _hash_slices(cfg: Mapping[str, Any]) -> dict[str, Any]:
    """Pull the three hash slices into the State's named fields.

    All three are read-only views.  Rules see them via dedicated
    :class:`State` fields, not via raw cfg access — this keeps the
    "rules read but never write hashes" contract observable in code
    review (any rule that does ``state.cfg["_pipeline_..."]`` instead
    of ``state.pipeline_config_hash`` is a code-smell flagged in PR).
    """
    step_hashes = cfg.get("_pipeline_step_hashes")
    if isinstance(step_hashes, dict):
        # Wrap in MappingProxy so rules can't mutate this either.
        step_hashes = types.MappingProxyType(dict(step_hashes))
    elif step_hashes is not None:
        # Unexpected shape — log and drop so rules don't accidentally
        # consume a string / list as if it were a dict.
        logger.warning(
            "_pipeline_step_hashes has unexpected type %s; ignoring.",
            type(step_hashes).__name__)
        step_hashes = None

    return {
        "pipeline_config_hash": cfg.get("_pipeline_config_hash"),
        "pipeline_step_hashes": step_hashes,
        "mp_book_hash": cfg.get("_mp_book_hash"),
    }


# ---------------------------------------------------------------------
# Tool-path probing — cached at capture time, NOT per-rule
# ---------------------------------------------------------------------

def _probe_tool_paths(cfg: Mapping[str, Any]) -> Mapping[str, str | None]:
    """Resolve external tool paths once per snapshot.

    Avoids the warning-fatigue / latency failure mode the critique
    flagged: if a quality rule called ``os.path.isfile(empi)`` on
    every keystroke, NFS-mounted home dirs would make field-edit
    rule evaluation 30-100 ms.  We probe once at capture time and
    rules just read the cached mapping.

    Tools probed: svarog jar, empi binary, mpv, ffmpeg, JRE,
    ConnectiVIS jar, L2CS weights.  Each entry is either a resolved
    absolute path (file exists) or ``None`` (not found).
    """
    paths: dict[str, str | None] = {}

    # Lazy imports so this module stays importable in CLI / test
    # contexts where the GUI's heavy deps are not available.
    try:
        from ide4eeg.gui_config import (
            _find_svarog_jar, _find_empi, _find_connectivis_jar,
        )
    except ImportError:
        # In a stripped environment, just leave all tool-presence
        # checks as None.  Rules that need them will emit info-class
        # "tool not found" issues, which is the correct UX.
        logger.debug("Tool finders unavailable; tool_paths will be empty.")
        return types.MappingProxyType({})

    try:
        svarog = _find_svarog_jar()
        paths["svarog_jar"] = svarog if svarog and os.path.isfile(svarog) else None
    except Exception as exc:  # noqa: BLE001
        logger.debug("svarog probe failed: %s", exc)
        paths["svarog_jar"] = None

    try:
        empi = _find_empi(paths.get("svarog_jar"))
        paths["empi"] = empi if empi and os.path.isfile(empi) else None
    except Exception as exc:  # noqa: BLE001
        logger.debug("empi probe failed: %s", exc)
        paths["empi"] = None

    try:
        connectivis = _find_connectivis_jar()
        paths["connectivis_jar"] = (
            connectivis if connectivis and os.path.isfile(connectivis) else None)
    except Exception as exc:  # noqa: BLE001
        logger.debug("connectivis probe failed: %s", exc)
        paths["connectivis_jar"] = None

    # mpv / ffmpeg / L2CS / JRE — probed on demand by their respective
    # rules in Phase 7 (tool-presence rule family).  Phase 0 lands the
    # three above so the State shape is stable.

    return types.MappingProxyType(paths)


# ---------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------

def capture_from_cfg_and_info(
    cfg: Mapping[str, Any],
    *,
    fire_point: FirePoint,
    ch_names: tuple[str, ...] | None = None,
    ch_types: Mapping[str, str] | None = None,
    sfreq: float | None = None,
    duration: float | None = None,
    has_events: bool | None = None,
    event_codes: frozenset[int] = frozenset(),
    event_names: frozenset[str] = frozenset(),
    has_native_positions: bool | None = None,
    probe_tools: bool = True,
) -> State:
    """Build a :class:`State` from explicit pieces.

    Used by CLI / batch / test code paths.  All signal-derived fields
    are optional; pass what's known.  When the signal isn't loaded,
    leave ``ch_names``/``sfreq``/etc. at their defaults; rules that
    need signal context will then short-circuit.

    Parameters
    ----------
    cfg :
        Live config dict.  Wrapped in :class:`MappingProxyType` before
        being attached to the snapshot, so rules cannot mutate it.
    fire_point :
        Which fire-point this capture is for.  Stored on the snapshot
        for provenance + fingerprinting.
    ch_names, ch_types, sfreq, duration, has_events, event_codes,
    has_native_positions :
        Signal-derived metadata; pass whatever's known.
    probe_tools :
        If True (default), :func:`_probe_tool_paths` is called.  Tests
        that don't care about tool presence pass ``probe_tools=False``
        for speed.
    """
    # Defensive: read-only view of the live cfg.
    cfg_view = types.MappingProxyType(dict(cfg)) if not isinstance(
        cfg, types.MappingProxyType) else cfg

    # ch_types as MappingProxy too — rules see it as immutable.
    if ch_types is not None and not isinstance(ch_types, types.MappingProxyType):
        ch_types = types.MappingProxyType(dict(ch_types))

    hash_slices = _hash_slices(cfg_view)
    tool_paths = _probe_tool_paths(cfg_view) if probe_tools else types.MappingProxyType({})

    return State(
        cfg=cfg_view,
        ch_names=ch_names,
        ch_types=ch_types,
        sfreq=sfreq,
        duration=duration,
        has_events=has_events,
        event_codes=event_codes,
        event_names=event_names,
        has_native_positions=has_native_positions,
        tool_paths=tool_paths,
        captured_at=fire_point,
        snapshot_id=_fingerprint(cfg_view, ch_names, sfreq, fire_point),
        **hash_slices,
    )


def capture_from_gui(gui_self: Any, *, fire_point: FirePoint) -> State:
    """Build a :class:`State` from the GUI's live attributes.

    Reads from the conventional ``_cached_*`` attributes set by
    :meth:`IDE4EEG_Qt._on_signal_info_ready` and the live cfg dict
    snapshot from ``_collect_config``.  When the signal hasn't been
    loaded yet, the ``_cached_*`` attributes are ``None``-equivalent
    and the returned state has ``ch_names is None`` etc.

    Parameters
    ----------
    gui_self :
        The :class:`IDE4EEG_Qt` instance.  Typed loosely because the
        validators package must remain importable in CLI contexts;
        we only access conventional attributes.
    fire_point :
        See :func:`capture_from_cfg_and_info`.
    """
    cfg = gui_self._collect_config() if hasattr(
        gui_self, "_collect_config") else dict(getattr(gui_self, "config_data", {}))

    ch_names = getattr(gui_self, "_cached_ch_names", None)
    if ch_names is not None:
        ch_names = tuple(ch_names)

    ch_types_list = getattr(gui_self, "_cached_ch_types", None)
    if ch_names and ch_types_list:
        ch_types: Mapping[str, str] | None = {
            n: t for n, t in zip(ch_names, ch_types_list)
        }
    else:
        ch_types = None

    events_dict = getattr(gui_self, "_cached_events", None) or {}
    unnamed = getattr(gui_self, "_cached_unnamed_codes", None) or {}
    has_events = bool(events_dict) or bool(unnamed)
    # Compose event codes from named + unnamed (both are ints or
    # parse-able to ints depending on source).
    codes: set[int] = set()
    for v in events_dict.values():
        try:
            codes.add(int(v))
        except (TypeError, ValueError):
            continue
    for k in unnamed:
        try:
            codes.add(int(k))
        except (TypeError, ValueError):
            continue
    # Event NAMES: the set of labels offered in the Events picker.
    # Single source of truth for the format is :func:`compose_event_names`.
    name_set = compose_event_names(events_dict, unnamed)

    return capture_from_cfg_and_info(
        cfg,
        fire_point=fire_point,
        ch_names=ch_names,
        ch_types=ch_types,
        sfreq=getattr(gui_self, "_cached_sfreq", None),
        duration=getattr(gui_self, "_cached_duration", None),
        has_events=has_events,
        event_codes=frozenset(codes),
        event_names=name_set,
        has_native_positions=getattr(gui_self, "_has_native_positions", None),
    )


__all__ = [
    "capture_from_cfg_and_info",
    "capture_from_gui",
    "compose_event_names",
]
