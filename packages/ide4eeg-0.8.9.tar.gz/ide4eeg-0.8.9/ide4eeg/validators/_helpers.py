"""Shared helpers for the consistency-rule modules.

Three pieces of logic re-used across :mod:`...hard.reference`,
:mod:`...hard.channels`, and :mod:`...hard.step_order`:

* :func:`parse_channel_list` -- normalise a cfg value (string,
  list, or junk) to a tuple of channel names, treating
  domain-specific sentinels as "no names requested".
* :func:`missing_channels` -- case-insensitive subset diff.
* :func:`read_step_order` -- defensively read
  ``cfg['preprocessing']['step_order']`` as a list of strings.

These helpers were previously duplicated in two modules (with
slightly different sentinel sets); centralising them prevents
drift and makes the parsing contract testable in one place.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Iterable


def parse_channel_list(value: Any,
                       sentinels: Iterable[str] = ()) -> tuple[str, ...]:
    """Normalise a cfg value to a tuple of channel names.

    Parameters
    ----------
    value :
        The raw cfg value -- usually a comma-separated string
        (``"M1, M2"``), a list / tuple of strings, or absent.
    sentinels :
        Lowercase string values that should be treated as "no
        specific channels requested" and yield ``()``.  Domain-
        specific: re-reference uses ``{"average", "rest", "none",
        ""}``; analysis channel-lists use ``{"all", "none", ""}``.

    Returns
    -------
    tuple of str
        Channel names (whitespace-stripped, empty entries dropped).
        Returns ``()`` for any malformed shape (None, dict, etc.) so
        callers can short-circuit with ``if not required: return``.
    """
    sentinels_set = frozenset(s.lower() for s in sentinels)
    if isinstance(value, (list, tuple)):
        return tuple(str(c).strip() for c in value if str(c).strip())
    if not isinstance(value, str):
        return ()
    if value.strip().lower() in sentinels_set:
        return ()
    return tuple(c.strip() for c in value.split(",") if c.strip())


def missing_channels(required: Iterable[str],
                     available: Iterable[str]) -> tuple[str, ...]:
    """Subset of ``required`` not in ``available``, case-insensitive.

    Preserves the order of ``required`` so error messages list
    channels in the same order the user typed them.
    """
    have = {n.lower() for n in available}
    return tuple(c for c in required if c.lower() not in have)


def read_step_order(cfg: Any) -> list[str]:
    """Read ``cfg['preprocessing']['step_order']`` defensively.

    Returns ``[]`` for the legacy / malformed shapes we've seen
    (``None``, a single string, missing ``preprocessing`` key,
    ``cfg`` itself non-Mapping, etc.) -- rules then short-circuit
    because nothing's enabled.

    Deliberately does NOT call
    :func:`ide4eeg.preprocessing.preprocessing.effective_step_order`,
    which runs the GUI's enabled-step filter + legacy injection and
    pulls in heavy MNE imports at module load time.  For consistency
    rules the raw ``step_order`` is enough: the order is what we
    check, and any disabled steps either don't appear in step_order
    (GUI) or are filtered before the rule runs (CLI).
    """
    if not isinstance(cfg, Mapping):
        return []
    preproc = cfg.get("preprocessing")
    if not isinstance(preproc, Mapping):
        return []
    so = preproc.get("step_order")
    if not isinstance(so, list):
        return []
    return [str(s) for s in so]


# Single source of truth for "is this consumer scheduled to run?"
# Drives the false-positive gate on every rule that emits about a
# cfg field consumed by a specific step or analysis (v0.8.9 audit).
# Keep this mapping in sync with the actual consumers in
# ``ide4eeg/preprocessing/preprocessing.py`` (step_order tokens) and
# ``ide4eeg/analysis/`` (prepare_* flags).
_PREPROC_STEP_CONSUMERS: frozenset[str] = frozenset({
    "ica",
    "mp_decomposition",
    "mp_filter",
    "chosen_channels",
    "filtering",
})
_ANALYSIS_FLAG_CONSUMERS: dict[str, str] = {
    "dipole_fitting": "prepare_dipole_fitting",
    "eeg_profiles":   "prepare_eeg_profiles",
    "connectivity":   "prepare_connectivity_analysis",
}

# Preprocessing steps that have an ADDITIONAL top-level ``prepare_*``
# flag the runtime checks before deciding to actually include them.
# At ``preprocessing.py:1342-1343`` the runner strips ``mp_filter``
# from ``step_order`` when ``prepare_mp_filter`` is falsy -- so even
# if a stale TOML has the token in step_order, the step won't run.
# The gate must mirror that: enabled iff BOTH conditions hold.
# Discovered post-v0.8.9 audit B1 finding.
_STEP_ALSO_GATED_BY_FLAG: dict[str, str] = {
    "mp_filter": "prepare_mp_filter",
}

# Pipeline-step name → GUI checkbox key in
# ``preprocessing.enabled_steps``.  Mirrors the inverse of
# ``_ENABLED_TO_STEPS`` at ``preprocessing.py:1320-1328``: when the
# user unchecks one of these GUI rows, the runtime strips the
# corresponding pipeline step(s) from ``step_order`` (preprocessing.py
# :1330-1336).  So a rule that gates on "step in step_order" alone
# can still false-fire when the user has the step in cfg but its
# GUI checkbox is off.
#
# Note: ``mp_decomposition``, ``eeg_artifacts``, ``gaze_artifacts``,
# and ``mp_filter`` are NOT in ``_ENABLED_TO_STEPS`` (those are
# controlled differently); they're absent from this map intentionally.
# Discovered post-v0.8.9 audit second pass.
_STEP_TO_GUI_ENABLED_KEY: dict[str, str] = {
    "trim":            "trim",
    "resample":        "resample",
    "bad_channels":    "bad_channels",
    "montage":         "signal_setup",
    "reference":       "signal_setup",
    "filtering":       "filtering",
    "ica":             "ica",
    "chosen_channels": "select",
}


def consumer_enabled(cfg: Any, consumer: str) -> bool:
    """True iff ``consumer`` is scheduled to run in this pipeline.

    Maps each known consumer to its enable condition:

    * Preprocessing steps (``ica``, ``mp_decomposition``,
      ``mp_filter``, ``chosen_channels``) → ``consumer`` is in
      ``preprocessing.step_order`` (case-insensitive) AND, for
      steps in :data:`_STEP_ALSO_GATED_BY_FLAG`, their additional
      ``prepare_*`` flag is truthy.
    * Analyses (``dipole_fitting``, ``eeg_profiles``,
      ``connectivity``) → their ``prepare_*`` flag is truthy.
    * Unknown consumer name → ``False`` (safe default).

    The single-source-of-truth helper used by every Stage 5 rule
    whose emit-condition only matters if its consumer will actually
    run.  Without this gate, rules become noisy on cfgs where a
    "stale" field references a step the user has disabled.
    """
    if consumer in _PREPROC_STEP_CONSUMERS:
        order = read_step_order(cfg)
        # Phase-2 multi-instance tokens look like ``"filtering:hp"`` --
        # split on the colon so ``consumer_enabled("filtering")``
        # matches whenever ANY filter instance is in step_order.
        # Non-colon tokens partition with empty id, so the base
        # name is the whole token unchanged.
        order_bases = {s.strip().lower().partition(":")[0]
                       for s in order}
        if consumer not in order_bases:
            return False
        # The GUI's per-step checkbox lives in
        # ``preprocessing.enabled_steps`` and the runtime strips
        # steps whose checkbox is False even if the token is still
        # in step_order (preprocessing.py:1330-1336).  Mirror that.
        gui_key = _STEP_TO_GUI_ENABLED_KEY.get(consumer)
        if gui_key is not None and isinstance(cfg, Mapping):
            preproc = cfg.get("preprocessing")
            if isinstance(preproc, Mapping):
                enabled_steps = preproc.get("enabled_steps")
                if isinstance(enabled_steps, Mapping):
                    # Default True: if the key is absent, the step
                    # is considered enabled (matches the runtime's
                    # ``.get(gui_key, True)``).
                    if not enabled_steps.get(gui_key, True):
                        return False
        # Some steps have an EXTRA prepare_* gate that the runtime
        # consults to decide whether to actually run them.
        extra_flag = _STEP_ALSO_GATED_BY_FLAG.get(consumer)
        if extra_flag is not None:
            if not isinstance(cfg, Mapping):
                return False
            return bool(cfg.get(extra_flag, False))
        return True
    flag = _ANALYSIS_FLAG_CONSUMERS.get(consumer)
    if flag is None:
        return False
    if not isinstance(cfg, Mapping):
        return False
    return bool(cfg.get(flag, False))


__all__ = [
    "consumer_enabled",
    "missing_channels",
    "parse_channel_list",
    "read_step_order",
]
