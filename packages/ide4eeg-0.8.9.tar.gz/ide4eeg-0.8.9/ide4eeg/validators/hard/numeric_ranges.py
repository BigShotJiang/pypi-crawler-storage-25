"""Numeric-range consistency rules.

Locks the silent-garbage paths surfaced by the v0.8.9 hostile audit
(2026-05-17): cfg fields where an out-of-range value is accepted by
the pipeline and produces empty / degraded output without raising.
``project_stage5_future_rule_candidates.md`` in auto-memory has the
full list of original findings.

Each rule emits ``error`` when the value is structurally broken
(can't possibly be what the user meant) or ``warning`` when the
value is suspicious-but-conceivably-intentional.
"""
from __future__ import annotations

from typing import Any, Iterable

from ide4eeg.validators import Issue, State, rule
from ide4eeg.validators._helpers import consumer_enabled


def _iter_filter_blocks(cfg: Any) -> Iterable[tuple[str, dict]]:
    """Yield ``(label, block)`` for every filter block in *cfg*.

    Handles BOTH layouts:

    * Flat (single filter): ``[filters]`` with ``highpass_freq`` /
      ``lowpass_freq`` / ``notch_freq`` directly under it.
    * Phase-2 multi-instance: ``[filters.<id>]`` sub-tables, one per
      ``filtering:<id>`` token in step_order.

    The ``save`` key under ``filters`` (the per-step save-toggle) is
    skipped — it's not a filter block.
    """
    filters = cfg.get("filters") if hasattr(cfg, "get") else None
    if not isinstance(filters, dict):
        return
    flat_keys = {"highpass_freq", "lowpass_freq", "notch_freq", "method"}
    if any(k in filters for k in flat_keys):
        yield "filters", filters
        return
    for fid, block in filters.items():
        if isinstance(block, dict) and fid.lower() != "save":
            yield f"filters.{fid}", block


def _as_float(value: Any) -> float | None:
    """Coerce to float; return None on non-numeric or NaN."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if v != v:  # NaN
        return None
    return v


# ---------------------------------------------------------------------
# 1. filters.{highpass,lowpass}_freq ordering
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["filters.highpass_freq", "filters.lowpass_freq"],
    rule_id="hard.numeric_ranges.filter_hp_lp_ordering",
    rationale="When highpass_freq > lowpass_freq the IIR/FIR design "
              "produces an empty passband -- the filter silently "
              "zeros the signal across that range instead of raising. "
              "Easy to hit by swapping the two values during config "
              "editing.",
)
def filter_hp_lp_ordering(state: State) -> Iterable[Issue]:
    if not consumer_enabled(state.cfg, "filtering"):
        return
    for label, block in _iter_filter_blocks(state.cfg):
        hp = _as_float(block.get("highpass_freq", 0))
        lp = _as_float(block.get("lowpass_freq", 0))
        if hp is None or lp is None:
            continue
        # 0 in either means "disabled" on that side -- no ordering.
        if hp <= 0 or lp <= 0:
            continue
        if hp > lp:
            yield Issue(
                severity="error",
                field_path=f"{label}.highpass_freq",
                message=(
                    f"highpass_freq={hp} > lowpass_freq={lp}: passband "
                    "is empty and the signal would be silently zeroed "
                    "across that range. Swap the two cutoffs."),
            )


# ---------------------------------------------------------------------
# 2. filters.*_freq vs Nyquist
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["filters.highpass_freq", "filters.lowpass_freq",
              "filters.notch_freq"],
    rule_id="hard.numeric_ranges.filter_above_nyquist",
    rationale="Filter cutoff at or above sfreq/2 (Nyquist) leaves "
              "IIR designs unstable and FIR designs with wraparound "
              "artefacts.  Signal-loaded rule -- needs the actual "
              "sampling rate to flag.",
)
def filter_above_nyquist(state: State) -> Iterable[Issue]:
    if state.sfreq is None:
        return
    if not consumer_enabled(state.cfg, "filtering"):
        return
    nyq = state.sfreq / 2
    for label, block in _iter_filter_blocks(state.cfg):
        for key in ("highpass_freq", "lowpass_freq", "notch_freq"):
            v = _as_float(block.get(key, 0))
            if v is None or v <= 0:
                continue
            if v >= nyq:
                yield Issue(
                    severity="error",
                    field_path=f"{label}.{key}",
                    message=(
                        f"{key}={v} Hz >= Nyquist ({nyq} Hz, "
                        f"sfreq={state.sfreq}).  The filter would be "
                        "unstable or wrap around; cap it below "
                        "sfreq/2."),
                )


# ---------------------------------------------------------------------
# 3. dipole_fitting.min_gof in [0, 1]
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["dipole_fitting.min_gof"],
    rule_id="hard.numeric_ranges.dipole_min_gof_range",
    rationale="dipole_fitting.min_gof is a goodness-of-fit threshold "
              "in [0, 1].  Typing 50 to mean '50 %' silently filters "
              "every dipole out; typing -1 or 2 trips the inverse "
              "footgun.",
)
def dipole_min_gof_range(state: State) -> Iterable[Issue]:
    if not consumer_enabled(state.cfg, "dipole_fitting"):
        return
    dip = state.cfg.get("dipole_fitting", {})
    if not isinstance(dip, dict):
        return
    v = _as_float(dip.get("min_gof"))
    if v is None:
        return
    # 0 is the documented "no filter" value -- silent.
    if v == 0:
        return
    if v < 0 or v > 1:
        hint = (" Use a fraction in [0, 1] -- e.g. 0.5 for 50 %."
                if v > 1 else
                " min_gof is a probability and must be non-negative.")
        yield Issue(
            severity="error",
            field_path="dipole_fitting.min_gof",
            message=f"min_gof={v} is outside [0, 1].{hint}",
        )


# ---------------------------------------------------------------------
# 4. epochs.start_offset < epochs.stop_offset
# ---------------------------------------------------------------------

def _is_event_locked(cfg: Any) -> bool:
    """Inline duplicate of ``modes._is_event_locked`` -- imported
    indirectly would create a dependency loop at module-load time.

    Match the post-a05c0ab canonical helper: modern
    ``[segmentation] mode = "epochs"`` shape only (legacy flat
    shape raises in the runtime; rules must agree)."""
    if not hasattr(cfg, "get"):
        return False
    seg = cfg.get("segmentation")
    if not isinstance(seg, dict):
        return False
    return str(seg.get("mode", "")).strip().lower() == "epochs"


@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["epochs.start_offset", "epochs.stop_offset"],
    rule_id="hard.numeric_ranges.epochs_offset_ordering",
    rationale="When start_offset >= stop_offset the epoch window has "
              "zero or negative duration.  The pipeline silently "
              "resets to the default [-0.3, 0.7] with only a log "
              "warning (channels_and_signal.py:617-633).  Surface it "
              "as an error so the user sees their values were "
              "discarded.",
)
def epochs_offset_ordering(state: State) -> Iterable[Issue]:
    if not _is_event_locked(state.cfg):
        return
    epochs = state.cfg.get("epochs")
    if not isinstance(epochs, dict):
        return
    start = _as_float(epochs.get("start_offset"))
    stop = _as_float(epochs.get("stop_offset"))
    if start is None or stop is None:
        return
    if start >= stop:
        yield Issue(
            severity="error",
            field_path="epochs.stop_offset",
            message=(
                f"epochs.start_offset ({start}) must be strictly less "
                f"than epochs.stop_offset ({stop}); otherwise the "
                "epoch window collapses and the pipeline silently "
                "falls back to the default [-0.3, 0.7]."),
        )


# ---------------------------------------------------------------------
# 5. matching_pursuit.{iterations,explained_energy} sanity
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["matching_pursuit.iterations",
              "matching_pursuit.explained_energy"],
    rule_id="hard.numeric_ranges.mp_iterations_or_energy_required",
    rationale="empi needs at least one stopping criterion -- if both "
              "iterations and explained_energy are 0, the decomposition "
              "hangs.  An explained_energy > 1.0 silently caps at 1.0 "
              "(no error, no log).",
)
def mp_iterations_or_energy_required(state: State) -> Iterable[Issue]:
    if not consumer_enabled(state.cfg, "mp_decomposition"):
        return
    mp = state.cfg.get("matching_pursuit")
    if not isinstance(mp, dict):
        return
    # Only fire when BOTH fields are explicitly present in cfg AND
    # both are 0.  Missing fields get DEFAULT_CONFIG values
    # (iterations=30, explained_energy=0.99) at check_and_prepare_config
    # time, so this rule must not flag a sparse TOML where the user
    # accepted the defaults.
    raw_iters = mp.get("iterations")
    raw_energy = mp.get("explained_energy")
    if raw_iters is not None and raw_energy is not None:
        iters = _as_float(raw_iters)
        energy = _as_float(raw_energy)
        if (iters is not None and energy is not None
                and iters <= 0 and energy <= 0):
            yield Issue(
                severity="error",
                field_path="matching_pursuit.iterations",
                message=(
                    "Both matching_pursuit.iterations and "
                    "matching_pursuit.explained_energy are 0; empi "
                    "needs at least one stopping criterion or it "
                    "will run indefinitely.  Set iterations > 0 or "
                    "explained_energy in (0, 1]."),
            )
    energy = _as_float(raw_energy) if raw_energy is not None else None
    if energy is not None and energy > 1.0:
        yield Issue(
            severity="warning",
            field_path="matching_pursuit.explained_energy",
            message=(
                f"matching_pursuit.explained_energy={energy} > 1.0; "
                "empi silently caps at 1.0.  Set a value in (0, 1] "
                "if you want a meaningful stopping criterion."),
        )


# ---------------------------------------------------------------------
# 6. connectivity.mvar_order upper bound
# ---------------------------------------------------------------------

# Upper bound chosen from the connectivity module's per-tag fit:
# orders > 30 push MVAR into rank-loss territory on typical EEG
# epoch lengths (per ``connectivity_analysis.py:144``).  Conservative
# warn-only -- 50 might be legitimate on long recordings.
_MVAR_ORDER_WARN_THRESHOLD = 50


@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["connectivity.mvar_order"],
    rule_id="hard.numeric_ranges.connectivity_mvar_order_range",
    rationale="connectivity.mvar_order=0 triggers AIC auto-selection "
              "(documented).  Negative values are nonsensical; very "
              "large values trip a silent per-tag skip-with-log "
              "instead of erroring out.",
)
def connectivity_mvar_order_range(state: State) -> Iterable[Issue]:
    if not consumer_enabled(state.cfg, "connectivity"):
        return
    conn = state.cfg.get("connectivity")
    if not isinstance(conn, dict):
        return
    v = _as_float(conn.get("mvar_order"))
    if v is None:
        return
    if v < 0:
        yield Issue(
            severity="error",
            field_path="connectivity.mvar_order",
            message=(
                f"connectivity.mvar_order={v} is negative.  Use 0 for "
                "AIC auto-selection or a positive integer for a fixed "
                "order."),
        )
        return
    if v > _MVAR_ORDER_WARN_THRESHOLD:
        yield Issue(
            severity="warning",
            field_path="connectivity.mvar_order",
            message=(
                f"connectivity.mvar_order={int(v)} is unusually large "
                f"(> {_MVAR_ORDER_WARN_THRESHOLD}).  Per-tag fits "
                "with insufficient samples will silently skip with "
                "only a log line.  Set 0 for AIC auto-selection."),
        )


# ---------------------------------------------------------------------
# 7. amplitude_max_threshold SI scale confusion
# ---------------------------------------------------------------------

# The cfg field stores volts (raw SI, default 150e-6 = 150 µV).  Any
# value above this bound is almost certainly a µV-style number the
# user pasted in (e.g. ``150`` meaning ``150 µV``).
# Threshold 0.01 V = 10 mV; no realistic EEG amplitude reaches that.
_AMPLITUDE_THRESHOLD_SUSPICIOUS_V = 0.01


@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["amplitude_max_threshold"],
    rule_id="hard.numeric_ranges.amplitude_threshold_scale",
    rationale="amplitude_max_threshold is in volts (raw SI; default "
              "150e-6 = 150 µV).  Users editing TOML often type 150 "
              "thinking microvolts, which would set the threshold to "
              "150 V and effectively disable amplitude rejection.",
)
def amplitude_threshold_scale(state: State) -> Iterable[Issue]:
    v = _as_float(state.cfg.get("amplitude_max_threshold"))
    if v is None or v <= 0:
        return
    if v >= _AMPLITUDE_THRESHOLD_SUSPICIOUS_V:
        # Hint at what the value would mean if interpreted as µV.
        as_uv = v * 1e-6
        yield Issue(
            severity="warning",
            field_path="amplitude_max_threshold",
            message=(
                f"amplitude_max_threshold={v} V is implausibly large "
                f"for EEG (typical rejection threshold is ~150e-6 V "
                f"= 150 µV).  If you meant 'µV', use {as_uv} (V) "
                "instead -- the cfg field is stored in volts."),
        )


__all__ = [
    "filter_hp_lp_ordering",
    "filter_above_nyquist",
    "dipole_min_gof_range",
    "epochs_offset_ordering",
    "mp_iterations_or_energy_required",
    "connectivity_mvar_order_range",
    "amplitude_threshold_scale",
]
