"""Dipole-fitting consistency rules.

Phase 2 of the Stage 5 migration.  Catches the silent-fail case the
arch-review's channel-name audit flagged as the "worst offender":
``dipole_fitting.ref_channel`` is today a QComboBox hardcoded to
``["average", "Cz", "Fz"]`` regardless of what's in the loaded
signal.  If the signal lacks Cz (e.g. an 18-channel cap with no
central electrodes, or a stale config carrying Cz from a previous
recording), MNE's ``set_eeg_reference`` silently fails downstream
and the dipole fit runs against the raw recording reference.

This module's rule is the validation half of the fix; the GUI half
(populate the dropdown from actual signal channels) lands alongside.
"""
from __future__ import annotations

from typing import Iterable

from ide4eeg.validators import Issue, State, rule


# Re-reference values that are valid regardless of channel set.
# ``"average"`` is the canonical common-average reference; an empty
# string falls back to the existing recording reference (legacy
# behaviour).
_UNIVERSAL_DIPOLE_REFS = frozenset({"average", "", "none"})


@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["dipole_fitting.ref_channel"],
    rule_id="hard.dipole.ref_channel_present",
    rationale="dipole_fitting.ref_channel names a single channel "
              "(or 'average') used as the reference for MNE's "
              "fit_dipole.  If the named channel isn't in the signal, "
              "MNE's set_eeg_reference silently leaves the reference "
              "unchanged and the dipole fit runs against the raw "
              "reference -- a known silent-failure mode.",
)
def dipole_ref_channel_present(state: State) -> Iterable[Issue]:
    """Block when ``dipole_fitting.ref_channel`` names a channel not
    in the signal.

    Silent for ``"average"``, empty string, and ``"none"`` (universal
    references that don't need a channel-existence check).  Silent
    when no signal is loaded yet (defers to the ``signal_load``
    fire).  Silent when ``prepare_dipole_fitting`` is off — the cfg
    value is then inert and complaining about it is noise.
    """
    from ide4eeg.validators._helpers import consumer_enabled
    if not consumer_enabled(state.cfg, "dipole_fitting"):
        return
    dip = state.cfg.get("dipole_fitting", {})
    if not isinstance(dip, dict):
        return
    ref = dip.get("ref_channel", "average")
    if not isinstance(ref, str):
        return
    if ref.strip().lower() in _UNIVERSAL_DIPOLE_REFS:
        return
    if state.ch_names is None:
        return
    have = {n.lower() for n in state.ch_names}
    if ref.lower() not in have:
        yield Issue(
            severity="error",
            field_path="dipole_fitting.ref_channel",
            message=(
                f"Reference channel {ref!r} is not in the loaded "
                "signal.  Pick a channel from the dropdown or use "
                "'average'."
            ),
        )


__all__ = ["dipole_ref_channel_present"]
