"""Re-reference consistency rules.

Migrates two pieces of duplicated validation logic onto the Stage 5
substrate:

1.  The live channel-existence badge on the Reference panel
    (``_update_reref_status`` in ``gui.py:12679``, ~45 lines of inline
    parse + check + render).
2.  The duplicate preflight check at ``gui.py:~15150-15173`` inside
    ``_preflight_check``.

After Phase 1 both call into ``reref_channels_present`` (this module).
The GUI's preset-dropdown disable is a thin wrapper around the same
rule, evaluated against a hypothetical state per preset value.
"""
from __future__ import annotations

import dataclasses
from typing import Any, Iterable

from ide4eeg.validators import Issue, State, rule
from ide4eeg.validators._helpers import (
    missing_channels,
    parse_channel_list,
    read_step_order,
)


# Re-reference values that name specific channels are parsed and
# checked against the loaded signal.  These three values use the
# whole signal (CAR), source-localisation math (REST), or no
# operation (raw) — no per-channel check needed.
_UNIVERSAL_SCHEMES = frozenset({"average", "rest", "none", ""})


def _is_universal(value: Any) -> bool:
    """True iff the re_reference value is a universal scheme that
    doesn't need per-channel validation.

    Subtler than the membership check it wraps because the cfg may
    be a list-of-empties (``[""]``) rather than a clean ``"none"``
    string — both should be treated as "no reference, raw signal."
    """
    if isinstance(value, (list, tuple)):
        return not value or all(not str(c).strip() for c in value)
    return (isinstance(value, str)
            and value.lower().strip() in _UNIVERSAL_SCHEMES)


# ---------------------------------------------------------------------
# The rule
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["re_reference"],
    rule_id="hard.reference.channels_present",
    rationale="Named re-reference channels must exist in the signal; "
              "otherwise the pipeline's _set_reference silently drops "
              "them and the recording is left at its native reference.",
)
def reref_channels_present(state: State) -> Iterable[Issue]:
    """Flag ``cfg["re_reference"]`` channels not in the signal.

    Fires for the Custom-derivation case ("M1, M2") and for the
    named-channel presets (Linked mastoids, Linked ears).  Silent
    for universal schemes (average, REST, raw) and when no signal
    is loaded yet (the GUI's signal-load handler re-fires this rule
    once signal info becomes available).

    Severity contract (matches the legacy GUI ``_preflight_check``
    so Phase 11's dedup is a no-op for the user):

    * ``error`` when the ``reference`` step IS enabled AND every
      requested channel is absent -- the pipeline would silently
      drop all of them and run with the raw reference, which is
      almost certainly not what the user wants.
    * ``warning`` otherwise -- partial-match (some present, some
      absent), or any miss when the step is disabled.  The
      pipeline would still produce output, just with a degraded /
      partial re-reference.
    """
    rr = state.cfg.get("re_reference")
    if _is_universal(rr):
        return
    required = parse_channel_list(rr, _UNIVERSAL_SCHEMES)
    if not required:
        return
    if state.ch_names is None:
        return  # no signal loaded yet; rule re-fires at signal_load
    # Consumer-enabled gate.  Re-referencing actually runs iff EITHER
    # ``"reference"`` is in step_order explicitly, OR the legacy auto-
    # injection condition holds: ``"montage"`` is in step_order AND
    # ``re_reference`` is non-empty (see ``preprocessing.py``'s
    # injection block, which adds a ``reference`` step right after
    # ``montage`` when both are true).  If neither condition holds,
    # the cfg value is inert and any "missing channel" complaint is
    # noise -- matches the v0.8.9 audit class.
    order_lower = {s.strip().lower() for s in read_step_order(state.cfg)}
    step_enabled = (
        "reference" in order_lower
        or ("montage" in order_lower and required))
    if not step_enabled:
        return
    missing = missing_channels(required, state.ch_names)
    if not missing:
        return
    all_missing = len(missing) == len(required)
    severity = "error" if all_missing else "warning"
    if severity == "error":
        msg = (
            f"None of the requested channels ({', '.join(required)}) "
            "are in the signal.  Pipeline would silently run with "
            "the raw reference.  Fix the channel list on the "
            "Reference panel or disable the reference step."
        )
    else:
        msg = (
            f"{', '.join(missing)} not in signal "
            "(re-reference will silently skip these channels)."
        )
    yield Issue(severity=severity, field_path="re_reference", message=msg)


# ---------------------------------------------------------------------
# GUI-facing helper — used by the Reference dropdown to grey out
# presets whose named channels aren't in the loaded signal
# ---------------------------------------------------------------------

def preset_availability(state: State,
                        preset_value: str) -> Issue | None:
    """Evaluate :func:`reref_channels_present` against a hypothetical
    state where ``re_reference`` has been set to ``preset_value``.

    Returns the issue (worst severity) if any would fire, else None.
    The GUI uses this to disable dropdown items whose presets would
    produce missing channels under the currently-loaded signal.

    This is NOT a separate rule — it's a derived check against the
    same rule logic, applied to a counterfactual cfg.  Single source
    of truth for "is this reference value valid here?"
    """
    # Build a temporary cfg with the preset substituted in.  We can't
    # use dataclasses.replace because State.cfg is a MappingProxyType
    # over a dict — building a new dict + wrapping it again is correct
    # and cheap.
    import types as _types
    new_cfg_dict: dict[str, Any] = dict(state.cfg)
    new_cfg_dict["re_reference"] = preset_value
    hypothetical = dataclasses.replace(
        state, cfg=_types.MappingProxyType(new_cfg_dict))
    for issue in reref_channels_present(hypothetical):
        return issue   # first issue wins (there's only one possible)
    return None


__all__ = [
    "preset_availability",
    "reref_channels_present",
]
