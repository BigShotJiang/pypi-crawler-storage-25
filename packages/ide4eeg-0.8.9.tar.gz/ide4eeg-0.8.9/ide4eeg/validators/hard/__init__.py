"""Hard rules — execution-failure prevention.

Severity is ``error`` (blocks pipeline run) or ``warning`` (does not
block, surfaces as a badge).  Never ``info``/``hint`` — those go in
:mod:`ide4eeg.validators.quality`.

Rule modules are imported explicitly below — we do NOT use
:func:`pkgutil.walk_packages`.  Frozen PyInstaller builds don't reliably
support package walking (see ``mne.html_templates`` debugging from
Monika v0.8.5 → v0.8.6).  Adding a new rule module = one line below.
"""
# Phase 0 ships the substrate with no hard rules.  Subsequent phases
# add rule modules here.  Each import has the side-effect of running
# the @rule decorators inside the module, which appends entries to
# the central :data:`ide4eeg.validators._REGISTRY`.
#
from . import reference                    # noqa: F401
from . import dipole                       # noqa: F401
from . import channels                     # noqa: F401
from . import modes                        # noqa: F401
from . import step_order                   # noqa: F401
from . import tools                         # noqa: F401
from . import numeric_ranges               # noqa: F401
