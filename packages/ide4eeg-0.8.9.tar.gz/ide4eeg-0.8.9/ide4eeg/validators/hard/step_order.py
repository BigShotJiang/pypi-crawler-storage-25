"""Step-order constraint rules — Phase 5.

Migrates the ordering and data-dependency invariants from
:mod:`ide4eeg.preprocessing.constraints` onto the Stage 5 substrate
so the same checks fire at signal_load / field_edit / pre_launch
identically in the GUI and CLI paths.

The dict-of-pairs in :mod:`...constraints` stays as the data source
(``DEFAULT_HARD_CONSTRAINTS``, ``DATA_DEPENDENCIES``,
``HARD_CONSTRAINT_RATIONALES``); this module is the adapter that
runs them through the rule machinery.

R10 invariants in
``ide4eeg/preprocessing/preprocessing.py`` lines 468-572
(bound-method scan, pin-coverage, pin-before-truncation) are NOT
migrated — those are correctness asserts on the hash machinery, not
user-input rules.  They stay where they are.
"""
from __future__ import annotations

from typing import Iterable, Mapping

from ide4eeg.preprocessing.constraints import (
    DATA_DEPENDENCIES,
    DEFAULT_HARD_CONSTRAINTS,
    DEFAULT_SOFT_CONSTRAINTS,
    HARD_CONSTRAINT_RATIONALES,
    SOFT_CONSTRAINT_RATIONALES,
)
from ide4eeg.validators import Issue, State, rule
from ide4eeg.validators._helpers import (
    consumer_enabled as _consumer_enabled,
    read_step_order as _step_order,
)


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def _mp_book_available(state: State) -> bool:
    """True when an MP book is reachable for downstream consumers.

    Two signals: ``mp_decomposition`` enabled in this run, OR a book
    pinned in ``_mp_book_path`` (set by the GUI when the user picks
    an existing book on the Analysis tab).  Either way the consumer
    step has something to read.

    Virtual-contract note: ``_mp_book_path`` is a GUI-internal field
    (underscore prefix marks it as runtime-only, not user-edited
    TOML).  If the GUI ever renames this key, this rule -- and the
    Analysis-tab book picker -- both need to be updated in lockstep.
    See ``project_mp_book_reuse.md`` in auto-memory for the contract.
    """
    order_lower = {s.strip().lower() for s in _step_order(state.cfg)}
    if "mp_decomposition" in order_lower:
        return True
    book = state.cfg.get("_mp_book_path")
    return bool(book)


def _mp_algorithm(cfg: Mapping) -> str:
    """The MP algorithm chosen in ``[matching_pursuit] algorithm``.

    Defaults to ``"smp"`` (single-channel) per
    :data:`ide4eeg.gui_config.DEFAULT_CONFIG`.  Lowercased so the
    comparison against ``DATA_DEPENDENCIES`` values is robust.
    """
    mp = cfg.get("matching_pursuit", {})
    if not isinstance(mp, dict):
        return "smp"
    algo = mp.get("algorithm", "smp")
    return str(algo).strip().lower()


# ``_consumer_enabled`` lives in ``validators/_helpers`` as a single
# source of truth — imported above as the canonical name.  This
# module used to define a local MP-centric version; consolidated in
# the v0.8.9 false-positive audit so channels / dipole / reference
# / step_order all gate identically.


# ---------------------------------------------------------------------
# Rule: hard ordering constraints
#
# Wraps every pair in ``DEFAULT_HARD_CONSTRAINTS`` into a single rule
# that emits one Issue per violated pair.  Data-driven so adding a
# new pair to ``constraints.py`` automatically gets validated here.
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["preprocessing.step_order"],
    rule_id="hard.step_order.ordering_constraints",
    rationale="Some pairs of preprocessing steps have a fixed "
              "execution order because one consumes the other's "
              "output (e.g. mp_filter consumes mp_decomposition's "
              "atom book).  Reordering them silently breaks the "
              "consumer.",
)
def ordering_constraints(state: State) -> Iterable[Issue]:
    # Two defences in one place:
    #   - Case-fold step_order so a hand-edited TOML with mis-cased
    #     tokens (e.g. ``"MP_Decomposition"``) still gates correctly.
    #   - Delegate to validate_step_order so Phase 2 multi-instance
    #     tokens (e.g. ``"filtering:hp"``, ``"filtering:lp"``) parse
    #     via ``_split_step_id``: otherwise ``"filtering" in
    #     ["filtering:hp", "ica", "filtering:lp"]`` is False and a
    #     user with filtering on both sides of ICA silently bypasses
    #     the constraint check.
    # Lazy import: preprocessing.py pulls in ``import mne`` at module
    # load time, which is too heavy for the rule registration path.
    raw_order = [s.strip().lower() for s in _step_order(state.cfg)]
    if not raw_order:
        return
    from ide4eeg.preprocessing.preprocessing import validate_step_order
    _, errors, _ = validate_step_order(raw_order)
    for v in errors:
        rationale = HARD_CONSTRAINT_RATIONALES.get(
            (v.before, v.after), "")
        yield Issue(
            severity="error",
            field_path="preprocessing.step_order",
            message=(
                f"{v.before!r} must come before {v.after!r} in the "
                f"preprocessing step order. "
                + (f"({rationale})" if rationale else "")
            ),
        )


# ---------------------------------------------------------------------
# Rule: soft (recommended) ordering constraints
#
# Wraps DEFAULT_SOFT_CONSTRAINTS (filtering→ica, bad_channels→ica)
# into a warning-severity rule.  Mirrors the runtime check in
# preprocessing.validate_step_order so the same recommendations are
# surfaced both at reorder time (existing inline UI) and at the
# Stage 5 surfaces (badge + preflight modal + Help panel).  The
# inline reorder-time check is intentionally NOT removed: it gives
# immediate drag-and-drop feedback that the rule layer's debounced
# field_edit dispatch can't match for that interaction shape.
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["preprocessing.step_order"],
    rule_id="hard.step_order.soft_ordering_constraints",
    rationale="Recommended-only step orderings (e.g. filter before "
              "ICA, bad-channel detection before ICA).  Reordering "
              "them won't crash the pipeline, but the literature and "
              "internal benchmarks show degraded downstream results.",
)
def soft_ordering_constraints(state: State) -> Iterable[Issue]:
    # Same case-fold + multi-instance defences as
    # ``ordering_constraints``.  Without delegation, soft
    # ``filtering→ica`` silently passes for users who legitimately
    # need filtering on both sides of ICA.
    raw_order = [s.strip().lower() for s in _step_order(state.cfg)]
    if not raw_order:
        return
    from ide4eeg.preprocessing.preprocessing import validate_step_order
    _, _, warnings = validate_step_order(raw_order)
    for v in warnings:
        rationale = SOFT_CONSTRAINT_RATIONALES.get(
            (v.before, v.after), "")
        yield Issue(
            severity="warning",
            field_path="preprocessing.step_order",
            message=(
                f"{v.before!r} usually comes before {v.after!r} in "
                f"the preprocessing step order. "
                + (f"({rationale})" if rationale else "")
            ),
        )


# ---------------------------------------------------------------------
# Rule: dipole_fitting requires MMP1 algorithm
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["prepare_dipole_fitting",
              "matching_pursuit.algorithm",
              "preprocessing.step_order"],
    rule_id="hard.step_order.dipole_requires_mmp1",
    rationale="Dipole fitting reads multivariate atoms (MMP1).  "
              "Single-channel MP (SMP) atoms have no shared "
              "topography across channels and cannot be source-"
              "localised.",
)
def dipole_requires_mmp1(state: State) -> Iterable[Issue]:
    if not _consumer_enabled(state.cfg, "dipole_fitting"):
        return
    # If MP is going to run in this pipeline, its algorithm must be
    # mmp1.  If MP is NOT going to run, the book-existence rule
    # below catches the missing-book case; here we only catch the
    # wrong-algorithm case.  Case-fold the membership check.
    order_lower = {s.strip().lower() for s in _step_order(state.cfg)}
    if "mp_decomposition" not in order_lower:
        return  # delegated to dipole_requires_mp_available
    required = DATA_DEPENDENCIES["dipole_fitting"]["mp_decomposition"]
    if _mp_algorithm(state.cfg) != required:
        yield Issue(
            severity="error",
            field_path="matching_pursuit.algorithm",
            message=(
                f"Dipole fitting requires algorithm = {required!r} "
                f"(currently {_mp_algorithm(state.cfg)!r}).  "
                "Switch the MP algorithm or disable dipole fitting."
            ),
        )


# ---------------------------------------------------------------------
# Rules: MP consumers need an MP book available
#
# One rule per consumer so the failure message points at the right
# field path and the dismissal granularity is correct.
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["prepare_dipole_fitting",
              "preprocessing.step_order",
              "_mp_book_path"],
    rule_id="hard.step_order.dipole_requires_mp_available",
    rationale="Dipole fitting consumes atoms from an MP book.  "
              "Either MP decomposition must run in this pipeline "
              "or an existing book must be selected on the "
              "Analysis tab.",
)
def dipole_requires_mp_available(state: State) -> Iterable[Issue]:
    if not _consumer_enabled(state.cfg, "dipole_fitting"):
        return
    if not _mp_book_available(state):
        yield Issue(
            severity="error",
            field_path="prepare_dipole_fitting",
            message=(
                "Dipole fitting needs an MP book.  Either enable "
                "'MP decomposition' in the Preprocessing tab, or "
                "pick an existing book on the Analysis tab."
            ),
        )


@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["preprocessing.step_order", "_mp_book_path"],
    rule_id="hard.step_order.mp_filter_requires_mp_available",
    rationale="mp_filter reconstructs a signal from atoms; it cannot "
              "run without a book to read.",
)
def mp_filter_requires_mp_available(state: State) -> Iterable[Issue]:
    if not _consumer_enabled(state.cfg, "mp_filter"):
        return
    if not _mp_book_available(state):
        yield Issue(
            severity="error",
            field_path="preprocessing.step_order",
            message=(
                "mp_filter needs an MP book.  Either enable "
                "'MP decomposition' in the Preprocessing tab, or "
                "pick an existing book on the Analysis tab."
            ),
        )


@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["prepare_eeg_profiles",
              "preprocessing.step_order",
              "_mp_book_path"],
    rule_id="hard.step_order.eeg_profiles_requires_mp_available",
    rationale="EEG profiles classifies atoms from an MP book.  "
              "Either MP decomposition must run in this pipeline "
              "or an existing book must be selected on the "
              "Analysis tab.",
)
def eeg_profiles_requires_mp_available(state: State) -> Iterable[Issue]:
    if not _consumer_enabled(state.cfg, "eeg_profiles"):
        return
    if not _mp_book_available(state):
        yield Issue(
            severity="error",
            field_path="prepare_eeg_profiles",
            message=(
                "EEG profiles needs an MP book.  Either enable "
                "'MP decomposition' in the Preprocessing tab, or "
                "pick an existing book on the Analysis tab."
            ),
        )


# ---------------------------------------------------------------------
# Rule: mp_filter step_entry sanity check
#
# pre_launch already guarantees an MP book is *promised* (either
# mp_decomposition is in step_order, or _mp_book_path is pinned to an
# existing file).  But the runner may have re-evaluated reuse since
# launch -- if mp_decomposition crashed, or the user deleted the
# pinned book file between Run-click and the step running, the
# pre_launch invariant no longer holds.  step_entry is the last line
# of defence: emit a clean error here instead of letting empi's
# reader fail mid-step with a cryptic "no such file" / "atom count
# zero".
# ---------------------------------------------------------------------

@rule(
    fires_at=["step_entry"],
    rule_id="hard.step_order.mp_filter_book_present_at_entry",
    rationale="mp_filter consumes an MP book; by the time the step "
              "runs, _mp_book_path must point at a readable file.  "
              "pre_launch checks this against intent, but the book "
              "can disappear (failed decomposition, manual delete) "
              "between Run-click and step entry -- catch it here.",
)
def mp_filter_book_present_at_entry(state: State) -> Iterable[Issue]:
    if state.current_step != "mp_filter":
        return
    import os
    book = state.cfg.get("_mp_book_path")
    if not book or not os.path.isfile(str(book)):
        yield Issue(
            severity="error",
            field_path="_mp_book_path",
            message=(
                "mp_filter is about to run but no MP book is "
                "available at "
                f"{book!r}.  This usually means mp_decomposition "
                "did not produce a book in this run, or the "
                "pinned book was deleted.  Re-run with MP "
                "decomposition enabled, or pick a fresh book on "
                "the Analysis tab."
            ),
        )


# ---------------------------------------------------------------------
# Rule: pinned MP book file still exists on disk
#
# Complements the step_entry rule above for the live GUI / pre-launch
# case.  When the user pinned a book on the Analysis tab in a prior
# session and the file has since been deleted or moved, surface the
# stale pin BEFORE the user clicks Run -- no need to wait for empi's
# reader to fail mid-step.  Only fires when a consumer needs the book
# (mp_filter / dipole_fitting / eeg_profiles), so an empty pipeline
# stays silent.
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "signal_load", "pre_launch"],
    triggers=["_mp_book_path",
              "prepare_dipole_fitting",
              "prepare_eeg_profiles",
              "preprocessing.step_order"],
    rule_id="hard.step_order.pinned_mp_book_exists_on_disk",
    rationale="When _mp_book_path is pinned to an existing book "
              "(typed in a prior session, picked on the Analysis "
              "tab) the file must still be on disk -- otherwise the "
              "next pipeline run fails mid-step.  Triggered by the "
              "pin itself and by every MP consumer's enable flag.",
)
def pinned_mp_book_exists_on_disk(state: State) -> Iterable[Issue]:
    book = state.cfg.get("_mp_book_path")
    if not book:
        return  # no pin -> no opinion (decomposition may create one)
    import os
    if os.path.isfile(str(book)):
        return  # pinned file present, good
    # File missing.  Only surface when a consumer is wired up;
    # otherwise the stale pin is harmless.
    consumers = ("mp_filter", "dipole_fitting", "eeg_profiles")
    if not any(_consumer_enabled(state.cfg, c) for c in consumers):
        return
    yield Issue(
        severity="error",
        field_path="_mp_book_path",
        message=(
            f"The pinned MP book at {book!r} doesn't exist on "
            "disk.  Pick a fresh book on the Analysis tab, or "
            "enable 'MP decomposition' in the Preprocessing tab "
            "to create one."
        ),
    )


__all__ = [
    "dipole_requires_mmp1",
    "dipole_requires_mp_available",
    "eeg_profiles_requires_mp_available",
    "mp_filter_book_present_at_entry",
    "mp_filter_requires_mp_available",
    "ordering_constraints",
    "pinned_mp_book_exists_on_disk",
    "soft_ordering_constraints",
]
