"""Segmentation-mode coherence rules — Phase 4.

Four rules covering the "event-locked mode chosen on a recording it
can't actually run on" failure cluster.  Originally migrated from
inline checks in ``gui.py::_preflight_check`` and the
``_check_events_in_trim`` helper; Phase 11b stripped the inline
duplicates and these rules are now the single source of truth.

Three of the four are ERROR severity (block the run); one is
WARNING (allows the run but advises the user).  All fire at
signal_load / pre_launch; the event-name and tag-selection rules
also fire at field_edit for the relevant fields.
"""
from __future__ import annotations

from typing import Iterable, Mapping

from ide4eeg.validators import Issue, State, rule


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def _is_event_locked(cfg: Mapping) -> bool:
    """True iff cfg's segmentation mode is event-locked.

    Mirrors :func:`ide4eeg.preprocessing.channels_and_signal.
    get_segmentation_mode` — reads
    ``cfg['segmentation']['mode']`` and compares to ``"epochs"``.
    Legacy flat-string shape (``segmentation = "epochs"``) is not
    supported by the canonical helper, so the rule layer doesn't
    support it either — otherwise the rule would disagree with the
    pipeline on legacy configs.
    """
    seg = cfg.get("segmentation")
    mode = seg.get("mode", "rest") if isinstance(seg, Mapping) else "rest"
    return str(mode).lower() == "epochs"


def _selected_event_names(cfg: Mapping) -> list[str]:
    """User's selected event tags (from epochs.tags.selected).

    Defaults to ``[]`` so the no-events case returns an empty list,
    not ``None``.
    """
    tags = cfg.get("epochs", {}).get("tags", {})
    if not isinstance(tags, dict):
        return []
    selected = tags.get("selected", [])
    return list(selected) if isinstance(selected, list) else []


# ---------------------------------------------------------------------
# Rule 1 — event-locked mode requires a STIM channel
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["segmentation.mode", "segmentation"],
    rule_id="hard.modes.event_locked_mode_no_stim_channel",
    rationale="Event-locked mode reads markers from the STIM channel "
              "(or its annotation surrogate).  Without one, "
              "find_events finds nothing and the pipeline cuts zero "
              "epochs -- caught early so the user can switch modes.",
)
def event_locked_mode_no_stim_channel(state: State) -> Iterable[Issue]:
    if not _is_event_locked(state.cfg):
        return
    if state.ch_names is None or state.ch_types is None:
        # No signal yet — rule will re-fire at signal_load.
        return
    # Filter by channel TYPE only — CLAUDE.md invariant.  The layered
    # type-inference pipeline (file reader → IDE4EEG overlay →
    # readmanager heuristic → user overrides) is authoritative; matching
    # by name "STIM" would false-positive a user-renamed non-stim
    # channel and false-negative a stim channel renamed away from
    # "STIM".
    has_stim = any(t == "stim" for t in state.ch_types.values())
    if not has_stim:
        yield Issue(
            severity="error",
            field_path="segmentation.mode",
            message=(
                "Event-locked mode selected, but the signal has no "
                "STIM channel.  Switch to 'timed windows' in "
                "Segmentation setup, or pick a recording with markers."
            ),
        )


# ---------------------------------------------------------------------
# Rule 2 — event-locked mode requires at least one selected event
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["segmentation.mode", "epochs.tags.selected"],
    rule_id="hard.modes.event_locked_mode_no_events_selected",
    rationale="Event-locked mode needs at least one event picked in "
              "the Events panel.  An empty selection produces zero "
              "epochs at cut_segments time.",
)
def event_locked_mode_no_events_selected(state: State) -> Iterable[Issue]:
    if not _is_event_locked(state.cfg):
        return
    if not _selected_event_names(state.cfg):
        yield Issue(
            severity="error",
            field_path="epochs.tags.selected",
            message=(
                "No events selected.  Event-locked mode requires at "
                "least one event -- check events in the Events panel "
                "(Segmentation setup)."
            ),
        )


# ---------------------------------------------------------------------
# Rule 3 — selected event names must exist in the file
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["epochs.tags.selected"],
    rule_id="hard.modes.event_locked_mode_events_not_in_trim",
    rationale="Selected event names must appear among the events "
              "the reader discovered.  A stale config can carry tag "
              "names from a different recording; the pipeline would "
              "later raise 'zero epochs' with no actionable context.",
)
def event_locked_mode_events_not_in_trim(state: State) -> Iterable[Issue]:
    if not _is_event_locked(state.cfg):
        return
    selected = _selected_event_names(state.cfg)
    if not selected:
        return  # rule 2 catches the empty-selection case
    if not state.event_names:
        # Reader didn't report any event labels — pipeline will
        # surface its own diagnostic.
        return
    missing = [n for n in selected if n not in state.event_names]
    if not missing:
        return
    avail = sorted(state.event_names)
    preview = ", ".join(avail[:10])
    if len(avail) > 10:
        preview += f", ... ({len(avail)} total)"
    yield Issue(
        severity="error",
        field_path="epochs.tags.selected",
        message=(
            f"Selected events not present in file: {', '.join(missing)}. "
            f"Available: {preview}.  "
            "Update the event selection or switch recordings."
        ),
    )


# ---------------------------------------------------------------------
# Rule 4 — EEG profiles + event-locked mode = soft warning
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["segmentation.mode", "prepare_eeg_profiles"],
    rule_id="hard.modes.eeg_profiles_with_event_locked_mode",
    rationale="EEG profiles assumes a continuous time axis.  With "
              "event-locked epochs the profile chart's x-axis covers "
              "only the contiguous epoch duration; detections in "
              "gaps between events fall off the canvas.",
)
def eeg_profiles_with_event_locked_mode(state: State) -> Iterable[Issue]:
    if not _is_event_locked(state.cfg):
        return
    if not state.cfg.get("prepare_eeg_profiles", False):
        return
    yield Issue(
        severity="warning",
        field_path="prepare_eeg_profiles",
        message=(
            "EEG profiles + event-locked mode: profiles is designed "
            "for continuous timed-windows analysis.  With event-"
            "locked epochs the profile chart's x-axis covers only "
            "n_epochs × epoch_length seconds; detections in gaps "
            "between events won't be visible.  Switch to timed "
            "windows in Segmentation setup for profiles."
        ),
    )


__all__ = [
    "eeg_profiles_with_event_locked_mode",
    "event_locked_mode_events_not_in_trim",
    "event_locked_mode_no_events_selected",
    "event_locked_mode_no_stim_channel",
]
