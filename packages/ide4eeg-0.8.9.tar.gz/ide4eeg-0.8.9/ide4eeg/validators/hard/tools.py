"""Tool-availability rules — Stage 5 Phase 7.

Fires when a pipeline configuration enables a step that requires an
external binary, but the binary isn't on the system.  The user would
otherwise hit a confusing 'No such file' / 'command not found' error
mid-run; the rule turns that into an actionable preflight message
that points at the Config-tab download button.

What's NOT here, and why
------------------------
- **Svarog JAR** — every Svarog-mediated path (eye buttons,
  ``check_segments`` manual review, ``--split-signal`` preview)
  silently falls back to a paired MNE window when the JAR is
  missing.  Firing a rule would amount to "missing optional
  feature, run continues"; the existing tool-paths-Config-tab UX
  is the right surface for that.
- **mpv binary** — same story.  The InsightFace/L2CS gaze preview
  windows fall back to OpenCV when mpv isn't installed.

Both are tracked in
:mod:`ide4eeg.download_tools` for the download path and in
:mod:`ide4eeg.gui_config` for the discovery helpers.

What IS here
------------
- ``mp_decomposition_requires_empi`` — error if mp_decomposition is
  scheduled to run, no book is pinned, and the empi binary isn't
  on disk.  Without empi the step fails immediately.
- ``connectivity_requires_connectivis`` — warning if connectivity
  analysis is enabled and the ConnectiVIS JAR isn't on disk.
  Warning rather than error because the connectivity *computation*
  runs without ConnectiVIS; only the 3D source visualisation
  is unavailable.
"""
from __future__ import annotations

import os
from typing import Iterable, Mapping

from ide4eeg.validators import Issue, State, rule
from ide4eeg.validators._helpers import read_step_order


def _empi_available() -> bool:
    """True iff the empi binary is found on the current system.

    Wraps :func:`ide4eeg.gui_config._find_empi` (which already does
    env-var + standard-location + Svarog-bundled discovery).  The
    extra ``os.path.isfile`` guard catches a stale env var pointing
    at a removed file.
    """
    try:
        from ide4eeg.gui_config import _find_empi, _find_svarog_jar
        path = _find_empi(_find_svarog_jar())
        return bool(path) and os.path.isfile(path)
    except Exception:
        # If discovery itself raises, treat as "not available" --
        # the user will get the rule message, the same as if the
        # binary were missing.
        return False


def _connectivis_available() -> bool:
    """True iff the ConnectiVIS JAR is found on the current system."""
    try:
        from ide4eeg.gui_config import _find_connectivis_jar
        path = _find_connectivis_jar()
        return bool(path) and os.path.isfile(path)
    except Exception:
        return False


def _has_pinned_book(cfg: Mapping) -> bool:
    """True when ``_mp_book_path`` points at an extant file.

    When the user has selected a pre-built book on the Analysis tab,
    mp_decomposition is skipped at runtime (see
    ``project_mp_book_reuse.md``), so empi isn't required.
    """
    book = cfg.get("_mp_book_path")
    return bool(book) and isinstance(book, str) and os.path.isfile(book)


# ---------------------------------------------------------------------
# Rule 1 — MP decomposition needs the empi binary
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["preprocessing.step_order", "_mp_book_path"],
    rule_id="hard.tools.mp_decomposition_requires_empi",
    rationale="MP decomposition uses the empi binary to build the "
              "atom book.  Without it on this machine the step "
              "fails immediately with 'empi: command not found' or "
              "a Java ClassNotFoundException.  Reusing an existing "
              "book (when _mp_book_path is pinned) bypasses empi.",
)
def mp_decomposition_requires_empi(state: State) -> Iterable[Issue]:
    if "mp_decomposition" not in read_step_order(state.cfg):
        return
    if _has_pinned_book(state.cfg):
        return
    if _empi_available():
        return
    yield Issue(
        severity="error",
        field_path="preprocessing.step_order",
        message=(
            "MP decomposition is enabled but the empi binary "
            "isn't installed on this machine.  Use the Config tab's "
            "'Download Svarog + empi' button, or pin an existing "
            "_mp_book_path on the Analysis tab."
        ),
    )


# ---------------------------------------------------------------------
# Rule 2 — Connectivity analysis benefits from ConnectiVIS for 3D viz
# ---------------------------------------------------------------------

@rule(
    fires_at=["field_edit", "pre_launch"],
    triggers=["prepare_connectivity_analysis"],
    rule_id="hard.tools.connectivity_requires_connectivis",
    rationale="Connectivity analysis runs without ConnectiVIS, but "
              "the 3D source-space viewer (cvis-gui) won't be "
              "reachable from the Output tab.  The numeric CSV "
              "outputs are unaffected, hence warning not error.",
)
def connectivity_requires_connectivis(state: State) -> Iterable[Issue]:
    if not state.cfg.get("prepare_connectivity_analysis", False):
        return
    if _connectivis_available():
        return
    yield Issue(
        severity="warning",
        field_path="prepare_connectivity_analysis",
        message=(
            "Connectivity analysis is enabled but the ConnectiVIS "
            "JAR isn't installed.  Numeric outputs (CSV/JSON) will "
            "be produced, but the 3D viewer won't open.  Use the "
            "Config tab's 'Download ConnectiVIS' button to get it."
        ),
    )


__all__ = [
    "mp_decomposition_requires_empi",
    "connectivity_requires_connectivis",
]
