"""Channel-name consistency rules — Phase 3.

Six rules covering the remaining channel-name surfaces flagged by
the May 2026 audit:

  * ``ICA_EOG.find_bads_eog_ch``      — EOG channels for ICA find_bads
  * ``dipole_fitting.ignored_channels`` — exclude from dipole fit
  * ``eeg_profiles.channel``          — single channel for FASP profiles
  * ``matching_pursuit.channels``     — channels for MP decomposition
  * ``connectivity.channels``         — channels for connectivity analysis
  * ``choosing_channels.{selected,dropped}_channels`` — manual subset

Each rule fires at signal_load / field_edit / pre_launch and emits
a ``warning`` issue when named channels aren't present in the loaded
signal.  The pipeline consumers all follow the "log-and-filter"
pattern (drop missing channels silently, log once), so these rules
exist to make that silent drop visible in the GUI BEFORE the run.

Universal sentinels (``"all"``, empty value) are treated as "no
specific channel naming" and never fire.
"""
from __future__ import annotations

from typing import Any, Iterable

from ide4eeg.validators import Issue, State, rule
from ide4eeg.validators._helpers import (
    consumer_enabled as _consumer_enabled,
    missing_channels as _missing,
    parse_channel_list,
)


# Sentinels that mean "no specific channel filter" — never validated.
_ALL_SENTINELS = frozenset({"all", "", "none"})


def _as_channel_list(value: Any) -> tuple[str, ...]:
    """Normalise a cfg value to a tuple of channel names, treating
    ``"all"`` / ``""`` / ``"none"`` as "no specific channels"."""
    return parse_channel_list(value, _ALL_SENTINELS)


def _make_channel_issue(field_path: str,
                        missing: Iterable[str],
                        message_tmpl: str) -> Issue:
    """Build a uniform warning Issue for a missing-channel finding."""
    missing_str = ", ".join(missing)
    return Issue(
        severity="warning",
        field_path=field_path,
        message=message_tmpl.format(missing=missing_str),
    )


# ---------------------------------------------------------------------
# 1. ICA_EOG.find_bads_eog_ch  (list)
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["ICA_EOG.find_bads_eog_ch"],
    rule_id="hard.channels.ica_eog_channels_present",
    rationale="ICA's find_bads_eog selector references EOG channels "
              "by name; missing names are dropped with a log warning, "
              "and ICA falls back to whichever channels remain.",
)
def ica_eog_channels_present(state: State) -> Iterable[Issue]:
    if state.ch_names is None:
        return
    if not _consumer_enabled(state.cfg, "ica"):
        return  # ICA disabled -> ICA_EOG cfg is inert
    ica_cfg = state.cfg.get("ICA_EOG", {})
    if not isinstance(ica_cfg, dict):
        return
    required = _as_channel_list(ica_cfg.get("find_bads_eog_ch"))
    if not required:
        return
    missing = _missing(required, state.ch_names)
    if missing:
        yield _make_channel_issue(
            "ICA_EOG.find_bads_eog_ch", missing,
            "EOG channels {missing} not in signal (ICA will skip them).")


# ---------------------------------------------------------------------
# 2. dipole_fitting.ignored_channels  (string or list)
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["dipole_fitting.ignored_channels"],
    rule_id="hard.channels.dipole_ignored_channels_present",
    rationale="dipole_fitting.ignored_channels lists channels to "
              "exclude from the fit.  Misnaming an ignored channel "
              "means it's NOT excluded -- silently weakening the fit.",
)
def dipole_ignored_channels_present(state: State) -> Iterable[Issue]:
    if state.ch_names is None:
        return
    if not _consumer_enabled(state.cfg, "dipole_fitting"):
        return
    dip = state.cfg.get("dipole_fitting", {})
    if not isinstance(dip, dict):
        return
    required = _as_channel_list(dip.get("ignored_channels"))
    if not required:
        return
    missing = _missing(required, state.ch_names)
    if missing:
        yield _make_channel_issue(
            "dipole_fitting.ignored_channels", missing,
            "Channels to ignore {missing} are not in the signal "
            "(they will not be excluded from the fit).")


# ---------------------------------------------------------------------
# 3. eeg_profiles.channel  (single value; can be int index or str name)
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["eeg_profiles.channel"],
    rule_id="hard.channels.eeg_profiles_channel_present",
    rationale="eeg_profiles.channel picks one channel from the MP "
              "book.  String values must match a signal channel; "
              "int values are book indices and validated elsewhere "
              "(eeg_profiles step uses them as raw indices).",
)
def eeg_profiles_channel_present(state: State) -> Iterable[Issue]:
    if state.ch_names is None:
        return
    if not _consumer_enabled(state.cfg, "eeg_profiles"):
        return
    prof = state.cfg.get("eeg_profiles", {})
    if not isinstance(prof, dict):
        return
    ch = prof.get("channel")
    # Int indices are book-side, not signal-side.  Empty / 'all' /
    # 'mmp1' (the "use all atoms" sentinel) — silent.
    if not isinstance(ch, str):
        return
    name = ch.strip()
    if not name or name.lower() in _ALL_SENTINELS or name.lower() == "mmp1":
        return
    if name.lower() not in {n.lower() for n in state.ch_names}:
        yield Issue(
            severity="warning",
            field_path="eeg_profiles.channel",
            message=(
                f"Channel {name!r} is not in the signal (EEG profiles "
                "will fall back to channel index 0 with a warning)."
            ),
        )


# ---------------------------------------------------------------------
# 4. matching_pursuit.channels  (string or list; 'all' sentinel)
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["matching_pursuit.channels"],
    rule_id="hard.channels.matching_pursuit_channels_present",
    rationale="MP decomposition writes a book whose channels are "
              "matching_pursuit.channels.  Missing names are dropped, "
              "shrinking the book to whatever's available -- consumers "
              "(dipole, eeg_profiles, mp_filter) then can't find what "
              "they expected.",
)
def matching_pursuit_channels_present(state: State) -> Iterable[Issue]:
    if state.ch_names is None:
        return
    if not _consumer_enabled(state.cfg, "mp_decomposition"):
        return  # if MP isn't running, channels list is irrelevant
    mp = state.cfg.get("matching_pursuit", {})
    if not isinstance(mp, dict):
        return
    required = _as_channel_list(mp.get("channels"))
    if not required:
        return
    missing = _missing(required, state.ch_names)
    if missing:
        yield _make_channel_issue(
            "matching_pursuit.channels", missing,
            "MP channels {missing} are not in the signal (the book "
            "will be missing these channels and downstream consumers "
            "may fail).")


# ---------------------------------------------------------------------
# 5. connectivity.channels  (string or list; 'all' sentinel)
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["connectivity.channels"],
    rule_id="hard.channels.connectivity_channels_present",
    rationale="connectivity.channels selects channels for the MVAR "
              "fit.  Missing channels are silently dropped; the user "
              "sees a smaller-than-expected connectivity matrix.",
)
def connectivity_channels_present(state: State) -> Iterable[Issue]:
    if state.ch_names is None:
        return
    if not _consumer_enabled(state.cfg, "connectivity"):
        return
    conn = state.cfg.get("connectivity", {})
    if not isinstance(conn, dict):
        return
    required = _as_channel_list(conn.get("channels"))
    if not required:
        return
    missing = _missing(required, state.ch_names)
    if missing:
        yield _make_channel_issue(
            "connectivity.channels", missing,
            "Connectivity channels {missing} are not in the signal "
            "(the analysis will run on the matched subset).")


# ---------------------------------------------------------------------
# 6. choosing_channels.{selected,dropped}_channels
# ---------------------------------------------------------------------

@rule(
    fires_at=["signal_load", "field_edit", "pre_launch"],
    triggers=["choosing_channels.selected_channels",
              "choosing_channels.dropped_channels"],
    rule_id="hard.channels.choosing_channels_present_subset",
    rationale="choosing_channels carries the user's manual subset "
              "(selected or dropped).  Stale TOMLs from a different "
              "recording can name channels that don't exist; the "
              "pipeline silently filters those out and proceeds with "
              "whatever matched.",
)
def choosing_channels_present_subset(state: State) -> Iterable[Issue]:
    if state.ch_names is None:
        return
    if not _consumer_enabled(state.cfg, "chosen_channels"):
        return  # manual subset only matters when chosen_channels runs
    cc = state.cfg.get("choosing_channels", {})
    if not isinstance(cc, dict):
        return
    available = state.ch_names
    # SelectionPanel writes either `selected_channels` (with possibly
    # `"all"`) or `dropped_channels` (a list).  Either could be stale.
    selected = cc.get("selected_channels")
    if isinstance(selected, (list, tuple)) and selected:
        missing = _missing(
            (str(c).strip() for c in selected if str(c).strip()),
            available)
        if missing:
            yield _make_channel_issue(
                "choosing_channels.selected_channels", missing,
                "Selected channels {missing} are not in the signal "
                "(stale from a different recording? they will be "
                "filtered out).")
    dropped = cc.get("dropped_channels")
    if isinstance(dropped, (list, tuple)) and dropped:
        missing = _missing(
            (str(c).strip() for c in dropped if str(c).strip()),
            available)
        if missing:
            yield _make_channel_issue(
                "choosing_channels.dropped_channels", missing,
                "Dropped channels {missing} are not in the signal "
                "(stale from a different recording? they have no "
                "effect).")


__all__ = [
    "choosing_channels_present_subset",
    "connectivity_channels_present",
    "dipole_ignored_channels_present",
    "eeg_profiles_channel_present",
    "ica_eog_channels_present",
    "matching_pursuit_channels_present",
]
