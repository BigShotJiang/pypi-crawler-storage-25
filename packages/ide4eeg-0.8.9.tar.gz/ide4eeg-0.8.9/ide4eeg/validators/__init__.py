"""Consistency-rule framework (Stage 5).

Pure-function predicates over an immutable :class:`State` snapshot,
collected via a small :func:`rule` decorator and dispatched at five
named fire-points (config-load, signal-load, field-edit, pre-launch,
step-entry).  Designed to extend the existing
:mod:`ide4eeg.config_schema` validator from "TOML shape" to
"config-vs-state consistency" without inventing a reactive framework
or a god-registry.

Design contract (locked in Phase 0):

* **State is frozen** — ``frozen=True`` dataclass; rules cannot mutate.
* **State.cfg is a read-only mapping** — wrapped in :class:`MappingProxyType`
  before being handed to rules; rules cannot mutate the underlying dict.
* **Hash slices are read-only** — ``_pipeline_config_hash``,
  ``_pipeline_step_hashes``, ``_mp_book_hash`` are populated from cfg
  at snapshot time and exposed as separate fields.  Rules read them;
  rules MUST NOT call hash recomputation.
* **The change bus never recomputes hashes** — :class:`ConfigChangeBus`
  publishes field-edit events that have two consumers (hash
  mark-dirty, rule re-eval); it is fire-and-forget for rule re-eval and
  "drop pin if present" for hashes, never "recompute."
* **R10 invariants untouched** — bound-method check, pin-coverage check,
  pin-before-truncation in :mod:`ide4eeg.preprocessing.preprocessing`
  lines 468-572 stay as runtime correctness guards on the hash
  machinery.  Stage 5 does not migrate them.

Mirrors the philosophy from R5 (single :class:`StepDef` registry) and
the deferred R10 (hash invariants as cheap runtime asserts): narrow
substrate, stdlib-only, no new runtime deps.

See :ref:`CONTRIBUTING.md § Adding a new consistency rule
<adding-a-new-consistency-rule>` for the developer-facing how-to,
and the per-module docstrings under :mod:`ide4eeg.validators.hard`
for the design rationale of each rule family.
"""
from __future__ import annotations

import dataclasses
import logging
import types
from typing import (
    Any, Callable, Iterable, Literal, Mapping, Protocol, runtime_checkable,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------
# Severity, fire-points, Issue (extends ConfigIssue's role)
# ---------------------------------------------------------------------

Severity = Literal["error", "warning", "info", "hint"]
"""Issue severity, ordered by user impact.

* ``error``    — blocks pipeline run.  Surfaces as red modal at pre-launch.
* ``warning``  — does not block.  Surfaces as a badge near the field.
* ``info``     — neutral observation.  Surfaces as a low-emphasis badge.
* ``hint``     — advisory heuristic.  Dismissible per-user.
"""

FirePoint = Literal[
    "config_load", "signal_load", "field_edit", "pre_launch", "step_entry"
]
"""When a rule is checked.

* ``config_load``  — after a TOML is loaded into a cfg dict
* ``signal_load``  — after the signal file's metadata becomes available
* ``field_edit``   — when a single field changes in the GUI / live cfg
* ``pre_launch``   — just before the pipeline starts running
* ``step_entry``   — at the entry of each preprocessing/analysis step
"""


@dataclasses.dataclass(frozen=True)
class Issue:
    """One consistency finding emitted by a rule.

    Extends the legacy :class:`ide4eeg.config_schema.ConfigIssue` shape
    with a stable ``rule_id`` (for dismissal targeting), a per-issue
    ``dismiss_id`` (for grouping equivalent re-issues), and a snapshot
    fingerprint used to drop stale issues during async signal loads.

    Attributes
    ----------
    severity : Severity
        See :data:`Severity`.
    field_path :
        Dot-separated path to the config field the issue is about
        (e.g. ``"re_reference"`` or ``"ICA_EOG.find_bads_eog_ch"``).
        Empty string for global / multi-field issues.
    message :
        Human-readable explanation.
    rule_id :
        Stable identifier of the rule that emitted the issue.  Used by
        the dismissal subsystem to suppress repeats.  Populated by the
        dispatcher from the rule's ``_rule_meta``.
    dismiss_id :
        Optional fine-grained dismissal key.  When unset, the rule's
        ``rule_id`` is used.  Useful when one rule fires on multiple
        distinct config values (e.g. ``trim_too_aggressive`` per
        kept-fraction bucket).
    snapshot_id :
        Identifier of the :class:`State` snapshot the rule observed.
        Allows the dispatcher to drop issues that originated from a
        snapshot that's already been superseded (async signal-load
        race).
    """
    severity: Severity
    field_path: str
    message: str
    rule_id: str = ""
    dismiss_id: str | None = None
    snapshot_id: str = ""

    def __str__(self) -> str:  # pragma: no cover (cosmetic)
        return f"[{self.severity}] {self.field_path}: {self.message}"


# ---------------------------------------------------------------------
# State snapshot
# ---------------------------------------------------------------------

@dataclasses.dataclass(frozen=True)
class State:
    """Immutable snapshot of everything a rule can observe.

    Built once per fire-point round by
    :func:`ide4eeg.validators._state.capture`.  Rules receive a single
    ``State`` and return a list of :class:`Issue` objects; they MUST
    NOT mutate this object (Python's :class:`dataclasses.FrozenInstanceError`
    enforces it) and they MUST NOT mutate the underlying cfg dict
    (the ``cfg`` field is a :class:`types.MappingProxyType` view).

    Hash slices (``pipeline_config_hash``, ``pipeline_step_hashes``,
    ``mp_book_hash``) mirror the existing ``cfg["_pipeline_*"]``
    runtime pins.  They are read-only views; rules MUST NOT trigger
    hash recomputation from rule code.  See module docstring.
    """
    cfg: Mapping[str, Any]
    """Read-only view of the live config dict (MappingProxyType)."""

    # --- Signal metadata (None when no signal is loaded yet) ---
    ch_names: tuple[str, ...] | None = None
    ch_types: Mapping[str, str] | None = None
    sfreq: float | None = None
    duration: float | None = None
    has_events: bool | None = None
    event_codes: frozenset[int] = frozenset()
    event_names: frozenset[str] = frozenset()
    has_native_positions: bool | None = None

    # --- Hash slices (READ-ONLY; populated from cfg["_pipeline_*"]) ---
    pipeline_config_hash: str | None = None
    pipeline_step_hashes: Mapping[str, str] | None = None
    mp_book_hash: str | None = None

    # --- Tool presence (cached at capture time, not per-rule) ---
    tool_paths: Mapping[str, str | None] = dataclasses.field(
        default_factory=lambda: types.MappingProxyType({}))

    # --- Provenance ---
    captured_at: FirePoint = "config_load"
    snapshot_id: str = ""

    # --- step_entry context (None at every other fire-point) ---
    # When :func:`run_at` is invoked at ``fire_point="step_entry"``,
    # the dispatcher clones the snapshot via :func:`dataclasses.replace`
    # to set ``current_step`` to the step name (matches the pipeline's
    # ``step_order`` token), so step_entry rules can key off "which
    # step am I gating?".
    current_step: str | None = None


# ---------------------------------------------------------------------
# Rule protocol + decorator + registry
# ---------------------------------------------------------------------

@runtime_checkable
class Rule(Protocol):
    """A consistency rule.

    Any callable matching ``(State) -> Iterable[Issue]`` and carrying
    a ``_rule_meta`` attribute is a Rule.  The :func:`rule` decorator
    is the canonical way to attach the metadata.

    Notes
    -----
    The protocol is :func:`runtime_checkable` for testing but normal
    callsites don't ``isinstance(fn, Rule)`` — they trust the registry.
    """
    _rule_meta: "_RuleMeta"

    def __call__(self, state: State) -> Iterable[Issue]: ...  # pragma: no cover


@dataclasses.dataclass(frozen=True)
class _RuleMeta:
    """Decorator-attached metadata stashed on every rule function.

    Attributes
    ----------
    rule_id :
        Stable identifier (auto-generated from module + function name
        when not given explicitly).  Used for dismissal targeting and
        log correlation.
    fires_at :
        Tuple of fire-points at which this rule is run.
    triggers :
        Tuple of field paths whose edits should trigger this rule.
        Empty tuple = rule fires regardless of field path (e.g.
        whole-config rules).
    rationale :
        Short docstring-style sentence explaining WHY the rule exists.
        Used in the Pipeline-invariants panel (Phase 5) and in
        dismissal UI as the hover-tooltip.
    """
    rule_id: str
    fires_at: tuple[FirePoint, ...]
    triggers: tuple[str, ...]
    rationale: str


_REGISTRY: list[Rule] = []
"""Module-level rule registry.  Populated by :func:`rule` at decoration
time and re-exported via :func:`registered_rules`.

The registry is populated at import time of any module that defines
``@rule``-decorated functions.  To make rules discoverable, each
sub-package (:mod:`ide4eeg.validators.hard`, :mod:`...quality`) MUST
import its rule modules explicitly in ``__init__.py``.  We do not
use :func:`pkgutil.walk_packages` because it does not work reliably
under PyInstaller frozen builds (see the Monika v0.8.5 / v0.8.6
``mne.html_templates`` debugging notes — same failure mode)."""

_REGISTERED_IDS: set[str] = set()


def rule(
    *,
    fires_at: Iterable[FirePoint],
    triggers: Iterable[str] = (),
    rule_id: str | None = None,
    rationale: str = "",
) -> Callable[[Callable[[State], Iterable[Issue]]],
              Callable[[State], Iterable[Issue]]]:
    """Decorator: register a function as a consistency rule.

    Parameters
    ----------
    fires_at :
        One or more :data:`FirePoint` values.  The dispatcher only
        invokes the rule at those points.
    triggers :
        Field paths whose edits should trigger this rule at
        ``field_edit`` time.  When empty, the rule fires on every
        edit (use sparingly).
    rule_id :
        Stable identifier.  Defaults to ``<module>.<function>``.
    rationale :
        Short sentence explaining WHY the rule exists.

    Returns
    -------
    decorator
        The decorator attaches a frozen :class:`_RuleMeta` to the
        function via the ``_rule_meta`` attribute and appends it to
        :data:`_REGISTRY`.
    """
    fires_at_t = tuple(fires_at)
    triggers_t = tuple(triggers)

    def decorator(fn: Callable[[State], Iterable[Issue]]
                  ) -> Callable[[State], Iterable[Issue]]:
        rid = rule_id or f"{fn.__module__}.{fn.__qualname__}"
        if rid in _REGISTERED_IDS:
            raise ValueError(
                f"Duplicate rule_id {rid!r}.  Rule IDs must be unique "
                "across the registry; rename one or pass rule_id= "
                "explicitly to differentiate.")
        meta = _RuleMeta(
            rule_id=rid,
            fires_at=fires_at_t,
            triggers=triggers_t,
            rationale=rationale,
        )
        # Stash metadata on the function so the registry index works
        # but introspection-style discovery is still possible.
        fn._rule_meta = meta  # type: ignore[attr-defined]
        _REGISTRY.append(fn)  # type: ignore[arg-type]
        _REGISTERED_IDS.add(rid)
        return fn

    return decorator


def registered_rules() -> tuple[Rule, ...]:
    """Return the current rule registry as an immutable tuple.

    Order matches decoration order, which is import order, which is
    fully determined by the explicit-import lists in
    :mod:`ide4eeg.validators.hard.__init__` and
    :mod:`ide4eeg.validators.quality.__init__`.
    """
    return tuple(_REGISTRY)


#: Display labels for the rule-category groups surfaced in the
#: Pipeline-invariants Help panel.  Keys must match the second segment
#: of ``rule_id`` (i.e. the module name under ``validators/hard/`` or
#: ``validators/quality/``).  The GUI iterates this mapping in
#: insertion order so the panel layout is stable; unknown modules
#: render with a Title-Cased fallback label.
CATEGORY_LABELS: dict[str, str] = {
    "reference":  "Reference & re-referencing",
    "dipole":     "Dipole fitting",
    "channels":   "Channel selection",
    "modes":      "Segmentation modes & events",
    "step_order": "Preprocessing step order",
    "tools":      "External tool availability",
}


def clear_registry_for_testing() -> None:
    """Wipe the registry — TESTS ONLY.

    Production code should never call this.  Tests that want to
    register isolated rules call this first, then re-import the
    rule modules they need.
    """
    _REGISTRY.clear()
    _REGISTERED_IDS.clear()


# ---------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------

def run_at(
    fire_point: FirePoint,
    state: State,
    *,
    field_path: str | None = None,
    respect_dismissals: bool = False,
    step_name: str | None = None,
) -> list[Issue]:
    """Run every applicable rule and collect issues.

    Parameters
    ----------
    fire_point :
        Which fire-point this invocation is for.  Only rules whose
        ``fires_at`` includes this value are considered.
    state :
        The immutable snapshot to evaluate.
    field_path :
        Optional field path filter.  When set, only rules whose
        ``triggers`` include this path (or have empty ``triggers``)
        are run.  Used by the GUI's per-field-edit dispatch to avoid
        evaluating unrelated rules on every keystroke.
    respect_dismissals :
        When True, skip rules whose ``rule_id`` the user has
        dismissed via :mod:`ide4eeg.validators._dismissals`.  Used
        by the inline ``field_edit`` / ``signal_load`` dispatchers
        so a "don't show again" choice silences the badge.  Always
        False at ``pre_launch`` -- run-time errors must surface in
        the preflight dialog even if previously dismissed inline.
    step_name :
        At ``fire_point="step_entry"`` only -- the step about to
        run (matches the pipeline's ``step_order`` token,
        e.g. ``"ica"``, ``"mp_decomposition"``).  The dispatcher
        clones ``state`` via :func:`dataclasses.replace` so rules
        see ``state.current_step == step_name``.  Ignored at
        every other fire-point.

    Returns
    -------
    list of Issue
        Each issue carries the rule's ``rule_id`` and the state's
        ``snapshot_id`` so the renderer can drop superseded issues.
    """
    if fire_point == "step_entry" and step_name is not None:
        state = dataclasses.replace(state, current_step=step_name)
    dismissed: frozenset[str] = frozenset()
    if respect_dismissals:
        from ide4eeg.validators._dismissals import dismissed_ids
        dismissed = dismissed_ids()
    issues: list[Issue] = []
    for r in _REGISTRY:
        meta: _RuleMeta = r._rule_meta  # type: ignore[attr-defined]
        if fire_point not in meta.fires_at:
            continue
        if respect_dismissals and meta.rule_id in dismissed:
            continue
        if (field_path is not None
                and meta.triggers
                and field_path not in meta.triggers):
            continue
        try:
            emitted = r(state)
        except Exception as exc:  # noqa: BLE001
            # A buggy rule should not crash the pipeline / GUI.  Log
            # and continue; the rule author's tests catch this in CI.
            logger.error("Rule %s raised at fire_point=%s: %s",
                         meta.rule_id, fire_point, exc, exc_info=True)
            continue
        for issue in emitted or ():
            # Stamp rule_id / snapshot_id on emit so rules don't have
            # to.  Rules only need to fill severity, field_path,
            # message, optional dismiss_id.
            issues.append(dataclasses.replace(
                issue, rule_id=meta.rule_id, snapshot_id=state.snapshot_id))
    return issues


# ---------------------------------------------------------------------
# ConfigChangeBus — single edit event, two consumers
# ---------------------------------------------------------------------

class ConfigChangeBus:
    """Single pub/sub for "a field changed" events.

    Consumers
    ---------
    1. **Hash machinery (existing)** — drops the pin if present
       (``cfg["_pipeline_*"]`` keys are removed).  Never recomputes
       here; recompute happens only at pipeline entry per R10.
    2. **Stage 5 rule re-eval (new)** — calls :func:`run_at` with the
       ``"field_edit"`` fire-point and the changed field path.

    Debouncing
    ----------
    The bus coalesces rapid edits via an optional debounce delay
    (default 300 ms).  Without debouncing, typing "M1, M2" into the
    Reference field would fire the bus once per keystroke ("M",
    "M1", "M1,", "M1, ", "M1, M", ...) and the user would see
    transient red badges.  The debounce timer is reset on every
    publish; the bus delivers when the field has been idle for
    ``debounce_ms`` milliseconds.

    Pure Python / no Qt
    -------------------
    The bus itself is pure stdlib (uses :class:`threading.Timer`).
    The GUI wires it to ``textChanged`` / ``currentTextChanged``;
    the CLI does not use it at all (CLI re-runs rules on launch).
    """

    def __init__(self, debounce_ms: int = 300) -> None:
        self._debounce_s = debounce_ms / 1000.0
        self._subscribers: list[Callable[[str], None]] = []
        # Map field_path -> (active Timer, epoch).  Epoch increments on
        # every publish; a Timer's _deliver only fires if its captured
        # epoch still matches what's in _pending.  threading.Timer.cancel()
        # is best-effort -- a Timer that has already started its
        # _deliver cannot be stopped, so the epoch check is what
        # actually prevents superseded fires.
        self._pending: dict[str, tuple] = {}
        self._next_epoch = 0
        # Lazy import — keeps this class importable in test contexts
        # that monkeypatch threading.
        import threading
        self._Timer = threading.Timer
        # Lock guards _pending + _next_epoch.  Subscribers run OUTSIDE
        # the lock (re-entrant publish() during a subscriber callback
        # would otherwise deadlock).
        self._lock = threading.Lock()

    def subscribe(self, callback: Callable[[str], None]) -> None:
        """Register a consumer.  Each consumer receives the field path
        of every published edit, post-debounce.

        Single-threaded use case: subscribers register at GUI
        construction; the bus only publishes after that.  No lock on
        the list itself.
        """
        self._subscribers.append(callback)

    def publish(self, field_path: str) -> None:
        """Schedule a deliver-on-idle for ``field_path``.

        Subsequent publishes for the same path reset the timer; the
        new epoch makes any racing already-firing prior Timer drop
        its delivery via the epoch check in :meth:`_deliver`.
        """
        with self._lock:
            old = self._pending.pop(field_path, None)
            if old is not None:
                old[0].cancel()  # best-effort; epoch check is the real guard
            self._next_epoch += 1
            epoch = self._next_epoch
            timer = self._Timer(self._debounce_s, self._deliver,
                                args=(field_path, epoch))
            timer.daemon = True
            self._pending[field_path] = (timer, epoch)
            timer.start()

    def flush(self, field_path: str | None = None) -> None:
        """Deliver pending events immediately (used by tests and by
        the GUI on launch-button click — we don't want to wait the
        debounce window before running the pre-launch rule sweep).
        """
        with self._lock:
            keys = [field_path] if field_path is not None else list(
                self._pending)
            delivered = []
            for k in keys:
                entry = self._pending.pop(k, None)
                if entry is not None:
                    entry[0].cancel()
                    delivered.append(k)
        # Fan out OUTSIDE the lock so a subscriber re-entering
        # publish() doesn't deadlock.
        for k in delivered:
            self._fanout(k)

    def _deliver(self, field_path: str, epoch: int) -> None:
        with self._lock:
            entry = self._pending.get(field_path)
            if entry is None or entry[1] != epoch:
                # Superseded by a later publish (different epoch) or
                # already drained by flush().  Drop without firing.
                return
            self._pending.pop(field_path, None)
        self._fanout(field_path)

    def _fanout(self, field_path: str) -> None:
        for cb in self._subscribers:
            try:
                cb(field_path)
            except Exception as exc:  # noqa: BLE001
                logger.error(
                    "ConfigChangeBus subscriber raised on field %r: %s",
                    field_path, exc, exc_info=True)


# ---------------------------------------------------------------------
# Internal-state predicate (shared across validator + hash + export)
# ---------------------------------------------------------------------

_RUNTIME_KEY_PREFIX = "_"
_PIPELINE_KEY_PREFIX = "_pipeline_"


def is_internal_state(key: str) -> bool:
    """True iff ``key`` is runtime / pipeline-internal state.

    Centralises the predicate used by three subsystems that today
    each have their own definition of "treat this key differently":

    * the validator's ``_pipeline_*`` skip in :mod:`ide4eeg.config_schema`
    * the script exporter's underscore-key filter in :mod:`ide4eeg.api`
    * the hash machinery's runtime-field exclusion in
      :mod:`ide4eeg.preprocessing.preprocessing`

    Today the three definitions agree but are duplicated; the shared
    helper prevents future drift.  See ``stage5-design-notes.md``
    "Integration with the existing substrate."
    """
    return key.startswith(_RUNTIME_KEY_PREFIX)


def is_pipeline_pin(key: str) -> bool:
    """True iff ``key`` is a pipeline freshness pin (``_pipeline_*``).

    Stricter than :func:`is_internal_state`.  Used to detect "this
    cfg came out of the GUI's serialise-deserialise cycle" — the
    validator skips on this signal to avoid spamming dead-key
    warnings on the runner's own snapshot.
    """
    return key.startswith(_PIPELINE_KEY_PREFIX)


__all__ = [
    "CATEGORY_LABELS",
    "ConfigChangeBus",
    "FirePoint",
    "Issue",
    "Rule",
    "Severity",
    "State",
    "clear_registry_for_testing",
    "is_internal_state",
    "is_pipeline_pin",
    "registered_rules",
    "rule",
    "run_at",
]
