"""Quality rules — heuristic advisory issues.

Severity is ``info`` or ``hint``.  Never blocking; dismissible
per-user via the dismissal subsystem (Phase 10).

Like :mod:`...hard`, rule modules are imported explicitly here — we
do NOT use :func:`pkgutil.walk_packages` (PyInstaller frozen-build
compatibility).
"""
# Phase 0 ships the substrate with no quality rules.  Subsequent
# phases add rule modules here.
#
# Phase 6:  from . import soft_order            # noqa: F401
# Phase 8:  from . import preprocessing_quality # noqa: F401
# Phase 9:  from . import staleness             # noqa: F401
