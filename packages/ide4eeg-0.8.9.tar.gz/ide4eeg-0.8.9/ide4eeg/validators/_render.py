"""Issue rendering — GUI badge + CLI / log formats.

Two-tier design: the pure-text formatters (:func:`render_for_log`,
:func:`render_for_cli`) work in any environment; the Qt-dependent
:class:`ChannelStatusBadge` is loaded only when PySide6 is available
(no hard import at module top).  CLI / test code can use this module
without pulling in Qt.
"""
from __future__ import annotations

import logging
from typing import Iterable, TYPE_CHECKING

from . import Issue, Severity

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------
# Severity ordering — used by the badge to pick the most severe of a
# list, and by the dispatcher post-filter when consolidating duplicates.
# ---------------------------------------------------------------------

_SEVERITY_ORDER: dict[Severity, int] = {
    "hint": 0, "info": 1, "warning": 2, "error": 3,
}


def severity_rank(s: Severity) -> int:
    """Higher = more severe.  Used to pick the worst of a group."""
    return _SEVERITY_ORDER[s]


def worst_of(issues: Iterable[Issue]) -> Issue | None:
    """Return the highest-severity issue from a group, or None.

    Used by the GUI badge when one widget has multiple issues — show
    the worst one as the badge, list the rest in the tooltip.
    """
    items = list(issues)
    if not items:
        return None
    return max(items, key=lambda i: severity_rank(i.severity))


# ---------------------------------------------------------------------
# Text formatters — work everywhere, no Qt
# ---------------------------------------------------------------------

def render_for_log(issue: Issue) -> str:
    """One-line log format.  Compact, no colors, machine-greppable."""
    return f"[{issue.severity}] {issue.rule_id} ({issue.field_path}): {issue.message}"


def render_for_cli(issue: Issue) -> str:
    """One-line CLI format with severity glyph.  ASCII-only so the
    output survives non-UTF-8 Windows consoles."""
    glyph = {
        "error": "[X]", "warning": "[!]", "info": "[i]", "hint": "[*]",
    }.get(issue.severity, "[?]")
    where = f" ({issue.field_path})" if issue.field_path else ""
    return f"{glyph} {issue.message}{where}"


def render_summary_table(issues: Iterable[Issue]) -> str:
    """Multi-line summary used at pre-launch by the CLI.

    One row per issue grouped by severity, sorted by severity
    (worst first).  No external table library; just stdlib string
    formatting.
    """
    rows = list(issues)
    if not rows:
        return ""
    rows.sort(key=lambda i: (-severity_rank(i.severity), i.field_path))
    lines: list[str] = []
    cur_sev: Severity | None = None
    for issue in rows:
        if issue.severity != cur_sev:
            cur_sev = issue.severity
            lines.append(f"  {cur_sev.upper()}:")
        field = f" ({issue.field_path})" if issue.field_path else ""
        lines.append(f"    - {issue.message}{field}")
    return "\n".join(lines)


def log_issues(issues: Iterable[Issue],
               level: int = logging.WARNING) -> None:
    """Convenience: log every issue to the stdlib logger at the given
    level.  Default WARNING — matches the existing config_schema
    convention."""
    for issue in issues:
        logger.log(level, "%s", render_for_log(issue))


# ---------------------------------------------------------------------
# Qt badge — optional, only present when PySide6 is importable
# ---------------------------------------------------------------------

if TYPE_CHECKING:  # pragma: no cover
    from PySide6.QtWidgets import QLabel, QWidget


def _try_import_qt():
    """Lazy import of PySide6 — returns the relevant classes or None."""
    try:
        from PySide6.QtCore import Qt
        from PySide6.QtWidgets import QLabel, QWidget  # noqa: F401
        return QLabel, QWidget, Qt
    except ImportError:
        return None


_COLORS: dict[Severity, str] = {
    "error":   "#c62828",   # red
    "warning": "#ef6c00",   # orange
    "info":    "#1565c0",   # blue
    "hint":    "#6a737d",   # gray
}

_GLYPHS: dict[Severity, str] = {
    "error":   "✗",   # ✗
    "warning": "⚠",   # ⚠
    "info":    "ℹ",   # ℹ
    "hint":    "•",   # •
}


class ChannelStatusBadge:
    """Qt-side renderer that any widget can attach to.

    Usage::

        badge = ChannelStatusBadge(parent=header_layout)
        badge.show_issues(issues)        # paint the worst severity
        badge.clear()                    # no issues to show

    Stays a thin facade — under the hood it owns one :class:`QLabel`
    whose text/colour/tooltip are updated.  No layout work; the
    caller decides where to place ``badge.widget``.

    The :class:`QLabel` is created lazily on first show so import
    of this module in a Qt-less environment doesn't fail.
    """

    # Class-level: every live badge registers here so a dismissal
    # can sweep ALL of them and refresh their painted state.  Without
    # this, multi-surface fan-out (one rule painting two badges, e.g.
    # ``_mp_book_path`` on both BookChannelPanels) leaves the sibling
    # badge stale after the user dismisses on one side: the next
    # dispatch would clear it, but until then the visual is wrong.
    # WeakSet so badges that go out of scope drop out automatically;
    # nothing here pins them against garbage collection.
    import weakref as _weakref
    _live_badges: "_weakref.WeakSet[ChannelStatusBadge]" = (
        _weakref.WeakSet())

    def __init__(self, parent: "QWidget | None" = None) -> None:
        qt = _try_import_qt()
        if qt is None:
            raise RuntimeError(
                "ChannelStatusBadge requires PySide6.  Use "
                "render_for_log / render_for_cli in non-Qt contexts.")
        QLabel, _QWidget, Qt = qt
        self._label = QLabel(parent)
        self._label.setVisible(False)
        self._label.setTextFormat(Qt.PlainText)
        self._label.setOpenExternalLinks(False)
        self._issues: list[Issue] = []
        # Right-click → context menu with "Don't show again" per rule.
        # The menu is rebuilt lazily so a badge for a rule a user
        # hasn't dismissed (the common case) doesn't allocate one.
        self._label.setContextMenuPolicy(Qt.CustomContextMenu)
        self._label.customContextMenuRequested.connect(
            self._on_context_menu)
        ChannelStatusBadge._live_badges.add(self)

    @property
    def widget(self) -> "QWidget":
        """The :class:`QLabel` to add to your layout."""
        return self._label

    def show_issues(self, issues: Iterable[Issue]) -> None:
        """Paint the worst issue's severity as the badge; list all
        in the tooltip."""
        self._issues = list(issues)
        if not self._issues:
            self.clear()
            return
        worst = worst_of(self._issues)
        assert worst is not None  # _issues non-empty
        glyph = _GLYPHS.get(worst.severity, "*")
        color = _COLORS.get(worst.severity, "#000")
        self._label.setStyleSheet(f"color: {color};")
        self._label.setText(f"{glyph} {worst.message}")
        self._label.setToolTip("\n".join(
            render_for_cli(i) for i in self._issues))
        self._label.setVisible(True)

    def clear(self) -> None:
        """Hide the badge — used when issues drain to empty."""
        self._issues = []
        self._label.clear()
        self._label.setVisible(False)

    def current_issues(self) -> tuple[Issue, ...]:
        """Immutable snapshot of currently-displayed issues.  Used by
        tests."""
        return tuple(self._issues)

    def _on_context_menu(self, pos) -> None:
        """Build a per-rule "Don't show again" menu on right-click.

        One entry per distinct ``rule_id`` in the currently-displayed
        issues; clicking dismisses that rule via
        :mod:`ide4eeg.validators._dismissals`.  After dismissal the
        badge clears (the issue is no longer relevant); the next
        ``field_edit`` / ``signal_load`` dispatch already filters
        dismissed rules so it won't reappear.
        """
        if not self._issues:
            return
        from PySide6.QtWidgets import QMenu
        from ide4eeg.validators import _dismissals
        menu = QMenu(self._label)
        # De-dup by rule_id so a single rule emitting multiple
        # issues for one field shows ONE menu entry.
        seen: set[str] = set()
        for issue in self._issues:
            rid = getattr(issue, "rule_id", None)
            if not rid or rid in seen:
                continue
            seen.add(rid)
            label = f"Don't show '{rid}' again"
            action = menu.addAction(label)
            action.triggered.connect(
                lambda _checked=False, r=rid: self._dismiss_rule(r))
        if not seen:
            return
        menu.exec(self._label.mapToGlobal(pos))

    def _dismiss_rule(self, rule_id: str) -> None:
        """Persist the dismissal and refresh every live badge.

        The clicked badge needs immediate feedback, but so does any
        SIBLING badge currently painting the same ``rule_id`` (one
        rule may have multiple visual surfaces via the GUI's
        ``_field_badge_secondary`` fan-out -- ``_mp_book_path`` paints
        on both BookChannelPanels).  Walk :data:`_live_badges` and
        drop the dismissed rule from each.  Subsequent dispatches
        already filter dismissed rules via
        :func:`run_at(respect_dismissals=True)`, so this is just the
        immediate-visual-consistency fix.
        """
        from ide4eeg.validators import _dismissals
        from shiboken6 import isValid as _qt_isValid
        _dismissals.dismiss(rule_id)
        for badge in list(ChannelStatusBadge._live_badges):
            # WeakSet retains the Python wrapper for any badge whose
            # C++ side has been destroyed (the wrapper isn't gc'd
            # while a reference lingers in the set).  Skip those --
            # touching ._label on a deleted Qt object raises
            # RuntimeError ("Internal C++ object already deleted").
            # Production hits this on app restart / error recovery;
            # the test suite hits it whenever a fixture forces a
            # shiboken6.delete() between sessions.
            if not _qt_isValid(badge) or not _qt_isValid(badge._label):
                continue
            remaining = [i for i in badge._issues
                         if getattr(i, "rule_id", None) != rule_id]
            if remaining:
                badge.show_issues(remaining)
            else:
                badge.clear()


__all__ = [
    "ChannelStatusBadge",
    "log_issues",
    "render_for_cli",
    "render_for_log",
    "render_summary_table",
    "severity_rank",
    "worst_of",
]
