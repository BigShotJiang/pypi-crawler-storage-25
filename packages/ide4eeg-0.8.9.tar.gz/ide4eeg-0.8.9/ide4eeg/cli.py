"""CLI entry point for IDE4EEG.

Default mode is GUI.  An optional positional config path preloads
the TOML into the GUI form (equivalent to clicking ``Load pipeline
settings .toml`` right after launch).  ``--run`` switches to
headless batch mode.

After ``pip install ide4eeg`` the entry point is just ``ide4eeg``;
``python -m ide4eeg`` works as well via :mod:`ide4eeg.__main__`.

Examples
--------
    ide4eeg                       # open GUI, blank state
    ide4eeg myconfig.toml         # GUI with config preloaded
    ide4eeg --run myconfig.toml   # batch run, no GUI
    ide4eeg --run x.toml -t       # batch with full traceback
"""

import sys

if sys.version_info < (3, 11):
    sys.stderr.write(
        f"IDE4EEG requires Python 3.11 or newer (you have "
        f"{sys.version_info.major}.{sys.version_info.minor}."
        f"{sys.version_info.micro}).\n"
        f"The pipeline uses the stdlib `tomllib` module, added in "
        f"Python 3.11. Please install a newer Python and recreate "
        f"the virtual environment.\n"
    )
    sys.exit(1)

import argparse
import logging
from pathlib import Path

from ide4eeg.utils.log import setup_logging
import ide4eeg

setup_logging(logging.INFO)


def _parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="ide4eeg",
        description=(
            "IDE4EEG — Integrated Development Environment for EEG.\n"
            "\n"
            "Bare invocation opens the Qt6 GUI.  Pass --run with a\n"
            "saved pipeline config to run the pipeline in batch\n"
            "mode (no GUI)."
        ),
        epilog=(
            "examples:\n"
            "  ide4eeg                          "
            "# open GUI, blank state\n"
            "  ide4eeg myconfig.toml            "
            "# GUI with config preloaded\n"
            "  ide4eeg --run myconfig.toml      "
            "# batch run, no GUI\n"
            "  ide4eeg --run x.toml -t          "
            "# batch with full traceback\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "config",
        type=Path,
        nargs="?",
        default=None,
        help=(
            "Path to a TOML pipeline config.  In GUI mode "
            "(default), the file is preloaded into the form.  "
            "With --run, the pipeline consumes it directly."),
    )
    parser.add_argument(
        "--run",
        action="store_true",
        help=(
            "Run the pipeline in batch mode (no GUI).  Requires a "
            "config path."),
    )
    parser.add_argument(
        "-t",
        "--show-traceback",
        action="store_true",
        help="Show full traceback on error (batch mode only).",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"ide4eeg {ide4eeg.__version__}",
    )
    return parser.parse_args(argv)


def _run_batch(config_path, show_traceback):
    """Headless pipeline run.  No Qt, no event loop."""
    if not config_path.exists():
        logging.error(
            f"Config file not found: {config_path}\n"
            f"Provide a valid TOML config path.")
        sys.exit(1)
    # Import the pipeline only in batch mode — avoids loading
    # MNE / numpy / scipy when the user just wants the GUI.
    print("IDE4EEG: loading pipeline (MNE, numpy, scipy) — "
          "first launch can take ~5-15 s...", flush=True)
    from ide4eeg.main import main as pipeline_main
    from ide4eeg.config_schema import ConfigIsExamplesManifestError

    sys.tracebacklimit = None if show_traceback else 0
    logging.info(
        f"Preparing signal with configuration file from "
        f"{config_path}.")
    try:
        pipeline_main(config_path)
    except ConfigIsExamplesManifestError as exc:
        # Clean exit with the actionable message -- no traceback
        # even when -t is set; the user pointed at the wrong file,
        # not at a code bug.
        sys.stderr.write(f"\nERROR: {exc}\n")
        sys.exit(2)
    logging.info("Terminating.")


def _run_gui(preload_config):
    """Launch the GUI, optionally preloading a config."""
    if preload_config is not None and not preload_config.exists():
        # Don't bail — the user might have typo'd a path on a
        # double-click or shortcut.  Warn loudly, open blank.
        sys.stderr.write(
            f"WARNING: config not found: {preload_config}\n"
            f"Opening GUI without preloading.\n")
        preload_config = None
    # Examples-manifest sniff: cheap pre-flight before the heavy
    # GUI / matplotlib imports.  Same UX guard as the --run path.
    if preload_config is not None:
        try:
            import tomllib
            with open(preload_config, "rb") as f:
                _peek = tomllib.load(f)
            from ide4eeg.config_schema import is_examples_manifest
            if is_examples_manifest(_peek):
                from ide4eeg.config_schema import (
                    _format_manifest_remediation)
                sys.stderr.write(
                    f"\nWARNING: {_format_manifest_remediation(_peek, str(preload_config))}\n"
                    f"Opening GUI without preloading.\n")
                preload_config = None
        except (OSError, ValueError):
            # Malformed TOML / unreadable -- let the normal load
            # path surface it.
            pass
    print("IDE4EEG: loading GUI (PySide6, matplotlib) — "
          "first launch can take ~10-30 s...", flush=True)
    from ide4eeg import gui
    gui.main(preload_config=preload_config)


def main(argv=None):
    args = _parse_args(argv)
    if args.run:
        if args.config is None:
            sys.stderr.write(
                "ide4eeg --run: missing config path.\n"
                "Usage: ide4eeg --run <path/to/config.toml>\n")
            sys.exit(2)
        _run_batch(args.config, args.show_traceback)
        return
    _run_gui(args.config)


if __name__ == "__main__":
    main()
