"""Download SVAROG and connectivis from GitLab CI artifacts.

Both tools are built in CI pipelines on GitLab and published as
job artifacts (zip archives containing JAR files).  This module
downloads the latest successful artifact and extracts only the
files needed for the current platform into ``~/.obci/``.

Target layout::

    ~/.obci/svarog/svarog-standalone-*.jar
    ~/.obci/svarog/empi-*-<platform>   (OS-appropriate binary)
    ~/.obci/connectivis/connectivis.jar

Usage (Python)::

    from ide4eeg.download_tools import download_svarog, download_connectivis
    jar, empi = download_svarog()
    jar = download_connectivis()
"""

import logging
import os
import platform
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

logger = logging.getLogger(__name__)

#: GitLab Releases URL surfaced when frozen builds need the user to
#: download a different bundle variant.  Used by the frozen-skip
#: short-circuits in the brew / winget / mpv install paths.
FROZEN_RELEASES_URL = (
    "https://gitlab.com/fuw_software/ide4eeg/-/releases"
)


def _is_lite_frozen():
    """Return True when running inside a frozen "lite" bundle.

    Frozen builds (PyInstaller .exe, py2app .app) come in two
    flavours: **full** (cv2 / torch / l2cs bundled) and **lite**
    (EEG-core only, no video stack).  We don't pass a variant flag
    into the bundle; instead we probe at runtime by trying to import
    a marker package that only the full variant ships.

    Returns
    -------
    bool
        ``True`` iff ``sys.frozen`` is set **and** ``cv2`` cannot
        be imported (i.e. this is the lite variant).  ``False`` for
        regular pip installs and for full-frozen bundles.
    """
    if not getattr(sys, 'frozen', False):
        return False
    try:
        import cv2  # noqa: F401
    except ImportError:
        return True
    return False


#: HTTP User-Agent used for GitLab API requests. GitLab sits behind
#: Cloudflare which occasionally challenges or rate-limits bare or
#: missing UAs; identifying ourselves avoids the whole class of
#: "random bot" heuristics.
_USER_AGENT = "ide4eeg/download_tools (https://gitlab.com/fuw_software/ide4eeg)"


def _certifi_ssl_context():
    """Build an SSL context using the :mod:`certifi` CA bundle.

    Returns ``None`` if certifi is not installed — in that case the
    caller falls back to :func:`ssl.create_default_context`, which
    consults the platform CA store.
    """
    try:
        import certifi
    except ImportError:
        return None
    return ssl.create_default_context(cafile=certifi.where())


def _platform_ssl_fix_hint():
    """Return a platform-specific suggestion for fixing TLS verify
    failures, used in user-facing error messages."""
    system = platform.system()
    if system == "Darwin":
        # python.org macOS installers ship Install Certificates.command
        # in /Applications/Python 3.XX/ which pip-installs certifi and
        # patches the system Python's SSL config to use it. Users who
        # skipped that step see CERTIFICATE_VERIFY_FAILED on any HTTPS
        # endpoint whose CA chain isn't in the (usually empty) macOS
        # keychain-for-Python.
        return (
            "On macOS, if you installed Python from python.org, run:\n"
            "    /Applications/Python*/Install\\ Certificates.command\n"
            "That script installs certifi and wires it into Python's "
            "SSL config (a one-time fix)."
        )
    if system == "Windows":
        return (
            "On Windows, update certifi:\n"
            "    pip install --upgrade certifi"
        )
    return (
        "On Linux, ensure your ca-certificates package is installed\n"
        "and run:  pip install --upgrade certifi"
    )

# GitLab project IDs
_SVAROG_PROJECT_ID = 79716492
_CONNECTIVIS_PROJECT_ID = 80596862

_GITLAB_API = "https://gitlab.com/api/v4/projects"

_SVAROG_URL = (
    f"{_GITLAB_API}/{_SVAROG_PROJECT_ID}"
    "/jobs/artifacts/main/download?job=Svarog+standalone+jar"
)
_CONNECTIVIS_URL = (
    f"{_GITLAB_API}/{_CONNECTIVIS_PROJECT_ID}"
    "/jobs/artifacts/main/download?job=build"
)

# Standard install location.  ``~/.obci/`` is the OBCI ecosystem
# convention (Svarog itself probes its sub-paths for mpv etc.), so
# we keep the external-binaries layout there.  Anything IDE4EEG
# manages directly — model weights, runtime caches — goes under
# ``~/.obci/ide4eeg/`` so the user has at most two places to look:
# the OBCI tree (managed) and their venv site-packages (pip).
TOOLS_DIR = Path.home() / ".obci"
SVAROG_DIR = TOOLS_DIR / "svarog"
CONNECTIVIS_DIR = TOOLS_DIR / "connectivis"
IDE4EEG_DATA_DIR = TOOLS_DIR / "ide4eeg"
IDE4EEG_MODELS_DIR = IDE4EEG_DATA_DIR / "models"
INSIGHTFACE_ROOT = IDE4EEG_DATA_DIR / "insightface"


def _os_tag():
    """Return the empi platform tag for the current OS."""
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system == "darwin":
        return "macos-arm64" if machine == "arm64" else "macos-x64"
    if system == "windows":
        return "windows-x64"
    return "linux-x64"


def _open_url(url, context):
    """Open *url* with an explicit SSL context and a friendly
    User-Agent header. Returns the HTTPResponse (caller closes)."""
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    return urllib.request.urlopen(req, context=context, timeout=30)


def _is_ssl_verify_error(exc):
    """Return True if *exc* is a TLS certificate-verification failure.

    Recognises both ``ssl.SSLCertVerificationError`` directly and the
    ``URLError``/``HTTPError`` wrappers that urllib raises when the
    underlying handshake fails.
    """
    cause = exc
    seen = set()
    while cause is not None and id(cause) not in seen:
        seen.add(id(cause))
        if isinstance(cause, ssl.SSLCertVerificationError):
            return True
        if isinstance(cause, ssl.SSLError) and "CERTIFICATE_VERIFY" in str(cause):
            return True
        msg = str(cause)
        if "CERTIFICATE_VERIFY_FAILED" in msg or "certificate verify failed" in msg:
            return True
        cause = getattr(cause, "__cause__", None) or getattr(cause, "reason", None)
    return False


def _download_zip(url, progress_callback=None):
    """Download *url* to a temporary file, return its path.

    Uses a two-attempt TLS strategy to handle common misconfigurations:

    1. **First attempt — certifi's CA bundle**, if certifi is
       installed. Mozilla's curated root list; works on macOS
       python.org installs that skipped
       ``Install Certificates.command``, on Linux with a missing
       ``ca-certificates`` package, and on Windows with a stale
       cert store. This succeeds for the vast majority of users.

    2. **Second attempt — platform default CA store**, if the first
       attempt raises a TLS verify error. Handles the corporate
       TLS-inspection case: some workplaces run SSL-inspecting
       proxies that re-sign HTTPS traffic with a corporate root CA
       that's in the system store but NOT in Mozilla's bundle. In
       that case certifi verification fails but the platform store
       works.

    On both attempts failing with verify errors, raises a
    :class:`RuntimeError` with a platform-specific hint pointing at
    the appropriate fix. Any other error (network down, 404, etc.)
    is re-raised unchanged.
    """
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
        tmp_path = tmp.name

    def _try_download(context, label):
        """Stream the response for a single SSL context attempt.
        Returns None on success; raises on failure."""
        import time as _t
        with _open_url(url, context) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            size_mb = total / (1024 * 1024) if total else 0
            logger.info(
                "Fetching %s (%.1f MB)...",
                url, size_mb) if total else logger.info(
                "Fetching %s (size unknown)...", url)
            downloaded = 0
            # Tick periodic progress to the console when the GUI didn't
            # wire a progress_callback.  Without this the only visible
            # output for a multi-second download is the start/end log
            # line, which feels frozen.
            last_log = _t.monotonic()
            with open(tmp_path, "wb") as f:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback:
                        progress_callback(downloaded, total)
                    elif _t.monotonic() - last_log > 5.0:
                        if total:
                            logger.info(
                                "  ... %.1f / %.1f MB (%d%%)",
                                downloaded / (1024 * 1024), size_mb,
                                int(100 * downloaded / total))
                        else:
                            logger.info(
                                "  ... %.1f MB downloaded",
                                downloaded / (1024 * 1024))
                        last_log = _t.monotonic()
        # If the server advertised a Content-Length, sanity-check that
        # we actually got it.  A TLS connection-reset mid-download
        # produces a clean EOF in Python's urllib without raising —
        # we'd otherwise end up with a truncated zip that crashes
        # zipfile / Java with a confusing "bad header" later.
        if total and downloaded != total:
            raise IOError(
                f"Truncated download: got {downloaded} of {total} "
                f"bytes from {url} (likely network reset). "
                "Retry, or check your connection.")
        logger.info("Downloaded via %s CA bundle: %d bytes", label, downloaded)

    certifi_ctx = _certifi_ssl_context()
    default_ctx = ssl.create_default_context()

    first_exc = None
    if certifi_ctx is not None:
        try:
            _try_download(certifi_ctx, "certifi")
            return tmp_path
        except urllib.error.URLError as exc:
            if not _is_ssl_verify_error(exc):
                # Not a cert problem — something else (network down,
                # 404, timeout). Don't retry, clean up, re-raise.
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
                raise
            logger.info(
                "certifi SSL verify failed, retrying with platform CA store...")
            first_exc = exc

    # Either certifi wasn't available, or the certifi attempt hit a
    # cert verify error. Fall back to the platform CA store, which
    # handles corporate TLS-inspection proxies that re-sign traffic
    # with a root cert installed in the OS store but not in certifi.
    try:
        _try_download(default_ctx, "platform")
        return tmp_path
    except urllib.error.URLError as exc:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        if _is_ssl_verify_error(exc):
            hint = _platform_ssl_fix_hint()
            raise RuntimeError(
                "TLS certificate verification failed for GitLab CI "
                "artifact download. This is usually a one-time "
                "Python environment setup issue, not a GitLab "
                "problem: Python's SSL library can't validate the "
                "CDN certificate against the CA bundle it's using.\n\n"
                f"Fix:\n{hint}\n\n"
                f"Original error: {exc}"
            ) from exc
        # Non-TLS error from the fallback attempt — surface it.
        raise
    except Exception:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        raise


# ── SVAROG ────────────────────────────────────────────────────────────

def download_svarog(target_dir=None, progress_callback=None):
    """Download the latest SVAROG standalone artifact.

    Extracts the standalone JAR and the OS-appropriate empi binary
    into *target_dir* (default ``~/.obci/svarog/``).

    Parameters
    ----------
    target_dir : str or Path or None
        Override install directory.
    progress_callback : callable or None
        Called with ``(bytes_downloaded, total_bytes)`` during download.

    Returns
    -------
    (str, str or None)
        ``(jar_path, empi_path)`` on success.
    """
    dest = Path(target_dir) if target_dir else SVAROG_DIR
    dest.mkdir(parents=True, exist_ok=True)

    logger.info("Downloading SVAROG from GitLab CI...")
    tmp_path = _download_zip(_SVAROG_URL, progress_callback)

    try:
        os_tag = _os_tag()
        binary = "empi.exe" if platform.system().lower() == "windows" else "empi"
        jar_path = None
        empi_path = None

        with zipfile.ZipFile(tmp_path) as zf:
            for info in zf.infolist():
                name = info.filename
                # Safety
                if name.startswith("/") or ".." in name:
                    continue

                # Extract JAR
                if name.startswith("SVAROG4/svarog-standalone") and name.endswith(".jar"):
                    out = dest / os.path.basename(name)
                    with zf.open(info) as src, open(out, "wb") as dst:
                        _copy_stream(src, dst)
                    jar_path = str(out)
                    logger.info("Installed %s", out)

                # Extract matching empi binary (keep original name)
                elif (f"empi-" in name and os_tag in name
                      and name.endswith(binary)):
                    out = dest / os.path.basename(name)
                    with zf.open(info) as src, open(out, "wb") as dst:
                        _copy_stream(src, dst)
                    # Make executable on Unix
                    if platform.system().lower() != "windows":
                        out.chmod(out.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)
                    # macOS: strip Gatekeeper's com.apple.quarantine
                    # xattr that gets attached to anything pulled
                    # over the network.  Without this, Svarog's first
                    # attempt to run empi can be blocked silently
                    # (Svarog logs an opaque error).  Best-effort —
                    # ignore failures (e.g. the xattr binary is on
                    # PATH but the file has no quarantine flag set).
                    if platform.system() == "Darwin":
                        try:
                            subprocess.run(
                                ["xattr", "-d",
                                 "com.apple.quarantine", str(out)],
                                check=False, capture_output=True)
                        except Exception:
                            pass
                    empi_path = str(out)
                    logger.info("Installed %s", out)

                # Windows empi also needs fftw3.dll
                elif (os_tag == "windows-x64"
                      and "windows-x64" in name
                      and name.endswith("fftw3.dll")):
                    out = dest / "fftw3.dll"
                    with zf.open(info) as src, open(out, "wb") as dst:
                        _copy_stream(src, dst)
                    logger.info("Installed %s", out)

        if not jar_path:
            raise RuntimeError("SVAROG JAR not found in artifact zip")
        return jar_path, empi_path

    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


# ── connectivis ───────────────────────────────────────────────────────

def download_connectivis(target_dir=None, progress_callback=None):
    """Download the latest connectivis artifact.

    Extracts ``connectivis.jar`` into *target_dir*
    (default ``~/.obci/connectivis/``).

    Parameters
    ----------
    target_dir : str or Path or None
        Override install directory.
    progress_callback : callable or None
        Called with ``(bytes_downloaded, total_bytes)`` during download.

    Returns
    -------
    str
        Path to the installed JAR.
    """
    dest = Path(target_dir) if target_dir else CONNECTIVIS_DIR
    dest.mkdir(parents=True, exist_ok=True)

    logger.info("Downloading connectivis from GitLab CI...")
    tmp_path = _download_zip(_CONNECTIVIS_URL, progress_callback)

    try:
        jar_path = None
        with zipfile.ZipFile(tmp_path) as zf:
            for info in zf.infolist():
                name = info.filename
                if name.startswith("/") or ".." in name:
                    continue
                if name.endswith("connectivis.jar"):
                    out = dest / "connectivis.jar"
                    with zf.open(info) as src, open(out, "wb") as dst:
                        _copy_stream(src, dst)
                    jar_path = str(out)
                    logger.info("Installed %s", out)
                    break

        if not jar_path:
            raise RuntimeError("connectivis.jar not found in artifact zip")
        return jar_path

    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


def _copy_stream(src, dst, bufsize=65536):
    """Copy file-like *src* to *dst* in chunks."""
    while True:
        chunk = src.read(bufsize)
        if not chunk:
            break
        dst.write(chunk)


# ── mpv ───────────────────────────────────────────────────────────────

#: Used for the cache-directory layout (``~/.obci/svarog/mpv/mpv-<v>-<os>/``)
#: and for the Windows SourceForge URL (which is content-addressed by
#: version).  The Linux URL is discovered at install time from the
#: pkgforge-dev/mpv-AppImage GitHub releases API — see
#: :func:`_resolve_mpv_url_linux` — because that project's tag scheme
#: mixes the version with an opaque per-release timestamp suffix
#: (e.g. ``v0.41.0@2026-05-01_1777638833``) that can't be hardcoded
#: stably.
_MPV_VERSION = "0.39.0"

#: Last-known-good Linux AppImage URL.  Used as fallback when the
#: GitHub API is unreachable (rate-limited / network down / corporate
#: firewall).  Bump this together with ``_MPV_VERSION`` whenever you
#: refresh the hardpin — a stale URL is better than nothing here, but
#: the API path is the primary one.
_MPV_LINUX_FALLBACK_URL = (
    "https://github.com/pkgforge-dev/mpv-AppImage/releases/download/"
    "v0.41.0%402026-05-01_1777638833/"
    "mpv-v0.41.0-anylinux-x86_64.AppImage"
)

#: Per-platform sources. Platforms not listed fall back to PATH —
#: see :func:`download_mpv`.
_MPV_SOURCES = {
    "linux-x64": {
        # ``url`` is resolved lazily via ``_resolve_mpv_url_linux``;
        # this entry exists only to mark the platform as supported.
        "format": "appimage",
    },
    "windows-x64": {
        "url": (
            "https://sourceforge.net/projects/mpv-player-windows/"
            f"files/release/mpv-{_MPV_VERSION}-x86_64.7z/download"
        ),
        "format": "7z",
    },
}

#: Override URL for the ``_os_tag()`` of the running machine. Honoured
#: regardless of platform — useful for behind-corporate-mirror setups
#: and for the test suite.
_MPV_URL_ENV = "IDE4EEG_MPV_URL"


def _resolve_mpv_url_linux():
    """Return the download URL for the latest Linux x86_64 AppImage.

    Queries ``https://api.github.com/repos/pkgforge-dev/mpv-AppImage/
    releases/latest`` for the asset whose name ends with
    ``anylinux-x86_64.AppImage`` (and isn't a ``.zsync`` companion).
    Falls back to :data:`_MPV_LINUX_FALLBACK_URL` if the API is
    unreachable or returns an unexpected payload — a stale hardpin
    is better than no install path on a flaky network.
    """
    import json
    api_url = ("https://api.github.com/repos/pkgforge-dev/"
               "mpv-AppImage/releases/latest")
    ctx = _certifi_ssl_context() or ssl.create_default_context()
    try:
        with _open_url(api_url, ctx) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        for asset in data.get("assets", []):
            name = asset.get("name", "")
            if (name.endswith("anylinux-x86_64.AppImage")
                    and not name.endswith(".zsync")):
                return asset["browser_download_url"]
        logger.warning(
            "GitHub release for pkgforge-dev/mpv-AppImage (%s) had no "
            "anylinux-x86_64 asset; falling back to hardpin.",
            data.get("tag_name", "?"))
    except Exception as exc:
        logger.warning(
            "Could not query GitHub for the latest pkgforge-dev/"
            "mpv-AppImage release (%s); falling back to hardpin.", exc)
    return _MPV_LINUX_FALLBACK_URL


def _mpv_dest_dir(target_dir=None):
    """``~/.obci/svarog/mpv/mpv-<version>-<platform>/``.

    Matches Svarog's ``VideoBackendFactory.findBundledMpv()`` resolver
    layout — binaries placed here are picked up automatically with no
    further coordination.
    """
    base = Path(target_dir) if target_dir else SVAROG_DIR / "mpv"
    return base / f"mpv-{_MPV_VERSION}-{_os_tag()}"


def _mpv_binary_path(target_dir=None):
    binary = "mpv.exe" if platform.system().lower() == "windows" else "mpv"
    return _mpv_dest_dir(target_dir) / binary


def download_mpv(target_dir=None, progress_callback=None, force=False,
                 confirm_brew_install=None):
    """Install a portable mpv binary at ``~/.obci/svarog/mpv/mpv-<v>-<platform>/``.

    Svarog's ``VideoBackendFactory`` looks for mpv at this exact
    location and uses it without further configuration.

    Platform coverage
    -----------------
    Linux x86_64
        Downloads the pkgforge-dev/mpv-AppImage release; chmods +x.
        Single-file portable, runs on any glibc-based distro.
    Windows x86_64
        Downloads the official mpv-player-windows 7z and extracts
        ``mpv.exe`` + bundled DLLs. Requires :mod:`py7zr` (pip-installable
        soft dependency); raises :class:`RuntimeError` if missing.
    macOS
        Portable mpv on macOS would require bundling ~30 dylibs from
        /opt/homebrew/lib and rewriting their rpaths — out of scope.
        Instead we delegate to Homebrew when the user explicitly
        consents (see ``confirm_brew_install``):

        1. If ``mpv`` is already on ``PATH``, return that path.
        2. If Homebrew is detected and ``confirm_brew_install`` returns
           True, run ``brew install mpv`` and return the resulting
           binary path.
        3. Otherwise return ``None``; Svarog's resolver still finds a
           PATH-installed mpv, and falls back to JavaFX if there is
           none.

    Caching: an executable binary at the destination short-circuits
    the download (``force=True`` overrides).

    Parameters
    ----------
    target_dir : path or None
        Override the parent directory; defaults to ``~/.obci/svarog/mpv/``.
    progress_callback : callable or None
        Receives ``(bytes_downloaded, total_bytes)`` updates during
        download (same shape as ``download_svarog``).
    force : bool
        Re-download even if a cached binary exists.
    confirm_brew_install : callable(brew_path) -> bool, or None
        macOS-only consent hook. When mpv is missing but Homebrew is
        present, this is called with the brew binary path; returning
        ``True`` authorises ``brew install mpv``. ``None`` (the default)
        means *do not run brew*, even if it would work — auto-install
        requires explicit consent. Has no effect on Linux/Windows.

    Returns
    -------
    str or None
        Path to the installed mpv binary, or ``None`` if auto-install
        is unsupported on this platform.
    """
    os_tag = _os_tag()
    if os_tag.startswith("macos"):
        return _download_mpv_macos(confirm_brew_install)

    src_cfg = _MPV_SOURCES.get(os_tag)
    if src_cfg is None:
        logger.info("download_mpv: no source configured for %s", os_tag)
        return None

    url = os.environ.get(_MPV_URL_ENV)
    if url is None:
        if os_tag == "linux-x64":
            url = _resolve_mpv_url_linux()
        else:
            url = src_cfg["url"]
    dest_dir = _mpv_dest_dir(target_dir)
    cached = _mpv_binary_path(target_dir)
    if not force and cached.is_file() and os.access(cached, os.X_OK):
        logger.debug("download_mpv: using cached %s", cached)
        return str(cached)

    dest_dir.mkdir(parents=True, exist_ok=True)

    fmt = src_cfg["format"]
    if fmt == "appimage":
        _install_mpv_appimage(url, cached, progress_callback)
    elif fmt == "7z":
        _install_mpv_7z(url, dest_dir, progress_callback)
    else:
        raise RuntimeError(f"Unknown mpv source format: {fmt}")

    if not cached.is_file():
        raise RuntimeError(
            f"mpv install completed but expected binary missing: {cached}"
        )
    return str(cached)


def _install_mpv_appimage(url, dest_path, progress_callback):
    """Linux: download a single-file AppImage to *dest_path* and chmod +x."""
    import shutil
    tmp = _download_zip(url, progress_callback)
    try:
        shutil.move(tmp, str(dest_path))
    except Exception:
        try: os.remove(tmp)
        except OSError: pass
        raise
    dest_path.chmod(
        dest_path.stat().st_mode
        | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
    )
    logger.info("Installed mpv (AppImage): %s", dest_path)


def _install_mpv_7z(url, dest_dir, progress_callback):
    """Windows: download a 7z archive and extract its contents flat into *dest_dir*."""
    try:
        import py7zr
    except ImportError as exc:
        raise RuntimeError(
            "Auto-install of mpv on Windows requires py7zr.\n"
            "Install with:  pip install py7zr\n"
            "Or install mpv manually and put it on PATH."
        ) from exc

    tmp = _download_zip(url, progress_callback)
    try:
        with py7zr.SevenZipFile(tmp, mode="r") as archive:
            # mpv-player-windows packs everything (mpv.exe, mpv.com, dlls,
            # subdirs) at the archive root — extract straight into dest_dir.
            archive.extractall(path=str(dest_dir))
    finally:
        try: os.remove(tmp)
        except OSError: pass
    logger.info("Installed mpv (Windows 7z): %s", dest_dir)


# ── macOS auto-install via Homebrew ───────────────────────────────────
#
# macOS portable mpv requires bundling ~30 dylibs from /opt/homebrew/lib
# and rewriting their LC_LOAD_DYLIB rpaths with install_name_tool, then
# re-codesigning. That's a maintenance trap we don't want to take on for
# every mpv release. Instead, when mpv is missing on macOS we delegate
# to Homebrew if the user explicitly consents — brew handles linking,
# updates, and codesigning, and the result lands on the system PATH so
# Svarog's resolver picks it up automatically.
#
# Consent is required because brew installs touch global state (writes
# under /opt/homebrew or /usr/local). The GUI surfaces a dialog and
# only passes a True-returning callback if the user clicks OK.

_BREW_PATHS = (
    "/opt/homebrew/bin/brew",  # Apple Silicon default
    "/usr/local/bin/brew",     # Intel default
)


def _macos_brew_path():
    """Locate the Homebrew binary, or return ``None`` if not installed.

    Checks the two default install prefixes first (most common case),
    then falls back to ``shutil.which`` to catch Linuxbrew or non-default
    install locations on someone's ``$PATH``.
    """
    for candidate in _BREW_PATHS:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return shutil.which("brew")


def _frozen_bundled_mpv():
    """Probe the mpv shipped inside a frozen .exe / .app full bundle.

    Returns the absolute path if found and executable, else ``None``.
    Layout per packaging spec:
      - macOS (py2app):  <.app>/Contents/Resources/mpv/Contents/MacOS/mpv
      - Windows (PyInstaller, one-folder): <exe_dir>/mpv/mpv.exe
    Lite builds omit the ``mpv/`` subtree — function returns ``None``.
    """
    if not getattr(sys, "frozen", False):
        return None
    if sys.platform == "darwin":
        cand = Path(
            os.path.dirname(os.path.dirname(sys.executable))
        ) / "Resources" / "mpv" / "Contents" / "MacOS" / "mpv"
    elif sys.platform == "win32":
        cand = Path(os.path.dirname(sys.executable)) / "mpv" / "mpv.exe"
    else:
        return None
    if cand.is_file() and os.access(cand, os.X_OK):
        return str(cand)
    return None


def find_installed_mpv():
    """Return the path of an mpv binary IDE4EEG / Svarog can use,
    or ``None``.

    Resolution order:

    1. Bundled binary inside a frozen full .exe / .app — IDE4EEG-full
       ships mpv next to the executable.  Probed first so frozen
       users never depend on system PATH or user-installed copies.
    2. Canonical user-cache location (``~/.obci/svarog/mpv/...``) —
       what :func:`download_mpv` populates on Linux / Windows.
    3. System install via ``shutil.which("mpv")`` — covers Homebrew
       on macOS, distro packages on Linux, manual installs anywhere.
    4. ``None`` — Svarog will fall back to JavaFX (MP4 only) or
       VLC (if the user installed it system-wide).

    Cheap pure-disk probe; does not run ``mpv``, does not call any
    GitLab API.  Safe to call repeatedly from a GUI refresh.
    """
    bundled = _frozen_bundled_mpv()
    if bundled:
        return bundled
    cached = _mpv_binary_path()
    if cached.is_file() and os.access(cached, os.X_OK):
        return str(cached)
    sys_mpv = shutil.which("mpv")
    if sys_mpv:
        return sys_mpv
    return None


def macos_mpv_status():
    """Detect mpv install state on macOS.

    Designed to be called from the GUI thread *before* invoking
    :func:`download_mpv`, so the user can be prompted (on the main
    thread) about whether to run ``brew install mpv``.

    Returns
    -------
    (status, detail) : tuple
        - ``("installed", path)`` — mpv is on PATH; nothing to do.
        - ``("brew-available", brew_path)`` — Homebrew is present and
          can install mpv with explicit user consent.
        - ``("no-brew", None)`` — mpv is missing and there's no
          installer; user must install mpv manually.
        - ``("not-applicable", None)`` — running on a non-macOS
          platform; check Linux/Windows behaviour instead.
    """
    if not _os_tag().startswith("macos"):
        return ("not-applicable", None)
    mpv = shutil.which("mpv")
    if mpv:
        return ("installed", mpv)
    brew = _macos_brew_path()
    if brew:
        return ("brew-available", brew)
    return ("no-brew", None)


def _download_mpv_macos(confirm_brew_install):
    """macOS install path. See :func:`download_mpv` for semantics."""
    # Frozen builds never touch Homebrew — system-mutating installs
    # are out of scope for the bundled distribution.  Full-frozen
    # bundles ship mpv inside the .app, lite-frozen tells the user
    # to grab the full variant; neither needs brew.
    if getattr(sys, 'frozen', False):
        logger.info(
            "Frozen build: skipping macOS brew-install of mpv. "
            "For synced video playback, install the IDE4EEG-full "
            "variant from %s",
            FROZEN_RELEASES_URL,
        )
        return None
    status, detail = macos_mpv_status()
    if status == "installed":
        logger.info("mpv already on PATH at %s; using system install", detail)
        return detail
    if status == "no-brew":
        logger.info(
            "mpv not on PATH and Homebrew not detected; "
            "user must install mpv manually (Svarog will fall back to JavaFX)"
        )
        return None
    # status == "brew-available"
    brew_path = detail
    if confirm_brew_install is None:
        logger.info(
            "mpv missing; Homebrew available at %s but no consent "
            "callback was provided — skipping auto-install",
            brew_path,
        )
        return None
    try:
        consent = bool(confirm_brew_install(brew_path))
    except Exception as exc:
        logger.warning(
            "confirm_brew_install raised %s; treating as decline",
            exc.__class__.__name__,
        )
        return None
    if not consent:
        logger.info("User declined brew install of mpv")
        return None
    return _macos_brew_install_mpv(brew_path)


def _macos_brew_install_mpv(brew_path):
    """Run ``brew install mpv`` and return the resulting binary path.

    Returns ``None`` (with a logged error) on any failure mode:
    timeout, non-zero exit, or missing binary after a clean run.
    """
    # Belt-and-suspenders: _download_mpv_macos already short-circuits
    # frozen builds before reaching here, but block direct callers too.
    if getattr(sys, 'frozen', False):
        logger.info(
            "Frozen build: refusing to run %s install mpv. "
            "Download the IDE4EEG-full variant from %s instead.",
            brew_path, FROZEN_RELEASES_URL,
        )
        return None
    logger.info("Running %s install mpv ...", brew_path)
    try:
        proc = subprocess.run(
            [brew_path, "install", "mpv"],
            capture_output=True,
            text=True,
            timeout=600,
        )
    except subprocess.TimeoutExpired:
        logger.error("brew install mpv timed out after 10 minutes")
        return None
    except OSError as exc:
        logger.error("Failed to launch %s: %s", brew_path, exc)
        return None
    if proc.returncode != 0:
        logger.error(
            "brew install mpv failed (exit %d)\nstdout:\n%s\nstderr:\n%s",
            proc.returncode, proc.stdout, proc.stderr,
        )
        return None
    # Re-resolve mpv: brew installs into <prefix>/bin/, but a brand-new
    # brew install may not yet be on this Python's $PATH (caching).
    mpv = shutil.which("mpv")
    if mpv:
        logger.info("brew install mpv succeeded: %s", mpv)
        return mpv
    prefix = os.path.dirname(os.path.dirname(brew_path))  # /opt/homebrew
    candidate = os.path.join(prefix, "bin", "mpv")
    if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
        logger.info("brew install mpv succeeded: %s", candidate)
        return candidate
    logger.error(
        "brew install mpv reported success but mpv binary not found "
        "(checked PATH and %s)", candidate,
    )
    return None


# ── Java detection + per-platform install plan ────────────────────────
#
# Java is integral to the IDE4EEG GUI workflow (Svarog + ConnectiVIS +
# every interactive review window). The Download Recent button checks
# for a usable JVM and helps the user install one when it's missing.
# Auto-install paths exist on macOS (brew) and Windows (winget); on
# Linux we only print the right command for the detected package
# manager because every install path needs sudo. Detection is
# always pure (no subprocess writes).

#: Minimum Java major version IDE4EEG accepts. Java 8 is the floor
#: because Svarog is a Swing app that runs on any modern JVM.
_MIN_JAVA_MAJOR = 8

#: Subprocess timeout for ``brew install`` / ``winget install``.
#: 15 minutes covers a 200 MB JDK download plus macOS Gatekeeper
#: notarization and Windows Defender real-time scanning of the
#: extracted tree.
_INSTALL_TIMEOUT_SEC = 900


def _parse_java_version(text):
    """Parse ``java -version`` output. Returns ``(major, version_str)``
    or ``(None, None)`` when the text is unrecognisable.

    Handles both the modern ``openjdk version "17.0.9"`` form and the
    Java-8 legacy ``java version "1.8.0_392"`` form (where the real
    major is 8, not 1).
    """
    import re as _re
    m = _re.search(r'version "(\d+)(?:\.(\d+))?(?:[._]\d+)*"', text)
    if not m:
        return (None, None)
    first = int(m.group(1))
    major = int(m.group(2)) if first == 1 and m.group(2) else first
    short = _re.search(r'version "([^"]+)"', text)
    return (major, short.group(1) if short else str(major))


def detect_java():
    """Return ``(status, detail)`` describing the Java install on PATH.

    Status values:

    - ``"ok"``       — Java major ≥ 8; ``detail`` is the full version
                        line for logs/dialogs (e.g. ``'17.0.9'``).
    - ``"too-old"``  — Java present but major < 8; ``detail`` is the
                        major version as int.
    - ``"missing"``  — no ``java`` on PATH; ``detail`` is ``None``.

    Pure: never installs anything, only invokes ``java -version`` with
    a 5 s timeout. Safe to call from the GUI thread.
    """
    try:
        out = subprocess.run(
            ["java", "-version"],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, OSError):
        return ("missing", None)
    except subprocess.TimeoutExpired:
        logger.warning("java -version timed out after 5s")
        return ("missing", None)
    major, version_str = _parse_java_version(
        (out.stderr or "") + (out.stdout or ""))
    if major is None:
        return ("missing", None)
    if major < _MIN_JAVA_MAJOR:
        return ("too-old", major)
    return ("ok", version_str)


#: Linux package-manager → install command. Order matters: the first
#: detected manager wins. ``apt`` first because it covers the vast
#: majority of EEG-research desktops (Debian / Ubuntu / derivatives).
_LINUX_PKG_MANAGERS = (
    ("apt",     "sudo apt install openjdk-17-jdk"),
    ("dnf",     "sudo dnf install java-17-openjdk-devel"),
    ("zypper",  "sudo zypper install java-17-openjdk-devel"),
    ("pacman",  "sudo pacman -S jdk17-openjdk"),
)


def _linux_pkg_install_cmd():
    """Return ``(pkg_mgr, install_cmd)`` for the user's distro, or
    ``(None, None)`` if no known manager is on PATH."""
    for name, cmd in _LINUX_PKG_MANAGERS:
        if shutil.which(name):
            return (name, cmd)
    return (None, None)


def _windows_winget_path():
    """Return the path to ``winget.exe`` if available, else ``None``.

    winget ships with Windows 10 1809+ / Windows 11 by default but
    isn't always on every shell's ``%PATH%`` — fall back to the
    canonical install location under ``%LOCALAPPDATA%\\Microsoft``.
    """
    found = shutil.which("winget")
    if found:
        return found
    local = os.environ.get("LOCALAPPDATA", "")
    if local:
        candidate = os.path.join(
            local, "Microsoft", "WindowsApps", "winget.exe")
        if os.path.isfile(candidate):
            return candidate
    return None


def java_install_plan():
    """Inspect the system and return a plan for getting Java installed.

    Returns ``(mode, detail)`` where ``mode`` is one of:

    - ``"ok"`` — already installed; ``detail`` is the version string.
    - ``"auto-mac"`` — ``brew install --cask temurin`` is available;
      ``detail`` is ``(brew_path, install_cmd_str)``.
    - ``"auto-windows"`` — winget is available; ``detail`` is
      ``(winget_path, install_cmd_str)``.
    - ``"manual-linux"`` — known package manager detected; ``detail``
      is ``(pkg_mgr_name, install_cmd_str)`` for the user to run with
      sudo. We never run sudo for them.
    - ``"manual-mac"`` — macOS without Homebrew; ``detail`` is the
      adoptium URL.
    - ``"manual-windows"`` — Windows without winget; ``detail`` is the
      adoptium URL.
    - ``"manual-linux-unknown"`` — Linux without a recognised package
      manager; ``detail`` is the adoptium URL.

    Pure: only inspects ``$PATH`` and known install locations.
    """
    status, info_detail = detect_java()
    if status == "ok":
        return ("ok", info_detail)
    # Frozen bundles ship a JRE next to the executable; if PATH
    # detection failed, fall back to that before suggesting any
    # system-mutating install path.  Reported as "ok" so callers
    # don't prompt for an install we don't need.
    if getattr(sys, 'frozen', False):
        plat_frozen = platform.system()
        bundled = (_macos_find_temurin_java() if plat_frozen == "Darwin"
                   else _windows_find_temurin_java() if plat_frozen == "Windows"
                   else None)
        if bundled:
            return ("ok", f"bundled JRE at {bundled}")
    # missing or too-old: figure out the install path
    plat = platform.system()
    if plat == "Darwin":
        # In frozen builds we never suggest brew — the bundle is
        # supposed to be self-contained.  Fall through to the
        # manual-mac branch which the GUI gates into a "use the
        # full variant" message in lite-frozen.
        if not getattr(sys, 'frozen', False):
            brew = _macos_brew_path()
            if brew:
                return ("auto-mac",
                        (brew, f"{brew} install --cask temurin"))
        return ("manual-mac", "https://adoptium.net")
    if plat == "Windows":
        if not getattr(sys, 'frozen', False):
            winget = _windows_winget_path()
            if winget:
                cmd = (f"{winget} install --scope user "
                       f"EclipseAdoptium.Temurin.17.JDK")
                return ("auto-windows", (winget, cmd))
        return ("manual-windows", "https://adoptium.net")
    # Linux (and BSDs, treated the same)
    pkg_mgr, cmd = _linux_pkg_install_cmd()
    if pkg_mgr:
        return ("manual-linux", (pkg_mgr, cmd))
    return ("manual-linux-unknown", "https://adoptium.net")


def _macos_brew_install_java(brew_path):
    """Run ``brew install --cask temurin`` and return success."""
    # Frozen builds bundle a JRE under <bundle>.app/Contents/
    # Frameworks/jre/ — brew-installing Java would be dead code at
    # best and a system-mutating side effect at worst.  Skip silently
    # so install_java() can pick up the bundled JRE via
    # _macos_find_temurin_java's frozen-bundle branch.
    if getattr(sys, 'frozen', False):
        logger.info(
            "Frozen build: skipping brew install --cask temurin "
            "(JRE is bundled under <bundle>/Contents/Frameworks/jre/).")
        return False
    cmd = [brew_path, "install", "--cask", "temurin"]
    logger.info("Running %s ...", " ".join(cmd))
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=_INSTALL_TIMEOUT_SEC)
    except subprocess.TimeoutExpired:
        logger.error("brew install --cask temurin timed out")
        return False
    except OSError as exc:
        logger.error("Failed to launch %s: %s", brew_path, exc)
        return False
    if proc.returncode != 0:
        logger.error(
            "brew install --cask temurin failed (exit %d)\n"
            "stdout:\n%s\nstderr:\n%s",
            proc.returncode, proc.stdout, proc.stderr,
        )
        return False
    logger.info("brew install --cask temurin succeeded")
    return True


def _windows_find_temurin_java():
    """Locate a usable ``java.exe`` on Windows.

    When running from a PyInstaller-frozen build (``sys.frozen``), we
    first check for a bundled JRE under
    ``<install_dir>/jre/bin/java.exe`` (or ``javaw.exe``) — the
    frozen .exe ships an Adoptium Temurin 17 JRE so Svarog/empi/
    ConnectiVIS launches work without the user installing Java
    separately.

    Otherwise (or if the bundled JRE isn't present/verified), probe
    the canonical winget install location after
    ``winget install --scope user EclipseAdoptium.Temurin.17.JDK``.

    winget updates the user-scope ``PATH`` in the registry, but the
    running Python process holds a snapshot of ``os.environ`` from
    startup — so ``shutil.which("java")`` will still miss a brand-new
    install until the GUI is restarted. Probing the install directory
    directly bypasses that staleness.

    Frozen-bundle branch: PyInstaller lays out
    ``dist/ide4eeg-lite/ide4eeg-lite.exe`` next to
    ``dist/ide4eeg-lite/jre/`` (and the .app analogue on macOS), so
    the bundled JRE lives at ``<exe_dir>/jre/bin/java.exe``.  Check
    that first when running frozen — it's the only Java the bundle
    is allowed to assume exists.

    Returns the path to a verified ``java.exe`` or ``None``.
    """
    if getattr(sys, 'frozen', False):
        bundled = os.path.join(
            os.path.dirname(sys.executable),
            "jre", "bin", "java.exe")
        if _verify_java_path(bundled):
            return bundled
    import glob
    # Frozen-build bundled JRE takes priority.
    if getattr(sys, "frozen", False):
        install_dir = os.path.dirname(sys.executable)
        for exe_name in ("java.exe", "javaw.exe"):
            candidate = os.path.join(install_dir, "jre", "bin", exe_name)
            if os.path.isfile(candidate) and _verify_java_path(candidate):
                logger.info("Using bundled JRE at %s", candidate)
                return candidate
    local = os.environ.get("LOCALAPPDATA", "")
    if not local:
        return None
    pattern = os.path.join(
        local, "Programs", "Eclipse Adoptium", "jdk-*",
        "bin", "java.exe")
    matches = glob.glob(pattern)
    if not matches:
        return None
    # Newest version typically sorts last lexically (jdk-17.0.9 <
    # jdk-21.0.2). Not bulletproof but good enough.
    matches.sort()
    return matches[-1]


def _macos_find_temurin_java():
    """Probe the bundled JRE inside a frozen macOS .app, if any.

    py2app lays the .app out as::

        <Bundle>.app/Contents/MacOS/<exe>
        <Bundle>.app/Contents/Frameworks/jre/bin/java

    so from ``sys.executable`` (``…/Contents/MacOS/<exe>``) the JRE
    is reached via ``..`` (Contents) + ``Frameworks/jre/bin/java``.
    Returns the verified path or ``None``.  For non-frozen macOS we
    return ``None`` — there is no canonical user-scope install
    location to probe (brew installs land on ``$PATH`` directly,
    where ``detect_java()`` already finds them).
    """
    if not getattr(sys, 'frozen', False):
        return None
    contents = os.path.dirname(os.path.dirname(sys.executable))
    bundled = os.path.join(contents, "Frameworks", "jre", "bin", "java")
    if _verify_java_path(bundled):
        return bundled
    return None


def _verify_java_path(java_path):
    """Run ``<java_path> -version`` and return the version string, or
    ``None`` if the binary doesn't work or its version is below the
    floor. Bypasses ``$PATH`` so it's safe to call right after an
    auto-install.
    """
    try:
        out = subprocess.run(
            [java_path, "-version"],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        return None
    major, version_str = _parse_java_version(
        (out.stderr or "") + (out.stdout or ""))
    if major is None or major < _MIN_JAVA_MAJOR:
        return None
    return version_str


def _windows_winget_install_java(winget_path):
    """Run ``winget install --scope user EclipseAdoptium.Temurin.17.JDK``
    and return success.

    User-scope install avoids the UAC prompt — Temurin's winget package
    supports both scopes and the user-scope install lands in
    ``%LOCALAPPDATA%\\Programs\\Eclipse Adoptium\\``."""
    cmd = [winget_path, "install", "--scope", "user",
           "--accept-package-agreements", "--accept-source-agreements",
           "EclipseAdoptium.Temurin.17.JDK"]
    logger.info("Running %s ...", " ".join(cmd))
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=_INSTALL_TIMEOUT_SEC)
    except subprocess.TimeoutExpired:
        logger.error("winget install timed out")
        return False
    except OSError as exc:
        logger.error("Failed to launch %s: %s", winget_path, exc)
        return False
    if proc.returncode != 0:
        logger.error(
            "winget install Temurin failed (exit %d)\n"
            "stdout:\n%s\nstderr:\n%s",
            proc.returncode, proc.stdout, proc.stderr,
        )
        return False
    logger.info("winget install Temurin succeeded")
    return True


def install_java(confirm_callback=None, plan=None):
    """Top-level Java installer for the GUI's Download Recent flow.

    Returns one of:

    - ``("ok", version_str)`` — Java was already installed; nothing
      to do.
    - ``("installed", version_str)`` — auto-install ran and a usable
      Java is now on PATH.
    - ``("declined", (plan, detail))`` — user said no, or the platform
      requires manual install.
    - ``("failed", error_str)`` — auto-install ran but Java still not
      detected afterwards.

    Parameters
    ----------
    confirm_callback : callable() -> bool, or None
        Consent hook. The GUI must show its consent dialog on the main
        thread *before* this function runs in a worker thread, then
        pass a thunk returning the user's choice.  ``None`` is treated
        as decline. Mirrors :func:`download_mpv`'s
        ``confirm_brew_install``.
    plan : tuple, optional
        Pre-computed result of :func:`java_install_plan`. The GUI
        already calls that on the main thread to build the consent
        dialog; threading it back in here saves a duplicate
        ``java -version`` subprocess.
    """
    if plan is None:
        plan_name, detail = java_install_plan()
    else:
        plan_name, detail = plan
    if plan_name == "ok":
        return ("ok", detail)
    if confirm_callback is None:
        return ("declined", (plan_name, detail))
    # Auto paths: get consent, run installer.
    auto_installers = {
        "auto-mac": _macos_brew_install_java,
        "auto-windows": _windows_winget_install_java,
    }
    installer = auto_installers.get(plan_name)
    if installer is None:
        # manual-linux / manual-mac / manual-windows /
        # manual-linux-unknown — caller shows install instructions.
        return ("declined", (plan_name, detail))
    try:
        consented = bool(confirm_callback())
    except Exception as exc:
        logger.warning(
            "confirm_callback raised %s; treating as decline",
            exc.__class__.__name__)
        return ("declined", (plan_name, detail))
    if not consented:
        return ("declined", (plan_name, detail))
    binary_path = detail[0]  # (brew_path, _cmd) or (winget_path, _cmd)
    if not installer(binary_path):
        return ("failed", f"{plan_name} install failed; "
                          f"see log for details")
    # Auto-install path: re-detect to confirm. macOS works via
    # /usr/bin/java's java_home stub (always on PATH, auto-discovers
    # the new JDK). Windows hits PATH staleness — the registry is
    # updated but our process holds a snapshot, so probe the canonical
    # install directory directly.
    status, info_detail = detect_java()
    if status == "ok":
        return ("installed", info_detail)
    if plan_name == "auto-windows":
        probe = _windows_find_temurin_java()
        if probe:
            version = _verify_java_path(probe)
            if version:
                return ("installed",
                        f"{version} at {probe} — restart the GUI "
                        f"so Python's PATH picks it up")
    if plan_name == "auto-mac":
        probe = _macos_find_temurin_java()
        if probe:
            version = _verify_java_path(probe)
            if version:
                return ("installed",
                        f"{version} at {probe} — restart the GUI "
                        f"so Python's PATH picks it up")
    return ("failed", "install reported success but no Java detected "
                      "afterwards — try restarting the GUI")


# ── L2CS-Net eye-gaze stack (PyTorch + l2cs + Gaze360 weights) ────────
#
# Three independent on-demand pulls:
#   1. PyTorch from PyPI via pip install torch torchvision (~500 MB
#      on macOS / Linux-CPU wheels, up to ~2 GB on Linux-CUDA)
#   2. L2CS Python package (~few hundred KB) from GitHub fork via pip
#   3. L2CSNet_gaze360.pkl weights (~96 MB) from the IDE4EEG GitLab
#      Releases asset via stdlib urllib — handled inside
#      l2cs_gaze._download_weights().  Mirror of the upstream
#      MIT-licensed Ahmednull/L2CS-Net checkpoint; see
#      facetag/models/L2CSNet_gaze360.LICENSE for attribution.
# Default install keeps all three out — most users use InsightFace
# face detection + head-pose fallback gaze and never need L2CS.

L2CS_GIT_URL = (
    "l2cs @ git+https://github.com/Ahmednull/L2CS-Net.git@main"
)
# Backwards-compat alias for legacy callers in this module.
_L2CS_GIT_URL = L2CS_GIT_URL


def l2cs_missing_deps():
    """Return missing L2CS Python deps as a subset of ``["torch", "l2cs"]``.

    Both packages are required for the L2CS gaze backend: ``torch``
    powers the model itself; ``l2cs`` ships the architecture
    definition (``getArch``) imported at model-load time.  Use
    ``find_spec`` rather than importing — torch's first import is
    a 1–3 s cost we don't want to pay just to update a button label
    or refresh a missing-deps indicator.

    Survives in-process uninstall: see
    :func:`ide4eeg.install_diagnostics._is_pkg_importable` — for
    an already-loaded module we check whether ``__file__`` still
    exists on disk instead of popping it (popping torch crashes
    the next ``import torch`` because torch has process-singleton
    ``TORCH_LIBRARY`` registrations that can't run twice).
    """
    from ide4eeg.install_diagnostics import _is_pkg_importable
    return [m for m in ("torch", "l2cs")
            if not _is_pkg_importable(m)]


def _l2cs_torch_present():
    return "torch" not in l2cs_missing_deps()


def _l2cs_pkg_present():
    return "l2cs" not in l2cs_missing_deps()


L2CS_WEIGHTS_FNAME = "L2CSNet_gaze360.pkl"


def _legacy_in_package_l2cs_weights_path():
    """Where the weights file used to live, inside the package tree.

    Kept for one-time migration: if a user upgrades from a version
    that stored weights here, :func:`migrate_legacy_paths` moves
    the file to the new ``~/.obci/ide4eeg/models/`` location.
    """
    here = os.path.dirname(__file__)
    return os.path.join(
        here, "preprocessing", "facetag", "models",
        L2CS_WEIGHTS_FNAME,
    )


def canonical_l2cs_weights_path():
    """Where the weights file lives now: ``~/.obci/ide4eeg/models/``.

    Computed without importing ``l2cs_gaze`` (whose module body
    imports cv2, ~200 ms).  The location is fixed; the only
    override is the GUI-only ``set_weights_path`` for testing.
    """
    return str(IDE4EEG_MODELS_DIR / L2CS_WEIGHTS_FNAME)


def migrate_legacy_paths():
    """Move runtime data from old in-package / upstream locations
    to the consolidated ``~/.obci/ide4eeg/`` tree.

    Runs once per process from :mod:`ide4eeg.__init__`.  Idempotent
    — no-op when the migrations are already done.

    Migrations performed:

    1. **L2CS weights** — ``<package>/preprocessing/facetag/models/
       L2CSNet_gaze360.pkl`` → ``~/.obci/ide4eeg/models/...``
    2. **InsightFace models** — ``~/.insightface/models/`` →
       ``~/.obci/ide4eeg/insightface/models/``
    3. **Example data** — ``~/.obci/ide4eeg/examples/`` →
       ``~/IDE4EEG_examples/``.  Reason: the pipeline's default
       ``output_path`` is the parent of the input file, so leaving
       examples under ``~/.obci/`` made every analysis write
       ``IDE4EEG_OUT_*`` directories into the OBCI cache tree.

    Migration uses an atomic same-disk rename when possible.  Cross-
    disk moves or permission errors are caught and logged; the
    legacy location stays put so nothing is lost.
    """
    _migrate_path(
        Path(_legacy_in_package_l2cs_weights_path()),
        Path(canonical_l2cs_weights_path()),
        label="L2CS weights",
        fallback_hint="leaving legacy file in place.",
    )
    new_if = INSIGHTFACE_ROOT / "models"
    _migrate_path(
        Path.home() / ".insightface" / "models",
        new_if,
        label="InsightFace models",
        fallback_hint=(
            f"will fall back to {new_if} for new downloads."),
        clean_old_parent=True,
    )
    new_ex = Path.home() / "IDE4EEG_examples"
    _migrate_path(
        IDE4EEG_DATA_DIR / "examples",
        new_ex,
        label="example data",
        fallback_hint=(
            f"will fall back to {new_ex} for new downloads."),
    )


def _migrate_path(old: Path, new: Path, *, label: str,
                  fallback_hint: str,
                  clean_old_parent: bool = False) -> None:
    """Atomic rename ``old`` → ``new`` for :func:`migrate_legacy_paths`.

    No-op when ``old`` doesn't exist or ``new`` is already present
    (idempotent across runs).  Both file and directory ``old`` paths
    are supported.  Cross-disk / permission failures are logged at
    WARNING with ``fallback_hint`` appended so callers know what to
    expect next.
    """
    if not (old.is_file() or old.is_dir()):
        return
    if new.exists():
        return
    try:
        new.parent.mkdir(parents=True, exist_ok=True)
        old.rename(new)
        logger.info("Migrated %s %s → %s", label, old, new)
        if clean_old_parent:
            try:
                old.parent.rmdir()
            except OSError:
                pass
    except OSError as exc:
        logger.warning(
            "Could not migrate %s from %s to %s: %s; %s",
            label, old, new, exc, fallback_hint)


def is_l2cs_stack_installed(weights_path=None):
    """``(torch_ok, l2cs_pkg_ok, weights_ok)`` triple.

    ``weights_path`` overrides the canonical location for the
    weights existence check — pass the GUI's current edit text so
    the button state tracks the user's override.
    """
    wpath = weights_path or canonical_l2cs_weights_path()
    return (
        _l2cs_torch_present(),
        _l2cs_pkg_present(),
        os.path.isfile(wpath),
    )


def download_l2cs_weights(target_dir=None):
    """Download the L2CS Gaze360 weights file from GitLab Releases.

    Pulls the ~96 MB MIT-mirrored checkpoint via stdlib urllib —
    no third-party download library, no Drive rate limit.
    ``target_dir`` overrides the default
    (``ide4eeg/preprocessing/facetag/models/``); useful when the user
    wants to keep the blob outside the package tree.
    """
    from ide4eeg.preprocessing.facetag.l2cs_gaze import _download_weights
    return _download_weights(target_dir=target_dir)
