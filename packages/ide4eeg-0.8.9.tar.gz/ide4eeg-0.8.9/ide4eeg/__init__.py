# Ensure "spawn" start method for multiprocessing — required on Linux
# where the default "fork" crashes with Qt. macOS already uses "spawn"
# by default since Python 3.8. Must run before any multiprocessing use.
#
# Only touch the start method from the main process: child processes
# (e.g. joblib/loky workers) re-import this package during unpickling
# and calling set_start_method there raises "context has already been
# set" even when the context is already spawn (the guard below can't
# tell the difference in a spawned child, because the child never
# explicitly called set_start_method itself — see
# https://docs.python.org/3/library/multiprocessing.html#contexts-and-start-methods).
import multiprocessing as _mp
_is_main = _mp.current_process().name == "MainProcess"
if _is_main:
    if _mp.get_start_method(allow_none=True) != "spawn":
        _mp.set_start_method("spawn")

# Once-per-process migration of runtime data from old in-package /
# upstream locations to the consolidated ~/.obci/ide4eeg/ tree.
# Idempotent — silently no-ops when nothing to migrate.  Done eagerly
# at import time so subsequent code (insightface_backend, l2cs_gaze)
# sees the consolidated paths regardless of import order.  Skipped in
# child processes (joblib/loky workers) because they inherit the
# already-migrated state from the parent.
if _is_main:
    try:
        from ide4eeg.download_tools import migrate_legacy_paths
        migrate_legacy_paths()
    except Exception as _exc:
        # Per-step rename failures are caught + logged inside
        # migrate_legacy_paths; this outer except covers anything
        # broader (e.g. ImportError on a malformed download_tools).
        # Log a warning so a real bug doesn't get silently swallowed.
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "Path migration skipped: %s: %s",
            type(_exc).__name__, _exc)
        del _logging, _exc

del _mp, _is_main

# Frozen-only PATH injection for bundled video tools (macOS .app).
# SVAROG spawns `ffmpeg` and `mpv` via Java's Runtime.exec, which
# inherits this process's environment.  Launchd hands the .app a
# minimal PATH (no /opt/homebrew/bin etc.), so without this prepend
# SVAROG hits its hardcoded "ffmpeg is required to play video files"
# preflight dialog even on machines where the bundled binaries are
# right inside the .app.
import sys as _sys
import os as _os
if getattr(_sys, "frozen", False) and _sys.platform == "darwin":
    _bundle_res = _os.path.join(
        _os.path.dirname(_os.path.dirname(_sys.executable)), "Resources")
    _extra = [
        _os.path.join(_bundle_res, "mpv", "Contents", "MacOS"),
        _os.path.join(_bundle_res, "ffmpeg"),
    ]
    _extra = [p for p in _extra if _os.path.isdir(p)]
    if _extra:
        _os.environ["PATH"] = (
            _os.pathsep.join(_extra) + _os.pathsep + _os.environ.get("PATH", ""))
    del _bundle_res, _extra
del _sys, _os

__version__ = "0.8.9"

#: Prefix used for per-recording output directories.
#: Layout: ``<output_root>/<OUTPUT_DIR_PREFIX><filename_core>/{preprocessing,analysis}/``
#: Single source of truth — pipeline writers and GUI viewers should
#: reference this rather than the literal string.
OUTPUT_DIR_PREFIX = "IDE4EEG_OUT_"

#: Sentinel value for ``config["electrodes_layout"]`` meaning
#: "use the 3D positions already in the file, don't apply a
#: standard montage".  Auto-set by the preprocessing step when
#: native positions are detected; exposed as a selectable combobox
#: item in the GUI.
NATIVE_POSITIONS_SENTINEL = "native (from file)"
