"""AppCDS (Application Class Data Sharing) flag builder for Java jars.

When IDE4EEG launches Svarog or ConnectiVIS, the JVM normally re-loads
all the Swing/AWT/3rd-party classes from scratch — a 0.5–1 s tax on
every cold start.  AppCDS lets the JVM persist class metadata to a
``.jsa`` archive on first run and reuse it on every subsequent run.

This module centralises the flag construction so all four launch
sites (gui.py ``_launch_svarog`` / ``_launch_connectivis``, the three
``review_*_via_svarog`` entry points in ``preprocessing/svarog_review``)
follow the same scheme as the standalone Svarog launcher
(``standalone-package-files/svarog`` in svarog4) and the connecti-VIS
``run.sh``.

Filename scheme
---------------

``<jar-dir>/<jar-stem>-<jvm-id>.jsa``

* ``<jar-dir>`` — directory containing the jar.  Putting the archive
  next to the jar means an uninstall (rm -rf the install dir) cleans
  it up automatically, and the launcher script + IDE4EEG share the
  same file.
* ``<jar-stem>`` — jar basename minus ``.jar``.  Different versions
  of the same app land on different filenames automatically.
* ``<jvm-id>`` — first 8 hex chars of ``sha1(<absolute path to java
  binary>)``.  AppCDS archives are tied to the exact JVM build that
  wrote them, so a JDK upgrade that lands on a new install path needs
  a fresh archive.  Tagging with the path means the upgrade naturally
  triggers regeneration instead of silently falling back via
  ``-Xshare:auto`` on a stale file.

Freshness check
---------------

If the archive's mtime is older than the jar's, treat it as stale
(jar has been redeployed, the archive's class list is out of date)
and regenerate.  Saves a manual ``rm`` step after every Svarog
rebuild.

JDK floor
---------

``-XX:ArchiveClassesAtExit`` (JEP 350, dynamic CDS) requires JDK 13+.
On JDK 11/12 the JVM rejects the flag with "Unrecognized VM option"
and aborts before main, so the version-probe gate is load-bearing.
We probe lazily — only when the archive is missing or stale — because
a fresh archive is itself proof that the JVM was JDK 13+ when it
wrote it (path-tagged jvm-id means a JDK swap lands on a new
filename), so reuse can skip the probe entirely and recover the full
~380 ms cold-start win.

Failure modes
-------------

Anything unexpected (jar dir read-only, jar gone between mtime calls,
sha1 module missing on a platform we haven't seen, ``java`` not on
PATH, version probe failed) → return ``[]`` and let the launch proceed
without AppCDS.  AppCDS is a perf optimisation, never a correctness
requirement.
"""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess


def _java_major(java_path: str) -> int | None:
    """Probe ``java -version`` and return the feature version.

    Returns ``None`` on any failure (binary missing, timeout, output
    unparseable).  Callers treat ``None`` as "don't enable AppCDS".

    Handles both the modern ``openjdk version "17.0.9"`` form and the
    Java-8 legacy ``java version "1.8.0_392"`` form (where the real
    major is 8, not 1).
    """
    resolved = shutil.which(java_path) or java_path
    try:
        out = subprocess.run(
            [resolved, "-version"],
            capture_output=True, text=True, timeout=5,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    text = (out.stderr or "") + (out.stdout or "")
    m = re.search(r'version "(\d+)(?:\.(\d+))?', text)
    if not m:
        return None
    first = int(m.group(1))
    return int(m.group(2)) if first == 1 and m.group(2) else first


def appcds_flags(jar_path: str, java_path: str = "java") -> list[str]:
    """Build AppCDS flags for launching ``jar_path`` under ``java_path``.

    Parameters
    ----------
    jar_path : str
        Absolute path to the jar.  Must exist; otherwise returns ``[]``.
    java_path : str
        ``java`` binary to launch with.  ``"java"`` (the default) is
        resolved via :func:`shutil.which`; an absolute path is used
        as-is.  The jvm-id is derived from the resolved path so a
        JDK upgrade swapping out the binary changes the archive name.

    Returns
    -------
    list[str]
        Either ``[-XX:SharedArchiveFile=..., -Xshare:auto]`` (reuse a
        valid archive), ``[-XX:ArchiveClassesAtExit=...]`` (generate
        on next clean exit), or ``[]`` (fall back to no AppCDS — jar
        missing, jar dir read-only, JDK < 13, etc.).
    """
    try:
        jar_path = os.fspath(jar_path)
        if not os.path.isfile(jar_path):
            return []

        resolved_java = shutil.which(java_path) or java_path
        jvm_id = hashlib.sha1(
            resolved_java.encode("utf-8")).hexdigest()[:8]

        jar_dir = os.path.dirname(os.path.abspath(jar_path)) or "."
        if not os.access(jar_dir, os.W_OK):
            return []

        jar_stem = os.path.splitext(os.path.basename(jar_path))[0]
        archive = os.path.join(jar_dir, f"{jar_stem}-{jvm_id}.jsa")

        try:
            jar_mtime = os.path.getmtime(jar_path)
        except OSError:
            return []

        if os.path.isfile(archive):
            try:
                archive_mtime = os.path.getmtime(archive)
            except OSError:
                archive_mtime = None
            if archive_mtime is not None and archive_mtime > jar_mtime:
                # Fresh archive → JVM that wrote it was JDK 13+ already
                # (couldn't have written it otherwise), so skip the
                # version probe and reuse directly.
                return [
                    f"-XX:SharedArchiveFile={archive}",
                    "-Xshare:auto",
                ]
            # Stale (jar redeployed since we wrote the archive) — drop
            # so the next clean exit regenerates.
            try:
                os.remove(archive)
            except OSError:
                pass

        # No fresh archive → we need ArchiveClassesAtExit, which is
        # JDK 13+ only.  Probe now (worth ~100 ms cold-path subprocess
        # only on the first launch of a (jar, jvm) pair).
        major = _java_major(java_path)
        if major is None or major < 13:
            return []

        return [f"-XX:ArchiveClassesAtExit={archive}"]
    except Exception:
        # Any unexpected error: skip AppCDS, never block the launch.
        return []
