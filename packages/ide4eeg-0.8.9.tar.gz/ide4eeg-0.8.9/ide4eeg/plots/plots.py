"""Publication-ready figure generation for IDE4EEG.

Provides plotting functions for time-frequency heatmaps with signal
overlays, filter responses, band-power diagnostics, cluster-test
results, correlation matrices, and video artifact timelines.
"""

import logging
import mne
import numpy as np
import os
# Use the object-oriented matplotlib API (Figure + Agg canvas) so
# rendering works from worker threads.  The pyplot interface
# initialises a GUI backend even when only savefig() is called,
# which raises "Starting a Matplotlib GUI outside of the main thread
# will likely fail." when the bad-channels detector or other
# pipeline steps run in a background thread.
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg

def plot_cluster_test(erps, erps_num, clusters, clusters_p_values, epochs_info, config, file_name, output_path):
    '''
    Plotting parts of the time domain plot of erp where cluster test finds statistical significant difference between
    tags.

    Parameters
    ----------
    erps: dict
        Dictionary which has names of tags as keys and numpy.ndarrays as values. Each array has
        [n_channels, erp] as shape and represent set of ERPs for each channel.
    erps_num: dict
        Dictionary which has names of tags as keys and number of epochs for that tag.
    clusters: list
        List of found clusters by cluster test. Each cluster has shape [signal_length, n_channels] and show position of
        them on the signal with bool values.
    clusters_p_values: numpy.ndarray
        List of p values for each cluster.
    epochs_info: mne.io.meas_info.Info
        MNE info taken from epochs.
    config: dict
        Dictionary of configuration variables.
    file_name: str
        Name of the file with raw signal.
    output_path: str
        Destinetion path of the plot.
    '''

    tag_names = list(erps.keys())
    if len(tag_names) < 2:
        logging.warning("Cluster test plot requires at least 2 event types, got %d — skipping.", len(tag_names))
        return

    t = np.linspace(config["epochs"]["start_offset"], config["epochs"]["stop_offset"], erps[tag_names[0]].shape[1])

    for ch_nr, ch_name in enumerate(epochs_info.ch_names):

        fig = Figure(dpi=1000)
        FigureCanvasAgg(fig)
        ax = fig.subplots()

        # plotting erps
        for tag in erps.keys():
            ax.plot(t, erps[tag][ch_nr, :]*10**6, label=f"{tag} ({erps_num[tag]})")
            ax.set_xlabel("Time [s]")
            ax.set_ylabel(r"Potential $[\mu V]$")
            ax.set_title(f"Cluster test {ch_name}")

        for cl_nr, cluster in enumerate(clusters):

            cluster_p_value = clusters_p_values[cl_nr]
            cluster = cluster.T  # n_channels x time_points

            if cluster_p_value < 0.05:
                color = "blue"
                alpha = 0.3
                label = "p<0.05"
                paint_patch = True
            elif cluster_p_value < 0.1:
                color = "blue"
                alpha = 0.1
                label = "p<0.1"
                paint_patch = True
            else:
                color = "gray"
                alpha = 1 - cluster_p_value
                label = "p>0.1"
                paint_patch = False

            # plot significant p_val
            if paint_patch:
                cls_ch = np.split(np.where(cluster[ch_nr] == True)[0], np.where(np.diff(np.where(cluster[ch_nr] == True)[0]) != 1)[0]+1)
                for c, cl in enumerate(cls_ch):
                    if cl.size >= 2:
                        label=label if c==0 else None
                        ax.axvspan(t[cl[0]], t[cl[-1]], color=color, alpha=alpha, zorder=1, label=label)

        ax.legend()
        fig.savefig(os.path.join(output_path, f"{os.path.splitext(file_name)[0]}___clustertest_{ch_name}_{tag_names[0]}_vs_{tag_names[1]}.jpg"))

def plot_BandPower(time, Pg, thrs, channel, band, width, ymin, ymax, facecolor, path, file_name):
    '''
    Preparing plot for searching bad channels via BandPower in preprocessing/channels_and_signal.py

    Parameters
    ----------
    time: numpy.ndarray
        Matrix with time.
    Pg: numpy.ndarray
        Points of average estimated power in defined window and band.
    thrs: list
        List with three floats/integers (in μV^2) for thresholds to calculate which channel has too much noise. So if
        thrs_type is:
            "+" -> then thrs[0] > thrs[1] > thrs[2]
            "-" -> then thrs[0] < thrs[1] < thrs[2]
    channel: str
        Channel name.
    band: list
        List with two floats/integers representing frequency band for the noise.
    width: float
        Function will cut windows from signal with this width (in seconds) and calculate spectral density for them.
    ymin: float
        Minimal value of Y axis (Pg).
    ymax: float
        Maximum value of Y axis (Pg).
    facecolor: str
        Facecolor of plot.
    path: str
        Output path for plot.
    file_name: str
        Name of input data.
    '''

    fig = Figure()  # , figsize=(19.2, 10.8), dpi=1000)
    FigureCanvasAgg(fig)
    ax = fig.subplots(1, 1)

    ax.plot(time, Pg)
    ax.plot([time[0], time[-1]], [thrs[0], thrs[0]], 'g--')
    ax.plot([time[0], time[-1]], [thrs[1], thrs[1]], 'y--')
    ax.plot([time[0], time[-1]], [thrs[2], thrs[2]], 'r--')

    ax.set_yscale('log')
    ax.set_ylim([ymin, ymax])
    ax.set_xlim((time[0], time[-1]))
    if facecolor is not None:
        ax.set_facecolor(facecolor)

    ax.set_title(f"{channel}: {band[0]}-{band[1]} Hz and window's width {width} s (n_win={Pg.size})")
    ax.set_xlabel("Number of window")
    ax.set_ylabel(r"Power $[\mu V^2]$")

    fig.savefig(os.path.join(path, f"{file_name}___{channel}_{band[0]}_{band[1]}Hz_{width}s.png"))

def plot_correlation_matrix(corr, corr_bad_x, corr_bad_y, channels_names, bad_channels, correlation_window, path, file_name):

    corr[np.triu_indices_from(corr)] = None  # deleting upper triangle of correlation matrix for aesthetic purposes
    fig = Figure()
    FigureCanvasAgg(fig)
    ax = fig.subplots()
    im = ax.matshow(corr, vmin=-1, vmax=1)
    ax.scatter(corr_bad_x, corr_bad_y, c='r', s=4)
    fig.colorbar(im, ax=ax, location="right")
    ax.set_xticks(np.arange(len(channels_names)))
    ax.set_xticklabels(channels_names, rotation=90)
    ax.set_yticks(np.arange(len(channels_names)))
    ax.set_yticklabels(channels_names)
    ax.set_title(f"{file_name} \n Bad channels out of [{correlation_window[0]}, {correlation_window[1]}]: {' '.join(bad_channels)} ")

    fig.savefig(os.path.join(path, f"{file_name}___channels_correlation_matrix.png"))


