import logging

class LogColors:
    """Color codes for different logging levels in terminal output.
    
    Contains ANSI escape codes for coloring log messages based on their level:
    - DEBUG: No color
    - INFO: Green
    - WARNING: Yellow
    - ERROR: Red
    - CRITICAL: Purple
    """
    COLORS = {
        logging.DEBUG: '',  # No color
        logging.INFO: '\033[92m',     # Green
        logging.WARNING: '\033[93m',  # Yellow
        logging.ERROR: '\033[91m',    # Red
        logging.CRITICAL: '\033[95;1m',  # Purple
    }
    ENDC = '\033[0m'

class LevelFormatter(logging.Formatter):
    """Custom formatter for logging that adds color based on message level.
    
    Extends the standard logging.Formatter to add color coding to log messages.
    DEBUG messages show timestamp, while other levels show colored level names.
    """
    def format(self, record):
        """Format the log record with appropriate color and layout.

        Args:
            record: The log record to format

        Returns:
            str: The formatted log message
        """
        color = LogColors.COLORS.get(record.levelno, '')
        reset = LogColors.ENDC if color else ''
        if record.levelno == logging.DEBUG:
            fmt = f"%(asctime)s - {record.levelname} - %(message)s"
        else:
            fmt = f"{color}%(levelname)s{reset}: %(message)s"
        # Use a per-call formatter to avoid mutating shared state
        formatter = logging.Formatter(fmt, datefmt=self.datefmt)
        return formatter.format(record)

def setup_logging(level=logging.INFO):
    """Configure the basic logging settings with colored output.
    
    Args:
        level: The minimum logging level to display (default: logging.INFO)
    """
    handler = logging.StreamHandler()
    handler.setFormatter(LevelFormatter("%(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    logging.basicConfig(level=level, handlers=[handler])