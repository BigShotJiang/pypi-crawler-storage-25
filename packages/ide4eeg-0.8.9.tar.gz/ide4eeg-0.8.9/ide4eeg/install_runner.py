"""Install / uninstall video-stack packages via subprocess pip.

The *write* counterpart to :mod:`ide4eeg.install_diagnostics`,
which is read-only.  Together they form the two halves of the
in-app install panel: diagnose + remediate.

Both runners stream pip output line-by-line to a caller-supplied
callback, so a GUI panel can show live progress in a log widget
instead of blocking on a single ``subprocess.run`` call.

Public API:

- :class:`VideoStackInstaller` — install one package or a whole plan
- :class:`VideoStackUninstaller` — bulk-uninstall the video stack
- :class:`InstallResult` / :class:`InstallSummary` — install shapes
- :class:`UninstallResult` / :class:`UninstallSummary` — uninstall shapes

Cell-blocked packages from
:func:`ide4eeg.install_diagnostics.cell_issues` are intentionally NOT
auto-installed — they require human-only remediation (install a
C compiler, switch Python version) that no in-process button can
perform.  The summary surfaces them so the GUI can route the user
to the diagnostic dialog with the cell-specific text.
"""

from __future__ import annotations

import platform
import shutil
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from ide4eeg.install_diagnostics import ActionPlan, Pkg

# Packages whose newly-installed .so / .pyd extensions cannot be
# reliably hot-imported into a running interpreter.  Heavy native
# loaders (torch, onnxruntime), C-extension modules (cv2, av), and
# anything that probes ONNX models on import (insightface) all want
# a clean process boot to reload cleanly.  When any of these are
# freshly installed the GUI prompts the user to restart.
_RESTART_REQUIRED_PKGS = frozenset(
    {"cv2", "av", "insightface", "onnxruntime", "torch"})


@dataclass(frozen=True)
class InstallResult:
    """Outcome of a single ``pip install <pkg>`` invocation."""
    pkg: Pkg
    exit_code: int
    output: str

    @property
    def success(self) -> bool:
        return self.exit_code == 0


@dataclass(frozen=True)
class InstallSummary:
    """Aggregated result of running an install plan."""
    attempted: tuple[Pkg, ...] = field(default_factory=tuple)
    results: tuple[InstallResult, ...] = field(default_factory=tuple)
    skipped_blocked: tuple[Pkg, ...] = field(default_factory=tuple)
    needs_restart: bool = False
    cancelled: bool = False

    @property
    def all_succeeded(self) -> bool:
        return all(r.success for r in self.results)

    @property
    def failures(self) -> tuple[InstallResult, ...]:
        return tuple(r for r in self.results if not r.success)


class CancellationToken:
    """Thread-safe cancellation signal for long-running pip flows.

    Owner (typically the GUI) creates a token, hands it to the
    installer/uninstaller, and can call :meth:`cancel` from any
    thread.  The runner:

    - Polls :attr:`is_cancelled` before starting each subprocess
      and skips remaining work when set.
    - Stores the active :class:`subprocess.Popen` handle so
      :meth:`cancel` can ``terminate()`` an in-flight pip.  pip
      handles SIGTERM gracefully (partial download is discarded,
      no package is installed) so cancelled state is well-
      defined — whatever pip completed stays, what didn't doesn't.
    """

    def __init__(self):
        self._cancelled = threading.Event()
        self._proc_lock = threading.Lock()
        self._active_proc: subprocess.Popen | None = None

    @property
    def is_cancelled(self) -> bool:
        return self._cancelled.is_set()

    def cancel(self) -> None:
        """Request cancellation.  Idempotent; safe to call from any
        thread including the one running the subprocess."""
        self._cancelled.set()
        with self._proc_lock:
            proc = self._active_proc
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass

    def _set_active_proc(self, proc: subprocess.Popen) -> None:
        with self._proc_lock:
            self._active_proc = proc

    def _clear_active_proc(self) -> None:
        with self._proc_lock:
            self._active_proc = None


def _is_in_venv() -> bool:
    """Return True if the active interpreter is inside a venv.

    PEP 405 venvs set ``sys.prefix != sys.base_prefix``.  Older
    virtualenv installs set ``sys.real_prefix`` instead; honour both.
    """
    if sys.prefix != getattr(sys, "base_prefix", sys.prefix):
        return True
    if hasattr(sys, "real_prefix"):
        return True
    return False


def _run_pip_streaming(
    cmd: list[str],
    log_callback: Callable[[str], None],
    *,
    cancel: CancellationToken | None = None,
) -> tuple[int, str]:
    """Run a pip subprocess, streaming each output line to ``log_callback``.

    Returns ``(exit_code, full_output)``.  Combined stdout/stderr;
    the same primitive used by both :class:`VideoStackInstaller`
    and :class:`VideoStackUninstaller`, plus the L2CS install path
    in the GUI.

    When ``cancel`` is provided, the running subprocess is
    registered with the token so :meth:`CancellationToken.cancel`
    can ``terminate()`` it from another thread.
    """
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    if cancel is not None:
        cancel._set_active_proc(proc)
    try:
        lines: list[str] = []
        assert proc.stdout is not None
        for raw in proc.stdout:
            line = raw.rstrip("\n")
            lines.append(line)
            log_callback(line)
        proc.wait()
        return proc.returncode, "\n".join(lines)
    finally:
        if cancel is not None:
            cancel._clear_active_proc()


def install_specs(
    specs: list[str],
    *,
    label: str,
    log_callback: Callable[[str], None],
    cancel: CancellationToken | None = None,
) -> tuple[bool, str]:
    """Run ``pip install <specs...>`` in a single subprocess with
    streaming output.

    Parameters
    ----------
    specs
        One or more pip specifiers, e.g. ``["torch", "torchvision"]``
        or ``["l2cs @ git+https://..."]``.
    label
        Human-readable description (e.g. ``"PyTorch + torchvision"``)
        used in the banner line.
    log_callback
        Receives each pip line.
    cancel
        Optional :class:`CancellationToken` for SIGTERM-driven abort.

    Returns ``(success, full_output)``.  ``success`` is True iff
    pip exited 0; cancelled subprocess is treated as failure.
    """
    cmd = [sys.executable, "-m", "pip", "install"]
    if not _is_in_venv():
        cmd.append("--user")
    cmd.extend(specs)
    log_callback("")
    log_callback(f">>> Installing {label}")
    log_callback(f">>> {' '.join(cmd)}")
    exit_code, output = _run_pip_streaming(
        cmd, log_callback, cancel=cancel)
    return exit_code == 0, output


def pip_failure_hint(output: str) -> str:
    """Detect "no compatible wheel" pip-install failures and explain
    in plain language.

    Returns ``""`` when nothing matches, or a multi-line hint string
    callers can append to error dialogs.  Common cases: PyTorch on
    Intel Mac since torch 2.3, freshly-released Python versions
    that lag PyTorch wheel cuts.
    """
    if ("No matching distribution" not in output
            and "Could not find a version" not in output):
        return ""
    py = "%d.%d.%d" % sys.version_info[:3]
    plat = f"{platform.system()} {platform.machine()}"
    return (
        "\n\nLikely cause: no compatible wheel for your "
        f"Python/platform combination (Python {py} on {plat}).\n"
        "PyTorch dropped macOS x86_64 (Intel Mac) wheels in "
        "torch 2.3 — Apple Silicon only.\n"
        "Newly-released Python versions also lag a few weeks "
        "behind PyTorch wheels.\n"
        "Workarounds:\n"
        "  - On Intel Mac: install a CPU-only PyTorch nightly "
        "manually, or use a pre-built older release.\n"
        "  - Otherwise: try a different Python version that "
        "PyTorch publishes wheels for."
    )


class VideoStackInstaller:
    """Run ``pip install`` for video-stack packages with streaming
    output.

    Parameters
    ----------
    log_callback : callable(str) or None
        Receives each line of pip output (without trailing newline)
        plus banner lines emitted by the runner itself.  When
        ``None``, output is silently discarded; tests use this
        default plus a manual capture.
    pip_executor : callable or None
        Indirection for tests: builds and runs the subprocess.  The
        default uses :func:`subprocess.Popen` with combined
        stdout / stderr.  Tests inject a stub.
    cancel : CancellationToken or None
        Optional cancellation token; when set, :meth:`install_plan`
        polls before each subprocess and skips remaining packages
        once cancelled.  Active pip subprocesses are also
        ``terminate()``-d when the token is cancelled mid-flight.
    """

    def __init__(
        self,
        *,
        log_callback: Callable[[str], None] | None = None,
        pip_executor: Callable[..., InstallResult] | None = None,
        cancel: CancellationToken | None = None,
    ):
        self._log = log_callback or (lambda _line: None)
        self._exec = pip_executor or self._default_pip_executor
        self._cancel = cancel

    def _emit(self, line: str) -> None:
        self._log(line)

    def _default_pip_executor(self, pkg: Pkg, cmd: list[str]) -> InstallResult:
        exit_code, output = _run_pip_streaming(
            cmd, self._log, cancel=self._cancel)
        return InstallResult(
            pkg=pkg, exit_code=exit_code, output=output)

    def build_command(self, pkg: Pkg) -> list[str]:
        """Return the ``pip install`` argv for one package."""
        cmd = [sys.executable, "-m", "pip", "install"]
        if not _is_in_venv():
            cmd.append("--user")
        cmd.append(pkg.pip_spec)
        return cmd

    def install_one(self, pkg: Pkg) -> InstallResult:
        """Install one package.  Banner-logs the command, then runs."""
        cmd = self.build_command(pkg)
        self._emit("")
        self._emit(f">>> Installing {pkg.import_name}: {pkg.pip_spec}")
        self._emit(f">>> {' '.join(cmd)}")
        return self._exec(pkg, cmd)

    def install_plan(
        self,
        plan: ActionPlan,
        *,
        include_optional: bool = True,
    ) -> InstallSummary:
        """Install every clean-install package in ``plan``.

        ``plan.blocked`` is recorded in :attr:`InstallSummary.skipped_blocked`
        but never auto-installed — those need user-side remediation.

        ``include_optional`` controls whether L2CS extras (the two
        :class:`Pkg` entries with ``optional=True`` — torch + l2cs)
        are installed.  Default True since L2CS is the headline
        gaze backend; the GUI exposes a checkbox so users without
        a GPU + spare ~500 MB can opt out.

        When the runner has a :class:`CancellationToken` and it is
        already set when this method is entered (or becomes set
        between subprocesses), remaining packages are skipped and
        the partial summary is returned with
        :attr:`InstallSummary.cancelled` = True.
        """
        attempted: list[Pkg] = []
        results: list[InstallResult] = []
        cancelled = False
        for pkg in plan.missing:
            if self._cancel is not None and self._cancel.is_cancelled:
                cancelled = True
                self._emit("")
                self._emit("--- Cancelled by user; "
                           "skipping remaining packages")
                break
            if pkg.optional and not include_optional:
                self._emit(
                    f"--- Skipping {pkg.import_name} (caller opted out)")
                continue
            attempted.append(pkg)
            results.append(self.install_one(pkg))
        needs_restart = any(
            r.success and r.pkg.import_name in _RESTART_REQUIRED_PKGS
            for r in results
        )
        skipped = tuple(p for p, _ in plan.blocked)
        if skipped and not cancelled:
            self._emit("")
            self._emit(
                "--- The following packages are platform-blocked on "
                "this cell and were NOT auto-installed:")
            for p in skipped:
                self._emit(f"---   {p.import_name} ({p.purpose})")
            self._emit(
                "--- See the Config tab → Video processing panel "
                "for cell-specific remediation steps.")
        return InstallSummary(
            attempted=tuple(attempted),
            results=tuple(results),
            skipped_blocked=skipped,
            needs_restart=needs_restart,
            cancelled=cancelled,
        )


def restart_required_packages(pkgs: Iterable[Pkg]) -> tuple[Pkg, ...]:
    """Return the subset of ``pkgs`` whose install requires a process
    restart to become importable cleanly."""
    return tuple(p for p in pkgs if p.import_name in _RESTART_REQUIRED_PKGS)


# Distribution (pip) names removed by the video-stack uninstaller.
# Distinct from import names — pip uninstall takes dist names — which
# diverge for opencv-contrib-python-headless (-> cv2).  All four
# opencv distributions are listed because they ship the same `cv2/`
# package and can coexist in the same venv (a user who pip-installed
# `opencv-python` directly, or pulled it in transitively from another
# tool, will keep `import cv2` working until *every* variant is
# removed).  Pip skips dist names that aren't installed and reports
# "not installed" — UninstallResult.success treats that as success.
# ``torchvision`` isn't in VIDEO_STACK because nothing imports it
# directly, but the L2CS Download flow installs it alongside torch
# and users expect Uninstall to remove it.  ``gdown`` is included
# for the same reason: the previous L2CS download path used it;
# users who installed via that path have a stale copy that nothing
# else needs.  mpv is deliberately absent — Svarog uses it
# independently of facetag.
_VIDEO_STACK_DIST_NAMES = (
    "opencv-contrib-python-headless",
    "opencv-contrib-python",
    "opencv-python-headless",
    "opencv-python",
    "av",
    "imageio",
    "insightface",
    "onnxruntime",
    "torch",
    "torchvision",
    "l2cs",
    "gdown",
)


@dataclass(frozen=True)
class UninstallResult:
    """Outcome of a single ``pip uninstall <dist>`` invocation."""
    dist: str
    exit_code: int
    output: str

    @property
    def success(self) -> bool:
        # pip uninstall -y of a not-installed package returns non-zero
        # with "WARNING: Skipping <pkg> as it is not installed." — we
        # treat that as success because the post-condition (package is
        # gone) holds either way.
        if self.exit_code == 0:
            return True
        return "not installed" in self.output.lower()


@dataclass(frozen=True)
class UninstallSummary:
    """Aggregated result of running an uninstall."""
    pip_results: tuple[UninstallResult, ...] = field(default_factory=tuple)
    files_removed: tuple[str, ...] = field(default_factory=tuple)
    cancelled: bool = False

    @property
    def all_succeeded(self) -> bool:
        return all(r.success for r in self.pip_results)

    @property
    def failures(self) -> tuple[UninstallResult, ...]:
        return tuple(r for r in self.pip_results if not r.success)


class VideoStackUninstaller:
    """Bulk-remove the video stack: pip-uninstall the seven Python
    packages plus L2CS-Net's torchvision + gdown extras, then delete
    the L2CS weights file and the InsightFace model cache.

    Mirrors :class:`VideoStackInstaller` — same streaming-log
    callback, same pip subprocess, same test-injection hook for
    ``pip_executor``.

    mpv is deliberately not touched — it lives at ``~/.obci/svarog/
    mpv/`` and Svarog uses it independently of facetag.

    Parameters
    ----------
    log_callback : callable(str) or None
        Receives each pip line + banner emit (without trailing
        newline).  Default: silent.
    pip_executor : callable or None
        Test-injection hook for ``subprocess.Popen``.
    cancel : CancellationToken or None
        Optional cancellation token; when set, :meth:`uninstall_all`
        polls before each subprocess and skips remaining packages
        once cancelled.
    """

    DIST_NAMES = _VIDEO_STACK_DIST_NAMES

    def __init__(
        self,
        *,
        log_callback: Callable[[str], None] | None = None,
        pip_executor: Callable[..., UninstallResult] | None = None,
        cancel: CancellationToken | None = None,
    ):
        self._log = log_callback or (lambda _line: None)
        self._exec = pip_executor or self._default_pip_executor
        self._cancel = cancel

    def _emit(self, line: str) -> None:
        self._log(line)

    def _default_pip_executor(self, dist: str, cmd: list[str]) -> UninstallResult:
        exit_code, output = _run_pip_streaming(
            cmd, self._log, cancel=self._cancel)
        return UninstallResult(
            dist=dist, exit_code=exit_code, output=output)

    def build_command(self, dist: str) -> list[str]:
        """Return the ``pip uninstall -y`` argv for one distribution."""
        return [sys.executable, "-m", "pip", "uninstall", "-y", dist]

    def uninstall_one(self, dist: str) -> UninstallResult:
        cmd = self.build_command(dist)
        self._emit("")
        self._emit(f">>> Uninstalling {dist}")
        self._emit(f">>> {' '.join(cmd)}")
        return self._exec(dist, cmd)

    def uninstall_all(self) -> UninstallSummary:
        """Run pip-uninstall for every distribution in :attr:`DIST_NAMES`,
        then remove the L2CS weights file and InsightFace model
        cache.  Returns the aggregated summary.

        Cancellable via the constructor's ``cancel`` token; when
        cancelled mid-run the data-files cleanup is also skipped
        (state on disk reflects whatever pip completed before the
        SIGTERM landed).
        """
        results: list[UninstallResult] = []
        cancelled = False
        for dist in self.DIST_NAMES:
            if self._cancel is not None and self._cancel.is_cancelled:
                cancelled = True
                self._emit("")
                self._emit("--- Cancelled by user; "
                           "skipping remaining uninstalls")
                break
            results.append(self.uninstall_one(dist))
        files_removed: list[str] = []
        if not cancelled:
            files_removed = self.remove_data_files()
            if files_removed:
                self._emit("")
                self._emit("--- Removed runtime data:")
                for path in files_removed:
                    self._emit(f"---   {path}")
        return UninstallSummary(
            cancelled=cancelled,
            pip_results=tuple(results),
            files_removed=tuple(files_removed),
        )

    def remove_data_files(self) -> list[str]:
        """Delete the L2CS weights file + InsightFace model cache.

        Returns the list of paths actually removed (skipping ones that
        weren't there).  No-ops on permission errors — the streaming
        log shows the partial result.
        """
        from ide4eeg.download_tools import (
            INSIGHTFACE_ROOT, canonical_l2cs_weights_path)
        removed: list[str] = []
        weights = Path(canonical_l2cs_weights_path())
        if weights.exists():
            try:
                weights.unlink()
                removed.append(str(weights))
            except OSError as exc:
                self._emit(
                    f"--- Failed to remove {weights}: {exc}")
        if_models = INSIGHTFACE_ROOT / "models"
        if if_models.exists():
            try:
                shutil.rmtree(if_models)
                removed.append(str(if_models))
            except OSError as exc:
                self._emit(
                    f"--- Failed to remove {if_models}: {exc}")
        return removed


def _cli_main(argv: list[str] | None = None) -> int:
    """Entry point for ``python -m ide4eeg.install_runner``.

    Useful on headless boxes, in CI, and for scripted setup —
    mirrors the GUI's Install missing button without launching Qt.
    Prints the plan, confirms (unless ``-y`` is passed), runs the
    installer with stdout as the streaming log, prints a summary,
    and suggests a Python restart if needed.
    """
    import argparse

    from ide4eeg.install_diagnostics import (
        format_diagnostic, plan_install)

    parser = argparse.ArgumentParser(
        prog="python -m ide4eeg.install_runner",
        description="Install missing video-stack packages.",
    )
    parser.add_argument(
        "-y", "--yes", action="store_true",
        help="Skip the confirmation prompt.")
    parser.add_argument(
        "--no-l2cs", action="store_true",
        help="Skip the L2CS-Net + PyTorch extras (default-on; "
             "L2CS-Net is the default eye-gaze backend, ~500 MB "
             "CPU / up to ~2 GB CUDA).")
    args = parser.parse_args(argv)

    plan = plan_install()
    if not plan.missing:
        sys.stdout.write(format_diagnostic(plan))
        if plan.blocked:
            sys.stdout.write(
                "\nSome packages are platform-blocked — see above "
                "for cell-specific remediation.\n")
        return 0

    sys.stdout.write(format_diagnostic(plan))
    if not args.yes:
        sys.stdout.write(
            "\nProceed with `pip install` for the missing "
            "packages? [y/N] ")
        sys.stdout.flush()
        try:
            reply = input().strip().lower()
        except EOFError:
            reply = ""
        if reply not in ("y", "yes"):
            sys.stdout.write("Aborted.\n")
            return 1

    installer = VideoStackInstaller(
        log_callback=lambda line: print(line))
    summary = installer.install_plan(
        plan, include_optional=not args.no_l2cs)

    sys.stdout.write("\n--- Install summary ---\n")
    for r in summary.results:
        marker = "OK" if r.success else "FAIL"
        sys.stdout.write(f"  [{marker}] {r.pkg.import_name}\n")
    if summary.skipped_blocked:
        sys.stdout.write(
            "Platform-blocked (not attempted):\n")
        for p in summary.skipped_blocked:
            sys.stdout.write(f"  [BLOCKED] {p.import_name}\n")
    if summary.needs_restart:
        sys.stdout.write(
            "\nNote: restart the Python process before importing "
            "ide4eeg again — newly installed C extensions / native "
            "loaders cannot be hot-imported reliably.\n")
    return 0 if summary.all_succeeded else 2


if __name__ == "__main__":
    sys.exit(_cli_main())
