"""Tests for :mod:`ide4eeg.download_tools` — GitLab CI artifact
downloads used to fetch Svarog/empi/ConnectiVIS on first run.

Focus areas:

- TLS context construction (certifi preferred, platform fallback)
- Two-attempt download strategy (certifi → platform on verify error)
- User-friendly error when both attempts fail with verify errors
- Non-TLS errors (404, network down) re-raise without fallback
- User-Agent header is sent
"""

import io
import ssl
import sys
import urllib.error
from unittest.mock import patch, MagicMock

import pytest

from ide4eeg.download_tools import (
    _certifi_ssl_context,
    _download_zip,
    _is_ssl_verify_error,
    _platform_ssl_fix_hint,
    _USER_AGENT,
)


# ---------------------------------------------------------------------------
# _certifi_ssl_context
# ---------------------------------------------------------------------------

class TestCertifiContext:

    def test_returns_ssl_context_when_certifi_available(self):
        """Happy path — certifi is installed (required by
        requirements.txt), and the helper returns an SSLContext
        whose CA bundle points at the certifi file."""
        ctx = _certifi_ssl_context()
        assert ctx is not None
        assert isinstance(ctx, ssl.SSLContext)

    def test_returns_none_when_certifi_missing(self):
        """If certifi can't be imported, return None so the caller
        falls back to the platform default context."""
        # Simulate ImportError by temporarily hiding certifi in sys.modules
        import importlib
        saved = sys.modules.pop("certifi", None)
        try:
            # Use builtins.__import__ patch to force ImportError for
            # the specific module
            original_import = __builtins__["__import__"] if isinstance(
                __builtins__, dict) else __builtins__.__import__

            def _fake_import(name, *args, **kwargs):
                if name == "certifi":
                    raise ImportError("simulated missing certifi")
                return original_import(name, *args, **kwargs)

            with patch("builtins.__import__", side_effect=_fake_import):
                ctx = _certifi_ssl_context()
            assert ctx is None
        finally:
            if saved is not None:
                sys.modules["certifi"] = saved


# ---------------------------------------------------------------------------
# _is_ssl_verify_error
# ---------------------------------------------------------------------------

class TestIsSSLVerifyError:

    def test_direct_cert_verification_error(self):
        exc = ssl.SSLCertVerificationError(
            "certificate verify failed: self-signed certificate")
        assert _is_ssl_verify_error(exc) is True

    def test_ssl_error_with_verify_in_message(self):
        exc = ssl.SSLError(1, "CERTIFICATE_VERIFY_FAILED")
        assert _is_ssl_verify_error(exc) is True

    def test_urlerror_wrapping_ssl_verify(self):
        """urllib.error.URLError wraps the underlying SSL error in
        its ``reason`` attribute."""
        inner = ssl.SSLCertVerificationError(
            "certificate verify failed: self-signed certificate")
        exc = urllib.error.URLError(inner)
        assert _is_ssl_verify_error(exc) is True

    def test_urlerror_string_matching(self):
        """Sometimes the SSL error is stringified into the URLError
        message without a proper __cause__ chain."""
        exc = urllib.error.URLError(
            "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] "
            "certificate verify failed: self-signed certificate "
            "in certificate chain (_ssl.c:1081)>")
        assert _is_ssl_verify_error(exc) is True

    def test_network_down_is_not_verify_error(self):
        exc = urllib.error.URLError("Network is unreachable")
        assert _is_ssl_verify_error(exc) is False

    def test_http_404_is_not_verify_error(self):
        exc = urllib.error.HTTPError(
            "https://gitlab.com/", 404, "Not Found", {}, None)
        assert _is_ssl_verify_error(exc) is False

    def test_value_error_is_not_verify_error(self):
        exc = ValueError("unrelated")
        assert _is_ssl_verify_error(exc) is False


# ---------------------------------------------------------------------------
# _platform_ssl_fix_hint
# ---------------------------------------------------------------------------

class TestPlatformSSLFixHint:

    def test_returns_nonempty_string(self):
        hint = _platform_ssl_fix_hint()
        assert isinstance(hint, str)
        assert len(hint) > 0

    def test_macos_hint_mentions_install_certificates_command(self):
        with patch("platform.system", return_value="Darwin"):
            hint = _platform_ssl_fix_hint()
        assert "Install" in hint and "Certificates" in hint

    def test_windows_hint_mentions_certifi_upgrade(self):
        with patch("platform.system", return_value="Windows"):
            hint = _platform_ssl_fix_hint()
        assert "certifi" in hint.lower()

    def test_linux_hint_mentions_ca_certificates(self):
        with patch("platform.system", return_value="Linux"):
            hint = _platform_ssl_fix_hint()
        assert "ca-certificates" in hint or "certifi" in hint


# ---------------------------------------------------------------------------
# _download_zip — two-attempt TLS strategy
# ---------------------------------------------------------------------------

class _FakeResponse:
    """Context-manager wrapper around an in-memory byte stream that
    mimics the subset of :class:`http.client.HTTPResponse` used by
    :func:`_download_zip`."""

    def __init__(self, body, content_length=None):
        self._stream = io.BytesIO(body)
        self._content_length = (
            content_length if content_length is not None else len(body))

    @property
    def headers(self):
        return {"Content-Length": str(self._content_length)}

    def read(self, size):
        return self._stream.read(size)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._stream.close()
        return False


class TestDownloadZip:

    _FAKE_ZIP = b"PK\x03\x04" + b"\x00" * 96  # minimal zip-magic payload

    def _urlopen_returning(self, body):
        """Build a urlopen side_effect that returns a FakeResponse
        on every call."""
        return lambda req, **kw: _FakeResponse(body)

    def _urlopen_raising(self, exc):
        return lambda req, **kw: (_ for _ in ()).throw(exc)

    def test_certifi_path_succeeds(self, tmp_path):
        """Happy path: certifi context works on first attempt."""
        side = self._urlopen_returning(self._FAKE_ZIP)
        with patch("urllib.request.urlopen", side_effect=side):
            path = _download_zip("https://example/artifact.zip")
        try:
            with open(path, "rb") as f:
                assert f.read() == self._FAKE_ZIP
        finally:
            import os
            os.unlink(path)

    def test_certifi_fails_verify_platform_succeeds(self, tmp_path):
        """certifi context raises a verify error; platform context
        succeeds on the retry."""
        calls = {"count": 0}

        def side_effect(req, **kw):
            calls["count"] += 1
            if calls["count"] == 1:
                raise urllib.error.URLError(
                    ssl.SSLCertVerificationError(
                        "certificate verify failed"))
            return _FakeResponse(self._FAKE_ZIP)

        with patch("urllib.request.urlopen", side_effect=side_effect):
            path = _download_zip("https://example/artifact.zip")
        assert calls["count"] == 2  # one retry happened
        import os
        os.unlink(path)

    def test_both_attempts_fail_verify_raises_friendly(self):
        """Both certifi and platform contexts hit verify errors —
        raise RuntimeError with a platform-specific remediation hint."""
        def side_effect(req, **kw):
            raise urllib.error.URLError(
                ssl.SSLCertVerificationError("certificate verify failed"))

        with patch("urllib.request.urlopen", side_effect=side_effect):
            with pytest.raises(RuntimeError, match="TLS certificate"):
                _download_zip("https://example/artifact.zip")

    def test_friendly_error_mentions_fix(self):
        def side_effect(req, **kw):
            raise urllib.error.URLError(
                ssl.SSLCertVerificationError("certificate verify failed"))

        with patch("urllib.request.urlopen", side_effect=side_effect):
            with pytest.raises(RuntimeError) as excinfo:
                _download_zip("https://example/artifact.zip")
        msg = str(excinfo.value)
        assert "TLS certificate" in msg
        assert "Fix:" in msg
        # Platform-specific hint is included
        import platform
        sys_name = platform.system()
        if sys_name == "Darwin":
            assert "Install Certificates" in msg or "Install" in msg
        # Original error is preserved via __cause__
        assert excinfo.value.__cause__ is not None

    def test_non_tls_error_does_not_retry(self):
        """HTTP 404 on the first attempt should not trigger the
        platform fallback — it's not a TLS problem."""
        calls = {"count": 0}

        def side_effect(req, **kw):
            calls["count"] += 1
            raise urllib.error.HTTPError(
                "https://gitlab.com/", 404, "Not Found", {}, None)

        with patch("urllib.request.urlopen", side_effect=side_effect):
            with pytest.raises(urllib.error.HTTPError):
                _download_zip("https://example/artifact.zip")
        assert calls["count"] == 1  # NO retry for non-TLS errors

    def test_network_down_does_not_retry(self):
        calls = {"count": 0}

        def side_effect(req, **kw):
            calls["count"] += 1
            raise urllib.error.URLError("Network is unreachable")

        with patch("urllib.request.urlopen", side_effect=side_effect):
            with pytest.raises(urllib.error.URLError,
                               match="Network is unreachable"):
                _download_zip("https://example/artifact.zip")
        assert calls["count"] == 1

    def test_user_agent_header_sent(self):
        """Every download request identifies itself via a stable
        User-Agent so GitLab / Cloudflare don't treat us as a bot."""
        captured = []

        def side_effect(req, **kw):
            captured.append(req.get_header("User-agent"))
            return _FakeResponse(self._FAKE_ZIP)

        with patch("urllib.request.urlopen", side_effect=side_effect):
            path = _download_zip("https://example/artifact.zip")
        import os
        os.unlink(path)
        assert captured
        assert "ide4eeg" in captured[0].lower()

    def test_progress_callback_called(self):
        """The progress callback receives (bytes_downloaded,
        total_bytes) pairs during streaming."""
        recorded = []

        def progress(downloaded, total):
            recorded.append((downloaded, total))

        side = self._urlopen_returning(self._FAKE_ZIP)
        with patch("urllib.request.urlopen", side_effect=side):
            path = _download_zip(
                "https://example/artifact.zip", progress_callback=progress)
        import os
        os.unlink(path)
        # At least one progress call happened, with total matching
        # the fake zip length
        assert recorded
        assert recorded[-1][0] == len(self._FAKE_ZIP)
        assert recorded[-1][1] == len(self._FAKE_ZIP)


class TestDownloadMpv:
    """download_mpv() dispatcher logic — does NOT exercise real network I/O."""

    def test_macos_no_brew_no_path_returns_none(self):
        """macOS with neither mpv on PATH nor Homebrew: nothing we can
        do; fall back silently."""
        from ide4eeg.download_tools import download_mpv
        with patch("ide4eeg.download_tools._os_tag", return_value="macos-arm64"), \
             patch("ide4eeg.download_tools.shutil.which", return_value=None), \
             patch("ide4eeg.download_tools._macos_brew_path", return_value=None):
            assert download_mpv() is None

    def test_unsupported_platform_returns_none(self):
        """A platform tag with no entry in _MPV_SOURCES returns None
        rather than raising."""
        from ide4eeg.download_tools import download_mpv
        with patch("ide4eeg.download_tools._os_tag", return_value="freebsd-x64"):
            assert download_mpv() is None

    def test_cached_binary_short_circuits_download(self, tmp_path):
        """An executable binary at the expected destination skips the
        network call entirely and returns the cached path."""
        from ide4eeg.download_tools import download_mpv, _mpv_binary_path
        with patch("ide4eeg.download_tools._os_tag", return_value="linux-x64"), \
             patch("ide4eeg.download_tools.platform.system", return_value="Linux"):
            target = tmp_path / "mpv"
            # Compute the cached path inside the patched-os context so
            # _os_tag and platform.system see the linux-x64 stubs.
            cached = _mpv_binary_path(target)
            cached.parent.mkdir(parents=True)
            cached.write_text("#!/bin/sh\n")
            cached.chmod(0o755)
            with patch("ide4eeg.download_tools._download_zip") as mocked:
                result = download_mpv(target_dir=target)
                mocked.assert_not_called()
            assert result == str(cached)

    def test_force_redownloads_even_when_cached(self, tmp_path):
        """force=True re-downloads regardless of cache (useful for
        upgrading the pinned mpv version)."""
        from ide4eeg.download_tools import download_mpv, _mpv_binary_path

        def fake_install(url, dest_path, progress_callback):
            dest_path.write_text("#!/bin/sh\n# fresh install\n")
            dest_path.chmod(0o755)

        with patch("ide4eeg.download_tools._os_tag", return_value="linux-x64"), \
             patch("ide4eeg.download_tools.platform.system", return_value="Linux"), \
             patch("ide4eeg.download_tools._install_mpv_appimage",
                   side_effect=fake_install) as installer:
            target = tmp_path / "mpv"
            cached = _mpv_binary_path(target)
            cached.parent.mkdir(parents=True)
            cached.write_text("#!/bin/sh\n")
            cached.chmod(0o755)
            result = download_mpv(target_dir=target, force=True)
            installer.assert_called_once()
            assert result == str(cached)


class TestResolveMpvUrlLinux:
    """_resolve_mpv_url_linux() — discovers the latest pkgforge-dev/
    mpv-AppImage asset via the GitHub releases API, falls back to a
    hardpinned URL on any failure.  Behaviour-locked so that an
    upstream tag-scheme change can't silently 404 every Linux install
    again (see USER report 2026-05-04)."""

    @staticmethod
    def _api_response(payload):
        """Build an _open_url-compatible context manager with *payload*
        as JSON bytes."""
        import io, json
        cm = MagicMock()
        cm.__enter__.return_value = io.BytesIO(json.dumps(payload).encode())
        cm.__exit__.return_value = False
        return cm

    def test_picks_anylinux_x86_64_asset(self):
        from ide4eeg.download_tools import _resolve_mpv_url_linux
        payload = {
            "tag_name": "v0.41.0@2026-05-01_xxx",
            "assets": [
                {"name": "mpv-v0.41.0-anylinux-aarch64.AppImage",
                 "browser_download_url": "https://example/aarch64"},
                {"name": "mpv-v0.41.0-anylinux-x86_64.AppImage",
                 "browser_download_url": "https://example/x86_64"},
                {"name": "mpv-v0.41.0-anylinux-x86_64.AppImage.zsync",
                 "browser_download_url": "https://example/x86_64.zsync"},
            ],
        }
        with patch("ide4eeg.download_tools._open_url",
                   return_value=self._api_response(payload)):
            assert _resolve_mpv_url_linux() == "https://example/x86_64"

    def test_falls_back_when_api_unreachable(self):
        from ide4eeg.download_tools import (
            _resolve_mpv_url_linux, _MPV_LINUX_FALLBACK_URL)
        with patch("ide4eeg.download_tools._open_url",
                   side_effect=urllib.error.URLError("network down")):
            assert _resolve_mpv_url_linux() == _MPV_LINUX_FALLBACK_URL

    def test_falls_back_when_no_matching_asset(self):
        """A future release with only aarch64 / .zsync assets shouldn't
        return the wrong file — fall back instead."""
        from ide4eeg.download_tools import (
            _resolve_mpv_url_linux, _MPV_LINUX_FALLBACK_URL)
        payload = {
            "tag_name": "v0.99.0@stub",
            "assets": [
                {"name": "mpv-v0.99.0-anylinux-aarch64.AppImage",
                 "browser_download_url": "https://example/aarch64"},
                {"name": "mpv-v0.99.0-anylinux-x86_64.AppImage.zsync",
                 "browser_download_url": "https://example/zsync"},
            ],
        }
        with patch("ide4eeg.download_tools._open_url",
                   return_value=self._api_response(payload)):
            assert _resolve_mpv_url_linux() == _MPV_LINUX_FALLBACK_URL

    def test_download_mpv_uses_resolver_on_linux(self, tmp_path):
        """download_mpv() with no env override must query the resolver
        for the Linux URL — we don't want the static URL pattern back."""
        from ide4eeg.download_tools import download_mpv
        with patch("ide4eeg.download_tools._os_tag", return_value="linux-x64"), \
             patch("ide4eeg.download_tools.platform.system", return_value="Linux"), \
             patch.dict("os.environ", {}, clear=False) as env, \
             patch("ide4eeg.download_tools._resolve_mpv_url_linux",
                   return_value="https://example/resolved.AppImage") as resolver, \
             patch("ide4eeg.download_tools._install_mpv_appimage") as installer:
            env.pop("IDE4EEG_MPV_URL", None)
            # Make the installer write the binary the dispatcher expects.
            def fake_install(url, dest_path, progress_callback):
                dest_path.write_text("#!/bin/sh\n")
                dest_path.chmod(0o755)
            installer.side_effect = fake_install
            download_mpv(target_dir=tmp_path / "mpv", force=True)
        resolver.assert_called_once()
        # The installer was called with the resolver's URL, not the
        # fallback / hardpin / a stale static value.
        assert installer.call_args[0][0] == "https://example/resolved.AppImage"


class TestMacosMpvStatus:
    """macos_mpv_status() — detect-before-prompt helper used by the GUI."""

    def test_not_applicable_off_macos(self):
        from ide4eeg.download_tools import macos_mpv_status
        with patch("ide4eeg.download_tools._os_tag", return_value="linux-x64"):
            status, detail = macos_mpv_status()
        assert status == "not-applicable"
        assert detail is None

    def test_installed_when_mpv_on_path(self):
        from ide4eeg.download_tools import macos_mpv_status
        with patch("ide4eeg.download_tools._os_tag", return_value="macos-arm64"), \
             patch("ide4eeg.download_tools.shutil.which", return_value="/opt/homebrew/bin/mpv"):
            status, detail = macos_mpv_status()
        assert status == "installed"
        assert detail == "/opt/homebrew/bin/mpv"

    def test_brew_available_when_mpv_missing(self):
        from ide4eeg.download_tools import macos_mpv_status
        with patch("ide4eeg.download_tools._os_tag", return_value="macos-arm64"), \
             patch("ide4eeg.download_tools.shutil.which", return_value=None), \
             patch("ide4eeg.download_tools._macos_brew_path",
                   return_value="/opt/homebrew/bin/brew"):
            status, detail = macos_mpv_status()
        assert status == "brew-available"
        assert detail == "/opt/homebrew/bin/brew"

    def test_no_brew_when_neither_present(self):
        from ide4eeg.download_tools import macos_mpv_status
        with patch("ide4eeg.download_tools._os_tag", return_value="macos-arm64"), \
             patch("ide4eeg.download_tools.shutil.which", return_value=None), \
             patch("ide4eeg.download_tools._macos_brew_path", return_value=None):
            status, detail = macos_mpv_status()
        assert status == "no-brew"
        assert detail is None


class TestDownloadMpvMacos:
    """download_mpv() on macOS: detect → optionally prompt → optionally brew."""

    def _patch_macos(self, mpv_on_path=None, brew_at=None):
        """Return a context-manager-like list of patches mocking the
        macOS environment. Caller wraps with contextlib.ExitStack."""
        from contextlib import ExitStack
        stack = ExitStack()
        stack.enter_context(patch(
            "ide4eeg.download_tools._os_tag", return_value="macos-arm64"))
        stack.enter_context(patch(
            "ide4eeg.download_tools.shutil.which", return_value=mpv_on_path))
        stack.enter_context(patch(
            "ide4eeg.download_tools._macos_brew_path", return_value=brew_at))
        return stack

    def test_returns_path_when_mpv_already_installed(self):
        """If mpv is on PATH, return that path immediately — no prompt,
        no subprocess."""
        from ide4eeg.download_tools import download_mpv
        with self._patch_macos(mpv_on_path="/opt/homebrew/bin/mpv"):
            # callback should NOT be invoked because nothing needs installing
            callback = MagicMock()
            result = download_mpv(confirm_brew_install=callback)
        assert result == "/opt/homebrew/bin/mpv"
        callback.assert_not_called()

    def test_no_brew_returns_none_silently(self):
        from ide4eeg.download_tools import download_mpv
        with self._patch_macos(mpv_on_path=None, brew_at=None):
            callback = MagicMock(return_value=True)
            result = download_mpv(confirm_brew_install=callback)
        assert result is None
        callback.assert_not_called()  # nothing to consent to

    def test_brew_available_no_callback_skips(self):
        """Without an explicit consent callback, we never run brew —
        even though we could. Auto-install requires opt-in."""
        from ide4eeg.download_tools import download_mpv
        with self._patch_macos(mpv_on_path=None, brew_at="/opt/homebrew/bin/brew"):
            with patch("ide4eeg.download_tools._macos_brew_install_mpv") as installer:
                result = download_mpv()  # no confirm_brew_install
        assert result is None
        installer.assert_not_called()

    def test_brew_available_callback_declines(self):
        from ide4eeg.download_tools import download_mpv
        with self._patch_macos(mpv_on_path=None, brew_at="/opt/homebrew/bin/brew"):
            with patch("ide4eeg.download_tools._macos_brew_install_mpv") as installer:
                callback = MagicMock(return_value=False)
                result = download_mpv(confirm_brew_install=callback)
        assert result is None
        callback.assert_called_once_with("/opt/homebrew/bin/brew")
        installer.assert_not_called()

    def test_brew_available_callback_consents_runs_brew(self):
        """Consent → _macos_brew_install_mpv invoked with brew path,
        and its return value is propagated."""
        from ide4eeg.download_tools import download_mpv
        with self._patch_macos(mpv_on_path=None, brew_at="/opt/homebrew/bin/brew"):
            with patch("ide4eeg.download_tools._macos_brew_install_mpv",
                       return_value="/opt/homebrew/bin/mpv") as installer:
                callback = MagicMock(return_value=True)
                result = download_mpv(confirm_brew_install=callback)
        assert result == "/opt/homebrew/bin/mpv"
        callback.assert_called_once_with("/opt/homebrew/bin/brew")
        installer.assert_called_once_with("/opt/homebrew/bin/brew")

    def test_callback_exception_treated_as_decline(self):
        """If the consent callback raises (e.g. dialog system breakage),
        we should treat it as a decline rather than crashing the whole
        download flow."""
        from ide4eeg.download_tools import download_mpv
        with self._patch_macos(mpv_on_path=None, brew_at="/opt/homebrew/bin/brew"):
            with patch("ide4eeg.download_tools._macos_brew_install_mpv") as installer:
                callback = MagicMock(side_effect=RuntimeError("dialog crashed"))
                result = download_mpv(confirm_brew_install=callback)
        assert result is None
        installer.assert_not_called()


class TestMacosBrewInstallMpv:
    """_macos_brew_install_mpv() — actually shells out to brew."""

    def test_success_returns_path_from_which(self, tmp_path):
        from ide4eeg.download_tools import _macos_brew_install_mpv
        completed = MagicMock(returncode=0, stdout="installed", stderr="")
        with patch("ide4eeg.download_tools.subprocess.run",
                   return_value=completed) as run, \
             patch("ide4eeg.download_tools.shutil.which",
                   return_value="/opt/homebrew/bin/mpv"):
            result = _macos_brew_install_mpv("/opt/homebrew/bin/brew")
        run.assert_called_once()
        args, _kw = run.call_args
        assert args[0] == ["/opt/homebrew/bin/brew", "install", "mpv"]
        assert result == "/opt/homebrew/bin/mpv"

    def test_success_falls_back_to_brew_prefix_when_path_stale(self, tmp_path):
        """shutil.which may not see the brand-new install if Python's
        environment $PATH is stale — fall back to <brew_prefix>/bin/mpv."""
        from ide4eeg.download_tools import _macos_brew_install_mpv
        # Build a fake brew prefix layout under tmp_path
        prefix = tmp_path / "homebrew"
        (prefix / "bin").mkdir(parents=True)
        brew = prefix / "bin" / "brew"
        brew.write_text("#!/bin/sh\n"); brew.chmod(0o755)
        mpv = prefix / "bin" / "mpv"
        mpv.write_text("#!/bin/sh\n"); mpv.chmod(0o755)

        completed = MagicMock(returncode=0, stdout="ok", stderr="")
        with patch("ide4eeg.download_tools.subprocess.run", return_value=completed), \
             patch("ide4eeg.download_tools.shutil.which", return_value=None):
            result = _macos_brew_install_mpv(str(brew))
        assert result == str(mpv)

    def test_nonzero_exit_returns_none(self):
        from ide4eeg.download_tools import _macos_brew_install_mpv
        completed = MagicMock(returncode=1, stdout="", stderr="formula not found")
        with patch("ide4eeg.download_tools.subprocess.run", return_value=completed):
            result = _macos_brew_install_mpv("/opt/homebrew/bin/brew")
        assert result is None

    def test_timeout_returns_none(self):
        import subprocess
        from ide4eeg.download_tools import _macos_brew_install_mpv
        with patch("ide4eeg.download_tools.subprocess.run",
                   side_effect=subprocess.TimeoutExpired(cmd="brew", timeout=600)):
            result = _macos_brew_install_mpv("/opt/homebrew/bin/brew")
        assert result is None

    def test_brew_missing_returns_none(self):
        from ide4eeg.download_tools import _macos_brew_install_mpv
        with patch("ide4eeg.download_tools.subprocess.run",
                   side_effect=OSError("brew vanished")):
            result = _macos_brew_install_mpv("/opt/homebrew/bin/brew")
        assert result is None


class TestMacosBrewPath:
    """_macos_brew_path() — locate the Homebrew binary."""

    def test_apple_silicon_default(self, tmp_path):
        """Both default install prefixes are checked; Apple Silicon
        path returns when present."""
        from ide4eeg.download_tools import _macos_brew_path
        with patch("ide4eeg.download_tools.os.path.isfile",
                   side_effect=lambda p: p == "/opt/homebrew/bin/brew"), \
             patch("ide4eeg.download_tools.os.access", return_value=True):
            result = _macos_brew_path()
        assert result == "/opt/homebrew/bin/brew"

    def test_intel_default_fallback(self):
        from ide4eeg.download_tools import _macos_brew_path
        with patch("ide4eeg.download_tools.os.path.isfile",
                   side_effect=lambda p: p == "/usr/local/bin/brew"), \
             patch("ide4eeg.download_tools.os.access", return_value=True):
            result = _macos_brew_path()
        assert result == "/usr/local/bin/brew"

    def test_path_lookup_when_no_default(self):
        """Non-default install (e.g. ~/.brew) — fall back to PATH."""
        from ide4eeg.download_tools import _macos_brew_path
        with patch("ide4eeg.download_tools.os.path.isfile", return_value=False), \
             patch("ide4eeg.download_tools.shutil.which",
                   return_value="/Users/me/.brew/bin/brew"):
            result = _macos_brew_path()
        assert result == "/Users/me/.brew/bin/brew"

    def test_returns_none_when_brew_absent(self):
        from ide4eeg.download_tools import _macos_brew_path
        with patch("ide4eeg.download_tools.os.path.isfile", return_value=False), \
             patch("ide4eeg.download_tools.shutil.which", return_value=None):
            result = _macos_brew_path()
        assert result is None


# ── Java detection + install plan ─────────────────────────────────────


class TestDetectJava:
    """detect_java() — parse `java -version` output."""

    def _patch_run(self, returncode=0, stdout="", stderr="",
                   raise_exc=None):
        """Convenience: patch subprocess.run to return a fake completed
        process or raise the given exception."""
        if raise_exc is not None:
            return patch("ide4eeg.download_tools.subprocess.run",
                         side_effect=raise_exc)
        completed = MagicMock(returncode=returncode,
                              stdout=stdout, stderr=stderr)
        return patch("ide4eeg.download_tools.subprocess.run",
                     return_value=completed)

    def test_modern_java_on_path(self):
        """OpenJDK 17 stderr: openjdk version "17.0.9" 2023-10-17"""
        from ide4eeg.download_tools import detect_java
        with self._patch_run(stderr='openjdk version "17.0.9" 2023-10-17\n'
                                    'OpenJDK Runtime Environment ...'):
            status, detail = detect_java()
        assert status == "ok"
        assert detail == "17.0.9"

    def test_java_8_format(self):
        """Java 8 reports "1.8.0_392" — major must be normalized to 8."""
        from ide4eeg.download_tools import detect_java
        with self._patch_run(stderr='java version "1.8.0_392"\n'):
            status, detail = detect_java()
        assert status == "ok"
        assert detail == "1.8.0_392"

    def test_java_too_old(self):
        """Pre-Java-8 (1.7 / 1.6) is unsupported by Svarog."""
        from ide4eeg.download_tools import detect_java
        with self._patch_run(stderr='java version "1.7.0_80"\n'):
            status, detail = detect_java()
        assert status == "too-old"
        assert detail == 7

    def test_no_java_on_path(self):
        from ide4eeg.download_tools import detect_java
        with self._patch_run(raise_exc=FileNotFoundError("java")):
            status, detail = detect_java()
        assert status == "missing"
        assert detail is None

    def test_garbled_output(self):
        """If `java -version` returns text we can't parse, treat as
        missing rather than crash."""
        from ide4eeg.download_tools import detect_java
        with self._patch_run(stderr="who knows what this is"):
            status, detail = detect_java()
        assert status == "missing"

    def test_timeout_treated_as_missing(self):
        import subprocess as _sp
        from ide4eeg.download_tools import detect_java
        with self._patch_run(raise_exc=_sp.TimeoutExpired(
                cmd="java", timeout=5)):
            status, detail = detect_java()
        assert status == "missing"


class TestJavaInstallPlan:
    """java_install_plan() dispatch by platform + installer
    availability."""

    def test_ok_when_java_already_installed(self):
        from ide4eeg.download_tools import java_install_plan
        with patch("ide4eeg.download_tools.detect_java",
                   return_value=("ok", "17.0.9")):
            plan, detail = java_install_plan()
        assert plan == "ok"
        assert detail == "17.0.9"

    def test_macos_with_brew(self):
        from ide4eeg.download_tools import java_install_plan
        with patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools.platform.system",
                   return_value="Darwin"), \
             patch("ide4eeg.download_tools._macos_brew_path",
                   return_value="/opt/homebrew/bin/brew"):
            plan, detail = java_install_plan()
        assert plan == "auto-mac"
        brew, cmd = detail
        assert brew == "/opt/homebrew/bin/brew"
        assert "install --cask temurin" in cmd

    def test_macos_without_brew(self):
        from ide4eeg.download_tools import java_install_plan
        with patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools.platform.system",
                   return_value="Darwin"), \
             patch("ide4eeg.download_tools._macos_brew_path",
                   return_value=None):
            plan, detail = java_install_plan()
        assert plan == "manual-mac"
        assert detail.startswith("https://adoptium")

    def test_windows_with_winget(self):
        from ide4eeg.download_tools import java_install_plan
        with patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools.platform.system",
                   return_value="Windows"), \
             patch("ide4eeg.download_tools._windows_winget_path",
                   return_value="C:\\Path\\winget.exe"):
            plan, detail = java_install_plan()
        assert plan == "auto-windows"
        winget, cmd = detail
        assert winget == "C:\\Path\\winget.exe"
        assert "EclipseAdoptium.Temurin.17.JDK" in cmd
        assert "--scope user" in cmd

    def test_windows_without_winget(self):
        from ide4eeg.download_tools import java_install_plan
        with patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools.platform.system",
                   return_value="Windows"), \
             patch("ide4eeg.download_tools._windows_winget_path",
                   return_value=None):
            plan, detail = java_install_plan()
        assert plan == "manual-windows"

    def test_linux_with_apt(self):
        from ide4eeg.download_tools import java_install_plan
        with patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools.platform.system",
                   return_value="Linux"), \
             patch("ide4eeg.download_tools._linux_pkg_install_cmd",
                   return_value=("apt", "sudo apt install openjdk-17-jdk")):
            plan, detail = java_install_plan()
        assert plan == "manual-linux"
        pkg_mgr, cmd = detail
        assert pkg_mgr == "apt"
        assert "openjdk-17-jdk" in cmd

    def test_linux_unknown_distro(self):
        from ide4eeg.download_tools import java_install_plan
        with patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools.platform.system",
                   return_value="Linux"), \
             patch("ide4eeg.download_tools._linux_pkg_install_cmd",
                   return_value=(None, None)):
            plan, detail = java_install_plan()
        assert plan == "manual-linux-unknown"
        assert detail.startswith("https://adoptium")


class TestInstallJava:
    """install_java() — top-level flow with consent callback."""

    def test_returns_ok_when_already_installed(self):
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("ok", "17.0.9")):
            status, detail = install_java(confirm_callback=MagicMock())
        assert status == "ok"
        assert detail == "17.0.9"

    def test_no_callback_returns_declined(self):
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-mac", ("/brew", "/brew install --cask temurin"))):
            status, detail = install_java(confirm_callback=None)
        assert status == "declined"

    def test_macos_callback_declines(self):
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-mac", ("/brew", "cmd"))), \
             patch("ide4eeg.download_tools._macos_brew_install_java") as installer:
            cb = MagicMock(return_value=False)
            status, detail = install_java(confirm_callback=cb)
        assert status == "declined"
        installer.assert_not_called()

    def test_macos_callback_consents_then_succeeds(self):
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-mac", ("/brew", "cmd"))), \
             patch("ide4eeg.download_tools._macos_brew_install_java",
                   return_value=True), \
             patch("ide4eeg.download_tools.detect_java",
                   return_value=("ok", "17.0.9")):
            cb = MagicMock(return_value=True)
            status, detail = install_java(confirm_callback=cb)
        assert status == "installed"
        assert detail == "17.0.9"

    def test_macos_brew_install_fails(self):
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-mac", ("/brew", "cmd"))), \
             patch("ide4eeg.download_tools._macos_brew_install_java",
                   return_value=False):
            cb = MagicMock(return_value=True)
            status, detail = install_java(confirm_callback=cb)
        assert status == "failed"

    def test_windows_install_succeeds_path_stale(self):
        """Windows: PATH staleness means detect_java() still misses
        the new install, but the canonical-location probe finds it."""
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-windows", ("C:\\winget.exe", "cmd"))), \
             patch("ide4eeg.download_tools._windows_winget_install_java",
                   return_value=True), \
             patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools._windows_find_temurin_java",
                   return_value="C:\\...\\Temurin\\jdk-17\\bin\\java.exe"), \
             patch("ide4eeg.download_tools._verify_java_path",
                   return_value="17.0.9"):
            cb = MagicMock(return_value=True)
            status, detail = install_java(confirm_callback=cb)
        assert status == "installed"
        assert "17.0.9" in detail
        assert "restart" in detail.lower()  # tells user to restart GUI

    def test_windows_install_succeeds_path_picks_up(self):
        """Windows: rare case where PATH already includes the install
        location (e.g. previous JDK install). detect_java works."""
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-windows", ("C:\\winget.exe", "cmd"))), \
             patch("ide4eeg.download_tools._windows_winget_install_java",
                   return_value=True), \
             patch("ide4eeg.download_tools.detect_java",
                   return_value=("ok", "17.0.9")):
            cb = MagicMock(return_value=True)
            status, detail = install_java(confirm_callback=cb)
        assert status == "installed"
        assert detail == "17.0.9"

    def test_windows_install_fails_no_probe_match(self):
        """Windows: winget reports success but neither PATH nor
        canonical location finds java. Distinct failure mode."""
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-windows", ("C:\\winget.exe", "cmd"))), \
             patch("ide4eeg.download_tools._windows_winget_install_java",
                   return_value=True), \
             patch("ide4eeg.download_tools.detect_java",
                   return_value=("missing", None)), \
             patch("ide4eeg.download_tools._windows_find_temurin_java",
                   return_value=None):
            cb = MagicMock(return_value=True)
            status, detail = install_java(confirm_callback=cb)
        assert status == "failed"

    def test_callback_exception_treated_as_decline(self):
        """If the consent dialog itself crashes, we should treat as
        decline rather than crash the whole download."""
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("auto-mac", ("/brew", "cmd"))), \
             patch("ide4eeg.download_tools._macos_brew_install_java") as installer:
            cb = MagicMock(side_effect=RuntimeError("dialog crashed"))
            status, detail = install_java(confirm_callback=cb)
        assert status == "declined"
        installer.assert_not_called()

    def test_manual_linux_returns_declined(self):
        """manual-linux: caller (GUI) shows install instructions —
        install_java itself doesn't run sudo for them."""
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan",
                   return_value=("manual-linux",
                                 ("apt", "sudo apt install openjdk-17-jdk"))):
            status, detail = install_java(confirm_callback=lambda: True)
        assert status == "declined"
        plan, info = detail
        assert plan == "manual-linux"

    def test_pre_computed_plan_skips_redundant_detect(self):
        """When the GUI passes the already-computed plan, install_java
        must not call java_install_plan() again — saves a duplicate
        java -version subprocess on the no-op path."""
        from ide4eeg.download_tools import install_java
        with patch("ide4eeg.download_tools.java_install_plan") as fn:
            status, detail = install_java(
                confirm_callback=None,
                plan=("ok", "17.0.9"))
        fn.assert_not_called()
        assert status == "ok"
        assert detail == "17.0.9"


class TestWindowsTemurinProbe:
    """_windows_find_temurin_java() — PATH-staleness workaround."""

    def test_finds_jdk_in_canonical_location(self, tmp_path):
        # Build a fake LOCALAPPDATA tree:
        # tmp/Programs/Eclipse Adoptium/jdk-17.0.9-hotspot/bin/java.exe
        adoptium = tmp_path / "Programs" / "Eclipse Adoptium" / "jdk-17.0.9-hotspot" / "bin"
        adoptium.mkdir(parents=True)
        java_exe = adoptium / "java.exe"
        java_exe.write_text("fake")
        from ide4eeg.download_tools import _windows_find_temurin_java
        with patch.dict("os.environ", {"LOCALAPPDATA": str(tmp_path)}):
            result = _windows_find_temurin_java()
        assert result == str(java_exe)

    def test_picks_newer_when_multiple(self, tmp_path):
        """If multiple JDKs are installed, return the lexically last
        (good enough proxy for newest)."""
        for ver in ("jdk-11.0.20-hotspot", "jdk-17.0.9-hotspot",
                    "jdk-21.0.2-hotspot"):
            d = tmp_path / "Programs" / "Eclipse Adoptium" / ver / "bin"
            d.mkdir(parents=True)
            (d / "java.exe").write_text("fake")
        from ide4eeg.download_tools import _windows_find_temurin_java
        with patch.dict("os.environ", {"LOCALAPPDATA": str(tmp_path)}):
            result = _windows_find_temurin_java()
        assert "jdk-21.0.2-hotspot" in result

    def test_returns_none_when_no_install(self, tmp_path):
        from ide4eeg.download_tools import _windows_find_temurin_java
        with patch.dict("os.environ", {"LOCALAPPDATA": str(tmp_path)}):
            result = _windows_find_temurin_java()
        assert result is None

    def test_returns_none_when_localappdata_unset(self):
        from ide4eeg.download_tools import _windows_find_temurin_java
        with patch.dict("os.environ", {}, clear=True):
            result = _windows_find_temurin_java()
        assert result is None


class TestVerifyJavaPath:
    """_verify_java_path() — direct version probe of an explicit path."""

    def test_valid_modern_java(self):
        from ide4eeg.download_tools import _verify_java_path
        completed = MagicMock(returncode=0,
                              stdout="",
                              stderr='openjdk version "17.0.9"\n')
        with patch("ide4eeg.download_tools.subprocess.run",
                   return_value=completed):
            result = _verify_java_path("/fake/java")
        assert result == "17.0.9"

    def test_too_old_returns_none(self):
        from ide4eeg.download_tools import _verify_java_path
        completed = MagicMock(returncode=0,
                              stdout="",
                              stderr='java version "1.6.0_45"\n')
        with patch("ide4eeg.download_tools.subprocess.run",
                   return_value=completed):
            result = _verify_java_path("/fake/java")
        assert result is None  # below floor

    def test_unparseable_returns_none(self):
        from ide4eeg.download_tools import _verify_java_path
        completed = MagicMock(returncode=0, stdout="", stderr="garbled")
        with patch("ide4eeg.download_tools.subprocess.run",
                   return_value=completed):
            result = _verify_java_path("/fake/java")
        assert result is None

    def test_oserror_returns_none(self):
        from ide4eeg.download_tools import _verify_java_path
        with patch("ide4eeg.download_tools.subprocess.run",
                   side_effect=OSError("boom")):
            result = _verify_java_path("/fake/java")
        assert result is None


class TestLinuxPkgInstallCmd:
    """_linux_pkg_install_cmd() — picks the first available pkg manager."""

    def test_apt_wins_when_present(self):
        from ide4eeg.download_tools import _linux_pkg_install_cmd
        # apt is first in the table; if available, return it
        def which(name):
            return f"/usr/bin/{name}" if name == "apt" else None
        with patch("ide4eeg.download_tools.shutil.which",
                   side_effect=which):
            pkg, cmd = _linux_pkg_install_cmd()
        assert pkg == "apt"
        assert "openjdk-17-jdk" in cmd

    def test_dnf_when_apt_missing(self):
        from ide4eeg.download_tools import _linux_pkg_install_cmd
        def which(name):
            return f"/usr/bin/{name}" if name == "dnf" else None
        with patch("ide4eeg.download_tools.shutil.which",
                   side_effect=which):
            pkg, cmd = _linux_pkg_install_cmd()
        assert pkg == "dnf"
        assert "java-17-openjdk-devel" in cmd

    def test_no_pkg_mgr(self):
        from ide4eeg.download_tools import _linux_pkg_install_cmd
        with patch("ide4eeg.download_tools.shutil.which",
                   return_value=None):
            pkg, cmd = _linux_pkg_install_cmd()
        assert pkg is None
        assert cmd is None
