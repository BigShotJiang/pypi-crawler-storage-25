"""Script export end-to-end round-trip.

Build a cfg via ``run_file`` kwargs → generate a standalone script via
``api.generate_script`` → execute the script in a fresh subprocess →
diff its produced output against the original run.

Existing ``tests/test_script_export.py`` checks the script is valid
Python and contains the right kwargs.  This file goes one step
further: it actually runs the generated script and asserts identical
numerical output.  Catches the bug class where ``generate_script``
silently drops a load-bearing kwarg (the ``_picked_atoms``,
``video_reference_dir``, ``_mp_book_path`` history of fixes).

Rewired in 2026-05-14 to use ``dipole_spindles`` (the previous
``simulated_data`` example was retired on main in 76a6373).  To keep
wall time acceptable for an in-loop test we truncate the rest window
to one segment and disable the dipole-fit + MP-filter analyses;
preprocessing + MP decomposition still run, which is where the
historical kwarg-drop bugs lived.  Gated behind ``RUN_SLOW_GOLDENS=1``
alongside :file:`tests/test_pipeline_golden.py`.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tomllib
from pathlib import Path

import pytest


_EXAMPLES = Path.home() / "IDE4EEG_examples" / "dipole_spindles"
_INPUT_PATH = _EXAMPLES / "dipoles_example.raw"
_CFG_PATH = _EXAMPLES / "config_dipole_spindles.toml"

_RUN_SLOW = os.environ.get("RUN_SLOW_GOLDENS") == "1"


@pytest.fixture(autouse=True)
def _require_example_data():
    if not _RUN_SLOW:
        pytest.skip("Set RUN_SLOW_GOLDENS=1 to enable.")
    if not _INPUT_PATH.is_file():
        pytest.skip(
            f"Example data not at {_INPUT_PATH}; "
            f"run `python -m ide4eeg.download_examples dipole_spindles`.")


def test_generated_script_executes_and_produces_same_output(tmp_path):
    """End-to-end: API run, then export-and-execute, then diff output dirs.

    The script subprocess uses the project's own venv Python and the
    same ide4eeg package the test runs in — so the test is independent
    of any system Python differences.
    """
    from ide4eeg.api import generate_script, run_file
    from ide4eeg.gui_config import DEFAULT_CONFIG

    with open(_CFG_PATH, "rb") as f:
        kwargs = {k: v for k, v in tomllib.load(f).items()
                  if k not in ("input_path", "output_path")}
    # Truncate to one 20-s rest window and disable the slow analyses
    # so the round-trip lands in well under a minute.  The script
    # export path still exercises preprocessing + MP decomposition,
    # which is where the historical kwarg-drop bugs lived.
    kwargs["rest"] = {**kwargs.get("rest", {}), "rest_duration": [0, 20]}
    kwargs["prepare_dipole_fitting"] = False
    kwargs["prepare_mp_filter"] = False

    # ── Run 1: direct run_file ──────────────────────────────────
    out_direct = tmp_path / "direct"
    cfg_direct = dict(DEFAULT_CONFIG)
    cfg_direct.update(kwargs)
    cfg_direct["input_path"] = str(_INPUT_PATH)
    cfg_direct["output_path"] = str(out_direct)
    run_file(str(_INPUT_PATH), output_path=str(out_direct), **kwargs)

    # ── Run 2: generate script → execute it ─────────────────────
    out_script = tmp_path / "via_script"
    cfg_for_export = dict(cfg_direct)
    cfg_for_export["output_path"] = str(out_script)
    repo_root = str(Path(__file__).resolve().parents[1])
    script_src = generate_script(
        cfg_for_export, DEFAULT_CONFIG, repo_path=repo_root)

    script_path = tmp_path / "exported.py"
    script_path.write_text(script_src)

    result = subprocess.run(
        [sys.executable, str(script_path)],
        capture_output=True, text=True, timeout=180,
    )
    assert result.returncode == 0, (
        f"Generated script failed:\nSTDOUT:\n{result.stdout}\n"
        f"STDERR:\n{result.stderr[-2000:]}")

    # ── Compare numerical outputs ───────────────────────────────
    # FIF files carry a timestamp in their info["meas_date"] preamble
    # that differs across runs even on identical signal data, so a raw
    # byte hash would diverge.  Check structural equivalence
    # (same set of relative paths) plus content equality for non-FIF
    # artifacts (CSV / JSON / TXT round-trip deterministically).
    paths_direct = sorted(
        p.relative_to(out_direct).as_posix()
        for p in out_direct.rglob("*") if p.is_file())
    paths_script = sorted(
        p.relative_to(out_script).as_posix()
        for p in out_script.rglob("*") if p.is_file())
    assert paths_direct == paths_script, (
        "Generated-script run produced a different file set than the "
        f"direct API run.\n  direct only: {set(paths_direct)-set(paths_script)}\n"
        f"  script only: {set(paths_script)-set(paths_direct)}")

    # For non-FIF files (CSV, JSON if any), content must match.
    for rel in paths_direct:
        if rel.endswith((".csv", ".json", ".txt")):
            content_direct = (out_direct / rel).read_text()
            content_script = (out_script / rel).read_text()
            assert content_direct == content_script, (
                f"Content diverged in {rel}\n"
                f"  direct:\n{content_direct[:500]}\n"
                f"  script:\n{content_script[:500]}")
