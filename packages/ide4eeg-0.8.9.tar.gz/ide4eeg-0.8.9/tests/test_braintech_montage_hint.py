"""Tests for the BrainTech ``eegSystemSymbol`` → Montage-combo hint.

readmanager 1.6.0 added ``rm.get_param("eeg_system_symbol")``, which
returns the cap layout name (e.g. ``"EEG_10_20"``) from the BrainTech
XML's ``<rs:eegSystemName><rs:eegSystemSymbol>`` element. IDE4EEG maps
known symbols onto its Montage-combo display names so the GUI can
prefill the dropdown when a ``.raw`` file is loaded.
"""

from unittest.mock import MagicMock, patch

import pytest

from ide4eeg.input.input import _resolve_braintech_montage_hint


def _rm_with_symbol(symbol):
    """Return a stub ReadManager that returns ``symbol`` for the
    ``eeg_system_symbol`` param and raises for everything else."""
    rm = MagicMock()
    def get_param(name):
        if name == "eeg_system_symbol":
            return symbol
        raise KeyError(name)
    rm.get_param.side_effect = get_param
    return rm


@pytest.mark.parametrize("symbol,expected", [
    ("EEG_10_20", "10-20"),
    ("EEG_10_10", "10-10"),
    ("EEG_10_05", "10-05"),
])
def test_known_symbols_map_to_combo_labels(symbol, expected):
    rm = _rm_with_symbol(symbol)
    assert _resolve_braintech_montage_hint(rm) == expected


def test_whitespace_around_symbol_is_stripped():
    """Real-world XMLs sometimes have leading/trailing whitespace from
    XML pretty-printing — strip before lookup so we don't miss a hit."""
    rm = _rm_with_symbol("  EEG_10_20\n")
    assert _resolve_braintech_montage_hint(rm) == "10-20"


@pytest.mark.parametrize("symbol", [
    "EEG GENERIC",        # observed in dipole_spindles example
    "EEG_BIOSEMI_64",     # plausible non-10-X cap
    "",                   # falsy → no hint
    None,                 # explicit None
    "completely unknown",
])
def test_unmapped_symbols_yield_none(symbol):
    rm = _rm_with_symbol(symbol)
    assert _resolve_braintech_montage_hint(rm) is None


def test_missing_param_yields_none():
    """Older XMLs (pre-eegSystemName) make readmanager raise — must
    degrade silently to None, not propagate the exception."""
    rm = MagicMock()
    rm.get_param.side_effect = KeyError("eeg_system_symbol")
    assert _resolve_braintech_montage_hint(rm) is None


def test_empty_element_crash_is_swallowed():
    """readmanager 1.6.0 crashes with AttributeError on
    ``firstChild.nodeValue`` when the XML element is self-closing
    (``<rs:eegSystemSymbol/>``). The hint resolver must catch that —
    failing the whole signal load just because a hint can't be read
    would be unacceptable."""
    rm = MagicMock()
    rm.get_param.side_effect = AttributeError(
        "'NoneType' object has no attribute 'nodeValue'")
    assert _resolve_braintech_montage_hint(rm) is None


def _example_base_path():
    """Path to the dipole_spindles example file stem (without
    extension).  Resolves against ``~/IDE4EEG_examples/``, the
    canonical example-data location (post 2026-05-16 relocation).
    Tests skip cleanly when the data isn't downloaded."""
    from pathlib import Path
    return Path.home() / "IDE4EEG_examples" / "dipole_spindles" / \
        "dipoles_example"


def test_real_example_file_returns_none():
    """The dipole_spindles example XML has ``EEG GENERIC`` — should
    produce no hint, but must not crash. Skipped if the example data
    isn't downloaded."""
    base = _example_base_path()
    if not base.with_suffix(".xml").exists():
        pytest.skip("example XML not present "
                    "(run `python -m ide4eeg.download_examples "
                    "dipole_spindles`)")
    from obci_readmanager.signal_processing.read_manager import ReadManager
    rm = ReadManager(str(base) + ".xml", str(base) + ".raw", "")
    assert _resolve_braintech_montage_hint(rm) is None


def test_metadata_path_includes_hint_field():
    """``read_file_info`` for a BrainTech .raw must surface a
    ``montage_hint`` key in its result dict — even when None — so the
    GUI doesn't have to special-case the absent-key case."""
    base = _example_base_path()
    if not base.with_suffix(".raw").exists():
        pytest.skip("example .raw not present "
                    "(run `python -m ide4eeg.download_examples "
                    "dipole_spindles`)")
    from ide4eeg.input.input import read_file_info
    info = read_file_info(str(base) + ".raw")
    assert info is not None
    assert "montage_hint" in info
    assert info["montage_hint"] is None  # EEG GENERIC → no hint
