"""Event-name sanitization regression test for GitLab issue #15.

BrainVision ``.vmrk`` sidecars use the ``Mk370=Stimulus,S 17,...``
format; MNE renders this as the annotation description
``"Stimulus/S 17"``.  The slash is a path separator on every
platform we ship to.  Pre-fix, the MNE catalog's filename
builders interpolated raw ``tag`` strings into ``os.path.join``
output paths and ``f"..."`` patterns -- with these inputs that
silently writes to ``output/Stimulus/S 17.png`` (unintended
subdirectory on macOS/Linux) or crashes (Windows, missing
``\\Stimulus\\`` directory).

The fix uses the existing ``_safe_tag`` helper from
``ide4eeg.analysis`` (already wired through
``connectivity_analysis`` and ``mp_analysis``) at the four
remaining callsites in ``mne_catalog.py``.

This test pins all five filename-building functions for
``"Stimulus/S 17"`` style tags without exercising the full
pipeline (no Epochs, no MNE plot machinery -- just the path
construction).  A regression would re-introduce a ``/`` into
the produced filename and fail the assertion.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from ide4eeg.analysis import _safe_tag


# Canonical bug-triggering tag from BrainVision .vmrk parsing.
_BAD_TAG = "Stimulus/S 17"


def test_safe_tag_replaces_slash():
    """Sanity: the helper itself replaces ``/`` with ``_``."""
    assert _safe_tag(_BAD_TAG) == "Stimulus_S 17"
    # Multiple slashes all get replaced.
    assert _safe_tag("a/b/c") == "a_b_c"
    # No-op when no slash.
    assert _safe_tag("clean") == "clean"


def test_safe_tag_preserves_spaces():
    """Spaces are valid in filenames on all supported platforms;
    only ``/`` is the path-component breaker.  The helper must NOT
    over-sanitise."""
    assert " " in _safe_tag(_BAD_TAG)


def test_save_csv_filename_safe(tmp_path, monkeypatch):
    """``_maybe_save_csv`` must never write to a subdirectory of
    ``mne_dir`` named after the tag's first slash-component."""
    from ide4eeg.analysis import mne_catalog

    captured: dict[str, str] = {}

    class _StubSpec:
        def to_data_frame(self):
            import pandas as pd
            return pd.DataFrame({"x": [1, 2]})

    # Intercept the actual file write so we read the *intended* path
    # without depending on pandas/csv internals.
    real_to_csv = None
    import pandas as pd

    def _capture_csv(self, path, **kw):
        captured["path"] = path
        # Still create the file so downstream code doesn't bork.
        Path(path).write_text("noop")

    monkeypatch.setattr(pd.DataFrame, "to_csv", _capture_csv)

    mne_catalog._maybe_save_csv(
        _StubSpec(), {"save_csv": True},
        str(tmp_path), "subj01", "psd_welch", _BAD_TAG)

    path = captured["path"]
    # The bug shape: ``/`` in tag would put 'Stimulus/' as a
    # subdirectory in the path.  Post-fix: the tag's slash is gone.
    assert "Stimulus_S 17" in path, (
        f"sanitised tag missing from path: {path}")
    # And the resulting filename has no slash component beyond the
    # tmp_path -- compare relative path component count to baseline.
    rel = os.path.relpath(path, tmp_path)
    assert "/" not in rel and "\\" not in rel, (
        f"tag-induced path separator leaked into filename: {rel}")


def test_save_figure_filename_safe(tmp_path):
    """``_save`` is the most-called sink; matplotlib figures from
    every ERP/PSD/TFR analysis pass tags through it."""
    from ide4eeg.analysis import mne_catalog
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure()
    mne_catalog._save(
        fig, str(tmp_path), "subj01", "erp_butterfly",
        tag=_BAD_TAG)

    files = sorted(Path(tmp_path).iterdir())
    # Exactly one file written, no subdirectory created from the
    # tag's slash.
    assert len(files) == 1, f"expected one file, got: {files}"
    fname = files[0].name
    assert "Stimulus_S 17" in fname
    # Directory parts of the saved path are just tmp_path itself.
    parts = files[0].relative_to(tmp_path).parts
    assert len(parts) == 1, (
        f"tag-induced subdirectory created: {parts}")


def test_save_stc_screenshot_filename_safe():
    """``_save_stc_screenshot``'s f-string previously interpolated
    raw tag.  Verify the path the function constructs (without
    actually running PyVista, which needs a 3D context).

    We can't easily stub ``stc.plot(...)`` so this test inspects
    the source string directly -- guarantees the sanitiser is on
    the load-bearing line.
    """
    import inspect
    from ide4eeg.analysis import mne_catalog
    src = inspect.getsource(mne_catalog._save_stc_screenshot)
    assert "_safe_tag(tag)" in src, (
        "_save_stc_screenshot lost its _safe_tag call -- the f-string "
        "path will leak slashes from BrainVision event names.")


def test_save_stc_filename_safe(tmp_path):
    """``_save_stc`` writes a .h5; no 3D context needed."""
    from ide4eeg.analysis import mne_catalog

    class _StubStc:
        def save(self, path, **kw):
            self.saved_path = path

    stub = _StubStc()
    mne_catalog._save_stc(
        stub, str(tmp_path), "subj01", _BAD_TAG, "mne_dspm")

    assert hasattr(stub, "saved_path")
    rel = os.path.relpath(stub.saved_path, tmp_path)
    assert "/" not in rel and "\\" not in rel, (
        f"_save_stc h5 path leaked slash component: {rel}")
    assert "Stimulus_S 17" in stub.saved_path


@pytest.mark.parametrize("dirty,clean", [
    ("Stimulus/S 17", "Stimulus_S 17"),  # BrainVision .vmrk default
    ("target/hit", "target_hit"),         # legacy AUTO mode hierarchical
    ("a/b/c/d", "a_b_c_d"),               # multi-slash
    ("nothing-to-fix", "nothing-to-fix"),
])
def test_safe_tag_table(dirty, clean):
    """Table of known event-name shapes; lock the sanitisation
    contract so a future "let's also drop spaces" or "let's also
    drop colons" tweak is a visible code change."""
    assert _safe_tag(dirty) == clean
