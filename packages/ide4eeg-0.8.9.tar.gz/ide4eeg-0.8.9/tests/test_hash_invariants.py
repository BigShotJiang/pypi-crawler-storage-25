"""Runtime invariants for the [cfg:<hash>] staleness chain.

After Stage 3 of the architecture refactor, the three lessons from
project_staleness_hash.md are encoded as runtime asserts so they fire
loudly on future regressions:

1. Bound methods in the hash scope -> TypeError at hash time
   (because deepcopy(method) walks __self__ and explodes opaquely
   downstream).

2. _pipeline_step_hashes pre-pin must cover the steps the runner
   actually executes.  Missing entries would silently fall back to
   live recompute against an already-mutating config.

Lesson 3 (truncated-pipeline drift) is enforced structurally: the
gui-side ``_run_truncated_pipeline`` pins BEFORE truncation, and
``_launch_pipeline`` honours the pre-pin via ``setdefault``.  Locking
that integration is left to ``tests/test_staleness_hash.py`` and
``tests/test_view_step_result.py``.
"""
from ide4eeg.preprocessing.preprocessing import (
    _assert_no_bound_methods_in_hash_scope,
    _compute_preprocessing_hash,
)

import pytest


# ── Lesson 1: bound methods break the hash + deepcopy chain ──────

class _FakeWidget:
    """Stand-in for a Qt widget — its bound methods would normally
    walk the entire Qt tree when deepcopied."""
    def review(self):
        return "user picks"


def test_bound_method_in_hash_scope_raises():
    widget = _FakeWidget()
    with pytest.raises(TypeError, match="Bound method found in hash scope"):
        _assert_no_bound_methods_in_hash_scope(
            {"filters": {"method": "iir", "hook": widget.review}})


def test_bound_method_at_top_level_raises():
    widget = _FakeWidget()
    with pytest.raises(TypeError, match="Bound method found"):
        _assert_no_bound_methods_in_hash_scope({"filters": widget.review})


def test_bound_method_inside_list_raises():
    widget = _FakeWidget()
    with pytest.raises(TypeError, match=r"\[0\]"):
        _assert_no_bound_methods_in_hash_scope(
            {"filters": {"hooks": [widget.review]}})


def test_plain_callable_is_fine():
    """Module-level functions don't carry __self__ and survive deepcopy."""
    def stand_alone():
        return 42
    _assert_no_bound_methods_in_hash_scope({"x": stand_alone})


def test_clean_scope_passes():
    """The standard config shape (no callables) should pass silently."""
    _assert_no_bound_methods_in_hash_scope({
        "filters": {"method": "iir", "highpass_freq": 0.5},
        "preprocessing": {"step_order": ["trim", "resample"]},
    })


def test_compute_hash_catches_bound_method_in_config():
    """End-to-end: a bound method anywhere in the hashed config keys
    surfaces from _compute_preprocessing_hash itself, not just from a
    later deepcopy."""
    widget = _FakeWidget()
    cfg = {"filters": {"method": "iir", "callback": widget.review}}
    with pytest.raises(TypeError, match="Bound method"):
        _compute_preprocessing_hash(cfg)


# ── Lesson 2: pre-pinned step-hash dict must cover runner's steps ──

def _build_runnable_config():
    """Minimal config that gets through preprocessing's preamble.

    Built from DEFAULT_CONFIG to inherit the right shape; only the
    fields the runner consumes before the first step are required.
    """
    from ide4eeg.gui_config import DEFAULT_CONFIG
    import copy
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    cfg["preprocessing"]["step_order"] = ["trim", "resample"]
    cfg["resample_freq"] = 256
    return cfg


def test_partial_step_hash_pin_raises_at_runner_entry():
    """Pre-pin missing steps must raise loudly, not silently recompute."""
    from ide4eeg.preprocessing.preprocessing import (
        _check_step_hash_pin_coverage,
        _compute_step_hashes,
        effective_step_order,
    )
    cfg = _build_runnable_config()
    full_pin = _compute_step_hashes(cfg, effective_step_order(cfg))
    # Drop one step from the pin to simulate the bug
    cfg["_pipeline_step_hashes"] = {
        k: v for k, v in full_pin.items() if k != "resample"}

    with pytest.raises(RuntimeError, match="resample"):
        _check_step_hash_pin_coverage(cfg)


def test_complete_step_hash_pin_passes():
    """The happy path — full pin covers every step → invariant silent."""
    from ide4eeg.preprocessing.preprocessing import (
        _check_step_hash_pin_coverage,
        _compute_step_hashes,
        effective_step_order,
    )
    cfg = _build_runnable_config()
    cfg["_pipeline_step_hashes"] = _compute_step_hashes(
        cfg, effective_step_order(cfg))
    # Must return cleanly — no exception.
    _check_step_hash_pin_coverage(cfg)


def test_no_pin_dict_is_a_clean_passthrough():
    """Programmatic callers (run_file) may skip the pin entirely;
    the invariant must not fire on a cfg without _pipeline_step_hashes."""
    from ide4eeg.preprocessing.preprocessing import (
        _check_step_hash_pin_coverage,
    )
    cfg = _build_runnable_config()
    _check_step_hash_pin_coverage(cfg)  # no exception


def test_pin_after_preflight_mutation_covers_added_steps():
    """Regression: ``_preflight_check`` at ``gui.py:15394-15397`` can
    append ``mp_decomposition`` to ``preprocessing.step_order`` when
    an analysis requires an MP book and the user has empi installed.
    Pre-fix, the GUI pinned ``_pipeline_step_hashes`` BEFORE preflight
    ran -- so the added step wasn't in the pin, and the runner's
    coverage check raised ``Step hash pin from caller is missing
    entries for steps the runner will execute: ['mp_decomposition']``.

    Post-fix (gui.py: pin moved AFTER preflight), this test models the
    contract: simulate the preflight mutation, then pin, then verify
    the runner's check passes.
    """
    from ide4eeg.preprocessing.preprocessing import (
        _check_step_hash_pin_coverage,
        _compute_step_hashes,
        effective_step_order,
    )
    cfg = _build_runnable_config()

    # Simulate what _preflight_check does when an analysis needs MP:
    # append mp_decomposition to step_order.  (The real preflight
    # gates on `mp_consumers_from_cfg`; this test only needs to
    # exercise the post-mutation pin path.)
    cfg["preprocessing"]["step_order"].append("mp_decomposition")

    # Pin AFTER the mutation, as the post-fix code does.
    cfg["_pipeline_step_hashes"] = _compute_step_hashes(
        cfg, effective_step_order(cfg))

    # Runner's invariant check must pass -- mp_decomposition is now
    # in BOTH the runner's step_order and the pinned dict.
    _check_step_hash_pin_coverage(cfg)


def test_disable_all_analyses_zeros_prepare_mp_filter():
    """v0.8.9 audit BLOCKER 2.  The truncated-pipeline path
    (``_run_truncated_pipeline``) calls ``_disable_all_analyses``
    before ``_launch_pipeline``.  Pre-fix, ``_disable_all_analyses``
    zeroed only the three analysis-tab flags
    (``prepare_eeg_profiles`` / ``connectivity_analysis`` /
    ``dipole_fitting``) and missed ``prepare_mp_filter``.  Result:
    a user with ``prepare_mp_filter=True`` + no MP book + empi
    installed could click an eye-button and trigger the preflight
    auto-fetch path (gui.py:_preflight_check), which appends
    ``mp_decomposition`` to ``step_order`` AFTER the pre-pin from
    8561.  Runner's ``_check_step_hash_pin_coverage`` then raised
    ``missing entries for: ['mp_decomposition']`` -- the very class
    47042ba was meant to neutralise.

    Lock: ``prepare_mp_filter`` must be in ``_ANALYSIS_FLAGS`` so
    ``_disable_all_analyses`` neutralises it before the truncated
    pipeline starts.
    """
    # We import the class definition only; no GUI instantiation
    # required.  ``_ANALYSIS_FLAGS`` is a class attribute.
    from ide4eeg.gui import IDE4EEG_Qt
    assert "prepare_mp_filter" in IDE4EEG_Qt._ANALYSIS_FLAGS, (
        "prepare_mp_filter MUST be in _ANALYSIS_FLAGS -- otherwise "
        "the truncated-pipeline path can still trigger the "
        "preflight mp_decomposition mutation that the pin-after-"
        "preflight fix in gui.py:_launch_pipeline was meant to "
        "neutralise.")


def test_pin_before_preflight_mutation_raises_at_runner():
    """The pre-fix failure mode, locked.  If a caller pins BEFORE
    a step is added to step_order, the runner's coverage check must
    raise loudly -- not silently recompute and produce a stale
    snapshot.  This is the contract that catches the
    ``gui.py:_launch_pipeline`` pin-ordering bug class.
    """
    from ide4eeg.preprocessing.preprocessing import (
        _check_step_hash_pin_coverage,
        _compute_step_hashes,
        effective_step_order,
    )
    cfg = _build_runnable_config()
    # Pin first (with the original step_order)...
    cfg["_pipeline_step_hashes"] = _compute_step_hashes(
        cfg, effective_step_order(cfg))
    # ...then mutate step_order (the bug shape).
    cfg["preprocessing"]["step_order"].append("mp_decomposition")
    # Runner's check fires.
    with pytest.raises(RuntimeError, match="mp_decomposition"):
        _check_step_hash_pin_coverage(cfg)


# ── Issue #21: stale pin from a previously-auto-saved TOML ────────

def test_strip_runtime_top_level_keys_drops_pin_fields():
    """The helper must drop every key in ``_RUNTIME_TOP_LEVEL_KEYS``."""
    from ide4eeg.preprocessing.preprocessing import (
        _RUNTIME_TOP_LEVEL_KEYS,
        strip_runtime_top_level_keys,
    )
    cfg = {k: "stale" for k in _RUNTIME_TOP_LEVEL_KEYS}
    cfg["keep_me"] = "yes"
    cfg["_other_underscore_top_level"] = "kept"  # not in the runtime list
    strip_runtime_top_level_keys(cfg)
    for k in _RUNTIME_TOP_LEVEL_KEYS:
        assert k not in cfg, f"{k} not stripped"
    assert cfg["keep_me"] == "yes"
    assert cfg["_other_underscore_top_level"] == "kept"


def test_issue21_stale_pin_in_user_toml_does_not_break_cli(tmp_path):
    """Regression for GitLab issue #21.

    The pre-fix GUI auto-saved ``_pipeline_step_hashes`` into the
    output-dir ``config.toml``.  When a user later re-loaded that TOML
    and changed the pipeline (added ``gaze_artifacts``, swapped a
    filter widget), the stale pin survived into the cfg, ``setdefault``
    in ``_launch_pipeline`` refused to recompute, and the runner's
    coverage check fired with ``'missing entries for steps the runner
    will execute: [filtering:..., gaze_artifacts]'``.

    Post-fix: ``main()`` strips runtime pin keys after
    ``read_config_file`` (unless the eye-button truncated path opts in
    via ``_preserve_runtime_pin_keys=True``), so the runner self-pins
    fresh against the user's actual effective step_order.  Smoke test:
    serialize a cfg with a stale pin, parse it back through
    ``read_config_file``, and verify the strip is what the runner
    would see.
    """
    from ide4eeg.input.input import read_config_file
    from ide4eeg.gui_config import dump_toml
    from ide4eeg.preprocessing.preprocessing import (
        strip_runtime_top_level_keys,
    )
    cfg = _build_runnable_config()
    # Simulate the reporter's TOML: stale pin from a previous run that
    # doesn't cover gaze_artifacts (added by the user since the save).
    cfg["_pipeline_config_hash"] = "deadbeefcafef00d"
    cfg["_pipeline_step_hashes"] = {
        "trim": "111", "resample": "222"}  # missing later steps
    cfg["_mp_book_hash"] = "fee1dead"
    cfg_path = tmp_path / "stale_pin.toml"
    dump_toml(cfg, str(cfg_path))

    # Load through read_config_file + apply the same strip that
    # ``main()`` does with _preserve_runtime_pin_keys=False.
    loaded = read_config_file(str(cfg_path))
    assert "_pipeline_step_hashes" in loaded  # still in raw load
    strip_runtime_top_level_keys(loaded)
    assert "_pipeline_step_hashes" not in loaded
    assert "_pipeline_config_hash" not in loaded
    assert "_mp_book_hash" not in loaded
    # The runner would now self-pin against the current step_order
    # -- no stale pin, no spurious "missing entries" failure.


def test_issue21_preserve_pin_keys_kwarg_keeps_pin_for_eye_button():
    """The eye-button truncated path opts INTO pin preservation by
    passing ``_preserve_runtime_pin_keys=True``.  This locks the
    contract that the strip is conditional, not unconditional --
    truncated-pipeline snapshots are tagged with the user-level
    pre-truncation hash, which has to survive the TOML roundtrip
    that the worker thread does on the way to ``run_pipeline``.
    """
    # Validate the API shape by introspecting the signature; running
    # main() end-to-end here would require a full pipeline stack.
    import inspect
    from ide4eeg.main import main
    sig = inspect.signature(main)
    assert "_preserve_runtime_pin_keys" in sig.parameters
    param = sig.parameters["_preserve_runtime_pin_keys"]
    assert param.default is False, (
        "Default must be False so all non-eye-button callers (CLI, "
        "programmatic, GUI Run button) get the strip.  Only the "
        "eye-button worker should opt in to True.")
