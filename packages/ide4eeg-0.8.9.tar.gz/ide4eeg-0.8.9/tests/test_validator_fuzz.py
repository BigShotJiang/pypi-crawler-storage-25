"""Robustness fuzz for the TOML config validator.

``validate_config`` must never raise — its contract is to return a
list of :class:`ConfigIssue` and let the caller decide what to do.
TOML loading itself is upstream (``tomllib.load``) so malformed TOML
syntax never reaches the validator; we only exercise dict shapes
that a well-formed TOML can produce.
"""
from __future__ import annotations

import logging

import pytest

from ide4eeg.config_schema import validate_config


def test_empty_dict_no_issues():
    assert validate_config({}) == []


def test_only_underscore_keys_no_issues():
    issues = validate_config({
        "_pipeline_config_hash": "abc",
        "_input_dir": "/tmp",
        "_input_file_name": "x.fif",
        "_mp_book_path": "/x.db",
    })
    assert issues == []


def test_huge_dict_no_crash():
    """A dict with 1000 random keys should not blow up
    ``difflib.get_close_matches`` or cause O(n^2) badness."""
    cfg = {f"unknown_key_{i}": i for i in range(1000)}
    issues = validate_config(cfg)
    assert len(issues) == 1000  # every key flagged
    # Each issue is a ConfigIssue, not a raised exception
    for iss in issues[:5]:
        assert iss.severity == logging.WARNING


def test_unicode_keys_no_crash():
    issues = validate_config({"naïve_filters": {}, "α_rejection": 5})
    # Keys aren't ASCII, no fuzzy match to any DEFAULT_CONFIG entry —
    # should just emit warnings, not raise.
    assert all(i.severity == logging.WARNING for i in issues)


def test_nested_dicts_arbitrary_depth_no_crash():
    """The validator only inspects top-level keys' shapes; nested
    contents may be arbitrarily deep dicts and lists."""
    deep = {"a": {"b": {"c": {"d": {"e": list(range(100))}}}}}
    issues = validate_config({"filters": deep})  # 'filters' is known dict
    assert issues == []


def test_extreme_nesting_via_list_no_crash():
    issues = validate_config({
        "filters": {"method": "iir", "extra": [[[[[1]]]]]},
    })
    assert issues == []


@pytest.mark.parametrize("bad_value", [
    "iir",                     # str
    123,                       # int
    1.5,                       # float
    True,                      # bool
    [1, 2, 3],                 # list
    None,                      # None
])
def test_known_dict_section_with_scalar_value_warns(bad_value):
    """If the user writes ``filters = <not a dict>`` the validator
    should warn about the shape, not raise."""
    issues = validate_config({"filters": bad_value})
    assert len(issues) == 1
    assert "expected a [section]" in issues[0].message


@pytest.mark.parametrize("good_value", [
    {},
    {"method": "iir"},
    {"a": {"nested": True}},
])
def test_known_dict_section_with_dict_value_clean(good_value):
    issues = validate_config({"filters": good_value})
    assert issues == []


def test_all_default_config_keys_clean():
    """A config carrying every DEFAULT_CONFIG key (with the canonical
    default values) must validate without issues."""
    from ide4eeg.gui_config import DEFAULT_CONFIG
    assert validate_config(dict(DEFAULT_CONFIG)) == []


def test_known_keys_with_wrong_scalar_type_still_load():
    """Most leaf scalars (resample_freq=256 vs 256.0) round-trip
    silently; the validator doesn't fingerprint scalar types."""
    issues = validate_config({"resample_freq": "256"})  # str not int
    # Either no issue (we don't type-check scalars) or one specific
    # issue — but never an exception.
    assert isinstance(issues, list)


def test_runtime_pin_present_always_skips():
    """Cross-cuts every other case: if any _pipeline_* pin is set,
    even an otherwise-flaggable shape skips validation entirely."""
    issues = validate_config({
        "_pipeline_config_hash": "abc",
        "filter_z": "iir",    # would normally warn
        "filters": 42,        # would normally warn
        "xyzzy": True,        # would normally warn
    })
    assert issues == []
