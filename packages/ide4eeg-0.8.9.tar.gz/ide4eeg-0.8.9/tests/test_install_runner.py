"""Tests for ide4eeg.install_runner."""

import sys

import pytest

from ide4eeg.install_diagnostics import (
    VIDEO_STACK,
    ActionPlan,
    CellIssue,
    Pkg,
    plan_install,
)
from ide4eeg.install_runner import (
    InstallResult,
    InstallSummary,
    UninstallResult,
    UninstallSummary,
    VideoStackInstaller,
    VideoStackUninstaller,
    _is_in_venv,
    install_specs,
    pip_failure_hint,
    restart_required_packages,
)


# ---------------------------------------------------------------------- helpers

def _stub_executor(*, succeed: set[str], fail_output: str = "ERROR"):
    """Build a fake pip executor that succeeds for some pkgs, fails for others.

    ``succeed`` is the set of import_names whose install should
    return exit 0; everything else returns 1 with ``fail_output``.
    """
    calls: list[tuple[Pkg, list[str]]] = []

    def stub(pkg: Pkg, cmd: list[str]) -> InstallResult:
        calls.append((pkg, cmd))
        if pkg.import_name in succeed:
            return InstallResult(pkg=pkg, exit_code=0,
                                 output=f"Successfully installed {pkg.import_name}")
        return InstallResult(pkg=pkg, exit_code=1, output=fail_output)

    stub.calls = calls
    return stub


def _pkg(name):
    """Look up a Pkg from VIDEO_STACK by import name (test convenience)."""
    for p in VIDEO_STACK:
        if p.import_name == name:
            return p
    raise KeyError(name)


# ---------------------------------------------------------------------- venv

def test_is_in_venv_returns_bool():
    assert isinstance(_is_in_venv(), bool)


def test_build_command_uses_sys_executable_and_pip_spec():
    inst = VideoStackInstaller()
    cmd = inst.build_command(_pkg("cv2"))
    assert cmd[0] == sys.executable
    assert cmd[1:4] == ["-m", "pip", "install"]
    assert _pkg("cv2").pip_spec in cmd


def test_build_command_user_flag_outside_venv(monkeypatch):
    monkeypatch.setattr("ide4eeg.install_runner._is_in_venv",
                        lambda: False)
    inst = VideoStackInstaller()
    cmd = inst.build_command(_pkg("cv2"))
    assert "--user" in cmd


def test_build_command_no_user_flag_inside_venv(monkeypatch):
    monkeypatch.setattr("ide4eeg.install_runner._is_in_venv",
                        lambda: True)
    inst = VideoStackInstaller()
    cmd = inst.build_command(_pkg("cv2"))
    assert "--user" not in cmd


# ---------------------------------------------------------------------- install_one

def test_install_one_invokes_executor_and_logs():
    log: list[str] = []
    stub = _stub_executor(succeed={"cv2"})
    inst = VideoStackInstaller(log_callback=log.append, pip_executor=stub)
    result = inst.install_one(_pkg("cv2"))
    assert result.success is True
    assert result.exit_code == 0
    assert len(stub.calls) == 1
    # Banner lines should mention the package + spec.
    joined = "\n".join(log)
    assert "Installing cv2" in joined
    assert "opencv-contrib-python-headless" in joined


def test_install_one_failure_returns_nonzero():
    stub = _stub_executor(succeed=set())
    inst = VideoStackInstaller(pip_executor=stub)
    result = inst.install_one(_pkg("cv2"))
    assert result.success is False
    assert result.exit_code == 1
    assert "ERROR" in result.output


# ---------------------------------------------------------------------- install_plan

def test_install_plan_attempts_only_missing_not_blocked():
    detection = {p.import_name: False for p in VIDEO_STACK}
    # Synthetic: pretend we're on Intel Mac + Py3.14 so onnxruntime
    # is in plan.blocked, not plan.missing.
    plan = plan_install(detection,
                        platform_="darwin", machine="x86_64",
                        py_minor=14)
    assert any(p.import_name == "onnxruntime"
               for p, _ in plan.blocked)
    stub = _stub_executor(
        succeed={p.import_name for p in VIDEO_STACK})
    inst = VideoStackInstaller(pip_executor=stub)
    summary = inst.install_plan(plan)
    attempted_names = {p.import_name for p in summary.attempted}
    assert "onnxruntime" not in attempted_names
    assert "cv2" in attempted_names
    assert summary.skipped_blocked
    assert any(p.import_name == "onnxruntime"
               for p in summary.skipped_blocked)


def test_install_plan_include_optional_false_skips_l2cs_extras():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    stub = _stub_executor(
        succeed={p.import_name for p in VIDEO_STACK})
    inst = VideoStackInstaller(pip_executor=stub)
    summary = inst.install_plan(plan, include_optional=False)
    names = {p.import_name for p in summary.attempted}
    assert "torch" not in names
    assert "l2cs" not in names
    assert "cv2" in names


def test_install_plan_include_optional_true_installs_l2cs_extras():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    stub = _stub_executor(
        succeed={p.import_name for p in VIDEO_STACK})
    inst = VideoStackInstaller(pip_executor=stub)
    summary = inst.install_plan(plan, include_optional=True)
    names = {p.import_name for p in summary.attempted}
    assert "torch" in names
    assert "l2cs" in names


def test_install_plan_partial_failure_records_results():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    # Succeed on cv2 + av, fail on the rest.
    stub = _stub_executor(succeed={"cv2", "av"})
    inst = VideoStackInstaller(pip_executor=stub)
    summary = inst.install_plan(plan)
    assert summary.all_succeeded is False
    assert {r.pkg.import_name for r in summary.failures} >= {
        "imageio", "insightface", "onnxruntime"}


# ---------------------------------------------------------------------- restart logic

def test_needs_restart_true_when_torch_installed():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    stub = _stub_executor(succeed={"torch"})
    inst = VideoStackInstaller(pip_executor=stub)
    summary = inst.install_plan(plan, include_optional=True)
    assert summary.needs_restart is True


def test_needs_restart_false_when_only_pure_python_installed():
    # imageio is the only pure-Python pkg in the stack.
    detection = {p.import_name: True for p in VIDEO_STACK}
    detection["imageio"] = False
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    stub = _stub_executor(succeed={"imageio"})
    inst = VideoStackInstaller(pip_executor=stub)
    summary = inst.install_plan(plan)
    assert summary.needs_restart is False


def test_restart_required_packages_filter():
    pkgs = list(VIDEO_STACK)
    needs = restart_required_packages(pkgs)
    names = {p.import_name for p in needs}
    assert names == {"cv2", "av", "insightface", "onnxruntime", "torch"}


# ---------------------------------------------------------------------- summary

def test_summary_all_succeeded_property():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    stub = _stub_executor(succeed={p.import_name for p in VIDEO_STACK})
    inst = VideoStackInstaller(pip_executor=stub)
    summary = inst.install_plan(plan)
    assert summary.all_succeeded is True
    assert summary.failures == ()


# ---------------------------------------------------------------------- VideoStackUninstaller

def _stub_uninstall_executor(*, succeed_dists, fail_output="ERROR"):
    """Build a fake pip-uninstall executor.

    ``succeed_dists`` is the set of dist names whose uninstall returns
    exit 0; everything else returns exit 1 with ``fail_output`` (which
    may include the literal "not installed" to test that path).
    """
    calls: list[tuple[str, list[str]]] = []

    def stub(dist, cmd):
        calls.append((dist, cmd))
        if dist in succeed_dists:
            return UninstallResult(
                dist=dist, exit_code=0,
                output=f"Successfully uninstalled {dist}-1.0")
        return UninstallResult(
            dist=dist, exit_code=1, output=fail_output)

    stub.calls = calls
    return stub


def test_uninstaller_dist_names_omit_mpv():
    # mpv is intentionally not in DIST_NAMES — Svarog uses it.
    assert "mpv" not in VideoStackUninstaller.DIST_NAMES
    # All four opencv distributions are listed: any of them can
    # provide cv2, and a user may have one or several coexisting.
    # Pip silently skips ones that aren't installed.
    expected = {"opencv-contrib-python-headless",
                "opencv-contrib-python",
                "opencv-python-headless",
                "opencv-python",
                "av", "imageio",
                "insightface", "onnxruntime", "torch", "torchvision",
                "l2cs", "gdown"}
    assert set(VideoStackUninstaller.DIST_NAMES) == expected


def test_uninstaller_build_command_uses_y_flag():
    u = VideoStackUninstaller()
    cmd = u.build_command("torch")
    assert cmd[:5] == [sys.executable, "-m", "pip", "uninstall", "-y"]
    assert cmd[-1] == "torch"


def test_uninstaller_uninstall_one_logs_and_invokes_executor():
    log: list[str] = []
    stub = _stub_uninstall_executor(succeed_dists={"torch"})
    u = VideoStackUninstaller(log_callback=log.append, pip_executor=stub)
    result = u.uninstall_one("torch")
    assert result.success is True
    joined = "\n".join(log)
    assert "Uninstalling torch" in joined


def test_uninstall_result_treats_not_installed_as_success():
    r = UninstallResult(
        dist="some-pkg", exit_code=1,
        output="WARNING: Skipping some-pkg as it is not installed.")
    assert r.success is True


def test_uninstall_result_real_failure_is_failure():
    r = UninstallResult(
        dist="some-pkg", exit_code=1,
        output="Permission denied")
    assert r.success is False


def test_uninstaller_uninstall_all_iterates_every_dist(tmp_path,
                                                       monkeypatch):
    # Redirect L2CS weights + InsightFace cache to tmp_path so the
    # data-file removal step doesn't touch real installs.
    import ide4eeg.download_tools as dt
    fake_weights = tmp_path / "models" / "L2CSNet_gaze360.pkl"
    fake_weights.parent.mkdir(parents=True)
    fake_weights.write_text("dummy")
    fake_if_root = tmp_path / "insightface"
    (fake_if_root / "models").mkdir(parents=True)
    (fake_if_root / "models" / "buffalo_l").mkdir()
    monkeypatch.setattr(dt, "canonical_l2cs_weights_path",
                        lambda: str(fake_weights))
    monkeypatch.setattr(dt, "INSIGHTFACE_ROOT", fake_if_root)

    stub = _stub_uninstall_executor(
        succeed_dists=set(VideoStackUninstaller.DIST_NAMES))
    u = VideoStackUninstaller(pip_executor=stub)
    summary = u.uninstall_all()

    # Every dist was attempted, in declared order.
    attempted = [c[0] for c in stub.calls]
    assert attempted == list(VideoStackUninstaller.DIST_NAMES)
    assert summary.all_succeeded is True
    # Both data files were removed.
    assert not fake_weights.exists()
    assert not (fake_if_root / "models").exists()
    assert len(summary.files_removed) == 2


def test_uninstaller_uninstall_all_partial_failure():
    stub = _stub_uninstall_executor(
        succeed_dists={"torch", "torchvision"})
    u = VideoStackUninstaller(pip_executor=stub)
    summary = u.uninstall_all()
    failed_dists = {r.dist for r in summary.failures}
    # cv2/av/imageio/insightface/onnxruntime/l2cs/gdown should all
    # appear as failures (none are "not installed" — exit 1 with
    # generic "ERROR" output).
    assert "opencv-contrib-python-headless" in failed_dists
    assert "torch" not in failed_dists


# ---------------------------------------------------------------------- pip_failure_hint

def test_pip_failure_hint_recognises_no_matching_distribution():
    output = (
        "ERROR: Could not find a version that satisfies the "
        "requirement torch (from versions: none)\n"
        "ERROR: No matching distribution found for torch")
    hint = pip_failure_hint(output)
    assert hint  # non-empty
    assert "PyTorch" in hint
    assert "x86_64" in hint or "Apple Silicon" in hint


def test_pip_failure_hint_recognises_could_not_find_a_version():
    output = "ERROR: Could not find a version that satisfies foo"
    hint = pip_failure_hint(output)
    assert hint != ""


def test_pip_failure_hint_empty_for_unrelated_error():
    output = "ERROR: Permission denied"
    assert pip_failure_hint(output) == ""


# ---------------------------------------------------------------------- install_specs

def test_install_specs_invokes_pip_with_user_outside_venv(monkeypatch):
    monkeypatch.setattr("ide4eeg.install_runner._is_in_venv",
                        lambda: False)
    captured = {}

    def fake_run(cmd, log_callback, *, cancel=None):
        captured["cmd"] = cmd
        log_callback("fake install line 1")
        log_callback("Successfully installed foo-1.0")
        return 0, "fake install line 1\nSuccessfully installed foo-1.0"

    monkeypatch.setattr("ide4eeg.install_runner._run_pip_streaming",
                        fake_run)
    log = []
    ok, output = install_specs(
        ["foo", "bar"], label="foo + bar",
        log_callback=log.append)
    assert ok is True
    assert "foo" in output and "Successfully installed" in output
    cmd = captured["cmd"]
    assert cmd[:4] == [sys.executable, "-m", "pip", "install"]
    assert "--user" in cmd
    assert cmd[-2:] == ["foo", "bar"]
    # Banner lines were emitted before pip ran.
    assert any("Installing foo + bar" in line for line in log)


def test_install_specs_no_user_flag_inside_venv(monkeypatch):
    monkeypatch.setattr("ide4eeg.install_runner._is_in_venv",
                        lambda: True)
    captured = {}

    def fake_run(cmd, log_callback, *, cancel=None):
        captured["cmd"] = cmd
        return 0, ""

    monkeypatch.setattr("ide4eeg.install_runner._run_pip_streaming",
                        fake_run)
    install_specs(["foo"], label="foo", log_callback=lambda _: None)
    assert "--user" not in captured["cmd"]


def test_install_specs_returns_failure_on_nonzero_exit(monkeypatch):
    def fake_run(cmd, log_callback, *, cancel=None):
        return 1, "ERROR: oh no"

    monkeypatch.setattr("ide4eeg.install_runner._run_pip_streaming",
                        fake_run)
    ok, output = install_specs(
        ["foo"], label="foo", log_callback=lambda _: None)
    assert ok is False
    assert "ERROR: oh no" in output


# ---------------------------------------------------------------------- CancellationToken

from ide4eeg.install_runner import CancellationToken


def test_cancellation_token_starts_uncancelled():
    t = CancellationToken()
    assert t.is_cancelled is False


def test_cancellation_token_cancel_sets_flag():
    t = CancellationToken()
    t.cancel()
    assert t.is_cancelled is True


def test_cancellation_token_cancel_is_idempotent():
    t = CancellationToken()
    t.cancel()
    t.cancel()  # second call is no-op
    assert t.is_cancelled is True


def test_cancellation_token_terminates_active_proc():
    """When cancel() is called and a Popen is registered, terminate
    is requested on it."""
    from unittest.mock import MagicMock
    t = CancellationToken()
    fake_proc = MagicMock()
    fake_proc.poll.return_value = None  # still running
    t._set_active_proc(fake_proc)
    t.cancel()
    fake_proc.terminate.assert_called_once()


def test_cancellation_token_skips_terminate_for_finished_proc():
    from unittest.mock import MagicMock
    t = CancellationToken()
    fake_proc = MagicMock()
    fake_proc.poll.return_value = 0  # already exited
    t._set_active_proc(fake_proc)
    t.cancel()
    fake_proc.terminate.assert_not_called()


# ---------------------------------------------------------------------- cancellation in install_plan

def test_install_plan_cancelled_before_start_skips_everything():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    token = CancellationToken()
    token.cancel()  # set BEFORE running
    stub = _stub_executor(succeed={p.import_name for p in VIDEO_STACK})
    inst = VideoStackInstaller(pip_executor=stub, cancel=token)
    summary = inst.install_plan(plan)
    assert summary.cancelled is True
    assert summary.attempted == ()  # nothing was even tried


def test_install_plan_cancellation_mid_run():
    """Cancel after first package — remaining are skipped."""
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64",
                        py_minor=13)
    token = CancellationToken()

    cv2_pkg = next(p for p in VIDEO_STACK if p.import_name == "cv2")

    def cancelling_stub(pkg, cmd):
        if pkg.import_name == "cv2":
            token.cancel()  # cancel after first package starts
        return InstallResult(pkg=pkg, exit_code=0,
                             output=f"installed {pkg.import_name}")

    inst = VideoStackInstaller(pip_executor=cancelling_stub,
                                cancel=token)
    summary = inst.install_plan(plan)
    assert summary.cancelled is True
    # Only the first package made it through.
    assert len(summary.attempted) == 1
    assert summary.attempted[0].import_name == "cv2"


# ---------------------------------------------------------------------- cancellation in uninstall_all

def test_uninstall_all_cancelled_skips_data_files(tmp_path,
                                                  monkeypatch):
    """When uninstall is cancelled, data-files cleanup is skipped
    (state on disk reflects whatever pip got through)."""
    import ide4eeg.download_tools as dt
    fake_weights = tmp_path / "models" / "L2CSNet_gaze360.pkl"
    fake_weights.parent.mkdir(parents=True)
    fake_weights.write_text("dummy")
    fake_if = tmp_path / "insightface"
    (fake_if / "models").mkdir(parents=True)
    monkeypatch.setattr(dt, "canonical_l2cs_weights_path",
                        lambda: str(fake_weights))
    monkeypatch.setattr(dt, "INSIGHTFACE_ROOT", fake_if)

    token = CancellationToken()
    token.cancel()  # cancel before any uninstalls run

    stub = _stub_uninstall_executor(
        succeed_dists=set(VideoStackUninstaller.DIST_NAMES))
    u = VideoStackUninstaller(pip_executor=stub, cancel=token)
    summary = u.uninstall_all()
    assert summary.cancelled is True
    # Data files survived since cleanup was skipped.
    assert fake_weights.exists()
    assert (fake_if / "models").exists()
    assert summary.files_removed == ()
