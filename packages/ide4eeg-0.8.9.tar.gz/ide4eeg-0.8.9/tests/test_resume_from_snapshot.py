"""Tests for ``preprocessing._find_resume_point``.

The resume helper enables the pipeline runner to skip steps whose
saved FIF snapshots are still fresh (hash matches the per-step
cumulative hash for that step under the current config).  The
correctness contract is identical regardless of hash granularity:

  * Fresh snapshot found  → return its index + the loaded signal.
  * Hash mismatch         → return (None, None).
  * Missing FIF           → return (None, None).
  * Corrupt FIF           → fall through to an earlier candidate.
  * Past a state-populating step (currently ``artifacts``) → bounded
    above; the runner cannot reconstruct
    ``state["bad_event_positions"]`` from a saved signal alone.

The granular per-step regime (vs. the old whole-config hash) makes
this fire more often: editing a downstream key no longer
invalidates upstream snapshots.  ``test_resume_after_downstream_edit``
covers that case explicitly.
"""

import os

import mne
import numpy as np
import pytest

from ide4eeg.preprocessing.preprocessing import (
    _STEP_SAVE_MAP,
    _compute_step_hash,
    _find_resume_point,
    _stamp_signal_description,
)


def _cfg():
    return {
        "preprocessing": {
            "step_order": ["trim", "resample", "bad_channels",
                           "filtering"],
        },
        "trim_start": 0.0,
        "trim_end": 10.0,
        "resample_freq": 128,
        "choosing_channels": {"bad_channels": []},
        "bad_channels": {},
        "filters": {"highpass_freq": 1.0, "lowpass_freq": 40.0},
        "segmentation": {"mode": "rest"},
        "rest": {"window_length": 10},
    }


def _stamp_and_save(tmp_path, base_name, step_name, cfg_hash):
    """Write a 3-channel zeroed FIF stamped with *cfg_hash* under the
    expected ``saved_steps/`` filename for *step_name*."""
    saved_dir = os.path.join(str(tmp_path), "saved_steps")
    os.makedirs(saved_dir, exist_ok=True)
    suffix = _STEP_SAVE_MAP[step_name][1]
    out = os.path.join(
        saved_dir, f"{base_name}-{suffix}-raw.fif")
    info = mne.create_info(["C3", "C4", "Cz"], 128, ["eeg"] * 3)
    raw = mne.io.RawArray(np.zeros((3, 128)), info, verbose=False)
    _stamp_signal_description(raw, step_name, cfg_hash)
    raw.save(out, overwrite=True, verbose=False)
    return out


def _step_hash(cfg, step):
    """Convenience: per-step cumulative hash under cfg's step_order."""
    return _compute_step_hash(
        step, cfg, cfg["preprocessing"]["step_order"])


def test_resume_returns_latest_fresh_snapshot(tmp_path):
    cfg = _cfg()
    _stamp_and_save(tmp_path, "signal", "trim", _step_hash(cfg, "trim"))
    _stamp_and_save(tmp_path, "signal", "resample",
                    _step_hash(cfg, "resample"))
    # filtering snapshot left absent on purpose — resume should
    # land at "resample" (idx 1), not "filtering" (idx 3).
    idx, sig = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    assert idx == 1
    assert sig is not None


def test_resume_returns_none_on_hash_mismatch(tmp_path):
    cfg = _cfg()
    _stamp_and_save(tmp_path, "signal", "trim", "deadbeefcafebabe")
    idx, sig = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    assert idx is None
    assert sig is None


def test_resume_returns_none_when_saved_steps_missing(tmp_path):
    cfg = _cfg()
    idx, sig = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    assert idx is None
    assert sig is None


def test_resume_falls_through_corrupt_fif(tmp_path):
    """A truncated/garbage FIF at the latest-step's expected path
    should not abort the search — earlier fresh snapshots still
    win."""
    cfg = _cfg()
    _stamp_and_save(tmp_path, "signal", "trim", _step_hash(cfg, "trim"))
    saved_dir = os.path.join(str(tmp_path), "saved_steps")
    suffix = _STEP_SAVE_MAP["resample"][1]
    bogus = os.path.join(saved_dir, f"signal-{suffix}-raw.fif")
    with open(bogus, "wb") as f:
        f.write(b"not a real fif file")
    idx, sig = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    assert idx == 0  # trim, not resample
    assert sig is not None


def test_resume_capped_by_state_populating_step(tmp_path):
    """``eeg_artifacts`` populates state beyond ``signal`` so resuming
    past it would lose ``bad_event_positions``.  Even with a fresh
    snapshot at ``filtering`` (which sits AFTER ``eeg_artifacts`` here),
    the helper must not return it."""
    cfg = _cfg()
    cfg["preprocessing"]["step_order"] = [
        "trim", "eeg_artifacts", "filtering"]
    _stamp_and_save(tmp_path, "signal", "trim", _step_hash(cfg, "trim"))
    _stamp_and_save(tmp_path, "signal", "filtering",
                    _step_hash(cfg, "filtering"))
    idx, sig = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    # Allowed range is [0, 1) — only "trim" qualifies.
    assert idx == 0


def test_resume_uses_pinned_hash_when_provided(tmp_path):
    """``config["_pipeline_step_hashes"][step]`` wins over a live
    recompute — same contract as ``_save_step_signal_if_requested``,
    so the write-side and read-side stay aligned."""
    cfg = _cfg()
    pinned = "1234567890abcdef"
    cfg["_pipeline_step_hashes"] = {"trim": pinned}
    _stamp_and_save(tmp_path, "signal", "trim", pinned)
    idx, sig = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    assert idx == 0
    assert sig is not None


def test_resume_after_downstream_edit(tmp_path):
    """The whole point of per-step hashes: editing a config key
    only consumed by a downstream step (here: filtering's
    ``lowpass_freq``) should NOT invalidate upstream snapshots.
    Resume must still land at the latest upstream snapshot.

    Under the old whole-config-hash regime this returned
    ``(None, None)`` — even though ``trim`` and ``resample`` haven't
    been touched, their snapshot's hash carried the old value of
    ``filters.lowpass_freq`` so the read-side recompute mismatched.
    """
    cfg = _cfg()
    # Stamp upstream snapshots with the per-step hash computed at
    # save time (i.e. with lowpass_freq=40.0).
    _stamp_and_save(tmp_path, "signal", "trim", _step_hash(cfg, "trim"))
    _stamp_and_save(tmp_path, "signal", "resample",
                    _step_hash(cfg, "resample"))

    # Now the user edits a downstream-only key.  Per-step hashes for
    # trim/resample are unchanged; filtering's hash is different.
    cfg["filters"]["lowpass_freq"] = 30.0

    idx, sig = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    # Resume from the latest fresh upstream snapshot — resample (idx
    # 1).  The whole-config-hash regime would have returned (None,
    # None) here because *every* snapshot's stamp would mismatch.
    assert idx == 1
    assert sig is not None


def test_force_rerun_steps_bypasses_target_snapshot(tmp_path):
    """``config["_force_rerun_steps"]`` is the eye-button escape
    hatch for manual-review steps: even when the target step's
    snapshot is fresh, the resume helper must land BEFORE it so the
    runner re-executes the step and the manual hook gets a chance
    to open the review window.

    Without the bypass, the GUI's bad-channels eye-click in manual
    mode would silently load the cached signal and never open
    Svarog / MNE — defeating the user's request to re-review.
    """
    cfg = _cfg()
    # Stamp fresh snapshots for trim, resample, and bad_channels.
    _stamp_and_save(tmp_path, "signal", "trim", _step_hash(cfg, "trim"))
    _stamp_and_save(tmp_path, "signal", "resample",
                    _step_hash(cfg, "resample"))
    _stamp_and_save(tmp_path, "signal", "bad_channels",
                    _step_hash(cfg, "bad_channels"))

    # Without the flag → resume lands at bad_channels (idx 2).
    idx, _ = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    assert idx == 2

    # With the flag → cap moves to BEFORE bad_channels; resume lands
    # at the latest upstream snapshot (resample, idx 1).
    cfg["_force_rerun_steps"] = ["bad_channels"]
    idx, _ = _find_resume_point(
        cfg["preprocessing"]["step_order"],
        cfg, str(tmp_path), "signal.fif")
    assert idx == 1
