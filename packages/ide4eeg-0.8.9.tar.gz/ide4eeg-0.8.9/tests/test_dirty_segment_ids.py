"""Regression tests for ``_dirty_segment_ids`` / ``_remove_bad_segments``
event-position contract.

Bug surfaced 2026-04-25: a user pipeline crashed with::

    IndexError: Epoch index 249 is out of bounds

because ``_dirty_segment_ids`` returned segment indices using its own
counter, which got out of sync with ``mne.Epochs`` whenever MNE
silently dropped events at construction (out-of-bounds tmin/tmax,
baseline issues, …).  The fix moved both helpers to a
sample-position contract: ``_dirty_segment_ids`` returns the sample
positions of bad events (matching ``Epochs.events[:, 0]``), and
``_remove_bad_segments`` looks them up there to derive epoch
indices.  Events filtered out by MNE simply don't appear in
``Epochs.events`` and are transparently excluded.

These tests build synthetic signals with various edge-event
configurations and confirm:

1. ``_dirty_segment_ids`` returns sample positions, not segment
   indices.
2. ``_remove_bad_segments`` correctly drops the right epochs even
   when MNE filtered out some events.
3. The end-to-end pipeline doesn't crash on the user-reported case.
"""

import numpy as np
import mne
import pytest

from ide4eeg.preprocessing.rest_and_epochs import (
    _dirty_segment_ids, _cut_segments, _remove_bad_segments)


# ── Builders ──────────────────────────────────────────────────────────


def _build_signal(sfreq=128, n_seconds=10, event_times=None):
    """Synthetic Raw with EEG + STIM channels and events at given times."""
    n = int(sfreq * n_seconds)
    rng = np.random.default_rng(0)
    eeg_data = rng.standard_normal((3, n)) * 1e-6
    stim = np.zeros((1, n))
    for t_sec in event_times or ():
        idx = int(t_sec * sfreq)
        if 0 <= idx < n:
            stim[0, idx] = 1
    data = np.vstack([eeg_data, stim])
    info = mne.create_info(
        ch_names=["C3", "C4", "Cz", "STIM"],
        sfreq=sfreq,
        ch_types=["eeg"] * 3 + ["stim"])
    return mne.io.RawArray(data, info, verbose=False)


def _build_config(tmin=-0.2, tmax=0.5):
    """Minimal config dict the pipeline helpers need."""
    return {
        "segmentation": {"mode": "epochs"},
        "epochs": {
            "start_offset": tmin,
            "stop_offset": tmax,
            "epochs_baseline": "None",
            "tags": {"selected": ["evt"]},
        },
        "artifacts": {"artifact_threshold": 0.0},
    }


# ── Tests ─────────────────────────────────────────────────────────────


def test_returns_sample_positions_not_indices():
    """The helper now returns sample positions (matching
    Epochs.events[:, 0]), not segment indices.
    """
    sfreq = 128
    cfg = _build_config(tmin=-0.2, tmax=0.5)
    event_times = [1.0, 3.0, 5.0, 7.0, 8.5]
    raw = _build_signal(
        sfreq=sfreq, n_seconds=10, event_times=event_times)
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    art_mask = np.ones((3, raw.n_times))
    positions = _dirty_segment_ids(
        raw, cfg, {"all_artifact": art_mask}, tags_desc_id)

    expected_positions = [int(t * sfreq) for t in event_times]
    assert positions == expected_positions, (
        f"Expected sample positions {expected_positions}, "
        f"got {positions}.  The contract is sample-position-based, "
        f"NOT segment-index-based.")


def test_remove_bad_segments_maps_positions_to_indices(monkeypatch):
    """``_remove_bad_segments`` translates positions → epoch indices
    via ``segments.events[:, 0]`` regardless of which segments were
    flagged bad."""
    sfreq = 128
    cfg = _build_config(tmin=-0.2, tmax=0.5)
    event_times = [1.0, 3.0, 5.0, 7.0, 8.5]
    raw = _build_signal(
        sfreq=sfreq, n_seconds=10, event_times=event_times)
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    assert len(segments) == 5

    # Mark the 1st and 4th events bad (positions matching the
    # original event_times list).
    bad_positions = [int(1.0 * sfreq), int(7.0 * sfreq)]
    cleaned, _ = _remove_bad_segments(
        segments, bad_positions, cfg)

    # Should have dropped 2 of the 5 epochs.
    assert len(cleaned) == 3
    # And the remaining epochs should be the ones at t=3, 5, 8.5
    remaining_positions = [int(ev[0]) for ev in cleaned.events]
    expected_remaining = [int(3.0 * sfreq), int(5.0 * sfreq),
                          int(8.5 * sfreq)]
    assert remaining_positions == expected_remaining


def test_pipeline_survives_leading_out_of_bounds_events():
    """End-to-end check on the bug class that crashed the user
    pipeline: MNE drops some events at Epochs construction; the
    artifact-bad list still resolves correctly without IndexError."""
    sfreq = 128
    cfg = _build_config(tmin=-0.5, tmax=0.5)
    # First event at t=0.1 with tmin=-0.5 → window starts at -51
    # samples → MNE drops it. Other events (t=1, 2, 3) are in-bounds.
    raw = _build_signal(
        sfreq=sfreq, n_seconds=5,
        event_times=[0.1, 1.0, 2.0, 3.0])
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    assert len(segments) == 3, (
        f"MNE should keep the 3 in-bounds events; got {len(segments)}")

    art_mask = np.ones((3, raw.n_times))
    positions = _dirty_segment_ids(
        raw, cfg, {"all_artifact": art_mask}, tags_desc_id)

    # The leading out-of-bounds event (at t=0.1) is correctly
    # excluded because its window extends before sample 0.
    expected = [int(t * sfreq) for t in (1.0, 2.0, 3.0)]
    assert positions == expected

    # And _remove_bad_segments handles it gracefully.
    cleaned, _ = _remove_bad_segments(
        segments, positions, cfg)
    assert len(cleaned) == 0  # all in-bounds epochs dropped


def test_pipeline_survives_trailing_out_of_bounds_events():
    """Same robustness check, but with trailing out-of-bounds events.
    MNE drops the last few; positions list must still resolve."""
    sfreq = 128
    tmax = 0.5
    n_seconds = 10
    cfg = _build_config(tmin=-0.2, tmax=tmax)
    edge = n_seconds - tmax + 0.01
    raw = _build_signal(
        sfreq=sfreq, n_seconds=n_seconds,
        event_times=[1.0, 3.0, 5.0, 6.0, 7.0,
                     edge, edge + 0.05, edge + 0.1])
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    assert len(segments) == 5

    art_mask = np.ones((3, raw.n_times))
    positions = _dirty_segment_ids(
        raw, cfg, {"all_artifact": art_mask}, tags_desc_id)

    # Out-of-bounds events at the tail are excluded.
    expected = [int(t * sfreq) for t in (1.0, 3.0, 5.0, 6.0, 7.0)]
    assert positions == expected

    cleaned, _ = _remove_bad_segments(
        segments, positions, cfg)
    assert len(cleaned) == 0


# ── Rest-mode artifact rejection (issue #11 follow-up) ───────────────


def _build_rest_signal(sfreq=128, n_seconds=30):
    """Synthetic Raw with EEG + (empty) STIM, no file events.
    REST annotations are attached by the caller via _add_rest_markers
    or directly with set_annotations."""
    n = int(sfreq * n_seconds)
    rng = np.random.default_rng(1)
    eeg_data = rng.standard_normal((3, n)) * 1e-6
    stim = np.zeros((1, n))
    data = np.vstack([eeg_data, stim])
    info = mne.create_info(
        ch_names=["C3", "C4", "Cz", "STIM"],
        sfreq=sfreq,
        ch_types=["eeg"] * 3 + ["stim"])
    return mne.io.RawArray(data, info, verbose=False)


def _build_rest_config(window_length=5.0):
    """Rest-mode config: continuous segments of ``window_length`` s."""
    return {
        "segmentation": {"mode": "rest"},
        "rest": {
            "rest_duration": [0, ""],
            "window_length": window_length,
            "whole_signal": False,
        },
        "epochs": {
            "start_offset": 0.0,
            "stop_offset": window_length,
            "epochs_baseline": "None",
            "tags": {"selected": []},
        },
        "artifacts": {"artifact_threshold": 0.3},
    }


def test_rest_mode_dirty_segment_ids_uses_rest_annotations():
    """Issue #11 follow-up: ``_dirty_segment_ids`` in rest mode must
    iterate REST annotations (via ``get_segment_events``), not the
    file's STIM channel.  Otherwise rest-mode artifact accounting is
    a no-op and every rest segment survives regardless of contamination.
    """
    from ide4eeg.preprocessing.channels_and_signal import (
        _add_rest_markers, REST_EVENT_ID)
    sfreq = 128
    window = 5.0
    cfg = _build_rest_config(window_length=window)
    raw = _build_rest_signal(sfreq=sfreq, n_seconds=30)
    _add_rest_markers(raw, cfg)

    # Build an artifact mask that flags every sample of the second
    # rest window (samples [window*sfreq, 2*window*sfreq)).  At
    # artifact_threshold=0.3 the second segment is well above
    # threshold; all others are clean.
    n = raw.n_times
    win_n = int(window * sfreq)
    mask = np.zeros((3, n))
    mask[:, win_n:2 * win_n] = 1
    positions = _dirty_segment_ids(raw, cfg, {"all_artifact": mask})

    # Exactly one bad segment at sample position win_n.  Pre-fix this
    # returned [] because the helper read signal["STIM"][0] which has
    # no rest events.
    assert positions == [win_n], (
        f"Expected the second rest window (at sample {win_n}) to be "
        f"flagged bad, got {positions}.  This is the rest-mode "
        f"regression issue #11 follow-up.")


def test_rest_mode_remove_bad_segments_actually_drops():
    """End-to-end: REST-annotated signal → cut → score → remove.
    The artifact-contaminated rest window must be dropped."""
    from ide4eeg.preprocessing.channels_and_signal import (
        _add_rest_markers)
    sfreq = 128
    window = 5.0
    cfg = _build_rest_config(window_length=window)
    raw = _build_rest_signal(sfreq=sfreq, n_seconds=30)
    _add_rest_markers(raw, cfg)

    segments, _ = _cut_segments(raw, cfg, {"rest": 1})
    n_segments = len(segments)
    assert n_segments >= 2, (
        f"Need at least 2 rest segments to exercise selective drop; "
        f"got {n_segments}")

    # Flag the second segment as fully contaminated.
    win_n = int(window * sfreq)
    mask = np.zeros((3, raw.n_times))
    mask[:, win_n:2 * win_n] = 1
    positions = _dirty_segment_ids(raw, cfg, {"all_artifact": mask})
    cleaned, _ = _remove_bad_segments(segments, positions, cfg)

    assert len(cleaned) == n_segments - 1, (
        f"Expected exactly one dropped rest segment, got "
        f"{n_segments - len(cleaned)}")
    # And the survivors are NOT the second window.
    surviving_starts = [int(ev[0]) for ev in cleaned.events]
    assert win_n not in surviving_starts, (
        "The artifact-contaminated rest window survived rejection")


def test_unmatched_positions_silently_skipped():
    """Defensive check: a position not in segments.events[:, 0] (e.g.
    upstream re-cropping changed which events became epochs) is
    silently skipped — no IndexError, no crash."""
    sfreq = 128
    cfg = _build_config(tmin=-0.2, tmax=0.5)
    raw = _build_signal(
        sfreq=sfreq, n_seconds=10,
        event_times=[1.0, 3.0, 5.0])
    tags_desc_id = {"evt": 1}
    segments, _ = _cut_segments(raw, cfg, tags_desc_id)

    # Mix valid + invalid sample positions.
    bad_positions = [int(1.0 * sfreq),     # valid
                     int(99.9 * sfreq),    # not in events → skipped
                     int(5.0 * sfreq)]     # valid
    cleaned, _ = _remove_bad_segments(
        segments, bad_positions, cfg)

    # Should drop 2 of 3 (the matched ones); the non-matching
    # position is silently ignored.
    assert len(cleaned) == 1
    assert int(cleaned.events[0][0]) == int(3.0 * sfreq)
