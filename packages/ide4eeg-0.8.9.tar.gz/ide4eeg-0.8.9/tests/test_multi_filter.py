"""Tests for Phase 2 multi-instance filtering (2026-04-28).

Filtering is the first step that can appear multiple times in
``step_order`` at user-chosen positions, identified by tokens of the
form ``"filtering:<id>"`` with per-id config under
``cfg["filters"][<id>]``.

These tests lock the pipeline-side contract:

1. ``_split_step_id`` correctly parses base / id from step tokens.
2. ``validate_step_order`` tolerates ID suffixes and detects
   constraint violations across multiple instances.
3. ``_step_filtering`` picks the right config slice given the
   current step id, falling back to legacy flat layout.
4. ``_save_step_signal_if_requested`` namespaces output filenames
   by id and reads per-instance save flags.
"""

import os
from unittest import mock

import mne
import numpy as np
import pytest

from ide4eeg.preprocessing.preprocessing import (
    _save_step_signal_if_requested,
    _split_step_id,
    _step_filtering,
    validate_step_order,
)


# ── _split_step_id ───────────────────────────────────────────────────


class TestSplitStepId:
    def test_bare_name_returns_empty_id(self):
        assert _split_step_id("filtering") == ("filtering", "")

    def test_id_token_round_trip(self):
        assert _split_step_id("filtering:a3f2") == ("filtering", "a3f2")

    def test_multi_colon_only_first_split(self):
        # Defensive: ids should never contain colons, but if they do
        # the partition keeps everything after the first one as the id.
        assert _split_step_id("filtering:a:b") == ("filtering", "a:b")


# ── validate_step_order with multi-instance ──────────────────────────


class TestValidateStepOrderMultiInstance:
    """Constraint matching must tolerate ":<id>" suffixes and detect
    violations across multiple positions of the same base step."""

    def test_legacy_bare_names_unchanged(self):
        ok, errs, warns = validate_step_order(
            ["mp_decomposition", "mp_filter"])
        assert ok and not errs
        ok, errs, warns = validate_step_order(
            ["mp_filter", "mp_decomposition"])
        assert not ok
        assert any("decomposition" in str(e).lower() for e in errs)

    def test_id_suffixed_filtering_satisfies_soft_constraint(self):
        # filtering:abc before ica → soft "filtering before ica" OK.
        _, _, warns = validate_step_order(
            ["filtering:abc", "ica"])
        assert not any("ica" in str(w).lower() for w in warns)

    def test_id_suffixed_filtering_violates_soft_constraint(self):
        # filtering:abc after ica → soft "filtering before ica" fires.
        _, _, warns = validate_step_order(
            ["ica", "filtering:abc"])
        assert any("ica" in str(w).lower() for w in warns)

    def test_multi_filter_violation_when_any_after(self):
        # First filter before ICA, second after → still a violation
        # (ANY filtering after ICA is a soft warning).
        _, _, warns = validate_step_order(
            ["filtering:a", "ica", "filtering:b"])
        assert any("ica" in str(w).lower() for w in warns)

    def test_multi_filter_clean_when_all_before(self):
        _, _, warns = validate_step_order(
            ["filtering:a", "filtering:b", "ica"])
        assert not any("ica" in str(w).lower() for w in warns)


# ── _step_filtering config slicing ───────────────────────────────────


def _make_signal():
    rng = np.random.default_rng(0)
    info = mne.create_info(
        ["EEG1", "EEG2", "STIM"], sfreq=100,
        ch_types=["eeg", "eeg", "stim"])
    data = rng.standard_normal((3, 200)) * 1e-6
    return mne.io.RawArray(data, info, verbose=False)


def _filter_cfg(hp=0.5, lp=30, notch=0, method="iir"):
    return {
        "highpass_freq": hp, "lowpass_freq": lp,
        "notch_freq": notch, "method": method,
    }


class TestStepFilteringDispatch:
    """``_step_filtering`` must read ``cfg["filters"][step_id]`` when
    an id is supplied, else fall back to the flat legacy layout."""

    def test_legacy_flat_filters_used_when_no_id(self, tmp_path):
        sig = _make_signal()
        state = {
            "signal": sig.copy(),
            "config": {"filters": _filter_cfg(hp=1, lp=20)},
            "path": str(tmp_path),
        }
        with mock.patch(
                "ide4eeg.preprocessing.preprocessing._filter_signal"
                ) as mfilter:
            mfilter.return_value = sig.copy()
            _step_filtering(state)
        passed_cfg = mfilter.call_args[0][1]
        assert passed_cfg["filters"]["highpass_freq"] == 1
        assert passed_cfg["filters"]["lowpass_freq"] == 20

    def test_id_keyed_filters_sliced_by_step_id(self, tmp_path):
        sig = _make_signal()
        state = {
            "signal": sig.copy(),
            "config": {"filters": {
                "abc": _filter_cfg(hp=0.1, lp=40),
                "xyz": _filter_cfg(hp=2, lp=10),
            }},
            "path": str(tmp_path),
            "_current_step_id": "xyz",
        }
        with mock.patch(
                "ide4eeg.preprocessing.preprocessing._filter_signal"
                ) as mfilter:
            mfilter.return_value = sig.copy()
            _step_filtering(state)
        passed_cfg = mfilter.call_args[0][1]
        assert passed_cfg["filters"]["highpass_freq"] == 2
        assert passed_cfg["filters"]["lowpass_freq"] == 10

    def test_id_keyed_no_id_uses_first_entry(self, tmp_path):
        sig = _make_signal()
        state = {
            "signal": sig.copy(),
            "config": {"filters": {
                "abc": _filter_cfg(hp=0.1, lp=40),
            }},
            "path": str(tmp_path),
        }
        with mock.patch(
                "ide4eeg.preprocessing.preprocessing._filter_signal"
                ) as mfilter:
            mfilter.return_value = sig.copy()
            _step_filtering(state)
        passed_cfg = mfilter.call_args[0][1]
        assert passed_cfg["filters"]["highpass_freq"] == 0.1


# ── _save_step_signal_if_requested with ids ──────────────────────────


class TestSaveStepWithId:
    def test_id_tagged_save_writes_id_in_filename(self, tmp_path):
        sig = _make_signal()
        out_dir = tmp_path
        state = {
            "signal": sig,
            "config": {"filters": {
                "abc": {"save": True, **_filter_cfg()},
            }},
            "path": str(out_dir),
            "file_name": "demo",
        }
        _save_step_signal_if_requested(state, "filtering:abc")
        expected = out_dir / "saved_steps" / "demo-filtered-abc-raw.fif"
        assert expected.exists()

    def test_per_instance_save_flag_false_skips_save(self, tmp_path):
        sig = _make_signal()
        state = {
            "signal": sig,
            "config": {"filters": {
                "abc": {"save": False, **_filter_cfg()},
            }},
            "path": str(tmp_path),
            "file_name": "demo",
        }
        _save_step_signal_if_requested(state, "filtering:abc")
        assert not list((tmp_path / "saved_steps").glob("*")) \
            if (tmp_path / "saved_steps").exists() else True

    def test_legacy_flat_save_unchanged_filename(self, tmp_path):
        sig = _make_signal()
        state = {
            "signal": sig,
            "config": {"filters": {"save": True, **_filter_cfg()}},
            "path": str(tmp_path),
            "file_name": "demo",
        }
        _save_step_signal_if_requested(state, "filtering")
        expected = tmp_path / "saved_steps" / "demo-filtered-raw.fif"
        assert expected.exists()
