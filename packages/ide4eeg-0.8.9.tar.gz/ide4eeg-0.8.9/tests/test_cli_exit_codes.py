"""CLI exit-code + error-message smoke matrix.

End-user-facing contract: ``ide4eeg`` exits cleanly with an actionable
message on the obvious wrong-input scenarios, without spilling a
Python traceback.  The CLI surface is the user's first interaction
with the tool; cryptic exits here are the worst kind of silly
release bug.

Each test invokes the CLI as a subprocess (so ``sys.exit`` exit codes
are observable) and asserts on:

- The exit code -- 0 for ``--version``, 1 for "file not found",
  2 for "wrong file type" / "missing arg" (per Unix convention,
  argparse already uses 2 for usage errors).
- A substring of the user-facing error message -- so we lock the
  remediation phrase, not the exact wording.

Scope:

- ``--run`` (batch) only.  GUI mode would launch Qt; out of scope
  for a CLI smoke.
- No tests that actually run the pipeline (slow; covered by the
  golden tests instead).
"""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

import pytest


_REPO_ROOT = Path(__file__).resolve().parent.parent
_PYTHON = sys.executable  # the venv we're running in


def _invoke(*args: str, timeout: int = 30):
    """Run ``ide4eeg <args>`` as a subprocess; return CompletedProcess."""
    return subprocess.run(
        [_PYTHON, "-m", "ide4eeg", *args],
        capture_output=True, text=True, timeout=timeout,
        cwd=_REPO_ROOT, check=False,
    )


# ---------------------------------------------------------------------
# --version
# ---------------------------------------------------------------------

def test_version_exits_zero_and_prints_version():
    """``ide4eeg --version`` is the cheapest possible end-to-end CLI
    smoke -- if it fails, something is wrong at the import or
    argparse layer.  Catches stale import errors after a refactor."""
    res = _invoke("--version")
    assert res.returncode == 0, (
        f"--version exit code {res.returncode}; "
        f"stderr:\n{res.stderr}")
    out = res.stdout + res.stderr
    assert "ide4eeg" in out.lower(), (
        f"--version output missing 'ide4eeg':\n{out}")


# ---------------------------------------------------------------------
# --run without a config path
# ---------------------------------------------------------------------

def test_run_without_path_exits_two_with_usage_hint():
    res = _invoke("--run")
    assert res.returncode == 2, (
        f"`--run` without path: exit {res.returncode}, "
        f"expected 2; stderr:\n{res.stderr}")
    assert "missing config path" in res.stderr.lower()


# ---------------------------------------------------------------------
# --run <nonexistent path>
# ---------------------------------------------------------------------

def test_run_missing_file_exits_one():
    res = _invoke("--run", "/nonexistent/path/to/config.toml")
    assert res.returncode == 1, (
        f"missing config: exit {res.returncode}, expected 1; "
        f"stderr:\n{res.stderr}")
    # The message comes from ``_run_batch`` and routes through the
    # logger; just check the path is named so the user sees what's
    # being looked for.
    assert "config.toml" in res.stderr.lower() or \
           "not found" in res.stderr.lower()


# ---------------------------------------------------------------------
# --run <examples manifest> (post-v0.8.8 UX guard)
# ---------------------------------------------------------------------

def test_run_manifest_file_exits_two_and_points_at_real_configs(
        tmp_path):
    """The v0.8.9 manifest detector must fire end-to-end through the
    CLI when a user accidentally points ``--run`` at an example.toml
    manifest.  Locks the catch handler in cli._run_batch."""
    manifest = tmp_path / "example.toml"
    manifest.write_text("""\
title = "Smoke example"
description = "manifest synthesized for the CLI smoke test"

[[configs]]
file = "config_smoke.toml"
label = "Default smoke pipeline"
""")
    res = _invoke("--run", str(manifest))
    assert res.returncode == 2, (
        f"manifest --run: exit {res.returncode}, expected 2; "
        f"stderr:\n{res.stderr}")
    assert "manifest" in res.stderr.lower(), (
        f"manifest error message missing 'manifest':\n{res.stderr}")
    assert "config_smoke.toml" in res.stderr, (
        f"manifest error didn't list the referenced real config:"
        f"\n{res.stderr}")
    # No Python traceback ("Traceback (most recent call last)") -- the
    # catch handler in cli._run_batch should print a clean error.
    assert "Traceback" not in res.stderr, (
        f"manifest path leaked a traceback; expected clean exit:\n"
        f"{res.stderr}")


# ---------------------------------------------------------------------
# --run <malformed TOML>
# ---------------------------------------------------------------------

def test_run_malformed_toml_exits_nonzero():
    """A TOML that doesn't even parse should exit nonzero but not
    spam a deep MNE traceback.  ``-t`` would show the full trace;
    without it, we set ``sys.tracebacklimit = 0`` so the user sees
    just the exception name + message."""
    with tempfile.NamedTemporaryFile(
            mode="w", suffix=".toml", delete=False) as fh:
        fh.write("this = is not = valid toml [\n")
        path = fh.name
    try:
        res = _invoke("--run", path)
        assert res.returncode != 0, (
            f"malformed TOML: exit code {res.returncode}, "
            f"expected nonzero; stderr:\n{res.stderr}")
    finally:
        Path(path).unlink(missing_ok=True)


# ---------------------------------------------------------------------
# argparse usage on totally invalid args
# ---------------------------------------------------------------------

def test_unknown_flag_exits_two():
    """argparse default for unrecognised args is exit 2; lock that
    behaviour so we don't accidentally swallow CLI mistakes."""
    res = _invoke("--nonexistent-flag", "value")
    assert res.returncode == 2


# ---------------------------------------------------------------------
# --help
# ---------------------------------------------------------------------

def test_help_exits_zero_and_contains_usage():
    res = _invoke("--help")
    assert res.returncode == 0
    out = res.stdout + res.stderr
    assert "usage" in out.lower()
    # Spot-check that the examples block landed (it's in the epilog
    # and historically broke when someone reformatted the parser).
    assert "myconfig.toml" in out or "--run" in out
