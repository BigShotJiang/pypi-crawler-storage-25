"""Tests for preprocessing step ordering, validation, and legacy derivation."""

import pytest

from ide4eeg.preprocessing.preprocessing import (
    validate_step_order,
    _derive_step_order,
    ConstraintViolation,
    DEFAULT_HARD_CONSTRAINTS,
    DEFAULT_SOFT_CONSTRAINTS,
    DEFAULT_STEP_ORDER,
    HARD_CONSTRAINT_RATIONALES,
    SOFT_CONSTRAINT_RATIONALES,
    STEP_REGISTRY,
)


# ── validate_step_order ─────────────────────────────────────────────


class TestValidateStepOrder:
    """Tests for the step-order constraint checker."""

    def test_default_order_is_valid(self):
        valid, errors, warnings = validate_step_order(DEFAULT_STEP_ORDER)
        assert valid
        assert errors == []

    def test_hard_constraint_violation(self):
        """mp_filter before mp_decomposition violates a hard constraint.

        After the Phase 2 refactor, the only default hard constraint is
        the mp data-flow rule — every other historical ordering rule
        has been removed in favour of an "only-the-obvious" policy."""
        order = ["mp_filter", "mp_decomposition"]
        valid, errors, _warnings = validate_step_order(order)
        assert not valid
        assert len(errors) >= 1
        assert any("before" in e for e in errors)

    def test_soft_constraint_produces_warning(self):
        """ica before filtering violates a soft constraint (warning, not error)."""
        order = ["resample", "bad_channels", "montage", "ica", "filtering"]
        valid, _errors, warnings = validate_step_order(order)
        assert valid  # soft constraints don't make it invalid
        assert len(warnings) >= 1

    def test_missing_steps_dont_trigger_constraints(self):
        """Constraints only apply to steps that are actually in the list."""
        order = ["resample", "filtering"]  # no montage — constraint skipped
        valid, errors, warnings = validate_step_order(order)
        assert valid
        assert errors == []

    def test_empty_order_is_valid(self):
        valid, errors, warnings = validate_step_order([])
        assert valid
        assert errors == []
        assert warnings == []

    def test_single_step_is_valid(self):
        valid, errors, warnings = validate_step_order(["filtering"])
        assert valid

    def test_custom_hard_constraint(self):
        """Custom hard constraint is enforced."""
        hard = [["ica", "artifacts"]]
        order = ["artifacts", "ica"]
        valid, errors, _w = validate_step_order(order, hard_constraints=hard,
                                                soft_constraints=[])
        assert not valid
        assert len(errors) == 1

    def test_all_registry_keys_are_strings(self):
        """Every key in STEP_REGISTRY is a valid string."""
        for key in STEP_REGISTRY:
            assert isinstance(key, str)
            assert len(key) > 0

    def test_duplicate_steps_last_position_wins(self):
        """With duplicate steps, later position wins in the dict — may violate.

        After the Phase 2 refactor the only default hard constraint is
        ``mp_decomposition → mp_filter``.  With duplicate mp_decomposition
        entries, the later position wins in the position dict, so placing
        mp_filter between the two copies still violates the constraint."""
        order = ["mp_decomposition", "mp_filter", "mp_decomposition"]
        # Position dict: mp_decomposition=2, mp_filter=1, so
        # mp_decomposition(2) > mp_filter(1) — constraint violated.
        valid, errors, _w = validate_step_order(order)
        assert not valid


# ── _derive_step_order ───────────────────────────────────────────────


class TestDeriveStepOrder:
    """Tests for legacy config flag → step order derivation."""

    def test_eeg_artifacts_enabled(self):
        config = {"prepare_eeg_artifacts": True, "prepare_ica": False}
        order = _derive_step_order(config)
        assert "trim" in order
        assert "resample" in order
        assert "bad_channels" in order
        assert "montage" in order
        assert "filtering" in order
        assert "chosen_channels" in order
        assert "ica" not in order

    def test_ica_requires_eeg_artifacts(self):
        """ICA only appears when prepare_eeg_artifacts is also enabled."""
        config = {"prepare_eeg_artifacts": True, "prepare_ica": True}
        order = _derive_step_order(config)
        assert "ica" in order

    def test_ica_alone_not_added(self):
        """prepare_ica without prepare_eeg_artifacts produces no ICA step."""
        config = {"prepare_eeg_artifacts": False, "prepare_ica": True}
        order = _derive_step_order(config)
        assert "ica" not in order

    def test_video_artifacts_only(self):
        """Video artifacts without EEG artifacts adds gaze_artifacts only."""
        config = {"prepare_eeg_artifacts": False,
                  "prepare_video_artifacts": True}
        order = _derive_step_order(config)
        assert "gaze_artifacts" in order
        assert "eeg_artifacts" not in order
        assert "resample" not in order

    def test_nothing_enabled(self):
        """With no legacy flags enabled the derived order is just
        ``["trim"]`` — trim used to run unconditionally as part of the
        fixed preamble and has been folded into the reorderable set
        after the Phase 2 refactor, so legacy configs still get it."""
        config = {"prepare_eeg_artifacts": False, "prepare_ica": False}
        order = _derive_step_order(config)
        assert order == ["trim"]

    def test_mp_decomposition_legacy_flag_logs_error(self, caplog):
        """``prepare_mp_decomposition`` was deleted in the MP-book-reuse
        change.  Configs that still set it get a clear error logged and
        MP is NOT added to the derived step order — users must migrate
        to ``preprocessing.step_order``."""
        import logging
        config = {"prepare_mp_decomposition": True}
        with caplog.at_level(logging.ERROR):
            order = _derive_step_order(config)
        assert "mp_decomposition" not in order
        assert any("prepare_mp_decomposition" in r.message
                   for r in caplog.records), \
            "Expected an error log mentioning the deleted legacy flag"

    def test_mp_filter_flag(self):
        config = {"prepare_mp_filter": True}
        order = _derive_step_order(config)
        assert "mp_filter" in order

    def test_derived_order_passes_validation(self):
        """Order derived from any legacy flag combo should be valid."""
        configs = [
            {"prepare_eeg_artifacts": True, "prepare_ica": True},
            {"prepare_eeg_artifacts": True, "prepare_ica": False},
            {"prepare_video_artifacts": True},
            {"prepare_eeg_artifacts": True, "prepare_video_artifacts": True,
             "prepare_ica": True, "prepare_mp_filter": True},
        ]
        for cfg in configs:
            order = _derive_step_order(cfg)
            valid, errors, _w = validate_step_order(order)
            assert valid, f"Invalid order {order} for config {cfg}: {errors}"


# ── Phase 2 refactor: trim-as-reorderable + minimal hard constraints ─


class TestTrimAsReorderableStep:
    """Phase 2 (2026-04) folded ``trim`` from the fixed preamble into
    the reorderable step set.  These tests lock the new shape so a
    future refactor doesn't silently revert it."""

    def test_trim_is_registered(self):
        """Trim must be a first-class entry in STEP_REGISTRY with a
        callable wrapper and a human-readable label."""
        assert "trim" in STEP_REGISTRY
        entry = STEP_REGISTRY["trim"]
        assert callable(entry.handler)
        assert isinstance(entry.label, str) and entry.label

    def test_trim_appears_first_in_default_order(self):
        """Default ordering still puts trim at the very front — it is
        the least surprising place and matches the old preamble."""
        assert "trim" in DEFAULT_STEP_ORDER
        assert DEFAULT_STEP_ORDER[0] == "trim"

    def test_default_hard_constraints_is_mp_only(self):
        """The Phase 2 "only-the-obvious" policy leaves exactly one
        default hard constraint: mp_filter consumes mp_decomposition's
        atoms, so it must come after it."""
        assert DEFAULT_HARD_CONSTRAINTS == [
            ["mp_decomposition", "mp_filter"],
        ]


# ── Phase 2: soft-constraint rationales + ConstraintViolation ────────


class TestSoftConstraintRationales:
    """Phase 2 (2026-04) attaches scientific rationale to every soft
    constraint so the GUI can surface the reasoning when a reorder
    would create a violation.  These tests lock the rationale set and
    the ``ConstraintViolation`` shape that carries it."""

    def test_default_soft_set_is_ica_prerequisites(self):
        """The default soft constraints are the two ICA prerequisites:
        Winkler 2015 (filter → ICA) and bad channels → ICA (clean
        input). filter → MP was dropped — atom-based downstream
        analyses operate on the book directly, and pre-MP filtering
        risks introducing ringing artefacts that MP would then
        decompose into spurious atoms."""
        assert DEFAULT_SOFT_CONSTRAINTS == [
            ["filtering", "ica"],
            ["bad_channels", "ica"],
        ]

    def test_every_default_soft_constraint_has_a_rationale(self):
        """The GUI modal expects a non-empty rationale for every
        default soft constraint — otherwise users would see an empty
        explanation box."""
        for before, after in DEFAULT_SOFT_CONSTRAINTS:
            assert (before, after) in SOFT_CONSTRAINT_RATIONALES, \
                f"Missing rationale for ({before}, {after})"
            rationale = SOFT_CONSTRAINT_RATIONALES[(before, after)]
            assert len(rationale) >= 40, \
                f"Rationale for ({before}, {after}) is too short " \
                f"— users want a sentence or two, not a stub."

    def test_every_default_hard_constraint_has_a_rationale(self):
        for pair in DEFAULT_HARD_CONSTRAINTS:
            before, after = pair
            assert (before, after) in HARD_CONSTRAINT_RATIONALES, \
                f"Missing rationale for ({before}, {after})"

    def test_soft_violation_returns_constraint_violation_with_rationale(
            self):
        """A soft violation must produce a ``ConstraintViolation`` that
        (a) is a str with the short summary, and (b) exposes
        ``severity``, ``before``, ``after``, and ``rationale`` for
        GUI consumption."""
        order = ["ica", "filtering"]  # filtering → ica violated
        valid, _errors, warnings = validate_step_order(order)
        assert valid  # soft never blocks
        assert len(warnings) == 1
        v = warnings[0]
        # str subclass — existing callers keep working
        assert isinstance(v, str)
        assert "before" in v.lower() or "comes" in v.lower()
        # Structured fields for the GUI
        assert isinstance(v, ConstraintViolation)
        assert v.severity == "soft"
        assert v.before == "filtering"
        assert v.after == "ica"
        assert "Winkler" in v.rationale

    def test_hard_violation_returns_constraint_violation_with_rationale(
            self):
        order = ["mp_filter", "mp_decomposition"]
        valid, errors, _w = validate_step_order(order)
        assert not valid
        assert len(errors) == 1
        v = errors[0]
        assert isinstance(v, ConstraintViolation)
        assert v.severity == "hard"
        assert v.before == "mp_decomposition"
        assert v.after == "mp_filter"
        assert "atoms" in v.rationale.lower()

    def test_constraint_violation_joins_as_string(self):
        """Existing callers do ``"; ".join(errors)`` — that must still
        work on a list of ``ConstraintViolation`` objects."""
        order = ["mp_filter", "mp_decomposition"]
        _valid, errors, _w = validate_step_order(order)
        joined = "; ".join(errors)
        assert isinstance(joined, str)
        assert "before" in joined.lower()
