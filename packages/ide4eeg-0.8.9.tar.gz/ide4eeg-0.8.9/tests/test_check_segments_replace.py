"""Behaviour lock for the replace-semantics rewrite of
``_check_segments`` (2026-05-02).

Before this change the GUI hook only saw the *survivors* of
``_remove_bad_segments``; PTP-rejected epochs were silently dropped
before review, so Svarog's bad-epochs view couldn't display them and
the user had no way to confirm or undo a PTP rejection.  The new
contract:

* Hook receives the *original* (pre-rejection) Epochs plus the set
  of indices that PTP flagged.
* Hook returns the *final* rejection set in original-event indices.
* ``_check_segments`` rebuilds ``clean_segments`` from ``original``
  by dropping that final set — fully replacing whatever
  ``_remove_bad_segments`` had concluded.

The CLI path (no hook) keeps the legacy add-only shape — MNE's
interactive plot has no preselect mechanism, so the user can only
mark *more* on top of the already-cleaned subset.
"""

import mne
import numpy as np
import pytest

from ide4eeg.preprocessing.rest_and_epochs import _check_segments


def _make_epochs(n_events=10, sfreq=250.0):
    """Build a 10-epoch synthetic fixture for the contract tests."""
    n_ch, n_samples = 4, int(60 * sfreq)
    rng = np.random.default_rng(0)
    data = rng.standard_normal((n_ch, n_samples)) * 1e-6
    info = mne.create_info(
        [f"EEG{i:03d}" for i in range(n_ch)],
        sfreq=sfreq, ch_types="eeg")
    raw = mne.io.RawArray(data, info, verbose=False)
    events = np.array(
        [[int((1 + i * 5) * sfreq), 0, 1] for i in range(n_events)],
        dtype=int)
    return mne.Epochs(
        raw, events, event_id={"X": 1}, tmin=-0.2, tmax=1.0,
        baseline=None, preload=True, verbose=False)


def _make_cfg(hook=None, check=True):
    return {
        "_manual_hooks": ({"segments": hook} if hook else None),
        "segmentation": {"mode": "epochs"},
        "epochs": {
            "check_epochs": check,
            "start_offset": -0.2, "stop_offset": 1.0,
            "baseline": None,
            "reject_dict": None, "flat_dict": None,
        },
    }


# ── Replace-semantics contract ───────────────────────────────────────


class TestReplaceSemantics:
    def test_hook_receives_original_epochs_not_cleaned(self):
        original = _make_epochs(n_events=10)
        seg_clean = original.copy()
        seg_clean.drop([2, 5, 7], reason="USER")
        captured = {}

        def hook(eps, preselected):
            captured["n_eps"] = len(eps)
            captured["preselected"] = set(preselected)
            return set(preselected)  # no change

        _check_segments(seg_clean, original, [2, 5, 7],
                        _make_cfg(hook))
        # Hook saw the FULL pre-rejection epochs object, not the 7
        # survivors — that's what makes Svarog's bad-epoch view show
        # PTP-rejected epochs in the first place.
        assert captured["n_eps"] == 10
        assert captured["preselected"] == {2, 5, 7}

    def test_un_marking_all_preselected_un_does_ptp_rejection(self):
        """User opens Svarog, un-checks every PTP-flagged epoch (says
        'I disagree, none of these are actually bad'), saves.  The
        cleaned segments should now contain all 10 originals."""
        original = _make_epochs(n_events=10)
        seg_clean = original.copy()
        seg_clean.drop([2, 5, 7], reason="USER")

        def hook_unmark_all(eps, preselected):
            return set()

        clean, bad = _check_segments(
            seg_clean, original, [2, 5, 7],
            _make_cfg(hook_unmark_all))
        assert len(clean) == 10
        assert bad == []

    def test_subset_replace_swaps_final_rejection_set(self):
        """User keeps idx=5 from PTP, un-marks 2 and 7, adds 9.  The
        returned set is the FINAL rejection list — replace semantics
        kicks 2 and 7 out and pulls 9 in."""
        original = _make_epochs(n_events=10)
        seg_clean = original.copy()
        seg_clean.drop([2, 5, 7], reason="USER")

        def hook_subset(eps, preselected):
            return {5, 9}

        clean, bad = _check_segments(
            seg_clean, original, [2, 5, 7],
            _make_cfg(hook_subset))
        assert len(clean) == 8
        assert sorted(bad) == [5, 9]

    def test_hook_returning_preselect_unchanged_keeps_ptp_set(self):
        """Mirrors a Svarog cancel where ``_review_bad_epochs`` falls
        back to returning the preselect set — the cleaned segments
        should match the post-PTP state exactly."""
        original = _make_epochs(n_events=10)
        seg_clean = original.copy()
        seg_clean.drop([2, 5, 7], reason="USER")

        def hook_cancel(eps, preselected):
            return set(preselected)

        clean, bad = _check_segments(
            seg_clean, original, [2, 5, 7],
            _make_cfg(hook_cancel))
        assert len(clean) == 7
        assert sorted(bad) == [2, 5, 7]


# ── No-hook (CLI) path ───────────────────────────────────────────────


class TestNoHookPath:
    def test_check_off_passes_through_clean_unchanged(self):
        original = _make_epochs(n_events=10)
        seg_clean = original.copy()
        seg_clean.drop([2, 5, 7], reason="USER")
        clean, bad = _check_segments(
            seg_clean, original, [2, 5, 7],
            _make_cfg(check=False))
        assert len(clean) == 7
        assert sorted(bad) == [2, 5, 7]

    def test_empty_input_returns_immediately(self):
        # Build a fixture then drop everything so we have a valid
        # Epochs with len()==0; the early-return guard at the top of
        # _check_segments should kick in before any hook is touched.
        original = _make_epochs(n_events=3)
        empty = original.copy()
        empty.drop(list(range(3)), reason="USER")
        called = {"hook": False}

        def should_not_run(eps, preselected):
            called["hook"] = True
            return set()

        clean, bad = _check_segments(
            empty, original, [0, 1, 2],
            _make_cfg(should_not_run))
        assert len(clean) == 0
        assert bad == []
        assert called["hook"] is False
