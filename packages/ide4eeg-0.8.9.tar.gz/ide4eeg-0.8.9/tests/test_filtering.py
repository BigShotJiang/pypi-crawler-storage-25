"""Tests for the filtering pipeline: design_iir_filter, filter_signal(), mgr_filter.

Verifies:
- Filter design at various sampling rates
- Nyquist validation (impossible filters rejected gracefully)
- SOS numerical stability at extreme rates
- Actual frequency attenuation (signal content check)
- IIR and FIR paths produce correct bandpass behavior
- mgr_filter SOS path
- Backward compatibility with legacy config
"""

import numpy as np
import pytest
import scipy.signal as ss

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_sine(freq_hz, duration=2.0, fs=512.0, amplitude=1.0):
    """Generate a pure sine wave."""
    t = np.arange(int(fs * duration)) / fs
    return amplitude * np.sin(2 * np.pi * freq_hz * t), t


def measure_power(signal, freq_hz, fs):
    """Measure power at a specific frequency using FFT."""
    n = len(signal)
    fft = np.abs(np.fft.rfft(signal))
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    # Find the bin closest to freq_hz
    idx = np.argmin(np.abs(freqs - freq_hz))
    return fft[idx] ** 2


def make_test_signal(fs=512.0, duration=4.0):
    """Create a composite test signal: 0.05 Hz drift + 10 Hz alpha + 50 Hz line noise."""
    t = np.arange(int(fs * duration)) / fs
    drift = 50.0 * np.sin(2 * np.pi * 0.05 * t)      # slow drift
    alpha = 10.0 * np.sin(2 * np.pi * 10 * t)         # 10 Hz alpha
    line = 5.0 * np.sin(2 * np.pi * 50 * t)           # 50 Hz line noise
    return drift + alpha + line, t


# ---------------------------------------------------------------------------
# Tests: design_iir_filter
# ---------------------------------------------------------------------------

class TestDesignIIRFilter:
    """Test the design_iir_filter function."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from ide4eeg.preprocessing.channels_and_signal import design_iir_filter
        self.design = design_iir_filter

    def test_highpass_basic(self):
        sos, info = self.design("highpass", 1.0, 512)
        assert sos is not None
        assert info["ftype"] == "butter"
        assert info["order"] > 0

    def test_lowpass_basic(self):
        sos, info = self.design("lowpass", 30.0, 512)
        assert sos is not None
        assert info["ftype"] == "butter"

    def test_notch_basic(self):
        sos, info = self.design("notch", 50.0, 512)
        assert sos is not None
        assert info["ftype"] == "cheby2"

    def test_zero_freq_returns_none(self):
        sos, info = self.design("highpass", 0, 512)
        assert sos is None

    def test_negative_freq_returns_none(self):
        sos, info = self.design("lowpass", -5, 512)
        assert sos is None

    @pytest.mark.parametrize("fs", [128, 256, 500, 512, 1000, 2048])
    def test_highpass_various_fs(self, fs):
        sos, info = self.design("highpass", 1.0, fs)
        assert sos is not None, f"Failed at fs={fs}"

    @pytest.mark.parametrize("fs", [128, 256, 500, 512, 1000, 2048])
    def test_lowpass_various_fs(self, fs):
        sos, info = self.design("lowpass", 30.0, fs)
        assert sos is not None, f"Failed at fs={fs}"

    @pytest.mark.parametrize("fs", [128, 256, 512, 1000])
    def test_notch_50_various_fs(self, fs):
        sos, info = self.design("notch", 50.0, fs)
        if fs <= 110:  # 50 Hz too close to Nyquist at very low fs
            assert sos is None
        else:
            assert sos is not None, f"Failed at fs={fs}"

    def test_highpass_above_nyquist_returns_none(self):
        # HP at 100 Hz with fs=128 (Nyquist=64) is impossible
        sos, info = self.design("highpass", 100.0, 128)
        assert sos is None

    def test_lowpass_above_nyquist_returns_none(self):
        sos, info = self.design("lowpass", 100.0, 128)
        assert sos is None

    def test_notch_near_nyquist_returns_none(self):
        # 60 Hz notch at fs=110 (Nyquist=55): too close
        sos, info = self.design("notch", 60.0, 110)
        assert sos is None

    def test_unknown_type_raises(self):
        with pytest.raises(ValueError, match="Unknown filter type"):
            self.design("bandpass", 10.0, 512)


# ---------------------------------------------------------------------------
# Tests: SOS stability
# ---------------------------------------------------------------------------

class TestSOSStability:
    """Verify that SOS filters are numerically stable."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from ide4eeg.preprocessing.channels_and_signal import design_iir_filter
        self.design = design_iir_filter

    def test_highpass_01_at_5000hz_stable(self):
        """0.1 Hz highpass at 5000 Hz would be very high order in ba form."""
        sos, info = self.design("highpass", 0.1, 5000)
        assert sos is not None
        # Apply to random signal — should not produce NaN or Inf
        sig = np.random.randn(50000)
        filtered = ss.sosfiltfilt(sos, sig)
        assert np.all(np.isfinite(filtered))

    def test_lowpass_30_at_5000hz_stable(self):
        sos, info = self.design("lowpass", 30.0, 5000)
        assert sos is not None
        sig = np.random.randn(50000)
        filtered = ss.sosfiltfilt(sos, sig)
        assert np.all(np.isfinite(filtered))

    @pytest.mark.parametrize("fs", [128, 256, 512, 1000, 2048, 5000])
    def test_no_nan_after_filtering(self, fs):
        """Filter a random signal and check for NaN/Inf at various rates."""
        n = int(fs * 4)
        sig = np.random.randn(n)
        for ftype, freq in [("highpass", 0.5), ("lowpass", 30)]:
            sos, _ = self.design(ftype, freq, fs)
            if sos is not None:
                out = ss.sosfiltfilt(sos, sig)
                assert np.all(np.isfinite(out)), \
                    f"{ftype} {freq} Hz at fs={fs} produced NaN/Inf"


# ---------------------------------------------------------------------------
# Tests: frequency attenuation
# ---------------------------------------------------------------------------

class TestFrequencyAttenuation:
    """Verify that filters actually attenuate the right frequencies."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from ide4eeg.preprocessing.channels_and_signal import design_iir_filter
        self.design = design_iir_filter

    def test_highpass_removes_dc(self):
        """Highpass at 1 Hz should remove a 0.05 Hz drift."""
        fs = 512
        sig, t = make_test_signal(fs=fs)
        power_before = measure_power(sig, 0.05, fs)

        sos, _ = self.design("highpass", 1.0, fs)
        filtered = ss.sosfiltfilt(sos, sig)
        power_after = measure_power(filtered, 0.05, fs)

        # Drift should be attenuated by at least 20 dB
        assert power_after < power_before * 0.01

    def test_highpass_passes_alpha(self):
        """Highpass at 1 Hz should preserve 10 Hz alpha."""
        fs = 512
        sig, t = make_test_signal(fs=fs)
        power_before = measure_power(sig, 10, fs)

        sos, _ = self.design("highpass", 1.0, fs)
        filtered = ss.sosfiltfilt(sos, sig)
        power_after = measure_power(filtered, 10, fs)

        # Alpha should be preserved (within 10%)
        assert power_after > power_before * 0.9

    def test_lowpass_removes_high_freq(self):
        """Lowpass at 30 Hz should remove 50 Hz line noise."""
        fs = 512
        sig, t = make_test_signal(fs=fs)
        power_before = measure_power(sig, 50, fs)

        sos, _ = self.design("lowpass", 30.0, fs)
        filtered = ss.sosfiltfilt(sos, sig)
        power_after = measure_power(filtered, 50, fs)

        assert power_after < power_before * 0.01

    def test_lowpass_passes_alpha(self):
        """Lowpass at 30 Hz should preserve 10 Hz alpha."""
        fs = 512
        sig, t = make_test_signal(fs=fs)
        power_before = measure_power(sig, 10, fs)

        sos, _ = self.design("lowpass", 30.0, fs)
        filtered = ss.sosfiltfilt(sos, sig)
        power_after = measure_power(filtered, 10, fs)

        assert power_after > power_before * 0.9

    def test_notch_removes_line_noise(self):
        """Notch at 50 Hz should remove 50 Hz and preserve 10 Hz."""
        fs = 512
        sig, t = make_test_signal(fs=fs)
        p50_before = measure_power(sig, 50, fs)
        p10_before = measure_power(sig, 10, fs)

        sos, _ = self.design("notch", 50.0, fs)
        filtered = ss.sosfiltfilt(sos, sig)
        p50_after = measure_power(filtered, 50, fs)
        p10_after = measure_power(filtered, 10, fs)

        assert p50_after < p50_before * 0.01  # 50 Hz removed
        assert p10_after > p10_before * 0.9   # 10 Hz preserved

    @pytest.mark.parametrize("fs", [256, 512, 1000, 2048])
    def test_bandpass_at_various_rates(self, fs):
        """HP 0.5 + LP 30 should pass 10 Hz and reject 0.05 Hz and 100 Hz."""
        duration = 4.0
        t = np.arange(int(fs * duration)) / fs
        sig = (50 * np.sin(2 * np.pi * 0.05 * t)      # drift
               + 10 * np.sin(2 * np.pi * 10 * t)       # alpha
               + 5 * np.sin(2 * np.pi * min(100, fs/2 - 10) * t))  # high freq

        sos_hp, _ = self.design("highpass", 0.5, fs)
        sos_lp, _ = self.design("lowpass", 30.0, fs)

        filtered = sig.copy()
        if sos_hp is not None:
            filtered = ss.sosfiltfilt(sos_hp, filtered)
        if sos_lp is not None:
            filtered = ss.sosfiltfilt(sos_lp, filtered)

        p_alpha = measure_power(filtered, 10, fs)
        p_drift = measure_power(filtered, 0.05, fs)

        assert p_drift < p_alpha * 0.01, f"Drift not removed at fs={fs}"


# ---------------------------------------------------------------------------
# Tests: full filtering() function with MNE signal
# ---------------------------------------------------------------------------

class TestFilteringFunction:
    """Test the complete filtering() pipeline function."""

    def _make_raw(self, fs=512, duration=4.0):
        """Create an MNE Raw object with a test signal."""
        import mne
        sig, t = make_test_signal(fs=fs, duration=duration)
        # 2 EEG channels + 1 STIM
        data = np.vstack([sig, sig * 0.5,
                          np.zeros_like(sig)])
        info = mne.create_info(
            ["EEG1", "EEG2", "STIM"], sfreq=fs,
            ch_types=["eeg", "eeg", "stim"])
        return mne.io.RawArray(data, info, verbose=False)

    def test_iir_highpass_lowpass(self, tmp_path):
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        raw = self._make_raw(fs=512)
        cfg = {
            "filters": {
                "method": "iir",
                "highpass_freq": 1.0,
                "lowpass_freq": 30.0,
                "notch_freq": 0,
                "show_filt": False,
                "plot_filt": False,
            }
        }
        out = _filter_signal(raw, cfg, str(tmp_path))
        assert out is not None
        assert out.info["highpass"] == 1.0
        assert out.info["lowpass"] == 30.0
        # Check 50 Hz is attenuated (lowpass at 30)
        data = out.get_data(picks=["eeg"])[0]
        p50 = measure_power(data, 50, 512)
        p10 = measure_power(data, 10, 512)
        assert p50 < p10 * 0.01

    def test_fir_highpass_lowpass(self, tmp_path):
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        raw = self._make_raw(fs=512)
        cfg = {
            "filters": {
                "method": "fir",
                "highpass_freq": 1.0,
                "lowpass_freq": 30.0,
                "notch_freq": 0,
                "show_filt": False,
                "plot_filt": False,
            }
        }
        out = _filter_signal(raw, cfg, str(tmp_path))
        assert out is not None
        # MNE's filter() sets info["highpass"]/["lowpass"] automatically
        assert out.info["highpass"] == 1.0
        assert out.info["lowpass"] == 30.0
        data = out.get_data(picks=["eeg"])[0]
        p50 = measure_power(data, 50, 512)
        p10 = measure_power(data, 10, 512)
        assert p50 < p10 * 0.01

    def test_iir_at_different_fs(self, tmp_path):
        """IIR filtering should work at non-512 sampling rates."""
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        for fs in [256, 1000]:
            raw = self._make_raw(fs=fs)
            cfg = {
                "filters": {
                    "method": "iir",
                    "highpass_freq": 0.5,
                    "lowpass_freq": 30.0,
                    "notch_freq": 50,
                    "show_filt": False,
                    "plot_filt": False,
                }
            }
            out = _filter_signal(raw, cfg, str(tmp_path))
            assert out is not None, f"Failed at fs={fs}"
            data = out.get_data(picks=["eeg"])[0]
            assert np.all(np.isfinite(data)), f"NaN at fs={fs}"

    def test_no_filters(self, tmp_path):
        """All cutoffs 0 should return signal unchanged."""
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        raw = self._make_raw()
        cfg = {
            "filters": {
                "method": "iir",
                "highpass_freq": 0,
                "lowpass_freq": 0,
                "notch_freq": 0,
                "show_filt": False,
                "plot_filt": False,
            }
        }
        out = _filter_signal(raw, cfg, str(tmp_path))
        orig = raw.get_data(picks=["eeg"])
        filt = out.get_data(picks=["eeg"])
        np.testing.assert_array_almost_equal(orig, filt)

    def test_stim_channel_preserved(self, tmp_path):
        """STIM channel should pass through as zeros (not filtered)."""
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        raw = self._make_raw()

        cfg = {
            "filters": {
                "method": "iir",
                "highpass_freq": 1.0,
                "lowpass_freq": 30.0,
                "notch_freq": 50,
                "show_filt": False,
                "plot_filt": False,
            }
        }
        out = _filter_signal(raw, cfg, str(tmp_path))
        # STIM should be all zeros (not corrupted by filtering)
        out_stim = out.get_data(picks=["stim"])
        assert np.allclose(out_stim, 0), "STIM channel was modified"
        # EEG should be modified (not all zeros)
        out_eeg = out.get_data(picks=["eeg"])
        assert not np.allclose(out_eeg, 0), "EEG was not filtered"


# ---------------------------------------------------------------------------
# Tests: mgr_filter (artifact detection)
# ---------------------------------------------------------------------------

class TestMgrFilter:
    """Test the artifact detection filter function."""

    def test_mgr_filter_sos(self):
        import mne
        from ide4eeg.preprocessing.artifacts import mgr_filter

        fs = 512
        n = int(fs * 2)
        data = np.random.randn(2, n) * 1e-5  # 2 channels
        info = mne.create_info(["C3", "C4"], sfreq=fs, ch_types="eeg")

        # Highpass at 1 Hz
        filtered = mgr_filter(data.copy(), info, 1.0, 0.5, 3, 6.97, "butter")
        assert np.all(np.isfinite(filtered))

    def test_mgr_filter_notch(self):
        import mne
        from ide4eeg.preprocessing.artifacts import mgr_filter

        fs = 512
        n = int(fs * 2)
        t = np.arange(n) / fs
        # Signal with 50 Hz line noise
        data = np.vstack([
            10e-6 * np.sin(2 * np.pi * 10 * t) + 5e-6 * np.sin(2 * np.pi * 50 * t),
            10e-6 * np.sin(2 * np.pi * 10 * t) + 5e-6 * np.sin(2 * np.pi * 50 * t),
        ])
        info = mne.create_info(["C3", "C4"], sfreq=fs, ch_types="eeg")

        filtered = mgr_filter(data.copy(), info,
                              [47.5, 52.5], [49.9, 50.1], 3, 25, "cheby2")
        # 50 Hz should be attenuated
        p50_before = measure_power(data[0], 50, fs)
        p50_after = measure_power(filtered[0], 50, fs)
        assert p50_after < p50_before * 0.1


# ---------------------------------------------------------------------------
# Tests: legacy config conversion
# ---------------------------------------------------------------------------

