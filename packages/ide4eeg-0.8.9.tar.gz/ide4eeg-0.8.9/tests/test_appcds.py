"""Tests for ide4eeg._appcds.

Verifies the AppCDS flag-builder produces the right flags under each
state (no archive → ArchiveClassesAtExit, fresh archive → SharedArchiveFile,
stale archive → drop + regenerate, missing jar / read-only dir → []).

The flags are passed verbatim to the JVM, so a regression here either
loses cold-start speed or breaks the launch outright.
"""

import hashlib
import os
import time

import pytest

from ide4eeg import _appcds
from ide4eeg._appcds import appcds_flags


@pytest.fixture(autouse=True)
def _stub_java_major(monkeypatch):
    """Pretend the JVM is JDK 21 unless a test overrides it.

    Without this, ``appcds_flags`` would probe the real ``java`` on
    PATH and skip AppCDS on JDK < 13 (or when ``java`` is missing
    entirely, e.g. in CI), making the existing tests flaky.
    """
    monkeypatch.setattr(_appcds, "_java_major", lambda java_path: 21)


@pytest.fixture
def jar(tmp_path):
    p = tmp_path / "demo.jar"
    p.write_bytes(b"")
    return str(p)


def _sha8(java):
    """Same jvm-id hash the helper uses, for cross-checking filenames."""
    import shutil as _sh
    resolved = _sh.which(java) or java
    return hashlib.sha1(resolved.encode("utf-8")).hexdigest()[:8]


def test_returns_archive_at_exit_when_no_archive_exists(jar):
    flags = appcds_flags(jar)
    assert len(flags) == 1
    assert flags[0].startswith("-XX:ArchiveClassesAtExit=")
    archive_path = flags[0].split("=", 1)[1]
    assert os.path.dirname(archive_path) == os.path.dirname(jar)
    assert archive_path.endswith(".jsa")
    assert _sha8("java") in os.path.basename(archive_path)


def test_returns_shared_archive_when_archive_newer_than_jar(jar, tmp_path):
    flags1 = appcds_flags(jar)
    archive_path = flags1[0].split("=", 1)[1]
    # Touch the archive, make it newer than the jar.
    open(archive_path, "wb").close()
    os.utime(jar, (time.time() - 60, time.time() - 60))

    flags2 = appcds_flags(jar)
    assert flags2 == [
        f"-XX:SharedArchiveFile={archive_path}",
        "-Xshare:auto",
    ]


def test_drops_stale_archive_and_regenerates(jar):
    flags1 = appcds_flags(jar)
    archive_path = flags1[0].split("=", 1)[1]
    # Create an archive *older* than the jar — simulates a Svarog
    # rebuild that needs the archive recomputed.
    open(archive_path, "wb").close()
    os.utime(archive_path, (time.time() - 3600, time.time() - 3600))
    os.utime(jar, (time.time(), time.time()))

    flags2 = appcds_flags(jar)
    assert flags2 == [f"-XX:ArchiveClassesAtExit={archive_path}"]
    # Stale archive was deleted so the next clean exit can write fresh.
    assert not os.path.exists(archive_path)


def test_jvm_id_changes_archive_filename(jar):
    """Different java paths land on different archive filenames so a
    JDK upgrade with a fresh install path doesn't reuse a stale .jsa."""
    f_default = appcds_flags(jar, java_path="java")
    # Pass a fully-qualified, unmistakably-different path. The helper
    # treats it as a literal when shutil.which fails to resolve it.
    f_other = appcds_flags(
        jar, java_path="/nonexistent/jdks/temurin-99/bin/java")
    a1 = f_default[0].split("=", 1)[1]
    a2 = f_other[0].split("=", 1)[1]
    assert a1 != a2
    assert os.path.dirname(a1) == os.path.dirname(a2)


def test_returns_empty_when_jar_missing(tmp_path):
    assert appcds_flags(str(tmp_path / "does-not-exist.jar")) == []


def test_returns_empty_on_jdk_too_old(jar, monkeypatch):
    """JDK 11/12 reject ``-XX:ArchiveClassesAtExit`` with
    "Unrecognized VM option" and abort before main, so we must not
    emit it.  JEP 350 (dynamic CDS) shipped in JDK 13."""
    monkeypatch.setattr(_appcds, "_java_major", lambda p: 11)
    assert appcds_flags(jar) == []


def test_returns_empty_when_java_version_unprobeable(jar, monkeypatch):
    """``java`` missing or unparseable → skip AppCDS, never block the launch."""
    monkeypatch.setattr(_appcds, "_java_major", lambda p: None)
    assert appcds_flags(jar) == []


def test_returns_archive_at_exit_on_jdk_13(jar, monkeypatch):
    """JDK 13 is the lower bound — emit the flag."""
    monkeypatch.setattr(_appcds, "_java_major", lambda p: 13)
    flags = appcds_flags(jar)
    assert len(flags) == 1
    assert flags[0].startswith("-XX:ArchiveClassesAtExit=")


def test_fresh_archive_skips_version_probe(jar, monkeypatch):
    """If a fresh ``.jsa`` already exists, the JVM that wrote it must
    have been JDK 13+ (couldn't have written it otherwise), so reuse
    skips the version probe and works even if the probe would fail."""
    # First call writes a fresh archive (JDK 21 stub).
    flags1 = appcds_flags(jar)
    archive_path = flags1[0].split("=", 1)[1]
    open(archive_path, "wb").close()
    os.utime(jar, (time.time() - 60, time.time() - 60))

    # Now break the probe entirely — reuse path must not call it.
    def _explode(p):
        raise AssertionError("version probe must not run on reuse path")
    monkeypatch.setattr(_appcds, "_java_major", _explode)

    flags2 = appcds_flags(jar)
    assert flags2 == [
        f"-XX:SharedArchiveFile={archive_path}",
        "-Xshare:auto",
    ]


def test_returns_empty_when_jar_dir_unwritable(tmp_path):
    # Make a read-only dir, drop a jar in it, then strip write perms.
    ro = tmp_path / "ro"
    ro.mkdir()
    jar = ro / "demo.jar"
    jar.write_bytes(b"")
    os.chmod(ro, 0o555)
    try:
        # On macOS / Linux non-root, this should hit the W_OK branch.
        if os.access(str(ro), os.W_OK):
            pytest.skip("running as root or filesystem ignores chmod")
        assert appcds_flags(str(jar)) == []
    finally:
        os.chmod(ro, 0o755)
