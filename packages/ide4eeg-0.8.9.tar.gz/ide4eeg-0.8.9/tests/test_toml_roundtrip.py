"""Round-trip tests for `_collect_config` ↔ `_populate_vars` in the
Qt GUI — guards against the regression class fixed in May 2026 where
several keys were collected but never restored (mp/conn/dip channel
panels, dipole picked atoms, eeg_profiles book channel, prof atom
table empty-clear) and the dead `dip_maxit` widget reference.

These tests build the real `IDE4EEG_Qt` window offscreen.  They are
deliberately narrow: each test pokes at one widget, runs the round
trip, and asserts the value survived.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# Shared offscreen-Qt fixture (matches the one in test_gui_qt_config.py).
# Module-scoped so the heavy GUI build runs once.
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def qt_gui():
    try:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        _app = QApplication.instance() or QApplication(sys.argv)
        from ide4eeg.gui import IDE4EEG_Qt
        gui = IDE4EEG_Qt()
        for i in range(gui._tabs.count()):
            gui._tabs.setCurrentIndex(i)
        return gui
    except Exception as e:
        pytest.skip(f"Cannot create Qt GUI: {e}")


# ---------------------------------------------------------------------------
# 1. The dead `dip_maxit` widget reference was deleted from
#    _collect_config_analysis; max_iterations now flows through the
#    AtomFilterTable.  Lock that path: a non-zero value in cfg must
#    survive populate → collect.
# ---------------------------------------------------------------------------

def test_dip_max_iterations_roundtrip(qt_gui):
    cfg = qt_gui._collect_config()
    cfg.setdefault("dipole_fitting", {})["max_iterations"] = 42
    qt_gui._populate_vars(cfg)
    out = qt_gui._collect_config()
    assert out["dipole_fitting"]["max_iterations"] == 42, (
        "dip_maxit dead widget regressed: max_iterations lost on "
        "round-trip — atom table column should be the only source")


def test_no_dead_dip_maxit_widget(qt_gui):
    """Belt-and-braces: the dip_maxit key must NOT exist as a widget.
    If a future contributor re-adds it, the collect path will start
    fighting the atom table again."""
    assert "dip_maxit" not in qt_gui._an, (
        "dip_maxit widget was re-introduced; this duplicates the "
        "atom-table column and silently overwrites it")


# ---------------------------------------------------------------------------
# 2. Channel-panel restore (mp_channels, conn_channels). Drive the
#    extracted helper directly — populating the panels manually
#    sidesteps the heavy _on_signal_info_ready path.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("panel_key, section", [
    ("mp_channels", "matching_pursuit"),
    ("conn_channels", "connectivity"),
])
def test_channel_panel_restore_from_config_data(
        qt_gui, panel_key, section):
    panel = qt_gui._pp.get(panel_key) or qt_gui._an.get(panel_key)
    assert panel is not None, f"{panel_key} not built"
    names = ["Cz", "C3", "C4", "Oz"]
    panel.populate(names, ch_types={n: "eeg" for n in names})
    qt_gui.config_data.setdefault(section, {})["channels"] = ["C3", "Oz"]
    qt_gui._restore_channel_panel_selections()
    got = set(panel.selected_items())
    assert got == {"C3", "Oz"}, (
        f"{panel_key} restore did not match cfg: got {got}, "
        f"expected {{'C3', 'Oz'}}")


def test_mp_channels_default_eeg_when_no_cfg(qt_gui):
    """When cfg has no explicit channels list, mp_channels falls back
    to the legacy 'EEG only' default — locks the elif branch."""
    panel = qt_gui._pp.get("mp_channels")
    assert panel is not None
    names = ["Cz", "EOG1", "EMG1"]
    types = {"Cz": "eeg", "EOG1": "eog", "EMG1": "emg"}
    panel.populate(names, ch_types=types)
    qt_gui.config_data.setdefault("matching_pursuit", {})["channels"] = []
    qt_gui._restore_channel_panel_selections()
    assert set(panel.selected_items()) == {"Cz"}


# ---------------------------------------------------------------------------
# 3. Dipole picked atoms — the list and the readout label.
# ---------------------------------------------------------------------------

def test_dipole_picked_atoms_roundtrip(qt_gui):
    cfg = qt_gui._collect_config()
    cfg.setdefault("dipole_fitting", {})["_picked_atoms"] = [
        {"channel": "Cz", "id": 1},
        {"channel": "C3", "id": 2},
    ]
    qt_gui._populate_vars(cfg)
    assert len(qt_gui._an["dip_picked_atoms"]) == 2
    label = qt_gui._an.get("dip_picked_label")
    assert label is not None
    assert "2 atom(s) selected" in label.text()


def test_dipole_picked_atoms_empty_restores_default_label(qt_gui):
    cfg = qt_gui._collect_config()
    cfg.setdefault("dipole_fitting", {})["_picked_atoms"] = []
    qt_gui._populate_vars(cfg)
    label = qt_gui._an.get("dip_picked_label")
    assert label is not None
    assert "no manual selection" in label.text()


# ---------------------------------------------------------------------------
# 4. step_order supersedes prepare_* for preprocessing groups.
#    Behaviour lock: if a future cleanup decides to remove the
#    prepare_* writes entirely, this test should be updated rather
#    than silently re-shape the load semantics.
# ---------------------------------------------------------------------------

def test_step_order_supersedes_prepare_flags(qt_gui):
    cfg = qt_gui._collect_config()
    cfg["prepare_ica"] = True
    cfg["prepare_eeg_artifacts"] = True
    cfg.setdefault("preprocessing", {})["step_order"] = []
    qt_gui._populate_vars(cfg)
    pp = qt_gui._pp
    ica = pp.get("_ica_grp")
    art = pp.get("_art_grp")
    assert ica is not None and art is not None
    assert not ica.isChecked(), (
        "step_order=[] should override prepare_ica=True")
    assert not art.isChecked(), (
        "step_order=[] should override prepare_eeg_artifacts=True")


# ---------------------------------------------------------------------------
# 5. prof_atom_table populates even when structures = [] so that
#    saving an empty list actually clears the table on next load.
# ---------------------------------------------------------------------------

def test_prof_atom_table_clears_when_empty(qt_gui):
    tbl = qt_gui._an.get("prof_atom_table")
    assert tbl is not None
    cfg = qt_gui._collect_config()
    cfg.setdefault("eeg_profiles", {})["structures"] = [
        {"name": "alpha", "freq_min": 8, "freq_max": 12},
        {"name": "beta", "freq_min": 13, "freq_max": 30},
    ]
    qt_gui._populate_vars(cfg)
    assert tbl._table.rowCount() == 2
    cfg["eeg_profiles"]["structures"] = []
    qt_gui._populate_vars(cfg)
    assert tbl._table.rowCount() == 0, (
        "Empty structures list should clear the table; stale rows "
        "would otherwise be picked up by the next collect")


# ---------------------------------------------------------------------------
# 6. EEG Profiles book channel — set_channel pre-population and
#    deferred apply after _on_book_changed populates the combo.
# ---------------------------------------------------------------------------

def test_book_panel_set_channel_immediate(qt_gui):
    bp = qt_gui._an.get("prof_book_panel")
    assert bp is not None
    bp._ch_combo.clear()
    bp._ch_combo.addItems(["Cz", "C3", "C4"])
    bp.set_channel("C3")
    assert bp.selected_channel() == "C3"


def test_book_panel_set_channel_pending(qt_gui):
    """When the combo is empty (book not loaded yet), set_channel
    stashes the request and applies it after items are added."""
    bp = qt_gui._an.get("prof_book_panel")
    assert bp is not None
    bp._ch_combo.clear()
    bp.set_channel("Cz")
    assert bp.selected_channel() == "", (
        "Combo was empty, nothing to select yet")
    bp._ch_combo.addItems(["C3", "Cz", "C4"])
    bp._apply_pending_channel()
    assert bp.selected_channel() == "Cz"


# ---------------------------------------------------------------------------
# 7. Filter panels — full rebuild when cfg has a different number of
#    blocks than the GUI currently shows.  This was the May-2026 bug
#    that motivated the audit; lock the fix.
# ---------------------------------------------------------------------------

def test_correlation_enabled_flag_round_trip(qt_gui):
    """The Correlation checkbox round-trips through an explicit
    ``enable_correlation`` boolean.  Locks the 2026-05-13 schema
    migration that replaced the legacy "if correlation_window in
    cfg" presence-gate.  Bug report: stale correlation_window
    from a previously loaded TOML silently re-enabled detection
    even when the checkbox was off; the boolean migration
    eliminates that leak structurally."""
    qt_gui._pp["corr_window"].setText("0.6, 0.95")
    qt_gui._pp["corr_thr"].setText("0.9")
    qt_gui._pp["enable_corr"].setChecked(False)
    cfg_off = qt_gui._collect_config()
    cc = cfg_off["choosing_channels"]
    assert cc["enable_correlation"] is False
    # Window/threshold params survive in the TOML for save/load
    # symmetry — the boolean is the sole gate now.
    assert cc["correlation_window"] == [0.6, 0.95]
    assert cc["correlation_badch_threshold"] == 0.9

    qt_gui._pp["enable_corr"].setChecked(True)
    cfg_on = qt_gui._collect_config()
    assert cfg_on["choosing_channels"]["enable_correlation"] is True


def test_correlation_legacy_toml_auto_promotes(qt_gui):
    """A pre-migration TOML with ``correlation_window`` but no
    ``enable_correlation`` flag must auto-promote to enabled
    (preserving the legacy "presence == enabled" semantics).
    Locks the shim in input/input.py::check_and_prepare_config."""
    from ide4eeg.input.input import check_and_prepare_config
    legacy = {
        "input_path": "/tmp/test.fif",
        "choosing_channels": {
            "correlation_window": [0.7, 0.95],
            # NB: no enable_correlation key — legacy schema
        },
    }
    promoted = check_and_prepare_config(legacy)
    assert promoted["choosing_channels"]["enable_correlation"] is True


def test_filter_panels_rebuild_to_match_cfg(qt_gui):
    cfg = qt_gui._collect_config()
    cfg["filters"] = {
        "abc12345": {"highpass_freq": 1.0, "lowpass_freq": 40.0,
                     "notch_freq": 50, "method": "iir"},
        "def67890": {"highpass_freq": 0.5, "lowpass_freq": 30.0,
                     "notch_freq": 0, "method": "fir"},
        "ghi24680": {"highpass_freq": 8.0, "lowpass_freq": 12.0,
                     "notch_freq": 50, "method": "iir"},
    }
    qt_gui._populate_vars(cfg)
    assert len(qt_gui._filter_widgets) == 3
    cfg["filters"] = {
        "single001": {"highpass_freq": 2.0, "lowpass_freq": 20.0,
                      "notch_freq": 50, "method": "iir"},
    }
    qt_gui._populate_vars(cfg)
    assert len(qt_gui._filter_widgets) == 1
    fid, _ = qt_gui._filter_widgets[0]
    assert float(qt_gui._pp[f"hp_{fid}"].text()) == 2.0
    assert float(qt_gui._pp[f"lp_{fid}"].text()) == 20.0
