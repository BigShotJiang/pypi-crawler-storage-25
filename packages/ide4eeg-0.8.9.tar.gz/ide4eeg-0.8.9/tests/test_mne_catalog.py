"""Tests for the MNE&+ catalog (`ide4eeg/analysis/mne_catalog.py`)
and its GUI form-builder (gui.py)."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# Schema integrity (pure data, no Qt)
# ---------------------------------------------------------------------------


class TestCatalogSchema:

    def test_advanced_flag_is_optional_and_bool(self):
        """Every catalog param either omits 'advanced' (defaults to
        simple) or sets it to a real bool — no None / int / string."""
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG
        for entry in MNE_CATALOG:
            for p in entry.get("params", []):
                if "advanced" in p:
                    assert isinstance(p["advanced"], bool), (
                        f"{entry['id']}.{p['key']}: advanced must be bool, "
                        f"got {type(p['advanced']).__name__}")

    def test_legacy_psd_bands_topomap_removed(self):
        """psd_bands_topomap was folded into psd_topomap on 2026-05-01;
        the standalone entry must no longer exist."""
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG
        ids = {e["id"] for e in MNE_CATALOG}
        assert "psd_bands_topomap" not in ids


# ---------------------------------------------------------------------------
# Catalog helpers (pure data, no Qt)
# ---------------------------------------------------------------------------


class TestParseBands:

    def test_empty_string_returns_none(self):
        from ide4eeg.analysis.mne_catalog import _parse_bands
        assert _parse_bands("") is None
        assert _parse_bands("   ") is None
        assert _parse_bands(None) is None

    def test_default_five_bands(self):
        from ide4eeg.analysis.mne_catalog import _parse_bands
        out = _parse_bands("1-4,4-8,8-12,12-30,30-50")
        assert out == {
            "delta": (1.0, 4.0), "theta": (4.0, 8.0),
            "alpha": (8.0, 12.0), "beta": (12.0, 30.0),
            "gamma": (30.0, 50.0),
        }

    def test_more_than_five_bands_get_band6_etc(self):
        from ide4eeg.analysis.mne_catalog import _parse_bands
        out = _parse_bands("1-4,4-8,8-12,12-30,30-50,50-80")
        assert "band6" in out
        assert out["band6"] == (50.0, 80.0)

    def test_malformed_returns_none(self):
        from ide4eeg.analysis.mne_catalog import _parse_bands
        assert _parse_bands("not valid") is None
        assert _parse_bands("1-4,bogus") is None


class TestOptionalKwargs:

    def test_filters_to_allowed_keys(self):
        from ide4eeg.analysis.mne_catalog import _optional_kwargs
        out = _optional_kwargs(
            {"bandwidth": 4.0, "ignored": 99.0}, ["bandwidth"])
        assert out == {"bandwidth": 4.0}

    def test_drops_zero_sentinel(self):
        from ide4eeg.analysis.mne_catalog import _optional_kwargs
        out = _optional_kwargs({"bandwidth": 0}, ["bandwidth"])
        assert out == {}

    def test_drops_unparsable(self):
        from ide4eeg.analysis.mne_catalog import _optional_kwargs
        out = _optional_kwargs({"bandwidth": "abc"}, ["bandwidth"])
        assert out == {}

    def test_missing_key_omitted(self):
        from ide4eeg.analysis.mne_catalog import _optional_kwargs
        assert _optional_kwargs({}, ["bandwidth"]) == {}


# ---------------------------------------------------------------------------
# Legacy config migration (pure data, no Qt)
# ---------------------------------------------------------------------------


class TestPsdBandsTopomapMigration:

    def test_legacy_id_rewritten_to_psd_topomap(self):
        from ide4eeg.gui import IDE4EEG_Qt
        cfg = {
            "mne_catalog": ["psd_bands_topomap"],
            "mne_params": {"psd_bands_topomap": {"bands": "1-4,4-8"}},
        }
        IDE4EEG_Qt._migrate_legacy_psd_bands_topomap(cfg)
        assert cfg["mne_catalog"] == ["psd_topomap"]
        assert cfg["mne_params"] == {
            "psd_topomap": {"bands": "1-4,4-8"}}

    def test_dedup_when_psd_topomap_already_present(self):
        from ide4eeg.gui import IDE4EEG_Qt
        cfg = {
            "mne_catalog": ["psd_topomap", "psd_bands_topomap"],
            "mne_params": {"psd_bands_topomap": {"bands": "8-12"}},
        }
        IDE4EEG_Qt._migrate_legacy_psd_bands_topomap(cfg)
        assert cfg["mne_catalog"] == ["psd_topomap"]
        # legacy bands win — user explicitly customized them.
        assert cfg["mne_params"]["psd_topomap"]["bands"] == "8-12"

    def test_no_legacy_id_is_noop(self):
        from ide4eeg.gui import IDE4EEG_Qt
        cfg = {
            "mne_catalog": ["psd_topomap"],
            "mne_params": {"psd_topomap": {"bands": ""}},
        }
        IDE4EEG_Qt._migrate_legacy_psd_bands_topomap(cfg)
        assert cfg["mne_catalog"] == ["psd_topomap"]
        assert cfg["mne_params"] == {"psd_topomap": {"bands": ""}}

    def test_empty_cfg_is_noop(self):
        from ide4eeg.gui import IDE4EEG_Qt
        cfg = {}
        IDE4EEG_Qt._migrate_legacy_psd_bands_topomap(cfg)
        assert cfg == {"mne_params": {}}


# ---------------------------------------------------------------------------
# Advanced-disclosure persistence (Qt-aware, offscreen)
# ---------------------------------------------------------------------------


_qt_gui = None


def _get_qt_gui():
    """Lazily build and cache a Qt GUI instance offscreen."""
    global _qt_gui
    if _qt_gui is not None:
        return _qt_gui
    try:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication(sys.argv)  # noqa: F841
        from ide4eeg.gui import IDE4EEG_Qt
        _qt_gui = IDE4EEG_Qt()
        for i in range(_qt_gui._tabs.count()):
            _qt_gui._tabs.setCurrentIndex(i)
        return _qt_gui
    except Exception as e:
        pytest.skip(f"Cannot create Qt GUI: {e}")


@pytest.fixture(scope="module")
def qt_gui():
    return _get_qt_gui()


class TestAdvancedDisclosurePersistence:

    def test_collector_returns_dict(self, qt_gui):
        """Phase 1 ships zero entries with advanced=True params, so the
        groupbox dict is empty and the collector returns {}."""
        result = qt_gui._collect_mne_advanced_open()
        assert isinstance(result, dict)
        # Every value must be a real bool.
        for k, v in result.items():
            assert isinstance(v, bool)

    def test_round_trip_through_collect_and_populate(self, qt_gui):
        """Toggling a synthetic Advanced groupbox open, collecting, then
        re-populating, restores the open state.  Uses a manually
        injected QGroupBox so the test does not depend on any catalog
        entry having advanced params yet."""
        from PySide6.QtWidgets import QGroupBox
        fake_id = "__test_round_trip__"
        box = QGroupBox("Advanced")
        box.setCheckable(True)
        box.setChecked(False)
        qt_gui._mne_advanced_groupboxes[fake_id] = box

        try:
            # Open the disclosure.
            box.setChecked(True)
            collected = qt_gui._collect_mne_advanced_open()
            assert collected.get(fake_id) is True

            # Simulate save+reload by closing the box and asking
            # _populate_vars to restore from a cfg dict that says open.
            box.setChecked(False)
            qt_gui._populate_vars({"mne_advanced_open": {fake_id: True}})
            assert box.isChecked() is True

            # Likewise, a cfg that omits the entry should leave it
            # closed (the default).
            box.setChecked(True)
            qt_gui._populate_vars({"mne_advanced_open": {}})
            assert box.isChecked() is False
        finally:
            qt_gui._mne_advanced_groupboxes.pop(fake_id, None)

    def test_round_trip_with_collapsible_step(self, qt_gui):
        """Same round-trip as test_round_trip_through_collect_and_populate
        but with the production widget — a CollapsibleStep — to lock in
        the disclosure-open helpers (`_is_disclosure_open` /
        `_set_disclosure_open`)."""
        from ide4eeg.gui import CollapsibleStep
        fake_id = "__test_collapsible_round_trip__"
        step = CollapsibleStep(
            "Advanced parameters", checkable=False,
            has_run=False, has_help=False)
        qt_gui._mne_advanced_groupboxes[fake_id] = step
        try:
            step.expand()
            collected = qt_gui._collect_mne_advanced_open()
            assert collected.get(fake_id) is True

            step.collapse()
            qt_gui._populate_vars(
                {"mne_advanced_open": {fake_id: True}})
            assert step._collapsed is False

            step.expand()
            qt_gui._populate_vars({"mne_advanced_open": {}})
            assert step._collapsed is True
        finally:
            qt_gui._mne_advanced_groupboxes.pop(fake_id, None)

    def test_missing_cfg_key_defaults_to_collapsed(self, qt_gui):
        """A cfg dict with no mne_advanced_open key must not crash
        _populate_vars and must leave existing groupboxes closed."""
        from PySide6.QtWidgets import QGroupBox
        fake_id = "__test_missing_key__"
        box = QGroupBox("Advanced")
        box.setCheckable(True)
        box.setChecked(True)
        qt_gui._mne_advanced_groupboxes[fake_id] = box
        try:
            qt_gui._populate_vars({})
            assert box.isChecked() is False
        finally:
            qt_gui._mne_advanced_groupboxes.pop(fake_id, None)


# ---------------------------------------------------------------------------
# Widget type dispatch — bool / choice / default (Qt-aware, offscreen)
# ---------------------------------------------------------------------------


class TestWidgetTypeDispatch:
    """`_build_mne_param_row` switches on `p["type"]`; `_collect_mne_params`
    and `_populate_vars` mirror it."""

    def test_bool_param_renders_qcheckbox(self, qt_gui):
        from PySide6.QtWidgets import QCheckBox
        row = qt_gui._build_mne_param_row(
            [{"key": "k", "label": "Lbl", "type": "bool", "default": True}],
            (widgets := {}))
        assert isinstance(widgets["k"], QCheckBox)
        assert widgets["k"].isChecked() is True

    def test_choice_param_renders_qcombobox(self, qt_gui):
        from PySide6.QtWidgets import QComboBox
        row = qt_gui._build_mne_param_row(
            [{"key": "k", "label": "Lbl", "type": "choice",
              "choices": ["a", "b", "c"], "default": "b"}],
            (widgets := {}))
        assert isinstance(widgets["k"], QComboBox)
        assert widgets["k"].currentText() == "b"

    def test_unknown_type_falls_back_to_qlineedit(self, qt_gui):
        from PySide6.QtWidgets import QLineEdit
        row = qt_gui._build_mne_param_row(
            [{"key": "k", "label": "Lbl", "type": "float",
              "default": 0.5}],
            (widgets := {}))
        assert isinstance(widgets["k"], QLineEdit)
        assert widgets["k"].text() == "0.5"

    def test_collect_returns_bool_for_qcheckbox(self, qt_gui):
        """Inject a fake checked-entry, force-check its widgets, and
        verify _collect_mne_params produces typed values."""
        from PySide6.QtWidgets import QCheckBox, QComboBox, QLineEdit
        fake_id = "__test_collect_types__"
        cb_box = QCheckBox("entry"); cb_box.setChecked(True)
        qt_gui._mne_checks[fake_id] = cb_box
        flag = QCheckBox("flag"); flag.setChecked(True)
        choice = QComboBox(); choice.addItems(["a", "b"])
        choice.setCurrentText("a")
        line = QLineEdit("3.14")
        qt_gui._mne_params[fake_id] = {
            "flag": flag, "choice": choice, "num": line}
        try:
            collected = qt_gui._collect_mne_params()
            assert collected[fake_id] == {
                "flag": True, "choice": "a", "num": 3.14}
        finally:
            qt_gui._mne_checks.pop(fake_id, None)
            qt_gui._mne_params.pop(fake_id, None)

    def test_populate_writes_typed_values(self, qt_gui):
        """_populate_vars must restore bool / choice / numeric values
        into their respective widget types."""
        from PySide6.QtWidgets import QCheckBox, QComboBox, QLineEdit
        fake_id = "__test_populate_types__"
        cb_box = QCheckBox("entry"); cb_box.setChecked(True)
        qt_gui._mne_checks[fake_id] = cb_box
        flag = QCheckBox("flag"); flag.setChecked(False)
        choice = QComboBox(); choice.addItems(["a", "b", "c"])
        choice.setCurrentText("a")
        line = QLineEdit("0")
        qt_gui._mne_params[fake_id] = {
            "flag": flag, "choice": choice, "num": line}
        try:
            qt_gui._populate_vars({
                "mne_catalog": [fake_id],
                "mne_params": {fake_id: {
                    "flag": True, "choice": "c", "num": "2.5"}},
            })
            assert flag.isChecked() is True
            assert choice.currentText() == "c"
            assert line.text() == "2.5"
        finally:
            qt_gui._mne_checks.pop(fake_id, None)
            qt_gui._mne_params.pop(fake_id, None)


# ---------------------------------------------------------------------------
# New entries (Phase 3) and CSV export
# ---------------------------------------------------------------------------


class TestPhase3Entries:

    def test_psd_welch_and_topo_are_in_catalog(self):
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG
        ids = {e["id"] for e in MNE_CATALOG}
        assert "psd_welch" in ids
        assert "psd_topo" in ids

    def test_save_csv_param_present_on_all_psd_entries(self):
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG
        psd_entries = {"psd_topomap", "psd_multitaper",
                       "psd_welch", "psd_topo"}
        for entry in MNE_CATALOG:
            if entry["id"] in psd_entries:
                keys = {p["key"] for p in entry.get("params", [])}
                assert "save_csv" in keys, (
                    f"{entry['id']} missing save_csv param")

    def test_dispatch_routes_psd_welch_and_topo(self):
        """Dispatch table knows about the new entries."""
        from ide4eeg.analysis.mne_catalog import _DISPATCH
        assert "psd_welch" in _DISPATCH
        assert "psd_topo" in _DISPATCH


class TestSpectrumPlotKwargs:

    def test_show_false_always(self):
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        out = _spectrum_plot_kwargs_from_params({})
        assert out == {"show": False}

    def test_scale_default_is_mne_default(self):
        """No scale param → empty (MNE default kicks in: dB=True)."""
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        out = _spectrum_plot_kwargs_from_params({"scale": "dB"})
        assert "dB" not in out and "amplitude" not in out

    def test_scale_power_means_db_false(self):
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        out = _spectrum_plot_kwargs_from_params({"scale": "power"})
        assert out["dB"] is False
        assert "amplitude" not in out

    def test_scale_amplitude_sets_both_kwargs(self):
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        out = _spectrum_plot_kwargs_from_params({"scale": "amplitude"})
        assert out["dB"] is False
        assert out["amplitude"] is True

    def test_ci_off_becomes_none(self):
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        out = _spectrum_plot_kwargs_from_params({"ci": "off"})
        assert out["ci"] is None

    def test_ci_known_choices_pass_through(self):
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        for v in ("sd", "range"):
            out = _spectrum_plot_kwargs_from_params({"ci": v})
            assert out["ci"] == v

    def test_ci_unknown_value_dropped(self):
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        out = _spectrum_plot_kwargs_from_params({"ci": "garbage"})
        assert "ci" not in out

    def test_average_only_when_truthy(self):
        from ide4eeg.analysis.mne_catalog import \
            _spectrum_plot_kwargs_from_params
        assert "average" not in _spectrum_plot_kwargs_from_params(
            {"average": False})
        assert _spectrum_plot_kwargs_from_params(
            {"average": True})["average"] is True


class TestScaleKwargsTopoFallback:
    """`_scale_kwargs(supports_amplitude=False)` is for plot_topomap /
    plot_topo, which don't have an `amplitude` kwarg.  When the user
    picks "amplitude" on those entries, fall back silently to power."""

    def test_amplitude_falls_back_to_power_on_topo(self):
        from ide4eeg.analysis.mne_catalog import _scale_kwargs
        out = _scale_kwargs({"scale": "amplitude"},
                            supports_amplitude=False)
        assert out == {"dB": False}

    def test_amplitude_full_on_plot(self):
        from ide4eeg.analysis.mne_catalog import _scale_kwargs
        out = _scale_kwargs({"scale": "amplitude"},
                            supports_amplitude=True)
        assert out == {"dB": False, "amplitude": True}


class TestPsdScaleParamPresence:
    """Every PSD entry exposes a `scale` choice."""

    def test_all_psd_entries_have_scale(self):
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG
        psd_entries = {"psd_topomap", "psd_multitaper",
                       "psd_welch", "psd_topo"}
        for entry in MNE_CATALOG:
            if entry["id"] in psd_entries:
                keys = {p["key"] for p in entry.get("params", [])}
                assert "scale" in keys, (
                    f"{entry['id']} missing scale param")

    def test_topo_entries_use_2way_choice(self):
        """psd_topomap / psd_topo only offer dB / power (their plot
        function lacks amplitude)."""
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG
        for entry in MNE_CATALOG:
            if entry["id"] in ("psd_topomap", "psd_topo"):
                scale = next(p for p in entry["params"]
                             if p["key"] == "scale")
                assert scale["choices"] == ["dB", "power"]

    def test_plot_entries_use_3way_choice(self):
        """psd_multitaper / psd_welch offer the full dB / power /
        amplitude choice."""
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG
        for entry in MNE_CATALOG:
            if entry["id"] in ("psd_multitaper", "psd_welch"):
                scale = next(p for p in entry["params"]
                             if p["key"] == "scale")
                assert scale["choices"] == ["dB", "power", "amplitude"]


class TestMaybeSaveCsv:

    def test_skips_when_save_csv_false(self, tmp_path):
        from ide4eeg.analysis.mne_catalog import _maybe_save_csv

        class FakeSpec:
            def to_data_frame(self):  # pragma: no cover
                raise AssertionError("should not be called")
        _maybe_save_csv(FakeSpec(), {"save_csv": False}, str(tmp_path),
                        "base", "psd_welch", "go")
        assert list(tmp_path.iterdir()) == []

    def test_writes_csv_when_save_csv_true(self, tmp_path):
        import pandas as pd
        from ide4eeg.analysis.mne_catalog import _maybe_save_csv

        class FakeSpec:
            def to_data_frame(self):
                return pd.DataFrame({"freq": [1, 2, 3], "power": [.1, .2, .3]})
        _maybe_save_csv(FakeSpec(), {"save_csv": True}, str(tmp_path),
                        "base", "psd_welch", "go")
        files = list(tmp_path.iterdir())
        assert len(files) == 1
        assert files[0].name == "base___MNE___psd_welch___go.csv"
