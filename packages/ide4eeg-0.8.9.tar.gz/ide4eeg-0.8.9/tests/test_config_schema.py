"""Validation rules for IDE4EEG TOML configs.

Locks the behaviour of :mod:`ide4eeg.config_schema`: typos and
wrong-shape sections must surface as a single WARNING line through
the standard logger, while the load itself stays lenient (returns a
dict either way).
"""
import dataclasses
import logging

import pytest

from ide4eeg.config_schema import (
    ConfigIsExamplesManifestError,
    ConfigIssue,
    is_examples_manifest,
    validate_config,
)


def test_default_config_validates_clean():
    """The shipped DEFAULT_CONFIG must itself be schema-clean."""
    from ide4eeg.gui_config import DEFAULT_CONFIG
    issues = validate_config(dict(DEFAULT_CONFIG))
    assert issues == []


def test_empty_config_validates_clean():
    """Sparse user configs are normal — defaults fill the rest."""
    assert validate_config({}) == []


def test_unknown_top_level_key_warns():
    issues = validate_config({"filer": {"method": "iir"}})
    assert len(issues) == 1
    assert issues[0].severity == logging.WARNING
    assert issues[0].key_path == "filer"
    assert "unknown top-level key" in issues[0].message


def test_typo_suggestion_offered():
    issues = validate_config({"filers": {}})
    assert len(issues) == 1
    assert "did you mean 'filters'" in issues[0].message


def test_deprecated_keys_get_tailored_message():
    """Keys we intentionally removed (use_mne_viewer, prepare_tf_*)
    must warn with migration text, not the generic "typo" line.
    Without this the user sees "likely a typo" for a key we
    deliberately dropped — confusing and unactionable.
    """
    from ide4eeg.config_schema import DEPRECATED_TOP_LEVEL_KEYS
    for key, expected_phrase in [
        ("use_mne_viewer", "deprecated in 0.8.5"),
        ("prepare_tf_statistics", "deferred"),
        ("prepare_statistics", "removed"),
    ]:
        assert key in DEPRECATED_TOP_LEVEL_KEYS, (
            f"{key} should be registered in DEPRECATED_TOP_LEVEL_KEYS")
        issues = validate_config({key: False})
        assert len(issues) == 1
        assert issues[0].key_path == key
        assert "typo" not in issues[0].message, (
            f"deprecated key {key!r} should not say 'typo'; got: "
            f"{issues[0].message!r}")
        assert expected_phrase in issues[0].message


def test_typo_too_far_no_suggestion():
    issues = validate_config({"xyzzy": 42})
    assert len(issues) == 1
    # No close match → no parenthetical
    assert "did you mean" not in issues[0].message


def test_dict_section_scalar_value_warns():
    """`filters = "iir"` instead of `[filters]\\nmethod = "iir"`."""
    issues = validate_config({"filters": "iir"})
    assert len(issues) == 1
    assert issues[0].key_path == "filters"
    assert "expected a [section]" in issues[0].message


def test_underscore_prefixed_keys_skipped():
    """Runtime-injected metadata (_input_dir, _mp_book_path etc.)
    isn't in DEFAULT_CONFIG; must not produce typo warnings."""
    issues = validate_config({
        "_input_dir": "/tmp",
        "_mp_book_path": "/data/book.db",
    })
    assert issues == []


def test_runtime_serialized_cfg_skipped_entirely():
    """When the GUI dumps its in-memory cfg to a temp TOML for the
    runner to consume, the cfg holds runtime sections that aren't
    declared in DEFAULT_CONFIG (mne_catalog, amplitude_*, etc.).
    Validating those would spam warnings the user never typed.

    The _pipeline_config_hash pin is the tell: a user-facing TOML
    never carries it, runtime snapshots always do."""
    issues = validate_config({
        "_pipeline_config_hash": "abcd1234",
        "filerz": {},          # typo — would normally warn
        "amplitude_max_threshold": 150e-6,  # runtime-injected
        "mne_catalog": [],     # runtime-injected
    })
    assert issues == []


def test_multiple_issues_all_reported():
    issues = validate_config({
        "filer": {},        # typo
        "filters": "iir",   # wrong shape
        "input_path": "/data/x.fif",  # correct
    })
    assert len(issues) == 2
    keys = {iss.key_path for iss in issues}
    assert keys == {"filer", "filters"}


def test_issues_logged_at_warning_level(caplog):
    with caplog.at_level(logging.WARNING, logger="ide4eeg.config_schema"):
        validate_config({"unknown_thing": 1}, source="/tmp/test.toml")
    assert any("unknown_thing" in r.message for r in caplog.records)
    assert any("/tmp/test.toml" in r.message for r in caplog.records)


def test_load_toml_emits_validation_warning(tmp_path, caplog):
    """End-to-end: load_toml passes a typo'd config and the warning
    surfaces through the logger."""
    cfg = tmp_path / "test.toml"
    cfg.write_text('filer = "iir"\n')
    from ide4eeg.gui_config import load_toml
    with caplog.at_level(logging.WARNING, logger="ide4eeg.config_schema"):
        result = load_toml(str(cfg))
    # Lenient: load still returns the (invalid) dict
    assert result == {"filer": "iir"}
    # But the warning was emitted
    assert any("filer" in r.message for r in caplog.records)


class TestConfigIssue:
    def test_str_format(self):
        iss = ConfigIssue(logging.WARNING, "filers", "unknown top-level key")
        assert str(iss) == "[warning] filers: unknown top-level key"

    def test_frozen(self):
        iss = ConfigIssue(logging.WARNING, "x", "y")
        with pytest.raises(dataclasses.FrozenInstanceError):
            iss.severity = logging.ERROR  # type: ignore[misc]


class TestExamplesManifestGuard:
    """``ide4eeg path/to/example.toml`` (the per-example manifest
    rather than the pipeline config) used to spew ~7 unknown-key
    warnings then crash deeper in.  The detector + custom exception
    short-circuit with a single message pointing at the actual
    config file."""

    _SHIPPED_MANIFEST = {
        "title": "Example",
        "order": 1,
        "description": "...",
        "reference": "doi:...",
        "data": {"package": "foo", "version": "v1", "sha256": "abc"},
        "docs": [{"url": "...", "label": "..."}],
        "configs": [{"file": "config_foo.toml", "label": "Default"}],
    }

    def test_shipped_manifest_shape_detected(self):
        assert is_examples_manifest(self._SHIPPED_MANIFEST) is True

    def test_real_pipeline_config_not_flagged(self):
        cfg = {
            "filters": {"method": "iir", "order": 2},
            "preprocessing": {"step_order": ["filtering"]},
            "ICA_EOG": {"method": "picard"},
        }
        assert is_examples_manifest(cfg) is False

    def test_empty_cfg_not_flagged(self):
        assert is_examples_manifest({}) is False

    def test_configs_array_without_file_keys_not_flagged(self):
        # ``configs`` is the strong signature, but only when the
        # array entries each have a ``file`` key (the manifest
        # contract).  A user putting a free-form ``configs = [...]``
        # in their cfg must not be misclassified.
        assert is_examples_manifest(
            {"configs": [{"label": "x"}, {"label": "y"}]}) is False

    def test_validate_config_raises_on_manifest(self):
        with pytest.raises(ConfigIsExamplesManifestError) as exc_info:
            validate_config(self._SHIPPED_MANIFEST,
                            source="/path/to/example.toml")
        msg = str(exc_info.value)
        assert "manifest" in msg.lower()
        assert "config_foo.toml" in msg  # points at the real config

    def test_validate_config_clean_on_real_cfg(self):
        # Positive control -- a real cfg with ``filters`` etc. must
        # NOT trip the manifest path.
        issues = validate_config({"filters": {"method": "iir"}})
        # No raise, no manifest-related issue.
        assert all("manifest" not in (i.message or "").lower()
                   for i in issues)

    def test_error_message_lists_all_configs(self):
        manifest = {
            "title": "Multi-config example",
            "configs": [
                {"file": "config_a.toml", "label": "A"},
                {"file": "config_b.toml", "label": "B"},
            ],
        }
        with pytest.raises(ConfigIsExamplesManifestError) as exc_info:
            validate_config(manifest, source="/dir/example.toml")
        msg = str(exc_info.value)
        assert "config_a.toml" in msg
        assert "config_b.toml" in msg
        # And the example title is in the message for context.
        assert "Multi-config example" in msg
