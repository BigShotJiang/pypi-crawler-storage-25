"""Tests for the MP decomposition ↔ analysis preflight validation.

Rules under test (see mp-preflight-rules.md):

R1  Dipole Fitting forces MMP1 algorithm.
R2  TF Statistics (MP) / EEG Profiles require explicit channel
    selection from the MP book.
R3  Any consumer that needs an MP book auto-enables MP
    decomposition (GUI: modal + unfold; CLI: ValueError).
"""

import copy
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _legacy_to_step_order(cfg):
    """Translate the deleted ``prepare_mp_decomposition`` test keyword
    into ``preprocessing.step_order`` membership (in place).

    Lets the existing test corpus keep using the readable
    ``prepare_mp_decomposition=True/False`` shorthand without mass
    rewriting.  Mirrors the migration the user does in their TOMLs.
    """
    if "prepare_mp_decomposition" in cfg:
        enable = cfg.pop("prepare_mp_decomposition")
        preproc = cfg.setdefault("preprocessing", {})
        order = preproc.setdefault("step_order", [])
        if enable and "mp_decomposition" not in order:
            order.append("mp_decomposition")
        elif not enable and "mp_decomposition" in order:
            order.remove("mp_decomposition")


# ── CLI preflight ────────────────────────────────────────────────────

class TestCLIPreflight:
    """Test _preflight_check_cli from ide4eeg/main.py."""

    @staticmethod
    def _base_cfg(**overrides):
        cfg = {
            "prepare_dipole_fitting": False,
            "prepare_eeg_profiles": False,
            "prepare_mp_filter": False,
            "matching_pursuit": {"algorithm": "smp"},
            "eeg_profiles": {},
            "preprocessing": {"step_order": ["mp_decomposition"]},
        }
        for k, v in overrides.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
        _legacy_to_step_order(cfg)
        return cfg

    def test_no_consumers_passes(self):
        from ide4eeg.main import _preflight_check_cli
        _preflight_check_cli(self._base_cfg())

    def test_r3_mp_off_raises(self):
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            prepare_mp_decomposition=False,
            prepare_eeg_profiles=True,
            eeg_profiles={"channel": "Cz"})
        with pytest.raises(ValueError, match="MP (decomposition|book)"):
            _preflight_check_cli(cfg)

    def test_r1_dipoles_with_smp_raises(self):
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            prepare_dipole_fitting=True,
            matching_pursuit={"algorithm": "smp"})
        with pytest.raises(ValueError, match="(?i)mmp1"):
            _preflight_check_cli(cfg)

    def test_r1_dipoles_with_mmp1_passes(self):
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            prepare_dipole_fitting=True,
            matching_pursuit={"algorithm": "mmp1"})
        _preflight_check_cli(cfg)

    def test_r1_dipoles_with_mmp3_raises(self):
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            prepare_dipole_fitting=True,
            matching_pursuit={"algorithm": "mmp3"})
        with pytest.raises(ValueError, match="(?i)mmp1"):
            _preflight_check_cli(cfg)

    def test_r2_profiles_no_channel_raises(self):
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            prepare_eeg_profiles=True,
            eeg_profiles={})
        with pytest.raises(ValueError, match="channel selection"):
            _preflight_check_cli(cfg)

    def test_r2_profiles_with_channel_passes(self):
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            prepare_eeg_profiles=True,
            eeg_profiles={"channel": "Cz"})
        _preflight_check_cli(cfg)

    def test_r1_and_r2_dipoles_plus_profiles(self):
        """Both Dipoles + Profiles: algo must be MMP1 AND channel set."""
        from ide4eeg.main import _preflight_check_cli
        # Fails R1 first (algo check runs before channel check)
        cfg = self._base_cfg(
            prepare_dipole_fitting=True,
            prepare_eeg_profiles=True,
            matching_pursuit={"algorithm": "smp"},
            eeg_profiles={"channel": "Cz"})
        with pytest.raises(ValueError, match="(?i)mmp1"):
            _preflight_check_cli(cfg)
        # Fix algo → passes R1, but missing channel → fails R2
        cfg["matching_pursuit"]["algorithm"] = "mmp1"
        cfg["eeg_profiles"] = {}
        with pytest.raises(ValueError, match="channel"):
            _preflight_check_cli(cfg)
        # Fix both
        cfg["eeg_profiles"]["channel"] = "Cz"
        _preflight_check_cli(cfg)

    def test_shared_consumer_helper(self):
        from ide4eeg.main import mp_consumers_from_cfg
        cfg = self._base_cfg(
            prepare_dipole_fitting=True,
            prepare_eeg_profiles=True,
            prepare_mp_filter=True)
        consumers = mp_consumers_from_cfg(cfg)
        assert "Dipole Fitting" in consumers
        assert "EEG Profiles" in consumers
        assert "MP Filter" in consumers


class TestCLIStage5Rules:
    """Stage 5 dispatcher integration in the CLI preflight path.

    Phase 11a/b wired the dispatcher into the GUI; this verifies the
    CLI calls it too so the GUI/CLI parity contract holds for the
    cfg-only rule subset (step order, mode-event, dipole-mmp1).
    Signal-dependent rules (channel-name, etc.) short-circuit at
    ``ch_names=None`` and will re-fire per-file during the load
    loop -- not covered here.
    """

    @staticmethod
    def _base_cfg(**overrides):
        cfg = {
            "matching_pursuit": {"algorithm": "smp"},
            "eeg_profiles": {},
            "preprocessing": {"step_order": []},
        }
        for k, v in overrides.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
        return cfg

    def test_ordering_constraint_violation_raises_value_error(self):
        """``mp_filter`` before ``mp_decomposition`` is a hard rule
        error -> ValueError out of _preflight_check_cli."""
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            preprocessing={
                "step_order": ["mp_filter", "mp_decomposition"],
            },
        )
        with pytest.raises(ValueError, match="mp_decomposition"):
            _preflight_check_cli(cfg)

    def test_mode_event_no_selection_raises(self):
        """Event-locked mode + empty selection -> rule fires
        ValueError."""
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            segmentation={"mode": "epochs"},
            epochs={"tags": {"selected": []}},
        )
        with pytest.raises(ValueError, match="events"):
            _preflight_check_cli(cfg)

    def test_warnings_logged_not_raised(self, caplog):
        """Rule with severity=warning logs via logging.warning but
        does NOT raise.  Uses re_reference channel-missing as the
        warning trigger because eeg_profiles + event-locked also
        trips the inline R2 (no channel selected)."""
        from ide4eeg.main import _preflight_check_cli
        cfg = self._base_cfg(
            re_reference="M1, M2",   # no signal context -> rule short-circuits
            segmentation={"mode": "rest"},
        )
        # With ch_names=None the reference rule short-circuits silently.
        # Pick a rule that runs cfg-only and emits warning: connectivity
        # without signal also short-circuits.  Use the modes warning:
        cfg = self._base_cfg(
            segmentation={"mode": "epochs"},
            epochs={"tags": {"selected": ["target"]}},
            prepare_eeg_profiles=True,
            eeg_profiles={"channel": "Cz"},   # satisfy R2
            preprocessing={"step_order": ["mp_decomposition"]},
        )
        import logging
        with caplog.at_level(logging.WARNING):
            _preflight_check_cli(cfg)  # must NOT raise
        # The eeg_profiles + event-locked rule emits a warning.
        assert any("eeg_profiles" in r.message.lower()
                   for r in caplog.records), (
            f"expected an eeg_profiles warning, got "
            f"{[r.message for r in caplog.records]}")

    def test_clean_cfg_passes(self):
        """Sanity: no rules fire on a vanilla cfg."""
        from ide4eeg.main import _preflight_check_cli
        _preflight_check_cli(self._base_cfg())


class TestCLISignalLoadRules:
    """Phase 13b: per-file signal_load dispatcher inside
    _process_one_file.  Channel-dependent rules only fire here
    because the pre-loop pre_launch preflight has ch_names=None.
    """

    @staticmethod
    def _make_signal(ch_names=("Fp1", "Fp2", "Cz", "Pz", "STIM"),
                     ch_types=("eeg", "eeg", "eeg", "eeg", "stim")):
        """Build a tiny synthetic MNE Raw with given channels."""
        import numpy as np
        import mne
        info = mne.create_info(list(ch_names), sfreq=128.0,
                               ch_types=list(ch_types))
        data = np.zeros((len(ch_names), 256))
        return mne.io.RawArray(data, info, verbose=False)

    @staticmethod
    def _base_cfg(**overrides):
        cfg = {
            "matching_pursuit": {"algorithm": "smp"},
            "eeg_profiles": {},
            "preprocessing": {"step_order": []},
        }
        for k, v in overrides.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
        return cfg

    def test_missing_ica_eog_channel_warns(self, caplog):
        """ICA EOG references a channel not in the per-file signal
        -> warning logged but run continues."""
        from ide4eeg.main import _run_stage5_signal_load_rules_cli
        cfg = self._base_cfg(
            ICA_EOG={"find_bads_eog_ch": ["MISSING_EOG"]},
            # v0.8.9 consumer-enabled gate: rule only fires when ICA
            # is actually in step_order.
            preprocessing={"step_order": ["ica"]},
        )
        signal = self._make_signal()  # has Fp1/Fp2/Cz/Pz/STIM, no EOG
        import logging
        with caplog.at_level(logging.WARNING):
            _run_stage5_signal_load_rules_cli(cfg, signal)
        assert any("MISSING_EOG" in r.message for r in caplog.records), (
            f"expected ICA EOG warning, got "
            f"{[r.message for r in caplog.records]}")

    def test_dipole_ref_channel_missing_raises(self):
        """Dipole rule emits error severity -> ValueError propagates
        up to the per-file loop which adds to file_failures."""
        from ide4eeg.main import _run_stage5_signal_load_rules_cli
        cfg = self._base_cfg(
            prepare_dipole_fitting=True,
            dipole_fitting={"ref_channel": "MISSING_REF"},
        )
        signal = self._make_signal()
        with pytest.raises(ValueError, match="MISSING_REF"):
            _run_stage5_signal_load_rules_cli(cfg, signal)

    def test_event_locked_no_stim_raises(self):
        """No STIM channel + event-locked mode -> rule fires
        error -> ValueError."""
        from ide4eeg.main import _run_stage5_signal_load_rules_cli
        cfg = self._base_cfg(
            segmentation={"mode": "epochs"},
            epochs={"tags": {"selected": ["target"]}},
        )
        # Signal without STIM
        signal = self._make_signal(
            ch_names=("Fp1", "Fp2", "Cz"),
            ch_types=("eeg", "eeg", "eeg"),
        )
        with pytest.raises(ValueError, match="STIM"):
            _run_stage5_signal_load_rules_cli(cfg, signal)

    def test_clean_cfg_passes(self):
        """Sanity: matching channels + no MP analyses = no rules fire."""
        from ide4eeg.main import _run_stage5_signal_load_rules_cli
        cfg = self._base_cfg(
            ICA_EOG={"find_bads_eog_ch": ["Fp1", "Fp2"]},
        )
        signal = self._make_signal()
        # Must NOT raise.
        _run_stage5_signal_load_rules_cli(cfg, signal)


class TestCLIPeekSignalInfo:
    """Phase 13c: the _try_peek_signal_info helper + its integration
    with _preflight_check_cli so signal-dependent rules can fire at
    preflight time without waiting for the per-file loop.
    """

    @staticmethod
    def _write_fif(tmp_path, ch_names=("Fp1", "Fp2", "Cz", "Pz", "STIM"),
                   ch_types=("eeg", "eeg", "eeg", "eeg", "stim")):
        """Write a tiny synthetic FIF to tmp_path; return its path."""
        import numpy as np
        import mne
        info = mne.create_info(list(ch_names), sfreq=128.0,
                               ch_types=list(ch_types))
        raw = mne.io.RawArray(np.zeros((len(ch_names), 256)), info,
                              verbose=False)
        p = tmp_path / "synthetic-raw.fif"
        raw.save(str(p), overwrite=True, verbose=False)
        return str(p)

    def test_peek_no_input_path(self):
        from ide4eeg.main import _try_peek_signal_info
        assert _try_peek_signal_info({}) is None

    def test_peek_missing_file(self):
        from ide4eeg.main import _try_peek_signal_info
        assert _try_peek_signal_info(
            {"input_path": "/tmp/does-not-exist.fif"}) is None

    def test_peek_directory_not_file(self, tmp_path):
        """Batch mode (input_path is a directory) -> skip peek,
        defer to per-file dispatcher."""
        from ide4eeg.main import _try_peek_signal_info
        assert _try_peek_signal_info(
            {"input_path": str(tmp_path)}) is None

    def test_peek_success_returns_metadata(self, tmp_path):
        """Real FIF -> peek returns ch_names + ch_types."""
        from ide4eeg.main import _try_peek_signal_info
        path = self._write_fif(tmp_path)
        info = _try_peek_signal_info({"input_path": path})
        assert info is not None
        assert "Fp1" in info["ch_names"]
        assert info["ch_types"]["STIM"] == "stim"

    def test_preflight_cli_uses_peek_for_signal_rules(self, tmp_path):
        """Integration: ICA EOG referencing a missing channel +
        a readable input file -> preflight catches the issue
        BEFORE the file loop (vs. only catching it per-file in
        Phase 13b)."""
        from ide4eeg.main import _preflight_check_cli
        path = self._write_fif(
            tmp_path,
            ch_names=("Fp1", "Fp2", "Cz", "STIM"),  # no Fpz
            ch_types=("eeg", "eeg", "eeg", "stim"),
        )
        cfg = {
            "input_path": path,
            "matching_pursuit": {"algorithm": "smp"},
            "eeg_profiles": {},
            # v0.8.9 consumer-enabled gate.
            "preprocessing": {"step_order": ["ica"]},
            "ICA_EOG": {"find_bads_eog_ch": ["Fpz"]},
        }
        # ICA EOG rule fires with severity=warning -> logged, not
        # raised.  Must not raise.
        import logging
        import io
        log_stream = io.StringIO()
        handler = logging.StreamHandler(log_stream)
        handler.setLevel(logging.WARNING)
        logging.getLogger().addHandler(handler)
        try:
            _preflight_check_cli(cfg)
        finally:
            logging.getLogger().removeHandler(handler)
        assert "Fpz" in log_stream.getvalue()

    def test_preflight_cli_silent_without_input_path(self):
        """Sanity: no input_path -> peek returns None -> signal
        rules short-circuit -> no spurious warnings about channels."""
        from ide4eeg.main import _preflight_check_cli
        cfg = {
            "matching_pursuit": {"algorithm": "smp"},
            "eeg_profiles": {},
            "preprocessing": {"step_order": []},
            "ICA_EOG": {"find_bads_eog_ch": ["Fpz"]},
        }
        # Must NOT raise (no signal info means signal-dependent
        # rules can't evaluate -- they short-circuit silently).
        _preflight_check_cli(cfg)


# ── CLI end-to-end via ide4eeg.main.main() ───────────────────────────
#
# These exercise the full CLI path: TOML file → read_config_file →
# _preflight_check_cli → ValueError before the per-file loop ever
# starts.  Two variants: passing a real TOML file on disk (the
# ``python run.py -c config.toml`` code path), and passing a
# programmatic config dict via a temp TOML written by dump_toml
# (the same path the GUI worker takes).


class TestCLIEndToEndWithTOML:
    """Write a minimal config.toml with a preflight violation, call
    ``ide4eeg.main.main(config_path)`` and assert ValueError."""

    @staticmethod
    def _write_toml(tmp_path, **overrides):
        """Create a minimal TOML and return the file path."""
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
        from ide4eeg.gui_config import dump_toml
        cfg = {
            "input_path": str(tmp_path / "dummy.raw"),
            "output_path": str(tmp_path),
        }
        cfg.update(overrides)
        _legacy_to_step_order(cfg)
        path = str(tmp_path / "test.toml")
        dump_toml(cfg, path)
        return path

    def test_r3_toml_dipoles_without_mp(self, tmp_path):
        """Dipoles on, MP decomposition off → ValueError from TOML."""
        from ide4eeg.main import main as run_pipeline
        path = self._write_toml(
            tmp_path,
            prepare_dipole_fitting=True,
            prepare_mp_decomposition=False)
        with pytest.raises(ValueError, match="MP (decomposition|book)"):
            run_pipeline(path)

    def test_r1_toml_dipoles_with_smp(self, tmp_path):
        """Dipoles + SMP → ValueError from TOML."""
        from ide4eeg.main import main as run_pipeline
        path = self._write_toml(
            tmp_path,
            prepare_dipole_fitting=True,
            prepare_mp_decomposition=True,
            matching_pursuit={"algorithm": "smp"})
        with pytest.raises(ValueError, match="(?i)mmp1"):
            run_pipeline(path)

    def test_r2_toml_profiles_no_channel(self, tmp_path):
        """Profiles on, no channel → ValueError from TOML."""
        from ide4eeg.main import main as run_pipeline
        path = self._write_toml(
            tmp_path,
            prepare_eeg_profiles=True,
            prepare_mp_decomposition=True)
        with pytest.raises(ValueError, match="channel"):
            run_pipeline(path)

    def test_r1_toml_dipoles_mmp1_passes_preflight(self, tmp_path):
        """Dipoles + MMP1 passes preflight (fails later on missing file,
        not on preflight)."""
        from ide4eeg.main import main as run_pipeline
        path = self._write_toml(
            tmp_path,
            prepare_dipole_fitting=True,
            prepare_mp_decomposition=True,
            matching_pursuit={"algorithm": "mmp1"})
        # Should raise RuntimeError ("Cannot read signal") not ValueError
        with pytest.raises((RuntimeError, FileNotFoundError)):
            run_pipeline(path)

class TestCLIEndToEndProgrammatic:
    """Same violations but config is built in Python and dumped to
    a temp TOML — mimicking the GUI's _launch_pipeline path."""

    @staticmethod
    def _dump_and_run(tmp_path, cfg):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
        from ide4eeg.gui_config import dump_toml
        from ide4eeg.main import main as run_pipeline
        cfg.setdefault("input_path", str(tmp_path / "dummy.raw"))
        cfg.setdefault("output_path", str(tmp_path))
        _legacy_to_step_order(cfg)
        path = str(tmp_path / "programmatic.toml")
        dump_toml(cfg, path)
        run_pipeline(path)

    def test_r3_programmatic_profiles_no_mp(self, tmp_path):
        with pytest.raises(ValueError, match="MP (decomposition|book)"):
            self._dump_and_run(tmp_path, {
                "prepare_eeg_profiles": True,
                "eeg_profiles": {"channel": "Cz"},
                "prepare_mp_decomposition": False,
            })

    def test_r1_programmatic_dipoles_mmp3(self, tmp_path):
        with pytest.raises(ValueError, match="(?i)mmp1"):
            self._dump_and_run(tmp_path, {
                "prepare_dipole_fitting": True,
                "prepare_mp_decomposition": True,
                "matching_pursuit": {"algorithm": "mmp3"},
            })

    def test_r2_programmatic_profiles_no_channel(self, tmp_path):
        with pytest.raises(ValueError, match="channel"):
            self._dump_and_run(tmp_path, {
                "prepare_eeg_profiles": True,
                "prepare_mp_decomposition": True,
            })

    def test_clean_config_passes_preflight(self, tmp_path):
        """Well-formed config passes preflight (fails later on missing file)."""
        with pytest.raises((RuntimeError, FileNotFoundError)):
            self._dump_and_run(tmp_path, {
                "prepare_eeg_profiles": True,
                "eeg_profiles": {"channel": "Cz"},
                "prepare_mp_decomposition": True,
                "matching_pursuit": {"algorithm": "smp"},
            })


# ── GUI preflight ────────────────────────────────────────────────────

_qt_app = None
_qt_gui = None


def _get_qt_gui():
    global _qt_app, _qt_gui
    if _qt_gui is not None:
        return _qt_gui
    try:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        _qt_app = QApplication.instance() or QApplication(sys.argv)
        from ide4eeg.gui import IDE4EEG_Qt
        _qt_gui = IDE4EEG_Qt()
    except Exception as e:
        pytest.skip(f"Cannot create Qt GUI: {e}")
    return _qt_gui


@pytest.fixture(scope="module")
def qt_gui():
    gui = _get_qt_gui()
    if gui is None:
        pytest.skip("Qt GUI not available")
    yield gui


def _reset_gui_state(gui):
    """Reset analysis + MP checkboxes to off for clean test state."""
    an = getattr(gui, "_an", {})
    pp = getattr(gui, "_pp", {})
    for key in ("_dip_grp", "_prof_grp"):
        grp = an.get(key)
        if grp and hasattr(grp, "setChecked"):
            grp.setChecked(False)
    mp_grp = pp.get("_mp_grp")
    if mp_grp:
        mp_grp.setChecked(False)
    mpf_grp = pp.get("_mpf_grp")
    if mpf_grp:
        mpf_grp.setChecked(False)


class TestGUIPreflight:
    """Test _mp_preflight_gui on the offscreen Qt GUI."""

    def test_no_consumers_returns_true(self, qt_gui, monkeypatch):
        _reset_gui_state(qt_gui)
        assert qt_gui._mp_preflight_gui() is True

    def test_r3_auto_enables_mp_and_returns_false(
            self, qt_gui, monkeypatch):
        """When Profiles is on but MP is off, R3 fires."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        an["_prof_grp"].setChecked(True)
        monkeypatch.setattr(qt_gui, "_find_mp_book", lambda: None)
        shown = {}
        monkeypatch.setattr(
            qt_gui, "_msg_info",
            lambda t, m: shown.setdefault("title", t))

        result = qt_gui._mp_preflight_gui()
        _reset_gui_state(qt_gui)

        assert result is False
        assert "mp" in shown.get("title", "").lower()

    def test_r1_switches_to_mmp1_and_returns_false(
            self, qt_gui, monkeypatch):
        """When Dipoles is on with SMP, R1 fires."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        pp = qt_gui._pp
        an["_dip_grp"].setChecked(True)
        pp["_mp_grp"].setChecked(True)
        # Set algo to SMP
        from ide4eeg.analysis.mp_analysis import mp_algorithm_choices
        smp_label = next(
            l for n, l in mp_algorithm_choices() if n == "smp")
        pp["mp_algo"].setCurrentText(smp_label)

        shown = {}
        monkeypatch.setattr(
            qt_gui, "_msg_info",
            lambda t, m: shown.setdefault("title", t))

        result = qt_gui._mp_preflight_gui()
        _reset_gui_state(qt_gui)

        assert result is False
        assert "mp" in shown.get("title", "").lower()

    def test_r1_mmp1_already_set_passes(self, qt_gui, monkeypatch):
        """When Dipoles is on with MMP1 already, R1 doesn't fire."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        pp = qt_gui._pp
        an["_dip_grp"].setChecked(True)
        pp["_mp_grp"].setChecked(True)
        from ide4eeg.analysis.mp_analysis import mp_algorithm_choices
        mmp1_label = next(
            l for n, l in mp_algorithm_choices() if n == "mmp1")
        pp["mp_algo"].setCurrentText(mmp1_label)

        result = qt_gui._mp_preflight_gui()
        _reset_gui_state(qt_gui)

        assert result is True

    def test_r2_profiles_no_channel_returns_false(
            self, qt_gui, monkeypatch):
        """Profiles with no channel selected fires R2."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        pp = qt_gui._pp
        an["_prof_grp"].setChecked(True)
        pp["_mp_grp"].setChecked(True)
        # Ensure the book panel has no channel selected
        bp = an.get("prof_book_panel")
        if bp:
            bp._ch_combo.clear()

        shown = {}
        monkeypatch.setattr(
            qt_gui, "_msg_info",
            lambda t, m: shown.setdefault("title", t))

        result = qt_gui._mp_preflight_gui()
        _reset_gui_state(qt_gui)

        assert result is False
        assert "channel" in shown.get("title", "").lower()

    def test_r2_profiles_with_channel_passes(
            self, qt_gui, monkeypatch):
        """Profiles with a channel selected passes R2."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        pp = qt_gui._pp
        an["_prof_grp"].setChecked(True)
        pp["_mp_grp"].setChecked(True)
        bp = an.get("prof_book_panel")
        if bp:
            bp._ch_combo.clear()
            bp._ch_combo.addItem("Cz")

        result = qt_gui._mp_preflight_gui()
        _reset_gui_state(qt_gui)

        assert result is True

    def test_r3_before_r1_order(self, qt_gui, monkeypatch):
        """R3 (auto-enable MP) fires before R1 (algo check)."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        an["_dip_grp"].setChecked(True)
        # MP is OFF — R3 should fire first, not R1
        monkeypatch.setattr(qt_gui, "_find_mp_book", lambda: None)
        shown = {}
        monkeypatch.setattr(
            qt_gui, "_msg_info",
            lambda t, m: shown.setdefault("title", t))

        result = qt_gui._mp_preflight_gui()
        _reset_gui_state(qt_gui)

        assert result is False
        assert "mp" in shown.get("title", "").lower()


    def test_mp_filter_needs_mp(self, qt_gui, monkeypatch):
        """MP Filter on + MP decomposition off fires R3."""
        _reset_gui_state(qt_gui)
        pp = qt_gui._pp
        mpf_grp = pp.get("_mpf_grp")
        if not mpf_grp:
            pytest.skip("MP Filter panel not built")
        mpf_grp.setChecked(True)
        monkeypatch.setattr(qt_gui, "_find_mp_book", lambda: None)
        shown = {}
        monkeypatch.setattr(
            qt_gui, "_msg_info",
            lambda t, m: shown.setdefault("title", t))

        result = qt_gui._mp_preflight_gui()
        _reset_gui_state(qt_gui)

        assert result is False
        assert "mp" in shown.get("title", "").lower()


class TestGUIRunPipelinePreflight:
    """End-to-end: call _run_pipeline with monkeypatched
    _launch_pipeline to verify _mp_preflight_gui gates the launch."""

    def test_run_pipeline_blocked_by_r1(self, qt_gui, monkeypatch):
        """_run_pipeline should NOT reach _launch_pipeline when R1 fails."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        pp = qt_gui._pp
        an["_dip_grp"].setChecked(True)
        pp["_mp_grp"].setChecked(True)
        from ide4eeg.analysis.mp_analysis import mp_algorithm_choices
        smp_label = next(
            l for n, l in mp_algorithm_choices() if n == "smp")
        pp["mp_algo"].setCurrentText(smp_label)

        launched = {"count": 0}
        monkeypatch.setattr(
            qt_gui, "_launch_pipeline",
            lambda cfg: launched.__setitem__(
                "count", launched["count"] + 1) or True)
        monkeypatch.setattr(
            qt_gui, "_msg_info", lambda t, m: None)

        qt_gui._run_pipeline()
        _reset_gui_state(qt_gui)

        assert launched["count"] == 0, \
            "_launch_pipeline should not be called when R1 fails"

    def test_run_pipeline_blocked_by_r3(self, qt_gui, monkeypatch):
        """_run_pipeline blocked when MP off + consumer on."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        an["_prof_grp"].setChecked(True)
        monkeypatch.setattr(qt_gui, "_find_mp_book", lambda: None)

        launched = {"count": 0}
        monkeypatch.setattr(
            qt_gui, "_launch_pipeline",
            lambda cfg: launched.__setitem__(
                "count", launched["count"] + 1) or True)
        monkeypatch.setattr(
            qt_gui, "_msg_info", lambda t, m: None)

        qt_gui._run_pipeline()
        _reset_gui_state(qt_gui)

        assert launched["count"] == 0

    def test_run_pipeline_proceeds_when_all_rules_pass(
            self, qt_gui, monkeypatch):
        """_run_pipeline reaches _launch_pipeline when preflight passes."""
        _reset_gui_state(qt_gui)
        an = qt_gui._an
        pp = qt_gui._pp
        an["_prof_grp"].setChecked(True)
        pp["_mp_grp"].setChecked(True)
        bp = an.get("prof_book_panel")
        if bp:
            bp._ch_combo.clear()
            bp._ch_combo.addItem("Cz")

        launched = {"count": 0}
        monkeypatch.setattr(
            qt_gui, "_launch_pipeline",
            lambda cfg: launched.__setitem__(
                "count", launched["count"] + 1) or True)

        qt_gui._run_pipeline()
        _reset_gui_state(qt_gui)

        assert launched["count"] == 1, \
            "_launch_pipeline should be called when preflight passes"
