"""Parity tests for parallelised preprocessing steps.

Locks byte-equality between sequential (n_jobs=1) and parallel
(n_jobs>1) execution for:

- IIR filtering (``_filter_signal``, threading backend, in-place)
- Artifact detection (``outliers``, ``P2P``, ``muscles``, loky backend)

These tests exist because both paths were refactored to parallelise
the per-channel inner loop. If a future change alters numerical
behaviour when n_jobs changes, these tests will flag it.
"""

import numpy as np
import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_multichannel_raw(fs=256, duration=4.0, n_eeg=6, seed=0):
    """Create an MNE Raw with N EEG channels + 1 STIM, deterministic."""
    import mne
    rng = np.random.default_rng(seed)
    n = int(fs * duration)
    t = np.arange(n) / fs
    eeg = np.zeros((n_eeg, n))
    for i in range(n_eeg):
        eeg[i] = (
            (i + 1) * 1e-5 * np.sin(2 * np.pi * (8 + i) * t)
            + 3e-6 * np.sin(2 * np.pi * 50 * t)
            + 1e-6 * rng.standard_normal(n)
        )
    stim = np.zeros(n)
    data = np.vstack([eeg, stim])
    names = [f"EEG{i+1}" for i in range(n_eeg)] + ["STIM"]
    info = mne.create_info(names, sfreq=fs,
                           ch_types=["eeg"] * n_eeg + ["stim"])
    return mne.io.RawArray(data, info, verbose=False)


def _make_artifact_data(fs=256, duration=4.0, n_ch=6, seed=0):
    """Deterministic multichannel numpy array + MNE Info + channel names."""
    import mne
    rng = np.random.default_rng(seed)
    n = int(fs * duration)
    t = np.arange(n) / fs
    data = np.zeros((n_ch, n))
    for i in range(n_ch):
        data[i] = (
            (i + 1) * 1e-5 * np.sin(2 * np.pi * (8 + i) * t)
            + 2e-6 * rng.standard_normal(n)
        )
        # inject a spike to make thresholds non-trivial
        data[i, 100 + i * 50] += 5e-4
    names = [f"C{i+1}" for i in range(n_ch)]
    info = mne.create_info(names, sfreq=fs, ch_types="eeg")
    return data, info, names


# ---------------------------------------------------------------------------
# IIR filter parity
# ---------------------------------------------------------------------------

class TestIIRFilterParity:
    """n_jobs=1 and n_jobs=2 must produce byte-identical filtered signals."""

    def _run(self, n_jobs, tmp_path):
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        raw = _make_multichannel_raw(fs=256, duration=4.0, n_eeg=6, seed=42)
        cfg = {
            "filters": {
                "method": "iir",
                "highpass_freq": 1.0,
                "lowpass_freq": 30.0,
                "notch_freq": 50.0,
                "show_filt": False,
                "plot_filt": False,
            },
            "parallelism": {"n_jobs": n_jobs},
        }
        out = _filter_signal(raw, cfg, str(tmp_path))
        return out.get_data(picks=["eeg"])

    def test_serial_vs_parallel_identical(self, tmp_path):
        a = self._run(n_jobs=1, tmp_path=tmp_path)
        b = self._run(n_jobs=2, tmp_path=tmp_path)
        # Threading backend + in-place writes — must be byte-equal.
        np.testing.assert_array_equal(a, b)

    def test_single_channel_still_works(self, tmp_path):
        """Edge case: fewer channels than workers."""
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        import mne
        fs = 256
        t = np.arange(fs * 2) / fs
        data = np.vstack([1e-5 * np.sin(2 * np.pi * 10 * t), np.zeros_like(t)])
        info = mne.create_info(["EEG1", "STIM"], sfreq=fs,
                               ch_types=["eeg", "stim"])
        raw = mne.io.RawArray(data, info, verbose=False)
        cfg = {
            "filters": {
                "method": "iir",
                "highpass_freq": 1.0,
                "lowpass_freq": 30.0,
                "notch_freq": 0,
                "show_filt": False,
                "plot_filt": False,
            },
            "parallelism": {"n_jobs": 4},  # more workers than channels
        }
        out = _filter_signal(raw, cfg, str(tmp_path))
        assert np.all(np.isfinite(out.get_data(picks=["eeg"])))


# ---------------------------------------------------------------------------
# Artifact detection parity
# ---------------------------------------------------------------------------

class TestArtifactParity:
    """outliers / P2P / muscles must return identical dicts for n_jobs=1 vs 2."""

    def test_outliers_parity(self):
        from ide4eeg.preprocessing.artifacts import outliers
        data, info, names = _make_artifact_data(seed=1)
        kw = dict(filters=None, StdThr=3.0, AbsThr=np.inf, MedThr=np.inf,
                  outpath="")
        bad_a, thr_a = outliers(data.copy(), info, names, n_jobs=1, **kw)
        bad_b, thr_b = outliers(data.copy(), info, names, n_jobs=2, **kw)
        assert thr_a == thr_b
        assert set(bad_a) == set(bad_b)
        for ch in bad_a:
            np.testing.assert_array_equal(bad_a[ch], bad_b[ch])

    def test_p2p_parity(self):
        from ide4eeg.preprocessing.artifacts import P2P
        data, info, names = _make_artifact_data(seed=2)
        kw = dict(filters=None, StdThr=3.0, AbsThr=np.inf, MedThr=np.inf,
                  kind="slopes", outpath="")
        bad_a, thr_a = P2P(data.copy(), info, names, 0.2, n_jobs=1, **kw)
        bad_b, thr_b = P2P(data.copy(), info, names, 0.2, n_jobs=2, **kw)
        assert thr_a == thr_b
        assert set(bad_a) == set(bad_b)
        for ch in bad_a:
            np.testing.assert_array_equal(bad_a[ch], bad_b[ch])

    def test_muscles_parity(self):
        from ide4eeg.preprocessing.artifacts import muscles
        data, info, names = _make_artifact_data(seed=3)
        kw = dict(filters=None, StdThr=3.0, AbsThr=np.inf, MedThr=np.inf,
                  outpath="")
        bad_a, thr_a = muscles(data.copy(), info, names, 0.5,
                               [47.5, 52.5], n_jobs=1, **kw)
        bad_b, thr_b = muscles(data.copy(), info, names, 0.5,
                               [47.5, 52.5], n_jobs=2, **kw)
        assert thr_a == thr_b
        assert set(bad_a) == set(bad_b)
        for ch in bad_a:
            np.testing.assert_array_equal(bad_a[ch], bad_b[ch])


# ---------------------------------------------------------------------------
# Read-only-input regression (joblib loky mmap)
# ---------------------------------------------------------------------------
# joblib's loky backend serialises large parent-process arrays via
# mmap and ships read-only views to workers.  Any in-place op
# (`c -= ...`) inside a worker fails with "output array is read-only".
# Reported on Linux 2026-04-27.  These tests simulate the failure
# locally by flipping `c.flags.writeable = False` so the regression
# is caught regardless of host platform / array size threshold.

class TestReadOnlyInputs:

    def test_outliers_one_channel_handles_readonly(self):
        from ide4eeg.preprocessing.artifacts import _outliers_one_channel
        c = np.random.default_rng(0).standard_normal(2048)
        c.flags.writeable = False
        # Should not raise.
        _outliers_one_channel(
            ch=0, c=c, StdThr=5.0, AbsThr=np.inf, MedThr=np.inf,
            outpath="")

    def test_muscles_one_channel_handles_readonly(self):
        from ide4eeg.preprocessing.artifacts import _muscles_one_channel
        c = np.random.default_rng(0).standard_normal(2048)
        c.flags.writeable = False
        # `_muscles_one_channel` expects width in samples; muscles()
        # does the seconds→samples conversion before dispatching.
        _muscles_one_channel(
            ch=0, c=c, width=128, rng=[47.5, 52.5], Fs=256,
            StdThr=3.0, AbsThr=np.inf, MedThr=np.inf, outpath="")
