"""Tests for ``ide4eeg.input.input.fif_format`` — Phase 1 STIM invariants.

Covers the three scenarios from the STIM-handling redesign:

- **(a)** FIF with no annotations and no native STIM channel
- **(b)** FIF with annotations but no native STIM channel
- **(c)** FIF with both annotations and a native STIM channel

After Phase 1, the reader must always return a signal with a ``STIM``
channel (closing a latent bug where downstream code would ``KeyError``
on ``ch_names.index("STIM")``), and case (c) runs a consistency check
that emits warnings on mismatch between annotation-derived events and
the native STIM channel.
"""

import logging

import mne
import numpy as np
import pytest

from ide4eeg.input.input import fif_format


# ── Helpers ─────────────────────────────────────────────────────────


def _make_raw(sfreq=100.0, duration=10.0, n_eeg=3,
              stim_events=None, annotations=None):
    """Build a synthetic ``RawArray`` with ``n_eeg`` EEG channels plus
    an optional STIM channel and optional annotations.

    Parameters
    ----------
    sfreq : float
    duration : float
    n_eeg : int
    stim_events : list[tuple[int, int]] or None
        ``[(sample_index, event_id), …]`` pulses to write to a STIM
        channel.  If ``None`` the RawArray has no STIM channel.  Passing
        an empty list gives a STIM channel full of zeros.
    annotations : list[tuple[int, str]] or None
        ``[(sample_index, description), …]`` events to set as MNE
        annotations on the returned Raw.
    """
    rng = np.random.default_rng(42)
    n_samples = int(sfreq * duration)
    eeg_data = rng.standard_normal((n_eeg, n_samples)) * 1e-6

    if stim_events is None:
        data = eeg_data
        ch_names = [f"EEG{i + 1}" for i in range(n_eeg)]
        ch_types = ["eeg"] * n_eeg
    else:
        stim_data = np.zeros((1, n_samples), dtype=np.float64)
        for sample, eid in stim_events:
            stim_data[0, sample] = eid
        data = np.vstack([eeg_data, stim_data])
        ch_names = [f"EEG{i + 1}" for i in range(n_eeg)] + ["STIM"]
        ch_types = ["eeg"] * n_eeg + ["stim"]

    info = mne.create_info(ch_names, sfreq=sfreq, ch_types=ch_types)
    raw = mne.io.RawArray(data, info, verbose=False)

    if annotations:
        onsets = [s / sfreq for s, _ in annotations]
        durations = [0.0] * len(annotations)
        descriptions = [d for _, d in annotations]
        raw.set_annotations(
            mne.Annotations(onset=onsets, duration=durations,
                            description=descriptions))

    return raw


def _save_fif(raw, tmp_path, base):
    """Save *raw* to ``<tmp_path>/<base>-raw.fif`` and return the path
    stem (without the ``.fif`` extension) that :func:`fif_format`
    expects as its *name* argument.

    MNE enforces the ``-raw.fif`` suffix at save time; ``fif_format``
    appends ``.fif`` to its *name* argument, so the stem we return
    includes the ``-raw`` part.
    """
    path = tmp_path / f"{base}-raw.fif"
    raw.save(str(path), overwrite=True, verbose=False)
    return str(tmp_path / f"{base}-raw")


# ── Case (a): no annotations, no native STIM ────────────────────────


class TestCaseA_NoAnnotationsNoStim:
    """Closes a latent bug: the reader now guarantees a STIM channel
    even when the FIF file had no events at all."""

    def test_empty_stim_channel_is_added(self, tmp_path):
        raw = _make_raw()
        name = _save_fif(raw, tmp_path, "case_a")

        loaded, events_desc_id = fif_format(name)

        assert "STIM" in loaded.info["ch_names"]
        stim_idx = loaded.info["ch_names"].index("STIM")
        stim_data = loaded.get_data()[stim_idx]
        assert np.all(stim_data == 0)
        assert events_desc_id == {}
        # Channel type is stim, not eeg or misc
        assert loaded.get_channel_types()[stim_idx] == "stim"

    def test_stim_channel_length_matches_signal(self, tmp_path):
        raw = _make_raw(sfreq=250, duration=4)
        name = _save_fif(raw, tmp_path, "case_a_len")

        loaded, _ = fif_format(name)

        stim_idx = loaded.info["ch_names"].index("STIM")
        assert loaded.get_data()[stim_idx].shape == (loaded.n_times,)


# ── Case (b): annotations, no native STIM ───────────────────────────


class TestCaseB_AnnotationsOnly:
    """Synthesize STIM from annotations — existing behaviour, now
    locked by tests."""

    def test_stim_built_from_annotations(self, tmp_path):
        raw = _make_raw(
            annotations=[(100, "target"),
                         (300, "target"),
                         (500, "nontarget")])
        name = _save_fif(raw, tmp_path, "case_b")

        loaded, events_desc_id = fif_format(name)

        assert "STIM" in loaded.info["ch_names"]
        assert "target" in events_desc_id
        assert "nontarget" in events_desc_id

        # Three pulses (two targets + one nontarget) should land in STIM.
        stim_idx = loaded.info["ch_names"].index("STIM")
        stim_data = loaded.get_data()[stim_idx]
        nonzero = np.where(stim_data != 0)[0]
        assert len(nonzero) == 3


# ── Case (c): both annotations and native STIM ───────────────────────


class TestCaseC_BothPresent:
    """Phase 1 consistency check: STIM is authoritative for timing;
    annotations supply names; mismatches emit warnings."""

    def test_agreement_emits_no_disagree_warning(self, tmp_path, caplog):
        raw = _make_raw(
            stim_events=[(100, 1), (500, 2)],
            annotations=[(100, "target"), (500, "nontarget")])
        name = _save_fif(raw, tmp_path, "case_c_agree")

        with caplog.at_level(logging.WARNING):
            loaded, events_desc_id = fif_format(name)

        assert "STIM" in loaded.info["ch_names"]
        # No "disagree" warning when annotation IDs == native STIM IDs.
        assert not any(
            "disagree" in r.message for r in caplog.records), \
            f"unexpected warning: {caplog.text}"

    def test_annotation_id_missing_from_stim_warns(
            self, tmp_path, caplog):
        # Native STIM has ID 1 only; annotations reference two distinct
        # names so events_from_annotations assigns IDs {1, 2}.  ID 2 is
        # not in native STIM → warn.
        raw = _make_raw(
            stim_events=[(100, 1)],
            annotations=[(100, "target"), (300, "nontarget")])
        name = _save_fif(raw, tmp_path, "case_c_missing")

        with caplog.at_level(logging.WARNING):
            fif_format(name)

        missing_msgs = [r.message for r in caplog.records
                        if "not present in the native STIM" in r.message]
        assert missing_msgs, \
            f"expected missing-from-STIM warning, got: {caplog.text}"

    def test_extra_event_in_stim_gets_fallback_name(
            self, tmp_path, caplog):
        # Native STIM has IDs {1, 42}; annotations only name ID 1 as
        # "target".  Expect warning + fallback entry "42" → 42 in dict.
        raw = _make_raw(
            stim_events=[(100, 1), (300, 42)],
            annotations=[(100, "target")])
        name = _save_fif(raw, tmp_path, "case_c_extra")

        with caplog.at_level(logging.WARNING):
            loaded, events_desc_id = fif_format(name)

        extra_msgs = [r.message for r in caplog.records
                      if "not referenced by" in r.message]
        assert extra_msgs, \
            f"expected extra-in-STIM warning, got: {caplog.text}"

        assert "42" in events_desc_id
        assert events_desc_id["42"] == 42
        # Original annotation name still present.
        assert "target" in events_desc_id


# ── Legacy path: STIM only, no annotations ──────────────────────────


class TestStimOnly:
    """No annotations + native STIM → dict built via find_events with
    numeric-string names.  Locked as-is by Phase 1."""

    def test_dict_from_find_events(self, tmp_path):
        raw = _make_raw(
            stim_events=[(100, 1), (200, 1), (300, 7)])
        name = _save_fif(raw, tmp_path, "stim_only")

        loaded, events_desc_id = fif_format(name)

        assert "STIM" in loaded.info["ch_names"]
        # find_events ⇒ {"1": 1, "7": 7}
        assert "1" in events_desc_id
        assert "7" in events_desc_id
        assert events_desc_id["1"] == 1
        assert events_desc_id["7"] == 7

    def test_empty_stim_channel_gives_empty_dict(self, tmp_path):
        """Native STIM present but all zeros, no annotations → empty
        dict, STIM channel still present after read."""
        raw = _make_raw(stim_events=[])  # empty list ⇒ zero-filled STIM
        name = _save_fif(raw, tmp_path, "stim_empty")

        loaded, events_desc_id = fif_format(name)

        assert "STIM" in loaded.info["ch_names"]
        assert events_desc_id == {}
