"""Tests for the MP-book auto-discovery + hash reuse feature.

Covers:

* The MP hash helper is deterministic and changes with the inputs
  that actually drive book contents.
* Books carry their hash in the SQLite ``metadata`` table.
* When ``mp_decomposition`` is absent from ``step_order``, the
  preprocessing preamble auto-discovers an existing book and either
  reuses it (match / legacy) or halts with a clear error (mismatch).

These tests do NOT run empi.  They exercise the reuse logic with
hand-crafted fake .db files that mimic the schema empi would produce.
"""

import os
import sqlite3
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ide4eeg.preprocessing.mp_preprocessing import (
    _compute_mp_book_hash,
    _read_book_hash,
    _read_book_channels,
    _book_hash_status,
    _resolve_existing_book_path,
    _required_consumer_channels,
    try_reuse_existing_mp_book,
)


# ── Helpers ──────────────────────────────────────────────────────────

def _make_fake_book(path, book_hash=None, channel_names="C3,C4"):
    """Write a minimal .db file matching empi's metadata schema.

    If *book_hash* is provided, store it under ``_input_hash``; omit
    it to simulate a "legacy" book that predates this feature.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with sqlite3.connect(path) as conn:
        conn.execute(
            "CREATE TABLE metadata (param TEXT PRIMARY KEY, value TEXT)")
        conn.execute(
            "INSERT INTO metadata (param, value) VALUES ('algorithm', 'SMP')")
        conn.execute(
            "INSERT INTO metadata (param, value) VALUES "
            "('channel_names', ?)", [channel_names])
        if book_hash is not None:
            conn.execute(
                "INSERT INTO metadata (param, value) VALUES "
                "('_input_hash', ?)", [book_hash])


def _base_cfg():
    """Minimal config that exercises every hash-relevant key."""
    return {
        "preprocessing": {"step_order": [
            "trim", "chosen_channels", "bad_channels", "montage",
            "filtering", "mp_decomposition"]},
        "trim_start": 0.0,
        "trim_end": 60.0,
        "resample_freq": 256,
        "segmentation": {"mode": "rest"},
        "rest": {"window_length": 5.0},
        "events_desc_id": {},
        "choosing_channels": {"selected_channels": "all"},
        "bad_channels": {},
        "montage": {"layout": "standard_1020"},
        "re_reference": "average",
        "filters": {"highpass_freq": 0.5, "lowpass_freq": 30.0},
        "ICA_EOG": {},
        "artifacts": {},
        "matching_pursuit": {
            "algorithm": "smp",
            "iterations": 50,
            "channels": "C3,C4",
        },
    }


# ── Hash determinism ──────────────────────────────────────────

class TestHashDeterminism:

    def test_same_config_same_hash(self):
        cfg1 = _base_cfg()
        cfg2 = _base_cfg()
        assert _compute_mp_book_hash(cfg1) == \
               _compute_mp_book_hash(cfg2)

    def test_runtime_keys_dont_affect_hash(self):
        """empi_path differs across machines but doesn't change MP output."""
        cfg = _base_cfg()
        baseline = _compute_mp_book_hash(cfg)
        cfg["matching_pursuit"]["empi_path"] = "/usr/local/bin/empi"
        cfg["matching_pursuit"]["_default_workers"] = 8
        cfg["matching_pursuit"]["_segment_size"] = 1024
        cfg["matching_pursuit"]["cpu_workers"] = 4
        assert _compute_mp_book_hash(cfg) == baseline

    def test_mp_param_change_changes_hash(self):
        cfg1 = _base_cfg()
        cfg2 = _base_cfg()
        cfg2["matching_pursuit"]["iterations"] = 100
        assert _compute_mp_book_hash(cfg1) != \
               _compute_mp_book_hash(cfg2)

    def test_filter_change_changes_hash(self):
        """An upstream preprocessing change invalidates the hash."""
        cfg1 = _base_cfg()
        cfg2 = _base_cfg()
        cfg2["filters"]["highpass_freq"] = 1.0
        assert _compute_mp_book_hash(cfg1) != \
               _compute_mp_book_hash(cfg2)

    def test_epochs_change_does_not_affect_hash(self):
        """``epochs`` is postamble — runs after MP, can't influence input."""
        cfg1 = _base_cfg()
        cfg2 = _base_cfg()
        cfg1["epochs"] = {"start_offset": -0.3, "stop_offset": 0.7}
        cfg2["epochs"] = {"start_offset": -1.0, "stop_offset": 2.0}
        assert _compute_mp_book_hash(cfg1) == \
               _compute_mp_book_hash(cfg2)

    def test_mp_filter_change_does_not_affect_hash(self):
        """``mp_filter`` runs after decomposition; not part of input."""
        cfg1 = _base_cfg()
        cfg2 = _base_cfg()
        cfg1["mp_filter"] = {"freq_min": 0.5}
        cfg2["mp_filter"] = {"freq_min": 4.0}
        assert _compute_mp_book_hash(cfg1) == \
               _compute_mp_book_hash(cfg2)

    def test_input_file_mtime_changes_hash(self, tmp_path):
        """Re-recording over the same name must invalidate the book."""
        cfg = _base_cfg()
        f = tmp_path / "rec.raw"
        f.write_bytes(b"x" * 100)
        h1 = _compute_mp_book_hash(cfg, str(f))
        # Touch with a different size + later mtime.
        f.write_bytes(b"x" * 200)
        h2 = _compute_mp_book_hash(cfg, str(f))
        assert h1 != h2

    def test_step_order_reorder_changes_hash(self):
        cfg1 = _base_cfg()
        cfg2 = _base_cfg()
        cfg2["preprocessing"]["step_order"] = [
            "trim", "filtering", "chosen_channels", "bad_channels",
            "montage", "mp_decomposition"]
        assert _compute_mp_book_hash(cfg1) != \
               _compute_mp_book_hash(cfg2)


# ── Reading hashs out of fake books ───────────────────────────

class TestReadBookHash:

    def test_read_present(self, tmp_path):
        path = str(tmp_path / "book.db")
        _make_fake_book(path, book_hash="abc123def456")
        assert _read_book_hash(path) == "abc123def456"

    def test_read_legacy_returns_none(self, tmp_path):
        path = str(tmp_path / "book.db")
        _make_fake_book(path, book_hash=None)
        assert _read_book_hash(path) is None

    def test_read_missing_returns_none(self, tmp_path):
        path = str(tmp_path / "nope.db")
        assert _read_book_hash(path) is None

    def test_read_corrupt_returns_none(self, tmp_path):
        """A non-SQLite file should surface as 'no hash', not crash."""
        path = str(tmp_path / "junk.db")
        with open(path, "wb") as f:
            f.write(b"not a database")
        assert _read_book_hash(path) is None


# ── Status classification ────────────────────────────────────────────

class TestBookHashStatus:

    def test_absent(self, tmp_path):
        status, stored = _book_hash_status(
            str(tmp_path / "missing.db"), "expected")
        assert status == "absent"
        assert stored is None

    def test_legacy(self, tmp_path):
        path = str(tmp_path / "book.db")
        _make_fake_book(path, book_hash=None)
        status, stored = _book_hash_status(path, "expected")
        assert status == "legacy"
        assert stored is None

    def test_match(self, tmp_path):
        path = str(tmp_path / "book.db")
        _make_fake_book(path, book_hash="abc")
        status, stored = _book_hash_status(path, "abc")
        assert status == "match"
        assert stored == "abc"

    def test_mismatch(self, tmp_path):
        path = str(tmp_path / "book.db")
        _make_fake_book(path, book_hash="old")
        status, stored = _book_hash_status(path, "new")
        assert status == "mismatch"
        assert stored == "old"


# ── Path resolution ──────────────────────────────────────────────────

class TestResolveExistingBookPath:

    def test_no_directory_returns_none(self, tmp_path):
        assert _resolve_existing_book_path(
            {}, str(tmp_path), "rec.raw") is None

    def test_single_match_returned(self, tmp_path):
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        path = str(mp_dir / "book_rec_smp.db")
        _make_fake_book(path)
        found = _resolve_existing_book_path(
            {}, str(tmp_path), "rec.raw")
        assert found == path

    def test_no_match_returns_none(self, tmp_path):
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        # Different base name.
        _make_fake_book(str(mp_dir / "book_other_smp.db"))
        assert _resolve_existing_book_path(
            {}, str(tmp_path), "rec.raw") is None

    def test_ambiguous_picks_matching_hash(self, tmp_path):
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        wanted = str(mp_dir / "book_rec_smp.db")
        other = str(mp_dir / "book_rec_mmp1.db")
        _make_fake_book(wanted, book_hash="WANT")
        _make_fake_book(other, book_hash="OTHER")
        cfg = {"_mp_book_hash": "WANT"}
        assert _resolve_existing_book_path(
            cfg, str(tmp_path), "rec.raw") == wanted

    def test_ambiguous_no_match_returns_none(self, tmp_path):
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        _make_fake_book(str(mp_dir / "book_rec_smp.db"), book_hash="A")
        _make_fake_book(str(mp_dir / "book_rec_mmp1.db"), book_hash="B")
        cfg = {"_mp_book_hash": "C"}
        assert _resolve_existing_book_path(
            cfg, str(tmp_path), "rec.raw") is None


# ── try_reuse_existing_mp_book — the disabled-step branch ────────────

class TestTryReuseExistingMPBook:

    def _state(self, tmp_path, expected_hash="EXPECTED"):
        # Enable a book consumer so try_reuse_existing_mp_book
        # actually engages — without one the function short-circuits.
        return {
            "config": {
                "_mp_book_hash": expected_hash,
                "prepare_dipole_fitting": True,
            },
            "path": str(tmp_path),
            "file_name": "rec.raw",
        }

    def test_no_book_is_noop(self, tmp_path):
        """Absent book → no error, no _mp_book_path set."""
        state = self._state(tmp_path)
        try_reuse_existing_mp_book(state)
        assert "_mp_book_path" not in state["config"]

    def test_match_sets_mp_book_path(self, tmp_path, caplog):
        """Stamped book matches → reuse silently (info log)."""
        import logging
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        book = str(mp_dir / "book_rec_smp.db")
        _make_fake_book(book, book_hash="EXPECTED")

        state = self._state(tmp_path, expected_hash="EXPECTED")
        with caplog.at_level(logging.INFO):
            try_reuse_existing_mp_book(state)
        assert state["config"]["_mp_book_path"] == book
        assert any("hash match" in r.message
                   for r in caplog.records)

    def test_legacy_warns_and_reuses(self, tmp_path, caplog):
        """Book without stamp → reuse with warning (don't break old users)."""
        import logging
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        book = str(mp_dir / "book_rec_smp.db")
        _make_fake_book(book, book_hash=None)

        state = self._state(tmp_path)
        with caplog.at_level(logging.WARNING):
            try_reuse_existing_mp_book(state)
        assert state["config"]["_mp_book_path"] == book
        assert any("predates this feature" in r.message
                   for r in caplog.records)

    def test_mismatch_raises(self, tmp_path):
        """Different hash → halt; never silently reuse stale."""
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        book = str(mp_dir / "book_rec_smp.db")
        _make_fake_book(book, book_hash="OLD")

        state = self._state(tmp_path, expected_hash="NEW")
        with pytest.raises(RuntimeError, match="different configuration"):
            try_reuse_existing_mp_book(state)
        # _mp_book_path must NOT have leaked through on a mismatch
        assert "_mp_book_path" not in state["config"]

    def test_mismatch_message_contains_actionable_steps(self, tmp_path):
        """Error message must tell the user how to recover."""
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        book = str(mp_dir / "book_rec_smp.db")
        _make_fake_book(book, book_hash="OLD")

        state = self._state(tmp_path, expected_hash="NEW")
        with pytest.raises(RuntimeError) as exc:
            try_reuse_existing_mp_book(state)
        msg = str(exc.value)
        assert "Check the MP decomposition step" in msg
        assert "Restore the upstream parameters" in msg
        assert "OLD" in msg and "NEW" in msg


# ── Channel-presence check on the reuse path ────────────────────────

class TestConsumerChannelCheck:
    """When the existing book matches the MP hash but lacks a
    channel that an enabled downstream consumer needs, halt at preflight
    with an actionable error — not three minutes later inside
    ``eeg_profiles()``."""

    def _state(self, tmp_path, **cfg_extra):
        cfg = {"_mp_book_hash": "MATCH"}
        cfg.update(cfg_extra)
        return {
            "config": cfg,
            "path": str(tmp_path),
            "file_name": "rec.raw",
        }

    def _make_book(self, tmp_path, channels="C3,C4", book_hash="MATCH"):
        mp_dir = tmp_path / "mp_decomposition"
        mp_dir.mkdir()
        book = str(mp_dir / "book_rec_smp.db")
        _make_fake_book(book, book_hash=book_hash, channel_names=channels)
        return book

    def test_required_consumer_channels_eeg_profiles(self):
        cfg = {
            "prepare_eeg_profiles": True,
            "eeg_profiles": {"channel": "Fp1"},
        }
        assert _required_consumer_channels(cfg) == {"EEG Profiles": "Fp1"}

    def test_required_consumer_channels_disabled_skipped(self):
        cfg = {
            "prepare_eeg_profiles": False,
            "eeg_profiles": {"channel": "Fp1"},
        }
        assert _required_consumer_channels(cfg) == {}

    def test_book_channels_present_reuses(self, tmp_path, caplog):
        """Book contains the required channel → reuse silently."""
        import logging
        self._make_book(tmp_path, channels="Fp1,Cz")
        state = self._state(
            tmp_path,
            prepare_eeg_profiles=True,
            eeg_profiles={"channel": "Fp1"})
        with caplog.at_level(logging.INFO):
            try_reuse_existing_mp_book(state)
        assert state["config"].get("_mp_book_path", "").endswith(
            "book_rec_smp.db")

    def test_book_missing_consumer_channel_raises(self, tmp_path):
        """Book doesn't have Fp1, EEG Profiles wants Fp1 → halt."""
        self._make_book(tmp_path, channels="Cz")
        state = self._state(
            tmp_path,
            prepare_eeg_profiles=True,
            eeg_profiles={"channel": "Fp1"})
        with pytest.raises(RuntimeError, match="EEG Profiles needs 'Fp1'"):
            try_reuse_existing_mp_book(state)
        # _mp_book_path must NOT have been set on this branch
        assert "_mp_book_path" not in state["config"]

    def test_book_missing_consumer_channel_message_actionable(self, tmp_path):
        """Error must mention both recovery paths (set channel / rewrite book)."""
        self._make_book(tmp_path, channels="Cz")
        state = self._state(
            tmp_path,
            prepare_eeg_profiles=True,
            eeg_profiles={"channel": "Fp1"})
        with pytest.raises(RuntimeError) as exc:
            try_reuse_existing_mp_book(state)
        msg = str(exc.value)
        assert "Set the analysis channel to one in the book" in msg or \
               "set the analysis channel to one in the book" in msg
        assert "matching_pursuit.channels" in msg
        # Both the book's channel list and the missing one are surfaced
        assert "Cz" in msg
        assert "Fp1" in msg

    def test_consumer_disabled_channel_check_skipped(self, tmp_path):
        """A consumer that doesn't require a named channel (e.g.
        dipole fitting) lets reuse proceed even when another disabled
        consumer's channel isn't in the book."""
        self._make_book(tmp_path, channels="Cz")
        state = self._state(
            tmp_path,
            prepare_eeg_profiles=False,
            eeg_profiles={"channel": "Fp1"},
            prepare_dipole_fitting=True)  # consumer with no channel req
        try_reuse_existing_mp_book(state)
        assert state["config"]["_mp_book_path"].endswith("book_rec_smp.db")

    def test_no_consumers_skips_everything(self, tmp_path, caplog):
        """No enabled book consumers → don't even read the book.

        A run with no MP-consuming analyses should not warn about
        legacy books, raise on mismatches, or set ``_mp_book_path``.
        """
        import logging
        # Legacy book (no hash stamp) — would normally trigger a
        # soft warning, but no consumer is enabled.
        self._make_book(tmp_path, channels="Cz", book_hash=None)
        state = self._state(
            tmp_path,
            prepare_eeg_profiles=False,
            prepare_dipole_fitting=False,
            prepare_mp_filter=False)
        with caplog.at_level(logging.WARNING):
            try_reuse_existing_mp_book(state)
        assert "_mp_book_path" not in state["config"]
        assert not any("predates this feature" in r.message
                       for r in caplog.records), \
            "Should not warn about legacy book when no consumer enabled"

    def test_no_consumers_does_not_raise_on_mismatch(self, tmp_path):
        """Mismatch error must NOT fire when no consumer needs the book."""
        self._make_book(tmp_path, channels="Cz", book_hash="OLD")
        state = self._state(
            tmp_path,
            expected_hash="NEW",
            prepare_eeg_profiles=False,
            prepare_dipole_fitting=False,
            prepare_mp_filter=False)
        # Would raise if any consumer were enabled — must not here.
        try_reuse_existing_mp_book(state)
        assert "_mp_book_path" not in state["config"]

    def test_legacy_book_still_gets_channel_check(self, tmp_path):
        """A book without hash must still pass the channel
        check — otherwise we'd reuse a stale-channel legacy book."""
        # Legacy book = no hash stamp.
        self._make_book(tmp_path, channels="Cz", book_hash=None)
        state = self._state(
            tmp_path,
            prepare_eeg_profiles=True,
            eeg_profiles={"channel": "Fp1"})
        with pytest.raises(RuntimeError, match="EEG Profiles needs 'Fp1'"):
            try_reuse_existing_mp_book(state)

    def test_read_book_channels(self, tmp_path):
        path = str(tmp_path / "book.db")
        _make_fake_book(path, channel_names="Cz, Fp1, Fp2")
        # Whitespace-tolerant; comma-separated.
        assert _read_book_channels(path) == ["Cz", "Fp1", "Fp2"]

    def test_read_book_channels_missing_returns_empty(self, tmp_path):
        assert _read_book_channels(str(tmp_path / "nope.db")) == []


# ── Pinning happens once, before pipeline mutation ───────────────────

class TestHashPinning:
    """The pipeline pins both ``_pipeline_config_hash`` and
    ``_mp_book_hash`` near the top of ``preprocessing()``.
    Verify ``setdefault`` semantics: callers that pre-pin (the GUI's
    truncated-pipeline path) keep their values."""

    def test_setdefault_preserves_pre_pinned(self):
        from ide4eeg.preprocessing.preprocessing import (
            _compute_preprocessing_hash)
        cfg = {"_pipeline_config_hash": "PRE_PINNED",
               "matching_pursuit": {"algorithm": "smp"}}
        # Mimics the line in preprocessing(): setdefault — no-op.
        cfg.setdefault("_pipeline_config_hash",
                       _compute_preprocessing_hash(cfg))
        assert cfg["_pipeline_config_hash"] == "PRE_PINNED"

    def test_setdefault_pins_when_unset(self):
        from ide4eeg.preprocessing.preprocessing import (
            _compute_preprocessing_hash)
        cfg = {"matching_pursuit": {"algorithm": "smp"}}
        cfg.setdefault("_pipeline_config_hash",
                       _compute_preprocessing_hash(cfg))
        assert cfg["_pipeline_config_hash"]
        assert isinstance(cfg["_pipeline_config_hash"], str)
