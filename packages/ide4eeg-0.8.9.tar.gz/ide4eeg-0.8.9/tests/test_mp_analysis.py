"""Tests for Matching Pursuit analysis pure functions.

Covers:
- gabor(): Gabor atom generation
- filter_atoms(): atom filtering by FASP criteria
- _has_reconstruction_criteria(): filter predicate
- reconstruct_signal(): signal reconstruction from atoms
"""

import numpy as np
import pytest

from ide4eeg.analysis.mp_analysis import (
    gabor,
    filter_atoms,
    _has_reconstruction_criteria,
    _describe_criteria,
    reconstruct_signal,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_atom(**overrides):
    """Create a test atom dict with sensible defaults."""
    atom = {
        "f_Hz": 10.0,
        "t0_s": 0.5,
        "scale_s": 0.1,
        "amplitude": 1.0,
        "phase": 0.0,
        "energy": 0.5,
        "iteration": 0,
    }
    atom.update(overrides)
    return atom


# ---------------------------------------------------------------------------
# gabor
# ---------------------------------------------------------------------------

class TestGabor:
    def test_peak_at_center(self):
        """Gabor should peak at t0."""
        t = np.linspace(0, 1, 1000)
        y = gabor(t, 1.0, 0.5, 10.0, 0.1, phase=0.0)
        peak_idx = np.argmax(np.abs(y))
        assert abs(t[peak_idx] - 0.5) < 0.01

    def test_zero_amplitude(self):
        t = np.linspace(0, 1, 100)
        y = gabor(t, 0.0, 0.5, 10.0, 0.1)
        np.testing.assert_array_equal(y, 0.0)

    def test_gaussian_envelope_shape(self):
        """Envelope should decay away from center."""
        t = np.linspace(0, 1, 1000)
        y = gabor(t, 1.0, 0.5, 0.0, 0.1, phase=0.0)
        # At f=0, gabor = amplitude * exp(...) * cos(0) = pure Gaussian
        assert np.abs(y[0]) < np.abs(y[500])  # edge < center

    def test_symmetry(self):
        """Gabor should be symmetric around t0 for zero phase."""
        t = np.linspace(-1, 1, 1001)
        y = gabor(t, 1.0, 0.0, 10.0, 0.2, phase=0.0)
        # Cosine is even → gabor(t0+dt) == gabor(t0-dt)
        # 1001 points: center is index 500, left=[:500], right=[501:]
        np.testing.assert_allclose(y[:500], y[501:][::-1], atol=1e-12)

    def test_correct_frequency(self):
        """Peak of FFT should be near f0."""
        sfreq = 1000
        t = np.arange(4 * sfreq) / sfreq
        y = gabor(t, 1.0, 2.0, 25.0, 0.5, phase=0.0)
        fft = np.abs(np.fft.rfft(y))
        freqs = np.fft.rfftfreq(len(y), 1.0 / sfreq)
        peak_freq = freqs[np.argmax(fft)]
        assert abs(peak_freq - 25.0) < 1.0


# ---------------------------------------------------------------------------
# filter_atoms
# ---------------------------------------------------------------------------

class TestFilterAtoms:
    def test_no_filter(self):
        atoms = [make_atom(f_Hz=5), make_atom(f_Hz=15)]
        result = filter_atoms(atoms, {})
        assert len(result) == 2

    def test_freq_min(self):
        atoms = [make_atom(f_Hz=5), make_atom(f_Hz=15)]
        result = filter_atoms(atoms, {"freq_min": 10})
        assert len(result) == 1
        assert result[0]["f_Hz"] == 15

    def test_freq_max(self):
        atoms = [make_atom(f_Hz=5), make_atom(f_Hz=15)]
        result = filter_atoms(atoms, {"freq_max": 10})
        assert len(result) == 1
        assert result[0]["f_Hz"] == 5

    def test_time_range(self):
        atoms = [make_atom(t0_s=0.1), make_atom(t0_s=0.5),
                 make_atom(t0_s=0.9)]
        result = filter_atoms(atoms, {"time_min": 0.2, "time_max": 0.8})
        assert len(result) == 1
        assert result[0]["t0_s"] == 0.5

    def test_min_energy(self):
        atoms = [make_atom(energy=0.1), make_atom(energy=1.0)]
        result = filter_atoms(atoms, {"min_energy": 0.5})
        assert len(result) == 1
        assert result[0]["energy"] == 1.0

    def test_max_iterations(self):
        atoms = [make_atom(iteration=0), make_atom(iteration=5),
                 make_atom(iteration=10)]
        result = filter_atoms(atoms, {"max_iterations": 5})
        # iteration >= max_iterations is excluded (0-indexed)
        assert len(result) == 1
        assert result[0]["iteration"] == 0

    def test_combined_filters(self):
        atoms = [
            make_atom(f_Hz=5, energy=0.1),
            make_atom(f_Hz=15, energy=0.1),
            make_atom(f_Hz=5, energy=1.0),
            make_atom(f_Hz=15, energy=1.0),
        ]
        result = filter_atoms(atoms, {"freq_min": 10, "min_energy": 0.5})
        assert len(result) == 1
        assert result[0]["f_Hz"] == 15 and result[0]["energy"] == 1.0

    def test_empty_atoms(self):
        assert filter_atoms([], {"freq_min": 10}) == []

    def test_zero_means_no_filter(self):
        """Zero values for filter criteria should mean no filtering."""
        atoms = [make_atom(f_Hz=1)]
        result = filter_atoms(atoms, {
            "freq_min": 0, "freq_max": 0,
            "time_min": 0, "time_max": 0,
            "min_energy": 0, "max_iterations": 0,
            "amp_min": 0, "amp_max": 0,
            "scale_min": 0, "scale_max": 0})
        assert len(result) == 1

    def test_amp_p2p_convention(self):
        """``amp_min``/``amp_max`` are peak-to-peak µV.

        Atom envelope amplitude 5 µV → p2p 10 µV.  A floor of 12 µV
        should reject; a floor of 8 µV should keep.  scale_uV=1.0
        means the book already stores amplitude in µV.
        """
        atoms = [make_atom(amplitude=5.0)]
        assert filter_atoms(atoms, {"amp_min": 12}, scale_uV=1.0) == []
        result = filter_atoms(atoms, {"amp_min": 8}, scale_uV=1.0)
        assert len(result) == 1

    def test_amp_max_p2p_convention(self):
        """Atom envelope 5 µV → p2p 10 µV.  Cap at 8 µV rejects, 12
        µV keeps."""
        atoms = [make_atom(amplitude=5.0)]
        assert filter_atoms(atoms, {"amp_max": 8}, scale_uV=1.0) == []
        result = filter_atoms(atoms, {"amp_max": 12}, scale_uV=1.0)
        assert len(result) == 1

    def test_amp_default_scale_uV_is_volts(self):
        """Default scale_uV=1e6: book amplitude in V, criteria in µV."""
        atoms = [make_atom(amplitude=5e-6)]  # 5 µV envelope = 10 µV p2p
        assert filter_atoms(atoms, {"amp_min": 12}) == []
        result = filter_atoms(atoms, {"amp_min": 8})
        assert len(result) == 1

    def test_scale_range(self):
        atoms = [make_atom(scale_s=0.05), make_atom(scale_s=0.5),
                 make_atom(scale_s=4.0)]
        result = filter_atoms(atoms, {"scale_min": 0.1, "scale_max": 3.5})
        assert len(result) == 1
        assert result[0]["scale_s"] == 0.5


# ---------------------------------------------------------------------------
# _has_reconstruction_criteria
# ---------------------------------------------------------------------------

class TestHasReconstructionCriteria:
    def test_empty(self):
        assert not _has_reconstruction_criteria({})

    def test_none(self):
        assert not _has_reconstruction_criteria(None)

    def test_all_zero(self):
        assert not _has_reconstruction_criteria({
            "freq_min": 0, "freq_max": 0, "min_energy": 0})

    def test_freq_min_set(self):
        assert _has_reconstruction_criteria({"freq_min": 5})

    def test_max_iterations_set(self):
        assert _has_reconstruction_criteria({"max_iterations": 100})


# ---------------------------------------------------------------------------
# _describe_criteria
# ---------------------------------------------------------------------------

class TestDescribeCriteria:
    def test_empty(self):
        desc = _describe_criteria({})
        assert isinstance(desc, str)

    def test_freq_min(self):
        desc = _describe_criteria({"freq_min": 5})
        assert "5" in desc

    def test_multiple(self):
        desc = _describe_criteria({"freq_min": 5, "freq_max": 30})
        assert "5" in desc and "30" in desc


# ---------------------------------------------------------------------------
# reconstruct_signal
# ---------------------------------------------------------------------------

class TestReconstructSignal:
    def test_empty_atoms(self):
        result = reconstruct_signal([], 100, 256.0)
        np.testing.assert_array_equal(result, np.zeros(100))

    def test_single_atom_nonzero(self):
        atoms = [{"f_Hz": 10, "t0_s": 0.25, "scale_s": 0.05,
                  "amplitude": 1.0, "phase": 0.0}]
        result = reconstruct_signal(atoms, 128, 256.0)
        assert result.shape == (128,)
        assert np.max(np.abs(result)) > 0

    def test_two_atoms_superpose(self):
        atom1 = {"f_Hz": 10, "t0_s": 0.1, "scale_s": 0.05,
                 "amplitude": 1.0, "phase": 0.0}
        atom2 = {"f_Hz": 20, "t0_s": 0.3, "scale_s": 0.05,
                 "amplitude": 1.0, "phase": 0.0}
        r1 = reconstruct_signal([atom1], 128, 256.0)
        r2 = reconstruct_signal([atom2], 128, 256.0)
        r_both = reconstruct_signal([atom1, atom2], 128, 256.0)
        np.testing.assert_allclose(r_both, r1 + r2, atol=1e-12)
