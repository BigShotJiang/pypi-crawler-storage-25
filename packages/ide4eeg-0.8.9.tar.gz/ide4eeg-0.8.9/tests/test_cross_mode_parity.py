"""Validator-warning bug-class locks.

The GUI's internal serialize-deserialize cycle must not emit spurious
validator warnings.  Before commit ``9f596e1`` (on this branch; was
``92a0be6`` pre-rebase), ``ide4eeg.config_schema`` was hooked into
both ``gui_config.load_toml`` AND ``input.input.read_config_file``.
The latter is shared between user-facing CLI loads and the GUI's
internal cfg → dump_toml → tempfile → main.main cycle, turning
validation that's appropriate on user input into spam noise on the
runner's serialized snapshot.  Fix: skip validation when the cfg
carries any ``_pipeline_*`` pin.

Symmetric test: a user-facing load WITHOUT the pin must still
surface dead-key warnings.

Both tests use synthetic TOMLs in ``tmp_path`` instead of the shipped
simulated_data example (dropped on main in 76a6373).  This makes the
tests run on every checkout, not just ones that happen to have
example data downloaded.

A run_file ↔ batch path parity test (cfg-dict equality) used to
live here but produced false positives — DEFAULT_CONFIG and the
internal defaults inside ``check_and_prepare_config`` disagree on
unused sub-section keys, in a way the runtime pipeline tolerates
via ``cfg.get(...)`` fallbacks.  The actual run_file output is
locked by ``tests/test_pipeline_golden.py``; the batch path can
diverge from run_file in unimportant ways without being a bug.
"""
from __future__ import annotations

import logging


# ── End-to-end log assertion (validator-warning bug-class lock) ──

def test_gui_internal_cycle_emits_no_validator_warnings(caplog, tmp_path):
    """GUI dumps cfg to a tempfile and the runner reads it back.

    Mimic the cycle with a minimal-but-realistic cfg.  Pin the hash to
    mark this as a runtime snapshot — the validator must skip on the
    pinned cycle.  If the gate regresses, this test fails.
    """
    from ide4eeg.gui_config import DEFAULT_CONFIG, dump_toml, load_toml
    from ide4eeg.input.input import read_config_file

    user_toml = tmp_path / "user.toml"
    user_toml.write_text(
        'input_path = "nope.fif"\n'
        'segmentation = { mode = "rest" }\n'
        'resample_freq = 128\n'
    )

    cfg = load_toml(str(user_toml))
    # Ensure cfg has the full DEFAULT_CONFIG shape so dump→read is a
    # realistic runner cycle, not a sparse-cfg corner case.
    for k, v in DEFAULT_CONFIG.items():
        cfg.setdefault(k, v)
    # Mimic gui.py — pin the hash to mark this as a runtime snapshot.
    cfg["_pipeline_config_hash"] = "stub-hash-for-test"

    runtime_toml = tmp_path / "runtime.toml"
    dump_toml(cfg, str(runtime_toml))

    caplog.clear()  # scope the assertion to just the runtime cycle
    with caplog.at_level(logging.WARNING, logger="ide4eeg.config_schema"):
        read_config_file(str(runtime_toml))

    schema_warnings = [
        r for r in caplog.records
        if r.name == "ide4eeg.config_schema"
        and r.levelno >= logging.WARNING
    ]
    assert not schema_warnings, (
        "Runtime-serialized cfg triggered validator warnings:\n  "
        + "\n  ".join(r.message for r in schema_warnings))


def test_user_facing_load_DOES_emit_warnings_on_dead_keys(caplog, tmp_path):
    """Symmetric to the previous test: a user-facing load WITHOUT
    the ``_pipeline_*`` pin must still surface dead-key warnings.

    Validator's job is to flag deferred / removed keys at user-facing
    load time.  This test prevents an over-broad "skip everything"
    workaround that would silence the warning the validator was
    designed to emit.
    """
    from ide4eeg.gui_config import load_toml

    dead_cfg = tmp_path / "dead_keys.toml"
    dead_cfg.write_text(
        'input_path = "nope.fif"\n'
        'segmentation = { mode = "rest" }\n'
        'prepare_frequency_analysis = true\n'
        'prepare_statistics = true\n'
        'prepare_tf_statistics = true\n'
    )

    with caplog.at_level(logging.WARNING, logger="ide4eeg.config_schema"):
        load_toml(str(dead_cfg))

    msgs = [r.message for r in caplog.records
            if r.name == "ide4eeg.config_schema"]
    assert any("prepare_frequency_analysis" in m for m in msgs), msgs
    assert any("prepare_statistics" in m for m in msgs), msgs
    assert any("prepare_tf_statistics" in m for m in msgs), msgs


