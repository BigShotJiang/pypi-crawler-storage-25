"""Regression tests for step-snapshot staleness detection.

These exist because three session-local bugs in a row (2026-04-23)
shipped without being caught by the broader test suite:

  1. deepcopy of bound method (fix: 40bb9f2)
  2. hash drift from auto-detected bads appended to
     choosing_channels during the bad_channels step (fix: e7a302d)
  3. hash drift from the scratch-config truncation inside
     _run_truncated_pipeline (fix: 01c9028)

Each of these resulted in the eye-button "run to step, open viewer"
flow looping forever because the hash stored in saved-step FIFs
didn't match the hash recomputed at view time.  The existing
tests/test_view_step_result.py fixtures bypass the hash check via
monkeypatch, so they can't catch this class of bug.

The hash regime moved from a single whole-config blake2b digest to
per-step cumulative hashes (Merkle-style chain over step_order).
``_pipeline_step_hashes`` is the new pinning surface; the legacy
``_pipeline_config_hash`` is retained only as a fallback used by
``_compute_mp_book_hash`` and other callers that need a single
coarse digest.

What we test here:
  * _compute_preprocessing_hash is deterministic
  * _compute_step_hash is deterministic and chain-sensitive
  * Pipeline-side mutations of hashed sections change the live
    hash (evidence that preserving a pre-pipeline hash matters)
  * _save_step_signal_if_requested respects a pre-pinned
    _pipeline_step_hashes entry — it writes that value into the
    FIF's info['description'], NOT a live recompute of the
    (possibly mutated) config.
  * A real FIF round-trip: write the snapshot with one hash,
    read back via mne.io.read_info, extract and match.
"""

import os

import mne
import numpy as np

from ide4eeg.preprocessing.preprocessing import (
    _compute_preprocessing_hash,
    _compute_step_hash,
    _compute_step_hashes,
    _save_step_signal_if_requested,
    _STEP_SAVE_MAP,
)


def _base_cfg():
    """Minimal config with a couple of _HASHED_CONFIG_KEYS populated."""
    return {
        "preprocessing": {
            "step_order": ["trim", "bad_channels", "montage"],
            "allow_reorder": False,
        },
        "trim_start": 0.0,
        "trim_end": 10.0,
        "choosing_channels": {
            "bad_channels": [],
            "choose_bad_channels": "manual",
            "save": True,
        },
        "bad_channels": {"save": True},
        "segmentation": {"mode": "rest"},
        "rest": {"window_length": 10, "rest_duration": [0, ""]},
        "filters": {"highpass_freq": 1.0, "lowpass_freq": 40.0},
    }


def _make_state(cfg, tmp_path):
    """Build the ``state`` dict that _save_step_signal_if_requested wants."""
    info = mne.create_info(["C3", "C4", "Cz"], 128, ["eeg"] * 3)
    raw = mne.io.RawArray(np.zeros((3, 128)), info, verbose=False)
    return {
        "signal": raw,
        "config": cfg,
        "path": str(tmp_path),
        "file_name": "signal.fif",
    }


# ── _compute_preprocessing_hash ─────────────────────────────────────


def test_hash_is_deterministic():
    """Same config in → same hash out, across repeated calls."""
    cfg = _base_cfg()
    h1 = _compute_preprocessing_hash(cfg)
    h2 = _compute_preprocessing_hash(cfg)
    assert h1 == h2


def test_hash_ignores_underscore_prefixed_keys():
    """Runtime-injected keys (_manual_hooks, _input_dir, ...) don't
    perturb the hash — they're not in _HASHED_CONFIG_KEYS."""
    cfg = _base_cfg()
    baseline = _compute_preprocessing_hash(cfg)
    cfg["_manual_hooks"] = {"bad_channels": lambda *a, **kw: []}
    cfg["_input_file_name"] = "whatever.raw"
    cfg["_pipeline_config_hash"] = "not-relevant-for-self-hashing"
    assert _compute_preprocessing_hash(cfg) == baseline


def test_hash_changes_when_user_changes_settings():
    """The check that catches real staleness — different hashed
    section → different hash."""
    cfg = _base_cfg()
    before = _compute_preprocessing_hash(cfg)
    cfg["filters"]["lowpass_freq"] = 30.0
    after = _compute_preprocessing_hash(cfg)
    assert before != after


def test_hash_drifts_when_pipeline_mutates_choosing_channels():
    """This is the exact shape of bug #2: the bad_channels step
    appends auto-detected channels to choosing_channels.bad_channels
    during the run.  A live recompute BEFORE vs AFTER the mutation
    produces different hashes.  Pre-pinning (tested below) is the
    workaround."""
    cfg = _base_cfg()
    before = _compute_preprocessing_hash(cfg)
    cfg["choosing_channels"]["bad_channels"].extend(["Fp1", "Fp2"])
    after = _compute_preprocessing_hash(cfg)
    assert before != after


def test_hash_drifts_when_step_order_truncated():
    """This is the exact shape of bug #3: _run_truncated_pipeline
    slices step_order at the target step.  A live recompute on the
    truncated config differs from the user's full-GUI hash."""
    cfg = _base_cfg()
    full_hash = _compute_preprocessing_hash(cfg)
    cfg["preprocessing"]["step_order"] = ["trim", "bad_channels"]  # truncated
    truncated_hash = _compute_preprocessing_hash(cfg)
    assert full_hash != truncated_hash


# ── _compute_step_hash (per-step cumulative chain) ──────────────────


def _step_order_cfg():
    """Config exercising trim / resample / bad_channels / filtering
    in a known order — the canonical step_order for chain tests."""
    return {
        "preprocessing": {
            "step_order": ["trim", "resample", "bad_channels",
                           "filtering"],
        },
        "trim_start": 0.0,
        "trim_end": 10.0,
        "resample_freq": 128,
        "choosing_channels": {"bad_channels": []},
        "bad_channels": {},
        "filters": {"highpass_freq": 1.0, "lowpass_freq": 40.0},
    }


def test_step_hash_is_deterministic():
    cfg = _step_order_cfg()
    order = cfg["preprocessing"]["step_order"]
    h1 = _compute_step_hash("filtering", cfg, order)
    h2 = _compute_step_hash("filtering", cfg, order)
    assert h1 == h2 and h1


def test_step_hash_chain_differs_per_step():
    """step_hash(filtering) != step_hash(trim) even when filters
    config is unchanged — because the cumulative chain folds the
    upstream step's hash into each step's digest."""
    cfg = _step_order_cfg()
    order = cfg["preprocessing"]["step_order"]
    trim_h = _compute_step_hash("trim", cfg, order)
    filt_h = _compute_step_hash("filtering", cfg, order)
    assert trim_h != filt_h
    # And every pair distinct, since each consumes a different
    # config slice on top of distinct upstream chains.
    resample_h = _compute_step_hash("resample", cfg, order)
    bc_h = _compute_step_hash("bad_channels", cfg, order)
    assert len({trim_h, resample_h, bc_h, filt_h}) == 4


def test_step_hash_granular_invalidation():
    """Editing a downstream-only key changes that step's hash and
    every downstream step's hash, but NOT upstream steps' hashes.

    This is the core property that makes per-step hashing useful:
    editing ``filters.lowpass_freq`` invalidates the filtering
    snapshot but leaves trim/resample snapshots fresh.
    """
    cfg = _step_order_cfg()
    order = cfg["preprocessing"]["step_order"]
    before = {s: _compute_step_hash(s, cfg, order) for s in order}

    cfg["filters"]["lowpass_freq"] = 30.0
    after = {s: _compute_step_hash(s, cfg, order) for s in order}

    # Upstream of filtering — unchanged.
    for s in ("trim", "resample", "bad_channels"):
        assert before[s] == after[s], \
            f"upstream step {s} hash drifted on a downstream-only edit"
    # Filtering itself — different.
    assert before["filtering"] != after["filtering"]


def test_step_hash_reorder_sensitivity():
    """Swapping the order of two steps must change BOTH their
    cumulative hashes — they have different upstream chains in the
    swapped order, so even with identical config the digests
    differ."""
    cfg = _step_order_cfg()
    order_orig = ["trim", "resample", "bad_channels", "filtering"]
    order_swapped = ["trim", "bad_channels", "resample", "filtering"]

    cfg["preprocessing"]["step_order"] = order_orig
    h_resample_orig = _compute_step_hash("resample", cfg, order_orig)
    h_bc_orig = _compute_step_hash("bad_channels", cfg, order_orig)

    cfg["preprocessing"]["step_order"] = order_swapped
    h_resample_swapped = _compute_step_hash(
        "resample", cfg, order_swapped)
    h_bc_swapped = _compute_step_hash(
        "bad_channels", cfg, order_swapped)

    assert h_resample_orig != h_resample_swapped
    assert h_bc_orig != h_bc_swapped


def test_step_hash_multi_instance_isolation():
    """Editing one filter block's config must not perturb a
    *parallel* filter block's per-step hash — isolation guaranteed
    by ``_step_relevant_subset``'s per-id slicing.

    The relevant direction is upstream: filtering:b is downstream
    of filtering:a in the chain, so editing filtering:a invalidates
    filtering:b too (correct — filtering:b's input signal differs).
    The isolation we test here is the OTHER direction: editing
    filtering:b must not change filtering:a's hash, since
    filtering:a's subset doesn't include ``filters[b]`` and
    filtering:a's upstream chain doesn't include filtering:b.
    """
    def _cfg():
        return {
            "preprocessing": {
                "step_order": ["trim", "filtering:a", "filtering:b"],
            },
            "trim_start": 0.0,
            "trim_end": 10.0,
            "filters": {
                "a": {"highpass_freq": 1.0, "lowpass_freq": 40.0},
                "b": {"highpass_freq": 0.5, "lowpass_freq": 20.0},
            },
        }

    cfg = _cfg()
    order = cfg["preprocessing"]["step_order"]
    a_baseline = _compute_step_hash("filtering:a", cfg, order)
    b_baseline = _compute_step_hash("filtering:b", cfg, order)

    # Edit block B — the parallel block, downstream of A.
    cfg["filters"]["b"]["lowpass_freq"] = 15.0
    a_after_b_edit = _compute_step_hash("filtering:a", cfg, order)
    b_after_b_edit = _compute_step_hash("filtering:b", cfg, order)

    # Isolation: B's edit must not perturb A's hash.
    assert a_baseline == a_after_b_edit, \
        "editing filter block B perturbed filter block A's hash"
    # B itself is correctly invalidated.
    assert b_baseline != b_after_b_edit

    # The other direction: editing A invalidates both A and B
    # (downstream invalidation is intentional).
    cfg = _cfg()
    a_baseline = _compute_step_hash("filtering:a", cfg, order)
    b_baseline = _compute_step_hash("filtering:b", cfg, order)
    cfg["filters"]["a"]["lowpass_freq"] = 35.0
    assert _compute_step_hash("filtering:a", cfg, order) != a_baseline
    assert _compute_step_hash("filtering:b", cfg, order) != b_baseline


def test_step_hashes_dict_covers_step_order():
    cfg = _step_order_cfg()
    order = cfg["preprocessing"]["step_order"]
    hashes = _compute_step_hashes(cfg, order)
    assert set(hashes) == set(order)
    # And matches the per-step computation.
    for s in order:
        assert hashes[s] == _compute_step_hash(s, cfg, order)


# ── _save_step_signal_if_requested: hash-pinning contract ──────────


def test_save_uses_pinned_hash_when_provided(tmp_path):
    """The fix from 01c9028: when the GUI has pre-pinned
    _pipeline_step_hashes, the saved FIF's description carries that
    exact value — NOT a live recompute off the (mutated) config."""
    cfg = _base_cfg()
    pinned = "deadbeefcafebabe"  # sentinel, not a real hash
    cfg["_pipeline_step_hashes"] = {"bad_channels": pinned}
    # Simulate auto-detection mutating the config AFTER the GUI
    # pinned its hash.
    cfg["choosing_channels"]["bad_channels"].extend(["Fp1", "Fp2"])

    state = _make_state(cfg, tmp_path)
    _save_step_signal_if_requested(state, "bad_channels")

    suffix = _STEP_SAVE_MAP["bad_channels"][1]
    out = tmp_path / "saved_steps" / f"signal-{suffix}-raw.fif"
    assert out.is_file()

    info = mne.io.read_info(str(out), verbose=False)
    desc = info.get("description") or ""
    assert f"[cfg:{pinned}]" in desc, \
        f"expected pinned hash in description, got {desc!r}"


def test_save_falls_back_to_live_hash_without_pin(tmp_path):
    """run_file() programmatic callers don't set _pipeline_step_hashes;
    in that case the save function recomputes from the live config —
    using the per-step cumulative hash for the saved step."""
    cfg = _base_cfg()
    expected = _compute_step_hash(
        "bad_channels", cfg, cfg["preprocessing"]["step_order"])
    state = _make_state(cfg, tmp_path)
    _save_step_signal_if_requested(state, "bad_channels")

    suffix = _STEP_SAVE_MAP["bad_channels"][1]
    out = tmp_path / "saved_steps" / f"signal-{suffix}-raw.fif"
    info = mne.io.read_info(str(out), verbose=False)
    desc = info.get("description") or ""
    assert f"[cfg:{expected}]" in desc


def test_save_pinned_survives_simulated_truncation(tmp_path):
    """The exact scenario from bug #3: scratch config built by
    _run_truncated_pipeline has truncated step_order + disabled
    analyses, but carries the user-level per-step hash dict pinned
    from BEFORE the mutations.  When _save_step_signal_if_requested
    runs from within that truncated pipeline, the written description
    still contains the user-level per-step hash — which is what
    _view_step_result will look for at view time.

    Per-step hashes are computed against the user's full step_order;
    because the truncated order is a strict prefix, both the runner
    inside the truncated pipeline and the user-side viewer agree on
    the hash for any step in the truncated range.
    """
    user_cfg = _base_cfg()
    user_hashes = _compute_step_hashes(
        user_cfg, user_cfg["preprocessing"]["step_order"])
    user_bc_hash = user_hashes["bad_channels"]

    # _run_truncated_pipeline's scratch config: truncated step_order,
    # forced saves, user-level hashes pinned BEFORE these mutations.
    scratch = _base_cfg()
    scratch["_pipeline_step_hashes"] = user_hashes
    scratch["preprocessing"]["step_order"] = ["trim", "bad_channels"]

    state = _make_state(scratch, tmp_path)
    _save_step_signal_if_requested(state, "bad_channels")

    suffix = _STEP_SAVE_MAP["bad_channels"][1]
    out = tmp_path / "saved_steps" / f"signal-{suffix}-raw.fif"
    info = mne.io.read_info(str(out), verbose=False)
    desc = info.get("description") or ""
    # The saved snapshot carries the USER-level per-step hash, not
    # the hash a live recompute off `scratch` would produce.
    scratch_bc_hash = _compute_step_hash(
        "bad_channels", scratch, scratch["preprocessing"]["step_order"])
    assert f"[cfg:{user_bc_hash}]" in desc
    # Sanity: the truncated step_order makes "preprocessing"
    # subsection differ between user_cfg and scratch, so the chain
    # produces different per-step hashes.
    assert user_bc_hash != scratch_bc_hash


def test_save_is_skipped_when_save_flag_off(tmp_path):
    """The existing ``cfg[section].save`` gate still wins over the
    hash plumbing — no flag, no file."""
    cfg = _base_cfg()
    cfg["bad_channels"]["save"] = False
    state = _make_state(cfg, tmp_path)
    _save_step_signal_if_requested(state, "bad_channels")
    suffix = _STEP_SAVE_MAP["bad_channels"][1]
    out = tmp_path / "saved_steps" / f"signal-{suffix}-raw.fif"
    assert not out.exists()


# ── Freshness check: skip overwrite when hash already matches ───────


def test_save_skips_overwrite_when_existing_hash_matches(tmp_path):
    """Second save with identical pinned hash is a no-op on disk.

    Avoids rewriting hundreds of MB of FIF data across runs where
    only downstream-of-this-step config changed.
    """
    cfg = _base_cfg()
    cfg["_pipeline_step_hashes"] = {"bad_channels": "fe541f00d0000001"}
    state = _make_state(cfg, tmp_path)
    _save_step_signal_if_requested(state, "bad_channels")

    suffix = _STEP_SAVE_MAP["bad_channels"][1]
    out = tmp_path / "saved_steps" / f"signal-{suffix}-raw.fif"
    assert out.is_file()
    mtime_before = out.stat().st_mtime_ns

    # Second call with same pinned hash → should be a no-op.  We check
    # that mtime_ns is identical, not "newer" — a real write updates
    # mtime_ns even sub-millisecond.
    _save_step_signal_if_requested(state, "bad_channels")
    mtime_after = out.stat().st_mtime_ns
    assert mtime_before == mtime_after, \
        "file was rewritten despite matching hash"


def test_save_overwrites_when_existing_hash_differs(tmp_path):
    """A stale snapshot (different hash) gets replaced."""
    cfg = _base_cfg()
    cfg["_pipeline_step_hashes"] = {"bad_channels": "5ca1eb1e00000001"}
    state = _make_state(cfg, tmp_path)
    _save_step_signal_if_requested(state, "bad_channels")

    suffix = _STEP_SAVE_MAP["bad_channels"][1]
    out = tmp_path / "saved_steps" / f"signal-{suffix}-raw.fif"
    assert out.is_file()

    # Change the pinned hash → next save must overwrite.
    cfg["_pipeline_step_hashes"] = {"bad_channels": "f8e5800000000002"}
    _save_step_signal_if_requested(state, "bad_channels")

    info = mne.io.read_info(str(out), verbose=False)
    desc = info.get("description") or ""
    assert "[cfg:f8e5800000000002]" in desc
    assert "[cfg:5ca1eb1e00000001]" not in desc


def test_save_overwrites_corrupt_existing_file(tmp_path):
    """An unreadable existing file at the target path must not block
    the save — fall through to the normal overwrite."""
    cfg = _base_cfg()
    cfg["_pipeline_step_hashes"] = {"bad_channels": "f8e5800000000003"}
    suffix = _STEP_SAVE_MAP["bad_channels"][1]
    out_dir = tmp_path / "saved_steps"
    out_dir.mkdir()
    corrupt = out_dir / f"signal-{suffix}-raw.fif"
    corrupt.write_text("definitely not a FIF")

    state = _make_state(cfg, tmp_path)
    _save_step_signal_if_requested(state, "bad_channels")

    info = mne.io.read_info(str(corrupt), verbose=False)
    desc = info.get("description") or ""
    assert "[cfg:f8e5800000000003]" in desc


# ── Regression for bug 1: bound-method-in-config deepcopy ───────────


def test_manual_hooks_must_be_plain_functions_not_bound_methods():
    """Catches the shape of the initial Svarog-review bug: a bound
    method placed in config deep-copies its __self__, which is the
    QMainWindow — unpicklable.

    This test is a guard rail: if anyone again writes
    ``cfg["_manual_hooks"] = {"bad_channels": self._something}``,
    the test fails.  The safe pattern is wrapping the bound method
    in a local ``def`` so deepcopy sees a plain function (treated
    as a leaf — closure cells aren't walked).
    """
    import copy

    class _FakeQMainWindow:
        """Mimics the deepcopy-unfriendly aspect of Qt windows: a
        __reduce_ex__ that raises.  Real Qt does this via its C++
        state; we simulate just enough to trigger the same
        TypeError."""
        def __reduce_ex__(self, protocol):
            raise TypeError(
                "cannot pickle '_FakeQMainWindow' object")

        def _bound(self, a, b):
            return a + b

    fake = _FakeQMainWindow()

    # The UNSAFE pattern: bound method in config.
    unsafe_cfg = {"_manual_hooks": {"bad_channels": fake._bound},
                  "other": "stuff"}
    try:
        copy.deepcopy(unsafe_cfg)
    except TypeError as e:
        assert "pickle" in str(e).lower()
    else:
        raise AssertionError(
            "deepcopy of bound method in config should have raised")

    # The SAFE pattern: wrap in a plain closure.
    def _hook(a, b):
        return fake._bound(a, b)

    safe_cfg = {"_manual_hooks": {"bad_channels": _hook},
                "other": "stuff"}
    copied = copy.deepcopy(safe_cfg)  # must not raise
    assert copied["_manual_hooks"]["bad_channels"](1, 2) == 3
