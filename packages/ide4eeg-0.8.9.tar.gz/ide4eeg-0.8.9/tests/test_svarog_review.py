"""Tests for ide4eeg.preprocessing.svarog_review.

The real Svarog subprocess isn't runnable from tests, so we
monkey-patch ``subprocess_runner`` with a fake that either writes
a canned tag file and returns exit 0 (success) or simulates
cancel / timeout / corrupt output.
"""

import os
import subprocess
import warnings

import mne
import numpy as np
import pytest

from ide4eeg.preprocessing import svarog_review

# FastICA on unfiltered white noise (the minimal test fixture) doesn't
# converge and MNE warns about missing high-pass filter — ignore the
# noise so it doesn't pollute CI output.
pytestmark = [
    pytest.mark.filterwarnings("ignore:.*FastICA did not converge"),
    pytest.mark.filterwarnings(
        "ignore:.*data has not been high-pass filtered"),
]


def _make_raw(ch_names=("Fp1", "Fp2", "Cz", "O1"), sfreq=128, dur=4.0):
    """Minimal Raw for review tests — small enough to save quickly."""
    n_samples = int(sfreq * dur)
    data = np.random.randn(len(ch_names), n_samples) * 1e-6
    info = mne.create_info(list(ch_names), sfreq, ["eeg"] * len(ch_names))
    return mne.io.RawArray(data, info, verbose=False)


def _fake_svarog_writes(output_path, bad_channels, all_ch_names, rc=0):
    """Return a subprocess_runner that writes *bad_channels* to
    the ``--output`` path and returns exit *rc*."""

    def runner(cmd, timeout=None, check=False):
        # Find --output and --preselect args
        out_idx = cmd.index("--output")
        out_path = cmd[out_idx + 1]
        # Verify the signal path was passed
        assert cmd[0].endswith("java") or cmd[0] == "java"
        assert "--select-mode" in cmd
        assert cmd[cmd.index("--select-mode") + 1] == "bad_channels"
        # Write the canned selection
        svarog_review._write_channel_tag_file(
            out_path, bad_channels, all_ch_names)
        return subprocess.CompletedProcess(cmd, rc)

    return runner


def _fake_svarog_cancels(rc=1):
    """Runner that returns non-zero without writing output."""

    def runner(cmd, timeout=None, check=False):
        return subprocess.CompletedProcess(cmd, rc)

    return runner


def _fake_svarog_timeouts():
    """Runner that raises TimeoutExpired."""

    def runner(cmd, timeout=None, check=False):
        raise subprocess.TimeoutExpired(cmd, timeout or 10)

    return runner


# ── Tests ───────────────────────────────────────────────────────────


def test_returns_user_selection_on_success(tmp_path):
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")  # path just has to exist
    runner = _fake_svarog_writes(
        None, ["Fp1", "O1"], raw.info["ch_names"])

    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar), subprocess_runner=runner)

    assert result == ["Fp1", "O1"]


def test_returns_none_on_cancel(tmp_path):
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar), subprocess_runner=_fake_svarog_cancels())
    assert result is None


def test_returns_none_on_timeout(tmp_path):
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar), subprocess_runner=_fake_svarog_timeouts())
    assert result is None


def test_returns_none_when_jar_missing(tmp_path):
    raw = _make_raw()
    missing_jar = tmp_path / "nope.jar"  # doesn't exist
    assert svarog_review.review_bad_channels_via_svarog(
        raw, str(missing_jar)) is None


def test_returns_none_when_output_missing(tmp_path):
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")

    def rc0_no_output(cmd, timeout=None, check=False):
        # Exit 0 but don't write the output file
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar), subprocess_runner=rc0_no_output)
    assert result is None


def test_preselect_tag_file_is_written(tmp_path):
    """When preselected_bads is given, a --preselect arg is passed
    and the referenced file contains those channels."""
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    captured = {}

    def capture_cmd(cmd, timeout=None, check=False):
        captured["cmd"] = cmd
        # Read the preselect file that IDE4EEG just wrote
        idx = cmd.index("--preselect")
        path = cmd[idx + 1]
        captured["preselect_contents"] = (
            svarog_review._read_channel_tag_file(path))
        # Then write an output tag file
        out_idx = cmd.index("--output")
        svarog_review._write_channel_tag_file(
            cmd[out_idx + 1], ["Cz"], raw.info["ch_names"])
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar),
        preselected_bads=["Fp1", "Fp2"],
        subprocess_runner=capture_cmd)

    assert "--preselect" in captured["cmd"]
    assert captured["preselect_contents"] == ["Fp1", "Fp2"]
    assert result == ["Cz"]


def test_filters_unknown_channels(tmp_path):
    """Svarog shouldn't write channels outside the signal, but if
    it does we drop them rather than poisoning the caller."""
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_svarog_writes(
        None, ["Fp1", "ghost_channel", "Cz"], raw.info["ch_names"])
    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar), subprocess_runner=runner)
    # ghost_channel has no index so it doesn't end up in the
    # preselect tag file, hence not in the output either.  Fp1+Cz
    # survive.
    assert result == ["Fp1", "Cz"]


def test_empty_selection_is_preserved(tmp_path):
    """User saves with nothing marked → empty list, not None."""
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_svarog_writes(None, [], raw.info["ch_names"])
    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar), subprocess_runner=runner)
    assert result == []


def test_roundtrip_tag_file(tmp_path):
    """Writing and re-reading a tag file preserves the channel list."""
    all_ch = ["Fp1", "Fp2", "Cz", "O1", "O2"]
    tag_path = str(tmp_path / "t.tag")
    svarog_review._write_channel_tag_file(
        tag_path, ["Fp2", "O1"], all_ch)
    assert svarog_review._read_channel_tag_file(tag_path) == ["Fp2", "O1"]


def test_raises_or_fails_gracefully_on_corrupt_output(tmp_path):
    """Corrupt tag file → return None (don't propagate XML errors)."""
    raw = _make_raw()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")

    def writes_garbage(cmd, timeout=None, check=False):
        idx = cmd.index("--output")
        with open(cmd[idx + 1], "w") as f:
            f.write("not actually xml")
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_bad_channels_via_svarog(
        raw, str(jar), subprocess_runner=writes_garbage)
    assert result is None


# ── review_bad_epochs_via_svarog ────────────────────────────────────


def _make_epochs(n_epochs=5, sfreq=128, dur=1.0, tmin=-0.1):
    """Minimal mne.Epochs from a synthetic Raw + STIM."""
    n_ch = 3
    # Continuous signal long enough to hold n_epochs windows.
    n_samples = int(sfreq * dur) * (n_epochs + 2)
    data = np.random.randn(n_ch, n_samples) * 1e-6
    info = mne.create_info(["C3", "C4", "Cz"], sfreq, ["eeg"] * n_ch)
    raw = mne.io.RawArray(data, info, verbose=False)
    # Fake events, one per epoch, spaced dur apart.
    events = np.array([
        [int((i + 1) * sfreq * dur), 0, 1] for i in range(n_epochs)
    ], dtype=int)
    return mne.Epochs(raw, events, event_id={"evt": 1},
                      tmin=tmin, tmax=tmin + dur, baseline=None,
                      preload=True, verbose=False)


def _fake_epochs_writes(rejections, rc=0):
    """Return a subprocess_runner that writes an epoch-rejection
    tag file to the ``--output`` path and returns exit *rc*."""

    def runner(cmd, timeout=None, check=False):
        out_idx = cmd.index("--output")
        out_path = cmd[out_idx + 1]
        # We don't need a real Epochs object to write the output;
        # use the writer function directly with a minimal stand-in.
        from obci_readmanager.signal_processing.tags.tags_file_writer import (
            TagsFileWriter)
        w = TagsFileWriter(out_path)
        for idx in rejections:
            w.tag_received({
                "channelNumber": -1,
                "start_timestamp": 0.0,
                "end_timestamp": 0.0,
                "name": "reject",
                "desc": {"typ": "reject_epoch", "idx": str(int(idx))},
            })
        w.finish_saving(0.0)
        assert "--select-mode" in cmd
        assert cmd[cmd.index("--select-mode") + 1] == "bad_epochs"
        return subprocess.CompletedProcess(cmd, rc)

    return runner


def test_epoch_review_returns_indices_on_success(tmp_path):
    epochs = _make_epochs(n_epochs=5)
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_epochs_writes({0, 3})

    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar), subprocess_runner=runner)
    assert result == {0, 3}


def test_epoch_review_returns_none_on_cancel(tmp_path):
    epochs = _make_epochs()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar), subprocess_runner=_fake_svarog_cancels())
    assert result is None


def test_epoch_review_returns_none_on_timeout(tmp_path):
    epochs = _make_epochs()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar), subprocess_runner=_fake_svarog_timeouts())
    assert result is None


def test_epoch_review_returns_none_when_jar_missing(tmp_path):
    epochs = _make_epochs()
    missing_jar = tmp_path / "nope.jar"  # doesn't exist
    assert svarog_review.review_bad_epochs_via_svarog(
        epochs, str(missing_jar)) is None


def test_epoch_review_preselect_is_written(tmp_path):
    """When preselected_rejections is given, --preselect arg is
    passed and the referenced file contains those indices."""
    epochs = _make_epochs(n_epochs=5)
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    captured = {}

    def capture_cmd(cmd, timeout=None, check=False):
        captured["cmd"] = cmd
        idx = cmd.index("--preselect")
        path = cmd[idx + 1]
        captured["preselect_contents"] = (
            svarog_review._read_epoch_tag_file(path))
        out_idx = cmd.index("--output")
        # Simulate user accepting preselection + adding one more.
        from obci_readmanager.signal_processing.tags.tags_file_writer import (
            TagsFileWriter)
        w = TagsFileWriter(cmd[out_idx + 1])
        for i in (1, 2, 4):
            w.tag_received({
                "channelNumber": -1,
                "start_timestamp": 0.0,
                "end_timestamp": 0.0,
                "name": "reject",
                "desc": {"typ": "reject_epoch", "idx": str(i)},
            })
        w.finish_saving(0.0)
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar),
        preselected_rejections=[1, 2],
        subprocess_runner=capture_cmd)

    assert "--preselect" in captured["cmd"]
    assert captured["preselect_contents"] == {1, 2}
    assert result == {1, 2, 4}


def test_epoch_review_filters_out_of_range_indices(tmp_path):
    """Svarog shouldn't write indices outside [0, N), but if it
    does we drop them."""
    epochs = _make_epochs(n_epochs=5)
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_epochs_writes({0, 4, 99, -1})
    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar), subprocess_runner=runner)
    assert result == {0, 4}


def test_epoch_review_empty_selection_is_preserved(tmp_path):
    """User saves with nothing marked → empty set, not None."""
    epochs = _make_epochs()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_epochs_writes(set())
    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar), subprocess_runner=runner)
    assert result == set()


def test_epoch_review_corrupt_output_returns_none(tmp_path):
    epochs = _make_epochs()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")

    def writes_garbage(cmd, timeout=None, check=False):
        idx = cmd.index("--output")
        with open(cmd[idx + 1], "w") as f:
            f.write("not actually xml")
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar), subprocess_runner=writes_garbage)
    assert result is None


def test_epoch_review_skips_tags_without_idx(tmp_path):
    """Output tags missing the ``idx`` element are ignored rather
    than crashing — defence against third-party tag files."""
    epochs = _make_epochs()
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")

    def runner(cmd, timeout=None, check=False):
        out_idx = cmd.index("--output")
        # Hand-write a tag file where one tag has no idx element.
        with open(cmd[out_idx + 1], "w") as f:
            f.write(
                "<?xml version='1.0' encoding='UTF-8'?>\n"
                "<tags>\n"
                "  <tag name='reject' channelNumber='-1' "
                "position='0.0' length='0.0'>\n"
                "    <typ>reject_epoch</typ>\n"
                "    <idx>2</idx>\n"
                "  </tag>\n"
                "  <tag name='huh' channelNumber='-1' "
                "position='0.0' length='0.0'>\n"
                "    <typ>not_an_epoch_reject</typ>\n"
                "  </tag>\n"
                "</tags>\n"
            )
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_bad_epochs_via_svarog(
        epochs, str(jar), subprocess_runner=runner)
    assert result == {2}


def test_epoch_roundtrip_tag_file(tmp_path):
    """Writing and re-reading a tag file preserves the index set."""
    epochs = _make_epochs(n_epochs=7)
    tag_path = str(tmp_path / "epochs.tag")
    svarog_review._write_epoch_tag_file(tag_path, [1, 3, 5], epochs)
    assert svarog_review._read_epoch_tag_file(tag_path) == {1, 3, 5}


def test_epoch_write_skips_out_of_range_indices(tmp_path):
    """Writer silently drops indices outside [0, len(epochs))."""
    epochs = _make_epochs(n_epochs=3)
    tag_path = str(tmp_path / "epochs.tag")
    svarog_review._write_epoch_tag_file(
        tag_path, [0, 2, 5, -1, 100], epochs)
    assert svarog_review._read_epoch_tag_file(tag_path) == {0, 2}


# ── review_ica_via_svarog ───────────────────────────────────────────


def _make_ica(n_components=4, sfreq=128, dur=20.0):
    """Minimal Raw + fitted ICA for review tests.

    Uses a small synthetic dataset — ICA fits in <2s.  Returns
    (raw, ica) so callers don't need to re-fit.  Prefer the
    ``ica_default`` module fixture when n_components=4 works.
    """
    from mne.preprocessing import ICA
    rng = np.random.default_rng(0)
    ch_names = ["Fp1", "Fp2", "C3", "C4", "O1", "O2"]
    n_samples = int(sfreq * dur)
    data = rng.standard_normal((len(ch_names), n_samples)) * 1e-6
    info = mne.create_info(ch_names, sfreq, ["eeg"] * len(ch_names))
    raw = mne.io.RawArray(data, info, verbose=False)
    raw.set_montage("standard_1020", verbose=False)
    ica = ICA(n_components=n_components, random_state=0,
              max_iter=200, verbose=False)
    ica.fit(raw, verbose=False)
    return raw, ica


@pytest.fixture(scope="module")
def ica_default():
    """Shared (raw, ica) fitted once per test module (n_components=4).

    Tests that need a different component count use ``_make_ica``
    directly.  The ICA is immutable across tests; callers pass
    preselections by value so there's no cross-test state to worry
    about.
    """
    return _make_ica(n_components=4)


def _fake_ica_writes(excludes, rc=0):
    """Return a subprocess_runner that writes an ICA-exclusion tag
    file to ``--output`` and returns exit *rc*."""

    def runner(cmd, timeout=None, check=False):
        out_idx = cmd.index("--output")
        out_path = cmd[out_idx + 1]
        from obci_readmanager.signal_processing.tags.tags_file_writer import (
            TagsFileWriter)
        w = TagsFileWriter(out_path)
        for idx in excludes:
            w.tag_received({
                "channelNumber": -1,
                "start_timestamp": 0.0,
                "end_timestamp": 0.0,
                "name": f"ICA{int(idx):03d}",
                "desc": {"typ": "exclude_component", "idx": str(int(idx))},
            })
        w.finish_saving(0.0)
        assert "--select-mode" in cmd
        assert cmd[cmd.index("--select-mode") + 1] == "ica_components"
        # The positional file must be a sources-raw.fif written by
        # the helper — verify it actually exists on disk.
        sources_path = next(
            (a for a in cmd if a.endswith("sources-raw.fif")), None)
        assert sources_path and os.path.isfile(sources_path)
        # Topomap directory must exist and be populated.
        ti = cmd.index("--ica-topomaps")
        topomaps_dir = cmd[ti + 1]
        assert os.path.isdir(topomaps_dir)
        png_files = [f for f in os.listdir(topomaps_dir)
                     if f.startswith("comp_") and f.endswith(".png")]
        assert len(png_files) >= 1, "no topomap PNGs were written"
        return subprocess.CompletedProcess(cmd, rc)

    return runner


def test_ica_review_returns_excludes_on_success(tmp_path, ica_default):
    raw, ica = ica_default
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_ica_writes([0, 2])
    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=runner)
    assert result == [0, 2]


def test_ica_review_returns_none_on_cancel(tmp_path, ica_default):
    raw, ica = ica_default
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=_fake_svarog_cancels())
    assert result is None


def test_ica_review_returns_none_on_timeout(tmp_path, ica_default):
    raw, ica = ica_default
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=_fake_svarog_timeouts())
    assert result is None


def test_ica_review_returns_none_when_jar_missing(tmp_path, ica_default):
    raw, ica = ica_default
    missing_jar = tmp_path / "nope.jar"  # doesn't exist
    assert svarog_review.review_ica_via_svarog(
        raw, ica, str(missing_jar)) is None


def test_ica_review_topomap_pngs_match_component_count(tmp_path):
    """One PNG per component, named comp_<idx>.png."""
    raw, ica = _make_ica(n_components=3)
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    seen_files = {}

    def runner(cmd, timeout=None, check=False):
        ti = cmd.index("--ica-topomaps")
        topomaps_dir = cmd[ti + 1]
        seen_files["pngs"] = sorted(os.listdir(topomaps_dir))
        out_idx = cmd.index("--output")
        from obci_readmanager.signal_processing.tags.tags_file_writer import (
            TagsFileWriter)
        TagsFileWriter(cmd[out_idx + 1]).finish_saving(0.0)
        return subprocess.CompletedProcess(cmd, 0)

    svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=runner)
    assert seen_files["pngs"] == [
        "comp_0.png", "comp_1.png", "comp_2.png"]


def test_ica_review_preselect_is_written(tmp_path, ica_default):
    """When preselected is given, --preselect file contains those idxs."""
    raw, ica = ica_default
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    captured = {}

    def capture_cmd(cmd, timeout=None, check=False):
        captured["cmd"] = cmd
        idx = cmd.index("--preselect")
        captured["preselect_contents"] = (
            svarog_review._read_component_tag_file(cmd[idx + 1]))
        out_idx = cmd.index("--output")
        # User accepts preselection + adds one.
        from obci_readmanager.signal_processing.tags.tags_file_writer import (
            TagsFileWriter)
        w = TagsFileWriter(cmd[out_idx + 1])
        for i in (1, 3):
            w.tag_received({
                "channelNumber": -1,
                "start_timestamp": 0.0,
                "end_timestamp": 0.0,
                "name": f"ICA{i:03d}",
                "desc": {"typ": "exclude_component", "idx": str(i)},
            })
        w.finish_saving(0.0)
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar),
        preselected=[1], subprocess_runner=capture_cmd)
    assert "--preselect" in captured["cmd"]
    assert captured["preselect_contents"] == [1]
    assert result == [1, 3]


def test_ica_review_filters_out_of_range_indices(tmp_path):
    """Svarog shouldn't write indices outside [0, n_components_)."""
    raw, ica = _make_ica(n_components=3)
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_ica_writes([0, 2, 99, -1])
    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=runner)
    assert result == [0, 2]


def test_ica_review_empty_selection_is_preserved(tmp_path, ica_default):
    """User saves with nothing marked → empty list, not None."""
    raw, ica = ica_default
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")
    runner = _fake_ica_writes([])
    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=runner)
    assert result == []


def test_ica_review_corrupt_output_returns_none(tmp_path, ica_default):
    raw, ica = ica_default
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")

    def writes_garbage(cmd, timeout=None, check=False):
        idx = cmd.index("--output")
        with open(cmd[idx + 1], "w") as f:
            f.write("not actually xml")
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=writes_garbage)
    assert result is None


def test_ica_review_skips_wrong_typ_tags(tmp_path, ica_default):
    """Output tags whose typ != exclude_component are ignored.

    Defends against a stale tag file with bad_channel or
    reject_epoch entries; we only consume our own type.
    """
    raw, ica = ica_default
    jar = tmp_path / "svarog.jar"
    jar.write_bytes(b"")

    def runner(cmd, timeout=None, check=False):
        out_idx = cmd.index("--output")
        with open(cmd[out_idx + 1], "w") as f:
            f.write(
                "<?xml version='1.0' encoding='UTF-8'?>\n"
                "<tags>\n"
                "  <tag name='ICA001' channelNumber='-1' "
                "position='0.0' length='0.0'>\n"
                "    <typ>exclude_component</typ>\n"
                "    <idx>1</idx>\n"
                "  </tag>\n"
                "  <tag name='Fp1' channelNumber='0' "
                "position='0.0' length='0.0'>\n"
                "    <typ>bad_channel</typ>\n"
                "    <idx>0</idx>\n"
                "  </tag>\n"
                "</tags>\n"
            )
        return subprocess.CompletedProcess(cmd, 0)

    result = svarog_review.review_ica_via_svarog(
        raw, ica, str(jar), subprocess_runner=runner)
    assert result == [1]


def test_ica_roundtrip_tag_file(tmp_path):
    """Writing and re-reading preserves the index list and order."""
    tag_path = str(tmp_path / "ica.tag")
    svarog_review._write_component_tag_file(tag_path, [3, 0, 7])
    assert svarog_review._read_component_tag_file(tag_path) == [3, 0, 7]
