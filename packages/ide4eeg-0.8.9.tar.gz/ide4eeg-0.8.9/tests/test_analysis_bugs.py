"""Regression tests for analysis bugs found during code review.

Tests scientific computation correctness and edge cases that
have caused real bugs in the past.
"""

import os
import sys
import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# FDR correction (was broken: single threshold instead of step-up)
# ---------------------------------------------------------------------------

class TestFDRCorrection:
    """Verify Benjamini-Yekutieli FDR step-up procedure."""

    def test_all_significant(self):
        """When all p-values are 0, all should be rejected."""
        p = np.zeros(100)
        m = len(p)
        c_m = np.sum(1.0 / np.arange(1, m + 1))
        k = np.arange(1, m + 1)
        thresholds = k * 0.05 / (m * c_m)
        rejected = np.where(p <= thresholds)[0]
        p_rej = thresholds[rejected[-1]] if len(rejected) > 0 else 0.0
        assert p_rej > 0
        assert np.all(p <= p_rej)

    def test_none_significant(self):
        """When all p-values are 1, none should be rejected."""
        p = np.ones(100)
        m = len(p)
        c_m = np.sum(1.0 / np.arange(1, m + 1))
        k = np.arange(1, m + 1)
        thresholds = k * 0.05 / (m * c_m)
        rejected = np.where(p <= thresholds)[0]
        p_rej = thresholds[rejected[-1]] if len(rejected) > 0 else 0.0
        assert p_rej == 0.0

    def test_mixed_significance(self):
        """Some p-values significant, some not."""
        p = np.array([0.001, 0.01, 0.05, 0.1, 0.5, 0.9])
        p_sorted = np.sort(p)
        m = len(p_sorted)
        c_m = np.sum(1.0 / np.arange(1, m + 1))
        k = np.arange(1, m + 1)
        thresholds = k * 0.05 / (m * c_m)
        rejected = np.where(p_sorted <= thresholds)[0]
        p_rej = thresholds[rejected[-1]] if len(rejected) > 0 else 0.0
        # At least the 0.001 value should be rejected
        assert p_rej >= 0.001


# ---------------------------------------------------------------------------
# Bootstrap pseudo-t (was broken: wrong denominator)
# ---------------------------------------------------------------------------

class TestBootstrapPseudoT:
    """Verify the pseudo-t statistic formula."""

    def test_equal_means(self):
        """Equal distributions should give t ≈ 0."""
        np.random.seed(42)
        a = np.random.randn(100)
        b = np.random.randn(100)
        n1, n2 = len(a), len(b)
        denom = np.sqrt(np.var(a, ddof=1) / n1 + np.var(b, ddof=1) / n2)
        t = (np.mean(a) - np.mean(b)) / denom if denom > 0 else 0
        assert abs(t) < 3.0  # should be small

    def test_different_means(self):
        """Shifted distributions should give large |t|."""
        np.random.seed(42)
        a = np.random.randn(100) + 5  # shifted by 5
        b = np.random.randn(100)
        n1, n2 = len(a), len(b)
        denom = np.sqrt(np.var(a, ddof=1) / n1 + np.var(b, ddof=1) / n2)
        t = (np.mean(a) - np.mean(b)) / denom
        assert abs(t) > 10  # should be very large

    def test_zero_variance_handled(self):
        """Constant arrays should not crash."""
        a = np.ones(10)
        b = np.ones(10) * 2
        n1, n2 = len(a), len(b)
        denom = np.sqrt(np.var(a, ddof=1) / n1 + np.var(b, ddof=1) / n2)
        t = (np.mean(a) - np.mean(b)) / denom if denom > 0 else 0.0
        assert t == 0.0  # denom is 0, so t is 0 by convention


# ---------------------------------------------------------------------------
# PSD normalization (was wrong: missing /sfreq)
# ---------------------------------------------------------------------------

class TestPSDNormalization:
    """Verify PSD computation produces V²/Hz units."""

    def test_psd_scales_with_sfreq(self):
        """PSD should be independent of sampling rate for same signal."""
        np.random.seed(42)
        duration = 1.0  # seconds
        for sfreq in (256, 512, 1024):
            n = int(duration * sfreq)
            signal = np.random.randn(n) * 1e-5  # ~10 µV
            psd = np.abs(np.fft.rfft(signal)) ** 2 / (n * sfreq)
            mean_psd = np.mean(psd)
            # All should be similar order of magnitude
            assert 1e-15 < mean_psd < 1e-8, \
                f"PSD at {sfreq} Hz: {mean_psd} — out of expected range"


# ---------------------------------------------------------------------------
# Artifact detection: inf thresholds disable detection
# ---------------------------------------------------------------------------

class TestArtifactDisable:
    """Verify that inf thresholds effectively disable artifact detection."""

    def test_inf_threshold_no_detections(self):
        """No samples should exceed infinity."""
        data = np.random.randn(1000) * 100
        threshold = np.inf
        assert not np.any(np.abs(data) > threshold)

    def test_inf_multiplication(self):
        """inf * finite = inf (the disable mechanism)."""
        median_val = 5.0
        std_val = 2.0
        assert np.inf * median_val == np.inf
        assert np.inf * std_val + median_val == np.inf
        assert min(np.inf, np.inf, np.inf) == np.inf


# ---------------------------------------------------------------------------
# Channel correlation: bincount vs unique (was wrong: unique dropped channels)
# ---------------------------------------------------------------------------

class TestChannelCorrelation:
    """Verify channel correlation bad-channel detection."""

    def test_bincount_includes_all_channels(self):
        """np.bincount with minlength should count all channels."""
        # Simulate: 5 channels, only channels 1 and 3 have bad correlations
        bad_x = np.array([1, 1, 1, 3, 3])
        n_channels = 5
        counts = np.bincount(bad_x, minlength=n_channels)
        assert len(counts) == 5
        assert counts[0] == 0  # channel 0: no bad correlations
        assert counts[1] == 3  # channel 1: 3 bad correlations
        assert counts[2] == 0  # channel 2: none
        assert counts[3] == 2  # channel 3: 2 bad correlations
        assert counts[4] == 0  # channel 4: none

    def test_unique_would_give_wrong_indices(self):
        """Demonstrate why np.unique was wrong (regression test)."""
        bad_x = np.array([1, 1, 3, 3])
        # np.unique returns only values that appear
        vals, counts = np.unique(bad_x, return_counts=True)
        # vals = [1, 3], counts = [2, 2]
        # If we do channels_names[np.where(counts >= 2)[0]]:
        # indices [0, 1] → channels_names[0], channels_names[1]
        # But channel 0 has NO bad correlations — it's channels 1 and 3!
        assert list(vals) == [1, 3]
        # The indices from np.where would be 0 and 1 (into the unique array)
        # NOT the actual channel indices
        assert np.where(counts >= 2)[0].tolist() == [0, 1]


# ---------------------------------------------------------------------------
# .tag XML export: well-formed output
# ---------------------------------------------------------------------------

class TestTagExport:
    """Verify .tag XML files are well-formed."""

    def test_eeg_profiles_tag_export(self, tmp_path):
        """EEG profiles tag export produces valid XML."""
        from ide4eeg.analysis.eeg_profiles import _save_detection_tags

        detections = [
            {"name": "Sleep spindles", "t0_s": 5.0, "scale_s": 0.5,
             "f_Hz": 12.0, "amplitude_uV": 25.0, "energy": 0.001,
             "phase": 0.0},
            {"name": "Alpha waves", "t0_s": 10.0, "scale_s": 1.0,
             "f_Hz": 10.0, "amplitude_uV": 15.0, "energy": 0.002,
             "phase": 0.1},
        ]
        structures = [{"name": "Sleep spindles"}, {"name": "Alpha waves"}]

        tag_path = _save_detection_tags(
            detections, structures, "Cz", "test", str(tmp_path))

        assert os.path.isfile(tag_path)

        # Parse XML to verify well-formedness
        from xml.etree import ElementTree as ET
        tree = ET.parse(tag_path)
        root = tree.getroot()
        assert root.tag == "tagFile"

        tags = root.findall(".//tag")
        assert len(tags) == 2
        assert tags[0].get("name") == "Sleep spindles"
        assert float(tags[0].get("position")) == pytest.approx(4.5)
        assert float(tags[0].get("length")) == pytest.approx(1.0)

    # test_sleep_staging_graphoelement_tags moved to
    # _unreleased/tests/test_sleep_staging.py


# ---------------------------------------------------------------------------
# Empi command formatting
# ---------------------------------------------------------------------------

class TestEmpiCommand:
    """Verify empi command-line argument formatting."""

    def test_residual_formatting(self):
        """Residual energy should be formatted cleanly (no float noise)."""
        from ide4eeg.analysis.mp_analysis import _build_empi_cmd
        cmd = _build_empi_cmd(
            "/usr/bin/empi", "/tmp/in.bin", "/tmp/out.db",
            sfreq=512, n_channels=1,
            mp_cfg={"explained_energy": 0.95, "algorithm": "smp"})
        # Find the -r value
        r_idx = cmd.index("-r")
        r_val = cmd[r_idx + 1]
        assert r_val == "0.05", f"Expected '0.05', got '{r_val}'"

    def test_iterations_is_int(self):
        """Iterations should be formatted as integer."""
        from ide4eeg.analysis.mp_analysis import _build_empi_cmd
        cmd = _build_empi_cmd(
            "/usr/bin/empi", "/tmp/in.bin", "/tmp/out.db",
            sfreq=512, n_channels=1,
            mp_cfg={"iterations": 50, "algorithm": "smp"})
        i_idx = cmd.index("-i")
        assert cmd[i_idx + 1] == "50"
