"""Preflight guards for connectivity short-time computation.

Locks the behaviour added 2026-05-13 to catch the two failure modes
observed in v0.8.3 user logs (`Singular matrix` for short-time GCI on
rank-deficient signals, `padlen` ValueError for short-time AEC on
small windows): the orchestrator must now raise :class:
`ShortWindowError` from `_compute_short_time` and surface a WARNING
(not an ERROR with traceback) at the call site.
"""
import numpy as np
import pytest

from ide4eeg.analysis.connectivity_analysis import (
    ShortWindowError,
    _aec_min_window_samples,
    _compute_short_time,
    _mvar_min_window_samples,
)


def _rng_signal(n_channels, n_samples, seed=0):
    rng = np.random.default_rng(seed)
    return rng.standard_normal((n_channels, n_samples))


# ── Preflight helpers ────────────────────────────────────────────

def test_aec_min_window_samples_is_positive():
    assert _aec_min_window_samples(128.0) > 0


def test_mvar_min_window_samples_scales_with_order_and_channels():
    base = _mvar_min_window_samples(n_channels=10, order=2)
    more_order = _mvar_min_window_samples(n_channels=10, order=4)
    more_ch = _mvar_min_window_samples(n_channels=20, order=2)
    assert more_order > base
    assert more_ch > base


# ── End-to-end preflight via _compute_short_time ─────────────────

def test_short_time_aec_raises_short_window_error_on_tiny_window():
    """Reproduces conn2/conn3 log: 19-ch, nfft → ~27 samples."""
    signal = _rng_signal(n_channels=19, n_samples=129)
    with pytest.raises(ShortWindowError, match="filtfilt"):
        _compute_short_time(
            "aec", signal, mvar_method="yw", order=3,
            sfreq=128.0, resolution=100, nfft=25, no=10)


def test_short_time_gci_raises_short_window_error_on_tiny_window():
    """Reproduces conn2/conn3 log: 19-ch MVAR(3) on 25-sample window."""
    signal = _rng_signal(n_channels=19, n_samples=129)
    with pytest.raises(ShortWindowError, match="MVAR"):
        _compute_short_time(
            "gci", signal, mvar_method="yw", order=3,
            sfreq=128.0, resolution=100, nfft=25, no=10)


def test_short_time_ar_method_also_preflighted():
    """DTF and similar AR methods follow the same MVAR threshold."""
    signal = _rng_signal(n_channels=10, n_samples=200)
    with pytest.raises(ShortWindowError, match="MVAR"):
        _compute_short_time(
            "dtf", signal, mvar_method="yw", order=4,
            sfreq=128.0, resolution=100, nfft=20, no=5)


def test_short_time_coh_no_mvar_preflight():
    """Coherency is signal-based (no MVAR, no filtfilt) — preflight
    doesn't apply and small windows must reach the underlying solver
    rather than be rejected upfront."""
    signal = _rng_signal(n_channels=5, n_samples=200)
    # Should not raise ShortWindowError — may or may not succeed
    # inside coherency itself, but the preflight stays out of the way.
    try:
        _compute_short_time(
            "coh", signal, mvar_method="yw", order=2,
            sfreq=128.0, resolution=50, nfft=40, no=10)
    except ShortWindowError:  # pragma: no cover
        pytest.fail("COH should not trip the short-time preflight")
    except Exception:
        # Anything else is fine for this test — we only assert the
        # preflight doesn't fire.
        pass
