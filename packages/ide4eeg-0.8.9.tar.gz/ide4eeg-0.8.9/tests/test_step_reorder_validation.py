"""Headless tests for the Preprocessing-tab reorder-time validator.

The interesting logic — "would this move create a new violation?" —
lives in ``IDE4EEG_Qt._preview_step_move``, which is a pure-Python
classmethod.  These tests import it directly and exercise it against
synthetic step-key lists so no QApplication / main window is needed.

Two things are covered:

* the GUI → pipeline expansion done by
  ``_step_widgets_to_pipeline_order`` (gaze maps to
  ``gaze_artifacts`` and artifacts to ``eeg_artifacts``, both
  independent steps after the artifacts-step split);
* the "new violations only" diff inside ``_preview_step_move`` —
  pre-existing violations that the user already accepted when
  loading a config must not fire the modal on an unrelated move.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Avoid accidentally booting a full Qt display.  Importing ``gui``
# brings in PySide6 which needs this for macOS CI.
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from ide4eeg.gui import IDE4EEG_Qt  # noqa: E402


# Canonical default order (what the GUI ships with).
_DEFAULT_KEYS = [
    "trim", "select", "bad_channels", "montage", "reference",
    "resample", "filtering", "ica", "artifacts",
    "mp_decomposition", "mp_filter", "gaze",
]


class TestStepWidgetsToPipelineOrder:
    """``_step_widgets_to_pipeline_order`` is the GUI→pipeline
    bridge used by both ``_preview_step_move`` and ``_collect_config``.
    It must drop GUI-only rows and expand aggregated ones."""

    def test_gaze_maps_to_gaze_artifacts(self):
        # The gaze panel maps to its own ``gaze_artifacts`` pipeline
        # step (post-split); the GUI key itself is dropped.
        order = IDE4EEG_Qt._step_widgets_to_pipeline_order(
            ["trim", "gaze", "filtering"],
            IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS)
        assert "gaze" not in order
        assert order == ["trim", "gaze_artifacts", "filtering"]

    def test_gaze_and_artifacts_are_independent(self):
        # Post-split: gaze and artifacts panels drive distinct
        # pipeline steps and both appear in widget order.
        order = IDE4EEG_Qt._step_widgets_to_pipeline_order(
            ["artifacts", "gaze"], IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS)
        assert order == ["eeg_artifacts", "gaze_artifacts"]
        order_swapped = IDE4EEG_Qt._step_widgets_to_pipeline_order(
            ["gaze", "artifacts"], IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS)
        assert order_swapped == ["gaze_artifacts", "eeg_artifacts"]

    def test_resample_and_filtering_are_independent(self):
        """After Phase 1, resample and filtering are separate GUI keys
        each mapping to a single pipeline step.  No expansion."""
        order = IDE4EEG_Qt._step_widgets_to_pipeline_order(
            ["resample", "filtering"], IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS)
        assert order == ["resample", "filtering"]
        order_swapped = IDE4EEG_Qt._step_widgets_to_pipeline_order(
            ["filtering", "resample"], IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS)
        assert order_swapped == ["filtering", "resample"]

    def test_default_order_matches_step_registry_expectations(self):
        order = IDE4EEG_Qt._step_widgets_to_pipeline_order(
            _DEFAULT_KEYS, IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS)
        # Every ``STEP_REGISTRY`` entry must be represented.
        from ide4eeg.preprocessing.preprocessing import STEP_REGISTRY
        for step in STEP_REGISTRY:
            assert step in order, (
                f"Pipeline step '{step}' missing from default "
                f"GUI→pipeline projection: {order}")


class TestPreviewStepMoveBasics:
    """Bounds and no-op behaviour of the move preview."""

    def test_out_of_bounds_up_returns_not_ok(self):
        result = IDE4EEG_Qt._preview_step_move(
            _DEFAULT_KEYS, "trim", -1)
        assert result["ok"] is False
        assert result["new_step_keys"] == []

    def test_out_of_bounds_down_returns_not_ok(self):
        result = IDE4EEG_Qt._preview_step_move(
            _DEFAULT_KEYS, "gaze", 1)
        assert result["ok"] is False

    def test_unknown_key_returns_not_ok(self):
        result = IDE4EEG_Qt._preview_step_move(
            _DEFAULT_KEYS, "does_not_exist", 1)
        assert result["ok"] is False

    def test_clean_move_reports_no_new_violations(self):
        # Swap trim and select — neither participates in any
        # default constraint, so the move must be silent.
        result = IDE4EEG_Qt._preview_step_move(
            _DEFAULT_KEYS, "trim", 1)
        assert result["ok"] is True
        assert result["new_hard_violations"] == []
        assert result["new_soft_violations"] == []
        # New key order swaps trim and select.
        assert result["new_step_keys"][:2] == ["select", "trim"]


class TestPreviewStepMoveHardViolations:
    """Reordering mp_filter above mp_decomposition is the only hard
    constraint in the default set.  It must fire loudly the first
    time it's introduced."""

    def test_mp_filter_above_mp_decomposition_creates_hard(self):
        # Move mp_filter up past mp_decomposition.
        result = IDE4EEG_Qt._preview_step_move(
            _DEFAULT_KEYS, "mp_filter", -1)
        assert result["ok"] is True
        hard = result["new_hard_violations"]
        assert len(hard) == 1
        v = hard[0]
        assert v.severity == "hard"
        assert v.before == "mp_decomposition"
        assert v.after == "mp_filter"
        assert v.rationale  # non-empty

    def test_caller_should_reject_the_move_on_hard(self):
        # The preview doesn't itself refuse — it just reports.  But
        # the caller (``_move_step``) is contractually required to
        # bail when ``new_hard_violations`` is non-empty, so nothing
        # should move in the GUI.  We assert the contract: the
        # result carries the *projected* post-move key order so the
        # caller can display a "would-be" tint, but it also carries
        # the hard violation so the caller knows not to commit.
        result = IDE4EEG_Qt._preview_step_move(
            _DEFAULT_KEYS, "mp_filter", -1)
        assert result["new_hard_violations"]
        # Both the "after" and "before" step names are in the
        # ConstraintViolation, so the caller can look up widgets
        # for both halves of the pair for red tinting.
        v = result["new_hard_violations"][0]
        assert {v.before, v.after} == {"mp_decomposition", "mp_filter"}


class TestPreviewStepMoveSoftViolations:
    """Soft constraints: filter→ica, bad_channels→ica."""

    def test_filter_after_ica_is_soft(self):
        # Move ica up past filtering → filtering comes after ica,
        # violating the Winkler recommendation.
        result = IDE4EEG_Qt._preview_step_move(
            _DEFAULT_KEYS, "ica", -1)
        assert result["ok"] is True
        assert result["new_hard_violations"] == []
        soft = result["new_soft_violations"]
        assert len(soft) == 1
        v = soft[0]
        assert v.severity == "soft"
        assert v.before == "filtering"
        assert v.after == "ica"
        assert "Winkler" in v.rationale


class TestPreviewIgnoresPreExistingViolations:
    """Loading a config with an unusual order shouldn't spam the
    user about old violations when they move an unrelated step."""

    def test_preexisting_soft_silent_on_unrelated_move(self):
        # Start with ica BEFORE filtering (pre-existing filter→ica
        # violation).  Then move trim down — completely unrelated.
        # No NEW violation should be reported.
        keys = ["trim", "select", "bad_channels", "montage", "ica",
                "filtering", "artifacts", "mp_decomposition",
                "mp_filter", "gaze"]
        result = IDE4EEG_Qt._preview_step_move(keys, "trim", 1)
        assert result["ok"] is True
        assert result["new_hard_violations"] == []
        assert result["new_soft_violations"] == []
