"""Tests for TOML serialization and config string conversion.

Covers:
- _toml_value(): Python → TOML string conversion
- convert_strings(): TOML string → Python type conversion
"""

import numpy as np
import pytest

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# _toml_value  (gui_config.py)
# ---------------------------------------------------------------------------

from ide4eeg.gui_config import _toml_value


class TestTomlValue:
    """Test Python → TOML string conversion."""

    def test_none(self):
        assert _toml_value(None) == '""'

    def test_bool_true(self):
        assert _toml_value(True) == "true"

    def test_bool_false(self):
        assert _toml_value(False) == "false"

    def test_int(self):
        assert _toml_value(42) == "42"

    def test_int_zero(self):
        assert _toml_value(0) == "0"

    def test_int_negative(self):
        assert _toml_value(-7) == "-7"

    def test_float(self):
        assert _toml_value(3.14) == "3.14"

    def test_float_zero(self):
        assert _toml_value(0.0) == "0.0"

    def test_string_simple(self):
        assert _toml_value("hello") == '"hello"'

    def test_string_with_quotes(self):
        assert _toml_value('say "hi"') == '"say \\"hi\\""'

    def test_string_with_backslash(self):
        assert _toml_value("C:\\Users") == '"C:\\\\Users"'

    def test_string_empty(self):
        assert _toml_value("") == '""'

    def test_list_of_ints(self):
        assert _toml_value([1, 2, 3]) == "[1, 2, 3]"

    def test_list_of_strings(self):
        assert _toml_value(["a", "b"]) == '["a", "b"]'

    def test_list_empty(self):
        assert _toml_value([]) == "[]"

    def test_tuple_treated_as_list(self):
        assert _toml_value((1, 2)) == "[1, 2]"

    def test_dict(self):
        result = _toml_value({"w": 6.0})
        assert result == "{w = 6.0}"

    def test_dict_multiple_keys(self):
        result = _toml_value({"a": 1, "b": True})
        assert "a = 1" in result
        assert "b = true" in result

    def test_nested_list(self):
        assert _toml_value([[1, 2], [3]]) == "[[1, 2], [3]]"

    def test_mixed_list(self):
        result = _toml_value([1, "two", True])
        assert result == '[1, "two", true]'


# ---------------------------------------------------------------------------
# convert_strings  (ide4eeg/input/input.py)
# ---------------------------------------------------------------------------

from ide4eeg.input.input import convert_strings


class TestConvertStrings:
    """Test TOML string → Python type conversion."""

    def test_none_string(self):
        assert convert_strings({"x": "None"}) == {"x": None}

    def test_true_string(self):
        assert convert_strings({"x": "True"}) == {"x": True}

    def test_false_string(self):
        assert convert_strings({"x": "False"}) == {"x": False}

    def test_inf_string(self):
        result = convert_strings({"x": "inf"})
        assert result["x"] == np.inf

    def test_np_inf_string(self):
        result = convert_strings({"x": "np.inf"})
        assert result["x"] == np.inf

    def test_oo_string(self):
        result = convert_strings({"x": "oo"})
        assert result["x"] == np.inf

    def test_path_backslash(self):
        result = convert_strings({"input_path": "C:\\data\\file.raw"})
        assert result["input_path"] == "C:/data/file.raw"

    def test_comma_separated(self):
        result = convert_strings({"channels": "C3, C4, Cz"})
        assert result["channels"] == ["C3", "C4", "Cz"]

    def test_comma_separated_strips_whitespace(self):
        result = convert_strings({"x": " a , b , c "})
        assert result["x"] == ["a", "b", "c"]

    def test_nested_dict(self):
        cfg = {"outer": {"inner": "True"}}
        result = convert_strings(cfg)
        assert result["outer"]["inner"] is True

    def test_non_string_passthrough(self):
        cfg = {"x": 42, "y": 3.14, "z": True}
        result = convert_strings(cfg)
        assert result == cfg

    def test_regular_string_unchanged(self):
        cfg = {"name": "hello"}
        result = convert_strings(cfg)
        assert result["name"] == "hello"

    def test_backslash_in_non_path(self):
        result = convert_strings({"x": "a\\b"})
        assert result["x"] == "a/b"

    def test_path_with_comma_not_split(self):
        # Paths should not be split on commas
        result = convert_strings({"input_path": "C:/some,path/file.raw"})
        assert result["input_path"] == "C:/some,path/file.raw"


# ---------------------------------------------------------------------------
# dump_toml + _toml_key  (gui_config.py)  — round-trip with special chars
# ---------------------------------------------------------------------------

from ide4eeg.gui_config import dump_toml, _toml_key


class TestTomlKey:
    """Bare keys stay bare; everything else gets quoted."""

    def test_bare_key_unchanged(self):
        assert _toml_key("filtering") == "filtering"
        assert _toml_key("Cz") == "Cz"
        assert _toml_key("abc1234") == "abc1234"
        assert _toml_key("HP_freq") == "HP_freq"
        assert _toml_key("re-reference") == "re-reference"

    def test_key_with_space_quoted(self):
        assert _toml_key("target trial") == "\"target trial\""

    def test_key_with_brackets_quoted(self):
        assert _toml_key("Aux29 [misc]") == "\"Aux29 [misc]\""

    def test_key_with_dot_quoted(self):
        # Dots have meaning in TOML keys (dotted-key path), so any
        # name containing a dot must be quoted to be treated as a
        # single key rather than a nested-table path.
        assert _toml_key("event.name") == "\"event.name\""

    def test_empty_key_quoted(self):
        # Empty string is not a valid bare key.
        assert _toml_key("") == "\"\""


class TestDumpTomlRoundTrip:
    """End-to-end: write our config dict, read it back via tomllib,
    and verify every key/value matches.  Covers the "channel name
    with space" / "event name with bracket" failure modes that
    crashed the pipeline (gui_config issue, 2026-04-29)."""

    def _roundtrip(self, tmp_path, data):
        import tomllib
        path = tmp_path / "cfg.toml"
        dump_toml(data, str(path))
        with open(path, "rb") as f:
            return tomllib.load(f)

    def test_simple_dict(self, tmp_path):
        data = {"trim_start": 0.0, "trim_end": ""}
        out = self._roundtrip(tmp_path, data)
        assert out == data

    def test_inline_table_with_safe_keys(self, tmp_path):
        data = {"events_desc_id": {"target": 1, "nontarget": 2}}
        out = self._roundtrip(tmp_path, data)
        assert out == data

    def test_inline_table_key_with_space_round_trips(self, tmp_path):
        data = {"events_desc_id": {"target trial": 1, "nontarget": 2}}
        out = self._roundtrip(tmp_path, data)
        assert out == data

    def test_inline_table_key_with_brackets_round_trips(self, tmp_path):
        data = {"choosing_channels": {
            "type_overrides": {"Aux29 [misc]": "misc", "Cz": "eeg"},
        }}
        out = self._roundtrip(tmp_path, data)
        assert out == data

    def test_section_key_with_special_char_round_trips(self, tmp_path):
        # Filter id with hyphen / starts-with-digit (auto-id schema
        # uses 8-char hex but defensive: any UUID-like string).
        data = {"filters": {
            "abc1234": {"highpass_freq": 0.5, "lowpass_freq": 30.0},
            "5fa9-77": {"highpass_freq": 1.0, "lowpass_freq": 40.0},
        }}
        out = self._roundtrip(tmp_path, data)
        assert out == data

    def test_filter_block_inline_round_trips(self, tmp_path):
        # Mirrors the schema produced by the multi-filter Phase 2 GUI.
        data = {"filters": {
            "abc1234": {
                "highpass_freq": 0.5, "lowpass_freq": 30.0,
                "notch_freq": 50, "method": "iir",
                "show_filt": False, "plot_filt": False, "save": False,
            },
        }}
        out = self._roundtrip(tmp_path, data)
        assert out == data

