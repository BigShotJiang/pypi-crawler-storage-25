"""Behaviour lock for the V→µV² unit fix in BandPower.

User report (2026-05-04): the bad-channels band-power plots showed
power ~10⁻⁹ vs threshold lines ~10¹–10⁵ — a 10¹² mismatch caused by
``Power()`` returning V² (MNE SI) while ``BandPower``'s thresholds and
the ``[choosing_channels.badchs_params]`` config keys are documented
in µV². Every channel scored 0 → the band-power detector silently
flagged nothing.

Fix: convert ``Pg`` to µV² at the boundary in ``BandPower``. Tests
here lock in:
1. Power output units are µV² (not V²) after the fix.
2. A clearly-noisy channel against documented-µV² thresholds is flagged.
3. A clearly-clean channel is left alone.
"""
import os
import tempfile

import mne
import numpy as np
import pytest

from ide4eeg.preprocessing.channels_and_signal import (
    BandPower,
    Power,
    ValidateChannels_Noise,
)


def _make_raw_with_noisy_channel(sfreq=200.0, duration=20.0,
                                 noisy_idx=0, noisy_uv=200.0):
    """RawArray with N normal EEG channels + one noisy channel.

    All amplitudes specified in µV; ``mne.io.RawArray`` expects V.
    """
    rng = np.random.default_rng(42)
    n_samples = int(sfreq * duration)
    n_eeg = 4
    # Background noise: ~5 µV RMS, well below any µV² threshold.
    data = rng.standard_normal((n_eeg, n_samples)) * 5e-6
    # Noisy channel: large broadband + 60 Hz line-noise mix in V.
    t = np.arange(n_samples) / sfreq
    line = noisy_uv * 1e-6 * np.sin(2 * np.pi * 60.0 * t)
    broadband = rng.standard_normal(n_samples) * (noisy_uv * 1e-6)
    data[noisy_idx] = line + broadband

    ch_names = [f"EEG{i + 1}" for i in range(n_eeg)]
    ch_types = ["eeg"] * n_eeg
    info = mne.create_info(ch_names, sfreq=sfreq, ch_types=ch_types)
    return mne.io.RawArray(data, info, verbose=False)


class TestPowerUnits:
    """Direct check that ``BandPower``'s scale is µV² after the fix."""

    def test_clean_signal_power_is_uv_squared_scale(self):
        # 30 µV RMS sine at 10 Hz → expected band power ~450 µV² in
        # the 8–12 Hz band (RMS² = (30 µV)² / 2 ≈ 450 µV² for a sine).
        raw = _make_raw_with_noisy_channel(noisy_idx=0, noisy_uv=0.0)
        sfreq = raw.info["sfreq"]
        rng = np.random.default_rng(0)
        t = np.arange(int(sfreq * 20)) / sfreq
        # Replace channel 0 with a pure 30 µV @ 10 Hz sine.
        raw._data[0] = 30e-6 * np.sin(2 * np.pi * 10.0 * t)

        with tempfile.TemporaryDirectory() as tmp:
            Pgs, _ = BandPower(raw, width=2.0, band=[8, 12],
                               thrs_type="-", thrs=[1e3, 1e4, 1e5],
                               path=tmp, file_name="t")

        # After the µV² conversion, power for the sine channel must
        # land in the hundreds (µV²), not in the 10⁻¹⁰ V² range.
        Pg = Pgs["EEG1"]
        median_p = float(np.median(Pg))
        assert 50.0 < median_p < 5000.0, (
            f"BandPower returned {median_p:.3g} (expected ~10²–10³ µV² "
            "for a 30 µV sine). If you see ~1e-10, the V→µV² "
            "conversion in BandPower is missing.")


class TestNoiseDetection:
    """End-to-end: noisy channel flagged, clean channels left alone."""

    def test_noisy_channel_flagged_against_uv_thresholds(self):
        # 200 µV broadband + 60 Hz sine on EEG1; defaults thresholds
        # (slow_oscillations / noise_power) target the band power that
        # results.
        raw = _make_raw_with_noisy_channel(
            noisy_idx=0, noisy_uv=200.0, sfreq=200.0, duration=20.0)
        with tempfile.TemporaryDirectory() as tmp:
            bad = ValidateChannels_Noise(
                raw, width=1.0, band=[52, 98],
                thresholds_type="-",
                thresholds=[2e1, 2e2, 2e3],  # noise_power defaults (µV²)
                path=tmp, file_name="t",
            )
        assert "EEG1" in bad, (
            "Noisy channel (200 µV broadband+line) should exceed the "
            "noise_power µV² thresholds. Got bad list: " + str(bad))

    def test_clean_channels_not_flagged(self):
        raw = _make_raw_with_noisy_channel(
            noisy_idx=0, noisy_uv=200.0, sfreq=200.0, duration=20.0)
        with tempfile.TemporaryDirectory() as tmp:
            bad = ValidateChannels_Noise(
                raw, width=1.0, band=[52, 98],
                thresholds_type="-",
                thresholds=[2e1, 2e2, 2e3],
                path=tmp, file_name="t",
            )
        # EEG2/3/4 carry only 5 µV RMS background — band power in
        # 52–98 Hz must stay below the lowest threshold (20 µV²).
        for ch in ("EEG2", "EEG3", "EEG4"):
            assert ch not in bad, (
                f"{ch} (5 µV RMS background) must not trip "
                "noise_power thresholds. Got: " + str(bad))


class TestDocumentedContractMatchesImplementation:
    """The function docstring promises µV² thresholds — make sure that's
    what the code actually uses."""

    def test_bandpower_docstring_says_uv_squared(self):
        doc = BandPower.__doc__
        assert "μV^2" in doc or "µV^2" in doc or "µV²" in doc, (
            "BandPower's docstring should advertise µV² threshold "
            "units; if you change the units, update the docstring "
            "and the badchs_params defaults too.")
