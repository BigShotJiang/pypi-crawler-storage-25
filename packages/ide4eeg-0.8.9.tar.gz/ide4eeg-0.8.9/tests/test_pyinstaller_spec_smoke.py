"""PyInstaller spec smoke — every hidden import in the Windows specs
resolves against the current venv.

Locks the contract that **every name in `hiddenimports` is something
PyInstaller could plausibly bundle** -- i.e. it imports without
ModuleNotFoundError in the dev environment.  Catches:

- Stale entries left behind after a refactor (the import is dead).
- Typos in the spec file (`pickard` instead of `picard`).
- Optional-dep entries that became hard requirements.
- Drift in `collect_submodules` walks (e.g. a renamed package).

What this does NOT catch:

- The inverse case ("module X needed at frozen runtime but NOT in
  hiddenimports") -- only an actual `.exe --version` smoke catches
  that.  We rely on Windows CI's post-build smoke for it.
- Platform-specific imports that resolve on Windows but not macOS
  (e.g. `winreg`).  Filter via ``_ALLOWED_TO_MISS_LOCALLY`` below.

Skipped silently when PyInstaller isn't installed -- the dev venv
doesn't always carry it (only Windows CI does).
"""
from __future__ import annotations

import importlib

import pytest


pyinstaller_hooks = pytest.importorskip(
    "PyInstaller.utils.hooks",
    reason="PyInstaller not installed in this venv "
           "(typical for non-Windows-CI environments)")

collect_submodules = pyinstaller_hooks.collect_submodules


# Optional / platform-conditional / dynamic-load entries that may not
# import cleanly in this venv but are still correct to list in the
# spec for the Windows build.  Each entry has a short rationale; if
# you add to this list, document WHY.
_ALLOWED_TO_MISS_LOCALLY: dict[str, str] = {
    # Jupyter notebook backend.  MNE imports ipyevents only when
    # the user is in a notebook; the dev venv doesn't carry it.
    # Safe to leave in spec -- pyinstaller will only bundle it if
    # actually reachable from the dependency graph.
    "mne.viz.backends._notebook": "ipyevents (Jupyter-only)",
    # Windows-only runtime dep: download_tools.py imports it under
    # ``if sys.platform == 'win32'`` to unpack mpv's 7z archive on
    # first launch.  Declared in pyproject.toml with the matching
    # platform marker (`py7zr; sys_platform == 'win32'`), so it's
    # not installed in the macOS dev venv -- correctly.
    "py7zr": "win32-only (download_tools mpv unpack)",
}


def _build_lite_hiddenimports() -> list[str]:
    """Mirror the hiddenimports construction in ide4eeg-lite.spec.

    Kept in sync by hand -- if the spec changes, update here.  A
    drift-detection test below catches the case where the spec adds
    a NEW collect_submodules call this helper doesn't know about.
    """
    h: list[str] = []
    h += [
        "ide4eeg.analysis.eeg_profiles",
        "ide4eeg.analysis.dipole_analysis",
    ]
    for pkg in ("ide4eeg.input", "ide4eeg.preprocessing",
                "ide4eeg.analysis", "ide4eeg.plots", "ide4eeg.utils"):
        h += collect_submodules(pkg)
    h += [
        "ide4eeg.download_examples", "ide4eeg.download_tools",
        "ide4eeg.install_diagnostics", "ide4eeg.install_runner",
        "ide4eeg._appcds", "ide4eeg.api", "ide4eeg.references",
        "ide4eeg.gui_config",
    ]
    h += [
        "mne.io.brainvision.brainvision", "mne.io.edf.edf",
        "mne.io.eeglab.eeglab", "mne.io.fiff.raw", "mne.io.kit.kit",
        "mne.io.eyelink.eyelink", "mne.io.snirf",
        "mne.preprocessing.ica", "mne.preprocessing.eog",
        "mne.preprocessing.bads", "mne.minimum_norm.inverse",
        "mne.beamformer", "mne.dipole", "mne.viz._mpl_figure",
        "mne.viz.backends._notebook", "mne.viz.backends._utils",
        "mne.report.report", "mne.channels._standard_montage_utils",
    ]
    h += collect_submodules("mne.html_templates")
    h += collect_submodules("mne.utils")
    h += [
        "scipy._lib.messagestream", "scipy.special.cython_special",
        "scipy.spatial.transform._rotation_groups",
        "scipy.spatial._ckdtree", "scipy.stats._stats",
        "scipy.stats._continuous_distns",
        "scipy.signal._peak_finding_utils",
        "scipy.io.matlab._mio5_utils",
    ]
    h += [
        "joblib._parallel_backends", "joblib.externals.loky",
        "joblib.externals.loky.backend",
        "joblib.externals.loky.backend.spawn",
        "joblib.externals.loky.backend.context",
    ]
    h += [
        "matplotlib.backends.backend_qtagg",
        "matplotlib.backends.backend_agg",
        "matplotlib.backends.backend_qt5agg",
    ]
    h += ["PySide6.QtSvg", "PySide6.QtPrintSupport"]
    h += ["picard"]
    h += collect_submodules("obci_readmanager")
    h += ["psutil", "certifi", "py7zr", "send2trash"]
    return h


def test_all_lite_hidden_imports_resolve():
    """Every hidden import in the lite spec must either (a) import in
    this venv, or (b) be in ``_ALLOWED_TO_MISS_LOCALLY``.  A new
    unexpected-missing entry surfaces here so we can decide whether
    it's a stale spec entry (delete) or a new platform-only import
    (add to the allowlist with a rationale)."""
    hiddenimports = _build_lite_hiddenimports()
    fails: dict[str, str] = {}
    for name in sorted(set(hiddenimports)):
        try:
            importlib.import_module(name)
        except Exception as exc:
            fails[name] = f"{type(exc).__name__}: {exc}"
    unexpected = {
        name: msg for name, msg in fails.items()
        if name not in _ALLOWED_TO_MISS_LOCALLY
    }
    assert not unexpected, (
        "Hidden imports listed in ide4eeg-lite.spec that don't "
        "resolve and aren't in the allowlist:\n"
        + "\n".join(f"  {n}: {m}" for n, m in unexpected.items())
        + "\n\nEither delete from the spec (stale entry) or add to "
          "_ALLOWED_TO_MISS_LOCALLY in this test with a comment "
          "explaining why it's missing in dev.")


def test_lite_spec_collect_submodules_yields_nonempty():
    """Each ``collect_submodules`` call in the spec must yield at
    least one module -- an empty list means the package being walked
    is missing entirely and the entry is silently a no-op."""
    walked = {
        "mne.utils": collect_submodules("mne.utils"),
        "mne.html_templates": collect_submodules("mne.html_templates"),
        "obci_readmanager": collect_submodules("obci_readmanager"),
        "ide4eeg.input": collect_submodules("ide4eeg.input"),
        "ide4eeg.preprocessing":
            collect_submodules("ide4eeg.preprocessing"),
        "ide4eeg.analysis": collect_submodules("ide4eeg.analysis"),
        "ide4eeg.plots": collect_submodules("ide4eeg.plots"),
        "ide4eeg.utils": collect_submodules("ide4eeg.utils"),
    }
    empty = [pkg for pkg, mods in walked.items() if not mods]
    assert not empty, (
        f"collect_submodules() returned EMPTY for: {empty}. "
        "Either the package is missing or its layout changed; "
        "the spec entry is silently doing nothing.")
