"""Golden output test for the IDE4EEG pipeline.

Runs the shipped ``dipole_spindles`` example end-to-end with a 40 s
crop (first 2 of the 9 rest segments) and compares key numerical
outputs against a fixture committed to
``tests/fixtures/golden/dipole_spindles_2seg.json``.

This is the safety net for the architecture refactor: every commit
that touches pipeline plumbing must keep these hashes stable.  If a
commit changes pipeline output, that's a *deliberate* decision the
author must verify by hand, then regenerate the fixture.

Run (gated behind an env var because MP + dipole-fit costs ~50 s):

    RUN_SLOW_GOLDENS=1 pytest tests/test_pipeline_golden.py -v

Regenerate the fixture after a deliberate change:

    RUN_SLOW_GOLDENS=1 GOLDEN_REGEN=1 pytest tests/test_pipeline_golden.py

The fixture is plain JSON so a regen diff is human-readable in
review.  The test skips cleanly if the example data isn't downloaded.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import tomllib
from pathlib import Path

import pytest


_EXAMPLES = Path.home() / "IDE4EEG_examples" / "dipole_spindles"
_INPUT = _EXAMPLES / "dipoles_example.raw"
_CONFIG = _EXAMPLES / "config_dipole_spindles.toml"
_FIXTURES = Path(__file__).parent / "fixtures" / "golden"
_FIXTURE_NAME = "dipole_spindles_2seg"

_REGEN = os.environ.get("GOLDEN_REGEN") == "1"
_RUN_SLOW = os.environ.get("RUN_SLOW_GOLDENS") == "1"


def _hash_array(arr) -> str:
    """Stable SHA-256 of a numpy array's bytes + dtype + shape."""
    h = hashlib.sha256()
    h.update(str(arr.dtype).encode())
    h.update(str(arr.shape).encode())
    h.update(arr.tobytes())
    return h.hexdigest()


def _hash_dataframe(df) -> str:
    """Stable SHA-256 of a DataFrame as CSV bytes."""
    return hashlib.sha256(df.to_csv(index=False).encode()).hexdigest()


def _collect_pipeline_summary(results) -> dict:
    """Reduce a Results namedtuple to a JSON-stable summary dict."""
    summary: dict = {}
    for slot in ("rest", "rest_clean", "epochs", "epochs_clean"):
        ep = getattr(results, slot)
        if ep is None:
            summary[slot] = None
            continue
        data = ep.get_data(copy=False)
        summary[slot] = {
            "shape": list(data.shape),
            "data_sha256": _hash_array(data),
            "events_shape": list(ep.events.shape),
            "events_sha256": _hash_array(ep.events),
            "event_ids": dict(sorted(ep.event_id.items())),
            "ch_names": list(ep.ch_names),
            "sfreq": float(ep.info["sfreq"]),
        }
    summary["data"] = {
        "shape": list(results.data.shape),
        "columns": list(results.data.columns),
        "sha256": _hash_dataframe(results.data),
    }
    summary["tags_desc_id"] = dict(sorted(results.tags_desc_id.items()))
    return summary


def _hash_dipole_csv(path: Path) -> dict | None:
    """Hash the per-atom dipole CSV (number of rows + content hash).

    Captures the analysis-stage output too — without this, the golden
    only covers preprocessing and would miss regressions in the dipole
    backend (e.g. amp filter wiring, see project_dipole_amp_filter_handoff).
    """
    if not path.is_file():
        return None
    data = path.read_text()
    n_rows = max(0, data.count("\n") - 1)  # subtract header
    return {"n_rows": n_rows,
            "sha256": hashlib.sha256(data.encode()).hexdigest()}


def _fixture_path(name: str) -> Path:
    return _FIXTURES / f"{name}.json"


def _load_or_regen(name: str, summary: dict) -> dict | None:
    """Return *expected*; write fixture and return None when regen=True
    or fixture is missing."""
    fixture = _fixture_path(name)
    if _REGEN or not fixture.is_file():
        fixture.parent.mkdir(parents=True, exist_ok=True)
        fixture.write_text(json.dumps(summary, indent=2, sort_keys=True))
        return None
    return json.loads(fixture.read_text())


# ── Test ──────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _require_example_data():
    """Skip cleanly if the example data isn't on disk or the slow-run
    gate isn't set.  ``GOLDEN_REGEN=1`` implies ``RUN_SLOW_GOLDENS=1``
    (regenerating without running is a contradiction) so a user can
    just type ``GOLDEN_REGEN=1 pytest …`` without needing both flags.
    """
    if not (_RUN_SLOW or _REGEN):
        pytest.skip("Set RUN_SLOW_GOLDENS=1 to enable (~50 s on 8 cores).")
    if not _INPUT.is_file():
        pytest.skip(
            f"Example data not at {_INPUT}; "
            f"run `python -m ide4eeg.download_examples dipole_spindles`.")


def test_dipole_spindles_2seg_golden(tmp_path):
    """Truncated dipole_spindles pipeline (2 segments) — full golden.

    Overrides ``rest.rest_duration`` to ``[0, 40]`` so only the first
    two 20 s windows are extracted.  Everything else (resample to
    128 Hz, MMP1 with 50 iterations, dipole fit) is exactly the
    shipped example.  Locks: preprocessing + per-tag DataFrame +
    dipole CSV row count and content hash.
    """
    with open(_CONFIG, "rb") as f:
        cfg = tomllib.load(f)
    cfg.pop("input_path", None)
    cfg.pop("output_path", None)
    cfg["rest"] = {**cfg.get("rest", {}), "rest_duration": [0, 40]}

    from ide4eeg.api import run_file
    out = tmp_path / "out"
    results = run_file(str(_INPUT), output_path=str(out), **cfg)

    summary = _collect_pipeline_summary(results)
    # Hunt for the dipole CSV — its exact path lives under
    # IDE4EEG_OUT_dipoles_example/analysis/dipole_analysis/.
    csv_candidates = list(out.rglob("*___dipoles.csv"))
    summary["dipole_csv"] = (
        _hash_dipole_csv(csv_candidates[0]) if csv_candidates else None)

    expected = _load_or_regen(_FIXTURE_NAME, summary)
    if expected is None:
        pytest.skip("Regenerated fixture; re-run without GOLDEN_REGEN "
                    "to compare.")
    assert summary == expected, (
        "Pipeline output drifted from golden fixture.  Inspect the "
        "diff; if intentional, regen via "
        "`RUN_SLOW_GOLDENS=1 GOLDEN_REGEN=1 pytest "
        "tests/test_pipeline_golden.py`.")
