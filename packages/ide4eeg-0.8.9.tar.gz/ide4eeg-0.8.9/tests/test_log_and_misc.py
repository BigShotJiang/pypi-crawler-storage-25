"""Tests for utilities, logging, and edge-case bug fixes."""

import logging

import numpy as np
import pytest


# ── LogColors / LevelFormatter ──────────────────────────────────────


class TestLogColors:
    """Tests for the colored logging formatter."""

    def test_color_lookup_for_each_level(self):
        from ide4eeg.utils.log import LogColors
        for level in (logging.DEBUG, logging.INFO, logging.WARNING,
                      logging.ERROR, logging.CRITICAL):
            assert level in LogColors.COLORS

    def test_info_is_green(self):
        from ide4eeg.utils.log import LogColors
        assert "\033[92m" in LogColors.COLORS[logging.INFO]

    def test_error_is_red(self):
        from ide4eeg.utils.log import LogColors
        assert "\033[91m" in LogColors.COLORS[logging.ERROR]

    def test_debug_has_no_color(self):
        from ide4eeg.utils.log import LogColors
        assert LogColors.COLORS[logging.DEBUG] == ""

    def test_endc_resets_color(self):
        from ide4eeg.utils.log import LogColors
        assert LogColors.ENDC == "\033[0m"


class TestLevelFormatter:
    """Tests for the custom log formatter."""

    def _make_record(self, level, msg="test"):
        return logging.LogRecord(
            name="test", level=level, pathname="", lineno=0,
            msg=msg, args=(), exc_info=None)

    def test_debug_includes_timestamp(self):
        from ide4eeg.utils.log import LevelFormatter
        fmt = LevelFormatter("%(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        output = fmt.format(self._make_record(logging.DEBUG, "hello"))
        assert "DEBUG" in output
        assert "hello" in output

    def test_info_includes_color_and_level(self):
        from ide4eeg.utils.log import LevelFormatter
        fmt = LevelFormatter("%(message)s")
        output = fmt.format(self._make_record(logging.INFO, "msg"))
        assert "INFO" in output
        assert "msg" in output

    def test_error_includes_color_code(self):
        from ide4eeg.utils.log import LevelFormatter
        fmt = LevelFormatter("%(message)s")
        output = fmt.format(self._make_record(logging.ERROR, "oops"))
        assert "\033[91m" in output
        assert "oops" in output

    def test_setup_logging_does_not_crash(self):
        from ide4eeg.utils.log import setup_logging
        setup_logging(level=logging.WARNING)


# ── Artifact edge cases ─────────────────────────────────────────────


class TestArtifactEdgeCases:
    """Tests for the artifacts.py empty-data guard."""

    def test_art_tags_writer_empty_bad_samples(self):
        """ArtTagsWriter() with empty bad_samples returns early."""
        from ide4eeg.preprocessing.artifacts import ArtTagsWriter
        desc, occ = ArtTagsWriter(
            bad_samples={}, Fs=256.0, doc_channels=[],
            MergWin=0.0, ArtName="test", Thresholds=np.inf,
            MinDuration=0.0)
        assert desc == []
        assert occ.size == 0

    def test_art_tags_writer_uses_doc_channel_indices(self):
        """``channelNumber`` is the index in ``doc_channels`` (the
        saved -raw.fif's ch_names) -- NOT the pre-drop input
        channel set.

        Regression: when ``chosen_channels`` reduces 23 channels to
        5, tags built off the original 23-name list crashed Svarog
        with ``IndexOutOfBoundsException`` because the post-drop
        document only has 5 source channels.  See log_svarog.txt
        in the bug report.
        """
        import numpy as np
        from ide4eeg.preprocessing.artifacts import ArtTagsWriter
        # Document Svarog will display: 5 channels (post-drop).
        doc_channels = ["Fp1", "Fp2", "F7", "C7", "STIM"]
        # Two artifacts on F7 and C7.
        n_samples = 1000
        bad_samples = {
            "F7": np.zeros(n_samples, dtype=np.int8),
            "C7": np.zeros(n_samples, dtype=np.int8),
        }
        bad_samples["F7"][100:200] = 1
        bad_samples["C7"][500:600] = 1
        descs, _ = ArtTagsWriter(
            bad_samples, Fs=100, doc_channels=doc_channels,
            MergWin=0.1, ArtName="outlier")
        # Each tag's channelNumber must be a valid index into the
        # 5-channel document, not into a longer original list.
        for d in descs:
            ch_idx = int(d["channelNumber"])
            assert 0 <= ch_idx < len(doc_channels), \
                f"channelNumber {ch_idx} out of range for "\
                f"{len(doc_channels)} doc channels"
            # And it must point at the right channel name.
            assert doc_channels[ch_idx] == d["desc"]["ch"], \
                f"channelNumber {ch_idx} -> "\
                f"{doc_channels[ch_idx]!r}, expected "\
                f"{d['desc']['ch']!r}"


# ── rest_and_epochs STIM guard ──────────────────────────────────────


class TestCutSegmentsGuard:
    """``_cut_segments`` raises a clear error when no segment-boundary
    events are present (rest mode: missing REST annotations *and*
    legacy STIM_rest channel)."""

    def test_missing_rest_events_raises(self):
        import mne
        from ide4eeg.preprocessing.rest_and_epochs import _cut_segments
        # Raw with only EEG channels — no REST annotations, no
        # STIM_rest fallback channel.
        info = mne.create_info(ch_names=["Cz"], sfreq=256, ch_types=["eeg"])
        raw = mne.io.RawArray(np.random.randn(1, 2560), info)
        config = {"segmentation": {"mode": "rest"},
                  "rest": {"window_length": 5}}
        with pytest.raises(RuntimeError, match="REST annotations"):
            _cut_segments(raw, config, {"rest": 1})


# ── plots cluster test guard ────────────────────────────────────────


class TestPlotClusterTestGuard:
    """Test that plot_cluster_test handles insufficient event types."""

    def test_single_event_type_returns_early(self):
        """With only 1 event type, cluster test plot is skipped."""
        import mne
        from ide4eeg.plots.plots import plot_cluster_test
        info = mne.create_info(ch_names=["Cz"], sfreq=256, ch_types=["eeg"])
        erps = {"P300": np.random.randn(1, 100)}
        # Should not raise — just returns early
        plot_cluster_test(
            erps=erps, erps_num={"P300": 10},
            clusters=[], clusters_p_values=np.array([]),
            epochs_info=info,
            config={"epochs": {"start_offset": -0.2, "stop_offset": 0.8}},
            file_name="test.fif", output_path="/tmp")

    def test_empty_erps_returns_early(self):
        """Empty erps dict should not crash."""
        import mne
        from ide4eeg.plots.plots import plot_cluster_test
        info = mne.create_info(ch_names=["Cz"], sfreq=256, ch_types=["eeg"])
        plot_cluster_test(
            erps={}, erps_num={},
            clusters=[], clusters_p_values=np.array([]),
            epochs_info=info,
            config={"epochs": {"start_offset": -0.2, "stop_offset": 0.8}},
            file_name="test.fif", output_path="/tmp")
