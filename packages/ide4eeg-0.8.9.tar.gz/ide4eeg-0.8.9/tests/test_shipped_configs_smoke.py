"""Shipped-config smoke — every TOML under ``examples/`` round-trips
through ``validate_config`` cleanly.

Locks the contract that **every config shipped in the repo is itself
schema-clean**.  If we ever rename a top-level key without also
updating the shipped configs, this lights up before users hit it.

Two flavours, since ``examples/<name>/`` typically holds both a
pipeline config and a manifest:

- Pipeline configs (``config_<name>.toml``): validate cleanly, NO
  issues, NOT detected as a manifest.
- Manifests (``example.toml``): correctly detected by
  ``is_examples_manifest`` and refused by ``validate_config`` with
  the proper exception type and a message naming the manifest's
  configs.

Together these cover the "stale shipped TOML" failure class.
"""
from __future__ import annotations

import tomllib
from pathlib import Path

import pytest

from ide4eeg.config_schema import (
    ConfigIsExamplesManifestError,
    is_examples_manifest,
    validate_config,
)


_REPO_ROOT = Path(__file__).resolve().parent.parent
_EXAMPLES_DIR = _REPO_ROOT / "examples"


def _all_shipped_tomls() -> list[Path]:
    """Every ``.toml`` tracked under ``examples/``.

    Sorted for deterministic test discovery / readable failure output.
    """
    if not _EXAMPLES_DIR.is_dir():
        return []
    return sorted(_EXAMPLES_DIR.rglob("*.toml"))


_SHIPPED = _all_shipped_tomls()

# Parametrise per file so pytest reports each one separately; one
# bad TOML doesn't mask the others.
_PIPELINE_CONFIGS = [p for p in _SHIPPED
                     if p.name.startswith("config_")]
_MANIFESTS = [p for p in _SHIPPED
              if p.name == "example.toml"]


@pytest.mark.parametrize("cfg_path", _PIPELINE_CONFIGS,
                         ids=lambda p: p.relative_to(_REPO_ROOT).as_posix())
def test_shipped_pipeline_config_validates_clean(cfg_path):
    """Every ``examples/*/config_*.toml`` must validate without issues
    on the current schema.  A failure means we renamed / dropped a
    cfg field but forgot to update the shipped example."""
    with open(cfg_path, "rb") as f:
        cfg = tomllib.load(f)
    # Sanity: shouldn't be flagged as a manifest.
    assert not is_examples_manifest(cfg), (
        f"{cfg_path.name} matched the manifest signature; rename "
        "or restructure -- pipeline configs must not carry a "
        "[[configs]] array with `file` keys.")
    issues = validate_config(cfg, source=str(cfg_path))
    assert issues == [], (
        f"{cfg_path.relative_to(_REPO_ROOT)} produced schema issues:\n"
        + "\n".join(f"  [{i.severity}] {i.key_path}: {i.message}"
                    for i in issues))


@pytest.mark.parametrize("manifest_path", _MANIFESTS,
                         ids=lambda p: p.relative_to(_REPO_ROOT).as_posix())
def test_shipped_manifest_detected_and_refused(manifest_path):
    """Every ``examples/*/example.toml`` must be detected as a manifest
    and refused by ``validate_config`` -- the UX guard added after
    v0.8.8.  Locks both the detector and the error-message shape so a
    future refactor doesn't silently drop the guard."""
    with open(manifest_path, "rb") as f:
        manifest = tomllib.load(f)
    assert is_examples_manifest(manifest), (
        f"{manifest_path.name} not detected as a manifest -- the "
        "`[[configs]]` array signature must be intact.")
    with pytest.raises(ConfigIsExamplesManifestError) as exc_info:
        validate_config(manifest, source=str(manifest_path))
    msg = str(exc_info.value)
    # The remediation must list at least one of the referenced
    # configs (otherwise the user gets a useless "not a config"
    # message with no actionable next step).
    referenced = [c["file"] for c in manifest["configs"]]
    assert any(ref in msg for ref in referenced), (
        f"manifest exception didn't list any referenced config:\n"
        f"  expected one of: {referenced}\n  message: {msg!r}")


def test_at_least_one_shipped_example_present():
    """Sanity: don't let the parametrize lists silently collapse to
    empty.  If examples/ is moved or deleted, this test fails loudly
    instead of the parametrize quietly producing zero cases."""
    assert _PIPELINE_CONFIGS, "no shipped pipeline configs found"
    assert _MANIFESTS, "no shipped manifests found"
