"""Comprehensive tests covering edge cases and less-tested paths.

Adds tests for:
- Epochs mode pipeline (CLI + generated script)
- Preprocessing steps individually
- Config edge cases (empty strings, None values, missing sections)
- API individual step wrappers
- Signal loading for different formats
- MP book metadata reading
- Artifact tag writing
- EEG Profiles structure detection
- Sleep staging epoch features
- Connectivity data class
- Various GUI helper functions
"""

import copy
import os
import subprocess
import sys
import tempfile

import numpy as np
import mne
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---------------------------------------------------------------------------
# Signal creation helpers
# ---------------------------------------------------------------------------

def _make_raw(n_channels=5, sfreq=256, duration=10.0, with_stim=True):
    """Create a simple test Raw object."""
    n_samples = int(sfreq * duration)
    data = np.random.randn(n_channels, n_samples) * 10e-6
    ch_names = [f"EEG{i+1}" for i in range(n_channels)]
    ch_types = ["eeg"] * n_channels
    if with_stim:
        stim = np.zeros((1, n_samples))
        stim[0, 0] = 1
        data = np.vstack([data, stim])
        ch_names.append("STIM")
        ch_types.append("stim")
    info = mne.create_info(ch_names, sfreq, ch_types)
    return mne.io.RawArray(data, info, verbose=False)


# ---------------------------------------------------------------------------
# Preprocessing step tests
# ---------------------------------------------------------------------------

class TestPreprocessingSteps:
    """Test individual preprocessing steps with synthetic data."""

    def test_resample(self):
        from ide4eeg.preprocessing.channels_and_signal import _resample_signal
        raw = _make_raw(sfreq=512)
        config = {"resample_freq": 256}
        resampled = _resample_signal(raw, config)
        assert resampled.info["sfreq"] == 256
        assert resampled.n_times < raw.n_times

    def test_trim_signal(self):
        from ide4eeg.preprocessing.channels_and_signal import _trim_signal
        raw = _make_raw(sfreq=256, duration=10.0)
        config = {"trim_start": 2.0, "trim_end": 8.0}
        trimmed, _ = _trim_signal(raw, config)
        # Should be ~6 seconds
        assert 5.5 < trimmed.times[-1] - trimmed.times[0] < 6.5

    def test_filter_fir(self):
        from ide4eeg.preprocessing.channels_and_signal import _filter_signal
        raw = _make_raw(sfreq=256)
        config = {
            "filters": {
                "method": "fir",
                "highpass_freq": 1.0,
                "lowpass_freq": 30.0,
                "notch_freq": 0,
                "show_filt": False,
                "plot_filt": False,
            }
        }
        with tempfile.TemporaryDirectory() as tmp:
            filtered = _filter_signal(raw, config, tmp)
        assert filtered.info["highpass"] == 1.0
        assert filtered.info["lowpass"] == 30.0

    def test_select_channels(self):
        from ide4eeg.preprocessing.channels_and_signal import _select_channels
        raw = _make_raw(n_channels=5)
        config = {
            "choosing_channels": {
                "selected_channels": ["EEG1", "EEG3", "EEG5"],
                "dropped_channels": [],
                "check_final_channels": False,
            }
        }
        tags = {"rest": 1}
        result = _select_channels([raw], tags, config)
        signal = result[0] if isinstance(result, list) else result
        eeg_names = [ch for ch in signal.info["ch_names"] if ch != "STIM"]
        assert eeg_names == ["EEG1", "EEG3", "EEG5"]


# ---------------------------------------------------------------------------
# Config edge cases
# ---------------------------------------------------------------------------

class TestConfigEdgeCases:
    """Test pipeline config handling with unusual values."""

    def test_empty_string_trim_end(self):
        """trim_end='' should be treated as None (no trimming)."""
        from ide4eeg.preprocessing.channels_and_signal import _trim_signal
        raw = _make_raw(sfreq=256, duration=10.0)
        config = {"trim_start": 0.0, "trim_end": ""}
        trimmed, _ = _trim_signal(raw, config)
        # Should keep full signal
        assert trimmed.n_times == raw.n_times

    def test_check_and_prepare_with_all_sections(self):
        """Full config with all sections should not crash."""
        from ide4eeg.input.input import check_and_prepare_config
        from ide4eeg.gui_config import DEFAULT_CONFIG
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["input_path"] = "/tmp/test.fif"
        # Remove internal keys
        cfg = {k: v for k, v in cfg.items() if not k.startswith("_")}
        check_and_prepare_config(cfg)
        assert "choosing_channels" in cfg
        assert "artifacts" in cfg

    def test_check_and_prepare_minimal_epochs(self):
        """Minimal epochs config should get all defaults."""
        from ide4eeg.input.input import check_and_prepare_config
        cfg = {
            "input_path": "/tmp/test.fif",
            "segmentation": {"mode": "epochs"},
        }
        check_and_prepare_config(cfg)
        assert "reject_dict" in cfg["epochs"]
        assert "flat_dict" in cfg["epochs"]


# ---------------------------------------------------------------------------
# API individual step wrappers
# ---------------------------------------------------------------------------

class TestAPIWrappers:
    """Test ide4eeg.api individual step functions."""

    def test_resample_signal(self):
        from ide4eeg.api import resample_signal
        raw = _make_raw(sfreq=512)
        result = resample_signal(raw, freq=256)
        assert result.info["sfreq"] == 256

    def test_trim_signal(self):
        from ide4eeg.api import trim_signal
        raw = _make_raw(sfreq=256, duration=10.0)
        result = trim_signal(raw, start=2.0, end=8.0)
        assert 5.5 < result.times[-1] < 6.5

    def test_filter_signal(self):
        from ide4eeg.api import filter_signal
        raw = _make_raw(sfreq=256)
        result = filter_signal(raw, highpass=1.0, lowpass=30.0)
        assert result.info["highpass"] == 1.0


# ---------------------------------------------------------------------------
# MP book metadata
# ---------------------------------------------------------------------------

class TestMPBookMetadata:
    """Test MP book reading functions."""

    def test_build_empi_cmd_smp(self):
        from ide4eeg.analysis.mp_analysis import _build_empi_cmd
        cmd = _build_empi_cmd(
            "/usr/bin/empi", "/tmp/in.bin", "/tmp/out.db",
            sfreq=512, n_channels=3,
            mp_cfg={"algorithm": "smp", "iterations": 30,
                    "explained_energy": 0.95})
        assert "-c" in cmd and "3" in cmd
        assert "-f" in cmd and "512" in cmd
        assert "-i" in cmd and "30" in cmd

    def test_build_empi_cmd_mmp1(self):
        from ide4eeg.analysis.mp_analysis import _build_empi_cmd
        cmd = _build_empi_cmd(
            "/usr/bin/empi", "/tmp/in.bin", "/tmp/out.db",
            sfreq=128, n_channels=20,
            mp_cfg={"algorithm": "mmp1"})
        assert "--mmp1" in cmd

    def test_build_empi_cmd_mmp3(self):
        from ide4eeg.analysis.mp_analysis import _build_empi_cmd
        cmd = _build_empi_cmd(
            "/usr/bin/empi", "/tmp/in.bin", "/tmp/out.db",
            sfreq=128, n_channels=20,
            mp_cfg={"algorithm": "mmp3"})
        assert "--mmp3" in cmd

    def test_build_empi_cmd_unknown_algorithm_raises(self):
        from ide4eeg.analysis.mp_analysis import _build_empi_cmd
        with pytest.raises(ValueError, match="Unknown MP algorithm"):
            _build_empi_cmd(
                "/usr/bin/empi", "/tmp/in.bin", "/tmp/out.db",
                sfreq=128, n_channels=20,
                mp_cfg={"algorithm": "mmp42"})


class TestClassifyChannelTypePolicy:
    """_classify_channel_type is a thin policy layer around readmanager's
    chtype_heuristic. Its only job is to decide whether to delegate to
    readmanager (for generic reader types like 'eeg') or respect the
    reader's specific assignment (for 'eog', 'ecg', 'misc', etc.).

    The classification rules themselves live in readmanager and are
    tested there — see test/signal_processing/test_chtype_heuristic.py
    in the readmanager repo. These tests focus only on the policy.
    """

    def test_specific_types_respected(self):
        """If the reader assigned a specific type, return it unchanged."""
        from ide4eeg.input.input import _classify_channel_type
        # FIF authoritative eog
        assert _classify_channel_type("Fp1", "eog") == "eog"
        # Reader said 'ecg' — respect it even though Fp1 would be eeg
        assert _classify_channel_type("Fp1", "ecg") == "ecg"
        # Exotic types that IDE4EEG doesn't itself produce
        assert _classify_channel_type("random", "seeg") == "seeg"
        assert _classify_channel_type("random", "fnirs") == "fnirs"
        assert _classify_channel_type("random", "dbs") == "dbs"
        # MEG types
        assert _classify_channel_type("random", "mag") == "mag"
        assert _classify_channel_type("random", "grad") == "grad"

    def test_misc_is_respected_not_delegated(self):
        """'misc' from any reader means 'deliberately unclassified' and
        should be left alone. This matters for FIF files whose author
        explicitly flagged a channel as misc — the overlay must not
        second-guess that decision.

        Contrast with readmanager 1.3.x where 'misc' was readmanager's
        fallback type and IDE4EEG's older overlay used to refine it.
        Post-readmanager 1.4.0, any 'misc' is authoritative.
        """
        from ide4eeg.input.input import _classify_channel_type
        assert _classify_channel_type("Fp1", "misc") == "misc"
        # Even for names that look EOG/ECG/etc., misc wins
        assert _classify_channel_type("EOG Left", "misc") == "misc"
        assert _classify_channel_type("ECG lead", "misc") == "misc"

    def test_generic_eeg_delegates_to_readmanager(self):
        """MNE's EDF/BDF reader defaults every channel to 'eeg'
        regardless of name. The overlay must delegate these to
        readmanager so polysomnography channels (EOG/EMG/ECG/...)
        are correctly re-classified."""
        from ide4eeg.input.input import _classify_channel_type
        assert _classify_channel_type("EOG Left Horiz", "eeg") == "eog"
        assert _classify_channel_type("EMG Chin1", "eeg") == "emg"
        assert _classify_channel_type("ECG ECGI", "eeg") == "ecg"
        assert _classify_channel_type("Resp Thermistor", "eeg") == "bio"
        # Positive EEG via tokenized 10-05 (new in readmanager 1.4.0)
        assert _classify_channel_type("EEG F3-CLE", "eeg") == "eeg"
        # Bare 10-05 position still matches
        assert _classify_channel_type("Fp1", "eeg") == "eeg"

    def test_none_and_empty_initial(self):
        """None / "" as initial type means 'no info from reader' —
        delegate to readmanager."""
        from ide4eeg.input.input import _classify_channel_type
        assert _classify_channel_type("Fp1", None) == "eeg"
        assert _classify_channel_type("Fp1", "") == "eeg"
        assert _classify_channel_type("EOG Left", None) == "eog"

    def test_reader_eeg_not_demoted_to_misc(self):
        """The MNE FIF reader authoritatively types channels as 'eeg',
        but their names (e.g. ``"EEG 001"`` in the MNE sample data) may
        not match readmanager's 10-20 position lookup and would otherwise
        come back as 'misc' — which would strip every EEG channel from
        the pipeline and break re-reference / ICA.  The policy must
        keep the reader's 'eeg' whenever the heuristic has no positive
        non-EEG evidence."""
        from ide4eeg.input.input import _classify_channel_type
        # MNE sample-data naming
        assert _classify_channel_type("EEG 001", "eeg") == "eeg"
        assert _classify_channel_type("EEG 060", "eeg") == "eeg"
        # Any opaque scalp-channel name the heuristic can't place:
        # trust the reader rather than silently demoting.
        assert _classify_channel_type("Sensor_17", "eeg") == "eeg"
        # Regression guard: positive non-EEG hits must still override.
        assert _classify_channel_type("EOG 061", "eeg") == "eog"
        assert _classify_channel_type("STI 014", "eeg") == "stim"


class TestRefineChannelTypes:
    """Direct coverage for _refine_channel_types — the MNE-Raw
    plumbing layer that applies _classify_channel_type in place."""

    def _make_raw(self, names, types):
        """Build a tiny RawArray with the given channel names and
        initial types."""
        info = mne.create_info(
            ch_names=list(names), sfreq=256.0, ch_types=list(types))
        data = np.zeros((len(names), 10))
        return mne.io.RawArray(data, info, verbose=False)

    def test_refines_edf_default_all_eeg(self):
        """Simulate EDF's default (everything is 'eeg'): the overlay
        must refine EOG/EMG/ECG/Resp/SaO2 channels to specific types."""
        from ide4eeg.input.input import _refine_channel_types
        names = ["Fp1", "EOG Left Horiz", "EMG Chin1",
                 "ECG ECGI", "Resp Belt Thor", "SaO2 SaO2"]
        raw = self._make_raw(names, ["eeg"] * len(names))
        _refine_channel_types(raw)
        assert raw.get_channel_types() == [
            "eeg", "eog", "emg", "ecg", "bio", "bio"]

    def test_misc_preserved_not_delegated(self):
        """After readmanager 1.4.0, 'misc' from any source means
        'deliberately unclassified' and the overlay respects it.
        Even names that would otherwise match a non-EEG pattern are
        left as-is when the initial type is misc."""
        from ide4eeg.input.input import _refine_channel_types
        names = ["F3", "ECG ECGI", "Resp Thermistor", "UnknownAux"]
        types = ["eeg", "misc", "misc", "misc"]
        raw = self._make_raw(names, types)
        _refine_channel_types(raw)
        # F3 stays eeg (delegated, readmanager returns eeg). Everything
        # else was misc and stays misc (not delegated).
        assert raw.get_channel_types() == [
            "eeg", "misc", "misc", "misc"]

    def test_specific_types_preserved(self):
        """If the file reader assigned specific types, don't touch them."""
        from ide4eeg.input.input import _refine_channel_types
        names = ["Fp1", "VEOG", "HEOG", "ECG lead1", "M1"]
        types = ["eeg", "eog", "eog", "ecg", "eeg"]
        raw = self._make_raw(names, types)
        _refine_channel_types(raw)
        # All unchanged — reader's types respected
        assert raw.get_channel_types() == types

    def test_no_changes_no_mne_call(self):
        """When nothing needs refining, set_channel_types is not called
        at all (micro-perf and avoids spurious side effects)."""
        from unittest.mock import patch
        from ide4eeg.input.input import _refine_channel_types
        raw = self._make_raw(["Fp1", "Fp2", "Cz"], ["eeg", "eeg", "eeg"])
        with patch.object(raw, "set_channel_types") as mock_set:
            _refine_channel_types(raw)
        mock_set.assert_not_called()

    def test_returns_same_raw_for_chaining(self):
        from ide4eeg.input.input import _refine_channel_types
        raw = self._make_raw(["Fp1", "EOG"], ["eeg", "eeg"])
        assert _refine_channel_types(raw) is raw

    def test_no_runtime_warnings_on_refinement(self):
        """Promoting an EDF-defaulted 'eeg' channel to a non-EEG type
        (e.g. 'ecg', 'bio') must not trigger any RuntimeWarning. The
        warning filter inside _refine_channel_types catches MNE's
        'unit has changed' warning for any transition where the unit
        assumption changes."""
        import warnings
        from ide4eeg.input.input import _refine_channel_types
        # EDF-style: everything defaults to 'eeg', overlay refines
        raw = self._make_raw(
            ["Fp1", "ECG ECGI", "Resp Belt"], ["eeg", "eeg", "eeg"])
        with warnings.catch_warnings():
            warnings.simplefilter("error")  # any warning → test fails
            _refine_channel_types(raw)
        assert raw.get_channel_types() == ["eeg", "ecg", "bio"]


class TestBrainTechChannelTyping:
    """End-to-end regression tests for the MASS PSG bug:
    polysomnography files used to show 31/32 channels checked after
    clicking "EEG only" because read_file_info typed every channel
    as "eeg". Fix landed in readmanager 1.4.0 (rich chtype_heuristic)
    plus an IDE4EEG overlay that delegates generic types to
    readmanager's name classifier.

    These tests check the IDE4EEG-side integration; the underlying
    classification rules are tested in readmanager's
    test_chtype_heuristic.py.
    """

    def test_read_file_info_types_match_overlay(self):
        """On the minimal dataset_I fixture, verify read_file_info
        returns types consistent with what _classify_channel_type
        independently produces — pins the contract that the BrainTech
        info path goes through the overlay rather than fabricating."""
        from ide4eeg.input.input import (
            _classify_channel_type, read_file_info)
        import os
        fixture = os.path.join(
            os.path.dirname(__file__), "..",
            "_unreleased", "examples", "tfstat_data", "dataset_I.obci.raw")
        if not os.path.isfile(fixture):
            pytest.skip(f"Fixture not found: {fixture}")
        info = read_file_info(fixture)
        # Last channel is always synthetic "STIM" with type "stim"
        assert info["ch_names"][-1] == "STIM"
        assert info["ch_types"][-1] == "stim"
        # Each non-STIM channel must match the overlay's decision
        # (which delegates to readmanager.chtype_heuristic)
        for name, t in zip(info["ch_names"][:-1], info["ch_types"][:-1]):
            expected = _classify_channel_type(name, "")
            assert t == expected, \
                (f"read_file_info typed {name!r} as {t!r} but "
                 f"_classify_channel_type says {expected!r}")

    def test_mass_psg_full_channel_list_end_to_end(self):
        """Simulate the full 32-channel MASS PSG recording via the
        overlay. Pass each name through _classify_channel_type with
        the initial type the reader would have given (generic 'eeg'
        for MNE readers, delegated to readmanager 1.4.0), and verify
        the final types match the MASS expectations."""
        from ide4eeg.input.input import _classify_channel_type
        mass_cases = [
            ("EOG Left Horiz", "eog"),
            ("EOG Right Horiz", "eog"),
            ("EMG Chin1", "emg"),
            ("EMG Chin2", "emg"),
            ("EMG Chin3", "emg"),
            ("F3", "eeg"),
            ("F4", "eeg"),
            ("C3", "eeg"),
            ("C4", "eeg"),
            ("O1", "eeg"),
            ("O2", "eeg"),
            ("ECG ECGI", "ecg"),
            ("EMG Ant Tibia-0", "emg"),
            ("EMG Ant Tibia-1", "emg"),
            ("Resp Thermistor", "bio"),
            ("Resp Cannula", "bio"),
            ("Resp Belt Thor", "bio"),
            ("Resp Belt Abdo", "bio"),
            ("F7", "eeg"),
            ("F8", "eeg"),
            ("T3", "eeg"),
            ("T4", "eeg"),
            ("T5", "eeg"),
            ("T6", "eeg"),
            ("P3", "eeg"),
            ("P4", "eeg"),
            ("Fz", "eeg"),
            ("Cz", "eeg"),
            ("Pz", "eeg"),
            ("A2", "eeg"),
            ("SaO2 SaO2", "bio"),
        ]
        for name, expected in mass_cases:
            actual = _classify_channel_type(name, "eeg")
            assert actual == expected, \
                f"{name!r} → {actual!r}, expected {expected!r}"
        # Sanity: 18 EEG channels out of the 31 real channels
        eeg_count = sum(1 for _, t in mass_cases if t == "eeg")
        assert eeg_count == 18

    def test_edf_prefixed_names_recognized(self):
        """EDF's MASS-style EEG channels use an 'EEG ' prefix and
        '-CLE' suffix: 'EEG F3-CLE' etc. These require readmanager's
        1.4.0 tokenised 10-05 lookup to be recognised as EEG."""
        from ide4eeg.input.input import _classify_channel_type
        edf_cases = [
            ("EEG F3-CLE", "eeg"),
            ("EEG C3-CLE", "eeg"),
            ("EEG O1-CLE", "eeg"),
            ("EEG A2-CLE", "eeg"),
            ("EEG Fp1-M2", "eeg"),  # referenced against M2
            ("F3-CAR", "eeg"),       # common average reference suffix
        ]
        for name, expected in edf_cases:
            actual = _classify_channel_type(name, "eeg")
            assert actual == expected, \
                f"EDF-style: {name!r} → {actual!r}, expected {expected!r}"


class TestChannelTypeOverrides:
    """User-specified channel type overrides — the config-level
    escape hatch for channels the automatic heuristic gets wrong.

    Tests the contract:
    - Overrides always win over auto-inferred types (the user's final word)
    - Unknown channel names in the override dict are silently skipped
      (the user may have loaded a different file than the one whose
      overrides are in config)
    - Empty/None override dicts are no-ops (no spurious set_channel_types
      calls)
    - Overrides round-trip through TOML save/load
    """

    def _make_raw(self, names, types):
        info = mne.create_info(
            ch_names=list(names), sfreq=256.0, ch_types=list(types))
        data = np.zeros((len(names), 10))
        return mne.io.RawArray(data, info, verbose=False)

    def test_override_promotes_misc_to_specific(self):
        """The override dict wins over any reader-assigned type,
        including 'misc' (which the refine step respects)."""
        from ide4eeg.input.input import _apply_type_overrides
        raw = self._make_raw(
            ["Fp1", "Heart_sensor", "Aux1"], ["eeg", "misc", "misc"])
        _apply_type_overrides(raw, {"Heart_sensor": "ecg"})
        assert raw.get_channel_types() == ["eeg", "ecg", "misc"]

    def test_override_can_downgrade_eeg_to_misc(self):
        """A FIF file where the user wants to exclude a specific
        channel from EEG analysis — override it to misc."""
        from ide4eeg.input.input import _apply_type_overrides
        raw = self._make_raw(
            ["Fp1", "BadChannel"], ["eeg", "eeg"])
        _apply_type_overrides(raw, {"BadChannel": "misc"})
        assert raw.get_channel_types() == ["eeg", "misc"]

    def test_override_unknown_channel_is_silently_skipped(self):
        """If the overrides dict contains a name not in the file,
        the override is logged and skipped (no KeyError, no crash)."""
        from ide4eeg.input.input import _apply_type_overrides
        raw = self._make_raw(["Fp1", "Cz"], ["eeg", "eeg"])
        # "Unknown" is not in the file — should be silently skipped
        _apply_type_overrides(raw, {"Unknown": "ecg", "Fp1": "eog"})
        assert raw.get_channel_types() == ["eog", "eeg"]

    def test_override_empty_dict_is_noop(self):
        """Empty override dict must not call set_channel_types at all
        (no spurious work, no spurious warnings)."""
        from unittest.mock import patch
        from ide4eeg.input.input import _apply_type_overrides
        raw = self._make_raw(["Fp1", "Cz"], ["eeg", "eeg"])
        with patch.object(raw, "set_channel_types") as mock_set:
            _apply_type_overrides(raw, {})
            _apply_type_overrides(raw, None)
        mock_set.assert_not_called()

    def test_override_round_trip_through_toml(self, tmp_path):
        """Save a config with overrides, load it back, verify the
        dict survives intact."""
        import copy
        from ide4eeg.gui_config import DEFAULT_CONFIG, dump_toml, load_toml
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["choosing_channels"]["type_overrides"] = {
            "Heart_sensor": "ecg",
            "Aux_L": "eog",
            "Muscle_chin": "emg",
        }
        path = str(tmp_path / "overrides.toml")
        dump_toml(cfg, path)
        loaded = load_toml(path)
        restored = loaded.get("choosing_channels", {}).get(
            "type_overrides", {})
        assert restored == {
            "Heart_sensor": "ecg",
            "Aux_L": "eog",
            "Muscle_chin": "emg",
        }

    def test_default_config_has_empty_override_dict(self):
        """DEFAULT_CONFIG must ship with an empty override dict so
        the TOML round-trip works and _collect_config has something
        to copy from."""
        from ide4eeg.gui_config import DEFAULT_CONFIG
        assert (DEFAULT_CONFIG["choosing_channels"]["type_overrides"]
                == {})

    def test_override_suppresses_unit_change_warning(self):
        """Promoting misc (unit NA) to ecg (unit V) via an override
        should not emit MNE's 'unit has changed' RuntimeWarning."""
        import warnings
        from ide4eeg.input.input import _apply_type_overrides
        raw = self._make_raw(["Fp1", "Heart"], ["eeg", "misc"])
        with warnings.catch_warnings():
            warnings.simplefilter("error")  # any warning → test fails
            _apply_type_overrides(raw, {"Heart": "ecg"})
        assert raw.get_channel_types() == ["eeg", "ecg"]


class TestMPAlgorithmHelpers:
    """Test MP_ALGORITHMS metadata helpers."""

    def test_choices_returns_name_label_pairs(self):
        from ide4eeg.analysis.mp_analysis import (
            mp_algorithm_choices, MP_ALGORITHMS)
        choices = mp_algorithm_choices()
        assert len(choices) == len(MP_ALGORITHMS)
        for name, label in choices:
            assert name in MP_ALGORITHMS
            assert label.startswith(name)
            assert "\u2014" in label  # em dash separator

    def test_multichannel_names(self):
        from ide4eeg.analysis.mp_analysis import (
            mp_multichannel_algorithm_names)
        names = mp_multichannel_algorithm_names()
        assert "mmp1" in names
        assert "mmp3" in names
        assert "smp" not in names

    def test_parse_label_round_trip(self):
        from ide4eeg.analysis.mp_analysis import (
            mp_algorithm_choices, parse_mp_algorithm_label)
        for name, label in mp_algorithm_choices():
            assert parse_mp_algorithm_label(label) == name

    def test_parse_label_unknown_returns_default(self):
        from ide4eeg.analysis.mp_analysis import parse_mp_algorithm_label
        assert parse_mp_algorithm_label("zzz — bogus") == "smp"
        assert parse_mp_algorithm_label("") == "smp"
        assert parse_mp_algorithm_label(None) == "smp"

    def test_parse_label_default_override(self):
        from ide4eeg.analysis.mp_analysis import parse_mp_algorithm_label
        assert parse_mp_algorithm_label("zzz", default="mmp1") == "mmp1"


# ---------------------------------------------------------------------------
# EEG Profiles structure detection
# ---------------------------------------------------------------------------

class TestEEGProfiles:
    """Test EEG structure detection."""

    def test_detect_spindle(self):
        from ide4eeg.analysis.eeg_profiles import detect_structures, PRESETS
        spindle_struct = next(p for p in PRESETS
                             if p["name"] == "Sleep spindles")
        atoms = [
            {"f_Hz": 13.0, "scale_s": 1.0, "amplitude": 20e-6,
             "phase": 0.0, "energy": 1e-10},
        ]
        dets = detect_structures(atoms, [spindle_struct], scale_uV=1e6)
        assert len(dets) == 1
        assert dets[0]["name"] == "Sleep spindles"

    def test_detect_no_match(self):
        from ide4eeg.analysis.eeg_profiles import detect_structures, PRESETS
        spindle_struct = next(p for p in PRESETS
                             if p["name"] == "Sleep spindles")
        # 1 Hz atom should NOT match spindle criteria (11-15 Hz)
        atoms = [
            {"f_Hz": 1.0, "scale_s": 1.0, "amplitude": 20e-6,
             "phase": 0.0, "energy": 1e-10},
        ]
        dets = detect_structures(atoms, [spindle_struct], scale_uV=1e6)
        assert len(dets) == 0

    def test_interval_sec_is_ignored(self):
        """The legacy ``interval_sec`` config key is no longer read by
        eeg_profiles — bin width is always set from MP segment length.
        Verify by inspecting the source for any use of the key."""
        import inspect
        from ide4eeg.analysis import eeg_profiles
        src = inspect.getsource(eeg_profiles)
        assert 'prof_cfg.get("interval_sec"' not in src, \
            "eeg_profiles still reads interval_sec from config"
        assert "prof_cfg['interval_sec']" not in src, \
            "eeg_profiles still reads interval_sec from config"


# ---------------------------------------------------------------------------
# Connectivity data class
# ---------------------------------------------------------------------------

class TestConnectivityData:
    """Test ConnectiviPy data class."""

    def test_data_creation(self):
        from ide4eeg.analysis.connectivity.data import Data
        d = Data(np.random.randn(3, 1000), fs=256)
        # Data class stores data internally
        assert d.data.shape[0] == 3

    def test_select_channels_none(self):
        """select_channels(None) should reset to all channels."""
        from ide4eeg.analysis.connectivity.data import Data
        d = Data(np.random.randn(5, 1000), fs=256)
        d.select_channels(None)
        # Should not crash and should have all 5 channels

    def test_select_channels_subset(self):
        from ide4eeg.analysis.connectivity.data import Data
        d = Data(np.random.randn(5, 1000), fs=256)
        d.select_channels([0, 2, 4])

    def test_select_channels_invalid(self):
        from ide4eeg.analysis.connectivity.data import Data
        d = Data(np.random.randn(5, 1000), fs=256)
        with pytest.raises(ValueError):
            d.select_channels([0, 10])  # index 10 > 5 channels


# ---------------------------------------------------------------------------
# GUI helper functions
# ---------------------------------------------------------------------------

class TestGUIHelpers:
    """Test GUI utility functions."""

    def test_toml_value_round_trip(self):
        from ide4eeg.gui_config import _toml_value, dump_toml, load_toml
        cfg = {
            "int_val": 42,
            "float_val": 3.14,
            "bool_val": True,
            "str_val": "hello",
            "list_val": [1.0, 2.0],
            "nested": {"a": 1, "b": "test"},
        }
        with tempfile.NamedTemporaryFile(mode="w", suffix=".toml",
                                          delete=False) as f:
            dump_toml(cfg, f.name)
            loaded = load_toml(f.name)
            os.unlink(f.name)

        assert loaded["int_val"] == 42
        assert loaded["float_val"] == pytest.approx(3.14)
        assert loaded["bool_val"] is True
        assert loaded["str_val"] == "hello"
        assert loaded["list_val"] == pytest.approx([1.0, 2.0])
        assert loaded["nested"]["a"] == 1


# ---------------------------------------------------------------------------
# Dipole atom filtering
# ---------------------------------------------------------------------------

class TestDipoleFiltering:
    """Test dipole fitting atom selection logic."""

    def test_freq_filter(self):
        """Frequency filter should exclude atoms outside range."""
        macroatoms = [
            {"segment_id": 0, "iteration": 0,
             "channels": [{"amplitude": 1.0, "f_Hz": 5.0, "scale_s": 1.0}]},
            {"segment_id": 0, "iteration": 1,
             "channels": [{"amplitude": 1.0, "f_Hz": 15.0, "scale_s": 1.0}]},
            {"segment_id": 0, "iteration": 2,
             "channels": [{"amplitude": 1.0, "f_Hz": 25.0, "scale_s": 1.0}]},
        ]
        # Filter to 10-20 Hz
        filtered = [m for m in macroatoms
                    if max(m["channels"],
                           key=lambda c: abs(c["amplitude"]))["f_Hz"] >= 10
                    and max(m["channels"],
                            key=lambda c: abs(c["amplitude"]))["f_Hz"] <= 20]
        assert len(filtered) == 1
        assert filtered[0]["iteration"] == 1

    def test_picked_atoms_matching(self):
        """Picked atoms should match by (segment_id, iteration)."""
        macroatoms = [
            {"segment_id": 0, "iteration": 0, "channels": []},
            {"segment_id": 0, "iteration": 1, "channels": []},
            {"segment_id": 1, "iteration": 0, "channels": []},
        ]
        picked = [
            {"segment_id": 0, "iteration": 1},
            {"segment_id": 1, "iteration": 0},
        ]
        picked_keys = {(a["segment_id"], a["iteration"]) for a in picked}
        matched = [m for m in macroatoms
                   if (m["segment_id"], m["iteration"]) in picked_keys]
        assert len(matched) == 2
