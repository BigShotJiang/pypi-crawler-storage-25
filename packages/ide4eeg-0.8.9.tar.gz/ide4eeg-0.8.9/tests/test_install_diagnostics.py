"""Tests for ide4eeg.install_diagnostics."""

import sys

import pytest

from ide4eeg import install_diagnostics as idiag
from ide4eeg.install_diagnostics import (
    VIDEO_STACK,
    ActionPlan,
    CellIssue,
    Pkg,
    cell_issues,
    detect_video_stack,
    format_diagnostic,
    plan_install,
)


def test_video_stack_has_expected_packages():
    names = {p.import_name for p in VIDEO_STACK}
    assert names == {"cv2", "av", "imageio",
                     "insightface", "onnxruntime",
                     "torch", "l2cs"}
    optional = {p.import_name for p in VIDEO_STACK if p.optional}
    assert optional == {"torch", "l2cs"}


def test_detect_returns_bool_for_every_package():
    result = detect_video_stack()
    assert set(result.keys()) == {p.import_name for p in VIDEO_STACK}
    assert all(isinstance(v, bool) for v in result.values())


def test_cell_issues_intel_mac_py314_blocks_onnxruntime():
    issues = cell_issues(platform_="darwin", machine="x86_64", py_minor=14)
    assert len(issues) == 1
    assert issues[0].pkg == "onnxruntime"


def test_cell_issues_apple_silicon_py314_clean():
    issues = cell_issues(platform_="darwin", machine="arm64", py_minor=14)
    assert issues == []


def test_cell_issues_linux_py314_blocks_insightface():
    # Wildcard arch — both x86_64 and aarch64 hit the same issue.
    for arch in ("x86_64", "aarch64"):
        issues = cell_issues(platform_="linux", machine=arch, py_minor=14)
        assert len(issues) == 1
        assert issues[0].pkg == "insightface"


def test_cell_issues_linux_py313_clean():
    issues = cell_issues(platform_="linux", machine="x86_64", py_minor=13)
    assert issues == []


def test_cell_issues_windows_clean():
    issues = cell_issues(platform_="win32", machine="AMD64", py_minor=14)
    assert issues == []


def test_plan_install_categorises_have_missing_blocked():
    detection = {
        "cv2": True,
        "av": True,
        "imageio": True,
        "insightface": True,
        "onnxruntime": False,   # missing on Intel Mac + Py3.14 -> blocked
        "torch": False,         # missing, no cell issue -> clean install
        "l2cs": False,          # missing, no cell issue -> clean install
    }
    plan = plan_install(detection,
                        platform_="darwin", machine="x86_64", py_minor=14)
    assert {p.import_name for p in plan.have} == {
        "cv2", "av", "imageio", "insightface"}
    assert {p.import_name for p in plan.missing} == {"torch", "l2cs"}
    assert {p.import_name for p, _ in plan.blocked} == {"onnxruntime"}
    assert plan.all_clear is False


def test_plan_install_all_clear_when_everything_installed():
    detection = {p.import_name: True for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64", py_minor=13)
    assert plan.all_clear is True
    assert len(plan.have) == len(VIDEO_STACK)
    assert plan.missing == ()
    assert plan.blocked == ()


def test_plan_install_uses_live_cell_when_no_overrides():
    """Smoke test: running on the actual machine doesn't crash."""
    plan = plan_install()
    assert isinstance(plan, ActionPlan)
    assert (len(plan.have) + len(plan.missing) + len(plan.blocked)
            == len(VIDEO_STACK))


def test_format_diagnostic_for_all_clear():
    detection = {p.import_name: True for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64", py_minor=13)
    text = format_diagnostic(plan)
    assert "Video stack is fully installed." in text
    assert "[ok]" in text
    assert "[--]" not in text
    assert "[!!]" not in text


def test_format_diagnostic_for_blocked_cell():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="x86_64", py_minor=14)
    text = format_diagnostic(plan)
    assert "[!!]" in text
    assert "onnxruntime" in text
    assert "Python 3.13" in text or "python@3.13" in text


def test_format_diagnostic_for_missing_with_clean_install():
    detection = {p.import_name: False for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64", py_minor=13)
    text = format_diagnostic(plan)
    assert "[--]" in text
    assert "pip install" in text
    assert "[!!]" not in text


def test_format_diagnostic_ends_with_single_newline():
    detection = {p.import_name: True for p in VIDEO_STACK}
    plan = plan_install(detection,
                        platform_="darwin", machine="arm64", py_minor=13)
    text = format_diagnostic(plan)
    assert text.endswith("\n")
    assert not text.endswith("\n\n")
