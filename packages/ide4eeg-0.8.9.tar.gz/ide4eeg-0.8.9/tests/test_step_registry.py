"""Locks the structural invariants of the consolidated STEP_REGISTRY.

After the Stage-2 refactor, ``_STEP_SAVE_MAP``, ``_STEP_CONFIG_DEPS``,
and ``STEP_LABELS`` are *derived* views over ``STEP_REGISTRY``.  These
tests are the explicit contract that adding a new step in one place
shouldn't be possible to leave inconsistent.
"""
import pytest

from ide4eeg.preprocessing.preprocessing import (
    DEFAULT_STEP_ORDER,
    STEP_LABELS,
    STEP_REGISTRY,
    StepDef,
    _STEP_CONFIG_DEPS,
    _STEP_SAVE_MAP,
)


def test_every_entry_is_a_stepdef():
    for name, sd in STEP_REGISTRY.items():
        assert isinstance(sd, StepDef), (
            f"{name!r} must be a StepDef, got {type(sd).__name__}")


def test_handler_is_callable():
    for name, sd in STEP_REGISTRY.items():
        assert callable(sd.handler), (
            f"{name!r}.handler is not callable: {sd.handler!r}")


def test_label_non_empty():
    for name, sd in STEP_REGISTRY.items():
        assert isinstance(sd.label, str) and sd.label, (
            f"{name!r}.label must be a non-empty string")


def test_save_section_and_suffix_are_paired():
    """A step either saves a FIF (both set) or doesn't (both None)."""
    for name, sd in STEP_REGISTRY.items():
        if sd.save_section is None:
            assert sd.save_suffix is None, (
                f"{name!r}: save_section is None but save_suffix is "
                f"{sd.save_suffix!r} — partial save config")
        else:
            assert sd.save_suffix is not None, (
                f"{name!r}: save_section is {sd.save_section!r} but "
                f"save_suffix is None — incomplete save config")


def test_step_save_map_matches_registry():
    """_STEP_SAVE_MAP must be derivable from STEP_REGISTRY exactly."""
    expected = {
        name: (sd.save_section, sd.save_suffix)
        for name, sd in STEP_REGISTRY.items()
        if sd.save_section is not None
    }
    assert _STEP_SAVE_MAP == expected


def test_step_config_deps_matches_registry():
    """Likewise for _STEP_CONFIG_DEPS."""
    expected = {
        name: list(sd.config_deps)
        for name, sd in STEP_REGISTRY.items()
    }
    assert _STEP_CONFIG_DEPS == expected


def test_step_labels_matches_registry():
    expected = {name: sd.label for name, sd in STEP_REGISTRY.items()}
    assert STEP_LABELS == expected


def test_default_step_order_subset_of_registry():
    """Every step in DEFAULT_STEP_ORDER must exist in the registry."""
    unknown = [s for s in DEFAULT_STEP_ORDER if s not in STEP_REGISTRY]
    assert not unknown, f"DEFAULT_STEP_ORDER refs unknown steps: {unknown}"


def test_known_steps_still_present():
    """Sanity: any step removal should be conscious + reflected in tests."""
    required = {
        "trim", "resample", "bad_channels", "montage", "reference",
        "filtering", "ica", "chosen_channels",
        "mp_decomposition", "mp_filter",
        "eeg_artifacts", "gaze_artifacts",
    }
    missing = required - set(STEP_REGISTRY)
    assert not missing, (
        f"Expected steps missing from registry: {missing}.  If a step "
        f"was deliberately retired into _unreleased/, update this "
        f"test's `required` set too.")


def test_step_def_is_frozen():
    sd = next(iter(STEP_REGISTRY.values()))
    with pytest.raises(Exception):  # FrozenInstanceError
        sd.label = "changed"  # type: ignore[misc]
