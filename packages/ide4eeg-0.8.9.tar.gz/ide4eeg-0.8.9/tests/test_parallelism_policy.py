"""Lint-style tests enforcing the centralised parallelism policy.

All parallel execution in IDE4EEG is supposed to go through joblib
(see CONTRIBUTING.md §"Parallelism"). These tests scan the source
tree for primitives that would bypass that policy and fail the PR if
any new bypasses show up.

Whitelists cover the documented exception:
  - ide4eeg/analysis/dipole/ — legacy, maintained by another dev,
    pending migration to joblib (see CONTRIBUTING.md worked example).
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
PKG_ROOT = REPO_ROOT / "ide4eeg"

# Patterns that indicate a direct use of stdlib parallel primitives.
# These are the things that should go through joblib.Parallel instead.
FORBIDDEN_PATTERNS = [
    re.compile(r"\bProcessPoolExecutor\s*\("),
    re.compile(r"\bmultiprocessing\.Pool\s*\("),
    re.compile(r"from\s+multiprocessing\s+import\s+Pool\b"),
]

# Files allowed to use the forbidden primitives. Keep this list tight
# and comment each entry with the reason.
WHITELIST = {
    # Legacy dipole fitting — maintained by a separate developer, slated
    # for migration to joblib (CONTRIBUTING.md §"Worked example").
    "ide4eeg/analysis/dipole/fitting.py",
}


def _python_files():
    for path in PKG_ROOT.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        yield path


def _lines_matching(path: Path, pattern: re.Pattern) -> list[tuple[int, str]]:
    out: list[tuple[int, str]] = []
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return out
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if stripped.startswith("#"):
            continue
        if pattern.search(line):
            out.append((lineno, line.rstrip()))
    return out


def test_no_raw_processpool_outside_whitelist():
    """No ProcessPoolExecutor / multiprocessing.Pool outside the whitelist.

    If this fails with a new file showing up, port it to
    joblib.Parallel (see CONTRIBUTING.md §"Parallelism"). If the file
    genuinely must use raw primitives, add it to WHITELIST with a
    comment explaining why.
    """
    offenders: list[str] = []
    for py in _python_files():
        rel = py.relative_to(REPO_ROOT).as_posix()
        if rel in WHITELIST:
            continue
        for pat in FORBIDDEN_PATTERNS:
            for lineno, line in _lines_matching(py, pat):
                offenders.append(f"{rel}:{lineno}: {line}")
    assert not offenders, (
        "Direct use of stdlib parallel primitives detected. Port to "
        "joblib.Parallel (CONTRIBUTING.md §Parallelism) or add the "
        "file to WHITELIST in tests/test_parallelism_policy.py with "
        "a justification:\n  " + "\n  ".join(offenders)
    )


def test_whitelist_entries_exist():
    """Every WHITELIST entry must point to an actual file.

    Prevents stale entries from rotting the whitelist as files move
    or get renamed.
    """
    missing = [
        rel for rel in WHITELIST
        if not (REPO_ROOT / rel).is_file()
    ]
    assert not missing, (
        "WHITELIST in tests/test_parallelism_policy.py references "
        f"missing files: {missing}"
    )


def test_joblib_and_threadpoolctl_explicit_in_pyproject():
    """joblib + threadpoolctl must be declared in pyproject.toml.

    They are transitively available via MNE/scikit-learn today, but
    the parallelism policy makes them load-bearing (ide4eeg.main
    _configure_parallelism calls joblib.parallel_config, and
    threadpoolctl is how joblib pins BLAS threads in workers). If
    MNE ever changes backend, we still need joblib — declare it
    explicitly.
    """
    try:
        import tomllib
    except ImportError:  # Python < 3.11
        import tomli as tomllib  # type: ignore[no-redef]
    pyproject = tomllib.loads(
        (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    deps = pyproject["project"]["dependencies"]
    names = {
        re.split(r"[<>=!~\s]", d, maxsplit=1)[0].lower() for d in deps
    }
    assert "joblib" in names, (
        "joblib must be declared explicitly in pyproject.toml "
        "(it's load-bearing for ide4eeg.main._configure_parallelism)")
    assert "threadpoolctl" in names, (
        "threadpoolctl must be declared explicitly in pyproject.toml "
        "(it's how joblib pins BLAS threads in worker processes "
        "via inner_max_num_threads=1)")
