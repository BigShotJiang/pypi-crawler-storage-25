"""Tests for analysis modules: MVAR connectivity, and Nyquist clamping
logic from main.py.

Uses only lightweight synthetic data (numpy arrays, MNE EpochsArray).
No external model files or optional deps (torch, insightface, etc.).
"""

import numpy as np
import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def rng():
    """Seeded RNG for reproducibility."""
    return np.random.default_rng(42)


@pytest.fixture
def synth_signal_3ch(rng):
    """3-channel signal, 256 Hz, 2 seconds."""
    sfreq = 256
    dur = 2.0
    n = int(sfreq * dur)
    return rng.standard_normal((3, n)), sfreq



# ═══════════════════════════════════════════════════════════════════════════
# MVAR connectivity  (Mvar.fit, order_akaike)
# ═══════════════════════════════════════════════════════════════════════════

class TestMvarFit:
    """Tests for ide4eeg.analysis.connectivity.mvarmodel.Mvar.fit."""

    def test_fit_returns_correct_shapes(self, synth_signal_3ch):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data, _ = synth_signal_3ch
        k = data.shape[0]  # 3 channels
        order = 2
        Av, Vf = Mvar.fit(data, order=order, method='yw')

        # Av: (order, k, k),  Vf: (k, k)
        assert Av.shape == (order, k, k)
        assert Vf.shape == (k, k)

    def test_fit_with_vieira_morf(self, synth_signal_3ch):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data, _ = synth_signal_3ch
        k = data.shape[0]
        order = 3
        Av, Vf = Mvar.fit(data, order=order, method='vm')

        assert Av.shape == (order, k, k)
        assert Vf.shape == (k, k)

    def test_fit_with_nutall_strand(self, synth_signal_3ch):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data, _ = synth_signal_3ch
        k = data.shape[0]
        order = 2
        Av, Vf = Mvar.fit(data, order=order, method='ns')

        assert Av.shape == (order, k, k)
        assert Vf.shape == (k, k)

    def test_fit_auto_order(self, rng):
        """When order=None, Mvar.fit uses Hannan-Quinn to pick order."""
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data = rng.standard_normal((2, 200))
        Av, Vf = Mvar.fit(data, order=None, method='yw')

        # Auto-selected order should be between 1 and 5 (default p_max)
        auto_order = Av.shape[0]
        assert 1 <= auto_order <= 5
        assert Av.shape == (auto_order, 2, 2)
        assert Vf.shape == (2, 2)

    def test_fit_order_1(self, synth_signal_3ch):
        """Edge case: order = 1."""
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data, _ = synth_signal_3ch
        Av, Vf = Mvar.fit(data, order=1, method='yw')

        assert Av.shape == (1, 3, 3)
        assert Vf.shape == (3, 3)

    def test_fit_single_channel(self, rng):
        """Edge case: single channel (k=1)."""
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data = rng.standard_normal((1, 500))
        Av, Vf = Mvar.fit(data, order=2, method='yw')

        assert Av.shape == (2, 1, 1)
        assert Vf.shape == (1, 1)

    def test_fit_coefficients_finite(self, synth_signal_3ch):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data, _ = synth_signal_3ch
        Av, Vf = Mvar.fit(data, order=2, method='yw')

        assert np.all(np.isfinite(Av))
        assert np.all(np.isfinite(Vf))


class TestMvarOrderAkaike:
    """Tests for ide4eeg.analysis.connectivity.mvarmodel.Mvar.order_akaike."""

    def test_order_akaike_returns_int_and_array(self, rng):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data = rng.standard_normal((2, 300))
        best_order, crit = Mvar.order_akaike(data, p_max=5, method='yw')

        assert isinstance(best_order, (int, np.integer))
        assert isinstance(crit, np.ndarray)
        assert crit.shape == (5,)
        assert 1 <= best_order <= 5

    def test_order_akaike_criterion_values_finite(self, rng):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data = rng.standard_normal((3, 400))
        best_order, crit = Mvar.order_akaike(data, p_max=4, method='yw')

        assert np.all(np.isfinite(crit))

    def test_order_akaike_single_channel(self, rng):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data = rng.standard_normal((1, 500))
        best_order, crit = Mvar.order_akaike(data, p_max=3, method='yw')

        assert 1 <= best_order <= 3
        assert crit.shape == (3,)

    def test_order_akaike_default_pmax(self, rng):
        """p_max=None should default to 5."""
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data = rng.standard_normal((2, 300))
        best_order, crit = Mvar.order_akaike(data, p_max=None, method='yw')

        assert crit.shape == (5,)
        assert 1 <= best_order <= 5

    def test_order_akaike_known_process(self, rng):
        """For data generated from an AR(2), Akaike should find order near 2."""
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar
        from ide4eeg.analysis.connectivity.mvar.fitting import mvar_gen

        # Create a simple AR(2) process with 2 channels
        Acf = np.zeros((2, 2, 2))
        Acf[0] = [[0.5, 0.1], [0.0, 0.3]]
        Acf[1] = [[-0.2, 0.0], [0.05, -0.1]]
        data = mvar_gen(Acf, 2000)

        best_order, crit = Mvar.order_akaike(data, p_max=5, method='yw')

        # Should pick order 2 (the true order) — allow 1-3 due to noise
        assert 1 <= best_order <= 4


class TestMvarOrderSchwartz:
    """Tests for Schwartz (BIC) criterion."""

    def test_order_schwartz_shapes(self, rng):
        from ide4eeg.analysis.connectivity.mvarmodel import Mvar

        data = rng.standard_normal((2, 300))
        best_order, crit = Mvar.order_schwartz(data, p_max=4, method='yw')

        assert isinstance(best_order, (int, np.integer))
        assert crit.shape == (4,)
        assert 1 <= best_order <= 4

