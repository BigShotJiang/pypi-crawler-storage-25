"""Defensive tests for the L2CS weights download path.

Regression coverage for the v0.8.8 DMG bug where
``_download_weights`` crashed with ``OSError: [Errno 2] No such
file or directory: '...pkl.part' -> '...pkl'`` — the rename was
attempted but the source ``.part`` file was missing.

Root causes covered:
* Concurrent invocation race (two threads enter ``_download_weights``,
  the first's ``os.replace`` consumes the ``.part``, the second
  finds it gone).
* urlretrieve returns cleanly but writes no file (observed on
  macOS DMG bundles — likely XProtect / quarantine interaction).
* Truncated / 0-byte responses where urlretrieve doesn't raise
  ``ContentTooShortError``.

These tests do NOT make real network calls; ``urlretrieve`` is
monkeypatched.
"""
from __future__ import annotations

import os
import threading
import urllib.error

import pytest

from ide4eeg.preprocessing.facetag import l2cs_gaze


@pytest.fixture
def weights_in_tmp(tmp_path, monkeypatch):
    """Redirect the canonical weights path into a tmp_path dir so
    tests don't write to the user's real ``~/.obci/`` cache."""
    target = tmp_path / "L2CSNet_gaze360.pkl"
    monkeypatch.setattr(l2cs_gaze, "set_weights_path",
                        lambda p: None)  # neutralise
    monkeypatch.setattr(l2cs_gaze, "weights_path", lambda: str(target))
    yield target


class TestSilentEmptyDownload:
    """``urlretrieve`` returns cleanly but the ``.part`` is missing
    or has 0 bytes -- both cases must raise a clear FileNotFoundError
    with remediation text, NOT a cryptic os.replace OSError."""

    def test_part_file_missing_after_urlretrieve(
            self, weights_in_tmp, monkeypatch):
        """Simulate urlretrieve returning without writing anything
        (the symptom from the v0.8.8 DMG bug)."""
        def noop_urlretrieve(url, filename):
            return filename, None  # but never write the file
        monkeypatch.setattr(
            l2cs_gaze.urllib.request, "urlretrieve", noop_urlretrieve)
        with pytest.raises(FileNotFoundError) as exc_info:
            l2cs_gaze._download_weights()
        msg = str(exc_info.value)
        # Should contain the remediation URL, not a raw OSError.
        assert "L2CSNet_gaze360.pkl" in msg
        assert "manually" in msg.lower() or "gitlab" in msg.lower()

    def test_part_file_too_small(
            self, weights_in_tmp, monkeypatch):
        """urlretrieve writes only a few bytes (truncated stream) →
        must raise with a size-aware message, not silently rename a
        broken .pkl into place."""
        def stub_urlretrieve(url, filename):
            with open(filename, "wb") as fh:
                fh.write(b"truncated")
            return filename, None
        monkeypatch.setattr(
            l2cs_gaze.urllib.request, "urlretrieve", stub_urlretrieve)
        with pytest.raises(FileNotFoundError) as exc_info:
            l2cs_gaze._download_weights()
        msg = str(exc_info.value)
        assert "small" in msg.lower() or "91" in msg or "bytes" in msg
        # The bogus .part should have been cleaned up.
        assert not (weights_in_tmp.parent /
                    "L2CSNet_gaze360.pkl.part").exists()

    def test_urlretrieve_raises_with_partial_part_left_behind(
            self, weights_in_tmp, monkeypatch):
        """urlretrieve writes some bytes then raises mid-stream.  The
        except handler must unlink the partial ``.part`` so the next
        attempt sees a clean slate and doesn't trip the size-sanity
        check on prior junk."""
        def stub_urlretrieve(url, filename):
            with open(filename, "wb") as fh:
                fh.write(b"partial_50kb_payload" * 2500)  # ~50 KB
            raise urllib.error.URLError("connection reset by peer")
        monkeypatch.setattr(
            l2cs_gaze.urllib.request, "urlretrieve", stub_urlretrieve)
        with pytest.raises(FileNotFoundError) as exc_info:
            l2cs_gaze._download_weights()
        # Remediation URL surfaced, no raw OSError.
        assert "L2CSNet_gaze360.pkl" in str(exc_info.value)
        # Critical: the partial .part must be gone so a retry starts
        # fresh (otherwise the stale-cleanup-before-urlretrieve path
        # would handle it, but the except-handler unlink is what
        # makes that less load-bearing).
        assert not (weights_in_tmp.parent /
                    "L2CSNet_gaze360.pkl.part").exists()


class TestConcurrentDownloadSerialised:
    """Two threads call ``_download_weights`` simultaneously.  Before
    the fix this raced: the first thread's ``os.replace`` consumed
    the ``.part`` out from under the second, which then crashed on
    its own rename.  After the lock, the second thread sees the
    finished ``dest`` and returns it cleanly."""

    def test_two_concurrent_calls_dont_race(
            self, weights_in_tmp, monkeypatch):
        """Stub urlretrieve to write a plausibly-sized file, then
        run two downloads concurrently from threads.  Both must
        return the same dest path with no exception."""
        download_count = [0]

        def stub_urlretrieve(url, filename):
            # Slow enough that the second thread gets to the lock
            # while the first is mid-download.
            import time
            time.sleep(0.05)
            with open(filename, "wb") as fh:
                # >= 1 MB so the size sanity check passes.
                fh.write(b"\x00" * 2_000_000)
            download_count[0] += 1
            return filename, None
        monkeypatch.setattr(
            l2cs_gaze.urllib.request, "urlretrieve", stub_urlretrieve)

        results = []
        errors = []

        def worker():
            try:
                results.append(l2cs_gaze._download_weights())
            except Exception as exc:  # noqa: BLE001
                errors.append(exc)

        t1 = threading.Thread(target=worker)
        t2 = threading.Thread(target=worker)
        t1.start(); t2.start()
        t1.join(); t2.join()

        assert not errors, (
            f"concurrent downloads raised: {errors}")
        assert len(results) == 2
        assert results[0] == results[1]
        # Critical: only ONE actual download happened.  The second
        # thread acquired the lock after the first finished, saw the
        # dest file exists, and short-circuited.
        assert download_count[0] == 1, (
            f"expected 1 urlretrieve call, got {download_count[0]}")


class TestStaleHalfPartCleanedUp:
    """A previous interrupted download left a stale ``.part`` on
    disk.  The new code must clean it up before urlretrieve writes
    the fresh download so the size-sanity check doesn't fire on a
    half-finished prior attempt."""

    def test_stale_part_does_not_block_retry(
            self, weights_in_tmp, monkeypatch):
        stale_part = weights_in_tmp.parent / "L2CSNet_gaze360.pkl.part"
        stale_part.parent.mkdir(parents=True, exist_ok=True)
        stale_part.write_bytes(b"stale_partial")

        def stub_urlretrieve(url, filename):
            with open(filename, "wb") as fh:
                fh.write(b"\x00" * 2_000_000)
            return filename, None
        monkeypatch.setattr(
            l2cs_gaze.urllib.request, "urlretrieve", stub_urlretrieve)

        result = l2cs_gaze._download_weights()
        assert os.path.isfile(result)
        # The final file should be the fresh 2 MB write, NOT the
        # 13-byte stale partial.
        assert os.path.getsize(result) >= 1_000_000


class TestAlreadyDownloadedShortCircuits:
    """When the dest file already exists, _download_weights returns
    immediately — no urlretrieve, no lock contention."""

    def test_existing_file_returned_directly(
            self, weights_in_tmp, monkeypatch):
        weights_in_tmp.parent.mkdir(parents=True, exist_ok=True)
        weights_in_tmp.write_bytes(b"\x00" * 100)

        def must_not_be_called(*a, **kw):
            raise AssertionError(
                "urlretrieve should NOT be called when dest exists")
        monkeypatch.setattr(
            l2cs_gaze.urllib.request, "urlretrieve",
            must_not_be_called)

        result = l2cs_gaze._download_weights()
        assert result == str(weights_in_tmp)
