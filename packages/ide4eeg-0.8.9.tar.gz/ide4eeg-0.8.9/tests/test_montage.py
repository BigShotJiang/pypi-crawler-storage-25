"""Tests for montage handling in preprocessing/channels_and_signal.

Covers the native-positions detection path added in commit b398c66
and refined in the simplify pass (constant + helper consolidation):

- ``_has_native_eeg_positions`` — True iff every EEG channel already
  has a finite, non-zero 3D location (as MNE sample FIFs ship).
- ``_set_montage`` branches:
    * native detected         → keep file's positions, no set_montage
    * sentinel + no positions → warn + fall back to standard_1020
    * empty/None in config    → default to standard_1020
    * explicit layout         → apply as-is

These tests are the single behaviour lock ensuring the pipeline
never silently blanks out real digitized positions (the regression
that motivated b398c66) and that the sentinel string survives
config round-trips without tripping set_montage.
"""

import logging

import mne
import numpy as np
import pytest

from ide4eeg import NATIVE_POSITIONS_SENTINEL
from ide4eeg.input.input import read_file_info
from ide4eeg.preprocessing.channels_and_signal import (
    _has_native_eeg_positions,
    _set_montage,
)


# ── Helpers ─────────────────────────────────────────────────────────


def _bare_raw(ch_names=("Fp1", "Fz", "Cz"), sfreq=256.0, duration=1.0):
    """Synthetic EEG raw with NO channel positions."""
    n = int(sfreq * duration)
    data = np.zeros((len(ch_names), n))
    info = mne.create_info(list(ch_names), sfreq=sfreq, ch_types="eeg")
    return mne.io.RawArray(data, info, verbose=False)


def _min_cfg(layout):
    """Minimal config dict accepted by _set_montage (no re-ref / no bads)."""
    return {
        "electrodes_layout": layout,
        "re_reference": [],
        "choosing_channels": {},
    }


# ── _has_native_eeg_positions ──────────────────────────────────────


class TestHasNativeEegPositions:
    def test_bare_synthetic_no_montage_is_false(self):
        assert _has_native_eeg_positions(_bare_raw()) is False

    def test_after_applying_standard_1020_is_true(self):
        raw = _bare_raw().set_montage("standard_1020")
        assert _has_native_eeg_positions(raw) is True

    def test_mne_style_names_without_positions_is_false(self):
        """EEG 001-style names (MNE-sample naming) alone don't count
        — positions must be populated in info['chs'][i]['loc']."""
        raw = _bare_raw(ch_names=("EEG 001", "EEG 002", "EEG 003"))
        assert _has_native_eeg_positions(raw) is False

    def test_no_eeg_channels_is_false(self):
        """Empty pick → False (not True-by-vacuous-all)."""
        info = mne.create_info(["STIM"], sfreq=256.0, ch_types="stim")
        raw = mne.io.RawArray(np.zeros((1, 10)), info, verbose=False)
        assert _has_native_eeg_positions(raw) is False


# ── _set_montage branches ──────────────────────────────────────────


class TestSetMontageNativeDetected:
    def test_keeps_positions_and_writes_sentinel(self, caplog):
        raw = _bare_raw().set_montage("standard_1020")
        # Capture one channel's coords before — must survive the call.
        fp1_before = raw.info["chs"][
            raw.ch_names.index("Fp1")]["loc"][:3].copy()
        cfg = _min_cfg("standard_1005")  # user picked something else
        with caplog.at_level(logging.INFO,
                             logger="root"):
            out = _set_montage(raw, cfg)
        fp1_after = out.info["chs"][
            out.ch_names.index("Fp1")]["loc"][:3]
        assert np.allclose(fp1_before, fp1_after)
        assert cfg["electrodes_layout"] == NATIVE_POSITIONS_SENTINEL
        assert any("Keeping native electrode positions" in r.message
                   for r in caplog.records)


class TestSetMontageSentinelFallback:
    def test_warns_and_falls_back_to_standard_1020(self, caplog):
        """Config ships the native sentinel but signal has no positions
        (e.g. user pointed a FIF config at a fresh BrainTech file)."""
        raw = _bare_raw(
            ch_names=("EEG 001", "EEG 002"))  # 1005-invalid names
        cfg = _min_cfg(NATIVE_POSITIONS_SENTINEL)
        with caplog.at_level(logging.WARNING, logger="root"):
            _set_montage(raw, cfg)
        assert cfg["electrodes_layout"] == "standard_1020"
        assert any("no native positions" in r.message.lower()
                   for r in caplog.records)


class TestSetMontageDefaultBranches:
    @pytest.mark.parametrize("layout", ["None", None, ""])
    def test_empty_sentinels_default_to_standard_1020(self, layout):
        raw = _bare_raw()
        cfg = _min_cfg(layout)
        _set_montage(raw, cfg)
        assert cfg["electrodes_layout"] == "standard_1020"

    def test_explicit_layout_passes_through(self):
        """User selected a non-standard montage → it must be applied
        verbatim and not clobbered by the native/fallback logic."""
        raw = _bare_raw()
        cfg = _min_cfg("standard_1005")
        _set_montage(raw, cfg)
        assert cfg["electrodes_layout"] == "standard_1005"


# ── read_file_info.has_native_positions ────────────────────────────


class TestReadFileInfoNativePositions:
    """read_file_info must report the same verdict that
    _set_montage will use at pipeline time — otherwise the GUI's
    prefill/lock decision disagrees with the actual skip decision."""

    def _save(self, raw, tmp_path, base):
        """Save *raw* under MNE's required ``-raw.fif`` suffix and
        return the full path accepted by ``read_file_info``."""
        path = tmp_path / f"{base}-raw.fif"
        raw.save(str(path), overwrite=True, verbose=False)
        return str(path)

    def test_fif_without_positions_reports_false(self, tmp_path):
        raw = _bare_raw(
            ch_names=("EEG 001", "EEG 002", "EEG 003"), duration=0.5)
        info = read_file_info(self._save(raw, tmp_path, "nopos"))
        assert info is not None
        assert info.get("has_native_positions") is False

    def test_fif_with_standard_1020_reports_true(self, tmp_path):
        raw = _bare_raw(duration=0.5).set_montage("standard_1020")
        info = read_file_info(self._save(raw, tmp_path, "withpos"))
        assert info is not None
        assert info.get("has_native_positions") is True
