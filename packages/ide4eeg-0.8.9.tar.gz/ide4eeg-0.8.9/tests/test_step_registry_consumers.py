"""Structural test: every GUI consumer of the new ``STEP_REGISTRY``
dataclass sees the same values that ``_STEP_SAVE_MAP`` /
``_STEP_CONFIG_DEPS`` carried before the Stage 2 consolidation.

After 839c1a1 the three parallel dicts are derived views.  This file
locks the *derivation* against drift between StepDef fields and the
shape the consumers expect (tuples for save-map, lists for deps).

Mirrors the offscreen-Qt fixture pattern from test_view_step_result.py.
"""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


_qt_app = None
_qt_gui = None


def _get_qt_gui():
    global _qt_app, _qt_gui
    if _qt_gui is not None:
        return _qt_gui
    try:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        _qt_app = QApplication.instance() or QApplication(sys.argv)
        from ide4eeg.gui import IDE4EEG_Qt
        _qt_gui = IDE4EEG_Qt()
    except Exception as e:
        pytest.skip(f"Cannot create Qt GUI: {e}")
    return _qt_gui


@pytest.fixture(scope="module")
def qt_gui():
    gui = _get_qt_gui()
    if gui is None:
        pytest.skip("Qt GUI not available")
    yield gui


def test_step_save_map_shape_matches_consumer_expectations(qt_gui):
    """gui.py:7853 does ``entry = _STEP_SAVE_MAP.get(pipe_base)`` and
    later ``entry[0]`` / ``entry[1]`` — verify tuple shape."""
    from ide4eeg.preprocessing.preprocessing import _STEP_SAVE_MAP
    for name, entry in _STEP_SAVE_MAP.items():
        assert isinstance(entry, tuple), (
            f"_STEP_SAVE_MAP[{name!r}] must be a tuple for legacy "
            f"consumers that unpack it; got {type(entry).__name__}")
        assert len(entry) == 2, f"{name!r} entry must be (section, suffix)"
        section, suffix = entry
        assert isinstance(section, str) and section, name
        assert isinstance(suffix, str) and suffix, name


def test_step_config_deps_shape_matches_consumer_expectations(qt_gui):
    """preprocessing.py:560 builds ``relevant`` by iterating
    ``_STEP_CONFIG_DEPS[step]`` — verify list-of-str shape."""
    from ide4eeg.preprocessing.preprocessing import _STEP_CONFIG_DEPS
    for name, deps in _STEP_CONFIG_DEPS.items():
        assert isinstance(deps, list), (
            f"_STEP_CONFIG_DEPS[{name!r}] should be a list for "
            f"_compute_step_hash's iteration, got {type(deps).__name__}")
        assert all(isinstance(d, str) for d in deps), name


def test_every_savable_step_has_view_button_via_registry(qt_gui):
    """Sanity-cross-check with the existing test_view_step_result.py
    SAVEABLE_GUI_STEPS list — but derived from STEP_REGISTRY this
    time, so a new step added to the registry must also wire up
    its eye button (or be explicitly excluded)."""
    from ide4eeg.preprocessing.preprocessing import STEP_REGISTRY

    # _GUI_TO_PIPELINE_STEPS is a class attribute; access via the
    # instance.  GUI keys may map to one or many pipeline names
    # (e.g. "artifacts" → ["eeg_artifacts", "gaze_artifacts"]).
    gui_to_pipeline = qt_gui._GUI_TO_PIPELINE_STEPS
    saveable_pipeline = {
        name for name, sd in STEP_REGISTRY.items()
        if sd.save_section is not None
    }
    widgets = dict(qt_gui._step_widgets)
    # Build the inverse: each saveable pipeline name should be
    # reachable from at least one GUI key whose panel has an eye btn.
    pipeline_reached_via_eye_btn = set()
    for gui_key, grp in widgets.items():
        if getattr(grp, "_view_btn", None) is None:
            continue
        # Phase 2 multi-instance steps carry a ":<id>" suffix on the
        # widget key but the lookup table holds bare base names.
        base_key = gui_key.partition(":")[0]
        pipe_names = gui_to_pipeline.get(base_key, base_key)
        if isinstance(pipe_names, (list, tuple)):
            pipeline_reached_via_eye_btn.update(pipe_names)
        else:
            pipeline_reached_via_eye_btn.add(pipe_names)
    # Resample uses two per-side header eyes (resample_before_eye /
    # resample_after_eye in _pp) instead of a panel-level _view_btn —
    # Svarog's --split-signal can't sync across rate changes, so the
    # generic before/after split view doesn't apply.  Count it as
    # covered when the per-side buttons exist.
    pp = getattr(qt_gui, "_pp", {})
    if (pp.get("resample_before_eye") is not None
            and pp.get("resample_after_eye") is not None):
        pipeline_reached_via_eye_btn.add("resample")
    missing = saveable_pipeline - pipeline_reached_via_eye_btn
    assert not missing, (
        f"Saveable pipeline steps in STEP_REGISTRY with no GUI panel "
        f"carrying an eye button: {sorted(missing)}.  Either add a "
        f"panel with _view_btn, or remove save_section from the "
        f"StepDef.")


def test_step_labels_show_in_run_log(qt_gui):
    """The runner emits a log line per step using STEP_LABELS.  A
    missing entry means a step would run silently.  Spot-check that
    every label is non-empty and matches what tests expect."""
    from ide4eeg.preprocessing.preprocessing import STEP_LABELS, STEP_REGISTRY
    assert set(STEP_LABELS) == set(STEP_REGISTRY)
    for name, label in STEP_LABELS.items():
        assert label.strip(), f"empty label for {name!r}"
