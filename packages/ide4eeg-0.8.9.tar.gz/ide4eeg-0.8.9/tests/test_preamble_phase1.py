"""Tests for the Phase 1 preamble split (2026-04).

``_create_stim_channel`` has been split into:

- :func:`_build_event_dict` — pure config operation, no signal touch
- :func:`_add_rest_markers` — additive, attaches ``REST`` annotations
  describing synthetic window onsets and never touches the original
  ``STIM`` channel

These tests lock the contract:

1. ``_build_event_dict`` returns the right dict for each mode, and
   raises with clear errors on misconfiguration.
2. ``_add_rest_markers`` attaches REST annotations whose onsets follow
   the post-trim ``rest_duration`` semantic, leaves the original
   ``STIM`` channel bit-for-bit unchanged, and never preloads the
   signal data (so multi-hour recordings stay lazy through the
   preamble).
3. The pipeline integration: rest mode on a file that already has
   hardware event markers preserves those markers in the output — the
   key behaviour fix Phase 1 was designed to deliver.
"""

import logging

import mne
import numpy as np
import pytest

from ide4eeg.preprocessing.channels_and_signal import (
    _add_rest_markers,
    _build_event_dict,
    get_segment_events,
    REST_ANNOT,
    REST_EVENT_ID,
)


# ── Helpers ─────────────────────────────────────────────────────────


def _make_raw(sfreq=100.0, duration=10.0, n_eeg=2,
              stim_events=None):
    """Build a synthetic RawArray with EEG + one STIM channel.

    *stim_events* is a list of ``(sample_idx, event_id)`` tuples.  If
    omitted, the STIM channel is all zeros.
    """
    rng = np.random.default_rng(123)
    n_samples = int(sfreq * duration)
    eeg_data = rng.standard_normal((n_eeg, n_samples)) * 1e-6

    stim_data = np.zeros((1, n_samples), dtype=np.float64)
    if stim_events:
        for sample, eid in stim_events:
            stim_data[0, sample] = eid

    data = np.vstack([eeg_data, stim_data])
    ch_names = [f"EEG{i + 1}" for i in range(n_eeg)] + ["STIM"]
    ch_types = ["eeg"] * n_eeg + ["stim"]
    info = mne.create_info(ch_names, sfreq=sfreq, ch_types=ch_types)
    return mne.io.RawArray(data, info, verbose=False)


# ── _build_event_dict ───────────────────────────────────────────────


class TestBuildEventDict:
    """Pure config operation: no signal required."""

    def test_rest_mode_returns_rest_entry(self):
        cfg = {"segmentation": {"mode": "rest"}}
        d = _build_event_dict(cfg, events_desc_id={})
        assert d == {"rest": REST_EVENT_ID}

    def test_rest_mode_ignores_file_events(self):
        """Even if the file has events, rest mode doesn't consult
        them — the returned dict is {'rest': REST_EVENT_ID}."""
        cfg = {"segmentation": {"mode": "rest"}}
        d = _build_event_dict(
            cfg, events_desc_id={"target": 1, "nontarget": 2})
        assert d == {"rest": REST_EVENT_ID}

    def test_epochs_mode_selected_format(self):
        cfg = {
            "segmentation": {"mode": "epochs"},
            "epochs": {"tags": {"selected": ["target", "nontarget"]}},
        }
        d = _build_event_dict(
            cfg, events_desc_id={"target": 1, "nontarget": 2, "other": 3})
        assert d == {"target": 1, "nontarget": 2}

    def test_epochs_mode_no_events_raises(self):
        cfg = {
            "segmentation": {"mode": "epochs"},
            "epochs": {"tags": {"selected": ["target"]}},
        }
        with pytest.raises(ValueError,
                           match="requires event markers"):
            _build_event_dict(cfg, events_desc_id={})

    def test_epochs_mode_empty_selection_raises(self):
        cfg = {
            "segmentation": {"mode": "epochs"},
            "epochs": {"tags": {"selected": []}},
        }
        with pytest.raises(ValueError, match="No events selected"):
            _build_event_dict(cfg, events_desc_id={"target": 1})

    def test_epochs_mode_no_match_raises(self):
        """Selected names present but none match file events."""
        cfg = {
            "segmentation": {"mode": "epochs"},
            "epochs": {"tags": {"selected": ["stop"]}},
        }
        with pytest.raises(ValueError, match="No events matched"):
            _build_event_dict(
                cfg, events_desc_id={"target": 1, "nontarget": 2})

    def test_epochs_mode_legacy_auto_format(self):
        cfg = {
            "segmentation": {"mode": "epochs"},
            "epochs": {"tags": {"AUTO": True}},
        }
        d = _build_event_dict(
            cfg, events_desc_id={"target_a": 1, "nontarget_b": 2})
        assert "target/target_a" in d
        assert "nontarget/nontarget_b" in d

    def test_unknown_mode_raises(self):
        cfg = {"segmentation": {"mode": "bogus"}}
        with pytest.raises(ValueError, match="rest.*or.*epochs"):
            _build_event_dict(cfg, events_desc_id={})


# ── _add_rest_markers ───────────────────────────────────────────────


class TestAddRestMarkers:
    """Additive behaviour: attaches REST annotations, never touches STIM."""

    def _make_cfg(self, window_length=1.0, rest_duration=(0, "")):
        return {
            "segmentation": {"mode": "rest"},
            "rest": {
                "window_length": window_length,
                "rest_duration": list(rest_duration),
                "whole_signal": False,
            },
        }

    def test_rest_annotations_are_added(self):
        raw = _make_raw(sfreq=100, duration=10)
        cfg = self._make_cfg(window_length=2.0)

        out = _add_rest_markers(raw, cfg)

        descs = list(out.annotations.description)
        assert REST_ANNOT in descs

    def test_original_stim_is_not_modified(self):
        # Seed STIM with file events; after _add_rest_markers those
        # events must survive unchanged.
        file_events = [(100, 1), (300, 2), (500, 1), (700, 2)]
        raw = _make_raw(sfreq=100, duration=10,
                        stim_events=file_events)
        cfg = self._make_cfg(window_length=2.0)

        stim_before = raw.get_data(picks="STIM")[0].copy()
        out = _add_rest_markers(raw, cfg)
        stim_after = out.get_data(picks="STIM")[0]

        # Bit-for-bit equality — append-only invariant.
        np.testing.assert_array_equal(stim_before, stim_after)
        # And nonzero positions are exactly the file events.
        nonzero_samples = np.where(stim_after != 0)[0]
        expected_samples = np.array([s for s, _ in file_events])
        np.testing.assert_array_equal(nonzero_samples, expected_samples)

    def test_rest_markers_at_expected_positions(self):
        """``window_length=2`` s at 100 Hz over a 10 s signal.

        The signal has 1000 samples (indices 0..999), so
        ``signal.times[-1] = 9.99``.  The loop stops at ``stop_n =
        round(9.99*100) = 999``, giving ``999 // 200 = 4`` windows at
        samples 0, 200, 400, 600 (the fifth window at 800 would need
        200 more samples, but only 199 remain).
        """
        raw = _make_raw(sfreq=100, duration=10)
        cfg = self._make_cfg(window_length=2.0)

        out = _add_rest_markers(raw, cfg)
        rest_onsets = [a["onset"] for a in out.annotations
                       if a["description"] == REST_ANNOT]
        rest_samples = (np.array(rest_onsets) * 100).round().astype(int)

        assert len(rest_samples) == 4
        np.testing.assert_array_equal(
            rest_samples, np.array([0, 200, 400, 600]))

    def test_rest_markers_use_post_trim_coordinates(self):
        """After trim, the signal's t=0 is the start of the trimmed
        data.  ``rest_duration = [2, 8]`` should therefore mean "cover
        seconds 2-8 of the current (trimmed) signal", not "seconds 2-8
        of the original".  This test locks the Phase 1 post-trim
        semantic."""
        raw = _make_raw(sfreq=100, duration=10)  # 10 s signal
        cfg = self._make_cfg(
            window_length=2.0, rest_duration=(2, 8))

        out = _add_rest_markers(raw, cfg)
        rest_samples = np.array(
            [round(a["onset"] * 100)
             for a in out.annotations
             if a["description"] == REST_ANNOT], dtype=int)

        # window_length=2 s over [2, 8] s → 3 windows at 2, 4, 6 s
        # (i.e. samples 200, 400, 600 at sfreq=100)
        np.testing.assert_array_equal(
            rest_samples, np.array([200, 400, 600]))

    def test_add_rest_markers_is_idempotent_on_signal_length(self):
        raw = _make_raw(sfreq=250, duration=6)
        n_samples_before = raw.n_times
        n_channels_before = raw.info["nchan"]
        cfg = self._make_cfg(window_length=1.0)

        out = _add_rest_markers(raw, cfg)
        assert out.n_times == n_samples_before
        assert out.info["nchan"] == n_channels_before

    def test_add_rest_markers_does_not_preload(self):
        """Annotations don't require ``load_data()`` — the preamble
        must stay lazy on signals that aren't already preloaded."""
        raw = _make_raw(sfreq=100, duration=10)
        # Force the synthetic raw to look lazy by clearing _data.
        # (RawArray is preloaded by construction; this simulates a
        # lazy file-backed reader.)
        if raw.preload:
            raw._data = None
            raw.preload = False
        cfg = self._make_cfg(window_length=2.0)

        out = _add_rest_markers(raw, cfg)
        # Still lazy after the step.
        assert not out.preload

    def test_rest_markers_round_trip_through_events_after_crop(self):
        """Regression: when the signal has been cropped to a non-zero
        first_samp (the realistic flow: trim_signal does
        ``signal.crop(tmin=...)`` before add_rest_markers runs), the
        attached REST annotations must survive a round-trip through
        ``events_from_annotations`` and produce events at the right
        sample offsets.

        The original annotation-based implementation used onsets in
        cropped-signal coordinates with ``orig_time=meas_date``.  MNE
        treats those as absolute timestamps, so cut_segments saw zero
        events (annotations landed before the cropped window).
        """
        # Build a 30 s raw with a fake meas_date so orig_time is set,
        # then crop to [10, 20] s — first_samp jumps to 10*100=1000.
        from datetime import datetime, timezone
        raw = _make_raw(sfreq=100, duration=30)
        raw.set_meas_date(
            datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc))
        raw.crop(tmin=10.0, tmax=20.0)
        assert raw.first_samp == 1000

        cfg = self._make_cfg(window_length=2.0)
        out = _add_rest_markers(raw, cfg)

        events = get_segment_events(out, {"segmentation": {"mode": "rest"}})
        # 5 windows of 2 s in a 10 s cropped signal at sfreq=100 →
        # cropped offsets 0, 200, 400, 600, 800.  events_from_annotations
        # returns sample indices in absolute coordinates (first_samp
        # included), matching mne.find_events convention; mne.Epochs
        # subtracts first_samp internally to land on the right cropped
        # samples.
        first_samp = out.first_samp
        np.testing.assert_array_equal(
            events[:, 0],
            first_samp + np.array([0, 200, 400, 600, 800]))
        assert np.all(events[:, 2] == REST_EVENT_ID)

        # And mne.Epochs builds correctly on these events — the
        # round-trip through cut_segments would have failed at
        # this step before the fix.
        epochs = mne.Epochs(out, events,
                            event_id={"REST": REST_EVENT_ID},
                            tmin=0.0, tmax=1.0, baseline=None,
                            preload=False, verbose=False)
        assert len(epochs.events) == 5

    def test_rest_markers_coexist_with_file_events(self):
        """REST annotations and file events in STIM live in different
        spaces (annotations vs channel data), so they can't collide."""
        raw = _make_raw(sfreq=100, duration=10,
                        stim_events=[(100, 1), (300, 1)])
        cfg = self._make_cfg(window_length=2.0)

        out = _add_rest_markers(raw, cfg)
        stim = out.get_data(picks="STIM")[0]
        rest_onsets = [a["onset"] for a in out.annotations
                       if a["description"] == REST_ANNOT]

        # STIM has the file events, annotations have the rest windows.
        assert np.sum(stim != 0) == 2
        assert len(rest_onsets) == 4
        assert stim[100] == 1 and stim[300] == 1
        # First rest marker at t=0.
        assert rest_onsets[0] == 0.0

    def test_rerunning_strips_old_rest_annotations(self):
        """``_add_rest_markers`` must be idempotent under re-entry —
        the truncated-pipeline view path can re-run the preamble."""
        raw = _make_raw(sfreq=100, duration=10)
        cfg = self._make_cfg(window_length=2.0)

        out1 = _add_rest_markers(raw, cfg)
        n_rest1 = sum(1 for a in out1.annotations
                      if a["description"] == REST_ANNOT)
        out2 = _add_rest_markers(out1, cfg)
        n_rest2 = sum(1 for a in out2.annotations
                      if a["description"] == REST_ANNOT)
        assert n_rest1 == n_rest2 > 0


# ── Pipeline integration: the fix we shipped Phase 1 for ─────────────


class TestRestModePreservesFileEvents:
    """End-to-end behaviour: the reason Phase 1 exists.

    Before: a file with hardware event markers analysed in rest mode
    had its STIM channel overwritten, destroying the original events.
    After: STIM stays intact, REST annotations carry the synthetic
    windows, and downstream saved outputs still contain the file's
    events for later inspection.
    """

    def test_cut_segments_uses_rest_annotations_in_rest_mode(self, tmp_path):
        from ide4eeg.preprocessing.rest_and_epochs import _cut_segments

        # File with 4 hardware events in STIM at non-zero IDs.
        file_events = [(100, 1), (300, 2), (500, 1), (700, 2)]
        raw = _make_raw(sfreq=100, duration=10,
                        stim_events=file_events)
        cfg = {
            "segmentation": {"mode": "rest"},
            "rest": {
                "window_length": 2.0,
                "rest_duration": [0, ""],
                "whole_signal": False,
            },
        }
        raw = _add_rest_markers(raw, cfg)

        tags = {"rest": REST_EVENT_ID}
        segments, events = _cut_segments(raw, cfg, tags)

        # Segments come from rest-window onsets, not file events.
        # 4 windows starting at samples 0, 200, 400, 600 (see
        # test_rest_markers_at_expected_positions for the off-by-one).
        assert len(events) == 4
        # All events must carry the rest ID.
        assert np.all(events[:, 2] == REST_EVENT_ID)

    def test_stim_survives_into_saved_signal(self, tmp_path):
        """The critical test: after running rest mode, the signal
        that would be saved for inspection still has the original
        STIM events intact."""
        file_events = [(100, 1), (300, 2)]
        raw = _make_raw(sfreq=100, duration=10,
                        stim_events=file_events)
        cfg = {
            "segmentation": {"mode": "rest"},
            "rest": {
                "window_length": 2.0,
                "rest_duration": [0, ""],
                "whole_signal": False,
            },
        }

        out = _add_rest_markers(raw, cfg)
        stim = out.get_data(picks="STIM")[0]

        # Original file events still present.
        assert stim[100] == 1
        assert stim[300] == 2
        # And nothing extra was written into STIM.
        nonzero = np.where(stim != 0)[0]
        assert set(nonzero.tolist()) == {100, 300}

    def test_cut_segments_drops_all_stim_channels(self):
        """Epochs returned by _cut_segments must have no stim-type
        channels, regardless of how many the input had."""
        from ide4eeg.preprocessing.rest_and_epochs import _cut_segments

        raw = _make_raw(sfreq=100, duration=10,
                        stim_events=[(100, 1), (500, 1)])
        cfg = {
            "segmentation": {"mode": "rest"},
            "rest": {
                "window_length": 2.0,
                "rest_duration": [0, ""],
                "whole_signal": False,
            },
        }
        raw = _add_rest_markers(raw, cfg)

        tags = {"rest": REST_EVENT_ID}
        segments, _ = _cut_segments(raw, cfg, tags)

        stim_in_epochs = [
            c for i, c in enumerate(segments.ch_names)
            if mne.channel_type(segments.info, i) == "stim"
        ]
        assert stim_in_epochs == []


class TestLegacyStimRestFallback:
    """Old saved snapshots (before 2026-04) carry a STIM_rest channel
    instead of REST annotations.  ``get_segment_events`` must still
    pick those up so users can re-open existing snapshots."""

    def test_legacy_snapshot_falls_back_to_stim_rest(self):
        # Build a raw with a synthetic STIM_rest channel and NO REST
        # annotations — simulating an old saved snapshot.
        sfreq = 100.0
        duration = 10.0
        n_samples = int(sfreq * duration)
        rng = np.random.default_rng(0)
        eeg = rng.standard_normal((2, n_samples)) * 1e-6
        stim = np.zeros((1, n_samples))
        stim_rest = np.zeros((1, n_samples))
        # Four legacy rest pulses at samples 0, 200, 400, 600.
        for s in (0, 200, 400, 600):
            stim_rest[0, s] = REST_EVENT_ID
        data = np.vstack([eeg, stim, stim_rest])
        info = mne.create_info(
            ["EEG1", "EEG2", "STIM", "STIM_rest"], sfreq=sfreq,
            ch_types=["eeg", "eeg", "stim", "stim"])
        raw = mne.io.RawArray(data, info, verbose=False)
        # Sanity: no REST annotations.
        assert REST_ANNOT not in set(raw.annotations.description)

        cfg = {"segmentation": {"mode": "rest"}}
        events = get_segment_events(raw, cfg)
        assert len(events) == 4
        np.testing.assert_array_equal(
            events[:, 0], np.array([0, 200, 400, 600]))
        assert np.all(events[:, 2] == REST_EVENT_ID)


# ── Trim is reorderable: events must stay correct in any position ────


class TestEventCorrectnessAcrossTrimPosition:
    """``trim`` is a reorderable step (``preprocessing.py``
    ``DEFAULT_STEP_ORDER``).  Events — both REST annotations and
    file-derived STIM markers — must land at the right times in the
    final signal regardless of whether trim ran before or after other
    sample-mutating steps like resample.
    """

    def test_rest_events_correct_with_trim_after_resample(self):
        """Run resample → trim → add_rest_markers (the non-default
        order) and verify REST events land at the right cropped
        times.  Default order (trim first) is already covered by
        ``test_rest_markers_round_trip_through_events_after_crop``.
        """
        from datetime import datetime, timezone
        from ide4eeg.preprocessing.channels_and_signal import (
            _trim_signal, _resample_signal, _add_rest_markers,
            get_segment_events)

        # 30 s × 1000 Hz raw, meas_date set so orig_time triggers the
        # cropped-coords annotation shift in _add_rest_markers.
        raw = _make_raw(sfreq=1000, duration=30, n_eeg=2)
        raw.set_meas_date(
            datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc))

        cfg = {
            "segmentation": {"mode": "rest"},
            "trim_start": 5.0,
            "trim_end": 24.0,             # 19 s cropped — clean math
            "resample_freq": 250,
            "rest": {"window_length": 4.0,
                     "rest_duration": [0, ""],
                     "whole_signal": False},
        }

        # Resample first, then trim, then mark.
        sig = _resample_signal(raw, dict(cfg, sfreq=raw.info["sfreq"]))
        sig, cfg = _trim_signal(sig, dict(cfg))
        sig = _add_rest_markers(sig, dict(cfg))

        events = get_segment_events(sig, cfg)
        # 4 windows of 4 s in 19 s.
        assert len(events) == 4
        # Cropped times: 0, 4, 8, 12 s.
        cropped_times = ((events[:, 0] - sig.first_samp)
                         / sig.info["sfreq"])
        np.testing.assert_allclose(
            cropped_times, np.array([0.0, 4.0, 8.0, 12.0]), atol=5e-3)
        assert np.all(events[:, 2] == REST_EVENT_ID)

    def test_stim_events_survive_trim_after_resample(self):
        """File-derived STIM events must still be findable when trim
        runs *after* resample.  Resample decimates stim channels (no
        smearing), trim's MNE crop preserves event positions in the
        kept window."""
        from ide4eeg.preprocessing.channels_and_signal import (
            _trim_signal, _resample_signal, get_segment_events)

        # 30 s at 1000 Hz, STIM events at 5 / 10 / 15 / 20 / 25 s
        # (samples 5000, 10000, 15000, 20000, 25000) all coded 99.
        events_s = [(5000, 99), (10000, 99), (15000, 99),
                    (20000, 99), (25000, 99)]
        raw = _make_raw(sfreq=1000, duration=30, n_eeg=2,
                        stim_events=events_s)

        cfg = {
            "segmentation": {"mode": "epochs"},
            "trim_start": 8.0,
            "trim_end": 22.0,
            "resample_freq": 250,
        }

        # Resample first, then trim — the non-default reorder.
        sig = _resample_signal(raw, dict(cfg, sfreq=raw.info["sfreq"]))
        sig, _ = _trim_signal(sig, dict(cfg))

        events = get_segment_events(sig, cfg)
        # Only events inside [8, 22] s survive: those at 10, 15, 20.
        assert len(events) == 3
        # All carry the original event ID.
        assert np.all(events[:, 2] == 99)
        # In cropped seconds: 10-8=2, 15-8=7, 20-8=12.
        cropped_times = ((events[:, 0] - sig.first_samp)
                         / sig.info["sfreq"])
        np.testing.assert_allclose(
            cropped_times, np.array([2.0, 7.0, 12.0]), atol=5e-3)
