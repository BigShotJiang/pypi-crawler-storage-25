"""End-to-end Stage-5 preflight smoke tests against the shipped example.

These tests are the answer to the v0.8.8 false-positive bug class:
an existing example config + an existing example signal should
produce ZERO spurious preflight issues, and toggling any consumer
on/off should not introduce false positives.  Catches the bug
class "rule fires when its trigger is technically true but its
consumer step / analysis is disabled."

Methodology (one example, many cfg permutations — preflight is
metadata-only and fast, so we can run dozens of permutations in
under a second):

1.  **Gold standard.**  Load ``examples/dipole_spindles/
    config_dipole_spindles.toml`` against
    ``~/IDE4EEG_examples/dipole_spindles/dipoles_example.raw``,
    run preflight, assert NO error-severity issues fire.  This
    is the "this example works out of the box" lock.

2.  **Single-knob mutations.**  For each preprocessing step in
    the default ``step_order``, remove it and re-run preflight.
    None of the *channel rules* that gate on a now-disabled
    consumer should fire.  Same for each ``prepare_*`` analysis
    flag.

3.  **Empty pipeline.**  ``step_order = []`` + every
    ``prepare_*`` false: should be silent (no analyses scheduled
    means no cfg field is "stale").

Tests skip when the example data file isn't present (e.g. fresh
CI checkout that hasn't run ``ide4eeg.download_examples``).
"""
from __future__ import annotations

import copy
import os
import tomllib
from pathlib import Path

import pytest


# Locations.  CLAUDE.md "Runtime data layout" says examples live at
# ``~/IDE4EEG_examples/<name>/``; configs are git-tracked under
# ``examples/<name>/``.
_REPO_ROOT = Path(__file__).resolve().parent.parent
_EXAMPLES_CFG_DIR = _REPO_ROOT / "examples"
_EXAMPLES_DATA_DIR = Path.home() / "IDE4EEG_examples"

_DIPOLE_EXAMPLE_CFG = (
    _EXAMPLES_CFG_DIR / "dipole_spindles" / "config_dipole_spindles.toml")
_DIPOLE_EXAMPLE_DATA = (
    _EXAMPLES_DATA_DIR / "dipole_spindles" / "dipoles_example.raw")


def _need_example_data():
    """Skip the test if the example signal isn't downloaded yet."""
    if not _DIPOLE_EXAMPLE_CFG.is_file():
        pytest.skip(f"example config missing: {_DIPOLE_EXAMPLE_CFG}")
    if not _DIPOLE_EXAMPLE_DATA.is_file():
        pytest.skip(
            f"example data missing: {_DIPOLE_EXAMPLE_DATA}.  "
            "Run ide4eeg.download_examples to fetch it.")


def _load_example_cfg() -> dict:
    """Read the example's default TOML cfg, attach an absolute
    input_path pointing at the downloaded signal file."""
    with _DIPOLE_EXAMPLE_CFG.open("rb") as fh:
        cfg = tomllib.load(fh)
    cfg["input_path"] = str(_DIPOLE_EXAMPLE_DATA)
    return cfg


def _peek_signal_info(path):
    """Read header-only info (channel names, sfreq, etc.) without
    loading the signal."""
    from ide4eeg.input.input import read_file_info
    info = read_file_info(str(path))
    assert info is not None, f"read_file_info returned None for {path}"
    return info


def _build_state(cfg, info, fire_point="pre_launch"):
    """Build a Stage 5 State from cfg + peeked signal info."""
    from ide4eeg.validators._state import capture_from_cfg_and_info
    ch_names = tuple(info.get("ch_names") or ())
    ch_types_list = info.get("ch_types") or []
    ch_types = (
        {n: t for n, t in zip(ch_names, ch_types_list)}
        if ch_names and ch_types_list else None)
    return capture_from_cfg_and_info(
        cfg, fire_point=fire_point,
        ch_names=ch_names if ch_names else None,
        ch_types=ch_types,
        sfreq=info.get("sfreq"),
        duration=info.get("duration"),
        probe_tools=False)


def _run_preflight(cfg, info):
    """Dispatch every pre_launch rule and return the emitted issues."""
    import ide4eeg.validators.hard  # populate registry
    from ide4eeg.validators import run_at
    state = _build_state(cfg, info)
    return run_at("pre_launch", state)


# ---------------------------------------------------------------------
# 1. Gold standard — shipped example must pass preflight cleanly
# ---------------------------------------------------------------------

class TestGoldStandardConfig:
    def test_default_example_config_produces_no_errors(self):
        """The shipped ``config_dipole_spindles.toml`` against the
        shipped data file is the canonical "this works" baseline.
        ANY error-severity preflight issue here is a regression.
        Warnings are allowed (e.g. soft step-order recommendations
        the example may deliberately violate)."""
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        issues = _run_preflight(cfg, info)
        errors = [i for i in issues if i.severity == "error"]
        assert errors == [], (
            "Shipped example produces preflight errors — regression "
            f"in rule definitions or cfg drift: {errors}")

    def test_default_example_no_channel_rule_false_positives(self):
        """No channel-rule warning should fire on the gold standard
        cfg either.  This catches the v0.8.8 bug class directly:
        ICA disabled by default, but ICA_EOG cfg populated → rule
        used to fire."""
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        issues = _run_preflight(cfg, info)
        channel_issues = [
            i for i in issues
            if i.rule_id.startswith("hard.channels.")
            or i.rule_id == "hard.reference.reref_channels_present"
            or i.rule_id == "hard.dipole.ref_channel_present"
        ]
        assert channel_issues == [], (
            "Channel-existence rule fired on the gold-standard cfg — "
            "the rule is over-eager (likely missing a consumer-enabled "
            f"gate).  Issues: "
            f"{[(i.rule_id, i.message) for i in channel_issues]}")


# ---------------------------------------------------------------------
# 2. Single-knob mutations — disabling a consumer step must not
#    introduce a false positive on any rule scoped to that consumer.
# ---------------------------------------------------------------------

def _step_orders_to_test(default_order: list[str]) -> list[tuple[str, list[str]]]:
    """For each step in the default order, build a variant that
    REMOVES it.  Returns (label, variant_order) pairs."""
    variants = [("EMPTY", [])]
    for step in default_order:
        variant = [s for s in default_order if s != step]
        variants.append((f"WITHOUT_{step}", variant))
    return variants


_ANALYSIS_FLAGS = (
    "prepare_dipole_fitting",
    "prepare_eeg_profiles",
    "prepare_connectivity_analysis",
    "prepare_mp_filter",
)


class TestStepOrderMutations:
    @pytest.mark.parametrize("ignored", [None])  # placeholder
    def test_removing_each_step_introduces_no_channel_false_positives(
            self, ignored):
        """For each preprocessing step in the default step_order,
        remove it and re-run preflight.  Channel rules gated on that
        step's enable-state should now be silent — not introduce a
        FRESH "missing channel" warning that wasn't there before."""
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        base_order = list(
            cfg.get("preprocessing", {}).get("step_order", []) or [])
        # Baseline: rules that fire under the default config.  Any
        # rule that fires when ITS consumer is removed but was silent
        # in baseline is a false positive.
        baseline_issues = _run_preflight(cfg, info)
        baseline_rule_ids = {i.rule_id for i in baseline_issues}

        false_positives = []
        for label, variant in _step_orders_to_test(base_order):
            variant_cfg = copy.deepcopy(cfg)
            variant_cfg.setdefault(
                "preprocessing", {})["step_order"] = variant
            variant_issues = _run_preflight(variant_cfg, info)
            for issue in variant_issues:
                if issue.rule_id in baseline_rule_ids:
                    continue  # already fired in baseline; not new
                # New issue in a stripped-down pipeline → could be
                # legitimate ("you turned off X, now Y is required")
                # but channel-existence warnings are almost always
                # false positives in this scenario.
                if issue.rule_id.startswith("hard.channels."):
                    false_positives.append((label, issue.rule_id,
                                            issue.message))
        assert not false_positives, (
            "Removing a step introduced channel-rule warnings that "
            f"weren't in the baseline: {false_positives}")

    def test_disabling_each_analysis_introduces_no_channel_false_positives(
            self):
        """Same idea for the four ``prepare_*`` flags."""
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        baseline_rule_ids = {i.rule_id for i in _run_preflight(cfg, info)}

        false_positives = []
        for flag in _ANALYSIS_FLAGS:
            variant_cfg = copy.deepcopy(cfg)
            variant_cfg[flag] = False
            for issue in _run_preflight(variant_cfg, info):
                if issue.rule_id in baseline_rule_ids:
                    continue
                if issue.rule_id.startswith("hard.channels."):
                    false_positives.append(
                        (f"DISABLED_{flag}", issue.rule_id, issue.message))
        assert not false_positives, (
            f"Disabling an analysis introduced channel-rule warnings: "
            f"{false_positives}")


# ---------------------------------------------------------------------
# 3. Empty pipeline — nothing runs, nothing should fire
# ---------------------------------------------------------------------

class TestEnableMutations:
    """The inverse of the disable-mutation tests: ENABLING a step
    that's normally OFF on the example must surface the expected
    Issues (rule fires when expected) and NOT surface false issues
    for steps unrelated to the new mutation.

    The v0.8.8 false-positive bug was structurally invisible to the
    "disable each step" mutation matrix above because the bug shape
    was the inverse: the cfg field was set for a step that was OFF,
    and the rule fired anyway.  These tests catch that direction.
    """

    def test_enabling_ica_with_eog_cfg_makes_rule_fire(self):
        """ICA is OFF on the dipole example by default and EOG cfg
        is populated.  After v0.8.8 fix, the rule should be silent
        in the default state and FIRE only when ICA is explicitly
        added to step_order.  This locks BOTH directions."""
        _need_example_data()
        cfg_base = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        # Default (ICA off): rule silent for the EOG cfg
        baseline = _run_preflight(cfg_base, info)
        baseline_ica = [
            i for i in baseline
            if i.rule_id == "hard.channels.ica_eog_channels_present"]
        assert baseline_ica == [], (
            "ICA-EOG rule fired on default example (ICA off) -- this "
            "is the v0.8.8 regression shape.")

        # Turn ICA ON: now if find_bads_eog_ch references a missing
        # channel, the rule SHOULD fire.
        cfg_with_ica = copy.deepcopy(cfg_base)
        order = list(
            cfg_with_ica.setdefault("preprocessing", {}).get(
                "step_order", []) or [])
        if "ica" not in order:
            order.append("ica")
        cfg_with_ica["preprocessing"]["step_order"] = order
        cfg_with_ica["ICA_EOG"] = {"find_bads_eog_ch": ["GHOST_EOG"]}
        enabled_issues = _run_preflight(cfg_with_ica, info)
        ica_issues = [
            i for i in enabled_issues
            if i.rule_id == "hard.channels.ica_eog_channels_present"]
        assert len(ica_issues) == 1, (
            "Enabling ICA + stale EOG cfg should produce exactly "
            f"one ICA-EOG warning, got {len(ica_issues)}: "
            f"{[i.message for i in ica_issues]}")
        assert "GHOST_EOG" in ica_issues[0].message

    def test_enabling_dipole_with_bad_ref_fires_rule(self):
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        # Default dipole-spindles example DOES enable
        # prepare_dipole_fitting; that's covered by the gold-
        # standard test.  Here we mutate to BREAK it.
        cfg["prepare_dipole_fitting"] = True
        cfg.setdefault("dipole_fitting", {})["ref_channel"] = "GHOST_REF"
        issues = _run_preflight(cfg, info)
        ref_issues = [
            i for i in issues
            if i.rule_id == "hard.dipole.ref_channel_present"]
        assert len(ref_issues) == 1
        assert ref_issues[0].severity == "error"
        assert "GHOST_REF" in ref_issues[0].message

    def test_ica_in_step_order_but_gui_checkbox_off(self):
        """v0.8.9 audit pass 3 regression: GUI per-step checkbox in
        ``preprocessing.enabled_steps`` can disable a step without
        removing it from ``step_order``.  The runtime strips it;
        the rule must NOT fire."""
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        order = list(cfg.setdefault(
            "preprocessing", {}).get("step_order", []) or [])
        if "ica" not in order:
            order.append("ica")
        cfg["preprocessing"]["step_order"] = order
        cfg["preprocessing"]["enabled_steps"] = {"ica": False}
        # Stale EOG cfg that would fire IF the gate didn't catch
        # the GUI-disabled state.
        cfg["ICA_EOG"] = {"find_bads_eog_ch": ["GHOST_EOG"]}

        issues = _run_preflight(cfg, info)
        ica_issues = [
            i for i in issues
            if i.rule_id == "hard.channels.ica_eog_channels_present"]
        assert ica_issues == [], (
            "ICA-EOG rule fired despite enabled_steps.ica=False -- "
            "the GUI checkbox should fully disable the consumer.")

    def test_signal_setup_gates_both_montage_and_reference(self):
        """The ``signal_setup`` GUI checkbox controls TWO pipeline
        steps (``montage`` + ``reference``).  Disabling it must
        suppress channel rules on BOTH — verifies the mapping in
        ``_STEP_TO_GUI_ENABLED_KEY`` correctly mirrors the runtime's
        ``_ENABLED_TO_STEPS`` (where ``signal_setup`` -> two tokens)."""
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        order = list(cfg.setdefault(
            "preprocessing", {}).get("step_order", []) or [])
        for s in ("montage", "reference"):
            if s not in order:
                order.append(s)
        cfg["preprocessing"]["step_order"] = order
        cfg["preprocessing"]["enabled_steps"] = {"signal_setup": False}
        # Stale references that BOTH montage- and reference-tied
        # rules would normally fire on.
        cfg["re_reference"] = {"channels": ["GHOST_M1", "GHOST_M2"]}

        issues = _run_preflight(cfg, info)
        ref_issues = [
            i for i in issues
            if "reref" in i.rule_id.lower()
            or "reference" in i.rule_id.lower()]
        assert ref_issues == [], (
            "reference-tied rules fired despite signal_setup=False -- "
            f"got: {[(i.rule_id, i.message[:60]) for i in ref_issues]}")

    def test_mp_filter_in_step_order_but_prepare_flag_off(self):
        """Specific regression test for v0.8.9 audit B1 finding:
        ``mp_filter`` token in ``step_order`` but ``prepare_mp_filter
        = False`` → runtime strips the step.  The MP-book consumer
        rule must NOT fire a fatal error in this case (the step
        won't run)."""
        _need_example_data()
        cfg = _load_example_cfg()
        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        order = list(cfg.setdefault(
            "preprocessing", {}).get("step_order", []) or [])
        if "mp_filter" not in order:
            order.append("mp_filter")
        cfg["preprocessing"]["step_order"] = order
        cfg["prepare_mp_filter"] = False
        cfg.pop("_mp_book_path", None)

        issues = _run_preflight(cfg, info)
        mp_filter_issues = [
            i for i in issues
            if i.rule_id == "hard.step_order.mp_filter_requires_mp_available"]
        assert mp_filter_issues == [], (
            "mp_filter-book rule fired despite prepare_mp_filter=False "
            "(runtime would strip the step anyway): "
            f"{[(i.severity, i.message) for i in mp_filter_issues]}")


class TestEmptyPipeline:
    def test_empty_pipeline_silent_on_stale_channel_cfg(self):
        """Cfg with step_order=[] + every analysis off + leftover
        channel-name lists from a prior recording → preflight must
        be silent.  This is the canonical v0.8.8 regression scenario:
        the user disabled everything via the GUI but the TOML still
        carries the analysis cfg, and rules should NOT fire on
        inert cfg."""
        _need_example_data()
        cfg = _load_example_cfg()
        cfg.setdefault("preprocessing", {})["step_order"] = []
        for flag in _ANALYSIS_FLAGS:
            cfg[flag] = False
        # Plant stale channel-name cfg that would fire if rules
        # didn't gate on consumer-enabled.
        cfg["ICA_EOG"] = {"find_bads_eog_ch": ["NONEXISTENT_EOG"]}
        cfg["dipole_fitting"] = dict(cfg.get("dipole_fitting") or {})
        cfg["dipole_fitting"]["ignored_channels"] = ["GHOST"]
        cfg["matching_pursuit"] = dict(cfg.get("matching_pursuit") or {})
        cfg["matching_pursuit"]["channels"] = ["ALSO_GHOST"]

        info = _peek_signal_info(_DIPOLE_EXAMPLE_DATA)
        issues = _run_preflight(cfg, info)

        channel_issues = [
            i for i in issues
            if i.rule_id.startswith("hard.channels.")
            or i.rule_id == "hard.reference.reref_channels_present"
            or i.rule_id == "hard.dipole.ref_channel_present"
        ]
        assert channel_issues == [], (
            "Channel rules fired on an empty-pipeline cfg with stale "
            "channel-name leftovers — this is the v0.8.8 regression "
            f"shape.  Issues: "
            f"{[(i.rule_id, i.message) for i in channel_issues]}")
