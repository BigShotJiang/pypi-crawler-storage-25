# Demo Assets Placeholder

Add your screenshots/GIF here and keep these filenames for README references:

- `cli-workflow.png`
- `visual-workflow.png`
- `mcp-workflow.png`
- `saurix-demo.gif`

Suggested capture flow:

1. CLI: `index`, `stats`, `find`, `impact`
2. Visual UI: search + edge filters + path highlight
3. MCP: `index_repo` -> `find_symbol` -> `path_between` -> `impact_of_symbol`
