import aiohttp
import asyncio
import random
import argparse
import sys
import os
import glob


NEXUS_URL = "http://192.168.2.174:8081"
USERNAME = "T3N1bGNvZGUueGlhbw=="
PASSWORD = "T3N1bGNvZGUueGlhb0AxMjM="
REPOSITORY = "shengye"


async def upload(file_path: str, nexus_url: str = NEXUS_URL,
                 username: str = USERNAME, password: str = PASSWORD,
                 repository: str = REPOSITORY) -> bool:
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return False

    jar = aiohttp.CookieJar(unsafe=True)
    async with aiohttp.ClientSession(cookie_jar=jar) as session:
        async with session.get(f"{nexus_url}/") as resp:
            resp.raise_for_status()

        async with session.post(
            f"{nexus_url}/service/rapture/session",
            data={"username": username, "password": password},
        ) as resp:
            resp.raise_for_status()

        csrf_token = str(random.random())
        session.cookie_jar.update_cookies(
            {"NX-ANTI-CSRF-TOKEN": csrf_token},
            response_url=aiohttp.client.URL(nexus_url),
        )

        filename = os.path.basename(file_path)
        data = aiohttp.FormData()
        data.add_field("NX-ANTI-CSRF-TOKEN", csrf_token)
        data.add_field(
            "asset0", open(file_path, "rb"),
            filename=filename, content_type="application/octet-stream",
        )

        async with session.post(
            f"{nexus_url}/service/rest/internal/ui/upload/{repository}",
            data=data,
        ) as resp:
            status = resp.status
            text = await resp.text()

        if status in (200, 204):
            print(f"Upload successful: {filename} -> {repository}")
            return True
        else:
            print(f"Upload failed ({status}): {text}")
            return False


def main():
    parser = argparse.ArgumentParser(
        prog="nexus-upload",
        description="上传 whl 包到 Nexus 仓库",
    )
    parser.add_argument(
        "file", nargs="?", default=None,
        help="whl 文件路径 (默认: dist/*.whl 中最新的)",
    )
    parser.add_argument(
        "--url", default=NEXUS_URL,
        help=f"Nexus 地址 (默认: {NEXUS_URL})",
    )
    parser.add_argument(
        "-r", "--repository", default=REPOSITORY,
        help=f"仓库名称 (默认: {REPOSITORY})",
    )

    args = parser.parse_args()

    if args.file:
        file_path = args.file
    else:
        dist_files = sorted(glob.glob("dist/*.whl"))
        if not dist_files:
            print("No .whl file found in dist/")
            sys.exit(1)
        file_path = dist_files[-1]

    ok = asyncio.run(upload(file_path, nexus_url=args.url, repository=args.repository))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
