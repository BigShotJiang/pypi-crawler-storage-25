from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional


class TokenUsage(BaseModel):
    """Token 使用记录模型"""
    user_id: str = Field(..., description="用户ID")
    input_tokens: int = Field(default=0, description="输入 token 数量")
    output_tokens: int = Field(default=0, description="输出 token 数量")
    total_tokens: int = Field(default=0, description="总 token 数量")
    model: Optional[str] = Field(default=None, description="使用的模型名称")
    trace_id: Optional[str] = Field(default=None, description="链路追踪ID")
    timestamp: datetime = Field(default_factory=datetime.now, description="插入时间")
    system: Optional[str] = Field(default=None, description="系统标识")
    tenant_id: Optional[str] = Field(default=None, description="租户ID（多租户系统）")
    service_name: Optional[str] = Field(default=None, description="服务名称")

    def to_es_document(self) -> dict:
        """转换为 ES 文档格式"""
        doc = self.model_dump()
        # 确保timestamp是ISO格式字符串
        if isinstance(doc.get('timestamp'), datetime):
            doc['timestamp'] = doc['timestamp'].isoformat()
        return doc
