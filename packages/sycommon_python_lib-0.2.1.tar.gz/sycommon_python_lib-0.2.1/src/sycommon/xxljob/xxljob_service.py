import socket
import threading
from typing import Optional

from pyxxl import ExecutorConfig, PyxxlRunner
from sycommon.logging.kafka_log import SYLogger
from sycommon.config.Config import SingletonMeta
from sycommon.config.XxlJobConfig import XxlJobConfig
from sycommon.synacos.nacos_service import NacosService
from sycommon.models.xxljob_handler_config import XxlJobHandlerConfig

logging = SYLogger


def _is_port_in_use(port: int) -> bool:
    """检查端口是否已被占用"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0


def _get_network_ip() -> str:
    """自动获取本机局域网 IP（非 127.0.0.1）"""
    try:
        # 通过 UDP 连接获取出口 IP（不会真正发包）
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(('8.8.8.8', 80))
            return s.getsockname()[0]
    except Exception:
        return '127.0.0.1'


class XxlJobService(metaclass=SingletonMeta):
    """XXL-JOB 执行器服务

    从 Nacos 共享配置中读取 xxl-job 配置，创建并管理 PyxxlRunner 实例。
    使用守护线程运行执行器，避免 macOS spawn 模式下 multiprocessing 的问题。

    多 Worker 模式下通过端口锁保证只启动一个执行器实例。

    配置格式（Nacos 共享配置中）：
        task:
          executor:
            appname: your-executor-appname
            dstc:
              address: https://your-xxl-job-admin.com
    """

    _runner: Optional[PyxxlRunner] = None
    _config: Optional[XxlJobConfig] = None
    _initialized: bool = False
    _thread: Optional[threading.Thread] = None
    _handlers: list = []

    @classmethod
    def setup(cls, config: dict, handlers: list = None) -> None:
        """从 Nacos 共享配置初始化 XXL-JOB 执行器

        在 Services.plugins() 中调用，读取配置并启动执行器守护线程。
        多 Worker 模式下只会在第一个进程中启动执行器。

        Args:
            config: Nacos 配置字典
            handlers: XxlJobHandlerConfig 列表，可通过 Services.plugins(xxljob_handlers=[...]) 传入
        """
        service_name = config.get('Name', '') if config else ''
        common = NacosService(config).share_configs.get(service_name, {})

        task_config = common.get('task', None)
        if not task_config:
            logging.warning("Nacos 共享配置中未找到 task 配置，跳过 XXL-JOB 初始化")
            return

        try:
            xxl_config = XxlJobConfig(**task_config)
            cls._config = xxl_config
            logging.info(
                f"XXL-JOB 配置加载成功: appname={xxl_config.executor.appname}, "
                f"admin={xxl_config.executor.dstc.address}"
            )
        except Exception as e:
            logging.error(f"XXL-JOB 配置解析失败: {e}", exc_info=True)
            raise

        admin_url = xxl_config.executor.dstc.address.rstrip("/")
        if not admin_url.endswith("/api"):
            admin_url += "/api"
        admin_url += "/"

        executor_port = 9999

        # 多 Worker 模式下，检查是否为 uvicorn 的 reloader 主进程
        import os
        if os.environ.get("RUN_MAIN") == "true":
            logging.info("检测到 uvicorn reloader 子进程，跳过 XXL-JOB 执行器启动")
            return

        # 多 Worker 模式下，通过端口锁保证只有一个进程启动执行器
        if _is_port_in_use(executor_port):
            logging.info(f"XXL-JOB 执行器端口 {executor_port} 已被占用，跳过启动")
            return

        network_ip = _get_network_ip()
        executor_url = f"http://{network_ip}:{executor_port}"

        executor_config = ExecutorConfig(
            xxl_admin_baseurl=admin_url,
            executor_app_name=xxl_config.executor.appname,
            executor_listen_port=executor_port,
            executor_listen_host="0.0.0.0",
            executor_url=executor_url,
        )
        cls._runner = PyxxlRunner(executor_config)

        # 注册通过 Services.plugins(xxljob_handlers=[...]) 传入的 handler
        if handlers:
            for h in handlers:
                cls._handlers.append((h.name, h.handler))

        # 统一注册所有 handler（装饰器 + 参数传入）
        for name, func in cls._handlers:
            cls._runner.register(name=name)(func)

        # 使用守护线程启动执行器，避免 macOS spawn 模式的 multiprocessing 问题
        cls._thread = threading.Thread(
            target=cls._runner.run_executor,
            kwargs={"handle_signals": False},
            name="pyxxljob",
            daemon=True,
        )
        cls._thread.start()
        cls._initialized = True
        logging.info(
            f"XXL-JOB 执行器已启动（守护线程）: appname={xxl_config.executor.appname}"
        )

    @classmethod
    def register_handler(cls, name: str):
        """装饰器：注册 XXL-JOB 任务处理器

        用法：
            @XxlJobService.register_handler(name="myJobHandler")
            async def my_task():
                return "done"

        handler 会在 setup() 启动执行器时统一注册。
        """
        def decorator(func):
            cls._handlers.append((name, func))
            # 如果 runner 已经创建（setup 已执行），立即注册
            if cls._runner is not None:
                cls._runner.register(name=name)(func)
            return func
        return decorator

    @classmethod
    def get_runner(cls) -> Optional[PyxxlRunner]:
        """获取 PyxxlRunner 实例"""
        return cls._runner

    @classmethod
    def shutdown(cls) -> None:
        """关闭 XXL-JOB 执行器"""
        if cls._runner and cls._initialized:
            try:
                logging.info("XXL-JOB 执行器正在关闭...")
                cls._runner = None
                cls._initialized = False
                cls._config = None
            except Exception as e:
                logging.error(f"关闭 XXL-JOB 执行器时发生异常: {e}", exc_info=True)


'''
async def demo_task():
    """获取参数并在控制台/调度中心打印日志"""
    from pyxxl.ctx import g

    params = g.xxl_run_data.executorParams
    g.logger.info("--- 任务开始运行 ---")
    g.logger.info(f"接收到的参数内容为: {params}")
    g.logger.info("--- 任务处理完成 ---")
    return f"任务执行成功，参数是: {params}"

app.py plugins(
    xxljob_service=[
        XxlJobHandlerConfig(name="simple_python_job", handler=demo_task),
    ],
)

保证nacos 服务名的配置下已经有
task:
  executor:
    appname: shengye-platform-digital-work
    dstc:
      address: https://task-test1.syitservice.com
'''
