"""
Agent 模块

提供数字员工和数字团队的高级封装方案，方便后续其他服务接入使用。

核心组件:
- DeepAgent: 数字员工（单 Agent）
- MultiAgentTeam: 数字团队（多 Agent 协作）
- SandboxBackend: 沙箱后端（用于代码执行）
- ChatEvent: 聊天事件（前后端交互数据结构）

使用示例:

    # 1. 简单的数字员工
    from sycommon.agent import create_deep_agent

    agent = await create_deep_agent(user_id="user123")
    async for event in agent.chat("帮我写一个 Python 脚本"):
        yield event.to_sse()  # 直接转换为 SSE 格式

    # 2. 自定义模型的数字员工
    from sycommon.agent import create_deep_agent, AgentConfig

    config = AgentConfig(
        model_name="gpt-4o",
        model_provider="openai",
        system_prompt="你是一个后端工程师...",
    )
    agent = await create_deep_agent(user_id="user123", config=config)

    # 3. 数字团队（多 Agent 协作）
    from sycommon.agent import create_multi_agent_team, TeamMember

    team = await create_multi_agent_team(
        user_id="user123",
        members=[
            TeamMember(name="后端工程师", description="负责后端开发..."),
            TeamMember(name="前端工程师", description="负责前端开发..."),
        ],
    )
    async for event in team.chat("帮我开发一个 TODO 应用"):
        yield event.to_sse()

    # 4. 使用 ChatEventBuilder 构建事件
    from sycommon.agent import ChatEventBuilder

    event = ChatEventBuilder.ai_chunk("你好")
    event = ChatEventBuilder.tool_call("execute", {"command": "ls"}, tool_call_id="call_123")

    # 5. 通过 Services.plugins 接入
    from fastapi import FastAPI
    from sycommon.services import Services

    app = Services.plugins(
        app=FastAPI(),
        deep_agent_service=True,  # 启用数字员工服务
        # 或
        multi_agent_service=True,  # 启用数字团队服务
    )
"""

from sycommon.agent.sandbox import (
    HTTPSandboxBackend,
    SandboxPool,
    SandboxInstance,
    SandboxRecoveryManager,
    areset_all_sandboxes,
    aget_sandbox_status,
)
from sycommon.agent.deep_agent import (
    AgentConfig,
    DeepAgent,
    create_deep_agent,
)
from sycommon.agent.multi_agent_team import (
    TeamMember,
    TeamConfig,
    MultiAgentTeam,
    create_multi_agent_team,
)
from sycommon.agent.agent_manager import (
    AgentManager,
    AgentInfo,
    get_agent_manager,
    create_agent,
    create_team,
    get_agent,
    destroy_agent,
)
from sycommon.agent.chat_events import (
    ChatEvent,
    ChatEventBuilder,
    EventType,
    DEFAULT_AGENT_NAME,
    is_multi_agent_mode,
    # 便捷函数
    progress_event,
    ai_chunk_event,
    tool_call_event,
    tool_result_event,
    agent_switch_event,
    parallel_agents_event,
    agent_complete_event,
    done_event,
    error_event,
    cancelled_event,
)

__all__ = [
    # 沙箱
    "HTTPSandboxBackend",
    "SandboxPool",
    "SandboxInstance",
    "SandboxRecoveryManager",
    "areset_all_sandboxes",
    "aget_sandbox_status",

    # 数字员工
    "AgentConfig",
    "DeepAgent",
    "create_deep_agent",

    # 数字团队
    "TeamMember",
    "TeamConfig",
    "MultiAgentTeam",
    "create_multi_agent_team",

    # Agent 管理
    "AgentManager",
    "AgentInfo",
    "get_agent_manager",

    # 聊天事件
    "ChatEvent",
    "ChatEventBuilder",
    "EventType",
    "DEFAULT_AGENT_NAME",
    "is_multi_agent_mode",
    "progress_event",
    "ai_chunk_event",
    "tool_call_event",
    "tool_result_event",
    "agent_switch_event",
    "parallel_agents_event",
    "agent_complete_event",
    "done_event",
    "error_event",
    "cancelled_event",
]
