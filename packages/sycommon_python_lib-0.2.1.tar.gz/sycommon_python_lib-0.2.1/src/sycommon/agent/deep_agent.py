"""
数字员工 (Deep Agent) 基础封装

提供单 Agent 的高级封装，方便后续其他服务接入使用。
支持会话管理、沙箱同步、流式响应、自动重试、取消任务等功能。

核心能力:
- 流式聊天（SSE 事件流）
- 自动重试 + 沙箱恢复
- 取消任务（cancel_event）
- 事件回调（on_event）用于 DB 持久化等扩展
- 外部 checkpointer 注入（支持 Redis）

使用示例:

    # 1. 简单使用
    from sycommon.agent import create_deep_agent, AgentConfig

    config = AgentConfig(
        system_prompt="你是后端工程师...",
        tools=[my_tool],
    )
    agent = await create_deep_agent(user_id="user123", config=config)
    async for event in agent.chat("帮我写脚本"):
        yield event.to_sse()

    # 2. 传入沙箱后端和 checkpointer
    from sycommon.agent import create_deep_agent, HTTPSandboxBackend

    agent = await create_deep_agent(
        user_id="user123",
        sandbox_backend=my_backend,
        checkpointer=my_redis_checkpointer,
    )
"""

import asyncio
import json
import os
from pathlib import Path
from typing import Any, AsyncGenerator, Callable, Awaitable, Dict, List, Optional, Tuple, TYPE_CHECKING

from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage, BaseMessage
from langchain_core.tools import BaseTool, tool

from sycommon.logging.kafka_log import SYLogger
from sycommon.llm.get_llm import get_llm
from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend
from sycommon.agent.sandbox.sandbox_recovery import SandboxRecoveryManager
from sycommon.agent.chat_events import ChatEvent, ChatEventBuilder, DEFAULT_AGENT_NAME
from sycommon.middleware.background_execution import BackgroundExecutionMiddleware
from sycommon.middleware.token_tracking import TokenTrackingMiddleware
from deepagents.middleware.summarization import create_summarization_tool_middleware

if TYPE_CHECKING:
    from deepagents.graph import CompiledStateGraph


@tool
def get_current_date() -> str:
    """获取当前日期时间"""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# 默认系统提示词
DEFAULT_SYSTEM_PROMPT = """你是智能助手，使用中文和我对话。

## 记忆系统
你可以通过 edit_file 工具更新 /memory/AGENTS.md 文件来保存重要信息。

**何时更新记忆（立即执行，在其他操作之前）：**
- 用户告诉你重要信息（如邮箱、偏好、项目代号）
- 用户纠正你的行为或给出反馈
- 你发现了有用的模式或工作流程
- 用户明确了你的角色或行为方式

**何时不要更新记忆：**
- 临时性信息（如"我正在路上"）
- 一次性任务请求
- 简单问答或闲聊
- 敏感信息（API密钥、密码等）

## 沙箱环境说明
- 沙箱环境具有外网访问权限
- 所有文件操作（下载、读取、写入、执行）都必须使用相对路径或 ./ 开头的路径
- 禁止使用 /tmp/、/var/ 等系统目录，始终使用当前工作目录 ./
- 文件组织规范：
  - ./output/ — 运行时产生的输出文件（图片、数据文件、日志等）
  - ./projects/ — 生成的代码文件或完整项目（如新建 Python 脚本、Web 项目等）
  - 写入前先创建目录，如 mkdir -p output projects
"""


class AgentConfig(BaseModel):
    """数字员工配置"""

    # 模型配置
    model_name: Optional[str] = None
    model_temperature: float = 0.7
    model_thinking: bool = False

    # 系统提示词
    system_prompt: str = DEFAULT_SYSTEM_PROMPT

    # 沙箱配置
    sandbox_service_name: str = "shengye-platform-sandbox"
    sandbox_timeout: int = 60
    skills_dir: Optional[str] = None
    memory_dir: Optional[str] = None

    # 工具
    tools: List[BaseTool] = Field(default_factory=list)

    # 调试模式
    debug: bool = False

    # 后台执行超时（秒）
    background_timeout: int = 600

    class Config:
        arbitrary_types_allowed = True


class DeepAgent:
    """数字员工封装类"""

    def __init__(
        self,
        user_id: str,
        agent: "CompiledStateGraph",
        config: Dict[str, Any],
        sandbox_backend: HTTPSandboxBackend,
        recovery_manager: Optional[SandboxRecoveryManager] = None,
    ):
        self.user_id = user_id
        self.agent = agent
        self.config = config
        self.sandbox_backend = sandbox_backend
        self.recovery_manager = recovery_manager

    async def cleanup(self):
        """清理资源：终止该用户的所有后台进程"""
        if self.sandbox_backend:
            try:
                await self.sandbox_backend.akill_all_processes()
            except Exception as e:
                SYLogger.warning(f"[DeepAgent] 清理后台进程失败: {e}")

    async def chat(
        self,
        message: str,
        cancel_event: Optional[asyncio.Event] = None,
        on_event: Optional[Callable[[ChatEvent], Awaitable[None]]] = None,
    ) -> AsyncGenerator[ChatEvent, None]:
        """流式聊天

        Args:
            message: 用户消息
            cancel_event: 取消事件（用于取消当前任务）
            on_event: 事件回调，每个事件触发后调用（可用于 DB 持久化等）

        Yields:
            ChatEvent: 聊天事件流
        """
        current_tool_calls = []
        ai_chunk_buffer = ""
        seen_tool_call_ids = set()
        stream_step = 0
        # 兜底：累积流式 chunk 中的 usage_metadata（middleware 在流式场景可能拿不到）
        total_input_tokens = 0
        total_output_tokens = 0

        try:
            async for chunk in self._astream_with_retry(
                {"messages": [HumanMessage(content=message)]},
                max_retries=3,
                base_delay=1.0,
            ):
                # 检查取消
                if cancel_event and cancel_event.is_set():
                    event = ChatEventBuilder.cancelled("任务已取消")
                    if on_event:
                        await on_event(event)
                    yield event
                    return

                # 解析 chunk（subgraphs=True 格式）
                namespace = ()
                if isinstance(chunk, tuple) and len(chunk) == 2:
                    if isinstance(chunk[1], tuple) and len(chunk[1]) == 2:
                        namespace, (msg, metadata) = chunk
                    else:
                        msg, metadata = chunk
                else:
                    continue

                stream_step += 1

                # ===== 日志（仅关键节点） =====
                if isinstance(msg, BaseMessage):
                    msg_type = msg.__class__.__name__

                    # 累积 token 统计（流式 chunk 中的 usage_metadata 兜底）
                    if msg_type in ("AIMessage", "AIMessageChunk"):
                        usage_meta = getattr(msg, "usage_metadata", None)
                        if usage_meta:
                            total_input_tokens += usage_meta.get("input_tokens", 0)
                            total_output_tokens += usage_meta.get("output_tokens", 0)

                    if msg_type == "AIMessageChunk":
                        tool_calls_log = getattr(msg, "tool_calls", [])
                        if tool_calls_log:
                            for tc_l in tool_calls_log:
                                tc_args_l = tc_l.get('args', {})
                                args_str = str(tc_args_l)[:100]
                                SYLogger.debug(
                                    f"[DeepAgent #{stream_step}] tool_call | {tc_l.get('name','?')} | args={args_str}")
                        elif not (msg.content or ""):
                            SYLogger.debug(
                                f"[DeepAgent #{stream_step}] chunk | (empty)")
                    elif msg_type == "AIMessage":
                        content_log = (msg.content or "")[:100]
                        tc_names = [tc.get('name', '?')
                                    for tc in getattr(msg, "tool_calls", [])]
                        print(
                            f"[DeepAgent] AIMessage | content={repr(content_log)} | tools={tc_names}")
                    elif msg_type == "ToolMessage":
                        content_log = (msg.content or "")
                        preview = content_log[:100]
                        print(
                            f"[DeepAgent] ToolResult | {getattr(msg, 'name', '?')} | len={len(content_log)} | preview={repr(preview)}")
                    elif msg_type == "HumanMessage":
                        content_log = (msg.content or "")[:100]
                        print(
                            f"[DeepAgent] HumanMessage | {repr(content_log)}")
                # ===== 日志结束 =====

                # 发送进度
                if metadata:
                    event = ChatEventBuilder.progress(
                        node=metadata.get("langgraph_node", ""),
                        step=metadata.get("langgraph_step", 0),
                        agent=DEFAULT_AGENT_NAME,
                    )
                    if on_event:
                        await on_event(event)
                    yield event

                if not isinstance(msg, BaseMessage):
                    continue

                msg_type = msg.__class__.__name__
                content = msg.content or ""

                if msg_type in ("AIMessage", "AIMessageChunk"):
                    # 处理 tool_call_chunks（流式分片逐步到达，args 是字符串片段）
                    tool_call_chunks = getattr(msg, "tool_call_chunks", [])
                    if tool_call_chunks:
                        for tcc in tool_call_chunks:
                            tcc_id = tcc.get("id")
                            tcc_index = tcc.get("index")
                            tcc_name = tcc.get("name")
                            tcc_args_str = tcc.get("args")

                            # 用 (id 或 index) 匹配已记录的 tool_call
                            if tcc_id:
                                existing_tc = next(
                                    (tc for tc in current_tool_calls if tc.get("id") == tcc_id), None
                                )
                            elif tcc_index is not None:
                                existing_tc = next(
                                    (tc for tc in current_tool_calls if tc.get("_index") == tcc_index), None
                                )
                            else:
                                existing_tc = None

                            if existing_tc:
                                # 追加 args 字符串片段
                                if tcc_args_str:
                                    existing_tc["_args_buffer"] += tcc_args_str
                                if tcc_name:
                                    existing_tc["name"] = tcc_name
                            else:
                                # 新 tool_call，可能只有部分信息
                                new_tc = {
                                    "id": tcc_id or "",
                                    "name": tcc_name or "unknown",
                                    "args": {},
                                    "_args_buffer": tcc_args_str or "",
                                    "_index": tcc_index,
                                }
                                current_tool_calls.append(new_tc)
                                existing_tc = new_tc

                            # 尝试解析累积的 args 字符串
                            buf = existing_tc["_args_buffer"]
                            args_parsed = False
                            if buf:
                                try:
                                    parsed = json.loads(buf)
                                    existing_tc["args"] = parsed
                                    args_parsed = True
                                except json.JSONDecodeError:
                                    pass  # 还没接收完整，下次继续

                            # 发送 tool_call 事件，前端根据 tool_call_id 更新
                            tc_id = existing_tc["id"]
                            if tc_id:
                                current_args = existing_tc["args"]
                                # 只有以下情况才发送：
                                # 1. 首次出现（args 为空，先发一个占位）
                                # 2. args 解析成功（有实质更新）
                                is_first = not existing_tc.get("_sent")
                                if is_first or args_parsed:
                                    event = ChatEventBuilder.tool_call(
                                        name=existing_tc["name"],
                                        args=current_args,
                                        tool_call_id=tc_id,
                                        id=getattr(msg, "id", None),
                                        agent=DEFAULT_AGENT_NAME,
                                    )
                                    existing_tc["_sent"] = True
                                    if on_event:
                                        await on_event(event)
                                    yield event
                    else:
                        # 无 tool_call_chunks，走 tool_calls（非流式场景或最终完整消息）
                        tool_calls = getattr(msg, "tool_calls", [])
                        if tool_calls:
                            for tc in tool_calls:
                                tc_id = tc.get("id", "")
                                if not tc_id:
                                    continue

                                tc_name = tc.get("name", "unknown")
                                tc_args = tc.get("args", {})

                                # 查找是否已有该 tool_call
                                existing_tc = None
                                for etc in current_tool_calls:
                                    if etc.get("id") == tc_id:
                                        existing_tc = etc
                                        break

                                if existing_tc:
                                    # 非空 args 覆盖（完整解析后的结果）
                                    if tc_args and tc_args != {}:
                                        existing_tc["args"] = tc_args
                                        existing_tc["_args_buffer"] = json.dumps(tc_args, ensure_ascii=False)
                                else:
                                    current_tool_calls.append({
                                        "id": tc_id, "name": tc_name, "args": tc_args,
                                        "_args_buffer": json.dumps(tc_args, ensure_ascii=False) if tc_args else "",
                                        "_index": None,
                                    })
                                    existing_tc = current_tool_calls[-1]

                                # 发送 tool_call 事件
                                event = ChatEventBuilder.tool_call(
                                    name=existing_tc["name"],
                                    args=existing_tc["args"],
                                    tool_call_id=tc_id,
                                    id=getattr(msg, "id", None),
                                    agent=DEFAULT_AGENT_NAME,
                                )
                                if on_event:
                                    await on_event(event)
                                yield event

                    if content:
                        ai_chunk_buffer += content
                        event = ChatEventBuilder.ai_chunk(
                            content, id=getattr(msg, "id", None),
                            agent=DEFAULT_AGENT_NAME)
                        if on_event:
                            await on_event(event)
                        yield event

                elif msg_type == "ToolMessage":
                    if ai_chunk_buffer:
                        print(
                            f"[DeepAgent] AI chunk done | {repr(ai_chunk_buffer[:100])}...")
                        ai_chunk_buffer = ""

                    tool_name = getattr(msg, "name", None)
                    tool_call_id = getattr(msg, "tool_call_id", "")

                    tool_args = {}
                    for tc in current_tool_calls:
                        if tc.get("id") == tool_call_id:
                            if not tool_name:
                                tool_name = tc.get("name", "unknown")
                            tool_args = tc.get("args", {})
                            break

                    # 优先使用 langchain ToolMessage.status，回退到内容判断
                    msg_status = getattr(msg, "status", None)
                    if msg_status is not None:
                        is_success = msg_status == "success"
                    else:
                        is_success = (
                            "Exit code: 0" in content
                            or (not content.startswith("[stderr]")
                                and "Error:" not in content
                                and "exit code" not in content.lower())
                        )

                    event = ChatEventBuilder.tool_result(
                        tool_call_id=tool_call_id, name=tool_name or "unknown",
                        content=content, args=tool_args, success=is_success,
                        id=getattr(msg, "id", None),
                        agent=DEFAULT_AGENT_NAME,
                    )
                    if on_event:
                        await on_event(event)
                    yield event

                elif msg_type == "HumanMessage":
                    if ai_chunk_buffer:
                        print(
                            f"[DeepAgent] AI chunk done | {repr(ai_chunk_buffer[:100])}...")
                        ai_chunk_buffer = ""

            if ai_chunk_buffer:
                print(
                    f"[DeepAgent] AI chunk done | {repr(ai_chunk_buffer[:100])}...")

            # 兜底：如果 middleware 没有成功记录（流式场景），在这里补充记录
            if total_input_tokens > 0 or total_output_tokens > 0:
                try:
                    from sycommon.llm.token_usage_mysql_service import TokenUsageMySQLService
                    await TokenUsageMySQLService.record(
                        user_id=self.user_id,
                        input_tokens=total_input_tokens,
                        output_tokens=total_output_tokens,
                        model=None,  # model 已通过 middleware 记录
                    )
                    SYLogger.info(
                        f"[DeepAgent] Token 兜底统计: input={total_input_tokens}, output={total_output_tokens}")
                except Exception as te:
                    SYLogger.warning(f"[DeepAgent] Token 兜底统计失败: {te}")

            event = ChatEventBuilder.done()
            if on_event:
                await on_event(event)
            yield event

        except asyncio.CancelledError:
            event = ChatEventBuilder.cancelled("任务已取消")
            if on_event:
                await on_event(event)
            yield event
            raise
        except Exception as e:
            SYLogger.error(f"[DeepAgent] 聊天异常: {e}")
            event = ChatEventBuilder.error(str(e))
            if on_event:
                await on_event(event)
            yield event
            event = ChatEventBuilder.done()
            if on_event:
                await on_event(event)
            yield event

    # ============== 内部方法 ==============

    def _parse_chunk(self, chunk) -> Tuple[Optional[BaseMessage], Optional[Dict]]:
        """解析流式响应的 chunk"""
        if isinstance(chunk, tuple) and len(chunk) == 2:
            if isinstance(chunk[1], tuple) and len(chunk[1]) == 2:
                _, (msg, metadata) = chunk
            else:
                msg, metadata = chunk
            return msg, metadata
        return None, None

    async def _astream_with_retry(
        self,
        input_data: Dict,
        max_retries: int = 3,
        base_delay: float = 1.0,
    ) -> AsyncGenerator:
        """带重试机制的 astream"""
        import httpx
        from openai import APIConnectionError, APIError, APITimeoutError

        last_error = None

        while True:
            for attempt in range(max_retries):
                try:
                    async for chunk in self.agent.astream(
                        input_data,
                        config=self.config,
                        stream_mode="messages",
                        subgraphs=True
                    ):
                        yield chunk
                    return
                except (APIConnectionError, APIError, APITimeoutError, ConnectionError, httpx.RemoteProtocolError) as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt)
                        SYLogger.warning(
                            f"[DeepAgent] 连接错误: {e}, {delay}秒后重试...")
                        await asyncio.sleep(delay)
                    else:
                        raise last_error
                except RuntimeError as e:
                    if "沙箱服务不可用" in str(e) and self.recovery_manager:
                        SYLogger.warning("[DeepAgent] 沙箱服务不可用，尝试恢复...")
                        recovered = await self.recovery_manager.recover()
                        if recovered:
                            SYLogger.info("[DeepAgent] 沙箱已恢复，继续执行")
                            break
                        raise
                    raise
            else:
                break


async def create_deep_agent(
    user_id: str,
    config: Optional[AgentConfig] = None,
    sandbox_backend: Optional[HTTPSandboxBackend] = None,
    checkpointer=None,
    project_root: Optional[Path] = None,
    thread_id: Optional[str] = None,
) -> DeepAgent:
    """创建数字员工实例

    Args:
        user_id: 用户 ID
        config: Agent 配置（可选）
        sandbox_backend: 沙箱后端（可选，不传则自动创建）
        checkpointer: 检查点存储（可选，不传则使用 MemorySaver）
        project_root: 项目根目录（用于确定默认的 skills/memory 目录）
        thread_id: 线程 ID（可选，默认使用 user_id）

    Returns:
        DeepAgent: 数字员工实例
    """
    if config is None:
        config = AgentConfig()

    if project_root is None:
        project_root = Path.cwd()

    # 创建沙箱后端
    if sandbox_backend is None:
        sandbox_backend = await _create_sandbox_backend(user_id, config, project_root)

    # 创建模型
    model = get_llm(
        model=config.model_name,
        streaming=True,
        temperature=config.model_temperature,
        thinking=config.model_thinking,
        wrap_structured=False,
    )

    # 创建 checkpointer
    if checkpointer is None:
        from langgraph.checkpoint.memory import MemorySaver
        checkpointer = MemorySaver()

    tid = thread_id or user_id
    agent_config = {"configurable": {"thread_id": tid}}

    # 确定沙箱路径
    # skills_dir: 本地目录路径 → 同步到沙箱 /skills（仅上传沙箱中不存在的技能目录）
    # memory_dir: 非路径字符串 → 标记启用沙箱 /memory/AGENTS.md
    skills_path = "/skills" if config.skills_dir else None
    memory_path = "/memory/AGENTS.md" if config.memory_dir else None

    # 同步 skills 到沙箱（按目录名检查，已存在则跳过）
    if config.skills_dir and sandbox_backend:
        await _sync_skills_to_sandbox(config.skills_dir, sandbox_backend)

    # 创建 agent
    from deepagents import create_deep_agent as _create_deep_agent

    agent_kwargs = {
        "model": model,
        "tools": config.tools or [get_current_date],
        "backend": sandbox_backend,
        "checkpointer": checkpointer,
        "system_prompt": config.system_prompt,
        "debug": config.debug,
        "middleware": [
            BackgroundExecutionMiddleware(backend=sandbox_backend),
            TokenTrackingMiddleware(model_name=config.model_name, user_id=user_id),
            create_summarization_tool_middleware(model, sandbox_backend),
        ],
    }
    if skills_path:
        agent_kwargs["skills"] = [skills_path]
    if memory_path:
        agent_kwargs["memory"] = [memory_path]

    agent = _create_deep_agent(**agent_kwargs)

    recovery_manager = SandboxRecoveryManager(sandbox_backend)

    return DeepAgent(
        user_id=user_id,
        agent=agent,
        config=agent_config,
        sandbox_backend=sandbox_backend,
        recovery_manager=recovery_manager,
    )


async def _sync_skills_to_sandbox(
    skills_dir: str,
    backend: HTTPSandboxBackend,
) -> None:
    """同步 skills 到沙箱（按目录名检查，已存在则跳过，不覆盖用户文件）"""
    if not os.path.isdir(skills_dir):
        return

    try:
        # 获取沙箱 /skills 下已有的目录列表
        existing_dirs = set()
        tree_result = await backend.atree("/skills", max_depth=1)
        if tree_result and tree_result.tree and tree_result.tree.children:
            for child in tree_result.tree.children:
                if child.is_dir:
                    existing_dirs.add(child.name)

        # 只上传沙箱中不存在的技能
        for skill_name in os.listdir(skills_dir):
            src = os.path.join(skills_dir, skill_name)
            if not os.path.isdir(src):
                continue
            if skill_name in existing_dirs:
                SYLogger.debug(f"[DeepAgent] 技能已存在，跳过: {skill_name}")
                continue
            await backend.async_sync_dirs([(src, f"/skills/{skill_name}")])
            SYLogger.info(f"[DeepAgent] 同步技能到沙箱: {skill_name}")
    except Exception as e:
        SYLogger.warning(f"[DeepAgent] 技能同步失败: {e}")


async def _create_sandbox_backend(
    user_id: str,
    config: AgentConfig,
    project_root: Path,
) -> HTTPSandboxBackend:
    """创建并同步沙箱后端"""
    sync_dirs = []

    if config.skills_dir:
        skills_dir = Path(config.skills_dir)
    else:
        skills_dir = project_root / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    sync_dirs.append((str(skills_dir), "/skills"))

    if config.memory_dir:
        memory_dir = Path(config.memory_dir)
    else:
        memory_dir = project_root / "history"
    memory_dir.mkdir(parents=True, exist_ok=True)
    sync_dirs.append((str(memory_dir), "/memory"))

    sandbox_backend = HTTPSandboxBackend.from_nacos(
        service_name=config.sandbox_service_name,
        user_id=user_id,
        timeout=config.sandbox_timeout,
        sync_dirs=sync_dirs,
        auto_sync=True,
    )

    try:
        sync_result = await asyncio.wait_for(sandbox_backend.async_sync(), timeout=3600)
        total_success = sum(r.get("success", 0) for r in sync_result.values())
        total_failed = sum(r.get("failed", 0) for r in sync_result.values())
        SYLogger.info(
            f"[DeepAgent] 沙箱同步完成: 成功 {total_success}, 失败 {total_failed}")
    except asyncio.TimeoutError:
        SYLogger.warning("[DeepAgent] 沙箱同步超时，继续执行")
    except Exception as e:
        SYLogger.error(f"[DeepAgent] 沙箱同步失败: {e}")

    return sandbox_backend
