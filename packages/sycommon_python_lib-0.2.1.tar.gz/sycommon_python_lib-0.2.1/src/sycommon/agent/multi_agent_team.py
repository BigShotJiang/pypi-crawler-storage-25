"""
数字团队 (Multi-Agent Team) 基础封装

提供多 Agent 协作的高级封装，方便后续其他服务接入使用。
支持团队成员管理、任务委派、并行执行、流式响应等功能。

核心能力:
- 多 Agent 协作流式聊天
- Agent 切换检测（namespace / metadata）
- 并行任务委派追踪
- 取消任务（cancel_event）
- 事件回调（on_event）用于 DB 持久化等扩展
- 外部 checkpointer 注入（支持 Redis）

使用示例:

    from sycommon.agent import create_multi_agent_team, TeamMember, TeamConfig

    team = await create_multi_agent_team(
        user_id="user123",
        members=[
            TeamMember(name="后端工程师", description="负责后端开发..."),
            TeamMember(name="前端工程师", description="负责前端开发..."),
        ],
        checkpointer=my_redis_checkpointer,
    )
    async for event in team.chat("帮我开发一个 TODO 应用"):
        yield event.to_sse()
"""

import asyncio
from pathlib import Path
from typing import Any, AsyncGenerator, Callable, Awaitable, Dict, List, Optional, Tuple, TYPE_CHECKING

from pydantic import BaseModel, Field, field_validator
from langchain_core.messages import HumanMessage, BaseMessage
from langchain_core.tools import BaseTool, tool

from sycommon.logging.kafka_log import SYLogger
from sycommon.llm.get_llm import get_llm
from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend
from sycommon.tools.env import get_env_var
from sycommon.agent.sandbox.sandbox_recovery import SandboxRecoveryManager
from sycommon.agent.chat_events import ChatEvent, ChatEventBuilder, DEFAULT_AGENT_NAME
from sycommon.middleware.background_execution import BackgroundExecutionMiddleware
from sycommon.middleware.token_tracking import TokenTrackingMiddleware
from deepagents.middleware.summarization import create_summarization_tool_middleware

if TYPE_CHECKING:
    from deepagents.graph import CompiledStateGraph


@tool
def get_current_date() -> str:
    """获取当前日期时间"""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# 默认记忆系统提示词（所有角色共享）
MEMORY_PROMPT = """
## 记忆系统
你可以通过 edit_file 工具更新 /memory/AGENTS.md 文件来保存重要信息。

**何时更新记忆（立即执行，在其他操作之前）：**
- 用户告诉你重要信息（如邮箱、偏好、项目代号）
- 用户纠正你的行为或给出反馈
- 你发现了有用的模式或工作流程
- 用户明确了你的角色或行为方式

**何时不要更新记忆：**
- 临时性信息（如"我正在路上"）
- 一次性任务请求
- 简单问答或闲聊
- 敏感信息（API密钥、密码等）
"""


class TeamMember(BaseModel):
    """团队成员配置"""
    name: str
    description: str
    system_prompt: str = ""
    tools: List[BaseTool] = Field(default_factory=list)
    children: List["TeamMember"] = Field(default_factory=list)

    @field_validator('system_prompt', mode='before')
    @classmethod
    def set_default_prompt(cls, v: str, info) -> str:
        if not v:
            return cls._generate_default_prompt(
                info.data.get('name', ''),
                info.data.get('description', '')
            )
        return v

    @staticmethod
    def _generate_default_prompt(name: str, description: str) -> str:
        return f"""你是{name}。

{MEMORY_PROMPT}

## 职责
{description}

## 工作方式
- 认真完成分配给你的任务
- 与团队成员保持良好协作
- 用中文回答问题

## 重要约束 - 沙箱执行环境

### 后台执行工具

沙箱提供了专门的后台执行工具，用于管理长时间运行的服务：

- **execute_background(command, timeout=600)**: 在后台启动命令（不阻塞），返回 process_id
- **check_process(process_id)**: 检查后台进程的状态
- **kill_process(process_id)**: 终止后台进程

### 启动和测试服务的正确方式

当需要启动长时间运行的服务（如 FastAPI、数据库）时：

```python
# 1. 后台启动服务
result = execute_background(command="uvicorn main:app --host 0.0.0.0 --port 8000")
process_id = result["process_id"]

# 2. 等待服务启动
execute(command="sleep 3")

# 3. 测试服务
execute(command="curl http://localhost:8000/health")

# 4. 完成后终止服务（重要！）
kill_process(process_id=process_id)
```

### 关键规则

1. **启动服务必须使用 execute_background** - 使用 execute 启动服务会超时
2. **记住 process_id** - 每次启动服务都会返回新的 process_id，需要保存用于后续操作
3. **测试完成后必须 kill_process** - 避免资源浪费
4. **使用 check_process 检查状态** - 可以查看服务是否还在运行
"""

    class Config:
        arbitrary_types_allowed = True


# 处理 TeamMember 的前向引用（children: List["TeamMember"]）
TeamMember.model_rebuild()


class TeamConfig(BaseModel):
    """数字团队配置"""

    model_name: Optional[str] = None
    model_temperature: float = 0.7
    model_thinking: bool = False

    coordinator_prompt: str = ""
    coordinator_name: str = "项目经理"

    sandbox_service_name: str = "shengye-platform-sandbox"
    sandbox_timeout: int = 60
    skills_dir: Optional[str] = None
    memory_dir: Optional[str] = None

    shared_tools: List[BaseTool] = Field(default_factory=list)

    debug: bool = False
    background_timeout: int = 600

    @field_validator('coordinator_prompt', mode='before')
    @classmethod
    def set_default_coordinator_prompt(cls, v: str) -> str:
        if not v:
            return cls._generate_default_coordinator_prompt()
        return v

    @staticmethod
    def _generate_default_coordinator_prompt() -> str:
        return f"""你是虚拟团队的项目经理，负责协调团队成员完成用户任务。

{MEMORY_PROMPT}

## 工作方式
- 根据用户任务类型，委派给合适的团队成员
- 可以同时委派多个成员协作处理复杂任务
- 综合各成员的输出，给用户一个完整的回复
- 如果任务涉及多个领域，协调不同成员的贡献
- 沙箱环境具有外网访问权限
- 所有文件操作（下载、读取、写入、执行）都必须使用相对路径或 ./ 开头的路径
- 禁止使用 /tmp/、/var/ 等系统目录，始终使用当前工作目录 ./

## 委派原则
- 复杂任务 → 多角色协作
"""

    class Config:
        arbitrary_types_allowed = True


class MultiAgentTeam:
    """数字团队封装类"""

    def __init__(
        self,
        user_id: str,
        agent: "CompiledStateGraph",
        config: Dict[str, Any],
        members: List[TeamMember],
        sandbox_backend: HTTPSandboxBackend,
        coordinator_name: str = "项目经理",
        recovery_manager: Optional[SandboxRecoveryManager] = None,
    ):
        self.user_id = user_id
        self.agent = agent
        self.config = config
        self.members = members
        self.member_names = [m.name for m in members]
        self.coordinator_name = coordinator_name
        self.sandbox_backend = sandbox_backend
        self.recovery_manager = recovery_manager

    async def cleanup(self):
        """清理资源：终止该用户的所有后台进程"""
        if self.sandbox_backend:
            try:
                await self.sandbox_backend.akill_all_processes()
            except Exception as e:
                SYLogger.warning(f"[MultiAgentTeam] 清理后台进程失败: {e}")

    async def chat(
        self,
        message: str,
        cancel_event: Optional[asyncio.Event] = None,
        on_event: Optional[Callable[[ChatEvent], Awaitable[None]]] = None,
    ) -> AsyncGenerator[ChatEvent, None]:
        """流式聊天

        Args:
            message: 用户消息
            cancel_event: 取消事件
            on_event: 事件回调

        Yields:
            ChatEvent: 聊天事件流
        """
        current_tool_calls = []
        task_agent_map = {}       # task_id -> agent 映射
        parent_agent_map = {}     # task_id -> 父 agent 映射
        ai_chunk_buffer = ""
        current_agent = self.coordinator_name
        seen_tool_call_ids = set()  # 去重：流式分片中同一 tool_call 多次到达

        try:
            async for chunk in self._astream_with_retry(
                {"messages": [HumanMessage(content=message)]},
                max_retries=3,
                base_delay=1.0,
            ):
                # 检查取消
                if cancel_event and cancel_event.is_set():
                    event = ChatEventBuilder.cancelled("任务已取消")
                    if on_event:
                        await on_event(event)
                    yield event
                    return

                # 解析 chunk（带 namespace）
                namespace, msg, metadata = self._parse_chunk_with_namespace(chunk)
                if msg is None:
                    continue

                # 检测 agent 切换
                subagent_name = self._detect_agent_change(namespace, metadata, current_agent)
                if subagent_name and subagent_name != current_agent:
                    current_agent = subagent_name
                    event = ChatEventBuilder.agent_switch(
                        agent=current_agent,
                        namespace=list(namespace) if namespace else None,
                    )
                    if on_event:
                        await on_event(event)
                    yield event

                # 发送进度
                if metadata:
                    event = ChatEventBuilder.progress(
                        node=metadata.get("langgraph_node", ""),
                        step=metadata.get("langgraph_step", 0),
                        agent=current_agent,
                    )
                    if on_event:
                        await on_event(event)
                    yield event

                if not isinstance(msg, BaseMessage):
                    continue

                msg_type = msg.__class__.__name__
                content = msg.content or ""

                if msg_type in ("AIMessage", "AIMessageChunk"):
                    tool_calls = getattr(msg, "tool_calls", [])

                    if tool_calls:
                        # 检测并行任务
                        parallel_agents = [
                            tc.get("args", {}).get("subagent_type")
                            for tc in tool_calls
                            if tc.get("name") == "task" and tc.get("args", {}).get("subagent_type")
                        ]

                        if len(parallel_agents) > 1:
                            event = ChatEventBuilder.parallel_agents(parallel_agents)
                            if on_event:
                                await on_event(event)
                            yield event

                        for tc in tool_calls:
                            tc_name = tc.get("name", "unknown")
                            tc_args = tc.get("args", {})
                            tc_id = tc.get("id", "")
                            tc_agent = current_agent

                            # 流式分片中同一 tool_call 可能多次到达，去重
                            if not tc_id or tc_id in seen_tool_call_ids:
                                continue
                            seen_tool_call_ids.add(tc_id)

                            if tc_name == "task" and "subagent_type" in tc_args:
                                subagent_type = tc_args["subagent_type"]
                                task_agent_map[tc_id] = subagent_type
                                parent_agent_map[tc_id] = current_agent
                                tc_agent = subagent_type

                                if len(parallel_agents) <= 1:
                                    current_agent = subagent_type
                                    event = ChatEventBuilder.agent_switch(
                                        agent=current_agent, task_id=tc_id,
                                    )
                                    if on_event:
                                        await on_event(event)
                                    yield event

                            event = ChatEventBuilder.tool_call(
                                name=tc_name, args=tc_args, tool_call_id=tc_id, agent=tc_agent,
                                id=getattr(msg, "id", None),
                            )
                            if on_event:
                                await on_event(event)
                            yield event
                            current_tool_calls.append({
                                "id": tc_id, "name": tc_name,
                                "args": tc_args, "agent": tc_agent,
                            })

                    if content:
                        ai_chunk_buffer += content
                        event = ChatEventBuilder.ai_chunk(content, id=getattr(msg, "id", None), agent=current_agent)
                        if on_event:
                            await on_event(event)
                        yield event

                elif msg_type == "ToolMessage":
                    if ai_chunk_buffer:
                        SYLogger.debug(f"[ai_message] {repr(ai_chunk_buffer[:100])}...")
                        ai_chunk_buffer = ""

                    tool_name = getattr(msg, "name", None)
                    tool_call_id = getattr(msg, "tool_call_id", "")

                    # 查找对应的 agent
                    result_agent = current_agent
                    for tc in current_tool_calls:
                        if tc.get("id") == tool_call_id:
                            result_agent = tc.get("agent", current_agent)
                            break

                    # 查找工具参数
                    tool_args = {}
                    for tc in current_tool_calls:
                        if tc.get("id") == tool_call_id:
                            if not tool_name:
                                tool_name = tc.get("name", "unknown")
                            tool_args = tc.get("args", {})
                            break

                    # 优先使用 langchain ToolMessage.status，回退到内容判断
                    msg_status = getattr(msg, "status", None)
                    if msg_status is not None:
                        is_success = msg_status == "success"
                    else:
                        is_success = "Exit code: 0" in content or (
                            not content.startswith("[stderr]") and "Error:" not in content
                        )

                    event = ChatEventBuilder.tool_result(
                        tool_call_id=tool_call_id, name=tool_name or "unknown",
                        content=content, args=tool_args, success=is_success,
                        agent=result_agent,
                        id=getattr(msg, "id", None),
                    )
                    if on_event:
                        await on_event(event)
                    yield event

                    # task 工具返回 → 子 Agent 任务完成
                    if tool_name == "task":
                        completed_agent = task_agent_map.get(tool_call_id, result_agent)
                        parent_agent = parent_agent_map.get(tool_call_id)
                        event = ChatEventBuilder.agent_complete(
                            agent=completed_agent, task_id=tool_call_id,
                            parent_agent=parent_agent,
                        )
                        if on_event:
                            await on_event(event)
                        yield event
                        task_agent_map.pop(tool_call_id, None)
                        parent_agent_map.pop(tool_call_id, None)

                elif msg_type == "HumanMessage":
                    if ai_chunk_buffer:
                        SYLogger.debug(f"[ai_message] {repr(ai_chunk_buffer[:100])}...")
                        ai_chunk_buffer = ""

            if ai_chunk_buffer:
                SYLogger.debug(f"[ai_message] {repr(ai_chunk_buffer[:100])}...")

            event = ChatEventBuilder.done()
            if on_event:
                await on_event(event)
            yield event

        except asyncio.CancelledError:
            event = ChatEventBuilder.cancelled("任务已取消")
            if on_event:
                await on_event(event)
            yield event
            raise
        except Exception as e:
            SYLogger.error(f"[MultiAgentTeam] 聊天异常: {e}")
            event = ChatEventBuilder.error(str(e))
            if on_event:
                await on_event(event)
            yield event
            event = ChatEventBuilder.done()
            if on_event:
                await on_event(event)
            yield event

    # ============== 内部方法 ==============

    def _parse_chunk_with_namespace(self, chunk) -> Tuple[tuple, Optional[BaseMessage], Optional[Dict]]:
        """解析 chunk（带 namespace）"""
        namespace = ()
        if isinstance(chunk, tuple) and len(chunk) == 2:
            if isinstance(chunk[1], tuple) and len(chunk[1]) == 2:
                namespace, (msg, metadata) = chunk
                return namespace, msg, metadata
            else:
                msg, metadata = chunk
                return namespace, msg, metadata
        return namespace, None, None

    def _detect_agent_change(
        self,
        namespace: tuple,
        metadata: Optional[Dict],
        current_agent: str,
    ) -> Optional[str]:
        """检测 agent 切换"""
        if metadata and "lc_agent_name" in metadata:
            return metadata["lc_agent_name"]
        if namespace and len(namespace) >= 2:
            return namespace[-1]
        return None

    async def _astream_with_retry(
        self,
        input_data: Dict,
        max_retries: int = 3,
        base_delay: float = 1.0,
    ) -> AsyncGenerator:
        """带重试机制的 astream"""
        import httpx
        from openai import APIConnectionError, APIError, APITimeoutError

        last_error = None

        while True:
            for attempt in range(max_retries):
                try:
                    async for chunk in self.agent.astream(
                        input_data,
                        config=self.config,
                        stream_mode="messages",
                        subgraphs=True
                    ):
                        yield chunk
                    return
                except (APIConnectionError, APIError, APITimeoutError, ConnectionError, httpx.RemoteProtocolError) as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt)
                        SYLogger.warning(f"[MultiAgentTeam] 连接错误: {e}, {delay}秒后重试...")
                        await asyncio.sleep(delay)
                    else:
                        raise last_error
                except RuntimeError as e:
                    if "沙箱服务不可用" in str(e) and self.recovery_manager:
                        SYLogger.warning("[MultiAgentTeam] 沙箱服务不可用，尝试恢复...")
                        recovered = await self.recovery_manager.recover()
                        if recovered:
                            SYLogger.info("[MultiAgentTeam] 沙箱已恢复，继续执行")
                            break
                        raise
                    raise
            else:
                break


async def create_multi_agent_team(
    user_id: str,
    members: List[TeamMember],
    config: Optional[TeamConfig] = None,
    sandbox_backend: Optional[HTTPSandboxBackend] = None,
    checkpointer=None,
    project_root: Optional[Path] = None,
    thread_id: Optional[str] = None,
) -> MultiAgentTeam:
    """创建数字团队实例

    Args:
        user_id: 用户 ID
        members: 团队成员列表
        config: 团队配置（可选）
        sandbox_backend: 沙箱后端（可选）
        checkpointer: 检查点存储（可选，不传则使用 MemorySaver）
        project_root: 项目根目录
        thread_id: 线程 ID（可选，默认使用 user_id）

    Returns:
        MultiAgentTeam: 数字团队实例
    """
    if config is None:
        config = TeamConfig()

    if not members:
        raise ValueError("团队成员不能为空")

    if project_root is None:
        project_root = Path.cwd()

    # 创建沙箱后端
    if sandbox_backend is None:
        sandbox_backend = await _create_sandbox_backend_for_team(user_id, config, project_root)

    # 创建模型
    model = get_llm(
        model=config.model_name,
        streaming=True,
        temperature=config.model_temperature,
        thinking=config.model_thinking,
        wrap_structured=False,
    )

    # 创建 checkpointer
    if checkpointer is None:
        from langgraph.checkpoint.memory import MemorySaver
        checkpointer = MemorySaver()

    tid = thread_id or user_id
    agent_config = {"configurable": {"thread_id": tid}}

    # 创建子 agents（递归支持嵌套团队）
    from deepagents import create_deep_agent
    from deepagents.middleware.subagents import CompiledSubAgent

    middleware = [
        BackgroundExecutionMiddleware(backend=sandbox_backend),
        TokenTrackingMiddleware(model_name=config.model_name, user_id=user_id),
        create_summarization_tool_middleware(model, sandbox_backend),
    ]
    shared = config.shared_tools or [get_current_date]

    def _build_subagent(member: TeamMember) -> CompiledSubAgent:
        """递归构建子 Agent（支持无限嵌套）"""
        member_tools = member.tools or shared
        if member.children:
            # 有子团队 → 递归创建子 subagents
            child_subagents = [_build_subagent(child) for child in member.children]
            member_agent = create_deep_agent(
                model=model,
                tools=member_tools,
                backend=sandbox_backend,
                memory=["/memory/AGENTS.md"],
                system_prompt=member.system_prompt,
                name=member.name,
                subagents=child_subagents,
                middleware=middleware,
            )
        else:
            # 叶子节点 → 普通 Agent
            member_agent = create_deep_agent(
                model=model,
                tools=member_tools,
                backend=sandbox_backend,
                memory=["/memory/AGENTS.md"],
                system_prompt=member.system_prompt,
                name=member.name,
                middleware=middleware,
            )
        return CompiledSubAgent(
            name=member.name,
            description=member.description,
            runnable=member_agent,
        )

    subagents = [_build_subagent(member) for member in members]

    # 创建协调者 Agent
    coord_name = config.coordinator_name
    coordinator_agent = create_deep_agent(
        model=model,
        tools=config.shared_tools or [get_current_date],
        backend=sandbox_backend,
        skills=["/skills"],
        memory=["/memory/AGENTS.md"],
        checkpointer=checkpointer,
        system_prompt=config.coordinator_prompt,
        subagents=subagents,
        debug=config.debug,
        name=coord_name,
        middleware=[
            BackgroundExecutionMiddleware(backend=sandbox_backend),
            TokenTrackingMiddleware(model_name=config.model_name, user_id=user_id),
            create_summarization_tool_middleware(model, sandbox_backend),
        ],
    )

    recovery_manager = SandboxRecoveryManager(sandbox_backend)

    return MultiAgentTeam(
        user_id=user_id,
        agent=coordinator_agent,
        config=agent_config,
        members=members,
        sandbox_backend=sandbox_backend,
        coordinator_name=coord_name,
        recovery_manager=recovery_manager,
    )


async def _create_sandbox_backend_for_team(
    user_id: str,
    config: TeamConfig,
    project_root: Path,
) -> HTTPSandboxBackend:
    """创建并同步沙箱后端（团队版本）"""
    sync_dirs = []

    if config.skills_dir:
        skills_dir = Path(config.skills_dir)
    else:
        skills_dir = project_root / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    sync_dirs.append((str(skills_dir), "/skills"))

    if config.memory_dir:
        memory_dir = Path(config.memory_dir)
    else:
        memory_dir = project_root / "history"
    memory_dir.mkdir(parents=True, exist_ok=True)
    sync_dirs.append((str(memory_dir), "/memory"))

    sandbox_backend = HTTPSandboxBackend.from_nacos(
        service_name=config.sandbox_service_name,
        user_id=user_id,
        timeout=config.sandbox_timeout,
        sync_dirs=sync_dirs,
        auto_sync=True,
        version=get_env_var('VERSION') or None,
    )

    # 健康检查
    try:
        is_available = await asyncio.wait_for(
            asyncio.to_thread(sandbox_backend.check_available, 5),
            timeout=10
        )
        if not is_available:
            raise RuntimeError("沙箱服务健康检查失败")
    except asyncio.TimeoutError:
        raise RuntimeError("沙箱服务不可用：健康检查超时")

    # 同步目录
    try:
        sync_result = await asyncio.wait_for(sandbox_backend.async_sync(), timeout=3600)
        total_success = sum(r.get("success", 0) for r in sync_result.values())
        total_failed = sum(r.get("failed", 0) for r in sync_result.values())
        SYLogger.info(f"[MultiAgentTeam] 沙箱同步完成: 成功 {total_success}, 失败 {total_failed}")
    except asyncio.TimeoutError:
        SYLogger.warning("[MultiAgentTeam] 沙箱同步超时，继续执行")
    except Exception as e:
        SYLogger.error(f"[MultiAgentTeam] 沙箱同步失败: {e}")

    return sandbox_backend
