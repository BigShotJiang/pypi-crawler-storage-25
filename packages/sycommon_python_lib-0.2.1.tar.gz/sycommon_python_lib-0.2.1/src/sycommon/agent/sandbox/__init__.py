"""
沙箱模块

提供远程沙箱容器的连接和管理能力，支持通过 Nacos 服务发现。

架构说明:
┌─────────────────────────────────────────────────────────────┐
│                      调用服务                                │
│                                                             │
│  HTTPSandboxBackend.from_nacos("sandbox-service")          │
│                           │                                 │
│                           ▼                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │                    Nacos                             │   │
│  │  负责服务发现 + 负载均衡                              │   │
│  │                                                     │   │
│  │  sandbox-service:                                   │   │
│  │    - 192.168.1.100:8080 (实例1)                     │   │
│  │    - 192.168.1.101:8080 (实例2)                     │   │
│  │    - 192.168.1.102:8080 (实例3)                     │   │
│  └─────────────────────────────────────────────────────┘   │
│                           │                                 │
│              Nacos 轮询返回一个实例                          │
│                           ▼                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              沙箱容器 (多副本)                        │   │
│  │                                                     │   │
│  │  每个容器运行 sandbox_server.py                     │   │
│  │  提供命令执行、文件操作 API                          │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘

使用示例:

    # 方式 1: 获取单个沙箱（推荐，Nacos 负责负载均衡）
    from sycommon.agent.sandbox import HTTPSandboxBackend

    sandbox = HTTPSandboxBackend.from_nacos("sandbox-service", user_id="user123")
    result = await sandbox.aexecute("python --version")

    # 方式 2: 普通用户重置自己的工作目录
    await sandbox.areset()  # 仅重置 /workspace/user123/

    # 方式 3: 管理员批量管理所有沙箱
    from sycommon.agent.sandbox import SandboxPool

    pool = await SandboxPool.from_nacos("sandbox-service", is_admin=True)
    print(await pool.astatus())  # 查看所有实例状态
    await pool.areset_all()  # 重置所有沙箱（需要管理员权限）

    # 方式 4: 配合 Agent 使用
    from deepagents import create_deep_agent
    from sycommon.agent.sandbox import HTTPSandboxBackend

    sandbox = HTTPSandboxBackend.from_nacos("sandbox-service", user_id="user123")
    agent = create_deep_agent(
        model="openai:gpt-4o",
        backend=sandbox,
    )

    # 方式 5: 启用沙箱服务（在其他项目中）
    from fastapi import FastAPI
    from sycommon.services import Services

    app = Services.plugins(
        app=FastAPI(),
        sandbox_service=True,  # 启用沙箱服务
        ...
    )
"""

from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend
from sycommon.agent.sandbox.file_ops import TreeResult
from sycommon.agent.sandbox.sandbox_pool import (
    SandboxPool,
    SandboxInstance,
    areset_all_sandboxes,
    aget_sandbox_status,
)
from sycommon.agent.sandbox.sandbox_recovery import SandboxRecoveryManager

__all__ = [
    # 后端
    "HTTPSandboxBackend",

    # 数据类
    "TreeResult",

    # 池管理
    "SandboxPool",
    "SandboxInstance",

    # 恢复管理
    "SandboxRecoveryManager",

    # 便捷函数
    "areset_all_sandboxes",
    "aget_sandbox_status",
]
