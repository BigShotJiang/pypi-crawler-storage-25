"""
沙箱文件操作 Mixin

提供文件相关的同步/异步操作方法
适配 deepagents 0.5.0a2 协议
"""

import asyncio
import base64
from dataclasses import dataclass, field
from typing import Optional, TYPE_CHECKING

from sycommon.logging.kafka_log import SYLogger
from deepagents.backends.protocol import (
    FileInfo,
    FileData,
    LsResult,
    GrepResult,
    GlobResult,
    ReadResult,
    WriteResult,
    EditResult,
    GrepMatch,
)
from sycommon.models.sandbox import TreeNode

if TYPE_CHECKING:
    from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend

# 沙箱 API 路径前缀
SANDBOX_API_PREFIX = "/v1/sandbox"


@dataclass
class TreeResult:
    """tree 操作结果"""
    tree: Optional[TreeNode] = None
    error: Optional[str] = None

    def to_text(self) -> str:
        """将树形结构格式化为文本（类似 tree 命令输出）"""
        if self.error:
            return f"Error: {self.error}"
        if not self.tree:
            return ""
        lines = []
        self._format_node(self.tree, "", True, lines, is_root=True)
        return "\n".join(lines)

    def _format_node(self, node: TreeNode, prefix: str, is_last: bool, lines: list, is_root: bool = False):
        """递归格式化节点"""
        if is_root:
            lines.append(f"{node.name}/" if node.is_dir else node.name)
        else:
            connector = "└── " if is_last else "├── "
            suffix = "/" if node.is_dir else ""
            lines.append(f"{prefix}{connector}{node.name}{suffix}")

        if not node.is_dir or not node.children:
            return

        child_prefix = prefix + ("    " if is_last or is_root else "│   ")
        children = node.children
        for i, child in enumerate(children):
            self._format_node(child, child_prefix, i ==
                              len(children) - 1, lines)


@dataclass
class DeleteResult:
    """删除操作结果"""
    path: str
    error: Optional[str] = None


class FileOperationsMixin:
    """文件操作 Mixin

    适配 deepagents 0.5.0a2 协议
    同步方法为主实现，异步方法使用 aiohttp 实现
    """

    _timeout: int  # 类型提示，子类需要提供此属性
    user_id: str  # 类型提示，子类需要提供此属性
    _auto_sync: bool = False  # 是否自动同步
    _synced: bool = False  # 是否已同步
    _workspace_verified: bool = False  # 工作空间是否已验证存在

    def _post_sync(self: "HTTPSandboxBackend", endpoint: str, data: dict, timeout: int = None) -> dict:
        """发送同步 POST 请求"""
        ...

    async def _post_async_with_failover(self: "HTTPSandboxBackend", endpoint: str, data: dict, timeout: int = None) -> dict:
        """发送异步 POST 请求（带故障转移）"""
        ...

    def _ensure_synced_sync(self: "HTTPSandboxBackend"):
        """确保目录已同步（同步版本）"""
        if not self._auto_sync:
            return

        if self._synced and self._workspace_verified:
            return

        SYLogger.info(f"[Sandbox] 开始检查工作空间同步状态...")

        try:
            workspace_exists = self._check_workspace_exists_sync()
        except Exception as e:
            SYLogger.warning(f"[Sandbox] 检查工作空间异常: {e}，跳过检查")
            workspace_exists = True

        if not workspace_exists:
            SYLogger.info(f"[Sandbox] 工作空间不存在或已被清空，重新同步...")
            self._synced = False

        if not self._synced:
            SYLogger.info(f"[Sandbox] 开始同步目录...")
            self._sync_sync()
            self._workspace_verified = True
            SYLogger.info(f"[Sandbox] 同步完成")

    async def _ensure_synced_async(self: "HTTPSandboxBackend"):
        """确保目录已同步（异步版本）"""
        if not self._auto_sync:
            return

        if self._synced and self._workspace_verified:
            return

        SYLogger.info(f"[Sandbox] 开始检查工作空间同步状态（异步）...")

        try:
            workspace_exists = await self._check_workspace_exists_async()
        except Exception as e:
            SYLogger.warning(f"[Sandbox] 检查工作空间异常: {e}，跳过检查")
            workspace_exists = True

        if not workspace_exists:
            SYLogger.info(f"[Sandbox] 工作空间不存在或已被清空，重新同步...")
            self._synced = False

        if not self._synced:
            SYLogger.info(f"[Sandbox] 开始同步目录（异步）...")
            await self._sync_async()
            self._workspace_verified = True
            SYLogger.info(f"[Sandbox] 同步完成")

    def _check_workspace_exists_sync(self: "HTTPSandboxBackend") -> bool:
        """检查沙箱工作空间是否存在（同步版本）"""
        try:
            self._post_sync(f"{SANDBOX_API_PREFIX}/ls", {
                "path": "/",
                "user_id": self.user_id
            })
            return True
        except Exception as e:
            SYLogger.warning(f"[Sandbox] 检查工作空间失败: {e}")
            return False

    async def _check_workspace_exists_async(self: "HTTPSandboxBackend") -> bool:
        """检查沙箱工作空间是否存在（异步版本）"""
        try:
            await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/ls", {
                "path": "/",
                "user_id": self.user_id
            })
            return True
        except Exception as e:
            SYLogger.warning(f"[Sandbox] 检查工作空间失败: {e}")
            return False

    def _sync_sync(self: "HTTPSandboxBackend"):
        """同步目录（同步版本，由子类实现）"""
        ...

    async def _sync_async(self: "HTTPSandboxBackend") -> dict:
        """同步目录（异步版本，由子类实现）"""
        ...

    # ============== 目录操作 ==============

    def ls(self: "HTTPSandboxBackend", path: str) -> LsResult:
        """列出目录内容"""
        try:
            self._ensure_synced_sync()
            print(
                f"[Sandbox-DEBUG] ls() called with path={repr(path)}, user_id={repr(self.user_id)}", flush=True)
            SYLogger.info(f"[Sandbox] 列出目录: {path}")
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/ls", {
                "path": path,
                "user_id": self.user_id
            })
            print(
                f"[Sandbox-DEBUG] ls() raw result type={type(result).__name__}, repr={repr(result)[:500]}", flush=True)
            entries = [FileInfo(**item) for item in result]
            print(
                f"[Sandbox-DEBUG] ls() parsed entries={len(entries)}", flush=True)
            SYLogger.info(f"[Sandbox] 目录内容: {len(entries)} 项")
            return LsResult(entries=entries)
        except Exception as e:
            print(
                f"[Sandbox-DEBUG] ls() EXCEPTION: {type(e).__name__}: {e}", flush=True)
            SYLogger.error(f"[Sandbox] 列出目录失败: {e}")
            return LsResult(error=str(e))

    async def als(self: "HTTPSandboxBackend", path: str) -> LsResult:
        """异步列出目录内容（真正的异步实现）"""
        try:
            await self._ensure_synced_async()
            print(
                f"[Sandbox-DEBUG] als() called with path={repr(path)}, user_id={repr(self.user_id)}, base_url={repr(self._base_url if hasattr(self, '_base_url') else 'N/A')}", flush=True)
            SYLogger.info(f"[Sandbox] 异步列出目录: {path}")
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/ls", {
                "path": path,
                "user_id": self.user_id
            })
            print(
                f"[Sandbox-DEBUG] als() raw result type={type(result).__name__}, repr={repr(result)[:500]}", flush=True)
            entries = [FileInfo(**item) for item in result]
            print(
                f"[Sandbox-DEBUG] als() parsed entries={len(entries)}, first 3 paths={[e.get('path','?') if isinstance(e, dict) else getattr(e, 'path','?') for e in entries[:3]]}", flush=True)
            SYLogger.info(f"[Sandbox] 目录内容: {len(entries)} 项")
            return LsResult(entries=entries)
        except Exception as e:
            print(
                f"[Sandbox-DEBUG] als() EXCEPTION: {type(e).__name__}: {e}", flush=True)
            SYLogger.error(f"[Sandbox] 异步列出目录失败: {e}")
            return LsResult(error=str(e))

    # ============== 文件读写 ==============

    def read(
        self: "HTTPSandboxBackend",
        file_path: str,
        offset: int = 0,
        limit: int = 2000,
    ) -> ReadResult:
        """读取文件内容"""
        try:
            self._ensure_synced_sync()
            SYLogger.info(
                f"[Sandbox] 读取文件: {file_path} (offset={offset}, limit={limit})")
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/read", {
                "file_path": file_path,
                "user_id": self.user_id,
                "offset": offset,
                "limit": limit
            })
            if result.get("error"):
                SYLogger.error(f"[Sandbox] 读取文件失败: {result['error']}")
                return ReadResult(error=result["error"])
            content = result.get("content", "")
            SYLogger.info(f"[Sandbox] 读取完成: {len(content)} 字符")
            # 构建 FileData 格式
            from datetime import datetime
            now = datetime.now().isoformat()
            file_data = FileData(
                content=content,
                encoding="utf-8",
                created_at=result.get("created_at", now),
                modified_at=result.get("modified_at", now),
            )
            return ReadResult(file_data=file_data)
        except Exception as e:
            SYLogger.error(f"[Sandbox] 读取文件异常: {e}")
            return ReadResult(error=str(e))

    async def aread(
        self: "HTTPSandboxBackend",
        file_path: str,
        offset: int = 0,
        limit: int = 2000,
    ) -> ReadResult:
        """异步读取文件内容（真正的异步实现）"""
        try:
            await self._ensure_synced_async()
            SYLogger.info(
                f"[Sandbox] 异步读取文件: {file_path} (offset={offset}, limit={limit})")
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/read", {
                "file_path": file_path,
                "user_id": self.user_id,
                "offset": offset,
                "limit": limit
            })
            if result.get("error"):
                SYLogger.error(f"[Sandbox] 异步读取文件失败: {result['error']}")
                return ReadResult(error=result["error"])
            content = result.get("content", "")
            SYLogger.info(f"[Sandbox] 异步读取完成: {len(content)} 字符")
            from datetime import datetime
            now = datetime.now().isoformat()
            file_data = FileData(
                content=content,
                encoding="utf-8",
                created_at=result.get("created_at", now),
                modified_at=result.get("modified_at", now),
            )
            return ReadResult(file_data=file_data)
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步读取文件异常: {e}")
            return ReadResult(error=str(e))

    def write(
        self: "HTTPSandboxBackend",
        file_path: str,
        content: str,
    ) -> WriteResult:
        """写入文件"""
        try:
            self._ensure_synced_sync()
            SYLogger.info(f"[Sandbox] 写入文件: {file_path} ({len(content)} 字符)")
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/write", {
                "file_path": file_path,
                "content": base64.b64encode(content.encode()).decode(),
                "user_id": self.user_id
            })
            write_result = WriteResult(
                error=result.get("error"),
                path=result.get("path")
            )
            if write_result.error:
                SYLogger.error(f"[Sandbox] 写入失败: {write_result.error}")
            else:
                SYLogger.info(f"[Sandbox] 写入成功: {write_result.path}")
            return write_result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 写入文件异常: {e}")
            return WriteResult(error=str(e))

    async def awrite(
        self: "HTTPSandboxBackend",
        file_path: str,
        content: str,
    ) -> WriteResult:
        """异步写入文件（真正的异步实现）"""
        try:
            await self._ensure_synced_async()
            SYLogger.info(f"[Sandbox] 异步写入文件: {file_path} ({len(content)} 字符)")
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/write", {
                "file_path": file_path,
                "content": base64.b64encode(content.encode()).decode(),
                "user_id": self.user_id
            })
            write_result = WriteResult(
                error=result.get("error"),
                path=result.get("path")
            )
            if write_result.error:
                SYLogger.error(f"[Sandbox] 异步写入失败: {write_result.error}")
            else:
                SYLogger.info(f"[Sandbox] 异步写入成功: {write_result.path}")
            return write_result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步写入文件异常: {e}")
            return WriteResult(error=str(e))

    def edit(
        self: "HTTPSandboxBackend",
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """编辑文件"""
        try:
            self._ensure_synced_sync()
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/edit", {
                "file_path": file_path,
                "old_string": base64.b64encode(old_string.encode()).decode(),
                "new_string": base64.b64encode(new_string.encode()).decode(),
                "user_id": self.user_id,
                "replace_all": replace_all
            })
            return EditResult(
                error=result.get("error"),
                path=result.get("path"),
                occurrences=result.get("occurrences")
            )
        except Exception as e:
            SYLogger.error(f"[Sandbox] 编辑文件异常: {e}")
            return EditResult(error=str(e))

    async def aedit(
        self: "HTTPSandboxBackend",
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """异步编辑文件（真正的异步实现）"""
        try:
            await self._ensure_synced_async()
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/edit", {
                "file_path": file_path,
                "old_string": base64.b64encode(old_string.encode()).decode(),
                "new_string": base64.b64encode(new_string.encode()).decode(),
                "user_id": self.user_id,
                "replace_all": replace_all
            })
            return EditResult(
                error=result.get("error"),
                path=result.get("path"),
                occurrences=result.get("occurrences")
            )
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步编辑文件异常: {e}")
            return EditResult(error=str(e))

    # ============== 搜索 ==============

    def glob(self: "HTTPSandboxBackend", pattern: str, path: str = "/") -> GlobResult:
        """glob 搜索文件"""
        try:
            self._ensure_synced_sync()
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/glob", {
                "pattern": pattern,
                "path": path,
                "user_id": self.user_id
            })
            matches = [FileInfo(**item) for item in result]
            return GlobResult(matches=matches)
        except Exception as e:
            SYLogger.error(f"[Sandbox] glob 搜索失败: {e}")
            return GlobResult(error=str(e))

    async def aglob(self: "HTTPSandboxBackend", pattern: str, path: str = "/") -> GlobResult:
        """异步 glob 搜索文件（真正的异步实现）"""
        try:
            await self._ensure_synced_async()
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/glob", {
                "pattern": pattern,
                "path": path,
                "user_id": self.user_id
            })
            matches = [FileInfo(**item) for item in result]
            return GlobResult(matches=matches)
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步 glob 搜索失败: {e}")
            return GlobResult(error=str(e))

    # ============== 树形目录 ==============

    def tree(self: "HTTPSandboxBackend", path: str = "/", max_depth: int = 30, max_files: int = 0) -> TreeResult:
        """以树形结构展示目录"""
        try:
            self._ensure_synced_sync()
            SYLogger.info(f"[Sandbox] tree: {path}")
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/tree", {
                "path": path,
                "user_id": self.user_id,
                "max_depth": max_depth,
                "max_files": max_files,
            })
            if result.get("error"):
                return TreeResult(error=result["error"])
            tree_node = TreeNode(
                **result["tree"]) if result.get("tree") else None
            return TreeResult(tree=tree_node)
        except Exception as e:
            SYLogger.error(f"[Sandbox] tree 失败: {e}")
            return TreeResult(error=str(e))

    async def atree(self: "HTTPSandboxBackend", path: str = "/", max_depth: int = 30, max_files: int = 0) -> TreeResult:
        """异步以树形结构展示目录"""
        try:
            await self._ensure_synced_async()
            SYLogger.info(f"[Sandbox] 异步 tree: {path}")
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/tree", {
                "path": path,
                "user_id": self.user_id,
                "max_depth": max_depth,
                "max_files": max_files,
            })
            if result.get("error"):
                return TreeResult(error=result["error"])
            tree_node = TreeNode(
                **result["tree"]) if result.get("tree") else None
            return TreeResult(tree=tree_node)
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步 tree 失败: {e}")
            return TreeResult(error=str(e))

    def grep(
        self: "HTTPSandboxBackend",
        pattern: str,
        path: str = None,
        glob: str = None,
    ) -> GrepResult:
        """搜索文件内容"""
        try:
            self._ensure_synced_sync()
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/grep", {
                "pattern": pattern,
                "user_id": self.user_id,
                "path": path,
                "glob": glob
            })
            if isinstance(result, list):
                matches = [GrepMatch(**item) for item in result]
                return GrepResult(matches=matches)
            return GrepResult(error="Unexpected result format")
        except Exception as e:
            SYLogger.error(f"[Sandbox] grep 搜索失败: {e}")
            return GrepResult(error=str(e))

    async def agrep(
        self: "HTTPSandboxBackend",
        pattern: str,
        path: str = None,
        glob: str = None,
    ) -> GrepResult:
        """异步搜索文件内容（真正的异步实现）"""
        try:
            await self._ensure_synced_async()
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/grep", {
                "pattern": pattern,
                "user_id": self.user_id,
                "path": path,
                "glob": glob
            })
            if isinstance(result, list):
                matches = [GrepMatch(**item) for item in result]
                return GrepResult(matches=matches)
            return GrepResult(error="Unexpected result format")
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步 grep 搜索失败: {e}")
            return GrepResult(error=str(e))

    # ============== 删除操作 ==============

    def delete(
        self: "HTTPSandboxBackend",
        path: str,
        recursive: bool = False,
    ) -> DeleteResult:
        """删除文件或文件夹

        Args:
            path: 要删除的文件或文件夹路径
            recursive: 是否递归删除（删除文件夹时需要设为 True）

        Returns:
            DeleteResult
        """
        try:
            self._ensure_synced_sync()
            SYLogger.info(f"[Sandbox] 删除: {path} (recursive={recursive})")
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/delete", {
                "path": path,
                "user_id": self.user_id,
                "recursive": recursive,
            })
            delete_result = DeleteResult(
                path=result.get("path", path),
                error=result.get("error"),
            )
            if delete_result.error:
                SYLogger.error(f"[Sandbox] 删除失败: {delete_result.error}")
            else:
                SYLogger.info(f"[Sandbox] 删除成功: {delete_result.path}")
            return delete_result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 删除异常: {e}")
            return DeleteResult(path=path, error=str(e))

    async def adelete(
        self: "HTTPSandboxBackend",
        path: str,
        recursive: bool = False,
    ) -> DeleteResult:
        """异步删除文件或文件夹

        Args:
            path: 要删除的文件或文件夹路径
            recursive: 是否递归删除（删除文件夹时需要设为 True）

        Returns:
            DeleteResult
        """
        try:
            await self._ensure_synced_async()
            SYLogger.info(f"[Sandbox] 异步删除: {path} (recursive={recursive})")
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/delete", {
                "path": path,
                "user_id": self.user_id,
                "recursive": recursive,
            })
            delete_result = DeleteResult(
                path=result.get("path", path),
                error=result.get("error"),
            )
            if delete_result.error:
                SYLogger.error(f"[Sandbox] 异步删除失败: {delete_result.error}")
            else:
                SYLogger.info(f"[Sandbox] 异步删除成功: {delete_result.path}")
            return delete_result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步删除异常: {e}")
            return DeleteResult(path=path, error=str(e))

    # ============== 文件存在检查 ==============

    async def astat(self: "HTTPSandboxBackend", path: str) -> "StatResult":
        """异步检查文件或目录是否存在（尝试 read 一行来判断）"""
        try:
            await self._ensure_synced_async()
            SYLogger.info(f"[Sandbox] 异步检查文件存在: {path}")

            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/read", {
                "file_path": path,
                "user_id": self.user_id,
                "offset": 0,
                "limit": 1,
            })
            # read 成功返回结果说明文件存在
            if result and not result.get("error"):
                return StatResult(path=path, exists=True, is_dir=False, size=0)

            error = result.get("error", "") if result else ""
            # 如果错误是 is a directory，说明是目录，也存在
            if "is a directory" in error.lower() or "is_dir" in error.lower():
                return StatResult(path=path, exists=True, is_dir=True, size=0)

            return StatResult(path=path, exists=False)
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步检查文件存在异常: {e}")
            return StatResult(path=path, error=str(e))


@dataclass
class StatResult:
    """文件存在检查结果"""
    path: str
    exists: bool = False
    is_dir: bool = False
    size: int = 0
    error: Optional[str] = None
