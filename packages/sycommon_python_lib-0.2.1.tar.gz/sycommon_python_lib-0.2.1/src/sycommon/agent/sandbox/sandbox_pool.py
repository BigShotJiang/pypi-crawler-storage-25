"""
沙箱池管理器（异步版）

依赖 Nacos 进行服务发现和负载均衡，无需额外实现。

使用场景:
1. 管理员批量重置所有沙箱
2. 统一监控沙箱状态
3. Nacos 不可用时的本地缓存

推荐使用方式:
    # 简单场景 - 直接使用 HTTPSandboxBackend.from_nacos
    from sycommon.agent import HTTPSandboxBackend
    backend = HTTPSandboxBackend.from_nacos("sandbox-service", user_id="user123")

    # 普通用户重置自己的工作目录
    await backend.areset()

    # 管理员需要批量管理时 - 使用 SandboxPool（需要 is_admin=True）
    from sycommon.agent import SandboxPool
    pool = await SandboxPool.from_nacos("sandbox-service", is_admin=True)
    await pool.astatus()  # 查看所有实例状态
    await pool.areset_all()  # 重置所有沙箱（需要管理员权限）
"""

import time
import asyncio
from typing import Optional, List, Dict
from dataclasses import dataclass

from sycommon.logging.kafka_log import SYLogger
from sycommon.agent.sandbox.http_sandbox_backend import HTTPSandboxBackend


@dataclass
class SandboxInstance:
    """沙箱实例信息"""
    id: str
    base_url: str
    user_id: str = "default"
    is_admin: bool = False
    backend: Optional[HTTPSandboxBackend] = None


class SandboxPool:
    """
    沙箱容器池（异步版）- 管理员使用

    主要用于批量管理操作，负载均衡由 Nacos 负责。

    注意：此类的 areset_all 方法会重置所有用户的工作目录，仅限管理员使用。

    使用示例:
        # 管理员模式 - 查看状态和批量操作
        pool = await SandboxPool.from_nacos("sandbox-service", is_admin=True)
        print(await pool.astatus())
        await pool.areset_all()  # 重置所有沙箱（管理员权限）

        # 普通用户 - 使用 HTTPSandboxBackend 操作自己的工作目录
        from sycommon.agent import HTTPSandboxBackend
        backend = HTTPSandboxBackend.from_nacos("sandbox-service", user_id="user123")
        await backend.areset()  # 仅重置自己的工作目录
    """

    def __init__(self, is_admin: bool = False, user_id: str = "default"):
        """初始化空池

        Args:
            is_admin: 是否为管理员模式
            user_id: 用户ID（管理员模式下忽略）
        """
        self._is_admin = is_admin
        self._user_id = user_id
        self._instances: Dict[str, SandboxInstance] = {}
        self._last_refresh: float = 0
        self._refresh_interval: int = 30
        self._lock = asyncio.Lock()

    @classmethod
    async def from_nacos(
        cls,
        service_name: str,
        is_admin: bool = False,
        user_id: str = "default",
        group: str = "DEFAULT_GROUP",
        version: str = None,
    ) -> "SandboxPool":
        """
        从 Nacos 服务发现初始化沙箱池

        Args:
            service_name: Nacos 服务名
            is_admin: 是否为管理员模式（管理员可重置所有沙箱）
            user_id: 用户ID（管理员模式下忽略）
            group: 服务分组
            version: 服务版本

        Returns:
            SandboxPool 实例
        """
        from sycommon.synacos.nacos_service import NacosService

        pool = cls(is_admin=is_admin, user_id=user_id)

        # Nacos 服务发现是同步的，在线程池中执行
        nacos_manager = NacosService(None)
        instances = await asyncio.to_thread(
            nacos_manager.get_service_instances,
            service_name, group, None, version
        )

        if not instances:
            SYLogger.warning(f"服务 [{service_name}] 无可用实例")
            return pool

        for inst in instances:
            url = f"http://{inst['ip']}:{inst['port']}"
            instance_id = f"{inst['ip']}:{inst['port']}"
            pool._instances[instance_id] = SandboxInstance(
                id=instance_id,
                base_url=url,
                user_id=user_id if not is_admin else "admin",
                is_admin=is_admin,
            )

        SYLogger.info(f"沙箱池初始化: {service_name} -> {len(pool._instances)} 个实例 (admin={is_admin})")
        return pool

    async def refresh_from_nacos(
        self,
        service_name: str,
        group: str = "DEFAULT_GROUP",
        version: str = None,
    ):
        """从 Nacos 刷新实例列表"""
        if time.time() - self._last_refresh < self._refresh_interval:
            return

        from sycommon.synacos.nacos_service import NacosService

        nacos_manager = NacosService(None)
        instances = await asyncio.to_thread(
            nacos_manager.get_service_instances,
            service_name, group, None, version
        )

        async with self._lock:
            new_ids = set()
            for inst in instances or []:
                instance_id = f"{inst['ip']}:{inst['port']}"
                url = f"http://{inst['ip']}:{inst['port']}"
                new_ids.add(instance_id)

                if instance_id not in self._instances:
                    self._instances[instance_id] = SandboxInstance(
                        id=instance_id,
                        base_url=url,
                        user_id=self._user_id,
                    )

            removed = set(self._instances.keys()) - new_ids
            for instance_id in removed:
                del self._instances[instance_id]
                SYLogger.info(f"移除沙箱实例: {instance_id}")

        self._last_refresh = time.time()

    def get_all_backends(self) -> List[HTTPSandboxBackend]:
        """获取所有沙箱后端实例"""
        backends = []
        for instance in self._instances.values():
            if instance.backend is None:
                instance.backend = HTTPSandboxBackend(instance.base_url, user_id=instance.user_id)
            backends.append(instance.backend)
        return backends

    async def areset_all(self):
        """异步重置所有沙箱环境（仅管理员）"""
        if not self._is_admin:
            raise PermissionError("areset_all 方法仅限管理员使用，普通用户请使用 HTTPSandboxBackend.areset()")

        async def reset_one(instance: SandboxInstance):
            try:
                if instance.backend is None:
                    instance.backend = HTTPSandboxBackend(instance.base_url, user_id=instance.user_id)
                await instance.backend.areset()
                SYLogger.info(f"沙箱重置成功: {instance.id}")
            except Exception as e:
                SYLogger.error(f"沙箱重置失败: {instance.id} - {e}")

        tasks = [reset_one(inst) for inst in self._instances.values()]
        await asyncio.gather(*tasks)

    async def ahealth_check_all(self) -> Dict[str, bool]:
        """异步检查所有沙箱健康状态"""
        async def check_one(instance_id: str, instance: SandboxInstance) -> tuple:
            try:
                if instance.backend is None:
                    instance.backend = HTTPSandboxBackend(instance.base_url, user_id=instance.user_id)
                result = await instance.backend.ahealth_check()
                return (instance_id, result.get("status") == "ok")
            except Exception:
                return (instance_id, False)

        tasks = [check_one(id, inst) for id, inst in self._instances.items()]
        results = await asyncio.gather(*tasks)
        return dict(results)

    async def astatus(self) -> dict:
        """异步获取沙箱池状态"""
        health_status = await self.ahealth_check_all()
        return {
            "total": len(self._instances),
            "healthy": sum(1 for v in health_status.values() if v),
            "instances": {
                inst_id: {
                    "base_url": inst.base_url,
                    "healthy": health_status.get(inst_id, False),
                }
                for inst_id, inst in self._instances.items()
            }
        }

    @property
    def instance_count(self) -> int:
        """实例数量"""
        return len(self._instances)

    @property
    def instance_ids(self) -> List[str]:
        """所有实例 ID"""
        return list(self._instances.keys())


# ============== 便捷函数 ==============

async def areset_all_sandboxes(
    service_name: str,
    group: str = "DEFAULT_GROUP",
    is_admin: bool = True,
) -> int:
    """
    异步重置指定服务的所有沙箱（仅管理员）

    Args:
        service_name: Nacos 服务名
        group: 服务分组
        is_admin: 是否为管理员（必须为 True 才能执行）

    Returns:
        实例数量

    Raises:
        PermissionError: 非管理员调用时抛出
    """
    pool = await SandboxPool.from_nacos(service_name, is_admin=is_admin, group=group)
    await pool.areset_all()
    return pool.instance_count


async def aget_sandbox_status(
    service_name: str,
    group: str = "DEFAULT_GROUP",
) -> dict:
    """异步获取沙箱服务状态"""
    pool = await SandboxPool.from_nacos(service_name, group=group)
    return await pool.astatus()
