import asyncio
import random
from typing import Optional, List, Tuple
from aio_pika import connect_robust
from aio_pika.abc import AbstractChannel, AbstractRobustConnection
from sycommon.logging.kafka_log import SYLogger
from sycommon.notice.uvicorn_monitor import send_mq_disconnect_alert

logger = SYLogger


class RabbitMQConnectionPool:
    """
    RabbitMQ 连接池

    核心修复：
    1. 移除全局共享主通道模式，所有通道均为独立通道，彻底解决生产者共享通道导致的阻塞问题。
    2. 优化锁逻辑，防止死锁。
    3. 增强连接探活与重建机制。
    """

    # 心跳重试配置
    HEARTBEAT_RETRY_COUNT = 3  # 心跳失败重试次数
    HEARTBEAT_RETRY_INTERVAL = 10  # 心跳重试间隔（秒）

    def __init__(
        self,
        hosts: List[str],
        port: int,
        username: str,
        password: str,
        virtualhost: str = "/",
        heartbeat: int = 60,
        app_name: str = "",
        connection_timeout: int = 30,
        reconnect_interval: int = 5,
        prefetch_count: int = 2,
    ):
        # 参数处理
        self.hosts = [host.strip() for host in hosts if host.strip()]
        if not self.hosts:
            raise ValueError("至少需要提供一个RabbitMQ主机地址")

        self.port = port
        self.username = username
        self.password = password
        self.virtualhost = virtualhost
        self.app_name = app_name or "rabbitmq-client"
        self.heartbeat = heartbeat
        self.connection_timeout = connection_timeout
        self.reconnect_interval = reconnect_interval
        self.prefetch_count = prefetch_count

        self._current_host: str = random.choice(self.hosts)
        logger.info(f"[INIT] 随机选择RabbitMQ主机: {self._current_host}")

        # 核心资源
        self._connection: Optional[AbstractRobustConnection] = None
        # 保留内部通道仅用于连接池自身的探活检测，不对外暴露
        self._internal_channel: Optional[AbstractChannel] = None

        # 状态控制
        self._lock = asyncio.Lock()
        self._initialized = False
        self._is_shutdown = False

        # 心跳重试计数器
        self._heartbeat_fail_count = 0

        # 告警状态（实例级别，避免多实例共享状态）
        self._alert_sent: bool = False  # 是否已发送断连告警
        self._reconnect_attempts: int = 0  # 当前重连尝试次数
        self._disconnect_count: int = 0  # 累计断开次数
        self._consecutive_success: int = 0  # 连续成功次数，用于确认恢复

    async def is_alive(self) -> bool:
        """对外暴露的连接存活状态（带心跳重试机制）

        心跳检测失败时不会立即判定为断开，而是重试3次后才断开。
        恢复通知需要连续成功3次确认，避免短暂恢复后又断开的波动情况。
        """
        if self._is_shutdown:
            return False
        if not self._initialized:
            return False

        # 基础连接检查
        if self._connection is None or self._connection.is_closed:
            self._heartbeat_fail_count += 1
            self._consecutive_success = 0  # 失败时重置连续成功计数
            logger.warning(
                f"⚠️ [HEARTBEAT] 连接已断开 (失败计数: {self._heartbeat_fail_count}/{self.HEARTBEAT_RETRY_COUNT})"
            )
            if self._heartbeat_fail_count >= self.HEARTBEAT_RETRY_COUNT:
                logger.error("❌ [HEARTBEAT] 心跳重试次数已达上限，判定连接死亡")
                # 发送断连告警（仅发送一次）
                if not self._alert_sent:
                    self._alert_sent = True
                    self._disconnect_count += 1
                    logger.warning(
                        f"📊 [MQ_ALERT] 发送断连告警，累计断开: {self._disconnect_count}次，重连尝试: {self._reconnect_attempts}次"
                    )
                    asyncio.create_task(send_mq_disconnect_alert(
                        error_msg="心跳检测连续失败，连接已断开",
                        host=self._current_host,
                        app_name=self.app_name,
                        disconnect_count=self._disconnect_count,
                        reconnect_attempts=self._reconnect_attempts
                    ))
                return False
            # 未达上限，暂时认为存活（等待重试）
            return True

        # 内部通道探活检查
        try:
            if self._internal_channel is None or self._internal_channel.is_closed:
                self._internal_channel = await self._connection.channel()
            # 探活成功
            self._heartbeat_fail_count = 0
            self._consecutive_success += 1

            # 如果之前发送过告警，心跳成功一次即发送恢复通知
            if self._alert_sent and self._consecutive_success >= 1:
                self._alert_sent = False
                saved_reconnect_attempts = self._reconnect_attempts
                saved_disconnect_count = self._disconnect_count
                self._reconnect_attempts = 0
                logger.info(
                    f"✅ [MQ_RECOVERED] 连接已稳定恢复（连续成功{self._consecutive_success}次），发送恢复通知"
                )
                asyncio.create_task(send_mq_disconnect_alert(
                    error_msg="连接已恢复",
                    host=self._current_host,
                    app_name=self.app_name,
                    disconnect_count=saved_disconnect_count,
                    reconnect_attempts=saved_reconnect_attempts,
                    is_recovered=True
                ))
            return True
        except Exception as e:
            self._heartbeat_fail_count += 1
            self._consecutive_success = 0  # 异常时重置连续成功计数
            logger.warning(
                f"⚠️ [HEARTBEAT] 连接探活失败: {e} (失败计数: {self._heartbeat_fail_count}/{self.HEARTBEAT_RETRY_COUNT})"
            )
            if self._heartbeat_fail_count >= self.HEARTBEAT_RETRY_COUNT:
                logger.error("❌ [HEARTBEAT] 心跳重试次数已达上限，判定连接死亡")
                # 发送断连告警（仅发送一次）
                if not self._alert_sent:
                    self._alert_sent = True
                    self._disconnect_count += 1
                    logger.warning(
                        f"📊 [MQ_ALERT] 发送断连告警（异常），累计断开: {self._disconnect_count}次，重连尝试: {self._reconnect_attempts}次"
                    )
                    asyncio.create_task(send_mq_disconnect_alert(
                        error_msg=str(e),
                        host=self._current_host,
                        app_name=self.app_name,
                        disconnect_count=self._disconnect_count,
                        reconnect_attempts=self._reconnect_attempts
                    ))
                return False
            # 未达上限，暂时认为存活（等待重试）
            return True

    async def _cleanup_resources(self):
        """彻底清理资源"""
        logger.info("🧹 [CLEANUP] 开始清理连接池资源...")

        if self._internal_channel:
            try:
                if not self._internal_channel.is_closed:
                    await self._internal_channel.close()
            except Exception as e:
                logger.warning(f"⚠️ [CLEANUP_INTERNAL] 关闭内部通道失败: {e}")
            finally:
                self._internal_channel = None

        if self._connection:
            try:
                if not self._connection.is_closed:
                    await self._connection.close()
            except Exception as e:
                logger.warning(f"⚠️ [CLEANUP_CONN] 关闭连接失败: {e}")
            finally:
                self._connection = None

        logger.info("✅ [CLEANUP] 资源清理完成")

    async def _create_connection_impl(self, host: str) -> AbstractRobustConnection:
        conn_url = (
            f"amqp://{self.username}:{self.password}@{host}:{self.port}/"
            f"{self.virtualhost}?name={self.app_name}&heartbeat={self.heartbeat}"
            f"&reconnect_interval={self.reconnect_interval}&fail_fast=1"
        )
        logger.info(f"🔌 [CONNECT] 尝试连接节点: {host}")
        try:
            conn = await asyncio.wait_for(
                connect_robust(conn_url),
                timeout=self.connection_timeout + 5
            )
            logger.info(f"✅ [CONNECT_OK] 节点连接成功: {host}")
            return conn
        except Exception as e:
            logger.error(f"❌ [CONNECT_FAIL] 节点 {host} 连接失败: {str(e)}")
            raise ConnectionError(f"无法连接RabbitMQ {host}") from e

    async def _ensure_connection(self) -> AbstractRobustConnection:
        async with self._lock:
            if self._is_shutdown:
                raise RuntimeError("连接池已关闭")

            connection_is_dead = False

            if self._connection is None or self._connection.is_closed:
                connection_is_dead = True
            else:
                try:
                    if self._internal_channel is None or self._internal_channel.is_closed:
                        self._internal_channel = await self._connection.channel()
                except Exception:
                    logger.warning("⚠️ 连接探活失败，判定为死连接，强制重建...")
                    connection_is_dead = True

            if connection_is_dead:
                await self._cleanup_resources()

                retry_hosts = self.hosts.copy()
                random.shuffle(retry_hosts)
                last_error = None

                for host in retry_hosts:
                    self._current_host = host
                    self._reconnect_attempts += 1
                    try:
                        self._connection = await self._create_connection_impl(host)
                        self._initialized = True
                        last_error = None
                        break
                    except Exception as e:
                        last_error = e
                        await asyncio.sleep(self.reconnect_interval)

                if last_error:
                    self._initialized = False
                    raise ConnectionError("所有 RabbitMQ 节点连接失败") from last_error

                # 重连成功
                self._consecutive_success = 1  # 重连成功算第1次成功
                # 发送恢复通知（重连成功后直接发送，因为是主动重建连接）
                if self._alert_sent:
                    self._alert_sent = False
                    saved_reconnect_attempts = self._reconnect_attempts
                    saved_disconnect_count = self._disconnect_count
                    self._reconnect_attempts = 0
                    logger.info(
                        f"✅ [MQ_RECONNECT_OK] 重连成功，发送恢复通知，累计断开: {saved_disconnect_count}次"
                    )
                    asyncio.create_task(send_mq_disconnect_alert(
                        error_msg="连接重连成功",
                        host=self._current_host,
                        app_name=self.app_name,
                        disconnect_count=saved_disconnect_count,
                        reconnect_attempts=saved_reconnect_attempts,
                        is_recovered=True
                    ))

            # 连接正常，重置心跳失败计数器
            self._heartbeat_fail_count = 0

            return self._connection

    async def init_pools(self):
        """初始化入口"""
        if self._initialized:
            return
        await self._ensure_connection()
        logger.info(f"🚀 [INIT_OK] 连接池初始化完成: {self._current_host}")

    async def acquire_channel(self) -> Tuple[AbstractChannel, AbstractRobustConnection]:
        """
        获取通道
        【安全保证】：每次返回独立通道，调用方负责关闭或由连接池事件清理
        """
        if not self._initialized and not self._is_shutdown:
            await self.init_pools()

        conn = await self._ensure_connection()

        try:
            channel = await conn.channel()
            await channel.set_qos(prefetch_count=self.prefetch_count)
            return channel, conn
        except Exception as e:
            logger.error(f"❌ [CHANNEL_FAIL] 创建独立通道失败: {e}")
            # 通道创建失败可能是连接已失效，触发连接重建以便下次使用新连接
            # 不在持有锁的情况下调用 force_reconnect，避免死锁
            self._initialized = False
            raise

    async def force_reconnect(self):
        async with self._lock:
            if self._is_shutdown:
                return
            logger.warning("🔄 [FORCE_RECONNECT] 开始强制重连...")
            self._initialized = False
            await self._cleanup_resources()

        try:
            await self._ensure_connection()
            logger.info("✅ [FORCE_RECONNECT_OK] 强制重连成功")
        except Exception as e:
            logger.error(f"❌ [FORCE_RECONNECT_FAIL] 强制重连失败: {e}")
            raise

    async def close(self):
        async with self._lock:
            if self._is_shutdown:
                return
            self._is_shutdown = True
            self._initialized = False
            logger.info("🛑 [CLOSE] 开始关闭连接池...")
            await self._cleanup_resources()
            logger.info("🏁 [CLOSE] 连接池已关闭")
