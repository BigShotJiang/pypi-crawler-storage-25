# -*- coding: utf-8 -*-
"""
心跳进程模块

将 Nacos 心跳和 RabbitMQ 连接监控迁移到独立进程，避免主进程 GIL 对心跳的影响。

使用场景：
- 主进程存在 CPU 密集型任务（如 MQ 消费者处理业务逻辑）
- 需要保证心跳和连接监控的稳定性

架构说明：
- 心跳进程有独立的 Python 解释器和 GIL
- 即使主进程阻塞，心跳进程仍能正常工作
- MQ 消息的收发仍在主进程（业务需要）

使用方式：

方式一：环境变量开关
    import os
    os.environ['HEARTBEAT_PROCESS_MODE'] = 'true'

方式二：代码开关
    from sycommon.heartbeat_process import HeartbeatProcessManager, NacosHeartbeatConfig

    # 启用进程模式
    HeartbeatProcessManager.enable_process_mode(True)

    # 创建配置
    nacos_config = NacosHeartbeatConfig(
        server_addresses="nacos.example.com:8848",
        namespace_id="your-namespace",
        service_name="my-service",
        real_ip="192.168.1.100",
        port=8080,
        version="1.0.0"
    )

    # 启动心跳进程
    HeartbeatProcessManager.start(nacos_config=nacos_config)

    # 关闭时
    HeartbeatProcessManager.stop()

方式三：集成到现有服务
    # 在 nacos_service.py 的 setup_nacos() 中
    use_process = config.get('useProcessMode', False)
    if use_process:
        HeartbeatProcessManager.enable_process_mode(True)
        nacos_config = NacosHeartbeatConfig.from_dict(config)
        HeartbeatProcessManager.start(nacos_config=nacos_config)
"""

from sycommon.heartbeat_process.heartbeat_process_manager import HeartbeatProcessManager
from sycommon.heartbeat_process.heartbeat_config import (
    NacosHeartbeatConfig,
    RabbitMQMonitorConfig,
    LogConfig
)

__all__ = [
    'HeartbeatProcessManager',
    'NacosHeartbeatConfig',
    'RabbitMQMonitorConfig',
    'LogConfig',
]

__version__ = '1.0.0'
