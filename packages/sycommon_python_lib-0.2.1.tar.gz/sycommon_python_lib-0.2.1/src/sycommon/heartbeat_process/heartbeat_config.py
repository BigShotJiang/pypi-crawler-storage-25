# -*- coding: utf-8 -*-
"""
心跳进程配置类

用于在主进程和心跳进程之间传递配置信息。
使用 dataclass 确保配置可序列化（multiprocessing 需要可序列化的对象）。
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class NacosHeartbeatConfig:
    """Nacos 心跳配置（可序列化）

    用于独立进程中的 Nacos 心跳发送。
    包含建立 Nacos 连接和发送心跳所需的所有信息。
    """
    server_addresses: str           # Nacos 服务器地址，如 "nacos.example.com:8848"
    namespace_id: str               # 命名空间 ID
    service_name: str               # 服务名称
    real_ip: str                    # 服务真实 IP
    port: int                       # 服务端口
    version: Optional[str] = None   # 服务版本
    heartbeat_interval: int = 15    # 心跳间隔（秒）
    heartbeat_timeout: int = 15     # 心跳超时（秒）
    username: Optional[str] = None  # Nacos 用户名
    password: Optional[str] = None  # Nacos 密码

    @classmethod
    def from_dict(cls, config: dict) -> 'NacosHeartbeatConfig':
        """从字典创建配置对象

        Args:
            config: Nacos 配置字典，通常来自 NacosService 的配置

        Returns:
            NacosHeartbeatConfig 实例
        """
        return cls(
            server_addresses=config.get('registerIp', ''),
            namespace_id=config.get('namespaceId', ''),
            service_name=config.get('serviceName', ''),
            real_ip=config.get('ip', ''),
            port=int(config.get('port', 8080)),
            version=config.get('version'),
            heartbeat_interval=int(config.get('heartbeatInterval', 15)),
            heartbeat_timeout=int(config.get('heartbeatTimeout', 15)),
            username=config.get('username'),
            password=config.get('password')
        )


@dataclass
class RabbitMQMonitorConfig:
    """RabbitMQ 连接监控配置（可序列化）

    用于独立进程中的 RabbitMQ 连接存活监控。
    注意：此配置仅用于连接监控，不涉及消息的消费和发送。

    职责：
    - 定期检查 RabbitMQ 服务器是否可达
    - 检测连接断开/恢复并发送告警

    不负责：
    - MQ 消息消费（在主进程中进行）
    - MQ 消息发送（在主进程中进行）
    """
    host: str                       # RabbitMQ 主机地址
    port: int                       # RabbitMQ 端口
    username: str                   # 用户名
    password: str                   # 密码
    virtualhost: str                # 虚拟主机
    app_name: str                   # 应用名称（用于标识连接）
    heartbeat: int = 60             # 心跳间隔（秒）
    check_interval: int = 15        # 连接检查间隔（秒）

    @classmethod
    def from_dict(cls, config: dict) -> 'RabbitMQMonitorConfig':
        """从字典创建配置对象

        Args:
            config: RabbitMQ 配置字典

        Returns:
            RabbitMQMonitorConfig 实例
        """
        return cls(
            host=config.get('host', 'localhost'),
            port=int(config.get('port', 5672)),
            username=config.get('username', 'guest'),
            password=config.get('password', 'guest'),
            virtualhost=config.get('virtualhost', '/'),
            app_name=config.get('app_name', 'unknown'),
            heartbeat=int(config.get('heartbeat', 60)),
            check_interval=int(config.get('check_interval', 15))
        )


@dataclass
class LogConfig:
    """日志配置（可序列化）

    用于在独立进程中初始化日志系统。
    包含发送日志到 Kafka 所需的配置信息。
    """
    service_name: str                           # 服务名称
    namespace_id: str                           # 命名空间 ID（用于 env 字段）
    kafka_servers: Optional[str] = None         # Kafka 服务器地址
    kafka_topic: str = "shengye-json-log"       # Kafka topic

    @classmethod
    def from_nacos_config(cls, nacos_config: dict, service_name: str, shared_configs: dict = None) -> 'LogConfig':
        """从 Nacos 配置创建日志配置

        Args:
            nacos_config: Nacos 配置字典
            service_name: 服务名称
            shared_configs: 共享配置（已从 Nacos 读取的配置）

        Returns:
            LogConfig 实例
        """
        kafka_servers = None

        # 尝试从 shared_configs 获取 Kafka 配置
        if shared_configs and isinstance(shared_configs, dict):
            common_config = shared_configs.get("common.yml", {})
            if isinstance(common_config, dict):
                kafka_servers = common_config.get('log', {}).get('kafka', {}).get('servers')

        return cls(
            service_name=service_name,
            namespace_id=nacos_config.get('namespaceId', ''),
            kafka_servers=kafka_servers
        )
