import os
import threading
import socket
import signal
import sys
import time
from typing import Callable, Dict, List, Optional
from sycommon.config.Config import Config, SingletonMeta
from sycommon.logging.kafka_log import SYLogger

from sycommon.synacos.nacos_client_base import NacosClientBase
from sycommon.synacos.nacos_service_registration import NacosServiceRegistration
from sycommon.synacos.nacos_heartbeat_manager import NacosHeartbeatManager
from sycommon.synacos.nacos_config_manager import NacosConfigManager
from sycommon.synacos.nacos_service_discovery import NacosServiceDiscovery
from sycommon.tools.env import check_env_flag, get_env_var


class NacosService(metaclass=SingletonMeta):
    # 进程模式标记
    _use_process_mode: bool = False
    _heartbeat_process_started: bool = False
    _signal_handled: bool = False  # 防止重复处理信号

    def __init__(self, config):
        if config:
            self.config = config
            self.nacos_config = config['Nacos']
            self.service_name = config['Name']
            self.host = config['Host']
            self.port = config['Port']
            self.version = get_env_var('VERSION')
            self.enable_register_nacos = check_env_flag(
                ['REGISTER_NACOS'], 'true')

            # 检查是否启用进程模式
            self._check_process_mode()

            # 初始化基础模块
            self.client_base = NacosClientBase(
                self.nacos_config, self.enable_register_nacos)

            # 获取真实IP
            self.real_ip = self.get_service_ip(self.host)

            # 初始化各功能模块
            self.registration = NacosServiceRegistration(
                self.client_base, self.service_name, self.real_ip, self.port, self.version
            )
            self.config_manager = NacosConfigManager(self.client_base)
            self.discovery = NacosServiceDiscovery(self.client_base)

            # 心跳间隔配置
            self.heartbeat_interval = self.nacos_config.get(
                'heartbeatInterval', 15)
            self.heartbeat_manager = NacosHeartbeatManager(
                self.client_base, self.registration, self.heartbeat_interval
            )

            if self.enable_register_nacos:
                # 初始化客户端
                self.client_base._initialize_client()
                # 清理残留实例
                self.registration._cleanup_stale_instance()
            else:
                SYLogger.info("nacos:本地开发模式，不初始化Nacos客户端")

            # 读取配置并设置到全局配置
            self.share_configs = self.config_manager.read_configs(
                self.nacos_config.get('sharedConfigs', []))
            Config().set_attr(self.share_configs)

            # 仅在需要注册时启动心跳
            if self.enable_register_nacos:
                # 如果启用进程模式，跳过线程模式的心跳启动
                if not self._use_process_mode:
                    self.heartbeat_manager.start_heartbeat()
                else:
                    SYLogger.info("nacos:进程模式已启用，心跳将在独立进程中运行")
            else:
                SYLogger.info("nacos:本地开发模式，不启动心跳和监控线程")

    def _check_process_mode(self):
        """检查是否启用进程模式

        优先级：
        1. 环境变量 HEARTBEAT_PROCESS_MODE
        2. 配置项 useProcessMode
        3. 操作系统检测（Windows 默认禁用）

        默认：
        - Windows: 禁用进程模式（spawn 模式有限制）
        - macOS/Linux: 启用进程模式
        """
        import platform

        env_mode = os.getenv('HEARTBEAT_PROCESS_MODE', '').lower()
        if env_mode in ('false', '0', 'no'):
            self._use_process_mode = False
            SYLogger.info("nacos:环境变量禁用进程模式，使用线程模式")
        elif env_mode in ('true', '1', 'yes'):
            self._use_process_mode = True
        else:
            # 从配置读取
            config_value = self.nacos_config.get('useProcessMode')
            if config_value is not None:
                # 处理字符串配置
                if isinstance(config_value, str):
                    self._use_process_mode = config_value.lower() not in ('false', '0', 'no')
                else:
                    self._use_process_mode = bool(config_value)
            else:
                # 默认：Windows 禁用进程模式，其他系统启用
                if platform.system() == 'Windows':
                    self._use_process_mode = False
                    SYLogger.info("nacos:Windows 系统默认禁用进程模式，使用线程模式")
                else:
                    self._use_process_mode = True

        if self._use_process_mode:
            SYLogger.info("nacos:启用进程模式，心跳将在独立进程中运行")

    @staticmethod
    def setup_nacos(config: dict):
        """创建并初始化Nacos管理器（保持原有接口）

        支持进程模式：
        - 通过环境变量 HEARTBEAT_PROCESS_MODE=true 启用
        - 通过配置 useProcessMode: true 启用
        - 进程模式下，心跳在独立进程中运行，不受主进程 GIL 影响
        """
        instance = NacosService(config)

        if instance.enable_register_nacos:
            # 启动注册线程
            timeout = 60
            start_time = time.time()

            register_thread = threading.Thread(
                target=instance.registration.register_with_retry,
                daemon=True,
                name="NacosRegisterThread"
            )
            register_thread.start()

            # 等待注册完成或超时（使用事件等待替代 time.sleep 自旋）
            _register_event = threading.Event()

            def _check_registered():
                while not instance.registration.registered:
                    if time.time() - start_time >= timeout:
                        break
                    time.sleep(0.2)
                _register_event.set()

            threading.Thread(target=_check_registered, daemon=True).start()
            _register_event.wait(timeout=timeout)

            # 最终状态检查
            if not instance.registration.registered:
                try:
                    instance.registration.deregister_service()
                except Exception as e:
                    SYLogger.error(f"nacos:服务注册失败后，注销服务时发生错误: {e}")
                raise RuntimeError("nacos:服务注册失败，应用启动终止")

            # 注册信号处理（Windows 兼容）
            signal.signal(signal.SIGINT, instance.handle_signal)
            if hasattr(signal, 'SIGTERM'):
                signal.signal(signal.SIGTERM, instance.handle_signal)

            # 根据模式启动心跳
            if instance._use_process_mode:
                # 进程模式：在独立进程中运行心跳
                instance._start_heartbeat_process()
            else:
                # 线程模式：启动连接监控线程
                threading.Thread(target=instance.discovery.monitor_connection,
                                 args=(instance.registration,),
                                 daemon=True,
                                 name="NacosConnectionMonitorThread").start()
        else:
            SYLogger.info("nacos:本地开发模式，跳过服务注册流程")

        return instance

    def _start_heartbeat_process(self):
        """启动独立心跳进程"""
        if self._heartbeat_process_started:
            return

        try:
            from sycommon.heartbeat_process import (
                HeartbeatProcessManager,
                NacosHeartbeatConfig,
                LogConfig
            )

            # 创建心跳配置
            nacos_heartbeat_config = NacosHeartbeatConfig(
                server_addresses=self.nacos_config.get('registerIp', ''),
                namespace_id=self.nacos_config.get('namespaceId', ''),
                service_name=self.service_name,
                real_ip=self.real_ip,
                port=self.port,
                version=self.version,
                heartbeat_interval=self.heartbeat_interval,
                heartbeat_timeout=self.nacos_config.get(
                    'heartbeatTimeout', 15),
                username=self.nacos_config.get('username'),
                password=self.nacos_config.get('password')
            )

            # 创建日志配置（用于独立进程发送日志到公司平台）
            log_config = LogConfig.from_nacos_config(
                self.nacos_config,
                self.service_name,
                self.share_configs  # 已读取的共享配置
            )

            # 启动心跳进程
            HeartbeatProcessManager.enable_process_mode(True)
            success = HeartbeatProcessManager.start(
                nacos_config=nacos_heartbeat_config,
                log_config=log_config
            )

            if success:
                self._heartbeat_process_started = True
                SYLogger.info("nacos:心跳进程启动成功")
            else:
                SYLogger.warning("nacos:心跳进程启动失败，降级到线程模式")
                self._use_process_mode = False
                self.heartbeat_manager.start_heartbeat()

        except Exception as e:
            SYLogger.error(f"nacos:启动心跳进程异常: {e}，降级到线程模式")
            self._use_process_mode = False
            self.heartbeat_manager.start_heartbeat()

    def get_service_ip(self, config_ip):
        """获取服务实际IP地址（保持原有逻辑）"""
        if config_ip in ['127.0.0.1', '0.0.0.0']:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                    s.connect(('8.8.8.8', 80))
                    return s.getsockname()[0]
            except Exception:
                return '127.0.0.1'
        return config_ip

    def handle_signal(self, signum, frame):
        """处理退出信号：Ctrl+C 一次直接退出进程。"""
        print(f"[NacosService] 收到信号 {signum}，正在关闭服务...")

        # 停止心跳进程（非阻塞：terminate 后不 join）
        if self._heartbeat_process_started:
            try:
                from sycommon.heartbeat_process import HeartbeatProcessManager
                proc = HeartbeatProcessManager._process
                if proc and proc.is_alive():
                    proc.terminate()
                HeartbeatProcessManager._cleanup()
                print("[NacosService] 心跳进程已停止")
            except Exception as e:
                print(f"[NacosService] 停止心跳进程异常: {e}")

        try:
            self.registration.deregister_service()
        except Exception as e:
            print(f"[NacosService] 注销服务异常: {e}")

        os._exit(0)

    # 以下为兼容原有接口的封装方法
    def add_config_listener(self, data_id: str, callback: Callable[[str], None], group: str = "DEFAULT_GROUP"):
        return self.config_manager.add_config_listener(data_id, callback, group)

    def get_config(self, data_id: str, group: str = "DEFAULT_GROUP") -> Optional[str]:
        return self.config_manager.get_config(data_id, group)

    def discover_services(self, service_name: str, group: str = "DEFAULT_GROUP", version: str = None) -> List[Dict]:
        return self.discovery.discover_services(service_name, group, version)

    def get_service_instances(self, service_name: str, group: str = "DEFAULT_GROUP", target_version: str = None, return_all: bool = False) -> List[Dict]:
        return self.discovery.get_service_instances(service_name, group, target_version, return_all)
