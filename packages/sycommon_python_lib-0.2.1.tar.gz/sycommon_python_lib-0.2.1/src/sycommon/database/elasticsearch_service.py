"""
Elasticsearch 异步服务
管理 ES 客户端连接，供其他业务服务使用
"""
import logging
from typing import Optional, Any, List

from sycommon.config.Config import SingletonMeta


class ElasticsearchService(metaclass=SingletonMeta):
    """Elasticsearch 基础服务（单例）"""
    _client: Optional[Any] = None
    _initialized: bool = False

    def __init__(self):
        pass

    @classmethod
    def setup(cls, config: Optional[dict] = None):
        """
        ES 服务初始化函数（用于 Services.plugins 传入）

        用法：
            Services.plugins(
                app,
                elasticsearch_service=ElasticsearchService.setup
            )
        """
        cls.init(config)

    @classmethod
    def init(cls, config: Optional[dict] = None):
        """
        初始化 ES 连接

        Args:
            config: 配置字典，包含 ElasticsearchConfig 配置
        """
        if cls._initialized:
            return

        try:
            from sycommon.config.ElasticsearchConfig import ElasticsearchConfig
            from sycommon.config.Config import Config

            # 获取 ES 配置
            es_configs = Config().config.get('ElasticsearchConfig', [])
            if not es_configs:
                logging.info("未配置 ElasticsearchConfig，ES 服务将禁用")
                return

            # 使用第一个配置
            es_config = ElasticsearchConfig(**es_configs[0])

            # 导入 ES 客户端
            try:
                from elasticsearch import AsyncElasticsearch
            except ImportError:
                logging.warning("未安装 elasticsearch 包，请执行: pip install elasticsearch")
                return

            # 创建异步客户端
            cls._client = AsyncElasticsearch(
                hosts=es_config.uri_list,
                basic_auth=(es_config.username, es_config.password),
                verify_certs=False,
                retry_on_timeout=True,
                max_retries=3
            )

            cls._initialized = True
            logging.info(f"ElasticsearchService 初始化成功，ES 地址: {es_config.uris}")

        except Exception as e:
            logging.error(f"ElasticsearchService 初始化失败: {e}", exc_info=True)

    @classmethod
    def get_client(cls) -> Optional[Any]:
        """
        获取 ES 客户端

        Returns:
            AsyncElasticsearch 客户端实例，未初始化返回 None
        """
        return cls._client

    @classmethod
    def is_initialized(cls) -> bool:
        """检查是否已初始化"""
        return cls._initialized

    @classmethod
    async def close(cls):
        """关闭 ES 连接"""
        if cls._client:
            try:
                await cls._client.close()
                logging.info("ElasticsearchService ES 连接已关闭")
            except Exception as e:
                logging.error(f"关闭 ES 连接失败: {e}")
            finally:
                cls._client = None
                cls._initialized = False
