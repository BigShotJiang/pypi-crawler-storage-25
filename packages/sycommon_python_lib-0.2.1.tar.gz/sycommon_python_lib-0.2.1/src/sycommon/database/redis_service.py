"""
Redis 异步服务
使用 redis-py 官方异步客户端
"""
import logging
from typing import Optional, Any, Union

from sycommon.config.Config import SingletonMeta
from sycommon.config.RedisConfig import RedisConfig


class RedisService(metaclass=SingletonMeta):
    """Redis 异步服务（单例）"""
    _client: Optional[Any] = None
    _initialized: bool = False
    _config: Optional[RedisConfig] = None

    def __init__(self):
        # 延迟初始化，等待配置加载完成
        pass

    @classmethod
    def setup(cls, config: Optional[dict] = None):
        """
        Redis 服务初始化函数（用于 Services.plugins 传入）

        用法：
            Services.plugins(
                app,
                redis_service=RedisService.setup
            )
        """
        cls.init(config)

    @classmethod
    def init(cls, config: Optional[dict] = None):
        """
        初始化 Redis 连接

        如果不传 config，会自动从 Nacos 读取 redis.yml 配置：
            NacosService(Config().config).share_configs.get("redis.yml", {})

        Args:
            config: 配置字典，支持 Spring Redis YAML 格式（可选）
        """
        if cls._initialized:
            return

        try:
            # 如果没有传入配置，自动从 Nacos 读取
            if config is None:
                try:
                    from sycommon.config.Config import Config

                    config = Config().config.get("redis.yml", {})

                    if not config:
                        logging.info("未从 Nacos 获取到 redis.yml 配置，Redis 服务将禁用")
                        return

                    logging.info("从 Nacos 获取 redis.yml 配置成功")
                except Exception as e:
                    logging.info(f"从 Nacos 读取 redis.yml 配置失败: {e}，Redis 服务将禁用")
                    return

            # 解析 Spring Redis YAML 格式配置
            cls._config = RedisConfig.from_spring_yaml(config)

            # 导入 redis-py 异步客户端
            try:
                import redis.asyncio
            except ImportError:
                logging.warning("未安装 redis 包，请执行: pip install redis")
                return

            # 获取连接池配置
            pool_config = cls._config.pool
            max_connections = pool_config.max_active if pool_config else 50

            # 判断是否为 Sentinel 模式
            if cls._config.is_sentinel_mode:
                cls._init_sentinel_client(max_connections)
            else:
                cls._init_standalone_client(max_connections)

            cls._initialized = True

        except Exception as e:
            logging.error(f"RedisService 初始化失败: {e}", exc_info=True)

    @classmethod
    def _init_standalone_client(cls, max_connections: int):
        """初始化单机模式客户端"""
        from redis.asyncio import Redis, ConnectionPool

        pool = ConnectionPool(
            host=cls._config.host,
            port=cls._config.port,
            password=cls._config.password,
            db=cls._config.database,
            max_connections=max_connections,
            socket_timeout=cls._config.timeout,
            decode_responses=True  # 自动解码为字符串
        )

        cls._client = Redis(connection_pool=pool)

        logging.info(
            f"RedisService 初始化成功（单机模式），地址: {cls._config.host}:{cls._config.port}, "
            f"数据库: {cls._config.database}"
        )

    @classmethod
    def _init_sentinel_client(cls, max_connections: int):
        """初始化 Sentinel 模式客户端"""
        try:
            from redis.asyncio.sentinel import Sentinel
        except ImportError:
            logging.error(
                "Sentinel 模式需要 redis>=4.2.0，请升级: pip install redis>=4.2.0")
            raise

        sentinel_config = cls._config.sentinel

        # 解析 Sentinel 节点地址
        # 格式: ["host1:port1", "host2:port2", ...]
        sentinel_hosts = []
        for node in sentinel_config.nodes:
            if ":" in node:
                host, port = node.rsplit(":", 1)
                sentinel_hosts.append((host, int(port)))
            else:
                sentinel_hosts.append((node, 26379))  # 默认 Sentinel 端口

        if not sentinel_hosts:
            raise ValueError("Sentinel 节点列表为空")

        # 创建 Sentinel 连接
        sentinel = Sentinel(
            sentinel_hosts,
            socket_timeout=cls._config.timeout,
            password=cls._config.password,  # Redis 密码
            decode_responses=True
        )

        # 获取主节点客户端
        cls._client = sentinel.master_for(
            sentinel_config.master,
            socket_timeout=cls._config.timeout,
            password=cls._config.password,
            db=cls._config.database,
            decode_responses=True
        )

        logging.info(
            f"RedisService 初始化成功（Sentinel 模式），主节点: {sentinel_config.master}, "
            f"Sentinel 节点: {sentinel_config.nodes}, 数据库: {cls._config.database}"
        )

    @classmethod
    async def _ensure_initialized(cls):
        """确保 Redis 已初始化"""
        if not cls._initialized or not cls._client:
            raise RuntimeError("RedisService 未初始化，请先调用 RedisService.init()")
        return cls._client

    @classmethod
    async def get(cls, key: str) -> Optional[str]:
        """
        获取值

        Args:
            key: 键名

        Returns:
            值，不存在返回 None
        """
        client = await cls._ensure_initialized()
        try:
            return await client.get(key)
        except Exception as e:
            logging.error(f"Redis GET 失败: {e}")
            return None

    @classmethod
    async def set(
        cls,
        key: str,
        value: Union[str, int, float],
        ex: Optional[int] = None,
        px: Optional[int] = None,
        nx: bool = False,
        xx: bool = False
    ) -> bool:
        """
        设置值

        Args:
            key: 键名
            value: 值
            ex: 过期时间（秒）
            px: 过期时间（毫秒）
            nx: 仅当键不存在时设置
            xx: 仅当键存在时设置

        Returns:
            是否设置成功
        """
        client = await cls._ensure_initialized()
        try:
            result = await client.set(
                key, value, ex=ex, px=px, nx=nx, xx=xx
            )
            return result is not None
        except Exception as e:
            logging.error(f"Redis SET 失败: {e}")
            return False

    @classmethod
    async def delete(cls, *keys: str) -> int:
        """
        删除键

        Args:
            keys: 键名列表

        Returns:
            删除的键数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.delete(*keys)
        except Exception as e:
            logging.error(f"Redis DELETE 失败: {e}")
            return 0

    @classmethod
    async def exists(cls, *keys: str) -> int:
        """
        检查键是否存在

        Args:
            keys: 键名列表

        Returns:
            存在的键数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.exists(*keys)
        except Exception as e:
            logging.error(f"Redis EXISTS 失败: {e}")
            return 0

    @classmethod
    async def expire(cls, key: str, seconds: int) -> bool:
        """
        设置过期时间

        Args:
            key: 键名
            seconds: 过期秒数

        Returns:
            是否设置成功
        """
        client = await cls._ensure_initialized()
        try:
            return await client.expire(key, seconds)
        except Exception as e:
            logging.error(f"Redis EXPIRE 失败: {e}")
            return False

    @classmethod
    async def ttl(cls, key: str) -> int:
        """
        获取剩余过期时间

        Args:
            key: 键名

        Returns:
            剩余秒数，-1 表示永不过期，-2 表示键不存在
        """
        client = await cls._ensure_initialized()
        try:
            return await client.ttl(key)
        except Exception as e:
            logging.error(f"Redis TTL 失败: {e}")
            return -2

    @classmethod
    async def incr(cls, key: str) -> int:
        """
        自增

        Args:
            key: 键名

        Returns:
            自增后的值
        """
        client = await cls._ensure_initialized()
        try:
            return await client.incr(key)
        except Exception as e:
            logging.error(f"Redis INCR 失败: {e}")
            raise

    @classmethod
    async def incrby(cls, key: str, amount: int) -> int:
        """
        自增指定值

        Args:
            key: 键名
            amount: 增量

        Returns:
            自增后的值
        """
        client = await cls._ensure_initialized()
        try:
            return await client.incrby(key, amount)
        except Exception as e:
            logging.error(f"Redis INCRBY 失败: {e}")
            raise

    @classmethod
    async def decr(cls, key: str) -> int:
        """
        自减

        Args:
            key: 键名

        Returns:
            自减后的值
        """
        client = await cls._ensure_initialized()
        try:
            return await client.decr(key)
        except Exception as e:
            logging.error(f"Redis DECR 失败: {e}")
            raise

    @classmethod
    async def hset(cls, name: str, key: str, value: Union[str, int, float]) -> int:
        """
        设置哈希字段

        Args:
            name: 哈希名
            key: 字段名
            value: 值

        Returns:
            新增字段数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.hset(name, key, value)
        except Exception as e:
            logging.error(f"Redis HSET 失败: {e}")
            return 0

    @classmethod
    async def hget(cls, name: str, key: str) -> Optional[str]:
        """
        获取哈希字段

        Args:
            name: 哈希名
            key: 字段名

        Returns:
            值
        """
        client = await cls._ensure_initialized()
        try:
            return await client.hget(name, key)
        except Exception as e:
            logging.error(f"Redis HGET 失败: {e}")
            return None

    @classmethod
    async def hgetall(cls, name: str) -> dict:
        """
        获取哈希所有字段

        Args:
            name: 哈希名

        Returns:
            字段字典
        """
        client = await cls._ensure_initialized()
        try:
            return await client.hgetall(name)
        except Exception as e:
            logging.error(f"Redis HGETALL 失败: {e}")
            return {}

    @classmethod
    async def hdel(cls, name: str, *keys: str) -> int:
        """
        删除哈希字段

        Args:
            name: 哈希名
            keys: 字段名列表

        Returns:
            删除的字段数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.hdel(name, *keys)
        except Exception as e:
            logging.error(f"Redis HDEL 失败: {e}")
            return 0

    @classmethod
    async def lpush(cls, name: str, *values: Union[str, int, float]) -> int:
        """
        从左侧插入列表

        Args:
            name: 列表名
            values: 值列表

        Returns:
            列表长度
        """
        client = await cls._ensure_initialized()
        try:
            return await client.lpush(name, *values)
        except Exception as e:
            logging.error(f"Redis LPUSH 失败: {e}")
            return 0

    @classmethod
    async def rpush(cls, name: str, *values: Union[str, int, float]) -> int:
        """
        从右侧插入列表

        Args:
            name: 列表名
            values: 值列表

        Returns:
            列表长度
        """
        client = await cls._ensure_initialized()
        try:
            return await client.rpush(name, *values)
        except Exception as e:
            logging.error(f"Redis RPUSH 失败: {e}")
            return 0

    @classmethod
    async def lpop(cls, name: str) -> Optional[str]:
        """
        从左侧弹出列表元素

        Args:
            name: 列表名

        Returns:
            弹出的值
        """
        client = await cls._ensure_initialized()
        try:
            return await client.lpop(name)
        except Exception as e:
            logging.error(f"Redis LPOP 失败: {e}")
            return None

    @classmethod
    async def rpop(cls, name: str) -> Optional[str]:
        """
        从右侧弹出列表元素

        Args:
            name: 列表名

        Returns:
            弹出的值
        """
        client = await cls._ensure_initialized()
        try:
            return await client.rpop(name)
        except Exception as e:
            logging.error(f"Redis RPOP 失败: {e}")
            return None

    @classmethod
    async def lrange(cls, name: str, start: int = 0, end: int = -1) -> list:
        """
        获取列表范围内的元素

        Args:
            name: 列表名
            start: 起始索引
            end: 结束索引

        Returns:
            元素列表
        """
        client = await cls._ensure_initialized()
        try:
            return await client.lrange(name, start, end)
        except Exception as e:
            logging.error(f"Redis LRANGE 失败: {e}")
            return []

    @classmethod
    async def llen(cls, name: str) -> int:
        """
        获取列表长度

        Args:
            name: 列表名

        Returns:
            列表长度
        """
        client = await cls._ensure_initialized()
        try:
            return await client.llen(name)
        except Exception as e:
            logging.error(f"Redis LLEN 失败: {e}")
            return 0

    @classmethod
    async def sadd(cls, name: str, *values: Union[str, int, float]) -> int:
        """
        添加集合成员

        Args:
            name: 集合名
            values: 值列表

        Returns:
            新增成员数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.sadd(name, *values)
        except Exception as e:
            logging.error(f"Redis SADD 失败: {e}")
            return 0

    @classmethod
    async def srem(cls, name: str, *values: Union[str, int, float]) -> int:
        """
        移除集合成员

        Args:
            name: 集合名
            values: 值列表

        Returns:
            移除成员数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.srem(name, *values)
        except Exception as e:
            logging.error(f"Redis SREM 失败: {e}")
            return 0

    @classmethod
    async def smembers(cls, name: str) -> set:
        """
        获取集合所有成员

        Args:
            name: 集合名

        Returns:
            成员集合
        """
        client = await cls._ensure_initialized()
        try:
            return await client.smembers(name)
        except Exception as e:
            logging.error(f"Redis SMEMBERS 失败: {e}")
            return set()

    @classmethod
    async def sismember(cls, name: str, value: Union[str, int, float]) -> bool:
        """
        检查是否是集合成员

        Args:
            name: 集合名
            value: 值

        Returns:
            是否是成员
        """
        client = await cls._ensure_initialized()
        try:
            return await client.sismember(name, value)
        except Exception as e:
            logging.error(f"Redis SISMEMBER 失败: {e}")
            return False

    @classmethod
    async def zadd(cls, name: str, mapping: dict) -> int:
        """
        添加有序集合成员

        Args:
            name: 有序集合名
            mapping: 成员-分数映射

        Returns:
            新增成员数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.zadd(name, mapping)
        except Exception as e:
            logging.error(f"Redis ZADD 失败: {e}")
            return 0

    @classmethod
    async def zrange(cls, name: str, start: int, end: int, withscores: bool = False) -> list:
        """
        获取有序集合范围内的成员

        Args:
            name: 有序集合名
            start: 起始索引
            end: 结束索引
            withscores: 是否包含分数

        Returns:
            成员列表
        """
        client = await cls._ensure_initialized()
        try:
            return await client.zrange(name, start, end, withscores=withscores)
        except Exception as e:
            logging.error(f"Redis ZRANGE 失败: {e}")
            return []

    @classmethod
    async def zrem(cls, name: str, *values: str) -> int:
        """
        移除有序集合成员

        Args:
            name: 有序集合名
            values: 成员列表

        Returns:
            移除成员数量
        """
        client = await cls._ensure_initialized()
        try:
            return await client.zrem(name, *values)
        except Exception as e:
            logging.error(f"Redis ZREM 失败: {e}")
            return 0

    @classmethod
    async def zscore(cls, name: str, value: str) -> Optional[float]:
        """
        获取有序集合成员的分数

        Args:
            name: 有序集合名
            value: 成员

        Returns:
            分数
        """
        client = await cls._ensure_initialized()
        try:
            return await client.zscore(name, value)
        except Exception as e:
            logging.error(f"Redis ZSCORE 失败: {e}")
            return None

    @classmethod
    async def keys(cls, pattern: str = "*") -> list:
        """
        获取匹配的所有键

        Args:
            pattern: 匹配模式

        Returns:
            键列表
        """
        client = await cls._ensure_initialized()
        try:
            return await client.keys(pattern)
        except Exception as e:
            logging.error(f"Redis KEYS 失败: {e}")
            return []

    @classmethod
    async def ping(cls) -> bool:
        """
        测试连接

        Returns:
            是否连接成功
        """
        client = await cls._ensure_initialized()
        try:
            result = await client.ping()
            return result
        except Exception as e:
            logging.error(f"Redis PING 失败: {e}")
            return False

    @classmethod
    async def execute_command(cls, *args, **kwargs) -> Any:
        """
        执行原始 Redis 命令

        Args:
            args: 命令参数
            kwargs: 命令关键字参数

        Returns:
            命令结果
        """
        client = await cls._ensure_initialized()
        try:
            return await client.execute_command(*args, **kwargs)
        except Exception as e:
            logging.error(f"Redis 命令执行失败: {e}")
            raise

    @classmethod
    def get_client(cls) -> Optional[Any]:
        """
        获取原始 Redis 客户端

        Returns:
            Redis 客户端实例
        """
        return cls._client

    @classmethod
    async def close(cls):
        """关闭 Redis 连接"""
        if cls._client:
            try:
                await cls._client.close()
                logging.info("RedisService 连接已关闭")
            except Exception as e:
                logging.error(f"关闭 Redis 连接失败: {e}")
            finally:
                cls._client = None
                cls._initialized = False

    @classmethod
    def is_initialized(cls) -> bool:
        """检查是否已初始化"""
        return cls._initialized
