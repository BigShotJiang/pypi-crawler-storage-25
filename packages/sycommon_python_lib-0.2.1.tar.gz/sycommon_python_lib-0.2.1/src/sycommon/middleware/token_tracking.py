# -*- coding: utf-8 -*-
"""
Token 统计中间件

基于 AgentMiddleware 协议，在每次模型调用后自动统计 Token 使用量并写入 MySQL。
适用于 deep_agent 和 multi_agent_team，兼容 FastAPI 多 worker 环境。
"""

from collections.abc import Awaitable, Callable
from typing import Any, Optional

from langchain.agents.middleware.types import (
    AgentMiddleware,
    AgentState,
    ContextT,
    ModelRequest,
    ModelResponse,
    ResponseT,
)
from langchain_core.messages import AIMessage
from langgraph.runtime import Runtime

from sycommon.logging.kafka_log import SYLogger
from sycommon.tools.merge_headers import get_header_value


class TokenTrackingMiddleware(AgentMiddleware):
    """
    Token 使用量统计中间件

    通过 awrap_model_call 钩子拦截模型调用，从 ModelResponse.result 中
    提取 AIMessage 的 usage_metadata，记录到 MySQL。

    同时通过 aafter_model 兜底：从 state["messages"] 中提取（部分模型在
    流式模式下 usage_metadata 会延迟到 state 更新后才可用）。

    支持 FastAPI 多 worker：底层 TokenUsageMySQLService 使用线程安全缓冲 + 定期刷盘。
    """

    def __init__(self, model_name: Optional[str] = None, user_id: Optional[str] = None):
        """
        Args:
            model_name: 模型名称（用于记录，可选）
            user_id: 用户ID（优先使用，比从请求头获取更可靠）
        """
        self._model_name = model_name
        self._user_id = user_id

    @property
    def name(self) -> str:
        return "TokenTrackingMiddleware"

    def _get_user_id(self) -> Optional[str]:
        """获取用户 ID（优先使用构造函数传入的，否则从请求头获取）"""
        if self._user_id:
            return self._user_id
        userid = get_header_value(SYLogger.get_headers(), "x-userid-header")
        return userid if userid else None

    def _get_tenant_id(self) -> Optional[str]:
        """从请求头获取租户 ID"""
        return get_header_value(SYLogger.get_headers(), "x-tenant-header")

    def _extract_and_record(self, messages: list) -> bool:
        """从消息列表中提取 token 使用量并同步记录，返回是否成功"""
        for msg in reversed(messages):
            if isinstance(msg, AIMessage):
                usage_meta = getattr(msg, "usage_metadata", None)
                if usage_meta:
                    return self._record_usage(usage_meta)
                break
        return False

    def _record_usage(self, usage_meta: dict) -> bool:
        """记录 token 使用量，返回是否有效"""
        input_tokens = usage_meta.get("input_tokens", 0)
        output_tokens = usage_meta.get("output_tokens", 0)
        if input_tokens == 0 and output_tokens == 0:
            return False

        try:
            from sycommon.llm.token_usage_mysql_service import TokenUsageMySQLService
            TokenUsageMySQLService.record_sync(
                user_id=self._get_user_id(),
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                model=self._model_name,
                tenant_id=self._get_tenant_id(),
            )
            SYLogger.debug(
                f"[TokenTracking] input={input_tokens}, output={output_tokens}"
            )
            return True
        except Exception as e:
            SYLogger.warning(f"[TokenTracking] 记录失败: {e}")
            return False

    async def _record_usage_async(self, usage_meta: dict):
        """异步记录 token 使用量"""
        input_tokens = usage_meta.get("input_tokens", 0)
        output_tokens = usage_meta.get("output_tokens", 0)
        if input_tokens == 0 and output_tokens == 0:
            return

        try:
            from sycommon.llm.token_usage_mysql_service import TokenUsageMySQLService
            await TokenUsageMySQLService.record(
                user_id=self._get_user_id(),
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                model=self._model_name,
                tenant_id=self._get_tenant_id(),
            )
            SYLogger.debug(
                f"[TokenTracking] input={input_tokens}, output={output_tokens}"
            )
        except Exception as e:
            SYLogger.warning(f"[TokenTracking] 记录失败: {e}")

    async def awrap_model_call(
        self,
        request: ModelRequest[ContextT],
        handler: Callable[
            [ModelRequest[ContextT]], Awaitable[ModelResponse[ResponseT]]
        ],
    ) -> ModelResponse[ResponseT]:
        """
        拦截模型调用，从返回的 ModelResponse 中提取 usage_metadata。
        这是最可靠的方式——ModelResponse.result 包含完整的 AIMessage（含 usage_metadata）。
        """
        response = await handler(request)

        # 从 ModelResponse.result 中提取
        if hasattr(response, "result") and response.result:
            for msg in response.result:
                if isinstance(msg, AIMessage):
                    usage_meta = getattr(msg, "usage_metadata", None)
                    if usage_meta:
                        await self._record_usage_async(usage_meta)
                    else:
                        SYLogger.debug(
                            f"[TokenTracking] awrap_model_call: usage_metadata=None, "
                            f"msg_type={type(msg).__name__}, "
                            f"response_metadata={getattr(msg, 'response_metadata', None)}"
                        )
                    break

        return response

    async def aafter_model(
        self, state: AgentState, runtime: Runtime
    ) -> dict[str, Any] | None:
        """
        兜底：从 state["messages"] 中提取 token 使用量。
        某些模型在流式模式下，usage_metadata 可能只在 state 更新后才可用，
        而不在 ModelResponse.result 中。
        """
        messages = state.get("messages", [])
        if not messages:
            return None

        # 从后往前找最新的 AIMessage
        for msg in reversed(messages):
            if isinstance(msg, AIMessage):
                usage_meta = getattr(msg, "usage_metadata", None)
                if usage_meta:
                    input_tokens = usage_meta.get("input_tokens", 0)
                    output_tokens = usage_meta.get("output_tokens", 0)
                    if input_tokens > 0 or output_tokens > 0:
                        await self._record_usage_async(usage_meta)
                break

        return None
