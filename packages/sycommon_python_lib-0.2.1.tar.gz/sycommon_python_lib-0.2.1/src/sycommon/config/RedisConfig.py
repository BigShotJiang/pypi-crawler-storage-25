from pydantic import BaseModel, Field
from typing import Optional, List
import re


class RedisPoolConfig(BaseModel):
    """Redis 连接池配置（对应 Spring Lettuce Pool）"""
    max_active: int = Field(default=50, description="最大活跃连接数")
    max_idle: int = Field(default=10, description="最大空闲连接数")
    max_wait: int = Field(default=30, description="最大等待时间（秒）")
    min_idle: int = Field(default=1, description="最小空闲连接数")


class RedisSentinelConfig(BaseModel):
    """Redis Sentinel 配置"""
    master: str = Field(..., description="主节点名称")
    nodes: List[str] = Field(default_factory=list, description="Sentinel 节点列表")
    topology_refresh_interval: Optional[int] = Field(default=None, description="拓扑刷新间隔（秒）")

    @classmethod
    def from_dict(cls, sentinel: dict) -> "RedisSentinelConfig":
        """从字典解析 Sentinel 配置"""
        nodes_str = sentinel.get("nodes", "")
        # 解析节点列表，支持逗号分隔
        nodes = []
        if nodes_str:
            nodes = [n.strip() for n in nodes_str.split(",") if n.strip()]

        # 解析拓扑刷新间隔
        topology_refresh_interval = None
        topology_refresh = sentinel.get("topologyRefresh", {})
        if topology_refresh:
            interval = topology_refresh.get("interval")
            if interval:
                topology_refresh_interval = RedisConfig._parse_duration(interval)

        return cls(
            master=sentinel.get("master", "mymaster"),
            nodes=nodes,
            topology_refresh_interval=topology_refresh_interval
        )


class RedisConfig(BaseModel):
    """Redis 配置（对应 Spring Redis YAML 格式）"""
    host: str = Field(default="localhost", description="Redis 主机地址")
    port: int = Field(default=6379, description="Redis 端口")
    password: Optional[str] = Field(default=None, description="密码")
    database: int = Field(default=0, description="数据库索引")
    timeout: int = Field(default=60, description="超时时间（秒）")
    pool: Optional[RedisPoolConfig] = Field(default=None, description="连接池配置")
    sentinel: Optional[RedisSentinelConfig] = Field(default=None, description="Sentinel 配置")

    @classmethod
    def from_spring_yaml(cls, config: dict) -> "RedisConfig":
        """
        从 Spring Redis YAML 格式解析配置

        支持两种模式：
        1. 单机模式：配置 host/port
        2. Sentinel 模式：配置 sentinel.master/nodes

        Args:
            config: Spring Redis 配置字典

        Returns:
            RedisConfig 实例
        """
        # 获取 spring.redis 配置
        spring_config = config.get("spring", {})
        redis_config = spring_config.get("redis", {})

        if not redis_config:
            raise ValueError("未找到 Spring Redis 配置")

        # 解析超时时间（支持 "60s" 格式）
        timeout = redis_config.get("timeout", 60)
        if isinstance(timeout, str):
            timeout = cls._parse_duration(timeout)

        # 解析连接池配置
        pool_config = None
        lettuce = redis_config.get("lettuce", {})
        pool = lettuce.get("pool", {})
        if pool:
            max_wait = pool.get("max-wait", 30)
            if isinstance(max_wait, str):
                max_wait = cls._parse_duration(max_wait)

            pool_config = RedisPoolConfig(
                max_active=pool.get("max-active", 50),
                max_idle=pool.get("max-idle", 10),
                max_wait=max_wait,
                min_idle=pool.get("min-idle", 1)
            )

        # 解析 Sentinel 配置
        sentinel_config = None
        sentinel = redis_config.get("sentinel", {})
        if sentinel and sentinel.get("master") and sentinel.get("nodes"):
            sentinel_config = RedisSentinelConfig.from_dict(sentinel)

        return cls(
            host=redis_config.get("host", "localhost"),
            port=redis_config.get("port", 6379),
            password=redis_config.get("password"),
            database=redis_config.get("database", 0),
            timeout=timeout,
            pool=pool_config,
            sentinel=sentinel_config
        )

    @staticmethod
    def _parse_duration(duration: str) -> int:
        """
        解析持续时间字符串为秒数

        Args:
            duration: 持续时间字符串，如 "60s", "30s", "1m"

        Returns:
            秒数
        """
        if not duration:
            return 60

        if isinstance(duration, (int, float)):
            return int(duration)

        # 匹配数字和单位
        match = re.match(r"(\d+)([smh]?)", str(duration).strip())
        if not match:
            return 60

        value = int(match.group(1))
        unit = match.group(2) or "s"

        if unit == "s":
            return value
        elif unit == "m":
            return value * 60
        elif unit == "h":
            return value * 3600

        return value

    @property
    def is_sentinel_mode(self) -> bool:
        """是否为 Sentinel 模式"""
        return self.sentinel is not None and len(self.sentinel.nodes) > 0
