"""
认证模块

提供 LDAP 域账号登录认证、企微-LDAP 用户关联功能。

LDAP 认证示例::

    from sycommon.auth import LDAPAuthService, LDAPConfig

    config = LDAPConfig.from_config()
    auth_service = LDAPAuthService(config)
    result = await auth_service.authenticate("username", "password")

企微-LDAP 关联示例::

    from sycommon.auth import WeComLDAPService

    service = WeComLDAPService()
    user = await service.get_user_info("0633")
    if user.matched and user.ldap_user:
        print(user.ldap_user.email)
"""

from sycommon.auth.ldap_service import (
    LDAPConfig,
    LDAPAuthService,
    LDAPUser,
    LDAPAuthResult,
)
from sycommon.auth.wecom_ldap_service import (
    WeComConfig,
    WeComLDAPService,
    WeComLDAPUser,
    LDAPFullUser,
)

__all__ = [
    "LDAPConfig",
    "LDAPAuthService",
    "LDAPUser",
    "LDAPAuthResult",
    "WeComConfig",
    "WeComLDAPService",
    "WeComLDAPUser",
    "LDAPFullUser",
]
