"""
Token 使用量记录服务（MySQL版本）
按用户+系统+日期维度聚合存储，每个人每天每个系统只保留一条记录

使用独立的数据库连接（llm 配置中的数据库），与业务系统数据库隔离

性能优化：进程内内存聚合 + 定时批量刷盘
  - 每次 LLM 调用只写入内存缓冲区（O(1)，无 IO）
  - 每 5 秒或缓冲区达到阈值时，合并为一条 SQL 刷盘
  - 多 worker 下每进程独立聚合，DB 写入频率从 N次/秒 降至 0.2次/秒
"""
import asyncio
import logging
import os
import threading
from collections import defaultdict
from datetime import datetime, date
from typing import Optional, Dict, Any, List

from sqlalchemy import select
from sqlalchemy.dialects.mysql import insert

from sycommon.config.Config import SingletonMeta, Config
from sycommon.logging.kafka_log import SYLogger
from sycommon.database.token_usage_db_service import TokenUsageDBService
from sycommon.models.token_usage_mysql import TokenUsageMySQL

logger = SYLogger

# 当前 worker 标识
_WORKER_ID = f"{os.getpid()}"


class _TokenBuffer:
    """进程内 Token 聚合缓冲区（线程安全）"""

    def __init__(self):
        self._lock = threading.Lock()
        # key: (user_id, service_name, system_env, usage_date)
        # value: {"input_tokens": int, "output_tokens": int, "model": str, "tenant_id": str}
        self._buffer: Dict[tuple, Dict[str, Any]] = defaultdict(
            lambda: {"input_tokens": 0, "output_tokens": 0, "model": None, "tenant_id": None}
        )

    def add(
        self,
        user_id: str,
        service_name: str,
        system_env: str,
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        tenant_id: Optional[str] = None,
    ):
        """聚合一条 token 记录到内存（线程安全，无 IO）"""
        today = date.today()
        key = (user_id, service_name, system_env, today)
        with self._lock:
            entry = self._buffer[key]
            entry["input_tokens"] += input_tokens
            entry["output_tokens"] += output_tokens
            if model:
                entry["model"] = model
            if tenant_id:
                entry["tenant_id"] = tenant_id

    def drain(self) -> Dict[tuple, Dict[str, Any]]:
        """清空并返回当前缓冲区所有数据"""
        with self._lock:
            data = dict(self._buffer)
            self._buffer.clear()
        return data

    def put_back(self, data: Dict[tuple, Dict[str, Any]]):
        """将一批数据批量放回缓冲区（线程安全，仅一次加锁）"""
        with self._lock:
            for key, entry in data.items():
                if key in self._buffer:
                    self._buffer[key]["input_tokens"] += entry["input_tokens"]
                    self._buffer[key]["output_tokens"] += entry["output_tokens"]
                else:
                    self._buffer[key] = entry.copy()

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._buffer)


class TokenUsageMySQLService(metaclass=SingletonMeta):
    """Token 使用量记录服务（MySQL异步版本）

    使用独立的数据库连接，连接到 shengye_platform_ai_middleware 库
    配置来源：Config().config.get("llm", {}).get("spring", {}).get("datasource", {})

    写入策略：内存聚合 + 定时批量刷盘
    """

    _initialized: bool = False
    _db_service: Optional[TokenUsageDBService] = None
    _service_name: Optional[str] = None
    _system_env: Optional[str] = None

    # 内存聚合
    _buffer: _TokenBuffer = _TokenBuffer()
    _flush_interval: float = 5.0  # 刷盘间隔（秒）
    _flush_threshold: int = 200   # 缓冲区条目阈值（预留，暂未使用）
    _flush_timeout: float = 10.0  # 单次刷盘超时（秒）
    _flush_thread: Optional[threading.Thread] = None
    _flush_loop_event: Optional[asyncio.AbstractEventLoop] = None
    _init_lock = threading.Lock()

    # 连续失败降频：连续 flush 失败时自动拉长间隔，最大 60 秒
    _consecutive_failures: int = 0
    _MAX_BACKOFF_INTERVAL: float = 60.0
    _MAX_BACKOFF_EXPONENT: int = 4  # 2^4=16, 16*5=80s > 60s, 更大无意义

    def __init__(self):
        pass

    @classmethod
    def _load_service_info(cls):
        """加载服务信息（延迟加载，确保 Config 已加载）"""
        if cls._service_name is not None and cls._system_env is not None:
            return

        try:
            config = Config().config
            if cls._service_name is None:
                service_name = config.get('Name', None)
                if service_name:
                    cls._service_name = service_name
                    logging.info(
                        f"TokenUsageMySQLService 加载 service_name: {cls._service_name}")

            if cls._system_env is None:
                env = config.get('Nacos', {}).get('namespaceId', None)
                if env:
                    cls._system_env = env
                    logging.info(
                        f"TokenUsageMySQLService 加载 system_env: {cls._system_env}")

        except Exception as e:
            logging.warning(f"获取服务信息失败: {e}")

    @classmethod
    def init(cls):
        """初始化 Token 记录服务"""
        with cls._init_lock:
            if cls._initialized:
                return

            cls._load_service_info()

            try:
                cls._db_service = TokenUsageDBService()
                if cls._db_service.init():
                    cls._initialized = True
                    logging.info(
                        f"TokenUsageMySQLService 初始化成功 (worker={_WORKER_ID})")
                    # 启动定时刷盘（独立线程）
                    cls._start_flush_loop()
                else:
                    logging.warning("TokenUsageMySQLService 初始化失败: 数据库服务未就绪")
            except Exception as e:
                logging.warning(f"TokenUsageMySQLService 初始化失败: {e}")

    @classmethod
    def _start_flush_loop(cls):
        """启动独立线程运行 flush，与主服务 event loop 完全隔离"""
        if cls._flush_thread and cls._flush_thread.is_alive():
            return
        cls._flush_thread = threading.Thread(
            target=cls._run_flush_in_thread,
            daemon=True,
            name="token-flush"
        )
        cls._flush_thread.start()
        logging.info(f"Token flush 线程已启动 (worker={_WORKER_ID})")

    @classmethod
    def _run_flush_in_thread(cls):
        """在独立线程中运行 flush loop"""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        cls._flush_loop_event = loop
        try:
            loop.run_until_complete(cls._flush_loop())
        except Exception as e:
            logging.error(f"Token flush 线程异常退出: {e}", exc_info=True)
        finally:
            loop.close()

    @classmethod
    async def _flush_loop(cls):
        """定时刷盘循环（连续失败时自动降频）"""
        while cls._initialized:
            try:
                # 动态间隔：连续失败时指数退避，上限 60s
                exponent = min(cls._consecutive_failures, cls._MAX_BACKOFF_EXPONENT)
                interval = min(
                    cls._flush_interval * (2 ** exponent),
                    cls._MAX_BACKOFF_INTERVAL
                )
                await asyncio.sleep(interval)
                await cls._flush_to_db()
            except asyncio.CancelledError:
                # 关闭时刷盘一次
                await cls._flush_to_db()
                break
            except Exception as e:
                logging.error(f"Token 刷盘循环异常: {e}", exc_info=True)

    @classmethod
    async def _flush_to_db(cls) -> int:
        """将缓冲区数据批量写入数据库（单 session + 超时保护）

        所有 entry 共用一个 session 和事务，减少 DB 往返。
        整体超时保护防止 MySQL 慢响应拖垮主服务。

        Returns:
            成功写入的条目数
        """
        data = cls._buffer.drain()
        if not data:
            return 0

        if not cls._db_service:
            logging.warning("TokenUsageMySQLService: DB 未就绪，丢弃缓冲区数据")
            return 0

        count = 0
        try:
            async with asyncio.timeout(cls._flush_timeout):
                async with cls._db_service.session() as session:
                    for key, entry in data.items():
                        user_id, service_name, system_env, usage_date = key
                        try:
                            today = date.today()
                            input_tokens = entry["input_tokens"]
                            output_tokens = entry["output_tokens"]
                            total = input_tokens + output_tokens
                            model = entry.get("model")
                            tenant_id = entry.get("tenant_id")

                            stmt = insert(TokenUsageMySQL).values(
                                user_id=user_id or '',
                                tenant_id=tenant_id,
                                service_name=service_name or '',
                                system_env=system_env or '',
                                input_tokens=input_tokens,
                                output_tokens=output_tokens,
                                total_tokens=total,
                                model=model,
                                usage_date=today
                            )
                            stmt = stmt.on_duplicate_key_update(
                                input_tokens=TokenUsageMySQL.input_tokens + input_tokens,
                                output_tokens=TokenUsageMySQL.output_tokens + output_tokens,
                                total_tokens=TokenUsageMySQL.total_tokens + total,
                                model=model,
                                updated_at=datetime.now()
                            )
                            await session.execute(stmt)
                            count += 1
                        except Exception as e:
                            logging.error(f"Token 刷盘写入失败 key={key}: {e}", exc_info=True)

            # 成功：重置连续失败计数
            cls._consecutive_failures = 0

        except TimeoutError:
            cls._consecutive_failures += 1
            # 将失败的数据批量放回缓冲区（一次加锁），下次 flush 重试
            cls._buffer.put_back(data)
            exponent = min(cls._consecutive_failures, cls._MAX_BACKOFF_EXPONENT)
            next_interval = min(
                cls._flush_interval * (2 ** exponent),
                cls._MAX_BACKOFF_INTERVAL
            )
            logging.warning(
                f"Token 刷盘超时（{cls._flush_timeout}s），{len(data)} 条数据退回缓冲区"
                f"（连续失败 {cls._consecutive_failures} 次，下次间隔 {next_interval:.0f}s）"
            )
        except Exception as e:
            cls._consecutive_failures += 1
            # 将失败的数据批量放回缓冲区（一次加锁），下次 flush 重试
            cls._buffer.put_back(data)
            logging.error(f"Token 刷盘异常: {e}（连续失败 {cls._consecutive_failures} 次，数据已退回缓冲区）", exc_info=True)

        if count > 0:
            logging.debug(f"Token 刷盘完成: {count} 条")
        return count

    # ─── 写入接口（写入内存，不直接写 DB） ───

    @classmethod
    def record_sync(
        cls,
        user_id: Optional[str],
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        trace_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> bool:
        """记录 Token 使用量（写入内存缓冲区，定时刷盘）

        Args:
            user_id: 用户ID
            input_tokens: 输入 token 数量
            output_tokens: 输出 token 数量
            model: 模型名称
            trace_id: 链路追踪ID（兼容参数，未使用）
            tenant_id: 租户ID
            service_name: 服务名称
            system_env: 系统环境

        Returns:
            bool: 是否成功写入缓冲区
        """
        if not cls._initialized:
            cls.init()

        if not cls._initialized:
            return False

        cls._load_service_info()

        if service_name is None:
            service_name = cls._service_name
        if system_env is None:
            system_env = cls._system_env

        user_id = user_id or ''
        service_name = service_name or ''
        system_env = system_env or ''

        cls._buffer.add(
            user_id=user_id,
            service_name=service_name,
            system_env=system_env,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model=model,
            tenant_id=tenant_id,
        )

        # 达到阈值时，由定时刷盘线程在下一周期处理
        # 不再在调用方线程中主动触发 flush，避免阻塞主服务

        return True

    @classmethod
    async def record(
        cls,
        user_id: Optional[str],
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        trace_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> bool:
        """异步记录 Token 使用量（写入内存缓冲区，定时刷盘）"""
        return cls.record_sync(
            user_id=user_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model=model,
            trace_id=trace_id,
            tenant_id=tenant_id,
            service_name=service_name,
            system_env=system_env,
        )

    # ─── 关闭 ───

    @classmethod
    async def flush(cls) -> int:
        """手动触发刷盘（服务关闭时调用）"""
        return await cls._flush_to_db()

    @classmethod
    async def shutdown(cls):
        """关闭服务：停止循环 + 刷盘"""
        with cls._init_lock:
            cls._initialized = False
            if cls._flush_loop_event and not cls._flush_loop_event.is_closed():
                # 在 flush 线程的 loop 中安排最终刷盘
                future = asyncio.run_coroutine_threadsafe(
                    cls._flush_to_db(), cls._flush_loop_event)
                try:
                    future.result(timeout=10)
                except Exception as e:
                    logging.error(f"关闭时刷盘失败: {e}")
                cls._flush_loop_event.call_soon_threadsafe(
                    cls._flush_loop_event.stop)

    # ─── 查询接口（无变化，直接透传到 DB） ───

    @classmethod
    async def get_user_daily_usage(
        cls,
        user_id: str,
        usage_date: Optional[date] = None,
        service_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> Dict[str, Any]:
        """查询用户某天的 Token 使用量"""
        if not cls._db_service:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            if usage_date is None:
                usage_date = date.today()

            async with cls._db_service.session() as session:
                conditions = [
                    TokenUsageMySQL.user_id == user_id,
                    TokenUsageMySQL.usage_date == usage_date
                ]

                if service_name:
                    conditions.append(TokenUsageMySQL.service_name == service_name)
                if tenant_id:
                    conditions.append(TokenUsageMySQL.tenant_id == tenant_id)
                if system_env:
                    conditions.append(TokenUsageMySQL.system_env == system_env)

                stmt = select(TokenUsageMySQL).where(*conditions)
                result = await session.execute(stmt)
                record = result.scalar_one_or_none()

                if record:
                    return {
                        "input_tokens": record.input_tokens,
                        "output_tokens": record.output_tokens,
                        "total_tokens": record.total_tokens,
                        "model": record.model,
                        "service_name": record.service_name,
                        "system_env": record.system_env,
                        "date": record.usage_date.isoformat()
                    }
                else:
                    return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        except Exception as e:
            logging.error(f"查询用户日 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    async def get_user_usage(
        cls,
        user_id: str,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        service_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> Dict[str, Any]:
        """查询用户 Token 使用量统计（跨天聚合）"""
        if not cls._db_service:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            async with cls._db_service.session() as session:
                conditions = [TokenUsageMySQL.user_id == user_id]

                if service_name:
                    conditions.append(TokenUsageMySQL.service_name == service_name)
                if tenant_id:
                    conditions.append(TokenUsageMySQL.tenant_id == tenant_id)
                if system_env:
                    conditions.append(TokenUsageMySQL.system_env == system_env)
                if start_date:
                    conditions.append(TokenUsageMySQL.usage_date >= start_date)
                if end_date:
                    conditions.append(TokenUsageMySQL.usage_date <= end_date)

                stmt = select(TokenUsageMySQL).where(*conditions)
                result = await session.execute(stmt)
                records = result.scalars().all()

                total_input = sum(r.input_tokens for r in records)
                total_output = sum(r.output_tokens for r in records)
                total_tokens = sum(r.total_tokens for r in records)

                return {
                    "input_tokens": total_input,
                    "output_tokens": total_output,
                    "total_tokens": total_tokens,
                    "days": len(records)
                }

        except Exception as e:
            logging.error(f"查询用户 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    async def get_usage(
        cls,
        user_id: Optional[str] = None,
        service_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        system_env: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        group_by_user: bool = False,
        group_by_service: bool = False,
        group_by_tenant: bool = False,
        group_by_env: bool = False,
        limit: int = 100
    ) -> Dict[str, Any]:
        """通用查询 Token 使用量统计"""
        if not cls._db_service:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            async with cls._db_service.session() as session:
                conditions = []

                if user_id:
                    conditions.append(TokenUsageMySQL.user_id == user_id)
                if service_name:
                    conditions.append(TokenUsageMySQL.service_name == service_name)
                if tenant_id:
                    conditions.append(TokenUsageMySQL.tenant_id == tenant_id)
                if system_env:
                    conditions.append(TokenUsageMySQL.system_env == system_env)
                if start_date:
                    conditions.append(TokenUsageMySQL.usage_date >= start_date)
                if end_date:
                    conditions.append(TokenUsageMySQL.usage_date <= end_date)

                stmt = select(TokenUsageMySQL)
                if conditions:
                    stmt = stmt.where(*conditions)

                result = await session.execute(stmt)
                records = result.scalars().all()

                total_input = sum(r.input_tokens for r in records)
                total_output = sum(r.output_tokens for r in records)
                total_tokens = sum(r.total_tokens for r in records)

                response = {
                    "input_tokens": total_input,
                    "output_tokens": total_output,
                    "total_tokens": total_tokens
                }

                if group_by_user:
                    user_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.user_id or "unknown"
                        if key not in user_stats:
                            user_stats[key] = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        user_stats[key]["input_tokens"] += r.input_tokens
                        user_stats[key]["output_tokens"] += r.output_tokens
                        user_stats[key]["total_tokens"] += r.total_tokens

                    response["by_user"] = [
                        {"user_id": uid, **stats}
                        for uid, stats in sorted(user_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                if group_by_service:
                    service_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.service_name or "unknown"
                        if key not in service_stats:
                            service_stats[key] = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        service_stats[key]["input_tokens"] += r.input_tokens
                        service_stats[key]["output_tokens"] += r.output_tokens
                        service_stats[key]["total_tokens"] += r.total_tokens

                    response["by_service"] = [
                        {"service_name": svc, **stats}
                        for svc, stats in sorted(service_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                if group_by_tenant:
                    tenant_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.tenant_id or "unknown"
                        if key not in tenant_stats:
                            tenant_stats[key] = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        tenant_stats[key]["input_tokens"] += r.input_tokens
                        tenant_stats[key]["output_tokens"] += r.output_tokens
                        tenant_stats[key]["total_tokens"] += r.total_tokens

                    response["by_tenant"] = [
                        {"tenant_id": tid, **stats}
                        for tid, stats in sorted(tenant_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                if group_by_env:
                    env_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.system_env or "unknown"
                        if key not in env_stats:
                            env_stats[key] = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        env_stats[key]["input_tokens"] += r.input_tokens
                        env_stats[key]["output_tokens"] += r.output_tokens
                        env_stats[key]["total_tokens"] += r.total_tokens

                    response["by_env"] = [
                        {"system_env": env, **stats}
                        for env, stats in sorted(env_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                return response

        except Exception as e:
            logging.error(f"查询 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    async def query_usage(
        cls,
        user_ids: Optional[List[str]] = None,
        service_names: Optional[List[str]] = None,
        tenant_ids: Optional[List[str]] = None,
        system_envs: Optional[List[str]] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        group_by: Optional[List[str]] = None,
        include_details: bool = False,
        order_by: str = "total_tokens",
        order_desc: bool = True,
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """灵活查询 Token 使用量统计"""
        if not cls._db_service:
            return {
                "total": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
                "groups": [],
                "details": []
            }

        valid_group_fields = {"user_id", "service_name",
                              "tenant_id", "system_env", "date"}
        if group_by:
            group_by = [g for g in group_by if g in valid_group_fields]

        try:
            async with cls._db_service.session() as session:
                conditions = []

                if user_ids:
                    if len(user_ids) == 1:
                        conditions.append(TokenUsageMySQL.user_id == user_ids[0])
                    else:
                        conditions.append(TokenUsageMySQL.user_id.in_(user_ids))

                if service_names:
                    if len(service_names) == 1:
                        conditions.append(TokenUsageMySQL.service_name == service_names[0])
                    else:
                        conditions.append(TokenUsageMySQL.service_name.in_(service_names))

                if tenant_ids:
                    if len(tenant_ids) == 1:
                        conditions.append(TokenUsageMySQL.tenant_id == tenant_ids[0])
                    else:
                        conditions.append(TokenUsageMySQL.tenant_id.in_(tenant_ids))

                if system_envs:
                    if len(system_envs) == 1:
                        conditions.append(TokenUsageMySQL.system_env == system_envs[0])
                    else:
                        conditions.append(TokenUsageMySQL.system_env.in_(system_envs))

                if start_date:
                    conditions.append(TokenUsageMySQL.usage_date >= start_date)
                if end_date:
                    conditions.append(TokenUsageMySQL.usage_date <= end_date)

                stmt = select(TokenUsageMySQL)
                if conditions:
                    stmt = stmt.where(*conditions)

                result = await session.execute(stmt)
                records = result.scalars().all()

                total_input = sum(r.input_tokens for r in records)
                total_output = sum(r.output_tokens for r in records)
                total_tokens = sum(r.total_tokens for r in records)

                response = {
                    "total": {
                        "input_tokens": total_input,
                        "output_tokens": total_output,
                        "total_tokens": total_tokens,
                        "record_count": len(records)
                    },
                    "groups": [],
                    "details": []
                }

                if group_by:
                    group_stats: Dict[tuple, Dict] = {}

                    for r in records:
                        key_parts = []
                        for g in group_by:
                            if g == "date":
                                key_parts.append(r.usage_date.isoformat())
                            elif g == "user_id":
                                key_parts.append(r.user_id or "unknown")
                            elif g == "service_name":
                                key_parts.append(r.service_name or "unknown")
                            elif g == "tenant_id":
                                key_parts.append(r.tenant_id or "unknown")
                            elif g == "system_env":
                                key_parts.append(r.system_env or "unknown")

                        key = tuple(key_parts)

                        if key not in group_stats:
                            group_stats[key] = {
                                "input_tokens": 0,
                                "output_tokens": 0,
                                "total_tokens": 0,
                                "record_count": 0
                            }
                            for i, g in enumerate(group_by):
                                group_stats[key][g] = key_parts[i]

                        group_stats[key]["input_tokens"] += r.input_tokens
                        group_stats[key]["output_tokens"] += r.output_tokens
                        group_stats[key]["total_tokens"] += r.total_tokens
                        group_stats[key]["record_count"] += 1

                    def get_sort_value(item):
                        return item[1].get(order_by, 0)

                    sorted_groups = sorted(
                        group_stats.items(),
                        key=get_sort_value,
                        reverse=order_desc
                    )

                    paginated = sorted_groups[offset:offset + limit]
                    response["groups"] = [stats for _, stats in paginated]
                    response["total_groups"] = len(group_stats)

                if include_details:
                    details = []
                    for r in records:
                        details.append({
                            "user_id": r.user_id,
                            "tenant_id": r.tenant_id,
                            "service_name": r.service_name,
                            "system_env": r.system_env,
                            "input_tokens": r.input_tokens,
                            "output_tokens": r.output_tokens,
                            "total_tokens": r.total_tokens,
                            "model": r.model,
                            "usage_date": r.usage_date.isoformat(),
                            "updated_at": r.updated_at.isoformat() if r.updated_at else None
                        })

                    if order_by in details[0] if details else {}:
                        details.sort(key=lambda x: x.get(
                            order_by, 0), reverse=order_desc)

                    response["details"] = details[offset:offset + limit]

                return response

        except Exception as e:
            logging.error(f"查询 Token 使用量失败: {e}", exc_info=True)
            return {
                "total": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
                "groups": [],
                "details": []
            }

    @classmethod
    async def get_user_stats(
        cls,
        user_id: str,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """查询指定用户的 Token 使用统计（按服务分组）"""
        return await cls.query_usage(
            user_ids=[user_id],
            start_date=start_date,
            end_date=end_date,
            group_by=["service_name"],
            order_by="total_tokens",
            order_desc=True
        )

    @classmethod
    async def get_service_stats(
        cls,
        service_name: str,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """查询指定服务的 Token 使用统计（按用户分组）"""
        return await cls.query_usage(
            service_names=[service_name],
            start_date=start_date,
            end_date=end_date,
            group_by=["user_id"],
            order_by="total_tokens",
            order_desc=True
        )
