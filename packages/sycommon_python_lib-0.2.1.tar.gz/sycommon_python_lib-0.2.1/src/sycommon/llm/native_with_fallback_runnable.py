# -*- coding: utf-8 -*-
"""
原生模式 + 降级修正 Runnable

第一次使用原生 with_structured_output，失败后降级到修正逻辑。
"""

import json
import re
from typing import Type, Optional, Any

from pydantic import BaseModel, ValidationError
from langchain_core.language_models import BaseChatModel
from langchain_core.runnables import Runnable, RunnableConfig
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.messages import HumanMessage


class NativeWithFallbackRunnable(Runnable):
    """
    原生模式 + 降级修正 Runnable

    第一次使用原生 with_structured_output，失败后降级到修正逻辑。
    """

    def __init__(
        self,
        native_runnable: Runnable,
        llm: BaseChatModel,
        output_model: Type[BaseModel],
        max_retries: int = 3
    ):
        super().__init__()
        self.native_runnable = native_runnable
        self.llm = llm
        self.output_model = output_model
        self.max_retries = max_retries
        self.parser = PydanticOutputParser(pydantic_object=output_model)

    def _try_parse_result(self, result) -> BaseModel:
        """尝试将结果转换为 Pydantic 模型"""
        if isinstance(result, self.output_model):
            return result

        if isinstance(result, dict):
            return self.output_model(**result)

        if isinstance(result, str):
            processed = self._process_content(result)
            data = json.loads(processed)
            return self.output_model(**data)

        raise ValueError(f"无法将结果转换为 {self.output_model.__name__}")

    def _process_content(self, content: str) -> str:
        """处理内容"""
        content = content.strip("```json").strip("```").strip()
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            content = json_match.group(0)
        content = content.replace("None", "null").replace("none", "null").replace("NONE", "null")
        content = content.replace('"', '"').replace('"', '"')
        return content

    def _extract_content(self, response) -> str:
        """从 LLM 响应中提取文本内容"""
        if hasattr(response, 'content'):
            return response.content
        return str(response)

    def _request_fix(self, messages: list, failed_output: str, error_message: str, config=None) -> str:
        """请求 LLM 修正输出"""
        fix_prompt = f"""上一次输出解析失败，请根据错误信息修正后重新输出。

**重要提示**：
1. 必须严格按照指定的 JSON schema 输出
2. 不能遗漏任何必需字段（required fields）
3. 不能添加 schema 中未定义的字段
4. 字段类型必须匹配（字符串、数字、列表、对象等）

错误信息：
{error_message}

上一次输出：
{failed_output}

输出格式，请严格按照以下 JSON schema 输出，不要输出任何多余内容：
{self.parser.get_format_instructions()}"""

        fix_messages = messages + [HumanMessage(content=fix_prompt)]
        response = self.llm.invoke(fix_messages, config=config)
        return self._extract_content(response)

    async def _arequest_fix(self, messages: list, failed_output: str, error_message: str, config=None) -> str:
        """异步请求 LLM 修正输出"""
        fix_prompt = f"""上一次输出解析失败，请根据错误信息修正后重新输出。

**重要提示**：
1. 必须严格按照指定的 JSON schema 输出
2. 不能遗漏任何必需字段（required fields）
3. 不能添加 schema 中未定义的字段
4. 字段类型必须匹配（字符串、数字、列表、对象等）

错误信息：
{error_message}

上一次输出：
{failed_output}

输出格式，请严格按照以下 JSON schema 输出，不要输出任何多余内容：
{self.parser.get_format_instructions()}"""

        fix_messages = messages + [HumanMessage(content=fix_prompt)]
        response = await self.llm.ainvoke(fix_messages, config=config)
        return self._extract_content(response)

    def invoke(self, input: Any, config: Optional[RunnableConfig] = None) -> BaseModel:
        """同步调用"""
        messages = input if isinstance(input, list) else input.get("messages", [])
        last_error = None
        last_content = None

        for attempt in range(self.max_retries):
            try:
                if attempt == 0:
                    # 第一次：使用原生 runnable
                    result = self.native_runnable.invoke(input, config=config)
                    return self._try_parse_result(result)
                else:
                    # 修正模式
                    from sycommon.logging.kafka_log import SYLogger
                    SYLogger.warning(f"[Native降级修正] 第 {attempt} 次尝试，错误: {last_error}")

                    last_content = self._request_fix(
                        messages, last_content or "", str(last_error), config
                    )
                    processed = self._process_content(last_content)
                    try:
                        result = self.parser.parse(processed)
                        return result
                    except Exception:
                        data = json.loads(processed)
                        return self.output_model(**data)

            except (ValidationError, json.JSONDecodeError, ValueError, TypeError) as e:
                last_error = e
                from sycommon.logging.kafka_log import SYLogger
                if attempt == 0:
                    try:
                        last_content = str(result) if 'result' in dir() else ""
                    except:
                        last_content = ""
                    SYLogger.warning(f"[Native降级修正] 原生模式失败，降级到修正模式: {e}")

                if attempt == self.max_retries - 1:
                    raise ValueError(f"经过 {self.max_retries} 次尝试仍无法解析: {last_error}")

        raise ValueError("未知错误")

    async def ainvoke(self, input: Any, config: Optional[RunnableConfig] = None) -> BaseModel:
        """异步调用"""
        messages = input if isinstance(input, list) else input.get("messages", [])
        last_error = None
        last_content = None

        for attempt in range(self.max_retries):
            try:
                if attempt == 0:
                    # 第一次：使用原生 runnable
                    result = await self.native_runnable.ainvoke(input, config=config)
                    return self._try_parse_result(result)
                else:
                    # 修正模式
                    from sycommon.logging.kafka_log import SYLogger
                    SYLogger.warning(f"[Native降级修正] 第 {attempt} 次尝试，错误: {last_error}")

                    last_content = await self._arequest_fix(
                        messages, last_content or "", str(last_error), config
                    )
                    processed = self._process_content(last_content)
                    try:
                        result = self.parser.parse(processed)
                        return result
                    except Exception:
                        data = json.loads(processed)
                        return self.output_model(**data)

            except (ValidationError, json.JSONDecodeError, ValueError, TypeError) as e:
                last_error = e
                from sycommon.logging.kafka_log import SYLogger
                if attempt == 0:
                    try:
                        last_content = str(result) if 'result' in dir() else ""
                    except:
                        last_content = ""
                    SYLogger.warning(f"[Native降级修正] 原生模式失败，降级到修正模式: {e}")

                if attempt == self.max_retries - 1:
                    raise ValueError(f"经过 {self.max_retries} 次尝试仍无法解析: {last_error}")

        raise ValueError("未知错误")
