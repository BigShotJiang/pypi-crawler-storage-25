# -*- coding: utf-8 -*-
"""
结构化输出自动修正 Runnable

当 JSON 解析失败时，自动将错误信息和原始输出发送给 LLM 请求修正。
类似于 LangChain 旧版的 OutputFixingParser 功能。
"""

import json
import re
from typing import Type, Optional, Any

from pydantic import BaseModel, ValidationError
from langchain_core.language_models import BaseChatModel
from langchain_core.runnables import Runnable, RunnableConfig
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.messages import HumanMessage


class OutputFixingRunnable(Runnable):
    """
    结构化输出自动修正 Runnable

    特点：
    - 当解析失败时，自动将错误信息和原始输出发送给 LLM 请求修正
    - 支持自定义最大重试次数
    - 自动处理常见的 JSON 格式问题（中文引号、代码块标记等）

    适用场景：
    - 输出偶尔格式错误
    - 需要稳定可靠的 JSON 解析
    """

    def __init__(
        self,
        base_chain: Runnable,
        llm: BaseChatModel,
        output_model: Type[BaseModel],
        max_retries: int = 3
    ):
        super().__init__()
        self.base_chain = base_chain
        self.llm = llm
        self.output_model = output_model
        self.max_retries = max_retries
        self.parser = PydanticOutputParser(pydantic_object=output_model)

    def invoke(self, input: Any, config: Optional[RunnableConfig] = None) -> BaseModel:
        """同步调用"""
        # 获取 LLM 响应（通过 base_chain，包含 prompt）
        response = self.base_chain.invoke(input, config=config)
        content = self._extract_content(response)

        last_error = None
        last_content = content

        for attempt in range(self.max_retries):
            try:
                # 处理内容并尝试解析
                processed = self._process_content(last_content)
                # 先尝试直接用 PydanticOutputParser 解析
                try:
                    result = self.parser.parse(processed)
                    return result
                except Exception:
                    # 如果失败，尝试用 json.loads 解析后再实例化
                    data = json.loads(processed)
                    result = self.output_model(**data)
                    return result
            except (ValidationError, json.JSONDecodeError, ValueError, TypeError) as e:
                last_error = e
                from sycommon.logging.kafka_log import SYLogger
                SYLogger.warning(f"[OutputFixing] 第 {attempt + 1} 次解析失败: {e}")

                if attempt < self.max_retries - 1:
                    # 请求 LLM 修正
                    last_content = self._request_fix(
                        original_input=input,
                        failed_output=last_content,
                        error_message=str(e),
                        config=config
                    )

        raise ValueError(f"经过 {self.max_retries} 次尝试仍无法解析: {last_error}")

    async def ainvoke(self, input: Any, config: Optional[RunnableConfig] = None) -> BaseModel:
        """异步调用"""
        # 获取 LLM 响应（通过 base_chain，包含 prompt）
        response = await self.base_chain.ainvoke(input, config=config)
        content = self._extract_content(response)

        last_error = None
        last_content = content

        for attempt in range(self.max_retries):
            try:
                # 处理内容并尝试解析
                processed = self._process_content(last_content)
                # 先尝试直接用 PydanticOutputParser 解析
                try:
                    result = self.parser.parse(processed)
                    return result
                except Exception:
                    # 如果失败，尝试用 json.loads 解析后再实例化
                    data = json.loads(processed)
                    result = self.output_model(**data)
                    return result
            except (ValidationError, json.JSONDecodeError, ValueError, TypeError) as e:
                last_error = e
                from sycommon.logging.kafka_log import SYLogger
                SYLogger.warning(f"[OutputFixing] 第 {attempt + 1} 次解析失败: {e}")

                if attempt < self.max_retries - 1:
                    # 请求 LLM 修正
                    last_content = await self._arequest_fix(
                        original_input=input,
                        failed_output=last_content,
                        error_message=str(e),
                        config=config
                    )

        raise ValueError(f"经过 {self.max_retries} 次尝试仍无法解析: {last_error}")

    def _extract_content(self, response) -> str:
        """从 LLM 响应中提取文本内容"""
        if hasattr(response, 'content'):
            return response.content
        return str(response)

    def _process_content(self, content: str) -> str:
        """处理内容（移除代码块标记、规范化 JSON）"""
        # 移除 markdown 代码块标记
        content = content.strip("```json").strip("```").strip()

        # 尝试提取 JSON 对象（处理前后有多余文本的情况）
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            content = json_match.group(0)

        # 规范化 null 值
        content = content.replace("None", "null").replace(
            "none", "null").replace("NONE", "null")

        # 规范化中文引号为英文引号（只处理键和字符串值外部的引号）
        content = content.replace('"', '"').replace('"', '"')

        # 处理单引号（谨慎处理，只替换明显不是内容中的单引号）
        # 不再简单替换所有单引号为双引号，因为这可能破坏内容

        return content

    def _request_fix(
        self,
        original_input: Any,
        failed_output: str,
        error_message: str,
        config: Optional[RunnableConfig] = None
    ) -> str:
        """请求 LLM 修正输出"""
        fix_prompt = f"""上一次输出解析失败，请根据错误信息修正后重新输出。

**重要提示**：
1. 必须严格按照指定的 JSON schema 输出
2. 不能遗漏任何必需字段（required fields）
3. 不能添加 schema 中未定义的字段
4. 字段类型必须匹配（字符串、数字、列表、对象等）

错误信息：
{error_message}

上一次输出：
{failed_output}

输出格式，请严格按照以下 JSON schema 输出，不要输出任何多余内容：
{self.parser.get_format_instructions()}"""

        # 提取原始消息
        messages = original_input.get("messages", []) if isinstance(
            original_input, dict) else []
        fix_messages = messages + [HumanMessage(content=fix_prompt)]

        response = self.llm.invoke(fix_messages, config=config)
        return self._extract_content(response)

    async def _arequest_fix(
        self,
        original_input: Any,
        failed_output: str,
        error_message: str,
        config: Optional[RunnableConfig] = None
    ) -> str:
        """异步请求 LLM 修正输出"""
        fix_prompt = f"""上一次输出解析失败，请根据错误信息修正后重新输出。

**重要提示**：
1. 必须严格按照指定的 JSON schema 输出
2. 不能遗漏任何必需字段（required fields）
3. 不能添加 schema 中未定义的字段
4. 字段类型必须匹配（字符串、数字、列表、对象等）

错误信息：
{error_message}

上一次输出：
{failed_output}

输出格式，请严格按照以下 JSON schema 输出，不要输出任何多余内容：
{self.parser.get_format_instructions()}"""

        # 提取原始消息
        messages = original_input.get("messages", []) if isinstance(
            original_input, dict) else []
        fix_messages = messages + [HumanMessage(content=fix_prompt)]

        response = await self.llm.ainvoke(fix_messages, config=config)
        return self._extract_content(response)
