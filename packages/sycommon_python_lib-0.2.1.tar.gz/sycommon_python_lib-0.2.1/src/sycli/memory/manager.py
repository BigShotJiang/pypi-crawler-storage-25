"""记忆管理器 - 协调热/温/全记忆层级。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from langchain_core.language_models import BaseChatModel

from sycli.memory.compressor import compress_memory, count_tokens, deep_compress_memory
from sycli.core.display import warning
from sycli.memory.full import FullMemory
from sycli.memory.hot import HotMemory
from sycli.memory.warm import WarmMemory


class MemoryManager:
    """协调三层记忆。

    第 0+1 层（热记忆）: 约 4K tokens，每轮刷新
    第 2 层（温记忆）: 约 13K tokens，每 5 轮压缩
    第 3 层（全记忆）: 无限原始归档，从不加载到上下文
    """

    def __init__(
        self,
        memory_dir: Path,
        project_name: str,
        llm: BaseChatModel,
        hot_budget: int = 4000,
        warm_budget: int = 13000,
        compress_threshold: float = 0.8,
    ):
        self.project_dir = memory_dir / project_name
        self.llm = llm
        self._compress_threshold = compress_threshold

        self.hot = HotMemory(
            path=self.project_dir / "hot" / "context.md",
            token_budget=hot_budget,
        )
        self.warm = WarmMemory(
            warm_dir=self.project_dir / "warm",
            token_budget=warm_budget,
        )
        self.full = FullMemory(
            full_dir=self.project_dir / "full",
        )

        # 从层级预算派生的压缩预算
        self._compress_budget = hot_budget
        self._deep_compress_budget = warm_budget

        # 确保目录存在
        for d in [
            self.project_dir / "hot",
            self.project_dir / "warm" / "agents",
            self.project_dir / "full" / "agents",
            self.project_dir / "full" / "episodes",
        ]:
            d.mkdir(parents=True, exist_ok=True)

    def get_sources_for_agent(self, agent_name: str) -> list[str]:
        """获取 agent 的有序记忆源路径。

        这些路径会传递给 MemoryMiddleware.sources。
        顺序: 热 → 温/agent → 温/策略 → 温/反面模式
        """
        project_name = self.project_dir.name
        return [
            f".sycli/memory/{project_name}/hot/context.md",
            f".sycli/memory/{project_name}/warm/agents/{agent_name}.md",
            f".sycli/memory/{project_name}/warm/strategies.md",
            f".sycli/memory/{project_name}/warm/anti_patterns.md",
        ]

    def after_round(
        self,
        round_data: dict,
        compress: bool = False,
        deep_compress: bool = False,
    ) -> None:
        """在一轮结束后更新所有记忆层级。

        Args:
            round_data: 轮次执行结果。
            compress: 是否运行常规压缩（每 N 轮）。
            deep_compress: 是否运行深度压缩（每 N 轮）。
        """
        # 1. 保存完整的原始轮次记录
        self.full.save_episode(round_data)

        # 2. 更新团队全记忆
        round_num = round_data.get("round", round_data.get("round_number", 0))
        score = round_data.get("score", 0)
        self.full.append_team_full(
            f"第 {round_num} 轮: 得分={score:.3f}, 决策={round_data.get('decision', 'UNKNOWN')}"
        )

        # 3. 刷新热记忆
        self.hot.refresh(
            round_number=round_num,
            current_score=score,
            task_description=round_data.get("task", ""),
            strategy=round_data.get("strategy", "auto"),
            recent_rounds=round_data.get("recent_rounds", []),
            active_warnings=round_data.get("warnings", []),
        )

        # 4. 用轮次特定经验更新 agent 温记忆
        agent_rewards = round_data.get("agent_rewards", {})
        agent_summaries = round_data.get("agent_summaries", {})
        for agent_name, reward in agent_rewards.items():
            sign = "+" if reward >= 0 else ""
            summary = agent_summaries.get(agent_name, "")
            entry = f"第 {round_num} 轮: 奖励={sign}{reward:.2f} | {summary}"
            self.warm.append_agent_memory(agent_name, entry)
            # 同时写入每个 agent 的全记忆
            self.full.append_agent_full(agent_name, entry)

        # 5. 从失败中更新反面模式
        test_result = round_data.get("test_result")
        if test_result and test_result.get("failed", 0) > 0:
            decision = round_data.get("decision", "")
            strategy = round_data.get("strategy", "")
            self.warm.append_anti_pattern(
                f"第 {round_num} 轮: {test_result['failed']} 个失败 "
                f"(决策={decision}, 策略={strategy})"
            )

        # 5b. 在温记忆中记录策略效果
        strategy = round_data.get("strategy", "")
        strategy_outcome = round_data.get("strategy_outcome", "")
        if strategy:
            entry = (
                f"第 {round_num} 轮: 策略={strategy}, "
                f"结果={strategy_outcome}, 得分={score:.3f}"
            )
            self.warm.append_strategy_log(entry)

        # 6. 执行记忆预算限制 - 超出预算时裁剪
        if not self.warm.is_within_budget():
            self._trim_warm_memory()

        # 7. 基于阈值的压缩：使用量达到预算的 threshold% 时触发压缩
        warm_usage_ratio = self.warm.total_tokens() / self.warm.token_budget if self.warm.token_budget > 0 else 0.0
        threshold_triggered = warm_usage_ratio >= self._compress_threshold

        if deep_compress:
            self._deep_compress_safe()
        elif compress or threshold_triggered:
            self._compress_safe()

    def _run_async_safely(self, coro):
        """在任意上下文中安全运行异步协程。

        如果在异步事件循环内，则创建新线程。
        如果不在，则直接使用 asyncio.run()。
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # 在异步事件循环内 — 在单独的线程中运行
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result(timeout=60)
        else:
            return asyncio.run(coro)

    def _compress_safe(self) -> None:
        """常规压缩：最近 5 轮 → 更新温记忆。"""
        recent_text = self.full.get_recent_episodes_text(n=5)

        try:
            compressed = self._run_async_safely(
                compress_memory(self.llm, recent_text, token_budget=self._compress_budget)
            )
            if compressed and len(compressed) > 50:
                self.warm.update_strategies(compressed)
        except Exception as e:
            warning(f"记忆压缩失败（尽力执行）: {e}")

    def _deep_compress_safe(self) -> None:
        """深度压缩：温 + 全 → 重建温记忆（保留反面模式）。"""
        warm_text = self.warm.read_strategies() + "\n" + self.warm.read_anti_patterns()
        recent_text = self.full.get_recent_episodes_text(n=10)

        try:
            compressed = self._run_async_safely(
                deep_compress_memory(self.llm, warm_text, recent_text, token_budget=self._deep_compress_budget)
            )
            if compressed and len(compressed) > 50:
                self.warm.update_strategies(compressed)
                # 保留反面模式 — 深度压缩输出只写入策略
        except Exception as e:
            warning(f"深度记忆压缩失败（尽力执行）: {e}")

    def _trim_warm_memory(self) -> None:
        """裁剪温记忆文件以保持在预算内。

        通过丢弃最旧的条目来保留最新的条目。
        """
        while not self.warm.is_within_budget():
            # 裁剪 agent 记忆（丢弃最旧的条目）
            trimmed_any = False
            for f in self.warm.agents_dir.glob("*.md"):
                content = f.read_text()
                lines = content.split("\n")
                # 查找条目（标题后由空行分隔）
                if len(lines) > 10:
                    # 丢弃最旧的条目（标题部分之后）
                    # 找到第一个非标题、非空行的块并移除
                    in_header = True
                    first_entry_start = None
                    for i, line in enumerate(lines):
                        if in_header and not line.startswith("#") and line.strip():
                            in_header = False
                        if not in_header and line.strip() and first_entry_start is None:
                            first_entry_start = i
                        if first_entry_start is not None and not line.strip():
                            # 移除此条目块
                            end = i
                            lines = lines[:first_entry_start] + lines[end:]
                            f.write_text("\n".join(lines))
                            trimmed_any = True
                            break
                if trimmed_any:
                    break

            # 如果无法裁剪 agent 记忆，尝试反面模式
            if not trimmed_any:
                ap_path = self.warm.warm_dir / "anti_patterns.md"
                if ap_path.exists():
                    content = ap_path.read_text()
                    lines = content.split("\n")
                    if len(lines) > 5:
                        # 移除第一个非标题行块
                        for i, line in enumerate(lines):
                            if not line.startswith("#") and line.strip():
                                end = i
                                while end < len(lines) and lines[end].strip():
                                    end += 1
                                lines = lines[:i] + lines[end:]
                                ap_path.write_text("\n".join(lines))
                                trimmed_any = True
                                break

            if not trimmed_any:
                break  # 无法进一步裁剪
