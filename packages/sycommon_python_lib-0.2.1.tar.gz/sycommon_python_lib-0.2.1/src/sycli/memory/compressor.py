"""记忆压缩器 - 基于 LLM 的记忆蒸馏。"""

from __future__ import annotations

import tiktoken
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage

COMPRESS_SYSTEM_PROMPT = """你是一个记忆蒸馏引擎。你的任务是将原始优化历史压缩为简洁、可操作的知识。

## 输入
你将收到原始优化轮次数据。

## 输出规则
1. 提取关键模式：哪些策略有效，哪些失败
2. 只保留最重要的发现
3. 目标：保持在指定的 token 预算内
4. 格式：使用简洁的 markdown 列表
5. 优先级：高奖励策略 > 反面模式 > 项目事实

## 输出格式
```markdown
## 策略（按有效性排序）
- [策略] → 平均奖励: X（使用 N 次）

## 反面模式（应避免的做法）
- [模式] → 原因

## 项目知识
- [关于代码库的关键事实]
```
"""

DEEP_COMPRESS_SYSTEM_PROMPT = """你是一个深度记忆整合引擎。你负责合并和去重积累的知识。

## 输入
你将收到温记忆（已压缩）和最近的轮次数据。

## 任务
1. 移除重复条目
2. 用新数据更新策略排名
3. 合并相关发现
4. 移除过时条目（保留最新版本）
5. 只保留 TOP-5 策略、TOP-10 反面模式、TOP-5 项目事实

## 输出
使用相同的 markdown 格式，但更加整合和精炼。
"""


def count_tokens(text: str, model: str = "cl100k_base") -> int:
    """统计文本中的 token 数量。

    由于 tiktoken 编码不能准确覆盖 GLM 模型，
    使用基于字符的启发式方法。
    """
    try:
        enc = tiktoken.get_encoding(model)
        return len(enc.encode(text))
    except Exception:
        # 回退：中文/混合内容约 3 个字符 = 1 个 token
        return max(1, len(text) // 3)


async def compress_memory(
    llm: BaseChatModel,
    raw_content: str,
    token_budget: int = 4000,
) -> str:
    """使用 LLM 将原始记忆内容压缩为简洁知识。

    Args:
        llm: 用于压缩的 LLM 实例。
        raw_content: 要压缩的原始轮次/记忆内容。
        token_budget: 压缩输出的目标 token 数。

    Returns:
        压缩后的记忆内容。
    """
    response = await llm.ainvoke(
        [
            SystemMessage(content=COMPRESS_SYSTEM_PROMPT),
            HumanMessage(content=f"Token 预算: {token_budget}\n\n原始内容:\n---\n{raw_content}\n\n压缩:"),
        ]
    )

    # 对输出执行预算限制
    result = response.content
    token_count = count_tokens(result)
    if token_count > token_budget * 1.2:
        # 严重超出预算时硬截断
        char_limit = int(len(result) * token_budget / token_count)
        result = result[:char_limit] + "\n... (已截断至预算内)"
    return result


async def deep_compress_memory(
    llm: BaseChatModel,
    warm_content: str,
    recent_episodes: str,
    token_budget: int = 6000,
) -> str:
    """深度压缩：将温记忆与最近轮次合并。

    Args:
        llm: LLM 实例。
        warm_content: 当前温记忆内容。
        recent_episodes: 要合并的最近轮次数据。
        token_budget: 目标 token 数。

    Returns:
        整合后的记忆内容。
    """
    response = await llm.ainvoke(
        [
            SystemMessage(content=DEEP_COMPRESS_SYSTEM_PROMPT),
            HumanMessage(
                content=(
                    f"Token 预算: {token_budget}\n\n"
                    f"## 当前温记忆\n---\n{warm_content}\n\n"
                    f"## 最近轮次\n---\n{recent_episodes}\n\n"
                    f"整合并压缩:"
                )
            ),
        ]
    )

    # 对输出执行预算限制
    result = response.content
    token_count = count_tokens(result)
    if token_count > token_budget * 1.2:
        char_limit = int(len(result) * token_budget / token_count)
        result = result[:char_limit] + "\n... (已截断至预算内)"
    return result
