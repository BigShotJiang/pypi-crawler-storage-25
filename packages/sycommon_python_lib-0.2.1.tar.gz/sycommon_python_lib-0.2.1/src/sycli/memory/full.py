"""全记忆 - 第 3 层完整原始归档（无限大小，从不加载到上下文）。

存储在 .sycli/memory/{project}/full/
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path


class FullMemory:
    """第 3 层：磁盘上的完整原始记忆。

    从不加载到 agent 上下文。用于：
    - 压缩源材料
    - 历史查询
    - 审计追踪
    """

    def __init__(self, full_dir: Path):
        self.full_dir = full_dir
        self.episodes_dir = full_dir / "episodes"
        self.agents_dir = full_dir / "agents"
        self.episodes_dir.mkdir(parents=True, exist_ok=True)
        self.agents_dir.mkdir(parents=True, exist_ok=True)

    def save_episode(self, episode: dict) -> Path:
        """保存完整的轮次记录。"""
        round_num = episode.get("round_number", episode.get("round", 0))
        path = self.episodes_dir / f"ep_{round_num:03d}.json"
        if "timestamp" not in episode:
            episode["timestamp"] = datetime.now().isoformat()
        path.write_text(json.dumps(episode, indent=2, ensure_ascii=False))
        return path

    def load_episode(self, round_number: int) -> dict | None:
        """加载指定的轮次记录。"""
        path = self.episodes_dir / f"ep_{round_number:03d}.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    def list_episodes(self) -> list[dict]:
        """按顺序列出所有轮次记录。"""
        episodes = []
        for f in sorted(self.episodes_dir.glob("ep_*.json")):
            try:
                episodes.append(json.loads(f.read_text()))
            except Exception:
                continue
        return episodes

    def append_agent_full(self, agent_name: str, entry: str) -> None:
        """向 agent 的全记忆追加原始条目。"""
        path = self.agents_dir / f"{agent_name}_full.md"
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        with open(path, "a") as f:
            f.write(f"\n## [{timestamp}]\n{entry}\n")

    def append_team_full(self, entry: str) -> None:
        """向团队全记忆追加原始条目。"""
        path = self.full_dir / "TEAM_FULL.md"
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        with open(path, "a") as f:
            f.write(f"\n## [{timestamp}]\n{entry}\n")

    def get_recent_episodes_text(self, n: int = 5) -> str:
        """获取最近 N 轮的文本内容（用于压缩）。"""
        episodes = self.list_episodes()[-n:]
        if not episodes:
            return "（暂无轮次记录）"
        return json.dumps(episodes, indent=2, ensure_ascii=False)
