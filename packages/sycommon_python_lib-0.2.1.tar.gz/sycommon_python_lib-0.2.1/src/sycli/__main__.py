"""Allow running sycli as `python -m sycli`."""

from sycli.cli import main

if __name__ == "__main__":
    main()
