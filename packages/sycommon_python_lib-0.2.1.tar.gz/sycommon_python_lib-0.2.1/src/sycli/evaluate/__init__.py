"""sycli API evaluation package."""
