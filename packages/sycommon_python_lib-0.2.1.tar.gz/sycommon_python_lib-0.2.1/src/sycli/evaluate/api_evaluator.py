"""API-level multi-node evaluator.

Starts a service, calls an SSE endpoint, compares actual results against
ground truth, and computes per-node accuracy for the RL reward loop.

Uses aiohttp for all HTTP calls (async-native).
"""

from __future__ import annotations

import asyncio
import json
import re
import signal
import subprocess
import time
from pathlib import Path
from typing import Any

import aiohttp
from pydantic import BaseModel

from sycli.core.display import error, info, success, warning
from sycli.models.config_models import EvaluationSettings, SycliConfig


# ── Models ──


class NodeScore(BaseModel):
    """Per-node evaluation score."""

    node_name: str
    fields_total: int
    fields_correct: int
    accuracy: float  # fields_correct / fields_total
    details: dict[str, bool]  # field_path -> correct/incorrect


class EvaluationResult(BaseModel):
    """Full API evaluation result."""

    node_scores: dict[str, NodeScore]
    aggregate_accuracy: float  # weighted average
    total_fields: int
    total_correct: int
    service_started: bool
    api_response_received: bool


# ── Dot-path accessor ──


def _get_by_dotpath(data: Any, path: str) -> Any:
    """Navigate a nested dict/list by dot-path.

    Examples:
        _get_by_dotpath(d, "main_contracts[0].contractNo")
        _get_by_dotpath(d, "industry")
        _get_by_dotpath(d, "[0].price_with_tax")  # when data is a list
    """
    parts = path.split(".")
    current = data
    for part in parts:
        idx_match = re.match(r"^(.*?)\[(\d+)\]$", part)
        if idx_match:
            key, idx = idx_match.group(1), int(idx_match.group(2))
            if key:
                if isinstance(current, dict) and key in current:
                    current = current[key]
                else:
                    return None
            if isinstance(current, list) and idx < len(current):
                current = current[idx]
            else:
                return None
        else:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
    return current


def _match_value(actual: str, expected: str, mode: str) -> bool:
    """Compare actual vs expected using the given match mode."""
    actual_str = str(actual)
    expected_str = str(expected)

    if mode == "exact":
        return actual_str == expected_str
    elif mode == "contains":
        return expected_str in actual_str
    elif mode == "regex":
        return bool(re.search(expected_str, actual_str))
    elif mode == "status":
        return actual_str == expected_str
    return actual_str == expected_str


# ── Service management ──


async def start_service(config: EvaluationSettings, project_root: Path) -> subprocess.Popen | None:
    """Start the backend service as a background subprocess.

    Returns the process handle, or None on failure.
    """
    if not config.service_startup:
        info("No service_startup command configured, skipping service start")
        return None

    info(f"Starting service: {config.service_startup}")
    try:
        proc = subprocess.Popen(
            config.service_startup,
            shell=True,
            cwd=str(project_root),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=lambda: signal.signal(signal.SIGINT, signal.SIG_IGN),
        )
    except Exception as e:
        error(f"Failed to start service: {e}")
        return None

    # Wait for health check
    if config.service_health_url:
        deadline = time.time() + config.service_startup_timeout
        async with aiohttp.ClientSession() as session:
            while time.time() < deadline:
                try:
                    async with session.get(
                        config.service_health_url,
                        timeout=aiohttp.ClientTimeout(total=5),
                    ) as resp:
                        if resp.status < 500:
                            success(f"Service is healthy ({resp.status})")
                            return proc
                except Exception:
                    pass
                await asyncio.sleep(2)

        error(f"Service did not become healthy within {config.service_startup_timeout}s")
        stop_service(proc)
        return None
    else:
        # No health URL — just wait a fixed 5s and hope
        await asyncio.sleep(5)
        return proc


def stop_service(process: subprocess.Popen | None) -> None:
    """Stop the service subprocess gracefully."""
    if process is None:
        return
    info("Stopping service...")
    try:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
    except Exception as e:
        warning(f"Error stopping service: {e}")


# ── SSE API call ──


def _parse_endpoint(endpoint: str) -> tuple[str, str]:
    """Parse 'POST http://...' into (method, url)."""
    parts = endpoint.strip().split(None, 1)
    if len(parts) == 2:
        return parts[0].upper(), parts[1]
    return "GET", parts[0]


async def _retry_request(fn, max_retries: int = 3, base_delay: float = 2.0):
    """Retry an async callable with exponential backoff for transient errors."""
    for attempt in range(max_retries):
        try:
            return await fn()
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            if attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt)
            warning(f"Request failed (attempt {attempt+1}/{max_retries}), retrying in {delay:.1f}s: {e}")
            await asyncio.sleep(delay)
    return None


async def call_api_sse(config: EvaluationSettings, request_body: dict) -> list[dict]:
    """Call the SSE endpoint and collect all events.

    Returns a list of parsed JSON event dicts.
    """
    method, url = _parse_endpoint(config.endpoint)
    method = method.lower()

    events: list[dict] = []

    try:
        async def _do_stream():
            collected = []
            timeout = aiohttp.ClientTimeout(total=config.sse_timeout)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.request(
                    method,
                    url,
                    json=request_body,
                    headers=config.request_headers,
                ) as resp:
                    resp.raise_for_status()

                    event_data = ""
                    event_id = ""
                    async for raw_line in resp.content:
                        line = raw_line.decode("utf-8", errors="replace").rstrip("\n").rstrip("\r")

                        if line.startswith("id:"):
                            event_id = line[len("id:"):].strip()
                        elif line.startswith("data:"):
                            data_str = line[len("data:"):].strip()
                            if data_str:
                                try:
                                    parsed = json.loads(data_str)
                                    collected.append(parsed)
                                except json.JSONDecodeError:
                                    event_data += data_str
                        elif line.startswith("event:"):
                            pass
                        elif line.startswith(":"):
                            pass
                        elif line.strip() == "":
                            if event_data:
                                try:
                                    parsed = json.loads(event_data)
                                    collected.append(parsed)
                                except json.JSONDecodeError:
                                    pass
                                event_data = ""
                            if event_id == "end":
                                break
                            event_id = ""
            return collected

        events = await _retry_request(_do_stream, max_retries=3, base_delay=2.0) or []

    except asyncio.TimeoutError:
        error(f"SSE request timed out after {config.sse_timeout}s (all retries exhausted)")
    except aiohttp.ClientResponseError as e:
        error(f"API returned HTTP {e.status}")
    except aiohttp.ClientConnectorError:
        error(f"Cannot connect to API endpoint: {url}")
    except Exception as e:
        error(f"API call failed: {e}")

    return events


async def call_api_json(config: EvaluationSettings, request_body: dict) -> dict | None:
    """Call a non-SSE JSON endpoint and return the response dict.

    Used as a fallback when the endpoint is not SSE.
    """
    method, url = _parse_endpoint(config.endpoint)
    try:
        async def _do_request():
            timeout = aiohttp.ClientTimeout(total=config.sse_timeout)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.request(
                    method.lower(),
                    url,
                    json=request_body,
                    headers=config.request_headers,
                ) as resp:
                    resp.raise_for_status()
                    return await resp.json()

        return await _retry_request(_do_request, max_retries=3, base_delay=2.0)
    except (aiohttp.ClientError, asyncio.TimeoutError):
        error(f"JSON API call failed after retries: {url}")
        return None
    except Exception as e:
        error(f"API call failed: {e}")
        return None


# ── Result comparison ──


def compare_results(
    actual_nodes: dict[str, Any],
    expected: dict[str, dict],
    nodes_config: dict[str, Any],
) -> dict[str, NodeScore]:
    """Compare actual API results against ground truth expectations.

    Args:
        actual_nodes: Mapping of node_name -> node output from API response.
            Node output can be a dict (keyed fields) or a list (array of items).
        expected: Mapping of node_name -> {field_path: {"value": ..., "match": ...}}.
            Field paths for list nodes use array indexing: "[0].price_with_tax".
        nodes_config: Mapping of node_name -> EvaluationNode config.

    Returns:
        Dict of node_name -> NodeScore.
    """
    scores: dict[str, NodeScore] = {}

    for node_name, field_expectations in expected.items():
        node_config = nodes_config.get(node_name)
        default_match = node_config.match if node_config else "exact"

        actual_node = actual_nodes.get(node_name, {})
        details: dict[str, bool] = {}
        fields_correct = 0

        for field_path, expectation in field_expectations.items():
            if isinstance(expectation, dict):
                expected_val = str(expectation.get("value", ""))
                match_mode = expectation.get("match", default_match)
            else:
                # Shorthand: just a value string, use default match
                expected_val = str(expectation)
                match_mode = default_match

            actual_val = _get_by_dotpath(actual_node, field_path)
            if actual_val is None:
                details[field_path] = False
                continue

            is_correct = _match_value(str(actual_val), expected_val, match_mode)
            details[field_path] = is_correct
            if is_correct:
                fields_correct += 1

        fields_total = len(field_expectations)
        accuracy = fields_correct / fields_total if fields_total > 0 else 0.0

        scores[node_name] = NodeScore(
            node_name=node_name,
            fields_total=fields_total,
            fields_correct=fields_correct,
            accuracy=accuracy,
            details=details,
        )

    return scores


# ── Aggregate accuracy ──


def _compute_aggregate(
    node_scores: dict[str, NodeScore],
    nodes_config: dict[str, Any],
) -> float:
    """Compute weighted aggregate accuracy across all nodes."""
    total_weight = 0.0
    weighted_sum = 0.0

    for name, score in node_scores.items():
        weight = 1.0
        node_cfg = nodes_config.get(name)
        if node_cfg:
            weight = getattr(node_cfg, "weight", 1.0)
        total_weight += weight
        weighted_sum += weight * score.accuracy

    return weighted_sum / total_weight if total_weight > 0 else 0.0


async def call_api_query(config: EvaluationSettings, query_body: dict) -> dict | None:
    """Call the query endpoint to fetch results after an SSE trigger.

    Used when `query_url` is configured — the SSE endpoint triggers processing
    but doesn't return data; results must be fetched separately.
    """
    method, url = _parse_endpoint(config.query_url)
    try:
        async def _do_request():
            timeout = aiohttp.ClientTimeout(total=config.sse_timeout)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.request(
                    method.lower(),
                    url,
                    json=query_body,
                    headers=config.request_headers,
                ) as resp:
                    resp.raise_for_status()
                    return await resp.json()

        return await _retry_request(_do_request, max_retries=3, base_delay=2.0)
    except (aiohttp.ClientError, asyncio.TimeoutError):
        error(f"Query API call failed after retries: {url}")
        return None
    except Exception as e:
        error(f"Query API call failed: {e}")
        return None


def _extract_results_from_query_response(raw: dict) -> dict[str, Any]:
    """Extract per-node results from a /v1/query-style response.

    Expected response structure (goodsprice-parse):
    {
      "code": 200,
      "data": [
        {
          "fileId": "...",
          "businessNo": "...",
          "fileParseType": "1",     # 1=material, 2=fenbao
          "fileParseStatus": "2",   # 2=success
          "projectItemList": [
            {"project_name": "...", "price_with_tax": "...", ...},
            ...
          ]
        }
      ]
    }

    We split the projectItemList into nodes by fileParseType:
      - "ocr_node": common OCR parsing (fileParseStatus check)
      - "classify_node": file type classification (fileParseType check)
      - "fenbao_node": fenbao (subcontracting) items (fileParseType=="2")
      - "material_node": material items (fileParseType=="1")
    """
    # Navigate to the data list
    data = raw
    if "data" in data:
        data = data["data"]
    if isinstance(data, dict) and "data" in data:
        data = data["data"]

    if data is None:
        return {}

    # Normalize to list
    if isinstance(data, dict):
        items = [data]
    elif isinstance(data, list):
        items = data
    else:
        return {}

    node_results: dict[str, Any] = {}

    for file_result in items:
        if not isinstance(file_result, dict):
            continue

        # OCR/classify node: check parse status
        node_results["parse_status_node"] = {
            "fileParseStatus": file_result.get("fileParseStatus", ""),
            "fileParseType": file_result.get("fileParseType", ""),
            "fileId": file_result.get("fileId", ""),
        }

        # Get project items
        project_items = file_result.get("projectItemList") or []
        parse_type = file_result.get("fileParseType", "")

        # Split items by parse type or individual item type
        fenbao_items = []
        material_items = []

        for item in project_items:
            if not isinstance(item, dict):
                continue
            item_type = item.get("fileParseType", parse_type)
            if item_type == "2":
                fenbao_items.append(item)
            else:
                material_items.append(item)

        if fenbao_items:
            node_results["fenbao_node"] = fenbao_items
        if material_items:
            node_results["material_node"] = material_items

        # Also store all items together for "all_items" node if needed
        if project_items:
            node_results["all_items_node"] = project_items

    return node_results


# ── Main orchestrator ──


def _extract_node_results(raw_events: list[dict] | dict) -> dict[str, Any]:
    """Extract per-node results from the API response.

    Handles multiple response formats:
    1. SSE events: list of dicts, each with a "node" or "nodeName" key
    2. Single JSON response: dict with node results nested
    """
    node_results: dict[str, Any] = {}

    if isinstance(raw_events, dict):
        # Single JSON response
        # Try common nesting patterns
        if "data" in raw_events:
            data = raw_events["data"]
            if isinstance(data, dict):
                # Could be {node_name: result} or {results: {node_name: result}}
                if "results" in data:
                    return data["results"]
                return data
            elif isinstance(data, list):
                for item in data:
                    name = item.get("node") or item.get("nodeName") or item.get("node_name")
                    if name:
                        node_results[name] = item
                return node_results
        return raw_events

    # SSE events: list of dicts
    for event in raw_events:
        name = event.get("node") or event.get("nodeName") or event.get("node_name")
        if name:
            # Merge all data for this node
            if name not in node_results:
                node_results[name] = {}
            if isinstance(event, dict):
                node_results[name].update(event)

    return node_results


async def evaluate_api(
    config: SycliConfig,
    project_root: Path,
    skip_start: bool = False,
) -> EvaluationResult:
    """Full API evaluation pipeline: start service → call API → compare → stop.

    Supports two patterns:
    1. SSE-with-data: endpoint returns data in SSE stream events
    2. SSE-trigger + query: endpoint triggers processing, results fetched from query_url

    Args:
        config: Full sycli config.
        project_root: Path to the project root directory.
        skip_start: If True, skip starting the service (service_manager already did it).

    Returns:
        EvaluationResult with per-node and aggregate scores.
    """
    eval_cfg = config.evaluation
    proc = None
    api_response_received = False

    try:
        # Step 1: Start service (or skip if service_manager already started it)
        if skip_start:
            info("Skipping service start (service_manager already restarted)")
            service_started = True
        else:
            proc = await start_service(eval_cfg, project_root)
            service_started = proc is not None or not eval_cfg.service_startup

        if not service_started:
            return EvaluationResult(
                node_scores={},
                aggregate_accuracy=0.0,
                total_fields=0,
                total_correct=0,
                service_started=False,
                api_response_received=False,
            )

        # Step 2: Load ground truth
        gt_path = project_root / eval_cfg.ground_truth_file
        if not gt_path.exists():
            error(f"Ground truth file not found: {gt_path}")
            return EvaluationResult(
                node_scores={},
                aggregate_accuracy=0.0,
                total_fields=0,
                total_correct=0,
                service_started=service_started,
                api_response_received=False,
            )

        with open(gt_path) as f:
            ground_truth = json.load(f)

        request_body = ground_truth.get("request", eval_cfg.request_body)
        expected = ground_truth.get("expected", {})

        actual_nodes: dict[str, Any] = {}

        if eval_cfg.query_url:
            # ── Two-step pattern: SSE trigger + query ──
            # Step 3a: Call SSE endpoint to trigger processing
            info(f"Triggering parse: {eval_cfg.endpoint}")
            raw_events = await call_api_sse(eval_cfg, request_body)
            info(f"SSE stream completed (got {len(raw_events)} events)")

            # Step 3b: Wait for processing to finish
            delay = eval_cfg.query_delay
            info(f"Waiting {delay}s for processing to complete...")
            await asyncio.sleep(delay)

            # Step 3c: Query results
            query_body = eval_cfg.query_body or request_body
            info(f"Querying results: {eval_cfg.query_url}")
            query_resp = await call_api_query(eval_cfg, query_body)

            if query_resp:
                actual_nodes = _extract_results_from_query_response(query_resp)
                api_response_received = True
                info(f"Extracted results for {len(actual_nodes)} nodes from query response")
            else:
                error("Query endpoint returned no data")

        else:
            # ── Single-step pattern: SSE endpoint returns data ──
            info(f"Calling API: {eval_cfg.endpoint}")
            raw_events = await call_api_sse(eval_cfg, request_body)

            if not raw_events:
                info("SSE yielded no events, trying plain JSON request...")
                json_resp = await call_api_json(eval_cfg, request_body)
                if json_resp:
                    raw_events = json_resp
                    api_response_received = True
            else:
                api_response_received = True

            if not raw_events:
                error("No API response received")
                return EvaluationResult(
                    node_scores={},
                    aggregate_accuracy=0.0,
                    total_fields=0,
                    total_correct=0,
                    service_started=service_started,
                    api_response_received=False,
                )

            actual_nodes = _extract_node_results(raw_events)
            info(f"Received results for {len(actual_nodes)} nodes")

        # Step 4: Compare against ground truth
        if not actual_nodes:
            error("No node results extracted from API response")
            return EvaluationResult(
                node_scores={},
                aggregate_accuracy=0.0,
                total_fields=0,
                total_correct=0,
                service_started=service_started,
                api_response_received=api_response_received,
            )

        node_scores = compare_results(actual_nodes, expected, eval_cfg.nodes)

        # Step 5: Compute aggregate
        aggregate = _compute_aggregate(node_scores, eval_cfg.nodes)

        total_fields = sum(s.fields_total for s in node_scores.values())
        total_correct = sum(s.fields_correct for s in node_scores.values())

        # Display results
        info(f"API Evaluation: {total_correct}/{total_fields} fields correct")
        for name, ns in node_scores.items():
            marker = "OK" if ns.accuracy == 1.0 else "!!"
            info(f"  [{marker}] {name}: {ns.fields_correct}/{ns.fields_total} ({ns.accuracy:.0%})")
        info(f"  Aggregate: {aggregate:.1%}")

        return EvaluationResult(
            node_scores=node_scores,
            aggregate_accuracy=aggregate,
            total_fields=total_fields,
            total_correct=total_correct,
            service_started=service_started,
            api_response_received=api_response_received,
        )

    except Exception as e:
        error(f"API evaluation failed: {e}")
        return EvaluationResult(
            node_scores={},
            aggregate_accuracy=0.0,
            total_fields=0,
            total_correct=0,
            service_started=proc is not None,
            api_response_received=False,
        )
    finally:
        stop_service(proc)
