"""Agent 工厂——构建 sycli 的所有 agent。"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Sequence

from deepagents import SubAgent
from deepagents.backends.local_shell import LocalShellBackend
from deepagents.middleware.memory import MemoryMiddleware
from langchain_core.language_models import BaseChatModel

from sycli.models.config_models import SkillSettings, SycliConfig

# 内置技能目录（随 sycli 包发布）
_BUILTIN_SKILLS_DIR = Path(__file__).parent.parent / "skills" / "builtin"

# 映射：agent 名称 -> 内置技能目录名称列表
_SKILL_AGENT_MAP: dict[str, list[str]] = {
    "coder": ["test-driven-development", "systematic-debugging"],
    "analyst": ["systematic-debugging"],
    "critic": ["verification-before-completion", "code-review-enhanced"],
}


def _get_skills_for_agent(
    agent_name: str, config_skills: SkillSettings
) -> list[str] | None:
    """返回指定 agent 的技能源路径，根据启用的配置进行过滤。

    如果没有技能适用于此 agent，则返回 None（不设置 skills 键）。
    """
    skill_names = _SKILL_AGENT_MAP.get(agent_name, [])
    if not skill_names:
        return None
    # 根据 config.enabled 过滤（空列表 = 全部禁用；仅包含已启用的）
    if config_skills.enabled is not None and len(config_skills.enabled) >= 0:
        if not config_skills.enabled:
            return None
        skill_names = [s for s in skill_names if s in config_skills.enabled]
    if not skill_names:
        return None
    paths = [str(_BUILTIN_SKILLS_DIR / s) for s in skill_names]
    return paths


def _inject_project_root(prompt: str, project_root: str) -> str:
    """将 __PROJECT_ROOT__ 占位符替换为实际的项目根目录路径。"""
    return prompt.replace("__PROJECT_ROOT__", project_root)


def _memory_middleware(
    backend: LocalShellBackend,
    project_name: str,
    agent_role: str,
) -> MemoryMiddleware:
    """创建带有按 agent 源路径的 MemoryMiddleware。

    按顺序加载的源（拼接）：
    1. hot/context.md          - 第 0+1 层：工作记忆
    2. warm/agents/{role}.md   - 第 2 层：agent 特定压缩
    3. warm/strategies.md      - 第 2 层：共享策略
    4. warm/anti_patterns.md   - 第 2 层：共享反模式
    """
    return MemoryMiddleware(
        backend=backend,
        sources=[
            f".sycli/memory/{project_name}/hot/context.md",
            f".sycli/memory/{project_name}/warm/agents/{agent_role}.md",
            f".sycli/memory/{project_name}/warm/strategies.md",
            f".sycli/memory/{project_name}/warm/anti_patterns.md",
        ],
    )


def _get_prompt(
    builtin_attr: str,
    harness: Any | None = None,
    agent_name: str = "",
    project_root: str = "",
) -> str:
    """从 harness（基于文件）获取提示词，或回退到内置默认值。

    对任一来源应用 __PROJECT_ROOT__ 注入。
    """
    prompt = ""
    if harness is not None:
        prompt = harness.get_prompt(agent_name)
    if not prompt:
        prompt = getattr(
            __import__("sycli.agents.prompts", fromlist=[builtin_attr]),
            builtin_attr,
            "",
        )
    if project_root:
        prompt = _inject_project_root(prompt, project_root)
    return prompt


def build_subagents(
    config: SycliConfig,
    llm: BaseChatModel,
    backend: LocalShellBackend,
    project_name: str,
    mode: str = "optimize",
    project_root: str | None = None,
    harness: Any | None = None,
) -> list[SubAgent]:
    """根据模式构建所有 agent 的 SubAgent 规格。

    Args:
        config: sycli 配置。
        llm: 所有 agent 共享的 LLM 实例。
        backend: 所有 agent 共享的 LocalShellBackend。
        project_name: 用于记忆路径的项目名称。
        mode: "optimize" 或 "create"。
        project_root: 要注入提示词的绝对项目根目录路径。
        harness: 可选的 HarnessPromptManager，用于基于文件的提示词。

    Returns:
        要传递给编排器的 SubAgent 规格列表。
    """
    agents: list[SubAgent] = []
    root = project_root or str(backend.cwd)

    # --- 核心 agent（始终可用） ---

    agents.append({
        "name": "researcher",
        "description": (
            "Explores the codebase to understand structure, find relevant files, "
            "analyze dependencies and patterns. Use FIRST before coding."
        ),
        "system_prompt": _get_prompt("RESEARCHER_PROMPT", harness, "researcher", root),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "researcher")],
    })

    agents.append({
        "name": "coder",
        "description": (
            "Writes and modifies code, generates test cases. "
            "The ONLY agent with write/edit capabilities. "
            "Auto-fixes compilation errors before reporting."
        ),
        "system_prompt": _get_prompt("CODER_PROMPT", harness, "coder", root),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "coder")],
        "skills": _get_skills_for_agent("coder", config.skills),
    })

    agents.append({
        "name": "critic",
        "description": (
            "Evaluates code changes by running tests and static analysis. "
            "Read + execute access, no write. "
            "Produces a structured evaluation report."
        ),
        "system_prompt": _get_prompt("CRITIC_PROMPT", harness, "critic", root),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "critic")],
        "skills": _get_skills_for_agent("critic", config.skills),
    })

    # --- 深度分析 agent（始终可用） ---

    agents.append({
        "name": "analyst",
        "description": (
            "Performs deep code analysis: traces execution paths, identifies bugs, "
            "analyzes data flow and root causes. Read-only. "
            "Use after researcher to provide deeper context for the coder."
        ),
        "system_prompt": _get_prompt("ANALYST_PROMPT", harness, "analyst", root),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "analyst")],
        "skills": _get_skills_for_agent("analyst", config.skills),
    })

    # --- 服务管理器 agent（始终可用） ---

    agents.append({
        "name": "service_manager",
        "description": (
            "Manages the project's runtime service: stops old processes, starts "
            "fresh, health-checks. Read + execute, no write. "
            "Use after coder to restart the service before API evaluation."
        ),
        "system_prompt": _get_prompt("SERVICE_MANAGER_PROMPT", harness, "service_manager", root),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "service_manager")],
    })

    agents.append({
        "name": "runtime_observer",
        "description": (
            "Starts the project, monitors runtime behavior, collects metrics. "
            "Read + execute access, no write. "
            "Produces a runtime validation report."
        ),
        "system_prompt": _get_prompt("RUNTIME_OBSERVER_PROMPT", harness, "runtime_observer", root),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "runtime_observer")],
    })

    agents.append({
        "name": "prompt_engineer",
        "description": (
            "Optimizes the strategy based on evaluation results. "
            "Read-only. Only called when a round scores below threshold. "
            "Produces actionable optimization suggestions."
        ),
        "system_prompt": _get_prompt("PROMPT_ENGINEER_PROMPT", harness, "prompt_engineer"),
        "model": llm,
        "middleware": [_memory_middleware(backend, project_name, "prompt_engineer")],
    })

    # --- 仅 CREATE 模式 ---

    if mode == "create":
        agents.append({
            "name": "architect",
            "description": (
                "Designs project architecture from scratch. "
                "CREATE mode only. Read-only. "
                "Produces a complete architecture blueprint."
            ),
            "system_prompt": _get_prompt("ARCHITECT_PROMPT", harness, "architect", root),
            "model": llm,
            "middleware": [_memory_middleware(backend, project_name, "architect")],
        })

        agents.append({
            "name": "data_analyst",
            "description": (
                "Analyzes datasets to infer schemas, types, and relationships. "
                "CREATE mode only. Read + execute. "
                "Produces a data analysis report with seed data."
            ),
            "system_prompt": _get_prompt("DATA_ANALYST_PROMPT", harness, "data_analyst", root),
            "model": llm,
            "middleware": [_memory_middleware(backend, project_name, "data_analyst")],
        })

    return agents
