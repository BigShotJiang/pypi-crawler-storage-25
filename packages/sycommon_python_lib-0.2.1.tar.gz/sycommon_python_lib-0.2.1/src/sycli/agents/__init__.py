"""Agent factory for sycli."""
