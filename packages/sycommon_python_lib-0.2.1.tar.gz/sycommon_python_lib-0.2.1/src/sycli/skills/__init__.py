"""Skill system for sycli — powered by deepagents SkillsMiddleware."""

# Builtin skills are loaded by deepagents via per-subagent `skills` paths.
# See sycli/agents/factory.py for the agent-to-skill mapping.

