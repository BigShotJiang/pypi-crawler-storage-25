"""基于文件的 LangGraph Checkpointer，持久化到 .sycli/checkpoints/。

替换 MemorySaver，使 agent 对话状态在进程重启后可恢复。

存储结构:
  .sycli/checkpoints/
    {thread_id}/
      checkpoint_{id}.json   # 序列化的 checkpoint 数据
      meta_{id}.json         # checkpoint metadata
      writes_{task_id}.json  # pending writes
      latest.json            # 最新 checkpoint_id
"""

from __future__ import annotations

import json
import os
import random
import shutil
from collections.abc import AsyncIterator, Iterator, Sequence
from pathlib import Path
from typing import Any

from langchain_core.runnables import RunnableConfig

from langgraph.checkpoint.base import (
    WRITES_IDX_MAP,
    BaseCheckpointSaver,
    ChannelVersions,
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
    SerializerProtocol,
    get_checkpoint_id,
    get_checkpoint_metadata,
)
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer


class FileCheckpointer(BaseCheckpointSaver[str]):
    """基于文件的 LangGraph checkpointer。

    Checkpoint 数据以 JSON 文件形式存储在磁盘上，按 thread_id 分目录。
    """

    def __init__(
        self,
        checkpoints_dir: Path,
        *,
        serde: SerializerProtocol | None = None,
        keep_threads: int = 5,
    ) -> None:
        super().__init__(serde=serde or JsonPlusSerializer())
        self._dir = Path(checkpoints_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._keep_threads = keep_threads

    # ── 内部辅助 ──

    def _thread_dir(self, thread_id: str) -> Path:
        d = self._dir / thread_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _latest_path(self, thread_id: str) -> Path:
        return self._thread_dir(thread_id) / "latest.json"

    def _checkpoint_path(self, thread_id: str, checkpoint_ns: str, cp_id: str) -> Path:
        ns_suffix = f"_ns_{checkpoint_ns}" if checkpoint_ns else ""
        safe_id = cp_id.replace("/", "_")
        return self._thread_dir(thread_id) / f"checkpoint{ns_suffix}_{safe_id}.json"

    def _meta_path(self, thread_id: str, checkpoint_ns: str, cp_id: str) -> Path:
        ns_suffix = f"_ns_{checkpoint_ns}" if checkpoint_ns else ""
        safe_id = cp_id.replace("/", "_")
        return self._thread_dir(thread_id) / f"meta{ns_suffix}_{safe_id}.json"

    def _writes_path(self, thread_id: str, checkpoint_ns: str, cp_id: str, task_id: str) -> Path:
        ns_suffix = f"_ns_{checkpoint_ns}" if checkpoint_ns else ""
        safe_id = cp_id.replace("/", "_")
        return self._thread_dir(thread_id) / f"writes{ns_suffix}_{safe_id}_{task_id}.json"

    def _blob_path(self, thread_id: str, checkpoint_ns: str, channel: str, version: Any) -> Path:
        safe_ver = str(version).replace("/", "_").replace("\\", "_")
        return self._thread_dir(thread_id) / f"blob_{channel}_{safe_ver}.bin"

    def _atomic_write(self, path: Path, data: bytes) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)

    def _write_json(self, path: Path, obj: Any) -> None:
        data = json.dumps(obj, ensure_ascii=False, default=str).encode()
        self._atomic_write(path, data)

    def _read_json(self, path: Path) -> Any | None:
        if not path.exists():
            return None
        try:
            return json.loads(path.read_bytes())
        except Exception:
            return None

    def _save_blob(self, path: Path, typed_data: tuple[str, bytes]) -> None:
        """Save a serde typed blob as JSON (type_tag + base64 data)."""
        import base64

        tag, raw = typed_data
        obj = {"tag": tag, "data": base64.b64encode(raw).decode()}
        self._write_json(path.with_suffix(".json"), obj)

    def _load_blob(self, path: Path) -> tuple[str, bytes] | None:
        """Load a serde typed blob from JSON."""
        import base64

        json_path = path.with_suffix(".json")
        obj = self._read_json(json_path)
        if obj is None:
            return None
        return (obj["tag"], base64.b64decode(obj["data"]))

    def _cleanup_old_threads(self) -> None:
        """保留最近 keep_threads 个 thread 目录，删除其余。"""
        try:
            dirs = sorted(
                self._dir.iterdir(),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            for d in dirs[self._keep_threads :]:
                if d.is_dir():
                    shutil.rmtree(d, ignore_errors=True)
        except Exception:
            pass

    # ── Blob (channel values) 管理 ──

    def _save_blobs(
        self, thread_id: str, checkpoint_ns: str, values: dict[str, Any], new_versions: ChannelVersions
    ) -> None:
        for k, v in new_versions.items():
            blob_path = self._blob_path(thread_id, checkpoint_ns, k, v)
            if k in values:
                self._save_blob(blob_path, self.serde.dumps_typed(values[k]))
            else:
                # 标记为空
                json_path = blob_path.with_suffix(".json")
                self._write_json(json_path, {"tag": "empty", "data": ""})

    def _load_blobs(
        self, thread_id: str, checkpoint_ns: str, versions: ChannelVersions
    ) -> dict[str, Any]:
        channel_values: dict[str, Any] = {}
        for k, v in versions.items():
            blob_path = self._blob_path(thread_id, checkpoint_ns, k, v)
            typed = self._load_blob(blob_path)
            if typed is not None and typed[0] != "empty":
                channel_values[k] = self.serde.loads_typed(typed)
        return channel_values

    # ── 同步接口 ──

    def put(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: ChannelVersions,
    ) -> RunnableConfig:
        thread_id: str = config["configurable"]["thread_id"]
        checkpoint_ns: str = config["configurable"].get("checkpoint_ns", "")

        # 拆分 channel_values
        c = checkpoint.copy()
        values: dict[str, Any] = c.pop("channel_values", {})

        # 持久化 blobs
        self._save_blobs(thread_id, checkpoint_ns, values, new_versions)

        # 持久化 checkpoint (不含 channel_values)
        cp_path = self._checkpoint_path(thread_id, checkpoint_ns, checkpoint["id"])
        cp_data = self.serde.dumps_typed(c)
        self._save_blob(cp_path, cp_data)

        # 持久化 metadata
        meta_path = self._meta_path(thread_id, checkpoint_ns, checkpoint["id"])
        meta_data = self.serde.dumps_typed(
            get_checkpoint_metadata(config, metadata)
        )
        self._save_blob(meta_path, meta_data)

        # 记录 parent_checkpoint_id
        parent_id = config["configurable"].get("checkpoint_id")
        latest_obj = {
            "checkpoint_id": checkpoint["id"],
            "checkpoint_ns": checkpoint_ns,
            "parent_checkpoint_id": parent_id,
        }
        self._write_json(self._latest_path(thread_id), latest_obj)

        # 清理旧 thread
        self._cleanup_old_threads()

        return {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint["id"],
            }
        }

    def get_tuple(self, config: RunnableConfig) -> CheckpointTuple | None:
        thread_id: str = config["configurable"]["thread_id"]
        checkpoint_ns: str = config["configurable"].get("checkpoint_ns", "")

        checkpoint_id = get_checkpoint_id(config)

        if checkpoint_id:
            cp_id = checkpoint_id
            # 查找 parent
            latest = self._read_json(self._latest_path(thread_id))
            parent_id = None
            if latest and latest.get("checkpoint_id") == cp_id:
                parent_id = latest.get("parent_checkpoint_id")
        else:
            latest = self._read_json(self._latest_path(thread_id))
            if not latest:
                return None
            cp_id = latest["checkpoint_id"]
            parent_id = latest.get("parent_checkpoint_id")

        # 读取 checkpoint
        cp_path = self._checkpoint_path(thread_id, checkpoint_ns, cp_id)
        cp_blob = self._load_blob(cp_path)
        if cp_blob is None:
            return None
        checkpoint_: Checkpoint = self.serde.loads_typed(cp_blob)

        # 读取 metadata
        meta_path = self._meta_path(thread_id, checkpoint_ns, cp_id)
        meta_blob = self._load_blob(meta_path)
        metadata = self.serde.loads_typed(meta_blob) if meta_blob else {}

        # 读取 pending writes
        pending_writes = self._load_pending_writes(thread_id, checkpoint_ns, cp_id)

        # 恢复 channel_values
        channel_values = self._load_blobs(
            thread_id, checkpoint_ns, checkpoint_["channel_versions"]
        )

        return CheckpointTuple(
            config={
                "configurable": {
                    "thread_id": thread_id,
                    "checkpoint_ns": checkpoint_ns,
                    "checkpoint_id": cp_id,
                }
            },
            checkpoint={**checkpoint_, "channel_values": channel_values},
            metadata=metadata,
            parent_config=(
                {
                    "configurable": {
                        "thread_id": thread_id,
                        "checkpoint_ns": checkpoint_ns,
                        "checkpoint_id": parent_id,
                    }
                }
                if parent_id
                else None
            ),
            pending_writes=pending_writes or None,
        )

    def _load_pending_writes(
        self, thread_id: str, checkpoint_ns: str, cp_id: str
    ) -> list[tuple[str, str, Any]]:
        """加载指定 checkpoint 的所有 pending writes。"""
        tdir = self._thread_dir(thread_id)
        writes: list[tuple[str, str, Any]] = []
        ns_suffix = f"_ns_{checkpoint_ns}" if checkpoint_ns else ""
        safe_id = cp_id.replace("/", "_")

        for f in tdir.iterdir():
            if f.name.startswith(f"writes{ns_suffix}_{safe_id}_") and f.name.endswith(".json"):
                data = self._read_json(f)
                if data is None:
                    continue
                for entry in data:
                    task_id = entry.get("task_id", "")
                    channel = entry.get("channel", "")
                    value_blob = entry.get("value")
                    if value_blob is not None:
                        value = self.serde.loads_typed(
                            (value_blob["tag"], __import__("base64").b64decode(value_blob["data"]))
                        )
                    else:
                        value = None
                    writes.append((task_id, channel, value))
        return writes

    def list(
        self,
        config: RunnableConfig | None,
        *,
        filter: dict[str, Any] | None = None,
        before: RunnableConfig | None = None,
        limit: int | None = None,
    ) -> Iterator[CheckpointTuple]:
        thread_ids = (
            (config["configurable"]["thread_id"],) if config else [d.name for d in self._dir.iterdir() if d.is_dir()]
        )
        config_checkpoint_ns = config["configurable"].get("checkpoint_ns") if config else None

        for thread_id in thread_ids:
            tdir = self._dir / thread_id
            if not tdir.is_dir():
                continue

            # 收集所有 checkpoint 文件
            cp_files: list[tuple[str, str, Path]] = []  # (cp_id, ns, path)
            for f in tdir.iterdir():
                if f.name.startswith("checkpoint") and f.name.endswith(".json"):
                    # 解析 checkpoint_ns 和 id
                    name = f.stem  # e.g. "checkpoint_ns__cp_id" or "checkpoint_cp_id"
                    if name.startswith("checkpoint_ns_"):
                        # checkpoint_ns_{ns}_{id}
                        rest = name[len("checkpoint_ns_"):]
                        # ns 中可能有 _，id 是最后部分 — 但我们简化处理
                        # 只处理空 ns 的情况（sycli 默认）
                        continue  # 跳过有 ns 的（sycli 不使用）
                    elif name.startswith("checkpoint_"):
                        cp_id = name[len("checkpoint_"):]
                        cp_files.append((cp_id, "", f))

            # 按文件修改时间排序（最新优先）
            cp_files.sort(key=lambda x: x[2].stat().st_mtime, reverse=True)

            for cp_id, cp_ns, cp_path in cp_files:
                if config_checkpoint_ns is not None and cp_ns != config_checkpoint_ns:
                    continue

                # 读取
                cp_blob = self._load_blob(cp_path)
                if cp_blob is None:
                    continue
                checkpoint_: Checkpoint = self.serde.loads_typed(cp_blob)

                meta_path = self._meta_path(thread_id, cp_ns, cp_id)
                meta_blob = self._load_blob(meta_path)
                metadata = self.serde.loads_typed(meta_blob) if meta_blob else {}

                # filter by metadata
                if filter and not all(
                    metadata.get(k) == v for k, v in filter.items()
                ):
                    continue

                # before filter
                if before and (before_cp_id := get_checkpoint_id(before)):
                    if cp_id >= before_cp_id:
                        continue

                if limit is not None and limit <= 0:
                    break
                elif limit is not None:
                    limit -= 1

                latest = self._read_json(self._latest_path(thread_id))
                parent_id = latest.get("parent_checkpoint_id") if latest else None

                channel_values = self._load_blobs(
                    thread_id, cp_ns, checkpoint_["channel_versions"]
                )
                pending_writes = self._load_pending_writes(thread_id, cp_ns, cp_id)

                yield CheckpointTuple(
                    config={
                        "configurable": {
                            "thread_id": thread_id,
                            "checkpoint_ns": cp_ns,
                            "checkpoint_id": cp_id,
                        }
                    },
                    checkpoint={**checkpoint_, "channel_values": channel_values},
                    metadata=metadata,
                    parent_config=(
                        {
                            "configurable": {
                                "thread_id": thread_id,
                                "checkpoint_ns": cp_ns,
                                "checkpoint_id": parent_id,
                            }
                        }
                        if parent_id
                        else None
                    ),
                    pending_writes=pending_writes or None,
                )

    def put_writes(
        self,
        config: RunnableConfig,
        writes: Sequence[tuple[str, Any]],
        task_id: str,
        task_path: str = "",
    ) -> None:
        import base64

        thread_id = config["configurable"]["thread_id"]
        checkpoint_ns = config["configurable"].get("checkpoint_ns", "")
        checkpoint_id = config["configurable"]["checkpoint_id"]

        wp = self._writes_path(thread_id, checkpoint_ns, checkpoint_id, task_id)
        safe_id = checkpoint_id.replace("/", "_")
        ns_suffix = f"_ns_{checkpoint_ns}" if checkpoint_ns else ""
        wp = self._thread_dir(thread_id) / f"writes{ns_suffix}_{safe_id}_{task_id}.json"

        # 读取已有的 writes
        existing = self._read_json(wp) or []

        for idx, (c, v) in enumerate(writes):
            inner_idx = WRITES_IDX_MAP.get(c, idx)
            if inner_idx >= 0 and any(
                e.get("task_id") == task_id and e.get("idx") == inner_idx
                for e in existing
            ):
                continue

            typed = self.serde.dumps_typed(v)
            entry = {
                "task_id": task_id,
                "channel": c,
                "idx": inner_idx,
                "task_path": task_path,
                "value": {
                    "tag": typed[0],
                    "data": base64.b64encode(typed[1]).decode(),
                },
            }
            existing.append(entry)

        self._write_json(wp, existing)

    def delete_thread(self, thread_id: str) -> None:
        tdir = self._dir / thread_id
        if tdir.is_dir():
            shutil.rmtree(tdir, ignore_errors=True)

    def get_next_version(self, current: str | None, channel: None) -> str:
        if current is None:
            current_v = 0
        elif isinstance(current, int):
            current_v = current
        else:
            current_v = int(current.split(".")[0])
        next_v = current_v + 1
        next_h = random.random()
        return f"{next_v:032}.{next_h:016}"

    # ── 异步接口（委托给同步方法） ──

    async def aget_tuple(self, config: RunnableConfig) -> CheckpointTuple | None:
        return self.get_tuple(config)

    async def alist(
        self,
        config: RunnableConfig | None,
        *,
        filter: dict[str, Any] | None = None,
        before: RunnableConfig | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[CheckpointTuple]:
        for item in self.list(config, filter=filter, before=before, limit=limit):
            yield item

    async def aput(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: ChannelVersions,
    ) -> RunnableConfig:
        return self.put(config, checkpoint, metadata, new_versions)

    async def aput_writes(
        self,
        config: RunnableConfig,
        writes: Sequence[tuple[str, Any]],
        task_id: str,
        task_path: str = "",
    ) -> None:
        return self.put_writes(config, writes, task_id, task_path)

    async def adelete_thread(self, thread_id: str) -> None:
        return self.delete_thread(thread_id)
