"""RL 循环的收敛检测。

策略：
  - window（滑动窗口）：所有变化量 < 阈值 → 已收敛
  - ema（指数移动平均）：EMA 变化 < 阈值 → 已收敛
  - patience（耐心）：滑动窗口内连续 N 轮无改进 → 已收敛

收敛判断增强：
  - 接近目标时放宽收敛条件（near-target convergence）
  - patience 使用滑动窗口而非全局历史
  - 收敛但未达标时返回扰动提示（perturbation hint）
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class ConvergenceResult(BaseModel):
    """收敛检查的结果。"""

    converged: bool = False
    reason: str = ""
    window_max_delta: float | None = None
    ema_value: float | None = None
    perturbation_hint: str = ""  # 停滞但未达标时的扰动建议


def check_convergence(
    scores: list[float],
    *,
    strategy: Literal["window", "ema", "patience"] = "window",
    threshold: float = 0.05,
    window_size: int = 10,
    ema_alpha: float = 0.3,
    patience: int = 15,
    min_rounds: int = 5,
    target_accuracy: float = 0.95,
    near_target_margin: float = 0.02,
) -> ConvergenceResult:
    """检查 RL 循环是否已收敛。

    Args:
        scores: 轮次得分列表（准确率值）。
        strategy: 收敛检测策略。
        threshold: 收敛阈值。
        window_size: 'window' 策略的窗口大小。
        ema_alpha: 'ema' 策略的平滑因子。
        patience: 'patience' 策略的最大无改进轮次。
        min_rounds: 检查收敛前的最小轮次。
        target_accuracy: 目标准确率（用于接近目标判定）。
        near_target_margin: 接近目标时的容差。

    Returns:
        ConvergenceResult，指示是否收敛及原因。
    """
    if len(scores) < min_rounds:
        return ConvergenceResult(
            converged=False,
            reason=f"仅 {len(scores)} 轮（最小={min_rounds}）",
        )

    if strategy == "window":
        return _check_window(scores, threshold, window_size, target_accuracy, near_target_margin)
    elif strategy == "ema":
        return _check_ema(scores, threshold, ema_alpha, window_size, target_accuracy, near_target_margin)
    elif strategy == "patience":
        return _check_patience(scores, patience, target_accuracy)
    else:
        return ConvergenceResult(converged=False, reason=f"未知策略: {strategy}")


def _check_window(
    scores: list[float],
    threshold: float,
    window_size: int,
    target_accuracy: float = 0.95,
    near_target_margin: float = 0.02,
) -> ConvergenceResult:
    """滑动窗口：窗口内所有变化量 < 阈值 → 已收敛。

    增强：如果平均得分接近目标且窗口内波动小，也判定为收敛。
    """
    if len(scores) < window_size:
        return ConvergenceResult(
            converged=False,
            reason=f"仅 {len(scores)} 个得分（窗口={window_size}）",
        )

    recent = scores[-window_size:]
    deltas = [abs(recent[i] - recent[i - 1]) for i in range(1, len(recent))]
    max_delta = max(deltas) if deltas else 0.0

    if max_delta < threshold:
        return ConvergenceResult(
            converged=True,
            reason=f"最近 {window_size} 轮最大变化量 ({max_delta:.4f}) < 阈值 ({threshold})",
            window_max_delta=max_delta,
        )

    # 增强：接近目标时的放宽收敛
    avg_recent = sum(recent) / len(recent)
    if avg_recent >= target_accuracy - near_target_margin and max_delta < threshold * 2:
        return ConvergenceResult(
            converged=True,
            reason=f"平均得分 ({avg_recent:.4f}) 接近目标 ({target_accuracy})，最大变化量 ({max_delta:.4f}) < 放宽阈值 ({threshold * 2:.4f})",
            window_max_delta=max_delta,
        )

    # 停滞但未达标 — 提供扰动提示
    if avg_recent < target_accuracy - near_target_margin and max_delta < threshold * 3:
        return ConvergenceResult(
            converged=False,
            reason=f"停滞但未达标（avg={avg_recent:.4f}, max_delta={max_delta:.4f}），建议扰动",
            window_max_delta=max_delta,
            perturbation_hint=f"平均得分 {avg_recent:.4f} 距目标 {target_accuracy} 较远，但得分已稳定。建议尝试根本不同的方法。",
        )

    return ConvergenceResult(
        converged=False,
        reason=f"最大变化量 ({max_delta:.4f}) >= 阈值 ({threshold})",
        window_max_delta=max_delta,
    )


def _check_ema(
    scores: list[float],
    threshold: float,
    alpha: float,
    check_rounds: int,
    target_accuracy: float = 0.95,
    near_target_margin: float = 0.02,
) -> ConvergenceResult:
    """EMA：指数移动平均变化 < 阈值 → 已收敛。

    增强：如果 EMA 值接近目标且变化小，也判定为收敛。
    """
    if len(scores) < 2:
        return ConvergenceResult(converged=False, reason="需要 >= 2 个得分才能计算 EMA")

    # 计算 EMA 序列
    ema = scores[0]
    ema_series = [ema]
    for s in scores[1:]:
        ema = alpha * s + (1 - alpha) * ema
        ema_series.append(ema)

    # 检查最近 N 个 EMA 变化量
    check_n = min(check_rounds, len(ema_series) - 1)
    recent_deltas = [abs(ema_series[-i] - ema_series[-i - 1]) for i in range(1, check_n + 1)]
    max_delta = max(recent_deltas) if recent_deltas else 0.0

    current_ema = ema_series[-1]

    if max_delta < threshold:
        return ConvergenceResult(
            converged=True,
            reason=f"EMA 已稳定 {check_n} 轮（最大变化量={max_delta:.4f}）",
            ema_value=current_ema,
        )

    # 增强：EMA 接近目标时放宽
    if current_ema >= target_accuracy - near_target_margin and max_delta < threshold * 2:
        return ConvergenceResult(
            converged=True,
            reason=f"EMA ({current_ema:.4f}) 接近目标，变化量 ({max_delta:.4f}) < 放宽阈值",
            ema_value=current_ema,
        )

    # 停滞但未达标
    if current_ema < target_accuracy - near_target_margin and max_delta < threshold * 3:
        return ConvergenceResult(
            converged=False,
            reason=f"EMA 停滞但未达标（ema={current_ema:.4f}），建议扰动",
            ema_value=current_ema,
            perturbation_hint=f"EMA {current_ema:.4f} 距目标 {target_accuracy} 较远但已稳定，建议尝试不同方向。",
        )

    return ConvergenceResult(
        converged=False,
        reason=f"EMA 仍在变化（最大变化量={max_delta:.4f}）",
        ema_value=current_ema,
    )


def _check_patience(
    scores: list[float],
    patience: int,
    target_accuracy: float = 0.95,
) -> ConvergenceResult:
    """耐心：滑动窗口内连续 N 轮无改进 → 已收敛。

    修复：使用滑动窗口（patience*2）而非全局历史来查找最佳值，
    避免 flaky test 偶然高分导致误判。
    """
    if len(scores) < patience:
        return ConvergenceResult(
            converged=False,
            reason=f"仅 {len(scores)} 轮（耐心={patience}）",
        )

    # 使用滑动窗口而非全局历史
    window = scores[-(patience * 2):]
    best = max(window)
    best_idx = len(window) - 1 - window[::-1].index(best)
    rounds_since_best = len(window) - 1 - best_idx

    if rounds_since_best >= patience:
        # 检查是否达标
        if best < target_accuracy - 0.05:
            return ConvergenceResult(
                converged=True,
                reason=f"已连续 {rounds_since_best} 轮无改进（耐心={patience}），窗口最佳={best:.4f}",
                perturbation_hint=f"窗口最佳得分 {best:.4f} 未达标 ({target_accuracy})，已收敛但可能需要扰动重启。",
            )
        return ConvergenceResult(
            converged=True,
            reason=f"已连续 {rounds_since_best} 轮无改进（耐心={patience}）",
        )

    return ConvergenceResult(
        converged=False,
        reason=f"最佳得分在 {rounds_since_best} 轮前（耐心={patience}）",
    )
