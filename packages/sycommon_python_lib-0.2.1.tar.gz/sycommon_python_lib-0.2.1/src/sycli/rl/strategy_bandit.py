"""Thompson Sampling 策略 Bandit，用于 RL 策略选择。

跟踪不同策略在各轮次中的有效性，使用 Thompson Sampling（Beta 分布）
平衡探索与利用。

增强：
  - Arm 膨胀控制：相似名称归并、低效 arm 淘汰
  - ROLLBACK 强失败信号处理
  - 最大 arm 数量限制
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from math import sqrt
from pathlib import Path
from typing import Any

from sycli.core.display import info


@dataclass
class StrategyArm:
    """Bandit 中的单个策略臂。"""

    name: str
    approach_template: str = ""
    trials: int = 0
    total_reward_delta: float = 0.0
    alpha: float = 1.0  # Beta 分布成功参数
    beta: float = 1.0  # Beta 分布失败参数

    def avg_delta(self) -> float:
        """所有试验的平均奖励变化量。"""
        return self.total_reward_delta / self.trials if self.trials > 0 else 0.0


def _name_similarity(a: str, b: str) -> float:
    """计算两个策略名称的相似度（0-1）。"""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


class StrategyBandit:
    """Thompson Sampling 策略选择器。

    通过跟踪奖励变化量来学习哪些策略最有效。
    对每个臂使用 Beta(alpha, beta) 分布——从所有臂采样
    并选择采样值最高的臂。

    增强：
    - 相似名称自动归并到已有 arm
    - 低效 arm 淘汰机制（trials >= 5 且 avg_delta < -0.05 时降低权重）
    - 最大 arm 数量限制
    """

    def __init__(self, history_dir: Path, max_arms: int = 20):
        self.history_dir = history_dir
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self.max_arms = max_arms
        self.arms: dict[str, StrategyArm] = {}
        self._state_file = history_dir / "bandit_state.json"
        self._load()
        self._load_from_history()

    def _load(self) -> None:
        """从磁盘加载 bandit 状态。"""
        if not self._state_file.exists():
            return
        try:
            with open(self._state_file) as f:
                data = json.load(f)
            for name, arm_data in data.get("arms", {}).items():
                self.arms[name] = StrategyArm(
                    name=name,
                    approach_template=arm_data.get("approach_template", ""),
                    trials=arm_data.get("trials", 0),
                    total_reward_delta=arm_data.get("total_reward_delta", 0.0),
                    alpha=arm_data.get("alpha", 1.0),
                    beta=arm_data.get("beta", 1.0),
                )
        except Exception:
            pass

    def _load_from_history(self) -> None:
        """从现有 RL 历史（rounds.json）引导臂。"""
        rounds_file = self.history_dir / "rounds.json"
        if not rounds_file.exists():
            return
        try:
            with open(rounds_file) as f:
                rounds_data = json.load(f)
        except Exception:
            return

        # 仅在没有臂时引导
        if self.arms:
            return

        prev_score = 0.0
        for r in rounds_data:
            strategy = r.get("strategy", "")
            if not strategy:
                prev_score = r.get("score", 0.0)
                continue
            score = r.get("score", 0.0)
            delta = score - prev_score
            self._update_arm(strategy, delta)
            prev_score = score

        if self.arms:
            self._save()

    def _find_similar_arm(self, name: str, threshold: float = 0.7) -> StrategyArm | None:
        """查找与给定名称相似的已有 arm。"""
        best_arm = None
        best_sim = threshold
        for arm in self.arms.values():
            sim = _name_similarity(name, arm.name)
            if sim > best_sim:
                best_sim = sim
                best_arm = arm
        return best_arm

    def _update_arm(self, name: str, reward_delta: float) -> None:
        """更新单个臂的统计信息（不保存）。"""
        # 尝试归并到相似名称的已有 arm
        if name not in self.arms:
            similar = self._find_similar_arm(name)
            if similar:
                name = similar.name

        if name not in self.arms:
            self.arms[name] = StrategyArm(name=name)

        arm = self.arms[name]
        arm.trials += 1
        arm.total_reward_delta += reward_delta

        if reward_delta > 0:
            arm.alpha += 1.0
        else:
            arm.beta += 1.0

    def _cleanup_ineffective_arms(self) -> None:
        """淘汰低效臂：trials >= 5 且 avg_delta < -0.05。"""
        if len(self.arms) <= self.max_arms:
            return

        to_remove = []
        for name, arm in self.arms.items():
            if arm.trials >= 5 and arm.avg_delta() < -0.05:
                to_remove.append(name)

        for name in to_remove:
            del self.arms[name]
            info(f"Bandit: 淘汰低效臂 '{name}'")

    def _save(self) -> None:
        """将 bandit 状态持久化到磁盘。"""
        data: dict[str, Any] = {"arms": {}}
        for name, arm in self.arms.items():
            data["arms"][name] = {
                "approach_template": arm.approach_template,
                "trials": arm.trials,
                "total_reward_delta": arm.total_reward_delta,
                "alpha": arm.alpha,
                "beta": arm.beta,
            }
        try:
            with open(self._state_file, "w") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception:
            pass  # 尽力持久化

    def select(self) -> StrategyArm:
        """使用 Thompson Sampling 选择策略。

        从每个臂的 Beta(alpha, beta) 中采样，返回采样值最高的臂。
        如果没有臂则回退到均匀随机。
        低效臂（trials >= 5 且 avg_delta < -0.05）采样权重降低。
        """
        import random

        if not self.arms:
            # 尚无历史——返回默认探索臂
            return StrategyArm(name="initial_exploration")

        best_arm: StrategyArm | None = None
        best_sample = -1.0

        candidates = self.arms.values()
        # 当 arm 数量超过限制时，只从 top 策略中采样
        if len(self.arms) > self.max_arms:
            top = self.top_strategies(self.max_arms)
            candidates = top

        for arm in candidates:
            # 低效臂降低采样权重：使用更高的 beta
            effective_beta = arm.beta
            if arm.trials >= 5 and arm.avg_delta() < -0.05:
                effective_beta = arm.beta * 2.0

            # Thompson 从 Beta(alpha, beta) 采样
            try:
                a_sample = self._gamma_sample(arm.alpha)
                b_sample = self._gamma_sample(effective_beta)
                sample = a_sample / (a_sample + b_sample) if (a_sample + b_sample) > 0 else 0.5
            except Exception:
                sample = random.random()

            if sample > best_sample:
                best_sample = sample
                best_arm = arm

        return best_arm or StrategyArm(name="initial_exploration")

    @staticmethod
    def _gamma_sample(shape: float) -> float:
        """使用 Marsaglia 和 Tsang 方法从 Gamma(shape, 1) 采样。"""
        import random
        import math

        if shape < 1.0:
            # 当 shape < 1 时，使用变换：X = Y^(1/shape)，其中 Y ~ Gamma(shape+1)
            return StrategyBandit._gamma_sample(shape + 1.0) * (random.random() ** (1.0 / shape))

        d = shape - 1.0 / 3.0
        c = 1.0 / sqrt(9.0 * d)

        while True:
            x = random.gauss(0, 1)
            v = (1.0 + c * x) ** 3
            if v <= 0:
                continue
            u = random.random()
            if u < 1.0 - 0.0331 * (x * x) ** 2:
                return d * v
            if math.log(u) < 0.5 * x * x + d * (1.0 - v + math.log(v)):
                return d * v

    def update(self, strategy_name: str, reward_delta: float, decision: str = "") -> None:
        """观察到轮次结果后更新 bandit。

        Args:
            strategy_name: 策略名称。
            reward_delta: 奖励变化量（使用 total_reward 而非原始 score delta）。
            decision: 本轮决策（ACCEPT/RETRY/ROLLBACK）。
                ROLLBACK 时视为强失败信号，增加额外的 beta 惩罚。
        """
        # ROLLBACK 时增加额外的失败权重
        if decision == "ROLLBACK":
            reward_delta = min(reward_delta, -0.1)

        self._update_arm(strategy_name, reward_delta)

        # 清理低效臂
        self._cleanup_ineffective_arms()

        self._save()

    def top_strategies(self, n: int = 5) -> list[StrategyArm]:
        """返回按平均奖励变化量排序的前 N 个策略。"""
        sorted_arms = sorted(
            self.arms.values(),
            key=lambda a: a.avg_delta(),
            reverse=True,
        )
        return sorted_arms[:n]

    def get_hint(self) -> str:
        """生成用于 LLM 提示词的可读推荐。"""
        if not self.arms:
            return "暂无推荐（历史数据不足）。"

        top = self.top_strategies(3)
        lines = []
        for i, arm in enumerate(top):
            avg = arm.avg_delta()
            lines.append(
                f"  {i+1}. '{arm.name}' — 平均变化量: {avg:+.3f} "
                f"(试验次数: {arm.trials}, alpha: {arm.alpha:.0f}, beta: {arm.beta:.0f})"
            )

        recommended = self.select()
        return (
            f"推荐策略: '{recommended.name}' "
            f"(平均变化量: {recommended.avg_delta():+.3f}, 试验次数: {recommended.trials})\n"
            f"Top 策略:\n" + "\n".join(lines)
        )
