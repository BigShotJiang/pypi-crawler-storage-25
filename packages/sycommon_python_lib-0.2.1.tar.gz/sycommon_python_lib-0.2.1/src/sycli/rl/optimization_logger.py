"""统一优化日志记录器，写入 .sycli/optimization_log.jsonl。

以 JSONL 格式记录每个关键事件，提供完整可追溯的时间线日志。
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class OptimizationLogger:
    """统一优化日志记录器。

    写入 .sycli/optimization_log.jsonl，每行一个 JSON 事件。
    """

    def __init__(self, sycli_dir: Path, project_name: str):
        self._log_file = sycli_dir / "optimization_log.jsonl"
        self._project = project_name
        self._start_time: str = ""

    def _ts(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _emit(self, event: str, round_num: int, data: dict | None = None) -> None:
        entry: dict[str, Any] = {
            "ts": self._ts(),
            "project": self._project,
            "round": round_num,
            "event": event,
        }
        if data:
            entry["data"] = data
        try:
            with open(self._log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
        except Exception:
            pass

    # ── 高级日志方法 ──

    def log_session_start(self, total_rounds: int, config_summary: dict | None = None) -> None:
        self._start_time = self._ts()
        self._emit("session_start", 0, {
            "total_rounds": total_rounds,
            **(config_summary or {}),
        })

    def log_session_resume(self, start_round: int, total_rounds: int, best_score: float | None = None) -> None:
        self._emit("session_resume", start_round, {
            "start_round": start_round,
            "total_rounds": total_rounds,
            "best_score": best_score,
        })

    def log_round_start(self, round_num: int, strategy: str, exploration_level: str = "") -> None:
        self._emit("round_start", round_num, {
            "strategy": strategy,
            "exploration_level": exploration_level,
        })

    def log_strategy_selected(self, round_num: int, strategy_name: str, bandit_hint: str = "") -> None:
        self._emit("strategy_selected", round_num, {
            "strategy": strategy_name,
            "bandit_hint": bandit_hint,
        })

    def log_test_result(
        self,
        round_num: int,
        passed: int,
        failed: int,
        total: int,
        compilation_success: bool = True,
        api_accuracy: float | None = None,
        node_scores: dict | None = None,
    ) -> None:
        data: dict[str, Any] = {
            "passed": passed,
            "failed": failed,
            "total": total,
            "compilation_success": compilation_success,
        }
        if api_accuracy is not None:
            data["api_accuracy"] = api_accuracy
        if node_scores:
            data["node_scores"] = node_scores
        self._emit("test_result", round_num, data)

    def log_reward_computed(
        self,
        round_num: int,
        accuracy: float,
        total_reward: float,
        decision: str,
        progress_bonus: float = 0.0,
        regression_penalty: float = 0.0,
        stagnation_penalty: float = 0.0,
    ) -> None:
        self._emit("reward_computed", round_num, {
            "accuracy": accuracy,
            "total_reward": total_reward,
            "decision": decision,
            "progress_bonus": progress_bonus,
            "regression_penalty": regression_penalty,
            "stagnation_penalty": stagnation_penalty,
        })

    def log_round_end(self, round_num: int, score: float, decision: str, strategy: str = "") -> None:
        self._emit("round_end", round_num, {
            "score": score,
            "decision": decision,
            "strategy": strategy,
        })

    def log_convergence(self, round_num: int, converged: bool, reason: str, strategy_used: str = "") -> None:
        self._emit("convergence", round_num, {
            "converged": converged,
            "reason": reason,
            "convergence_strategy": strategy_used,
        })

    def log_direction_correction(self, round_num: int, reason: str, correction: str = "") -> None:
        self._emit("direction_correction", round_num, {
            "reason": reason,
            "correction": correction[:500] if correction else "",
        })

    def log_perturbation_restart(self, round_num: int, hint: str = "") -> None:
        self._emit("perturbation_restart", round_num, {"hint": hint})

    def log_memory_compressed(self, round_num: int, layer: str, token_count: int = 0) -> None:
        self._emit("memory_compressed", round_num, {
            "layer": layer,
            "token_count": token_count,
        })

    def log_experience_cleanup(self, round_num: int, removed: int) -> None:
        self._emit("experience_cleanup", round_num, {"removed_rounds": removed})

    def log_error(self, round_num: int, error_msg: str) -> None:
        self._emit("error", round_num, {"error": error_msg[:500]})

    def log_shutdown(self, round_num: int, status: str, final_score: float, best_score: float) -> None:
        self._emit("session_end", round_num, {
            "status": status,
            "final_score": final_score,
            "best_score": best_score,
            "start_time": self._start_time,
        })

    def log_pre_analysis(self, round_num: int, analysis: dict) -> None:
        self._emit("pre_analysis", round_num, analysis)

    def log_baseline_tests(self, round_num: int, passed: int, total: int, files: list[str] | None = None) -> None:
        self._emit("baseline_tests", round_num, {
            "passed": passed,
            "total": total,
            "files": files or [],
        })

    # ── 报告生成 ──

    def _read_events(self) -> list[dict]:
        events: list[dict] = []
        if not self._log_file.exists():
            return events
        try:
            with open(self._log_file, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        events.append(json.loads(line))
        except Exception:
            pass
        return events

    def generate_report(self) -> str:
        """生成 Markdown 格式的优化报告摘要。"""
        events = self._read_events()
        if not events:
            return "# 优化报告\n\n无事件记录。"

        # 解析事件
        rounds_data: dict[int, dict] = {}
        session_start = None
        session_end = None
        direction_corrections = []
        perturbation_restarts = []

        for ev in events:
            r = ev.get("round", 0)
            etype = ev.get("event", "")
            data = ev.get("data", {})

            if etype == "session_start":
                session_start = ev
            elif etype == "session_end":
                session_end = ev
            elif etype == "round_end":
                rounds_data[r] = data
            elif etype == "direction_correction":
                direction_corrections.append((r, data))
            elif etype == "perturbation_restart":
                perturbation_restarts.append((r, data))

        lines = [
            "# 优化报告",
            "",
            f"- **项目**: {self._project}",
            f"- **开始时间**: {session_start.get('ts', 'N/A') if session_start else 'N/A'}",
            f"- **结束时间**: {session_end.get('ts', 'N/A') if session_end else 'N/A'}",
            f"- **总轮次**: {len(rounds_data)}",
        ]

        if session_end and session_end.get("data"):
            sd = session_end["data"]
            lines.append(f"- **最终得分**: {sd.get('final_score', 'N/A')}")
            lines.append(f"- **最佳得分**: {sd.get('best_score', 'N/A')}")
            lines.append(f"- **状态**: {sd.get('status', 'N/A')}")

        # 得分趋势
        if rounds_data:
            lines.append("")
            lines.append("## 得分趋势")
            lines.append("")
            sorted_rounds = sorted(rounds_data.keys())
            for r in sorted_rounds:
                d = rounds_data[r]
                score = d.get("score", 0)
                decision = d.get("decision", "")
                strategy = d.get("strategy", "")
                bar_len = max(0, min(50, int(score * 50)))
                bar = "#" * bar_len
                lines.append(f"| R{r:03d} | {score:.3f} | {bar:<50} | {decision} | {strategy} |")

        # 方向纠偏
        if direction_corrections:
            lines.append("")
            lines.append("## 方向纠偏")
            for r, d in direction_corrections:
                lines.append(f"- **R{r}**: {d.get('reason', 'N/A')}")

        # 扰动重启
        if perturbation_restarts:
            lines.append("")
            lines.append("## 扰动重启")
            for r, d in perturbation_restarts:
                lines.append(f"- **R{r}**: {d.get('hint', 'N/A')}")

        lines.append("")
        return "\n".join(lines)

    def save_report(self, sycli_dir: Path) -> Path:
        """生成并保存优化报告到 .sycli/optimization_report.md。"""
        report_path = sycli_dir / "optimization_report.md"
        try:
            report_path.write_text(self.generate_report(), encoding="utf-8")
        except Exception:
            pass
        return report_path
