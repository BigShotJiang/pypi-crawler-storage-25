"""RL 奖励计算。

奖励 = 测试准确率 + 进步奖励（reward shaping）。
惩罚 = 回退惩罚 + 停滞惩罚（对数增长）。
编译错误不计分（编码员自动修复）。
"""

from __future__ import annotations

import math

from pydantic import BaseModel


class TestResult(BaseModel):
    """原始测试执行结果。"""

    tests_passed: int = 0
    tests_failed: int = 0
    tests_total: int = 0
    tests_errors: int = 0
    compilation_success: bool = True
    # 各节点 API 评估得分（节点名称 -> 准确率 0.0-1.0）
    node_scores: dict[str, float] = {}
    # 汇总 API 准确率（如果通过 API 模式评估）
    api_accuracy: float | None = None


class RewardResult(BaseModel):
    """单轮计算的奖励。"""

    test_accuracy: float = 0.0          # tests_passed / tests_total
    progress_bonus: float = 0.0         # 进步奖励（reward shaping）
    regression_penalty: float = 0.0     # -权重 * 新增失败数 / 之前通过数
    stagnation_penalty: float = 0.0     # 连续 N 轮无改进时施加（对数增长）
    total_reward: float = 0.0           # accuracy + progress + regression + stagnation
    decision: str = "ACCEPT"            # ACCEPT | RETRY | ROLLBACK
    # 各节点得分透传用于记录
    node_scores: dict[str, float] = {}


def compute_reward(
    test_result: TestResult,
    previous_passed: int = 0,
    previous_total: int = 0,
    regression_weight: float = 0.3,
    stagnation_rounds: int = 5,
    consecutive_no_improvement: int = 0,
    stagnation_penalty: float = -0.1,
    prev_accuracy: float = 0.0,
    accept_threshold: float = 0.8,
) -> RewardResult:
    """从测试结果计算奖励。

    RL 奖励 = 测试准确率 + 进步奖励。
    之前通过的测试现在失败时施加回退惩罚。
    超过停滞轮数后，停滞惩罚对数增长（无硬上限）。
    进步奖励具有 diminishing returns（越高准确率越难获得额外奖励）。

    当 api_accuracy 已设置（API 评估模式）时，将其作为主要
    准确率指标，而非 tests_passed/tests_total。

    Args:
        test_result: 当前轮次的测试执行结果。
        previous_passed: 本轮之前通过的测试数。
        previous_total: 本轮之前的测试总数（用于检测测试数变化）。
        regression_weight: 回退惩罚权重（0.0 - 1.0）。
        stagnation_rounds: 触发惩罚前的无改进轮数。
        consecutive_no_improvement: 连续无改进的轮数。
        stagnation_penalty: 停滞的基础惩罚值（应为负数）。
        prev_accuracy: 上轮准确率（用于计算进步奖励）。
        accept_threshold: ACCEPT 决策的准确率阈值。

    Returns:
        包含计算奖励和决策的 RewardResult。
    """
    # 如果有 api_accuracy（API 评估模式），则使用它，否则回退到 pytest
    if test_result.api_accuracy is not None:
        accuracy = test_result.api_accuracy
    else:
        accuracy = test_result.tests_passed / test_result.tests_total if test_result.tests_total > 0 else 0.0

    # 回退：之前通过但现在失败的测试
    # 当测试总数发生变化时，按比例估算 previous_passed
    if test_result.tests_total != previous_total and previous_total > 0 and test_result.tests_total > 0:
        ratio = test_result.tests_total / previous_total
        estimated_prev_passed = round(previous_passed * ratio)
        newly_failed = max(0, estimated_prev_passed - test_result.tests_passed)
    else:
        newly_failed = max(0, previous_passed - test_result.tests_passed)

    regression = -regression_weight * (newly_failed / previous_passed) if previous_passed > 0 else 0.0

    # 停滞：超过停滞轮数后对数增长惩罚（不再硬截断）
    stag = 0.0
    if consecutive_no_improvement >= stagnation_rounds:
        excess = consecutive_no_improvement - stagnation_rounds
        stag = stagnation_penalty * (1 + math.log1p(excess))

    # 进步奖励（reward shaping）— diminishing returns
    score_delta = accuracy - prev_accuracy
    if score_delta > 0:
        # 越接近 1.0，每单位进步获得的额外奖励越少
        progress_bonus = min(score_delta * 2.0, 0.2) * (1.0 - accuracy)
    else:
        progress_bonus = 0.0

    # 总奖励
    total = accuracy + progress_bonus + regression + stag

    # 决策逻辑
    # ACCEPT：达到阈值且无回退
    if accuracy >= accept_threshold and newly_failed == 0:
        decision = "ACCEPT"
    # ROLLBACK：显著回退（超过 30% 的之前通过测试现在失败）
    elif previous_passed > 0 and newly_failed / previous_passed > 0.3:
        decision = "ROLLBACK"
    # ROLLBACK：绝对回退惩罚超过阈值
    elif regression < -0.3:
        decision = "ROLLBACK"
    else:
        decision = "RETRY"

    return RewardResult(
        test_accuracy=accuracy,
        progress_bonus=progress_bonus,
        regression_penalty=regression,
        stagnation_penalty=stag,
        total_reward=total,  # 保留负值用于回退信号
        decision=decision,
        node_scores=test_result.node_scores,
    )
