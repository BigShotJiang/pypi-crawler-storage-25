"""环境引导——在首轮优化前收集项目快照。

受 Meta-Harness 启发：外循环提议者拥有文件系统访问权限，可获取所有先前候选。
类似地，sycli 应从对项目环境的丰富理解开始，使前几轮不必浪费探索步骤
来重新发现基本项目事实。

收集的信息：
- 语言、框架、测试框架
- 项目结构（目录树）
- 关键依赖（来自 requirements.txt / pyproject.toml / package.json）
- 最近的测试失败（如有）
- 入口点和配置文件
- 启动方式、架构模式、方案优劣分析（E5 增强）
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from sycli.core.display import info


def _run_cmd(cmd: str, cwd: str, timeout: int = 10) -> str:
    """运行命令并返回 stdout，失败时静默返回空字符串。"""
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout,
        )
        return result.stdout.strip()
    except Exception:
        return ""


def _detect_languages(project_root: Path) -> list[str]:
    """检测项目使用的编程语言。"""
    langs = set()
    if (project_root / "pyproject.toml").exists() or (project_root / "setup.py").exists():
        langs.add("python")
    if (project_root / "package.json").exists():
        langs.add("javascript")
    if (project_root / "go.mod").exists():
        langs.add("go")
    if (project_root / "Cargo.toml").exists():
        langs.add("rust")
    if (project_root / "pom.xml").exists():
        langs.add("java")
    # 回退：扫描文件扩展名
    if not langs:
        for ext in [".py", ".js", ".ts", ".go", ".java", ".rs"]:
            if list(project_root.rglob(f"*{ext}"))[:5]:
                name = {
                    ".py": "python", ".js": "javascript", ".ts": "typescript",
                    ".go": "go", ".java": "java", ".rs": "rust",
                }[ext]
                langs.add(name)
    return sorted(langs)


def _detect_framework(project_root: Path, languages: list[str]) -> str:
    """检测主要框架。"""
    if "python" in languages:
        # 检查 Web 框架
        req_files = ["requirements.txt", "pyproject.toml", "setup.py"]
        for rf in req_files:
            path = project_root / rf
            if path.exists():
                content = path.read_text(errors="ignore").lower()
                if "fastapi" in content:
                    return "fastapi"
                if "flask" in content:
                    return "flask"
                if "django" in content:
                    return "django"
                if "langchain" in content:
                    return "langchain"
        # 检查入口文件
        for name in ["app.py", "main.py", "app.yaml"]:
            if (project_root / name).exists():
                content = (project_root / name).read_text(errors="ignore").lower()
                if "fastapi" in content:
                    return "fastapi"
                if "flask" in content:
                    return "flask"
    return "unknown"


def _detect_test_framework(project_root: Path, languages: list[str]) -> str:
    """检测测试框架。"""
    if "python" in languages:
        if (project_root / "pytest.ini").exists() or (project_root / "conftest.py").exists():
            return "pytest"
        if (project_root / "pyproject.toml").exists():
            content = (project_root / "pyproject.toml").read_text(errors="ignore")
            if "pytest" in content:
                return "pytest"
            if "unittest" in content:
                return "unittest"
        if list(project_root.rglob("test_*.py")) or list(project_root.rglob("*_test.py")):
            return "pytest（推断）"
    if "javascript" in languages:
        if (project_root / "jest.config.js").exists():
            return "jest"
        if (project_root / "vitest.config.ts").exists():
            return "vitest"
    if "go" in languages:
        return "go test"
    return "unknown"


def _get_project_structure(project_root: Path, max_depth: int = 3) -> str:
    """获取精简的目录树。"""
    lines = []
    root_str = str(project_root)

    def _walk(path: Path, prefix: str, depth: int):
        if depth > max_depth:
            lines.append(f"{prefix}...")
            return
        try:
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name))
        except PermissionError:
            return
        # 跳过常见噪音目录
        skip = {
            "__pycache__", ".git", "node_modules", ".venv", "venv",
            ".mypy_cache", ".pytest_cache", ".tox", "dist", "build",
            ".eggs", "*.egg-info",
        }
        for entry in entries:
            if entry.name in skip or entry.name.endswith(".egg-info"):
                continue
            if entry.is_dir():
                lines.append(f"{prefix}{entry.name}/")
                _walk(entry, prefix + "  ", depth + 1)
            else:
                lines.append(f"{prefix}{entry.name}")

    _walk(project_root, "", 0)
    # 截断到合理长度
    result = "\n".join(lines)
    if len(result) > 3000:
        result = result[:3000] + "\n... (已截断)"
    return result


def _get_dependencies(project_root: Path, languages: list[str]) -> str:
    """提取关键依赖信息。"""
    parts = []
    if "python" in languages:
        req = project_root / "requirements.txt"
        if req.exists():
            content = req.read_text(errors="ignore").strip()
            if content:
                parts.append(f"requirements.txt:\n{content[:1000]}")
        pyproject = project_root / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text(errors="ignore")
            # 提取 [project.dependencies] 部分
            in_deps = False
            dep_lines = []
            for line in content.split("\n"):
                if "[project.dependencies]" in line or "[tool.poetry.dependencies]" in line:
                    in_deps = True
                    continue
                if in_deps:
                    if line.startswith("["):
                        break
                    if line.strip():
                        dep_lines.append(line.strip())
            if dep_lines:
                parts.append(f"pyproject.toml deps:\n" + "\n".join(dep_lines[:30]))
    if "javascript" in languages:
        pkg = project_root / "package.json"
        if pkg.exists():
            try:
                data = json.loads(pkg.read_text())
                deps = data.get("dependencies", {})
                dev_deps = data.get("devDependencies", {})
                if deps:
                    parts.append(f"dependencies: {json.dumps(deps, indent=2)[:500]}")
                if dev_deps:
                    parts.append(f"devDependencies: {json.dumps(dev_deps, indent=2)[:500]}")
            except json.JSONDecodeError:
                pass
    return "\n\n".join(parts) if parts else "未找到依赖文件。"


def _get_recent_errors(project_root: Path) -> str:
    """尝试运行一次测试套件并捕获错误。"""
    result = _run_cmd("python -m pytest --tb=line -q 2>&1 | tail -30", str(project_root), timeout=30)
    if result:
        return result[:1500]
    return "无法运行初始测试。"


def collect_environment(project_root: Path) -> dict[str, Any]:
    """收集完整的项目环境快照。"""
    languages = _detect_languages(project_root)
    framework = _detect_framework(project_root, languages)
    test_framework = _detect_test_framework(project_root, languages)
    structure = _get_project_structure(project_root)
    dependencies = _get_dependencies(project_root, languages)
    recent_errors = _get_recent_errors(project_root)

    # E5 增强：启动方式、架构、方案评估
    startup_method = _detect_startup_method(project_root, languages, framework)
    architecture = _analyze_architecture(project_root, languages, structure)
    approach_evaluation = _evaluate_approach(project_root, framework, architecture)

    return {
        "languages": languages,
        "framework": framework,
        "test_framework": test_framework,
        "structure": structure,
        "dependencies": dependencies,
        "recent_errors": recent_errors,
        "startup_method": startup_method,
        "architecture": architecture,
        "approach_evaluation": approach_evaluation,
    }


# ── E5: 预分析增强 ──


def _detect_startup_method(project_root: Path, languages: list[str], framework: str) -> dict[str, Any]:
    """检测项目启动方式。"""
    result: dict[str, Any] = {
        "start_command": "",
        "entry_point": "",
        "runner": "",
        "config_files": [],
    }

    if "python" not in languages:
        return result

    # 检查 pyproject.toml [project.scripts]
    pyproject = project_root / "pyproject.toml"
    if pyproject.exists():
        content = pyproject.read_text(errors="ignore")
        if "[project.scripts]" in content:
            for line in content.split("\n"):
                line = line.strip()
                if "=" in line and not line.startswith("["):
                    result["entry_point"] = line.split("=")[1].strip().strip('"').strip("'")
                    break

    # 检查 Dockerfile
    dockerfile = project_root / "Dockerfile"
    if dockerfile.exists():
        result["config_files"].append("Dockerfile")
        content = dockerfile.read_text(errors="ignore")
        for line in content.split("\n"):
            line = line.strip()
            if line.startswith("CMD") or line.startswith("ENTRYPOINT"):
                result["start_command"] = line
                break

    # 检查 Makefile
    makefile = project_root / "Makefile"
    if makefile.exists():
        result["config_files"].append("Makefile")
        content = makefile.read_text(errors="ignore")
        for target in ["run", "start", "serve", "dev"]:
            if f"{target}:" in content:
                result["start_command"] = f"make {target}"
                break

    # 基于框架推断启动命令
    if not result["start_command"]:
        if framework == "fastapi":
            # 寻找 uvicorn 入口
            for name in ["main.py", "app.py", "server.py"]:
                path = project_root / name
                if path.exists():
                    content = path.read_text(errors="ignore")
                    if "app" in content and "FastAPI" in content:
                        result["runner"] = "uvicorn"
                        result["start_command"] = f"uvicorn {name[:-3]}:app"
                        result["entry_point"] = f"{name}:app"
                        break
        elif framework == "flask":
            for name in ["main.py", "app.py", "server.py"]:
                path = project_root / name
                if path.exists():
                    content = path.read_text(errors="ignore")
                    if "Flask" in content:
                        result["runner"] = "flask"
                        result["start_command"] = f"flask --app {name[:-3]} run"
                        result["entry_point"] = f"{name}:app"
                        break
        elif framework == "django":
            result["runner"] = "django"
            result["start_command"] = "python manage.py runserver"

    # 检查 main() 入口
    if not result["entry_point"]:
        for name in ["main.py", "app.py", "server.py", "run.py"]:
            path = project_root / name
            if path.exists():
                content = path.read_text(errors="ignore")
                if "def main(" in content or "__main__" in content:
                    result["entry_point"] = name
                    if not result["start_command"]:
                        result["start_command"] = f"python {name}"
                    break

    # 检查 app.yaml / Procfile（PaaS 部署配置）
    for cfg in ["app.yaml", "Procfile", "railway.json", "render.yaml"]:
        if (project_root / cfg).exists():
            result["config_files"].append(cfg)

    return result


def _analyze_architecture(project_root: Path, languages: list[str], structure: str) -> dict[str, Any]:
    """分析项目架构模式。"""
    result: dict[str, Any] = {
        "pattern": "unknown",
        "layers": [],
        "key_modules": {},
    }

    # 常见目录名映射
    dir_patterns = {
        "api": "API 层",
        "routers": "路由层",
        "views": "视图层",
        "controllers": "控制器层",
        "models": "数据模型层",
        "schemas": "数据验证层",
        "services": "业务逻辑层",
        "core": "核心层",
        "utils": "工具层",
        "middleware": "中间件层",
        "tests": "测试层",
        "config": "配置层",
        "migrations": "数据库迁移",
        "static": "静态资源",
        "templates": "模板层",
        "serializers": "序列化层",
        "repositories": "仓储层",
        "handlers": "处理器层",
        "tasks": "异步任务层",
        "engine": "引擎层",
        "agents": "Agent 层",
        "memory": "记忆层",
        "rl": "RL 层",
    }

    detected_layers: list[str] = []
    key_modules: dict[str, str] = {}

    try:
        for entry in sorted(project_root.iterdir()):
            if entry.is_dir() and not entry.name.startswith(".") and entry.name not in (
                "__pycache__", "node_modules", ".venv", "venv", "dist", "build",
            ):
                if entry.name in dir_patterns:
                    detected_layers.append(f"{entry.name}/ ({dir_patterns[entry.name]})")
                    key_modules[entry.name] = dir_patterns[entry.name]
    except PermissionError:
        pass

    result["layers"] = detected_layers
    result["key_modules"] = key_modules

    # 推断架构模式
    layer_names = set(key_modules.keys())
    if {"models", "views", "controllers"} <= layer_names:
        result["pattern"] = "MVC"
    elif {"api", "services", "models"} <= layer_names:
        result["pattern"] = "layered (API/Service/Model)"
    elif {"routers", "services", "schemas"} <= layer_names:
        result["pattern"] = "layered (Router/Service/Schema)"
    elif {"routers", "models"} <= layer_names:
        result["pattern"] = "FastAPI Router/Model"
    elif detected_layers:
        result["pattern"] = "flat/modular"
    else:
        result["pattern"] = "monolith"

    return result


def _evaluate_approach(project_root: Path, framework: str, architecture: dict[str, Any]) -> dict[str, Any]:
    """评估当前架构的优劣。"""
    result: dict[str, Any] = {
        "strengths": [],
        "weaknesses": [],
        "risks": [],
    }

    pattern = architecture.get("pattern", "")
    layers = architecture.get("layers", [])

    # 基于框架的已知优劣
    framework_eval: dict[str, dict[str, list[str]]] = {
        "fastapi": {
            "strengths": ["异步支持", "自动文档", "类型校验", "依赖注入"],
            "weaknesses": ["较少中间件生态", "WebSocket 管理复杂"],
        },
        "flask": {
            "strengths": ["简单灵活", "丰富扩展", "文档完善"],
            "weaknesses": ["无异步原生支持", "大型项目需要手动组织"],
        },
        "django": {
            "strengths": ["全功能框架", "ORM 成熟", "Admin 后台"],
            "weaknesses": ["单体架构", "异步支持有限"],
        },
        "langchain": {
            "strengths": ["LLM 集成完善", "Chain 模式"],
            "weaknesses": ["版本更新快", "抽象层多"],
        },
    }

    if framework in framework_eval:
        result["strengths"].extend(framework_eval[framework]["strengths"])
        result["weaknesses"].extend(framework_eval[framework]["weaknesses"])

    # 基于架构模式的优劣
    if pattern == "MVC":
        result["strengths"].append("关注点分离")
    elif "layered" in pattern:
        result["strengths"].append("层次清晰")
    elif pattern == "monolith":
        result["risks"].append("单文件/模块耦合，优化时可能影响全局")

    # 基于层级深度的风险
    if len(layers) > 8:
        result["risks"].append("层级较多，优化时需要注意跨层影响")
    elif len(layers) == 0:
        result["risks"].append("项目结构扁平，可能缺少模块化")

    return result


def format_environment_for_prompt(env: dict[str, Any]) -> str:
    """将环境快照格式化以注入提示词。"""
    parts = [
        "## 项目环境（引导）",
        f"- 语言: {', '.join(env['languages'])}",
        f"- 框架: {env['framework']}",
        f"- 测试框架: {env['test_framework']}",
        "",
        "### 项目结构",
        env["structure"],
        "",
    ]
    if env["dependencies"]:
        parts.append("### 关键依赖")
        parts.append(env["dependencies"])
        parts.append("")
    if env["recent_errors"]:
        parts.append("### 初始测试运行（错误）")
        parts.append(env["recent_errors"])
        parts.append("")
    # E5 增强：启动方式和架构信息
    startup = env.get("startup_method", {})
    if startup.get("start_command"):
        parts.append("### 启动方式")
        parts.append(f"- 启动命令: {startup.get('start_command', 'N/A')}")
        parts.append(f"- 入口: {startup.get('entry_point', 'N/A')}")
        parts.append(f"- Runner: {startup.get('runner', 'N/A')}")
        if startup.get("config_files"):
            parts.append(f"- 配置文件: {', '.join(startup['config_files'])}")
        parts.append("")
    arch = env.get("architecture", {})
    if arch.get("pattern") and arch["pattern"] != "unknown":
        parts.append("### 架构模式")
        parts.append(f"- 模式: {arch['pattern']}")
        if arch.get("layers"):
            parts.append(f"- 层级: {', '.join(arch['layers'][:8])}")
        parts.append("")
    eval_info = env.get("approach_evaluation", {})
    if eval_info.get("strengths") or eval_info.get("risks"):
        parts.append("### 架构评估")
        if eval_info.get("strengths"):
            parts.append(f"- 优势: {', '.join(eval_info['strengths'][:5])}")
        if eval_info.get("weaknesses"):
            parts.append(f"- 不足: {', '.join(eval_info['weaknesses'][:5])}")
        if eval_info.get("risks"):
            parts.append(f"- 风险: {', '.join(eval_info['risks'][:5])}")
        parts.append("")
    return "\n".join(parts)
