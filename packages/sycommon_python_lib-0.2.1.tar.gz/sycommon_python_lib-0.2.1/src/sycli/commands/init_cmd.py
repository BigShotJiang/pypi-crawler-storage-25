"""sycli init command - initialize .sycli/ directory."""

from __future__ import annotations

import json
from pathlib import Path

from sycli.core.display import error, info, success, warning
from sycli.models.config_models import SycliConfig


def _default_sycli_json() -> dict:
    """Return default sycli.json template."""
    return {
        "version": "1.0",
        "llm": {
            "model": "glm-5.1",
            "provider": "openai",
            "base_url": "http://10.10.6.132:3000/v1",
            "base_url_env": "",
            "api_key": "sk-3hXhO7uCG5CRi7t3THE2cWTKVJqesXJ38cKstHZhDVXHQOIn",
            "api_key_env": "",
            "temperature": 0.7,
            "max_tokens": 200000,
            "timeout": 180,
            "thinking": True,
        },
        "rl": {
            "max_rounds": 100,
            "min_rounds": 5,
            "target_accuracy": 0.95,
            "convergence_threshold": 0.05,
            "convergence_window_size": 10,
            "regression_penalty_weight": 0.3,
            "auto_fix_compilation": True,
            "auto_fix_max_retries": 5,
            "stagnation_after_rounds": 5,
            "stagnation_penalty": -0.1,
            "exploration_epsilon_start": 0.3,
            "exploration_epsilon_end": 0.05,
            "exploration_epsilon_decay": 0.95,
        },
        "memory": {
            "hot_token_budget": 16000,
            "warm_token_budget": 40000,
            "compress_every_n_rounds": 8,
            "deep_compress_every_n_rounds": 30,
            "compress_threshold": 0.8,
        },
        "guardrails": {
            "max_file_changes_per_step": 10,
            "max_lines_changed_per_file": 200,
            "auto_rollback_on_fatal": True,
            "fatal_threshold": -0.4,
        },
        "detection": {
            "auto": True,
            "test_command": "auto",
            "health_endpoint": "/ping",
            "startup_timeout_s": 30,
        },
    }


def handle_init(args) -> int:
    """Handle `sycli init` command."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"

    # Check if already initialized
    if sycli_dir.exists() and not args.force:
        config_file = sycli_dir / "sycli.json"
        if config_file.exists():
            warning(f".sycli/ already exists at {sycli_dir}. Use --force to reinitialize.")
            return 1

    # Get project name
    project_name = args.project_name or project_root.name

    info(f"Initializing sycli for project '{project_name}'...")

    # Create directory structure
    dirs_to_create = [
        sycli_dir,
        sycli_dir / "memory" / project_name / "hot",
        sycli_dir / "memory" / project_name / "warm" / "agents",
        sycli_dir / "memory" / project_name / "full" / "agents",
        sycli_dir / "memory" / project_name / "full" / "episodes",
        sycli_dir / "input" / "datasets",
        sycli_dir / "cache",
        sycli_dir / "checkpoints",
        sycli_dir / "evaluations",
        sycli_dir / "logs",
        sycli_dir / "skills",
    ]

    for d in dirs_to_create:
        d.mkdir(parents=True, exist_ok=True)

    # Write sycli.json
    config_data = _default_sycli_json()
    config_path = sycli_dir / "sycli.json"
    with open(config_path, "w") as f:
        json.dump(config_data, f, indent=2, ensure_ascii=False)
    success(f"Created {config_path}")

    # Initialize memory files with placeholders
    _init_memory_files(sycli_dir, project_name)

    # Create .gitignore in .sycli/
    gitignore_path = sycli_dir / ".gitignore"
    gitignore_path.write_text("# sycli local state\nstate.db\nlogs/\n*.jsonl\n")

    # Add .sycli/ to project .gitignore if not already there
    project_gitignore = project_root / ".gitignore"
    if project_gitignore.exists():
        content = project_gitignore.read_text()
        if ".sycli/" not in content:
            with open(project_gitignore, "a") as f:
                f.write("\n# sycli\n.sycli/\n")
    else:
        project_gitignore.write_text("# sycli\n.sycli/\n")

    success(f"sycli initialized at {sycli_dir}")
    info(f"Project: {project_name}")
    info(f"Config:  {config_path}")
    info("")
    info("Next steps:")
    info("  1. Edit .sycli/sycli.json to configure your LLM settings")
    info("  2. Run: sycli run \"your task description\"")

    return 0


def _init_memory_files(sycli_dir: Path, project_name: str) -> None:
    """Initialize empty memory files."""
    memory_base = sycli_dir / "memory" / project_name

    # Hot memory
    hot_context = memory_base / "hot" / "context.md"
    hot_context.write_text("# Working Memory\n\n(Initialized - will be populated during first round)\n")

    # Warm memory - shared
    for name in ["strategies.md", "anti_patterns.md", "project_knowledge.md"]:
        path = memory_base / "warm" / name
        path.write_text(f"# {name.replace('_', ' ').replace('.md', '').title()}\n\n(No entries yet)\n")

    # Warm memory - per agent
    agents = [
        "orchestrator", "researcher", "coder", "critic",
        "runtime_observer", "prompt_engineer", "architect", "data_analyst",
    ]
    for agent in agents:
        path = memory_base / "warm" / "agents" / f"{agent}.md"
        path.write_text(f"# {agent.title()} Memory\n\n(No entries yet)\n")

    # Full memory - team
    team_full = memory_base / "full" / "TEAM_FULL.md"
    team_full.write_text("# Team Full Memory\n\n(Complete raw history - not loaded into context)\n")

    # Full memory - per agent
    for agent in agents:
        path = memory_base / "full" / "agents" / f"{agent}_full.md"
        path.write_text(f"# {agent.title()} Full Memory\n\n(Raw unfiltered history)\n")
