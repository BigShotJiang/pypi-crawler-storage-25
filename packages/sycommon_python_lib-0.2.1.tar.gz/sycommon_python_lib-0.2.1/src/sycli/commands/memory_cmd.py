"""sycli memory command - memory management."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from sycli.core.display import error, info, success, warning


def handle_memory(args) -> int:
    """Handle `sycli memory` command."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"
    project_name = args.project_name or project_root.name

    if not sycli_dir.exists():
        error(".sycli/ not found. Run `sycli init` first.")
        return 1

    if args.action == "show":
        return _show_memory(sycli_dir, project_name, args)
    elif args.action == "clear":
        return _clear_memory(sycli_dir, project_name, args)
    elif args.action == "export":
        return _export_memory(sycli_dir, project_name, args)
    elif args.action == "import":
        return _import_memory(sycli_dir, project_name, args)
    else:
        error(f"Unknown memory action: {args.action}")
        return 1


def _show_memory(sycli_dir: Path, project_name: str, args) -> int:
    """Show memory contents."""
    memory_base = sycli_dir / "memory" / project_name
    agent = args.agent

    if agent:
        # Show specific agent memory
        for layer in ["warm/agents", "full/agents"]:
            path = memory_base / layer / f"{agent}.md"
            if not path.exists():
                path = memory_base / layer / f"{agent}_full.md"
            if path.exists():
                info(f"=== {layer}/{path.name} ===")
                content = path.read_text()
                # Truncate if too long
                if len(content) > 2000:
                    print(content[:2000] + "\n... (truncated)")
                else:
                    print(content)
                return 0
        error(f"No memory found for agent '{agent}'")
        return 1

    # Show overview
    info(f"Memory structure for '{project_name}':")

    # Hot
    hot_path = memory_base / "hot" / "context.md"
    if hot_path.exists():
        size = len(hot_path.read_text())
        info(f"  hot/context.md: {size} chars")

    # Warm
    warm_dir = memory_base / "warm"
    if warm_dir.exists():
        for f in warm_dir.rglob("*.md"):
            size = len(f.read_text())
            rel = f.relative_to(warm_dir)
            info(f"  warm/{rel}: {size} chars")

    # Full
    full_dir = memory_base / "full"
    if full_dir.exists():
        episode_count = len(list((full_dir / "episodes").glob("*.json"))) if (full_dir / "episodes").exists() else 0
        info(f"  full/episodes/: {episode_count} episodes")

    return 0


def _clear_memory(sycli_dir: Path, project_name: str, args) -> int:
    """Clear memory for a specific agent or all."""
    memory_base = sycli_dir / "memory" / project_name
    agent = args.agent

    if not agent:
        error("Specify --agent to clear, or use --agent all to clear everything.")
        return 1

    if agent == "all":
        # Reset all memory to initial state
        for layer in ["hot", "warm", "full"]:
            layer_dir = memory_base / layer
            if layer_dir.exists():
                shutil.rmtree(layer_dir)
                layer_dir.mkdir(parents=True, exist_ok=True)
        success("All memory cleared.")
    else:
        # Clear specific agent
        cleared = False
        for path in [
            memory_base / "warm" / "agents" / f"{agent}.md",
            memory_base / "full" / "agents" / f"{agent}_full.md",
        ]:
            if path.exists():
                path.write_text(f"# {agent.title()} Memory\n\n(Cleared)\n")
                cleared = True
        if cleared:
            success(f"Memory cleared for agent '{agent}'")
        else:
            error(f"No memory found for agent '{agent}'")
            return 1

    return 0


def _export_memory(sycli_dir: Path, project_name: str, args) -> int:
    """Export memory to a portable file."""
    memory_base = sycli_dir / "memory" / project_name
    output_file = Path(args.file or f"{project_name}_memory.json")

    export_data = {"project": project_name, "layers": {}}

    # Collect all memory files
    for layer in ["hot", "warm"]:
        layer_dir = memory_base / layer
        if layer_dir.exists():
            export_data["layers"][layer] = {}
            for f in layer_dir.rglob("*.md"):
                rel = str(f.relative_to(layer_dir))
                export_data["layers"][layer][rel] = f.read_text()

    with open(output_file, "w") as f:
        json.dump(export_data, f, indent=2, ensure_ascii=False)

    success(f"Memory exported to {output_file}")
    return 0


def _import_memory(sycli_dir: Path, project_name: str, args) -> int:
    """Import memory from a portable file."""
    if not args.file:
        error("--file required for import")
        return 1

    input_file = Path(args.file)
    if not input_file.exists():
        error(f"File not found: {input_file}")
        return 1

    with open(input_file) as f:
        data = json.load(f)

    memory_base = sycli_dir / "memory" / project_name

    for layer, files in data.get("layers", {}).items():
        layer_dir = memory_base / layer
        layer_dir.mkdir(parents=True, exist_ok=True)
        for rel_path, content in files.items():
            path = layer_dir / rel_path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content)

    success(f"Memory imported from {input_file}")
    return 0
