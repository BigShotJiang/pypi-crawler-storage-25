"""sycli resume command - resume interrupted optimization."""

from __future__ import annotations

import asyncio
import json
import subprocess
from pathlib import Path

from sycli.core.backend import create_backend
from sycli.core.display import error, header, info, success, warning
from sycli.core.llm import create_llm
from sycli.models.config_models import SycliConfig
from sycli.mode.create import run_create
from sycli.mode.optimize import run_optimize


def _show_resume_summary(sycli_dir: Path, state: dict) -> None:
    """显示恢复前的进展摘要。"""
    # 尝试从 optimization_log.jsonl 读取最近事件
    log_file = sycli_dir / "optimization_log.jsonl"
    if log_file.exists():
        try:
            recent_events: list[dict] = []
            with open(log_file, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        recent_events.append(json.loads(line))
            # 只保留 round_end 事件
            round_ends = [e for e in recent_events if e.get("event") == "round_end"]
            if round_ends:
                info("最近轮次:")
                for ev in round_ends[-5:]:
                    data = ev.get("data", {})
                    r = ev.get("round", "?")
                    score = data.get("score", 0)
                    decision = data.get("decision", "?")
                    strategy = data.get("strategy", "")
                    info(f"  R{r}: score={score:.3f}, decision={decision}, strategy={strategy}")
        except Exception:
            pass

    # 从 rounds.json 读取最佳得分
    rounds_file = sycli_dir / "rl" / "rounds.json"
    if rounds_file.exists():
        try:
            with open(rounds_file) as f:
                rounds = json.load(f)
            if rounds:
                best = max(rounds, key=lambda r: r.get("score", 0))
                info(f"最佳轮次: R{best.get('round_number', '?')}, score={best.get('score', 0):.3f}")
                total_rounds = len(rounds)
                info(f"已完成轮次: {total_rounds}")
        except Exception:
            pass


def _verify_git_state(project_root: Path, state: dict) -> tuple[bool, str]:
    """验证 git 状态与记录一致。

    Returns:
        (is_consistent, message)
    """
    last_commit = state.get("last_git_commit", "")
    if not last_commit:
        return True, "无 git commit 记录（跳过校验）"

    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, cwd=str(project_root), timeout=10,
        )
        if result.returncode != 0:
            return True, "非 git 仓库（跳过校验）"

        current = result.stdout.strip()
        if current == last_commit:
            return True, f"git HEAD 一致 ({current[:8]})"

        # 检查是否有未提交的修改
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, cwd=str(project_root), timeout=10,
        )
        dirty = bool(status_result.stdout.strip())

        msg = f"git HEAD 不一致: 记录={last_commit[:8]}, 当前={current[:8]}"
        if dirty:
            msg += "（且有未提交修改）"
        return False, msg

    except (FileNotFoundError, subprocess.TimeoutExpired):
        return True, "git 不可用（跳过校验）"


def _get_git_head(project_root: Path) -> str:
    """获取当前 git HEAD commit hash。"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, cwd=str(project_root), timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return ""


def handle_resume(args) -> int:
    """Handle `sycli resume` command - resume an interrupted optimization."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"
    state_file = sycli_dir / "rl_state.json"
    config_path = sycli_dir / "sycli.json"

    if not state_file.exists():
        error("No previous state found. Run `sycli run` first.")
        return 1

    with open(state_file) as f:
        state = json.load(f)

    status = state.get("status")
    if status not in ("interrupted", "running", "max_rounds_reached"):
        error(f"Cannot resume from status: {status}")
        info("Only 'interrupted', 'running', or 'max_rounds_reached' states can be resumed.")
        return 1

    if not config_path.exists():
        error(".sycli/sycli.json not found.")
        return 1

    # Load config
    config = SycliConfig.load(config_path)
    config.project_root = str(project_root)

    issues = config.validate_config()
    if issues:
        for issue in issues:
            warning(issue)
        error("Configuration issues found. Fix .sycli/sycli.json or set env vars.")
        return 1

    mode = state.get("mode", "optimize")
    task = state.get("last_task", state.get("description", ""))
    if not task:
        error("No task description found in state. Run `sycli run \"task\"` instead.")
        return 1

    project_name = state.get("project", project_root.name)

    header(f"Resuming {mode.upper()} | {project_name}")
    info(f"From round: {state.get('current_round', 0)}")
    info(f"Best score: {state.get('best_reward', 0):.3f}")
    info(f"Status was: {status}")
    info(f"Task: {task}")

    # ── E4: 进展摘要 ──
    info("")
    info("── 进展摘要 ──")
    _show_resume_summary(sycli_dir, state)

    # ── E4: Git 状态校验 ──
    info("")
    info("── Git 状态校验 ──")
    is_consistent, git_msg = _verify_git_state(project_root, state)
    info(f"  {git_msg}")
    if not is_consistent:
        warning("代码可能已被外部修改，优化结果可能不可预测。")

    # Initialize components
    try:
        llm = create_llm(config.llm, streaming=True)
    except Exception as e:
        error(f"Failed to initialize LLM: {e}")
        return 1

    try:
        backend = create_backend(project_root)
    except Exception as e:
        error(f"Failed to create backend: {e}")
        return 1

    # Determine remaining rounds
    rounds_used = state.get("current_round", 0)
    max_rounds = config.rl.max_rounds
    remaining = max_rounds - rounds_used
    if remaining <= 0:
        warning(f"All {max_rounds} rounds already used.")
        info("Increase rl.max_rounds in sycli.json to continue.")
        return 1

    info(f"Remaining rounds: {remaining}")

    try:
        if mode == "create":
            state = asyncio.run(
                run_create(
                    config=config,
                    llm=llm,
                    backend=backend,
                    project_name=project_name,
                    sycli_dir=sycli_dir,
                    description=task,
                    max_rounds=max_rounds,  # engine will detect start_round from history
                )
            )
        else:
            state = asyncio.run(
                run_optimize(
                    config=config,
                    llm=llm,
                    backend=backend,
                    project_name=project_name,
                    sycli_dir=sycli_dir,
                    task_description=task,
                    max_rounds=max_rounds,
                )
            )
    except KeyboardInterrupt:
        warning("\nInterrupted again. State saved. Run `sycli resume` to continue.")
        return 0
    except Exception as e:
        error(f"Resume failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    if state.get("status") == "converged":
        success(f"Converged! Best score: {state['best_reward']:.3f}")

    return 0
