"""sycli chat command - interactive conversational RL loop.

Runs the same RL optimization loop as `sycli run` or `sycli create`, but
pauses between rounds for user interaction.  The user can:
  - continue / Enter  → proceed to next round
  - stop              → stop the loop
  - hint <text>       → inject a hint into the next round
  - skip              → skip the next round
  - status            → display current round / score info
"""

from __future__ import annotations

import asyncio
import signal
import sys
from pathlib import Path

from sycli.core.backend import create_backend
from sycli.core.display import (
    chat_banner,
    error,
    header,
    info,
    success,
    user_prompt,
    warning,
)
from sycli.core.llm import create_llm
from sycli.models.config_models import SycliConfig
from sycli.rl.engine import RLEngine

# ── Graceful shutdown ──

_shutdown_requested = False


def _signal_handler(sig, frame):
    global _shutdown_requested
    if _shutdown_requested:
        warning("\nForce quit.")
        sys.exit(1)
    _shutdown_requested = True
    warning("\nGraceful shutdown requested. Finishing current round...")


# ── Interactive callback ──


def _make_round_callback() -> tuple[callable, list[str]]:
    """Return an (on_round_end callback, accumulated_hints) pair.

    The callback is called by the engine after each round.  It prints a
    summary, shows the `sycli >` prompt, and waits for user input.
    """
    pending_hints: list[str] = []

    def on_round_end(summary: dict) -> str | None:
        global _shutdown_requested
        if _shutdown_requested:
            return "__stop__"

        round_num = summary["round"]
        score = summary["score"]
        prev_score = summary["prev_score"]
        best = summary["best_score"]
        passed = summary["tests_passed"]
        total = summary["tests_total"]
        decision = summary["decision"]

        delta = score - prev_score
        info(
            f"Round {round_num} done: {passed}/{total} passed, "
            f"score={score:.3f} ({delta:+.3f}), best={best:.3f} [{decision}]"
        )

        # Show prompt and loop until user says continue / stop
        while True:
            cmd = user_prompt()

            if not cmd or cmd == "continue":
                # Return any pending hints
                if pending_hints:
                    hint = " ".join(pending_hints)
                    pending_hints.clear()
                    return hint
                return None

            if cmd == "stop":
                return "__stop__"

            if cmd == "skip":
                # Skip: just continue without injecting anything
                pending_hints.clear()
                return None

            if cmd == "status":
                info(f"  Round:   {round_num}/{summary['max_rounds']}")
                info(f"  Score:   {score:.3f} (best: {best:.3f})")
                info(f"  Tests:   {passed}/{total}")
                info(f"  Decision: {decision}")
                continue

            if cmd.startswith("hint "):
                hint_text = cmd[5:].strip()
                if hint_text:
                    pending_hints.append(hint_text)
                    success(f"Hint recorded: {hint_text}")
                continue

            warning(
                f"Unknown command: {cmd}. "
                "Use: continue | stop | hint <text> | skip | status"
            )

    return on_round_end, pending_hints


# ── Command handler ──


def handle_chat(args) -> int:
    """Handle `sycli chat` command."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"
    config_path = sycli_dir / "sycli.json"

    mode = getattr(args, "mode", "optimize") or "optimize"

    # Auto-init if needed (for create-mode first run)
    if not sycli_dir.exists() or not config_path.exists():
        if mode == "create":
            info("Initializing .sycli/ for CREATE mode...")
            from sycli.commands.init_cmd import handle_init
            import argparse
            init_args = argparse.Namespace(
                project_root=str(project_root),
                project_name=project_root.name,
                force=False,
            )
            handle_init(init_args)
            success(".sycli/ initialized")
        else:
            error(".sycli/ not found. Run `sycli init` first.")
            return 1

    # Load config
    config = SycliConfig.load(config_path)
    config.project_root = str(project_root)

    issues = config.validate_config()
    if issues:
        for issue in issues:
            warning(issue)
        error("Configuration issues found. Fix .sycli/sycli.json or set env vars.")
        return 1

    # Get task
    task = getattr(args, "task", None)
    if not task:
        if mode == "create":
            task = getattr(args, "description", "")
        if not task:
            error("Task description required. Usage: sycli chat \"your task\"")
            return 1

    project_name = args.project_name or project_root.name

    # Initialize components
    try:
        llm = create_llm(config.llm, streaming=True)
    except Exception as e:
        error(f"Failed to initialize LLM: {e}")
        return 1

    try:
        backend = create_backend(project_root)
    except Exception as e:
        error(f"Failed to create backend: {e}")
        return 1

    chat_banner()

    if mode == "create":
        return _chat_create(args, config, llm, backend, sycli_dir, project_root, project_name, task)
    else:
        return _chat_optimize(args, config, llm, backend, sycli_dir, project_root, project_name, task)


def _chat_optimize(args, config, llm, backend, sycli_dir, project_root, project_name, task) -> int:
    """Chat mode for OPTIMIZE."""
    engine = RLEngine(
        config=config,
        llm=llm,
        backend=backend,
        project_name=project_name,
        sycli_dir=sycli_dir,
    )

    max_rounds = getattr(args, "max_rounds", None) or config.rl.max_rounds
    on_round_end, _ = _make_round_callback()

    global _shutdown_requested
    _shutdown_requested = False
    signal.signal(signal.SIGINT, _signal_handler)

    try:
        state = asyncio.run(
            engine.run_loop(
                task_description=task,
                mode="optimize",
                max_rounds=max_rounds,
                on_round_end=on_round_end,
            )
        )
    except KeyboardInterrupt:
        warning("\nInterrupted. State saved. Run `sycli resume` to continue.")
        return 0
    except Exception as e:
        error(f"RL loop failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    _print_final_status(state)
    return 0


def _chat_create(args, config, llm, backend, sycli_dir, project_root, project_name, task) -> int:
    """Chat mode for CREATE."""
    from sycli.mode.create import run_create

    data_dir = Path(args.data).resolve() if getattr(args, "data", None) else None
    test_file = Path(args.test).resolve() if getattr(args, "test", None) else None
    template = getattr(args, "template", None)

    # CREATE mode doesn't use on_round_end directly (it has its own loop),
    # so we run it normally but still register signal handling.
    global _shutdown_requested
    _shutdown_requested = False
    signal.signal(signal.SIGINT, _signal_handler)

    try:
        state = asyncio.run(
            run_create(
                config=config,
                llm=llm,
                backend=backend,
                project_name=project_name,
                sycli_dir=sycli_dir,
                description=task,
                data_dir=data_dir,
                test_file=test_file,
                template=template,
            )
        )
    except KeyboardInterrupt:
        warning("\nInterrupted. State saved. Run `sycli resume` to continue.")
        return 0
    except Exception as e:
        error(f"CREATE mode failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    _print_final_status(state)
    return 0


def _print_final_status(state: dict) -> None:
    """Print final status after chat session ends."""
    status = state.get("status", "unknown")
    if status == "user_stopped":
        warning("Stopped by user.")
    elif status == "target_reached":
        success(f"Target accuracy reached! Score: {state['best_reward']:.3f}")
    elif status == "converged":
        success(f"Converged! Best score: {state['best_reward']:.3f}")
    else:
        warning(f"Session ended with status: {status}")

    info(f"Total rounds: {state.get('current_round', 0)}, Best: {state.get('best_reward', 0):.3f}")
    info("Run `sycli resume` to continue or `sycli history` to review rounds.")
