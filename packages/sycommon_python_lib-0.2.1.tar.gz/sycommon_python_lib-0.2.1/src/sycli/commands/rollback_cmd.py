"""sycli rollback command - revert to a previous round's checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from sycli.core.display import error, info, success, warning
from sycli.core.git_integration import git_rollback


def handle_rollback(args) -> int:
    """Handle `sycli rollback` command."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"
    state_file = sycli_dir / "rl_state.json"

    if not state_file.exists():
        error("No RL state found. Run `sycli run` first.")
        return 1

    with open(state_file) as f:
        state = json.load(f)

    history = state.get("history", [])
    if not history:
        error("No round history to rollback to.")
        return 1

    # Find target round
    target = args.step
    if target is None:
        # Default: rollback to best round
        target = state.get("best_round")
        if target is None:
            error("No best round found. Specify --step N.")
            return 1
        info(f"Rolling back to best round: {target}")

    # Use the shared git_rollback which properly reverts all post-target commits
    ok = git_rollback(project_root, target)
    if not ok:
        return 1

    # Update state
    state["current_round"] = target
    state["status"] = "rolled_back"
    with open(state_file, "w") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)

    success(f"Rolled back to round {target}")
    return 0
