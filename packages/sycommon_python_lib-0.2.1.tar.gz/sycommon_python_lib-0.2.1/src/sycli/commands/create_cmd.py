"""sycli create command - create project from description + data."""

from __future__ import annotations

import asyncio
from pathlib import Path

from sycli.core.backend import create_backend
from sycli.core.display import error, header, info, success, warning
from sycli.core.llm import create_llm
from sycli.mode.create import run_create
from sycli.models.config_models import SycliConfig


def handle_create(args) -> int:
    """Handle `sycli create` command."""
    project_root = Path(args.project_root or ".").resolve()
    sycli_dir = project_root / ".sycli"
    config_path = sycli_dir / "sycli.json"

    description = args.description
    if not description:
        error("Project description required. Usage: sycli create \"description\"")
        return 1

    data_dir = Path(args.data).resolve() if args.data else None
    test_file = Path(args.test).resolve() if args.test else None
    template = getattr(args, "template", None)

    # Validate data dir
    if data_dir and not data_dir.exists():
        error(f"Data directory not found: {data_dir}")
        return 1

    # Validate test file
    if test_file and not test_file.exists():
        error(f"Test file not found: {test_file}")
        return 1

    # Auto-init .sycli/ if not present
    if not sycli_dir.exists() or not config_path.exists():
        info("Initializing .sycli/ for CREATE mode...")
        from sycli.commands.init_cmd import handle_init
        init_args = _make_init_args(project_root, project_root.name)
        handle_init(init_args)
        success(".sycli/ initialized")

    # Load config
    config = SycliConfig.load(config_path)
    config.project_root = str(project_root)

    # Validate config
    issues = config.validate_config()
    if issues:
        for issue in issues:
            warning(issue)
        error("Configuration issues found. Fix .sycli/sycli.json or set env vars.")
        return 1

    project_name = project_root.name

    # Initialize components
    try:
        llm = create_llm(config.llm, streaming=True)
    except Exception as e:
        error(f"Failed to initialize LLM: {e}")
        return 1

    try:
        backend = create_backend(project_root)
    except Exception as e:
        error(f"Failed to create backend: {e}")
        return 1

    header(f"Creating project: {project_name}")
    info(f"Description: {description}")
    if data_dir:
        info(f"Data: {data_dir}")
    if test_file:
        info(f"Tests: {test_file}")
    if template:
        info(f"Template: {template}")

    try:
        state = asyncio.run(
            run_create(
                config=config,
                llm=llm,
                backend=backend,
                project_name=project_name,
                sycli_dir=sycli_dir,
                description=description,
                data_dir=data_dir,
                test_file=test_file,
                template=template,
            )
        )
    except KeyboardInterrupt:
        warning("\nInterrupted. State saved. Run `sycli resume` to continue.")
        return 0
    except Exception as e:
        error(f"CREATE mode failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    if state.get("status") == "converged":
        success(f"Project created successfully! Best score: {state['best_reward']:.3f}")
    else:
        warning(f"CREATE finished with status: {state.get('status')}")

    return 0


def _make_init_args(project_root: Path, project_name: str):
    """Create a namespace mimicking init args."""
    import argparse
    return argparse.Namespace(
        project_root=str(project_root),
        project_name=project_name,
        force=False,
    )
