"""CDP command handler — entry point for `sycli cdp` subcommand."""

from __future__ import annotations

import asyncio
import base64
import json
import sys
from pathlib import Path

from sycli.core.display import Colors, error, header, info, success, warning


def handle_cdp(args) -> int:
    """Handle `sycli cdp` command — synchronous entry point."""
    return asyncio.run(_async_handle_cdp(args))


async def _async_handle_cdp(args) -> int:
    from sycli.cdp.browser import BrowserLauncher, discover_ws_url
    from sycli.cdp.client import CDPClient

    port = getattr(args, "port", 9222)
    url = getattr(args, "url", None)
    launch = getattr(args, "launch", False)
    headless = getattr(args, "headless", True)
    cdp_action = getattr(args, "cdp_action", None)

    if not cdp_action:
        error("No CDP action specified. Use: screenshot, console, network, dom, performance, errors, interactive")
        print(f"  Example: sycli cdp screenshot --url https://example.com")
        return 1

    browser_proc = None

    try:
        # ── Launch browser if requested ──
        if launch:
            info("Launching headless Chrome ...")
            browser_proc = await BrowserLauncher.launch(
                port=port,
                headless=headless,
            )
            port = browser_proc.port
            success(f"Chrome launched on port {port}")

        # ── Discover WebSocket URL ──
        ws_url = await discover_ws_url(port)
        if not ws_url:
            error(f"No CDP target found on port {port}")
            if not launch:
                print(f"  Start Chrome with: google-chrome --remote-debugging-port={port}")
                print(f"  Or use: sycli cdp {cdp_action} --launch --url <url>")
            return 1

        # ── Connect ──
        client = CDPClient(ws_url)
        await client.connect()
        success(f"Connected to CDP target")

        # ── Navigate if URL given ──
        if url:
            from sycli.cdp.protocol import navigate
            info(f"Navigating to {url} ...")
            await navigate(client, url)
            success(f"Page loaded: {url}")

        # ── Dispatch to action ──
        if cdp_action == "screenshot":
            return await _do_screenshot(client, args)
        elif cdp_action == "console":
            return await _do_console(client, args)
        elif cdp_action == "network":
            return await _do_network(client, args)
        elif cdp_action == "dom":
            return await _do_dom(client, args)
        elif cdp_action in ("performance", "perf"):
            return await _do_performance(client, args)
        elif cdp_action == "errors":
            return await _do_errors(client, args)
        elif cdp_action == "interactive":
            from sycli.cdp.repl import run_repl
            return await run_repl(client)
        else:
            error(f"Unknown CDP action: {cdp_action}")
            return 1

    except FileNotFoundError as e:
        error(str(e))
        return 1
    except TimeoutError as e:
        error(str(e))
        return 1
    except KeyboardInterrupt:
        print()
        return 0
    except Exception as e:
        error(f"CDP error: {e}")
        return 1
    finally:
        if browser_proc:
            info("Closing browser ...")
            await browser_proc.terminate()


# ── Action implementations ────────────────────────────────────────────

async def _do_screenshot(client: CDPClient, args) -> int:
    from sycli.cdp.capabilities.screenshot import take_screenshot

    output = getattr(args, "output", None) or "screenshot.png"
    fmt = getattr(args, "format", "png")
    quality = getattr(args, "quality", 80)
    full_page = getattr(args, "full_page", False)
    selector = getattr(args, "selector", None)

    info(f"Capturing screenshot ({fmt}, full_page={full_page}) ...")
    data = await take_screenshot(
        client,
        format=fmt,
        quality=quality,
        full_page=full_page,
        selector=selector,
    )

    Path(output).write_bytes(data)
    success(f"Screenshot saved to {output} ({len(data)} bytes)")
    return 0


async def _do_console(client: CDPClient, args) -> int:
    from sycli.cdp.capabilities.console import capture_console

    duration = getattr(args, "duration", 5.0)
    evaluate = getattr(args, "evaluate", None)

    info(f"Capturing console for {duration}s ...")
    entries = await capture_console(client, duration=duration, evaluate=evaluate)

    if not entries:
        warning("No console output captured")
        return 0

    header("Console Output")
    for entry in entries:
        level = entry.get("type", "log")
        color = {
            "error": Colors.RED,
            "warning": Colors.YELLOW,
            "exception": Colors.RED,
        }.get(level, "")
        text = entry.get("text", "")
        print(f"  {color}[{level:>9}]{Colors.RESET} {text}")

    print(f"\n  Total: {len(entries)} entries")
    return 0


async def _do_network(client: CDPClient, args) -> int:
    from sycli.cdp.capabilities.network import capture_network

    duration = getattr(args, "duration", 10.0)
    url_filter = getattr(args, "filter", None)
    include_body = getattr(args, "include_body", False)

    info(f"Capturing network for {duration}s ...")
    entries = await capture_network(
        client,
        duration=duration,
        url_filter=url_filter,
        include_body=include_body,
    )

    if not entries:
        warning("No network requests captured")
        return 0

    header("Network Requests")
    print(f"  {'Method':<7} {'Status':<7} {'Size':>8}  {'URL'}")
    print(f"  {'─' * 7} {'─' * 7} {'─' * 8}  {'─' * 40}")

    for e in entries:
        method = e.get("method", "?")
        status = str(e.get("status") or "...")
        size = e.get("size")
        size_str = f"{size:,}" if size else "-"
        url = e.get("url", "")
        if len(url) > 80:
            url = url[:77] + "..."
        if e.get("failed"):
            status = f"{Colors.RED}FAIL{Colors.RESET}"
        print(f"  {method:<7} {status:<7} {size_str:>8}  {url}")

        if include_body and e.get("body"):
            body = e["body"]
            if len(body) > 200:
                body = body[:200] + "..."
            print(f"  {'':>7} {'':>7} {'':>8}  {Colors.DIM}Body: {body}{Colors.RESET}")

    print(f"\n  Total: {len(entries)} requests")

    # Summary
    failed = sum(1 for e in entries if e.get("failed"))
    errors = sum(1 for e in entries if e.get("status") and e.get("status", 0) >= 400)
    if failed or errors:
        print(f"  {Colors.YELLOW}Failed: {failed}, HTTP errors: {errors}{Colors.RESET}")

    return 0


async def _do_dom(client: CDPClient, args) -> int:
    from sycli.cdp.capabilities.dom import query_dom

    selector = args.selector
    info(f"Querying DOM: {selector}")

    result = await query_dom(client, selector)
    if not result.get("found"):
        warning(f"No element found for selector: {selector}")
        return 1

    html = result.get("outer_html", "")
    success(f"Found element (node_id={result['node_id']}):")
    if len(html) > 5000:
        html = html[:5000] + f"\n  ... (truncated, {len(html)} total chars)"
    print(f"  {html}")
    return 0


async def _do_performance(client: CDPClient, args) -> int:
    from sycli.cdp.capabilities.performance import get_performance_metrics

    info("Collecting performance metrics ...")
    result = await get_performance_metrics(client)
    highlights = result.get("highlights", {})

    if not highlights:
        warning("No performance metrics available")
        return 0

    header("Performance Metrics")
    for label, value in highlights.items():
        print(f"  {label:<30} {value}")
    return 0


async def _do_errors(client: CDPClient, args) -> int:
    from sycli.cdp.capabilities.page_errors import capture_errors

    duration = getattr(args, "duration", 5.0)
    info(f"Capturing errors for {duration}s ...")
    errors = await capture_errors(client, duration=duration)

    if not errors:
        success("No errors captured — page looks healthy")
        return 0

    header("Page Errors")
    for e in errors:
        msg = e.get("message", "")
        url = e.get("url", "")
        line = e.get("line", -1)
        col = e.get("column", -1)
        loc = f" ({url}:{line}:{col})" if url else ""
        print(f"  {Colors.RED}[{e.get('type', 'error')}]{Colors.RESET} {msg}{loc}")
        stack = e.get("stack", "")
        if stack:
            print(f"  {Colors.DIM}{stack}{Colors.RESET}")

    print(f"\n  Total: {len(errors)} errors")
    return 1 if errors else 0
