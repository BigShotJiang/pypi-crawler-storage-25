"""Interactive CDP REPL — run debugging commands in an interactive loop."""

from __future__ import annotations

import asyncio
import base64
import json
import sys
from pathlib import Path

from sycli.cdp.client import CDPClient
from sycli.core.display import Colors, error, info, success, warning


async def run_repl(client: CDPClient) -> int:
    """Run the interactive CDP debugging REPL."""
    _print_banner()

    while True:
        try:
            print(f"{Colors.MAGENTA}{Colors.BOLD}cdp > {Colors.RESET}", end="", flush=True)
            line = input().strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not line:
            continue
        if line in ("help", "h", "?"):
            _print_help()
            continue
        if line in ("quit", "exit", "q"):
            break

        parts = line.split(None, 1)
        cmd = parts[0]
        arg = parts[1] if len(parts) > 1 else ""

        try:
            if cmd == "screenshot":
                await _repl_screenshot(client, arg)
            elif cmd == "console":
                await _repl_console(client, arg)
            elif cmd == "network":
                await _repl_network(client, arg)
            elif cmd == "dom":
                if not arg:
                    error("Usage: dom <css-selector>")
                    continue
                await _repl_dom(client, arg)
            elif cmd in ("perf", "performance"):
                await _repl_performance(client)
            elif cmd == "errors":
                await _repl_errors(client, arg)
            elif cmd == "eval":
                if not arg:
                    error("Usage: eval <javascript-expression>")
                    continue
                await _repl_eval(client, arg)
            elif cmd == "navigate":
                if not arg:
                    error("Usage: navigate <url>")
                    continue
                await _repl_navigate(client, arg)
            elif cmd == "targets":
                await _repl_targets(client)
            else:
                error(f"Unknown command: {cmd}. Type 'help' for commands.")
        except Exception as e:
            error(f"Command failed: {e}")

    return 0


def _print_banner() -> None:
    print(f"\n{Colors.BOLD}{Colors.CYAN}── CDP Interactive REPL ──{Colors.RESET}")
    print(f"  Type {Colors.BOLD}help{Colors.RESET} for available commands, {Colors.BOLD}quit{Colors.RESET} to exit\n")


def _print_help() -> None:
    print(f"\n{Colors.BOLD}Available commands:{Colors.RESET}")
    print(f"  {Colors.CYAN}screenshot{Colors.RESET} [file.png]    Capture screenshot (default: screenshot.png)")
    print(f"  {Colors.CYAN}console{Colors.RESET} [seconds]       Capture console logs (default: 5s)")
    print(f"  {Colors.CYAN}network{Colors.RESET} [seconds]       Capture network requests (default: 10s)")
    print(f"  {Colors.CYAN}dom{Colors.RESET} <selector>           Query DOM element by CSS selector")
    print(f"  {Colors.CYAN}perf{Colors.RESET}                      Collect performance metrics")
    print(f"  {Colors.CYAN}errors{Colors.RESET} [seconds]         Capture page errors (default: 5s)")
    print(f"  {Colors.CYAN}eval{Colors.RESET} <expression>        Evaluate JavaScript expression")
    print(f"  {Colors.CYAN}navigate{Colors.RESET} <url>            Navigate to URL")
    print(f"  {Colors.CYAN}targets{Colors.RESET}                   List browser targets")
    print(f"  {Colors.CYAN}help{Colors.RESET}                      Show this help")
    print(f"  {Colors.CYAN}quit{Colors.RESET}                      Exit REPL\n")


async def _repl_screenshot(client: CDPClient, arg: str) -> None:
    from sycli.cdp.capabilities.screenshot import take_screenshot

    output = arg.strip() or "screenshot.png"
    info(f"Capturing screenshot → {output} ...")
    data = await take_screenshot(client)
    Path(output).write_bytes(data)
    success(f"Screenshot saved to {output} ({len(data)} bytes)")


async def _repl_console(client: CDPClient, arg: str) -> None:
    from sycli.cdp.capabilities.console import capture_console

    duration = float(arg) if arg else 5.0
    info(f"Capturing console for {duration}s (interact with the page if needed) ...")
    entries = await capture_console(client, duration=duration)

    if not entries:
        warning("No console output captured")
        return

    for entry in entries:
        level = entry.get("type", "log")
        color = {
            "error": Colors.RED,
            "warning": Colors.YELLOW,
            "exception": Colors.RED,
        }.get(level, Colors.RESET)
        text = entry.get("text", "")
        print(f"  {color}[{level:>9}]{Colors.RESET} {text}")


async def _repl_network(client: CDPClient, arg: str) -> None:
    from sycli.cdp.capabilities.network import capture_network

    duration = float(arg) if arg else 10.0
    info(f"Capturing network for {duration}s ...")
    entries = await capture_network(client, duration=duration)

    if not entries:
        warning("No network requests captured")
        return

    print(f"\n  {'Method':<7} {'Status':<7} {'Size':>8}  {'URL'}")
    print(f"  {'─' * 7} {'─' * 7} {'─' * 8}  {'─' * 40}")
    for e in entries:
        method = e.get("method", "?")
        status = str(e.get("status") or "...")
        size = e.get("size")
        size_str = f"{size}" if size else "-"
        url = e.get("url", "")
        # Truncate long URLs
        if len(url) > 80:
            url = url[:77] + "..."
        if e.get("failed"):
            status = f"{Colors.RED}FAIL{Colors.RESET}"
        print(f"  {method:<7} {status:<7} {size_str:>8}  {url}")
    print(f"\n  Total: {len(entries)} requests")


async def _repl_dom(client: CDPClient, selector: str) -> None:
    from sycli.cdp.capabilities.dom import query_dom

    info(f"Querying DOM: {selector}")
    result = await query_dom(client, selector)
    if not result.get("found"):
        warning(f"No element found for selector: {selector}")
        return
    html = result.get("outer_html", "")
    # Truncate very long HTML
    if len(html) > 2000:
        html = html[:2000] + f"\n  ... (truncated, {len(html)} total chars)"
    success(f"Found element (node_id={result['node_id']}):")
    print(f"  {html}")


async def _repl_performance(client: CDPClient) -> None:
    from sycli.cdp.capabilities.performance import get_performance_metrics

    info("Collecting performance metrics ...")
    result = await get_performance_metrics(client)
    highlights = result.get("highlights", {})

    if not highlights:
        warning("No performance metrics available")
        return

    success("Performance Metrics:")
    for label, value in highlights.items():
        print(f"  {label:<30} {value}")


async def _repl_errors(client: CDPClient, arg: str) -> None:
    from sycli.cdp.capabilities.page_errors import capture_errors

    duration = float(arg) if arg else 5.0
    info(f"Capturing errors for {duration}s ...")
    errors = await capture_errors(client, duration=duration)

    if not errors:
        success("No errors captured")
        return

    for e in errors:
        msg = e.get("message", "")
        url = e.get("url", "")
        line = e.get("line", -1)
        col = e.get("column", -1)
        loc = f" ({url}:{line}:{col})" if url else ""
        print(f"  {Colors.RED}[{e.get('type', 'error')}]{Colors.RESET} {msg}{loc}")
        stack = e.get("stack", "")
        if stack:
            print(f"  {Colors.DIM}{stack}{Colors.RESET}")


async def _repl_eval(client: CDPClient, expression: str) -> None:
    from sycli.cdp.protocol import evaluate_js

    result = await evaluate_js(client, expression)
    outcome = result.get("result", {})
    obj_type = outcome.get("type", "undefined")
    value = outcome.get("value")
    description = outcome.get("description", "")

    if obj_type == "undefined":
        print(f"  {Colors.DIM}undefined{Colors.RESET}")
    elif value is not None:
        text = json.dumps(value, indent=2, ensure_ascii=False) if isinstance(value, (dict, list)) else repr(value)
        print(f"  {text}")
    elif description:
        print(f"  {description}")
    else:
        print(f"  [{obj_type}]")

    # Show exception details if any
    exc_detail = result.get("exceptionDetails")
    if exc_detail:
        exc = exc_detail.get("exception", {})
        error(f"Exception: {exc.get('description', exc_detail.get('text', 'Unknown'))}")


async def _repl_navigate(client: CDPClient, url: str) -> None:
    from sycli.cdp.protocol import navigate

    info(f"Navigating to {url} ...")
    await navigate(client, url)
    success(f"Navigated to {url}")


async def _repl_targets(client: CDPClient) -> None:
    import aiohttp

    # Extract port from current ws_url
    # ws_url format: ws://localhost:PORT/devtools/page/...
    try:
        port_part = client._ws_url.split(":")[2].split("/")[0]
        port = int(port_part)
    except (IndexError, ValueError):
        port = 9222

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"http://localhost:{port}/json") as resp:
                targets = await resp.json()
                for t in targets:
                    ttype = t.get("type", "?")
                    title = t.get("title", "")
                    url = t.get("url", "")
                    active = "●" if t.get("webSocketDebuggerUrl") == client._ws_url else "○"
                    print(f"  {active} [{ttype}] {title[:50]}")
                    print(f"    {url}")
    except Exception as e:
        error(f"Failed to list targets: {e}")
