"""CDP WebSocket client — core protocol layer using aiohttp.

Manages message ID correlation, event dispatch, and connection lifecycle.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

import aiohttp

logger = logging.getLogger(__name__)


class CDPClient:
    """Async CDP WebSocket client backed by aiohttp."""

    def __init__(self, ws_url: str) -> None:
        self._ws_url = ws_url
        self._session: aiohttp.ClientSession | None = None
        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._msg_id = 0
        self._pending: dict[int, asyncio.Future[dict]] = {}
        self._event_handlers: dict[str, list[Callable[[dict], Any]]] = {}
        self._recv_task: asyncio.Task | None = None

    # ── Connection lifecycle ──────────────────────────────────────

    async def connect(self) -> None:
        self._session = aiohttp.ClientSession()
        self._ws = await self._session.ws_connect(
            self._ws_url,
            max_msg_size=16 * 1024 * 1024,  # 16 MB for large screenshots
            heartbeat=30,
        )
        self._recv_task = asyncio.create_task(self._recv_loop())
        logger.debug("CDP connected to %s", self._ws_url)

    async def close(self) -> None:
        if self._recv_task:
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass
            self._recv_task = None

        if self._ws and not self._ws.closed:
            await self._ws.close()

        if self._session and not self._session.closed:
            await self._session.close()

        # Cancel any pending futures
        for fut in self._pending.values():
            if not fut.done():
                fut.cancel()
        self._pending.clear()
        logger.debug("CDP connection closed")

    # ── Send commands ─────────────────────────────────────────────

    async def send(self, method: str, params: dict | None = None, timeout: float = 30.0) -> dict:
        """Send a CDP command and wait for the response."""
        if self._ws is None or self._ws.closed:
            raise RuntimeError("CDP client not connected")

        self._msg_id += 1
        msg_id = self._msg_id
        message: dict[str, Any] = {"id": msg_id, "method": method}
        if params:
            message["params"] = params

        loop = asyncio.get_running_loop()
        fut: asyncio.Future[dict] = loop.create_future()
        self._pending[msg_id] = fut

        await self._ws.send_json(message)
        logger.debug("CDP → %s %s", method, params or {})

        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            self._pending.pop(msg_id, None)
            raise TimeoutError(f"CDP command '{method}' timed out after {timeout}s") from None

    # ── Event handling ────────────────────────────────────────────

    def on_event(self, method: str, handler: Callable[[dict], Any]) -> None:
        """Register a handler for a CDP event (e.g. 'Runtime.consoleAPICalled')."""
        self._event_handlers.setdefault(method, []).append(handler)

    def remove_event_handler(self, method: str, handler: Callable[[dict], Any]) -> None:
        handlers = self._event_handlers.get(method, [])
        if handler in handlers:
            handlers.remove(handler)

    # ── Internal receive loop ─────────────────────────────────────

    async def _recv_loop(self) -> None:
        try:
            async for msg in self._ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    await self._dispatch(data)
                elif msg.type in (aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSED):
                    break
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("CDP receive loop error")

    async def _dispatch(self, data: dict) -> None:
        # Response to a command
        if "id" in data:
            fut = self._pending.pop(data["id"], None)
            if fut and not fut.done():
                if "error" in data:
                    fut.set_exception(
                        CDPError(data["error"].get("code", -1), data["error"].get("message", "Unknown CDP error"))
                    )
                else:
                    fut.set_result(data.get("result", {}))
            return

        # CDP event
        method = data.get("method")
        if method:
            params = data.get("params", {})
            handlers = self._event_handlers.get(method, [])
            for handler in handlers:
                try:
                    result = handler(params)
                    if asyncio.iscoroutine(result):
                        await result
                except Exception:
                    logger.exception("Event handler error for %s", method)


class CDPError(Exception):
    """Error returned by the CDP protocol."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        super().__init__(f"CDP error {code}: {message}")
