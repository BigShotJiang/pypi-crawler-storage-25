"""Browser launcher — find and start Chrome/Chromium with remote debugging.

Supports macOS, Linux, and Windows. Uses a temporary user data directory
and cleans up the process tree on termination.
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path

import aiohttp

logger = logging.getLogger(__name__)

# Platform-specific Chrome search paths
_CHROME_PATHS: dict[str, list[str]] = {
    "Darwin": [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
    ],
    "Linux": [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
        "/snap/bin/chromium",
    ],
    "Windows": [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ],
}


class BrowserProcess:
    """Manages a launched Chrome subprocess."""

    def __init__(self, process: subprocess.Popen, port: int, user_data_dir: str) -> None:
        self.process = process
        self.port = port
        self.user_data_dir = user_data_dir

    async def wait_for_ready(self, timeout: float = 10.0) -> None:
        """Poll the /json/version endpoint until Chrome is ready."""
        import time
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        f"http://localhost:{self.port}/json/version",
                        timeout=aiohttp.ClientTimeout(total=2),
                    ) as resp:
                        if resp.status == 200:
                            return
            except Exception:
                pass
            await asyncio.sleep(0.2)
        raise TimeoutError(f"Chrome did not become ready on port {self.port} within {timeout}s")

    async def terminate(self) -> None:
        """Terminate the Chrome process and clean up."""
        if self.process.poll() is None:
            try:
                import psutil
                parent = psutil.Process(self.process.pid)
                children = parent.children(recursive=True)
                for child in children:
                    try:
                        child.terminate()
                    except psutil.NoSuchProcess:
                        pass
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()
            except ImportError:
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()

        # Clean up temp directory
        if self.user_data_dir and os.path.exists(self.user_data_dir):
            try:
                shutil.rmtree(self.user_data_dir, ignore_errors=True)
            except Exception:
                pass


class BrowserLauncher:
    """Find and launch Chrome/Chromium with remote debugging enabled."""

    @staticmethod
    def find_chrome() -> str | None:
        """Return the path to a Chrome/Chromium executable, or None."""
        system = platform.system()
        paths = _CHROME_PATHS.get(system, [])

        for path in paths:
            if os.path.isfile(path):
                return path

        # Fallback to PATH lookup
        for name in ("google-chrome", "google-chrome-stable", "chromium-browser", "chromium", "chrome"):
            found = shutil.which(name)
            if found:
                return found

        return None

    @staticmethod
    async def launch(
        port: int = 0,
        headless: bool = True,
        extra_args: list[str] | None = None,
    ) -> BrowserProcess:
        """Launch Chrome and return a BrowserProcess handle.

        Args:
            port: Remote debugging port. 0 = auto-select an available port.
            headless: Run in headless mode.
            extra_args: Additional Chrome command-line arguments.
        """
        chrome_path = BrowserLauncher.find_chrome()
        if not chrome_path:
            raise FileNotFoundError(
                "Chrome/Chromium not found. Install Chrome or use --port to connect "
                "to an existing browser with --remote-debugging-port."
            )

        # Auto-select port if 0
        if port == 0:
            import socket
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("", 0))
                port = s.getsockname()[1]

        user_data_dir = tempfile.mkdtemp(prefix="sycli-cdp-")

        args = [
            chrome_path,
            f"--remote-debugging-port={port}",
            f"--user-data-dir={user_data_dir}",
            "--disable-gpu",
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-extensions",
            "--disable-background-networking",
            "--disable-sync",
            "--no-first-run",
            "--disable-default-apps",
        ]

        if headless:
            args.append("--headless=new")

        if extra_args:
            args.extend(extra_args)

        logger.debug("Launching Chrome: %s", " ".join(args))

        process = subprocess.Popen(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

        bp = BrowserProcess(process, port, user_data_dir)
        await bp.wait_for_ready()
        return bp


async def discover_ws_url(port: int, target_id: str | None = None) -> str | None:
    """Query /json endpoint to find a page's WebSocket debugger URL."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"http://localhost:{port}/json",
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                if resp.status != 200:
                    return None
                targets = await resp.json()
                if not isinstance(targets, list):
                    return None

                if target_id:
                    for t in targets:
                        if t.get("id") == target_id:
                            return t.get("webSocketDebuggerUrl")

                # Default: first page target
                for t in targets:
                    if t.get("type") == "page":
                        return t.get("webSocketDebuggerUrl")

                # Fallback: any target
                if targets:
                    return targets[0].get("webSocketDebuggerUrl")
    except Exception:
        return None
    return None
