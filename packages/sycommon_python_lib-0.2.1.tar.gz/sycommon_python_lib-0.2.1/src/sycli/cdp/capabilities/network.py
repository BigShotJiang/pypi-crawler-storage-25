"""Network capability — capture HTTP request/response traffic."""

from __future__ import annotations

import asyncio
from typing import Any

from sycli.cdp.client import CDPClient
from sycli.cdp.protocol import (
    disable_network,
    enable_network,
    get_response_body,
)


async def capture_network(
    client: CDPClient,
    duration: float = 10.0,
    url_filter: str | None = None,
    include_body: bool = False,
) -> list[dict[str, Any]]:
    """Capture network requests for a duration.

    Args:
        client: Connected CDP client.
        duration: How long to capture (seconds).
        url_filter: Optional URL substring filter.
        include_body: Fetch response bodies for text responses.

    Returns:
        List of network entries with request/response info.
    """
    entries: dict[str, dict[str, Any]] = {}

    def on_request(params: dict) -> None:
        req = params.get("request", {})
        rid = params.get("requestId", "")
        entries[rid] = {
            "request_id": rid,
            "method": req.get("method", ""),
            "url": req.get("url", ""),
            "headers": req.get("headers", {}),
            "request_type": params.get("type", ""),
            "timestamp": params.get("timestamp", 0),
            "status": None,
            "mime_type": None,
            "size": None,
            "timing": None,
            "body": None,
            "failed": False,
            "error_text": None,
        }

    def on_response(params: dict) -> None:
        rid = params.get("requestId", "")
        resp = params.get("response", {})
        if rid in entries:
            entries[rid]["status"] = resp.get("status")
            entries[rid]["mime_type"] = resp.get("mimeType", "")
            entries[rid]["size"] = resp.get("encodedDataLength") or resp.get("content", {}).get("size")
            entries[rid]["timing"] = resp.get("timing")

    def on_loading_finished(params: dict) -> None:
        rid = params.get("requestId", "")
        if rid in entries:
            entries[rid]["size"] = params.get("encodedDataLength", entries[rid]["size"])

    def on_loading_failed(params: dict) -> None:
        rid = params.get("requestId", "")
        if rid in entries:
            entries[rid]["failed"] = True
            entries[rid]["error_text"] = params.get("errorText", "")
            entries[rid]["canceled"] = params.get("canceled", False)

    # Enable network BEFORE any page activity
    client.on_event("Network.requestWillBeSent", on_request)
    client.on_event("Network.responseReceived", on_response)
    client.on_event("Network.loadingFinished", on_loading_finished)
    client.on_event("Network.loadingFailed", on_loading_failed)
    await enable_network(client)

    # If page is already loaded, reload to capture traffic
    try:
        from sycli.cdp.protocol import enable_page
        await enable_page(client)
        await client.send("Page.reload", {"ignoreCache": True})
    except Exception:
        pass

    await asyncio.sleep(duration)

    try:
        await disable_network(client)
    except Exception:
        pass

    # Fetch response bodies if requested
    results = list(entries.values())
    if include_body:
        for entry in results:
            if entry["failed"] or entry["status"] is None:
                continue
            mime = (entry.get("mime_type") or "").lower()
            if any(t in mime for t in ("text", "json", "javascript", "html", "xml", "css")):
                try:
                    body_result = await get_response_body(client, entry["request_id"])
                    body = body_result.get("body", "")
                    if body_result.get("base64Encoded"):
                        import base64
                        body = base64.b64decode(body).decode("utf-8", errors="replace")
                    entry["body"] = body[:10000]  # Truncate large bodies
                except Exception:
                    pass

    # Apply URL filter
    if url_filter:
        results = [e for e in results if url_filter in e.get("url", "")]

    return results
