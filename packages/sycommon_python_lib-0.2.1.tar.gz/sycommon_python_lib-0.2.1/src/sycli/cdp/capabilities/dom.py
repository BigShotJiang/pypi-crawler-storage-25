"""DOM capability — query and inspect DOM elements."""

from __future__ import annotations

from typing import Any

from sycli.cdp.client import CDPClient
from sycli.cdp.protocol import (
    enable_dom,
    enable_page,
    get_document,
    get_outer_html,
    query_selector,
)


async def query_dom(
    client: CDPClient,
    selector: str,
) -> dict[str, Any]:
    """Query a DOM element by CSS selector.

    Args:
        client: Connected CDP client.
        selector: CSS selector string.

    Returns:
        Dict with "selector", "node_id", "outer_html".
    """
    await enable_page(client)
    await enable_dom(client)

    doc = await get_document(client)
    root_node_id = doc.get("root", {}).get("nodeId", 0)

    result = await query_selector(client, root_node_id, selector)
    node_id = result.get("nodeId", 0)

    if node_id == 0:
        return {
            "selector": selector,
            "node_id": 0,
            "outer_html": None,
            "found": False,
        }

    html_result = await get_outer_html(client, node_id)
    return {
        "selector": selector,
        "node_id": node_id,
        "outer_html": html_result.get("outerHTML", ""),
        "found": True,
    }
