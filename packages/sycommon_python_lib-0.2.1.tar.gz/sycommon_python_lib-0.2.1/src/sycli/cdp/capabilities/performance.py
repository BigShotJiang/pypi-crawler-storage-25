"""Performance capability — collect Chrome performance metrics."""

from __future__ import annotations

from typing import Any

from sycli.cdp.client import CDPClient
from sycli.cdp.protocol import (
    disable_performance,
    enable_performance,
    evaluate_js,
    get_metrics,
)

# Key metrics to highlight
_KEY_METRICS = {
    "LayoutCount": "Layout Count",
    "RecalcStyleCount": "Style Recalc Count",
    "LayoutDuration": "Layout Duration (ms)",
    "RecalcStyleDuration": "Style Recalc Duration (ms)",
    "ScriptDuration": "Script Duration (ms)",
    "TaskDuration": "Task Duration (ms)",
    "JSHeapUsedSize": "JS Heap Used (MB)",
    "JSHeapTotalSize": "JS Heap Total (MB)",
    "Timestamp": "Timestamp",
    "DomContentLoaded": "DOM Content Loaded (ms)",
    "FirstMeaningfulPaint": "First Meaningful Paint (ms)",
    "NavigationStart": "Navigation Start",
}


async def get_performance_metrics(client: CDPClient) -> dict[str, Any]:
    """Collect Chrome performance metrics.

    Returns:
        Dict with "metrics" (name->value) and "highlights" (key metrics).
    """
    await enable_performance(client)

    result = await get_metrics(client)
    raw_metrics = result.get("metrics", [])

    metrics = {}
    for m in raw_metrics:
        name = m.get("name", "")
        value = m.get("value", 0)
        # Convert microseconds to milliseconds for duration metrics
        if "Duration" in name or "Paint" in name or "ContentLoaded" in name:
            value = round(value, 2)
        elif "Heap" in name:
            value = round(value / (1024 * 1024), 2)
        else:
            value = round(value, 2)
        metrics[name] = value

    # Build highlights with human-readable names
    highlights = {}
    for key, label in _KEY_METRICS.items():
        if key in metrics:
            highlights[label] = metrics[key]

    await disable_performance(client)

    return {
        "metrics": metrics,
        "highlights": highlights,
    }
