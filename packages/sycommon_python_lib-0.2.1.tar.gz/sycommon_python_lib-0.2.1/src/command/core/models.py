"""
CLI 数据模型
"""
from dataclasses import dataclass
from typing import Dict


# Agent 项目默认启用的功能
AGENT_DEFAULTS = {
    "database": True,
    "rabbitmq": True,
    "sse": True,
    "llm": True,
}


@dataclass
class FeatureOptions:
    """功能模块选项"""
    database: bool = False
    rabbitmq: bool = False
    nacos: bool = True  # 默认开启
    kafka_log: bool = True  # 默认开启
    sse: bool = False
    llm: bool = True  # 默认开启
    redis: bool = False  # Redis 缓存
    elasticsearch: bool = False  # Elasticsearch 日志/Token记录
    sentry: bool = True  # Sentry 错误监控，默认开启

    @classmethod
    def defaults_for(cls, project_type: str) -> "FeatureOptions":
        """根据项目类型返回推荐默认配置"""
        if project_type == "agent":
            return cls(**AGENT_DEFAULTS)
        return cls()

    def to_template_vars(self) -> dict:
        """转换为模板变量"""
        return {
            "feature_database": str(self.database).lower(),
            "feature_rabbitmq": str(self.rabbitmq).lower(),
            "feature_nacos": str(self.nacos).lower(),
            "feature_kafka_log": str(self.kafka_log).lower(),
            "feature_sse": str(self.sse).lower(),
            "feature_llm": str(self.llm).lower(),
            "feature_redis": str(self.redis).lower(),
            "feature_elasticsearch": str(self.elasticsearch).lower(),
            "feature_sentry": str(self.sentry).lower(),
        }

    def get_enabled_features(self) -> Dict[str, bool]:
        """获取所有启用的功能"""
        return {
            "database": self.database,
            "rabbitmq": self.rabbitmq,
            "nacos": self.nacos,
            "kafka_log": self.kafka_log,
            "sse": self.sse,
            "llm": self.llm,
            "redis": self.redis,
            "elasticsearch": self.elasticsearch,
            "sentry": self.sentry,
        }
