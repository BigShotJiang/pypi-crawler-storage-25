"""
数据库模型
"""
{% if feature_database == 'true' %}
from .entity import {{ safe_class_name }}Model

__all__ = ["{{ safe_class_name }}Model"]
{% endif %}
