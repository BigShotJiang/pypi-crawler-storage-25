{%- if feature_database == 'true' %}
"""
数据库服务层
"""
from sycommon.database.database_service import DatabaseService


class {{ safe_class_name }}Service:
    """数据库服务"""

    def __init__(self):
        self.db = DatabaseService.get_instance()

    def create(self, **kwargs):
        """创建记录"""
        # TODO: 实现创建逻辑
        pass

    def get_by_id(self, id: str):
        """根据 ID 查询"""
        # TODO: 实现查询逻辑
        pass

    def update(self, id: str, **kwargs):
        """更新记录"""
        # TODO: 实现更新逻辑
        pass

    def delete(self, id: str):
        """删除记录"""
        # TODO: 实现删除逻辑
        pass
{%- else %}
# 数据库功能未启用
# 如需使用数据库，请在初始化项目时添加 --with-db 参数
pass
{%- endif %}
