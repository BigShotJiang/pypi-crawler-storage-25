import traceback
from fastapi import APIRouter
from fastapi.responses import JSONResponse

from model.parse import QueryReq
from sycommon.logging.kafka_log import SYLogger
from sycommon.models.base_http import success_response


router = APIRouter()


@router.post('/v1/query')
async def query(req: QueryReq):
    """
    查询解析结果

    Args:
        req: QueryReq 请求参数（bizCode, fileList）

    Returns:
        JSON 响应
    """
    try:
        # TODO: 实现查询逻辑，从数据库查询解析结果
        return success_response(data=[], message="查询成功")
    except Exception as e:
        error_msg = f"查询失败: {str(e)}"
        SYLogger.error(traceback.format_exc())
        return JSONResponse(content={'code': 500, 'message': error_msg})
