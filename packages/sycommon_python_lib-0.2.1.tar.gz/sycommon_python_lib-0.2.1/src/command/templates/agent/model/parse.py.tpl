from typing import Optional
from pydantic import BaseModel, Field


class ParseReq(BaseModel):
    """解析请求"""
    bizCode: str = Field(..., description="业务编码")
    fileList: list[str] = Field(..., description="文件ID列表")
    isFlat: Optional[bool] = Field(False, description="是否进行一维解析，默认False")
    province: Optional[str] = Field(None, description="省份")
    city: Optional[str] = Field(None, description="城市")


class ParseResp(BaseModel):
    """解析响应"""
    pass


class QueryReq(BaseModel):
    """查询请求"""
    bizCode: str = Field(..., description="业务编码")
    fileList: list[str] = Field(..., description="文件ID列表")
