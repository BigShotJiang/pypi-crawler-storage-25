# {{ project_name }}

{{ project_name }} - AI Agent 服务

## 项目结构

```
{{ project_name }}/
├── agent/                  # Agent 核心模块
│   ├── __init__.py
│   ├── main_agent.py      # Agent 主入口
│   ├── enums/             # 枚举定义
│   │   └── node_type.py   # 节点类型
│   ├── nodes/             # 处理节点
│   │   └── example_node.py
│   └── states/            # 状态定义
│       └── agent_state.py
├── api/                   # API 路由
│   └── sse/
│       └── agent.py       # SSE 流式接口
├── model/                 # 数据模型
├── tools/                 # 工具函数
│   └── mq.py              # MQ 消息处理
├── client/                # 外部服务客户端
├── db/                    # 数据库层
│   ├── service.py         # 服务类
│   └── model/             # 数据库模型
├── app.py                 # 应用入口
├── app.yaml               # 应用配置
└── README.md

## 快速开始

### 安装依赖
```bash
pip install -r requirements.txt
```

### 启动服务
```bash
python app.py
```

### 测试接口

#### SSE 流式接口
```bash
curl -X POST http://localhost:{{ default_port }}/v1/sse/parse \
  -H "Content-Type: application/json" \
  -d '{"bizCode": "test", "fileList": ["file-id-1"]}'
```

#### 查询接口
```bash
curl -X POST http://localhost:{{ default_port }}/v1/query \
  -H "Content-Type: application/json" \
  -d '{"bizCode": "test", "fileList": ["file-id-1"]}'
```

## 部署说明

### Docker 构建
```bash
docker build -t {{ project_name }} .
docker run -p {{ default_port }}:{{ default_port }} {{ project_name }}
```

### Nacos 配置

1. 同步 nacos 配置 {{ project_name }}

2. 配置网关

```yaml
- id: "{{ project_name }}"
  uri: lb://{{ project_name }}
  filters:
    - AddRequestHeader=X-Request-Gateway,{{ short_project_name }}
    - StripPrefix=1
  predicates:
    - Path=/{{ short_project_name }}/**
```

## 核心依赖

- sycommon-python-lib: 公共基础库
- langgraph: Agent 状态图框架
- langchain: LLM 链式调用
