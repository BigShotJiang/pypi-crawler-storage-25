from typing import AsyncGenerator
from langgraph.graph import StateGraph, START

from agent.nodes.example_node import example_node
from agent.states.agent_state import AgentState
from model.parse import ParseReq
from sycommon.sse.sse import ServerSentEvent
from sycommon.logging.kafka_log import SYLogger


async def main_agent(data: ParseReq) -> AsyncGenerator[str, None]:
    """
    Agent 主入口

    构建状态图并流式返回处理结果

    Args:
        data: ParseReq 请求对象，包含 fileIds、business_no 等

    Yields:
        ServerSentEvent: SSE 事件流
    """
    # 构建状态图
    builder = StateGraph(AgentState)

    # 添加节点
    builder.add_node("example", example_node)
    # 如需添加更多节点：
    # builder.add_node("node_b", node_b_func)

    # 设置起始边：START -> 第一个节点
    builder.add_edge(START, "example")
    # 如需添加更多边：
    # builder.add_edge("example", "node_b")

    # 编译图
    agent = builder.compile()

    # 构建初始状态
    state = AgentState(
        fileIds=data.fileList,
        business_no=data.bizCode,
    )

    # 流式执行并返回 SSE 事件
    async for chunk in agent.astream(state, stream_mode="values"):
        yield ServerSentEvent(
            data=AgentState(**chunk).model_dump_json(),
            event="message",
            id="end"
        )
