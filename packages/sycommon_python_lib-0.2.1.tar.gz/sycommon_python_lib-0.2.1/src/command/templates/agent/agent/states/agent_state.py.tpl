from typing import List, Optional
from pydantic import BaseModel, Field


class AgentState(BaseModel):
    """
    Agent 状态定义

    在节点之间传递的共享状态，支持文件处理工作流
    """
    # 文件ID列表
    fileIds: List[str] = Field(default_factory=list, description="待处理文件ID列表")

    # 业务编号
    business_no: str = Field(default="", description="业务编号")

    # OCR/外部数据源结果（key: file_id）
    ocr_data: dict[str, list] = Field(default_factory=dict, description="OCR识别数据")

    # 文件分类结果（key: file_id）
    file_type_dict: dict[str, dict] = Field(default_factory=dict, description="文件分类结果")

    # 提取结果（key: file_id）
    results: dict[str, list] = Field(default_factory=dict, description="各文件提取结果")

    # 错误信息
    error: Optional[str] = None

    # 是否完成
    is_completed: bool = False
