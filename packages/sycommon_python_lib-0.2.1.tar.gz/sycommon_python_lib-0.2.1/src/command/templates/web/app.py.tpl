"""
{{ project_name }} - FastAPI Web 服务入口
创建时间: {{ create_time }}
作者: {{ author }}
"""
from fastapi import FastAPI
import uvicorn

# 路由导入
from api.echo import router as EchoRouter
{% if feature_sse == 'true' %}
from api.sse.echo import router as SSEEchoRouter
{% endif %}
{% if feature_rabbitmq == 'true' %}
from tools.mq import {{ safe_upper_name }}_QUEUE_NAME, handle_{{ safe_identifier }}_messages
{% endif %}

# 基础服务导入
from sycommon.services import Services
from sycommon.middleware.middleware import Middleware

# 条件导入 - 服务注册与配置
{% if feature_nacos == 'true' %}
from sycommon.synacos.nacos_service import NacosService
{% endif %}

# 条件导入 - 日志与监控
{% if feature_kafka_log == 'true' %}
from sycommon.logging.kafka_log import KafkaLogger
{% endif %}
# 条件导入 - 数据存储
{% if feature_database == 'true' %}
from sycommon.database.database_service import DatabaseService
{% endif %}
{% if feature_redis == 'true' %}
from sycommon.database.redis_service import RedisService
{% endif %}
{% if feature_elasticsearch == 'true' %}
from sycommon.database.elasticsearch_service import ElasticsearchService
{% endif %}

# 条件导入 - 消息队列
{% if feature_rabbitmq == 'true' %}
from sycommon.models.mqlistener_config import RabbitMQListenerConfig
from sycommon.models.mqsend_config import RabbitMQSendConfig
{% endif %}


app = Services.plugins(
    app=FastAPI(
        title="{{ project_name }} API",
        description="{{ project_name }} Web服务文档",
    ),
    # 注册中间件
    middleware=Middleware.setup_middleware,
{% if feature_nacos == 'true' %}
    # 注册Nacos服务
    nacos_service=NacosService.setup_nacos,
{% endif %}
{% if feature_kafka_log == 'true' %}
    # 注册日志服务
    logging_service=KafkaLogger.setup_logger,
{% endif %}
{% if feature_database == 'true' %}
    # 注册数据库服务
    database_service=(DatabaseService.setup_database, "{{ project_name }}"),
{% endif %}
{% if feature_redis == 'true' %}
    # 注册Redis缓存服务
    redis_service=RedisService.setup,
{% endif %}
{% if feature_elasticsearch == 'true' %}
    # 注册Elasticsearch服务
    elasticsearch_service=ElasticsearchService.init,
{% endif %}
{% if feature_rabbitmq == 'true' %}
    # 注册RabbitMQ监听器
    rabbitmq_listeners=[
        RabbitMQListenerConfig(
            queue_name={{ safe_upper_name }}_QUEUE_NAME,
            handler=handle_{{ safe_identifier }}_messages,
        ),
    ],
    # 注册RabbitMQ发送器
    rabbitmq_senders=[
        RabbitMQSendConfig(queue_name={{ safe_upper_name }}_QUEUE_NAME),
    ],
{% endif %}
)

# 注册路由
app.include_router(EchoRouter)
{% if feature_sse == 'true' %}
app.include_router(SSEEchoRouter)
{% endif %}


if __name__ == '__main__':
    uvicorn.run("app:app", **app.state.config)
