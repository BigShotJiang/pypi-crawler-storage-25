{%- if feature_rabbitmq == 'true' %}
"""
MQ 消息处理
"""
from sycommon.logging.kafka_log import SYLogger


# 队列名称
{{ safe_upper_name }}_QUEUE_NAME = "{{ project_name }}"


async def handle_{{ safe_identifier }}_messages(message: dict):
    """
    处理 MQ 消息

    Args:
        message: 消息内容
    """
    try:
        SYLogger.info(f"收到消息: {message}")
        # TODO: 实现实际的消息处理逻辑

    except Exception as e:
        SYLogger.error(f"处理消息失败: {str(e)}")
{%- else %}
# RabbitMQ 功能未启用
# 如需使用消息队列，请在初始化项目时添加 --with-mq 参数
pass
{%- endif %}
