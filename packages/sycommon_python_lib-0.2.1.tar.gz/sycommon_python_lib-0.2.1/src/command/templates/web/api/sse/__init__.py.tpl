"""
SSE 流式 API
"""
{% if feature_sse == 'true' %}
from .echo import router

__all__ = ["router"]
{% endif %}
