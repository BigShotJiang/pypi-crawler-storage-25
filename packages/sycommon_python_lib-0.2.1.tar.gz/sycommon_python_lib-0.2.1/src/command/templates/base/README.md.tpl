# {{ project_name }}

{{ project_name }} - 微服务项目

## 项目结构

```
{{ project_name }}/
├── api/                   # API 路由
├── model/                 # 数据模型
├── client/                # 外部服务客户端
├── app.py                 # 应用入口
├── app.yaml               # 应用配置
├── requirements.txt       # 依赖包
├── Dockerfile             # 容器化部署
└── README.md
```

## 快速开始

### 安装依赖
```bash
pip install -r requirements.txt
```

### 本地开发
```bash
# 配置 .env 文件
cp .env.example .env

# 启动服务
python app.py
```

### 健康检查
```bash
curl http://localhost:{{ default_port }}/health
```

## 部署说明

### Docker 构建
```bash
docker build -t {{ project_name }} .
docker run -p {{ default_port }}:{{ default_port }} {{ project_name }}
```

### Nacos 配置

1. 同步 test nacos 配置 {{ project_name }}

2. 配置网关

```yaml
- id: "{{ project_name }}"
  uri: lb://{{ project_name }}
  filters:
    - AddRequestHeader=X-Request-Gateway,{{ short_project_name }}
    - StripPrefix=1
  predicates:
    - Path=/{{ short_project_name }}/**
```
