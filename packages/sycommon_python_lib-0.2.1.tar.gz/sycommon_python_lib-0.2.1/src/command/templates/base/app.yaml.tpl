Name: {{ project_name }}
Host: 0.0.0.0
Port: {{ default_port }}
# 请求参数最大长度200M
MaxBytes: 209715200
# 请求超时时间60分钟
Timeout: 3600000
# 最大重试次数
MaxRetries: 3

Nacos:
  registerIp: nacos-wshh.syitservice.com
  namespaceId: test1
  groupName: DEFAULT_GROUP
  registerPort: 80
  registerGrpcPort: 9848
  notLoadCacheAtStart: true
  sharedConfigs:
    - dataId: common.yml
      group: DEFAULT_GROUP
      refresh: true
    - dataId: {{ project_name }}
      group: DEFAULT_GROUP
      refresh: true
    - dataId: mq.yml
      group: DEFAULT_GROUP
      refresh: true
    - dataId: llm
      group: DEFAULT_GROUP
      refresh: true