# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# Virtual environments
.venv/
venv/
ENV/

# IDE
.vscode/
.idea/
*.swp
*.swo

# Environment
.env

# Logs
*.log
logs/

# Cache
cache/
.pytest_cache/
.mypy_cache/

# Nacos local data
/nacos-data/

# Output
output/
tmp/

# OS
.DS_Store
Thumbs.db
