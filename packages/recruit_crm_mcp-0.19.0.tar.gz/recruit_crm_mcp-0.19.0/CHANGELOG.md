# CHANGELOG


## v0.19.0 (2026-05-01)

### Features

- **MAIN-806**: Default Sentry traces_sample_rate to 1.0
  ([#40](https://github.com/ebragas/recruitcrm-mcp/pull/40),
  [`46bd33e`](https://github.com/ebragas/recruitcrm-mcp/commit/46bd33ee2e506e0176475b2cdbdfe3154f3a1ec3))

* feat(MAIN-806): default Sentry traces_sample_rate to 1.0

Flips the empty/missing default for RECRUIT_CRM_MCP_SENTRY_TRACES_RATE from 0.0 to 1.0 so users with
  a DSN configured get the Sentry MCP Dashboard populated (per-tool request count, error rate, p95
  latency, client mix) without having to know about an extra env var. Without a DSN the MCP still
  makes zero network calls — the bring-your-own-DSN posture is unchanged.

Operators on tight Sentry quotas can dial sampling down via the env var or set 0.0 to disable
  tracing while keeping error capture.

* chore(MAIN-806): bump sentry-sdk[mcp] floor to 2.43.0

MCPIntegration requires sentry-sdk>=2.43.0 per the docs. Without this floor, the integration import
  succeeds but the MCP onboarding/verify step in Sentry won't recognize the events.

* feat(MAIN-806): stamp spans with per-process id for session grouping

The MCP stdio transport carries no native session ID, and FastMCP opens a fresh root trace for every
  tools/call, so out of the box there's no way to group calls made within one Claude Desktop launch.

Generate a UUID once per server boot and attach it as the recruit_crm_mcp.process_id tag on every
  span. Dashboards can then answer 'which tools get used together in one session' and 'what's the
  typical sequence' — useful for spotting tools that are always paired (e.g. a lookup before a
  write) and could be merged.

---------

Co-authored-by: Eric Bragas <eric@magicandco.agency>


## v0.18.2 (2026-05-01)

### Bug Fixes

- **MAIN-805**: Filter 4xx upstream-API errors from Sentry
  ([#39](https://github.com/ebragas/recruitcrm-mcp/pull/39),
  [`cbb6c5b`](https://github.com/ebragas/recruitcrm-mcp/commit/cbb6c5b13fb8f980b131baf8e2e946b5753f4d0f))

* chore: initialize branch for MAIN-805

* fix(MAIN-805): filter 4xx upstream-API errors from Sentry capture

Add a before_send hook that drops Sentry events whose root cause is a 4xx response from the Recruit
  CRM API. These are user-input errors (bad slugs, already-assigned candidates, etc.) the API
  surfaces correctly to the caller — they aren't production bugs and were eroding signal-to-noise in
  Sentry (PYTHON-6, PYTHON-8).

5xx, network errors, ValidationError, and unhandled exceptions still capture normally.

Implements MAIN-805.

---------

Co-authored-by: Eric Bragas <eric@magicandco.agency>

### Chores

- **release**: 0.18.2
  ([`d6c7196`](https://github.com/ebragas/recruitcrm-mcp/commit/d6c71963143dc6f874725392070e7ce10f8a9662))


## v0.18.1 (2026-05-01)

### Bug Fixes

- **MAIN-804**: Associations accepts JSON-encoded string args
  ([#38](https://github.com/ebragas/recruitcrm-mcp/pull/38),
  [`fcd4d46`](https://github.com/ebragas/recruitcrm-mcp/commit/fcd4d46483e6b922b43d791168b5f52a104798ff))

* fix(MAIN-804): Associations accepts JSON-encoded string args

Some MCP clients stringify nested object arguments before invoking tools/call — the captured Sentry
  event for create_note showed the client passing `associated` as the literal string '{"jobs":
  [...], "companies": [...]}' rather than as a JSON object. FastMCP's TypeAdapter rejected it under
  the Associations | None union before our handler ran, so the call failed with a Pydantic schema
  error.

Fix at the model boundary: Associations gets a model_validator(mode="before") that json.loads any
  string input. Bad JSON yields a clear "invalid JSON" error instead of an opaque schema error.

Cascades automatically to every tool that takes an Associations arg. Includes a
  TypeAdapter[Associations | None] test that exercises the exact union-mode path FastMCP uses on
  every tools/call.

Fixes PYTHON-7

* fix(MAIN-804): tighten Associations JSON-string validator (Copilot review)

Two related fixes from PR review:

- Drop "or null" from the error message. Stringified "null" doesn't actually round-trip to a valid
  Associations on a non-Optional call shape, so the wording was misleading.

- Reject valid JSON that isn't an object (array, scalar, parsed null) with the same clear "must be a
  JSON object" message. Previously these fell through to an opaque Pydantic schema error.

Adds two test cases pinning the new behavior.

---------

Co-authored-by: Eric Bragas <eric@magicandco.agency>

### Chores

- **release**: 0.18.1
  ([`a4d38e1`](https://github.com/ebragas/recruitcrm-mcp/commit/a4d38e18e72036eebfb58f1b61d46329c81ef99c))


## v0.18.0 (2026-05-01)

### Chores

- **release**: 0.18.0
  ([`cda0959`](https://github.com/ebragas/recruitcrm-mcp/commit/cda095912cf6a991b6758f2c40b2f0eb736dc353))

### Features

- **MAIN-802**: Clarify Conventional Commits requirement, ship pending releases
  ([#37](https://github.com/ebragas/recruitcrm-mcp/pull/37),
  [`3942d37`](https://github.com/ebragas/recruitcrm-mcp/commit/3942d3711babda85640c4b95de7c32a394f947d4))

Two merges since 0.17.0 (MAIN-797, MAIN-801) used "MAIN-NNN:" PR title prefixes that don't match
  Conventional Commits, so semantic-release silently skipped them and the fixes never reached PyPI.
  CLAUDE.md mandated the issue-ID prefix but never said it must also be Conventional Commits
  compliant — this commit closes that gap.

Doubles as the feat: trigger that bundles the two pending merges into 0.18.0: - MAIN-797:
  update_note tool + Markdown<->HTML normalization - MAIN-801: CompanySummary is_parent_company /
  is_child_company string types (Sentry PYTHON-5)

Co-authored-by: Eric Bragas <eric@magicandco.agency>


## v0.17.0 (2026-04-28)

### Chores

- **release**: 0.17.0
  ([`ef61712`](https://github.com/ebragas/recruitcrm-mcp/commit/ef6171258786aa51bbfd1931c85b17808dfb6019))

### Features

- Optional Sentry capture and report_issue tool
  ([#32](https://github.com/ebragas/recruitcrm-mcp/pull/32),
  [`1f67bb1`](https://github.com/ebragas/recruitcrm-mcp/commit/1f67bb15a09d85319670da5884d5e8df829cf2c4))

Adds two opt-in error reporting channels for end users of recruit-crm-mcp:

* Sentry auto-capture (bring-your-own-DSN) — `init_telemetry()` runs at server import, no-ops unless
  `RECRUIT_CRM_MCP_SENTRY_DSN` (or `SENTRY_DSN`) is set. Initializes Sentry's official
  `MCPIntegration(include_prompts=True)` plus `LoggingIntegration(event_level=None)` so each tool
  exception lands in the user's own Sentry project as a single event with full args, stack trace,
  and HTTPX breadcrumbs. No DSN is published or embedded. * `report_issue` MCP tool — builds a
  prefilled `github.com/ebragas/recruitcrm-mcp/issues/new` URL with summary, last error, and
  environment info. Long inputs are progressively shrunk (drop additional_context → mark trace
  truncated → trim summary) until the encoded URL fits under 7000 chars. * Installer/README now bake
  `--refresh-package recruit-crm-mcp` into the `args` so end users auto-update on Claude Desktop
  launch instead of staying stuck on the version that was installed first.

End-to-end verified against magic-co Sentry org with `0.17.0rc3` — single event captured with
  `release`, `environment`, tool name, args, and stack trace tags.

Closes MAIN-791


## v0.16.1 (2026-04-27)

### Bug Fixes

- Coerce JobSummary numeric fields from int to str
  ([#31](https://github.com/ebragas/recruitcrm-mcp/pull/31),
  [`ee9b005`](https://github.com/ebragas/recruitcrm-mcp/commit/ee9b005476aa2f097b9af0181a1526a47ecc18b1))

The Recruit CRM API returns minimum_experience, maximum_experience, min_annual_salary,
  max_annual_salary, pay_rate, and bill_rate as integers for some job records. JobSummary typed all
  six as str | None, so Pydantic v2 raised ValidationError on every list_jobs / search_jobs response
  containing such a record (e.g. Vandelay graphic designer: 80000 / 90000 / 0). The deployed MCP
  failed end-to-end before any write tool could be invoked.

Add coerce_numbers_to_str=True so Pydantic accepts both shapes from the API and stores them as
  strings. Adds a regression unit test covering the int payload.

Refs MAIN-790

Co-authored-by: Eric Bragas <eric@magicandco.agency>

### Chores

- **release**: 0.16.1
  ([`c788924`](https://github.com/ebragas/recruitcrm-mcp/commit/c788924002a3d7d714d95ab833f6d5f26d3218ad))


## v0.16.0 (2026-04-27)

### Bug Fixes

- **ci**: Exclude mcp_live tests from Release workflow
  ([#30](https://github.com/ebragas/recruitcrm-mcp/pull/30),
  [`e6cf5d8`](https://github.com/ebragas/recruitcrm-mcp/commit/e6cf5d8dc0fe31769afd7e330e63666790e21763))

Mirrors the exclusion already in ci.yml and publish-prerelease.yml. Without it, the post-merge
  Release run on main fails because mcp_live tests require RECRUIT_CRM_API_KEY, which is not wired
  into CI.

Co-authored-by: Eric Bragas <eric@magicandco.agency>

### Chores

- **release**: 0.16.0
  ([`8b9fb80`](https://github.com/ebragas/recruitcrm-mcp/commit/8b9fb80a0c55de27b83b1dba18b3f4d440263b12))

### Continuous Integration

- Add manual pre-release publish workflow
  ([`d3ae7eb`](https://github.com/ebragas/recruitcrm-mcp/commit/d3ae7eb1efd36f3ae32578ec14b4663a512ae499))

workflow_dispatch trigger that lints, runs unit tests, validates the input version is a PEP 440
  pre-release (aN/bN/rcN/.devN), pins it into pyproject.toml on the runner, builds, and publishes
  via the existing pypi trusted-publisher environment. Concurrency-serialized against the stable
  release workflow so the two can't race on PyPI.

Cherry-picked from fe3b9fc on the write-tools-pr1/meeting-note-task-lookups feature branch —
  separated into its own PR so the workflow becomes visible in the Actions UI before that feature
  branch merges, enabling pre-release testing of the in-flight write-surface changes.

### Features

- Avery Knapp write surface + pre-release CI
  ([#28](https://github.com/ebragas/recruitcrm-mcp/pull/28),
  [`3351ff2`](https://github.com/ebragas/recruitcrm-mcp/commit/3351ff29481e98896e00ac3b3b0ddeb06dd01c3d))

* feat: add write tools covering the full Avery Knapp transcript-to-CRM surface

Ships 21 MCP write tools, 11 lookup tools, and the CI infrastructure to dogfood them via pre-release
  PyPI publishes before cutting stable.

Write tools: - log_meeting / update_meeting - create_note / delete_note - create_task / update_task
  - create/update company, contact, job, candidate (inline custom_fields) -
  set_{company,contact,job,candidate}_custom_fields wrappers - assign_candidate / unassign_candidate
  / update_hiring_stage - upload_file (public URL via POST /v1/files multipart)

Lookup tools for every ID the write surface depends on: note/meeting/ task types, hiring pipelines +
  stages, contact stages, industries, and custom-field definitions for
  company/contact/job/candidate.

Scaffolding: EntityRef, Associations, LookupItem, WriteResult, and

CustomFieldValue Pydantic models. RecruitCrmError surfaces structured 4xx/5xx bodies to tool
  callers. _fetch_merge_post implements the "fetch -> merge -> POST" pattern the edit endpoints
  need. _request now supports multipart via post_multipart. Server layer adds _build_payload
  (None-strip + custom_fields serialization) and _write_result_from (title fallback for every entity
  kind).

CI: new .github/workflows/publish-prerelease.yml with manual

workflow_dispatch, PEP 440 regex gate, runner-side pyproject.toml version pin. Reuses the existing
  pypi trusted-publisher environment. Concurrency-grouped with the stable release workflow.

Docs: README adds "Installing a pre-release (test) build" and an

expanded Tools table. CLAUDE.md documents the maintainer-side pre-release flow and six new
  field-mapping gotchas for the write endpoints (inline custom_fields, 7-field job create,
  query-param assign/unassign, hiring-stage plural path, /files multipart, contact multi-company
  comma-separated company_slug).

Tests: 254 -> 320 unit tests. 13 new integration round-trips with

strict try/finally cleanup via DELETE endpoints (TestWriteSurface, TestCustomFieldsWrites,
  TestAssignmentWrites, TestFileUploadWrites).

* fix: harden write tools + add MCP-layer tests before Windows deploy

Closes the ship-blockers flagged in the multi-agent review and builds the missing test layer that
  exercises FastMCP dispatch end-to-end, so the Windows install call doesn't surface these on first
  real use.

- Partial POST replaces broken _fetch_merge_post across 6 update_* funcs (read shape diverges from
  write shape -> 422 on every associated_* field) - do_not_send_calendar_invites coerced to "1"/"0"
  (API rejects JSON false) - list_hiring_pipeline_stages reads status_id not docs' stage_id - 17
  write tools surface RecruitCrmError.body via fastmcp.ToolError - update_task gains task_type_id;
  mutable defaults, dead code, empty-id path, _fetch_merge_post, unused Pydantic models all cleaned
  up - tests/mcp/ harness + 33 MCP-layer tests + expanded integration coverage (related_to_type
  variants, rejection guards, attendee round-trip) - make mcp-test, mcp-live-test, smoke;
  scripts/smoke.py via UvxStdioTransport - WINDOWS_PREDEPLOY.md checklist for clean-VM verification
  - CLAUDE.md gotchas document every live-API discovery

346 non-live + 15 integration + 5 live-MCP tests green.

* fix: address Copilot PR review comments

- _build_payload: let custom_fields=[] serialize (was treated same as None, blocking callers from
  intentionally clearing all custom-field values) - Associations: Field(default_factory=list) on all
  5 list fields (Pydantic idiom + static-analysis-friendly; Pydantic v2 already deep-copied but this
  matches house style) - _request: raise ValueError when both data and files passed instead of
  silently dropping data (misuse fails loudly) - test _ts(): microsecond precision to avoid
  collision under retry/concurrent runs within the same second

Adds 4 unit tests pinning the new semantics.

* fix: address Copilot round 2 review comments

- update_task: remove status param (silently ignored by API; was misleading MCP clients per
  CLAUDE.md gotcha) - 5 update_* docstrings: replace stale "GET+merge+POST" with accurate "partial
  POST" wording (CLAUDE.md explicitly discourages fetch-merge) - update_task docstring: same
  correction; mention status is read-only - scripts/smoke.py: handle both wrapped {"result": [...]}
  and direct list shapes from structured_content (FastMCP varies by tool return type) -
  publish-prerelease workflow: exclude mcp_live tests from CI (no live API key in CI environment;
  would fail unintended live writes) - test_calendar_invites docstring: clarify it tests raw client
  payloads, not the server tools (which now serialize bools to strings) - Update unit + MCP-layer
  tests to match new update_task signature

* fix: exclude mcp_live tests from CI + type job_location_type as string Literal

CI was running the live MCP-layer tests because `pytest -m "not integration"` doesn't exclude the
  `mcp_live` marker, causing 4 errors + 1 failure on every PR run when RECRUIT_CRM_API_KEY isn't
  available. Mirror the selector already used in publish-prerelease.yml: `not integration and not
  mcp_live`.

Also retype `job_location_type` on `create_job`/`update_job` to `Literal["0", "1", "2"] | None` so
  the MCP tool surface matches the API's documented string codes (per CLAUDE.md and the
  find-job-by-slug.md example), instead of forwarding an int verbatim. Update the create_job unit
  test to assert the string code in the outgoing payload.

* test(integration): add orphan sweep + canonical MCP-Test- prefix

Standardize every integration-test entity name to the canonical ``MCP-Test-<descriptor>-<uuid8>``
  format via a single ``_test_label()`` helper, and add a session-scope autouse sweep that searches
  each entity type for the prefix and deletes any leftovers at the end of every integration run.

The sweep is a backstop for orphans from crashed teardowns (process kill, transient delete error,
  assertion mid-cleanup chain) — every test still cleans up via try/finally first. It runs at
  session end (not start) to avoid clobbering in-progress entities from a concurrent run on the same
  tenant; a standalone ``make integration-sweep`` target covers ad-hoc pre-run cleanup.

Bypass: ``RECRUIT_CRM_SKIP_SWEEP=1 make integration-test`` for debugging

where you want to inspect leftovers manually.

* test(integration): add RECRUIT_CRM_KEEP_ENTITIES step-through mode

When set, monkey-patches client.delete and client.delete_note to no-op so test entities persist in
  the tenant for UI verification. Also implies SKIP_SWEEP so the session sweep doesn't delete what
  you wanted to inspect.

Workflow: uv run pytest -m integration --collect-only -q RECRUIT_CRM_KEEP_ENTITIES=1 uv run pytest
  <node_id> -v -s # verify in Recruit CRM UI make integration-sweep

Adds make integration-test-keep target as a shortcut.

* fix(integration): sync-wrap session sweep + log walkthrough findings

The session-scope async _orphan_sweep_session fixture errored with ScopeMismatch because
  anyio_backend is function-scoped (in tests/conftest.py). Sync-wrap the sweep with asyncio.run so
  it can stay session-scoped.

Also seed TODO.md with the issues surfaced during the test #1-#7 walkthrough on the live tenant:
  about_company create-path bug, read-after-write race in update round-trips, designation/Title
  naming mismatch, sweep needing per-entity confirmation, and tenant UI not surfacing several
  persisted fields.

---------

Co-authored-by: Eric Bragas <eric@magicandco.agency>


## v0.15.0 (2026-04-02)

### Bug Fixes

- Rename job_id to job_slug in get_assigned_candidates for consistency
  ([`2e82934`](https://github.com/ebragas/recruitcrm-mcp/commit/2e82934d1d73e3afc276dfb56446b4262e1d3f16))

The parameter was named job_id but passed as job_slug to the client, which was misleading. Renamed
  to match the client API and underlying endpoint path (/jobs/{job_slug}/assigned-candidates).

### Chores

- **release**: 0.15.0
  ([`f2513bd`](https://github.com/ebragas/recruitcrm-mcp/commit/f2513bd2c6540b56d524db3792d1ddfd5c19a5f6))

### Testing

- Add Literal validation tests for TaskCreate and MeetingCreate
  ([`df8aff5`](https://github.com/ebragas/recruitcrm-mcp/commit/df8aff516fc71650060e82b164f5a1812071ff34))


## v0.14.1 (2026-04-02)

### Bug Fixes

- Address Copilot review feedback
  ([`dc54104`](https://github.com/ebragas/recruitcrm-mcp/commit/dc54104db6150915800accd5f8d3f30c5354892e))

- Filter MSIX glob results to directories only (is_dir check) - Make cache-warming best-effort in
  install.sh (if/else vs set -e abort) - Check $LASTEXITCODE in install.ps1 cache-warming step

- Use is_dir() instead of exists() for Packages dir check
  ([`f6c0c35`](https://github.com/ebragas/recruitcrm-mcp/commit/f6c0c35cc74ddd5aca5213ba92da6cf29d02bf67))

- **install**: Detect Windows Store config path + pre-cache packages
  ([`b5a8a0d`](https://github.com/ebragas/recruitcrm-mcp/commit/b5a8a0dd82388f0140d854adba2d0cfad1872947))

Implements MAIN-624: Windows installer: wrong config path + first-run cold-start timeout

- Detect Windows Store (MSIX) sandboxed config path at
  %LOCALAPPDATA%/Packages/Claude_*/LocalCache/Roaming/Claude/ and prefer it over standard
  %APPDATA%/Claude/ when present - Add cache-warming step to install.ps1 and install.sh that
  pre-downloads uvx packages after install, preventing the 60-second timeout on first Claude Desktop
  launch

### Chores

- **release**: 0.14.1
  ([`1e2ed2e`](https://github.com/ebragas/recruitcrm-mcp/commit/1e2ed2e27bbfc79654805e62c8963e03b870695d))


## v0.14.0 (2026-04-02)

### Bug Fixes

- Address Copilot review feedback
  ([`326eda7`](https://github.com/ebragas/recruitcrm-mcp/commit/326eda748ee6db46dba00af4311ee31e2b6b3876))

- Swap PATH rebuild to standard Windows order (machine;user) - Replace exit 1 with Write-Error +
  return to avoid killing host session - Use ExecutionPolicy Bypass in review-first README
  instructions

- Normalize ExecutionPolicy casing to Bypass
  ([`604ccba`](https://github.com/ebragas/recruitcrm-mcp/commit/604ccbac9013c6cbd3c8a8887dfb3eb2e69db55a))

- Propagate uvx exit code in install.ps1
  ([`014ce11`](https://github.com/ebragas/recruitcrm-mcp/commit/014ce1159938e5b46cab0c3b5872807ff1a715ea))

### Chores

- Add .claude/worktrees/ to .gitignore
  ([`2edee11`](https://github.com/ebragas/recruitcrm-mcp/commit/2edee115c1f8dc2ec515551608dd9d5d0fbdb049))

- **release**: 0.14.0
  ([`08a371b`](https://github.com/ebragas/recruitcrm-mcp/commit/08a371b48ab619bae59dfbb289a59f442e2c8a18))

### Features

- Add Windows one-click install (install.ps1)
  ([`73b0598`](https://github.com/ebragas/recruitcrm-mcp/commit/73b05984b22bed567a2f757858e618b2ddbd7a06))

Implements MAIN-579: PowerShell bootstrap script that mirrors install.sh for Windows users. Installs
  uv if missing, refreshes PATH from registry, then delegates to the existing Python installer via
  uvx.

Updates README with side-by-side macOS/Windows install instructions.


## v0.13.0 (2026-03-04)

### Bug Fixes

- Add pydantic as explicit dep + test invalid related_to_type
  ([`c0a0fae`](https://github.com/ebragas/recruitcrm-mcp/commit/c0a0fae8d06cdc7bcefb7d1100d2523f1c3ac1da))

- Add pydantic>=2.0.0 to pyproject.toml dependencies (was only available as transitive dep via
  fastmcp) - Add test_invalid_related_to_type_raises to verify Literal constraint enforcement on
  NoteCreate

- Use correct Copilot reviewer name in workflow and skill
  ([`5617d92`](https://github.com/ebragas/recruitcrm-mcp/commit/5617d9225261c82d4c92867282d9d78013b49938))

The API requires `reviewers[]=Copilot` not `copilot-pull-request-reviewer`.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- Add rule to never include Co-Authored-By Claude in commits
  ([`1b145a5`](https://github.com/ebragas/recruitcrm-mcp/commit/1b145a50826cf2c49bd3ce0a58cba6d08c12dac6))

- Auto-request Copilot review in workflow and PR comments skill
  ([`e07df48`](https://github.com/ebragas/recruitcrm-mcp/commit/e07df48f8d145ed90008f4241de70754c46ef443))

Add Copilot review request step to the workflow in CLAUDE.md and ensure the review-pr-comments skill
  always re-requests Copilot review after pushing fixes.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Update uv.lock to match pyproject.toml version
  ([`c08ddea`](https://github.com/ebragas/recruitcrm-mcp/commit/c08ddeac3035b4e7f1fc071db03f92459c1d5fff))

- **release**: 0.13.0
  ([`de3c9bf`](https://github.com/ebragas/recruitcrm-mcp/commit/de3c9bf873224a5ee035b5870ea6f7953ef229fe))

### Features

- Add Pydantic models for API entities, replace _summarize_* functions
  ([`7f93f7f`](https://github.com/ebragas/recruitcrm-mcp/commit/7f93f7f7770b143457a100557a5775e6b79cff90))

Introduce structured Pydantic models for all Recruit CRM API entities: - 9 summary models with
  from_api_response() classmethods replacing ad-hoc _summarize_* dict functions in server.py - 6
  input models (extra="forbid") for future write operations - Comprehensive test coverage (53 model
  tests) - Updated server.py return types from list[dict] to list[ModelType] - Updated all test
  assertions from dict access to attribute access

- **client**: Add POST and DELETE support to HTTP client
  ([`119e117`](https://github.com/ebragas/recruitcrm-mcp/commit/119e117712eb9d5be1e7bbd74f6bcbbc9af4d105))

Extract shared _request() base method from get() to DRY up auth, rate-limit retry, and error
  handling. Add post() and delete() convenience wrappers.

The Recruit CRM API uses POST for both create and edit operations (not PUT/PATCH), so only post()
  and delete() are needed.

MAIN-170

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.12.0 (2026-03-04)

### Chores

- **release**: 0.12.0
  ([`02a2e6a`](https://github.com/ebragas/recruitcrm-mcp/commit/02a2e6a53811e88db5a2e19ea666da135d979fec))

### Features

- Add search_notes tool with ID short-circuit
  ([`a624b27`](https://github.com/ebragas/recruitcrm-mcp/commit/a624b27c787a951a76bd6d21a8cfbfd7642e593f))

Add search_notes MCP tool for searching and listing notes in Recruit CRM. Notes use integer `id`
  (not `slug`). The API uses `added_from/to` instead of `created_from/to` — the tool maps
  `created_from/to` params to `added_from/to` internally for a consistent user interface. API
  rejects related_to, related_to_type (422), and created_from (400).

Includes integration tests (8 raw API probes + 4 client-level), unit tests, client methods
  (search_notes, get_note), _summarize_note, and CLAUDE.md endpoint/gotcha documentation.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.11.0 (2026-03-04)

### Bug Fixes

- Correct test docstrings for filtered search tests
  ([`1e99bdc`](https://github.com/ebragas/recruitcrm-mcp/commit/1e99bdc3dfbe1363dec1172cea742b9b37d87811))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.11.0
  ([`25e2cc3`](https://github.com/ebragas/recruitcrm-mcp/commit/25e2cc369e04a3378ae0726355d394574eb22fbf))


## v0.10.0 (2026-03-04)

### Bug Fixes

- Rename get_contact param to contact_slug and handle null names
  ([`aca575c`](https://github.com/ebragas/recruitcrm-mcp/commit/aca575cdb7884b9253ef54603506e896a2034c7b))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Split search_contacts into get_contact + search_contacts
  ([`f7f7b73`](https://github.com/ebragas/recruitcrm-mcp/commit/f7f7b734b5ba4ef0a405b2c646a23a4021a8f246))

Extract a dedicated get_contact tool so each tool has a consistent return type, matching the
  established get_*/search_* pattern.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.10.0
  ([`295204d`](https://github.com/ebragas/recruitcrm-mcp/commit/295204dad5ce92375c8c22e8e747d1a98583f167))

### Testing

- Remove duplicate test_title_filter in meetings tests
  ([`a93d497`](https://github.com/ebragas/recruitcrm-mcp/commit/a93d49768fc4620768254d8f9b71ced5b88374d5))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Split get_meeting test from search_meetings tests
  ([`7997199`](https://github.com/ebragas/recruitcrm-mcp/commit/799719976e2c4601bc038ee3da604c7473fa250d))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.9.0 (2026-03-03)

### Chores

- **release**: 0.9.0
  ([`1386845`](https://github.com/ebragas/recruitcrm-mcp/commit/13868456ed91d61de261a2c0d0c1f888bd8258bb))


## v0.8.0 (2026-03-03)

### Bug Fixes

- Address PR review — clarify search_jobs docstring
  ([`965216c`](https://github.com/ebragas/recruitcrm-mcp/commit/965216cbc3cd33d2f05b3a636240cf7d40bff063))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Address PR review — test actual tool function via mocked client
  ([`d8c0dca`](https://github.com/ebragas/recruitcrm-mcp/commit/d8c0dca2a862c7c125c9ac1bb5740d0e6b928d13))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Address PR review — use _parse_dt in job date tests
  ([`bfac6ec`](https://github.com/ebragas/recruitcrm-mcp/commit/bfac6ecba603678da29bd4a380db57af39755e12))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.8.0
  ([`2801772`](https://github.com/ebragas/recruitcrm-mcp/commit/2801772fbe56e4665c526863807dd7cb8395dbe6))

### Features

- Add search_companies tool with slug short-circuit
  ([`9568a48`](https://github.com/ebragas/recruitcrm-mcp/commit/9568a48205564f245d26ddad81eafe1de64cca99))

Add search_companies MCP tool for searching and listing companies in Recruit CRM. Companies use slug
  identifiers. All documented search params verified via integration tests: company_name,
  created_from/to, updated_from/to, owner_id, sort_by/sort_order, exact_search, marked_as_off_limit,
  owner_name, owner_email.

Includes integration tests (12 raw API probes + 4 client-level), unit tests, client methods
  (search_companies, get_company), _summarize_company, and CLAUDE.md endpoint/gotcha documentation.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Add search_contacts tool with slug short-circuit
  ([`d2eabb5`](https://github.com/ebragas/recruitcrm-mcp/commit/d2eabb5796e1758d118ea110449df4d22ad3cae8))

Add search_contacts MCP tool combining listing and searching contacts. When contact_slug is
  provided, short-circuits to return raw record. Otherwise searches via /contacts/search with
  filters or falls back to /contacts for no-filter listing. Integration tests discovered that
  designation filter is rejected (400) by the API.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Add search_meetings tool with ID short-circuit
  ([`154a83c`](https://github.com/ebragas/recruitcrm-mcp/commit/154a83cfd32a119ab7c0866a25ad457fae7702f4))

Add search_meetings MCP tool for searching and listing meetings in Recruit CRM. Meetings use integer
  `id` (not `slug`). Supported search params: title, created_from/to, updated_from/to,
  starting_from/to,

owner_id. API rejects related_to and related_to_type with 422.

Includes integration tests (raw API probes + client-level), unit tests, client methods
  (search_meetings, get_meeting), _summarize_meeting, and CLAUDE.md endpoint/gotcha documentation.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Add search_tasks tool with ID short-circuit
  ([`8830ded`](https://github.com/ebragas/recruitcrm-mcp/commit/8830ded6f8ed817dc30a2e8b3276f61fecd12097))

Add search_tasks MCP tool for searching and listing tasks in Recruit CRM. Tasks use integer `id`
  (not `slug`). Supported search params: title, created_from/to, updated_from/to, starting_from/to,
  owner_id. API rejects related_to and related_to_type with 422 (same as meetings).

Includes integration tests (10 raw API probes + 4 client-level), unit tests, client methods
  (search_tasks, get_task), _summarize_task, and CLAUDE.md endpoint/gotcha documentation.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.7.0 (2026-03-03)

### Bug Fixes

- Address PR review — fix docstring and test flakiness
  ([`160850d`](https://github.com/ebragas/recruitcrm-mcp/commit/160850db076169e821f27da2fb4416279d769a90))

- Update search_jobs docstring: filters are optional, empty list with no filters (not a hard
  requirement) - Derive date filter cutoffs from existing data in integration tests instead of
  hardcoding, with pytest.skip on empty results

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Address PR review — fuzzy country assertion and flaky date test
  ([`2c86a18`](https://github.com/ebragas/recruitcrm-mcp/commit/2c86a18a1594385df65f1a718babb4f0a92beab4))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Address PR review — handle naive/Z timestamps in date tests
  ([`f90693e`](https://github.com/ebragas/recruitcrm-mcp/commit/f90693e301531ef1cba75f4e7b3c6da2c5348996))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Main-153 replace broken search_candidates query parameters
  ([`d833ba8`](https://github.com/ebragas/recruitcrm-mcp/commit/d833ba8053b11df33e95eec318fc2d562ff2e3ca))

Replace non-functional query/city/job_title params with first_name/last_name that the
  /candidates/search endpoint actually supports. Fix email filter to route to /candidates/search
  instead of /candidates. Remove per_page from search endpoint calls (causes 400). Add default
  sort_by=updated_at for the no-filter fallback path.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Remove vacuous assertion in test_returns_results
  ([`8090bd0`](https://github.com/ebragas/recruitcrm-mcp/commit/8090bd08f34dba29efdb8e364ef8f3764a70ec25))

The `assert len(results) > 0` inside `if results:` was always true.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.7.0
  ([`5d98ad6`](https://github.com/ebragas/recruitcrm-mcp/commit/5d98ad6fecac6539c968f44fc15fb44e2aa53531))

### Continuous Integration

- Fix pypi-publish workflow using invalid dist-path input
  ([`2acc0bc`](https://github.com/ebragas/recruitcrm-mcp/commit/2acc0bc722104bad4e3a95e9ccf80c40cbe1a3cd))

MAIN-89: Replace `dist-path` with `packages-dir` in the pypa/gh-action-pypi-publish

step to eliminate the "Unexpected input" warning on every release run.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Features

- Main-151 add state, country, and date filters to search_candidates
  ([`eba78e2`](https://github.com/ebragas/recruitcrm-mcp/commit/eba78e24afc1d57bb2fb71e5ac4f2b4f5f27c551))

Add state, country, created_from, created_to, updated_from, updated_to params to search_candidates.
  Remove sort_by/sort_order which the live API rejects with 422 despite being listed in docs. Fix
  pre-existing 422 on the /candidates list fallback caused by hardcoded sort defaults.

Add integration tests verifying filter correctness (country, state, date range, combined filters)
  and rejection guard tests for sort params. Update CLAUDE.md with API gotchas and TDD workflow for
  new API params.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Main-155 expand search_jobs response fields, add date/owner filters and list_users tool
  ([`6710fd5`](https://github.com/ebragas/recruitcrm-mcp/commit/6710fd5c211b8dcc1201cd981f69fb6e6931b1a1))

Add 12 new fields to job summaries (salary, experience, location type, description, etc.), date
  range and owner_id filters to search_jobs, and a new list_users tool for discovering owner IDs.

Also fix pre-existing trio test failures by switching asyncio.sleep to anyio.sleep and restricting
  test backend to asyncio-only (removes trio dependency).

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Main-156 add get_assigned_candidates tool
  ([`cc9be8a`](https://github.com/ebragas/recruitcrm-mcp/commit/cc9be8a10e1775aec9ceecf2405d01822d3417b9))

Add tool to retrieve candidates assigned to a job with their hiring stage via GET
  /jobs/{slug}/assigned-candidates. Supports status_id filtering and client-side limit enforcement.
  Reuses _summarize_candidate for consistent output with search_candidates.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Refactoring

- Extract _extract_results helper, fix _job_location_label, remove description from job summary
  ([`b94637c`](https://github.com/ebragas/recruitcrm-mcp/commit/b94637c123845d187f48f20e4c6e175e22c094fa))

- Extract _extract_results() to deduplicate 4 identical response-parsing blocks in client.py - Fix
  _job_location_label None handling: replace str(None) accidental fallthrough with explicit guard -
  Remove job_description_text from _summarize_job — large HTML payloads belong in get_job/job
  description resource, not list/search summaries

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Testing

- Remove duplicate email filter test
  ([`37e04c3`](https://github.com/ebragas/recruitcrm-mcp/commit/37e04c323e4fac92b9e825727acdb8375822b034))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.6.2 (2026-02-26)

### Bug Fixes

- **client**: Update search_candidates docstring to match behavior
  ([`ac76f91`](https://github.com/ebragas/recruitcrm-mcp/commit/ac76f912ebb5b4713e60cc0e589cafdd8bd5a29c))

Filters are optional, not required — align client docstring with the server docstring updated in the
  previous commit.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- **docs**: Address PR review comments on search/list tools
  ([`829a579`](https://github.com/ebragas/recruitcrm-mcp/commit/829a5793c6777e297abf3505c997b906dbcff7c2))

- Remove unverified "reverse chronological order" claim from list_candidates - Update
  search_candidates docstring to reflect actual behavior (no filters = empty list) - Guard
  integration test against falsy first_name

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- **search**: Don't send per_page to search endpoint, add list_candidates
  ([`7b394b2`](https://github.com/ebragas/recruitcrm-mcp/commit/7b394b2520497d570bee8aea932d54e53a9aabe5))

The /candidates/search endpoint rejects per_page with 400. It also returns [] with no filters, so a
  separate list_candidates function (hitting /candidates) is needed for unfiltered browsing.

Adds integration tests that confirm the MAIN-85 fix: filters actually narrow results, and different
  filters produce different result sets.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- **search**: Use correct API endpoint and params for candidate search
  ([`e5b740d`](https://github.com/ebragas/recruitcrm-mcp/commit/e5b740d5bd6475cc2a8a3208ae9a00d254a87f35))

search_candidates was hitting /candidates (list endpoint) for field filters, which silently ignores
  all filter params. Now always uses /candidates/search with the params the API actually supports:
  first_name, last_name, email, country, state.

Removes unsupported params (query, city, job_title) that never worked.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- Gitignore fetched API docs
  ([`7b2eebc`](https://github.com/ebragas/recruitcrm-mcp/commit/7b2eebcae07a2eae062a77473865729a2f69f123))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Merge main and reconcile remote branch
  ([`92bda65`](https://github.com/ebragas/recruitcrm-mcp/commit/92bda654e27eebac4b36a7cbcc9b6a03e8e2af22))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Merge main into MAIN-85/fix-candidate-search
  ([`c5e8067`](https://github.com/ebragas/recruitcrm-mcp/commit/c5e8067ffcd1eb8cc84fc833df562167c7cfa005))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- **release**: 0.6.2
  ([`6f4f73a`](https://github.com/ebragas/recruitcrm-mcp/commit/6f4f73a25583ad7c23e8663bc1dc1aca7c438d75))

### Documentation

- Update CLAUDE.md to reflect eager client init pattern
  ([`66cebbf`](https://github.com/ebragas/recruitcrm-mcp/commit/66cebbfc98f9fc21cce0d329d16a243fd9520c31))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Update README tools table for new search params
  ([`d2e7c1d`](https://github.com/ebragas/recruitcrm-mcp/commit/d2e7c1dd13f292352423ef4f17c254814b69c8a0))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Refactoring

- Merge list_jobs into find_jobs with dynamic status resolution
  ([`8b78b3e`](https://github.com/ebragas/recruitcrm-mcp/commit/8b78b3e83ea25138ceb907ffca6b18a00ca10fcf))

Replace list_jobs with find_jobs using the same pattern as find_candidates: filters present →
  /jobs/search, no filters → /jobs.

New filters: name, status, city, country, company_name. Status labels (e.g. "Open", "On Hold") are
  resolved to API integer IDs via /jobs-pipeline, cached for the session. Closed status (ID 0)
  returns a clear error since the API treats it as no-filter.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- Merge search_candidates and list_candidates into find_candidates
  ([`22404b7`](https://github.com/ebragas/recruitcrm-mcp/commit/22404b769879d4c629528f9827ac124eef5d1165))

Single tool that routes internally: filters present → /candidates/search, no filters → /candidates.
  Simpler agent UX — one intent, one tool.

Also extracts _extract_results helper to DRY up response parsing.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- **client**: Eagerly init httpx client, document sibling error
  ([`ce0f3f5`](https://github.com/ebragas/recruitcrm-mcp/commit/ce0f3f53d84d35d07fafb7080782eb6aba37c138))

"Sibling tool call errored" is a Claude Code client-side behavior — when one parallel tool call
  fails, Claude Code cancels the siblings. The root cause was the broken filters in MAIN-85/MAIN-87
  causing tool errors that cascaded. No server concurrency bug exists.

Eagerly initializes the httpx AsyncClient in the server lifespan handler instead of lazy-init,
  making the lifecycle explicit.

Documents API quirks and concurrency notes in CLAUDE.md.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.6.1 (2026-02-26)

### Chores

- Merge main into MAIN-87/fix-jobs-status-filter
  ([`ae2e976`](https://github.com/ebragas/recruitcrm-mcp/commit/ae2e976b29e34a03bf33a39314cd0bf68b34640c))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- **release**: 0.6.1
  ([`d6223b7`](https://github.com/ebragas/recruitcrm-mcp/commit/d6223b73fb6d7735be3e0d60d80854a93d6159e2))


## v0.6.0 (2026-02-26)

### Bug Fixes

- **jobs**: Use /jobs/search with job_status param for status filtering
  ([`6fb484e`](https://github.com/ebragas/recruitcrm-mcp/commit/6fb484e85b6be63d52d4a150ad4ff0464f55faec))

list_jobs was hitting /jobs which silently ignores filter params. Now split into list_jobs
  (unfiltered browse via /jobs) and search_jobs (filtered search via /jobs/search with job_status,
  name, city, country, company_name).

Status labels (Open, Closed, etc.) are mapped to the integer IDs the API expects. Note: "Closed" (ID
  0) is unsearchable due to an API quirk where 0 is treated as no-filter.

Also adds no-backward-compat convention to CLAUDE.md and gitignores fetched API docs.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.6.0
  ([`424da7a`](https://github.com/ebragas/recruitcrm-mcp/commit/424da7a971308b8f33cb558e0cc4f79df82f6bd6))

### Features

- Add per-endpoint API docs fetcher replacing monolithic spec
  ([`98bbc93`](https://github.com/ebragas/recruitcrm-mcp/commit/98bbc93330ed207ed405bebf0ca75a2ed303ee43))

Replace the bash script that downloaded an 850KB monolithic OpenAPI spec with a Python script that
  fetches individual endpoint, article, and model docs from Stoplight into organized files under
  docs/recruitcrm/.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Refactoring

- **scripts**: Address PR review on fetch_api_docs
  ([`117e6ad`](https://github.com/ebragas/recruitcrm-mcp/commit/117e6adbe08bddb8e337638d86665e31943d9b5c))

- Add empty-string fallback in slugify - Filter failed items from _index.json instead of leaving
  empty paths - Remove unused endpoint_filename function - Replace unreachable return with
  RuntimeError

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.5.1 (2026-02-26)

### Bug Fixes

- **install**: Use absolute path to uvx in Claude Desktop config
  ([`7bfa346`](https://github.com/ebragas/recruitcrm-mcp/commit/7bfa34645134d8920fe6a1c43d7591eafa30f96d))

Claude Desktop doesn't inherit the user's shell PATH, so a bare "uvx" command fails. Resolve the
  absolute path via shutil.which() during installation and write that to the config instead.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.5.1
  ([`704ac59`](https://github.com/ebragas/recruitcrm-mcp/commit/704ac59143f09b83e57cd4280f4c4e404fff911e))


## v0.5.0 (2026-02-26)

### Chores

- **release**: 0.5.0
  ([`8d68ace`](https://github.com/ebragas/recruitcrm-mcp/commit/8d68ace1d6bd154da5ff9d86b821da11abea942e))

### Features

- Add curl | bash bootstrap installer and remove chmod on config
  ([#7](https://github.com/ebragas/recruitcrm-mcp/pull/7),
  [`84a8b4a`](https://github.com/ebragas/recruitcrm-mcp/commit/84a8b4a97aba5da5e82b02283cd3c8b6e20ba98d))

* fix(install): remove chmod 0o600 on Claude Desktop config file

The installer was setting restrictive permissions on claude_desktop_config.json after writing it.
  This is an opinionated change that could conflict with Claude Desktop's own expectations for its
  config file. The file already lives in the user's Application Support directory which is
  user-scoped on macOS.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

* feat(install): add curl | bash bootstrap script

Adds install.sh that installs uv if missing, sources the env file so uvx is available immediately
  (no terminal restart), then hands off to the interactive Python installer via uvx.

One-liner for end users: curl -LsSf
  https://raw.githubusercontent.com/ebragas/recruitcrm-mcp/main/install.sh | bash

* fix(install): add curl preflight check and download-then-run option

- Add curl availability check at the top of install.sh with clear error - Add download-then-review
  alternative in README for security-conscious users

* fix(install): remove redundant curl preflight check

curl is the delivery mechanism for the script itself, so checking for it inside the script is
  unnecessary.

---------

Co-authored-by: Eric Bragas <eric@ebragas.com>

Co-authored-by: Claude Opus 4.6 <noreply@anthropic.com>


## v0.4.0 (2026-02-26)

### Bug Fixes

- **client**: Cap Retry-After at 120s, move imports to module level
  ([`ae298a3`](https://github.com/ebragas/recruitcrm-mcp/commit/ae298a3b31f329ba5cf8cca2979087605008683e))

- Cap Retry-After header value at 120s to match X-RateLimit-Reset behavior - Move time import to
  module level in client.py - Move time and logging imports to module level in test_client.py - Add
  tests for Retry-After cap and X-RateLimit-Reset in the past

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.4.0
  ([`2694cff`](https://github.com/ebragas/recruitcrm-mcp/commit/2694cff6801d6b2a49077ec129ff33349b0d67ec))

### Features

- **client**: Add rate limit handling with retry on 429
  ([`97ba5af`](https://github.com/ebragas/recruitcrm-mcp/commit/97ba5afd8a30f8ed518b2e5e314fff1db2296312))

Catch 429 responses in client.get(), parse Retry-After / X-RateLimit-Reset headers for wait
  duration, log a warning, and retry once. If the second attempt also fails, the error is raised to
  the caller.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.3.0 (2026-02-26)

### Bug Fixes

- Simplify uv install guidance for non-technical users
  ([`b7a6e17`](https://github.com/ebragas/recruitcrm-mcp/commit/b7a6e173b746a66b8cfcfd7d07b3ccac99e48bf1))

Drop Homebrew reference (target users won't have it) and default the auto-install prompt to Yes so
  users can just press Enter.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

- **install**: Harden installer and boost test coverage to 92%
  ([`c89f8db`](https://github.com/ebragas/recruitcrm-mcp/commit/c89f8db566b9b2e06e264b4ccde76f560fbc941c))

- Fix PATH detection after uv auto-install (advise restart instead of failing) - Add graceful
  handling for invalid JSON in existing config - Add explicit UTF-8 encoding for file I/O (Windows
  portability) - Set restrictive file permissions (0600) on config containing API key - Wrap main()
  in KeyboardInterrupt handler for clean Ctrl+C exit - Guard __main__.py with if __name__ ==
  "__main__" - Add tests for prompt_install_uv, _auto_install_uv, main() flow, and invalid JSON —
  coverage 47% → 92%

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.3.0
  ([`5160e07`](https://github.com/ebragas/recruitcrm-mcp/commit/5160e075b1787becd09f19ed114e08e6636d2649))

### Continuous Integration

- Add conventional commit message validation hook
  ([`8e36b6c`](https://github.com/ebragas/recruitcrm-mcp/commit/8e36b6c96fdeb79abf64e6473778bf3a1f7962e1))

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Features

- Add one-click installer for Claude Desktop configuration
  ([`fa92dbf`](https://github.com/ebragas/recruitcrm-mcp/commit/fa92dbf6ba7d48e95578480c8356d4de9a969442))

Interactive CLI wizard that prompts for the Recruit CRM API key, detects OS, locates
  claude_desktop_config.json, backs up existing config, and injects the MCP server entry. Runnable
  via `uvx --from recruit-crm-mcp recruit-crm-mcp-install` or `python -m recruit_crm_mcp`.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.2.0 (2026-02-25)

### Bug Fixes

- Run uv build in workflow instead of semantic-release container
  ([`965326f`](https://github.com/ebragas/recruitcrm-mcp/commit/965326fc5a7bd8dd3248288a5b050428180187dc))

The semantic-release Docker container doesn't have uv installed, so build_command = "uv build"
  fails. Disable building inside the action and run uv build as a separate workflow step where uv is
  available.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### Chores

- **release**: 0.2.0
  ([`b9f0cab`](https://github.com/ebragas/recruitcrm-mcp/commit/b9f0cab82adf6c08099efedf46b5e5d8f1d87889))

### Features

- Add semantic versioning with auto-publish on merge to main
  ([`97676ba`](https://github.com/ebragas/recruitcrm-mcp/commit/97676ba766e548250e1b5ceaaab3c2ca864359ca))

Replace tag-based publish workflow with python-semantic-release. Version bumps are now driven by
  conventional commits — fix: for patch, feat: for minor, BREAKING CHANGE for major. On merge to
  main, the workflow analyzes commits, bumps pyproject.toml, creates a GitHub Release, and publishes
  to PyPI automatically.

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>


## v0.1.0 (2026-02-25)
