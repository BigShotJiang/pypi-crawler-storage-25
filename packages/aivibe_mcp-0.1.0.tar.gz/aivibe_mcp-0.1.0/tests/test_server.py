"""Tests for the MCP server tool definitions."""

import json
from unittest.mock import patch

from aivibe_mcp.server import (
    check_recos_freshness,
    get_organization,
    get_survey,
    get_survey_results,
    get_team,
    get_team_summary,
    list_organizations,
    list_surveys,
    list_teams,
)

MOCK_RESPONSE = json.dumps([{"id": 1, "name": "Test"}], indent=2)


class TestTools:
    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_organizations(self, mock_get) -> None:
        result = list_organizations()
        mock_get.assert_called_once_with("/api/platform/orgs")
        assert "Test" in result

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_organization(self, mock_get) -> None:
        result = get_organization(1)
        mock_get.assert_called_once_with("/api/platform/orgs/1")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_surveys_no_filter(self, mock_get) -> None:
        list_surveys()
        mock_get.assert_called_once_with("/api/diagnose/surveys", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_surveys_with_org(self, mock_get) -> None:
        list_surveys(org_id=5)
        mock_get.assert_called_once_with("/api/diagnose/surveys", params={"organization_id": 5})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey(self, mock_get) -> None:
        get_survey("abc-123")
        mock_get.assert_called_once_with("/api/diagnose/surveys/abc-123")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_results(self, mock_get) -> None:
        get_survey_results("abc-123")
        mock_get.assert_called_once_with("/api/diagnose/reporting/analytics/abc-123")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_no_filter(self, mock_get) -> None:
        list_teams()
        mock_get.assert_called_once_with("/api/map/teams", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_with_org(self, mock_get) -> None:
        list_teams(org_id=3)
        mock_get.assert_called_once_with("/api/map/teams", params={"organization_id": 3})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team(self, mock_get) -> None:
        get_team(42)
        mock_get.assert_called_once_with("/api/map/teams/42")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_summary(self, mock_get) -> None:
        get_team_summary(42)
        mock_get.assert_called_once_with("/api/map/reporting/teams/42/summary")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_check_recos_freshness(self, mock_get) -> None:
        check_recos_freshness()
        mock_get.assert_called_once_with("/api/recos/freshness")
