"""AIVibe MCP server — read-only tools for querying platform data."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from aivibe_mcp.client import api_get

mcp = FastMCP("aivibe")


@mcp.tool()
def list_organizations() -> str:
    """List all accessible organizations. Names are anonymized (shown as org codes)."""
    return api_get("/api/platform/orgs")


@mcp.tool()
def get_organization(org_id: int) -> str:
    """Get organization details by ID."""
    return api_get(f"/api/platform/orgs/{org_id}")


@mcp.tool()
def list_surveys(org_id: int | None = None) -> str:
    """List surveys, optionally filtered by organization ID."""
    params = {"organization_id": org_id} if org_id is not None else None
    return api_get("/api/diagnose/surveys", params=params)


@mcp.tool()
def get_survey(survey_id: str) -> str:
    """Get survey details by ID."""
    return api_get(f"/api/diagnose/surveys/{survey_id}")


@mcp.tool()
def get_survey_results(survey_id: str) -> str:
    """Get survey analytics and results summary."""
    return api_get(f"/api/diagnose/reporting/analytics/{survey_id}")


@mcp.tool()
def list_teams(org_id: int | None = None) -> str:
    """List teams, optionally filtered by organization ID."""
    params = {"organization_id": org_id} if org_id is not None else None
    return api_get("/api/map/teams", params=params)


@mcp.tool()
def get_team(team_id: int) -> str:
    """Get team details by ID."""
    return api_get(f"/api/map/teams/{team_id}")


@mcp.tool()
def get_team_summary(team_id: int) -> str:
    """Get team reporting summary."""
    return api_get(f"/api/map/reporting/teams/{team_id}/summary")


@mcp.tool()
def check_recos_freshness() -> str:
    """Check data freshness for recommendations."""
    return api_get("/api/recos/freshness")


def main() -> None:
    """Entry point for the MCP server (stdio transport)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
