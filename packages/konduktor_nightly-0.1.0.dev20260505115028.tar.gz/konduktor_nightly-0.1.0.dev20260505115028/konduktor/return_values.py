"""Return-value plumbing for Konduktor jobs.

A workload reports a value by writing JSON to
``$KONDUKTOR_OUTPUT_DIR/result.json``. The launch-time pod wrapper reads that
file on exit and emits a small envelope to ``/dev/termination-log`` (kubelet
hoists it onto ``pod.status.containerStatuses[].state.terminated.message``).
The worker-cluster ``trainy-controller`` reconciler reads that message and
patches a ``KonduktorResult`` condition onto the owning JobSet's status.

This module watches that condition on the JobSet — **not** the pod status
directly. That's deliberate: the condition is what multikueue syncs
worker→manager, which is how the client gets a cross-cluster-safe result
without talking to any worker cluster itself.
"""

from __future__ import annotations

import enum
import json
import os
import time
from typing import Any, Dict, Optional

from konduktor import logging
from konduktor.backends import jobset_utils
from konduktor.utils import kubernetes_utils

logger = logging.get_logger(__name__)

KONDUKTOR_OUTPUT_DIR_ENV = 'KONDUKTOR_OUTPUT_DIR'
RESULT_FILENAME = 'result.json'

# Condition type the controller patches on the JobSet. Part of the public API
# contract between client and controller — don't rename without touching both.
KONDUKTOR_RESULT_CONDITION_TYPE = 'KonduktorResult'


class _Reason(str, enum.Enum):
    """Valid ``reason`` strings for the KonduktorResult condition.

    Values are the wire format — they appear verbatim in
    ``condition.reason`` on the JobSet. Authoritative source for the
    strings is the Go controller at
    ``trainy-controller/internal/controller/returnvalue_controller.go``
    (``reason*`` consts). Keep both sides in sync on any rename.

    Inherits from ``str`` so comparisons with raw condition values
    (``reason == _Reason.SUCCEEDED``) work without explicit ``.value``
    unwrapping — the enum member compares equal to its string value.
    """

    SUCCEEDED = 'Succeeded'
    FAILED = 'Failed'
    RESULT_TOO_LARGE = 'ResultTooLarge'
    MALFORMED_RESULT = 'MalformedResult'


# Kubelet enforces a 4 KB cap on `terminationMessagePath`. Leave headroom for
# the envelope wrapper itself (exit code, field names, JSON quoting).
_RESULT_SIZE_BUDGET_BYTES = 3500

_POLL_INTERVAL_SECONDS = 2.0

_EXPERIMENTAL_MESSAGE = (
    'EXPERIMENTAL: Job.result() / Job.wait() are new and may change in '
    'backwards-incompatible ways. See docs/return-values.mdx.'
)
_experimental_warned = False


def _warn_experimental_once() -> None:
    global _experimental_warned
    if _experimental_warned:
        return
    _experimental_warned = True
    logger.info(_EXPERIMENTAL_MESSAGE)


class KonduktorReturnError(Exception):
    """Base class for return-value retrieval errors."""


class JobFailedError(KonduktorReturnError):
    """The JobSet reached Failed without reporting a result."""


class ResultTooLargeError(KonduktorReturnError):
    """The workload wrote a result that exceeds the termination-message cap."""


class MalformedResultError(KonduktorReturnError):
    """The workload wrote ``result.json`` but it wasn't valid JSON."""


class NoResultReportedError(KonduktorReturnError):
    """The JobSet completed successfully but didn't write ``result.json``."""


class ResultTimeoutError(KonduktorReturnError, TimeoutError):
    """`Job.result(timeout=...)` elapsed before the job reached a terminal state."""


def report(value: Any, path: Optional[str] = None) -> None:
    """Write ``value`` as JSON to ``$KONDUKTOR_OUTPUT_DIR/result.json``.

    Optional convenience helper for Python workloads. Shell/Go/Rust jobs just
    write the file directly — no SDK needed in the workload image.

    Args:
        value: any JSON-serializable object.
        path: override path (defaults to ``$KONDUKTOR_OUTPUT_DIR/result.json``).
    """
    if path is None:
        output_dir = os.environ.get(KONDUKTOR_OUTPUT_DIR_ENV)
        if not output_dir:
            raise RuntimeError(
                f'{KONDUKTOR_OUTPUT_DIR_ENV} is not set; call konduktor.report() '
                'only from inside a Konduktor-launched job.'
            )
        path = os.path.join(output_dir, RESULT_FILENAME)
    with open(path, 'w') as f:
        json.dump(value, f)


def _condition_message_to_result(reason: str, message: str) -> Any:
    """Translate a ``KonduktorResult`` condition into a return value or raise.

    The condition's ``message`` field is always a JSON object. On success it's
    the reported value; on failure paths it carries error details.
    """
    try:
        payload = json.loads(message) if message else {}
    except json.JSONDecodeError as e:
        raise MalformedResultError(
            f'{_Reason.MALFORMED_RESULT.value}: KonduktorResult '
            f'condition.message was not JSON: {e}; raw: {message!r}'
        ) from e

    if reason == _Reason.SUCCEEDED:
        if isinstance(payload, dict) and payload.get('error') == 'NoResult':
            raise NoResultReportedError(
                'job completed successfully but did not write '
                f'$KONDUKTOR_OUTPUT_DIR/{RESULT_FILENAME}'
            )
        return payload
    if reason == _Reason.RESULT_TOO_LARGE:
        raise ResultTooLargeError(
            f'{_Reason.RESULT_TOO_LARGE.value}: workload result exceeded '
            f'{_RESULT_SIZE_BUDGET_BYTES} bytes (size={payload["size"]}); '
            'return a summary, not the full artifact.'
        )
    if reason == _Reason.MALFORMED_RESULT:
        raise MalformedResultError(
            f'{_Reason.MALFORMED_RESULT.value}: workload wrote invalid JSON '
            f'to result.json: {payload["reason"]}'
        )
    if reason == _Reason.FAILED:
        # Go controller emits Failed with a few shapes depending on what
        # it observed:
        #   - pod exited nonzero WITH termination message: {"exit": N}
        #   - pod exited without termination message (user ran
        #     ``exit N`` outside the envelope, or the wrapper crashed):
        #     {"error": "Failed", "reason": "..."}
        # Be lenient about which keys are present.
        detail: list[str] = []
        if 'exit' in payload:
            detail.append(f'exit={payload["exit"]}')
        if 'reason' in payload:
            detail.append(f'reason={payload["reason"]!r}')
        suffix = f' ({", ".join(detail)})' if detail else ''
        raise JobFailedError(f'{_Reason.FAILED.value}: job failed{suffix}')
    raise KonduktorReturnError(
        f'unknown KonduktorResult reason {reason!r}; message: {message!r}'
    )


def _find_konduktor_result_condition(
    jobset: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    """Return the KonduktorResult condition dict on a JobSet, or None."""
    status = jobset.get('status') or {}
    for cond in status.get('conditions') or []:
        if cond.get('type') == KONDUKTOR_RESULT_CONDITION_TYPE:
            return cond
    return None


def _jobset_terminal_state(namespace: str, job_name: str) -> Optional[str]:
    """Return 'succeeded'|'failed' if the JobSet is terminal, else None."""
    jobset = jobset_utils.get_jobset(namespace, job_name)
    if not jobset or 'status' not in jobset:
        return None
    repl_status = jobset['status'].get('replicatedJobsStatus') or []
    if not repl_status:
        return None
    if repl_status[0].get('succeeded'):
        return 'succeeded'
    if repl_status[0].get('failed'):
        return 'failed'
    return None


def _wait_for_result_condition(
    namespace: str,
    job_name: str,
    timeout: Optional[float],
) -> Dict[str, Any]:
    """Block until the JobSet has a KonduktorResult condition, return the dict.

    This is the cross-cluster-safe surface: under multikueue, Kueue's JobSet
    adapter syncs the condition from the worker's JobSet to the manager's,
    and clients talk only to the manager. Polling is fine for v1 — short
    interval, no streaming-watch complexity. Upgrade to a streaming watch if
    latency ever becomes the bottleneck.
    """
    deadline = time.monotonic() + timeout if timeout is not None else None
    while True:
        jobset = jobset_utils.get_jobset(namespace, job_name)
        if jobset is not None:
            cond = _find_konduktor_result_condition(jobset)
            if cond is not None:
                return cond
        if deadline is not None and time.monotonic() >= deadline:
            raise ResultTimeoutError(
                f'job {job_name!r} did not report a KonduktorResult condition '
                f'within {timeout}s'
            )
        time.sleep(_POLL_INTERVAL_SECONDS)


class Job(str):
    """Handle returned by :func:`konduktor.launch`.

    Subclasses ``str`` for back-compat: existing callers that do
    ``job_name = konduktor.launch(task)`` and treat the return as a string
    continue to work. New callers get ``.result()`` / ``.wait()``.
    """

    _namespace: Optional[str]
    _context: Optional[str]
    __slots__ = ('_namespace', '_context')

    def __new__(
        cls, name: str, namespace: Optional[str] = None, context: Optional[str] = None
    ) -> 'Job':
        obj = super().__new__(cls, name)
        obj._namespace = namespace
        obj._context = context
        return obj

    @property
    def name(self) -> str:
        return str(self)

    @property
    def namespace(self) -> str:
        # Cache the resolved namespace on first access — both
        # `result()` and `wait()` call this inside their polling loops
        # (every 2s), and each uncached call re-reads the kubeconfig
        # from disk. Once resolved, the kubeconfig isn't going to
        # change mid-poll; pin the value.
        if self._namespace:
            return self._namespace
        ctx = self._context or kubernetes_utils.get_current_kube_config_context_name()
        self._namespace = kubernetes_utils.get_kube_config_context_namespace(ctx)
        return self._namespace

    def wait(self, timeout: Optional[float] = None) -> str:
        """Block until the JobSet reaches a terminal state.

        Returns ``'succeeded'`` or ``'failed'``. Does not read the
        KonduktorResult condition — use :meth:`result` for that.
        """
        _warn_experimental_once()
        deadline = time.monotonic() + timeout if timeout is not None else None
        while True:
            state = _jobset_terminal_state(self.namespace, self.name)
            if state is not None:
                return state
            if deadline is not None and time.monotonic() >= deadline:
                raise ResultTimeoutError(
                    f'job {self.name!r} did not reach terminal state within {timeout}s'
                )
            time.sleep(_POLL_INTERVAL_SECONDS)

    def result(self, timeout: Optional[float] = None) -> Any:
        """Block until the KonduktorResult condition lands, return the value.

        Raises:
            JobFailedError: the JobSet failed without a successful result.
            ResultTooLargeError: the workload's result exceeded the 4 KB cap.
            MalformedResultError: the workload wrote non-JSON to result.json.
            NoResultReportedError: the JobSet succeeded but no result was written.
            ResultTimeoutError: ``timeout`` elapsed before the condition landed.
        """
        _warn_experimental_once()
        cond = _wait_for_result_condition(self.namespace, self.name, timeout)
        return _condition_message_to_result(
            cond.get('reason', ''),
            cond.get('message', ''),
        )
