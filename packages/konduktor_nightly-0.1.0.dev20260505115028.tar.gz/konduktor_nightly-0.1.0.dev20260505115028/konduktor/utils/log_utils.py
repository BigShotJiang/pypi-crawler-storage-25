# Proprietary Changes made for Trainy under the Trainy Software License
# Original source: skypilot: https://github.com/skypilot-org/skypilot
# which is Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import copy
import io
import json
import multiprocessing
import os
import subprocess
import sys
import time
import types
from typing import Any, Dict, List, Optional, Tuple, Type, Union

import colorama
import prettytable
import requests

from konduktor import logging
from konduktor.utils import kubernetes_utils, subprocess_utils

logger = logging.get_logger(__name__)


INFINITY = 999999
VICKY_NAMESPACE = 'victoria-logs'
VICKY_SERVICE = 'vls-victoria-logs-single-server'
VICKY_REMOTE_PORT = 9428
# Timeout in seconds for the --no-follow streaming read (per-chunk).
# 60s gives VL room to start streaming on a freshly-completed busy job
# (OTel ingest lag + index warmup) — observed needing >30s in CI on
# `python_api-*` jobs that just finished.
NO_FOLLOW_QUERY_TIMEOUT = 60
# Retry settings for --no-follow when VictoriaLogs returns empty results
# (log ingestion pipeline may have latency). Total wall-clock budget is
# roughly NO_FOLLOW_MAX_RETRIES * NO_FOLLOW_RETRY_DELAY seconds of sleeps
# plus query time. The previous kr8s PortForward path accidentally added
# ~6s of cold-start latency on the first attempt, which gave OTel→VL
# ingest extra time to catch up; with the service-proxy path that buffer
# is gone, so we increase retries and delay to restore the headroom that
# `python_api-*` smoke tests rely on (they query immediately after a
# job completes, while OTel is still flushing the last records).
NO_FOLLOW_MAX_RETRIES = 5
NO_FOLLOW_RETRY_DELAY = 4  # seconds between retries


class LineProcessor(object):
    """A processor for log lines."""

    def __enter__(self) -> None:
        pass

    def process_line(self, log_line: str) -> None:
        pass

    def __exit__(
        self,
        except_type: Optional[Type[BaseException]],
        except_value: Optional[BaseException],
        traceback: Optional[types.TracebackType],
    ) -> None:
        del except_type, except_value, traceback  # unused
        pass


class _ProcessingArgs:
    """Arguments for processing logs."""

    def __init__(
        self,
        log_path: str,
        stream_logs: bool,
        start_streaming_at: str = '',
        end_streaming_at: Optional[str] = None,
        skip_lines: Optional[List[str]] = None,
        replace_crlf: bool = False,
        line_processor: Optional[LineProcessor] = None,
        streaming_prefix: Optional[str] = None,
    ) -> None:
        self.log_path = log_path
        self.stream_logs = stream_logs
        self.start_streaming_at = start_streaming_at
        self.end_streaming_at = end_streaming_at
        self.skip_lines = skip_lines
        self.replace_crlf = replace_crlf
        self.line_processor = line_processor
        self.streaming_prefix = streaming_prefix


def _handle_io_stream(io_stream, out_stream, args: _ProcessingArgs):
    """Process the stream of a process."""
    out_io = io.TextIOWrapper(
        io_stream, encoding='utf-8', newline='', errors='replace', write_through=True
    )

    start_streaming_flag = False
    end_streaming_flag = False
    streaming_prefix = args.streaming_prefix if args.streaming_prefix else ''
    line_processor = (
        LineProcessor() if args.line_processor is None else args.line_processor
    )

    out = []
    with open(args.log_path, 'a', encoding='utf-8') as fout:
        with line_processor:
            while True:
                line = out_io.readline()
                if not line:
                    break
                # start_streaming_at logic in processor.process_line(line)
                if args.replace_crlf and line.endswith('\r\n'):
                    # Replace CRLF with LF to avoid ray logging to the same
                    # line due to separating lines with '\n'.
                    line = line[:-2] + '\n'
                if args.skip_lines is not None and any(
                    skip in line for skip in args.skip_lines
                ):
                    continue
                if args.start_streaming_at in line:
                    start_streaming_flag = True
                if args.end_streaming_at is not None and args.end_streaming_at in line:
                    # Keep executing the loop, only stop streaming.
                    # saving them in log files.
                    end_streaming_flag = True
                if args.stream_logs and start_streaming_flag and not end_streaming_flag:
                    print(streaming_prefix + line, end='', file=out_stream, flush=True)
                if args.log_path != '/dev/null':
                    fout.write(line)
                    fout.flush()
                line_processor.process_line(line)
                out.append(line)
    return ''.join(out)


def process_subprocess_stream(proc, args: _ProcessingArgs) -> Tuple[str, str]:
    """Redirect the process's filtered stdout/stderr to both stream and file"""
    if proc.stderr is not None:
        # Asyncio does not work as the output processing can be executed in a
        # different thread.
        # selectors is possible to handle the multiplexing of stdout/stderr,
        # but it introduces buffering making the output not streaming.
        with multiprocessing.pool.ThreadPool(processes=1) as pool:
            err_args = copy.copy(args)
            err_args.line_processor = None
            stderr_fut = pool.apply_async(
                _handle_io_stream, args=(proc.stderr, sys.stderr, err_args)
            )
            # Do not launch a thread for stdout as the rich.status does not
            # work in a thread, which is used in
            # log_utils.RayUpLineProcessor.
            stdout = _handle_io_stream(proc.stdout, sys.stdout, args)
            stderr = stderr_fut.get()
    else:
        stdout = _handle_io_stream(proc.stdout, sys.stdout, args)
        stderr = ''
    return stdout, stderr


def create_table(field_names: List[str], **kwargs) -> prettytable.PrettyTable:
    """Creates table with default style."""
    border = kwargs.pop('border', False)
    align = kwargs.pop('align', 'l')
    table = prettytable.PrettyTable(
        align=align, border=border, field_names=field_names, **kwargs
    )
    table.left_padding_width = 0
    table.right_padding_width = 2
    return table


def _make_vicky_session() -> Tuple[requests.Session, str]:
    """Build an authenticated session targeting VictoriaLogs via the apiserver
    service-proxy endpoint.

    Returns ``(session, base_url)`` where ``base_url`` already includes the
    ``/api/v1/namespaces/.../services/.../proxy`` prefix; callers append
    ``/select/logsql/query`` etc.

    Why service proxy: kr8s' ``PortForward`` defers WebSocket negotiation to
    the first request, costing ~6.5s on cold first byte. The apiserver's
    service-proxy endpoint reuses an existing TLS connection to the apiserver
    (HTTP-only target, plain GET with query params), reducing first-call
    latency to ~0.2s. Required RBAC is ``services/proxy`` ``get`` on the VL
    service — strictly tighter than ``pods/portforward`` ``create``.
    """
    from kubernetes import client as kclient
    from kubernetes import config as kconfig

    ctx = kubernetes_utils.get_current_kube_config_context_name()
    try:
        if ctx:
            kconfig.load_kube_config(context=ctx)
        else:
            kconfig.load_kube_config()
    except Exception as e:
        raise ValueError(
            f'Failed to load kubeconfig for context {ctx!r}. '
            'Ensure the context exists and your kubeconfig is valid.'
        ) from e
    cfg = kclient.Configuration.get_default_copy()

    session = requests.Session()
    if cfg.cert_file and cfg.key_file:
        session.cert = (cfg.cert_file, cfg.key_file)
    if cfg.ssl_ca_cert:
        session.verify = cfg.ssl_ca_cert
    elif cfg.verify_ssl is False:
        session.verify = False
    if cfg.api_key:
        # api_key is {auth_type: token}; we only ever attach one Authorization
        # header. Most kubeconfigs have at most one entry here.
        for token in cfg.api_key.values():
            session.headers['Authorization'] = (
                token if token.startswith('Bearer') else f'Bearer {token}'
            )
            break

    base_url = (
        f'{cfg.host}/api/v1/namespaces/{VICKY_NAMESPACE}/services/'
        f'{VICKY_SERVICE}:{VICKY_REMOTE_PORT}/proxy'
    )
    if ctx:
        logger.debug('VictoriaLogs proxy via apiserver %s (context=%s)', cfg.host, ctx)
    return session, base_url


def run_with_log(
    cmd: Union[List[str], str],
    log_path: str,
    *,
    require_outputs: bool = False,
    stream_logs: bool = False,
    start_streaming_at: str = '',
    end_streaming_at: Optional[str] = None,
    skip_lines: Optional[List[str]] = None,
    shell: bool = False,
    with_ray: bool = False,
    process_stream: bool = True,
    line_processor: Optional[LineProcessor] = None,
    streaming_prefix: Optional[str] = None,
    **kwargs,
) -> Union[int, Tuple[int, str, str]]:
    """Runs a command and logs its output to a file.

    Args:
        cmd: The command to run.
        log_path: The path to the log file.
        stream_logs: Whether to stream the logs to stdout/stderr.
        require_outputs: Whether to return the stdout/stderr of the command.
        process_stream: Whether to post-process the stdout/stderr of the
            command, such as replacing or skipping lines on the fly. If
            enabled, lines are printed only when '\r' or '\n' is found.

    Returns the returncode or returncode, stdout and stderr of the command.
      Note that the stdout and stderr is already decoded.
    """
    assert process_stream or not require_outputs, (
        process_stream,
        require_outputs,
        'require_outputs should be False when process_stream is False',
    )

    log_path = os.path.expanduser(log_path)
    dirname = os.path.dirname(log_path)
    os.makedirs(dirname, exist_ok=True)
    # Redirect stderr to stdout when using ray, to preserve the order of
    # stdout and stderr.
    stdout_arg = stderr_arg = None
    if process_stream:
        stdout_arg = subprocess.PIPE
        stderr_arg = subprocess.PIPE if not with_ray else subprocess.STDOUT
    # Use stdin=subprocess.DEVNULL by default, as allowing inputs will mess up
    # the terminal output when typing in the terminal that starts the API
    # server.
    stdin = kwargs.pop('stdin', subprocess.DEVNULL)
    with subprocess.Popen(
        cmd,
        stdout=stdout_arg,
        stderr=stderr_arg,
        start_new_session=True,
        shell=shell,
        stdin=stdin,
        **kwargs,
    ) as proc:
        try:
            subprocess_utils.kill_process_daemon(proc.pid)
            stdout = ''
            stderr = ''

            if process_stream:
                if skip_lines is None:
                    skip_lines = []
                # Skip these lines caused by `-i` option of bash. Failed to
                # find other way to turn off these two warning.
                # https://stackoverflow.com/questions/13300764/how-to-tell-bash-not-to-issue-warnings-cannot-set-terminal-process-group-and # noqa: E501
                # `ssh -T -i -tt` still cause the problem.
                skip_lines += [
                    'bash: cannot set terminal process group',
                    'bash: no job control in this shell',
                ]
                # We need this even if the log_path is '/dev/null' to ensure the
                # progress bar is shown.
                # NOTE: Lines are printed only when '\r' or '\n' is found.
                args = _ProcessingArgs(
                    log_path=log_path,
                    stream_logs=stream_logs,
                    start_streaming_at=start_streaming_at,
                    end_streaming_at=end_streaming_at,
                    skip_lines=skip_lines,
                    line_processor=line_processor,
                    # Replace CRLF when the output is logged to driver by ray.
                    replace_crlf=with_ray,
                    streaming_prefix=streaming_prefix,
                )
                stdout, stderr = process_subprocess_stream(proc, args)
            proc.wait()
            if require_outputs:
                return proc.returncode, stdout, stderr
            return proc.returncode
        except KeyboardInterrupt:
            # Kill the subprocess directly, otherwise, the underlying
            # process will only be killed after the python program exits,
            # causing the stream handling stuck at `readline`.
            subprocess_utils.kill_children_processes()
            raise


def _print_vicky_line(line: str, job_name: str, worker_id: int) -> None:
    """Parse and print a single NDJSON log line from VictoriaLogs."""
    try:
        payload = json.loads(line)
    except json.JSONDecodeError:
        logger.warning(f'Failed to decode log line, skipping: {line}')
        return
    if 'missing _msg field' in payload.get('_msg', ''):
        payload['_msg'] = ''
    print(
        f'{colorama.Fore.CYAN}{colorama.Style.BRIGHT} '
        f'(job_name={job_name} worker_id={worker_id})'
        f'{colorama.Style.RESET_ALL} {payload.get("_msg", "")}',
        flush=True,
    )


def _tail_vicky_logs_follow(
    session: requests.Session,
    base_url: str,
    query: Dict[str, Any],
    job_name: str,
    worker_id: int,
) -> None:
    """Stream logs via the /tail endpoint (--follow mode)."""
    vicky_url = f'{base_url}/select/logsql/tail'
    logger.debug(f'Vicky URL: {vicky_url}')
    try:
        logger.debug(f'Making request to {vicky_url} with query: {query}')
        with session.get(
            vicky_url, params=query, stream=True, timeout=INFINITY
        ) as response:
            logger.debug(f'Response status: {response.status_code}')
            if response.status_code != 200:
                logger.error(
                    f'VictoriaLogs API returned status {response.status_code}: '
                    f'{response.text}'
                )
                return
            # chunk_size=1 ensures lines are yielded as soon as they arrive
            # instead of waiting for the default 512-byte buffer to fill.
            for line in response.iter_lines(chunk_size=1, decode_unicode=True):
                if line:
                    _print_vicky_line(line, job_name, worker_id)
    except KeyboardInterrupt:
        logger.info('\nStopping log stream...')
    except requests.exceptions.Timeout:
        logger.error(
            f'Request to VictoriaLogs timed out after {INFINITY} seconds. '
            'Try increasing the timeout in the config '
            'file under `logs.timeout`. If '
            'you are still seeing issues, please contact support.'
        )
    except requests.exceptions.ConnectionError as e:
        logger.error(f'Failed to connect to VictoriaLogs at {vicky_url}: {e}')
    except requests.exceptions.RequestException as e:
        logger.error(f'Request to VictoriaLogs failed: {e}')
    except Exception as e:
        logger.error(f'Unexpected error while tailing VictoriaLogs: {e}')


def _tail_vicky_logs_query(
    session: requests.Session,
    base_url: str,
    query: Dict[str, Any],
    job_name: str,
    worker_id: int,
    reverse_output: bool = False,
) -> None:
    """Fetch matching logs via /query (--no-follow mode).

    Uses a streaming request so lines are printed as they arrive from
    VictoriaLogs rather than buffering the entire response.  The /query
    endpoint closes the connection after sending all results, so
    iter_lines() terminates naturally — no idle-timeout heuristic needed.

    If the query returns zero results, retries a few times to handle
    log ingestion latency (container → OTEL → VictoriaLogs).

    When `reverse_output=True`, buffer all returned lines and print them
    in reverse order. This pairs with a `| last N by (_time)` pipeline
    (which emits in descending `_time` order) so the user sees the last
    N in chronological order. Memory cost is bounded by N.  We don't
    chain a server-side `| sort by (_time)` because that has been
    observed to silently misbehave on the pinned VL build under load,
    even when input is just N records.
    """
    vicky_url = f'{base_url}/select/logsql/query'
    logger.debug(f'Vicky URL: {vicky_url}')

    for attempt in range(NO_FOLLOW_MAX_RETRIES + 1):
        had_output = False
        buffered: list = []
        try:
            logger.debug(
                f'Making request to {vicky_url} with query: {query}'
                + (f' (retry {attempt})' if attempt > 0 else '')
            )
            with session.get(
                vicky_url,
                params=query,
                stream=True,
                timeout=(30, NO_FOLLOW_QUERY_TIMEOUT),
            ) as response:
                logger.debug(f'Response status: {response.status_code}')
                if response.status_code != 200:
                    logger.error(
                        f'VictoriaLogs API returned status '
                        f'{response.status_code}: {response.text}'
                    )
                    return
                for line in response.iter_lines(chunk_size=1, decode_unicode=True):
                    if line:
                        if reverse_output:
                            buffered.append(line)
                        else:
                            _print_vicky_line(line, job_name, worker_id)
                        had_output = True
                if reverse_output:
                    for line in reversed(buffered):
                        _print_vicky_line(line, job_name, worker_id)
        except KeyboardInterrupt:
            logger.info('\nStopping log stream...')
            return
        except requests.exceptions.Timeout:
            logger.error(
                f'Request to VictoriaLogs timed out after '
                f'{NO_FOLLOW_QUERY_TIMEOUT} seconds.'
            )
            return
        except requests.exceptions.ConnectionError as e:
            logger.error(f'Failed to connect to VictoriaLogs at {vicky_url}: {e}')
            return
        except requests.exceptions.RequestException as e:
            logger.error(f'Request to VictoriaLogs failed: {e}')
            return
        except Exception as e:
            logger.error(f'Unexpected error while querying VictoriaLogs: {e}')
            return

        if had_output or attempt >= NO_FOLLOW_MAX_RETRIES:
            break
        logger.debug(
            f'No logs returned, retrying in {NO_FOLLOW_RETRY_DELAY}s '
            f'(attempt {attempt + 1}/{NO_FOLLOW_MAX_RETRIES})'
        )
        time.sleep(NO_FOLLOW_RETRY_DELAY)


def tail_vicky_logs(
    job_name: str,
    worker_id: int = 0,
    num_logs: int = -1,
    follow: bool = True,
    start_offset: str = '1h',
    job_created_at: Optional[str] = None,
):
    context = kubernetes_utils.get_current_kube_config_context_name()
    namespace = kubernetes_utils.get_kube_config_context_namespace(context)
    session, base_url = _make_vicky_session()

    base_logsql = (
        f'k8s.namespace.name: "{namespace}" AND '
        f'k8s.job.name: "{job_name}-workers-0" AND '
        f'batch.kubernetes.io/job-completion-index: "{worker_id}"'
    )

    bootstrap_logsql: Optional[str] = None
    if num_logs != -1:
        assert num_logs > 0, f'num_logs must be greater than 0, got {num_logs}'
        # `| last N by (_time)` is a heap-based top-N selector: cheap
        # regardless of how many records are in the window, returns the
        # newest N in descending order.  We deliberately don't chain a
        # `| sort by (_time)` after it — observed to be flaky in CI on
        # the pinned VL v1.6.1 even on a tiny N-sized input.  Instead
        # we reverse client-side over a buffer of size N (cheap).
        bootstrap_logsql = f'{base_logsql} | last {num_logs} by (_time)'

    if follow and bootstrap_logsql is None:
        # Default --follow: stream from `start_offset` ago onwards.
        effective_offset = start_offset or '1h'
        logger.info(
            f'Tailing logs from {effective_offset} ago. '
            'If logs come up empty, there might be logs just '
            'earlier than that window, check Grafana or use:\n'
            f'{colorama.Style.BRIGHT}{colorama.Fore.YELLOW}'
            f'`konduktor logs --no-follow {job_name}`'
            f'{colorama.Style.RESET_ALL}'
        )
        _tail_vicky_logs_follow(
            session,
            base_url,
            {'query': base_logsql, 'start_offset': effective_offset},
            job_name,
            worker_id,
        )
    elif follow and bootstrap_logsql is not None:
        # --follow + -n N: print the last N lines within `start_offset`,
        # then live-tail new logs from now on.
        effective_offset = start_offset or '1h'
        logger.info(
            f'Showing the last {num_logs} log lines from the '
            f'past {effective_offset}, then streaming new logs.'
        )
        # VL accepts relative durations on `start` (e.g. '-1h')
        # — avoids depending on local clock being in sync with
        # the VL server.
        _tail_vicky_logs_query(
            session,
            base_url,
            {'query': bootstrap_logsql, 'start': f'-{effective_offset}'},
            job_name,
            worker_id,
            reverse_output=True,
        )
        # Small overlap on the live tail so we don't drop lines
        # at the bootstrap→tail handoff. Some duplication near
        # the boundary is preferable to a gap.
        _tail_vicky_logs_follow(
            session,
            base_url,
            {'query': base_logsql, 'start_offset': '5s'},
            job_name,
            worker_id,
        )
    else:
        # --no-follow: single /query. Bound to the job's creation
        # time so VL doesn't scan the full retention window.
        # Falls back to an unbounded scan if the jobset was
        # deleted or the timestamp is missing.
        nf_query: Dict[str, Any] = {
            'query': bootstrap_logsql if bootstrap_logsql is not None else base_logsql
        }
        if job_created_at:
            nf_query['start'] = job_created_at
        elif bootstrap_logsql is None:
            logger.debug(
                'Job creation time unavailable (jobset may have '
                'been deleted); querying all stored logs.'
            )
        _tail_vicky_logs_query(
            session,
            base_url,
            nf_query,
            job_name,
            worker_id,
            reverse_output=bootstrap_logsql is not None,
        )


def tail_logs(
    job_name: str,
    worker_id: int = 0,
    num_logs: int = 1000,
    follow: bool = True,
    start_offset: str = '1h',
    job_created_at: Optional[str] = None,
):
    tail_vicky_logs(job_name, worker_id, num_logs, follow, start_offset, job_created_at)
