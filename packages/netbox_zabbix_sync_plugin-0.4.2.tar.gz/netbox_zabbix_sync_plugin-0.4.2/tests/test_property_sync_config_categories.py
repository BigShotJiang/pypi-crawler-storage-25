"""
Feature: zabbix-sync-gui, Property 4: Sync config keys are categorized

Validates: Requirements 5.2
For any sync config key, it SHALL be assigned to at least one logical category.
"""

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

from hypothesis import given, settings
from hypothesis import strategies as st

# Load setup_wizard.py directly to get SYNC_CONFIG_DEFAULTS and SYNC_CONFIG_CATEGORIES
_wizard_path = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin" / "forms" / "setup_wizard.py"

# Need minimal Django for forms module
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = []  # type: ignore[attr-defined]
    settings_mod.DATABASES = {}  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

_spec = importlib.util.spec_from_file_location("setup_wizard", _wizard_path)
assert _spec is not None and _spec.loader is not None
_wizard_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_wizard_mod)

SYNC_CONFIG_DEFAULTS = _wizard_mod.SYNC_CONFIG_DEFAULTS
SYNC_CONFIG_CATEGORIES = _wizard_mod.SYNC_CONFIG_CATEGORIES

# Build reverse mapping: key -> list of categories
_key_to_categories: dict[str, list[str]] = {}
for category, keys in SYNC_CONFIG_CATEGORIES.items():
    for key in keys:
        _key_to_categories.setdefault(key, []).append(category)

ALL_CONFIG_KEYS = list(SYNC_CONFIG_DEFAULTS.keys())

key_subsets = st.lists(st.sampled_from(ALL_CONFIG_KEYS), min_size=1, max_size=len(ALL_CONFIG_KEYS), unique=True)


@given(keys=key_subsets)
@settings(max_examples=100)
def test_sync_config_keys_are_categorized(keys):
    """Property 4: Every sync config key belongs to at least one category."""
    for key in keys:
        assert key in _key_to_categories, f"Sync config key {key!r} is not assigned to any category"


def test_all_categorized_keys_are_valid_config_keys():
    """Every key listed in categories must be a valid sync config key."""
    for category, keys in SYNC_CONFIG_CATEGORIES.items():
        for key in keys:
            assert key in SYNC_CONFIG_DEFAULTS, f"Category {category!r} references unknown key {key!r}"
