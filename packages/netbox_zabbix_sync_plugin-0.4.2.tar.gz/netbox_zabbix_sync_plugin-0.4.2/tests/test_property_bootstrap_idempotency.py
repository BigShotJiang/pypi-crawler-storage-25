"""
Feature: zabbix-sync-gui, Property 9: Bootstrap idempotency for custom fields

Validates: Requirements 12.4
For any subset of required custom fields that already exist in NetBox,
running the bootstrap utility SHALL skip creation of existing fields,
create only missing fields, and accurately report which were created vs. skipped.
"""

from hypothesis import given, settings
from hypothesis import strategies as st

# The custom field names that bootstrap creates
REQUIRED_FIELDS = ["zabbix_hostid", "zabbix_template"]


def simulate_bootstrap(existing_fields: set[str]) -> tuple[list[str], list[str]]:
    """Simulate the bootstrap idempotency logic.

    Given a set of already-existing field names, return (created, skipped) lists.
    This mirrors the logic in _create_custom_fields().
    """
    created = []
    skipped = []
    for name in REQUIRED_FIELDS:
        if name in existing_fields:
            skipped.append(name)
        else:
            created.append(name)
    return created, skipped


# Strategy: generate random subsets of pre-existing custom fields
existing_subsets = st.frozensets(st.sampled_from(REQUIRED_FIELDS))


@given(existing=existing_subsets)
@settings(max_examples=100)
def test_bootstrap_skips_existing_creates_missing(existing):
    """Property 9: Bootstrap skips existing fields and creates only missing ones."""
    created, skipped = simulate_bootstrap(existing)

    # Every existing field must be skipped
    for name in existing:
        assert name in skipped, f"Existing field {name!r} should be skipped"
        assert name not in created, f"Existing field {name!r} should not be created"

    # Every missing field must be created
    missing = set(REQUIRED_FIELDS) - existing
    for name in missing:
        assert name in created, f"Missing field {name!r} should be created"
        assert name not in skipped, f"Missing field {name!r} should not be skipped"

    # Total must equal all required fields
    assert len(created) + len(skipped) == len(REQUIRED_FIELDS)


@given(existing=existing_subsets)
@settings(max_examples=100)
def test_bootstrap_idempotent_on_second_run(existing):
    """Running bootstrap twice produces no new creations on the second run."""
    created_1, skipped_1 = simulate_bootstrap(existing)

    # After first run, all fields now exist
    all_existing = existing | set(created_1)
    created_2, skipped_2 = simulate_bootstrap(all_existing)

    assert created_2 == [], "Second run should create nothing"
    assert set(skipped_2) == set(REQUIRED_FIELDS), "Second run should skip all fields"
