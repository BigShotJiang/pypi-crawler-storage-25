"""
Feature: zabbix-tab-preferred-runner, Properties 1-3, 11: Preferred runner model invariants

Property 1: At-most-one preferred runner
Property 2: Preferred deletion promotes lowest PK
Property 3: Preferred runner resolution
Property 11: Wizard does not change existing preferred runner
"""

import os
import sys
from types import ModuleType

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    settings_mod.SECRET_KEY = "test-secret-key-for-pbt"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for _mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if _mod_name not in sys.modules:
        sys.modules[_mod_name] = ModuleType(_mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so SyncConfig import doesn't fail
for _mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if _mod_name not in sys.modules:
        sys.modules[_mod_name] = ModuleType(_mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Now import the model
from django.db import connection  # noqa: E402
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.models.synchronization_runner import (  # noqa: E402
    SynchronizationRunner,
)

# Create the table once at module level
with connection.schema_editor() as schema_editor:
    schema_editor.create_model(SynchronizationRunner)


def _cleanup():
    """Delete all runners without triggering promotion logic issues."""
    SynchronizationRunner.objects.all().delete()


@given(n=st.integers(min_value=1, max_value=5))
@settings(max_examples=100)
def test_at_most_one_preferred_runner(n):
    """Property 1: At-most-one preferred runner.

    **Validates: Requirements 1.2**

    For any set of SynchronizationRunner records after any save() operation
    where preferred=True, exactly one runner in the database should have
    preferred=True and all others should have preferred=False.
    """
    _cleanup()

    # Create N runners (first one auto-gets preferred=True)
    runners = []
    for i in range(n):
        r = SynchronizationRunner(name=f"runner-{i}")
        r.save()
        runners.append(r)

    # Pick the last runner and save it with preferred=True
    target = runners[-1]
    target.preferred = True
    target.save()

    # Assert exactly one runner has preferred=True
    preferred_count = SynchronizationRunner.objects.filter(preferred=True).count()
    assert preferred_count == 1, f"Expected exactly 1 preferred runner, got {preferred_count} (n={n})"

    # Assert the target is the preferred one
    target.refresh_from_db()
    assert target.preferred is True, "The runner saved with preferred=True should be preferred"


@given(n=st.integers(min_value=2, max_value=5))
@settings(max_examples=100)
def test_preferred_deletion_promotes_lowest_pk(n):
    """Property 2: Preferred deletion promotes lowest PK.

    **Validates: Requirements 1.5**

    For any set of SynchronizationRunner records where the preferred runner
    is deleted and at least one other runner remains, the runner with the
    lowest primary key among the remaining runners should have preferred=True.
    """
    _cleanup()

    # Create N runners
    runners = []
    for i in range(n):
        r = SynchronizationRunner(name=f"runner-{i}")
        r.save()
        runners.append(r)

    # Make the last runner preferred
    target = runners[-1]
    target.preferred = True
    target.save()

    # Delete the preferred runner
    target.delete()

    # The remaining runner with the lowest PK should now be preferred
    remaining = SynchronizationRunner.objects.order_by("pk")
    assert remaining.exists(), "Should have remaining runners"

    lowest_pk_runner = remaining.first()
    assert lowest_pk_runner.preferred is True, (
        f"Expected lowest-PK runner (pk={lowest_pk_runner.pk}) to be preferred after deletion"
    )

    # Exactly one preferred
    preferred_count = SynchronizationRunner.objects.filter(preferred=True).count()
    assert preferred_count == 1, f"Expected exactly 1 preferred runner after deletion, got {preferred_count}"


@given(n=st.integers(min_value=0, max_value=5))
@settings(max_examples=100)
def test_preferred_runner_resolution(n):
    """Property 3: Preferred runner resolution.

    **Validates: Requirements 1.3, 2.1, 2.2**

    For any set of SynchronizationRunner records:
    - 0 runners: get_preferred() returns None
    - 1 runner: get_preferred() returns that runner (regardless of preferred field)
    - N>1 runners: get_preferred() returns the runner with preferred=True
    """
    _cleanup()

    if n == 0:
        result = SynchronizationRunner.get_preferred()
        assert result is None, "get_preferred() should return None when no runners exist"
        return

    # Create N runners
    runners = []
    for i in range(n):
        r = SynchronizationRunner(name=f"runner-{i}")
        r.save()
        runners.append(r)

    result = SynchronizationRunner.get_preferred()
    assert result is not None, f"get_preferred() should not return None with {n} runners"

    if n == 1:
        # Single runner is always returned
        assert result.pk == runners[0].pk, "Single runner should be returned by get_preferred()"
    else:
        # Multiple runners: the preferred one should be returned
        result.refresh_from_db()
        assert result.preferred is True, "get_preferred() should return the preferred runner"


@given(n=st.integers(min_value=1, max_value=4))
@settings(max_examples=100)
def test_wizard_does_not_change_existing_preferred(n):
    """Property 11: Wizard does not change existing preferred runner.

    **Validates: Requirements 6.2**

    For any existing set of SynchronizationRunner records with a preferred
    runner, creating a new runner (simulating wizard) should not change which
    runner has preferred=True.
    """
    _cleanup()

    # Create N runners; the first one auto-gets preferred
    runners = []
    for i in range(n):
        r = SynchronizationRunner(name=f"runner-{i}")
        r.save()
        runners.append(r)

    # Identify the current preferred runner
    preferred_before = SynchronizationRunner.objects.filter(preferred=True).first()
    assert preferred_before is not None, "Should have a preferred runner"
    preferred_pk_before = preferred_before.pk

    # Simulate wizard creating a new runner (without setting preferred=True)
    new_runner = SynchronizationRunner(name=f"wizard-runner-{n}")
    new_runner.save()

    # The original preferred runner should still be preferred
    preferred_before.refresh_from_db()
    assert preferred_before.preferred is True, (
        f"Original preferred runner (pk={preferred_pk_before}) should still be preferred after wizard"
    )

    # The new runner should NOT be preferred
    new_runner.refresh_from_db()
    assert new_runner.preferred is False, "Wizard-created runner should not become preferred"

    # Still exactly one preferred
    preferred_count = SynchronizationRunner.objects.filter(preferred=True).count()
    assert preferred_count == 1, f"Expected exactly 1 preferred runner after wizard, got {preferred_count}"
