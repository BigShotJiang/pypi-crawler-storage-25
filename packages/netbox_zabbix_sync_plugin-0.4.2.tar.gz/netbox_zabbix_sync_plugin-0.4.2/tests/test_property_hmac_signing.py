"""
Feature: zabbix-sync-gui, Property 10: HMAC request signing

Validates: Requirements 13.1, 13.2
For any request body and HMAC token, the signed request SHALL include an
X-Signature header containing a valid HMAC-SHA256 digest of "{timestamp}.{body}",
an X-Timestamp header with a unix timestamp, and an X-Event-ID header with a
non-empty string.
"""

import hashlib
import hmac
import sys
from types import ModuleType

for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services.hmac_client import HMACClient  # noqa: E402

# Strategy: arbitrary request bodies and tokens (non-empty)
bodies = st.text(min_size=0, max_size=500)
tokens = st.text(min_size=1, max_size=200)


@given(body=bodies, token=tokens)
@settings(max_examples=100)
def test_hmac_signature_is_valid(body, token):
    """Property 10: HMAC request signing.

    The X-Signature must be a valid HMAC-SHA256 hex digest of "{timestamp}.{body}"
    using the token as key.
    """
    client = HMACClient(base_url="http://localhost:9999", token=token)
    headers = client._sign_request(body)

    timestamp = headers["X-Timestamp"]
    expected_message = f"{timestamp}.{body}"
    expected_sig = hmac.new(token.encode(), expected_message.encode(), hashlib.sha256).hexdigest()

    assert headers["X-Signature"] == expected_sig, (
        f"Signature mismatch: got {headers['X-Signature']!r}, expected {expected_sig!r}"
    )


@given(body=bodies, token=tokens)
@settings(max_examples=100)
def test_hmac_timestamp_is_unix(body, token):
    """Property 10: X-Timestamp must be a valid unix timestamp (integer string)."""
    client = HMACClient(base_url="http://localhost:9999", token=token)
    headers = client._sign_request(body)

    timestamp = headers["X-Timestamp"]
    ts_int = int(timestamp)  # must not raise
    assert ts_int > 0, f"Timestamp should be positive, got {ts_int}"


@given(body=bodies, token=tokens)
@settings(max_examples=100)
def test_hmac_event_id_is_non_empty(body, token):
    """Property 10: X-Event-ID must be a non-empty string."""
    client = HMACClient(base_url="http://localhost:9999", token=token)
    headers = client._sign_request(body)

    event_id = headers["X-Event-ID"]
    assert isinstance(event_id, str)
    assert len(event_id) > 0, "X-Event-ID must be non-empty"
