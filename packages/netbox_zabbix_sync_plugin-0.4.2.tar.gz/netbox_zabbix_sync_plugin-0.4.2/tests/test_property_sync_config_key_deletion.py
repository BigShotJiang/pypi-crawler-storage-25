"""
Feature: builtin-sync-backend, Property 6: SyncConfig key deletion

Validates: Requirements 8.5

For any SyncConfig instance and for any key present in its config JSON dict,
calling delete_sync_config_key(key) on the LocalBackend SHALL result in that
key being absent from the config dict. The remaining keys SHALL be unchanged.
"""

import os
import sys
from types import ModuleType
from unittest.mock import MagicMock

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so LocalBackend import path works
for mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Now import the actual modules under test
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services.local_backend import LocalBackend  # noqa: E402

# Strategy: generate non-empty config dicts with string keys and string values
_config_values = st.text(min_size=0, max_size=50)
_config_dicts = st.dictionaries(
    keys=st.text(min_size=1, max_size=20),
    values=_config_values,
    min_size=1,
    max_size=10,
)


def _make_runner(config: dict) -> MagicMock:
    """Create a mock runner with a sync_config attribute holding *config*."""
    runner = MagicMock()
    sc = MagicMock()
    sc.config = dict(config)  # copy so mutations are visible
    sc.save = MagicMock()
    runner.sync_config = sc
    return runner


@given(config=_config_dicts, data=st.data())
@settings(max_examples=200)
def test_sync_config_key_deletion(config, data):
    """Property 6: SyncConfig key deletion.

    **Validates: Requirements 8.5**

    For any SyncConfig with a non-empty config dict, picking any key and
    calling delete_sync_config_key(key) SHALL remove that key and leave
    all other keys unchanged.
    """
    # Feature: builtin-sync-backend, Property 6: SyncConfig key deletion

    # Pick a random key that exists in the config
    key_to_delete = data.draw(st.sampled_from(sorted(config.keys())))

    # Snapshot the expected remaining keys/values before deletion
    expected_remaining = {k: v for k, v in config.items() if k != key_to_delete}

    runner = _make_runner(config)
    backend = LocalBackend(runner)

    # Act
    backend.delete_sync_config_key(key_to_delete)

    # Assert: deleted key is absent
    assert key_to_delete not in runner.sync_config.config, (
        f"Key '{key_to_delete}' should have been deleted but is still present in config: {runner.sync_config.config}"
    )

    # Assert: remaining keys are unchanged
    assert runner.sync_config.config == expected_remaining, (
        f"Remaining config keys should be unchanged after deleting '{key_to_delete}'. "
        f"Expected {expected_remaining}, got {runner.sync_config.config}"
    )

    # Assert: save() was called
    runner.sync_config.save.assert_called_once()
