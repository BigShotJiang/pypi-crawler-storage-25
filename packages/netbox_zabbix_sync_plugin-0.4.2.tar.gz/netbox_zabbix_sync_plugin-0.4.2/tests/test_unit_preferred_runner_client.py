"""
Unit tests for Zabbix client preferred runner logic.

6.5 Connection failure error includes runner name (Req 2.3)
6.7 Local runner base URL from ConnectConfig (Req 5.4)
6.8 Remote runner base URL from webserver response (Req 5.5)
"""

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Stub out Django/NetBox imports so we can load zabbix_client.py
# ---------------------------------------------------------------------------
_stub_modules = (
    "django",
    "django.conf",
    "django.core.exceptions",
    "django.db",
    "django.db.models",
    "django.db.models.signals",
    "django.dispatch",
    "django.urls",
    "netbox",
    "netbox.plugins",
    "netbox.models",
    "netbox.models.features",
    "zabbix_utils",
)
for _mod_name in _stub_modules:
    if _mod_name not in sys.modules:
        sys.modules[_mod_name] = ModuleType(_mod_name)

# Provide stubs for zabbix_utils classes
sys.modules["zabbix_utils"].APIRequestError = type("APIRequestError", (Exception,), {})  # type: ignore[attr-defined]
sys.modules["zabbix_utils"].ProcessingError = type("ProcessingError", (Exception,), {})  # type: ignore[attr-defined]
sys.modules["zabbix_utils"].ZabbixAPI = MagicMock  # type: ignore[attr-defined]

# Set up the plugin package hierarchy
_plugin_root = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin"

_pkg = ModuleType("netbox_zabbix_sync_plugin")
_pkg.__path__ = [str(_plugin_root)]  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin", _pkg)

_svc_pkg = ModuleType("netbox_zabbix_sync_plugin.services")
_svc_pkg.__path__ = [str(_plugin_root / "services")]  # type: ignore[attr-defined]
_svc_pkg.WebserverError = type("WebserverError", (Exception,), {})  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.services", _svc_pkg)

# Stub the HMACClient
_hmac_mod = ModuleType("netbox_zabbix_sync_plugin.services.hmac_client")
_hmac_mod.HMACClient = MagicMock  # type: ignore[attr-defined]
_hmac_mod.logger = MagicMock()  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.services.hmac_client", _hmac_mod)

# Ensure WebserverError is present on the services package
if not hasattr(sys.modules["netbox_zabbix_sync_plugin.services"], "WebserverError"):
    sys.modules["netbox_zabbix_sync_plugin.services"].WebserverError = type("WebserverError", (Exception,), {})  # type: ignore[attr-defined]

# Stub the models package
_models_pkg = ModuleType("netbox_zabbix_sync_plugin.models")
_models_pkg.__path__ = [str(_plugin_root / "models")]  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.models", _models_pkg)

# Stub the synchronization_runner module with RunnerMode
_runner_mod = ModuleType("netbox_zabbix_sync_plugin.models.synchronization_runner")


class _RunnerMode:
    LOCAL = "local"
    REMOTE = "remote"


_runner_mod.RunnerMode = _RunnerMode  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.models.synchronization_runner", _runner_mod)

# Load zabbix_client module
_zc_path = _plugin_root / "services" / "zabbix_client.py"
_spec = importlib.util.spec_from_file_location(
    "netbox_zabbix_sync_plugin.services.zabbix_client",
    _zc_path,
    submodule_search_locations=[],
)
assert _spec is not None and _spec.loader is not None
_zc_mod = importlib.util.module_from_spec(_spec)
_zc_mod.__package__ = "netbox_zabbix_sync_plugin.services"
sys.modules["netbox_zabbix_sync_plugin.services.zabbix_client"] = _zc_mod
_spec.loader.exec_module(_zc_mod)

_cache = _zc_mod._cache
get_host_maintenance = _zc_mod.get_host_maintenance
get_host_problems = _zc_mod.get_host_problems
get_zabbix_base_url = _zc_mod.get_zabbix_base_url


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeConnectConfig:
    def __init__(self, url="http://zabbix.example.com/api_jsonrpc.php"):
        self.zabbix_url = url
        self.zabbix_user = "admin"
        self.zabbix_password = "secret"
        self.zabbix_token = ""


class _FakeRunner:
    def __init__(self, pk, name="test-runner", mode="local"):
        self.pk = pk
        self.name = name
        self.mode = mode
        self.url = ""
        self.token = ""
        self.connect_config = _FakeConnectConfig()


class _FailingRunner:
    """Runner whose connect_config raises an exception."""

    pk = 1
    name = "failing-runner"
    mode = "local"

    @property
    def connect_config(self):
        raise Exception("connection failed")


def _clear_cache():
    """Clear the per-runner cache between tests."""
    _cache.clear()


# ---------------------------------------------------------------------------
# 6.5 Connection failure error includes runner name (Req 2.3)
# ---------------------------------------------------------------------------
def test_connection_failure_error_includes_runner_name():
    """When connect_config raises, error string contains the runner name."""
    _clear_cache()
    runner = _FailingRunner()

    maint = get_host_maintenance("12345", runner)
    assert maint["error"] is not None, "Should have an error"
    assert "failing-runner" in maint["error"], f"Error should contain runner name, got: {maint['error']}"

    _clear_cache()
    problems = get_host_problems("12345", runner)
    assert problems["error"] is not None, "Should have an error"
    assert "failing-runner" in problems["error"], f"Error should contain runner name, got: {problems['error']}"


# ---------------------------------------------------------------------------
# 6.7 Local runner base URL from ConnectConfig (Req 5.4)
# ---------------------------------------------------------------------------
def test_local_runner_base_url_from_connect_config():
    """Local runner: get_zabbix_base_url() strips /api_jsonrpc.php from ConnectConfig.zabbix_url."""
    _clear_cache()
    runner = _FakeRunner(pk=10, name="local-runner", mode="local")
    runner.connect_config = _FakeConnectConfig(url="http://zabbix.example.com/api_jsonrpc.php")

    result = get_zabbix_base_url(runner)
    assert result == "http://zabbix.example.com", f"Expected 'http://zabbix.example.com', got '{result}'"


# ---------------------------------------------------------------------------
# 6.8 Remote runner base URL from webserver response (Req 5.5)
# ---------------------------------------------------------------------------
def test_remote_runner_base_url_from_webserver():
    """Remote runner: get_zabbix_base_url() fetches URL from HMACClient response."""
    _clear_cache()
    runner = _FakeRunner(pk=20, name="remote-runner", mode="remote")
    runner.url = "http://webserver:8080"
    runner.token = "secret-token"

    mock_client_instance = MagicMock()
    mock_client_instance.get.return_value = {"config": {"zabbix_url": "http://zabbix.remote.com/api_jsonrpc.php"}}

    with patch.object(_zc_mod, "HMACClient", return_value=mock_client_instance):
        result = get_zabbix_base_url(runner)

    assert result == "http://zabbix.remote.com", f"Expected 'http://zabbix.remote.com', got '{result}'"
