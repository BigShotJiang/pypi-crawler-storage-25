"""
Feature: zabbix-tab-preferred-runner, Properties 4-5: Runner selector bar

Property 4: Runner selector bar visibility matches runner count
Property 5: Runner selector lists all runners with preferred pre-selected
"""

import importlib.util
import sys
from pathlib import Path
from types import ModuleType

from hypothesis import given, settings
from hypothesis import strategies as st

# ---------------------------------------------------------------------------
# Stub out Django/NetBox imports so we can load _build_zabbix_context
# ---------------------------------------------------------------------------
_stub_modules = (
    "dcim",
    "dcim.models",
    "django",
    "django.http",
    "django.shortcuts",
    "django.urls",
    "django.views",
    "netbox",
    "netbox.plugins",
    "netbox.views",
    "netbox.views.generic",
    "utilities",
    "utilities.views",
    "virtualization",
    "virtualization.models",
)
for _mod_name in _stub_modules:
    if _mod_name not in sys.modules:
        sys.modules[_mod_name] = ModuleType(_mod_name)

sys.modules["django.urls"].reverse = lambda *a, **kw: "/stub/"  # type: ignore[attr-defined]
sys.modules["django.shortcuts"].get_object_or_404 = lambda *a, **kw: None  # type: ignore[attr-defined]
sys.modules["django.shortcuts"].render = lambda *a, **kw: None  # type: ignore[attr-defined]
sys.modules["django.http"].JsonResponse = type("JsonResponse", (), {})  # type: ignore[attr-defined]
sys.modules["django.views"].View = type("View", (), {})  # type: ignore[attr-defined]


class _FakeManager:
    def all(self):
        return self


sys.modules["dcim.models"].Device = type("Device", (), {"objects": _FakeManager()})  # type: ignore[attr-defined]
sys.modules["virtualization.models"].VirtualMachine = type("VirtualMachine", (), {"objects": _FakeManager()})  # type: ignore[attr-defined]
sys.modules["netbox.views.generic"].ObjectView = type("ObjectView", (), {})  # type: ignore[attr-defined]
sys.modules["utilities.views"].ViewTab = lambda **kw: None  # type: ignore[attr-defined]
sys.modules["utilities.views"].register_model_view = lambda *a, **kw: (lambda cls: cls)  # type: ignore[attr-defined]

# Set up the plugin package hierarchy so relative imports work
_plugin_root = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin"

_pkg = ModuleType("netbox_zabbix_sync_plugin")
_pkg.__path__ = [str(_plugin_root)]  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin", _pkg)

_views_pkg = ModuleType("netbox_zabbix_sync_plugin.views")
_views_pkg.__path__ = [str(_plugin_root / "views")]  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.views", _views_pkg)

_svc_pkg = ModuleType("netbox_zabbix_sync_plugin.services")
_svc_pkg.__path__ = [str(_plugin_root / "services")]  # type: ignore[attr-defined]
_svc_pkg.WebserverError = type("WebserverError", (Exception,), {})  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.services", _svc_pkg)
if not hasattr(sys.modules["netbox_zabbix_sync_plugin.services"], "WebserverError"):
    sys.modules["netbox_zabbix_sync_plugin.services"].WebserverError = type("WebserverError", (Exception,), {})  # type: ignore[attr-defined]

_zbx_client = ModuleType("netbox_zabbix_sync_plugin.services.zabbix_client")
_zbx_client.get_host_maintenance = lambda *a, **kw: {  # type: ignore[attr-defined]
    "in_maintenance": False,
    "maintenance_name": None,
    "maintenance_until": None,
    "error": None,
}
_zbx_client.get_host_problems = lambda *a, **kw: {"problems": [], "error": None}  # type: ignore[attr-defined]
_zbx_client.get_zabbix_base_url = lambda *a, **kw: None  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.services.zabbix_client", _zbx_client)

_cfg_cache = ModuleType("netbox_zabbix_sync_plugin.services.config_cache")
_cfg_cache.get_device_cf = lambda: "zabbix_hostid"  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.services.config_cache", _cfg_cache)

_models_pkg = ModuleType("netbox_zabbix_sync_plugin.models")
_models_pkg.__path__ = [str(_plugin_root / "models")]  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.models", _models_pkg)


class _StubSyncRunnerManager:
    """Minimal manager stub so zabbix_tab.py can call .objects.all() / .get()."""

    def all(self):
        return []

    def get(self, **kwargs):
        raise LookupError("stub")


class _StubSynchronizationRunner:
    objects = _StubSyncRunnerManager()
    DoesNotExist = type("DoesNotExist", (Exception,), {})

    @classmethod
    def get_preferred(cls):
        return None


_models_pkg.SynchronizationRunner = _StubSynchronizationRunner  # type: ignore[attr-defined]

# Load the zabbix_tab module
_tc_path = _plugin_root / "views" / "zabbix_tab.py"
_spec = importlib.util.spec_from_file_location(
    "netbox_zabbix_sync_plugin.views.zabbix_tab",
    _tc_path,
    submodule_search_locations=[],
)
assert _spec is not None and _spec.loader is not None
_mod = importlib.util.module_from_spec(_spec)
_mod.__package__ = "netbox_zabbix_sync_plugin.views"
sys.modules["netbox_zabbix_sync_plugin.views.zabbix_tab"] = _mod
_spec.loader.exec_module(_mod)

_build_zabbix_context = _mod._build_zabbix_context


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeRunner:
    """Minimal runner stub for context building."""

    def __init__(self, pk, name, preferred=False):
        self.pk = pk
        self.name = name
        self.preferred = preferred


class _FakeQuerySet(list):
    """List that behaves enough like a Django QuerySet for template use."""

    def all(self):
        return self


class _FakeObj:
    """Fake Device/VM with a cf dict containing a hostid."""

    def __init__(self, hostid=None):
        self.cf = {"zabbix_hostid": hostid}
        self.primary_ip4 = "10.0.0.1"
        self.primary_ip6 = None


@given(n=st.integers(min_value=0, max_value=6))
@settings(max_examples=100)
def test_runner_selector_bar_visibility(n):
    """Property 4: Runner selector bar visibility matches runner count.

    **Validates: Requirements 3.1, 3.2**

    The runner selector bar should be visible if and only if the total number
    of SynchronizationRunner records is greater than one.
    """
    # Build a fake queryset of N runners
    runners = _FakeQuerySet(_FakeRunner(pk=i, name=f"runner-{i}", preferred=(i == 0)) for i in range(n))

    # The selector bar visibility is determined by runners|length > 1 in the
    # template. We verify the context provides the correct runners list.
    # Patch SynchronizationRunner.objects.all() to return our fake queryset
    original_all = _mod.SynchronizationRunner.objects.all
    _mod.SynchronizationRunner.objects.all = lambda: runners

    try:
        if n == 0:
            # No runners — _build_zabbix_context won't be called (tab hidden)
            # Just verify the runners list would be empty
            assert len(runners) == 0
            # Selector bar should NOT be visible (0 is not > 1)
            assert not (len(runners) > 1)
        else:
            preferred = runners[0]
            obj = _FakeObj(hostid="12345")
            ctx = _build_zabbix_context(obj, "device", preferred)

            ctx_runners = list(ctx["runners"])
            assert len(ctx_runners) == n, f"Context should contain {n} runners, got {len(ctx_runners)}"

            # The template shows the selector bar iff runners|length > 1
            selector_visible = len(ctx_runners) > 1
            if n > 1:
                assert selector_visible, "Selector bar should be visible when >1 runners"
            else:
                assert not selector_visible, "Selector bar should be hidden when <=1 runners"
    finally:
        _mod.SynchronizationRunner.objects.all = original_all


@given(n=st.integers(min_value=1, max_value=6))
@settings(max_examples=100)
def test_runner_selector_lists_all_runners_with_preferred(n):
    """Property 5: Runner selector lists all runners with preferred pre-selected.

    **Validates: Requirements 3.3**

    For any set of SynchronizationRunner records passed to the Zabbix tab
    context, the dropdown should contain every runner by name, and the
    preferred runner should be marked as the selected option.
    """
    runners = _FakeQuerySet(_FakeRunner(pk=i, name=f"runner-{i}", preferred=(i == 0)) for i in range(n))
    preferred = runners[0]

    original_all = _mod.SynchronizationRunner.objects.all
    _mod.SynchronizationRunner.objects.all = lambda: runners

    try:
        obj = _FakeObj(hostid="12345")
        ctx = _build_zabbix_context(obj, "device", preferred)

        # All runners present in context
        ctx_runners = list(ctx["runners"])
        ctx_names = {r.name for r in ctx_runners}
        expected_names = {f"runner-{i}" for i in range(n)}
        assert ctx_names == expected_names, f"Expected runner names {expected_names}, got {ctx_names}"

        # Preferred runner is in context
        assert ctx["preferred_runner"] is preferred, "preferred_runner in context should be the preferred runner"
        assert ctx["preferred_runner"].pk == 0, "preferred_runner should have the correct pk"
    finally:
        _mod.SynchronizationRunner.objects.all = original_all
