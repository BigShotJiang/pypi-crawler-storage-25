"""
Feature: zabbix-tab-preferred-runner, Properties 6, 7, 9: Zabbix client cache

Property 6: AJAX fetch uses the specified runner's credentials
Property 7: Per-runner session isolation
Property 9: Problems include triggerid from objectid
"""

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from unittest.mock import MagicMock, patch

from hypothesis import given, settings
from hypothesis import strategies as st

# ---------------------------------------------------------------------------
# Stub out Django/NetBox imports so we can load zabbix_client.py
# ---------------------------------------------------------------------------
_stub_modules = (
    "django",
    "django.conf",
    "django.core.exceptions",
    "django.db",
    "django.db.models",
    "django.db.models.signals",
    "django.dispatch",
    "django.urls",
    "netbox",
    "netbox.plugins",
    "netbox.models",
    "netbox.models.features",
    "zabbix_utils",
)
for _mod_name in _stub_modules:
    if _mod_name not in sys.modules:
        sys.modules[_mod_name] = ModuleType(_mod_name)

# Provide stubs for zabbix_utils classes
sys.modules["zabbix_utils"].APIRequestError = type("APIRequestError", (Exception,), {})  # type: ignore[attr-defined]
sys.modules["zabbix_utils"].ProcessingError = type("ProcessingError", (Exception,), {})  # type: ignore[attr-defined]
sys.modules["zabbix_utils"].ZabbixAPI = MagicMock  # type: ignore[attr-defined]

# Set up the plugin package hierarchy
_plugin_root = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin"

_pkg = ModuleType("netbox_zabbix_sync_plugin")
_pkg.__path__ = [str(_plugin_root)]  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin", _pkg)

_svc_pkg = ModuleType("netbox_zabbix_sync_plugin.services")
_svc_pkg.__path__ = [str(_plugin_root / "services")]  # type: ignore[attr-defined]
_svc_pkg.WebserverError = type("WebserverError", (Exception,), {})  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.services", _svc_pkg)

# Stub the HMACClient
_hmac_mod = ModuleType("netbox_zabbix_sync_plugin.services.hmac_client")
_hmac_mod.HMACClient = MagicMock  # type: ignore[attr-defined]
_hmac_mod.logger = MagicMock()  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.services.hmac_client", _hmac_mod)

# Ensure WebserverError is present on the services package
if not hasattr(sys.modules["netbox_zabbix_sync_plugin.services"], "WebserverError"):
    sys.modules["netbox_zabbix_sync_plugin.services"].WebserverError = type("WebserverError", (Exception,), {})  # type: ignore[attr-defined]

# Stub the models package
_models_pkg = ModuleType("netbox_zabbix_sync_plugin.models")
_models_pkg.__path__ = [str(_plugin_root / "models")]  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.models", _models_pkg)

# Stub the synchronization_runner module with RunnerMode
_runner_mod = ModuleType("netbox_zabbix_sync_plugin.models.synchronization_runner")


class _RunnerMode:
    LOCAL = "local"
    REMOTE = "remote"


_runner_mod.RunnerMode = _RunnerMode  # type: ignore[attr-defined]
sys.modules.setdefault("netbox_zabbix_sync_plugin.models.synchronization_runner", _runner_mod)

# Load zabbix_client module
_zc_path = _plugin_root / "services" / "zabbix_client.py"
_spec = importlib.util.spec_from_file_location(
    "netbox_zabbix_sync_plugin.services.zabbix_client",
    _zc_path,
    submodule_search_locations=[],
)
assert _spec is not None and _spec.loader is not None
_zc_mod = importlib.util.module_from_spec(_spec)
_zc_mod.__package__ = "netbox_zabbix_sync_plugin.services"
sys.modules["netbox_zabbix_sync_plugin.services.zabbix_client"] = _zc_mod
_spec.loader.exec_module(_zc_mod)

_get_zabbix_api = _zc_mod._get_zabbix_api
_cache = _zc_mod._cache
get_host_problems = _zc_mod.get_host_problems


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeConnectConfig:
    def __init__(self, url="http://zabbix.example.com/api_jsonrpc.php"):
        self.zabbix_url = url
        self.zabbix_user = "admin"
        self.zabbix_password = "secret"
        self.zabbix_token = ""


class _FakeRunner:
    """Minimal runner stub for zabbix_client tests."""

    def __init__(self, pk, name="test-runner", mode="local"):
        self.pk = pk
        self.name = name
        self.mode = mode
        self.url = ""
        self.token = ""
        self.connect_config = _FakeConnectConfig()


def _clear_cache():
    """Clear the per-runner cache between tests."""
    _cache.clear()


@given(
    runner_pk=st.integers(min_value=1, max_value=1000),
    hostid=st.from_regex(r"[1-9][0-9]{0,5}", fullmatch=True),
)
@settings(max_examples=100)
def test_ajax_fetch_uses_specified_runner(runner_pk, hostid):
    """Property 6: AJAX fetch uses the specified runner's credentials.

    **Validates: Requirements 3.4**

    For any valid runner PK and hostid, the endpoint should use that runner's
    connection details (not the preferred runner's) to query the Zabbix API.
    """
    _clear_cache()

    runner = _FakeRunner(pk=runner_pk, name=f"runner-{runner_pk}")

    # Mock ZabbixAPI to track which runner's credentials are used
    mock_zapi = MagicMock()
    mock_zapi.check_auth = MagicMock()
    mock_zapi.version = "6.0"
    mock_zapi.problem = MagicMock()
    mock_zapi.problem.get = MagicMock(return_value=[])

    with patch.object(_zc_mod, "ZabbixAPI", return_value=mock_zapi):
        result = get_host_problems(hostid, runner)

    # The cache should have an entry for this specific runner PK
    assert runner_pk in _cache, f"Cache should contain entry for runner pk={runner_pk}"

    # The result should come from the specified runner (no error)
    assert result["error"] is None, "Should not have an error when runner is valid"


@given(
    pk_a=st.integers(min_value=1, max_value=500),
    pk_b=st.integers(min_value=501, max_value=1000),
)
@settings(max_examples=100)
def test_per_runner_session_isolation(pk_a, pk_b):
    """Property 7: Per-runner session isolation.

    **Validates: Requirements 4.2**

    For any two SynchronizationRunner instances with different primary keys,
    the Zabbix client cache should maintain independent sessions.
    """
    _clear_cache()

    runner_a = _FakeRunner(pk=pk_a, name=f"runner-{pk_a}")
    runner_b = _FakeRunner(pk=pk_b, name=f"runner-{pk_b}")

    mock_zapi_a = MagicMock()
    mock_zapi_a.check_auth = MagicMock()
    mock_zapi_a.version = "6.0"

    mock_zapi_b = MagicMock()
    mock_zapi_b.check_auth = MagicMock()
    mock_zapi_b.version = "6.0"

    call_count = [0]
    apis = [mock_zapi_a, mock_zapi_b]

    def mock_zabbix_api_factory(*args, **kwargs):
        idx = min(call_count[0], 1)
        call_count[0] += 1
        return apis[idx]

    with patch.object(_zc_mod, "ZabbixAPI", side_effect=mock_zabbix_api_factory):
        _get_zabbix_api(runner_a)
        _get_zabbix_api(runner_b)

    # Both runners should have independent cache entries
    assert pk_a in _cache, f"Cache should contain entry for runner A (pk={pk_a})"
    assert pk_b in _cache, f"Cache should contain entry for runner B (pk={pk_b})"

    # The cached sessions should be different objects
    cached_a, _ = _cache[pk_a]
    cached_b, _ = _cache[pk_b]
    assert cached_a is not cached_b, "Cached sessions should be independent objects"


@given(
    objectids=st.lists(
        st.from_regex(r"[1-9][0-9]{0,5}", fullmatch=True),
        min_size=1,
        max_size=5,
    ),
)
@settings(max_examples=100)
def test_problems_include_triggerid_from_objectid(objectids):
    """Property 9: Problems include triggerid from objectid.

    **Validates: Requirements 5.7**

    For any problem returned by get_host_problems(), the result dict should
    contain a triggerid key whose value is sourced from the objectid field
    of the Zabbix problem API response.
    """
    _clear_cache()

    runner = _FakeRunner(pk=999, name="test-runner")

    # Build mock Zabbix API problem responses
    mock_problems = [
        {
            "eventid": str(i + 1),
            "name": f"Problem {i}",
            "severity": "3",
            "clock": "1700000000",
            "acknowledged": "0",
            "objectid": oid,
        }
        for i, oid in enumerate(objectids)
    ]

    mock_zapi = MagicMock()
    mock_zapi.check_auth = MagicMock()
    mock_zapi.version = "6.0"
    mock_zapi.problem = MagicMock()
    mock_zapi.problem.get = MagicMock(return_value=mock_problems)

    with patch.object(_zc_mod, "ZabbixAPI", return_value=mock_zapi):
        result = get_host_problems("12345", runner)

    problems = result["problems"]
    assert len(problems) == len(objectids), f"Expected {len(objectids)} problems, got {len(problems)}"

    for p, expected_oid in zip(problems, objectids, strict=True):
        assert "triggerid" in p, "Each problem should have a triggerid key"
        assert p["triggerid"] == expected_oid, (
            f"triggerid should equal objectid: expected {expected_oid}, got {p['triggerid']}"
        )
