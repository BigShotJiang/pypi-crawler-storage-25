"""
Tests for Zabbix client cache invalidation behavior.

Verifies that invalidate_cache() correctly handles token-based vs
user/password sessions — token sessions must NOT call logout() because
that would revoke the API token on the Zabbix server.

Updated for per-runner cache (dict keyed by runner PK).
"""

import sys
import time
from types import ModuleType
from unittest.mock import MagicMock

# Stub out NetBox model imports (zabbix_client imports them lazily inside
# _get_zabbix_api, but the package chain needs netbox stubs to load).
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = type("JobsMixin", (), {})  # type: ignore[attr-defined]

import importlib  # noqa: E402

from netbox_zabbix_sync_plugin.services import zabbix_client as zc  # noqa: E402

# Force a clean load — other test modules may have triggered a partial import
# of zabbix_client via zabbix_tab.py's collection-time import.
# Preserve WebserverError on the services package to avoid cross-test pollution.
_svc_mod = sys.modules.get("netbox_zabbix_sync_plugin.services")
_saved_wse = getattr(_svc_mod, "WebserverError", None) if _svc_mod else None
zc = importlib.reload(zc)
# Restore WebserverError if it was lost during reload
_svc_mod = sys.modules.get("netbox_zabbix_sync_plugin.services")
if _svc_mod and _saved_wse and not hasattr(_svc_mod, "WebserverError"):
    _svc_mod.WebserverError = _saved_wse  # type: ignore[attr-defined]


def _reset_cache():
    """Reset module-level per-runner cache state between tests."""
    zc._cache.clear()


def test_invalidate_cache_calls_logout_for_userpass_session():
    """User/password sessions should call logout() on invalidation."""
    _reset_cache()

    mock_zapi = MagicMock()
    mock_zapi._ZabbixAPI__use_token = False

    zc._cache[1] = (mock_zapi, 1000.0)

    zc.invalidate_cache(1)

    mock_zapi.logout.assert_called_once()
    assert 1 not in zc._cache


def test_invalidate_cache_skips_logout_for_token_session():
    """Token-based sessions must NOT call logout() — it would revoke the token."""
    _reset_cache()

    mock_zapi = MagicMock()
    mock_zapi._ZabbixAPI__use_token = True

    zc._cache[2] = (mock_zapi, 1000.0)

    zc.invalidate_cache(2)

    mock_zapi.logout.assert_not_called()
    assert 2 not in zc._cache


def test_invalidate_cache_handles_none_gracefully():
    """Invalidating when no session is cached should not raise."""
    _reset_cache()
    zc.invalidate_cache(999)
    assert 999 not in zc._cache


def test_invalidate_cache_handles_logout_exception():
    """If logout() raises, the cache should still be cleared."""
    _reset_cache()

    mock_zapi = MagicMock()
    mock_zapi._ZabbixAPI__use_token = False
    mock_zapi.logout.side_effect = Exception("connection lost")

    zc._cache[3] = (mock_zapi, 1000.0)

    zc.invalidate_cache(3)

    assert 3 not in zc._cache


def test_cache_ttl_expiry():
    """After TTL expires, a cached entry should be considered stale."""
    _reset_cache()

    mock_zapi = MagicMock()
    # Set cached_at to 0 (epoch) — well past the TTL
    zc._cache[4] = (mock_zapi, 0.0)

    # The cache entry exists but is expired
    cached_zapi, cached_at = zc._cache[4]
    is_valid = (time.time() - cached_at) < zc._CACHE_TTL
    assert not is_valid


def test_cache_valid_within_ttl():
    """Within TTL, a cached entry should be considered valid."""
    _reset_cache()

    mock_zapi = MagicMock()
    zc._cache[5] = (mock_zapi, time.time())

    cached_zapi, cached_at = zc._cache[5]
    is_valid = (time.time() - cached_at) < zc._CACHE_TTL
    assert is_valid
