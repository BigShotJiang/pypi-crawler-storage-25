"""
Feature: zabbix-sync-gui, Property 2: Sensitive fields are masked in display

Validates: Requirements 4.2
For any connect config containing sensitive field values (netbox_token,
zabbix_password, zabbix_token), the rendered display output SHALL NOT
contain the raw sensitive value.
"""

from hypothesis import given, settings
from hypothesis import strategies as st

from netbox_zabbix_sync_plugin.services.masking import SENSITIVE_FIELDS, mask_value

# Strategy: generate non-empty credential strings (min 5 chars, alphanumeric — realistic tokens)
credential_strings = st.text(
    alphabet=st.characters(categories=("L", "N")),
    min_size=5,
    max_size=200,
)


@given(value=credential_strings)
@settings(max_examples=200)
def test_masked_value_does_not_contain_raw_credential(value):
    """Property 2: Sensitive fields are masked in display.

    For any non-empty credential string, the masked output must not
    equal the original value (i.e., the raw value is not exposed).
    """
    masked = mask_value(value)
    assert masked != value, f"Masked value should differ from raw value: {value!r}"


@given(value=credential_strings)
@settings(max_examples=200)
def test_masked_value_contains_asterisks(value):
    """The masked output must contain asterisk characters."""
    masked = mask_value(value)
    assert "*" in masked, f"Masked value should contain asterisks: {masked!r}"


@given(
    config=st.fixed_dictionaries(
        {
            "netbox_url": st.just("http://localhost:8000"),
            "netbox_token": credential_strings,
            "zabbix_url": st.just("http://localhost"),
            "zabbix_password": credential_strings,
            "zabbix_token": credential_strings,
        }
    )
)
@settings(max_examples=100)
def test_sensitive_fields_are_masked_in_config(config):
    """For any config dict, masking sensitive fields must hide raw values."""
    masked_config = {}
    for key, value in config.items():
        if key in SENSITIVE_FIELDS and value:
            masked_config[key] = mask_value(str(value))
        else:
            masked_config[key] = value

    for field in SENSITIVE_FIELDS:
        if config.get(field):
            assert masked_config[field] != config[field], f"Sensitive field {field!r} should be masked"
