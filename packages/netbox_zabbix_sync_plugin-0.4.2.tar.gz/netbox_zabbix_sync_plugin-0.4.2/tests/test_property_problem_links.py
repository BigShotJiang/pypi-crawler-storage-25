"""
Feature: zabbix-tab-preferred-runner, Properties 8, 10: Problem deep link URLs

Property 8: Problem deep link URL construction
Property 10: Problem links degrade to plain text when base URL missing
"""

from hypothesis import given, settings
from hypothesis import strategies as st


def _enrich_problem_link(zabbix_base_url, problem):
    """Replicate the link enrichment logic from _build_zabbix_context.

    This is the same logic used in zabbix_tab.py to add a 'link' field
    to each problem dict.
    """
    if zabbix_base_url and problem.get("triggerid") and problem.get("eventid"):
        problem["link"] = (
            f"{zabbix_base_url}/tr_events.php?triggerid={problem['triggerid']}&eventid={problem['eventid']}"
        )
    else:
        problem["link"] = None
    return problem


# Strategies
_base_url_strategy = st.from_regex(r"https?://[a-z][a-z0-9.:-]{0,50}", fullmatch=True)
_triggerid_strategy = st.from_regex(r"[1-9][0-9]{0,8}", fullmatch=True)
_eventid_strategy = st.from_regex(r"[1-9][0-9]{0,8}", fullmatch=True)


@given(
    base_url=_base_url_strategy,
    triggerid=_triggerid_strategy,
    eventid=_eventid_strategy,
)
@settings(max_examples=100)
def test_problem_deep_link_url_construction(base_url, triggerid, eventid):
    """Property 8: Problem deep link URL construction.

    **Validates: Requirements 5.3**

    For any problem event with a non-null zabbix_base_url, triggerid, and
    eventid, the constructed link should equal
    {zabbix_base_url}/tr_events.php?triggerid={triggerid}&eventid={eventid}.
    """
    problem = {
        "eventid": eventid,
        "name": "Test problem",
        "severity": "High",
        "triggerid": triggerid,
    }

    enriched = _enrich_problem_link(base_url, problem)

    expected = f"{base_url}/tr_events.php?triggerid={triggerid}&eventid={eventid}"
    assert enriched["link"] == expected, f"Expected link {expected!r}, got {enriched['link']!r}"


@given(
    base_url=st.one_of(st.none(), st.just(""), st.just(None)),
    triggerid=_triggerid_strategy,
    eventid=_eventid_strategy,
)
@settings(max_examples=100)
def test_problem_links_degrade_when_base_url_missing(base_url, triggerid, eventid):
    """Property 10: Problem links degrade to plain text when base URL missing.

    **Validates: Requirements 5.6**

    For any problem event where zabbix_base_url is None or empty, the problem
    link should be None (rendered as plain text in the template).
    """
    problem = {
        "eventid": eventid,
        "name": "Test problem",
        "severity": "High",
        "triggerid": triggerid,
    }

    enriched = _enrich_problem_link(base_url, problem)

    assert enriched["link"] is None, f"Expected link to be None when base_url={base_url!r}, got {enriched['link']!r}"
