"""
Unit tests for preferred runner views and serializer.

6.3 API serializer includes preferred field (Req 1.6)
6.4 No runners → tab hidden (Req 2.2)
6.6 AJAX fetch invalid runner_pk → DoesNotExist (Req 3.6)
"""

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from unittest.mock import MagicMock

# ---------------------------------------------------------------------------
# Plugin root
# ---------------------------------------------------------------------------
_plugin_root = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin"


# ===========================================================================
# 6.3 — Serializer includes "preferred" in Meta.fields and Meta.brief_fields
# ===========================================================================


def test_serializer_includes_preferred_field():
    """The SynchronizationRunnerSerializer has 'preferred' in fields and brief_fields."""
    # Stub DRF and netbox serializer modules
    _drf = ModuleType("rest_framework")
    _drf_ser = ModuleType("rest_framework.serializers")
    _drf_ser.HyperlinkedIdentityField = lambda **kw: None  # type: ignore[attr-defined]
    _drf_ser.CharField = lambda **kw: None  # type: ignore[attr-defined]
    sys.modules.setdefault("rest_framework", _drf)
    sys.modules["rest_framework.serializers"] = _drf_ser

    _nb_api = ModuleType("netbox.api")
    _nb_api_ser = ModuleType("netbox.api.serializers")

    class _StubSerializer:
        class Meta:
            pass

    _nb_api_ser.NetBoxModelSerializer = _StubSerializer  # type: ignore[attr-defined]
    sys.modules["netbox.api"] = _nb_api
    sys.modules["netbox.api.serializers"] = _nb_api_ser

    # Stub the models import used by the serializer (force-set to override any prior module)
    _models_pkg = sys.modules.get("netbox_zabbix_sync_plugin.models")
    if _models_pkg is None:
        _models_pkg = ModuleType("netbox_zabbix_sync_plugin.models")
        _models_pkg.__path__ = [str(_plugin_root / "models")]  # type: ignore[attr-defined]
    _models_pkg.SynchronizationRunner = MagicMock()  # type: ignore[attr-defined]
    sys.modules["netbox_zabbix_sync_plugin.models"] = _models_pkg

    # Ensure plugin package exists
    _pkg = ModuleType("netbox_zabbix_sync_plugin")
    _pkg.__path__ = [str(_plugin_root)]  # type: ignore[attr-defined]
    sys.modules.setdefault("netbox_zabbix_sync_plugin", _pkg)

    _api_pkg = ModuleType("netbox_zabbix_sync_plugin.api")
    _api_pkg.__path__ = [str(_plugin_root / "api")]  # type: ignore[attr-defined]
    sys.modules.setdefault("netbox_zabbix_sync_plugin.api", _api_pkg)

    _ser_pkg = ModuleType("netbox_zabbix_sync_plugin.api.serializers")
    _ser_pkg.__path__ = [str(_plugin_root / "api" / "serializers")]  # type: ignore[attr-defined]
    sys.modules.setdefault("netbox_zabbix_sync_plugin.api.serializers", _ser_pkg)

    # Load the serializer module via importlib
    _ser_path = _plugin_root / "api" / "serializers" / "synchronization_runner.py"
    spec = importlib.util.spec_from_file_location(
        "netbox_zabbix_sync_plugin.api.serializers.synchronization_runner",
        _ser_path,
        submodule_search_locations=[],
    )
    assert spec is not None and spec.loader is not None
    ser_mod = importlib.util.module_from_spec(spec)
    ser_mod.__package__ = "netbox_zabbix_sync_plugin.api.serializers"
    spec.loader.exec_module(ser_mod)

    SerializerClass = ser_mod.SynchronizationRunnerSerializer
    assert "preferred" in SerializerClass.Meta.fields, (
        f"'preferred' should be in Meta.fields, got: {SerializerClass.Meta.fields}"
    )
    assert "preferred" in SerializerClass.Meta.brief_fields, (
        f"'preferred' should be in Meta.brief_fields, got: {SerializerClass.Meta.brief_fields}"
    )


# ===========================================================================
# 6.4 — No runners → tab hidden
# ===========================================================================


def test_no_runners_tab_hidden():
    """When no runners exist, _tab_visible returns False."""
    # Stub Django/NetBox imports for zabbix_tab.py
    _stub_modules = (
        "dcim",
        "dcim.models",
        "django.http",
        "django.shortcuts",
        "django.urls",
        "django.views",
        "netbox.views",
        "netbox.views.generic",
        "utilities",
        "utilities.views",
        "virtualization",
        "virtualization.models",
    )
    for mod_name in _stub_modules:
        if mod_name not in sys.modules:
            sys.modules[mod_name] = ModuleType(mod_name)

    sys.modules["django.urls"].reverse = lambda *a, **kw: "/stub/"  # type: ignore[attr-defined]
    sys.modules["django.shortcuts"].get_object_or_404 = lambda *a, **kw: None  # type: ignore[attr-defined]
    sys.modules["django.shortcuts"].render = lambda *a, **kw: None  # type: ignore[attr-defined]
    sys.modules["django.http"].JsonResponse = type("JsonResponse", (), {})  # type: ignore[attr-defined]
    sys.modules["django.views"].View = type("View", (), {})  # type: ignore[attr-defined]

    class _FakeManager:
        def all(self):
            return self

    sys.modules["dcim.models"].Device = type("Device", (), {"objects": _FakeManager()})  # type: ignore[attr-defined]
    sys.modules["virtualization.models"].VirtualMachine = type("VirtualMachine", (), {"objects": _FakeManager()})  # type: ignore[attr-defined]
    sys.modules["netbox.views.generic"].ObjectView = type("ObjectView", (), {})  # type: ignore[attr-defined]
    sys.modules["utilities.views"].ViewTab = lambda **kw: None  # type: ignore[attr-defined]
    sys.modules["utilities.views"].register_model_view = lambda *a, **kw: (lambda cls: cls)  # type: ignore[attr-defined]

    # Ensure plugin package hierarchy
    _pkg = ModuleType("netbox_zabbix_sync_plugin")
    _pkg.__path__ = [str(_plugin_root)]  # type: ignore[attr-defined]
    sys.modules.setdefault("netbox_zabbix_sync_plugin", _pkg)

    _views_pkg = ModuleType("netbox_zabbix_sync_plugin.views")
    _views_pkg.__path__ = [str(_plugin_root / "views")]  # type: ignore[attr-defined]
    sys.modules.setdefault("netbox_zabbix_sync_plugin.views", _views_pkg)

    _svc_pkg = ModuleType("netbox_zabbix_sync_plugin.services")
    _svc_pkg.__path__ = [str(_plugin_root / "services")]  # type: ignore[attr-defined]
    sys.modules.setdefault("netbox_zabbix_sync_plugin.services", _svc_pkg)

    _zbx_client = ModuleType("netbox_zabbix_sync_plugin.services.zabbix_client")
    _zbx_client.get_host_maintenance = lambda *a, **kw: {}  # type: ignore[attr-defined]
    _zbx_client.get_host_problems = lambda *a, **kw: {"problems": [], "error": None}  # type: ignore[attr-defined]
    _zbx_client.get_zabbix_base_url = lambda *a, **kw: None  # type: ignore[attr-defined]
    sys.modules["netbox_zabbix_sync_plugin.services.zabbix_client"] = _zbx_client

    _cfg_cache = ModuleType("netbox_zabbix_sync_plugin.services.config_cache")
    _cfg_cache.get_device_cf = lambda: "zabbix_hostid"  # type: ignore[attr-defined]
    sys.modules["netbox_zabbix_sync_plugin.services.config_cache"] = _cfg_cache

    _models_pkg2 = ModuleType("netbox_zabbix_sync_plugin.models")
    _models_pkg2.__path__ = [str(_plugin_root / "models")]  # type: ignore[attr-defined]

    class _StubSyncRunnerManager:
        def all(self):
            return []

        def get(self, **kwargs):
            raise LookupError("stub")

    class _StubSynchronizationRunner:
        objects = _StubSyncRunnerManager()
        DoesNotExist = type("DoesNotExist", (Exception,), {})

        @classmethod
        def get_preferred(cls):
            return None

    _models_pkg2.SynchronizationRunner = _StubSynchronizationRunner  # type: ignore[attr-defined]
    sys.modules["netbox_zabbix_sync_plugin.models"] = _models_pkg2

    # Load zabbix_tab module
    _tc_path = _plugin_root / "views" / "zabbix_tab.py"
    spec = importlib.util.spec_from_file_location(
        "netbox_zabbix_sync_plugin.views.zabbix_tab",
        _tc_path,
        submodule_search_locations=[],
    )
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    mod.__package__ = "netbox_zabbix_sync_plugin.views"
    sys.modules["netbox_zabbix_sync_plugin.views.zabbix_tab"] = mod
    spec.loader.exec_module(mod)

    _tab_visible = mod._tab_visible

    # No preferred runner → tab not visible
    class _FakeObj:
        primary_ip4 = "10.0.0.1"
        primary_ip6 = None

    result = _tab_visible(_FakeObj(), None)
    assert result is False, "_tab_visible should return False when preferred_runner is None"


# ===========================================================================
# 6.6 — AJAX fetch with invalid runner_pk → DoesNotExist
# ===========================================================================


def test_ajax_fetch_invalid_runner_pk_raises_does_not_exist():
    """Accessing a non-existent runner raises DoesNotExist (which the view catches → 404)."""
    # We test the underlying model lookup logic: .objects.get(pk=...) raises DoesNotExist
    # The ZabbixTabFetchView catches this and returns 404.

    # Use the stub from the zabbix_tab module loaded above
    _models_pkg = sys.modules.get("netbox_zabbix_sync_plugin.models")
    if _models_pkg is None:
        # Ensure it's available
        _models_pkg = ModuleType("netbox_zabbix_sync_plugin.models")
        _models_pkg.__path__ = [str(_plugin_root / "models")]  # type: ignore[attr-defined]

        class _StubSyncRunnerManager:
            def all(self):
                return []

            def get(self, **kwargs):
                raise _StubSynchronizationRunner.DoesNotExist("not found")

        class _StubSynchronizationRunner:
            objects = _StubSyncRunnerManager()
            DoesNotExist = type("DoesNotExist", (Exception,), {})

        _models_pkg.SynchronizationRunner = _StubSynchronizationRunner  # type: ignore[attr-defined]
        sys.modules["netbox_zabbix_sync_plugin.models"] = _models_pkg

    SyncRunner = _models_pkg.SynchronizationRunner  # type: ignore[attr-defined]

    raised = False
    try:
        SyncRunner.objects.get(pk=99999)
    except SyncRunner.DoesNotExist:
        raised = True
    except Exception:
        # Also accept LookupError from the stub
        raised = True

    assert raised, "Accessing non-existent runner should raise DoesNotExist"
