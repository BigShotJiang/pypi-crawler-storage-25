"""
Feature: zabbix-sync-gui, Property 13: Server error messages include response details

Validates: Requirements 15.3
For any webserver response with HTTP status in the 5xx range, the error message
displayed to the user SHALL include the HTTP status code and response body details.
"""

import sys
from types import ModuleType
from unittest.mock import MagicMock, patch

# Stub out netbox and django modules so the plugin package can be imported
# without the full NetBox/Django framework installed.
for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

# Provide a minimal PluginConfig so the plugin __init__.py can define its class.
sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services import WebserverError  # noqa: E402
from netbox_zabbix_sync_plugin.services.hmac_client import HMACClient  # noqa: E402

# Strategy: 5xx status codes (500-599)
server_error_statuses = st.integers(min_value=500, max_value=599)

# Strategy: arbitrary response body text
response_bodies = st.text(min_size=1, max_size=500)


@given(status_code=server_error_statuses, body=response_bodies)
@settings(max_examples=100)
def test_server_error_message_includes_status_and_details(status_code, body):
    """Property 13: Server error messages include response details.

    For any 5xx status code and any response body, the raised WebserverError
    message must contain both the numeric status code and the response body text.
    """
    client = HMACClient(base_url="http://localhost:9999", token="test-token")

    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.ok = False
    mock_response.text = body
    mock_response.json.side_effect = ValueError("not json")

    with patch("requests.request", return_value=mock_response):
        try:
            client.get("/test")
            raise AssertionError(f"Expected WebserverError for HTTP {status_code}")
        except WebserverError as exc:
            # Status code must appear in the message
            assert str(status_code) in exc.message, (
                f"Status code {status_code} not found in error message: {exc.message!r}"
            )
            # Response body details must appear in the message
            assert body in exc.message, f"Response body not found in error message: {exc.message!r}"
            # The exception's status_code attribute must match
            assert exc.status_code == status_code, f"Exception status_code {exc.status_code} != expected {status_code}"


@given(status_code=server_error_statuses, body=response_bodies)
@settings(max_examples=100)
def test_server_error_message_includes_details_when_json(status_code, body):
    """Property 13 (JSON variant): When the 5xx response is valid JSON,
    the error message still includes the status code and body text,
    and the details dict is populated from the JSON payload.
    """
    client = HMACClient(base_url="http://localhost:9999", token="test-token")

    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.ok = False
    mock_response.text = body
    mock_response.json.return_value = {"error": body}

    with patch("requests.request", return_value=mock_response):
        try:
            client.get("/test")
            raise AssertionError(f"Expected WebserverError for HTTP {status_code}")
        except WebserverError as exc:
            assert str(status_code) in exc.message
            assert body in exc.message
            assert exc.status_code == status_code
            # When JSON is parseable, details should contain the parsed dict
            assert exc.details == {"error": body}
