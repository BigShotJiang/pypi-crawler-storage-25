"""
Feature: builtin-sync-backend, Property 1: Runner mode-aware validation

Validates: Requirements 1.1, 1.3, 1.4

For any runner with mode=remote, validation SHALL fail if url or token is empty.
For any runner with mode=local, validation SHALL pass regardless of whether url
and token are empty. For any runner, the mode field SHALL only accept the values
local and remote.
"""

import os
import sys
from types import ModuleType

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so SyncConfig import doesn't fail
for mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Now import the model — the real package is on sys.path, stubs are in place
from django.core.exceptions import ValidationError  # noqa: E402
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.models.synchronization_runner import (  # noqa: E402
    RunnerMode,
    SynchronizationRunner,
)


@given(
    mode=st.sampled_from(["local", "remote"]),
    url=st.text(max_size=200),
    token=st.text(max_size=200),
)
@settings(max_examples=200)
def test_runner_mode_aware_validation(mode, url, token):
    """Property 1: Runner mode-aware validation.

    **Validates: Requirements 1.1, 1.3, 1.4**

    Remote mode requires non-empty url and token.
    Local mode passes validation regardless of url/token.
    """
    runner = SynchronizationRunner(
        name="test-runner",
        mode=mode,
        url=url,
        token=token,
    )

    if mode == "local":
        # Local mode: clean() should never raise ValidationError
        runner.clean()
    elif mode == "remote":
        url_empty = not url
        token_empty = not token
        if url_empty or token_empty:
            try:
                runner.clean()
                raise AssertionError(f"Expected ValidationError for remote mode with url={url!r}, token={token!r}")
            except ValidationError as e:
                if url_empty:
                    assert "url" in e.message_dict, "Expected 'url' error for empty url in remote mode"
                if token_empty:
                    assert "token" in e.message_dict, "Expected 'token' error for empty token in remote mode"
        else:
            # Non-empty url and token: should pass
            runner.clean()


@given(
    url=st.text(min_size=1, max_size=200).filter(lambda s: s.strip()),
    token=st.text(min_size=1, max_size=200).filter(lambda s: s.strip()),
)
@settings(max_examples=100)
def test_remote_mode_passes_with_valid_url_and_token(url, token):
    """Remote mode with non-empty url and token should always pass validation.

    **Validates: Requirements 1.4**
    """
    runner = SynchronizationRunner(
        name="test-runner",
        mode=RunnerMode.REMOTE,
        url=url,
        token=token,
    )
    runner.clean()


@given(
    url=st.text(max_size=200),
    token=st.text(max_size=200),
)
@settings(max_examples=100)
def test_local_mode_always_passes_validation(url, token):
    """Local mode should always pass validation regardless of url/token values.

    **Validates: Requirements 1.3**
    """
    runner = SynchronizationRunner(
        name="test-runner",
        mode=RunnerMode.LOCAL,
        url=url,
        token=token,
    )
    runner.clean()


def test_mode_field_only_accepts_local_and_remote():
    """The mode field SHALL only accept 'local' and 'remote'.

    **Validates: Requirements 1.1**
    """
    valid_modes = {choice[0] for choice in RunnerMode.choices}
    assert valid_modes == {"local", "remote"}, f"Expected exactly {{'local', 'remote'}}, got {valid_modes}"
