"""
Unit tests for ImportConfigForm.

Tests file extension validation and file size validation without
requiring a full Django app registry.
"""

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType
from unittest.mock import MagicMock

# Minimal Django settings
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = []  # type: ignore[attr-defined]
    settings_mod.DATABASES = {}  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

# Load import_config.py directly to bypass forms/__init__.py model imports
_form_path = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin" / "forms" / "import_config.py"
_spec = importlib.util.spec_from_file_location("import_config", _form_path)
assert _spec is not None and _spec.loader is not None
_form_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_form_mod)

ImportConfigForm = _form_mod.ImportConfigForm


def _make_uploaded_file(name: str, size: int) -> MagicMock:
    """Create a mock UploadedFile with the given name and size."""
    f = MagicMock()
    f.name = name
    f.size = size
    f.read.return_value = b"x" * min(size, 64)
    return f


class TestImportConfigFormClean:
    """Tests for ImportConfigForm.clean_config_file()."""

    def test_valid_py_file_accepted(self):
        mock_file = _make_uploaded_file("config.py", 100)
        form = ImportConfigForm(data={}, files={"config_file": mock_file})
        assert form.is_valid()

    def test_non_py_extension_rejected(self):
        mock_file = _make_uploaded_file("config.txt", 100)
        form = ImportConfigForm(data={}, files={"config_file": mock_file})
        assert not form.is_valid()
        assert "Only .py files are accepted." in str(form.errors["config_file"])

    def test_file_over_1mb_rejected(self):
        over_limit = ImportConfigForm.MAX_SIZE + 1
        mock_file = _make_uploaded_file("config.py", over_limit)
        form = ImportConfigForm(data={}, files={"config_file": mock_file})
        assert not form.is_valid()
        assert "File exceeds the 1 MB size limit." in str(form.errors["config_file"])

    def test_file_exactly_1mb_accepted(self):
        mock_file = _make_uploaded_file("config.py", ImportConfigForm.MAX_SIZE)
        form = ImportConfigForm(data={}, files={"config_file": mock_file})
        assert form.is_valid()

    def test_no_file_submitted(self):
        form = ImportConfigForm(data={}, files={})
        assert not form.is_valid()
        assert "config_file" in form.errors
