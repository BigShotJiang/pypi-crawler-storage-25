"""
Feature: builtin-sync-backend, Property 2: ConnectConfig sensitive field exclusion

Validates: Requirements 3.2

For any ConnectConfig instance with non-empty values in netbox_token,
zabbix_password, or zabbix_token, serializing the ConnectConfig (via
get_connect_config() without secrets flag) SHALL NOT include the plaintext
values of those sensitive fields in the output.
"""

import os
import sys
from types import ModuleType
from unittest.mock import MagicMock

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so LocalBackend import path works
for mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Now import the actual modules under test
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services.local_backend import LocalBackend  # noqa: E402


def _make_runner(
    netbox_url: str,
    netbox_token: str,
    zabbix_url: str,
    zabbix_user: str,
    zabbix_password: str,
    zabbix_token: str,
) -> MagicMock:
    """Create a mock runner with a connect_config attribute."""
    runner = MagicMock()
    cc = MagicMock()
    cc.netbox_url = netbox_url
    cc.netbox_token = netbox_token
    cc.zabbix_url = zabbix_url
    cc.zabbix_user = zabbix_user
    cc.zabbix_password = zabbix_password
    cc.zabbix_token = zabbix_token
    runner.connect_config = cc
    return runner


@given(
    netbox_url=st.from_regex(r"https?://[a-z]{1,10}\.[a-z]{2,4}", fullmatch=True),
    netbox_token=st.text(min_size=1, max_size=50),
    zabbix_url=st.from_regex(r"https?://[a-z]{1,10}\.[a-z]{2,4}", fullmatch=True),
    zabbix_user=st.text(min_size=1, max_size=50),
    zabbix_password=st.text(min_size=1, max_size=50),
    zabbix_token=st.text(min_size=1, max_size=50),
)
@settings(max_examples=200)
def test_connect_config_excludes_zabbix_password(
    netbox_url,
    netbox_token,
    zabbix_url,
    zabbix_user,
    zabbix_password,
    zabbix_token,
):
    """Property 2: ConnectConfig returns all fields including sensitive ones.

    **Validates: Requirements 3.2**

    get_connect_config() returns all fields so the edit form can detect
    changes. Sensitive field masking is handled by the display view layer.
    """
    # Feature: builtin-sync-backend, Property 2: ConnectConfig sensitive field exclusion
    runner = _make_runner(
        netbox_url=netbox_url,
        netbox_token=netbox_token,
        zabbix_url=zabbix_url,
        zabbix_user=zabbix_user,
        zabbix_password=zabbix_password,
        zabbix_token=zabbix_token,
    )
    backend = LocalBackend(runner)
    config = backend.get_connect_config()

    # All fields must be present in the output
    assert config["netbox_url"] == netbox_url
    assert config["netbox_token"] == netbox_token
    assert config["zabbix_url"] == zabbix_url
    assert config["zabbix_user"] == zabbix_user
    assert config["zabbix_password"] == zabbix_password
    assert config["zabbix_token"] == zabbix_token
