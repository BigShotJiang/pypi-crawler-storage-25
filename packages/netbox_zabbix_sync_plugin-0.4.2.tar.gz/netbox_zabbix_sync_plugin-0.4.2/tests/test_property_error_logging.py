"""
Feature: zabbix-sync-gui, Property 14: All webserver errors are logged

Validates: Requirements 15.4
For any webserver communication error, the plugin SHALL write a log entry
containing the request URL, HTTP status code, and error details.
"""

import sys
from types import ModuleType
from unittest.mock import MagicMock, patch

for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

import requests as req  # noqa: E402
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services import WebserverError  # noqa: E402
from netbox_zabbix_sync_plugin.services.hmac_client import HMACClient  # noqa: E402

# Strategies
error_statuses = st.sampled_from([400, 401, 403, 500, 502, 503, 504])
paths = st.from_regex(r"/[a-z_]{1,30}", fullmatch=True)
response_bodies = st.text(min_size=1, max_size=300)


@given(status_code=error_statuses, path=paths, body=response_bodies)
@settings(max_examples=100)
def test_http_errors_are_logged_with_url_status_and_details(status_code, path, body):
    """Property 14: All webserver errors are logged.

    For any HTTP error response, a log entry must contain the request URL,
    HTTP status code, and error details.
    """
    base_url = "http://localhost:9999"
    client = HMACClient(base_url=base_url, token="test-token")
    expected_url = f"{base_url}{path}"

    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.ok = False
    mock_response.text = body
    mock_response.json.side_effect = ValueError("not json")

    with (
        patch("requests.request", return_value=mock_response),
        patch("netbox_zabbix_sync_plugin.services.hmac_client.logger") as mock_logger,
    ):
        try:
            client.get(path)
        except WebserverError:
            pass

        mock_logger.error.assert_called_once()
        log_args = mock_logger.error.call_args
        log_message = log_args[0][0] % log_args[0][1:]

        assert expected_url in log_message, f"URL {expected_url!r} not in log: {log_message!r}"
        assert str(status_code) in log_message, f"Status {status_code} not in log: {log_message!r}"


@given(path=paths)
@settings(max_examples=100)
def test_connection_errors_are_logged(path):
    """Property 14: Connection errors are logged with URL and status 0."""
    base_url = "http://localhost:9999"
    client = HMACClient(base_url=base_url, token="test-token")
    expected_url = f"{base_url}{path}"

    with (
        patch("requests.request", side_effect=req.ConnectionError("refused")),
        patch("netbox_zabbix_sync_plugin.services.hmac_client.logger") as mock_logger,
    ):
        try:
            client.get(path)
        except WebserverError:
            pass

        mock_logger.error.assert_called_once()
        log_args = mock_logger.error.call_args
        log_message = log_args[0][0] % log_args[0][1:]

        assert expected_url in log_message, f"URL {expected_url!r} not in log: {log_message!r}"
        assert "0" in log_message, f"Status 0 not in log: {log_message!r}"


@given(path=paths)
@settings(max_examples=100)
def test_timeout_errors_are_logged(path):
    """Property 14: Timeout errors are logged with URL and status 0."""
    base_url = "http://localhost:9999"
    client = HMACClient(base_url=base_url, token="test-token")
    expected_url = f"{base_url}{path}"

    with (
        patch("requests.request", side_effect=req.Timeout("timed out")),
        patch("netbox_zabbix_sync_plugin.services.hmac_client.logger") as mock_logger,
    ):
        try:
            client.get(path)
        except WebserverError:
            pass

        mock_logger.error.assert_called_once()
        log_args = mock_logger.error.call_args
        log_message = log_args[0][0] % log_args[0][1:]

        assert expected_url in log_message, f"URL {expected_url!r} not in log: {log_message!r}"
        assert "0" in log_message, f"Status 0 not in log: {log_message!r}"
