"""
Unit tests for SynchronizationRunner preferred runner model logic.

6.1 First runner creation sets preferred=True (Req 1.4)
6.2 Single runner treated as preferred regardless of field value (Req 1.3)
6.9 Setup wizard first runner gets preferred=True (Req 6.1)
6.10 Data migration sets preferred on lowest-PK existing runner
"""

import os
import sys
from types import ModuleType

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    settings_mod.SECRET_KEY = "test-secret-key-for-unit"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for _mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if _mod_name not in sys.modules:
        sys.modules[_mod_name] = ModuleType(_mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so SyncConfig import doesn't fail
for _mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if _mod_name not in sys.modules:
        sys.modules[_mod_name] = ModuleType(_mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Force-remove any prior stubs of the model module so the real module is imported
for _stale in (
    "netbox_zabbix_sync_plugin",
    "netbox_zabbix_sync_plugin.models",
    "netbox_zabbix_sync_plugin.models.synchronization_runner",
    "netbox_zabbix_sync_plugin.fields",
):
    sys.modules.pop(_stale, None)

# Now import the model
from django.db import connection  # noqa: E402

from netbox_zabbix_sync_plugin.models.synchronization_runner import (  # noqa: E402
    SynchronizationRunner,
)

# Create the table once at module level (may already exist from PBT test)
try:
    with connection.schema_editor() as schema_editor:
        schema_editor.create_model(SynchronizationRunner)
except Exception:
    pass  # Table already exists from another test module


def _cleanup():
    """Delete all runners without triggering promotion logic issues."""
    SynchronizationRunner.objects.all().delete()


# ---------------------------------------------------------------------------
# 6.1 First runner creation sets preferred=True (Req 1.4)
# ---------------------------------------------------------------------------
def test_first_runner_creation_sets_preferred():
    """When a new runner is created and no other runners exist, preferred=True."""
    _cleanup()
    runner = SynchronizationRunner(name="first-runner")
    runner.save()
    runner.refresh_from_db()
    assert runner.preferred is True, "First runner should have preferred=True"


# ---------------------------------------------------------------------------
# 6.2 Single runner treated as preferred regardless of field value (Req 1.3)
# ---------------------------------------------------------------------------
def test_single_runner_treated_as_preferred():
    """get_preferred() returns the sole runner even if preferred field is False."""
    _cleanup()
    runner = SynchronizationRunner(name="sole-runner")
    runner.save()

    result = SynchronizationRunner.get_preferred()
    assert result is not None, "get_preferred() should return the sole runner"
    assert result.pk == runner.pk, "get_preferred() should return the only runner"


# ---------------------------------------------------------------------------
# 6.9 Setup wizard first runner gets preferred=True (Req 6.1)
# ---------------------------------------------------------------------------
def test_wizard_first_runner_gets_preferred():
    """Simulating wizard: delete all runners, create one via save(), assert preferred=True."""
    _cleanup()
    # Verify no runners exist
    assert SynchronizationRunner.objects.count() == 0

    wizard_runner = SynchronizationRunner(name="wizard-runner")
    wizard_runner.save()
    wizard_runner.refresh_from_db()
    assert wizard_runner.preferred is True, "Wizard-created first runner should have preferred=True"


# ---------------------------------------------------------------------------
# 6.10 Data migration sets preferred on lowest-PK existing runner
# ---------------------------------------------------------------------------
def test_data_migration_sets_preferred_on_lowest_pk():
    """Simulate the migration logic: create 3 runners, reset all preferred=False,
    then run the migration logic (order_by pk, set first to preferred).
    Verify only the lowest-PK runner has preferred=True.
    """
    _cleanup()

    # Create 3 runners (first auto-gets preferred)
    r1 = SynchronizationRunner(name="runner-a")
    r1.save()
    r2 = SynchronizationRunner(name="runner-b")
    r2.save()
    r3 = SynchronizationRunner(name="runner-c")
    r3.save()

    # Reset all preferred=False via bulk update (bypass save() logic)
    SynchronizationRunner.objects.update(preferred=False)

    # Verify all are False
    assert SynchronizationRunner.objects.filter(preferred=True).count() == 0

    # Simulate the migration logic from 0007_add_preferred_runner.py
    first = SynchronizationRunner.objects.order_by("pk").first()
    assert first is not None
    first.preferred = True
    first.save(update_fields=["preferred"])

    # Verify only the lowest-PK runner has preferred=True
    lowest_pk = SynchronizationRunner.objects.order_by("pk").first()
    assert lowest_pk.preferred is True, "Lowest-PK runner should be preferred"

    # Verify the other two are False
    others = SynchronizationRunner.objects.exclude(pk=lowest_pk.pk)
    for r in others:
        assert r.preferred is False, f"Runner pk={r.pk} should not be preferred"

    # Verify exactly one preferred
    assert SynchronizationRunner.objects.filter(preferred=True).count() == 1
