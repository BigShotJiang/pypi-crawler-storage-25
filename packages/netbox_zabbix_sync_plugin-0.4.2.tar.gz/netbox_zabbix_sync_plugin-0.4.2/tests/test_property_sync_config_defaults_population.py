"""
Feature: builtin-sync-backend, Property 3: SyncConfig default population

Validates: Requirements 4.3

For any SyncConfig instance created with an empty config dict, after saving,
the config field SHALL contain all keys present in DEFAULT_CONFIG from
netbox_zabbix_sync.modules.settings, and each key's value SHALL match the
corresponding default.
"""

import os
import sys
from types import ModuleType
from unittest.mock import patch

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so SyncConfig import doesn't fail.
# Set a realistic DEFAULT_CONFIG dict on the stub.
_REALISTIC_DEFAULT_CONFIG = {
    "device_cf": "zabbix_hostid",
    "template_cf": "zabbix_template",
    "device_journal": False,
    "device_removal": False,
    "sync_vms": False,
    "vm_cf": "zabbix_hostid",
    "vm_journal": False,
    "vm_removal": False,
    "hostgroup_format": "site/manufacturer/role",
    "templates_config_context": False,
    "templates_config_context_overrule": False,
    "proxy_power": False,
    "create_hostgroups": True,
    "create_journal": False,
}

for mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = _REALISTIC_DEFAULT_CONFIG  # type: ignore[attr-defined]

# Now import the model
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.models.sync_config import SyncConfig  # noqa: E402

# Strategy: generate subsets of DEFAULT_CONFIG keys to override, proving that
# only truly empty configs get populated.
_default_keys = list(_REALISTIC_DEFAULT_CONFIG.keys())


@given(data=st.data())
@settings(max_examples=100)
def test_empty_config_populated_with_all_defaults(data):
    """Property 3: SyncConfig default population — empty config case.

    **Validates: Requirements 4.3**

    When SyncConfig is saved with an empty config dict, the save() method
    SHALL populate config with all DEFAULT_CONFIG keys and matching values.
    """
    # Create a SyncConfig instance with empty config (don't hit DB)
    instance = SyncConfig.__new__(SyncConfig)
    instance.config = {}

    # Ensure the stub has the correct DEFAULT_CONFIG (other tests may have overwritten it)
    sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = _REALISTIC_DEFAULT_CONFIG  # type: ignore[attr-defined]

    # Mock super().save() so we don't need a real database
    with patch.object(django_models.Model, "save"):
        instance.save()

    # After save, config must contain every DEFAULT_CONFIG key with correct value
    for key, expected_value in _REALISTIC_DEFAULT_CONFIG.items():
        assert key in instance.config, f"Key {key!r} missing from config after save with empty config"
        assert instance.config[key] == expected_value, (
            f"Key {key!r}: expected {expected_value!r}, got {instance.config[key]!r}"
        )

    # Config should have exactly the same keys as DEFAULT_CONFIG (no extras)
    assert set(instance.config.keys()) == set(_REALISTIC_DEFAULT_CONFIG.keys()), (
        f"Config keys mismatch: got {set(instance.config.keys())}, expected {set(_REALISTIC_DEFAULT_CONFIG.keys())}"
    )


@given(config_values=st.fixed_dictionaries({k: st.just(v) for k, v in _REALISTIC_DEFAULT_CONFIG.items()}))
@settings(max_examples=100)
def test_nonempty_config_not_overwritten(config_values):
    """Property 3 (inverse): Non-empty config is preserved on save.

    **Validates: Requirements 4.3**

    When SyncConfig already has a non-empty config, save() SHALL NOT
    overwrite it with DEFAULT_CONFIG.
    """
    instance = SyncConfig.__new__(SyncConfig)
    instance.config = dict(config_values)

    original_config = dict(instance.config)

    with patch.object(django_models.Model, "save"):
        instance.save()

    # Config should remain unchanged
    assert instance.config == original_config, (
        f"Non-empty config was modified during save: {instance.config} != {original_config}"
    )
