"""
Tables for SynchronizationRunner model.

For more information on NetBox tables, see:
https://docs.netbox.dev/en/stable/plugins/development/tables/

For django-tables2 documentation, see:
https://django-tables2.readthedocs.io/
"""

import django_tables2 as tables
from netbox.tables import NetBoxTable
from netbox.tables.columns import TagColumn

from ..models import SynchronizationRunner


class SynchronizationRunnerTable(NetBoxTable):
    """Table for displaying SynchronizationRunner objects in list views."""

    name = tables.Column(linkify=True)
    url = tables.Column(verbose_name="URL")
    preferred = tables.BooleanColumn(verbose_name="Preferred")
    tags = TagColumn(url_name="plugins:netbox_zabbix_sync_plugin:synchronizationrunner_list")

    class Meta(NetBoxTable.Meta):
        model = SynchronizationRunner
        fields = (
            "pk",
            "id",
            "name",
            "description",
            "mode",
            "preferred",
            "url",
            "tags",
            "created",
            "last_updated",
            "actions",
        )
        default_columns = (
            "name",
            "description",
            "mode",
            "preferred",
            "url",
        )
