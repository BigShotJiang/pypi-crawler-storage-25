"""
Tables for NetBox Zabbix Sync Plugin.
"""

from .synchronization_runner import SynchronizationRunnerTable

__all__ = ("SynchronizationRunnerTable",)
