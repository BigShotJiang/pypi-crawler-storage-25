"""
Template extensions for injecting content onto core NetBox views.

The Zabbix tab is now implemented as a registered model view
(see views/zabbix_tab.py) using register_model_view() + ViewTab.
This file is kept for any future PluginTemplateExtension needs.
"""

template_extensions = []
