"""
Filtersets for NetBox Zabbix Sync Plugin.
"""

from .synchronization_runner import SynchronizationRunnerFilterSet

__all__ = ("SynchronizationRunnerFilterSet",)
