"""Custom validators for the NetBox Zabbix Sync Plugin."""

import re

from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _


def validate_url_with_hostname(value: str) -> None:
    """Validate a URL, allowing bare hostnames without a TLD.

    Django's built-in URLValidator rejects URLs like ``http://netbox:8080``
    because ``netbox`` has no TLD. This validator accepts any hostname that
    is valid per RFC 952/1123 (letters, digits, hyphens), including Docker
    container names and short hostnames.
    """
    pattern = re.compile(
        r"^https?://"  # scheme
        r"[a-zA-Z0-9]([a-zA-Z0-9\-\.]*[a-zA-Z0-9])?"  # hostname (with dots for FQDN)
        r"(:\d{1,5})?"  # optional port
        r"(/.*)?$",  # optional path
        re.IGNORECASE,
    )
    if not pattern.match(value):
        raise ValidationError(
            _("Enter a valid URL (e.g. http://netbox:8080 or https://netbox.example.com)."),
            code="invalid_url",
        )
