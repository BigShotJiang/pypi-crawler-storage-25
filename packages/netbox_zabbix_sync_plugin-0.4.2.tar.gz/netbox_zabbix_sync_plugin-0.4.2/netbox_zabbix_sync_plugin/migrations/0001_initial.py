import netbox.models.deletion
import taggit.managers
import utilities.json
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("extras", "0134_owner"),
    ]

    operations = [
        migrations.CreateModel(
            name="SynchronizationRunner",
            fields=[
                (
                    "id",
                    models.BigAutoField(auto_created=True, primary_key=True, serialize=False),
                ),
                ("created", models.DateTimeField(auto_now_add=True, null=True)),
                ("last_updated", models.DateTimeField(auto_now=True, null=True)),
                (
                    "custom_field_data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=utilities.json.CustomFieldJSONEncoder,
                    ),
                ),
                (
                    "name",
                    models.CharField(
                        help_text="Unique name for this synchronization runner",
                        max_length=100,
                        unique=True,
                    ),
                ),
                (
                    "description",
                    models.CharField(
                        blank=True,
                        help_text="Optional description of the runner",
                        max_length=200,
                    ),
                ),
                (
                    "url",
                    models.URLField(
                        blank=True,
                        help_text="URL endpoint for the runner service (leave blank for local runner)",
                    ),
                ),
                (
                    "token",
                    models.CharField(
                        blank=True,
                        help_text="Authentication token for the runner service (leave blank for local runner)",
                        max_length=255,
                    ),
                ),
                (
                    "tags",
                    taggit.managers.TaggableManager(through="extras.TaggedItem", to="extras.Tag"),
                ),
            ],
            options={
                "verbose_name": "Synchronization Runner",
                "verbose_name_plural": "Synchronization Runners",
                "ordering": ("name",),
            },
            bases=(netbox.models.deletion.DeleteMixin, models.Model),
        ),
    ]
