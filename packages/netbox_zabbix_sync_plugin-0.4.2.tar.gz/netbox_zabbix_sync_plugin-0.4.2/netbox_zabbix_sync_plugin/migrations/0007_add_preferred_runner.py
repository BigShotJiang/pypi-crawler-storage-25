"""Add preferred BooleanField to SynchronizationRunner.

Sets preferred=True on the runner with the lowest PK (if any exist)
so existing deployments have a preferred runner after upgrade.
"""

from django.db import migrations, models


def set_initial_preferred(apps, schema_editor):
    """Set preferred=True on the lowest-PK runner, if any exist."""
    Runner = apps.get_model("netbox_zabbix_sync_plugin", "SynchronizationRunner")
    first = Runner.objects.order_by("pk").first()
    if first:
        first.preferred = True
        first.save(update_fields=["preferred"])


class Migration(migrations.Migration):
    dependencies = [
        ("netbox_zabbix_sync_plugin", "0006_encrypt_runner_token"),
    ]

    operations = [
        migrations.AddField(
            model_name="synchronizationrunner",
            name="preferred",
            field=models.BooleanField(
                default=False,
                help_text="Flag this runner as the preferred runner for the Zabbix tab.",
            ),
        ),
        migrations.RunPython(set_initial_preferred, migrations.RunPython.noop),
    ]
