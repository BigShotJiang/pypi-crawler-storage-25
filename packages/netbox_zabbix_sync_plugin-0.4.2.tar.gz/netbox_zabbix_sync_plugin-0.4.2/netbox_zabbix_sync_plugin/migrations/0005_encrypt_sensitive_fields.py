"""Encrypt sensitive ConnectConfig fields at rest.

Changes netbox_token, zabbix_password, and zabbix_token from plain CharField
to EncryptedCharField (Fernet AES encryption using Django's SECRET_KEY).

Existing plaintext values are encrypted in a data migration step.
"""

from django.db import migrations

from netbox_zabbix_sync_plugin.fields import EncryptedCharField, encrypt_value


def encrypt_existing_values(apps, schema_editor):
    """Encrypt any existing plaintext values in the database."""
    ConnectConfig = apps.get_model("netbox_zabbix_sync_plugin", "ConnectConfig")
    for cc in ConnectConfig.objects.all():
        changed = False
        for field_name in ("netbox_token", "zabbix_password", "zabbix_token"):
            value = getattr(cc, field_name)
            if value and not value.startswith("gAAAAA"):
                # Value is plaintext — encrypt it
                setattr(cc, field_name, encrypt_value(value))
                changed = True
        if changed:
            cc.save()


class Migration(migrations.Migration):
    dependencies = [
        ("netbox_zabbix_sync_plugin", "0004_connectconfig_url_to_charfield"),
    ]

    operations = [
        migrations.AlterField(
            model_name="connectconfig",
            name="netbox_token",
            field=EncryptedCharField(blank=True, max_length=512),
        ),
        migrations.AlterField(
            model_name="connectconfig",
            name="zabbix_password",
            field=EncryptedCharField(blank=True, max_length=512),
        ),
        migrations.AlterField(
            model_name="connectconfig",
            name="zabbix_token",
            field=EncryptedCharField(blank=True, max_length=512),
        ),
        migrations.RunPython(encrypt_existing_values, migrations.RunPython.noop),
    ]
