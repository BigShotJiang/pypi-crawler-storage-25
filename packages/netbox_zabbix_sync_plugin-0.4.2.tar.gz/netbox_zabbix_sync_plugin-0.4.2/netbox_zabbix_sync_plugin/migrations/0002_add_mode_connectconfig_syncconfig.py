import django.db.models.deletion
from django.db import migrations, models


def set_existing_runners_to_remote(apps, schema_editor):
    """Existing runners that have url and token configured are remote runners."""
    SynchronizationRunner = apps.get_model("netbox_zabbix_sync_plugin", "SynchronizationRunner")
    SynchronizationRunner.objects.exclude(url="").exclude(token="").update(mode="remote")


class Migration(migrations.Migration):
    dependencies = [
        ("netbox_zabbix_sync_plugin", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="synchronizationrunner",
            name="mode",
            field=models.CharField(
                choices=[("local", "Local"), ("remote", "Remote")],
                default="local",
                help_text="Backend mode: local (built-in sync) or remote (external webserver)",
                max_length=10,
            ),
        ),
        migrations.RunPython(
            set_existing_runners_to_remote,
            migrations.RunPython.noop,
        ),
        migrations.CreateModel(
            name="ConnectConfig",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                    ),
                ),
                ("netbox_url", models.URLField(blank=True)),
                ("netbox_token", models.CharField(blank=True, max_length=255)),
                ("zabbix_url", models.URLField(blank=True)),
                ("zabbix_user", models.CharField(blank=True, max_length=200)),
                ("zabbix_password", models.CharField(blank=True, max_length=255)),
                ("zabbix_token", models.CharField(blank=True, max_length=255)),
                (
                    "runner",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="connect_config",
                        to="netbox_zabbix_sync_plugin.synchronizationrunner",
                    ),
                ),
            ],
            options={
                "verbose_name": "Connect Configuration",
            },
        ),
        migrations.CreateModel(
            name="SyncConfig",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                    ),
                ),
                (
                    "config",
                    models.JSONField(
                        default=dict,
                        help_text="Sync configuration key-value pairs",
                    ),
                ),
                (
                    "runner",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="sync_config",
                        to="netbox_zabbix_sync_plugin.synchronizationrunner",
                    ),
                ),
            ],
            options={
                "verbose_name": "Sync Configuration",
            },
        ),
    ]
