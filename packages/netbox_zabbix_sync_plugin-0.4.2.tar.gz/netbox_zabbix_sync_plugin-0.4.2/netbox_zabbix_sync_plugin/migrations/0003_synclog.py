"""Add SyncLog model for capturing local sync output."""

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("netbox_zabbix_sync_plugin", "0002_add_mode_connectconfig_syncconfig"),
    ]

    operations = [
        migrations.CreateModel(
            name="SyncLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "status",
                    models.CharField(
                        choices=[("running", "Running"), ("completed", "Completed"), ("failed", "Failed")],
                        default="running",
                        max_length=10,
                    ),
                ),
                ("output", models.TextField(blank=True, default="")),
                ("log_level", models.CharField(default="WARNING", max_length=10)),
                ("started", models.DateTimeField(auto_now_add=True)),
                ("finished", models.DateTimeField(blank=True, null=True)),
                (
                    "runner",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="sync_logs",
                        to="netbox_zabbix_sync_plugin.synchronizationrunner",
                    ),
                ),
            ],
            options={
                "verbose_name": "Sync Log",
                "verbose_name_plural": "Sync Logs",
                "ordering": ("-started",),
                "app_label": "netbox_zabbix_sync_plugin",
            },
        ),
    ]
