"""
Filterset tests for SynchronizationRunner.

Verifies that the filterset correctly filters on runner fields.
"""

from django.test import TestCase

from netbox_zabbix_sync_plugin.filtersets import SynchronizationRunnerFilterSet
from netbox_zabbix_sync_plugin.models import SynchronizationRunner


class SynchronizationRunnerFilterSetTest(TestCase):
    """Tests for the SynchronizationRunner filterset."""

    @classmethod
    def setUpTestData(cls):
        SynchronizationRunner.objects.create(
            name="Production Runner",
            description="Handles production sync",
            url="http://prod.example.com:8007",
            token="prod-token",
        )
        SynchronizationRunner.objects.create(
            name="Staging Runner",
            description="Handles staging sync",
            url="http://staging.example.com:8007",
            token="staging-token",
        )
        SynchronizationRunner.objects.create(
            name="Dev Runner",
            description="Local development",
            url="http://dev.example.com:8007",
            token="dev-token",
        )

    def _filter(self, **kwargs):
        qs = SynchronizationRunner.objects.all()
        return SynchronizationRunnerFilterSet(kwargs, qs).qs

    def test_filter_by_name(self):
        qs = self._filter(name="Production")
        self.assertEqual(qs.count(), 1)
        self.assertEqual(qs.first().name, "Production Runner")

    def test_filter_by_name_case_insensitive(self):
        qs = self._filter(name="production")
        self.assertEqual(qs.count(), 1)

    def test_filter_by_description(self):
        qs = self._filter(description="staging")
        self.assertEqual(qs.count(), 1)
        self.assertEqual(qs.first().name, "Staging Runner")

    def test_filter_by_url(self):
        qs = self._filter(url="dev.example")
        self.assertEqual(qs.count(), 1)
        self.assertEqual(qs.first().name, "Dev Runner")

    def test_search(self):
        fs = SynchronizationRunnerFilterSet({"q": "production"}, SynchronizationRunner.objects.all())
        self.assertEqual(fs.qs.count(), 1)

    def test_no_results(self):
        qs = self._filter(name="nonexistent")
        self.assertEqual(qs.count(), 0)
