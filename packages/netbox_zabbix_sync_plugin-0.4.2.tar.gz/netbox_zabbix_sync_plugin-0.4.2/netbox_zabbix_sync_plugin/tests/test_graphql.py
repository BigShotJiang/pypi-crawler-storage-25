"""
GraphQL tests for NetBox Zabbix Sync Plugin.

Verifies the GraphQL schema exposes the correct fields and excludes token.
"""

from django.test import TestCase

from netbox_zabbix_sync_plugin.graphql import SynchronizationRunnerType


class GraphQLSchemaTest(TestCase):
    """Tests for the GraphQL type definition."""

    def test_type_excludes_token(self):
        """Token must not be exposed via GraphQL."""
        field_names = [f.name for f in SynchronizationRunnerType.__strawberry_definition__.fields]
        self.assertNotIn("token", field_names)

    def test_type_includes_expected_fields(self):
        """Verify key fields are present in the GraphQL type."""
        field_names = [f.name for f in SynchronizationRunnerType.__strawberry_definition__.fields]
        for expected in ("id", "name", "description", "url"):
            self.assertIn(expected, field_names, f"Missing field: {expected}")
