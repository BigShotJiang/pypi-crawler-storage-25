"""
REST API tests for NetBox Zabbix Sync Plugin.

Tests the API endpoints, serializer output, and token exclusion.
Uses force_authenticate() to bypass v2 token complexity — we're
testing our views/serializers, not NetBox's auth layer.
"""

from django.urls import reverse
from rest_framework.test import APITestCase
from users.models import User

from netbox_zabbix_sync_plugin.models import SynchronizationRunner


class RunnerAPIReadTest(APITestCase):
    """Read-only API tests (GET requests)."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser(username="apiadmin", password="testpass123")
        cls.runner = SynchronizationRunner.objects.create(
            name="API Test Runner",
            description="Runner for API tests",
            url="http://webserver.example.com:8007",
            token="secret-hmac-token",
        )

    def setUp(self):
        self.client.force_authenticate(user=self.user)

    def test_list_runners(self):
        url = reverse("plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(response.data["count"], 1)

    def test_detail_runner(self):
        url = reverse(
            "plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-detail",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["name"], "API Test Runner")

    def test_token_excluded_from_response(self):
        """Token (HMAC secret) must never appear in API responses."""
        url = reverse(
            "plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-detail",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertNotIn("token", response.data)
        self.assertNotIn("secret-hmac-token", str(response.data))

    def test_webserver_url_in_response(self):
        """The model's url field should be exposed as webserver_url."""
        url = reverse(
            "plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-detail",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertIn("webserver_url", response.data)
        self.assertEqual(response.data["webserver_url"], "http://webserver.example.com:8007")


class RunnerAPIWriteTest(APITestCase):
    """Write API tests (POST/DELETE)."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser(username="apiwriter", password="testpass123")

    def setUp(self):
        self.client.force_authenticate(user=self.user)

    def test_create_runner_via_api(self):
        url = reverse("plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-list")
        data = {
            "name": "API Created Runner",
            "description": "Created via API test",
            "url": "http://new.example.com:8007",
            "token": "new-token",
        }
        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, 201)
        self.assertTrue(SynchronizationRunner.objects.filter(name="API Created Runner").exists())

    def test_delete_runner_via_api(self):
        runner = SynchronizationRunner.objects.create(name="To Delete", url="http://delete.example.com", token="x")
        url = reverse(
            "plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-detail",
            args=[runner.pk],
        )
        response = self.client.delete(url)
        self.assertEqual(response.status_code, 204)
        self.assertFalse(SynchronizationRunner.objects.filter(pk=runner.pk).exists())
