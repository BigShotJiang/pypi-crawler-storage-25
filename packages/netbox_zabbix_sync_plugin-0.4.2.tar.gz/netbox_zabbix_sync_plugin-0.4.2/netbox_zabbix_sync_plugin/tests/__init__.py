"""
Django integration tests for NetBox Zabbix Sync Plugin.

These tests run inside a full NetBox environment with a real database.
They are executed by the CI pipeline via:
    python manage.py test netbox_zabbix_sync_plugin.tests
"""

from .test_api import *  # noqa: F401, F403
from .test_filtersets import *  # noqa: F401, F403
from .test_graphql import *  # noqa: F401, F403
from .test_models import *  # noqa: F401, F403
from .test_urls import *  # noqa: F401, F403
from .test_views import *  # noqa: F401, F403
