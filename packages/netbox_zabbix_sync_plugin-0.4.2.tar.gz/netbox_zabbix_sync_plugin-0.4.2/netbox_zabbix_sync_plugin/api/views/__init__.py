"""
API viewsets for NetBox Zabbix Sync Plugin.
"""

from .synchronization_runner import SynchronizationRunnerViewSet

__all__ = ("SynchronizationRunnerViewSet",)
