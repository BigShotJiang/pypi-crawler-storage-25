"""
API serializers for NetBox Zabbix Sync Plugin.
"""

from .synchronization_runner import SynchronizationRunnerSerializer

__all__ = ("SynchronizationRunnerSerializer",)
