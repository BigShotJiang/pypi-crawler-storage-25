"""
API serializers for SynchronizationRunner model.

Serializers are required for NetBox event handling (webhooks, change logging).
They also power the REST API endpoints.

For more information on NetBox REST API serializers, see:
https://docs.netbox.dev/en/stable/plugins/development/rest-api/#serializers

For Django REST Framework serializers, see:
https://www.django-rest-framework.org/api-guide/serializers/
"""

from netbox.api.serializers import NetBoxModelSerializer
from rest_framework import serializers

from ...models import SynchronizationRunner


class SynchronizationRunnerSerializer(NetBoxModelSerializer):
    """Serializer for SynchronizationRunner model.

    Note: ``token`` is deliberately excluded to prevent leaking the HMAC secret.
    The model's ``url`` field (webserver URL) is exposed as ``webserver_url``
    to avoid collision with DRF's HyperlinkedIdentityField ``url``.
    """

    url = serializers.HyperlinkedIdentityField(
        view_name="plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-detail"
    )
    webserver_url = serializers.CharField(source="url", read_only=True)

    class Meta:
        model = SynchronizationRunner
        fields = (
            "id",
            "url",
            "display",
            "name",
            "description",
            "mode",
            "preferred",
            "webserver_url",
            "tags",
            "custom_fields",
            "created",
            "last_updated",
        )
        brief_fields = (
            "id",
            "url",
            "display",
            "name",
            "mode",
            "preferred",
        )
