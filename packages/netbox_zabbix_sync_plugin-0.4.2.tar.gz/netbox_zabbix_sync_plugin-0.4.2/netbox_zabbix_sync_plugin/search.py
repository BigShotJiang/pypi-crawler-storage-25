"""
Search indexes for NetBox Zabbix Sync Plugin.

This module defines search indexes to make plugin models searchable in NetBox's
global search. See: https://docs.netbox.dev/en/stable/plugins/development/search/
"""

from netbox.search import SearchIndex

from .models import SynchronizationRunner


class SynchronizationRunnerIndex(SearchIndex):
    """
    Search index for SynchronizationRunner model.

    This enables SynchronizationRunner objects to appear in NetBox's global
    search results.
    """

    model = SynchronizationRunner

    fields = (
        ("name", 100),
        ("description", 500),
        ("url", 200),
    )

    display_attrs = ("url",)


indexes = (SynchronizationRunnerIndex,)
