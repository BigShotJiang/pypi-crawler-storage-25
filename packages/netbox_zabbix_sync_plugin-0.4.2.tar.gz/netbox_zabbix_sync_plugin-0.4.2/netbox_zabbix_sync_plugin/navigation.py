"""
Navigation menu items for NetBox Zabbix Sync Plugin.

For more information on navigation menus, see:
https://docs.netbox.dev/en/stable/plugins/development/navigation/
"""

from netbox.plugins import PluginMenu, PluginMenuButton, PluginMenuItem

runner_buttons = [
    PluginMenuButton(
        link="plugins:netbox_zabbix_sync_plugin:synchronizationrunner_add",
        title="Add",
        icon_class="mdi mdi-plus-thick",
    )
]

actions_items = (
    PluginMenuItem(
        link="plugins:netbox_zabbix_sync_plugin:schedule_synchronization",
        link_text="Schedule Synchronization",
        permissions=["netbox_zabbix_sync_plugin.view_synchronizationrunner"],
    ),
    PluginMenuItem(
        link="plugins:netbox_zabbix_sync_plugin:setup_wizard_step1",
        link_text="Setup Wizard",
        staff_only=True,
    ),
)

settings_items = (
    PluginMenuItem(
        link="plugins:netbox_zabbix_sync_plugin:synchronizationrunner_list",
        link_text="Runners",
        buttons=runner_buttons,
        staff_only=True,
    ),
)


menu = PluginMenu(
    label="NetBox Zabbix Sync",
    groups=(
        ("Actions", actions_items),
        ("Settings", settings_items),
    ),
    icon_class="mdi mdi-sync",
)
