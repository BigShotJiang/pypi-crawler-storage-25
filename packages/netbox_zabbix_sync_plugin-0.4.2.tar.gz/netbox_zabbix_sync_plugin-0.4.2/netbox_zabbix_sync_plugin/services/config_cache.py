"""
Lightweight in-memory cache for sync config values.

Populated lazily on first access and updated whenever the sync config
is saved via the GUI.  No TTL, no polling.
"""

import logging

logger = logging.getLogger(__name__)

# None means "not yet loaded"; a string means "loaded".
_device_cf: str | None = None


def get_device_cf() -> str:
    """Return the cached ``device_cf`` custom field name.

    On the very first call the value is fetched from the runner's
    SyncConfig model (local mode) or from the webserver (remote mode).
    Subsequent calls return the cached value instantly.
    """
    global _device_cf
    if _device_cf is None:
        _load_device_cf()
    # After loading, _device_cf is either the loaded value or the fallback.
    return _device_cf  # type: ignore[return-value]


def set_device_cf(value: str) -> None:
    """Update the cached ``device_cf`` value (called on config save)."""
    global _device_cf
    _device_cf = value
    logger.debug("device_cf cache updated to '%s'", value)


def _load_device_cf() -> None:
    """Fetch ``device_cf`` from the first runner's config source.

    Checks the runner's mode to determine the source:
    - local mode: reads from the SyncConfig model directly
    - remote mode: fetches from the webserver via HMACClient

    Fails silently — sets the default ``"zabbix_hostid"`` if no runner
    exists or the source is unreachable.
    """
    global _device_cf

    try:
        from ..models import SynchronizationRunner
        from ..models.synchronization_runner import RunnerMode

        runner = SynchronizationRunner.objects.first()
        if not runner:
            logger.debug("No runner configured — using default device_cf")
            _device_cf = "zabbix_hostid"
            return

        if runner.mode == RunnerMode.LOCAL:
            # Read directly from the SyncConfig model
            try:
                sc = runner.sync_config
                _device_cf = sc.config.get("device_cf", "zabbix_hostid")
                logger.info("device_cf loaded from SyncConfig model: '%s'", _device_cf)
            except Exception:
                logger.debug("Could not read SyncConfig for local runner, using default")
                _device_cf = "zabbix_hostid"
        else:
            # Remote mode: fetch from webserver via HMACClient (existing behavior)
            if not runner.url or not runner.token:
                logger.debug("No runner URL/token configured — using default device_cf")
                _device_cf = "zabbix_hostid"
                return

            from .hmac_client import HMACClient

            client = HMACClient(runner.url, runner.token)
            response = client.get("/sync_config")
            config = response.get("config", {})
            _device_cf = config.get("device_cf", "zabbix_hostid")
            logger.info("device_cf loaded from webserver: '%s'", _device_cf)
    except Exception:
        logger.debug("Could not load device_cf, using default")
        _device_cf = "zabbix_hostid"
