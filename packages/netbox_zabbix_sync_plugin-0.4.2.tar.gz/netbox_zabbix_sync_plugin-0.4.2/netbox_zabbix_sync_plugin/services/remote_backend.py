"""RemoteBackend delegates all operations to the external webserver via HMACClient."""

from typing import Any

from .hmac_client import HMACClient


class RemoteBackend:
    """Delegates all operations to the external webserver via HMACClient."""

    def __init__(self, url: str, token: str):
        self.client = HMACClient(url, token)

    def get_connect_config(self) -> dict[str, Any]:
        response = self.client.get("/connect_config")
        return response.get("config", {})

    def patch_connect_config(self, data: dict[str, Any]) -> None:
        self.client.patch("/connect_config", data)

    def get_sync_config(self) -> dict[str, Any]:
        response = self.client.get("/sync_config")
        return response.get("config", {})

    def patch_sync_config(self, data: dict[str, Any]) -> None:
        self.client.patch("/sync_config", data)

    def delete_sync_config_key(self, key: str) -> None:
        self.client.delete(f"/sync_config/{key}")

    def trigger_sync(self, payload: dict[str, Any], *, background: bool = True) -> dict[str, Any]:
        return self.client.post("/sync", payload)

    def health_check(self) -> bool:
        return self.client.health_check()
