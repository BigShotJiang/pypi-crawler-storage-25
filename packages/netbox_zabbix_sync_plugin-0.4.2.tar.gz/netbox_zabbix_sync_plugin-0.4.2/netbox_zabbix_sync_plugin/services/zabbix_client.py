"""
Zabbix API client with per-runner session caching.

Connects to Zabbix using credentials from a runner's ConnectConfig model
(local mode) or fetched from the webserver via HMACClient (remote mode).
Each runner gets its own cached session keyed by runner PK, with a TTL to
avoid re-authenticating on every page load. If no runner is provided or
credentials are unavailable, all methods return empty results with an error flag.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from zabbix_utils import APIRequestError, ProcessingError, ZabbixAPI

from .hmac_client import HMACClient

if TYPE_CHECKING:
    from ..models.synchronization_runner import SynchronizationRunner

logger = logging.getLogger(__name__)

# Cache TTL in seconds
_CACHE_TTL = 300  # 5 minutes

# Per-runner cache: runner_pk -> (zapi, cached_at)
_cache_lock = threading.Lock()
_cache: dict[int, tuple[ZabbixAPI, float]] = {}


def _get_zabbix_api(runner: SynchronizationRunner) -> ZabbixAPI | None:
    """Get or create a cached ZabbixAPI session for the given runner.

    Looks up the cache by ``runner.pk``. If the cached entry is still within
    the TTL, it is returned immediately. Otherwise a new session is
    authenticated using the runner's credentials and stored in the cache.

    Returns None if connection fails.
    """
    from ..models.synchronization_runner import RunnerMode

    with _cache_lock:
        if runner.pk in _cache:
            zapi, cached_at = _cache[runner.pk]
            if (time.time() - cached_at) < _CACHE_TTL:
                return zapi

        if runner.mode == RunnerMode.LOCAL:
            # Read credentials directly from the ConnectConfig model
            try:
                cc = runner.connect_config
                config = {
                    "zabbix_url": cc.zabbix_url,
                    "zabbix_user": cc.zabbix_user,
                    "zabbix_password": cc.zabbix_password,
                    "zabbix_token": cc.zabbix_token,
                }
            except Exception:
                logger.warning("Could not read connect config for local runner '%s'", runner.name)
                return None
        else:
            # Remote mode: fetch from webserver via HMACClient
            if not runner.url or not runner.token:
                logger.debug("No runner URL/token configured — cannot connect to Zabbix")
                return None

            try:
                client = HMACClient(runner.url, runner.token)
                response = client.get("/connect_config?include_secrets=true")
                config = response.get("config", {})
            except Exception:
                logger.warning("Could not fetch connect config from runner '%s'", runner.name)
                return None

        zbx_url = config.get("zabbix_url")
        if not zbx_url:
            logger.warning("No zabbix_url in connect config")
            return None

        zbx_token = config.get("zabbix_token")
        zbx_user = config.get("zabbix_user")
        zbx_pass = config.get("zabbix_password")

        try:
            if zbx_token:
                zapi = ZabbixAPI(zbx_url, token=zbx_token)
            elif zbx_user and zbx_pass:
                zapi = ZabbixAPI(zbx_url, user=zbx_user, password=zbx_pass)
            else:
                logger.warning("No Zabbix credentials in connect config")
                return None

            zapi.check_auth()
            _cache[runner.pk] = (zapi, time.time())
            logger.info("Zabbix API session cached for runner '%s' (version %s)", runner.name, zapi.version)
            return zapi
        except (APIRequestError, ProcessingError) as e:
            logger.error("Zabbix API auth failed: %s", e)
            return None
        except Exception:
            logger.exception("Unexpected error connecting to Zabbix")
            return None


def invalidate_cache(runner_pk: int) -> None:
    """Clear the cached Zabbix API session for a specific runner."""
    with _cache_lock:
        entry = _cache.pop(runner_pk, None)
        if entry is not None:
            zapi, _ = entry
            try:
                if not getattr(zapi, "_ZabbixAPI__use_token", False):
                    zapi.logout()
            except Exception:
                pass


def get_host_maintenance(hostid: str, runner: SynchronizationRunner) -> dict:
    """Get maintenance status for a Zabbix host.

    Returns dict with keys:
        - in_maintenance (bool)
        - maintenance_name (str or None)
        - maintenance_until (int timestamp or None)
        - error (str or None)
    """
    zapi = _get_zabbix_api(runner)
    if zapi is None:
        return {
            "in_maintenance": False,
            "maintenance_name": None,
            "maintenance_until": None,
            "error": f"Zabbix unavailable (runner: {runner.name})",
        }

    try:
        hosts = zapi.host.get(
            hostids=hostid,
            output=["hostid", "maintenance_status", "maintenance_type", "maintenanceid"],
        )
        if not hosts:
            return {
                "in_maintenance": False,
                "maintenance_name": None,
                "maintenance_until": None,
                "error": "Host not found in Zabbix",
            }

        host = hosts[0]
        in_maintenance = str(host.get("maintenance_status")) == "1"

        maintenance_name = None
        maintenance_until = None
        if in_maintenance and host.get("maintenanceid") and host["maintenanceid"] != "0":
            try:
                maintenances = zapi.maintenance.get(
                    maintenanceids=host["maintenanceid"],
                    output=["name", "active_till"],
                )
                if maintenances:
                    maintenance_name = maintenances[0].get("name")
                    till = int(maintenances[0].get("active_till", 0))
                    maintenance_until = datetime.fromtimestamp(till, tz=UTC) if till else None
            except Exception:
                logger.warning("Could not fetch maintenance details for host %s", hostid)

        return {
            "in_maintenance": in_maintenance,
            "maintenance_name": maintenance_name,
            "maintenance_until": maintenance_until,
            "error": None,
        }
    except Exception as e:
        logger.error("Error fetching maintenance for host %s: %s", hostid, e)
        return {"in_maintenance": False, "maintenance_name": None, "maintenance_until": None, "error": str(e)}


def get_host_problems(hostid: str, runner: SynchronizationRunner) -> dict:
    """Get current open problems for a Zabbix host.

    Returns dict with keys:
        - problems (list of dicts with: eventid, name, severity, timestamp,
          acknowledged, triggerid)
        - error (str or None)
    """
    zapi = _get_zabbix_api(runner)
    if zapi is None:
        return {"problems": [], "error": f"Zabbix unavailable (runner: {runner.name})"}

    severity_map = {
        "0": "Not classified",
        "1": "Information",
        "2": "Warning",
        "3": "Average",
        "4": "High",
        "5": "Disaster",
    }

    try:
        problems = zapi.problem.get(
            hostids=hostid,
            output=["eventid", "name", "severity", "clock", "acknowledged", "objectid"],
            recent=True,
            sortfield="eventid",
            sortorder="DESC",
        )

        result = []
        for p in problems:
            clock = int(p.get("clock", 0))
            result.append(
                {
                    "eventid": p.get("eventid"),
                    "name": p.get("name", ""),
                    "severity": severity_map.get(str(p.get("severity", "0")), "Unknown"),
                    "severity_num": int(p.get("severity", 0)),
                    "timestamp": datetime.fromtimestamp(clock, tz=UTC) if clock else None,
                    "acknowledged": str(p.get("acknowledged")) == "1",
                    "triggerid": p.get("objectid", ""),
                }
            )

        return {"problems": result, "error": None}
    except Exception as e:
        logger.error("Error fetching problems for host %s: %s", hostid, e)
        return {"problems": [], "error": str(e)}


def get_zabbix_base_url(runner: SynchronizationRunner) -> str | None:
    """Derive the Zabbix frontend base URL from a runner's config.

    For local runners: reads ConnectConfig.zabbix_url
    For remote runners: fetches from webserver GET /connect_config
    Returns None if unavailable. Strips trailing '/api_jsonrpc.php' if present.
    """
    from ..models.synchronization_runner import RunnerMode

    try:
        if runner.mode == RunnerMode.LOCAL:
            url = runner.connect_config.zabbix_url
        else:
            client = HMACClient(runner.url, runner.token)
            config = client.get("/connect_config")
            url = config.get("config", {}).get("zabbix_url", "")

        if not url:
            return None

        if url.endswith("/api_jsonrpc.php"):
            url = url[: -len("/api_jsonrpc.php")]

        url = url.rstrip("/")
        return url or None
    except Exception:
        return None
