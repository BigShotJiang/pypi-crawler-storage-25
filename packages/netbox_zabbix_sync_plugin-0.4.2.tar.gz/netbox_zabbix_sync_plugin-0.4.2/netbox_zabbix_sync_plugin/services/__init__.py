"""Services package for netbox-zabbix-sync-plugin."""


class WebserverError(Exception):
    """Structured error raised by HMACClient for webserver communication failures.

    Attributes:
        status_code: HTTP status code (0 for connection/timeout errors).
        message: Human-readable error message.
        details: Optional dictionary with additional error context.
    """

    def __init__(self, status_code: int, message: str, details: dict | None = None):
        self.status_code = status_code
        self.message = message
        self.details = details or {}
        super().__init__(message)


def get_backend(runner):
    """Return the appropriate backend for the given runner's mode.

    Lazy import wrapper to avoid loading Django models at package import time.
    """
    from .backend_factory import get_backend as _get_backend

    return _get_backend(runner)
