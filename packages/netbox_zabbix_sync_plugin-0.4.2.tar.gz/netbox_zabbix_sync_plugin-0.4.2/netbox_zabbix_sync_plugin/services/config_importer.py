"""ConfigImporter service — AST-based parser for config.py files.

Parses a user-supplied ``config.py`` from the standalone netbox-zabbix-sync CLI
tool, extracts recognised sync-config assignments, serialises them to the
string format expected by :class:`SyncConfig`, and merges with defaults.

Security: uses ``ast.parse()`` + ``ast.literal_eval()`` only — no
``exec``/``eval``/``compile`` with execution.
"""

from __future__ import annotations

import ast
import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ImportResult:
    """Result of a full config import pipeline."""

    merged_config: dict[str, str] = field(default_factory=dict)
    recognized_keys: list[str] = field(default_factory=list)
    error: str | None = None


class ConfigImporter:
    """Parse, filter, serialise and merge a config.py source string."""

    CONNECTION_KEYS = frozenset(
        {
            "netbox_url",
            "netbox_token",
            "zabbix_url",
            "zabbix_user",
            "zabbix_password",
            "zabbix_token",
        }
    )

    # ------------------------------------------------------------------
    # parse
    # ------------------------------------------------------------------

    def parse(self, source: str) -> dict[str, Any]:
        """Parse a config.py source string using AST analysis.

        Returns a dict of all top-level variable assignments whose values are
        Python literals (str, int, float, bool, list, dict, None).  Ignores
        function calls, imports, class definitions, and any node whose value
        cannot be evaluated as a literal.

        Raises :class:`SyntaxError` with a descriptive message when *source*
        is not valid Python.
        """
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            msg = f"Invalid Python syntax: {exc.msg} (line {exc.lineno})"
            raise SyntaxError(msg) from exc

        result: dict[str, Any] = {}
        for node in ast.iter_child_nodes(tree):
            if not isinstance(node, ast.Assign):
                continue
            # Only handle simple single-target assignments (e.g. ``X = val``)
            if len(node.targets) != 1:
                continue
            target = node.targets[0]
            if not isinstance(target, ast.Name):
                continue
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                # Value is not a literal (e.g. function call) — skip silently
                continue
            result[target.id] = value
        return result

    # ------------------------------------------------------------------
    # filter_recognized
    # ------------------------------------------------------------------

    def filter_recognized(self, raw: dict[str, Any]) -> dict[str, Any]:
        """Retain only keys present in ``SYNC_CONFIG_DEFAULTS``, excluding
        connection keys.

        Returns a (possibly empty) dict.
        """
        from netbox_zabbix_sync_plugin.forms.setup_wizard import SYNC_CONFIG_DEFAULTS

        return {k: v for k, v in raw.items() if k in SYNC_CONFIG_DEFAULTS and k not in self.CONNECTION_KEYS}

    # ------------------------------------------------------------------
    # serialize
    # ------------------------------------------------------------------

    def serialize(self, recognized: dict[str, Any]) -> dict[str, str]:
        """Convert Python-typed values to the string format expected by
        :class:`SyncConfig`.

        Conversion rules (inverse of
        ``LocalBackend._deserialize_config()``):

        * ``bool``  → ``"true"`` / ``"false"``
        * ``dict`` / ``list`` → ``json.dumps(value)``
        * ``str``   → unchanged
        * ``int`` / ``float`` → ``str(value)``
        * ``None``  → ``"false"`` (treated as disabled)
        """
        out: dict[str, str] = {}
        for key, val in recognized.items():
            if isinstance(val, bool):
                out[key] = "true" if val else "false"
            elif isinstance(val, dict | list):
                out[key] = json.dumps(val)
            elif isinstance(val, str):
                out[key] = val
            elif isinstance(val, int | float):
                out[key] = str(val)
            elif val is None:
                out[key] = "false"
            else:
                # Fallback — shouldn't happen for literal-safe values
                out[key] = str(val)
        return out

    # ------------------------------------------------------------------
    # merge_with_defaults
    # ------------------------------------------------------------------

    def merge_with_defaults(self, serialized: dict[str, str]) -> dict[str, str]:
        """Start from serialised ``SYNC_CONFIG_DEFAULTS``, override with
        *serialized*.

        Returns a complete config dict ready for ``SyncConfig`` storage.
        """
        from netbox_zabbix_sync_plugin.forms.setup_wizard import SYNC_CONFIG_DEFAULTS

        defaults_serialized = self.serialize(dict(SYNC_CONFIG_DEFAULTS))
        defaults_serialized.update(serialized)
        return defaults_serialized

    # ------------------------------------------------------------------
    # import_config  (full pipeline)
    # ------------------------------------------------------------------

    def import_config(self, source: str) -> ImportResult:
        """Full pipeline: parse → filter → serialise → merge.

        Returns an :class:`ImportResult`.  On parse failure the result
        contains the error message and an empty ``merged_config``.
        """
        try:
            raw = self.parse(source)
        except SyntaxError as exc:
            return ImportResult(error=str(exc))

        recognized = self.filter_recognized(raw)
        serialized = self.serialize(recognized)
        merged = self.merge_with_defaults(serialized)

        return ImportResult(
            merged_config=merged,
            recognized_keys=sorted(recognized.keys()),
        )
