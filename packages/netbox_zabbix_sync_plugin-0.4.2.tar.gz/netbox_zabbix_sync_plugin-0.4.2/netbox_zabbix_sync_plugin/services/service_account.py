"""
Service account bootstrapping for local-mode runners.

Creates or reuses a dedicated Django user (``netbox-zabbix-sync``) with an API
token and the NetBox ObjectPermissions required by the sync library to read
devices, VMs, sites, regions, site groups, clusters, custom fields, and to
write (change) devices and VMs.
"""

from __future__ import annotations

import logging

from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from users.models import Token
from users.models.permissions import ObjectPermission

logger = logging.getLogger(__name__)

SERVICE_ACCOUNT_USERNAME = "netbox-zabbix-sync"

# Read-only object types (app_label, model)
_READ_OBJECT_TYPES = (
    ("dcim", "device"),
    ("dcim", "devicetype"),
    ("dcim", "region"),
    ("dcim", "sitegroup"),
    ("dcim", "site"),
    ("extras", "customfield"),
    ("virtualization", "cluster"),
    ("virtualization", "virtualmachine"),
    ("netbox_zabbix_sync_plugin", "synclog"),
    ("netbox_zabbix_sync_plugin", "connectconfig"),
    ("netbox_zabbix_sync_plugin", "syncconfig"),
    ("netbox_zabbix_sync_plugin", "synchronizationrunner"),
)

# Read + write object types (app_label, model)
_WRITE_OBJECT_TYPES = (
    ("dcim", "device"),
    ("virtualization", "virtualmachine"),
)

# Journal entry permissions — view + add (app_label, model)
_JOURNAL_OBJECT_TYPES = (("extras", "journalentry"),)

_READ_PERM_NAME = "Netbox-Zabbix-sync read permissions"
_WRITE_PERM_NAME = "Netbox-Zabbix-sync write permissions"
_JOURNAL_PERM_NAME = "Netbox-Zabbix-sync journal permissions"


def _ensure_object_permission(name: str, object_types: tuple, actions: list, user) -> None:
    """Create or update a NetBox ObjectPermission and assign it to the user."""
    perm, created = ObjectPermission.objects.get_or_create(
        name=name,
        defaults={"actions": actions, "enabled": True},
    )
    if not created:
        # Update actions in case they changed
        if set(perm.actions) != set(actions):
            perm.actions = actions
            perm.save()

    # Set the object types
    cts = []
    for app_label, model in object_types:
        try:
            ct = ContentType.objects.get(app_label=app_label, model=model)
            cts.append(ct)
        except ContentType.DoesNotExist:
            logger.warning(
                "ContentType %s.%s not found — skipping for permission '%s'",
                app_label,
                model,
                name,
            )
    perm.object_types.set(cts)

    # Ensure the user is assigned
    if not perm.users.filter(pk=user.pk).exists():
        perm.users.add(user)

    logger.debug("ObjectPermission '%s': actions=%s, object_types=%d, user=%s", name, actions, len(cts), user.username)


def service_account_exists() -> bool:
    """Return ``True`` if the service account user already exists."""
    User = get_user_model()
    return User.objects.filter(username=SERVICE_ACCOUNT_USERNAME).exists()


def ensure_service_account(password: str | None = None) -> tuple:
    """Create or reuse the service account and return ``(user, token_plaintext)``.

    * If the user does not exist, *password* is required and a new user is
      created with that password.
    * If the user already exists, the password is **not** changed (the
      *password* parameter is ignored).  Only a fresh API token is generated.
    * Deletes any previous API tokens for the user and generates a fresh v2 one.
    * Creates NetBox ObjectPermissions for read and write access.
    * Returns the user instance and the plaintext token value.
    """
    User = get_user_model()

    # --- user -----------------------------------------------------------
    user, created = User.objects.get_or_create(
        username=SERVICE_ACCOUNT_USERNAME,
        defaults={"is_active": True},
    )
    if created:
        if not password:
            raise ValueError("Password is required when creating a new service account.")
        user.set_password(password)
        user.save()
        logger.info("Service account '%s': created", SERVICE_ACCOUNT_USERNAME)
    else:
        logger.info("Service account '%s': reused (password unchanged)", SERVICE_ACCOUNT_USERNAME)

    # --- permissions (NetBox ObjectPermission) --------------------------
    _ensure_object_permission(_READ_PERM_NAME, _READ_OBJECT_TYPES, ["view"], user)
    _ensure_object_permission(_WRITE_PERM_NAME, _WRITE_OBJECT_TYPES, ["view", "change"], user)
    _ensure_object_permission(_JOURNAL_PERM_NAME, _JOURNAL_OBJECT_TYPES, ["view", "add"], user)

    # --- token ----------------------------------------------------------
    # Remove any existing tokens so we always return a fresh, known value.
    Token.objects.filter(user=user).delete()

    token = Token(user=user)
    token.save()

    # Build the full plaintext token string.
    # v2 tokens (NetBox 4.5+) use the format "nbt_{key}.{secret}".
    # v1 tokens store the plaintext directly.
    if token.v2:
        plaintext = f"nbt_{token.key}.{token.token}"
    else:
        plaintext = token.token

    logger.info("Service account '%s': new API token generated (v%s)", SERVICE_ACCOUNT_USERNAME, token.version)

    return (user, plaintext)
