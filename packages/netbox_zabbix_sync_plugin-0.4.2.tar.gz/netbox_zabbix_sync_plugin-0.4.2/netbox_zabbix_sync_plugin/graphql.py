"""
GraphQL schema for NetBox Zabbix Sync Plugin.

For more information on NetBox GraphQL, see:
https://docs.netbox.dev/en/stable/plugins/development/graphql/

For Strawberry GraphQL documentation, see:
https://strawberry.rocks/
"""

import strawberry
import strawberry_django

from .models import SynchronizationRunner


@strawberry_django.type(
    SynchronizationRunner,
    fields=[
        "id",
        "name",
        "description",
        "url",
        "tags",
        "custom_fields",
        "created",
        "last_updated",
    ],
)
class SynchronizationRunnerType:
    """GraphQL type for SynchronizationRunner model.

    Note: ``token`` is deliberately excluded to prevent leaking the HMAC secret.
    """

    pass


@strawberry.type(name="Query")
class NetBoxZabbixSyncQuery:
    """GraphQL queries for NetBox Zabbix Sync Plugin."""

    synchronizationrunner: SynchronizationRunnerType = strawberry_django.field()
    synchronizationrunner_list: list[SynchronizationRunnerType] = strawberry_django.field()


schema = [
    NetBoxZabbixSyncQuery,
]
