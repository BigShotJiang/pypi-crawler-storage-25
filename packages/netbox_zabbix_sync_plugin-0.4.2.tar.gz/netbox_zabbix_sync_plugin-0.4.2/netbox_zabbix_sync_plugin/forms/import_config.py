"""
Form for importing a config.py file.

Provides a single FileField with validation for file size (1 MB max)
and file extension (.py only).
"""

from django import forms
from django.core.exceptions import ValidationError


class ImportConfigForm(forms.Form):
    """Upload form for a netbox-zabbix-sync config.py file."""

    config_file = forms.FileField(
        label="config.py file",
        help_text="Upload your netbox-zabbix-sync config.py file",
    )

    MAX_SIZE = 1 * 1024 * 1024  # 1 MB

    def clean_config_file(self):
        f = self.cleaned_data["config_file"]
        if not f.name.endswith(".py"):
            raise ValidationError("Only .py files are accepted.")
        if f.size > self.MAX_SIZE:
            raise ValidationError("File exceeds the 1 MB size limit.")
        return f
