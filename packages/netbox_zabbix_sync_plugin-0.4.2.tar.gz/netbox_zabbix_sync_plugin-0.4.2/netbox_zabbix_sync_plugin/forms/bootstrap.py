"""
Forms for the Bootstrap Utility.

Checkboxes for selecting which resources to create during bootstrap.
"""

from django import forms


class BootstrapForm(forms.Form):
    """Bootstrap utility form — select which resources to create."""

    create_custom_fields = forms.BooleanField(
        label="Create Custom Fields",
        required=False,
        initial=True,
        help_text="Create custom fields based on the webserver's sync config (device_cf, template_cf)",
    )
    create_config_contexts = forms.BooleanField(
        label="Create Example Config Contexts",
        required=False,
        initial=True,
        help_text="Create example config contexts for SNMPv3, custom template, and multi-template",
    )
    create_sync_schedule = forms.BooleanField(
        label="Create Default Hourly Sync Schedule",
        required=False,
        initial=False,
        help_text="Enqueue a default hourly sync job for the selected runner",
    )
    create_custom_links = forms.BooleanField(
        label="Create Zabbix Custom Links",
        required=False,
        initial=True,
        help_text="Create custom links on Devices and VMs that link to the Zabbix frontend (uses the preferred runner's Zabbix URL)",
    )
