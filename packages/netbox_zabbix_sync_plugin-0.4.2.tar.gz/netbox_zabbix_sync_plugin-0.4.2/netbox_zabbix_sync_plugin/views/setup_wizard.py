"""
Views for the Setup Wizard.

Four-step wizard using Django session to track state:
- Step 1: Mode selection + credentials, validate, create Runner
- Step 2: Connect config (NetBox/Zabbix credentials), POST to webserver or save locally
- Step 3: Sync config options, POST to webserver or save locally
- Step 4: Bootstrap — create custom fields, config contexts, sync schedule
"""

import json
import logging

from django import forms as django_forms
from django.contrib import messages
from django.shortcuts import redirect, render
from django.views.generic import View

from ..forms.bootstrap import BootstrapForm
from ..forms.import_config import ImportConfigForm
from ..forms.setup_wizard import (
    SYNC_CONFIG_CATEGORIES,
    SetupWizardStep1Form,
    SetupWizardStep2Form,
    SetupWizardStep3Form,
)
from ..models import ConnectConfig, SyncConfig, SynchronizationRunner
from ..models.synchronization_runner import RunnerMode
from ..services import WebserverError
from ..services.config_importer import ConfigImporter
from ..services.hmac_client import HMACClient
from ..services.service_account import ensure_service_account, service_account_exists
from ..views.bootstrap import (
    CONFIG_CONTEXTS,
    _create_config_contexts,
    _create_custom_fields,
    _create_custom_links,
    _get_custom_field_defs_from_runner,
    _get_custom_link_defs,
)

logger = logging.getLogger(__name__)

SESSION_RUNNER_ID = "wizard_runner_id"
SESSION_STEP = "wizard_step"
SESSION_NETBOX_URL = "wizard_netbox_url"

# Form fields that are BooleanField in SetupWizardStep3Form
_BOOLEAN_FIELDS = frozenset(
    {
        "templates_config_context",
        "templates_config_context_overrule",
        "clustering",
        "create_hostgroups",
        "create_journal",
        "traverse_regions",
        "traverse_site_groups",
        "extended_site_properties",
        "inventory_sync",
        "tag_sync",
        "tag_lower",
        "sync_vms",
        "full_proxy_sync",
    }
)

# Form fields that use Textarea widgets (JSON content)
_JSON_FIELDS = frozenset(
    {
        "device_inventory_map",
        "vm_inventory_map",
        "device_usermacro_map",
        "vm_usermacro_map",
        "device_tag_map",
        "vm_tag_map",
        "zabbix_device_removal",
        "zabbix_device_disable",
        "nb_device_filter",
        "nb_vm_filter",
    }
)


def _config_to_form_initial(config: dict[str, str]) -> dict:
    """Convert a merged config dict (string values) to form-compatible initial values.

    - Boolean strings "true"/"false" → Python bool (for BooleanField)
    - JSON strings → pretty-printed JSON string (for Textarea fields)
    - Plain strings → unchanged
    """
    initial: dict = {}
    for key, value in config.items():
        if key in _BOOLEAN_FIELDS:
            initial[key] = value.lower() == "true"
        elif key in _JSON_FIELDS:
            # Try to parse and pretty-print JSON; fall back to raw string
            try:
                parsed = json.loads(value)
                initial[key] = json.dumps(parsed, indent=2)
            except (json.JSONDecodeError, TypeError):
                initial[key] = value
        else:
            initial[key] = value
    return initial


class SetupWizardStep1View(View):
    """Step 1: Mode selection + credentials, validate connectivity, create Runner."""

    template_name = "netbox_zabbix_sync_plugin/setup_wizard_step1.html"

    def get(self, request):
        account_exists = service_account_exists()
        form = SetupWizardStep1Form()

        if account_exists:
            # Password is not needed when reusing an existing service account
            form.fields["service_account_password"].required = False

        # Warn if a local runner already exists — re-running the wizard
        # will regenerate the service account token and invalidate the old one.
        existing_local = SynchronizationRunner.objects.filter(mode=RunnerMode.LOCAL).first()
        if existing_local:
            messages.warning(
                request,
                f"A local runner '{existing_local.name}' is already configured. "
                "Re-running the wizard will generate a new API token and invalidate the current one.",
            )

        return render(
            request,
            self.template_name,
            {"form": form, "service_account_exists": account_exists},
        )

    def post(self, request):
        account_exists = service_account_exists()
        form = SetupWizardStep1Form(request.POST)

        if account_exists:
            # Password is not needed when reusing an existing service account
            form.fields["service_account_password"].required = False

        if not form.is_valid():
            return render(
                request,
                self.template_name,
                {"form": form, "service_account_exists": account_exists},
            )

        mode = form.cleaned_data["mode"]

        if mode == RunnerMode.REMOTE:
            return self._handle_remote(request, form)
        return self._handle_local(request, form)

    def _handle_remote(self, request, form):
        """Remote mode: health check + create runner with url/token (existing flow)."""
        url = form.cleaned_data["url"]
        token = form.cleaned_data["token"]

        # Validate connectivity via health check (unauthenticated GET /)
        client = HMACClient(url, token)
        try:
            client.health_check()
        except WebserverError as e:
            messages.error(request, e.message)
            return render(request, self.template_name, {"form": form})
        except Exception:
            logger.exception("Unexpected error during health check for %s", url)
            messages.error(request, "An unexpected error occurred while connecting to the webserver.")
            return render(request, self.template_name, {"form": form})

        # Validate HMAC token with an authenticated request (GET /connect_config)
        try:
            client.get("/connect_config")
        except WebserverError as e:
            messages.error(request, e.message)
            return render(request, self.template_name, {"form": form})
        except Exception:
            logger.exception("Unexpected error validating token for %s", url)
            messages.error(request, "An unexpected error occurred while validating the token.")
            return render(request, self.template_name, {"form": form})

        # Create or update the Runner
        runner, _created = SynchronizationRunner.objects.update_or_create(
            url=url,
            defaults={"name": f"Runner ({url})", "token": token, "mode": RunnerMode.REMOTE},
        )

        # Store wizard state in session
        request.session[SESSION_RUNNER_ID] = runner.pk
        request.session[SESSION_STEP] = 2

        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step2")

    def _handle_local(self, request, form):
        """Local mode: create runner with blank url/token, create service account."""
        account_exists = service_account_exists()
        password = form.cleaned_data.get("service_account_password") or None

        try:
            _user, token_plaintext = ensure_service_account(password)
        except Exception:
            logger.exception("Failed to create service account")
            messages.error(request, "An unexpected error occurred while creating the service account.")
            return render(
                request,
                self.template_name,
                {"form": form, "service_account_exists": account_exists},
            )

        # Create or update the Runner (local mode, blank url/token)
        runner, _created = SynchronizationRunner.objects.update_or_create(
            name="Local Runner",
            defaults={"url": "", "token": "", "mode": RunnerMode.LOCAL},
        )

        # Build netbox_url from the deployment type and request hostname
        scheme = form.get_netbox_scheme()
        port = form.get_netbox_port()
        deployment_type = form.cleaned_data.get("deployment_type", "docker")

        # For Docker deployments, use the container service name "netbox" since
        # the sync runs inside the same Docker network where 127.0.0.1 does not
        # resolve to the NetBox container.
        if deployment_type == "docker":
            hostname = "netbox"
        else:
            hostname = request.get_host().split(":")[0]  # strip any existing port
        # Omit port from URL for standard ports
        if (scheme == "https" and port == 443) or (scheme == "http" and port == 80):
            netbox_url = f"{scheme}://{hostname}/"
        else:
            netbox_url = f"{scheme}://{hostname}:{port}/"

        # Store wizard state in session
        request.session[SESSION_RUNNER_ID] = runner.pk
        request.session[SESSION_STEP] = 2
        request.session[SESSION_NETBOX_URL] = netbox_url
        # Store the token for use in step 2 when creating ConnectConfig
        request.session["wizard_netbox_token"] = token_plaintext

        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step2")


class SetupWizardStep2View(View):
    """Step 2: Collect connect config and POST to /connect_config."""

    template_name = "netbox_zabbix_sync_plugin/setup_wizard_step2.html"

    def _get_runner(self, request):
        runner_id = request.session.get(SESSION_RUNNER_ID)
        step = request.session.get(SESSION_STEP, 0)
        if not runner_id or step < 2:
            return None
        try:
            return SynchronizationRunner.objects.get(pk=runner_id)
        except SynchronizationRunner.DoesNotExist:
            return None

    def _is_local(self, runner):
        return runner.mode == RunnerMode.LOCAL

    def get(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        is_local = self._is_local(runner)
        initial = {}
        if is_local:
            # Pre-populate netbox_url from session (set in step 1)
            initial["netbox_url"] = request.session.get(SESSION_NETBOX_URL, "")

        form = SetupWizardStep2Form(initial=initial)

        if is_local:
            # netbox_token is auto-generated for local mode; hide and make optional
            form.fields["netbox_token"].required = False
            form.fields["netbox_token"].widget = django_forms.HiddenInput()

        return render(
            request,
            self.template_name,
            {"form": form, "runner": runner, "is_local": is_local},
        )

    def post(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        is_local = self._is_local(runner)
        form = SetupWizardStep2Form(request.POST)

        if is_local:
            # netbox_token is auto-generated for local mode; not required from form
            form.fields["netbox_token"].required = False

        if not form.is_valid():
            if is_local:
                form.fields["netbox_token"].widget = django_forms.HiddenInput()
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": is_local},
            )

        if is_local:
            return self._handle_local_post(request, form, runner)
        return self._handle_remote_post(request, form, runner)

    def _handle_local_post(self, request, form, runner):
        """Local mode: validate Zabbix connectivity and save to ConnectConfig."""
        payload = form.get_connect_config_payload()

        # Use netbox_url and netbox_token from session (set in step 1)
        netbox_url = request.session.get(SESSION_NETBOX_URL, "")
        netbox_token = request.session.get("wizard_netbox_token", "")

        # Validate Zabbix connectivity before saving
        zabbix_url = payload.get("zabbix_url", "")
        try:
            self._validate_zabbix_connectivity(payload, zabbix_url)
        except Exception as e:
            messages.error(request, f"Failed to connect to Zabbix: {e}")
            form.fields["netbox_token"].widget = django_forms.HiddenInput()
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": True},
            )

        # Create or update ConnectConfig for this runner
        ConnectConfig.objects.update_or_create(
            runner=runner,
            defaults={
                "netbox_url": netbox_url,
                "netbox_token": netbox_token,
                "zabbix_url": zabbix_url,
                "zabbix_user": payload.get("zabbix_user", ""),
                "zabbix_password": payload.get("zabbix_password", ""),
                "zabbix_token": payload.get("zabbix_token", ""),
            },
        )

        request.session[SESSION_STEP] = 3
        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step3")

    def _validate_zabbix_connectivity(self, payload, zabbix_url):
        """Attempt to authenticate with Zabbix using the provided credentials."""
        from zabbix_utils import ZabbixAPI

        zapi = ZabbixAPI(url=zabbix_url)
        if payload.get("zabbix_token"):
            zapi.login(token=payload["zabbix_token"])
        else:
            zapi.login(user=payload.get("zabbix_user", ""), password=payload.get("zabbix_password", ""))
        zapi.logout()

    def _handle_remote_post(self, request, form, runner):
        """Remote mode: POST to webserver via HMACClient (existing flow)."""
        client = HMACClient(runner.url, runner.token)
        payload = form.get_connect_config_payload()
        try:
            client.post("/connect_config", payload)
        except WebserverError as e:
            messages.error(request, e.message)
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": False},
            )
        except Exception:
            logger.exception("Unexpected error posting connect config for runner %s", runner.pk)
            messages.error(request, "An unexpected error occurred while saving credentials.")
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": False},
            )

        request.session[SESSION_STEP] = 3
        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step3")


class SetupWizardStep3View(View):
    """Step 3: Collect sync config and POST to /sync_config."""

    template_name = "netbox_zabbix_sync_plugin/setup_wizard_step3.html"

    def _get_runner(self, request):
        runner_id = request.session.get(SESSION_RUNNER_ID)
        step = request.session.get(SESSION_STEP, 0)
        if not runner_id or step < 3:
            return None
        try:
            return SynchronizationRunner.objects.get(pk=runner_id)
        except SynchronizationRunner.DoesNotExist:
            return None

    def _is_local(self, runner):
        return runner.mode == RunnerMode.LOCAL

    def get(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")
        form = SetupWizardStep3Form()
        return render(
            request,
            self.template_name,
            {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
        )

    def post(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        action = request.POST.get("action")

        if action == "import":
            return self._handle_import(request, runner)

        form = SetupWizardStep3Form(request.POST)
        if not form.is_valid():
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )

        if self._is_local(runner):
            return self._handle_local_post(request, form, runner)
        return self._handle_remote_post(request, form, runner)

    def _handle_import(self, request, runner):
        """Handle action=import: validate upload, parse config, re-render form with imported values."""
        import_form = ImportConfigForm(request.POST, request.FILES)
        if not import_form.is_valid():
            # Re-render with a blank sync config form and the import errors
            form = SetupWizardStep3Form()
            return render(
                request,
                self.template_name,
                {
                    "form": form,
                    "runner": runner,
                    "categories": SYNC_CONFIG_CATEGORIES,
                    "import_form": import_form,
                },
            )

        uploaded_file = import_form.cleaned_data["config_file"]
        source = uploaded_file.read().decode("utf-8", errors="replace")

        importer = ConfigImporter()
        result = importer.import_config(source)

        if result.error:
            messages.error(request, f"Failed to parse config.py: {result.error}")
            form = SetupWizardStep3Form()
            return render(
                request,
                self.template_name,
                {
                    "form": form,
                    "runner": runner,
                    "categories": SYNC_CONFIG_CATEGORIES,
                    "import_form": import_form,
                },
            )

        # Convert merged config to form-compatible initial values
        initial = _config_to_form_initial(result.merged_config)
        form = SetupWizardStep3Form(initial=initial)

        count = len(result.recognized_keys)
        messages.success(
            request,
            f"Imported {count} setting{'s' if count != 1 else ''} from config.py. "
            "Review the values below and click Save & Continue.",
        )

        return render(
            request,
            self.template_name,
            {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
        )

    def _handle_local_post(self, request, form, runner):
        """Local mode: save sync config to SyncConfig model."""
        payload = form.get_sync_config_payload()

        SyncConfig.objects.update_or_create(
            runner=runner,
            defaults={"config": payload.get("config", payload)},
        )

        request.session[SESSION_STEP] = 4
        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step4")

    def _handle_remote_post(self, request, form, runner):
        """Remote mode: POST to webserver via HMACClient (existing flow)."""
        client = HMACClient(runner.url, runner.token)
        payload = form.get_sync_config_payload()
        try:
            client.post("/sync_config", payload)
        except WebserverError as e:
            messages.error(request, e.message)
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )
        except Exception:
            logger.exception("Unexpected error posting sync config for runner %s", runner.pk)
            messages.error(request, "An unexpected error occurred while saving sync configuration.")
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )

        request.session[SESSION_STEP] = 4
        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step4")


# Default custom field definitions used when sync config is unavailable
DEFAULT_CUSTOM_FIELDS = [
    {
        "name": "zabbix_hostid",
        "label": "Zabbix Hostid",
        "type": "integer",
        "content_types": ["dcim.device", "virtualization.virtualmachine"],
        "description": "Zabbix host ID (default — sync config unavailable)",
    },
    {
        "name": "zabbix_template",
        "label": "Zabbix Template",
        "type": "text",
        "content_types": ["dcim.devicetype"],
        "description": "Zabbix template name (default — sync config unavailable)",
    },
]


class SetupWizardStep4View(View):
    """Step 4: Bootstrap — create custom fields, config contexts, custom links, sync schedule."""

    template_name = "netbox_zabbix_sync_plugin/setup_wizard_step4.html"
    complete_template_name = "netbox_zabbix_sync_plugin/setup_wizard_complete.html"

    def _get_runner(self, request):
        """Validate session state and return runner, or None."""
        runner_id = request.session.get(SESSION_RUNNER_ID)
        step = request.session.get(SESSION_STEP, 0)
        if not runner_id or step < 4:
            return None
        try:
            return SynchronizationRunner.objects.get(pk=runner_id)
        except SynchronizationRunner.DoesNotExist:
            return None

    def _get_custom_fields(self, runner):
        """Resolve custom field defs from runner's sync config, with fallback.

        Returns (custom_fields, used_fallback) tuple.
        """
        try:
            return _get_custom_field_defs_from_runner(runner), False
        except Exception:
            logger.warning(
                "Could not fetch sync config from runner '%s', using defaults",
                runner.name,
            )
            return DEFAULT_CUSTOM_FIELDS, True

    def _get_zabbix_base_url_and_device_cf(self, runner):
        """Resolve the Zabbix base URL and device_cf name from the runner."""
        from ..services.zabbix_client import get_zabbix_base_url

        zabbix_base_url = None
        device_cf = "zabbix_hostid"

        try:
            zabbix_base_url = get_zabbix_base_url(runner)
        except Exception:
            logger.warning("Could not resolve Zabbix base URL from runner '%s'", runner.name)

        try:
            from ..services import get_backend

            backend = get_backend(runner)
            config = backend.get_sync_config()
            device_cf = config.get("device_cf", "zabbix_hostid")
        except Exception:
            pass

        return zabbix_base_url, device_cf

    def _build_context(self, form, runner, custom_fields):
        """Build the template context with all preview data."""
        zabbix_base_url, device_cf = self._get_zabbix_base_url_and_device_cf(runner)
        custom_links = _get_custom_link_defs(zabbix_base_url or "http://your-zabbix-server", device_cf)
        return {
            "form": form,
            "runner": runner,
            "custom_fields": custom_fields,
            "config_contexts": CONFIG_CONTEXTS,
            "custom_links": custom_links,
            "zabbix_base_url": zabbix_base_url,
        }

    def get(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        custom_fields, used_fallback = self._get_custom_fields(runner)
        if used_fallback:
            messages.warning(request, "Could not fetch sync config, using defaults.")

        form = BootstrapForm()
        return render(request, self.template_name, self._build_context(form, runner, custom_fields))

    def post(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        custom_fields, used_fallback = self._get_custom_fields(runner)
        form = BootstrapForm(request.POST)

        if not form.is_valid():
            return render(request, self.template_name, self._build_context(form, runner, custom_fields))

        results = {}
        has_error = False

        # Create custom fields
        if form.cleaned_data.get("create_custom_fields"):
            try:
                created, skipped = _create_custom_fields(custom_fields)
                results["custom_fields"] = {"created": created, "skipped": skipped}
            except Exception:
                logger.exception("Error creating custom fields during wizard step 4")
                messages.error(request, "Error creating custom fields.")
                has_error = True

        # Create config contexts
        if form.cleaned_data.get("create_config_contexts"):
            try:
                created, skipped = _create_config_contexts()
                results["config_contexts"] = {"created": created, "skipped": skipped}
            except Exception:
                logger.exception("Error creating config contexts during wizard step 4")
                messages.error(request, "Error creating config contexts.")
                has_error = True

        # Create custom links
        if form.cleaned_data.get("create_custom_links"):
            try:
                zabbix_base_url, device_cf = self._get_zabbix_base_url_and_device_cf(runner)
                if zabbix_base_url:
                    created, skipped = _create_custom_links(zabbix_base_url, device_cf)
                    results["custom_links"] = {"created": created, "skipped": skipped}
                else:
                    messages.warning(
                        request,
                        "Could not determine Zabbix base URL — custom links were not created. "
                        "You can create them later by re-running the wizard after configuring the connect config.",
                    )
                    results["custom_links"] = {"status": "no_url"}
            except Exception:
                logger.exception("Error creating custom links during wizard step 4")
                messages.error(request, "Error creating custom links.")
                has_error = True

        # Create sync schedule
        if form.cleaned_data.get("create_sync_schedule"):
            try:
                from ..jobs import SyncJob

                SyncJob.enqueue_once(instance=runner, interval=60)
                results["sync_schedule"] = {"status": "scheduled", "runner": runner.name}
            except Exception:
                logger.exception("Error creating sync schedule during wizard step 4")
                messages.error(request, "Error creating sync schedule.")
                has_error = True

        # On error, remain on Step 4 so the user can retry
        if has_error:
            return render(request, self.template_name, self._build_context(form, runner, custom_fields))

        # Success — clear all wizard session keys
        for key in (SESSION_RUNNER_ID, SESSION_STEP, SESSION_NETBOX_URL, "wizard_netbox_token"):
            request.session.pop(key, None)

        return render(
            request,
            self.complete_template_name,
            {
                "runner": runner,
                "results": results,
            },
        )
