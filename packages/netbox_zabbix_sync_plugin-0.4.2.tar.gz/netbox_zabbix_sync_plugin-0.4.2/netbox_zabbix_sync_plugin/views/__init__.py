"""
Views for NetBox Zabbix Sync Plugin.
"""

from .connect_config import (
    ConnectConfigEditView,
    ConnectConfigView,
)
from .force_sync import (
    DeviceForceSyncView,
    VMForceSyncView,
)
from .import_config import ImportConfigView
from .setup_wizard import (
    SetupWizardStep1View,
    SetupWizardStep2View,
    SetupWizardStep3View,
    SetupWizardStep4View,
)
from .sync_config import (
    SyncConfigDeleteKeyView,
    SyncConfigEditView,
    SyncConfigView,
)
from .sync_log import (
    RunnerSyncStatusView,
    SyncLogDetailView,
    SyncLogListView,
    SyncLogPollView,
)
from .sync_schedule import SyncScheduleView
from .synchronization import ScheduleSynchronizationView
from .synchronization_runner import (
    SynchronizationRunnerBulkDeleteView,
    SynchronizationRunnerBulkEditView,
    SynchronizationRunnerBulkImportView,
    SynchronizationRunnerDeleteView,
    SynchronizationRunnerEditView,
    SynchronizationRunnerListView,
    SynchronizationRunnerView,
)
from .zabbix_tab import DeviceZabbixTabView, VMZabbixTabView, ZabbixTabFetchView

__all__ = (
    "ConnectConfigView",
    "ConnectConfigEditView",
    "ImportConfigView",
    "DeviceForceSyncView",
    "VMForceSyncView",
    "DeviceZabbixTabView",
    "VMZabbixTabView",
    "ZabbixTabFetchView",
    "SetupWizardStep1View",
    "SetupWizardStep2View",
    "SetupWizardStep3View",
    "SetupWizardStep4View",
    "SyncConfigView",
    "SyncConfigEditView",
    "SyncConfigDeleteKeyView",
    "SyncLogListView",
    "SyncLogDetailView",
    "SyncLogPollView",
    "RunnerSyncStatusView",
    "SyncScheduleView",
    "ScheduleSynchronizationView",
    "SynchronizationRunnerView",
    "SynchronizationRunnerListView",
    "SynchronizationRunnerEditView",
    "SynchronizationRunnerDeleteView",
    "SynchronizationRunnerBulkImportView",
    "SynchronizationRunnerBulkEditView",
    "SynchronizationRunnerBulkDeleteView",
)
