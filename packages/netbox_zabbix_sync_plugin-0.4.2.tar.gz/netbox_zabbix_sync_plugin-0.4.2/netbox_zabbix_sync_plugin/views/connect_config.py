"""
Views for Connect Config management.

Display and edit connect config (NetBox/Zabbix credentials) stored on the webserver.
"""

import logging

from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import View

from ..forms.connect_config import ConnectConfigEditForm
from ..models import SynchronizationRunner
from ..services import WebserverError, get_backend
from ..services.masking import SENSITIVE_FIELDS, mask_value

logger = logging.getLogger(__name__)


class ConnectConfigView(View):
    """Display connect config with masked sensitive fields."""

    template_name = "netbox_zabbix_sync_plugin/connect_config.html"

    # All expected fields in display order
    _DISPLAY_FIELDS = (
        "netbox_url",
        "netbox_token",
        "zabbix_url",
        "zabbix_user",
        "zabbix_password",
        "zabbix_token",
    )

    def get(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        from ..models.synchronization_runner import RunnerMode

        is_remote = runner.mode == RunnerMode.REMOTE

        try:
            backend = get_backend(runner)
            if hasattr(backend, "get_connect_config_display"):
                raw_config = backend.get_connect_config_display()
            else:
                config = backend.get_connect_config()
                raw_config = {}
                for key, value in config.items():
                    if key in SENSITIVE_FIELDS and value:
                        raw_config[key] = mask_value(str(value))
                    else:
                        raw_config[key] = value
        except RuntimeError as e:
            messages.error(request, str(e))
            return redirect(runner.get_absolute_url())
        except WebserverError as e:
            messages.error(request, e.message)
            return redirect(runner.get_absolute_url())
        except Exception:
            logger.exception("Unexpected error fetching connect config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return redirect(runner.get_absolute_url())

        # Ensure all expected fields are present in display order.
        # For remote runners, missing sensitive fields get a placeholder.
        display_config = {}
        for key in self._DISPLAY_FIELDS:
            if key in raw_config:
                display_config[key] = raw_config[key]
            elif is_remote and key in SENSITIVE_FIELDS:
                display_config[key] = "(managed on webserver)"
            else:
                display_config[key] = ""

        return render(
            request,
            self.template_name,
            {"runner": runner, "config": display_config, "is_remote": is_remote},
        )


class ConnectConfigEditView(View):
    """Edit connect config and send PATCH with only changed fields."""

    template_name = "netbox_zabbix_sync_plugin/connect_config_edit.html"

    def _get_current_config(self, runner):
        backend = get_backend(runner)
        return backend.get_connect_config()

    def get(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)

        try:
            config = self._get_current_config(runner)
        except RuntimeError as e:
            messages.error(request, str(e))
            return redirect(runner.get_absolute_url())
        except WebserverError as e:
            messages.error(request, e.message)
            return redirect(runner.get_absolute_url())
        except Exception:
            logger.exception("Unexpected error fetching connect config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return redirect(runner.get_absolute_url())

        # Determine auth type from current config
        auth_type = "token" if config.get("zabbix_token") else "userpass"

        # Auto-check "edit" toggles only when the stored value is genuinely
        # empty — an empty credential will never work so the user must fill it.
        # For remote runners the API hides sensitive values, so we can never
        # know whether they are stored; default to unchecked (user opts in).
        from ..models.synchronization_runner import RunnerMode

        if runner.mode == RunnerMode.LOCAL:
            cc = runner.connect_config
            edit_netbox_token = not cc.netbox_token
            edit_zabbix_password = not cc.zabbix_password
            edit_zabbix_token = not cc.zabbix_token
        else:
            # Remote: sensitive fields are hidden by the API — never auto-check
            edit_netbox_token = False
            edit_zabbix_password = False
            edit_zabbix_token = False

        form = ConnectConfigEditForm(
            initial={
                "netbox_url": config.get("netbox_url", ""),
                "zabbix_url": config.get("zabbix_url", ""),
                "zabbix_auth_type": auth_type,
                "zabbix_user": config.get("zabbix_user", ""),
                "edit_netbox_token": edit_netbox_token,
                "edit_zabbix_password": edit_zabbix_password,
                "edit_zabbix_token": edit_zabbix_token,
            }
        )
        return render(request, self.template_name, {"form": form, "runner": runner})

    def post(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        form = ConnectConfigEditForm(request.POST)

        if not form.is_valid():
            return render(request, self.template_name, {"form": form, "runner": runner})

        try:
            original = self._get_current_config(runner)
        except RuntimeError as e:
            messages.error(request, str(e))
            return render(request, self.template_name, {"form": form, "runner": runner})
        except WebserverError as e:
            messages.error(request, e.message)
            return render(request, self.template_name, {"form": form, "runner": runner})
        except Exception:
            logger.exception("Unexpected error fetching connect config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return render(request, self.template_name, {"form": form, "runner": runner})

        payload = form.get_patch_payload(original)
        if not payload:
            messages.info(request, "No changes detected.")
            return redirect("plugins:netbox_zabbix_sync_plugin:connect_config", pk=pk)

        backend = get_backend(runner)
        try:
            backend.patch_connect_config(payload)
        except RuntimeError as e:
            messages.error(request, str(e))
            return render(request, self.template_name, {"form": form, "runner": runner})
        except WebserverError as e:
            messages.error(request, e.message)
            return render(request, self.template_name, {"form": form, "runner": runner})
        except Exception:
            logger.exception("Unexpected error patching connect config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return render(request, self.template_name, {"form": form, "runner": runner})

        messages.success(request, "Connect configuration updated.")
        return redirect("plugins:netbox_zabbix_sync_plugin:connect_config", pk=pk)
