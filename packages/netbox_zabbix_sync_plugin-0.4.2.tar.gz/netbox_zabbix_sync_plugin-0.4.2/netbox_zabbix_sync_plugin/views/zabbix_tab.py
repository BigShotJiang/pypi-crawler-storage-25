"""
Zabbix tab views for Device and VirtualMachine detail pages.

Registers as additional tabs on the core Device and VM views using
NetBox's register_model_view() mechanism.
"""

import logging

from dcim.models import Device
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views import View
from netbox.views import generic
from utilities.views import ViewTab, register_model_view
from virtualization.models import VirtualMachine

from ..models import SynchronizationRunner
from ..services.config_cache import get_device_cf
from ..services.zabbix_client import get_host_maintenance, get_host_problems, get_zabbix_base_url

logger = logging.getLogger(__name__)


def _has_primary_ip(obj) -> bool:
    """Return True if the object has any primary IP (v4 or v6)."""
    return bool(getattr(obj, "primary_ip4", None) or getattr(obj, "primary_ip6", None))


def _get_zabbix_hostid(obj):
    """Return the Zabbix host ID custom field value, or None.

    The custom field name is read from the config cache (populated at
    startup and updated when sync config is saved via the GUI).
    """
    try:
        return obj.cf.get(get_device_cf())
    except Exception:
        return None


def _tab_visible(obj, preferred_runner) -> bool:
    """Tab is visible when a preferred runner exists and the object has a primary IP."""
    return preferred_runner is not None and _has_primary_ip(obj)


def _build_zabbix_context(obj, object_type, preferred_runner):
    """Build the Zabbix tab context dict for a device or VM.

    Fetches maintenance and problems using the preferred runner, resolves
    the Zabbix base URL, enriches problems with deep-link URLs, and adds
    runner selector context.
    """
    hostid = _get_zabbix_hostid(obj)
    sync_url = reverse("plugins:netbox_zabbix_sync_plugin:schedule_synchronization")

    ctx = {
        "object": obj,
        "object_type": object_type,
        "tab_hidden": False,
        "zabbix_hostid": hostid,
        "sync_url": sync_url,
        "maintenance": None,
        "problems": None,
        "runners": SynchronizationRunner.objects.all(),
        "preferred_runner": preferred_runner,
        "zabbix_base_url": None,
    }

    zabbix_base_url = get_zabbix_base_url(preferred_runner)
    ctx["zabbix_base_url"] = zabbix_base_url

    if hostid:
        ctx["maintenance"] = get_host_maintenance(str(hostid), preferred_runner)
        problems_data = get_host_problems(str(hostid), preferred_runner)

        # Enrich each problem with a deep-link URL
        for p in problems_data.get("problems", []):
            if zabbix_base_url and p.get("triggerid") and p.get("eventid"):
                p["link"] = f"{zabbix_base_url}/tr_events.php?triggerid={p['triggerid']}&eventid={p['eventid']}"
            else:
                p["link"] = None

        ctx["problems"] = problems_data

    return ctx


@register_model_view(Device, name="zabbix", path="zabbix")
class DeviceZabbixTabView(generic.ObjectView):
    """Zabbix tab on Device detail page."""

    queryset = Device.objects.all()
    tab = ViewTab(label="Zabbix", hide_if_empty=False)

    def get(self, request, pk):
        device = get_object_or_404(Device, pk=pk)
        preferred_runner = SynchronizationRunner.get_preferred()

        if not _tab_visible(device, preferred_runner):
            return render(
                request,
                "netbox_zabbix_sync_plugin/zabbix_tab.html",
                {
                    "object": device,
                    "tab": self.tab,
                    "tab_hidden": True,
                    "tab_hidden_reason": (
                        "No runner is configured."
                        if preferred_runner is None
                        else "This device has no primary IP address."
                    ),
                },
            )

        ctx = _build_zabbix_context(device, "device", preferred_runner)
        ctx["tab"] = self.tab
        return render(request, "netbox_zabbix_sync_plugin/zabbix_tab.html", ctx)


@register_model_view(VirtualMachine, name="zabbix", path="zabbix")
class VMZabbixTabView(generic.ObjectView):
    """Zabbix tab on VirtualMachine detail page."""

    queryset = VirtualMachine.objects.all()
    tab = ViewTab(label="Zabbix", hide_if_empty=False)

    def get(self, request, pk):
        vm = get_object_or_404(VirtualMachine, pk=pk)
        preferred_runner = SynchronizationRunner.get_preferred()

        if not _tab_visible(vm, preferred_runner):
            return render(
                request,
                "netbox_zabbix_sync_plugin/zabbix_tab.html",
                {
                    "object": vm,
                    "tab": self.tab,
                    "tab_hidden": True,
                    "tab_hidden_reason": (
                        "No runner is configured."
                        if preferred_runner is None
                        else "This virtual machine has no primary IP address."
                    ),
                },
            )

        ctx = _build_zabbix_context(vm, "vm", preferred_runner)
        ctx["tab"] = self.tab
        return render(request, "netbox_zabbix_sync_plugin/zabbix_tab.html", ctx)


class ZabbixTabFetchView(View):
    """AJAX endpoint: fetch Zabbix data for a specific runner + hostid."""

    def get(self, request):
        runner_pk = request.GET.get("runner_pk")
        hostid = request.GET.get("hostid")

        if not runner_pk or not hostid:
            return JsonResponse({"error": "Missing runner_pk or hostid"}, status=400)

        try:
            runner = SynchronizationRunner.objects.get(pk=runner_pk)
        except SynchronizationRunner.DoesNotExist:
            return JsonResponse({"error": "Runner not found"}, status=404)

        maintenance = get_host_maintenance(str(hostid), runner)
        problems_data = get_host_problems(str(hostid), runner)

        # Resolve base URL for deep links
        base_url = get_zabbix_base_url(runner)
        for p in problems_data.get("problems", []):
            if base_url and p.get("triggerid") and p.get("eventid"):
                p["link"] = f"{base_url}/tr_events.php?triggerid={p['triggerid']}&eventid={p['eventid']}"
            else:
                p["link"] = None
            # Convert datetime to ISO string for JSON serialization
            if p.get("timestamp"):
                p["timestamp"] = p["timestamp"].isoformat()

        # Convert maintenance_until datetime to ISO string
        if maintenance.get("maintenance_until"):
            maintenance["maintenance_until"] = maintenance["maintenance_until"].isoformat()

        return JsonResponse(
            {
                "runner_name": runner.name,
                "zabbix_base_url": base_url,
                "maintenance": maintenance,
                "problems": problems_data.get("problems", []),
                "problems_error": problems_data.get("error"),
            }
        )
