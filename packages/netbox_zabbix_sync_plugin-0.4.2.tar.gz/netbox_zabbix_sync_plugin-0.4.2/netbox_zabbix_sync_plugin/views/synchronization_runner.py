"""
Views for SynchronizationRunner model.

For more information on NetBox views, see:
https://docs.netbox.dev/en/stable/plugins/development/views/

For generic view classes, see:
https://docs.netbox.dev/en/stable/development/views/
"""

from netbox.views import generic

from .. import filtersets, forms, models, tables
from ..models.synchronization_runner import RunnerMode


class SynchronizationRunnerView(generic.ObjectView):
    """Detail view for a single SynchronizationRunner object."""

    queryset = models.SynchronizationRunner.objects.all()

    def get_extra_context(self, request, instance):
        from core.choices import JobIntervalChoices, JobStatusChoices

        from ..jobs import SyncJob

        job = SyncJob.get_jobs(instance=instance).filter(status__in=JobStatusChoices.ENQUEUED_STATE_CHOICES).first()
        interval_labels = dict(JobIntervalChoices.CHOICES)

        # Check if a local-mode runner needs setup (missing ConnectConfig/SyncConfig)
        needs_local_setup = False
        if instance.mode == RunnerMode.LOCAL:
            from ..models.connect_config import ConnectConfig
            from ..models.sync_config import SyncConfig

            has_connect_config = ConnectConfig.objects.filter(runner=instance).exists()
            has_sync_config = SyncConfig.objects.filter(runner=instance).exists()

            # Auto-create missing configs so manually created runners aren't blocked
            if not has_connect_config:
                ConnectConfig.objects.create(runner=instance)
                has_connect_config = True
            if not has_sync_config:
                SyncConfig.objects.create(runner=instance)
                has_sync_config = True

            # Check if the connect config has been filled in (netbox_url is the minimum)
            cc = ConnectConfig.objects.get(runner=instance)
            if not cc.netbox_url:
                needs_local_setup = True

        return {
            "scheduled_job": job,
            "schedule_interval_label": interval_labels.get(job.interval) if job and job.interval else None,
            "needs_local_setup": needs_local_setup,
            "latest_sync_log": instance.sync_logs.first() if instance.mode == RunnerMode.LOCAL else None,
        }


class SynchronizationRunnerListView(generic.ObjectListView):
    """List view for SynchronizationRunner objects."""

    queryset = models.SynchronizationRunner.objects.all()
    table = tables.SynchronizationRunnerTable
    filterset = filtersets.SynchronizationRunnerFilterSet
    filterset_form = forms.SynchronizationRunnerFilterForm


class SynchronizationRunnerEditView(generic.ObjectEditView):
    """Create/Edit view for SynchronizationRunner objects."""

    queryset = models.SynchronizationRunner.objects.all()
    form = forms.SynchronizationRunnerForm
    template_name = "netbox_zabbix_sync_plugin/synchronizationrunner_edit.html"


class SynchronizationRunnerDeleteView(generic.ObjectDeleteView):
    """Delete view for a single SynchronizationRunner object."""

    queryset = models.SynchronizationRunner.objects.all()


class SynchronizationRunnerBulkImportView(generic.BulkImportView):
    """Bulk import view for SynchronizationRunner objects."""

    queryset = models.SynchronizationRunner.objects.all()
    model_form = forms.SynchronizationRunnerImportForm


class SynchronizationRunnerBulkEditView(generic.BulkEditView):
    """Bulk edit view for SynchronizationRunner objects."""

    queryset = models.SynchronizationRunner.objects.all()
    filterset = filtersets.SynchronizationRunnerFilterSet
    table = tables.SynchronizationRunnerTable
    form = forms.SynchronizationRunnerBulkEditForm


class SynchronizationRunnerBulkDeleteView(generic.BulkDeleteView):
    """Bulk delete view for SynchronizationRunner objects."""

    queryset = models.SynchronizationRunner.objects.all()
    filterset = filtersets.SynchronizationRunnerFilterSet
    table = tables.SynchronizationRunnerTable
