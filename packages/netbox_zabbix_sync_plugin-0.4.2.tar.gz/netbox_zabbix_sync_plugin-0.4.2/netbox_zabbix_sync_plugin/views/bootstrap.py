"""
Bootstrap helpers for the Setup Wizard.

Creates custom fields, example config contexts, custom links, and optionally a sync schedule.
Custom field names are read from the runner's sync config (device_cf, template_cf).
"""

import logging

from ..services import get_backend

logger = logging.getLogger(__name__)


def _get_custom_field_defs_from_runner(runner):
    """Fetch sync config from the runner's backend and build custom field definitions."""
    backend = get_backend(runner)
    config = backend.get_sync_config()

    device_cf = config.get("device_cf", "zabbix_hostid")
    template_cf = config.get("template_cf", "zabbix_template")

    return [
        {
            "name": device_cf,
            "label": device_cf.replace("_", " ").title(),
            "type": "integer",
            "content_types": ["dcim.device", "virtualization.virtualmachine"],
            "description": "Zabbix host ID (from sync config key 'device_cf')",
        },
        {
            "name": template_cf,
            "label": template_cf.replace("_", " ").title(),
            "type": "text",
            "content_types": ["dcim.devicetype"],
            "description": "Zabbix template name (from sync config key 'template_cf')",
        },
    ]


# Example config context definitions — based on the netbox-zabbix-sync wiki:
# https://github.com/TheNetworkGuy/netbox-zabbix-sync/wiki/Sync-Behavior
CONFIG_CONTEXTS = [
    {
        "name": "Zabbix Agent Interface Example",
        "description": "Example config context for Zabbix agent interface",
        "data": {
            "zabbix": {
                "interface_port": 10050,
                "interface_type": 1,
            }
        },
    },
    {
        "name": "Zabbix SNMPv2 Example",
        "description": "Example config context for SNMPv2 monitoring",
        "data": {
            "zabbix": {
                "interface_port": 161,
                "interface_type": 2,
                "snmp": {
                    "bulk": 1,
                    "community": "{$SNMP_COMMUNITY}",
                    "version": 2,
                },
            }
        },
    },
    {
        "name": "Zabbix SNMPv3 Example",
        "description": "Example config context for SNMPv3 monitoring (uses Zabbix usermacro for auth passphrase)",
        "data": {
            "zabbix": {
                "interface_port": 1610,
                "interface_type": 2,
                "snmp": {
                    "authpassphrase": "{$SNMPV3_AUTH}",
                    "bulk": 1,
                    "securitylevel": 1,
                    "securityname": "MySecurityName",
                    "version": 3,
                },
            }
        },
    },
    {
        "name": "Zabbix Template Assignment Example",
        "description": "Example config context for assigning multiple Zabbix templates",
        "data": {
            "zabbix": {
                "templates": [
                    "Template OS Linux by Zabbix agent",
                    "Template App MySQL by Zabbix agent",
                ]
            }
        },
    },
    {
        "name": "Zabbix Tags and Usermacros Example",
        "description": "Example config context for host tags and usermacros",
        "data": {
            "zabbix": {
                "tags": [
                    {"environment": "production"},
                    {"location": "datacenter-01"},
                ],
                "usermacros": {
                    "{$SNMP_COMMUNITY}": "public",
                    "{$SECRET_MACRO}": {"type": "secret", "value": "SuperSecret"},
                },
            }
        },
    },
    {
        "name": "Zabbix Proxy Example",
        "description": "Example config context for assigning a Zabbix proxy",
        "data": {"zabbix": {"proxy": "yourawesomeproxy.local"}},
    },
]


def _create_custom_fields(custom_fields):
    """Create custom fields, skipping any that already exist. Returns (created, skipped) lists."""
    from django.contrib.contenttypes.models import ContentType
    from extras.models import CustomField

    created = []
    skipped = []

    cf_type_map = {
        "integer": "integer",
        "text": "text",
    }

    for cf_def in custom_fields:
        if CustomField.objects.filter(name=cf_def["name"]).exists():
            skipped.append(cf_def["name"])
            continue

        cf = CustomField.objects.create(
            name=cf_def["name"],
            label=cf_def["label"],
            type=cf_type_map[cf_def["type"]],
            description=cf_def["description"],
        )
        for ct_label in cf_def["content_types"]:
            app_label, model = ct_label.split(".")
            ct = ContentType.objects.get(app_label=app_label, model=model)
            cf.object_types.add(ct)

        created.append(cf_def["name"])

    return created, skipped


def _create_config_contexts():
    """Create example config contexts, skipping any that already exist. Returns (created, skipped) lists."""
    from extras.models import ConfigContext

    created = []
    skipped = []

    for ctx_def in CONFIG_CONTEXTS:
        if ConfigContext.objects.filter(name=ctx_def["name"]).exists():
            skipped.append(ctx_def["name"])
            continue

        ConfigContext.objects.create(
            name=ctx_def["name"],
            description=ctx_def["description"],
            data=ctx_def["data"],
            is_active=False,
        )
        created.append(ctx_def["name"])

    return created, skipped


def _get_custom_link_defs(zabbix_base_url, device_cf):
    """Build custom link definitions using the Zabbix base URL and device custom field name.

    Links are only rendered when the object has a populated zabbix_hostid custom field,
    using Jinja2 conditional logic in the link text.

    Reference: https://github.com/TheNetworkGuy/netbox-zabbix-sync/wiki/Netbox-preperations#custom-links
    """
    return [
        {
            "name": "Zabbix Latest Data",
            "link_text": f'{{% if object.cf["{device_cf}"] %}}Latest Data{{% endif %}}',
            "link_url": f'{zabbix_base_url}/zabbix.php?action=latest.view&hostids[]={{{{ object.cf["{device_cf}"] }}}}',
            "group_name": "Zabbix",
            "button_class": "Teal",
            "new_window": True,
            "weight": 100,
            "content_types": ["dcim.device", "virtualization.virtualmachine"],
        },
        {
            "name": "Zabbix Problems",
            "link_text": f'{{% if object.cf["{device_cf}"] %}}Problems{{% endif %}}',
            "link_url": f'{zabbix_base_url}/zabbix.php?action=problem.view&filter_set=1&hostids%5B0%5D={{{{ object.cf["{device_cf}"] }}}}',
            "group_name": "Zabbix",
            "button_class": "Teal",
            "new_window": True,
            "weight": 200,
            "content_types": ["dcim.device", "virtualization.virtualmachine"],
        },
    ]


def _create_custom_links(zabbix_base_url, device_cf):
    """Create Zabbix custom links, skipping any that already exist. Returns (created, skipped) lists."""
    from django.contrib.contenttypes.models import ContentType
    from extras.models import CustomLink

    link_defs = _get_custom_link_defs(zabbix_base_url, device_cf)
    created = []
    skipped = []

    for link_def in link_defs:
        if CustomLink.objects.filter(name=link_def["name"]).exists():
            skipped.append(link_def["name"])
            continue

        cl = CustomLink.objects.create(
            name=link_def["name"],
            link_text=link_def["link_text"],
            link_url=link_def["link_url"],
            group_name=link_def["group_name"],
            button_class=link_def["button_class"],
            new_window=link_def["new_window"],
            weight=link_def["weight"],
            enabled=True,
        )
        for ct_label in link_def["content_types"]:
            app_label, model = ct_label.split(".")
            ct = ContentType.objects.get(app_label=app_label, model=model)
            cl.object_types.add(ct)

        created.append(link_def["name"])

    return created, skipped
