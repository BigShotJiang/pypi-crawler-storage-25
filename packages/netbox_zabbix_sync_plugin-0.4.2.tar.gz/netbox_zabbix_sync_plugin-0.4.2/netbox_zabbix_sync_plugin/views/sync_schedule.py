"""
Views for managing the sync schedule on a runner.

Shows the current scheduled job (if any) and lets users create, update,
or delete the recurring sync schedule.
"""

import logging

from core.choices import JobIntervalChoices, JobStatusChoices
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import View

from ..jobs import SyncJob
from ..models import SynchronizationRunner

logger = logging.getLogger(__name__)

# Human-readable labels for interval values (minutes)
INTERVAL_LABELS = dict(JobIntervalChoices.CHOICES)


def _get_scheduled_job(runner):
    """Return the active (pending/scheduled/running) SyncJob for this runner, or None."""
    return SyncJob.get_jobs(instance=runner).filter(status__in=JobStatusChoices.ENQUEUED_STATE_CHOICES).first()


class SyncScheduleView(View):
    """Manage the sync schedule for a runner."""

    template_name = "netbox_zabbix_sync_plugin/sync_schedule.html"

    def get(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        job = _get_scheduled_job(runner)

        return render(
            request,
            self.template_name,
            {
                "runner": runner,
                "job": job,
                "interval_label": INTERVAL_LABELS.get(job.interval) if job and job.interval else None,
                "interval_choices": JobIntervalChoices.CHOICES,
            },
        )

    def post(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        action = request.POST.get("action")

        if action == "delete":
            job = _get_scheduled_job(runner)
            if job:
                job.delete()
                messages.success(request, "Sync schedule removed.")
            else:
                messages.info(request, "No active schedule to remove.")
            return redirect("plugins:netbox_zabbix_sync_plugin:sync_schedule", pk=pk)

        if action == "save":
            interval_type = request.POST.get("interval_type", "preset")

            if interval_type == "custom":
                try:
                    interval = int(request.POST.get("custom_interval", 0))
                except (ValueError, TypeError):
                    messages.error(request, "Custom interval must be a whole number.")
                    return redirect("plugins:netbox_zabbix_sync_plugin:sync_schedule", pk=pk)
                if interval < 1:
                    messages.error(request, "Interval must be at least 1 minute.")
                    return redirect("plugins:netbox_zabbix_sync_plugin:sync_schedule", pk=pk)
            else:
                try:
                    interval = int(request.POST.get("interval", 0))
                except (ValueError, TypeError):
                    messages.error(request, "Invalid interval value.")
                    return redirect("plugins:netbox_zabbix_sync_plugin:sync_schedule", pk=pk)

                valid_intervals = [c[0] for c in JobIntervalChoices.CHOICES]
                if interval not in valid_intervals:
                    messages.error(request, "Invalid interval selected.")
                    return redirect("plugins:netbox_zabbix_sync_plugin:sync_schedule", pk=pk)

            # Delete existing schedule before creating new one
            existing = _get_scheduled_job(runner)
            if existing:
                existing.delete()

            SyncJob.enqueue_once(instance=runner, interval=interval)
            label = INTERVAL_LABELS.get(interval, f"{interval} minutes")
            messages.success(request, f"Sync schedule set to {label}.")
            return redirect("plugins:netbox_zabbix_sync_plugin:sync_schedule", pk=pk)

        messages.error(request, "Unknown action.")
        return redirect("plugins:netbox_zabbix_sync_plugin:sync_schedule", pk=pk)
