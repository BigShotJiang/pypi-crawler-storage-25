"""
View for importing a config.py file into SyncConfig.

Standalone import page for local-mode runners. Parses the uploaded file via
ConfigImporter, saves the merged config to SyncConfig, and redirects to the
sync_config detail page with a success or error message.
"""

import logging

from django.contrib import messages
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import View

from ..forms.import_config import ImportConfigForm
from ..models import SynchronizationRunner
from ..models.sync_config import SyncConfig
from ..models.synchronization_runner import RunnerMode
from ..services.config_importer import ConfigImporter

logger = logging.getLogger(__name__)


class ImportConfigView(View):
    """Import a config.py file and save the merged config to SyncConfig."""

    template_name = "netbox_zabbix_sync_plugin/import_config.html"

    def _get_local_runner(self, pk):
        """Return the runner if it exists and is local-mode, else raise Http404."""
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        if runner.mode != RunnerMode.LOCAL:
            raise Http404("Import is only available for local-mode runners.")
        return runner

    def get(self, request, pk):
        runner = self._get_local_runner(pk)
        form = ImportConfigForm()
        return render(request, self.template_name, {"form": form, "runner": runner})

    def post(self, request, pk):
        runner = self._get_local_runner(pk)
        form = ImportConfigForm(request.POST, request.FILES)

        if not form.is_valid():
            return render(request, self.template_name, {"form": form, "runner": runner})

        config_file = form.cleaned_data["config_file"]
        source = config_file.read().decode("utf-8", errors="replace")

        importer = ConfigImporter()
        result = importer.import_config(source)

        if result.error:
            messages.error(request, f"Import failed: {result.error}")
            return render(request, self.template_name, {"form": form, "runner": runner})

        # Save merged config to SyncConfig (create if it doesn't exist yet)
        sync_config, _ = SyncConfig.objects.get_or_create(runner=runner)
        sync_config.config = result.merged_config
        sync_config.save()

        n = len(result.recognized_keys)
        messages.success(
            request,
            f"Successfully imported {n} key{'s' if n != 1 else ''} from {config_file.name}.",
        )
        return redirect("plugins:netbox_zabbix_sync_plugin:sync_config", pk=pk)
