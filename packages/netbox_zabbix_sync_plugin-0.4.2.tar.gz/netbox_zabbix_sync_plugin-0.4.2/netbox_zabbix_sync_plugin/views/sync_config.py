"""
Views for Sync Config management.

Display, edit, and delete sync config keys stored on the webserver.
"""

import logging

from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import View

from ..forms.setup_wizard import SYNC_CONFIG_CATEGORIES
from ..forms.sync_config import SyncConfigEditForm
from ..models import SynchronizationRunner
from ..services import WebserverError, get_backend

logger = logging.getLogger(__name__)


class SyncConfigView(View):
    """Display sync config grouped by category."""

    template_name = "netbox_zabbix_sync_plugin/sync_config.html"

    def get(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)

        try:
            backend = get_backend(runner)
            config = backend.get_sync_config()
        except RuntimeError as e:
            messages.error(request, str(e))
            return redirect(runner.get_absolute_url())
        except WebserverError as e:
            messages.error(request, e.message)
            return redirect(runner.get_absolute_url())
        except Exception:
            logger.exception("Unexpected error fetching sync config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return redirect(runner.get_absolute_url())

        # Organize config by category for template rendering
        categorized = {}
        for category, fields in SYNC_CONFIG_CATEGORIES.items():
            items = []
            for field_name in fields:
                if field_name in config:
                    items.append({"name": field_name, "value": config[field_name]})
            if items:
                categorized[category] = items

        return render(
            request,
            self.template_name,
            {"runner": runner, "categorized": categorized},
        )


class SyncConfigEditView(View):
    """Edit sync config and send PATCH with only changed fields."""

    template_name = "netbox_zabbix_sync_plugin/sync_config_edit.html"

    def _get_current_config(self, runner):
        backend = get_backend(runner)
        return backend.get_sync_config()

    def get(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)

        try:
            config = self._get_current_config(runner)
        except RuntimeError as e:
            messages.error(request, str(e))
            return redirect(runner.get_absolute_url())
        except WebserverError as e:
            messages.error(request, e.message)
            return redirect(runner.get_absolute_url())
        except Exception:
            logger.exception("Unexpected error fetching sync config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return redirect(runner.get_absolute_url())

        form = SyncConfigEditForm()
        form.populate_from_config(config)
        return render(
            request,
            self.template_name,
            {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
        )

    def post(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        form = SyncConfigEditForm(request.POST)

        if not form.is_valid():
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )

        try:
            original = self._get_current_config(runner)
        except RuntimeError as e:
            messages.error(request, str(e))
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )
        except WebserverError as e:
            messages.error(request, e.message)
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )
        except Exception:
            logger.exception("Unexpected error fetching sync config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )

        payload = form.get_patch_payload(original)
        if not payload:
            messages.info(request, "No changes detected.")
            return redirect("plugins:netbox_zabbix_sync_plugin:sync_config", pk=pk)

        backend = get_backend(runner)
        try:
            backend.patch_sync_config(payload)
        except RuntimeError as e:
            messages.error(request, str(e))
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )
        except WebserverError as e:
            messages.error(request, e.message)
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )
        except Exception:
            logger.exception("Unexpected error patching sync config for runner %s", pk)
            messages.error(request, "An unexpected error occurred.")
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )

        # Update cached device_cf if it was changed
        if "device_cf" in payload:
            from ..services.config_cache import set_device_cf

            set_device_cf(str(payload["device_cf"]))

        messages.success(request, "Sync configuration updated.")
        return redirect("plugins:netbox_zabbix_sync_plugin:sync_config", pk=pk)


class SyncConfigDeleteKeyView(View):
    """Delete a single sync config key."""

    def post(self, request, pk, key):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)

        try:
            backend = get_backend(runner)
            backend.delete_sync_config_key(key)
        except RuntimeError as e:
            messages.error(request, str(e))
        except WebserverError as e:
            messages.error(request, e.message)
        except Exception:
            logger.exception("Unexpected error deleting sync config key %s for runner %s", key, pk)
            messages.error(request, "An unexpected error occurred.")
        else:
            messages.success(request, f"Sync config key '{key}' deleted.")

        return redirect("plugins:netbox_zabbix_sync_plugin:sync_config", pk=pk)
