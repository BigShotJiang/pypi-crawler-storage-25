"""
SynchronizationRunner model for NetBox Zabbix Sync Plugin.

For more information on NetBox models, see:
https://docs.netbox.dev/en/stable/plugins/development/models/

For NetBox model features (tags, custom fields, change logging, etc.), see:
https://docs.netbox.dev/en/stable/development/models/#netbox-model-features
"""

from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.urls import reverse
from netbox.models import NetBoxModel
from netbox.models.features import JobsMixin

from ..fields import EncryptedCharField


class RunnerMode(models.TextChoices):
    LOCAL = "local", "Local"
    REMOTE = "remote", "Remote"


class SynchronizationRunner(JobsMixin, NetBoxModel):
    """
    Model for storing synchronization runner configurations.

    This model represents a runner service that can execute synchronization tasks
    between NetBox and external monitoring systems like Zabbix. Each runner has
    authentication credentials. Runners are device-independent — they may run
    anywhere (e.g. in the cloud).
    """

    name = models.CharField(max_length=100, unique=True, help_text="Unique name for this synchronization runner")
    description = models.CharField(max_length=200, blank=True, help_text="Optional description of the runner")
    url = models.URLField(
        max_length=200,
        blank=True,
        help_text="URL of the remote netbox-zabbix-sync webserver (remote mode only)",
    )
    token = EncryptedCharField(
        max_length=512,
        blank=True,
        help_text="HMAC token for the remote webserver (remote mode only)",
    )
    mode = models.CharField(
        max_length=10,
        choices=RunnerMode.choices,
        default=RunnerMode.LOCAL,
        help_text="Backend mode: local (built-in sync) or remote (external webserver)",
    )
    preferred = models.BooleanField(
        default=False,
        help_text="Flag this runner as the preferred runner for the Zabbix tab.",
    )

    class Meta:
        app_label = "netbox_zabbix_sync_plugin"
        ordering = ("name",)
        verbose_name = "Synchronization Runner"
        verbose_name_plural = "Synchronization Runners"

    def __str__(self) -> str:
        return self.name

    def get_absolute_url(self) -> str:
        return reverse("plugins:netbox_zabbix_sync_plugin:synchronizationrunner", args=[self.pk])

    def clean(self):
        super().clean()
        if self.mode == RunnerMode.REMOTE:
            errors = {}
            if not self.url:
                errors["url"] = "URL is required when mode is remote."
            if not self.token:
                errors["token"] = "Token is required when mode is remote."
            if errors:
                raise ValidationError(errors)

    def serialize_object(self, exclude=None):
        data = super().serialize_object(exclude=exclude)
        if "token" in data and data["token"]:
            data["token"] = "********"
        return data

    def save(self, *args, **kwargs):
        with transaction.atomic():
            others = SynchronizationRunner.objects.select_for_update().exclude(pk=self.pk)
            if not others.exists():
                self.preferred = True
            elif self.preferred:
                others.update(preferred=False)
            super().save(*args, **kwargs)

    @classmethod
    def get_preferred(cls) -> "SynchronizationRunner | None":
        """Return the preferred runner, the sole runner, or None."""
        qs = cls.objects.all()
        count = qs.count()
        if count == 0:
            return None
        if count == 1:
            return qs.first()
        return qs.filter(preferred=True).first()


@receiver(post_delete, sender=SynchronizationRunner)
def promote_preferred_on_delete(sender, instance, **kwargs):
    """When the preferred runner is deleted, promote the lowest-PK remaining runner."""
    if instance.preferred:
        next_runner = SynchronizationRunner.objects.order_by("pk").first()
        if next_runner is not None:
            next_runner.preferred = True
            next_runner.save(update_fields=["preferred"])
