"""
SyncLog model — stores captured log output from local sync runs.
"""

from django.db import models


class SyncLogStatus(models.TextChoices):
    RUNNING = "running", "Running"
    COMPLETED = "completed", "Completed"
    FAILED = "failed", "Failed"


class SyncLog(models.Model):
    """Stores captured log output from a local sync run."""

    runner = models.ForeignKey(
        "netbox_zabbix_sync_plugin.SynchronizationRunner",
        on_delete=models.CASCADE,
        related_name="sync_logs",
    )
    status = models.CharField(
        max_length=10,
        choices=SyncLogStatus.choices,
        default=SyncLogStatus.RUNNING,
    )
    log_level = models.CharField(max_length=10, default="WARNING")
    output = models.TextField(blank=True, default="")
    started = models.DateTimeField(auto_now_add=True)
    finished = models.DateTimeField(null=True, blank=True)

    class Meta:
        app_label = "netbox_zabbix_sync_plugin"
        ordering = ("-started",)
        verbose_name = "Sync Log"
        verbose_name_plural = "Sync Logs"

    def __str__(self):
        return f"SyncLog {self.pk} ({self.runner.name} — {self.status})"
