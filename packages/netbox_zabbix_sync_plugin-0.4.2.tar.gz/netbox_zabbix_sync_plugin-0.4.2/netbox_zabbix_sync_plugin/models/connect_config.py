"""
ConnectConfig model for NetBox Zabbix Sync Plugin.

Stores NetBox and Zabbix connection credentials locally for local-mode runners.
Sensitive fields are encrypted at rest using Fernet (AES) with a key derived
from Django's SECRET_KEY.
"""

from django.db import models

from ..fields import EncryptedCharField
from ..services.masking import SENSITIVE_FIELDS


class ConnectConfig(models.Model):
    """
    Stores connection credentials for a local-mode SynchronizationRunner.

    One-to-one relationship with SynchronizationRunner. When the runner is
    deleted, this record is cascade-deleted. Deleting this record does NOT
    delete the runner.
    """

    runner = models.OneToOneField(
        "netbox_zabbix_sync_plugin.SynchronizationRunner",
        on_delete=models.CASCADE,
        related_name="connect_config",
    )
    netbox_url = models.CharField(max_length=200, blank=True)
    netbox_token = EncryptedCharField(max_length=512, blank=True)
    zabbix_url = models.CharField(max_length=200, blank=True)
    zabbix_user = models.CharField(max_length=200, blank=True)
    zabbix_password = EncryptedCharField(max_length=512, blank=True)
    zabbix_token = EncryptedCharField(max_length=512, blank=True)

    class Meta:
        app_label = "netbox_zabbix_sync_plugin"
        verbose_name = "Connect Configuration"

    def __str__(self) -> str:
        return f"ConnectConfig for {self.runner}"

    def serialize_object(self, exclude=None):
        """Serialize the model, masking sensitive fields."""
        data = {}
        for field in self._meta.get_fields():
            if not hasattr(field, "attname"):
                continue
            name = field.attname
            if exclude and name in exclude:
                continue
            value = getattr(self, name)
            if field.name in SENSITIVE_FIELDS and value:
                data[name] = "********"
            else:
                data[name] = value
        return data
