# NetBox Zabbix Sync Plugin

NetBox companion plugin for the netbox-zabbix-sync python project

- Free software: MIT
- Documentation: https://thenetworkguy.github.io/netbox-zabbix-sync-plugin/

## Features

The features the plugin provides should be listed here. For example:

- Manage netbox_zabbix_sync resources through NetBox UI
- Track and organize netbox_zabbix_sync data with custom fields and tags
- REST API endpoints for programmatic access
- GraphQL support for flexible data queries
- Full change logging and journaling support
- Integration with NetBox's permission system
- Global search integration for finding netbox_zabbix_sync objects
- Comprehensive filtering and table views

## Compatibility

This plugin requires **NetBox 4.5** or later.

| NetBox Version | Plugin Version |
| -------------- | -------------- |
| 4.5+           | 0.4.2          |

For more detailed compatibility information, see
[COMPATIBILITY.md](COMPATIBILITY.md).

## Dependencies

This plugin requires:

- NetBox 4.5 or later
- Python 3.12 or later
- zabbix_utils

No additional Python packages are required beyond NetBox's core dependencies.

## REST API

This plugin provides a REST API endpoint for managing netbox_zabbix_sync
resources:

- `/api/plugins/netbox-zabbix-sync/netbox-zabbix-syncs/` - List and create
  Netbox_Zabbix_Sync objects

## GraphQL

This plugin provides GraphQL support for querying netbox_zabbix_sync resources
through NetBox's GraphQL API.

## Installing

For adding to a NetBox Docker setup see
[the general instructions for using netbox-docker with plugins](https://github.com/netbox-community/netbox-docker/wiki/Using-Netbox-Plugins).

While this is still in development you can install this with pip:

```bash
pip install git+https://github.com/thenetworkguy/netbox-zabbix-sync-plugin
```

or by adding to your `local_requirements.txt` or `plugin_requirements.txt`
(netbox-docker):

```bash
git+https://github.com/thenetworkguy/netbox-zabbix-sync-plugin
```

Enable the plugin in `/opt/netbox/netbox/netbox/configuration.py`, or if you use
netbox-docker, your `/configuration/plugins.py` file :

```python
PLUGINS = [
    'netbox_zabbix_sync_plugin'
]

PLUGINS_CONFIG = {
    "netbox_zabbix_sync_plugin": {},
}
```

## Configuration

This plugin does not require any additional configuration by default. Optional
configuration parameters can be added to `PLUGINS_CONFIG` in your NetBox
configuration file as needed.

## Usage

For detailed usage instructions, please refer to the
[documentation](https://thenetworkguy.github.io/netbox-zabbix-sync-plugin/).

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for
guidelines.

### Reporting Bugs

Please report bugs by opening an issue on our
[GitHub Issues](https://github.com/thenetworkguy/netbox-zabbix-sync-plugin/issues)
page. When reporting bugs, please include:

- NetBox version
- Plugin version
- Python version
- Steps to reproduce
- Expected behavior
- Actual behavior

### Feature Requests

Feature requests can be submitted as
[GitHub Issues](https://github.com/thenetworkguy/netbox-zabbix-sync-plugin/issues)
with the "enhancement" label.

## Support

- **Documentation**: https://thenetworkguy.github.io/netbox-zabbix-sync-plugin/
- **Issues**: https://github.com/thenetworkguy/netbox-zabbix-sync-plugin/issues
- **Discussions**:
  https://github.com/thenetworkguy/netbox-zabbix-sync-plugin/discussions
- **NetBox Community Slack**: [netdev-community.slack.com](https://netdev.chat/)

## Credits

Based on the NetBox plugin tutorial:

- [demo repository](https://github.com/netbox-community/netbox-plugin-demo)
- [tutorial](https://github.com/netbox-community/netbox-plugin-tutorial)

This package was created with
[Cookiecutter](https://github.com/audreyr/cookiecutter) and the
[`netbox-community/cookiecutter-netbox-plugin`](https://github.com/netbox-community/cookiecutter-netbox-plugin)
project template.
