"""Race results for a specific season and round."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client
from basef1.domain.tables import RaceTable


def main() -> None:
    with BaseF1Client() as client:
        envelope = client.query().season(2024).round(1).get_results(limit=10)
        _summary.print_pagination(envelope, "2024 round 1 results")
        assert isinstance(envelope.data, RaceTable)
        races = envelope.data.races
        if not races:
            return
        race = races[0]
        for row in race.results[:5]:
            code = row.driver.code if row.driver else None
            print(f"  P{row.position} #{row.number} {code}")


if __name__ == "__main__":
    main()
