"""Finishing status id catalogue (``get_statuses()`` terminal)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client
from basef1.domain.tables import StatusTable


def main() -> None:
    with BaseF1Client() as client:
        envelope = client.get_statuses(limit=10)
        _summary.print_pagination(envelope, "Status catalogue")
        assert isinstance(envelope.data, StatusTable)
        for row in envelope.data.statuses[:5]:
            print(f"  id={row.status_id} — {row.status}")


if __name__ == "__main__":
    main()
