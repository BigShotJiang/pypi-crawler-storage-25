"""Shared printing helpers for example scripts (import as ``_summary``)."""

from __future__ import annotations

from basef1.domain.parse import ParsedApiResponse
from basef1.models import ApiResponse


def print_pagination(resp: ParsedApiResponse | ApiResponse, title: str) -> None:
    pg = resp.pagination
    print(f"{title} — total={pg.total_int!r} limit={pg.limit} offset={pg.offset}")
