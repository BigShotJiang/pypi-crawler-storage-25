"""Global championship seasons (shorthand on the client)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client
from basef1.domain.tables import SeasonTable


def main() -> None:
    with BaseF1Client() as client:
        envelope = client.get_seasons(limit=5)
        _summary.print_pagination(envelope, "Seasons")
        assert isinstance(envelope.data, SeasonTable)
        seasons = envelope.data.seasons
        if seasons:
            print("First season:", seasons[0].season)


if __name__ == "__main__":
    main()
