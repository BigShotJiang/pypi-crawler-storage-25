"""Races for a single season."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client
from basef1.domain.tables import RaceTable


def main() -> None:
    with BaseF1Client() as client:
        envelope = client.query().season(2025).get_races(limit=30)
        _summary.print_pagination(envelope, "2025 races")
        assert isinstance(envelope.data, RaceTable)
        for r in envelope.data.races:
            print(f"  Round {r.round}: {r.race_name} ({r.date})")


if __name__ == "__main__":
    main()
