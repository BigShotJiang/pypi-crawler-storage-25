"""HTTP response caches for idempotent GET responses."""

from __future__ import annotations

import copy
import json
import sqlite3
import threading
import time
from collections import OrderedDict
from collections.abc import Callable
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable

CacheBackend = Literal["memory", "sqlite"]


def cache_key_for_request(method: str, url: str, params: dict[str, Any] | None) -> str:
    """Stable cache key for HTTP ``method``, ``url``, and query ``params``."""
    m = method.upper()
    items = sorted((params or {}).items())
    if not items:
        return f"{m} {url}"
    qs = "&".join(f"{k}={v}" for k, v in items)
    return f"{m} {url}?{qs}"


def default_sqlite_cache_path() -> Path:
    """Default on-disk cache file: ``~/.cache/basef1/http_cache.sqlite``."""
    return Path.home() / ".cache" / "basef1" / "http_cache.sqlite"


@runtime_checkable
class ResponseCache(Protocol):
    """Minimal cache interface used by :class:`basef1.client.BaseF1Client`."""

    def get(self, key: str) -> dict[str, Any] | None: ...

    def set(self, key: str, data: dict[str, Any]) -> None: ...


class TTLCache:
    """
    Thread-safe in-memory LRU-ish cache: entries expire after ``ttl_seconds``;
    when full, the oldest inserted entry is evicted.
    """

    __slots__ = ("_clock", "_data", "_lock", "_max_entries", "_ttl")

    def __init__(
        self,
        max_entries: int,
        ttl_seconds: float,
        *,
        clock: Callable[[], float] | None = None,
    ) -> None:
        if max_entries < 1:
            raise ValueError("max_entries must be >= 1")
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be > 0")
        self._max_entries = max_entries
        self._ttl = ttl_seconds
        self._clock = clock or time.monotonic
        self._data: OrderedDict[str, tuple[float, dict[str, Any]]] = OrderedDict()
        self._lock = threading.RLock()

    def get(self, key: str) -> dict[str, Any] | None:
        now = self._clock()
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return None
            expires_at, data = entry
            if expires_at <= now:
                del self._data[key]
                return None
            self._data.move_to_end(key)
            return copy.deepcopy(data)

    def set(self, key: str, data: dict[str, Any]) -> None:
        now = self._clock()
        expires_at = now + self._ttl
        stored = copy.deepcopy(data)
        with self._lock:
            self._data[key] = (expires_at, stored)
            self._data.move_to_end(key)
            while len(self._data) > self._max_entries:
                self._data.popitem(last=False)


class SQLiteCache:
    """
    Thread-safe on-disk TTL cache backed by SQLite.

    Entries expire after ``ttl_seconds``. The database file is created if missing.
    """

    __slots__ = ("_clock", "_conn", "_lock", "_path", "_ttl")

    def __init__(
        self,
        path: str | Path,
        ttl_seconds: float,
        *,
        clock: Callable[[], float] | None = None,
    ) -> None:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be > 0")
        self._path = Path(path)
        self._ttl = ttl_seconds
        self._clock = clock or time.monotonic
        self._lock = threading.RLock()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS cache_entries (
                cache_key TEXT PRIMARY KEY,
                body TEXT NOT NULL,
                expires_at REAL NOT NULL
            )
            """,
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_cache_expires ON cache_entries(expires_at)",
        )
        self._conn.commit()

    @property
    def path(self) -> Path:
        return self._path

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def get(self, key: str) -> dict[str, Any] | None:
        now = self._clock()
        with self._lock:
            row = self._conn.execute(
                "SELECT body, expires_at FROM cache_entries WHERE cache_key = ?",
                (key,),
            ).fetchone()
            if row is None:
                return None
            body, expires_at = row
            if expires_at <= now:
                self._conn.execute(
                    "DELETE FROM cache_entries WHERE cache_key = ?",
                    (key,),
                )
                self._conn.commit()
                return None
            data = json.loads(body)
            if not isinstance(data, dict):
                self._conn.execute(
                    "DELETE FROM cache_entries WHERE cache_key = ?",
                    (key,),
                )
                self._conn.commit()
                return None
            return copy.deepcopy(data)

    def set(self, key: str, data: dict[str, Any]) -> None:
        now = self._clock()
        expires_at = now + self._ttl
        stored = copy.deepcopy(data)
        body = json.dumps(stored, separators=(",", ":"), sort_keys=True)
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO cache_entries (cache_key, body, expires_at)
                VALUES (?, ?, ?)
                ON CONFLICT(cache_key) DO UPDATE SET
                    body = excluded.body,
                    expires_at = excluded.expires_at
                """,
                (key, body, expires_at),
            )
            self._conn.execute(
                "DELETE FROM cache_entries WHERE expires_at <= ?",
                (now,),
            )
            self._conn.commit()


def create_response_cache(
    *,
    backend: CacheBackend = "memory",
    path: str | Path | None = None,
    ttl_seconds: float,
    max_entries: int = 256,
) -> TTLCache | SQLiteCache:
    """Build a :class:`TTLCache` or :class:`SQLiteCache` for the given backend."""
    if backend == "memory":
        return TTLCache(max_entries=max_entries, ttl_seconds=ttl_seconds)
    db_path = Path(path) if path is not None else default_sqlite_cache_path()
    return SQLiteCache(path=db_path, ttl_seconds=ttl_seconds)
