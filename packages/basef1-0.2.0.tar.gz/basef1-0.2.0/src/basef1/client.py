"""HTTP client for the Jolpica F1 API."""

from __future__ import annotations

import sys
import threading
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, NamedTuple, TextIO

import httpx

if TYPE_CHECKING:
    from basef1.query import F1Query

from basef1.cache import (
    CacheBackend,
    ResponseCache,
    SQLiteCache,
    TTLCache,
    cache_key_for_request,
    create_response_cache,
)
from basef1.exceptions import JolpicaHTTPError
from basef1.models import ApiResponse

DEFAULT_BASE_URL = "https://api.jolpi.ca/ergast/f1"
DEFAULT_CACHE_TTL_SECONDS = 300.0


class RequestLogEntry(NamedTuple):
    """One logical client request (cache or network)."""

    method: str
    url: str
    params: tuple[tuple[str, Any], ...]
    source: Literal["cache", "network"]


class UsageSnapshot(NamedTuple):
    """Point-in-time usage counters and request log (newest last)."""

    logical_requests: int
    http_requests: int
    cache_hits: int
    caching_enabled: bool
    request_log: tuple[RequestLogEntry, ...]


def _validate_limit(limit: int | None) -> None:
    if limit is None:
        return
    if not isinstance(limit, int) or limit < 1 or limit > 100:
        raise ValueError("limit must be an integer between 1 and 100")


def _validate_offset(offset: int | None) -> None:
    if offset is None:
        return
    if not isinstance(offset, int) or offset < 0:
        raise ValueError("offset must be a non-negative integer")


class BaseF1Client:
    """
    Sync client for https://api.jolpi.ca/ergast/f1 (JSON).

    By default responses are cached in memory (``TTLCache``) to reduce duplicate
    GET traffic. Pass ``cache_backend="sqlite"`` for a persistent local SQLite
    cache, ``cache=False`` to disable caching, or pass ``cache=`` / ``cache_ttl=``
    to customize.

    Pass a custom ``httpx.Client`` for tests or advanced configuration.
    If ``client`` is omitted, an internal client is created and closed when
    this instance is used as a context manager.

    ``request_log_maxlen`` bounds the in-memory request log (``None`` = unlimited).
    """

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float | httpx.Timeout | None = 30.0,
        client: httpx.Client | None = None,
        cache: TTLCache | SQLiteCache | Literal[False] | None = None,
        cache_backend: CacheBackend = "memory",
        cache_path: str | Path | None = None,
        cache_ttl: float | None = None,
        cache_max_entries: int = 256,
        request_log_maxlen: int | None = 512,
    ) -> None:
        if cache is not None and cache is not False and cache_ttl is not None:
            raise ValueError("Pass either cache= or cache_ttl=, not both.")
        if cache is False and cache_ttl is not None:
            raise ValueError("cache=False cannot be combined with cache_ttl=.")
        if cache is False and cache_backend != "memory":
            raise ValueError("cache=False cannot be combined with cache_backend=.")
        if cache is not None and cache is not False and cache_backend != "memory":
            raise ValueError("Pass either cache= or cache_backend=, not both.")
        if cache_path is not None and cache_backend != "sqlite":
            raise ValueError("cache_path= requires cache_backend='sqlite'.")
        if request_log_maxlen is not None and request_log_maxlen < 1:
            raise ValueError("request_log_maxlen must be >= 1 or None for unlimited.")
        self._base_url = base_url.rstrip("/") + "/"
        self._owns_client = client is None
        self._client = client or httpx.Client(timeout=timeout)
        self._sqlite_cache: SQLiteCache | None = None
        if cache is False:
            self._cache: ResponseCache | None = None
        elif cache is not None:
            self._cache = cache
            if isinstance(cache, SQLiteCache):
                self._sqlite_cache = cache
        else:
            ttl = cache_ttl if cache_ttl is not None else DEFAULT_CACHE_TTL_SECONDS
            built = create_response_cache(
                backend=cache_backend,
                path=cache_path,
                ttl_seconds=ttl,
                max_entries=cache_max_entries,
            )
            self._cache = built
            if isinstance(built, SQLiteCache):
                self._sqlite_cache = built

        self._stats_lock = threading.Lock()
        self._stats_logical = 0
        self._stats_network = 0
        self._stats_cache_hits = 0
        if request_log_maxlen is None:
            self._request_log: deque[RequestLogEntry] = deque()
        else:
            self._request_log = deque(maxlen=request_log_maxlen)

    @property
    def base_url(self) -> str:
        return self._base_url.rstrip("/")

    @property
    def http_client(self) -> httpx.Client:
        return self._client

    def __enter__(self) -> BaseF1Client:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()
        if self._sqlite_cache is not None:
            self._sqlite_cache.close()
            self._sqlite_cache = None

    def query(self) -> F1Query:
        from basef1.query import F1Query as F1QueryBuilder

        return F1QueryBuilder(self, [])

    def get_seasons(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        return self.query().get_seasons(limit=limit, offset=offset)

    def get_statuses(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        return self.query().get_statuses(limit=limit, offset=offset)

    def usage_snapshot(self) -> UsageSnapshot:
        """Return current usage counters and the full in-memory request log."""
        with self._stats_lock:
            return UsageSnapshot(
                logical_requests=self._stats_logical,
                http_requests=self._stats_network,
                cache_hits=self._stats_cache_hits,
                caching_enabled=self._cache is not None,
                request_log=tuple(self._request_log),
            )

    def stats(self, *, file: TextIO | None = None) -> None:
        """Print a human-readable usage summary (logical vs HTTP vs cache)."""
        out = sys.stdout if file is None else file
        snap = self.usage_snapshot()
        lines = [
            "BaseF1Client usage",
            f"  logical requests:  {snap.logical_requests}",
            f"  HTTP GET requests: {snap.http_requests}",
            f"  cache hits:        {snap.cache_hits}",
            f"  caching enabled:   {snap.caching_enabled}",
        ]
        if snap.logical_requests:
            rate = 100.0 * snap.cache_hits / snap.logical_requests
            lines.append(f"  cache hit rate:    {rate:.1f}%")
        else:
            lines.append("  cache hit rate:    n/a")
        lines.append("  recent requests (oldest first, up to 10):")
        log = snap.request_log
        tail = log[-10:] if len(log) > 10 else log
        if not tail:
            lines.append("    (none)")
        else:
            for ent in tail:
                param_s = ", ".join(f"{k}={v!r}" for k, v in ent.params) if ent.params else ""
                suffix = f" ?{param_s}" if param_s else ""
                lines.append(f"    {ent.method} {ent.url}{suffix}  [{ent.source}]")
        print("\n".join(lines), file=out)

    def _request(
        self,
        path_segments: list[str],
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        _validate_limit(limit)
        _validate_offset(offset)
        base = self._base_url.rstrip("/")
        path = "/".join(s for s in path_segments if s).strip("/")
        if not path:
            raise ValueError("path_segments must not be empty")
        url = f"{base}/{path}.json"

        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        params_tuple = tuple(sorted(params.items()))
        cache_key = cache_key_for_request("GET", url, params)
        if self._cache is not None:
            cached = self._cache.get(cache_key)
            if cached is not None:
                with self._stats_lock:
                    self._stats_logical += 1
                    self._stats_cache_hits += 1
                    self._request_log.append(
                        RequestLogEntry("GET", url, params_tuple, "cache"),
                    )
                return ApiResponse(raw=cached)

        with self._stats_lock:
            self._stats_logical += 1
            self._stats_network += 1
            self._request_log.append(
                RequestLogEntry("GET", url, params_tuple, "network"),
            )

        try:
            response = self._client.get(url, params=params or None)
        except httpx.HTTPError as exc:
            raise JolpicaHTTPError(
                f"HTTP transport error: {exc}",
                status_code=-1,
                body=None,
            ) from exc

        if response.status_code >= 400:
            text = response.text[:500] if response.text else None
            raise JolpicaHTTPError(
                f"HTTP {response.status_code} for {url}",
                status_code=response.status_code,
                body=text,
            )

        try:
            data = response.json()
        except ValueError as exc:
            raise JolpicaHTTPError(
                "Response body is not valid JSON",
                status_code=response.status_code,
                body=response.text[:500] if response.text else None,
            ) from exc

        if not isinstance(data, dict):
            raise JolpicaHTTPError(
                "Top-level JSON value must be an object",
                status_code=response.status_code,
                body=None,
            )

        if self._cache is not None:
            self._cache.set(cache_key, data)

        return ApiResponse(raw=data)
