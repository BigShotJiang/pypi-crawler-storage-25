"""Race-centric domain parsing."""

from __future__ import annotations

from basef1.domain.race_graph import Race


def test_race_from_dict_parses_sprint_results() -> None:
    data = {
        "season": "2024",
        "round": "5",
        "SprintResults": [
            {
                "position": "1",
                "number": "1",
                "Driver": {"driverId": "max_verstappen", "code": "VER"},
            }
        ],
    }
    race = Race.from_dict(data)
    assert len(race.sprint_results) == 1
    assert race.sprint_results[0].position == "1"
    assert race.sprint_results[0].driver is not None
    assert race.sprint_results[0].driver.driver_id == "max_verstappen"


def test_race_from_dict_sprint_results_empty_when_missing() -> None:
    race = Race.from_dict({"season": "2024", "round": "1"})
    assert race.sprint_results == []
