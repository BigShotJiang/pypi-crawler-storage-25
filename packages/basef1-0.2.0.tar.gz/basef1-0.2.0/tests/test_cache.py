"""TTL cache behavior, HTTP call counting, and usage stats."""

from __future__ import annotations

import io

import httpx
import pytest

from basef1 import BaseF1Client, JolpicaHTTPError
from basef1.cache import SQLiteCache, TTLCache, cache_key_for_request
from basef1.domain.tables import SeasonTable


def test_cache_key_stable_order() -> None:
    a = cache_key_for_request("GET", "https://api.example/x.json", {"limit": 10, "offset": 0})
    b = cache_key_for_request("GET", "https://api.example/x.json", {"offset": 0, "limit": 10})
    assert a == b


def test_ttl_cache_expiry() -> None:
    clock = {"t": 0.0}

    def fake_mono() -> float:
        return clock["t"]

    cache = TTLCache(max_entries=10, ttl_seconds=60.0, clock=fake_mono)
    cache.set("k", {"MRData": {"a": 1}})
    assert cache.get("k") == {"MRData": {"a": 1}}
    clock["t"] = 61.0
    assert cache.get("k") is None


def test_ttl_cache_lru_eviction() -> None:
    clock = {"t": 0.0}

    def fake_mono() -> float:
        return clock["t"]

    cache = TTLCache(max_entries=2, ttl_seconds=100.0, clock=fake_mono)
    cache.set("a", {"x": 1})
    clock["t"] += 1
    cache.set("b", {"x": 2})
    clock["t"] += 1
    cache.set("c", {"x": 3})
    assert cache.get("a") is None
    assert cache.get("b") == {"x": 2}
    assert cache.get("c") == {"x": 3}


def test_ttl_cache_deepcopy_isolation() -> None:
    cache = TTLCache(max_entries=5, ttl_seconds=60.0)
    data = {"MRData": {"nested": {"v": 1}}}
    cache.set("k", data)
    out = cache.get("k")
    assert out is not None
    out["MRData"]["nested"]["v"] = 999
    out2 = cache.get("k")
    assert out2 is not None
    assert out2["MRData"]["nested"]["v"] == 1


def test_cached_client_single_http_call_for_duplicate_request() -> None:
    counts = {"n": 0}
    sample = {
        "MRData": {
            "xmlns": "",
            "series": "f1",
            "url": "http://example/seasons/",
            "limit": "30",
            "offset": "0",
            "total": "1",
            "SeasonTable": {"Seasons": [{"season": "2024"}]},
        }
    }

    def handler(request: httpx.Request) -> httpx.Response:
        counts["n"] += 1
        return httpx.Response(200, json=sample)

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache_ttl=300.0, cache_max_entries=32)
        r1 = client.get_seasons(limit=30, offset=0)
        r2 = client.get_seasons(limit=30, offset=0)

    assert counts["n"] == 1
    # Terminal methods return ParsedApiResponse (F1Query applies parse()).
    assert isinstance(r1.data, SeasonTable)
    assert r1.data.seasons[0].season == "2024"
    assert r1 == r2


def test_uncached_client_counts_two_calls() -> None:
    counts = {"n": 0}
    sample = {"MRData": {"SeasonTable": {"Seasons": []}}}

    def handler(request: httpx.Request) -> httpx.Response:
        counts["n"] += 1
        return httpx.Response(200, json=sample)

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        client.get_seasons()
        client.get_seasons()

    assert counts["n"] == 2


def test_client_rejects_cache_and_cache_ttl_together() -> None:
    with pytest.raises(ValueError, match="either"):
        BaseF1Client(cache=TTLCache(1, 1.0), cache_ttl=30.0)


def test_client_rejects_cache_false_with_cache_ttl() -> None:
    with pytest.raises(ValueError, match="cache=False"):
        BaseF1Client(cache=False, cache_ttl=60.0)


def test_usage_snapshot_cache_hit_after_network() -> None:
    sample = {
        "MRData": {
            "xmlns": "",
            "series": "f1",
            "url": "http://example/seasons/",
            "limit": "30",
            "offset": "0",
            "total": "1",
            "SeasonTable": {"Seasons": [{"season": "2024"}]},
        }
    }

    transport = httpx.MockTransport(lambda r: httpx.Response(200, json=sample))
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache_ttl=300.0, cache_max_entries=32)
        client.get_seasons(limit=30, offset=0)
        client.get_seasons(limit=30, offset=0)
        snap = client.usage_snapshot()

    assert snap.logical_requests == 2
    assert snap.http_requests == 1
    assert snap.cache_hits == 1
    assert snap.caching_enabled is True
    assert len(snap.request_log) == 2
    assert snap.request_log[0].source == "network"
    assert snap.request_log[1].source == "cache"


def test_usage_snapshot_uncached_all_network() -> None:
    sample = {"MRData": {"SeasonTable": {"Seasons": []}}}
    transport = httpx.MockTransport(lambda r: httpx.Response(200, json=sample))
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        client.get_seasons()
        client.get_seasons()
        snap = client.usage_snapshot()

    assert snap.logical_requests == 2
    assert snap.http_requests == 2
    assert snap.cache_hits == 0
    assert snap.caching_enabled is False
    assert all(e.source == "network" for e in snap.request_log)


def test_usage_snapshot_counts_network_on_http_error() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(500, text="nope"))
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache_ttl=300.0)
        with pytest.raises(JolpicaHTTPError):
            client.query().get_seasons()
        snap = client.usage_snapshot()

    assert snap.logical_requests == 1
    assert snap.http_requests == 1
    assert snap.cache_hits == 0


def test_usage_snapshot_counts_network_on_invalid_json() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200, text="not-json"))
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache_ttl=300.0)
        with pytest.raises(JolpicaHTTPError, match="JSON"):
            client.query().get_seasons()
        snap = client.usage_snapshot()

    assert snap.logical_requests == 1
    assert snap.http_requests == 1
    assert snap.cache_hits == 0


def test_stats_prints_to_stream() -> None:
    sample = {"MRData": {"SeasonTable": {"Seasons": []}}}
    transport = httpx.MockTransport(lambda r: httpx.Response(200, json=sample))
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        client.get_seasons()
        buf = io.StringIO()
        client.stats(file=buf)

    out = buf.getvalue()
    assert "logical requests" in out
    assert "HTTP GET requests" in out
    assert "cache hits" in out
    assert "[network]" in out


def test_client_rejects_invalid_request_log_maxlen() -> None:
    with pytest.raises(ValueError, match="request_log_maxlen"):
        BaseF1Client(request_log_maxlen=0)


def test_sqlite_cache_expiry(tmp_path) -> None:
    clock = {"t": 0.0}

    def fake_mono() -> float:
        return clock["t"]

    cache = SQLiteCache(
        tmp_path / "c.sqlite",
        ttl_seconds=60.0,
        clock=fake_mono,
    )
    try:
        cache.set("k", {"MRData": {"a": 1}})
        assert cache.get("k") == {"MRData": {"a": 1}}
        clock["t"] = 61.0
        assert cache.get("k") is None
    finally:
        cache.close()


def test_sqlite_cache_deepcopy_isolation(tmp_path) -> None:
    cache = SQLiteCache(tmp_path / "c.sqlite", ttl_seconds=60.0)
    try:
        data = {"MRData": {"nested": {"v": 1}}}
        cache.set("k", data)
        out = cache.get("k")
        assert out is not None
        out["MRData"]["nested"]["v"] = 999
        out2 = cache.get("k")
        assert out2 is not None
        assert out2["MRData"]["nested"]["v"] == 1
    finally:
        cache.close()


def test_sqlite_client_single_http_call_for_duplicate_request(tmp_path) -> None:
    counts = {"n": 0}
    sample = {
        "MRData": {
            "xmlns": "",
            "series": "f1",
            "url": "http://example/seasons/",
            "limit": "30",
            "offset": "0",
            "total": "1",
            "SeasonTable": {"Seasons": [{"season": "2024"}]},
        }
    }

    def handler(request: httpx.Request) -> httpx.Response:
        counts["n"] += 1
        return httpx.Response(200, json=sample)

    transport = httpx.MockTransport(handler)
    db = tmp_path / "http_cache.sqlite"
    with httpx.Client(transport=transport) as http_client:
        with BaseF1Client(
            client=http_client,
            cache_backend="sqlite",
            cache_path=db,
            cache_ttl=300.0,
        ) as client:
            client.get_seasons(limit=30, offset=0)
            client.get_seasons(limit=30, offset=0)

    assert counts["n"] == 1


def test_sqlite_cache_persists_across_clients(tmp_path) -> None:
    counts = {"n": 0}
    sample = {
        "MRData": {
            "xmlns": "",
            "series": "f1",
            "url": "http://example/seasons/",
            "limit": "30",
            "offset": "0",
            "total": "1",
            "SeasonTable": {"Seasons": [{"season": "2024"}]},
        }
    }

    def handler(request: httpx.Request) -> httpx.Response:
        counts["n"] += 1
        return httpx.Response(200, json=sample)

    transport = httpx.MockTransport(handler)
    db = tmp_path / "http_cache.sqlite"
    with httpx.Client(transport=transport) as http_client:
        with BaseF1Client(
            client=http_client,
            cache_backend="sqlite",
            cache_path=db,
            cache_ttl=300.0,
        ) as client:
            client.get_seasons(limit=30, offset=0)

    assert counts["n"] == 1

    with httpx.Client(transport=transport) as http_client:
        with BaseF1Client(
            client=http_client,
            cache_backend="sqlite",
            cache_path=db,
            cache_ttl=300.0,
        ) as client:
            client.get_seasons(limit=30, offset=0)

    assert counts["n"] == 1


def test_client_rejects_cache_and_cache_backend_together() -> None:
    with pytest.raises(ValueError, match="either"):
        BaseF1Client(cache=TTLCache(1, 1.0), cache_backend="sqlite")


def test_client_rejects_cache_false_with_sqlite_backend() -> None:
    with pytest.raises(ValueError, match="cache=False"):
        BaseF1Client(cache=False, cache_backend="sqlite")


def test_client_rejects_cache_path_without_sqlite_backend() -> None:
    with pytest.raises(ValueError, match="cache_path"):
        BaseF1Client(cache_path="/tmp/x.sqlite")
