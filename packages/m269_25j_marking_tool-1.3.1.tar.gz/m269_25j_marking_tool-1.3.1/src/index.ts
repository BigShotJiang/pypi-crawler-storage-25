import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';
import { ICommandPalette } from '@jupyterlab/apputils';
import { INotebookTracker, NotebookPanel, NotebookActions } from '@jupyterlab/notebook';
import { CodeCell, MarkdownCell } from '@jupyterlab/cells';
import { ContentsManager } from '@jupyterlab/services';
import { Contents } from '@jupyterlab/services';
import { PageConfig } from '@jupyterlab/coreutils';
import { showDialog, Dialog, InputDialog } from '@jupyterlab/apputils';
import { Widget, Menu } from '@lumino/widgets';
import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { IMainMenu } from '@jupyterlab/mainmenu';

//import { IObservableJSON } from '@jupyterlab/observables';

/**
 * Initialization data for the m269-25j-marking-tool extension.
 */
const prep_command = 'm269-25j-marking-tool:prep';
const colourise_command = 'm269-25j-marking-tool:colourise';
const prep_for_students = 'm269-25j-marking-tool:prep_for_students';
const al_tests_command = 'm269-25j-prep-al-tests';
const open_all_tmas = 'm269-25j-marking-tool:open_all_tmas';
const finish_marking = 'm269-25j-marking-tool:finish_marking';
const set_tests_location_command = 'm269-25j-marking-tool:set_tests_location';
const change_decrypt_key_command = 'm269-25j-marking-tool:change_decrypt_key';
const write_al_test_file_command = 'm269-25j-marking-tool:write_al_test_file';

// Initial code cell code pt 1
const initial_code_cell_pt1 = `import pickle # allowed
from IPython.display import display, Markdown, HTML # allowed
from typing import TypedDict # allowed
import ipywidgets as widgets  # allowed

class ObserveChange(TypedDict):
    """Type definitios for radio buttons."""

    new: str | None
    old: str | None
    name: str
    owner: widgets.RadioButtons
    type: str

# Dictionary to store marks
pickle_file = "marks.dat"
try: # allowed
    with open(pickle_file, "rb") as f: # allowed
        question_marks = pickle.load(f)
except FileNotFoundError:
    print('Data file does not exist')`;

// Initial code cell code pt 2
const initial_code_cell_pt2 = `def on_radio_change(
    change: ObserveChange,
    question_id: str,
    _radio_widget: widgets.RadioButtons,
) -> None:
    """React to radio button changes."""
    print('Radio change')
    print(change)
    question_marks[question_id]["awarded"] = change["new"]
    with open("marks.dat", "wb") as f:  # "wb" = write binary mode # allowed
        pickle.dump(question_marks, f)

def generate_radio_buttons(question_id: str) -> None:
    """Create radio buttons linked to stored_answers, updating a Markdown cell."""
    if question_id not in question_marks:
        raise ValueError(f"Question {question_id} not found in dictionary") # allowed
    previous_selection = question_marks[question_id].get("awarded") # allowed

    # Create radio buttons
    radio_buttons = widgets.RadioButtons( # allowed
        options = [ # allowed
            (f"{key} ({question_marks[question_id][key]})", key) # allowed
            for key in question_marks[question_id].keys() # allowed
            if key != "awarded" # allowed
        ], # allowed
        description="Grade:", # allowed
        disabled=False # allowed
    )
    if previous_selection is not None: # allowed
        radio_buttons.value = previous_selection  # Restore previous selection
    else:
        radio_buttons.value = None  # Ensure no selection
    # Attach event listener
    radio_buttons.observe(lambda change: on_radio_change(change, question_id, # allowed
    radio_buttons), names='value')

    # Display the radio buttons
    display(radio_buttons)


def create_summary_table() -> None:
    """Generate and display an HTML table from the question_marks dictionary."""
    if not question_marks:
        display(HTML("<p>No data available.</p>"))
        return

    # Start the HTML table with styling
    html = """
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            text-align: center;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
        }
        .not-selected {
            background-color: #ffcccc;
        }
    </style>
    <table>
        <tr>
            <th>Question</th>
            <th>Fail</th>
            <th>Bare Pass</th>
            <th>Pass</th>
            <th>Merit</th>
            <th>Distinction</th>
            <th>Awarded</th>
            <th>Marks</th>
        </tr>
    """

    total_marks = 0  # Sum of all selected marks

    # Loop through the dictionary to populate rows
    for question, values in question_marks.items():
        fail = values.get("fail", "-")  # allowed
        bare_passed = values.get("bare pass", "-")  # allowed
        passed = values.get("pass", "-")  # allowed
        merit = values.get("merit", "-") # allowed
        distinction = values.get("distinction", "-") # allowed
        awarded = values.get("awarded", None) # allowed

        # If marked is None, highlight the cell
        awarded_display = awarded if awarded else "Not Awarded" # allowed
        awarded_class = "not-selected" if awarded is None else "" # allowed

        if awarded is not None: # allowed
            total_marks += values[awarded]  # Add to total
            marks = values[awarded]
        else:
            marks = 0

        html += """
        <tr>
            <td>{}</td>
            <td>{}</td>
            <td>{}</td>
            <td>{}</td>
            <td>{}</td>
            <td>{}</td>
            <td class='{}'>{}</td>
            <td>{}</td>
        </tr>
        """.format(
            question,
            fail,
            bare_passed,
            passed,
            merit,
            distinction,
            awarded_class,
            awarded_display,
            marks
        )

    # Add total row
    html += """
    <tr>
        <td colspan='6'><b>Total Marks</b></td>
        <td><b>{}</b></td>
    </tr>
    """.format(total_marks)

    html += "</table>"
    # Display the table in the Jupyter Notebook
    display(HTML(html))`;

// Question Marks JSON
// TMA 01
const question_marks_tma01 = `    question_marks = {
        "Q1a": {"fail": 0, "pass": 2, "awarded": None},
        "Q1b": {"fail": 0, "pass": 2, "awarded": None},
        "Q1c": {"fail": 0, "pass": 2, "awarded": None},
        "Q2a": {"fail": 0, "pass": 3, "merit": 6, "distinction": 8, "awarded": None},
        "Q2bi": {"fail": 0, "pass": 5, "merit": 9, "distinction": 13, "awarded": None},
        "Q2bii": {"fail": 0, "pass": 2, "awarded": None},
        "Q2c": {"fail": 0, "pass": 3, "merit": 6, "distinction": 8, "awarded": None},
        "Q2d": {"fail": 0, "pass": 2, "merit": 3, "distinction": 5, "awarded": None},
        "Q3a": {"fail": 0, "pass": 4, "merit": 7, "distinction": 10, "awarded": None},
        "Q3b": {"fail": 0, "pass": 2, "awarded": None},
        "Q4a": {"fail": 0, "pass": 2, "merit": 4, "distinction": 6, "awarded": None},
        "Q4b": {"fail": 0, "pass": 2, "merit": 4, "awarded": None},
        "Q5a": {"fail": 0, "pass": 2, "merit": 4, "distinction": 6, "awarded": None},
        "Q5b": {"fail": 0, "pass": 3, "merit": 5, "distinction": 8, "awarded": None},
        "Q5c": {"fail": 0, "pass": 2, "merit": 4, "distinction": 6, "awarded": None},
        "Q6a": {"fail": 0, "pass": 4, "merit": 7, "distinction": 10, "awarded": None},
        "Q6b": {"fail": 0, "pass": 3, "merit": 6, "awarded": None},
    }`;
// TMA 02
const question_marks_tma02 = `    question_marks = {
        "Q1a": {"fail": 0, "distinction": 2, "awarded": None},
        "Q1b": {"fail": 0, "distinction": 2, "awarded": None},
        "Q1c": {"fail": 0, "distinction": 2, "awarded": None},
        "Q2a": {"fail": 0, "pass": 3, "merit": 6, "distinction": 9, "awarded": None},
        "Q2b": {"fail": 0, "pass": 2, "merit": 4, "distinction": 6, "awarded": None},
        "Q2c": {"fail": 0, "pass": 2, "merit": 4, "distinction": 6, "awarded": None},
        "Q3a": {"fail": 0, "pass": 2, "merit": 4, "distinction": 6, "awarded": None},
        "Q3bi": {"fail": 0, "pass": 1, "distinction": 3, "awarded": None},
        "Q3bii": {"fail": 0, "distinction": 4, "awarded": None},
        "Q4a": {"fail": 0, "pass": 2, "merit": 4, "distinction": 6, "awarded": None},
        "Q4b": {"fail": 0, "pass": 2, "distinction": 4, "awarded": None},
        "Q4c": {"fail": 0, "pass": 6, "merit": 10, "distinction": 14, "awarded": None},
        "Q5a": {"fail": 0, "distinction": 2, "awarded": None},
        "Q5b": {"fail": 0, "distinction": 2, "awarded": None},
        "Q5c": {"fail": 0, "distinction": 2, "awarded": None},
        "Q5d": {"fail": 0, "distinction": 2, "awarded": None},
        "Q5e": {"fail": 0, "pass": 1, "merit": 2, "awarded": None},
        "Q5f": {"fail": 0, "distinction": 2, "awarded": None},
        "Q6a": {"fail": 0, "pass": 7, "merit": 12, "distinction": 16, "awarded": None},
        "Q6bi": {"fail": 0, "pass": 2, "distinction": 4, "awarded": None},
        "Q6bii": {"fail": 0, "pass": 2, "distinction": 4, "awarded": None},
    }`
// TMA 03
const question_marks_tma03 = `    question_marks = {
        "Q1a": {"fail": 0, "bare pass": 3, "pass": 4, "merit": 5, "distinction": 6,
          "awarded": None},
        "Q1b": {"fail": 0, "bare pass": 2,                        "distinction": 4,
          "awarded": None},
        "Q1c": {"fail": 0, "bare pass": 2,                        "distinction": 4,
          "awarded": None},
        "Q1d": {"fail": 0, "bare pass": 3,            "merit": 5, "distinction": 6,
          "awarded": None},
        "Q1e": {"fail": 0, "bare pass": 3, "pass": 4, "merit": 6, "distinction": 8,
          "awarded": None},
        "Q1f": {"fail": 0, "bare pass": 3, "pass": 4, "merit": 6, "distinction": 8,
          "awarded": None},
        "Q2a": {"fail": 0, "bare pass": 3,                        "distinction": 6,
          "awarded": None},
        "Q2b": {"fail": 0, "bare pass": 3,                        "distinction": 6,
          "awarded": None},
        "Q2c": {"fail": 0, "bare pass": 4, "pass": 6, "merit": 8, "distinction": 10,
          "awarded": None},
        "Q3a": {"fail": 0, "bare pass": 2,                        "distinction": 4,
          "awarded": None},
        "Q3b": {"fail": 0, "bare pass": 3,            "merit": 5, "distinction": 6,
          "awarded": None},
        "Q4a": {"fail": 0, "bare pass": 3, "pass": 4, "merit": 6, "distinction": 8,
          "awarded": None},
        "Q4b": {"fail": 0, "bare pass": 3, "pass": 4, "merit": 6, "distinction": 8,
          "awarded": None},
        "Q4c": {"fail": 0, "bare pass": 2,            "merit": 3, "distinction": 4,
          "awarded": None},
        "Q4d": {"fail": 0, "bare pass": 3, "pass": 4, "merit": 6, "distinction": 8,
          "awarded": None},
        "Q5" : {"fail": 0,                                        "distinction": 4,
          "awarded": None},
    }`;

// Testing calls
const testCalls: Record<number, Record<string, string>> = {
  1: {
    'Q2bi' : `try: # allowed
    test(find_client_surname, al_test_table_tma01_q2bi)
except NameError:
    print('Function not defined.')`,
    'Q3a'  : `try: # allowed
    test(find_occurrences_with_follow_on, al_test_table_tma01_q3a)
except NameError:
    print('Function not defined.')`,
    'Q4a'  : `al_tests_tma01_q4a()`,
    'Q5b'  : `try: # allowed
    test(council_decision, al_test_table_tma01_q5b)
except NameError:
    print('Function not defined.')`,
    'Q6a'  : `try: # allowed
    test(weighted_council_decision, al_test_table_tma01_q6a)
except NameError:
    print('Function not defined.')`
  },
  2: {
    'Q2a'  : 'test(power, al_test_table_tma02_q2a)',
    'Q4c' : 'al_test_tma02_q4biii()',
    'Q6a'  : 'al_test_tma02_q6a()'
  },
  3: {
    'Q1a'  : '# Double check in case student removed.\ncheck_tests(q1_your_tests, [Tree, int], max=5)\nprint("\\nChecking student tests against our solution to help grade part (a)...")\ntest(tma03_q1_smallest_product_tutor, q1_your_tests)',
    'Q1e'  : '# Double check in case student removed.\nprint("\\nChecking your code with the public tests...")\ntest(q1_smallest_product, q1_public_tests)\nprint("\\nChecking student code with the hidden tests...")\ntest(q1_smallest_product, tma03_q1_hidden_tests)',
    'Q4a'  : 'print("\\nChecking our TM against the students tests to help grade part (a)...")\ntest_tm(tutor_tm, q4_your_tests)',
    'Q4d'  : '# Double check in case student removed/didnt add.\nprint("\\nChecking your machine with the public tests...")\ntest_tm(your_tm, q4_public_tests)\nprint("\\nChecking your machine with the hidden tests...")\ntest_tm(your_tm, tma03_q4_hidden_tests)'
  }
};


// Walk through root dir looking for files
async function walkDir(
  contents: Contents.IManager,
  path: string,
  collected: string[] = []
): Promise<string[]> {
  const listing = await contents.get(path, { content: true });

  if (listing.type === 'directory' && listing.content) {
    for (const item of listing.content) {
      if (item.type === 'directory') {
        await walkDir(contents, item.path, collected);
      } else if (item.type === 'notebook' && item.path.endsWith('.ipynb')) {
        collected.push(item.path);
      }
    }
  }
  return collected;
}


export async function decrypt(keyText: string): Promise<string> {
  // Replace this with your encrypted base64-encoded string
  const ENCRYPTED_BASE64 = "Gf7RzjlA62McTQz1JLNqEVcnoybfZc/7PH+6dWtWa4aUjiD5FvdDtEbeg6FLNeYheOWONSjHG4Z8IhdORSWe9JLcoA4CA2DCepCyLaTllNqDZiXnZXduxeArsRD3xswsy+7aEsk9+aE8sALji/ATBsVv5lV97s/wAD2RRBplE3XcjajKXWcUo2uhPtfi1NRZMcOMT4ZefACqmqw14eOb0IRmKpiT8DfbVjnv/q8B4TBj9AD0KRp7Ggh0IUjzZq5HaTEaebU4oqhONEYaWYido3ifQQRNkoXSV/kK4n/+J4USMY09s5WKIRX1scPNMGqLNv+gTq3HpK/0zgzU7wb9TGCF5m1e9ac7wED4OZ6L2Y2dsPw7PszmQAzF3JP7CB9U6ROWpmjqQAknzN614m7IFVf0mY+6nDA+x07M7uSvJFeLIQqLmRVC0AKVWtSreP51EJC4OfmERweeqyUOmCP7pEUkN90qFdKZXN05He0WksalNlPLmmHJJ82bmtkpOvcZO3J0XhIENEtLMJRIH0p+S+PdTd1cifCSIelyqEgi2pNWRDvf2oHqM2nTwKlNYCqRCWmlvrHAtIEOFVYZrS0plFSP8+AmS7JyGjGzeJHfBBL/ar5Wh+7SQFVPPfbB0DsFO/0rxcY81kdTNJoQOdEP3YriXmvzwggZ/oJ5MbSL40FHFq04fLIzyu+g7PLo0FGGGoy35wfe00q++wPMK4jFqaE2R0rNivdsC4tBTSkl+mJO2pIIj/48W/TobmPrgg9sOXcLLnJIeADAFYz4MgCg8EOBZBMYQb5KNQYjaJ1LSg2MOW23ThalYhUwuG2e3eiNYh057RlvXLBnrGRexVrEoYbhuS2RRIODvGUYwFabNfjKm/RhUM4OfVn2ciglOBCcYUfqHsNeXYsr1GziIYTAY/+7BRglTHHH3/kDHCVMJjc1uDsk9lZlvb0mmSvVTu8KM9j5wJZXFdMp14+Btn6Cs9xwoH/6WGLSBCypJqd9u3ocoPwAKHk7d5bBH+NK9YTqYpHPhI1IYRQGiURAWbM8+iT4jcpuLz/yqEVbAY+jMaz3kVZpLNO0KknxX+952FHeLcAbCfUShOPzV6gfMPucAb7r1HmLPBYz6XTsF57qUdR3/7/EQmC18FJbmLKVMRsuOUXGOx+NhQ1xL5FQNJPDURdiukUKaqA5W3IL07shiEU5SC3QiEsyTcjq+ANPfgB4JwpUzCdEw85k4VUweaUoRvBnJ3OfPUiREpNbhy6250cH4MC4z/X+Nh/6b3NdC/6UYUZI04ctq+dCbS65goBCACrL8800MXTfp0Y/hJocx94GOu3QrI6thGf/w/kdZZ1I9aq97S5ejDjW8k/xI/M4kvlyIYNj2H6XN35XROMK5M6V19JiSMHiy3ZbxxC4ry04xA227nQ1zW+DXftGLznJKXQuDtBGnmcKxOREr3UyDQiWMm7CTuCw7/IgXq0Le6XKWPWUYM24S9kalM5eRyY5JO1VZk2j/FZTlSprhZ33WB99KBDeBzG0JdKhVYaUhqzV6en1qnMAKuI1WQAPbuKyYYD/FcTQ6adl3B3HQm7KsUHVyhzNv0Gk1bdhRhviYp6kVdXihgt6zLu3k8Xqufh585IF83ygNqVrsYnvOsPAduaLeqp93Q+N9HXE/ZrxFblzjF0zrpa309OYe0ovW/5oMOdXfznVeozFekwVOmwFLfbnMD0V35XyLK67/eZSHxd53s9NBcOwNVNpZNOh2qbEXUWyvesSDGejs8vvEYO6SgxmvAc9G8K7IaVa0Bz59lpp2CsSmsgGzgnHeXFvoDUSEZsjwg5OR+3T2axCx3GqxqetmQmxENsLSOsGqI8HN6don0/Cz4rWRmrfwAmKjDiwkHSvpiCeFvlNZU+02uM/PZ5QOn0OtgYfkCN0wMX5pPKO/WVqnZz8CtXQd+X31lHZcC4T+BFzRnPyiRixy9gzkN34g8vqG2Gq16ZAVOkvOQpFV3J0byF9c5pIcyiKFNaLvkXo8zXcDdJBkNwoe7cWrYzntM77tdBSf4snJZ5jHDGfPP9Mv9uEulZw3ckPVuRYygaPso+fXFX+Qk9NbEpC2QiTU6YnHlE3VnW9CSAyqnADTk4Qy1UpZ8djREYfSUW+BJ8FPtTCuUvUyFpCJ8Y7096YepSyy4GVuaqo7c0EBHP5ABAnzJ2RT9TVPPnxLtfEx994xYQW/bJUcWDwRKBkSnOEdXoVY4P26u6EmJo2DCORPt8FICrwkdcwDrDFAzFRZZLlf7R5xEJ1pof76vNJiRQ/gLC29C6y6iBb0U8maT0dIKS04RRqJMDADUFQWf6TilNFfwDyiuz3UQmQe0S5sLBot2wuMPDnKllJvCewJ6+WI1CiUayb4r4M9j14aKxbOaj+kNmqSv+MYneTBboIlA8qIAfZ7IWuMrvnP+/zFPFMit4Rl+1K3hJ63C89I+hsfmEoHPebiJK/XXb6HEWE4dcCoFuIKjUhtr8LwkQZiOU2B3xpkKV0i+8RwEEOBXaI+OJh0dnD/TSiXU1VnYraIKSZgNWPrfHanuuSv+28kMHbyUphUDS6Q1RvWKVJECRMEv1wmGmodguerzxqK5TENmua/ptG/8djsmybs0xjEH0sDbsswvy74gJ6C3k2YLDKbHLLjI/QqM4jGoT1+dvNUYGmTN1/RnLYtZkVnWxcGMM6ynuYf0k6qYXVyPIbfBVwsvdGnWC8uLQL7U15NI9p6Uwo7mLCewxBLQTJdkbABwrInv7spaA5gLeenrlcoLYh/p13ETzDya8VYETFrg9FC4HUKHYEmdhx3CwiBO4M9wdyVrB0W6JIdyUo3dx20z8bgGata7p5ymNaRJnxJY3geokigRc5c2sVENEZu+B1uE3RWJEBbVmYuUg6EPGYScR7vy8CZ491/8hkRzfh6uDvAoFsV54qllonxevXVgva2GTJ4uJJO6cJBKusz4QkxpxCPu91TzJAJw5okEgAkoieVkj/54vS+v1eYrPKAvejp8zemz1Bmj3k21n+PvIjrgr6qE/hubeBCjIKt0LI/zDtfnSk6sDcyq5S3yLETX7hxr51hLgkb7JCN9wtH11WhtvdSHd8grgOMBEvt1HDRAqI26JSfkZ0p4hERLoAOQdwUddRx9deRbWoCJCpOvN1JmDjhFSHLZ5vH2ueoAlE/gWdNOJEVplYurPuDHk/2jFoqx6mFeGdAUYyeMBsazQwC/WrtLG7c+GEmm0SXmLPPRxPUvjcf4cfVX0eioASjsCMuIQUIApUHNHhGjCCxmqrrA0jScpnOO/M+SGmmlJj1avpAMurJDEk9EZb6MJAzGRn19oR7pm0o04/MGLL8jHUhbFuVbAFu6hJWDxc7UGQT7WPaTbZYkX0bJ1ASVchv1b/eJsHRsTW7Z5kTk8ZIKwHtAUwKEazUGvjxHJ7xJ60XmJX1o2OCit4v+swcGe2hzxBeK1FQ2Us1KguAiZ7zt0wz9U/Hm4zTxrJh2jLIAzurt+klhn97T34KiOTvlGWt8bvx8QHU9z03+jAme3ZZ7BNNwnFjY1wjxY5rYSJel2zfHFJ3Xdvv8fwztFkfSBI3ecMSnQwhy4AmqQZEPOV4d61/KytRl0JHnXPqpEo2Qu4u+ytsheiCg8hVtXbpv04EEZFNuIAHMt5cF5c6Ohu4HS4LH5hzT1x7OV7uvQGTBuA5zSl8IgX8dx453w+d/Pc07VnchriYcVw+oFLYBQE3AUPu8gnEwESMjxTtFVAgUGBvL1xUl//fwuKqWPCEF0nvfnqX83GnCArkVr7r7r9ol+d1Zoxd07cwD73KlYQ0y2nCkz3FUgewtrwy70QLmOktNjGs00mGuysIq/cAWkNX/02OS0ZGvFLByS96rxUa+40iW88wlu2Q+Uj+vSYo4ErhJ4m92iJTSDCkdtMpHG6y93poShozZTROIwDp4XBEXFucn9hm6gEeH+rwzaSsHl2g0or/pQncJkUYSasCY8bHylWdTNTxmOGASYzzRETWbKllkiDPsur46g5CQMra3vhDLKU2fS0uG76FVzBmLsg75m471Rn92Rf7dDX3VsMBHwRCopEfFJGfvO92QOjtVePmdmaO7VKB5p93ATQvaHsOK+uGy3Tt7cTWRm2fHaGpTmI+qXE1m9elOlrY7E3aHsRYdC5bGpfrxrYcUdnzbVjcY2sCk7zmnUrUl+mg0bsmTAFKCuBYZgVAu8s1iM5t1LvVzUpCSi/R4Q8kmraQW6fY06SSHJC1M8Apbps+tTX1Ob27s4FhVT+Q7QyEJxJgKRiUPC2auxWMwOCCi+6EcuMkzH+mCN2PlbLXZ0iYXmPjBh1ylD/vJEZYYa7zR6CaZ7EPd3XVZ+IeOb9kiPIcjEoReDaAfRxlJif6T7R5zq6lWjyHrqnO1dJxDNZdYh19Fis9Z5R6HXCjIXH7USdk4DxmBpDx0o/xWZ7ua4X+YyyOXX4fuM+SqoiDbtBHTLPv4HHUikaiTTE1ctGPNYPzzBGzMfgmL//Qk0UiLYv0uyYT8PwY1ZBrJJlIsI6VvV0AippTBa/9PPquEH1dKniDGnvqRjVw8sCcZY6v3cved3K9gQIJDzXRGdFruBBF+/Nu3mOwEiYtoauwNDhqkZvvnbK1aBmNNFMKBolqGN290gVUHqFSpcPAgE/yP2MpowK+kZpJzZdICwoeOSw5P8F7rrK2JeFeFlVAIQYzZ8iUlYkJwNRZXryQGyNEGLlH0FG+q+hh3EjOH62K+P2yehD4nWsmf/RDsW0g7Kw8EQ/RMMozhU8pJgtl0DbWoAA13a12wv8iBodkZFDE8jQyfe9f5unJSgJn85CSUjCfryDN5FE5U6/bhdScg0ckQIrP8qhvbm7xCf/TX8+NAWur2lkHB5BqGL9++xbT8UN0hc0Y5qRSO7nIYpmtobqudMm10B2kTGlIM/lgG8w6cvFPrO327TmI3zFoEdZ7ZimIW/cT6kz4gyidiQuT6E3qLm6KiE4djPKXuP2XEb15lXwxmZKBX+rdQt0SRKmCsDGMc/FCgVaqmhO7hqgyY3P7L1YCUlnopG03E5jz9GeS+9jFACm9kIPShzVNr/oBCRrUKjPFK+wVTnSVW6wPBBYwv9urQyj6JrZDgcytx1E0kvfnR0LehhzN/oTwc3ljHtJaAU5gF4cZMzQDWuJcBD0nevrCkxfwT2LgDmHz1hIWy6cZ6Grl6Fe5pvMlaoK2/95gF9Hmn1lbsF0/o4tw/486BHUpnkJQ/BfW7aC6oQR97flU7Wl1gCwfYlST2vBs62NHMPWNOjToIMFrEMsohkMW8ucLzueTPIsI7voRmvikqF/E9NqpLJWotuZYbM6fXsm/bDaPePTR8hzXXvZKtIADCnr2MP3OO6F5s7J0SXrR5THkdMtjCC+RA+zFy29io9CUJ+VhvOlyZC5Z9cC+t7N1zirJMEMa8neZDT+8vu6grEbaPgO8ndnz4B9U15pLXJ83hDoA2EwqRGz8xrsFjE5GCqbvbJjqs9+PPtIFWHQOHGDI8NuDOKygzY2LFttOgJ1h3aiUsFpc3rGo7MfXcfcmgWdjs+urggOdcrxTpmgIhW2bLvLXm0aIgKoBENBczGQEba0mmUugBzAL2pcE+xrKVcvYW9cj5o3zGq21dtbgKzK57CCxaecFSYGMcUPE9XGsqGdlIwESjWIEP4UZgFQhKXi8Z/SqWjVtfZXIVDAXX4AVFgvjJIl7WwwmliovVevalFDfCJQv6eIaJSxa8aiuRZH/uZoA7Hbwe21n57RwvyQ6GnBn9tn2Wmo5uCCtVjILAy0S9SD+tJDsfyJ51hDUWdCZ2SxLiIcwLaqJsrrA0Zl9l1aRc9hKFopzjujkooyOuUcmUSJqVEiaUXV8qHW8dxb1zNcR+UMrPUK73Lp4bcSoBEQusVnRnnuMk6mTohKEFIhJsYcTOm8W+RUMVpofPOtXwQRCW+kbNeTQqVfuB1uHF3+yPL05BGrWQuZJfHJSVKtdD3VPdq3rwjDaTDwoXOdaNiJdvurX1sbZBOgxgqDib1nTIWbP/aud23pFZEB+VPUcDNNCIfQzjnugxZ7DLG5GDA5Zy3eNP4Zes1Rz4HMgzEmZg0dXFwJIxcawgIEGcOxUv853DG5ycpI9H+y6M0TpTaYq3lJbIxHxvbVXowXwVijbiQNXsgrxTk1k6y153TUcZJsMHKAg1uGw8LAqP3Hh+X6ncmXRyHSsXs11JoyX9GjW2tABr68TWzRitj/7g8epIBuPpuT3t+U84yRaWVBSxvGqAy8v8DvkbRY2xkHDNrceUjWtgDFuaTWOC0QVL+4xD7sBgL/drowbthNaANw9w80kzi9bWFIXFrcNFjvjFS23wMSIVlGVJc9VDSUaCH9Ircd7sTjduFujzeDpK8ZdAI5LIEHnllK4cDXrQGB5QIc0Jf3RJJZIF/wquRzSLvf5F5H4HSDuEawfSsAkKqT1/59F9MPax+hQv1ekbeG7Oz6NtyVJIZY34qxqZnUWK8OeP7StoOi7RuOAMhItx3qImGoU5KxDV1ofdMpiJ5ElHYg/YJ0uiZDNPiGyDxRXrDIAc89JKosKqTgIgpClptveeV+sO/R3SAb2OEcwDk7qQY1d7Si4OZ15qyj4VjbSP6bNyN55t0PZK4C7N6Cq8gRtugzOrdObWeVw5oiu845KI0FF2/JaaOvS0oxgWazPc6d2xpgFq1Q8Lao5wZn2gSX7lVUcewlM21wI3CP95EbS5ksZU4YF5/9jy3r/U0IT9Y+drO5iDEFa9H7p+sVg1rdr+piFBosnpzswTAohzwpC6LwTrbcJ+B+0hRBYMTlt7uaVbmtZ9tc8W/IQMh+rTMZZVVDGIACyV1LBfF6yVWeAECm3UjC6n2l6nUxmKRSL6gy2Ql0YlpUb9KqSpKj4/hxIgb06n0pnQp7E96BmoZngrJ/z+2zXOlLdWo/MTfxPlgbEXZMmpJVlmjkMGPapUKGjPiJQ/JFY73BqBpSejl1zPss2WQ35NN5RpUs5OxLv8yVpoYRxMPrbIjjL2sF7jX1Lx/HEonhjhhwFiV6xHFa/s7bzW0wLqS2buALueaHhqG9cwuiLnB+8+Npz/8Xen5pbGLSGJcJF+Pq0AM/l9Xaxf8FcIZNgwuvbdTe+SwY6iO+odmRQViSOLBIdwupJKVWvSs/Y4Xl5l9yOw6ZntOTBf5px0u333HAuWA4NbU9ULCKhs4HRnbXz2CR4PfZ1NbfDVvD4FpPLhBKXZkX6cxkMPc+AWOVscWRwOfhGy+peMMa/FfugFv4+MxYvAOP5fk9LEWl/AK7U/jdb0uAtvg/GXhCfmvlj+0pZTVhOlrmrVcw9mTtBF/zYlgx7r6kOVjSk6bwl3E+YhU/mroexpR6c7tmDbBD62Ih4HbDv/O1mGo4GqUkWkFS8et1K0KfSJAvBTzMcWq8JEDEtdXu44Pnr7jdsADyDb3HiXEhmaHQxXb3RMDnGIBpSAKHMgRu2Ykghu9P/cbCu8hEY8VPN27s4NjqhIASD72COjyo+X76hN7aUaKoDz/npGs8Q3/7wqtgpw3vuO6MbCoOp4oyzUjBYYt1rV9SoOx2X263WLo/OrdeDoZzVTJjZvRUFj0zXrNHNj/lbCDABCBjSZ5G+OPp6KbJAWdTy0hVeGbOLW5XE4uRH7+JzbT3XjxQPnzTKaQhyj3SWLsewuQy5vuiwCkK/VwG1itXpJNwWsj5Wwe0/4gwSN2vg3nkND72znfx08wnotYynBt7/LfncdZg65jNJzRMBiJkjgW6KtAEf1utfMeVbiz9GDbfWfUzQjeI0hnMZBht3nWoEAins8RVUj/abkOkjif+A7rzcJUl+9fCr6L4vnW3XEyMQXGd1051Gch5cuTayFNviKllw6ZIBN88UJ47SReEiiGidCWQRoOKGuLy/YDG5c5T2hN0A8AstCeaGllSo6OfDVKyJPUWt7gSN7nnYK1E8X5EvQa8EVtFRR5dgPUoBryd5z/8N3fuCZnyL1QxEKy+nc94mVigjkVr1sO/Nzi82y5c0v5mTFDHk89C3VovoJ6BmDCh/M5Sl9r+fZOxxv0HMUrWKnAkTRljQ9jfhfjZwwEtYa9xInLeCdkAYtvx4SOvV4x9mOFEZL3hLW84nhNAlHPHWUgJraaoKV7BCpzKsHAy/1H1ld+4HVS6AWaOupenMsBN8wF3CQhQkryMe4kXMd7AacmIElEDb7jj+I0XOSJmEHsuyOI2Fyvw/Zfu/e/gduHz6Yr6QhWUqwPw53L+xEg+D06MUq7AqmosQjwtMk+BCuObn8NgIlWmiJKf6JlDZAvvJ4BJvFEL9q9qMR6UUyUR32YLnqsRZzvuw+KE45Z5JHXyR+yakYoE3R0YKIeMoh8lo723EGUFBnUUIZSBtF1QiRSKtlgExRjNWKZN6smVRSyvH1ct0b0NxdNmGG8aT1Y1MJ88UYwVc6M2E/LLuJLJ1hPSBkkDKvE5ifBJK+2lv7cIri+FJnFnDym/9Q4aY0v2u4zsZMdZkRcE39ZylRna6Dc2WYf+nVdLId437mH9NxVz0lj83wy/FmwnzhiwFYWS9sIyrv5n+DdA9bM2iHLD5HbuD1Lz6yP+mXLqWvCJEmxcVAQoi9207EpYKEfEwW8kgMV9cCrVLKAIZ4kUqjGEYp86mqDq8HjUFwFfC30ri/cCHQVp8AlM43ROhZzrwyiMYckFSVyDLqkgwAQelBR3bqmNXotCh4mIhiaq221anNZwPhv7Uxl4AVFsf1mxoBrG/PtfsKPM64Fh6cLb5fJQSb9lU2BkDRh+AwPiTqzSQTQ7GYPOxQnlRNqjPo1f+/egifLcpgs+q6XAHwI3097eCc3KZRjgUrZWny23yPwID3QEJ0tZ3O+KECiqgT9LQ/vnd5j+XRXRNS4l8BLISzsa5dW8dE5dUuMm8gABS83wroWHz1FiYZDIWI6dyO4xqfWLFSJ5x5C3+4AZfKJ42D/ynT/hztB57HpfKpa4Avr4jJvpgKXpSRiC7DTU89RLKsY1+BZJSlNLllTGnwFumG+Rqgq/DwaJgE1763pBxHeQpN+m6nAQ3P2qjIFPvUbB5XiUCmrI5bguEArwmvWDg8tFRHw/UHoRYFOqdlRNecMEDWVVCdJKX8YCeFuYLpdXD8/xPr2qmya8gGZj8GQiCKNInY+GNzXezQj8/lurZy4OJqMIP1jl6vSdhuPiSHUQOPoPvQztPWckXPSdYTpPR07M9Ncdt6Z5zLqiubXn1cY9HYtxTZ+DnrFkdfzoVSTcq04C6MAxTkOCyUd/8jLJ2uGKe79o07zl2z+3orQjXVfcIOnDkqWy69HZLP666Qm2vG8+pFcpPuHh23EN95q2cxZBTRmoTN6sfGF6f0LT+sXDuTeJTcRub5d1vkvZr1q4t5/CeX4V16W5XVnwp5WHzfj6oHx0a1FpqA1895TV2ZRcPQCXC62EHEWPQRT/bCjZ7JESmZHmmfGOAk65cQD5tnKpN44kesPT626tRFTqa1Vdki/bKmgISFugHUsBiTCBF/ycqPCjbChV+CtA69GpMC1zBPquoXfuaDUMhSGQ/IR8XVd9ESoa03GKo+jCPpqgDO93gki5x8AlAxGCBDLageyhLUlGYcRITq5AFofIfUi2M489qMZhYgW55QnkWp+w61vfeDvsSOqbik+lCne9tNNLBDciyxFOSWDsfNJiOcxuOiB89dNJMX3mwqmcRO/YD2wa/l1EsdyBC6ba7NthbQszwzao4O41hQetjrr4g6GdtTC2KVlIvQuhor38FODipgNhFGLgQLCw8s+awXnNKZ7aWbMKVhJOvNJ23NKo03oN7D+b25Lcf+2UQ7IIG6FfxyDoCFI7c2mxh9/oiwkVndPuB5m24yjs6Jfz6QcFuRs0Nk9v0IBh0y4D99lAMcKKPfpdF/Bs1MSqkORcHag9VBU1/Yzxkg7stYS/wJxwB3ViY3+t40BcQHWlO5SyJBd/e49fLZSlDnai03sR3PLOA7fbuWMu308y8ajb0gG6kWAxTLLdK6XOnyO22NTk7ow5o/4E5wYBkmzHjBfAVfhf2jz9n7WbXtK6aHsUtoqDxN9vDDvAUTqjaCzAXNzF9II85bJDOoaptOCTyVKLKMrnuH1wqz8+2T7yXKSkKwch6mjTsOu6YxFHujePC2v3uruhtJtUUgYl03tKTdazS56H0nx6/ZVQ1rO4NJto1Bos2/nOFbrqHFPKrMbTHm5fbr3+iad4a+q1dZWoH5KkegxmfQsA/NbrXoic7oIXy2LVYChnMlB9sKMO8ABO0WkFHuMtYTthtY7JTNf4CzgEJMfLKQ4+v7MQqr9Tj025/grRLYmO1KjpC6086L4dS8c6nNnEa9doXJGUrgvgJ4zNbEy7czKYn4mNoyK4IMLkETeVUOSKTzBOuHJtS6AjsBEnPyi5yRA0E9YHJuXQTTytm114+/OvrMNX7G1wzUSQuu2D3u5YVIhDIDOqIgDhMh6vddgfq8exi8NlEZzyEH+MeEcJnzO17FylcXjGYkcgbY51q7d4wzoVJNgyeiSByMCyj5YZLqm2e0QNs52/C4qjbHc0T1f4+c5UR27fyrFODWw2+VSGEW1lmioJikET+gTI8hsd9aloTJG19CYBgZ2SVkINT9GXFCSu3bw1kJQOqrdPocPOrFMT/JCUGsAzHW1wc49nRRrJx4Vn4JFnV/6glmu/basrzX31eAs5al4fq3aqrynxGdbsefwVQWqVzlnsrq7K4QcR4EUMzMXo33IggpnoovdP86NqJVFiwhBlf2fOhu4RaSFD3OmvaMI86OL7dK8hSUyzt6lB/UBhaaqf/Q+7t43wbLugcvOV3TqXxa7Lw6MCjRPf3Ri1ix5kN2cl3/f+xr1JyJdyONw0yd+TVGOTsgYAymJjkuWyALh80Sd9L5wU8yglrB+dV0fRzfEhycrZ/Q4274a2ujsfq8i8WeYpMHWJPiyLrPZKM9I8R+iPUl1l78POJLM/va7wjpcrTT8lfX7r6K1vvzoLv2w7OCPElcOb/480oGBTLb7LC4V2TiT860q4xcWaUMAXDu/9+aKvCbiGAV1Nr67Du9MCZJ3PKcdxQAXHEUhnQpMYup6/rWQMqY7m4s9GXwUJpqRp2ruPkLZb99UyWGb/cDms8wRktM9phm4hsVEAzT5Uo7n7kQE5FqFrqJplNPUcs8QC+FPKQdLV1cSlsdOVRGi5RzX89SVBWmvzD6jVGmJ7qCH1Ia5d80YvkLlCJ2Xrvbu0sId/UJ3dVHCQ2z+vGP0MSzKGu9oPFTVlqfYH4z60ilCE6y7fNJrTAlu3b63UrZLZP53gl+GpAKRLX/lbiDttzztNeCWO+YNUXIPKhAtXAik/kJvqdZSlWBe/R/9l/1Zv+2Vf4wNrp0QWftJx9WlD8+/VAjerLPjEGeH5Ti2WcEG5ZcEKZIsz3y+G07b5Ro33Lm3K7g0nJ4JHlbJ992WTg+HTZ9gmyJvxSB2wnIE7kikiii05Ici1eMHL4mG4FmP1PbFK6PXy8nNm3h4ve+SjN8AJnROCPVBVlT9H+eymAVtvzAmpHWCFwqOpu2et+WAVOLb7OQEtKcFbAxg9BOg/LqEjiBygOnC/lhCeQAdXNbTSMk6WATOP8TF9cFJMdllaA79/FGCf4SweQ0GkFz4uJyGheeeohc1NZwFQpdcHzGlrWBhRaIU+jUFZ7Jc/eeC9I2RAWKOK+EaJh1OYHdoo5HcGuKNqxwVmczUw4QlszAREo3NnXynALc+2l9qdTV81JoJcgxIyuC8E5JJLXC2gOYXGfSYonUZRfAradj3ZXG5VsvIAPJ1TvVK6BpMh26uDtiut7TttnjJ2er9zBsZ4rwYF3EtdPeuR8onOmE9okVD/4l7Ec7OfTyfWEHyN8bewNnCLiDTw+O6j8+H8sbKJXkAdjIbFni0JB++xYXMk4dGQ+5E2bPdqSr/OvOgt8QxR3geC5IlThdP5pXIZUvz5pBls7TsSx7IZbtRjxG8Naw+e6GroNxq08Vrq1DegqBmBng8HCnz3qXqxve8LkRCiXHmXbiDZ7VixlA7Lm7Bjn0xF3flNPj7REU9G71tCUNdZcdQh3TJSXPphIAE/wwaoKlmYKOPSJJP0pK7csEBSJ7ZpbDtva6wr5HRqy2NBnOuJNvrHUEUmqnAyLKL01AyLDQsb7TxT9wMDoe6I7LMZ1i54iWpC6CKFxfu3clLDvHHSlJenyUE51JVT2ifk6snSB8eN7r3RYnxIitQEjlqcJYseJJ3+fA01LHZseU/P8APEgzVPmCFeABANsCv7MhdN8eO87Ie8TQHD2XfLnQF7K4FYQ36Z+1XMaNP1GcOvDF8fmUsorTMmtmVpwFB5h3VQdzhErNt11TipLoJnBTC05fBPhlaLou5scp5dGsVLXxmLYjTgnX1JCqT3YLCDk4XG9xbOLsGeKiTD6AITm58WCWOoYmO/YKs4LuYzFE+K7/o4HTMyEO3aEBGMZLIpq9l6sRmmSPint1mUSdNLCQzK0zJ0Gr8EiwEqiG98JI3j183UsU49P/D9CYL9VTuJYbyjc3sn2brITbPhopWQH0cpVd/Y6s+39ATEoTrC6JM/1UKFtfphddb0z0egxp+XqvmTtFBiuq98+8XarJvavBsDpVarSppkVglhqNQJas2KDt/IsHBzG4oTwxkQ76qKGhzWZj0N2sO0aZkykZIBvNAs6oSk3OAivgHkKwqGGsn1No57B3YvS1+xiLmi9gf1t4nHz5i2Dh5BZ9u4YTGpDEXAFtvFxGyOF4W1Sz7jxJ4QcaBiHdjOpYxRyGEAK5muZzk+ncgCn7SYl06WGSgdOONE0Wh6w2vMoRpw5K9NPK/d/Uj/DPJbudaYphXjSEOZ4BewE7d6M+7YlBkTwcoWjisapqGjfBj0QKiI8qqRb9YkHoBQ+xD2MHJrF480DFnJ5bjsYgdf8W0nRZQSlNsCTPD/ZQWmBzmzlDJyD+cmkW78i9dBFD/fQEB7XnVedc99YeFZkqhL5ecuWavPsABj038dsQz3PjtkVVgl6DtBlp4rlt9jlCW7T3Xoilxf842EzinjyYGjkJH1TJRlF4qNorVc4oqcApjJ9nTau0E3+BeLjQpvv+oTaifbTbXYRgA7M1x4Kounvy5XUBEmEeXRbSNbI3n3KxjLm5yVR9fmF+N+CCx8S3IN+XDOfegWR1p0ZEQ7OVvZa4nEO8h/7KcFTQK33OGr4OiMPzYZsEg+HfnlpwT/qQ1BmP7I4jy56JxNbBbGdtzUKG/D0WSo9Qxu5sHEUf1TdZAUEIS8lh1fSNDNuVa4LefYr2ZLCluczm9+BHNnxzFzpCpFzXObTs7j4RGdmJrZqD79hCzh9cgZc2V1y0Uh6gLm3XFxwlWUSKOp7fdKNM/A1o7m1YXI59p1fRvSdtkZsao7Dj93F++povvtIGpbqOQOQIyFi0d4VlMq/OIHNTa1wNYozcP+0e2bE7wQ/jbWsuerbgIThYeJdJ8vmpQGLxBcSstoIp0BWlS69Fqcw6vS+WlOPrhciewc2O0XjJ/wO2BJSL0m52ls9ZyP3pvGE8KxCvTgQglbyQ4UQzkg4HLDGuvEi5vNRqZkTK+P3x4dqx9H/U98Q2BhSsA96y0A7/SVWY23Ln9sZsXyvHR4xmGxTl5BT2bnj+RlZ208EmzjKU6NmpGqx6CzJEg2erEUWhi83/eQiiJsg+CvVI5JFvZ7jj/6CSR4ugwZHYmtbLXnORwdSQd98YXrj6RAsG7WGw/mOi+/BeG+HY7G4WpGn9kE/aAoDO5l1CMbwW2a1OKTZxOMB0wE8UlkKnVhp0XgGZ9i4UeKbzSvndtqWmG12DwIMqv9NutvVUjoc5tjWhtasgcWMTXaJQAEsot1I8zL4duH20KyywMbeOK/6OqLU4a5ANcwr1zJM6VGohEMlLG4PQo5XyUqyCpRqrgvknfEmx4lIcAujoIw9VjCuXmoEU5aULngHxJNu9bZnYHdY2y6klMeWYxiiDpSgIWicU5MmJbGsQI5DK22/bg2NAxUP0Q+VQu152ODeGZRFbaDksvXIg8Zk8peZ2IMmF4XwXAMYLanB5DliDV3nhfMqrKFNXUDYpPRo/QeOw1C/E1i4m8E5lVyK1SC7Xx7JPBkyiKqNB9xySeqDq9uji0jmrmQYJsOFNYuPssatc4GjztXGh78LxpgkSwnxCLCUZ8nwbb9GqL71+aEG6DZkc9lQxWe+ilgbb5GswaRD4Q41zhUWCkt/h8SE4/dLJCt5mvGVN88F72qMWRdPnVyfEJYO+QP8QJ9olGAZkRnxPYSjLuSGiMDS/LTApmQONogHQCEObW1JINix69kETpyC8bhSAwkyumnLF/V6L3XDsD9bSC907n8f6Ou39BJAgRppH0S8p6ZKUg4O8BDOPFCZ8UN/ry9H/Y6TDcMQvloCaTv6jHmaJtzdXaIH4oVF+WvFHYkP0Le16ED8sm4ee/4t3wl0I0GzSiGxvGWH/bkB4rEIJIFMDfuVtcDFlh2O9JU2iMgG+LLo4TY3OmjxBqMmf4GDUJiAe/mNdpmOlyB4Eq+kQ2V2LTYqrDSiNDrFiCRZaK/6mLcJTb5L3XdY3KiIgabJqc8aJrSUcirHS82+AVXop4eh8ZdLkfWG1xRm/C9OZoH5Bc14SAJhEvxBAlyETvz1mDfHzmQBEbhMio03OYCBIfMFTWnhx/6xSuNh39wX98KuxzwlLqiFZA2I0MjO4ZOcWTPIgXzAWcwKyTIR3tZrdJJSL5q5dg9fr1jRiIe9zy+UwrijFG4jpR0SQJPbE7sUusgDYFTbJzQ1fXwanl57UqzD0WAUSWQe+rVGdfmFxThpzzKEnqJCNQ3qR+JbKXfrviSwgSVKDxviCyrnLQTVT+9lF9nAe4Q1XGAKunuEJiI5bv/uCNqAYJtfv1APXL3mYj5Mn9nWpfoty/Uo0EE+zwXjkN6QY4G1O2gLM281e4fc2E7Vy1EFX7kFfuAr/bj2aaQeAcNUhzpNuLO4sve6Ory27kOZ3Nj1Zxph7pOVpfTPhrlrO857YRwvp+vrPS1tH7qk+lBzkJRDLcB/5xZXihAfF30GnFqo7goNd+Gapo+zf9Sxwj2QhPaLJ/S4amAueF50ZF6Cr76vZx2WrmXjkMa78W6sFUZ5KMLZTdeE19YtiSAO4nwoFBpXipGxyH3Ht6gmsfexmUTOR7DHUWFR/KfVhrblWiCXQqvXpdXSD8Al4zp3EucpqOzNOxlYFYECPKz7T4m3uqExdkfnhbswEFb62++8wEH9PpVC9zz8qZCEBHp2ZwJBoXPn76gmvZ79lTXjHHDLMEp3vZGlHNtS0t4gDGEqhE2S8AE2ip6JYbQzHA789t7d3DP9Ok7OG5i3tLGHAIWCISeTjwfdmpoh5qXsME2A1cObYP43Lo6CvEiR7C++L6pExKecF+M25dcb7HFsSk0Snm72gfgY2Uax3LWRbyhcgtETeksf5wlEHaW3yKj73xtWgYRmPBGrk1Sx2UNfMom4PU+DhUYePKUP+K8ljQ737joHC52cKDpnYMvPf3xgzHYqiyQb3RufKhBBjYHtGpQtBlDYwkyBep7oHsUkoO3HM5V//huDyGiuYLo0E2bzSmDnPVixEr8tACTs60tAaATBuPdDz5A0pIZDaps92vdapuFUKWcUFYsTdiQFVwhiLqrzCCE/ulYC+w2KInhelRE5DIUgbwyuLTkdUA0BH+Hb6GjdmqBgqxUbPhOjJTjCaLL4pyK5RsIox5WnpI3OruZwE2kZmlmRynteGB+pcyG+VOjvVSRs1/ipEuJkmwQ6QL9s39YnbFQ4R7SFyg4Mmvvm5yP1vofG80d3gCr2utSghAPJpgws9aami9YUXYXMzZLViyjVeMPfJhX5s8KFDMjLfAYNYhBDe0rEC4oim6EssTRUm55LTyh9hQQK+iTbJFTCcNr60ScrhdLrNBrQufKhFbWD7Bz40i7b9jRqYqVjletwkM4S1l/YLXAq9QTGL27WayQGIw/s2laLMvZWdDzx4KzY0pxoHglUyy3jfLIfqLi6Cu83KskTOrZ8CyoFHvSV4cWLKoAQxeynj132vNX8IlHrTqs5Rw8j2yhGffIryFjiL7ZlwNaHmq1U7rLnm+wFcPg/0WDJ33Htpbqk4VOXluKlx1J/6H3TsmdS1fTuYuy6rMAuajVZ81TNEoLbumQgUvvaseB/mNBZGDdIcej0s6nqy7OcPr37isRIXT93Ij2nE/CpxstsrTKAA5WrqjQXMG9HWYGLkp71VNAFP4Fiom6EeL9NKL6waMGbUv2zkcNBUTxDUx/U6JrQYEXFk2gmypqBpeNX8ovgCRuau+hPUI6BrNTYvTJinfsfTs+9SImWiKE8M6PeTMxIDbRrSB0GEBpMhaY9XDSBLtSHv8LJkeA0zWKqasTiVJF0aexWKR7mEzTEp1Eq1rGGuS4Lbuexezmuy+DCzAKtZzrsUIubePTZ3vKHlay5TlxONCkN1MFqbvzWLJ6lRB4LSKzyYxhhUjanjxTWnIOKVagYwgK7Y3H8CkoXPQ12e4AStp4/KBzpoUcMOLicbXSyxjIL7fJUFm+Z1/3xsTO3Nf/QLPMWC9dEwtSsJjUMcSX7DDrMxAhcGWKTqNPK27MkE91I5pJ3q9M0YTakuCv2UmvgSBcv0wqbqR7jVkz1Bm/Ob3moNQvdp4P5nRZTiadINasnGbKDolJPjUhoH6Y9dRNM959PdCx7w2S11MaD2HXcmvA97Lf3e+P4XzrxOZxkbeuB2uiyEetA/xiWchxuDH7ndJvM11bmicIvu1/rLFeeQ6WhIK5GxJP6llAkF5tHEX4eHbwg0cKkpogBL8MxIMU6hwTsT43p2k5pAE4eW6++X2+c9MV8BCREKI0xQb5GQZSB841SnuEhTYHCxp49F3A/bjIckIFuNlCGvuo7h1F7bMaNilD9W2TSEFIuWniSoST/aysY2NogE6tcsFt4F2tv3fvdLIwoEyoO0MSvIpGtR3KYPumnnlmbk0tGzR86XDly/aav3bZMV8SnaEEmuqQFsQuqc68QuUj62pvw5+IQ9iPOI9L6fVE0JWtuCnDB1mFe4AbfBc0hqv0Rg9hcPYeGp27l3JpcPz6NdERzMfDf+toIv4IjgqEa0cAH/MlSxcofccO82zYiK9JwNcU8RpjAVAN2whIvnjRnptxGtAnQ/fmQShBRiaFggwbZvHNjXg30oJHfuWv4TICnj2BnveHj74N2FgjKcei7FPx+tgl80a0m0fr6YP5A69eSS9K6mcBLmsFBVxtF+RCEBOJ3yi8bjIJLnpuhedwyAgCbh3zAOSEJKL2cHiRY+GBRhriPvSxjclVHyNxlI6YyFi8lkSH11/fryS/dwOC6HUFbukhASKaa/DJpEPt7hXwehvH7nAcemSnXaueWxQAWfbhmzchRt350ra8UHTztEpRROWJJymnh+UYAd1GMnZTW5qYodQWDjriJg8CkLyBkECNzes4bXbR1tyz6cE78XqnehSKEBp9QvsXR7m2BPxDpeWTbgNIwJ/CWJCQ31JTcT+zcPCk53jCPVhqqljUMsxsEzHEy3zuVIHKptjOvXOtVc6bgOKEoEfyqnL6eWz/TisNwRHIh2PKAGVrB/EkARRuoIymTAfDHIymQ9ax7KgjUXp7ubXyzWzYriQt5jOj0/lqfcHcS4roEeUPglaYHrILn2Zan3AEOEEiu/O/K3nG/+eehpuEU+QJKT53CW91mUga+bW/dQKdb2Q1WjC9gqnf1x1OFG+faOIxXghlAipQByz4sFEcM03JLgiX+68/7St8mwbIu5NDm+f6gEnfTNsTDS99YREwpCW2Ms/Ro/cDwCWtzHQ5oWEMprBrOZAA7vI4+quoz9DL0FjX0h47+503+gE1VI0oKW6YMsiI291GzPoeJbs6cHUscMR2pJ7eJQT/U43VKKMnNo0uRLwwYeG6cCHp32eJFHLk4BosqG1X1sACQalO4P3oksKVtmVK51i4CNXZNR2hylAybkdBitZsUZLp4vVQU7zJ8tmxPyhqWvVlsnnl5Ql8S/rNArlA7xuZA9d9IOvnnAv+1qHqCjEIyLvgD87qi47nYQr+QpgGDSoLnvoyrvbS+MdtFhrZAt56pTBBunsJFUBiAfpff7rGq7WmQNwmKw6dNSo642tpjKziVLNkoEhLBMPXnxYQV+9IfBj0/kTbAAdtzjr2Zcac3wkV7epgjrmu+6kx4gSIaYHitUOJisBNqScuxVARjktOuYmiUgv65GIWO3qG1Wh/FgzexF6Lbe3cwsObr22T+rK6q9JJD5Je8uNVSMOnFRefZg6GWOP0tCjEKW6/pBkJdfeA/1i2s0q3rCgH8Xy/tFJ5bZDy/47BYTW0JG8/Os6TzXwcJ/XoDzOQ/WfbWRyG9XgkRCD6iSJlYgVgGGnp+iSmXqFfS2K1KLrcjNZitYSEwe6kH9KfOcBekesHPCtDhqo407qWovUAyXfvD22aMSWXJ0JKSduaHWyMHc6nBfmcO8aLcpc1vyaUKlkj+IxBU7pdtkSzfTpPo5T/Cuy+8TUPsAq1ujMAPcye//PLcZR30PCEeyu0rzf7DZEzmJFMFIp/tYNjcFwEqLriIuQpTo3QIAhzTDJmdy+UZQG8/n6BB/pRw+ZoiQsy2vQxwvnQS0NKLbJGlnf3RJD9R9s6kp5Xk+hRemSipt3HapxQIThiXmjdVOc0xQGeS2Nvd1FhchC9FCjNmP+xmLQLNvgJJu97WadY4lWcs8rfedorkKKKv0zYzXqGZW2vGcK0Sa/z59nDXWwAUfXvs7re4wZ60k7PCRHt+55Sl4XcHeb+sPA/dPKgNTgtRXWw84IOvGV9kouyzkbY0bUALWdkNrHVfJaN5buFK2c/O/QijvGGxxdwV0yqNnRU8hy59IHMTAV+R4zhweqZ+a2haVe97gvnJl8b6oR3J7ipjJFetJI0ZnzKtipA+zQGm2yQaashNnrMrlcW5xZM8bkxELIv9K5JWuikDDukVSGjyjAwxgPETTqAVxSV1SR093IuTIFsJvGkKaxHGDeOrgKQ5f6XUmHk4Uuhga2hlxmShvyl58AeUslp61DDXGCoTvNnEzll86J9qEgms1X0V8QwI6lr+sb8Xuv1hdKNHeZkO5cHsyKEY7qciv1XH6DC/4Gouy2neOKpCT9RKaCNEXH2CDvFLWkPXyksq5OT4bvPmsvrI/mfZDxL7Y6A3WegHaTF6tgrVBycKfEgM5nN+yXLYq374KyRMqv2CuuBgpKh1FlfOqW/PFsaZlMLEcdp/SjYujioivtzJpPSubLICDcFCN5RB8sjRB0gCcJXODmJ6vfqSb88CMMASNQvYaZGtKj9rIFLvRy5lABD9JV/eEPe8cOi0nDJemkxeppuwL1Lev5Aukgridkom0E4RpWXaVygv5s91koyTjdLnat7OrBQr2WvA1nXczs3+CNnSSLkyRMWvXfLz+7OcORFRaPi1YRLpsY4snYtuxyiwRk4aCfbvnXq2kUa7H0kzTmrUrN1FXbv5vBSvnBB04oPc+eH/K703zQq1FvFUSuM1lYG2XacdJa/nJp7fp6+j550ESR2ixWwTQ0D6m2S2eVYZzgrFnUmCnydmFeoi0mebCA9GYZIPlHesRqp5N4iU9/6LiiQ89tzmkN7PQLXgOUMf+zWzIbZpM97Xxmr1jVmPuZX+a8OEzKhNp9cXCRwcqivX1QfK0mrX/rzqp2nATsdXeIS4b+Qmmv9VHlBg0Nqw8F5j64T/EmSWUBRx0HWrQJpoyR/q9jyRaWeVbOThKThab0OTil089swCSkHq7XX4qqbn1jk0PlYMUVriggTITOnY7iq585gt/A9zlNL0ZaBFl5jhHSJyUIyb8sVQZntCuwv5PHball1P9Ick5cFBgaJJZkOw8UPZOcIWx+mk5DOWuhlNjhNgx6+dpfcJc9bizQnqbGmqqJbKBoqQuUlLu32+IFbpVtoimMz1oxmF+gilVmQNQNY7efHSRZY0sJiGBqAsQ/E035A9ERvSDnmoRBy1+LrOh8IJRiTLGtx0Q6sTbnVCAv7Old0Ngk9jYbjKoU429k28K3fXb2jTTWCtxXS0GAcK24X+I5KSZQlNW98W/BHVwy0j2P8ZR7VZvIAajTkBDnuwzVDP9RJCThIm7AdaH2qSBeQcdj6oiYlR6oWAtarJvbuQrvqG/M7hLBnOeyEM16zGni8gzsxhWvFa8QBf54W/vYSStamB2Vf94nXGtPtA1oovbTjQt7+0VZgB2suj1nEX0qOvld6TkrSYeEWL5luMklQzpuzTQW+d8VhPPALgb0YQT2SFfearYRFAH6S1BVDFmkWHoIurPe2ydn0Z9w2KUddLWHO8A7R2nwC1ugpIpZrxjMtlylgRoq2cGt0F4dOk69ReXtPAM5VgDyPn/N8YSeott39G3lMxomLkfqrmaoWHxi9uuyJIZAzdCvq2wpNTsrcavn5BM0BJ0atBc+oZ6QgD6gIC1eJ6ROCQynIhU+wVjovozzc1f23Dbcjfw1VwNxgmItewVV0nwuGaJXt1zGXRSaoKyAVncBpfv2gVgeh47iAtEmQ5S8nFG9riRi/0sqHF6WeTI+++SCtProvZzXlyoFx2vW9mxKPnYD77tbpFiBrcSzla5CljW+XuuCm78gSiP5nhutWtMaUPSuSQ5JETDnr24u2TfxLRvB4QQSxg7ov1vGhoHYl+0YKvhWKY2HFk7gVFiHiy0W5mjo3Yt9Jnp8FSNpt1Sqayh9l0v6EgYFPc8eAsFxWL3ufEwkDbvFzvFfwK+1swYqhcLTE+AHLnChOlz7UA8LBBVrlUoff5xR2ov8NDUjgIK+4AYWibLdciYzIFW72k4976uc576qLUqypSztyxkg/pyuJaN2ti5se6bCHgAT0ji0yg/wLFOzCItLOm19Yfq1E1Zi/L7tlGc/zUFD89p8lyP/cwZ0rfzx9KqcmZre+3gf+pKHttX3I9BoIF9mchirzeW9HWnb8VxdCe5+wlI7Ts9HoFgcnQk3/Ae5WGEJkzSQQqyvFIPtn28+DvZrc3vKqO2dPi8KO4rVd/QOW9ShvJAxzmUWaH7YRIGuX/Y47/uokHijE8lDcgx9WTh/45u300ZZP9WFuXB5O8z5Gl/CBgjA7z2ykjIWbJgrkAnG1YojNVRbN5qwSamuD8fX2aQBHMf8DTQeIbnrz8gFj5dvCOabo9mjxcrXA/8rxj2pJ/PgdFAIuV2y9ZEjDYLIRS09Ez6RwrMhX6yQFIW2AbvDvK9eiPzawFpA41b3T2ur8FZRzFTW4ZN36mcW+PHzALeEqWTOvwueHLdrwQlh47sH9HCySuE0MasQipCsHUXhc+/IE4csODBiUra+xWjWpBlMMnvFep80hvpb1flGuD3ePTnaX0dZ/LS8G3XGHlvGLepfD8iVNUknjaIL69TRsi01+nIFLu/SrXFCwQe2da6upzdPFY6OLFHP/gQ/4T/7s5rMaK/+OdCxUqFHCL9ujhN/2lsP9XOBM2zxix8xwfNs/HedB4mDBQTkWXoVyCzJMosUv5Y4hE2pWmNtwcoD/OWdytAZcgUzhJeuoRGvudRz5eOeYPC2ZftyM73zaEgISTHC9q0/ybMNLmyolRcmXpdqxJ4Wwi1LWt01E0DNGoztgVrhoJ5hmk7CLXMx+Lw7E7bRN0HinJRqnG9p+f/T7VNSF97R+CbN0KW+gQL5C6SEc3KgXbafFdGUGy97km6sHwdXT4indg2blw9bftrYKLhcRKPSCuiV60ntrM1MR2MMHronHGx7x4XUXEe1O3y+FytRiQigv";
  const encryptedBytes = Uint8Array.from(atob(ENCRYPTED_BASE64), c => c.charCodeAt(0));
  const iv = encryptedBytes.slice(0, 12);
  const ciphertext = encryptedBytes.slice(12);

  const encoder = new TextEncoder();
  const keyData = encoder.encode(keyText);
  const key = await crypto.subtle.importKey(
    "raw",
    keyData,
    { name: "AES-GCM" },
    false,
    ["decrypt"]
  );

  const decryptedBuffer = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv },
    key,
    ciphertext
  );

  return new TextDecoder().decode(decryptedBuffer);
}

function getSetting(settings: ISettingRegistry.ISettings, key: string, default_value: string): string {
  try {
    const value = settings.get(key).composite;
    return typeof value === 'string' ? value : '';
  } catch (err) {
    console.warn(`Error reading setting "${key}":`, err);
    return default_value;
  }
}

function htmlTableToMarkdown(html: string): string {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    const table = doc.querySelector("table");
    if (!table) {
        throw new Error("No <table> found in HTML");
    }

    const rows = Array.from(table.querySelectorAll("tr"));
    const extractText = (el: Element) =>
        el.textContent?.trim().replace(/\s+/g, " ") ?? "";

    const mdRows = rows.map(row => {
        const cells = Array.from(row.children).map(extractText);
        return `| ${cells.join(" | ")} |`;
    });

    const firstRow = rows[0];
    const hasHeader = firstRow.querySelector("th") !== null;

    if (hasHeader) {
        const headerCellCount = firstRow.children.length;
        const separator = `| ${Array(headerCellCount).fill("---").join(" | ")} |`;
        mdRows.splice(1, 0, separator);
    }

    return mdRows.join("\n");
}

const plugin: JupyterFrontEndPlugin<void> = {
  id: 'm269-25j-marking-tool:plugin',
  description: 'A tutor marking tool for M269 in the 25J presentation',
  autoStart: true,
  requires: [ICommandPalette, INotebookTracker, ISettingRegistry, IDocumentManager, IMainMenu as any],
  activate: async (
    app: JupyterFrontEnd,
    palette: ICommandPalette,
    notebookTracker: INotebookTracker,
    settingRegistry: ISettingRegistry,
    docManager: IDocumentManager,
    mainMenu: IMainMenu
  ) => {
    console.log('JupyterLab extension m269-25j-marking-tool is activated! hurrah');
    console.log('Loading settings registry');
    const settings = await settingRegistry.load('m269-25j-marking-tool:plugin');
    console.log('Loading colours');
    const answer_colour = getSetting(settings,'answer_colour','rgb(255, 255, 204)');
    const feedback_colour = getSetting(settings,'feedback_colour','rgb(93, 163, 243)');
    const tutor_colour = getSetting(settings,'tutor_colour','rgb(249, 142, 142)');
    console.log('Answers: '+answer_colour);
    console.log('Feedback: '+feedback_colour);
    console.log('Tutor: '+tutor_colour);
    // Inject custom styles
    const style = document.createElement('style');
    /*style.textContent = `
      .m269-answer {
        background-color:rgb(255, 255, 204) !important;
      }
      .m269-feedback {
        background-color:rgb(93, 163, 243) !important;
      }
      .m269-tutor {
        background-color: rgb(249, 142, 142) !important;
      }
    `;*/
    style.textContent = `
      .m269-answer {
        background-color:`+answer_colour+` !important;
      }
      .m269-feedback {
        background-color:`+feedback_colour+` !important;
      }
      .m269-tutor {
        background-color: `+tutor_colour+` !important;
      }
    `;
    document.head.appendChild(style);

    // Prep command
    app.commands.addCommand(prep_command, {
      label: 'M269 Prep for Marking',
      caption: 'M269 Prep for Marking',
      execute: async (args: any) => {
        const currentWidget = app.shell.currentWidget;
        if (currentWidget instanceof NotebookPanel) {
          const notebook = currentWidget.content;
          const metadata = currentWidget?.context?.model?.metadata;
          //console.log('metadata');
          //console.log(metadata);
          //xonsole.log(metadata["TMANUMBER"]);
          if (!metadata) {
            console.error('Notebook metadata is undefined');
            return;
          }
          if (metadata["TMANUMBER"] != 1 && metadata["TMANUMBER"] != 2 && metadata["TMANUMBER"] != 3) {
            alert("Could not identify TMA number.");
            return;
          }
          if (metadata["TMAPRES"] != "25J") {
            alert("This tool is only for presentation 25J. This TMA not identifiable as a 25J assessment.");
            return;
          }
          // Duplicate the file
          const oldName = currentWidget.context.path;
          const newName = oldName.replace(/\.ipynb$/, '-UNMARKED.ipynb');
          await app.serviceManager.contents.copy(oldName, newName);
          //console.log('Notebook copied successfully:', newName);
          // Insert initial code cell
          notebook.activeCellIndex = 0;
          notebook.activate();
          await app.commands.execute('notebook:insert-cell-above');
          const cell = notebook.activeCell;
          //console.log("Getting TMA number");
          if (cell && cell.model.type === 'code') {
            let question_marks = "";
            if (metadata["TMANUMBER"] == 1) {
              question_marks = question_marks_tma01;
            } else if (metadata["TMANUMBER"] == 2) {
              question_marks = question_marks_tma02;
            } else if (metadata["TMANUMBER"] == 3) {
              question_marks = question_marks_tma03;
            } else {
              alert("TMA Not identified from metadata");
              return;
            }
            (cell as CodeCell).model.sharedModel.setSource(`${initial_code_cell_pt1}\n\n${question_marks}\n\n${initial_code_cell_pt2}`);
            cell.model.setMetadata('CELLTYPE','MARKCODE');
            await app.commands.execute('notebook:run-cell');
            if (cell) {
              cell.inputHidden = true;
            }
          }
          //console.log("inserting marking forms");
          // Insert marking cell after every cell with metadata "QUESTION"
          for (let i = 0; i < notebook.widgets.length; i++) {
            //console.log(i);
            const currentCell = notebook.widgets[i];
            const meta = currentCell.model.metadata as any;
            const celltype = meta['CELLTYPE'];
            //console.log(celltype);
            const questionValue = meta['QUESTION'];
            //console.log(questionValue);
            if (celltype == 'TMACODE') {
              notebook.activeCellIndex = i;
              await app.commands.execute('notebook:run-cell');
            }
            if (questionValue !== undefined) {
              notebook.activeCellIndex = i;
              await app.commands.execute('notebook:insert-cell-below');
              let insertedCell = notebook.activeCell;
              if (insertedCell && insertedCell.model.type === 'code') {
                (insertedCell as CodeCell).model.sharedModel.setSource(`# Marking Form
generate_radio_buttons(${JSON.stringify(questionValue)})`);
                insertedCell.model.setMetadata('CELLTYPE','MARKCODE');
              }
              await app.commands.execute('notebook:run-cell');
              i++; // Skip over inserted cell to avoid infinite loop
              
              notebook.activeCellIndex = i;
              await app.commands.execute('notebook:insert-cell-below');
              await app.commands.execute('notebook:change-cell-to-markdown');
              insertedCell = notebook.activeCell;
              if (insertedCell && insertedCell.model.type === 'markdown') {
                //console.log('markdown cell being metadatad');
                (insertedCell as CodeCell).model.sharedModel.setSource(`Feedback:`);
                insertedCell.model.setMetadata('CELLTYPE','FEEDBACK');
              } else {
                //console.log('markdown cell cannot be metadatad');
              }
              await app.commands.execute('notebook:run-cell');
              i++; // Skip over inserted cell to avoid infinite loop
            }
          }
          // Insert final code cell at bottom
          //await app.commands.execute('notebook:activate-next-cell');
          notebook.activeCellIndex = notebook.widgets.length -1;

          //console.log('Inserting final cell');
          await app.commands.execute('notebook:insert-cell-below');
          //console.log('Getting final cell');
          const finalCell = notebook.widgets[notebook.widgets.length - 1];
          //console.log(finalCell);
          if (finalCell) {
            //console.log('Got final cell');
            //console.log(finalCell.model.type);
          } else {
            //console.log('Not got final cell');
          }
          if (finalCell && finalCell.model.type === 'code') {
            //console.log('got and it is code');
            (finalCell as CodeCell).model.sharedModel.setSource(`create_summary_table()`);
            finalCell.model.setMetadata('CELLTYPE','MARKCODE');

          } else {
            //console.log('could not get or not code');
          }
          //console.log('activating');
          await app.commands.execute('notebook:run-cell');
          // Automatically run the colourise command after prep
          await app.commands.execute(colourise_command);
          // Automatically run AL Tests after colourise
          await app.commands.execute(al_tests_command);
          //console.log('done');
        }
      }
    });
    // End prep command

    // Finish command
    app.commands.addCommand(finish_marking, {
      label: 'M269 Finish Marking',
      caption: 'M269 Finish Marking',
      execute: async (args: any) => {
        let currentWidget = app.shell.currentWidget;
        if (currentWidget instanceof NotebookPanel) {
          let context = docManager.contextForWidget(currentWidget);
          if (!context) {
            console.warn("Not a document widget");
            return;
          }
          // Run colourise on original notebook first to ensure all MARKCODE cells have fresh outputs
          await app.commands.execute(colourise_command);
          await context.save();
          const content = await context.model.toJSON();

          const oldPath = context.path;
          const newPath = oldPath.replace(/\.ipynb$/, '') + '-MARKED.ipynb';

          await docManager.services.contents.save(newPath, {
            type: 'notebook',
            format: 'json',
            content
          });

          await app.commands.execute('docmanager:open', { path: newPath });
          console.log('Regetting notebook.')
          // Wait until the widget tracker registers the new path
          let widget: NotebookPanel | null = null;
          for (let i = 0; i < 50; i++) {   // retry ~50 times over 1s
            widget = docManager.findWidget(newPath, 'Notebook') as NotebookPanel;
            //console.log(i);
            if (widget) break;
            await new Promise(r => setTimeout(r, 20));
          }

          widget = docManager.findWidget(newPath, 'Notebook') as NotebookPanel;
          if (!widget) {
            console.error('Could not find new widget. Exiting.');
            return;
          }

          await widget.context.ready;

          // Start kernel automatically using the same kernelspec as the original
          const kernelName = (widget.context.model?.metadata?.kernelspec as any)?.name || 'python3';
          await widget.context.sessionContext.changeKernel({ name: kernelName });

          // Focus the -MARKED notebook so notebook:run-cell targets it
          app.shell.activateById(widget.id);

          currentWidget = widget

          //currentWidget = app.shell.currentWidget;

          if (currentWidget instanceof NotebookPanel) {
            context = docManager.contextForWidget(currentWidget);
          } else {
            console.log('Could not get new context');
            return;
          }
          
          const notebook = currentWidget.content;
          const metadata = currentWidget?.context?.model?.metadata;
          console.log('Checking metadata');
          console.log(metadata);
          //console.log(metadata["TMANUMBER"]);
          if (!metadata) {
            console.error('Notebook metadata is undefined');
            return;
          }
          if (metadata["TMANUMBER"] != 1 && metadata["TMANUMBER"] != 2 && metadata["TMANUMBER"] != 3) {
            alert("Could not identify TMA number.");
            return;
          }
          if (metadata["TMAPRES"] != "25J") {
            alert("This tool is only for presentation 25J. This TMA not identifiable as a 25J assessment.");
            return;
          }
          console.log("-- Running mark code cells --");
          // Run mark code cells
          for (let i = 0; i < notebook.widgets.length; i++) {
              const currentCell = notebook.widgets[i];
              const meta = currentCell.model.metadata as any;
              const celltype = meta['CELLTYPE'];
            // console.log(celltype);
              if (celltype === "MARKCODE") {
                notebook.activeCellIndex = i;
                await NotebookActions.run(notebook, widget.context.sessionContext);
              }
          }
          console.log("-- Querying kernel for awarded grades --");
          // Get all awarded grades from kernel as JSON (question_marks is in kernel memory after forward pass)
          let marksData: Record<string, string | null> = {};
          const kernel = widget.context.sessionContext.session?.kernel;
          if (kernel) {
            const future = kernel.requestExecute({
              code: 'import json; print(json.dumps({k: v.get("awarded") for k, v in question_marks.items()}))'
            });
            await new Promise<void>(resolve => {
              future.onIOPub = (msg: any) => {
                if (msg.header.msg_type === 'stream' && msg.content.name === 'stdout') {
                  try { marksData = JSON.parse(msg.content.text.trim()); } catch (e) { console.error('Failed to parse marks JSON:', e); }
                }
              };
              future.done.then(() => resolve());
            });
          }
          console.log("marksData:", marksData);

          console.log("-- Removing all marking cells --");
          // Remove all marking cells
          for (let i = notebook.widgets.length-1; i >= 0;  i--) {
              const currentCell = notebook.widgets[i];
              const meta = currentCell.model.metadata as any;
              const celltype = meta['CELLTYPE'];
              if (celltype === "MARKCODE") {
                notebook.activeCellIndex = i;
                if (notebook.activeCell instanceof CodeCell) {
                  const cellSrc = (notebook.activeCell as CodeCell).model.sharedModel.getSource();
                  const outputs = notebook.activeCell.model.outputs;
                  let html = null;
                  for (let j = 0; j < outputs.length; j++) {
                    const out = outputs.get(j);
                    const htmlVal = (out as any).data?.['text/html'];
                    if (Array.isArray(htmlVal)) { html = htmlVal.join(''); }
                    else if (typeof htmlVal === 'string') { html = htmlVal; }
                  }
                  // Look up grade by question ID extracted from cell source
                  const qidMatch = cellSrc.match(/generate_radio_buttons\(['"]([^'"]+)['"]\)/);
                  const questionId = qidMatch ? qidMatch[1] : null;
                  const grade = questionId ? (marksData[questionId] ?? null) : null;
                  console.log(`MARKCODE cell qid:${questionId} → grade: ${grade}, hasHtml: ${html !== null}`);
                  if (grade != null) {
                    NotebookActions.changeCellType(notebook, 'markdown');
                    const updated = notebook.activeCell as unknown as MarkdownCell | null;
                    if (updated) {
                      (updated as any).model.sharedModel.setSource("Grade awarded: " + grade);
                    }
                  } else if (html != null) {
                    NotebookActions.changeCellType(notebook, 'markdown');
                    const updated = notebook.activeCell as unknown as MarkdownCell | null;
                    if (updated) {
                      try {
                        (updated as any).model.sharedModel.setSource(htmlTableToMarkdown(html));
                      } catch (e) {
                        console.error('htmlTableToMarkdown failed:', e);
                        (updated as any).model.sharedModel.setSource(html);
                      }
                    }
                  } else {
                    notebook.model?.sharedModel.deleteCell(i);
                  }
                }
              } else {
                // al_tests.py
                if (i == 0) {
                  notebook.activeCellIndex = i;
                  if (notebook.activeCell instanceof CodeCell) {
                    let existing = (currentCell as CodeCell).model.sharedModel.getSource();
                    if (existing.endsWith('al_tests.py')) {
                        notebook.model?.sharedModel.deleteCell(i);
                    }
                  }
                }
              }
          }
          await app.commands.execute(colourise_command);
          NotebookActions.renderAllMarkdown(notebook);
          await widget.context.save();
          alert('MARKED file complete. This TMA can be returned.');
        }
      }
    });
    // End finish command

    // Colourise command
    app.commands.addCommand(colourise_command, {
      label: 'M269 Colourise',
      caption: 'M269 Colourise',
      execute: async (args: any) => {
        const currentWidget = app.shell.currentWidget;
        if (currentWidget instanceof NotebookPanel) {
          const notebook = currentWidget.content;
          //console.log('Colourising cells');
          for (let i = 0; i < notebook.widgets.length; i++) {
            //console.log(i);
            const currentCell = notebook.widgets[i];
            const meta = currentCell.model.metadata as any;
            const celltype = meta['CELLTYPE'];
            //console.log(celltype);
            if (celltype === 'ANSWER') {
              currentCell.addClass('m269-answer');
            } else if (celltype === "FEEDBACK") {
              currentCell.addClass('m269-feedback');
              if (currentCell.model.type === 'code') {
                notebook.activeCellIndex = i;
                await app.commands.execute('notebook:run-cell');
              }
            } else if (celltype === "MARKCODE") {
              currentCell.addClass('m269-feedback');
              if (currentCell.model.type === 'code') {
                notebook.activeCellIndex = i;
                await app.commands.execute('notebook:run-cell');
              }
            } else if (celltype === "SOLUTION" || celltype === "SECREF" || celltype === "GRADING") {
              currentCell.addClass('m269-tutor');
            }
          }
        }
      }
    });
    // End colourise command

    // Prep-for-students command
    app.commands.addCommand(prep_for_students, {
      label: 'M269 Prep for Student (MT)',
      caption: 'M269 Prep for Student (MT)',
      execute: async (args: any) => {
        const currentWidget = app.shell.currentWidget;
        if (currentWidget instanceof NotebookPanel) {
          // Duplicate the file
          const oldName = currentWidget.context.path;
          const masterName = oldName;
          //const newName = oldName.replace(/-Master(?=\.ipynb$)/, "");
          const newName = oldName
            .replace(/-Master(?=\.ipynb$)/, "")
            .replace(/(?=\.ipynb$)/, "-STUDENT");

          await currentWidget.context.save();

          await app.serviceManager.contents.rename(oldName, newName);

          await currentWidget.close();
          
          const newWidget = await app.commands.execute('docmanager:open', {
            path: newName,
            factory: 'Notebook'
          });

          if (newWidget && 'context' in newWidget) {
            await (newWidget as NotebookPanel).context.ready;
          }
          
          await app.serviceManager.contents.copy(newName, masterName);
          
          console.log('Notebook copied successfully:', newName);
          // Iterate backwards over the cells
          const notebook = newWidget.content;
          for (let i = notebook.widgets.length - 1; i >= 0; i--) {
            const cell = notebook.widgets[i];
            const meta = cell.model.metadata as any;
            const celltype = meta['CELLTYPE'];
            // Do something with each cell
            console.log(`Cell ${i} type: ${cell.model.type} - ${celltype}`);
            if (celltype == 'SECREF' || celltype == 'SOLUTION' || celltype == 'GRADING') {
              notebook.activeCellIndex = i;
              await app.commands.execute('notebook:delete-cell');
              console.log('... deleted.');
            }
          }
        }
      }
    });

    async function ensurePopupsAllowed(): Promise<boolean> {
      // 1) Try to open a harmless placeholder immediately (sync).
      // If it returns null, the browser blocked it.
      const testWin = window.open('about:blank', '_blank');

      if (!testWin) {
        // 2) Build site/origin string for instructions
        //const baseUrl = PageConfig.getBaseUrl();          // e.g. "/user/olih/lab"
        const origin  = window.location.origin;           // e.g. "https://yourhub.example.org"
        //const site    = `${origin}${baseUrl}`.replace(/\/lab\/?$/, ''); // hub root-ish

        const body = document.createElement('div');
        body.innerHTML = `
          <p><b>Pop-ups are blocked</b> for <code>${origin}</code>. To open multiple notebooks automatically, please allow pop-ups for this site, then click <b>Try again</b>.</p>
          <details open>
            <summary><b>How to allow pop-ups</b></summary>
            <ul style="margin-top:0.5em">
              <li><b>Check your address bar:</b> There may be an option to whitelist popups.</li>
              <li><b>Chrome / Edge (Chromium):</b> Click the icon to left of address bar → <i>Site settings</i> → set <i>Pop-ups and redirects</i> to <b>Allow</b> for <code>${origin}</code>. Then close the tab to return.</li>
              <li><b>Firefox:</b> Preferences → <i>Privacy &amp; Security</i> → <i>Permissions</i> → uncheck <i>Block pop-up windows</i> or add an exception for <code>${origin}</code>.</li>
              <li><b>Safari (macOS):</b> Safari → Settings → <i>Websites</i> → <i>Pop-up Windows</i> → for <code>${origin}</code>, choose <b>Allow</b>. Or “Settings for This Website…” from the address bar.</li>
            </ul>
          </details>
          <p style="margin-top:0.5em">Tip: some extensions (ad blockers, privacy tools) also block pop-ups; whitelist this site there if needed.</p>
        `;
        const bodyWidget = new Widget({ node: body });

        const result = await showDialog({
          title: 'Allow pop-ups to open notebooks',
          body: bodyWidget,
          //buttons: [Dialog.cancelButton({ label: 'Cancel' }), Dialog.okButton({ label: 'Try again' })]
          buttons: [Dialog.cancelButton({ label: 'Cancel' })]
        });

        return result.button.accept;
      } else {
        // 3) We had permission—tidy up and continue
        try { testWin.close(); } catch { /* ignore */ }
        return true;
      }
    }

    // Prepare the AL tests command
    app.commands.addCommand(al_tests_command, {
      label: 'M269 AL Tests',
      caption: 'M269 AL Tests',
      
      execute: async (args: any) => {
        const contents = new ContentsManager();
        const currentWidget = notebookTracker.currentWidget;
        if (currentWidget) {
          const notebookPath = currentWidget.context.path; // e.g. "subdir/notebook.ipynb"
          console.log("Notebook path:", notebookPath);
        }
        const notebookPath = currentWidget?.context.path ?? ""
        const upLevels = notebookPath.split("/").length - 1;
        const relPathToRoot = Array(upLevels).fill("..").join("/");
        const testsLocation = getSetting(settings, 'tests_location', '');
        const filePath = testsLocation ? `${testsLocation}/al_tests.py` : 'al_tests.py';
        const fullPath = testsLocation
          ? (relPathToRoot ? `${relPathToRoot}/${testsLocation}/al_tests.py` : `${testsLocation}/al_tests.py`)
          : (relPathToRoot ? `${relPathToRoot}/al_tests.py` : 'al_tests.py');
        let fileContent: string;
        try {
          let decryptKey = getSetting(settings, 'decrypt_key', '');
          if (!decryptKey || decryptKey.length !== 16) {
            const entered = prompt("Enter 16-character decryption key:");
            if (!entered || entered.length !== 16) {
              alert("Invalid key. Must be exactly 16 characters.");
              return;
            }
            decryptKey = entered;
            await settings.set('decrypt_key', decryptKey);
          }
          fileContent = await decrypt(decryptKey);
        } catch (err) {
          alert("Decryption failed: " + (err instanceof Error ? err.message : err));
          return;
        }
        try {
          await contents.save(filePath, {
            type: 'file',
            format: 'text',
            content: fileContent
          });
          console.log('File created successfully');
          if (currentWidget instanceof NotebookPanel) {
            // 1. Put run call in cell 0
            const notebook = currentWidget.content;
            notebook.activeCellIndex = 0;
            notebook.activate();
            await app.commands.execute('notebook:insert-cell-above');
            const cell = notebook.activeCell;
            const code = `%run -i ${fullPath}`;
            (cell as CodeCell).model.sharedModel.setSource(code);
            await app.commands.execute('notebook:run-cell');
            // 2. Check TMA number
            const metadata = currentWidget?.context?.model?.metadata;
            console.log('metadata');
            console.log(metadata);
            console.log(metadata["TMANUMBER"]);
            if (!metadata) {
              console.error('Notebook metadata is undefined');
              return;
            }
            if (metadata["TMANUMBER"] != 1 && metadata["TMANUMBER"] != 2 && metadata["TMANUMBER"] != 3) {
              alert("Could not identify TMA number.");
              return;
            }
            if (metadata["TMAPRES"] != "25J") {
              alert("This tool is only for presentation 25J. This TMA not identifiable as a 25J assessment.");
              return;
            }
            console.log('Identified as TMA '+metadata["TMANUMBER"]+' Presentation '+metadata["TMAPRES"]);
            // 3. Iterate over dictionary for relevant TMA puttin calls in CELLTYPE:ANSWER with relevant QUESTION at last line.
            const tmaNumber = metadata["TMANUMBER"];
            const entries = testCalls[tmaNumber];
            if (entries) {
              for (const [key, value] of Object.entries(entries)) {
                console.log(`Key: ${key}, Value: ${value}`);
                for (let i = 0; i < notebook.widgets.length; i++) {
                  const currentCell = notebook.widgets[i];
                  const meta = currentCell.model.metadata as any;
                  const questionKey = meta["QUESTION"];
                  const cellType = meta["CELLTYPE"];
                  console.log(`Cell ${i}: Type = ${cellType}, Question = ${questionKey}`);
                  if (cellType === "ANSWER" && questionKey === key && currentCell.model.type === "code") {
                    console.log('found');
                    let existing = (currentCell as CodeCell).model.sharedModel.getSource();
                    (currentCell as CodeCell).model.sharedModel.setSource(existing + `\n\n`+value);
                  }
                  if (i == 18 || i == 19 || i == 20) {
                    console.log(cellType);
                    console.log(cellType === "ANSWER");
                    console.log(questionKey);
                    console.log(key)
                    console.log(questionKey === key);
                    console.log(currentCell.model.type)
                    console.log(currentCell.model.type === "code");
                  }
                }
              }
            }
            console.log(code);
          } else {
            alert('Error: Could not access NotebookPanel');
            return;
          }
        } catch (err) {
          alert('Failed to create file: '+ err);
          return;
        }
      }
    });

    // Open all TMAs
    app.commands.addCommand(open_all_tmas, {
            label: 'M269 Open All TMAs',
      caption: 'M269 Open All TMAs',
      
      execute: async (args: any) => {
        // Ask for popup permission (or instructions if blocked)
        const ok = await ensurePopupsAllowed();
        if (!ok) return; // user cancelled
        //alert('OK');
        const contents = app.serviceManager.contents;
        // 1) collect all notebooks from the Jupyter root
        let notebooks = await walkDir(contents, ''); // '' = root

        notebooks = notebooks.filter(path => !path.includes('-UNMARKED'));

        // DEBUG
        const baseUrl = PageConfig.getBaseUrl();
        console.log('OPEN ALL DEBUGGING START');
        for (const path of notebooks) {
          const url = baseUrl + 'lab/tree/' + encodeURIComponent(path);
          console.log('>> '+url);
        }
        console.log('OPEN ALL DEBUGGING END');


        // END DEBUG

        // (optional) sanity check so you don't open hundreds at once
        if (notebooks.length > 20) {
          const ok = window.confirm(
            `Found ${notebooks.length} notebooks. Open them all in new tabs?`
          );
          if (!ok) return;
        }
        
        // 2) open each notebook in a new browser tab
        //const baseUrl = PageConfig.getBaseUrl();
        for (const path of notebooks) {
          const url = baseUrl + 'lab/tree/' + encodeURIComponent(path);
          window.open(url, '_blank');
        }

        alert(`Opened ${notebooks.length} notebooks in new tabs.\mIf they didn't open, enable popups for this site and try again.`);   
      }
    });

    // Set tests location command
    app.commands.addCommand(set_tests_location_command, {
      label: 'M269 Set Tests Location',
      caption: 'M269 Set Tests Location',
      execute: async () => {
        const current = getSetting(settings, 'tests_location', '');
        const result = await InputDialog.getText({
          title: 'Set Tests Location',
          label: 'Enter a readable and writable directory path:',
          placeholder: '/path/to/tests',
          text: current
        });
        if (!result.button.accept || result.value === null) {
          return;
        }
        const path = result.value.trim();
        if (!path) {
          await showDialog({ title: 'Invalid Path', body: 'Path cannot be empty.', buttons: [Dialog.okButton()] });
          return;
        }
        // Validate readable: try to get the directory
        const contents = app.serviceManager.contents;
        try {
          const item = await contents.get(path, { content: false });
          if (item.type !== 'directory') {
            await showDialog({ title: 'Invalid Path', body: `"${path}" is not a directory.`, buttons: [Dialog.okButton()] });
            return;
          }
        } catch {
          await showDialog({ title: 'Invalid Path', body: `Cannot read "${path}". Check the path exists and is accessible.`, buttons: [Dialog.okButton()] });
          return;
        }
        // Validate writable: try to save and delete a temp file
        const tmpPath = path.replace(/\/$/, '') + '/m269_write_test.tmp';
        try {
          await contents.save(tmpPath, { type: 'file', format: 'text', content: '' });
          await contents.delete(tmpPath);
        } catch {
          await showDialog({ title: 'Invalid Path', body: `"${path}" does not appear to be writable.`, buttons: [Dialog.okButton()] });
          return;
        }
        await settings.set('tests_location', path);
        await showDialog({ title: 'Tests Location Saved', body: `Tests location set to: ${path}`, buttons: [Dialog.okButton()] });
      }
    });
    // End set tests location command

    app.commands.addCommand(change_decrypt_key_command, {
      label: 'M269 Change Decrypt Key',
      caption: 'M269 Change Decrypt Key',
      execute: async () => {
        const current = getSetting(settings, 'decrypt_key', '');
        const result = await InputDialog.getText({
          title: 'Change Decrypt Key',
          label: 'Enter decryption key:',
          text: current
        });
        if (!result.button.accept || result.value === null) {
          return;
        }
        await settings.set('decrypt_key', result.value);
      }
    });
    // End change decrypt key command

    app.commands.addCommand(write_al_test_file_command, {
      label: 'M269 Write AL Test File',
      caption: 'M269 Write AL Test File',
      execute: async () => {
        let decryptKey = getSetting(settings, 'decrypt_key', '');
        if (!decryptKey) {
          const result = await InputDialog.getText({
            title: 'Decryption Key Required',
            label: 'Enter decryption key:',
          });
          if (!result.button.accept || !result.value) {
            return;
          }
          decryptKey = result.value;
          await settings.set('decrypt_key', decryptKey);
        }
        let fileContent: string;
        try {
          fileContent = await decrypt(decryptKey);
        } catch (err) {
          await showDialog({
            title: 'Decryption Failed',
            body: 'Could not decrypt the test file. Check your decryption key.',
            buttons: [Dialog.okButton()]
          });
          return;
        }
        const testsLocation = getSetting(settings, 'tests_location', '');
        const filePath = testsLocation ? `${testsLocation}/al_tests.py` : 'al_tests.py';
        try {
          await app.serviceManager.contents.save(filePath, {
            type: 'file',
            format: 'text',
            content: fileContent
          });
          await showDialog({
            title: 'AL Test File Written',
            body: `Successfully wrote al_tests.py to: ${filePath}`,
            buttons: [Dialog.okButton()]
          });
        } catch (err) {
          await showDialog({
            title: 'Write Failed',
            body: `Could not write file to "${filePath}": ${err instanceof Error ? err.message : err}`,
            buttons: [Dialog.okButton()]
          });
        }
      }
    });
    // End write AL test file command

    const category = 'M269-25j';
    // Add commands to pallette
    palette.addItem({ command: prep_command, category, args: { origin: 'from palette' } });
    palette.addItem({ command: colourise_command, category, args: { origin: 'from palette' } });
    palette.addItem({ command: prep_for_students, category, args: { origin: 'from palette' } });
    palette.addItem({ command: al_tests_command, category, args: {origin: 'from palette' }});
    palette.addItem({ command: open_all_tmas, category, args: {origin: 'from palette' }});
    palette.addItem({ command: finish_marking, category, args: {origin: 'from palette' }});
    palette.addItem({ command: set_tests_location_command, category, args: {origin: 'from palette' }});
    palette.addItem({ command: change_decrypt_key_command, category, args: {origin: 'from palette' }});
    palette.addItem({ command: write_al_test_file_command, category, args: {origin: 'from palette' }});

    // Add M269 menu to menubar
    const menu = new Menu({ commands: app.commands });
    menu.title.label = 'M269';
    menu.addItem({ command: prep_command });
    menu.addItem({ command: colourise_command });
    menu.addItem({ command: finish_marking });
    mainMenu.addMenu(menu as any, true, { rank: 1000 });
  }
};

export default plugin;
