"""Browser authentication flow."""
