from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


class RuntimeAPIError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


DEFAULT_WARMUP_TIMEOUT = 180.0


@dataclass(slots=True)
class RuntimeClient:
    base_url: str
    api_key: str | None = None
    timeout: float = 10.0
    transport: httpx.BaseTransport | None = None

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")

    def start_verification(self, email: str, name: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"email": email}
        if name is not None:
            body["name"] = name
        return self._request("POST", "/api/auth/start", json=body)

    def signup(self, email: str, name: str | None = None) -> dict[str, Any]:
        return self.start_verification(email, name)

    def verify(self, flow_id: int, code: str) -> dict[str, Any]:
        return self._request("POST", "/api/auth/verify", json={"flow_id": flow_id, "code": code})

    def whoami(self) -> dict[str, Any]:
        return self._request("GET", "/api/auth/whoami", auth_required=True)

    def logout(self) -> dict[str, Any]:
        return self._request("POST", "/api/auth/logout", auth_required=True)

    # --- Computers ---

    def create_computer(
        self,
        *,
        slug: str | None = None,
        command: str | None = None,
        cwd: str | None = None,
        port: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if slug:
            body["slug"] = slug
        if command is not None or cwd is not None or port is not None:
            start: dict[str, Any] = {}
            if command is not None:
                start["command"] = command
            if cwd is not None:
                start["cwd"] = cwd
            if port is not None:
                start["port"] = port
            body["start"] = start
        return self._request(
            "POST",
            "/api/computers",
            json=body or None,
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def list_computers(self) -> dict[str, Any]:
        return self._request("GET", "/api/computers", auth_required=True)

    def get_computer(self, computer_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/computers/{computer_id}", auth_required=True)

    def get_computer_network(self, computer_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/computers/{computer_id}/network", auth_required=True)

    def start_computer(self, computer_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/start",
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def delete_computer(self, computer_id: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/computers/{computer_id}", auth_required=True)

    def create_terminal_ticket(self, computer_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/terminal-ticket",
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def create_proxy_ticket(self, computer_id: str, port: int) -> dict[str, Any]:
        if port <= 0 or port > 65535:
            raise RuntimeAPIError("port must be between 1 and 65535")
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/proxy-ticket",
            json={"port": port},
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def run_command(
        self,
        computer_id: str,
        command: str,
        *,
        uid: int | None = None,
        gid: int | None = None,
        cwd: str | None = None,
        shell: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"command": command}
        if uid is not None:
            body["uid"] = uid
        if gid is not None:
            body["gid"] = gid
        if cwd is not None:
            body["cwd"] = cwd
        if shell is not None:
            body["shell"] = shell
        return self._request("POST", f"/api/computers/{computer_id}/exec", json=body, auth_required=True)

    def publish_port(self, computer_id: str, port: int) -> dict[str, Any]:
        if port <= 0 or port > 65535:
            raise RuntimeAPIError("port must be between 1 and 65535")
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/publish",
            json={"port": port},
            auth_required=True,
        )

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        auth_required: bool = False,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if auth_required:
            if not self.api_key:
                raise RuntimeAPIError("missing api key")
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            with httpx.Client(
                base_url=self.base_url,
                timeout=self.timeout if timeout is None else timeout,
                transport=self.transport,
            ) as client:
                response = client.request(method, path, json=json, headers=headers)
        except httpx.HTTPError as exc:
            raise RuntimeAPIError(f"request failed: {exc}") from exc

        payload = self._decode_response(response)
        if response.is_success:
            return payload

        message = payload.get("error") or payload.get("message") or f"http {response.status_code}"
        raise RuntimeAPIError(str(message), status_code=response.status_code)

    @staticmethod
    def _decode_response(response: httpx.Response) -> dict[str, Any]:
        if not response.content:
            return {}
        try:
            decoded = response.json()
        except ValueError as exc:
            raise RuntimeAPIError("server returned invalid JSON", status_code=response.status_code) from exc

        if not isinstance(decoded, dict):
            raise RuntimeAPIError("server returned non-object JSON", status_code=response.status_code)
        return decoded
