# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for the Temporal worker module.

Tests the _vram_watchdog circuit breaker using physical psutil/pynvml probing,
and the PartitionedActivityExecutor thread pool lifecycle — zero mocks.
"""

import pytest


def _probe_physical_gpu() -> bool:
    """Mechanically probes the PCIe bus for an active NVIDIA driver."""
    try:
        import pynvml  # type: ignore[import-untyped, import-not-found, unused-ignore]

        pynvml.nvmlInit()
        device_count = pynvml.nvmlDeviceGetCount()
        pynvml.nvmlShutdown()
        return int(device_count) > 0
    except Exception:
        return False


requires_physical_gpu = pytest.mark.skipif(
    not _probe_physical_gpu(),
    reason="TEST QUARANTINED: Requires a physical NVIDIA GPU and pynvml drivers.",
)

# ── _vram_watchdog: Physical Memory Monitor ───────────────────────────
