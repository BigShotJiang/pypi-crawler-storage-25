# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest

from coreason_runtime.orchestration.activities import (
    KineticActivities,
    execute_spatial_kinematic_compute_activity,
)


@pytest.fixture
def activities(tmp_path: Any) -> KineticActivities:
    return KineticActivities(memory_path=str(tmp_path / "mem"))


@pytest.mark.asyncio
async def test_spatial_kinematic() -> None:
    # 1711-1719
    res = await execute_spatial_kinematic_compute_activity({})
    assert res["success"] is False
    assert "forbidden" in res["error"]
