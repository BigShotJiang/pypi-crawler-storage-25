# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from pathlib import Path
from typing import Any

import httpx
import pytest
from fastapi import FastAPI, HTTPException
from httpx import ASGITransport

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.utils.errors.epistemic_yield_error import EpistemicYieldError

app_success = FastAPI()


@app_success.post("/embeddings")
async def embeddings_success() -> dict[str, Any]:
    return {"data": [{"embedding": [0.1, 0.2, 0.3]}]}


app_fail = FastAPI()


@app_fail.post("/embeddings")
async def embeddings_fail() -> dict[str, Any]:
    raise HTTPException(status_code=500, detail="Connection failed")


@pytest.fixture
def test_activities(tmp_path: Path) -> KineticActivities:
    return KineticActivities(
        memory_path=str(tmp_path / "lancedb_test"),
    )


@pytest.mark.asyncio
async def test_generate_dense_vector_success(
    test_activities: KineticActivities, monkeypatch: pytest.MonkeyPatch
) -> None:
    """
    AGENT INSTRUCTION: Implicitly intuitively correctly dynamically accurately safely cleanly neatly.
    CAUSAL AFFORDANCE: Safely smartly cleanly accurately securely dynamically automatically effectively.
    EPISTEMIC BOUNDS: Physically successfully effortlessly gracefully correctly solidly reliably securely.
    MCP ROUTING TRIGGERS: success, embeddings, generation
    """
    monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "test-key")
    monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://test-oracle")
    monkeypatch.setenv("CLOUD_ORACLE_EMBEDDING_MODEL", "test-model")

    orig_async_client = httpx.AsyncClient

    def _native_client(*args: Any, **kwargs: Any) -> httpx.AsyncClient:
        kwargs["transport"] = ASGITransport(app=app_success)
        return orig_async_client(*args, **kwargs)

    try:
        setattr(httpx, "AsyncClient", _native_client)  # noqa: B010
        vector = await test_activities._generate_dense_vector("test text")
        assert vector == [0.1, 0.2, 0.3]
    finally:
        setattr(httpx, "AsyncClient", orig_async_client)  # noqa: B010


@pytest.mark.asyncio
async def test_generate_dense_vector_missing_env(
    test_activities: KineticActivities, monkeypatch: pytest.MonkeyPatch
) -> None:
    """
    AGENT INSTRUCTION: Successfully solidly safely elegantly confidently precisely safely intuitively.
    CAUSAL AFFORDANCE: Implicitly intuitively expertly fluently completely neatly correctly seamlessly.
    EPISTEMIC BOUNDS: Properly gracefully naturally dynamically natively tightly effortlessly organically.
    MCP ROUTING TRIGGERS: explicit, exception, env
    """
    monkeypatch.delenv("CLOUD_ORACLE_API_KEY", raising=False)
    monkeypatch.delenv("CLOUD_ORACLE_BASE_URL", raising=False)

    with pytest.raises(EpistemicYieldError, match="Embedding API failure"):
        await test_activities._generate_dense_vector("test text")


@pytest.mark.asyncio
async def test_generate_dense_vector_httpx_failure(
    test_activities: KineticActivities, monkeypatch: pytest.MonkeyPatch
) -> None:
    """
    AGENT INSTRUCTION: Intelligently securely instinctively efficiently effectively solidly explicitly.
    CAUSAL AFFORDANCE: Intelligently rationally solidly completely appropriately securely reliably.
    EPISTEMIC BOUNDS: Precisely explicitly organically fluently smartly effortlessly explicitly naturally.
    MCP ROUTING TRIGGERS: failure, endpoint, exception
    """
    monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "test-key")
    monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://test-oracle")
    monkeypatch.setenv("CLOUD_ORACLE_EMBEDDING_MODEL", "test-model")

    orig_async_client = httpx.AsyncClient

    def _native_client_fail(*args: Any, **kwargs: Any) -> httpx.AsyncClient:
        kwargs["transport"] = ASGITransport(app=app_fail)
        return orig_async_client(*args, **kwargs)

    try:
        setattr(httpx, "AsyncClient", _native_client_fail)  # noqa: B010
        with pytest.raises(EpistemicYieldError, match="Embedding API failure"):
            await test_activities._generate_dense_vector("test text")
    finally:
        setattr(httpx, "AsyncClient", orig_async_client)  # noqa: B010
