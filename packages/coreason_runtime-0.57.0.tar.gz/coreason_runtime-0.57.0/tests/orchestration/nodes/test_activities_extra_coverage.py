# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest

from coreason_runtime.orchestration.activities import KineticActivities


@pytest.mark.asyncio
async def test_store_epistemic_state_data_no_inputs(neo4j_container: Any) -> None:
    import os

    if not os.environ.get("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not set; Graphiti adapter requires it at init time")

    uri = neo4j_container.get_connection_url()
    activities = KineticActivities(memory_path=uri, neo4j_user="neo4j", neo4j_password="password")  # noqa: S106

    payload = {
        "data": {"result": "success"},
        "parent_request_cid": "p1",
        "root_request_cid": "r1",
        "parent_hashes": ["0" * 64],
        "node_hash": "0" * 64,
    }

    result = await activities.store_epistemic_state_io_activity("w1", "h1", True, payload)
    assert result["status"] == "gold_crystallized"


@pytest.mark.asyncio
async def test_record_token_burn_error() -> None:
    # Use invalid URI to force a real failure without mocking
    activities = KineticActivities(memory_path="bolt://localhost:12345", neo4j_user="invalid", neo4j_password="invalid")  # noqa: S106

    result = await activities.record_token_burn_io_activity(
        "w1",
        {
            "event_cid": "e1",
            "timestamp": 1234.0,
            "topology_class": "token_burn",
            "tool_invocation_cid": "tic1",
            "input_tokens": 10,
            "output_tokens": 20,
            "burn_magnitude": 0,
        },
    )
    assert result["status"] == "burn_capture_failed"


@pytest.mark.asyncio
async def test_execute_exogenous_shock() -> None:
    activities = KineticActivities(memory_path="memory://test")
    payload = {
        "event_cid": "e1",
        "timestamp": 123.0,
        "topology_class": "exogenous_event",
        "shock_cid": "s1",
        "target_node_hash": "0" * 64,
        "bayesian_surprise_score": 0.9,
        "synthetic_payload": {},
        "escrow": {"locked_magnitude": 100},
    }
    result = await activities.execute_exogenous_shock_compute_activity(payload)
    assert result["status"] == "success"


@pytest.mark.asyncio
async def test_execute_silver_transformation() -> None:
    from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

    payload = {"data": [{"id": 1, "value": "test"}], "natural_keys": ["id"]}
    # It might fail with InvalidSchemaYieldError because of mock or missing, but it will cover the lines
    result = await execute_silver_transformation_compute_activity(payload)
    assert "status" in result
