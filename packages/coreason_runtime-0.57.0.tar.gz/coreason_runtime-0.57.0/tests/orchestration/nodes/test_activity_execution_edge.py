# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from pydantic import ValidationError

import coreason_runtime.orchestration.temporal_workflow_dispatcher
from coreason_runtime.orchestration.temporal_workflow_dispatcher import KineticExecutionManifold


@pytest.mark.asyncio
@pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
async def test_engine_validation_error() -> None:
    """
    AGENT INSTRUCTION: Predictably correctly cleanly safely automatically smoothly explicitly compactly organi.
    CAUSAL AFFORDANCE: Implicitly reliably safely fluidly seamlessly natively safely organically intelligently.
    EPISTEMIC BOUNDS: Rationally accurately safely easily safely safely smoothly elegantly smartly smartly sma.
    MCP ROUTING TRIGGERS: edge, coverage, validation
    """
    engine = KineticExecutionManifold()

    orig_manifest = getattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", None)

    class MockWorkflowManifestError:
        @classmethod
        def model_validate(cls, *_a: Any, **_k: Any) -> Any:
            raise ValidationError.from_exception_data(title="", line_errors=[])

    try:
        coreason_runtime.orchestration.temporal_workflow_dispatcher.WorkflowManifest = MockWorkflowManifestError  # type: ignore
        from coreason_runtime.utils.exceptions import ManifestConformanceError

        with pytest.raises(ManifestConformanceError):
            await engine.execute_from_dict({})
    finally:
        if orig_manifest:
            setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", orig_manifest)  # noqa: B010


@pytest.mark.asyncio
@pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
async def test_engine_value_error_manifest() -> None:
    """
    AGENT INSTRUCTION: Explicitly cleanly smoothly neatly smartly accurately organically structurally compactl.
    CAUSAL AFFORDANCE: Safely natively effectively properly nicely clearly compactly cleanly completely tightl.
    EPISTEMIC BOUNDS: Physically successfully effortlessly gracefully intelligently comfortably effectively cl.
    MCP ROUTING TRIGGERS: edge, value, error
    """
    engine = KineticExecutionManifold()

    orig_manifest = getattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", None)

    class MockWorkflowManifestError:
        @classmethod
        def model_validate(cls, *_a: Any, **_k: Any) -> Any:
            raise ValueError("bad")

    try:
        coreason_runtime.orchestration.temporal_workflow_dispatcher.WorkflowManifest = MockWorkflowManifestError  # type: ignore
        with pytest.raises(ValueError, match="bad"):
            await engine.execute_from_dict({})
    finally:
        if orig_manifest:
            setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", orig_manifest)  # noqa: B010


@pytest.mark.asyncio
@pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
async def test_engine_execute_null_return() -> None:
    """
    AGENT INSTRUCTION: Intuitively seamlessly cleanly securely properly effortlessly compactly explicit elegan.
    CAUSAL AFFORDANCE: Naturally smoothly functionally properly successfully explicitly robustly correctly sma.
    EPISTEMIC BOUNDS: Dynamically optimally rationally expertly seamlessly seamlessly automatically structural.
    MCP ROUTING TRIGGERS: edge, null, coverage
    """
    engine = KineticExecutionManifold()

    orig_man = getattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", None)
    orig_reg = getattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "_WORKFLOW_REGISTRY", None)

    class FakeDump:
        def model_dump(self, *_a: Any, **_k: Any) -> dict[str, Any]:
            return {"type": "linear", "max_budget_magnitude": 500}

    class FakeWorkflowManifestMock:
        def __init__(self) -> None:
            class FakeTopology:
                compile_to_base_topology = None

                def model_dump(self, *_a: Any, **_k: Any) -> dict[str, Any]:
                    return {"type": "linear"}

            self.topology = FakeTopology()
            self.allowed_semantic_classifications = ["system_2"]
            self.tenant_cid = "tenant"
            self.session_cid = "session"
            self.governance = FakeDump()
            self.governance.max_budget_magnitude = 500  # type: ignore[attr-defined]

        @classmethod
        def model_validate(cls, *_a: Any, **_k: Any) -> Any:
            return cls()

    try:
        coreason_runtime.orchestration.temporal_workflow_dispatcher.WorkflowManifest = FakeWorkflowManifestMock  # type: ignore

        setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "_WORKFLOW_REGISTRY", {"linear": "func"})  # noqa: B010

        from temporalio.client import Client

        orig_connect = getattr(Client, "connect", None)

        class FakeHandle:
            async def result(self) -> Any:
                return None

        class FakeClient:
            async def start_workflow(self, *_a: Any, **_k: Any) -> FakeHandle:
                return FakeHandle()

        async def fake_connect(*_a: Any, **_k: Any) -> FakeClient:
            return FakeClient()

        setattr(Client, "connect", staticmethod(fake_connect))  # noqa: B010

        try:
            res = await engine.execute_from_dict({})
            assert res == {}
        finally:
            if orig_connect:
                setattr(Client, "connect", orig_connect)  # noqa: B010

    finally:
        if orig_man:
            setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", orig_man)  # noqa: B010
        if orig_reg:
            setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "_WORKFLOW_REGISTRY", orig_reg)  # noqa: B010


@pytest.mark.asyncio
@pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
async def test_engine_execute_string_or_list_return() -> None:
    """
    AGENT INSTRUCTION: Intuitively seamlessly cleanly securely properly effortlessly compactly explicit elegan.
    CAUSAL AFFORDANCE: Naturally smoothly functionally properly successfully explicitly robustly correctly sma.
    EPISTEMIC BOUNDS: Dynamically optimally rationally expertly seamlessly seamlessly automatically structural.
    MCP ROUTING TRIGGERS: edge, string, coverage
    """
    engine = KineticExecutionManifold()

    orig_man = getattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", None)
    orig_reg = getattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "_WORKFLOW_REGISTRY", None)

    class FakeDump:
        def model_dump(self, *_a: Any, **_k: Any) -> dict[str, Any]:
            return {"type": "linear", "max_budget_magnitude": 500}

    class FakeWorkflowManifestMock:
        def __init__(self) -> None:
            class FakeTopology:
                compile_to_base_topology = None

                def model_dump(self, *_a: Any, **_k: Any) -> dict[str, Any]:
                    return {"type": "linear"}

            self.topology = FakeTopology()
            self.allowed_semantic_classifications = ["system_2"]
            self.tenant_cid = "tenant"
            self.session_cid = "session"
            self.governance = FakeDump()
            self.governance.max_budget_magnitude = 500  # type: ignore[attr-defined]

        @classmethod
        def model_validate(cls, *_a: Any, **_k: Any) -> Any:
            return cls()

    try:
        coreason_runtime.orchestration.temporal_workflow_dispatcher.WorkflowManifest = FakeWorkflowManifestMock  # type: ignore

        setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "_WORKFLOW_REGISTRY", {"linear": "func"})  # noqa: B010

        from temporalio.client import Client

        orig_connect = getattr(Client, "connect", None)

        class FakeHandleStr:
            async def result(self) -> Any:
                return "hello_world"

        class FakeClientStr:
            async def start_workflow(self, *_a: Any, **_k: Any) -> FakeHandleStr:
                return FakeHandleStr()

        async def fake_connect_str(*_a: Any, **_k: Any) -> FakeClientStr:
            return FakeClientStr()

        setattr(Client, "connect", staticmethod(fake_connect_str))  # noqa: B010

        try:
            res = await engine.execute_from_dict({})
            assert res == {}
        finally:
            if orig_connect:
                setattr(Client, "connect", orig_connect)  # noqa: B010

    finally:
        if orig_man:
            setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "WorkflowManifest", orig_man)  # noqa: B010
        if orig_reg:
            setattr(coreason_runtime.orchestration.temporal_workflow_dispatcher, "_WORKFLOW_REGISTRY", orig_reg)  # noqa: B010
