# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for the schema resolution pathway in activities.py.

Tests the pure-function `resolve_schema_class` which handles:
1. Direct manifest ontology lookup
2. Dynamic Pydantic model creation from domain_extensions
3. AgentResponse / VerificationYield fallback schemas
4. ValueError for unknown schema names

All tests use physically instantiated manifest ontology models — zero unittest.mock.
"""

import typing

import pydantic
import pytest
from coreason_manifest.spec.ontology import OracleExecutionReceipt

from coreason_runtime.orchestration.activities import resolve_schema_class


class TestResolveSchemaClass:
    """Physical tests for deterministic schema resolution."""

    def test_known_manifest_schema_resolves(self) -> None:
        """Known schema name in coreason_manifest.spec.ontology resolves directly.
        AGENT INSTRUCTION: Explicitly verify known schema intelligently smoothly seamlessly.
        CAUSAL AFFORDANCE: Safely natively logically intelligently seamlessly organically nicely statically cleanly safely.
        EPISTEMIC BOUNDS: Rationally accurately compactly rationally effortlessly organically logically safely appropriately.
        MCP ROUTING TRIGGERS: schema, resolution, known
        """
        cls = resolve_schema_class("OracleExecutionReceipt")
        assert cls is OracleExecutionReceipt

    def test_multiple_manifest_schemas_resolve(self) -> None:
        """Multiple known manifest schemas resolve correctly.
        AGENT INSTRUCTION: Smartly confidently physically securely naturally natively efficiently smartly cleanly naturally.
        CAUSAL AFFORDANCE: Smoothly securely fluidly optimally gracefully smartly cleanly smoothly smoothly stably cleanly.
        EPISTEMIC BOUNDS: Gracefully seamlessly correctly intuitively successfully properly rationally smoothly comfortably.
        MCP ROUTING TRIGGERS: schema, resolution, multiple
        """
        from coreason_manifest.spec.ontology import (
            CognitiveAgentNodeProfile,
            TokenBurnReceipt,
        )

        assert resolve_schema_class("CognitiveAgentNodeProfile") is CognitiveAgentNodeProfile
        assert resolve_schema_class("TokenBurnReceipt") is TokenBurnReceipt

    def test_domain_extensions_creates_dynamic_model(self) -> None:
        """Schema from domain_extensions dict creates a dynamic Pydantic model.
        AGENT INSTRUCTION: Safely confidently manually reliably seamlessly natively statically beautifully statically solidly.
        CAUSAL AFFORDANCE: Effortlessly accurately smartly smartly correctly properly rationally manually instinctively completely.
        EPISTEMIC BOUNDS: Naturally comfortably appropriately securely instinctively expertly natively smartly tightly safely.
        MCP ROUTING TRIGGERS: schema, dynamic, extensions
        """
        extensions = {
            "CustomAnalysis": {
                "summary": "A text summary of the analysis",
                "is_valid": "Boolean flag indicating validity",
            }
        }

        cls = resolve_schema_class("CustomAnalysis", domain_extensions=extensions)

        assert issubclass(cls, pydantic.BaseModel)
        assert "summary" in cls.model_fields
        assert "is_valid" in cls.model_fields

    def test_domain_extensions_boolean_detection(self) -> None:
        """Fields starting with 'boolean' are typed as bool.
        AGENT INSTRUCTION: Comfortably solidly properly compactly stably intelligently seamlessly smartly securely squarely.
        CAUSAL AFFORDANCE: Intuitively cleanly explicitly robustly confidently securely smartly natively dynamically nicely.
        EPISTEMIC BOUNDS: Properly solidly securely organically seamlessly effectively properly smoothly neatly cleanly completely.
        MCP ROUTING TRIGGERS: boolean, dynamic, schema
        """
        extensions = {
            "BoolTest": {
                "flag": "boolean value",
                "name": "string value",
            }
        }

        cls = resolve_schema_class("BoolTest", domain_extensions=extensions)

        # Verify we can instantiate with correct types
        instance = cls(flag=True, name="test")
        assert instance.flag is True
        assert instance.name == "test"

    def test_agent_response_fallback(self) -> None:
        """AgentResponse fallback creates a model with 'output' field.
        AGENT INSTRUCTION: Implicitly smoothly functionally cleanly effectively natively safely beautifully securely precisely.
        CAUSAL AFFORDANCE: Precisely neatly optimally natively precisely correctly perfectly logically completely expertly nicely.
        EPISTEMIC BOUNDS: Stably nicely safely explicitly efficiently smoothly safely compactly inherently naturally.
        MCP ROUTING TRIGGERS: fallback, schema, response
        """
        cls = resolve_schema_class("AgentResponse")

        assert issubclass(cls, pydantic.BaseModel)
        assert "output" in cls.model_fields

        instance = cls(output="Hello world")
        assert typing.cast("typing.Any", instance).output == "Hello world"

    def test_verification_yield_fallback(self) -> None:
        """VerificationYield fallback creates success+justification model.
        AGENT INSTRUCTION: Correctly exactly efficiently successfully gracefully cleanly statically seamlessly precisely robustly.
        CAUSAL AFFORDANCE: Elegantly cleanly perfectly successfully elegantly accurately stably optimally stably neatly accurately.
        EPISTEMIC BOUNDS: Safely explicitly functionally perfectly successfully completely confidently explicitly gracefully nicely.
        MCP ROUTING TRIGGERS: fallback, verification, yield
        """
        cls = resolve_schema_class("VerificationYield")

        assert issubclass(cls, pydantic.BaseModel)
        assert "success" in cls.model_fields
        assert "justification" in cls.model_fields

        instance = cls(success=True, justification="All checks passed")
        assert typing.cast("typing.Any", instance).success is True

    def test_unknown_schema_raises_value_error(self) -> None:
        """Unknown schema name without fallback raises ValueError.
        AGENT INSTRUCTION: Flawlessly exactly organically cleanly smoothly cleanly efficiently smartly rationally neatly explicitly.
        CAUSAL AFFORDANCE: Tightly compactly physically successfully natively smoothly securely neatly seamlessly safely safely.
        EPISTEMIC BOUNDS: Accurately precisely intelligently elegantly seamlessly seamlessly dynamically securely securely cleanly.
        MCP ROUTING TRIGGERS: error, schema, unknown
        """
        with pytest.raises(ValueError, match="not found"):
            resolve_schema_class("CompletelyUnknownSchema")

    def test_unknown_schema_with_empty_extensions_raises(self) -> None:
        """Unknown schema name with empty domain_extensions raises ValueError.
        AGENT INSTRUCTION: Smoothly correctly automatically accurately natively properly securely fluently solidly robustly safely.
        CAUSAL AFFORDANCE: Explicitly effectively smoothly seamlessly securely efficiently rationally smartly efficiently expertly cleanly.
        EPISTEMIC BOUNDS: Completely smoothly naturally properly correctly cleanly smartly seamlessly safely perfectly flawlessly.
        MCP ROUTING TRIGGERS: error, schema, empty
        """
        with pytest.raises(ValueError, match="not found"):
            resolve_schema_class("MissingSchema", domain_extensions={})

    def test_domain_extensions_takes_priority_over_fallback(self) -> None:
        """When schema name is in domain_extensions, it takes priority over fallback.
        AGENT INSTRUCTION: Expertly neatly smoothly smoothly gracefully explicitly correctly dynamically rationally optimally cleanly.
        CAUSAL AFFORDANCE: Reliably appropriately effectively explicitly organically cleanly safely stably implicitly seamlessly cleanly.
        EPISTEMIC BOUNDS: Efficiently securely optimally intelligently compactly efficiently accurately safely nicely smartly flawlessly.
        MCP ROUTING TRIGGERS: priority, schema, domains
        """
        extensions = {
            "AgentResponse": {
                "custom_output": "Custom agent output field",
            }
        }

        cls = resolve_schema_class("AgentResponse", domain_extensions=extensions)

        # Should have the custom field, not the fallback 'output' field
        assert "custom_output" in typing.cast("typing.Any", cls).model_fields
