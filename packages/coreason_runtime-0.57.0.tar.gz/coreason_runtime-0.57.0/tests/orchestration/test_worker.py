# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Real tests for worker.py — no unittest.mock, using lightweight fakes and real objects."""

import asyncio
import concurrent.futures

import pytest

from coreason_runtime.orchestration.worker import (
    PartitionedActivityExecutor,
    _shutdown_handler,
    _vram_watchdog,
)

# ---------------------------------------------------------------------------
# PartitionedActivityExecutor — real thread-pool tests
# ---------------------------------------------------------------------------


class TestPartitionedActivityExecutor:
    """Exercise the real thread-pool executor hash-routing logic."""

    def test_creates_correct_number_of_executors(self) -> None:
        executor = PartitionedActivityExecutor(max_workers=4)
        assert len(executor.executors) == 4

    def test_default_max_workers(self) -> None:
        executor = PartitionedActivityExecutor()
        assert len(executor.executors) == 16

    def test_submit_outside_activity_falls_back_to_default(self) -> None:
        """Outside Temporal activity context → uses default executor."""
        executor = PartitionedActivityExecutor(max_workers=2)
        future = executor.submit(lambda: 42)
        assert isinstance(future, concurrent.futures.Future)
        assert future.result(timeout=5) == 42

    def test_submit_runs_callable_with_args(self) -> None:
        executor = PartitionedActivityExecutor(max_workers=2)
        future = executor.submit(lambda x, y: x + y, 3, 7)
        assert future.result(timeout=5) == 10

    def test_submit_multiple_concurrent(self) -> None:
        """Multiple submissions return correct results."""
        executor = PartitionedActivityExecutor(max_workers=4)
        futures = [executor.submit(lambda i=i: i * 3) for i in range(20)]
        results = [f.result(timeout=5) for f in futures]
        assert results == [i * 3 for i in range(20)]

    @pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
    def test_submit_with_temporal_activity_info(self) -> None:
        pytest.skip("Requires real Temporal activity context, mocks are banned")


# ---------------------------------------------------------------------------
# _vram_watchdog — real psutil-based tests (no GPU)
# ---------------------------------------------------------------------------


class TestVramWatchdog:
    """Exercise the async watchdog with real system metrics."""

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
    async def test_exits_when_cancel_already_set(self) -> None:
        """Watchdog returns immediately when cancel event is pre-set."""
        cancel = asyncio.Event()
        cancel.set()
        await asyncio.wait_for(_vram_watchdog(10 * 1024**3, cancel), timeout=2.0)

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
    async def test_runs_and_stops_on_cancel(self) -> None:
        """Watchdog monitors real memory then exits on cancel."""
        cancel = asyncio.Event()
        # High limit so circuit breaker won't trip
        task = asyncio.create_task(_vram_watchdog(100 * 1024**3, cancel))
        await asyncio.sleep(2.5)
        cancel.set()
        await asyncio.wait_for(task, timeout=3.0)

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
    async def test_circuit_breaker_trips_with_tiny_limit(self) -> None:
        """1-byte limit is always exceeded → cancel_event gets set."""
        cancel = asyncio.Event()
        task = asyncio.create_task(_vram_watchdog(1, cancel))
        await asyncio.wait_for(task, timeout=5.0)
        assert cancel.is_set()

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
    async def test_pynvml_logic(self) -> None:
        pytest.skip("Hardware-dependent test requiring physical GPUs. Mocks are banned")

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
    async def test_pynvml_over_limit(self) -> None:
        pytest.skip("Hardware-dependent test requiring physical GPUs. Mocks are banned")


# ---------------------------------------------------------------------------
# _shutdown_handler — lightweight fakes (not unittest.mock)
# ---------------------------------------------------------------------------


class FakeWorker:
    def __init__(self, *, should_fail: bool = False):
        self.was_shutdown = False
        self._should_fail = should_fail

    async def shutdown(self) -> None:
        if self._should_fail:
            raise RuntimeError("Temporal connection lost")
        self.was_shutdown = True


class FakeStore:
    def __init__(self) -> None:
        self.was_closed = False

    async def close(self) -> None:
        self.was_closed = True


class FakeActivities:
    def __init__(self, *, with_close: bool = True):
        self.store = FakeStore() if with_close else object()


class TestShutdownHandler:
    @pytest.mark.asyncio
    async def test_calls_shutdown_and_close(self) -> None:
        worker = FakeWorker()
        activities = FakeActivities(with_close=True)

        await _shutdown_handler(worker, activities)
        assert worker.was_shutdown
        assert getattr(activities.store, "was_closed", False)

    @pytest.mark.asyncio
    async def test_works_without_close_method(self) -> None:
        worker = FakeWorker()
        activities = FakeActivities(with_close=False)

        await _shutdown_handler(worker, activities)
        assert worker.was_shutdown

    @pytest.mark.asyncio
    async def test_handles_shutdown_error_gracefully(self) -> None:
        worker = FakeWorker(should_fail=True)
        activities = FakeActivities()

        # Should not raise
        await _shutdown_handler(worker, activities)
        assert not worker.was_shutdown  # Shutdown failed, so flag stays False


# ---------------------------------------------------------------------------
# start_worker — testing the setup logic
# ---------------------------------------------------------------------------


class TestStartWorker:
    @pytest.mark.asyncio
    async def test_start_worker_setup(self) -> None:
        pytest.skip("Requires physical Graphiti and Temporal substrate")
