# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


from typing import Any

import httpx
import pytest
from coreason_manifest import MCPPromptReferenceState, MCPResourceManifest
from fastapi import FastAPI, Response
from hypothesis import given, settings
from hypothesis import strategies as st
from temporalio.testing import ActivityEnvironment

from coreason_runtime.execution_plane.gateway_bridge.master_mcp import MasterGatewayClient
from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.utils.exceptions import ManifestConformanceError

app = FastAPI()


@app.post("/mcp/{server_cid}/tools/call")
async def call_tool(server_cid: str, payload: dict[str, Any]) -> Any:
    if payload.get("TEST_TRIGGER_EXCEPTION") or payload.get("arguments", {}).get("TEST_TRIGGER_EXCEPTION"):
        return Response(status_code=500, content='{"error": "MasterGateway connection failed"}')
    return {
        "status": "success",
        "iterations": 1,
        "results": [{"status": "success", "intent_hash": "GATEWAY_REAL"}],
    }


@app.post("/mcp/{server_cid}/prompts/get")
async def get_prompt(server_cid: str, payload: dict[str, Any]) -> Any:
    return {"prompt": "test"}


@app.post("/mcp/{server_cid}/resources/read")
async def read_resource(server_cid: str, payload: dict[str, Any]) -> Any:
    return {"res": "data"}


@app.post("/mcp/{server_cid}/{method:path}")
async def generic_request(server_cid: str, method: str, payload: dict[str, Any]) -> Any:
    if server_cid == "urn:test" and method == "test":
        return Response(status_code=404, content='{"error": "Not Found"}')
    if method == "custom/method":
        return {"custom": "method_data"}
    if method == "shim/test":
        return {"shim": "works"}
    if method == "shim/test2":
        return {"shim2": "works_no_args"}
    return {"echo": payload}


@pytest.fixture
def activity_env() -> ActivityEnvironment:
    return ActivityEnvironment()


@pytest.fixture
def activities() -> KineticActivities:
    transport = httpx.ASGITransport(app=app)
    return KineticActivities(memory_path="memory", gateway_transport=transport)


@pytest.mark.asyncio
async def test_execute_gateway_cognitive_activity_success(
    activity_env: ActivityEnvironment, activities: KineticActivities
) -> None:
    result = await activity_env.run(activities.execute_gateway_cognitive_activity, {"some": "data"})
    assert result["status"] == "success"
    assert result["results"][0]["intent_hash"] == "GATEWAY_REAL"


@pytest.mark.asyncio
async def test_execute_gateway_cognitive_activity_exception(
    activity_env: ActivityEnvironment, activities: KineticActivities
) -> None:
    with pytest.raises(Exception, match="Gateway internal server error"):
        await activity_env.run(activities.execute_gateway_cognitive_activity, {"TEST_TRIGGER_EXCEPTION": True})


@pytest.mark.asyncio
async def test_gateway_bridge_client_exceptions() -> None:
    transport = httpx.ASGITransport(app=app)
    client = MasterGatewayClient(transport=transport)
    with pytest.raises(ManifestConformanceError, match="Gateway HTTP error"):
        await client._post_payload("urn:test", "test", {})

    # For connection error, we can use a client with no transport hitting a dead port
    client_dead = MasterGatewayClient(gateway_url="http://127.0.0.1:1")
    with pytest.raises(Exception, match="Gateway communication failure"):
        await client_dead._post_payload("urn:test", "test_conn", {})


# Cert logic stripped from MasterGatewayClient


@pytest.mark.asyncio
async def test_gateway_bridge_methods() -> None:
    transport = httpx.ASGITransport(app=app)
    client = MasterGatewayClient(transport=transport)

    # hydrate_prompt
    prompt_state = MCPPromptReferenceState(server_cid="urn:test", prompt_name="p", arguments={"k": "v"})
    res = await client.hydrate_prompt(prompt_state)
    assert res == {"prompt": "test"}

    # read_resource
    resource_manifest = MCPResourceManifest(server_cid="urn:test", uris=["file:///test.txt"])
    res2 = await client.read_resource(resource_manifest)
    assert res2 == {"resources": [{"res": "data"}]}

    # request
    res3 = await client.request("urn:test", "custom/method", {"arg": "val"})
    assert res3 == {"custom": "method_data"}


@pytest.mark.asyncio
async def test_mcp_client_manager_shim() -> None:
    transport = httpx.ASGITransport(app=app)
    bridge = MasterGatewayClient(transport=transport)
    shim = bridge.get_client("urn:shim_test")

    # Test request with args
    res = await shim.request("shim/test", {"some": "arg"})
    assert res == {"shim": "works"}

    # Test request without args
    res2 = await shim.request("shim/test2")
    assert res2 == {"shim2": "works_no_args"}


@settings(max_examples=10)
@given(
    server_cid=st.from_regex(r"^[a-zA-Z0-9_-]+$", fullmatch=True),
    method=st.from_regex(r"^[a-zA-Z0-9_-]+/[a-zA-Z0-9_-]+$", fullmatch=True),
    arguments=st.dictionaries(
        st.text(alphabet="abcdefghijklmnopqrstuvwxyz"), st.text(alphabet="abcdefghijklmnopqrstuvwxyz")
    ),
)
@pytest.mark.asyncio
async def test_gateway_hypothesis(server_cid: str, method: str, arguments: dict[str, str]) -> None:
    transport = httpx.ASGITransport(app=app)
    bridge = MasterGatewayClient(transport=transport)
    shim = bridge.get_client(server_cid)

    res = await shim.request(method, arguments)
    assert res["echo"] == arguments
