# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import dspy
import pytest

from coreason_runtime.orchestration.solvers.remediation_compiler import RemediationCompiler


class MockLM(dspy.LM):
    def __init__(self, **kwargs):
        super().__init__("mock", **kwargs)

    def __call__(self, *args, **kwargs):  # noqa: ARG002
        return ['{"reasoning": "Looks bad", "critique": "Needs work.", "optimized_solution": "Better code."}']


@pytest.fixture(autouse=True)
def setup_dspy():
    mock_lm = MockLM()
    dspy.settings.configure(lm=mock_lm)


def test_remediation_compiler():
    compiler = RemediationCompiler()

    input_context = "Task: Write a function to add two numbers."
    proposed_solution = "def add(a, b): return a - b"

    # Use __call__ instead of forward to suppress warning
    result = compiler(input_context=input_context, proposed_solution=proposed_solution)

    if not hasattr(result, "critique"):
        pytest.fail("Result does not have attribute 'critique'")
    if not hasattr(result, "optimized_solution"):
        pytest.fail("Result does not have attribute 'optimized_solution'")
    if not isinstance(result.critique, str):
        pytest.fail(f"Expected critique to be str, got {type(result.critique)}")
    if not isinstance(result.optimized_solution, str):
        pytest.fail(f"Expected optimized_solution to be str, got {type(result.optimized_solution)}")
