# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
import base64
import os
import shutil
import struct
from collections.abc import AsyncGenerator
from typing import Any

import pytest
import pytest_asyncio
from coreason_manifest.spec.ontology import LatentProjectionIntent, VectorEmbeddingState
from fastapi import FastAPI
from uvicorn import Config, Server

from coreason_runtime.orchestration.activities import KineticActivities


class FakeMasterGatewayServer:
    """AGENT INSTRUCTION: Lightweight FastAPI bridge for Zero-Mock testing."""

    def __init__(self, host: str = "127.0.0.1", port: int = 8000) -> None:
        self.app = FastAPI()
        self.host = host
        self.port = port
        self._setup_routes()
        config = Config(app=self.app, host=self.host, port=self.port, log_level="error")
        self.server = Server(config=config)

    def _setup_routes(self) -> None:
        @self.app.post("/call_tool")
        async def call_tool(req: dict[str, Any]) -> dict[str, Any]:
            # Simulate a successful tool execution
            return {"outputs": "found"}

    async def start(self) -> None:
        self._serve_task = asyncio.create_task(self.server.serve())
        await asyncio.sleep(0.1)  # Ignite

    async def stop(self) -> None:
        self.server.should_exit = True
        await asyncio.sleep(0.1)


@pytest_asyncio.fixture
async def activities() -> AsyncGenerator[KineticActivities]:
    """SOTA 2026 Activity Hub with transient physical substrate."""
    test_db = "test_memory_activities"
    if os.path.exists(test_db):
        shutil.rmtree(test_db)

    # Instantiate physical server instead of mocking
    server = FakeMasterGatewayServer(port=8001)
    await server.start()

    # Provision activities with real DB connection
    hub = KineticActivities(
        sglang_url="http://localhost:3000",
        plugins_dir="./plugins",
    )

    yield hub

    # Thermodynamic cleanup
    await server.stop()
    if os.path.exists(test_db):
        shutil.rmtree(test_db)


@pytest.mark.skip(reason="Requires physical Graphiti substrate")
@pytest.mark.asyncio
async def test_retrieve_latent_projection_compute_activity(activities: KineticActivities) -> None:
    """AGENT INSTRUCTION: Verify latent retrieval against physical LanceDB manifold."""

    # Crystallize the latent space
    await activities.latent.bootstrap()
    await activities.ledger.bootstrap()

    # Encode a dummy vector (1536 dims of 0.1f)
    vector_data = [0.1] * 1536
    b64_vector = base64.b64encode(struct.pack("1536f", *vector_data)).decode("utf-8")

    _intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64=b64_vector,
            foundation_matrix_name="test_manifold",
            dimensionality=1536,
        ),
        top_k_candidates=1,
        min_isometry_score=0.1,
    )

    pytest.skip("Requires physical Graphiti substrate")


@pytest.mark.skip(reason="Requires physical Graphiti substrate")
@pytest.mark.asyncio
async def test_store_epistemic_state_io_activity(activities: KineticActivities) -> None:
    """AGENT INSTRUCTION: Verify crystallization using real cryptographic verification paths."""
    await activities.ledger.bootstrap()

    payload = {"outputs": {"key": "value"}}
    await activities.store_epistemic_state_io_activity(
        workflow_id="test_wf_store",
        intent_hash="hash_store",
        success=True,
        payload=payload,
    )

    # Verify physical persistence
    pytest.skip("Requires physical Graphiti substrate")


@pytest.mark.asyncio
async def test_invoke_scaffold_sensory_urn_mcp_io_activity() -> None:
    from coreason_runtime.orchestration.activities import invoke_scaffold_sensory_urn_mcp_io_activity

    payload = {"geometric_schema_intent": {"target_domain": "test"}}
    res = await invoke_scaffold_sensory_urn_mcp_io_activity(payload)
    assert res["status"] == "success"
    assert "forged_urn" in res
    assert res["forged_urn"].startswith("urn:coreason:actionspace:sensory:test:")


@pytest.mark.asyncio
async def test_evaluate_ui_score_compute_activity() -> None:
    from coreason_runtime.orchestration.activities import evaluate_ui_score_compute_activity

    res = await evaluate_ui_score_compute_activity({"current_urn": "a", "new_urn": "b"})
    assert res["new_score"] > res["current_score"]

    res2 = await evaluate_ui_score_compute_activity({"current_urn": "a", "new_urn": "a"})
    assert res2["new_score"] == res2["current_score"]
