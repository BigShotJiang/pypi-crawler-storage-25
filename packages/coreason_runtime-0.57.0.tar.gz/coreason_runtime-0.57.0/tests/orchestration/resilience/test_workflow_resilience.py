# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from temporalio import activity
from temporalio.exceptions import ApplicationError


@pytest.fixture
def cognitive_topology_manifest() -> dict[str, Any]:
    return {
        "topology_class": "cognitive_topology",
        "nodes": {
            "did:test:agent-1-cognitive": {
                "topology_class": "agent",
                "description": "A helpful cognitive agent.",
            }
        },
    }


# --- Mock activities ---


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="ExecuteNemoclawCognitiveActivity")
async def mock_execute_tensor_inference_yield(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Returns epistemic_yield to trigger Oracle escalation path."""
    return {
        "node_cid": "mock-node",
        "status": "epistemic_yield",
        "intent_hash": "mock-hash",
        "success": False,
        "result": {"output": "Epistemic yield triggered"},
    }


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "success", "vector_id": "mock-123"}


@activity.defn(name="ExecuteMCPToolIOActivity")
async def mock_execute_mcp_tool_fault(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Raises a SemanticFirewallPolicyError to simulate Bipartite Graph Separation violation."""
    raise ApplicationError(
        "Mathematical bounds violation: Mutually Exclusive Traversal",
        non_retryable=True,
        type="SemanticFirewallPolicyError",
    )


@activity.defn(name="EmitResumedEventIOActivity")
async def mock_emit_resumed_event_activity(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "resumed"}


@activity.defn(name="RequestOracleInterventionIOActivity")
async def mock_request_oracle_intervention(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "success"}


@activity.defn(name="AnnounceTaskIOActivity")
async def mock_announce_task(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return _args[0] if _args else {}


@activity.defn(name="BroadcastStateEchoIOActivity")
async def mock_broadcast_state_echo(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "echoed"}


COMMON_ACTIVITIES = [
    mock_execute_tensor_inference_yield,
    mock_store_epistemic_state,
    mock_emit_resumed_event_activity,
    mock_request_oracle_intervention,
    mock_announce_task,
    mock_broadcast_state_echo,
]
