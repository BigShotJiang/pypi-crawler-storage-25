# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import dspy
import pytest

from coreason_runtime.orchestration.graphs.topology_resolution_graph import create_topology_resolution_graph


class MockLM(dspy.LM):
    def __init__(self, **kwargs):
        super().__init__("mock", **kwargs)

    def __call__(self, *args, **kwargs):  # noqa: ARG002
        # Handle the DSPy v3+ message format
        return ['{"reasoning": "Looks bad", "critique": "Needs work.", "optimized_solution": "Better code."}']


@pytest.fixture(autouse=True)
def setup_dspy():
    mock_lm = MockLM()
    dspy.settings.configure(lm=mock_lm)


@pytest.mark.asyncio
async def test_topology_resolution_graph():
    graph = create_topology_resolution_graph()

    input_payload = {"task": "Solve a complex problem"}

    initial_state = {
        "input_payload": input_payload,
        "current_solution": "",
        "critiques": [],
        "iteration_count": 0,
        "final_output": {},
    }

    final_state = await graph.ainvoke(initial_state)

    if final_state["iteration_count"] != 3:
        pytest.fail(f"Expected iteration_count 3, got {final_state['iteration_count']}")
    if len(final_state["critiques"]) != 3:
        pytest.fail(f"Expected 3 critiques, got {len(final_state['critiques'])}")
    if "Better code." not in final_state["current_solution"]:
        pytest.fail(f"Expected 'Better code.' in current_solution, got {final_state['current_solution']}")
