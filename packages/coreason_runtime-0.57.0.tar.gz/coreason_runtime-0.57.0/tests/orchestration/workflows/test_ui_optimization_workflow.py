from typing import Any

import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from coreason_runtime.orchestration.activities import (
    evaluate_ui_score_compute_activity,
    invoke_scaffold_sensory_urn_mcp_io_activity,
)
from coreason_runtime.orchestration.workflows.ui_optimization_workflow import UIOptimizationWorkflow

# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


@pytest.mark.asyncio
async def test_ui_optimization_workflow_success() -> None:
    # SOTA 2026: Zero-Mock Physical Testing Axiom
    async with await WorkflowEnvironment.start_time_skipping() as env:
        from temporalio import activity

        @activity.defn(name="BroadcastStateEchoIOActivity")
        async def mock_broadcast(workflow_id: str, payload: dict[str, Any]) -> dict[str, str]:
            return {"status": "success"}

        async with Worker(
            env.client,
            task_queue="test-ui-queue",
            workflows=[UIOptimizationWorkflow],
            activities=[
                invoke_scaffold_sensory_urn_mcp_io_activity,
                evaluate_ui_score_compute_activity,
                mock_broadcast,
            ],
        ):
            payload = {"target_domain": "test", "current_urn": "urn:old"}

            result = await env.client.execute_workflow(
                UIOptimizationWorkflow.run,
                payload,
                id="test-ui-opt-workflow",
                task_queue="test-ui-queue",
            )
            assert result["status"] == "upgrade_emitted"
            assert "new_urn" in result
