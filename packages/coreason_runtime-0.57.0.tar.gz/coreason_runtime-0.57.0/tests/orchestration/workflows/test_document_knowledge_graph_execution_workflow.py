# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for DocumentKnowledgeGraphExecutionWorkflow.

Tests both the estimate_causal_effect_activity (local activity / pure function)
and the full Temporal workflow via WorkflowEnvironment.start_time_skipping().

All tests use physically instantiated manifest models —
returning manifest-typed payloads — zero unittest.mock.
"""

import concurrent.futures
from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    ExecutionEnvelopeState,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.document_knowledge_graph_execution_workflow import (
    DocumentKnowledgeGraphExecutionWorkflow,
)


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="ExecuteMCPToolIOActivity")
async def stub_execute_mcp_tool(
    tool_name: str, intent_payload: dict[str, Any], caller_context: dict[str, Any]
) -> dict[str, Any]:
    if not intent_payload.get("params", {}).get("arguments", {}):
        return {"success": False, "error": "Missing required causal parameters"}
    return {
        "success": True,
        "estimated_effect": 3.0,
        "treatment_variable": "A",
        "outcome_variable": "B",
    }


def _build_kg_envelope(payload_data: dict[str, Any]) -> dict[str, Any]:
    """Build a physically validated ExecutionEnvelopeState for the KG workflow."""
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H00000000000000000000000",
            span_cid="01H00000000000000000000001",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=payload_data,
    )
    return envelope.model_dump(mode="json")


class TestDocumentKnowledgeGraphWorkflow:
    """Physical Temporal tests for DocumentKnowledgeGraphExecutionWorkflow."""

    @pytest.mark.asyncio
    async def test_workflow_estimates_effect(self) -> None:
        """Workflow processes graph and returns causal estimation."""
        import numpy as np

        n_samples = 100
        x = np.random.normal(0, 1, n_samples)
        y = 3.0 * x + np.random.normal(0, 0.1, n_samples)

        data = [{"A": float(x_val), "B": float(y_val)} for x_val, y_val in zip(x, y, strict=False)]

        graph_str = 'graph[directed 1node[id "A" label "A"]node[id "B" label "B"]edge[source "A" target "B"]]'

        payload_data = {
            "treatment_variable": "A",
            "outcome_variable": "B",
            "graph_payload": graph_str,
            "data": data,
        }

        payload = _build_kg_envelope(payload_data)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="kg-test-queue",
                workflows=[DocumentKnowledgeGraphExecutionWorkflow],
                activities=[stub_emit_span, stub_execute_mcp_tool],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    DocumentKnowledgeGraphExecutionWorkflow.run,
                    payload,
                    id="kg-test-workflow",
                    task_queue="kg-test-queue",
                )

        assert result["success"] is True
        assert "estimated_effect" in result
        assert 2.5 <= result["estimated_effect"] <= 3.5
        assert "knowledge_graph_" in result["manifest"]["server_cid"]

    @pytest.mark.asyncio
    async def test_workflow_missing_params(self) -> None:
        """Workflow handles missing parameters gracefully."""
        payload = _build_kg_envelope({})

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="kg-empty-queue",
                workflows=[DocumentKnowledgeGraphExecutionWorkflow],
                activities=[stub_emit_span, stub_execute_mcp_tool],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    DocumentKnowledgeGraphExecutionWorkflow.run,
                    payload,
                    id="kg-empty-test",
                    task_queue="kg-empty-queue",
                )

        assert result["success"] is False
        assert "error" in result
