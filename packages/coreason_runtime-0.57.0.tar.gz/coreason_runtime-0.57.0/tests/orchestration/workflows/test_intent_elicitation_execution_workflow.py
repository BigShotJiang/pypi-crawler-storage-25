# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
from typing import Any

import httpx
import pytest
from coreason_manifest import (
    ExecutionEnvelopeState,
    IntentElicitationTopologyManifest,
)
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    StateVectorProfile,
    TraceContextState,
)
from fastapi import FastAPI
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.orchestration.workflows.intent_elicitation_execution_workflow import (
    IntentElicitationExecutionWorkflow,
)

# ── Physical Substrate Setup ─────────────────────────────────────────

app = FastAPI()

# Global state to control entropy for tests
entropy_to_return = 0.1


@app.post("/mcp/{server_cid}/tools/call")
async def mock_gateway_call(server_cid: str, payload: dict[str, Any]) -> "Any":
    """Physical FastAPI endpoint for MasterGateway bridge testing."""
    return {
        "success": True,
        "outputs": {"result": True, "entropy": entropy_to_return},
        "intent_hash": "b" * 64,
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        "cost": 0.01,
    }


@app.get("/profiles")
async def mock_gateway_profiles() -> dict[str, list[str]]:
    return {"profiles": ["system_node", "urn:coreason:oracle:gateway"]}


# ── Envelope Factory ──────────────────────────────────────────────────


def _build_intent_envelope(
    max_clarification_loops: int = 3,
) -> dict[str, Any]:
    """Build an ExecutionEnvelopeState for intent elicitation."""
    scanner_cid = "did:coreason:scanner-0"
    transmuter_cid = "did:coreason:transmuter-0"
    oracle_cid = "did:coreason:oracle-0"

    nodes: dict[str, CognitiveAgentNodeProfile] = {
        scanner_cid: CognitiveAgentNodeProfile(
            description="VLM Scanner Node",
            topology_class="agent",
        ),
        transmuter_cid: CognitiveAgentNodeProfile(
            description="Transmuter Node",
            topology_class="agent",
        ),
        oracle_cid: CognitiveAgentNodeProfile(
            description="Human Oracle Node",
            topology_class="agent",
        ),
    }

    manifest = IntentElicitationTopologyManifest(
        nodes=nodes,  # type: ignore[arg-type]
        max_clarification_loops=max_clarification_loops,
        scanner_node_cid=scanner_cid,
        transmuter_node_cid=transmuter_cid,
        human_oracle_cid=oracle_cid,
        raw_human_artifact_cid="artifact-001",
    )

    manifest_payload = manifest.model_dump(mode="json")
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H0000000000000000000000A",
            span_cid="01H0000000000000000000000B",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest_payload,
    )
    return envelope.model_dump(mode="json")


# ── Tests ─────────────────────────────────────────────────────────────


class TestIntentElicitationExecutionWorkflow:
    """Physical Temporal tests for intent elicitation workflow."""

    @pytest.mark.asyncio
    async def test_low_entropy_converges_immediately(self, neo4j_container: "Any") -> None:
        """Entropy below threshold causes immediate convergence on first round."""
        global entropy_to_return
        entropy_to_return = 0.1
        payload = _build_intent_envelope(max_clarification_loops=3)

        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-q1",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=activities.get_activities(),
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-low-entropy",
                    task_queue="intent-q1",
                )

        assert result["status"] == "success"
        assert result["rounds"] == 0  # converged on first round
        assert result["intent"] is not None

    @pytest.mark.asyncio
    async def test_single_loop_iteration(self, neo4j_container: "Any") -> None:
        """Single clarification loop produces correct structure."""
        global entropy_to_return
        entropy_to_return = 0.1
        payload = _build_intent_envelope(max_clarification_loops=1)

        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-q2",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=activities.get_activities(),
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-single-loop",
                    task_queue="intent-q2",
                )

        assert result["status"] == "success"


class TestIntentElicitationHighEntropy:
    """Evaluate structural fallback blocks natively via high-entropy stubs."""

    @pytest.mark.asyncio
    async def test_high_entropy_resolved_by_override(self, neo4j_container: "Any") -> None:
        """Covers entropy wait_condition, receive_oracle_override signal, and intent_hash calculation fallback."""
        global entropy_to_return
        entropy_to_return = 0.8
        payload = _build_intent_envelope(max_clarification_loops=3)

        # Modify the payload to force `node_profile is None` organically!
        payload_data = payload["payload"]
        payload_data["scanner_node_cid"] = "did:coreason:missing-node"

        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-high",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=activities.get_activities(),
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                handle = await env.client.start_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-high-entropy",
                    task_queue="intent-high",
                )

                await asyncio.sleep(0.1)
                await handle.signal("receive_oracle_override", {"success": True, "override": "absolute_truth"})

                res = await handle.result()

        assert res["status"] == "success"
        assert res["intent"]["override"] == "absolute_truth"

    @pytest.mark.asyncio
    async def test_high_entropy_resolved_by_resolution(self, neo4j_container: "Any") -> None:
        """Covers inject_oracle_resolution signal breaking inner loops organically."""
        global entropy_to_return
        entropy_to_return = 0.8
        payload = _build_intent_envelope(max_clarification_loops=1)

        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="intent-high-res",
                workflows=[IntentElicitationExecutionWorkflow],
                activities=activities.get_activities(),
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                handle = await env.client.start_workflow(
                    IntentElicitationExecutionWorkflow.run,
                    payload,
                    id="intent-high-resolution",
                    task_queue="intent-high-res",
                )

                await asyncio.sleep(0.1)
                await handle.signal("inject_oracle_resolution", {"status": "cleared"})

                res = await handle.result()

        assert res["status"] == "success"
        # Since override was not used and resolution allowed progress, it proceeds to increment round and loop again!
        assert res["rounds"] == 1
