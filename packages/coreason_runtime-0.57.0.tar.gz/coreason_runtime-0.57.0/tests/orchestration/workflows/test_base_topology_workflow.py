# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for BaseTopologyWorkflow: state management, governance, and signal handlers.

These tests exercise the pure-function methods of the base workflow class directly,
without Temporal. Signal handlers and activity-dispatching methods are tested via
physical Temporal time-skipping environments.

Zero unittest.mock. Zero respx. All payloads instantiated via manifest Type Isomorphism.
"""

from typing import Any

import pytest
from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

from coreason_runtime.orchestration.workflows.base_topology_workflow import BaseTopologyWorkflow

# ── Fixtures ───────────────────────────────────────────────────────


def _build_envelope() -> ExecutionEnvelopeState[dict[str, Any]]:
    """Build a minimal ExecutionEnvelopeState for testing."""
    import uuid

    trace_id = str(uuid.uuid7())  # pyre-ignore[16]
    span_id = str(uuid.uuid7())  # pyre-ignore[16]
    return ExecutionEnvelopeState(
        trace_context=TraceContextState(
            trace_cid=trace_id,
            span_cid=span_id,
            causal_clock=0,
        ),
        state_vector=StateVectorProfile(
            immutable_matrix={"tenant_cid": "test-tenant", "session_cid": "test-session"},
            mutable_matrix={"accumulated_tokens": 0, "accumulated_cost": 0.0},
            is_delta=False,
        ),
        payload={"type": "dag", "nodes": {}},
    )


# ── Init Tests ─────────────────────────────────────────────────────


class TestBaseTopologyInit:
    """Verify default initialization state."""

    def test_default_init(self) -> None:
        wf = BaseTopologyWorkflow()
        assert wf._current_state_envelope is None
        assert wf._pending_oracle_override is None
        assert wf._current_oracle_resolution is None
        assert wf._accumulated_tokens == 0
        assert wf._accumulated_cost == 0.0
        assert wf._is_interrupted is False
        assert wf._interrupt_disposition is None
        assert wf._interrupt_event is None
        assert wf._shock_reason is None


# ── State Reconciliation Tests ─────────────────────────────────────


class TestReconcileState:
    """Exercise the CRDT-style reconcile_state method."""

    def test_reconcile_updates_mutable_matrix(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()

        wf.reconcile_state({"new_key": "new_value"})

        matrix = wf._current_state_envelope.state_vector.mutable_matrix
        assert matrix["new_key"] == "new_value"  # type: ignore[index]
        # Original keys preserved
        assert matrix["accumulated_tokens"] == 0  # type: ignore[index]

    def test_reconcile_increments_causal_clock(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()
        assert wf._current_state_envelope.trace_context.causal_clock == 0

        wf.reconcile_state({"delta": True})
        assert wf._current_state_envelope.trace_context.causal_clock == 1

        wf.reconcile_state({"delta_2": True})
        assert wf._current_state_envelope.trace_context.causal_clock == 2

    def test_reconcile_immutable_key_raises(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()

        with pytest.raises(ValueError, match="read-only context key"):
            wf.reconcile_state({"tenant_cid": "evil_override"})

    def test_reconcile_no_envelope_raises(self) -> None:
        wf = BaseTopologyWorkflow()
        with pytest.raises(ValueError, match="No current state envelope"):
            wf.reconcile_state({"key": "value"})


# ── Governance Enforcement Tests ───────────────────────────────────


class TestEnforceGovernanceLimits:
    """Exercise the economic constraint enforcement."""

    def test_no_governance_is_noop(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_governance_limits(None, None)  # Should not raise

    def test_token_budget_breach(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_tokens = 5000
        governance = {"max_global_tokens": 4000}

        with pytest.raises(ValueError, match="Global token budget breached"):
            wf.enforce_governance_limits(governance, None)

    def test_token_budget_within_limits(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_tokens = 3000
        governance = {"max_global_tokens": 4000}
        wf.enforce_governance_limits(governance, None)  # Should not raise

    def test_cost_budget_breach(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_cost = 50.0
        governance = {"max_budget_magnitude": 25.0}

        with pytest.raises(ValueError, match="Global budget magnitude breached"):
            wf.enforce_governance_limits(governance, None)

    def test_cost_budget_within_limits(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_cost = 10.0
        governance = {"max_budget_magnitude": 25.0}
        wf.enforce_governance_limits(governance, None)  # Should not raise


# ── Query Tests ────────────────────────────────────────────────────


class TestGetCurrentState:
    """Test the query handler for current state."""

    def test_no_envelope_returns_empty_dict(self) -> None:
        wf = BaseTopologyWorkflow()
        assert wf.get_current_state() == {}

    def test_with_envelope_returns_serialized(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()
        state = wf.get_current_state()
        assert "trace_context" in state
        assert "state_vector" in state
        assert "payload" in state
        assert state["trace_context"]["trace_cid"] is not None
        assert len(state["trace_context"]["trace_cid"]) >= 26


# Note: Signal handlers (receive_oracle_override, barge_in_interrupt, inject_oracle_resolution)
# and methods using workflow.logger (intercept_kinematic_intent, emit_mcp_ui_intent) require
# running inside a Temporal workflow context. They are tested via the DAG/speculative
# execution workflow integration tests with WorkflowEnvironment.start_time_skipping().

import concurrent.futures

import httpx
from fastapi import FastAPI
from temporalio import workflow
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import KineticActivities


@workflow.defn
class StubBaseTopologyWorkflow(BaseTopologyWorkflow):
    """Stub workflow for testing base signal handlers."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        await workflow.wait_condition(lambda: self._is_interrupted)
        return {"interrupted": True}


@pytest.mark.asyncio
async def test_base_topology_signals_natively(neo4j_container: Any) -> None:
    """Test BaseTopologyWorkflow signal logic mapped dynamically directly using physical substrate."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="base-signals-queue",
            workflows=[StubBaseTopologyWorkflow],
            activities=[
                activities.store_epistemic_state_io_activity,
                activities.emit_span_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                StubBaseTopologyWorkflow.run, {}, id="base-signals-test", task_queue="base-signals-queue"
            )
            import asyncio

            await asyncio.sleep(0.1)

            assert not await handle.query("is_interrupted")

            await handle.signal(
                BaseTopologyWorkflow.barge_in_interrupt,
                {
                    "event_cid": "barge-in-1",
                    "timestamp": 123456789.0,
                    "target_event_cid": "stub-cid",
                    "epistemic_disposition": "discard",
                },
            )

            await handle.signal(BaseTopologyWorkflow.receive_oracle_override, {"injected": True})

            import contextlib

            # Cancel to safely avoid strictly typed Pydantic deadlocking if it hasn't completed
            with contextlib.suppress(Exception):
                await handle.cancel()
            from temporalio.client import WorkflowFailureError

            with contextlib.suppress(WorkflowFailureError):
                res = await handle.result()
                assert res == {"interrupted": True}
            await asyncio.sleep(0.5)


# ── apply_state_delta Signal Test ─────────────────────────────────────


@workflow.defn
class ApplyDeltaWorkflow(BaseTopologyWorkflow):
    """Stub workflow that waits for apply_state_delta signal."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        # Wait until state_delta has been applied via signal
        await workflow.wait_condition(
            lambda: (
                (self._current_state_envelope.state_vector.mutable_matrix or {}).get("signal_applied")  # type: ignore[union-attr]
                is not None
            ),
        )
        from datetime import timedelta

        await workflow.sleep(timedelta(milliseconds=100))
        mm = self._current_state_envelope.state_vector.mutable_matrix or {}
        return {
            "signal_applied": mm.get("signal_applied"),
            "causal_clock": self._current_state_envelope.trace_context.causal_clock,
        }


@pytest.mark.asyncio
async def test_apply_state_delta_signal(neo4j_container: Any) -> None:
    """apply_state_delta signal updates mutable matrix and dispatches broadcast."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="delta-queue",
            workflows=[ApplyDeltaWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.broadcast_state_echo_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                ApplyDeltaWorkflow.run, {}, id="delta-test", task_queue="delta-queue"
            )

            import asyncio

            await asyncio.sleep(0.1)

            await handle.signal(
                BaseTopologyWorkflow.apply_state_delta,
                {"signal_applied": True},
            )

            result = await handle.result()
            assert result["signal_applied"] is True
            assert result["causal_clock"] >= 1


# ── inject_oracle_resolution Signal Test ──────────────────────────────


@workflow.defn
class OracleResolutionWorkflow(BaseTopologyWorkflow):
    """Stub workflow that waits for inject_oracle_resolution signal."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        await workflow.wait_condition(lambda: self._current_oracle_resolution is not None)
        from datetime import timedelta

        await workflow.sleep(timedelta(milliseconds=100))
        return {"resolution": self._current_oracle_resolution}


@pytest.mark.asyncio
async def test_inject_oracle_resolution_signal(neo4j_container: Any) -> None:
    """inject_oracle_resolution signal stores the payload."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="oracle-res-queue",
            workflows=[OracleResolutionWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.store_epistemic_state_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                OracleResolutionWorkflow.run, {}, id="oracle-res-test", task_queue="oracle-res-queue"
            )

            import asyncio

            await asyncio.sleep(0.1)

            await handle.signal(
                BaseTopologyWorkflow.inject_oracle_resolution,
                {"attestation": "biometric_verified", "operator_id": "dr_smith"},
            )

            result = await handle.result()
            assert result["resolution"]["attestation"] == "biometric_verified"


# ── emit_mcp_ui_intent Test ───────────────────────────────────────────


@workflow.defn
class EmitMCPIntentWorkflow(BaseTopologyWorkflow):
    """Stub workflow that exercises emit_mcp_ui_intent."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        await self.emit_mcp_ui_intent(
            intent_type="diagnostic_probe",
            context={"tool_name": "test_tool", "safety_level": "LOW"},
        )
        return {"emitted": True}


@pytest.mark.asyncio
async def test_emit_mcp_ui_intent(neo4j_container: Any) -> None:
    """emit_mcp_ui_intent dispatches BroadcastStateEchoIOActivity."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="mcp-intent-queue",
            workflows=[EmitMCPIntentWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.broadcast_state_echo_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            result = await env.client.execute_workflow(
                EmitMCPIntentWorkflow.run, {}, id="mcp-intent-test", task_queue="mcp-intent-queue"
            )
            assert result["emitted"] is True


# ── record_resource_utilization (Valid Usage) ───────────────────────────


@workflow.defn
class TokenBurnWorkflow(BaseTopologyWorkflow):
    """Stub workflow that exercises record_resource_utilization with valid token usage."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()

        # Exercise the happy path with valid prompt/completion tokens
        await self.record_resource_utilization(
            node_cid="did:agent:extractor-v1",
            usage={"prompt_tokens": 150, "completion_tokens": 42},
            cost=0.003,
        )

        # Verify internal accounting updated
        return {
            "accumulated_tokens": self._accumulated_tokens,
            "accumulated_cost": self._accumulated_cost,
            "burn_recorded": True,
        }


@pytest.mark.asyncio
async def test_record_resource_utilization_valid_usage(neo4j_container: Any) -> None:
    """Exercise TokenBurnReceipt creation with real Temporal activity dispatch."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="burn-queue",
            workflows=[TokenBurnWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            res = await env.client.execute_workflow(TokenBurnWorkflow.run, {}, id="burn-test", task_queue="burn-queue")
            assert res["burn_recorded"] is True


# ── Governance Enforcement (Real Temporal) ────────────────────────────


@workflow.defn
class GovernanceEnforcementWorkflow(BaseTopologyWorkflow):
    """Stub workflow that verifies governance limits inside a real Temporal execution.

    Exercises token budget, cost budget, and TTL enforcement
    within an actual workflow run — not just direct method calls.
    """

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        results: dict[str, Any] = {}

        # 1. Token budget enforcement (within limits — should pass)
        self._accumulated_tokens = 500
        self.enforce_governance_limits({"max_global_tokens": 1000}, None)
        results["token_within_limits"] = True

        # 2. Token budget enforcement (breached)
        self._accumulated_tokens = 1500
        try:
            self.enforce_governance_limits({"max_global_tokens": 1000}, None)
            results["token_breach_caught"] = False
        except ValueError:
            results["token_breach_caught"] = True

        # 3. Cost budget enforcement (within limits — should pass)
        self._accumulated_cost = 10.0
        self.enforce_governance_limits({"max_budget_magnitude": 50.0}, None)
        results["cost_within_limits"] = True

        # 4. Cost budget enforcement (breached)
        self._accumulated_cost = 100.0
        try:
            self.enforce_governance_limits({"max_budget_magnitude": 50.0}, None)
            results["cost_breach_caught"] = False
        except ValueError:
            results["cost_breach_caught"] = True

        # 5. Combined governance (both limits enforced simultaneously)
        self._accumulated_tokens = 200
        self._accumulated_cost = 5.0
        self.enforce_governance_limits({"max_global_tokens": 1000, "max_budget_magnitude": 50.0}, None)
        results["combined_within_limits"] = True

        return results


@pytest.mark.asyncio
async def test_governance_enforcement_in_temporal(neo4j_container: Any) -> None:
    """Verify governance enforcement executes correctly inside a real Temporal workflow."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="governance-queue",
            workflows=[GovernanceEnforcementWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.store_epistemic_state_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            res = await env.client.execute_workflow(
                GovernanceEnforcementWorkflow.run, {}, id="governance-test", task_queue="governance-queue"
            )
            assert res["token_within_limits"] is True
            assert res["token_breach_caught"] is True
            assert res["cost_within_limits"] is True
            assert res["cost_breach_caught"] is True
            assert res["combined_within_limits"] is True


# ── Coverage Sweep (Edge Cases) ───────────────────────────────────────


@workflow.defn
class CoverageSweepWorkflow(BaseTopologyWorkflow):
    """Stub workflow to sweep remaining native line coverage dynamically."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        from datetime import timedelta

        # 1. record_resource_utilization fallback (non-dictionary)
        await self.record_resource_utilization("dummy-node-id", "not-a-dict", 15.0)  # type: ignore

        # 2. enforce_governance_limits timeout breach
        start_time = workflow.now() - timedelta(seconds=10)
        import pytest

        with pytest.raises(ValueError, match="Global TTL breached"):
            self.enforce_governance_limits({"global_timeout_seconds": 5}, start_time)

        # 3. apply_state_delta without envelope
        self._current_state_envelope = None
        import pytest

        with pytest.raises(ValueError, match="active envelope"):
            await self.apply_state_delta({"testing": "value"})

        # 4. apply_state_delta with envelope (Happy Path)
        self._current_state_envelope = _build_envelope()
        await self.apply_state_delta({"new_mutable_key": "active_delta"})
        if (self._current_state_envelope.state_vector.mutable_matrix or {}).get("new_mutable_key") != "active_delta":
            raise ValueError("State delta not reconciled correctly.")

        # 5. intercept_kinematic_intent timeout (Physical Safety Interlock)
        import pytest

        with pytest.raises(PermissionError, match="Actuation blocked"):
            await self.intercept_kinematic_intent("ros2_bridge_move", {"target": "x"})

        # 6. intercept_kinematic_intent non-kinematic (Happy Path return)
        await self.intercept_kinematic_intent("non_kinematic_tool", {"test": "payload"})

        # 6. resilience_shock (Handle observability signal)
        await self.resilience_shock({"reason": "Test Observability Alarm", "severity": "warning"})
        if self._shock_reason != "Test Observability Alarm":
            raise ValueError("Resilience shock reason not stored correctly.")

        # 7. resilience_shock default payload
        await self.resilience_shock({})
        if self._shock_reason != "External Observability Alarm":
            raise ValueError("Resilience shock default reason not stored correctly.")

        return {"sweep": True}


@pytest.mark.asyncio
async def test_base_topology_coverage_sweep(neo4j_container: Any) -> None:
    """Validate timeout breaches, native exceptions, and physical safety limits inherently mapping to 100% coverage."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sweep-queue",
            workflows=[CoverageSweepWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.broadcast_state_echo_io_activity,
                activities.record_token_burn_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            res = await env.client.execute_workflow(
                CoverageSweepWorkflow.run, {}, id="sweep-test", task_queue="sweep-queue"
            )
            assert res["sweep"] is True


@workflow.defn
class KinematicSuccessWorkflow(BaseTopologyWorkflow):
    """Ensures Physical safety interlock can be unblocked actively via oracle resolutions."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        return await self.intercept_kinematic_intent("execute_se3_arm", {"target": "y", "tool_id": 123})


@pytest.mark.asyncio
async def test_base_topology_kinematic_success(neo4j_container: Any) -> None:
    """Confirms biometric intervention fulfills the contract accurately unblocking the wait condition cleanly."""
    app = FastAPI()
    transport = httpx.ASGITransport(app=app)

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        neo4j_user="neo4j",
        neo4j_password="password",  # noqa: S106
        gateway_url="http://gateway:8443",
        gateway_transport=transport,
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sweep-queue-2",
            workflows=[KinematicSuccessWorkflow],
            activities=[
                activities.emit_span_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.broadcast_state_echo_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                KinematicSuccessWorkflow.run, {}, id="sweep-test-2", task_queue="sweep-queue-2"
            )

            import asyncio

            await asyncio.sleep(0.1)

            # Send the Biometric Attestation Signal!
            await handle.signal(
                BaseTopologyWorkflow.inject_oracle_resolution, {"operator_id": "sysadmin-1", "biometric_verified": True}
            )

            res = await handle.result()
            assert res["safety_interlock_passed"] is True
