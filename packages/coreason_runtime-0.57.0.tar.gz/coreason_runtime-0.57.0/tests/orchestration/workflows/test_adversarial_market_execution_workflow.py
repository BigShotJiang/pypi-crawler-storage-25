# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for AdversarialMarketExecutionWorkflow.

Tests: full delegate-to-council path, governance passthrough.

All tests use Temporal time-skipping environments with physical stub activities — zero unittest.mock.
"""

import concurrent.futures
from typing import Any

import httpx
import pytest
from coreason_manifest import (
    AdversarialMarketTopologyManifest,
    ExecutionEnvelopeState,
)
from coreason_manifest.spec.ontology import (
    ObservationEvent,
    OracleExecutionReceipt,
    PredictionMarketPolicy,
    StateVectorProfile,
    TraceContextState,
)
from fastapi import FastAPI
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.orchestration.workflows.adversarial_market_execution_workflow import (
    AdversarialMarketExecutionWorkflow,
)
from coreason_runtime.orchestration.workflows.council_execution_workflow import (
    CouncilExecutionWorkflow,
)

# ── Physical Substrate Setup ─────────────────────────────────────────

app = FastAPI()


@app.post("/mcp/{server_cid}/tools/call")
async def mock_gateway_call(server_cid: str, payload: dict[str, Any]) -> "Any":
    """Return manifest-typed payload."""
    receipt = OracleExecutionReceipt(
        execution_hash="c" * 64,
        solver_urn="urn:coreason:solver:stub_adversarial_member",
        tokens_burned=15,
    )
    payload_resp = receipt.model_dump(mode="json")
    payload_resp["evidence"] = [
        ObservationEvent(
            event_cid="stub-adversarial-req",
            timestamp=123.0,
            payload={"result": True},
        ).model_dump(mode="json")
    ]
    payload_resp["intent_hash"] = "c" * 64
    payload_resp["usage"] = {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    payload_resp["cost"] = 0.01
    payload_resp["success"] = True
    return {"success": True, "outputs": payload_resp}


@app.get("/profiles")
async def mock_gateway_profiles() -> dict[str, list[str]]:
    return {"profiles": ["system_node", "urn:coreason:oracle:gateway"]}


# ── Envelope Factory ──────────────────────────────────────────────────


def _build_adversarial_envelope(
    governance: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build an ExecutionEnvelopeState for adversarial market topology.

    AdversarialMarketTopologyManifest requires: blue_team_cids, red_team_cids,
    adjudicator_cid, market_rules (PredictionMarketPolicy). It does NOT have a `nodes` field.
    The compile_to_base_topology() method synthesizes a CouncilTopologyManifest.
    """
    manifest = AdversarialMarketTopologyManifest(
        blue_team_cids=["did:coreason:blue-0", "did:coreason:blue-1"],
        red_team_cids=["did:coreason:red-0"],
        adjudicator_cid="did:coreason:adjudicator",
        market_rules=PredictionMarketPolicy(
            staking_function="linear",
            min_liquidity_magnitude=100,
            convergence_delta_threshold=0.01,
        ),
    )

    manifest_payload = manifest.model_dump(mode="json")
    if governance:
        manifest_payload["governance"] = governance

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H0000000000000000000000A",
            span_cid="01H0000000000000000000000B",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest_payload,
    )
    return envelope.model_dump(mode="json")


# ── Tests ─────────────────────────────────────────────────────────────


class TestAdversarialMarketExecutionWorkflow:
    """Physical Temporal tests for adversarial market workflow."""

    @pytest.mark.asyncio
    async def test_delegate_to_council_success(self, neo4j_container: "Any") -> None:
        """Adversarial market delegates to council and returns success."""
        payload = _build_adversarial_envelope()

        # Physical Activities with injected ASGITransport
        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="adversarial-q1",
                workflows=[AdversarialMarketExecutionWorkflow, CouncilExecutionWorkflow],
                activities=[
                    activities.emit_span_io_activity,
                    activities.execute_gateway_cognitive_activity,
                    activities.store_epistemic_state_io_activity,
                    activities.record_token_burn_io_activity,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    AdversarialMarketExecutionWorkflow.run,
                    payload,
                    id="adversarial-test-1",
                    task_queue="adversarial-q1",
                )

        assert result["status"] == "success"
