# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for HierarchicalDOMExecutionWorkflow.

Tests both the parse_spatial_blocks_activity (local activity / pure function)
and the full Temporal workflow via WorkflowEnvironment.start_time_skipping().

All tests use physically instantiated manifest models —
returning manifest-typed payloads — zero unittest.mock.
"""

import concurrent.futures
from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    ExecutionEnvelopeState,
    StateVectorProfile,
    TraceContextState,
)

# ── Pure Function Tests (parse_spatial_blocks_activity) ───────────────
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.hierarchical_dom_execution_workflow import (
    HierarchicalDOMExecutionWorkflow,
    parse_spatial_blocks_activity,
)


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


class TestParseSpatialBlocksActivity:
    """Physical tests for the local activity parsing nested DOM blocks."""

    def test_single_root_no_children(self) -> None:
        """Single root node with no children."""
        payload = {
            "nodes": {
                "root-1": {"type": "container", "spatial_bounds": {"x": 0, "y": 0}, "children": []},
            }
        }
        result = parse_spatial_blocks_activity(payload)

        assert result["total_nodes_parsed"] == 1
        assert result["parsed_spatial_blocks"][0]["node_cid"] == "root-1"
        assert result["parsed_spatial_blocks"][0]["depth"] == 0

    def test_nested_tree_depth(self) -> None:
        """Two-level tree: root → child."""
        payload = {
            "nodes": {
                "root": {"type": "container", "children": ["child-1"]},
                "child-1": {"type": "text", "children": []},
            }
        }
        result = parse_spatial_blocks_activity(payload)

        assert result["total_nodes_parsed"] == 2
        depths = {b["node_cid"]: b["depth"] for b in result["parsed_spatial_blocks"]}
        assert depths["root"] == 0
        assert depths["child-1"] == 1

    def test_multiple_roots(self) -> None:
        """Multiple roots (no parent) are all traversed."""
        payload: Any = {
            "nodes": {
                "root-a": {"children": []},
                "root-b": {"children": []},
            }
        }
        result = parse_spatial_blocks_activity(payload)

        assert result["total_nodes_parsed"] == 2
        cids = {b["node_cid"] for b in result["parsed_spatial_blocks"]}
        assert cids == {"root-a", "root-b"}

    def test_empty_nodes(self) -> None:
        """Empty nodes dict produces empty results."""
        result = parse_spatial_blocks_activity({"nodes": {}})
        assert result["total_nodes_parsed"] == 0
        assert result["parsed_spatial_blocks"] == []

    def test_three_level_tree(self) -> None:
        """Three-level nested structure."""
        payload = {
            "nodes": {
                "page": {"children": ["section"]},
                "section": {"children": ["paragraph"]},
                "paragraph": {"children": []},
            }
        }
        result = parse_spatial_blocks_activity(payload)

        assert result["total_nodes_parsed"] == 3
        depths = {b["node_cid"]: b["depth"] for b in result["parsed_spatial_blocks"]}
        assert depths["page"] == 0
        assert depths["section"] == 1
        assert depths["paragraph"] == 2

    def test_missing_child_reference(self) -> None:
        """Child CID not in nodes dict is silently skipped."""
        payload = {
            "nodes": {
                "root": {"children": ["missing-child"]},
            }
        }
        result = parse_spatial_blocks_activity(payload)

        assert result["total_nodes_parsed"] == 1


# ── Temporal Workflow Tests ───────────────────────────────────────────


def _build_dom_envelope(nodes: dict[str, Any]) -> dict[str, Any]:
    """Build a physically validated ExecutionEnvelopeState for the DOM workflow."""
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H00000000000000000000000",
            span_cid="01H00000000000000000000001",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload={"nodes": nodes},
    )
    return envelope.model_dump(mode="json")


class TestHierarchicalDOMWorkflow:
    """Physical Temporal tests for HierarchicalDOMExecutionWorkflow."""

    @pytest.mark.asyncio
    async def test_workflow_parses_dom_tree(self) -> None:
        """Workflow processes a two-level DOM tree."""
        payload = _build_dom_envelope(
            {
                "header": {"type": "header", "children": ["title"]},
                "title": {"type": "text", "children": []},
            }
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="dom-test-queue",
                workflows=[HierarchicalDOMExecutionWorkflow],
                activities=[stub_emit_span, parse_spatial_blocks_activity],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    HierarchicalDOMExecutionWorkflow.run,
                    payload,
                    id="dom-test-workflow",
                    task_queue="dom-test-queue",
                )

        assert result["success"] is True
        assert result["total_nodes"] == 2
        assert "hierarchical_dom_" in result["manifest"]["server_cid"]

    @pytest.mark.asyncio
    async def test_workflow_empty_dom(self) -> None:
        """Workflow handles empty DOM gracefully."""
        payload = _build_dom_envelope({})

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="dom-empty-queue",
                workflows=[HierarchicalDOMExecutionWorkflow],
                activities=[stub_emit_span, parse_spatial_blocks_activity],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    HierarchicalDOMExecutionWorkflow.run,
                    payload,
                    id="dom-empty-test",
                    task_queue="dom-empty-queue",
                )

        assert result["success"] is True
        assert result["total_nodes"] == 0
