# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import httpx
import pytest
from fastapi import FastAPI
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.orchestration.workflows.capability_forge_execution_workflow import (
    CapabilityForgeExecutionWorkflow,
)

# ── Physical Substrate Setup ─────────────────────────────────────────

app = FastAPI()


@app.post("/mcp/{server_cid}/tools/call")
async def mock_gateway_call(server_cid: str, payload: dict[str, Any]) -> "Any":
    """Physical FastAPI endpoint for MasterGateway bridge testing."""
    name = payload.get("name")
    args = payload.get("arguments", {})

    if name == "deploy_cognitive_topology":
        schema_requested = args.get("schema_to_request", "AgentResponse")
        if schema_requested == "VerificationYield":
            return {
                "success": True,
                "outputs": {"success": True, "justification": "Looks good"},
                "usage": {"total_tokens": 5},
                "cost": 0.01,
                "request_cid": "testhash",
            }
        # Default Generator/Agent Response
        return {
            "success": True,
            "outputs": {"output": '{"scaffold_type": "scaffold_logic_actuator"}'},
            "usage": {"total_tokens": 10},
            "cost": 0.05,
            "request_cid": "testhash",
        }

    return {"success": True, "receipt": {"success": True}, "status": "success", "intent_hash": "mcp_hash"}


@app.get("/profiles")
async def mock_gateway_profiles() -> dict[str, list[str]]:
    return {"profiles": ["system_node", "urn:coreason:oracle:gateway"]}


# ── Tests ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_bipartite(neo4j_container: "Any") -> None:
    """Test the full bipartite forge loop with physical substrates."""
    manifest_payload = {
        "nodes": {
            "did:coreason:generator_1": {
                "topology_class": "agent",
                "description": "Generator node",
            },
            "did:coreason:verifier_1": {
                "topology_class": "agent",
                "description": "Verifier node",
            },
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:generator_1",
        "formal_verifier_cid": "did:coreason:verifier_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    # Physical Activities with injected ASGITransport
    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                activities.execute_gateway_cognitive_activity,
                activities.execute_mcp_tool_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf",
                task_queue="capability-forge-test",
            )
            assert result["status"] == "success"
            results = result["results"]
            assert results[0]["type"] == "generation"
            assert results[1]["type"] == "verification"
            assert results[2]["type"] == "forge_proxy"
            assert results[3]["type"] == "promotion"


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_no_verifier(neo4j_container: "Any") -> None:
    """Test forge loop without a verifier node (skips verification step)."""
    manifest_payload = {
        "nodes": {
            "did:coreason:generator_1": {
                "topology_class": "agent",
                "description": "Generator node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:generator_1",
        "formal_verifier_cid": "did:coreason:none",
        "fuzzing_engine_cid": "did:coreason:none_fuzz",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test-no-ver",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                activities.execute_gateway_cognitive_activity,
                activities.execute_mcp_tool_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf-no-ver",
                task_queue="capability-forge-test-no-ver",
            )
            assert result["status"] == "success"
            results = result["results"]
            assert len(results) == 3  # generation, forge_proxy, promotion
            assert results[0]["type"] == "generation"
            assert results[1]["type"] == "forge_proxy"
            assert results[2]["type"] == "promotion"


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_hallucination_prevention(neo4j_container: "Any") -> None:
    """Test that the workflow prevents CID hallucination by ensuring node uniqueness."""
    manifest_payload = {
        "nodes": {
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:fuzz_1",
        "formal_verifier_cid": "did:coreason:fuzz_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    activities = KineticActivities(
        memory_path=neo4j_container.get_connection_url(),
        gateway_url="http://gateway-bridge",
        gateway_transport=httpx.ASGITransport(app=app),
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test-halluc",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                activities.execute_gateway_cognitive_activity,
                activities.execute_mcp_tool_io_activity,
                activities.store_epistemic_state_io_activity,
                activities.record_token_burn_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            handle = await env.client.start_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf-halluc",
                task_queue="capability-forge-test-halluc",
            )
            await handle.signal(CapabilityForgeExecutionWorkflow.approve_forge, "yes")
            result = await handle.result()
            assert result["status"] == "success"
