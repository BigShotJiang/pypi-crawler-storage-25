# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for ConsensusFederationExecutionWorkflow.

Tests the zero-cost macro that compiles a ConsensusFederationTopologyManifest
into a CouncilTopologyManifest and delegates via child workflow execution.

All tests use Temporal time-skipping environments with physical substrate
returning manifest-typed payloads — zero unittest.mock.
"""

import concurrent.futures
from typing import Any

import httpx
import pytest
from coreason_manifest import (
    ConsensusFederationTopologyManifest,
    ExecutionEnvelopeState,
)
from coreason_manifest.spec.ontology import (
    ObservationEvent,
    OracleExecutionReceipt,
    QuorumPolicy,
    StateVectorProfile,
    TraceContextState,
)
from fastapi import FastAPI
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.orchestration.workflows.consensus_federation_execution_workflow import (
    ConsensusFederationExecutionWorkflow,
)
from coreason_runtime.orchestration.workflows.council_execution_workflow import (
    CouncilExecutionWorkflow,
)

# ── Physical Substrate Setup ─────────────────────────────────────────

app = FastAPI()


@app.post("/mcp/{server_cid}/tools/call")
async def mock_gateway_call(server_cid: str, payload: dict[str, "Any"]) -> dict[str, "Any"]:
    """Return a physically validated OracleExecutionReceipt payload."""
    receipt = OracleExecutionReceipt(
        execution_hash="c" * 64,
        solver_urn="urn:coreason:solver:stub_federation_member",
        tokens_burned=8,
    )
    payload_resp = receipt.model_dump(mode="json")
    payload_resp["evidence"] = [
        ObservationEvent(
            event_cid="stub-federation-req",
            timestamp=123.0,
            payload={"result": True},
        ).model_dump(mode="json")
    ]
    payload_resp["intent_hash"] = "c" * 64
    payload_resp["usage"] = {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8}
    payload_resp["cost"] = 0.005
    payload_resp["success"] = True
    return payload_resp


@app.get("/profiles")
async def mock_gateway_profiles() -> dict[str, list[str]]:
    return {"profiles": ["system_node", "urn:coreason:oracle:gateway"]}


# ── Manifest Model Factories ──────────────────────────────────────────


def _build_federation_envelope(
    participant_count: int = 3,
) -> dict[str, Any]:
    """Construct a physically validated ExecutionEnvelopeState for a consensus federation.

    Instantiates ConsensusFederationTopologyManifest with the specified number
    of participants plus an adjudicator, wraps in ExecutionEnvelopeState.
    """
    participant_cids = [f"did:coreason:participant-{i}" for i in range(participant_count)]
    adjudicator_cid = "did:coreason:federation-adjudicator"

    quorum = QuorumPolicy(
        max_tolerable_faults=0,
        min_quorum_size=participant_count,  # BFT: N >= 3f + 1, where f=0 → N >= 1
        state_validation_metric="ledger_hash",
        byzantine_action="quarantine",
    )

    manifest = ConsensusFederationTopologyManifest(
        participant_cids=participant_cids,
        adjudicator_cid=adjudicator_cid,
        quorum_rules=quorum,
    )

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H0000000000000000000000A",
            span_cid="01H0000000000000000000000B",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )

    return envelope.model_dump(mode="json")


# ── Consensus Federation Execution Tests ───────────────────────────────


class TestConsensusFederationExecutionWorkflow:
    """Physical Temporal tests for the federation macro → council delegation."""

    @pytest.mark.asyncio
    async def test_federation_compiles_and_delegates(self, neo4j_container: "Any") -> None:
        """Federation compiles to council and executes successfully."""
        payload = _build_federation_envelope(participant_count=3)

        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="federation-test-queue",
                workflows=[ConsensusFederationExecutionWorkflow, CouncilExecutionWorkflow],
                activities=[
                    activities.emit_span_io_activity,
                    activities.execute_gateway_cognitive_activity,
                    activities.store_epistemic_state_io_activity,
                    activities.record_token_burn_io_activity,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    ConsensusFederationExecutionWorkflow.run,
                    payload,
                    id="federation-compile-test",
                    task_queue="federation-test-queue",
                )

        assert result["status"] == "success"
        assert "results" in result
        # Federation compiled: 3 participants + 1 adjudicator = 4 council nodes
        assert len(result["results"]) == 4

    @pytest.mark.asyncio
    async def test_child_workflow_id_pattern(self, neo4j_container: "Any") -> None:
        """Child workflow ID follows {parent_id}-council-delegate pattern."""
        payload = _build_federation_envelope(participant_count=3)

        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="federation-id-queue",
                workflows=[ConsensusFederationExecutionWorkflow, CouncilExecutionWorkflow],
                activities=[
                    activities.emit_span_io_activity,
                    activities.execute_gateway_cognitive_activity,
                    activities.store_epistemic_state_io_activity,
                    activities.record_token_burn_io_activity,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                # Execute and verify no crash (child ID validation is implicit)
                result = await env.client.execute_workflow(
                    ConsensusFederationExecutionWorkflow.run,
                    payload,
                    id="federation-id-test",
                    task_queue="federation-id-queue",
                )

        assert result["status"] == "success"

    @pytest.mark.asyncio
    async def test_three_participant_federation(self, neo4j_container: "Any") -> None:
        """Federation with 3 participants compiles to 4-node council."""
        payload = _build_federation_envelope(participant_count=3)

        activities = KineticActivities(
            memory_path=neo4j_container.get_connection_url(),
            gateway_url="http://gateway-bridge",
            gateway_transport=httpx.ASGITransport(app=app),
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="federation-3p-queue",
                workflows=[ConsensusFederationExecutionWorkflow, CouncilExecutionWorkflow],
                activities=[
                    activities.emit_span_io_activity,
                    activities.execute_gateway_cognitive_activity,
                    activities.store_epistemic_state_io_activity,
                    activities.record_token_burn_io_activity,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    ConsensusFederationExecutionWorkflow.run,
                    payload,
                    id="federation-3p-test",
                    task_queue="federation-3p-queue",
                )

        assert result["status"] == "success"
        # 3 participants + 1 adjudicator = 4 nodes
        assert len(result["results"]) == 4
