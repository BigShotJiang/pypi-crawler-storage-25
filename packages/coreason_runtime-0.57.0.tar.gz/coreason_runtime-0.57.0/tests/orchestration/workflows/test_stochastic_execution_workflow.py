# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>
import pytest
from coreason_manifest.spec.ontology import IdeationPhaseProfile


@pytest.fixture
def mock_manifest_payload() -> dict[str, Any]:
    """Provides a structurally sound StochasticTopologyManifest payload dict."""
    return {
        "topology_cid": "stoch_topo_1",
        "phase": IdeationPhaseProfile.STOCHASTIC_DIFFUSION,
        "stochastic_graph": [
            {
                "node_cid": "branch_A",
                "agent_role": "generator",
                "stochastic_tensor": "test logic 1",
                "epistemic_entropy": 0.5,
            },
            {
                "node_cid": "branch_B",
                "agent_role": "critic",
                "stochastic_tensor": "test logic 2",
                "epistemic_entropy": 0.2,
            },
        ],
        "superposition": {
            "superposition_cid": "sup_1",
            "wave_collapse_function": "highest_confidence",
            "competing_manifolds": {
                "branch_A": 0.8,
                "branch_B": 0.2,
            },
        },
    }


# Markov Blanket tests removed as logic is delegated to MasterGateway


import httpx
from fastapi import FastAPI
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.stochastic_execution_workflow import (
    StochasticActivities,
    StochasticExecutionWorkflow,
)


@pytest.mark.asyncio
async def test_stochastic_workflow_execution(mock_manifest_payload: dict[str, Any]) -> None:
    """Validate StochasticExecutionWorkflow correctly delegates to MasterGateway transition activities using physical substrate."""
    app = FastAPI()

    @app.post("/mcp/urn:coreason:oracle:gateway/transition/predict")
    async def predict_endpoint(request: dict[str, Any]) -> dict[str, Any]:
        return {"target_branch": "branch_A"}

    transport = httpx.ASGITransport(app=app)
    activities = StochasticActivities(gateway_url="http://gateway:8443", gateway_transport=transport)

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="stoch-queue",
            workflows=[StochasticExecutionWorkflow],
            activities=[activities.evaluate_transition_probability_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                StochasticExecutionWorkflow.run,
                mock_manifest_payload,
                id="stoch-test",
                task_queue="stoch-queue",
            )

    assert result["status"] == "stochastic_execution_completed"
    assert result["traversed_branch"] == "branch_A"
