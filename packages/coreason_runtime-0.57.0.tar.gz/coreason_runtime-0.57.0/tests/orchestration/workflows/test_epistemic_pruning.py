# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from coreason_runtime.orchestration.workflows.epistemic_pruning_workflow import (
    EpistemicPruningWorkflow,
)


@pytest.mark.asyncio
async def test_epistemic_pruning_evaluates_correct_protected_bounds() -> None:
    """Verifies that mathematical decay ignores perfectly matched protected CIDs natively."""

    @activity.defn(name="evaluate_and_decay_salience_activity")
    async def mock_evaluate_activity(payload: dict[str, Any]) -> int:
        assert "eviction_policy" in payload
        assert payload["eviction_policy"]["protected_event_cids"] == ["cid-alpha-99", "cid-beta-77"]
        assert payload["salience"]["decay_rate"] == 0.05
        return 50

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="epistemic-pruning-tasks",
            workflows=[EpistemicPruningWorkflow],
            activities=[stub_emit_span, mock_evaluate_activity],
        ):
            from coreason_runtime.orchestration.workflows.epistemic_pruning_workflow import (
                EpistemicPruningPayloadDict,
            )

            payload: EpistemicPruningPayloadDict = {
                "eviction_policy": {
                    "strategy": "salience_decay",
                    "max_retained_tokens": 5000,
                    "protected_event_cids": ["cid-alpha-99", "cid-beta-77"],
                },
                "salience": {"baseline_importance": 1.0, "decay_rate": 0.05},
            }

            result = await env.client.execute_workflow(
                EpistemicPruningWorkflow.run,
                payload,
                id="epistemic-pruning-run-001",
                task_queue="epistemic-pruning-tasks",
            )

            assert result["status"] == "epistemic_pruning_complete"
            assert result["purged_vector_count"] == 50
            assert result["pruned_dimensions"] == 50 * 1536

            # Verify exactly parsed payload parameters into target functions
            # Assertion is done inside mock_evaluate_activity


from temporalio import activity


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@pytest.mark.asyncio
async def test_epistemic_pruning_evaluates_empty_payload() -> None:
    """Verifies that an empty payload leverages the internal default instantiation limits."""

    @activity.defn(name="evaluate_and_decay_salience_activity")
    async def mock_evaluate_activity(payload: dict[str, Any]) -> int:
        # Validate that the defaults were natively injected inside the workflow bounds
        assert "eviction_policy" in payload
        assert "salience" in payload
        assert payload["eviction_policy"]["strategy"] == "salience_decay"
        assert payload["salience"]["baseline_importance"] == 1.0
        return 10

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="epistemic-pruning-empty",
            workflows=[EpistemicPruningWorkflow],
            activities=[stub_emit_span, mock_evaluate_activity],
        ):
            from coreason_runtime.orchestration.workflows.epistemic_pruning_workflow import (
                EpistemicPruningPayloadDict,
            )

            payload: EpistemicPruningPayloadDict = {}

            result = await env.client.execute_workflow(
                EpistemicPruningWorkflow.run,
                payload,
                id="epistemic-pruning-run-empty",
                task_queue="epistemic-pruning-empty",
            )

            assert result["status"] == "epistemic_pruning_complete"
            assert result["purged_vector_count"] == 10
            assert result["pruned_dimensions"] == 10 * 1536
