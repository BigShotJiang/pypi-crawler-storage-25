# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for SpatialTaxonomicRestructureWorkflow."""

from typing import Any

import pytest
from coreason_manifest.spec.ontology import DerivationModeProfile, EpistemicSecurityPolicy
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.spatial_taxonomic_restructure_workflow import (
    SpatialTaxonomicRestructureWorkflow,
)


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="BroadcastStateEchoIOActivity")
async def mock_broadcast_echo(event_type: str, payload: dict[str, Any]) -> None:
    pass


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state(
    workflow_id: str, event_cid: str, success: bool, holographic_payload: dict[str, Any], event_dict: dict[str, Any]
) -> None:
    pass


@pytest.mark.asyncio
async def test_spatial_taxonomic_restructure_workflow_success() -> None:
    """Test the full progression of the taxonomic restructuring workflow."""
    payload = {
        "restructure_heuristic": "semantic_cluster",
        "target_taxonomy": {
            "manifest_cid": "tax_test_1",
            "root_node_cid": "node1",
            "nodes": {"node1": {"node_cid": "node1", "semantic_label": "concept"}},
        },
    }

    # Needs to match coreason_manifest.spec.ontology.WorkflowManifest
    manifest_payload = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "extracted_by": "did:coreason:agent01",
            "source_event_cid": "src",
            "derivation_mode": DerivationModeProfile.DIRECT_TRANSLATION,
        },
        "topology": {
            "topology_class": "evolutionary",
            "generations": 1,
            "population_size": 1,
            "mutation": {"mutation_rate": 0.1, "temperature_shift_variance": 0.1, "verifiable_entropy": None},
            "crossover": {"strategy_profile": "uniform_blend", "blending_factor": 0.1, "verifiable_entropy": None},
            "fitness_objectives": [{"target_metric": "acc", "direction": "maximize", "weight": 1.0}],
            "epistemic_enforcement": {
                "decay_propagation_rate": 0.1,
                "epistemic_quarantine_threshold": 0.5,
                "enforce_cross_agent_quarantine": False,
                "max_cascade_depth": 1,
                "max_quarantine_blast_radius": 1,
                "retroactive_falsification_mode": "cap_validity",
            },
            "lifecycle_phase": "live",
            "architectural_intent": "test",
            "justification": None,
            "nodes": {
                "did:coreason:agent01": {
                    "architectural_intent": None,
                    "justification": None,
                    "intervention_policies": [],
                    "description": "test",
                    "topology_class": "agent",
                    "hardware": {
                        "compute_tier": "urn:coreason:compute_tier:kinetic",
                        "min_vram_gb": 8.0,
                        "accelerator_type": "urn:coreason:accelerator:bf16_tensor",
                        "provider_whitelist": ["aws"],
                    },
                    "security": {
                        "epistemic_security": EpistemicSecurityPolicy.STANDARD,
                        "network_isolation": False,
                        "egress_obfuscation": False,
                    },
                    "action_space_cid": "act1",
                }
            },
        },
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="taxonomic-test-queue",
            workflows=[SpatialTaxonomicRestructureWorkflow],
            activities=[stub_emit_span, mock_broadcast_echo, mock_store_epistemic_state],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                SpatialTaxonomicRestructureWorkflow.run,
                args=[payload, manifest_payload],
                id="test-val-wf-tax-1",
                task_queue="taxonomic-test-queue",
            )
            assert result["status"] == "success"
            assert "event_id" in result
