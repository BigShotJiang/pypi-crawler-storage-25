# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import concurrent.futures
from pathlib import Path
from typing import Any

import pytest
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.active_inference_execution_workflow import (
    ActiveInferenceExecutionWorkflow,
    ActiveInferencePayload,
    evaluate_surprise_compute_activity,
    flush_receipts_to_ledger_activity,
    update_latent_belief_activity,
)


@pytest.mark.asyncio
async def test_active_inference_workflow_valid_policy() -> None:
    """Verifies that a valid epistemic reward policy is validated and processed correctly."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-valid-queue",
            workflows=[ActiveInferenceExecutionWorkflow],
            activities=[
                evaluate_surprise_compute_activity,
                update_latent_belief_activity,
                flush_receipts_to_ledger_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload: ActiveInferencePayload = {
                "active_inference_epochs": 1,
                "contract": {"threshold": 0.8},
                "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
                "free_energy": 0.5,
                "epistemic_reward_policy": {
                    "pruning_threshold": 0.9,
                    "max_backtracks_allowed": 5,
                    "evaluator_matrix_name": "eval_2",
                    "convergence_sla": {
                        "convergence_delta_epsilon": 0.05,
                        "lookback_window_steps": 3,
                        "minimum_reasoning_steps": 5,
                    },
                },
            }

            result = await env.client.execute_workflow(
                ActiveInferenceExecutionWorkflow.run,
                payload,
                id="active-inference-valid-run",
                task_queue="active-inference-valid-queue",
            )

            assert result["success"] is True
            assert result["epochs_run"] == 1


@pytest.mark.asyncio
async def test_active_inference_workflow_validation_error_fallback() -> None:
    """Verifies that a policy failing Pydantic validation falls back to dict access gracefully."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-fallback-queue",
            workflows=[ActiveInferenceExecutionWorkflow],
            activities=[
                evaluate_surprise_compute_activity,
                update_latent_belief_activity,
                flush_receipts_to_ledger_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            # Invalid max_backtracks_allowed type (should be an int) triggers ValidationError
            payload: ActiveInferencePayload = {
                "active_inference_epochs": 1,
                "contract": {"threshold": 0.8},
                "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
                "free_energy": 0.5,
                "epistemic_reward_policy": {
                    "pruning_threshold": 0.9,
                    "max_backtracks_allowed": "not-an-int-value",
                    "convergence_sla": {
                        "convergence_delta_epsilon": 0.05,
                        "lookback_window_steps": 3,
                        "minimum_reasoning_steps": 5,
                    },
                },
            }

            result = await env.client.execute_workflow(
                ActiveInferenceExecutionWorkflow.run,
                payload,
                id="active-inference-fallback-run",
                task_queue="active-inference-fallback-queue",
            )

            assert result["success"] is True
            assert result["epochs_run"] == 1


from coreason_manifest.spec.ontology import ProcessRewardContract


@pytest.mark.asyncio
async def test_active_inference_workflow_unanticipated_exception(monkeypatch: pytest.MonkeyPatch) -> None:
    """Verifies that unanticipated system exceptions fail the workflow with ManifestConformanceError."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-fault-queue",
            workflows=[ActiveInferenceExecutionWorkflow],
            activities=[
                evaluate_surprise_compute_activity,
                update_latent_belief_activity,
                flush_receipts_to_ledger_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload: ActiveInferencePayload = {
                "active_inference_epochs": 1,
                "contract": {"threshold": 0.8},
                "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
                "free_energy": 0.5,
                "epistemic_reward_policy": {
                    "pruning_threshold": 0.9,
                    "max_backtracks_allowed": 5,
                    "convergence_sla": {
                        "convergence_delta_epsilon": 0.05,
                        "lookback_window_steps": 3,
                        "minimum_reasoning_steps": 5,
                    },
                },
            }

            def faulty_validate(*args: Any, **kwargs: Any) -> Any:
                raise RuntimeError("Simulated database/system failure during validation")

            monkeypatch.setattr(ProcessRewardContract, "model_validate", faulty_validate)

            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    ActiveInferenceExecutionWorkflow.run,
                    payload,
                    id="active-inference-fault-run",
                    task_queue="active-inference-fault-queue",
                )

            # Ensure the underlying exception was propagated and wrapped as a ManifestConformanceError
            assert "ManifestConformanceError" in str(exc_info.value.cause)
            assert "Governance Configuration Fault" in str(exc_info.value.cause)


@pytest.mark.asyncio
async def test_active_inference_workflow_oracle_receipts_propagation() -> None:
    """Verifies that OracleExecutionReceipts are aggregated and returned inside WorkflowResult."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-receipts-queue",
            workflows=[ActiveInferenceExecutionWorkflow],
            activities=[
                evaluate_surprise_compute_activity,
                update_latent_belief_activity,
                flush_receipts_to_ledger_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload: ActiveInferencePayload = {
                "active_inference_epochs": 2,  # Run 2 epochs to generate 2 receipts
                "contract": {"threshold": 0.8},
                "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
                "free_energy": 0.5,
            }

            result = await env.client.execute_workflow(
                ActiveInferenceExecutionWorkflow.run,
                payload,
                id="active-inference-receipts-run",
                task_queue="active-inference-receipts-queue",
            )

            assert result["success"] is True
            assert result["epochs_run"] == 2
            assert "oracle_receipts" in result
            assert len(result["oracle_receipts"]) == 0


@pytest.mark.asyncio
async def test_active_inference_workflow_epoch_cascade_prevention() -> None:
    """Verifies that running multi-epoch workflows decrements epochs correctly and completes execution."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-cascade-queue",
            workflows=[ActiveInferenceExecutionWorkflow],
            activities=[
                evaluate_surprise_compute_activity,
                update_latent_belief_activity,
                flush_receipts_to_ledger_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload: ActiveInferencePayload = {
                "active_inference_epochs": 3,
                "contract": {"threshold": 0.8},
                "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
                "free_energy": 0.5,
            }

            result = await env.client.execute_workflow(
                ActiveInferenceExecutionWorkflow.run,
                payload,
                id="active-inference-cascade-run",
                task_queue="active-inference-cascade-queue",
            )

            assert result["success"] is True
            assert result["epochs_run"] == 3
            assert len(result["oracle_receipts"]) == 0


@pytest.mark.asyncio
async def test_active_inference_workflow_monotonic_epoch_decrement(monkeypatch: pytest.MonkeyPatch) -> None:
    """Assert remaining epoch sizes match completed runs across continue_as_new boundaries."""
    from temporalio import workflow

    class MockInfo:
        def get_current_history_length(self) -> int:
            return 100

    class MockLogger:
        def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
            pass

        def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
            pass

        def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
            pass

    async def mock_execute_activity(activity_fn: Any, payload: Any, **kwargs: Any) -> Any:
        if "evaluate_surprise_compute" in activity_fn.__name__:
            return {"free_energy": 0.5, "novel_surprise_factor": 0.8}
        return {"belief_updated": True, "variational_free_energy_reduction": 0.5}

    continue_as_new_called_with = []

    def mock_continue_as_new(payload: Any) -> None:
        continue_as_new_called_with.append(payload)

    monkeypatch.setattr(workflow, "info", MockInfo)
    monkeypatch.setattr(workflow.logger, "info", MockLogger().info)
    monkeypatch.setattr(workflow, "execute_activity", mock_execute_activity)
    monkeypatch.setattr(workflow, "continue_as_new", mock_continue_as_new)

    workflow_instance = ActiveInferenceExecutionWorkflow()
    payload: ActiveInferencePayload = {
        "active_inference_epochs": 5,
        "contract": {"threshold": 0.8},
        "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
        "free_energy": 0.5,
    }

    await workflow_instance.run(payload)
    assert len(continue_as_new_called_with) == 1
    passed_payload = continue_as_new_called_with[0]
    assert passed_payload["active_inference_epochs"] == 4  # Monotonic decrement: 5 - (0 + 1) = 4


@pytest.mark.asyncio
async def test_active_inference_workflow_receipts_batch_flushing_real(tmp_path: Path) -> None:
    """Verifies that when oracle_receipts count reaches 25, they are flushed to the real LanceDB database."""
    import os

    import lancedb  # type: ignore[import-untyped]

    db_uri = str(tmp_path / "epistemic_cache.lance")
    os.environ["SIMULATE_URN_AUTHORITY_TIMEOUT"] = "true"
    os.environ["LANCEDB_URI"] = db_uri

    try:
        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="active-inference-batch-queue",
                workflows=[ActiveInferenceExecutionWorkflow],
                activities=[
                    evaluate_surprise_compute_activity,
                    update_latent_belief_activity,
                    flush_receipts_to_ledger_activity,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                payload: ActiveInferencePayload = {
                    "active_inference_epochs": 27,  # Will result in 27 receipts, triggering flushes
                    "contract": {"threshold": 0.8},
                    "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
                    "free_energy": 0.5,
                }

                result = await env.client.execute_workflow(
                    ActiveInferenceExecutionWorkflow.run,
                    payload,
                    id="active-inference-batch-run",
                    task_queue="active-inference-batch-queue",
                )

                assert result["success"] is True
                assert len(result["oracle_receipts"]) == 0

                # Verify actual side effects in the real LanceDB cache
                db = await lancedb.connect_async(db_uri)
                table = await db.open_table("oracle_receipt_buffer")
                df = (await table.to_arrow()).to_pandas()
                assert len(df) == 27
    finally:
        os.environ.pop("SIMULATE_URN_AUTHORITY_TIMEOUT", None)
        os.environ.pop("LANCEDB_URI", None)


@pytest.mark.asyncio
async def test_active_inference_workflow_high_epochs_flushing_real(tmp_path: Path) -> None:
    """Verify that a 100-epoch execution triggers real flushes to the LanceDB database."""
    import os

    import lancedb  # type: ignore[import-untyped]

    db_uri = str(tmp_path / "epistemic_cache_high.lance")
    os.environ["SIMULATE_URN_AUTHORITY_TIMEOUT"] = "true"
    os.environ["LANCEDB_URI"] = db_uri

    try:
        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="active-inference-high-epochs-queue",
                workflows=[ActiveInferenceExecutionWorkflow],
                activities=[
                    evaluate_surprise_compute_activity,
                    update_latent_belief_activity,
                    flush_receipts_to_ledger_activity,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                payload: ActiveInferencePayload = {
                    "active_inference_epochs": 100,  # 100 receipts
                    "contract": {"threshold": 0.8},
                    "epoch_state": {"belief_matrix": [0.1, 0.2, 0.7]},
                    "free_energy": 0.5,
                }

                result = await env.client.execute_workflow(
                    ActiveInferenceExecutionWorkflow.run,
                    payload,
                    id="active-inference-high-epochs-run",
                    task_queue="active-inference-high-epochs-queue",
                )

                assert result["success"] is True
                assert len(result["oracle_receipts"]) == 0

                # Verify actual side effects in the real LanceDB cache
                db = await lancedb.connect_async(db_uri)
                table = await db.open_table("oracle_receipt_buffer")
                df = (await table.to_arrow()).to_pandas()
                assert len(df) == 100
    finally:
        os.environ.pop("SIMULATE_URN_AUTHORITY_TIMEOUT", None)
        os.environ.pop("LANCEDB_URI", None)


@pytest.mark.asyncio
async def test_flush_receipts_to_ledger_activity_fallback(tmp_path: Path) -> None:
    """Assert that the activity interceptor triggers fallback rules smoothly under network partition."""
    import os

    os.environ["SIMULATE_URN_AUTHORITY_TIMEOUT"] = "true"
    os.environ["LANCEDB_URI"] = str(tmp_path / "test_epistemic_cache.lance")
    try:
        receipts = [{"solver_urn": "test", "execution_hash": "abc"}]
        result = await flush_receipts_to_ledger_activity(receipts)
        assert result == "LOCAL_LANCEDB_CACHE_SUCCESS"
    finally:
        os.environ.pop("SIMULATE_URN_AUTHORITY_TIMEOUT", None)
        os.environ.pop("LANCEDB_URI", None)
