# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for Hollow Plane Bridging workflow."""

import os
import tempfile
from typing import Any

import coreason_manifest.spec.ontology as o
import lancedb  # type: ignore[import-untyped]
import pytest
from neo4j import AsyncGraphDatabase
from pydantic import BaseModel, ConfigDict
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.migration_activities import (
    MigrationRequestPayload,
    rehydrate_agent_state_activity,
    serialize_agent_state_activity,
)
from coreason_runtime.orchestration.workflows.hollow_plane_bridge_workflow import (
    HollowPlaneBridgeWorkflow,
    cross_dimensional_state_projector_activity,
    verify_tensor_boundary_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


class MockHollowPlaneBridge(BaseModel):
    target_plane: str
    model_config = ConfigDict(extra="ignore")


class MockObserverPhysics(BaseModel):
    spatial_offset: float
    model_config = ConfigDict(extra="ignore")


class MockNDimensionalTensorManifest(BaseModel):
    merkle_root: str
    shape: list[int]
    structural_format: str
    model_config = ConfigDict(extra="ignore")


# Backwards mock injecting to prevent import failures directly
o.HollowPlaneBridge = MockHollowPlaneBridge  # type: ignore
o.ObserverPhysics = MockObserverPhysics  # type: ignore
o.NDimensionalTensorManifest = MockNDimensionalTensorManifest  # type: ignore


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


# Custom stubs to bypass live docker requirement during local test runs
class MockRecord:
    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)


class MockSession:
    def __init__(self, queries: dict[str, Any]) -> None:
        self.queries = queries

    async def __aenter__(self) -> "MockSession":
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        pass

    async def run(self, query: str, **_kwargs: Any) -> Any:
        # Match base query prefix to handle dynamic parameterization
        records = []
        for q, r in self.queries.items():
            if query.startswith(q.split(" {")[0]):
                records = list(r)
                break

        class MockResult:
            def __init__(self, recs: list[Any]) -> None:
                self.recs = recs

            def __aiter__(self) -> "MockResult":
                return self

            async def __anext__(self) -> MockRecord:
                if not self.recs:
                    raise StopAsyncIteration
                return MockRecord(self.recs.pop(0))

        return MockResult(records)


class MockDriver:
    def __init__(self, queries: dict[str, Any]) -> None:
        self.queries = queries

    async def __aenter__(self) -> "MockDriver":
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        pass

    def session(self) -> MockSession:
        return MockSession(self.queries)


@pytest.mark.asyncio
async def test_migration_serialization_logic() -> None:
    """Test full serialize/rehydrate logic with OpenDAL and custom stubs."""
    temp_dir = tempfile.mkdtemp()
    os.environ["COREASON_STORAGE_SCHEME"] = "fs"
    os.environ["COREASON_STORAGE_PATH"] = temp_dir
    os.environ["COREASON_LANCEDB_URI"] = tempfile.mkdtemp()

    mock_nodes = [
        {"uuid": "node-1", "labels": ["Entity"], "properties": {"name": "Test Node 1"}},
        {"uuid": "node-2", "labels": ["Entity"], "properties": {"name": "Test Node 2"}},
    ]
    mock_rels = [
        {"source_uuid": "node-1", "target_uuid": "node-2", "type": "RELATES_TO", "properties": {"weight": 1.0}}
    ]

    queries = {
        "MATCH (n) RETURN labels(n) as labels, properties(n) as properties, n.uuid as uuid": [
            {"labels": n["labels"], "properties": n["properties"], "uuid": n["uuid"]} for n in mock_nodes
        ],
        "MATCH (s)-[r]->(t)": [
            {
                "source_uuid": r["source_uuid"],
                "target_uuid": r["target_uuid"],
                "type": r["type"],
                "properties": r["properties"],
            }
            for r in mock_rels
        ],
    }

    # Intercept AsyncGraphDatabase.driver using setattr to prevent mypy method-assign errors
    original_driver = AsyncGraphDatabase.driver

    def mock_driver(*args: Any, **kwargs: Any) -> MockDriver:
        return MockDriver(queries)

    AsyncGraphDatabase.driver = mock_driver  # type: ignore[assignment]

    try:
        payload: MigrationRequestPayload = {
            "tenant_cid": "test_tenant",
            "workflow_id": "test_workflow",
            "snapshot_key": "test/state.bin",
        }

        # Run serialization activity
        ser_res = await serialize_agent_state_activity(payload)
        assert "snapshot_key" in ser_res
        assert "signature" in ser_res

        # Run rehydration activity
        rehy_payload: MigrationRequestPayload = {
            "tenant_cid": "test_tenant",
            "workflow_id": "test_workflow",
            "snapshot_key": ser_res["snapshot_key"],
            "signature": ser_res["signature"],
        }
        rehy_res = await rehydrate_agent_state_activity(rehy_payload)
        assert rehy_res["rehydrated"] is True
    finally:
        AsyncGraphDatabase.driver = original_driver  # type: ignore[method-assign]


@pytest.mark.skipif(
    os.getenv("NEO4J_URI") is None and os.getenv("CI") != "true",
    reason="Docker/Neo4j test container required for full integration test",
)
@pytest.mark.asyncio
async def test_hollow_plane_bridge_workflow_success(neo4j_container: Any) -> None:
    """Test mathematically constrained bridging projection and agent state migration."""
    host = neo4j_container.get_container_host_ip()
    port = neo4j_container.get_exposed_port(7687)
    uri = f"bolt://{host}:{port}"
    os.environ["NEO4J_URI"] = uri
    os.environ["NEO4J_USERNAME"] = "neo4j"
    os.environ["NEO4J_PASSWORD"] = "password"  # noqa: S105 # nosec B105

    temp_storage_dir = tempfile.mkdtemp()
    os.environ["COREASON_STORAGE_SCHEME"] = "fs"
    os.environ["COREASON_STORAGE_PATH"] = temp_storage_dir

    temp_db_dir = tempfile.mkdtemp()
    os.environ["COREASON_LANCEDB_URI"] = temp_db_dir
    os.environ["COREASON_FORCE_INDEXER"] = "true"

    tenant_cid = "test_tenant_123"

    driver = AsyncGraphDatabase.driver(uri, auth=("neo4j", "password"))
    try:
        async with driver.session() as session:
            await session.run("MATCH (n) DETACH DELETE n")
            await session.run("CREATE (n:Entity {uuid: 'test-node-1', name: 'Source Node'})")
            await session.run("CREATE (m:Entity {uuid: 'test-node-2', name: 'Target Node'})")
            await session.run(
                "MATCH (a {uuid: 'test-node-1'}), (b {uuid: 'test-node-2'}) CREATE (a)-[:RELATES_TO {weight: 1.0}]->(b)"
            )

        db = lancedb.connect(temp_db_dir)
        data = [
            {
                "capability_id": "test_tool",
                "description": "Test tool description",
                "input_schema": "{}",
                "source_type": "wasm",
            }
        ]
        db.create_table("capabilities", data=data, mode="overwrite")

        payload: dict[str, Any] = {
            "bridge_request": {
                "target_plane": "ros2_bridge",
                "tenant_cid": tenant_cid,
                "target_task_queue": "hollow-plane-queue",
            },
            "observer": {"spatial_offset": 5.0},
            "tensor": {
                "shape": (256, 256, 3),
                "structural_format": "float32",
                "merkle_root": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "storage_uri": "mock://data",
                "vram_footprint_bytes": 1024,
            },
        }

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="hollow-plane-queue",
                workflows=[HollowPlaneBridgeWorkflow],
                activities=[
                    stub_emit_span,
                    verify_tensor_boundary_activity,
                    cross_dimensional_state_projector_activity,
                    serialize_agent_state_activity,
                    rehydrate_agent_state_activity,
                ],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(  # type: ignore
                    HollowPlaneBridgeWorkflow.run,
                    payload,
                    id="test-hpb-1",
                    task_queue="hollow-plane-queue",
                )
                assert result["transported"] is True

                async with driver.session() as session:
                    res_nodes = await session.run("MATCH (n) RETURN count(n) as cnt")
                    node_count = await res_nodes.single()
                    assert node_count is not None
                    assert node_count["cnt"] == 2

                    res_rels = await session.run("MATCH ()-[r]->() RETURN count(r) as cnt")
                    rel_count = await res_rels.single()
                    assert rel_count is not None
                    assert rel_count["cnt"] == 1
    finally:
        await driver.close()


@pytest.mark.asyncio
async def test_hollow_plane_bridge_failures() -> None:
    """Test rigorous schema conformance enforcement."""
    payload_bad: dict[str, Any] = {
        "bridge_request": {},
        "observer": {"spatial_offset": 5.0},
        "tensor": {},
    }
    with pytest.raises(ManifestConformanceError) as exc_info:
        await verify_tensor_boundary_activity(payload_bad)  # type: ignore
    assert "Hollow Plane Boundary Violation" in str(exc_info.value)

    with pytest.raises(ManifestConformanceError):
        await cross_dimensional_state_projector_activity({})
