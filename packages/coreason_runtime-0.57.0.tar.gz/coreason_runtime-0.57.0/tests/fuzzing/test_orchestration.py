# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


import pytest
from coreason_manifest import SwarmTopologyManifest as CognitiveTopologyManifest
from pydantic import ValidationError


def test_cognitive_topology_manifest_adversarial_rejection() -> None:
    # Mathematical Proof: The ontology must strictly reject infinite/malformed graphs
    # before they ever reach the Temporal Workflow AST
    adversarial_payload = {"nodes": "not_a_list", "edges": [{"from": "A", "to": "B", "weight": -1}]}

    with pytest.raises(ValidationError):
        CognitiveTopologyManifest.model_validate(adversarial_payload)
