# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64
import contextlib
import struct

from coreason_manifest import LatentProjectionIntent
from hypothesis import given
from hypothesis import strategies as st
from pydantic import ValidationError


@given(st.lists(st.floats(allow_nan=True, allow_infinity=True, width=32), min_size=1, max_size=1024))
def test_latent_memory_numerical_stability(hostile_vector: list[float]) -> None:
    # Pack to base64 to simulate the Extism WASM return payload
    packed = struct.pack(f"{len(hostile_vector)}f", *hostile_vector)
    encoded = base64.b64encode(packed).decode("utf-8")

    payload = {
        "synthetic_target_vector": {
            "foundation_matrix_name": "adversarial-embed",
            "dimensionality": len(hostile_vector),
            "vector_base64": encoded,
        },
        "top_k_candidates": 5,
        "min_isometry_score": 0.5,
    }

    # Proof: Pydantic should catch Infinity/NaNs (if configured in manifest)
    # or the storage activity must gracefully reject it before Parquet insertion.
    with contextlib.suppress(ValidationError):
        LatentProjectionIntent.model_validate(payload)
