# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for the OpenTelemetry tracing module."""

import pytest


class TestTracingModule:
    """Verify that the tracing module initializes and returns functional tracers."""

    def test_get_tracer_returns_tracer(self) -> None:
        """get_tracer should return a tracer (OTel or NoOp) without raising."""
        from coreason_runtime.utils.tracing import get_tracer

        tracer = get_tracer("test-tracer")
        assert tracer is not None

    def test_get_tracer_idempotent(self) -> None:
        """Multiple calls to get_tracer should return the same provider-backed tracer."""
        from coreason_runtime.utils.tracing import get_tracer

        t1 = get_tracer("test-a")
        t2 = get_tracer("test-b")
        assert t1 is not None
        assert t2 is not None

    def test_start_span_context_manager(self) -> None:
        """start_as_current_span should work as a context manager without errors."""
        from coreason_runtime.utils.tracing import get_tracer

        tracer = get_tracer("test-span")
        with tracer.start_as_current_span("test_operation") as span:
            span.set_attribute("test.key", "test_value")
            span.add_event("test_event", {"detail": "value"})

    def test_shutdown_tracer_no_error(self) -> None:
        """shutdown_tracer should complete without raising, even if called multiple times."""
        from coreason_runtime.utils.tracing import shutdown_tracer

        shutdown_tracer()
        shutdown_tracer()  # Idempotent — no error on double shutdown

    @pytest.mark.asyncio
    async def test_emit_span_activity_with_otel(self) -> None:
        """EmitSpanIOActivity should emit OTel spans from a dict payload."""
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        payload = {
            "name": "otel_integration_test",
            "trace_cid": "trace_otel_001",
            "span_cid": "span_otel_001",
            "kind": "server",
            "status": "ok",
            "events": [
                {"name": "validation_complete", "attributes": {"schema": "OracleExecutionReceipt"}},
                {"name": "serialization_done", "attributes": {}},
            ],
        }
        result = await ka.emit_span_io_activity(payload)
        assert result == {"status": "span_emitted"}

    @pytest.mark.asyncio
    async def test_emit_span_activity_empty_payload(self) -> None:
        """EmitSpanIOActivity should handle empty payloads gracefully."""
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        result = await ka.emit_span_io_activity({})
        assert result == {"status": "span_emitted"}

    @pytest.mark.asyncio
    async def test_emit_span_activity_with_non_dict_events(self) -> None:
        """EmitSpanIOActivity should skip non-dict events without crashing."""
        from coreason_runtime.orchestration.activities import KineticActivities

        ka = KineticActivities.__new__(KineticActivities)
        payload = {
            "name": "resilience_test",
            "events": ["not_a_dict", 42, None],
        }
        result = await ka.emit_span_io_activity(payload)
        assert result == {"status": "span_emitted"}
