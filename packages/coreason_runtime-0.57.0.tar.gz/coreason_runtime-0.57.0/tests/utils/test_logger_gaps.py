# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Targeted tests to close residual coverage gaps in utils/logger.py."""

import logging
from typing import cast

import loguru

from coreason_runtime.utils.logger import (
    InterceptHandler,
    otel_telemetry_sink,
)


# ---------------------------------------------------------------------------
# L59-60: InterceptHandler.emit — ValueError branch when levelname is unknown
# ---------------------------------------------------------------------------
def test_intercept_handler_emit_unknown_level() -> None:
    """Covers the `except ValueError: level = record.levelno` branch (lines 59-60)."""
    handler = InterceptHandler()
    record = logging.LogRecord(
        name="test",
        level=logging.DEBUG,
        pathname=__file__,
        lineno=1,
        msg="test message",
        args=(),
        exc_info=None,
    )
    # Use a non-standard level name that loguru will not recognise, triggering ValueError
    record.levelname = "NONEXISTENT_LEVEL_XYZ"
    # Should not raise — the handler catches ValueError and falls back to levelno
    handler.emit(record)


# ---------------------------------------------------------------------------
# L136-137: otel_telemetry_sink — json.JSONDecodeError branch
# ---------------------------------------------------------------------------
def test_otel_telemetry_sink_invalid_json() -> None:
    """Covers the `except json.JSONDecodeError: pass` branch (lines 136-137)."""

    class MockMessage(str):
        record: loguru.Record

    # Non-JSON string — will trigger JSONDecodeError inside the sink
    mock_msg = MockMessage("this is not json at all")
    record = cast("loguru.Record", {"extra": {}})
    mock_msg.record = record
    msg = cast("loguru.Message", mock_msg)

    # Should not raise — just silently swallows the decode error
    otel_telemetry_sink(msg)


# ---------------------------------------------------------------------------
# L167-169: temporal_context_patcher — RuntimeError branch
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# L191: set_global_log_level — mkdir when parent directory does not exist
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# L206-207: set_global_log_level — ENABLE_OTEL_SINK=True branch
# ---------------------------------------------------------------------------
