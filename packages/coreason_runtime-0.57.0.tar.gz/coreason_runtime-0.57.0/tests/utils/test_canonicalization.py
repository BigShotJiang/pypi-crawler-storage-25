# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import uuid
from datetime import UTC, datetime

from pydantic import BaseModel

from coreason_runtime.utils import canonicalize


class DummyModel(BaseModel):
    b: int
    a: str
    c: list[int] | None = None


def test_lexicographical_sorting() -> None:
    # Dictionary keys should be sorted lexicographically
    data = {"z": 1, "a": {"y": 2, "b": 3}}
    res = canonicalize(data)
    assert res == b'{"a":{"b":3,"y":2},"z":1}'


def test_pydantic_model_serialization() -> None:
    # Pydantic models should be converted to json dicts and sorted
    model = DummyModel(b=42, a="test")
    res = canonicalize(model)
    # None values should be stripped recursively
    assert res == b'{"a":"test","b":42}'


def test_recursive_none_stripping() -> None:
    # None values must be recursively stripped from dicts
    data = {"x": None, "y": [1, None, {"a": None, "b": 2}], "z": {"nested_none": None, "val": "hello"}}
    res = canonicalize(data)
    # Note: in lists, None values are kept or stripped depending on manifest design, but _to_json_compatible
    # keeps None in lists (to preserve indexes) and strips from dict keys. Let's verify:
    assert res == b'{"y":[1,null,{"b":2}],"z":{"val":"hello"}}'


def test_non_primitive_fallback() -> None:
    # Tuples, sets, datetimes and UUIDs should be serialized
    now = datetime(2026, 5, 19, 21, 0, 0, tzinfo=UTC)
    uid = uuid.UUID("12345678-1234-5678-1234-567812345678")
    data = {
        "set_val": {3, 1, 2},
        "tuple_val": (4, 5),
        "date_val": now,
        "uuid_val": uid,
    }
    res = canonicalize(data)
    # Sets/tuples become sorted/list structures, date and uuid become string representations.
    assert b'"date_val":"2026-05-19 21:00:00+00:00"' in res
    assert b'"uuid_val":"12345678-1234-5678-1234-567812345678"' in res
    assert b'"tuple_val":[4,5]' in res
    assert b'"set_val":[1,2,3]' in res


def test_float_formatting_determinism() -> None:
    # JCS float serialization behavior
    data = {"f": 1.23e4, "z": 0.00001}
    res = canonicalize(data)
    assert res == b'{"f":12300,"z":0.00001}'
