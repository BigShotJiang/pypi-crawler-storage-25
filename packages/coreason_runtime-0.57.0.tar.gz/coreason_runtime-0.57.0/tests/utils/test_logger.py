# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any, cast

from pydantic import BaseModel


class LogEvent(BaseModel):
    timestamp: float
    level: str
    message: str
    context_profile: dict[str, Any]
    event_cid: str = "mock-cid"


from coreason_runtime.utils.logger import (
    LoggerConfig,
    temporal_context_patcher,
)


def test_logger_config_loads_defaults() -> None:
    config = LoggerConfig()
    assert config.LOG_LEVEL == "INFO"
    assert config.LOG_FILE_PATH == "logs/app.log"
    assert config.ENABLE_CONSOLE_LOGS is True
    assert config.ENABLE_OTEL_SINK is False


def test_temporal_context_patcher_outside_context() -> None:
    # Should not throw an exception when called outside a temporal context
    record_dict: dict[str, Any] = {"message": "test", "extra": {}}
    record = cast("Any", record_dict)
    temporal_context_patcher(record)
    assert record_dict["extra"] == {}
