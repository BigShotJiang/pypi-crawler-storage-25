# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import yaml

from coreason_runtime.execution_plane.io_broker import IOBroker


def test_generate_topology_no_mapping() -> None:
    broker = IOBroker(broker_url="localhost:9092")
    yaml_str = broker.generate_topology(input_topic="in_events", output_topic="out_events")

    parsed = yaml.safe_load(yaml_str)
    assert "pipeline" not in parsed
    assert parsed["input"]["kafka"]["topics"] == ["in_events"]
    assert parsed["input"]["kafka"]["addresses"] == ["localhost:9092"]
    assert parsed["output"]["kafka"]["topic"] == "out_events"


def test_generate_topology_with_mapping() -> None:
    broker = IOBroker(broker_url="test_broker:1234")
    mapping = "root.value = this.value.uppercase()"
    yaml_str = broker.generate_topology(
        input_topic="in_events", output_topic="out_events", consumer_group="test-group", mapping_logic=mapping
    )

    parsed = yaml.safe_load(yaml_str)
    assert "pipeline" in parsed
    assert parsed["pipeline"]["processors"][0]["mapping"] == mapping
    assert parsed["input"]["kafka"]["consumer_group"] == "test-group"
    assert parsed["input"]["kafka"]["addresses"] == ["test_broker:1234"]
