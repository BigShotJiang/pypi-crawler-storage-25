# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os

import pytest

from coreason_runtime.execution_plane.blob_store import UniversalBlobStore


@pytest.mark.asyncio
async def test_universal_blob_store_memory() -> None:
    os.environ["COREASON_STORAGE_SCHEME"] = "memory"
    store = UniversalBlobStore()

    await store.write_bytes("test_key.txt", b"test_data")
    data = await store.read_bytes("test_key.txt")
    assert data == b"test_data"

    stat = await store.stat("test_key.txt")
    assert stat.content_length == len(b"test_data")

    await store.delete("test_key.txt")

    with pytest.raises(Exception, match="NotFound"):
        await store.read_bytes("test_key.txt")
