# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Test suite for the LicenseVerifier validating SOTA 2026 Cryptographic constraints
(ML-DSA, SD-JWT, zk-SNARK). Mocks are strictly forbidden; physical instantiation only.
"""

import time

import pytest
from coreason_manifest.spec.ontology import CommercialOverrideReceipt

from coreason_runtime.execution_plane.license_verifier import (
    LicenseVerifier,
)


@pytest.fixture
def valid_receipt() -> CommercialOverrideReceipt:
    current_time = int(time.time())
    return CommercialOverrideReceipt(
        license_tier="commercial",
        signer_did="did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB",
        signature_algorithm="ML-DSA-65",
        credential_format="sd-jwt",
        distr_license_cid="distr_test_12345",
        hardware_zk_proof="fake_zk_snark_proof_xyz",
        issued_at_epoch=current_time - 3600,
        expires_at_epoch=current_time + 86400,
        exp=current_time + 86400,
        iat=current_time - 3600,
        entitlements=["COMMERCIAL_USE", "IP_SOVEREIGNTY_EXCEPTION"],
        network_mode="private",
        federation_enabled=False,
    )


def test_license_verifier_success(valid_receipt: CommercialOverrideReceipt) -> None:
    """Tests the physical validation of a valid ML-DSA SD-JWT receipt with matching hardware."""
    # Instantiating physical verifier
    verifier = LicenseVerifier(local_cluster_fingerprint_hash="hardware_hash_123")

    # Execution
    active_entitlements = verifier.verify_and_apply(valid_receipt)

    # Assertion
    assert "COMMERCIAL_USE" in active_entitlements
    assert "IP_SOVEREIGNTY_EXCEPTION" in active_entitlements


def test_license_verifier_temporal_expiration(valid_receipt: CommercialOverrideReceipt) -> None:
    """Tests the Temporal Ordering bounds. Graceful fallback on expiration."""
    current_time = int(time.time())

    # Mutate receipt to be expired (bypassing model validator strictly for testing the boundary)
    object.__setattr__(valid_receipt, "expires_at_epoch", current_time - 3600)

    verifier = LicenseVerifier(local_cluster_fingerprint_hash="hardware_hash_123")
    active_entitlements = verifier.verify_and_apply(valid_receipt)

    # Verify fallback to Prosperity 3.0 (empty entitlements list)
    assert active_entitlements == []


def test_license_verifier_hardware_mismatch(valid_receipt: CommercialOverrideReceipt) -> None:
    """Tests the zk-SNARK hardware fingerprint boundary. Fails if no fingerprint provided locally."""
    # Instantiating verifier with NO hardware fingerprint (simulating a piracy attempt)
    verifier = LicenseVerifier(local_cluster_fingerprint_hash=None)

    active_entitlements = verifier.verify_and_apply(valid_receipt)

    # Verify fallback to Prosperity 3.0
    assert active_entitlements == []


def test_license_verifier_unsupported_crypto(valid_receipt: CommercialOverrideReceipt) -> None:
    """Tests the signature algorithm enforcement boundary."""
    # The signature algorithm validation in the class throws CryptographicVerificationError
    # but the generic verify_and_apply intercepts it and returns an empty list.
    object.__setattr__(
        valid_receipt, "signature_algorithm", "RSA-2048"
    )  # Type violation in real validation, simulating an attack

    verifier = LicenseVerifier(local_cluster_fingerprint_hash="hardware_hash_123")
    active_entitlements = verifier.verify_and_apply(valid_receipt)

    # Verify fallback to Prosperity 3.0
    assert active_entitlements == []
