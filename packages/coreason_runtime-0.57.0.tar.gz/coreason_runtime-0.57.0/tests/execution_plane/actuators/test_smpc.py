# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import math

import pytest

from coreason_runtime.execution_plane.actuators.smpc_tool import run_smpc_tool as run_smpc


def test_smpc() -> None:
    pytest.importorskip("tenseal")
    result = run_smpc(["participant_1", "participant_2"], "garbled_circuits")
    if result["status"] != "success":
        pytest.fail(f"Expected status 'success', got {result['status']}")

    if not math.isclose(result["result_decrypted"][0], 0.6, abs_tol=0.1):
        pytest.fail(f"Expected index 0 decrypted result to be ~0.6, got {result['result_decrypted'][0]}")
    if not math.isclose(result["result_decrypted"][1], 0.8, abs_tol=0.1):
        pytest.fail(f"Expected index 1 decrypted result to be ~0.8, got {result['result_decrypted'][1]}")
