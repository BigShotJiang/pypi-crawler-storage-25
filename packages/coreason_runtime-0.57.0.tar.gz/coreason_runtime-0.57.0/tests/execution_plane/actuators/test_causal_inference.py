# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest

from coreason_runtime.execution_plane.actuators.causal_inference_tool import (
    run_causal_inference_tool as run_causal_inference,
)


def test_causal_inference() -> None:
    causal_graph = {
        "nodes": ["A", "B", "C"],
        "edges": [("A", "B"), ("C", "A"), ("C", "B")],
        "treatment": "A",
        "outcome": "B",
    }
    dataset = {"A": [0, 1, 0, 1, 0, 1, 0, 1], "B": [0, 1, 0, 1, 0, 1, 0, 1], "C": [0, 0, 1, 1, 0, 0, 1, 1]}
    result = run_causal_inference(causal_graph, dataset)
    if result["status"] != "success":
        pytest.fail(f"Expected status 'success', got {result['status']}")

    # Assert real processing happened
    if "causal_effect" not in result:
        pytest.fail("Causal effect is missing from result.")
