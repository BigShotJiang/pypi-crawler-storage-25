# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest

from coreason_runtime.execution_plane.actuators.neurosymbolic_tool import (
    run_neurosymbolic_verification_tool as run_neurosymbolic_verification,
)


def test_neurosymbolic() -> None:
    result = run_neurosymbolic_verification({"constraint": "A > B"})
    if result["status"] != "success":
        pytest.fail(f"Expected status 'success', got {result['status']}")
