# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os

# Force indexer to run even in test mode for these specific unit tests
os.environ["COREASON_FORCE_INDEXER"] = "true"


def test_discovery_is_test_mode() -> None:
    """Verify that we use a dummy model in test mode to avoid network calls."""
    import importlib

    import coreason_runtime.execution_plane.discovery_indexer

    # Reload to ensure our _IS_TEST logic runs
    importlib.reload(coreason_runtime.execution_plane.discovery_indexer)

    from coreason_runtime.execution_plane.discovery_indexer import model

    # Check that it's our dummy model (has VectorField method)
    assert hasattr(model, "VectorField")
    assert model.ndims() == 384
