# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest

import coreason_runtime.execution_plane.license_verifier as license_verifier_mod
from coreason_runtime.execution_plane.integrity import (
    IntegrityViolationError,
    assert_module_integrity,
)


def test_integrity_check_passes_on_unmodified_module() -> None:
    # This should pass without raising any exception if the file hasn't been tampered with
    # If the file gets reformatted or changed, this hash will need to be updated.
    expected_hash = "04ce95755dfea75f705ebf15c26df16f3aff99d0dc7ea8a9b574223dbd6090a8"
    assert_module_integrity(license_verifier_mod, expected_hash)


def test_integrity_check_fails_on_bad_hash() -> None:
    bad_hash = "0000000000000000000000000000000000000000000000000000000000000000"

    with pytest.raises(IntegrityViolationError) as exc_info:
        assert_module_integrity(license_verifier_mod, bad_hash)

    assert "CRITICAL INTEGRITY VIOLATION" in str(exc_info.value)


def test_rust_module_direct_verification() -> None:
    """If coreason_runtime_rust is compiled, verify its functions directly with various inputs."""
    try:
        from coreason_runtime import coreason_runtime_rust  # type: ignore[attr-defined]
    except ImportError:
        pytest.skip("coreason_runtime_rust extension not compiled/installed.")

    source = "print('Hello World')\r\n"
    expected = "6075c051cc5f23ddd8926338be443cf2b28ee2422f41d0203acd005c8d1fe635"  # sha256 of normalized "print('Hello World')\n"

    assert coreason_runtime_rust.verify_module_integrity(source, expected) is True
    assert coreason_runtime_rust.verify_module_integrity(source, "badhash") is False
