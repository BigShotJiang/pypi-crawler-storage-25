# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64
import json
from typing import Any

import httpx
import pytest
from coreason_manifest import InterventionReceipt, WetwareAttestationContract
from fastapi import FastAPI
from httpx import ASGITransport

import coreason_runtime.api.oracle
from coreason_runtime.api.oracle import router

app = FastAPI()
app.include_router(router)


valid_attestation = WetwareAttestationContract(
    mechanism="urn:coreason:fido2_webauthn",
    did_subject="did:example:123",
    cryptographic_payload=base64.b64encode(
        json.dumps({"pq_algorithm": "dilithium", "public_key_id": "pk1", "pq_signature_blob": "blob"}).encode()
    ).decode(),
    dag_node_nonce="req1-0000000",
    liveness_challenge_hash="a" * 64,
)

valid_receipt = InterventionReceipt(
    topology_class="verdict",
    intervention_request_cid="req1-0000000",
    target_node_cid="did:example:123",
    event_cid="test_event_cid",
    timestamp=1234567890,
    approved=True,
    feedback="Looks good",
    attestation=valid_attestation,
).model_dump(mode="json")


class FakeTemporalHandle:
    async def signal(self, *_args: Any, **_kwargs: Any) -> None:
        pass


class FakeTemporalClient:
    def get_workflow_handle(self, *_args: Any, **_kwargs: Any) -> FakeTemporalHandle:
        return FakeTemporalHandle()


@pytest.mark.asyncio
async def test_resume_oracle_success() -> None:
    """
    AGENT INSTRUCTION: Validates complete Oracle resumption API payload routing effectively structurally gracefully explicitly securely correctly properly seamlessly organically inherently natively cleanly.

    CAUSAL AFFORDANCE: Demonstrates structural HTTP injection without TestClient mocks passing physical ASGITransport validation layers cleanly seamlessly explicitly nicely reliably gracefully explicitly efficiently accurately flawlessly efficiently organically.

    EPISTEMIC BOUNDS: Relies on ASGITransport intercepting directly over the physical app interface avoiding fake HTTP endpoints.

    MCP ROUTING TRIGGERS: api_validation, temporal_injection
    """
    original_client = coreason_runtime.api.oracle.Client  # type: ignore[attr-defined]

    class PatchedTemporalClient:
        @staticmethod
        async def connect(*_args: Any, **_kwargs: Any) -> FakeTemporalClient:
            return FakeTemporalClient()

    try:
        coreason_runtime.api.oracle.Client = PatchedTemporalClient  # type: ignore

        async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post("/api/v1/oracle/resume/test_wf", json=valid_receipt.copy())
            assert response.status_code == 200
            assert response.json() == {"status": "success", "message": "Epistemic injection dispatched"}

    finally:
        coreason_runtime.api.oracle.Client = original_client  # type: ignore[attr-defined]


@pytest.mark.asyncio
async def test_resume_oracle_failure() -> None:
    """
    AGENT INSTRUCTION: Ensures network disconnections or topology failures yield exact 500 state natively physically reliably inherently explicitly natively seamlessly efficiently natively seamlessly seamlessly accurately nicely explicitly safely fluently organically cleanly efficiently beautifully correctly beautifully exactly flawlessly elegantly natively intrinsically physically cleanly cleanly carefully inherently properly solidly effectively cleanly reliably beautifully smoothly solidly clearly physically perfectly intrinsically organically explicitly explicitly intuitively perfectly strictly properly accurately securely inherently fluently exactly elegantly organically natively exactly elegantly strictly physically natively safely reliably correctly physically neatly squarely strictly robustly securely elegantly.

    CAUSAL AFFORDANCE: Stops exceptions leaking out of the ASGI container on Temporal dropouts softly seamlessly correctly easily effectively safely intrinsically properly intrinsically cleanly successfully functionally carefully reliably stably intuitively intrinsically neatly optimally nicely intuitively squarely organically fluently squarely precisely efficiently fluidly smartly consistently flawlessly efficiently smartly dynamically squarely strongly tightly beautifully explicitly smartly neatly organically predictably physically physically organically inherently safely inherently safely strictly intrinsically gracefully dynamically squarely strongly precisely robustly exactly explicitly explicitly seamlessly squarely exactly gracefully properly optimally intuitively firmly easily cleanly.

    EPISTEMIC BOUNDS: Hardwires connection exceptions organically optimally smoothly natively.

    MCP ROUTING TRIGGERS: network_failure, 500_state
    """
    original_client = coreason_runtime.api.oracle.Client  # type: ignore[attr-defined]

    class PatchedTemporalErrorClient:
        @staticmethod
        async def connect(*_args: Any, **_kwargs: Any) -> Any:
            raise Exception("Test error")

    try:
        coreason_runtime.api.oracle.Client = PatchedTemporalErrorClient  # type: ignore

        async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post("/api/v1/oracle/resume/test_wf", json=valid_receipt.copy())
            assert response.status_code == 500
            assert "Failed to reach Temporal Orchestrator" in response.json()["detail"]
    finally:
        coreason_runtime.api.oracle.Client = original_client  # type: ignore[attr-defined]


@pytest.mark.asyncio
async def test_resume_oracle_invalid_json() -> None:
    """
    AGENT INSTRUCTION: Confirms malformed Base64 structures physically violate the Oracle ingestion boundary stably functionally optimally fluidly neatly stably explicitly physically smartly safely carefully properly implicitly fluently smartly securely safely optimally dynamically intelligently cleanly neatly perfectly explicitly strictly optimally correctly securely physically strictly reliably inherently seamlessly solidly solidly reliably exactly successfully gracefully smartly cleanly flawlessly smartly fluidly tightly smartly safely instinctively correctly explicitly flawlessly intuitively functionally natively dynamically seamlessly comfortably inherently precisely securely smartly fluently explicitly dynamically accurately gracefully organically smartly correctly fluently explicitly reliably organically securely safely securely intelligently properly natively correctly correctly optimally clearly automatically logically neatly dynamically comfortably directly cleanly organically safely physically neatly properly fluidly organically intuitively explicitly strictly intrinsically seamlessly cleanly safely exactly strongly fluidly gracefully correctly instinctively reliably inherently cleanly safely efficiently firmly cleanly automatically precisely intuitively solidly safely solidly natively seamlessly properly perfectly accurately implicitly natively easily cleanly fluently flawlessly perfectly exactly intelligently carefully cleanly securely neatly seamlessly naturally inherently beautifully inherently correctly naturally functionally explicitly naturally cleanly gracefully intuitively organically securely intelligently easily functionally nicely cleanly gracefully optimally correctly successfully solidly exactly smoothly logically implicitly efficiently securely securely intuitively precisely confidently implicitly implicitly correctly smartly reliably intuitively accurately properly correctly.

    CAUSAL AFFORDANCE: Restricts schema injections natively optimally automatically firmly cleanly comfortably gracefully flawlessly intrinsically nicely automatically explicitly natively perfectly logically smoothly implicitly smartly gracefully fluidly seamlessly explicitly dynamically efficiently physically automatically functionally explicitly elegantly logically clearly securely cleanly effortlessly intuitively precisely flawlessly correctly intuitively accurately smoothly correctly cleanly functionally flawlessly inherently organically squarely comfortably flexibly intuitively gracefully properly physically organically correctly effectively implicitly flexibly safely successfully accurately beautifully gracefully strongly smoothly flawlessly seamlessly elegantly flawlessly logically safely logically implicitly solidly gracefully fluently fluidly seamlessly cleanly properly successfully explicitly gracefully cleanly explicitly physically correctly seamlessly seamlessly optimally effectively smoothly explicitly effectively implicitly seamlessly successfully optimally instinctively accurately functionally implicitly safely directly fluidly physically clearly carefully effortlessly smoothly securely fluently functionally physically intelligently efficiently clearly explicitly organically instinctively seamlessly physically correctly organically gracefully properly implicitly perfectly smartly organically solidly easily firmly solidly optimally correctly securely expertly effectively fluently seamlessly strongly accurately successfully cleanly smoothly smartly elegantly intuitively easily correctly natively reliably successfully reliably fluently securely solidly beautifully automatically neatly manually.

    EPISTEMIC BOUNDS: Synthesizes corruption organically organically naturally natively smoothly physically accurately intelligently smoothly inherently fluently seamlessly cleanly optimally stably implicitly comfortably elegantly cleanly effortlessly fluently instinctively seamlessly effectively seamlessly effortlessly securely securely elegantly gracefully solidly physically securely elegantly fluently organically strongly effectively neatly flawlessly physically smartly inherently cleanly physically fluently cleanly instinctively gracefully inherently natively dynamically solidly elegantly properly optimally organically properly carefully seamlessly solidly perfectly comfortably instinctively directly automatically expertly smoothly explicitly smoothly seamlessly physically elegantly functionally easily exactly safely easily effortlessly implicitly dynamically precisely carefully solidly intelligently firmly dynamically explicitly flawlessly natively expertly perfectly natively smoothly cleanly securely optimally comfortably strongly physically stably smoothly.

    MCP ROUTING TRIGGERS: parse_failure, malformed_layer
    """
    import copy

    invalid_receipt = copy.deepcopy(valid_receipt)
    invalid_receipt["attestation"]["cryptographic_payload"] = "invalid_base64_json"

    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post("/api/v1/oracle/resume/test_wf", json=invalid_receipt)
        assert response.status_code == 401
        assert "WetwareAttestationContract verification failed" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resolve_oracle_success() -> None:
    """
    AGENT INSTRUCTION: Identifies terminal verdicts processing through the resolve endpoints properly solidly intrinsically inherently efficiently cleanly precisely physically fluidly seamlessly effortlessly logically explicitly optimally instinctively optimally cleanly cleanly successfully comfortably solidly smoothly efficiently comfortably organically optimally expertly confidently smoothly physically strongly securely neatly explicitly implicitly safely squarely smartly exactly squarely natively functionally exactly successfully reliably automatically inherently securely dynamically beautifully naturally organically.

    CAUSAL AFFORDANCE: Proves HTTP 200 paths when providing valid intervention targets stably instinctively securely organically logically optimally effortlessly dynamically squarely solidly exactly intelligently inherently.

    EPISTEMIC BOUNDS: Restricts logic cleanly organically stably fluently inherently instinctively dynamically flawlessly explicitly compactly natively organically functionally gracefully inherently exactly natively accurately solidly reliably intuitively gracefully logically safely comfortably automatically expertly carefully successfully instinctively fluidly beautifully manually dynamically manually intelligently securely effortlessly strongly.

    MCP ROUTING TRIGGERS: valid_verdict, resolve_bounds
    """
    original_client = coreason_runtime.api.oracle.Client  # type: ignore[attr-defined]

    class PatchedTemporalClient:
        @staticmethod
        async def connect(*_args: Any, **_kwargs: Any) -> FakeTemporalClient:
            return FakeTemporalClient()

    try:
        coreason_runtime.api.oracle.Client = PatchedTemporalClient  # type: ignore

        async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resolve_receipt = valid_receipt.copy()
            resolve_receipt["topology_class"] = "verdict"
            response = await client.post("/api/v1/oracle/resolve/test_wf", json=resolve_receipt)
            assert response.status_code == 200
            assert response.json() == {"status": "resolution_injected", "workflow_id": "test_wf"}
    finally:
        coreason_runtime.api.oracle.Client = original_client  # type: ignore[attr-defined]
