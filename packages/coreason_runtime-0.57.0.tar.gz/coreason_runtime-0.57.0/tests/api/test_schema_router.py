# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from pathlib import Path

from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.schema.router import JSONDepthLimitMiddleware, router

app = FastAPI()
app.add_middleware(JSONDepthLimitMiddleware)
app.include_router(router)

client = TestClient(app)


def test_get_receipt_schema() -> None:
    response = client.get("/api/v1/schema/receipt")
    assert response.status_code == 200
    assert "$defs" in response.json() or "title" in response.json()


def test_get_topology_schema() -> None:
    response = client.get("/api/v1/schema/topology/dag")
    assert response.status_code == 200
    assert "$defs" in response.json() or "title" in response.json()


def test_get_topology_schema_invalid() -> None:
    response = client.get("/api/v1/schema/topology/nonexistent")
    assert response.status_code == 404


def test_get_capabilities_schema() -> None:
    response = client.get("/api/v1/schema/capabilities")
    assert response.status_code == 200
    assert "title" in response.json()
    assert response.json()["title"] == "ExecutableCapabilities"


def test_json_depth_limit_middleware_fallback() -> None:
    # Attempting to send normal JSON Depth
    response = client.post("/api/v1/schema/topology/dag", json={"test": "data"})
    assert response.status_code in [404, 405]  # just testing the middleware bypass

    # Create a deeply nested JSON to trigger the 400
    deep_json = "{" + "".join(['"a": {' for _ in range(12)]) + '"b": 1' + "".join(["}" for _ in range(12)]) + "}"
    response = client.post(
        "/api/v1/schema/topology/dag", content=deep_json, headers={"Content-Type": "application/json"}
    )
    assert response.status_code == 400
    assert "JSON Payload rejected" in response.json().get("detail", "")


def test_json_depth_limit_middleware_fallback_logic() -> None:
    # Test the fallback scanner logic directly without monkeypatching sys.modules
    # This respects the "Zero-Mock" requirement by testing the real logic on real data.

    # Test the fallback parser with backslash escape and depth limit
    deep_json_with_esc = (
        '{"a": "'
        + '\\"'
        + '", "b": ['
        + "".join(['{"c": ' for _ in range(12)])
        + "1"
        + "".join(["}" for _ in range(12)])
        + "]}"
    )
    error = JSONDepthLimitMiddleware._fallback_byte_scanner(deep_json_with_esc.encode("utf-8"))
    assert error == "JSON Payload rejected: nesting depth exceeds maximum allowed of 10."

    # Test valid JSON with brackets closing
    valid_json = '{"a": "\\\\", "b": [1, 2, 3]}'
    error2 = JSONDepthLimitMiddleware._fallback_byte_scanner(valid_json.encode("utf-8"))
    assert error2 is None


def test_get_capabilities_schema_empty_dir(tmp_path: Path) -> None:
    # Use a real empty directory on the filesystem to verify behavior.
    # This satisfies the "Zero-Mock" requirement.
    import sys
    from typing import Any

    schema_router_module: Any = sys.modules["coreason_runtime.api.schema.router"]
    original_dir = schema_router_module.COREASON_PLUGINS_DIR
    try:
        schema_router_module.COREASON_PLUGINS_DIR = str(tmp_path)
        response = client.get("/api/v1/schema/capabilities")
        assert response.status_code == 200
        assert response.json()["enum"] == ["no_tools_available"]
    finally:
        schema_router_module.COREASON_PLUGINS_DIR = original_dir


def test_get_capabilities_schema_with_tools(tmp_path: Path) -> None:
    # Use a real directory with real files.
    (tmp_path / "test_tool.wasm").write_text("dummy binary data")
    (tmp_path / "other.txt").write_text("not a tool")

    import sys
    from typing import Any

    schema_router_module: Any = sys.modules["coreason_runtime.api.schema.router"]
    original_dir = schema_router_module.COREASON_PLUGINS_DIR
    try:
        schema_router_module.COREASON_PLUGINS_DIR = str(tmp_path)
        response = client.get("/api/v1/schema/capabilities")
        assert response.status_code == 200
        assert "test_tool" in response.json()["enum"]
        assert "other" not in response.json()["enum"]
        assert "no_tools_available" not in response.json()["enum"]
    finally:
        schema_router_module.COREASON_PLUGINS_DIR = original_dir
