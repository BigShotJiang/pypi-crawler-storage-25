# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from pathlib import Path

from coreason_runtime.cli import execute, start_api, start_node


def test_cli_start_node_dry_run() -> None:
    """Tests the node startup in dry-run mode to ensure structural validity."""
    # Zero-Mock: We use the real function with dry_run=True to verify it runs without crashing.
    start_node(dry_run=True)


def test_cli_start_api_dry_run() -> None:
    """Tests the API startup in dry-run mode to ensure structural validity."""
    # Zero-Mock: We use the real function with dry_run=True.
    start_api(dry_run=True)


def test_cli_execute_dry_run(tmp_path: Path) -> None:
    """Tests manifest execution in dry-run mode with a real file input."""
    # Zero-Mock: We use a real file on the filesystem.
    manifest_file = tmp_path / "test_manifest.json"
    manifest_file.write_text('{"test": "data"}')

    execute(manifest_path=manifest_file, query="test_query", dry_run=True)


def test_cli_main_entrypoint() -> None:
    """Verifies the Typer app object exists and is correctly configured."""
    from coreason_runtime.cli import app

    assert app.registered_commands
    assert any(cmd.name == "execute" for cmd in app.registered_commands)
