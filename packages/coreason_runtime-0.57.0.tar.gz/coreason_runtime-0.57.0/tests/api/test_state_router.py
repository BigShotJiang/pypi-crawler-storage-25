# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from coreason_runtime.api.state_router import state_router

app = FastAPI()
app.include_router(state_router)


from collections.abc import AsyncGenerator


@pytest.fixture
async def client() -> AsyncGenerator[AsyncClient]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest.mark.asyncio
async def test_sync_state_payload_too_large(client: AsyncClient) -> None:
    # 256KB +
    large_payload = {"type": "cognitive_topology", "nodes": {"large": "a" * (256 * 1024 + 10)}}
    resp = await client.post("/api/v1/state/sync/wf-123", json=large_payload)

    assert resp.status_code == 413
    assert "Payload Too Large" in resp.text


@pytest.mark.asyncio
async def test_sync_state_validation_error(client: AsyncClient) -> None:
    # No patching of validate_python, let it fail
    payload = {"invalid": "payload"}
    resp = await client.post("/api/v1/state/sync/wf-123", json=payload)

    assert resp.status_code == 422
    assert "Invalid state delta payload" in resp.text
