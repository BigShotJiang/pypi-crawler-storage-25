# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

# Attempt to import the FastAPI app and predict_router
from coreason_runtime.api.predict_router import _build_synthesis_prompt, predict_router

app = FastAPI()
app.include_router(predict_router)


from collections.abc import AsyncGenerator


@pytest.fixture
async def client() -> AsyncGenerator[AsyncClient]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


def test_build_synthesis_prompt() -> None:
    prompt = _build_synthesis_prompt(None, "user prompt", "discovery context")
    assert "user prompt" in prompt
    assert "discovery context" in prompt

    topology = {"topology": {"type": "cognitive_topology", "nodes": {"did:node:1": {"description": "node 1"}}}}
    prompt2 = _build_synthesis_prompt(topology, "", "")
    assert "cognitive_topology" in prompt2
    assert "did:node:1" in prompt2


@pytest.mark.asyncio
async def test_synthesize_topology_expansion_bad_topology(client: AsyncClient) -> None:
    # Testing json parsing failure early -> 422
    payload = {"topology": "{bad json", "user_prompt": "test"}
    resp = await client.post("/api/v1/predict/synthesize", json=payload)
    assert resp.status_code == 422
    assert "Failed to parse topology" in resp.text


# ---------------------------------------------------------------------------
# Additional coverage: _build_synthesis_prompt variations
# ---------------------------------------------------------------------------
class TestBuildSynthesisPromptEdgeCases:
    def test_empty_topology_dict(self) -> None:
        prompt = _build_synthesis_prompt({}, "test prompt")
        assert "blank canvas" in prompt.lower()

    def test_nodes_without_description(self) -> None:
        topology = {
            "topology": {
                "type": "council",
                "nodes": {"did:key:a": {}},
            }
        }
        prompt = _build_synthesis_prompt(topology, "")
        assert "no description" in prompt.lower()

    def test_user_prompt_is_whitespace(self) -> None:
        prompt = _build_synthesis_prompt(None, "   ")
        # Empty after strip -> no user_hint
        assert "topology architect" in prompt.lower()


# ---------------------------------------------------------------------------
# Additional endpoint coverage: dict topology input
# ---------------------------------------------------------------------------
