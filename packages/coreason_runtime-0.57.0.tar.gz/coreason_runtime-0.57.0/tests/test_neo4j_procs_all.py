# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from neo4j import AsyncGraphDatabase


@pytest.mark.asyncio
async def test_list_all_procs(neo4j_container: Any) -> None:
    host = neo4j_container.get_container_host_ip()
    port = neo4j_container.get_exposed_port(7687)
    uri = f"bolt://{host}:{port}"
    driver = AsyncGraphDatabase.driver(uri, auth=("neo4j", "password"))

    async with driver.session() as session:
        result = await session.run("SHOW PROCEDURES YIELD name, signature, description")
        records = await result.data()
        print("\n[INFO] All Procedures:")
        for r in records:
            if "set" in r["name"].lower() and "vector" in r["name"].lower():
                print(f"  {r['name']}: {r['signature']}")

    await driver.close()
