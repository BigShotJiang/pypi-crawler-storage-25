# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>
import os

os.environ["COREASON_TESTING"] = "1"

# Configure Temporal sandbox to allow loguru and all of its submodules to pass through
try:
    import dataclasses

    import temporalio.worker.workflow_sandbox as ws

    loguru_submods = {
        "loguru",
        "loguru._asyncio_loop",
        "loguru._better_exceptions",
        "loguru._colorama",
        "loguru._colorizer",
        "loguru._contextvars",
        "loguru._ctime_functions",
        "loguru._datetime",
        "loguru._defaults",
        "loguru._error_interceptor",
        "loguru._file_sink",
        "loguru._filters",
        "loguru._get_frame",
        "loguru._handler",
        "loguru._locks_machinery",
        "loguru._logger",
        "loguru._recattrs",
        "loguru._simple_sinks",
        "loguru._string_parsers",
    }
    passthrough_submods = loguru_submods | {
        "urllib",
        "urllib.request",
        "http",
        "http.client",
    }

    unrestricted_members = ws.SandboxRestrictions.default.invalid_module_members
    print(
        f"CONFTEST: urllib request is restricted: {'request' in unrestricted_members.children['urllib'].children if 'urllib' in unrestricted_members.children else False}"
    )
    for path in [("urllib", "request"), ("urllib",), ("http", "client"), ("http",)]:
        try:
            unrestricted_members = unrestricted_members.with_child_unrestricted(*path)
        except Exception as e:
            print(f"CONFTEST ERROR: {e}")

    print(
        f"CONFTEST: after unrestrict: {'request' in unrestricted_members.children['urllib'].children if 'urllib' in unrestricted_members.children else False}"
    )

    ws.SandboxRestrictions.passthrough_modules_default = (
        ws.SandboxRestrictions.passthrough_modules_default | passthrough_submods
    )
    ws.SandboxRestrictions.default = dataclasses.replace(
        ws.SandboxRestrictions.default,
        passthrough_modules=ws.SandboxRestrictions.default.passthrough_modules | passthrough_submods,
        invalid_module_members=unrestricted_members,
    )
    from typing import Any

    from temporalio.worker import UnsandboxedWorkflowRunner, Worker

    original_init = Worker.__init__

    def custom_init(self: Any, *args: Any, **kwargs: Any) -> None:
        if "workflow_runner" not in kwargs:
            kwargs["workflow_runner"] = UnsandboxedWorkflowRunner()
        original_init(self, *args, **kwargs)

    Worker.__init__ = custom_init  # type: ignore[method-assign]
except ImportError:
    # Temporal is optional in some test environments, skipping sandbox passthrough setup is intentional
    pass

from typing import Any

import pytest
from testcontainers.neo4j import Neo4jContainer  # type: ignore[import-untyped]


@pytest.fixture(scope="session")
def neo4j_container() -> Any:
    """AGENT INSTRUCTION: Provisions a session-scoped Neo4j substrate for integration testing.

    Physical execution engine for Graphiti-backed memory subsystems.
    """
    try:
        container = Neo4jContainer("neo4j:5.18")
        container.with_env("NEO4J_AUTH", "none")
        with container as neo4j:
            yield neo4j
    except Exception as e:
        pytest.skip(f"Docker is not available or Neo4j failed to start: {e}")
