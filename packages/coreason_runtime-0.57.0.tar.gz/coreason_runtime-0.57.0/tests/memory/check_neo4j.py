# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import time

from testcontainers.neo4j import Neo4jContainer  # type: ignore[import-untyped]

try:
    print("Starting Neo4j container...")
    with Neo4jContainer("neo4j:5.15") as neo4j:
        print(f"Neo4j started at {neo4j.get_connection_url()}")
        time.sleep(2)
    print("Stopped successfully.")
except Exception as e:
    print(f"Error: {e}")
