# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

import subprocess
import sys
from typing import Any

import httpx
import pytest
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from coreason_runtime.execution_plane.gateway_bridge.master_mcp import MasterGatewayClient


# Step 5: NemoClaw Sandbox execution simulator
class MockNemoClawSandbox:
    def __init__(self, script: str) -> None:
        self.script = script

    def run(self) -> str:
        """Executes the Python script in a hermetically sealed subprocess."""
        # To simulate kernel-level process isolation, we run in a safe Python subprocess
        print(f"[NemoClaw Sandbox] Booting sandbox for script: {self.script!r}")
        try:
            result = subprocess.run(  # nosec B603  # noqa: S603
                [sys.executable, "-c", self.script],
                capture_output=True,
                text=True,
                timeout=5,
                check=True,
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError as e:
            return f"Error: {e.stderr.strip()}"


# Step 4: OpenShell Manager simulator
class MockOpenShellManager:
    def verify_and_build(self, grpc_payload: dict[str, Any]) -> str:
        """Verifies security credentials and builds the NemoClaw sandbox."""
        print("[OpenShell Manager] Received gRPC execution request on simulated port 8080")
        credentials = grpc_payload.get("security_context", {})
        if not credentials.get("authorized", False):
            raise PermissionError("OpenShell Security verification failed")

        script = grpc_payload.get("script_payload", "")
        print("[OpenShell Manager] Credentials verified. Spawning NemoClaw sandbox...")
        sandbox = MockNemoClawSandbox(script)
        return sandbox.run()


# Step 3: WasmCloud Translator simulator
class MockWasmCloudTranslator:
    def __init__(self) -> None:
        self.manager = MockOpenShellManager()

    def translate_and_deliver(self, nats_json_payload: dict[str, Any]) -> dict[str, Any]:
        """Translates the NATS JSON payload into OpenShell-compatible gRPC/HTTP payload."""
        print("[WasmCloud Translator] Subscribed to NATS lattice. Downloaded JSON bytes.")
        raw_script = nats_json_payload.get("script", "")

        # Translate to the strict "OpenShell Government Form" (simulating gRPC structure)
        grpc_payload = {
            "security_context": {
                "authorized": True,
                "spiffe_id": "spiffe://coreason.ai/ns/default/sa/runtime",
            },
            "script_payload": raw_script,
        }
        print("[WasmCloud Translator] Translating payload to strict OpenShell gRPC format.")

        # Act as HTTP web client to deliver it to OpenShell on port 8080
        print("[WasmCloud Translator] Delivering payload as HTTP web client to OpenShell...")
        output = self.manager.verify_and_build(grpc_payload)

        return {"execution_result": output}


# Step 2: NATS Gateway Provider simulator
app = FastAPI()
translator = MockWasmCloudTranslator()


@app.post("/mcp/{server_cid}/tools/call")
async def handle_tool_call(server_cid: str, request: Request) -> JSONResponse:
    body = await request.json()
    print(f"[Master Gateway] Received HTTP request for server: {server_cid}")

    tool_name = body.get("name")
    arguments = body.get("arguments", {})

    if tool_name not in ("calculate_math", "run_active_inference_model"):
        return JSONResponse(status_code=400, content={"error": f"Unknown tool: {tool_name}"})

    script = arguments.get("script")

    # Package into NATS payload (convert to JSON bytes and broadcast)
    nats_payload = {"script": script}
    print("[NATS Gateway] Converting payload to raw JSON bytes and broadcasting on NATS mesh...")

    # Broadcast across NATS: WasmCloud translator intercepts this NATS message
    response_payload = translator.translate_and_deliver(nats_payload)

    # Return translated result back to Gateway response format
    result = {
        "content": [
            {
                "type": "text",
                "text": response_payload["execution_result"],
            }
        ]
    }
    return JSONResponse(content=result)


@pytest.fixture
def patch_gateway_client(monkeypatch: Any) -> None:
    """Fixture to patch the httpx.AsyncClient used inside MasterGatewayClient."""
    transport = httpx.ASGITransport(app=app)
    original_client_init = httpx.AsyncClient.__init__

    def patched_init(self: httpx.AsyncClient, *args: Any, **kwargs: Any) -> None:
        kwargs["transport"] = transport
        original_client_init(self, *args, **kwargs)

    monkeypatch.setattr(httpx.AsyncClient, "__init__", patched_init)


@pytest.mark.asyncio
async def test_engineers_described_workflow(patch_gateway_client: Any) -> None:
    """End-to-End integration test simulating the ideal 5-step workflow described by the engineers."""
    # Instantiate the client (Step 1: The Brain)
    client = MasterGatewayClient(gateway_url="http://localhost:8080")

    print("\n--- BEGINNING IDEAL WORKFLOW TEST (MATH) ---")

    # Step 1: The Brain (Runtime) decides it needs to calculate a math problem.
    # It packages the Python script in a call to calculate_math.
    script_to_run = "print(2 + 2)"
    print(f"[The Brain] Dispatching calculation request for: {script_to_run!r}")

    response = await client.call_tool(
        server_cid="math-server",
        name="calculate_math",
        arguments={"script": script_to_run},
    )

    # Step 5 check: NemoClaw runs script, prints output, and shuts down.
    # The output is returned up the chain.
    content = response.get("content", [])
    assert len(content) > 0
    assert content[0]["type"] == "text"
    execution_output = content[0]["text"]

    print(f"[The Brain] Received execution result: {execution_output!r}")
    assert execution_output == "4"

    print("--- IDEAL WORKFLOW TEST (MATH) COMPLETED SUCCESSFULLY ---")


@pytest.mark.asyncio
async def test_engineers_flow_with_pymdp_model(patch_gateway_client: Any) -> None:
    """End-to-End integration test running a small PyMDP active inference model inside the NemoClaw sandbox."""
    client = MasterGatewayClient(gateway_url="http://localhost:8080")

    print("\n--- BEGINNING IDEAL WORKFLOW TEST (PYMDP ACTIVE INFERENCE MODEL) ---")

    # Step 1: The Brain (Runtime) launches a task requiring inference of a POMDP model.
    # It packages a script running PyMDP model belief updating.
    model_script = (
        "import numpy as np; "
        "from pymdp.agent import Agent; "
        "A = [np.array([[0.9, 0.1], [0.1, 0.9]])]; "
        "B = [np.array([[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]])]; "
        "C = [np.array([1.0, -1.0])]; "
        "D = [np.array([0.5, 0.5])]; "
        "agent = Agent(A=A, B=B, C=C, D=D); "
        "qs = agent.infer_states([[1]], empirical_prior=agent.D); "
        "print(float(qs[0].flatten()[1]))"
    )

    print("[The Brain] Dispatching model execution request...")

    response = await client.call_tool(
        server_cid="inference-server",
        name="run_active_inference_model",
        arguments={"script": model_script},
    )

    content = response.get("content", [])
    assert len(content) > 0
    assert content[0]["type"] == "text"
    execution_output = content[0]["text"]

    print(f"[The Brain] Received execution result: {execution_output!r}")

    # Assert output is correct (posterior anomaly probability is ~0.9)
    val = float(execution_output)
    assert abs(val - 0.9) < 1e-5

    print("--- IDEAL WORKFLOW TEST (PYMDP ACTIVE INFERENCE MODEL) COMPLETED SUCCESSFULLY ---")
