# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from neo4j import AsyncGraphDatabase


@pytest.mark.asyncio
async def test_neo4j_vector_capabilities(neo4j_container: Any) -> None:
    host = neo4j_container.get_container_host_ip()
    port = neo4j_container.get_exposed_port(7687)
    uri = f"bolt://{host}:{port}"
    driver = AsyncGraphDatabase.driver(uri, auth=("neo4j", "password"))

    async with driver.session() as session:
        # 1. Test normal SET for vector
        print("\nTesting SET...")
        await session.run("CREATE (n:TestNode {uuid: 'v1'})")
        await session.run("MATCH (n:TestNode {uuid: 'v1'}) SET n.vec = $vec", vec=[0.1, 0.2, 0.3])
        result = await session.run("MATCH (n:TestNode {uuid: 'v1'}) RETURN n.vec as vec")
        record = await result.single()
        assert record is not None
        print(f"Retrieved vec: {record['vec']}")
        assert record["vec"] == [0.1, 0.2, 0.3]
        print("[SUCCESS] Normal SET works for vectors")

        # 2. Test vector index creation (Procedure way)
        print("Testing db.index.vector.createNodeIndex...")
        try:
            await session.run("CALL db.index.vector.createNodeIndex('test_index', 'TestNode', 'vec', 3, 'cosine')")
            print("[SUCCESS] db.index.vector.createNodeIndex works")
        except Exception as e:
            print(f"[FAILURE] db.index.vector.createNodeIndex failed: {e}")

        # 3. Check if db.create.setNodeVectorProperty exists
        print("Testing db.create.setNodeVectorProperty...")
        try:
            await session.run(
                "MATCH (n:TestNode {uuid: 'v1'}) CALL db.create.setNodeVectorProperty(n, 'vec2', $vec)",
                vec=[0.4, 0.5, 0.6],
            )
            print("[SUCCESS] db.create.setNodeVectorProperty exists")
        except Exception as e:
            print(f"[FAILURE] db.create.setNodeVectorProperty missing: {e}")

        # 4. Check if db.create.setVectorProperty exists
        print("Testing db.create.setVectorProperty...")
        try:
            await session.run(
                "MATCH (n:TestNode {uuid: 'v1'}) CALL db.create.setVectorProperty(n, 'vec3', $vec)", vec=[0.7, 0.8, 0.9]
            )
            print("[SUCCESS] db.create.setVectorProperty works")
        except Exception as e:
            print(f"[FAILURE] db.create.setVectorProperty missing: {e}")

    await driver.close()
