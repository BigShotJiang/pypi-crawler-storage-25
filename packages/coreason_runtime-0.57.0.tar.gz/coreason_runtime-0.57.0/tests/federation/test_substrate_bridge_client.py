# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for SubstrateBridgeClient.

Tests the publish_crystallized_topology method via httpx.ASGITransport.
Zero unittest.mock — all network I/O is physically executed through ASGI.
"""

from typing import Any

import httpx
import pytest
from fastapi import FastAPI, HTTPException

from coreason_runtime.federation.substrate_bridge_client import SubstrateBridgeClient

# ── ASGI Test App ─────────────────────────────────────────────────────

app = FastAPI()


@app.post("/api/v1/transmute")
async def transmute_endpoint(request: dict[str, Any]) -> dict[str, Any]:
    """Physical test endpoint mimicking the ecosystem registry."""
    if request.get("manifest_type") == "fail_me":
        raise HTTPException(status_code=500, detail="Internal Server Error")
    return {
        "success": True,
        "urn": f"urn:coreason:mcp:{request.get('trace_id', 'unknown')}",
        "rust_efficiency_multiplier": 14.8,
    }


# ── Fixtures ──────────────────────────────────────────────────────────


@pytest.fixture
def bridge_client() -> SubstrateBridgeClient:
    transport = httpx.ASGITransport(app=app)
    return SubstrateBridgeClient(base_url="http://testserver", transport=transport)


@pytest.fixture
def bridge_client_no_transport() -> SubstrateBridgeClient:
    return SubstrateBridgeClient(base_url="http://127.0.0.1:1", transport=None)


# ── Tests ─────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_publish_crystallized_topology_success(bridge_client: SubstrateBridgeClient) -> None:
    """Successful topology publication returns ecosystem response."""
    result = await bridge_client.publish_crystallized_topology(
        event_dict={"status": "success", "outputs": {"result": "ok"}},
        trace_id="trace-001",
        manifest_type="architectural_transmutation",
        topology_payload={"nodes": {}, "edges": []},
    )
    if result["success"] is not True:
        pytest.fail(f"Expected success True, got {result['success']}")
    if "urn:coreason:mcp:trace-001" not in result["urn"]:
        pytest.fail(f"Expected URN containing trace-001, got {result['urn']}")
    if result["rust_efficiency_multiplier"] != 14.8:
        pytest.fail(f"Expected multiplier 14.8, got {result['rust_efficiency_multiplier']}")


@pytest.mark.asyncio
async def test_publish_crystallized_topology_server_error(bridge_client: SubstrateBridgeClient) -> None:
    """Server error triggers raise_for_status and raises httpx.HTTPStatusError."""
    with pytest.raises(httpx.HTTPStatusError):
        await bridge_client.publish_crystallized_topology(
            event_dict={"status": "error"},
            trace_id="trace-fail",
            manifest_type="fail_me",
            topology_payload={},
        )


@pytest.mark.asyncio
async def test_bridge_client_default_url() -> None:
    """Default URL fallback when ECOSYSTEM_REGISTRY_URL is unset."""
    client = SubstrateBridgeClient(base_url="http://ecosystem:8080", transport=httpx.ASGITransport(app=app))
    # The method should construct the URL from the default
    result = await client.publish_crystallized_topology(
        event_dict={"status": "success"},
        trace_id="trace-default",
        manifest_type="dag",
        topology_payload={},
    )
    if result["success"] is not True:
        pytest.fail(f"Expected success True, got {result['success']}")
