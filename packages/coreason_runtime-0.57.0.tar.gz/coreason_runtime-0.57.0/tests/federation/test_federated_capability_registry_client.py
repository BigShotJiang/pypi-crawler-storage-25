# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import time
from typing import Any

import httpx
import pytest
from coreason_manifest.spec.ontology import CommercialOverrideReceipt
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response

from coreason_runtime.federation.federated_capability_registry_client import FederatedCapabilityRegistryClient
from coreason_runtime.utils.exceptions import ManifestConformanceError

app = FastAPI()

# Mock endpoints for FederatedCapabilityRegistryClient


@app.get("/api/v1/registry/capabilities/{urn}/download")
async def get_wasm(urn: str) -> Response:
    if urn == "not_found":
        raise HTTPException(status_code=404, detail="Not Found")

    if urn == "too_big":
        # Return 11MB of zero bytes to trigger the 10MB trap
        return Response(content=b"\x00" * 11000000, media_type="application/wasm")

    # Regular valid returning
    return Response(content=b"VALID_WASM_BYTES", media_type="application/wasm")


@app.post("/api/v1/registry/capabilities/publish")
async def publish_mcp(event: dict[str, Any], request: Request) -> dict[str, Any]:
    # Mock publishing logic, returning urn
    if event.get("compression_ratio") is None:
        raise HTTPException(status_code=400, detail="Bad Request")

    receipt_header = request.headers.get("x-coreason-license-receipt")
    if receipt_header == "distr_private_123":
        return {"urn": f"urn:coreason:capability:{event.get('crystallized_semantic_node_cid')}_private"}

    return {"urn": f"urn:coreason:capability:{event.get('crystallized_semantic_node_cid')}"}


@pytest.fixture
def registry_client(monkeypatch: Any) -> FederatedCapabilityRegistryClient:
    monkeypatch.setenv("ECOSYSTEM_REGISTRY_URL", "http://mockserver")
    transport = httpx.ASGITransport(app=app)
    # The new __init__ accepts transport
    return FederatedCapabilityRegistryClient(transport=transport)


@pytest.fixture
def private_receipt() -> CommercialOverrideReceipt:
    current_time = int(time.time())
    return CommercialOverrideReceipt(
        license_tier="commercial",
        signer_did="did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB",
        signature_algorithm="ML-DSA-65",
        credential_format="sd-jwt",
        distr_license_cid="distr_private_123",
        hardware_zk_proof="fake_zk_snark",
        issued_at_epoch=current_time - 3600,
        expires_at_epoch=current_time + 86400,
        exp=current_time + 86400,
        iat=current_time - 3600,
        entitlements=["COMMERCIAL_USE", "PRIVATE_NETWORK_FEDERATION"],
        network_mode="private",
        federation_enabled=True,
    )


@pytest.mark.asyncio
async def test_fetch_capability_binary_valid(registry_client: FederatedCapabilityRegistryClient) -> None:
    data = await registry_client.fetch_capability_binary("urn:coreason:capability:valid")
    assert data == b"VALID_WASM_BYTES"


@pytest.mark.asyncio
async def test_fetch_capability_binary_not_found(registry_client: FederatedCapabilityRegistryClient) -> None:
    with pytest.raises(ManifestConformanceError, match="Client error '404 Not Found'"):
        await registry_client.fetch_capability_binary("not_found")


@pytest.mark.asyncio
async def test_fetch_capability_binary_too_big(registry_client: FederatedCapabilityRegistryClient) -> None:
    with pytest.raises(ManifestConformanceError, match="payload exceeds"):
        await registry_client.fetch_capability_binary("too_big")


@pytest.mark.asyncio
async def test_publish_master_mcp_success(registry_client: FederatedCapabilityRegistryClient) -> None:
    event = {
        "event_cid": "promotion-123",
        "crystallized_semantic_node_cid": "crystal-456",
        "compression_ratio": 1.0,
        "timestamp": 1234567890.0,
        "source_episodic_event_cids": ["Dynamic Intent Execution"],
    }
    urn = await registry_client.publish_master_mcp(event)
    assert urn == "urn:coreason:capability:crystal-456"


@pytest.mark.asyncio
async def test_client_ledger_switching_private(private_receipt: CommercialOverrideReceipt, monkeypatch: Any) -> None:
    """Tests that the client switches base URLs and injects headers when a private VCDM v2.0 receipt is provided."""
    monkeypatch.setenv("PRIVATE_REGISTRY_URL", "http://private-ledger.local:9090")
    monkeypatch.setenv("ECOSYSTEM_REGISTRY_URL", "http://ecosystem:8080")

    transport = httpx.ASGITransport(app=app)
    client = FederatedCapabilityRegistryClient(transport=transport, receipt=private_receipt)

    # Verify ledger switched to the private URL based on network_mode
    assert client.base_url == "http://private-ledger.local:9090"

    event = {
        "event_cid": "promotion-123",
        "crystallized_semantic_node_cid": "crystal-private-node",
        "compression_ratio": 1.0,
        "timestamp": 1234567890.0,
        "source_episodic_event_cids": [],
    }

    urn = await client.publish_master_mcp(event)

    # Verify the SD-JWT/Distr receipt was injected into the headers and processed by the server
    assert urn == "urn:coreason:capability:crystal-private-node_private"
