# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio

from neo4j import AsyncGraphDatabase


async def test_vector_set() -> None:
    uri = "bolt://localhost:7687"
    driver = AsyncGraphDatabase.driver(uri, auth=("neo4j", "password"))
    async with driver.session() as session:
        # Try to set a vector property using normal SET
        try:
            await session.run("CREATE (n:TestNode {uuid: '123'})")
            await session.run("MATCH (n:TestNode {uuid: '123'}) SET n.vec = $vec", vec=[0.1, 0.2, 0.3])
            print("SET vector property successful")

            # Now try to create a vector index
            try:
                await session.run(
                    "CREATE VECTOR INDEX test_index IF NOT EXISTS FOR (n:TestNode) ON (n.vec) "
                    "OPTIONS {indexConfig: {`vector.dimensions`: 3, `vector.similarity_function`: 'cosine'}}"
                )
                print("Vector index creation successful")
            except Exception as e:
                print(f"Vector index creation failed: {e}")

        except Exception as e:
            print(f"SET vector property failed: {e}")
    await driver.close()


if __name__ == "__main__":
    asyncio.run(test_vector_set())
