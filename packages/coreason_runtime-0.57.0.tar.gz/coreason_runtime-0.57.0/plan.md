1. Verify purges from Step 1 are correct and complete.
   - Ensure mcp_external_tools is removed from both src/ and tests/
   - Ensure imports are updated to nemoclaw_bridge
2. Review Step 2 (Unify the Bridge in master_mcp.py).
   - Ensure the created master_mcp.py works, tests pass.
3. Review Step 3 (Streamline Sovereign MCP Registry).
   - Checked sovereign_mcp_registry.py or federated_capability_registry_client.py for any transport-related tracking logic. None exist.
4. Execute Step 4 Verification and Cleanup.
   - Run type checker and tests.
   - Follow pre-commit instructions
5. Submit PR to GitHub.
