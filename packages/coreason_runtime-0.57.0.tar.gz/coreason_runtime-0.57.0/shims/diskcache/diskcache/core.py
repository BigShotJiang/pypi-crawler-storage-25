# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

# ruff: noqa: ARG001, ARG002
import hashlib
from collections.abc import Callable
from typing import Any

import msgspec

# Required sentinel objects
ENOVAL = object()
UNKNOWN = object()
MODE_PICKLE = 2


def full_name(func: Callable[..., Any]) -> str:
    """Return the name of the function."""
    return func.__name__


def args_to_key(base: Any, args: Any, kwargs: Any, typed: bool, ignore: Any) -> str:
    """Generate a cache key using msgspec for safe serialization."""
    encoder = msgspec.json.Encoder(sort_keys=True)  # type: ignore[call-arg]
    try:
        # Create a stable string representation
        data = (base, args, kwargs, typed)
        encoded_data = encoder.encode(data)
        return hashlib.sha256(encoded_data).hexdigest()
    except Exception:
        # Fallback to string concatenation if not JSON-serializable
        return hashlib.sha256(str((base, args, kwargs, typed)).encode("utf-8")).hexdigest()


class Disk:
    """Stub Disk class for API compatibility."""

    def __init__(self, directory: str, **kwargs: Any) -> None:
        self.directory = directory


class Cache(dict):  # type: ignore
    """RAM-backed ephemeral transport using a standard Python dict."""

    def __init__(
        self, directory: str, eviction_policy: str = "none", cull_limit: int = 0, disk: Any = None, **kwargs: Any
    ) -> None:
        super().__init__()
        self.directory = directory

    def set(
        self, key: Any, value: Any, expire: Any = None, read: bool = False, tag: Any = None, retry: bool = True
    ) -> None:
        """Store the value in the ephemeral dictionary."""
        self[key] = value

    def get(
        self,
        key: Any,
        default: Any = ENOVAL,
        read: bool = False,
        expire_time: bool = False,
        tag: bool = False,
        retry: bool = True,
    ) -> Any:
        """Retrieve the value from the ephemeral dictionary."""
        return super().get(key, default)

    def delete(self, key: Any, retry: bool = True) -> bool:
        """Safely evict the key if outlines requests deletion."""
        if key in self:
            del self[key]
            return True
        return False

    def close(self) -> None:
        """Swallow teardown calls during garbage collection."""

    def __enter__(self) -> "Cache":
        """Support standard context manager usage."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Safely tear down context manager."""
        self.close()


class FanoutCache(Cache):
    """Stub FanoutCache class for API compatibility."""
