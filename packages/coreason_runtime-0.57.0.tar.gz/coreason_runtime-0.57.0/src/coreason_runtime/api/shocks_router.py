# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from temporalio.client import Client, WorkflowExecutionStatus

from coreason_runtime.utils.settings import COREASON_TEMPORAL_HOST

shocks_router = APIRouter(prefix="/api/v1/orchestration/shocks", tags=["Resilience Shocks"])


class ResilienceShockRequest(BaseModel):
    """
    Structural boundary for external resilience signals.
    """

    workflow_id: str
    reason: str = "External Observability Alarm"
    severity: str = "critical"


@shocks_router.post("")
async def emit_resilience_shock(request: ResilienceShockRequest) -> dict[str, str]:
    """
    Sovereign Callback Ingress: Receives an external webhook signal from an OTel-native
    observability backend and injects a 'resilience_shock' signal into the specified workflow.

    AGENT INSTRUCTION: This endpoint is the primary gateway for the 'Sovereign Callback'
    architecture. It allows external OTel engines to exert physical control (cancellation)
    over agentic loops that breach thermodynamic bounds.
    """
    temporal_host = COREASON_TEMPORAL_HOST
    try:
        client = await Client.connect(temporal_host)
        handle = client.get_workflow_handle(request.workflow_id)

        # Verify workflow is actually running before signaling
        desc = await handle.describe()
        if desc.status != WorkflowExecutionStatus.RUNNING:
            raise HTTPException(status_code=410, detail="Workflow has already finished or is not running.")

        await handle.signal("resilience_shock", {"reason": request.reason, "severity": request.severity})
        return {"status": "shock_injected", "workflow_id": request.workflow_id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to inject resilience shock: {e!s}") from e
