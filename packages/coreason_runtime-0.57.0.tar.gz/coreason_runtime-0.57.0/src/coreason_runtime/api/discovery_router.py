# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from coreason_runtime.execution_plane.discovery_indexer import DiscoveryIndexer

discovery_router = APIRouter(prefix="/api/v1/discovery", tags=["Semantic Discovery"])


class DiscoverySearchRequest(BaseModel):
    query: str = Field(..., description="The semantic query to search for capabilities.")
    limit: int = Field(5, description="Maximum number of results to return.")
    tenant_cid: str = Field(
        "889955217295c2bfef2d6812071b633b0819477e67f57853febf116f69f30531",
        description="Tenant CID for segregation.",
    )


@discovery_router.post("/search")
async def search_capabilities(request: DiscoverySearchRequest) -> list[dict[str, Any]]:
    """AGENT INSTRUCTION: Perform semantic discovery of URN-addressable capabilities.

    CAUSAL AFFORDANCE: Resolves a natural language intent into a ranked list of available tools.

    EPISTEMIC BOUNDS: Limited to the capabilities indexed in the tenant's vector store.

    MCP ROUTING TRIGGERS: Semantic Search, Tool Discovery, Vector Retrieval, Intent Matching
    """
    try:
        indexer = DiscoveryIndexer(tenant_cid=request.tenant_cid)
        # Ensure local WASM tools are indexed
        indexer.sync_local_wasm()
        # Note: Remote MCP sync is typically handled by the MasterGateway bridge out-of-process,
        # but search_capabilities will find whatever is already in the LanceDB table.
        return indexer.search_capabilities(query=request.query, limit=request.limit, tenant_cid=request.tenant_cid)
    except Exception as e:
        from fastapi import HTTPException

        raise HTTPException(status_code=500, detail=f"Discovery search failed: {e}") from e
