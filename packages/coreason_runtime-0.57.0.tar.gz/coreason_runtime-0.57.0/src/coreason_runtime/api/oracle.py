# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
import os
from typing import Any

from coreason_manifest import InterventionReceipt
from fastapi import APIRouter, HTTPException
from temporalio.client import Client

from coreason_runtime.execution_plane.actuators.active_inference_tool import (
    run_active_inference_tool as run_active_inference,
)
from coreason_runtime.execution_plane.actuators.causal_inference_tool import (
    run_causal_inference_tool as run_causal_inference,
)
from coreason_runtime.execution_plane.actuators.neurosymbolic_tool import (
    run_neurosymbolic_verification_tool as run_neurosymbolic_verification,
)
from coreason_runtime.execution_plane.actuators.smpc_tool import run_smpc_tool as run_smpc
from coreason_runtime.utils.logger import logger

router = APIRouter(prefix="/api/v1/oracle", tags=["Epistemic Oracle"])


def _enforce_wetware_attestation(payload: InterventionReceipt) -> None:
    """Enforce WetwareAttestationContract verification on an InterventionReceipt.

    Raises HTTPException(401) if attestation is missing, incomplete, or cryptographically invalid.
    """
    attestation = getattr(payload, "attestation", None)
    if attestation is None:
        raise HTTPException(status_code=401, detail="Missing strict WetwareAttestationContract authorization")

    crypto_payload = getattr(attestation, "cryptographic_payload", "")
    if not crypto_payload:
        raise HTTPException(status_code=401, detail="WetwareAttestationContract requires cryptographic_payload")

    try:
        import base64

        json.loads(base64.b64decode(crypto_payload).decode("utf-8"))
    except Exception as e:
        logger.exception("WetwareAttestationContract validation encountered an unexpected fault")
        raise HTTPException(status_code=401, detail=f"WetwareAttestationContract verification failed: {e!s}") from e


@router.post("/resume/{workflow_id}")
async def resume_oracle(workflow_id: str, payload: InterventionReceipt) -> dict[str, str]:
    """Inject an absolute epistemic correction to bypass standard execution.

    Args:
        workflow_id: The Temporal workflow ID.
        payload: The strictly validated InterventionReceipt.

    Returns:
        Status indicating whether the signal was dispatched.
    """
    _enforce_wetware_attestation(payload)

    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
    try:
        client = await Client.connect(temporal_host)
        handle = client.get_workflow_handle(workflow_id)

        # Fire the gRPC signal to unpause the Temporal workflow with the strictly validated receipt
        await handle.signal("receive_oracle_override", payload.model_dump(mode="json"))
        return {"status": "success", "message": "Epistemic injection dispatched"}
    except Exception as e:
        logger.exception(f"Temporal manifold connection failed for workflow {workflow_id}")
        raise HTTPException(status_code=500, detail=f"Failed to reach Temporal Orchestrator: {e!s}") from e


@router.post("/resolve/{workflow_id}")
async def resolve_oracle(workflow_id: str, payload: InterventionReceipt) -> dict[str, str]:
    """Inject resolving priors to a suspended active inference manifold.

    Args:
        workflow_id: The Temporal workflow ID.
        payload: The strictly validated InterventionReceipt.

    Returns:
        Status indicating whether the signal was accepted.
    """
    _enforce_wetware_attestation(payload)

    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
    try:
        client = await Client.connect(temporal_host)
        handle = client.get_workflow_handle(workflow_id)

        # Fire the gRPC signal to unpause the Temporal workflow with the strictly validated receipt
        await handle.signal("inject_oracle_resolution", payload.model_dump(mode="json"))
        return {"status": "resolution_injected", "workflow_id": workflow_id}
    except Exception as e:
        logger.exception(f"Temporal manifold resolution injection failed for workflow {workflow_id}")
        raise HTTPException(status_code=500, detail=f"Failed to reach Temporal Orchestrator: {e!s}") from e


@router.post("/active-inference")
async def active_inference_tool(payload: dict[str, Any]) -> dict[str, Any]:
    """Execute Active Inference natively using PyMDP."""
    generative_model = payload.get("generative_model", {})
    observation_history = payload.get("observation_history")
    return run_active_inference(generative_model, observation_history=observation_history)  # type: ignore


@router.post("/causal-inference")
async def causal_inference_tool(payload: dict[str, Any]) -> dict[str, Any]:
    """Execute Causal Inference natively using DoWhy."""
    causal_graph = payload.get("causal_graph", {})
    dataset = payload.get("dataset", {})
    return run_causal_inference(causal_graph, dataset)  # type: ignore


@router.post("/neurosymbolic-verification")
async def neurosymbolic_tool(payload: dict[str, Any]) -> dict[str, Any]:
    """Execute Neurosymbolic Verification natively using Z3."""
    ontology_constraints = payload.get("ontology_constraints", {})
    return run_neurosymbolic_verification(ontology_constraints)  # type: ignore


@router.post("/smpc")
async def smpc_tool(payload: dict[str, Any]) -> dict[str, Any]:
    """Execute Secure Multi-Party Computation."""
    participants = payload.get("participants", [])
    protocol = payload.get("protocol", "garbled_circuits")
    return run_smpc(participants, protocol)  # type: ignore
