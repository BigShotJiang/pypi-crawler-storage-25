# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""AGENT INSTRUCTION: OpenTelemetry TracerProvider initialization and span utilities.

Replaces CoReason's custom Dapper-style tracing schemas (ExecutionSpanReceipt,
SpanEvent, TraceExportManifest) with the industry-standard OpenTelemetry SDK.

CAUSAL AFFORDANCE: Provides centralized tracer acquisition for the runtime,
enabling auto-instrumentation of instructor LLM calls, Temporal workflows,
and HTTP clients via a single TracerProvider backed by OTLP export.

EPISTEMIC BOUNDS: Configuration is strictly driven by standard OTel environment
variables (OTEL_SERVICE_NAME, OTEL_EXPORTER_OTLP_ENDPOINT, etc.).

MCP ROUTING TRIGGERS: OpenTelemetry, OTLP, Distributed Tracing, Dapper Model,
Observability, TracerProvider
"""

from __future__ import annotations

import os
from typing import Any

from coreason_runtime.utils.logger import logger


def _create_otlp_exporter(endpoint: str, protocol: str) -> Any:
    """Create the appropriate OTLP exporter based on protocol."""
    if protocol == "http/protobuf":
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    else:
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter  # type: ignore[assignment]

    return OTLPSpanExporter(endpoint=endpoint)


def _create_tracer_provider() -> Any:
    """Initialize and return an OpenTelemetry TracerProvider with OTLP export.

    Returns the configured TracerProvider, or None if OTel SDK is unavailable.
    """
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        service_name = os.environ.get("OTEL_SERVICE_NAME", "coreason-runtime")
        endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "")

        resource = Resource.create({"service.name": service_name})
        provider = TracerProvider(resource=resource)

        if endpoint:
            protocol = os.environ.get("OTEL_EXPORTER_OTLP_PROTOCOL", "grpc")
            exporter = _create_otlp_exporter(endpoint, protocol)
            provider.add_span_processor(BatchSpanProcessor(exporter))
            logger.info(f"OpenTelemetry TracerProvider initialized. Service: {service_name}, Endpoint: {endpoint}")
        else:
            logger.debug(
                "OpenTelemetry TracerProvider initialized without exporter "
                "(set OTEL_EXPORTER_OTLP_ENDPOINT to enable OTLP export)."
            )

        trace.set_tracer_provider(provider)
        return provider

    except ImportError:
        logger.debug("OpenTelemetry SDK not available. Tracing disabled.")
        return None


# Module-level singleton — initialized lazily on first get_tracer() call
_provider: Any = None
_initialized: bool = False


def get_tracer(name: str = "coreason-runtime") -> Any:
    """Acquire a tracer instance from the global TracerProvider.

    Returns an OpenTelemetry Tracer if the SDK is available,
    otherwise returns a no-op proxy tracer.
    """
    global _provider, _initialized

    if not _initialized:
        _provider = _create_tracer_provider()
        _initialized = True

    if _provider is not None:
        return _provider.get_tracer(name)

    # Return a no-op tracer when OTel SDK is unavailable
    return _NoOpTracer()


def shutdown_tracer() -> None:
    """Flush and shut down the tracer provider."""
    global _provider, _initialized

    if _provider is not None:
        try:
            _provider.shutdown()
        except Exception as e:
            logger.debug(f"TracerProvider shutdown error: {e}")

    _provider = None
    _initialized = False


class _NoOpSpan:
    """Minimal no-op span for environments without the OTel SDK."""

    def set_attribute(self, _key: str, _value: Any) -> None:
        pass

    def set_status(self, _status: Any, _description: str | None = None) -> None:
        pass

    def add_event(self, _name: str, _attributes: dict[str, Any] | None = None) -> None:
        pass

    def end(self) -> None:
        pass

    def __enter__(self) -> _NoOpSpan:
        return self

    def __exit__(self, *_args: Any) -> None:
        pass


class _NoOpTracer:
    """Minimal no-op tracer for environments without the OTel SDK."""

    def start_span(self, _name: str, **_kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()

    def start_as_current_span(self, _name: str, **_kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()
