# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import logging
from typing import Any

import graphiti_core.models.nodes.node_db_queries as node_queries
from graphiti_core.driver.driver import GraphProvider

logger = logging.getLogger(__name__)


def patch_graphiti_queries() -> None:
    """AGENT INSTRUCTION: Intercepts and repairs incompatible Cypher syntax in graphiti-core.

    Resolves Neo4j 5.x CypherSyntaxError: Invalid input '$': expected an identifier.
    Specifically targets SET n:$(node.labels) which is invalid in Neo4j 5.x UNWIND blocks.
    """
    if hasattr(node_queries, "_patched_by_coreason"):
        return

    original_get_bulk_query = node_queries.get_entity_node_save_bulk_query

    def patched_get_bulk_query(
        provider: GraphProvider, nodes: list[dict[Any, Any]], has_aoss: bool = False
    ) -> str | Any:
        query = original_get_bulk_query(provider, nodes, has_aoss)
        if provider == GraphProvider.NEO4J and isinstance(query, str) and "SET n:$(node.labels)" in query:
            # Neo4j 5.x does not support dynamic label assignment with $ inside UNWIND.
            # Since 'Entity' label is already provided by MERGE (n:Entity), we safely
            # remove the problematic SET n:$(node.labels) statement to maintain compatibility.
            # This is a temporary stabilizer until upstream graphiti-core supports Neo4j 5.x securing.
            logger.info("Patching graphiti-core Cypher: Removing SET n:$(node.labels)")
            query = query.replace("SET n:$(node.labels)", "")
        return query

    # Apply the patch to the source module
    node_queries.get_entity_node_save_bulk_query = patched_get_bulk_query

    # Also patch in bulk_utils where it's imported via 'from ... import ...'
    import graphiti_core.utils.bulk_utils as bulk_utils

    bulk_utils.get_entity_node_save_bulk_query = patched_get_bulk_query  # type: ignore[attr-defined]

    node_queries._patched_by_coreason = True  # type: ignore[attr-defined]
    logger.info("Successfully applied Neo4j compatibility patch to graphiti_core")
