# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Strict RFC-8785 JSON Canonicalization Scheme (JCS) utility.

AGENT INSTRUCTION: This utility guarantees absolute cryptographic byte-level invariance
by recursively normalizing python types, stripping `None` values to match the manifest ontology,
and serializing with the jcs library.
"""

from typing import Any

import jcs  # type: ignore[import-untyped]
from pydantic import BaseModel


def _to_json_compatible(obj: Any) -> Any:
    """Recursively converts an object to standard JSON types and strips None values from dicts.

    CAUSAL AFFORDANCE: Matches the coreason-manifest ontology _canonicalize_payload behavior
    to prevent semantic variance and ensure cross-language deterministic hashes.
    """
    if isinstance(obj, BaseModel):
        obj = obj.model_dump(mode="json")

    typ = type(obj)
    if typ is dict:
        return {k: _to_json_compatible(v) for k, v in obj.items() if v is not None}
    if typ in (list, tuple, set):
        return [_to_json_compatible(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    # Fallback to string representation for other non-primitive types (e.g. datetime, UUID, etc.)
    return str(obj)


def canonicalize(obj: Any) -> bytes:
    """Canonicalize a Python object to RFC 8785 JSON bytes.

    Returns:
        RFC 8785 compliant canonical bytes.
    """
    normalized = _to_json_compatible(obj)
    return bytes(jcs.canonicalize(normalized))
