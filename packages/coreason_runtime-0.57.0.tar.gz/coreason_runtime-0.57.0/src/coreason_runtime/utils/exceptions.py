# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


class KineticExecutionManifoldError(Exception):
    """Base exception for all Coreason Runtime kinetic failures."""


class ManifestConformanceError(KineticExecutionManifoldError, ValueError):
    """Raised when a topological manifest or schema violates formal ontology rules.

    Inherits from ValueError for backwards compatibility with existing exception guards.
    """


class SchemaOnWriteValidationError(ManifestConformanceError):
    """Raised when execution state mutates into an invalid conformation at boundary sync."""


class TopologySyntaxError(ManifestConformanceError):
    """Raised when the base JSON structure violates fundamental structural rules."""


class PayloadTooLargeError(KineticExecutionManifoldError):
    """AGENT INSTRUCTION: Raised when payload surpasses Topological Caging bounds."""


class SecurityViolationError(KineticExecutionManifoldError):
    """Raised when an execution violates strict security bounds enforced by the service mesh (SPIFFE/SPIRE + Envoy)."""


class BudgetExhaustionError(KineticExecutionManifoldError):
    """Raised when thermodynamic timeout or quota limit is breached."""


class IntegrityViolationError(KineticExecutionManifoldError):
    """Raised when a capability bundle's computed CID does not match the registry's expected content hash.

    This indicates potential supply-chain tampering, a stale cache, or an incomplete
    download. The runtime MUST reject execution of bundles that fail CID verification.
    """
