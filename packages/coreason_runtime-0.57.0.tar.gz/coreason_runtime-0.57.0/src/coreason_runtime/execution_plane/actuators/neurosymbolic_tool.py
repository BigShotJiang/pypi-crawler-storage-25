# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import typing

from mcp.server.fastmcp import FastMCP

app = FastMCP("neurosymbolic-verification-tool")


@app.tool()
def run_neurosymbolic_verification_tool(ontology_constraints: dict[str, typing.Any]) -> dict[str, typing.Any]:
    """Execute formal verification of neural outputs against symbolic ontology constraints.

    Args:
        ontology_constraints: A dictionary containing Z3-compatible symbolic constraints.

    Returns:
        A dictionary containing the SAT/UNSAT result and any counter-models identified.
    """
    from z3 import Solver, parse_smt2_string

    solver = Solver()

    axioms = ontology_constraints.get("axioms", [])
    constraint_count = len(axioms)

    if constraint_count > 0:
        solver.set("timeout", 1000)
        for axiom in axioms:
            try:
                parsed = parse_smt2_string(axiom)
                solver.add(parsed)
            except Exception:
                # In case of invalid SMT-LIB2 syntax, we might want to return unsatisfiable
                # but adding False forces it to unsat.
                solver.add(False)

    result = solver.check()

    return {
        "status": "success",
        "verification_result": str(result),
        "constraints_evaluated": constraint_count,
        "is_consistent": str(result) == "sat",
    }


if __name__ == "__main__":
    app.run()
