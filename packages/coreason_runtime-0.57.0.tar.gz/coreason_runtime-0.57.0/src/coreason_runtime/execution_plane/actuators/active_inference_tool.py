# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import typing

from mcp.server.fastmcp import FastMCP

app = FastMCP("active-inference-tool")


@app.tool()
def run_active_inference_tool(
    generative_model: dict[str, typing.Any],
    observation_history: list[typing.Any] | dict[str, typing.Any] | str | None = None,
) -> dict[str, typing.Any]:
    """Execute active inference to minimize variational free energy.

    Args:
        generative_model: The Pydantic-mapped generative model dictionary.
        observation_history: Optional history of observations sourced straight from telemetry.
                             Can be a list, dictionary (Polars-compatible), or a Parquet/IPC file path.

    Returns:
        A dictionary containing the expected information gain and precision-weighted policy.
    """
    try:
        import numpy as np
        from pymdp.agent import Agent
    except ImportError as err:
        msg = "pymdp and numpy are required for active inference operations but are not installed."
        raise ImportError(msg) from err

    import copy

    generative_model_copy = copy.deepcopy(generative_model)

    model_name = generative_model_copy.get("name", "unnamed_generative_model")

    # Extract or create default matrices
    a_matrix = generative_model_copy.get("A")
    b_matrix = generative_model_copy.get("B")
    c_matrix = generative_model_copy.get("C")
    d_matrix = generative_model_copy.get("D")

    def get_depth(item: typing.Any) -> int:
        if isinstance(item, (list, tuple)):
            if len(item) > 0:
                return 1 + get_depth(item[0])
            return 1
        return 0

    def to_np_list(val: typing.Any, expected_depth: int) -> list[np.ndarray]:
        if val is None:
            return []
        if not isinstance(val, (list, tuple)):
            return [np.array(val)]
        depth = get_depth(val)
        if depth < expected_depth:
            return [np.array(val)]
        return [np.array(x) for x in val]

    def _ensure_multidimensional_a(a_list: list[np.ndarray]) -> list[np.ndarray]:
        res = []
        for arr in a_list:
            if arr.ndim == 1:
                # Expand (N,) to (N, 1)
                arr = np.expand_dims(arr, axis=-1)
            elif arr.ndim == 0:
                # Scalar to (1, 1)
                arr = np.array([[arr.item()]])
            res.append(arr)
        return res

    def _ensure_multidimensional_b(b_list: list[np.ndarray]) -> list[np.ndarray]:
        res = []
        for arr in b_list:
            if arr.ndim == 1:
                # Expand (N,) to (N, 1, 1)
                arr = np.expand_dims(arr, axis=(-1, -2))
            elif arr.ndim == 2:
                # Expand (N, N) to (N, N, 1)
                arr = np.expand_dims(arr, axis=-1)
            elif arr.ndim == 0:
                arr = np.array([[[arr.item()]]])
            res.append(arr)
        return res

    def _ensure_multidimensional_c(c_list: list[np.ndarray]) -> list[np.ndarray]:
        res = []
        for arr in c_list:
            if arr.ndim == 0:
                arr = np.array([arr.item()])
            res.append(arr)
        return res

    def _ensure_multidimensional_d(d_list: list[np.ndarray]) -> list[np.ndarray]:
        res = []
        for arr in d_list:
            if arr.ndim == 0:
                arr = np.array([arr.item()])
            res.append(arr)
        return res

    # Standardize input into lists of numpy arrays (pymdp obj_array format)
    a_matrix = [np.array([[0.9, 0.1], [0.1, 0.9]])] if a_matrix is None else to_np_list(a_matrix, 3)
    b_matrix = (
        [np.array([[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]])]
        if b_matrix is None
        else to_np_list(b_matrix, 4)
    )
    c_matrix = [np.array([1.0, -1.0])] if c_matrix is None else to_np_list(c_matrix, 2)
    d_matrix = [np.array([0.5, 0.5])] if d_matrix is None else to_np_list(d_matrix, 2)

    a_matrix = _ensure_multidimensional_a(a_matrix)
    b_matrix = _ensure_multidimensional_b(b_matrix)
    c_matrix = _ensure_multidimensional_c(c_matrix)
    d_matrix = _ensure_multidimensional_d(d_matrix)

    # Initialize pymdp Agent
    agent = Agent(A=a_matrix, B=b_matrix, C=c_matrix, D=d_matrix)

    # Normalize observation history to list of lists (modalities per timestep)
    obs_list = []
    if observation_history is not None:
        if isinstance(observation_history, str):
            import os
            import tempfile

            import polars as pl

            def get_canonical_path(path: str) -> str:
                return os.path.normcase(os.path.realpath(os.path.abspath(path)))

            # Enforce strict path containment rules before letting Polars parse strings
            scratch_env = os.environ.get("COREASON_TELEMETRY_SCRATCH_DIR")
            allowed_bases = [scratch_env] if scratch_env else ["./scratch", tempfile.gettempdir()]

            if os.path.isabs(observation_history):
                target_path = os.path.abspath(observation_history)
            else:
                target_path = os.path.abspath(os.path.join(allowed_bases[0], observation_history))

            canonical_target = get_canonical_path(target_path)

            is_contained = False
            for base in allowed_bases:
                canonical_base = get_canonical_path(base)
                base_prefix = canonical_base if canonical_base.endswith(os.path.sep) else canonical_base + os.path.sep
                if canonical_target.startswith(base_prefix) or canonical_target == canonical_base:
                    is_contained = True
                    break

            if not is_contained:
                raise ValueError(
                    f"Epistemic Quarantine Violation: Path traversal security violation: Path breakout detected for path {observation_history}"
                )

            try:
                if observation_history.endswith(".parquet"):
                    df = pl.read_parquet(target_path)
                elif observation_history.endswith((".ipc", ".arrow", ".feather")):
                    df = pl.read_ipc(target_path)
                elif observation_history.endswith(".csv"):
                    df = pl.read_csv(target_path)
                else:
                    msg = f"Unsupported file format for observation history: {observation_history}"
                    raise ValueError(msg)

                if len(df.columns) > 1:
                    raw_steps = [list(row) for row in df.iter_rows()]
                else:
                    col_name = df.columns[0]
                    raw_steps = [[val] for val in df[col_name].to_list()]
            except Exception as e:
                msg = f"Failed to load observation history from file: {e!s}"
                raise ValueError(msg) from e
        elif isinstance(observation_history, dict):
            try:
                import polars as pl

                df = pl.DataFrame(observation_history)
                if len(df.columns) > 1:
                    raw_steps = [list(row) for row in df.iter_rows()]
                else:
                    col_name = df.columns[0]
                    raw_steps = [[val] for val in df[col_name].to_list()]
            except Exception as e:
                msg = f"Failed to load observation history from dictionary: {e!s}"
                raise ValueError(msg) from e
        elif isinstance(observation_history, list):
            if not observation_history:
                raw_steps = []
            elif isinstance(observation_history[0], list):
                raw_steps = observation_history
            else:
                for item in observation_history:
                    if isinstance(item, (dict, set, tuple)) and not isinstance(item, list):
                        msg = f"Observation must be a list of modality values, got {type(item)}"
                        raise ValueError(msg)
                raw_steps = [[val] for val in observation_history]
        else:
            msg = f"Unsupported type for observation_history: {type(observation_history)}"
            raise TypeError(msg)

        # Batch raw_steps (list of modalities for each timestep) to PyMDP format (batch_size = 1)
        for idx, step in enumerate(raw_steps):
            if not isinstance(step, list):
                msg = f"Observation at index {idx} must be a list of modality values, got {type(step)}"
                raise ValueError(msg)
            if len(step) != len(a_matrix):
                msg = f"Observation at index {idx} has length {len(step)}, but model has {len(a_matrix)} modalities"
                raise ValueError(msg)

            formatted_step = []
            for val in step:
                if isinstance(val, list):
                    formatted_step.append(val)
                else:
                    formatted_step.append([val])
            obs_list.append(formatted_step)

    # Fallback to dummy observation if history is empty or not provided
    if not obs_list:
        dummy_obs = [[0] for _ in range(len(a_matrix))]
        obs_list = [dummy_obs]

    # Run sequential active inference
    empirical_prior = agent.D
    all_efe = []
    qs = None
    for obs in obs_list:
        qs = agent.infer_states(obs, empirical_prior=empirical_prior)
        q_pi, efe = agent.infer_policies(qs)
        all_efe.append(efe)
        action = agent.sample_action(q_pi)
        empirical_prior = agent.update_empirical_prior(action, qs)

    # Calculate expected information gain using the optimal policy metric (lowest EFE, i.e. highest q_pi)
    if all_efe:
        q_pi_flat = np.asarray(q_pi).flatten()
        efe_flat = np.asarray(all_efe[-1]).flatten()
        best_policy_idx = np.argmax(q_pi_flat)
        expected_information_gain = float(-efe_flat[best_policy_idx])
    else:
        expected_information_gain = 0.0
    precision = float(np.mean(agent.alpha)) if hasattr(agent, "alpha") else 1.0

    return {
        "status": "success",
        "action": "minimize_variational_free_energy",
        "generative_model_referenced": model_name,
        "expected_information_gain": expected_information_gain,
        "precision": precision,
    }


if __name__ == "__main__":
    app.run()
