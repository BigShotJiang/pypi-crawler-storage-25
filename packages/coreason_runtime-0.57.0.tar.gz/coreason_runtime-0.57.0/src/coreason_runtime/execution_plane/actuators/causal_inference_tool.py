# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import typing

from mcp.server.fastmcp import FastMCP

app = FastMCP("causal-inference-tool")


@app.tool()
def run_causal_inference_tool(
    causal_graph: dict[str, typing.Any], dataset: dict[str, typing.Any]
) -> dict[str, typing.Any]:
    """Execute causal identification and estimation using the Do-Operator.

    Args:
        causal_graph: The structural causal model (DAG) defined as a dictionary.
        dataset: The observational data to perform inference upon.

    Returns:
        A dictionary containing the identified estimand and causal effect estimate.
    """
    # Causal Inference: Identifies and estimates causal effects via Do-Calculus
    try:
        import pandas as pd
        from dowhy import CausalModel
    except ImportError as err:
        msg = "dowhy and pandas are required for causal inference operations but are not installed."
        raise ImportError(msg) from err

    nodes = causal_graph.get("nodes", [])
    edges = causal_graph.get("edges", [])
    treatment = causal_graph.get("treatment", "treatment")
    outcome = causal_graph.get("outcome", "outcome")

    # Build a simple DOT graph for DoWhy
    dot_graph = "digraph {\n"
    for edge in edges:
        if isinstance(edge, (tuple, list)) and len(edge) == 2:
            dot_graph += f"    {edge[0]} -> {edge[1]};\n"
        elif isinstance(edge, str):
            dot_graph += f"    {edge};\n"
    dot_graph += "}"

    df = pd.DataFrame(dataset)

    model = CausalModel(
        data=df,
        treatment=treatment,
        outcome=outcome,
        graph=dot_graph,
    )

    identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)
    estimate = model.estimate_effect(
        identified_estimand, method_name="backdoor.linear_regression", test_significance=False
    )

    return {
        "status": "success",
        "identified_estimand": str(identified_estimand.estimands),
        "causal_effect": float(estimate.value),
        "graph_topology": {"node_count": len(nodes), "edge_count": len(edges)},
        "data_statistics": {"sample_size": len(df)},
    }


if __name__ == "__main__":
    app.run()
