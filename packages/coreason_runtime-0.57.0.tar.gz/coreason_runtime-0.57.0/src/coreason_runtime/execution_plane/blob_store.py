# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os
import tempfile
from typing import Any

import opendal

from coreason_runtime.utils.logger import logger


class UniversalBlobStore:
    """
    AGENT INSTRUCTION: An S3-compliant Blob Store interface abstracting object storage.

    CAUSAL AFFORDANCE: Physically decouples the CoReason runtime from proprietary cloud
    SDKs (like AWS boto3 specifics or Azure Storage SDK). By enforcing the S3 API protocol,
    it allows identical telemetry and state-backup operations to run on public hyperscalers
    (Amazon S3) and sovereign air-gapped bare-metal environments (MinIO).

    EPISTEMIC BOUNDS: The `endpoint_url` dynamically overrides the default AWS domain,
    enforcing universal routing.

    MCP ROUTING TRIGGERS: BYOO, S3 API, MinIO, Object Storage, Disaster Recovery, Air-Gapped
    """

    def __init__(self) -> None:
        scheme = os.environ.get("COREASON_STORAGE_SCHEME", "memory")
        options = {}

        if scheme == "s3":
            options["bucket"] = os.environ.get("COREASON_S3_BUCKET", "coreason-mesh-state")
            options["endpoint"] = os.environ.get("S3_ENDPOINT_URL", "")
            options["region"] = os.environ.get("AWS_REGION", "us-east-1")
            options["access_key_id"] = os.environ.get("AWS_ACCESS_KEY_ID", "")
            options["secret_access_key"] = os.environ.get("AWS_SECRET_ACCESS_KEY", "")
        elif scheme == "fs":
            options["root"] = os.environ.get("COREASON_STORAGE_PATH", os.path.join(tempfile.gettempdir(), "coreason"))

        # Create OpenDAL AsyncOperator
        self.operator = opendal.AsyncOperator(scheme, **options)

    async def write_bytes(self, object_key: str, data: bytes) -> str:
        """
        Durably write byte payloads (e.g., Arrow IPC telemetry or Temporal backups) to the S3 bucket.
        """
        try:
            await self.operator.write(object_key, data)
            # Retaining the same return format for compatibility, could adapt if needed
            bucket_name = os.environ.get("COREASON_S3_BUCKET", "coreason-mesh-state")
            return f"s3://{bucket_name}/{object_key}"
        except Exception as e:
            logger.error(f"Failed to write object {object_key}: {e}")
            raise

    async def read_bytes(self, object_key: str) -> bytes:
        """
        Retrieve durably stored byte payloads from the S3 bucket.
        """
        try:
            return await self.operator.read(object_key)
        except Exception as e:
            logger.error(f"Failed to read object {object_key}: {e}")
            raise

    async def stat(self, object_key: str) -> Any:
        """
        Get metadata of the object.
        """
        try:
            return await self.operator.stat(object_key)
        except Exception as e:
            logger.error(f"Failed to stat object {object_key}: {e}")
            raise

    async def delete(self, object_key: str) -> None:
        """
        Delete the object.
        """
        try:
            await self.operator.delete(object_key)
        except Exception as e:
            logger.error(f"Failed to delete object {object_key}: {e}")
            raise
