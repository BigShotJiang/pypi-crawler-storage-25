# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import yaml


class IOBroker:
    """
    Control Plane Configurator for IO and stream processing.

    Delegates byte movement and ETL logic entirely to Redpanda Connect (Benthos) by generating
    declarative YAML topologies. This preserves the Anti-CRUD mandate, treating data streams
    as immutable event logs.
    """

    def __init__(self, broker_url: str = "localhost:9092") -> None:
        self.broker_url = broker_url

    def generate_topology(
        self,
        input_topic: str,
        output_topic: str,
        consumer_group: str = "coreason-group",
        mapping_logic: str | None = None,
    ) -> str:
        """
        Generate a Redpanda Connect YAML topology string.

        Args:
            input_topic: The topic/stream to consume from.
            output_topic: The topic/stream to produce to.
            consumer_group: The consumer group for Kafka input.
            mapping_logic: Optional bloblang mapping string for data transformation.

        Returns:
            A YAML formatted string representing the Redpanda Connect configuration.
        """
        pipeline = {}
        if mapping_logic:
            pipeline = {"processors": [{"mapping": mapping_logic}]}

        config = {
            "input": {
                "kafka": {
                    "addresses": [self.broker_url],
                    "topics": [input_topic],
                    "consumer_group": consumer_group,
                }
            },
            "pipeline": pipeline,
            "output": {
                "kafka": {
                    "addresses": [self.broker_url],
                    "topic": output_topic,
                }
            },
        }

        # Remove empty pipeline if no mapping logic provided
        if not pipeline:
            config.pop("pipeline")

        return yaml.dump(config, sort_keys=False)
