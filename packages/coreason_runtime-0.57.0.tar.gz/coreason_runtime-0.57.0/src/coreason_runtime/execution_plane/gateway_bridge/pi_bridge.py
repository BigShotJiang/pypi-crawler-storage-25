# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
from typing import Any

from coreason_runtime.utils.logger import logger


class PiAgentCoreBridge:
    """The pi.dev execution bridge.

    This replaces heavy custom sandbox loops with the minimalist pi-agent-core.
    It restricts execution exclusively to Read, Write, Edit, and Bash primitives
    enforced by the Kinematic Safety Interlock.
    """

    def __init__(self) -> None:
        self.agent_path = "npx"
        self.agent_args = ["--yes", "@mariozechner/pi-coding-agent", "--headless"]

    async def execute_bash(self, command: str) -> dict[str, Any]:
        """Maps a restricted bash command to the pi-agent-core engine."""
        logger.info(f"Routing bash payload to pi.dev engine: {command}")

        try:
            process = await asyncio.create_subprocess_exec(
                self.agent_path,
                *self.agent_args,
                "bash",
                "--command",
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate()
            return {
                "stdout": stdout.decode("utf-8"),
                "stderr": stderr.decode("utf-8"),
                "exit_code": process.returncode or 0,
            }
        except Exception as e:
            logger.error(f"pi-agent-core execution failed: {e}")
            raise Exception(f"Sovereign execution failed: {e}") from e

    async def call_tool(self, _server_cid: str, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Route tool calls through the Pi minimalist primitives."""
        allowed_primitives = {"read_file", "write_file", "edit_file", "bash"}
        if name not in allowed_primitives:
            raise ValueError(f"Tool {name} rejected by PermissionBoundaryPolicy. Only {allowed_primitives} allowed.")

        logger.debug(f"Routing primitive {name} to pi.dev sandbox...")
        if name == "bash":
            return await self.execute_bash(arguments.get("command", ""))

        try:
            args_list = []
            for k, v in arguments.items():
                args_list.extend([f"--{k}", str(v)])

            process = await asyncio.create_subprocess_exec(
                self.agent_path,
                *self.agent_args,
                name,
                *args_list,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate()
            return {
                "stdout": stdout.decode("utf-8"),
                "stderr": stderr.decode("utf-8"),
                "exit_code": process.returncode or 0,
            }
        except Exception as e:
            logger.error(f"pi-agent-core tool execution failed: {e}")
            raise Exception(f"Sovereign execution failed: {e}") from e
