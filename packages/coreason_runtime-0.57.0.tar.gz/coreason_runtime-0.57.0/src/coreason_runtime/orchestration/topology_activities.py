# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from langgraph.graph.state import CompiledStateGraph
from temporalio import activity

from coreason_runtime.orchestration.graphs.topology_resolution_graph import create_topology_resolution_graph


@activity.defn
async def resolve_cognitive_topology(input_payload: dict[str, Any]) -> dict[str, Any]:
    """
    Atomic Temporal Activity that encapsulates the LangGraph state machine.
    This replaces the noisy multi-step legacy stochastic and Swarm workflows with a single L1 entry point
    that handles L2/L3 in-memory.
    """
    graph: CompiledStateGraph = create_topology_resolution_graph()

    initial_state = {
        "input_payload": input_payload,
        "current_solution": "",
        "critiques": [],
        "iteration_count": 0,
        "final_output": {},
    }

    # Run the graph in memory
    final_state = await graph.ainvoke(initial_state)

    # Compress the final state to return to Temporal
    return {
        "status": "resolved",
        "iterations": final_state.get("iteration_count"),
        "final_solution": final_state.get("current_solution"),
        "critiques": final_state.get("critiques", []),
    }
