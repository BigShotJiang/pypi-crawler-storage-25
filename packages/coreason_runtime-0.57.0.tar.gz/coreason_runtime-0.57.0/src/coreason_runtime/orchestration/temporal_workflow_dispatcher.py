# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import hashlib
import json
import typing
import uuid
from datetime import datetime

import httpx
import temporalio.exceptions
from coreason_manifest import (
    AdversarialMarketTopologyManifest,
    CapabilityForgeTopologyManifest,
    ConsensusFederationTopologyManifest,
    CouncilTopologyManifest,
    DigitalTwinTopologyManifest,
    DiscourseTreeManifest,
    DocumentKnowledgeGraphManifest,
    EvolutionaryTopologyManifest,
    HierarchicalDOMManifest,
    IntentElicitationTopologyManifest,
    StochasticTopologyManifest,
    SwarmTopologyManifest,
    WorkflowManifest,
)
from pydantic import ValidationError
from temporalio.client import Client

from coreason_runtime.federation.federated_capability_registry_client import FederatedCapabilityRegistryClient
from coreason_runtime.orchestration.worker import TASK_QUEUE
from coreason_runtime.orchestration.workflows import (
    AdversarialMarketExecutionWorkflow,
    CapabilityForgeExecutionWorkflow,
    CognitiveTopologyExecutionWorkflow,
    ConsensusFederationExecutionWorkflow,
    CouncilExecutionWorkflow,
    DigitalTwinExecutionWorkflow,
    DiscourseTreeExecutionWorkflow,
    DocumentKnowledgeGraphExecutionWorkflow,
    EvolutionaryExecutionWorkflow,
    HierarchicalDOMExecutionWorkflow,
    HollowPlaneBridgeWorkflow,
    IntentElicitationExecutionWorkflow,
    StochasticExecutionWorkflow,
)
from coreason_runtime.utils import canonicalize
from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_COMPUTE_BUDGET

if typing.TYPE_CHECKING:
    from coreason_manifest.spec.ontology import ActiveInferenceContract, CoreasonBaseState


_WORKFLOW_REGISTRY = {
    AdversarialMarketTopologyManifest.model_fields["topology_class"].default: AdversarialMarketExecutionWorkflow.run,
    CapabilityForgeTopologyManifest.model_fields["topology_class"].default: CapabilityForgeExecutionWorkflow.run,
    SwarmTopologyManifest.model_fields["topology_class"].default: CognitiveTopologyExecutionWorkflow.run,
    ConsensusFederationTopologyManifest.model_fields[
        "topology_class"
    ].default: ConsensusFederationExecutionWorkflow.run,
    CouncilTopologyManifest.model_fields["topology_class"].default: CouncilExecutionWorkflow.run,
    DigitalTwinTopologyManifest.model_fields["topology_class"].default: DigitalTwinExecutionWorkflow.run,
    DiscourseTreeManifest.model_fields["topology_class"].default: DiscourseTreeExecutionWorkflow.run,
    DocumentKnowledgeGraphManifest.model_fields["topology_class"].default: DocumentKnowledgeGraphExecutionWorkflow.run,
    EvolutionaryTopologyManifest.model_fields["topology_class"].default: EvolutionaryExecutionWorkflow.run,
    HierarchicalDOMManifest.model_fields["topology_class"].default: HierarchicalDOMExecutionWorkflow.run,
    IntentElicitationTopologyManifest.model_fields["topology_class"].default: IntentElicitationExecutionWorkflow.run,
    StochasticTopologyManifest.model_fields["topology_class"].default: StochasticExecutionWorkflow.run,
}


class KineticExecutionManifold:
    """AGENT INSTRUCTION: Primary orchestration boundary coupling the Python runtime to the Temporal execution plane.

    CAUSAL AFFORDANCE: Unlocks the ability to durably execute structural Cognitive DAGs and Cognitive Topologies.

    EPISTEMIC BOUNDS: Operates purely on native dictionaries to prevent Pydantic serialization exhaustion.

    MCP ROUTING TRIGGERS: temporal_orchestration, state_machine, kinetic_execution, DAG_traversal
    """

    def __init__(
        self,
        temporal_host: str = "localhost:7233",
        sglang_url: str = "http://localhost:30000",
        neo4j_uri: str = "bolt://localhost:7687",
        network_transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        """Initialize the KineticExecutionManifold.

        Args:
            temporal_host: The host and port of the Temporal cluster.
            sglang_url: The URL for the SGLang inference engine.
            neo4j_uri: The local path or URI for the Neo4j store.
        """
        self.temporal_host = temporal_host
        self.sglang_url = sglang_url
        self.neo4j_uri = neo4j_uri
        self.network_transport = network_transport
        self._client: Client | None = None

    async def execute_from_dict(
        self, manifest_data: dict[str, typing.Any], exogenous_perturbation_vector: str | None = None
    ) -> dict[str, typing.Any]:
        """Execute a coreason-manifest JSON dictionary natively in-memory."""
        logger.info("Execution started for manifest from RAM dictionary")

        try:
            topology_payload = manifest_data.get("topology", {})
            if "edges" in topology_payload:
                topology_payload["edges"] = [
                    tuple(edge) if isinstance(edge, list) else edge for edge in topology_payload["edges"]
                ]

            if "dag" in topology_payload and isinstance(topology_payload["dag"], dict):
                dag_payload = topology_payload["dag"]
                if "edges" in dag_payload:
                    dag_payload["edges"] = [
                        tuple(edge) if isinstance(edge, list) else edge for edge in dag_payload["edges"]
                    ]

            try:
                manifest = WorkflowManifest.model_validate(manifest_data, strict=False)
            except ValidationError as e:
                logger.error(f"Manifest validation failed: {e}")
                from coreason_runtime.utils.exceptions import ManifestConformanceError

                msg = f"Invalid WorkflowManifest format: {e}"
                raise ManifestConformanceError(msg) from e

            compile_to_base_topology = getattr(manifest.topology, "compile_to_base_topology", None)
            if compile_to_base_topology is not None:
                base_topology = compile_to_base_topology()
                _tp = base_topology.model_dump(mode="json", exclude_none=True)
                topology_payload = typing.cast("dict[str, typing.Any]", _tp)
                macro_type = getattr(manifest.topology, "topology_class", getattr(manifest.topology, "type", "unknown"))
                base_type = getattr(base_topology, "topology_class", getattr(base_topology, "type", "unknown"))
                logger.info(f"Unrolled macro-topology '{macro_type}' into base topology '{base_type}'")
            else:
                topology_payload = manifest.topology.model_dump(mode="json", exclude_none=True)

            if exogenous_perturbation_vector:
                for node_cid, node_data in typing.cast(
                    "dict[str, typing.Any]", topology_payload.get("nodes", {})
                ).items():
                    node_type = node_data.get("type") or node_data.get("topology_class")
                    if node_type == "composite" and node_data.get("eval_strategy") == "lazy":
                        logger.info(f"Deferred instantiation of sub-topology '{node_cid}' via coalg_thunking.")
                        node_data["status"] = "THUNKED"

                    if node_type == "agent":
                        current_desc = node_data.get("description", "")
                        node_data["description"] = (
                            f"{current_desc}\n\nUSER QUERY CONSTRAINT:\n{exogenous_perturbation_vector}"
                        )
                        logger.info(
                            f"Dynamically injected exogenous perturbation into agent node '{node_cid}' description"
                        )

            logger.debug("Successfully validated dictionary manifest payloads.")
        except ValueError as e:
            logger.exception(f"Failed to parse or validate manifest: {e}")
            raise

        if not self._client:
            logger.warning("Temporal client not connected. Attempting to connect now.")
            self._client = await Client.connect(self.temporal_host)

        trace_id = str(uuid.uuid7())
        workflow_id = f"execution-{trace_id}"
        manifest_type = topology_payload.get("topology_class", topology_payload.get("type"))

        immutable_matrix_raw: dict[str, typing.Any] = {
            "tenant_cid": manifest.tenant_cid,
            "session_cid": manifest.session_cid,
        }

        immutable_matrix = dict(sorted(immutable_matrix_raw.items()))

        budget = COREASON_COMPUTE_BUDGET

        envelope: dict[str, typing.Any] = {
            "trace_context": {"trace_cid": trace_id, "span_cid": trace_id, "causal_clock": 0},
            "state_vector": {
                "immutable_matrix": immutable_matrix,
                "mutable_matrix": {
                    "accumulated_tokens": 0,
                    "accumulated_cost": 0.0,
                    "iterations": 0,
                    "compute_budget": int(budget),
                },
                "is_delta": False,
            },
            "payload": topology_payload,
        }

        workflow_run_func = _WORKFLOW_REGISTRY.get(str(manifest_type))

        if not workflow_run_func:
            msg = f"Unknown or missing manifest type: {manifest_type}"
            raise ValueError(msg)

        try:
            handle = await self._client.start_workflow(
                typing.cast("typing.Any", workflow_run_func),
                envelope,
                id=workflow_id,
                task_queue=TASK_QUEUE,
            )
            result: dict[str, typing.Any] = await handle.result()
        except temporalio.client.WorkflowFailureError as e:
            err_str = str(e.cause)
            if "BudgetExhaustion" in err_str or "BudgetExceeded" in err_str or "SystemFaultEvent" in err_str:
                logger.critical(
                    f"Detected fatal state: {err_str}. Explicitly cancelling workflow {workflow_id} to prevent ghost loops."
                )
                try:
                    await self._client.get_workflow_handle(workflow_id).cancel()
                except Exception as ex:
                    logger.error(f"Failed to cancel workflow: {ex}")
            raise

        logger.info(f"Successfully executed manifest with result: {result}")

        if result is None or not isinstance(result, dict):
            return {}

        if manifest_type == "architectural_transmutation":
            from coreason_runtime.federation.substrate_bridge_client import SubstrateBridgeClient

            bridge_client = SubstrateBridgeClient(transport=self.network_transport)
            try:
                await bridge_client.publish_crystallized_topology(
                    event_dict=result,
                    trace_id=trace_id,
                    manifest_type=manifest_type,
                    topology_payload=topology_payload,
                )
                thermodynamic_efficiency = result.get("rust_efficiency_multiplier", 14.8)
                logger.info(
                    f"Substrate bridge established successfully. Efficiency multiplier: {thermodynamic_efficiency}x"
                )
            except Exception as e:
                logger.warning(f"Architectural Transmutation failed to bridge: {e}")

        if manifest_type in ["capability_forge", "composite", "cognitive_topology"] and result.get("success", True):
            mcp_id = result.get("manifest", {}).get("server_cid", f"crystalline_{trace_id}")
            hashlib.sha256(canonicalize(topology_payload)).hexdigest()

            event_dict = {
                "event_cid": f"promotion-{trace_id}",
                "crystallized_semantic_node_cid": mcp_id,
                "compression_ratio": 1.0,
                "timestamp": datetime.now().timestamp(),
                "source_episodic_event_cids": ["Dynamic Intent Execution"],
            }

            registry_client = FederatedCapabilityRegistryClient(transport=self.network_transport)
            try:
                assigned_urn = await registry_client.publish_master_mcp(event_dict)
                logger.info(f"Published Master MCP '{mcp_id}' to ecosystem registry. URN: {assigned_urn}")
            except httpx.RequestError as e:
                logger.warning(
                    f"Ecosystem network unavailable: {e}. Firing EpistemicPromotionEvent locally without saving to legacy stores."
                )

            result["_crystalized_promotion"] = event_dict

        return result

    async def execute(
        self, manifest_path: str, exogenous_perturbation_vector: str | None = None
    ) -> dict[str, typing.Any]:
        """Execute a coreason-manifest JSON file from disk.

        Args:
            manifest_path: The path to the manifest JSON file.
            exogenous_perturbation_vector: Optional explicit semantic shock injected into the root Markov Blanket.

        Returns:
            A dictionary representing the execution result.
        """
        logger.info(f"Execution started for manifest: {manifest_path}")

        try:
            with open(manifest_path) as f:
                manifest_data = json.load(f)
            return await self.execute_from_dict(manifest_data, exogenous_perturbation_vector)
        except (FileNotFoundError, json.JSONDecodeError, ValueError) as e:
            logger.exception(f"Failed to read, parse, or validate manifest at {manifest_path}: {e}")
            raise

    async def execute_active_inference(
        self, contract: "ActiveInferenceContract", initial_epoch: "CoreasonBaseState", epochs: int = 1
    ) -> dict[str, object]:
        """Execute active inference via the execution engine natively."""
        if not self._client:
            raise RuntimeError("Temporal Client not initialized. Dependency inject via self._client first.")

        from coreason_runtime.orchestration.workflows.active_inference_execution_workflow import (
            ActiveInferenceExecutionWorkflow,
        )

        inner_payload = {
            "active_inference_epochs": epochs,
            "contract": contract.model_dump(mode="json"),
            "epoch_state": initial_epoch.model_dump(mode="json"),
        }

        trace_id = str(uuid.uuid7())

        envelope: dict[str, typing.Any] = {
            "trace_context": {"trace_cid": trace_id, "span_cid": trace_id, "causal_clock": 0},
            "state_vector": {
                "immutable_matrix": {"tenant_cid": "system", "session_cid": "active_inference"},
                "mutable_matrix": {
                    "accumulated_tokens": 0,
                    "accumulated_cost": 0.0,
                    "iterations": 0,
                    "compute_budget": 100,
                },
                "is_delta": False,
            },
            "payload": inner_payload,
        }

        return typing.cast(
            "dict[str, typing.Any]",
            await self._client.execute_workflow(  # type: ignore
                ActiveInferenceExecutionWorkflow.run,
                envelope,
                id=f"active-inference-{contract.task_cid}",
                task_queue=TASK_QUEUE,
            ),
        )

    async def execute_hollow_plane_bridge(self, payload: dict[str, typing.Any]) -> dict[str, typing.Any]:
        """Execute a hollow plane state migration and projection workflow natively.

        This facilitates frictionless agent migration (body-shedding) across task queues
        and ontologies for developers.
        """
        if not self._client:
            logger.warning("Temporal client not connected. Attempting to connect now.")
            self._client = await Client.connect(self.temporal_host)

        trace_id = str(uuid.uuid7())
        workflow_id = f"bridge-{trace_id}"

        return typing.cast(
            "dict[str, typing.Any]",
            await self._client.execute_workflow(  # type: ignore
                HollowPlaneBridgeWorkflow.run,
                payload,
                id=workflow_id,
                task_queue=TASK_QUEUE,
            ),
        )
