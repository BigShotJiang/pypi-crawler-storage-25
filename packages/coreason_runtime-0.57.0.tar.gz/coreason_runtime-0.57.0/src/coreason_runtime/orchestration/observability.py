# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from pydantic import BaseModel, Field, HttpUrl
from temporalio import activity


class ResilienceShockError(Exception):
    """
    Raised when an external observability platform detects catastrophic drift
    or epistemic surprise, triggering a sovereign workflow cancellation.
    """

    def __init__(self, reason: str, severity: str = "critical") -> None:
        self.reason = reason
        self.severity = severity
        super().__init__(f"Resilience Shock: {reason} (Severity: {severity})")


class OTelObservabilityPolicy(BaseModel):
    """
    The policy definition for external observability platforms (e.g., Jaeger, Arize).
    CoReason delegates metric evaluation to standard OpenTelemetry-native engines.

    AGENT INSTRUCTION: This model acts as a structural policy container. It defines the
    thresholds projected as OTLP span attributes for evaluation by external engines.
    """

    max_semantic_similarity: float = Field(
        default=0.92,
        description="The maximum allowable cosine similarity between agent turns before external alarm.",
    )
    max_stalling_turns: int = Field(
        default=3,
        description="The maximum turns permitted with identical environment state hashes.",
    )
    shock_webhook_url: HttpUrl | None = Field(
        default=None,
        description="The callback endpoint for the external termination signal.",
    )


@activity.defn(name="EvaluateEpistemicSurpriseActivity")
async def evaluate_epistemic_surprise_activity(
    _epistemic_history: list[str],
    _bounds_payload: dict[str, Any],
) -> float:
    """EPISTEMIC NODE INSTRUCTION: Metric evaluation delegated to OTLP-native semantic engines.

    This activity facilitates the transition to standard OpenTelemetry-based metrics
    for "epistemic surprise," ensuring the runtime remains a hollow data plane.
    """
    # Note: We return 0.0 to prevent internal cancellations from firing.
    # Metric evaluation is now handled asynchronously by the OTel backend.
    return 0.0
