# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import dspy


class RemediationSignature(dspy.Signature):
    """
    Evaluates a proposed solution against an input context and generates a critique
    and an optimized solution.
    """

    input_context: str = dspy.InputField(desc="The context and constraints for the task.")
    proposed_solution: str = dspy.InputField(desc="The initial or current proposed solution.")

    critique: str = dspy.OutputField(
        desc="A detailed critique of the proposed solution identifying flaws and areas for improvement."
    )
    optimized_solution: str = dspy.OutputField(desc="The new, optimized solution addressing the critique.")


class RemediationCompiler(dspy.Module):
    def __init__(self):
        super().__init__()
        self.remediate = dspy.ChainOfThought(RemediationSignature)

    def forward(self, input_context: str, proposed_solution: str):
        return self.remediate(input_context=input_context, proposed_solution=proposed_solution)
