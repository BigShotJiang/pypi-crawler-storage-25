# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""AGENT INSTRUCTION: Executable Workflow orchestrating heuristic-based UI reorganization intents mapped across human holographic frontends dynamically."""

import uuid
from datetime import timedelta
from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import (
        EpistemicTelemetryEvent,
        SpatialTaxonomicRestructureIntent,
        WorkflowManifest,
    )

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class SpatialTaxonomicRestructureWorkflow(BaseTopologyWorkflow):
    """AGENT INSTRUCTION: Orchestrates spatial Taxonomic pivot intents dynamically bouncing across holographic SSE visual borders natively."""

    def __init__(self) -> None:
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any], manifest_payload: dict[str, Any]) -> dict[str, Any]:
        """Broadcast heuristic UI reorganization natively across holographic environments."""
        intent = SpatialTaxonomicRestructureIntent.model_validate(payload, strict=False)
        manifest = WorkflowManifest.model_validate(manifest_payload, strict=False)

        workflow.logger.info(f"Reorganizing UI Topology employing heuristic: {intent.restructure_heuristic}")

        # Topological Validation evaluating matching bounds actively against Node targets
        nodes = manifest.topology.nodes if hasattr(manifest.topology, "nodes") else {}  # generic mapping bound check
        if intent.target_taxonomy and isinstance(nodes, dict):
            target_nodes = intent.target_taxonomy.nodes or {}
            valid_targets = [n for n in target_nodes if n in nodes]
            if len(valid_targets) != len(target_nodes):
                workflow.logger.warning(
                    "Topological mismatch: Not all taxonomy targets mapped within execution limits."
                )

        # Wrapping Holographic structure parameters natively projecting mapping bindings efficiently targeting extension clients
        holographic_payload = {
            "type": "taxonomic_restructure",
            "heuristic": getattr(intent, "restructure_heuristic", "default_heuristic"),
            "target_taxonomy": getattr(intent.target_taxonomy, "manifest_cid", "global_taxonomy"),
            "animation_duration": 500,  # Map visual bounds dynamically
            "workflow_id": workflow.info().workflow_id,
        }

        # Telemetry Emission broadcasting via SSE holographic borders effectively mapping UI arrays
        await workflow.execute_activity(
            "BroadcastStateEchoIOActivity",
            args=["taxonomic_restructure_event", holographic_payload],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        # State Persistence: Compile an EpistemicTelemetryEvent structurally updating offline logic bounds
        with workflow.unsafe.sandbox_unrestricted():
            telemetry_event = EpistemicTelemetryEvent(
                event_cid=f"telemetry-{uuid.uuid4()}",
                timestamp=workflow.now().timestamp(),
                interaction_modality="expansion",
                target_node_cid=getattr(intent.target_taxonomy, "root_node_cid", "global_taxonomy"),
                dwell_duration_ms=500,
            )
            event_dict = telemetry_event.model_dump(mode="json")

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, telemetry_event.event_cid, True, holographic_payload, event_dict],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        return {"status": "success", "event_id": telemetry_event.event_cid}
