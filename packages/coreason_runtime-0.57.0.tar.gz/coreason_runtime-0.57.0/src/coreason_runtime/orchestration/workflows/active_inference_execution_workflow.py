# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Active inference execution logic.

AGENT INSTRUCTION: This workflow loops to update beliefs and minimize variational free energy.
"""

from datetime import timedelta
from typing import Any, TypedDict

from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import OracleExecutionReceipt, ProcessRewardContract

    from coreason_runtime.utils import canonicalize
    from coreason_runtime.utils.exceptions import ManifestConformanceError


class EpochStateDict(TypedDict, total=False):
    belief_matrix: list[float]


class ContractDict(TypedDict, total=False):
    threshold: float


class ActiveInferencePayload(TypedDict, total=False):
    epoch_state: EpochStateDict
    contract: ContractDict
    active_inference_epochs: int
    free_energy: float
    epistemic_reward_policy: Any
    prior_event_hash: str
    oracle_receipts: list[dict[str, Any]]


class SurpriseResult(TypedDict, total=False):
    free_energy: float
    novel_surprise_factor: float


class BeliefUpdateResult(TypedDict, total=False):
    belief_updated: bool
    variational_free_energy_reduction: float


class WorkflowResult(TypedDict, total=False):
    success: bool
    final_free_energy: float
    epochs_run: int
    rehydrated_hash: str
    oracle_receipts: list[dict[str, Any]]


@activity.defn
async def evaluate_surprise_compute_activity(payload: ActiveInferencePayload) -> SurpriseResult:
    """Evaluate variational free energy delta against expected state in memory.

    AGENT INSTRUCTION: Interface with lancedb/latent logic.
    """
    activity.logger.info("Evaluating active inference surprise compute phase")
    if not payload.get("epoch_state"):
        msg = "Invalid ActiveInferenceEpochState: Missing explicit payload boundaries."
        raise ManifestConformanceError(msg)

    return SurpriseResult(free_energy=0.5, novel_surprise_factor=0.8)


@activity.defn
async def update_latent_belief_activity(payload: ActiveInferencePayload) -> BeliefUpdateResult:
    """Update beliefs internally minimizing variational free energy."""
    activity.logger.info("Executing active inference latent belief update loop")
    if not payload.get("contract"):
        msg = "Invalid ActiveInferenceContract: Missing explicit payload boundaries."
        raise ManifestConformanceError(msg)

    val = payload.get("free_energy")
    reduction = float(val) if val is not None else 0.0
    return BeliefUpdateResult(belief_updated=True, variational_free_energy_reduction=reduction)


@activity.defn
async def flush_receipts_to_ledger_activity(receipts: list[dict[str, Any]]) -> str:
    """Dynamically stream execution receipts to the Epistemic Ledger plane.

    Borrowing from native open-source storage primitives to enforce a strict
    stateless substrate edge footprint.
    """
    import os

    from temporalio.exceptions import ApplicationError

    activity.logger.info(f"Initiating Epistemic Crystallization hook for {len(receipts)} batches.")

    try:
        if os.environ.get("SIMULATE_URN_AUTHORITY_TIMEOUT") == "true":
            raise ConnectionError("Timeout contacting Ecosystem URN Authority plane")
        # Simulated successful remote publish call to URN Authority
        return "URN_AUTHORITY_COMMIT_SUCCESS"

    except Exception as network_err:
        activity.logger.warning(
            f"Ecosystem network partition unreachable. Degrading gracefully to local LanceDB caching: {network_err}"
        )
        try:
            # Leverage native zero-copy LanceDB bindings to append blocks locally
            import lancedb  # type: ignore[import-untyped]

            db_uri = os.environ.get("LANCEDB_URI", "/var/run/coreason/cache/epistemic_cache.lance")
            db = await lancedb.connect_async(db_uri)
            try:
                table = await db.open_table("oracle_receipt_buffer")
                await table.add(receipts)
            except Exception:
                await db.create_table("oracle_receipt_buffer", data=receipts)
            return "LOCAL_LANCEDB_CACHE_SUCCESS"
        except Exception as storage_err:
            raise ApplicationError(
                f"SystemFaultEvent: Core Ledger plane and local fallback disk space exhausted: {storage_err}",
                non_retryable=True,
            ) from storage_err


@workflow.defn
class ActiveInferenceExecutionWorkflow:
    """Continuously updating engine optimizing target epistemic topologies."""

    def __init__(self) -> None:
        """Initialize ActiveInferenceExecutionWorkflow."""

    @workflow.run
    async def run(self, payload: ActiveInferencePayload) -> WorkflowResult:
        """Execute active inference looping mechanism.

        Args:
            payload: Payload dict containing the epoch_state and contract configurations.

        Returns:
            Dictionary representing convergence and final variation free energy state.
        """
        epochs_val = payload.get("active_inference_epochs")
        epochs = int(epochs_val) if epochs_val is not None else 1

        last_free_energy = 1.0
        oracle_receipts = list(payload.get("oracle_receipts") or [])

        for current_idx, _ in enumerate(range(epochs)):
            workflow.logger.info("Transition: executing surprise compute loop")
            eval_result = await workflow.execute_activity(
                evaluate_surprise_compute_activity,
                payload,
                schedule_to_close_timeout=timedelta(seconds=60),
            )

            last_free_energy = eval_result["free_energy"]

            if "epistemic_reward_policy" in payload:
                from pydantic import ValidationError

                try:
                    policy = ProcessRewardContract.model_validate(payload["epistemic_reward_policy"])
                except ValidationError:
                    policy = None
                except Exception as e:
                    workflow.logger.error(
                        f"Governance Configuration Fault: Unanticipated exception during epistemic reward policy validation: {e!s}",
                        exc_info=True,
                        extra={"telemetry_fault": "governance_configuration_fault"},
                    )
                    from temporalio.exceptions import ApplicationError

                    raise ApplicationError(
                        f"Governance Configuration Fault: Unanticipated exception during epistemic reward policy validation: {e!s}",
                        type="ManifestConformanceError",
                        non_retryable=True,
                    ) from e
                if policy is not None:
                    min_gradient = policy.convergence_sla.convergence_delta_epsilon if policy.convergence_sla else 0.0
                    max_tolerance = policy.pruning_threshold
                else:
                    policy_dict = payload["epistemic_reward_policy"]
                    min_gradient = policy_dict.get("convergence_sla", {}).get("convergence_delta_epsilon", 0.0)
                    max_tolerance = policy_dict.get("pruning_threshold", 1.0)
                if min_gradient > 0:
                    workflow.logger.info("Evaluating MCTS topological pruning constraints.")
                    if last_free_energy > max_tolerance:
                        workflow.logger.warning(
                            f"Branch Pruned: Free energy {last_free_energy} exceeds "
                            f"epistemic gradient tolerance {max_tolerance}"
                        )  # pragma: no cover
                        break  # pragma: no cover

            remaining_epochs = epochs - (current_idx + 1)

            update_payload = ActiveInferencePayload(**payload)
            update_payload["free_energy"] = last_free_energy
            update_payload["active_inference_epochs"] = remaining_epochs

            workflow.logger.info("Transition: updating latent beliefs")
            await workflow.execute_activity(
                update_latent_belief_activity,
                update_payload,
                schedule_to_close_timeout=timedelta(seconds=60),
            )

            import hashlib

            epoch_state_bytes = canonicalize(payload.get("epoch_state", {}))
            exec_hash = hashlib.sha256(epoch_state_bytes).hexdigest()

            receipt = OracleExecutionReceipt(
                solver_urn="urn:coreason:solver:active_inference:v1",
                execution_hash=exec_hash,
                tokens_burned=0,
            )
            oracle_receipts.append(receipt.model_dump(mode="json"))

            # Flush memory to external storage plane when buffer crosses limits
            if len(oracle_receipts) >= 25:
                workflow.logger.info("Buffer limit crossed. Offloading volatile cache to external storage.")
                await workflow.execute_activity(
                    flush_receipts_to_ledger_activity,
                    oracle_receipts,
                    schedule_to_close_timeout=timedelta(seconds=30),
                )
                oracle_receipts = []  # Instantly flush local cache memory bounds

            # The Temporal Axiom: O(1) Rehydration via ContinueAsNew
            if remaining_epochs > 0 and workflow.info().get_current_history_length() > 50:  # pragma: no cover
                import hashlib

                # We inject the cryptographically secure SHA-256 hash of the serialized snapshot
                serialized_snapshot_bytes = canonicalize(update_payload)
                prior_event_hash = hashlib.sha256(serialized_snapshot_bytes).hexdigest()

                workflow.logger.info(
                    f"O(1) Rehydration required. Merkle-DAG injected prior_event_hash: {prior_event_hash}"
                )

                # Emulate the respawn via ContinueAsNew
                update_payload["prior_event_hash"] = prior_event_hash
                update_payload["oracle_receipts"] = oracle_receipts
                workflow.continue_as_new(update_payload)
                return WorkflowResult(
                    success=True,
                    final_free_energy=last_free_energy,
                    epochs_run=current_idx + 1,
                    oracle_receipts=oracle_receipts,
                )

        # Final loop completion flush for remaining tail elements
        if oracle_receipts:
            await workflow.execute_activity(
                flush_receipts_to_ledger_activity,
                oracle_receipts,
                schedule_to_close_timeout=timedelta(seconds=30),
            )
            oracle_receipts = []

        return WorkflowResult(
            success=True,
            final_free_energy=last_free_energy,
            epochs_run=epochs,
            rehydrated_hash=str(payload.get("prior_event_hash", "")),
            oracle_receipts=[],
        )
