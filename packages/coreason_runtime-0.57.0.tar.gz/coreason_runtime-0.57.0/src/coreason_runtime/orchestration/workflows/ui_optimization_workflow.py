# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from datetime import timedelta
from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import SensoryUIUpgradeAvailableEvent

    from coreason_runtime.orchestration.workflows.base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class UIOptimizationWorkflow(BaseTopologyWorkflow):
    """
    Background UI Optimization Workflow.

    Monitors EpistemicProxyState usage and invokes the scaffold_sensory_urn MCP tool
    to forge improved URN geometries based on usage density. Emits a SensoryUIUpgradeAvailableEvent
    over the active SSE stream if a new URN scores higher than the user's current UI URN.
    """

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """
        Executes the background optimization logic.

        Args:
            payload: Payload containing optimization parameters like current_ui_urn and epistemic_deficit_vector.
        """
        workflow.logger.info("Starting UI Optimization Workflow...")

        current_ui_urn = payload.get("current_ui_urn")
        epistemic_deficit = payload.get("epistemic_deficit_vector", {})

        # 1. Trigger scaffold_sensory_urn via an MCP activity
        # We assume an activity exists that invokes the Meta-Engineering MCP tool `scaffold_sensory_urn`.
        # The result would be a newly forged URN.
        try:
            forge_result = await workflow.execute_activity(
                "InvokeScaffoldSensoryUrnMCPIOActivity",
                args=[{"geometric_schema_intent": epistemic_deficit}],
                schedule_to_close_timeout=timedelta(minutes=5),
            )
            new_ui_urn = forge_result.get("forged_urn")
        except Exception as e:
            workflow.logger.error(f"Failed to forge new sensory URN: {e}")
            return {"status": "failed", "error": str(e)}

        if not new_ui_urn or new_ui_urn == current_ui_urn:
            return {"status": "no_upgrade_needed"}

        # 2. Vector Boundary Matching & Scoring
        # In this workflow, we simulate the cosine-similarity routing mechanism
        # that determines if the new URN scores higher.
        try:
            score_result = await workflow.execute_activity(
                "EvaluateUIScoreComputeActivity",
                args=[{"current_urn": current_ui_urn, "new_urn": new_ui_urn, "deficit_vector": epistemic_deficit}],
                schedule_to_close_timeout=timedelta(minutes=1),
            )
        except Exception as e:
            workflow.logger.error(f"Failed to evaluate UI score: {e}")
            return {"status": "failed", "error": str(e)}

        if score_result.get("new_score", 0) > score_result.get("current_score", 0):
            # 3. Emit SensoryUIUpgradeAvailableEvent over the active SSE stream

            with workflow.unsafe.sandbox_unrestricted():
                upgrade_event = SensoryUIUpgradeAvailableEvent(
                    available_upgrade_urn=new_ui_urn,
                    improvement_delta=score_result.get("new_score", 0.0) - score_result.get("current_score", 0.0),
                )
                upgrade_payload = upgrade_event.model_dump(mode="json")

            # Emit to telemetry broker for SSE
            await workflow.execute_activity(
                "BroadcastStateEchoIOActivity",
                args=[
                    workflow.info().workflow_id,
                    {"type": "SensoryUIUpgradeAvailableEvent", "event": upgrade_payload},
                ],
                schedule_to_close_timeout=timedelta(seconds=10),
            )
            workflow.logger.info(f"Emitted SensoryUIUpgradeAvailableEvent for URN {new_ui_urn}")
            return {"status": "upgrade_emitted", "new_urn": new_ui_urn}

        return {"status": "completed"}
