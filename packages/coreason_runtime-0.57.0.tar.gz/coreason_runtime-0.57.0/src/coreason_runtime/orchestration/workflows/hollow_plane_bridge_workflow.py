# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Hollow Plane Bridging Engine logic.

AGENT INSTRUCTION: This workflow securely transfers agent state across non-intersecting ontologies.
"""

from datetime import timedelta
from typing import TypedDict

from temporalio import activity, workflow

from coreason_runtime.orchestration.migration_activities import (
    MigrationRequestPayload,
    rehydrate_agent_state_activity,
    serialize_agent_state_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


class BridgeRequestDict(TypedDict, total=False):
    target_plane: str
    tenant_cid: str
    target_task_queue: str
    snapshot_key: str


class ObserverPhysicsDict(TypedDict, total=False):
    optical_center_x: float


class TensorDict(TypedDict, total=False):
    tensor_hash: str


class TensorBoundaryPayload(TypedDict, total=False):
    bridge_request: BridgeRequestDict
    observer: ObserverPhysicsDict
    tensor: TensorDict
    boundary_verified: bool


class TensorBoundaryResult(TypedDict, total=False):
    boundary_verified: bool
    target_plane: str


class ProjectorResult(TypedDict, total=False):
    projection_status: str
    transported: bool


@activity.defn
async def verify_tensor_boundary_activity(payload: TensorBoundaryPayload) -> TensorBoundaryResult:
    """Verify semantic boundaries before bridging.

    AGENT INSTRUCTION: Validate the ObserverPhysics payload using the
    NDimensionalTensorManifest to determine crossing constraints.

    Mocks lancedb / latent verification semantic checks.
    Requires compatible dimensions or mathematically sound projections.
    """
    activity.logger.info("Verifying semantic bounding constraints across tensor manifest")
    bridge_req = payload.get("bridge_request", {})
    if (bridge_req or {}).get("target_plane") is None:
        msg = "Hollow Plane Boundary Violation: Missing target plane"
        raise ManifestConformanceError(msg)

    target_plane = (bridge_req or {}).get("target_plane", "unknown")

    return TensorBoundaryResult(boundary_verified=True, target_plane=target_plane)


@activity.defn
async def cross_dimensional_state_projector_activity(payload: TensorBoundaryPayload) -> ProjectorResult:
    """Execute the multi-dimensional transport.

    AGENT INSTRUCTION: Mathematically reshape the tensor for the target topology plane.
    Mocks state projection math mapped into target ontology.
    """
    activity.logger.info("Executing cross-dimensional hollow plane transfer")
    if not payload.get("boundary_verified"):
        msg = "Hollow Plane Boundary Violation: unverified projection"
        raise ManifestConformanceError(msg)

    return ProjectorResult(projection_status="complete", transported=True)


@workflow.defn
class HollowPlaneBridgeWorkflow:
    """Orchestrate N-dimensional hollow plane bridging."""

    @workflow.run
    async def run(self, payload: TensorBoundaryPayload) -> ProjectorResult:
        """Bridging lifecycle."""
        workflow.logger.info("Transition: orchestrate verify_tensor_boundary_activity")
        verify_result = await workflow.execute_activity(
            verify_tensor_boundary_activity,
            payload,
            schedule_to_close_timeout=timedelta(seconds=60),
        )

        # Retrieve migration identifiers
        bridge_req = payload.get("bridge_request", {}) or {}
        tenant_cid = bridge_req.get("tenant_cid", "default_tenant")
        workflow_id = workflow.info().workflow_id
        snapshot_key = bridge_req.get("snapshot_key", f"migration/{tenant_cid}/{workflow_id}.state")
        target_queue = bridge_req.get("target_task_queue", workflow.info().task_queue)

        # 1. Serialize state package on current queue (source node)
        workflow.logger.info("Orchestrating serialize_agent_state_activity on source node")
        serialize_payload: MigrationRequestPayload = {
            "tenant_cid": tenant_cid,
            "workflow_id": workflow_id,
            "snapshot_key": snapshot_key,
        }
        serialize_res = await workflow.execute_activity(
            serialize_agent_state_activity,
            serialize_payload,
            schedule_to_close_timeout=timedelta(seconds=120),
        )

        # 2. Rehydrate state package on target queue (destination node)
        workflow.logger.info(f"Orchestrating rehydrate_agent_state_activity on target queue: {target_queue}")
        rehydrate_payload: MigrationRequestPayload = {
            "tenant_cid": tenant_cid,
            "workflow_id": workflow_id,
            "snapshot_key": serialize_res["snapshot_key"],
            "signature": serialize_res["signature"],
        }
        await workflow.execute_activity(
            rehydrate_agent_state_activity,
            rehydrate_payload,
            task_queue=target_queue,
            schedule_to_close_timeout=timedelta(seconds=120),
        )

        projector_payload = TensorBoundaryPayload(**payload)
        projector_payload.update(verify_result)  # type: ignore

        workflow.logger.info("Transition: orchestrate cross_dimensional_state_projector")
        return await workflow.execute_activity(
            cross_dimensional_state_projector_activity,
            projector_payload,
            schedule_to_close_timeout=timedelta(seconds=120),
        )
