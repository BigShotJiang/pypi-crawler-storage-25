# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from datetime import timedelta
from typing import Any, cast

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class CognitiveTopologyExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Cognitive Topology manifest.

    AGENT INSTRUCTION: This workflow encapsulates the L1 Macro-Plane durable execution.
    It delegates the L2 Meso-Plane cyclic orchestration (LangGraph) to an atomic
    Temporal Activity, ensuring the noisy stochastic reasoning loops do not
    pollute the Temporal event history.
    """

    def __init__(self) -> None:
        """Initialize CognitiveTopologyExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Cognitive Topology workflow.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing a CognitiveTopologyManifest.

        Returns:
            A dictionary containing the resolved state from the LangGraph activity.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting CognitiveTopologyExecutionWorkflow")

        # Execute the LangGraph-based activity (L2 Meso-Plane)
        result = await workflow.execute_activity(
            "resolve_cognitive_topology",
            manifest_payload,
            schedule_to_close_timeout=timedelta(minutes=30),
        )

        workflow.logger.info("Completed CognitiveTopologyExecutionWorkflow")
        return cast("dict[str, Any]", result)
