# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from datetime import timedelta
from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class DocumentKnowledgeGraphExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Document Knowledge Graph Topology manifest."""

    def __init__(self) -> None:
        """Initialize DocumentKnowledgeGraphExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Document Knowledge Graph workflow.

        Args:
            payload: The ExecutionEnvelopeState containing a DocumentKnowledgeGraphManifest.

        Returns:
            A dictionary containing the estimated causal effect.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting DocumentKnowledgeGraphExecutionWorkflow")

        target_urn = "urn:coreason:actionspace:oracle:pywhy_dowhy_estimator:v1"

        intent_jsonrpc = {
            "jsonrpc": "2.0",
            "method": "mcp.ui.emit_intent",
            "params": {"name": target_urn, "arguments": manifest_payload},
        }

        estimation_result = await workflow.execute_activity(
            "ExecuteMCPToolIOActivity",
            args=[target_urn, intent_jsonrpc, {}],
            schedule_to_close_timeout=timedelta(minutes=30),
        )

        result = {
            "success": estimation_result.get("success", False),
            "estimated_effect": estimation_result.get("estimated_effect"),
            "manifest": {"server_cid": f"knowledge_graph_{workflow.info().workflow_id}"},
        }

        if "error" in estimation_result:
            result["error"] = estimation_result["error"]

        workflow.logger.info("Completed DocumentKnowledgeGraphExecutionWorkflow")

        return result
