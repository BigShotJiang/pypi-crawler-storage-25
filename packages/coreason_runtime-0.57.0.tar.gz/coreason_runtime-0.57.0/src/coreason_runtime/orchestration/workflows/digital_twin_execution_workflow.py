# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class DigitalTwinExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Digital Twin Topology manifest.

    AGENT INSTRUCTION: Establishes an epistemically isolated shadow graph for
    sandbox simulations. Enforces strict side-effect isolation and implements
    Monte Carlo rollouts bounded by SimulationConvergenceSLA.
    """

    def __init__(self) -> None:
        """Initialize DigitalTwinExecutionWorkflow."""
        super().__init__()
        self._pending_shocks: list[dict[str, Any]] = []

    @workflow.signal(name="inject_exogenous_shock")
    def inject_exogenous_shock(self, shock_payload: dict[str, Any]) -> None:
        """AGENT INSTRUCTION: Handle Out-of-Distribution Exogenous Epistemic Event."""
        workflow.logger.warning("Received Exogenous Epistemic Shock!")
        self._pending_shocks.append(shock_payload)

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Digital Twin workflow.

        AGENT INSTRUCTION: This workflow enforces strict epistemic isolation.
        When enforce_no_side_effects is True, NO tool execution or state broadcast
        activities are dispatched — only execute_tensor_inference_compute_activity is permitted.
        Monte Carlo rollouts converge via variance tolerance from the convergence_sla.


        AGENT INSTRUCTION: Store epistemic state (append-only ledger write is permitted even in isolation)

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing a DigitalTwinTopologyManifest.

        Returns:
            A dictionary containing the simulation results and convergence metrics.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting DigitalTwinExecutionWorkflow")

        results: list[dict[str, Any]] = []
        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import DigitalTwinTopologyManifest

            manifest = DigitalTwinTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")

        max_rollouts = manifest.convergence_sla.max_monte_carlo_rollouts
        variance_tolerance = manifest.convergence_sla.variance_tolerance
        enforce_isolation = manifest.enforce_no_side_effects

        if enforce_isolation:
            workflow.logger.info(
                "Digital Twin: Strict epistemic isolation enforced. "
                "No MCP tools or state broadcasts will be dispatched."
            )

        if self._current_state_envelope is None:
            msg = "State Envelope is None"
            raise ValueError(msg)

        node_cids = list(manifest.nodes.keys())
        rollout_scores: list[float] = []
        converged = False

        for rollout in range(max_rollouts):
            # Safe pivot preventing fast loop race conditions natively executing wait checkpoints
            await workflow.wait_condition(lambda: True)

            while self._pending_shocks:
                from coreason_manifest.spec.ontology import ExogenousEpistemicEvent

                shock_payload = self._pending_shocks.pop(0)

                with workflow.unsafe.sandbox_unrestricted():
                    shock_event = ExogenousEpistemicEvent.model_validate(shock_payload)

                shock_threshold = getattr(manifest, "shock_threshold", 0.05)
                if shock_event.bayesian_surprise_score > shock_threshold:
                    workflow.logger.warning(
                        f"Black Swan threshold breached! ({shock_event.bayesian_surprise_score} > {shock_threshold}). Absorbing shock."
                    )
                    shock_result = await workflow.execute_activity(
                        "ExecuteExogenousShockComputeActivity",
                        args=[shock_payload],
                        schedule_to_close_timeout=timedelta(minutes=1),
                    )
                    self.reconcile_state({"exogenous_shock_applied": shock_result})
                else:
                    workflow.logger.info("Shock rejected: Bayesian Surprise Score below threshold.")

            workflow.logger.info(f"Digital Twin rollout {rollout + 1}/{max_rollouts}")

            await workflow.sleep(timedelta(seconds=0.1))
            self.enforce_governance_limits(governance, workflow_start_time)

            self.reconcile_state({"rollout": rollout})

            rollout_results: list[dict[str, Any]] = []

            for node_cid in node_cids:
                node_profile = manifest.nodes[node_cid]
                with workflow.unsafe.sandbox_unrestricted():
                    node_payload = manifest_payload.get("nodes", {}).get(str(node_cid))
                    if not node_payload:
                        node_payload = node_profile.model_dump(mode="json")

                segregated_payload = {
                    "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                    "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                    "node_profile": node_payload,
                }

                result = await workflow.execute_activity(
                    "ExecuteNemoclawCognitiveActivity",
                    args=[
                        {
                            "name": "deploy_cognitive_topology",
                            "arguments": {
                                "workflow_id": workflow.info().workflow_id,
                                "payload": segregated_payload,
                                "schema_to_request": (
                                    "AutonomousAgentResponse"
                                    if (
                                        segregated_payload.get("node_profile", {}).get("action_space_cid")
                                        if isinstance(segregated_payload, dict) and "node_profile" in segregated_payload
                                        else (
                                            segregated_payload.get("action_space_cid")
                                            if isinstance(segregated_payload, dict)
                                            else None
                                        )
                                    )
                                    else "AgentResponse"
                                ),
                            },
                        }
                    ],
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=0),
                )

                usage = result.get("usage", {})
                self._accumulated_tokens += usage.get("total_tokens", 0)
                self._accumulated_cost += result.get("cost", 0.0)
                await self.record_resource_utilization("result", usage, result.get("cost", 0.0))

                rollout_results.append(result)

            results.append({"rollout": rollout, "results": rollout_results})

            rollout_score = sum(1.0 if r.get("success", False) else 0.0 for r in rollout_results) / max(
                len(rollout_results), 1
            )
            rollout_scores.append(rollout_score)

            if len(rollout_scores) >= 2:
                mean = sum(rollout_scores) / len(rollout_scores)
                variance = sum((s - mean) ** 2 for s in rollout_scores) / len(rollout_scores)
                workflow.logger.info(f"Digital Twin variance: {variance:.6f} (tolerance: {variance_tolerance})")
                if variance <= variance_tolerance:
                    converged = True
                    workflow.logger.info("Digital Twin: Variance convergence achieved. Stopping early.")
                    break

        self.reconcile_state(
            {
                "accumulated_tokens": self._accumulated_tokens,
                "accumulated_cost": self._accumulated_cost,
            }
        )

        final_result = results[-1] if results else {}
        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[
                workflow.info().workflow_id,
                f"twin:{manifest.target_topology_cid}",
                converged,
                final_result,
                None,
            ],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed DigitalTwinExecutionWorkflow")
        return {
            "status": "success",
            "converged": converged,
            "rollouts_completed": len(rollout_scores),
            "results": results,
        }
