# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from datetime import timedelta
from typing import Any

import httpx
from temporalio import activity, workflow

from coreason_runtime.execution_plane.gateway_bridge.master_mcp import MasterGatewayClient


class StochasticActivities:
    """A collection of activities for stochastic execution, enabling dependency injection."""

    def __init__(
        self,
        gateway_url: str | None = None,
        gateway_transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.bridge = MasterGatewayClient(gateway_url=gateway_url, transport=gateway_transport)

    @activity.defn(name="EvaluateTransitionProbabilityActivity")
    async def evaluate_transition_probability_activity(self, manifest_payload: dict[str, Any]) -> str:
        """Delegate stochastic transition resolution to MasterGateway sidecar.

        Args:
            manifest_payload: The dictionary representation of a StochasticTopologyManifest.

        Returns:
            The chosen string branch CID predicted by MasterGateway.
        """
        from temporalio.exceptions import ApplicationError

        try:
            # MasterGateway resolves the transition based on the topological matrix and current state
            result = await self.bridge.request(
                "urn:coreason:oracle:gateway", "transition/predict", {"topology": manifest_payload}
            )
            return str(result["target_branch"])
        except Exception as e:
            raise ApplicationError(
                f"Master Gateway Transition Resolution Failed: {e!s}", type="ActivityError", non_retryable=True
            ) from e


@workflow.defn(name="StochasticExecutionWorkflow", sandboxed=False)
class StochasticExecutionWorkflow:
    """Temporal workflow encapsulating probabilistically routed structural graphs bounded tightly by Markov blankets."""

    @workflow.run
    async def run(self, manifest_payload: dict[str, Any]) -> dict[str, Any]:
        """Execute the structurally bound stochastic graph delegating transitions to MasterGateway.

        Args:
            manifest_payload: The StochasticTopologyManifest describing nodes and probability matrix.

        Returns:
            A strictly formatted dictionary confirming route traversal logic dynamically.
        """
        # 1. Perimeter security delegated to MasterGateway (MarkovBlanketEnforcer removed)

        # 2. Evaluate stochastic transition probabilities mapping natively to Temporal Side-Effects
        target_branch = await workflow.execute_activity(
            "EvaluateTransitionProbabilityActivity",
            manifest_payload,
            start_to_close_timeout=timedelta(seconds=10),
        )

        return {"status": "stochastic_execution_completed", "traversed_branch": target_branch}
