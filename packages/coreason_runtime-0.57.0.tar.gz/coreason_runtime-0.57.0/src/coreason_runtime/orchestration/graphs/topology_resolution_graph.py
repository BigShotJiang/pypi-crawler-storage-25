# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
from typing import Any, TypedDict

from langgraph.graph import END, StateGraph
from langgraph.graph.state import CompiledStateGraph

from coreason_runtime.orchestration.solvers.remediation_compiler import RemediationCompiler


class GraphState(TypedDict):
    input_payload: dict[str, Any]
    current_solution: str
    critiques: list[str]
    iteration_count: int
    final_output: dict[str, Any]


def proposer_node(state: GraphState) -> dict[str, Any]:
    input_data = state.get("input_payload", {})
    current_solution = state.get("current_solution")
    if not current_solution:
        current_solution = json.dumps(input_data)

    return {"current_solution": current_solution, "iteration_count": state.get("iteration_count", 0) + 1}


def critique_and_optimize_node(state: GraphState) -> dict[str, Any]:
    compiler = RemediationCompiler()
    input_context = json.dumps(state.get("input_payload", {}))
    proposed_solution = state.get("current_solution", "")

    result = compiler(input_context=input_context, proposed_solution=proposed_solution)

    critiques = [*state.get("critiques", []), result.critique]

    return {"current_solution": result.optimized_solution, "critiques": critiques}


def routing_logic(state: GraphState) -> str:
    # If we have 3 critiques, end.
    if len(state.get("critiques", [])) >= 3:
        return "end"
    return "proposer"


def create_topology_resolution_graph() -> CompiledStateGraph:
    workflow = StateGraph(GraphState)

    workflow.add_node("proposer", proposer_node)
    workflow.add_node("critique_and_optimize", critique_and_optimize_node)

    workflow.set_entry_point("proposer")

    workflow.add_edge("proposer", "critique_and_optimize")

    workflow.add_conditional_edges("critique_and_optimize", routing_logic, {"proposer": "proposer", "end": END})

    return workflow.compile()
