# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""
Unified CLI Daemon interface for the Coreason Runtime.

This module provides the Typer CLI application for starting workers,
running the API, and executing manifests.
"""

import asyncio
from pathlib import Path
from typing import Annotated, Any

import typer
from dotenv import find_dotenv, load_dotenv

from coreason_runtime.orchestration.temporal_workflow_dispatcher import KineticExecutionManifold
from coreason_runtime.orchestration.worker import start_worker
from coreason_runtime.utils.logger import logger

load_dotenv(find_dotenv())

app = typer.Typer(
    name="coreason",
    help="Coreason Runtime CLI daemon.",
    add_completion=False,
)

start_app = typer.Typer(help="Commands for starting runtime processes.")
app.add_typer(start_app, name="start")


@start_app.command(name="node")
def start_node(
    dry_run: Annotated[
        bool,
        typer.Option(
            help="Parses structural inputs without hooking telemetry.",
        ),
    ] = False,
) -> None:
    """
    Bootstraps the Temporal Worker and connects it to the cluster.
    """
    logger.info("Starting Temporal Worker node...")
    if dry_run:
        return

    from coreason_runtime.utils.settings import COREASON_TEMPORAL_HOST

    asyncio.run(start_worker(COREASON_TEMPORAL_HOST))


def create_app() -> Any:
    from fastapi import FastAPI

    api_app = FastAPI(title="CoReason Runtime API")
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

    FastAPIInstrumentor.instrument_app(api_app)

    from coreason_runtime.api.discovery_router import discovery_router
    from coreason_runtime.api.middleware import EnterpriseIdentityMiddleware
    from coreason_runtime.api.oracle import router as oracle_router
    from coreason_runtime.api.predict_router import predict_router
    from coreason_runtime.api.schema import router as schema_router
    from coreason_runtime.api.shocks_router import shocks_router
    from coreason_runtime.api.state_router import state_router
    from coreason_runtime.api.temporal_router import temporal_router

    api_app.add_middleware(EnterpriseIdentityMiddleware)

    api_app.include_router(state_router)
    api_app.include_router(schema_router)
    api_app.include_router(oracle_router)
    api_app.include_router(predict_router)
    api_app.include_router(shocks_router)
    api_app.include_router(discovery_router)
    api_app.include_router(temporal_router)
    return api_app


@start_app.command(name="api")
def start_api(
    port: Annotated[
        int,
        typer.Option(
            help="Port to serve the FastAPI ingress on.",
        ),
    ] = 8000,
    dry_run: Annotated[
        bool,
        typer.Option(
            help="Parses structural inputs without hooking telemetry.",
        ),
    ] = False,
) -> None:
    """
    Boots the FastAPI ingress via uvicorn.
    """
    import uvicorn

    from coreason_runtime.utils.logger import logger

    logger.info("Starting FastAPI ingress API with Rebootless Patching (hot-reload) enabled...")
    if dry_run:
        return
    uvicorn.run(
        "coreason_runtime.cli:create_app",
        host="0.0.0.0",  # noqa: S104  # nosec B104
        port=port,
        factory=True,
        reload=True,
        log_config=None,
    )


@app.command(name="execute")
def execute(
    manifest_path: Annotated[
        Path,
        typer.Argument(
            help="Path to a local JSON manifest to parse and dispatch.",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
        ),
    ],
    query: Annotated[
        str | None,
        typer.Option(
            help="Inject a dynamic user query into the root agent node.",
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option(
            help="Parses structural inputs without hooking telemetry.",
        ),
    ] = False,
) -> None:
    """
    Reads a local JSON manifest, parses it into an ontology model,
    and dispatches it to the workflow engine.
    """
    logger.info(f"Executing manifest at {manifest_path}...")

    if dry_run:
        return

    async def _run() -> None:
        from temporalio.client import Client

        from coreason_runtime.utils.settings import COREASON_TEMPORAL_HOST

        engine = KineticExecutionManifold()
        engine._client = await Client.connect(COREASON_TEMPORAL_HOST)
        await engine.execute(str(manifest_path), exogenous_perturbation_vector=query)

    asyncio.run(_run())


if __name__ == "__main__":
    app()
