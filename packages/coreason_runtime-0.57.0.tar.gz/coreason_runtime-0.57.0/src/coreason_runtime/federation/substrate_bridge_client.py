# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os
import typing

import httpx
from loguru import logger


class SubstrateBridgeClient:
    """AGENT INSTRUCTION: Bridges the kinetic execution plane to the coreason-ecosystem
    registry for Master MCP publication and crystallized topology promotion.

    CAUSAL AFFORDANCE: Publishes crystallized epistemic nodes as Master MCP servers,
    falling back to local LanceDB on network failure.

    EPISTEMIC BOUNDS: Network-bound I/O via httpx with injectable transport.

    MCP ROUTING TRIGGERS: federation, ecosystem_registry, master_mcp_publication,
    epistemic_promotion, crystallized_topology, substrate_bridge, urn_assignment
    """

    def __init__(
        self,
        base_url: str | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        """Initialize the SubstrateBridgeClient.

        Args:
            base_url: Optional base URL for the ecosystem registry.
            transport: Optional injectable httpx transport for testing.
        """
        # Explicitly handling None case from os.getenv to satisfy Mypy union-attr requirements
        resolved_url = base_url or os.getenv("ECOSYSTEM_REGISTRY_URL") or "http://ecosystem:8080"
        self.base_url = resolved_url.rstrip("/")
        self.transport = transport

    async def publish_crystallized_topology(
        self,
        event_dict: dict[str, typing.Any],
        trace_id: str,
        manifest_type: str,
        topology_payload: dict[str, typing.Any],
    ) -> dict[str, typing.Any]:
        """Publish a crystallized topology to the ecosystem registry.

        Args:
            event_dict: The execution result dictionary.
            trace_id: The trace identifier for the execution.
            manifest_type: The type of manifest being published.
            topology_payload: The topology payload for the published MCP.

        Returns:
            The response from the ecosystem registry.
        """
        url = f"{self.base_url}/api/v1/transmute"
        payload = {
            "trace_id": trace_id,
            "manifest_type": manifest_type,
            "topology_payload": topology_payload,
            "result": event_dict,
        }

        transport_kwargs: dict[str, typing.Any] = {}
        if self.transport is not None:
            transport_kwargs["transport"] = self.transport

        async with httpx.AsyncClient(base_url=url, **transport_kwargs) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            result: dict[str, typing.Any] = response.json()
            logger.info(f"Substrate bridge published topology for trace {trace_id}")
            return result
