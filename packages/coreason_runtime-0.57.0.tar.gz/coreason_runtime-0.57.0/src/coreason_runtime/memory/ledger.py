# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""AGENT INSTRUCTION: Graphiti-backed Epistemic Ledger Manager.

Implements the same interface as EpistemicLedgerManager but delegates to
Graphiti's temporal knowledge graph for bi-temporal episodic storage,
automatic entity extraction, temporal edge invalidation (replacing BFS
cascade), and hierarchical community detection.

CAUSAL AFFORDANCE: Enables the orchestration layer to persist and query
execution state using Graphiti's native temporal semantics instead of
manual LanceDB Medallion layers.

EPISTEMIC BOUNDS: All outputs must validate against EpistemicLedgerState
from coreason-manifest. No schema changes permitted.

MCP ROUTING TRIGGERS: Temporal Knowledge Graph, Episodic Memory, Defeasible
Cascade, Community Detection, Truth Maintenance, Graphiti Adapter
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from coreason_runtime.utils.logger import logger

if TYPE_CHECKING:
    from coreason_manifest import CognitiveActionSpaceManifest

    from coreason_runtime.memory.graphiti_engine import GraphitiStateEngine


class GraphitiEpistemicLedgerManager:
    """Graphiti-backed Epistemic Ledger implementing the EpistemicLedgerManager interface.

    AGENT INSTRUCTION: This adapter translates all Medallion-layer operations
    (Bronze/Silver/Gold) into Graphiti episodic ingestion and temporal graph
    queries. The defeasible cascade uses Graphiti's native edge invalidation
    instead of manual BFS traversal.

    CAUSAL AFFORDANCE: Provides full round-trip fidelity: AnyStateEvent →
    Graphiti episode → EpistemicLedgerState hydration.

    EPISTEMIC BOUNDS: Output must always validate against EpistemicLedgerState.
    Cryptographic signing is delegated to Sigstore (Cosign + Rekor).

    MCP ROUTING TRIGGERS: Epistemic Ledger, Graphiti Adapter, Temporal
    Invalidation, Medallion Migration, Bronze Silver Gold
    """

    def __init__(self, engine: GraphitiStateEngine) -> None:
        self.engine = engine

    async def bootstrap(self) -> None:
        """Initialize Graphiti indices and constraints."""
        await self.engine.bootstrap()
        logger.info("GraphitiEpistemicLedgerManager bootstrapped.")

    async def commit_bronze_failure_telemetry(
        self, workflow_id: str, intent_hash: str, raw_payload: dict[str, Any], error: str
    ) -> None:
        """Ingest high-entropy failure data as a Graphiti episode.

        Maps to the Bronze Medallion layer: raw, unprocessed failure telemetry.
        """
        from graphiti_core.nodes import EpisodeType

        episode_body = json.dumps(
            {
                "intent_hash": intent_hash,
                "error_trace": error,
                "raw_payload": str(raw_payload),
                "medallion_layer": "bronze",
            }
        )

        await self.engine.graphiti.add_episode(
            name=f"bronze_failure_{intent_hash}",
            episode_body=episode_body,
            source_description="CoReason Bronze Medallion Layer - Failure Telemetry Ingestion",
            source=EpisodeType.json,
            group_id=workflow_id,
            reference_time=datetime.now(tz=UTC),
        )
        logger.debug(f"Bronze Failure Telemetry Committed via Graphiti. Merkle Root: {intent_hash}")

    async def commit_silver_standardized_state(self, workflow_id: str, dataframe: Any) -> None:
        """Ingest standardized entity data as Graphiti episodes.

        Maps to the Silver Medallion layer: entity-resolved, standardized.
        Each row in the Arrow table becomes a separate episode.
        """
        from graphiti_core.nodes import EpisodeType

        rows = dataframe.to_pylist() if hasattr(dataframe, "to_pylist") else []

        for row in rows:
            entity_uuid = row.get("entity_uuid", "unknown")
            episode_body = json.dumps(
                {
                    "entity_uuid": entity_uuid,
                    "payload": row.get("payload", ""),
                    "medallion_layer": "silver",
                }
            )

            await self.engine.graphiti.add_episode(
                name=f"silver_entity_{entity_uuid}",
                episode_body=episode_body,
                source_description="CoReason Silver Medallion Layer - Standardized Entity Resolution",
                source=EpisodeType.json,
                group_id=workflow_id,
                reference_time=datetime.now(tz=UTC),
            )

        logger.info(f"Committed Silver Standardization via Graphiti for workflow: {workflow_id}")

    async def promote_silver_to_gold(
        self, workflow_id: str, silver_intent_hash: str, _policy: Any | None = None
    ) -> None:
        """Promote Silver entities to Gold crystallization via Graphiti.

        Graphiti's community detection and entity consolidation replace
        the manual Silver→Gold promotion logic.
        """
        from graphiti_core.nodes import EpisodeType

        # Search for Silver-layer episodes matching this intent
        results = await self.engine.graphiti.search(
            query=silver_intent_hash,
            group_ids=[workflow_id],
            num_results=100,
        )

        if not results:
            logger.warning(
                f"Silver-to-Gold Promotion Rejection via Graphiti: No matching entities for {silver_intent_hash}."
            )
            return

        # Commit Gold crystallization episode
        gold_body = json.dumps(
            {
                "intent_hash": silver_intent_hash,
                "status": "success",
                "medallion_layer": "gold",
                "source_results_count": len(results),
            }
        )
        await self.engine.graphiti.add_episode(
            name=f"gold_crystallization_{silver_intent_hash}",
            episode_body=gold_body,
            source_description="CoReason Gold Medallion Layer - Crystallization Promotion",
            source=EpisodeType.json,
            group_id=workflow_id,
            reference_time=datetime.now(tz=UTC),
        )
        logger.info(f"Gold Crystallization via Graphiti Completed: {silver_intent_hash}")

    async def commit_gold_crystallization(
        self,
        workflow_id: str,
        intent_hash: str,
        receipt: Any,
    ) -> None:
        """Commit a verified Gold-layer crystallization.

        Cryptographic signing is delegated to Sigstore (Cosign + Rekor).
        """
        from graphiti_core.nodes import EpisodeType

        if not intent_hash:
            msg = "Gold Cache Rejection: Missing intent hash"
            raise ValueError(msg)

        # Serialize receipt into the episode
        episode_body = json.dumps(
            {
                "intent_hash": intent_hash,
                "status": "success",
                "receipt_payload": receipt.model_dump_json(),
                "medallion_layer": "gold",
            }
        )

        await self.engine.graphiti.add_episode(
            name=f"gold_crystallization_{intent_hash}",
            episode_body=episode_body,
            source_description="CoReason Gold Medallion Layer - Crystallization",
            source=EpisodeType.json,
            group_id=workflow_id,
            reference_time=datetime.now(tz=UTC),
        )
        logger.info(f"Gold State Crystallized via Graphiti. Intent hash: {intent_hash}")

    # Alias for backward compatibility
    crystallize_gold_state = commit_gold_crystallization

    async def fetch_memoized_state_io_activity(
        self, _query_vector: list[float], threshold: float = 0.05
    ) -> dict[str, Any] | None:
        """Query Graphiti using hybrid search for near-exact semantic matches."""
        # Graphiti's search() returns EntityEdge objects
        results = await self.engine.graphiti.search(
            query="memoized state lookup",
            num_results=1,
        )

        if not results:
            return None

        top_result = results[0]

        # Apply threshold check (Graphiti scores are typically 0-1)
        score = getattr(top_result, "score", 0.0) or 0.0
        if score < (1.0 - threshold):
            return None

        try:
            fact_data = json.loads(top_result.fact) if isinstance(top_result.fact, str) else {}
        except Exception:
            return None

        return dict(fact_data)

    async def fetch_action_space_manifest(self, action_space_cid: str) -> CognitiveActionSpaceManifest | None:
        """Hydrate an action space ontology from Graphiti."""
        results = await self.engine.graphiti.search(
            query=f"action_space {action_space_cid}",
            num_results=1,
        )

        if not results:
            return None

        try:
            fact_data = json.loads(results[0].fact) if isinstance(results[0].fact, str) else {}
            from coreason_manifest.spec.ontology import CognitiveActionSpaceManifest

            return CognitiveActionSpaceManifest.model_validate(fact_data)
        except Exception:
            return None

    async def apply_defeasible_cascade(self, root_intent_hash: str) -> None:
        """Apply defeasible cascade via Graphiti's temporal edge invalidation.

        Replaces the manual BFS traversal over LanceDB records with
        Graphiti's native temporal invalidation mechanism.
        """
        # Find all edges related to the root hash using basic search
        results = await self.engine.graphiti.search(
            query=root_intent_hash,
            num_results=1000,
        )

        invalidated_count = 0
        now = datetime.now(tz=UTC)

        for result in results:
            # Invalidate temporal edges by setting invalid_at
            edge_uuid = getattr(result, "uuid", None)
            if edge_uuid:
                try:
                    # Edges returned by search are EntityEdge objects
                    if not getattr(result, "invalid_at", None):
                        result.invalid_at = now
                        result.expired_at = now
                        await result.save(self.engine.graphiti.driver)
                        invalidated_count += 1
                except Exception as e:
                    logger.warning(f"Edge invalidation skipped for {edge_uuid}: {e}")

        if invalidated_count > 0:
            logger.info(
                f"Defeasible Cascade via Graphiti Applied. "
                f"Invalidated {invalidated_count} temporal edges from root {root_intent_hash}."
            )

    async def commit_retracted_nodes(self, workflow_id: str, nodes: list[str]) -> None:
        """Store retracted causal arrays as Graphiti episodes."""
        from graphiti_core.nodes import EpisodeType

        if not nodes:
            return

        episode_body = json.dumps(
            {
                "retracted_node_cids": nodes,
                "workflow_id": workflow_id,
                "event_type": "retraction",
            }
        )

        await self.engine.graphiti.add_episode(
            name=f"retraction_{workflow_id}",
            episode_body=episode_body,
            source_description="CoReason Defeasible Cascade - Node Retraction Event",
            source=EpisodeType.json,
            group_id=workflow_id,
            reference_time=datetime.now(tz=UTC),
        )
        logger.info(f"Committed {len(nodes)} logic quarantines via Graphiti.")

    async def commit_cascade_event(self, workflow_id: str, event: Any) -> None:
        """Serialize cascade events as Graphiti episodes."""
        from graphiti_core.nodes import EpisodeType

        episode_body = json.dumps(
            {
                "cascade_cid": event.cascade_cid,
                "payload": event.model_dump_json(),
                "event_type": "cascade",
            }
        )

        await self.engine.graphiti.add_episode(
            name=f"cascade_{event.cascade_cid}",
            episode_body=episode_body,
            source_description="CoReason Defeasible Cascade - Cascade Propagation Event",
            source=EpisodeType.json,
            group_id=workflow_id,
            reference_time=datetime.now(tz=UTC),
        )
        logger.info(f"Committed cascade event via Graphiti: {event.cascade_cid}")

    async def execute_rollback(self, workflow_id: str, rollback_intent: Any) -> None:
        """Execute rollback by invalidating temporal edges and recording retraction."""
        invalidated = getattr(rollback_intent, "invalidated_node_cids", [])
        target_cid = getattr(rollback_intent, "target_event_cid", "")
        if not invalidated and target_cid:
            invalidated = [target_cid]

        if invalidated:
            await self.commit_retracted_nodes(workflow_id, list(invalidated))
            for cid in invalidated:
                await self.apply_defeasible_cascade(cid)

        root_cid = getattr(rollback_intent, "request_cid", f"auto_{target_cid}")

        from coreason_manifest.spec.ontology import DefeasibleCascadeEvent

        event = DefeasibleCascadeEvent(
            cascade_cid=f"cascade_{root_cid}",
            root_falsified_event_cid=root_cid,
            propagated_decay_factor=1.0,
            quarantined_event_cids=list(invalidated),
            cross_boundary_quarantine_issued=True,
        )

        await self.commit_cascade_event(workflow_id, event)
        logger.info(f"Executed RollbackIntent via Graphiti. Tainted nodes isolated: {invalidated}")

    async def fetch_epistemic_ledger_state(self, workflow_id: str) -> Any:
        """Compile full EpistemicLedgerState from Graphiti's temporal graph."""
        from coreason_manifest.spec.ontology import EpistemicLedgerState

        # We use retrieve_episodes to get all recent episodic nodes in the group.
        # This is more robust than fulltext search for structured JSON payloads in tests.
        from graphiti_core.utils.datetime_utils import utc_now

        episodes = await self.engine.graphiti.retrieve_episodes(
            reference_time=utc_now(),
            last_n=1000,
            group_ids=[workflow_id],
        )

        retracted_nodes: list[str] = []
        active_cascades: list[dict[str, Any]] = []
        history: list[dict[str, Any]] = []

        for episode in episodes:
            try:
                data = json.loads(episode.content) if isinstance(episode.content, str) else {}

                # Handle retraction and cascade events
                if data.get("event_type") == "retraction":
                    retracted_nodes.extend(data.get("retracted_node_cids", []))
                elif data.get("event_type") == "cascade":
                    # Cascade payload is also JSON stringified in commit_cascade_event
                    payload = data.get("payload")
                    if isinstance(payload, str):
                        active_cascades.append(json.loads(payload))
                    elif isinstance(payload, dict):
                        active_cascades.append(payload)

                # Handle gold-layer crystallization
                if data.get("medallion_layer") == "gold" and data.get("receipt_payload"):
                    receipt = json.loads(data["receipt_payload"])
                    history.append(receipt)
            except Exception as _err:
                logger.debug(f"Episode parse skipped: {_err}")

        logger.debug(
            f"Fetched ledger state: {len(retracted_nodes)} retractions, {len(active_cascades)} cascades, {len(history)} history items"
        )

        return EpistemicLedgerState.model_validate(
            {
                "history": history,
                "retracted_nodes": retracted_nodes,
                "active_cascades": active_cascades,
            }
        )

    async def get_community_summaries(self, workflow_id: str) -> list[dict[str, Any]]:
        """Hierarchical community detection — net-new capability from Graphiti.

        Replaces aspirational Spectral Graph Coarsening with Graphiti's
        built-in Louvain/Leiden community summarization.
        """
        try:
            from graphiti_core.search.search_config_recipes import (
                COMMUNITY_HYBRID_SEARCH_RRF,
            )

            search_results = await self.engine.graphiti.search_(
                query=f"community summary for {workflow_id}",
                config=COMMUNITY_HYBRID_SEARCH_RRF,
                group_ids=[workflow_id],
            )
            return [
                {
                    "community_id": getattr(c, "uuid", ""),
                    "summary": getattr(c, "summary", ""),
                    "name": getattr(c, "name", ""),
                }
                for c in search_results.communities
            ]
        except Exception as e:
            logger.warning(f"Community detection query failed: {e}")
            return []
