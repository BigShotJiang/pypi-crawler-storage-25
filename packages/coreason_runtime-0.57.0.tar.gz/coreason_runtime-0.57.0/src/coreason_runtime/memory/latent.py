# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""AGENT INSTRUCTION: Graphiti-backed Latent Memory Manager.

Replaces the LanceDB-backed LatentMemoryManager with Graphiti's native
hybrid retrieval (semantic + keyword + graph traversal) for vector-space
operations and episodic memory compaction.

CAUSAL AFFORDANCE: Provides vector-space memoization and stale-vector
pruning using Graphiti's temporal search filters instead of manual
exponential decay calculations.

EPISTEMIC BOUNDS: Query results are bounded by Graphiti's search config.
Pruning uses temporal validity windows instead of exponential decay.

MCP ROUTING TRIGGERS: Latent Memory, Vector Search, Hybrid Retrieval,
Episodic Compaction, Graphiti Vector Space
"""

from __future__ import annotations

import json
import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from coreason_runtime.utils.logger import logger

if TYPE_CHECKING:
    from coreason_manifest import LatentProjectionIntent

    from coreason_runtime.memory.graphiti_engine import GraphitiStateEngine


class GraphitiLatentMemoryManager:
    """Graphiti-backed Latent Memory Manager.

    AGENT INSTRUCTION: Replaces the LanceDB LatentMemoryManager by using
    Graphiti's hybrid search for vector retrieval and temporal filters
    for stale-vector pruning. Compaction is delegated to the database engine.

    CAUSAL AFFORDANCE: Provides semantic memoization via Graphiti's combined
    search instead of raw cosine similarity on 1536-dim vectors.

    EPISTEMIC BOUNDS: Search results bounded by num_results parameter.
    Pruning uses temporal validity instead of exponential decay.

    MCP ROUTING TRIGGERS: Graphiti Latent Memory, Hybrid Vector Search,
    Temporal Pruning, Episodic Compaction
    """

    def __init__(self, engine: GraphitiStateEngine) -> None:
        self.engine = engine

    async def bootstrap(self) -> None:
        """Bootstrap is handled by the shared GraphitiStateEngine."""
        logger.info("GraphitiLatentMemoryManager: Indices managed by GraphitiStateEngine.")

    async def optimize_and_compact(self) -> None:
        """Graphiti manages index optimization internally via Neo4j/FalkorDB."""
        logger.info("Graphiti backend: index optimization delegated to database engine.")

    async def upsert_projection(self, intent_hash: str, intent: LatentProjectionIntent, vector: list[float]) -> None:
        """Upsert a latent projection as a Graphiti episode.

        The raw vector is stored as episode metadata; Graphiti handles
        embedding generation independently for its own search index.
        """
        from graphiti_core.nodes import EpisodeType

        episode_body = json.dumps(
            {
                "intent_hash": intent_hash,
                "context": intent.model_dump_json(),
                "timestamp": time.time(),
                "vector_dimensions": len(vector),
                "event_type": "latent_projection",
            }
        )

        await self.engine.graphiti.add_episode(
            name=f"latent_projection_{intent_hash}",
            episode_body=episode_body,
            source_description="CoReason Latent Memory - Projection Upsert",
            source=EpisodeType.json,
            group_id=f"latent_{intent_hash}",
            reference_time=datetime.now(tz=UTC),
        )
        logger.debug(f"Latent Projection via Graphiti. Key: {intent_hash}")

    async def prune_stale_vectors(self, decay_rate: float, threshold: float, protected_cids: list[str]) -> int:
        """Prune stale latent projections using Graphiti's temporal search.

        Instead of exponential decay over LanceDB rows, queries for episodes
        older than the calculated temporal window and removes them via
        Graphiti's edge invalidation.
        """
        try:
            results = await self.engine.graphiti.search(
                query="latent_projection event_type",
                num_results=10000,
            )

            if not results:
                return 0

            import math

            now = time.time()
            pruned_count = 0

            for result in results:
                try:
                    fact_data = json.loads(result.fact) if isinstance(result.fact, str) else {}
                    intent_hash = fact_data.get("intent_hash", "")
                    timestamp = fact_data.get("timestamp", now)
                    age = now - timestamp

                    if intent_hash in protected_cids:
                        continue

                    # Apply the same exponential decay formula as legacy
                    utility = math.e ** (-decay_rate * age)
                    if utility < threshold and not getattr(result, "invalid_at", None):
                        try:
                            result.expired_at = datetime.now(tz=UTC)
                            await result.save(self.engine.graphiti.driver)
                            pruned_count += 1
                        except Exception as _edge_err:
                            logger.debug(f"Edge prune skipped: {_edge_err}")

                except Exception as _parse_err:
                    logger.debug(f"Projection parse skipped: {_parse_err}")
                    continue

            if pruned_count > 0:
                logger.info(f"Epistemic Pruning via Graphiti: Expired {pruned_count} stale projections.")

            return pruned_count

        except Exception as e:
            logger.warning(f"Epistemic pruning via Graphiti failed: {e}")
            return 0
