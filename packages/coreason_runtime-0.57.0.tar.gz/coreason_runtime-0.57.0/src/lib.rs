// Copyright (c) 2026 CoReason, Inc
//
// This software is proprietary and dual-licensed
// Licensed under the Prosperity Public License 3.0 (the "License")
// A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
// For details, see the LICENSE file
// Commercial use beyond a 30-day trial requires a separate license
//
// Source Code: <https://github.com/CoReason-AI/coreason-runtime>

#[cfg(feature = "pyo3")]
use pyo3::prelude::*;

#[cfg(feature = "pyo3")]
#[pyfunction]
pub fn verify_module_integrity(source_code: &str, expected_sha256: &str) -> PyResult<bool> {
    use sha2::{Digest, Sha256};
    let normalized = source_code.replace("\r\n", "\n");
    let mut hasher = Sha256::new();
    hasher.update(normalized.as_bytes());
    let actual_hash = format!("{:x}", hasher.finalize());
    Ok(actual_hash == expected_sha256)
}

#[cfg(feature = "pyo3")]
#[pymodule]
fn coreason_runtime_rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(verify_module_integrity, m)?)?;
    Ok(())
}
