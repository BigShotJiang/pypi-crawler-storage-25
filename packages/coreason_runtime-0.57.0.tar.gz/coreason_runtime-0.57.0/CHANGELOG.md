# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Enterprise-grade SECURITY.md vulnerability disclosure policy
- PyPI keywords for package discoverability
- Gitleaks managed action with organization license key
- Advanced security workflow (ClamAV malware scan + copyleft license firewall)

*Copyright (c) 2026 CoReason, Inc. Licensed under the Prosperity Public License 3.0.*
