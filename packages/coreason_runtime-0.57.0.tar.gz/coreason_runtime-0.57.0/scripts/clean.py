#!/usr/bin/env python3
# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import logging
import shutil
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)


def clean_environment() -> None:
    root = Path(__file__).parent.parent

    # Directories to wipe completely
    cache_dirs = [
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".uv_cache",
        "__pycache__",
    ]

    for d in cache_dirs:
        for path in root.rglob(d):
            if path.is_dir():
                try:
                    shutil.rmtree(path)
                    logger.info(f"Removed cache directory: {path.relative_to(root)}")
                except Exception as e:
                    logger.warning(f"Failed to remove {path}: {e}")

    # File patterns to remove
    log_patterns = ["logs/*.log", "logs/*.zip", "cov_final.txt", "*_output.txt"]
    for pattern in log_patterns:
        # Match globally or in specific directory
        paths = root.glob(pattern) if "/" in pattern else root.rglob(pattern)

        for path in paths:
            if path.is_file():
                try:
                    path.unlink()
                    logger.info(f"Removed file: {path.relative_to(root)}")
                except Exception as e:
                    logger.warning(f"Failed to remove {path}: {e}")

    logger.info("Environment cleanup completed successfully.")


if __name__ == "__main__":
    clean_environment()
