# detect_capabilities.ps1
# Detects NVIDIA GPU presence and configures .env for Docker Compose capabilities.

$gpuDetected = $false

# 1. Check if nvidia-smi command works
try {
    $null = Get-Command nvidia-smi -ErrorAction SilentlyContinue
    if ($LASTEXITCODE -eq 0 -or $?) {
        $gpuDetected = $true
    }
} catch {}

# 2. Check using CIM/WMI if nvidia-smi is not in PATH
if (-not $gpuDetected) {
    try {
        $gpus = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue
        foreach ($gpu in $gpus) {
            if ($gpu.Name -like "*NVIDIA*") {
                $gpuDetected = $true
                break
            }
        }
    } catch {}
}

Write-Host "--- CoReason Hardware Capability Detection ---"
if ($gpuDetected) {
    Write-Host "[INFO] NVIDIA GPU detected. Configuring environment for GPU acceleration." -ForegroundColor Green
    $profiles = "gpu"
    $extras = "inference"
    $sglangUrl = "http://sglang:30000"
} else {
    Write-Host "[INFO] No NVIDIA GPU detected. Configuring environment for CPU-only execution." -ForegroundColor Yellow
    $profiles = ""
    $extras = ""
    $sglangUrl = ""
}

# Define env paths
$envExamplePath = Resolve-Path (Join-Path $PSScriptRoot "..\.env.example") -ErrorAction SilentlyContinue
if (-not $envExamplePath) {
    $envExamplePath = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\.env.example"))
}
$envPath = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\.env"))

# Load base contents
if (Test-Path $envPath) {
    Write-Host "[INFO] Updating existing .env file."
    $content = Get-Content $envPath
} elseif (Test-Path $envExamplePath) {
    Write-Host "[INFO] Creating .env file from .env.example."
    $content = Get-Content $envExamplePath
} else {
    Write-Error "[ERROR] Neither .env nor .env.example found!"
    exit 1
}

# Update or insert lines in Content
$newContent = @()
$keysToSet = @{
    "COMPOSE_PROFILES" = $profiles
    "EXTRAS" = $extras
    "SGLANG_URL" = $sglangUrl
}

$processedKeys = @{}

foreach ($line in $content) {
    $matched = $false
    foreach ($key in $keysToSet.Keys) {
        if ($line -match "^$key\s*=") {
            $newContent += "$key=$($keysToSet[$key])"
            $processedKeys[$key] = $true
            $matched = $true
            break
        }
    }
    if (-not $matched) {
        $newContent += $line
    }
}

# Add any keys that were not found in the original file
foreach ($key in $keysToSet.Keys) {
    if (-not $processedKeys.ContainsKey($key)) {
        $newContent += "$key=$($keysToSet[$key])"
    }
}

# Write back to .env
$newContent | Set-Content $envPath
Write-Host "[SUCCESS] Updated .env file at $envPath successfully." -ForegroundColor Green
