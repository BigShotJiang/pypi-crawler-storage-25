import argparse
import urllib.parse
import webbrowser
from datetime import date

from prompt_toolkit import prompt

from redi.cli.alias import resolve_alias
from redi.cli.editor import open_editor
from redi.cli.keybinding import (
    date_key_bindings,
    digit_and_period_key_bindings,
    digit_only_key_bindings,
)
from redi.cli.picker import inline_checkbox, inline_choice
from redi.cli.confirm import confirm_delete
from redi.cli.validator import (
    DateValidator,
    DueDateValidator,
    FloatValidator,
    HourValidator,
    IntValidator,
    RequiredValidator,
)
from redi.config import default_project_id, redmine_url
from redi.api.enumeration import fetch_issue_priorities, fetch_time_entry_activities
from redi.api.issue import (
    add_note,
    add_watcher,
    create_issue,
    delete_issue,
    fetch_issue,
    fetch_issues,
    list_issues,
    parse_custom_fields,
    read_issue,
    remove_watcher,
    update_issue,
)
from redi.api.issue_relation import create_relation, delete_relation
from redi.api.issue_status import fetch_issue_statuses
from redi.api.membership import fetch_project_users
from redi.api.project import fetch_project
from redi.api.time_entry import create_time_entry
from redi.api.version import fetch_versions
from redi.i18n import messages

from redi.api.custom_field import (
    CustomField,
    fetch_custom_fields,
    fetch_project_issue_custom_field_ids,
    filter_optional_issue_custom_fields,
    filter_required_issue_custom_fields,
)


def add_issue_parser(
    subparsers: argparse._SubParsersAction, parents: list[argparse.ArgumentParser]
) -> None:
    i_parser = subparsers.add_parser(
        "issue",
        aliases=["i"],
        help=messages.arg_help_issue_command,
        parents=parents,
    )
    i_parser.add_argument(
        "--full", action="store_true", help=messages.arg_help_full_json
    )
    i_parser.add_argument(
        "--project_id", "-p", help=messages.arg_help_issue_filter_project
    )
    i_parser.add_argument(
        "--version",
        "-v",
        help=messages.arg_help_issue_filter_version,
    )
    i_parser.add_argument(
        "--assigned_to",
        "-a",
        help=messages.arg_help_issue_filter_assigned_to,
    )
    i_parser.add_argument(
        "--status_id",
        "-s",
        help=messages.arg_help_issue_filter_status,
    )
    i_parser.add_argument(
        "--tracker_id", "-t", help=messages.arg_help_issue_filter_tracker
    )
    i_parser.add_argument("--priority_id", help=messages.arg_help_issue_filter_priority)
    i_parser.add_argument(
        "--query_id",
        "-q",
        help=messages.arg_help_issue_filter_query,
    )
    i_parser.add_argument("--limit", "-l", type=int, help=messages.arg_help_limit)
    i_parser.add_argument("--offset", "-o", type=int, help=messages.arg_help_offset)
    i_subparsers = i_parser.add_subparsers(dest="issue_command")
    i_subparsers.add_parser(
        "list", aliases=["l"], help=messages.arg_help_issue_list, parents=parents
    )
    i_view_parser = i_subparsers.add_parser(
        "view", aliases=["v"], help=messages.arg_help_issue_view, parents=parents
    )
    i_view_parser.add_argument("issue_id", help=messages.arg_help_issue_view_id)
    i_view_parser.add_argument(
        "--include",
        help=messages.arg_help_issue_include,
    )
    i_view_parser.add_argument(
        "--full", action="store_true", help=messages.arg_help_full_json
    )
    i_view_parser.add_argument(
        "--web", "-w", action="store_true", help=messages.arg_help_open_web
    )
    i_create_parser = i_subparsers.add_parser(
        "create", aliases=["c"], help=messages.arg_help_issue_create, parents=parents
    )
    i_create_parser.add_argument(
        "subject", nargs="?", help=messages.arg_help_issue_subject_arg
    )
    i_create_parser.add_argument(
        "--project_id", "-p", help=messages.arg_help_project_id
    )
    i_create_parser.add_argument(
        "--tracker_id", "-t", help=messages.arg_help_issue_tracker_id
    )
    i_create_parser.add_argument(
        "--priority_id", help=messages.arg_help_issue_priority_id
    )
    i_create_parser.add_argument(
        "--assigned_to_id", "-a", help=messages.arg_help_issue_assigned_to_id
    )
    i_create_parser.add_argument(
        "--fixed_version_id", help=messages.arg_help_issue_fixed_version_id
    )
    i_create_parser.add_argument(
        "--parent_issue_id", help=messages.arg_help_issue_parent
    )
    i_create_parser.add_argument(
        "--start_date", help=messages.arg_help_issue_start_date
    )
    i_create_parser.add_argument("--due_date", help=messages.arg_help_issue_due_date)
    i_create_parser.add_argument(
        "--estimated_hours", type=float, help=messages.arg_help_issue_estimated_hours
    )
    i_create_parser.add_argument(
        "--description",
        "-d",
        nargs="?",
        const="",
        default=None,
        help=messages.arg_help_issue_description,
    )
    i_create_parser.add_argument(
        "--custom_fields",
        help=messages.arg_help_custom_fields,
    )
    i_update_parser = i_subparsers.add_parser(
        "update", aliases=["u"], help=messages.arg_help_issue_update, parents=parents
    )
    i_update_parser.add_argument(
        "issue_id", nargs="?", help=messages.arg_help_issue_update_id
    )
    i_update_parser.add_argument(
        "--subject", "-s", help=messages.arg_help_issue_subject_opt
    )
    i_update_parser.add_argument(
        "--description",
        "-d",
        nargs="?",
        const="",
        default=None,
        help=messages.arg_help_issue_update_description,
    )
    i_update_parser.add_argument(
        "--tracker_id", "-t", help=messages.arg_help_issue_update_tracker_id
    )
    i_update_parser.add_argument("--status_id", help=messages.arg_help_issue_status_id)
    i_update_parser.add_argument(
        "--priority_id", help=messages.arg_help_issue_priority_id
    )
    i_update_parser.add_argument(
        "--assigned_to_id", "-a", help=messages.arg_help_issue_assigned_to_id
    )
    i_update_parser.add_argument(
        "--fixed_version_id", help=messages.arg_help_issue_fixed_version_id
    )
    i_update_parser.add_argument(
        "--parent_issue_id", help=messages.arg_help_issue_parent
    )
    i_update_parser.add_argument(
        "--start_date", help=messages.arg_help_issue_start_date
    )
    i_update_parser.add_argument("--due_date", help=messages.arg_help_issue_due_date)
    i_update_parser.add_argument(
        "--done_ratio", type=int, help=messages.arg_help_issue_done_ratio
    )
    i_update_parser.add_argument(
        "--estimated_hours", type=float, help=messages.arg_help_issue_estimated_hours
    )
    i_update_parser.add_argument("--notes", "-n", help=messages.arg_help_issue_notes)
    i_update_parser.add_argument(
        "--custom_fields",
        help=messages.arg_help_custom_fields,
    )
    i_update_parser.add_argument(
        "--relate",
        help=messages.arg_help_issue_relate,
    )
    i_update_parser.add_argument(
        "--to", dest="relate_to", help=messages.arg_help_issue_relate_to
    )
    i_update_parser.add_argument(
        "--delete-relation",
        action="store_true",
        help=messages.arg_help_issue_delete_relation,
    )
    i_update_parser.add_argument(
        "--attach",
        action="append",
        help=messages.arg_help_issue_attach,
    )
    i_update_parser.add_argument(
        "--hours", type=float, help=messages.arg_help_issue_hours
    )
    i_update_parser.add_argument(
        "--activity_id", help=messages.arg_help_issue_activity_id
    )
    i_update_parser.add_argument("--spent_on", help=messages.arg_help_issue_spent_on)
    i_update_parser.add_argument(
        "--time_comments", help=messages.arg_help_issue_time_comments
    )
    i_update_parser.add_argument(
        "--add-watcher",
        type=int,
        action="append",
        dest="add_watcher_ids",
        help=messages.arg_help_issue_add_watcher,
    )
    i_update_parser.add_argument(
        "--remove-watcher",
        type=int,
        action="append",
        dest="remove_watcher_ids",
        help=messages.arg_help_issue_remove_watcher,
    )
    i_comment_parser = i_subparsers.add_parser(
        "comment", aliases=["co"], help=messages.arg_help_issue_comment, parents=parents
    )
    i_comment_parser.add_argument("issue_id", help=messages.arg_help_issue_view_id)
    i_comment_parser.add_argument(
        "notes", nargs="?", default="", help=messages.arg_help_issue_comment_notes
    )
    i_delete_parser = i_subparsers.add_parser(
        "delete", aliases=["d"], help=messages.arg_help_issue_delete, parents=parents
    )
    i_delete_parser.add_argument("issue_id", help=messages.arg_help_issue_view_id)
    i_delete_parser.add_argument(
        "-y", "--yes", action="store_true", help=messages.arg_help_skip_confirm
    )


def _build_create_issue_url(
    project_id: str,
    subject: str = "",
    description: str = "",
    tracker_id: str | None = None,
    priority_id: str | None = None,
    assigned_to_id: str | None = None,
    fixed_version_id: str | None = None,
    parent_issue_id: str | None = None,
    start_date: str | None = None,
    due_date: str | None = None,
    estimated_hours: float | None = None,
    custom_fields: str | None = None,
) -> str:
    params: list[tuple[str, str]] = []
    if subject:
        params.append(("issue[subject]", subject))
    if description:
        params.append(("issue[description]", description))
    if tracker_id:
        params.append(("issue[tracker_id]", tracker_id))
    if priority_id:
        params.append(("issue[priority_id]", priority_id))
    if assigned_to_id:
        params.append(("issue[assigned_to_id]", assigned_to_id))
    if fixed_version_id:
        params.append(("issue[fixed_version_id]", fixed_version_id))
    if parent_issue_id:
        params.append(("issue[parent_issue_id]", parent_issue_id))
    if start_date:
        params.append(("issue[start_date]", start_date))
    if due_date:
        params.append(("issue[due_date]", due_date))
    if estimated_hours is not None:
        params.append(("issue[estimated_hours]", str(estimated_hours)))
    if custom_fields:
        for cf in parse_custom_fields(custom_fields):
            value = cf["value"]
            if isinstance(value, list):
                for v in value:
                    params.append((f"issue[custom_field_values][{cf['id']}][]", str(v)))
            else:
                params.append((f"issue[custom_field_values][{cf['id']}]", str(value)))
    base = f"{redmine_url}/projects/{project_id}/issues/new"
    if not params:
        return base
    return f"{base}?{urllib.parse.urlencode(params)}"


def _interactive_select_issue_id() -> str:
    issues = fetch_issues(project_id=default_project_id)
    if not issues:
        print(messages.no_issues_available)
        exit(1)
    options: list[tuple[str, str]] = [
        (str(i["id"]), f"#{i['id']} {i['subject']}") for i in issues
    ]
    labels = dict(options)
    try:
        issue_id = inline_choice(messages.prompt_select_issue_to_update, options)
    except KeyboardInterrupt:
        print(messages.canceled)
        exit(1)
    print(messages.update_target_issue.format(label=labels[issue_id]))
    return issue_id


def _interactive_fill_issue_update_args(args: argparse.Namespace) -> None:
    current = fetch_issue(args.issue_id)
    field_values: list[tuple[str, str]] = [
        ("tracker", messages.field_tracker),
        ("subject", messages.field_subject),
        ("description", messages.field_description),
        ("status", messages.field_status),
        ("priority", messages.field_priority),
        ("assigned_to", messages.field_assignee),
        ("fixed_version", messages.field_fixed_version),
        ("start_date", messages.field_start_date),
        ("due_date", messages.field_due_date),
        ("done_ratio", messages.field_done_ratio),
        ("estimated_hours", messages.field_estimated_hours),
        ("notes", messages.field_notes),
        ("time_entry", messages.field_time_entry),
    ]
    try:
        selected = inline_checkbox(
            messages.prompt_select_update_items,
            field_values,
            initial_value="description",
        )
    except KeyboardInterrupt:
        print(messages.canceled)
        exit(1)
    if not selected:
        print(messages.canceled_no_items_selected)
        exit(1)
    labels = dict(field_values)
    print(messages.update_items.format(items=", ".join(labels[v] for v in selected)))
    try:
        if "tracker" in selected:
            project_id = (current.get("project") or {}).get("id")
            if not project_id:
                print(messages.canceled_no_project)
                exit(1)
            project = fetch_project(str(project_id), include="trackers")
            trackers = project.get("trackers") or []
            tracker_options: list[tuple[str, str]] = [
                (str(t["id"]), t["name"]) for t in trackers
            ]
            tracker_labels = dict(tracker_options)
            args.tracker_id = inline_choice(
                messages.prompt_select_tracker, tracker_options
            )
            print(messages.tracker_label.format(value=tracker_labels[args.tracker_id]))
        if "subject" in selected:
            args.subject = prompt(
                messages.prompt_subject, default=current.get("subject") or ""
            ).strip()
        if "description" in selected:
            args.description = ""
        if "status" in selected:
            statuses = fetch_issue_statuses()
            status_options: list[tuple[str, str]] = [
                (str(s["id"]), s["name"]) for s in statuses
            ]
            status_labels = dict(status_options)
            args.status_id = inline_choice(
                messages.prompt_select_status, status_options
            )
            print(messages.status_label.format(value=status_labels[args.status_id]))
        if "priority" in selected:
            priorities = fetch_issue_priorities()
            priority_options: list[tuple[str, str]] = [
                (str(p["id"]), p["name"]) for p in priorities
            ]
            priority_labels = dict(priority_options)
            args.priority_id = inline_choice(
                messages.prompt_select_priority, priority_options
            )
            print(
                messages.priority_label.format(value=priority_labels[args.priority_id])
            )
        if "assigned_to" in selected:
            project_id = (current.get("project") or {}).get("id")
            if not project_id:
                print(messages.canceled_no_project)
                exit(1)
            users = fetch_project_users(str(project_id))
            assignee_options: list[tuple[str, str]] = [
                ("", messages.prompt_select_assignee_none)
            ] + [(str(u["id"]), u["name"]) for u in users]
            assignee_labels = dict(assignee_options)
            current_assignee_id = (current.get("assigned_to") or {}).get("id")
            default_assignee = (
                str(current_assignee_id) if current_assignee_id is not None else ""
            )
            args.assigned_to_id = inline_choice(
                messages.prompt_select_assignee,
                assignee_options,
                default=default_assignee,
            )
            print(
                messages.assignee_label.format(
                    value=assignee_labels[args.assigned_to_id]
                )
            )
        if "fixed_version" in selected:
            project_id = (current.get("project") or {}).get("id")
            if not project_id:
                print(messages.canceled_no_project)
                exit(1)
            versions = fetch_versions(str(project_id))
            version_options: list[tuple[str, str]] = [
                (str(v["id"]), f"{v['name']} ({v['status']})") for v in versions
            ]
            version_labels = dict(version_options)
            args.fixed_version_id = inline_choice(
                messages.prompt_select_fixed_version, version_options
            )
            print(
                messages.fixed_version_label.format(
                    value=version_labels[args.fixed_version_id]
                )
            )
        if "start_date" in selected:
            args.start_date = prompt(
                messages.prompt_start_date,
                default=current.get("start_date") or date.today().isoformat(),
                validator=DateValidator(allow_empty=True),
            ).strip()
        if "due_date" in selected:
            effective_start = (
                args.start_date
                if "start_date" in selected
                else current.get("start_date")
            )
            start_date: date | None = None
            if effective_start:
                try:
                    start_date = date.fromisoformat(effective_start)
                except ValueError:
                    start_date = None
            args.due_date = prompt(
                messages.prompt_due_date,
                default=current.get("due_date") or date.today().isoformat(),
                validator=DueDateValidator(start_date),
            ).strip()
        if "done_ratio" in selected:
            ratio_options: list[tuple[str, str]] = [
                (str(r), f"{r}%") for r in range(0, 101, 10)
            ]
            current_ratio = current.get("done_ratio")
            default_ratio = str(current_ratio) if current_ratio is not None else None
            args.done_ratio = int(
                inline_choice(
                    messages.prompt_select_done_ratio,
                    ratio_options,
                    default=default_ratio,
                )
            )
            print(messages.done_ratio_label.format(value=args.done_ratio))
        if "estimated_hours" in selected:
            current_estimated = current.get("estimated_hours")
            default_estimated = (
                str(current_estimated) if current_estimated is not None else ""
            )
            args.estimated_hours = float(
                prompt(
                    messages.prompt_estimated_hours,
                    default=default_estimated,
                    validator=HourValidator(),
                ).strip()
            )
            print(messages.estimated_hours_label.format(value=args.estimated_hours))
        if "notes" in selected:
            args.notes = prompt(messages.prompt_comment).strip()
        if "time_entry" in selected:
            hours_str = prompt(messages.prompt_hours, validator=HourValidator()).strip()
            if hours_str:
                args.hours = float(hours_str)
            activities = fetch_time_entry_activities()
            activity_options: list[tuple[str, str]] = [
                (str(a["id"]), a["name"]) for a in activities
            ]
            activity_labels = dict(activity_options)
            args.activity_id = inline_choice(
                messages.prompt_select_activity, activity_options
            )
            print(
                messages.activity_label.format(value=activity_labels[args.activity_id])
            )
            args.spent_on = (
                prompt(
                    messages.prompt_spent_on,
                    validator=DateValidator(allow_empty=True),
                    key_bindings=date_key_bindings(),
                ).strip()
                or None
            )
            args.time_comments = prompt(messages.prompt_time_comments).strip() or None
    except (KeyboardInterrupt, EOFError):
        print(messages.canceled)
        exit(1)


# attachment 型のような未対応フィールドで「スキップしてブラウザでの編集に倒す」ことを示すセンチネル
_SKIP_UNSUPPORTED_FIELD = object()


def _shorten_to_oneline(text: str, max_len: int = 80) -> str:
    """改行をスペースに畳んで 1 行化し、長すぎたら省略する。"""
    one_line = " ".join(text.splitlines())
    if len(one_line) > max_len:
        return one_line[: max_len - 1] + "…"
    return one_line


def _choose_from_options(
    name: str,
    label: str,
    options: list[tuple[str, str]],
    multiple: bool,
    default_value: str,
) -> str | list[str] | object:
    """選択肢からの入力を取得する共通処理。空オプションは _SKIP_UNSUPPORTED_FIELD を返す。"""
    if not options:
        return _SKIP_UNSUPPORTED_FIELD
    label_map = dict(options)
    if multiple:
        # 空選択は受け付けず、最低 1 つチェックされるまで再表示する
        while True:
            checked = inline_checkbox(
                label,
                options,
                initial_checked=[default_value] if default_value else None,
            )
            if checked:
                break
        display = ", ".join(label_map[k] for k in checked)
        print(messages.prompt_field_value.format(name=name, value=display))
        return checked
    key = inline_choice(label, options, default=default_value or None)
    print(messages.prompt_field_value.format(name=name, value=label_map[key]))
    return key


def _prompt_custom_field_value(
    custom_field: CustomField,
    project_id: str,
) -> str | list[str] | object:
    name = custom_field["name"]
    field_format = custom_field["field_format"]
    multiple = custom_field["multiple"]
    label = messages.prompt_required_field.format(name=name)
    default_value = custom_field.get("default_value") or ""

    match field_format:
        # キーバリューリスト
        case "enumeration":
            possible_values = custom_field.get("possible_values") or []
            options: list[tuple[str, str]] = [
                (str(pv.get("value", "")), str(pv.get("label", "")))
                for pv in possible_values
                if pv.get("value", "") != ""
            ]
            return _choose_from_options(name, label, options, multiple, default_value)

        # リスト
        case "list":
            possible = custom_field.get("possible_values") or []
            options = [
                (str(pv.get("value", "")), str(pv.get("value", "")))
                for pv in possible
                if pv.get("value", "") != ""
            ]
            return _choose_from_options(name, label, options, multiple, default_value)

        # ユーザー
        case "user":
            users = fetch_project_users(project_id)
            options = [(str(u["id"]), u.get("name", "")) for u in users]
            return _choose_from_options(name, label, options, multiple, default_value)

        # バージョン
        case "version":
            versions = fetch_versions(project_id)
            options = [(str(v["id"]), v["name"]) for v in versions]
            return _choose_from_options(name, label, options, multiple, default_value)

        # 真偽値
        case "bool":
            bool_options: list[tuple[str, str]] = [
                ("1", messages.label_bool_true),
                ("0", messages.label_bool_false),
            ]
            bool_label_map = dict(bool_options)
            key = inline_choice(label, bool_options, default=default_value or None)
            print(
                messages.prompt_field_value.format(name=name, value=bool_label_map[key])
            )
            return key

        # 長いテキスト
        case "text":
            # 空のまま閉じられたらエディタを開き直す
            while True:
                value = open_editor(initial_text=default_value)
                if value:
                    print(
                        messages.prompt_field_value.format(
                            name=name, value=_shorten_to_oneline(value)
                        )
                    )
                    return value

        # 日付
        case "date":
            return prompt(
                messages.prompt_custom_field_label.format(name=label),
                validator=DateValidator(),
                default=default_value,
            ).strip()

        # 進捗 (0-100% の 10% 刻み)
        case "progressbar":
            progress_options: list[tuple[str, str]] = [
                (str(r), f"{r}%") for r in range(0, 101, 10)
            ]
            value = inline_choice(label, progress_options)
            print(messages.prompt_field_value.format(name=name, value=f"{value}%"))
            return value

        # 整数
        case "int":
            return prompt(
                messages.prompt_custom_field_label.format(name=label),
                validator=IntValidator(),
                default=default_value,
            ).strip()

        # 小数
        case "float":
            return prompt(
                messages.prompt_custom_field_label.format(name=label),
                validator=FloatValidator(),
                default=default_value,
            ).strip()

        # ファイル添付は redi 側で対応していないため、呼び出し側に「ブラウザで編集」を強制させる
        case "attachment":
            print(messages.attachment_field_unsupported_notice.format(name=name))
            return _SKIP_UNSUPPORTED_FIELD

        # 自由入力(string,link)。未知のフォーマット
        case _:
            return prompt(
                messages.prompt_custom_field_label.format(name=label),
                validator=RequiredValidator(),
                default=default_value,
            ).strip()


def _interactive_fill_required_custom_fields(
    project_id: str, tracker_id: str | None, existing: str | None
) -> tuple[str | None, bool]:
    """戻り値の bool は「未対応の必須フィールドが含まれていた = ブラウザ編集が必須」を示す。"""
    custom_fields = fetch_custom_fields()
    if custom_fields is None:
        # 非管理者はあらかじめ渡されているパラメータを使うしかない
        return existing, False
    project_cf_ids = fetch_project_issue_custom_field_ids(project_id)
    required = filter_required_issue_custom_fields(
        custom_fields, project_cf_ids, tracker_id
    )
    if not required:
        return existing, False

    existing_ids: set[int] = set()
    if existing:
        for pair in existing.split(","):
            key = pair.split("=")[0]
            existing_ids.add(int(key))

    added: list[str] = []
    browser_only = False
    for cf in required:
        if cf["id"] in existing_ids:
            continue
        try:
            value = _prompt_custom_field_value(cf, project_id)
        except (KeyboardInterrupt, EOFError):
            print(messages.canceled)
            exit(1)
        if value is _SKIP_UNSUPPORTED_FIELD:
            browser_only = True
            continue
        if isinstance(value, list):
            for v in value:
                added.append(f"{cf['id']}={v}")
        else:
            added.append(f"{cf['id']}={value}")
    if not added:
        return existing, browser_only
    if existing:
        return existing + "," + ",".join(added), browser_only
    return ",".join(added), browser_only


def _interactive_fill_optional_create_fields(
    args: argparse.Namespace,
    project_id: str,
    tracker_id: str | None,
    custom_fields: str | None,
) -> str | None:
    """アクションメニューから「任意項目を入力する」を選んだときの入力フロー。

    標準項目（担当者・対象バージョン・親チケット・開始日・期日・予定工数）に加えて
    任意のカスタムフィールドも選択肢に並べる。入力された CF 値を含めた更新後の
    custom_fields 文字列を返す。
    """
    field_options: list[tuple[str, str]] = [
        ("assigned_to", messages.field_assignee),
        ("fixed_version", messages.field_fixed_version),
        ("parent_issue", messages.field_parent_issue),
        ("start_date", messages.field_start_date),
        ("due_date", messages.field_due_date),
        ("estimated_hours", messages.field_estimated_hours),
    ]
    optional_cfs: list[CustomField] = []
    all_cfs = fetch_custom_fields()
    if all_cfs is not None:
        existing_ids: set[int] = set()
        if custom_fields:
            for pair in custom_fields.split(","):
                existing_ids.add(int(pair.split("=")[0]))
        project_cf_ids = fetch_project_issue_custom_field_ids(project_id)
        optional_cfs = [
            cf
            for cf in filter_optional_issue_custom_fields(
                all_cfs, project_cf_ids, tracker_id
            )
            if cf["id"] not in existing_ids
        ]
        for cf in optional_cfs:
            field_options.append((f"cf_{cf['id']}", cf["name"]))
    try:
        selected = inline_checkbox(
            messages.prompt_select_create_optional_items,
            field_options,
        )
    except KeyboardInterrupt:
        print(messages.canceled)
        exit(1)
    if not selected:
        return custom_fields
    added_cfs: list[str] = []
    try:
        if "assigned_to" in selected:
            users = fetch_project_users(project_id)
            assignee_options: list[tuple[str, str]] = [
                ("", messages.prompt_select_assignee_none)
            ] + [(str(u["id"]), u.get("name", "")) for u in users]
            assignee_labels = dict(assignee_options)
            args.assigned_to_id = inline_choice(
                messages.prompt_select_assignee, assignee_options
            )
            print(
                messages.assignee_label.format(
                    value=assignee_labels[args.assigned_to_id]
                )
            )
        if "fixed_version" in selected:
            versions = fetch_versions(project_id)
            version_options: list[tuple[str, str]] = [
                ("", messages.prompt_select_fixed_version_none)
            ] + [(str(v["id"]), f"{v['name']} ({v['status']})") for v in versions]
            version_labels = dict(version_options)
            args.fixed_version_id = inline_choice(
                messages.prompt_select_fixed_version, version_options
            )
            print(
                messages.fixed_version_label.format(
                    value=version_labels[args.fixed_version_id]
                )
            )
        if "parent_issue" in selected:
            value = prompt(
                messages.prompt_parent_issue_id,
                validator=IntValidator(allow_empty=True),
                key_bindings=digit_only_key_bindings(),
            ).strip()
            args.parent_issue_id = value or None
        if "start_date" in selected:
            value = prompt(
                messages.prompt_start_date,
                default=date.today().isoformat(),
                validator=DateValidator(allow_empty=True),
                key_bindings=date_key_bindings(),
            ).strip()
            args.start_date = value or None
        if "due_date" in selected:
            start_date_obj: date | None = None
            if args.start_date:
                try:
                    start_date_obj = date.fromisoformat(args.start_date)
                except ValueError:
                    start_date_obj = None
            value = prompt(
                messages.prompt_due_date,
                validator=DueDateValidator(start_date_obj),
                key_bindings=date_key_bindings(),
            ).strip()
            args.due_date = value or None
        if "estimated_hours" in selected:
            value = prompt(
                messages.prompt_estimated_hours,
                validator=HourValidator(allow_empty=True),
                key_bindings=digit_and_period_key_bindings(),
            ).strip()
            if value:
                args.estimated_hours = float(value)
        for cf in optional_cfs:
            if f"cf_{cf['id']}" not in selected:
                continue
            cf_value = _prompt_custom_field_value(cf, project_id)
            if cf_value is _SKIP_UNSUPPORTED_FIELD:
                continue
            if isinstance(cf_value, list):
                for v in cf_value:
                    added_cfs.append(f"{cf['id']}={v}")
            else:
                added_cfs.append(f"{cf['id']}={cf_value}")
    except (KeyboardInterrupt, EOFError):
        print(messages.canceled)
        exit(1)
    if not added_cfs:
        return custom_fields
    if custom_fields:
        return custom_fields + "," + ",".join(added_cfs)
    return ",".join(added_cfs)


def handle_issue_create(args: argparse.Namespace) -> None:
    project_id = args.project_id or default_project_id
    if not project_id:
        print(messages.project_id_required)
        exit(1)
    subject = args.subject
    tracker_id = args.tracker_id
    custom_fields = args.custom_fields
    interactive = subject is None or args.description is None
    browser_only = False
    if subject is None:
        if tracker_id is None:
            project = fetch_project(project_id, include="trackers")
            trackers = project.get("trackers") or []
            tracker_options: list[tuple[str, str]] = [
                (str(t["id"]), t["name"]) for t in trackers
            ]
            labels = dict(tracker_options)
            try:
                tracker_id = inline_choice(
                    messages.prompt_select_tracker, tracker_options
                )
            except KeyboardInterrupt:
                print(messages.canceled)
                exit(1)
            print(messages.tracker_label.format(value=labels[tracker_id]))
        try:
            subject = prompt(messages.prompt_subject).strip()
        except (KeyboardInterrupt, EOFError):
            print(messages.canceled)
            exit(1)
        if not subject:
            print(messages.canceled_empty_subject)
            exit(1)
        # 必要なカスタムフィールドを対話的に入力
        custom_fields, browser_only = _interactive_fill_required_custom_fields(
            project_id=project_id,
            tracker_id=tracker_id,
            existing=args.custom_fields,
        )
    if args.description is None:
        description = open_editor()
        if description:
            print(
                messages.prompt_field_value.format(
                    name=messages.field_description,
                    value=_shorten_to_oneline(description),
                )
            )
    else:
        description = args.description
    if interactive:
        # 添付ファイル必須など redi で送信できないケースは「ブラウザで編集」のみ提示する
        while True:
            action_options: list[tuple[str, str]] = (
                [
                    ("browser", messages.action_continue_in_browser),
                    ("optional", messages.action_fill_optional),
                ]
                if browser_only
                else [
                    ("submit", messages.action_submit),
                    ("browser", messages.action_continue_in_browser),
                    ("optional", messages.action_fill_optional),
                ]
            )
            try:
                action = inline_choice(messages.prompt_what_next, action_options)
            except KeyboardInterrupt:
                print(messages.canceled)
                exit(1)
            if action == "optional":
                custom_fields = _interactive_fill_optional_create_fields(
                    args, project_id, tracker_id, custom_fields
                )
                continue
            if action == "browser":
                url = _build_create_issue_url(
                    project_id=project_id,
                    subject=subject,
                    description=description,
                    tracker_id=tracker_id,
                    priority_id=args.priority_id,
                    assigned_to_id=args.assigned_to_id,
                    fixed_version_id=args.fixed_version_id,
                    parent_issue_id=args.parent_issue_id,
                    start_date=args.start_date,
                    due_date=args.due_date,
                    estimated_hours=args.estimated_hours,
                    custom_fields=custom_fields,
                )
                webbrowser.open(url)
                return
            break
    create_issue(
        project_id=project_id,
        subject=subject,
        description=description,
        tracker_id=tracker_id,
        priority_id=args.priority_id,
        assigned_to_id=args.assigned_to_id,
        fixed_version_id=args.fixed_version_id,
        parent_issue_id=args.parent_issue_id,
        start_date=args.start_date,
        due_date=args.due_date,
        estimated_hours=args.estimated_hours,
        custom_fields=custom_fields,
    )


def handle_issue_update(args: argparse.Namespace) -> None:
    if not args.issue_id:
        args.issue_id = _interactive_select_issue_id()
    no_args_provided = not (
        args.subject
        or args.description is not None
        or args.tracker_id
        or args.status_id
        or args.priority_id
        or args.assigned_to_id is not None
        or args.fixed_version_id
        or args.parent_issue_id is not None
        or args.start_date is not None
        or args.due_date is not None
        or args.done_ratio is not None
        or args.estimated_hours is not None
        or args.notes
        or args.custom_fields
        or args.relate
        or args.relate_to
        or args.delete_relation
        or args.attach
        or args.hours is not None
        or args.add_watcher_ids
        or args.remove_watcher_ids
    )
    if no_args_provided:
        _interactive_fill_issue_update_args(args)
    description = args.description
    if description is not None and description == "":
        current = fetch_issue(args.issue_id)
        description = open_editor(current.get("description") or "")
    should_update_issue = (
        args.subject
        or description is not None
        or args.tracker_id
        or args.status_id
        or args.priority_id
        or args.assigned_to_id is not None
        or args.fixed_version_id
        or args.parent_issue_id is not None
        or args.start_date is not None
        or args.due_date is not None
        or args.done_ratio is not None
        or args.estimated_hours is not None
        or args.notes
        or args.custom_fields
        or args.attach
    )
    should_update_issue_relation = args.delete_relation or (
        args.relate and args.relate_to
    )
    should_create_time_entry = args.hours is not None
    if should_update_issue:
        update_issue(
            issue_id=args.issue_id,
            subject=args.subject,
            description=description if description else None,
            tracker_id=args.tracker_id,
            status_id=args.status_id,
            priority_id=args.priority_id,
            assigned_to_id=args.assigned_to_id,
            fixed_version_id=args.fixed_version_id,
            parent_issue_id=args.parent_issue_id,
            start_date=args.start_date,
            due_date=args.due_date,
            done_ratio=args.done_ratio,
            estimated_hours=args.estimated_hours,
            notes=args.notes or "",
            custom_fields=args.custom_fields,
            attachments=args.attach,
        )
    if args.delete_relation:
        if not args.relate_to:
            print(messages.delete_relation_requires_to)
            exit(1)
        delete_relation(
            issue_id=args.issue_id,
            issue_to_id=args.relate_to,
        )
    elif args.relate and args.relate_to:
        create_relation(
            issue_id=args.issue_id,
            issue_to_id=args.relate_to,
            relation_type=args.relate,
        )
    elif args.relate or args.relate_to:
        print(messages.relate_and_to_required)
        exit(1)
    if should_create_time_entry:
        create_time_entry(
            issue_id=args.issue_id,
            hours=args.hours,
            activity_id=args.activity_id,
            spent_on=args.spent_on,
            comments=args.time_comments,
        )
    for user_id in args.add_watcher_ids or []:
        add_watcher(args.issue_id, user_id)
    for user_id in args.remove_watcher_ids or []:
        remove_watcher(args.issue_id, user_id)
    should_update_watchers = bool(args.add_watcher_ids or args.remove_watcher_ids)
    if (
        not should_update_issue
        and not should_update_issue_relation
        and not should_create_time_entry
        and not should_update_watchers
    ):
        print(messages.update_canceled_no_changes)
        exit(1)


def handle_issue(args: argparse.Namespace) -> None:
    cmd = resolve_alias(args.issue_command)
    if cmd == "view":
        read_issue(
            args.issue_id,
            include=args.include or "",
            full=args.full,
            web=args.web,
        )
    elif cmd == "create":
        handle_issue_create(args)
    elif cmd == "update":
        handle_issue_update(args)
    elif cmd == "comment":
        if args.notes:
            add_note(args.issue_id, args.notes)
        else:
            notes = open_editor()
            if notes:
                add_note(args.issue_id, notes)
            else:
                print(messages.canceled_empty_comment)
    elif cmd == "delete":
        if not args.yes:
            issue = fetch_issue(args.issue_id)
            confirm_delete(
                messages.delete_target_issue.format(
                    id=issue["id"], subject=issue["subject"]
                )
            )
        delete_issue(args.issue_id)
    elif cmd == "list" or cmd is None:
        list_issues(
            project_id=args.project_id or default_project_id,
            fixed_version_id=args.version,
            assigned_to=args.assigned_to,
            status_id=args.status_id,
            tracker_id=args.tracker_id,
            priority_id=args.priority_id,
            query_id=args.query_id,
            limit=args.limit,
            offset=args.offset,
            full=args.full,
        )
