# 作者: Assassin
# version: 0.4.21
"""
Mcode — interactive AI coding agent CLI.
Usage: python3 run.py [--project <name>]

Type /help inside the REPL for the full command list.
Esc+Enter for multiline input. @path to attach a file.
"""
import os
import sys
import threading

_HISTORY_FILE = os.path.expanduser("~/.mcode/history")

sys.path.insert(0, os.path.dirname(__file__))
from control.brain import Brain
from control.fmt import p_dim, p_info, p_warn, p_ok, cyan, dim, bold, fmt_prompt_tag

from cmds._utils import _ask, _toggle
from cmds.memory import cmd_memory
from cmds.tasks import cmd_tasks
from cmds.rewind import cmd_rewind, cmd_show_context, _show_recent_turns
from cmds.email import cmd_email
from cmds.project import cmd_project, cmd_new, cmd_switch, cmd_rename
from cmds.resource import cmd_resource
from cmds.at_expand import _extract_image_blocks, _expand_at_files


_HELP = """
Slash commands:
  /quit  /exit                      Exit the agent
  /end                              End session (save to memory, keep verbatim tail)
  /rewind [N]                       Rewind session: pick a turn, clear conversation and/or restore files
  /context [path]                   Export full context (core+project+recent memory + session history) to file or stdout

  /project new                      Start a fresh unbound session
  /project switch [name]            Switch to a session (interactive list if no name given)
  /project rename <name>            Rename the current session (makes it permanent)
  /project list                     List all sessions
  /project delete <name>            Delete a session (glob patterns supported)
  /project workdir [path]           Bind work_dir to current session (enables file rewind)

  /memory                           Show core memory (all dims), project memory (all dims), and open tasks
  /memory compact                   Condense bloated memory entries (removes duplicates via LLM)
  /memory set <key> <value>         Write a core memory entry (default dim: interaction_style)
  /memory set <key> <value> --dim <dim>  Write core memory entry with specific dimension (interaction_style / delegation)
  /memory del <key>                 Delete a core memory entry
  /memory pin <key>                 Pin an entry (stability=999, never forgets)
  /memory set <key> <value> --project   Write/correct a project memory entry (key = dimension name)
  /memory del <key> --project       Delete a project memory entry

  /resource                         [preview] List all registered resources (with index numbers)
  /resource add [-r] <path|glob|dir>  [preview] Classify and register file(s); -r for recursive dir
  /resource rescan [filter]         [preview] Re-classify resources with empty description/tags
  /resource del <idx|range|query>   [preview] Remove resource(s) by index/range (e.g. 1, 2-5) or keyword
  /resource edit <idx|query>        [preview] Edit name/description/tags by index or keyword
  /resource search <query>          [preview] Search resource registry by keyword

  /tasks                            List all tasks
  /tasks done <id>                  Mark task as done
  /tasks cancel <id>                Cancel a task
  /tasks del <id>                   Hard-delete a task from the store

!<command>                         Run shell command directly (bypasses LLM, still safety-checked)
  @<path>                           Attach a file's contents to your message (e.g. @src/main.py)

  /email [file] [--since <days>] [--batch <count>] [--lang zh|en] [--tasks]
                                   Summarise unread Outlook emails via LLM (Windows only)
                                   Scans Inbox + all subfolders within --since days (default 30);
                                   --batch: emails per LLM call (default 10); saves report to file if given

  /tools                            List all loaded tools
  /model [name]                     Show or switch the LLM model at runtime
  /btw <question>                   Quick one-shot question (no memory, no tools)
  /template [example]               Show auto-mode task prompt template
  /safety [on|off]                  Toggle safety module (off = bypass ALL checks, DANGEROUS)
  /auto [on|off]                    Toggle auto mode (no prompts, hard boundaries)
  /auto whitelist                   Show current whitelist
  /auto whitelist add <cmd>         Add command to whitelist
  /auto whitelist remove <cmd>      Remove command from whitelist
  /auto whitelist reset             Reset to default whitelist

  /status                           Show current settings
  /help                             Show this help
""".strip()


_AUTO_TEMPLATE = """\
# Auto-mode task template  (/auto on  to enable)
# ─────────────────────────────────────────────────
# Task: <一句话描述目标>
#
# Context:
#   - work_dir: <项目根目录，已在 /project workdir 设置>
#   - Language / framework: <语言/框架>
#   - Entry point: <主文件或命令>
#
# Acceptance criteria (done when ALL true):
#   1. <具体可验证的完成标准>
#   2. <例如：pytest 全部通过>
#   3. <例如：文件 X 存在且内容包含 Y>
#
# Constraints:
#   - Do NOT modify: <不能动的文件>
#   - Preserve existing tests
#
# Verify by running: <验证命令，例如 pytest / cargo test / npm test>
"""

_AUTO_TEMPLATE_EXAMPLE = """\
# 示例：给已有 Flask 项目加一个健康检查接口
# ─────────────────────────────────────────────────
Task: 在 app.py 里新增 GET /health 接口，返回 {"status": "ok"}

Context:
  - work_dir: /home/user/myapp
  - Language / framework: Python 3.11, Flask 2.x
  - Entry point: app.py

Acceptance criteria:
  1. GET /health 返回 200 和 {"status": "ok"}
  2. 不影响现有路由和测试
  3. pytest tests/ 全部通过

Constraints:
  - Do NOT modify: requirements.txt, Dockerfile

Verify by running: pytest tests/ -v
"""


def _cmd_template(arg: str):
    """Print auto-mode task template."""
    if arg in ("example", "ex"):
        print(cyan("\n── Auto-mode task example ──"))
        print(_AUTO_TEMPLATE_EXAMPLE)
    else:
        print(cyan("\n── Auto-mode task template ──"))
        print(_AUTO_TEMPLATE)
        print(dim("  tip: /template example  shows a filled-in example"))
    print()


def _cmd_btw(brain: Brain, question: str):
    """One-shot question: no memory, no tools, no project side-effects."""
    if not question:
        print("  Usage: /btw <question>")
        return

    messages = [{"role": "user", "content": question}]

    _stop = threading.Event()

    def _spin():
        frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        i = 0
        while not _stop.is_set():
            sys.stdout.write(f"\r  {frames[i % len(frames)]}  thinking…")
            sys.stdout.flush()
            _stop.wait(0.1)
            i += 1
        sys.stdout.write("\r\033[K")
        sys.stdout.flush()

    t = threading.Thread(target=_spin, daemon=True)
    t.start()

    chunks: list[str] = []
    try:
        for chunk in brain.llm.stream(messages, max_tokens=2000):
            if not _stop.is_set():
                _stop.set()
                t.join()
            chunks.append(chunk)
            sys.stdout.write(chunk)
            sys.stdout.flush()
    except KeyboardInterrupt:
        pass
    finally:
        if not _stop.is_set():
            _stop.set()
        t.join()

    if chunks:
        print()


def _cmd_safety(brain: Brain, arg: str):
    """Toggle safety bypass. Requires explicit confirmation when disabling."""
    from control.fmt import red, yellow, green

    if arg in ("on", ""):
        if not brain.bypass_safety:
            print("  Safety module is already ON.")
            return
        brain.bypass_safety = False
        p_ok("  Safety module restored.")
        return

    if arg == "off":
        if brain.bypass_safety:
            print("  Safety module is already OFF (bypassed).")
            return
        print(red("\n  ⚠️   WARNING — SAFETY BYPASS"))
        print(yellow("  ─" * 32))
        print(yellow("  All safety checks will be DISABLED."))
        print(yellow("  The agent can read/write/execute ANYWHERE"))
        print(yellow("  with full privileges of the current user."))
        print(yellow("  ─" * 32))
        print(red("  FOR EXPERIMENTAL ENVIRONMENTS ONLY."))
        print(red("  ANY CONSEQUENCES ARE YOUR RESPONSIBILITY."))
        print(yellow("  ─" * 32))
        try:
            raw = _ask("  Type 'yes' to confirm, anything else to cancel: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            raw = ""
        if raw != "yes":
            print(dim("  Cancelled."))
            return
        brain.bypass_safety = True
        print(red("  ⚡  Safety bypassed. You are on your own."))
        return

    print(f"  Usage: /safety on | /safety off")


def _cmd_auto(brain: Brain, args: str):
    """Manage auto mode and whitelist."""
    from safety.safety import DEFAULT_AUTO_WHITELIST
    from control.fmt import p_ok, p_info, green

    parts = args.split(None, 2)
    sub = parts[0].lower() if parts else ""

    if sub in ("on", "off", ""):
        if sub == "on":
            new = True
        elif sub == "off":
            new = False
        else:
            new = not brain.auto_mode
        brain.auto_mode = new
        brain._agent_cfg["auto_mode"] = new
        brain._save_agent_cfg()
        state = green("AUTO") if new else dim("HUMAN")
        print(f"  mode → {state}")
        if new:
            wl = brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST
            print(dim(f"  whitelist: {len(wl)} commands  (/auto whitelist to view)"))
        return

    if sub == "whitelist":
        sub2 = parts[1].lower() if len(parts) > 1 else "list"

        if sub2 in ("list", ""):
            wl = brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST
            source = "custom" if "auto_whitelist" in brain._agent_cfg else "default"
            print(f"\n  Whitelist ({source}, {len(wl)} entries):")
            for entry in sorted(wl):
                print(f"    {entry}")
            print()

        elif sub2 == "add":
            cmd_entry = parts[2].strip() if len(parts) > 2 else ""
            if not cmd_entry:
                print("  Usage: /auto whitelist add <command>")
                return
            wl = list(brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST)
            if cmd_entry in wl:
                print(f"  already in whitelist: {cmd_entry}")
                return
            wl.append(cmd_entry)
            brain._agent_cfg["auto_whitelist"] = wl
            brain._save_agent_cfg()
            p_ok(f"  added: {cmd_entry}")

        elif sub2 == "remove":
            cmd_entry = parts[2].strip() if len(parts) > 2 else ""
            if not cmd_entry:
                print("  Usage: /auto whitelist remove <command>")
                return
            wl = list(brain._agent_cfg.get("auto_whitelist") or DEFAULT_AUTO_WHITELIST)
            if cmd_entry not in wl:
                print(f"  not in whitelist: {cmd_entry}")
                return
            wl.remove(cmd_entry)
            brain._agent_cfg["auto_whitelist"] = wl
            brain._save_agent_cfg()
            p_ok(f"  removed: {cmd_entry}")

        elif sub2 == "reset":
            if "auto_whitelist" in brain._agent_cfg:
                del brain._agent_cfg["auto_whitelist"]
                brain._save_agent_cfg()
            p_ok("  whitelist reset to default")

        else:
            print(f"  Unknown: /auto whitelist {sub2}")
        return

    print(f"  Unknown: /auto {sub}  (try /auto on|off|whitelist)")


def handle_slash(cmd: str, brain: Brain) -> bool:
    """
    Handle a /command. Returns handled.
    Raises SystemExit on /quit.
    """
    parts = cmd[1:].split(None, 1)
    name = parts[0].lower()
    arg_raw = parts[1] if len(parts) > 1 else ""
    arg = arg_raw.lower()

    if name in ("quit", "exit"):
        if not getattr(brain, "_session_ended", False):
            brain.end_session()
            brain._session_ended = True
        raise SystemExit(0)

    if name == "end":
        brain.end_session()
        brain._session_ended = True
        print("[session ended]")

    elif name == "help":
        print(_HELP)

    elif name == "rewind":
        cmd_rewind(brain, arg)

    elif name == "context":
        cmd_show_context(brain, arg_raw)

    elif name == "project":
        cmd_project(brain, arg_raw)

    elif name == "memory":
        cmd_memory(brain, arg_raw)

    elif name == "resource":
        cmd_resource(brain, arg_raw)

    elif name == "tasks":
        cmd_tasks(brain, arg_raw)

    elif name == "btw":
        _cmd_btw(brain, arg_raw)

    elif name == "template":
        _cmd_template(arg)

    elif name == "safety":
        _cmd_safety(brain, arg)

    elif name == "auto":
        _cmd_auto(brain, arg_raw)

    elif name == "parallel":
        pass  # parallel execution removed (agentic loop handles sequencing)

    elif name == "model":
        if not arg_raw:
            active = brain._agent_cfg.get("active_model", "")
            print(f"  active: {active}  ({brain.llm.model})")
            models = brain.list_models()
            if models:
                print("  available:")
                for alias, prof in models.items():
                    marker = " ◀" if alias == active else ""
                    print(f"    {alias}{marker}  — {prof.get('model', '')}  [{prof.get('provider', 'openai')}]")
            print("  usage: /model <alias>")
        else:
            alias = arg_raw.strip()
            try:
                brain.switch_model(alias)
                p_ok(f"  model → {alias}  ({brain.llm.model})")
            except KeyError as e:
                print(f"  {e}")
                print(f"  available: {', '.join(brain.list_models())}")

    elif name == "email":
        cmd_email(brain, arg_raw)

    elif name == "tools":
        tools = brain.registry.list()
        print(f"\n  {len(tools)} tool(s) loaded:")
        for t in tools:
            print(f"  • {t.name:20s} {t.description.splitlines()[0]}")
        print()

    elif name == "status":
        p = brain.projects.current_project
        wd = brain.projects.work_dir
        wd_str = f"{wd}  (explicit)" if brain.projects.has_work_dir else f"{wd}  (cwd fallback, no rewind)"
        mode = "AUTO" if brain.auto_mode else "HUMAN"
        safety = "⚡ BYPASSED" if brain.bypass_safety else "ON"
        cfg_path = os.path.expanduser("~/.mcode/agent.json")
        debug_log = getattr(brain, "_debug_log_path", "")
        print(
            f"  session:   {p}\n"
            f"  work_dir:  {wd_str}\n"
            f"  model:     {brain.llm.model}\n"
            f"  mode:      {mode}\n"
            f"  safety:    {safety}\n"
            f"  config:    {cfg_path}\n"
            f"  debug log: {debug_log}\n"
        )

    else:
        print(f"Unknown command: /{name}  (type /help for list)")

    return True


def _print_logo(brain: "Brain"):
    logo = r"""  __  __               _
 |  \/  | ___ ___   __| | ___
 | |\/| |/ __/ _ \ / _` |/ _ \
 | |  | | (_| (_) | (_| |  __/
 |_|  |_|\___\___/ \__,_|\___|"""
    width = os.get_terminal_size().columns if sys.stdout.isatty() else 72
    border = cyan("─" * width)
    project = brain.projects.current_project
    active = brain._agent_cfg.get("active_model", "")
    model_str = f"{active}  ({brain.llm.model})" if active else brain.llm.model
    print()
    print(border)
    print(cyan(logo))
    print(border)
    print("  Mcode  —  Your local AI coding agent")
    print(dim("  › /help for commands"))
    bound = "  [workdir bound]" if brain.projects.has_work_dir else ""
    print(dim(f"  › Session: {project}{bound}  —  /project rename <name> · /project switch · /project new"))
    print(dim(f"  › Model:   {model_str}  —  /model to switch"))
    print(border)
    print()


def _divider():
    width = os.get_terminal_size().columns if sys.stdout.isatty() else 72
    print(cyan("─" * width))


def _normalize_blank_lines(text: str) -> str:
    """Remove excessive blank lines (keep at most 1 blank line)."""
    import re
    return re.sub(r'\n{3,}', '\n\n', text)


def _render_markdown(text: str):
    """Render markdown with rich if available, else plain print."""
    text = _normalize_blank_lines(text)
    try:
        from rich.console import Console
        from rich.markdown import Markdown
        Console().print(Markdown(text))
    except Exception:
        print(text)


def _run_shell_direct(brain: Brain, cmd: str):
    """Execute a shell command directly, bypassing the LLM. Output is shown to user only."""
    from control.planner import Task
    import safety.safety as _safety
    from safety.policy import is_always_allowed, remember_always, get_allowed_paths
    from control.fmt import red, yellow

    if not cmd:
        return

    task = Task(id=1, tool="shell_exec", args={"command": cmd},
                description=cmd, depends_on=[])

    work_dir = brain.projects.work_dir
    result = _safety.check(task, work_dir=work_dir,
                           allowed_paths=get_allowed_paths())

    if result.violation:
        print(red(f"🛑  BLOCKED  {result.reason}"))
        return

    if result.backup_paths:
        print(dim(f"💾  backup → {', '.join(result.backup_paths)}"))

    if result.requires_confirmation:
        op = result.operation_class
        if not (op and is_always_allowed(op)):
            print(yellow(f"⚠️   {result.reason}"))
            if result.can_always:
                raw = _ask("    Proceed? [y]es  [n]o  [a]lways ❯ ").lower()
            else:
                raw = _ask("    Proceed? [y]es  [n]o ❯ ").lower()
            if raw in ("a", "always") and result.can_always:
                remember_always(op)
                print(cyan(f"📌  policy saved: always allow [{op}]"))
            elif raw not in ("y", "yes"):
                print(red("🚫  cancelled"))
                return

    if result.backup_paths:
        from safety.backup import backup_files
        backup_files(result.backup_paths)

    import subprocess as _sp
    from tools.shell import _wrap_command, _popen_session_kwargs
    cwd = work_dir or os.getcwd()
    _args, _use_shell = _wrap_command(cmd)
    try:
        proc = _sp.Popen(_args, shell=_use_shell, cwd=cwd, **_popen_session_kwargs())
        proc.wait()
        if proc.returncode != 0:
            print(dim(f"  [exit {proc.returncode}]"))
    except KeyboardInterrupt:
        proc.kill()
        print()


def _run_with_output(brain: Brain, user_input: str):
    """Run one turn: stderr spinner during thinking, then render with dividers."""
    _stop = threading.Event()
    _frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    _fi = [0]

    def _spin():
        while not _stop.wait(0.1):
            sys.stderr.write(f"\r  {_frames[_fi[0] % len(_frames)]}  thinking…")
            sys.stderr.flush()
            _fi[0] += 1
        sys.stderr.write("\r\033[K")
        sys.stderr.flush()

    brain._spinner_stop = _stop
    t = threading.Thread(target=_spin, daemon=True)
    t.start()

    chunks: list[str] = []
    try:
        for chunk in brain.stream_run(user_input):
            if not _stop.is_set():
                _stop.set()
            chunks.append(chunk)
    except KeyboardInterrupt:
        _stop.set()
        t.join(timeout=1)
        raise
    except Exception as _e:
        _stop.set()
        t.join(timeout=1)
        from control.fmt import p_err
        p_err(f"[error] {type(_e).__name__}: {_e}")
        return
    finally:
        _stop.set()
        t.join(timeout=1)

    full = "".join(chunks)

    _divider()
    if full.strip():
        full = _normalize_blank_lines(full)
        if brain._last_was_action:
            print(full)
        else:
            _render_markdown(full)

    # Direct confirmation for staged resource operations
    if hasattr(brain, "resources"):
        _mgr = brain.resources
        _reg = _mgr._pending
        _del = _mgr._pending_delete
        if _reg or _del:
            _parts = []
            if _reg:
                _parts.append(f"登记 {len(_reg)} 个文件")
            if _del:
                _parts.append(f"删除 {len(_del)} 条记录")
            try:
                _answer = input(f"\n确认{' / '.join(_parts)}？[y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                _answer = ""
            if _answer in ("y", "yes", "确认", "是", "ok", "好的"):
                _result = _mgr.commit_pending()
                if _result["registered"]:
                    for _r in _result["registered"]:
                        p_ok(f"  ✓ 已登记 {_r['name']}  →  {_r['path']}")
                if _result["deleted"]:
                    for _r in _result["deleted"]:
                        print(dim(f"  ✗ 已删除 {_r['name']}  →  {_r['path']}"))
            else:
                _mgr._pending = []
                _mgr._pending_delete = []
                print(dim("  已取消。"))

    _divider()
    print()


_TOP_CMDS = [
    "/quit", "/exit", "/end", "/help", "/status", "/tools",
    "/rewind", "/context",
    "/btw", "/template", "/safety", "/auto",
    "/model", "/project", "/memory", "/tasks", "/resource", "/email",
]
_SUB_CMDS = {
    "project": ["new", "switch", "list", "delete", "rename", "workdir"],
    "memory": ["set", "del", "pin"],
    "resource": ["list", "add", "del", "search"],
}
_TOGGLE_VALS = ["on", "off"]
_TOGGLE_CMDS = {"safety", "auto"}


def _make_session(brain: "Brain"):
    """Build a prompt_toolkit PromptSession with completer and status bar."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.styles import Style, DynamicStyle
    from prompt_toolkit.key_binding import KeyBindings

    _STYLE_BASE = {
        "bottom-toolbar":         "bg:#1c1c1e #636366",
        "bottom-toolbar.divider": "bg:#1c1c1e #3a3a3c",
        "bottom-toolbar.project": "bg:#1c1c1e #5ac8fa bold",
        "bottom-toolbar.path":    "bg:#1c1c1e #8e8e93",
        "bottom-toolbar.tokens":  "bg:#1c1c1e #34c759",
        "bottom-toolbar.dry":     "bg:#1c1c1e #ffd60a",
    }

    def _make_style():
        try:
            from prompt_toolkit.application import get_app
            shell_mode = get_app().current_buffer.text.startswith("!")
        except Exception:
            shell_mode = False
        extra = {"": "bg:#3a0000"} if shell_mode else {}
        return Style.from_dict({**_STYLE_BASE, **extra})

    style = DynamicStyle(_make_style)

    class _Completer(Completer):
        def get_completions(self, document, complete_event):
            text = document.text_before_cursor

            # @file completion
            words = text.split()
            if words:
                last = words[-1]
                if last.startswith("@"):
                    raw = last[1:]
                    path = os.path.expanduser(raw) if raw else ""
                    work_dir = brain.projects.work_dir or os.getcwd()
                    base = path if os.path.isabs(path) else os.path.join(work_dir, path)
                    if path.endswith("/") or not path:
                        dir_path = base
                        prefix = ""
                    else:
                        dir_path = os.path.dirname(base) or work_dir
                        prefix = os.path.basename(base)
                    try:
                        entries = sorted(os.listdir(dir_path))
                    except OSError:
                        entries = []
                    for entry in entries:
                        if entry.startswith("."):
                            continue
                        if entry.lower().startswith(prefix.lower()):
                            full = os.path.join(dir_path, entry)
                            suffix = "/" if os.path.isdir(full) else ""
                            completion = entry[len(prefix):] + suffix
                            display = entry + suffix
                            yield Completion(completion, display=display)
                    return

            if not text.startswith("/"):
                return
            parts = text.split()
            trailing = text.endswith(" ")

            if not parts or (len(parts) == 1 and not trailing):
                prefix = parts[0] if parts else "/"
                for cmd in _TOP_CMDS:
                    if cmd.startswith(prefix):
                        yield Completion(cmd[len(prefix):], display=cmd)

            elif len(parts) == 1 and trailing:
                cmd = parts[0].lstrip("/")
                if cmd == "model":
                    for alias in brain.list_models():
                        yield Completion(alias)
                else:
                    opts = _SUB_CMDS.get(cmd, _TOGGLE_VALS if cmd in _TOGGLE_CMDS else [])
                    for o in opts:
                        yield Completion(o)

            elif len(parts) == 2 and not trailing:
                cmd = parts[0].lstrip("/")
                prefix = parts[1]
                if cmd == "model":
                    for alias in brain.list_models():
                        if alias.startswith(prefix):
                            yield Completion(alias[len(prefix):], display=alias)
                else:
                    opts = _SUB_CMDS.get(cmd, _TOGGLE_VALS if cmd in _TOGGLE_CMDS else [])
                    for o in opts:
                        if o.startswith(prefix):
                            yield Completion(o[len(prefix):], display=o)

            elif (parts[0] == "/project" and len(parts) >= 2
                  and parts[1] == "switch"):
                prefix = parts[2] if len(parts) == 3 and not trailing else ""
                try:
                    for p in brain.projects.list_projects():
                        if p["name"].startswith(prefix):
                            yield Completion(p["name"][len(prefix):],
                                             display=p["name"])
                except Exception:
                    pass

    def _toolbar():
        import shutil
        from tools.shell import get_bg_processes
        width = shutil.get_terminal_size((80, 24)).columns
        project = brain.projects.current_project
        wd = brain.projects.work_dir or ""
        home = os.path.expanduser("~")
        if wd:
            wd = wd.replace(home, "~")
        tokens = getattr(brain.memory, "_last_context_tokens", 0)
        tok_str = f"{tokens:,} tokens" if tokens else "0 tokens"
        compress_count = getattr(brain.memory, "_compress_count", 0)
        compress_part = (f" <bottom-toolbar.dry>[compressed×{compress_count}]</bottom-toolbar.dry>"
                         f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if compress_count else ""

        active = brain._agent_cfg.get("active_model", "") or brain.llm.model
        divider = "─" * width
        wd_part = (f" <bottom-toolbar.path>{wd}</bottom-toolbar.path>"
                   f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if wd else ""
        auto_part = (f" <bottom-toolbar.dry>AUTO</bottom-toolbar.dry>"
                     f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if brain.auto_mode else ""
        bypass_part = (f" <bottom-toolbar.dry>⚡UNSAFE</bottom-toolbar.dry>"
                       f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if brain.bypass_safety else ""
        _n_bg = len(get_bg_processes())
        shell_part = (f" <bottom-toolbar.dry>{_n_bg} shell</bottom-toolbar.dry>"
                      f" <bottom-toolbar.divider>│</bottom-toolbar.divider>") if _n_bg else ""

        return HTML(
            f"<bottom-toolbar.divider>{divider}</bottom-toolbar.divider>\n"
            f" <bottom-toolbar.project>{project}</bottom-toolbar.project>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f" <bottom-toolbar.path>{active}</bottom-toolbar.path>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f"{wd_part}{auto_part}{bypass_part}{compress_part}{shell_part}"
            f" <bottom-toolbar.tokens>{tok_str}</bottom-toolbar.tokens>"
            f" <bottom-toolbar.divider>│</bottom-toolbar.divider>"
            f" <bottom-toolbar.path>Esc+↵ newline · Ctrl+C cancel</bottom-toolbar.path> "
        )

    kb = KeyBindings()

    @kb.add("enter")
    def _submit(event):
        event.current_buffer.validate_and_handle()

    @kb.add("escape", "enter")
    def _newline(event):
        event.current_buffer.insert_text("\n")

    @kb.add("c-j")
    def _newline_cj(event):
        event.current_buffer.insert_text("\n")

    @kb.add("escape", "up")
    def _hist_prev(event):
        event.current_buffer.history_backward()

    @kb.add("escape", "down")
    def _hist_next(event):
        event.current_buffer.history_forward()

    session = PromptSession(
        history=FileHistory(_HISTORY_FILE),
        completer=_Completer(),
        complete_while_typing=False,
        bottom_toolbar=_toolbar,
        style=style,
        refresh_interval=1.0,
        multiline=True,
        key_bindings=kb,
        prompt_continuation=lambda width, line_number, is_soft_wrap: "  ",
    )
    return session


def main():
    import argparse
    import logging
    from control.project_manager import is_auto_named

    parser = argparse.ArgumentParser()
    parser.add_argument("--project", "-p", default=None,
                        help="Switch to a named project instead of creating a new auto session")
    parser.add_argument("--version", "-V", action="store_true",
                        help="Show version and exit")
    args = parser.parse_args()

    if args.version:
        try:
            from importlib.metadata import version
            print(version("memocode"))
        except Exception:
            print("0.5.3")
        return

    import tempfile
    from logging.handlers import RotatingFileHandler

    _log_fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")

    _info_log_path = os.path.expanduser("~/.mcode/chatmem.log")
    os.makedirs(os.path.dirname(_info_log_path), exist_ok=True)
    _info_handler = logging.FileHandler(_info_log_path, encoding="utf-8")
    _info_handler.setLevel(logging.INFO)
    _info_handler.setFormatter(_log_fmt)

    _debug_log_path = os.path.join(tempfile.gettempdir(), "mcode_debug.log")
    _debug_handler = RotatingFileHandler(
        _debug_log_path, maxBytes=1024 * 1024, backupCount=3, encoding="utf-8"
    )
    _debug_handler.setLevel(logging.DEBUG)
    _debug_handler.setFormatter(_log_fmt)

    _chatmem_logger = logging.getLogger("chatmem")
    _chatmem_logger.addHandler(_info_handler)
    _chatmem_logger.addHandler(_debug_handler)
    _chatmem_logger.setLevel(logging.DEBUG)

    try:
        brain = Brain(project=args.project or None)
    except RuntimeError as e:
        import platform as _platform
        from control.fmt import yellow
        _cfg = os.path.expanduser("~/.mcode/agent.json")
        print(yellow(f"\n  ✗  {e}"))
        print()
        print(f"  Config file: {_cfg}")
        print()
        print("  Set the API key environment variable, then restart mcode:")
        print()
        if _platform.system() == "Windows":
            print(dim("    PowerShell (current session):"))
            print(dim('      $env:YOUR_API_KEY = "your_api_key_here"'))
            print()
            print(dim("    PowerShell (persistent — user level):"))
            print(dim('      [System.Environment]::SetEnvironmentVariable("YOUR_API_KEY", "your_api_key_here", "User")'))
            print()
            print(dim("    CMD (current session):"))
            print(dim("      set YOUR_API_KEY=your_api_key_here"))
        else:
            print(dim("    Current session only:"))
            print(dim("      export YOUR_API_KEY=your_api_key_here"))
            print()
            _rc = ".zshrc" if os.path.exists(os.path.expanduser("~/.zshrc")) else ".bashrc"
            print(dim(f"    Persist across sessions (add to ~/{_rc}):"))
            print(dim(f"      echo 'export YOUR_API_KEY=your_api_key_here' >> ~/{_rc}"))
            print(dim(f"      source ~/{_rc}"))
        print()
        raise SystemExit(1)

    session = _make_session(brain)

    import atexit, signal as _signal

    def _on_exit():
        if not getattr(brain, "_session_ended", False):
            try:
                brain.end_session()
            except (Exception, KeyboardInterrupt, SystemExit):
                pass

    atexit.register(_on_exit)

    def _on_sigterm(*_):
        _on_exit()
        raise SystemExit(0)

    try:
        _signal.signal(_signal.SIGTERM, _on_sigterm)
    except (OSError, ValueError):
        pass

    stale = brain.projects.cleanup_stale()
    if stale:
        p_dim(f"[cleanup] removed {len(stale)} stale session(s): {', '.join(stale)}")

    if args.project:
        try:
            brain.switch_project(args.project)
            p_info(f"[project] {args.project}")
        except FileNotFoundError:
            brain.projects.new_project(args.project, work_dir=None)
            brain.switch_project(args.project)
            p_info(f"[project] created: {args.project}")
    else:
        matched = brain.projects.find_permanent_for_cwd()
        if matched:
            brain.switch_project(matched)
            p_info(f"[restored] {matched}")
        else:
            auto_name = brain.projects.new_auto_project()
            brain.switch_project(auto_name)

    brain._debug_log_path = _debug_log_path
    _print_logo(brain)

    _pending_count = len(brain.memory.load_pending_sessions())
    if _pending_count:
        import threading as _threading
        _sync_stop = _threading.Event()

        def _sync_spin():
            frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
            i = 0
            while not _sync_stop.is_set():
                sys.stdout.write(f"\r  {frames[i % len(frames)]}  同步记忆中...")
                sys.stdout.flush()
                _sync_stop.wait(0.1)
                i += 1
            sys.stdout.write("\r\033[K")
            sys.stdout.flush()

        _spin_t = _threading.Thread(target=_sync_spin, daemon=True)
        _spin_t.start()
        brain.process_pending_sessions(blocking=True)
        _sync_stop.set()
        _spin_t.join()
        p_dim(f"  [memory] synced {_pending_count} session(s)")
    else:
        brain.process_pending_sessions(blocking=True)

    _show_recent_turns(brain)

    _sync_thread = getattr(brain, "_resource_sync_thread", None)
    if _sync_thread and _sync_thread.is_alive():
        _sync_thread.join(timeout=3)
    _sync = getattr(brain, "_resource_sync_result", {})
    if _sync.get("removed") or _sync.get("updated") or _sync.get("added"):
        _parts = []
        if _sync.get("added"):
            _parts.append(f"{_sync['added']} added")
        if _sync.get("updated"):
            _parts.append(f"{_sync['updated']} updated")
        if _sync.get("removed"):
            _parts.append(f"{_sync['removed']} removed")
        p_dim(f"  [resources] {', '.join(_parts)}")

    _open_tasks = brain.tasks.open_tasks() if hasattr(brain, "tasks") else []
    if _open_tasks:
        print(cyan(f"[Tasks] {len(_open_tasks)} open task(s) — /memory to view"))

    _had_conversation = False
    _divider()
    while True:
        try:
            user_input = session.prompt("❯ ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye.")
            break

        if not user_input:
            continue

        first_line = user_input.splitlines()[0].strip()

        _divider()

        if first_line.startswith("/"):
            try:
                handle_slash(first_line, brain)
            except SystemExit:
                break
            print()
            continue

        if first_line.startswith("!"):
            _run_shell_direct(brain, first_line[1:].strip())
            print()
            continue

        _bare = first_line.strip().lower().replace("-", "_")
        if _bare in {t.name for t in brain.registry.list()}:
            user_input = f"Call the {first_line.strip()} tool now and show me the result."

        _had_conversation = True
        brain._session_ended = False
        user_input, _img_blocks, _img_names = _extract_image_blocks(user_input, brain.projects.work_dir)
        user_input = _expand_at_files(user_input, brain.projects.work_dir, brain)
        if _img_blocks:
            _img_note = "  ".join(f"[image: {n}]" for n in _img_names)
            _text_with_note = f"{_img_note}\n{user_input}".strip()
            user_content: "str | list" = [{"type": "text", "text": _text_with_note}] + _img_blocks
        else:
            user_content = user_input
        try:
            _run_with_output(brain, user_content)
        except KeyboardInterrupt:
            _divider()
            print()
        except Exception as e:
            from control.fmt import red
            import traceback
            logging.getLogger("chatmem").debug(
                "Unhandled exception:\n%s", traceback.format_exc()
            )
            _divider()
            print(red(f"  ✗  {type(e).__name__}: {e}"))
            traceback.print_exc()
            _divider()
            print()

    if not getattr(brain, "_session_ended", False):
        try:
            brain.end_session()
        except (KeyboardInterrupt, Exception):
            pass

    p = brain.projects.current_project
    if _had_conversation and is_auto_named(p):
        p_info(f"[tip] save this session: /project rename <name>")


if __name__ == "__main__":
    main()
