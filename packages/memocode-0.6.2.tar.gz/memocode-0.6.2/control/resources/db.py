"""
Resource registry — SQLite storage layer.
Stores metadata about local files so the LLM can find them by topic/task.
"""
import json
import math
import os
import re
import sqlite3
from contextlib import contextmanager

_DEFAULT_DB = os.path.expanduser("~/.mcode/resources/index.db")


def init_db(db_path: str = _DEFAULT_DB) -> None:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    with _conn(db_path) as cx:
        cx.execute("""
            CREATE TABLE IF NOT EXISTS resources (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT NOT NULL,
                path        TEXT NOT NULL UNIQUE,
                description TEXT DEFAULT '',
                tags        TEXT DEFAULT '[]',
                file_hash   TEXT DEFAULT '',
                file_mtime  REAL DEFAULT 0,
                created_at  TEXT DEFAULT (datetime('now')),
                updated_at  TEXT DEFAULT (datetime('now')),
                use_count   INTEGER DEFAULT 0,
                last_used   TEXT
            )
        """)
        cx.execute("""
            CREATE TABLE IF NOT EXISTS resource_cooccurrence (
                file_id_a   INTEGER NOT NULL,
                file_id_b   INTEGER NOT NULL,
                count       INTEGER DEFAULT 1,
                last_seen   TEXT DEFAULT (datetime('now')),
                PRIMARY KEY (file_id_a, file_id_b)
            )
        """)
        cx.execute("""
            CREATE TABLE IF NOT EXISTS watched_dirs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                path        TEXT NOT NULL UNIQUE,
                recursive   INTEGER DEFAULT 0,
                created_at  TEXT DEFAULT (datetime('now'))
            )
        """)
        # migrate: drop scope column if it exists (SQLite doesn't support DROP COLUMN
        # before 3.35, so we just ignore it on read via _row_to_dict)


@contextmanager
def _conn(db_path: str):
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


_CJK_BOUNDARY_RE = re.compile(
    r'(?<=[a-z0-9])(?=[\u4e00-\u9fff])|(?<=[\u4e00-\u9fff])(?=[a-z0-9])'
)


def _tokenize(text: str) -> list[str]:
    """Tokenize for BM25: CJK bigrams + word tokens for Latin/mixed.
    Also splits at Latin/CJK script boundaries so 'go语言' → ['go', '语言'].
    """
    text = text.lower()
    tokens: list[str] = []
    for i in range(len(text) - 1):
        if '\u4e00' <= text[i] <= '\u9fff' or '\u4e00' <= text[i + 1] <= '\u9fff':
            tokens.append(text[i:i + 2])
    # Insert spaces at Latin↔CJK boundaries before word-splitting so that
    # mixed tokens like "go语言特性" → "go" + "语言特性" instead of one opaque token.
    split_text = _CJK_BOUNDARY_RE.sub(' ', text)
    tokens.extend(w for w in re.split(r'[^\w]+', split_text) if len(w) > 1)
    return tokens


def _bm25(query_tokens: list[str], docs: list[list[str]], k1: float = 1.5, b: float = 0.75) -> list[float]:
    """Return BM25 score for each document."""
    N = len(docs)
    if not N:
        return []
    avg_dl = sum(len(d) for d in docs) / N or 1.0
    df: dict[str, int] = {}
    for doc in docs:
        for t in set(doc):
            df[t] = df.get(t, 0) + 1
    scores: list[float] = []
    for doc in docs:
        dl = len(doc)
        tf: dict[str, int] = {}
        for t in doc:
            tf[t] = tf.get(t, 0) + 1
        score = 0.0
        for qt in query_tokens:
            n = df.get(qt, 0)
            if not n:
                continue
            idf = math.log((N - n + 0.5) / (n + 0.5) + 1)
            f = tf.get(qt, 0)
            score += idf * f * (k1 + 1) / (f + k1 * (1 - b + b * dl / avg_dl))
        scores.append(score)
    return scores


def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    d["tags"] = json.loads(d.get("tags") or "[]")
    d.pop("scope", None)  # remove legacy field if present
    return d


# ── Write ──────────────────────────────────────────────────────────────────────

def upsert(
    path: str,
    name: str,
    description: str,
    tags: list[str],
    file_hash: str,
    file_mtime: float,
    db_path: str = _DEFAULT_DB,
) -> None:
    with _conn(db_path) as cx:
        cx.execute("""
            INSERT INTO resources (name, path, description, tags, file_hash, file_mtime)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(path) DO UPDATE SET
                name        = excluded.name,
                description = excluded.description,
                tags        = excluded.tags,
                file_hash   = excluded.file_hash,
                file_mtime  = excluded.file_mtime,
                updated_at  = datetime('now')
        """, (name, path, description, json.dumps(tags, ensure_ascii=False),
              file_hash, file_mtime))


def update_content(
    path: str,
    description: str,
    tags: list[str],
    file_hash: str,
    file_mtime: float,
    db_path: str = _DEFAULT_DB,
) -> None:
    """Update description/tags after file content changed."""
    with _conn(db_path) as cx:
        cx.execute("""
            UPDATE resources
            SET description = ?, tags = ?, file_hash = ?, file_mtime = ?,
                updated_at = datetime('now')
            WHERE path = ?
        """, (description, json.dumps(tags, ensure_ascii=False), file_hash, file_mtime, path))


def delete(path: str, db_path: str = _DEFAULT_DB) -> None:
    with _conn(db_path) as cx:
        file_id = cx.execute("SELECT id FROM resources WHERE path = ?", (path,)).fetchone()
        if file_id:
            fid = file_id["id"]
            cx.execute(
                "DELETE FROM resource_cooccurrence WHERE file_id_a = ? OR file_id_b = ?",
                (fid, fid),
            )
        cx.execute("DELETE FROM resources WHERE path = ?", (path,))


def record_use(path: str, db_path: str = _DEFAULT_DB) -> None:
    with _conn(db_path) as cx:
        cx.execute("""
            UPDATE resources
            SET use_count = use_count + 1, last_used = datetime('now')
            WHERE path = ?
        """, (path,))


def record_cooccurrence(file_ids: list[int], db_path: str = _DEFAULT_DB) -> None:
    """Record that file_ids were referenced together. Updates co-occurrence counts."""
    if len(file_ids) < 2:
        return
    with _conn(db_path) as cx:
        for i in range(len(file_ids)):
            for j in range(i + 1, len(file_ids)):
                a, b = sorted([file_ids[i], file_ids[j]])
                cx.execute("""
                    INSERT INTO resource_cooccurrence (file_id_a, file_id_b, count, last_seen)
                    VALUES (?, ?, 1, datetime('now'))
                    ON CONFLICT(file_id_a, file_id_b) DO UPDATE SET
                        count = count + 1,
                        last_seen = datetime('now')
                """, (a, b))


def add_watch(path: str, recursive: bool = False, db_path: str = _DEFAULT_DB) -> None:
    with _conn(db_path) as cx:
        cx.execute("""
            INSERT INTO watched_dirs (path, recursive)
            VALUES (?, ?)
            ON CONFLICT(path) DO UPDATE SET recursive = excluded.recursive
        """, (path, int(recursive)))


def remove_watch(path: str, db_path: str = _DEFAULT_DB) -> bool:
    """Returns True if a row was deleted."""
    with _conn(db_path) as cx:
        cur = cx.execute("DELETE FROM watched_dirs WHERE path = ?", (path,))
        return cur.rowcount > 0


def list_watches(db_path: str = _DEFAULT_DB) -> list[dict]:
    with _conn(db_path) as cx:
        rows = cx.execute("SELECT * FROM watched_dirs ORDER BY path").fetchall()
    return [dict(r) for r in rows]


def get_cooccurred(file_id: int, db_path: str = _DEFAULT_DB, top_k: int = 5) -> list[int]:
    """Return file IDs that most frequently co-occur with the given file_id."""
    with _conn(db_path) as cx:
        rows = cx.execute("""
            SELECT CASE WHEN file_id_a = ? THEN file_id_b ELSE file_id_a END AS other_id,
                   count
            FROM resource_cooccurrence
            WHERE file_id_a = ? OR file_id_b = ?
            ORDER BY count DESC
            LIMIT ?
        """, (file_id, file_id, file_id, top_k)).fetchall()
    return [r["other_id"] for r in rows]


# ── Read ───────────────────────────────────────────────────────────────────────

def get_all(db_path: str = _DEFAULT_DB) -> list[dict]:
    with _conn(db_path) as cx:
        rows = cx.execute(
            "SELECT * FROM resources ORDER BY name"
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def get_by_ids(file_ids: list[int], db_path: str = _DEFAULT_DB) -> list[dict]:
    if not file_ids:
        return []
    placeholders = ",".join("?" * len(file_ids))
    with _conn(db_path) as cx:
        rows = cx.execute(
            f"SELECT * FROM resources WHERE id IN ({placeholders})", file_ids
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def match_by_pattern(pattern: str, db_path: str = _DEFAULT_DB) -> list[dict]:
    """
    Regex match against resource name and path (case-insensitive).
    Falls back to plain substring match if pattern is invalid regex.
    Used for deletion to avoid BM25 false positives.
    """
    records = get_all(db_path)
    try:
        rx = re.compile(pattern, re.IGNORECASE)
        return [r for r in records if rx.search(r["name"]) or rx.search(r["path"])]
    except re.error:
        p = pattern.lower()
        return [r for r in records if p in r["name"].lower() or p in r["path"].lower()]


def _normalize(s: str) -> str:
    """Normalize for @mention matching: lowercase, strip whitespace and separators."""
    import unicodedata
    s = unicodedata.normalize("NFC", s)
    s = s.lower().strip()
    # collapse underscores/hyphens/spaces used as word separators
    s = re.sub(r"[\s_\-]+", "", s)
    return s


def match_by_name(name: str, db_path: str = _DEFAULT_DB) -> list[dict]:
    """
    Exact and fuzzy name/basename match for @mention resolution.
    Priority: exact name match > basename match > substring match.
    """
    norm_input = _normalize(name)
    records = get_all(db_path)
    exact, basename_match, substring = [], [], []
    for r in records:
        rname = _normalize(r["name"])
        rbase = _normalize(os.path.splitext(os.path.basename(r["path"]))[0])
        if rname == norm_input or rbase == norm_input:
            exact.append(r)
        elif norm_input in rname or norm_input in rbase:
            basename_match.append(r)
        elif rname in norm_input or rbase in norm_input:
            substring.append(r)
    return exact or basename_match or substring


# File extension tokens — structural metadata, not semantic content.
# Excluded from name-layer matching to prevent extension-only false positives.
_EXT_STOPWORDS = {
    "py", "pdf", "txt", "md", "js", "ts", "json", "yaml", "yml",
    "csv", "xlsx", "xls", "html", "htm", "css", "sh", "bat",
    "java", "cpp", "cc", "cxx", "cs", "go", "rs", "rb", "php",
    "toml", "ini", "cfg", "conf", "log", "sql", "db", "xml",
}


def _name_tokens(d: dict) -> set[str]:
    """
    Meaningful tokens from resource name + full path (all components).
    Includes every directory segment and the filename stem so that path-based
    queries like "weekly", "reports/2024", or "src/auth" work in Layer-1 match.
    Excludes: file extension, single-char tokens, extension stopwords.
    """
    base = os.path.splitext(os.path.basename(d["path"]))[0]
    # Split full path into components, normalise separators and word-delimiters
    path_parts = d["path"].replace("\\", "/").split("/")
    raw = " ".join(
        [d["name"], base]
        + [p.replace("_", " ").replace("-", " ").replace(".", " ") for p in path_parts if p]
    )
    return {t for t in _tokenize(raw) if len(t) >= 2 and t not in _EXT_STOPWORDS}


def search(query: str, db_path: str = _DEFAULT_DB, threshold: float = 0.0,
           boost_ids: list[int] | None = None) -> list[dict]:
    """
    Two-layer resource search:
      Layer 1 — name match: query token overlaps with resource name / base filename
                (extension tokens excluded; requires token length >= 2)
      Layer 2 — semantic BM25: scored on description + tags only (no path/extension noise)
                with a minimum threshold of 0.3

    A resource matches if it passes either layer.
    Ranked by semantic BM25 score; name-only matches get a small fixed score.
    boost_ids: file IDs to boost via co-occurrence (added as candidates even if below threshold).
    """
    query_tokens = _tokenize(query)
    if not query_tokens:
        return get_all(db_path)

    with _conn(db_path) as cx:
        rows = cx.execute("SELECT * FROM resources").fetchall()
    if not rows:
        return []

    records = [_row_to_dict(r) for r in rows]
    boost_set = set(boost_ids or [])

    # Significant query tokens: length >= 2, not pure extension stopwords.
    # If the entire query is stopwords (e.g. "go", "ts"), fall back to unfiltered tokens
    # so the user's explicit search intent is not discarded.
    sig_query = {t for t in query_tokens if len(t) >= 2 and t not in _EXT_STOPWORDS}
    match_query = sig_query or {t for t in query_tokens if len(t) >= 2}

    # Layer 1: name/filename token overlap
    name_match: set[int] = set()
    if match_query:
        # When using fallback (sig_query empty), also match against unfiltered doc name tokens
        use_filtered_doc = bool(sig_query)
        for i, d in enumerate(records):
            if use_filtered_doc:
                doc_tokens = _name_tokens(d)
            else:
                # Fallback (stopword-only query): full path, unfiltered
                _path_parts = d["path"].replace("\\", "/").split("/")
                _raw = " ".join(
                    [d["name"], os.path.splitext(os.path.basename(d["path"]))[0]]
                    + [p.replace("_", " ").replace("-", " ").replace(".", " ") for p in _path_parts if p]
                )
                doc_tokens = {t for t in _tokenize(_raw) if len(t) >= 2}
            if match_query & doc_tokens:
                name_match.add(i)

    # Layer 2: BM25 on description + tags only.
    sem_threshold = max(threshold, 0.6)

    def _sem_text(d: dict) -> str:
        return " ".join([d["description"]] + d["tags"])

    ranked = []
    for i, d in enumerate(records):
        in_name = i in name_match
        sem_score = _bm25(query_tokens, [_tokenize(_sem_text(d))])[0]
        in_sem = sem_score > sem_threshold
        in_boost = d.get("id") in boost_set
        if in_name or in_sem or in_boost:
            if in_boost and not in_sem:
                # Co-occurrence boost: small fixed score, ranked after direct matches
                effective = 0.03
            else:
                effective = sem_score if in_sem else 0.05
            ranked.append((effective, d["use_count"], d))

    ranked.sort(key=lambda x: (-x[0], -x[1]))
    return [d for _, _, d in ranked]
