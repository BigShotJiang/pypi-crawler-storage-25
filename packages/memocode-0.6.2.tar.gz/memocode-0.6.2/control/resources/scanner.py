"""
File change detection and content extraction for the resource registry.
"""
import hashlib
import os
import zipfile
import xml.etree.ElementTree as _ET

# Types that can be meaningfully read and classified
_SUPPORTED_TYPES = {"pdf", "xlsx", "xls", "docx", "doc", "text"}


# ── File type detection (magic bytes) ─────────────────────────────────────────

def detect_file_type(path: str) -> str:
    """
    Detect actual file type from magic bytes, not file extension.
    Returns one of: 'pdf', 'xlsx', 'xls', 'docx', 'doc', 'pptx',
                    'text', 'binary', 'zip', 'unknown'
    """
    try:
        with open(path, "rb") as f:
            header = f.read(8)
    except OSError:
        return "unknown"

    # PDF
    if header[:4] == b"%PDF":
        return "pdf"

    # ZIP-based (Office Open XML: docx, xlsx, pptx)
    if header[:4] == b"PK\x03\x04":
        return _detect_zip_office(path)

    # OLE2 compound file (legacy .doc, .xls)
    if header[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        ext = os.path.splitext(path)[1].lower()
        return "doc" if ext in (".doc", ".dot") else "xls"

    # Try as text: check for null bytes (binary indicator); accept any encoding
    try:
        with open(path, "rb") as f:
            chunk = f.read(8192)
        if b"\x00" not in chunk:
            return "text"
    except OSError:
        pass

    return "binary"


def _detect_zip_office(path: str) -> str:
    """Distinguish docx / xlsx / pptx by inspecting ZIP contents."""
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
        if any(n.startswith("word/") for n in names):
            return "docx"
        if any(n.startswith("xl/") for n in names):
            return "xlsx"
        if any(n.startswith("ppt/") for n in names):
            return "pptx"
        return "zip"
    except Exception:
        return "zip"


# ── Hash / mtime ───────────────────────────────────────────────────────────────

def compute_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def compute_mtime(path: str) -> float:
    return os.path.getmtime(path)


def check_status(path: str, stored_hash: str, stored_mtime: float) -> str:
    """
    Returns: 'unchanged' | 'modified' | 'deleted'
    Uses mtime as fast pre-check; only computes hash if mtime changed.
    """
    if not os.path.isfile(path):
        return "deleted"
    current_mtime = os.path.getmtime(path)
    if current_mtime == stored_mtime:
        return "unchanged"
    if compute_hash(path) == stored_hash:
        return "unchanged"  # content same despite touch
    return "modified"


# ── Content extraction ─────────────────────────────────────────────────────────

def read_file_summary(path: str, max_chars: int = 4000) -> str:
    """
    Read file content for LLM classification.
    Dispatches by detected file type (magic bytes), not extension.
    """
    ftype = detect_file_type(path)

    if ftype == "pdf":
        return _read_pdf(path, max_chars)
    if ftype in ("xlsx", "xls"):
        return _read_excel(path, max_chars)
    if ftype in ("docx", "doc"):
        return _read_docx(path, max_chars)
    if ftype == "text":
        return _read_text(path, max_chars)

    # binary / zip / pptx / unknown — not supported
    return f"[unsupported file type: {ftype}]"


def _read_text(path: str, max_chars: int) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            content = f.read(max_chars)
        return content + ("..." if os.path.getsize(path) > max_chars else "")
    except OSError as e:
        return f"[read error: {e}]"


def _read_pdf(path: str, max_chars: int) -> str:
    # pdfplumber: richer extraction (layout-aware, table-capable).
    # chdir to system temp so any image writes from pdfminer/PIL land there, not cwd.
    try:
        import pdfplumber
        import tempfile
        _cwd = os.getcwd()
        try:
            os.chdir(tempfile.gettempdir())
            with pdfplumber.open(path) as pdf:
                parts = [f"[PDF, {len(pdf.pages)} pages]"]
                for page in pdf.pages[:5]:
                    text = (page.extract_text() or "").strip()
                    if text:
                        parts.append(text)
                    if sum(len(p) for p in parts) >= max_chars:
                        break
        finally:
            os.chdir(_cwd)
        result = "\n".join(parts)
        return result[:max_chars] + ("..." if len(result) > max_chars else "")
    except ImportError:
        pass
    except Exception as e:
        return f"[PDF read error: {e}]"

    # Fallback: pdfminer.six (text-only, no image writes)
    try:
        from pdfminer.high_level import extract_text
        from pdfminer.pdfpage import PDFPage
        with open(path, "rb") as f:
            page_count = sum(1 for _ in PDFPage.get_pages(f))
        text = extract_text(path, maxpages=5) or ""
        result = f"[PDF, {page_count} pages]\n" + text.strip()
        return result[:max_chars] + ("..." if len(result) > max_chars else "")
    except ImportError:
        return "[PDF support requires pdfplumber or pdfminer.six]"
    except Exception as e:
        return f"[PDF read error: {e}]"


def _read_excel(path: str, max_chars: int) -> str:
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        parts = []
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            parts.append(f"[Sheet: {sheet_name}]")
            row_count = 0
            for row in ws.iter_rows(values_only=True):
                cells = [str(c) if c is not None else "" for c in row]
                if any(c.strip() for c in cells):
                    parts.append("\t".join(cells))
                    row_count += 1
                if row_count >= 30 or sum(len(p) for p in parts) >= max_chars:
                    break
            if sum(len(p) for p in parts) >= max_chars:
                break
        wb.close()
        result = "\n".join(parts)
        return result[:max_chars] + ("..." if len(result) > max_chars else "")
    except ImportError:
        return "[openpyxl not installed — install with: pip install openpyxl]"
    except Exception as e:
        return f"[Excel read error: {e}]"


def _read_docx(path: str, max_chars: int) -> str:
    """Extract text from docx/doc using stdlib zipfile + XML (no extra deps)."""
    # Modern .docx (ZIP-based)
    try:
        with zipfile.ZipFile(path) as z:
            if "word/document.xml" not in z.namelist():
                return "[docx: word/document.xml not found]"
            with z.open("word/document.xml") as f:
                tree = _ET.parse(f)
        ns = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
        texts = [
            node.text for node in tree.iter(f"{{{ns}}}t")
            if node.text
        ]
        result = " ".join(texts)
        return result[:max_chars] + ("..." if len(result) > max_chars else "")
    except zipfile.BadZipFile:
        # Legacy .doc (OLE2) — no stdlib parser, fall back to raw text attempt
        return _read_text(path, max_chars)
    except Exception as e:
        return f"[docx read error: {e}]"
