"""
ResourceManager: coordinates DB, scanner, and LLM re-classification.
Instantiated by Brain; tools call into it.
"""
import logging
import os
import re
from collections import defaultdict

from . import db as _db
from .scanner import check_status, compute_hash, compute_mtime, read_file_summary

logger = logging.getLogger("chatmem")


class ResourceManager:
    def __init__(
        self,
        api_key: str = "",
        model: str = "",
        base_url: str | None = None,
        extra_body: dict | None = None,
        provider: str = "openai",
        db_path: str | None = None,
        llm_adapter=None,  # LLMAdapter instance; preferred over raw credentials
    ):
        self._api_key = api_key
        self._model = model
        self._base_url = base_url
        self._extra_body = extra_body
        self._provider = provider
        self._llm_adapter = llm_adapter  # carries SSO token, ssl_verify, retry
        self._db_path = db_path or os.path.expanduser("~/.mcode/resources/index.db")
        self._pending: list[dict] = []         # staged register proposals awaiting resource_confirm
        self._pending_delete: list[dict] = []  # staged delete proposals awaiting resource_confirm
        _db.init_db(self._db_path)

    # ── Public API (called by tools) ───────────────────────────────────────────

    def scan_file(self, path: str) -> str:
        """Read file content for LLM classification. Returns summary text."""
        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.isfile(path):
            raise FileNotFoundError(f"File not found: {path}")
        return read_file_summary(path)

    def register(
        self,
        path: str,
        name: str,
        description: str,
        tags: list[str],
    ) -> dict:
        """Write a resource entry to the DB. Returns the registered record."""
        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.isfile(path):
            raise FileNotFoundError(f"File not found: {path}")
        fhash = compute_hash(path)
        fmtime = compute_mtime(path)
        _db.upsert(path, name, description, tags, fhash, fmtime, self._db_path)
        return {"path": path, "name": name, "tags": tags}

    def find(self, query: str) -> list[dict]:
        """Search resources by keyword, with co-occurrence boosting."""
        results = _db.search(query, self._db_path)
        for r in results:
            _db.record_use(r["path"], self._db_path)
        return results

    def find_by_name(self, name: str) -> list[dict]:
        """Exact/fuzzy name match for @mention resolution. No use_count side-effect."""
        return _db.match_by_name(name, self._db_path)

    def record_access(self, file_ids: list[int]) -> None:
        """Record that these file IDs were referenced together (co-occurrence)."""
        _db.record_cooccurrence(file_ids, self._db_path)

    def find_with_cooccurrence(self, query: str, seed_ids: list[int]) -> list[dict]:
        """
        Search with co-occurrence boosting: files that co-occur with seed_ids
        are promoted even if BM25 score is below threshold.
        """
        boost_ids: list[int] = []
        for fid in seed_ids:
            boost_ids.extend(_db.get_cooccurred(fid, self._db_path))
        return _db.search(query, self._db_path, boost_ids=boost_ids)

    def list_all(self) -> list[dict]:
        return _db.get_all(self._db_path)

    def delete(self, path: str) -> None:
        path = os.path.expanduser(os.path.normpath(path))
        _db.delete(path, self._db_path)

    def edit(self, path: str, name: str | None, description: str | None, tags: list[str] | None) -> dict:
        """Update name/description/tags for an existing resource. None means no change."""
        path = os.path.expanduser(os.path.normpath(path))
        records = _db.get_all(self._db_path)
        rec = next((r for r in records if r["path"] == path), None)
        if rec is None:
            raise KeyError(f"Resource not found: {path}")
        new_name = name if name is not None else rec["name"]
        new_desc = description if description is not None else rec["description"]
        new_tags = tags if tags is not None else rec["tags"]
        fhash = compute_hash(path) if os.path.isfile(path) else rec.get("file_hash", "")
        fmtime = compute_mtime(path) if os.path.isfile(path) else rec.get("file_mtime", 0)
        _db.upsert(path, new_name, new_desc, new_tags, fhash, fmtime, self._db_path)
        return {"path": path, "name": new_name, "description": new_desc, "tags": new_tags}

    def list_dir_files(self, directory: str, recursive: bool = False) -> tuple[list[str], list[str]]:
        """
        Enumerate scannable files in directory without calling LLM.
        Returns (new_files, already_registered_paths, skipped_binary_paths).
        """
        from .scanner import detect_file_type, _SUPPORTED_TYPES

        directory = os.path.abspath(os.path.expanduser(directory))
        registered = {r["path"] for r in _db.get_all(self._db_path)}

        files = []
        if recursive:
            for root, _, fnames in os.walk(directory):
                for fname in sorted(fnames):
                    if not fname.startswith("."):
                        files.append(os.path.join(root, fname))
        else:
            files = [
                os.path.join(directory, f)
                for f in sorted(os.listdir(directory))
                if os.path.isfile(os.path.join(directory, f)) and not f.startswith(".")
            ]

        scannable, skipped = [], []
        for f in files:
            (scannable if detect_file_type(f) in _SUPPORTED_TYPES else skipped).append(f)

        already = [f for f in scannable if f in registered]
        new_files = [f for f in scannable if f not in registered]
        return new_files, already, skipped

    # ── Prefix-based grouping for batch classification ────────────────────────

    @classmethod
    def _prefix_key(cls, path: str) -> str:
        """
        Grouping key: split basename stem on delimiters, drop ordinal/sequential
        tokens (week numbers, sprint numbers, version numbers, pure digits, dates),
        but KEEP discriminative structural tokens like fiscal year (FY27), quarter
        (Q3), half (H1) so that FY26 and FY27 series are not merged.

        Examples:
          FY27_TimeSheet_Aroan_WK1  → timesheet-aroan-fy27
          FY26_TimeSheet_Aroan_WK1  → timesheet-aroan-fy26  (different group)
          weekly-2024-01-15         → weekly
          sprint-42-retro           → sprint-retro
          v1.2.3-changelog          → changelog
          api-design-v2             → api-design

        Files in different directories never group together (parent dir in key).
        """
        stem = os.path.splitext(os.path.basename(path))[0]
        parent = os.path.basename(os.path.dirname(path))
        parts = re.split(r'[-_.]', stem)
        key_parts = [
            p for p in parts
            if p and not re.fullmatch(
                r'v\d+(?:[._]\d+)*'            # version tags: v1, v2.3.1
                r'|\d+(?:[._]\d+)*'            # pure numbers / dotted numbers: 42, 1.2.3
                r'|wk?\d+'                     # week serials: WK1, W2, WK10
                r'|week\d+'                    # week serials: Week3
                r'|sprint\d+'                  # sprint serials: sprint5
                r'|iter\d+'                    # iteration serials: iter4
                r'|\d{4}[-/_]\d{1,2}[-/_]\d{1,2}',  # date strings: 2024-01-15
                p, re.IGNORECASE,
            )
        ]
        key = "-".join(key_parts).lower() if key_parts else stem.lower()
        return f"{parent}/{key}"

    def classify_dir(self, directory: str, recursive: bool = False) -> tuple[list[dict], list[str]]:
        """
        Scan directory, classify new files with internal LLM, store in _pending.
        Files sharing the same name prefix (e.g. weekly-2024-01-*, sprint-42-*)
        are grouped: the first file in each group is fully classified; the rest
        inherit the same description and tags (only the display name differs).
        This avoids redundant LLM calls and keeps similar files consistently tagged.
        Returns (proposals, already_registered_paths).
        """
        new_files, already, _ = self.list_dir_files(directory, recursive)

        # Group by prefix key; preserve scan order within each group
        groups: dict[str, list[str]] = defaultdict(list)
        for path in new_files:
            groups[self._prefix_key(path)].append(path)

        proposals = []
        for key, paths in groups.items():
            # Classify the representative (first / alphabetically first) file
            rep_path = paths[0]
            summary = read_file_summary(rep_path)
            cl = self._classify_file(rep_path, summary)

            for path in paths:
                if path == rep_path:
                    proposals.append({"path": path, **cl})
                else:
                    # Inherit shared description + tags; use individual filename as display name
                    proposals.append({
                        "path": path,
                        "name": os.path.splitext(os.path.basename(path))[0],
                        "description": cl["description"],
                        "tags": cl["tags"],
                    })
            if len(paths) > 1:
                logger.info(
                    "[resources] grouped %d files under prefix '%s', "
                    "classified once (rep: %s)",
                    len(paths), key, os.path.basename(rep_path),
                )

        self._pending = proposals
        return proposals, already

    def stage_delete(self, query: str) -> list[dict]:
        """Match resources by regex/substring against name and path, stage for deletion.
        Pass query='*' or 'all' to stage every registered resource."""
        if query.strip().lower() in ("*", "all"):
            results = _db.get_all(self._db_path)
        else:
            results = _db.match_by_pattern(query, self._db_path)
        self._pending_delete = list(results)
        return results

    def commit_pending(self) -> dict:
        """
        Commit all staged operations (register + delete) and clear staging areas.
        Returns {"registered": [...], "deleted": [...]}.
        """
        registered = []
        for item in self._pending:
            try:
                rec = self.register(
                    path=item["path"],
                    name=item["name"],
                    description=item["description"],
                    tags=item.get("tags", []),
                )
                registered.append(rec)
            except Exception as e:
                logger.warning("[resources] commit failed for %s: %s", item.get("path"), e)
        self._pending = []

        deleted = []
        for item in self._pending_delete:
            try:
                _db.delete(item["path"], self._db_path)
                deleted.append(item)
            except Exception as e:
                logger.warning("[resources] delete failed for %s: %s", item.get("path"), e)
        self._pending_delete = []

        return {"registered": registered, "deleted": deleted}

    def _classify_file(self, path: str, content_summary: str,
                        series_size: int = 1) -> dict:
        """
        Ask internal LLM to classify a single file. Returns dict with name/description/tags.
        series_size > 1: this file is a representative of a series — generate series-level
        description and tags that apply to ALL files, not just this specific instance.
        """
        import json as _json
        default = {
            "name": os.path.basename(path),
            "description": "",
            "tags": [],
        }
        if not self._llm_adapter and (not self._api_key or not self._model):
            return default

        if series_size > 1:
            series_note = (
                f"\nNOTE: This file is a representative of a series of {series_size} similar "
                f"files (e.g. weekly reports, sprint retros). Write a name, description, and "
                f"tags that apply to the ENTIRE SERIES — do NOT mention specific week numbers, "
                f"dates, or instance-specific details. The name should reflect the file type "
                f"(e.g. \"Aroan FY27 Weekly Timesheet\" not \"Aroan FY27 Week 1 Timesheet\").\n"
            )
        else:
            series_note = ""

        prompt = (
            f"File: {os.path.basename(path)}\n"
            f"Content excerpt:\n{content_summary}\n"
            f"{series_note}\n"
            "Classify this file for a personal knowledge resource registry.\n"
            "Output valid JSON only. Fields:\n"
            "  name        — concise display name\n"
            "  description — 1-2 sentences: what the file contains and what tasks it helps with\n"
            "  tags        — 4-8 search keywords; include Chinese + English synonyms and common\n"
            "                abbreviations (e.g. k8s, CI/CD)\n\n"
            "Example for an unrelated file (do NOT copy these values):\n"
            '{"name": "Q3 Sales Report", '
            '"description": "Quarterly revenue breakdown by region for Q3 2024.", '
            '"tags": ["sales", "revenue", "Q3", "quarterly", "财务", "销售"]}\n\n'
            "Now classify the file above. Reply with JSON only, no other text."
        )
        _placeholder_tags = {"tag1", "tag2", "tag3"}
        _placeholder_text = ("short display name", "what this file contains")

        def _try_classify() -> dict | None:
            raw = self._llm(prompt)
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if not m:
                return None
            data = _json.loads(m.group())
            name = data.get("name", default["name"])
            description = data.get("description", "")
            tags = data.get("tags", [])
            if (set(tags) & _placeholder_tags
                    or any(p in name for p in _placeholder_text)
                    or any(p in description for p in _placeholder_text)):
                return None  # placeholder response — retry
            return {"name": name, "description": description, "tags": tags}

        for attempt in range(2):
            try:
                result = _try_classify()
                if result is not None:
                    return result
                logger.warning("[resources] placeholder response for %s (attempt %d)",
                               os.path.basename(path), attempt + 1)
            except Exception as e:
                logger.warning("[resources] classify failed for %s: %s", path, e)
        return default

    # ── Sync (called at startup in background thread) ─────────────────────────

    def sync_one(self, path: str) -> str:
        """Force re-classify a single registered resource. Returns status string."""
        path = os.path.expanduser(os.path.normpath(path))
        records = _db.get_all(self._db_path)
        rec = next((r for r in records if r["path"] == path), None)
        if rec is None:
            raise KeyError(f"Resource not registered: {path}")
        if not os.path.isfile(path):
            _db.delete(path, self._db_path)
            return "deleted"
        summary = read_file_summary(path)
        description, tags = self._reclassify(path, summary, rec["description"], rec["tags"])
        _db.update_content(path, description, tags,
                           compute_hash(path), compute_mtime(path), self._db_path)
        return "updated"

    def sync(self) -> dict:
        """
        Check all registered files for changes or deletion, and scan watched
        directories for new files.
        Deleted → remove from DB.
        Modified → re-read content, LLM updates description/tags.
        New in watched dirs → classify and register automatically.
        Returns summary counts.
        """
        records = _db.get_all(self._db_path)
        removed = updated = added = 0

        for rec in records:
            path = rec["path"]
            status = check_status(path, rec["file_hash"], rec["file_mtime"])

            if status == "deleted":
                _db.delete(path, self._db_path)
                removed += 1
                logger.info("[resources] removed (file deleted): %s", path)

            elif status == "modified":
                try:
                    summary = read_file_summary(path)
                    description, tags = self._reclassify(
                        path, summary, rec["description"], rec["tags"]
                    )
                    _db.update_content(
                        path, description, tags,
                        compute_hash(path), compute_mtime(path),
                        self._db_path,
                    )
                    updated += 1
                    logger.info("[resources] updated (content changed): %s", path)
                except Exception as e:
                    logger.warning("[resources] sync error for %s: %s", path, e)

        # Scan watched directories for new files
        for watch in _db.list_watches(self._db_path):
            dir_path = watch["path"]
            recursive = bool(watch["recursive"])
            if not os.path.isdir(dir_path):
                logger.warning("[resources] watched dir gone: %s", dir_path)
                continue
            new_files, _, _ = self.list_dir_files(dir_path, recursive)
            for path in new_files:
                try:
                    summary = read_file_summary(path)
                    cl = self._classify_file(path, summary)
                    self.register(path, cl["name"], cl["description"], cl.get("tags", []))
                    added += 1
                    logger.info("[resources] auto-registered: %s", path)
                except Exception as e:
                    logger.warning("[resources] auto-register failed for %s: %s", path, e)

        return {"checked": len(records), "removed": removed, "updated": updated, "added": added}

    def watch_dir(self, path: str, recursive: bool = False) -> None:
        path = os.path.expanduser(os.path.normpath(path))
        if not os.path.isdir(path):
            raise NotADirectoryError(f"Not a directory: {path}")
        _db.add_watch(path, recursive, self._db_path)

    def unwatch_dir(self, path: str) -> bool:
        path = os.path.expanduser(os.path.normpath(path))
        return _db.remove_watch(path, self._db_path)

    def list_watches(self) -> list[dict]:
        return _db.list_watches(self._db_path)

    # ── LLM re-classification ─────────────────────────────────────────────────

    def _reclassify(
        self, path: str, content_summary: str,
        old_description: str, old_tags: list[str],
    ) -> tuple[str, list[str]]:
        """
        Ask LLM to update description and tags based on new file content.
        Returns (description, tags).
        Falls back to old values on any error.
        """
        if not self._llm_adapter and (not self._api_key or not self._model):
            return old_description, old_tags

        prompt = (
            f"File: {os.path.basename(path)}\n"
            f"Previous description: {old_description}\n"
            f"Previous tags: {old_tags}\n\n"
            f"New file content (excerpt):\n{content_summary}\n\n"
            "The file content has changed. Update the description and tags to reflect "
            "the current content.\n"
            "tags: include 4-8 keywords covering both Chinese and English synonyms "
            "(e.g. [\"客户\", \"联系方式\", \"contacts\", \"CRM\"]). "
            "For technical content, also include common abbreviations "
            "(e.g. \"kubernetes\" → add \"k8s\", \"continuous integration\" → add \"CI/CD\"). "
            "This enables cross-language and abbreviation search.\n"
            "Reply in this exact format (JSON, no other text):\n"
            '{"description": "...", "tags": ["tag1", "tag2", ...]}'
        )
        try:
            raw = self._llm(prompt)
            import json
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if m:
                data = json.loads(m.group())
                return data.get("description", old_description), data.get("tags", old_tags)
        except Exception:
            pass
        return old_description, old_tags

    def _llm(self, user_content: str) -> str:
        import re as _re
        messages = [{"role": "user", "content": user_content}]
        if self._llm_adapter:
            raw = self._llm_adapter.complete(messages, max_tokens=1500)
        elif self._provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=self._api_key, base_url=self._base_url)
            response = client.messages.create(
                model=self._model, max_tokens=512, messages=messages
            )
            raw = "".join(b.text for b in response.content if b.type == "text")
        else:
            from openai import OpenAI
            client = OpenAI(api_key=self._api_key, base_url=self._base_url)
            kwargs = dict(model=self._model, messages=messages)
            if self._extra_body:
                kwargs["extra_body"] = self._extra_body
            response = client.chat.completions.create(**kwargs)
            raw = response.choices[0].message.content or ""
        return _re.sub(r"<think>.*?</think>", "", raw, flags=_re.DOTALL).strip()
