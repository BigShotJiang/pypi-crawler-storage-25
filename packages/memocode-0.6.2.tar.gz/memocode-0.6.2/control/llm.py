"""
LLM Adapter — unified interface for OpenAI-compatible and Anthropic native APIs.

Config (chatmem.json → llm section):
  provider:         "openai" (default) | "anthropic"
  thinking:         false (default) | true
  thinking_budget:  8000 (default, tokens)

OpenAI-compatible (provider="openai"):
  - Uses openai.OpenAI client
  - Thinking passed via extra_body (provider-specific, e.g. {"thinking": {"type": "enabled"}})
  - Response: choices[0].message.content (always a string)
  - Streaming: choices[0].delta.content chunks

Anthropic native (provider="anthropic"):
  - Uses anthropic.Anthropic client
  - Thinking passed as thinking={"type": "enabled", "budget_tokens": N}
  - Response: content blocks → extract type="text" blocks
  - Streaming: messages.stream() → text_stream
"""
from __future__ import annotations
import json
import random
import sys
import time
from dataclasses import dataclass, field
from typing import Iterator


try:
    import httpx as _httpx

    class _SSOAuth(_httpx.Auth):
        """
        httpx Auth that calls auth_adapter.get_api_key() on every request.
        On 401, forces a token refresh and retries once.
        """
        def __init__(self, auth_adapter):
            self._auth = auth_adapter

        def auth_flow(self, request):
            token = self._auth.get_api_key()
            request.headers["Authorization"] = f"Bearer {token}"
            response = yield request
            if response.status_code == 401:
                # Token expired — force refresh and retry once
                try:
                    token = self._auth.get_api_key(force_refresh=True)
                except TypeError:
                    # adapter doesn't support force_refresh; try plain call
                    token = self._auth.get_api_key()
                request.headers["Authorization"] = f"Bearer {token}"
                yield request

except ImportError:
    _SSOAuth = None  # type: ignore


@dataclass
class ToolCall:
    id: str
    name: str
    args: dict


@dataclass
class LLMResponse:
    text: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    # OpenAI-format assistant message dict for appending to loop_msgs
    assistant_msg: dict | None = None
    finish_reason: str | None = None


class LLMAdapter:
    """
    Drop-in replacement for the raw OpenAI client used by intent / planner /
    reflection / judge / brain._verify.

    Call .complete() for non-streaming and .stream() for streaming.
    Both return plain text strings / text chunks — thinking blocks are
    transparently stripped.
    """

    def __init__(
        self,
        provider: str,
        api_key: str,
        model: str,
        base_url: str | None = None,
        extra_body: dict | None = None,
        thinking: bool = False,
        thinking_budget: int = 8000,
        timeout: int = 60,
        ssl_verify: bool = True,
        auth_adapter=None,  # AIAuthAdapter instance for token auto-refresh
    ):
        self.provider = provider.lower()
        self.model = model
        self.api_key = api_key  # static key or initial token; use auth_adapter for live refresh
        self.auth_adapter = auth_adapter  # kept alive for sharing with resource adapter
        self.extra_body = extra_body or {}
        self.thinking = thinking
        self.thinking_budget = thinking_budget
        self.timeout = timeout

        if self.provider == "anthropic":
            try:
                import anthropic
                self._client = anthropic.Anthropic(api_key=api_key)
            except ImportError:
                raise ImportError(
                    "anthropic package required for provider='anthropic'. "
                    "Run: pip install anthropic"
                )
        else:
            from openai import OpenAI
            import httpx
            # httpx verify=True uses the OS system CA store, not certifi.
            # Explicitly pass certifi.where() so Dell/internal CA certs
            # appended to the certifi bundle are actually trusted.
            import certifi as _certifi
            _verify = _certifi.where() if ssl_verify else False
            if auth_adapter:
                # SSO: use per-request token refresh via custom httpx auth
                http_client = httpx.Client(verify=_verify, auth=_SSOAuth(auth_adapter))
                self._client = OpenAI(api_key="no-key", base_url=base_url, http_client=http_client)
            else:
                http_client = httpx.Client(verify=_verify)
                self._client = OpenAI(api_key=api_key, base_url=base_url, http_client=http_client)

    # ── Retry ─────────────────────────────────────────────────────────────────

    _MAX_RETRIES = 5
    _BASE_DELAY  = 1.0   # seconds
    _MAX_DELAY   = 60.0  # seconds

    def _is_retriable(self, exc: Exception) -> bool:
        """Return True if the exception should trigger a retry."""
        name = type(exc).__name__
        # Both openai and anthropic use same class names for these errors
        if name in ("RateLimitError", "OverloadedError",
                    "APIConnectionError", "APITimeoutError"):
            return True
        if name == "APIStatusError":
            status = getattr(exc, "status_code", 0)
            return status in (429, 500, 502, 503, 529)
        return False

    def _call_with_retry(self, fn, *args, **kwargs):
        """
        Call fn(*args, **kwargs) with exponential backoff + jitter.
        Retries on rate-limit / server / network errors up to _MAX_RETRIES times.
        On 401 AuthenticationError with SSO, forces a token refresh and retries once.
        """
        delay = self._BASE_DELAY
        _sso_refreshed = False
        for attempt in range(self._MAX_RETRIES + 1):
            try:
                return fn(*args, **kwargs)
            except Exception as exc:
                # SSO token expired: force refresh and retry once (no delay needed)
                if (
                    not _sso_refreshed
                    and self.auth_adapter is not None
                    and type(exc).__name__ == "AuthenticationError"
                ):
                    try:
                        self.auth_adapter.get_api_key(force_refresh=True)
                    except Exception:
                        pass
                    _sso_refreshed = True
                    continue
                if attempt == self._MAX_RETRIES or not self._is_retriable(exc):
                    raise
                jitter = random.uniform(0, delay * 0.25)
                wait = min(delay + jitter, self._MAX_DELAY)
                print(
                    f"\r[llm] {type(exc).__name__} — retrying in {wait:.1f}s "
                    f"(attempt {attempt + 1}/{self._MAX_RETRIES}) …",
                    file=sys.stderr,
                )
                time.sleep(wait)
                delay = min(delay * 2, self._MAX_DELAY)

    # ── Public API ────────────────────────────────────────────────────────────

    def complete(
        self,
        messages: list[dict],
        max_tokens: int = 800,
        timeout: int | None = None,
    ) -> str:
        """Non-streaming completion. Returns text only."""
        t = timeout or self.timeout
        if self.provider == "anthropic":
            return self._anthropic_complete(messages, max_tokens)
        return self._openai_complete(messages, max_tokens, t)

    def stream(
        self,
        messages: list[dict],
        max_tokens: int = 2000,
    ) -> Iterator[str]:
        """Streaming completion. Yields text chunks; thinking chunks are skipped."""
        if self.provider == "anthropic":
            yield from self._anthropic_stream(messages, max_tokens)
        else:
            yield from self._openai_stream(messages, max_tokens)

    # ── OpenAI-compatible ─────────────────────────────────────────────────────

    def _openai_complete(self, messages: list[dict], max_tokens: int, timeout: int) -> str:
        kwargs: dict = dict(
            model=self.model,
            messages=messages,
            max_tokens=max_tokens,
            timeout=timeout,
        )
        if self.extra_body:
            kwargs["extra_body"] = self.extra_body
        response = self._call_with_retry(self._client.chat.completions.create, **kwargs)
        content = response.choices[0].message.content or ""
        return content.strip()

    def _openai_stream(self, messages: list[dict], max_tokens: int) -> Iterator[str]:
        kwargs: dict = dict(
            model=self.model,
            messages=messages,
            max_tokens=max_tokens,
            stream=True,
            timeout=self.timeout,
        )
        if self.extra_body:
            kwargs["extra_body"] = self.extra_body
        stream = self._call_with_retry(self._client.chat.completions.create, **kwargs)
        for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    # ── Anthropic native ──────────────────────────────────────────────────────

    def _anthropic_kwargs(self, messages: list[dict], max_tokens: int) -> dict:
        # Convert OpenAI-format messages (tool_calls / role=tool) to Anthropic format
        messages = self._convert_messages_for_anthropic(messages)
        # Anthropic separates system message from the messages list
        system = None
        filtered = []
        for m in messages:
            if m["role"] == "system":
                system = m["content"]
            else:
                filtered.append(m)

        kwargs: dict = dict(
            model=self.model,
            max_tokens=max_tokens,
            messages=filtered,
        )
        if system:
            kwargs["system"] = system
        if self.thinking:
            kwargs["thinking"] = {
                "type": "enabled",
                "budget_tokens": self.thinking_budget,
            }
        return kwargs

    def _anthropic_complete(self, messages: list[dict], max_tokens: int) -> str:
        kwargs = self._anthropic_kwargs(messages, max_tokens)
        response = self._call_with_retry(self._client.messages.create, **kwargs)
        # Extract text blocks only (skip thinking blocks)
        parts = [b.text for b in response.content if b.type == "text"]
        return "".join(parts).strip()

    def _anthropic_stream(self, messages: list[dict], max_tokens: int) -> Iterator[str]:
        kwargs = self._anthropic_kwargs(messages, max_tokens)
        # Use non-streaming with retry, then yield result as a single chunk
        # (Anthropic streaming context manager can't be retried mid-stream)
        response = self._call_with_retry(self._client.messages.create, **kwargs)
        parts = [b.text for b in response.content if b.type == "text"]
        text = "".join(parts)
        if text:
            yield text

    # ── Tool use ──────────────────────────────────────────────────────────────

    def complete_with_tools(
        self,
        messages: list[dict],
        tools: list[dict],          # OpenAI format: [{type,function:{name,description,parameters}}]
        max_tokens: int = 8000,
    ) -> LLMResponse:
        """Non-streaming call with tool use. Returns LLMResponse with text and/or tool_calls."""
        if self.provider == "anthropic":
            return self._anthropic_complete_with_tools(messages, tools, max_tokens)
        return self._openai_complete_with_tools(messages, tools, max_tokens)

    def stream_with_tools(
        self,
        messages: list[dict],
        tools: list[dict],
        max_tokens: int = 8000,
        tool_choice: str = "auto",
    ) -> Iterator[str | LLMResponse]:
        """
        Streaming tool-use call. Yields str text chunks while streaming,
        then yields a final LLMResponse with tool_calls (if any).

        tool_choice: "auto" (model decides) | "required" (must call ≥1 tool)
        """
        if self.provider == "anthropic":
            yield from self._anthropic_stream_with_tools(messages, tools, max_tokens)
        else:
            yield from self._openai_stream_with_tools(messages, tools, max_tokens,
                                                      tool_choice=tool_choice)

    def _openai_stream_with_tools(
        self, messages: list[dict], tools: list[dict], max_tokens: int,
        tool_choice: str = "auto",
    ) -> Iterator[str | LLMResponse]:
        kwargs: dict = dict(
            model=self.model,
            messages=messages,
            tools=tools,
            tool_choice=tool_choice,
            max_tokens=max_tokens,
            stream=True,
            timeout=self.timeout,
        )
        if self.extra_body:
            kwargs["extra_body"] = self.extra_body

        text = ""
        reasoning_content = ""  # DeepSeek reasoning_content (must be passed back)
        tc_acc: dict[int, dict] = {}  # index → {id, name, arguments}
        # reasoning_details: list of reasoning objects (MiniMax reasoning_split=True)
        reasoning_details: list[dict] = []
        finish_reason: str | None = None

        stream = self._call_with_retry(self._client.chat.completions.create, **kwargs)
        for chunk in stream:
            if not chunk.choices:
                # Some providers emit top-level reasoning_details outside choices
                rd = getattr(chunk, "reasoning_details", None)
                if rd:
                    reasoning_details.extend(rd if isinstance(rd, list) else [rd])
                continue
            choice = chunk.choices[0]
            if choice.finish_reason:
                finish_reason = choice.finish_reason
            delta = choice.delta
            if delta.content:
                text += delta.content
                yield delta.content
            # Capture DeepSeek reasoning_content (thinking tokens, must be echoed back)
            rc = getattr(delta, "reasoning_content", None)
            if rc:
                reasoning_content += rc
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    if idx not in tc_acc:
                        tc_acc[idx] = {"id": "", "name": "", "arguments": ""}
                    if tc.id:
                        tc_acc[idx]["id"] = tc.id
                    if tc.function and tc.function.name:
                        tc_acc[idx]["name"] = tc.function.name
                    if tc.function and tc.function.arguments:
                        tc_acc[idx]["arguments"] += tc.function.arguments
            # Capture reasoning_details from delta (MiniMax reasoning_split=True)
            delta_rd = getattr(delta, "reasoning_details", None)
            if delta_rd:
                reasoning_details.extend(
                    delta_rd if isinstance(delta_rd, list) else [delta_rd]
                )

        tool_calls = []
        raw_tcs = []
        for idx in sorted(tc_acc):
            tc = tc_acc[idx]
            try:
                args = json.loads(tc["arguments"])
            except json.JSONDecodeError:
                continue
            tool_calls.append(ToolCall(id=tc["id"], name=tc["name"], args=args))
            raw_tcs.append({
                "id": tc["id"], "type": "function",
                "function": {"name": tc["name"], "arguments": tc["arguments"]},
            })

        # If text is empty but reasoning_details has content, extract it as fallback.
        # MiniMax M2.7 may place the final answer inside reasoning_details instead of delta.content.
        if not text and reasoning_details:
            for rd in reasoning_details:
                rd_text = ""
                if isinstance(rd, dict):
                    rd_text = rd.get("content", "") or rd.get("text", "") or ""
                elif isinstance(rd, str):
                    rd_text = rd
                if rd_text:
                    text += rd_text

        # vLLM streaming bug: tool calls may be lost in stream (e.g. gpt-oss-120b with
        # <|call|> EOS token). Fallback to non-streaming if both text and tool_calls are empty.
        if not tool_calls and not text:
            fallback = self._openai_complete_with_tools(messages, tools, max_tokens)
            yield fallback
            return

        assistant_msg: dict = {"role": "assistant", "content": text or None}
        if raw_tcs:
            assistant_msg["tool_calls"] = raw_tcs
        # Preserve reasoning_content for DeepSeek (must be echoed back in multi-turn)
        if reasoning_content:
            assistant_msg["reasoning_content"] = reasoning_content
        # Preserve reasoning_details for models that require it (e.g. MiniMax M2.7)
        # so the thinking chain is not broken across multi-turn tool use.
        if reasoning_details:
            assistant_msg["reasoning_details"] = reasoning_details
        yield LLMResponse(text=text.strip(), tool_calls=tool_calls, assistant_msg=assistant_msg,
                          finish_reason=finish_reason)

    def _anthropic_stream_with_tools(
        self, messages: list[dict], tools: list[dict], max_tokens: int
    ) -> Iterator[str | LLMResponse]:
        # Fall back to non-streaming for Anthropic (tool streaming is complex)
        response = self._anthropic_complete_with_tools(messages, tools, max_tokens)
        if response.text:
            yield response.text
        yield response

    def _openai_complete_with_tools(
        self, messages: list[dict], tools: list[dict], max_tokens: int
    ) -> LLMResponse:
        kwargs: dict = dict(
            model=self.model,
            messages=messages,
            tools=tools,
            max_tokens=max_tokens,
            timeout=self.timeout,
        )
        if self.extra_body:
            kwargs["extra_body"] = self.extra_body
        response = self._call_with_retry(self._client.chat.completions.create, **kwargs)
        msg = response.choices[0].message
        text = msg.content or ""
        tool_calls = []
        assistant_msg: dict = {"role": "assistant", "content": msg.content}
        assistant_msg: dict = {"role": "assistant", "content": msg.content}
        if msg.tool_calls:
            raw_tcs = []
            for tc in msg.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    import sys
                    print(f"[llm] malformed tool call args skipped: {tc.function.name}({tc.function.arguments[:80]!r})", file=sys.stderr)
                    continue
                tool_calls.append(ToolCall(id=tc.id, name=tc.function.name, args=args))
                raw_tcs.append({
                    "id": tc.id, "type": "function",
                    "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                })
            assistant_msg["tool_calls"] = raw_tcs
        return LLMResponse(text=text, tool_calls=tool_calls, assistant_msg=assistant_msg)

    def _anthropic_complete_with_tools(
        self, messages: list[dict], tools: list[dict], max_tokens: int
    ) -> LLMResponse:
        # Convert tools to Anthropic format
        anthropic_tools = [
            {"name": t["function"]["name"],
             "description": t["function"]["description"],
             "input_schema": t["function"]["parameters"]}
            for t in tools
        ]
        # Convert messages (may contain OpenAI tool_calls / role=tool)
        converted = self._convert_messages_for_anthropic(messages)
        # Extract system
        system = None
        filtered = []
        for m in converted:
            if m.get("role") == "system":
                system = m["content"]
            else:
                filtered.append(m)
        kwargs: dict = dict(
            model=self.model,
            max_tokens=max_tokens,
            messages=filtered,
            tools=anthropic_tools,
        )
        if system:
            kwargs["system"] = system
        if self.thinking:
            kwargs["thinking"] = {"type": "enabled", "budget_tokens": self.thinking_budget}
        response = self._call_with_retry(self._client.messages.create, **kwargs)

        text = ""
        tool_calls = []
        # Also build OpenAI-format assistant_msg for loop_msgs
        raw_tcs = []
        for block in response.content:
            if block.type == "text":
                text += block.text
            elif block.type == "tool_use":
                args = block.input if isinstance(block.input, dict) else {}
                tool_calls.append(ToolCall(id=block.id, name=block.name, args=args))
                raw_tcs.append({
                    "id": block.id, "type": "function",
                    "function": {"name": block.name,
                                 "arguments": json.dumps(args, ensure_ascii=False)},
                })
        assistant_msg: dict = {"role": "assistant", "content": text or None}
        if raw_tcs:
            assistant_msg["tool_calls"] = raw_tcs
        return LLMResponse(text=text.strip(), tool_calls=tool_calls, assistant_msg=assistant_msg)

    def _convert_messages_for_anthropic(self, messages: list[dict]) -> list[dict]:
        """Convert OpenAI-format messages (incl. tool_calls / role=tool) to Anthropic format."""
        result = []
        i = 0
        while i < len(messages):
            msg = messages[i]
            role = msg.get("role")

            if role == "system":
                result.append(msg)
                i += 1

            elif role == "assistant" and msg.get("tool_calls"):
                content = []
                if msg.get("content"):
                    content.append({"type": "text", "text": msg["content"]})
                for tc in msg["tool_calls"]:
                    args = tc["function"]["arguments"]
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except json.JSONDecodeError:
                            args = {}
                    content.append({
                        "type": "tool_use",
                        "id": tc["id"],
                        "name": tc["function"]["name"],
                        "input": args,
                    })
                result.append({"role": "assistant", "content": content})
                i += 1

            elif role == "tool":
                # Collect consecutive tool results → single user message
                tool_results = []
                while i < len(messages) and messages[i].get("role") == "tool":
                    m = messages[i]
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": m["tool_call_id"],
                        "content": m["content"],
                    })
                    i += 1
                result.append({"role": "user", "content": tool_results})

            else:
                result.append(msg)
                i += 1

        return result

    # ── Compatibility shim for chatmem / memory (OpenAI response format) ─────

    @property
    def chat(self):
        """Expose a .chat.completions.create() interface for legacy callers."""
        return _OpenAIShim(self)


class _OpenAIShim:
    """Minimal shim so legacy code calling client.chat.completions.create() still works."""

    def __init__(self, adapter: LLMAdapter):
        self._adapter = adapter
        self.completions = self

    def create(self, messages, stream=False, max_tokens=800, timeout=60, **_):
        if stream:
            return _StreamWrapper(self._adapter.stream(messages, max_tokens=max_tokens))
        text = self._adapter.complete(messages, max_tokens=max_tokens, timeout=timeout)
        return _FakeResponse(text)


class _FakeResponse:
    """Mimics openai.ChatCompletion response shape."""
    def __init__(self, text: str):
        self.choices = [_FakeChoice(text)]


class _FakeChoice:
    def __init__(self, text: str):
        self.message = _FakeMessage(text)
        self.delta = _FakeMessage(text)


class _FakeMessage:
    def __init__(self, text: str):
        self.content = text


class _StreamWrapper:
    """Wraps a text Iterator to look like an openai streaming response."""
    def __init__(self, it: Iterator[str]):
        self._it = it

    def __iter__(self):
        for chunk in self._it:
            yield _FakeStreamChunk(chunk)


class _FakeStreamChunk:
    def __init__(self, text: str):
        self.choices = [_FakeStreamChoice(text)]


class _FakeStreamChoice:
    def __init__(self, text: str):
        self.delta = _FakeMessage(text)


# ── Factory ───────────────────────────────────────────────────────────────────

def make_adapter(cfg, timeout: int = 60) -> LLMAdapter:
    """Create LLMAdapter from a ContextConfig (chatmem config object)."""
    llm = cfg.llm
    provider = getattr(llm, "provider", "openai") or "openai"
    thinking = getattr(llm, "thinking", False) or False
    thinking_budget = getattr(llm, "thinking_budget", 8000) or 8000
    extra_body = getattr(llm, "extra_body", None) or {}
    ssl_verify = getattr(llm, "ssl_verify", True)

    # If using Anthropic provider, clear extra_body (not applicable)
    if provider == "anthropic":
        extra_body = {}

    # Resolve API key / SSO auth adapter
    api_key = llm.resolve_api_key()
    auth_adapter = None
    auth_config = getattr(llm, "auth", None)
    if auth_config:
        try:
            from aia_auth_adapter import AIAuthAdapter
        except ImportError:
            AIAuthAdapter = None  # SSO module not installed — fall back to api_key
        if AIAuthAdapter is not None:
            auth_adapter = AIAuthAdapter.resolve_from_config({
                "base_url": getattr(llm, "base_url", None),
                "ssl_verify": ssl_verify,
                "auth": auth_config,
            })
            # Keep auth_adapter alive for per-request token refresh;
            # get initial token only for validation purposes
            if auth_adapter:
                api_key = auth_adapter.get_api_key()

    return LLMAdapter(
        provider=provider,
        api_key=api_key,
        model=llm.model,
        base_url=getattr(llm, "base_url", None),
        extra_body=extra_body,
        thinking=thinking,
        thinking_budget=thinking_budget,
        timeout=timeout,
        ssl_verify=ssl_verify,
        auth_adapter=auth_adapter,
    )
