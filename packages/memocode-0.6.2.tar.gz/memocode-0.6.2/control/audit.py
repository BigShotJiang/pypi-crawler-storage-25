"""
Audit log: persists every agent run to SQLite for traceability and rollback.
"""
from __future__ import annotations
import json
import os
import sqlite3
import time


class AuditLog:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_runs (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts         REAL    NOT NULL,
                    project    TEXT    NOT NULL DEFAULT '',
                    user_input TEXT    NOT NULL,
                    goal       TEXT    NOT NULL,
                    tasks      TEXT    NOT NULL,
                    success    INTEGER NOT NULL,
                    log        TEXT    NOT NULL,
                    backups    TEXT    NOT NULL DEFAULT '{}',
                    turn_idx   INTEGER NOT NULL DEFAULT -1
                )
            """)
            # Migrate: add columns if missing (existing DBs)
            for col_sql in [
                "ALTER TABLE audit_runs ADD COLUMN project TEXT NOT NULL DEFAULT ''",
                "ALTER TABLE audit_runs ADD COLUMN turn_idx INTEGER NOT NULL DEFAULT -1",
            ]:
                try:
                    conn.execute(col_sql)
                except Exception:
                    pass

    def record(
        self,
        user_input: str,
        goal: str,
        tasks: list,
        success: bool,
        log: list[dict],
        project: str = "",
        turn_idx: int = -1,
    ):
        """Write one completed run to the audit log."""
        backups: dict[str, str] = {}
        for entry in log:
            backups.update(entry.get("backups", {}))

        tasks_data = [
            {"id": t.id, "tool": t.tool, "args": t.args, "description": t.description}
            for t in tasks
        ]
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO audit_runs (ts, project, user_input, goal, tasks, success, log, backups, turn_idx) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    time.time(),
                    project,
                    user_input,
                    goal,
                    json.dumps(tasks_data, ensure_ascii=False),
                    1 if success else 0,
                    json.dumps(log, ensure_ascii=False),
                    json.dumps(backups, ensure_ascii=False),
                    turn_idx,
                ),
            )

    def recent(self, limit: int = 20, project: str | None = None) -> list[dict]:
        """Return most recent runs, newest first. Optionally filter by project."""
        with self._conn() as conn:
            if project is not None:
                rows = conn.execute(
                    "SELECT * FROM audit_runs WHERE project = ? ORDER BY ts DESC LIMIT ?",
                    (project, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM audit_runs ORDER BY ts DESC LIMIT ?", (limit,)
                ).fetchall()
        return [dict(r) for r in rows]

    def runs_with_backups(self, project: str | None = None) -> list[dict]:
        """Return all runs that have backup files available, optionally filtered by project."""
        runs = self.recent(9999, project=project)
        result = []
        for run in runs:
            backups = json.loads(run["backups"])
            available = {
                orig: bp for orig, bp in backups.items()
                if bp == "__NEW__" or os.path.exists(bp)
            }
            if available:
                run["available_backups"] = available
                result.append(run)
        return result

    def delete_runs_after_turn(self, turn_idx: int, project: str | None = None) -> list[str]:
        """
        Delete audit runs with turn_idx > turn_idx and remove their backup files from disk.
        Returns list of backup file paths that were deleted.
        """
        with self._conn() as conn:
            if project is not None:
                rows = conn.execute(
                    "SELECT id, backups FROM audit_runs WHERE project = ? AND turn_idx > ?",
                    (project, turn_idx),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT id, backups FROM audit_runs WHERE turn_idx > ?", (turn_idx,)
                ).fetchall()

        deleted_files = []
        run_ids = []
        for row in rows:
            run_ids.append(row["id"])
            backups = json.loads(row["backups"])
            for bp in backups.values():
                if os.path.exists(bp):
                    try:
                        os.remove(bp)
                        deleted_files.append(bp)
                    except OSError:
                        pass

        if run_ids:
            with self._conn() as conn:
                conn.execute(
                    f"DELETE FROM audit_runs WHERE id IN ({','.join('?' * len(run_ids))})",
                    run_ids,
                )
        return deleted_files
