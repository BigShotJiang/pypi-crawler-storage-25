"""
ChatMem configuration.
Supports any OpenAI-compatible API (OpenAI, DeepSeek, local models, etc.).

Usage:
    # Programmatic
    config = ContextConfig(
        llm=LLMConfig(model="gpt-4o-mini"),
        dimensions={
            "interaction_style": DimensionConfig(label="Interaction Style", stability=30.0),
            "delegation":        DimensionConfig(label="Delegation",        stability=35.0),
        },
    )

    # From JSON file
    config = ContextConfig.from_json("my_config.json")

    cm = ContextManager.create(api_key=..., config=config)

JSON config example:
    {
        "llm": {
            "model": "gpt-4o-mini",
            "base_url": null,
            "context_window": 128000,
            "compress_model": null,
            "extra_body": null
        },
        "dimensions": {
            "interaction_style": {"label": "Interaction Style", "stability": 30.0},
            "delegation":        {"label": "Delegation",        "stability": 35.0}
        }
    }
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field


@dataclass
class LLMConfig:
    """LLM provider settings. Works with any OpenAI-compatible API."""
    model: str = "gpt-4o-mini"
    provider: str = "openai"             # "openai" (default) | "anthropic"
    base_url: str | None = None          # None = use provider default (OpenAI)
    context_window: int = 128_000
    compress_model: str | None = None    # model for compression calls; defaults to model
    extra_body: dict | None = None       # provider-specific params, e.g. {"thinking": {"type": "disabled"}}
    excluded_params: list | None = None  # params to drop from proxy requests, e.g. ["temperature"]
    api_key: str | None = None           # API key (use api_key_env for production)
    api_key_env: str | None = None       # env var name to read API key from, e.g. "OPENAI_API_KEY"
    thinking: bool = False               # enable thinking/reasoning mode
    thinking_budget: int = 8000          # max tokens for thinking (Anthropic extended thinking)
    ssl_verify: bool = True              # set False to skip SSL cert verification (corporate proxies)
    auth: dict | None = None             # SSO auth config: {"mode": "sso"|"client_credentials"|"local_sso", ...}

    def resolve_api_key(self) -> str | None:
        """Return api_key, falling back to the env var named by api_key_env."""
        import os
        if self.api_key:
            return self.api_key
        if self.api_key_env:
            return os.environ.get(self.api_key_env)
        return None


@dataclass
class DimensionConfig:
    label: str        # human-readable label (shown in context injection)
    stability: float  # decay half-life in days; higher = more persistent


DEFAULT_DIMENSIONS: dict[str, DimensionConfig] = {
    "interaction_style": DimensionConfig(label="Interaction Style", stability=30.0),
    "delegation":        DimensionConfig(label="Delegation",        stability=35.0),
}


@dataclass
class ContextConfig:
    dimensions: dict[str, DimensionConfig] = field(
        default_factory=lambda: dict(DEFAULT_DIMENSIONS)
    )
    llm: LLMConfig = field(default_factory=LLMConfig)
    compression_mode: str = "auto"  # "auto" | "code" | "plan"

    @classmethod
    def from_dict(cls, data: dict) -> ContextConfig:
        dims = {
            k: DimensionConfig(label=v["label"], stability=float(v["stability"]))
            for k, v in data.get("dimensions", {}).items()
        } or dict(DEFAULT_DIMENSIONS)

        llm_data = data.get("llm", {})
        llm = LLMConfig(
            model=llm_data.get("model", "gpt-4o-mini"),
            provider=llm_data.get("provider", "openai"),
            base_url=llm_data.get("base_url"),
            context_window=int(llm_data.get("context_window", 128_000)),
            compress_model=llm_data.get("compress_model"),
            extra_body=llm_data.get("extra_body"),
            excluded_params=llm_data.get("excluded_params"),
            api_key=llm_data.get("api_key"),
            api_key_env=llm_data.get("api_key_env"),
            thinking=bool(llm_data.get("thinking", False)),
            thinking_budget=int(llm_data.get("thinking_budget", 8000)),
            ssl_verify=llm_data.get("ssl_verify", True),
            auth=llm_data.get("auth"),
        )
        compression_mode = data.get("compression_mode", "code")
        return cls(dimensions=dims, llm=llm, compression_mode=compression_mode)

    @classmethod
    def from_json(cls, path: str | None = None) -> "ContextConfig":
        """
        Load config from a JSON file.
        If path is omitted, auto-discovers in this order:
          1. $CHATMEM_CONFIG env var
          2. ./chatmem.json
          3. ~/.chatmem/config.json
        Raises FileNotFoundError if no config is found.
        """
        import os
        from pathlib import Path

        if path is None:
            candidates = [
                os.environ.get("CHATMEM_CONFIG"),
                "chatmem.json",
                str(Path.home() / ".chatmem" / "config.json"),
            ]
            for c in candidates:
                if c and Path(c).exists():
                    path = c
                    break
            else:
                raise FileNotFoundError(
                    "No chatmem config found. Run `chatmem init` to create one, "
                    "or pass an explicit path to from_json()."
                )

        with open(path, encoding="utf-8") as f:
            return cls.from_dict(json.load(f))

    def to_dict(self) -> dict:
        llm_dict: dict = {"model": self.llm.model, "context_window": self.llm.context_window}
        if self.llm.base_url:
            llm_dict["base_url"] = self.llm.base_url
        if self.llm.compress_model:
            llm_dict["compress_model"] = self.llm.compress_model
        if self.llm.extra_body:
            llm_dict["extra_body"] = self.llm.extra_body

        return {
            "llm": llm_dict,
            "compression_mode": self.compression_mode,
            "dimensions": {
                k: {"label": v.label, "stability": v.stability}
                for k, v in self.dimensions.items()
            },
        }

    def to_json(self, path: str):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)
