"""
Recent memory: compressed summaries from past sessions.
Entries accumulate and decay over time via Ebbinghaus mechanism.
Active memory_search hits reset decay timer (extend entry lifetime).
Stale entries are second-compressed (level-2) before being removed.
Pinned entries bypass decay entirely.
"""

import math
import re
import sqlite3
import time
from datetime import datetime

from ..token_counter import count_tokens
from ..compressor import Compressor


_CJK_BOUNDARY_RE = re.compile(
    r'(?<=[a-z0-9])(?=[\u4e00-\u9fff])|(?<=[\u4e00-\u9fff])(?=[a-z0-9])'
)


def _tokenize(text: str) -> list[str]:
    """Tokenize for BM25: CJK bigrams + word tokens for Latin/mixed.
    Splits at Latin/CJK script boundaries so 'redis缓存' → ['redis', '缓存'].
    """
    text = text.lower()
    tokens: list[str] = []
    for i in range(len(text) - 1):
        if '\u4e00' <= text[i] <= '\u9fff' or '\u4e00' <= text[i + 1] <= '\u9fff':
            tokens.append(text[i:i + 2])
    split_text = _CJK_BOUNDARY_RE.sub(' ', text)
    tokens.extend(w for w in re.split(r'[^\w]+', split_text) if len(w) > 1)
    return tokens


def _bm25(query_tokens: list[str], docs: list[list[str]], k1: float = 1.5, b: float = 0.75) -> list[float]:
    """Return BM25 score for each document."""
    N = len(docs)
    if not N:
        return []
    avg_dl = sum(len(d) for d in docs) / N or 1.0
    df: dict[str, int] = {}
    for doc in docs:
        for t in set(doc):
            df[t] = df.get(t, 0) + 1
    scores: list[float] = []
    for doc in docs:
        dl = len(doc)
        tf: dict[str, int] = {}
        for t in doc:
            tf[t] = tf.get(t, 0) + 1
        score = 0.0
        for qt in query_tokens:
            n = df.get(qt, 0)
            if not n:
                continue
            idf = math.log((N - n + 0.5) / (n + 0.5) + 1)
            f = tf.get(qt, 0)
            score += idf * f * (k1 + 1) / (f + k1 * (1 - b + b * dl / avg_dl))
        scores.append(score)
    return scores


def _compute_score(created_at: float, stability: float, last_accessed_at: float | None = None) -> float:
    now = time.time()
    ref = last_accessed_at if last_accessed_at else created_at
    days = (now - ref) / 86400.0
    return min(math.exp(-days / stability), 1.0)


class RecentMemory:
    """
    Stores LLM-compressed session summaries with Ebbinghaus decay.

    Lifecycle:
      add()                → level-1 entry (stability=21d, score=1.0)
      search() hit         → last_accessed_at reset → decay timer extended
      run_decay()          → recompute scores from time elapsed
      consolidate_stale()  → low-score entries → project judge → level-2 summary
      level-2 entries      → stability=90d, decay eventually triggers deletion
    """

    INJECT_TOKEN_CAP = 4000
    LEVEL1_STABILITY = 21.0   # days
    LEVEL2_STABILITY = 90.0   # days
    DECAY_THRESHOLD  = 0.3    # score below this → consolidation candidate
    MIN_BATCH        = 3      # minimum entries needed to trigger second compression

    def __init__(
        self,
        db_path: str,
        compressor: Compressor,
        inject_token_cap: int | None = None,
        token_budget: int | None = None,  # ignored, kept for API compatibility
    ):
        self.db_path = db_path
        self.compressor = compressor
        self._inject_token_cap = inject_token_cap or self.INJECT_TOKEN_CAP
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS recent_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    turn_id INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    original_content TEXT,
                    compression_level INTEGER DEFAULT 1,
                    token_count INTEGER NOT NULL,
                    created_at REAL NOT NULL,
                    score REAL DEFAULT 1.0,
                    stability REAL DEFAULT 21.0,
                    search_hit_count INTEGER DEFAULT 0,
                    pinned INTEGER DEFAULT 0,
                    last_accessed_at REAL
                )
            """)
            for col, defn in [
                ("original_content",  "TEXT"),
                ("compression_level", "INTEGER DEFAULT 1"),
                ("score",             "REAL DEFAULT 1.0"),
                ("stability",         "REAL DEFAULT 21.0"),
                ("search_hit_count",  "INTEGER DEFAULT 0"),
                ("pinned",            "INTEGER DEFAULT 0"),
                ("last_accessed_at",  "REAL"),
            ]:
                try:
                    conn.execute(f"ALTER TABLE recent_memory ADD COLUMN {col} {defn}")
                except Exception:
                    pass
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_turn ON recent_memory(turn_id)"
            )

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def add(self, turn_id: int, compressed_content: str, original_content: str | None = None,
            compression_level: int = 1):
        """Add a compressed session summary."""
        tokens = count_tokens(compressed_content)
        stability = self.LEVEL1_STABILITY if compression_level == 1 else self.LEVEL2_STABILITY
        now = time.time()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO recent_memory
                   (turn_id, content, original_content, compression_level, token_count,
                    created_at, score, stability, search_hit_count, pinned)
                   VALUES (?, ?, ?, ?, ?, ?, 1.0, ?, 0, 0)""",
                (turn_id, compressed_content, original_content, compression_level, tokens, now, stability),
            )

    def pin(self, entry_id: int, pinned: bool = True):
        """Pin or unpin an entry. Pinned entries are excluded from decay and consolidation."""
        with self._conn() as conn:
            conn.execute(
                "UPDATE recent_memory SET pinned = ? WHERE id = ?",
                (1 if pinned else 0, entry_id),
            )

    # ------------------------------------------------------------------
    # Read / inject
    # ------------------------------------------------------------------

    def get_entries_for_context(self) -> list[str]:
        """Return individual recent memory entries, newest-first, up to INJECT_TOKEN_CAP."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content, created_at FROM recent_memory ORDER BY created_at DESC"
            ).fetchall()
        kept = []
        budget = self._inject_token_cap
        for r in rows:
            tok = count_tokens(r["content"])
            if tok <= budget:
                date_str = datetime.fromtimestamp(r["created_at"]).strftime("%Y-%m-%d %H:%M")
                kept.append(f"[{date_str}]\n{r['content']}")
                budget -= tok
            if budget <= 0:
                break
        return list(reversed(kept))

    def get_for_context(self) -> str:
        """
        Return recent memory content for context injection, newest-first up to INJECT_TOKEN_CAP.
        Newest sessions are most relevant, so we prioritise them within the token budget.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content, created_at FROM recent_memory ORDER BY created_at DESC"
            ).fetchall()
        if not rows:
            return ""
        kept = []
        budget = self._inject_token_cap
        for r in rows:
            tok = count_tokens(r["content"])
            if tok <= budget:
                date_str = datetime.fromtimestamp(r["created_at"]).strftime("%Y-%m-%d %H:%M")
                kept.append(f"[{date_str}]\n{r['content']}")
                budget -= tok
            if budget <= 0:
                break
        return "\n".join(reversed(kept))

    def search(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.0,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[str]:
        """
        Search recent memory for entries relevant to the query.
        Active search hits reset last_accessed_at → extend entry lifetime.
        """
        ts_start: float | None = None
        ts_end: float | None = None
        if start_date:
            try:
                dt = datetime.strptime(start_date, "%Y-%m-%d")
                ts_start = dt.replace(hour=0, minute=0, second=0).timestamp()
            except ValueError:
                pass
        if end_date:
            try:
                dt = datetime.strptime(end_date, "%Y-%m-%d")
                ts_end = dt.replace(hour=23, minute=59, second=59).timestamp()
            except ValueError:
                pass

        with self._conn() as conn:
            rows = conn.execute(
                "SELECT id, content, turn_id, created_at FROM recent_memory ORDER BY created_at DESC"
            ).fetchall()
        if not rows:
            return []

        if ts_start is not None or ts_end is not None:
            rows = [
                r for r in rows
                if (ts_start is None or r["created_at"] >= ts_start)
                and (ts_end is None or r["created_at"] <= ts_end)
            ]
        if not rows:
            return []

        if not query.strip():
            results = []
            for row in rows[:top_k]:
                date_str = datetime.fromtimestamp(row["created_at"]).strftime("%Y-%m-%d %H:%M")
                results.append(f"[{date_str}]\n{row['content']}")
            return results

        query_tokens = _tokenize(query)
        if not query_tokens:
            return []

        doc_tokens = [_tokenize(row["content"]) for row in rows]
        bm25_scores = _bm25(query_tokens, doc_tokens)

        scored = [
            (s, row["turn_id"], row["created_at"], row["content"], row["id"])
            for s, row in zip(bm25_scores, rows)
            if s > 0
        ]
        scored.sort(key=lambda x: (-x[0], -x[1]))
        results = []
        hit_ids = []
        for score, _, created_at, content, entry_id in scored[:top_k]:
            if score >= min_score:
                date_str = datetime.fromtimestamp(created_at).strftime("%Y-%m-%d %H:%M")
                results.append(f"[{date_str}]\n{content}")
                hit_ids.append(entry_id)

        # Reset decay timer for entries that were actively searched
        if hit_ids:
            now = time.time()
            with self._conn() as conn:
                conn.executemany(
                    "UPDATE recent_memory SET last_accessed_at = ?, "
                    "search_hit_count = search_hit_count + 1, score = 1.0 WHERE id = ?",
                    [(now, eid) for eid in hit_ids],
                )

        return results

    def get_recent_entries(self, limit: int = 20) -> list[str]:
        """Return the most recent N entries in chronological order. Used by consolidation."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content FROM recent_memory ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [r["content"] for r in reversed(rows)]

    # ------------------------------------------------------------------
    # Decay
    # ------------------------------------------------------------------

    def get_all_with_scores(self) -> list[dict]:
        """Return all entries with full metadata. Used by ForgettingManager."""
        with self._conn() as conn:
            rows = conn.execute("SELECT * FROM recent_memory").fetchall()
        return [dict(r) for r in rows]

    def update_score(self, entry_id: int, new_score: float):
        with self._conn() as conn:
            conn.execute(
                "UPDATE recent_memory SET score = ? WHERE id = ?",
                (new_score, entry_id),
            )

    def get_stale_candidates(self, threshold: float = DECAY_THRESHOLD) -> list[dict]:
        """Return non-pinned entries whose decay score is below threshold."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM recent_memory WHERE pinned = 0 AND score < ? ORDER BY created_at ASC",
                (threshold,),
            ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Consolidation (second compression + project judge)
    # ------------------------------------------------------------------

    def consolidate_stale(
        self,
        project_judge_fn=None,
        threshold: float = DECAY_THRESHOLD,
        min_batch: int = MIN_BATCH,
    ) -> int:
        """
        Second compression pass for stale entries.

        Level-1 batch (≥ min_batch):
          1. Run project_judge_fn (extract decisions to project memory)
          2. LLM re-compress → level-2 summary entry
          3. Delete originals

        Level-2 stale entries:
          1. Run project_judge_fn (final extraction)
          2. Delete

        Returns number of entries removed.
        """
        import logging
        logger = logging.getLogger("chatmem")

        candidates = self.get_stale_candidates(threshold)
        if not candidates:
            return 0

        level1 = [c for c in candidates if c.get("compression_level", 1) == 1]
        level2 = [c for c in candidates if c.get("compression_level", 1) >= 2]

        removed = 0

        # Level-1 → level-2
        if len(level1) >= min_batch:
            combined = "\n\n---\n\n".join(c["content"] for c in level1)

            if project_judge_fn:
                try:
                    project_judge_fn(combined)
                    logger.info("[recent] project judge ran on %d stale level-1 entries", len(level1))
                except Exception as e:
                    logger.warning("[recent] project judge error: %s", e)

            try:
                summary = self.compressor.compress_for_session_context(combined, mode="plan")
            except Exception as e:
                logger.warning("[recent] second compression failed: %s", e)
                return removed

            max_turn_id = max(c["turn_id"] for c in level1)
            for c in level1:
                self.remove(c["id"])
            self.add(max_turn_id, summary, compression_level=2)
            removed += len(level1)
            logger.info("[recent] consolidated %d level-1 → 1 level-2 entry", len(level1))

        # Level-2 → delete (with final project judge pass)
        if level2:
            combined2 = "\n\n---\n\n".join(c["content"] for c in level2)
            if project_judge_fn:
                try:
                    project_judge_fn(combined2)
                    logger.info("[recent] project judge ran on %d stale level-2 entries", len(level2))
                except Exception as e:
                    logger.warning("[recent] project judge error (level-2): %s", e)
            for c in level2:
                self.remove(c["id"])
            removed += len(level2)
            logger.info("[recent] deleted %d expired level-2 entries", len(level2))

        return removed

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def remove(self, entry_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM recent_memory WHERE id = ?", (entry_id,))

    def clear(self) -> int:
        """Delete all entries from recent_memory. Returns number of deleted rows."""
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM recent_memory")
        return cur.rowcount
