"""Command handler: /tasks"""
from control.brain import Brain


def cmd_tasks(brain: Brain, args: str = ""):
    """Manage tasks directly without going through the LLM."""
    tasks = getattr(brain, "tasks", None)
    if not tasks:
        print("  Task store not available.")
        return
    parts = args.split(None, 1)
    sub = parts[0].lower() if parts else ""
    rest = parts[1].strip() if len(parts) > 1 else ""

    if sub == "done" and rest.isdigit():
        t = tasks.done(int(rest))
        print(f"  Marked done: #{rest} {t['title'] if t else '(not found)'}")
    elif sub == "cancel" and rest.isdigit():
        t = tasks.cancel(int(rest))
        print(f"  Cancelled: #{rest} {t['title'] if t else '(not found)'}")
    elif sub == "del" and rest.isdigit():
        all_tasks = tasks._load()
        before = len(all_tasks)
        all_tasks = [t for t in all_tasks if t["id"] != int(rest)]
        tasks._save(all_tasks)
        if len(all_tasks) < before:
            print(f"  Deleted task #{rest}.")
        else:
            print(f"  Task #{rest} not found.")
    else:
        all_tasks = tasks.list()
        if not all_tasks:
            print("  (no tasks)")
            return
        for t in all_tasks:
            desc = f"  {t['description'][:60]}" if t.get("description") else ""
            print(f"  #{t['id']} [{t['status']}]  {t['title']}{desc}")
        print(f"\n  Usage: /tasks done <id> | /tasks cancel <id> | /tasks del <id>")
