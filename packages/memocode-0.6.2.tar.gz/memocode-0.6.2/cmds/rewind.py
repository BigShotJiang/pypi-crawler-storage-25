"""Command handlers: /rewind, /context, and related helpers."""
import json
import os
import re
import sys

from control.brain import Brain
from control.fmt import p_dim, p_ok
from cmds._utils import _ask


def _show_recent_turns(brain: Brain, n: int = 3):
    """Print a brief summary of the last N sessions from recent memory."""
    try:
        entries = brain.memory.recent_memory.get_recent_entries(limit=n)
    except Exception:
        entries = []
    if not entries:
        return
    p_dim("  [conversation history]")
    for entry in entries:
        text = entry.strip()
        m = re.search(r'\bassistant\s*:', text, re.IGNORECASE)
        if m:
            user_part = text[:m.start()].strip()
            asst_part = text[m.end():].strip()
            user_part = re.sub(r'^\s*user\s*:\s*', '', user_part, flags=re.IGNORECASE)
            u = user_part.replace("\n", " ")[:80]
            a = asst_part.replace("\n", " ")[:80]
            p_dim(f"  You:   {u}")
            p_dim(f"  Agent: {a}")
        else:
            p_dim(f"  {text.replace(chr(10), ' ')[:120]}")
        p_dim("  ─" * 20)


def _restore_files(files: dict):
    """Restore backed-up files; delete files created after target turn (__NEW__ sentinel)."""
    from safety.backup import restore_backup
    for orig, bp in files.items():
        if bp == "__NEW__":
            if os.path.isfile(orig):
                os.remove(orig)
                print(f"  Deleted (new file): {orig}")
            else:
                print(f"  Already gone: {orig}")
        else:
            print(f"  {'Restored' if restore_backup(bp) else 'Failed'}: {orig}")


def _rewind_clear_project(brain: Brain):
    """Optionally clear project memory and tasks after rewinding to turn 0."""
    ans = _ask("Also clear project memory and tasks? [y/N]: ").strip().lower()
    if ans == "y":
        n_recent = brain.memory.recent_memory.clear()
        pm = getattr(brain, "project_memory", None)
        n_facts = pm.clear() if pm else 0
        tasks = getattr(brain, "tasks", None)
        if tasks:
            all_tasks = tasks.list()
            for t in all_tasks:
                tasks.cancel(t["id"])
            n_tasks = len(all_tasks)
        else:
            n_tasks = 0
        print(f"Cleared: {n_recent} session summary(s), {n_facts} project fact(s), {n_tasks} task(s).")


def _do_rewind(brain: Brain, idx: int):
    """Rewind conversation to turn idx and handle side effects."""
    try:
        brain.memory.rewind_to(idx)
    except IndexError as e:
        print(f"Error: {e}")
        return
    if idx == 0:
        print("Conversation cleared.")
        _rewind_clear_project(brain)
    else:
        remaining = brain.memory.list_turns()
        print(f"Rewound to turn [{idx}]. Session now has {len(remaining)} turn(s).")


def cmd_show_context(brain: Brain, arg: str = ""):
    """Export the full current context to a file or print to stdout."""
    from datetime import datetime

    out_path = arg.strip() or ""

    lines: list[str] = []
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines.append(f"# mcode context snapshot — {now}\n")

    # 1. Core memory
    lines.append("## Core Memory")
    cm = brain.memory.core_memory
    entries = cm.get_all()
    if entries:
        for e in entries:
            lines.append(f"  [{e.get('dim', '')}] {e.get('key', '')}: {e.get('value', '')}")
    else:
        lines.append("  (empty)")
    lines.append("")

    # 2. Project memory
    lines.append("## Project Memory")
    pm = brain.project_memory
    if pm:
        s = pm.to_context_string().strip()
        lines.append(s if s else "  (empty)")
    else:
        lines.append("  (none)")
    lines.append("")

    # 3. Recent memory (injected sessions)
    lines.append("## Recent Memory (injected sessions)")
    rm_entries = brain.memory.recent_memory.get_entries_for_context()
    if rm_entries:
        for entry in rm_entries:
            lines.append(entry)
            lines.append("---")
    else:
        lines.append("  (empty)")
    lines.append("")

    # 4. Current session history
    lines.append("## Current Session History")
    history = brain.memory._history
    if history:
        turn = 0
        i = 0
        while i < len(history):
            msg = history[i]
            if msg.get("_is_summary"):
                lines.append(f"[compressed summary]\n{msg.get('content', '')}")
                i += 1
                continue
            role = msg.get("role", "")
            if role == "user":
                turn += 1
                content = msg.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"
                    )
                lines.append(f"[Turn {turn}] User: {content}")
            elif role == "assistant":
                content = msg.get("content", "")
                if isinstance(content, list):
                    parts = []
                    for p in content:
                        if not isinstance(p, dict):
                            continue
                        t = p.get("type", "")
                        if t == "text":
                            parts.append(p.get("text", ""))
                        elif t == "tool_use":
                            parts.append(f"[tool: {p.get('name', '?')}({p.get('input', {})})]")
                        elif t == "thinking":
                            pass  # skip internal thinking blocks
                    content = " ".join(parts)
                if content:
                    lines.append(f"[Turn {turn}] Assistant: {content}")
            i += 1
    else:
        lines.append("  (empty)")
    lines.append("")

    output = "\n".join(lines)

    if out_path:
        try:
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(output)
            p_ok(f"  Context exported to {out_path}  ({len(output):,} chars)")
        except OSError as e:
            print(f"  Error writing file: {e}")
    else:
        print(output)


def cmd_rewind(brain: Brain, arg: str = ""):
    """Rewind the session: pick a turn, then clear conversation and/or restore files."""
    has_wd = brain.projects.has_work_dir
    turns = brain.memory.list_turns()
    runs = brain.audit.runs_with_backups(project=brain.projects.current_project) if has_wd else []

    turn_files: dict[int, dict[str, str]] = {}
    for run in runs:
        tidx = run.get("turn_idx", -1)
        if tidx >= 0:
            turn_files.setdefault(tidx, {}).update(run["available_backups"])
    all_files: dict[str, str] = {}
    for run in reversed(runs):
        all_files.update(run["available_backups"])

    # /rewind N — direct rewind
    if arg.isdigit():
        target = int(arg)
        if has_wd:
            target_files = all_files if target == 0 else turn_files.get(target, {})
            if target_files:
                _restore_files(target_files)
            deleted = brain.audit.delete_runs_after_turn(
                target, project=brain.projects.current_project
            )
            if deleted:
                print(f"  Cleaned up {len(deleted)} backup file(s) from after turn [{target}].")
        _do_rewind(brain, target)
        return

    if not turns and not runs:
        print("Nothing to rewind (no conversation turns, no file backups).")
        return

    max_turn = turns[-1]["index"] if turns else 0
    print(f"\nCurrent session turns:")
    file_note = f"  ({len(all_files)} backed-up file(s))" if all_files else ""
    print(f"  [0] Clear entire session{file_note}")
    for t in turns:
        tidx = t["index"]
        files = turn_files.get(tidx, {})
        file_tag = "  [file]" if files else ""
        print(f"  [{tidx}] {t['user'].replace(chr(10), ' ')[:65]}{file_tag}")
        for f in files:
            print(f"       {f}")

    choice = _ask(f"\nSelect turn to rewind to [0–{max_turn}] (or Enter to cancel): ")
    if not choice.isdigit():
        print("Cancelled.")
        return

    target = int(choice)
    if target > max_turn:
        print(f"Invalid turn (max {max_turn}).")
        return

    target_files = all_files if target == 0 else turn_files.get(target, {})
    has_conv = bool(turns)
    has_files = bool(target_files)

    if not has_wd:
        if has_conv:
            _do_rewind(brain, target)
            print("Done.")
        else:
            print("Nothing to rewind.")
        return

    print("\nWhat to clear?")
    if has_conv and has_files:
        print("  [1] Conversation + files")
        print("  [2] Conversation only")
        print("  [3] Files only")
    elif has_conv:
        print("  [1] Conversation")
    elif has_files:
        print("  [1] Files")
    print("  [0] Cancel")
    action = _ask("Choice: ").strip()

    do_conv = do_files = False
    if has_conv and has_files:
        if action == "1":   do_conv = do_files = True
        elif action == "2": do_conv = True
        elif action == "3": do_files = True
        else: print("Cancelled."); return
    elif has_conv:
        if action == "1": do_conv = True
        else: print("Cancelled."); return
    elif has_files:
        if action == "1": do_files = True
        else: print("Cancelled."); return

    if do_files:
        _restore_files(target_files)
    if do_conv:
        _do_rewind(brain, target)

    deleted = brain.audit.delete_runs_after_turn(
        target, project=brain.projects.current_project
    )
    if deleted:
        print(f"  Cleaned up {len(deleted)} backup file(s) from after turn [{target}].")

    print("Done.")
