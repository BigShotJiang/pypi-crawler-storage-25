"""Shared utilities for command handlers."""


def _ask(prompt_str: str) -> str:
    """Prompt for input using prompt_toolkit to avoid terminal glitches."""
    from prompt_toolkit import prompt as _pt_prompt
    try:
        return _pt_prompt(prompt_str).strip()
    except (EOFError, KeyboardInterrupt):
        return ""


def _toggle(current: bool, arg: str, name: str) -> bool:
    if arg in ("on", "1", "true"):
        new = True
    elif arg in ("off", "0", "false"):
        new = False
    else:
        new = not current
    state = "ON" if new else "OFF"
    print(f"[{name}] {state}")
    return new
