"""Command handlers: /project, /project new, switch, rename"""
import fnmatch
import sys

from control.brain import Brain
from control.fmt import p_info, p_dim
from cmds._utils import _ask
from cmds.rewind import _show_recent_turns


def cmd_new(brain: Brain):
    """Start a fresh unbound session."""
    brain.switch_project(brain.projects.new_auto_project())
    p_info(f"[new session] {brain.projects.current_project}")


def cmd_switch(brain: Brain, arg: str = ""):
    """Switch to a different session by name or interactive list."""
    projects = brain.projects.list_projects()
    if not projects:
        print("No sessions available.")
        return

    if arg:
        name = arg.strip()
        all_names = [p["name"] for p in projects]
        if name not in all_names:
            print(f"Session not found: {name}")
            print(f"  Available: {', '.join(all_names)}")
            return
    else:
        print("\nSessions:")
        cur = brain.projects.current_project
        for i, p in enumerate(projects, 1):
            marker = " ◀" if p["name"] == cur else ""
            wd = f"  [{p['work_dir']}]" if p["work_dir"] else ""
            auto = " (auto)" if p["auto"] else ""
            print(f"  [{i}] {p['name']}{marker}{wd}{auto}")
        choice = _ask(f"\nSelect [1–{len(projects)}] (or Enter to cancel): ").strip()
        if not choice.isdigit() or not (1 <= int(choice) <= len(projects)):
            print("Cancelled.")
            return
        name = projects[int(choice) - 1]["name"]

    if name == brain.projects.current_project:
        print(f"Already on: {name}")
        return

    brain.switch_project(name)

    # Process pending sessions so recent_memory is up-to-date (same as startup)
    _pending = brain.memory.load_pending_sessions()
    if _pending:
        import threading as _threading
        _stop = _threading.Event()

        def _spin():
            frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
            i = 0
            while not _stop.is_set():
                sys.stdout.write(f"\r  {frames[i % len(frames)]}  同步记忆中...")
                sys.stdout.flush()
                _stop.wait(0.1)
                i += 1
            sys.stdout.write("\r\033[K")
            sys.stdout.flush()

        _t = _threading.Thread(target=_spin, daemon=True)
        _t.start()
        brain.process_pending_sessions(blocking=True)
        _stop.set()
        _t.join()
        p_dim(f"  [memory] synced {len(_pending)} session(s)")
    else:
        brain.process_pending_sessions(blocking=True)

    _show_recent_turns(brain)
    p_info(f"[switched] → {name}")
    wd = brain.projects.work_dir if brain.projects.has_work_dir else None
    p_dim(f"  [workdir] {wd}" if wd else "  [workdir] (not set)")


def cmd_rename(brain: Brain, new_name: str):
    """Rename the current session."""
    if not new_name:
        print("Usage: /rename <new-name>")
        return
    old = brain.projects.current_project
    try:
        brain.projects.rename_project(old, new_name)
        if brain.projects.current_project == new_name:
            brain._reinit_memory()
        p_info(f"Renamed: {old} → {new_name}")
    except (ValueError, FileExistsError) as e:
        print(f"Error: {e}")


def cmd_project(brain: Brain, args: str):
    parts = args.split(None, 2)
    if not parts:
        print("Usage: /project new|list|delete|rename|switch|workdir")
        return
    sub = parts[0].lower()
    try:
        if sub == "new":
            cmd_new(brain)
        elif sub == "switch":
            cmd_switch(brain, parts[1] if len(parts) > 1 else "")
        elif sub == "list":
            projects = brain.projects.list_projects()
            print("\nSessions:")
            for p in projects:
                marker = " ◀" if p["name"] == brain.projects.current_project else ""
                wd = f"  [{p['work_dir']}]" if p["work_dir"] else ""
                auto = " (auto)" if p["auto"] else ""
                print(f"  {p['name']}{marker}{wd}{auto}")
        elif sub == "delete":
            pattern = parts[1]
            all_names = [p["name"] for p in brain.projects.list_projects()]
            matches = [n for n in all_names if fnmatch.fnmatch(n, pattern)]
            if not matches:
                print(f"No projects match: {pattern}")
            else:
                if len(matches) == 1:
                    print(f"Delete project: {matches[0]}")
                else:
                    print(f"Will delete {len(matches)} projects:")
                    for n in matches:
                        print(f"  - {n}")
                confirm = _ask("Confirm? [y/N] ❯ ").lower()
                if confirm in ("y", "yes"):
                    deleted, skipped = [], []
                    for n in matches:
                        try:
                            brain.projects.delete_project(n)
                            deleted.append(n)
                        except ValueError as e:
                            skipped.append(f"{n} ({e})")
                    if deleted:
                        print(f"Deleted: {', '.join(deleted)}")
                    if skipped:
                        print(f"Skipped: {', '.join(skipped)}")
                else:
                    print("Cancelled.")
        elif sub == "rename":
            new_name = parts[1] if len(parts) > 1 else ""
            cmd_rename(brain, new_name)
        elif sub == "workdir":
            if len(parts) > 1 and parts[1].lower() == "clear":
                brain.projects.set_work_dir(None)
                print("work_dir cleared.")
            elif len(parts) > 1:
                new_wd = parts[1]
                brain.projects.set_work_dir(new_wd)
                print(f"work_dir set to: {new_wd}")
            else:
                wd = brain.projects.work_dir
                print(f"work_dir: {wd or '(not set)'}")
                print("  /project workdir <path>   set · /project workdir clear   unset")
        else:
            print(f"Unknown subcommand: {sub}")
    except (IndexError, KeyError):
        print(f"Missing argument for /project {sub}")
    except Exception as e:
        print(f"Error: {e}")
