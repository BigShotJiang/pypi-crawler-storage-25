"""@mention expansion: @path, @*query, @dir, @N index references."""
import os
import re

from control.fmt import p_dim, p_warn

_IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.tiff', '.tif'}
_PDF_EXTS   = {'.pdf'}
_EXCEL_EXTS = {'.xlsx', '.xls'}

# Matches @"path with spaces", @'path with spaces', or @plain/path
_AT_FILE_RE = re.compile(r'@(?:"([^"]+)"|\'([^\']+)\'|([\w./~\\][^\s,;!?]*))')

# Matches @*query — inject ALL resource search results
_AT_ALL_RE = re.compile(r'@\*(?:"([^"]+)"|\'([^\']+)\'|([\w./~\\-][^\s,;!?]*))')


def _extract_image_blocks(text: str, work_dir: str) -> tuple[str, list[dict], list[str]]:
    """
    Find @path references to image files. Remove them from text and return
    (cleaned_text, image_url_blocks, filenames) for building a multimodal content list.
    Non-image @paths are left in text for _expand_at_files to handle.
    """
    import base64, mimetypes
    image_refs: set[str] = set()
    image_blocks: list[dict] = []
    filenames: list[str] = []

    for m in _AT_FILE_RE.finditer(text):
        raw = m.group(1) or m.group(2) or m.group(3)
        path = os.path.expanduser(raw)
        if not os.path.isabs(path):
            path = os.path.join(work_dir, path)
        path = os.path.normpath(path)
        if not os.path.isfile(path):
            continue
        if os.path.splitext(path)[1].lower() not in _IMAGE_EXTS:
            continue
        try:
            mime = mimetypes.guess_type(path)[0] or "image/png"
            with open(path, "rb") as f:
                data = base64.b64encode(f.read()).decode()
            image_blocks.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}})
            image_refs.add(raw)
            filenames.append(os.path.basename(path))
            p_dim(f"  🖼  image: {raw}")
        except OSError as e:
            p_warn(f"@{raw}: cannot read image ({e}), skipped")

    if not image_refs:
        return text, [], []

    clean = _AT_FILE_RE.sub(
        lambda m: "" if (m.group(1) or m.group(2) or m.group(3)) in image_refs else m.group(0),
        text
    ).strip()
    return clean, image_blocks, filenames


def _at_inject_file(
    path: str,
    raw: str,
    res_id: int | None,
    attachments: list,
    resource_ids: list,
) -> None:
    """Inject a single file into attachments. Handles PDF/Excel/text."""
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in _PDF_EXTS:
            content = (f"[PDF file attached: {path}]\n"
                       f"Use the pdf_read tool with path=\"{path}\" to read this file.")
            attachments.append((raw, path, content))
            p_dim(f"  📄 pdf: {raw}")
        elif ext in _EXCEL_EXTS:
            content = (f"[Spreadsheet attached: {path}]\n"
                       f"Use the excel_read tool with path=\"{path}\" to read this file.")
            attachments.append((raw, path, content))
            p_dim(f"  📊 spreadsheet: {raw}")
        else:
            _MAX_AT_CHARS = 200_000
            with open(path, encoding="utf-8") as _f:
                content = _f.read(_MAX_AT_CHARS)
            if len(content) == _MAX_AT_CHARS:
                content += f"\n... [truncated at {_MAX_AT_CHARS:,} chars — use file_read for full content]"
            attachments.append((raw, path, content))
            p_dim(f"  📎 attached: {raw} ({len(content):,} chars)")
        if res_id is not None:
            resource_ids.append(res_id)
    except UnicodeDecodeError:
        p_warn(f"@{raw}: binary file cannot be inlined, skipped")
    except OSError as e:
        p_warn(f"@{raw}: cannot read ({e}), skipped")


def _expand_at_files(text: str, work_dir: str, brain=None) -> str:
    """Replace @path references with file contents inline.
    Binary formats (PDF, Excel) are represented as tool-call hints rather
    than inlined bytes.
    If brain is provided, unresolved @names are looked up in the resource registry.

    Special forms:
      @*query   — inject ALL resource search results matching query
      @dir_name — if resolves to a directory, inject a file listing
    """
    attachments: list[tuple[str, str, str]] = []
    resource_ids: list[int] = []
    consumed_ranges: list[tuple[int, int]] = []

    # ── Pass 1: @*query → inject all search results ──────────────────────────
    if brain is not None and hasattr(brain, "resources"):
        for m in _AT_ALL_RE.finditer(text):
            consumed_ranges.append((m.start(), m.end()))
            query = m.group(1) or m.group(2) or m.group(3)
            results = brain.resources.find(query)
            if not results:
                p_warn(f"@*{query}: no resources found, skipped")
                continue
            p_dim(f"  📦 @*{query}: injecting {len(results)} resource(s)")
            for rec in results:
                _at_inject_file(rec["path"], rec.get("name", os.path.basename(rec["path"])),
                                rec.get("id"), attachments, resource_ids)

    # ── Pass 2: @name / @path → single file or directory ─────────────────────
    for m in _AT_FILE_RE.finditer(text):
        if any(s <= m.start() < e for s, e in consumed_ranges):
            continue
        raw = m.group(1) or m.group(2) or m.group(3)
        force_dir = raw.endswith("/") or raw.endswith("\\")
        raw_stripped = raw.rstrip("/\\")
        path = os.path.expanduser(raw_stripped)
        if not os.path.isabs(path):
            path = os.path.join(work_dir, path)
        path = os.path.normpath(path)
        res_id: int | None = None

        if not os.path.exists(path):
            if brain is not None and hasattr(brain, "resources"):
                norm_raw = raw_stripped.lower().replace("_", "").replace("-", "")
                # 1. Watched-directory exact-basename match (highest priority for dirs)
                for w in brain.resources.list_watches():
                    wbase = os.path.basename(w["path"].rstrip("/\\"))
                    if norm_raw == wbase.lower().replace("_", "").replace("-", ""):
                        path = w["path"]
                        break
                # 2. Numeric index (@17 → resource at global index 17)
                if not os.path.exists(path) and raw_stripped.isdigit():
                    all_recs = brain.resources.list_all()
                    idx = int(raw)
                    if 1 <= idx <= len(all_recs):
                        rec = all_recs[idx - 1]
                        path = rec["path"]
                        res_id = rec.get("id")
                # 3. Name match in file registry (skipped if trailing slash — must be a dir)
                if not os.path.exists(path) and not force_dir:
                    matches = brain.resources.find_by_name(raw_stripped)
                    if matches:
                        path = matches[0]["path"]
                        res_id = matches[0].get("id")
            if not os.path.exists(path):
                p_warn(f"@{raw}: not found, skipped")
                continue

        if force_dir and not os.path.isdir(path):
            p_warn(f"@{raw}: not a directory, skipped")
            continue

        if os.path.isdir(path):
            try:
                entries = sorted(os.listdir(path))
                files = [e for e in entries if os.path.isfile(os.path.join(path, e))]
                subdirs = [e for e in entries if os.path.isdir(os.path.join(path, e))]
                lines = [f"[Directory listing: {path}]"]
                if subdirs:
                    lines += [f"  {d}/" for d in subdirs]
                lines += [f"  {f}" for f in files]
                content = "\n".join(lines)
                attachments.append((raw, path, content))
                p_dim(f"  📁 dir: {raw} ({len(files)} files)")
            except OSError as e:
                p_warn(f"@{raw}: cannot list directory ({e}), skipped")
            continue

        _at_inject_file(path, raw, res_id, attachments, resource_ids)

    # Record co-occurrence for resource registry learning
    if len(resource_ids) >= 2 and brain is not None and hasattr(brain, "resources"):
        brain.resources.record_access(resource_ids)

    if not attachments:
        return text

    attached_raws = {r for r, _, _ in attachments}
    clean = _AT_ALL_RE.sub(
        lambda m: "" if (m.group(1) or m.group(2) or m.group(3)) in attached_raws else m.group(0),
        text,
    )
    clean = _AT_FILE_RE.sub(
        lambda m: "" if (m.group(1) or m.group(2) or m.group(3)) in attached_raws else m.group(0),
        clean,
    ).strip()
    blocks = "\n\n".join(
        f"--- @{raw} ({path}) ---\n{content}\n---"
        for raw, path, content in attachments
    )
    return f"{clean}\n\n{blocks}"
