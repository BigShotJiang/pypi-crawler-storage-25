"""Command handler: /resource"""
import os
import sys

from control.brain import Brain
from control.fmt import p_ok, p_dim, dim, cyan
from cmds._utils import _ask


def _parse_index_spec(spec: str, total: int) -> list[int] | None:
    """
    Parse an index spec like '1', '1,3,5', '2-5', '1,3-5,7' into a list of 0-based indices.
    Returns None if spec doesn't look like an index spec (contains non-numeric/range chars).
    Raises ValueError if indices are out of range.
    """
    import re as _re
    spec = spec.strip()
    if not _re.fullmatch(r'[\d,\-\s]+', spec):
        return None
    indices = []
    for part in spec.split(','):
        part = part.strip()
        if '-' in part:
            lo, _, hi = part.partition('-')
            indices.extend(range(int(lo), int(hi) + 1))
        else:
            indices.append(int(part))
    for i in indices:
        if i < 1 or i > total:
            raise ValueError(f"Index {i} out of range (1-{total})")
    return [i - 1 for i in indices]  # convert to 0-based


def _cmd_resource_add_single(mgr, path: str):
    """Classify and register one file with interactive confirmation."""
    import threading, itertools, time
    from control.resources.scanner import detect_file_type, _SUPPORTED_TYPES

    ftype = detect_file_type(path)
    if ftype not in _SUPPORTED_TYPES:
        print(f"  Unsupported file type: {ftype}  ({path})")
        print(f"  Supported types: pdf, docx, doc, xlsx, xls, and plain text formats")
        return

    done = threading.Event()

    def _spin():
        for ch in itertools.cycle("⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"):
            if done.is_set():
                break
            sys.stdout.write(f"\r  {ch} Classifying ...")
            sys.stdout.flush()
            time.sleep(0.1)
        sys.stdout.write("\r\033[K")
        sys.stdout.flush()

    t = threading.Thread(target=_spin, daemon=True)
    t.start()
    try:
        summary = mgr.scan_file(path)
        classification = mgr._classify_file(path, summary)
    except Exception as e:
        done.set(); t.join()
        print(f"  Error: {e}")
        return
    finally:
        done.set(); t.join()

    tags = ", ".join(classification.get("tags", []))
    print(f"\n  Proposed registration:")
    print(f"    name:  {classification.get('name', '')}")
    print(f"    desc:  {classification.get('description', '')}")
    print(f"    tags:  {tags}")
    answer = _ask("\n  Register this file? [y/N] ❯ ").strip().lower()
    if answer in ("y", "yes"):
        try:
            rec = mgr.register(path, classification["name"], classification["description"],
                               classification.get("tags", []))
            p_ok(f"  Registered: {rec['name']}  →  {rec['path']}")
        except Exception as e:
            print(f"  Registration failed: {e}")
    else:
        print("  Cancelled.")


def _cmd_resource_add_batch(mgr, paths: list, is_dirs: bool, recursive: bool = False,
                            watch_on_confirm: bool = False):
    """Classify and batch-register multiple files or a directory."""
    if is_dirs:
        import threading, itertools, time as _time

        dir_label = f"  {paths[0]} {'(recursive)' if recursive else ''}"
        done_scan = threading.Event()

        def _spin_scan():
            for ch in itertools.cycle("⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"):
                if done_scan.is_set():
                    break
                sys.stdout.write(f"\r  {ch} Scanning {dir_label} ")
                sys.stdout.flush()
                _time.sleep(0.1)
            sys.stdout.write("\r\033[K")
            sys.stdout.flush()

        t_scan = threading.Thread(target=_spin_scan, daemon=True)
        t_scan.start()
        try:
            new_files, already, skipped_binary = mgr.list_dir_files(paths[0], recursive=recursive)
        except Exception as e:
            done_scan.set(); t_scan.join()
            print(f"  Error: {e}")
            return
        finally:
            done_scan.set(); t_scan.join()

        if skipped_binary:
            for p in skipped_binary:
                print(f"  Skipped {os.path.basename(p)}: binary / unsupported type")
        if already:
            print(f"  Already registered ({len(already)} skipped):")
            for p in already:
                print(f"    ✓ {os.path.basename(p)}")

        from collections import defaultdict as _defaultdict
        from control.resources.manager import ResourceManager as _RM

        groups: dict = _defaultdict(list)
        for path in new_files:
            groups[_RM._prefix_key(path)].append(path)

        proposals = []
        classified_count = 0
        total_groups = len(groups)
        for g_idx, (key, group_paths) in enumerate(groups.items(), 1):
            rep_path = group_paths[0]
            rep_fname = os.path.basename(rep_path)
            sys.stdout.write(
                f"\r  [{g_idx}/{total_groups}] {rep_fname[:55]:<55}"
                + (f" (+{len(group_paths)-1} similar)" if len(group_paths) > 1 else "")
            )
            sys.stdout.flush()
            try:
                summary = mgr.scan_file(rep_path)
                cl = mgr._classify_file(rep_path, summary,
                                        series_size=len(group_paths))
                classified_count += 1
            except Exception as e:
                sys.stdout.write("\r\033[K")
                print(f"  Skipped {rep_fname}: {e}")
                continue

            proposals.append({"path": rep_path, **cl})
            for path in group_paths[1:]:
                proposals.append({
                    "path": path,
                    "name": cl["name"],
                    "description": cl["description"],
                    "tags": cl["tags"],
                })

        sys.stdout.write("\r\033[K")
        sys.stdout.flush()
        if classified_count < len(new_files):
            saved = len(new_files) - classified_count
            print(f"  Grouped {saved} file(s) under {total_groups} prefix(es) — {saved} LLM call(s) saved")
        mgr._pending = proposals
    else:
        already_registered = {r["path"] for r in mgr.list_all()}
        new_files = [p for p in paths if p not in already_registered]
        skipped = [p for p in paths if p in already_registered]
        if skipped:
            print(f"  Already registered ({len(skipped)} skipped):")
            for p in skipped:
                print(f"    ✓ {os.path.basename(p)}")
        if not new_files:
            print("  All files already registered.")
            return
        total = len(new_files)
        proposals = []
        for i, path in enumerate(new_files, 1):
            fname = os.path.basename(path)
            sys.stdout.write(f"\r  [{i}/{total}] {fname[:60]:<60}")
            sys.stdout.flush()
            try:
                summary = mgr.scan_file(path)
                classification = mgr._classify_file(path, summary)
                proposals.append({"path": path, **classification})
            except Exception as e:
                sys.stdout.write("\n")
                print(f"  Skipped {fname}: {e}")
        sys.stdout.write("\r\033[K")
        sys.stdout.flush()
        mgr._pending = proposals

    if not proposals:
        print("  No new files to register.")
        return

    print(f"\n  Classified {len(proposals)} file(s):\n")
    col_w = min(max(len(os.path.basename(p["path"])) for p in proposals), 30)
    print(f"  {'File':<{col_w}}  Tags")
    print(f"  {'─' * col_w}  {'─' * 40}")
    for p in proposals:
        fname = os.path.basename(p["path"])[:col_w]
        tags = ", ".join(p.get("tags", [])[:4])
        print(f"  {fname:<{col_w}}  {tags}")
    print()
    for p in proposals:
        print(f"  • {p.get('name', '')}: {p.get('description', '')}")

    answer = _ask(f"\n  Register all {len(proposals)} file(s)? [y/N] ❯ ").strip().lower()
    if answer in ("y", "yes"):
        result = mgr.commit_pending()
        for r in result["registered"]:
            p_ok(f"  ✓ {r['name']}  →  {r['path']}")
        if len(result["registered"]) < len(proposals):
            failed = len(proposals) - len(result["registered"])
            print(f"  {failed} file(s) failed — check logs.")
        if watch_on_confirm and is_dirs:
            try:
                mgr.watch_dir(paths[0], recursive)
                flag = " (recursive)" if recursive else ""
                p_dim(f"  Watching for new files: {os.path.normpath(paths[0])}{flag}")
            except Exception:
                pass
    else:
        mgr._pending = []
        print("  Cancelled.")


def cmd_resource(brain: Brain, args: str = ""):
    """Manage the local resource registry directly."""
    mgr = getattr(brain, "resources", None)
    if not mgr:
        print("  Resource registry not available.")
        return

    parts = args.split(None, 1)
    sub = parts[0].lower() if parts else ""
    rest = parts[1].strip() if len(parts) > 1 else ""

    def _print_resource(r: dict, idx: int = 0, total: int = 0):
        tags = ", ".join(r["tags"][:6]) if r["tags"] else "—"
        used = f"used {r['use_count']}×" if r["use_count"] else "never used"
        counter = f"[{idx}] " if idx else ""
        print(f"  {counter}{r['name']}")
        print(f"  {dim(r['path'])}")
        if r.get("description"):
            print(f"  {r['description'][:100]}")
        print(f"  tags: {tags}  |  {used}")
        print()

    if not sub or sub == "list":
        records = mgr.list_all()
        if not records:
            print("  (no resources registered)")
            print("  Use /resource add <path> or ask the agent to register files.")
            return
        if rest:
            try:
                idxs = _parse_index_spec(rest, len(records))
            except ValueError as e:
                print(f"  {e}")
                return
            if idxs is not None:
                for i in idxs:
                    _print_resource(records[i], i + 1)
                return
        print(f"  {len(records)} resource(s)\n")
        for i, r in enumerate(records, 1):
            _print_resource(r, i)
        return

    if sub == "tree":
        records = mgr.list_all()
        if not records:
            print("  (no resources registered)")
            return
        import collections as _col
        watches = {os.path.normpath(w["path"]) for w in mgr.list_watches()}
        by_dir: dict[str, list[tuple[int, dict]]] = _col.defaultdict(list)
        for i, r in enumerate(records, 1):
            by_dir[os.path.dirname(r["path"])].append((i, r))
        dirs_sorted = sorted(by_dir, key=lambda d: (0 if os.path.normpath(d) in watches else 1, d))

        save_path = os.path.expanduser(rest) if rest else None
        lines_plain: list[str] = []

        header = f"{len(records)} resource(s) across {len(by_dir)} director{'y' if len(by_dir)==1 else 'ies'}"
        if not save_path:
            print(f"  {header}\n")
        lines_plain.append(header)
        lines_plain.append("")

        for d in dirs_sorted:
            entries = by_dir[d]
            watched = os.path.normpath(d) in watches
            watch_mark = "  [watched]" if watched else ""
            if not save_path:
                print(f"  {cyan(d)}{dim(watch_mark)}")
            lines_plain.append(f"{d}{watch_mark}")
            for idx, r in entries:
                fname = os.path.basename(r["path"])
                tags = ", ".join(r["tags"][:3]) if r["tags"] else ""
                tag_str = f"  [{tags}]" if tags else ""
                if not save_path:
                    print(f"    [{idx}] {fname}{dim(tag_str) if tags else ''}")
                lines_plain.append(f"  [{idx}] {fname}{tag_str}")
            if not save_path:
                print()
            lines_plain.append("")

        if save_path:
            try:
                with open(save_path, "w", encoding="utf-8") as _f:
                    _f.write("\n".join(lines_plain))
                p_ok(f"  Saved to {save_path}")
            except OSError as e:
                print(f"  Error saving: {e}")
        return

    if sub == "search":
        if not rest:
            print("  Usage: /resource search <query>")
            return
        results = mgr.find(rest)
        if not results:
            print(f"  No resources found for: {rest!r}")
            return
        all_records = mgr.list_all()
        global_idx = {r["path"]: i for i, r in enumerate(all_records, 1)}
        print(f"  {len(results)} result(s) for {rest!r}\n")
        for r in results:
            _print_resource(r, global_idx.get(r["path"], 0))
        names = "  ".join(f"@{r['name'].replace(' ', '_')}" for r in results[:5])
        print(f"  {dim('Tip: reference in your message with')}  {names}")
        query_slug = rest.replace(' ', '_')
        print(f"  {dim('     @*' + query_slug + dim(' — inject all ' + str(len(results)) + ' results  |  @<dir> — list directory files'))}")
        print()
        return

    if sub == "add":
        if not rest:
            print("  Usage: /resource add [-r] <path|glob|directory>")
            return
        import glob as _glob
        recursive = False
        raw = rest.strip()
        if raw.startswith("-r "):
            recursive = True
            raw = raw[3:].strip()
        expanded = os.path.expanduser(raw)

        if os.path.isdir(expanded):
            _cmd_resource_add_batch(mgr, [expanded], is_dirs=True, recursive=recursive,
                                    watch_on_confirm=True)
        elif any(c in raw for c in ("*", "?", "[")):
            matches = sorted(_glob.glob(expanded))
            if not matches:
                print(f"  No files matched: {raw}")
                return
            files = [os.path.abspath(p) for p in matches if os.path.isfile(p)]
            if not files:
                print(f"  No files (directories skipped): {raw}")
                return
            _cmd_resource_add_batch(mgr, files, is_dirs=False)
        else:
            path = os.path.abspath(expanded)
            if not os.path.isfile(path):
                print(f"  File not found: {path}")
                return
            _cmd_resource_add_single(mgr, path)
        return

    if sub == "rescan":
        records = mgr.list_all()
        targets = [r for r in records if not r.get("description") and not r.get("tags")]
        if rest:
            targets = [r for r in targets if rest.lower() in r["path"].lower() or rest.lower() in r["name"].lower()]
        if not targets:
            print("  All registered resources already have descriptions/tags.")
            return
        total_rescan = len(targets)
        print(f"  Re-classifying {total_rescan} resource(s) with empty metadata ...")
        updated = 0
        for i, r in enumerate(targets, 1):
            fname = os.path.basename(r["path"])
            sys.stdout.write(f"\r  [{i}/{total_rescan}] {fname[:60]:<60}")
            sys.stdout.flush()
            try:
                summary = mgr.scan_file(r["path"])
                cl = mgr._classify_file(r["path"], summary)
                from control.resources import db as _db
                _db.update_content(
                    r["path"], cl["description"], cl.get("tags", []),
                    r["file_hash"], r["file_mtime"], mgr._db_path,
                )
                sys.stdout.write("\r\033[K")
                p_ok(f"  ✓ {fname}: {', '.join(cl.get('tags', [])[:4])}")
                updated += 1
            except Exception as e:
                sys.stdout.write("\r\033[K")
                print(f"  Skipped {fname}: {e}")
        print(f"\n  Done: {updated}/{len(targets)} updated.")
        return

    if sub == "del":
        if not rest:
            print("  Usage: /resource del <index|range|query>")
            return
        all_records = mgr.list_all()
        try:
            idxs = _parse_index_spec(rest, len(all_records))
        except ValueError as e:
            print(f"  {e}")
            return
        if idxs is not None:
            results = [all_records[i] for i in idxs]
            mgr._pending_delete = list(results)
        else:
            results = mgr.stage_delete(rest)
        if not results:
            print(f"  No resources found for: {rest!r}")
            return
        print(f"\n  Will delete {len(results)} resource(s):")
        for r in results:
            print(f"    {r['name']}  →  {r['path']}")
        answer = _ask("\n  Confirm deletion? [y/N] ❯ ").strip().lower()
        if answer in ("y", "yes"):
            result = mgr.commit_pending()
            for r in result["deleted"]:
                print(f"  Deleted: {r['name']}")
        else:
            mgr._pending_delete = []
            print("  Cancelled.")
        return

    if sub == "edit":
        if not rest:
            print("  Usage: /resource edit <index|query>")
            return
        all_records = mgr.list_all()
        try:
            idxs = _parse_index_spec(rest, len(all_records))
        except ValueError as e:
            print(f"  {e}")
            return
        if idxs is not None:
            if len(idxs) != 1:
                print("  Please specify a single index for edit.")
                return
            rec = all_records[idxs[0]]
        else:
            from control.resources import db as _rdb
            results = _rdb.match_by_pattern(rest, mgr._db_path)
            if not results:
                print(f"  No resources found for: {rest!r}")
                return
            if len(results) > 1:
                print(f"  {len(results)} matches — pick one:")
                for i, r in enumerate(results, 1):
                    print(f"    {i}. {r['name']}  ({r['path']})")
                choice = _ask("  Number ❯ ").strip()
                try:
                    rec = results[int(choice) - 1]
                except (ValueError, IndexError):
                    print("  Cancelled.")
                    return
            else:
                rec = results[0]
        print(f"\n  Editing: {rec['name']}  ({rec['path']})")
        print(f"  Current description: {rec['description'] or '(empty)'}")
        print(f"  Current tags: {', '.join(rec['tags']) if rec['tags'] else '(none)'}")
        new_name_str = _ask(f"\n  New name [{rec['name']}]: ").strip()
        new_desc_str = _ask(f"  New description [{(rec['description'] or '')[:60]}]: ").strip()
        new_tags_str = _ask(f"  New tags (comma-separated) [{', '.join(rec['tags'])}]: ").strip()
        new_name = new_name_str or None
        new_desc = new_desc_str if new_desc_str else None
        new_tags = [t.strip() for t in new_tags_str.split(",") if t.strip()] if new_tags_str else None
        if new_name is None and new_desc is None and new_tags is None:
            print("  No changes.")
            return
        try:
            updated = mgr.edit(rec["path"], new_name, new_desc, new_tags)
            p_ok(f"  Updated: {updated['name']}")
            if new_desc is not None:
                print(f"  Description: {updated['description']}")
            if new_tags is not None:
                print(f"  Tags: {', '.join(updated['tags'])}")
        except Exception as e:
            print(f"  Error: {e}")
        return

    if sub == "watch":
        if not rest:
            watches = mgr.list_watches()
            if not watches:
                print("  No watched directories.")
                print("  Use /resource watch [-r] <directory> to add one.")
            else:
                print(f"  {len(watches)} watched director{'y' if len(watches) == 1 else 'ies'}:\n")
                for w in watches:
                    flag = " (recursive)" if w["recursive"] else ""
                    print(f"    {w['path']}{flag}")
            return
        recursive = False
        raw = rest.strip()
        if raw.startswith("-r "):
            recursive = True
            raw = raw[3:].strip()
        try:
            mgr.watch_dir(raw, recursive)
            flag = " (recursive)" if recursive else ""
            p_ok(f"  Watching: {os.path.expanduser(os.path.normpath(raw))}{flag}")
            print("  New files will be auto-registered on next startup or /resource sync.")
        except NotADirectoryError as e:
            print(f"  {e}")
        return

    if sub == "unwatch":
        if not rest:
            print("  Usage: /resource unwatch <directory>")
            return
        removed = mgr.unwatch_dir(rest.strip())
        if removed:
            p_ok(f"  Removed watch: {rest.strip()}")
        else:
            print(f"  Not watched: {rest.strip()}")
        return

    if sub == "sync":
        if rest:
            from control.resources import db as _rdb
            all_records = mgr.list_all()
            try:
                idxs = _parse_index_spec(rest, len(all_records))
                targets = [all_records[i] for i in idxs] if idxs is not None else None
            except ValueError:
                targets = None
            if targets is None:
                targets = _rdb.match_by_pattern(rest, mgr._db_path)
                if not targets:
                    targets = mgr.find_by_name(rest)
            if not targets:
                print(f"  No resources found for: {rest!r}")
                return
            ok = fail = 0
            for r in targets:
                try:
                    status = mgr.sync_one(r["path"])
                    if status == "deleted":
                        print(f"  Removed (file gone): {r['name']}")
                    else:
                        p_ok(f"  Updated: {r['name']}")
                    ok += 1
                except Exception as e:
                    print(f"  Failed {r['name']}: {e}")
                    fail += 1
            print(f"\n  Done: {ok} updated" + (f", {fail} failed" if fail else ""))
            return
        result = mgr.sync()
        parts = [f"checked {result['checked']}"]
        if result.get("added"):
            parts.append(f"added {result['added']}")
        if result.get("updated"):
            parts.append(f"updated {result['updated']}")
        if result.get("removed"):
            parts.append(f"removed {result['removed']}")
        p_ok(f"  Sync complete: {', '.join(parts)}")
        return

    print(f"  Unknown subcommand: {sub}")
    print("  Usage: /resource [list|tree|search <q>|add [-r] <path>|watch [-r] <dir>|unwatch <dir>|sync|rescan|del <q>|edit <q>]")
