"""Command handler: /memory"""
import time

from control.brain import Brain
from cmds._utils import _ask


def cmd_memory(brain: Brain, args: str = ""):
    """Show or edit core/project memory."""
    parts = args.split(None, 1)
    sub = parts[0].lower() if parts else ""
    rest = parts[1] if len(parts) > 1 else ""

    # --project flag routes set/del to project_memory instead of core_memory
    use_project = "--project" in rest
    if use_project:
        rest = rest.replace("--project", "").strip()

    cm = brain.memory.core_memory
    pm = getattr(brain, "project_memory", None)

    # --- subcommands ---
    if sub == "set":
        if use_project:
            if not pm:
                print("  No project memory configured for this project.")
                return
            kv = rest.split(None, 1)
            if len(kv) < 2:
                print("Usage: /memory set <key> <value> --project")
                return
            key, value = kv[0], kv[1]
            dim = key  # project memory keys equal dimension names
            if key not in pm.dimensions:
                dims = ", ".join(pm.dimensions)
                print(f"  Unknown key '{key}'. Valid keys: {dims}")
                return
            pm.set(key, value, dimension=dim)
            print(f"  Set [project/{key}]: {value}")
            return
        dim = "interaction_style"
        if "--dim" in rest:
            rest, _, dim_part = rest.partition("--dim")
            dim = dim_part.strip()
            rest = rest.strip()
        kv = rest.split(None, 1)
        if len(kv) < 2:
            print("Usage: /memory set <key> <value> [--dim <dimension>]")
            return
        key, value = kv[0], kv[1]
        cm.set(key, value, dimension=dim)
        print(f"  Set [{dim}] {key}: {value}")
        return

    if sub == "del":
        key = rest.strip()
        if not key:
            print("Usage: /memory del <key> [--project]")
            return
        if use_project:
            if not pm:
                print("  No project memory configured for this project.")
                return
            deleted = pm.delete(key)
            print(f"  {'Deleted from project memory' if deleted else 'Key not found'}: {key}")
        else:
            deleted = cm.delete(key)
            print(f"  {'Deleted' if deleted else 'Key not found'}: {key}")
        return

    if sub == "compact":
        cm = brain.memory.core_memory
        print("  Compacting bloated memory entries...")
        keys = cm.compact(threshold=200)
        if keys:
            print(f"  Compacted {len(keys)} entry(ies): {', '.join(keys)}")
        else:
            print("  All entries are within size limits.")
        return

    if sub == "pin":
        key = rest.strip()
        if not key:
            print("Usage: /memory pin <key>")
            return
        entries = cm.get_all_with_scores()
        meta = next((e for e in entries if e["key"] == key), None)
        if not meta:
            print(f"  Key not found: {key}")
            return
        cm.set(key, meta["value"], dimension=meta.get("dimension", "interaction_style"), stability=999.0)
        print(f"  Pinned: {key}  (stability=999, never forgets)")
        return

    # --- default: show all ---
    core_entries = cm.get_all_with_scores() if cm else []
    print("\n[Core Memory]")
    if not core_entries:
        print("  (empty)")
    else:
        by_dim: dict[str, list] = {}
        for e in core_entries:
            by_dim.setdefault(e.get("dimension", "?"), []).append(e)
        for dim, items in sorted(by_dim.items()):
            print(f"  [{dim}]")
            for e in items:
                days = (time.time() - e["updated_at"]) / 86400
                pin = " 📌" if e["stability"] >= 999 else ""
                print(f"    {e['value']}")
                print(f"      score={e['score']:.2f}  updated={days:.1f}d ago{pin}")

    pm = getattr(brain, "project_memory", None)
    project = brain.projects.current_project
    print(f"\n[Project Memory — {project}]")
    if not pm:
        print("  (not configured)")
    else:
        proj_entries = pm.get_all_with_scores()
        by_dim2: dict[str, list] = {}
        for e in proj_entries:
            by_dim2.setdefault(e.get("dimension", "?"), []).append(e)
        all_dims = list(pm.dimensions.keys()) if hasattr(pm, "dimensions") else sorted(by_dim2.keys())
        for dim in all_dims:
            items = by_dim2.get(dim, [])
            if not items:
                print(f"  [{dim}]: (empty)")
                continue
            print(f"  [{dim}]")
            for e in items:
                days = (time.time() - e["updated_at"]) / 86400
                print(f"    {e['value']}")
                print(f"      score={e['score']:.2f}  updated={days:.1f}d ago")

    tasks = getattr(brain, "tasks", None)
    print(f"\n[Tasks — {project}]")
    if tasks:
        open_tasks = tasks.open_tasks()
        done_tasks = tasks.list("done")
        if not open_tasks and not done_tasks:
            print("  (no tasks)")
        for t in open_tasks:
            print(f"  #{t['id']} [open]  {t['title']}")
            if t.get("description"):
                print(f"           {t['description']}")
            print(f"           created: {t['created_at']}")
        for t in done_tasks[-5:]:
            print(f"  #{t['id']} [done]  {t['title']}  ({t['done_at']})")
    else:
        print("  (not configured)")
    print()
