"""Command handler: /email"""
import os

from control.brain import Brain
from cmds._utils import _ask


def cmd_email(brain: "Brain", arg_raw: str = "") -> None:
    """
    /email [output_file] [--since <days>] [--batch <count>] [--lang zh|en|auto] [--no-open] [--tasks]
    Summarise unread Outlook emails via LLM.  Windows only.
    Scans Inbox and all its subfolders; processes emails within the last --since days.
    """
    from tools.outlook import run_outlook_summary, create_outlook_tasks

    parts = arg_raw.split()
    since = 30
    batch = 10
    lang = "auto"
    launch = True
    do_tasks = False
    output_file = None
    i = 0
    while i < len(parts):
        token = parts[i]
        if token == "--since" and i + 1 < len(parts):
            since = int(parts[i + 1]); i += 1
        elif token == "--batch" and i + 1 < len(parts):
            batch = int(parts[i + 1]); i += 1
        elif token == "--lang" and i + 1 < len(parts):
            lang = parts[i + 1]; i += 1
        elif token in ("zh", "en", "auto"):
            lang = token
        elif token == "--no-open":
            launch = False
        elif token == "--tasks":
            do_tasks = True
        elif not token.startswith("-") and output_file is None:
            output_file = os.path.expanduser(token)
        i += 1

    def _progress(current, total, email_count):
        if current > total:
            print(f"[email] Consolidating {email_count} emails...", flush=True)
        else:
            print(f"[email] Processing batch {current}/{total}  ({email_count} total unread)...", flush=True)

    print(f"[email] Scanning Inbox subfolders (last {since} days, batch={batch})…")
    try:
        report, action_items = run_outlook_summary(
            since_days=since,
            batch_size=batch,
            lang=lang,
            launch=launch,
            llm_fn=lambda msgs: brain.llm.complete(msgs, max_tokens=4096),
            progress_fn=_progress,
        )
    except RuntimeError as e:
        print(f"[email] {e}")
        return

    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"[email] Report saved to {output_file}")

    from rich.console import Console
    from rich.markdown import Markdown
    from rich.rule import Rule
    console = Console()
    console.print()
    console.print(Rule("Outlook Email Summary"))
    console.print()
    console.print(Markdown(report))
    console.print()

    if do_tasks and action_items:
        print(f"\nAction items ({len(action_items)}):")
        for idx, ai in enumerate(action_items, 1):
            due = f"  Due: {ai['due_date']}" if ai.get("due_date") else ""
            print(f"  {idx}. [{ai['priority'].upper()}] {ai['task']}{due}")
            print(f"     From: {ai['email_subject']} ({ai['sender']})")
        answer = _ask("Create these as Outlook Tasks? [y/N] ").strip().lower()
        if answer == "y":
            try:
                n = create_outlook_tasks(action_items)
                print(f"[email] Created {n} Outlook task(s).")
            except RuntimeError as e:
                print(f"[email] {e}")
