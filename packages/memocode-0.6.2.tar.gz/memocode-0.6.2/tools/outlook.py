"""
Custom tool: outlook_summary  (Windows only)
Reads unread emails from Outlook Inbox and its subfolders, processes them in
batches via LLM, and returns a consolidated Markdown report with action items.

As a standalone script:
  python outlook.py [--since 30] [--batch 10] [--lang zh|en|auto] [--no-open]
                    [--tasks] [output_file]

Requirements (Windows):
  pip install pywin32
"""

from __future__ import annotations
import argparse
import html
import json
import os
import re
import sys
import textwrap
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone

# ── Config ────────────────────────────────────────────────────────────────────

_AGENT_JSON = os.path.expanduser("~/.mcode/agent.json")
_DEFAULT_MODEL = "gpt-4o"
_MAX_EMAIL_CHARS = 3000
_MAX_BATCH_CHARS = 60000


def _load_agent_cfg() -> dict:
    try:
        with open(_AGENT_JSON, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


# ── Outlook COM ───────────────────────────────────────────────────────────────

def _ensure_outlook_running(launch: bool = True) -> None:
    import subprocess
    import shutil
    result = subprocess.run(
        ["tasklist", "/FI", "IMAGENAME eq OUTLOOK.EXE"],
        capture_output=True, text=True,
    )
    if "OUTLOOK.EXE" in result.stdout:
        return
    if not launch:
        return
    outlook_exe = shutil.which("OUTLOOK") or shutil.which("outlook")
    if not outlook_exe:
        for c in [
            r"C:\Program Files\Microsoft Office\root\Office16\OUTLOOK.EXE",
            r"C:\Program Files (x86)\Microsoft Office\root\Office16\OUTLOOK.EXE",
            r"C:\Program Files\Microsoft Office\Office16\OUTLOOK.EXE",
        ]:
            if os.path.exists(c):
                outlook_exe = c
                break
    if outlook_exe:
        import subprocess as _sp
        _sp.Popen([outlook_exe])
        import time
        print("[outlook] Launching Outlook, waiting 5s...", file=sys.stderr)
        time.sleep(5)


def _strip_html(text: str) -> str:
    text = re.sub(r"<style[^>]*>.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<script[^>]*>.*?</script>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _get_body(mail_item) -> str:
    try:
        body = mail_item.Body or ""
        if body.strip():
            return body.strip()
    except Exception:
        pass
    try:
        html_body = mail_item.HTMLBody or ""
        return _strip_html(html_body)
    except Exception:
        return ""


def _enum_inbox_subfolders(ns) -> list:
    """Return Inbox folder and all user-created subfolders recursively."""
    try:
        inbox = ns.GetDefaultFolder(6)  # olFolderInbox
    except Exception as e:
        raise RuntimeError(f"Cannot open Inbox: {e}")
    folders = [inbox]

    def _recurse(folder):
        try:
            count = folder.Folders.Count
        except Exception:
            return
        for i in range(1, count + 1):
            try:
                sub = folder.Folders.Item(i)
                folders.append(sub)
                _recurse(sub)
            except Exception:
                pass

    _recurse(inbox)
    return folders


def _com_dt_to_utc(com_dt) -> datetime:
    """Convert pywintypes.datetime (or string) to UTC-aware datetime."""
    try:
        # pywintypes.datetime is a datetime subclass; may carry tzinfo
        if hasattr(com_dt, "utctimetuple"):
            # Replace with UTC tzinfo if naive
            if com_dt.tzinfo is None:
                return com_dt.replace(tzinfo=timezone.utc)
            return com_dt.astimezone(timezone.utc)
    except Exception:
        pass
    try:
        return datetime.fromisoformat(str(com_dt)[:19]).replace(tzinfo=timezone.utc)
    except Exception:
        return datetime.now(timezone.utc)


def _read_all_unread(ns, since_days: int = 30) -> tuple[list[dict], list]:
    """
    Collect ALL unread emails from Inbox and its subfolders within since_days.
    Returns (list[dict], list[COM mail items]), newest first within each folder.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=since_days)
    folders = _enum_inbox_subfolders(ns)

    emails: list[dict] = []
    mail_items: list = []

    for folder in folders:
        try:
            folder_name = folder.Name
            items = folder.Items
            items.Sort("[ReceivedTime]", True)   # newest first
        except Exception:
            continue

        for item in items:
            try:
                received_dt = _com_dt_to_utc(item.ReceivedTime)
                if received_dt < cutoff:
                    break   # sorted newest-first; everything older can be skipped
                if not item.UnRead:
                    continue
                body = _get_body(item)
                emails.append({
                    "subject":  item.Subject or "(no subject)",
                    "sender":   item.SenderName or item.SenderEmailAddress or "?",
                    "received": str(item.ReceivedTime),
                    "folder":   folder_name,
                    "body":     body[:_MAX_EMAIL_CHARS] + ("…" if len(body) > _MAX_EMAIL_CHARS else ""),
                })
                mail_items.append(item)
            except Exception:
                continue

    return emails, mail_items


def _mark_emails_read(mail_items: list) -> None:
    for item in mail_items:
        try:
            item.UnRead = False
            item.Save()
        except Exception:
            continue


def create_outlook_tasks(action_items: list[dict]) -> int:
    """
    Create Outlook Tasks from a list of action item dicts.
    Each dict: {task, due_date (YYYY-MM-DD|null), priority (urgent/normal/low),
                email_subject (optional), sender (optional)}
    Returns count of successfully created tasks.
    """
    try:
        import win32com.client
    except ImportError:
        raise RuntimeError("pywin32 not installed. Run: pip install pywin32")

    _priority_map = {"urgent": 2, "normal": 1, "low": 0}
    outlook = win32com.client.Dispatch("Outlook.Application")
    created = 0
    for ai in action_items:
        try:
            task = outlook.CreateItem(3)   # olTaskItem
            task.Subject = ai.get("task", "(no title)")
            if ai.get("due_date"):
                try:
                    task.DueDate = datetime.strptime(ai["due_date"], "%Y-%m-%d")
                except ValueError:
                    pass
            task.Importance = _priority_map.get(ai.get("priority", "normal"), 1)
            body_parts = []
            if ai.get("email_subject"):
                body_parts.append(f"From email: {ai['email_subject']}")
            if ai.get("sender"):
                body_parts.append(f"Sender: {ai['sender']}")
            if body_parts:
                task.Body = "\n".join(body_parts)
            task.Save()
            created += 1
        except Exception as e:
            print(f"[email] Task creation failed: {e}", file=sys.stderr)
    return created


# ── LLM ───────────────────────────────────────────────────────────────────────

def _llm_complete(messages: list[dict], api_key: str, model: str,
                  base_url: str | None, extra_body: dict | None,
                  provider: str = "openai") -> str:
    if provider == "anthropic":
        url = (base_url or "https://api.anthropic.com") + "/v1/messages"
        payload: dict = {"model": model, "max_tokens": 4096, "messages": messages}
        if extra_body:
            payload.update(extra_body)
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "x-api-key": api_key,
                     "anthropic-version": "2023-06-01"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read())["content"][0]["text"]
    else:
        url = (base_url or "https://api.openai.com") + "/v1/chat/completions"
        payload = {"model": model, "messages": messages, "max_tokens": 4096}
        if extra_body:
            payload.update(extra_body)
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {api_key}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read())["choices"][0]["message"]["content"]


# ── Prompts ───────────────────────────────────────────────────────────────────

_BATCH_PROMPT_EN = """\
Analyze the following {n} unread emails. Return a JSON array ONLY (no markdown, no explanation).

Each element must have these fields:
- "subject": email subject
- "sender": sender name
- "folder": folder name
- "received": received time string
- "action_required": true if the recipient must do something; false if purely informational
- "relevance": "high" (directly involves recipient), "medium" (relevant but indirect), "low" (bulk/newsletter/auto-notification)
- "summary": 1-2 sentence summary
- "action_items": array of objects, each with:
    "task": what needs to be done,
    "due_date": inferred deadline as "YYYY-MM-DD" or null,
    "priority": "urgent" | "normal" | "low"

Emails:
{emails}
"""

_BATCH_PROMPT_ZH = """\
分析以下 {n} 封未读邮件。只返回JSON数组，不要markdown格式，不要任何解释。

每个元素必须包含以下字段：
- "subject": 邮件主题
- "sender": 发件人
- "folder": 所在文件夹
- "received": 接收时间字符串
- "action_required": 收件人是否需要采取行动（true/false）
- "relevance": "high"（直接涉及收件人）、"medium"（相关但间接）、"low"（群发/自动通知/简报）
- "summary": 1-2句内容摘要
- "action_items": 待办事项数组，每项包含：
    "task": 需要做什么,
    "due_date": 从邮件内容推断的截止日期（"YYYY-MM-DD"）或null,
    "priority": "urgent" | "normal" | "low"

邮件内容：
{emails}
"""

_CONSOLIDATE_PROMPT_EN = """\
Below is structured data for {n} unread emails. Generate a Markdown report.

Format:
## Overview
(1-2 paragraphs)

## Action Required ({action_count} emails)
- **[URGENT/NORMAL/LOW] Subject** — Folder | Sender | Due: date
  Summary line. Action: what to do.

## FYI Only ({fyi_count} emails)
- **Subject** — Sender: one-line summary.

## Low Relevance ({low_count} emails)
- Subject (sender)

Data (JSON):
{data}
"""

_CONSOLIDATE_PROMPT_ZH = """\
以下是 {n} 封未读邮件的结构化数据，请生成Markdown报告。

格式：
## 整体概述
（1-2段）

## 需要行动（{action_count} 封）
- **[紧急/普通/低] 主题** — 文件夹 | 发件人 | 截止：日期
  摘要。行动：需要做什么。

## 仅供参考（{fyi_count} 封）
- **主题** — 发件人：一行摘要。

## 低相关性（{low_count} 封）
- 主题（发件人）

数据（JSON）：
{data}
"""


def _is_chinese(text: str, threshold: float = 0.3) -> bool:
    chinese = len(re.findall(r"[\u4e00-\u9fff]", text))
    total = len(text.replace(" ", "").replace("\n", ""))
    return total > 0 and chinese / total >= threshold


def _format_emails(emails: list[dict]) -> str:
    parts = []
    for i, e in enumerate(emails, 1):
        parts.append(
            f"[{i}] Subject: {e['subject']}\n"
            f"    From: {e['sender']}  Folder: {e.get('folder', '?')}\n"
            f"    Received: {e['received']}\n"
            f"    Body:\n{textwrap.indent(e['body'], '    ')}"
        )
    block = "\n\n".join(parts)
    if len(block) > _MAX_BATCH_CHARS:
        block = block[:_MAX_BATCH_CHARS] + "\n… (truncated)"
    return block


def _extract_json(text: str):
    """Extract a JSON array from LLM response (handles markdown code blocks)."""
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if m:
        try:
            return json.loads(m.group(1).strip())
        except json.JSONDecodeError:
            pass
    m = re.search(r"\[[\s\S]*\]", text)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    return None


def _process_batch(emails: list[dict], llm_fn, lang: str) -> list[dict]:
    """Send one batch to LLM, return list of structured email dicts."""
    prompt_tmpl = _BATCH_PROMPT_ZH if lang == "zh" else _BATCH_PROMPT_EN
    prompt = prompt_tmpl.format(n=len(emails), emails=_format_emails(emails))
    raw = llm_fn([{"role": "user", "content": prompt}])
    result = _extract_json(raw)
    if isinstance(result, list):
        return result
    # Fallback: return minimal dicts so processing can continue
    return [
        {
            "subject": e["subject"], "sender": e["sender"],
            "folder": e.get("folder", "?"), "received": e["received"],
            "action_required": False, "relevance": "low",
            "summary": "(parse error)", "action_items": [],
        }
        for e in emails
    ]


def _consolidate(all_results: list[dict], llm_fn, lang: str) -> str:
    """Final consolidation pass: generate Markdown report from all batch results."""
    action = [r for r in all_results if r.get("action_required")]
    fyi = [r for r in all_results
           if not r.get("action_required") and r.get("relevance") in ("high", "medium")]
    low = [r for r in all_results if r.get("relevance") == "low" and not r.get("action_required")]

    prompt_tmpl = _CONSOLIDATE_PROMPT_ZH if lang == "zh" else _CONSOLIDATE_PROMPT_EN
    prompt = prompt_tmpl.format(
        n=len(all_results),
        action_count=len(action),
        fyi_count=len(fyi),
        low_count=len(low),
        data=json.dumps(all_results, ensure_ascii=False, indent=2)[:_MAX_BATCH_CHARS],
    )
    return llm_fn([{"role": "user", "content": prompt}])


# ── Core function ─────────────────────────────────────────────────────────────

def run_outlook_summary(
    since_days: int = 30,
    batch_size: int = 10,
    lang: str = "auto",
    launch: bool = True,
    llm_fn=None,
    progress_fn=None,   # callable(current: int, total: int, folder_count: int)
) -> tuple[str, list[dict]]:
    """
    Read ALL unread Outlook emails from Inbox + subfolders (within since_days)
    and return (markdown_report, action_items).

    action_items: flat list of {task, due_date, priority, email_subject, sender}
    llm_fn: callable(messages: list[dict]) -> str
    progress_fn: called before each batch with (batch_idx, total_batches, email_count)
    """
    if sys.platform != "win32":
        raise RuntimeError("outlook_summary is Windows-only (requires Outlook desktop + pywin32)")

    try:
        import win32com.client
    except ImportError:
        raise RuntimeError("pywin32 not installed. Run: pip install pywin32")

    _ensure_outlook_running(launch=launch)

    outlook_app = win32com.client.Dispatch("Outlook.Application")
    ns = outlook_app.GetNamespace("MAPI")

    emails, mail_items = _read_all_unread(ns, since_days=since_days)
    if not emails:
        return f"No unread emails found in the last {since_days} days.", []

    # Detect language from email subjects/bodies
    sample = " ".join(e["subject"] + " " + e["body"][:200] for e in emails[:5])
    use_zh = lang == "zh" or (lang == "auto" and _is_chinese(sample))
    effective_lang = "zh" if use_zh else "en"

    if llm_fn is None:
        cfg = _load_agent_cfg()
        api_key  = cfg.get("api_key", os.environ.get("OPENAI_API_KEY", ""))
        base_url = cfg.get("base_url")
        model    = cfg.get("model") or _DEFAULT_MODEL
        provider = cfg.get("provider", "openai")
        extra    = cfg.get("extra_body")
        if not api_key:
            raise RuntimeError("No API key. Set api_key in ~/.mcode/agent.json or OPENAI_API_KEY env var.")
        llm_fn = lambda msgs: _llm_complete(msgs, api_key, model, base_url, extra, provider)

    # Split into batches
    batches = [emails[i:i + batch_size] for i in range(0, len(emails), batch_size)]
    all_results: list[dict] = []

    for idx, batch in enumerate(batches):
        if progress_fn:
            progress_fn(idx + 1, len(batches), len(emails))
        results = _process_batch(batch, llm_fn, effective_lang)
        all_results.extend(results)

    # Final consolidation
    if progress_fn:
        progress_fn(len(batches) + 1, len(batches) + 1, len(emails))   # "consolidating"
    report = _consolidate(all_results, llm_fn, effective_lang)

    # Collect all action items with parent email context
    action_items: list[dict] = []
    for r in all_results:
        if r.get("action_required"):
            for ai in r.get("action_items", []):
                action_items.append({
                    "task":          ai.get("task", r.get("summary", "")),
                    "due_date":      ai.get("due_date"),
                    "priority":      ai.get("priority", "normal"),
                    "email_subject": r.get("subject", ""),
                    "sender":        r.get("sender", ""),
                })

    _mark_emails_read(mail_items)
    return report, action_items


# No Tool registration — triggered only via the /email slash command in run.py.


# ── CLI entry point ───────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Summarise unread Outlook emails with LLM.",
    )
    parser.add_argument("output",        nargs="?",                      help="Output file path (optional)")
    parser.add_argument("--since",       type=int,   default=30,         help="Only process emails within N days (default: 30 days)")
    parser.add_argument("--batch",       type=int,   default=10,         help="Number of emails per LLM batch (default: 10 emails)")
    parser.add_argument("--lang",        choices=["zh", "en", "auto"],   help="Output language (default: auto)", default="auto")
    parser.add_argument("--no-open",     action="store_true",            help="Don't launch Outlook if not running")
    parser.add_argument("--tasks",       action="store_true",            help="Prompt to create Outlook tasks from action items")
    args = parser.parse_args()

    if sys.platform != "win32":
        print("[error] This tool is Windows-only (requires Outlook desktop + pywin32).")
        sys.exit(1)

    def _progress(current, total, email_count):
        if current > total:
            print(f"[email] Consolidating {email_count} emails...", file=sys.stderr, flush=True)
        else:
            print(f"[email] Processing batch {current}/{total} ({email_count} total emails)...",
                  file=sys.stderr, flush=True)

    print(f"[email] Scanning Inbox subfolders (last {args.since} days, batch={args.batch})…",
          file=sys.stderr)
    try:
        report, action_items = run_outlook_summary(
            since_days=args.since,
            batch_size=args.batch,
            lang=args.lang,
            launch=not args.no_open,
            progress_fn=_progress,
        )
    except RuntimeError as e:
        print(f"[error] {e}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.HTTPError as e:
        print(f"[error] LLM request failed {e.code}: {e.read().decode(errors='replace')}", file=sys.stderr)
        sys.exit(1)

    # Output report
    if args.output:
        out_path = os.path.expanduser(args.output)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"[email] Report saved to {out_path}", file=sys.stderr)

    try:
        from rich.console import Console
        from rich.markdown import Markdown
        from rich.rule import Rule
        console = Console()
        console.print()
        console.print(Rule("Outlook Email Summary"))
        console.print()
        console.print(Markdown(report))
        console.print()
    except ImportError:
        print("\n" + "═" * 60)
        print("  Outlook Email Summary")
        print("═" * 60 + "\n")
        print(report)
        print()

    # Task creation
    if args.tasks and action_items:
        print(f"\nAction items ({len(action_items)}):")
        for i, ai in enumerate(action_items, 1):
            due = f"  Due: {ai['due_date']}" if ai.get("due_date") else ""
            print(f"  {i}. [{ai['priority'].upper()}] {ai['task']}{due}")
            print(f"     From: {ai['email_subject']} ({ai['sender']})")
        answer = input("\nCreate these as Outlook Tasks? [y/N] ").strip().lower()
        if answer == "y":
            try:
                n = create_outlook_tasks(action_items)
                print(f"[email] Created {n} Outlook task(s).")
            except RuntimeError as e:
                print(f"[email] {e}")


if __name__ == "__main__":
    main()
