"""
Built-in tool: web_fetch
Fetch a URL and return readable text content.
HTML is stripped to plain text; JSON/plain text returned as-is.
"""
from .registry import Tool, ToolSchema

_MAX_CHARS = 30_000
_DEFAULT_MAX_RESULTS = 15  # overridden by brain at startup via agent.json web_search_max_results
_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"
)


def _make_ssl_context():
    """Return an SSL context. Uses certifi bundle if available, else system default."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        pass
    return ssl.create_default_context()


def _web_fetch(
    url: str,
    method: str = "GET",
    headers: dict | None = None,
    body: str | None = None,
    json_body: dict | None = None,
    max_chars: int = _MAX_CHARS,
) -> str:
    import urllib.request
    import urllib.error
    import ssl
    import json as _json

    method = method.upper()

    # Build request body
    data: bytes | None = None
    default_headers: dict = {"User-Agent": _UA}
    if json_body is not None:
        data = _json.dumps(json_body).encode("utf-8")
        default_headers["Content-Type"] = "application/json"
    elif body is not None:
        data = body.encode("utf-8") if isinstance(body, str) else body
        if "Content-Type" not in (headers or {}):
            default_headers["Content-Type"] = "application/x-www-form-urlencoded"

    merged_headers = {**default_headers, **(headers or {})}
    req = urllib.request.Request(url, data=data, headers=merged_headers, method=method)

    def _fetch(ctx=None):
        kwargs = {"timeout": 15}
        if ctx is not None:
            kwargs["context"] = ctx
        with urllib.request.urlopen(req, **kwargs) as resp:
            return resp.status, resp.headers.get("Content-Type", ""), resp.read()

    def _is_ssl_error(exc) -> bool:
        if isinstance(exc, ssl.SSLError):
            return True
        reason = getattr(exc, "reason", None)
        return isinstance(reason, ssl.SSLError)

    def _fallback_no_verify():
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return _fetch(ctx)

    status, content_type, raw = 200, "", b""
    try:
        status, content_type, raw = _fetch(_make_ssl_context())
    except (ssl.SSLError, urllib.error.URLError) as e:
        if _is_ssl_error(e):
            try:
                status, content_type, raw = _fallback_no_verify()
                raw = b"[SSL verification skipped]\n" + raw
            except Exception as e2:
                return f"[Error] {e2}"
        else:
            return f"[URL Error] {getattr(e, 'reason', e)}: {url}"
    except urllib.error.HTTPError as e:
        # For non-2xx, still return body so LLM can read the error message
        try:
            raw = e.read()
            content_type = e.headers.get("Content-Type", "")
            status = e.code
        except Exception:
            return f"[HTTP {e.code}] {e.reason}: {url}"
    except Exception as e:
        return f"[Error] {e}"

    # Decode
    charset = "utf-8"
    if "charset=" in content_type:
        charset = content_type.split("charset=")[-1].split(";")[0].strip()
    try:
        text = raw.decode(charset, errors="replace")
    except (LookupError, UnicodeDecodeError):
        text = raw.decode("utf-8", errors="replace")

    # Strip HTML → plain text
    if "html" in content_type.lower():
        text = _html_to_text(text)
    elif "json" in content_type.lower():
        pass  # return as-is
    # else: plain text, xml, etc. — return as-is

    text = text.strip()
    if len(text) > max_chars:
        text = text[:max_chars] + f"\n\n... [truncated — {len(text) - max_chars} chars omitted]"
    prefix = f"[HTTP {status}]\n" if status != 200 else ""
    return prefix + (text or "(empty response)")


def _html_to_text(html: str) -> str:
    """Minimal HTML → readable text conversion without external dependencies."""
    import re

    # Remove <script>, <style>, <head> blocks entirely
    html = re.sub(r"<(script|style|head)[^>]*>.*?</\1>", " ", html,
                  flags=re.DOTALL | re.IGNORECASE)
    # Replace block-level tags with newlines
    html = re.sub(r"<(br|p|div|h[1-6]|li|tr|blockquote)[^>]*>", "\n", html,
                  flags=re.IGNORECASE)
    # Replace links: keep text + URL
    html = re.sub(r'<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                  lambda m: f"{m.group(2).strip()} ({m.group(1)})" if m.group(2).strip() else m.group(1),
                  html, flags=re.DOTALL | re.IGNORECASE)
    # Strip all remaining tags
    html = re.sub(r"<[^>]+>", "", html)
    # Decode common HTML entities
    for ent, ch in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
                    ("&quot;", '"'), ("&#39;", "'"), ("&nbsp;", " ")):
        html = html.replace(ent, ch)
    # Collapse excessive blank lines
    html = re.sub(r"\n{3,}", "\n\n", html)
    return html.strip()


def _clean_html(s: str) -> str:
    import re, html as _html_mod
    s = re.sub(r"<[^>]+>", "", s)
    s = _html_mod.unescape(s)
    return " ".join(s.split()).strip()


def _format_results(query: str, results: list) -> str:
    lines = [f"Search results for: {query}\n"]
    for idx, (title, link, snippet) in enumerate(results, 1):
        lines.append(f"{idx}. {title}")
        lines.append(f"   {link}")
        if snippet:
            lines.append(f"   {snippet}")
        lines.append("")
    return "\n".join(lines).strip()


def _search_duckduckgo(query: str, max_results: int) -> list | None:
    """Try DuckDuckGo Lite. Returns list of (title, url, snippet) or None on failure."""
    import urllib.parse
    import urllib.request
    import urllib.error
    import gzip
    import re

    post_data = urllib.parse.urlencode({"q": query, "kl": "wt-wt"}).encode()
    req = urllib.request.Request(
        "https://lite.duckduckgo.com/lite/",
        data=post_data,
        method="POST",
        headers={
            "User-Agent": _UA,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Origin": "https://lite.duckduckgo.com",
            "Referer": "https://lite.duckduckgo.com/",
        },
    )
    try:
        ssl_ctx = _make_ssl_context()
        with urllib.request.urlopen(req, context=ssl_ctx, timeout=15) as resp:
            raw = resp.read()
    except Exception:
        return None

    try:
        raw = gzip.decompress(raw)
    except Exception:
        pass

    html = raw.decode("utf-8", errors="replace")
    if len(html) < 500 or ("result-link" not in html and "result__a" not in html):
        return None

    title_matches = re.findall(
        r'href="([^"]+)"[^>]*class=[\'"]result-link[\'"]>(.*?)</a>',
        html, re.DOTALL
    )
    snippet_matches = re.findall(
        r"class=['\"]result-snippet['\"][^>]*>\s*(.*?)\s*</td>",
        html, re.DOTALL
    )

    results = []
    for i, (link, title_raw) in enumerate(title_matches[:max_results]):
        title = _clean_html(title_raw)
        snippet = _clean_html(snippet_matches[i]) if i < len(snippet_matches) else ""
        if title and link.startswith("http"):
            results.append((title, link, snippet))
    return results or None


def _search_bing(query: str, max_results: int) -> list | None:
    """Try Bing search (no API key). Returns list of (title, url, snippet) or None on failure."""
    import urllib.parse
    import urllib.request
    import gzip
    import re

    url = "https://www.bing.com/search?" + urllib.parse.urlencode({"q": query, "count": max_results})
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": _UA,
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
        },
    )
    try:
        ssl_ctx = _make_ssl_context()
        with urllib.request.urlopen(req, context=ssl_ctx, timeout=15) as resp:
            raw = resp.read()
    except Exception:
        return None

    try:
        raw = gzip.decompress(raw)
    except Exception:
        pass

    html = raw.decode("utf-8", errors="replace")
    if len(html) < 500 or 'class="b_algo"' not in html:
        return None

    # Bing result structure: <h2><a href="URL">Title</a></h2> inside <li class="b_algo">
    blocks = re.findall(r'class="b_algo".*?</li>', html, re.DOTALL)
    results = []
    for block in blocks[:max_results]:
        link_m = re.search(r'<h2[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', block, re.DOTALL)
        snip_m = re.search(r'class="b_caption"[^>]*>.*?<p[^>]*>(.*?)</p>', block, re.DOTALL)
        if not link_m:
            continue
        link = link_m.group(1)
        # Bing wraps URLs in tracking redirects; decode the real URL from u= param
        if "bing.com/ck/" in link:
            import urllib.parse as _up
            import html as _html_mod
            clean_link = _html_mod.unescape(link)
            qs = _up.parse_qs(_up.urlparse(clean_link).query)
            if "u" in qs:
                try:
                    import base64
                    real = base64.urlsafe_b64decode(qs["u"][0][2:] + "==").decode("utf-8", errors="ignore")
                    if real.startswith("http"):
                        link = real
                except Exception:
                    pass
        title = _clean_html(link_m.group(2))
        snippet = _clean_html(snip_m.group(1)) if snip_m else ""
        if title and link.startswith("http"):
            results.append((title, link, snippet))
    return results or None


def _web_search(query: str, max_results: int = 0) -> str:
    """
    Search the web. Tries DuckDuckGo first, falls back to Bing if unavailable.
    No API key required.
    """
    if not max_results:
        max_results = _DEFAULT_MAX_RESULTS
    max_results = min(max(1, max_results), 20)

    results = _search_duckduckgo(query, max_results)
    if results:
        return _format_results(query, results)

    results = _search_bing(query, max_results)
    if results:
        return _format_results(query, results)

    return f"[Search Error] Both DuckDuckGo and Bing are unavailable. Try web_fetch with a direct URL."


WEB_SEARCH_TOOL = Tool(
    schema=ToolSchema(
        name="web_search",
        description=(
            "Search the web for current information. "
            "Returns a list of results with title, URL, and snippet. "
            "Use this to find recent news, documentation, package versions, or any topic. "
            "Does not require an API key."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default: 8, max: 20)",
                },
            },
            "required": ["query"],
        },
    ),
    fn=_web_search,
)


WEB_FETCH_TOOL = Tool(
    schema=ToolSchema(
        name="web_fetch",
        description=(
            "Fetch a URL and return its text content. Supports GET, POST, PUT, PATCH, DELETE. "
            "HTML pages are converted to readable plain text; JSON returned as-is. "
            "Use for REST APIs, webhooks, reading documentation, or any HTTP request."
        ),
        parameters={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to fetch (http or https)",
                },
                "method": {
                    "type": "string",
                    "description": "HTTP method: GET (default), POST, PUT, PATCH, DELETE",
                },
                "headers": {
                    "type": "object",
                    "description": "Custom request headers as key-value pairs",
                },
                "json_body": {
                    "type": "object",
                    "description": "Request body as JSON object (sets Content-Type: application/json)",
                },
                "body": {
                    "type": "string",
                    "description": "Raw request body string (use json_body for JSON payloads)",
                },
                "max_chars": {
                    "type": "integer",
                    "description": f"Maximum characters to return (default: {_MAX_CHARS})",
                },
            },
            "required": ["url"],
        },
    ),
    fn=_web_fetch,
)
