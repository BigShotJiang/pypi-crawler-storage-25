"""
Built-in tools: task store
Dynamic task/bug tracking, separated from static project memory.
"""
from __future__ import annotations
from .registry import Tool, ToolSchema

_manager = None  # TaskManager injected by Brain at startup


def _require_manager():
    if _manager is None:
        raise RuntimeError("TaskManager not initialised — restart mcode")
    return _manager


# ── task_add ───────────────────────────────────────────────────────────────────

def _task_add(title: str, description: str = "") -> str:
    mgr = _require_manager()
    task = mgr.add(title, description)
    return f"Task #{task['id']} added: {task['title']}"


TASK_ADD_TOOL = Tool(
    schema=ToolSchema(
        name="task_add",
        description=(
            "Add a new open task or bug to the task store for the current project. "
            "Use this when a bug is discovered, a task is identified, or follow-up work is needed. "
            "Do NOT write bug/task status to project memory — use this tool instead."
        ),
        parameters={
            "type": "object",
            "properties": {
                "title":       {"type": "string", "description": "Short task title (one line)"},
                "description": {"type": "string", "description": "Details, context, or reproduction steps", "default": ""},
            },
            "required": ["title"],
        },
    ),
    fn=_task_add,
)


# ── task_list ──────────────────────────────────────────────────────────────────

def _task_list(status: str = "open") -> str:
    mgr = _require_manager()
    tasks = mgr.list(status)
    if not tasks:
        label = status or "all"
        return f"No {label} tasks."
    lines = [f"{len(tasks)} task(s) [{status or 'all'}]:\n"]
    for t in tasks:
        done_str = f"  done: {t['done_at']}" if t["done_at"] else ""
        lines.append(
            f"  #{t['id']} [{t['status']}] {t['title']}\n"
            f"       created: {t['created_at']}{done_str}"
        )
        if t.get("description"):
            lines.append(f"       {t['description']}")
    return "\n".join(lines)


TASK_LIST_TOOL = Tool(
    schema=ToolSchema(
        name="task_list",
        description=(
            "List tasks for the current project. "
            "Call this when the user asks what's pending, says '继续' or 'continue', "
            "asks about current work status, or asks whether tasks are done / complete. "
            "ALWAYS call this tool for task status questions — never rely on memory or project memory to answer. "
            "When asking about a specific past or completed task, use status='done' or status='' (all) — "
            "do not use the default 'open' filter or you will miss completed tasks."
        ),
        parameters={
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Filter by status: 'open' (default), 'done', 'cancelled', or '' for all",
                    "default": "open",
                },
            },
            "required": [],
        },
    ),
    fn=_task_list,
)


# ── task_done ──────────────────────────────────────────────────────────────────

def _task_done(task_id: int) -> str:
    mgr = _require_manager()
    task = mgr.done(task_id)
    if not task:
        return f"Task #{task_id} not found."
    return f"Task #{task_id} marked done: {task['title']}"


TASK_DONE_TOOL = Tool(
    schema=ToolSchema(
        name="task_done",
        description=(
            "Mark a task as done. Call this immediately when a bug is fixed or a task is completed — "
            "do not wait until the end of the conversation. "
            "If a task requires multiple steps, call task_done only after ALL steps are confirmed complete."
        ),
        parameters={
            "type": "object",
            "properties": {
                "task_id": {"type": "integer", "description": "Task ID from task_list"},
            },
            "required": ["task_id"],
        },
    ),
    fn=_task_done,
)


# ── task_update ────────────────────────────────────────────────────────────────

def _task_update(task_id: int, title: str = "", description: str = "") -> str:
    mgr = _require_manager()
    task = mgr.update(task_id, title, description)
    if not task:
        return f"Task #{task_id} not found."
    return f"Task #{task_id} updated: {task['title']}"


TASK_UPDATE_TOOL = Tool(
    schema=ToolSchema(
        name="task_update",
        description="Update a task's title or description.",
        parameters={
            "type": "object",
            "properties": {
                "task_id":     {"type": "integer", "description": "Task ID from task_list"},
                "title":       {"type": "string",  "description": "New title (leave empty to keep current)", "default": ""},
                "description": {"type": "string",  "description": "New description (leave empty to keep current)", "default": ""},
            },
            "required": ["task_id"],
        },
    ),
    fn=_task_update,
)


# ── task_cancel ────────────────────────────────────────────────────────────────

def _task_cancel(task_id: int) -> str:
    mgr = _require_manager()
    task = mgr.cancel(task_id)
    if not task:
        return f"Task #{task_id} not found."
    return f"Task #{task_id} cancelled: {task['title']}"


TASK_CANCEL_TOOL = Tool(
    schema=ToolSchema(
        name="task_cancel",
        description="Cancel a task (won't be done / no longer relevant).",
        parameters={
            "type": "object",
            "properties": {
                "task_id": {"type": "integer", "description": "Task ID from task_list"},
            },
            "required": ["task_id"],
        },
    ),
    fn=_task_cancel,
)


# ── TOOLS export ───────────────────────────────────────────────────────────────

TOOLS = [
    TASK_ADD_TOOL,
    TASK_LIST_TOOL,
    TASK_DONE_TOOL,
    TASK_UPDATE_TOOL,
    TASK_CANCEL_TOOL,
]
