"""
Built-in tool: pdf_read
Full-coverage PDF extraction: text, tables, images, metadata.

Dependencies (install as needed):
  pip install pdfplumber   — text, tables, image coords (required)
  pip install Pillow       — image saving (required for extract_images=True)
  pip install pypdf        — fallback text extraction if pdfplumber unavailable
"""
import os
import re
from .registry import Tool, ToolSchema


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_page_range(pages_str: str, total: int) -> list[int]:
    """Parse '1-3', '1,3,5', '2' into sorted 0-based indices."""
    indices: set[int] = set()
    for part in pages_str.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            indices.update(range(int(a) - 1, min(int(b), total)))
        else:
            idx = int(part) - 1
            if 0 <= idx < total:
                indices.add(idx)
    return sorted(indices)


def _format_table(rows: list[list]) -> str:
    """Render a list-of-lists table as aligned plain text."""
    if not rows:
        return ""
    # Normalize: all rows same width, convert None → ""
    col_count = max(len(r) for r in rows)
    norm = [[str(c) if c is not None else "" for c in (r + [""] * col_count)][:col_count]
            for r in rows]
    widths = [max(len(norm[ri][ci]) for ri in range(len(norm)))
              for ci in range(col_count)]
    widths = [min(w, 25) for w in widths]

    def fmt_row(r):
        return " | ".join(c[:25].ljust(widths[i]) for i, c in enumerate(r))

    lines = [fmt_row(norm[0])]
    if len(norm) > 1:
        lines.append("-+-".join("-" * w for w in widths))
        for row in norm[1:]:
            lines.append(fmt_row(row))
    return "\n".join(lines)


def _extract_tables_from_page(page) -> list[str]:
    """Try multiple table strategies; return list of formatted table strings."""
    results = []
    seen: set[str] = set()

    for settings in (
        {},  # default: line-based (good for bordered tables)
        {"vertical_strategy": "text", "horizontal_strategy": "text"},  # text-based (borderless)
    ):
        try:
            tables = page.extract_tables(table_settings=settings) if settings else page.extract_tables()
        except Exception:
            continue
        for tbl in (tables or []):
            if not tbl:
                continue
            formatted = _format_table(tbl)
            if formatted and formatted not in seen and len(formatted) > 20:
                seen.add(formatted)
                results.append(formatted)

    return results


def _save_image(img_dict: dict, out_path: str) -> bool:
    """
    Extract and save a PDF image to out_path.
    Returns True on success.
    Supports: raw RGB (FlateDecode), JPEG (DCTDecode), PNG-compressed.
    """
    try:
        stream = img_dict.get("stream")
        if stream is None:
            return False

        # Detect filter
        stream_obj = stream
        filters = []
        raw_filter = getattr(stream_obj, "attrs", {}).get("Filter", None)
        if raw_filter is not None:
            if hasattr(raw_filter, "name"):
                filters = [raw_filter.name]
            elif isinstance(raw_filter, list):
                filters = [f.name if hasattr(f, "name") else str(f) for f in raw_filter]

        # JPEG: save raw bytes directly
        if "DCTDecode" in filters:
            raw = stream_obj.get_rawdata()
            with open(out_path.rsplit(".", 1)[0] + ".jpg", "wb") as f:
                f.write(raw)
            return True

        # PNG embedded: FlateDecode over RGBA/RGB
        data = stream_obj.get_data()  # decompressed raw bytes
        w, h = img_dict["srcsize"]
        bits = img_dict.get("bits", 8)
        colorspace = img_dict.get("colorspace", [])

        # Determine mode
        cs_str = str(colorspace)
        if "DeviceRGB" in cs_str or "RGB" in cs_str:
            mode = "RGB"
            expected = w * h * 3
        elif "DeviceCMYK" in cs_str or "CMYK" in cs_str:
            mode = "CMYK"
            expected = w * h * 4
        elif "DeviceGray" in cs_str or "Gray" in cs_str:
            mode = "L"
            expected = w * h
        else:
            # Guess from data length
            if len(data) == w * h * 4:
                mode = "RGBA"
            elif len(data) == w * h * 3:
                mode = "RGB"
            elif len(data) == w * h:
                mode = "L"
            else:
                return False

        try:
            from PIL import Image as _PIL
        except ImportError:
            return False

        img = _PIL.frombytes(mode, (w, h), data)
        # Convert CMYK → RGB for compatibility
        if mode == "CMYK":
            img = img.convert("RGB")
        img.save(out_path)
        return True

    except Exception:
        return False


def _get_metadata(pdf) -> str:
    """Extract document metadata."""
    try:
        meta = pdf.metadata or {}
        parts = []
        for key in ("Title", "Author", "Subject", "Creator", "Producer", "CreationDate"):
            val = meta.get(key) or meta.get(f"/{key}")
            if val:
                s = str(val).strip()
                if s:
                    # Truncate very long fields (e.g. author lists)
                    s = s[:200] + "..." if len(s) > 200 else s
                    parts.append(f"{key}: {s}")
        return ", ".join(parts) if parts else ""
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Main function
# ---------------------------------------------------------------------------

def _pdf_read(
    path: str,
    pages: str | None = None,
    extract_images: bool = True,
    image_dir: str | None = None,
    max_chars: int = 80_000,
) -> str:
    """
    Extract text, tables, images and metadata from a PDF.

    path          — path to the PDF file
    pages         — page range: '1-3', '1,3,5', '2', or None for all
    extract_images — save embedded images to disk and report paths
    image_dir     — directory to save images (default: same folder as PDF)
    max_chars     — max characters in returned text
    """
    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"File not found: {path}")

    # ---- Try pdfplumber ----
    try:
        import pdfplumber
    except ImportError:
        return _pdf_read_fallback(path, pages, max_chars)

    import tempfile
    img_out_dir = os.path.expanduser(image_dir) if image_dir else tempfile.gettempdir()
    pdf_basename = os.path.splitext(os.path.basename(path))[0]

    output_parts: list[str] = []

    with pdfplumber.open(path) as pdf:
        total = len(pdf.pages)
        page_indices = _parse_page_range(pages, total) if pages else list(range(total))

        # Metadata
        meta = _get_metadata(pdf)
        header = f"[{os.path.basename(path)}]  Pages: {total}"
        if meta:
            header += f"\n[Metadata] {meta}"
        output_parts.append(header)

        # Image counter (global across pages)
        img_counter = [0]

        for i in page_indices:
            page = pdf.pages[i]
            page_parts: list[str] = [f"\n[Page {i + 1}]"]
            has_content = False

            # --- Images ---
            if extract_images and page.images:
                saved_paths = []
                for img_dict in page.images:
                    img_counter[0] += 1
                    # Try JPEG first (DCTDecode), then PNG
                    out_path = os.path.join(
                        img_out_dir,
                        f"{pdf_basename}_p{i+1}_img{img_counter[0]}.png"
                    )
                    if _save_image(img_dict, out_path):
                        # _save_image may change extension to .jpg
                        actual = out_path
                        jpg = out_path.rsplit(".", 1)[0] + ".jpg"
                        if os.path.isfile(jpg):
                            actual = jpg
                        w, h = img_dict["srcsize"]
                        saved_paths.append(f"  → {actual}  ({w}×{h}px)")
                    else:
                        saved_paths.append(
                            f"  → [Image {img_counter[0]}: extraction failed"
                            " — install Pillow: pip install Pillow]"
                        )
                if saved_paths:
                    page_parts.append(f"[Images × {len(saved_paths)}]")
                    page_parts.extend(saved_paths)
                    # Emit IMAGE_ATTACH markers so vision models can analyse extracted images
                    for sp in saved_paths:
                        # saved_paths entries: "  → /actual/path  (WxHpx)" or error strings
                        if sp.strip().startswith("→") and "extraction failed" not in sp:
                            img_file = sp.strip()[1:].split("  ")[0].strip()
                            page_parts.append(f"[IMAGE_ATTACH:{img_file}]")
                    has_content = True

            # --- Tables ---
            tables = _extract_tables_from_page(page)
            for t_idx, tbl in enumerate(tables, 1):
                page_parts.append(f"[Table {t_idx}]")
                page_parts.append(tbl)
                has_content = True

            # --- Text ---
            text = (page.extract_text() or "").strip()
            if text:
                page_parts.append("[Text]")
                page_parts.append(text)
                has_content = True

            if has_content:
                output_parts.append("\n".join(page_parts))

    result = "\n\n".join(output_parts)
    if not result.strip():
        return "(No extractable content — PDF may be image-based or encrypted)"

    if len(result) > max_chars:
        result = result[:max_chars] + f"\n\n... [truncated — {len(result) - max_chars} chars omitted]"
    return result


def _pdf_read_fallback(path: str, pages: str | None, max_chars: int) -> str:
    """Fallback using pypdf when pdfplumber is unavailable."""
    try:
        from pypdf import PdfReader
    except ImportError:
        return (
            "[Error] No PDF library found.\n"
            "Install: pip install pdfplumber Pillow"
        )
    reader = PdfReader(path)
    total = len(reader.pages)
    page_indices = _parse_page_range(pages, total) if pages else list(range(total))
    parts = [f"[{os.path.basename(path)}]  Pages: {total}  (pypdf fallback — install pdfplumber for full features)"]
    for i in page_indices:
        text = reader.pages[i].extract_text() or ""
        if text.strip():
            parts.append(f"\n[Page {i + 1}]\n{text.strip()}")
    result = "\n\n".join(parts)
    if len(result) > max_chars:
        result = result[:max_chars] + f"\n\n... [truncated]"
    return result


# ---------------------------------------------------------------------------
# Tool definition
# ---------------------------------------------------------------------------

PDF_READ_TOOL = Tool(
    schema=ToolSchema(
        name="pdf_read",
        description=(
            "Extract text, tables, images and metadata from a PDF file. "
            "Images are saved to disk and their paths are reported. "
            "Requires: pip install pdfplumber Pillow"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the PDF file",
                },
                "pages": {
                    "type": "string",
                    "description": 'Pages to extract: "1-3", "1,3,5", or "2". Default: all pages.',
                },
                "extract_images": {
                    "type": "boolean",
                    "description": "Extract and save embedded images to disk (default: true)",
                },
                "image_dir": {
                    "type": "string",
                    "description": "Directory to save extracted images (default: same folder as PDF)",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "Maximum characters to return (default: 80000)",
                },
            },
            "required": ["path"],
        },
    ),
    fn=_pdf_read,
)
