"""
Built-in tools: resource registry
Lets the LLM find, register, and manage local file resources.
"""
from __future__ import annotations
import datetime
import json
import os

from .registry import Tool, ToolSchema

# ResourceManager instance injected by Brain at startup
_manager = None


def _require_manager():
    if _manager is None:
        raise RuntimeError("ResourceManager not initialised — restart mcode")
    return _manager


# ── resource_find ──────────────────────────────────────────────────────────────

def _resource_find(query: str) -> str:
    mgr = _require_manager()
    results = mgr.find(query)
    if not results:
        return f"No resources found matching: {query!r}"
    lines = [f"Found {len(results)} resource(s) for {query!r}:\n"]
    for r in results:
        tags = ", ".join(r["tags"]) if r["tags"] else "—"
        mtime = r.get("file_mtime")
        mtime_str = (
            datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
            if mtime else "—"
        )
        lines.append(
            f"  {r['name']}\n"
            f"    path:     {r['path']}\n"
            f"    modified: {mtime_str}\n"
            f"    desc:     {r['description']}\n"
            f"    tags:     {tags}\n"
        )
    return "\n".join(lines)


RESOURCE_FIND_TOOL = Tool(
    schema=ToolSchema(
        name="resource_find",
        description=(
            "Search the local resource registry by keyword. "
            "Use this when the task requires local files or data (spreadsheets, PDFs, documents). "
            "Returns file paths and descriptions so you can read them with appropriate tools."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Keywords describing the type of file or task (e.g. '客户 拜访', 'price list', 'contract')",
                },
            },
            "required": ["query"],
        },
    ),
    fn=_resource_find,
)


# ── resource_scan ──────────────────────────────────────────────────────────────

def _resource_scan(path: str) -> str:
    """Classify a single file and stage it for registration."""
    mgr = _require_manager()
    path = os.path.expanduser(os.path.normpath(path))
    if not os.path.isfile(path):
        return f"File not found: {path}"
    summary = mgr.scan_file(path)
    classification = mgr._classify_file(path, summary)
    mgr._pending = [{"path": path, **classification}]
    tags = ", ".join(classification.get("tags", []))
    return (
        f"File: {path}\n"
        f"Size: {os.path.getsize(path):,} bytes\n"
        f"---\n"
        f"Proposed registration:\n"
        f"  name:  {classification.get('name', '')}\n"
        f"  tags:  {tags}\n"
        f"  desc:  {classification.get('description', '')}\n"
        f"\n→ Staged for registration. The CLI will prompt the user for y/N confirmation automatically."
    )


RESOURCE_SCAN_TOOL = Tool(
    schema=ToolSchema(
        name="resource_scan",
        description=(
            "Classify a single file and stage it for registration. "
            "The CLI will automatically prompt the user for y/N confirmation — "
            "never call resource_confirm or resource_register directly."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or ~ path to the file",
                },
            },
            "required": ["path"],
        },
    ),
    fn=_resource_scan,
)


# ── resource_register ──────────────────────────────────────────────────────────

def _resource_register(
    path: str,
    name: str,
    description: str,
    tags: list | str,
) -> str:
    mgr = _require_manager()
    if isinstance(tags, str):
        try:
            tags = json.loads(tags)
        except Exception:
            tags = [t.strip() for t in tags.split(",") if t.strip()]
    rec = mgr.register(path, name, description, tags)
    return (
        f"Registered: {rec['name']}\n"
        f"  path:  {rec['path']}\n"
        f"  tags:  {', '.join(rec['tags'])}"
    )


RESOURCE_REGISTER_TOOL = Tool(
    schema=ToolSchema(
        name="resource_register",
        description="Register a local file in the resource registry after user confirms classification.",
        parameters={
            "type": "object",
            "properties": {
                "path":        {"type": "string", "description": "Absolute or ~ path to the file"},
                "name":        {"type": "string", "description": "Short display name for this resource"},
                "description": {"type": "string", "description": "What this file contains and what tasks it helps with"},
                "tags":        {"type": "array",  "items": {"type": "string"}, "description": "Keywords for search"},
            },
            "required": ["path", "name", "description", "tags"],
        },
    ),
    fn=_resource_register,
)


# ── resource_list ──────────────────────────────────────────────────────────────

def _resource_list() -> str:
    mgr = _require_manager()
    records = mgr.list_all()
    if not records:
        return "No resources registered.\nUse resource_scan or resource_scan_dir to add files."
    lines = [f"Resource registry ({len(records)} entries):\n"]
    for r in records:
        tags = ", ".join(r["tags"]) if r["tags"] else "—"
        used = f"used {r['use_count']}×" if r["use_count"] else "never used"
        lines.append(f"  {r['name']}")
        lines.append(f"    {r['path']}")
        lines.append(f"    {r['description']}")
        lines.append(f"    tags: {tags}  |  {used}")
    return "\n".join(lines)


RESOURCE_LIST_TOOL = Tool(
    schema=ToolSchema(
        name="resource_list",
        description="List all registered resources.",
        parameters={"type": "object", "properties": {}, "required": []},
    ),
    fn=_resource_list,
)


# ── resource_scan_dir ─────────────────────────────────────────────────────────

def _resource_scan_dir(directory: str, recursive: bool = False) -> str:
    mgr = _require_manager()
    directory = os.path.expanduser(os.path.normpath(directory))
    if not os.path.isdir(directory):
        return f"Not a directory: {directory}"

    proposals, already = mgr.classify_dir(directory, recursive=recursive)

    parts = [f"Directory: {directory}"]
    if already:
        parts.append(f"\nAlready registered ({len(already)} skipped):")
        for p in already:
            parts.append(f"  ✓ {os.path.basename(p)}")

    if not proposals:
        if already:
            return "\n".join(parts) + "\n\nAll files already registered."
        return f"No scannable files found in {directory}"

    parts.append(f"\nClassified {len(proposals)} new file(s):\n")
    parts.append(f"{'File':<30} {'Name':<20} Tags")
    parts.append("─" * 70)
    for p in proposals:
        fname = os.path.basename(p["path"])[:28]
        name  = p["name"][:18]
        tags  = ", ".join(p["tags"][:4])
        parts.append(f"{fname:<30} {name:<20} {tags}")

    parts.append("\nDescriptions:")
    for p in proposals:
        parts.append(f"  • {p['name']}: {p['description']}")

    parts.append("\n→ Proposals staged. The CLI will prompt the user for y/N confirmation automatically.")
    return "\n".join(parts)


RESOURCE_SCAN_DIR_TOOL = Tool(
    schema=ToolSchema(
        name="resource_scan_dir",
        description=(
            "Scan a directory and classify all supported files "
            "(xlsx, pdf, csv, txt, md, json, etc.) for batch registration. "
            "The CLI will automatically prompt the user for y/N confirmation — "
            "never call resource_confirm or resource_register directly."
        ),
        parameters={
            "type": "object",
            "properties": {
                "directory": {
                    "type": "string",
                    "description": "Absolute or ~ path to the directory to scan",
                },
                "recursive": {
                    "type": "boolean",
                    "description": "Scan subdirectories recursively (default: false)",
                    "default": False,
                },
            },
            "required": ["directory"],
        },
    ),
    fn=_resource_scan_dir,
)


# ── resource_sync ──────────────────────────────────────────────────────────────

def _resource_sync() -> str:
    mgr = _require_manager()
    result = mgr.sync()
    return (
        f"Sync complete: checked {result['checked']} file(s), "
        f"removed {result['removed']} deleted, "
        f"updated {result['updated']} changed."
    )


RESOURCE_SYNC_TOOL = Tool(
    schema=ToolSchema(
        name="resource_sync",
        description=(
            "Scan all registered resources for changes or deletions and update the registry. "
            "Runs automatically at startup; call manually if files may have changed."
        ),
        parameters={"type": "object", "properties": {}, "required": []},
    ),
    fn=_resource_sync,
)


# ── resource_confirm ───────────────────────────────────────────────────────────

def _resource_confirm() -> str:
    mgr = _require_manager()
    if not mgr._pending and not mgr._pending_delete:
        return "No staged operations. Run resource_scan_dir or resource_delete first."
    result = mgr.commit_pending()
    lines = []
    if result["registered"]:
        lines.append(f"Registered {len(result['registered'])} file(s):")
        for r in result["registered"]:
            lines.append(f"  ✓ {r['name']}  →  {r['path']}")
    if result["deleted"]:
        lines.append(f"Deleted {len(result['deleted'])} resource(s):")
        for r in result["deleted"]:
            lines.append(f"  ✗ {r['name']}  →  {r['path']}")
    if not lines:
        return "No operations completed (all failed)."
    return "\n".join(lines)


RESOURCE_CONFIRM_TOOL = Tool(
    schema=ToolSchema(
        name="resource_confirm",
        description=(
            "Commit all staged resource operations. "
            "The CLI handles confirmation automatically — do not call this directly."
        ),
        parameters={"type": "object", "properties": {}, "required": []},
    ),
    fn=_resource_confirm,
)


# ── resource_delete ────────────────────────────────────────────────────────────

def _resource_delete(query: str) -> str:
    mgr = _require_manager()
    results = mgr.stage_delete(query)
    if not results:
        return f"No resources found matching: {query!r}. Nothing staged."
    lines = [f"Staged {len(results)} resource(s) for deletion:\n"]
    for r in results:
        tags = ", ".join(r["tags"]) if r["tags"] else "—"
        lines.append(f"  {r['name']}\n    path: {r['path']}\n    tags: {tags}\n")
    lines.append("→ The CLI will prompt the user for y/N confirmation automatically.")
    return "\n".join(lines)


RESOURCE_DELETE_TOOL = Tool(
    schema=ToolSchema(
        name="resource_delete",
        description=(
            "Search the registry by keyword and stage matched entries for deletion. "
            "The actual files are NOT deleted, only the registry entries. "
            "The CLI will prompt the user for y/N confirmation automatically."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Keywords to find the resource(s) to delete (e.g. 'price list', 'all')",
                },
            },
            "required": ["query"],
        },
    ),
    fn=_resource_delete,
)


# ── TOOLS export ───────────────────────────────────────────────────────────────
# resource_confirm and resource_register excluded: CLI handles confirmation directly.

TOOLS = [
    RESOURCE_FIND_TOOL,
    RESOURCE_SCAN_TOOL,
    RESOURCE_SCAN_DIR_TOOL,
    RESOURCE_LIST_TOOL,
    RESOURCE_SYNC_TOOL,
    RESOURCE_DELETE_TOOL,
]
