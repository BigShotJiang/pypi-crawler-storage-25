"""Tests for LLMAdapter retry mechanism."""
import os
import sys
import time
from unittest.mock import MagicMock, patch, call

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.llm import LLMAdapter


def _make_adapter():
    """Create a minimal openai adapter without actually connecting."""
    adapter = LLMAdapter.__new__(LLMAdapter)
    adapter.provider = "openai"
    adapter.model = "gpt-4o"
    adapter.extra_body = {}
    adapter.thinking = False
    adapter.thinking_budget = 8000
    adapter.timeout = 60
    adapter._client = MagicMock()
    adapter.auth_adapter = None
    return adapter


# ── _is_retriable ─────────────────────────────────────────────────────────────

class _FakeError(Exception):
    pass


class _FakeAPIStatusError(Exception):
    def __init__(self, status_code):
        self.status_code = status_code


def test_is_retriable_rate_limit():
    adapter = _make_adapter()
    err = _FakeError()
    err.__class__.__name__ = "RateLimitError"
    type(err).__name__ = "RateLimitError"
    # patch name via subclass
    class RateLimitError(Exception): pass
    assert adapter._is_retriable(RateLimitError())


def test_is_retriable_overloaded():
    adapter = _make_adapter()
    class OverloadedError(Exception): pass
    assert adapter._is_retriable(OverloadedError())


def test_is_retriable_connection_error():
    adapter = _make_adapter()
    class APIConnectionError(Exception): pass
    assert adapter._is_retriable(APIConnectionError())


def test_is_retriable_timeout():
    adapter = _make_adapter()
    class APITimeoutError(Exception): pass
    assert adapter._is_retriable(APITimeoutError())


def test_is_retriable_status_500():
    adapter = _make_adapter()
    class APIStatusError(Exception):
        status_code = 500
    assert adapter._is_retriable(APIStatusError())


def test_is_retriable_status_429():
    adapter = _make_adapter()
    class APIStatusError(Exception):
        status_code = 429
    assert adapter._is_retriable(APIStatusError())


def test_is_retriable_status_529():
    adapter = _make_adapter()
    class APIStatusError(Exception):
        status_code = 529
    assert adapter._is_retriable(APIStatusError())


def test_not_retriable_status_400():
    adapter = _make_adapter()
    class APIStatusError(Exception):
        status_code = 400
    assert not adapter._is_retriable(APIStatusError())


def test_not_retriable_value_error():
    adapter = _make_adapter()
    assert not adapter._is_retriable(ValueError("bad input"))


def test_not_retriable_auth_error():
    adapter = _make_adapter()
    class AuthenticationError(Exception): pass
    assert not adapter._is_retriable(AuthenticationError())


# ── _call_with_retry behaviour ────────────────────────────────────────────────

def test_succeeds_on_first_try():
    adapter = _make_adapter()
    fn = MagicMock(return_value="ok")
    with patch.object(adapter, "_is_retriable", return_value=False):
        result = adapter._call_with_retry(fn, "arg1", key="val")
    fn.assert_called_once_with("arg1", key="val")
    assert result == "ok"


def test_retries_on_retriable_error_then_succeeds():
    adapter = _make_adapter()

    class RateLimitError(Exception): pass

    calls = [RateLimitError("429"), RateLimitError("429"), "success"]

    def side_effect(*a, **kw):
        result = calls.pop(0)
        if isinstance(result, Exception):
            raise result
        return result

    fn = MagicMock(side_effect=side_effect)

    with patch("time.sleep"), patch("sys.stderr"):
        result = adapter._call_with_retry(fn)

    assert result == "success"
    assert fn.call_count == 3


def test_raises_after_max_retries():
    adapter = _make_adapter()

    class RateLimitError(Exception): pass

    fn = MagicMock(side_effect=RateLimitError("always fails"))

    with patch("time.sleep"), patch("sys.stderr"):
        with pytest.raises(RateLimitError):
            adapter._call_with_retry(fn)

    assert fn.call_count == adapter._MAX_RETRIES + 1


def test_non_retriable_error_raises_immediately():
    adapter = _make_adapter()

    fn = MagicMock(side_effect=ValueError("bad"))

    with patch("time.sleep") as mock_sleep:
        with pytest.raises(ValueError):
            adapter._call_with_retry(fn)

    fn.assert_called_once()
    mock_sleep.assert_not_called()


def test_retry_delay_increases():
    adapter = _make_adapter()

    class RateLimitError(Exception): pass

    fn = MagicMock(side_effect=RateLimitError("fail"))
    sleep_calls = []

    def capture_sleep(t):
        sleep_calls.append(t)

    with patch("time.sleep", side_effect=capture_sleep), patch("sys.stderr"):
        with pytest.raises(RateLimitError):
            adapter._call_with_retry(fn)

    # Each delay should be >= previous (exponential growth)
    assert len(sleep_calls) == adapter._MAX_RETRIES
    for i in range(1, len(sleep_calls)):
        assert sleep_calls[i] >= sleep_calls[i - 1] * 0.9  # allow jitter tolerance
