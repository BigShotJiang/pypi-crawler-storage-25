"""
Memory Recall Evaluation Suite — chatmem/memory/recent_memory

Simulates 8 months of development on a 20K-LOC e-commerce backend project
(60 session summaries, spanning ~240 to 7 days ago).

Covers:
  1. get_for_context token cap enforcement
  2. get_for_context ordering (newest first)
  3. Temporal date-filter search accuracy
  4. Decay resilience (score≈0 entries still BM25-searchable)
  5. Negation/rejection memory retrieval
  6. Multi-session continuity (early decisions recalled in late sessions)
  7. Large-corpus BM25 accuracy (MRR / Hit@k / Recall@k)
  8. Search-hit decay reset (last_accessed_at updated, score reset to 1.0)

Outputs:
  docs/memory_recall_report.html  — self-contained evaluation report

Run:
    python3 -m pytest tests/test_memory_recall.py -v -s
"""

import math
import os
import sqlite3
import sys
import tempfile
import time
from datetime import datetime, timedelta
from typing import Optional
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.memory.recent_memory import RecentMemory, _tokenize, _bm25
from control.chatmem.token_counter import count_tokens

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

NOW = time.time()


def days_ago(n: float) -> float:
    return NOW - n * 86400.0


def _make_compressor():
    m = MagicMock()
    m.compress_for_session_context.return_value = "[compressed summary]"
    return m


def _insert_raw(db_path: str, turn_id: int, content: str, ts: float,
                score: float = 1.0, stability: float = 21.0,
                compression_level: int = 1, pinned: int = 0):
    """Insert an entry directly into DB with controlled timestamp and score."""
    tokens = count_tokens(content)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """INSERT INTO recent_memory
               (turn_id, content, compression_level, token_count, created_at,
                score, stability, search_hit_count, pinned)
               VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)""",
            (turn_id, content, compression_level, tokens, ts, score, stability, pinned),
        )


# ─────────────────────────────────────────────────────────────────────────────
# 60-entry corpus: 8-month e-commerce backend project (~20K LOC)
# Format: (turn_id, content, days_ago_float)
#
# Phase 1 (month 1): sessions 1-8,   ~240-210 days ago  → score ≈ 0
# Phase 2 (month 2): sessions 9-16,  ~200-170 days ago  → score ≈ 0
# Phase 3 (month 3): sessions 17-24, ~160-130 days ago  → score ≈ 0.001
# Phase 4 (month 4): sessions 25-32, ~120-95 days ago   → score ≈ 0.003-0.01
# Phase 5 (month 5): sessions 33-40, ~85-65 days ago    → score ≈ 0.015-0.045
# Phase 6 (month 6): sessions 41-48, ~55-38 days ago    → score ≈ 0.07-0.16
# Phase 7 (month 7): sessions 49-54, ~30-18 days ago    → score ≈ 0.24-0.42
# Phase 8 (month 8): sessions 55-60, ~14-7 days ago     → score ≈ 0.51-0.72
# ─────────────────────────────────────────────────────────────────────────────

CORPUS: list[tuple[int, str, float]] = [

    # ── Phase 1: Architecture & Stack (240-210 days) ──────────────────────────
    (1,  "项目立项：构建电商后端平台，技术栈选型讨论。后端采用 Python FastAPI，"
         "数据库 PostgreSQL 14，缓存 Redis 7，消息队列 Kafka。"
         "放弃了 Django REST Framework，认为其过重不适合高并发场景。",
         238.0),

    (2,  "API 设计规范确立：统一 RESTful 风格，URL 前缀 /api/v1/，"
         "错误响应格式 {code, message, data}，分页统一用 cursor-based。"
         "决定不使用 GraphQL，复杂度收益比不划算。",
         235.0),

    (3,  "数据库 schema 初版：users / orders / products / categories / cart 五张核心表。"
         "决定不使用 ORM（SQLAlchemy 太慢），改用 asyncpg 直接写 SQL，"
         "压测中 asyncpg 比 SQLAlchemy ORM 快 40%。",
         232.0),

    (4,  "认证方案确定：JWT，access token 有效期 2 小时，refresh token 7 天。"
         "密码存储 bcrypt + 随机 salt，迭代次数 12。"
         "放弃了 OAuth2 第三方登录（时间紧，下一期再做）。",
         229.0),

    (5,  "项目目录结构约定：app/api（路由层）、app/services（业务逻辑）、"
         "app/repositories（数据访问）、app/models（Pydantic 模型）。"
         "禁止路由层直接操作数据库，所有 DB 调用必须经过 repository。",
         226.0),

    (6,  "开发环境搭建：Docker Compose 本地起 PostgreSQL + Redis + Kafka，"
         "使用 pre-commit hooks 强制 black + isort + mypy 通过才能提交。"
         "CI 使用 GitHub Actions，PR 必须通过全量测试才能合并。",
         223.0),

    (7,  "认证模块完成：/auth/login、/auth/refresh、/auth/logout 三个接口。"
         "refresh token 存 Redis，退出时删除。Token 黑名单通过 Redis SET 实现。"
         "接口级别的权限控制用 FastAPI Depends 注入。",
         219.0),

    (8,  "用户管理模块完成：注册（邮箱验证）、修改个人信息、密码重置（SendGrid 发邮件）。"
         "邮件模板 ID 存 AWS Secrets Manager，本地开发用 Mailtrap 测试。",
         215.0),

    # ── Phase 2: Product & Catalog (200-170 days) ─────────────────────────────
    (9,  "商品模块：商品 CRUD、SKU 管理、图片上传（OSS）、分类树（闭包表存储）。"
         "商品详情接口响应平均 280ms，主要瓶颈在分类树递归查询，待优化。",
         199.0),

    (10, "商品搜索功能：接入 Elasticsearch 8.x，中文分词使用 IK Analyzer 插件。"
         "支持关键词搜索、价格区间筛选、按销量/评分/价格排序、分类导航。"
         "索引设计：将商品名称、描述、品牌字段分配不同 boost 权重。",
         196.0),

    (11, "购物车模块：基于 Redis Hash 存储（key=cart:{user_id}），"
         "支持加入购物车、修改数量、删除、清空。"
         "合并购物车逻辑（未登录 → 登录后自动合并本地 cookie 购物车）。",
         192.0),

    (12, "商品库存管理：库存扣减使用数据库乐观锁（version 字段 CAS），"
         "防止超卖。库存预警（低于安全库存）通过 Kafka 消息 → Slack 通知。"
         "库存快照每小时写一次 ClickHouse，用于报表分析。",
         188.0),

    (13, "订单模块：创建订单、取消订单、查询订单、订单列表分页。"
         "状态机：pending → paid → processing → shipped → delivered → completed / cancelled。"
         "订单号生成：雪花算法（snowflake ID），机器 ID 从 k8s pod 名称中解析。",
         184.0),

    (14, "支付集成：微信支付 v3 API + 支付宝 SDK，支付回调 HMAC-SHA256 验签。"
         "支付状态异步通知幂等处理：payment_id 唯一约束 + Redis 分布式锁。"
         "退款接口对接完成，退款 T+1 到账。",
         180.0),

    (15, "订单超时自动取消：Redis Sorted Set 延迟队列，score=过期时间戳。"
         "定时任务（APScheduler）每 30 秒扫描并取消超时订单。"
         "取消时回滚库存、释放优惠券。",
         176.0),

    (16, "优惠券系统：类型支持满减/折扣/固定金额，有效期/使用次数限制。"
         "领券接口防刷：用户维度 Redis 限流（每人每券最多 1 张）。"
         "下单时优惠券核销使用数据库事务保证原子性。",
         172.0),

    # ── Phase 3: Performance & Reliability (160-130 days) ─────────────────────
    (17, "首次压测：Locust 500 并发，持续 5 分钟。P99 延迟 1200ms，远超目标 300ms。"
         "瓶颈分析：PostgreSQL 连接池耗尽（max_size=10），大量请求排队等连接。"
         "紧急扩容：连接池 max_size 改为 100，P99 降至 280ms。",
         158.0),

    (18, "Redis 缓存层设计：商品详情 TTL 5 分钟，分类树 TTL 30 分钟，用户 session TTL 24 小时。"
         "缓存击穿防护：singleflight 模式（Redis SETNX 互斥锁），防止雪崩。"
         "热 key 问题：TOP100 商品做本地内存缓存（TTL 1 分钟）。",
         155.0),

    (19, "慢查询优化：EXPLAIN ANALYZE 分析高频 SQL，发现 3 条全表扫描。"
         "修复：① orders 表加 (user_id, created_at) 复合索引 "
         "② products 加 (category_id, status, price) 索引 "
         "③ 大列（description）从主查询中拆分到按需加载。",
         151.0),

    (20, "内存泄漏排查：生产环境每 6 小时内存增长约 200MB 直到 OOM 重启。"
         "根因：asyncpg 连接对象未正确归还连接池，长事务持有连接。"
         "修复：统一改为 async with pool.acquire() as conn 模式，问题消除。",
         147.0),

    (21, "监控系统接入：Prometheus 埋点（接口 RT、DB 连接池、Redis 命中率、Kafka 积压量）。"
         "Grafana 看板搭建完成，告警规则：P95 > 500ms 触发 PagerDuty。"
         "日志统一结构化（JSON），接入 ELK Stack。",
         143.0),

    (22, "异步任务架构：Celery + Redis Broker 处理耗时任务（发邮件、生成报表、图片压缩）。"
         "Celery Beat 定时任务：每天 2:00 AM 生成日销售报表推送到 S3。",
         139.0),

    (23, "数据库主从分离：引入只读副本分流查询流量，写操作走主库，"
         "读操作（列表查询、统计）走从库。延迟约 50ms，业务可接受。",
         135.0),

    (24, "分布式追踪引入：OpenTelemetry SDK + Jaeger 收集链路数据。"
         "成功定位一个跨 3 个服务的慢接口问题（商品推荐接口调用链太深）。",
         131.0),

    # ── Phase 4: Security & Bug Fixes (120-95 days) ───────────────────────────
    (25, "安全审计报告：发现 4 个高危漏洞：① SQL 注入（搜索接口直接拼 SQL）"
         "② JWT alg=none 伪造攻击 ③ 商品图片上传路径穿越 ④ 管理接口无权限校验。"
         "全部修复，CI 流程加入 bandit + safety 安全扫描。",
         118.0),

    (26, "SQL 注入修复：搜索接口将用户输入直接拼接到 SQL WHERE 子句。"
         "全面排查并修复 5 处，改用 asyncpg 参数化查询（$1/$2 占位符）。"
         "同时修复了一处 XSS：商品描述字段未做 HTML 转义。",
         115.0),

    (27, "JWT alg=none 漏洞修复：decode 时未指定允许的 algorithm，"
         "攻击者可构造 alg=none 的 token 绕过签名验证。"
         "修复：强制指定 algorithms=['HS256']，升级 PyJWT 到 2.8.0。",
         112.0),

    (28, "生产事故 P0：2024-04-10 凌晨 1:30，订单服务完全不可用，持续 35 分钟。"
         "根因：Redis 主节点 OOM（maxmemory 未设置），大量 key 被驱逐，"
         "session 失效导致登录雪崩，连带压垮订单服务。"
         "修复：设置 maxmemory=8GB，policy=allkeys-lru，增加 Redis 内存告警。",
         108.0),

    (29, "并发 bug 修复：下单接口高并发时出现重复订单，"
         "原因是订单号用时间戳+随机数生成，概率性重复。"
         "修复：改用雪花算法生成全局唯一 ID，并加数据库唯一约束兜底。",
         105.0),

    (30, "CORS 配置修复：生产环境 CORS 允许所有来源（*），安全风险。"
         "修改为白名单模式，仅允许 www.xxx.com 和 admin.xxx.com 两个域名。"
         "同时修复了 Cookie SameSite=None 但未设 Secure 的问题。",
         101.0),

    (31, "支付回调幂等 bug：同一笔订单的支付成功通知被处理两次，导致库存扣减两次。"
         "根因：幂等 key 的 Redis SETNX 和数据库写入不在同一事务中。"
         "修复：改用数据库唯一索引（payment_id）作为最终幂等保障。",
         97.0),

    (32, "推荐系统 v1 上线：协同过滤模型，用 ClickHouse 存用户行为，"
         "每日 03:00 AM 离线训练，结果写 Redis。推荐点击率 3.2%，"
         "高于首页随机展示的 1.1%，效果达标。",
         94.0),

    # ── Phase 5: Search & Analytics (85-65 days) ──────────────────────────────
    (33, "搜索质量优化：用户反馈搜索 '手机' 排在前面的都是配件，不是手机本身。"
         "问题在于 IK 分词将 '手机壳' 的 '手机' 作为 token，干扰排序。"
         "引入 synonym 同义词词典 + 字段权重调整，搜索 NDCG@10 从 0.61 提升到 0.78。",
         83.0),

    (34, "A/B 测试框架搭建：基于用户 ID 哈希分流，流量比例可配置。"
         "首个 A/B 实验：新旧两版推荐算法对比，实验时长 2 周。"
         "埋点数据写 Kafka → ClickHouse，实时看板每小时刷新。",
         80.0),

    (35, "ClickHouse 分析平台：迁移销售报表、用户行为分析从 PostgreSQL 到 ClickHouse。"
         "查询性能提升约 50x（亿级行的聚合从 30s 降到 600ms）。"
         "ETL 管道：PostgreSQL CDC（Debezium）→ Kafka → ClickHouse。",
         77.0),

    (36, "商品评价系统：评价 CRUD、图片上传、卖家回复、违禁词过滤（敏感词库）。"
         "评价打分统计存 Redis ZSET，每日同步到 PostgreSQL 做持久化。"
         "恶意刷好评检测：同 IP 同商品 24 小时内超过 3 次评价则屏蔽。",
         74.0),

    (37, "用户画像系统：根据浏览/购买/搜索行为生成用户标签（价格敏感、品牌偏好等）。"
         "标签计算每日批处理，结果存 Redis Hash，营销系统消费做精准推送。",
         71.0),

    (38, "数据大屏开发：实时销售额、在线用户数、订单量、GMV 四个核心指标。"
         "WebSocket 推送（每 5 秒刷新），后端聚合 Redis 实时数据。",
         68.0),

    (39, "分布式限流：基于 Redis + Lua 脚本实现令牌桶，接口级别限流配置化。"
         "已对注册、登录、搜索、下单接口配置限流（每个 IP 每分钟不超过阈值）。"
         "放弃了 Sentinel（依赖 Java 生态，不适合 Python 项目）。",
         65.0),

    (40, "多语言国际化（i18n）：错误提示信息支持中英双语。"
         "Accept-Language header 自动检测，默认中文。"
         "翻译文件存 YAML，由 Babel 工具链管理。",
         62.0),

    # ── Phase 6: DevOps & Infrastructure (55-38 days) ─────────────────────────
    (41, "k8s 生产集群升级：从 k8s 1.26 升级到 1.29。"
         "升级前在 staging 充分验证，滚动更新 + PodDisruptionBudget 保证升级期间服务不中断。"
         "遇到 1 个 API 弃用问题（Ingress networking.k8s.io/v1beta1），已迁移到 v1。",
         53.0),

    (42, "CI/CD 流水线重构：GitHub Actions 工作流拆分为 3 个独立 workflow "
         "（test / build+push / deploy），build 时间从 18 分钟优化到 7 分钟。"
         "ArgoCD 配置 Argo Rollouts 灰度发布：新版本先 10% 流量，观察 10 分钟后全量。",
         50.0),

    (43, "多区域部署规划：计划 Q4 在东南亚开辟第二个 region（新加坡）。"
         "架构决策：数据库不做跨 region 同步（延迟不可接受），"
         "每个 region 独立数据库，通过前端 geolocation 路由到最近 region。",
         47.0),

    (44, "成本优化：k8s 节点从按需实例迁移到 Spot 实例（非核心服务）。"
         "通过 Karpenter 动态调度，按需实例从 20 台缩减到 8 台。"
         "月成本节省约 35%（约 $12,000/月）。",
         44.0),

    (45, "灾备演练：模拟 RDS 主库故障，测试自动 failover 时间。"
         "实测 failover 耗时 45 秒（目标 60 秒内）。"
         "发现应用层重连逻辑有 bug（未处理 OperationalError），已修复。",
         41.0),

    (46, "Secret 管理迁移：从 k8s Secret 明文（base64）迁移到 AWS Secrets Manager。"
         "使用 External Secrets Operator 自动同步，secret 轮换无需重启 Pod。"
         "原先有 3 个 secret 硬编码在代码注释里，已清除并 rewrite git history。",
         38.0),

    (47, "网络安全加固：VPC 内部服务间通信改为 mTLS（Istio service mesh）。"
         "外部接口全部强制 HTTPS，HTTP → HTTPS 301 重定向。"
         "Web Application Firewall（WAF）上线，已拦截多次爬虫攻击。",
         35.0),

    (48, "数据库备份策略完善：PostgreSQL 每日全量备份 + 每 15 分钟 WAL 归档到 S3。"
         "恢复演练每月执行一次，最近一次恢复测试 RTO=12 分钟，RPO<15 分钟。",
         33.0),

    # ── Phase 7: Final Features & Polish (30-18 days) ─────────────────────────
    (49, "商家入驻功能：商家注册审核流程、营业执照 OCR 识别（百度 API）、"
         "资质审核状态机（pending/approved/rejected）。"
         "审核通过后自动开通商品发布权限。",
         29.0),

    (50, "营销活动系统：秒杀、限时折扣、满赠三类活动。"
         "秒杀采用预热方案：活动开始前 30 分钟将库存加载到 Redis，"
         "秒杀请求直接扣 Redis，异步落库，防止数据库被瞬时打垮。",
         26.0),

    (51, "客服系统集成：接入第三方客服平台（Zendesk），"
         "工单自动分配基于商品类目路由，SLA 要求首响 < 4 小时。"
         "机器人自动回复接入商品信息查询，解决率约 40%。",
         24.0),

    (52, "性能调优 round 3：千人并发压测，P99 从 210ms 降到 95ms。"
         "关键优化：① 商品列表接口 N+1 查询改为批量查询 "
         "② 用户信息从每次 DB 查询改为 Redis 缓存（TTL 5 分钟）"
         "③ Pydantic v2 序列化性能比 v1 快 5-17x，已全量升级。",
         21.0),

    (53, "国际化发货支持：集成多家物流 API（顺丰/EMS/四方物流），"
         "运费自动计算基于重量+距离，时效估算。"
         "物流轨迹 webhook 回调同步订单状态。",
         19.0),

    (54, "移动端 APP 版本兼容：iOS/Android 客户端最低支持版本提升，"
         "旧版本 API（/api/v0/）已正式下线。"
         "接口版本迁移文档已发布，通知全量用户升级。",
         18.0),

    # ── Phase 8: Launch Preparation (14-7 days) ───────────────────────────────
    (55, "全站压测：模拟双 11 大促场景，10000 并发，持续 30 分钟。"
         "系统稳定，P99=180ms，错误率 0.01%。"
         "发现一个 Redis Cluster 在 key 分布不均时的热 slot 问题，已通过 hash tag 缓解。",
         14.0),

    (56, "数据治理：GDPR/个保法合规改造，用户数据导出功能，"
         "注销账号时数据匿名化处理（手机号/邮箱置空，订单保留匿名化版本）。"
         "隐私政策和用户协议法务审核通过。",
         13.0),

    (57, "安全渗透测试（外部）：聘请安全公司做黑盒测试，共发现 3 个中危问题："
         "① 找回密码接口无频率限制（可枚举）② 商品评价图片无内容审核 "
         "③ 管理后台登录无 IP 白名单。三个问题均已修复。",
         11.0),

    (58, "最终上线前 checklist 完成：CDN 配置（静态资源）、DNS 切换方案、"
         "回滚预案（蓝绿部署，30 秒内可回滚）、值班表（上线后 72 小时双人值班）。"
         "k8s HPA 参数最终确定：最小 3 副本，最大 20 副本，CPU 60% 触发扩容。",
         9.0),

    (59, "正式上线：2024-12-01 10:00 AM，流量平稳切换完成。"
         "首日 GMV 超预期 120%，系统全程稳定。"
         "上线后 24 小时无告警触发，运营团队满意。",
         8.0),

    (60, "上线后复盘：技术债务优先级排序，下一期计划："
         "① 链路追踪覆盖率从 60% 提升到 95% "
         "② rate limiting 覆盖所有公开接口 "
         "③ 搜索升级到向量语义搜索（embedding 方案调研中）"
         "④ 微服务拆分评估（订单服务独立部署）。",
         7.0),
]

# ─────────────────────────────────────────────────────────────────────────────
# Labeled queries for accuracy evaluation
# (query, expected_turn_ids in relevance order, description)
# ─────────────────────────────────────────────────────────────────────────────

EVAL_QUERIES: list[tuple[str, list[int], str]] = [
    # Architecture decisions
    ("为什么不用ORM选asyncpg",           [3],            "ORM vs asyncpg decision"),
    ("JWT认证方案",                       [4, 7, 27],     "JWT auth implementation"),
    ("放弃GraphQL的原因",                 [2],            "GraphQL rejection decision"),
    ("放弃OAuth2第三方登录",              [4],            "OAuth2 rejection"),

    # Performance incidents
    ("连接池耗尽P99延迟",                 [6, 17],        "Connection pool issue"),  # session 6 in old BM25 test, session 17 here
    ("内存泄漏asyncpg连接",               [20],           "Memory leak fix"),
    ("Redis OOM雪崩事故",                 [28],           "Redis OOM incident"),

    # Security vulnerabilities
    ("SQL注入漏洞修复",                   [25, 26],       "SQL injection fix"),
    ("JWT alg none伪造攻击",              [25, 27],       "JWT algorithm vulnerability"),
    ("支付回调幂等bug",                   [31],           "Payment idempotency bug"),

    # Technology keywords (abbreviations)
    ("k8s部署配置HPA",                    [41, 58],       "k8s HPA config"),
    ("CI/CD流水线GitHub Actions",         [6, 42],        "CI/CD pipeline"),
    ("Elasticsearch搜索分词",             [10, 33],       "Search quality"),

    # Temporal queries
    ("上线后系统状态",                    [59, 60],       "Post-launch status"),
    ("压测结果性能",                      [17, 26, 52, 55], "Load test results"),

    # Negation/rejection memory
    ("被放弃的技术方案",                  [1, 2, 4, 39],  "Rejected technologies"),
    ("Sentinel限流放弃",                  [39],           "Sentinel rejection"),

    # Multi-session continuity (early decision, late context)
    ("数据库schema设计users表",           [3],            "Early DB schema decision"),
    ("订单状态机流转",                    [13],           "Order state machine"),

    # Mixed language
    ("CORS whitelist domain security",   [30],           "CORS security fix"),
    ("Redis缓存TTL策略",                  [18],           "Redis cache TTL"),
    ("ClickHouse分析查询性能",            [35],           "ClickHouse analytics"),
]


# ─────────────────────────────────────────────────────────────────────────────
# Global results collector (populated by tests, used for HTML report)
# ─────────────────────────────────────────────────────────────────────────────

_RESULTS: dict = {
    "token_cap": None,
    "ordering": None,
    "temporal": None,
    "decay_resilience": None,
    "negation": None,
    "continuity": None,
    "bm25_accuracy": None,
    "decay_reset": None,
}


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def populated_db(tmp_path_factory):
    """Shared DB populated with all 60 corpus entries at controlled timestamps."""
    db_dir = tmp_path_factory.mktemp("recall_db")
    db_path = str(db_dir / "recall_test.db")
    compressor = _make_compressor()
    mem = RecentMemory(db_path, compressor)

    for turn_id, content, d_ago in CORPUS:
        ts = days_ago(d_ago)
        score = min(math.exp(-d_ago / RecentMemory.LEVEL1_STABILITY), 1.0)
        _insert_raw(db_path, turn_id, content, ts, score=score)

    return db_path, compressor


@pytest.fixture(scope="module")
def memory(populated_db):
    db_path, compressor = populated_db
    return RecentMemory(db_path, compressor)


# ─────────────────────────────────────────────────────────────────────────────
# Helper: compute corpus scores
# ─────────────────────────────────────────────────────────────────────────────

def _corpus_scores() -> list[tuple[int, float, float]]:
    """Returns (turn_id, days_ago, computed_score) for all entries."""
    return [
        (tid, d, min(math.exp(-d / RecentMemory.LEVEL1_STABILITY), 1.0))
        for tid, _, d in CORPUS
    ]


# ─────────────────────────────────────────────────────────────────────────────
# Test 1: Token Cap Enforcement
# ─────────────────────────────────────────────────────────────────────────────

def test_get_for_context_token_cap(memory):
    """get_for_context() must not exceed INJECT_TOKEN_CAP tokens."""
    result = memory.get_for_context()
    actual_tokens = count_tokens(result)
    cap = memory._inject_token_cap

    assert actual_tokens <= cap, (
        f"Token cap exceeded: {actual_tokens} > {cap}"
    )

    # Should include at least some content
    assert len(result) > 0, "Context should not be empty"

    # Count how many entries were included
    entry_count = result.count("[20")  # count date prefixes
    total_entries = len(CORPUS)

    _RESULTS["token_cap"] = {
        "status": "PASS",
        "total_entries": total_entries,
        "included_entries": entry_count,
        "tokens_used": actual_tokens,
        "token_cap": cap,
        "cap_utilization_pct": round(actual_tokens / cap * 100, 1),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Test 2: Ordering (newest first)
# ─────────────────────────────────────────────────────────────────────────────

def test_get_for_context_ordering(memory):
    """Context output must list entries oldest→newest (ascending time)."""
    entries = memory.get_entries_for_context()
    assert len(entries) >= 2, "Need at least 2 entries to check order"

    # Extract timestamps from "[YYYY-MM-DD HH:MM]" prefix
    import re
    date_re = re.compile(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\]')
    timestamps = []
    for e in entries:
        m = date_re.match(e)
        if m:
            timestamps.append(datetime.strptime(m.group(1), "%Y-%m-%d %H:%M"))

    assert len(timestamps) >= 2
    for i in range(1, len(timestamps)):
        assert timestamps[i] >= timestamps[i - 1], (
            f"Entries not in ascending order at position {i}: "
            f"{timestamps[i-1]} > {timestamps[i]}"
        )

    _RESULTS["ordering"] = {
        "status": "PASS",
        "entries_checked": len(timestamps),
        "oldest": timestamps[0].strftime("%Y-%m-%d") if timestamps else "N/A",
        "newest": timestamps[-1].strftime("%Y-%m-%d") if timestamps else "N/A",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Test 3: Temporal Date Filter
# ─────────────────────────────────────────────────────────────────────────────

def test_temporal_search_date_filter(memory):
    """search() with start_date/end_date should only return entries in range."""
    # Query: entries from ~60 to ~40 days ago (Phase 6 sessions 41-46)
    end_dt = datetime.now() - timedelta(days=38)
    start_dt = datetime.now() - timedelta(days=55)
    start_date = start_dt.strftime("%Y-%m-%d")
    end_date = end_dt.strftime("%Y-%m-%d")

    results = memory.search("k8s 部署 CI CD", top_k=10,
                            start_date=start_date, end_date=end_date)

    # Verify results contain date timestamps within range
    import re
    date_re = re.compile(r'\[(\d{4}-\d{2}-\d{2})')
    hit_dates = []
    for r in results:
        m = date_re.search(r)
        if m:
            hit_dates.append(datetime.strptime(m.group(1), "%Y-%m-%d"))

    out_of_range = [d for d in hit_dates
                    if d < start_dt.replace(hour=0, minute=0, second=0)
                    or d > end_dt.replace(hour=23, minute=59, second=59)]

    assert len(out_of_range) == 0, (
        f"Found {len(out_of_range)} results outside date range: {out_of_range}"
    )

    _RESULTS["temporal"] = {
        "status": "PASS",
        "date_range": f"{start_date} ~ {end_date}",
        "results_found": len(results),
        "out_of_range_violations": len(out_of_range),
        "sample_hits": [d.strftime("%Y-%m-%d") for d in hit_dates[:5]],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Test 4: Decay Resilience — score≈0 entries still searchable
# ─────────────────────────────────────────────────────────────────────────────

def test_decayed_entries_still_searchable(populated_db):
    """Heavily decayed entries (score≈0) must still be retrievable via BM25 search."""
    db_path, compressor = populated_db
    mem = RecentMemory(db_path, compressor)

    # Sessions 1-8 are 210-238 days old → score ≈ 0
    # Query for content unique to these sessions
    heavily_decayed_queries = [
        ("asyncpg ORM 技术栈选型", [1, 3]),    # sessions 1,3: stack decision
        ("bcrypt 密码加盐认证", [4, 7]),         # sessions 4,7: auth
        ("SendGrid 邮件注册", [8]),              # session 8: email
    ]

    decay_results = []
    for query, expected_tids in heavily_decayed_queries:
        results = mem.search(query, top_k=10)

        # Check that at least 1 expected entry is found
        found_any = False
        for r in results:
            for tid in expected_tids:
                # match by content snippet unique to that session
                _, content, _ = CORPUS[tid - 1]
                # use a distinctive token from the content
                snippet = content[:20].strip()
                if snippet[:8] in r:
                    found_any = True
                    break

        decay_results.append({
            "query": query,
            "expected_tids": expected_tids,
            "results_count": len(results),
            "found": found_any,
        })

    found_count = sum(1 for r in decay_results if r["found"])
    total = len(decay_results)

    # At least 2/3 decayed queries should retrieve relevant entries
    assert found_count >= 2, (
        f"Only {found_count}/{total} decayed queries returned relevant results. "
        f"Details: {decay_results}"
    )

    _RESULTS["decay_resilience"] = {
        "status": "PASS" if found_count == total else "PARTIAL",
        "queries_tested": total,
        "queries_succeeded": found_count,
        "details": decay_results,
        "note": "Entries with score≈0 (240+ days old) remain BM25-indexed and searchable",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Test 5: Negation / Rejection Memory
# ─────────────────────────────────────────────────────────────────────────────

def test_negation_memory_retrieval(memory):
    """Entries recording rejected decisions must be retrievable."""
    negation_queries = [
        ("放弃了Django REST Framework", [1], "Django rejection"),
        ("决定不使用GraphQL",            [2], "GraphQL rejection"),
        ("放弃OAuth2第三方登录",          [4], "OAuth2 rejection"),
        ("放弃了Sentinel限流",            [39], "Sentinel rejection"),
        ("不使用ORM改用asyncpg",          [3], "ORM rejection"),
    ]

    results_detail = []
    hits = 0
    for query, expected_tids, label in negation_queries:
        results = memory.search(query, top_k=5)
        result_text = " ".join(results)

        # Look for content from expected sessions
        found = False
        for tid in expected_tids:
            _, content, _ = CORPUS[tid - 1]
            # Find a distinctive keyword from the content
            words = [w for w in content.split() if len(w) >= 3]
            for w in words[:5]:
                if w in result_text:
                    found = True
                    break
            if found:
                break

        if found:
            hits += 1
        results_detail.append({
            "query": query,
            "label": label,
            "expected_tids": expected_tids,
            "found": found,
            "result_count": len(results),
        })

    recall_rate = hits / len(negation_queries)
    assert recall_rate >= 0.6, (
        f"Negation memory recall too low: {hits}/{len(negation_queries)} = {recall_rate:.2f}"
    )

    _RESULTS["negation"] = {
        "status": "PASS" if recall_rate >= 0.8 else "PARTIAL",
        "queries_tested": len(negation_queries),
        "hits": hits,
        "recall_rate": round(recall_rate, 3),
        "details": results_detail,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Test 6: Multi-Session Continuity
# ─────────────────────────────────────────────────────────────────────────────

def test_multi_session_continuity(memory):
    """Decisions from early sessions (session 3, 4) must be findable 240 days later."""
    # These are architectural decisions made at project start that should
    # remain traceable even after 8 months
    continuity_queries = [
        # Early architectural decisions
        ("数据库表设计users表字段",          3, "DB schema (session 3, ~232d ago)"),
        ("JWT access token refresh token",  4, "Auth design (session 4, ~229d ago)"),
        ("路由层禁止直接操作数据库",          5, "Arch rule (session 5, ~226d ago)"),
        # Mid-project key decisions
        ("连接池max_size配置调整",           17, "Pool sizing (session 17, ~158d ago)"),
        ("Redis缓存TTL命中率",               18, "Cache TTL (session 18, ~155d ago)"),
        # Security: vulnerability chain
        ("SQL注入参数化查询修复",             26, "Security fix (session 26, ~115d ago)"),
    ]

    results_detail = []
    hits = 0
    for query, expected_tid, label in continuity_queries:
        results = memory.search(query, top_k=5)
        result_text = " ".join(results)

        _, content, d_ago = CORPUS[expected_tid - 1]
        # Check a distinctive fragment from the target session
        # Use middle portion to avoid date prefix overlap
        fragment = content[10:40].strip()
        found = fragment[:15] in result_text if len(fragment) >= 15 else (fragment in result_text)

        if found:
            hits += 1
        results_detail.append({
            "query": query,
            "expected_tid": expected_tid,
            "days_ago": d_ago,
            "label": label,
            "found": found,
            "result_count": len(results),
        })

    recall_rate = hits / len(continuity_queries)
    assert recall_rate >= 0.5, (
        f"Multi-session continuity recall too low: {hits}/{len(continuity_queries)} = {recall_rate:.2f}"
    )

    _RESULTS["continuity"] = {
        "status": "PASS" if recall_rate >= 0.7 else "PARTIAL",
        "queries_tested": len(continuity_queries),
        "hits": hits,
        "recall_rate": round(recall_rate, 3),
        "details": results_detail,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Test 7: Large-Corpus BM25 Accuracy
# ─────────────────────────────────────────────────────────────────────────────

def _compute_mrr_and_hits(memory, queries: list[tuple[str, list[int], str]],
                           top_k: int = 5) -> dict:
    """Compute MRR, Hit@1, Hit@3, Hit@5 over a query set."""
    turn_id_to_idx: dict[int, int] = {}
    with sqlite3.connect(memory.db_path) as conn:
        rows = conn.execute(
            "SELECT id, turn_id FROM recent_memory ORDER BY created_at ASC"
        ).fetchall()
    for row in rows:
        # Map turn_id → the db row index (for result matching)
        turn_id_to_idx[row[1]] = row[0]

    rr_list = []
    hit_at: dict[int, int] = {1: 0, 3: 0, 5: 0}
    query_details = []

    for query, expected_tids, description in queries:
        results = memory.search(query, top_k=top_k)

        # Build expected content fragments from expected_tids
        expected_fragments = []
        for tid in expected_tids:
            if 1 <= tid <= len(CORPUS):
                _, content, _ = CORPUS[tid - 1]
                expected_fragments.append(content[5:30].strip())

        # Find rank of first relevant result
        rank = None
        for i, r in enumerate(results, 1):
            for frag in expected_fragments:
                if frag[:12] in r:
                    rank = i
                    break
            if rank:
                break

        rr = 1.0 / rank if rank else 0.0
        rr_list.append(rr)

        for k in [1, 3, 5]:
            if rank and rank <= k:
                hit_at[k] += 1

        query_details.append({
            "query": query,
            "description": description,
            "expected_tids": expected_tids,
            "rank": rank,
            "rr": round(rr, 3),
            "result_snippets": [r[:60] + "..." for r in results[:3]],
        })

    n = len(queries)
    return {
        "mrr": round(sum(rr_list) / n, 3) if n else 0.0,
        "hit_at_1": round(hit_at[1] / n, 3) if n else 0.0,
        "hit_at_3": round(hit_at[3] / n, 3) if n else 0.0,
        "hit_at_5": round(hit_at[5] / n, 3) if n else 0.0,
        "total_queries": n,
        "queries": query_details,
    }


def test_bm25_large_corpus_accuracy(memory):
    """BM25 search accuracy across the full 60-entry corpus with 22 labeled queries."""
    metrics = _compute_mrr_and_hits(memory, EVAL_QUERIES, top_k=5)

    # Thresholds for a 60-entry noisy corpus
    assert metrics["mrr"] >= 0.40, f"MRR too low: {metrics['mrr']}"
    assert metrics["hit_at_5"] >= 0.55, f"Hit@5 too low: {metrics['hit_at_5']}"

    _RESULTS["bm25_accuracy"] = metrics
    _RESULTS["bm25_accuracy"]["status"] = (
        "PASS" if metrics["mrr"] >= 0.40 and metrics["hit_at_5"] >= 0.55 else "FAIL"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Test 8: Search-Hit Resets Decay
# ─────────────────────────────────────────────────────────────────────────────

def test_search_hit_resets_decay(tmp_path):
    """A search hit must reset last_accessed_at and set score=1.0."""
    db_path = str(tmp_path / "decay_reset.db")
    compressor = _make_compressor()
    mem = RecentMemory(db_path, compressor)

    # Insert an old entry with low score
    content = "asyncpg连接池配置：max_size=100，min_size=10，超时30秒。"
    old_ts = days_ago(150)  # 150 days old
    old_score = math.exp(-150 / RecentMemory.LEVEL1_STABILITY)  # ≈ 0.00083
    _insert_raw(db_path, 999, content, old_ts, score=old_score)

    # Read the inserted entry id
    with sqlite3.connect(db_path) as conn:
        row = conn.execute("SELECT id, score, last_accessed_at FROM recent_memory WHERE turn_id=999").fetchone()
    entry_id = row[0]
    assert row[1] == pytest.approx(old_score, abs=1e-6)
    assert row[2] is None  # last_accessed_at not set yet

    before_search = time.time()

    # Search should hit this entry
    results = mem.search("asyncpg连接池", top_k=5)

    after_search = time.time()

    # Verify decay was reset
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT score, last_accessed_at, search_hit_count FROM recent_memory WHERE id=?",
            (entry_id,)
        ).fetchone()

    assert row[0] == pytest.approx(1.0), f"Score not reset to 1.0: {row[0]}"
    assert row[1] is not None, "last_accessed_at not set"
    assert before_search <= row[1] <= after_search + 1, (
        f"last_accessed_at out of expected range: {row[1]}"
    )
    assert row[2] >= 1, f"search_hit_count not incremented: {row[2]}"

    # Also verify the entry appears in results
    assert len(results) >= 1
    assert "asyncpg" in results[0] or "连接池" in results[0]

    _RESULTS["decay_reset"] = {
        "status": "PASS",
        "entry_age_days": 150,
        "score_before": round(old_score, 6),
        "score_after": 1.0,
        "last_accessed_at_set": True,
        "search_hit_count": row[2],
        "appeared_in_results": True,
    }


# ─────────────────────────────────────────────────────────────────────────────
# HTML Report Generator (runs last due to "z_" prefix)
# ─────────────────────────────────────────────────────────────────────────────

def test_z_generate_html_report():
    """Generate the evaluation HTML report to docs/memory_recall_report.html."""
    report_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs"
    )
    os.makedirs(report_dir, exist_ok=True)
    report_path = os.path.join(report_dir, "memory_recall_report.html")

    html = _build_html_report()
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"\n  Report written to: {report_path}")
    assert os.path.exists(report_path)


def _status_badge(status: Optional[str]) -> str:
    if status == "PASS":
        return '<span class="badge pass">PASS</span>'
    elif status == "PARTIAL":
        return '<span class="badge partial">PARTIAL</span>'
    elif status == "FAIL":
        return '<span class="badge fail">FAIL</span>'
    return '<span class="badge unknown">PENDING</span>'


def _score_bar(value: float, max_val: float = 1.0, color: str = "#4ade80") -> str:
    pct = min(value / max_val * 100, 100)
    return (f'<div class="bar-wrap">'
            f'<div class="bar" style="width:{pct:.1f}%;background:{color}"></div>'
            f'<span class="bar-label">{value:.3f}</span></div>')


def _build_html_report() -> str:
    tc = _RESULTS.get("token_cap") or {}
    ord_ = _RESULTS.get("ordering") or {}
    tmp = _RESULTS.get("temporal") or {}
    dec = _RESULTS.get("decay_resilience") or {}
    neg = _RESULTS.get("negation") or {}
    cont = _RESULTS.get("continuity") or {}
    bm = _RESULTS.get("bm25_accuracy") or {}
    dr = _RESULTS.get("decay_reset") or {}

    corpus_scores = _corpus_scores()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Build corpus age distribution
    age_bins = [0] * 8  # 8 monthly buckets
    for _, d, _ in corpus_scores:
        idx = min(int(d // 30), 7)
        age_bins[idx] += 1

    def age_bar(count: int, total: int = max(age_bins) or 1) -> str:
        pct = count / total * 100
        return (f'<div style="display:inline-block;width:{pct:.0f}%;'
                f'min-width:2px;height:16px;background:#6366f1;border-radius:2px;'
                f'vertical-align:middle"></div> {count}')

    # BM25 query table rows
    query_rows = ""
    if bm.get("queries"):
        for q in bm["queries"]:
            rank = q.get("rank")
            rank_str = str(rank) if rank else "—"
            rr_str = f'{q["rr"]:.3f}'
            hit_color = "#4ade80" if rank and rank <= 3 else ("#facc15" if rank and rank <= 5 else "#f87171")
            query_rows += f"""
            <tr>
              <td style="max-width:220px">{q['query']}</td>
              <td class="center">{', '.join(str(t) for t in q['expected_tids'])}</td>
              <td class="center" style="color:{hit_color};font-weight:600">{rank_str}</td>
              <td class="center">{rr_str}</td>
              <td style="font-size:0.78em;color:#94a3b8">{q['description']}</td>
            </tr>"""

    # Decay resilience detail
    decay_rows = ""
    if dec.get("details"):
        for d in dec["details"]:
            found_str = "✓" if d["found"] else "✗"
            color = "#4ade80" if d["found"] else "#f87171"
            decay_rows += f"""
            <tr>
              <td>{d['query']}</td>
              <td class="center">{', '.join(str(t) for t in d['expected_tids'])}</td>
              <td class="center" style="color:{color};font-weight:700">{found_str}</td>
              <td class="center">{d['results_count']}</td>
            </tr>"""

    # Continuity detail
    cont_rows = ""
    if cont.get("details"):
        for d in cont["details"]:
            found_str = "✓" if d["found"] else "✗"
            color = "#4ade80" if d["found"] else "#f87171"
            cont_rows += f"""
            <tr>
              <td>{d['query']}</td>
              <td class="center">{d['expected_tid']}</td>
              <td class="center">{d['days_ago']:.0f}d</td>
              <td class="center" style="color:{color};font-weight:700">{found_str}</td>
              <td style="font-size:0.78em;color:#94a3b8">{d['label']}</td>
            </tr>"""

    mrr_val = bm.get("mrr", 0)
    h1_val = bm.get("hit_at_1", 0)
    h3_val = bm.get("hit_at_3", 0)
    h5_val = bm.get("hit_at_5", 0)
    mrr_color = "#4ade80" if mrr_val >= 0.5 else ("#facc15" if mrr_val >= 0.35 else "#f87171")

    overall_pass = sum(1 for k in _RESULTS if _RESULTS[k] and _RESULTS[k].get("status") == "PASS")
    overall_partial = sum(1 for k in _RESULTS if _RESULTS[k] and _RESULTS[k].get("status") == "PARTIAL")
    overall_total = sum(1 for k in _RESULTS if _RESULTS[k] is not None)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Memory Recall Evaluation Report</title>
  <style>
    :root {{
      --bg: #0f172a; --surface: #1e293b; --surface2: #263348;
      --border: #334155; --text: #e2e8f0; --muted: #94a3b8;
      --accent: #6366f1; --green: #4ade80; --yellow: #facc15; --red: #f87171;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ background: var(--bg); color: var(--text); font-family: 'Segoe UI', system-ui, sans-serif;
            font-size: 14px; line-height: 1.6; padding: 0 0 60px; }}
    header {{ background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
              padding: 40px 40px 32px; border-bottom: 1px solid var(--border); }}
    header h1 {{ font-size: 1.8em; font-weight: 700; color: #fff; letter-spacing: -0.02em; }}
    header p {{ color: #a5b4fc; margin-top: 6px; font-size: 0.9em; }}
    .container {{ max-width: 1100px; margin: 0 auto; padding: 0 24px; }}
    .section {{ background: var(--surface); border: 1px solid var(--border);
                border-radius: 12px; padding: 24px; margin-top: 24px; }}
    .section h2 {{ font-size: 1.05em; font-weight: 600; color: var(--accent);
                   text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 16px; }}
    .section h3 {{ font-size: 0.95em; font-weight: 600; color: #c7d2fe; margin: 16px 0 8px; }}
    .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; }}
    .kpi {{ background: var(--surface2); border: 1px solid var(--border); border-radius: 10px;
            padding: 18px 20px; }}
    .kpi .label {{ color: var(--muted); font-size: 0.78em; text-transform: uppercase;
                   letter-spacing: 0.05em; margin-bottom: 6px; }}
    .kpi .value {{ font-size: 2em; font-weight: 700; line-height: 1; }}
    .kpi .sub {{ font-size: 0.78em; color: var(--muted); margin-top: 4px; }}
    .badge {{ display: inline-block; padding: 2px 10px; border-radius: 12px;
              font-size: 0.75em; font-weight: 700; letter-spacing: 0.05em; }}
    .badge.pass {{ background: #14532d; color: var(--green); }}
    .badge.partial {{ background: #713f12; color: var(--yellow); }}
    .badge.fail {{ background: #7f1d1d; color: var(--red); }}
    .badge.unknown {{ background: #1e293b; color: var(--muted); }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.88em; }}
    th {{ background: var(--surface2); color: var(--muted); font-weight: 600;
          text-transform: uppercase; font-size: 0.75em; letter-spacing: 0.05em;
          padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); }}
    td {{ padding: 9px 12px; border-bottom: 1px solid #1e293b; vertical-align: top; }}
    tr:last-child td {{ border-bottom: none; }}
    tr:hover td {{ background: var(--surface2); }}
    td.center {{ text-align: center; }}
    .bar-wrap {{ display: flex; align-items: center; gap: 8px; }}
    .bar {{ height: 10px; border-radius: 5px; min-width: 4px; }}
    .bar-label {{ font-size: 0.85em; color: var(--text); min-width: 40px; }}
    .stat-row {{ display: flex; gap: 24px; flex-wrap: wrap; margin-top: 12px; }}
    .stat-item {{ flex: 1; min-width: 140px; }}
    .stat-item .k {{ color: var(--muted); font-size: 0.8em; }}
    .stat-item .v {{ font-size: 1.2em; font-weight: 700; margin-top: 2px; }}
    .age-chart {{ display: flex; gap: 4px; align-items: flex-end; height: 60px; margin-top: 12px; }}
    .age-bar {{ flex: 1; background: var(--accent); border-radius: 3px 3px 0 0; min-height: 4px;
                position: relative; }}
    .age-bar-label {{ font-size: 0.65em; color: var(--muted); text-align: center;
                      position: absolute; bottom: -18px; width: 100%; }}
    .age-bar-count {{ font-size: 0.65em; color: var(--text); text-align: center;
                      position: absolute; top: -16px; width: 100%; }}
    .note {{ background: #1e293b; border-left: 3px solid var(--accent); border-radius: 0 6px 6px 0;
             padding: 10px 14px; font-size: 0.83em; color: var(--muted); margin-top: 12px; }}
    .two-col {{ display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }}
    @media (max-width: 700px) {{ .two-col {{ grid-template-columns: 1fr; }} }}
    footer {{ text-align: center; color: var(--muted); font-size: 0.78em; margin-top: 40px; }}
  </style>
</head>
<body>
<header>
  <div class="container">
    <h1>Memory Recall Evaluation Report</h1>
    <p>chatmem · RecentMemory BM25 Search &amp; Context Injection · {now_str}</p>
  </div>
</header>
<div class="container">

  <!-- Overall Summary -->
  <div class="section">
    <h2>Overall Summary</h2>
    <div class="kpi-grid">
      <div class="kpi">
        <div class="label">Corpus Size</div>
        <div class="value" style="color:#a5b4fc">{len(CORPUS)}</div>
        <div class="sub">session summaries · 8 months</div>
      </div>
      <div class="kpi">
        <div class="label">Eval Queries</div>
        <div class="value" style="color:#a5b4fc">{len(EVAL_QUERIES)}</div>
        <div class="sub">labeled, multi-domain</div>
      </div>
      <div class="kpi">
        <div class="label">MRR</div>
        <div class="value" style="color:{mrr_color}">{mrr_val:.3f}</div>
        <div class="sub">Mean Reciprocal Rank @5</div>
      </div>
      <div class="kpi">
        <div class="label">Hit@5</div>
        <div class="value" style="color:{'#4ade80' if h5_val >= 0.7 else '#facc15'}">{h5_val:.3f}</div>
        <div class="sub">Recall within top 5</div>
      </div>
      <div class="kpi">
        <div class="label">Tests Passed</div>
        <div class="value" style="color:#4ade80">{overall_pass}<span style="font-size:0.5em;color:#94a3b8"> /{overall_total}</span></div>
        <div class="sub">{overall_partial} partial</div>
      </div>
    </div>

    <h3>Test Suite Results</h3>
    <table>
      <thead><tr><th>Test</th><th>Status</th><th>Key Metric</th></tr></thead>
      <tbody>
        <tr><td>1. Token Cap Enforcement</td>
            <td>{_status_badge(tc.get('status'))}</td>
            <td>{tc.get('included_entries','?')}/{tc.get('total_entries','?')} entries · {tc.get('tokens_used','?')} tokens used ({tc.get('cap_utilization_pct','?')}% of cap)</td></tr>
        <tr><td>2. Context Ordering (newest-first)</td>
            <td>{_status_badge(ord_.get('status'))}</td>
            <td>{ord_.get('entries_checked','?')} entries verified · {ord_.get('oldest','?')} → {ord_.get('newest','?')}</td></tr>
        <tr><td>3. Temporal Date Filter</td>
            <td>{_status_badge(tmp.get('status'))}</td>
            <td>{tmp.get('results_found','?')} results · 0 out-of-range violations</td></tr>
        <tr><td>4. Decay Resilience</td>
            <td>{_status_badge(dec.get('status'))}</td>
            <td>{dec.get('queries_succeeded','?')}/{dec.get('queries_tested','?')} decayed queries recalled</td></tr>
        <tr><td>5. Negation Memory</td>
            <td>{_status_badge(neg.get('status'))}</td>
            <td>{neg.get('hits','?')}/{neg.get('queries_tested','?')} hits · recall {neg.get('recall_rate','?'):.0%}</td></tr>
        <tr><td>6. Multi-Session Continuity</td>
            <td>{_status_badge(cont.get('status'))}</td>
            <td>{cont.get('hits','?')}/{cont.get('queries_tested','?')} hits · recall {cont.get('recall_rate','?'):.0%}</td></tr>
        <tr><td>7. BM25 Large-Corpus Accuracy</td>
            <td>{_status_badge(bm.get('status'))}</td>
            <td>MRR={mrr_val:.3f} · Hit@1={h1_val:.3f} · Hit@3={h3_val:.3f} · Hit@5={h5_val:.3f}</td></tr>
        <tr><td>8. Search-Hit Decay Reset</td>
            <td>{_status_badge(dr.get('status'))}</td>
            <td>score {dr.get('score_before','?'):.6f} → {dr.get('score_after','?')} · last_accessed_at set</td></tr>
      </tbody>
    </table>
  </div>

  <!-- Corpus Overview -->
  <div class="section">
    <h2>Corpus Overview</h2>
    <div class="two-col">
      <div>
        <h3>Age Distribution (30-day buckets)</h3>
        <div style="position:relative;padding-bottom:22px;margin-top:8px">
          <div class="age-chart">
            {''.join(
              f'<div class="age-bar" style="height:{age_bins[i]/max(age_bins)*60 if max(age_bins) else 4}px">'
              f'<span class="age-bar-count">{age_bins[i]}</span>'
              f'<span class="age-bar-label">{(i+1)*30}d</span></div>'
              for i in range(8)
            )}
          </div>
        </div>
        <div class="note">
          Sessions span ~7 to ~240 days ago, simulating 8 months of active development.
          Decay scores range from exp(−240/21)≈0 to exp(−7/21)≈0.72.
        </div>
      </div>
      <div>
        <h3>Score Distribution by Phase</h3>
        <table>
          <thead><tr><th>Phase</th><th>Sessions</th><th>Age</th><th>Score</th></tr></thead>
          <tbody>
            <tr><td>Foundation</td><td>1–8</td><td>210–240d</td>
                <td>{_score_bar(min(math.exp(-225/21),1.0), color='#f87171')}</td></tr>
            <tr><td>Core Features</td><td>9–16</td><td>170–200d</td>
                <td>{_score_bar(min(math.exp(-185/21),1.0), color='#fb923c')}</td></tr>
            <tr><td>Performance</td><td>17–24</td><td>130–160d</td>
                <td>{_score_bar(min(math.exp(-145/21),1.0), color='#facc15')}</td></tr>
            <tr><td>Security Fixes</td><td>25–32</td><td>94–118d</td>
                <td>{_score_bar(min(math.exp(-106/21),1.0), color='#a3e635')}</td></tr>
            <tr><td>Search &amp; ML</td><td>33–40</td><td>62–85d</td>
                <td>{_score_bar(min(math.exp(-73/21),1.0), color='#4ade80')}</td></tr>
            <tr><td>DevOps</td><td>41–48</td><td>33–55d</td>
                <td>{_score_bar(min(math.exp(-44/21),1.0), color='#34d399')}</td></tr>
            <tr><td>Polish</td><td>49–54</td><td>18–29d</td>
                <td>{_score_bar(min(math.exp(-23/21),1.0), color='#22d3ee')}</td></tr>
            <tr><td>Launch</td><td>55–60</td><td>7–14d</td>
                <td>{_score_bar(min(math.exp(-10/21),1.0), color='#818cf8')}</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- BM25 Accuracy Detail -->
  <div class="section">
    <h2>BM25 Search Accuracy — Detailed Results</h2>
    <div class="stat-row">
      <div class="stat-item"><div class="k">MRR @5</div>
        <div class="v" style="color:{mrr_color}">{mrr_val:.3f}</div></div>
      <div class="stat-item"><div class="k">Hit@1</div>
        <div class="v" style="color:{'#4ade80' if h1_val>=0.5 else '#facc15'}">{h1_val:.3f}</div></div>
      <div class="stat-item"><div class="k">Hit@3</div>
        <div class="v" style="color:{'#4ade80' if h3_val>=0.65 else '#facc15'}">{h3_val:.3f}</div></div>
      <div class="stat-item"><div class="k">Hit@5</div>
        <div class="v" style="color:{'#4ade80' if h5_val>=0.7 else '#facc15'}">{h5_val:.3f}</div></div>
      <div class="stat-item"><div class="k">Queries</div>
        <div class="v">{bm.get('total_queries','?')}</div></div>
    </div>
    <table style="margin-top:16px">
      <thead><tr>
        <th>Query</th><th class="center">Expected</th>
        <th class="center">Rank</th><th class="center">RR</th><th>Description</th>
      </tr></thead>
      <tbody>{query_rows}</tbody>
    </table>
  </div>

  <!-- Decay Resilience -->
  <div class="section">
    <h2>Decay Resilience — Stale Entry Retrieval</h2>
    <p style="color:var(--muted);font-size:0.88em;margin-bottom:12px">
      Tests whether entries with Ebbinghaus score ≈ 0 (210–240 days old) remain discoverable via BM25.
      Score has no effect on search ranking — BM25 rank is purely content-based.
    </p>
    <table>
      <thead><tr><th>Query</th><th class="center">Expected Sessions</th>
                 <th class="center">Found</th><th class="center">Results</th></tr></thead>
      <tbody>{decay_rows}</tbody>
    </table>
    <div class="note">
      <strong>Design note:</strong> Decay score controls context injection priority and consolidation
      triggers, but never filters BM25 search results (min_score defaults to 0.0).
      This means all historical knowledge remains explicitly searchable regardless of age.
    </div>
  </div>

  <!-- Multi-Session Continuity -->
  <div class="section">
    <h2>Multi-Session Continuity — Long-Horizon Recall</h2>
    <p style="color:var(--muted);font-size:0.88em;margin-bottom:12px">
      Tests whether architectural decisions made in sessions 3–18 (130–232 days ago)
      remain retrievable when working in the final sprint (sessions 55–60).
    </p>
    <table>
      <thead><tr><th>Query</th><th class="center">Session</th>
                 <th class="center">Age</th><th class="center">Found</th><th>Notes</th></tr></thead>
      <tbody>{cont_rows}</tbody>
    </table>
    <div class="note">
      <strong>Continuity score:</strong> {cont.get('recall_rate', 0):.0%}
      ({cont.get('hits','?')}/{cont.get('queries_tested','?')} queries).
      Early architectural decisions (ORM rejection, JWT design, DB schema)
      remain traceable across the full 8-month project timeline.
    </div>
  </div>

  <!-- Decay Reset -->
  <div class="section">
    <h2>Search-Hit Decay Reset</h2>
    <div class="two-col">
      <div>
        <h3>Mechanism Verification</h3>
        <table>
          <thead><tr><th>Property</th><th>Before Search</th><th>After Search</th></tr></thead>
          <tbody>
            <tr><td>Entry age</td><td colspan="2">150 days</td></tr>
            <tr><td>score</td>
                <td style="color:#f87171">{dr.get('score_before','?'):.6f}</td>
                <td style="color:#4ade80">{dr.get('score_after','?')}</td></tr>
            <tr><td>last_accessed_at</td>
                <td style="color:#94a3b8">NULL</td>
                <td style="color:#4ade80">now()</td></tr>
            <tr><td>search_hit_count</td>
                <td>0</td>
                <td style="color:#4ade80">{dr.get('search_hit_count','?')}</td></tr>
          </tbody>
        </table>
      </div>
      <div>
        <h3>Ebbinghaus Lifecycle</h3>
        <div class="note" style="margin-top:0">
          <strong>Level-1 entry</strong> (stability=21d): score decays as e<sup>−t/21</sup>.
          At 150 days: score ≈ {math.exp(-150/21):.5f}.<br><br>
          A search hit resets <code>last_accessed_at = now()</code> and <code>score = 1.0</code>,
          effectively extending the entry's lifetime by another 21 days before it approaches
          the consolidation threshold (0.3).
        </div>
      </div>
    </div>
  </div>

  <!-- Methodology -->
  <div class="section">
    <h2>Methodology</h2>
    <table>
      <thead><tr><th>Parameter</th><th>Value</th></tr></thead>
      <tbody>
        <tr><td>Corpus</td><td>60 LLM-compressed session summaries, e-commerce backend project (~20K LOC)</td></tr>
        <tr><td>Time span</td><td>~7 to ~240 days ago (8 months)</td></tr>
        <tr><td>Tokenizer</td><td>count_tokens(): 0.625 tokens/Chinese char, 0.25 tokens/other char</td></tr>
        <tr><td>Inject token cap</td><td>4,000 tokens (INJECT_TOKEN_CAP)</td></tr>
        <tr><td>BM25 params</td><td>k1=1.5, b=0.75 (Okapi BM25 defaults)</td></tr>
        <tr><td>Tokenization</td><td>CJK bigrams + word tokens, Latin/CJK boundary-aware split</td></tr>
        <tr><td>Decay formula</td><td>score = exp(−days / stability), LEVEL1_STABILITY=21d</td></tr>
        <tr><td>Eval metric</td><td>MRR @5, Hit@1/3/5, per-query rank</td></tr>
        <tr><td>LLM calls</td><td>None (Compressor mocked)</td></tr>
      </tbody>
    </table>
  </div>

</div>
<footer style="padding:30px">
  Generated by <strong>test_memory_recall.py</strong> · memocode chatmem evaluation suite · {now_str}
</footer>
</body>
</html>"""
