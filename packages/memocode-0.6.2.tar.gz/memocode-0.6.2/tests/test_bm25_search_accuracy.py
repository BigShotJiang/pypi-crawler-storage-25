"""
BM25 Search Accuracy Evaluation — chatmem/memory/recent_memory

Simulates a medium-sized backend project (~28 session entries, ~15 months of work).
Evaluates search accuracy with 22 labeled queries across three languages/domains.

Metrics reported:
  - Recall@1 / @3 / @5
  - MRR (Mean Reciprocal Rank)
  - Per-query hit/miss breakdown

Run:
    python3 -m pytest tests/test_bm25_search_accuracy.py -v -s
"""

import math
import os
import sqlite3
import sys
import tempfile
import time
from typing import Optional

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.memory.recent_memory import RecentMemory, _tokenize, _bm25


# ── Corpus: 28 session summaries from a medium backend project ────────────────
# Each entry is (turn_id, content). Content simulates LLM-compressed summaries.

CORPUS = [
    # ── Architecture & stack decisions ────────────────────────────────────────
    (1,  "确定项目技术栈：后端使用 Python FastAPI，数据库选用 PostgreSQL，消息队列选 Redis。"
         "部署方案采用 Docker + Kubernetes，初期单集群，后期按需扩容。"),
    (2,  "API 设计规范讨论：统一使用 RESTful 风格，版本号放在 URL 前缀 /api/v1/，"
         "错误响应格式统一为 {code, message, data}。认证方案选择 JWT，有效期 24 小时。"),
    (3,  "数据库 schema 初版设计：users 表、orders 表、products 表。"
         "users 表包含 id、email、password_hash、created_at、role 字段。"
         "决定不使用 ORM，改用 asyncpg 直接写 SQL，原因是 ORM 在压测中比 asyncpg 慢 40%。"),
    (4,  "认证模块完成：JWT 生成与验证、refresh token 机制、密码加盐 bcrypt 哈希。"
         "接口：POST /auth/login、POST /auth/refresh、POST /auth/logout。"),
    (5,  "用户管理模块完成：用户注册、邮箱验证、个人信息修改、密码重置（发送重置邮件）。"
         "邮件发送使用 SendGrid，模板 ID 存在环境变量中。"),

    # ── Performance & database ────────────────────────────────────────────────
    (6,  "压测发现接口 P99 延迟超过 800ms，定位到 PostgreSQL 连接池耗尽问题。"
         "将连接池 max_size 从 10 调整为 50，P99 延迟降至 120ms。asyncpg 配置已更新到 config.py。"),
    (7,  "添加 Redis 缓存层：热点商品数据缓存 TTL 5 分钟，用户 session 缓存 TTL 24 小时。"
         "缓存击穿保护使用分布式锁（Redis SETNX）。缓存命中率上线后稳定在 87%。"),
    (8,  "数据库查询优化：orders 表按 user_id + created_at 建立复合索引，"
         "慢查询（>200ms）添加 EXPLAIN ANALYZE 分析，已优化 3 条高频 SQL。"),
    (9,  "引入 Prometheus + Grafana 监控：接口响应时间、数据库连接池、Redis 命中率、"
         "错误率四个核心指标。告警阈值：P95 > 500ms 触发 PagerDuty。"),
    (10, "内存泄漏排查：asyncpg 连接对象未正确释放，在高并发场景下内存持续增长。"
         "修复方案：使用 async with pool.acquire() 确保连接归还。生产已部署修复版本。"),

    # ── Order & payment features ──────────────────────────────────────────────
    (11, "订单模块开发：创建订单、取消订单、查询订单状态、订单列表分页查询。"
         "订单状态机：pending → paid → shipped → delivered → completed。"),
    (12, "支付模块集成：接入微信支付和支付宝，支付回调验签使用 HMAC-SHA256。"
         "支付状态异步通知处理，幂等性通过 payment_id 唯一约束保证。"),
    (13, "订单超时自动取消：使用 Redis Sorted Set 实现延迟队列，"
         "订单创建时写入 score=过期时间戳，定时任务每分钟扫描并取消超时订单。"),
    (14, "库存管理模块：商品库存扣减使用数据库乐观锁（version 字段），"
         "防止超卖。库存预警：低于安全库存时发送 Slack 通知。"),

    # ── Deployment & CI/CD ────────────────────────────────────────────────────
    (15, "CI/CD 流水线搭建：GitHub Actions 实现自动化测试 + 构建 Docker 镜像 + 推送 ECR。"
         "生产部署使用 ArgoCD GitOps 方案，合并到 main 自动触发部署。"),
    (16, "Kubernetes 部署配置：Deployment 副本数 3，HPA 最大 10，CPU 阈值 70%。"
         "Ingress 使用 nginx-ingress，TLS 证书 cert-manager 自动续期。"),
    (17, "生产环境首次部署出现 OOMKilled：容器内存限制 512Mi 不够，"
         "FastAPI + asyncpg 实际占用约 800Mi。调整 limits 为 1Gi，问题解决。"),
    (18, "多环境配置管理：dev/staging/prod 使用 Kubernetes ConfigMap + Secret 分离，"
         "敏感配置（数据库密码、API Key）存 AWS Secrets Manager，启动时动态注入。"),

    # ── Bug fixes & incidents ─────────────────────────────────────────────────
    (19, "线上事故：2024-03-15 凌晨 2 点，订单服务不可用约 20 分钟。"
         "根因：Redis 主节点 OOM 导致 key 被驱逐，session 大量失效，登录接口雪崩。"
         "修复：Redis maxmemory-policy 改为 allkeys-lru，增加内存至 4GB。"),
    (20, "SQL 注入漏洞修复：发现 search 接口直接拼接用户输入到 SQL。"
         "全面排查后修复 3 处，改用 asyncpg 参数化查询。安全扫描工具已加入 CI 流程。"),
    (21, "JWT token 伪造漏洞：algorithm 参数未校验，存在 alg=none 攻击。"
         "修复：强制指定 algorithm=HS256，升级 PyJWT 到 2.8.0。"),
    (22, "并发 bug：下单接口在高并发时出现重复订单，原因是 order_no 生成用了时间戳。"
         "修复：改用 UUID v4 + 数据库唯一约束双重保证。"),

    # ── Search & recommendations ──────────────────────────────────────────────
    (23, "商品搜索功能：使用 Elasticsearch 7.x，中文分词用 IK 插件，"
         "支持模糊匹配、按销量/价格排序、筛选条件组合查询。"),
    (24, "推荐系统初版：基于协同过滤，用户行为数据（浏览、购买、收藏）存 ClickHouse，"
         "每日离线训练，结果写回 Redis 供实时查询。"),

    # ── Testing & quality ─────────────────────────────────────────────────────
    (25, "测试策略：单元测试覆盖率要求 80% 以上，集成测试覆盖核心链路（下单、支付、发货）。"
         "使用 pytest + pytest-asyncio，数据库测试用 testcontainers 起真实 PostgreSQL。"),
    (26, "压力测试报告：使用 Locust 模拟 1000 并发用户，持续 10 分钟。"
         "结果：平均 RT 45ms，P99 210ms，错误率 0.02%，系统稳定性达标。"),

    # ── Team & process ────────────────────────────────────────────────────────
    (27, "代码审查规范：PR 必须至少 1 人 approve，禁止 force push main，"
         "commit message 遵循 Conventional Commits 规范。"),
    (28, "技术债务清单：① asyncpg 连接池配置散落各处需集中管理 "
         "② 部分接口缺少 rate limiting ③ 日志格式不统一需结构化 ④ 缺少链路追踪（考虑 Jaeger）。"),
]


# ── Labeled queries with ground-truth relevant turn_ids ──────────────────────
# Relevance is inclusive: a result is "correct" if its turn_id is in relevant_ids.
# Queries span Chinese, English, mixed, abbreviations, and semantic paraphrases.

QUERIES: list[dict] = [
    # ── Chinese technical queries ─────────────────────────────────────────────
    {
        "id": "Q01", "lang": "zh",
        "query": "数据库连接池",
        "relevant": {3, 6, 10},
        "note": "exact term appears in entries 3, 6, 10",
    },
    {
        "id": "Q02", "lang": "zh",
        "query": "JWT认证",
        "relevant": {2, 4, 21},
        "note": "JWT appears across auth entries",
    },
    {
        "id": "Q03", "lang": "zh",
        "query": "Redis缓存",
        "relevant": {7, 13, 19},
        "note": "Redis used in caching, queue, and incident",
    },
    {
        "id": "Q04", "lang": "zh",
        "query": "订单支付",
        "relevant": {11, 12, 13},
        "note": "order and payment domain",
    },
    {
        "id": "Q05", "lang": "zh",
        "query": "性能优化 延迟",
        "relevant": {6, 8, 26},
        "note": "multi-token Chinese query",
    },
    {
        "id": "Q06", "lang": "zh",
        "query": "安全漏洞",
        "relevant": {20, 21},
        "note": "security vulnerabilities",
    },
    {
        "id": "Q07", "lang": "zh",
        "query": "Kubernetes 部署",
        "relevant": {15, 16, 17},
        "note": "mixed Chinese+English technical term",
    },
    {
        "id": "Q08", "lang": "zh",
        "query": "线上事故 Redis",
        "relevant": {19},
        "note": "incident + specific technology",
    },
    {
        "id": "Q09", "lang": "zh",
        "query": "压力测试",
        "relevant": {6, 26},
        "note": "load testing entries",
    },
    {
        "id": "Q10", "lang": "zh",
        "query": "库存超卖",
        "relevant": {14},
        "note": "specific domain term",
    },

    # ── English technical queries ─────────────────────────────────────────────
    {
        "id": "Q11", "lang": "en",
        "query": "postgresql connection pool",
        "relevant": {3, 6, 10},
        "note": "English terms matching Chinese content",
    },
    {
        "id": "Q12", "lang": "en",
        "query": "JWT token",
        "relevant": {2, 4, 21},
        "note": "English abbreviation JWT",
    },
    {
        "id": "Q13", "lang": "en",
        "query": "CI/CD deployment",
        "relevant": {15, 16},
        "note": "DevOps terminology",
    },
    {
        "id": "Q14", "lang": "en",
        "query": "SQL injection",
        "relevant": {20},
        "note": "security vulnerability English term",
    },
    {
        "id": "Q15", "lang": "en",
        "query": "Redis OOM memory",
        "relevant": {19},
        "note": "incident keywords",
    },
    {
        "id": "Q16", "lang": "en",
        "query": "asyncpg",
        "relevant": {3, 6, 10},
        "note": "specific library name",
    },

    # ── Mixed language queries ────────────────────────────────────────────────
    {
        "id": "Q17", "lang": "mixed",
        "query": "FastAPI PostgreSQL",
        "relevant": {1, 3},
        "note": "two tech names from stack decision",
    },
    {
        "id": "Q18", "lang": "mixed",
        "query": "Elasticsearch 中文分词",
        "relevant": {23},
        "note": "mixed: English product + Chinese feature",
    },
    {
        "id": "Q19", "lang": "mixed",
        "query": "Docker Kubernetes OOMKilled",
        "relevant": {16, 17},
        "note": "multi-token mixed query",
    },

    # ── Paraphrase / semantic variants ───────────────────────────────────────
    {
        "id": "Q20", "lang": "zh",
        "query": "登录接口认证",
        "relevant": {4, 5, 21},
        "note": "paraphrase: login/auth without exact match",
    },
    {
        "id": "Q21", "lang": "zh",
        "query": "慢查询 索引",
        "relevant": {8},
        "note": "DB optimization with query/index terms",
    },
    {
        "id": "Q22", "lang": "zh",
        "query": "并发 重复",
        "relevant": {22},
        "note": "concurrency bug keywords",
    },
]


# ── Test helpers ──────────────────────────────────────────────────────────────

def _create_db_with_corpus(db_path: str) -> None:
    """Insert corpus entries directly into the recent_memory SQLite table."""
    with sqlite3.connect(db_path) as cx:
        cx.execute("""
            CREATE TABLE IF NOT EXISTS recent_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                turn_id INTEGER NOT NULL,
                content TEXT NOT NULL,
                original_content TEXT,
                compression_level INTEGER DEFAULT 1,
                token_count INTEGER NOT NULL,
                created_at REAL NOT NULL,
                score REAL DEFAULT 1.0,
                stability REAL DEFAULT 21.0,
                search_hit_count INTEGER DEFAULT 0,
                pinned INTEGER DEFAULT 0,
                last_accessed_at REAL
            )
        """)
        base_time = time.time() - 400 * 86400  # entries span ~400 days
        for i, (turn_id, content) in enumerate(CORPUS):
            cx.execute(
                """INSERT INTO recent_memory
                   (turn_id, content, token_count, created_at, score)
                   VALUES (?, ?, ?, ?, 1.0)""",
                (turn_id, content, len(content), base_time + i * 86400 * 14),
            )


def _run_search(db_path: str, query: str, top_k: int = 5) -> list[int]:
    """Run BM25 search and return list of turn_ids in ranked order."""
    query_tokens = _tokenize(query)
    if not query_tokens:
        return []

    with sqlite3.connect(db_path) as cx:
        cx.row_factory = sqlite3.Row
        rows = cx.execute(
            "SELECT turn_id, content FROM recent_memory ORDER BY turn_id"
        ).fetchall()

    if not rows:
        return []

    docs = [_tokenize(r["content"]) for r in rows]
    scores = _bm25(query_tokens, docs)

    ranked = sorted(
        zip(scores, [r["turn_id"] for r in rows]),
        key=lambda x: (-x[0], -x[1]),
    )
    return [turn_id for score, turn_id in ranked if score > 0][:top_k]


def _reciprocal_rank(results: list[int], relevant: set[int]) -> float:
    for rank, turn_id in enumerate(results, 1):
        if turn_id in relevant:
            return 1.0 / rank
    return 0.0


def _recall_at_k(results: list[int], relevant: set[int], k: int) -> float:
    hits = sum(1 for t in results[:k] if t in relevant)
    return hits / len(relevant) if relevant else 0.0


def _hit_at_k(results: list[int], relevant: set[int], k: int) -> bool:
    return any(t in relevant for t in results[:k])


# ── Main evaluation test ──────────────────────────────────────────────────────

def test_bm25_search_accuracy_report():
    """
    Full BM25 search accuracy evaluation on a 28-entry project corpus.
    Prints detailed per-query results and aggregate metrics.
    Asserts minimum acceptable thresholds.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "recent_memory.db")
        _create_db_with_corpus(db_path)

        results_by_id: dict[str, dict] = {}
        k_values = [1, 3, 5]

        for q in QUERIES:
            ranked = _run_search(db_path, q["query"], top_k=5)
            rr = _reciprocal_rank(ranked, q["relevant"])
            recalls = {k: _recall_at_k(ranked, q["relevant"], k) for k in k_values}
            hits = {k: _hit_at_k(ranked, q["relevant"], k) for k in k_values}
            results_by_id[q["id"]] = {
                "query": q["query"],
                "lang": q["lang"],
                "note": q["note"],
                "relevant": q["relevant"],
                "ranked": ranked,
                "rr": rr,
                "recalls": recalls,
                "hits": hits,
            }

        # ── Compute aggregate metrics ─────────────────────────────────────────
        n = len(QUERIES)
        mrr = sum(r["rr"] for r in results_by_id.values()) / n
        hit_at = {k: sum(r["hits"][k] for r in results_by_id.values()) / n for k in k_values}
        avg_recall = {k: sum(r["recalls"][k] for r in results_by_id.values()) / n for k in k_values}

        by_lang: dict[str, list] = {}
        for q in QUERIES:
            by_lang.setdefault(q["lang"], []).append(results_by_id[q["id"]])
        mrr_by_lang = {
            lang: sum(r["rr"] for r in rs) / len(rs)
            for lang, rs in by_lang.items()
        }

        # ── Print report ──────────────────────────────────────────────────────
        sep = "─" * 88
        print(f"\n\n{'═' * 88}")
        print("  BM25 SEARCH ACCURACY EVALUATION REPORT")
        print(f"  Corpus: {len(CORPUS)} session entries  |  Queries: {n}  |  top_k=5")
        print(f"{'═' * 88}\n")

        print(f"{'ID':<5} {'Lang':<6} {'@1':>5} {'@3':>5} {'@5':>5} {'RR':>6}  Query")
        print(sep)
        for q in QUERIES:
            r = results_by_id[q["id"]]
            h1 = "✓" if r["hits"][1] else "✗"
            h3 = "✓" if r["hits"][3] else "✗"
            h5 = "✓" if r["hits"][5] else "✗"
            print(f"{q['id']:<5} {r['lang']:<6} {h1:>5} {h3:>5} {h5:>5} {r['rr']:>6.3f}  {r['query']}")
            # Show top-3 results for misses
            if not r["hits"][5]:
                top3 = r["ranked"][:3] if r["ranked"] else []
                print(f"       {'':6} {'':>5} {'':>5} {'':>5} {'':>6}  ↳ MISS — returned: {top3}  expected: {sorted(r['relevant'])}")
        print(sep)

        print(f"\n{'AGGREGATE METRICS':}")
        print(f"  MRR:          {mrr:.3f}")
        print(f"  Hit@1:        {hit_at[1]:.3f}  ({int(hit_at[1]*n)}/{n})")
        print(f"  Hit@3:        {hit_at[3]:.3f}  ({int(hit_at[3]*n)}/{n})")
        print(f"  Hit@5:        {hit_at[5]:.3f}  ({int(hit_at[5]*n)}/{n})")
        print(f"  Recall@1:     {avg_recall[1]:.3f}")
        print(f"  Recall@3:     {avg_recall[3]:.3f}")
        print(f"  Recall@5:     {avg_recall[5]:.3f}")

        print(f"\n{'MRR BY LANGUAGE':}")
        for lang, m in sorted(mrr_by_lang.items()):
            count = len(by_lang[lang])
            print(f"  {lang:<8}: {m:.3f}  (n={count})")

        # ── Failure analysis ──────────────────────────────────────────────────
        misses_at5 = [q["id"] for q in QUERIES if not results_by_id[q["id"]]["hits"][5]]
        if misses_at5:
            print(f"\n{'MISSED QUERIES (not found in top-5)':}")
            for qid in misses_at5:
                r = results_by_id[qid]
                print(f"  {qid}: {r['query']!r}")
                print(f"       expected turn_ids: {sorted(r['relevant'])}")
                print(f"       returned turn_ids: {r['ranked'][:5]}")
                # Token-level diagnosis
                qtoks = set(_tokenize(r["query"]))
                for tid in sorted(r["relevant"]):
                    entry_text = next(c for t, c in CORPUS if t == tid)
                    etoks = set(_tokenize(entry_text))
                    overlap = qtoks & etoks
                    print(f"       turn {tid} token overlap: {sorted(overlap) or '(none)'}")

        # ── Tokenization spot-check ───────────────────────────────────────────
        print(f"\n{'TOKENIZER SPOT-CHECK':}")
        spot = [
            ("数据库连接池", ["数据", "据库", "库连", "连接", "接池"]),
            ("JWT认证",     ["jwt", "认证"]),
            ("PostgreSQL",  ["postgresql"]),
            ("asyncpg连接", ["asyncpg", "连接"]),
            ("Redis缓存",   ["redis", "缓存"]),
            ("token认证",   ["token", "认证"]),
        ]
        for text, expected_subset in spot:
            tokens = _tokenize(text)
            found = [t for t in expected_subset if t in tokens]
            status = "✓" if found else "✗"
            print(f"  {status} _tokenize({text!r}) ⊇ {found} (from {expected_subset})")

        print(f"\n{'═' * 88}\n")

        # ── Assertions: minimum acceptable thresholds ─────────────────────────
        assert mrr >= 0.40, f"MRR {mrr:.3f} below 0.40 — BM25 retrieval critically poor"
        assert hit_at[1] >= 0.35, f"Hit@1 {hit_at[1]:.3f} below 0.35"
        assert hit_at[3] >= 0.55, f"Hit@3 {hit_at[3]:.3f} below 0.55"
        assert hit_at[5] >= 0.65, f"Hit@5 {hit_at[5]:.3f} below 0.65"


# ── Unit tests for tokenizer edge cases ──────────────────────────────────────

def test_tokenize_pure_chinese():
    tokens = _tokenize("数据库连接")
    assert "数据" in tokens
    assert "据库" in tokens
    assert "库连" in tokens
    assert "连接" in tokens


def test_tokenize_pure_english():
    tokens = _tokenize("PostgreSQL connection pool")
    assert "postgresql" in tokens
    assert "connection" in tokens
    assert "pool" in tokens


def test_tokenize_mixed():
    tokens = _tokenize("Redis缓存")
    # Latin/CJK boundary split: "redis缓存" → "redis" + "缓存" as separate tokens
    assert "redis" in tokens
    assert "缓存" in tokens


def test_tokenize_abbreviation():
    tokens = _tokenize("JWT token认证")
    assert "jwt" in tokens
    assert "token" in tokens  # boundary split separates "token" from "认证"
    assert "认证" in tokens


def test_tokenize_empty():
    assert _tokenize("") == []


def test_tokenize_single_char():
    # Single chars filtered from Latin tokens (len > 1 check)
    tokens = _tokenize("a b c")
    assert "a" not in tokens
    assert "b" not in tokens


def test_bm25_single_doc_exact_match():
    scores = _bm25(["redis"], [["redis", "缓存", "命中"]])
    assert scores[0] > 0


def test_bm25_no_match():
    scores = _bm25(["kubernetes"], [["redis", "缓存"]])
    assert scores[0] == 0.0


def test_bm25_ranking_order():
    """Document with more query term occurrences should rank higher."""
    scores = _bm25(
        ["redis"],
        [
            ["redis"],                           # 1 occurrence
            ["redis", "redis", "redis", "缓存"],  # 3 occurrences
            ["postgresql", "连接池"],             # 0 occurrences
        ],
    )
    assert scores[1] > scores[0] > scores[2]


def test_bm25_length_normalization():
    """Shorter doc with same TF should rank higher than longer doc (length penalty)."""
    scores = _bm25(
        ["redis"],
        [
            ["redis"] + ["x"] * 100,  # long doc, 1 hit
            ["redis"],                # short doc, 1 hit
        ],
    )
    assert scores[1] > scores[0], "shorter doc should score higher for same TF"
