"""Tests for control/resources/manager.py — ResourceManager staging/commit"""
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.resources.manager import ResourceManager


@pytest.fixture
def rm(tmp_path):
    return ResourceManager(db_path=str(tmp_path / "resources.db"))


@pytest.fixture
def sample_file(tmp_path):
    f = tmp_path / "sample.py"
    f.write_text("def hello(): pass\n")
    return str(f)


@pytest.fixture
def rm_with_entry(rm, sample_file):
    rm.register(
        path=sample_file,
        name="Sample",
        description="A sample file",
        tags=["python"],
    )
    return rm, sample_file


# ── register / list / find ────────────────────────────────────────────────────

def test_register_and_list(rm, sample_file):
    rm.register(sample_file, "Sample", "A file", ["py"])
    entries = rm.list_all()
    assert len(entries) == 1
    assert entries[0]["name"] == "Sample"


def test_register_file_not_found(rm):
    with pytest.raises(FileNotFoundError):
        rm.register("/nonexistent/file.py", "X", "Y", [])


def test_find_by_keyword(rm_with_entry):
    rm, sample_file = rm_with_entry
    results = rm.find("sample")
    assert len(results) == 1
    assert results[0]["name"] == "Sample"


def test_find_no_match(rm_with_entry):
    rm, _ = rm_with_entry
    results = rm.find("xyz_nonexistent_keyword")
    assert results == []


def test_list_all_empty(rm):
    assert rm.list_all() == []


def test_delete_entry(rm_with_entry):
    rm, sample_file = rm_with_entry
    rm.delete(sample_file)
    assert rm.list_all() == []


# ── stage_delete ──────────────────────────────────────────────────────────────

def test_stage_delete_by_keyword(rm_with_entry):
    rm, sample_file = rm_with_entry
    staged = rm.stage_delete("sample")
    assert len(staged) == 1
    assert staged[0]["name"] == "Sample"
    assert len(rm._pending_delete) == 1


def test_stage_delete_all_wildcard(rm_with_entry):
    rm, _ = rm_with_entry
    staged = rm.stage_delete("*")
    assert len(staged) == 1
    assert len(rm._pending_delete) == 1


def test_stage_delete_all_keyword(rm_with_entry):
    rm, _ = rm_with_entry
    staged = rm.stage_delete("all")
    assert len(staged) == 1


def test_stage_delete_empty_string_deletes_all(rm_with_entry):
    rm, _ = rm_with_entry
    staged = rm.stage_delete("")
    assert len(staged) == 1


def test_stage_delete_no_match(rm_with_entry):
    rm, _ = rm_with_entry
    staged = rm.stage_delete("xyz_no_match")
    assert staged == []
    assert rm._pending_delete == []


# ── commit_pending ────────────────────────────────────────────────────────────

def test_commit_pending_deletes(rm_with_entry):
    rm, sample_file = rm_with_entry
    rm.stage_delete("*")
    result = rm.commit_pending()
    assert len(result["deleted"]) == 1
    assert rm.list_all() == []
    assert rm._pending_delete == []


def test_commit_pending_clears_staging(rm_with_entry):
    rm, _ = rm_with_entry
    rm.stage_delete("*")
    rm.commit_pending()
    # staging area should be empty after commit
    assert rm._pending_delete == []
    assert rm._pending == []


def test_commit_pending_empty_staging(rm):
    result = rm.commit_pending()
    assert result == {"registered": [], "deleted": []}


def test_stage_delete_empty_db(rm):
    # Should not crash on empty DB
    staged = rm.stage_delete("*")
    assert staged == []


def test_commit_pending_empty_db(rm):
    rm.stage_delete("*")
    result = rm.commit_pending()
    assert result["deleted"] == []
