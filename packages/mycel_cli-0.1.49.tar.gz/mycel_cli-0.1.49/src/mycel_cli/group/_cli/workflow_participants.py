from __future__ import annotations

from typing import Any

from mycel_cli.group._state.workflow import remove_participant, upsert_participant
from mycel_cli.identity_store import IdentityStore

KEEP_PRESET = "keep.v1"


def upsert_keep_participant(
    group_id: str,
    *,
    role: str,
    session: str,
    user_id: str,
    name: str | None = None,
) -> None:
    preset_ref = f"{KEEP_PRESET}.{role}"
    upsert_participant(
        group_id,
        participant=_keep_participant(
            role=role,
            session=session,
            user_id=user_id,
            name=name,
            preset_ref=preset_ref,
        ),
        replace_alias=session,
        replace_preset_ref=preset_ref,
    )


def remove_keep_participant(group_id: str, *, role: str, session: str) -> None:
    remove_participant(
        group_id,
        alias=session,
        preset_ref=f"{KEEP_PRESET}.{role}",
    )


def sync_keep_participant_from_role(group_id: str, record: dict[str, Any]) -> None:
    role = str(record.get("role") or "").strip()
    session = str(record.get("session") or "").strip()
    if not role or not session:
        raise RuntimeError("group role record must include role and session")
    upsert_keep_participant(
        group_id,
        role=role,
        session=session,
        name=str(record.get("name") or "") or None,
        user_id=_role_user_id(record),
    )


def _keep_participant(
    *,
    role: str,
    session: str,
    user_id: str,
    name: str | None,
    preset_ref: str,
) -> dict[str, Any]:
    return {
        "handle": str(name or session),
        "user_id": user_id,
        "labels": [role],
        "aliases": _keep_aliases(role=role, session=session, name=name),
        "preset_ref": preset_ref,
        "capabilities": _keep_capabilities(role),
    }


def _keep_capabilities(role: str) -> list[str]:
    capabilities = {
        "supervisor": ["group.manage", "task.assign", "message.address"],
        "worker": ["task.execute", "message.reply"],
        "reviewer": ["task.review", "group.stop.review", "message.reply"],
    }.get(role)
    if capabilities is None:
        raise ValueError(f"unknown keep participant role: {role}")
    return capabilities


def _unique_refs(*refs: str | None) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for ref in refs:
        value = str(ref or "").strip()
        if not value or value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _keep_aliases(*, role: str, session: str, name: str | None) -> list[str]:
    role_alias = role if role == "supervisor" else None
    return _unique_refs(session, name, role_alias)


def _role_user_id(record: dict[str, Any]) -> str:
    local_id = str(record.get("local_id") or "")
    if not local_id:
        raise RuntimeError("group role has no local_id")
    identity = IdentityStore.from_env().get_identity(local_id)
    user_id = str(identity.get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError(f"identity {local_id!r} has no user_id")
    return user_id
