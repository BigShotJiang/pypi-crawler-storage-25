"""Parsing, validation, and resolution helpers for CLI dispatch."""

from __future__ import annotations

import os
import uuid
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

import click
import typer

from mycel_cli.group._cli.constants import (
    COMMAND_HELP,
    TASK_STATUS_ALLOWED,
    UUID_CANONICAL_RE,
    UUID_PREFIX_RE,
)
from mycel_cli.group._workflow.constants import (
    EV_GROUP_STOP,
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
)
from mycel_cli.group._process.processes import pid_exists
from mycel_cli.group._state.globals_ import load_global
from mycel_cli.group._state.groups import (
    group_terminal_type,
    load_group,
    mutate_group,
)
from mycel_cli.group._state.messages import (
    append_message_index,
    messages_dir,
)
from mycel_cli.group._state.roles import (
    find_supervisor,
    find_worker,
    iter_reviewers,
    iter_workers,
    role_agent_type,
)
from mycel_cli.group._state.config import is_workers_enabled_for_group
from mycel_cli.group.worker import WorkerInfo, resolve_worker, worker_cache_from_info

CommandHandler = Callable[[], None]


# ── cel config ─────────────────────────────────────────────────
def load_mycel_config() -> dict:
    from mycel_cli.group._state.config import get_global_config

    return get_global_config()


def save_mycel_config(config: dict) -> None:
    import json
    from mycel_cli.group._state.config import _config_path, _invalidate_cache
    from mycel_cli.group._state.paths import atomic_write_text

    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(path, json.dumps(config, indent=2, ensure_ascii=False))
    _invalidate_cache()


# ── required preconditions ─────────────────────────────────────
def require_global() -> dict:
    state = load_global()
    if state is None:
        typer.echo("没有活跃的 cel。先运行 cel self start", err=True)
        raise typer.Exit(1)
    return state


def require_group_by_name(name: str) -> dict:
    group = load_group(name)
    if group is None:
        typer.echo(f"Group '{name}' 不存在", err=True)
        raise typer.Exit(1)
    return group


def dispatch_command(command: str | None, handlers: dict[str, CommandHandler]) -> None:
    handler = handlers.get(command or "")
    if handler is None:
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)
    handler()


def require_group_active(group_id: str, group: dict) -> None:
    if group.get("status") == "stopped":
        typer.echo(
            f"Group '{group_id}' 已停止，本地事件检测不会处理后续事件。"
            f" 请先运行：cel group start {group_id}",
            err=True,
        )
        raise typer.Exit(1)


def require_mycel_daemon_ready(*, command: str) -> dict:
    global_state = require_global()
    if global_state.get("stopped"):
        typer.echo(
            f"Mycel daemon 已停止，{command} 无法继续：本地事件检测不会处理后续事件。"
            " 请先运行：cel self start",
            err=True,
        )
        raise typer.Exit(1)
    if not is_daemon_running(global_state):
        from mycel_cli.group._cli.spawn import launch_daemon

        launch_daemon(global_state, False, quiet=True)
        global_state = require_global()
        if not is_daemon_running(global_state):
            typer.echo(
                f"本地 Mycel 服务未运行，{command} 无法继续：后续事件不会被处理。"
                " 请先运行：cel self start",
                err=True,
            )
            raise typer.Exit(1)
    return global_state


def require_group_event_processing_active(
    group_id: str,
    group: dict,
    *,
    command: str,
) -> None:
    require_mycel_daemon_ready(command=command)
    require_group_active(group_id, group)


def reviewer_covers_event(reviewer: dict, event_type: str) -> bool:
    triggers = reviewer.get("triggers")
    if triggers is None:
        return True
    return event_type in triggers


REQUIRED_REVIEW_EVENTS = (
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    EV_GROUP_STOP,
)
REVIEW_EVENT_LABELS = {
    EV_TASK_PROPOSED_REVIEW: "task_proposed_review",
    EV_TASK_SUBMITTED_REVIEW: "task_submitted_review",
    EV_GROUP_STOP: "group_stop",
}


def review_event_coverage(reviewers: list[dict]) -> dict[str, list[str]]:
    coverage: dict[str, list[str]] = {
        event_type: [] for event_type in REQUIRED_REVIEW_EVENTS
    }
    for reviewer in reviewers:
        label = reviewer.get("name") or reviewer.get("id", "?")
        for event_type in REQUIRED_REVIEW_EVENTS:
            if reviewer_covers_event(reviewer, event_type):
                coverage[event_type].append(label)
    return coverage


def missing_review_events(reviewers: list[dict]) -> list[str]:
    coverage = review_event_coverage(reviewers)
    return [
        event_type for event_type in REQUIRED_REVIEW_EVENTS if not coverage[event_type]
    ]


def require_reviewer_event_coverage(group_id: str, event_type: str) -> list[dict]:
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if not reviewers:
        typer.echo(
            f"Group '{group_id}' 无法发起 {event_type}：没有 reviewer。",
            err=True,
        )
        raise typer.Exit(1)
    if not any(reviewer_covers_event(reviewer, event_type) for reviewer in reviewers):
        typer.echo(
            f"Group '{group_id}' 无法发起 {event_type}：没有 reviewer 覆盖 {event_type}。",
            err=True,
        )
        raise typer.Exit(1)
    return reviewers


def require_workers_enabled(group_id: str, group: dict, *, command: str) -> None:
    if is_workers_enabled_for_group(group):
        return
    typer.echo(
        f"Group '{group_id}' worker roles are disabled，不能执行 {command}。"
        " 该模式下应由 supervisor 使用 Agent tool 派 subagent 完成工作。",
        err=True,
    )
    raise typer.Exit(1)


# ── id / session generators ────────────────────────────────────
def generate_session_id() -> str:
    return str(uuid.uuid4())


# ── formatting ─────────────────────────────────────────────────
def format_timestamp(ts: float | None) -> str:
    if not ts:
        return "未知"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


# ── option parsing ─────────────────────────────────────────────
def extract_named_option(args: list[str], option: str) -> tuple[str | None, list[str]]:
    rest = list(args)
    if option not in rest:
        return None, rest
    index = rest.index(option)
    if index + 1 >= len(rest):
        typer.echo(f"Missing value for {option}", err=True)
        raise typer.Exit(2)
    value = rest[index + 1]
    del rest[index : index + 2]
    return value, rest


def reject_unknown_args(args: list[str]) -> None:
    if args:
        typer.echo(f"No such argument: {args[0]}", err=True)
        raise typer.Exit(2)


# ── resolvers (by UUID or prefix) ──────────────────────────────
def resolve_session_id_by_prefix_or_fail(
    *,
    group: dict,
    role: str,
    raw_id: str,
    id_label: str,
) -> str:
    roles = [
        u
        for u in group.get("roles", [])
        if u.get("role") == role and isinstance(u.get("session"), str)
    ]
    sessions = [u["session"] for u in roles]

    if raw_id in sessions:
        return raw_id

    if UUID_CANONICAL_RE.fullmatch(raw_id):
        if raw_id in sessions:
            return raw_id
        cross_role = [
            (u.get("role"), u["session"])
            for u in group.get("roles", [])
            if u.get("role") != role
            and isinstance(u.get("session"), str)
            and u["session"] == raw_id
        ]
        if len(cross_role) == 1:
            other_role, other_session = cross_role[0]
            typer.echo(
                f"{id_label} '{raw_id}' 不存在。这个 id 属于 group '{group['name']}' 的 {other_role} "
                f"(session={other_session[:8]})，不是 {role}。",
                err=True,
            )
            if other_role == "supervisor" and role == "worker":
                typer.echo(
                    "消息请使用顶层 cel send-message；group role 命令只管理 workflow。",
                    err=True,
                )
            raise typer.Exit(1)
        typer.echo(f"{id_label} '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)

    if not UUID_PREFIX_RE.fullmatch(raw_id):
        typer.echo(f"{id_label} 必须是 UUID 或唯一前缀", err=True)
        raise typer.Exit(1)

    matches = [session for session in sessions if session.startswith(raw_id)]
    if not matches:
        cross_role = [
            (u.get("role"), u["session"])
            for u in group.get("roles", [])
            if u.get("role") != role
            and isinstance(u.get("session"), str)
            and u["session"].startswith(raw_id)
        ]
        if len(cross_role) == 1:
            other_role, other_session = cross_role[0]
            typer.echo(
                f"{id_label} '{raw_id}' 不存在。这个 id 属于 group '{group['name']}' 的 {other_role} "
                f"(session={other_session[:8]})，不是 {role}。",
                err=True,
            )
            if other_role == "supervisor" and role == "worker":
                typer.echo(
                    "消息请使用顶层 cel send-message；group role 命令只管理 workflow。",
                    err=True,
                )
            raise typer.Exit(1)
        typer.echo(f"{id_label} '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)
    if len(matches) > 1:
        candidates = ", ".join(sorted(matches))
        typer.echo(f"{id_label} '{raw_id}' 歧义: {candidates}", err=True)
        raise typer.Exit(1)
    return matches[0]


def resolve_reviewer_id_by_prefix_or_fail(*, group_id: str, raw_id: str) -> str:
    """Resolve a reviewer_id (full or prefix) to a canonical id, or exit(1)."""
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    # Match by canonical id first
    for r in reviewers:
        if r.get("id") == raw_id:
            return r["id"]

    ids = [r["id"] for r in reviewers if "id" in r]
    matches = [rid for rid in ids if rid.startswith(raw_id)]
    if not matches:
        typer.echo(f"Reviewer '{raw_id}' 不存在", err=True)
        raise typer.Exit(1)
    if len(matches) > 1:
        candidates = ", ".join(sorted(matches))
        typer.echo(f"Reviewer '{raw_id}' 歧义: {candidates}", err=True)
        raise typer.Exit(1)
    return matches[0]


def resolve_task_status_or_fail(status: str) -> str:
    if status not in TASK_STATUS_ALLOWED:
        allowed = ", ".join(sorted(TASK_STATUS_ALLOWED))
        typer.echo(f"Invalid --status '{status}'. allowed: {allowed}", err=True)
        raise typer.Exit(2)
    return status


# ── payload parsers ────────────────────────────────────────────
def parse_task_ids_csv_or_fail(raw: str, *, option: str = "--tasks") -> list[str]:
    task_ids = [part.strip() for part in raw.split(",") if part.strip()]
    if not task_ids:
        typer.echo(f"{option} requires at least one task id", err=True)
        raise typer.Exit(2)
    return task_ids


def parse_task_selector_or_fail(
    payload: list[str],
    *,
    allow_missing: bool = False,
    allow_positional: bool = False,
) -> tuple[list[str], list[str]]:
    tasks_raw, rest = extract_named_option(payload, "--tasks")
    if tasks_raw is None:
        if allow_positional and payload and not payload[0].startswith("-"):
            return parse_task_ids_csv_or_fail(payload[0], option="task_id"), payload[1:]
        if allow_missing:
            return [], rest
        typer.echo("--tasks is required", err=True)
        raise typer.Exit(2)
    return parse_task_ids_csv_or_fail(tasks_raw), rest


def parse_task_update_payload(
    payload: list[str],
) -> tuple[list[str], dict[str, object], str | None]:
    """Returns (task_ids, patch, rationale_file_raw)."""
    if payload and payload[0] in {"-h", "--help"}:
        typer.echo(COMMAND_HELP["task"]["update"])
        raise typer.Exit()
    task_ids, rest = parse_task_selector_or_fail(payload)
    option_map = {
        "--subject": "subject",
        "--description": "description",
        "--status": "status",
        "--owner": "owner",
        "--blocks": "blocks",
        "--blocked-by": "blockedBy",
    }

    patch: dict[str, object] = {}
    rationale_file_raw: str | None = None
    index = 0
    while index < len(rest):
        option = rest[index]
        if option == "--rationale":
            if index + 1 >= len(rest):
                typer.echo("Missing value for --rationale", err=True)
                raise typer.Exit(2)
            rationale_file_raw = rest[index + 1]
            index += 2
            continue
        field = option_map.get(option)
        if field is None:
            if option.startswith("--"):
                typer.echo(f"No such option '{option}'", err=True)
            else:
                typer.echo(f"Unexpected argument '{option}'", err=True)
            raise typer.Exit(2)
        if index + 1 >= len(rest):
            typer.echo(f"Missing value for {option}", err=True)
            raise typer.Exit(2)

        value = rest[index + 1]
        if field in {"blocks", "blockedBy"}:
            patch[field] = [item.strip() for item in value.split(",") if item.strip()]
        elif field == "status":
            patch[field] = resolve_task_status_or_fail(value)
        else:
            patch[field] = value
        index += 2

    return task_ids, patch, rationale_file_raw


def parse_name_path_update(
    payload: list[str], *, id_label: str
) -> tuple[str, str | None, str | None]:
    if not payload:
        typer.echo(f"{id_label} is required", err=True)
        raise typer.Exit(2)

    target_id, name, path = parse_optional_name_path_update(payload)
    if target_id is None:
        typer.echo(f"{id_label} is required", err=True)
        raise typer.Exit(2)
    return target_id, name, path


def parse_optional_name_path_update(
    payload: list[str],
) -> tuple[str | None, str | None, str | None]:
    target_id: str | None = None
    rest = list(payload)
    if rest and not rest[0].startswith("--"):
        target_id = rest[0]
        rest = rest[1:]

    name: str | None = None
    path: str | None = None
    index = 0
    while index < len(rest):
        option = rest[index]
        if option not in {"--name", "--path"}:
            if option.startswith("--"):
                typer.echo(f"No such option '{option}'", err=True)
            else:
                typer.echo(f"Unexpected argument '{option}'", err=True)
            raise typer.Exit(2)
        if index + 1 >= len(rest):
            typer.echo(f"Missing value for {option}", err=True)
            raise typer.Exit(2)
        value = rest[index + 1]
        if option == "--name":
            name = value
        else:
            path = value
        index += 2

    return target_id, name, path


def _find_worker_by_session_or_fail(group: dict, session: str) -> dict:
    worker = find_worker(group, session)
    if worker is None:
        typer.echo("Worker not found in group", err=True)
        raise typer.Exit(1)
    return worker


def parse_worker_target_or_fail(
    group: dict, payload: list[str]
) -> tuple[dict, list[str]]:
    """Select the target worker from a (possibly empty / prefixed) payload.

    Returns (worker_dict, remaining_payload_after_worker_id).
    """
    workers = iter_workers(group)
    if payload and payload[0] in {"-h", "--help"}:
        help_text = COMMAND_HELP.get("supervisor", {}).get("wake")
        if help_text:
            typer.echo(help_text)
            raise typer.Exit()
        typer.echo("Usage: cel group <group_id> supervisor wake [worker_id]")
        raise typer.Exit()

    if not workers:
        typer.echo("Worker not found in group", err=True)
        raise typer.Exit(1)

    if len(workers) == 1:
        only_worker = workers[0]
        if not payload:
            return only_worker, []
        if payload[0].startswith("--"):
            raise click.UsageError(f"No such option '{payload[0]}'")

        resolved = resolve_session_id_by_prefix_or_fail(
            group=group,
            role="worker",
            raw_id=payload[0],
            id_label="worker_id",
        )
        return _find_worker_by_session_or_fail(group, resolved), payload[1:]

    if not payload:
        typer.echo("Multiple workers found; specify worker_id", err=True)
        raise typer.Exit(1)
    if payload[0].startswith("--"):
        raise click.UsageError(f"No such option '{payload[0]}'")

    resolved = resolve_session_id_by_prefix_or_fail(
        group=group,
        role="worker",
        raw_id=payload[0],
        id_label="worker_id",
    )
    return _find_worker_by_session_or_fail(group, resolved), payload[1:]


# ── worker process cache + online check ────────────────────────
def refresh_worker_cache(worker: dict, group_name: str, group: dict) -> WorkerInfo:
    terminal_type = group_terminal_type(group)
    agent_type = role_agent_type(worker)
    if agent_type == "codex":
        info = resolve_worker(
            worker["session"],
            terminal_type,
            agent_type=agent_type,
            cache_hint=worker.get("cache") or {},
        )
    else:
        info = resolve_worker(worker["session"], terminal_type)
    if info.running:
        new_cache = worker_cache_from_info(info)
        # Non-cmux terminals: target_id is stable, preserve existing cache value
        if new_cache.get("target_id") is None:
            existing_target_id = (worker.get("cache") or {}).get("target_id")
            if existing_target_id:
                new_cache["target_id"] = existing_target_id
        if new_cache != worker.get("cache"):
            worker["cache"] = new_cache
            with mutate_group(group_name) as fresh_group:
                fresh_worker = find_worker(fresh_group, worker["session"])
                if fresh_worker is not None:
                    fresh_worker["cache"] = new_cache
    return info


def ensure_worker_online_or_fail(
    *, worker: dict, group_id: str, group: dict
) -> tuple[str, str, WorkerInfo]:
    info = refresh_worker_cache(worker, group_id, group)
    if not info.running:
        typer.echo("Worker is offline", err=True)
        raise typer.Exit(1)
    target_id = (worker.get("cache") or {}).get("target_id")
    return group_terminal_type(group), str(target_id or ""), info


# ── path + file helpers ────────────────────────────────────────
def validate_spawn_path_or_fail(path: str | None) -> None:
    if path is None:
        return
    if not os.path.isdir(path):
        typer.echo(f"path 不存在或不是目录: {path}", err=True)
        raise typer.Exit(1)


def ensure_file_in_messages_dir(
    group: dict, file_arg: str, label: str = "file", record_index: bool = False
) -> Path:
    """Copy file into group messages/ dir if not already there. Returns final path.

    If record_index is True, appends an entry to index.json after copying.
    """
    src_path = Path(file_arg).expanduser().resolve()
    if not src_path.is_file():
        typer.echo(f"Error: {label} not found: {file_arg}", err=True)
        raise typer.Exit(2)
    msg_dir = messages_dir(group["name"])
    if src_path.parent.resolve() != msg_dir.resolve():
        dest = msg_dir / src_path.name
        dest.write_bytes(src_path.read_bytes())
        typer.echo(
            f"Warning: {label} copied to {dest} — create new message files here.",
            err=True,
        )
        final_path = dest
    else:
        final_path = src_path
    if record_index:
        sup = find_supervisor(group)
        supervisor_session = sup["session"][:8] if sup else "unknown"
        append_message_index(
            group["name"],
            {
                "role": "supervisor",
                "session": supervisor_session,
                "type": "rationale",
                "file": final_path.name,
            },
        )
    return final_path


def is_daemon_running(global_state: dict) -> bool:
    pid = global_state.get("daemon_pid")
    if not pid:
        return False
    return pid_exists(pid)
