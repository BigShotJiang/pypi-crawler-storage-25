"""Chat workflow header store for cel groups."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mycel_cli.config import load_owner_config
from mycel_cli.group._state.groups import mutate_group
from mycel_sdk import Client

KIND = "cel-group"
DEFAULT_PRESET = "keep.v1"
_OMIT = object()


@dataclass(frozen=True)
class GroupWorkflowHeader:
    state: str
    group_prompt: str | None
    terminal_type: str | None
    workers_enabled: bool | None
    created_at: float | None
    updated_at: float | None


def _client() -> Client:
    cfg = load_owner_config()
    return Client(base_url=cfg.base_url, auth_token=cfg.auth_token)


def _workflow_or_fail(chat_id: str) -> dict[str, Any]:
    workflow = _client().chats.get_workflow(chat_id)
    if not isinstance(workflow, dict):
        raise RuntimeError(f"backend workflow not found for group '{chat_id}'")
    if workflow.get("kind") != KIND:
        raise RuntimeError(
            f"group '{chat_id}' is workflow kind {workflow.get('kind')!r}, expected {KIND!r}"
        )
    return workflow


def _header_from_workflow(workflow: dict[str, Any]) -> GroupWorkflowHeader:
    config = dict(workflow.get("config") or {})
    return GroupWorkflowHeader(
        state=str(workflow.get("state") or "stopped"),
        group_prompt=config.get("group_prompt"),
        terminal_type=config.get("terminal_type"),
        workers_enabled=config.get("workers_enabled"),
        created_at=workflow.get("created_at"),
        updated_at=workflow.get("updated_at"),
    )


def get_header(chat_id: str) -> GroupWorkflowHeader:
    return _header_from_workflow(_workflow_or_fail(chat_id))


def create_workflow(
    chat_id: str,
    *,
    terminal_type: str,
    workers_enabled: bool,
    state: str = "stopped",
) -> GroupWorkflowHeader:
    workflow = _client().chats.set_workflow(
        chat_id,
        kind=KIND,
        state=state,
        config={
            "terminal_type": terminal_type,
            "workers_enabled": workers_enabled,
            "preset": DEFAULT_PRESET,
            "participants": [],
        },
    )
    if not isinstance(workflow, dict):
        raise RuntimeError("backend did not return a group workflow payload")
    return _header_from_workflow(workflow)


def set_header(
    chat_id: str,
    *,
    state: str | None = None,
    group_prompt: str | None | object = _OMIT,
    terminal_type: str | object = _OMIT,
    workers_enabled: bool | object = _OMIT,
) -> GroupWorkflowHeader:
    workflow = _workflow_or_fail(chat_id)
    config = dict(workflow.get("config") or {})
    if group_prompt is not _OMIT:
        if group_prompt:
            config["group_prompt"] = group_prompt
        else:
            config.pop("group_prompt", None)
    if terminal_type is not _OMIT:
        config["terminal_type"] = terminal_type
    if workers_enabled is not _OMIT:
        config["workers_enabled"] = workers_enabled
    updated = _client().chats.set_workflow(
        chat_id,
        kind=KIND,
        state=state or str(workflow.get("state") or "stopped"),
        config=config,
    )
    if not isinstance(updated, dict):
        raise RuntimeError("backend did not return a workflow payload")
    return _header_from_workflow(updated)


def delete_header(chat_id: str) -> None:
    _client().chats.delete_workflow(chat_id)


def upsert_participant(
    chat_id: str,
    *,
    participant: dict[str, Any],
    replace_alias: str,
    replace_preset_ref: str | None = None,
) -> None:
    workflow = _workflow_or_fail(chat_id)
    config = dict(workflow.get("config") or {})
    config["preset"] = str(config.get("preset") or DEFAULT_PRESET)
    config["participants"] = [
        item
        for item in _participant_list(config.get("participants"))
        if not _same_participant(
            item,
            alias=replace_alias,
            preset_ref=replace_preset_ref,
        )
    ]
    config["participants"].append(dict(participant))
    _client().chats.set_workflow(
        chat_id,
        kind=KIND,
        state=str(workflow.get("state") or "stopped"),
        config=config,
    )


def remove_participant(
    chat_id: str, *, alias: str, preset_ref: str | None = None
) -> None:
    workflow = _workflow_or_fail(chat_id)
    config = dict(workflow.get("config") or {})
    config["participants"] = [
        item
        for item in _participant_list(config.get("participants"))
        if not _same_participant(item, alias=alias, preset_ref=preset_ref)
    ]
    _client().chats.set_workflow(
        chat_id,
        kind=KIND,
        state=str(workflow.get("state") or "stopped"),
        config=config,
    )


def _participant_list(raw: Any) -> list[dict[str, Any]]:
    if not isinstance(raw, list):
        return []
    return [dict(item) for item in raw if isinstance(item, dict)]


def _same_participant(
    item: dict[str, Any], *, alias: str, preset_ref: str | None
) -> bool:
    if preset_ref is not None and item.get("preset_ref") != preset_ref:
        return False
    aliases = item.get("aliases")
    return isinstance(aliases, list) and alias in {str(item) for item in aliases}


def apply_header(group: dict[str, Any], header: GroupWorkflowHeader) -> dict[str, Any]:
    group["status"] = header.state
    group["group_prompt"] = header.group_prompt
    if header.terminal_type is not None:
        group["terminal_type"] = header.terminal_type
    if header.workers_enabled is not None:
        group["workers_enabled"] = header.workers_enabled
    if header.created_at is not None:
        group["created_at"] = header.created_at
    return group


def mirror_header(chat_id: str, header: GroupWorkflowHeader) -> dict[str, Any]:
    with mutate_group(chat_id) as group:
        apply_header(group, header)
        return dict(group)
