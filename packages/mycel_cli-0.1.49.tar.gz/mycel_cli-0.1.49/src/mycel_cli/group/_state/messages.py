"""Unified messages/ directory for group workflow evidence.

Workflow events such as worker stop and daemon notices are indexed here.
index.json is the sequential log; file mtime is the timestamp on disk.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from filelock import FileLock

from mycel_cli.group._state import paths as _paths
from mycel_cli.group._state.paths import atomic_write_text


def messages_dir(group_name: str) -> Path:
    """Return (and ensure exists) the messages/ directory for a group."""
    d = _paths.GROUPS_DIR / group_name / "messages"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _next_seq(entries: list[dict]) -> int:
    return (max(e["seq"] for e in entries) if entries else 0) + 1


def _load_index(index_path: Path) -> list[dict]:
    return (
        json.loads(index_path.read_text(encoding="utf-8"))
        if index_path.exists()
        else []
    )


def append_message_index(group_name: str, entry: dict) -> int:
    """Append one record to index.json. entry must include 'file'. Auto-sets seq and timestamp.

    Process-safe via filelock. Returns the assigned seq.
    """
    index_path = messages_dir(group_name) / "index.json"
    with FileLock(str(index_path) + ".lock"):
        entries = _load_index(index_path)
        seq = _next_seq(entries)
        entry = dict(entry)
        entry["seq"] = seq
        entry["timestamp"] = datetime.now(timezone.utc).isoformat()
        entries.append(entry)
        atomic_write_text(index_path, json.dumps(entries, ensure_ascii=False, indent=2))
    return seq


def _build_message_filename(
    seq: int, role: str, session: str | None, event_type: str
) -> str:
    parts = [f"{seq:04d}", role]
    if session:
        parts.append(session[:8])
    parts.append(event_type)
    return "-".join(parts) + ".md"


def write_and_index_message(
    group_name: str,
    *,
    role: str,
    session: str | None = None,
    event_type: str,
    content: str,
) -> tuple[int, Path]:
    """Atomically write content to messages/<seq>-...-<type>.md and append index.

    Filename convention:
      with session:    <seq:04d>-<role>-<session[:8]>-<type>.md
      without session: <seq:04d>-<role>-<type>.md

    Process-safe via filelock. Returns (seq, file_path).
    """
    msg_dir = messages_dir(group_name)
    index_path = msg_dir / "index.json"
    with FileLock(str(index_path) + ".lock"):
        entries = _load_index(index_path)
        seq = _next_seq(entries)
        filename = _build_message_filename(seq, role, session, event_type)
        out_file = msg_dir / filename
        atomic_write_text(out_file, content)
        index_entry: dict = {
            "seq": seq,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "role": role,
            "type": event_type,
            "file": filename,
        }
        if session:
            index_entry["session"] = session[:8]
        entries.append(index_entry)
        atomic_write_text(index_path, json.dumps(entries, ensure_ascii=False, indent=2))
    return seq, out_file
