from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mycel_sdk.errors import ApiError

from .identity_store import IdentityStore
from .target_resolver import resolve_user_ref


@dataclass(frozen=True)
class AddressedResolution:
    user_id: str | None
    local_id: str | None = None
    workflow_ref: str | None = None


@dataclass(frozen=True)
class _WorkflowCandidate:
    user_id: str
    source: str


def resolve_chat_addressed_ref(
    client: Any,
    *,
    chat_id: str,
    user_ref: str,
    store: IdentityStore,
    owner_user_id: str | None,
) -> AddressedResolution:
    workflow = _load_workflow(client, chat_id)
    workflow_candidate = _workflow_candidate(workflow, user_ref)
    local_user_id, local_id = resolve_user_ref(
        user_ref,
        store,
        owner_user_id=owner_user_id,
    )

    if workflow_candidate is None:
        return AddressedResolution(user_id=local_user_id, local_id=local_id)

    if local_id and local_user_id != workflow_candidate.user_id:
        raise RuntimeError(
            f"ambiguous addressed target {user_ref}: "
            f"workflow {workflow_candidate.source} -> user_id {workflow_candidate.user_id}; "
            f"local_id {local_id} -> user_id {local_user_id}"
        )
    return AddressedResolution(
        user_id=workflow_candidate.user_id,
        local_id=local_id,
        workflow_ref=user_ref,
    )


def _load_workflow(client: Any, chat_id: str) -> dict[str, Any] | None:
    chats = getattr(client, "chats", None)
    get_workflow = getattr(chats, "get_workflow", None)
    if get_workflow is None:
        raise RuntimeError("client.chats.get_workflow is required for chat addressing")
    try:
        workflow = get_workflow(chat_id)
    except ApiError as exc:
        if exc.status_code == 404:
            return None
        raise
    return workflow if isinstance(workflow, dict) else None


def _workflow_candidate(
    workflow: dict[str, Any] | None, user_ref: str
) -> _WorkflowCandidate | None:
    if workflow is None:
        return None
    config = workflow.get("config")
    if not isinstance(config, dict):
        return None
    candidates = [
        candidate
        for candidate in [
            *_participant_candidates(config.get("participants"), user_ref),
            *_alias_candidates(config, user_ref),
        ]
        if candidate.user_id
    ]
    unique = {candidate.user_id: candidate for candidate in candidates}
    if len(unique) > 1:
        details = "; ".join(
            f"{candidate.source} -> user_id {candidate.user_id}"
            for candidate in candidates
        )
        raise RuntimeError(f"ambiguous workflow target {user_ref}: {details}")
    return next(iter(unique.values()), None)


def _participant_candidates(
    participants: Any, user_ref: str
) -> list[_WorkflowCandidate]:
    if not isinstance(participants, list):
        return []
    candidates: list[_WorkflowCandidate] = []
    for participant in participants:
        if not isinstance(participant, dict):
            continue
        user_id = str(participant.get("user_id") or "").strip()
        if not user_id:
            continue
        if str(participant.get("handle") or "").strip() == user_ref:
            candidates.append(_WorkflowCandidate(user_id, "participant.handle"))
        if user_id == user_ref:
            candidates.append(_WorkflowCandidate(user_id, "participant.user_id"))
        aliases = participant.get("aliases")
        if isinstance(aliases, list) and user_ref in {str(item) for item in aliases}:
            candidates.append(_WorkflowCandidate(user_id, "participant.alias"))
    return candidates


def _alias_candidates(
    config: dict[str, Any], user_ref: str
) -> list[_WorkflowCandidate]:
    aliases = config.get("aliases")
    participants = config.get("participants")
    if not isinstance(aliases, dict) or user_ref not in aliases:
        return []
    alias = aliases[user_ref]
    if isinstance(alias, str):
        return _participant_candidates(participants, alias) or [
            _WorkflowCandidate(alias, "alias.raw")
        ]
    if not isinstance(alias, dict):
        return []
    user_id = str(alias.get("user_id") or "").strip()
    if user_id:
        return [_WorkflowCandidate(user_id, "alias.user_id")]
    handle = str(alias.get("handle") or "").strip()
    if handle:
        return _participant_candidates(participants, handle)
    return []
