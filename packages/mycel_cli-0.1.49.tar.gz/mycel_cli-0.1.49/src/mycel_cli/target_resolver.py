from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .identity_store import IdentityStore


@dataclass(frozen=True)
class MessageTarget:
    kind: str
    chat_id: str | None = None
    user_id: str | None = None
    addressed_user_id: str | None = None
    resolved_from_local_id: str | None = None
    addressed_resolved_from_local_id: str | None = None


def parse_message_target(
    target: str, *, allow_chat_mention: bool = True
) -> MessageTarget:
    if target.startswith("@"):
        user_id = target[1:].strip()
        if not user_id:
            raise RuntimeError("message user target is empty")
        return MessageTarget(kind="user", user_id=user_id)
    if target.startswith(":"):
        raise RuntimeError(
            "colon-prefixed chat targets are no longer supported; use chat_id or chat_id@user"
        )

    chat_part = target
    addressed_user_id = None
    if "@" in chat_part:
        if not allow_chat_mention:
            raise RuntimeError("read-message target cannot include an addressed user")
        chat_part, addressed_user_id = chat_part.split("@", 1)
        addressed_user_id = addressed_user_id.strip()
        if not addressed_user_id:
            raise RuntimeError("message addressed target is empty")
    chat_id = chat_part.strip()
    if not chat_id:
        raise RuntimeError("message chat target is empty")
    return MessageTarget(
        kind="chat", chat_id=chat_id, addressed_user_id=addressed_user_id
    )


def resolve_message_target(
    target: MessageTarget, store: IdentityStore, *, owner_user_id: str | None = None
) -> MessageTarget:
    if target.kind == "user":
        user_id, local_id = resolve_user_ref(
            target.user_id, store, owner_user_id=owner_user_id
        )
        return MessageTarget(
            kind="user",
            user_id=user_id,
            resolved_from_local_id=local_id,
        )
    return target


def resolve_user_ref(
    user_ref: str | None,
    store: IdentityStore,
    *,
    owner_user_id: str | None = None,
) -> tuple[str | None, str | None]:
    user_ref = str(user_ref or "").strip()
    if not user_ref:
        return None, None
    if user_ref == "owner":
        return _resolve_owner(owner_user_id), "owner"
    identities = store.identities()
    local_binding = identities.get(user_ref)
    local_user_id = (
        str(local_binding.get("user_id") or "").strip()
        if isinstance(local_binding, dict)
        else ""
    )
    raw_binding = next(
        (
            (local_id, identity)
            for local_id, identity in sorted(identities.items())
            if str(identity.get("user_id") or "").strip() == user_ref
        ),
        None,
    )
    if local_user_id and raw_binding is not None and local_user_id != user_ref:
        raw_local_id, _ = raw_binding
        raise RuntimeError(
            f"ambiguous user target {user_ref}: "
            f"local_id {user_ref} -> user_id {local_user_id}; "
            f"raw user_id {user_ref} belongs to local_id {raw_local_id}"
        )
    if local_user_id:
        return local_user_id, user_ref
    return user_ref, None


def _resolve_owner(owner_user_id: str | None) -> str:
    owner_user_id = str(owner_user_id or "").strip()
    if owner_user_id:
        return owner_user_id
    raise RuntimeError("owner alias requires the current identity owner user id")


def message_mentions(
    target: MessageTarget,
    mentions: list[str],
    *,
    store: IdentityStore | None = None,
    owner_user_id: str | None = None,
) -> list[str]:
    _ = target
    ordered = [mention for mention in mentions if mention]
    if store is not None:
        ordered = [
            str(
                resolve_user_ref(
                    mention,
                    store,
                    owner_user_id=owner_user_id,
                )[0]
                or ""
            )
            for mention in ordered
        ]
    return list(dict.fromkeys(ordered))


def resolve_user_refs(
    user_refs: list[str],
    *,
    store: IdentityStore,
    owner_user_id: str | None = None,
) -> tuple[list[str], list[str]]:
    resolved: list[str] = []
    local_ids: list[str] = []
    for user_ref in user_refs:
        user_id, local_id = resolve_user_ref(
            user_ref,
            store,
            owner_user_id=owner_user_id,
        )
        if user_id:
            resolved.append(user_id)
        if local_id:
            local_ids.append(local_id)
    return list(dict.fromkeys(resolved)), list(dict.fromkeys(local_ids))


def resolved_target(
    target: MessageTarget,
    *,
    chat_id: str,
    mentioned_user_ids: list[str] | None = None,
    addressed_to_user_ids: list[str] | None = None,
    addressed_resolved_from_local_ids: list[str] | None = None,
    addressed_resolved_from_workflow_refs: list[str] | None = None,
) -> dict[str, Any]:
    resolved: dict[str, Any] = {
        "target_type": target.kind,
        "chat_id": chat_id,
    }
    if target.user_id:
        resolved["user_id"] = target.user_id
    if target.resolved_from_local_id:
        resolved["resolved_from_local_id"] = target.resolved_from_local_id
    if mentioned_user_ids is not None:
        resolved["mentioned_user_ids"] = mentioned_user_ids
    if addressed_to_user_ids is not None:
        resolved["addressed_to_user_ids"] = addressed_to_user_ids
    local_ids = list(addressed_resolved_from_local_ids or [])
    if target.addressed_resolved_from_local_id:
        local_ids.insert(0, target.addressed_resolved_from_local_id)
    local_ids = list(dict.fromkeys(local_ids))
    if local_ids:
        resolved["addressed_resolved_from_local_ids"] = local_ids
    workflow_refs = list(addressed_resolved_from_workflow_refs or [])
    if workflow_refs:
        resolved["addressed_resolved_from_workflow_refs"] = list(
            dict.fromkeys(workflow_refs)
        )
    return resolved
