from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

MYCEL_HOOK_OWNER_KEY = "_mycel"


@dataclass(frozen=True)
class HookEntrySpec:
    event: str
    command: str
    purpose: str
    matcher: str | None = None
    hook_options: dict[str, Any] = field(default_factory=dict)


def ensure_hook_entries(
    settings: dict[str, Any],
    *,
    provider: str,
    specs: list[HookEntrySpec],
    owned_purpose_history: set[str | None] | None = None,
    replace_command_collisions: bool = False,
) -> None:
    hooks_root = settings.setdefault("hooks", {})
    if not isinstance(hooks_root, dict):
        raise RuntimeError("hook settings must contain a JSON object at hooks")
    purposes = owned_purpose_history or set()
    for spec in specs:
        entries = hooks_root.setdefault(spec.event, [])
        if not isinstance(entries, list):
            raise RuntimeError(f"hook settings hooks.{spec.event} must be a list")
        hooks_root[spec.event] = [
            entry
            for entry in entries
            if not entry_is_owned_hook(
                entry,
                provider=provider,
                purpose=spec.purpose,
                owned_purpose_history=purposes,
            )
            and not (
                replace_command_collisions and entry_has_command(entry, spec.command)
            )
        ]
        hooks_root[spec.event].append(_hook_entry(provider=provider, spec=spec))


def remove_owned_hook_entries(
    settings: dict[str, Any],
    *,
    provider: str,
    purpose: str,
    owned_purpose_history: set[str | None] | None = None,
) -> bool:
    hooks_root = settings.get("hooks")
    if not isinstance(hooks_root, dict):
        return False
    changed = False
    purposes = owned_purpose_history or set()
    for event in list(hooks_root):
        entries = hooks_root.get(event)
        if not isinstance(entries, list):
            continue
        next_entries = [
            entry
            for entry in entries
            if not entry_is_owned_hook(
                entry,
                provider=provider,
                purpose=purpose,
                owned_purpose_history=purposes,
            )
        ]
        if len(next_entries) == len(entries):
            continue
        changed = True
        if next_entries:
            hooks_root[event] = next_entries
        else:
            del hooks_root[event]
    return changed


def entry_has_command(entry: object, command: str) -> bool:
    if not isinstance(entry, dict):
        return False
    hooks = entry.get("hooks")
    if not isinstance(hooks, list):
        return False
    return any(
        isinstance(hook, dict) and hook.get("command") == command for hook in hooks
    )


def entry_is_owned_hook(
    entry: object,
    *,
    provider: str,
    purpose: str,
    owned_purpose_history: set[str | None] | None = None,
) -> bool:
    if not isinstance(entry, dict):
        return False
    owner = entry.get(MYCEL_HOOK_OWNER_KEY)
    purposes = {purpose, *(owned_purpose_history or set())}
    return (
        isinstance(owner, dict)
        and owner.get("owner") == "mycel"
        and owner.get("provider") == provider
        and owner.get("purpose") in purposes
    )


def _hook_entry(*, provider: str, spec: HookEntrySpec) -> dict[str, Any]:
    hook = {"type": "command", "command": spec.command}
    hook.update(spec.hook_options)
    entry: dict[str, Any] = {
        MYCEL_HOOK_OWNER_KEY: {
            "owner": "mycel",
            "provider": provider,
            "purpose": spec.purpose,
        },
        "hooks": [hook],
    }
    if spec.matcher is not None:
        entry["matcher"] = spec.matcher
    return entry
