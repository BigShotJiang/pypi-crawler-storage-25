"""Shared durable chat send helpers."""

from __future__ import annotations

from typing import Any


def send_addressed_message(
    client: Any,
    *,
    chat_id: str,
    content: str,
    addressed_to_user_ids: list[str],
    enforce_caught_up: bool | None = None,
) -> Any:
    addressed = [user_id for user_id in addressed_to_user_ids if user_id]
    if not addressed:
        raise RuntimeError("addressed message requires at least one user id")
    kwargs: dict[str, Any] = {
        "delivery_scope": "addressed",
        "addressed_to_user_ids": list(dict.fromkeys(addressed)),
    }
    if enforce_caught_up is not None:
        kwargs["enforce_caught_up"] = enforce_caught_up
    return client.messages.send(chat_id, content, **kwargs)
