import logging

from django.conf import settings
from redis import exceptions, from_url

from health_check.backends import BaseHealthCheckBackend
from health_check.exceptions import ServiceUnavailable

_logger = logging.getLogger("django_health_check_full_of_juice")


class RedisHealthCheck(BaseHealthCheckBackend):
    """Health check for Redis."""

    redis_url = getattr(settings, "REDIS_URL", "redis://localhost/1")
    redis_url_options = getattr(settings, "HEALTHCHECK_REDIS_URL_OPTIONS", {})

    def check_status(self):
        """Check Redis service by pinging the redis instance with a redis connection."""
        _logger.debug("Got %s as the redis_url. Connecting to redis...", self.redis_url)

        _logger.debug("Attempting to connect to redis...")
        try:
            # conn is used as a context to release opened resources later
            with from_url(self.redis_url, **self.redis_url_options) as conn:
                conn.ping()  # exceptions may be raised upon ping
        except ConnectionRefusedError as e:
            self.add_error(
                ServiceUnavailable("Unable to connect to Redis: Connection was refused."),
                e,
            )
        except exceptions.TimeoutError as e:
            self.add_error(ServiceUnavailable("Unable to connect to Redis: Timeout."), e)
        except exceptions.ConnectionError as e:
            self.add_error(ServiceUnavailable("Unable to connect to Redis: Connection Error"), e)
        except Exception as e:
            self.add_error(ServiceUnavailable("Unknown error"), e)
        else:
            _logger.debug("Connection established. Redis is healthy.")
