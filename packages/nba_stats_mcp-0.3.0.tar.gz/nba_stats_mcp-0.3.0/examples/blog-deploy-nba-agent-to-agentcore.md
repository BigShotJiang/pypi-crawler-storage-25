# Deploy an NBA Stats Agent to AWS in 5 Minutes with Bedrock AgentCore

You've built a local AI agent that can pull live NBA scores, look up player stats, and break down box scores. It works great on your laptop. Now what?

In this post, I'll walk through taking a Strands-based NBA analytics agent — backed by 26 MCP tools — and deploying it to production on AWS using the Bedrock AgentCore CLI. No Dockerfiles. No infrastructure. Just `configure`, `deploy`, `invoke`.

## What We're Working With

The [NBA MCP Server](https://github.com/dlight/nba_mcp_server) is a Model Context Protocol server that exposes 26 tools for fetching real-time NBA data: live scoreboards, player season stats, career stats, game logs, standings, league leaders, shot charts, play-by-play data, and more. It makes direct HTTP calls to official NBA endpoints — no third-party wrappers.

On the agent side, we use [Strands Agents](https://github.com/strands-agents/strands-agents-python) to wire a Claude model to those tools. The agent knows how to look up player IDs before fetching stats, format results into clean tables, and chain multiple tool calls together to answer complex basketball questions.

The goal: take this agent from `python my_agent.py` to a deployed, invokable AWS endpoint.

## The Entrypoint: 40 Lines

Bedrock AgentCore expects one thing from your code: a Python file with a `BedrockAgentCoreApp` and an `@app.entrypoint`-decorated function. That function receives a JSON payload and returns a result. That's the entire contract.

Here's the full agent:

```python
import sys

from bedrock_agentcore.runtime import BedrockAgentCoreApp
from mcp import StdioServerParameters, stdio_client
from strands import Agent
from strands.tools.mcp import MCPClient

app = BedrockAgentCoreApp()

SYSTEM_PROMPT = """You are an expert NBA analytics agent with deep basketball knowledge.

WORKFLOW:
- Always look up player IDs first using search_players before calling other player tools
- Use get_all_teams to find team IDs when needed
- Never guess player IDs or team IDs — always look them up

FORMATTING:
- Present stats in clear, organized tables when possible
- Highlight key insights and notable performances
- Compare numbers in context (league averages, career trends)
"""


@app.entrypoint
def invoke(payload, context):
    """Handle agent invocations from AgentCore Runtime."""
    mcp_client = MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command=sys.executable,
                args=["-u", "-m", "nba_mcp_server"],
            )
        )
    )

    with mcp_client:
        tools = mcp_client.list_tools_sync()
        agent = Agent(
            model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
            system_prompt=SYSTEM_PROMPT,
            tools=tools,
        )

        prompt = payload.get("prompt", "What NBA games are on today?")
        result = agent(prompt)
        return {"result": result.message}


if __name__ == "__main__":
    app.run()
```

Let's break down what's happening:

1. **`BedrockAgentCoreApp()`** turns your script into an HTTP service that AgentCore Runtime knows how to manage. When deployed, it listens on port 8080 and handles the request lifecycle.

2. **`@app.entrypoint`** marks the function that receives invocation payloads. The `payload` is whatever JSON you send via `agentcore invoke`. The `context` object carries runtime metadata like `session_id`.

3. **The MCP client** launches the NBA MCP server as a subprocess using stdio transport. This is the same pattern you'd use locally — the server runs alongside the agent inside the same container.

4. **`mcp_client.list_tools_sync()`** discovers all 26 NBA tools dynamically. No hardcoded tool definitions. If the MCP server adds new tools tomorrow, the agent picks them up automatically.

5. **The Strands `Agent`** wires Claude to those tools with a system prompt that teaches it the NBA data workflow — always search for player IDs first, never guess, format results clearly.

The `requirements.txt` is three lines:

```
bedrock-agentcore
strands-agents
nba-stats-mcp
```

## Deploy with the CLI

Install the toolkit:

```bash
pip install bedrock-agentcore-starter-toolkit strands-agents bedrock-agentcore nba-stats-mcp
```

Configure. The `--disable-memory` flag skips memory provisioning (we don't need cross-session persistence for this agent) and `--non-interactive` accepts defaults without prompting:

```bash
agentcore configure -e agentcore_nba_agent.py --disable-memory --non-interactive
```

This creates a `.bedrock_agentcore.yaml` file with your agent's configuration. It auto-creates an IAM execution role with the right permissions.

Deploy:

```bash
agentcore deploy
```

Under the hood, AgentCore packages your Python code into a zip, uploads it to S3, and stands up a runtime endpoint. No Docker build, no ECR push, no ECS task definitions. The default `direct_code_deploy` mode handles everything.

Deployment takes a couple of minutes. You can watch the status:

```bash
agentcore status
```

## Invoke It

Once the status shows the agent is active:

```bash
agentcore invoke '{"prompt": "What NBA games are on today?"}'
```

The agent spins up, launches the NBA MCP server subprocess, discovers the tools, calls `get_todays_scoreboard`, and returns a formatted rundown of today's games.

Try something more complex:

```bash
agentcore invoke '{"prompt": "Look up LeBron James and show me his 2024-25 season stats"}'
```

The agent chains two tool calls: `search_players` to find LeBron's player ID, then `get_player_season_stats` to pull his numbers. It formats the result into a clean table with points, rebounds, assists, and shooting percentages.

Or go deeper:

```bash
agentcore invoke '{"prompt": "Compare the top 5 scorers in the NBA this season"}'
```

## Test Locally First

You don't have to deploy to test. The `app.run()` call at the bottom starts a local server:

```bash
python agentcore_nba_agent.py
```

Then hit it with curl from another terminal:

```bash
curl -X POST http://localhost:8080/invocations \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Who leads the NBA in assists?"}'
```

Same code, same behavior, no AWS resources consumed.

## What This Pattern Unlocks

The interesting part isn't the deployment mechanics — it's the pattern. The NBA MCP server is a standalone process that speaks MCP over stdio. The Strands agent discovers its tools at runtime. The AgentCore entrypoint is just a thin wrapper.

This means you can:

- **Swap the MCP server** for any other MCP-compatible tool server without changing the agent code
- **Add more MCP servers** by creating additional `MCPClient` instances and merging the tool lists
- **Add memory** later with `agentcore configure` (drop the `--disable-memory` flag) to give the agent cross-session recall
- **Add auth** with AgentCore Identity if you want to expose the agent to external callers via OAuth
- **Invoke programmatically** using the AWS SDK `invoke_agent_runtime` API from any application

## Clean Up

When you're done:

```bash
agentcore destroy
```

This tears down the runtime endpoint, IAM roles, and S3 artifacts.

## The Full Picture

What we covered:

| Step | Command | What Happens |
|------|---------|-------------|
| Install | `pip install bedrock-agentcore-starter-toolkit ...` | Get the CLI and dependencies |
| Configure | `agentcore configure -e agentcore_nba_agent.py --disable-memory --non-interactive` | Generate deployment config, create IAM role |
| Deploy | `agentcore deploy` | Package code, upload to S3, create runtime endpoint |
| Test | `agentcore invoke '{"prompt": "..."}'` | Send prompts, get NBA analytics back |
| Monitor | `agentcore status` | Check agent health and resource state |
| Teardown | `agentcore destroy` | Remove all AWS resources |

40 lines of Python. 3 dependencies. 4 CLI commands. A production NBA analytics agent running on AWS.

The code is available in the [examples directory](https://github.com/dlight/nba_mcp_server/tree/main/examples) of the NBA MCP Server repository.
