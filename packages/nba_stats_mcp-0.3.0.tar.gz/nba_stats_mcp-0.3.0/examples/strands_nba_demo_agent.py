"""
NBA Analytics Agent - Strands + MCP Demo

A demo-ready NBA analytics agent built with Strands Agents and the NBA MCP Server.
Features custom hooks for tool invocation logging, multi-model support,
conversation management, and curated demo prompts for presentations.

Prereqs:
    pip install strands-agents strands-agents-tools python-dotenv

Run:
    # Interactive mode (REPL)
    python examples/strands_nba_demo_agent.py

    # Demo mode (runs curated prompts for presentations)
    python examples/strands_nba_demo_agent.py --demo

    # One-shot mode
    python examples/strands_nba_demo_agent.py --once "Who leads the NBA in scoring?"
"""

import argparse
import json
import os
import sys
from pprint import pprint

from dotenv import load_dotenv

load_dotenv()

from mcp import StdioServerParameters, stdio_client  # noqa: E402
from strands import Agent  # noqa: E402
from strands.agent.conversation_manager import SlidingWindowConversationManager  # noqa: E402
from strands.handlers import PrintingCallbackHandler  # noqa: E402
from strands.hooks import HookProvider, HookRegistry  # noqa: E402
from strands.experimental.hooks import BeforeToolInvocationEvent  # noqa: E402
from strands.tools.mcp import MCPClient  # noqa: E402
from strands_tools import current_time  # noqa: E402


# =============================================================================
# ANSI COLORS
# =============================================================================

BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"
BG_BLUE = "\033[44m"
BG_MAGENTA = "\033[45m"
BG_CYAN = "\033[46m"


# =============================================================================
# HOOKS - Clean tool invocation logging for demos
# =============================================================================


class LoggingHook(HookProvider):
    """Hook that logs tool invocations before execution.

    Displays a clean, formatted view of each tool call with the tool name
    and input parameters - perfect for demos and presentations.
    """

    def __init__(self, verbose: bool = True):
        self.calls = 0
        self.verbose = verbose

    def register_hooks(self, registry: HookRegistry) -> None:
        registry.add_callback(BeforeToolInvocationEvent, self.log_start)

    def log_start(self, event: BeforeToolInvocationEvent) -> None:
        self.calls += 1
        tool_name = event.tool_use["name"]

        print(f"\n{CYAN}{'─' * 60}{RESET}")
        print(f"  {YELLOW}{BOLD}▶ TOOL CALL #{self.calls}{RESET}  {CYAN}{BOLD}{tool_name}{RESET}")
        print(f"{CYAN}{'─' * 60}{RESET}")

        if self.verbose:
            tool_input = event.tool_use.get("input", {})
            if tool_input:
                formatted = json.dumps(tool_input, indent=2)
                for line in formatted.split("\n"):
                    print(f"  {DIM}{line}{RESET}")
            else:
                print(f"  {DIM}(no parameters){RESET}")

        print(f"{CYAN}{'─' * 60}{RESET}")


# =============================================================================
# AGENT CONFIGURATION
# =============================================================================

AGENT_NAME = "NBA Analytics Agent"

SYSTEM_PROMPT = """You are an expert NBA analytics agent with deep basketball knowledge.

WORKFLOW:
- Always look up player IDs first using search_players before calling other player tools
- Use get_all_teams to find team IDs when needed
- Never guess player IDs or team IDs - always look them up
- Use the current_time tool to get today's date for accurate responses

FORMATTING:
- Present stats in clear, organized tables when possible
- Highlight key insights and notable performances
- Compare numbers in context (league averages, career trends)

AVAILABLE TOOL CATEGORIES:
- Live Games: Today's scoreboard, game details, box scores
- Player Stats: Season stats, career stats, game logs, advanced metrics
- Team Data: Rosters, team advanced stats, schedules
- League: Standings, leaders, awards, hustle stats
- Shooting: Shot charts, shooting splits by zone
- Play-by-Play: Game actions, player rotations
""".strip()


# =============================================================================
# MODEL SELECTION
# =============================================================================


def get_model():
    """Configure the model based on available API keys."""
    # Default: Anthropic
    if os.getenv("ANTHROPIC_API_KEY"):
        from strands.models.anthropic import AnthropicModel

        return AnthropicModel(
            client_args={"api_key": os.getenv("ANTHROPIC_API_KEY")},
            model_id=os.getenv("MODEL_ID", "claude-sonnet-4-5-20250929"),
            max_tokens=4000,
        )

    # Fallback: Bedrock
    if os.getenv("AWS_REGION") or os.getenv("AWS_ACCESS_KEY_ID"):
        from strands.models.bedrock import BedrockModel

        return BedrockModel(
            model_id=os.getenv("MODEL_ID", "us.anthropic.claude-sonnet-4-5-20250929-v1:0"),
            region_name=os.getenv("AWS_REGION", "us-east-1"),
            max_tokens=4000,
        )

    # No explicit model - let Strands use its default
    return None


# =============================================================================
# DEMO PROMPTS - Curated for presentations
# =============================================================================

DEMO_PROMPTS = [
    "What NBA games are on today? Give me a quick rundown.",
    "Look up LeBron James and show me his season stats for 2024-25.",
    "Who are the top 5 scorers in the NBA this season?",
    "Show me the current NBA standings for both conferences.",
    "Get the Lakers schedule for the next few upcoming games.",
]


# =============================================================================
# MAIN
# =============================================================================


def print_banner():
    """Print a colorful agent banner."""
    print()
    print(f"{BLUE}{BOLD}{'═' * 60}{RESET}")
    print(f"{BLUE}{BOLD}  🏀  {AGENT_NAME}{RESET}")
    print(f"{BLUE}{BOLD}{'═' * 60}{RESET}")
    print(f"  {DIM}Powered by Strands Agents + NBA MCP Server{RESET}")
    print(f"{BLUE}{BOLD}{'═' * 60}{RESET}")
    print()


def main() -> int:
    parser = argparse.ArgumentParser(description="NBA Analytics Agent - Strands + MCP Demo")
    parser.add_argument("--demo", action="store_true", help="Run curated demo prompts.")
    parser.add_argument("--once", type=str, default=None, help="Run a single prompt and exit.")
    parser.add_argument("--verbose", action="store_true", default=True, help="Show tool parameters.")
    parser.add_argument("--quiet", action="store_true", help="Hide tool parameters in hook output.")
    args, unknown = parser.parse_known_args()

    # Support bare prompt without --once flag
    fallback_prompt = " ".join(unknown).strip()
    once_prompt = args.once or (fallback_prompt if fallback_prompt else None)
    verbose = not args.quiet

    print_banner()

    # Configure model
    model = get_model()

    # Launch the NBA MCP server as a subprocess
    mcp_client = MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command=sys.executable,
                args=["-u", "-m", "nba_mcp_server"],
            )
        )
    )

    with mcp_client:
        # Get tools from the MCP server
        tools_resp = mcp_client.list_tools_sync()
        tools = getattr(tools_resp, "tools", tools_resp)

        # Build agent kwargs
        agent_kwargs = {
            "tools": tools + [current_time],
            "system_prompt": SYSTEM_PROMPT,
            "conversation_manager": SlidingWindowConversationManager(
                window_size=20,
                should_truncate_results=True,
            ),
            "callback_handler": PrintingCallbackHandler(verbose_tool_use=False),
            "hooks": [LoggingHook(verbose=verbose)],
            "name": AGENT_NAME,
        }
        if model:
            agent_kwargs["model"] = model

        agent = Agent(**agent_kwargs)

        model_name = agent.model.config.get("model_id", "default")
        print(f"  {GREEN}Model:{RESET}  {BOLD}{model_name}{RESET}")
        print(f"  {GREEN}Tools:{RESET}  {BOLD}{len(tools)}{RESET} NBA tools + current_time")
        print(f"{DIM}{'─' * 60}{RESET}")

        # --- Demo mode ---
        if args.demo:
            print(f"  {MAGENTA}{BOLD}MODE: Demo (curated prompts){RESET}\n")
            for i, prompt in enumerate(DEMO_PROMPTS, 1):
                print(f"\n{MAGENTA}{BOLD}{'#' * 60}{RESET}")
                print(f"  {MAGENTA}{BOLD}DEMO {i}/{len(DEMO_PROMPTS)}{RESET}")
                print(f"{MAGENTA}{BOLD}{'#' * 60}{RESET}")
                print(f"\n{GREEN}{BOLD}> {prompt}{RESET}\n")
                try:
                    agent(prompt)
                except Exception as e:
                    print(f"\n{RED}[error] {type(e).__name__}: {e}{RESET}\n")
            return 0

        # --- One-shot mode ---
        if once_prompt:
            print(f"  {MAGENTA}{BOLD}MODE: One-shot{RESET}\n")
            print(f"{GREEN}{BOLD}> {once_prompt}{RESET}\n")
            agent(once_prompt)
            return 0

        # --- Interactive REPL ---
        print(f"  {MAGENTA}{BOLD}MODE: Interactive{RESET}")
        print(f"  {DIM}Commands: tools | model | metrics | help | exit{RESET}")
        print(f"{DIM}{'─' * 60}{RESET}\n")

        while True:
            try:
                prompt = input(f"{GREEN}{BOLD}> {RESET}").strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n{DIM}Goodbye!{RESET}")
                break

            if not prompt:
                continue

            if prompt.lower() in {"quit", "exit"}:
                print(f"{DIM}Goodbye!{RESET}")
                break

            if prompt.lower() == "tools":
                print(f"\n{CYAN}{BOLD}Available tools ({len(agent.tool_names)}):{RESET}")
                for name in sorted(agent.tool_names):
                    print(f"  {CYAN}•{RESET} {name}")
                print()
                continue

            if prompt.lower() == "clear":
                os.system("cls" if os.name == "nt" else "clear")
                continue

            if prompt.lower() == "model":
                print(f"\n{CYAN}{BOLD}Model:{RESET} {agent.model.config}\n")
                continue

            if prompt.lower() == "metrics":
                pprint(agent.event_loop_metrics)
                print()
                continue

            if prompt.lower() == "help":
                print(f"\n{CYAN}{BOLD}Commands:{RESET}")
                print(f"  {YELLOW}tools{RESET}   {DIM}─{RESET} List available NBA tools")
                print(f"  {YELLOW}model{RESET}   {DIM}─{RESET} Show current model config")
                print(f"  {YELLOW}metrics{RESET} {DIM}─{RESET} Show agent event loop metrics")
                print(f"  {YELLOW}exit{RESET}    {DIM}─{RESET} Exit the agent")
                print()
                continue

            try:
                agent(prompt)
            except Exception as e:
                print(f"\n{RED}{BOLD}[error]{RESET} {RED}{type(e).__name__}: {e}{RESET}\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
