from strands import Agent
from strands.models.bedrock import BedrockModel
from strands_tools import editor, shell

MODEL = BedrockModel(model_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0")

SYSTEM_PROMPT = """
You are a helpful assistant that can write code and run shell commands.
If you don't have the information you need, 
you can use the tools provided to you to get the information you need.

You have the following tools available to you:
- editor: A tool to edit code
- shell: A tool to run shell commands

For example, if you need to get the date and time write python code to get the date and time.
If you need to get information on the web use the shell or write code to scrape the internet to get the information you need.

When done always explain what you did and why you did it.
"""

# Create an agent
agent = Agent(model=MODEL, tools=[editor, shell], system_prompt=SYSTEM_PROMPT)

# Ask the agent a question
response = agent("What is the weather today in San Jose, CA?")
