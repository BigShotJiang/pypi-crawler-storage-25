#!/usr/bin/env python3
import urllib.request
import json

def get_weather():
    try:
        # Using a free weather service
        url = "https://wttr.in/San_Jose_CA?format=j1"
        with urllib.request.urlopen(url) as response:
            data = json.loads(response.read())
        
        current = data['current_condition'][0]
        location = data['nearest_area'][0]
        
        print(f"Weather for {location['areaName'][0]['value']}, {location['region'][0]['value']}")
        print(f"Temperature: {current['temp_F']}°F ({current['temp_C']}°C)")
        print(f"Condition: {current['weatherDesc'][0]['value']}")
        print(f"Feels like: {current['FeelsLikeF']}°F ({current['FeelsLikeC']}°C)")
        print(f"Humidity: {current['humidity']}%")
        print(f"Wind: {current['windspeedMiles']} mph {current['winddir16Point']}")
        print(f"Visibility: {current['visibility']} miles")
        
    except Exception as e:
        print(f"Error getting weather: {e}")
        # Fallback to simpler format
        try:
            url = "https://wttr.in/San_Jose_CA?format=3"
            with urllib.request.urlopen(url) as response:
                result = response.read().decode('utf-8').strip()
            print(f"Weather: {result}")
        except:
            print("Unable to fetch weather data. Please check your internet connection.")

if __name__ == "__main__":
    get_weather()