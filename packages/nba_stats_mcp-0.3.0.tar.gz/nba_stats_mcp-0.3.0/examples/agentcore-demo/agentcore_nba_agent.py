"""
NBA Agent — Deploy to Amazon Bedrock AgentCore

Wraps the Strands + NBA MCP Server agent for AgentCore Runtime deployment.
No gateway, no memory — just the NBA tools served over stdio MCP.

Install:
    pip install bedrock-agentcore strands-agents bedrock-agentcore-starter-toolkit nba-stats-mcp

Deploy:
    agentcore configure -e agentcore_nba_agent.py --disable-memory --non-interactive
    agentcore deploy
    agentcore invoke '{"prompt": "What NBA games are on today?"}'

Cleanup:
    agentcore destroy
"""

SYSTEM_PROMPT = """You are an expert NBA analytics agent with deep basketball knowledge.

WORKFLOW:
- Always look up player IDs first using search_players before calling other player tools
- Use get_all_teams to find team IDs when needed
- Never guess player IDs or team IDs — always look them up

FORMATTING:
- Present stats in clear, organized tables when possible
- Highlight key insights and notable performances
- Compare numbers in context (league averages, career trends)
"""

import sys

from bedrock_agentcore.runtime import BedrockAgentCoreApp
from mcp import StdioServerParameters, stdio_client
from strands import Agent
from strands.tools.mcp import MCPClient

app = BedrockAgentCoreApp()

@app.entrypoint
def invoke(payload, context):
    """Handle agent invocations from AgentCore Runtime."""
    mcp_client = MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command=sys.executable,
                args=["-u", "-m", "nba_mcp_server"],
            )
        )
    )

    with mcp_client:
        tools = mcp_client.list_tools_sync()
        agent = Agent(
            model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
            system_prompt=SYSTEM_PROMPT,
            tools=tools,
        )

        prompt = payload.get("prompt", "What NBA games are on today?")
        result = agent(prompt)
        return {"result": result.message}




if __name__ == "__main__":
    app.run()
