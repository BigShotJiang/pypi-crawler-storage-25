"""Reference resolution helpers for Trello objects."""

from __future__ import annotations

from typing import Any

from .models import error


def resolve_one(
    candidates: list[dict[str, Any]], ref: str, kind: str
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve one object by ID, exact name, or unique partial name."""
    return _resolve(candidates, ref, kind)


def resolve_board(
    ref: str, boards: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a board by ID, URL, exact name, or unique partial name."""
    return _resolve(boards, ref, "board", allow_url=True)


def resolve_list(
    ref: str,
    lists: list[dict[str, Any]],
    board_map: dict[str, Any] | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a list by ID, exact name, board-map alias, or partial name."""
    return _resolve(lists, ref, "list", board_map=board_map, map_collection="lists")


def resolve_label(
    ref: str,
    labels: list[dict[str, Any]],
    board_map: dict[str, Any] | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a label by ID, exact name, board-map alias, or partial name."""
    return _resolve(labels, ref, "label", board_map=board_map, map_collection="labels")


def resolve_card(
    ref: str, cards: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a card by ID, URL, exact name, or unique partial name."""
    return _resolve(cards, ref, "card", allow_url=True)


def _resolve(
    candidates: list[dict[str, Any]],
    ref: str,
    kind: str,
    allow_url: bool = False,
    board_map: dict[str, Any] | None = None,
    map_collection: str | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    ref_text = str(ref).strip()
    if not ref_text:
        return None, error("not_found", f"No {kind} matched empty reference", ref)

    id_matches = [item for item in candidates if item.get("id") == ref_text]
    if id_matches:
        return _single_or_ambiguous(id_matches, ref_text, kind)

    if allow_url:
        url_matches = [
            item
            for item in candidates
            if ref_text in {item.get("url"), item.get("shortUrl"), item.get("short_url")}
        ]
        if url_matches:
            return _single_or_ambiguous(url_matches, ref_text, kind)

    ref_lower = ref_text.lower()
    exact_matches = [
        item for item in candidates if str(item.get("name", "")).lower() == ref_lower
    ]
    if exact_matches:
        return _single_or_ambiguous(exact_matches, ref_text, kind)

    if board_map and map_collection:
        alias_matches = _alias_matches(ref_lower, candidates, board_map, map_collection)
        if alias_matches:
            return _single_or_ambiguous(alias_matches, ref_text, kind)

    partial_matches = [
        item
        for item in candidates
        if ref_lower in str(item.get("name", "")).lower()
    ]
    if partial_matches:
        return _single_or_ambiguous(partial_matches, ref_text, kind)

    return None, error("not_found", f"No {kind} matched '{ref_text}'", ref_text)


def _alias_matches(
    ref_lower: str,
    candidates: list[dict[str, Any]],
    board_map: dict[str, Any],
    collection_name: str,
) -> list[dict[str, Any]]:
    candidate_by_id = {item.get("id"): item for item in candidates}
    matches = []
    for entry in board_map.get(collection_name, []):
        aliases = [str(alias).lower() for alias in entry.get("aliases", [])]
        if ref_lower in aliases and entry.get("id") in candidate_by_id:
            matches.append(candidate_by_id[entry["id"]])
    return matches


def _single_or_ambiguous(
    matches: list[dict[str, Any]], ref: str, kind: str
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if len(matches) == 1:
        return matches[0], None
    return None, error(
        "ambiguous_ref",
        f"Multiple {kind}s matched '{ref}'",
        input_ref=ref,
        candidates=[_candidate(item) for item in matches],
    )


def _candidate(item: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in {
            "id": item.get("id"),
            "name": item.get("name"),
            "url": item.get("url") or item.get("shortUrl"),
        }.items()
        if value is not None
    }
