"""Shared response models and compact Trello object helpers."""

from __future__ import annotations

from typing import Any


ERROR_CODES = {
    "not_found",
    "ambiguous_ref",
    "invalid_input",
    "trello_bad_request",
    "trello_auth_error",
    "trello_rate_limited",
    "trello_unavailable",
    "partial_failure",
    "unsafe_operation",
    "board_map_stale",
    "board_map_corrupt",
}

WARNING_CODES = {
    "board_map_name_changed",
    "board_map_stale_object",
    "result_truncated",
    "using_inferred_unsaved_map",
    "description_omitted",
    "board_map_corrupt",
}


def board_summary(board: dict[str, Any] | None) -> dict[str, Any] | None:
    """Return the compact board identity used by response envelopes."""
    if board is None:
        return None
    return {
        "id": board.get("id"),
        "name": board.get("name"),
        "url": board.get("url") or board.get("shortUrl"),
    }


def error(
    code: str,
    message: str,
    input_ref: str | None = None,
    retryable: bool = False,
    candidates: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build a stable machine-readable error object."""
    if code not in ERROR_CODES:
        raise ValueError(f"Unknown error code: {code}")
    return {
        "code": code,
        "message": message,
        "input_ref": input_ref,
        "retryable": retryable,
        "candidates": candidates or [],
    }


def warning(
    code: str,
    message: str,
    input_ref: str | None = None,
    retryable: bool = False,
) -> dict[str, Any]:
    """Build a stable machine-readable warning object."""
    if code not in WARNING_CODES:
        raise ValueError(f"Unknown warning code: {code}")
    return {
        "code": code,
        "message": message,
        "input_ref": input_ref,
        "retryable": retryable,
    }


def envelope(
    tool: str,
    board: dict[str, Any] | None = None,
    result: dict[str, Any] | None = None,
    warnings: list[dict[str, Any]] | None = None,
    errors: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build the canonical dict-shaped tool response envelope."""
    response_errors = errors or []
    return {
        "ok": not response_errors,
        "tool": tool,
        "board": board_summary(board),
        "result": result or {},
        "warnings": warnings or [],
        "errors": response_errors,
    }


def card_receipt(
    card: dict[str, Any],
    list_name: str | None = None,
    labels: list[dict[str, Any]] | None = None,
    status: str = "changed",
) -> dict[str, Any]:
    """Return the shared compact mutation receipt for a card."""
    return {
        "id": card.get("id"),
        "name": card.get("name"),
        "list_id": card.get("idList") or card.get("list_id"),
        "list_name": list_name or card.get("list_name"),
        "labels": [simplify_label(label) for label in (labels if labels is not None else card.get("labels", []))],
        "url": card.get("url") or card.get("shortUrl"),
        "status": status,
    }


def simplify_label(label: dict[str, Any]) -> dict[str, Any]:
    """Simplify a label object."""
    return {
        "id": label.get("id"),
        "name": label.get("name"),
        "color": label.get("color"),
    }


def simplify_list(list_obj: dict[str, Any]) -> dict[str, Any]:
    """Simplify a list object."""
    return {
        "id": list_obj.get("id"),
        "name": list_obj.get("name"),
        "closed": list_obj.get("closed"),
        "pos": list_obj.get("pos"),
        "board_id": list_obj.get("idBoard") or list_obj.get("board_id"),
    }


def simplify_board(board: dict[str, Any]) -> dict[str, Any]:
    """Simplify a board object."""
    return {
        "id": board.get("id"),
        "name": board.get("name"),
        "url": board.get("url") or board.get("shortUrl"),
    }


def simplify_card(
    card: dict[str, Any],
    include_description: bool = False,
    list_name: str | None = None,
) -> dict[str, Any]:
    """Simplify a card object for compact agent responses."""
    simplified = {
        "id": card.get("id"),
        "name": card.get("name"),
        "board_id": card.get("idBoard") or card.get("board_id"),
        "list_id": card.get("idList") or card.get("list_id"),
        "list_name": list_name or card.get("list_name"),
        "label_ids": card.get("idLabels", []),
        "member_ids": card.get("idMembers", []),
        "due": card.get("due"),
        "start": card.get("start"),
        "due_complete": card.get("dueComplete"),
        "closed": card.get("closed"),
        "date_last_activity": card.get("dateLastActivity"),
        "url": card.get("url") or card.get("shortUrl"),
    }
    if card.get("labels"):
        simplified["labels"] = [simplify_label(label) for label in card.get("labels", [])]
    else:
        simplified["labels"] = []
    if include_description:
        simplified["desc"] = card.get("desc", "")
    return {key: value for key, value in simplified.items() if value is not None}


def simplify_action(action: dict[str, Any]) -> dict[str, Any]:
    """Simplify an action object without member/avatar payloads."""
    compact = {
        "id": action.get("id"),
        "type": action.get("type"),
        "date": action.get("date"),
        "data": _compact_action_data(action.get("data", {})),
    }
    return {key: value for key, value in compact.items() if value is not None}


def _compact_action_data(data: dict[str, Any]) -> dict[str, Any]:
    compact: dict[str, Any] = {}
    for key, value in data.items():
        if key in {"member", "memberCreator"}:
            continue
        if isinstance(value, dict):
            compact[key] = {
                nested_key: nested_value
                for nested_key, nested_value in value.items()
                if nested_key not in {"avatarUrl", "initials", "username", "fullName"}
            }
        else:
            compact[key] = value
    return compact
