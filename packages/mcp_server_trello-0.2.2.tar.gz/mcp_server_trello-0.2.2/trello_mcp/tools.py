"""Primary Trello MCP tool business functions."""

from __future__ import annotations

import re
from typing import Any

from fastmcp import FastMCP

from .board_maps import refresh_board_map
from .domain_models import simplify_checklist
from .extended_tools import (
    assign_members,
    batch_get_compact,
    manage_attachments,
    manage_boards,
    manage_cards,
    manage_checklists,
    manage_comments,
    manage_custom_fields,
    manage_labels,
    manage_lists,
)
from .models import (
    card_receipt,
    envelope,
    error,
    simplify_action,
    simplify_board,
    simplify_card,
    simplify_label,
    simplify_list,
)
from .raw_tools import trello_delete, trello_get, trello_post, trello_put
from .resolvers import resolve_board, resolve_card, resolve_label, resolve_list
from .trello_client import TrelloAPIError, TrelloClient


mcp = FastMCP("Trello")


def open_board(name_or_id: str, client: TrelloClient | None = None) -> dict[str, Any]:
    """Open a board, refresh its board map, and return compact metadata."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(name_or_id, trello)
    except TrelloAPIError as exc:
        return _error_envelope("open_board", exc, name_or_id)
    if opened.get("error"):
        return envelope("open_board", errors=[opened["error"]])
    return envelope(
        "open_board",
        board=opened["board"],
        result={
            "board": simplify_board(opened["board"]),
            "board_map_status": opened["board_map_status"],
            "board_map": opened["board_map"],
            "lists": [simplify_list(item) for item in opened["lists"]],
            "labels": [simplify_label(item) for item in opened["labels"]],
        },
        warnings=opened["warnings"],
    )


def get_board_snapshot(
    board_id_or_name: str,
    include: str = "summary",
    include_descriptions: bool = False,
    activity_limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Return compact board state."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("get_board_snapshot", errors=[opened["error"]])
        board = opened["board"]
        lists = opened["lists"]
        labels = opened["labels"]
        result: dict[str, Any] = {
            "board_map_status": opened["board_map_status"],
            "lists": [simplify_list(item) for item in lists],
            "labels": [simplify_label(item) for item in labels],
        }
        include_set = _include_set(include)
        if include_set & {"cards", "all"}:
            cards = trello.request(f"/boards/{board['id']}/cards", params={"filter": "open"})
            list_names = {item.get("id"): item.get("name") for item in lists}
            result["cards"] = [
                simplify_card(
                    card,
                    include_description=include_descriptions,
                    list_name=list_names.get(card.get("idList")),
                )
                for card in cards
            ]
        if include_set & {"activity", "all"}:
            actions = trello.request(
                f"/boards/{board['id']}/actions",
                params={"limit": activity_limit},
            )
            result["activity"] = [simplify_action(action) for action in actions]
        return envelope(
            "get_board_snapshot",
            board=board,
            result=result,
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("get_board_snapshot", exc, board_id_or_name)


def find_cards(
    board_id_or_name: str,
    query: str,
    filters: dict[str, Any] | None = None,
    limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Search board cards with safe Trello params and local fallback."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("find_cards", errors=[opened["error"]])
        board = opened["board"]
        params: dict[str, Any] = {
            "query": query,
            "modelTypes": "cards",
            "idBoards": board["id"],
        }
        if limit > 0:
            params["cards_limit"] = limit
        try:
            search = trello.request("/search", params=params)
            cards = search.get("cards", []) if isinstance(search, dict) else []
        except TrelloAPIError:
            cards = _local_card_search(trello, board["id"], query, filters)
        list_names = {item.get("id"): item.get("name") for item in opened["lists"]}
        if filters:
            cards = _filter_cards(cards, filters, opened)
        if limit > 0:
            cards = cards[:limit]
        return envelope(
            "find_cards",
            board=board,
            result={
                "cards": [
                    simplify_card(card, list_name=list_names.get(card.get("idList")))
                    for card in cards
                ],
                "truncated": limit > 0 and len(cards) == limit,
            },
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("find_cards", exc, board_id_or_name)


def get_card_context(
    board_id_or_name: str,
    card: str,
    include: list[str] | None = None,
    activity_limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Return compact card context."""
    trello = client or TrelloClient()
    include = include or []
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("get_card_context", errors=[opened["error"]])
        board = opened["board"]
        cards = trello.request(f"/boards/{board['id']}/cards", params={"filter": "open"})
        found, err = resolve_card(card, cards)
        if err:
            return envelope("get_card_context", board=board, errors=[err])
        list_names = {item.get("id"): item.get("name") for item in opened["lists"]}
        result = {
            "card": simplify_card(
                found,
                include_description="description" in include,
                list_name=list_names.get(found.get("idList")),
            )
        }
        if "activity" in include:
            actions = trello.request(
                f"/cards/{found['id']}/actions",
                params={"limit": activity_limit},
            )
            result["activity"] = [simplify_action(action) for action in actions]
        if "comments" in include:
            comments = trello.request(
                f"/cards/{found['id']}/actions",
                params={"filter": "commentCard", "limit": activity_limit},
            )
            result["comments"] = [simplify_action(action) for action in comments]
        if "checklists" in include:
            checklists = trello.request(f"/cards/{found['id']}/checklists")
            result["checklists"] = [simplify_checklist(item) for item in checklists]
        if "list" in include:
            current_list = next(
                (item for item in opened["lists"] if item.get("id") == found.get("idList")),
                None,
            )
            if current_list is not None:
                result["list"] = simplify_list(current_list)
        return envelope(
            "get_card_context",
            board=board,
            result=result,
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("get_card_context", exc, board_id_or_name)


def get_board_activity(
    board_id_or_name: str,
    limit: int = 10,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Return compact recent board activity."""
    trello = client or TrelloClient()
    try:
        opened = _open_board_data(board_id_or_name, trello)
        if opened.get("error"):
            return envelope("get_board_activity", errors=[opened["error"]])
        board = opened["board"]
        actions = trello.request(f"/boards/{board['id']}/actions", params={"limit": limit})
        return envelope(
            "get_board_activity",
            board=board,
            result={"activity": [simplify_action(action) for action in actions]},
            warnings=opened["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("get_board_activity", exc, board_id_or_name)


def create_cards(
    board_id_or_name: str,
    list: str,
    cards: list[dict[str, Any]],
    dry_run: bool = False,
    dedupe_by_name: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Create cards in one resolved list."""
    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("create_cards", errors=[context["error"]])
        target_list, list_error = resolve_list(list, context["lists"], context["board_map"])
        if list_error:
            return envelope("create_cards", board=context["board"], errors=[list_error])
        existing_cards = _board_cards(trello, context["board"]["id"])
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        for index, spec in enumerate(cards):
            duplicate = _find_exact_card(spec.get("name", ""), target_list["id"], existing_cards)
            if dedupe_by_name and duplicate:
                receipts.append(
                    card_receipt(duplicate, list_name=target_list.get("name"), status="unchanged")
                )
                continue
            labels, label_errors = _resolve_labels(spec.get("labels", []), context)
            draft = {
                "id": None,
                "name": spec.get("name"),
                "idList": target_list["id"],
                "url": None,
                "labels": labels,
            }
            if label_errors:
                receipts.append(
                    card_receipt(draft, list_name=target_list.get("name"), status="failed")
                )
                item_errors.extend(label_errors)
                continue
            if dry_run:
                receipts.append(
                    card_receipt(draft, list_name=target_list.get("name"), status="would_create")
                )
                continue
            try:
                created = trello.request(
                    "/cards",
                    method="POST",
                    data=_create_card_payload(spec, target_list["id"], labels),
                )
                receipts.append(
                    card_receipt(created, list_name=target_list.get("name"), status="created")
                )
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("create_cards", exc, spec.get("name", str(index)))
                receipts.append(
                    card_receipt(draft, list_name=target_list.get("name"), status="failed")
                )
                item_errors.append(
                    error(exc.code, exc.message, input_ref=spec.get("name"), retryable=exc.retryable)
                )
        return _mutation_envelope("create_cards", context, receipts, item_errors, "created")
    except TrelloAPIError as exc:
        return _error_envelope("create_cards", exc, board_id_or_name)


def update_cards(
    board_id_or_name: str,
    updates: list[dict[str, Any]],
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Update one or more cards."""
    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("update_cards", errors=[context["error"]])
        cards = _board_cards(trello, context["board"]["id"])
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        for update in updates:
            card, card_error = resolve_card(update.get("card", ""), cards)
            if card_error:
                receipts.append(_failed_receipt(update.get("card")))
                item_errors.append(card_error)
                continue
            if dry_run:
                receipts.append(card_receipt(card, list_name=_list_name(card, context), status="would_change"))
                continue
            try:
                updated = trello.request(
                    f"/cards/{card['id']}",
                    method="PUT",
                    data=_update_payload(update.get("set", {})),
                )
                for item in update.get("add", {}).get("checklist_items", []):
                    trello.request(
                        f"/cards/{card['id']}/checklistItems",
                        method="POST",
                        data={"name": item},
                    )
                receipts.append(
                    card_receipt(updated, list_name=_list_name(updated, context), status="changed")
                )
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("update_cards", exc, update.get("card", ""))
                receipts.append(card_receipt(card, list_name=_list_name(card, context), status="failed"))
                item_errors.append(
                    error(exc.code, exc.message, input_ref=update.get("card"), retryable=exc.retryable)
                )
        return _mutation_envelope("update_cards", context, receipts, item_errors, "changed")
    except TrelloAPIError as exc:
        return _error_envelope("update_cards", exc, board_id_or_name)


def move_cards(
    board_id_or_name: str,
    moves: list[dict[str, Any]],
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Move cards between lists."""
    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("move_cards", errors=[context["error"]])
        cards = _board_cards(trello, context["board"]["id"])
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        for move in moves:
            card, card_error = resolve_card(move.get("card", ""), cards)
            target_list, list_error = resolve_list(move.get("to_list", ""), context["lists"], context["board_map"])
            if card_error or list_error:
                receipts.append(_failed_receipt(move.get("card")))
                item_errors.append(card_error or list_error)
                continue
            if card.get("idList") == target_list.get("id"):
                receipts.append(card_receipt(card, list_name=target_list.get("name"), status="unchanged"))
                continue
            if dry_run:
                draft = dict(card, idList=target_list["id"])
                receipts.append(card_receipt(draft, list_name=target_list.get("name"), status="would_change"))
                continue
            try:
                moved = trello.request(
                    f"/cards/{card['id']}",
                    method="PUT",
                    data={"idList": target_list["id"]},
                )
                receipts.append(card_receipt(moved, list_name=target_list.get("name"), status="changed"))
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("move_cards", exc, move.get("card", ""))
                receipts.append(card_receipt(card, list_name=_list_name(card, context), status="failed"))
                item_errors.append(
                    error(exc.code, exc.message, input_ref=move.get("card"), retryable=exc.retryable)
                )
        return _mutation_envelope("move_cards", context, receipts, item_errors, "changed")
    except TrelloAPIError as exc:
        return _error_envelope("move_cards", exc, board_id_or_name)


def label_cards(
    board_id_or_name: str,
    card_refs: list[str] | None = None,
    query: str | None = None,
    add: list[str] | None = None,
    remove: list[str] | None = None,
    dry_run: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Apply or remove labels on cards."""
    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("label_cards", errors=[context["error"]])
        cards = _board_cards(trello, context["board"]["id"])
        targets, target_errors = _target_cards(cards, card_refs, query)
        receipts: list[dict[str, Any]] = []
        item_errors: list[dict[str, Any]] = []
        for failed_ref, failed_error in target_errors:
            receipts.append(_failed_receipt(failed_ref))
            item_errors.append(failed_error)
        add_labels, label_errors = _resolve_labels(add or [], context)
        item_errors.extend(label_errors)
        for target_ref, target in targets:
            if add_labels and all(label["id"] in target.get("idLabels", []) for label in add_labels):
                receipts.append(card_receipt(target, list_name=_list_name(target, context), status="unchanged"))
                continue
            if dry_run:
                receipts.append(card_receipt(target, list_name=_list_name(target, context), status="would_change"))
                continue
            try:
                latest = target
                for label in add_labels:
                    latest = trello.request(
                        f"/cards/{target['id']}/idLabels",
                        method="POST",
                        data={"value": label["id"]},
                    )
                    if isinstance(latest, list):
                        latest = dict(target, labels=latest)
                for label_ref in remove or []:
                    label, label_error = resolve_label(label_ref, context["labels"], context["board_map"])
                    if label_error:
                        item_errors.append(label_error)
                        continue
                    latest = trello.request(
                        f"/cards/{target['id']}/idLabels/{label['id']}",
                        method="DELETE",
                    )
                    if isinstance(latest, list):
                        latest = dict(target, labels=latest)
                receipts.append(card_receipt(latest, list_name=_list_name(target, context), status="changed"))
            except TrelloAPIError as exc:
                if _is_batch_stopping_error(exc):
                    return _error_envelope("label_cards", exc, target_ref)
                receipts.append(card_receipt(target, list_name=_list_name(target, context), status="failed"))
                item_errors.append(
                    error(exc.code, exc.message, input_ref=target.get("name"), retryable=exc.retryable)
                )
        return _mutation_envelope("label_cards", context, receipts, item_errors, "changed")
    except TrelloAPIError as exc:
        return _error_envelope("label_cards", exc, board_id_or_name)


def comment_on_card(
    board_id_or_name: str,
    card: str,
    text: str,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Add a comment to a card."""
    trello = client or TrelloClient()
    try:
        context = _mutation_context(board_id_or_name, trello)
        if context.get("error"):
            return envelope("comment_on_card", errors=[context["error"]])
        cards = _board_cards(trello, context["board"]["id"])
        found, card_error = resolve_card(card, cards)
        if card_error:
            return envelope("comment_on_card", board=context["board"], errors=[card_error])
        trello.request(
            f"/cards/{found['id']}/actions/comments",
            method="POST",
            data={"text": text},
        )
        return envelope(
            "comment_on_card",
            board=context["board"],
            result={"commented": 1, "card": card_receipt(found, list_name=_list_name(found, context), status="changed")},
            warnings=context["warnings"],
        )
    except TrelloAPIError as exc:
        return _error_envelope("comment_on_card", exc, card)


def _open_board_data(name_or_id: str, trello: TrelloClient) -> dict[str, Any]:
    boards = _candidate_boards(name_or_id, trello)
    board, err = resolve_board(name_or_id, boards)
    if err:
        return {"error": err}
    lists = trello.request(f"/boards/{board['id']}/lists")
    labels = trello.request(f"/boards/{board['id']}/labels")
    board_map, status, warnings = refresh_board_map(board, lists, labels)
    return {
        "board": board,
        "lists": lists,
        "labels": labels,
        "board_map": board_map,
        "board_map_status": status,
        "warnings": warnings,
    }


def _mutation_context(board_id_or_name: str, trello: TrelloClient) -> dict[str, Any]:
    return _open_board_data(board_id_or_name, trello)


def _board_cards(trello: TrelloClient, board_id: str) -> list[dict[str, Any]]:
    return trello.request(f"/boards/{board_id}/cards", params={"filter": "open"})


def _find_exact_card(name: str, list_id: str, cards: list[dict[str, Any]]) -> dict[str, Any] | None:
    for card in cards:
        if card.get("name") == name and card.get("idList") == list_id and not card.get("closed"):
            return card
    return None


def _create_card_payload(
    spec: dict[str, Any], list_id: str, labels: list[dict[str, Any]]
) -> dict[str, Any]:
    payload = {"idList": list_id, "name": spec.get("name")}
    if spec.get("desc"):
        payload["desc"] = spec["desc"]
    if spec.get("due"):
        payload["due"] = spec["due"]
    if labels:
        payload["idLabels"] = ",".join(label["id"] for label in labels)
    return payload


def _resolve_labels(
    refs: list[str], context: dict[str, Any]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    labels = []
    errors = []
    for ref in refs:
        label, label_error = resolve_label(ref, context["labels"], context["board_map"])
        if label_error:
            errors.append(label_error)
        else:
            labels.append(label)
    return labels, errors


def _update_payload(values: dict[str, Any]) -> dict[str, Any]:
    mapping = {"description": "desc", "due_complete": "dueComplete", "archived": "closed"}
    return {mapping.get(key, key): value for key, value in values.items()}


def _target_cards(
    cards: list[dict[str, Any]], refs: list[str] | None, query: str | None
) -> tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, dict[str, Any]]]]:
    if refs:
        targets = []
        errors = []
        for ref in refs:
            card, card_error = resolve_card(ref, cards)
            if card_error:
                errors.append((ref, card_error))
            else:
                targets.append((ref, card))
        return targets, errors
    if query:
        query_lower = query.lower()
        return [
            (card.get("name") or card.get("id"), card)
            for card in cards
            if query_lower in card.get("name", "").lower()
        ], []
    return [], []


def _list_name(card: dict[str, Any], context: dict[str, Any]) -> str | None:
    list_id = card.get("idList") or card.get("list_id")
    for item in context["lists"]:
        if item.get("id") == list_id:
            return item.get("name")
    return None


def _failed_receipt(input_ref: Any) -> dict[str, Any]:
    return {
        "id": None,
        "name": input_ref,
        "list_id": None,
        "list_name": None,
        "labels": [],
        "url": None,
        "status": "failed",
    }


def _mutation_envelope(
    tool: str,
    context: dict[str, Any],
    receipts: list[dict[str, Any]],
    item_errors: list[dict[str, Any]],
    changed_status: str,
) -> dict[str, Any]:
    changed = sum(1 for receipt in receipts if receipt["status"] in {changed_status, "created", "changed"})
    unchanged = sum(1 for receipt in receipts if receipt["status"] == "unchanged")
    failed = sum(1 for receipt in receipts if receipt["status"] == "failed")
    would_create = sum(1 for receipt in receipts if receipt["status"] == "would_create")
    would_change = sum(1 for receipt in receipts if receipt["status"] == "would_change")
    result = {
        "changed": changed,
        "created": sum(1 for receipt in receipts if receipt["status"] == "created"),
        "unchanged": unchanged,
        "failed": failed,
        "would_create": would_create,
        "would_change": would_change,
        "cards": receipts,
    }
    errors = []
    if failed and (changed or result["created"] or unchanged or would_create or would_change):
        errors.append(error("partial_failure", "Some items failed", retryable=False))
    errors.extend(item_errors)
    return envelope(
        tool,
        board=context["board"],
        result=result,
        warnings=context["warnings"],
        errors=errors,
    )


def _is_batch_stopping_error(exc: TrelloAPIError) -> bool:
    return exc.code in {"trello_auth_error", "trello_rate_limited"}


def _candidate_boards(name_or_id: str, trello: TrelloClient) -> list[dict[str, Any]]:
    if name_or_id.startswith("http"):
        return trello.request("/members/me/boards")
    if _looks_like_trello_id(name_or_id):
        try:
            return [trello.request(f"/boards/{name_or_id}")]
        except TrelloAPIError as exc:
            if exc.code != "not_found":
                raise
    try:
        result = trello.request(
            "/search",
            params={"query": name_or_id, "modelTypes": "boards", "boards_limit": 10},
        )
        boards = result.get("boards", []) if isinstance(result, dict) else []
        if boards:
            return boards
    except TrelloAPIError as exc:
        if exc.code != "trello_bad_request":
            raise
    return trello.request("/members/me/boards")


def _local_card_search(
    trello: TrelloClient,
    board_id: str,
    query: str,
    filters: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    cards = trello.request(f"/boards/{board_id}/cards", params={"filter": "open"})
    query_lower = query.lower()
    matches = [card for card in cards if query_lower in card.get("name", "").lower()]
    return _filter_cards(matches, filters or {}, {})


def _filter_cards(
    cards: list[dict[str, Any]],
    filters: dict[str, Any],
    opened: dict[str, Any],
) -> list[dict[str, Any]]:
    filtered = cards
    state = filters.get("state")
    if state == "open":
        filtered = [card for card in filtered if not card.get("closed")]
    elif state == "archived":
        filtered = [card for card in filtered if card.get("closed")]
    return filtered


def _include_set(include: str) -> set[str]:
    return {item.strip() for item in include.split(",") if item.strip()} or {"summary"}


def _looks_like_trello_id(value: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-fA-F]{8,}", value))


def _error_envelope(tool: str, exc: TrelloAPIError, input_ref: str) -> dict[str, Any]:
    return envelope(
        tool,
        errors=[
            error(
                exc.code,
                exc.message,
                input_ref=input_ref,
                retryable=exc.retryable,
            )
        ],
    )


def _register_tools() -> None:
    @mcp.tool(name="open_board")
    def _mcp_open_board(name_or_id: str) -> dict[str, Any]:
        return open_board(name_or_id)

    @mcp.tool(name="get_board_snapshot")
    def _mcp_get_board_snapshot(
        board_id_or_name: str,
        include: str = "summary",
        include_descriptions: bool = False,
        activity_limit: int = 10,
    ) -> dict[str, Any]:
        return get_board_snapshot(
            board_id_or_name,
            include=include,
            include_descriptions=include_descriptions,
            activity_limit=activity_limit,
        )

    @mcp.tool(name="find_cards")
    def _mcp_find_cards(
        board_id_or_name: str,
        query: str,
        filters: dict[str, Any] | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        return find_cards(board_id_or_name, query, filters=filters, limit=limit)

    @mcp.tool(name="get_card_context")
    def _mcp_get_card_context(
        board_id_or_name: str,
        card: str,
        include: list[str] | None = None,
        activity_limit: int = 10,
    ) -> dict[str, Any]:
        return get_card_context(
            board_id_or_name,
            card,
            include=include,
            activity_limit=activity_limit,
        )

    @mcp.tool(name="get_board_activity")
    def _mcp_get_board_activity(board_id_or_name: str, limit: int = 10) -> dict[str, Any]:
        return get_board_activity(board_id_or_name, limit=limit)

    @mcp.tool(name="create_cards")
    def _mcp_create_cards(
        board_id_or_name: str,
        list: str,
        cards: list[dict[str, Any]],
        dry_run: bool = False,
        dedupe_by_name: bool = False,
    ) -> dict[str, Any]:
        return create_cards(
            board_id_or_name,
            list,
            cards,
            dry_run=dry_run,
            dedupe_by_name=dedupe_by_name,
        )

    @mcp.tool(name="update_cards")
    def _mcp_update_cards(
        board_id_or_name: str,
        updates: list[dict[str, Any]],
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return update_cards(board_id_or_name, updates, dry_run=dry_run)

    @mcp.tool(name="move_cards")
    def _mcp_move_cards(
        board_id_or_name: str,
        moves: list[dict[str, Any]],
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return move_cards(board_id_or_name, moves, dry_run=dry_run)

    @mcp.tool(name="label_cards")
    def _mcp_label_cards(
        board_id_or_name: str,
        card_refs: list[str] | None = None,
        query: str | None = None,
        add: list[str] | None = None,
        remove: list[str] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return label_cards(
            board_id_or_name,
            card_refs=card_refs,
            query=query,
            add=add,
            remove=remove,
            dry_run=dry_run,
        )

    @mcp.tool(name="comment_on_card")
    def _mcp_comment_on_card(board_id_or_name: str, card: str, text: str) -> dict[str, Any]:
        return comment_on_card(board_id_or_name, card, text)

    @mcp.tool(name="manage_boards")
    def _mcp_manage_boards(
        operation: str,
        board_id_or_name: str | None = None,
        name: str | None = None,
        desc: str = "",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return manage_boards(
            operation,
            board_id_or_name=board_id_or_name,
            name=name,
            desc=desc,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_cards")
    def _mcp_manage_cards(
        board_id_or_name: str,
        operation: str,
        card: str | None = None,
        list: str | None = None,
        confirm: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return manage_cards(
            board_id_or_name,
            operation,
            card=card,
            list=list,
            confirm=confirm,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_comments")
    def _mcp_manage_comments(
        operation: str,
        action: str,
        text: str | None = None,
        confirm: bool = False,
    ) -> dict[str, Any]:
        return manage_comments(
            operation,
            action,
            text=text,
            confirm=confirm,
        )

    @mcp.tool(name="manage_checklists")
    def _mcp_manage_checklists(
        board_id_or_name: str,
        card: str,
        operation: str = "list",
        checklist: str | None = None,
        item: str | None = None,
        updates: list[dict[str, Any]] | None = None,
        name: str | None = None,
        checked: bool | None = None,
        state: str | None = None,
        pos: str | int | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return manage_checklists(
            board_id_or_name,
            card,
            operation=operation,
            checklist=checklist,
            item=item,
            updates=updates,
            name=name,
            checked=checked,
            state=state,
            pos=pos,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_attachments")
    def _mcp_manage_attachments(
        board_id_or_name: str,
        card: str,
        operation: str = "list",
        attachment: str | None = None,
        url: str | None = None,
        file_path: str | None = None,
        name: str | None = None,
        confirm: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return manage_attachments(
            board_id_or_name,
            card,
            operation=operation,
            attachment=attachment,
            url=url,
            file_path=file_path,
            name=name,
            confirm=confirm,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_custom_fields")
    def _mcp_manage_custom_fields(
        board_id_or_name: str,
        operation: str,
        card: str | None = None,
        field: str | None = None,
        value: Any = None,
        option: str | None = None,
        name: str | None = None,
        type: str | None = None,
        pos: str | int | None = None,
        display_cardFront: bool | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return manage_custom_fields(
            board_id_or_name,
            operation,
            card=card,
            field=field,
            value=value,
            option=option,
            name=name,
            type=type,
            pos=pos,
            display_cardFront=display_cardFront,
            dry_run=dry_run,
        )

    @mcp.tool(name="assign_members")
    def _mcp_assign_members(
        board_id_or_name: str,
        operation: str,
        card: str | None = None,
        members: list[str] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return assign_members(
            board_id_or_name,
            operation,
            card=card,
            members=members,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_lists")
    def _mcp_manage_lists(
        board_id_or_name: str,
        operation: str,
        list: str | None = None,
        target_list: str | None = None,
        name: str | None = None,
        pos: str | int | None = None,
        closed: bool | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return manage_lists(
            board_id_or_name,
            operation,
            list=list,
            target_list=target_list,
            name=name,
            pos=pos,
            closed=closed,
            dry_run=dry_run,
        )

    @mcp.tool(name="manage_labels")
    def _mcp_manage_labels(
        board_id_or_name: str,
        operation: str,
        label: str | None = None,
        name: str | None = None,
        color: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        return manage_labels(
            board_id_or_name,
            operation,
            label=label,
            name=name,
            color=color,
            dry_run=dry_run,
        )

    @mcp.tool(name="batch_get_compact")
    def _mcp_batch_get_compact(urls: list[str]) -> dict[str, Any]:
        return batch_get_compact(urls)

    @mcp.tool(name="trello_get")
    def _mcp_trello_get(
        endpoint: str,
        params: dict[str, Any] | None = None,
        compact: bool = True,
    ) -> dict[str, Any]:
        return trello_get(endpoint, params=params, compact=compact)

    @mcp.tool(name="trello_post")
    def _mcp_trello_post(
        endpoint: str,
        data: dict[str, Any] | None = None,
        compact: bool = True,
    ) -> dict[str, Any]:
        return trello_post(endpoint, data=data, compact=compact)

    @mcp.tool(name="trello_put")
    def _mcp_trello_put(
        endpoint: str,
        data: dict[str, Any] | None = None,
        compact: bool = True,
    ) -> dict[str, Any]:
        return trello_put(endpoint, data=data, compact=compact)

    @mcp.tool(name="trello_delete")
    def _mcp_trello_delete(
        endpoint: str,
        data: dict[str, Any] | None = None,
        confirm: bool = False,
    ) -> dict[str, Any]:
        return trello_delete(endpoint, data=data, confirm=confirm)


def main() -> None:
    """Run the Trello MCP server."""
    mcp.run()


_register_tools()
