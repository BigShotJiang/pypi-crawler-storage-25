"""PII analysis engine for generating static configurations.

This module analyzes sampled documents for PII patterns and generates
detailed statistics for config generation.
"""

import logging
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set

from pydantic import BaseModel, Field

from mongo_replication.engine.pii.custom_operators import resolve_smart_operator
from mongo_replication.engine.pii.presidio_analyzer import PresidioAnalyzer
from mongo_replication.engine.pii.sampler import SamplingResult

logger = logging.getLogger(__name__)


class FieldPIIStats(BaseModel):
    """Statistics for PII detected in a specific field."""

    field_path: str
    entity_type: str
    suggested_strategy: str
    detections: int
    total_samples: int
    prevalence_pct: float
    avg_confidence: float
    min_confidence: float
    max_confidence: float
    sample_value: Optional[str] = None
    """Sample value from first detection (for anonymization example generation)."""

    def __str__(self) -> str:
        """Human-readable representation."""
        return (
            f"{self.field_path} ({self.entity_type}): "
            f"{self.prevalence_pct:.1f}% prevalence, "
            f"avg confidence {self.avg_confidence:.2f}"
        )


class CollectionPIIAnalysis(BaseModel):
    """Analysis result for a single collection."""

    collection_name: str
    total_samples: int
    fields_with_pii: List[FieldPIIStats] = Field(default_factory=list)
    all_field_names: Set[str] = Field(default_factory=set)

    @property
    def has_pii(self) -> bool:
        """Check if any PII was detected."""
        return len(self.fields_with_pii) > 0

    @property
    def pii_field_count(self) -> int:
        """Number of fields containing PII."""
        return len(self.fields_with_pii)

    def get_pii_config(self) -> Dict[str, str]:
        """
        Get pii_fields config dict for YAML generation (DEPRECATED).

        DEPRECATED: This method returns the old dict format. Use get_pii_anonymization_list() instead.

        Returns:
            Dict mapping field_path -> strategy
        """
        return {stat.field_path: stat.suggested_strategy for stat in self.fields_with_pii}

    def get_pii_anonymization_list(self) -> List[Dict[str, Any]]:
        """
        Get pii_anonymization config list for YAML generation (NEW FORMAT).

        For fields with multiple entity types, entries are sorted by confidence
        (highest first) to ensure operators are applied in order of detection strength.

        Returns:
            List of dicts with 'field', 'operator', and 'params' keys,
            where params contains 'entity_type' and any other operator parameters.
            Sorted by (field_path, -avg_confidence) for multi-entity support
        """
        # Sort by field path first, then by confidence (descending) within each field
        # This ensures multi-entity fields have operators in confidence order
        sorted_stats = sorted(
            self.fields_with_pii, key=lambda stat: (stat.field_path, -stat.avg_confidence)
        )

        return [
            {
                "field": stat.field_path,
                "operator": stat.suggested_strategy,
                "params": {"entity_type": stat.entity_type},
            }
            for stat in sorted_stats
        ]


class PIIAnalysisEngine:
    """
    Analyzes sampled documents for PII and generates statistics.

    Uses Presidio for entity detection and aggregates results across
    all samples to provide confidence and prevalence metrics.
    """

    def __init__(
        self,
        confidence_threshold: float = 0.7,
        language: str = "en",
        prevalence_threshold: float = 0.10,  # Skip fields with <10% prevalence
        allowlist_fields: Optional[List[str]] = None,
        entity_types: Optional[List[str]] = None,
        presidio_config: Optional[str] = None,
        default_strategies: Optional[Dict[str, str]] = None,
    ):
        """
        Initialize PII analysis engine.

        Args:
            confidence_threshold: Minimum confidence score for PII detection
            language: Language code for NLP ('en' or 'fr')
            prevalence_threshold: Minimum prevalence (0.0-1.0) to include field
            allowlist_fields: Field patterns to exclude from detection
            entity_types: Specific entity types to detect (None or [] = all types)
            presidio_config: Optional path to Presidio YAML configuration file
            default_strategies: Default anonymization strategies per entity type
        """
        self.confidence_threshold = confidence_threshold
        self.language = language
        self.prevalence_threshold = prevalence_threshold
        self.allowlist_fields = allowlist_fields or ["_id", "meta.*", "*.id"]
        self.entity_types = entity_types if entity_types else None  # Empty list -> None (all types)
        self.presidio_config = presidio_config
        self.default_strategies = default_strategies or {}

        # Lazy load analyzer
        self._analyzer: Optional[PresidioAnalyzer] = None

    def get_analyzer(self) -> PresidioAnalyzer:
        """Lazy load Presidio analyzer."""
        if self._analyzer is None:
            if self.presidio_config:
                logger.info(
                    f"🔍 Initializing Presidio analyzer with config: {self.presidio_config} "
                    f"(language={self.language})..."
                )
            else:
                logger.info(f"🔍 Initializing Presidio analyzer (language={self.language})...")
            self._analyzer = PresidioAnalyzer()
        return self._analyzer

    def analyze_collection(
        self,
        sampling_result: SamplingResult,
    ) -> CollectionPIIAnalysis:
        """
        Analyze a collection's sampled documents for PII.

        Args:
            sampling_result: Result from CollectionSampler

        Returns:
            CollectionPIIAnalysis with aggregated statistics
        """
        collection_name = sampling_result.collection_name
        sample_docs = sampling_result.sample_docs

        if not sample_docs:
            logger.info("   ⚠️  No samples to analyze")
            return CollectionPIIAnalysis(
                collection_name=collection_name,
                total_samples=0,
            )

        logger.info(f"   🔍 Analyzing {len(sample_docs)} samples for PII...")

        # Track PII detections per field
        # Structure: {field_path: {entity_type: [confidence_scores]}}
        field_detections: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))

        # Track sample values per field (capture first non-None value)
        # Structure: {field_path: {entity_type: sample_value}}
        field_sample_values: Dict[str, Dict[str, str]] = defaultdict(dict)

        # Track all field names seen
        all_fields: Set[str] = set()

        analyzer = self.get_analyzer()

        # Analyze each document
        for doc in sample_docs:
            # Get all field paths
            doc_fields = self._get_all_field_paths(doc)
            all_fields.update(doc_fields)

            # Analyze document for PII
            pii_map = analyzer.analyze_document(
                document=doc,
                language=self.language,
                confidence_threshold=self.confidence_threshold,
                allowlist_fields=self.allowlist_fields,
                entity_types=self.entity_types,
                presidio_config_path=self.presidio_config,
            )

            # Aggregate detections (normalize array paths)
            for field_path, entity_info in pii_map.items():
                entity_type, confidence = (
                    entity_info  # Unpack tuple (entity_type, confidence_score)
                )
                # Normalize array indices (e.g., "invitations[0].email" -> "invitations.email")
                normalized_path = self._normalize_array_path(field_path)
                field_detections[normalized_path][entity_type].append(confidence)

                # Capture sample value (first non-None value per field+entity)
                if (
                    normalized_path not in field_sample_values
                    or entity_type not in field_sample_values[normalized_path]
                ):
                    field_value = self._get_field_value(doc, field_path)
                    if field_value is not None:
                        field_sample_values[normalized_path][entity_type] = str(field_value)
                        logger.debug(
                            f"      Captured sample value for {normalized_path}.{entity_type}: {field_value}"
                        )

        # Convert detections to statistics
        total_samples = len(sample_docs)
        fields_with_pii: List[FieldPIIStats] = []

        for field_path, entity_types in field_detections.items():
            for entity_type, confidences in entity_types.items():
                detections = len(confidences)
                prevalence = detections / total_samples

                # Skip low-prevalence fields (likely false positives or edge cases)
                if prevalence < self.prevalence_threshold:
                    logger.debug(
                        f"      Skipping {field_path} ({entity_type}): "
                        f"low prevalence {prevalence:.1%}"
                    )
                    continue

                avg_confidence = sum(confidences) / len(confidences)
                min_confidence = min(confidences)
                max_confidence = max(confidences)

                # Determine redaction strategy
                strategy = self._recommend_strategy(entity_type, avg_confidence)

                # Get sample value for this field+entity
                sample_value = field_sample_values.get(field_path, {}).get(entity_type)
                if sample_value:
                    logger.debug(
                        f"      Sample value for {field_path}.{entity_type}: {sample_value}"
                    )
                else:
                    logger.debug(f"      No sample value captured for {field_path}.{entity_type}")

                stats = FieldPIIStats(
                    field_path=field_path,
                    entity_type=entity_type,
                    suggested_strategy=strategy,
                    detections=detections,
                    total_samples=total_samples,
                    prevalence_pct=prevalence * 100,
                    avg_confidence=avg_confidence,
                    min_confidence=min_confidence,
                    max_confidence=max_confidence,
                    sample_value=sample_value,
                )

                fields_with_pii.append(stats)
                logger.info(f"      ✓ {stats}")

        # Sort by prevalence (most common first)
        fields_with_pii.sort(key=lambda s: s.prevalence_pct, reverse=True)

        return CollectionPIIAnalysis(
            collection_name=collection_name,
            total_samples=total_samples,
            fields_with_pii=fields_with_pii,
            all_field_names=all_fields,
        )

    def analyze_all_collections(
        self,
        sampling_results: Dict[str, SamplingResult],
    ) -> Dict[str, CollectionPIIAnalysis]:
        """
        Analyze PII across multiple collections.

        Args:
            sampling_results: Dict of collection_name -> SamplingResult

        Returns:
            Dict of collection_name -> CollectionPIIAnalysis
        """
        logger.info(f"\n🔍 Analyzing PII in {len(sampling_results)} collections...")

        analyses = {}
        for i, (coll_name, sampling_result) in enumerate(sampling_results.items(), 1):
            logger.info(f"\n[{i}/{len(sampling_results)}] {coll_name}")
            try:
                analysis = self.analyze_collection(sampling_result)
                analyses[coll_name] = analysis

                if analysis.has_pii:
                    logger.info(f"   ✅ Found PII in {analysis.pii_field_count} fields")
                else:
                    logger.info("   ℹ️  No PII detected")

            except Exception as e:
                logger.error(f"   ❌ Analysis failed: {e}")
                # Continue with other collections
                continue

        return analyses

    def _recommend_strategy(self, entity_type: str, avg_confidence: float) -> str:
        """
        Recommend anonymization strategy based on entity type and confidence.

        This method resolves smart operators (smart_mask, smart_fake) to concrete
        operators based on the detected entity type. The resolved operator will be
        stored in the replication config.

        Args:
            entity_type: Detected entity type (e.g., "EMAIL_ADDRESS")
            avg_confidence: Average confidence score

        Returns:
            Concrete operator name (e.g., "mask_email", "fake_phone", "mask")
        """
        # Priority 1: Check if user configured a strategy for this specific entity type
        if self.default_strategies and entity_type in self.default_strategies:
            strategy = self.default_strategies[entity_type]
            # Resolve smart operators to concrete operators
            return resolve_smart_operator(strategy, entity_type)

        # Priority 2: Check if user configured a DEFAULT strategy for all types
        if self.default_strategies and "DEFAULT" in self.default_strategies:
            strategy = self.default_strategies["DEFAULT"]
            # Resolve smart operators to concrete operators
            return resolve_smart_operator(strategy, entity_type)

        # Priority 3: Fallback to hardcoded logic (for backwards compatibility)
        # Highly sensitive - always hash for referential integrity
        if entity_type in [
            "CREDIT_CARD",
            "IBAN_CODE",
            "CRYPTO",
            "US_PASSPORT",
            "UK_PASSPORT",
        ]:
            return "hash"

        # High-confidence SSN - hash for referential integrity
        if entity_type == "US_SSN" and avg_confidence >= 0.9:
            return "hash"

        # Default to smart format-preserving redaction (legacy behavior)
        # Note: "redact" is a legacy operator, new configs should use smart_mask/smart_fake
        return "redact"

    @staticmethod
    def _normalize_array_path(field_path: str) -> str:
        """
        Remove array indices from field path.

        Examples:
            "invitations[0].invitee.email" -> "invitations.invitee.email"
            "contacts[5].name" -> "contacts.name"
            "simple.field" -> "simple.field"

        Args:
            field_path: Field path with array indices

        Returns:
            Normalized field path without array indices
        """
        import re

        # Remove [N] patterns and the dot that follows (if any)
        normalized = re.sub(r"\[\d+\]\.?", ".", field_path)
        # Clean up any double dots that might result
        normalized = re.sub(r"\.\.+", ".", normalized)
        # Remove leading/trailing dots
        return normalized.strip(".")

    def _get_all_field_paths(
        self,
        doc: Dict[str, Any],
        parent_path: str = "",
    ) -> Set[str]:
        """
        Recursively extract all field paths from a document.

        Args:
            doc: Document to extract fields from
            parent_path: Parent path prefix (for recursion)

        Returns:
            Set of field paths in dot notation
        """
        paths = set()

        for key, value in doc.items():
            # Build current path
            current_path = f"{parent_path}.{key}" if parent_path else key
            paths.add(current_path)

            # Recurse into nested dicts
            if isinstance(value, dict):
                nested_paths = self._get_all_field_paths(value, current_path)
                paths.update(nested_paths)

            # Handle arrays (only check first element for schema)
            elif isinstance(value, list) and value:
                first_item = value[0]
                if isinstance(first_item, dict):
                    # Add array notation
                    array_path = f"{current_path}[0]"
                    paths.add(array_path)
                    nested_paths = self._get_all_field_paths(first_item, array_path)
                    paths.update(nested_paths)

        return paths

    @staticmethod
    def _get_field_value(doc: Dict[str, Any], field_path: str) -> Optional[Any]:
        """
        Get the value of a field from a document using dot notation path.

        Args:
            doc: Document to extract value from
            field_path: Field path in dot notation (e.g., "user.email" or "contacts[0].name")

        Returns:
            Field value if found, None otherwise
        """
        import re

        # Split path into parts, handling array notation
        parts = re.split(r"[\.\[]", field_path)
        parts = [p.rstrip("]") for p in parts]  # Remove closing brackets

        current = doc
        for part in parts:
            if not part:  # Skip empty parts
                continue

            # Handle array index
            if part.isdigit():
                idx = int(part)
                if isinstance(current, list) and 0 <= idx < len(current):
                    current = current[idx]
                else:
                    return None
            # Handle dict key
            elif isinstance(current, dict):
                current = current.get(part)
                if current is None:
                    return None
            else:
                return None

        return current

    def get_summary_statistics(
        self,
        analyses: Dict[str, CollectionPIIAnalysis],
    ) -> Dict[str, Any]:
        """
        Generate summary statistics across all collections.

        Args:
            analyses: Dict of collection_name -> CollectionPIIAnalysis

        Returns:
            Dict with summary statistics
        """
        total_collections = len(analyses)
        collections_with_pii = sum(1 for a in analyses.values() if a.has_pii)
        collections_without_pii = total_collections - collections_with_pii

        total_pii_fields = sum(a.pii_field_count for a in analyses.values())

        # Count by entity type
        entity_type_counts: Dict[str, int] = defaultdict(int)
        for analysis in analyses.values():
            for field_stat in analysis.fields_with_pii:
                entity_type_counts[field_stat.entity_type] += 1

        # Sort entity types by count
        sorted_entity_types = sorted(entity_type_counts.items(), key=lambda x: x[1], reverse=True)

        return {
            "total_collections": total_collections,
            "collections_with_pii": collections_with_pii,
            "collections_without_pii": collections_without_pii,
            "total_pii_fields": total_pii_fields,
            "entity_type_breakdown": sorted_entity_types,
        }
