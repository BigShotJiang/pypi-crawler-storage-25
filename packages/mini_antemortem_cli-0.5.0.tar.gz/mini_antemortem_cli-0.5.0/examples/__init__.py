"""Example fixtures and deterministic replay helpers."""

