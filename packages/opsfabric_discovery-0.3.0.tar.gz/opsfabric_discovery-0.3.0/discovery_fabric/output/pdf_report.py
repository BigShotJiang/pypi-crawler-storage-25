"""Render the customer-facing executive PDF for a DiscoveryFabric audit run.

The PDF is the deliverable: a non-engineer (CTO, VP Eng) should be able to read
it in 30 seconds and immediately understand both the score and the top gaps,
each tied to a one-line statement of business impact.

Inputs come from the existing score command outputs (CoverageResult.summary,
CoverageResult.resources, account_meta). No new AWS calls are made here.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# WeasyPrint resolves libpango/libgobject via dyld at import time. On macOS
# Apple Silicon, Homebrew installs them under /opt/homebrew/lib which is not
# on dyld's default search path. We inject the path before the import so the
# library load succeeds without requiring users to set DYLD_FALLBACK_LIBRARY_PATH
# in their shell.
if sys.platform == "darwin":
    _brew_lib = "/opt/homebrew/lib"
    if Path(_brew_lib).is_dir():
        existing = os.environ.get("DYLD_FALLBACK_LIBRARY_PATH", "")
        if _brew_lib not in existing.split(":"):
            os.environ["DYLD_FALLBACK_LIBRARY_PATH"] = (
                f"{_brew_lib}:{existing}" if existing else _brew_lib
            )

from jinja2 import Environment, FileSystemLoader, select_autoescape  # noqa: E402
from weasyprint import HTML  # noqa: E402

_TEMPLATE_DIR = Path(__file__).parent / "templates"
_TEMPLATE_NAME = "executive_report.html"
_CSS_NAME = "executive_report.css"

# Static reference: typical alarm coverage we observe across mid-market
# AWS-heavy orgs running ECS / Lambda / RDS. Surfaced in the PDF footnote
# so the customer's score is contextualized rather than presented in a vacuum.
INDUSTRY_BASELINE = 75

# Display cap for the "Critical gaps" section. Beyond this, the PDF stops
# fitting in three pages and the disclaimer footer floats alone on page 4.
# Overflow is summarized in a "+N more" line.
MAX_CRITICAL_GAPS_DISPLAYED = 6

_RESOURCE_KIND_LABELS = {
    "ecs_service": "ECS service",
    "lambda_function": "Lambda function",
    "rds_instance": "RDS instance",
    "rds_cluster": "RDS / Aurora cluster",
    "sqs_queue": "SQS queue",
}


@dataclass
class AccountMeta:
    account_id: str
    account_alias: str | None
    scanned_at_utc: str
    regions_scanned: list[str]
    regions_skipped: list[dict[str, str]]


def _grade(score: float) -> tuple[str, str, str, str]:
    """Map a numeric coverage score to (letter, label, css_class, headline_class)."""
    if score >= 90:
        return ("A", "Excellent — at or above industry leaders", "good", "good")
    if score >= 75:
        return ("B", "Strong — at industry baseline", "good", "good")
    if score >= 60:
        return ("C", "Below baseline — material gaps remain", "warn", "warn")
    if score >= 40:
        return ("D", "Significant gaps — production risk elevated", "warn", "bad")
    return ("F", "Critical gaps — undetected outages are likely", "bad", "bad")


def _severity_class(severity: str) -> str:
    s = (severity or "").upper()
    if s == "P1":
        return "p1"
    if s == "P2":
        return "p2"
    return "p3"


def _severity_rank(severity: str) -> int:
    s = (severity or "").upper()
    return {"P1": 0, "P2": 1, "P3": 2}.get(s, 3)


def _build_critical_gaps(coverage_resources: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    """Flatten missing required checks across resources, sorted by severity then by check id.

    Returns (top_N, total_count) so the template can render a "+N more" line.
    """
    gaps: list[dict[str, Any]] = []
    for resource in coverage_resources:
        for check in resource.get("checks", []):
            status = str(check.get("status", "")).upper()
            # Both MISSING (no alarm at all) and DEGRADED (alarm exists but is
            # disabled / has no notification target / is in INSUFFICIENT_DATA)
            # are reported as critical gaps. They differ in remediation —
            # MISSING needs a new alarm; DEGRADED needs an existing one fixed.
            if status == "PRESENT" or not check.get("required"):
                continue
            base_impact = check.get("business_impact", "") or (
                "(No business-impact statement defined for this check.)"
            )
            if status == "DEGRADED":
                degraded_reason = str(check.get("degraded_reason") or "")
                hint_map = {
                    "actions_disabled": "Alarm exists but its actions are disabled — it will not page anyone.",
                    "no_alarm_actions_configured": "Alarm exists but has no notification targets — it will fire silently.",
                    "insufficient_data": "Alarm exists but is in INSUFFICIENT_DATA — CloudWatch isn't receiving the metric.",
                }
                hint = hint_map.get(degraded_reason, "Alarm exists but will not page anyone.")
                final_impact = f"{hint} {base_impact}"
            else:
                final_impact = base_impact
            gaps.append(
                {
                    "title": check.get("title", check.get("check_id", "Unknown check")),
                    "severity": (check.get("severity") or "P3").upper(),
                    "sev_class": _severity_class(check.get("severity", "")),
                    "business_impact": final_impact,
                    "resource_kind": _RESOURCE_KIND_LABELS.get(
                        resource.get("resource_kind", ""), resource.get("resource_kind", "")
                    ),
                    "region": resource.get("region", ""),
                    "resource_name": resource.get("resource_name", ""),
                    "_rank": _severity_rank(check.get("severity", "")),
                    "_check_id": check.get("check_id", ""),
                }
            )

    gaps.sort(key=lambda g: (g["_rank"], g["_check_id"]))
    total = len(gaps)
    return gaps[:MAX_CRITICAL_GAPS_DISPLAYED], total


def _build_coverage_by_kind(coverage_resources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_kind: dict[str, dict[str, int]] = {}
    for r in coverage_resources:
        kind = r.get("resource_kind", "unknown")
        agg = by_kind.setdefault(
            kind,
            {"resource_count": 0, "required_total": 0, "required_met": 0},
        )
        agg["resource_count"] += 1
        agg["required_total"] += int(r.get("required_total", 0))
        agg["required_met"] += int(r.get("required_met", 0))

    rows: list[dict[str, Any]] = []
    for kind, agg in sorted(by_kind.items()):
        required_total = agg["required_total"]
        coverage_pct = round((agg["required_met"] / required_total) * 100, 1) if required_total else 100.0
        rows.append(
            {
                "label": _RESOURCE_KIND_LABELS.get(kind, kind),
                "resource_count": agg["resource_count"],
                "required_total": required_total,
                "required_met": agg["required_met"],
                "coverage_pct": coverage_pct,
            }
        )
    return rows


def _remediation_breakdown(coverage_resources: list[dict[str, Any]]) -> dict[str, int]:
    """Count required-only gaps by the remediation path each one needs.

    The customer-facing question is "how do I close this gap?" — and the
    answer differs:
      auto_fixable → AlarmFabric creates the alarm in one click (no input)
      human_guided → AlarmFabric creates it once you provide threshold / SLO
      degraded     → an alarm already exists; enable it / attach an SNS target
    """
    auto = 0
    human = 0
    degraded = 0
    for r in coverage_resources:
        for c in r.get("checks", []):
            if not c.get("required"):
                continue
            status = str(c.get("status", "")).upper()
            if status == "MISSING":
                if str(c.get("mode", "auto")) == "auto":
                    auto += 1
                else:
                    human += 1
            elif status == "DEGRADED":
                degraded += 1
    return {"auto_fixable": auto, "human_guided": human, "degraded": degraded}


def _build_recommendations(
    score: float,
    required_missing: int,
    coverage_resources: list[dict[str, Any]],
    breakdown: dict[str, int] | None = None,
) -> list[str]:
    """Three concrete next steps tailored to the score band, using the
    real remediation-path breakdown so the reader sees actionable numbers
    instead of generic copy.
    """
    breakdown = breakdown or {"auto_fixable": 0, "human_guided": 0, "degraded": 0}
    auto = int(breakdown.get("auto_fixable", 0))
    human = int(breakdown.get("human_guided", 0))
    degraded = int(breakdown.get("degraded", 0))

    critical_resources = sum(
        1 for r in coverage_resources if int(r.get("required_total", 0)) > int(r.get("required_met", 0))
    )

    if score >= 90:
        return [
            "Coverage is strong. Maintain it by re-running this audit monthly to catch drift as new resources are deployed.",
            "Focus next on optional / application-layer checks (latency SLOs, log-pattern alarms) — these typically catch issues that infra metrics miss.",
            "Consider OpsFabric's runtime incident response to convert the existing alarm signal into automated triage and remediation.",
        ]

    steps: list[str] = []
    if auto > 0:
        steps.append(
            f"<strong>Day 1:</strong> close the <strong>{auto} auto-creatable required gap{'s' if auto != 1 else ''}</strong> via AlarmFabric — one click per resource, no thresholds to author by hand."
        )
    if degraded > 0:
        steps.append(
            f"<strong>Day 1:</strong> fix the <strong>{degraded} alarm{'s' if degraded != 1 else ''}</strong> that already exist but won't notify (actions disabled / no SNS target / INSUFFICIENT_DATA). These are higher-leverage than creating new — the alarm is already authored, it just isn't wired."
        )
    if human > 0:
        steps.append(
            f"<strong>Week 1:</strong> address the <strong>{human} workload-specific gap{'s' if human != 1 else ''}</strong> that need a threshold or SLO defined (function-timeout %, query latency target, etc.). AlarmFabric collects the inputs once, then creates the alarms."
        )

    if not steps:
        # Fallback to the original score-banded copy when breakdown is empty
        if score >= 60:
            steps.append(
                f"Address the <strong>{required_missing} required gaps</strong> highlighted above. Each one is a class of incident currently invisible to your on-call."
            )
        else:
            steps.append(
                f"<strong>Immediate priority:</strong> {required_missing} required alarm checks are missing across {critical_resources} resources. The team is operating without baseline visibility on these workloads."
            )

    # Cap technical steps at two so a directive call-to-action always lands
    # last — the eye reads the final bullet as the action to take.
    steps = steps[:2]
    if score < 90:
        steps.append(
            "<strong>Want OpsFabric to close these gaps for you?</strong> Visit <code>opsfabric.ai</code> or email <code>founders@opsfabric.ai</code> with this report attached — typical turnaround is one engineering day for a fleet this size. AlarmFabric applies the alarms via a read-only role you create and revoke; your data never leaves your AWS account during the audit."
        )
    return steps


def _render_html(context: dict[str, Any]) -> str:
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        autoescape=select_autoescape(["html"]),
    )
    template = env.get_template(_TEMPLATE_NAME)
    css_text = (_TEMPLATE_DIR / _CSS_NAME).read_text(encoding="utf-8")
    return template.render(inline_css=css_text, **context)


def render_audit_pdf(
    *,
    account_meta: AccountMeta,
    coverage_summary: dict[str, Any],
    coverage_resources: list[dict[str, Any]],
    demo_mode: bool = False,
) -> bytes:
    """Render the executive PDF and return its bytes.

    The caller is responsible for writing to disk; we keep this pure so it's
    easy to test and so the audit CLI can stream the bytes wherever needed.

    `demo_mode` adds a clear banner at the top of the report so a viewer
    can't mistake the synthetic dataset for a real audit of their account.
    """
    resources_scored = int(coverage_summary.get("resource_count_scored", 0))
    required_total = int(coverage_summary.get("required_checks_total", 0))
    required_met = int(coverage_summary.get("required_checks_met", 0))
    score = float(coverage_summary.get("required_coverage_score_pct", 0.0))
    required_missing = max(0, required_total - required_met)

    scoreable = resources_scored > 0 and required_total > 0

    if scoreable:
        score_int = int(round(score))
        grade_letter, grade_label, grade_class, headline_class = _grade(score)
    else:
        score_int = 0
        grade_letter, grade_label, grade_class, headline_class = ("—", "Not scoreable", "warn", "warn")

    critical_gaps, total_gaps = _build_critical_gaps(coverage_resources)
    more_gaps_count = max(0, total_gaps - len(critical_gaps))
    coverage_by_kind = _build_coverage_by_kind(coverage_resources)
    critical_resources = sum(
        1 for r in coverage_resources if int(r.get("required_total", 0)) > int(r.get("required_met", 0))
    )
    p1_gap_count = sum(
        1
        for r in coverage_resources
        for c in r.get("checks", [])
        if c.get("status") == "MISSING"
        and c.get("required")
        and (c.get("severity") or "").upper() == "P1"
    )

    if scoreable:
        if score >= 75:
            headline = f"This account is at or above the industry baseline ({INDUSTRY_BASELINE}/100) for alarm coverage."
            headline_sub = f"{required_met} of {required_total} required checks are in place across {resources_scored} resources. Maintain coverage as new workloads are deployed."
        elif score >= 40:
            headline = f"Coverage is below the industry baseline ({INDUSTRY_BASELINE}/100). {required_missing} required checks are missing."
            headline_sub = "Each gap is a class of incident the on-call team currently cannot detect until a customer reports it. Top gaps are listed below."
        else:
            headline = f"Coverage is critically below baseline. {required_missing} of {required_total} required checks are missing."
            headline_sub = "This account is operating without the alarm signal needed to detect classes of failure that cause customer-visible outages. Immediate remediation is recommended."
    else:
        headline = "No scoreable resources detected in scanned regions."
        headline_sub = "DiscoveryFabric's baseline pack covers ECS services, Lambda functions, RDS / Aurora instances and clusters, and SQS queues. None were found in this account's Resource Explorer index for the regions scanned."

    breakdown = _remediation_breakdown(coverage_resources)
    auto_fixable = breakdown["auto_fixable"]
    human_guided = breakdown["human_guided"]
    degraded_count = breakdown["degraded"]

    # Single-line summary of the remediation path, rendered as a callout
    # under the hero. Concrete numbers > generic copy.
    if scoreable and required_missing > 0:
        parts: list[str] = []
        if auto_fixable > 0:
            parts.append(
                f"<strong>{auto_fixable}</strong> can be auto-created via AlarmFabric (no input required)"
            )
        if human_guided > 0:
            parts.append(
                f"<strong>{human_guided}</strong> need workload-specific input (threshold / SLO)"
            )
        if degraded_count > 0:
            parts.append(
                f"<strong>{degraded_count}</strong> existing alarm(s) need to be enabled or have an SNS target attached"
            )
        remediation_callout = "Of the {n} required gaps: {body}.".format(
            n=required_missing, body="; ".join(parts)
        ) if parts else ""
    else:
        remediation_callout = ""

    next_steps = _build_recommendations(
        score, required_missing, coverage_resources, breakdown
    )

    account_label = account_meta.account_id
    if account_meta.account_alias and account_meta.account_alias != account_meta.account_id:
        account_label = f"{account_meta.account_alias} ({account_meta.account_id})"

    # Customer-facing line surfaced in the title block so the buyer sees their
    # name on page 1, not just an account number. Falls back to a generic
    # phrasing if the operator didn't supply --account-alias.
    prepared_for = account_meta.account_alias or f"AWS account {account_meta.account_id}"

    context = {
        "account_label": account_label,
        "scanned_at_utc": account_meta.scanned_at_utc,
        "regions_scanned": account_meta.regions_scanned,
        "regions_skipped": account_meta.regions_skipped,
        "scoped_kinds": "ECS, Lambda, RDS, Aurora, and SQS",
        "scoreable": scoreable,
        "score_int": score_int,
        "grade_letter": grade_letter,
        "grade_label": grade_label,
        "grade_class": grade_class,
        "headline": headline,
        "headline_sub": headline_sub,
        "headline_class": headline_class,
        "resources_scored": resources_scored,
        "required_missing": required_missing,
        "critical_resources": critical_resources,
        "p1_gap_count": p1_gap_count,
        "critical_gaps": critical_gaps,
        "more_gaps_count": more_gaps_count,
        "coverage_by_kind": coverage_by_kind,
        "next_steps": next_steps,
        "industry_baseline": INDUSTRY_BASELINE,
        "remediation_callout": remediation_callout,
        "auto_fixable": auto_fixable,
        "human_guided_required": human_guided,
        "degraded_required": degraded_count,
        "prepared_for": prepared_for,
        "demo_mode": demo_mode,
    }

    html_text = _render_html(context)
    # base_url tells WeasyPrint where to resolve relative paths (none today,
    # but this lets us add logos/images later without rewriting the call).
    return HTML(string=html_text, base_url=str(_TEMPLATE_DIR)).write_pdf()


def write_audit_pdf(
    path: str | Path,
    *,
    account_meta: AccountMeta,
    coverage_summary: dict[str, Any],
    coverage_resources: list[dict[str, Any]],
    demo_mode: bool = False,
) -> None:
    pdf_bytes = render_audit_pdf(
        account_meta=account_meta,
        coverage_summary=coverage_summary,
        coverage_resources=coverage_resources,
        demo_mode=demo_mode,
    )
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(pdf_bytes)
