"""Output helpers for terminal and files."""

