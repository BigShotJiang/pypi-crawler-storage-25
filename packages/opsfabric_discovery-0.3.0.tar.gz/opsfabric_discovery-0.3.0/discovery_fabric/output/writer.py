from __future__ import annotations

import csv
import json
import os
from typing import Any


def _str_or_empty(value: Any) -> str:
    """Coerce a record field to a display-safe string. None/absent → ''."""
    return str(value) if value is not None else ""


def _ensure_parent(path: str) -> None:
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)


def write_json(path: str, records: list[dict[str, Any]]) -> None:
    _ensure_parent(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, default=str)


def write_csv(path: str, records: list[dict[str, Any]]) -> None:
    _ensure_parent(path)
    fieldnames = [
        "arn",
        "service",
        "resource_type",
        "region",
        "account_id",
        "last_reported_at",
    ]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            row = {key: record.get(key) for key in fieldnames}
            writer.writerow(row)


def sort_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sort records by region -> service -> resource_type -> arn."""

    def _key(record: dict[str, Any]) -> tuple[str, str, str, str]:
        return (
            _str_or_empty(record.get("region")),
            _str_or_empty(record.get("service")),
            _str_or_empty(record.get("resource_type")),
            _str_or_empty(record.get("arn")),
        )

    return sorted(records, key=_key)


def render_table(records: list[dict[str, Any]], max_rows: int = 200) -> str:
    if not records:
        return "No resources found."

    rows = []
    for item in records[:max_rows]:
        if isinstance(item, dict):
            rows.append(item)
        else:
            rows.append({"arn": str(item)})
    headers = ["service", "resource_type", "region", "account_id", "arn"]

    widths: dict[str, int] = {}
    for header in headers:
        widths[header] = len(header)
    for row in rows:
        for header in headers:
            value = str(row.get(header, ""))
            widths[header] = max(widths[header], len(value))

    def fmt_row(values: list[str]) -> str:
        parts = []
        for i, header in enumerate(headers):
            parts.append(values[i].ljust(widths[header]))
        return " | ".join(parts)

    lines: list[str] = []
    lines.append(fmt_row(headers))
    lines.append("-+-".join("-" * widths[h] for h in headers))
    for row in rows:
        vals = [str(row.get(h, "")) for h in headers]
        lines.append(fmt_row(vals))

    if len(records) > max_rows:
        lines.append(
            f"... showing first {max_rows} of {len(records)} resources. Use --limit or --save for full output."
        )
    else:
        lines.append(f"Total resources: {len(records)}")

    return "\n".join(lines)


def render_grouped_table(records: list[dict[str, Any]], max_rows: int = 1000) -> str:
    if not records:
        return "No resources found."

    sorted_records = sort_records(records)
    rows = sorted_records[:max_rows]

    lines: list[str] = []
    current_group: tuple[str, str] | None = None
    group_count = 0

    for row in rows:
        # Display-layer fallback: a record without region/service is grouped under
        # an explicit "unknown-*" bucket so the table renders. Preserves visibility
        # of malformed records instead of silently dropping them.
        region_raw = row.get("region")
        service_raw = row.get("service")
        region = str(region_raw) if region_raw is not None else "unknown-region"
        service = str(service_raw) if service_raw is not None else "unknown-service"
        group = (region, service)

        if group != current_group:
            if current_group is not None:
                lines.append(f"  Group total: {group_count}")
                lines.append("")
            lines.append(f"Region: {region} | Service: {service}")
            lines.append("-" * 80)
            current_group = group
            group_count = 0

        resource_type = _str_or_empty(row.get("resource_type"))
        arn = _str_or_empty(row.get("arn"))
        lines.append(f"- {resource_type} | {arn}")
        group_count += 1

    if current_group is not None:
        lines.append(f"  Group total: {group_count}")

    if len(sorted_records) > max_rows:
        lines.append("")
        lines.append(
            f"... showing first {max_rows} of {len(sorted_records)} resources. Use --limit or --save for full output."
        )
    else:
        lines.append("")
        lines.append(f"Total resources: {len(sorted_records)}")

    return "\n".join(lines)
