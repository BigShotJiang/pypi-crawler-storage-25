from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import replace as dataclass_replace
from datetime import UTC, datetime
from pathlib import Path

from discovery_fabric.aws.alarm_coverage import score_alarm_coverage
from discovery_fabric.aws.mapping import build_resource_mapping
from discovery_fabric.aws.resource_explorer import (
    DiscoveryError,
    discover_resources,
    validate_aws_identity,
)
from discovery_fabric.config import (
    DEFAULT_ASSUME_ROLE_DURATION,
    Settings,
    assume_role_credentials,
    settings_from_cli,
)
from discovery_fabric.output.writer import (
    render_grouped_table,
    render_table,
    sort_records,
    write_csv,
    write_json,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="opsfabric-discovery",
        description="Open-source AWS reliability audit. Read-only, runs on your laptop.",
    )
    parser.add_argument(
        "--about",
        action="store_true",
        help=(
            "Print OpsFabric product context (DiscoveryFabric / AlarmFabric / "
            "OpsFabric) and exit. Use this to learn where this OSS tool fits in "
            "the broader OpsFabric reliability platform."
        ),
    )
    subparsers = parser.add_subparsers(dest="command")

    discover = subparsers.add_parser(
        "discover", help="Discover resources in your AWS account."
    )
    discover.add_argument(
        "--query",
        default="",
        help="Resource Explorer query string, e.g. 'service:ec2 region:ca-central-1'.",
    )
    discover.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Maximum number of resources to return.",
    )
    discover.add_argument(
        "--output",
        choices=["table", "json", "csv"],
        default="table",
        help="Terminal output format.",
    )
    discover.add_argument(
        "--save",
        default=None,
        help="Optional path to save output (.json or .csv recommended).",
    )
    discover.add_argument(
        "--profile",
        default=None,
        help="AWS profile override (defaults to AWS_PROFILE env/default chain).",
    )
    discover.add_argument(
        "--region",
        default=None,
        help="AWS region override used for Resource Explorer client/view discovery.",
    )
    discover.add_argument(
        "--regions",
        default=None,
        help="AWS regions: 'all' for every opted-in region in the account, or comma-separated (e.g. ca-central-1,us-east-1).",
    )
    discover.add_argument(
        "--view-arn",
        default=None,
        help="Explicit Resource Explorer view ARN. If omitted, auto-selects default/first view.",
    )
    _add_assume_role_args(discover)
    discover.add_argument(
        "--verbose",
        action="store_true",
        help="Print additional metadata (identity and selected view).",
    )
    discover.add_argument(
        "--grouped",
        action="store_true",
        help="Render terminal output grouped by region and service.",
    )

    map_cmd = subparsers.add_parser(
        "map",
        help="Generate resource list and mapping (ECS service -> log group -> CloudWatch alarms).",
    )
    map_cmd.add_argument(
        "--query",
        default="",
        help="Optional Resource Explorer query to scope discovery before mapping.",
    )
    map_cmd.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional max resources to discover before mapping.",
    )
    map_cmd.add_argument("--profile", default=None, help="AWS profile override.")
    map_cmd.add_argument("--region", default=None, help="AWS region override.")
    map_cmd.add_argument(
        "--regions",
        default=None,
        help="AWS regions: 'all' for every opted-in region in the account, or comma-separated (e.g. ca-central-1,us-east-1).",
    )
    map_cmd.add_argument("--view-arn", default=None, help="Explicit Resource Explorer view ARN.")
    _add_assume_role_args(map_cmd)
    map_cmd.add_argument(
        "--resources-save",
        default="out/all-resources.json",
        help="Where to save discovered resources JSON.",
    )
    map_cmd.add_argument(
        "--mapping-save",
        default="out/resource-mapping.json",
        help="Where to save mapping JSON.",
    )
    map_cmd.add_argument(
        "--mapping-text-save",
        default="out/resource-mapping.txt",
        help="Where to save human-readable mapping text.",
    )
    map_cmd.add_argument(
        "--verbose",
        action="store_true",
        help="Print additional metadata (identity and selected view).",
    )

    score_cmd = subparsers.add_parser(
        "score",
        help="Score alarm coverage pack for ECS, Lambda, and RDS resources.",
    )
    score_cmd.add_argument("--query", default="", help="Optional Resource Explorer query scope.")
    score_cmd.add_argument("--limit", type=int, default=None, help="Optional max resources.")
    score_cmd.add_argument("--profile", default=None, help="AWS profile override.")
    score_cmd.add_argument("--region", default=None, help="AWS region override.")
    score_cmd.add_argument(
        "--regions",
        default=None,
        help="AWS regions: 'all' for every opted-in region in the account, or comma-separated (e.g. ca-central-1,us-east-1).",
    )
    score_cmd.add_argument("--view-arn", default=None, help="Explicit Resource Explorer view ARN.")
    _add_assume_role_args(score_cmd)
    score_cmd.add_argument(
        "--resources-save",
        default="out/all-resources.json",
        help="Where to save discovered resources JSON.",
    )
    score_cmd.add_argument(
        "--score-save",
        default="out/alarm-coverage-score.json",
        help="Where to save coverage score JSON.",
    )
    score_cmd.add_argument(
        "--score-text-save",
        default="out/alarm-coverage-score.txt",
        help="Where to save coverage text report.",
    )
    score_cmd.add_argument(
        "--missing-save",
        default="out/alarm-coverage-missing.json",
        help="Where to save missing checks JSON.",
    )
    score_cmd.add_argument(
        "--missing-text-save",
        default="out/alarm-coverage-missing.txt",
        help="Where to save missing checks text report.",
    )
    score_cmd.add_argument(
        "--exec-save",
        default="out/alarm-coverage-executive-summary.json",
        help="Where to save executive summary JSON.",
    )
    score_cmd.add_argument(
        "--exec-text-save",
        default="out/alarm-coverage-executive-summary.txt",
        help="Where to save executive summary text report.",
    )
    score_cmd.add_argument(
        "--verbose",
        action="store_true",
        help="Print additional metadata (identity and selected view).",
    )

    changes_cmd = subparsers.add_parser(
        "changes",
        help="Detect per-run resource changes and recommend alarms for newly created resources.",
    )
    changes_cmd.add_argument("--query", default="", help="Optional Resource Explorer query scope.")
    changes_cmd.add_argument("--limit", type=int, default=None, help="Optional max resources.")
    changes_cmd.add_argument("--profile", default=None, help="AWS profile override.")
    changes_cmd.add_argument("--region", default=None, help="AWS region override.")
    changes_cmd.add_argument(
        "--regions",
        default=None,
        help="AWS regions: 'all' for every opted-in region in the account, or comma-separated (e.g. ca-central-1,us-east-1).",
    )
    changes_cmd.add_argument("--view-arn", default=None, help="Explicit Resource Explorer view ARN.")
    _add_assume_role_args(changes_cmd)
    changes_cmd.add_argument(
        "--state-dir",
        default="state",
        help="Directory to persist account-scoped snapshots.",
    )
    changes_cmd.add_argument(
        "--delta-save",
        default="out/new-resource-delta.json",
        help="Where to save run delta JSON.",
    )
    changes_cmd.add_argument(
        "--delta-text-save",
        default="out/new-resource-delta.txt",
        help="Where to save run delta text report.",
    )
    changes_cmd.add_argument(
        "--recommend-save",
        default="out/new-resource-alarm-recommendations.json",
        help="Where to save alarm recommendations JSON for new resources.",
    )
    changes_cmd.add_argument(
        "--recommend-text-save",
        default="out/new-resource-alarm-recommendations.txt",
        help="Where to save alarm recommendations text report.",
    )
    changes_cmd.add_argument(
        "--verbose",
        action="store_true",
        help="Print additional metadata (identity and selected view).",
    )

    audit_cmd = subparsers.add_parser(
        "audit",
        help="One-shot customer audit: discover, score, and render the executive PDF.",
    )
    audit_cmd.add_argument("--query", default="", help="Optional Resource Explorer query scope.")
    audit_cmd.add_argument("--limit", type=int, default=None, help="Optional max resources.")
    audit_cmd.add_argument("--profile", default=None, help="AWS profile override.")
    audit_cmd.add_argument("--region", default=None, help="AWS region override (used when --regions is not 'all').")
    audit_cmd.add_argument(
        "--regions",
        default="all",
        help="AWS regions: 'all' (default) for every opted-in region, or comma-separated (e.g. ca-central-1,us-east-1).",
    )
    audit_cmd.add_argument("--view-arn", default=None, help="Explicit Resource Explorer view ARN.")
    _add_assume_role_args(audit_cmd)
    audit_cmd.add_argument(
        "--output-dir",
        default="out",
        help="Directory for all audit artifacts (JSON exports + the PDF).",
    )
    audit_cmd.add_argument(
        "--pdf-out",
        default=None,
        help="PDF path (defaults to <output-dir>/audit-<account_id>-<UTC_date>.pdf).",
    )
    audit_cmd.add_argument(
        "--account-alias",
        default=None,
        help="Optional human-friendly account label printed in the PDF (e.g. 'acme-prod').",
    )
    audit_cmd.add_argument(
        "--demo",
        action="store_true",
        help=(
            "Run against a baked-in synthetic dataset instead of AWS. Produces "
            "a representative PDF with no AWS credentials needed — useful for "
            "evaluating the tool before pointing it at a real account."
        ),
    )
    audit_cmd.add_argument(
        "--verbose",
        action="store_true",
        help="Print additional metadata (identity, view, skipped regions).",
    )

    return parser


def _print_output(output_format: str, records: list[dict], grouped: bool = False) -> None:
    if output_format == "table":
        if grouped:
            print(render_grouped_table(records))
        else:
            print(render_table(records))
    elif output_format == "json":
        print(json.dumps(records, indent=2, default=str))
    elif output_format == "csv":
        # CSV is mainly for --save; terminal preview keeps it readable.
        print(render_table(records))
    else:
        raise ValueError(f"Unsupported output format: {output_format}")


def _add_assume_role_args(p) -> None:
    """Register cross-account auth flags consistently across subcommands."""
    p.add_argument(
        "--assume-role-arn",
        default=None,
        help=(
            "IAM role ARN to assume in the target account before running. "
            "Required for cross-account audits; the base credentials only need sts:AssumeRole on this role."
        ),
    )
    p.add_argument(
        "--external-id",
        default=None,
        help="External ID required by the assume-role trust policy (recommended for customer accounts).",
    )
    p.add_argument(
        "--session-duration",
        type=int,
        default=DEFAULT_ASSUME_ROLE_DURATION,
        help=(
            "STS session duration in seconds (default 3600). "
            "Must not exceed the role's MaxSessionDuration."
        ),
    )


REGIONS_ALL_SENTINEL = "all"


def _parse_regions(regions_value: str | None) -> list[str]:
    if not regions_value:
        return []
    out = []
    for item in regions_value.split(","):
        v = item.strip()
        if v:
            out.append(v)
    return out


def _list_enabled_regions(settings: Settings) -> list[str]:
    """Return all opted-in AWS regions for the account.

    AllRegions=False filters out regions disabled by the account (opt-in
    regions like ap-east-1, me-central-1, etc.). EC2 describe_regions is
    available globally; we anchor it on us-east-1 since every account has it.
    """
    from discovery_fabric.config import make_boto3_client

    ec2 = make_boto3_client(settings, "ec2", region="us-east-1")
    response = ec2.describe_regions(AllRegions=False)
    regions = sorted(r["RegionName"] for r in response.get("Regions", []) if r.get("RegionName"))
    return regions


def _resolve_regions(settings: Settings, regions_value: str | None) -> list[str]:
    """Translate the --regions CLI value into a concrete region list.

    - None / empty → [] (caller falls back to single-region path)
    - 'all' → describe_regions(AllRegions=False) for the resolved identity
    - 'a,b,c' → split-and-trim list
    """
    if regions_value and regions_value.strip().lower() == REGIONS_ALL_SENTINEL:
        return _list_enabled_regions(settings)
    return _parse_regions(regions_value)


def _merge_query_with_region(query: str, region: str) -> str:
    q = (query or "").strip()
    if not q:
        return f"region:{region}"
    return f"{q} region:{region}"


def _discover_records_for_regions(base_settings, query: str, limit: int | None, regions: list[str]):
    if not regions:
        result = discover_resources(settings=base_settings, query_string=query, limit=limit)
        return result.records, [result.view_arn], []

    all_records: list[dict] = []
    views: list[str] = []
    seen_arns: set[str] = set()
    skipped: list[dict] = []

    for region in regions:
        # Preserve the resolved credentials (including STS temp creds from
        # AssumeRole) by replacing only the region. settings_from_cli would
        # drop temp creds because env vars aren't repopulated.
        regional_settings = dataclass_replace(base_settings, aws_region=region)
        regional_query = _merge_query_with_region(query, region)
        try:
            result = discover_resources(
                settings=regional_settings, query_string=regional_query, limit=limit
            )
        except DiscoveryError as exc:
            # Common cause: Resource Explorer 2 not enabled in this region, or
            # IAM gap. Skipping a region produces an incomplete audit but a
            # complete deliverable; aborting produces nothing. We prefer the
            # former and surface the skip in stderr so it's visible.
            print(
                f"warning: skipping region {region}: {exc}",
                file=sys.stderr,
            )
            skipped.append({"region": region, "reason": str(exc)})
            continue
        views.append(result.view_arn)
        for rec in result.records:
            arn = rec.get("arn")
            if isinstance(arn, str) and arn in seen_arns:
                continue
            if isinstance(arn, str):
                seen_arns.add(arn)
            all_records.append(rec)

    return all_records, views, skipped


def _build_executive_summary(coverage_summary: dict, coverage_resources: list[dict], missing: list[dict]) -> tuple[dict, str]:
    by_kind: dict[str, dict[str, int | float]] = {}
    for resource in coverage_resources:
        kind = resource["resource_kind"]
        agg = by_kind.setdefault(
            kind,
            {
                "resource_count": 0,
                "required_total": 0,
                "required_met": 0,
                "required_coverage_score_pct": 0.0,
            },
        )
        agg["resource_count"] = int(agg["resource_count"]) + 1
        agg["required_total"] = int(agg["required_total"]) + int(resource["required_total"])
        agg["required_met"] = int(agg["required_met"]) + int(resource["required_met"])

    for kind, agg in by_kind.items():
        required_total = int(agg["required_total"])
        required_met = int(agg["required_met"])
        agg["required_coverage_score_pct"] = (
            round((required_met / required_total) * 100, 2) if required_total else 100.0
        )
        by_kind[kind] = agg

    missing_check_counter: dict[str, int] = {}
    for item in missing:
        for check in item["missing_required_checks"]:
            check_id = check["check_id"]
            missing_check_counter[check_id] = missing_check_counter.get(check_id, 0) + 1

    top_missing_checks = sorted(
        [{"check_id": k, "missing_count": v} for k, v in missing_check_counter.items()],
        key=lambda x: (-x["missing_count"], x["check_id"]),
    )[:10]

    payload = {
        "overall_required_coverage_score_pct": coverage_summary["required_coverage_score_pct"],
        "required_checks_met": coverage_summary["required_checks_met"],
        "required_checks_total": coverage_summary["required_checks_total"],
        "resources_scored": coverage_summary["resource_count_scored"],
        "resources_with_missing_required_checks": len(missing),
        "coverage_by_resource_kind": by_kind,
        "top_missing_required_checks": top_missing_checks,
    }

    lines = []
    lines.append("Executive Summary: Alarm Coverage (ECS/Lambda/RDS)")
    lines.append("=" * 72)
    lines.append(
        "Overall required coverage: "
        f"{coverage_summary['required_coverage_score_pct']}% "
        f"({coverage_summary['required_checks_met']}/{coverage_summary['required_checks_total']})"
    )
    lines.append(f"Resources scored: {coverage_summary['resource_count_scored']}")
    lines.append(f"Resources missing >=1 required check: {len(missing)}")
    lines.append("")
    lines.append("Coverage by resource kind:")
    for kind in sorted(by_kind.keys()):
        agg = by_kind[kind]
        lines.append(
            f"- {kind}: {agg['required_coverage_score_pct']}% "
            f"({agg['required_met']}/{agg['required_total']}) across {agg['resource_count']} resources"
        )
    lines.append("")
    lines.append("Top missing required checks:")
    if top_missing_checks:
        for item in top_missing_checks:
            lines.append(f"- {item['check_id']}: missing on {item['missing_count']} resource(s)")
    else:
        lines.append("- none")

    return payload, "\n".join(lines)


def _state_scope_key(regions: list[str], query: str, limit: int | None) -> str:
    scope = {
        "regions": sorted(regions),
        "query": (query or "").strip(),
        "limit": limit,
    }
    raw = json.dumps(scope, sort_keys=True)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def _build_state_paths(state_dir: str, account_id: str, scope_key: str) -> tuple[Path, Path]:
    root = Path(state_dir) / account_id / scope_key
    snapshot_path = root / "last_resources.json"
    meta_path = root / "last_run_meta.json"
    return snapshot_path, meta_path


def _index_by_arn(records: list[dict]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for rec in records:
        arn = rec.get("arn")
        if isinstance(arn, str) and arn:
            out[arn] = rec
    return out


def _compute_delta(previous: list[dict], current: list[dict]) -> dict:
    prev_idx = _index_by_arn(previous)
    curr_idx = _index_by_arn(current)

    prev_arns = set(prev_idx.keys())
    curr_arns = set(curr_idx.keys())

    new_arns = sorted(curr_arns - prev_arns)
    deleted_arns = sorted(prev_arns - curr_arns)
    unchanged_arns = sorted(curr_arns.intersection(prev_arns))

    return {
        "new_resources": [curr_idx[a] for a in new_arns],
        "deleted_resources": [prev_idx[a] for a in deleted_arns],
        "unchanged_resources": [curr_idx[a] for a in unchanged_arns],
        "counts": {
            "new": len(new_arns),
            "deleted": len(deleted_arns),
            "unchanged": len(unchanged_arns),
            "current_total": len(current),
            "previous_total": len(previous),
        },
    }


def _build_new_resource_recommendations(settings, current_records: list[dict], new_records: list[dict]) -> dict:
    new_arns = {r.get("arn") for r in new_records if isinstance(r.get("arn"), str)}
    if not new_arns:
        return {
            "summary": {
                "new_resources_scored": 0,
                "required_missing": 0,
                "optional_missing": 0,
                "auto_candidates": 0,
                "human_guided_candidates": 0,
            },
            "resources": [],
        }

    coverage = score_alarm_coverage(settings=settings, records=current_records)
    resources = [r for r in coverage.resources if r.get("resource_arn") in new_arns]

    required_missing = 0
    optional_missing = 0
    auto_candidates = 0
    human_guided_candidates = 0
    payload_resources: list[dict] = []

    for resource in resources:
        proposed = []
        for check in resource.get("checks", []):
            if check.get("status") != "MISSING":
                continue
            item = {
                "check_id": check.get("check_id"),
                "title": check.get("title"),
                "required": bool(check.get("required", True)),
                "domain": check.get("domain", "infra"),
                "mode": check.get("mode", "auto"),
                "severity": check.get("severity", "P3"),
                "needs_input": check.get("needs_input", []),
            }
            proposed.append(item)
            if item["required"]:
                required_missing += 1
            else:
                optional_missing += 1
            if item["mode"] == "auto":
                auto_candidates += 1
            else:
                human_guided_candidates += 1

        payload_resources.append(
            {
                "resource_kind": resource.get("resource_kind"),
                "region": resource.get("region"),
                "resource_name": resource.get("resource_name"),
                "resource_arn": resource.get("resource_arn"),
                "proposed_alarms": proposed,
            }
        )

    return {
        "summary": {
            "new_resources_scored": len(resources),
            "required_missing": required_missing,
            "optional_missing": optional_missing,
            "auto_candidates": auto_candidates,
            "human_guided_candidates": human_guided_candidates,
        },
        "resources": payload_resources,
    }


def _render_delta_text(delta: dict) -> str:
    lines = []
    lines.append("Resource Change Delta")
    lines.append("=" * 72)
    c = delta["counts"]
    lines.append(
        f"Current total: {c['current_total']} | Previous total: {c['previous_total']} | "
        f"New: {c['new']} | Deleted: {c['deleted']} | Unchanged: {c['unchanged']}"
    )
    lines.append("")

    lines.append("New Resources:")
    if delta["new_resources"]:
        for rec in delta["new_resources"]:
            lines.append(
                f"- [{rec.get('region')}] {rec.get('service')} {rec.get('resource_type')} | {rec.get('arn')}"
            )
    else:
        lines.append("- none")
    lines.append("")

    lines.append("Deleted Resources:")
    if delta["deleted_resources"]:
        for rec in delta["deleted_resources"]:
            lines.append(
                f"- [{rec.get('region')}] {rec.get('service')} {rec.get('resource_type')} | {rec.get('arn')}"
            )
    else:
        lines.append("- none")
    return "\n".join(lines)


def _render_recommendations_text(recommendations: dict) -> str:
    lines = []
    lines.append("Alarm Recommendations For Newly Created Resources")
    lines.append("=" * 72)
    s = recommendations["summary"]
    lines.append(
        f"New resources scored: {s['new_resources_scored']} | "
        f"Required missing: {s['required_missing']} | Optional missing: {s['optional_missing']}"
    )
    lines.append(
        f"Auto candidates: {s['auto_candidates']} | Human-guided candidates: {s['human_guided_candidates']}"
    )
    lines.append("")
    for r in recommendations["resources"]:
        lines.append(
            f"[{r['region']}] {r['resource_kind']} {r['resource_name']} ({r['resource_arn']})"
        )
        if r["proposed_alarms"]:
            for p in r["proposed_alarms"]:
                req = "required" if p["required"] else "optional"
                lines.append(
                    f"  - {p['check_id']} | {p['title']} | {req} | domain={p['domain']} | mode={p['mode']}"
                )
        else:
            lines.append("  - no missing alarms from pack")
        lines.append("")
    if not recommendations["resources"]:
        lines.append("No new pack-scored resources found in this run.")
    return "\n".join(lines)


def _run_demo_audit(args) -> int:
    """Render the demo PDF from the baked-in synthetic dataset.

    No AWS calls. The dataset lives at <project>/data/demo_score.json (or
    inside the package after pip install) and was produced by
    scripts/build_demo_data.py. Anyone running this offline gets the same
    PDF a stranger would see — the only difference vs a real audit is the
    data source.
    """
    from discovery_fabric.output.pdf_report import AccountMeta, write_audit_pdf

    demo_path = Path(__file__).resolve().parent / "data" / "demo_score.json"
    if not demo_path.exists():
        # Inside the installed package the data dir is a sibling of cli.py
        # rather than a sibling of this module. Try the alternate path.
        alt = Path(__file__).resolve().parent / "discovery_fabric" / "data" / "demo_score.json"
        demo_path = alt if alt.exists() else demo_path
    if not demo_path.exists():
        print(
            f"discovery-fabric error: demo dataset not found at {demo_path}. "
            "Run scripts/build_demo_data.py to regenerate it.",
            file=sys.stderr,
        )
        return 2

    payload = json.loads(demo_path.read_text(encoding="utf-8"))

    output_dir = Path(getattr(args, "output_dir", None) or "out")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Persist the demo JSON artifacts so the developer-facing tabs / Streamlit
    # / Next.js UI all see consistent data when they read out/*.json after a
    # demo run. This makes the demo experience match the real one even in
    # supporting tools.
    write_json(str(output_dir / "all-resources.json"), [])
    write_json(
        str(output_dir / "alarm-coverage-score.json"),
        {"summary": payload["summary"], "resources": payload["resources"]},
    )
    missing = []
    for r in payload["resources"]:
        miss = [c for c in r["checks"] if c.get("required") and c.get("status") in ("MISSING", "DEGRADED")]
        if miss:
            missing.append(
                {
                    "resource_kind": r["resource_kind"],
                    "region": r["region"],
                    "resource_name": r["resource_name"],
                    "resource_arn": r["resource_arn"],
                    "missing_required_checks": miss,
                }
            )
    write_json(str(output_dir / "alarm-coverage-missing.json"), {"missing_resources": missing, "count": len(missing)})

    scanned_at = datetime.now(UTC).strftime("%Y-%m-%d %H:%M")
    account_id = str(payload["account_id"])
    # CLI flag overrides the baked-in alias so the demo PDF can show the
    # caller's brand instead of the default if they want.
    account_alias = getattr(args, "account_alias", None) or payload.get("account_alias")

    write_json(
        str(output_dir / "audit-meta.json"),
        {
            "account_id": account_id,
            "account_alias": account_alias,
            "scanned_at_utc": scanned_at,
            "regions_scanned": payload.get("regions_scanned") or [],
            "regions_skipped": payload.get("regions_skipped") or [],
            "demo": True,
        },
    )

    pdf_out = getattr(args, "pdf_out", None)
    pdf_path = Path(pdf_out) if pdf_out else output_dir / "audit-demo.pdf"

    account_meta = AccountMeta(
        account_id=account_id,
        account_alias=account_alias,
        scanned_at_utc=scanned_at,
        regions_scanned=list(payload.get("regions_scanned") or []),
        regions_skipped=list(payload.get("regions_skipped") or []),
    )
    write_audit_pdf(
        str(pdf_path),
        account_meta=account_meta,
        coverage_summary=payload["summary"],
        coverage_resources=payload["resources"],
        demo_mode=True,
    )

    print("")
    print("Demo audit complete (synthetic data — no AWS calls were made).")
    print(f"  Account:        {account_id} ({account_alias})")
    print(f"  Regions scored: {len(payload.get('regions_scanned') or [])}")
    print(
        f"  Coverage:       {payload['summary']['required_coverage_score_pct']}% "
        f"({payload['summary']['required_checks_met']}/{payload['summary']['required_checks_total']} required checks)"
    )
    print(f"  Resources:      {payload['summary']['resource_count_scored']} scored")
    print("")
    print(f"  PDF report:     {pdf_path}")
    print("")
    print("To run a real audit against your own AWS account:")
    print("  opsfabric-discovery audit --profile <your-profile> --regions all")
    return 0


_ABOUT_TEXT = """\
opsfabric-discovery — Open-source AWS reliability audit.

DiscoveryFabric is the open layer of the OpsFabric reliability platform:

  DiscoveryFabric (this tool, MIT)  -> tells you what alarms are missing
  AlarmFabric (paid SaaS)           -> creates the missing alarms in your account
  OpsFabric (paid SaaS)             -> handles the incidents when they fire

Quick start:
  opsfabric-discovery audit --demo                   (no AWS access required)
  opsfabric-discovery audit --profile <name> --regions all

About the paid products: https://opsfabric.ai/
Feature comparison:      https://github.com/OpsFabric/opsfabric-discovery-pkg/blob/main/docs/comparison.md
Commercial questions:    founders@opsfabric.ai
Bug reports / PRs:       https://github.com/OpsFabric/opsfabric-discovery-pkg
"""


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    # `--about` is the OpsFabric product-context surface — answer "what is
    # this tool a part of?" without requiring the user to scroll through the
    # README. Short-circuits before subcommand dispatch so it works whether
    # or not a subcommand was given.
    if getattr(args, "about", False):
        print(_ABOUT_TEXT)
        return 0

    # Allow `python main.py` (or bare `opsfabric-discovery`) to default to discover.
    if args.command is None:
        args = parser.parse_args(["discover"])

    # `audit --demo` short-circuits every AWS call. Load a baked-in synthetic
    # dataset and run it through the same scoring → PDF pipeline so a stranger
    # can evaluate the tool with no AWS credentials. Same matching strategies,
    # same rendering, same DEGRADED handling — only the input is fabricated.
    if args.command == "audit" and getattr(args, "demo", False):
        return _run_demo_audit(args)

    try:
        settings = settings_from_cli(
            profile=getattr(args, "profile", None),
            region=getattr(args, "region", None),
            view_arn=getattr(args, "view_arn", None),
            assume_role_arn=getattr(args, "assume_role_arn", None),
        )
        # Cross-account: exchange base creds for STS temp creds before any
        # other AWS call, so all downstream clients use the assumed role.
        if settings.assume_role_arn:
            settings = assume_role_credentials(
                settings,
                external_id=getattr(args, "external_id", None),
                duration_seconds=getattr(args, "session_duration", DEFAULT_ASSUME_ROLE_DURATION),
            )
        identity = validate_aws_identity(settings)
        regions = _resolve_regions(settings, getattr(args, "regions", None))
        records, views, skipped_regions = _discover_records_for_regions(
            base_settings=settings,
            query=args.query,
            limit=args.limit,
            regions=regions,
        )
        sorted_records = sort_records(records)

        if getattr(args, "verbose", False):
            print(f"AWS identity: account={identity['Account']} arn={identity['Arn']} user_id={identity['UserId']}")
            if len(views) == 1:
                print(f"Using Resource Explorer view: {views[0]}")
            elif len(views) > 1:
                print(f"Using Resource Explorer views ({len(views)}): {', '.join(views)}")
            else:
                print("No Resource Explorer views found in scanned regions.")
            if skipped_regions:
                print(f"Skipped {len(skipped_regions)} region(s) due to errors:")
                for s in skipped_regions:
                    print(f"  - {s['region']}: {s['reason']}")

        if args.command == "discover":
            _print_output(args.output, sorted_records, grouped=args.grouped)

            if args.save:
                if args.save.lower().endswith(".csv"):
                    write_csv(args.save, sorted_records)
                else:
                    write_json(args.save, sorted_records)
                print(f"\nSaved {len(sorted_records)} resource records to: {args.save}")
        elif args.command == "map":
            write_json(args.resources_save, sorted_records)
            mapping = build_resource_mapping(settings=settings, records=sorted_records)
            mapping_payload = {
                "resource_count": len(sorted_records),
                "resource_mapping_count": len(mapping.resource_mappings),
                "resource_mappings": mapping.resource_mappings,
                "unmapped_alarms": mapping.unmapped_alarms,
            }
            write_json(args.mapping_save, mapping_payload)

            lines = []
            lines.append("Resource -> Log Group -> CloudWatch Alarm Mapping")
            lines.append("=" * 72)
            lines.append("")
            for item in mapping.resource_mappings:
                lines.append(
                    f"Region: {item['region']} | Type: {item['resource_kind']} | Name: {item['resource_name']}"
                )
                lines.append(f"  Resource ARN: {item['resource_arn']}")
                metadata = item.get("metadata", {})
                if metadata.get("cluster_name"):
                    lines.append(f"  Cluster: {metadata['cluster_name']}")
                if metadata.get("task_definition_arn"):
                    lines.append(f"  Task Definition: {metadata['task_definition_arn']}")
                if item["log_groups"]:
                    lines.append("  Log Groups:")
                    for lg in item["log_groups"]:
                        lines.append(f"    - {lg}")
                else:
                    lines.append("  Log Groups: none detected")

                if item["cloudwatch_alarms"]:
                    lines.append("  CloudWatch Alarms:")
                    for alarm in item["cloudwatch_alarms"]:
                        reasons = ", ".join(alarm.get("reasons", []))
                        confidence = alarm.get("confidence", "UNKNOWN")
                        lines.append(
                            f"    - {alarm['alarm_name']} | confidence={confidence} | reasons={reasons}"
                        )
                else:
                    lines.append("  CloudWatch Alarms: none mapped")
                lines.append("")

            if mapping.unmapped_alarms:
                lines.append("Unmapped CloudWatch Alarms")
                lines.append("-" * 28)
                for alarm in mapping.unmapped_alarms:
                    lines.append(
                        f"- {alarm['alarm_name']} | {alarm['alarm_arn']} | region={alarm['region']}"
                    )
                lines.append("")

            lines.append(f"Total resources discovered: {len(sorted_records)}")
            lines.append(f"Resources mapped: {len(mapping.resource_mappings)}")
            lines.append(f"Unmapped alarms: {len(mapping.unmapped_alarms)}")
            mapping_text = "\n".join(lines)

            with open(args.mapping_text_save, "w", encoding="utf-8") as f:
                f.write(mapping_text)

            print(mapping_text)
            print("")
            print(f"Saved resources to: {args.resources_save}")
            print(f"Saved mapping JSON to: {args.mapping_save}")
            print(f"Saved mapping text to: {args.mapping_text_save}")
        elif args.command == "score":
            write_json(args.resources_save, sorted_records)
            coverage = score_alarm_coverage(settings=settings, records=sorted_records)

            score_payload = {
                "summary": coverage.summary,
                "resources": coverage.resources,
            }
            write_json(args.score_save, score_payload)

            missing = []
            for r in coverage.resources:
                miss_checks = [c for c in r["checks"] if c["required"] and c["status"] == "MISSING"]
                if miss_checks:
                    missing.append(
                        {
                            "resource_kind": r["resource_kind"],
                            "region": r["region"],
                            "resource_name": r["resource_name"],
                            "resource_arn": r["resource_arn"],
                            "missing_required_checks": miss_checks,
                        }
                    )
            write_json(args.missing_save, {"missing_resources": missing, "count": len(missing)})

            score_lines = []
            score_lines.append("Alarm Coverage Score Report (ECS/Lambda/RDS)")
            score_lines.append("=" * 72)
            score_lines.append("")
            score_lines.append(
                f"Overall required coverage: {coverage.summary['required_coverage_score_pct']}% "
                f"({coverage.summary['required_checks_met']}/{coverage.summary['required_checks_total']})"
            )
            score_lines.append(
                f"Optional checks met: {coverage.summary['optional_checks_met']}/{coverage.summary['optional_checks_total']}"
            )
            score_lines.append(f"Resources scored: {coverage.summary['resource_count_scored']}")
            score_lines.append("")

            for r in coverage.resources:
                score_lines.append(
                    f"[{r['region']}] {r['resource_kind']} {r['resource_name']} -> "
                    f"{r['required_score_pct']}% ({r['required_met']}/{r['required_total']})"
                )
                for c in r["checks"]:
                    mark = "OK" if c["status"] == "PRESENT" else "MISSING"
                    req = "required" if c["required"] else "optional"
                    # Display-layer fallback: '-' is the human-readable placeholder
                    # for absent confidence/strategy fields in the printed report.
                    confidence = c.get("confidence")
                    strategy = c.get("strategy")
                    confidence_display = confidence if confidence is not None else "-"
                    strategy_display = strategy if strategy is not None else "-"
                    score_lines.append(
                        f"  - {mark} [{req}] {c['check_id']} | confidence={confidence_display} | strategy={strategy_display}"
                    )
                score_lines.append("")

            score_text = "\n".join(score_lines)
            with open(args.score_text_save, "w", encoding="utf-8") as f:
                f.write(score_text)

            missing_lines = []
            missing_lines.append("Missing Required Alarm Checks")
            missing_lines.append("=" * 40)
            missing_lines.append("")
            if not missing:
                missing_lines.append("No missing required checks found.")
            else:
                for m in missing:
                    missing_lines.append(
                        f"[{m['region']}] {m['resource_kind']} {m['resource_name']} ({m['resource_arn']})"
                    )
                    for c in m["missing_required_checks"]:
                        missing_lines.append(f"  - {c['check_id']}: {c['title']}")
                    missing_lines.append("")
            missing_text = "\n".join(missing_lines)
            with open(args.missing_text_save, "w", encoding="utf-8") as f:
                f.write(missing_text)

            exec_payload, exec_text = _build_executive_summary(
                coverage_summary=coverage.summary,
                coverage_resources=coverage.resources,
                missing=missing,
            )
            write_json(args.exec_save, exec_payload)
            with open(args.exec_text_save, "w", encoding="utf-8") as f:
                f.write(exec_text)

            print(score_text)
            print("")
            print(missing_text)
            print("")
            print(exec_text)
            print("")
            print(f"Saved resources to: {args.resources_save}")
            print(f"Saved score JSON to: {args.score_save}")
            print(f"Saved score text to: {args.score_text_save}")
            print(f"Saved missing JSON to: {args.missing_save}")
            print(f"Saved missing text to: {args.missing_text_save}")
            print(f"Saved executive summary JSON to: {args.exec_save}")
            print(f"Saved executive summary text to: {args.exec_text_save}")
        elif args.command == "changes":
            scope_key = _state_scope_key(regions=regions, query=args.query, limit=args.limit)
            snapshot_path, meta_path = _build_state_paths(
                state_dir=args.state_dir, account_id=identity["Account"], scope_key=scope_key
            )
            previous_records: list[dict] = []
            if snapshot_path.exists():
                try:
                    previous_records = json.loads(snapshot_path.read_text(encoding="utf-8"))
                    if not isinstance(previous_records, list):
                        previous_records = []
                except Exception:
                    previous_records = []

            delta = _compute_delta(previous=previous_records, current=sorted_records)
            recommendations = _build_new_resource_recommendations(
                settings=settings,
                current_records=sorted_records,
                new_records=delta["new_resources"],
            )

            delta_payload = {
                "account_id": identity["Account"],
                "scope_key": scope_key,
                "query": args.query,
                "regions": regions,
                "timestamp_utc": datetime.now(UTC).isoformat(),
                **delta,
            }
            write_json(args.delta_save, delta_payload)
            with open(args.delta_text_save, "w", encoding="utf-8") as f:
                f.write(_render_delta_text(delta))

            recommend_payload = {
                "account_id": identity["Account"],
                "scope_key": scope_key,
                "query": args.query,
                "regions": regions,
                "timestamp_utc": datetime.now(UTC).isoformat(),
                **recommendations,
            }
            write_json(args.recommend_save, recommend_payload)
            with open(args.recommend_text_save, "w", encoding="utf-8") as f:
                f.write(_render_recommendations_text(recommendations))

            snapshot_path.parent.mkdir(parents=True, exist_ok=True)
            snapshot_path.write_text(json.dumps(sorted_records, indent=2), encoding="utf-8")
            meta_path.write_text(
                json.dumps(
                    {
                        "account_id": identity["Account"],
                        "scope_key": scope_key,
                        "regions": regions,
                        "query": args.query,
                        "limit": args.limit,
                        "record_count": len(sorted_records),
                        "timestamp_utc": datetime.now(UTC).isoformat(),
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )

            print(_render_delta_text(delta))
            print("")
            print(_render_recommendations_text(recommendations))
            print("")
            print(f"Saved delta JSON to: {args.delta_save}")
            print(f"Saved delta text to: {args.delta_text_save}")
            print(f"Saved recommendations JSON to: {args.recommend_save}")
            print(f"Saved recommendations text to: {args.recommend_text_save}")
            print(f"Updated state snapshot: {snapshot_path}")
        elif args.command == "audit":
            from discovery_fabric.output.pdf_report import (
                AccountMeta,
                write_audit_pdf,
            )

            output_dir = Path(args.output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            resources_path = output_dir / "all-resources.json"
            score_path = output_dir / "alarm-coverage-score.json"
            missing_path = output_dir / "alarm-coverage-missing.json"

            write_json(str(resources_path), sorted_records)
            # Resource → log group → alarm mapping (with actionability fields).
            # We compute this alongside the score so the executive PDF, the
            # Streamlit UI, and the Next.js Resource Map view all read the
            # same fresh artifacts after a single `audit` run.
            mapping_path = output_dir / "resource-mapping.json"
            mapping = build_resource_mapping(settings=settings, records=sorted_records)
            write_json(
                str(mapping_path),
                {
                    "resource_count": len(sorted_records),
                    "resource_mapping_count": len(mapping.resource_mappings),
                    "resource_mappings": mapping.resource_mappings,
                    "unmapped_alarms": mapping.unmapped_alarms,
                },
            )
            coverage = score_alarm_coverage(settings=settings, records=sorted_records)
            write_json(
                str(score_path),
                {"summary": coverage.summary, "resources": coverage.resources},
            )

            missing = []
            for r in coverage.resources:
                miss_checks = [c for c in r["checks"] if c["required"] and c["status"] == "MISSING"]
                if miss_checks:
                    missing.append(
                        {
                            "resource_kind": r["resource_kind"],
                            "region": r["region"],
                            "resource_name": r["resource_name"],
                            "resource_arn": r["resource_arn"],
                            "missing_required_checks": miss_checks,
                        }
                    )
            write_json(str(missing_path), {"missing_resources": missing, "count": len(missing)})

            scanned_at = datetime.now(UTC).strftime("%Y-%m-%d %H:%M")
            account_id = identity["Account"]
            if args.pdf_out:
                pdf_path = Path(args.pdf_out)
            else:
                date_slug = datetime.now(UTC).strftime("%Y%m%d")
                pdf_path = output_dir / f"audit-{account_id}-{date_slug}.pdf"

            account_meta = AccountMeta(
                account_id=account_id,
                account_alias=args.account_alias,
                scanned_at_utc=scanned_at,
                regions_scanned=regions or [settings.aws_region],
                regions_skipped=skipped_regions,
            )
            # Persist meta alongside the JSON outputs so any downstream surface
            # (Streamlit, Next.js UI, future re-rendering of the PDF) can rebuild
            # the same account context without re-running discovery.
            write_json(
                str(output_dir / "audit-meta.json"),
                {
                    "account_id": account_id,
                    "account_alias": args.account_alias,
                    "scanned_at_utc": scanned_at,
                    "regions_scanned": regions or [settings.aws_region],
                    "regions_skipped": skipped_regions,
                },
            )
            write_audit_pdf(
                str(pdf_path),
                account_meta=account_meta,
                coverage_summary=coverage.summary,
                coverage_resources=coverage.resources,
            )

            print("")
            print("Audit complete.")
            print(f"  Account:        {account_id}{' (' + args.account_alias + ')' if args.account_alias else ''}")
            print(f"  Regions scored: {len(regions) if regions else 1}"
                  f"{' (' + str(len(skipped_regions)) + ' skipped)' if skipped_regions else ''}")
            print(f"  Coverage:       {coverage.summary['required_coverage_score_pct']}% "
                  f"({coverage.summary['required_checks_met']}/{coverage.summary['required_checks_total']} required checks)")
            print(f"  Resources:      {coverage.summary['resource_count_scored']} scored")
            print("")
            print(f"  Resources JSON: {resources_path}")
            print(f"  Score JSON:     {score_path}")
            print(f"  Missing JSON:   {missing_path}")
            print(f"  PDF report:     {pdf_path}")
        else:
            parser.error("Unsupported command.")

    except DiscoveryError as exc:
        print(f"discovery-fabric error: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # pragma: no cover - defensive
        print(f"unexpected error: {exc}", file=sys.stderr)
        return 1

    return 0


# Module-mode entry. The [project.scripts] entry-point calls main() directly so
# this guard is only exercised when someone runs `python -m discovery_fabric.cli`
# (e.g. CI's integration test).
if __name__ == "__main__":
    raise SystemExit(main())


