from __future__ import annotations

import os
from dataclasses import dataclass

import boto3
from botocore.config import Config as BotoConfig
from dotenv import load_dotenv

load_dotenv()


# Standard exponential-backoff retry policy applied to every AWS client we
# create. Large customer accounts will throttle aggressively; without this,
# discovery aborts mid-scan. Standard mode = boto3's documented retry mode
# with jitter, which we prefer over adaptive (we want throttling visible in
# logs, not silently rate-limited client-side).
DEFAULT_MAX_ATTEMPTS = 10
DEFAULT_CONNECT_TIMEOUT = 10
DEFAULT_READ_TIMEOUT = 60


@dataclass(frozen=True)
class Settings:
    aws_profile: str | None
    aws_access_key_id: str | None
    aws_secret_access_key: str | None
    aws_session_token: str | None
    aws_region: str
    view_arn: str | None
    assume_role_arn: str | None = None
    assume_role_session_name: str = "discovery-fabric-audit"


def settings_from_cli(
    profile: str | None = None,
    access_key_id: str | None = None,
    secret_access_key: str | None = None,
    session_token: str | None = None,
    region: str | None = None,
    view_arn: str | None = None,
    assume_role_arn: str | None = None,
    assume_role_session_name: str | None = None,
) -> Settings:
    return Settings(
        aws_profile=profile or os.getenv("AWS_PROFILE"),
        aws_access_key_id=access_key_id or os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=secret_access_key or os.getenv("AWS_SECRET_ACCESS_KEY"),
        aws_session_token=session_token or os.getenv("AWS_SESSION_TOKEN"),
        aws_region=region or os.getenv("AWS_REGION", "us-east-1"),
        view_arn=view_arn or os.getenv("RE2_VIEW_ARN"),
        assume_role_arn=assume_role_arn or os.getenv("AWS_ASSUME_ROLE_ARN"),
        assume_role_session_name=(
            assume_role_session_name
            or os.getenv("AWS_ASSUME_ROLE_SESSION_NAME")
            or "discovery-fabric-audit"
        ),
    )


def make_boto3_session(settings: Settings):
    session_kwargs: dict[str, str] = {}
    if settings.aws_profile:
        session_kwargs["profile_name"] = settings.aws_profile
    if settings.aws_access_key_id and settings.aws_secret_access_key:
        session_kwargs["aws_access_key_id"] = settings.aws_access_key_id
        session_kwargs["aws_secret_access_key"] = settings.aws_secret_access_key
        if settings.aws_session_token:
            session_kwargs["aws_session_token"] = settings.aws_session_token
    return boto3.Session(**session_kwargs)


def default_boto_config() -> BotoConfig:
    return BotoConfig(
        retries={"mode": "standard", "max_attempts": DEFAULT_MAX_ATTEMPTS},
        connect_timeout=DEFAULT_CONNECT_TIMEOUT,
        read_timeout=DEFAULT_READ_TIMEOUT,
        user_agent_extra="opsfabric-discovery/0.1",
    )


def make_boto3_client(settings: Settings, service: str, region: str | None = None):
    """Single entry point for AWS clients. Always carries retry+timeout config."""
    session = make_boto3_session(settings)
    return session.client(
        service,
        region_name=region or settings.aws_region,
        config=default_boto_config(),
    )


# AWS limits AssumeRole session duration to the role's MaxSessionDuration
# (default 1h, max 12h). Audits on very large accounts may exceed 1h once
# throttling backoff kicks in, so customers can raise this — but the role's
# max must allow it. We default to 1h to match the AWS default.
DEFAULT_ASSUME_ROLE_DURATION = 3600


def assume_role_credentials(
    settings: Settings,
    *,
    external_id: str | None = None,
    duration_seconds: int = DEFAULT_ASSUME_ROLE_DURATION,
) -> Settings:
    """Exchange the base credentials in `settings` for temporary credentials
    obtained via sts:AssumeRole. Returns a new Settings with the temp creds
    set and assume_role_arn cleared so downstream callers don't loop.

    Failure here aborts the run — without successful AssumeRole we cannot
    talk to the customer account at all.
    """
    if not settings.assume_role_arn:
        return settings

    sts = make_boto3_client(settings, "sts")
    params: dict[str, object] = {
        "RoleArn": settings.assume_role_arn,
        "RoleSessionName": settings.assume_role_session_name,
        "DurationSeconds": duration_seconds,
    }
    if external_id:
        params["ExternalId"] = external_id

    response = sts.assume_role(**params)
    creds = response["Credentials"]

    return Settings(
        aws_profile=None,
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
        aws_region=settings.aws_region,
        view_arn=settings.view_arn,
        assume_role_arn=None,
        assume_role_session_name=settings.assume_role_session_name,
    )
