from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError

from discovery_fabric.config import Settings, default_boto_config, make_boto3_session

# Match the AWS RDS log-group path structure precisely instead of substring-
# matching the identifier. Substring matching attributes the replica's log
# group to a same-prefix instance (e.g. `payments` matches both
# /aws/rds/instance/payments/ and /aws/rds/instance/payments-replica/).
RDS_LOG_GROUP_PATTERN = re.compile(r"^/aws/rds/(instance|cluster)/([^/]+)/")


def _rds_log_groups_for_identifier(
    log_groups: list[str], identifier: str, kind: str
) -> list[str]:
    """Filter log groups belonging to a specific RDS instance or cluster.

    `kind` is "instance" or "cluster" — anchors the regex group so an instance
    with the same name as a cluster doesn't accidentally claim cluster log
    groups (or vice-versa).
    """
    out = []
    for lg in log_groups:
        m = RDS_LOG_GROUP_PATTERN.match(lg)
        if not m:
            continue
        if m.group(1) != kind:
            continue
        if m.group(2) != identifier:
            continue
        out.append(lg)
    return out

logger = logging.getLogger(__name__)


def _str_or_empty(value: Any) -> str:
    """Coerce a record field to a display-safe string. None/absent → ''."""
    return str(value) if value is not None else ""


@dataclass
class MappingResult:
    resource_mappings: list[dict[str, Any]]
    unmapped_alarms: list[dict[str, Any]]


def _make_session(settings: Settings):
    return make_boto3_session(settings)


def _alarm_name_from_arn(arn: str) -> str | None:
    marker = ":alarm:"
    if marker not in arn:
        return None
    return arn.split(marker, 1)[1]


def _chunked(items: list[str], size: int):
    for i in range(0, len(items), size):
        yield items[i : i + size]


def _extract_alarm_metric_keys(alarm: dict[str, Any]) -> set[tuple[str, str]]:
    keys: set[tuple[str, str]] = set()

    namespace = alarm.get("Namespace")
    metric_name = alarm.get("MetricName")
    if namespace and metric_name:
        keys.add((str(namespace), str(metric_name)))

    for mq in alarm.get("Metrics", []) or []:
        metric_stat = mq.get("MetricStat", {})
        metric = metric_stat.get("Metric", {})
        ns = metric.get("Namespace")
        mn = metric.get("MetricName")
        if ns and mn:
            keys.add((str(ns), str(mn)))

    return keys


def _extract_alarm_dimensions(alarm: dict[str, Any]) -> dict[str, str]:
    dim_map: dict[str, str] = {}

    for d in alarm.get("Dimensions", []) or []:
        name = d.get("Name")
        value = d.get("Value")
        if name and value:
            dim_map[str(name)] = str(value)

    for mq in alarm.get("Metrics", []) or []:
        metric_stat = mq.get("MetricStat", {})
        metric = metric_stat.get("Metric", {})
        for d in metric.get("Dimensions", []) or []:
            name = d.get("Name")
            value = d.get("Value")
            if name and value:
                dim_map[str(name)] = str(value)

    return dim_map


def _parse_ecs_service_arn(arn: str) -> tuple[str, str] | None:
    # arn:aws:ecs:region:acct:service/cluster-name/service-name
    marker = ":service/"
    if marker not in arn:
        return None
    suffix = arn.split(marker, 1)[1]
    parts = suffix.split("/")
    if len(parts) != 2:
        return None
    return parts[0], parts[1]


def _parse_lambda_function_arn(arn: str) -> str | None:
    marker = ":function:"
    if marker not in arn:
        return None
    suffix = arn.split(marker, 1)[1]
    # Strip version/alias when present.
    return suffix.split(":", 1)[0]


def _parse_rds_db_arn(arn: str) -> str | None:
    marker = ":db:"
    if marker not in arn:
        return None
    return arn.split(marker, 1)[1]


def _parse_sqs_queue_arn(arn: str) -> str | None:
    # arn:aws:sqs:<region>:<acct>:<queue-name>
    # SQS ARN has 6 colon-separated segments and no resource-type prefix.
    parts = arn.split(":", 5)
    if len(parts) != 6:
        return None
    if parts[2] != "sqs":
        return None
    name = parts[5]
    if not name:
        return None
    return name


def _parse_rds_cluster_arn(arn: str) -> str | None:
    # Aurora/Aurora-Serverless cluster ARN: arn:aws:rds:<region>:<acct>:cluster:<cluster-id>
    # Cluster-level alarms use the DBClusterIdentifier dimension instead of
    # DBInstanceIdentifier — they need a separate code path from rds:db.
    marker = ":cluster:"
    if marker not in arn:
        return None
    return arn.split(marker, 1)[1]


def _target_group_short_form(arn: str) -> str | None:
    """Normalize an ALB target group ARN to the short form CloudWatch uses
    in the `TargetGroup` dimension value.

    Full ARN: arn:aws:elasticloadbalancing:<region>:<acct>:targetgroup/<name>/<id>
    Short:    targetgroup/<name>/<id>

    CloudWatch alarm dimensions store the short form, while ECS
    DescribeServices returns full ARNs. Without normalization the bridge
    silently fails to match.
    """
    if not isinstance(arn, str) or ":targetgroup/" not in arn:
        return None
    parts = arn.split(":", 5)
    if len(parts) != 6:
        return None
    suffix = parts[5]
    if not suffix.startswith("targetgroup/"):
        return None
    return suffix


def _alarm_is_actionable(alarm: dict[str, Any]) -> tuple[bool, str | None]:
    """Decide whether an alarm will actually page someone.

    Existence in CloudWatch is necessary but not sufficient — a disabled
    alarm or an alarm with no targets provides zero of the value the
    customer is paying for. Returns (actionable, degraded_reason).
    """
    actions_enabled = bool(alarm.get("ActionsEnabled", True))
    if not actions_enabled:
        return False, "actions_disabled"
    alarm_actions = alarm.get("AlarmActions") or []
    if not alarm_actions:
        return False, "no_alarm_actions_configured"
    state_value = str(alarm.get("StateValue", "")).upper()
    if state_value == "INSUFFICIENT_DATA":
        return False, "insufficient_data"
    return True, None


def _build_lambda_log_group_index(
    session, settings: Settings, records: list[dict[str, Any]]
) -> dict[tuple[str, str], str]:
    """Per-region map of `(region, function_name) → configured_log_group`.

    Built from `lambda:ListFunctions` (one paginated call per region) which
    returns each function's LoggingConfig, including the optional `LogGroup`
    override. When LoggingConfig.LogGroup is unset, AWS auto-creates and uses
    `/aws/lambda/<name>` — we record that canonical path so callers don't
    have to branch.

    No extra cost: list operations don't bill, and we already need
    `lambda:ListFunctions` in the IAM policy for discovery.
    """
    regions: set[str] = set()
    for rec in records:
        if rec.get("service") == "lambda" and rec.get("resource_type") == "lambda:function":
            regions.add(str(rec.get("region") or settings.aws_region))

    index: dict[tuple[str, str], str] = {}
    for region in regions:
        try:
            client = session.client("lambda", region_name=region, config=default_boto_config())
            paginator = client.get_paginator("list_functions")
            for page in paginator.paginate():
                for fn in page.get("Functions", []):
                    name = fn.get("FunctionName")
                    if not name:
                        continue
                    logging_cfg = fn.get("LoggingConfig") or {}
                    custom_lg = logging_cfg.get("LogGroup")
                    canonical_lg = f"/aws/lambda/{name}"
                    index[(region, str(name))] = str(custom_lg or canonical_lg)
        except (BotoCoreError, ClientError) as exc:
            # Per-region failure is non-fatal — fall back to the canonical
            # convention for any function in this region we can't introspect.
            logger.warning("list_functions failed in region=%s: %s", region, exc)
            continue
    return index


def _build_log_group_indexes(records: list[dict[str, Any]]) -> tuple[dict[str, list[str]], dict[str, str]]:
    by_region: dict[str, list[str]] = defaultdict(list)
    arn_by_name: dict[str, str] = {}
    for rec in records:
        if rec.get("service") != "logs" or rec.get("resource_type") != "logs:log-group":
            continue
        arn = rec.get("arn")
        region = _str_or_empty(rec.get("region"))
        if not isinstance(arn, str):
            continue
        if ":log-group:" not in arn:
            continue
        lg_name = arn.split(":log-group:", 1)[1]
        by_region[region].append(lg_name)
        arn_by_name[lg_name] = arn
    return by_region, arn_by_name


def _build_alarm_details(
    session,
    settings: Settings,
    alarm_records: list[dict[str, Any]],
    log_groups_by_region: dict[str, list[str]],
) -> dict[str, list[dict[str, Any]]]:
    alarms_by_region: dict[str, list[dict[str, Any]]] = defaultdict(list)

    metric_to_log_groups: dict[str, dict[tuple[str, str], set[str]]] = defaultdict(lambda: defaultdict(set))
    for region, log_groups in log_groups_by_region.items():
        logs = session.client("logs", region_name=region or settings.aws_region, config=default_boto_config())
        for lg in log_groups:
            try:
                paginator = logs.get_paginator("describe_metric_filters")
                for page in paginator.paginate(logGroupName=lg):
                    for mf in page.get("metricFilters", []):
                        for mt in mf.get("metricTransformations", []):
                            ns = mt.get("metricNamespace")
                            mn = mt.get("metricName")
                            if ns and mn:
                                metric_to_log_groups[region][(str(ns), str(mn))].add(lg)
            except (BotoCoreError, ClientError) as exc:
                # Per-log-group failure is non-fatal; record it and continue so a
                # single inaccessible group doesn't fail the whole mapping.
                logger.warning("describe_metric_filters failed for log_group=%s region=%s: %s", lg, region, exc)
                continue

    regions = {str(r.get("region") or settings.aws_region) for r in alarm_records}
    for region in regions:
        names: list[str] = []
        for rec in alarm_records:
            if str(rec.get("region") or settings.aws_region) != region:
                continue
            arn = rec.get("arn")
            if isinstance(arn, str):
                n = _alarm_name_from_arn(arn)
                if n:
                    names.append(n)
        if not names:
            continue

        cw = session.client("cloudwatch", region_name=region, config=default_boto_config())
        try:
            for batch in _chunked(names, 100):
                resp = cw.describe_alarms(AlarmNames=batch)
                for alarm in resp.get("MetricAlarms", []):
                    metric_keys = _extract_alarm_metric_keys(alarm)
                    linked_log_groups: set[str] = set()
                    for key in metric_keys:
                        linked_log_groups.update(metric_to_log_groups[region].get(key, set()))

                    actionable, degraded_reason = _alarm_is_actionable(alarm)
                    alarms_by_region[region].append(
                        {
                            "alarm_name": alarm.get("AlarmName"),
                            "alarm_arn": alarm.get("AlarmArn"),
                            "dimensions": _extract_alarm_dimensions(alarm),
                            "metric_keys": sorted(metric_keys),
                            "linked_log_groups": sorted(linked_log_groups),
                            "actions_enabled": bool(alarm.get("ActionsEnabled", True)),
                            "alarm_actions_count": len(alarm.get("AlarmActions") or []),
                            "state_value": str(alarm.get("StateValue", "")),
                            "actionable": actionable,
                            "degraded_reason": degraded_reason,
                            "raw": alarm,
                        }
                    )
        except (BotoCoreError, ClientError) as exc:
            # Skipping a region's alarm describe leaves alarms unmapped for that
            # region but lets the rest of the audit continue. Surface via logs.
            logger.warning("describe_alarms failed in region=%s: %s", region, exc)
            continue

    return alarms_by_region


def _collect_ecs_resources(session, settings: Settings, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for rec in records:
        if rec.get("service") != "ecs" or rec.get("resource_type") != "ecs:service":
            continue
        arn = rec.get("arn")
        if not isinstance(arn, str):
            continue
        parsed = _parse_ecs_service_arn(arn)
        if not parsed:
            continue
        cluster_name, service_name = parsed
        region = str(rec.get("region") or settings.aws_region)

        task_definition_arn = None
        log_groups: set[str] = set()
        target_groups: list[str] = []
        ecs = session.client("ecs", region_name=region, config=default_boto_config())
        try:
            svc_resp = ecs.describe_services(cluster=cluster_name, services=[service_name])
            services = svc_resp.get("services", [])
            if services:
                task_definition_arn = services[0].get("taskDefinition")
                # Capture the load-balancer attachments so the ALB → ECS bridge
                # can match alarms that scope by TargetGroup dimension (the
                # most common production ALB-fronted ECS alarm shape).
                for lb in services[0].get("loadBalancers", []) or []:
                    short = _target_group_short_form(lb.get("targetGroupArn", ""))
                    if short:
                        target_groups.append(short)
        except (BotoCoreError, ClientError) as exc:
            # Skipping a single ECS service's task-definition introspection is
            # non-fatal for mapping; log and degrade gracefully.
            logger.warning("describe_services failed for cluster=%s service=%s: %s", cluster_name, service_name, exc)

        if task_definition_arn:
            try:
                td_resp = ecs.describe_task_definition(taskDefinition=task_definition_arn)
                for cdef in td_resp.get("taskDefinition", {}).get("containerDefinitions", []):
                    lg = cdef.get("logConfiguration", {}).get("options", {}).get("awslogs-group")
                    if lg:
                        log_groups.add(str(lg))
            except (BotoCoreError, ClientError) as exc:
                logger.warning("describe_task_definition failed for %s: %s", task_definition_arn, exc)

        out.append(
            {
                "resource_kind": "ecs_service",
                "region": region,
                "resource_name": service_name,
                "resource_arn": arn,
                "metadata": {
                    "cluster_name": cluster_name,
                    "task_definition_arn": task_definition_arn,
                },
                "log_groups": sorted(log_groups),
                "target_group_short_forms": sorted(set(target_groups)),
                "dimension_values": {
                    "ClusterName": cluster_name,
                    "ServiceName": service_name,
                },
                "expected_namespace": "AWS/ECS",
            }
        )
    return out


def _collect_lambda_resources(
    settings: Settings,
    records: list[dict[str, Any]],
    log_groups_by_region: dict[str, list[str]],
    lambda_lg_index: dict[tuple[str, str], str],
) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for rec in records:
        if rec.get("service") != "lambda" or rec.get("resource_type") != "lambda:function":
            continue
        arn = rec.get("arn")
        if not isinstance(arn, str):
            continue
        fn_name = _parse_lambda_function_arn(arn)
        if not fn_name:
            continue
        region = str(rec.get("region") or settings.aws_region)
        # Use the canonical configured log group from `lambda:ListFunctions`,
        # falling back to the convention if introspection failed for the region.
        configured_lg = lambda_lg_index.get((region, fn_name)) or f"/aws/lambda/{fn_name}"
        found_lgs = [lg for lg in log_groups_by_region.get(region, []) if lg == configured_lg]
        out.append(
            {
                "resource_kind": "lambda_function",
                "region": region,
                "resource_name": fn_name,
                "resource_arn": arn,
                "metadata": {},
                "log_groups": sorted(found_lgs),
                "dimension_values": {
                    "FunctionName": fn_name,
                },
                "expected_namespace": "AWS/Lambda",
            }
        )
    return out


def _collect_rds_resources(
    settings: Settings,
    records: list[dict[str, Any]],
    log_groups_by_region: dict[str, list[str]],
) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for rec in records:
        if rec.get("service") != "rds" or rec.get("resource_type") != "rds:db":
            continue
        arn = rec.get("arn")
        if not isinstance(arn, str):
            continue
        db_id = _parse_rds_db_arn(arn)
        if not db_id:
            continue
        region = str(rec.get("region") or settings.aws_region)
        found_lgs = _rds_log_groups_for_identifier(
            log_groups_by_region.get(region, []), db_id, "instance"
        )
        out.append(
            {
                "resource_kind": "rds_instance",
                "region": region,
                "resource_name": db_id,
                "resource_arn": arn,
                "metadata": {},
                "log_groups": sorted(found_lgs),
                "dimension_values": {
                    "DBInstanceIdentifier": db_id,
                },
                "expected_namespace": "AWS/RDS",
            }
        )
    return out


def _collect_sqs_resources(
    settings: Settings,
    records: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """SQS queues are dimensioned by `QueueName` only, with namespace AWS/SQS.
    No additional AWS calls needed — Resource Explorer 2 already returned the
    queue ARN, and the queue name is parseable from it.
    """
    out: list[dict[str, Any]] = []
    for rec in records:
        if rec.get("service") != "sqs" or rec.get("resource_type") != "sqs:queue":
            continue
        arn = rec.get("arn")
        if not isinstance(arn, str):
            continue
        queue_name = _parse_sqs_queue_arn(arn)
        if not queue_name:
            continue
        region = str(rec.get("region") or settings.aws_region)
        out.append(
            {
                "resource_kind": "sqs_queue",
                "region": region,
                "resource_name": queue_name,
                "resource_arn": arn,
                "metadata": {},
                "log_groups": [],
                "dimension_values": {"QueueName": queue_name},
                "expected_namespace": "AWS/SQS",
            }
        )
    return out


def _collect_rds_cluster_resources(
    settings: Settings,
    records: list[dict[str, Any]],
    log_groups_by_region: dict[str, list[str]],
) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for rec in records:
        if rec.get("service") != "rds" or rec.get("resource_type") != "rds:cluster":
            continue
        arn = rec.get("arn")
        if not isinstance(arn, str):
            continue
        cluster_id = _parse_rds_cluster_arn(arn)
        if not cluster_id:
            continue
        region = str(rec.get("region") or settings.aws_region)
        found_lgs = _rds_log_groups_for_identifier(
            log_groups_by_region.get(region, []), cluster_id, "cluster"
        )
        out.append(
            {
                "resource_kind": "rds_cluster",
                "region": region,
                "resource_name": cluster_id,
                "resource_arn": arn,
                "metadata": {},
                "log_groups": sorted(found_lgs),
                "dimension_values": {
                    "DBClusterIdentifier": cluster_id,
                },
                "expected_namespace": "AWS/RDS",
            }
        )
    return out


def _score_alarm_match(resource: dict[str, Any], alarm: dict[str, Any]) -> tuple[str | None, list[str]]:
    reasons: list[str] = []
    expected_ns = resource.get("expected_namespace")
    resource_name = _str_or_empty(resource.get("resource_name"))
    dimension_values: dict[str, str] = resource.get("dimension_values", {})
    alarm_dims: dict[str, str] = alarm.get("dimensions", {})
    metric_keys = {(str(ns), str(mn)) for ns, mn in alarm.get("metric_keys", [])}
    alarm_name = _str_or_empty(alarm.get("alarm_name"))
    alarm_log_groups = set(alarm.get("linked_log_groups", []))
    resource_log_groups = set(resource.get("log_groups", []))

    # 1) Exact dimension match (HIGH)
    if dimension_values and all(alarm_dims.get(k) == v for k, v in dimension_values.items()):
        reasons.append("exact_dimension_match")
        return "HIGH", reasons

    # 2) ALB target-group bridge (HIGH) — alarm scopes by TargetGroup ARN,
    #    which we cross-reference back to the ECS service via its registered
    #    load-balancer attachments. The match is on full ARN equality (not
    #    substring), so it cannot false-positive across services.
    target_group_short_forms = set(resource.get("target_group_short_forms", []))
    alarm_target_group = alarm_dims.get("TargetGroup", "")
    if alarm_target_group and alarm_target_group in target_group_short_forms:
        reasons.append("alb_target_group_to_ecs_service")
        return "HIGH", reasons

    # 3) Metric namespace + partial dimensions (MEDIUM)
    has_expected_namespace = any(ns == expected_ns for ns, _ in metric_keys) if expected_ns else False
    partial_dim_match = any(alarm_dims.get(k) == v for k, v in dimension_values.items())
    if has_expected_namespace and partial_dim_match:
        reasons.append("metric_namespace_plus_partial_dimensions")
        return "MEDIUM", reasons

    # 4) Metric-filter to log-group linkage (HIGH)
    if resource_log_groups and alarm_log_groups.intersection(resource_log_groups):
        reasons.append("metric_filter_to_log_group_linkage")
        return "HIGH", reasons

    # 5) Naming heuristic (LOW)
    if resource_name and resource_name in alarm_name:
        reasons.append("naming_heuristic")
        return "LOW", reasons

    return None, reasons


def build_resource_mapping(settings: Settings, records: list[dict[str, Any]]) -> MappingResult:
    session = _make_session(settings)

    alarm_records = [
        r
        for r in records
        if r.get("service") == "cloudwatch" and r.get("resource_type") == "cloudwatch:alarm"
    ]
    log_groups_by_region, _ = _build_log_group_indexes(records)
    alarms_by_region = _build_alarm_details(
        session=session,
        settings=settings,
        alarm_records=alarm_records,
        log_groups_by_region=log_groups_by_region,
    )

    resources: list[dict[str, Any]] = []
    lambda_lg_index = _build_lambda_log_group_index(session, settings, records)

    resources.extend(_collect_ecs_resources(session, settings, records))
    resources.extend(_collect_lambda_resources(settings, records, log_groups_by_region, lambda_lg_index))
    resources.extend(_collect_rds_resources(settings, records, log_groups_by_region))
    resources.extend(_collect_rds_cluster_resources(settings, records, log_groups_by_region))
    resources.extend(_collect_sqs_resources(settings, records))

    mapped_alarm_arns: set[str] = set()
    resource_mappings: list[dict[str, Any]] = []

    for resource in resources:
        region = resource["region"]
        matched_alarms: list[dict[str, Any]] = []
        for alarm in alarms_by_region.get(region, []):
            confidence, reasons = _score_alarm_match(resource, alarm)
            if not confidence:
                continue
            matched_alarms.append(
                {
                    "alarm_name": alarm["alarm_name"],
                    "alarm_arn": alarm["alarm_arn"],
                    "confidence": confidence,
                    "reasons": reasons,
                    "actionable": alarm.get("actionable", True),
                    "degraded_reason": alarm.get("degraded_reason"),
                    "actions_enabled": alarm.get("actions_enabled", True),
                    "alarm_actions_count": alarm.get("alarm_actions_count", 0),
                    "state_value": alarm.get("state_value", ""),
                }
            )
            if alarm.get("alarm_arn"):
                mapped_alarm_arns.add(str(alarm["alarm_arn"]))

        matched_alarms.sort(key=lambda a: (a["confidence"], a["alarm_name"] or ""))
        resource_mappings.append(
            {
                "resource_kind": resource["resource_kind"],
                "region": resource["region"],
                "resource_name": resource["resource_name"],
                "resource_arn": resource["resource_arn"],
                "metadata": resource.get("metadata", {}),
                "log_groups": resource.get("log_groups", []),
                "cloudwatch_alarms": matched_alarms,
            }
        )

    unmapped_alarms = []
    for rec in alarm_records:
        arn = rec.get("arn")
        if isinstance(arn, str) and arn not in mapped_alarm_arns:
            unmapped_alarms.append(
                {
                    "region": rec.get("region") or settings.aws_region,
                    "alarm_arn": arn,
                    "alarm_name": _alarm_name_from_arn(arn),
                }
            )

    resource_mappings.sort(
        key=lambda x: (x["region"], x["resource_kind"], x["resource_name"])
    )
    unmapped_alarms.sort(key=lambda x: (x["region"], x["alarm_name"] or ""))

    return MappingResult(
        resource_mappings=resource_mappings,
        unmapped_alarms=unmapped_alarms,
    )
