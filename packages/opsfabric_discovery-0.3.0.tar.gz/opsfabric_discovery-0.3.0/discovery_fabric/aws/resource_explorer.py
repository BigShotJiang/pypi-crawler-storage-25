from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError

from discovery_fabric.config import Settings, make_boto3_client


class DiscoveryError(Exception):
    """Raised when discovery cannot proceed."""


@dataclass
class DiscoveryResult:
    view_arn: str
    records: list[dict[str, Any]]


def _resource_explorer_client(settings: Settings):
    return make_boto3_client(settings, "resource-explorer-2")


def _sts_client(settings: Settings):
    return make_boto3_client(settings, "sts")


def validate_aws_identity(settings: Settings) -> dict[str, str]:
    try:
        return _sts_client(settings).get_caller_identity()
    except (BotoCoreError, ClientError) as exc:
        raise DiscoveryError(
            f"Failed to validate AWS identity for profile={settings.aws_profile!r} region={settings.aws_region!r}: {exc}"
        ) from exc


def _select_view_arn(client, explicit_view_arn: str | None) -> str:
    if explicit_view_arn:
        return explicit_view_arn

    try:
        paginator = client.get_paginator("list_views")
        views: list[dict[str, Any]] = []
        for page in paginator.paginate():
            views.extend(page.get("Views", []))
    except (BotoCoreError, ClientError) as exc:
        raise DiscoveryError(
            f"Unable to list Resource Explorer views in region {client.meta.region_name}: {exc}"
        ) from exc

    if not views:
        raise DiscoveryError(
            "No Resource Explorer views found. Enable Resource Explorer 2 and create an index/view first."
        )

    normalized_arns: list[str] = []
    for view in views:
        if isinstance(view, str):
            normalized_arns.append(view)
            continue
        if not isinstance(view, dict):
            continue
        arn = view.get("ViewArn")
        if isinstance(arn, str) and arn:
            normalized_arns.append(arn)
        if view.get("ViewName", "").lower() == "default" and isinstance(arn, str) and arn:
            return arn

    if not normalized_arns:
        raise DiscoveryError("Found Resource Explorer views, but none had a usable ARN.")
    return normalized_arns[0]


def _to_iso_utc(value: Any) -> str | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value.astimezone(UTC).isoformat()
    return str(value)


def _normalize_resource(resource: dict[str, Any] | str) -> dict[str, Any]:
    # Properties are intentionally preserved as-is for downstream audit use.
    if isinstance(resource, str):
        return {
            "arn": resource,
            "service": None,
            "resource_type": None,
            "region": None,
            "account_id": None,
            "last_reported_at": None,
            "properties": [],
        }
    if not isinstance(resource, dict):
        return {
            "arn": str(resource),
            "service": None,
            "resource_type": None,
            "region": None,
            "account_id": None,
            "last_reported_at": None,
            "properties": [],
        }
    return {
        "arn": resource.get("Arn"),
        "service": resource.get("Service"),
        "resource_type": resource.get("ResourceType"),
        "region": resource.get("Region"),
        "account_id": resource.get("OwningAccountId"),
        "last_reported_at": _to_iso_utc(resource.get("LastReportedAt")),
        "properties": resource.get("Properties", []),
    }


def discover_resources(
    settings: Settings,
    query_string: str = "",
    limit: int | None = None,
) -> DiscoveryResult:
    client = _resource_explorer_client(settings)
    view_arn = _select_view_arn(client, settings.view_arn)

    records: list[dict[str, Any]] = []
    next_token: str | None = None
    page_size = 1000

    try:
        while True:
            params: dict[str, Any] = {
                "ViewArn": view_arn,
                "QueryString": query_string,
                "MaxResults": page_size,
            }
            if next_token:
                params["NextToken"] = next_token

            response = client.search(**params)
            resources = response.get("Resources", [])
            if isinstance(resources, dict) or not isinstance(resources, list):
                resources = [resources]

            for item in resources:
                records.append(_normalize_resource(item))
                if limit is not None and len(records) >= limit:
                    return DiscoveryResult(view_arn=view_arn, records=records)

            next_token = response.get("NextToken")
            if not next_token:
                break

    except (BotoCoreError, ClientError) as exc:
        raise DiscoveryError(
            f"Resource discovery failed using view {view_arn}: {exc}"
        ) from exc

    return DiscoveryResult(view_arn=view_arn, records=records)
