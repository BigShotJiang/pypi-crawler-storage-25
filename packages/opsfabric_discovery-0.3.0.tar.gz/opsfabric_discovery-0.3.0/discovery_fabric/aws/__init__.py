"""AWS integrations for discovery fabric."""

