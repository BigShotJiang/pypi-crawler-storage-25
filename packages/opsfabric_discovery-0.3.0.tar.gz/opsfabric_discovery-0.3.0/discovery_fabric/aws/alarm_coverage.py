from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError

from discovery_fabric.config import Settings, default_boto_config, make_boto3_session

# Anchored regex for RDS log-group path. Substring matching attributes
# log groups across same-prefix identifiers (e.g. `payments` would match
# `payments-replica`). See mapping._rds_log_groups_for_identifier.
RDS_LOG_GROUP_PATTERN = re.compile(r"^/aws/rds/(instance|cluster)/([^/]+)/")


def _target_group_short_form(arn: str) -> str | None:
    """Normalize an ALB target group ARN to the short form CloudWatch uses
    in the `TargetGroup` dimension. Mirrors mapping.py for parity.
    """
    if not isinstance(arn, str) or ":targetgroup/" not in arn:
        return None
    parts = arn.split(":", 5)
    if len(parts) != 6:
        return None
    suffix = parts[5]
    if not suffix.startswith("targetgroup/"):
        return None
    return suffix


def _rds_log_groups_for_identifier(
    log_groups: list[str], identifier: str, kind: str
) -> list[str]:
    out = []
    for lg in log_groups:
        m = RDS_LOG_GROUP_PATTERN.match(lg)
        if not m:
            continue
        if m.group(1) != kind:
            continue
        if m.group(2) != identifier:
            continue
        out.append(lg)
    return out


try:
    import yaml
except Exception:  # pragma: no cover - optional dependency guard
    yaml = None

logger = logging.getLogger(__name__)


def _str_or_empty(value: Any) -> str:
    """Coerce a record field to a display-safe string. None/absent → ''."""
    return str(value) if value is not None else ""


CONFIDENCE_RANK = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, None: 0}

DEFAULT_ALARM_PACK: dict[str, Any] = {
    "version": 1,
    "resource_packs": {
        "ecs_service": {
            "checks": [
                {
                    "id": "ecs_cpu_high",
                    "title": "ECS Service CPU high",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P2",
                    "required": True,
                    "namespace": "AWS/ECS",
                    "metric_any": ["CPUUtilization"],
                },
                {
                    "id": "ecs_memory_high",
                    "title": "ECS Service Memory high",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P2",
                    "required": True,
                    "namespace": "AWS/ECS",
                    "metric_any": ["MemoryUtilization"],
                },
                {
                    "id": "ecs_running_below_desired",
                    "title": "ECS RunningTaskCount vs DesiredTaskCount",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P1",
                    "required": True,
                    "namespace": "AWS/ECS",
                    "metric_all": ["RunningTaskCount", "DesiredTaskCount"],
                },
                {
                    "id": "ecs_alb_5xx_failure_signal",
                    "title": "ECS ALB 5XX failure signal",
                    "domain": "application",
                    "mode": "auto",
                    "severity": "P2",
                    "required": False,
                    "namespace": "AWS/ApplicationELB",
                    "metric_any": ["HTTPCode_Target_5XX_Count"],
                },
                {
                    "id": "ecs_latency_slo",
                    "title": "ECS endpoint latency SLO",
                    "domain": "application",
                    "mode": "human_guided",
                    "severity": "P2",
                    "required": False,
                    "namespace": "AWS/ApplicationELB",
                    "metric_any": ["TargetResponseTime"],
                    "needs_input": ["target_group", "threshold_ms", "percentile"],
                },
            ]
        },
        "lambda_function": {
            "checks": [
                {
                    "id": "lambda_errors",
                    "title": "Lambda Errors",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P1",
                    "required": True,
                    "namespace": "AWS/Lambda",
                    "metric_any": ["Errors"],
                },
                {
                    "id": "lambda_throttles",
                    "title": "Lambda Throttles",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P1",
                    "required": True,
                    "namespace": "AWS/Lambda",
                    "metric_any": ["Throttles"],
                },
                {
                    "id": "lambda_duration_high",
                    "title": "Lambda Duration high",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P2",
                    "required": True,
                    "namespace": "AWS/Lambda",
                    "metric_any": ["Duration"],
                },
                {
                    "id": "lambda_concurrency_high",
                    "title": "Lambda ConcurrentExecutions high",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P2",
                    "required": True,
                    "namespace": "AWS/Lambda",
                    "metric_any": ["ConcurrentExecutions"],
                },
                {
                    "id": "lambda_event_age",
                    "title": "Lambda event age high",
                    "domain": "application",
                    "mode": "human_guided",
                    "severity": "P2",
                    "required": False,
                    "namespace": "AWS/Lambda",
                    "metric_any": ["IteratorAge"],
                    "needs_input": ["event_source_type", "threshold_ms"],
                },
                {
                    "id": "lambda_error_log_pattern",
                    "title": "Lambda application error log pattern",
                    "domain": "application",
                    "mode": "human_guided",
                    "severity": "P2",
                    "required": False,
                    # Custom log-derived metrics can live in custom namespaces.
                    # Match via metric-filter->log-group linkage instead of namespace.
                    "namespace": "CUSTOM",
                    "match_linked_log_group_only": True,
                    "needs_input": ["pattern", "threshold_count"],
                },
            ]
        },
        "rds_instance": {
            "checks": [
                {
                    "id": "rds_cpu_high",
                    "title": "RDS CPU high",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P2",
                    "required": True,
                    "namespace": "AWS/RDS",
                    "metric_any": ["CPUUtilization"],
                },
                {
                    "id": "rds_free_storage_low",
                    "title": "RDS FreeStorageSpace low",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P1",
                    "required": True,
                    "namespace": "AWS/RDS",
                    "metric_any": ["FreeStorageSpace"],
                },
                {
                    "id": "rds_freeable_memory_low",
                    "title": "RDS FreeableMemory low",
                    "domain": "infra",
                    "mode": "auto",
                    "severity": "P2",
                    "required": True,
                    "namespace": "AWS/RDS",
                    "metric_any": ["FreeableMemory"],
                },
                {
                    "id": "rds_db_load_or_latency",
                    "title": "RDS DB connections/latency",
                    "domain": "infra",
                    "mode": "human_guided",
                    "severity": "P2",
                    "required": True,
                    "namespace": "AWS/RDS",
                    "metric_any": ["DatabaseConnections", "ReadLatency", "WriteLatency"],
                    "needs_input": ["preferred_metric", "threshold"],
                },
                {
                    "id": "rds_slow_query_pattern",
                    "title": "RDS slow query pattern",
                    "domain": "application",
                    "mode": "human_guided",
                    "severity": "P3",
                    "required": False,
                    "namespace": "AWS/RDS",
                    "metric_any": ["ReadLatency", "WriteLatency"],
                    "needs_input": ["db_engine", "query_slo_ms"],
                },
            ]
        },
    },
}


@dataclass
class CoverageResult:
    resources: list[dict[str, Any]]
    summary: dict[str, Any]


def _make_session(settings: Settings):
    return make_boto3_session(settings)


def _load_alarm_pack() -> tuple[dict[str, list[dict[str, Any]]], str]:
    pack_path = Path(__file__).resolve().parents[1] / "data" / "alarm_pack.yaml"
    source = "default"
    payload: dict[str, Any] = DEFAULT_ALARM_PACK

    if pack_path.exists() and yaml is not None:
        try:
            raw = yaml.safe_load(pack_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                payload = raw
                source = str(pack_path)
        except Exception:
            payload = DEFAULT_ALARM_PACK
            source = "default"

    packs: dict[str, list[dict[str, Any]]] = {}
    for resource_kind, body in payload.get("resource_packs", {}).items():
        checks = []
        for c in (body or {}).get("checks", []):
            if not isinstance(c, dict):
                continue
            if not c.get("id") or not c.get("title"):
                continue
            if not c.get("namespace") and not c.get("match_linked_log_group_only"):
                continue
            checks.append(
                {
                    "id": str(c["id"]),
                    "title": str(c["title"]),
                    "business_impact": str(c.get("business_impact", "")),
                    "domain": str(c.get("domain", "infra")),
                    "mode": str(c.get("mode", "auto")),
                    "severity": str(c.get("severity", "P3")),
                    "required": bool(c.get("required", True)),
                    "namespace": str(c.get("namespace", "")),
                    "metric_any": [str(m) for m in c.get("metric_any", [])],
                    "metric_all": [str(m) for m in c.get("metric_all", [])],
                    "needs_input": [str(m) for m in c.get("needs_input", [])],
                    "match_linked_log_group_only": bool(c.get("match_linked_log_group_only", False)),
                }
            )
        packs[str(resource_kind)] = checks

    return packs, source


def _checks_for(resource_kind: str, pack_checks: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    return [dict(c) for c in pack_checks.get(resource_kind, [])]


def _parse_ecs_service_arn(arn: str) -> tuple[str, str] | None:
    marker = ":service/"
    if marker not in arn:
        return None
    suffix = arn.split(marker, 1)[1]
    parts = suffix.split("/")
    if len(parts) != 2:
        return None
    return parts[0], parts[1]


def _parse_lambda_function_arn(arn: str) -> str | None:
    marker = ":function:"
    if marker not in arn:
        return None
    return arn.split(marker, 1)[1].split(":", 1)[0]


def _parse_sqs_queue_arn(arn: str) -> str | None:
    # arn:aws:sqs:<region>:<acct>:<queue-name>
    parts = arn.split(":", 5)
    if len(parts) != 6:
        return None
    if parts[2] != "sqs":
        return None
    name = parts[5]
    if not name:
        return None
    return name


def _parse_rds_cluster_arn(arn: str) -> str | None:
    # Aurora cluster ARN: arn:aws:rds:<region>:<acct>:cluster:<cluster-id>
    marker = ":cluster:"
    if marker not in arn:
        return None
    return arn.split(marker, 1)[1]


def _parse_rds_db_arn(arn: str) -> str | None:
    marker = ":db:"
    if marker not in arn:
        return None
    return arn.split(marker, 1)[1]


def _chunked(items: list[str], size: int):
    for i in range(0, len(items), size):
        yield items[i : i + size]


def _extract_alarm_dimensions(alarm: dict[str, Any]) -> dict[str, str]:
    dim_map: dict[str, str] = {}
    for d in alarm.get("Dimensions", []) or []:
        n, v = d.get("Name"), d.get("Value")
        if n and v:
            dim_map[str(n)] = str(v)
    for mq in alarm.get("Metrics", []) or []:
        metric = mq.get("MetricStat", {}).get("Metric", {})
        for d in metric.get("Dimensions", []) or []:
            n, v = d.get("Name"), d.get("Value")
            if n and v:
                dim_map[str(n)] = str(v)
    return dim_map


def _extract_alarm_metric_keys(alarm: dict[str, Any]) -> set[tuple[str, str]]:
    keys: set[tuple[str, str]] = set()
    ns = alarm.get("Namespace")
    mn = alarm.get("MetricName")
    if ns and mn:
        keys.add((str(ns), str(mn)))
    for mq in alarm.get("Metrics", []) or []:
        metric = mq.get("MetricStat", {}).get("Metric", {})
        ns = metric.get("Namespace")
        mn = metric.get("MetricName")
        if ns and mn:
            keys.add((str(ns), str(mn)))
    return keys


def _build_lambda_log_group_index(
    session, settings: Settings, records: list[dict[str, Any]]
) -> dict[tuple[str, str], str]:
    """Per-region map of `(region, function_name) → configured_log_group`.

    Uses `lambda:ListFunctions` to read the actual LoggingConfig.LogGroup,
    falling back to the canonical `/aws/lambda/<name>` when no override is
    set. Mirrors the helper in mapping.py.
    """
    regions: set[str] = set()
    for rec in records:
        if rec.get("service") == "lambda" and rec.get("resource_type") == "lambda:function":
            regions.add(str(rec.get("region") or settings.aws_region))

    index: dict[tuple[str, str], str] = {}
    for region in regions:
        try:
            client = session.client("lambda", region_name=region, config=default_boto_config())
            paginator = client.get_paginator("list_functions")
            for page in paginator.paginate():
                for fn in page.get("Functions", []):
                    name = fn.get("FunctionName")
                    if not name:
                        continue
                    logging_cfg = fn.get("LoggingConfig") or {}
                    custom_lg = logging_cfg.get("LogGroup")
                    canonical_lg = f"/aws/lambda/{name}"
                    index[(region, str(name))] = str(custom_lg or canonical_lg)
        except (BotoCoreError, ClientError) as exc:
            logger.warning("list_functions failed in region=%s: %s", region, exc)
            continue
    return index


def _build_log_group_index(records: list[dict[str, Any]]) -> dict[str, list[str]]:
    idx: dict[str, list[str]] = defaultdict(list)
    for rec in records:
        if rec.get("service") != "logs" or rec.get("resource_type") != "logs:log-group":
            continue
        arn = rec.get("arn")
        region = _str_or_empty(rec.get("region"))
        if isinstance(arn, str) and ":log-group:" in arn:
            idx[region].append(arn.split(":log-group:", 1)[1])
    return idx


def _build_alarm_details(
    session,
    settings: Settings,
    records: list[dict[str, Any]],
    log_groups_by_region: dict[str, list[str]],
) -> dict[str, list[dict[str, Any]]]:
    alarm_records = [
        r
        for r in records
        if r.get("service") == "cloudwatch" and r.get("resource_type") == "cloudwatch:alarm"
    ]

    metric_to_log_groups: dict[str, dict[tuple[str, str], set[str]]] = defaultdict(lambda: defaultdict(set))
    for region, lgs in log_groups_by_region.items():
        logs = session.client("logs", region_name=region or settings.aws_region, config=default_boto_config())
        for lg in lgs:
            try:
                paginator = logs.get_paginator("describe_metric_filters")
                for page in paginator.paginate(logGroupName=lg):
                    for mf in page.get("metricFilters", []):
                        for mt in mf.get("metricTransformations", []):
                            ns = mt.get("metricNamespace")
                            mn = mt.get("metricName")
                            if ns and mn:
                                metric_to_log_groups[region][(str(ns), str(mn))].add(lg)
            except (BotoCoreError, ClientError) as exc:
                # Per-log-group failure is non-fatal; record it and move on so a
                # single inaccessible group doesn't fail the whole coverage scan.
                logger.warning("describe_metric_filters failed for log_group=%s region=%s: %s", lg, region, exc)
                continue

    alarms_by_region: dict[str, list[dict[str, Any]]] = defaultdict(list)
    regions = {str(r.get("region") or settings.aws_region) for r in alarm_records}
    for region in regions:
        names: list[str] = []
        for rec in alarm_records:
            if str(rec.get("region") or settings.aws_region) != region:
                continue
            arn = rec.get("arn")
            if isinstance(arn, str) and ":alarm:" in arn:
                names.append(arn.split(":alarm:", 1)[1])
        if not names:
            continue
        cw = session.client("cloudwatch", region_name=region, config=default_boto_config())
        try:
            for batch in _chunked(names, 100):
                resp = cw.describe_alarms(AlarmNames=batch)
                for alarm in resp.get("MetricAlarms", []):
                    metric_keys = _extract_alarm_metric_keys(alarm)
                    linked_lgs: set[str] = set()
                    for key in metric_keys:
                        linked_lgs.update(metric_to_log_groups[region].get(key, set()))
                    actions_enabled = bool(alarm.get("ActionsEnabled", True))
                    alarm_actions = alarm.get("AlarmActions") or []
                    state_value = str(alarm.get("StateValue", ""))
                    if not actions_enabled:
                        actionable = False
                        degraded_reason: str | None = "actions_disabled"
                    elif not alarm_actions:
                        actionable = False
                        degraded_reason = "no_alarm_actions_configured"
                    elif state_value.upper() == "INSUFFICIENT_DATA":
                        actionable = False
                        degraded_reason = "insufficient_data"
                    else:
                        actionable = True
                        degraded_reason = None
                    alarms_by_region[region].append(
                        {
                            "alarm_name": alarm.get("AlarmName"),
                            "alarm_arn": alarm.get("AlarmArn"),
                            "dimensions": _extract_alarm_dimensions(alarm),
                            "metric_keys": metric_keys,
                            "linked_log_groups": linked_lgs,
                            "actions_enabled": actions_enabled,
                            "alarm_actions_count": len(alarm_actions),
                            "state_value": state_value,
                            "actionable": actionable,
                            "degraded_reason": degraded_reason,
                        }
                    )
        except (BotoCoreError, ClientError) as exc:
            # Skipping a region's alarm describe degrades coverage scoring for
            # that region only (resources there will look "uncovered"), which
            # is more useful than aborting the whole audit. Surfaced via logs.
            logger.warning("describe_alarms failed in region=%s: %s", region, exc)
            continue
    return alarms_by_region


def _collect_resources(
    session,
    settings: Settings,
    records: list[dict[str, Any]],
    log_groups_by_region: dict[str, list[str]],
    pack_checks: dict[str, list[dict[str, Any]]],
    lambda_lg_index: dict[tuple[str, str], str] | None = None,
) -> list[dict[str, Any]]:
    lambda_lg_index = lambda_lg_index or {}
    resources: list[dict[str, Any]] = []

    for rec in records:
        if rec.get("service") == "ecs" and rec.get("resource_type") == "ecs:service":
            arn = rec.get("arn")
            if not isinstance(arn, str):
                continue
            parsed = _parse_ecs_service_arn(arn)
            if not parsed:
                continue
            cluster_name, service_name = parsed
            region = str(rec.get("region") or settings.aws_region)
            task_definition_arn = None
            log_groups: set[str] = set()
            target_groups: list[str] = []

            ecs = session.client("ecs", region_name=region, config=default_boto_config())
            try:
                s = ecs.describe_services(cluster=cluster_name, services=[service_name]).get("services", [])
                if s:
                    task_definition_arn = s[0].get("taskDefinition")
                    for lb in s[0].get("loadBalancers", []) or []:
                        short = _target_group_short_form(lb.get("targetGroupArn", ""))
                        if short:
                            target_groups.append(short)
            except (BotoCoreError, ClientError) as exc:
                # Inability to introspect a single ECS service is non-fatal for the
                # coverage scan; we degrade gracefully by skipping this resource's
                # task-definition + log-group inference and continue.
                logger.warning("describe_services failed for cluster=%s service=%s: %s", cluster_name, service_name, exc)

            if task_definition_arn:
                try:
                    td = ecs.describe_task_definition(taskDefinition=task_definition_arn)
                    for c in td.get("taskDefinition", {}).get("containerDefinitions", []):
                        lg = c.get("logConfiguration", {}).get("options", {}).get("awslogs-group")
                        if lg:
                            log_groups.add(str(lg))
                except (BotoCoreError, ClientError) as exc:
                    logger.warning("describe_task_definition failed for %s: %s", task_definition_arn, exc)

            resources.append(
                {
                    "resource_kind": "ecs_service",
                    "region": region,
                    "resource_name": service_name,
                    "resource_arn": arn,
                    "dimensions": {"ClusterName": cluster_name, "ServiceName": service_name},
                    "log_groups": sorted(log_groups),
                    "target_group_short_forms": sorted(set(target_groups)),
                    "checks": _checks_for("ecs_service", pack_checks),
                }
            )

    for rec in records:
        if rec.get("service") == "lambda" and rec.get("resource_type") == "lambda:function":
            arn = rec.get("arn")
            if not isinstance(arn, str):
                continue
            fn = _parse_lambda_function_arn(arn)
            if not fn:
                continue
            region = str(rec.get("region") or settings.aws_region)
            # Canonical configured log group from list_functions (handles CDK/
            # Terraform LoggingConfig overrides). Falls back to the convention
            # if introspection failed.
            configured_lg = lambda_lg_index.get((region, fn)) or f"/aws/lambda/{fn}"
            resources.append(
                {
                    "resource_kind": "lambda_function",
                    "region": region,
                    "resource_name": fn,
                    "resource_arn": arn,
                    "dimensions": {"FunctionName": fn},
                    "log_groups": (
                        [configured_lg] if configured_lg in log_groups_by_region.get(region, []) else []
                    ),
                    "checks": _checks_for("lambda_function", pack_checks),
                }
            )

    for rec in records:
        if rec.get("service") == "rds" and rec.get("resource_type") == "rds:db":
            arn = rec.get("arn")
            if not isinstance(arn, str):
                continue
            db_id = _parse_rds_db_arn(arn)
            if not db_id:
                continue
            region = str(rec.get("region") or settings.aws_region)
            rds_lgs = _rds_log_groups_for_identifier(
                log_groups_by_region.get(region, []), db_id, "instance"
            )
            resources.append(
                {
                    "resource_kind": "rds_instance",
                    "region": region,
                    "resource_name": db_id,
                    "resource_arn": arn,
                    "dimensions": {"DBInstanceIdentifier": db_id},
                    "log_groups": sorted(rds_lgs),
                    "checks": _checks_for("rds_instance", pack_checks),
                }
            )

    for rec in records:
        if rec.get("service") == "rds" and rec.get("resource_type") == "rds:cluster":
            arn = rec.get("arn")
            if not isinstance(arn, str):
                continue
            cluster_id = _parse_rds_cluster_arn(arn)
            if not cluster_id:
                continue
            region = str(rec.get("region") or settings.aws_region)
            cluster_lgs = _rds_log_groups_for_identifier(
                log_groups_by_region.get(region, []), cluster_id, "cluster"
            )
            # Aurora clusters share the AWS/RDS pack metric names, but they're
            # keyed by DBClusterIdentifier — fall back to the rds_instance pack
            # if no rds_cluster pack section is defined yet, so we still score
            # something rather than 0% silently.
            cluster_checks = _checks_for("rds_cluster", pack_checks)
            if not cluster_checks:
                cluster_checks = _checks_for("rds_instance", pack_checks)
            resources.append(
                {
                    "resource_kind": "rds_cluster",
                    "region": region,
                    "resource_name": cluster_id,
                    "resource_arn": arn,
                    "dimensions": {"DBClusterIdentifier": cluster_id},
                    "log_groups": sorted(cluster_lgs),
                    "checks": cluster_checks,
                }
            )

    for rec in records:
        if rec.get("service") == "sqs" and rec.get("resource_type") == "sqs:queue":
            arn = rec.get("arn")
            if not isinstance(arn, str):
                continue
            queue_name = _parse_sqs_queue_arn(arn)
            if not queue_name:
                continue
            region = str(rec.get("region") or settings.aws_region)
            resources.append(
                {
                    "resource_kind": "sqs_queue",
                    "region": region,
                    "resource_name": queue_name,
                    "resource_arn": arn,
                    "dimensions": {"QueueName": queue_name},
                    "log_groups": [],
                    "checks": _checks_for("sqs_queue", pack_checks),
                }
            )

    resources.sort(key=lambda r: (r["region"], r["resource_kind"], r["resource_name"]))
    return resources


def _match_metric(
    alarm_metric_keys: set[tuple[str, str]],
    namespace: str,
    metric_any: list[str] | None,
    metric_all: list[str] | None,
) -> bool:
    if metric_all:
        required = {(namespace, m) for m in metric_all}
        return required.issubset(alarm_metric_keys)
    if metric_any:
        required = {(namespace, m) for m in metric_any}
        return any(r in alarm_metric_keys for r in required)
    return any(ns == namespace for ns, _ in alarm_metric_keys)


def _evaluate_check(resource: dict[str, Any], check: dict[str, Any], alarms: list[dict[str, Any]]) -> dict[str, Any]:
    namespace = check["namespace"]
    metric_any = check.get("metric_any")
    metric_all = check.get("metric_all")
    match_linked_log_group_only = bool(check.get("match_linked_log_group_only", False))
    dims = resource.get("dimensions", {})
    res_name = resource.get("resource_name", "")
    res_log_groups = set(resource.get("log_groups", []))
    res_target_groups = set(resource.get("target_group_short_forms", []))

    best = {
        "status": "MISSING",
        "confidence": None,
        "strategy": None,
        "alarm_name": None,
        "alarm_arn": None,
        "degraded_reason": None,
    }

    def consider(alarm: dict[str, Any], confidence: str, strategy: str) -> None:
        nonlocal best
        if CONFIDENCE_RANK[confidence] > CONFIDENCE_RANK.get(best["confidence"], 0):
            actionable = bool(alarm.get("actionable", True))
            # An alarm that exists but won't notify (disabled / no SNS target /
            # INSUFFICIENT_DATA for the demo audit) provides zero of the value
            # the customer is paying for. Surface as DEGRADED so it's visible
            # but does NOT count toward `required_checks_met`.
            best = {
                "status": "PRESENT" if actionable else "DEGRADED",
                "confidence": confidence,
                "strategy": strategy,
                "alarm_name": alarm.get("alarm_name"),
                "alarm_arn": alarm.get("alarm_arn"),
                "degraded_reason": alarm.get("degraded_reason"),
            }

    for alarm in alarms:
        alarm_dims = alarm.get("dimensions", {})
        alarm_metric_keys = alarm.get("metric_keys", set())
        alarm_lgs = set(alarm.get("linked_log_groups", set()))

        if match_linked_log_group_only:
            if res_log_groups and alarm_lgs.intersection(res_log_groups):
                consider(alarm, "HIGH", "metric_filter_to_log_group_linkage")
            continue

        if not _match_metric(alarm_metric_keys, namespace, metric_any, metric_all):
            continue

        if dims and all(alarm_dims.get(k) == v for k, v in dims.items()):
            consider(alarm, "HIGH", "exact_dimension_match")
            continue

        # ALB → ECS bridge: alarm scopes by TargetGroup ARN, which we
        # cross-reference back to the ECS service via its registered
        # load-balancer attachments. Exact-ARN equality, no false-positive risk.
        alarm_target_group = alarm_dims.get("TargetGroup", "")
        if res_target_groups and alarm_target_group and alarm_target_group in res_target_groups:
            consider(alarm, "HIGH", "alb_target_group_to_ecs_service")
            continue

        if dims and any(alarm_dims.get(k) == v for k, v in dims.items()):
            consider(alarm, "MEDIUM", "metric_namespace_plus_key_dimensions")

        if res_log_groups and alarm_lgs.intersection(res_log_groups):
            consider(alarm, "MEDIUM", "metric_filter_to_log_group_linkage")

        if res_name and res_name in _str_or_empty(alarm.get("alarm_name")):
            consider(alarm, "LOW", "naming_heuristic")

    return {
        "check_id": check["id"],
        "title": check["title"],
        "business_impact": check.get("business_impact", ""),
        "domain": check.get("domain", "infra"),
        "mode": check.get("mode", "auto"),
        "severity": check.get("severity", "P3"),
        "needs_input": check.get("needs_input", []),
        "required": bool(check.get("required", True)),
        **best,
    }


def score_alarm_coverage(settings: Settings, records: list[dict[str, Any]]) -> CoverageResult:
    session = _make_session(settings)
    pack_checks, pack_source = _load_alarm_pack()
    log_groups_by_region = _build_log_group_index(records)
    alarms_by_region = _build_alarm_details(session, settings, records, log_groups_by_region)
    lambda_lg_index = _build_lambda_log_group_index(session, settings, records)
    resources = _collect_resources(
        session, settings, records, log_groups_by_region, pack_checks, lambda_lg_index
    )

    coverage_resources: list[dict[str, Any]] = []
    total_required = 0
    total_required_met = 0
    total_optional = 0
    total_optional_met = 0

    for r in resources:
        checks = []
        alarms = alarms_by_region.get(r["region"], [])
        for check in r["checks"]:
            out = _evaluate_check(r, check, alarms)
            checks.append(out)

            if out["required"]:
                total_required += 1
                if out["status"] == "PRESENT":
                    total_required_met += 1
            else:
                total_optional += 1
                if out["status"] == "PRESENT":
                    total_optional_met += 1

        required_total = sum(1 for c in checks if c["required"])
        required_met = sum(1 for c in checks if c["required"] and c["status"] == "PRESENT")
        optional_total = sum(1 for c in checks if not c["required"])
        optional_met = sum(1 for c in checks if not c["required"] and c["status"] == "PRESENT")
        score = round((required_met / required_total) * 100, 2) if required_total else 100.0

        coverage_resources.append(
            {
                "resource_kind": r["resource_kind"],
                "region": r["region"],
                "resource_name": r["resource_name"],
                "resource_arn": r["resource_arn"],
                "log_groups": r["log_groups"],
                "required_total": required_total,
                "required_met": required_met,
                "required_score_pct": score,
                "optional_total": optional_total,
                "optional_met": optional_met,
                "checks": checks,
            }
        )

    overall_required_score = round((total_required_met / total_required) * 100, 2) if total_required else 100.0

    summary = {
        "resource_count_scored": len(coverage_resources),
        "required_checks_total": total_required,
        "required_checks_met": total_required_met,
        "required_coverage_score_pct": overall_required_score,
        "optional_checks_total": total_optional,
        "optional_checks_met": total_optional_met,
        "alarm_pack_source": pack_source,
    }

    return CoverageResult(resources=coverage_resources, summary=summary)
