# Code of Conduct

This project adopts the [Contributor Covenant, version 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/) as its code of conduct.

In short: be respectful, assume good intent, give and accept constructive feedback. The full text is at the link above.

## Scope

Applies to all project spaces — GitHub issues and PRs, discussions, and any direct communication conducted in connection with the project.

## Reporting

Conduct concerns can be reported privately to <founders@opsfabric.ai>. Reports are handled confidentially. We respond within 5 business days.

Maintainers commit to a fair investigation and to enforcing the Contributor Covenant's [enforcement guidelines](https://www.contributor-covenant.org/version/2/1/code_of_conduct/#enforcement-guidelines).
