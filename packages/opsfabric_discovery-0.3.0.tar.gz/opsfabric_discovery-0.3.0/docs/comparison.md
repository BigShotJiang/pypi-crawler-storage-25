# DiscoveryFabric vs AlarmFabric vs OpsFabric

OpsFabric is a three-layer reliability platform. Only the first layer is open source.

| Capability | DiscoveryFabric (OSS) | AlarmFabric (paid) | OpsFabric (paid) |
|---|:---:|:---:|:---:|
| Read-only audit | ✅ | ✅ | ✅ |
| Resource discovery (ECS / Lambda / RDS / Aurora / SQS) | ✅ | ✅ | ✅ |
| Five-strategy alarm matching | ✅ | ✅ | ✅ |
| DEGRADED alarm detection | ✅ | ✅ | ✅ |
| Executive PDF + JSON output | ✅ | ✅ | ✅ |
| `--demo` synthetic walkthrough | ✅ | ✅ | ✅ |
| Cross-account audits via STS AssumeRole | ✅ | ✅ | ✅ |
| **Create missing alarms in your account** | ❌ | ✅ | ✅ |
| Tagged + reversible alarm provenance | ❌ | ✅ | ✅ |
| SNS / PagerDuty / Opsgenie wiring | ❌ | ✅ | ✅ |
| Scheduled / continuous audits | ❌ | ✅ | ✅ |
| Drift detection between scans | ❌ | ✅ | ✅ |
| Auto-cleanup of orphan alarms (deleted resources) | ❌ | ✅ | ✅ |
| Slack-based incident triage | ❌ | ❌ | ✅ |
| Automated root-cause analysis | ❌ | ❌ | ✅ |
| Remediation suggestions with HIL gate | ❌ | ❌ | ✅ |
| Jira / Confluence incident lifecycle | ❌ | ❌ | ✅ |
| GitHub PR for app-side fixes | ❌ | ❌ | ✅ |
| Multi-tenant managed SaaS | ❌ | ✅ | ✅ |
| Pricing | Free (MIT) | [opsfabric.ai](https://opsfabric.ai) | [opsfabric.ai](https://opsfabric.ai) |

---

## Row-by-row, what each capability means

### Read-only audit

**All three products run the same audit code.** DiscoveryFabric publishes that audit as an open-source CLI; AlarmFabric and OpsFabric run it on a schedule against your account and persist the results in their managed dashboards.

### Resource discovery — ECS / Lambda / RDS / Aurora / SQS

The baseline pack covers the five AWS resource kinds most mid-market production stacks rely on. Future resource types (EKS, DynamoDB, API Gateway, Step Functions) land in DiscoveryFabric first if they're driven by community contribution, and in AlarmFabric / OpsFabric first if a paying customer needs them.

### Five-strategy alarm matching

Exact dimension match → ALB target-group bridge for ECS → namespace + partial dimension → metric-filter → log-group linkage → naming heuristic. First hit wins. Identical across all three products — the matching logic is open source so customers can audit how their alarms get attributed.

### DEGRADED alarm detection

An alarm that exists but won't actually notify (actions disabled, no SNS target, or stuck in INSUFFICIENT_DATA) is the most credibility-damaging false positive in audit tools. DiscoveryFabric surfaces these as a distinct state — not counted toward coverage. Same logic shared by all three products.

### Executive PDF + JSON output

The 3-page WeasyPrint PDF and the per-artifact JSON files (`alarm-coverage-score.json`, `resource-mapping.json`, etc.) are produced by the OSS code. AlarmFabric and OpsFabric add a hosted dashboard view on top.

### `--demo` synthetic walkthrough

Lets a prospect see what their audit would look like without granting AWS access. Open-source bait for the funnel; same flag works in AlarmFabric's evaluation mode.

### Cross-account audits via STS AssumeRole

`--assume-role-arn` + `--external-id` on the OSS CLI. AlarmFabric / OpsFabric automate the role provisioning via Terraform / CloudFormation templates and rotate credentials on a schedule.

### Create missing alarms in your account — *paid only*

This is the line. DiscoveryFabric tells you what's missing; it intentionally does **not** create alarms. AlarmFabric reads the audit JSON and applies the alarms via a write-scoped role you provision. Provenance tag (`opsfabric:source=alarmfabric-vN`) on every alarm so you can list and roll back as one set.

### Tagged + reversible alarm provenance — *paid only*

Every alarm AlarmFabric creates carries metadata: which audit produced it, which version of the alarm pack was used, which run ID, who approved. Lets you ask "show me everything OpsFabric created in the last 30 days" and remove them as one transaction. Manual CloudWatch authoring doesn't get you this.

### SNS / PagerDuty / Opsgenie wiring — *paid only*

The alarms aren't useful without notification targets. AlarmFabric wires each created alarm to your existing SNS topic / PagerDuty service / Opsgenie team based on a per-resource routing config. DiscoveryFabric leaves this for the user to handle (or for AlarmFabric).

### Scheduled / continuous audits — *paid only*

DiscoveryFabric is a one-shot CLI. Run it again to get a fresh audit. AlarmFabric / OpsFabric persist the run history, detect drift between consecutive audits, and notify when coverage regresses below a configurable threshold.

### Drift detection between scans — *paid only*

"You shipped 12 new Lambdas this week; 11 are uncovered." That delta is in the OSS `changes` subcommand at a basic level, but the timeseries view and the notifications are paid.

### Auto-cleanup of orphan alarms — *paid only*

When a resource is deleted, its alarms linger and start firing on missing data. AlarmFabric detects these and offers a one-click delete pass.

### Slack-based incident triage — *OpsFabric only*

A CloudWatch alarm fires → AlarmFabric routes it to Slack → OpsFabric's incident-response agent posts the initial triage (which logs to fetch, recent deploys, related alarms in the same time window). The audit / alarm-creation products don't do this.

### Automated root-cause analysis — *OpsFabric only*

LangGraph-driven agent that ingests CloudWatch logs, Terraform state, and the recent Git history of the affected service, then proposes an RCA in plain language. Closed source.

### Remediation suggestions with HIL gate — *OpsFabric only*

After RCA, OpsFabric proposes a remediation (scale up the ECS service, restart the Lambda function, roll back a recent deploy). Every destructive action is gated behind a human-in-the-loop approval in Slack.

### Jira / Confluence incident lifecycle — *OpsFabric only*

Auto-creates a Jira incident on alarm firing, posts updates as triage progresses, generates a Confluence post-mortem doc on resolution. The audit doesn't touch ticketing.

### GitHub PR for app-side fixes — *OpsFabric only*

When the RCA suggests a code-level fix (e.g. a missing null check that's been the root cause of 3 incidents this month), OpsFabric clones the repo, makes the change, and opens a PR with the incident-link in the description.

### Multi-tenant managed SaaS — *paid only*

DiscoveryFabric runs on your laptop. AlarmFabric and OpsFabric run on our infrastructure with proper tenant isolation, SSO, audit logs, and a 99.9% availability SLA.

---

## Why this split?

Three reasons:

1. **The audit should be free.** Tools that gate the audit behind a paid plan have terrible signup conversion — SREs sniff out the bait. DiscoveryFabric is fully featured and MIT-licensed precisely so the funnel is honest.
2. **The remediation is where the leverage is.** Knowing you're missing 40 alarms is one thing. Actually creating them in a way that won't paginate someone for noise is another — and that's where the IP lives.
3. **Incident response demands a managed surface.** OpsFabric needs to be running 24/7, hold credentials for Slack / Jira / GitHub, and present a multi-tenant dashboard. Not a CLI shape; not an open-source shape; a SaaS shape.

If you're considering AlarmFabric or OpsFabric for your team, email <founders@opsfabric.ai> — we run short evaluations against a sandbox account first.
