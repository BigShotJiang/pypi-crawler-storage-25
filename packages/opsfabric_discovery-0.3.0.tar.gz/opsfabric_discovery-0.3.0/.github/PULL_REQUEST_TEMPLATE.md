<!--
Thanks for sending a PR. Quick checklist below — the green-or-not status keeps
the merge loop fast.
-->

## What this changes

<!-- One or two sentences. What does this PR do? -->

## Why

<!-- Link the related issue if there is one. If not, briefly explain the motivation. -->

Fixes #<!-- issue number, if any -->

## How it was tested

- [ ] `uv run pytest` passes locally
- [ ] `uv run ruff check .` passes locally
- [ ] If touching the audit / matching logic, `opsfabric-discovery audit --demo` still produces the expected PDF
- [ ] If touching cross-account logic, smoke-tested against a real AWS account (one-line description below)

<!-- Optional: paste any new test output or screenshots. -->

## Checklist

- [ ] New code paths have tests (unit at minimum; integration if AWS-touching)
- [ ] `CHANGELOG.md` updated under `## [Unreleased]`
- [ ] No new runtime dependencies (or, if there are, justified in the PR description)
- [ ] No version bump (maintainers handle releases)
- [ ] Docs / README updated if user-visible behaviour changed
