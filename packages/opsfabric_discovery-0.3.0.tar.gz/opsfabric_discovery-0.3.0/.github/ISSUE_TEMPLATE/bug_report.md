---
name: Bug report
about: Something isn't behaving the way the docs say it should
title: "[bug] "
labels: bug
assignees: ''
---

## What happened

<!-- One or two sentences. What did you run, and what was the unexpected behaviour? -->

## What you expected

<!-- One or two sentences. -->

## Reproduction

```bash
# The exact command you ran (with any secrets redacted).
opsfabric-discovery audit ...
```

Output (redact ARNs / account IDs if needed):

```
<paste the relevant output here>
```

## Does `--demo` reproduce it?

- [ ] `opsfabric-discovery audit --demo` reproduces the same issue
- [ ] `--demo` works fine; the bug only triggers against a real AWS account
- [ ] N/A — the bug is in the install / packaging, not the audit itself

## Environment

- `opsfabric-discovery --version`: <!-- e.g. 0.3.0 -->
- Python version: <!-- `python --version` -->
- Operating system: <!-- e.g. macOS 14.5, Ubuntu 22.04 -->
- Install method: <!-- pip / uv tool / Docker / pipx -->
- AWS region(s) scanned:

## Anything else

<!-- Stack trace? Logs? Screenshot of the PDF? Anything else that helps us reproduce. -->
