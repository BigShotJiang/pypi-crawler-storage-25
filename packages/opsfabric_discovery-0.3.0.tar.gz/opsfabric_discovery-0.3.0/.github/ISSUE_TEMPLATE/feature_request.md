---
name: Feature request
about: Suggest a new resource type, alarm-pack check, or audit capability
title: "[feature] "
labels: enhancement
assignees: ''
---

## What problem are you trying to solve

<!-- The audit / coverage gap you've hit. E.g. "we run DynamoDB heavily and the audit ignores it." -->

## What you'd like to see

<!-- The shape of the feature. E.g. "Add a `dynamodb_table` resource kind with `SystemErrors` / `UserErrors` / `ThrottledRequests` required checks." -->

## Why now / who benefits

<!-- Is this a niche edge case, or would 100+ teams want this? Helps us prioritise. -->

## Scope check

Before submitting, please confirm this is in scope for the open-source audit:

- [ ] My request is a new **resource type** (e.g. DynamoDB, EKS), **alarm-pack check**, **matching strategy improvement**, or **output / CLI ergonomic**.
- [ ] My request is **not** about live alarm creation, incident triage, RCA, or runtime Slack/Jira integrations. (Those belong to the commercial [AlarmFabric / OpsFabric](https://opsfabric.ai) products. Email <founders@opsfabric.ai> for those conversations.)

## Anything else

<!-- Links, AWS docs, prior art in other audit tools, etc. -->
