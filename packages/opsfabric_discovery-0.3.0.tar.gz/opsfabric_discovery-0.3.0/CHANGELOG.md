# Changelog

All notable changes to `opsfabric-discovery` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] — 2026-05-15

First release shaped for public consumption (repo visibility still private, but PyPI publish is world-readable as always).

### Added
- Test suite: unit tests for ARN parsers, matching strategies, alarm-pack loader, alarm actionability detection, and RDS log-group regex. One integration test that runs `audit --demo` and asserts the full artifact set is produced. 55 tests, ~2 second run time.
- `opsfabric-discovery --about` CLI command that prints the OpsFabric product context (DiscoveryFabric / AlarmFabric / OpsFabric) and where to learn more.
- Dev tooling: pytest + ruff configured in `pyproject.toml` with a `dev` dependency group; lint passes cleanly on the whole tree.
- `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`, `CHANGELOG.md`, issue + PR templates, and `FUNDING.yml`.
- New `docs/comparison.md` covering DiscoveryFabric (open source) vs AlarmFabric / OpsFabric (commercial). Linked from the README and from the `--about` output.

### Changed
- Domain references updated from `opsfabric.com` to `opsfabric.ai` everywhere (PDF CTA, README, contributing docs).
- README rewritten for OSS-first audience: badges, hero block, trust statement, install / quickstart, open-source vs commercial comparison, About OpsFabric section, contributing pointer.

### Removed
- `bin/sync-from-monorepo.sh` retired. Going forward this repo is the source of truth; the internal monorepo at `discovery-fabric/` is a legacy copy maintained for the AlarmFabric demo flow only.

## [0.2.1] — 2026-05-13

### Changed
- README cleaned for public PyPI page: dropped monorepo references, the internal "stage 1 build" line, the matching-strategies one-paragraph explainer, and the "What's NOT in this build" section.
- Trust statement now includes the explicit minimum-IAM permission list inline.

## [0.2.0] — 2026-05-13

### Added
- `--demo` flag on the `audit` subcommand. Loads a baked-in synthetic dataset (`data/demo_score.json`) and renders the same PDF + JSON outputs as a real audit. No AWS credentials required.
- SQS queue support: alarm pack section (`sqs_queue`) with required infra checks (`ApproximateAgeOfOldestMessage`, `ApproximateNumberOfMessagesVisible`) plus optional application checks (in-flight stuck, send-throttling, DLQ visibility).
- Aurora cluster support: parser for `:cluster:` ARNs, `DBClusterIdentifier` dimension routing, new pack section with Aurora-specific metrics (`AuroraReplicaLag`, `FreeLocalStorage`, etc.).
- DEGRADED alarm detection: alarms that exist but won't notify (actions disabled, no SNS target, or stuck in INSUFFICIENT_DATA) are surfaced as `DEGRADED` and do not count toward coverage. Visible as separate cards in the PDF.
- ALB → ECS bridge matching strategy: when an alarm uses the `TargetGroup` dimension, we cross-reference back to the ECS service via its registered load-balancer attachments. HIGH-confidence match, exact ARN equality, no false-positive risk.
- Canonical Lambda log-group resolution via `lambda:ListFunctions` `LoggingConfig.LogGroup` — handles CDK / Terraform setups that override the default `/aws/lambda/<name>` convention.

### Changed
- RDS log-group matching tightened from substring to anchored regex (`^/aws/rds/(instance|cluster)/<exact-id>/`). Prevents `payments` from accidentally claiming `payments-replica` log groups.
- PDF CTA copy rewritten for self-service distribution.
- PDF "Critical gaps" cap lowered from 8 to 6 so the disclaimer footer no longer orphans on a fourth page.
- `audit` command now also writes `resource-mapping.json` alongside the score and missing files. One run = all artifacts.
- `audit-meta.json` now persists `account_alias` so the PDF re-renders with the correct customer label.

### Fixed
- PDF header alignment: hero number + grade pill no longer overlap on tall headlines.
- DEGRADED reasons now propagate through `_evaluate_check` into the PDF copy so the per-gap description names the actual problem (disabled vs no SNS vs INSUFFICIENT_DATA).

## [0.1.0] — 2026-05-13

Initial private build.

### Added
- CLI for AWS resource discovery via Resource Explorer 2.
- Alarm coverage scoring against a YAML-defined alarm pack.
- Five-strategy matching (exact-dim, namespace + partial-dim, metric-filter → log-group linkage, naming heuristic; ALB bridge added in 0.2.0).
- Executive PDF rendering via WeasyPrint with a baseline pack covering ECS, Lambda, and RDS instances.
- Cross-account `--assume-role-arn` + `--external-id` flags.
- Automatic region discovery via `--regions all`.
- Graceful per-region failure handling (skip + log rather than abort).
- Boto3 retry / backoff config and per-service IAM gap tolerance.
- MIT license.

[Unreleased]: https://github.com/OpsFabric/opsfabric-discovery-pkg/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/OpsFabric/opsfabric-discovery-pkg/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/OpsFabric/opsfabric-discovery-pkg/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/OpsFabric/opsfabric-discovery-pkg/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/OpsFabric/opsfabric-discovery-pkg/releases/tag/v0.1.0
