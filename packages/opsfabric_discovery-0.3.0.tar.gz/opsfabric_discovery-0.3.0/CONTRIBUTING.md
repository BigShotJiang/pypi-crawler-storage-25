# Contributing to opsfabric-discovery

Thanks for your interest. This is a small, focused tool — we keep the contribution loop short so changes ship quickly.

## What's in scope

The OSS audit pipeline:

- Resource discovery (new AWS resource kinds, broader namespace coverage)
- Alarm-coverage matching strategies and their accuracy
- Alarm pack additions for under-covered services (DynamoDB, ApiGateway, EKS, etc.)
- Output polish (PDF layout, JSON shape, CLI ergonomics)
- Testing, CI, performance, and developer experience
- Bug fixes

## What's intentionally out of scope

These belong to the commercial companion products (AlarmFabric, OpsFabric):

- **Live alarm creation** in customer accounts (PRs that wrap `cloudwatch:PutMetricAlarm` will be closed — that's [AlarmFabric](https://opsfabric.ai))
- **Incident triage / RCA / remediation logic** — that's [OpsFabric](https://opsfabric.ai)
- **Slack / Jira / PagerDuty integrations** for runtime incident response
- **Multi-tenant SaaS hosting** of the audit

Please open a feature request before adding a new resource type or matching strategy, so we can confirm it fits the project's direction.

## Dev setup

You'll need [`uv`](https://docs.astral.sh/uv/) (preferred) or any Python 3.11+ environment with `pip`.

```bash
git clone git@github.com:OpsFabric/opsfabric-discovery-pkg.git
cd opsfabric-discovery-pkg
uv sync --dev          # installs runtime + test deps into .venv
uv run opsfabric-discovery audit --demo
```

The repo runs against a baked-in synthetic dataset via `--demo`, so you don't need AWS credentials to develop or test most changes.

## Running tests

```bash
uv run pytest                   # all tests
uv run pytest tests/unit        # fast unit tests only
uv run pytest -x -v             # stop on first failure, verbose
uv run pytest --cov             # with coverage
```

## Linting

```bash
uv run ruff check .             # report issues
uv run ruff check --fix .       # auto-fix what's safe
uv run ruff format .            # format code
```

Please run both locally before opening a PR — `uv run pytest` and `uv run ruff check .` should be clean.

## Adding a new resource type

The matcher's five strategies are in [`discovery_fabric/aws/mapping.py`](discovery_fabric/aws/mapping.py). To add (say) DynamoDB:

1. **ARN parser** — add `_parse_dynamodb_table_arn` next to the other parsers.
2. **Collector** — add `_collect_dynamodb_resources` that builds the resource records with `dimension_values = {"TableName": ...}` and `expected_namespace = "AWS/DynamoDB"`.
3. **Hook in** — call your collector from `build_resource_mapping` in `mapping.py` and from `_collect_resources` in [`discovery_fabric/aws/alarm_coverage.py`](discovery_fabric/aws/alarm_coverage.py).
4. **Pack** — add a `dynamodb_table` section to [`discovery_fabric/data/alarm_pack.yaml`](discovery_fabric/data/alarm_pack.yaml) with the required checks (`SystemErrors`, `UserErrors`, `ThrottledRequests`, etc.) — each with a `business_impact` string.
5. **Label maps** — add `dynamodb_table: "DynamoDB table"` to `_RESOURCE_KIND_LABELS` in [`discovery_fabric/output/pdf_report.py`](discovery_fabric/output/pdf_report.py).
6. **Demo data** — extend [`scripts/build_demo_data.py`](scripts/build_demo_data.py) (if it gets ported) so `--demo` exercises the new kind.
7. **Tests** — add cases to `tests/unit/test_arn_parsers.py` for the new ARN format.
8. **CHANGELOG** — add an entry under the next release.

## PR conventions

- **One change per PR.** Bug fix + new feature → two PRs.
- **Tests included.** New code path → new test. Bug fix → regression test.
- **CHANGELOG entry.** Under `## [Unreleased]` in `CHANGELOG.md`. Keep it customer-facing — "fix substring collision in RDS log-group matching" not "refactor `_collect_rds_resources` for clarity."
- **No version bumps.** Maintainers handle releases.
- **No dependency additions without discussion.** Open an issue first if you need a new runtime dep.

## Commit messages

```
<short imperative summary, ≤ 70 chars>

<optional body with context, wrapped at 72 chars>

<optional fixes line>
Fixes #123
```

Example:

```
Tighten RDS log-group matching to anchored regex

Substring matching attributed `payments-replica` log groups to
`payments` instances. Move to a regex anchored on the AWS path
structure (/aws/rds/{instance,cluster}/{exact-id}/) so same-prefix
identifiers no longer collide.

Fixes #87
```

## Releasing (maintainers only)

```bash
# 1. Bump version in pyproject.toml + add CHANGELOG entry under the new version
# 2. Build and publish to PyPI
uv build
uv publish --token "$PYPI_API_TOKEN"
# 3. Commit and tag
git commit -am "Release vX.Y.Z"
git tag vX.Y.Z
git push origin main --tags
```

## Reporting bugs

Open an issue using the **Bug Report** template. Include:

- `opsfabric-discovery --version`
- The exact command you ran (with secrets redacted)
- The full error output / stack trace
- Whether `audit --demo` reproduces the issue (most bugs that aren't AWS-API-specific will)

## Security issues

Don't open public issues for security bugs. See [SECURITY.md](SECURITY.md) for the disclosure process.

## Code of conduct

By participating, you agree to follow our [Code of Conduct](CODE_OF_CONDUCT.md).

## Questions

For technical questions about the OSS tool: GitHub Discussions or issues.
For commercial questions about AlarmFabric / OpsFabric: <founders@opsfabric.ai>.
