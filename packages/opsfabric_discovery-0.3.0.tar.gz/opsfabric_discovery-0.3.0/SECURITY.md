# Security policy

## Reporting a vulnerability

Please report security issues privately to <founders@opsfabric.ai>.

Do **not** open public GitHub issues for security-impacting bugs.

We aim to:
- Acknowledge your report within **2 business days**
- Provide a status update within **7 business days**
- Issue a fix and public advisory within **90 days** of the initial report

If you discover a vulnerability while running the tool against a real AWS account, the fastest fix is usually:
1. Email us with the details
2. We respond with a workaround and a patch ETA
3. Once patched, we coordinate the disclosure timeline with you

## Scope

In scope:
- Bugs in `opsfabric-discovery` itself that could enable unauthorised AWS access, credential leakage, or arbitrary code execution on the runner
- Bundled dependencies (we'll triage and upstream as appropriate)
- The published wheel on PyPI (supply-chain integrity)

Out of scope:
- Issues that require the attacker to already have AWS access equivalent to the audit's IAM policy (it's read-only by design)
- Findings about CloudWatch alarm coverage on your account — those are audit results, not security bugs in the tool
- Issues in AlarmFabric / OpsFabric (commercial products) — report those directly via the same email

## What we ship to mitigate supply-chain risk

- Releases are tagged in GitHub and published to PyPI from CI using a project-scoped token
- The `LICENSE` and wheel metadata are checked into the repo, not generated dynamically
- No telemetry. No phone-home. No network calls except the AWS APIs the user explicitly invokes
- Source is open: every AWS call the tool makes is grep-able in `discovery_fabric/aws/`

## Disclosure credit

Security researchers who report valid issues will be credited in the changelog (with their permission) once the fix has shipped.
