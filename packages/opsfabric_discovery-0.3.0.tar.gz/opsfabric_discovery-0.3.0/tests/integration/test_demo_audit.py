"""End-to-end integration test for `opsfabric-discovery audit --demo`.

Spawns the CLI as a subprocess (mimics how a customer would actually run it),
then asserts the full artifact set lands in the output directory with the
right shape. If this passes, the install path and the audit pipeline are
both green; if it fails, the CLI is fundamentally broken.

Runs in CI on every PR. Should complete in < 5 seconds.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest


@pytest.fixture
def output_dir(tmp_path: Path) -> Path:
    d = tmp_path / "out"
    d.mkdir()
    yield d
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def cli_runner():
    """Invoke the CLI via `python -m discovery_fabric.cli` so the test runs
    against the source under test, not whatever's installed on PATH."""
    repo_root = Path(__file__).resolve().parents[2]

    def _run(args: list[str], cwd: Path) -> subprocess.CompletedProcess:
        env = os.environ.copy()
        # Ensure the test's PYTHONPATH includes the repo so `python -m` finds
        # the package even when invoked from a tmp working directory.
        env["PYTHONPATH"] = str(repo_root) + os.pathsep + env.get("PYTHONPATH", "")
        return subprocess.run(
            [sys.executable, "-m", "discovery_fabric.cli", *args],
            cwd=cwd,
            env=env,
            capture_output=True,
            text=True,
            timeout=60,
        )

    return _run


class TestDemoAudit:
    def test_demo_audit_produces_full_artifact_set(self, cli_runner, output_dir, tmp_path):
        """The complete happy path: run --demo, assert each artifact exists
        and parses correctly."""
        result = cli_runner(
            ["audit", "--demo", "--output-dir", str(output_dir)],
            cwd=tmp_path,
        )
        assert result.returncode == 0, (
            f"audit --demo exited non-zero: stdout={result.stdout!r} stderr={result.stderr!r}"
        )

        # PDF
        pdfs = list(output_dir.glob("audit-demo*.pdf"))
        # The cli writes to "audit-demo.pdf" by default; allow either shape
        if not pdfs:
            pdfs = list(output_dir.glob("*.pdf"))
        assert len(pdfs) >= 1, f"No PDF found in {output_dir}: {list(output_dir.iterdir())}"
        assert pdfs[0].stat().st_size > 5000, "PDF is suspiciously small"

        # Score JSON
        score_path = output_dir / "alarm-coverage-score.json"
        assert score_path.exists(), "alarm-coverage-score.json missing"
        score = json.loads(score_path.read_text())
        assert "summary" in score and "resources" in score
        # Demo dataset is designed to score ~25.5% — confirm we got close
        coverage = score["summary"]["required_coverage_score_pct"]
        assert 20.0 <= coverage <= 30.0, (
            f"Demo coverage {coverage}% is outside the expected 20–30% band; "
            "either the demo dataset or the scoring logic has drifted."
        )

        # Audit metadata (with demo flag set)
        meta_path = output_dir / "audit-meta.json"
        assert meta_path.exists()
        meta = json.loads(meta_path.read_text())
        assert meta.get("demo") is True
        assert meta.get("account_id") == "123456789012"

        # Missing-checks JSON
        missing_path = output_dir / "alarm-coverage-missing.json"
        assert missing_path.exists()
        missing = json.loads(missing_path.read_text())
        assert "missing_resources" in missing
        assert missing.get("count", 0) > 0, "Demo dataset should have at least one missing required check"

    def test_demo_audit_does_not_call_aws(self, cli_runner, output_dir, tmp_path, monkeypatch):
        """Sanity check: --demo must not need AWS credentials. We strip the
        AWS_* env vars and confirm the audit still completes."""
        monkeypatch.delenv("AWS_PROFILE", raising=False)
        monkeypatch.delenv("AWS_ACCESS_KEY_ID", raising=False)
        monkeypatch.delenv("AWS_SECRET_ACCESS_KEY", raising=False)

        result = cli_runner(
            ["audit", "--demo", "--output-dir", str(output_dir)],
            cwd=tmp_path,
        )
        assert result.returncode == 0, (
            f"audit --demo failed without AWS creds: {result.stderr!r}"
        )

    def test_about_flag(self, cli_runner, tmp_path):
        """--about should print the product context and exit cleanly."""
        result = cli_runner(["--about"], cwd=tmp_path)
        assert result.returncode == 0
        assert "DiscoveryFabric" in result.stdout
        assert "AlarmFabric" in result.stdout
        assert "OpsFabric" in result.stdout
        assert "opsfabric.ai" in result.stdout
