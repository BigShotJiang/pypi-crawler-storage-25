"""Alarm actionability detection — separates PRESENT from DEGRADED.

An alarm that exists but won't actually notify is the most damaging false
positive in audit tools. These tests lock in the four discriminator cases.
"""
from __future__ import annotations

from discovery_fabric.aws.mapping import _alarm_is_actionable


class TestAlarmActionability:
    def test_actionable_when_enabled_with_actions(self):
        alarm = {
            "ActionsEnabled": True,
            "AlarmActions": ["arn:aws:sns:us-east-1:123:my-topic"],
            "StateValue": "OK",
        }
        actionable, reason = _alarm_is_actionable(alarm)
        assert actionable is True
        assert reason is None

    def test_actions_disabled(self):
        alarm = {
            "ActionsEnabled": False,
            "AlarmActions": ["arn:aws:sns:us-east-1:123:my-topic"],
            "StateValue": "OK",
        }
        actionable, reason = _alarm_is_actionable(alarm)
        assert actionable is False
        assert reason == "actions_disabled"

    def test_no_alarm_actions_configured(self):
        alarm = {
            "ActionsEnabled": True,
            "AlarmActions": [],
            "StateValue": "OK",
        }
        actionable, reason = _alarm_is_actionable(alarm)
        assert actionable is False
        assert reason == "no_alarm_actions_configured"

    def test_insufficient_data(self):
        alarm = {
            "ActionsEnabled": True,
            "AlarmActions": ["arn:aws:sns:us-east-1:123:my-topic"],
            "StateValue": "INSUFFICIENT_DATA",
        }
        actionable, reason = _alarm_is_actionable(alarm)
        assert actionable is False
        assert reason == "insufficient_data"

    def test_actions_disabled_takes_priority_over_other_issues(self):
        """If actions are disabled, that's the reason — even if other fields would
        also flag the alarm as non-actionable. Reason ordering matters for the
        copy that ends up in the PDF."""
        alarm = {
            "ActionsEnabled": False,
            "AlarmActions": [],
            "StateValue": "INSUFFICIENT_DATA",
        }
        actionable, reason = _alarm_is_actionable(alarm)
        assert actionable is False
        assert reason == "actions_disabled"

    def test_missing_actions_enabled_defaults_to_actionable(self):
        """Edge case: a malformed alarm with no ActionsEnabled key. We default
        to True (actionable) so we don't false-positive a real alarm."""
        alarm = {"AlarmActions": ["arn:aws:sns:us-east-1:123:my-topic"]}
        actionable, reason = _alarm_is_actionable(alarm)
        assert actionable is True
        assert reason is None

    def test_state_alarm_with_actions_is_still_actionable(self):
        """A firing alarm is still actionable. We only mark DEGRADED when the
        alarm CAN'T fire, not when it's currently firing."""
        alarm = {
            "ActionsEnabled": True,
            "AlarmActions": ["arn:aws:sns:us-east-1:123:my-topic"],
            "StateValue": "ALARM",
        }
        actionable, reason = _alarm_is_actionable(alarm)
        assert actionable is True
        assert reason is None
