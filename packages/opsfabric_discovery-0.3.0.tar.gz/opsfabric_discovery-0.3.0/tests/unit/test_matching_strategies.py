"""Five matching strategies in _score_alarm_match.

Priority order (first hit wins):
  1. Exact dimension match               → HIGH
  2. ALB target-group bridge for ECS     → HIGH
  3. Namespace + partial dimension match → MEDIUM
  4. Metric-filter → log-group linkage   → HIGH
  5. Naming heuristic                    → LOW

Each test exercises one strategy in isolation, then we have a couple of
priority-ordering tests at the end to confirm earlier strategies short-circuit
later ones.
"""
from __future__ import annotations

from discovery_fabric.aws.mapping import _score_alarm_match


def _ecs_resource(name: str = "checkout-api", cluster: str = "prod", tg: str | None = None):
    return {
        "resource_name": name,
        "dimension_values": {"ClusterName": cluster, "ServiceName": name},
        "expected_namespace": "AWS/ECS",
        "log_groups": [],
        "target_group_short_forms": [tg] if tg else [],
    }


def _alarm(
    *,
    name: str = "alarm-x",
    namespace: str = "AWS/ECS",
    metric: str = "CPUUtilization",
    dimensions: dict | None = None,
    linked_log_groups: list[str] | None = None,
):
    return {
        "alarm_name": name,
        "dimensions": dimensions or {},
        "metric_keys": [(namespace, metric)],
        "linked_log_groups": linked_log_groups or [],
    }


class TestStrategy1ExactDimensionMatch:
    def test_high_confidence_when_all_dimensions_match(self):
        resource = _ecs_resource()
        alarm = _alarm(dimensions={"ClusterName": "prod", "ServiceName": "checkout-api"})
        confidence, reasons = _score_alarm_match(resource, alarm)
        assert confidence == "HIGH"
        assert "exact_dimension_match" in reasons

    def test_no_match_when_one_dim_wrong(self):
        resource = _ecs_resource()
        # Cluster wrong; falls through to partial-match strategy which still
        # returns MEDIUM since namespace + ServiceName overlap
        alarm = _alarm(dimensions={"ClusterName": "staging", "ServiceName": "checkout-api"})
        confidence, _ = _score_alarm_match(resource, alarm)
        assert confidence == "MEDIUM"


class TestStrategy2AlbTargetGroupBridge:
    def test_high_confidence_when_target_group_matches(self):
        resource = _ecs_resource(tg="targetgroup/checkout-api-tg/abc")
        alarm = _alarm(
            namespace="AWS/ApplicationELB",
            metric="HTTPCode_Target_5XX_Count",
            dimensions={
                "LoadBalancer": "app/prod-alb/xyz",
                "TargetGroup": "targetgroup/checkout-api-tg/abc",
            },
        )
        confidence, reasons = _score_alarm_match(resource, alarm)
        assert confidence == "HIGH"
        assert "alb_target_group_to_ecs_service" in reasons

    def test_no_match_when_target_group_different(self):
        resource = _ecs_resource(tg="targetgroup/checkout-api-tg/abc")
        alarm = _alarm(
            namespace="AWS/ApplicationELB",
            metric="HTTPCode_Target_5XX_Count",
            dimensions={"TargetGroup": "targetgroup/payments-tg/xyz"},
        )
        confidence, _ = _score_alarm_match(resource, alarm)
        assert confidence is None


class TestStrategy3NamespaceAndPartialDimensions:
    def test_medium_confidence_when_namespace_plus_one_dim(self):
        resource = _ecs_resource()
        alarm = _alarm(
            namespace="AWS/ECS",
            metric="CPUUtilization",
            dimensions={"ServiceName": "checkout-api"},  # ClusterName intentionally missing
        )
        confidence, reasons = _score_alarm_match(resource, alarm)
        assert confidence == "MEDIUM"
        assert "metric_namespace_plus_partial_dimensions" in reasons

    def test_no_match_when_namespace_doesnt_match(self):
        resource = _ecs_resource()
        alarm = _alarm(
            namespace="AWS/Lambda",  # wrong namespace
            metric="Errors",
            dimensions={"FunctionName": "checkout-api"},  # name happens to coincide
        )
        confidence, reasons = _score_alarm_match(resource, alarm)
        # Falls through to naming heuristic since the resource name appears in
        # the (default) alarm-name string ("alarm-x" — no, doesn't include
        # "checkout-api"). So this returns None.
        assert confidence is None
        assert "metric_namespace_plus_partial_dimensions" not in reasons


class TestStrategy4LogGroupLinkage:
    def test_high_confidence_when_log_group_matches(self):
        resource = _ecs_resource()
        resource["log_groups"] = ["/ecs/prod-cluster/checkout-api"]
        # Custom log-metric-filter alarm — namespace doesn't have to match
        # AWS/ECS for this strategy. Different namespace, different dims, but
        # linked log group is in the resource's log_groups → HIGH match.
        alarm = _alarm(
            namespace="Custom/App",
            metric="ErrorCount",
            dimensions={},
            linked_log_groups=["/ecs/prod-cluster/checkout-api"],
        )
        confidence, reasons = _score_alarm_match(resource, alarm)
        assert confidence == "HIGH"
        assert "metric_filter_to_log_group_linkage" in reasons


class TestStrategy5NamingHeuristic:
    def test_low_confidence_when_resource_name_in_alarm_name(self):
        resource = _ecs_resource(name="checkout-api")
        alarm = _alarm(
            name="some-random-alarm-checkout-api-5xx",
            namespace="AWS/X-Ray",
            metric="ErrorCount",
            dimensions={},
        )
        confidence, reasons = _score_alarm_match(resource, alarm)
        assert confidence == "LOW"
        assert "naming_heuristic" in reasons


class TestPriorityOrdering:
    """Earlier strategies short-circuit later ones. If both exact-dim AND
    naming-heuristic match the same alarm, we get HIGH (exact), not LOW."""

    def test_exact_dim_beats_naming_heuristic(self):
        resource = _ecs_resource()
        # Alarm name includes the service name (would trigger naming) AND
        # has exact-dim match (HIGH). Should report HIGH, not LOW.
        alarm = _alarm(
            name="checkout-api-CPUUtilization-page",
            dimensions={"ClusterName": "prod", "ServiceName": "checkout-api"},
        )
        confidence, _ = _score_alarm_match(resource, alarm)
        assert confidence == "HIGH"

    def test_alb_bridge_beats_naming_heuristic(self):
        resource = _ecs_resource(tg="targetgroup/checkout-api-tg/abc")
        alarm = _alarm(
            name="checkout-api-5xx-alert",  # also matches naming
            namespace="AWS/ApplicationELB",
            metric="HTTPCode_Target_5XX_Count",
            dimensions={"TargetGroup": "targetgroup/checkout-api-tg/abc"},
        )
        confidence, _ = _score_alarm_match(resource, alarm)
        assert confidence == "HIGH"


class TestNoMatch:
    def test_unrelated_alarm_returns_none(self):
        resource = _ecs_resource()
        alarm = _alarm(
            name="payments-Errors-page",  # different service
            namespace="AWS/Lambda",
            metric="Errors",
            dimensions={"FunctionName": "payments-worker"},
        )
        confidence, _ = _score_alarm_match(resource, alarm)
        assert confidence is None
