"""ARN parsers — turn AWS resource ARNs into the bare identifier used as
the CloudWatch dimension value. These are the foundation of every matching
strategy; a bug here cascades into every downstream test."""
from __future__ import annotations

from discovery_fabric.aws.mapping import (
    _alarm_name_from_arn,
    _parse_ecs_service_arn,
    _parse_lambda_function_arn,
    _parse_rds_cluster_arn,
    _parse_rds_db_arn,
    _parse_sqs_queue_arn,
    _target_group_short_form,
)


class TestEcsServiceArn:
    def test_standard_arn(self):
        arn = "arn:aws:ecs:us-east-1:123456789012:service/prod-cluster/checkout-api"
        assert _parse_ecs_service_arn(arn) == ("prod-cluster", "checkout-api")

    def test_cluster_with_hyphens(self):
        arn = "arn:aws:ecs:eu-west-1:123:service/my-cluster-prod-v2/payments-svc"
        assert _parse_ecs_service_arn(arn) == ("my-cluster-prod-v2", "payments-svc")

    def test_missing_marker_returns_none(self):
        assert _parse_ecs_service_arn("arn:aws:ecs:us-east-1:123:cluster/foo") is None

    def test_extra_path_segments_returns_none(self):
        # service/<cluster>/<service> is exactly 2 path parts; more parts are invalid
        arn = "arn:aws:ecs:us-east-1:123:service/cluster/svc/extra"
        assert _parse_ecs_service_arn(arn) is None


class TestLambdaFunctionArn:
    def test_unqualified(self):
        arn = "arn:aws:lambda:us-east-1:123:function:checkout-api"
        assert _parse_lambda_function_arn(arn) == "checkout-api"

    def test_with_version_qualifier(self):
        arn = "arn:aws:lambda:us-east-1:123:function:checkout-api:7"
        assert _parse_lambda_function_arn(arn) == "checkout-api"

    def test_with_alias(self):
        arn = "arn:aws:lambda:us-east-1:123:function:checkout-api:prod"
        assert _parse_lambda_function_arn(arn) == "checkout-api"

    def test_not_a_function_returns_none(self):
        assert _parse_lambda_function_arn("arn:aws:lambda:us-east-1:123:layer:foo") is None


class TestRdsArns:
    def test_db_instance(self):
        arn = "arn:aws:rds:us-east-1:123:db:orders-db-prod"
        assert _parse_rds_db_arn(arn) == "orders-db-prod"

    def test_db_instance_rejects_cluster_arn(self):
        arn = "arn:aws:rds:us-east-1:123:cluster:sessions-cluster"
        assert _parse_rds_db_arn(arn) is None

    def test_aurora_cluster(self):
        arn = "arn:aws:rds:us-east-1:123:cluster:sessions-cluster"
        assert _parse_rds_cluster_arn(arn) == "sessions-cluster"

    def test_aurora_cluster_rejects_instance_arn(self):
        arn = "arn:aws:rds:us-east-1:123:db:orders-db"
        assert _parse_rds_cluster_arn(arn) is None


class TestSqsQueueArn:
    def test_standard_queue(self):
        arn = "arn:aws:sqs:us-east-1:123456789012:events-buffer"
        assert _parse_sqs_queue_arn(arn) == "events-buffer"

    def test_dlq_naming_unchanged(self):
        # DLQ detection is not the parser's job; it just returns the name as-is.
        arn = "arn:aws:sqs:us-east-1:123:events-buffer-dlq"
        assert _parse_sqs_queue_arn(arn) == "events-buffer-dlq"

    def test_wrong_service_returns_none(self):
        arn = "arn:aws:sns:us-east-1:123:my-topic"
        assert _parse_sqs_queue_arn(arn) is None

    def test_empty_name_returns_none(self):
        arn = "arn:aws:sqs:us-east-1:123:"
        assert _parse_sqs_queue_arn(arn) is None


class TestTargetGroupShortForm:
    """The ALB → ECS bridge depends on normalising target-group ARNs to the
    short form CloudWatch uses in the `TargetGroup` dimension value."""

    def test_full_arn_to_short_form(self):
        arn = "arn:aws:elasticloadbalancing:us-east-1:123:targetgroup/checkout-api-tg/abc123"
        assert _target_group_short_form(arn) == "targetgroup/checkout-api-tg/abc123"

    def test_not_a_target_group_arn_returns_none(self):
        arn = "arn:aws:elasticloadbalancing:us-east-1:123:loadbalancer/app/foo/abc"
        assert _target_group_short_form(arn) is None

    def test_malformed_input_returns_none(self):
        assert _target_group_short_form("not-an-arn") is None
        assert _target_group_short_form("") is None


class TestAlarmNameFromArn:
    def test_extracts_alarm_name(self):
        arn = "arn:aws:cloudwatch:us-east-1:123:alarm:my-alarm-name"
        assert _alarm_name_from_arn(arn) == "my-alarm-name"

    def test_alarm_name_with_special_chars(self):
        arn = "arn:aws:cloudwatch:us-east-1:123:alarm:checkout-api-Errors-page"
        assert _alarm_name_from_arn(arn) == "checkout-api-Errors-page"

    def test_missing_marker_returns_none(self):
        assert _alarm_name_from_arn("arn:aws:cloudwatch:us-east-1:123:dashboard:foo") is None
