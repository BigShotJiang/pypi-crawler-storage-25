"""RDS / Aurora log-group regex matching.

The earlier substring-based matcher attributed `payments-replica` log groups
to a `payments` instance. The anchored regex in `_rds_log_groups_for_identifier`
fixes this. These tests lock in the behaviour so future refactors don't
silently regress to substring matching.
"""
from __future__ import annotations

from discovery_fabric.aws.mapping import _rds_log_groups_for_identifier


class TestRdsLogGroupMatching:
    def test_exact_identifier_match_instance(self):
        log_groups = [
            "/aws/rds/instance/payments/postgresql",
            "/aws/rds/instance/payments/upgrade",
        ]
        assert _rds_log_groups_for_identifier(log_groups, "payments", "instance") == log_groups

    def test_same_prefix_replica_is_NOT_matched(self):
        """The credibility-saving guard. `payments` must not claim `payments-replica`."""
        log_groups = [
            "/aws/rds/instance/payments/postgresql",
            "/aws/rds/instance/payments-replica/postgresql",
            "/aws/rds/instance/payments-replica/upgrade",
        ]
        result = _rds_log_groups_for_identifier(log_groups, "payments", "instance")
        assert result == ["/aws/rds/instance/payments/postgresql"]

    def test_instance_kind_does_not_match_cluster_log_groups(self):
        log_groups = [
            "/aws/rds/instance/sessions-cluster/postgresql",  # bogus shape but tests kind discriminator
            "/aws/rds/cluster/sessions-cluster/postgresql",
        ]
        # When asking for the instance kind, the cluster-kind path is filtered out
        assert _rds_log_groups_for_identifier(log_groups, "sessions-cluster", "instance") == [
            "/aws/rds/instance/sessions-cluster/postgresql"
        ]

    def test_cluster_kind_matches_only_cluster_paths(self):
        log_groups = [
            "/aws/rds/cluster/orders/audit",
            "/aws/rds/cluster/orders/postgresql",
            "/aws/rds/instance/orders-writer/postgresql",
        ]
        assert _rds_log_groups_for_identifier(log_groups, "orders", "cluster") == [
            "/aws/rds/cluster/orders/audit",
            "/aws/rds/cluster/orders/postgresql",
        ]

    def test_unrelated_path_prefixes_are_ignored(self):
        log_groups = [
            "/aws/lambda/payments/foo",
            "/some/random/path/payments/bar",
        ]
        assert _rds_log_groups_for_identifier(log_groups, "payments", "instance") == []

    def test_empty_inputs(self):
        assert _rds_log_groups_for_identifier([], "payments", "instance") == []
        assert _rds_log_groups_for_identifier(["/aws/rds/instance/payments/log"], "", "instance") == []
