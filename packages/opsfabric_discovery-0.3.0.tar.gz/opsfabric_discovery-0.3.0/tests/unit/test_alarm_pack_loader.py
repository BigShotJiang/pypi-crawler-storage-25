"""Alarm pack loader — reads alarm_pack.yaml into the structure the matcher uses.

Locks in:
  - The packaged YAML is shipped in the wheel and resolvable at import time.
  - business_impact strings round-trip into the per-check dict.
  - When YAML is unavailable, the in-code DEFAULT_ALARM_PACK is used as fallback.
"""
from __future__ import annotations

from discovery_fabric.aws.alarm_coverage import (
    DEFAULT_ALARM_PACK,
    _load_alarm_pack,
)


class TestPackLoader:
    def test_load_succeeds(self):
        packs, source = _load_alarm_pack()
        assert isinstance(packs, dict)
        assert isinstance(source, str)

    def test_expected_resource_kinds_present(self):
        """The five baseline kinds must always load. If any of these are
        missing the audit silently scores zero — that's the kind of bug we
        want loud."""
        packs, _ = _load_alarm_pack()
        for kind in ("ecs_service", "lambda_function", "rds_instance", "rds_cluster", "sqs_queue"):
            assert kind in packs, f"alarm pack is missing {kind!r}"
            assert len(packs[kind]) > 0, f"{kind} has no checks"

    def test_business_impact_is_preserved(self):
        """Every required check should have a non-empty business_impact string.
        That field is what makes the audit credible to non-engineers."""
        packs, _ = _load_alarm_pack()
        missing_impact = []
        for kind, checks in packs.items():
            for check in checks:
                if check.get("required") and not check.get("business_impact"):
                    missing_impact.append(f"{kind}.{check['id']}")
        assert missing_impact == [], (
            f"Required checks missing business_impact: {missing_impact}"
        )

    def test_default_alarm_pack_shape(self):
        """DEFAULT_ALARM_PACK is the fallback when the YAML can't be loaded.
        Verify it has the same shape as the YAML pack so behaviour is consistent
        across both code paths."""
        assert "resource_packs" in DEFAULT_ALARM_PACK
        assert "ecs_service" in DEFAULT_ALARM_PACK["resource_packs"]
        assert "lambda_function" in DEFAULT_ALARM_PACK["resource_packs"]
        assert "rds_instance" in DEFAULT_ALARM_PACK["resource_packs"]

    def test_required_checks_count(self):
        """Smoke-test that the pack hasn't been silently emptied. Numbers can
        change as we evolve the pack; the assertion just enforces non-trivial
        coverage."""
        packs, _ = _load_alarm_pack()
        total_required = sum(
            1 for checks in packs.values() for check in checks if check.get("required")
        )
        assert total_required >= 15, (
            f"Only {total_required} required checks across all kinds — pack looks under-populated"
        )

    def test_each_check_has_id_and_title(self):
        """Required fields the matcher relies on."""
        packs, _ = _load_alarm_pack()
        for kind, checks in packs.items():
            for check in checks:
                assert check.get("id"), f"{kind} has a check missing 'id'"
                assert check.get("title"), f"{kind}.{check['id']} missing 'title'"
