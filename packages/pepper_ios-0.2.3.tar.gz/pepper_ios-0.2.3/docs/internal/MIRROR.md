# Public Mirror System

The public repo (`skwallace36/Pepper`) is a filtered mirror of the private repo (`skwallace36/Pepper-private`). Every push to `main` on private triggers a full history rewrite and force push to public.

## How it works

**Workflow:** `.github/workflows/mirror-code.yml`

On every push to `main`:
1. Checks out the full private repo history (`fetch-depth: 0`)
2. Runs `git-filter-repo` to:
   - **Remove excluded files** from every commit in history
   - **Rewrite all commit authors** to `skwallace36`
3. Force pushes the rewritten history to public

This means the public repo has a **completely different commit graph** from private. Same code, same commit messages, but different SHAs (because file removals and author rewrites change every commit hash).

## What's excluded

Exclusions are defined in two places (keep them in sync):

### `.public-exclude`
Human-readable list of what's hidden. Used as documentation and by legacy sync scripts.

### `.github/workflows/mirror-code.yml`
The actual filter-repo arguments. This is what matters — the workflow reads these directly, not `.public-exclude`.

**Current exclusions:**
- `scripts/prompts/` — agent prompt templates
- `.claude/` — Claude Code config (settings, permissions, hooks)
- `.github/workflows/mirror-*` — mirror workflow files themselves
- `.public-exclude` — the exclude list
- `.env`, `.env.local` — secrets
- `events.jsonl`, `.pepper-kill`, `*.lock` — runtime state
- `build/`, `test-app/build/`, `.venv/`, `.ruff_cache/`, `tools/__pycache__/` — build artifacts
- `docs/internal/` — internal documentation (including this file)

**Everything else is public**, including:
- Agent runner, dashboard, hooks, coordinator scripts
- CLAUDE.md
- CI workflow, linter configs, Makefile
- All dylib/tools source code

## Changing what's excluded

### To hide something new

1. Add the path to `.public-exclude` (for documentation)
2. Add a `--path` or `--path-glob` line to the `filter-repo` command in `mirror-code.yml`
3. Push to main — the next mirror run will rewrite history to remove it from **all** commits

**Example — hide a new script:**
```yaml
# In mirror-code.yml, add to the filter-repo args:
--path scripts/my-secret-script.sh \
```

**Example — hide a directory:**
```yaml
--path 'my-secret-dir/' \
```

### To un-hide something (make it public)

1. Remove the path from `.public-exclude`
2. Remove the corresponding `--path` / `--path-glob` line from `mirror-code.yml`
3. Push to main — the file will appear in public history from the first commit that introduced it

### Filter-repo path syntax

- `--path scripts/foo.sh` — exact file path
- `--path 'dir/'` — entire directory (trailing slash). **Must use `--path`, not `--path-glob`** — `fnmatch` doesn't treat trailing slashes as directory prefixes.
- `--path-glob 'scripts/agent-*'` — shell glob for file patterns (use quotes)
- All paths are relative to repo root
- `--invert-paths` means "remove these" (already set in the workflow)

## Rewriting authors

All commits on public show `skwallace36 <skwallace36@users.noreply.github.com>` regardless of who authored them on private. This is handled by the `--name-callback` and `--email-callback` arguments.

To change the public author identity, edit these lines in `mirror-code.yml`:
```yaml
--name-callback 'return b"skwallace36"' \
--email-callback 'return b"skwallace36@users.noreply.github.com"' \
```

## Manually triggering a mirror

If you need to re-run the mirror without pushing a new commit:

```bash
gh workflow run "Mirror: code → public" --repo skwallace36/Pepper-private
```

Or from the Actions tab on the private repo (if workflow_dispatch is enabled — currently it's not, add it if needed).

## Testing changes locally

Before pushing mirror changes, test locally:

```bash
# Clone to temp dir
cd /tmp && rm -rf mirror-test
git clone --no-hardlinks /path/to/pepper mirror-test
cd mirror-test

# Run filter-repo (copy args from mirror-code.yml)
python3 -m git_filter_repo \
  --invert-paths \
  --path 'scripts/prompts/' \
  --path '.claude/' \
  ... \
  --name-callback 'return b"skwallace36"' \
  --email-callback 'return b"skwallace36@users.noreply.github.com"' \
  --force

# Verify
ls  # check top-level files
git log --format='%an <%ae>' | sort -u  # check authors
git rev-list --count HEAD  # check commit count
```

## Issue mirroring

**`mirror-issues.yml`** mirrors private issues to public issues (same title, body, labels, state). Each mirrored issue has an HTML comment marker (`<!-- pepper-mirror-issue-NNN -->`) in the body to link it back to the private original.

Issues with the `private` label or matching the keyword blocklist are skipped. If a previously-mirrored issue is later marked private or matches the blocklist, the public copy is closed.

## Troubleshooting

**Mirror failed with permission denied:**
The `PUBLIC_REPO_TOKEN` secret may have expired. Regenerate it from `skwallace36`'s settings and update the secret in Pepper-private.

**filter-repo removed the origin remote:**
This is expected — filter-repo always removes origin. The workflow adds the public remote after filtering.

**Credential helper overrides token:**
`actions/checkout` installs a credential helper that can interfere. The workflow clears it with `git config --unset-all` before pushing.

**Public repo shows old/stale files:**
The mirror force-pushes rewritten history. If a file still shows up, check that it's listed in the filter-repo args (not just `.public-exclude`).

**Contributors list shows unexpected users:**
GitHub caches contributor lists. After a force push with rewritten authors, it can take up to 24 hours to update. Check with `gh api repos/skwallace36/Pepper/contributors --jq '.[].login'`.
