import Foundation
import os

/// Handles {"cmd": "network"} commands.
/// Manages HTTP network traffic interception — start/stop capture,
/// query the transaction log, clear the buffer.
///
/// Usage:
///   {"cmd":"network", "params":{"action":"start"}}
///   {"cmd":"network", "params":{"action":"start", "buffer_size":1000}}
///   {"cmd":"network", "params":{"action":"stop"}}
///   {"cmd":"network", "params":{"action":"status"}}
///   {"cmd":"network", "params":{"action":"log"}}                                       // URL+status+duration only
///   {"cmd":"network", "params":{"action":"log", "limit":10, "filter":"api.example.com"}}
///   {"cmd":"network", "params":{"action":"log", "include_headers":true}}                 // include request/response headers
///   {"cmd":"network", "params":{"action":"log", "include_body":true}}                    // include bodies (up to 4096 chars)
///   {"cmd":"network", "params":{"action":"log", "include_body":true, "max_body":1024}}   // include bodies, truncate to 1KB
///   {"cmd":"network", "params":{"action":"clear"}}
///   {"cmd":"network", "params":{"action":"tasks"}}
///   {"cmd":"network", "params":{"action":"tasks", "state":"running"}}
///   {"cmd":"network", "params":{"action":"tasks", "filter":"api.example.com"}}
///   {"cmd":"network", "params":{"action":"simulate", "preset":"3G"}}
///   {"cmd":"network", "params":{"action":"simulate", "preset":"Edge", "url":"api.example.com"}}
///   {"cmd":"network", "params":{"action":"simulate", "preset":"LTE"}}
///   {"cmd":"network", "params":{"action":"simulate", "preset":"WiFi"}}
///   {"cmd":"network", "params":{"action":"simulate", "preset":"High Latency DNS"}}
///   {"cmd":"network", "params":{"action":"simulate", "preset":"100% Loss"}}
///   {"cmd":"network", "params":{"action":"presets"}}
///   {"cmd":"network", "params":{"action":"simulate", "effect":"latency", "latency_ms":500}}
///   {"cmd":"network", "params":{"action":"simulate", "effect":"latency", "latency_ms":2000, "url":"images.example.com"}}
///   {"cmd":"network", "params":{"action":"simulate", "effect":"offline"}}
///   {"cmd":"network", "params":{"action":"simulate", "effect":"fail_status", "status_code":500, "url":"api.example.com"}}
///   {"cmd":"network", "params":{"action":"simulate", "effect":"fail_error", "error_domain":"NSURLErrorDomain", "error_code":-1009}}
///   {"cmd":"network", "params":{"action":"simulate", "effect":"throttle", "bytes_per_second":1024, "url":"cdn.example.com"}}
///   {"cmd":"network", "params":{"action":"mock", "url":"api.example.com/users", "status":200, "body":"{\"users\":[]}"}}
///   {"cmd":"network", "params":{"action":"mock", "url":"api.example.com/error", "status":500, "body":"{\"error\":\"fail\"}", "method":"POST"}}
///   {"cmd":"network", "params":{"action":"mocks"}}
///   {"cmd":"network", "params":{"action":"remove_mock", "id":"mock-id"}}
///   {"cmd":"network", "params":{"action":"clear_mocks"}}
///   {"cmd":"network", "params":{"action":"conditions"}}
///   {"cmd":"network", "params":{"action":"remove_condition", "id":"condition-id"}}
///   {"cmd":"network", "params":{"action":"clear_conditions"}}
///   {"cmd":"network", "params":{"action":"stream_log", "id":"transaction-id"}}               // get SSE/streaming chunks
///   {"cmd":"network", "params":{"action":"stream_log", "id":"transaction-id", "limit":50, "offset":0}}
///
/// SSE/streaming responses (text/event-stream, application/x-ndjson) are detected automatically.
/// They appear in the log with `is_streaming: true` and `stream_status: "open"|"closed"`.
/// Real-time events: "network_stream_start", "network_stream_chunk", "network_stream_end".
///
/// While active, each completed HTTP request broadcasts a "network_request" event.
struct NetworkHandler: PepperHandler {
    let commandName = "network"
    private var logger: Logger { PepperLogger.logger(category: "network-handler") }

    func handle(_ command: PepperCommand) -> PepperResponse {
        guard let action = command.params?["action"]?.stringValue else {
            return .error(
                id: command.id,
                message:
                    "Missing 'action' param. Available: start, stop, status, log, clear, tasks, simulate, presets, conditions, remove_condition, clear_conditions, mock, mocks, remove_mock, clear_mocks, stream_log, ws_log, ws_status, ws_clear"
            )
        }

        PepperFlightRecorder.shared.ensureInstalled()
        let interceptor = PepperNetworkInterceptor.shared

        switch action {
        case "start":
            let bufferSize = command.params?["buffer_size"]?.intValue
            interceptor.install(bufferSize: bufferSize)
            PepperWebSocketInterceptor.shared.install(bufferSize: bufferSize)
            PepperURLSessionTracker.shared.install()
            return .ok(
                id: command.id,
                data: [
                    "active": AnyCodable(true),
                    "buffer_size": AnyCodable(interceptor.bufferSize),
                ])

        case "stop":
            interceptor.uninstall()
            PepperWebSocketInterceptor.shared.uninstall()
            return .ok(
                id: command.id,
                data: [
                    "active": AnyCodable(false),
                    "transactions_captured": AnyCodable(interceptor.totalRecorded),
                ])

        case "status":
            return handleStatus(command)

        case "log":
            return handleLog(command)

        case "clear":
            interceptor.clearBuffer()
            return .ok(
                id: command.id,
                data: [
                    "cleared": AnyCodable(true)
                ])

        case "simulate":
            return handleSimulate(command)

        case "presets":
            let presets = NetworkPreset.allCases.map { preset -> [String: AnyCodable] in
                [
                    "name": AnyCodable(preset.rawValue),
                    "effects": AnyCodable(
                        preset.effects.map {
                            ["effect": $0.effect.name, "description": $0.description]
                        }
                    ),
                ]
            }
            return .ok(
                id: command.id,
                data: [
                    "count": AnyCodable(presets.count),
                    "presets": AnyCodable(presets.map { AnyCodable($0) }),
                ])

        case "conditions":
            let conditions = interceptor.activeConditions
            return .ok(
                id: command.id,
                data: [
                    "count": AnyCodable(conditions.count),
                    "conditions": AnyCodable(conditions.map { AnyCodable($0.toDictionary()) }),
                ])

        case "remove_condition":
            guard let conditionId = command.params?["id"]?.stringValue else {
                return .error(id: command.id, message: "Missing 'id' param for remove_condition")
            }
            interceptor.removeCondition(id: conditionId)
            return .ok(
                id: command.id,
                data: [
                    "removed": AnyCodable(conditionId)
                ])

        case "clear_conditions":
            interceptor.removeAllConditions()
            return .ok(
                id: command.id,
                data: [
                    "cleared": AnyCodable(true)
                ])

        case "mock", "mocks", "remove_mock", "clear_mocks":
            return handleMockAction(action, command)

        case "tasks":
            return handleTasks(command)

        case "stream_log":
            return handleStreamLog(command)

        case "ws_log", "ws_status", "ws_clear":
            return handleWsAction(action, command)

        default:
            return .error(
                id: command.id,
                message:
                    "Unknown action '\(action)'. Available: start, stop, status, log, clear, tasks, simulate, presets, conditions, remove_condition, clear_conditions, mock, mocks, remove_mock, clear_mocks, stream_log, ws_log, ws_status, ws_clear"
            )
        }
    }

    // MARK: - Status

    private func handleStatus(_ command: PepperCommand) -> PepperResponse {
        let interceptor = PepperNetworkInterceptor.shared
        let dupes = interceptor.recentDuplicates(limit: 5)
        let conditions = interceptor.activeConditions
        let mocks = interceptor.activeMocks
        let bgMonitor = PepperBackgroundSessionMonitor.shared
        var statusData: [String: AnyCodable] = [
            "active": AnyCodable(interceptor.isIntercepting),
            "buffer_size": AnyCodable(interceptor.bufferSize),
            "buffer_count": AnyCodable(interceptor.transactionCount),
            "total_recorded": AnyCodable(interceptor.totalRecorded),
            "total_dropped": AnyCodable(interceptor.totalDropped),
            "conditions_count": AnyCodable(conditions.count),
            "mocks_count": AnyCodable(mocks.count),
            "background_sessions_tracked": AnyCodable(bgMonitor.trackedSessions),
            "background_transactions_recorded": AnyCodable(bgMonitor.totalRecorded),
        ]
        if !dupes.isEmpty {
            statusData["duplicate_warnings"] = AnyCodable(
                dupes.map { d in
                    [
                        "endpoint": AnyCodable(d.endpoint),
                        "count": AnyCodable(d.count),
                        "window_ms": AnyCodable(Int(d.windowMs)),
                        "seconds_ago": AnyCodable(Int(-d.timestamp.timeIntervalSinceNow)),
                    ] as [String: AnyCodable]
                })
        }
        if !conditions.isEmpty {
            statusData["conditions"] = AnyCodable(conditions.map { AnyCodable($0.toDictionary()) })
        }
        if !mocks.isEmpty {
            statusData["mocks"] = AnyCodable(mocks.map { AnyCodable($0.toDictionary()) })
        }

        // WebSocket stats
        let wsInterceptor = PepperWebSocketInterceptor.shared
        let activeConns = wsInterceptor.activeConnections
        statusData["ws_active"] = AnyCodable(wsInterceptor.isIntercepting)
        statusData["ws_frame_count"] = AnyCodable(wsInterceptor.frameCount)
        statusData["ws_total_recorded"] = AnyCodable(wsInterceptor.totalRecorded)
        statusData["ws_connections"] = AnyCodable(activeConns.count)
        if !activeConns.isEmpty {
            statusData["ws_active_connections"] = AnyCodable(activeConns.map { AnyCodable($0.toDictionary()) })
        }

        return .ok(id: command.id, data: statusData)
    }

    // MARK: - Tasks

    private func handleTasks(_ command: PepperCommand) -> PepperResponse {
        let tracker = PepperURLSessionTracker.shared
        tracker.install()  // Idempotent — ensures swizzle is active

        let stateFilter = command.params?["state"]?.stringValue
        let filter = command.params?["filter"]?.stringValue

        var snapshots = tracker.getAllActiveTasks()

        // Filter by state
        if let stateFilter = stateFilter {
            snapshots = snapshots.filter { $0.stateName == stateFilter }
        }

        // Filter by URL substring
        if let filter = filter, !filter.isEmpty {
            snapshots = snapshots.filter { snap in
                if let url = snap.originalRequestURL,
                    url.localizedCaseInsensitiveContains(filter)
                {
                    return true
                }
                if let url = snap.currentRequestURL,
                    url.localizedCaseInsensitiveContains(filter)
                {
                    return true
                }
                return false
            }
        }

        let stateCounts = Dictionary(grouping: snapshots, by: { $0.stateName })
            .mapValues { $0.count }

        return .list(
            id: command.id,
            "tasks",
            snapshots.map { AnyCodable($0.toDictionary()) },
            extra: [
                "sessions_tracked": AnyCodable(tracker.trackedSessionCount),
                "by_state": AnyCodable(stateCounts.mapValues { AnyCodable($0) }),
            ]
        )
    }

    // MARK: - Log

    private func handleLog(_ command: PepperCommand) -> PepperResponse {
        let interceptor = PepperNetworkInterceptor.shared
        let limit = command.params?["limit"]?.intValue ?? 10
        let offset = command.params?["offset"]?.intValue ?? 0
        let filter = command.params?["filter"]?.stringValue
        let includeHeaders = command.params?["include_headers"]?.boolValue ?? false
        let includeBody = command.params?["include_body"]?.boolValue ?? false

        // Noise filtering: hide_noise defaults to true, exclude is optional CSV
        let hideNoise = command.params?["hide_noise"]?.boolValue ?? true
        let excludeRaw = command.params?["exclude"]?.stringValue
        let exclude: [String]? = excludeRaw?.split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }

        // Body logic: include_body=true defaults to 4096, explicit max_body overrides.
        // When include_body is false and no explicit max_body, default to 0 (omit bodies).
        let explicitMaxBody = command.params?["max_body"]?.intValue
        let maxBodyRaw: Int
        if let explicit = explicitMaxBody {
            maxBodyRaw = explicit
        } else if includeBody {
            maxBodyRaw = 4096
        } else {
            maxBodyRaw = 0
        }
        let maxBody: Int? = maxBodyRaw > 0 ? maxBodyRaw : nil

        let sinceMs: Int64? =
            (command.params?["since_ms"]?.value as? Int).map { Int64($0) }
            ?? (command.params?["since_ms"]?.value as? Int64)
        let (transactions, total) = interceptor.recentTransactions(
            limit: limit, offset: offset, filter: filter, sinceMs: sinceMs, hideNoise: hideNoise, exclude: exclude)

        var data: [String: AnyCodable] = [
            "count": AnyCodable(transactions.count),
            "total": AnyCodable(total),
            "offset": AnyCodable(offset),
            "has_more": AnyCodable(offset + transactions.count < total),
            "transactions": AnyCodable(
                transactions.map {
                    AnyCodable($0.toDictionary(maxBody: maxBody, includeHeaders: includeHeaders))
                }),
        ]
        if hideNoise {
            data["noise_filtered"] = AnyCodable(true)
        }
        if transactions.count > 0 {
            data["hint"] = AnyCodable(
                "Use `timeline(last_seconds=30)` for a correlated view of network + console + screen events")
        }
        return .ok(id: command.id, data: data)
    }

    // MARK: - Simulate

    private func handleSimulate(_ command: PepperCommand) -> PepperResponse {
        // Preset takes priority — applies a bundle of conditions
        if let presetName = command.params?["preset"]?.stringValue {
            return handlePreset(presetName, command)
        }

        guard let effectName = command.params?["effect"]?.stringValue else {
            return .error(
                id: command.id,
                message: "Missing 'effect' or 'preset' param. "
                    + "Effects: latency, fail_status, fail_error, throttle, offline. "
                    + "Presets: \(NetworkPreset.availableNames)")
        }

        let interceptor = PepperNetworkInterceptor.shared

        // Build the effect
        let effect: NetworkConditionEffect
        var description: String

        switch effectName {
        case "latency":
            guard let ms = command.params?["latency_ms"]?.intValue, ms > 0 else {
                return .error(id: command.id, message: "Missing or invalid 'latency_ms' param (must be > 0)")
            }
            effect = .latency(ms: ms)
            description = "Add \(ms)ms latency"

        case "fail_status":
            guard let statusCode = command.params?["status_code"]?.intValue else {
                return .error(id: command.id, message: "Missing 'status_code' param")
            }
            effect = .failStatus(statusCode: statusCode)
            description = "Fail with HTTP \(statusCode)"

        case "fail_error":
            let domain = command.params?["error_domain"]?.stringValue ?? NSURLErrorDomain
            let code = command.params?["error_code"]?.intValue ?? NSURLErrorUnknown
            effect = .failError(domain: domain, code: code)
            description = "Fail with \(domain):\(code)"

        case "throttle":
            guard let bps = command.params?["bytes_per_second"]?.intValue, bps > 0 else {
                return .error(id: command.id, message: "Missing or invalid 'bytes_per_second' param (must be > 0)")
            }
            effect = .throttle(bytesPerSecond: bps)
            description = "Throttle to \(PepperNetworkInterceptor.formatBytes(bps))/s"

        case "offline":
            effect = .offline
            description = "Simulate offline"

        default:
            return .error(
                id: command.id,
                message:
                    "Unknown effect '\(effectName)'. Available: latency, fail_status, fail_error, throttle, offline")
        }

        // Build matcher (optional — nil means match all)
        let urlPattern = command.params?["url"]?.stringValue
        let methodFilter = command.params?["method"]?.stringValue
        var matcher: RequestMatcher?
        if urlPattern != nil || methodFilter != nil {
            matcher = RequestMatcher(urlContains: urlPattern, method: methodFilter)
            if let u = urlPattern { description += " [url~\(u)]" }
            if let m = methodFilter { description += " [\(m)]" }
        } else {
            description += " [all requests]"
        }

        // Auto-start interception if not already active
        if !interceptor.isIntercepting {
            interceptor.install()
        }

        let conditionId = command.params?["id"]?.stringValue ?? UUID().uuidString
        let condition = PepperNetworkCondition(
            id: conditionId,
            matcher: matcher,
            effect: effect,
            description: description
        )
        interceptor.addCondition(condition)

        return .ok(
            id: command.id,
            data: [
                "condition_id": AnyCodable(conditionId),
                "effect": AnyCodable(effectName),
                "description": AnyCodable(description),
                "active_conditions": AnyCodable(interceptor.activeConditions.count),
            ])
    }

    // MARK: - Preset

    private func handlePreset(_ presetName: String, _ command: PepperCommand) -> PepperResponse {
        guard let preset = NetworkPreset.named(presetName) else {
            return .error(
                id: command.id,
                message: "Unknown preset '\(presetName)'. Available: \(NetworkPreset.availableNames)")
        }

        let interceptor = PepperNetworkInterceptor.shared

        // Build matcher (optional — nil means match all)
        let urlPattern = command.params?["url"]?.stringValue
        let methodFilter = command.params?["method"]?.stringValue
        var matcher: RequestMatcher?
        if urlPattern != nil || methodFilter != nil {
            matcher = RequestMatcher(urlContains: urlPattern, method: methodFilter)
        }

        // Auto-start interception if not already active
        if !interceptor.isIntercepting {
            interceptor.install()
        }

        let fallback = "preset-\(preset.rawValue.lowercased().replacingOccurrences(of: " ", with: "-"))"
        let baseId = command.params?["id"]?.stringValue ?? fallback
        var conditionIds: [String] = []

        for (index, entry) in preset.effects.enumerated() {
            var desc = entry.description
            if let u = urlPattern { desc += " [url~\(u)]" }
            if let m = methodFilter { desc += " [\(m)]" }
            if matcher == nil { desc += " [all requests]" }

            let conditionId = preset.effects.count == 1 ? baseId : "\(baseId)-\(index)"
            let condition = PepperNetworkCondition(
                id: conditionId,
                matcher: matcher,
                effect: entry.effect,
                description: desc
            )
            interceptor.addCondition(condition)
            conditionIds.append(conditionId)
        }

        return .ok(
            id: command.id,
            data: [
                "preset": AnyCodable(preset.rawValue),
                "condition_ids": AnyCodable(conditionIds),
                "conditions_applied": AnyCodable(conditionIds.count),
                "active_conditions": AnyCodable(interceptor.activeConditions.count),
            ])
    }

    // MARK: - Mock

    private func handleMockAction(_ action: String, _ command: PepperCommand) -> PepperResponse {
        let interceptor = PepperNetworkInterceptor.shared

        switch action {
        case "mock":
            return handleMock(command)
        case "mocks":
            let mocks = interceptor.activeMocks
            return .ok(
                id: command.id,
                data: [
                    "count": AnyCodable(mocks.count),
                    "mocks": AnyCodable(mocks.map { AnyCodable($0.toDictionary()) }),
                ])
        case "remove_mock":
            guard let mockId = command.params?["id"]?.stringValue else {
                return .error(id: command.id, message: "Missing 'id' param for remove_mock")
            }
            interceptor.removeMock(id: mockId)
            return .ok(
                id: command.id,
                data: [
                    "removed": AnyCodable(mockId)
                ])
        case "clear_mocks":
            interceptor.removeAllMocks()
            return .ok(
                id: command.id,
                data: [
                    "cleared": AnyCodable(true)
                ])
        default:
            return .error(id: command.id, message: "Unknown mock action '\(action)'")
        }
    }

    private func handleMock(_ command: PepperCommand) -> PepperResponse {
        guard let urlPattern = command.params?["url"]?.stringValue else {
            return .error(
                id: command.id, message: "Missing 'url' param — URL pattern to match (substring, case-insensitive)")
        }

        let interceptor = PepperNetworkInterceptor.shared
        let statusCode = command.params?["status"]?.intValue ?? 200
        let bodyString = command.params?["body"]?.stringValue ?? ""
        let bodyData = Data(bodyString.utf8)
        let methodFilter = command.params?["method"]?.stringValue

        // Build headers — default to application/json if not specified
        var headers: [String: String] = ["Content-Type": "application/json"]
        if let customHeaders = command.params?["headers"]?.dictValue {
            for (key, value) in customHeaders {
                if let str = value.stringValue {
                    headers[key] = str
                }
            }
        }

        // Build description
        var description = "Mock \(statusCode)"
        description += " [url~\(urlPattern)]"
        if let m = methodFilter { description += " [\(m)]" }
        description += " (\(PepperNetworkInterceptor.formatBytes(bodyData.count)) body)"

        let matcher = RequestMatcher(urlContains: urlPattern, method: methodFilter)

        // Auto-start interception if not already active
        if !interceptor.isIntercepting {
            interceptor.install()
        }

        let mockId = command.params?["id"]?.stringValue ?? UUID().uuidString
        let mock = PepperNetworkMock(
            id: mockId,
            matcher: matcher,
            statusCode: statusCode,
            headers: headers,
            body: bodyData,
            description: description
        )
        interceptor.addMock(mock)

        return .ok(
            id: command.id,
            data: [
                "mock_id": AnyCodable(mockId),
                "status_code": AnyCodable(statusCode),
                "description": AnyCodable(description),
                "active_mocks": AnyCodable(interceptor.activeMocks.count),
            ])
    }

    // MARK: - Stream Log

    private func handleStreamLog(_ command: PepperCommand) -> PepperResponse {
        guard let transactionId = command.params?["id"]?.stringValue else {
            return .error(
                id: command.id,
                message: "Missing 'id' param — pass the transaction ID of a streaming request")
        }

        let limit = command.params?["limit"]?.intValue ?? 100
        let offset = command.params?["offset"]?.intValue ?? 0
        let interceptor = PepperNetworkInterceptor.shared

        let chunks = interceptor.streamingChunksForTransaction(
            transactionId, limit: limit, offset: offset)
        let totalChunks = interceptor.streamingChunkCount(for: transactionId)

        if totalChunks == 0 {
            return .error(
                id: command.id,
                message:
                    "No streaming chunks found for transaction '\(transactionId)'. "
                    + "Either the ID is wrong or this isn't a streaming response.")
        }

        return .ok(
            id: command.id,
            data: [
                "transaction_id": AnyCodable(transactionId),
                "count": AnyCodable(chunks.count),
                "total": AnyCodable(totalChunks),
                "offset": AnyCodable(offset),
                "has_more": AnyCodable(offset + chunks.count < totalChunks),
                "chunks": AnyCodable(chunks.map { AnyCodable($0.toDictionary()) }),
            ])
    }

    // MARK: - WebSocket

    private func handleWsAction(_ action: String, _ command: PepperCommand) -> PepperResponse {
        switch action {
        case "ws_log":
            return handleWsLog(command)
        case "ws_status":
            return handleWsStatus(command)
        case "ws_clear":
            PepperWebSocketInterceptor.shared.clearBuffer()
            return .ok(id: command.id, data: ["cleared": AnyCodable(true)])
        default:
            return .error(id: command.id, message: "Unknown ws action '\(action)'")
        }
    }

    private func handleWsLog(_ command: PepperCommand) -> PepperResponse {
        let wsInterceptor = PepperWebSocketInterceptor.shared

        // Auto-start if not active
        if !wsInterceptor.isIntercepting {
            wsInterceptor.install()
        }

        let limit = command.params?["limit"]?.intValue ?? 50
        let filter = command.params?["filter"]?.stringValue
        let direction = command.params?["direction"]?.stringValue
        let frames = wsInterceptor.recentFrames(limit: limit, connectionFilter: filter, directionFilter: direction)
        return .ok(
            id: command.id,
            data: [
                "count": AnyCodable(frames.count),
                "frames": AnyCodable(frames.map { AnyCodable($0.toDictionary()) }),
            ])
    }

    // MARK: - WebSocket Status

    private func handleWsStatus(_ command: PepperCommand) -> PepperResponse {
        let wsInterceptor = PepperWebSocketInterceptor.shared
        let activeConns = wsInterceptor.activeConnections
        let closedConns = wsInterceptor.recentClosedConnections
        var data: [String: AnyCodable] = [
            "active": AnyCodable(wsInterceptor.isIntercepting),
            "buffer_size": AnyCodable(wsInterceptor.bufferSize),
            "frame_count": AnyCodable(wsInterceptor.frameCount),
            "total_recorded": AnyCodable(wsInterceptor.totalRecorded),
            "total_dropped": AnyCodable(wsInterceptor.totalDropped),
            "active_connections": AnyCodable(activeConns.map { AnyCodable($0.toDictionary()) }),
        ]
        if !closedConns.isEmpty {
            data["closed_connections"] = AnyCodable(closedConns.map { AnyCodable($0.toDictionary()) })
        }
        return .ok(id: command.id, data: data)
    }
}
