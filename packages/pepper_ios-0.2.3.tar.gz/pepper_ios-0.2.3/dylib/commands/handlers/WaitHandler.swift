import UIKit
import os

/// Handles {"cmd": "wait_for", "until": {"element": "id", "state": "visible"}, "timeout_ms": 5000}
/// Polls for a condition to be met, returning when satisfied or on timeout.
/// Supported conditions: element visible, element exists, screen is X, element has value,
/// text visible (any element matching text label), predicate match/gone.
struct WaitHandler: PepperHandler {
    let commandName = "wait_for"
    let timeout: TimeInterval = 35.0  // generous — handler has its own internal deadline
    private var logger: Logger { PepperLogger.logger(category: "wait_for") }

    /// Polling interval in seconds.
    private static let pollInterval: TimeInterval = PepperDefaults.waitPollInterval

    /// Default timeout if none specified.
    private static let defaultTimeoutMs: Int = 5000

    func handle(_ command: PepperCommand) -> PepperResponse {
        guard let untilDict = command.params?["until"]?.value as? [String: AnyCodable] else {
            return .error(id: command.id, message: "Missing required param: until")
        }

        let timeoutMs = (command.params?["timeout_ms"]?.value as? Int) ?? Self.defaultTimeoutMs
        let startTime = Date()
        let deadline = startTime.addingTimeInterval(TimeInterval(timeoutMs) / 1000.0)

        let parseResult = parseCondition(from: untilDict)
        guard let condition = parseResult.condition else {
            return .error(
                id: command.id,
                message: parseResult.error
                    ?? "Invalid wait condition. Supported: element+state, text, screen, predicate.")
        }

        logger.info("Wait started, timeout \(timeoutMs)ms, condition: \(String(describing: condition))")

        // Check immediately — if already satisfied, return without waiting.
        if evaluate(condition) {
            logger.info("Wait condition already met")
            return .ok(
                id: command.id,
                data: [
                    "waited_ms": AnyCodable(0)
                ])
        }

        // Poll on a background thread so the main thread's RunLoop can process
        // SwiftUI rendering between condition evaluations. The original approach
        // used RunLoop.current.run(until:) in a tight loop on the main thread,
        // which created nested RunLoop iterations that blocked SwiftUI @Observable
        // state changes from triggering re-renders. (BUG-007)
        var pollResult: PepperResponse?
        let group = DispatchGroup()
        group.enter()
        let handler = self

        DispatchQueue.global(qos: .userInitiated).async {
            let axObserver = PepperAccessibilityObserver.shared
            while Date() < deadline {
                // Wake on accessibility notification or poll interval, whichever is first.
                // When the accessibility observer is active, screen changes signal the
                // semaphore immediately, so wait_for detects transitions near-instantly.
                // Without the observer, fall back to a fixed sleep.
                if axObserver.isRunning {
                    let _ = axObserver.waitForChange(timeout: Self.pollInterval)
                } else {
                    Thread.sleep(forTimeInterval: Self.pollInterval)
                }

                // Brief hop to main thread for UIKit-safe condition evaluation
                var conditionMet = false
                DispatchQueue.main.sync {
                    conditionMet = handler.evaluate(condition)
                }

                if conditionMet {
                    let elapsedMs = Int(Date().timeIntervalSince(startTime) * 1000)
                    handler.logger.info("Wait condition met after \(elapsedMs)ms")
                    pollResult = .ok(
                        id: command.id,
                        data: [
                            "waited_ms": AnyCodable(elapsedMs)
                        ])
                    group.leave()
                    return
                }
            }

            handler.logger.warning("Wait timed out after \(timeoutMs)ms")
            var found: [String] = []
            DispatchQueue.main.sync {
                found = PepperElementSuggestions.nearbyLabels(maxResults: 5)
            }
            var data: [String: AnyCodable] = ["message": AnyCodable("Timeout after \(timeoutMs)ms")]
            if !found.isEmpty {
                data["found"] = AnyCodable(found.map { AnyCodable($0) })
            }
            data["suggestion"] = AnyCodable("Try `look` to see current screen state")
            pollResult = PepperResponse(id: command.id, status: .error, data: data)
            group.leave()
        }

        // Cooperatively yield the main thread while the background thread polls.
        // RunLoop spins service the DispatchQueue.main.sync calls from above
        // and allow SwiftUI, CADisplayLink, and Core Animation to process normally.
        // The RunLoop wakes early when dispatch blocks arrive, so using pollInterval
        // as the max sleep avoids a tight busy-wait while staying responsive.
        while group.wait(timeout: .now()) == .timedOut {
            RunLoop.current.run(mode: .default, before: Date(timeIntervalSinceNow: Self.pollInterval))
        }

        return pollResult ?? .error(id: command.id, message: "Internal error: poll result unavailable")
    }

    // MARK: - Condition Parsing

    private enum WaitCondition: CustomStringConvertible {
        case elementVisible(id: String)
        case elementExists(id: String)
        case elementHasValue(id: String, value: String)
        case screenIs(screenID: String)
        case textVisible(text: String, exact: Bool)
        case predicateMatch(format: String)
        case predicateGone(format: String)

        var description: String {
            switch self {
            case .elementVisible(let id): return "element '\(id)' visible"
            case .elementExists(let id): return "element '\(id)' exists"
            case .elementHasValue(let id, let value): return "element '\(id)' has value '\(value)'"
            case .screenIs(let screenID): return "screen is '\(screenID)'"
            case .textVisible(let text, let exact): return "text '\(text)' visible (exact: \(exact))"
            case .predicateMatch(let format): return "predicate match '\(format)'"
            case .predicateGone(let format): return "predicate gone '\(format)'"
            }
        }
    }

    private func parseCondition(from dict: [String: AnyCodable])
        -> (condition: WaitCondition?, error: String?)
    {
        if let elementID = dict["element"]?.value as? String {
            let state = (dict["state"]?.value as? String) ?? "visible"
            switch state {
            case "visible":
                return (.elementVisible(id: elementID), nil)
            case "exists":
                return (.elementExists(id: elementID), nil)
            case "has_value":
                if let value = dict["value"]?.value as? String {
                    return (.elementHasValue(id: elementID, value: value), nil)
                }
                return (nil, "has_value state requires a 'value' param")
            default:
                return (nil, "Unknown state '\(state)'. Supported: visible, exists, has_value")
            }
        }

        if let screenID = dict["screen"]?.value as? String {
            return (.screenIs(screenID: screenID), nil)
        }

        if let text = dict["text"]?.value as? String {
            let exact = (dict["exact"]?.value as? Bool) ?? true
            return (.textVisible(text: text, exact: exact), nil)
        }

        if let predicateFormat = dict["predicate"]?.value as? String {
            // Validate the predicate format up front so a typo fails fast
            var parseError: String?
            PepperObjCExceptionCatcher.try(
                { _ = NSPredicate(format: predicateFormat, argumentArray: nil) },
                catch: { exception in
                    parseError = "Invalid predicate: \(exception.reason ?? exception.name.rawValue)"
                })
            if let parseError = parseError {
                return (nil, parseError)
            }
            let expect = (dict["expect"]?.value as? String) ?? "match"
            let condition: WaitCondition =
                expect == "gone"
                ? .predicateGone(format: predicateFormat)
                : .predicateMatch(format: predicateFormat)
            return (condition, nil)
        }

        return (nil, nil)
    }

    // MARK: - Condition Evaluation (called on main thread via dispatcher)

    private func evaluate(_ condition: WaitCondition) -> Bool {
        guard let window = UIWindow.pepper_keyWindow else { return false }

        switch condition {
        case .elementVisible(let id):
            if let result = PepperElementResolver.resolveByID(id, in: window) {
                if result.tapPoint != nil {
                    // SwiftUI element found via accessibility tree — visible by definition
                    return true
                }
                return !result.view.isHidden && result.view.alpha > 0 && result.view.window != nil
            }
            return false

        case .elementExists(let id):
            return PepperElementResolver.resolveByID(id, in: window) != nil

        case .elementHasValue(let id, let expected):
            guard let result = PepperElementResolver.resolveByID(id, in: window) else { return false }
            if result.tapPoint != nil {
                return swiftUIAccessibilityValue(id: id) == expected
            }
            return currentValue(of: result.view) == expected

        case .screenIs(let screenID):
            guard let topVC = Self.topViewController else { return false }
            return topVC.pepperScreenID == screenID

        case .textVisible(let text, let exact):
            return evaluateTextVisible(text: text, exact: exact, window: window)

        case .predicateMatch(let format):
            return evaluatePredicate(format: format, expectMatch: true)

        case .predicateGone(let format):
            return evaluatePredicate(format: format, expectMatch: false)
        }
    }

    /// Search all windows and SwiftUI accessibility, matching TapHandler's multi-source strategy.
    private func evaluateTextVisible(text: String, exact: Bool, window: UIWindow) -> Bool {
        for w in UIWindow.pepper_allVisibleWindows {
            if w.pepper_findElement(text: text, exact: exact) != nil {
                return true
            }
        }
        if PepperSwiftUIBridge.shared.findElement(label: text, exact: exact, in: window) != nil {
            return true
        }
        if PepperSwiftUIBridge.shared.findAccessibilityElementCenter(label: text, exact: exact) != nil {
            return true
        }
        return false
    }

    private func evaluatePredicate(format: String, expectMatch: Bool) -> Bool {
        let result = PepperPredicateQuery.evaluate(predicate: format, hitTestFilter: false, limit: 1)
        guard result.error == nil else { return false }
        return expectMatch ? !result.matches.isEmpty : result.matches.isEmpty
    }

    // MARK: - Helpers

    /// Read a SwiftUI element's value from the accessibility tree by identifier.
    private func swiftUIAccessibilityValue(id: String) -> String? {
        let accElements = PepperSwiftUIBridge.shared.collectAccessibilityElements()
        return accElements.first(where: { $0.identifier == id })?.value
    }

    private func currentValue(of view: UIView) -> String? {
        switch view {
        case let label as UILabel:
            return label.text
        case let field as UITextField:
            return field.text
        case let textView as UITextView:
            return textView.text
        case let toggle as UISwitch:
            return toggle.isOn ? "true" : "false"
        default:
            return nil
        }
    }

    private static var topViewController: UIViewController? {
        guard let root = UIWindow.pepper_keyWindow?.rootViewController else { return nil }
        return topMost(from: root)
    }

    private static func topMost(from vc: UIViewController) -> UIViewController {
        if let presented = vc.presentedViewController {
            return topMost(from: presented)
        }
        if let nav = vc as? UINavigationController, let visible = nav.visibleViewController {
            return topMost(from: visible)
        }
        if let tab = vc as? UITabBarController, let selected = tab.selectedViewController {
            return topMost(from: selected)
        }
        // Custom tab bar container (via TabBarProvider)
        if PepperAppConfig.shared.tabBarProvider?.isTabBarContainer(vc) == true,
            let displayed = vc.pepper_currentViewController
        {
            return topMost(from: displayed)
        }
        return vc
    }
}
