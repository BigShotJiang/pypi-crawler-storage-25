# Explore App

Systematically crawl a running iOS app through Pepper to map its screens, discover blind spots, and recommend adapter configuration.

Run with: `/explore-app <app-name>` or `/explore-app` (uses whatever's already connected)

## Known Apps

These apps have been tested with Pepper. Use the name as the argument.

| Name | Bundle ID | Notes |
|------|-----------|-------|
| ice-cubes | com.thomasricouard.IceCubesApp | Mastodon client. No login required to browse — cancel the Add Account screen to enter read-only mode. SwiftUI app. |
| wikipedia | org.wikimedia.wikipedia | Wikipedia iOS. Clone + build via `make wikipedia-setup`. UIKit app. |
| test-app | com.pepper.testapp | PepperTestApp — Pepper's own test harness. Build via `make test-app`. |

## Phase 0: Launch

If the user passed an app name:

1. **Find a booted simulator:** Run `xcrun simctl list devices booted` via Bash to find a booted sim UDID. If none, stop and tell the user to boot one.
2. **Check Pepper connection:** Use `status` with the sim UDID. If Pepper is already connected to the right app, skip to Phase 1.
3. **Deploy:** Use the `deploy_sim` MCP tool with `bundle_id` set to the known app's bundle ID and `workspace` set to the Pepper repo root (needed for locating the dylib). This handles:
   - Terminating the existing app
   - Launching with `SIMCTL_CHILD_DYLD_INSERT_LIBRARIES` and all required env vars
   - Granting privacy permissions
   - Waiting for Pepper to connect
4. **Verify:** Use `status` to confirm Pepper connected. If it fails, wait 3 seconds and retry once.

**NEVER** launch apps manually with `xcrun simctl launch`. Always use `deploy_sim` — it sets the correct env vars for dylib injection.

If no app name was given, just use `status` to check what's already connected. If nothing is connected, list booted sims and ask the user what app to explore.

## Phase 1: App Identity

```
Use the Pepper `status` tool to get:
- Bundle ID
- App name / version
- Current screen
```

Record this as the exploration target.

## Phase 2: Screen Crawl

Starting from the current screen, systematically discover all reachable screens.

For each screen:

1. **Observe:** `look` — record all elements, their types, labels, tap targets.
2. **Visual check:** `look visual=true` — compare structured output against the actual screenshot. Note discrepancies:
   - Elements visible on screen but missing from `look` output (Pepper blind spots)
   - Elements in `look` that don't match what's visually present (stale/phantom elements)
   - Custom drawn content (charts, maps, canvas) that `look` can't describe
3. **Accessibility audit:** `accessibility_audit` — record issues (missing labels, small tap targets).
4. **Element detail:** For interactive elements without labels/IDs, use `read_element` to inspect properties. Note which elements would benefit from accessibility identifiers.
5. **Navigate deeper:** Tap into sub-screens, modals, sheets. Track the navigation path so you can get back.
6. **Record:** Add the screen to the exploration map with:
   - Screen name (from `screen` tool)
   - Element count (interactive vs total)
   - Blind spots found
   - Navigation path to reach it

### Navigation strategy:
- Start with tab bar items (if present) — these are top-level entry points
- Within each tab, explore the primary navigation path (lists → detail → sub-detail)
- Check for modals, sheets, action sheets, alerts
- Look for settings/profile screens
- Try `back` to return, fall back to tab taps if lost
- Don't go deeper than 4 levels — diminishing returns

### What to look for:
- **Unlabeled buttons:** Interactive elements with no text, label, or accessibility ID. `look` shows these as `(icon_button)` or `(button)` with no identifying info. These are the #1 usability problem — agents can't tap what they can't name.
- **Custom views:** Anything that renders outside UIKit/SwiftUI standard controls (charts, maps, drawing canvases, WebViews). `look` can't introspect these.
- **Gesture-only interactions:** Swipe-to-delete, long-press menus, drag-and-drop. These won't appear as tappable elements.
- **Dynamic content:** Screens that change based on state (logged in vs out, empty vs populated, loading vs loaded). Note which states you observed.
- **Deep links:** If the app supports URL schemes or universal links, test a few via `navigate deeplink="scheme://path"`.
- **Tab bar / navigation patterns:** How the app structures navigation. This informs adapter deep link routes.

## Phase 3: Monitoring Check

On 2-3 representative screens with network activity:

1. `network action=start` → trigger a load → `network action=log` → `network action=stop`
   - Are API calls captured? Check for GraphQL (all same URL?), WebSocket, background fetches.
   - Note the API base URL and patterns.
2. `console action=start` → navigate around → `console action=log` → `console action=stop`
   - How noisy is the console? Is app logging useful or drowned in system noise?
3. `timeline query last_seconds=30`
   - Is the flight recorder capturing meaningful events?

## Phase 4: Report

Output a structured report:

```markdown
## App Exploration Report: <App Name> (<Bundle ID>)

### Screens Discovered
| Screen | Elements | Blind Spots | Path |
|--------|----------|-------------|------|
| ...    | ...      | ...         | ...  |

### Blind Spots (Pepper can't see or interact with)
- <description, screen, what's needed>

### Unlabeled Elements (agents can't target)
- <element type, screen, suggested fix>

### Accessibility Issues
- <from accessibility_audit, prioritized>

### Adapter Recommendations
Based on the exploration, here's what an adapter for this app should include:
- **Deep link routes:** <suggested routes based on navigation structure>
- **Icon mappings:** <custom icons that need human-readable names>
- **Custom tools:** <app-specific actions that would benefit from dedicated tools>
- **Element aliases:** <unlabeled elements that need stable identifiers>

### Monitoring Notes
- API pattern: <REST/GraphQL/WebSocket/mixed>
- Console noise level: <low/medium/high>
- Notable: <anything surprising>

### Missing Pepper Capabilities
- <things the app does that Pepper has no tool for>
```

## Targeted Mode

If invoked with a screen name after the app name (`/explore-app ice-cubes Settings`), skip the full crawl:
1. Navigate to the named screen (try deep link first, then tap sequence).
2. Run phases 1-3 on just that screen and its immediate children.
3. Output a focused report for that screen only.

## Tips
- If the app has onboarding/login, you may need to complete it first. Ask the user if you get stuck on a gate.
- Some apps have different states (logged in, premium, first launch). Note which state you're exploring.
- If `look` returns too many elements, use `look scope:"<container>"` to focus on sections.
- Use `snapshot save` before and after interactions to track what changed.
