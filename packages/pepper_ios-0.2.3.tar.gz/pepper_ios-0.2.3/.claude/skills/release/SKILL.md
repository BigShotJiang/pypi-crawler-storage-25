---
name: release
description: Cut a new Pepper release — bump version, tag, push, then monitor CI pipeline
user_invocable: true
---

# Release

Cut a new Pepper release. Runs the deterministic script, then monitors CI.

## Arguments

Accepts an optional bump type override: `patch`, `minor`, or `major`. If omitted, auto-detect from commits since the last tag.

## Steps

### 0. Determine bump type

If the user didn't specify a bump type, figure it out:

```bash
git log $(git describe --tags --abbrev=0)..HEAD --oneline
```

Read the commit messages and classify:
- **major** — breaking change to the MCP protocol, dylib wire format, or `.env` config keys. Commits with "BREAKING" or that remove/rename public tools.
- **minor** — new MCP tools, new commands, new skills, new CLI features. Commits with "Add", "feat", or new `mcp-registry.json` entries.
- **patch** — bug fixes, performance, docs, refactors, CI changes. Commits with "Fix", "Strip", "Bump", "Update", "Refactor", etc.

Tell the user what you picked and why (one line). If ambiguous, ask.

### 1. Run the release script

```bash
scripts/release.sh <patch|minor|major>
```

This bumps the version in `pyproject.toml` + `pepper_ios/__init__.py`, commits, tags, and pushes. If any guard fails (dirty tree, not on main, behind remote), stop and tell the user.

### 2. Monitor the CI pipeline

After the script succeeds, monitor the two workflows that fire on tag push:

**Mirror** (`mirror-code.yml`) — rewrites history and pushes to the public repo, including the tag. Usually finishes in ~1 minute.

```bash
gh run list --workflow=mirror-code.yml --limit=1
```

**Release** (`release.yml`) — builds dylib, creates GitHub releases on both repos, publishes to PyPI. Usually finishes in ~5 minutes. Depends on mirror completing first (waits up to 2.5min for public tag).

```bash
gh run list --workflow=release.yml --limit=1
```

Poll every 30 seconds. For each workflow, report:
- When it starts
- When it completes (success or failure)
- If failed, fetch logs: `gh run view <id> --log-failed`

### 3. Verify

After both workflows succeed:

```bash
# GitHub release exists on both repos
gh release view v<version>
gh release view v<version> --repo skwallace36/Pepper

# PyPI package updated
pip index versions pepper-ios 2>/dev/null || echo "check https://pypi.org/project/pepper-ios/"
```

Report the final state: version, release URLs, PyPI status.

## Architecture

```
git push --tags
  ├── mirror-code.yml     → filter + push to skwallace36/Pepper (public)
  └── release.yml         → build dylib → GitHub releases (both repos) → PyPI
                               └── waits for mirror to push tag to public before creating public release
```
