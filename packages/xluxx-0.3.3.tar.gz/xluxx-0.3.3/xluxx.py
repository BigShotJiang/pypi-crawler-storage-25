"""XLUXX Trust Layer — Python SDK. Makes AI agents reliable."""
import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from dataclasses import dataclass
from typing import Optional, List, Dict, Any

API_BASE = "https://api.xluxx.net"

@dataclass
class ResolveResult:
    best_server: Optional[str]
    confidence: float
    resonance_score: float
    fractal_reliability: float
    coherence_drift: float
    expected_latency: str
    risk_flags: List[str]
    reason: str
    fallback: Optional[str]
    fallback_stability: Optional[float]
    candidates: List[Dict]
    intent: str
    resolved_at: str
    raw: Dict[str, Any]

    @classmethod
    def from_dict(cls, d):
        return cls(
            best_server=d.get("best_server") or d.get("best_tool"),
            confidence=d.get("confidence", 0),
            resonance_score=d.get("resonance_score", 0),
            fractal_reliability=d.get("fractal_reliability", 0),
            coherence_drift=d.get("coherence_drift", 0),
            expected_latency=d.get("expected_latency", "unknown"),
            risk_flags=d.get("risk_flags", []),
            reason=d.get("reason", ""),
            fallback=d.get("fallback"),
            fallback_stability=d.get("fallback_stability"),
            candidates=d.get("candidates", d.get("ranked_tools", [])),
            intent=d.get("intent", ""),
            resolved_at=d.get("resolved_at", ""),
            raw=d
        )

class TrustLayerError(Exception):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code

class TrustLayer:
    """XLUXX Trust Layer client. Provides runtime trust scores for MCP servers."""
    def __init__(self, api_key=None, base_url=API_BASE):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def _request(self, method, path, body=None):
        url = f"{self.base_url}{path}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        data = json.dumps(body).encode() if body else None
        req = Request(url, data=data, headers=headers, method=method)
        try:
            with urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except HTTPError as e:
            body = e.read().decode() if e.fp else ""
            try: msg = json.loads(body).get("error", body)
            except: msg = body
            raise TrustLayerError(msg, e.code)
        except URLError as e:
            raise TrustLayerError(f"Connection failed: {e.reason}")

    def resolve(self, intent, tools=None, category=None, min_trust_score=None, max_latency_ms=None):
        body = {"intent": intent}
        if tools: body["available_tools"] = tools
        if category: body["category"] = category
        if min_trust_score is not None: body["min_trust_score"] = min_trust_score
        if max_latency_ms is not None: body["max_latency_ms"] = max_latency_ms
        return ResolveResult.from_dict(self._request("POST", "/resolve-tool", body))

    def rank(self, tools):
        return self._request("POST", "/rank-tools", {"tools": tools})

    def recommend(self, task):
        return self._request("POST", "/recommend", {"task": task})

    def resonance(self, server_id):
        return self._request("GET", f"/resonance/{server_id}")

    def chain_resonance(self, tools):
        return self._request("POST", "/resonance/chain", {"tools": tools})

    def status(self, server_id):
        return self._request("GET", f"/status/{server_id}")

    def trends(self, server_id):
        return self._request("GET", f"/trends/{server_id}")

    def alerts(self):
        return self._request("GET", "/alerts")

    def server(self, server_id):
        return self._request("GET", f"/servers/{server_id}")

    def servers(self, limit=50):
        return self._request("GET", f"/servers?limit={limit}").get("servers", [])

    def search(self, query):
        return self._request("GET", f"/search?q={query}").get("results", [])

    def usage(self):
        return self._request("GET", "/usage")

    def health(self):
        return self._request("GET", "/health")

    @staticmethod
    def register(name, email, base_url=API_BASE):
        client = TrustLayer(base_url=base_url)
        return client._request("POST", "/register", {"name": name, "email": email}).get("api_key", "")

def resolve(intent, api_key=None, **kwargs):
    """Quick resolve — find the best tool for an intent."""
    return TrustLayer(api_key=api_key).resolve(intent, **kwargs)

# AutoGen integration
class AutoGenToolConfig:
    """Configuration helper for Microsoft AutoGen agents."""
    def __init__(self, api_key=None):
        self.trust = TrustLayer(api_key=api_key)
    
    def get_config(self):
        return {"trust_layer": self.trust, "resolve": self.trust.resolve, "rank": self.trust.rank}

def xluxx_tool_config(api_key=None):
    """Create an XLUXX-aware tool config for AutoGen agents."""
    return AutoGenToolConfig(api_key=api_key).get_config()
