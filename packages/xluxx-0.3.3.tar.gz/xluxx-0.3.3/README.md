# XLUXX Trust Layer

Runtime trust scores for MCP tools. Makes AI agents reliable.

## Install

```bash
pip install xluxx
```

## Usage

```python
from xluxx import TrustLayer

trust = TrustLayer()
result = trust.resolve("search the web")
print(result.best_server)    # "brave-search"
print(result.confidence)     # 0.985
```

## API: https://api.xluxx.net
## Docs: https://github.com/DrDMT-VR/xluxx-trust
