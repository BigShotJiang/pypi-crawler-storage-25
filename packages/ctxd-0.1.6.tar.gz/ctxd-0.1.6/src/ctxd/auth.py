import threading
import time
import webbrowser
from typing import Any

import httpx

from ctxd.config import (
    clear_credentials,
    load_credentials,
    resolve_auth_api_url,
    resolve_base_url,
    resolve_client_id,
    save_credentials,
)
from ctxd.exceptions import CtxdAuthError
from ctxd.models import (
    AuthorizationServerMetadata,
    CredentialStore,
    DeviceLoginPollResponse,
    DeviceLoginStartResponse,
    OAuthTokenResponse,
    ResourceMetadata,
)

_REFRESH_LOCK = threading.Lock()
_EXPIRY_SAFETY_SECONDS = 60


def _normalize_base_url(base_url: str) -> str:
    normalized = base_url.rstrip("/")
    if normalized.endswith("/mcp"):
        normalized = normalized[: -len("/mcp")]
    if normalized.endswith("/sse"):
        normalized = normalized[: -len("/sse")]
    return normalized


def discover_resource_metadata(base_url: str) -> ResourceMetadata:
    root_url = _normalize_base_url(resolve_base_url(base_url))
    response = httpx.get(
        f"{root_url}/.well-known/oauth-protected-resource", timeout=30.0
    )
    response.raise_for_status()
    return ResourceMetadata.model_validate(response.json())


def discover_authorization_server_metadata(
    authorization_server: str,
) -> AuthorizationServerMetadata:
    candidates = [
        authorization_server.rstrip("/"),
        f"{authorization_server.rstrip('/')}/.well-known/oauth-authorization-server",
        f"{authorization_server.rstrip('/')}/.well-known/openid-configuration",
    ]

    last_error: Exception | None = None
    for candidate in candidates:
        try:
            response = httpx.get(candidate, timeout=30.0)
            response.raise_for_status()
            payload = response.json()
            if "authorization_endpoint" in payload and "token_endpoint" in payload:
                return AuthorizationServerMetadata.model_validate(payload)
        except Exception as exc:  # pragma: no cover - only hit in integration
            last_error = exc

    raise CtxdAuthError(
        "Unable to discover authorization server metadata.",
        payload=str(last_error) if last_error else None,
    )


def refresh_credentials(
    credentials: CredentialStore,
    *,
    client_id: str | None = None,
) -> CredentialStore:
    if not credentials.refresh_token:
        raise CtxdAuthError("No refresh token is available. Run `ctxd login` again.")

    resource_metadata = discover_resource_metadata(credentials.base_url)
    auth_server = resource_metadata.authorization_servers[0]
    auth_metadata = discover_authorization_server_metadata(auth_server)
    payload = {
        "grant_type": "refresh_token",
        "refresh_token": credentials.refresh_token,
        "client_id": resolve_client_id(client_id or credentials.client_id),
        "resource": resource_metadata.resource,
    }
    request_kwargs = _build_token_request_kwargs(
        payload=payload,
        client_id=resolve_client_id(client_id or credentials.client_id),
        client_secret=credentials.client_secret,
        token_endpoint_auth_method=credentials.token_endpoint_auth_method,
    )
    response = httpx.post(auth_metadata.token_endpoint, timeout=30.0, **request_kwargs)
    return _build_credentials_from_token_response(
        response=response,
        base_url=credentials.base_url,
        existing_refresh_token=credentials.refresh_token,
        client_id=resolve_client_id(client_id or credentials.client_id),
        client_secret=credentials.client_secret,
        token_endpoint_auth_method=credentials.token_endpoint_auth_method,
    )


def ensure_valid_credentials(
    *, base_url: str | None = None, client_id: str | None = None
) -> CredentialStore:
    credentials = load_credentials()
    if credentials is None:
        raise CtxdAuthError("Missing credentials. Run `ctxd login` first.")

    if base_url:
        credentials.base_url = _normalize_base_url(resolve_base_url(base_url))
    if client_id:
        credentials.client_id = resolve_client_id(client_id)

    if not _should_refresh(credentials):
        return credentials

    with _REFRESH_LOCK:
        latest_credentials = load_credentials() or credentials
        if base_url:
            latest_credentials.base_url = _normalize_base_url(
                resolve_base_url(base_url)
            )
        if client_id:
            latest_credentials.client_id = resolve_client_id(client_id)

        if not _should_refresh(latest_credentials):
            return latest_credentials

        refreshed = refresh_credentials(latest_credentials, client_id=client_id)
        save_credentials(refreshed)
        return refreshed


def login_with_browser(
    *,
    base_url: str | None = None,
    auth_api_url: str | None = None,
    timeout_seconds: float = 300.0,
    open_browser: bool = True,
    persist_credentials: bool | None = None,
) -> CredentialStore:
    device_login = start_device_login(base_url=base_url, auth_api_url=auth_api_url)
    if open_browser and not webbrowser.open(device_login.verification_uri_complete):
        raise CtxdAuthError(
            "Unable to open a browser automatically.",
            payload={"verification_uri": device_login.verification_uri_complete},
        )

    return wait_for_device_login(
        device_login=device_login,
        auth_api_url=auth_api_url,
        timeout_seconds=timeout_seconds,
        persist_credentials=(
            persist_credentials if persist_credentials is not None else True
        ),
    )


def start_device_login(
    *,
    base_url: str | None = None,
    auth_api_url: str | None = None,
) -> DeviceLoginStartResponse:
    resolved_base_url = _normalize_base_url(resolve_base_url(base_url))
    resolved_auth_api_url = resolve_auth_api_url(auth_api_url)
    response = httpx.post(
        f"{resolved_auth_api_url}/api/mcp/cli-login/start",
        json={"base_url": resolved_base_url},
        timeout=30.0,
    )
    if response.status_code >= 400:
        raise _build_http_error(
            response=response, message="Unable to start CLI login session."
        )
    return DeviceLoginStartResponse.model_validate(response.json())


def wait_for_device_login(
    *,
    device_login: DeviceLoginStartResponse,
    auth_api_url: str | None = None,
    timeout_seconds: float = 300.0,
    persist_credentials: bool = True,
) -> CredentialStore:
    resolved_auth_api_url = resolve_auth_api_url(auth_api_url)
    deadline = min(time.time() + timeout_seconds, float(device_login.expires_at))

    while time.time() < deadline:
        response = httpx.post(
            f"{resolved_auth_api_url}/api/mcp/cli-login/poll",
            json={"device_code": device_login.device_code},
            timeout=30.0,
        )
        if response.status_code >= 400:
            raise _build_http_error(
                response=response, message="Unable to poll CLI login session."
            )

        poll_result = DeviceLoginPollResponse.model_validate(response.json())
        if poll_result.status == "authorization_pending":
            time.sleep(device_login.interval_seconds)
            continue
        if poll_result.status == "expired":
            raise CtxdAuthError("CLI login session expired. Run `ctxd login` again.")
        if poll_result.status == "failed":
            raise CtxdAuthError(
                poll_result.error or "CLI login failed. Run `ctxd login` again."
            )
        if poll_result.status != "complete":
            raise CtxdAuthError(
                "CLI login returned an unexpected status.",
                payload={"status": poll_result.status},
            )

        if not poll_result.access_token or not poll_result.base_url:
            raise CtxdAuthError("CLI login completed without credentials.")
        if not poll_result.client_id or not poll_result.client_secret:
            raise CtxdAuthError("CLI login completed without client credentials.")

        credentials = CredentialStore(
            access_token=poll_result.access_token,
            refresh_token=poll_result.refresh_token,
            token_type=poll_result.token_type or "Bearer",
            expires_at=poll_result.expires_at,
            base_url=poll_result.base_url,
            client_id=poll_result.client_id,
            client_secret=poll_result.client_secret,
            token_endpoint_auth_method=poll_result.token_endpoint_auth_method,
        )
        if persist_credentials:
            save_credentials(credentials)
        return credentials

    raise CtxdAuthError("Timed out waiting for CLI login to complete.")


def logout(*, keep_base_url: bool = True) -> None:
    clear_credentials(keep_base_url=keep_base_url)


def _build_credentials_from_token_response(
    *,
    response: httpx.Response,
    base_url: str,
    existing_refresh_token: str | None,
    client_id: str,
    client_secret: str | None,
    token_endpoint_auth_method: str | None,
) -> CredentialStore:
    if response.status_code >= 400:
        raise _build_http_error(
            response=response, message="OAuth token request failed."
        )

    token_response = OAuthTokenResponse.model_validate(response.json())
    expires_at = None
    if token_response.expires_in is not None:
        expires_at = int(time.time()) + token_response.expires_in

    return CredentialStore(
        access_token=token_response.access_token,
        refresh_token=token_response.refresh_token or existing_refresh_token,
        token_type=token_response.token_type,
        expires_at=expires_at,
        base_url=base_url,
        client_id=client_id,
        client_secret=client_secret,
        token_endpoint_auth_method=token_endpoint_auth_method,
    )


def _build_token_request_kwargs(
    *,
    payload: dict[str, Any],
    client_id: str,
    client_secret: str | None,
    token_endpoint_auth_method: str | None,
) -> dict[str, Any]:
    auth_method = token_endpoint_auth_method or "none"
    if auth_method == "client_secret_post" and client_secret:
        post_payload = payload.copy()
        post_payload["client_secret"] = client_secret
        return {"data": post_payload}
    if auth_method == "client_secret_basic" and client_secret:
        basic_payload = payload.copy()
        basic_payload.pop("client_id", None)
        return {"data": basic_payload, "auth": (client_id, client_secret)}
    return {"data": payload}


def _should_refresh(credentials: CredentialStore) -> bool:
    if credentials.expires_at is None or credentials.refresh_token is None:
        return False
    return credentials.expires_at <= int(time.time()) + _EXPIRY_SAFETY_SECONDS


def _build_http_error(*, response: httpx.Response, message: str) -> CtxdAuthError:
    try:
        payload: Any = response.json()
    except ValueError:
        payload = response.text
    return CtxdAuthError(message, status_code=response.status_code, payload=payload)
