"""Public Python SDK for ctxd."""

from ctxd._metadata import SDK_NAME, SDK_VERSION, get_user_agent
from ctxd.async_client import AsyncClient
from ctxd.auth import ensure_valid_credentials, login_with_browser, logout
from ctxd.client import Client, CtxdClient
from ctxd.config import (
    DEFAULT_BASE_URL,
    clear_credentials,
    get_config_path,
    load_config,
    load_credentials,
    resolve_api_key,
    save_config,
    save_credentials,
)
from ctxd.exceptions import CtxdAuthError, CtxdError, CtxdProtocolError
from ctxd.models import CredentialStore, DocumentResult, ProfileResult, SearchResult

__all__ = [
    "AsyncClient",
    "Client",
    "CredentialStore",
    "CtxdClient",
    "CtxdAuthError",
    "CtxdError",
    "CtxdProtocolError",
    "DEFAULT_BASE_URL",
    "DocumentResult",
    "ProfileResult",
    "SDK_NAME",
    "SearchResult",
    "__version__",
    "clear_credentials",
    "ensure_valid_credentials",
    "get_config_path",
    "get_user_agent",
    "load_credentials",
    "login_with_browser",
    "load_config",
    "logout",
    "resolve_api_key",
    "save_config",
    "save_credentials",
]
__version__ = SDK_VERSION
