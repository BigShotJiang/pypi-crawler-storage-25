import asyncio
import json
from typing import Any

import httpx

from ctxd._metadata import get_user_agent
from ctxd.auth import ensure_valid_credentials, login_with_browser, logout
from ctxd.config import resolve_api_key, resolve_base_url
from ctxd.exceptions import CtxdAuthError, CtxdError, CtxdProtocolError
from ctxd.models import DocumentResult, ProfileResult, SearchResult


class AsyncClient:
    """Async client for the public ctxd MCP endpoint."""

    def __init__(
        self,
        *,
        access_token: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        client_id: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = self._normalize_base_url(resolve_base_url(base_url))
        self._access_token = access_token.strip() if access_token else None
        self._api_key = resolve_api_key(api_key)
        self._client_id = client_id.strip() if client_id else None
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def client_id(self) -> str | None:
        return self._client_id

    async def __aenter__(self) -> "AsyncClient":
        self._client = httpx.AsyncClient(timeout=self._timeout)
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def search(self, query: str) -> SearchResult:
        payload = await self.call_tool("search", {"query": query})
        return SearchResult.model_validate(payload)

    async def fetch_document(self, document_uid: str) -> DocumentResult:
        payload = await self.call_tool("fetch_document", {"document_uid": document_uid})
        return DocumentResult.model_validate(payload)

    async def get_profile(self) -> ProfileResult:
        payload = await self.call_tool("get_profile", {})
        return ProfileResult.model_validate(payload)

    async def login(
        self,
        *,
        open_browser: bool = True,
        timeout_seconds: float = 300.0,
        persist_credentials: bool | None = None,
    ):
        return await _run_sync(
            login_with_browser,
            base_url=self._base_url,
            timeout_seconds=timeout_seconds,
            open_browser=open_browser,
            persist_credentials=persist_credentials,
        )

    def logout(self, *, keep_base_url: bool = True) -> None:
        logout(keep_base_url=keep_base_url)

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        request_body = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": name,
                "arguments": arguments,
            },
            "id": 1,
        }
        token = await self._resolve_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json, text/event-stream",
            "User-Agent": get_user_agent(),
        }

        if self._client is not None:
            response = await self._client.post(
                self._base_url,
                headers=headers,
                json=request_body,
            )
        else:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    self._base_url,
                    headers=headers,
                    json=request_body,
                )

        return self._parse_response(response)

    async def _resolve_access_token(self) -> str:
        if self._api_key:
            return self._api_key

        if self._access_token:
            return self._access_token

        credentials = await _run_sync(
            ensure_valid_credentials,
            base_url=self._base_url,
            client_id=self._client_id,
        )
        if not credentials.access_token:
            raise CtxdAuthError("Missing access token. Run `ctxd login` first.")
        return credentials.access_token

    @staticmethod
    def _normalize_base_url(base_url: str) -> str:
        normalized = base_url.rstrip("/")
        if normalized.endswith("/sse"):
            normalized = normalized[: -len("/sse")]
        if not normalized.endswith("/mcp"):
            normalized = f"{normalized}/mcp"
        return normalized

    @staticmethod
    def _parse_response(response: httpx.Response) -> dict[str, Any]:
        if response.status_code >= 400:
            message = f"ctxd MCP request failed with status {response.status_code}"
            try:
                error_payload = response.json()
            except ValueError:
                error_payload = response.text
            raise CtxdError(
                message, status_code=response.status_code, payload=error_payload
            )

        content_type = response.headers.get("content-type", "")
        if "text/event-stream" in content_type:
            return AsyncClient._parse_sse_payload(response.text)
        if "application/json" in content_type:
            return AsyncClient._parse_json_payload(response.json())

        if response.text.startswith("event:") or response.text.startswith("data:"):
            return AsyncClient._parse_sse_payload(response.text)

        raise CtxdProtocolError(
            f"Unsupported MCP response content type: {content_type or 'unknown'}"
        )

    @staticmethod
    def _parse_sse_payload(raw_text: str) -> dict[str, Any]:
        data_line = next(
            (line for line in raw_text.splitlines() if line.startswith("data: ")),
            None,
        )
        if data_line is None:
            raise CtxdProtocolError("MCP SSE response did not contain a data line")

        body = json.loads(data_line[len("data: ") :])
        return AsyncClient._parse_json_payload(body)

    @staticmethod
    def _parse_json_payload(body: dict[str, Any]) -> dict[str, Any]:
        if "error" in body:
            raise CtxdError("MCP JSON-RPC error", payload=body["error"])

        result = body.get("result")
        if not isinstance(result, dict):
            raise CtxdProtocolError("MCP response did not include a result object")

        content = result.get("content")
        if not isinstance(content, list) or not content:
            raise CtxdProtocolError("MCP result content was missing or empty")

        first_item = content[0]
        if first_item.get("type") != "text":
            raise CtxdProtocolError("MCP result content item was not text")

        text = first_item.get("text")
        if not isinstance(text, str):
            raise CtxdProtocolError("MCP result text payload was not a string")

        if result.get("isError"):
            raise CtxdError(text, payload=result)

        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise CtxdProtocolError(
                "MCP result text payload was not valid JSON"
            ) from exc


async def _run_sync(func, /, *args, **kwargs):
    return await asyncio.to_thread(func, *args, **kwargs)
