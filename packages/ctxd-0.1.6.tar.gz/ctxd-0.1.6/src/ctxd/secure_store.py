import base64
import json
import os
import tempfile
from getpass import getpass
from pathlib import Path
from typing import Any

import keyring
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from keyring.backend import KeyringBackend
from keyring.errors import KeyringError, PasswordDeleteError

from ctxd.exceptions import CtxdAuthError

_SERVICE_NAME = "ctxd"
_CREDENTIAL_STORE_AUTO = "auto"
_CREDENTIAL_STORE_KEYRING = "keyring"
_CREDENTIAL_STORE_ENCRYPTED_FILE = "encrypted-file"
_DEFAULT_CREDENTIAL_STORE = _CREDENTIAL_STORE_AUTO
_DEFAULT_ENCRYPTED_STORE_PATH = Path.home() / ".ctxd" / "credentials.enc"
_KDF_ITERATIONS = 600_000


def _build_account_name(*, base_url: str, client_id: str | None) -> str:
    normalized_base_url = base_url.strip().rstrip("/")
    normalized_client_id = (client_id or "dynamic").strip() or "dynamic"
    return f"{normalized_base_url}|{normalized_client_id}"


def load_secret_bundle(*, base_url: str, client_id: str | None) -> dict[str, Any]:
    account_name = _build_account_name(base_url=base_url, client_id=client_id)
    backend = _resolve_storage_backend()
    if backend == _CREDENTIAL_STORE_KEYRING:
        return _load_secret_bundle_from_keyring(account_name)
    return _load_secret_bundle_from_encrypted_file(account_name)


def save_secret_bundle(
    bundle: dict[str, Any], *, base_url: str, client_id: str | None
) -> None:
    account_name = _build_account_name(base_url=base_url, client_id=client_id)
    backend = _resolve_storage_backend()
    if backend == _CREDENTIAL_STORE_KEYRING:
        _save_secret_bundle_to_keyring(account_name, bundle)
        return
    _save_secret_bundle_to_encrypted_file(account_name, bundle)


def clear_secret_bundle(*, base_url: str, client_id: str | None) -> None:
    account_name = _build_account_name(base_url=base_url, client_id=client_id)
    backend = _resolve_storage_backend()
    if backend == _CREDENTIAL_STORE_KEYRING:
        _clear_secret_bundle_from_keyring(account_name)
        return
    _clear_secret_bundle_from_encrypted_file(account_name)


def _resolve_storage_backend() -> str:
    configured = os.getenv("CTXD_CREDENTIAL_STORE", _DEFAULT_CREDENTIAL_STORE).strip()
    if configured not in {
        _CREDENTIAL_STORE_AUTO,
        _CREDENTIAL_STORE_KEYRING,
        _CREDENTIAL_STORE_ENCRYPTED_FILE,
    }:
        raise CtxdAuthError(
            "Invalid CTXD_CREDENTIAL_STORE value.",
            payload={"value": configured},
        )

    if configured == _CREDENTIAL_STORE_KEYRING:
        if not _keyring_is_available():
            raise CtxdAuthError("No usable OS keychain backend is available.")
        return _CREDENTIAL_STORE_KEYRING

    if configured == _CREDENTIAL_STORE_ENCRYPTED_FILE:
        return _CREDENTIAL_STORE_ENCRYPTED_FILE

    if _keyring_is_available():
        return _CREDENTIAL_STORE_KEYRING
    return _CREDENTIAL_STORE_ENCRYPTED_FILE


def _keyring_is_available() -> bool:
    backend: KeyringBackend = keyring.get_keyring()
    priority = getattr(backend, "priority", 0)
    return bool(priority and priority > 0)


def _load_secret_bundle_from_keyring(account_name: str) -> dict[str, Any]:
    try:
        payload = keyring.get_password(_SERVICE_NAME, account_name)
    except KeyringError as exc:
        raise CtxdAuthError("Unable to read credentials from the OS keychain.") from exc
    return _decode_bundle_payload(payload)


def _save_secret_bundle_to_keyring(account_name: str, bundle: dict[str, Any]) -> None:
    try:
        keyring.set_password(_SERVICE_NAME, account_name, json.dumps(bundle))
    except KeyringError as exc:
        raise CtxdAuthError("Unable to store credentials in the OS keychain.") from exc


def _clear_secret_bundle_from_keyring(account_name: str) -> None:
    try:
        keyring.delete_password(_SERVICE_NAME, account_name)
    except PasswordDeleteError:
        return
    except KeyringError as exc:
        raise CtxdAuthError(
            "Unable to remove credentials from the OS keychain."
        ) from exc


def _load_secret_bundle_from_encrypted_file(account_name: str) -> dict[str, Any]:
    store = _load_encrypted_store()
    bundle = store.get(account_name)
    if bundle is None:
        return {}
    if not isinstance(bundle, dict):
        raise CtxdAuthError("Stored encrypted credentials are invalid.")
    return bundle


def _save_secret_bundle_to_encrypted_file(
    account_name: str, bundle: dict[str, Any]
) -> None:
    store = _load_encrypted_store()
    store[account_name] = bundle
    _write_encrypted_store(store)


def _clear_secret_bundle_from_encrypted_file(account_name: str) -> None:
    store = _load_encrypted_store()
    if account_name not in store:
        return
    store.pop(account_name, None)
    _write_encrypted_store(store)


def _load_encrypted_store() -> dict[str, Any]:
    path = _get_encrypted_store_path()
    if not path.exists():
        return {}

    try:
        wrapper = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise CtxdAuthError("Encrypted credential store is invalid.") from exc

    if not isinstance(wrapper, dict):
        raise CtxdAuthError("Encrypted credential store is invalid.")

    salt_b64 = wrapper.get("salt")
    ciphertext_b64 = wrapper.get("ciphertext")
    if not isinstance(salt_b64, str) or not isinstance(ciphertext_b64, str):
        raise CtxdAuthError("Encrypted credential store is invalid.")

    try:
        salt = base64.urlsafe_b64decode(salt_b64.encode("utf-8"))
        ciphertext = base64.urlsafe_b64decode(ciphertext_b64.encode("utf-8"))
    except ValueError as exc:
        raise CtxdAuthError("Encrypted credential store is invalid.") from exc

    passphrase = _resolve_passphrase(confirm=False)
    fernet = Fernet(_derive_key(passphrase, salt))
    try:
        plaintext = fernet.decrypt(ciphertext)
    except InvalidToken as exc:
        raise CtxdAuthError("Unable to unlock encrypted credential store.") from exc

    try:
        payload = json.loads(plaintext.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise CtxdAuthError("Encrypted credential store is invalid.") from exc

    if not isinstance(payload, dict):
        raise CtxdAuthError("Encrypted credential store is invalid.")
    return payload


def _write_encrypted_store(store: dict[str, Any]) -> None:
    path = _get_encrypted_store_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    salt = os.urandom(16)
    passphrase = _resolve_passphrase(confirm=not path.exists())
    fernet = Fernet(_derive_key(passphrase, salt))
    ciphertext = fernet.encrypt(json.dumps(store).encode("utf-8"))
    wrapper = {
        "version": 1,
        "salt": base64.urlsafe_b64encode(salt).decode("utf-8"),
        "ciphertext": base64.urlsafe_b64encode(ciphertext).decode("utf-8"),
    }

    with tempfile.NamedTemporaryFile(
        "w", dir=path.parent, prefix=f"{path.name}.", delete=False
    ) as tmp:
        tmp.write(json.dumps(wrapper, indent=2, sort_keys=True) + "\n")
        tmp.flush()
        os.fsync(tmp.fileno())
        tmp_path = Path(tmp.name)

    os.replace(tmp_path, path)
    try:
        path.chmod(0o600)
    except OSError:
        pass


def _resolve_passphrase(*, confirm: bool) -> str:
    env_passphrase = os.getenv("CTXD_PASSPHRASE")
    if env_passphrase:
        return env_passphrase

    if not os.isatty(0):
        raise CtxdAuthError(
            "Encrypted credential storage requires a passphrase. Set CTXD_PASSPHRASE or run in an interactive terminal."
        )

    prompt = (
        "Create ctxd credential passphrase: "
        if confirm
        else "ctxd credential passphrase: "
    )
    passphrase = getpass(prompt)
    if not passphrase:
        raise CtxdAuthError("Credential passphrase cannot be empty.")
    if confirm:
        confirmation = getpass("Confirm ctxd credential passphrase: ")
        if passphrase != confirmation:
            raise CtxdAuthError("Credential passphrases did not match.")
    return passphrase


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=_KDF_ITERATIONS,
    )
    key = kdf.derive(passphrase.encode("utf-8"))
    return base64.urlsafe_b64encode(key)


def _get_encrypted_store_path() -> Path:
    configured = os.getenv("CTXD_ENCRYPTED_STORE_PATH")
    if configured:
        return Path(configured).expanduser()
    return _DEFAULT_ENCRYPTED_STORE_PATH


def _decode_bundle_payload(payload: str | None) -> dict[str, Any]:
    if not payload:
        return {}

    try:
        decoded = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise CtxdAuthError("Stored credentials are invalid.") from exc

    if not isinstance(decoded, dict):
        raise CtxdAuthError("Stored credentials are invalid.")
    return decoded
