SDK_NAME = "ctxd"
SDK_VERSION = "0.1.6"


def get_user_agent() -> str:
    return f"{SDK_NAME}/{SDK_VERSION}"
