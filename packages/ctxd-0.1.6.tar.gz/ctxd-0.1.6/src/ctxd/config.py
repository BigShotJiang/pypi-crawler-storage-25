import json
import os
import tempfile
from pathlib import Path
from typing import Any

from ctxd.models import CredentialStore
from ctxd.secure_store import (
    clear_secret_bundle,
    load_secret_bundle,
    save_secret_bundle,
)

DEFAULT_BASE_URL = "https://mcp.ctxd.dev"
DEFAULT_AUTH_API_URL = "https://api.ctxd.dev"
DEFAULT_CONFIG_PATH = Path.home() / ".ctxd" / "config.json"


def get_config_path() -> Path:
    configured = os.getenv("CTXD_CONFIG_PATH")
    if configured:
        return Path(configured).expanduser()
    return DEFAULT_CONFIG_PATH


def resolve_auth_api_url(auth_api_url: str | None = None) -> str:
    if auth_api_url and auth_api_url.strip():
        return auth_api_url.strip().rstrip("/")

    env_auth_api_url = os.getenv("CTXD_AUTH_API_URL")
    if env_auth_api_url and env_auth_api_url.strip():
        return env_auth_api_url.strip().rstrip("/")

    return DEFAULT_AUTH_API_URL


def resolve_api_key(api_key: str | None = None) -> str | None:
    if api_key and api_key.strip():
        return api_key.strip()

    env_api_key = os.getenv("CTXD_API_KEY")
    if env_api_key and env_api_key.strip():
        return env_api_key.strip()

    return None


def load_config() -> dict[str, Any]:
    path = get_config_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return {}


def save_config(config: dict[str, Any]) -> Path:
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.NamedTemporaryFile(
        "w", dir=path.parent, prefix=f"{path.name}.", delete=False
    ) as tmp:
        tmp.write(json.dumps(config, indent=2, sort_keys=True) + "\n")
        tmp.flush()
        os.fsync(tmp.fileno())
        tmp_path = Path(tmp.name)

    os.replace(tmp_path, path)
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return path


def load_credentials() -> CredentialStore | None:
    config = load_config()
    if not config:
        return None

    base_url = _resolve_base_url_from_config(config)
    client_id = _resolve_client_id_from_config(config)
    secret_bundle = load_secret_bundle(base_url=base_url, client_id=client_id)
    access_token = secret_bundle.get("access_token")
    if not isinstance(access_token, str) or not access_token.strip():
        return None

    merged_config = dict(config)
    merged_config.update(secret_bundle)
    return CredentialStore.model_validate(merged_config)


def save_credentials(credentials: CredentialStore) -> Path:
    config = load_config()
    config.update(
        {
            "base_url": credentials.base_url,
            "client_id": credentials.client_id,
            "expires_at": credentials.expires_at,
            "token_endpoint_auth_method": credentials.token_endpoint_auth_method,
            "token_type": credentials.token_type,
        }
    )
    for key in ("access_token", "refresh_token", "client_secret"):
        config.pop(key, None)

    save_secret_bundle(
        {
            "access_token": credentials.access_token,
            "refresh_token": credentials.refresh_token,
            "client_secret": credentials.client_secret,
        },
        base_url=credentials.base_url,
        client_id=credentials.client_id,
    )
    return save_config(config)


def clear_credentials(*, keep_base_url: bool = True) -> Path:
    config = load_config()
    base_url = _resolve_base_url_from_config(config)
    client_id = _resolve_client_id_from_config(config)
    clear_secret_bundle(base_url=base_url, client_id=client_id)
    retained: dict[str, Any] = {}
    if keep_base_url:
        if isinstance(base_url, str) and base_url.strip():
            retained["base_url"] = base_url.strip()

    return save_config(retained)


def resolve_base_url(base_url: str | None = None) -> str:
    if base_url and base_url.strip():
        return base_url.strip()

    env_base_url = os.getenv("CTXD_BASE_URL")
    if env_base_url and env_base_url.strip():
        return env_base_url.strip()

    config_base_url = load_config().get("base_url")
    if isinstance(config_base_url, str) and config_base_url.strip():
        return config_base_url.strip()

    return DEFAULT_BASE_URL


def resolve_client_id(client_id: str | None = None) -> str:
    resolved = _resolve_optional_client_id(client_id)
    if resolved is None:
        raise ValueError("Missing OAuth client_id.")
    return resolved


def _resolve_optional_client_id(client_id: str | None = None) -> str | None:
    if client_id and client_id.strip():
        return client_id.strip()

    config_client_id = load_config().get("client_id")
    if isinstance(config_client_id, str) and config_client_id.strip():
        return config_client_id.strip()

    return None


def _resolve_base_url_from_config(config: dict[str, Any]) -> str:
    config_base_url = config.get("base_url")
    if isinstance(config_base_url, str) and config_base_url.strip():
        return config_base_url.strip()
    return DEFAULT_BASE_URL


def _resolve_client_id_from_config(config: dict[str, Any]) -> str | None:
    config_client_id = config.get("client_id")
    if isinstance(config_client_id, str) and config_client_id.strip():
        return config_client_id.strip()
    return None
