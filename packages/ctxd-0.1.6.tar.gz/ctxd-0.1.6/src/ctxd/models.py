from typing import Any

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class SearchItem(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str = Field(validation_alias=AliasChoices("id", "document_uid"))
    title: str
    url: str
    text: str = Field(
        default="",
        validation_alias=AliasChoices("text", "snippet"),
    )
    metadata: dict[str, Any] = Field(default_factory=dict)


class SearchResult(BaseModel):
    model_config = ConfigDict(extra="allow")

    results: list[SearchItem] = Field(default_factory=list)
    error: str | None = None
    dsl_parse_error: str | None = None


class DocumentResult(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str | None = None
    title: str | None = None
    text: str | None = None
    url: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None


class ProfileResult(BaseModel):
    model_config = ConfigDict(extra="allow")

    integration_access: str
    file_tree: str


class CredentialStore(BaseModel):
    model_config = ConfigDict(extra="ignore")

    access_token: str
    refresh_token: str | None = None
    token_type: str = "Bearer"
    expires_at: int | None = None
    base_url: str
    client_id: str | None = None
    client_secret: str | None = None
    token_endpoint_auth_method: str | None = None


class ResourceMetadata(BaseModel):
    model_config = ConfigDict(extra="allow")

    authorization_servers: list[str]
    bearer_methods_supported: list[str] = Field(default_factory=list)
    resource: str


class AuthorizationServerMetadata(BaseModel):
    model_config = ConfigDict(extra="allow")

    authorization_endpoint: str
    token_endpoint: str
    registration_endpoint: str | None = None


class AuthorizationCodeGrant(BaseModel):
    authorization_endpoint: str
    token_endpoint: str
    resource: str
    client_id: str
    client_secret: str | None = None
    token_endpoint_auth_method: str | None = None
    state: str
    code_verifier: str
    redirect_uri: str
    authorization_url: str


class OAuthTokenResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    access_token: str
    token_type: str = "Bearer"
    expires_in: int | None = None
    refresh_token: str | None = None


class DynamicClientRegistrationResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    client_id: str
    client_secret: str
    redirect_uris: list[str] = Field(default_factory=list)
    token_endpoint_auth_method: str | None = None


class DeviceLoginStartResponse(BaseModel):
    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    expires_at: int
    interval_seconds: int


class DeviceLoginPollResponse(BaseModel):
    status: str
    error: str | None = None
    access_token: str | None = None
    refresh_token: str | None = None
    token_type: str | None = None
    expires_at: int | None = None
    base_url: str | None = None
    client_id: str | None = None
    client_secret: str | None = None
    token_endpoint_auth_method: str | None = None
