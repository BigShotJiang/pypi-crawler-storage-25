(() => {
  "use strict";

  // ── State ──────────────────────────────────
  let ws = null;
  let activeSessionId = null;
  let sessions = [];              // [{id, title, ...}]
  let messageCache = {};          // sessionId -> [msg]
  let ctxTargetId = null;
  let pendingImages = [];           // [{url, file}] waiting to send
  let draftCache = {};              // sessionId -> unsent input text
  let unreadSet = new Set();        // sessions with unread messages
  let countdownTimers = {};         // sessionId -> {startedAt, intervalId}

  const $ = (sel) => document.querySelector(sel);
  const $messages   = $("#messages");
  const $input      = $("#msg-input");
  const $btnSend    = $("#btn-send");
  const $sessionList = $("#session-list");
  const $chatTitle  = $("#chat-title");
  const $ctxMenu    = $("#ctx-menu");
  const $previewBar = $("#preview-bar");
  const $fileInput  = $("#file-input");
  const $btnCopy    = $("#btn-copy-activate");

  $btnCopy?.addEventListener("click", () => {
    const text = document.querySelector(".activate-text")?.textContent || "";
    navigator.clipboard.writeText(text).then(() => {
      $btnCopy.textContent = "✅";
      setTimeout(() => { $btnCopy.textContent = "📋"; }, 1500);
    });
  });

  // ── Markdown Setup ─────────────────────────
  const renderer = new marked.Renderer();
  const origCode = renderer.code.bind(renderer);
  renderer.code = function (text) {
    const html = origCode(text);
    return `<div class="code-wrap">${html}<button class="code-copy" onclick="this.parentElement.querySelector('code')&&navigator.clipboard.writeText(this.parentElement.querySelector('code').textContent).then(()=>{this.textContent='✓';setTimeout(()=>this.textContent='复制',1200)})">复制</button></div>`;
  };
  marked.setOptions({ breaks: true, renderer });

  // ── WebSocket ──────────────────────────────
  let reconnectDelay = 1000;

  function connect() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${proto}//${location.host}/ws`);

    ws.onopen = () => {
      console.log("[ws] connected");
      reconnectDelay = 1000;
      ws.send(JSON.stringify({ type: "list_sessions" }));
      if (activeSessionId) {
        ws.send(JSON.stringify({ type: "get_session", session_id: activeSessionId }));
      }
    };

    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);
      handleMessage(data);
    };

    ws.onclose = () => {
      console.log(`[ws] disconnected, reconnecting in ${reconnectDelay}ms…`);
      setTimeout(connect, reconnectDelay);
      reconnectDelay = Math.min(reconnectDelay * 2, 30000);
    };
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN)
      ws.send(JSON.stringify(obj));
  }

  // ── Message Router ─────────────────────────
  function handleMessage(data) {
    switch (data.type) {
      case "session_list":
        sessions = data.sessions;
        renderSidebar();
        break;

      case "session_detail":
        messageCache[data.session.id] = data.session.messages;
        if (data.session.id === activeSessionId) renderMessages();
        break;

      case "session_created": {
        if (!sessions.find((s) => s.id === data.session.id)) {
          sessions.unshift(data.session);
          renderSidebar();
        }
        const createdEl = $sessionList.querySelector(`[data-id="${data.session.id}"]`);
        if (createdEl) createdEl.classList.add("session-flash");
        if (!activeSessionId) selectSession(data.session.id);
        break;
      }

      case "user_message":
      case "assistant_message": {
        const sid = data.session_id;
        if (!messageCache[sid]) messageCache[sid] = [];
        messageCache[sid].push(data.message);
        if (sid === activeSessionId) {
          if (data.type === "assistant_message") removeTypingIndicator();
          appendBubble(data.message);
          if (data.type === "user_message") showTypingIndicator();
          scrollToBottom();
        } else {
          markUnread(sid);
        }
        updateSidebarPreview(sid, data.message);
        if (data.type === "assistant_message") {
          stopCountdown(sid);
          notifyNewMessage(data.message.content);
        }
        break;
      }

      case "session_waiting":
        startCountdown(data.session_id);
        if (data.session_id !== activeSessionId) {
          markUnread(data.session_id);
        }
        break;

      case "session_disconnected":
        stopCountdown(data.session_id);
        break;

      case "session_renamed":
        updateSessionTitle(data.session_id, data.title);
        break;

      case "message_deleted": {
        const sid2 = data.session_id;
        const mid = data.message_id;
        if (messageCache[sid2]) {
          messageCache[sid2] = messageCache[sid2].filter((m) => m.id !== mid);
        }
        if (sid2 === activeSessionId) {
          const el = $messages.querySelector(`[data-msg-id="${mid}"]`);
          if (el) el.remove();
          if ((messageCache[sid2] || []).length === 0) {
            $messages.innerHTML = '<div class="empty-state">发送第一条消息开始聊天</div>';
          }
        }
        updateSidebarPreview(sid2, (messageCache[sid2] || []).at(-1) || { content: "暂无消息" });
        break;
      }

      case "session_deleted":
        sessions = sessions.filter((s) => s.id !== data.session_id);
        delete messageCache[data.session_id];
        delete draftCache[data.session_id];
        renderSidebar();
        if (activeSessionId === data.session_id) {
          activeSessionId = null;
          $chatTitle.textContent = "选择或新建一个会话";
          $messages.innerHTML = '<div class="empty-state">暂无会话</div>';
        }
        break;
    }
  }

  // ── Sidebar ────────────────────────────────
  function renderSidebar() {
    $sessionList.innerHTML = "";
    if (sessions.length === 0) {
      $sessionList.innerHTML = '<div class="empty-state" style="padding:40px 0;font-size:13px">暂无会话</div>';
      return;
    }
    sessions.forEach((s) => {
      const el = document.createElement("div");
      el.className = "session-item"
        + (s.id === activeSessionId ? " active" : "")
        + (unreadSet.has(s.id) ? " session-unread" : "");
      el.dataset.id = s.id;

      const preview = s.last_message
        ? truncate(s.last_message.content, 30)
        : "暂无消息";

      el.innerHTML = `
        <div class="s-title">${esc(s.title || s.id)}</div>
        <div class="s-preview">${esc(preview)}</div>
        <div class="s-countdown-bar" data-bar="${s.id}" style="width:0"></div>
        <button class="s-del" title="删除会话">×</button>`;

      el.addEventListener("click", (e) => {
        if (e.target.closest(".s-del")) return;
        selectSession(s.id);
      });
      el.addEventListener("dblclick", (e) => {
        e.stopPropagation();
        startInlineRename(el, s.id);
      });
      el.addEventListener("contextmenu", (e) => showCtxMenu(e, s.id));
      $sessionList.appendChild(el);
    });
  }

  $sessionList.addEventListener("click", (e) => {
    const btn = e.target.closest(".s-del");
    if (!btn) return;
    const item = btn.closest(".session-item");
    const sid = item?.dataset.id;
    if (sid) {
      send({ type: "delete_session", session_id: sid });
    }
  });

  function selectSession(sid) {
    if (activeSessionId && activeSessionId !== sid) {
      draftCache[activeSessionId] = $input.value;
    }

    activeSessionId = sid;
    const s = sessions.find((x) => x.id === sid);
    $chatTitle.textContent = s ? s.title || sid : sid;

    $input.value = draftCache[sid] || "";
    autoResize();

    document.querySelectorAll(".session-item").forEach((el) => {
      el.classList.toggle("active", el.dataset.id === sid);
      if (el.dataset.id === sid) el.classList.remove("session-flash");
    });
    clearUnread(sid);

    if (messageCache[sid]) {
      renderMessages();
    } else {
      send({ type: "get_session", session_id: sid });
    }
    $input.focus();
  }

  function markUnread(sid) {
    unreadSet.add(sid);
    const el = $sessionList.querySelector(`[data-id="${sid}"]`);
    if (el) {
      el.classList.add("session-unread", "session-flash");
    }
  }

  const KEEPALIVE_SECONDS = 480;

  function startCountdown(sid) {
    stopCountdown(sid);
    const bar = $sessionList.querySelector(`[data-bar="${sid}"]`);
    if (bar) {
      bar.style.transition = "none";
      bar.style.width = "100%";
      bar.offsetHeight;
      bar.style.transition = `width ${KEEPALIVE_SECONDS}s linear`;
      bar.style.width = "0";
    }
    const startedAt = Date.now();
    const intervalId = setTimeout(() => {
      delete countdownTimers[sid];
    }, KEEPALIVE_SECONDS * 1000);
    countdownTimers[sid] = { startedAt, intervalId };
  }

  function stopCountdown(sid) {
    const timer = countdownTimers[sid];
    if (timer) {
      clearTimeout(timer.intervalId);
      delete countdownTimers[sid];
    }
    const bar = $sessionList.querySelector(`[data-bar="${sid}"]`);
    if (bar) {
      bar.style.transition = "none";
      bar.style.width = "0";
    }
  }

  function clearUnread(sid) {
    unreadSet.delete(sid);
    const el = $sessionList.querySelector(`[data-id="${sid}"]`);
    if (el) el.classList.remove("session-unread", "session-flash");
  }

  function updateSidebarPreview(sid, msg) {
    const s = sessions.find((x) => x.id === sid);
    if (s) s.last_message = msg;
    const el = $sessionList.querySelector(`[data-id="${sid}"] .s-preview`);
    if (el) el.textContent = truncate(msg.content, 30);
  }

  function updateSessionTitle(sid, title) {
    const s = sessions.find((x) => x.id === sid);
    if (s) s.title = title;
    const el = $sessionList.querySelector(`[data-id="${sid}"] .s-title`);
    if (el) el.textContent = title;
    if (sid === activeSessionId) $chatTitle.textContent = title;
  }

  // ── Messages ───────────────────────────────
  function renderMessages() {
    $messages.innerHTML = "";
    const msgs = messageCache[activeSessionId] || [];
    if (msgs.length === 0) {
      $messages.innerHTML = '<div class="empty-state">发送第一条消息开始聊天</div>';
      return;
    }
    msgs.forEach((m) => appendBubble(m));
    const lastMsg = msgs[msgs.length - 1];
    if (lastMsg && lastMsg.role === "user") showTypingIndicator();
    scrollToBottom();
  }

  function appendBubble(msg) {
    const empty = $messages.querySelector(".empty-state");
    if (empty) empty.remove();

    const div = document.createElement("div");
    div.className = `msg ${msg.role}`;
    div.dataset.msgId = msg.id;

    const avatarText = msg.role === "user" ? "你" : "AI";
    let rendered = msg.role === "assistant"
      ? marked.parse(msg.content)
      : esc(msg.content);

    const imgs = (msg.images || [])
      .map((u) => `<img class="msg-img" src="${esc(u)}" onclick="window.open('${esc(u)}')">`)
      .join("");

    const time = formatTime(msg.timestamp);

    div.innerHTML = `
      <div class="avatar">${avatarText}</div>
      <div class="bubble">${rendered}${imgs}</div>
      <span class="msg-time">${time}</span>
      <button class="msg-del" title="删除">×</button>`;

    $messages.appendChild(div);
  }

  function scrollToBottom() {
    requestAnimationFrame(() => {
      $messages.scrollTop = $messages.scrollHeight;
    });
  }

  function showTypingIndicator() {
    removeTypingIndicator();
    const div = document.createElement("div");
    div.className = "typing-indicator";
    div.id = "typing-indicator";
    div.innerHTML = `
      <div class="avatar">AI</div>
      <div class="bubble">
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
      </div>`;
    $messages.appendChild(div);
    scrollToBottom();
  }

  function removeTypingIndicator() {
    const el = document.getElementById("typing-indicator");
    if (el) el.remove();
  }

  // ── Delete Message (event delegation) ───
  $messages.addEventListener("click", (e) => {
    const btn = e.target.closest(".msg-del");
    if (!btn) return;
    const msgEl = btn.closest(".msg");
    const msgId = msgEl?.dataset.msgId;
    if (msgId && activeSessionId) {
      send({ type: "delete_message", session_id: activeSessionId, message_id: msgId });
    }
  });

  // ── Image Upload ────────────────────────────
  async function uploadFile(file) {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.ok) return data.url;
    throw new Error(data.message);
  }

  function addPendingImage(file) {
    const url = URL.createObjectURL(file);
    pendingImages.push({ url, file });
    renderPreviews();
  }

  function removePendingImage(idx) {
    URL.revokeObjectURL(pendingImages[idx].url);
    pendingImages.splice(idx, 1);
    renderPreviews();
  }

  function renderPreviews() {
    if (pendingImages.length === 0) {
      $previewBar.classList.add("hidden");
      $previewBar.innerHTML = "";
      return;
    }
    $previewBar.classList.remove("hidden");
    $previewBar.innerHTML = pendingImages
      .map((p, i) => `<div class="preview-item">
        <img src="${p.url}">
        <button class="remove-btn" data-idx="${i}">✕</button>
      </div>`)
      .join("");
    $previewBar.querySelectorAll(".remove-btn").forEach((btn) =>
      btn.addEventListener("click", () => removePendingImage(+btn.dataset.idx))
    );
  }

  $fileInput.addEventListener("change", () => {
    for (const f of $fileInput.files) addPendingImage(f);
    $fileInput.value = "";
  });

  $input.addEventListener("paste", (e) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith("image/")) {
        e.preventDefault();
        addPendingImage(item.getAsFile());
      }
    }
  });

  // ── Send ───────────────────────────────────
  async function sendUserMessage() {
    const text = $input.value.trim();
    if ((!text && pendingImages.length === 0) || !activeSessionId) return;

    let imageUrls = [];
    if (pendingImages.length > 0) {
      try {
        imageUrls = await Promise.all(pendingImages.map((p) => uploadFile(p.file)));
      } catch (err) {
        alert("图片上传失败：" + err.message);
        return;
      }
      pendingImages.forEach((p) => URL.revokeObjectURL(p.url));
      pendingImages = [];
      renderPreviews();
    }

    send({
      type: "send_message",
      session_id: activeSessionId,
      content: text,
      images: imageUrls,
    });
    $input.value = "";
    delete draftCache[activeSessionId];
    autoResize();
  }

  $("#btn-clear").addEventListener("click", () => {
    $input.value = "";
    if (activeSessionId) delete draftCache[activeSessionId];
    autoResize();
    $input.focus();
  });

  $btnSend.addEventListener("click", sendUserMessage);
  $input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      if (e.shiftKey) return;
      if (e.ctrlKey) {
        e.preventDefault();
        const start = $input.selectionStart;
        const end = $input.selectionEnd;
        $input.value = $input.value.substring(0, start) + "\n" + $input.value.substring(end);
        $input.selectionStart = $input.selectionEnd = start + 1;
        autoResize();
        return;
      }
      e.preventDefault();
      sendUserMessage();
    }
  });

  // auto-resize textarea
  function autoResize() {
    $input.style.height = "auto";
    $input.style.height = Math.min($input.scrollHeight, 120) + "px";
  }
  $input.addEventListener("input", autoResize);

  // ── Install to Cursor ──────────────────────
  $("#btn-install").addEventListener("click", async () => {
    const port = location.port || "8765";
    try {
      const res = await fetch(`/api/install?port=${port}`, { method: "POST" });
      const data = await res.json();
      alert(data.ok ? "✓ 已自动写入 ~/.cursor/mcp.json" : "✗ " + data.message);
    } catch (e) {
      alert("写入失败：" + e.message);
    }
  });

  // ── Open Cursor ───────────────────────────
  $("#btn-open-cursor").addEventListener("click", async () => {
    try {
      const res = await fetch("/api/open-cursor", { method: "POST" });
      const data = await res.json();
      if (!data.ok) alert("✗ " + data.message);
    } catch (e) {
      alert("启动失败：" + e.message);
    }
  });

  // ── Inline Rename ─────────────────────────
  function startInlineRename(el, sid) {
    const titleEl = el.querySelector(".s-title");
    if (!titleEl) return;
    const oldTitle = titleEl.textContent;

    const input = document.createElement("input");
    input.type = "text";
    input.value = oldTitle;
    input.className = "rename-input";
    titleEl.replaceWith(input);
    input.focus();
    input.select();

    let committed = false;
    function finish() {
      if (committed) return;
      committed = true;
      const newTitle = input.value.trim() || oldTitle;
      const span = document.createElement("div");
      span.className = "s-title";
      span.textContent = newTitle;
      input.replaceWith(span);
      if (newTitle !== oldTitle) {
        send({ type: "rename_session", session_id: sid, title: newTitle });
      }
    }

    input.addEventListener("blur", finish);
    input.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") { ev.preventDefault(); input.blur(); }
      if (ev.key === "Escape") { input.value = oldTitle; input.blur(); }
    });
  }

  // ── Context Menu ───────────────────────────
  function showCtxMenu(e, sid) {
    e.preventDefault();
    ctxTargetId = sid;
    $ctxMenu.style.left = e.clientX + "px";
    $ctxMenu.style.top = e.clientY + "px";
    $ctxMenu.classList.remove("hidden");
  }

  document.addEventListener("click", () => $ctxMenu.classList.add("hidden"));

  $ctxMenu.querySelectorAll(".ctx-item").forEach((el) => {
    el.addEventListener("click", () => {
      const action = el.dataset.action;
      if (!ctxTargetId) return;

      if (action === "rename") {
        const title = prompt("新标题：");
        if (title) send({ type: "rename_session", session_id: ctxTargetId, title });
      } else if (action === "delete") {
        if (confirm("确定删除此会话？"))
          send({ type: "delete_session", session_id: ctxTargetId });
      }
      ctxTargetId = null;
    });
  });

  // ── Notifications ──────────────────────────
  let notifGranted = false;
  if ("Notification" in window) {
    Notification.requestPermission().then((p) => { notifGranted = p === "granted"; });
  }

  let titleTimer = null;
  const origTitle = document.title;

  function notifyNewMessage(text) {
    const preview = truncate(text || "新消息", 50);

    if (notifGranted && document.hidden) {
      new Notification("丸子 MCP", { body: preview, icon: "" });
    }

    if (document.hidden) {
      clearInterval(titleTimer);
      let flash = true;
      titleTimer = setInterval(() => {
        document.title = flash ? `💬 ${preview}` : origTitle;
        flash = !flash;
      }, 800);
    }

    if (window.pywebview && window.pywebview.api) {
      window.pywebview.api.flash_taskbar();
    }
  }

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && titleTimer) {
      clearInterval(titleTimer);
      titleTimer = null;
      document.title = origTitle;
    }
  });

  // ── Helpers ────────────────────────────────
  function esc(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function truncate(s, n) {
    return s.length > n ? s.slice(0, n) + "…" : s;
  }

  function formatTime(iso) {
    try {
      const d = new Date(iso);
      return d.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
    } catch {
      return "";
    }
  }

  // ── Status Polling ─────────────────────────
  const $statusDot  = $("#status-dot");
  const $statusText = $("#status-text");

  async function pollStatus() {
    try {
      const res = await fetch("/api/status");
      const data = await res.json();
      $statusDot.className = "dot online";
      $statusText.textContent = data.sessions > 0 ? `${data.sessions} 个会话` : "服务运行中";
    } catch {
      $statusDot.className = "dot offline";
      $statusText.textContent = "服务已断开";
    }
  }

  setInterval(pollStatus, 3000);
  pollStatus();

  // ── Theme Toggle ──────────────────────────
  const $btnTheme = $("#btn-theme");
  function applyTheme(dark) {
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
    $btnTheme.textContent = dark ? "☀️" : "🌙";
    $btnTheme.title = dark ? "切换到浅色模式" : "切换到深色模式";
    localStorage.setItem("wanzi-theme", dark ? "dark" : "light");
  }
  const savedTheme = localStorage.getItem("wanzi-theme");
  const prefersDark = savedTheme === "dark" || (!savedTheme && window.matchMedia("(prefers-color-scheme: dark)").matches);
  applyTheme(prefersDark);
  $btnTheme.addEventListener("click", () => {
    const isDark = document.documentElement.getAttribute("data-theme") === "dark";
    applyTheme(!isDark);
  });

  // ── Boot ───────────────────────────────────
  connect();
})();
