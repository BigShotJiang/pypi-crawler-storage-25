"""Windows 任务栏：消息到达时闪烁 + 全局热键切换窗口。"""

from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import os
import sys
import threading

_user32 = ctypes.windll.user32 if sys.platform == "win32" else None

WM_HOTKEY = 0x0312
FLASHW_ALL = 0x03
FLASHW_TIMERNOFG = 0x0C

MOD_CONTROL = 0x0002
MOD_ALT = 0x0001
MOD_NOREPEAT = 0x4000
VK_E = 0x45
SW_HIDE = 0
SW_MINIMIZE = 6
SW_SHOW = 5
SW_RESTORE = 9

_HOTKEY_ID = 0x7701


class _FLASHWINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wt.UINT),
        ("hwnd", wt.HWND),
        ("dwFlags", wt.DWORD),
        ("uCount", wt.UINT),
        ("dwTimeout", wt.DWORD),
    ]


def _window_text(hwnd: int) -> str:
    length = _user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(length + 1)
    _user32.GetWindowTextW(hwnd, buf, length + 1)
    return buf.value


def _window_class(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(256)
    _user32.GetClassNameW(hwnd, buf, len(buf))
    return buf.value


def _find_hwnd_by_pid() -> int:
    if _user32 is None:
        return 0

    my_pid = os.getpid()
    candidates: list[tuple[int, str, str]] = []

    enum_proc = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)

    def _collect(hwnd, _lparam):
        pid = wt.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value != my_pid or not _user32.IsWindowVisible(hwnd):
            return True
        cls = _window_class(hwnd)
        title = _window_text(hwnd)
        candidates.append((int(hwnd), cls, title))
        return True

    _user32.EnumWindows(enum_proc(_collect), 0)

    for hwnd, cls, title in candidates:
        if cls.startswith("WindowsForms10.") and "MCP" in title:
            return hwnd
    for hwnd, cls, _title in candidates:
        if cls != "ConsoleWindowClass":
            return hwnd
    return 0


def _find_hwnd(title: str) -> int:
    if _user32 is None:
        return 0
    hwnd = _user32.FindWindowW(None, title)
    if hwnd:
        return hwnd
    return _find_hwnd_by_pid()


def flash(title: str = "丸子 MCP", count: int = 5):
    if _user32 is None:
        return
    hwnd = _find_hwnd(title)
    if not hwnd:
        return
    info = _FLASHWINFO()
    info.cbSize = ctypes.sizeof(_FLASHWINFO)
    info.hwnd = hwnd
    info.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG
    info.uCount = count
    info.dwTimeout = 0
    _user32.FlashWindowEx(ctypes.byref(info))


def _toggle_window(title: str):
    """切换窗口：前台时最小化，最小化/后台时恢复到最前。"""
    if _user32 is None:
        return
    hwnd = _find_hwnd(title)
    if not hwnd:
        return

    fg = _user32.GetForegroundWindow()
    visible = _user32.IsWindowVisible(hwnd)

    if visible and fg == hwnd:
        _user32.ShowWindow(hwnd, SW_MINIMIZE)
    else:
        fg_tid = _user32.GetWindowThreadProcessId(fg, None) if fg else 0
        cur_tid = ctypes.windll.kernel32.GetCurrentThreadId()
        attached = False
        if fg_tid and fg_tid != cur_tid:
            attached = bool(_user32.AttachThreadInput(cur_tid, fg_tid, True))
        _user32.ShowWindow(hwnd, SW_RESTORE)
        _user32.SetForegroundWindow(hwnd)
        if attached:
            _user32.AttachThreadInput(cur_tid, fg_tid, False)


def start_hotkey_listener(title: str = "丸子 MCP"):
    """后台线程注册 Ctrl+Alt+E 全局热键，按下时切换窗口。"""
    if _user32 is None:
        return

    def _loop():
        ok = _user32.RegisterHotKey(None, _HOTKEY_ID,
                                    MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, VK_E)
        if not ok:
            import logging
            logging.getLogger(__name__).warning(
                "Ctrl+Alt+E 热键注册失败，可能已被其他程序占用")
            return
        msg = wt.MSG()
        try:
            while _user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == WM_HOTKEY and msg.wParam == _HOTKEY_ID:
                    _toggle_window(title)
        finally:
            _user32.UnregisterHotKey(None, _HOTKEY_ID)

    t = threading.Thread(target=_loop, daemon=True)
    t.start()
