"""CLI 入口：wanzi / wanzi serve / wanzi gui / wanzi install"""

from __future__ import annotations

import asyncio
import threading
import time

import click


@click.group(invoke_without_command=True)
@click.option("--port", default=8765, help="服务端口", show_default=True)
@click.option("--stdio", is_flag=True, default=False, help="以 stdio 模式启动 MCP（由 Cursor 调用）")
@click.pass_context
def cli(ctx, port: int, stdio: bool):
    """丸子 MCP — Cursor AI 聊天桥接工具"""
    ctx.ensure_object(dict)
    ctx.obj["port"] = port
    if stdio:
        _start_stdio(port)
    elif ctx.invoked_subcommand is None:
        _start_all(port)


@cli.command()
@click.pass_context
def serve(ctx):
    """只启动后端服务"""
    _start_server(ctx.obj["port"])


@cli.command()
@click.pass_context
def gui(ctx):
    """只启动 GUI 窗口（需后端已运行）"""
    from .gui.app import start_gui

    start_gui(ctx.obj["port"])


@cli.command()
@click.pass_context
def install(ctx):
    """写入 ~/.cursor/mcp.json 注册 MCP"""
    from .installer import install_to_cursor

    install_to_cursor(ctx.obj["port"])


def _free_port(port: int):
    from .server_ctl import kill_port_occupants

    killed = kill_port_occupants(port)
    if killed:
        click.echo(f"已释放端口 {port}（终止 PID: {killed}）")
        time.sleep(0.5)


def _start_server(port: int):
    import uvicorn
    from .server import app

    _free_port(port)
    click.echo(f"丸子 MCP 后端启动: http://localhost:{port}")
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")


def _run_uvicorn(port: int):
    import uvicorn
    from .server import app

    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")


def _start_all(port: int):
    _free_port(port)
    click.echo(f"丸子 MCP 后端启动: http://localhost:{port}")
    t = threading.Thread(target=_run_uvicorn, args=(port,), daemon=True)
    t.start()
    time.sleep(1)

    from .gui.app import start_gui

    click.echo("正在打开 GUI 窗口…")
    start_gui(port)


def _start_stdio(port: int):
    """stdio 模式：作为轻量代理，通过 HTTP 调已运行的主服务器。"""
    import sys, logging
    logging.basicConfig(stream=sys.stderr, level=logging.INFO)

    from .stdio_proxy import run_stdio_proxy
    asyncio.run(run_stdio_proxy(port))


if __name__ == "__main__":
    cli()
