from __future__ import annotations

from pathlib import Path
from typing import Any

from loguru import logger as lg
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator


def read_tb_scalars(
	log_dir: str | Path,
	tags: list[str] | None = None,
) -> dict[str, list[dict[str, Any]]]:
	"""Read scalar events from a TensorBoard log directory.

	Args:
		log_dir: Path to the directory containing tfevents files.
		tags: If given, only read these scalar tags. Otherwise read all.

	Returns:
		Mapping ``{tag: [{wall_time, step, value}, ...]}``.
	"""
	log_dir = Path(log_dir)
	ea = EventAccumulator(str(log_dir))
	ea.Reload()

	available = ea.Tags().get("scalars", [])
	if tags is None:
		tags = available
	else:
		missing = set(tags) - set(available)
		if missing:
			lg.warning("tags not found in {}: {}", log_dir, missing)
		tags = [t for t in tags if t in available]

	result: dict[str, list[dict[str, Any]]] = {}
	for tag in tags:
		events = ea.Scalars(tag)
		result[tag] = [
			{"wall_time": e.wall_time, "step": e.step, "value": e.value}
			for e in events
		]
	lg.debug("read {} tags ({} total events) from {}", len(result), sum(len(v) for v in result.values()), log_dir)
	return result


def tb_scalars_to_xy(events: list[dict[str, Any]]) -> tuple[list[int], list[float]]:
	"""Extract (steps, values) lists from events returned by ``read_tb_scalars``."""
	steps = [e["step"] for e in events]
	values = [e["value"] for e in events]
	return steps, values
