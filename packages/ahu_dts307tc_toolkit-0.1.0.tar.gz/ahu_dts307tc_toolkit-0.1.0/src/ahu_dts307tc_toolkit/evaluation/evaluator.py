from __future__ import annotations

from typing import Any, Callable

import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
from loguru import logger as lg


def evaluate_discrete_policy(
	env: gym.Env,
	policy_fn: Callable[[torch.Tensor], torch.Tensor],
	device: torch.device,
	*,
	num_episodes: int = 10,
	deterministic: bool = True,
	max_steps: int | None = None,
) -> dict[str, float]:
	"""Run a discrete policy for ``num_episodes`` and return stats.

	Args:
		env: Gymnasium environment (already wrapped).
		policy_fn: Maps batched obs tensor -> logits tensor.
		device: Torch device.
		num_episodes: How many episodes to evaluate.
		deterministic: Argmax if True, sample if False.
		max_steps: Optional per-episode step limit.
	"""
	returns: list[float] = []
	lengths: list[int] = []
	for ep in range(num_episodes):
		obs, _ = env.reset()
		ep_ret = 0.0
		ep_len = 0
		terminated = truncated = False
		while not (terminated or truncated):
			o = torch.as_tensor(np.asarray(obs), device=device, dtype=torch.float32)
			if o.ndim == 3:
				o = o.unsqueeze(0)
			with torch.no_grad():
				out = policy_fn(o)
				if isinstance(out, torch.Tensor) and out.ndim == 2:
					if deterministic:
						action = int(out.argmax(dim=-1).item())
					else:
						probs = torch.softmax(out, dim=-1)
						action = int(torch.multinomial(probs, 1).item())
				else:
					action = int(out.item())
			obs, reward, terminated, truncated, _ = env.step(action)
			ep_ret += float(reward)
			ep_len += 1
			if max_steps is not None and ep_len >= max_steps:
				truncated = True
		returns.append(ep_ret)
		lengths.append(ep_len)
		lg.debug("eval ep {}/{}: return={:.1f}  len={}", ep + 1, num_episodes, ep_ret, ep_len)
	result = {
		"mean_return": float(np.mean(returns)),
		"std_return": float(np.std(returns)),
		"mean_length": float(np.mean(lengths)),
	}
	lg.info("eval done: mean_return={:.2f} ± {:.2f}", result["mean_return"], result["std_return"])
	return result


def load_state_dict(model: nn.Module, state: dict[str, Any], *, key: str = "model_state_dict") -> None:
	model.load_state_dict(state[key])
