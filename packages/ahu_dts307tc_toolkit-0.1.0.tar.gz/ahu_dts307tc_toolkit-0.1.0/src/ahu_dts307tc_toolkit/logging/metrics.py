from __future__ import annotations

from typing import Mapping

from ahu_dts307tc_toolkit.logging.tb_logger import TensorBoardLogger


def log_train_step(
	logger: TensorBoardLogger,
	*,
	step: int,
	rollout_mean_reward: float,
	policy_loss: float,
	value_loss: float,
	entropy: float,
	approx_kl: float,
	clipfrac: float,
	explained_variance: float,
	learning_rate: float,
) -> None:
	logger.add_scalar("rollout/mean_reward", rollout_mean_reward, step)
	logger.add_scalar("train/policy_loss", policy_loss, step)
	logger.add_scalar("train/value_loss", value_loss, step)
	logger.add_scalar("train/entropy", entropy, step)
	logger.add_scalar("train/approx_kl", approx_kl, step)
	logger.add_scalar("train/clipfrac", clipfrac, step)
	logger.add_scalar("train/explained_variance", explained_variance, step)
	logger.add_scalar("train/learning_rate", learning_rate, step)


def log_eval(
	logger: TensorBoardLogger,
	*,
	step: int,
	mean_return: float,
	std_return: float,
	mean_length: float,
) -> None:
	logger.add_scalar("eval/mean_return", mean_return, step)
	logger.add_scalar("eval/std_return", std_return, step)
	logger.add_scalar("eval/mean_length", mean_length, step)


def log_episode_stats(logger: TensorBoardLogger, *, step: int, episode_return: float, episode_len: float) -> None:
	logger.add_scalar("episode/return", episode_return, step)
	logger.add_scalar("episode/length", episode_len, step)


def log_dict(logger: TensorBoardLogger, prefix: str, values: Mapping[str, float], step: int) -> None:
	for k, v in values.items():
		logger.add_scalar(f"{prefix}/{k}", float(v), step)
