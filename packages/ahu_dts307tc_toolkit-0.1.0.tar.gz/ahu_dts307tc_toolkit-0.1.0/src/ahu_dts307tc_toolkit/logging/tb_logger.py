from __future__ import annotations

from pathlib import Path
from typing import Any

from loguru import logger as lg
from torch.utils.tensorboard import SummaryWriter


class TensorBoardLogger:
	def __init__(self, log_dir: str | Path) -> None:
		self.log_dir = Path(log_dir)
		self.log_dir.mkdir(parents=True, exist_ok=True)
		self._writer = SummaryWriter(str(self.log_dir))
		lg.info("TensorBoard logging to {}", self.log_dir)

	def add_scalar(self, tag: str, value: float, step: int) -> None:
		self._writer.add_scalar(tag, value, step)

	def add_scalars(self, main_tag: str, tag_scalar_dict: dict[str, float], step: int) -> None:
		self._writer.add_scalars(main_tag, tag_scalar_dict, step)

	def flush(self) -> None:
		self._writer.flush()

	def close(self) -> None:
		self._writer.close()
		lg.info("TensorBoard logger closed")

	def log_hparams(self, hparams: dict[str, Any], metrics: dict[str, float]) -> None:
		self._writer.add_hparams(hparams, metrics)
