"""Reusable visualization helpers."""

