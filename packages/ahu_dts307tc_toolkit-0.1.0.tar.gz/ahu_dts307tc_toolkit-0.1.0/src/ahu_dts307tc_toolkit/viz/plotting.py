from __future__ import annotations

from math import ceil
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from loguru import logger as lg

from ahu_dts307tc_toolkit.evaluation.tb_reader import read_tb_scalars, tb_scalars_to_xy

sns.set_theme(
	style="ticks",
	context="paper",
	font_scale=1.15,
	rc={
		"axes.spines.top": False,
		"axes.spines.right": False,
		"axes.facecolor": "#FCFCFC",
		"figure.facecolor": "#FFFFFF",
		"grid.color": "#D7DCE2",
		"grid.alpha": 0.55,
		"grid.linewidth": 0.8,
		"axes.edgecolor": "#3E4A59",
		"axes.labelcolor": "#243142",
		"text.color": "#243142",
		"xtick.color": "#506070",
		"ytick.color": "#506070",
		"legend.frameon": True,
		"legend.framealpha": 0.92,
		"legend.edgecolor": "#D7DCE2",
	},
)
mpl.rcParams["axes.titleweight"] = "semibold"
mpl.rcParams["axes.titlesize"] = 13
mpl.rcParams["axes.labelsize"] = 11
mpl.rcParams["legend.fontsize"] = 9.5
PALETTE = sns.color_palette("deep")


def _style_axis(ax, *, xlabel: str, ylabel: str, title: str) -> None:
	ax.set_xlabel(xlabel)
	ax.set_ylabel(ylabel)
	ax.set_title(title, pad=10)
	ax.grid(axis="y", linestyle="-", linewidth=0.85, alpha=0.55)
	ax.grid(axis="x", visible=False)
	sns.despine(ax=ax, offset=6)


def _mark_last_value(ax, steps: list[float], values: list[float], color) -> None:
	if not steps or not values:
		return
	ax.scatter([steps[-1]], [values[-1]], color=color, s=24, zorder=4)


def smooth_values(values: list[float], weight: float = 0.9) -> list[float]:
	smoothed: list[float] = []
	last = values[0] if values else 0.0
	for value in values:
		last = weight * last + (1 - weight) * value
		smoothed.append(last)
	return smoothed


def plot_scalar_series(
	log_dir: str | Path,
	output_path: str | Path,
	tag: str,
	smooth_weight: float,
	title: str,
	ylabel: str,
) -> Path:
	data = read_tb_scalars(log_dir, tags=[tag])
	out = Path(output_path)
	if tag not in data or not data[tag]:
		lg.warning("no data for tag '{}' in {}", tag, log_dir)
		return out
	steps, values = tb_scalars_to_xy(data[tag])
	smoothed = smooth_values(values, smooth_weight)
	fig, ax = plt.subplots(figsize=(8, 4.5))
	ax.plot(steps, values, alpha=0.18, color="#7F8C9A", linewidth=1.0, label="Raw")
	ax.plot(steps, smoothed, color=PALETTE[0], linewidth=2.4, label=f"EMA {smooth_weight:.2f}")
	_mark_last_value(ax, steps, smoothed, PALETTE[0])
	_style_axis(ax, xlabel="Environment Steps", ylabel=ylabel, title=title)
	ax.legend()
	fig.tight_layout()
	out.parent.mkdir(parents=True, exist_ok=True)
	fig.savefig(out, dpi=200, bbox_inches="tight")
	plt.close(fig)
	return out


def plot_scalar_panels(
	log_dir: str | Path,
	output_path: str | Path,
	panels: list[tuple[str, str]],
	smooth_weight: float,
	title: str,
) -> Path:
	cols = 2
	rows = ceil(len(panels) / cols)
	fig, axes = plt.subplots(rows, cols, figsize=(10, 3.5 * rows), sharex=True)
	axes_flat = list(axes.flat) if hasattr(axes, "flat") else [axes]
	for idx, (tag, label) in enumerate(panels):
		ax = axes_flat[idx]
		data = read_tb_scalars(log_dir, tags=[tag])
		if tag in data and data[tag]:
			steps, values = tb_scalars_to_xy(data[tag])
			smoothed = smooth_values(values, smooth_weight)
			color = PALETTE[idx % len(PALETTE)]
			ax.plot(steps, values, alpha=0.15, color="#8A96A3", linewidth=0.9)
			ax.plot(steps, smoothed, color=color, linewidth=2.1)
			_mark_last_value(ax, steps, smoothed, color)
		_style_axis(ax, xlabel="", ylabel=label, title=label)
	for ax in axes_flat[len(panels):]:
		ax.axis("off")
	for ax in axes_flat[max(len(panels) - cols, 0):len(panels)]:
		ax.set_xlabel("Environment Steps")
	fig.suptitle(title, fontsize=13, fontweight="semibold", y=1.01)
	fig.tight_layout()
	out = Path(output_path)
	out.parent.mkdir(parents=True, exist_ok=True)
	fig.savefig(out, dpi=200, bbox_inches="tight")
	plt.close(fig)
	return out


def plot_scalar_series_comparison(
	log_dirs: dict[str, str | Path],
	output_path: str | Path,
	tag: str,
	smooth_weight: float,
	title: str,
	ylabel: str,
	tag_map: dict[str, str] | None = None,
) -> Path:
	tag_map = tag_map or {}
	fig, ax = plt.subplots(figsize=(8, 4.5))
	for idx, (label, log_dir) in enumerate(log_dirs.items()):
		resolved_tag = tag_map.get(label, tag)
		data = read_tb_scalars(log_dir, tags=[resolved_tag])
		if resolved_tag not in data or not data[resolved_tag]:
			lg.warning("no data for '{}' in {} ({})", resolved_tag, log_dir, label)
			continue
		steps, values = tb_scalars_to_xy(data[resolved_tag])
		smoothed = smooth_values(values, smooth_weight)
		color = PALETTE[idx % len(PALETTE)]
		ax.plot(steps, values, alpha=0.12, color=color, linewidth=0.9)
		ax.plot(steps, smoothed, color=color, linewidth=2.3, label=label)
		_mark_last_value(ax, steps, smoothed, color)
	_style_axis(ax, xlabel="Environment Steps", ylabel=ylabel, title=title)
	ax.legend()
	fig.tight_layout()
	out = Path(output_path)
	out.parent.mkdir(parents=True, exist_ok=True)
	fig.savefig(out, dpi=200, bbox_inches="tight")
	plt.close(fig)
	return out
