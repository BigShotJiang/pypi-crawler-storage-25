from __future__ import annotations

import torch
import torch.nn as nn


class NatureCNN(nn.Module):
	"""Classic Nature-DQN-style CNN; outputs a flat feature vector."""

	def __init__(self, in_channels: int, feature_dim: int = 512) -> None:
		super().__init__()
		self.net = nn.Sequential(
			nn.Conv2d(in_channels, 32, kernel_size=8, stride=4), nn.ReLU(),
			nn.Conv2d(32, 64, kernel_size=4, stride=2), nn.ReLU(),
			nn.Conv2d(64, 64, kernel_size=3, stride=1), nn.ReLU(),
			nn.Flatten(),
		)
		self._feature_dim = feature_dim
		self.fc = nn.LazyLinear(feature_dim)
		self.act = nn.ReLU()

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		return self.act(self.fc(self.net(x)))


class SmallCNN(nn.Module):
	"""Lighter CNN variant for compact pixel-input experiments."""

	def __init__(self, in_channels: int, feature_dim: int = 256) -> None:
		super().__init__()
		self.net = nn.Sequential(
			nn.Conv2d(in_channels, 32, kernel_size=8, stride=4), nn.ReLU(),
			nn.Conv2d(32, 64, kernel_size=4, stride=2), nn.ReLU(),
			nn.Conv2d(64, 64, kernel_size=3, stride=1), nn.ReLU(),
			nn.Flatten(),
		)
		self.fc = nn.LazyLinear(feature_dim)
		self.act = nn.ReLU()

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		return self.act(self.fc(self.net(x)))


class EnhancedCNN(nn.Module):
	"""Slightly stronger encoder for pixel-heavy observations."""

	def __init__(self, in_channels: int, feature_dim: int = 512) -> None:
		super().__init__()
		self.net = nn.Sequential(
			nn.Conv2d(in_channels, 32, kernel_size=5, stride=2, padding=2), nn.ReLU(),
			nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1), nn.ReLU(),
			nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1), nn.ReLU(),
			nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1), nn.ReLU(),
			nn.Flatten(),
		)
		self.fc = nn.LazyLinear(feature_dim)
		self.act = nn.ReLU()

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		return self.act(self.fc(self.net(x)))
