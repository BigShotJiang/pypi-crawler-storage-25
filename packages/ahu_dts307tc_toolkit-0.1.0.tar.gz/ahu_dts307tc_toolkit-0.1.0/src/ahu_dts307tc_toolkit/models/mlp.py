from __future__ import annotations

import torch
import torch.nn as nn


class MLP(nn.Module):
	"""Fully connected stack with optional LayerNorm."""

	def __init__(
		self,
		in_dim: int,
		hidden_dims: tuple[int, ...],
		out_dim: int | None = None,
		activation: type[nn.Module] = nn.ReLU,
		use_layer_norm: bool = False,
	) -> None:
		super().__init__()
		layers: list[nn.Module] = []
		dim = in_dim
		for h in hidden_dims:
			layers.append(nn.Linear(dim, h))
			if use_layer_norm:
				layers.append(nn.LayerNorm(h))
			layers.append(activation())
			dim = h
		self.trunk = nn.Sequential(*layers)
		self.out: nn.Linear | None
		if out_dim is not None:
			self.out = nn.Linear(dim, out_dim)
		else:
			self.out = None

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		h = self.trunk(x)
		if self.out is not None:
			return self.out(h)
		return h
