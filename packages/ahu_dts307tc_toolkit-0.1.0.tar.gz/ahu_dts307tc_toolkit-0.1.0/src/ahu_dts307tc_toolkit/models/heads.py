from __future__ import annotations

import torch
import torch.nn as nn
from torch.distributions import Categorical

from ahu_dts307tc_toolkit.models.mlp import MLP


class ActorCriticDiscreteHeads(nn.Module):
	"""Actor logits + state value from a shared feature tensor."""

	def __init__(self, feature_dim: int, num_actions: int, hidden_dim: int = 256) -> None:
		super().__init__()
		self.actor = MLP(feature_dim, (hidden_dim,), out_dim=num_actions)
		self.critic = MLP(feature_dim, (hidden_dim,), out_dim=1)

	def forward(self, features: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
		logits = self.actor(features)
		value = self.critic(features).squeeze(-1)
		return logits, value

	def policy_dist(self, features: torch.Tensor) -> Categorical:
		logits, _ = self.forward(features)
		return Categorical(logits=logits)


class QNetworkHead(nn.Module):
	"""Q(s, :) head for discrete actions (DQN family)."""

	def __init__(self, feature_dim: int, num_actions: int, hidden_dim: int = 512) -> None:
		super().__init__()
		self.q = MLP(feature_dim, (hidden_dim, hidden_dim), out_dim=num_actions)

	def forward(self, features: torch.Tensor) -> torch.Tensor:
		return self.q(features)
