from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass

import numpy as np
import torch


@dataclass
class RolloutBatch:
	obs: torch.Tensor
	actions: torch.Tensor
	log_probs: torch.Tensor
	advantages: torch.Tensor
	returns: torch.Tensor
	values: torch.Tensor


class RolloutBuffer:
	"""Fixed-horizon on-policy storage with GAE computation."""

	def __init__(
		self,
		num_steps: int,
		num_envs: int,
		obs_shape: tuple[int, ...],
		action_dim: int = 1,
		device: torch.device | str = "cpu",
		gamma: float = 0.99,
		gae_lambda: float = 0.95,
	) -> None:
		self.num_steps = num_steps
		self.num_envs = num_envs
		self.gamma = gamma
		self.gae_lambda = gae_lambda
		self.device = torch.device(device)

		self.obs = np.zeros((num_steps, num_envs, *obs_shape), dtype=np.float32)
		self.actions = np.zeros((num_steps, num_envs, action_dim), dtype=np.int64)
		self.rewards = np.zeros((num_steps, num_envs), dtype=np.float32)
		self.dones = np.zeros((num_steps, num_envs), dtype=np.float32)
		self.values = np.zeros((num_steps, num_envs), dtype=np.float32)
		self.log_probs = np.zeros((num_steps, num_envs), dtype=np.float32)
		self.advantages = np.zeros((num_steps, num_envs), dtype=np.float32)
		self.returns = np.zeros((num_steps, num_envs), dtype=np.float32)
		self._pos = 0

	def reset_storage(self) -> None:
		self._pos = 0

	def add(
		self,
		obs: np.ndarray,
		action: np.ndarray,
		reward: np.ndarray,
		done: np.ndarray,
		value: np.ndarray,
		log_prob: np.ndarray,
	) -> None:
		self.obs[self._pos] = obs
		self.actions[self._pos] = action.reshape(self.num_envs, -1)
		self.rewards[self._pos] = reward
		self.dones[self._pos] = done
		self.values[self._pos] = value
		self.log_probs[self._pos] = log_prob
		self._pos += 1

	def full(self) -> bool:
		return self._pos >= self.num_steps

	def compute_gae(self, last_values: np.ndarray, last_dones: np.ndarray) -> None:
		advantages = np.zeros_like(self.rewards)
		last_gae = 0.0
		for t in reversed(range(self.num_steps)):
			if t == self.num_steps - 1:
				next_nonterminal = 1.0 - last_dones
				next_values = last_values
			else:
				next_nonterminal = 1.0 - self.dones[t + 1]
				next_values = self.values[t + 1]
			delta = self.rewards[t] + self.gamma * next_values * next_nonterminal - self.values[t]
			last_gae = delta + self.gamma * self.gae_lambda * next_nonterminal * last_gae
			advantages[t] = last_gae
		self.advantages = advantages
		self.returns = self.advantages + self.values

	def iter_batches(self, batch_size: int, num_epochs: int, *, normalize_advantages: bool = True) -> Iterator[RolloutBatch]:
		flat_obs = self.obs.reshape(-1, *self.obs.shape[2:])
		flat_actions = self.actions.reshape(-1, *self.actions.shape[2:])
		flat_log_probs = self.log_probs.reshape(-1)
		flat_advantages = self.advantages.reshape(-1)
		flat_returns = self.returns.reshape(-1)
		flat_values = self.values.reshape(-1)
		if normalize_advantages:
			flat_advantages = (flat_advantages - flat_advantages.mean()) / (flat_advantages.std() + 1e-8)
		total = flat_obs.shape[0]
		for _ in range(num_epochs):
			indices = np.random.permutation(total)
			for start in range(0, total, batch_size):
				idx = indices[start : start + batch_size]
				yield RolloutBatch(
					obs=torch.as_tensor(flat_obs[idx], device=self.device),
					actions=torch.as_tensor(flat_actions[idx], device=self.device).squeeze(-1),
					log_probs=torch.as_tensor(flat_log_probs[idx], device=self.device),
					advantages=torch.as_tensor(flat_advantages[idx], device=self.device),
					returns=torch.as_tensor(flat_returns[idx], device=self.device),
					values=torch.as_tensor(flat_values[idx], device=self.device),
				)
