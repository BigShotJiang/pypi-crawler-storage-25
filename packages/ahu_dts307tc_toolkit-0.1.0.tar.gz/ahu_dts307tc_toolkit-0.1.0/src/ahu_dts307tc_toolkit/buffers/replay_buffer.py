from __future__ import annotations

import numpy as np


class ReplayBuffer:
	"""Uniform replay buffer for off-policy methods (e.g. DQN)."""

	def __init__(self, capacity: int, obs_shape: tuple[int, ...], action_dim: int = 1) -> None:
		self.capacity = capacity
		self.obs_shape = obs_shape
		self.action_dim = action_dim
		self.obs = np.zeros((capacity, *obs_shape), dtype=np.float32)
		self.next_obs = np.zeros((capacity, *obs_shape), dtype=np.float32)
		self.actions = np.zeros((capacity, action_dim), dtype=np.int64)
		self.rewards = np.zeros((capacity,), dtype=np.float32)
		self.dones = np.zeros((capacity,), dtype=np.float32)
		self._idx = 0
		self._size = 0

	def add(self, obs: np.ndarray, action: np.ndarray, reward: float, next_obs: np.ndarray, done: bool) -> None:
		self.obs[self._idx] = obs
		self.actions[self._idx] = np.asarray(action).reshape(self.action_dim)
		self.rewards[self._idx] = reward
		self.next_obs[self._idx] = next_obs
		self.dones[self._idx] = float(done)
		self._idx = (self._idx + 1) % self.capacity
		self._size = min(self._size + 1, self.capacity)

	def sample(self, batch_size: int, rng: np.random.Generator | None = None) -> tuple[np.ndarray, ...]:
		if rng is None:
			rng = np.random.default_rng()
		idx = rng.integers(0, self._size, size=batch_size)
		return self.obs[idx], self.actions[idx], self.rewards[idx], self.next_obs[idx], self.dones[idx]

	def __len__(self) -> int:
		return self._size
