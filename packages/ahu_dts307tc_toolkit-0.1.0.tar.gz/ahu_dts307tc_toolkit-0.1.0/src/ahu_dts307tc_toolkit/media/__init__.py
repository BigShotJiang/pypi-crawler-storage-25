"""Reusable media helpers."""

