from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np


def record_policy_frames(env, policy_fn, num_episodes: int = 1) -> list[np.ndarray]:
	frames: list[np.ndarray] = []
	for _ in range(num_episodes):
		obs, _ = env.reset()
		terminated = truncated = False
		while not (terminated or truncated):
			action = policy_fn(obs)
			obs, _, terminated, truncated, _ = env.step(action)
			frame = env.render()
			if frame is not None:
				frames.append(frame)
	return frames


def write_video(frames: list[np.ndarray], output_path: str | Path, fps: int = 30) -> Path:
	out = Path(output_path)
	if not frames:
		raise ValueError("no frames captured for video export")
	out.parent.mkdir(parents=True, exist_ok=True)
	h, w = frames[0].shape[:2]
	writer = cv2.VideoWriter(str(out), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
	for frame in frames:
		writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
	writer.release()
	return out
