from __future__ import annotations

import torch


def get_device(prefer_cuda: bool = True) -> torch.device:
	if prefer_cuda and torch.cuda.is_available():
		return torch.device("cuda")
	if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
		return torch.device("mps")
	return torch.device("cpu")
