from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from loguru import logger as lg


def save_checkpoint(path: str | Path, payload: dict[str, Any]) -> None:
	p = Path(path)
	p.parent.mkdir(parents=True, exist_ok=True)
	torch.save(payload, p)
	lg.info("checkpoint saved: {}", p)


def load_checkpoint(path: str | Path, map_location: str | torch.device | None = None) -> dict[str, Any]:
	p = Path(path)
	lg.info("loading checkpoint: {}", p)
	try:
		return torch.load(p, map_location=map_location, weights_only=False)
	except TypeError:
		return torch.load(p, map_location=map_location)
