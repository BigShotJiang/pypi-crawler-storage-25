from __future__ import annotations

from pathlib import Path
from typing import Any

try:
	import tomllib
except ModuleNotFoundError:  # pragma: no cover
	import tomli as tomllib


def load_toml(path: str | Path) -> dict[str, Any]:
	with Path(path).open("rb") as f:
		data = tomllib.load(f)
	if data is None:
		return {}
	if not isinstance(data, dict):
		raise TypeError("TOML root must be a mapping.")
	return data
