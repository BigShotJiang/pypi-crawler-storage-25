from __future__ import annotations

from typing import Any

import gymnasium as gym

from ahu_dts307tc_toolkit.env.mode import EnvMode
from ahu_dts307tc_toolkit.env.wrappers import RecordEpisodeStats, build_pixel_wrappers


def make_pixel_env(
	env_id: str,
	*,
	mode: EnvMode = EnvMode.TRAIN,
	render_mode: str | None = None,
	grayscale: bool = True,
	resize_shape: tuple[int, int] = (84, 84),
	frame_stack: int = 4,
	channel_first: bool = True,
	scale: bool = True,
	record_stats: bool = True,
	**env_kwargs: Any,
) -> gym.Env:
	"""Create a pixel-input environment with the shared preprocessing pipeline."""
	env_kwargs = dict(env_kwargs)
	if render_mode is not None:
		env_kwargs["render_mode"] = render_mode
	env = gym.make(env_id, **env_kwargs)
	env = build_pixel_wrappers(
		env,
		grayscale=grayscale,
		resize_shape=resize_shape,
		frame_stack=frame_stack,
		channel_first=channel_first,
		scale=scale,
	)
	if record_stats:
		env = RecordEpisodeStats(env)
	_ = mode  # reserved for future train/eval divergence
	return env


def make_carracing_env(
	*,
	mode: EnvMode = EnvMode.TRAIN,
	render_mode: str | None = None,
	continuous: bool = False,
	grayscale: bool = True,
	resize_shape: tuple[int, int] = (84, 84),
	frame_stack: int = 4,
	record_stats: bool = True,
	**kwargs: Any,
) -> gym.Env:
	"""Create CarRacing-v3 with the shared pixel preprocessing pipeline."""
	return make_pixel_env(
		"CarRacing-v3",
		mode=mode,
		render_mode=render_mode,
		continuous=continuous,
		grayscale=grayscale,
		resize_shape=resize_shape,
		frame_stack=frame_stack,
		channel_first=True,
		scale=True,
		record_stats=record_stats,
		**kwargs,
	)
