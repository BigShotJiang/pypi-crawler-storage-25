from enum import Enum


class EnvMode(str, Enum):
	TRAIN = "train"
	EVAL = "eval"
