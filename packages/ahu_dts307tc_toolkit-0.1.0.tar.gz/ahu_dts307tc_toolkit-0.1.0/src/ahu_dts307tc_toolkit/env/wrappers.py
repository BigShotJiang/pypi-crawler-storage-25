from __future__ import annotations

from collections import deque
from typing import Any, SupportsFloat

import gymnasium as gym
import numpy as np
from gymnasium import spaces
from gymnasium.core import ActType, ObsType, ObservationWrapper, Wrapper


class SimpleFrameStack(Wrapper):
	"""Manual frame stack that works with (C, H, W) channel-first observations.

	Stores ``num_stack`` most recent observations and concatenates along C axis.
	Output shape: (C * num_stack, H, W).
	"""

	def __init__(self, env: gym.Env, num_stack: int) -> None:
		super().__init__(env)
		self._num_stack = num_stack
		self._buffer: deque[np.ndarray] = deque(maxlen=num_stack)
		obs_space = env.observation_space
		if not isinstance(obs_space, spaces.Box):
			raise TypeError("SimpleFrameStack expects Box observation space")
		c, h, w = obs_space.shape
		self._c, self._h, self._w = c, h, w
		new_c = c * num_stack
		self.observation_space = spaces.Box(
			low=0, high=255, shape=(new_c, h, w), dtype=obs_space.dtype,
		)

	def reset(self, **kwargs: Any) -> tuple[ObsType, dict[str, Any]]:
		obs, info = super().reset(**kwargs)
		self._buffer.clear()
		for _ in range(self._num_stack):
			self._buffer.append(np.asarray(obs, dtype=self.observation_space.dtype))
		return self._stack(), info

	def step(self, action: ActType) -> tuple[ObsType, SupportsFloat, bool, bool, dict[str, Any]]:
		obs, reward, term, trunc, info = super().step(action)
		self._buffer.append(np.asarray(obs, dtype=self.observation_space.dtype))
		return self._stack(), reward, term, trunc, info

	def _stack(self) -> np.ndarray:
		return np.concatenate(list(self._buffer), axis=0)


class NumpyFloat32Observation(ObservationWrapper):
	"""Cast observations to contiguous float32 and optionally scale to [0, 1]."""

	def __init__(self, env: gym.Env, *, scale: bool = True) -> None:
		super().__init__(env)
		self._scale = scale
		obs_space = env.observation_space
		if not isinstance(obs_space, spaces.Box):
			raise TypeError("NumpyFloat32Observation expects Box observation space")
		low = np.asarray(obs_space.low, dtype=np.float32)
		high = np.asarray(obs_space.high, dtype=np.float32)
		if scale:
			low = low / 255.0
			high = high / 255.0
		self.observation_space = spaces.Box(low=low, high=high, dtype=np.float32)

	def observation(self, observation: ObsType) -> ObsType:
		arr = np.asarray(observation, dtype=np.float32)
		if self._scale:
			arr = arr / 255.0
		return arr


def build_pixel_wrappers(
	env: gym.Env,
	*,
	grayscale: bool = True,
	resize_shape: tuple[int, int] = (84, 84),
	frame_stack: int = 4,
	channel_first: bool = True,
	scale: bool = True,
) -> gym.Env:
	"""Standard pixel preprocessing for vision-based Gym environments.

	Pipeline: Grayscale → Resize → ChannelFirst → SimpleFrameStack → float32
	Final output shape: (C * frame_stack, H, W)  e.g. (4, 84, 84)
	"""
	if grayscale:
		from gymnasium.wrappers import GrayscaleObservation
		env = GrayscaleObservation(env, keep_dim=True)

	from gymnasium.wrappers import ResizeObservation
	env = ResizeObservation(env, resize_shape)

	obs_space = env.observation_space
	if channel_first and isinstance(obs_space, spaces.Box):
		low = np.asarray(obs_space.low)
		if low.ndim == 3:
			h, w, c = low.shape
		else:
			raise RuntimeError(f"expected 3D obs after grayscale/resize, got {low.ndim}D")
		env = _ChannelFirstWrapper(env, c=c, h=h, w=w)

	env = SimpleFrameStack(env, num_stack=frame_stack)
	env = NumpyFloat32Observation(env, scale=scale)
	return env


class _ChannelFirstWrapper(Wrapper):
	"""Convert (H, W, C) → (C, H, W); update space accordingly.

	Handles both (H, W, C) and (H, W) single-channel outputs from ResizeObservation.
	"""

	def __init__(self, env: gym.Env, c: int, h: int, w: int) -> None:
		super().__init__(env)
		self._c, self._h, self._w = c, h, w
		self.observation_space = spaces.Box(
			low=0, high=255, shape=(c, h, w), dtype=np.uint8,
		)

	def reset(self, **kwargs: Any) -> tuple[ObsType, dict[str, Any]]:
		obs, info = super().reset(**kwargs)
		return self.observation(obs), info

	def step(self, action: ActType) -> tuple[ObsType, SupportsFloat, bool, bool, dict[str, Any]]:
		obs, reward, term, trunc, info = super().step(action)
		return self.observation(obs), reward, term, trunc, info

	def observation(self, observation: ObsType) -> ObsType:
		arr = np.asarray(observation)
		# Handle (H, W) from ResizeObservation
		if arr.ndim == 2:
			arr = arr[:, :, np.newaxis]
		# Handle (H, W, C) → (C, H, W)
		if arr.ndim == 3:
			return np.moveaxis(arr, -1, 0)
		# Handle (N, H, W, C) from FrameStackObservation → (C*N, H, W)
		if arr.ndim == 4:
			arr = np.moveaxis(arr, -1, 1)  # (N, C, H, W)
			n, c, h, w = arr.shape
			return arr.reshape(c * n, h, w)
		return arr


class RecordEpisodeStats(Wrapper):
	"""Lightweight episode return / length tracking."""

	def __init__(self, env: gym.Env) -> None:
		super().__init__(env)
		self._ep_return = 0.0
		self._ep_len = 0

	def reset(self, **kwargs: Any) -> tuple[ObsType, dict[str, Any]]:
		self._ep_return = 0.0
		self._ep_len = 0
		return super().reset(**kwargs)

	def step(self, action: ActType) -> tuple[ObsType, SupportsFloat, bool, bool, dict[str, Any]]:
		obs, reward, terminated, truncated, info = super().step(action)
		self._ep_return += float(reward)
		self._ep_len += 1
		if terminated or truncated:
			info = dict(info)
			info["episode"] = {"r": self._ep_return, "l": self._ep_len}
		return obs, reward, terminated, truncated, info
