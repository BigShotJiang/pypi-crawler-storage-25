import numpy as np
import gymnasium as gym
from gymnasium import spaces

from ahu_dts307tc_toolkit.env.wrappers import NumpyFloat32Observation


class _DummyEnv(gym.Env):
	metadata = {}

	def __init__(self) -> None:
		self.observation_space = spaces.Box(low=0, high=255, shape=(4, 8, 8), dtype=np.uint8)
		self.action_space = spaces.Discrete(2)

	def reset(self, *, seed=None, options=None):
		raise NotImplementedError

	def step(self, action):
		raise NotImplementedError


def test_numpy_float32_observation_scales_pixels() -> None:
	wrapper = NumpyFloat32Observation(_DummyEnv(), scale=True)
	obs = np.full((4, 8, 8), 255, dtype=np.uint8)
	result = wrapper.observation(obs)
	assert result.dtype == np.float32
	assert np.allclose(result, 1.0)


def test_numpy_float32_observation_keeps_raw_range_when_scale_disabled() -> None:
	wrapper = NumpyFloat32Observation(_DummyEnv(), scale=False)
	obs = np.full((4, 8, 8), 128, dtype=np.uint8)
	result = wrapper.observation(obs)
	assert result.dtype == np.float32
	assert np.allclose(result, 128.0)
