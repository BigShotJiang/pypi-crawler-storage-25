from pathlib import Path

from ahu_dts307tc_toolkit.utils.config import load_toml


def test_load_toml_reads_mapping(tmp_path: Path) -> None:
	config_path = tmp_path / "config.toml"
	config_path.write_text("[section]\nvalue = 3\n", encoding="utf-8")
	data = load_toml(config_path)
	assert data == {"section": {"value": 3}}
