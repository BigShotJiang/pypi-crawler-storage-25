import numpy as np
import torch

from ahu_dts307tc_toolkit.buffers.rollout_buffer import RolloutBuffer


def test_iter_batches_can_skip_advantage_normalization() -> None:
	buffer = RolloutBuffer(num_steps=2, num_envs=1, obs_shape=(4,), device="cpu")
	buffer.obs[:] = np.array([[[1, 1, 1, 1]], [[2, 2, 2, 2]]], dtype=np.float32)
	buffer.actions[:] = np.array([[[0]], [[1]]], dtype=np.int64)
	buffer.log_probs[:] = np.array([[0.1], [0.2]], dtype=np.float32)
	buffer.advantages[:] = np.array([[1.0], [3.0]], dtype=np.float32)
	buffer.returns[:] = np.array([[1.0], [2.0]], dtype=np.float32)
	buffer.values[:] = np.array([[0.5], [1.5]], dtype=np.float32)

	batches = list(buffer.iter_batches(batch_size=2, num_epochs=1, normalize_advantages=False))
	assert len(batches) == 1
	assert torch.equal(torch.sort(batches[0].advantages).values, torch.tensor([1.0, 3.0]))
