# ahu-dts307tc-toolkit

Shared building blocks that are reusable across `DTS307TC` Coursework 1 and Coursework 2.

## Scope

This package only contains logic that can serve both coursework projects, such as:

- environment helpers and pixel preprocessing,
- shared neural-network building blocks,
- PPO and DQN data buffers,
- TensorBoard logging and scalar readers,
- plotting helpers,
- evaluation export utilities,
- video generation helpers,
- general utility functions such as checkpointing, config loading, device selection, and seeding.

It does **not** contain coursework-specific training orchestration or report logic.

## Install

From PyPI:

```bash
pip install ahu-dts307tc-toolkit
```

For local development:

```bash
uv sync --extra dev
```

## Package Layout

| Module | Contents |
|--------|----------|
| `env` | generic `make_pixel_env`, `make_carracing_env`, pixel wrappers, `RecordEpisodeStats` |
| `models` | `NatureCNN`, `SmallCNN`, `EnhancedCNN`, MLP blocks, policy/value and Q-network heads |
| `buffers` | `RolloutBuffer` for PPO and `ReplayBuffer` for DQN |
| `logging` | TensorBoard logger and metric helpers |
| `evaluation` | deterministic evaluation, TensorBoard scalar readers, CSV/JSON export |
| `viz` | plotting helpers for coursework experiments |
| `media` | video rendering and export helpers |
| `utils` | TOML loading, checkpoint I/O, seeding, device helpers |

## Release Workflow

This package is prepared for PyPI Trusted Publishing through GitHub Actions.

Release flow:

1. bump `version` in `pyproject.toml` and `src/ahu_dts307tc_toolkit/__init__.py`
2. commit and push
3. create a tag like `v0.1.0`
4. push the tag
5. GitHub Actions publishes the build to PyPI

The publishing workflow is defined in `.github/workflows/publish.yml`.
