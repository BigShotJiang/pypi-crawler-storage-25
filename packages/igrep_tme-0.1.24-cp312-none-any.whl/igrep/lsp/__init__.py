"""Exact-symbol navigation support for igrep.

SPEC: Public callers use :mod:`igrep.lsp.api`; backend modules stay private.
INTENT: Keep LSP as a read-only sidecar beside semantic search.
"""

from __future__ import annotations

__all__ = ["api"]
