"""Per-language entity / relation extractors for the wiki graph.

Public surface: ``extract(file_path, source, language)`` from ``treesitter``
for code files, and ``extract_markdown(file_path, source)`` for doc files.

SSoT: docs/CODEBASE_LLM_WIKI_DESIGN.md §核心图谱 + §非代码文档的 ingest
"""

from __future__ import annotations

from . import base, markdown, queries, treesitter

__all__ = ["base", "markdown", "queries", "treesitter"]
