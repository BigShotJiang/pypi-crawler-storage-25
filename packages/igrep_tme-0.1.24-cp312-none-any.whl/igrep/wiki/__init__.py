"""Codebase LLM Wiki — long-term agent-facing understanding cache.

SPEC: Tree-sitter-extracted JSONL core graph + Markdown wiki pages.
INTENT: Replace transient per-query RAG with persistent, evidence-backed wiki.
SSoT: docs/CODEBASE_LLM_WIKI_DESIGN.md
"""

from __future__ import annotations

from . import (
    auto_pages,
    build,
    candidate,
    clean,
    community,
    describe,
    docify,
    extractors,
    graph_impact,
    ingest,
    init,
    jsonl_io,
    lint,
    paths,
    qname,
    query,
    report,
    scanner,
    schemas,
    stats,
    summarize,
)
from . import pages as pages

__all__ = [
    "auto_pages",
    "build",
    "candidate",
    "clean",
    "community",
    "describe",
    "docify",
    "extractors",
    "graph_impact",
    "ingest",
    "init",
    "jsonl_io",
    "lint",
    "pages",
    "paths",
    "qname",
    "query",
    "report",
    "scanner",
    "schemas",
    "stats",
    "summarize",
]
