// igrep OpenCode plugin — injects the igrep routing reminder into OpenCode's
// system context when the current worktree has a .igrep/ index. The decision
// is delegated to `igrep-claude-hook` (Python) via stdin; we do NOT duplicate
// the index-gate or reminder body in TypeScript.
//
// Verified against OpenCode plugin API at v0.x (late 2025 / early 2026). The
// plugin contract used here: exported default async function returning an
// object with an `"experimental.chat.system.transform"` handler. The current
// directory/worktree path comes from the plugin input.
//
// Shape note: OpenCode's plugin loader accepts named exports; we export BOTH
// the default and `igrep` for compatibility with both conventions.

import { spawn } from "node:child_process";

type HookResult = {
  hookSpecificOutput?: {
    additionalContext?: string;
  };
};

async function runIgrepHook(payload: string): Promise<HookResult | null> {
  return new Promise((resolve) => {
    const proc = spawn("igrep-claude-hook", [], {
      stdio: ["pipe", "pipe", "inherit"],
    });
    let out = "";
    proc.stdout.on("data", (chunk: Buffer) => {
      out += chunk.toString("utf-8");
    });
    proc.on("close", (code: number | null) => {
      if (code !== 0 || !out.trim()) {
        resolve(null);
        return;
      }
      try {
        resolve(JSON.parse(out) as HookResult);
      } catch {
        resolve(null);
      }
    });
    proc.on("error", () => resolve(null)); // never block tool execution
    proc.stdin.end(payload);
  });
}

export const igrep = async (
  { directory, worktree }: { directory?: string; worktree?: { path?: string } } = {},
) => {
  return {
    "experimental.chat.system.transform": async (
      _input: { sessionID?: string },
      output: { system: string[] },
    ) => {
      const payload = JSON.stringify({
        tool_name: "Bash",
        // Fake grep-like command: the Python hook still gates on .igrep/ and
        // returns the canonical reminder string from the shared hook core.
        tool_input: { command: "grep igrep-routing-probe ." },
        cwd: worktree?.path ?? directory ?? process.cwd(),
      });

      const result = await runIgrepHook(payload);
      const reminder = result?.hookSpecificOutput?.additionalContext;
      if (!reminder) return;

      if (!output.system.includes(reminder)) {
        output.system.push(reminder);
      }
    },
  };
};

export default igrep;
