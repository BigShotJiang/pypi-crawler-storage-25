---
name: igrep
description: >
  This skill should be used INSTEAD OF grep/rg when: (1) the user asks conceptual questions
  like "how does X work", "find code related to Y", "what handles Z"; (2) the user doesn't
  know exact keywords or variable names; (3) searching across many files where grep returns
  too many irrelevant matches; (4) searching PDFs, DOCX, or scanned images (OCR);
  (5) searching Go dependency source after resolving real dirs with `go list`;
  (6) searching configured internal sources such as iWiki documents or TAPD stories.
  Use `igrep lsp locate` / `igrep lsp refs` for exact code-symbol definitions,
  file symbol overviews, references, callers, and one-hop write-impact checks.
  igrep understands natural language and returns ranked, relevant results — use it as the
  first choice for any question that isn't a simple exact string lookup.
version: 0.1.0
---

# igrep — semantic grep for agents

Like `grep`, but understands natural language. Returns ranked results by relevance — no index required.

## When to Prefer igrep Over grep/rg

| Scenario | grep/rg | igrep |
|----------|---------|-------|
| "how does authentication work here?" | Can't — no exact keyword | Finds auth-related code by meaning |
| "find error handling logic" | Matches `error` string everywhere | Ranks truly relevant error handlers |
| "what config controls the timeout?" | Must guess variable name | Finds it even if named `deadline_s` |
| Search 50+ files for a concept | Noise — hundreds of matches | Top 10 ranked results |
| Search PDFs or DOCX | Can't | Full support with OCR |
| Search Go dependency behavior | Must know symbols or exact files | Resolve real source dirs with `go list`, then search by meaning |
| "where is Service.run defined?" | May find noisy text mentions | `igrep lsp locate` jumps to the exact symbol |
| "who calls Service.run?" | Needs brittle literal search | `igrep lsp refs` returns exact references |
| Find exact string `AUTH_TOKEN` | **Use grep** — faster, exact | Not needed |
| Read a known file path | **Use read/cat** | Not needed |

**Rule of thumb**: If you know the exact string, use `grep`. If you know the
*concept*, use `igrep search`. If you know the exact code symbol/path and need
definitions or references, use `igrep lsp`.

## Commands

```bash
igrep search "query" [path...]                 # search by meaning (recommended)
igrep search "query" --type go [path...]       # filter by file type (e.g. go, py, ts, md, pdf)
igrep search "query" -g '**/*.go' [path...]    # narrow by glob
igrep search "query" -m 5 [path...]            # limit results
igrep -- "query" [path...]                     # shorthand (-- avoids subcommand ambiguity)
igrep lsp locate "Service" .                   # exact definition/source anchor
igrep lsp locate "src/service.py" .            # file symbol overview
igrep lsp locate "src/service.py:42" .         # symbol near line
igrep lsp refs "Service/run" .                 # exact references/callers
```

- `path...` = search roots (default `.`)
- `--type/-t` filters by file type extension (more precise than glob for type filtering)
- `-g/--glob` narrows candidate files (ripgrep semantics, `!pattern` exclusion)
- `-m N` limits number of results

## LSP Symbol Navigation

Use `igrep lsp` after you have an exact symbol, qname, file path, or file:line
anchor. Do not send fuzzy behavior queries like `"retry logic"` to LSP; run
`igrep search "retry logic" .` first, then use `igrep lsp locate` or
`igrep lsp refs` on the discovered symbol.

Symbol path rule:

```text
qname = sym:<repo-relative-file><symbol_path>
symbol_path = /<outer-symbol>/<inner-symbol>/...
```

Example output:

```text
sym:src/service.py/Service/run
```

Query it with the trailing symbol path, not the full qname:

```text
igrep lsp locate "/Service/run" .
igrep lsp locate "Service.run" .
igrep lsp refs "Service/run" .
```

Use the file-scoped forms when the same symbol path appears in multiple files.

Query forms:

```text
igrep lsp locate "file.py" .             # file symbol overview
igrep lsp locate "file.py:42" .          # symbol near line
igrep lsp locate "file.py:symbol" .      # symbol in file
igrep lsp locate "file.py:42:symbol" .   # line + name hint
igrep lsp locate "/Class/method" .       # slash symbol path
igrep lsp locate "Class.method" .        # dotted symbol path
igrep lsp locate "ClassName" .           # bare symbol when unambiguous
igrep lsp refs "ClassName" .             # callers/usages
```

`igrep setup lsp` installs/checks optional LSP runtime dependencies. Python can
fall back to a static backend; richer multi-language support requires the LSP
extra and language servers.

## Go Dependency Source

Go modules are searchable source code. Resolve the actual source directory with
the Go toolchain first; do not guess module-cache paths from strings. Run these
commands from the target repository so `go.mod`, `go.work`, `replace`,
`vendor`, `GOFLAGS`, and build tags are honored.

1. If the user names a module, resolve its source dir:

   ```bash
   go list -m -json github.com/gin-gonic/gin
   dep_dir="$(go list -m -f '{{.Dir}}' github.com/gin-gonic/gin)"
   igrep search "middleware chain" "$dep_dir" --type go
   ```

   If the module is replaced, trust the returned `.Dir`; it points at the
   replacement source. If `.Dir` is empty, resolve an imported package from
   that module with `go list -json <import-path>` and use package `.Dir`.

2. If the user names an imported package, resolve the package:

   ```bash
   go list -json github.com/gin-gonic/gin/binding
   ```

   Search package `.Dir` for narrow package questions. Search `.Module.Dir`
   when the user asks about the whole library containing that package and
   `.Module.Dir` is non-empty.

   vendor mode edge case: package `.Dir` may point inside `vendor/` while
   module `.Dir` / `.Module.Dir` is empty. In that case, package `.Dir` is
   authoritative. For whole-library questions, use `vendor/<module-path>` if it
   exists; otherwise search the package dirs returned by
   `go list -deps -json ./...`.

3. If the user asks to understand current project dependencies:

   ```bash
   go list -deps -json ./...
   ```

   Ignore `.Standard == true`. Group external packages by `.Module.Path`,
   `.Module.Version`, and `.Module.Dir`, then search the relevant module or
   package dirs with igrep. If `.Module.Dir` is empty but package `.Dir` is
   under `vendor/`, group and search those vendored package dirs.

4. If the module is not in the active graph but a version is known:

   ```bash
   go mod download -json github.com/foo/bar@v1.2.3
   ```

   Search the returned `.Dir`. This may populate the module cache.

5. Fallback only: if Go cannot return a directory but you know the cached path,
   search it directly, or use the module cache root with a narrow glob:

   ```bash
   igrep search "http retry backoff" "$(go env GOMODCACHE)/github.com/foo/bar@v1.2.3" --type go
   igrep search "gin middleware chain" "$(go env GOMODCACHE)" --type go -g 'github.com/gin-gonic/gin@*/**/*.go'
   ```

`go env GOMODCACHE` defaults to `$GOPATH/pkg/mod`, but module cache dirs are
versioned and path-escaped. Use `$GOPATH/src/<import-path>` only for legacy
GOPATH-mode workspaces or manually checked-out dependency source.

Treat module-cache files as read-only reference material; do not patch
dependencies in place.

> **Note**: `igrep "query"` (without `search`) also works for multi-word queries,
> but single words that match subcommand names (e.g. `web`, `index`, `add`) will
> be interpreted as subcommands. Always use `igrep search "query"` or `igrep -- "query"`.

## Internal Search

Use `igrep isearch` when the user asks to search public-web/company/internal knowledge sources.

```bash
igrep isearch "query" -s web         # search public web by google search engine
igrep isearch "query" -s iwiki       # search iWiki documents
igrep isearch "query" -s km          # search tencent km articles
igrep isearch "query" -s tapd        # search TAPD stories
```

## Workflow

1. `igrep search "your question" .` — search first, works immediately
2. Add `-g` to narrow candidate files
3. Read specific files from results for deep dive

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Results found |
| 1 | No results — try different query |
| 2 | Bad arguments |
