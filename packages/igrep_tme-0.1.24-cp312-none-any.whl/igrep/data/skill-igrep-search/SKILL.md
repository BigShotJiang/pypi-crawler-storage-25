---
name: igrep-search
description: >
  Route repository questions to igrep MCP tools. Use `mcp__igrep__search` for
  semantic/concept exploration, behavior lookup, Go dependency source resolved
  by `go list`, and indexed PDF/DOCX/XLSX/PPTX content. Use
  `mcp__igrep__lsp_locate` / `mcp__igrep__lsp_refs` only for exact code-symbol
  navigation. Keep built-in Search/Grep/rg/Read for exact literals, exhaustive
  sweeps, and already-known files.
---

# igrep Search — Routing Directive

For repository search and exploration, classify the task before choosing a
tool:

- **Semantic repo exploration / Concept / intent**: use `mcp__igrep__search`
  first.
- **Exact code-symbol navigation**: use `mcp__igrep__lsp_locate` or
  `mcp__igrep__lsp_refs` when you already have a concrete symbol, qname, file
  path, or file:line anchor.
- **Exact string or known file**: use built-in Search/Grep/rg/Read.

The MCP tool should replace the common loop of "search a guessed keyword, read
several files, search again" when the user is exploring a codebase by meaning
or behavior.

The LSP tools should replace grep for precise code navigation once the symbol
is known. If the user describes behavior but not the symbol, search first, then
use LSP on the discovered symbol/path.

## Route To `mcp__igrep__search`

Use the MCP tool first for:

- Natural-language code questions: `"how is auth handled"`,
  `"retry backoff logic"`, `"where does request validation happen"`.
- Unfamiliar modules or repositories where you would otherwise probe with
  several guessed terms.
- Behavior-based lookup when the symbol name is unknown, e.g. `"retry logic"`
  should find names like `attemptWithBackoff` or `handleFailureAndRetry`.
- Indexed binary/document content that Grep cannot read: PDF, DOCX, XLSX,
  PPTX, and Markdown with embedded images. This requires prior
  `igrep project add` or `igrep index`; without an index, only code and plain
  text are searched.
- Code repositories where function/class boundaries matter; igrep uses
  tree-sitter instead of arbitrary line windows.
- Go dependency/library questions. Resolve the actual source directory with
  the Go toolchain first, then call `mcp__igrep__search` on that absolute path
  with `file_type="go"`. Do not guess module-cache paths from strings.

## Go Dependency Protocol

Run Go commands from the target repository so `go.mod`, `go.work`, `replace`,
`vendor`, `GOFLAGS`, and build tags are honored.

1. Whole external module known, e.g. `github.com/gin-gonic/gin`:

   ```bash
   go list -m -json github.com/gin-gonic/gin
   dep_dir="$(go list -m -f '{{.Dir}}' github.com/gin-gonic/gin)"
   ```

   Use the module `.Dir` as the igrep `path`. If `.Replace` is present, trust
   `.Dir`; it points at the replacement source. If `.Dir` is empty, do not
   guess: resolve an imported package from that module with `go list -json
   <import-path>` and use package `.Dir`.

2. Imported package path known, e.g. `github.com/gin-gonic/gin/binding`:

   ```bash
   go list -json github.com/gin-gonic/gin/binding
   ```

   Use package `.Dir` for narrow package questions. Use `.Module.Dir` when the
   user asks about the whole library that contains the package and `.Module.Dir`
   is non-empty.

   vendor mode edge case: package `.Dir` may point inside `vendor/` while
   module `.Dir` / `.Module.Dir` is empty. In that case, treat package `.Dir`
   as authoritative. For whole-library questions, use `vendor/<module-path>` if
   that directory exists; otherwise search the package dirs returned by
   `go list -deps -json ./...`.

3. Broad "understand project dependencies" question:

   ```bash
   go list -deps -json ./...
   ```

   Ignore packages with `.Standard == true`. Group the rest by
   `.Module.Path`, `.Module.Version`, and `.Module.Dir`, then search the
   relevant module or package dirs with igrep. If `.Module.Dir` is empty but
   package `.Dir` is under `vendor/`, group and search those vendored package
   dirs.

4. Module is not in the active graph but a version is known:

   ```bash
   go mod download -json github.com/foo/bar@v1.2.3
   ```

   Use the returned `.Dir`. This may populate the module cache.

Only use `$(go env GOMODCACHE)/<module>@<version>` or a cache-root glob when
`go list` / `go mod download -json` cannot give a directory. Module-cache dirs
are versioned and path-escaped. Use `$GOPATH/src/<import-path>` only for
legacy GOPATH-mode or manually checked-out dependency source. Treat
`GOMODCACHE` results as read-only reference material; do not patch dependency
cache files in place.

## Stay With Grep/Rg/Read

Use built-in search or ripgrep when:

- You know the exact literal or regex and a narrow path.
- You need an exhaustive audit/refactor sweep; igrep returns ranked top-K,
  while Grep/rg returns every match.
- You are already inside the target file and need a single-token lookup.
- The user explicitly asks for a literal grep/rg command.

## Route To LSP Tools

Use `mcp__igrep__lsp_locate` when the user asks:

- "where is X defined?"
- "show/open the source for this class/function"
- "list symbols in this file"
- "jump to file.py:42" or "find symbol near this line"

Use `mcp__igrep__lsp_refs` when the user asks:

- "who calls X?"
- "where is this used?"
- "what breaks if I change this symbol?"
- one-hop write-impact checks for a concrete symbol

### Symbol Path Rule

igrep LSP output identifies symbols with:

```text
qname = sym:<repo-relative-file><symbol_path>
symbol_path = /<outer-symbol>/<inner-symbol>/...
```

Example:

```text
sym:src/service.py/Service/run
```

The reusable LSP query handle is the trailing symbol path:

```text
/Service/run
Service.run
Service/run
```

Do not pass the full `sym:src/service.py/Service/run` qname back as the LSP
query. Use `/Service/run` or `Service.run`; add file scope only when needed to
disambiguate.

LSP query forms:

```text
mcp__igrep__lsp_locate(query="file.py", path="<workspace>")
mcp__igrep__lsp_locate(query="file.py:42", path="<workspace>")
mcp__igrep__lsp_locate(query="file.py:symbol", path="<workspace>")
mcp__igrep__lsp_locate(query="file.py:42:symbol", path="<workspace>")
mcp__igrep__lsp_locate(query="/Class/method", path="<workspace>")
mcp__igrep__lsp_locate(query="Class.method", path="<workspace>")
mcp__igrep__lsp_locate(query="ClassName", path="<workspace>")
mcp__igrep__lsp_refs(query="ClassName", path="<workspace>")
```

Use file scoping to resolve ambiguity:

```text
mcp__igrep__lsp_locate(query="src/service.py:Service", path="<workspace>")
mcp__igrep__lsp_refs(query="src/service.py:Service.run", path="<workspace>")
mcp__igrep__lsp_refs(query="src/service.py:42:run", path="<workspace>")
```

Do not send natural-language behavior queries to LSP. For "retry logic" or
"where is auth handled", use `mcp__igrep__search` first; then use
`mcp__igrep__lsp_locate` / `mcp__igrep__lsp_refs` if the search result exposes
an exact symbol or file anchor.

## Query Rules

- Send the user's natural phrase. Do not translate semantic intent into a
  regex first.
- Start broad enough to let ranking work, then narrow with `path`,
  `file_type`, or `glob`.
- Use `top_k=3..5` for one expected answer, `10` for normal exploration, and
  `25..50` for broader discovery.
- `file_type` is an extension without dot, e.g. `"py"`, `"go"`, `"pdf"`.
- `glob` uses ripgrep semantics; later patterns win and `!pattern` excludes.
  Examples: `["src/**/*.py"]`, `["src/**", "!**/test_*"]`,
  `["!vendor/**", "!**/*.lock"]`, or from a Go module cache root
  `["github.com/gin-gonic/gin@*/**/*.go"]`.
- For Go dependency source, prefer a `go list`-resolved `.Dir` over
  `GOMODCACHE` paths.

## Examples

| Good | Anti-pattern |
|------|--------------|
| `"JWT verification middleware"` | `"jwt.*verify"` (regex-translated) |
| `"where is rate limiting configured"` | `"RateLimit"` (guessing name) |
| `"Q3 revenue formula"` (runs against .xlsx when indexed) | opening the file in Read first |
| `"http retry backoff"` with path from `go list -m -f '{{.Dir}}' <module>`, `file_type="go"` | guessing `$GOPATH/pkg/mod/<module>@<version>` |
| `"validator binding behavior"` with package `.Dir` from `go list -json <import-path>` | passing an import path directly as a filesystem path |
| `async def handle_webhook` | broad grep before reading the localized file |
| `mcp__igrep__lsp_locate(query="/Service/run", path=".")` after seeing `sym:src/service.py/Service/run` | passing `query="sym:src/service.py/Service/run"` |
| `mcp__igrep__lsp_locate(query="src/service.py:42", path=".")` | `mcp__igrep__lsp_locate(query="retry logic", path=".")` |
| `mcp__igrep__lsp_refs(query="Service/run", path=".")` | using top-K search for exact callers of a known symbol |

## Tool Call Shape

Short form agents can mentally compile to:

```
mcp__igrep__search(query="<natural phrase>", path="<dir-or-file>",
                   top_k=<confidence>, file_type=<ext?>, glob=[<filters?>])
mcp__igrep__lsp_locate(query="<exact symbol-or-path>", path="<workspace>",
                       context_lines=<0..50>)
mcp__igrep__lsp_refs(query="<exact symbol>", path="<workspace>",
                     context_lines=<0..50>)
```

If the MCP tool is hidden behind deferred discovery, load
`mcp__igrep__search`, `mcp__igrep__lsp_locate`, or `mcp__igrep__lsp_refs` once
with the available tool-discovery mechanism, then call it. Do not fall back to
guessed grep probes merely because the tool is not visible yet.

## Deprecated alias

The legacy name `mcp__igrep__igrep_search` still forwards to `search`, but it
logs a warning. Always use `mcp__igrep__search`.
