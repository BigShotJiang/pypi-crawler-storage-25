"""igrep — agent-first semantic grep / RAG grep CLI."""

from __future__ import annotations

from pathlib import Path

# Install the pynvml guard before anything else in the package loads. Any
# downstream import of torch (keybert, sentence-transformers, ...) would
# otherwise trip the `pynvml` deprecation FutureWarning + ~600ms of macOS
# dyld lookups. See `_pynvml_guard` for details.
from ._pynvml_guard import install as _install_pynvml_guard

_install_pynvml_guard()


def _read_version() -> str:
    # SSoT: <repo-root>/VERSION (plain text). Two read paths:
    #   1) source tree / editable install → read the live file (no install needed)
    #   2) installed wheel → fall back to package metadata baked in by hatchling
    repo_file = Path(__file__).resolve().parents[2] / "VERSION"
    if repo_file.is_file():
        return repo_file.read_text().strip()
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version("igrep-tme")
    except PackageNotFoundError:
        return "0.0.0+unknown"


__version__ = _read_version()
