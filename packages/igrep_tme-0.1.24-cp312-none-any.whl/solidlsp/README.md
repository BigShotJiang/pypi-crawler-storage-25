# SolidLSP (icode-cli 内嵌副本)

本目录不是手工维护代码，而是从 Serena 上游镜像同步得到。

## 权威同步流程

请使用仓库根目录脚本，而不是手工 copy：

```bash
./scripts/update_serena_mirror.sh <tag-or-commit>
./scripts/sync_solidlsp_from_subtree.sh
./scripts/check_solidlsp_drift.sh --strict
```

详细流程见：

- `docs/lsp/SOLIDLSP_SYNC_WORKFLOW.md`
- `docs/lsp/USAGE_GUIDE.md`
- `docs/lsp/TROUBLESHOOTING.md`
- `patches/solidlsp/*.patch`

## 本地定制点

- `solidlsp/serena_compat.py`（本地兼容层）
- `patches/solidlsp/0001-use-local-serena-compat.patch`
- `patches/solidlsp/0002-drop-sensai-tostringmixin.patch`

## 兼容脚本

`solidlsp/sync_from_serena.sh` 与 `solidlsp/verify_solidlsp.sh` 仍保留，
但已转发到新脚本，仅用于向后兼容。
