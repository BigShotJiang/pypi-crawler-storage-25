#!/usr/bin/env python3
"""
Test script for serena_compat module
验证移植的 Serena 依赖是否正常工作
"""

import os
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from solidlsp.serena_compat import MatchedConsecutiveLines, match_path, TextLine, LineType
from pathspec import PathSpec


def test_matched_consecutive_lines():
    """Test MatchedConsecutiveLines functionality"""
    print("\n=== Testing MatchedConsecutiveLines ===")
    
    # Test file content
    file_content = """line 1
line 2
line 3
target line 4
line 5
line 6
line 7"""
    
    # Test case 1: Get line with context
    result = MatchedConsecutiveLines.from_file_contents(
        file_content,
        line=4,  # Target line (1-indexed)
        context_lines_before=2,
        context_lines_after=2,
        source_file_path="test.txt"
    )
    
    print(f"Source file: {result.source_file_path}")
    print(f"Total lines retrieved: {len(result.lines)}")
    print(f"Lines before: {len(result.lines_before_matched)}")
    print(f"Matched lines: {len(result.matched_lines)}")
    print(f"Lines after: {len(result.lines_after_matched)}")
    
    print("\nFormatted output:")
    for line in result.lines:
        print(line.format_line())
    
    # Assertions
    assert len(result.lines) == 5, f"Expected 5 lines, got {len(result.lines)}"
    assert len(result.lines_before_matched) == 2, "Should have 2 lines before"
    assert len(result.matched_lines) == 1, "Should have 1 matched line"
    assert len(result.lines_after_matched) == 2, "Should have 2 lines after"
    assert result.matched_lines[0].line_content == "target line 4", "Matched line content incorrect"
    
    print("✅ MatchedConsecutiveLines test passed!")


def test_match_path():
    """Test match_path functionality"""
    print("\n=== Testing match_path ===")
    
    # Create a pathspec for gitignore-like patterns
    patterns = [
        "*.pyc",
        "__pycache__/",
        "*.log",
        "build/",
        "dist/",
        ".git/"
    ]
    
    path_spec = PathSpec.from_lines('gitwildmatch', patterns)
    
    # Test cases
    test_cases = [
        ("test.py", False, "Python source file should not match"),
        ("test.pyc", True, "Compiled Python file should match"),
        ("__pycache__/test.py", True, "File in __pycache__ should match"),
        ("build/output.txt", True, "File in build directory should match"),
        ("src/main.py", False, "Source file should not match"),
        ("debug.log", True, "Log file should match"),
        (".git/config", True, "Git directory should match"),
    ]
    
    print("Testing path matching:")
    for path, should_match, description in test_cases:
        result = match_path(path, path_spec)
        status = "✅" if result == should_match else "❌"
        print(f"  {status} {path}: {description} (matched={result})")
        assert result == should_match, f"Failed for {path}: expected {should_match}, got {result}"
    
    print("✅ match_path test passed!")


def test_text_line():
    """Test TextLine functionality"""
    print("\n=== Testing TextLine ===")
    
    # Test different line types
    match_line = TextLine(
        line_number=10,
        line_content="This is the matched line",
        match_type=LineType.MATCH
    )
    
    before_line = TextLine(
        line_number=9,
        line_content="This is before",
        match_type=LineType.BEFORE_MATCH
    )
    
    after_line = TextLine(
        line_number=11,
        line_content="This is after",
        match_type=LineType.AFTER_MATCH
    )
    
    print(f"Match line prefix: '{match_line.get_display_prefix()}'")
    print(f"Before line prefix: '{before_line.get_display_prefix()}'")
    print(f"After line prefix: '{after_line.get_display_prefix()}'")
    
    print("\nFormatted lines:")
    print(match_line.format_line())
    print(before_line.format_line())
    print(after_line.format_line())
    
    # Assertions
    assert match_line.get_display_prefix() == " >", "Match line should have ' >' prefix"
    assert before_line.get_display_prefix() == "...", "Before line should have '...' prefix"
    assert after_line.get_display_prefix() == "...", "After line should have '...' prefix"
    
    print("✅ TextLine test passed!")


def main():
    """Run all tests"""
    print("Testing serena_compat module...")
    
    try:
        test_text_line()
        test_matched_consecutive_lines()
        test_match_path()
        
        print("\n" + "="*50)
        print("✅ All tests passed successfully!")
        print("The solidlsp module can now work without serena dependencies.")
        print("="*50)
        
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()