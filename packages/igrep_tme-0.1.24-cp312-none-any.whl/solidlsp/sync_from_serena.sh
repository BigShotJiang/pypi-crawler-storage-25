#!/usr/bin/env bash
# Backward-compatible wrapper. Use root-level sync script.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "[DEPRECATED] use ./scripts/sync_solidlsp_from_subtree.sh"
exec "$PROJECT_ROOT/scripts/sync_solidlsp_from_subtree.sh" "$@"
