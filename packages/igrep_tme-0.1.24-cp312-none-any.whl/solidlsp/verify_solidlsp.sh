#!/usr/bin/env bash
# Backward-compatible quick verification entrypoint.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "[INFO] running drift check (strict)"
"$PROJECT_ROOT/scripts/check_solidlsp_drift.sh" --strict

echo "[INFO] running import checks"
python3 -c "from solidlsp.ls import SolidLanguageServer" >/dev/null
python3 -c "from solidlsp.settings import SolidLSPSettings" >/dev/null
python3 -c "from solidlsp.serena_compat import MatchedConsecutiveLines" >/dev/null

echo "[OK] solidlsp verify passed"
