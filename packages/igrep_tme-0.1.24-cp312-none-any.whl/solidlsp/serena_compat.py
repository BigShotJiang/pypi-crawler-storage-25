"""
Serena compatibility module for solidlsp

This module provides local implementations of Serena dependencies to avoid external dependencies.
Extracted from: https://github.com/oraios/serena
"""

import os
import pickle
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Self, Optional
from enum import StrEnum
from pathspec import PathSpec


class ToStringMixin:
    """Small local replacement for sensai's debug string mixin."""

    def __repr__(self) -> str:
        includes = getattr(self, "_tostring_includes", lambda: [])()
        excludes = set(getattr(self, "_tostring_excludes", lambda: [])())
        if includes:
            items = [(name, getattr(self, name, None)) for name in includes]
        else:
            items = [
                (name, value)
                for name, value in vars(self).items()
                if name not in excludes
            ]
        args = ", ".join(f"{name}={value!r}" for name, value in items)
        return f"{self.__class__.__name__}({args})"

    __str__ = __repr__


def getstate(_cls: type[object], obj: object, transient_properties: list[str] | None = None) -> dict[str, object]:
    transient = set(transient_properties or [])
    return {key: value for key, value in vars(obj).items() if key not in transient}


def load_pickle(path: str | os.PathLike[str]) -> object:
    with open(path, "rb") as fp:
        return pickle.load(fp)


def dump_pickle(obj: object, path: str | os.PathLike[str]) -> None:
    with open(path, "wb") as fp:
        pickle.dump(obj, fp)


@contextmanager
def log_time(label: str, logger: object | None = None) -> Iterator[None]:
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed_ms = (time.perf_counter() - start) * 1000
        info = getattr(logger, "info", None)
        if callable(info):
            info("%s completed in %.1fms", label, elapsed_ms)


# ============================================================================
# From serena.text_utils
# ============================================================================

class LineType(StrEnum):
    MATCH = "match"
    BEFORE_MATCH = "prefix"
    AFTER_MATCH = "postfix"


@dataclass(kw_only=True)
class TextLine:
    line_number: int
    line_content: str
    match_type: LineType

    def get_display_prefix(self) -> str:
        if self.match_type == LineType.MATCH:
            return " >"
        return "..."

    def format_line(self, include_line_numbers: bool = True) -> str:
        prefix = self.get_display_prefix()
        if include_line_numbers:
            line_num = str(self.line_number).rjust(4)
            prefix = f"{prefix}{line_num}"
        return f"{prefix}:{self.line_content}"


@dataclass(kw_only=True)
class MatchedConsecutiveLines:
    lines: list[TextLine]
    source_file_path: Optional[str] = None
    lines_before_matched: list[TextLine] = field(default_factory=list)
    matched_lines: list[TextLine] = field(default_factory=list)
    lines_after_matched: list[TextLine] = field(default_factory=list)

    def __post_init__(self) -> None:
        for line in self.lines:
            if line.match_type == LineType.BEFORE_MATCH:
                self.lines_before_matched.append(line)
            elif line.match_type == LineType.MATCH:
                self.matched_lines.append(line)
            elif line.match_type == LineType.AFTER_MATCH:
                self.lines_after_matched.append(line)

        assert len(self.matched_lines) > 0, "At least one matched line is required"

    @property
    def start_line(self) -> int:
        """Get the line number of the first line in the match."""
        return self.lines[0].line_number if self.lines else 0

    @property
    def end_line(self) -> int:
        """Get the line number of the last line in the match."""
        return self.lines[-1].line_number if self.lines else 0

    @classmethod
    def from_file_contents(
        cls,
        file_contents: str,
        line: int,
        context_lines_before: int = 0,
        context_lines_after: int = 0,
        source_file_path: Optional[str] = None
    ) -> Self:
        """
        Create a MatchedConsecutiveLines instance from file contents.
        
        Args:
            file_contents: The full content of the file
            line: The target line number (1-indexed)
            context_lines_before: Number of lines to include before the target
            context_lines_after: Number of lines to include after the target
            source_file_path: Optional path to the source file
            
        Returns:
            MatchedConsecutiveLines instance with the requested lines
        """
        lines_list = file_contents.splitlines()
        
        # Convert to 0-indexed
        target_line_idx = line - 1
        
        # Ensure bounds
        start_idx = max(0, target_line_idx - context_lines_before)
        end_idx = min(len(lines_list), target_line_idx + context_lines_after + 1)
        
        text_lines = []
        
        # Add context before
        for i in range(start_idx, target_line_idx):
            text_lines.append(TextLine(
                line_number=i + 1,  # Convert back to 1-indexed
                line_content=lines_list[i] if i < len(lines_list) else "",
                match_type=LineType.BEFORE_MATCH
            ))
        
        # Add the target line
        if 0 <= target_line_idx < len(lines_list):
            text_lines.append(TextLine(
                line_number=line,
                line_content=lines_list[target_line_idx],
                match_type=LineType.MATCH
            ))
        else:
            # If line is out of bounds, create an empty match line
            text_lines.append(TextLine(
                line_number=line,
                line_content="",
                match_type=LineType.MATCH
            ))
        
        # Add context after
        for i in range(target_line_idx + 1, end_idx):
            text_lines.append(TextLine(
                line_number=i + 1,  # Convert back to 1-indexed
                line_content=lines_list[i] if i < len(lines_list) else "",
                match_type=LineType.AFTER_MATCH
            ))
        
        return cls(
            lines=text_lines,
            source_file_path=source_file_path
        )


# ============================================================================
# From serena.util.file_system
# ============================================================================

def match_path(relative_path: str, path_spec: PathSpec, root_path: str = "") -> bool:
    """
    Match a relative path against a given pathspec. Just pathspec.match_file() is not enough,
    we need to do some massaging to fix issues with pathspec matching.

    Args:
        relative_path: relative path to match against the pathspec
        path_spec: the pathspec to match against
        root_path: the root path from which the relative path is derived
        
    Returns:
        Whether the path matches the pathspec
    """
    normalized_path = str(relative_path).replace(os.path.sep, "/")

    # Prefix path with / to ensure correct matching from repo root
    if not normalized_path.startswith("/"):
        normalized_path = "/" + normalized_path

    # Handle directory matching by ensuring directories end with a slash
    abs_path = os.path.abspath(os.path.join(root_path, relative_path))
    if os.path.isdir(abs_path) and not normalized_path.endswith("/"):
        normalized_path = normalized_path + "/"

    return path_spec.match_file(normalized_path)
