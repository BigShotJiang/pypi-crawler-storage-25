# LSP 规范文档说明

本目录保留了历史规范快照文件 `lsp_protocol_complete.md`，用于离线查阅。

权威在线版本请以官方为准：

- [Language Server Protocol](https://microsoft.github.io/language-server-protocol/)
- [3.17 规范](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/)

注意：本地快照可能落后于官方最新版本，升级 Serena 或 LSP 实现时请优先核对官方文档。
