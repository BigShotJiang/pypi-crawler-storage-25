"""Small .NET runtime resolver used by SolidLSP language servers."""

from __future__ import annotations

import re
import shutil
import subprocess


class DotNETUtil:
    """Resolve a usable `dotnet` executable with a minimum major/minor version."""

    def __init__(self, min_version: str, *, allow_higher_version: bool = False) -> None:
        self.min_version = min_version
        self.allow_higher_version = allow_higher_version

    def get_dotnet_path_or_raise(self) -> str:
        dotnet = shutil.which("dotnet")
        if not dotnet:
            raise RuntimeError("dotnet is not installed or not in PATH.")
        version = self._dotnet_version(dotnet)
        if not self._version_ok(version):
            relation = "or higher" if self.allow_higher_version else "exactly"
            raise RuntimeError(f"dotnet {self.min_version} {relation} is required; found {version}.")
        return dotnet

    @staticmethod
    def _dotnet_version(dotnet: str) -> str:
        result = subprocess.run([dotnet, "--version"], capture_output=True, text=True, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"failed to read dotnet version: {result.stderr.strip()}")
        return result.stdout.strip()

    def _version_ok(self, version: str) -> bool:
        actual = self._parse_version(version)
        required = self._parse_version(self.min_version)
        if self.allow_higher_version:
            return actual >= required
        return actual[:2] == required[:2]

    @staticmethod
    def _parse_version(version: str) -> tuple[int, int, int]:
        match = re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", version)
        if not match:
            raise RuntimeError(f"cannot parse dotnet version: {version}")
        return tuple(int(part or 0) for part in match.groups())  # type: ignore[return-value]
