# solidlsp 本地定制说明

本文件是 `solidlsp/` 的最小定制清单，作为同步后的验收依据。

## 同步来源

- 上游镜像：`third_party/serena/src/solidlsp`
- 同步脚本：`scripts/sync_solidlsp_from_subtree.sh`
- 漂移检查：`scripts/check_solidlsp_drift.sh`

## 定制策略

所有定制必须以补丁形式存在于 `patches/solidlsp/`，禁止手工散改。

当前补丁：

1. `0001-use-local-serena-compat.patch`
   - 将 `solidlsp/ls.py` 中 Serena 工具引用改为本地 `solidlsp.serena_compat`。
2. `0002-drop-sensai-tostringmixin.patch`
   - 移除 `sensai.util.string.ToStringMixin` 依赖；
   - 为 `CustomLSSettings` 提供轻量 `__repr__`。

## 不可覆盖文件

这些文件是本地资产，`sync` 脚本会排除覆盖：

- `solidlsp/serena_compat.py`
- `solidlsp/test_serena_compat.py`
- `solidlsp/README.md`
- `solidlsp/SOLIDLSP_CUSTOMIZATION.md`
- `solidlsp/LSP_SPEC_README.md`
- `solidlsp/lsp_protocol_complete.md`
- `solidlsp/sync_from_serena.sh`
- `solidlsp/verify_solidlsp.sh`
