from .rpm_rs import *

__doc__ = rpm_rs.__doc__
if hasattr(rpm_rs, "__all__"):
    __all__ = rpm_rs.__all__