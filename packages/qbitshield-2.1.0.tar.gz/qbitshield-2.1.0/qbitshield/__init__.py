"""QbitShield SDK exports."""

import os
import sys

# Banner that displays on first import
QBITSHIELD_BANNER = """
 ██████╗ ██████╗ ██╗████████╗███████╗██╗  ██╗██╗███████╗██╗     ██████╗ 
██╔═══██╗██╔══██╗██║╚══██╔══╝██╔════╝██║  ██║██║██╔════╝██║     ██╔══██╗
██║   ██║██████╔╝██║   ██║   ███████╗███████║██║█████╗  ██║     ██║  ██║
██║▄▄ ██║██╔══██╗██║   ██║   ╚════██║██╔══██║██║██╔══╝  ██║     ██║  ██║
╚██████╔╝██████╔╝██║   ██║   ███████║██║  ██║██║███████╗███████╗██████╔╝
 ╚══▀▀═╝ ╚═════╝ ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═════╝ 

                          P Y T H O N   S D K   v 2 . 1 . 0
"""

# Print banner on first import (only once per session)
# This shows when users import the package, providing a nice welcome message
if os.getenv("_QBITSHIELD_BANNER_SHOWN") is None:
    try:
        # Always try to print (will be suppressed in non-interactive environments)
        print(QBITSHIELD_BANNER, file=sys.stderr, flush=True)
        os.environ["_QBITSHIELD_BANNER_SHOWN"] = "1"
    except:
        pass

from .client import QbitShieldClient
from .pb_qkd import generate_key, verify_key, report_usage, print_result, print_verify_result

__all__ = [
    "QbitShieldClient",
    "generate_key",
    "verify_key",
    "report_usage",
    "print_result",
    "print_verify_result",
]
