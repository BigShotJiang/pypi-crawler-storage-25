# QbitShield SDK  v1.0.0

Python client for QbitShield's quantum-safe key distribution API.

## Installation

```bash
pip install qbitshield-sdk
```

## Quick Start — Patent-Aligned PB-QKD

The `generate_key` / `verify_key` functions call the `/api/qkd/v1/` endpoints backed by the `prime_basis` library (patent NPA-N417, 2025).

```python
from qbitshield import generate_key, verify_key, report_usage
from qbitshield.pb_qkd import print_result

# Generate a prime-basis QKD key
result = generate_key(
    {
        "primes": [2, 3, 5, 7, 11],
        "times":  [0.1, 0.2, 0.3, 0.4, 0.5],
        "bases":  ["Z", "X", "Z", "X", "Z"],
    },
    api_key="YOUR_API_KEY",
    api_base="https://qbitshield-api.railway.app",
)

# Pretty-print the result in the terminal
print_result(result)

# Verify the key
check = verify_key(
    {
        "final_key":      result["final_key"],
        "key_material":   "...",          # from your session store
        "entropy_digest": result["entropy_digest"],
    },
    api_key="YOUR_API_KEY",
)
print("Valid:", check["valid"])
```

Terminal output of `print_result()`:

```
╔══════════════════════════════════════════════════════════════╗
║           QbitShield  ·  PB-QKD Key Generation              ║
╠══════════════════════════════════════════════════════════════╣
║  Session      7b31afe9b26e437e85179...                       ║
║  Final Key    54de1c58f816d113a3b7c...                       ║
║  Digest       18e57070cf191aac...                            ║
║  Primes       [2, 3, 5, 7, 11]                               ║
║  Patent       NPA-N417-2025                                  ║
║  Runtime      SYMBOLIC                                       ║
╠══════════════════════════════════════════════════════════════╣
║  Status   ✓  KEY GENERATED                                   ║
╚══════════════════════════════════════════════════════════════╝
```

## Encryption Helpers (QbitShieldClient)

```python
from qbitshield.client import QbitShieldClient

client = QbitShieldClient(
    base_url="https://qbitshield-api.railway.app/api",
    api_key="YOUR_API_KEY"
)
latest = client.get_latest_key(token="AUTH0_ID_TOKEN")
ciphertext = client.encrypt_message("classify this datum", latest["key"], strength=256)
plaintext  = client.decrypt_message(ciphertext, latest["key"], strength=256)
```

## API Base URL

| Environment | URL |
|-------------|-----|
| Production | `https://qbitshield-api.railway.app` |
| Local | `http://localhost:8000` |

Override the default with the `QBITSHIELD_API_BASE` environment variable.

## Resources

- [User Guide](USER_GUIDE.md) — full reference including error handling, retries, best practices
- [API Reference](https://qbitshield-api.railway.app/docs)
- [Enterprise Portal](https://qbitshield-enterprise.vercel.app)

## License

MIT License. See `LICENSE` for details.
