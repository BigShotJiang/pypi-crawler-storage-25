# Changelog

All notable changes to this Odoo module will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [17.0.1.4.0] - 2026-04-29

### Added

- Trace of activity in sinli message view

### Fixed

- Fix importing sinli lines with special characters
- Fix create sinli attachment when sinli message is the email body

### Changed

- Use authorship wizard to manage new authorships after sinli book import

## [17.0.1.3.0] - 2026-03-25

### Changed

- Improve sinli import order wizard + enable export/import of books from order

## [17.0.1.2.2] - 2026-03-17

### Changed

- Handle error when importing sinli messages without attachment

## [17.0.1.2.0] - 2025-10-31

The last undocumented release. We will document the following versions.
