# -*- coding: utf-8 -*-

"""
Provides common elements related to ETL processes.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version

from core_etl.async_based import IAsyncETL
from core_etl.base import IBaseETL
from core_etl.file_based import IBaseEtlFromFile
from core_etl.record_based import IBaseEtlFromRecord

try:
    __version__ = version("core-etl")

except PackageNotFoundError:
    __version__ = "unknown"


__all__ = [
    "__version__",
    "IAsyncETL",
    "IBaseETL",
    "IBaseEtlFromFile",
    "IBaseEtlFromRecord",
]
