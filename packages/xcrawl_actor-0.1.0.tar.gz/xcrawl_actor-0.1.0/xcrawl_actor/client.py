from __future__ import annotations

import asyncio
import base64
import json
from typing import Any

import httpx

from .models import ActorRun
from .utils import encode_body, filter_out_none_values_recursively, parse_datetime, safe_resource_id


def _encode_webhook_list_to_base64(webhooks: list[dict[str, Any]]) -> str:
    data = []
    for webhook in webhooks:
        payload = {
            "eventTypes": webhook["event_types"] if "event_types" in webhook else webhook["eventTypes"],
            "requestUrl": webhook["request_url"] if "request_url" in webhook else webhook["requestUrl"],
        }
        if "payload_template" in webhook:
            payload["payloadTemplate"] = webhook["payload_template"]
        elif "payloadTemplate" in webhook:
            payload["payloadTemplate"] = webhook["payloadTemplate"]
        if "headers_template" in webhook:
            payload["headersTemplate"] = webhook["headers_template"]
        elif "headersTemplate" in webhook:
            payload["headersTemplate"] = webhook["headersTemplate"]
        data.append(payload)
    return base64.b64encode(json.dumps(data).encode("utf-8")).decode("ascii")


class _BaseClient:
    def __init__(self, root: "XcrawlApiClientAsync") -> None:
        self._root = root

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        data: Any = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        return await self._root._request(method, path, params=params, json_body=json_body, data=data, headers=headers)


class UserClient(_BaseClient):
    async def get(self) -> dict[str, Any] | None:
        return await self._request("GET", "/users/me")


class RunClient(_BaseClient):
    def __init__(self, root: "XcrawlApiClientAsync", run_id: str) -> None:
        super().__init__(root)
        self._run_id = safe_resource_id(run_id)

    def _local_run_payload(
        self,
        *,
        status: str | None = None,
        status_message: str | None = None,
        is_status_message_terminal: bool | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"id": self._run_id}
        if status is not None:
            payload["status"] = status
        if status_message is not None:
            payload["statusMessage"] = status_message
        if is_status_message_terminal is not None:
            payload["isStatusMessageTerminal"] = is_status_message_terminal
        return payload

    async def get(self) -> dict[str, Any] | None:
        # Runtime containers should not depend on the control-plane run endpoints.
        # Return a minimal local payload so higher-level helpers keep working.
        return self._local_run_payload()

    async def acquire_proxy(
        self,
        *,
        mode: str,
        source: str | None = None,
        country: str | None = None,
        sticky_session: str | None = None,
        life_seconds: int | None = None,
        count: int | None = None,
        pool: str | None = None,
        js_render: bool | None = None,
        sandbox: str | None = None,
        endpoint: str | None = None,
        validate: bool | None = None,
    ) -> Any:
        body = filter_out_none_values_recursively(
            {
                "mode": mode,
                "source": source,
                "country": country,
                "sticky_session": sticky_session,
                "life_seconds": life_seconds,
                "count": count,
                "pool": pool,
                "js_render": js_render,
                "sandbox": sandbox,
                "endpoint": endpoint,
                "validate": validate,
            }
        ) or {"mode": mode}
        return await self._request(
            "POST",
            f"/runtime/runs/{self._run_id}/proxies/acquire",
            json_body=body,
        )

    async def update(
        self,
        *,
        status_message: str | None = None,
        is_status_message_terminal: bool | None = None,
    ) -> dict[str, Any]:
        return self._local_run_payload(
            status_message=status_message,
            is_status_message_terminal=is_status_message_terminal,
        )

    async def abort(self, *, gracefully: bool | None = None) -> dict[str, Any]:
        _ = gracefully
        return self._local_run_payload(status="ABORTING")

    async def wait_for_finish(self, *, wait_secs: int | None = None) -> dict[str, Any] | None:
        _ = wait_secs
        return self._local_run_payload(status="RUNNING")

    async def metamorph(
        self,
        *,
        target_actor_id: str,
        target_actor_build: str | None = None,
        run_input: Any = None,
        content_type: str | None = None,
    ) -> dict[str, Any]:
        _ = target_actor_id, target_actor_build, run_input, content_type
        return self._local_run_payload(status="RUNNING")

    async def reboot(self) -> dict[str, Any]:
        return self._local_run_payload(status="RUNNING")


class ActorClient(_BaseClient):
    def __init__(self, root: "XcrawlApiClientAsync", actor_id: str) -> None:
        super().__init__(root)
        self._actor_id = safe_resource_id(actor_id)

    async def start(
        self,
        *,
        run_input: Any = None,
        content_type: str | None = None,
        build: str | None = None,
        max_items: int | None = None,
        max_total_charge_usd: Any = None,
        restart_on_error: bool | None = None,
        memory_mbytes: int | None = None,
        timeout_secs: int | None = None,
        force_permission_level: str | None = None,
        wait_for_finish: int | None = None,
        webhooks: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        body, content_type = encode_body(run_input, content_type)
        params = filter_out_none_values_recursively(
            {
                "build": build,
                "maxItems": max_items,
                "maxTotalChargeUsd": max_total_charge_usd,
                "restartOnError": restart_on_error,
                "memory": memory_mbytes,
                "timeout": timeout_secs,
                "forcePermissionLevel": force_permission_level,
                "waitForFinish": wait_for_finish,
                "webhooks": _encode_webhook_list_to_base64(webhooks) if webhooks else None,
            }
        ) or {}
        return await self._request(
            "POST",
            f"/acts/{self._actor_id}/runs",
            params=params,
            data=body,
            headers={"content-type": content_type},
        )

    async def call(
        self,
        *,
        run_input: Any = None,
        content_type: str | None = None,
        build: str | None = None,
        max_items: int | None = None,
        max_total_charge_usd: Any = None,
        restart_on_error: bool | None = None,
        memory_mbytes: int | None = None,
        timeout_secs: int | None = None,
        webhooks: list[dict[str, Any]] | None = None,
        force_permission_level: str | None = None,
        wait_secs: int | None = None,
        logger: Any = None,
    ) -> dict[str, Any] | None:
        started_run = await self.start(
            run_input=run_input,
            content_type=content_type,
            build=build,
            max_items=max_items,
            max_total_charge_usd=max_total_charge_usd,
            restart_on_error=restart_on_error,
            memory_mbytes=memory_mbytes,
            timeout_secs=timeout_secs,
            force_permission_level=force_permission_level,
            webhooks=webhooks,
        )
        run_client = self._root.run(started_run["id"])
        if logger and logger != "default":
            logger.info("Started remote actor run %s", started_run["id"])
        return await run_client.wait_for_finish(wait_secs=wait_secs)


class TaskClient(_BaseClient):
    def __init__(self, root: "XcrawlApiClientAsync", task_id: str) -> None:
        super().__init__(root)
        self._task_id = safe_resource_id(task_id)

    async def call(
        self,
        *,
        task_input: dict[str, Any] | None = None,
        build: str | None = None,
        max_items: int | None = None,
        memory_mbytes: int | None = None,
        timeout_secs: int | None = None,
        restart_on_error: bool | None = None,
        webhooks: list[dict[str, Any]] | None = None,
        wait_secs: int | None = None,
    ) -> dict[str, Any] | None:
        params = filter_out_none_values_recursively(
            {
                "build": build,
                "maxItems": max_items,
                "memory": memory_mbytes,
                "timeout": timeout_secs,
                "restartOnError": restart_on_error,
                "webhooks": _encode_webhook_list_to_base64(webhooks) if webhooks else None,
            }
        ) or {}
        started_run = await self._request(
            "POST",
            f"/actor-tasks/{self._task_id}/runs",
            params=params,
            json_body=task_input,
            headers={"content-type": "application/json; charset=utf-8"},
        )
        return await self._root.run(started_run["id"]).wait_for_finish(wait_secs=wait_secs)


class WebhookCollectionClient(_BaseClient):
    async def create(
        self,
        *,
        event_types: list[str],
        request_url: str,
        payload_template: str | None = None,
        headers_template: str | None = None,
        actor_id: str | None = None,
        actor_task_id: str | None = None,
        actor_run_id: str | None = None,
        ignore_ssl_errors: bool | None = None,
        do_not_retry: bool | None = None,
        idempotency_key: str | None = None,
        is_ad_hoc: bool | None = None,
    ) -> dict[str, Any]:
        payload = filter_out_none_values_recursively(
            {
                "eventTypes": event_types,
                "requestUrl": request_url,
                "payloadTemplate": payload_template,
                "headersTemplate": headers_template,
                "actId": actor_id,
                "actorTaskId": actor_task_id,
                "actorRunId": actor_run_id,
                "ignoreSslErrors": ignore_ssl_errors,
                "doNotRetry": do_not_retry,
                "idempotencyKey": idempotency_key,
                "isAdHoc": is_ad_hoc,
            }
        ) or {}
        return await self._request("POST", "/webhooks", json_body=payload)


class XcrawlDatasetClient(_BaseClient):
    def __init__(self, root: "XcrawlApiClientAsync", dataset_id: str, *, run_id: str | None = None) -> None:
        super().__init__(root)
        self._dataset_id = safe_resource_id(dataset_id)
        self._run_id = safe_resource_id(run_id) if run_id else None

    async def get(self) -> dict[str, Any] | None:
        return await self._request("GET", f"/datasets/{self._dataset_id}")

    async def update(self, *, name: str | None = None) -> dict[str, Any]:
        payload = filter_out_none_values_recursively({"name": name}) or {}
        return await self._request("PUT", f"/datasets/{self._dataset_id}", json_body=payload)

    async def delete(self) -> None:
        await self._request("DELETE", f"/datasets/{self._dataset_id}")

    async def push_items(self, items: list[dict[str, Any]] | dict[str, Any]) -> None:
        await self._request(
            "POST",
            f"/datasets/{self._dataset_id}/items",
            json_body=items,
            headers={"content-type": "application/json; charset=utf-8"},
        )

    async def append_dataset_items(self, items: list[dict[str, Any]]) -> Any:
        if self._run_id:
            path = f"/runtime/runs/{self._run_id}/datasets/{self._dataset_id}/items"
        else:
            path = f"/datasets/{self._dataset_id}/items"
        return await self._request(
            "POST",
            path,
            json_body={"items": items},
        )

    async def list_items(
        self,
        *,
        offset: int = 0,
        limit: int = 250000,
        clean: bool = False,
        desc: bool = False,
        fields: list[str] | None = None,
        omit: list[str] | None = None,
        unwind: str | None = None,
        skip_empty: bool = False,
        skip_hidden: bool = False,
        flatten: list[str] | None = None,
        view: str | None = None,
    ) -> dict[str, Any]:
        params = filter_out_none_values_recursively({
            "offset": offset,
            "limit": limit,
            "clean": clean or None,
            "desc": desc or None,
            "fields": ",".join(fields) if fields else None,
            "omit": ",".join(omit) if omit else None,
            "unwind": unwind,
            "skipEmpty": skip_empty or None,
            "skipHidden": skip_hidden or None,
            "flatten": ",".join(flatten) if flatten else None,
            "view": view,
        }) or {}
        import httpx as _httpx
        url = f"{self._root.base_url}/datasets/{self._dataset_id}/items"
        request_headers: dict[str, str] = {}
        if self._root.token:
            request_headers["Authorization"] = f"Bearer {self._root.token}"
        async with _httpx.AsyncClient(timeout=self._root.timeout_secs, follow_redirects=True) as client:
            response = await client.get(url, params=params, headers=request_headers)
            response.raise_for_status()
            data = response.json()
            return {
                "items": data,
                "total": int(response.headers.get("x-apify-pagination-total", len(data))),
                "offset": int(response.headers.get("x-apify-pagination-offset", offset)),
                "count": len(data),
                "limit": int(response.headers.get("x-apify-pagination-limit", limit)),
                "desc": response.headers.get("x-apify-pagination-desc", "false").lower() == "true",
            }

    async def iterate_items(
        self,
        *,
        offset: int = 0,
        limit: int | None = None,
        clean: bool = False,
        desc: bool = False,
        fields: list[str] | None = None,
        omit: list[str] | None = None,
        unwind: str | None = None,
        skip_empty: bool = False,
        skip_hidden: bool = False,
    ):
        read_items = 0
        page_size = 1000
        while True:
            effective_limit = page_size if limit is None else min(page_size, limit - read_items)
            if effective_limit <= 0:
                break
            page = await self.list_items(
                offset=offset + read_items,
                limit=effective_limit,
                clean=clean,
                desc=desc,
                fields=fields,
                omit=omit,
                unwind=unwind,
                skip_empty=skip_empty,
                skip_hidden=skip_hidden,
            )
            for item in page["items"]:
                yield item
                read_items += 1
            if len(page["items"]) < effective_limit:
                break


class XcrawlKeyValueStoreClient(_BaseClient):
    def __init__(self, root: "XcrawlApiClientAsync", store_id: str, *, run_id: str | None = None) -> None:
        super().__init__(root)
        self._store_id = safe_resource_id(store_id)
        self._run_id = safe_resource_id(run_id) if run_id else None

    async def get(self) -> dict[str, Any] | None:
        return await self._request("GET", f"/key-value-stores/{self._store_id}")

    async def update(self, *, name: str | None = None) -> dict[str, Any]:
        payload = filter_out_none_values_recursively({"name": name}) or {}
        return await self._request("PUT", f"/key-value-stores/{self._store_id}", json_body=payload)

    async def delete(self) -> None:
        await self._request("DELETE", f"/key-value-stores/{self._store_id}")

    async def get_record(self, key: str) -> dict[str, Any] | None:
        import httpx as _httpx
        url = f"{self._root.base_url}/key-value-stores/{self._store_id}/records/{key}"
        request_headers: dict[str, str] = {}
        if self._root.token:
            request_headers["Authorization"] = f"Bearer {self._root.token}"
        async with _httpx.AsyncClient(timeout=self._root.timeout_secs, follow_redirects=True) as client:
            response = await client.get(url, headers=request_headers)
            if response.status_code == 404:
                return None
            response.raise_for_status()
            content_type = response.headers.get("content-type", "application/octet-stream")
            try:
                value = parse_datetime(response.json())
            except Exception:
                if content_type.startswith("text/"):
                    value = response.text
                else:
                    value = response.content
            return {
                "key": key,
                "value": value,
                "contentType": content_type,
                "size": len(response.content),
            }

    async def set_record(self, key: str, value: Any, *, content_type: str | None = None) -> None:
        body, resolved_content_type = encode_body(value, content_type)
        import httpx as _httpx
        url = f"{self._root.base_url}/key-value-stores/{self._store_id}/records/{key}"
        request_headers: dict[str, str] = {"content-type": resolved_content_type}
        if self._root.token:
            request_headers["Authorization"] = f"Bearer {self._root.token}"
        async with _httpx.AsyncClient(timeout=self._root.timeout_secs, follow_redirects=True) as client:
            response = await client.put(url, content=body, headers=request_headers)
            response.raise_for_status()

    async def set_runtime_record(
        self,
        key: str,
        value: Any,
        content_type: str = "application/json",
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        if self._run_id:
            path = f"/runtime/runs/{self._run_id}/key-value-stores/{self._store_id}/records/{safe_resource_id(key)}"
        else:
            path = f"/key-value-stores/{self._store_id}/records/{safe_resource_id(key)}"
        return await self._request(
            "PUT",
            path,
            json_body={
                "value": value,
                "content_type": content_type,
                "metadata": metadata or {},
            },
        )

    async def set_kv_record(
        self,
        key: str,
        value: Any,
        content_type: str = "application/json",
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        return await self._request(
            "PUT",
            f"/key-value-stores/{self._store_id}/records/{safe_resource_id(key)}",
            json_body={
                "value": value,
                "content_type": content_type,
                "metadata": metadata or {},
            },
        )

    async def delete_record(self, key: str) -> None:
        await self._request("DELETE", f"/key-value-stores/{self._store_id}/records/{key}")

    async def list_keys(
        self,
        *,
        exclusive_start_key: str | None = None,
        limit: int = 1000,
    ) -> dict[str, Any]:
        params = filter_out_none_values_recursively({
            "exclusiveStartKey": exclusive_start_key,
            "limit": limit,
        }) or {}
        return await self._request("GET", f"/key-value-stores/{self._store_id}/keys", params=params)


class XcrawlRequestQueueClient(_BaseClient):
    def __init__(self, root: "XcrawlApiClientAsync", queue_id: str) -> None:
        super().__init__(root)
        self._queue_id = safe_resource_id(queue_id)

    async def get(self) -> dict[str, Any] | None:
        return await self._request("GET", f"/request-queues/{self._queue_id}")

    async def update(self, *, name: str | None = None) -> dict[str, Any]:
        payload = filter_out_none_values_recursively({"name": name}) or {}
        return await self._request("PUT", f"/request-queues/{self._queue_id}", json_body=payload)

    async def delete(self) -> None:
        await self._request("DELETE", f"/request-queues/{self._queue_id}")

    async def add_request(self, request: dict[str, Any], *, forefront: bool = False) -> dict[str, Any]:
        params = filter_out_none_values_recursively({"forefront": forefront or None}) or {}
        return await self._request(
            "POST",
            f"/request-queues/{self._queue_id}/requests",
            params=params,
            json_body=request,
        )

    async def add_requests_batch(
        self,
        requests: list[dict[str, Any]],
        *,
        forefront: bool = False,
        client_key: str | None = None,
    ) -> dict[str, Any]:
        params = filter_out_none_values_recursively({
            "forefront": forefront or None,
            "clientKey": client_key,
        }) or {}
        return await self._request(
            "POST",
            f"/request-queues/{self._queue_id}/requests/batch",
            params=params,
            json_body=requests,
        )

    async def get_request(self, request_id: str) -> dict[str, Any] | None:
        return await self._request("GET", f"/request-queues/{self._queue_id}/requests/{request_id}")

    async def update_request(self, request_id: str, request: dict[str, Any], *, forefront: bool = False) -> dict[str, Any]:
        params = filter_out_none_values_recursively({"forefront": forefront or None}) or {}
        return await self._request(
            "PUT",
            f"/request-queues/{self._queue_id}/requests/{request_id}",
            params=params,
            json_body=request,
        )

    async def delete_request(self, request_id: str) -> None:
        await self._request("DELETE", f"/request-queues/{self._queue_id}/requests/{request_id}")

    async def list_head(self, *, limit: int = 100, client_key: str | None = None) -> dict[str, Any]:
        params = filter_out_none_values_recursively({
            "limit": limit,
            "clientKey": client_key,
        }) or {}
        return await self._request("GET", f"/request-queues/{self._queue_id}/head", params=params)

    async def list_and_lock_head(self, *, limit: int = 25, lock_secs: int = 60, client_key: str | None = None) -> dict[str, Any]:
        params = filter_out_none_values_recursively({
            "limit": limit,
            "lockSecs": lock_secs,
            "clientKey": client_key,
        }) or {}
        return await self._request("POST", f"/request-queues/{self._queue_id}/head/lock", params=params)


class XcrawlApiClientAsync:
    def __init__(
        self,
        *,
        token: str | None = None,
        api_url: str = "https://api.xcrawl.com",
        max_retries: int | None = None,
        min_delay_between_retries_millis: int | None = None,
        timeout_secs: int | None = None,
    ) -> None:
        self.token = token
        self.base_url = api_url.rstrip("/") + "/v2"
        self.public_base_url = self.base_url
        self.max_retries = 1 if max_retries is None else max_retries
        self.min_delay_between_retries = 0.5 if min_delay_between_retries_millis is None else max(
            min_delay_between_retries_millis / 1000,
            0,
        )
        self.timeout_secs = 30 if timeout_secs is None else timeout_secs
        self._client = httpx.AsyncClient(timeout=self.timeout_secs, follow_redirects=True)

    def actor(self, actor_id: str) -> ActorClient:
        return ActorClient(self, actor_id)

    def run(self, run_id: str) -> RunClient:
        return RunClient(self, run_id)

    def task(self, task_id: str) -> TaskClient:
        return TaskClient(self, task_id)

    def webhooks(self) -> WebhookCollectionClient:
        return WebhookCollectionClient(self)

    def user(self) -> UserClient:
        return UserClient(self)

    def dataset(self, dataset_id: str, *, run_id: str | None = None) -> XcrawlDatasetClient:
        return XcrawlDatasetClient(self, dataset_id, run_id=run_id)

    def key_value_store(self, store_id: str, *, run_id: str | None = None) -> XcrawlKeyValueStoreClient:
        return XcrawlKeyValueStoreClient(self, store_id, run_id=run_id)

    def request_queue(self, queue_id: str) -> XcrawlRequestQueueClient:
        return XcrawlRequestQueueClient(self, queue_id)

    async def append_dataset_items(self, items: list[dict[str, Any]], *, dataset_id: str = "default") -> Any:
        return await self.dataset(dataset_id).append_dataset_items(items)

    async def set_kv_record(
        self,
        key: str,
        value: Any,
        content_type: str = "application/json",
        metadata: dict[str, Any] | None = None,
        *,
        store_id: str = "default",
    ) -> Any:
        return await self.key_value_store(store_id).set_kv_record(key, value, content_type, metadata)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        data: Any = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        request_headers = dict(headers or {})
        if self.token:
            request_headers["Authorization"] = f"Bearer {self.token}"
        attempt = 0
        while True:
            try:
                response = await self._client.request(
                    method=method,
                    url=url,
                    params=params,
                    json=json_body,
                    content=data,
                    headers=request_headers,
                )
                response.raise_for_status()
                if response.status_code == 204:
                    return None
                payload = response.json()
                payload = parse_datetime(payload)
                if isinstance(payload, dict) and "data" in payload:
                    return payload["data"]
                return payload
            except httpx.HTTPStatusError:
                raise
            except httpx.HTTPError:
                attempt += 1
                if attempt > self.max_retries:
                    raise
                await asyncio.sleep(self.min_delay_between_retries)


def maybe_parse_actor_run(payload: dict[str, Any] | None) -> ActorRun | None:
    if payload is None:
        return None
    return ActorRun.model_validate(payload)
