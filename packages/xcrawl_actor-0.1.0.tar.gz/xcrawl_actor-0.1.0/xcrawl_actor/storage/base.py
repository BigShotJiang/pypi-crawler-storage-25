from __future__ import annotations

import asyncio
from collections import deque
from datetime import datetime, timezone
from typing import Any, Sequence

from typing_extensions import Self, override

from crawlee import Request
from crawlee._utils.crypto import crypto_random_object_id
from crawlee.storage_clients import StorageClient
from crawlee.storage_clients._base import DatasetClient, KeyValueStoreClient, RequestQueueClient
from crawlee.storage_clients.models import (
    AddRequestsResponse,
    DatasetItemsListPage,
    DatasetMetadata,
    KeyValueStoreMetadata,
    KeyValueStoreRecord,
    KeyValueStoreRecordMetadata,
    ProcessedRequest,
    RequestQueueMetadata,
    UnprocessedRequest,
)


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


class SimpleMemoryRequestQueueMixin(RequestQueueClient):
    def __init__(self, *, metadata: RequestQueueMetadata) -> None:
        self._metadata = metadata
        self._pending_requests = deque[Request]()
        self._handled_requests: dict[str, Request] = {}
        self._in_progress_requests: dict[str, Request] = {}
        self._requests_by_unique_key: dict[str, Request] = {}

    @override
    async def get_metadata(self) -> RequestQueueMetadata:
        return self._metadata

    @override
    async def add_batch_of_requests(
        self,
        requests: Sequence[Request],
        *,
        forefront: bool = False,
    ) -> AddRequestsResponse:
        processed_requests = []
        for request in requests:
            existing_request = self._requests_by_unique_key.get(request.unique_key)
            was_already_present = existing_request is not None
            was_already_handled = (
                was_already_present and existing_request is not None and existing_request.handled_at is not None
            )
            is_in_progress = request.unique_key in self._in_progress_requests

            if was_already_handled:
                processed_requests.append(
                    ProcessedRequest(
                        unique_key=request.unique_key,
                        was_already_present=True,
                        was_already_handled=True,
                    )
                )
                continue

            if is_in_progress:
                processed_requests.append(
                    ProcessedRequest(
                        unique_key=request.unique_key,
                        was_already_present=True,
                        was_already_handled=False,
                    )
                )
                continue

            if was_already_present and existing_request:
                self._requests_by_unique_key[request.unique_key] = request
                if forefront:
                    try:
                        self._pending_requests.remove(existing_request)
                    except ValueError:
                        pass
                    self._pending_requests.appendleft(request)
            else:
                if forefront:
                    self._pending_requests.appendleft(request)
                else:
                    self._pending_requests.append(request)
                self._requests_by_unique_key[request.unique_key] = request
                await self._update_metadata(
                    new_total_request_count=self._metadata.total_request_count + 1,
                    new_pending_request_count=self._metadata.pending_request_count + 1,
                )

            processed_requests.append(
                ProcessedRequest(
                    unique_key=request.unique_key,
                    was_already_present=was_already_present,
                    was_already_handled=False,
                )
            )

        await self._update_metadata(update_accessed_at=True, update_modified_at=True)
        return AddRequestsResponse(processed_requests=processed_requests, unprocessed_requests=[])

    @override
    async def get_request(self, unique_key: str) -> Request | None:
        await self._update_metadata(update_accessed_at=True)
        return self._requests_by_unique_key.get(unique_key)

    @override
    async def fetch_next_request(self) -> Request | None:
        while self._pending_requests:
            request = self._pending_requests.popleft()
            if request.was_already_handled:
                continue
            if request.unique_key in self._in_progress_requests:
                continue
            self._in_progress_requests[request.unique_key] = request
            return request
        return None

    @override
    async def mark_request_as_handled(self, request: Request) -> ProcessedRequest | None:
        if request.unique_key not in self._in_progress_requests:
            return None
        if not request.was_already_handled:
            request.handled_at = now_utc()
        self._handled_requests[request.unique_key] = request
        self._requests_by_unique_key[request.unique_key] = request
        del self._in_progress_requests[request.unique_key]
        await self._update_metadata(
            new_handled_request_count=self._metadata.handled_request_count + 1,
            new_pending_request_count=self._metadata.pending_request_count - 1,
            update_modified_at=True,
        )
        return ProcessedRequest(
            unique_key=request.unique_key,
            was_already_present=True,
            was_already_handled=True,
        )

    @override
    async def reclaim_request(
        self,
        request: Request,
        *,
        forefront: bool = False,
    ) -> ProcessedRequest | None:
        if request.unique_key not in self._in_progress_requests:
            return None
        del self._in_progress_requests[request.unique_key]
        if forefront:
            self._pending_requests.appendleft(request)
        else:
            self._pending_requests.append(request)
        await self._update_metadata(update_modified_at=True)
        return ProcessedRequest(
            unique_key=request.unique_key,
            was_already_present=True,
            was_already_handled=False,
        )

    @override
    async def is_empty(self) -> bool:
        await self._update_metadata(update_accessed_at=True)
        return len(self._pending_requests) == 0 and len(self._in_progress_requests) == 0

    async def _update_metadata(
        self,
        *,
        update_accessed_at: bool = False,
        update_modified_at: bool = False,
        new_handled_request_count: int | None = None,
        new_pending_request_count: int | None = None,
        new_total_request_count: int | None = None,
    ) -> None:
        now = now_utc()
        if update_accessed_at:
            self._metadata.accessed_at = now
        if update_modified_at:
            self._metadata.modified_at = now
        if new_handled_request_count is not None:
            self._metadata.handled_request_count = new_handled_request_count
        if new_pending_request_count is not None:
            self._metadata.pending_request_count = new_pending_request_count
        if new_total_request_count is not None:
            self._metadata.total_request_count = new_total_request_count


def new_dataset_metadata(*, id: str, name: str | None = None, item_count: int = 0) -> DatasetMetadata:
    now = now_utc()
    return DatasetMetadata(
        id=id,
        name=name,
        item_count=item_count,
        created_at=now,
        modified_at=now,
        accessed_at=now,
    )


def new_kvs_metadata(*, id: str, name: str | None = None) -> KeyValueStoreMetadata:
    now = now_utc()
    return KeyValueStoreMetadata(
        id=id,
        name=name,
        created_at=now,
        modified_at=now,
        accessed_at=now,
    )


def new_rq_metadata(*, id: str, name: str | None = None) -> RequestQueueMetadata:
    now = now_utc()
    return RequestQueueMetadata(
        id=id,
        name=name,
        created_at=now,
        modified_at=now,
        accessed_at=now,
        had_multiple_clients=False,
        handled_request_count=0,
        pending_request_count=0,
        total_request_count=0,
    )


def make_storage_id() -> str:
    return crypto_random_object_id()

