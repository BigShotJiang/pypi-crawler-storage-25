from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from json import JSONDecodeError
from typing import Any, AsyncIterator, Literal, Sequence

from typing_extensions import override

from crawlee import Request
from crawlee._utils.file import json_dumps
from crawlee.storage_clients import StorageClient
from crawlee.storage_clients._base import DatasetClient, KeyValueStoreClient, RequestQueueClient
from crawlee.storage_clients.models import (
    AddRequestsResponse,
    DatasetItemsListPage,
    DatasetMetadata,
    KeyValueStoreMetadata,
    KeyValueStoreRecord,
    KeyValueStoreRecordMetadata,
    ProcessedRequest,
    RequestQueueMetadata,
    UnprocessedRequest,
)

from ..configuration import Configuration
from ..consts import DEFAULT_ALIAS, DEFAULT_ALIAS_MAPPING_KEY
from ..utils import (
    compute_request_id,
    encode_body,
    filter_out_none_values_recursively,
    hash_api_base_url_and_token,
    parse_datetime,
    safe_resource_id,
)
from .base import SimpleMemoryRequestQueueMixin


def _storage_type_key(storage_type: str) -> str:
    return {
        "Dataset": "datasets",
        "KeyValueStore": "key_value_stores",
        "RequestQueue": "request_queues",
    }[storage_type]


class CloudApi:
    def __init__(self, configuration: Configuration) -> None:
        if not configuration.token:
            raise ValueError("Cloud storage requires `token` in Configuration.")
        self._configuration = configuration
        self._headers = {"Authorization": f"Bearer {configuration.token}"}
        self._base_url = configuration.api_base_url.rstrip("/") + "/v2"

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        data: Any = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        import httpx

        async with httpx.AsyncClient(timeout=360, follow_redirects=True) as client:
            request_headers = dict(self._headers)
            if headers:
                request_headers.update(headers)
            response = await client.request(
                method=method,
                url=f"{self._base_url}{path}",
                params=params,
                json=json_body,
                content=data,
                headers=request_headers,
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            if response.status_code == 204:
                return None
            payload = response.json()
            payload = parse_datetime(payload)
            if isinstance(payload, dict) and "data" in payload:
                return payload["data"]
            return payload

    async def get_kvs_record(self, store_id: str, key: str) -> dict[str, Any] | None:
        import httpx

        async with httpx.AsyncClient(timeout=360, follow_redirects=True) as client:
            response = await client.get(
                f"{self._base_url}/key-value-stores/{safe_resource_id(store_id)}/records/{key}",
                params={"attachment": True},
                headers=self._headers,
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            content_type = response.headers.get("content-type", "application/octet-stream")
            value: Any
            try:
                value = parse_datetime(response.json())
            except JSONDecodeError:
                if content_type.startswith("text/"):
                    value = response.text
                else:
                    value = response.content
            return {
                "key": key,
                "value": value,
                "content_type": content_type,
                "contentType": content_type,
                "size": len(response.content),
            }

    async def set_kvs_record(self, store_id: str, key: str, value: Any, content_type: str | None = None) -> None:
        body, resolved_content_type = encode_body(value, content_type)
        await self.request(
            "PUT",
            f"/key-value-stores/{safe_resource_id(store_id)}/records/{key}",
            data=body,
            headers={"content-type": resolved_content_type},
        )

    async def delete_kvs_record(self, store_id: str, key: str) -> None:
        await self.request("DELETE", f"/key-value-stores/{safe_resource_id(store_id)}/records/{key}")

    async def record_exists(self, store_id: str, key: str) -> bool:
        import httpx

        async with httpx.AsyncClient(timeout=360, follow_redirects=True) as client:
            response = await client.head(
                f"{self._base_url}/key-value-stores/{safe_resource_id(store_id)}/records/{key}",
                headers=self._headers,
            )
            if response.status_code == 404:
                return False
            response.raise_for_status()
            return response.status_code == 200


class CloudAliasResolver:
    _alias_map: dict[str, str] = {}
    _alias_map_loaded: bool = False
    _alias_init_lock: asyncio.Lock | None = None

    def __init__(self, storage_type: str, alias: str, configuration: Configuration) -> None:
        self._storage_type = storage_type
        self._alias = alias
        self._configuration = configuration
        self._api = CloudApi(configuration)

    async def __aenter__(self) -> "CloudAliasResolver":
        lock = await self._get_alias_init_lock()
        await lock.acquire()
        return self

    async def __aexit__(self, exc_type, exc_value, exc_traceback) -> None:
        lock = await self._get_alias_init_lock()
        lock.release()

    @classmethod
    async def _get_alias_init_lock(cls) -> asyncio.Lock:
        if cls._alias_init_lock is None:
            cls._alias_init_lock = asyncio.Lock()
        return cls._alias_init_lock

    @property
    def _storage_key(self) -> str:
        return ",".join(
            [
                self._storage_type,
                self._alias,
                hash_api_base_url_and_token(self._configuration.api_public_base_url, self._configuration.token or ""),
            ]
        )

    async def resolve_id(self) -> str | None:
        storages = self._configuration.actor_storages
        if storages:
            found = storages.get(_storage_type_key(self._storage_type), {}).get(self._alias)
            if found:
                return found
        alias_map = await self._get_alias_map()
        return alias_map.get(self._storage_key)

    async def store_mapping(self, storage_id: str) -> None:
        alias_map = await self._get_alias_map()
        alias_map[self._storage_key] = storage_id
        default_kvs_id = self._configuration.default_key_value_store_id
        if not default_kvs_id:
            return
        current = await self._api.get_kvs_record(default_kvs_id, DEFAULT_ALIAS_MAPPING_KEY)
        value = current["value"] if current else {}
        value[self._storage_key] = storage_id
        await self._api.set_kvs_record(default_kvs_id, DEFAULT_ALIAS_MAPPING_KEY, value, "application/json; charset=utf-8")

    async def _get_alias_map(self) -> dict[str, str]:
        if not self.__class__._alias_map_loaded and self._configuration.default_key_value_store_id:
            current = await self._api.get_kvs_record(
                self._configuration.default_key_value_store_id,
                DEFAULT_ALIAS_MAPPING_KEY,
            )
            self.__class__._alias_map = current["value"] if current else {}
            self.__class__._alias_map_loaded = True
        return self.__class__._alias_map


async def resolve_cloud_storage(
    *,
    storage_type: Literal["Dataset", "KeyValueStore", "RequestQueue"],
    configuration: Configuration,
    id: str | None = None,
    name: str | None = None,
    alias: str | None = None,
) -> tuple[CloudApi, dict[str, Any]]:
    if sum(1 for item in [id, name, alias] if item is not None) > 1:
        raise ValueError('Only one of "id", "name", or "alias" can be specified.')

    api = CloudApi(configuration)
    collection_path = {
        "Dataset": "/datasets",
        "KeyValueStore": "/key-value-stores",
        "RequestQueue": "/request-queues",
    }[storage_type]
    single_path = {
        "Dataset": "/datasets/{id}",
        "KeyValueStore": "/key-value-stores/{id}",
        "RequestQueue": "/request-queues/{id}",
    }[storage_type]

    default_id = {
        "Dataset": configuration.default_dataset_id,
        "KeyValueStore": configuration.default_key_value_store_id,
        "RequestQueue": configuration.default_request_queue_id,
    }[storage_type]

    async def get_by_id(storage_id: str) -> dict[str, Any] | None:
        return await api.request("GET", single_path.format(id=safe_resource_id(storage_id)))

    async def get_or_create(*, storage_name: str | None = None) -> dict[str, Any]:
        params = {"name": storage_name} if storage_name else None
        return await api.request("POST", collection_path, params=params)

    match (alias, name, id, default_id):
        case (None, None, None, None):
            async with CloudAliasResolver(storage_type, DEFAULT_ALIAS, configuration) as resolver:
                storage_id = await resolver.resolve_id()
                if storage_id:
                    metadata = await get_by_id(storage_id)
                    if metadata:
                        return api, metadata
                metadata = await get_or_create()
                await resolver.store_mapping(metadata["id"])
                return api, metadata
        case (str(), None, None, _):
            async with CloudAliasResolver(storage_type, alias, configuration) as resolver:
                storage_id = await resolver.resolve_id()
                if storage_id:
                    metadata = await get_by_id(storage_id)
                    if metadata:
                        return api, metadata
                metadata = await get_or_create()
                await resolver.store_mapping(metadata["id"])
                return api, metadata
        case (None, None, None, str()):
            metadata = await get_by_id(default_id)
            if metadata is None:
                metadata = await get_or_create()
            return api, metadata
        case (None, str(), None, _):
            metadata = await get_or_create(storage_name=name)
            return api, metadata
        case (None, None, str(), _):
            metadata = await get_by_id(id)
            if metadata is None:
                raise ValueError(f"Opening {storage_type} with id={id} failed.")
            return api, metadata
    raise RuntimeError("Unreachable code")


class CloudDatasetClient(DatasetClient):
    def __init__(self, *, api: CloudApi, metadata: DatasetMetadata) -> None:
        self._api = api
        self._metadata = metadata
        self._lock = asyncio.Lock()

    @classmethod
    async def open(
        cls,
        *,
        id: str | None,
        name: str | None,
        alias: str | None,
        configuration: Configuration,
    ) -> "CloudDatasetClient":
        api, raw_metadata = await resolve_cloud_storage(
            storage_type="Dataset",
            configuration=configuration,
            id=id,
            name=name,
            alias=alias,
        )
        return cls(api=api, metadata=DatasetMetadata.model_validate(raw_metadata))

    @override
    async def get_metadata(self) -> DatasetMetadata:
        metadata = await self._api.request("GET", f"/datasets/{safe_resource_id(self._metadata.id)}")
        if metadata is not None:
            self._metadata = DatasetMetadata.model_validate(metadata)
        return self._metadata

    @override
    async def drop(self) -> None:
        async with self._lock:
            await self._api.request("DELETE", f"/datasets/{safe_resource_id(self._metadata.id)}")

    @override
    async def purge(self) -> None:
        raise NotImplementedError("Purging datasets is not supported by the cloud backend. Use drop instead.")

    @override
    async def push_data(self, data: list[Any] | dict[str, Any]) -> None:
        async with self._lock:
            await self._api.request(
                "POST",
                f"/datasets/{safe_resource_id(self._metadata.id)}/items",
                json_body=data,
                headers={"content-type": "application/json; charset=utf-8"},
            )

    @override
    async def get_data(
        self,
        *,
        offset: int = 0,
        limit: int | None = 999_999_999_999,
        clean: bool = False,
        desc: bool = False,
        fields: list[str] | None = None,
        omit: list[str] | None = None,
        unwind: list[str] | None = None,
        skip_empty: bool = False,
        skip_hidden: bool = False,
        flatten: list[str] | None = None,
        view: str | None = None,
    ) -> DatasetItemsListPage:
        import httpx

        params = filter_out_none_values_recursively(
            {
                "offset": offset,
                "limit": limit,
                "clean": clean,
                "desc": desc,
                "fields": fields,
                "omit": omit,
                "unwind": unwind,
                "skipEmpty": skip_empty,
                "skipHidden": skip_hidden,
                "flatten": flatten,
                "view": view,
            }
        ) or {}
        headers = {"Authorization": f"Bearer {self._api._configuration.token}"}
        async with httpx.AsyncClient(timeout=360, follow_redirects=True) as client:
            response = await client.get(
                f"{self._api._base_url}/datasets/{safe_resource_id(self._metadata.id)}/items",
                params=params,
                headers=headers,
            )
            response.raise_for_status()
            data = response.json()
            return DatasetItemsListPage(
                items=data,
                total=int(response.headers.get("x-apify-pagination-total", len(data))),
                offset=int(response.headers.get("x-apify-pagination-offset", offset)),
                count=len(data),
                limit=int(response.headers.get("x-apify-pagination-limit", limit or len(data) or 0)),
                desc=response.headers.get("x-apify-pagination-desc", "false").lower() == "true",
            )

    @override
    async def iterate_items(
        self,
        *,
        offset: int = 0,
        limit: int | None = None,
        clean: bool = False,
        desc: bool = False,
        fields: list[str] | None = None,
        omit: list[str] | None = None,
        unwind: list[str] | None = None,
        skip_empty: bool = False,
        skip_hidden: bool = False,
    ) -> AsyncIterator[dict[str, Any]]:
        read_items = 0
        page_size = 1000
        while True:
            effective_limit = page_size if limit is None else min(page_size, limit - read_items)
            if effective_limit <= 0:
                break
            page = await self.get_data(
                offset=offset + read_items,
                limit=effective_limit,
                clean=clean,
                desc=desc,
                fields=fields,
                omit=omit,
                unwind=unwind,
                skip_empty=skip_empty,
                skip_hidden=skip_hidden,
            )
            for item in page.items:
                yield item
                read_items += 1
            if len(page.items) < effective_limit:
                break


class CloudKeyValueStoreClient(KeyValueStoreClient):
    def __init__(self, *, api: CloudApi, metadata: KeyValueStoreMetadata) -> None:
        self._api = api
        self._metadata = metadata
        self._lock = asyncio.Lock()

    @classmethod
    async def open(
        cls,
        *,
        id: str | None,
        name: str | None,
        alias: str | None,
        configuration: Configuration,
    ) -> "CloudKeyValueStoreClient":
        api, raw_metadata = await resolve_cloud_storage(
            storage_type="KeyValueStore",
            configuration=configuration,
            id=id,
            name=name,
            alias=alias,
        )
        return cls(api=api, metadata=KeyValueStoreMetadata.model_validate(raw_metadata))

    @override
    async def get_metadata(self) -> KeyValueStoreMetadata:
        metadata = await self._api.request("GET", f"/key-value-stores/{safe_resource_id(self._metadata.id)}")
        if metadata is not None:
            self._metadata = KeyValueStoreMetadata.model_validate(metadata)
        return self._metadata

    @override
    async def drop(self) -> None:
        async with self._lock:
            await self._api.request("DELETE", f"/key-value-stores/{safe_resource_id(self._metadata.id)}")

    @override
    async def purge(self) -> None:
        raise NotImplementedError("Purging key-value stores is not supported by the cloud backend. Use drop instead.")

    @override
    async def get_value(self, *, key: str) -> KeyValueStoreRecord | None:
        record = await self._api.get_kvs_record(self._metadata.id, key)
        return KeyValueStoreRecord.model_validate(record) if record else None

    @override
    async def set_value(self, *, key: str, value: Any, content_type: str | None = None) -> None:
        if value is None:
            await self.delete_value(key=key)
            return
        async with self._lock:
            await self._api.set_kvs_record(self._metadata.id, key, value, content_type)

    @override
    async def delete_value(self, *, key: str) -> None:
        async with self._lock:
            await self._api.delete_kvs_record(self._metadata.id, key)

    @override
    async def iterate_keys(
        self,
        *,
        exclusive_start_key: str | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[KeyValueStoreRecordMetadata]:
        count = 0
        while True:
            response = await self._api.request(
                "GET",
                f"/key-value-stores/{safe_resource_id(self._metadata.id)}/keys",
                params=filter_out_none_values_recursively(
                    {
                        "exclusiveStartKey": exclusive_start_key,
                        "limit": limit,
                    }
                ),
            )
            items = response.get("items", []) if response else []
            for item in items:
                yield KeyValueStoreRecordMetadata(
                    key=item["key"],
                    size=item.get("size"),
                    content_type=item.get("contentType", "application/octet-stream"),
                )
                count += 1
                if limit and count >= limit:
                    break
            if (limit and count >= limit) or not response or not response.get("isTruncated"):
                break
            exclusive_start_key = response.get("nextExclusiveStartKey")

    @override
    async def get_public_url(self, *, key: str) -> str:
        base = self._api._configuration.api_public_base_url.rstrip("/")
        return f"{base}/v2/key-value-stores/{safe_resource_id(self._metadata.id)}/records/{key}"

    @override
    async def record_exists(self, *, key: str) -> bool:
        return await self._api.record_exists(self._metadata.id, key)


class CloudRequestQueueClient(SimpleMemoryRequestQueueMixin):
    def __init__(self, *, api: CloudApi, metadata: RequestQueueMetadata, client_key: str | None) -> None:
        super().__init__(metadata=metadata)
        self._api = api
        self._client_key = client_key
        self._lock = asyncio.Lock()

    @classmethod
    async def open(
        cls,
        *,
        id: str | None,
        name: str | None,
        alias: str | None,
        configuration: Configuration,
    ) -> "CloudRequestQueueClient":
        api, raw_metadata = await resolve_cloud_storage(
            storage_type="RequestQueue",
            configuration=configuration,
            id=id,
            name=name,
            alias=alias,
        )
        client_key = (configuration.actor_run_id or configuration.actor_id or configuration.user_id or "xcrawl-client")[:32]
        return cls(
            api=api,
            metadata=RequestQueueMetadata.model_validate(raw_metadata),
            client_key=client_key,
        )

    @override
    async def get_metadata(self) -> RequestQueueMetadata:
        metadata = await self._api.request("GET", f"/request-queues/{safe_resource_id(self._metadata.id)}")
        if metadata is not None:
            self._metadata = RequestQueueMetadata.model_validate(metadata)
        return self._metadata

    @override
    async def drop(self) -> None:
        async with self._lock:
            await self._api.request("DELETE", f"/request-queues/{safe_resource_id(self._metadata.id)}")
            self._pending_requests.clear()
            self._handled_requests.clear()
            self._requests_by_unique_key.clear()
            self._in_progress_requests.clear()

    @override
    async def purge(self) -> None:
        raise NotImplementedError("Purging request queues is not supported by the cloud backend. Use drop instead.")

    @override
    async def add_batch_of_requests(
        self,
        requests: Sequence[Request],
        *,
        forefront: bool = False,
    ) -> AddRequestsResponse:
        payload = [request.model_dump(by_alias=True) for request in requests]
        response = await self._api.request(
            "POST",
            f"/request-queues/{safe_resource_id(self._metadata.id)}/requests/batch",
            params={"clientKey": self._client_key, "forefront": forefront},
            json_body=payload,
        )
        processed = [ProcessedRequest.model_validate(item) for item in response.get("processedRequests", [])]
        unprocessed = [UnprocessedRequest.model_validate(item) for item in response.get("unprocessedRequests", [])]
        for request in requests:
            if not any(item.unique_key == request.unique_key for item in unprocessed):
                self._requests_by_unique_key[request.unique_key] = request
        self._metadata = await self.get_metadata()
        return AddRequestsResponse(processed_requests=processed, unprocessed_requests=unprocessed)

    @override
    async def fetch_next_request(self) -> Request | None:
        response = await self._api.request(
            "GET",
            f"/request-queues/{safe_resource_id(self._metadata.id)}/head",
            params={"clientKey": self._client_key, "limit": 100},
        )
        items = response.get("items", []) if response else []
        for item in items:
            request = Request.model_validate(item)
            if request.unique_key in self._in_progress_requests:
                continue
            if request.handled_at is not None:
                continue
            self._in_progress_requests[request.unique_key] = request
            self._requests_by_unique_key[request.unique_key] = request
            return request
        return None

    @override
    async def get_request(self, unique_key: str) -> Request | None:
        request_id = compute_request_id(unique_key)
        raw = await self._api.request(
            "GET",
            f"/request-queues/{safe_resource_id(self._metadata.id)}/requests/{request_id}",
            params={"clientKey": self._client_key},
        )
        return Request.model_validate(raw) if raw else None

    @override
    async def mark_request_as_handled(self, request: Request) -> ProcessedRequest | None:
        if request.handled_at is None:
            request.handled_at = datetime.now(timezone.utc)
        request_id = compute_request_id(request.unique_key)
        raw = await self._api.request(
            "PUT",
            f"/request-queues/{safe_resource_id(self._metadata.id)}/requests/{request_id}",
            params={"clientKey": self._client_key},
            json_body=request.model_dump(by_alias=True),
        )
        self._in_progress_requests.pop(request.unique_key, None)
        self._requests_by_unique_key[request.unique_key] = request
        self._metadata = await self.get_metadata()
        return ProcessedRequest.model_validate(raw) if raw else None

    @override
    async def reclaim_request(
        self,
        request: Request,
        *,
        forefront: bool = False,
    ) -> ProcessedRequest | None:
        request.handled_at = None
        request_id = compute_request_id(request.unique_key)
        raw = await self._api.request(
            "PUT",
            f"/request-queues/{safe_resource_id(self._metadata.id)}/requests/{request_id}",
            params={"clientKey": self._client_key, "forefront": forefront},
            json_body=request.model_dump(by_alias=True),
        )
        self._in_progress_requests.pop(request.unique_key, None)
        self._requests_by_unique_key[request.unique_key] = request
        self._metadata = await self.get_metadata()
        return ProcessedRequest.model_validate(raw) if raw else None

    @override
    async def is_empty(self) -> bool:
        response = await self._api.request(
            "GET",
            f"/request-queues/{safe_resource_id(self._metadata.id)}/head",
            params={"clientKey": self._client_key, "limit": 1},
        )
        items = response.get("items", []) if response else []
        if items:
            for item in items:
                if item.get("handledAt") is None:
                    return False
        return len(self._in_progress_requests) == 0


class CloudStorageClient(StorageClient):
    def __init__(self, *, request_queue_access: Literal["single", "shared"] = "single") -> None:
        self._request_queue_access = request_queue_access

    @override
    async def create_dataset_client(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        configuration: Configuration | None = None,
    ) -> CloudDatasetClient:
        configuration = configuration or Configuration.get_global_configuration()
        return await CloudDatasetClient.open(id=id, name=name, alias=alias, configuration=configuration)

    @override
    async def create_kvs_client(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        configuration: Configuration | None = None,
    ) -> CloudKeyValueStoreClient:
        configuration = configuration or Configuration.get_global_configuration()
        return await CloudKeyValueStoreClient.open(id=id, name=name, alias=alias, configuration=configuration)

    @override
    async def create_rq_client(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        configuration: Configuration | None = None,
    ) -> CloudRequestQueueClient:
        configuration = configuration or Configuration.get_global_configuration()
        return await CloudRequestQueueClient.open(id=id, name=name, alias=alias, configuration=configuration)

    @override
    def get_storage_client_cache_key(self, configuration: Configuration) -> object:
        return (
            f"{self.__class__.__module__}.{self.__class__.__name__}",
            hash_api_base_url_and_token(configuration.api_public_base_url, configuration.token or ""),
        )
