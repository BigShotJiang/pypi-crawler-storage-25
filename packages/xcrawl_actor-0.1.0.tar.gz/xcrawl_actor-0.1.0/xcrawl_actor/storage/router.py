from __future__ import annotations

from typing import Literal

from typing_extensions import override

from crawlee.storage_clients._base import DatasetClient, KeyValueStoreClient, RequestQueueClient, StorageClient

from ..configuration import Configuration
from .cloud import CloudStorageClient
from .local import LocalStorageClient


class SmartStorageClient(StorageClient):
    def __init__(
        self,
        *,
        cloud_storage_client: StorageClient | None = None,
        local_storage_client: StorageClient | None = None,
        request_queue_access: Literal["single", "shared"] = "single",
    ) -> None:
        self._cloud_storage_client = cloud_storage_client or CloudStorageClient(request_queue_access=request_queue_access)
        self._local_storage_client = local_storage_client or LocalStorageClient()

    def _get_default_storage_client(self, *, configuration: Configuration, force_cloud: bool = False) -> StorageClient:
        if configuration.is_at_home:
            return self._cloud_storage_client
        if force_cloud:
            if configuration.token is None:
                raise RuntimeError(
                    "Using cloud storage outside the platform requires a token in configuration or XCRAWL_TOKEN."
                )
            return self._cloud_storage_client
        return self._local_storage_client

    def _get_request_queue_storage_client(self, *, configuration: Configuration) -> StorageClient:
        backend = str(getattr(configuration, "request_queue_backend", "auto") or "auto").strip().lower()

        if backend == "local":
            return self._local_storage_client
        if backend == "cloud":
            return self._get_default_storage_client(configuration=configuration, force_cloud=True)
        if backend == "auto":
            # Platform runs currently use runtime APIs for actor lifecycle and input,
            # but request queue control-plane access is not always authorized. Keep
            # the queue local by default to avoid hard startup failures on `crawler.run(...)`.
            if configuration.is_at_home:
                return self._local_storage_client
            return self._get_default_storage_client(configuration=configuration, force_cloud=False)

        raise ValueError(
            f"Unsupported request_queue_backend={backend!r}. Expected one of: 'auto', 'local', 'cloud'."
        )

    def get_suitable_storage_client(self, *, force_cloud: bool = False) -> StorageClient:
        configuration = Configuration.get_global_configuration()
        return self._get_default_storage_client(configuration=configuration, force_cloud=force_cloud)

    @override
    def get_storage_client_cache_key(self, configuration: Configuration) -> object:
        return (
            f"{self.__class__.__module__}.{self.__class__.__name__}",
            self._cloud_storage_client.get_storage_client_cache_key(configuration),
            self._local_storage_client.get_storage_client_cache_key(configuration),
            bool(configuration.is_at_home),
            getattr(configuration, "request_queue_backend", "auto"),
        )

    @override
    async def create_dataset_client(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        configuration: Configuration | None = None,
    ) -> DatasetClient:
        configuration = configuration or Configuration.get_global_configuration()
        return await self._get_default_storage_client(
            configuration=configuration,
            force_cloud=configuration.is_at_home,
        ).create_dataset_client(
            id=id,
            name=name,
            alias=alias,
            configuration=configuration,
        )

    @override
    async def create_kvs_client(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        configuration: Configuration | None = None,
    ) -> KeyValueStoreClient:
        configuration = configuration or Configuration.get_global_configuration()
        return await self._get_default_storage_client(
            configuration=configuration,
            force_cloud=configuration.is_at_home,
        ).create_kvs_client(
            id=id,
            name=name,
            alias=alias,
            configuration=configuration,
        )

    @override
    async def create_rq_client(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        configuration: Configuration | None = None,
    ) -> RequestQueueClient:
        configuration = configuration or Configuration.get_global_configuration()
        return await self._get_request_queue_storage_client(configuration=configuration).create_rq_client(
            id=id,
            name=name,
            alias=alias,
            configuration=configuration,
        )
