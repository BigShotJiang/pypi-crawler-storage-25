from __future__ import annotations

import asyncio
import json
import logging
from itertools import chain
from pathlib import Path

from typing_extensions import override

from crawlee._consts import METADATA_FILENAME
from crawlee._utils.file import atomic_write, infer_mime_type, json_dumps
from crawlee.configuration import Configuration as CrawleeConfiguration
from crawlee.storage_clients import FileSystemStorageClient
from crawlee.storage_clients._file_system import FileSystemKeyValueStoreClient
from crawlee.storage_clients.models import KeyValueStoreMetadata, KeyValueStoreRecord, KeyValueStoreRecordMetadata

from ..configuration import Configuration

logger = logging.getLogger(__name__)


class LocalKeyValueStoreClient(FileSystemKeyValueStoreClient):
    def __init__(
        self,
        *,
        metadata: KeyValueStoreMetadata,
        path_to_kvs: Path,
        lock: asyncio.Lock,
    ) -> None:
        super().__init__(metadata=metadata, path_to_kvs=path_to_kvs, lock=lock)
        global_configuration = Configuration.get_global_configuration()
        self._input_key = global_configuration.input_key
        self._input_key_filename = global_configuration.input_key

    @override
    @classmethod
    async def open(
        cls,
        *,
        id: str | None,
        name: str | None,
        alias: str | None,
        configuration: CrawleeConfiguration,
    ) -> "LocalKeyValueStoreClient":
        client = await super().open(id=id, name=name, alias=alias, configuration=configuration)
        if isinstance(configuration, Configuration):
            client._input_key = configuration.input_key
            input_key_filename = cls._get_input_key_file_name(
                path_to_kvs=client.path_to_kvs,
                configuration=configuration,
            )
            client._input_key_filename = input_key_filename
            input_file_path = client.path_to_kvs / input_key_filename
            input_file_metadata_path = client.path_to_kvs / f"{input_key_filename}.{METADATA_FILENAME}"
            if input_file_path.exists() and not input_file_metadata_path.exists():
                await cls._create_missing_metadata_for_input_file(
                    key=configuration.input_key,
                    record_path=input_file_path,
                )
        return client

    @override
    async def purge(self) -> None:
        async with self._lock:
            files_to_keep = {
                self._input_key_filename,
                f"{self._input_key_filename}.{METADATA_FILENAME}",
                METADATA_FILENAME,
            }
            for file_path in self.path_to_kvs.glob("*"):
                if file_path.name in files_to_keep:
                    continue
                if file_path.is_file():
                    await asyncio.to_thread(file_path.unlink, missing_ok=True)
            await self._update_metadata(update_accessed_at=True, update_modified_at=True)

    @override
    async def get_value(self, *, key: str) -> KeyValueStoreRecord | None:
        if key == self._input_key:
            key = self._input_key_filename
        return await super().get_value(key=key)

    @staticmethod
    async def _create_missing_metadata_for_input_file(key: str, record_path: Path) -> None:
        try:
            content = await asyncio.to_thread(record_path.read_bytes)
        except FileNotFoundError:
            logger.warning("Input file disappeared before metadata creation: %s", record_path)
            return

        size = len(content)
        if record_path.suffix == ".json":
            value = json.loads(content.decode("utf-8"))
        elif record_path.suffix == ".txt":
            value = content.decode("utf-8")
        elif record_path.suffix == "":
            try:
                value = json.loads(content.decode("utf-8"))
            except json.JSONDecodeError:
                value = content
        else:
            value = content

        record_metadata = KeyValueStoreRecordMetadata(
            key=key,
            content_type=infer_mime_type(value),
            size=size,
        )
        await atomic_write(
            record_path.with_name(f"{record_path.name}.{METADATA_FILENAME}"),
            await json_dumps(record_metadata.model_dump()),
        )

    @staticmethod
    def _get_input_key_file_name(path_to_kvs: Path, configuration: Configuration) -> str:
        found_input_files = set()
        for file_path in chain(path_to_kvs.glob(f"{configuration.input_key}.*"), path_to_kvs.glob(configuration.input_key)):
            if str(file_path).endswith(METADATA_FILENAME):
                continue
            found_input_files.add(file_path.name)
        if len(found_input_files) > 1:
            raise RuntimeError(f"Only one input file is allowed, found: {sorted(found_input_files)}")
        if len(found_input_files) == 1:
            return found_input_files.pop()
        return configuration.input_key


class LocalStorageClient(FileSystemStorageClient):
    @override
    def get_storage_client_cache_key(self, configuration: CrawleeConfiguration) -> object:
        return FileSystemStorageClient().get_storage_client_cache_key(configuration)

    @override
    async def create_kvs_client(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        configuration: CrawleeConfiguration | None = None,
    ) -> FileSystemKeyValueStoreClient:
        configuration = configuration or Configuration.get_global_configuration()
        client = await LocalKeyValueStoreClient.open(
            id=id,
            name=name,
            alias=alias,
            configuration=configuration,
        )
        await self._purge_if_needed(client, configuration)
        return client
