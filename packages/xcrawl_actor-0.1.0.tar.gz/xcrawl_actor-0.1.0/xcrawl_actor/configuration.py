from __future__ import annotations

import json
import os
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Annotated, Any, Literal

from pydantic import AliasChoices, BeforeValidator, Field

from crawlee.configuration import Configuration as CrawleeConfiguration


def _transform_to_list(value: Any) -> list[str] | None:
    if value is None:
        return None
    if not value:
        return []
    return value if isinstance(value, list) else str(value).split(",")


def _load_storage_keys(data: None | str | dict[str, Any]) -> dict[str, dict[str, str]] | None:
    if data is None:
        return None
    storage_mapping = json.loads(data) if isinstance(data, str) else data
    return {
        "key_value_stores": storage_mapping.get("keyValueStores", storage_mapping.get("key_value_stores", {})),
        "datasets": storage_mapping.get("datasets", {}),
        "request_queues": storage_mapping.get("requestQueues", storage_mapping.get("request_queues", {})),
    }


class Configuration(CrawleeConfiguration):
    actor_id: Annotated[
        str | None,
        Field(validation_alias=AliasChoices("actor_id", "xcrawl_actor_id", "xcrawl_act_id", "apify_actor_id", "apify_act_id")),
    ] = None
    actor_full_name: str | None = None
    actor_permission_level: str | None = None
    actor_run_id: Annotated[
        str | None,
        Field(
            validation_alias=AliasChoices(
                "actor_run_id",
                "xcrawl_actor_run_id",
                "xcrawl_act_run_id",
                "apify_actor_run_id",
                "apify_act_run_id",
            )
        ),
    ] = None
    actor_build_id: Annotated[
        str | None,
        Field(validation_alias=AliasChoices("actor_build_id", "xcrawl_actor_build_id", "apify_actor_build_id")),
    ] = None
    actor_build_number: Annotated[
        str | None,
        Field(validation_alias=AliasChoices("actor_build_number", "xcrawl_actor_build_number", "apify_actor_build_number")),
    ] = None
    actor_build_tags: Annotated[list[str] | None, BeforeValidator(_transform_to_list)] = None
    actor_task_id: Annotated[
        str | None,
        Field(validation_alias=AliasChoices("actor_task_id", "xcrawl_actor_task_id", "apify_actor_task_id")),
    ] = None
    actor_events_ws_url: Annotated[
        str | None,
        Field(
            validation_alias=AliasChoices(
                "actor_events_websocket_url",
                "xcrawl_actor_events_ws_url",
                "apify_actor_events_ws_url",
            )
        ),
    ] = None
    api_base_url: Annotated[
        str,
        Field(validation_alias=AliasChoices("xcrawl_api_base_url", "apify_api_base_url")),
    ] = "https://api.xcrawl.com"
    api_public_base_url: Annotated[
        str,
        Field(validation_alias=AliasChoices("xcrawl_api_public_base_url", "apify_api_public_base_url")),
    ] = "https://api.xcrawl.com"
    default_dataset_id: Annotated[
        str | None,
        Field(
            validation_alias=AliasChoices(
                "actor_default_dataset_id",
                "xcrawl_default_dataset_id",
                "apify_default_dataset_id",
            )
        ),
    ] = None
    default_key_value_store_id: Annotated[
        str | None,
        Field(
            validation_alias=AliasChoices(
                "actor_default_key_value_store_id",
                "xcrawl_default_key_value_store_id",
                "apify_default_key_value_store_id",
            )
        ),
    ] = None
    default_request_queue_id: Annotated[
        str | None,
        Field(
            validation_alias=AliasChoices(
                "actor_default_request_queue_id",
                "xcrawl_default_request_queue_id",
                "apify_default_request_queue_id",
            )
        ),
    ] = None
    request_queue_backend: Annotated[
        Literal["auto", "local", "cloud"],
        Field(validation_alias=AliasChoices("xcrawl_request_queue_backend", "apify_request_queue_backend")),
    ] = "auto"
    input_key: Annotated[
        str,
        Field(validation_alias=AliasChoices("actor_input_key", "xcrawl_input_key", "apify_input_key", "crawlee_input_key")),
    ] = "INPUT"
    is_at_home: Annotated[
        bool,
        Field(validation_alias=AliasChoices("xcrawl_is_at_home", "apify_is_at_home")),
    ] = False
    token: Annotated[
        str | None,
        Field(validation_alias=AliasChoices("xcrawl_token", "apify_token")),
    ] = None
    user_id: Annotated[
        str | None,
        Field(validation_alias=AliasChoices("xcrawl_user_id", "apify_user_id")),
    ] = None
    proxy_hostname: Annotated[
        str,
        Field(validation_alias=AliasChoices("xcrawl_proxy_hostname", "apify_proxy_hostname")),
    ] = "proxy.xcrawl.com"
    proxy_port: Annotated[
        int,
        Field(validation_alias=AliasChoices("xcrawl_proxy_port", "apify_proxy_port")),
    ] = 8000
    proxy_password: Annotated[
        str | None,
        Field(validation_alias=AliasChoices("xcrawl_proxy_password", "apify_proxy_password")),
    ] = None
    proxy_status_url: Annotated[
        str,
        Field(validation_alias=AliasChoices("xcrawl_proxy_status_url", "apify_proxy_status_url")),
    ] = "http://proxy.xcrawl.com"
    metamorph_after_sleep: Annotated[
        timedelta,
        Field(validation_alias=AliasChoices("xcrawl_metamorph_after_sleep_millis", "apify_metamorph_after_sleep_millis")),
        BeforeValidator(
            lambda value: (
                value
                if isinstance(value, timedelta)
                else timedelta(milliseconds=int(value))
                if value not in (None, "")
                else timedelta(minutes=5)
            )
        ),
    ] = timedelta(minutes=5)
    timeout_at: Annotated[
        datetime | None,
        Field(validation_alias=AliasChoices("actor_timeout_at", "xcrawl_timeout_at", "apify_timeout_at")),
        BeforeValidator(lambda value: value if value != "" else None),
    ] = None
    started_at: Annotated[
        datetime | None,
        Field(validation_alias=AliasChoices("actor_started_at", "xcrawl_started_at", "apify_started_at")),
        BeforeValidator(lambda value: value if value != "" else None),
    ] = None
    max_paid_dataset_items: Annotated[
        int | None,
        Field(alias="actor_max_paid_dataset_items"),
        BeforeValidator(lambda value: value if value != "" else None),
    ] = None
    max_total_charge_usd: Annotated[
        Decimal | None,
        Field(alias="actor_max_total_charge_usd"),
        BeforeValidator(lambda value: value if value != "" else None),
    ] = None
    web_server_port: Annotated[
        int,
        Field(validation_alias=AliasChoices("actor_web_server_port", "xcrawl_container_port", "apify_container_port")),
    ] = 4321
    web_server_url: Annotated[
        str,
        Field(validation_alias=AliasChoices("actor_web_server_url", "xcrawl_container_url", "apify_container_url")),
    ] = "http://localhost:4321"
    storage_dir: Annotated[
        str,
        Field(validation_alias=AliasChoices("xcrawl_local_storage_dir", "apify_local_storage_dir", "crawlee_storage_dir")),
    ] = "./storage"
    actor_storages: Annotated[
        dict[str, dict[str, str]] | None,
        Field(validation_alias=AliasChoices("actor_storages_json", "xcrawl_actor_storages_json")),
        BeforeValidator(_load_storage_keys),
    ] = None

    @classmethod
    def from_runtime_env(cls, *, storage_dir: str | Path | None = None) -> "Configuration":
        """Build a configuration instance from the runtime env contract used by xcrawl containers."""
        values: dict[str, Any] = {}

        runtime_field_map = {
            "XCRAWL_RUN_ID": "actor_run_id",
            # Run token is the closest xcrawl runtime equivalent to the API token
            # consumed by storage clients and remote Actor helpers.
            "XCRAWL_RUN_TOKEN": "token",
            "XCRAWL_API_BASE_URL": "api_base_url",
            "XCRAWL_DEFAULT_DATASET_ID": "default_dataset_id",
            "XCRAWL_DEFAULT_KV_STORE_ID": "default_key_value_store_id",
            "XCRAWL_DEFAULT_REQUEST_QUEUE_ID": "default_request_queue_id",
            "XCRAWL_REQUEST_QUEUE_BACKEND": "request_queue_backend",
            "XCRAWL_TIMEOUT_AT": "timeout_at",
            "XCRAWL_MEMORY_LIMIT": "memory_mbytes",
            "XCRAWL_IS_AT_HOME": "is_at_home",
            "XCRAWL_EVENTS_WS_URL": "actor_events_ws_url",
        }

        for env_key, field_name in runtime_field_map.items():
            env_value = os.getenv(env_key)
            if env_value in (None, ""):
                continue
            values[field_name] = env_value

        if "api_base_url" in values and "api_public_base_url" not in values:
            values["api_public_base_url"] = values["api_base_url"]

        if storage_dir is not None and "storage_dir" not in values:
            values["storage_dir"] = str(Path(storage_dir))

        return cls(**values)

    @classmethod
    def default_for_local(cls, storage_dir: str | Path) -> "Configuration":
        return cls(
            storage_dir=str(Path(storage_dir)),
            purge_on_start=True,
            is_at_home=False,
        )
