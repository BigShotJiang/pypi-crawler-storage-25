from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Annotated, Literal

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field


class WebhookEventType(StrEnum):
    ACTOR_RUN_CREATED = "ACTOR.RUN.CREATED"
    ACTOR_RUN_SUCCEEDED = "ACTOR.RUN.SUCCEEDED"
    ACTOR_RUN_FAILED = "ACTOR.RUN.FAILED"
    ACTOR_RUN_TIMED_OUT = "ACTOR.RUN.TIMED_OUT"
    ACTOR_RUN_ABORTED = "ACTOR.RUN.ABORTED"
    ACTOR_RUN_RESURRECTED = "ACTOR.RUN.RESURRECTED"
    ACTOR_BUILD_CREATED = "ACTOR.BUILD.CREATED"
    ACTOR_BUILD_SUCCEEDED = "ACTOR.BUILD.SUCCEEDED"
    ACTOR_BUILD_FAILED = "ACTOR.BUILD.FAILED"
    ACTOR_BUILD_TIMED_OUT = "ACTOR.BUILD.TIMED_OUT"
    ACTOR_BUILD_ABORTED = "ACTOR.BUILD.ABORTED"


class ActorJobStatus(StrEnum):
    READY = "READY"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    TIMING_OUT = "TIMING-OUT"
    TIMED_OUT = "TIMED-OUT"
    ABORTING = "ABORTING"
    ABORTED = "ABORTED"


WebhookDispatchStatus = Literal["ACTIVE", "SUCCEEDED", "FAILED"]


class WebhookCondition(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    actor_id: Annotated[str | None, Field(alias="actorId")] = None
    actor_task_id: Annotated[str | None, Field(alias="actorTaskId")] = None
    actor_run_id: Annotated[str | None, Field(alias="actorRunId")] = None


class ExampleWebhookDispatch(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    status: WebhookDispatchStatus
    finished_at: Annotated[datetime, Field(alias="finishedAt")]


class WebhookStats(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    total_dispatches: Annotated[int, Field(alias="totalDispatches")]


def _validate_http_url(value: str) -> str:
    if not value.startswith(("http://", "https://")):
        raise ValueError("URL must start with http:// or https://")
    return value


class Webhook(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    event_types: Annotated[list[WebhookEventType], Field(alias="eventTypes")]
    request_url: Annotated[str, BeforeValidator(_validate_http_url), Field(alias="requestUrl")]
    id: Annotated[str | None, Field(alias="id")] = None
    created_at: Annotated[datetime | None, Field(alias="createdAt")] = None
    modified_at: Annotated[datetime | None, Field(alias="modifiedAt")] = None
    user_id: Annotated[str | None, Field(alias="userId")] = None
    is_ad_hoc: Annotated[bool | None, Field(alias="isAdHoc")] = None
    should_interpolate_strings: Annotated[bool | None, Field(alias="shouldInterpolateStrings")] = None
    condition: Annotated[WebhookCondition | None, Field(alias="condition")] = None
    ignore_ssl_errors: Annotated[bool | None, Field(alias="ignoreSslErrors")] = None
    do_not_retry: Annotated[bool | None, Field(alias="doNotRetry")] = None
    payload_template: Annotated[str | None, Field(alias="payloadTemplate")] = None
    headers_template: Annotated[str | None, Field(alias="headersTemplate")] = None
    description: Annotated[str | None, Field(alias="description")] = None
    last_dispatch: Annotated[ExampleWebhookDispatch | None, Field(alias="lastDispatch")] = None
    stats: Annotated[WebhookStats | None, Field(alias="stats")] = None


class ActorRunMeta(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    origin: Annotated[str | None, Field(alias="origin")] = None
    client_ip: Annotated[str | None, Field(alias="clientIp")] = None
    user_agent: Annotated[str | None, Field(alias="userAgent")] = None
    schedule_id: Annotated[str | None, Field(alias="scheduleId")] = None
    scheduled_at: Annotated[datetime | None, Field(alias="scheduledAt")] = None


class ActorRunStats(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    input_body_len: Annotated[int | None, Field(alias="inputBodyLen")] = None
    migration_count: Annotated[int | None, Field(alias="migrationCount")] = None
    reboot_count: Annotated[int | None, Field(alias="rebootCount")] = None
    restart_count: Annotated[int | None, Field(alias="restartCount")] = None
    resurrect_count: Annotated[int | None, Field(alias="resurrectCount")] = None
    mem_avg_bytes: Annotated[float | None, Field(alias="memAvgBytes")] = None
    mem_max_bytes: Annotated[int | None, Field(alias="memMaxBytes")] = None
    mem_current_bytes: Annotated[int | None, Field(alias="memCurrentBytes")] = None
    cpu_avg_usage: Annotated[float | None, Field(alias="cpuAvgUsage")] = None
    cpu_max_usage: Annotated[float | None, Field(alias="cpuMaxUsage")] = None
    cpu_current_usage: Annotated[float | None, Field(alias="cpuCurrentUsage")] = None
    net_rx_bytes: Annotated[int | None, Field(alias="netRxBytes")] = None
    net_tx_bytes: Annotated[int | None, Field(alias="netTxBytes")] = None
    duration_millis: Annotated[int | None, Field(alias="durationMillis")] = None
    run_time_secs: Annotated[float | None, Field(alias="runTimeSecs")] = None
    metamorph: Annotated[int | None, Field(alias="metamorph")] = None
    compute_units: Annotated[float | None, Field(alias="computeUnits")] = None


class ActorRunOptions(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    build: Annotated[str | None, Field(alias="build")] = None
    timeout_secs: Annotated[int | None, Field(alias="timeoutSecs")] = None
    memory_mbytes: Annotated[int | None, Field(alias="memoryMbytes")] = None
    disk_mbytes: Annotated[int | None, Field(alias="diskMbytes")] = None
    max_items: Annotated[int | None, Field(alias="maxItems")] = None
    max_total_charge_usd: Annotated[float | None, Field(alias="maxTotalChargeUsd")] = None


class ActorRunUsage(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    actor_compute_units: Annotated[float | None, Field(alias="ACTOR_COMPUTE_UNITS")] = None
    dataset_reads: Annotated[int | None, Field(alias="DATASET_READS")] = None
    dataset_writes: Annotated[int | None, Field(alias="DATASET_WRITES")] = None
    key_value_store_reads: Annotated[int | None, Field(alias="KEY_VALUE_STORE_READS")] = None
    key_value_store_writes: Annotated[int | None, Field(alias="KEY_VALUE_STORE_WRITES")] = None
    key_value_store_lists: Annotated[int | None, Field(alias="KEY_VALUE_STORE_LISTS")] = None
    request_queue_reads: Annotated[int | None, Field(alias="REQUEST_QUEUE_READS")] = None
    request_queue_writes: Annotated[int | None, Field(alias="REQUEST_QUEUE_WRITES")] = None


class ActorRunUsageUsd(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    actor_compute_units: Annotated[float | None, Field(alias="ACTOR_COMPUTE_UNITS")] = None
    dataset_reads: Annotated[float | None, Field(alias="DATASET_READS")] = None
    dataset_writes: Annotated[float | None, Field(alias="DATASET_WRITES")] = None
    key_value_store_reads: Annotated[float | None, Field(alias="KEY_VALUE_STORE_READS")] = None
    key_value_store_writes: Annotated[float | None, Field(alias="KEY_VALUE_STORE_WRITES")] = None
    key_value_store_lists: Annotated[float | None, Field(alias="KEY_VALUE_STORE_LISTS")] = None
    request_queue_reads: Annotated[float | None, Field(alias="REQUEST_QUEUE_READS")] = None
    request_queue_writes: Annotated[float | None, Field(alias="REQUEST_QUEUE_WRITES")] = None


class MetamorphInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    created_at: Annotated[datetime | None, Field(alias="createdAt")] = None
    actor_id: Annotated[str | None, Field(alias="actorId")] = None
    build_id: Annotated[str | None, Field(alias="buildId")] = None
    input_key: Annotated[str | None, Field(alias="inputKey")] = None


class ActorRun(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: Annotated[str, Field(alias="id")]
    act_id: Annotated[str | None, Field(alias="actId")] = None
    user_id: Annotated[str | None, Field(alias="userId")] = None
    actor_task_id: Annotated[str | None, Field(alias="actorTaskId")] = None
    started_at: Annotated[datetime | None, Field(alias="startedAt")] = None
    finished_at: Annotated[datetime | None, Field(alias="finishedAt")] = None
    status: Annotated[ActorJobStatus | None, Field(alias="status")] = None
    status_message: Annotated[str | None, Field(alias="statusMessage")] = None
    is_status_message_terminal: Annotated[bool | None, Field(alias="isStatusMessageTerminal")] = None
    meta: Annotated[ActorRunMeta | None, Field(alias="meta")] = None
    stats: Annotated[ActorRunStats | None, Field(alias="stats")] = None
    options: Annotated[ActorRunOptions | None, Field(alias="options")] = None
    build_id: Annotated[str | None, Field(alias="buildId")] = None
    exit_code: Annotated[int | None, Field(alias="exitCode")] = None
    general_access: Annotated[str | None, Field(alias="generalAccess")] = None
    default_key_value_store_id: Annotated[str | None, Field(alias="defaultKeyValueStoreId")] = None
    default_dataset_id: Annotated[str | None, Field(alias="defaultDatasetId")] = None
    default_request_queue_id: Annotated[str | None, Field(alias="defaultRequestQueueId")] = None
    build_number: Annotated[str | None, Field(alias="buildNumber")] = None
    container_url: Annotated[str | None, Field(alias="containerUrl")] = None
    is_container_server_ready: Annotated[bool | None, Field(alias="isContainerServerReady")] = None
    git_branch_name: Annotated[str | None, Field(alias="gitBranchName")] = None
    usage: Annotated[ActorRunUsage | None, Field(alias="usage")] = None
    usage_total_usd: Annotated[float | None, Field(alias="usageTotalUsd")] = None
    usage_usd: Annotated[ActorRunUsageUsd | None, Field(alias="usageUsd")] = None
    charged_event_counts: Annotated[dict[str, int] | None, Field(alias="chargedEventCounts")] = None
    metamorphs: Annotated[list[MetamorphInfo] | None, Field(alias="metamorphs")] = None
