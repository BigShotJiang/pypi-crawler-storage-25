from __future__ import annotations

import base64
import hashlib
import json
import re
from datetime import datetime
from typing import Any


def utcnow() -> datetime:
    return datetime.utcnow().astimezone()


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=_json_default)


def json_dumps_pretty(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, default=_json_default)


def json_loads_if_possible(value: str | bytes) -> Any:
    raw = value.decode("utf-8") if isinstance(value, bytes) else value
    try:
        return json.loads(raw)
    except Exception:
        return raw


def filter_out_none_values_recursively(value: Any) -> Any:
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            filtered = filter_out_none_values_recursively(item)
            if filtered is not None:
                result[key] = filtered
        return result or None
    if isinstance(value, list):
        return [item for item in (filter_out_none_values_recursively(item) for item in value) if item is not None]
    return value


def safe_resource_id(resource_id: str) -> str:
    return resource_id.replace("/", "~")


def compute_request_id(unique_key: str, *, request_id_length: int = 15) -> str:
    hashed = hashlib.sha256(unique_key.encode("utf-8")).digest()
    encoded = base64.b64encode(hashed).decode("utf-8")
    url_safe = re.sub(r"(\+|/|=)", "", encoded)
    return url_safe[:request_id_length]


def hash_api_base_url_and_token(api_public_base_url: str, token: str) -> str:
    digest = hashlib.sha256(f"{api_public_base_url}{token}".encode("utf-8")).hexdigest()
    return digest[:16]


def encode_body(value: Any, content_type: str | None = None) -> tuple[Any, str]:
    if not content_type:
        if isinstance(value, str):
            content_type = "text/plain; charset=utf-8"
        elif isinstance(value, (bytes, bytearray)):
            content_type = "application/octet-stream"
        else:
            content_type = "application/json; charset=utf-8"

    if "application/json" in content_type and value is not None and not isinstance(value, (str, bytes, bytearray)):
        value = json_dumps_pretty(value).encode("utf-8")

    return value, content_type


def parse_datetime(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return value
    if isinstance(value, list):
        return [parse_datetime(item) for item in value]
    if isinstance(value, dict):
        return {key: parse_datetime(item) for key, item in value.items()}
    return value


def _json_default(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if hasattr(value, "model_dump"):
        return value.model_dump(by_alias=True, exclude_none=True)
    if hasattr(value, "dict"):
        return value.dict()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")
