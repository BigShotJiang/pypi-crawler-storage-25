from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import traceback
from contextlib import suppress
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from functools import cached_property
from pathlib import Path
from typing import Any, Literal, cast

from lazy_object_proxy import Proxy

from crawlee import service_locator
from crawlee.errors import ServiceConflictError
from crawlee.events import (
    Event,
    EventListener,
    EventMigratingData,
    EventPersistStateData,
    LocalEventManager,
)
from crawlee.storages import Dataset, KeyValueStore, RequestQueue

from .client import XcrawlApiClientAsync, maybe_parse_actor_run
from .configuration import Configuration
from .consts import DEFAULT_LOGGER_NAME, DEFAULT_STATE_KEY
from .models import ActorRun, Webhook
from .storage import SmartStorageClient
from .utils import safe_resource_id

EVENT_LISTENERS_TIMEOUT = timedelta(seconds=5)
_LOG_LEVEL_KWARG_NAMES = ("debug", "info", "warning", "warn", "error", "critical", "exception")


@dataclass(slots=True)
class _PreparedLogRecord:
    message: str
    level_name: str
    level_number: int
    stream: Literal["stdout", "stderr"]
    metadata: dict[str, Any]
    run_id: str | None


class _ActorLogProxy:
    """Callable logger facade that keeps the standard logger-style API."""

    def __init__(self, actor: "_ActorType") -> None:
        self._actor = actor

    def __call__(
        self,
        message: Any | None = None,
        *args: Any,
        level: str | int = "info",
        stream: str | None = None,
        metadata: dict[str, Any] | None = None,
        exc_info: Any = None,
        **logger_kwargs: Any,
    ) -> None:
        keyword_level = None
        keyword_message = None
        for level_name in _LOG_LEVEL_KWARG_NAMES:
            if level_name in logger_kwargs:
                if keyword_level is not None:
                    raise TypeError(
                        "Actor.log() received multiple level-specific keyword messages. "
                        "Use exactly one of debug/info/warning/warn/error/critical/exception."
                    )
                keyword_level = level_name
                keyword_message = logger_kwargs.pop(level_name)

        if keyword_level is not None:
            if message is not None or args:
                raise TypeError(
                    "Actor.log() cannot mix a positional message with level-specific keyword messages. "
                    "Use Actor.log('message'), Actor.log.info('message'), or Actor.log(info='message')."
                )
            message = keyword_message
            if keyword_level == "warn":
                level = "warning"
            elif keyword_level == "exception":
                level = "error"
                if exc_info is None:
                    exc_info = True
            else:
                level = keyword_level

        if message is None:
            raise TypeError(
                "Actor.log() missing required message. "
                "Use Actor.log('message'), Actor.log.info('message'), or Actor.log(info='message')."
            )

        self._actor._dispatch_log(
            message,
            *args,
            level=level,
            stream=stream,
            metadata=metadata,
            exc_info=exc_info,
            **logger_kwargs,
        )

    def debug(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self(message, *args, level="debug", **kwargs)

    def info(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self(message, *args, level="info", **kwargs)

    def warning(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self(message, *args, level="warning", **kwargs)

    def warn(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self.warning(message, *args, **kwargs)

    def error(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self(message, *args, level="error", **kwargs)

    def critical(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self(message, *args, level="critical", **kwargs)

    def exception(self, message: Any, *args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("exc_info", True)
        kwargs.setdefault("stream", "stderr")
        self(message, *args, level="error", **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._actor._local_logger, name)


class _ActorType:
    """Actor-style runtime facade built on top of Crawlee services and xcrawl backends."""

    def __init__(
        self,
        configuration: Configuration | None = None,
        *,
        configure_logging: bool = True,
        exit_process: bool | None = None,
        exit_code: int = 0,
        status_message: str | None = None,
        event_listeners_timeout: timedelta | None = EVENT_LISTENERS_TIMEOUT,
        cleanup_timeout: timedelta = timedelta(seconds=30),
        request_queue_access: Literal["single", "shared"] = "single",
    ) -> None:
        # Keep the raw constructor inputs untouched.
        #
        # The class is designed to lazily initialize expensive resources, so these
        # values act as the source of truth until the runtime actually starts.
        self._configuration = configuration
        self._configure_logging = configure_logging

        # Exit-related knobs are stored immediately because they influence both
        # normal shutdown and exception-driven shutdown paths.
        self._exit_process = self._get_default_exit_process() if exit_process is None else exit_process
        self._exit_code = exit_code
        self._status_message = status_message
        self._event_listeners_timeout = event_listeners_timeout
        self._cleanup_timeout = cleanup_timeout
        self._request_queue_access = request_queue_access

        # Lifecycle flags are intentionally explicit.
        #
        # This makes shutdown and reboot code easier to reason about and gives the
        # logging path a reliable way to describe the current actor state.
        self._active = False
        self._is_exiting = False
        self._is_rebooting = False

        # Network and storage resources are created on demand.
        #
        # Keeping them lazy avoids doing unnecessary work for short-lived scripts
        # that import Actor helpers but never actually touch the related services.
        self._xcrawl_client: XcrawlApiClientAsync | None = None
        self._use_state_stores: set[str | None] = set()
        self._pending_log_tasks: set[asyncio.Task[Any]] = set()

    def __repr__(self) -> str:
        if self is cast("Proxy", Actor).__wrapped__:
            return "<xcrawl.Actor>"
        return super().__repr__()

    def __call__(
        self,
        configuration: Configuration | None = None,
        *,
        configure_logging: bool = True,
        exit_process: bool | None = None,
        exit_code: int = 0,
        event_listeners_timeout: timedelta | None = EVENT_LISTENERS_TIMEOUT,
        status_message: str | None = None,
        cleanup_timeout: timedelta = timedelta(seconds=30),
        request_queue_access: Literal["single", "shared"] = "single",
    ) -> "_ActorType":
        # `Actor(...)` creates a fresh runtime instance while the module-level `Actor`
        # object remains a lazy proxy to the currently active instance.
        return self.__class__(
            configuration=configuration,
            configure_logging=configure_logging,
            exit_process=exit_process,
            exit_code=exit_code,
            event_listeners_timeout=event_listeners_timeout,
            status_message=status_message,
            cleanup_timeout=cleanup_timeout,
            request_queue_access=request_queue_access,
        )

    @cached_property
    def _local_logger(self) -> logging.Logger:
        return logging.getLogger(DEFAULT_LOGGER_NAME)

    @cached_property
    def log(self) -> _ActorLogProxy:
        return _ActorLogProxy(self)

    @property
    def exit_code(self) -> int:
        return self._exit_code

    @exit_code.setter
    def exit_code(self, value: int) -> None:
        self._exit_code = value

    @property
    def status_message(self) -> str | None:
        return self._status_message

    @status_message.setter
    def status_message(self, value: str | None) -> None:
        self._status_message = value

    @property
    def xcrawl_client(self) -> XcrawlApiClientAsync:
        if not self._xcrawl_client:
            self._xcrawl_client = self.new_client()
        return self._xcrawl_client

    @property
    def apify_client(self) -> XcrawlApiClientAsync:
        """Backward-compatible alias."""
        return self.xcrawl_client

    @cached_property
    def configuration(self) -> Configuration:
        if self._configuration:
            self._local_logger.debug("Using explicit Actor configuration instance provided by the caller.")
            return self._configuration
        try:
            # Prefer the explicit xcrawl runtime env contract when bootstrapping the
            # default configuration for containerized runs.
            implicit_configuration = Configuration.from_runtime_env(storage_dir=self._default_storage_dir())
            service_locator.set_configuration(implicit_configuration)
            self._configuration = implicit_configuration
            self._local_logger.info(
                "Actor configuration initialized from runtime environment. storage_dir=%s",
                self._default_storage_dir(),
            )
        except ServiceConflictError:
            self._local_logger.debug(
                "Configuration service was already registered. Reusing the global configuration instance."
            )
            self._configuration = Configuration.get_global_configuration()
        self._configuration = Configuration.get_global_configuration()
        self._local_logger.debug(
            "Actor configuration resolved. is_at_home=%s actor_run_id_present=%s default_dataset_id=%r "
            "default_key_value_store_id=%r default_request_queue_id=%r request_queue_backend=%r",
            bool(self._configuration.is_at_home),
            bool(self._configuration.actor_run_id),
            self._configuration.default_dataset_id,
            self._configuration.default_key_value_store_id,
            self._configuration.default_request_queue_id,
            self._configuration.request_queue_backend,
        )
        return self._configuration

    @cached_property
    def event_manager(self) -> LocalEventManager:
        try:
            # Reuse Crawlee's local event system so migration/persist-state hooks work
            # the same way for users building routers and background listeners.
            event_manager = LocalEventManager.from_config(config=self.configuration)
            service_locator.set_event_manager(event_manager)
            self._local_logger.debug("Created and registered a new LocalEventManager for the Actor runtime.")
        except ServiceConflictError:
            self._local_logger.debug("Event manager service already exists. Reusing the registered LocalEventManager.")
            event_manager = cast(LocalEventManager, service_locator.get_event_manager())
        return event_manager

    @cached_property
    def _storage_client(self) -> SmartStorageClient:
        try:
            # Route storage to local files or cloud APIs behind one client so the Actor
            # helpers can stay agnostic to where the run is currently executing.
            storage_client = SmartStorageClient(request_queue_access=self._request_queue_access)
            service_locator.set_storage_client(storage_client)
            self._local_logger.debug(
                "Created SmartStorageClient for Actor runtime. request_queue_access=%s",
                self._request_queue_access,
            )
        except ServiceConflictError:
            self._local_logger.debug("Storage client service already exists. Reusing the registered storage client.")
            storage_client = cast(SmartStorageClient, service_locator.get_storage_client())
        return storage_client

    def _bootstrap_configuration_service(self) -> None:
        """Ensure the configuration service is resolved before other services start."""
        if self._configuration:
            self._local_logger.debug(
                "Bootstrapping Actor with an explicit configuration object. Registering it in the service locator."
            )
            try:
                service_locator.set_configuration(self.configuration)
                self._local_logger.debug("Explicit Actor configuration registered successfully.")
            except ServiceConflictError:
                self._local_logger.debug(
                    "Configuration service was already initialized. Keeping the existing registration."
                )
            return

        self._local_logger.debug(
            "Bootstrapping Actor without an explicit configuration. Resolving configuration lazily."
        )
        _ = self.configuration

    def _configure_root_logging_if_requested(self) -> None:
        """Configure process-wide logging only when this Actor instance is responsible for it."""
        if not self._configure_logging:
            self._local_logger.debug("Actor logging auto-configuration is disabled for this instance.")
            return

        requested_level_name = str(self.configuration.log_level).upper()
        resolved_level = getattr(logging, requested_level_name, logging.INFO)

        # `basicConfig()` is intentionally still used here because the original API
        # relied on Python's standard one-shot logging bootstrap semantics.
        logging.basicConfig(
            level=resolved_level,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )
        self._local_logger.debug(
            "Actor root logging configured. requested_level=%s resolved_level=%s",
            requested_level_name,
            logging.getLevelName(resolved_level),
        )

    def _bind_global_actor_proxy(self) -> Any:
        """Point the module-level `Actor` proxy at this live runtime instance."""
        actor_proxy = cast("Proxy", Actor)
        previous_target = getattr(actor_proxy, "__wrapped__", None)
        actor_proxy.__wrapped__ = self
        self._local_logger.debug(
            "Module-level Actor proxy bound to the active runtime instance. previous_target_type=%s",
            type(previous_target).__name__ if previous_target is not None else None,
        )
        return previous_target

    def _restore_global_actor_proxy(self, previous_target: Any) -> None:
        """Restore the proxy target if initialization fails part-way through startup."""
        actor_proxy = cast("Proxy", Actor)
        actor_proxy.__wrapped__ = previous_target
        self._local_logger.debug(
            "Module-level Actor proxy restored after initialization failure. restored_target_type=%s",
            type(previous_target).__name__ if previous_target is not None else None,
        )

    async def __aenter__(self) -> "_ActorType":
        if self._active:
            raise RuntimeError("The Actor was already initialized!")

        self._local_logger.info(
            "Entering Actor context. configure_logging=%s exit_process=%s request_queue_access=%s",
            self._configure_logging,
            self._exit_process,
            self._request_queue_access,
        )

        previous_proxy_target: Any = None

        try:
            # Configuration must be available before storage and event services are
            # touched because those services derive their behavior from it.
            self._bootstrap_configuration_service()

            # Logging is configured before the remaining initialization steps so any
            # failure below is captured with the expected formatting and level.
            self._configure_root_logging_if_requested()

            # Switch the module-level lazy proxy to the concrete active instance so
            # calls like `Actor.push_data()` inside the context resolve to this runtime.
            previous_proxy_target = self._bind_global_actor_proxy()

            # Force lazy services to initialize now instead of half-way through user
            # code execution. That keeps startup failures concentrated in one place.
            _ = self._storage_client
            await self.event_manager.__aenter__()
        except Exception as exc:
            self._local_logger.exception(
                "Actor initialization failed before the runtime became active.",
                exc_info=(type(exc), exc, exc.__traceback__),
            )
            if previous_proxy_target is not None:
                self._restore_global_actor_proxy(previous_proxy_target)
            raise

        self._active = True
        self._is_exiting = False
        self._is_rebooting = False
        # if not self.is_at_home():
        #     await self.open_key_value_store()
        self.log.info("Initializing Actor")
        self._local_logger.debug(
            "Actor context entered successfully. actor_run_id_present=%s is_at_home=%s",
            bool(self._resolve_actor_run_id()),
            bool(self.configuration.is_at_home),
        )
        return self

    async def _finalize_actor_exit(self) -> None:
        """Run the shutdown sequence while keeping the main `__aexit__` flow readable."""
        if self.status_message is not None:
            self._local_logger.debug(
                "Sending terminal status message before shutdown. status_message_preview=%r",
                self._truncate_log_text(self.status_message, limit=200),
            )
            await self.set_status_message(self.status_message, is_terminal=True)
        else:
            self._local_logger.debug("No terminal status message was configured for this shutdown.")

        # Give log handlers and near-simultaneous listener tasks a brief chance to
        # start before the actor begins draining and closing resources.
        await asyncio.sleep(0.1)

        if self._event_listeners_timeout:
            self._local_logger.debug(
                "Waiting for actor event listeners to complete before shutdown. timeout=%s",
                self._event_listeners_timeout,
            )
            await self.event_manager.wait_for_all_listeners_to_complete(timeout=self._event_listeners_timeout)
        else:
            self._local_logger.debug("Event listener draining is disabled for this shutdown.")

        try:
            self._local_logger.debug(
                "Persisting autosaved actor state before shutdown. used_store_count=%d",
                len(self._use_state_stores),
            )
            await self._save_actor_state()
        finally:
            self._local_logger.debug("Draining pending actor log tasks before releasing runtime resources.")
            await self._drain_pending_log_tasks()

            if self._xcrawl_client is not None:
                self._local_logger.debug("Closing xcrawl API client during Actor shutdown.")
                await self._xcrawl_client.aclose()
            else:
                self._local_logger.debug("Actor shutdown skipped API client close because no client was created.")

            self._local_logger.debug("Closing LocalEventManager during Actor shutdown.")
            await self.event_manager.__aexit__(None, None, None)
            self._local_logger.debug("LocalEventManager closed successfully.")

    async def __aexit__(self, exc_type, exc_value, exc_traceback) -> None:
        if self._is_exiting:
            self._local_logger.debug("Ignoring duplicate Actor shutdown request because exit is already in progress.")
            return
        if not self._active:
            self._local_logger.error("Actor shutdown was requested while the runtime was inactive.")
            raise RuntimeError("The Actor is not active. Use it within the async context.")

        self._local_logger.info(
            "Exiting Actor context. has_exception=%s exit_code=%s status_message_present=%s cleanup_timeout=%s",
            exc_value is not None,
            self.exit_code,
            self.status_message is not None,
            self._cleanup_timeout,
        )

        if exc_value:
            self.log.exception("Actor failed with an exception", exc_info=exc_value)
            self.exit_code = self.exit_code or 1

        self._is_exiting = True
        self.log.info("Exiting Actor")

        try:
            await asyncio.wait_for(self._finalize_actor_exit(), timeout=self._cleanup_timeout.total_seconds())
        except TimeoutError:
            self.log.exception("Actor cleanup timed out")
        finally:
            self._active = False
            self._is_rebooting = False
            self._local_logger.debug(
                "Actor shutdown finished. active=%s exiting=%s rebooting=%s exit_code=%s",
                self._active,
                self._is_exiting,
                self._is_rebooting,
                self.exit_code,
            )

        if self._exit_process:
            self._local_logger.info("Actor is configured to exit the process after shutdown. exit_code=%s", self.exit_code)
            sys.exit(self.exit_code)

    async def init(self) -> None:
        """Explicitly initialize the Actor without using `async with`."""
        self._local_logger.debug("Actor.init() was called explicitly.")
        await self.__aenter__()

    async def exit(
        self,
        *,
        exit_code: int = 0,
        status_message: str | None = None,
        event_listeners_timeout: timedelta | None = EVENT_LISTENERS_TIMEOUT,
        cleanup_timeout: timedelta = timedelta(seconds=30),
    ) -> None:
        """Request a graceful shutdown using the same path as the async context manager."""
        self._local_logger.info(
            "Actor.exit() requested. exit_code=%s status_message_present=%s event_listeners_timeout=%s cleanup_timeout=%s",
            exit_code,
            status_message is not None,
            event_listeners_timeout,
            cleanup_timeout,
        )
        self.exit_code = exit_code
        self.status_message = status_message
        self._event_listeners_timeout = event_listeners_timeout
        self._cleanup_timeout = cleanup_timeout
        await self.__aexit__(None, None, None)

    async def fail(
        self,
        *,
        exit_code: int = 1,
        exception: BaseException | None = None,
        status_message: str | None = None,
    ) -> None:
        """Request a failure shutdown and preserve the original exception details when available."""
        self._local_logger.info(
            "Actor.fail() requested. exit_code=%s has_exception=%s status_message_present=%s",
            exit_code,
            exception is not None,
            status_message is not None,
        )
        self.exit_code = exit_code
        self.status_message = status_message
        await self.__aexit__(
            type(exception) if exception else None,
            exception,
            exception.__traceback__ if exception else None,
        )

    def new_client(
        self,
        *,
        token: str | None = None,
        api_url: str | None = None,
        max_retries: int | None = None,
        min_delay_between_retries: timedelta | None = None,
        timeout: timedelta | None = None,
    ) -> XcrawlApiClientAsync:
        """Create a dedicated API client while inheriting defaults from the Actor configuration."""
        resolved_token = token or self.configuration.token
        resolved_api_url = api_url or self.configuration.api_base_url
        resolved_min_delay_millis = (
            int(min_delay_between_retries.total_seconds() * 1000)
            if min_delay_between_retries is not None
            else None
        )
        resolved_timeout_secs = int(timeout.total_seconds()) if timeout else None

        self._local_logger.debug(
            "Creating a new xcrawl API client. token_override=%s api_url=%s max_retries=%r "
            "min_delay_between_retries_millis=%r timeout_secs=%r",
            token is not None,
            resolved_api_url,
            max_retries,
            resolved_min_delay_millis,
            resolved_timeout_secs,
        )

        return XcrawlApiClientAsync(
            token=resolved_token,
            api_url=resolved_api_url,
            max_retries=max_retries,
            min_delay_between_retries_millis=resolved_min_delay_millis,
            timeout_secs=resolved_timeout_secs,
        )

    def _resolve_api_client(self, *, token: str | None = None, operation: str) -> XcrawlApiClientAsync:
        """Use the shared client by default and only create a dedicated client when a token override is needed."""
        if token:
            self._local_logger.debug(
                "Using a dedicated xcrawl API client because %s received a token override.",
                operation,
            )
            return self.new_client(token=token)

        self._local_logger.debug("Using the shared Actor xcrawl client for %s.", operation)
        return self.xcrawl_client

    def _serialize_webhooks(self, webhooks: list[Webhook] | None) -> list[dict[str, Any]] | None:
        """Convert webhook models once so caller methods can focus on request semantics."""
        if not webhooks:
            self._local_logger.debug("No webhooks were provided for serialization.")
            return None

        serialized = [hook.model_dump(by_alias=True, exclude_unset=True, exclude_defaults=True) for hook in webhooks]
        self._local_logger.debug("Serialized webhook payloads for API call. webhook_count=%d", len(serialized))
        return serialized

    def _require_platform_run_id(self, operation: str) -> str:
        """Return the current platform run id or raise with a precise operation-specific message."""
        run_id = self.configuration.actor_run_id
        if run_id:
            self._local_logger.debug("%s will use platform actor_run_id=%s", operation, run_id)
            return run_id

        self._local_logger.error("%s requires actor_run_id, but the configuration does not provide one.", operation)
        raise RuntimeError("actor_run_id cannot be None when running on the platform.")

    async def _sleep_after_platform_operation(self, delay: timedelta | None, *, operation: str) -> None:
        """Honor optional post-operation sleeps while keeping the call sites compact and readable."""
        if not delay:
            self._local_logger.debug("No post-operation sleep configured for %s.", operation)
            return

        self._local_logger.debug("Sleeping after %s to let platform-side state settle. delay=%s", operation, delay)
        await asyncio.sleep(delay.total_seconds())

    def _dispatch_log(
        self,
        message: Any,
        *args: Any,
        level: str | int = "info",
        stream: str | None = None,
        metadata: dict[str, Any] | None = None,
        exc_info: Any = None,
        **logger_kwargs: Any,
    ) -> None:
        record = self._prepare_log_record(
            message,
            args=args,
            level=level,
            stream=stream,
            metadata=metadata,
            exc_info=exc_info,
        )
        self._emit_local_log(record, exc_info=exc_info, **logger_kwargs)
        if record.run_id:
            self._schedule_remote_log_append(record)

    def _prepare_log_record(
        self,
        message: Any,
        *,
        args: tuple[Any, ...] = (),
        level: str | int = "info",
        stream: str | None = None,
        metadata: dict[str, Any] | None = None,
        exc_info: Any = None,
    ) -> _PreparedLogRecord:
        level_name, level_number = self._normalize_log_level(level)
        normalized_stream = self._normalize_log_stream(stream, level_number)
        formatted_message = self._format_log_message(message, args)
        if not formatted_message.strip():
            self._local_logger.warning("Received an empty actor log message. A placeholder message will be used.")
            formatted_message = "<empty actor log message>"

        normalized_metadata = self._sanitize_log_metadata(metadata)
        normalized_metadata.setdefault("logger", DEFAULT_LOGGER_NAME)
        normalized_metadata.setdefault("loggedAt", datetime.now(tz=timezone.utc).isoformat())

        exception_metadata = self._extract_exception_metadata(exc_info)
        if exception_metadata:
            normalized_metadata["exception"] = exception_metadata

        run_id = self._resolve_actor_run_id()
        if run_id:
            normalized_metadata.setdefault("actorRunId", run_id)

        return _PreparedLogRecord(
            message=formatted_message,
            level_name=level_name,
            level_number=level_number,
            stream=normalized_stream,
            metadata=normalized_metadata,
            run_id=run_id,
        )

    def _resolve_actor_run_id(self) -> str | None:
        try:
            run_id = self.configuration.actor_run_id
        except Exception:
            return None
        return run_id or None

    def _normalize_log_level(self, level: str | int) -> tuple[str, int]:
        if isinstance(level, int):
            level_number = level
            level_name = logging.getLevelName(level_number)
            if not isinstance(level_name, str):
                level_name = f"LEVEL_{level_number}"
            return level_name.lower(), level_number

        normalized = str(level or "info").strip().lower()
        normalized = {"warn": "warning", "fatal": "critical"}.get(normalized, normalized)
        level_number = getattr(logging, normalized.upper(), None)
        if not isinstance(level_number, int):
            self._local_logger.warning("Unknown actor log level %r. Falling back to INFO.", level)
            return "info", logging.INFO
        return normalized, level_number

    def _normalize_log_stream(self, stream: str | None, level_number: int) -> Literal["stdout", "stderr"]:
        default_stream: Literal["stdout", "stderr"] = "stderr" if level_number >= logging.ERROR else "stdout"
        if stream is None:
            return default_stream

        normalized = str(stream).strip().lower()
        if normalized in {"stdout", "stderr"}:
            return cast(Literal["stdout", "stderr"], normalized)

        self._local_logger.warning(
            "Unknown actor log stream %r. Falling back to %s.",
            stream,
            default_stream,
        )
        return default_stream

    def _format_log_message(self, message: Any, args: tuple[Any, ...]) -> str:
        if isinstance(message, str):
            base_message = message
        else:
            base_message = self._stringify_for_log(message)

        if not args:
            return self._truncate_log_text(base_message)

        try:
            formatted = base_message % args
        except Exception:
            fallback_args = ", ".join(self._stringify_for_log(item) for item in args)
            self._local_logger.warning(
                "Failed to format actor log message using printf-style arguments. Falling back to stringified args."
            )
            formatted = f"{base_message} | args=[{fallback_args}]"
        return self._truncate_log_text(formatted)

    def _stringify_for_log(self, value: Any) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")
        try:
            return json.dumps(value, ensure_ascii=False, default=self._json_default_for_log)
        except Exception:
            return str(value)

    def _json_default_for_log(self, value: Any) -> Any:
        if isinstance(value, datetime):
            return value.isoformat()
        if hasattr(value, "model_dump"):
            return value.model_dump(by_alias=True, exclude_none=True)
        if hasattr(value, "dict"):
            return value.dict()
        return str(value)

    def _sanitize_log_metadata(self, metadata: dict[str, Any] | None) -> dict[str, Any]:
        if metadata is None:
            return {}

        candidate: Any = metadata if isinstance(metadata, dict) else {"value": metadata}
        try:
            normalized = json.loads(json.dumps(candidate, ensure_ascii=False, default=self._json_default_for_log))
        except Exception as exc:
            self._local_logger.exception(
                "Failed to serialize actor log metadata cleanly. Falling back to stringified metadata values.",
                exc_info=exc,
            )
            if isinstance(candidate, dict):
                return {str(key): self._stringify_for_log(value) for key, value in candidate.items()}
            return {"value": self._stringify_for_log(candidate)}

        if isinstance(normalized, dict):
            return normalized
        return {"value": normalized}

    def _extract_exception_metadata(self, exc_info: Any) -> dict[str, Any] | None:
        normalized = self._normalize_exc_info(exc_info)
        if not normalized:
            return None

        exc_type, exc_value, exc_traceback = normalized
        if exc_value is None:
            return None

        traceback_text = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        return {
            "type": exc_type.__name__ if exc_type else type(exc_value).__name__,
            "message": self._truncate_log_text(str(exc_value), limit=4000),
            "traceback": self._truncate_log_text(traceback_text, limit=16000),
        }

    def _normalize_exc_info(self, exc_info: Any) -> tuple[type[BaseException] | None, BaseException | None, Any] | None:
        if not exc_info:
            return None
        if exc_info is True:
            current_exc = sys.exc_info()
            return current_exc if current_exc[0] is not None else None
        if isinstance(exc_info, BaseException):
            return type(exc_info), exc_info, exc_info.__traceback__
        if isinstance(exc_info, tuple) and len(exc_info) == 3:
            return cast(tuple[type[BaseException] | None, BaseException | None, Any], exc_info)
        return None

    def _emit_local_log(self, record: _PreparedLogRecord, *, exc_info: Any = None, **logger_kwargs: Any) -> None:
        logger_kwargs = dict(logger_kwargs)
        normalized_exc_info = self._normalize_exc_info(exc_info)
        if normalized_exc_info is not None:
            logger_kwargs["exc_info"] = normalized_exc_info
        else:
            logger_kwargs.pop("exc_info", None)
        self._local_logger.log(record.level_number, self._compose_local_log_message(record), **logger_kwargs)

    def _compose_local_log_message(self, record: _PreparedLogRecord) -> str:
        if not record.metadata:
            return record.message

        metadata_text = self._truncate_log_text(
            json.dumps(record.metadata, ensure_ascii=False, sort_keys=True, default=self._json_default_for_log),
            limit=8000,
        )
        return f"{record.message} | metadata={metadata_text}"

    def _schedule_remote_log_append(self, record: _PreparedLogRecord) -> None:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            self._local_logger.debug(
                "Skipping remote actor log append because there is no running event loop. message=%r",
                self._truncate_log_text(record.message, limit=200),
            )
            return

        task = loop.create_task(self._append_log_to_runtime(record))
        self._pending_log_tasks.add(task)
        task.add_done_callback(self._handle_pending_log_task_done)

    def _handle_pending_log_task_done(self, task: asyncio.Task[Any]) -> None:
        self._pending_log_tasks.discard(task)
        try:
            task.result()
        except asyncio.CancelledError:
            self._local_logger.debug("A background actor log append task was cancelled before completion.")
        except Exception as exc:
            self._local_logger.exception(
                "Background actor log append failed.",
                exc_info=(type(exc), exc, exc.__traceback__),
            )

    async def _drain_pending_log_tasks(self) -> None:
        if not self._pending_log_tasks:
            return

        pending_tasks = tuple(self._pending_log_tasks)
        self._local_logger.debug("Draining %d pending actor log task(s) before shutdown.", len(pending_tasks))
        results = await asyncio.gather(*pending_tasks, return_exceptions=True)
        self._pending_log_tasks.clear()

        for result in results:
            if isinstance(result, asyncio.CancelledError):
                self._local_logger.debug("A pending actor log task was cancelled during shutdown draining.")
            elif isinstance(result, Exception):
                self._local_logger.exception(
                    "A pending actor log task failed during shutdown draining.",
                    exc_info=(type(result), result, result.__traceback__),
                )

    async def _append_log_to_runtime(self, record: _PreparedLogRecord) -> None:
        if not record.run_id:
            return

        self._local_logger.debug(
            "Appending actor log to runtime. run_id=%s level=%s stream=%s metadata_keys=%s",
            record.run_id,
            record.level_name,
            record.stream,
            sorted(record.metadata.keys()),
        )
        await self.xcrawl_client._request(
            method="POST",
            path=f"/runtime/runs/{safe_resource_id(record.run_id)}/logs",
            json_body={
                "message": record.message,
                "level": record.level_name,
                "stream": record.stream,
                "metadata": record.metadata,
            },
        )
        self._local_logger.debug(
            "Actor log appended to runtime successfully. run_id=%s level=%s",
            record.run_id,
            record.level_name,
        )

    def _truncate_log_text(self, value: str, *, limit: int = 12000) -> str:
        if len(value) <= limit:
            return value
        truncated = len(value) - limit
        return f"{value[:limit]}... <truncated {truncated} chars>"

    def _summarize_value_for_log(self, value: Any) -> dict[str, Any]:
        summary: dict[str, Any] = {"type": type(value).__name__}
        if value is None:
            summary["is_none"] = True
            return summary
        if isinstance(value, dict):
            summary["key_count"] = len(value)
            summary["keys_preview"] = [str(key) for key in list(value.keys())[:10]]
            return summary
        if isinstance(value, (list, tuple, set)):
            summary["length"] = len(value)
            if value:
                summary["first_item_type"] = type(next(iter(value))).__name__
            return summary
        if isinstance(value, (str, bytes, bytearray)):
            summary["length"] = len(value)
            return summary
        return summary

    def _ensure_context(self) -> None:
        """Fail fast when helpers are used outside the Actor lifecycle."""
        if not self._active:
            self._local_logger.error(
                "Actor helper was invoked without an active runtime context. active=%s exiting=%s rebooting=%s",
                self._active,
                self._is_exiting,
                self._is_rebooting,
            )
            raise RuntimeError("The Actor is not initialized. Use `async with Actor:` or `await Actor.init()`.")

    def _should_use_cloud_storage(self, *, force_cloud: bool = False) -> bool:
        return bool(self.configuration.is_at_home or force_cloud)

    def _resolve_default_storage_id(
        self,
        *,
        storage_kind: Literal["dataset", "key_value_store", "request_queue"],
        explicit_id: str | None = None,
        name: str | None = None,
        alias: str | None = None,
        force_cloud: bool = False,
    ) -> str | None:
        if explicit_id is not None:
            return explicit_id
        if name is not None or alias is not None:
            return None
        if not self._should_use_cloud_storage(force_cloud=force_cloud):
            self._local_logger.debug(
                "Skipping configured default %s id because local storage was selected. force_cloud=%s configured_id=%r",
                storage_kind,
                force_cloud,
                {
                    "dataset": self.configuration.default_dataset_id,
                    "key_value_store": self.configuration.default_key_value_store_id,
                    "request_queue": self.configuration.default_request_queue_id,
                }[storage_kind],
            )
            return None

        configured_default_id = {
            "dataset": self.configuration.default_dataset_id,
            "key_value_store": self.configuration.default_key_value_store_id,
            "request_queue": self.configuration.default_request_queue_id,
        }[storage_kind]
        self._local_logger.debug(
            "Using configured default %s id for cloud-backed storage open. force_cloud=%s configured_id=%r",
            storage_kind,
            force_cloud,
            configured_default_id,
        )
        return configured_default_id

    async def open_dataset(
        self,
        *,
        id: str | None = None,
        alias: str | None = None,
        name: str | None = None,
        force_cloud: bool = False,
    ) -> Dataset:
        self._ensure_context()
        effective_id = self._resolve_default_storage_id(
            storage_kind="dataset",
            explicit_id=id,
            name=name,
            alias=alias,
            force_cloud=force_cloud,
        )
        self._local_logger.debug(
            "Opening dataset. explicit_id=%r effective_id=%r alias=%r name=%r force_cloud=%s use_cloud=%s",
            id,
            effective_id,
            alias,
            name,
            force_cloud,
            self._should_use_cloud_storage(force_cloud=force_cloud),
        )
        # With no explicit target, open the default dataset for the current run.
        return await Dataset.open(
            id=effective_id,
            alias=alias,
            name=name,
            storage_client=self._storage_client.get_suitable_storage_client(force_cloud=force_cloud),
            configuration=self.configuration,
        )

    async def open_key_value_store(
        self,
        *,
        id: str | None = None,
        alias: str | None = None,
        name: str | None = None,
        force_cloud: bool = False,
    ) -> KeyValueStore:
        self._ensure_context()
        effective_id = self._resolve_default_storage_id(
            storage_kind="key_value_store",
            explicit_id=id,
            name=name,
            alias=alias,
            force_cloud=force_cloud,
        )
        self._local_logger.debug(
            "Opening key-value store. explicit_id=%r effective_id=%r alias=%r name=%r force_cloud=%s use_cloud=%s",
            id,
            effective_id,
            alias,
            name,
            force_cloud,
            self._should_use_cloud_storage(force_cloud=force_cloud),
        )
        # This is the backing store used by `get_input()`, `get_value()`, `set_value()`
        # and `use_state()` when no custom KVS name is supplied.
        return await KeyValueStore.open(
            id=effective_id,
            alias=alias,
            name=name,
            storage_client=self._storage_client.get_suitable_storage_client(force_cloud=force_cloud),
            configuration=self.configuration,
        )

    async def open_request_queue(
        self,
        *,
        id: str | None = None,
        alias: str | None = None,
        name: str | None = None,
        force_cloud: bool = False,
    ) -> RequestQueue:
        self._ensure_context()
        effective_id = self._resolve_default_storage_id(
            storage_kind="request_queue",
            explicit_id=id,
            name=name,
            alias=alias,
            force_cloud=force_cloud,
        )
        self._local_logger.debug(
            "Opening request queue. explicit_id=%r effective_id=%r alias=%r name=%r force_cloud=%s use_cloud=%s",
            id,
            effective_id,
            alias,
            name,
            force_cloud,
            self._should_use_cloud_storage(force_cloud=force_cloud),
        )
        # Request queue access mode is configured once on the storage client because
        # it affects how queue semantics are implemented underneath.
        return await RequestQueue.open(
            id=effective_id,
            alias=alias,
            name=name,
            storage_client=self._storage_client.get_suitable_storage_client(force_cloud=force_cloud),
            configuration=self.configuration,
        )

    async def push_data(
        self,
        data: dict | list[dict],
        charged_event_name: str | None = None,
        *,
        force_cloud: bool = False,
    ) -> dict[str, Any]:
        self._ensure_context()
        items = data if isinstance(data, list) else [data]

        run_id = self.configuration.actor_run_id
        dataset_id = self.configuration.default_dataset_id or "default"
        use_remote_dataset = bool(run_id or force_cloud)

        self._local_logger.info(
            "push_data called. item_count=%d charged_event_name=%r force_cloud=%s use_remote_dataset=%s dataset_id=%s",
            len(items),
            charged_event_name,
            force_cloud,
            use_remote_dataset,
            dataset_id,
        )

        # Prefer the runtime dataset endpoint when we are attached to a run or when
        # the caller explicitly forces cloud storage. Otherwise keep the original
        # local-storage path untouched.
        if use_remote_dataset:
            dataset_client = self.xcrawl_client.dataset(dataset_id, run_id=run_id)
            res=await dataset_client.append_dataset_items(items)
            self.log.info(f"dataset push_data  run_id:{run_id},dataset_id:{dataset_id},items:{items} response: {res}")
            self._local_logger.debug(
                "push_data stored items through the runtime dataset API. run_id=%s dataset_id=%s",
                run_id,
                dataset_id,
            )
        else:
            dataset = await self.open_dataset(force_cloud=False)
            await dataset.push_data(data)
            self._local_logger.debug("push_data stored items through the local dataset backend.")

        return {
            "charged_count": len(items),
            "event_charge_limit_reached": False,
            "chargeable_within_limit": True,
            "supported": False,
            "event_name": charged_event_name,
        }

    async def append_log(self,
        message: Any,
        level: str | int = "info",
        stream: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Append a log entry locally and, when possible, forward it to the runtime API."""
        record = self._prepare_log_record(message, level=level, stream=stream, metadata=metadata)
        self._local_logger.debug(
            "append_log called. level=%s stream=%s run_id_present=%s metadata_keys=%s message_preview=%r",
            record.level_name,
            record.stream,
            bool(record.run_id),
            sorted(record.metadata.keys()),
            self._truncate_log_text(record.message, limit=200),
        )
        self._emit_local_log(record)

        if not record.run_id:
            self._local_logger.info(
                "Actor run_id is not configured. append_log emitted the log locally only. level=%s",
                record.level_name,
            )
            return

        try:
            await self._append_log_to_runtime(record)
        except Exception as exc:
            self._local_logger.exception(
                "append_log failed to send the log record to the runtime API. The log entry remains available locally.",
                exc_info=(type(exc), exc, exc.__traceback__),
            )

    async def get_input(self, *, force_cloud: bool = False) -> Any:
        """Resolve actor input from the runtime API first when requested, otherwise fall back to KVS."""
        self._ensure_context()
        input_key = str(self.configuration.input_key or "").strip()
        actor_run_id = self.configuration.actor_run_id

        self._local_logger.debug(
            "Starting actor input resolution. force_cloud=%s actor_run_id_present=%s input_key=%r is_at_home=%s",
            force_cloud,
            bool(actor_run_id),
            input_key,
            self.is_at_home(),
        )

        if not input_key:
            self._local_logger.error("Actor input resolution failed because configuration.input_key is empty.")
            raise ValueError("Actor input key cannot be empty.")

        runtime_error: Exception | None = None

        if force_cloud and actor_run_id:
            self._local_logger.info(
                "Attempting to fetch actor input from the runtime API first. run_id=%s input_key=%s",
                actor_run_id,
                input_key,
            )
            try:
                runtime_input = await self.xcrawl_client._request(
                    method="GET",
                    path=f"/runtime/runs/{safe_resource_id(actor_run_id)}/input",
                )
                self._local_logger.info(
                    "Actor input fetched from the runtime API successfully. summary=%s",
                    self._summarize_value_for_log(runtime_input),
                )
                return runtime_input
            except Exception as exc:
                runtime_error = exc
                self._local_logger.exception(
                    "Fetching actor input from the runtime API failed. The code will fall back to the configured key-value store.",
                    exc_info=(type(exc), exc, exc.__traceback__),
                )
        elif force_cloud and not actor_run_id:
            self._local_logger.warning(
                "force_cloud=True was requested, but actor_run_id is not configured. Runtime API input lookup will be skipped."
            )

        self._local_logger.info(
            "Fetching actor input from the configured key-value store. input_key=%s force_cloud=%s",
            input_key,
            force_cloud,
        )
        try:
            stored_input = await self.get_value(input_key, force_cloud=force_cloud)
        except Exception as exc:
            self._local_logger.exception(
                "Fetching actor input from the key-value store failed. input_key=%s force_cloud=%s",
                input_key,
                force_cloud,
                exc_info=(type(exc), exc, exc.__traceback__),
            )
            if runtime_error is not None:
                raise RuntimeError("Failed to resolve actor input from both runtime API and key-value store.") from exc
            raise

        if stored_input is None:
            self._local_logger.warning(
                "Actor input resolved to None from the key-value store. input_key=%s force_cloud=%s",
                input_key,
                force_cloud,
            )
        else:
            self._local_logger.info(
                "Actor input fetched from the key-value store successfully. summary=%s",
                self._summarize_value_for_log(stored_input),
            )

        if runtime_error is not None:
            self._local_logger.warning(
                "Actor input retrieval ultimately succeeded via key-value store fallback after a runtime API failure."
            )

        return stored_input

    async def get_value(self, key: str, default_value: Any = None, *, force_cloud: bool = False) -> Any:
        """Read a record from the default key-value store selected for this Actor context."""
        self._ensure_context()
        self._local_logger.debug(
            "Reading actor key-value record. key=%s force_cloud=%s default_value_summary=%s",
            key,
            force_cloud,
            self._summarize_value_for_log(default_value),
        )
        key_value_store = await self.open_key_value_store(force_cloud=force_cloud)
        value = await key_value_store.get_value(key, default_value)
        self._local_logger.debug(
            "Actor key-value record read completed. key=%s value_summary=%s",
            key,
            self._summarize_value_for_log(value),
        )
        return value

    async def set_value(
        self,
        key: str,
        value: Any,
        *,
        content_type: str | None = None,
        force_cloud: bool = False,
    ) -> None:
        self._ensure_context()
        run_id = self.configuration.actor_run_id
        store_id = self.configuration.default_key_value_store_id or "default"
        use_runtime_store = bool(run_id or force_cloud)

        self._local_logger.info(
            "Writing actor key-value record. key=%s force_cloud=%s use_runtime_store=%s content_type=%r value_summary=%s",
            key,
            force_cloud,
            use_runtime_store,
            content_type,
            self._summarize_value_for_log(value),
        )

        # Keep the same storage routing semantics as before, but make it obvious
        # which backend was selected and what payload shape is being written.
        if use_runtime_store:
            kvs_client = self.xcrawl_client.key_value_store(store_id, run_id=run_id)
            await kvs_client.set_runtime_record(
                key,
                value,
                content_type=content_type or "application/json",
            )
            self._local_logger.debug(
                "Actor key-value record written through the runtime API. run_id=%s store_id=%s key=%s",
                run_id,
                store_id,
                key,
            )
        else:
            key_value_store = await self.open_key_value_store(force_cloud=force_cloud)
            await key_value_store.set_value(key, value, content_type=content_type)
            self._local_logger.debug("Actor key-value record written through the local store. key=%s", key)

    def get_charging_manager(self) -> dict[str, Any]:
        self._ensure_context()
        return {
            "supported": False,
            "reason": "xcrawl does not implement pay-per-event charging semantics.",
        }

    async def charge(self, event_name: str, count: int = 1) -> dict[str, Any]:
        self._ensure_context()
        return {
            "event_name": event_name,
            "charged_count": count,
            "event_charge_limit_reached": False,
            "chargeable_within_limit": True,
            "supported": False,
        }

    def on(self, event_name: Event, listener: EventListener[Any]) -> EventListener[Any]:
        self._ensure_context()
        self.event_manager.on(event=event_name, listener=listener)
        return listener

    def off(self, event_name: Event, listener: EventListener[Any] | None = None) -> None:
        self._ensure_context()
        self.event_manager.off(event=event_name, listener=listener)

    def is_at_home(self) -> bool:
        return bool(self.configuration.is_at_home)

    def get_env(self) -> dict[str, Any]:
        self._ensure_context()
        config: dict[str, Any] = {}
        for field_name, field in Configuration.model_fields.items():
            aliases: list[str]
            if field.alias:
                aliases = [field.alias]
            elif isinstance(field.validation_alias, str):
                aliases = [field.validation_alias]
            elif hasattr(field.validation_alias, "choices"):
                aliases = list(field.validation_alias.choices)
            else:
                aliases = [field_name]
            for alias in aliases:
                config[alias] = getattr(self.configuration, field_name)
        return config

    async def start(
        self,
        actor_id: str,
        run_input: Any = None,
        *,
        token: str | None = None,
        content_type: str | None = None,
        build: str | None = None,
        memory_mbytes: int | None = None,
        timeout: timedelta | None | Literal["inherit", "RemainingTime"] = None,
        wait_for_finish: int | None = None,
        webhooks: list[Webhook] | None = None,
    ) -> ActorRun:
        self._ensure_context()
        # `start()` kicks off a remote actor run and returns immediately with the
        # initial run payload, without polling for terminal completion.
        client = self._resolve_api_client(token=token, operation="Actor.start()")
        normalized_timeout = self._normalize_timeout(timeout)
        serialized_webhooks = self._serialize_webhooks(webhooks)

        self._local_logger.info(
            "Starting remote actor run. actor_id=%s token_override=%s build=%r memory_mbytes=%r timeout_secs=%r "
            "wait_for_finish=%r webhook_count=%d input_summary=%s",
            actor_id,
            token is not None,
            build,
            memory_mbytes,
            normalized_timeout,
            wait_for_finish,
            len(serialized_webhooks or []),
            self._summarize_value_for_log(run_input),
        )
        api_result = await client.actor(actor_id).start(
            run_input=run_input,
            content_type=content_type,
            build=build,
            memory_mbytes=memory_mbytes,
            timeout_secs=normalized_timeout,
            wait_for_finish=wait_for_finish,
            webhooks=serialized_webhooks,
        )
        actor_run = ActorRun.model_validate(api_result)
        self._local_logger.info(
            "Remote actor run started successfully. actor_id=%s run_id=%s status=%s",
            actor_id,
            actor_run.id,
            actor_run.status,
        )
        return actor_run

    async def abort(
        self,
        run_id: str,
        *,
        token: str | None = None,
        status_message: str | None = None,
        gracefully: bool | None = None,
    ) -> ActorRun:
        self._ensure_context()
        client = self._resolve_api_client(token=token, operation="Actor.abort()")
        self._local_logger.info(
            "Aborting remote actor run. run_id=%s token_override=%s gracefully=%r status_message_present=%s",
            run_id,
            token is not None,
            gracefully,
            status_message is not None,
        )
        if status_message:
            await client.run(run_id).update(status_message=status_message)
            self._local_logger.debug("Updated remote run status message before abort. run_id=%s", run_id)
        api_result = await client.run(run_id).abort(gracefully=gracefully)
        actor_run = ActorRun.model_validate(api_result)
        self._local_logger.info(
            "Remote actor run abort request completed. run_id=%s status=%s",
            actor_run.id,
            actor_run.status,
        )
        return actor_run

    async def call(
        self,
        actor_id: str,
        run_input: Any = None,
        *,
        token: str | None = None,
        content_type: str | None = None,
        build: str | None = None,
        memory_mbytes: int | None = None,
        timeout: timedelta | None | Literal["inherit", "RemainingTime"] = None,
        webhooks: list[Webhook] | None = None,
        wait: timedelta | None = None,
        logger: logging.Logger | _ActorLogProxy | None | Literal["default"] = "default",
    ) -> ActorRun | None:
        self._ensure_context()
        # `call()` is the higher-level helper: start the run and optionally wait until
        # the server can return a finished run payload within the requested window.
        client = self._resolve_api_client(token=token, operation="Actor.call()")
        normalized_timeout = self._normalize_timeout(timeout)
        wait_secs = int(wait.total_seconds()) if wait is not None else None
        serialized_webhooks = self._serialize_webhooks(webhooks)

        self._local_logger.info(
            "Calling remote actor. actor_id=%s token_override=%s build=%r memory_mbytes=%r timeout_secs=%r "
            "wait_secs=%r webhook_count=%d input_summary=%s",
            actor_id,
            token is not None,
            build,
            memory_mbytes,
            normalized_timeout,
            wait_secs,
            len(serialized_webhooks or []),
            self._summarize_value_for_log(run_input),
        )
        api_result = await client.actor(actor_id).call(
            run_input=run_input,
            content_type=content_type,
            build=build,
            memory_mbytes=memory_mbytes,
            timeout_secs=normalized_timeout,
            webhooks=serialized_webhooks,
            wait_secs=wait_secs,
            logger=logger,
        )
        actor_run = maybe_parse_actor_run(api_result)
        self._local_logger.info(
            "Remote actor call completed. actor_id=%s run_present=%s run_id=%s status=%s",
            actor_id,
            actor_run is not None,
            actor_run.id if actor_run else None,
            actor_run.status if actor_run else None,
        )
        return actor_run

    async def call_task(
        self,
        task_id: str,
        task_input: dict | None = None,
        *,
        build: str | None = None,
        memory_mbytes: int | None = None,
        timeout: timedelta | None | Literal["inherit"] = None,
        webhooks: list[Webhook] | None = None,
        wait: timedelta | None = None,
        token: str | None = None,
    ) -> ActorRun | None:
        self._ensure_context()
        # Tasks are platform-side templates around actors, so the client call is
        # almost the same as `call()` but targets the task endpoint instead.
        client = self._resolve_api_client(token=token, operation="Actor.call_task()")
        normalized_timeout = self._normalize_timeout(timeout)
        wait_secs = int(wait.total_seconds()) if wait is not None else None
        serialized_webhooks = self._serialize_webhooks(webhooks)

        self._local_logger.info(
            "Calling remote actor task. task_id=%s token_override=%s build=%r memory_mbytes=%r timeout_secs=%r "
            "wait_secs=%r webhook_count=%d input_summary=%s",
            task_id,
            token is not None,
            build,
            memory_mbytes,
            normalized_timeout,
            wait_secs,
            len(serialized_webhooks or []),
            self._summarize_value_for_log(task_input),
        )
        api_result = await client.task(task_id).call(
            task_input=task_input,
            build=build,
            memory_mbytes=memory_mbytes,
            timeout_secs=normalized_timeout,
            webhooks=serialized_webhooks,
            wait_secs=wait_secs,
        )
        actor_run = maybe_parse_actor_run(api_result)
        self._local_logger.info(
            "Remote actor task call completed. task_id=%s run_present=%s run_id=%s status=%s",
            task_id,
            actor_run is not None,
            actor_run.id if actor_run else None,
            actor_run.status if actor_run else None,
        )
        return actor_run

    async def metamorph(
        self,
        target_actor_id: str,
        run_input: Any = None,
        *,
        target_actor_build: str | None = None,
        content_type: str | None = None,
        custom_after_sleep: timedelta | None = None,
    ) -> None:
        self._ensure_context()
        if not self.is_at_home():
            self.log.error("Actor.metamorph() is only supported when running on the xcrawl platform.")
            return
        if not custom_after_sleep:
            custom_after_sleep = self.configuration.metamorph_after_sleep
        run_id = self._require_platform_run_id("Actor.metamorph()")

        self._local_logger.info(
            "Requesting actor metamorph. current_run_id=%s target_actor_id=%s target_actor_build=%r content_type=%r "
            "post_sleep=%s input_summary=%s",
            run_id,
            target_actor_id,
            target_actor_build,
            content_type,
            custom_after_sleep,
            self._summarize_value_for_log(run_input),
        )
        # Metamorph replaces the currently running actor with another one while
        # preserving the run identity on the platform side.
        await self.xcrawl_client.run(run_id).metamorph(
            target_actor_id=target_actor_id,
            run_input=run_input,
            target_actor_build=target_actor_build,
            content_type=content_type,
        )
        self._local_logger.info("Actor metamorph request sent successfully. current_run_id=%s", run_id)
        await self._sleep_after_platform_operation(custom_after_sleep, operation="Actor.metamorph()")

    async def reboot(
        self,
        *,
        event_listeners_timeout: timedelta | None = EVENT_LISTENERS_TIMEOUT,
        custom_after_sleep: timedelta | None = None,
    ) -> None:
        self._ensure_context()
        if not self.is_at_home():
            self.log.error("Actor.reboot() is only supported when running on the xcrawl platform.")
            return
        if self._is_rebooting:
            self._local_logger.warning("Ignoring duplicate Actor.reboot() request because a reboot is already in progress.")
            return
        self._is_rebooting = True
        if not custom_after_sleep:
            custom_after_sleep = self.configuration.metamorph_after_sleep
        run_id = self._require_platform_run_id("Actor.reboot()")

        self._local_logger.info(
            "Requesting actor reboot. run_id=%s event_listeners_timeout=%s post_sleep=%s",
            run_id,
            event_listeners_timeout,
            custom_after_sleep,
        )
        # Mirror the lifecycle notifications that platform actors expect before a reboot
        # so user listeners can checkpoint local state in the same way.
        self.event_manager.emit(event=Event.PERSIST_STATE, event_data=EventPersistStateData(is_migrating=True))
        self.event_manager.emit(event=Event.MIGRATING, event_data=EventMigratingData())
        if event_listeners_timeout:
            self._local_logger.debug(
                "Waiting for event listeners before actor reboot. timeout=%s",
                event_listeners_timeout,
            )
            await self.event_manager.wait_for_all_listeners_to_complete(timeout=event_listeners_timeout)
        await self.xcrawl_client.run(run_id).reboot()
        self._local_logger.info("Actor reboot request sent successfully. run_id=%s", run_id)
        await self._sleep_after_platform_operation(custom_after_sleep, operation="Actor.reboot()")

    async def add_webhook(
        self,
        webhook: Webhook,
        *,
        ignore_ssl_errors: bool | None = None,
        do_not_retry: bool | None = None,
        idempotency_key: str | None = None,
    ) -> None:
        self._ensure_context()
        if not self.is_at_home():
            self.log.error("Actor.add_webhook() is only supported when running on the xcrawl platform.")
            return
        run_id = self._require_platform_run_id("Actor.add_webhook()")
        self._local_logger.info(
            "Adding runtime webhook. run_id=%s event_type_count=%d request_url=%s ignore_ssl_errors=%r "
            "do_not_retry=%r idempotency_key_present=%s",
            run_id,
            len(webhook.event_types),
            webhook.request_url,
            ignore_ssl_errors,
            do_not_retry,
            idempotency_key is not None,
        )
        await self.xcrawl_client.webhooks().create(
            actor_run_id=run_id,
            event_types=[str(item) for item in webhook.event_types],
            request_url=webhook.request_url,
            payload_template=webhook.payload_template,
            headers_template=webhook.headers_template,
            ignore_ssl_errors=ignore_ssl_errors,
            do_not_retry=do_not_retry,
            idempotency_key=idempotency_key,
        )
        self._local_logger.info("Runtime webhook created successfully. run_id=%s request_url=%s", run_id, webhook.request_url)

    async def set_status_message(
        self,
        status_message: str,
        *,
        is_terminal: bool | None = None,
    ) -> ActorRun | None:
        self._ensure_context()
        if not self.is_at_home():
            title = "Terminal status message" if is_terminal else "Status message"
            self.log.info("[%s]: %s", title, status_message)
            return None
        run_id = self._require_platform_run_id("Actor.set_status_message()")
        self._local_logger.info(
            "Updating actor status message. run_id=%s is_terminal=%s message_preview=%r",
            run_id,
            is_terminal,
            self._truncate_log_text(status_message, limit=200),
        )
        api_result = await self.xcrawl_client.run(run_id).update(
            status_message=status_message,
            is_status_message_terminal=is_terminal,
        )
        actor_run = ActorRun.model_validate(api_result)
        self._local_logger.debug(
            "Actor status message updated successfully. run_id=%s status=%s",
            actor_run.id,
            actor_run.status,
        )
        return actor_run

    async def create_proxy_configuration(
        self,
        *,
        proxy_info: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        self._ensure_context()
        self._local_logger.debug(
            "Creating proxy request configuration. proxy_info_present=%s",
            proxy_info is not None,
        )

        if proxy_info in (None, False, "", {}):
            self._local_logger.info(
                "Proxy request configuration is empty. Returning None."
            )
            return None

        if not isinstance(proxy_info, dict):
            self._local_logger.warning("proxy_info must be a dict when provided. actual_type=%s", type(proxy_info).__name__)
            return None

        def _pick(*keys: str) -> Any:
            for key in keys:
                value = proxy_info.get(key)
                if value is None:
                    continue
                if isinstance(value, str):
                    value = value.strip()
                    if not value:
                        continue
                return value
            return None

        def _parse_int(value: Any, field_name: str) -> int | None:
            if value is None:
                return None
            if isinstance(value, bool):
                self._local_logger.warning("proxy_info.%s must be an integer, got bool.", field_name)
                return None
            try:
                parsed = int(value)
            except (TypeError, ValueError):
                self._local_logger.warning("proxy_info.%s must be an integer. actual_value=%r", field_name, value)
                return None
            return parsed

        def _parse_bool(value: Any, field_name: str) -> bool | None:
            if value is None:
                return None
            if isinstance(value, bool):
                return value
            if isinstance(value, int):
                return value != 0
            if isinstance(value, str):
                normalized = value.strip().lower()
                if normalized in {"1", "true", "yes", "y", "on"}:
                    return True
                if normalized in {"0", "false", "no", "n", "off"}:
                    return False
            self._local_logger.warning("proxy_info.%s must be a boolean. actual_value=%r", field_name, value)
            return None

        def _clamp(value: int, *, minimum: int, maximum: int) -> int:
            return max(minimum, min(maximum, value))

        mode_raw = _pick("mode", "type")
        if mode_raw is None:
            self._local_logger.warning("proxy_info.mode is required. Returning None.")
            return None
        normalized_mode = str(mode_raw).strip().lower()
        if normalized_mode not in {"debug", "normal"}:
            self._local_logger.warning(
                "proxy_info.mode must be 'debug' or 'normal'. actual_value=%r",
                mode_raw,
            )
            return None

        normalized_country = _pick("country")
        if normalized_country is None:
            normalized_country = "US"
        else:
            normalized_country = str(normalized_country).strip().upper() or "US"

        sticky_session = _pick("sticky_session", "stickySession")
        if sticky_session is not None:
            sticky_session = str(sticky_session).strip() or None

        life_seconds = _parse_int(_pick("life_seconds", "lifeSeconds"), "life_seconds")
        if life_seconds is None:
            life_seconds = 120
        clamped_life_seconds = _clamp(life_seconds, minimum=1, maximum=3600)
        if clamped_life_seconds != life_seconds:
            self._local_logger.info(
                "proxy_info.life_seconds was clamped from %s to %s.",
                life_seconds,
                clamped_life_seconds,
            )
        life_seconds = clamped_life_seconds

        count = _parse_int(_pick("count"), "count")
        if count is None:
            count = 1
        clamped_count = _clamp(count, minimum=1, maximum=50)
        if clamped_count != count:
            self._local_logger.info(
                "proxy_info.count was clamped from %s to %s.",
                count,
                clamped_count,
            )
        count = clamped_count

        request_config: dict[str, Any] = {
            "mode": normalized_mode,
            "country": normalized_country,
            "life_seconds": life_seconds,
            "count": count,
        }

        if sticky_session is not None:
            request_config["sticky_session"] = sticky_session

        if normalized_mode == "normal":
            source_raw = _pick("source")
            normalized_source = "auto" if source_raw is None else str(source_raw).strip().lower()
            if normalized_source not in {"auto", "bound_proxy_pool", "legacy_proxy_pool"}:
                self._local_logger.warning(
                    "proxy_info.source must be one of auto, bound_proxy_pool, legacy_proxy_pool. actual_value=%r",
                    source_raw,
                )
                return None
            request_config["source"] = normalized_source

            pool_value = _pick("pool")
            if pool_value is not None:
                normalized_pool = str(pool_value).strip()
                request_config["pool"] = normalized_pool or "auto"

            js_render = _parse_bool(_pick("js_render", "jsRender"), "js_render")
            if js_render is not None:
                request_config["js_render"] = js_render

            sandbox_value = _pick("sandbox")
            if sandbox_value is not None:
                sandbox_text = str(sandbox_value).strip()
                if sandbox_text:
                    if request_config.get("js_render") is True:
                        request_config["sandbox"] = sandbox_text
                    else:
                        self._local_logger.info(
                            "proxy_info.sandbox is ignored because js_render is not true. sandbox=%r",
                            sandbox_text,
                        )
        else:
            endpoint_value = _pick("endpoint")
            if endpoint_value is None:
                endpoint_value = os.getenv("XCRAWL_DEBUG_PROXY_ENDPOINT")
            if endpoint_value is not None:
                endpoint_text = str(endpoint_value).strip()
                if endpoint_text:
                    request_config["endpoint"] = endpoint_text

            validate = _parse_bool(_pick("validate"), "validate")
            if validate is not None:
                request_config["validate"] = validate

        self._local_logger.info(
            "Proxy request configuration prepared successfully. mode=%s country=%r source=%r count=%s life_seconds=%s",
            request_config["mode"],
            request_config.get("country"),
            request_config.get("source"),
            request_config.get("count"),
            request_config.get("life_seconds"),
        )
        return request_config

    async def get_proxy(self, proxy_info: dict[str, Any] | None = None) -> Any | None:
        self._ensure_context()
        request_config = await self.create_proxy_configuration(proxy_info=proxy_info)
        if request_config is None:
            self._local_logger.info("Proxy request configuration is unavailable. Runtime proxy acquisition skipped.")
            return None

        run_id = self.configuration.actor_run_id
        if not run_id:
            self._local_logger.warning("Actor.get_proxy() requires actor_run_id, but current configuration does not provide it.")
            return None
        self._local_logger.info(
            "Acquiring runtime proxy. run_id=%s mode=%s country=%r source=%r pool=%r",
            run_id,
            request_config.get("mode"),
            request_config.get("country"),
            request_config.get("source"),
            request_config.get("pool"),
        )
        try:
            proxy_payload = await self.xcrawl_client.run(run_id).acquire_proxy(**request_config)
        except Exception as exc:
            self._local_logger.warning(
                "Runtime proxy acquisition failed. run_id=%s mode=%s error=%s",
                run_id,
                request_config.get("mode"),
                exc,
            )
            return None

        self._local_logger.debug(
            "Runtime proxy acquired successfully. run_id=%s payload_summary=%s",
            run_id,
            self._summarize_value_for_log(proxy_payload),
        )
        return proxy_payload

    async def use_state(
        self,
        default_value: dict[str, Any] | None = None,
        key: str | None = None,
        kvs_name: str | None = None,
        *,
        force_cloud: bool = False,
    ) -> dict[str, Any]:
        self._ensure_context()
        # Remember which KVS instances were used for autosaved state so they can all
        # be flushed during Actor shutdown.
        self._use_state_stores.add(kvs_name)
        self._local_logger.debug(
            "Resolving auto-saved actor state. key=%s kvs_name=%r force_cloud=%s default_value_summary=%s",
            key or DEFAULT_STATE_KEY,
            kvs_name,
            force_cloud,
            self._summarize_value_for_log(default_value),
        )
        kvs = await self.open_key_value_store(name=kvs_name, force_cloud=force_cloud)
        state = await kvs.get_auto_saved_value(key or DEFAULT_STATE_KEY, default_value)
        self._local_logger.debug(
            "Auto-saved actor state loaded. key=%s kvs_name=%r state_summary=%s",
            key or DEFAULT_STATE_KEY,
            kvs_name,
            self._summarize_value_for_log(state),
        )
        return state

    async def _save_actor_state(self) -> None:
        """Persist every KVS touched by `use_state()` so shutdown does not lose autosaved values."""
        self._local_logger.debug("Persisting actor autosaved state stores. store_count=%d", len(self._use_state_stores))
        for kvs_name in self._use_state_stores:
            self._local_logger.debug("Persisting autosaved actor state store. kvs_name=%r", kvs_name)
            store = await self.open_key_value_store(name=kvs_name)
            await store.persist_autosaved_values()
        self._local_logger.debug("Actor autosaved state persistence finished.")

    def _default_storage_dir(self) -> str:
        """Resolve the local storage directory using the same env precedence as before."""
        env_storage = os.getenv("XCRAWL_LOCAL_STORAGE_DIR") or os.getenv("CRAWLEE_STORAGE_DIR")
        if env_storage:
            self._local_logger.debug("Using storage directory from environment. storage_dir=%s", env_storage)
            return env_storage
        fallback_storage = str(Path.cwd() / "storage")
        self._local_logger.debug("Using default storage directory under the current working directory. storage_dir=%s", fallback_storage)
        return fallback_storage

    def _get_default_exit_process(self) -> bool:
        """Keep the historical default of not calling `sys.exit()` automatically."""
        with suppress(ImportError):
            import IPython  # noqa: F401

            self._local_logger.debug("Detected IPython environment. Actor will not exit the process automatically.")
            return False
        with suppress(ImportError):
            import pytest  # noqa: F401

            self._local_logger.debug("Detected pytest environment. Actor will not exit the process automatically.")
            return False
        self._local_logger.debug("Using default non-exiting Actor process behavior.")
        return False

    def _get_remaining_time(self) -> timedelta | None:
        """Translate the runtime's absolute timeout deadline into a relative duration."""
        timeout_at = self.configuration.timeout_at
        if self.is_at_home() and timeout_at:
            try:
                # The platform passes an absolute deadline, but API calls expect a
                # relative timeout in seconds.
                remaining = max(timeout_at - datetime.now(tz=timezone.utc), timedelta(0))
                self._local_logger.debug("Calculated remaining actor runtime timeout. remaining=%s", remaining)
                return remaining
            except Exception as exc:
                self._local_logger.exception(
                    "Failed to calculate remaining actor runtime timeout.",
                    exc_info=(type(exc), exc, exc.__traceback__),
                )
                return None
        return None

    def _normalize_timeout(self, timeout: timedelta | None | Literal["inherit", "RemainingTime"]) -> int | None:
        """Normalize timeout helper inputs to the integer seconds expected by API client methods."""
        # API helpers accept special strings that mean "reuse the current run's
        # remaining platform time" instead of a literal duration.
        if timeout in {"inherit", "RemainingTime"}:
            remaining = self._get_remaining_time()
            normalized = int(remaining.total_seconds()) if remaining is not None else None
            self._local_logger.debug(
                "Normalized inherited actor timeout. original_timeout=%r normalized_timeout=%r",
                timeout,
                normalized,
            )
            return normalized
        if timeout is None:
            self._local_logger.debug("Normalized actor timeout. original_timeout=None normalized_timeout=None")
            return None
        if isinstance(timeout, timedelta):
            normalized = int(timeout.total_seconds())
            self._local_logger.debug(
                "Normalized timedelta actor timeout. original_timeout=%s normalized_timeout=%s",
                timeout,
                normalized,
            )
            return normalized
        self._local_logger.error("Received invalid actor timeout value. timeout=%r", timeout)
        raise ValueError(f"Invalid timeout: {timeout!r}")


# Expose a lazy proxy so user code can import `Actor` once and either use it as a
# singleton-style facade or call `Actor(...)` to create an isolated runtime instance.
Actor = cast(_ActorType, Proxy(_ActorType))
