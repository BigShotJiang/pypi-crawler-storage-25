from __future__ import annotations

import ipaddress
import os
import re
from dataclasses import dataclass, field
from re import Pattern
from typing import TYPE_CHECKING, Any
from urllib.parse import urlencode, urljoin, urlparse

import requests
from yarl import URL

from crawlee.proxy_configuration import ProxyConfiguration as CrawleeProxyConfiguration
from crawlee.proxy_configuration import ProxyInfo as CrawleeProxyInfo
from crawlee.proxy_configuration import _NewUrlFunction

from .configuration import Configuration

if TYPE_CHECKING:
    from crawlee import Request

    from .client import XcrawlApiClientAsync

XCRAWL_PROXY_VALUE_REGEX = re.compile(r"^[\w._~]+$")
COUNTRY_CODE_REGEX = re.compile(r"^[A-Z]{2}$")
SUBDIVISION_CODE_REGEX = re.compile(r"^[A-Z0-9]{1,3}$")
SESSION_ID_MAX_LENGTH = 50


def _check(
    value: Any,
    *,
    label: str | None,
    pattern: Pattern | None = None,
    min_length: int | None = None,
    max_length: int | None = None,
) -> None:
    error_str = f"Value {value}"
    if label:
        error_str += f" of argument {label}"
    if min_length and len(value) < min_length:
        raise ValueError(f"{error_str} is shorter than minimum allowed length {min_length}")
    if max_length and len(value) > max_length:
        raise ValueError(f"{error_str} is longer than maximum allowed length {max_length}")
    if pattern and not re.fullmatch(pattern, value):
        raise ValueError(f"{error_str} does not match pattern {pattern.pattern!r}")


def is_url(url: str) -> bool:
    try:
        parsed_url = urlparse(urljoin(url, "/"))
        has_all_parts = all([parsed_url.scheme, parsed_url.netloc, parsed_url.path])
        is_domain = "." in parsed_url.netloc
        is_localhost = parsed_url.netloc == "localhost"
        try:
            ipaddress.ip_address(parsed_url.netloc)
            is_ip_address = True
        except Exception:
            is_ip_address = False
        return has_all_parts and any([is_domain, is_localhost, is_ip_address])
    except Exception:
        return False


def _pick_first_value(data: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key not in data:
            continue
        value = data[key]
        if value is None:
            continue
        if isinstance(value, str):
            value = value.strip()
            if not value:
                continue
        return value
    return None


def _default_port_for_scheme(scheme: str) -> int:
    return 443 if scheme == "https" else 80


def _coerce_proxy_url(raw_proxy: str) -> str:
    proxy = str(raw_proxy).strip()
    if not proxy:
        raise ValueError("proxy value cannot be empty")
    return proxy if "://" in proxy else f"http://{proxy}"


def _extract_proxy_candidates(payload: Any) -> list[Any]:
    if isinstance(payload, list):
        return payload

    if not isinstance(payload, dict):
        return []

    for key in ("proxies", "proxy_list", "proxyList", "list", "items", "entries", "records"):
        value = payload.get(key)
        if isinstance(value, list):
            return value

    nested_data = payload.get("data")
    if nested_data is not None:
        nested_candidates = _extract_proxy_candidates(nested_data)
        if nested_candidates:
            return nested_candidates

    if _pick_first_value(payload, "url", "proxy_url", "proxyUrl", "proxy", "host", "hostname", "ip", "address"):
        return [payload]

    return []


def _proxy_info_from_url(
    proxy_url: str,
    *,
    session_id: str | None = None,
    groups: list[str] | None = None,
    country_code: str | None = None,
    subdivision_code: str | None = None,
) -> "ProxyInfo":
    parsed_url = URL(_coerce_proxy_url(proxy_url))
    scheme = parsed_url.scheme or "http"
    hostname = parsed_url.host
    if not hostname:
        raise ValueError(f"Could not resolve proxy hostname from {proxy_url!r}")
    port = parsed_url.port or _default_port_for_scheme(scheme)
    return ProxyInfo(
        url=str(parsed_url),
        scheme=scheme,
        hostname=hostname,
        port=port,
        username=parsed_url.user or "",
        password=parsed_url.password or "",
        session_id=session_id,
        proxy_tier=None,
        groups=list(groups or []),
        country_code=country_code,
        subdivision_code=subdivision_code,
    )


def _proxy_info_from_runtime_candidate(
    candidate: Any,
    *,
    session_id: str | None = None,
    groups: list[str] | None = None,
    country_code: str | None = None,
    subdivision_code: str | None = None,
) -> "ProxyInfo":
    if isinstance(candidate, str):
        return _proxy_info_from_url(
            candidate,
            session_id=session_id,
            groups=groups,
            country_code=country_code,
            subdivision_code=subdivision_code,
        )

    if not isinstance(candidate, dict):
        raise ValueError(f"Unsupported proxy candidate type: {type(candidate).__name__}")

    resolved_session_id = session_id or _pick_first_value(
        candidate,
        "sticky_session",
        "stickySession",
        "session_id",
        "sessionId",
        "session",
    )
    resolved_country = country_code or _pick_first_value(candidate, "country", "country_code", "countryCode")
    resolved_subdivision = subdivision_code or _pick_first_value(
        candidate,
        "subdivision",
        "subdivision_code",
        "subdivisionCode",
        "region",
    )

    direct_proxy_value = _pick_first_value(candidate, "url", "proxy_url", "proxyUrl", "proxy")
    if direct_proxy_value is not None:
        return _proxy_info_from_url(
            str(direct_proxy_value),
            session_id=str(resolved_session_id) if resolved_session_id is not None else None,
            groups=groups,
            country_code=str(resolved_country) if resolved_country is not None else None,
            subdivision_code=str(resolved_subdivision) if resolved_subdivision is not None else None,
        )

    scheme_value = _pick_first_value(candidate, "scheme", "protocol")
    scheme = str(scheme_value).lower() if scheme_value is not None else "http"
    hostname_value = _pick_first_value(candidate, "hostname", "host", "ip", "address")
    if hostname_value is None:
        raise ValueError(f"Runtime proxy candidate is missing host information: {candidate}")
    hostname = str(hostname_value)

    port_value = _pick_first_value(candidate, "port", "proxy_port", "proxyPort")
    port = _default_port_for_scheme(scheme) if port_value is None else int(port_value)

    username_value = _pick_first_value(candidate, "username", "user", "account")
    password_value = _pick_first_value(candidate, "password", "pass", "pwd")
    username = "" if username_value is None else str(username_value)
    password = "" if password_value is None else str(password_value)

    auth_part = ""
    if username:
        auth_part = username
        if password:
            auth_part = f"{auth_part}:{password}"
        auth_part += "@"

    return ProxyInfo(
        url=f"{scheme}://{auth_part}{hostname}:{port}",
        scheme=scheme,
        hostname=hostname,
        port=port,
        username=username,
        password=password,
        session_id=str(resolved_session_id) if resolved_session_id is not None else None,
        proxy_tier=None,
        groups=list(groups or []),
        country_code=str(resolved_country) if resolved_country is not None else None,
        subdivision_code=str(resolved_subdivision) if resolved_subdivision is not None else None,
    )


@dataclass
class ProxyInfo(CrawleeProxyInfo):
    groups: list[str] = field(default_factory=list)
    country_code: str | None = None
    subdivision_code: str | None = None


class ProxyConfiguration(CrawleeProxyConfiguration):
    def __init__(
        self,
        *,
        password: str | None = None,
        groups: list[str] | None = None,
        country_code: str | None = None,
        subdivision_code: str | None = None,
        proxy_urls: list[str | None] | None = None,
        new_url_function: _NewUrlFunction | None = None,
        tiered_proxy_urls: list[list[str | None]] | None = None,
        _actor_config: Configuration | None = None,
        _xcrawl_client: "XcrawlApiClientAsync | None" = None,
    ) -> None:
        actor_config = _actor_config or Configuration.get_global_configuration()
        if groups:
            groups = [str(group) for group in groups]
            for group in groups:
                _check(group, label="groups", pattern=XCRAWL_PROXY_VALUE_REGEX)
        if country_code:
            country_code = str(country_code)
            _check(country_code, label="country_code", pattern=COUNTRY_CODE_REGEX)
        if subdivision_code:
            if not country_code:
                raise ValueError('Cannot set "subdivision_code" without "country_code".')
            subdivision_code = str(subdivision_code)
            _check(subdivision_code, label="subdivision_code", pattern=SUBDIVISION_CODE_REGEX)
        if (proxy_urls or new_url_function or tiered_proxy_urls) and (groups or country_code or subdivision_code):
            raise ValueError("Cannot combine custom proxies with managed proxy options.")

        self._configuration = actor_config
        self._xcrawl_client = _xcrawl_client
        self._password = password or self._configuration.proxy_password
        self._groups = list(groups) if groups else []
        self._country_code = country_code
        self._subdivision_code = subdivision_code
        self._uses_managed_proxy = not (proxy_urls or new_url_function or tiered_proxy_urls)

        super().__init__(
            proxy_urls=[f"http://{self._configuration.proxy_hostname}:{self._configuration.proxy_port}"]
            if self._uses_managed_proxy
            else proxy_urls,
            new_url_function=new_url_function,
            tiered_proxy_urls=tiered_proxy_urls,
        )

    def _get_xcrawl_client(self) -> "XcrawlApiClientAsync":
        if self._xcrawl_client is None:
            token = self._configuration.token
            if not token:
                raise RuntimeError(
                    "Proxy runtime API requires a client or token. Pass `_xcrawl_client`, or configure `token`."
                )
            from .client import XcrawlApiClientAsync

            self._xcrawl_client = XcrawlApiClientAsync(
                token=token,
                api_url=self._configuration.api_base_url,
            )
        return self._xcrawl_client

    def _require_actor_run_id(self) -> str:
        run_id = self._configuration.actor_run_id
        if not run_id:
            raise RuntimeError(
                "Runtime proxy acquisition requires `actor_run_id` in the active configuration."
            )
        return run_id

    async def initialize(self) -> None:
        if not self._uses_managed_proxy:
            return
        if self._password:
            return
        token = self._configuration.token
        if token:
            user_info = await self._get_xcrawl_client().user().get()
            if user_info:
                self._password = user_info.get("proxy", {}).get("password")
        if not self._password:
            raise ValueError(
                "Managed proxy password must be provided through `password`, `XCRAWL_PROXY_PASSWORD`, or a valid token."
            )

    async def acquire_proxy(
        self,
        *,
        mode: str,
        source: str | None = None,
        country: str | None = None,
        sticky_session: str | None = None,
        life_seconds: int | None = None,
        count: int | None = None,
        pool: str | None = None,
        js_render: bool | None = None,
        sandbox: str | None = None,
        endpoint: str | None = None,
        validate: bool | None = None,
    ) -> Any:
        normalized_mode = str(mode).strip()
        if not normalized_mode:
            raise ValueError("mode cannot be empty")

        normalized_country = country or self._country_code
        if normalized_country is not None:
            normalized_country = str(normalized_country).upper()
            _check(normalized_country, label="country", pattern=COUNTRY_CODE_REGEX)

        normalized_sticky_session = sticky_session
        if normalized_sticky_session is not None:
            normalized_sticky_session = str(normalized_sticky_session)
            _check(
                normalized_sticky_session,
                label="sticky_session",
                max_length=SESSION_ID_MAX_LENGTH,
                pattern=XCRAWL_PROXY_VALUE_REGEX,
            )

        if life_seconds is not None and life_seconds <= 0:
            raise ValueError("life_seconds must be greater than 0")
        if count is not None and count <= 0:
            raise ValueError("count must be greater than 0")

        client = self._get_xcrawl_client()
        run_id = self._require_actor_run_id()
        return await client.run(run_id).acquire_proxy(
            mode=normalized_mode,
            source=source,
            country=normalized_country,
            sticky_session=normalized_sticky_session,
            life_seconds=life_seconds,
            count=count,
            pool=pool,
            js_render=js_render,
            sandbox=sandbox,
            endpoint=endpoint,
            validate=validate,
        )

    async def acquire_proxy_infos(
        self,
        *,
        mode: str,
        source: str | None = None,
        country: str | None = None,
        sticky_session: str | None = None,
        life_seconds: int | None = None,
        count: int | None = None,
        pool: str | None = None,
        js_render: bool | None = None,
        sandbox: str | None = None,
        endpoint: str | None = None,
        validate: bool | None = None,
    ) -> list["ProxyInfo"]:
        payload = await self.acquire_proxy(
            mode=mode,
            source=source,
            country=country,
            sticky_session=sticky_session,
            life_seconds=life_seconds,
            count=count,
            pool=pool,
            js_render=js_render,
            sandbox=sandbox,
            endpoint=endpoint,
            validate=validate,
        )
        candidates = _extract_proxy_candidates(payload)
        if not candidates:
            raise ValueError(f"Runtime proxy response does not contain any proxy candidates: {payload}")

        resolved_country = (country or self._country_code)
        resolved_country = str(resolved_country).upper() if resolved_country else None
        return [
            _proxy_info_from_runtime_candidate(
                candidate,
                session_id=sticky_session,
                groups=self._groups,
                country_code=resolved_country,
                subdivision_code=self._subdivision_code,
            )
            for candidate in candidates
        ]

    async def acquire_proxy_info(
        self,
        *,
        mode: str,
        source: str | None = None,
        country: str | None = None,
        sticky_session: str | None = None,
        life_seconds: int | None = None,
        count: int | None = None,
        pool: str | None = None,
        js_render: bool | None = None,
        sandbox: str | None = None,
        endpoint: str | None = None,
        validate: bool | None = None,
    ) -> "ProxyInfo":
        proxy_infos = await self.acquire_proxy_infos(
            mode=mode,
            source=source,
            country=country,
            sticky_session=sticky_session,
            life_seconds=life_seconds,
            count=count,
            pool=pool,
            js_render=js_render,
            sandbox=sandbox,
            endpoint=endpoint,
            validate=validate,
        )
        return proxy_infos[0]

    async def acquire_proxy_url(
        self,
        *,
        mode: str,
        source: str | None = None,
        country: str | None = None,
        sticky_session: str | None = None,
        life_seconds: int | None = None,
        count: int | None = None,
        pool: str | None = None,
        js_render: bool | None = None,
        sandbox: str | None = None,
        endpoint: str | None = None,
        validate: bool | None = None,
    ) -> str:
        proxy_info = await self.acquire_proxy_info(
            mode=mode,
            source=source,
            country=country,
            sticky_session=sticky_session,
            life_seconds=life_seconds,
            count=count,
            pool=pool,
            js_render=js_render,
            sandbox=sandbox,
            endpoint=endpoint,
            validate=validate,
        )
        return proxy_info.url

    async def new_proxy_info(
        self,
        session_id: str | None = None,
        request: "Request | None" = None,
        proxy_tier: int | None = None,
    ) -> ProxyInfo | None:
        if session_id is not None:
            _check(session_id, label="session_id", max_length=SESSION_ID_MAX_LENGTH, pattern=XCRAWL_PROXY_VALUE_REGEX)
        proxy_info = await super().new_proxy_info(session_id=session_id, request=request, proxy_tier=proxy_tier)
        if proxy_info is None:
            return None
        if self._uses_managed_proxy:
            parsed_url = URL(proxy_info.url)
            username = self._get_username(session_id)
            return ProxyInfo(
                url=f"http://{username}:{self._password or ''}@{parsed_url.host}:{parsed_url.port}",
                scheme="http",
                hostname=proxy_info.hostname,
                port=proxy_info.port,
                username=username,
                password=self._password or "",
                session_id=proxy_info.session_id,
                proxy_tier=proxy_info.proxy_tier,
                groups=self._groups,
                country_code=self._country_code,
                subdivision_code=self._subdivision_code,
            )
        return ProxyInfo(
            url=proxy_info.url,
            scheme=proxy_info.scheme,
            hostname=proxy_info.hostname,
            port=proxy_info.port,
            username=proxy_info.username,
            password=proxy_info.password,
            session_id=proxy_info.session_id,
            proxy_tier=proxy_info.proxy_tier,
        )

    def _get_username(self, session_id: int | str | None = None) -> str:
        if session_id is not None:
            session_id = f"{session_id}"
        parts: list[str] = []
        if self._groups:
            parts.append(f"groups-{'+'.join(self._groups)}")
        if session_id is not None:
            parts.append(f"session-{session_id}")
        if self._country_code:
            if self._subdivision_code:
                parts.append(f"country-{self._country_code}_{self._subdivision_code}")
            else:
                parts.append(f"country-{self._country_code}")
        if not parts:
            return "auto"
        return ",".join(parts)


# ---------------------------------------------------------------------------
# Debug Proxy (SmartProxy)
# ---------------------------------------------------------------------------

SMARTPROXY_API_BASE_URL = "https://api.smartproxy.cn/web_v1/ip/get-ip-v3"


@dataclass(frozen=True)
class DebugProxyConfig:
    enabled: bool = False
    app_key: str | None = None
    api_url: str | None = None
    country: str = "US"
    endpoint: str = ""
    life_minutes: int = 5
    count: int = 1
    timeout_seconds: int = 30
    validate: bool = True

    @classmethod
    def from_input(cls, actor_input: dict[str, Any]) -> DebugProxyConfig:
        raw = actor_input.get("debugProxy") or actor_input.get("debug_proxy")
        if raw in (None, False, "", 0):
            return cls(enabled=False)
        if raw is True:
            raw = {}
        if not isinstance(raw, dict):
            raise ValueError("debugProxy must be a boolean or object")
        return cls(
            enabled=True,
            app_key=raw.get("appKey") or raw.get("app_key"),
            api_url=raw.get("apiUrl") or raw.get("api_url"),
            country=(raw.get("country") or raw.get("cc") or "US").upper(),
            endpoint=raw.get("endpoint") or raw.get("ep") or "",
            life_minutes=max(1, min(30, int(raw.get("lifeMinutes") or raw.get("life") or 5))),
            count=max(1, min(10, int(raw.get("count") or raw.get("num") or 1))),
            timeout_seconds=max(1, min(60, int(raw.get("timeoutSeconds") or raw.get("timeout") or 30))),
            validate=_to_bool(raw.get("validate", raw.get("validateProxy")), default=True),
        )


def fetch_debug_proxy(config: DebugProxyConfig) -> str | None:
    if not config.enabled:
        return None

    url = config.api_url or os.getenv("XCRAWL_DEBUG_PROXY_API_URL", "").strip()
    if not url:
        app_key = config.app_key or os.getenv("XCRAWL_DEBUG_PROXY_APP_KEY", "").strip()
        if not app_key:
            raise ValueError("debug proxy requires XCRAWL_DEBUG_PROXY_APP_KEY or debugProxy.appKey")
        params = {
            "app_key": app_key,
            "pt": "9",
            "num": str(config.count),
            "ep": config.endpoint,
            "cc": config.country,
            "state": "",
            "city": "",
            "life": str(config.life_minutes),
            "protocol": "1",
            "format": "json",
            "lb": "\r\n",
        }
        url = f"{SMARTPROXY_API_BASE_URL}?{urlencode(params)}"

    response = requests.get(url, timeout=config.timeout_seconds)
    response.raise_for_status()
    payload = response.json()
    proxy_list = payload.get("data", {}).get("list", [])
    if not isinstance(proxy_list, list) or not proxy_list:
        raise ValueError(f"debug proxy response does not contain proxy list: {payload}")

    errors: list[str] = []
    for raw_proxy in proxy_list:
        proxy = str(raw_proxy).strip()
        if not proxy:
            continue
        if not config.validate:
            return proxy
        proxy_url = proxy if "://" in proxy else f"http://{proxy}"
        try:
            resp = requests.get(
                "http://httpbin.org/ip",
                proxies={"http": proxy_url, "https": proxy_url},
                timeout=config.timeout_seconds,
            )
            if resp.status_code < 400:
                return proxy
            errors.append(f"status={resp.status_code}")
        except requests.RequestException as exc:
            errors.append(f"{type(exc).__name__}: {exc}")

    if errors:
        raise ValueError(f"debug proxy validation failed for {len(errors)} candidate(s): {errors[-1]}")
    raise ValueError("debug proxy response returned only empty proxy entries")


def _to_bool(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on"}
    return default
