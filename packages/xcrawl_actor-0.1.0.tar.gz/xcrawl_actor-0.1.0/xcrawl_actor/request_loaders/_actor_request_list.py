from __future__ import annotations

import asyncio
import json
import re
from typing import Annotated, Any

from pydantic import BaseModel, Field, TypeAdapter
from typing_extensions import override

from crawlee import Request
from crawlee._types import HttpMethod
from crawlee.http_clients import HttpClient, ImpitHttpClient
from crawlee.request_loaders import RequestList

_URL_PATTERN = re.compile(r"https?://[^\s<>'\",]+")


class _RequestDefaults(BaseModel):
    method: HttpMethod = "GET"
    payload: str | bytes | None = None
    headers: Annotated[dict[str, str], Field(default_factory=dict)]
    user_data: Annotated[dict[str, Any], Field(default_factory=dict, alias="userData")]


class _DirectUrlSource(_RequestDefaults):
    url: str


class _RemoteUrlSource(_RequestDefaults):
    requests_from_url: str = Field(alias="requestsFromUrl")


_source_adapter = TypeAdapter(list[_DirectUrlSource | _RemoteUrlSource])


class ActorRequestList(RequestList):
    """Request list builder for Actor-style `requestListSources` input."""

    def __init__(
        self,
        requests=None,
        *,
        name: str | None = None,
        persist_state_key: str | None = None,
        persist_requests_key: str | None = None,
        known_total_count: int | None = None,
    ) -> None:
        super().__init__(
            requests=requests,
            name=name,
            persist_state_key=persist_state_key,
            persist_requests_key=persist_requests_key,
        )
        self._known_total_count = known_total_count

    @classmethod
    async def open(
        cls,
        *,
        name: str | None = None,
        request_list_sources_input: list[dict[str, Any]] | None = None,
        http_client: HttpClient | None = None,
    ) -> "ActorRequestList":
        """Create a request list from standard Actor input sources.

        Supported source shapes:
        - `{"url": "https://example.com"}`
        - `{"requestsFromUrl": "https://example.com/urls.txt"}`
        """
        request_list_sources_input = request_list_sources_input or []
        http_client = http_client or ImpitHttpClient()

        parsed_sources = _source_adapter.validate_python(request_list_sources_input)
        direct_sources = [source for source in parsed_sources if isinstance(source, _DirectUrlSource)]
        remote_sources = [source for source in parsed_sources if isinstance(source, _RemoteUrlSource)]

        requests = cls._requests_from_direct_sources(direct_sources)
        if remote_sources:
            requests.extend(await cls._requests_from_remote_sources(remote_sources, http_client))

        return cls(
            requests=requests,
            name=name,
            known_total_count=len(requests),
        )

    @override
    async def get_total_count(self) -> int:
        if self._known_total_count is not None:
            return self._known_total_count
        return await super().get_total_count()

    @classmethod
    async def _requests_from_remote_sources(
        cls,
        sources: list[_RemoteUrlSource],
        http_client: HttpClient,
    ) -> list[Request]:
        tasks = [cls._load_remote_source(source, http_client) for source in sources]
        batches = await asyncio.gather(*tasks)
        return [request for batch in batches for request in batch]

    @classmethod
    async def _load_remote_source(
        cls,
        source: _RemoteUrlSource,
        http_client: HttpClient,
    ) -> list[Request]:
        response = await http_client.send_request(method="GET", url=source.requests_from_url)
        body = await response.read()
        return cls._parse_remote_body(body.decode("utf-8", errors="replace"), source)

    @classmethod
    def _parse_remote_body(cls, body: str, source: _RemoteUrlSource) -> list[Request]:
        stripped_body = body.strip()
        if stripped_body:
            try:
                parsed = json.loads(stripped_body)
            except json.JSONDecodeError:
                parsed = None
            else:
                if isinstance(parsed, list):
                    requests = cls._requests_from_json_items(parsed, source)
                    if requests:
                        return requests

        urls: list[str] = []
        for line in stripped_body.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            urls.extend(match.group(0).rstrip(".,;)") for match in _URL_PATTERN.finditer(line))

        return [cls._build_request(url=url, defaults=source) for url in urls]

    @classmethod
    def _requests_from_json_items(cls, items: list[Any], source: _RemoteUrlSource) -> list[Request]:
        requests: list[Request] = []
        for item in items:
            if isinstance(item, str):
                requests.append(cls._build_request(url=item, defaults=source))
                continue
            if not isinstance(item, dict):
                continue
            if "url" not in item:
                continue

            merged_headers = {**source.headers, **dict(item.get("headers", {}))}
            merged_user_data = {**source.user_data, **dict(item.get("userData", {}))}
            requests.append(
                Request.from_url(
                    url=item["url"],
                    method=item.get("method", source.method),
                    payload=item.get("payload", source.payload),
                    headers=merged_headers,
                    user_data=merged_user_data,
                )
            )
        return requests

    @classmethod
    def _requests_from_direct_sources(cls, sources: list[_DirectUrlSource]) -> list[Request]:
        return [cls._build_request(url=source.url, defaults=source) for source in sources]

    @staticmethod
    def _build_request(url: str, defaults: _RequestDefaults) -> Request:
        return Request.from_url(
            url=url,
            method=defaults.method,
            payload=defaults.payload,
            headers=defaults.headers,
            user_data=defaults.user_data,
        )


RequestList = ActorRequestList
