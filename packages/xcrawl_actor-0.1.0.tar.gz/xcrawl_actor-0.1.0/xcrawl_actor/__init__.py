from importlib import metadata

from crawlee import Request
from crawlee.events import (
    Event,
    EventAbortingData,
    EventExitData,
    EventListener,
    EventMigratingData,
    EventPersistStateData,
    EventSystemInfoData,
)

from .actor import Actor
from .configuration import Configuration
from .models import ActorJobStatus, ActorRun, Webhook, WebhookCondition, WebhookDispatchStatus, WebhookEventType
from .proxy import DebugProxyConfig, ProxyConfiguration, ProxyInfo, fetch_debug_proxy
from .request_loaders import ActorRequestList, RequestList

try:
    __version__ = metadata.version("xcrawl-actor")
except metadata.PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "Actor",
    "ActorJobStatus",
    "ActorRequestList",
    "ActorRun",
    "DebugProxyConfig",
    "RequestList",
    "Configuration",
    "Event",
    "EventAbortingData",
    "EventExitData",
    "EventListener",
    "EventMigratingData",
    "EventPersistStateData",
    "EventSystemInfoData",
    "ProxyConfiguration",
    "ProxyInfo",
    "Request",
    "Webhook",
    "WebhookCondition",
    "WebhookDispatchStatus",
    "WebhookEventType",
    "__version__",
    "fetch_debug_proxy",
]
