# xcrawl-actor

`xcrawl-actor` is a Python SDK for building and running Xcrawl Actor workloads.

## Install

```bash
pip install xcrawl-actor
```

## Import

```python
from xcrawl_actor import Actor
```

The distribution name on PyPI uses a hyphen, but the Python import path uses an underscore.  
`from xcrawl-actor import Actor` is not valid Python syntax.

## Quick Start

```python
from xcrawl_actor import Actor


async def main() -> None:
    async with Actor:
        Actor.log.info("xcrawl actor started")


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
```

## Development Install

```bash
pip install -e .[dev]
```

## Build And Publish

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```

## Package Layout

- `xcrawl_actor/`: runtime package exported to users.
- `pyproject.toml`: PyPI metadata and build configuration.
- `MANIFEST.in`: source distribution include rules.

## Repository

- Homepage: `https://gitee.com/youquinc/xcrawlactorsdk`
- Repository: `https://gitee.com/youquinc/xcrawlactorsdk.git`
