# xcrawl-actor

`xcrawl-actor` 是一个用于构建和运行 Xcrawl Actor 的 Python SDK。

## 安装

```bash
pip install xcrawl-actor
```

## 导入

```python
from xcrawl_actor import Actor
```

PyPI 上的发行包名可以使用中划线，但 Python 导入路径不能带 `-`。  
所以正确写法是 `from xcrawl_actor import Actor`，不是 `from xcrawl-actor import Actor`。

## 快速开始

```python
from xcrawl_actor import Actor


async def main() -> None:
    async with Actor:
        Actor.log.info("xcrawl actor started")


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
```

## 开发安装

```bash
pip install -e .[dev]
```

## 打包与发布

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```

## 关键文件

- `xcrawl_actor/`：实际安装给用户使用的 Python 包。
- `pyproject.toml`：PyPI 元数据和构建配置。
- `MANIFEST.in`：控制源码包要包含哪些文件。

## 仓库地址

- 首页：`https://gitee.com/youquinc/xcrawlactorsdk`
- 仓库：`https://gitee.com/youquinc/xcrawlactorsdk.git`
