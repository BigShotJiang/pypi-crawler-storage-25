from __future__ import annotations

from paperless_mcp.models.document import (
    CustomFieldInstance,
    Document,
    DocumentHistoryEntry,
    DocumentMetadata,
    DocumentNote,
    DocumentPatch,
    DocumentSuggestions,
)


def test_document_minimal(load_fixture) -> None:
    doc = Document.model_validate(load_fixture("document_minimal.json"))
    assert doc.id == 1
    assert doc.title == "Test Document"
    assert doc.correspondent is None
    assert doc.tags == []


def test_document_full(load_fixture) -> None:
    doc = Document.model_validate(load_fixture("document_full.json"))
    assert doc.id == 42
    assert doc.tags == [1, 4, 9]
    assert doc.notes[0].note == "Paid 2026-04-22"
    assert doc.custom_fields[0].field == 2


def test_document_forward_compatible(load_fixture) -> None:
    doc = Document.model_validate(load_fixture("document_full.json"))
    assert doc.some_future_paperless_field == "that we don't know about yet"  # type: ignore[attr-defined]


def test_document_patch_strict_forbids_extra() -> None:
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        DocumentPatch.model_validate({"nonexistent_field": "x"})


def test_document_patch_allows_partial() -> None:
    patch = DocumentPatch.model_validate({"title": "New title"})
    assert patch.model_dump(exclude_unset=True) == {"title": "New title"}


def test_document_note_roundtrip() -> None:
    note = DocumentNote.model_validate(
        {"id": 5, "note": "hi", "created": "2026-04-23T10:00:00Z", "user": 1}
    )
    assert note.id == 5


def test_document_note_accepts_nested_user_object() -> None:
    """Newer Paperless-NGX returns ``user`` as a nested object, not a bare ID."""
    note = DocumentNote.model_validate(
        {
            "id": 5,
            "note": "hi",
            "created": "2026-04-23T10:00:00Z",
            "user": {
                "id": 3,
                "username": "peter",
                "first_name": "Peter",
                "last_name": "van Liesdonk",
            },
        }
    )
    assert note.user == 3


def test_document_owner_accepts_nested_user_object() -> None:
    """``owner`` likewise: collapses dict input down to the user ID."""
    doc = Document.model_validate(
        {
            "id": 1,
            "title": "x",
            "created": "2026-04-23T10:00:00Z",
            "owner": {"id": 7, "username": "alice"},
        }
    )
    assert doc.owner == 7


def test_document_metadata_accepts_empty() -> None:
    meta = DocumentMetadata.model_validate({})
    assert meta.model_dump(exclude_none=True) == {}


def test_document_history_entry_roundtrip() -> None:
    entry = DocumentHistoryEntry.model_validate(
        {"timestamp": "2026-04-23T10:00:00Z", "action": "modify", "actor": "peter"}
    )
    assert entry.action == "modify"
    assert entry.actor == "peter"


def test_document_history_entry_accepts_nested_actor_object() -> None:
    """Newer Paperless-NGX returns ``actor`` as a nested user object."""
    entry = DocumentHistoryEntry.model_validate(
        {
            "timestamp": "2026-04-23T10:00:00Z",
            "action": "modify",
            "actor": {"id": 3, "username": "peter", "first_name": "Peter"},
        }
    )
    assert entry.actor == "peter"


def test_user_id_rejects_dict_without_id_key() -> None:
    """A dict without ``id`` is malformed upstream — surface it, don't drop it silently."""
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        DocumentNote.model_validate(
            {
                "id": 5,
                "note": "hi",
                "created": "2026-04-23T10:00:00Z",
                "user": {"username": "alice"},
            }
        )


def test_username_rejects_dict_without_username_key() -> None:
    """Same contract for ``actor``: a dict without ``username`` must raise."""
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        DocumentHistoryEntry.model_validate(
            {
                "timestamp": "2026-04-23T10:00:00Z",
                "action": "modify",
                "actor": {"id": 3},
            }
        )


def test_document_history_entry_redacts_content_on_create() -> None:
    # Create events carry ["None", "<blob>"] — keep the marker, redact the blob.
    entry = DocumentHistoryEntry.model_validate(
        {
            "timestamp": "2026-04-23T10:00:00Z",
            "action": "create",
            "actor": None,
            "changes": {
                "content": ["None", "A" * 50_000],
                "title": ["None", "Invoice"],
            },
        }
    )
    assert entry.changes is not None
    content_change = entry.changes["content"]
    assert content_change[0] == "None"
    assert "A" * 50_000 not in content_change[1]
    assert "redacted" in content_change[1].lower()
    assert entry.changes["title"] == ["None", "Invoice"]


def test_document_history_entry_redacts_both_sides_on_modify() -> None:
    # Modify events carry ["<old>", "<new>"] — both can be 50+ kB, redact both.
    entry = DocumentHistoryEntry.model_validate(
        {
            "timestamp": "2026-04-23T10:00:00Z",
            "action": "modify",
            "actor": "peter",
            "changes": {"content": ["B" * 50_000, "A" * 50_000]},
        }
    )
    assert entry.changes is not None
    content_change = entry.changes["content"]
    assert "B" * 50_000 not in content_change[0]
    assert "A" * 50_000 not in content_change[1]
    assert "redacted" in content_change[0].lower()
    assert "redacted" in content_change[1].lower()


def test_document_history_entry_preserves_none_on_delete() -> None:
    # Delete-style events carry ["<old>", None] — keep the None terminator.
    entry = DocumentHistoryEntry.model_validate(
        {
            "timestamp": "2026-04-23T10:00:00Z",
            "action": "delete",
            "actor": "peter",
            "changes": {"content": ["C" * 50_000, None]},
        }
    )
    assert entry.changes is not None
    content_change = entry.changes["content"]
    assert content_change[1] is None
    assert "C" * 50_000 not in content_change[0]
    assert "redacted" in content_change[0].lower()


def test_document_history_entry_redacts_non_list_content() -> None:
    # Defensive: if Paperless sends content as a scalar, redact wholesale.
    entry = DocumentHistoryEntry.model_validate(
        {
            "timestamp": "2026-04-23T10:00:00Z",
            "action": "modify",
            "actor": "peter",
            "changes": {"content": "A" * 50_000},
        }
    )
    assert entry.changes is not None
    assert "A" * 50_000 not in entry.changes["content"]
    assert "redacted" in entry.changes["content"].lower()


def test_document_history_entry_no_changes_field() -> None:
    """Entries without a ``changes`` dict still parse fine."""
    entry = DocumentHistoryEntry.model_validate(
        {"timestamp": "2026-04-23T10:00:00Z", "action": "modify", "actor": "peter"}
    )
    assert entry.changes is None


def test_document_history_entry_changes_without_content_unchanged() -> None:
    entry = DocumentHistoryEntry.model_validate(
        {
            "timestamp": "2026-04-23T10:00:00Z",
            "action": "modify",
            "actor": "peter",
            "changes": {"title": ["Old", "New"]},
        }
    )
    assert entry.changes == {"title": ["Old", "New"]}


def test_document_suggestions_accepts_empty_lists() -> None:
    s = DocumentSuggestions.model_validate(
        {"tags": [], "correspondents": [], "document_types": [], "dates": []}
    )
    assert s.tags == []


def test_custom_field_instance_variadic_value() -> None:
    inst = CustomFieldInstance.model_validate({"field": 2, "value": 42})
    assert inst.value == 42
    inst2 = CustomFieldInstance.model_validate({"field": 3, "value": None})
    assert inst2.value is None
