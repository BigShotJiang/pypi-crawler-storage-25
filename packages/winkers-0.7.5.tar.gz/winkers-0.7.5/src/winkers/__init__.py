"""Winkers — architectural context layer for AI coding agents."""

__version__ = "0.7.5"
