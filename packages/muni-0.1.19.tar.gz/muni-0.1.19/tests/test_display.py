import unittest

from muni import display


class DisplayTests(unittest.TestCase):
    def test_spaces_table_marks_active_space(self) -> None:
        output = display.format_spaces_table(
            [
                {"id": "space-1", "name": "Alpha", "owner_id": "owner"},
                {"id": "space-2", "name": "Beta", "owner_id": "owner"},
            ],
            active_space_id="space-2",
        )
        self.assertIn("*", output)
        self.assertIn("space-2", output)

    def test_nodes_table_includes_columns(self) -> None:
        output = display.format_nodes_table([
            {
                "id": "node-1",
                "type": "structure",
                "title": "1UBQ",
                "hasScript": True,
                "positionX": 12,
                "positionY": 34,
            },
        ])
        self.assertIn("Type", output)
        self.assertIn("Title", output)
        self.assertIn("Script", output)
        self.assertIn("Position", output)
        self.assertIn("(12, 34)", output)
        self.assertIn("yes", output)


if __name__ == "__main__":
    unittest.main()
