"""Low-level HTTP helpers for Supabase PostgREST + Auth API (stdlib only)."""

import json
import urllib.request
import urllib.error
from typing import Any

from .exceptions import APIError, AuthError, NotFoundError


def _request(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: dict | None = None,
) -> tuple[int, Any]:
    """Make an HTTP request, return (status_code, parsed_json)."""
    data = json.dumps(body).encode() if body else None
    hdrs = headers or {}
    if body and "Content-Type" not in hdrs:
        hdrs["Content-Type"] = "application/json"

    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode()
            parsed = json.loads(raw) if raw else None
            return resp.status, parsed
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            parsed = {"message": raw}
        return e.code, parsed


def auth_login(supabase_url: str, publishable_key: str, email: str, password: str) -> dict:
    """POST /auth/v1/token?grant_type=password → tokens + user info."""
    url = f"{supabase_url}/auth/v1/token?grant_type=password"
    headers = {"apikey": publishable_key, "Content-Type": "application/json"}
    status, data = _request(url, method="POST", headers=headers, body={"email": email, "password": password})
    if status == 400:
        msg = data.get("error_description") or data.get("msg") or "Invalid credentials"
        raise AuthError(msg)
    if status != 200:
        raise APIError(f"Login failed: {data}", status)
    return data


def auth_refresh(supabase_url: str, publishable_key: str, refresh_token: str) -> dict:
    """POST /auth/v1/token?grant_type=refresh_token → new tokens."""
    url = f"{supabase_url}/auth/v1/token?grant_type=refresh_token"
    headers = {"apikey": publishable_key, "Content-Type": "application/json"}
    status, data = _request(url, method="POST", headers=headers, body={"refresh_token": refresh_token})
    if status != 200:
        raise AuthError(f"Token refresh failed: {data}")
    return data


def postgrest_get(
    supabase_url: str,
    publishable_key: str,
    access_token: str,
    path: str,
    params: str = "",
) -> Any:
    """GET on PostgREST. Returns parsed JSON."""
    url = f"{supabase_url}/rest/v1/{path}"
    if params:
        url += f"?{params}"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "apikey": publishable_key,
        "Content-Type": "application/json",
    }
    status, data = _request(url, headers=headers)
    if status == 404:
        raise NotFoundError(f"Not found: {path}")
    if status != 200:
        raise APIError(f"PostgREST GET {path} failed: {data}", status)
    return data


def postgrest_post(
    supabase_url: str,
    publishable_key: str,
    access_token: str,
    path: str,
    body: dict,
    *,
    prefer: str = "return=representation",
) -> Any:
    """POST on PostgREST (INSERT). Returns parsed JSON."""
    url = f"{supabase_url}/rest/v1/{path}"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "apikey": publishable_key,
        "Content-Type": "application/json",
        "Prefer": prefer,
    }
    status, data = _request(url, method="POST", headers=headers, body=body)
    if status not in (200, 201):
        raise APIError(f"PostgREST POST {path} failed: {data}", status)
    return data


def postgrest_patch(
    supabase_url: str,
    publishable_key: str,
    access_token: str,
    path: str,
    body: dict,
    params: str = "",
    *,
    prefer: str = "return=representation",
) -> Any:
    """PATCH on PostgREST (UPDATE). Returns parsed JSON."""
    url = f"{supabase_url}/rest/v1/{path}"
    if params:
        url += f"?{params}"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "apikey": publishable_key,
        "Content-Type": "application/json",
        "Prefer": prefer,
    }
    status, data = _request(url, method="PATCH", headers=headers, body=body)
    if status not in (200, 204):
        raise APIError(f"PostgREST PATCH {path} failed: {data}", status)
    return data


def postgrest_delete(
    supabase_url: str,
    publishable_key: str,
    access_token: str,
    path: str,
    params: str = "",
) -> Any:
    """DELETE on PostgREST."""
    url = f"{supabase_url}/rest/v1/{path}"
    if params:
        url += f"?{params}"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "apikey": publishable_key,
        "Content-Type": "application/json",
    }
    status, data = _request(url, method="DELETE", headers=headers)
    if status not in (200, 204):
        raise APIError(f"PostgREST DELETE {path} failed: {data}", status)
    return data


def rpc_call(
    supabase_url: str,
    publishable_key: str,
    access_token: str,
    function_name: str,
    params: dict,
) -> Any:
    """POST /rest/v1/rpc/{function_name} — call a Supabase RPC function."""
    url = f"{supabase_url}/rest/v1/rpc/{function_name}"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "apikey": publishable_key,
        "Content-Type": "application/json",
    }
    status, data = _request(url, method="POST", headers=headers, body=params)
    if status != 200:
        raise APIError(f"RPC {function_name} failed: {data}", status)
    return data
