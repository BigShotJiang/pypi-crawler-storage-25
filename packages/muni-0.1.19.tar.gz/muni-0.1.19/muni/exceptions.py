"""Error hierarchy for the Muni CLI."""


class MuniError(Exception):
    """Base error for all Muni operations."""


class AuthError(MuniError):
    """Authentication or authorization failure."""


class NotFoundError(MuniError):
    """Resource not found (tool, job, file, space)."""


class APIError(MuniError):
    """Unexpected HTTP error from API or Supabase."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class JobFailedError(MuniError):
    """Job completed with failed status."""

    def __init__(self, call_id: str, error: str | None = None):
        msg = f"Job {call_id} failed"
        if error:
            msg += f": {error}"
        super().__init__(msg)
        self.call_id = call_id
        self.error = error


class JobCancelledError(MuniError):
    """Job was cancelled before completion."""

    def __init__(self, call_id: str):
        super().__init__(f"Job {call_id} was cancelled")
        self.call_id = call_id


class JobTimeoutError(MuniError):
    """Timed out waiting for job completion."""

    def __init__(self, call_id: str, timeout: int):
        super().__init__(f"Job {call_id} did not complete within {timeout}s")
        self.call_id = call_id
        self.timeout = timeout
