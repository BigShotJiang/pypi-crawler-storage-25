"""Login, logout, token refresh, and credential storage.

The CLI supports three login flows, in order of preference:

    browser  (default)  — OAuth 2.0 authorization code + PKCE, localhost
                          loopback. Used by `muni login`.
    device              — RFC 8628 device authorization grant. Used by
                          `muni login --device` (no browser / headless).
    password  (legacy)  — email + password against Supabase Auth. Used by
                          `muni login --password` or CI environments.

Access tokens returned by flows (1) and (2) are Supabase-compatible JWTs
minted by the muni app; refresh tokens are opaque CLI tokens stored in
muni_cli_tokens. Flow (3) stores Supabase's own tokens directly.
"""

import base64
import getpass
import json
import time

from . import oauth
from . import supabase as sb
from .config import (
    clear_credentials,
    load_config,
    load_credentials,
    save_credentials,
)
from .exceptions import AuthError, MuniError


# ─── Shared helpers ──────────────────────────────────────────────────────────

def _decode_jwt_payload(token: str) -> dict:
    """Decode a JWT payload without verifying the signature."""
    parts = token.split(".")
    if len(parts) != 3:
        raise AuthError("Invalid JWT format")
    payload = parts[1]
    padding = (-len(payload)) % 4
    if padding:
        payload += "=" * padding
    return json.loads(base64.urlsafe_b64decode(payload))


def _get_supabase_config() -> tuple[str, str]:
    cfg = load_config()
    url = cfg.get("supabase_url")
    key = cfg.get("supabase_publishable_key")
    if not url or not key:
        raise MuniError(
            "Supabase not configured. Run 'muni config' or set MUNI_SUPABASE_URL and MUNI_SUPABASE_PUBLISHABLE_KEY."
        )
    return url, key


def _get_app_url() -> str:
    cfg = load_config()
    app_url = cfg.get("app_url")
    if not app_url:
        raise MuniError(
            "No app_url configured. Run 'muni config' or set MUNI_APP_URL."
        )
    return app_url


def _store_oauth_token(data: dict, fallback_email: str | None = None) -> dict:
    """Normalize an app /api/cli/token response into stored credentials."""
    user = data.get("user") or {}
    expires_at = data.get("expires_at")
    if not expires_at:
        expires_at = int(time.time()) + int(data.get("expires_in", 3600))
    creds = {
        "access_token": data["access_token"],
        "refresh_token": data["refresh_token"],
        "expires_at": int(expires_at),
        "user_id": user.get("id", ""),
        "email": user.get("email") or fallback_email or "",
    }
    save_credentials(creds)
    return creds


def _is_cli_refresh_token(token: str | None) -> bool:
    """CLI refresh tokens are minted by the app and prefixed 'mcli_'. Supabase
    refresh tokens (legacy password flow) have no such prefix."""
    return bool(token) and token.startswith("mcli_")


# ─── Login flows ─────────────────────────────────────────────────────────────

def login(
    *,
    method: str = "browser",
    email: str | None = None,
    password: str | None = None,
    open_browser: bool = True,
    client_name: str | None = None,
) -> dict:
    """Authenticate via the chosen flow and persist credentials.

    method:
        'browser'  — PKCE + localhost loopback (default)
        'device'   — RFC 8628 device code
        'password' — legacy Supabase email/password
    """
    if method == "browser":
        return _login_browser(open_browser=open_browser, client_name=client_name)
    if method == "device":
        return _login_device(open_browser=open_browser, client_name=client_name)
    if method == "password":
        return _login_password(email=email, password=password)
    raise MuniError(f"Unknown login method: {method!r}")


def _login_browser(*, open_browser: bool, client_name: str | None) -> dict:
    app_url = _get_app_url()
    data = oauth.login_browser(app_url, client_name=client_name, open_browser=open_browser)
    return _store_oauth_token(data)


def _login_device(*, open_browser: bool, client_name: str | None) -> dict:
    app_url = _get_app_url()
    data = oauth.login_device(app_url, client_name=client_name, open_browser=open_browser)
    return _store_oauth_token(data)


def _login_password(*, email: str | None, password: str | None) -> dict:
    url, key = _get_supabase_config()

    if not email:
        try:
            email = input("Email: ").strip()
        except EOFError:
            raise AuthError(
                "No TTY available for interactive login. Pass --email/--password or use environment variables."
            )
    if not password:
        try:
            password = getpass.getpass("Password: ")
        except EOFError:
            raise AuthError(
                "No TTY available for interactive login. Pass --email/--password or use environment variables."
            )

    data = sb.auth_login(url, key, email, password)
    expires_at = int(time.time()) + data.get("expires_in", 3600)
    user = data.get("user", {})
    creds = {
        "access_token": data["access_token"],
        "refresh_token": data["refresh_token"],
        "expires_at": expires_at,
        "user_id": user.get("id", ""),
        "email": user.get("email", email),
    }
    save_credentials(creds)
    return creds


# ─── Logout ──────────────────────────────────────────────────────────────────

def logout() -> None:
    """Revoke the stored CLI refresh token (best effort) and clear local creds."""
    creds = load_credentials() or {}
    refresh_token = creds.get("refresh_token")
    if _is_cli_refresh_token(refresh_token):
        try:
            oauth.revoke(_get_app_url(), refresh_token)
        except Exception:
            pass
    clear_credentials()


# ─── Token refresh ───────────────────────────────────────────────────────────

def ensure_token() -> dict:
    """Return valid credentials, refreshing the access token if near expiry."""
    creds = load_credentials()
    if not creds:
        raise AuthError("Not logged in. Run 'muni login' first.")

    # Refresh if expired or within 60s of expiry.
    if time.time() >= creds.get("expires_at", 0) - 60:
        refresh_token = creds.get("refresh_token")
        if not refresh_token:
            raise AuthError("No refresh token. Run 'muni login' again.")

        if _is_cli_refresh_token(refresh_token):
            # New CLI OAuth flow: rotate via the app.
            data = oauth.refresh(_get_app_url(), refresh_token)
            creds = _store_oauth_token(data, fallback_email=creds.get("email"))
        else:
            # Legacy password flow: direct Supabase refresh.
            url, key = _get_supabase_config()
            data = sb.auth_refresh(url, key, refresh_token)
            expires_at = int(time.time()) + data.get("expires_in", 3600)
            user = data.get("user", {})
            creds["access_token"] = data["access_token"]
            creds["refresh_token"] = data["refresh_token"]
            creds["expires_at"] = expires_at
            if user.get("id"):
                creds["user_id"] = user["id"]
            if user.get("email"):
                creds["email"] = user["email"]
            save_credentials(creds)

    return creds


def whoami() -> dict:
    creds = ensure_token()
    return {
        "user_id": creds.get("user_id", ""),
        "email": creds.get("email", ""),
    }
