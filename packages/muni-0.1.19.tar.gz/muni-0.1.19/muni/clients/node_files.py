"""NodeFilesClient — delegates to /api/sdk for all operations."""

from __future__ import annotations
from ._base import SDKClientBase


class NodeFilesClient(SDKClientBase):
    _namespace = "nodeFiles"

    def list(self, node_id: str) -> list[dict]:
        """List workspace files for a node."""
        return self._call("list", nodeId=node_id)

    def get(self, node_id: str, path: str) -> dict:
        """Read a single workspace file including content."""
        return self._call("get", nodeId=node_id, path=path)

    def create(
        self,
        node_id: str,
        *,
        path: str,
        content: str,
        language: str = "python",
        is_entrypoint: bool = False,
    ) -> dict:
        """Create a new workspace file."""
        return self._call(
            "create",
            nodeId=node_id,
            opts={"path": path, "content": content, "language": language, "isEntrypoint": is_entrypoint},
        )

    def update(self, file_id: str, content: str) -> None:
        """Update a workspace file's content."""
        self._call("update", fileId=file_id, content=content)
