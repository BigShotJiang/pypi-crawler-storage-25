"""ChatClient — delegates to /api/sdk for all operations."""

from __future__ import annotations
from ._base import SDKClientBase


class ChatClient(SDKClientBase):
    _namespace = "chat"

    def create_session(self, space_id: str, title: str | None = None) -> dict:
        """Create a new chat session in a space."""
        return self._call("createSession", spaceId=space_id, title=title)

    def list_sessions(self, space_id: str) -> list[dict]:
        """List chat sessions for a space."""
        return self._call("listSessions", spaceId=space_id)

    def get_session(self, session_id: str) -> dict:
        """Get a single chat session."""
        return self._call("getSession", sessionId=session_id)

    def delete_session(self, session_id: str) -> None:
        """Delete a chat session."""
        self._call("deleteSession", sessionId=session_id)

    def list_messages(self, session_id: str) -> list[dict]:
        """List messages in a chat session."""
        return self._call("listMessages", sessionId=session_id)
