"""SandboxClient — delegates to /api/sdk."""

from __future__ import annotations
from typing import Any

from ._base import SDKClientBase


class SandboxClient(SDKClientBase):
    _namespace = "sandbox"

    def run(
        self,
        code: str,
        *,
        env: dict | None = None,
        timeout: int = 30000,
        sdk: bool = True,
    ) -> dict:
        """Execute code in an isolated sandbox. Returns { output, logs, duration, error? }.

        Args:
            code: JavaScript/TypeScript code with a `run(env, muni)` function.
            env: Data passed into the sandbox as the first argument.
            timeout: Max execution time in ms (default 30000, max 120000).
            sdk: If True, the sandbox gets a `muni` SDK client as the second argument.
        """
        opts: dict[str, Any] = {
            "timeout": min(timeout, 120000),
            "sdk": sdk,
        }
        if env:
            opts["env"] = env
        return self._call("run", code=code, opts=opts)
