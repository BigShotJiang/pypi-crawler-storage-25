"""FilesClient — delegates list/read to /api/sdk, keeps save/download local."""

from __future__ import annotations
import base64
import fnmatch
from pathlib import Path

from ._base import SDKClientBase


class FilesClient(SDKClientBase):
    _namespace = "files"

    def list(self, call_id: str) -> list[dict]:
        """List output files for a job."""
        return self._call("list", callId=call_id)

    def read(self, call_id: str, file_path: str, *, max_lines: int | None = None) -> dict:
        """Read a file's text content, optionally truncated."""
        opts = {"maxLines": max_lines} if max_lines else None
        return self._call("read", callId=call_id, filePath=file_path, opts=opts)

    def download(self, call_id: str, file_path: str) -> tuple[str, bool]:
        """Download a file. Returns (content, is_text)."""
        result = self.read(call_id, file_path)
        return result.get("content", ""), result.get("isText", True)

    def save(self, call_id: str, file_path: str, dest: str | Path) -> Path:
        """Download a file and write it to disk."""
        result = self.read(call_id, file_path)
        content = result.get("content", "")
        is_text = result.get("isText", True)
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if is_text:
            dest.write_text(content)
        else:
            dest.write_bytes(base64.b64decode(content))
        return dest

    def save_all(
        self,
        call_id: str,
        output_dir: str | Path,
        *,
        path_prefix: str | None = None,
        glob_pattern: str | None = None,
    ) -> list[Path]:
        """Download all files for a job into output_dir."""
        output_dir = Path(output_dir)
        files = self.list(call_id)
        saved: list[Path] = []
        for f in files:
            fpath = f.get("path", f.get("name", ""))
            if path_prefix:
                prefix = path_prefix.rstrip("/") + "/"
                if not (fpath.startswith(prefix) or fpath == path_prefix.rstrip("/")):
                    continue
            if glob_pattern:
                if not fnmatch.fnmatch(fpath, glob_pattern) and not fnmatch.fnmatch(Path(fpath).name, glob_pattern):
                    continue
            dest = output_dir / fpath
            self.save(call_id, fpath, dest)
            saved.append(dest)
        return saved
