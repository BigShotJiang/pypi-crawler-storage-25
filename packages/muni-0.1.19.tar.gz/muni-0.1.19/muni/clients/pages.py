"""PagesClient — delegates to /api/sdk, returns typed models from _generated."""

from __future__ import annotations
from ._base import SDKClientBase
from .._generated.models import (
    PagesCreateOutput,
    PagesGetDefaultOutput,
    PagesListOutput,
    PagesListOutputItem,
)


class PagesClient(SDKClientBase):
    _namespace = "pages"

    def list(self, space_id: str) -> list[PagesListOutputItem]:
        """List all pages in a space."""
        result = self._call("list", response_model=PagesListOutput, spaceId=space_id)
        return list(result.root)

    def get(self, page_id: str) -> dict:
        """Get a single page. Response shape not yet in generated models — returns raw dict."""
        return self._call("get", pageId=page_id)

    def get_default(self, space_id: str) -> PagesGetDefaultOutput:
        """Get the default (first) page for a space. Creates one if none exist."""
        return self._call(
            "getDefault",
            response_model=PagesGetDefaultOutput,
            spaceId=space_id,
        )

    def create(self, space_id: str, title: str) -> PagesCreateOutput:
        """Create a new page in a space."""
        return self._call(
            "create",
            response_model=PagesCreateOutput,
            spaceId=space_id,
            title=title,
        )

    def delete(self, page_id: str) -> None:
        """Delete a page."""
        self._call("delete", pageId=page_id)

    def reorder(self, space_id: str, page_ids: list[str]) -> None:
        """Reorder pages within a space."""
        self._call("reorder", spaceId=space_id, pageIds=page_ids)
