"""UserClient — delegates to /api/sdk for balance, local credentials for whoami."""

from __future__ import annotations
from ._base import SDKClientBase
from .._generated.models import UserBalanceOutput, UserWhoamiOutput


class UserClient(SDKClientBase):
    _namespace = "user"

    def whoami(self) -> UserWhoamiOutput:
        """Current user identity (resolved from local credentials, no server round-trip)."""
        from ..auth import ensure_token
        creds = ensure_token()
        return UserWhoamiOutput.model_validate({
            "userId": creds.get("user_id", ""),
            "email": creds.get("email", ""),
        })

    def balance(self) -> UserBalanceOutput:
        """Credit balance."""
        return self._call("balance", response_model=UserBalanceOutput)
