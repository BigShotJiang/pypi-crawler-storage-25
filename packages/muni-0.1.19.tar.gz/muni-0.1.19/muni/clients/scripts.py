"""ScriptsClient — delegates to /api/sdk for script generation.

Takes validated primitives (SMILES / text / rows / storage refs) and returns
the canonical TypeScript for a given node kind. The server-side `@muni/sdk`
holds the only implementation, so UI drag-drop, CLI imports, and AI chat all
produce byte-identical output.
"""

from __future__ import annotations

from typing import Any, Literal

from ._base import SDKClientBase

ScriptKind = Literal[
    "chem",
    "text",
    "json",
    "metric",
    "structure",
    "image",
    "starter",
    "job",
]


class ScriptsClient(SDKClientBase):
    _namespace = "scripts"

    # ── Unified dispatcher ───────────────────────────────────────────

    def build(self, kind: ScriptKind, input: dict[str, Any]) -> str:
        """Generate the canonical script for ``kind`` from ``input`` primitives.

        Args:
            kind: One of "chem", "text", "json", "metric", "structure", "image".
            input: Primitive shape for the kind. See the per-kind helpers for
                the exact fields.

        Returns:
            TypeScript source ready to save into ``muni_nodes.script``.
        """
        result = self._call("build", kind=kind, input=input)
        if not isinstance(result, str):
            raise TypeError(f"scripts.build: expected string, got {type(result).__name__}")
        return result

    # ── Per-kind convenience (stronger typing at call sites) ────────

    def chem(self, *, smiles: str, label: str | None = None) -> str:
        return self._string_call("chem", {"smiles": smiles, "label": label})

    def text(self, *, content: str, label: str | None = None) -> str:
        return self._string_call("text", {"content": content, "label": label})

    def json(self, *, data: Any, label: str | None = None) -> str:
        return self._string_call("json", {"data": data, "label": label})

    def metric(
        self,
        *,
        columns: list[str],
        rows: list[dict[str, Any]],
        label: str | None = None,
    ) -> str:
        return self._string_call(
            "metric",
            {"columns": columns, "rows": rows, "label": label},
        )

    def structure(self, *, bucket: str, path: str, filename: str) -> str:
        return self._string_call(
            "structure",
            {"bucket": bucket, "path": path, "filename": filename},
        )

    def image(
        self,
        *,
        bucket: str,
        path: str,
        filename: str,
        content_type: str,
    ) -> str:
        return self._string_call(
            "image",
            {
                "bucket": bucket,
                "path": path,
                "filename": filename,
                "contentType": content_type,
            },
        )

    def starter(self, *, kind: str) -> str:
        """Empty-state scaffold for a node kind (metric/code/chart/…)."""
        return self._string_call("starter", {"kind": kind})

    def job(self, *, tool: str, params: dict[str, Any] | None = None) -> str:
        """Job-node declaration bound to a specific Tools API tool + params."""
        return self._string_call("job", {"tool": tool, "params": params or {}})

    # ── Internal ─────────────────────────────────────────────────────

    def _string_call(self, method: str, input_payload: dict[str, Any]) -> str:
        # Drop None values so the server picks its defaults (e.g. label="Molecule").
        cleaned = {k: v for k, v in input_payload.items() if v is not None}
        result = self._call(method, input=cleaned)
        if not isinstance(result, str):
            raise TypeError(f"scripts.{method}: expected string, got {type(result).__name__}")
        return result
