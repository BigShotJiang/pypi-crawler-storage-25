"""JobsClient — delegates CRUD to /api/sdk, keeps polling and batch local."""

from __future__ import annotations
import time
from typing import Any, Callable, TYPE_CHECKING

from ._base import SDKClientBase
from .._generated.models import (
    JobsCancelOutput,
    JobsSearchOutput,
    JobsSearchOutputItem,
    JobsStatusOutput,
    JobsSubmitOutput,
)
from ..exceptions import JobCancelledError, JobFailedError, JobTimeoutError

if TYPE_CHECKING:
    from ..client import MuniClient


class JobsClient(SDKClientBase):
    _namespace = "jobs"

    def submit(
        self,
        tool_name: str,
        params: dict[str, Any],
        *,
        title: str,
        space_id: str | None = None,
    ) -> JobsSubmitOutput:
        """Submit a job. Title is required.

        muni:// refs in params are resolved automatically. `space_id` is
        forwarded as metadata so the Tools API tags the job row with a space
        for ownership/filtering — it does NOT create a node. To surface the
        job on a canvas, call nodes.create(...) and persist the returned
        callId/jobId into the node's runtime.

        Returns a typed JobsSubmitOutput — use `.call_id` / `.job_id`, or
        `.model_dump(by_alias=True)` for a camelCase dict.
        """
        opts: dict[str, Any] = {"title": title}
        if space_id:
            opts["spaceId"] = space_id
        return self._call(
            "submit",
            response_model=JobsSubmitOutput,
            toolName=tool_name,
            params=params,
            opts=opts,
        )

    def status(self, call_id: str) -> JobsStatusOutput:
        """Check the current status of a job."""
        return self._call("status", response_model=JobsStatusOutput, callId=call_id)

    def wait(
        self,
        call_id: str,
        *,
        timeout: int = 3600,
        on_status: Callable[[dict], None] | None = None,
    ) -> dict:
        """Wait for a job using realtime subscription (with polling fallback)."""
        from ..realtime import create_job_waiter

        waiter = create_job_waiter(self._client, [call_id])
        delays = [2, 3, 5, 10, 15, 30]
        start = time.monotonic()
        i = 0
        try:
            while True:
                elapsed = time.monotonic() - start
                if elapsed >= timeout:
                    raise JobTimeoutError(call_id, timeout)

                s = self.status(call_id)
                if on_status:
                    on_status(s.model_dump(by_alias=True))

                if s.status == "completed":
                    return self.results(call_id)
                if s.status == "failed":
                    raise JobFailedError(call_id, s.error)
                if s.status == "cancelled":
                    raise JobCancelledError(call_id)

                delay = delays[min(i, len(delays) - 1)]
                if waiter:
                    waiter.wait_for_update(call_id, timeout=delay)
                else:
                    time.sleep(delay)
                i += 1
        finally:
            if waiter:
                waiter.stop()

    def results(self, call_id: str) -> dict:
        """Get the result payload of a completed job."""
        return self._call("results", callId=call_id)

    def search(
        self,
        *,
        call_id: str | None = None,
        job_id: str | None = None,
        status: str | None = None,
        tool_name: str | None = None,
        title: str | None = None,
        space_id: str | None = None,
        limit: int = 20,
    ) -> list[JobsSearchOutputItem]:
        """Search past jobs."""
        filters: dict[str, Any] = {"limit": limit}
        if call_id:
            filters["callId"] = call_id
        if job_id:
            filters["jobId"] = job_id
        if status:
            filters["status"] = status
        if tool_name:
            filters["toolName"] = tool_name
        if title:
            filters["title"] = title
        if space_id:
            filters["spaceId"] = space_id
        result = self._call("search", response_model=JobsSearchOutput, filters=filters)
        return list(result.root)

    def cancel(self, call_id: str) -> JobsCancelOutput:
        """Cancel a running job."""
        return self._call("cancel", response_model=JobsCancelOutput, callId=call_id)

    def summary(self, call_id: str) -> dict:
        """Get a structured summary of a job's output."""
        return self._call("summary", callId=call_id)

    def query(self, call_id: str, **opts: Any) -> dict:
        """Query metric/tabular data from a job's results."""
        return self._call("query", callId=call_id, opts=opts if opts else None)

    def logs(self, call_id: str) -> str:
        """Fetch provider logs for a job."""
        return self._call("logs", callId=call_id)

    def batch(
        self,
        tool_name: str,
        params_list: list[dict[str, Any]],
        *,
        title: str | None = None,
        space_id: str | None = None,
    ) -> list[dict]:
        """Submit multiple jobs. Client-side sequential submission."""
        opts: dict[str, Any] | None = None
        if title or space_id:
            opts = {}
            if title:
                opts["title"] = title
            if space_id:
                opts["spaceId"] = space_id
        return self._call(
            "batch",
            toolName=tool_name,
            paramsList=params_list,
            opts=opts,
        )
