"""ConnectionsClient — delegates to /api/sdk, returns typed models from _generated."""

from __future__ import annotations
from typing import Any

from ._base import SDKClientBase
from .._generated.models import (
    ConnectionsCreateOutput,
    ConnectionsListOutput,
    ConnectionsListOutputItem,
    ConnectionsUpdateOutput,
)

_UNSET = object()


class ConnectionsClient(SDKClientBase):
    _namespace = "connections"

    def list(self, page_id: str) -> list[ConnectionsListOutputItem]:
        """List all connections on a page."""
        result = self._call("list", response_model=ConnectionsListOutput, pageId=page_id)
        return list(result.root)

    def create(
        self,
        *,
        page_id: str,
        target_node_id: str,
        target_port: str,
        kind: str = "data",
        source_node_id: str | None = None,
        source_port: str | None = None,
    ) -> ConnectionsCreateOutput:
        """Create a connection."""
        return self._call(
            "create",
            response_model=ConnectionsCreateOutput,
            opts={
                "pageId": page_id,
                "targetNodeId": target_node_id,
                "targetPort": target_port,
                "kind": kind,
                "sourceNodeId": source_node_id,
                "sourcePort": source_port,
            },
        )

    def update(
        self,
        connection_id: str,
        *,
        source_node_id: str | None | object = _UNSET,
        target_node_id: str | None = None,
        source_port: str | None | object = _UNSET,
        target_port: str | None = None,
        kind: str | None = None,
        label: str | None | object = _UNSET,
        is_enabled: bool | None = None,
    ) -> ConnectionsUpdateOutput:
        """Edit a connection in place."""
        opts: dict[str, Any] = {}
        if source_node_id is not _UNSET:
            opts["sourceNodeId"] = source_node_id
        if target_node_id is not None:
            opts["targetNodeId"] = target_node_id
        if source_port is not _UNSET:
            opts["sourcePort"] = source_port
        if target_port is not None:
            opts["targetPort"] = target_port
        if kind is not None:
            opts["kind"] = kind
        if label is not _UNSET:
            opts["label"] = label
        if is_enabled is not None:
            opts["isEnabled"] = is_enabled

        return self._call(
            "update",
            response_model=ConnectionsUpdateOutput,
            connectionId=connection_id,
            opts=opts,
        )

    def remove(self, connection_id: str) -> None:
        """Delete a connection."""
        self._call("remove", connectionId=connection_id)

    def disable(self, connection_id: str) -> None:
        """Soft-disable a connection (preserves for undo)."""
        self._call("disable", connectionId=connection_id)

    def enable(self, connection_id: str) -> None:
        """Re-enable a disabled connection."""
        self._call("enable", connectionId=connection_id)
