"""PlansClient — delegates to /api/sdk for all operations."""

from __future__ import annotations
from typing import Any
from ._base import SDKClientBase


class PlansClient(SDKClientBase):
    _namespace = "plans"

    def create(
        self,
        plan: dict[str, Any],
        *,
        space_id: str | None = None,
        page_id: str | None = None,
    ) -> dict:
        """Create a multi-step pipeline.

        Args:
            plan: Plan definition with title, objective, steps.
            space_id: Target space (uses default page).
            page_id: Target page (overrides space_id).
        """
        resolved_space = space_id or self._client._cfg.get("active_space_id")
        resolved_page = page_id or self._client._cfg.get("active_page_id")

        if resolved_page:
            target = {"pageId": resolved_page}
        elif resolved_space:
            target = {"spaceId": resolved_space}
        else:
            from ..exceptions import MuniError
            raise MuniError("No page_id or space_id available. Set active_space_id or pass explicitly.")

        return self._call("create", target=target, plan=plan)

    def validate(self, node_id: str) -> dict:
        """Validate a plan node — check children exist, scripts compile."""
        return self._call("validate", nodeId=node_id)

    def run(self, node_id: str) -> None:
        """Run a plan node's orchestrator."""
        self._call("run", nodeId=node_id)
