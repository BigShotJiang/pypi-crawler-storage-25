"""SpacesClient — delegates to /api/sdk, returns typed models from _generated."""

from __future__ import annotations
from ._base import SDKClientBase
from .._generated.models import (
    SpacesCreateOutput,
    SpacesGetOutput,
    SpacesListOutput,
    SpacesListOutputItem,
)
from ..exceptions import NotFoundError


class SpacesClient(SDKClientBase):
    _namespace = "spaces"

    def list(self) -> list[SpacesListOutputItem]:
        """List all spaces the user has access to.

        Returns a list of typed items — use `.id`, `.name`, etc., or
        `item.model_dump(by_alias=True)` for a camelCase dict.
        """
        result = self._call("list", response_model=SpacesListOutput)
        return list(result.root)

    def get(self, space_id: str) -> SpacesGetOutput:
        """Get a single space by ID."""
        return self._call("get", response_model=SpacesGetOutput, spaceId=space_id)

    def create(self, name: str) -> SpacesCreateOutput:
        """Create a new space."""
        return self._call("create", response_model=SpacesCreateOutput, name=name)

    def delete(self, space_id: str) -> None:
        """Delete a space."""
        self._call("delete", spaceId=space_id)

    def members(self, space_id: str) -> list[dict]:
        """List members of a space. Returns raw dicts — shape not yet in generated models."""
        return self._call("members", spaceId=space_id)

    def invite(self, space_id: str, email: str) -> str:
        """Invite a user to a space by email."""
        return self._call("invite", spaceId=space_id, email=email)

    def resolve(self, id_or_name: str) -> str:
        """Resolve a space by UUID or name. Returns the space UUID."""
        import re
        if re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", id_or_name, re.I):
            return id_or_name
        if id_or_name.startswith("space_"):
            return id_or_name
        for s in self.list():
            if s.name.lower() == id_or_name.lower():
                return s.id
        raise NotFoundError(f"No space found with name: {id_or_name}")
