"""ToolsClient — delegates to /api/sdk, returns typed models from _generated."""

from __future__ import annotations
from ._base import SDKClientBase
from .._generated.models import (
    ToolsGetOutput,
    ToolsListOutput,
    ToolsListOutputItem,
)


class ToolsClient(SDKClientBase):
    _namespace = "tools"

    def list(
        self,
        *,
        query: str | None = None,
        category: str | None = None,
    ) -> list[ToolsListOutputItem]:
        """List available tools, optionally filtered by keyword or category."""
        opts: dict = {}
        if query:
            opts["query"] = query
        if category:
            opts["category"] = category
        result = self._call(
            "list",
            response_model=ToolsListOutput,
            opts=opts if opts else None,
        )
        return list(result.root)

    def get(self, name: str) -> ToolsGetOutput:
        """Get full tool definition with parameter schema."""
        return self._call("get", response_model=ToolsGetOutput, name=name)

    def examples(self, name: str) -> list[dict]:
        """Get curated usage examples for a tool.

        Not yet in the generated models — returns raw dicts.
        """
        return self._call("examples", name=name)
