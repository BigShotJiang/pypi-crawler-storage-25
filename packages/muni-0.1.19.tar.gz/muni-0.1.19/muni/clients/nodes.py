"""NodesClient — all operations route through /api/sdk."""

from __future__ import annotations
from typing import Any, TYPE_CHECKING

from ._base import SDKClientBase
from .._generated.models import (
    NodesCreateOutput,
    NodesGroupOutput,
    NodesListOutput,
    NodesListOutputItem,
    NodesUngroupOutput,
    Type as NodeType,
)
from ..exceptions import MuniError

if TYPE_CHECKING:
    from ..client import MuniClient

VALID_NODE_TYPES = {t.value for t in NodeType}


class NodesClient(SDKClientBase):
    _namespace = "nodes"

    def list(
        self,
        page_id: str,
        *,
        type: str | None = None,
        query: str | None = None,
        limit: int = 20,
    ) -> list[NodesListOutputItem]:
        """List/search nodes on a page."""
        opts: dict[str, Any] = {"limit": limit}
        if type:
            opts["type"] = type
        if query:
            opts["query"] = query
        result = self._call(
            "list",
            response_model=NodesListOutput,
            pageId=page_id,
            opts=opts,
        )
        return list(result.root)

    def get(self, node_id: str) -> dict:
        """Get full node state including script, data, and connections."""
        return self._call("get", nodeId=node_id)

    def create(
        self,
        page_id: str,
        title: str,
        *,
        type: str = "metric",
        script: str | None = None,
        python_code: str | None = None,
        position_x: float | None = None,
        position_y: float | None = None,
    ) -> dict:
        """Create a new node. For code nodes, pass python_code to set main.py."""
        if type not in VALID_NODE_TYPES:
            raise MuniError(f"Invalid node type '{type}'. Must be one of: {', '.join(sorted(VALID_NODE_TYPES))}")

        opts: dict[str, Any] = {"title": title, "type": type}
        if script is not None:
            opts["script"] = script
        if position_x is not None:
            opts["positionX"] = position_x
        if position_y is not None:
            opts["positionY"] = position_y
        # Python for code nodes is written to main.py inside sdk.nodes.create
        # BEFORE the server dispatches the pipeline — single round trip, the
        # first run compiles against caller-supplied code.
        if python_code is not None:
            opts["pythonCode"] = python_code

        # Every node create runs through the server's pipeline dispatch
        # (compile → validate → execute for runnable kinds; save-only for
        # job/plan; skip for group). No client-side branching — the
        # server is the single authority. See
        # src/lib/muni/sdk/server/dispatch-create.ts.
        parsed = self._call(
            "create",
            response_model=NodesCreateOutput,
            pageId=page_id,
            opts=opts,
        )
        return parsed.model_dump(by_alias=True)

    def update(self, node_id: str, *, title: str | None = None, script: str | None = None, python_code: str | None = None) -> dict:
        """Update a node's title, script, or Python code."""
        updated: list[str] = []
        patch: dict[str, Any] = {}
        if title is not None:
            patch["title"] = title
            updated.append("title")
        if script is not None:
            patch["script"] = script
            updated.append("script")
        if python_code is not None:
            patch["pythonCode"] = python_code
            updated.append("pythonCode")
        if patch:
            self._call("update", nodeId=node_id, patch=patch)

        return {"nodeId": node_id, "updated": updated}

    def remove(self, node_id: str, *, origin: str = "cli-remove") -> dict:
        """Soft-delete a node and disable its connections.

        ``origin`` is stamped onto ``muni_nodes.last_write_client_id`` for the
        audit trail. Defaults to ``'cli-remove'`` so ad-hoc CLI usage is
        identifiable; callers embedding this SDK should pass a more specific
        origin (e.g. ``'cli-batch-cleanup'``, ``'my-tool-name'``).
        """
        self._call("remove", nodeId=node_id, origin=origin)
        return {"nodeId": node_id, "removed": True}

    def restore(self, node_id: str, *, origin: str = "cli-restore") -> dict:
        """Restore a soft-deleted node and re-enable its connections."""
        self._call("restore", nodeId=node_id, origin=origin)
        return {"nodeId": node_id, "restored": True}

    def save(self, node_id: str, *, script: str | None = None, **_kw: Any) -> dict:
        """Save a node: persist script + compile + validate. Never execute."""
        args: dict[str, Any] = {"nodeId": node_id}
        if script is not None:
            args["script"] = script
        return self._call("save", **args)

    def run(self, node_id: str, *, script: str | None = None, job: dict | None = None, **_kw: Any) -> dict:
        """Run a node: compile + execute + validate + store + cascade.

        The server resolves pageId/spaceId from the node row, compiles
        the script, executes in the sandbox, and cascades downstream.
        """
        args: dict[str, Any] = {"nodeId": node_id}
        if script is not None:
            args["script"] = script
        if job is not None:
            args["job"] = job
        return self._call("run", **args)

    def move(self, node_id: str, *, x: float, y: float) -> dict:
        """Move a node. Broadcasts for realtime canvas updates."""
        self._call("move", nodeId=node_id, position={"x": x, "y": y})
        return {"nodeId": node_id, "x": x, "y": y}

    def select(self, page_id: str, node_ids: str | list[str]) -> dict:
        """Select node(s). Broadcasts to connected canvas clients."""
        ids = [node_ids] if isinstance(node_ids, str) else node_ids
        self._call("select", pageId=page_id, nodeIds=ids)
        return {"nodeIds": ids, "action": "select"}

    def focus(self, page_id: str, node_id: str) -> dict:
        """Focus the canvas viewport on a node."""
        self._call("focus", pageId=page_id, nodeId=node_id)
        return {"nodeId": node_id, "action": "focus"}

    def group(
        self,
        page_id: str,
        node_ids: list[str],
        *,
        label: str,
    ) -> NodesGroupOutput:
        """Group multiple nodes on a page under a new parent group node.

        Creates a ``group``-type node whose children are the given nodes;
        returns the new ``groupId`` and the count of members.
        """
        if not node_ids:
            raise MuniError("group() requires at least one node id.")
        return self._call(
            "group",
            response_model=NodesGroupOutput,
            pageId=page_id,
            opts={"label": label, "nodeIds": node_ids},
        )

    def ungroup(self, group_id: str) -> NodesUngroupOutput:
        """Ungroup a group node — detaches children and removes the group."""
        return self._call(
            "ungroup",
            response_model=NodesUngroupOutput,
            groupId=group_id,
        )

    def metric_summary(self, node_id: str) -> dict:
        """Get a summary of a metric node's data."""
        return self._call("metricSummary", nodeId=node_id)

    def metric_query(self, node_id: str, **opts: Any) -> dict:
        """Query a metric node's data with sorting, filtering, and pagination."""
        return self._call("metricQuery", nodeId=node_id, opts=opts if opts else None)

    def metric_select(
        self,
        node_id: str,
        *,
        action: str,
        rows: list[int] | None = None,
        filters: list[dict] | None = None,
    ) -> dict:
        """Select, deselect, clear, or read checked rows for a metric node."""
        opts: dict[str, Any] = {"action": action}
        if rows is not None:
            opts["rows"] = rows
        if filters is not None:
            opts["filters"] = filters
        return self._call("metricSelect", nodeId=node_id, opts=opts)

    # ── Python file convenience methods (delegate to node_files) ──

    def get_python_files(self, node_id: str) -> list[dict]:
        """List Python files for a code node."""
        return self._client.node_files.list(node_id)

    def get_python_code(self, node_id: str) -> str | None:
        """Get the entrypoint Python file content."""
        files = self._client.node_files.list(node_id)
        entrypoint = next((f for f in files if f.get("isEntrypoint")), None)
        if entrypoint:
            full = self._client.node_files.get(node_id, entrypoint["path"])
            return full.get("content")
        if files:
            full = self._client.node_files.get(node_id, files[0]["path"])
            return full.get("content")
        return None

    def set_python_code(self, node_id: str, code: str) -> dict:
        """Set the entrypoint Python file content."""
        files = self._client.node_files.list(node_id)
        main_py = next((f for f in files if f.get("path") == "main.py"), None)
        if main_py:
            self._client.node_files.update(main_py["id"], code)
        else:
            self._client.node_files.create(
                node_id, path="main.py", content=code,
                language="python", is_entrypoint=True,
            )
        return {"nodeId": node_id, "updated": ["pythonCode"]}
