"""Supabase Realtime subscription for job status changes.

Wraps the async ``realtime`` library in a background thread so the
synchronous CLI can block on ``threading.Event`` objects instead of
polling.  If the realtime connection fails at any point, callers
fall back to plain HTTP polling — this module never raises.

Strategy: subscribe to the **broadcast** channel ``jobs:user:<user_id>``
which the ``broadcast_job_changes`` trigger fires on every INSERT/UPDATE
to the ``jobs`` table.  Broadcast bypasses RLS (unlike postgres_changes
which can't evaluate the subquery-based policies on this table).
"""

from __future__ import annotations

import asyncio
import atexit
import logging
import threading
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import MuniClient

log = logging.getLogger(__name__)

# How long start() waits for the websocket to connect before giving up.
_CONNECT_TIMEOUT = 8.0


class RealtimeJobWaiter:
    """Subscribe to Supabase Realtime broadcast for job status changes.

    Runs an asyncio event loop in a daemon thread.  The main thread
    calls :meth:`wait_for_update` which blocks on a per-call_id
    ``threading.Event``.
    """

    def __init__(
        self,
        supabase_url: str,
        anon_key: str,
        access_token: str,
        user_id: str,
        call_ids: list[str],
    ) -> None:
        self._supabase_url = supabase_url.rstrip("/")
        self._anon_key = anon_key
        self._access_token = access_token
        self._user_id = user_id
        self._call_ids = set(call_ids)

        # Per-call_id threading events — set when a realtime update arrives.
        self._events: dict[str, threading.Event] = {
            cid: threading.Event() for cid in call_ids
        }
        # Latest payload per call_id (written by async thread, read by main).
        self._updates: dict[str, dict[str, Any]] = {}

        # Lifecycle signals
        self._connected = threading.Event()
        self._connection_failed = threading.Event()
        self._stop_flag = threading.Event()

        # Background loop / thread (set in start())
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._socket: Any = None  # AsyncRealtimeClient

    # ── public API (called from main thread) ────────────────────────

    def start(self) -> bool:
        """Connect and subscribe.  Returns True on success, False on failure."""
        self._thread = threading.Thread(
            target=self._run_loop, name="muni-realtime", daemon=True
        )
        self._thread.start()

        # Wait for either connected or failed.
        while not self._connected.is_set() and not self._connection_failed.is_set():
            if not self._connected.wait(timeout=_CONNECT_TIMEOUT):
                if not self._connected.is_set():
                    log.debug("realtime: connect timed out after %.1fs", _CONNECT_TIMEOUT)
                    self._stop_flag.set()
                    return False

        if self._connection_failed.is_set():
            log.debug("realtime: connection failed")
            return False

        log.debug("realtime: connected, watching %d call_ids", len(self._call_ids))
        return True

    def wait_for_update(self, call_id: str, timeout: float) -> dict[str, Any] | None:
        """Block until a realtime update arrives for *call_id*, or *timeout* expires.

        Returns the update payload, or ``None`` on timeout.
        After returning, the event is cleared so the next call blocks again.
        """
        ev = self._events.get(call_id)
        if ev is None:
            return None
        ev.wait(timeout=timeout)
        ev.clear()
        return self._updates.pop(call_id, None)

    def refresh_token(self, new_token: str) -> None:
        """Push a refreshed JWT to the live websocket."""
        self._access_token = new_token
        if self._loop and self._socket:
            try:
                asyncio.run_coroutine_threadsafe(
                    self._socket.set_auth(new_token), self._loop
                )
            except Exception:
                log.debug("realtime: failed to refresh token on socket", exc_info=True)

    def stop(self) -> None:
        """Disconnect and join the background thread."""
        import io
        import sys

        self._stop_flag.set()
        # The async loop checks _stop_flag every 0.5s and exits cleanly.
        if self._thread and self._thread.is_alive():
            # Suppress noisy asyncio/websocket teardown messages on stderr.
            old_stderr = sys.stderr
            sys.stderr = io.StringIO()
            try:
                self._thread.join(timeout=5)
            finally:
                sys.stderr = old_stderr

    @property
    def is_connected(self) -> bool:
        return self._connected.is_set() and not self._connection_failed.is_set()

    # ── background thread ───────────────────────────────────────────

    def _run_loop(self) -> None:
        """Entry point for the daemon thread."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        # Suppress noisy asyncio warnings during teardown (pending tasks, etc).
        self._loop.set_exception_handler(lambda _loop, ctx: None)
        try:
            self._loop.run_until_complete(self._async_main())
        except Exception:
            log.debug("realtime: background loop error", exc_info=True)
            self._connection_failed.set()
        finally:
            try:
                self._loop.run_until_complete(self._loop.shutdown_asyncgens())
            except Exception:
                pass
            # Cancel any remaining tasks (websocket keepalive, listener, etc).
            for task in asyncio.all_tasks(self._loop):
                task.cancel()
            if asyncio.all_tasks(self._loop):
                try:
                    self._loop.run_until_complete(
                        asyncio.gather(*asyncio.all_tasks(self._loop), return_exceptions=True)
                    )
                except Exception:
                    pass
            self._loop.close()

    async def _async_main(self) -> None:
        import warnings
        from realtime import AsyncRealtimeClient

        # Build the realtime URL from the Supabase project URL.
        # https://xyz.supabase.co → wss://xyz.supabase.co/realtime/v1
        host = self._supabase_url.replace("https://", "wss://").replace("http://", "ws://")
        url = f"{host}/realtime/v1"

        self._socket = AsyncRealtimeClient(url, self._anon_key, auto_reconnect=False)
        await self._socket.set_auth(self._access_token)
        await self._socket.connect()

        # Subscribe to the user-scoped broadcast channel.
        # The DB trigger `broadcast_job_changes` sends to `jobs:user:<user_id>`
        # on every INSERT/UPDATE to the `jobs` table.  Broadcast bypasses RLS.
        channel = self._socket.channel(f"jobs:user:{self._user_id}")
        channel.on_broadcast("job-status", self._on_broadcast)
        await channel.subscribe()

        self._connected.set()

        # Keep running until stop() is called.
        while not self._stop_flag.is_set():
            await asyncio.sleep(0.5)

        # Cleanup — suppress noisy warnings from the websocket library.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                await channel.unsubscribe()
            except Exception:
                pass
            try:
                await self._socket.close()
            except Exception:
                pass
            await asyncio.sleep(0.1)

    def _on_broadcast(self, payload: Any) -> None:
        """Handle a broadcast event from the ``job-status`` channel."""
        try:
            # The trigger sends: {id, call_id, status, job_type, title, user_id, space_id}
            # Broadcast payload structure: {"event": "job-status", "payload": {...}}
            data = payload
            if isinstance(payload, dict):
                data = payload.get("payload", payload)

            if not isinstance(data, dict):
                return

            call_id = data.get("call_id")
            if call_id and call_id in self._call_ids:
                self._updates[call_id] = data
                ev = self._events.get(call_id)
                if ev:
                    ev.set()
        except Exception:
            log.debug("realtime: broadcast callback error", exc_info=True)


# ── factory ─────────────────────────────────────────────────────────

def create_job_waiter(client: MuniClient, call_ids: list[str]) -> RealtimeJobWaiter | None:
    """Try to create and start a RealtimeJobWaiter.

    Returns ``None`` if the ``realtime`` package is unavailable or the
    websocket connection fails — callers should fall back to polling.
    """
    if not call_ids:
        return None

    try:
        from realtime import AsyncRealtimeClient  # noqa: F401
    except ImportError:
        log.debug("realtime: package not installed, falling back to polling")
        return None

    try:
        from .auth import ensure_token
        creds = ensure_token()
        waiter = RealtimeJobWaiter(
            supabase_url=client.supabase_url,
            anon_key=client.publishable_key,
            access_token=creds["access_token"],
            user_id=creds["user_id"],
            call_ids=call_ids,
        )
        if waiter.start():
            atexit.register(waiter.stop)
            return waiter
        return None
    except Exception:
        log.debug("realtime: failed to create waiter", exc_info=True)
        return None
