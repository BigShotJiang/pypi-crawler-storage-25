"""Human-readable table/tree formatting for CLI output."""

import json
from typing import Any


def _truncate(s: str, width: int) -> str:
    return s[:width - 1] + "\u2026" if len(s) > width else s


def _pad(s: str, width: int) -> str:
    return s + " " * max(0, width - len(s))


def _format_number(value: Any) -> str:
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return f"{value:.1f}"
    return "?"


def _format_position(node: dict[str, Any]) -> str:
    return f"({_format_number(node.get('position_x'))}, {_format_number(node.get('position_y'))})"


def _format_size(node: dict[str, Any]) -> str:
    return f"{_format_number(node.get('width'))}x{_format_number(node.get('height'))}"


def _preview_text(value: str, width: int = 80) -> str:
    compact = " ".join(value.split())
    return _truncate(compact, width)


def _indent_block(text: str, prefix: str = "  ") -> list[str]:
    return [f"{prefix}{line}" if line else prefix.rstrip() for line in text.splitlines()]


def _format_json_block(value: Any) -> list[str]:
    try:
        rendered = json.dumps(value, indent=2, sort_keys=True)
    except TypeError:
        rendered = str(value)
    return _indent_block(rendered)


def format_tools_table(tools: list[dict]) -> str:
    """Format a list of tools as a compact table."""
    if not tools:
        return "No tools found."

    col_name = max(len(t.get("name", "")) for t in tools)
    col_name = max(col_name, 4)  # "Name"
    col_cat = max(len(t.get("category", "")) for t in tools)
    col_cat = max(col_cat, 8)  # "Category"

    lines = [
        f"{_pad('Name', col_name)}  {_pad('Category', col_cat)}  Description",
        f"{'-' * col_name}  {'-' * col_cat}  {'-' * 40}",
    ]
    for t in tools:
        name = _pad(t.get("name", ""), col_name)
        cat = _pad(t.get("category", ""), col_cat)
        desc = _truncate(t.get("description", ""), 60)
        lines.append(f"{name}  {cat}  {desc}")
    return "\n".join(lines)


def format_tool_detail(tool: dict) -> str:
    """Format full tool detail including inputs."""
    lines = [
        f"{tool.get('name', '?')} \u2014 {tool.get('description', '')}",
        f"Category: {tool.get('category', '?')}",
    ]
    if ref := tool.get("reference_url"):
        lines.append(f"Reference: {ref}")

    params = tool.get("parameters", {})
    props = params.get("properties", {})
    required = set(params.get("required", []))

    if props:
        lines.append("")
        lines.append("Inputs:")
        for pname, pdef in props.items():
            ptype = pdef.get("type", "any")
            if isinstance(ptype, list):
                ptype = "/".join(ptype)
            req = "*" if pname in required else " "
            default = ""
            if "default" in pdef:
                default = f" (default: {pdef['default']})"
            desc = pdef.get("description", "")
            enum_vals = pdef.get("enum")
            if enum_vals:
                desc += f" [{', '.join(str(v) for v in enum_vals)}]"
            lines.append(f"  {req} {_pad(pname, 20)} {_pad(ptype, 10)} {desc}{default}")

    return "\n".join(lines)


def format_tool_inputs(tool: dict) -> str:
    """Format just the input parameters table."""
    params = tool.get("parameters", {})
    props = params.get("properties", {})
    required = set(params.get("required", []))

    if not props:
        return "No parameters."

    lines = [
        f"Inputs for {tool.get('name', '?')}:",
        "",
        f"  {'':1} {_pad('Name', 20)} {_pad('Type', 10)} {_pad('Default', 12)} Description",
        f"  {'-':1} {'-' * 20} {'-' * 10} {'-' * 12} {'-' * 30}",
    ]
    for pname, pdef in props.items():
        ptype = pdef.get("type", "any")
        if isinstance(ptype, list):
            ptype = "/".join(ptype)
        req = "*" if pname in required else " "
        default = str(pdef["default"]) if "default" in pdef else "-"
        desc = pdef.get("description", "")
        lines.append(f"  {req} {_pad(pname, 20)} {_pad(ptype, 10)} {_pad(default, 12)} {desc}")

    lines.append("")
    lines.append("  * = required")
    return "\n".join(lines)


def format_examples(tool_name: str, examples: list[dict]) -> str:
    """Format usage examples."""
    if not examples:
        return f"No examples available for {tool_name}."

    lines = [f"Examples for {tool_name}:", ""]
    for ex in examples:
        lines.append(f"  {ex.get('title', 'Example')}:")
        if desc := ex.get("description"):
            lines.append(f"    {desc}")
        params = ex.get("parameters", {})
        if params:
            parts = [f"{k}={_format_value(v)}" for k, v in params.items()]
            lines.append(f"    muni run {tool_name} {' '.join(parts)}")
        lines.append("")
    return "\n".join(lines)


def _format_value(v: Any) -> str:
    if isinstance(v, str):
        return v if " " not in v else f'"{v}"'
    if isinstance(v, (list, dict)):
        return json.dumps(v)
    return str(v)


def format_job_status(data: dict) -> str:
    """Format a job status response."""
    status = data.get("status", "?")
    job_id = data.get("job_id") or data.get("id")
    call_id = data.get("call_id")
    primary = job_id or call_id or "?"
    lines = [f"Job: {primary}", f"Status: {status}"]
    if job_id and call_id and job_id != call_id:
        lines.append(f"Call ID: {call_id}")
    if title := data.get("title"):
        lines.append(f"Title: {title}")
    lines.append(f"Type: {data.get('job_type', '?')}")
    if provider := data.get("provider"):
        lines.append(f"Provider: {provider}")
    if created := data.get("created_at"):
        lines.append(f"Created: {created}")
    if updated := data.get("updated_at"):
        lines.append(f"Updated: {updated}")
    if completed := data.get("completed_at"):
        lines.append(f"Completed: {completed}")
    if runtime := data.get("runtime_seconds"):
        lines.append(f"Runtime: {runtime}s")
    if result_status := data.get("result_status"):
        lines.append(f"Result Status: {result_status}")
    if error := data.get("error"):
        lines.append(f"Error: {error}")
    return "\n".join(lines)


def format_jobs_table(jobs: list[dict]) -> str:
    """Format a list of jobs as a table."""
    if not jobs:
        return "No jobs found."

    lines = [
        f"{_pad('Job ID', 42)}  {_pad('Status', 10)}  {_pad('Type', 28)}  Created",
        f"{'-' * 42}  {'-' * 10}  {'-' * 28}  {'-' * 20}",
    ]
    for j in jobs:
        primary = j.get("id") or j.get("job_id") or j.get("call_id") or "?"
        cid = _pad(_truncate(primary, 42), 42)
        st = _pad(j.get("status", "?"), 10)
        jt = _pad(_truncate(j.get("job_type", "?"), 28), 28)
        created = j.get("created_at", "?")[:19]
        lines.append(f"{cid}  {st}  {jt}  {created}")
    return "\n".join(lines)


def format_file_tree(data: dict, *, path_prefix: str | None = None) -> str:
    """Format the file listing response as a tree.

    If path_prefix is given, only show the subtree under that directory.
    """
    primary = data.get("job_id") or data.get("id") or data.get("call_id") or "?"
    label = f"Files for job {primary}"
    if path_prefix:
        label += f" (path: {path_prefix})"
    lines = [f"{label}:"]
    tree = data.get("tree", [])

    if path_prefix:
        tree = _find_subtree(tree, path_prefix)

    if not tree:
        lines.append("  (no files)")
        return "\n".join(lines)

    def _render(nodes: list, prefix: str = "") -> None:
        for i, node in enumerate(nodes):
            is_last = i == len(nodes) - 1
            connector = "\u2514\u2500 " if is_last else "\u251c\u2500 "
            name = node.get("name", "?")
            size = node.get("size_bytes")
            suffix = f"  ({_human_size(size)})" if size else ""
            lines.append(f"{prefix}{connector}{name}{suffix}")
            children = node.get("children", [])
            if children:
                child_prefix = prefix + ("   " if is_last else "\u2502  ")
                _render(children, child_prefix)

    _render(tree)
    return "\n".join(lines)


def _find_subtree(tree: list[dict], path_prefix: str) -> list[dict]:
    """Walk the tree to find the children of the node matching path_prefix."""
    parts = [p for p in path_prefix.strip("/").split("/") if p]
    nodes = tree
    for part in parts:
        found = None
        for node in nodes:
            if node.get("name") == part:
                found = node
                break
        if found is None:
            return []
        children = found.get("children", [])
        if children:
            nodes = children
        else:
            # Leaf node matched — return it as a single-item list
            return [found]
    return nodes


def _human_size(n: int | None) -> str:
    if n is None:
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def format_balance(data: dict) -> str:
    """Format user balance."""
    balance = data.get("balance", data.get("credits", 0))
    return f"Balance: {balance} credits"


def format_spaces_table(spaces: list[dict], *, active_space_id: str | None = None) -> str:
    """Format spaces list."""
    if not spaces:
        return "No spaces found."

    lines = [
        f"{_pad('Active', 6)}  {_pad('ID', 38)}  {_pad('Name', 30)}  Owner",
        f"{'-' * 6}  {'-' * 38}  {'-' * 30}  {'-' * 36}",
    ]
    for s in spaces:
        marker = "*" if s.get("id") == active_space_id else ""
        sid = _pad(s.get("id", "?"), 38)
        name = _pad(_truncate(s.get("name", "?"), 30), 30)
        owner = s.get("owner_id", "?")
        lines.append(f"{_pad(marker, 6)}  {sid}  {name}  {owner}")
    return "\n".join(lines)


def format_members_table(members: list[dict]) -> str:
    """Format space members."""
    if not members:
        return "No members found."

    lines = [
        f"{_pad('Email', 30)}  {_pad('Role', 10)}  User ID",
        f"{'-' * 30}  {'-' * 10}  {'-' * 36}",
    ]
    for m in members:
        email = _pad(m.get("email", "?"), 30)
        role = _pad(m.get("role", "?"), 10)
        uid = m.get("user_id", "?")
        lines.append(f"{email}  {role}  {uid}")
    return "\n".join(lines)


def format_config_display(cfg: dict[str, Any]) -> str:
    """Format config show output."""
    lines = [
        f"Profile: {cfg.get('profile', '?')}",
        f"API URL: {cfg.get('api_url', '(unset)')}",
        f"App URL: {cfg.get('app_url', '(unset)')}",
        f"Supabase URL: {cfg.get('supabase_url', '(unset)')}",
        f"Supabase Publishable Key: {cfg.get('supabase_publishable_key', '(unset)')}",
    ]
    active_space_id = cfg.get("active_space_id")
    if active_space_id:
        label = cfg.get("active_space_name")
        lines.append(
            f"Active Space: {label} ({active_space_id})" if label else f"Active Space: {active_space_id}"
        )
    else:
        lines.append("Active Space: (unset)")
    active_page_id = cfg.get("active_page_id")
    if active_page_id:
        page_title = cfg.get("active_page_title")
        lines.append(
            f"Active Page: {page_title} ({active_page_id})" if page_title else f"Active Page: {active_page_id}"
        )
    else:
        lines.append("Active Page: (unset)")
    return "\n".join(lines)


def format_results(data: dict) -> str:
    """Format job results."""
    status = data.get("status", "?")
    if status == "failed":
        return f"Job failed: {data.get('error', 'Unknown error')}"
    result = data.get("result")
    if result is None:
        return f"Status: {status} — no results yet"
    return json.dumps(result, indent=2)


def format_job_summary(data: dict) -> str:
    """Format a structured job output summary."""
    lines = [
        f"Job: {data.get('callId', '?')}",
        f"Tool: {data.get('toolName') or '(unknown)'}",
        f"Status: {data.get('status', '?')}",
        f"Files: {data.get('fileCount', 0)}",
    ]

    metrics = data.get("metricsSummary")
    if metrics:
        lines.append("")
        lines.append(f"Rows: {metrics.get('rowCount', 0)}")
        columns = metrics.get("columns", [])
        lines.append(f"Columns ({len(columns)}): {', '.join(columns)}")
        default_cols = metrics.get("defaultColumns", [])
        if default_cols:
            lines.append(f"Default Columns: {', '.join(default_cols)}")
    else:
        lines.append("")
        lines.append("No structured metric data available.")

    hints = data.get("summaryOutput")
    if hints:
        if m := hints.get("metrics"):
            if fmt := m.get("format"):
                lines.append(f"Metric Format: {fmt}")
            if path := m.get("path"):
                lines.append(f"Metric Path: {path}")
        if s := hints.get("structures"):
            lines.append(f"Structures: format={s.get('format', '?')}, path_field={s.get('path_field', '?')}")

    return "\n".join(lines)


def format_job_query(data: dict) -> str:
    """Format job query results as a table."""
    rows = data.get("rows", [])
    columns = data.get("columns", [])
    total = data.get("totalCount", len(rows))
    has_more = data.get("hasMore", False)

    if not rows:
        return f"No data rows. Total: {total}"

    # Compute column widths
    col_widths: dict[str, int] = {}
    for col in columns:
        col_widths[col] = len(col)
    for row in rows:
        for col in columns:
            val = str(row.get(col, ""))
            col_widths[col] = max(col_widths.get(col, 0), min(len(val), 40))

    # Header
    header = "  ".join(_pad(col, col_widths[col]) for col in columns)
    sep = "  ".join("-" * col_widths[col] for col in columns)
    lines = [header, sep]

    # Rows
    for row in rows:
        cells = []
        for col in columns:
            val = row.get(col, "")
            cells.append(_pad(_truncate(str(val), 40), col_widths[col]))
        lines.append("  ".join(cells))

    # Footer
    showing = len(rows)
    footer = f"\nShowing {showing} of {total} rows"
    if has_more:
        footer += " (more available — use --offset and --limit)"
    lines.append(footer)

    return "\n".join(lines)


# ── Pages ────────────────────────────────────────────────────────


def format_pages_table(pages: list[dict], *, active_page_id: str | None = None) -> str:
    """Format a list of pages as a table."""
    if not pages:
        return "No pages found."

    lines = [
        f"{_pad('Active', 6)}  {_pad('ID', 38)}  Title",
        f"{'-' * 6}  {'-' * 38}  {'-' * 30}",
    ]
    for p in pages:
        marker = "*" if p.get("id") == active_page_id else ""
        pid = _pad(p.get("id", "?"), 38)
        title = p.get("title", "(untitled)")
        lines.append(f"{_pad(marker, 6)}  {pid}  {title}")
    return "\n".join(lines)


# ── Nodes ────────────────────────────────────────────────────────


def format_nodes_table(nodes: list[dict]) -> str:
    """Format a list of muni nodes as a table."""
    if not nodes:
        return "No nodes found."

    lines = [
        f"{_pad('ID', 38)}  {_pad('Type', 10)}  {_pad('Title', 30)}  {_pad('Script', 6)}  Position",
        f"{'-' * 38}  {'-' * 10}  {'-' * 30}  {'-' * 6}  {'-' * 16}",
    ]
    for n in nodes:
        nid = _pad(_truncate(n.get("id", "?"), 38), 38)
        ntype = _pad(n.get("type", "?"), 10)
        title = _pad(_truncate(n.get("title", ""), 30), 30)
        has_script = _pad("yes" if n.get("hasScript") else "no", 6)
        pos = f"({_format_number(n.get('positionX'))}, {_format_number(n.get('positionY'))})"
        lines.append(f"{nid}  {ntype}  {title}  {has_script}  {pos}")
    return "\n".join(lines)


def format_node_detail(node: dict) -> str:
    """Format detailed node read view (read_node output)."""
    # Soft-deleted nodes get a short response
    if node.get("isRemoved"):
        return "\n".join([
            f"Node: {node.get('nodeId', node.get('id', '?'))}",
            f"Title: {node.get('title', '(none)')}",
            f"Type: {node.get('type', '?')}",
            "Status: removed",
        ])

    lines = [
        f"Node: {node.get('nodeId', '?')}",
        f"Title: {node.get('title', '(none)')}",
        f"Type: {node.get('type', '?')}",
        f"Position: ({_format_number(node.get('positionX'))}, {_format_number(node.get('positionY'))})",
    ]

    # Runtime
    runtime = node.get("runtime")
    if isinstance(runtime, dict) and runtime:
        if lifecycle := runtime.get("lifecycle"):
            lines.append(f"Lifecycle: {lifecycle}")
        if requested_at := runtime.get("requestedAt"):
            lines.append(f"Requested At: {requested_at}")

    # Gate results
    cr = node.get("compileResult")
    er = node.get("executeResult")
    vr = node.get("validateResult") or node.get("validation")
    if cr or er or vr:
        compile_s = cr.get("status", "—") if isinstance(cr, dict) else "—"
        execute_s = er.get("status", "—") if isinstance(er, dict) else "—"
        validate_s = vr.get("status", "—") if isinstance(vr, dict) else "—"
        lines.append(f"Gates: compile={compile_s}  execute={execute_s}  validate={validate_s}")

    # Render health
    rh = node.get("renderHealth")
    if isinstance(rh, dict):
        msg = f" ({rh['message']})" if rh.get("message") else ""
        lines.append(f"Render: {rh.get('status', '?')}{msg}")

    # Script
    script = node.get("script")
    if script:
        lines.append("")
        lines.append("Script:")
        lines.extend(_indent_block(str(script)))

    # Current Data
    current_data = node.get("currentData")
    if isinstance(current_data, dict) and current_data:
        lines.append("")
        lines.append("Current Data:")
        if data_type := current_data.get("dataType"):
            lines.append(f"  Data Type: {data_type}")
        if row_count := current_data.get("rowCount"):
            lines.append(f"  Row Count: {row_count}")
        column_schema = current_data.get("columnSchema")
        if isinstance(column_schema, list) and column_schema:
            col_names = [c.get("name", "?") for c in column_schema if isinstance(c, dict)]
            lines.append(f"  Columns: {', '.join(col_names[:10])}")
        preview = current_data.get("preview")
        if isinstance(preview, dict) and preview:
            lines.append("  Preview:")
            lines.extend(_format_json_block(preview))
        artifacts = current_data.get("artifacts")
        if isinstance(artifacts, list) and artifacts:
            lines.append(f"  Artifacts: {len(artifacts)}")

    # Python files (code nodes)
    python_files = node.get("pythonFiles") or []
    if python_files:
        lines.append("")
        lines.append(f"Python Files ({len(python_files)}):")
        for pf in python_files:
            path = pf.get("path", "?")
            content = pf.get("content", "")
            line_count = content.count("\n") + 1 if content else 0
            lines.append(f"  {path} ({line_count} lines)")
            lines.extend(_indent_block(content, prefix="    "))

    # Python stdout/stderr (code nodes)
    if isinstance(runtime, dict):
        stdout = runtime.get("pythonStdout")
        stderr = runtime.get("pythonStderr")
        if stdout:
            lines.append("")
            lines.append("Python Stdout:")
            lines.extend(_indent_block(str(stdout)))
        if stderr:
            lines.append("")
            lines.append("Python Stderr:")
            lines.extend(_indent_block(str(stderr)))

    # Connections
    connections = node.get("connections", [])
    if connections:
        lines.append("")
        lines.append(f"Connections ({len(connections)}):")
        for conn in connections:
            kind = conn.get("kind", "?")
            source = conn.get("sourceNodeId") or "(external)"
            lines.append(f"  {conn.get('id', '?')}: {source} -> this ({kind})")

    return "\n".join(lines)


def format_search_results(nodes: list[dict], query: str) -> str:
    """Format search results with a match count header."""
    if not nodes:
        return f'No nodes matching "{query}".'
    header = f'Found {len(nodes)} node{"s" if len(nodes) != 1 else ""} matching "{query}":'
    return header + "\n\n" + format_nodes_table(nodes)
