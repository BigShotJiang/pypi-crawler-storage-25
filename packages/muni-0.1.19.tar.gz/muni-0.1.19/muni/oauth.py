"""OAuth 2.0 login flows for the muni CLI.

Three flows, all against the muni app (not Supabase directly):

    browser     PKCE + localhost loopback (RFC 7636 §4.1 + §4.2)
                → primary flow when a desktop browser is available
    device      Device authorization grant (RFC 8628)
                → fallback for SSH/headless; user types a code on another device
    password    Legacy email+password against Supabase Auth
                → kept for CI/scripting; --password on `muni login`

Each returns the same credential shape consumed by `auth.py`:

    {
        "access_token":  str,  # Supabase-compatible JWT, ~1h lifetime
        "refresh_token": str,  # opaque CLI token (prefix "mcli_"), rotated on every refresh
        "expires_at":    int,  # unix seconds
        "user_id":       str,
        "email":         str,
    }
"""

from __future__ import annotations

import base64
import hashlib
import http.server
import json
import os
import platform
import secrets
import socket
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import dataclass

from .exceptions import AuthError, MuniError


# ─── Public API ───────────────────────────────────────────────────────────────

def login_browser(app_url: str, *, client_name: str | None = None, open_browser: bool = True) -> dict:
    """Run the PKCE + loopback flow and return credentials."""
    flow = _PkceFlow(app_url, client_name=client_name or _default_client_name())
    return flow.run(open_browser=open_browser)


def login_device(app_url: str, *, client_name: str | None = None, open_browser: bool = True) -> dict:
    """Run the device authorization grant and return credentials."""
    return _run_device_flow(app_url, client_name or _default_client_name(), open_browser=open_browser)


def refresh(app_url: str, refresh_token: str) -> dict:
    """Exchange a CLI refresh token for a new access+refresh pair."""
    return _token_request(app_url, {"grant_type": "refresh_token", "refresh_token": refresh_token})


def revoke(app_url: str, refresh_token: str) -> None:
    """Best-effort revoke a CLI refresh token. Silent on failure."""
    try:
        _post_json(_url(app_url, "/api/cli/revoke"), {"refresh_token": refresh_token})
    except Exception:
        pass


# ─── PKCE + loopback implementation ──────────────────────────────────────────

@dataclass
class _PkceFlow:
    app_url: str
    client_name: str

    def run(self, *, open_browser: bool) -> dict:
        code_verifier = _random_url_safe(64)
        code_challenge = _b64url(hashlib.sha256(code_verifier.encode()).digest())
        state = _random_url_safe(24)

        server = _LoopbackServer()
        redirect_uri = server.redirect_uri
        authorize_url = self._authorize_url(code_challenge, state, redirect_uri)

        print(f"Opening browser to {self.app_url}/cli/authorize …", file=sys.stderr)
        print("If the browser does not open, visit:", file=sys.stderr)
        print(f"  {authorize_url}\n", file=sys.stderr)
        if open_browser:
            try:
                webbrowser.open(authorize_url)
            except Exception:
                pass

        try:
            result = server.wait(timeout=300)
        finally:
            server.stop()

        if result.get("state") != state:
            raise AuthError("State mismatch in OAuth callback (possible CSRF).")
        if result.get("error"):
            raise AuthError(f"Authorization failed: {result.get('error_description') or result['error']}")
        code = result.get("code")
        if not code:
            raise AuthError("Authorization callback missing code parameter.")

        token = _token_request(
            self.app_url,
            {
                "grant_type": "authorization_code",
                "code": code,
                "code_verifier": code_verifier,
                "client_name": self.client_name,
                "user_agent": _user_agent(),
            },
        )
        return token

    def _authorize_url(self, code_challenge: str, state: str, redirect_uri: str) -> str:
        qs = urllib.parse.urlencode({
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "redirect_uri": redirect_uri,
            "state": state,
            "client_name": self.client_name,
        })
        return f"{self.app_url.rstrip('/')}/cli/authorize?{qs}"


class _LoopbackServer:
    """Tiny localhost HTTP server that captures the single OAuth callback."""

    def __init__(self) -> None:
        self._result: dict | None = None
        self._event = threading.Event()
        self._httpd = http.server.HTTPServer(("127.0.0.1", 0), self._build_handler())
        self._port = self._httpd.server_address[1]
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()

    @property
    def redirect_uri(self) -> str:
        return f"http://127.0.0.1:{self._port}/callback"

    def wait(self, *, timeout: float) -> dict:
        if not self._event.wait(timeout=timeout):
            raise AuthError(f"Timed out waiting for authorization (>{int(timeout)}s).")
        assert self._result is not None
        return self._result

    def stop(self) -> None:
        try:
            self._httpd.shutdown()
            self._httpd.server_close()
        except Exception:
            pass

    def _build_handler(self):
        server = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *_args, **_kwargs):  # silence access logs
                return

            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path != "/callback":
                    self.send_response(404)
                    self.end_headers()
                    return
                params = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
                server._result = params
                # Minimal success page — user returns to terminal.
                body = _callback_html(ok=not params.get("error"))
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                server._event.set()

        return Handler


def _callback_html(*, ok: bool) -> bytes:
    title = "muni CLI authorized" if ok else "Authorization cancelled"
    message = (
        "You can close this tab and return to your terminal."
        if ok else
        "The CLI has been notified. You can close this tab."
    )
    html = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
  html,body {{ margin:0; height:100%; font-family:-apple-system,system-ui,sans-serif;
               background:#fafaf9; color:#1a1a1a; }}
  .card {{ position:fixed; inset:0; display:flex; align-items:center; justify-content:center; }}
  .card > div {{ max-width:420px; padding:28px 32px; border-radius:20px; background:#fff;
                 box-shadow:0 24px 80px rgba(0,0,0,0.12); border:1px solid rgba(0,0,0,0.06); }}
  h1 {{ margin:0 0 8px; font-size:20px; letter-spacing:-0.02em; }}
  p  {{ margin:0; color:#7a7a75; font-size:14px; }}
</style></head>
<body><div class="card"><div><h1>{title}</h1><p>{message}</p></div></div></body></html>"""
    return html.encode()


# ─── Device authorization grant ──────────────────────────────────────────────

def _run_device_flow(app_url: str, client_name: str, *, open_browser: bool) -> dict:
    start = _post_json(_url(app_url, "/api/cli/device"), {"client_name": client_name})
    device_code = start["device_code"]
    user_code = start["user_code"]
    verify_uri = start["verification_uri"]
    verify_uri_complete = start.get("verification_uri_complete") or verify_uri
    interval = max(1, int(start.get("interval", 5)))
    expires_in = int(start.get("expires_in", 900))

    print("To authorize the muni CLI:", file=sys.stderr)
    print(f"  1. Open {verify_uri}", file=sys.stderr)
    print(f"  2. Enter code {user_code}", file=sys.stderr)
    print(f"\nOr follow this link: {verify_uri_complete}\n", file=sys.stderr)
    if open_browser:
        try:
            webbrowser.open(verify_uri_complete)
        except Exception:
            pass

    deadline = time.time() + expires_in
    while time.time() < deadline:
        time.sleep(interval)
        try:
            return _token_request(app_url, {"grant_type": "device_code", "device_code": device_code})
        except AuthError as err:
            code = getattr(err, "oauth_code", None)
            if code == "authorization_pending":
                continue
            if code == "slow_down":
                interval += 5
                continue
            raise
    raise AuthError("Device authorization timed out.")


# ─── HTTP helpers ────────────────────────────────────────────────────────────

def _token_request(app_url: str, body: dict) -> dict:
    return _post_json(_url(app_url, "/api/cli/token"), body)


def _post_json(url: str, body: dict) -> dict:
    # Set a real User-Agent. Cloudflare's bot filters 403 requests with
    # Python's default "Python-urllib/x.y" UA, which breaks the flow in prod.
    req = urllib.request.Request(
        url,
        method="POST",
        data=json.dumps(body).encode(),
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": _user_agent(),
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as err:
        raw = err.read().decode(errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {"error_description": raw}
        exc = AuthError(data.get("error_description") or data.get("error") or f"HTTP {err.code}")
        exc.oauth_code = data.get("error")  # type: ignore[attr-defined]
        exc.status_code = err.code  # type: ignore[attr-defined]
        raise exc
    except urllib.error.URLError as err:
        raise MuniError(f"Could not reach {url}: {err.reason}")


def _url(app_url: str, path: str) -> str:
    return f"{app_url.rstrip('/')}{path}"


# ─── Utilities ───────────────────────────────────────────────────────────────

def _random_url_safe(nbytes: int) -> str:
    return _b64url(secrets.token_bytes(nbytes))


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _default_client_name() -> str:
    try:
        host = socket.gethostname().split(".")[0] or "unknown-host"
    except Exception:
        host = "unknown-host"
    return f"muni-cli on {host}"


def _user_agent() -> str:
    return f"muni-cli/{_muni_version()} ({platform.system()} {platform.release()}; Python {platform.python_version()})"


def _muni_version() -> str:
    try:
        from . import __version__  # type: ignore
        return str(__version__)
    except Exception:
        return "0.0.0"
