"""Configuration file paths, env var reading, and profile-aware defaults."""

import json
import os
from pathlib import Path
from typing import Any

from .exceptions import MuniError

CONFIG_KEYS = (
    "app_url",
    "api_url",
    "supabase_url",
    "supabase_publishable_key",
    "active_space_id",
    "active_page_id",
    "sandbox_url",
    "sandbox_secret",
    "sandbox_tools_api_url",
)

# Public defaults — users shouldn't need to configure these.
DEFAULTS = {
    "api_url": "https://bioarena-api-tools-production.up.railway.app",
    "app_url": "https://muni.bio",
    "supabase_url": "https://kxoseeayisbxmbjmapjc.supabase.co",
    "supabase_publishable_key": "sb_publishable_g6AicEny85FI5yLqZXprRg_HYvO1_N4",
    "sandbox_tools_api_url": "https://bioarena-api-tools-production.up.railway.app",
}

CREDENTIAL_KEYS = (
    "access_token",
    "refresh_token",
    "expires_at",
    "user_id",
    "email",
)


def _muni_dir() -> Path:
    """Return ~/.muni, creating it if needed."""
    d = Path.home() / ".muni"
    d.mkdir(mode=0o700, exist_ok=True)
    return d


def config_path() -> Path:
    return _muni_dir() / "config.json"


def credentials_path() -> Path:
    return _muni_dir() / "credentials.json"


def _read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with open(path) as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


def _selected_profile(raw: dict[str, Any]) -> str:
    env_profile = os.environ.get("MUNI_PROFILE", "").strip()
    if env_profile:
        return env_profile
    current = raw.get("current_profile")
    if isinstance(current, str) and current.strip():
        return current.strip()
    return "default"


def _normalize_profiles(raw: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    profiles_raw = raw.get("profiles")
    if isinstance(profiles_raw, dict):
        profiles: dict[str, dict[str, Any]] = {}
        for name, profile in profiles_raw.items():
            if not isinstance(name, str) or not isinstance(profile, dict):
                continue
            profiles[name] = {
                key: profile[key]
                for key in keys
                if key in profile and profile[key] not in (None, "")
            }
        if not profiles:
            profiles = {"default": {}}
        current = raw.get("current_profile")
        current_profile = current if isinstance(current, str) and current in profiles else next(iter(profiles))
        return {
            "current_profile": current_profile,
            "profiles": profiles,
        }

    legacy = {
        key: raw[key]
        for key in keys
        if key in raw and raw[key] not in (None, "")
    }
    return {
        "current_profile": "default",
        "profiles": {"default": legacy},
    }


def _write_profile_doc(path: Path, payload: dict[str, Any]) -> None:
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
    os.chmod(path, 0o600)


def list_profiles() -> list[str]:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    return sorted(raw["profiles"].keys())


def current_profile_name() -> str:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    return _selected_profile(raw)


def set_current_profile(profile: str) -> None:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    if profile not in raw["profiles"]:
        raw["profiles"][profile] = {}
    raw["current_profile"] = profile
    _write_profile_doc(config_path(), raw)


def load_config(profile: str | None = None) -> dict:
    """Load config from file, falling back to built-in defaults and env vars."""
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    selected = profile or _selected_profile(raw)

    # Start with built-in defaults, then layer profile values on top
    cfg = dict(DEFAULTS)
    cfg.update(raw["profiles"].get(selected, {}))

    # Env vars override everything
    if v := os.environ.get("MUNI_API_URL"):
        cfg["api_url"] = v
    if v := os.environ.get("MUNI_APP_URL"):
        cfg["app_url"] = v
    if v := os.environ.get("MUNI_SUPABASE_URL"):
        cfg["supabase_url"] = v
    if v := os.environ.get("MUNI_SUPABASE_PUBLISHABLE_KEY"):
        cfg["supabase_publishable_key"] = v
    if v := os.environ.get("MUNI_SPACE_ID"):
        cfg["active_space_id"] = v
    if v := os.environ.get("MUNI_PAGE_ID"):
        cfg["active_page_id"] = v

    cfg["profile"] = selected
    return cfg


def save_config(cfg: dict, *, profile: str | None = None, set_current: bool = True) -> None:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or raw["current_profile"]
    raw["profiles"][selected] = {
        key: cfg[key]
        for key in CONFIG_KEYS
        if key in cfg and cfg[key] not in (None, "")
    }
    if set_current:
        raw["current_profile"] = selected
    _write_profile_doc(config_path(), raw)


def load_credentials(profile: str | None = None) -> dict | None:
    raw = _normalize_profiles(_read_json(credentials_path()), CREDENTIAL_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or current_profile_name()
    creds = raw["profiles"].get(selected)
    return dict(creds) if creds else None


def save_credentials(creds: dict, *, profile: str | None = None) -> None:
    raw = _normalize_profiles(_read_json(credentials_path()), CREDENTIAL_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or current_profile_name()
    raw["profiles"][selected] = {
        key: creds[key]
        for key in CREDENTIAL_KEYS
        if key in creds and creds[key] not in (None, "")
    }
    raw["current_profile"] = selected
    _write_profile_doc(credentials_path(), raw)


def clear_credentials(profile: str | None = None) -> None:
    p = credentials_path()
    if not p.exists():
        return

    raw = _normalize_profiles(_read_json(p), CREDENTIAL_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or current_profile_name()
    raw["profiles"].pop(selected, None)
    if not raw["profiles"]:
        p.unlink()
        return

    if raw["current_profile"] not in raw["profiles"]:
        raw["current_profile"] = next(iter(raw["profiles"]))
    _write_profile_doc(p, raw)


def get_active_space_id(override: str | None = None) -> str:
    """Return the space_id to use: explicit override > config > error."""
    if override:
        return override
    cfg = load_config()
    space_id = cfg.get("active_space_id")
    if not space_id:
        raise MuniError(
            "No active space. Run 'muni space use <space_id>' or pass --space-id."
        )
    return space_id


def get_active_page_id(override: str | None = None) -> str:
    """Return the page_id to use: explicit override > config > first page of active space."""
    if override:
        return override
    cfg = load_config()
    page_id = cfg.get("active_page_id")
    if page_id:
        return page_id
    # Fall back to the first page of the active space
    space_id = cfg.get("active_space_id")
    if space_id:
        try:
            from .client import MuniClient
            client = MuniClient()
            pages = client.pages.list(space_id)
            if pages:
                first_page = pages[0].get("id")
                if first_page:
                    return first_page
        except Exception:
            pass
    raise MuniError(
        "No active page. Run 'muni page use <page_id>' or pass --page-id."
    )
