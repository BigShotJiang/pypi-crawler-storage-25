"""Entry point for `python -m muni`."""

from .cli import main

main()
