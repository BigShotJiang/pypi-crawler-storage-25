# Payment Orchestrator Library v2.0

Pure business logic library for payment processing. No infrastructure dependencies, fully reusable across different platforms.

## What's Included ✅

### Core Business Logic
- **PaymentValidator**: Validate card numbers, expiry dates, CVV, amounts
- **FraudDetector**: Detect suspicious transactions based on configurable rules
- **PaymentEncryptor**: Encrypt/decrypt sensitive payment data
- **ReceiptGenerator**: Generate formatted payment receipts

All functions work with plain Python dictionaries - no models required.

## What's NOT Included ❌

Infrastructure concerns have been moved to application layer:
- DynamoDB operations
- SQS queue management
- SNS notifications
- Lambda invocations
- AWS SDK dependencies

## Installation

```bash
pip install -e .
```

## Usage

### Validation
```python
from payment_orchestrator import PaymentValidator

validator = PaymentValidator()
payment_data = {
    "card_number": "4242424242424242",
    "cvv": "123",
    "expiry_month": 12,
    "expiry_year": 2025,
    "amount": 1000,
    "currency": "USD",
    "cardholder_name": "John Doe",
    "email": "john@example.com"
}

is_valid, error = validator.validate(payment_data)
if not is_valid:
    print(f"Validation failed: {error}")
```

### Fraud Detection
```python
from payment_orchestrator import FraudDetector

fraud_detector = FraudDetector(high_amount_threshold=1000000)  # $10,000
is_fraud, reason = fraud_detector.check_fraud(payment_data)
if is_fraud:
    print(f"Fraud detected: {reason}")
```

### Encryption
```python
from payment_orchestrator import PaymentEncryptor

encryptor = PaymentEncryptor(encryption_type="none", region="us-east-1")
encrypted_card = encryptor.encrypt("4242424242424242")
decrypted_card = encryptor.decrypt(encrypted_card)
```

### Receipt Generation
```python
from payment_orchestrator import ReceiptGenerator

generator = ReceiptGenerator()
receipt_html = generator.generate_receipt(
    transaction_id="txn_123",
    amount=1000,
    currency="USD",
    cardholder_name="John Doe",
    masked_card="****4242",
    timestamp="2024-01-01T12:00:00Z",
    status="SUCCESS"
)
```

## Architecture

This library follows the **pure business logic** pattern:

```
Library (Pure Logic)
├── Validation rules
├── Fraud detection algorithms
├── Encryption/decryption
└── Receipt formatting

Application (Infrastructure)
├── DynamoDB operations
├── SQS queue management
├── SNS notifications
└── Lambda orchestration
```

## Benefits

1. **Reusable**: Use in any Python application (Flask, FastAPI, Lambda, Django)
2. **Testable**: No AWS mocks needed for unit tests
3. **Portable**: Works with any database or message queue
4. **Configurable**: Applications provide their own infrastructure configuration
5. **Maintainable**: Clear separation of concerns

## Migration from v1.x

If you were using v1.x with infrastructure components:

**Before (v1.x):**
```python
from payment_orchestrator.core.orchestrator import PaymentOrchestrator

orchestrator = PaymentOrchestrator(
    sqs_queue_url="...",
    dynamodb_table="...",
    sns_topic_arn="...",
)
result = orchestrator.process_payment(payment_data, endpoint)
```

**After (v2.0):**
```python
# Import pure logic from library
from payment_orchestrator import PaymentValidator, FraudDetector

# Import infrastructure from your application
from services.db_manager import TransactionStore
from services.sns_notifier import SNSNotifier

# Use library for business logic
validator = PaymentValidator()
fraud_detector = FraudDetector()

# Use application services for infrastructure
transaction_store = TransactionStore(table_name="your-table")
notifier = SNSNotifier(topic_arn="your-topic")
```

## Version History

- **v2.0.0**: Refactored to pure business logic, removed AWS dependencies
- **v1.x**: Monolithic library with infrastructure included

## License

MIT
