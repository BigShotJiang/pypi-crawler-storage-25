"""Receipt generator service for payment transactions - HTML version."""

import boto3
import logging
from datetime import datetime, timedelta
from typing import Optional
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class ReceiptGenerator:
    """
    Generates HTML receipts for payment transactions and uploads to S3.
    """
    
    def __init__(self, s3_bucket: str, region: str = "us-east-1"):
        """
        Initialize receipt generator.
        
        Args:
            s3_bucket: S3 bucket name for storing receipts
            region: AWS region
        """
        self.s3_bucket = s3_bucket
        self.region = region
        self.s3_client = boto3.client('s3', region_name=region)
        logger.info(f"ReceiptGenerator initialized with bucket: {s3_bucket}")
    
    def generate_and_upload_receipt(
        self,
        transaction_id: str,
        cardholder_name: str,
        email: str,
        amount: int,
        currency: str,
        card_last4: str,
        timestamp: Optional[str] = None
    ) -> Optional[str]:
        """
        Generate HTML receipt and upload to S3.
        
        Args:
            transaction_id: Transaction ID
            cardholder_name: Customer name
            email: Customer email
            amount: Payment amount in cents
            currency: Currency code
            card_last4: Last 4 digits of card
            timestamp: Transaction timestamp (ISO format)
            
        Returns:
            S3 URL of the receipt, or None if failed
        """
        try:
            # Generate receipt HTML
            html_content = self._generate_receipt_html(
                transaction_id=transaction_id,
                cardholder_name=cardholder_name,
                email=email,
                amount=amount,
                currency=currency,
                card_last4=card_last4,
                timestamp=timestamp or datetime.utcnow().isoformat()
            )
            
            # Upload to S3
            receipt_url = self._upload_to_s3(transaction_id, html_content)
            
            if receipt_url:
                logger.info(f"✅ Receipt generated and uploaded: {receipt_url}")
                return receipt_url
            else:
                logger.error(f"❌ Failed to upload receipt for: {transaction_id}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Error generating receipt: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None
    
    def _generate_receipt_html(
        self,
        transaction_id: str,
        cardholder_name: str,
        email: str,
        amount: int,
        currency: str,
        card_last4: str,
        timestamp: str
    ) -> str:
        """Generate HTML receipt content."""
        
        # Format data
        amount_formatted = amount / 100
        try:
            date_formatted = datetime.fromisoformat(timestamp.replace('Z', '+00:00')).strftime('%B %d, %Y at %I:%M %p UTC')
        except:
            date_formatted = datetime.utcnow().strftime('%B %d, %Y at %I:%M %p UTC')
        
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt - {transaction_id}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }}
        .receipt {{
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }}
        .header {{
            text-align: center;
            margin-bottom: 40px;
        }}
        .checkmark {{
            font-size: 64px;
            color: #28a745;
            margin-bottom: 10px;
        }}
        h1 {{
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }}
        .status {{
            display: inline-block;
            background: #28a745;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }}
        .section {{
            margin-bottom: 30px;
        }}
        .section-title {{
            font-size: 14px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .detail-row {{
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }}
        .detail-label {{
            color: #666;
            font-size: 14px;
        }}
        .detail-value {{
            color: #333;
            font-size: 14px;
            font-weight: 500;
        }}
        .amount-box {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            margin: 30px 0;
        }}
        .amount-label {{
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 10px;
        }}
        .amount-value {{
            font-size: 36px;
            font-weight: 700;
        }}
        .footer {{
            text-align: center;
            color: #666;
            font-size: 12px;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #f0f0f0;
        }}
        .footer p {{
            margin: 5px 0;
        }}
        @media print {{
            body {{
                background: white;
            }}
            .receipt {{
                box-shadow: none;
            }}
        }}
    </style>
</head>
<body>
    <div class="receipt">
        <div class="header">
            <div class="checkmark">✓</div>
            <h1>Payment Successful</h1>
            <span class="status">PAID</span>
        </div>
        
        <div class="section">
            <div class="section-title">Transaction Details</div>
            <div class="detail-row">
                <span class="detail-label">Transaction ID</span>
                <span class="detail-value">{transaction_id}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Date & Time</span>
                <span class="detail-value">{date_formatted}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Status</span>
                <span class="detail-value" style="color: #28a745; font-weight: 600;">SUCCESS</span>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Customer Information</div>
            <div class="detail-row">
                <span class="detail-label">Name</span>
                <span class="detail-value">{cardholder_name}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Email</span>
                <span class="detail-value">{email}</span>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Payment Method</div>
            <div class="detail-row">
                <span class="detail-label">Card</span>
                <span class="detail-value">•••• •••• •••• {card_last4}</span>
            </div>
        </div>
        
        <div class="amount-box">
            <div class="amount-label">Amount Paid</div>
            <div class="amount-value">{amount_formatted:.2f} {currency.upper()}</div>
        </div>
        
        <div class="footer">
            <p>Thank you for your payment!</p>
            <p>This is an automatically generated receipt.</p>
            <p>If you have any questions, please contact our support team.</p>
        </div>
    </div>
</body>
</html>
"""
        return html
    
    def _upload_to_s3(self, transaction_id: str, html_content: str) -> Optional[str]:
        """
        Upload receipt HTML to S3.
        
        Args:
            transaction_id: Transaction ID
            html_content: HTML content as string
            
        Returns:
            S3 URL or None if failed
        """
        try:
            # Generate S3 key
            timestamp = datetime.utcnow().strftime('%Y/%m/%d')
            s3_key = f"receipts/{timestamp}/{transaction_id}.html"
            
            # Upload to S3
            self.s3_client.put_object(
                Bucket=self.s3_bucket,
                Key=s3_key,
                Body=html_content.encode('utf-8'),
                ContentType='text/html',
                CacheControl='max-age=31536000',  # 1 year cache
                Metadata={
                    'transaction_id': transaction_id,
                    'generated_at': datetime.utcnow().isoformat()
                }
            )
            
            # Generate presigned URL (valid for 7 days)
            receipt_url = self.s3_client.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': self.s3_bucket,
                    'Key': s3_key
                },
                ExpiresIn=604800  # 7 days
            )
            
            logger.info(f"✅ Receipt uploaded to S3: {s3_key}")
            return receipt_url
            
        except ClientError as e:
            logger.error(f"❌ S3 upload failed: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Unexpected error uploading to S3: {e}")
            return None
    
    def get_receipt_url(self, transaction_id: str) -> Optional[str]:
        """
        Get presigned URL for existing receipt.
        
        Args:
            transaction_id: Transaction ID
            
        Returns:
            Presigned URL or None if not found
        """
        try:
            # Try to find receipt in S3
            # Search in last 30 days
            for days_ago in range(30):
                date = datetime.utcnow() - timedelta(days=days_ago)
                date_str = date.strftime('%Y/%m/%d')
                s3_key = f"receipts/{date_str}/{transaction_id}.html"
                
                try:
                    # Check if object exists
                    self.s3_client.head_object(Bucket=self.s3_bucket, Key=s3_key)
                    
                    # Generate presigned URL
                    receipt_url = self.s3_client.generate_presigned_url(
                        'get_object',
                        Params={
                            'Bucket': self.s3_bucket,
                            'Key': s3_key
                        },
                        ExpiresIn=604800  # 7 days
                    )
                    
                    return receipt_url
                except ClientError:
                    continue
            
            logger.warning(f"Receipt not found for transaction: {transaction_id}")
            return None
            
        except Exception as e:
            logger.error(f"Error retrieving receipt URL: {e}")
            return None
