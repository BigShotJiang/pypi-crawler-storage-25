"""
Payment Orchestrator Library - Pure Business Logic

This library provides reusable payment processing logic without infrastructure dependencies.

Core Components:
- Validator: Payment data validation
- FraudDetector: Fraud detection algorithms
- Encryptor: Data encryption/decryption
- ReceiptGenerator: Receipt formatting

All functions work with plain Python dictionaries - no models required.
"""

__version__ = "2.0.0"

# Core business logic
from payment_orchestrator.core.validator import PaymentValidator
from payment_orchestrator.core.fraud_detector import FraudDetector

# Services (pure logic, no AWS dependencies)
from payment_orchestrator.services.encryptor import PaymentEncryptor
from payment_orchestrator.services.receipt_generator import ReceiptGenerator

__all__ = [
    "PaymentValidator",
    "FraudDetector",
    "PaymentEncryptor",
    "ReceiptGenerator",
]
