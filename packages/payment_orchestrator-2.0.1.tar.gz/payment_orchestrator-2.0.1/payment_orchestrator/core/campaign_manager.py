"""
Campaign management logic for crowdfunding platform.
Handles campaign calculations, progress tracking, and validation.
"""
from datetime import datetime, timezone
from decimal import Decimal
from typing import Dict, Optional, List
from enum import Enum


class CampaignStatus(Enum):
    """Campaign status enumeration."""
    DRAFT = "draft"
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


class CampaignManager:
    """Manages campaign business logic and calculations."""
    
    @staticmethod
    def calculate_progress(current_amount: Decimal, goal_amount: Decimal) -> float:
        """
        Calculate campaign progress percentage.
        
        Args:
            current_amount: Current amount raised
            goal_amount: Target goal amount
            
        Returns:
            Progress percentage (0-100)
        """
        if goal_amount <= 0:
            return 0.0
        
        progress = (float(current_amount) / float(goal_amount)) * 100
        return min(progress, 100.0)
    
    @staticmethod
    def calculate_remaining_amount(current_amount: Decimal, goal_amount: Decimal) -> Decimal:
        """
        Calculate remaining amount to reach goal.
        
        Args:
            current_amount: Current amount raised
            goal_amount: Target goal amount
            
        Returns:
            Remaining amount needed
        """
        remaining = goal_amount - current_amount
        return max(remaining, Decimal('0'))
    
    @staticmethod
    def calculate_days_remaining(end_date: datetime) -> int:
        """
        Calculate days remaining until campaign end.
        
        Args:
            end_date: Campaign end date
            
        Returns:
            Number of days remaining (0 if expired)
        """
        now = datetime.now(timezone.utc)
        if end_date.tzinfo is None:
            end_date = end_date.replace(tzinfo=timezone.utc)
        
        delta = end_date - now
        return max(delta.days, 0)
    
    @staticmethod
    def determine_status(
        current_status: str,
        current_amount: Decimal,
        goal_amount: Decimal,
        end_date: datetime
    ) -> str:
        """
        Determine campaign status based on current state.
        
        Args:
            current_status: Current campaign status
            current_amount: Current amount raised
            goal_amount: Target goal amount
            end_date: Campaign end date
            
        Returns:
            Updated campaign status
        """
        # Don't change draft or cancelled status
        if current_status in [CampaignStatus.DRAFT.value, CampaignStatus.CANCELLED.value]:
            return current_status
        
        # Check if completed
        if current_amount >= goal_amount:
            return CampaignStatus.COMPLETED.value
        
        # Check if expired
        days_remaining = CampaignManager.calculate_days_remaining(end_date)
        if days_remaining == 0:
            return CampaignStatus.EXPIRED.value
        
        return CampaignStatus.ACTIVE.value
    
    @staticmethod
    def validate_campaign_data(
        title: str,
        description: str,
        goal_amount: Decimal,
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, List[str]]:
        """
        Validate campaign data.
        
        Args:
            title: Campaign title
            description: Campaign description
            goal_amount: Target goal amount
            start_date: Campaign start date
            end_date: Campaign end date
            
        Returns:
            Dictionary with validation errors (empty if valid)
        """
        errors = {}
        
        if not title or len(title.strip()) < 3:
            errors['title'] = ['Title must be at least 3 characters']
        
        if not description or len(description.strip()) < 10:
            errors['description'] = ['Description must be at least 10 characters']
        
        if goal_amount <= 0:
            errors['goal_amount'] = ['Goal amount must be greater than 0']
        
        if start_date >= end_date:
            errors['dates'] = ['End date must be after start date']
        
        now = datetime.now(timezone.utc)
        if start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        
        if start_date < now:
            errors['start_date'] = ['Start date cannot be in the past']
        
        return errors
    
    @staticmethod
    def get_campaign_summary(
        campaign_id: str,
        title: str,
        current_amount: Decimal,
        goal_amount: Decimal,
        end_date: datetime,
        status: str
    ) -> Dict:
        """
        Generate campaign summary with calculated fields.
        
        Args:
            campaign_id: Campaign identifier
            title: Campaign title
            current_amount: Current amount raised
            goal_amount: Target goal amount
            end_date: Campaign end date
            status: Campaign status
            
        Returns:
            Dictionary with campaign summary
        """
        progress = CampaignManager.calculate_progress(current_amount, goal_amount)
        remaining_amount = CampaignManager.calculate_remaining_amount(current_amount, goal_amount)
        days_remaining = CampaignManager.calculate_days_remaining(end_date)
        
        return {
            'campaign_id': campaign_id,
            'title': title,
            'current_amount': float(current_amount),
            'goal_amount': float(goal_amount),
            'remaining_amount': float(remaining_amount),
            'progress_percentage': round(progress, 2),
            'days_remaining': days_remaining,
            'end_date': end_date.isoformat(),
            'status': status,
            'is_active': status == CampaignStatus.ACTIVE.value,
            'is_completed': status == CampaignStatus.COMPLETED.value
        }
