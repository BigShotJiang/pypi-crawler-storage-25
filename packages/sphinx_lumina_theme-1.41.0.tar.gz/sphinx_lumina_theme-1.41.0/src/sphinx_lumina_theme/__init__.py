"""Sphinx Lumina Theme — a modern documentation theme."""

import copy
import hashlib
import re
from pathlib import Path

from sphinx import addnodes
from sphinx.environment.adapters.toctree import _resolve_toctree
from sphinx.util import logging

from . import _seo

logger = logging.getLogger(__name__)

__version__ = "1.41.0"

_CODE_STYLE_PRESETS = {
    "default": ("default", "monokai"),
    "nord": ("tango", "nord"),
    "one-dark": ("friendly", "one-dark"),
    "gruvbox": ("gruvbox-light", "gruvbox-dark"),
    "material": ("lovelace", "material"),
}

_HERO_FIELDS = (
    "hero_title",
    "hero_subtitle",
    "hero_primary_url",
    "hero_primary_text",
    "hero_secondary_url",
    "hero_secondary_text",
    "hero_tags",
)

# Average adult reading speed in words per minute, used by reading-time estimate.
_READING_WPM = 200


def _compute_reading_time(doctree):
    """Estimate reading time in minutes from a page doctree.

    Walks the doctree's text nodes, skipping content inside code blocks,
    images, comments, and toctrees. Returns ``None`` when the doctree is
    missing or contains no countable prose.
    """
    if doctree is None:
        return None

    from docutils import nodes

    skip_types = (
        nodes.literal_block,
        nodes.image,
        nodes.comment,
        nodes.target,
        nodes.system_message,
        addnodes.toctree,
    )

    word_count = 0
    for text_node in doctree.findall(nodes.Text):
        ancestor = text_node.parent
        while ancestor is not None and not isinstance(ancestor, skip_types):
            ancestor = ancestor.parent
        if ancestor is not None:
            continue  # text lives inside a skipped node
        word_count += len(text_node.astext().split())

    if not word_count:
        return None
    return max(1, round(word_count / _READING_WPM))


def _apply_code_style(app):
    """Map the ``code_style`` theme option to Pygments style pair.

    Replaces both the light and dark highlighters on the builder.
    Must run on ``builder-inited`` (not ``config-inited``) because theme
    extensions are loaded after ``config-inited`` has already fired.
    """
    opts = app.builder.theme_options
    code_style = opts.get("code_style", "default")
    if code_style == "default":
        return
    preset = _CODE_STYLE_PRESETS.get(code_style)
    if preset is None:
        valid = ", ".join(sorted(_CODE_STYLE_PRESETS))
        logger.warning(
            "Unknown code_style %r — valid presets: %s. Falling back to 'default'.",
            code_style,
            valid,
        )
        return
    light, dark = preset

    from sphinx.highlighting import PygmentsBridge

    app.builder.highlighter = PygmentsBridge("html", light)
    app.builder.dark_highlighter = PygmentsBridge("html", dark)


def _build_page_icons(app):
    """Build a mapping of pagename → icon name from page metadata."""
    icons = {}
    for pagename, meta in app.env.metadata.items():
        icon = meta.get("icon", "")
        if icon:
            icons[pagename] = icon
    return icons


def _resolve_href_to_pagename(href, pagename):
    """Best-effort mapping from a toctree link href back to a Sphinx pagename."""
    if href == "#" or href == "":
        return pagename
    target = re.sub(r"\.html$", "", href)
    target = re.sub(r"/$", "/index", target)
    if not target.startswith("/") and "/" in pagename:
        base = pagename.rsplit("/", 1)[0]
        target = base + "/" + target
    return target


def _with_basename_fallback(target):
    """Yield ``target`` and, if distinct, its basename.

    Sphinx pagenames are path-like (``guides/search``) but a page's own
    metadata may be keyed just by the basename in some edge cases.
    """
    yield target
    if "/" in target:
        yield target.rsplit("/", 1)[-1]


def _add_sidebar_icons(toctree_html, page_icons, pagename, get_icon_fn):
    """Post-process toctree HTML to inject icon SVGs into sidebar links."""
    if not page_icons:
        return toctree_html

    def _replace_link(match):
        full_match = match.group(0)
        href = match.group(1)
        if href == "#" or href == "":
            icon_name = page_icons.get(pagename, "")
        else:
            target = _resolve_href_to_pagename(href, pagename)
            icon_name = next(
                (
                    page_icons[k]
                    for k in _with_basename_fallback(target)
                    if k in page_icons
                ),
                "",
            )
        if not icon_name:
            return full_match
        svg = get_icon_fn(icon_name, size=16, css_class="lumina-sidebar-icon")
        if not svg:
            return full_match
        return full_match + str(svg)

    return re.sub(r'<a\b[^>]*href="([^"]*)"[^>]*>', _replace_link, toctree_html)


# Matches an opening <li ...> followed by a direct child <a href="...">.
# Splitting the match into three groups lets us rewrite just the <li> tag
# while preserving any whitespace that Sphinx emits between it and the <a>.
_LI_WITH_ANCHOR_RE = re.compile(
    r'(?P<open><li(?P<attrs>[^>]*)>)(?P<gap>\s*)(?P<anchor><a\b[^>]*href="(?P<href>[^"]*)"[^>]*>)',
    re.IGNORECASE,
)


def _mark_collapsed_entries(toctree_html, collapsed_docs, pagename):
    """Tag toctree ``<li>`` elements whose page opts into starting collapsed.

    For any ``<li>`` whose first child ``<a>`` resolves to a pagename in
    ``collapsed_docs``, append ``data-nav-collapsed="true"`` to the ``<li>``
    attributes.  The client-side ``sidebarNav`` Alpine component reads this
    attribute on init and starts that branch in the collapsed state
    (unless it contains the current page, in which case it is auto-expanded).
    """
    if not collapsed_docs:
        return toctree_html

    def _replace(match):
        attrs = match.group("attrs")
        if "data-nav-collapsed" in attrs:
            return match.group(0)
        target = _resolve_href_to_pagename(match.group("href"), pagename)
        if not any(k in collapsed_docs for k in _with_basename_fallback(target)):
            return match.group(0)
        new_open = f'<li{attrs} data-nav-collapsed="true">'
        return new_open + match.group("gap") + match.group("anchor")

    return _LI_WITH_ANCHOR_RE.sub(_replace, toctree_html)


def _build_collapsed_docs(app):
    """Build the set of pagenames with ``nav_collapsed`` metadata set."""
    collapsed = set()
    for pagename, meta in app.env.metadata.items():
        raw = meta.get("nav_collapsed", "")
        if str(raw).strip().lower() in ("true", "1", "yes"):
            collapsed.add(pagename)
    return collapsed


def _section_paths(section):
    """Return the list of path prefixes for a section.

    Supports both ``"path": "guides"`` (single) and
    ``"paths": ["getting-started", "guides"]`` (multiple).
    """
    paths = list(section.get("paths") or [])
    single = section.get("path", "")
    if single and single not in paths:
        paths.insert(0, single)
    return paths


def _paths_to_docnames(path_list):
    """Expand path prefixes to the set of docnames they match in root toctree."""
    result = set()
    for p in path_list:
        result.add(p)
        result.add(p + "/index")
    return result


def _detect_section(pagename, sections):
    """Return the section config dict matching pagename by path prefix.

    If a section has ``"default": True``, it matches any page not claimed
    by another section's explicit paths.
    """
    default = None
    for section in sections:
        if section.get("default"):
            default = section
            continue
        for prefix in _section_paths(section):
            if (
                pagename == prefix
                or pagename == prefix + "/index"
                or pagename.startswith(prefix + "/")
            ):
                return section
    return default


def _prepare_sections(app, sections):
    """Pre-compute cached data for doc sections (called once per build).

    Enriches each section dict with ``_link`` (nav target) and stores
    the root doctree and claimed-paths set on the app for reuse across pages.
    """
    root_doc = app.env.config.root_doc

    # Compute link targets and the set of all explicitly claimed docnames
    claimed = set()
    for s in sections:
        # Explicit "link" takes priority, then first path, then root_doc
        if "link" in s:
            s["_link"] = s["link"]
        else:
            paths = _section_paths(s)
            if paths:
                s["_link"] = paths[0] + "/index"
            else:
                s["_link"] = root_doc
        if not s.get("default"):
            claimed |= _paths_to_docnames(_section_paths(s))

    # Cache the root doctree (constant during write phase)
    try:
        app._lumina_root_doctree = app.env.get_doctree(root_doc)
    except FileNotFoundError:
        app._lumina_root_doctree = None

    app._lumina_claimed_paths = claimed


def _section_toctree(app, pagename, section, maxdepth, collapse):
    """Render toctree HTML for a section's subtree(s).

    Resolves the **root** document's toctree but filters its entries to only
    include those matching the section's path prefixes.  For a default section,
    includes all entries not claimed by any other section.

    Note: ``_resolve_toctree`` is a private API but has been stable across
    Sphinx 7.x and 8.x.  This project requires ``sphinx>=8.0``.
    """
    root_doctree = app._lumina_root_doctree
    if root_doctree is None:
        return ""

    is_default = section.get("default", False)
    if is_default:
        claimed = app._lumina_claimed_paths
    else:
        claimed = _paths_to_docnames(_section_paths(section))

    builder = app.builder
    fragments = []
    for node in root_doctree.findall(addnodes.toctree):
        if is_default:
            matching = [e for e in node["entries"] if e[1] not in claimed]
        else:
            matching = [e for e in node["entries"] if e[1] in claimed]
        if not matching:
            continue

        filtered = copy.deepcopy(node)
        filtered["entries"] = matching
        matched_docs = {dn for _, dn in matching}
        filtered["includefiles"] = [
            f for f in node["includefiles"] if f in matched_docs
        ]

        resolved = _resolve_toctree(
            app.env,
            pagename,
            builder,
            filtered,
            prune=True,
            maxdepth=maxdepth,
            titles_only=True,
            collapse=collapse,
            includehidden=True,
            tags=builder.tags,
        )
        if resolved:
            fragments.append(builder.render_partial(resolved)["fragment"])

    return "\n".join(fragments)


_SPHINX_SITEMAP_DEFAULT_URL_SCHEME = "{lang}{version}{link}"


def _apply_sitemap_defaults(app, config):
    """Set sphinx-sitemap defaults the user hasn't overridden.

    Runs at ``config-inited``, before the builder is created — so we read
    theme options from ``config.html_theme_options`` rather than
    ``app.builder.theme_options``. When SEO is disabled, returns early
    without applying defaults; sphinx-sitemap's handlers are still wired,
    but ``_suppress_sitemap_when_seo_disabled`` deletes the generated file.
    """
    theme_options = config.html_theme_options or {}
    if not _seo.should_emit_seo(theme_options):
        return

    # When sphinx-sitemap is loaded, it registers ``sitemap_url_scheme``
    # with default ``{lang}{version}{link}``. Override that default to
    # ``{link}`` so single-language docs without a configured language
    # produce ``<baseurl>/index.html`` rather than ``<baseurl>/en/index.html``.
    current_scheme = getattr(config, "sitemap_url_scheme", None)
    if current_scheme in (None, "", _SPHINX_SITEMAP_DEFAULT_URL_SCHEME):
        config.sitemap_url_scheme = "{link}"
    if not getattr(config, "sitemap_filename", None):
        config.sitemap_filename = "sitemap.xml"
    # Emit <lastmod> per URL when sphinx-last-updated-by-git is loaded
    # (it populates env.git_last_updated, which sphinx-sitemap reads).
    # Respect an explicit user choice (in conf.py or via -D).
    user_set_lastmod = "sitemap_show_lastmod" in getattr(
        config, "_raw_config", {}
    ) or "sitemap_show_lastmod" in getattr(config, "_overrides", {})
    if not user_set_lastmod:
        config.sitemap_show_lastmod = "sphinx_last_updated_by_git" in app.extensions


def _suppress_sitemap_when_seo_disabled(app, exception):
    """Delete sitemap.xml after build if SEO is disabled.

    Only deletes when Lumina was the one to auto-load ``sphinx-sitemap``.
    If the user explicitly added it to ``extensions`` in ``conf.py``, we
    leave the generated sitemap alone — ``disable_seo`` is meant to opt
    out of Lumina's emissions, not override the user's own extension config.
    """
    if exception is not None:
        return
    if app.builder.format != "html":
        return
    if _seo.should_emit_seo(app.builder.theme_options):
        return
    if not getattr(app, "_lumina_sitemap_auto_loaded", False):
        return
    sitemap_name = (
        getattr(app.config, "sitemap_filename", "sitemap.xml") or "sitemap.xml"
    )
    sitemap_path = Path(app.outdir) / sitemap_name
    if sitemap_path.exists():
        try:
            sitemap_path.unlink()
        except OSError:
            pass


def _check_baseurl(app):
    """Warn once at build start if html_baseurl is missing or non-absolute.

    Many SEO features (canonical URLs, sitemap entries, robots.txt sitemap
    reference) need an absolute site URL to work. We warn rather than error
    so local-only / preview builds aren't broken.
    """
    if not _seo.should_emit_seo(app.builder.theme_options):
        return
    baseurl = (app.config.html_baseurl or "").strip()
    if not baseurl:
        logger.warning(
            "html_baseurl is not set — canonical URLs, sitemap.xml entries, "
            "and the robots.txt sitemap reference will be skipped. "
            "Set html_baseurl in conf.py to enable them. "
            "[lumina.seo]"
        )


def _iso_last_updated(app, pagename: str) -> str | None:
    """Return ISO-8601 last-updated date for a page, or None if unavailable.

    Reads from ``sphinx_last_updated_by_git`` when active. The extension
    populates ``app.env.git_last_updated`` as a dict keyed by docname; the
    value is a 2-tuple ``(timestamp, show_sourcelink)`` after env-updated
    has run, where ``timestamp`` is a Unix-timestamp string from git (or
    ``None`` when git data is unavailable). Falls back to None so the
    JSON-LD field is omitted rather than emitting a non-ISO string.
    """
    git_last_updated = getattr(app.env, "git_last_updated", None)
    if not git_last_updated:
        return None
    data = git_last_updated.get(pagename)
    if data is None:
        return None
    # The extension stores a 2-tuple `(timestamp, ...)` after env-updated;
    # before then the value is None (handled above). Defensive unpacking
    # in case the schema ever changes.
    timestamp = data[0] if isinstance(data, tuple) and data else None
    if timestamp is None:
        return None
    try:
        from datetime import datetime, timezone

        dt = datetime.fromtimestamp(int(timestamp), timezone.utc)
        return dt.date().isoformat()  # YYYY-MM-DD
    except (TypeError, ValueError):
        return None


def _add_context(app, pagename, templatename, context, doctree):
    context["lumina_version"] = __version__
    context["has_llms_txt"] = "sphinx_llm.txt" in app.extensions
    wide_val = str(app.builder.theme_options.get("wide_layout", "false")).lower()
    if wide_val in ("toggle", "always"):
        context["lumina_wide_layout"] = True
        context["lumina_wide_layout_mode"] = wide_val
    else:
        context["lumina_wide_layout"] = False
        context["lumina_wide_layout_mode"] = "off"

    # Separate light/dark logos
    light_logo = app.builder.theme_options.get("light_logo", "")
    dark_logo = app.builder.theme_options.get("dark_logo", "")

    if light_logo:
        context["lumina_light_logo"] = context["pathto"]("_static/" + light_logo, 1)
    if dark_logo:
        context["lumina_dark_logo"] = context["pathto"]("_static/" + dark_logo, 1)

    # Derive a favicon from logo_icon (Lucide) when set, so the browser tab
    # matches the header logo. Sphinx's html_favicon still wins via the
    # ``favicon`` context variable check in layout.html.
    logo_icon = app.builder.theme_options.get("logo_icon", "")
    if logo_icon:
        from ._icon_utils import get_icon_data_href

        accent = app.builder.theme_options.get("accent_color", "#10b981")
        favicon_href = get_icon_data_href(logo_icon, stroke=accent)
        if favicon_href:
            context["lumina_logo_icon_favicon"] = favicon_href

    # Announcement banner
    announcement = app.builder.theme_options.get("announcement", "")
    if announcement:
        context["announcement_content"] = announcement
        context["announcement_id"] = hashlib.md5(
            announcement.encode(), usedforsecurity=False
        ).hexdigest()[:8]

    # Version switcher
    vs_json = app.builder.theme_options.get("version_switcher_json", "")
    vs_match = app.builder.theme_options.get("version_switcher_match", "")
    if vs_json:
        context["lumina_version_json"] = vs_json
        context["lumina_version_match"] = vs_match
        if not vs_match:
            logger.warning(
                "version_switcher_json is set but version_switcher_match is empty — "
                "the version dropdown will not highlight the current version"
            )

    # Allow pages to opt into a custom template via metadata
    meta = app.env.metadata.get(pagename, {})

    # Pass hero metadata fields to the template context
    for field in _HERO_FIELDS:
        if field in meta:
            context[field] = meta[field]

    # Reading-time estimate. Opt-in via theme option; per-page override via
    # ``reading_time`` front matter (``false`` to suppress, integer to override).
    if app.builder.theme_options.get("show_reading_time", "false") == "true":
        rt_meta = str(meta.get("reading_time", "")).strip().lower()
        if rt_meta == "false":
            pass  # explicitly suppressed for this page
        elif rt_meta.isdigit():
            context["lumina_reading_time"] = int(rt_meta)
        else:
            rt = _compute_reading_time(doctree)
            if rt is not None:
                context["lumina_reading_time"] = rt

    # Icon system: make icon renderer and sidebar filter available to templates
    from ._icon_utils import get_icon_inner, get_icon_svg

    context["lumina_icon"] = get_icon_svg
    context["lumina_icon_inner"] = get_icon_inner

    page_icons = _build_page_icons(app)
    collapsed_docs = _build_collapsed_docs(app)

    def _post_process_sidebar(html):
        html = _add_sidebar_icons(html, page_icons, pagename, get_icon_svg)
        html = _mark_collapsed_entries(html, collapsed_docs, pagename)
        return html

    context["add_sidebar_icons"] = _post_process_sidebar

    # Doc sections switcher
    sections = app.builder.theme_options.get("doc_sections", "")
    if sections:
        if not hasattr(app, "_lumina_root_doctree"):
            _prepare_sections(app, sections)
        current_section = _detect_section(pagename, sections)
        context["lumina_sections"] = sections
        context["lumina_current_section"] = current_section
        if current_section:
            maxdepth = int(app.builder.theme_options.get("nav_depth", "3"))
            section_html = _section_toctree(
                app, pagename, current_section, maxdepth, collapse=False
            )
            if section_html:
                context["lumina_section_toctree"] = section_html

    # Make all external scripts non-render-blocking (defer).
    # Sphinx places the {%- block scripts %} inside <head>, so without defer
    # every script blocks rendering.  We wrap the built-in js_tag() function
    # to inject defer="defer" into all external <script> tags while leaving
    # inline scripts (FOUC prevention, announcement state) synchronous.
    _original_js_tag = context["js_tag"]

    def _deferred_js_tag(js):
        tag = _original_js_tag(js)
        if "src=" in tag and "defer" not in tag and "async" not in tag:
            tag = tag.replace("<script ", '<script defer="defer" ', 1)
        return tag

    context["js_tag"] = _deferred_js_tag

    # SEO metadata
    if _seo.should_emit_seo(app.builder.theme_options):
        page_meta = app.env.metadata.get(pagename, {})
        if _seo.is_noindex(page_meta):
            context["lumina_seo_noindex"] = True
        description = _seo.extract_description(
            doctree=doctree,
            meta=page_meta,
            short_title=context.get("shorttitle", "") or app.config.project,
        )
        if description:
            context["lumina_seo_description"] = description
        context["lumina_seo_theme_color"] = app.builder.theme_options.get(
            "accent_color", "#10b981"
        )
        # `pageurl` is set by Sphinx's standard html-page-context handler when
        # html_baseurl is configured. Sphinx's basic/layout.html emits its own
        # `<link rel="canonical">` from this — we leave that emission in place
        # (no duplicate) and reuse the same value for og:url etc. in later tasks.
        page_url = context.get("pageurl", "")
        context["lumina_seo_page_url"] = page_url

        # og:type is "website" for the root document, "article" elsewhere.
        # Front matter `og_type` overrides.
        og_type = str(page_meta.get("og_type", "")).strip()
        if not og_type:
            og_type = "website" if pagename == app.config.root_doc else "article"
        context["lumina_seo_og_type"] = og_type
        og_title = _seo.plain_title(context.get("title", "")) or app.config.project
        context["lumina_seo_og_title"] = og_title
        context["lumina_seo_og_site_name"] = app.config.project
        context["lumina_seo_og_locale"] = _seo.og_locale_for_language(
            app.config.language
        )
        keywords = (
            str(page_meta.get("keywords", "")).strip()
            or str(app.builder.theme_options.get("seo_keywords", "")).strip()
        )
        if keywords:
            context["lumina_seo_keywords"] = keywords
        og_image, og_image_alt = _seo.resolve_og_image(
            page_meta=page_meta,
            theme_options=app.builder.theme_options,
            html_logo=app.config.html_logo,
            html_baseurl=app.config.html_baseurl,
        )
        if og_image:
            context["lumina_seo_og_image"] = og_image
            if og_image_alt:
                context["lumina_seo_og_image_alt"] = og_image_alt
            og_image_w = str(
                app.builder.theme_options.get("og_image_width", "")
            ).strip()
            og_image_h = str(
                app.builder.theme_options.get("og_image_height", "")
            ).strip()
            if og_image_w:
                context["lumina_seo_og_image_width"] = og_image_w
            if og_image_h:
                context["lumina_seo_og_image_height"] = og_image_h
        publisher_logo = _seo.resolve_publisher_logo(
            theme_options=app.builder.theme_options,
            html_logo=app.config.html_logo,
            html_baseurl=app.config.html_baseurl,
        )
        context["lumina_seo_twitter_card"] = (
            "summary_large_image" if og_image else "summary"
        )
        twitter_handle = _seo.derive_twitter_handle(app.builder.theme_options)
        if twitter_handle:
            context["lumina_seo_twitter_site"] = twitter_handle
        # JSON-LD: BreadcrumbList (only on non-root pages with parents)
        parents = context.get("parents") or []
        plain_page_title = _seo.plain_title(context.get("title", "")) or pagename
        if pagename != app.config.root_doc:
            crumbs = _seo.build_breadcrumb_jsonld(
                parents=parents,
                title=plain_page_title,
                page_url=page_url,
                site_url=app.config.html_baseurl or "",
                site_name=app.config.project,
            )
            if crumbs:
                context["lumina_seo_breadcrumb_jsonld"] = crumbs
        # JSON-LD: TechArticle (content pages only)
        if pagename != app.config.root_doc:
            # Sphinx defaults `author` to the literal string "Author name not set"
            # when the user has not configured one — treat that as unset.
            author = app.config.author or None
            if author == "Author name not set":
                author = None
            article_json = _seo.build_article_jsonld(
                headline=plain_page_title,
                description=description,
                page_url=page_url,
                site_url=app.config.html_baseurl or "",
                site_name=app.config.project,
                author=author,
                image_url=context.get("lumina_seo_og_image"),
                publisher_logo_url=publisher_logo,
                date_published=_iso_last_updated(app, pagename),
                date_modified=_iso_last_updated(app, pagename),
            )
            context["lumina_seo_article_jsonld"] = article_json
        # JSON-LD: WebSite + SearchAction (root page only, requires baseurl)
        if pagename == app.config.root_doc and app.config.html_baseurl:
            site_json = _seo.build_website_jsonld(
                site_url=app.config.html_baseurl,
                site_name=app.config.project,
                description=description,
            )
            if site_json:
                context["lumina_seo_website_jsonld"] = site_json
        context["lumina_seo_enabled"] = True
    else:
        # When SEO is disabled, suppress the basic theme's canonical link by
        # clearing pageurl. (Basic's canonical emission is gated on `{% if pageurl %}`.)
        context["pageurl"] = ""
        context["lumina_seo_enabled"] = False

    if "template" in meta:
        # Icon browser page: inject all icon names + SVG inner content
        if meta["template"] == "icon-browser.html":
            from ._icons import ICONS

            context["icon_entries"] = sorted(ICONS.items())
            context["icon_count"] = len(ICONS)
        return meta["template"]


def _filter_sitemap_noindex(app, exception):
    """Remove noindex pages from sitemap.xml after sphinx-sitemap writes it.

    Implemented as a post-processor because sphinx-sitemap's URL collection
    happens inside its own ``build-finished`` handler with no public hook
    for exclusion. We rewrite the file in place, stripping ``<url>`` blocks
    whose ``<loc>`` matches an excluded page.

    Reads the noindex flag straight from ``app.env.metadata`` so incremental
    builds (where some pages weren't re-rendered this run) still exclude all
    noindex pages from the sitemap.
    """
    if exception:
        return
    if app.builder.format != "html":
        return
    if not _seo.should_emit_seo(app.builder.theme_options):
        return
    excluded = {
        docname for docname, meta in app.env.metadata.items() if _seo.is_noindex(meta)
    }
    if not excluded:
        return
    sitemap_path = Path(app.outdir) / app.config.sitemap_filename
    if not sitemap_path.exists():
        return

    import xml.etree.ElementTree as ET

    ns = "http://www.sitemaps.org/schemas/sitemap/0.9"
    ET.register_namespace("", ns)
    tree = ET.parse(sitemap_path)
    root = tree.getroot()

    # The html builder always emits .html for page outputs; sphinx-sitemap
    # uses the same suffix. Anchor at the slash boundary so 'noindex.html'
    # doesn't accidentally match 'seo-noindex.html' or '.../foo-noindex.html'.
    excluded_paths = {f"/{name}.html" for name in excluded}

    for url_el in list(root.findall(f"{{{ns}}}url")):
        loc_el = url_el.find(f"{{{ns}}}loc")
        if loc_el is None or loc_el.text is None:
            continue
        if any(loc_el.text.endswith(p) for p in excluded_paths):
            root.remove(url_el)

    tree.write(sitemap_path, xml_declaration=True, encoding="utf-8")


def _write_robots_txt(app, exception):
    """Write a default robots.txt to the build output.

    Honors a user-supplied robots.txt placed via html_extra_path: by the
    time this build-finished handler runs, html_extra_path has already
    copied user files to the output dir, so we just check and skip.
    """
    if exception:
        return
    if app.builder.format != "html":
        return
    if not _seo.should_emit_seo(app.builder.theme_options):
        return

    robots_path = Path(app.outdir) / "robots.txt"
    if robots_path.exists():
        return  # User override already in place.

    lines = ["User-agent: *", "Allow: /", ""]
    baseurl = (app.config.html_baseurl or "").strip()
    if baseurl:
        sitemap_filename = getattr(app.config, "sitemap_filename", "") or "sitemap.xml"
        sitemap_url = baseurl.rstrip("/") + "/" + sitemap_filename
        lines.append(f"Sitemap: {sitemap_url}")

    robots_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def _run_pagefind(app, exception):
    """Run Pagefind to index the built HTML for search."""
    if exception:
        return
    if app.builder.format != "html":
        return
    if app.builder.theme_options.get("search_backend", "pagefind") != "pagefind":
        return

    import shutil
    import subprocess

    npx = shutil.which("npx")
    if not npx:
        logger.warning(
            "npx not found — skipping Pagefind indexing. "
            "Install Node.js or run manually: npx pagefind --site %s",
            app.outdir,
        )
        return

    logger.info("Running Pagefind indexing...")
    try:
        subprocess.run(
            [
                npx,
                "pagefind",
                "--site",
                app.outdir,
                "--output-subdir",
                "_pagefind",
                # Sphinx injects ¶ anchor links into headings — exclude them so they
                # don't corrupt page titles and result excerpts in the search index.
                "--exclude-selectors",
                "a.headerlink",
                # HTTP domain signature lines contain bare method verbs (GET, POST …)
                # which cause false positives via stemming (e.g. "Getting" → "get").
                # The endpoint descriptions (inside dd) are still fully indexed.
                "--exclude-selectors",
                "dl.http dt.sig",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        logger.info("Pagefind index created successfully")
    except subprocess.CalledProcessError as e:
        logger.warning("Pagefind indexing failed: %s", e.stderr.strip())
    except FileNotFoundError:
        logger.warning("Pagefind not found — skipping search indexing")


def setup(app):
    """Register the Lumina theme with Sphinx."""
    from ._directives import LuminaCardDirective, LuminaGridItemCardDirective

    app.add_html_theme("lumina", str(Path(__file__).parent / "theme"))
    app.add_js_file("lumina.js", loading_method="defer", priority=900)
    app.add_directive("card", LuminaCardDirective, override=True)
    app.add_directive("grid-item-card", LuminaGridItemCardDirective, override=True)
    # sphinx-sitemap auto-load. Themes load via the ``sphinx.html_themes``
    # entry point during ``builder.init_templates()`` — i.e. *after*
    # ``config-inited`` has already fired. So we call the defaults helper
    # directly with the live config and additionally connect to
    # ``config-inited`` to cover the (rarer) case where the user lists
    # the theme as a regular extension and our setup runs before it.
    # Track whether the user (vs. Lumina) put sphinx-sitemap in conf.py so
    # disable_seo only removes auto-loaded sitemaps. Use the config list
    # rather than ``app.extensions`` because the latter only reflects what
    # has been loaded *so far*.
    user_extensions = getattr(app.config, "extensions", []) or []
    app._lumina_sitemap_auto_loaded = "sphinx_sitemap" not in user_extensions
    app.setup_extension("sphinx_sitemap")
    app.connect("config-inited", _apply_sitemap_defaults)
    _apply_sitemap_defaults(app, app.config)
    app.connect("build-finished", _suppress_sitemap_when_seo_disabled)
    app.connect("builder-inited", _apply_code_style)
    app.connect("builder-inited", _check_baseurl)
    app.connect("html-page-context", _add_context)
    app.connect("build-finished", _run_pagefind)
    app.connect("build-finished", _filter_sitemap_noindex)
    app.connect("build-finished", _write_robots_txt)
    return {
        "version": __version__,
        "parallel_read_safe": True,
        "parallel_write_safe": True,
    }
