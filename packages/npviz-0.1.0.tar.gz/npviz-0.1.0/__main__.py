"""Allow `python -m npviz`."""
from .cli import main

main()
