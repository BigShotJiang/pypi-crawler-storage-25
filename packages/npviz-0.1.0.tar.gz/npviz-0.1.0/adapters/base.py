"""Abstract base class for model adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod


class AdapterBase(ABC):
    """Exposes the 5 properties that Recorder.attach() expects from a model.

    Subclass this and implement the abstract properties to make any model
    compatible with npviz's Recorder.
    """

    @property
    @abstractmethod
    def n_layers(self) -> int:
        """Number of layers in the architecture."""

    @property
    @abstractmethod
    def heads_per_layer(self) -> list[int]:
        """Number of attention heads per layer."""

    @property
    @abstractmethod
    def params_per_layer(self) -> list[int]:
        """Parameter count per layer."""

    @property
    @abstractmethod
    def total_params(self) -> int:
        """Total model parameters."""

    @property
    def connections(self) -> list[tuple[int, int]]:
        """Layer connectivity. Default: sequential."""
        return [(i, i + 1) for i in range(self.n_layers - 1)]

    def importance_scores(self) -> list[list[float]]:
        """Return per-head importance scores (layers x heads).

        Optional — subclasses may override.
        """
        raise NotImplementedError("This adapter does not compute importance scores")

    def attach_recorder(self, recorder) -> None:
        """Convenience: call recorder.attach(self)."""
        recorder.attach(self)

    def snapshot(self, recorder, step: int) -> None:
        """Convenience: log a snapshot at the given step."""
        recorder.log_snapshot(step, self)
