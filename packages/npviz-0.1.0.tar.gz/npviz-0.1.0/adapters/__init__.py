"""Model adapters for npviz — bridge real PyTorch models to the Recorder interface."""

from .base import AdapterBase

__all__ = ["AdapterBase", "auto_detect"]


def auto_detect(model) -> AdapterBase:
    """Return the best adapter for the given model.

    - HuggingFace PreTrainedModel -> TransformerAdapter
    - Any other nn.Module -> GenericAdapter
    """
    # Check for HuggingFace model first
    try:
        from transformers import PreTrainedModel

        if isinstance(model, PreTrainedModel):
            from .transformers import TransformerAdapter

            return TransformerAdapter(model)
    except ImportError:
        pass

    # Fall back to generic
    try:
        from .generic import GenericAdapter

        return GenericAdapter(model)
    except ImportError as e:
        raise ImportError(
            "PyTorch is required for model adapters. Install with: pip install npviz[adapters]"
        ) from e
