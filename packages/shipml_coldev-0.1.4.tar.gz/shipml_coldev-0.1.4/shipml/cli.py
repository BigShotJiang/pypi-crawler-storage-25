"""
ShipML CLI - Vercel para modelos de ML
=======================================
Uso:
    shipml register
    shipml login
    shipml deploy ./model.pkl --name iris-demo
    shipml list
    shipml logs iris-demo
    shipml delete iris-demo
"""

import json
from pathlib import Path
from typing import Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
from rich.progress import Progress, SpinnerColumn, TextColumn

# ─────────────────────────────────────────────
# SETUP
# ─────────────────────────────────────────────

app = typer.Typer(
    name="shipml",
    help="ShipML — despliega modelos de ML en producción con un comando.",
    add_completion=False,
    rich_markup_mode="rich",
)
console = Console()

# Config local del usuario
SHIPML_HOME = Path.home() / ".shipml"
CONFIG_FILE = SHIPML_HOME / "config.json"

# URL del backend (cambiar a producción cuando se despliegue)
BACKEND_URL = "https://shipml-backend-production.up.railway.app"


def load_config() -> dict:
    SHIPML_HOME.mkdir(exist_ok=True)
    if not CONFIG_FILE.exists():
        return {}
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def save_config(config: dict) -> None:
    SHIPML_HOME.mkdir(exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2), encoding="utf-8")


def get_api_key() -> str:
    config = load_config()
    api_key = config.get("api_key")
    if not api_key:
        console.print("[red]Error:[/red] No estás autenticado.")
        console.print("Ejecuta [bold]shipml login[/bold] para iniciar sesión.")
        raise typer.Exit(1)
    return api_key


def get_headers() -> dict:
    return {"x-api-key": get_api_key()}


# ─────────────────────────────────────────────
# AUTH COMMANDS
# ─────────────────────────────────────────────

@app.command()
def register():
    """Crear una cuenta en ShipML."""
    console.print("\n[bold cyan]ShipML — Crear cuenta[/bold cyan]")
    console.rule()

    email = Prompt.ask("Email")
    password = Prompt.ask("Password", password=True)
    password2 = Prompt.ask("Confirmar password", password=True)

    if password != password2:
        console.print("[red]Error:[/red] Las contraseñas no coinciden.")
        raise typer.Exit(1)

    try:
        r = httpx.post(
            f"{BACKEND_URL}/auth/register",
            json={"email": email, "password": password},
            timeout=10,
        )
        if r.status_code == 200:
            data = r.json()
            save_config({"email": email, "api_key": data["api_key"]})
            console.print(f"\n[green]Cuenta creada exitosamente.[/green]")
            console.print(f"  Email  : {email}")
            console.print(f"  API Key: {data['api_key'][:20]}...")
            console.print("\nYa puedes usar [bold]shipml deploy[/bold]")
        else:
            console.print(f"[red]Error:[/red] {r.json().get('detail', 'Error desconocido')}")
            raise typer.Exit(1)
    except httpx.ConnectError:
        console.print(f"[red]Error:[/red] No se puede conectar al backend en {BACKEND_URL}")
        console.print("Asegúrate de que el backend está corriendo.")
        raise typer.Exit(1)


@app.command()
def login():
    """Iniciar sesión en ShipML."""
    console.print("\n[bold cyan]ShipML — Iniciar sesión[/bold cyan]")
    console.rule()

    email = Prompt.ask("Email")
    password = Prompt.ask("Password", password=True)

    try:
        r = httpx.post(
            f"{BACKEND_URL}/auth/login",
            json={"email": email, "password": password},
            timeout=10,
        )
        if r.status_code == 200:
            data = r.json()
            save_config({"email": email, "api_key": data["api_key"]})
            console.print(f"\n[green]Sesión iniciada como {email}[/green]")
            console.print("Ya puedes usar [bold]shipml deploy[/bold]")
        else:
            console.print(f"[red]Error:[/red] {r.json().get('detail', 'Credenciales incorrectas')}")
            raise typer.Exit(1)
    except httpx.ConnectError:
        console.print(f"[red]Error:[/red] No se puede conectar al backend en {BACKEND_URL}")
        raise typer.Exit(1)


@app.command()
def whoami():
    """Muestra el usuario autenticado."""
    try:
        r = httpx.get(f"{BACKEND_URL}/auth/me", headers=get_headers(), timeout=10)
        if r.status_code == 200:
            data = r.json()
            console.print(f"\n  Email  : {data['email']}")
            console.print(f"  Plan   : {data['plan']}")
            console.print(f"  Deploys: {data['deploys_count']}")
        else:
            console.print(f"[red]Error:[/red] {r.json().get('detail')}")
    except httpx.ConnectError:
        console.print(f"[red]Error:[/red] Backend no disponible en {BACKEND_URL}")
        raise typer.Exit(1)


# ─────────────────────────────────────────────
# DEPLOY COMMANDS
# ─────────────────────────────────────────────

@app.command()
def deploy(
    model: Path = typer.Argument(..., help="Ruta al modelo .pkl"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Nombre del deploy"),
):
    """
    Despliega un modelo de ML en producción.

    Ejemplo: shipml deploy ./model.pkl --name iris-demo
    """
    if not model.exists():
        console.print(f"[red]Error:[/red] Archivo no encontrado: {model}")
        raise typer.Exit(1)
    if model.suffix not in (".pkl", ".pickle"):
        console.print(f"[red]Error:[/red] Formato no soportado: {model.suffix}")
        raise typer.Exit(1)

    app_name = (name or model.stem).lower().replace("_", "-").replace(" ", "-")

    console.print(f"\n[bold cyan]ShipML Deploy[/bold cyan] — {model.name}")
    console.rule()

    try:
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
            task = p.add_task(f"Desplegando [bold]{app_name}[/bold]...", total=None)

            with open(model, "rb") as f:
                r = httpx.post(
                    f"{BACKEND_URL}/deploy",
                    headers=get_headers(),
                    files={"model": (model.name, f, "application/octet-stream")},
                    data={"name": app_name},
                    timeout=300,  # deploy puede tardar hasta 5 minutos
                )

            p.stop()

        if r.status_code == 200:
            data = r.json()
            console.rule()
            console.print(f"\n[bold green]Deploy exitoso![/bold green]")
            console.print(f"  [bold]URL[/bold]     : {data['url']}")
            console.print(f"  [bold]Health[/bold]  : {data['endpoints']['health']}")
            console.print(f"  [bold]Predict[/bold] : POST {data['endpoints']['predict']}")
            console.print(f"  [bold]Docs[/bold]    : {data['endpoints']['docs']}")
            console.print(f"\n  Framework : {data['framework']}")
            console.print(f"  Modelo    : {data['model_type']}\n")
        else:
            console.print(f"\n[red]Error:[/red] {r.json().get('detail', 'Error desconocido')}")
            raise typer.Exit(1)

    except httpx.ConnectError:
        console.print(f"[red]Error:[/red] Backend no disponible en {BACKEND_URL}")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        console.print("[red]Error:[/red] Timeout — el deploy tardó demasiado.")
        raise typer.Exit(1)


@app.command(name="list")
def list_deploys():
    """Lista todos los modelos desplegados."""
    try:
        r = httpx.get(f"{BACKEND_URL}/deploys", headers=get_headers(), timeout=10)
        if r.status_code != 200:
            console.print(f"[red]Error:[/red] {r.json().get('detail')}")
            raise typer.Exit(1)

        deploys = r.json().get("deploys", [])

        if not deploys:
            console.print("[yellow]No hay deploys activos.[/yellow]")
            console.print("Ejecuta [bold]shipml deploy ./model.pkl[/bold] para comenzar.")
            return

        table = Table(title="ShipML — Modelos en producción", show_lines=True)
        table.add_column("Nombre", style="cyan bold")
        table.add_column("Framework", style="green")
        table.add_column("Tipo")
        table.add_column("Features", justify="right")
        table.add_column("URL", style="blue")

        for d in deploys:
            table.add_row(
                d["name"],
                d.get("framework", "—"),
                d.get("model_type", "—"),
                str(d.get("n_features", "—")),
                d.get("url", "—"),
            )

        console.print(table)

    except httpx.ConnectError:
        console.print(f"[red]Error:[/red] Backend no disponible en {BACKEND_URL}")
        raise typer.Exit(1)


@app.command()
def delete(
    name: str = typer.Argument(..., help="Nombre del deploy a eliminar"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Confirmar sin preguntar"),
):
    """Elimina un modelo desplegado."""
    if not yes:
        confirmed = typer.confirm(f"Eliminar '{name}'? Esta accion no se puede deshacer")
        if not confirmed:
            console.print("Cancelado.")
            raise typer.Exit(0)

    try:
        r = httpx.delete(
            f"{BACKEND_URL}/deploys/{name}",
            headers=get_headers(),
            timeout=10,
        )
        if r.status_code == 200:
            console.print(f"[green]✓[/green] '{name}' eliminado.")
        else:
            console.print(f"[red]Error:[/red] {r.json().get('detail')}")
            raise typer.Exit(1)

    except httpx.ConnectError:
        console.print(f"[red]Error:[/red] Backend no disponible en {BACKEND_URL}")
        raise typer.Exit(1)


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    app()