"""
ShipML Backend
==============
Servidor FastAPI que recibe modelos .pkl y los despliega en Railway.

Correr localmente:
    pip install fastapi uvicorn python-multipart pydantic
    python backend.py

Endpoints:
    POST /auth/register   - crear cuenta
    POST /auth/login      - obtener API key
    POST /deploy          - subir modelo y desplegarlo
    GET  /deploys         - listar deploys del usuario
    DELETE /deploys/{name} - eliminar deploy
"""

import hashlib
import json
import os
import pickle
import secrets
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Optional

import uvicorn
from fastapi import FastAPI, HTTPException, Header, UploadFile, File, Form, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(
    title="ShipML Backend",
    description="API para desplegar modelos de ML en producción",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────
# BASE DE DATOS (JSON simple para el PoC)
# ─────────────────────────────────────────────

DATA_DIR = Path(".shipml_data")
USERS_FILE = DATA_DIR / "users.json"
DEPLOYS_FILE = DATA_DIR / "deploys.json"

RAILWAY_CMD = (
    shutil.which("railway")
    or shutil.which("railway.cmd")
    or str(Path.home() / "AppData/Roaming/npm/railway.cmd")
)


def load_json(path: Path) -> dict:
    DATA_DIR.mkdir(exist_ok=True)
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: dict) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ─────────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str

class LoginResponse(BaseModel):
    api_key: str
    email: str


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def get_current_user(x_api_key: str = Header(..., description="API key de ShipML")) -> dict:
    users = load_json(USERS_FILE)
    for email, user in users.items():
        if user.get("api_key") == x_api_key:
            return user
    raise HTTPException(status_code=401, detail="API key inválida")


@app.post("/auth/register", tags=["auth"])
def register(req: RegisterRequest):
    """Crear cuenta en ShipML."""
    users = load_json(USERS_FILE)

    if req.email in users:
        raise HTTPException(status_code=400, detail="Email ya registrado")

    api_key = f"shipml-{secrets.token_urlsafe(32)}"
    users[req.email] = {
        "email": req.email,
        "password": hash_password(req.password),
        "api_key": api_key,
        "created_at": datetime.utcnow().isoformat(),
        "plan": "free",
        "deploys_count": 0,
    }
    save_json(USERS_FILE, users)

    return {
        "message": "Cuenta creada exitosamente",
        "api_key": api_key,
        "email": req.email,
    }


@app.post("/auth/login", response_model=LoginResponse, tags=["auth"])
def login(req: LoginRequest):
    """Iniciar sesión y obtener API key."""
    users = load_json(USERS_FILE)

    user = users.get(req.email)
    if not user or user["password"] != hash_password(req.password):
        raise HTTPException(status_code=401, detail="Email o contraseña incorrectos")

    return LoginResponse(api_key=user["api_key"], email=req.email)


@app.get("/auth/me", tags=["auth"])
def me(current_user: dict = Depends(get_current_user)):
    """Info del usuario autenticado."""
    return {
        "email": current_user["email"],
        "plan": current_user.get("plan", "free"),
        "deploys_count": current_user.get("deploys_count", 0),
    }


# ─────────────────────────────────────────────
# CORE: DETECCIÓN Y GENERACIÓN
# ─────────────────────────────────────────────

def _detect_model(model_path: Path) -> dict:
    with open(model_path, "rb") as f:
        model = pickle.load(f)

    module = type(model).__module__
    if module.startswith("sklearn"):
        framework = "scikit-learn"
    elif module.startswith("xgboost"):
        framework = "xgboost"
    elif module.startswith("lightgbm"):
        framework = "lightgbm"
    else:
        framework = f"unknown ({module})"

    n_features = None
    for attr in ("n_features_in_", "n_features_", "coef_"):
        if hasattr(model, attr):
            val = getattr(model, attr)
            n_features = val.shape[-1] if attr == "coef_" else int(val)
            break

    return {
        "framework": framework,
        "model_type": type(model).__name__,
        "n_features": n_features,
        "has_proba": hasattr(model, "predict_proba"),
    }


def _generate_server(meta: dict, output_dir: Path) -> None:
    n_features = meta["n_features"]
    has_proba = meta["has_proba"]
    model_type = meta["model_type"]

    if n_features:
        fields = "\n".join(
            f'    x{i}: float = Field(..., description="Feature {i}")'
            for i in range(n_features)
        )
        input_body = f"\nclass PredictInput(BaseModel):\n{fields}\n\n    def to_list(self):\n        return [{', '.join(f'self.x{i}' for i in range(n_features))}]\n"
        input_param = "body: PredictInput"
        features_expr = "[body.to_list()]"
    else:
        input_body = "\nclass PredictInput(BaseModel):\n    features: list[float] = Field(...)\n"
        input_param = "body: PredictInput"
        features_expr = "[body.features]"

    proba_endpoint = ""
    if has_proba:
        proba_endpoint = f"\n@app.post('/predict/proba')\ndef predict_proba({input_param}):\n    return {{\"probabilities\": MODEL.predict_proba({features_expr}).tolist()}}\n"

    server_code = f'''"""Auto-generado por ShipML - {model_type}"""
import pickle, os, time
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

app = FastAPI(title="ShipML - {model_type}", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

with open("model.pkl", "rb") as f:
    MODEL = pickle.load(f)

START_TIME = time.time()
{input_body}
@app.get("/health")
def health():
    return {{"status": "ok", "model": "{model_type}", "uptime_seconds": round(time.time() - START_TIME, 2)}}

@app.post("/predict")
def predict({input_param}):
    try:
        return {{"prediction": MODEL.predict({features_expr}).tolist()}}
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
{proba_endpoint}
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
'''
    (output_dir / "server.py").write_text(server_code, encoding="utf-8")


def _generate_dockerfile(output_dir: Path) -> None:
    (output_dir / "Dockerfile").write_text(
        "FROM python:3.11-slim\nWORKDIR /app\nENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1\n"
        "COPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\n"
        "COPY model.pkl .\nCOPY server.py .\n"
        "CMD uvicorn server:app --host 0.0.0.0 --port $PORT\n",
        encoding="utf-8",
    )


def _generate_requirements(output_dir: Path) -> None:
    (output_dir / "requirements.txt").write_text(
        "fastapi==0.111.0\nuvicorn[standard]==0.29.0\nscikit-learn==1.4.2\nnumpy==1.26.4\npydantic==2.7.1\n",
        encoding="utf-8",
    )


def _generate_railway_config(output_dir: Path) -> None:
    config = {
        "$schema": "https://railway.app/railway.schema.json",
        "build": {"builder": "DOCKERFILE", "dockerfilePath": "Dockerfile"},
        "deploy": {"restartPolicyType": "ON_FAILURE", "restartPolicyMaxRetries": 3},
    }
    (output_dir / "railway.json").write_text(json.dumps(config, indent=2), encoding="utf-8")


def _build_docker(app_name: str, output_dir: Path) -> None:
    result = subprocess.run(
        ["docker", "build", "-t", f"shipml-{app_name}:latest", "."],
        cwd=output_dir,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if result.returncode != 0:
        raise RuntimeError(f"Docker build falló: {result.stderr[-500:]}")


def _deploy_railway(app_name: str, output_dir: Path) -> str:
    subprocess.run(
        [RAILWAY_CMD, "init", "--name", app_name],
        cwd=output_dir,
        text=True,
    )
    result = subprocess.run(
        [RAILWAY_CMD, "up", "--detach"],
        cwd=output_dir,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError("Railway deploy falló")

    subprocess.run([RAILWAY_CMD, "domain"], cwd=output_dir, capture_output=True, text=True)
    url_result = subprocess.run(
        [RAILWAY_CMD, "domain"],
        cwd=output_dir,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    url = url_result.stdout.strip().splitlines()[-1] if url_result.stdout.strip() else ""
    if not url.startswith("http"):
        url = f"https://{url}" if url else f"https://{app_name}.up.railway.app"
    return url


# ─────────────────────────────────────────────
# DEPLOY ENDPOINT
# ─────────────────────────────────────────────

@app.post("/deploy", tags=["deploy"])
async def deploy(
    model: UploadFile = File(..., description="Archivo .pkl del modelo"),
    name: str = Form(..., description="Nombre del deploy"),
    current_user: dict = Depends(get_current_user),
):
    """
    Recibe un modelo .pkl, lo despliega en Railway y devuelve la URL.
    """
    # Validar formato
    if not model.filename.endswith((".pkl", ".pickle")):
        raise HTTPException(status_code=400, detail="Solo se aceptan archivos .pkl")

    # Validar plan free (max 1 deploy)
    deploys = load_json(DEPLOYS_FILE)
    user_deploys = {k: v for k, v in deploys.items() if v.get("email") == current_user["email"]}
    if current_user.get("plan", "free") == "free" and len(user_deploys) >= 1:
        raise HTTPException(
            status_code=403,
            detail="Plan free permite 1 deploy activo. Elimina el actual o actualiza a Pro."
        )

    app_name = name.lower().replace("_", "-").replace(" ", "-")
    if app_name in deploys:
        raise HTTPException(status_code=400, detail=f"Ya existe un deploy con el nombre '{app_name}'")

    build_dir = Path(tempfile.mkdtemp(prefix="shipml_build_"))

    try:
        # Guardar modelo recibido
        model_path = build_dir / "model.pkl"
        content = await model.read()
        model_path.write_bytes(content)

        # Detectar framework
        meta = _detect_model(model_path)

        # Generar archivos
        _generate_server(meta, build_dir)
        _generate_requirements(build_dir)
        _generate_dockerfile(build_dir)
        _generate_railway_config(build_dir)

        # Docker + Railway
        _build_docker(app_name, build_dir)
        url = _deploy_railway(app_name, build_dir)

        # Registrar deploy
        deploys[app_name] = {
            "name": app_name,
            "email": current_user["email"],
            "url": url,
            "framework": meta["framework"],
            "model_type": meta["model_type"],
            "n_features": meta["n_features"],
            "created_at": datetime.utcnow().isoformat(),
        }
        save_json(DEPLOYS_FILE, deploys)

        # Actualizar contador del usuario
        users = load_json(USERS_FILE)
        users[current_user["email"]]["deploys_count"] = users[current_user["email"]].get("deploys_count", 0) + 1
        save_json(USERS_FILE, users)

        return {
            "status": "ok",
            "name": app_name,
            "url": url,
            "framework": meta["framework"],
            "model_type": meta["model_type"],
            "endpoints": {
                "health": f"{url}/health",
                "predict": f"{url}/predict",
                "docs": f"{url}/docs",
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        shutil.rmtree(build_dir, ignore_errors=True)


# ─────────────────────────────────────────────
# DEPLOYS ENDPOINTS
# ─────────────────────────────────────────────

@app.get("/deploys", tags=["deploy"])
def list_deploys(current_user: dict = Depends(get_current_user)):
    """Lista todos los deploys del usuario."""
    deploys = load_json(DEPLOYS_FILE)
    user_deploys = {k: v for k, v in deploys.items() if v.get("email") == current_user["email"]}
    return {"deploys": list(user_deploys.values())}


@app.delete("/deploys/{name}", tags=["deploy"])
def delete_deploy(name: str, current_user: dict = Depends(get_current_user)):
    """Elimina un deploy."""
    deploys = load_json(DEPLOYS_FILE)

    if name not in deploys:
        raise HTTPException(status_code=404, detail=f"Deploy '{name}' no encontrado")
    if deploys[name].get("email") != current_user["email"]:
        raise HTTPException(status_code=403, detail="No tienes permiso para eliminar este deploy")

    del deploys[name]
    save_json(DEPLOYS_FILE, deploys)
    return {"status": "ok", "message": f"Deploy '{name}' eliminado"}


# ─────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────

@app.get("/health", tags=["system"])
def health():
    return {"status": "ok", "version": "0.1.0"}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    print(f"\nShipML Backend corriendo en http://localhost:{port}")
    print(f"Docs: http://localhost:{port}/docs\n")
    uvicorn.run("backend:app", host="0.0.0.0", port=port, reload=True)
