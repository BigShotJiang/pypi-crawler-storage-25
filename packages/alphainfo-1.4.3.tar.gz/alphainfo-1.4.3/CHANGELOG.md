# Changelog

All notable changes to the alphainfo Python SDK.

## [1.4.3] - 2026-04-17

### Fixed
- Guide .md files now ship inside the wheel at `alphainfo/guides/` (were only in sdist).
  Users can find them at `site-packages/alphainfo/guides/` after `pip install`.
- README guide links replaced with `client.guide()` usage example — no more 404s
  from private GitHub repo URLs.

## [1.4.2] - 2026-04-17

### Added
- **`guide()` method** on both `AlphaInfo` and `AsyncAlphaInfo` — fetches the
  universal encoding guide from `/v1/guide` (no auth required). Returns a dict
  with all sections: endpoints, common_mistakes, performance_tips, debugging_tips,
  encoding_patterns, fingerprint_patterns, and more. Useful for programmatic
  discoverability and AI agent introspection.

## [1.4.1] - 2026-04-17

### Fixed
- Guide links in PyPI README now point to absolute GitHub URLs (were broken relative links).
- COMMON_MISTAKES.md, PERFORMANCE_GUIDE.md, DEBUGGING_GUIDE.md included in source distribution via MANIFEST.in.
- CHANGELOG.md also included in source distribution.

## [1.4.0] - 2026-04-17

### Added
- **HTTP/2 support** — auto-detected when `h2` package is installed.
  Install with `pip install alphainfo[http2]`. Connection multiplexing and header
  compression for better throughput, especially with `AsyncAlphaInfo`.
- **Configurable retry delays** — new constructor params `retry_base_delay` (default 1.0s)
  and `retry_max_delay` (default 32.0s) for fine-tuning exponential backoff behavior.
- **`http2` constructor param** — explicitly enable/disable HTTP/2 (`True`/`False`)
  or auto-detect (`None`, default).
- **COMMON_MISTAKES.md** — guide covering 10 common pitfalls (short signals, wrong
  sampling_rate, missing close, loop vs batch, etc.).
- **PERFORMANCE_GUIDE.md** — endpoint selection decision tree, latency expectations,
  async concurrency patterns, retry tuning, windowing strategies.
- **DEBUGGING_GUIDE.md** — step-by-step troubleshooting for every error type,
  verbose logging setup, raw response inspection.

### Changed
- Internal refactor: validation and payload construction extracted into shared
  module-level functions (`_build_analyze_payload`, `_build_batch_payload`,
  `_build_matrix_payload`, `_build_vector_payload`). Response parsing also
  consolidated (`_parse_matrix`, `_parse_health`, `_parse_plans`, `_parse_audit_list`).
  This eliminates ~300 lines of duplicated code between `AlphaInfo` and `AsyncAlphaInfo`.
- README updated with new config params and links to the 3 new guides.

### Note
- Fully backwards compatible. All 47 SDK tests passing.
- No changes to the frozen API (core/metrics/api/config untouched).

## [1.3.0] - 2026-04-10

### Added
- **`analyze_batch(baselines=...)`** — per-signal baselines for batch analysis.
  Each baseline is compared against its corresponding signal. Use `None` for
  signals that don't need a baseline. 10x speedup for pairwise workflows.
- **`analyze_matrix(signals)`** — pairwise structural similarity matrix.
  Returns NxN matrix of structural_scores. Consumes N*(N-1)/2 analyses.
  `MatrixResult` includes helper methods: `score(i,j)`, `most_similar(i)`, `most_different(i)`.
- **`MatrixResult`** model with `matrix`, `labels`, `n_signals`, `n_pairs`, `analyses_consumed`.
- **`structural_perception.py`** example — LLM tool_use wrapper with `perceive()`,
  `diagnose()`, and `compare_multi()`. Demonstrates "LLM reasons, alphainfo perceives" pattern.

## [1.2.0] - 2026-04-10

### Breaking Change
- **`SemanticResult.trend`**: value `"degrading"` renamed to `"diverging"`
  - "degrading" implied a value judgment (something getting worse)
  - "diverging" is mathematically neutral — structure diverged from baseline
  - The API perceives structural change, it does not judge whether the change is good or bad
  - **Migration**: replace `trend == "degrading"` with `trend == "diverging"` in your code

### Added
- `/v1/guide` endpoint — universal encoding guide with 5 patterns and 3 usage modes
- Updated positioning language across docs

## [1.1.4] - 2026-04-09

### Added
- `BatchResult` is now **iterable**: `for r in batch_result` yields each `BatchItemResult`
- `BatchResult` supports `len(batch)` and `batch[i]` indexing
- Migration note: `for r in client.analyze_batch(...)` now works directly

### Clarification
- `composite` was never a public API field. It is an internal engine function.
  Accessing `result.composite` raises `AttributeError`. Use `getattr(result, "composite", None)` if needed.

## [1.1.3] - 2026-04-09

### Fixed
- **P2 Bug**: `AuditReplay.sampling_rate` now correctly reads from `parameters.sampling_rate` (was returning 0.0)
- **P2 Bug**: `PlanInfo.monthly_limit = -1` for Enterprise plans now documented as "unlimited"

### Added
- `PlanInfo.is_unlimited` property — returns `True` when `monthly_limit == -1` (Enterprise plans)
- `SemanticResult.trend` docs: valid values `"stable"`, `"monitoring"`, `"diverging"`
- `SemanticResult.recommended_action` docs: valid values `"log_only"`, `"monitor"`, `"human_review"`, `"immediate_human_review"`
- Contract tests for `AuditReplay.sampling_rate` fallback and `PlanInfo.is_unlimited`
- `/v1/help` now documents semantic_fields (trend values, recommended_action values) and plan tiers

## [1.1.1] - 2026-04-09

### Added
- `SemanticResult.severity` — granular severity label: `"none"`, `"low"`, `"moderate"`, `"high"`, `"critical"`
- `SemanticResult.severity_score` — severity score 0-100 (formula: `(1 - structural_score) * 100`)
- `SemanticResult.summary` — human-readable summary text (e.g. "Structural divergence detected (severity: high)")
- `SemanticResult.trend` — trend direction: `"stable"`, `"diverging"`, `"monitoring"`
- `AnalysisResult.warning` — warning message for short signals or limited engine confidence
- 8 SDK-to-API contract tests ensuring every API field maps to an SDK attribute

### Fixed
- `SemanticResult.alert_level` default corrected from `"none"` to `"normal"` (matching actual API values)
- `alert_level` documentation corrected: valid values are `"normal"`, `"attention"`, `"alert"`, `"critical"`

## [1.1.0] - 2026-04-09

### Added
- `VectorResult.confidence_band` — aggregate confidence band for vector analysis
- `VectorResult.warning` — warning for channels with insufficient samples
- `analyze_vector(baselines=...)` — per-channel baseline support
- Baseline validation (key matching, proportion limits)

### Fixed
- `VectorResult.change_score` now accessible (was missing from parser)

## [1.0.0] - 2026-04-04

### Initial release
- `AlphaInfo` and `AsyncAlphaInfo` clients
- `analyze()`, `analyze_batch()`, `analyze_vector()` methods
- `audit_list()`, `audit_replay()` for audit trail
- `health()` endpoint
- Full type annotations with `py.typed`
- Automatic retry with exponential backoff
- Rate limit tracking via response headers
- Exception hierarchy: `AuthError`, `ValidationError`, `RateLimitError`, `NotFoundError`, `APIError`
