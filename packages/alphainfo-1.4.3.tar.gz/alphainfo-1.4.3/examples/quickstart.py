#!/usr/bin/env python3
"""
alphainfo SDK Quick Start Example

Demonstrates basic usage of the alphainfo Python SDK for structural analysis.

Usage:
    export ALPHAINFO_API_KEY="ai_your_key_here"
    python examples/quickstart.py
"""

import os
from alphainfo import AlphaInfo, HealthStatus
from alphainfo.exceptions import AuthError, ValidationError


def main():
    """Run quick start examples."""

    # Get API key from environment
    api_key = os.getenv("ALPHAINFO_API_KEY")
    if not api_key:
        print("Error: ALPHAINFO_API_KEY environment variable not set")
        print("Usage: export ALPHAINFO_API_KEY='ai_xxx' && python examples/quickstart.py")
        return

    print("=" * 60)
    print("alphainfo Python SDK - Quick Start")
    print("=" * 60)

    # Initialize client with context manager (auto-closes)
    with AlphaInfo(api_key=api_key) as client:

        # 1. Health Check
        print("\n1. Health Check")
        print("-" * 40)
        try:
            health = client.health()
            print(f"Status: {health.status}")
            print(f"Version: {health.version}")
            print(f"Message: {health.message}")
        except Exception as e:
            print(f"Error: {e}")
            return

        # 2. Analyze Signal
        print("\n2. Signal Analysis")
        print("-" * 40)
        try:
            # Create a simple test signal
            signal = [1.0, 2.0, 3.0, 2.5, 2.0, 1.5, 1.0] * 20  # Repeat for more samples

            result = client.analyze(
                signal=signal,
                sampling_rate=250.0,
                domain="generic",
                metadata={"source": "example", "unit": "V"},
            )

            print(f"Structural Score: {result.structural_score:.3f}")
            print(f"Change Detected: {result.change_detected}")
            print(f"Change Score: {result.change_score:.3f}")
            print(f"Confidence Band: {result.confidence_band}")
            print(f"Engine Version: {result.engine_version}")
            print(f"Analysis ID: {result.analysis_id}")

            # Show rate limit info
            if client.rate_limit_info:
                print(f"\nRate Limit: {client.rate_limit_info.remaining}/{client.rate_limit_info.limit}")

        except ValidationError as e:
            print(f"Validation Error: {e.message}")
        except AuthError as e:
            print(f"Authentication Error: {e.message}")
        except Exception as e:
            print(f"Error: {e}")

        # 3. Billing Plans
        print("\n4. Available Plans")
        print("-" * 40)
        try:
            plans = client.plans()
            for plan in plans:
                print(f"- {plan.name}: ${plan.price_cents/100:.2f}/month")
                print(f"  Limit: {plan.monthly_limit} calls/month")
                if plan.features:
                    print(f"  Features: {', '.join(plan.features.keys())}")

        except Exception as e:
            print(f"Plans Error: {e}")

    print("\n" + "=" * 60)
    print("Done! (Client automatically closed)")
    print("=" * 60)


if __name__ == "__main__":
    main()
