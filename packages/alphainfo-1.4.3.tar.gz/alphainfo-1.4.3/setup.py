"""
Setup configuration for alphainfo Python SDK
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    with open(readme_file, "r", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name="alphainfo",
    version="1.0.0",
    description="Python SDK for alphainfo.io — Structural Regime Detection API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="alphainfo.io",
    author_email="support@alphainfo.io",
    url="https://github.com/alphainfo-io/python-sdk",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.25.0",
    ],
    extras_require={
        "http2": [
            "h2>=4.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
            "h2>=4.0",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Financial and Insurance Industry",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    keywords=[
        "alphainfo",
        "structural analysis",
        "regime detection",
        "financial analysis",
        "market analysis",
        "signal processing",
    ],
)
