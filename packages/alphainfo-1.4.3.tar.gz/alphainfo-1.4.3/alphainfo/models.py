"""
alphainfo SDK — Typed Data Models

All response objects are dataclasses with full type annotations.
This module contains ONLY public API contract types — no engine internals.
"""

from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional

# ---------------------------------------------------------------------------
# Semantic interpretation result
# ---------------------------------------------------------------------------

@dataclass
class SemanticResult:
    """Semantic interpretation of a structural analysis."""

    summary: str = ""
    """Human-readable summary of the analysis."""

    alert_level: str = "normal"
    """Alert level: 'normal', 'attention', 'alert', 'critical'."""

    recommended_action: Optional[str] = None
    """Suggested action: 'log_only', 'monitor', 'human_review', or 'immediate_human_review'."""

    trend: Optional[str] = None
    """Detected trend: 'stable', 'monitoring', or 'diverging'."""

    severity: Optional[str] = None
    """Severity label: 'none', 'low', 'moderate', 'high', 'critical'."""

    severity_score: Optional[float] = None
    """Severity score [0, 100]. Higher = more severe structural divergence."""

    details: Optional[Dict[str, Any]] = None
    """Additional semantic details."""

    def __repr__(self) -> str:
        return (
            f"SemanticResult(alert={self.alert_level!r}, "
            f"severity={self.severity!r}, "
            f"summary={self.summary[:60]!r})"
        )


# ---------------------------------------------------------------------------
# Core analysis result
# ---------------------------------------------------------------------------

@dataclass
class AnalysisResult:
    """Result from a single structural analysis."""

    structural_score: float
    """Structural preservation score [0, 1]. Higher = more preserved."""

    change_detected: bool
    """Whether a structural regime change was detected."""

    change_score: float
    """Change magnitude score [0, 1]. Higher = larger change."""

    confidence_band: str
    """Classification: 'stable', 'transition', or 'unstable'."""

    engine_version: str
    """Engine version that produced this result."""

    analysis_id: str
    """Unique UUID for audit trail and replay."""

    metrics: Optional[Dict[str, Any]] = None
    """Additional analysis metrics (when available)."""

    provenance: Optional[Dict[str, Any]] = None
    """Data provenance information."""

    semantic: Optional["SemanticResult"] = None
    """Semantic interpretation (when include_semantic=True)."""

    warning: Optional[str] = None
    """Warning about signal quality or analysis limitations."""

    def __repr__(self) -> str:
        return (
            f"AnalysisResult(score={self.structural_score:.3f}, "
            f"change={self.change_detected}, "
            f"band={self.confidence_band!r}, "
            f"id={self.analysis_id!r})"
        )


# ---------------------------------------------------------------------------
# Batch analysis result
# ---------------------------------------------------------------------------

@dataclass
class BatchItemResult:
    """Result for a single signal within a batch."""

    index: int
    """Position in the original batch (0-based)."""

    structural_score: Optional[float] = None
    change_detected: Optional[bool] = None
    change_score: Optional[float] = None
    confidence_band: Optional[str] = None
    engine_version: Optional[str] = None
    analysis_id: Optional[str] = None
    metrics: Optional[Dict[str, Any]] = None
    semantic: Optional["SemanticResult"] = None
    error: Optional[str] = None
    """Error message if this signal failed analysis."""

    @property
    def success(self) -> bool:
        """Whether this signal was analyzed successfully."""
        return self.error is None

    def __repr__(self) -> str:
        if self.error:
            return f"BatchItemResult(index={self.index}, error={self.error!r})"
        return (
            f"BatchItemResult(index={self.index}, "
            f"score={self.structural_score:.3f}, "
            f"band={self.confidence_band!r})"
        )


@dataclass
class BatchResult:
    """Result from a batch analysis request.

    Iterable: ``for r in batch_result`` yields each BatchItemResult.
    """

    results: List[BatchItemResult]
    """Per-signal results."""

    analyses_consumed: int
    """Number of analyses deducted from quota."""

    total_signals: int
    """Total number of signals submitted."""

    # -- Make BatchResult iterable so `for r in result` works --

    def __iter__(self) -> "Iterator[BatchItemResult]":
        return iter(self.results)

    def __len__(self) -> int:
        return len(self.results)

    def __getitem__(self, idx: int) -> BatchItemResult:
        return self.results[idx]

    @property
    def successful(self) -> List[BatchItemResult]:
        """Return only successfully analyzed items."""
        return [r for r in self.results if r.success]

    @property
    def failed(self) -> List[BatchItemResult]:
        """Return only failed items."""
        return [r for r in self.results if not r.success]

    def __repr__(self) -> str:
        ok = len(self.successful)
        fail = len(self.failed)
        return f"BatchResult(total={self.total_signals}, ok={ok}, failed={fail})"


# ---------------------------------------------------------------------------
# Vector (multi-channel) analysis result
# ---------------------------------------------------------------------------

@dataclass
class ChannelResult:
    """Result for a single channel within a vector analysis."""

    name: str
    """Channel name."""

    structural_score: Optional[float] = None
    change_detected: Optional[bool] = None
    change_score: Optional[float] = None
    confidence_band: Optional[str] = None
    engine_version: Optional[str] = None
    error: Optional[str] = None

    @property
    def success(self) -> bool:
        return self.error is None

    def __repr__(self) -> str:
        if self.error:
            return f"ChannelResult(name={self.name!r}, error={self.error!r})"
        return (
            f"ChannelResult(name={self.name!r}, "
            f"score={self.structural_score:.3f}, "
            f"band={self.confidence_band!r})"
        )


@dataclass
class VectorResult:
    """Result from a multi-channel vector analysis."""

    analysis_id: str
    """Unique UUID for the vector analysis."""

    structural_score: float
    """Aggregated score (worst-case across channels)."""

    change_detected: bool
    """True if ANY channel detected a change."""

    change_score: float
    """Aggregated change score (worst-case across channels) [0, 1]."""

    n_channels: int
    """Number of channels analyzed."""

    channels: Dict[str, ChannelResult]
    """Per-channel results keyed by channel name."""

    confidence_band: Optional[str] = None
    """Aggregated confidence band: stable, transition, or unstable."""

    analyses_consumed: int = 1
    """Vector analysis always consumes 1 analysis."""

    semantic: Optional["SemanticResult"] = None

    warning: Optional[str] = None
    """Warning about signal quality or analysis limitations."""

    def __repr__(self) -> str:
        return (
            f"VectorResult(channels={self.n_channels}, "
            f"score={self.structural_score:.3f}, "
            f"change={self.change_detected})"
        )


# ---------------------------------------------------------------------------
# Pairwise similarity matrix
# ---------------------------------------------------------------------------

@dataclass
class MatrixResult:
    """Result from a pairwise similarity matrix analysis."""

    matrix: List[List[float]]
    """NxN symmetric matrix of structural_scores. Diagonal = 1.0."""

    labels: List[str]
    """Signal labels (signal_0, signal_1, ...)."""

    n_signals: int
    """Number of signals compared."""

    n_pairs: int
    """Number of unique pairs computed: N*(N-1)/2."""

    analyses_consumed: int
    """Number of analyses deducted from quota."""

    errors: Optional[List[Dict[str, Any]]] = None
    """Errors for specific pairs (if any)."""

    def score(self, i: int, j: int) -> float:
        """Get the structural similarity score between signals i and j."""
        return self.matrix[i][j]

    def most_similar(self, i: int) -> int:
        """Return the index of the signal most similar to signal i."""
        scores = self.matrix[i]
        best_j = -1
        best_score = -1.0
        for j, s in enumerate(scores):
            if j != i and s > best_score:
                best_score = s
                best_j = j
        return best_j

    def most_different(self, i: int) -> int:
        """Return the index of the signal most different from signal i."""
        scores = self.matrix[i]
        worst_j = -1
        worst_score = 2.0
        for j, s in enumerate(scores):
            if j != i and s < worst_score:
                worst_score = s
                worst_j = j
        return worst_j

    def __repr__(self) -> str:
        return (
            f"MatrixResult(n={self.n_signals}, "
            f"pairs={self.n_pairs}, consumed={self.analyses_consumed})"
        )


# ---------------------------------------------------------------------------
# Audit trail models
# ---------------------------------------------------------------------------

@dataclass
class AuditReplay:
    """Full replay of a past analysis with all inputs and outputs."""

    analysis_id: str
    timestamp: str
    signal_length: int
    sampling_rate: float
    parameters: Dict[str, Any]
    """Original request parameters."""

    output: Dict[str, Any]
    """Original analysis output."""

    engine_version: str
    client_id: Optional[str] = None
    request_id: Optional[str] = None

    def __repr__(self) -> str:
        return (
            f"AuditReplay(id={self.analysis_id!r}, "
            f"length={self.signal_length}, "
            f"score={self.output.get('structural_score', '?')})"
        )


@dataclass
class AuditSummary:
    """Summary of a past analysis (from audit list)."""

    analysis_id: str
    timestamp: str
    signal_length: int
    domain: Optional[str] = None
    structural_score: Optional[float] = None
    change_detected: Optional[bool] = None

    @property
    def id(self) -> str:
        """Alias for analysis_id (consistent with REST response)."""
        return self.analysis_id

    def __repr__(self) -> str:
        return f"AuditSummary(id={self.analysis_id!r}, score={self.structural_score})"


# ---------------------------------------------------------------------------
# Health & infrastructure
# ---------------------------------------------------------------------------

@dataclass
class HealthStatus:
    """API health check response."""

    status: str
    """'healthy' or 'degraded'."""

    version: str
    """API version string."""

    message: str
    """Status message."""

    def is_healthy(self) -> bool:
        return self.status == "healthy"

    def __repr__(self) -> str:
        return f"HealthStatus(status={self.status!r}, version={self.version!r})"


@dataclass
class PlanInfo:
    """Billing plan information."""

    id: int
    name: str
    slug: str
    price_cents: int
    currency: str = "USD"
    monthly_limit: int = 0
    """Monthly analysis limit. -1 means unlimited (Enterprise plans)."""

    features: Optional[Dict[str, Any]] = None
    stripe_price_id: Optional[str] = None

    @property
    def is_unlimited(self) -> bool:
        """True if this plan has unlimited analyses (monthly_limit == -1)."""
        return self.monthly_limit == -1

    def __repr__(self) -> str:
        limit_str = "unlimited" if self.is_unlimited else str(self.monthly_limit)
        return (
            f"PlanInfo(name={self.name!r}, "
            f"${self.price_cents / 100:.2f}/mo, "
            f"limit={limit_str})"
        )


@dataclass
class RateLimitInfo:
    """Rate limit info extracted from response headers."""

    limit: int
    """Total allowed in the window."""

    remaining: int
    """Remaining in the current window."""

    reset: int
    """Unix timestamp when limit resets."""

    def __repr__(self) -> str:
        return f"RateLimitInfo({self.remaining}/{self.limit} remaining)"
