"""
alphainfo SDK — Exception Hierarchy

All exceptions inherit from AlphaInfoError for easy catch-all handling.
Each maps to a specific HTTP error scenario from the API.
"""

from typing import Any, Dict, Optional


class AlphaInfoError(Exception):
    """Base exception for all alphainfo SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_data = response_data or {}


class AuthError(AlphaInfoError):
    """Invalid or missing API key (HTTP 401)."""
    pass


class RateLimitError(AlphaInfoError):
    """Rate or quota limit exceeded (HTTP 429)."""

    def __init__(self, message: str, retry_after: Optional[int] = None, **kwargs: Any):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class ValidationError(AlphaInfoError):
    """Request validation failed (HTTP 400/413)."""
    pass


class NotFoundError(AlphaInfoError):
    """Resource not found (HTTP 404)."""
    pass


class APIError(AlphaInfoError):
    """Server-side API error (HTTP 5xx)."""
    pass


class TimeoutError(AlphaInfoError):
    """Request timed out after retries."""
    pass


class NetworkError(AlphaInfoError):
    """Network connectivity issue."""
    pass
