from __future__ import annotations

from abc import abstractmethod
from typing import Any, Generic, final, override

from tjax import JaxAbstractClass, JaxRealArray, abstract_jit, jit, stop_gradient
from typing_extensions import TypeVar

from efax._src.expectation_parametrization import ExpectationParametrization
from efax._src.natural_parametrization import NaturalParametrization
from efax._src.parametrization import Distribution
from efax._src.tools import parameter_dot_product

NP = TypeVar("NP", bound=NaturalParametrization, default=Any)


class HasEntropy(Distribution):
    def entropy(self) -> JaxRealArray:
        raise NotImplementedError


class HasEntropyEP(ExpectationParametrization[NP], HasEntropy, JaxAbstractClass, Generic[NP]):
    @abstract_jit
    @abstractmethod
    def expected_carrier_measure(self) -> JaxRealArray:
        """The expected carrier measure of the distribution.

        This is the missing term from the inner product between the observed distribution and the
        predicted distribution.  Often, it is just xp.zeros(self.shape).
        """
        raise NotImplementedError

    @jit
    @final
    def cross_entropy(self, q: NP) -> JaxRealArray:
        """The cross entropy.

        Args:
            q: The natural parameters of the prediction.
        """
        return (
            -parameter_dot_product(q, self) + q.log_normalizer() - self.expected_carrier_measure()
        )

    @jit
    @final
    @override
    def entropy(self) -> JaxRealArray:
        """The Shannon entropy.

        This can be quite slow since it depends on a conversion to natural parameters.
        """
        return self.cross_entropy(stop_gradient(self.to_nat()))


EP = TypeVar("EP", bound=HasEntropyEP, default=Any)


class HasEntropyNP(NaturalParametrization[EP], HasEntropy, Generic[EP]):
    @jit
    @final
    @override
    def entropy(self) -> JaxRealArray:
        """The Shannon entropy."""
        return self.to_exp().cross_entropy(self)
