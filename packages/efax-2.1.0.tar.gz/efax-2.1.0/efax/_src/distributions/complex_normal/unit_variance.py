from __future__ import annotations

import math
from typing import override

import jax.random as jr
from array_api_compat import array_namespace
from tjax import JaxArray, JaxComplexArray, JaxRealArray, KeyArray, Shape, abs_square
from tjax.dataclasses import dataclass

from efax._src.interfaces.samplable import Samplable
from efax._src.mixins.has_entropy import HasEntropyEP, HasEntropyNP
from efax._src.natural_parametrization import NaturalParametrization
from efax._src.parameter import ScalarSupport, complex_field, distribution_parameter


@dataclass
class ComplexUnitVarianceNormalNP(
    HasEntropyNP["ComplexUnitVarianceNormalEP"],
    NaturalParametrization["ComplexUnitVarianceNormalEP", JaxComplexArray],
    Samplable,
):
    """The natural parametrization of the complex unit normal distribution.

    It has unit variance, and zero pseudo-variance. This is a curved exponential family.

    Args:
        two_mean_conjugate: 2 * E(conjugate(x)).
    """

    two_mean_conjugate: JaxComplexArray = distribution_parameter(ScalarSupport(ring=complex_field))
    # S = I, U = 0
    # P = I, R = 0
    # H = -I, J = 0
    # K = 0, L = I/2
    # eta = 2mean.conjugate()
    # Leta = mean.conjugate()

    @property
    @override
    def shape(self) -> Shape:
        return self.two_mean_conjugate.shape

    @override
    @classmethod
    def domain_support(cls) -> ScalarSupport:
        return ScalarSupport(ring=complex_field)

    @override
    def log_normalizer(self) -> JaxRealArray:
        mean_conjugate = self.two_mean_conjugate * 0.5
        return abs_square(mean_conjugate) + math.log(math.pi)

    @override
    def to_exp(self) -> ComplexUnitVarianceNormalEP:
        xp = array_namespace(self)
        return ComplexUnitVarianceNormalEP(xp.conj(self.two_mean_conjugate) * 0.5)

    @override
    def carrier_measure(self, x: JaxComplexArray) -> JaxRealArray:
        return -abs_square(x)

    @override
    @classmethod
    def sufficient_statistics(
        cls, x: JaxComplexArray, **fixed_parameters: JaxArray
    ) -> ComplexUnitVarianceNormalEP:
        return ComplexUnitVarianceNormalEP(x)

    @override
    def sample(self, key: KeyArray, shape: Shape | None = None) -> JaxComplexArray:
        return self.to_exp().sample(key, shape)


@dataclass
class ComplexUnitVarianceNormalEP(HasEntropyEP[ComplexUnitVarianceNormalNP], Samplable):
    """The expectation parametrization of the complex unit normal distribution.

    It has unit variance, and zero pseudo-variance. This is a curved exponential family.

    Args:
        mean: E(x).
    """

    mean: JaxComplexArray = distribution_parameter(ScalarSupport(ring=complex_field))

    @property
    @override
    def shape(self) -> Shape:
        return self.mean.shape

    @override
    @classmethod
    def domain_support(cls) -> ScalarSupport:
        return ScalarSupport(ring=complex_field)

    @classmethod
    @override
    def natural_parametrization_cls(cls) -> type[ComplexUnitVarianceNormalNP]:
        return ComplexUnitVarianceNormalNP

    @override
    def to_nat(self) -> ComplexUnitVarianceNormalNP:
        xp = array_namespace(self)
        return ComplexUnitVarianceNormalNP(xp.conj(self.mean) * 2.0)

    @override
    def expected_carrier_measure(self) -> JaxRealArray:
        # The second moment of a normal distribution with the given mean.
        return -(abs_square(self.mean) + 1.0)

    @override
    def sample(self, key: KeyArray, shape: Shape | None = None) -> JaxComplexArray:
        xp = array_namespace(self)
        shape = self.shape if shape is None else shape + self.shape
        grow = (xp.newaxis,) * (len(shape) - len(self.shape))
        key_a, key_b = jr.split(key)
        a = jr.normal(key_a, shape)
        b = jr.normal(key_b, shape)
        return a + 1j * b + self.mean[grow]

    # def conjugate_prior_distribution(self, n: JaxRealArray) -> IsotropicNormalNP:
    #     negative_half_precision = -0.5 * n * xp.ones(self.shape)
    #     return IsotropicNormalNP(n * self.mean, negative_half_precision)
    #
    # def conjugate_prior_observation(self) -> JaxComplexArray:
    #     return self.mean
