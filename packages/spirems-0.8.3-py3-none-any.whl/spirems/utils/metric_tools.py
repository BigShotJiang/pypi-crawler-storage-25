#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import math
import cv2
import numpy as np
from spirems.msg_helper import def_msg
from typing import List, Dict, Tuple
from spirems.utils.label_tools import extract_peak_points_from_binmask


def miou_binary_hard(
        y_pred, 
        y_true, 
        thr_true=0.5, 
        thr_pred=0.5, 
        eps=1e-7, 
        reduction="none"
    ):
    """
    Hard mIoU for binary segmentation with thresholding.
    y_true, y_pred: (N, H, W)
    """
    # print(f"y_true: {y_true.shape}, y_pred: {y_pred.shape}")
    n, h, w = y_true.shape
    y_true = (np.asarray(y_true) >= thr_true).astype(np.uint8)
    y_pred = (np.asarray(y_pred) >= thr_pred).astype(np.uint8)

    yt = y_true.reshape(y_true.shape[0], -1)
    yp = y_pred.reshape(y_pred.shape[0], -1)

    # foreground
    inter_fg = np.sum((yp == 1) & (yt == 1), axis=1)
    union_fg = np.sum((yp == 1) | (yt == 1), axis=1)
    iou_fg = (inter_fg + eps) / (union_fg + eps)

    # background
    inter_bg = np.sum((yp == 0) & (yt == 0), axis=1)
    union_bg = np.sum((yp == 0) | (yt == 0), axis=1)
    iou_bg = (inter_bg + eps) / (union_bg + eps)

    miou_per_sample = 0.5 * (iou_fg + iou_bg)
    if reduction == "none":
        return miou_per_sample
    elif reduction == "mean":
        return float(np.mean(miou_per_sample))
    elif reduction == "sum":
        return float(np.sum(miou_per_sample))
    else:
        raise ValueError(f"Invalid reduction: {reduction}")


def _inside_and_dist_unique(boxA, boxB, eps=1e-9, strict=False):
    """
    boxA: (4,) float32, (cx,cy,w,h)
    boxB: (N,4) float32, (cx,cy,w,h)

    return:
        inside: (N,) bool   # 最多只有1个True（选dist最小的那个inside）
        dist:   (N,) float32
    """
    boxA = np.asarray(boxA, dtype=np.float32).reshape(4,)
    boxB = np.asarray(boxB, dtype=np.float32)
    if boxB.ndim != 2 or boxB.shape[1] != 4:
        raise ValueError(f"boxB must be (N,4), got {boxB.shape}")

    axc, ayc, aw, ah = boxA
    bxc, byc, bw, bh = boxB[:, 0], boxB[:, 1], boxB[:, 2], boxB[:, 3]

    # A 边界
    ax1 = axc - aw * 0.5
    ay1 = ayc - ah * 0.5
    ax2 = axc + aw * 0.5
    ay2 = ayc + ah * 0.5

    # B 边界（向量）
    bx1 = bxc - bw * 0.5
    by1 = byc - bh * 0.5
    bx2 = bxc + bw * 0.5
    by2 = byc + bh * 0.5

    # 包含关系（A 在 B 内）
    if strict:
        inside_all = (ax1 > bx1 + eps) & (ay1 > by1 + eps) & (ax2 < bx2 - eps) & (ay2 < by2 - eps)
    else:
        inside_all = (ax1 >= bx1 - eps) & (ay1 >= by1 - eps) & (ax2 <= bx2 + eps) & (ay2 <= by2 + eps)

    # 中心距离
    dx = axc - bxc
    dy = ayc - byc
    dist = np.sqrt(dx * dx + dy * dy).astype(np.float32)

    # 只保留 inside 且 dist 最小的那个（最多1个True）
    inside = np.zeros_like(inside_all, dtype=bool)
    if np.any(inside_all):
        # 非候选置为 +inf，argmin 一定落在候选里
        masked_dist = np.where(inside_all, dist, np.inf)
        best_idx = int(np.argmin(masked_dist))
        if np.isfinite(masked_dist[best_idx]):
            inside[best_idx] = True

    return inside, dist


class SODRegionF1Metric:
    def __init__(self, eps=1e-7):
        self.eps = eps
        self.TP = 0
        self.FP = 0
        self.FN = 0

    def __call__(self, y_pred, y_true):
        """
        y_pred: (H, W)
        y_true: spirecv_msgs::XYList / spirecv_msgs::XY
        """
        h, w = y_pred.shape
        pred_peak_pts = extract_peak_points_from_binmask(y_pred)
        pred_peak_pts = np.asarray([[pt[0] / w, pt[1] / h, 170 / w, 170 / h] for pt in pred_peak_pts], dtype=np.float32)

        if y_true["type"] == "spirecv_msgs::XYList":
            bboxes = y_true["Y"][-1]["bboxes"]
        elif y_true["type"] == "spirecv_msgs::XY":
            bboxes = y_true["Y"]["bboxes"]
        else:
            raise ValueError(f"Invalid msg type: {y_true['type']}")

        if len(bboxes) > 0:
            for bbox in bboxes:
                if len(pred_peak_pts) > 0:
                    inside, dist = _inside_and_dist_unique(bbox, pred_peak_pts)
                    if np.any(inside):
                        self.TP += 1
                    else:
                        self.FN += 1
                    pred_peak_pts = pred_peak_pts[~inside]
                else:
                    self.FN += 1
        self.FP += pred_peak_pts.shape[0]

    def reset(self):
        self.TP = 0
        self.FP = 0
        self.FN = 0

    def recall(self):
        """
        计算召回率
        """
        return self.TP / (self.TP + self.FN + self.eps)

    def precision(self):
        """
        计算准确率
        """ 
        return self.TP / (self.TP + self.FP + self.eps)

    def score(self):
        """
        计算 F1 分数
        """
        recall = self.TP / (self.TP + self.FN + self.eps)
        precision = self.TP / (self.TP + self.FP + self.eps)
        f1 = 2 * recall * precision / (recall + precision + self.eps)
        return f1


def count_macs_params_thop(model, inputs):
    from thop import profile
    import torch
    with torch.no_grad():
        model.eval()
        macs, params = profile(model, inputs=inputs, verbose=False)
    return macs, params
