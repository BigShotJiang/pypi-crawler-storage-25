import os
from spirems.msg_helper import def_msg


def yolo_format_to_XY(yolo_results):
    if isinstance(yolo_results, list):
        yolo_results = yolo_results[0]
    if not hasattr(yolo_results, "boxes"):
        raise ValueError("输入的yolo_results对象不包含boxes属性")
    boxes = yolo_results.boxes
    msg = def_msg("spirecv_msgs::XY")
    msg["X"] = {"img": yolo_results.orig_img.transpose(2, 0, 1).copy()}  # (C, H, W), BGR, uint8
    msg["Y"] = {
        "bboxes": boxes.xywhn.cpu().numpy().tolist(),  # (N, 4)
        "obj_cls": boxes.cls.cpu().numpy().tolist(),  # (N,)
        "names": yolo_results.names
    }
    return msg


def yolo_format_to_2DTargets(yolo_results):
    """将 YOLO 检测或跟踪结果转换为 spirecv_msgs::2DTargets 消息

    兼容 model.predict()（检测）和 model.track()（跟踪）两种模式的输出。
    跟踪模式下每个 target 额外包含 track_id 字段。

    @param yolo_results: YOLO model.predict() 或 model.track() 的返回值
    @return: spirecv_msgs::2DTargets 消息字典
    """
    if isinstance(yolo_results, list):
        yolo_results = yolo_results[0]
    if not hasattr(yolo_results, "boxes") or yolo_results.boxes is None:
        raise ValueError("输入的yolo_results对象不包含boxes属性")
        # 无检测/跟踪结果，返回空消息
        msg = def_msg("spirecv_msgs::2DTargets")
        if hasattr(yolo_results, 'orig_img') and yolo_results.orig_img is not None:
            msg["height"] = yolo_results.orig_img.shape[0]
            msg["width"] = yolo_results.orig_img.shape[1]
        return msg

    boxes = yolo_results.boxes
    msg = def_msg("spirecv_msgs::2DTargets")
    msg["file_name"] = ""
    msg["height"] = yolo_results.orig_img.shape[0]
    msg["width"] = yolo_results.orig_img.shape[1]
    msg["names"] = yolo_results.names
    msg["targets"] = []
    clss = yolo_results.boxes.cls.cpu().numpy().astype(float)
    conf = yolo_results.boxes.conf.cpu().numpy().astype(float)
    xywh = yolo_results.boxes.xywh.cpu().numpy().astype(float)

    # 跟踪模式下提取 track_id
    track_ids = None
    if boxes.is_track and boxes.id is not None:
        track_ids = boxes.id.int().cpu().numpy().tolist()

    for i in range(len(clss)):
        ann = dict()
        name = yolo_results.names[int(clss[i])].strip()
        ann["category_name"] = name.replace(' ', '_').lower()
        ann["category_id"] = int(clss[i])
        ann["score"] = round(float(conf[i]), 3)
        ann["bbox"] = [round(float(j), 3) for j in xywh[i].tolist()]
        ann["bbox"][0] = round(ann["bbox"][0] - ann["bbox"][2] / 2, 3)
        ann["bbox"][1] = round(ann["bbox"][1] - ann["bbox"][3] / 2, 3)
        ann["cxy"] = [
            round((ann["bbox"][0] + ann["bbox"][2] / 2.) / msg["width"], 5),
            round((ann["bbox"][1] + ann["bbox"][3] / 2.) / msg["height"], 5)
        ]
        if track_ids is not None:
            ann["tracked_id"] = int(track_ids[i])
        msg["targets"].append(ann)
    return msg


def yolo_format_to_SpireView(yolo_results):
    if isinstance(yolo_results, list):
        yolo_results = yolo_results[0]
    if not hasattr(yolo_results, "boxes"):
        raise ValueError("输入的yolo_results对象不包含boxes属性")
    boxes = yolo_results.boxes
    msg = {}
    msg["file_name"] = os.path.basename(yolo_results.path)
    msg["height"] = yolo_results.orig_img.shape[0]
    msg["width"] = yolo_results.orig_img.shape[1]
    msg["annos"] = []
    clss = yolo_results.boxes.cls.cpu().numpy().astype(float)
    conf = yolo_results.boxes.conf.cpu().numpy().astype(float)
    xywh = yolo_results.boxes.xywh.cpu().numpy().astype(float)
    for i in range(len(clss)):
        ann = dict()
        name = yolo_results.names[int(clss[i])].strip()
        ann["category_name"] = name.replace(' ', '_').lower()
        ann["category_id"] = int(clss[i])
        ann["score"] = round(conf[i], 3)
        ann["bbox"] = [round(j, 3) for j in xywh[i].tolist()]
        ann["bbox"][0] = round(ann["bbox"][0] - ann["bbox"][2] / 2, 3)
        ann["bbox"][1] = round(ann["bbox"][1] - ann["bbox"][3] / 2, 3)
        ann["cxy"] = [
            round((ann["bbox"][0] + ann["bbox"][2] / 2.) / msg["width"], 5),
            round((ann["bbox"][1] + ann["bbox"][3] / 2.) / msg["height"], 5)
        ]
        msg["annos"].append(ann)
    return msg


def spirecv_2DTargets_to_XY(targets_msg, cvimg=None):
    """
    将 spirecv_msgs::2DTargets 类型转换为 spirecv_msgs::XY 类型
    """
    msg = def_msg("spirecv_msgs::XY")
    msg["X"] = {"img": cvimg.transpose(2, 0, 1).copy() if cvimg is not None else None}
    bboxes = []
    obj_cls = []
    for target in targets_msg["targets"]:
        x1, y1, w, h = target["bbox"]
        x = (x1 + w / 2) / targets_msg["width"]
        y = (y1 + h / 2) / targets_msg["height"]
        w_norm = w / targets_msg["width"]
        h_norm = h / targets_msg["height"]
        bboxes.append([x, y, w_norm, h_norm])
        obj_cls.append(target["category_id"])
    msg["Y"] = {
        "bboxes": bboxes,
        "obj_cls": obj_cls,
        "names": {int(k): v for k, v in targets_msg["names"].items()}
    }
    return msg


def spirecv_2DTargets_to_SpireView(targets_msg):
    """
    将 spirecv_msgs::2DTargets 类型转换为 SpireView 类型
    """
    msg = {
        "file_name": targets_msg["file_name"],
        "height": targets_msg["height"],
        "width": targets_msg["width"],
        "annos": targets_msg["targets"]
    }
    return msg
