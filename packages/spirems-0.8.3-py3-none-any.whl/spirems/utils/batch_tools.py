#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import cv2
import numpy as np
from spirems.msg_helper import def_msg
from typing import List, Dict


def xy_collate_fn(batch: List[Dict]) -> Dict:
    """
    将多个 spirecv_msgs::XY/spirecv_msgs::XYList 转换为 spirecv_msgs::BatchXY/spirecv_msgs::BatchXYList

    参数:
        batch (List[dict]): spirecv_msgs::XY/spirecv_msgs::XYList 的列表数据

    返回值:
        (dict): spirecv_msgs::BatchXY/spirecv_msgs::BatchXYList
    """
    assert isinstance(batch, list) and len(batch) > 0
    assert all([item["type"] in ["spirecv_msgs::XY", "spirecv_msgs::XYList"] for item in batch])
    if batch[0]["type"] == "spirecv_msgs::XY":
        new_batch = def_msg("spirecv_msgs::BatchXY")
    else:
        new_batch = def_msg("spirecv_msgs::BatchXYList")
    new_batch["batch"] = batch
    return new_batch
