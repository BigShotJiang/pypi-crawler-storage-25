import cv2
import numpy as np

_g_dict = None


def attach_aruco(id: int, img: np.ndarray):
    """
    在img的右下角附加一个22x22的aruco marker，marker的id为id%1000（使用DICT_5X5_1000字典）
    id: int, aruco marker的id，范围0-999
    img: (H, W, 3) uint8
    return: (H, W, 3) uint8
    """
    assert img.shape[0] >= 22 and img.shape[1] >= 22, "图片尺寸必须至少为22x22 (attach_aruco)"
    assert img.shape[2] == 3, "图片必须为3通道 (attach_aruco)"
    assert img.dtype == np.uint8, "图片数据类型必须为uint8 (attach_aruco)"
    dict_aruco = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_1000)

    marker_pad = np.ones((22, 22), dtype=np.uint8) * 255
    inner_roi = (4, 4, 14, 14)  # x, y, w, h
    full_roi = (img.shape[1] - 22, img.shape[0] - 22, 22, 22)  # x, y, w, h

    id_k = id % 1000

    marker_img = cv2.aruco.generateImageMarker(dict_aruco, id_k, 14, 1)
    marker_pad[inner_roi[1]:inner_roi[1]+inner_roi[3], inner_roi[0]:inner_roi[0]+inner_roi[2]] = marker_img
    marker_pad = np.expand_dims(marker_pad, axis=2)

    img[full_roi[1]:full_roi[1]+full_roi[3], full_roi[0]:full_roi[0]+full_roi[2], :] = marker_pad
    return img


def parse_aruco(img: np.ndarray) -> int:
    """
    从img的右下角22x22区域解析aruco marker，返回marker的id
    img: (H, W, 3) uint8
    return: int, marker的id，如果未检测到返回-1
    """
    global _g_dict
    if _g_dict is None:
        _g_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_1000)

    full_roi = (img.shape[1] - 22, img.shape[0] - 22, 22, 22)  # x, y, w, h
    marker_img = img[full_roi[1]:full_roi[1]+full_roi[3], full_roi[0]:full_roi[0]+full_roi[2]]
    ch = cv2.split(marker_img)

    id_ = -1
    _, id_i, _ = cv2.aruco.detectMarkers(ch[0], _g_dict)
    if len(id_i) > 0:
        id_ = id_i[0]
    if id_ == -1:
        _, id_k, _ = cv2.aruco.detectMarkers(ch[1], _g_dict)
        if len(id_k) > 0:
            id_ = id_k[0]
    if id_ == -1:
        _, id_m, _ = cv2.aruco.detectMarkers(ch[2], _g_dict)
        if len(id_m) > 0:
            id_ = id_m[0]

    return id_


if __name__ == "__main__":
    import time
    img = np.ones((480, 640, 3), dtype=np.uint8) * 100
    for i in range(1000):
        t0 = time.time()
        img = attach_aruco(i, img)
        t1 = time.time()
        id_ = parse_aruco(img)
        t2 = time.time()
        assert id_ == i, f"解析错误: {id_} != {i}"
        print(f"测试通过: {id_} == {i}")
        print(f"attach_aruco耗时: {(t1-t0)*1000:.2f} ms, parse_aruco耗时: {(t2-t1)*1000:.2f} ms")
    # cv2.imwrite("/home/jario/test_aruco.png", img)

