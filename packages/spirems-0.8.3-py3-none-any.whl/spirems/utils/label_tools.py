#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import cv2
import numpy as np
from spirems.msg_helper import def_msg
from typing import List, Dict, Tuple


def bbox_iou_xywh(box1: list, box2: list) -> float:
    """
    计算两个边界框的 IoU
    输入:
        box1, box2: [x, y, w, h]
            x, y 为左上角坐标
            w, h 为宽高
    返回:
        iou: float
    """
    x1_1, y1_1, w1, h1 = box1
    x1_2, y1_2, w2, h2 = box2

    # 转成左上角 + 右下角
    x2_1 = x1_1 + w1
    y2_1 = y1_1 + h1
    x2_2 = x1_2 + w2
    y2_2 = y1_2 + h2

    # 交集区域
    inter_x1 = max(x1_1, x1_2)
    inter_y1 = max(y1_1, y1_2)
    inter_x2 = min(x2_1, x2_2)
    inter_y2 = min(y2_1, y2_2)

    inter_w = max(0, inter_x2 - inter_x1)
    inter_h = max(0, inter_y2 - inter_y1)
    inter_area = inter_w * inter_h

    # 各自面积
    area1 = max(0, w1) * max(0, h1)
    area2 = max(0, w2) * max(0, h2)

    # 并集面积
    union_area = area1 + area2 - inter_area

    if union_area == 0:
        return 0.0

    iou = inter_area / union_area
    return iou


def bbox_iou_matrix_xywh(boxes1: np.ndarray, boxes2: np.ndarray) -> np.ndarray:
    """
    计算两个框数组的IOU矩阵
    boxes1, boxes2: (N, 4) float, 格式xywh [x, y, w, h]
    返回: (N, M) IOU矩阵，其中N=len(boxes1), M=len(boxes2)
    """
    if boxes1.shape[1] != 4 or boxes2.shape[1] != 4:
        raise ValueError("Boxes must be (N, 4) arrays")
    
    # 转换为xyxy格式
    boxes1_xyxy = np.zeros_like(boxes1)
    boxes1_xyxy[:, 0] = boxes1[:, 0]  # x1 = x
    boxes1_xyxy[:, 1] = boxes1[:, 1]  # y1 = y
    boxes1_xyxy[:, 2] = boxes1[:, 0] + boxes1[:, 2]  # x2 = x + w
    boxes1_xyxy[:, 3] = boxes1[:, 1] + boxes1[:, 3]  # y2 = y + h
    
    boxes2_xyxy = np.zeros_like(boxes2)
    boxes2_xyxy[:, 0] = boxes2[:, 0]
    boxes2_xyxy[:, 1] = boxes2[:, 1]
    boxes2_xyxy[:, 2] = boxes2[:, 0] + boxes2[:, 2]
    boxes2_xyxy[:, 3] = boxes2[:, 1] + boxes2[:, 3]
    
    # 计算IOU
    N = boxes1_xyxy.shape[0]
    M = boxes2_xyxy.shape[0]
    iou_matrix = np.zeros((N, M), dtype=float)
    
    for i in range(N):
        for j in range(M):
            boxA = boxes1_xyxy[i]
            boxB = boxes2_xyxy[j]
            
            # 计算交集
            xA = max(boxA[0], boxB[0])
            yA = max(boxA[1], boxB[1])
            xB = min(boxA[2], boxB[2])
            yB = min(boxA[3], boxB[3])
            
            interW = max(0, xB - xA)
            interH = max(0, yB - yA)
            interArea = interW * interH
            
            # 计算并集
            boxAArea = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
            boxBArea = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])
            unionArea = boxAArea + boxBArea - interArea
            
            iou_matrix[i, j] = interArea / unionArea if unionArea > 0 else 0.0
    
    return iou_matrix


def _render_binmask(
        msg: dict,
        w: int,
        h: int,
        t: int,
        factor: float = 0.8,
        use_ellipse: bool = False
    ):
    binmask = np.zeros((h, w), dtype=np.float32)
    if msg["type"] == "spirecv_msgs::XY":
        pass
    elif msg["type"] == "spirecv_msgs::XYList":
        Y = msg["Y"]
        assert isinstance(Y, list) and t == len(Y)
        last_cxy = {}
        last_owh = {}
        last_color = 0
        for i, y in enumerate(Y):
            for bbox, track_id in zip(y["bboxes"], y["tracked_ids"]):
                obj_x1, obj_y1 = int((bbox[0] - bbox[2] / 2) * w), int((bbox[1] - bbox[3] / 2) * h)
                obj_x2, obj_y2 = int((bbox[0] + bbox[2] / 2) * w), int((bbox[1] + bbox[3] / 2) * h)
                obj_wh, obj_hh = int(bbox[2] * w / 2), int(bbox[3] * h / 2)
                obj_cx, obj_cy = int((bbox[0] * w)), int((bbox[1] * h))
                color = factor ** (t - 1 - i)
                if use_ellipse:
                    cv2.ellipse(
                        binmask, 
                        (obj_cx, obj_cy), 
                        (obj_wh, obj_hh), 
                        0, 
                        0, 
                        360, 
                        color, 
                        -1,
                        cv2.LINE_AA
                    )
                else:
                    cv2.rectangle(
                        binmask, 
                        (obj_x1, obj_y1),
                        (obj_x2, obj_y2),
                        color, 
                        -1,
                        cv2.LINE_AA
                    )
                # print(last_cxy)
                if i > 0 and track_id in last_cxy:
                    last_cx, last_cy = last_cxy[track_id]
                    last_wh, last_hh = last_owh[track_id]

                    # print("[1]:", np.sqrt((obj_cx - last_cx) ** 2 + (obj_cy - last_cy) ** 2))
                    # print("[2]:", obj_wh * 2)
                    # if np.sqrt((obj_cx - last_cx) ** 2 + (obj_cy - last_cy) ** 2) > obj_wh:
                    if np.abs(obj_cx - last_cx) > obj_wh or np.abs(obj_cy - last_cy) > obj_hh:
                        for scale in [0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875]:
                            cx, cy = last_cx + (obj_cx - last_cx) * scale, last_cy + (obj_cy - last_cy) * scale
                            wh, hh = last_wh + (obj_wh - last_wh) * scale, last_hh + (obj_hh - last_hh) * scale
                            c_color = last_color + (color - last_color) * scale
                            # if np.sqrt((cx - last_cx) ** 2 + (cy - last_cy) ** 2) >= obj_wh / 2 and np.sqrt((cx - obj_cx) ** 2 + (cy - obj_cy) ** 2) >= obj_wh / 2:
                            if (np.abs(cx - last_cx) >= obj_wh / 2 or np.abs(cy - last_cy) >= obj_hh / 2) and (np.abs(cx - obj_cx) >= obj_wh / 2 or np.abs(cy - obj_cy) >= obj_hh / 2):
                                if use_ellipse:
                                    cv2.ellipse(
                                        binmask, 
                                        (int(cx), int(cy)), 
                                        (int(wh), int(hh)), 
                                        0, 
                                        0, 
                                        360, 
                                        c_color, 
                                        -1,
                                        cv2.LINE_AA
                                    )
                                else:
                                    cv2.rectangle(
                                        binmask, 
                                        (int(cx - wh), int(cy - hh)), 
                                        (int(cx + wh), int(cy + hh)),
                                        c_color, 
                                        -1,
                                        cv2.LINE_AA
                                    )
                last_cxy[track_id] = (obj_cx, obj_cy)
                last_owh[track_id] = (obj_wh, obj_hh)
                last_color = color
    return binmask


def _render_split_binmask(
        msg: dict,
        w: int,
        h: int,
        t: int,
        use_ellipse: bool = False
    ):
    split_binmasks = []
    if msg["type"] == "spirecv_msgs::XY":
        pass
    elif msg["type"] == "spirecv_msgs::XYList":
        Y = msg["Y"]
        assert isinstance(Y, list) and t == len(Y)
        for i, y in enumerate(Y):
            binmask = np.zeros((h, w), dtype=np.float32)
            for bbox, track_id in zip(y["bboxes"], y["tracked_ids"]):
                obj_x1, obj_y1 = int((bbox[0] - bbox[2] / 2) * w), int((bbox[1] - bbox[3] / 2) * h)
                obj_x2, obj_y2 = int((bbox[0] + bbox[2] / 2) * w), int((bbox[1] + bbox[3] / 2) * h)
                obj_wh, obj_hh = int(bbox[2] * w / 2), int(bbox[3] * h / 2)
                obj_cx, obj_cy = int((bbox[0] * w)), int((bbox[1] * h))
                if use_ellipse:
                    cv2.ellipse(
                        binmask, 
                        (obj_cx, obj_cy), 
                        (obj_wh, obj_hh), 
                        0, 
                        0, 
                        360, 
                        1.0, 
                        -1,
                        cv2.LINE_AA
                    )
                else:
                    cv2.rectangle(
                        binmask,
                        (obj_x1, obj_y1),
                        (obj_x2, obj_y2),
                        1.0,
                        -1,
                        cv2.LINE_AA
                    )
            split_binmasks.append(binmask)
    return split_binmasks


def img_bbox_to_binmask(
        msg: dict, 
        order: str = "tchw",
        factor: float = 0.8,
        output_extra_sizes: List[Tuple[int, int]] | None = None,
        output_split_mask: bool = False,
        use_ellipse: bool = False
    ):
    """
    将 spirecv_msgs::XY/XYList 消息中的 bboxes 转换为二值掩码
    :param msg: spirecv_msgs::XY/XYList 消息
    :return: msg: spirecv_msgs::XY 消息
    """
    assert msg["type"] in ["spirecv_msgs::XY", "spirecv_msgs::XYList"]
    assert order == "tchw", "目前仅支持tchw格式"

    t, c, h, w = msg["X"]["img"].shape

    binmask = _render_binmask(msg, w, h, t, factor, use_ellipse)
    extra_binmasks = []
    if output_extra_sizes is not None:
        for (ew, eh) in output_extra_sizes:
            extra_binmasks.append(_render_binmask(msg, ew, eh, t, factor, use_ellipse))
    if output_split_mask:
        split_binmasks = _render_split_binmask(msg, w, h, t, use_ellipse)

    if msg["type"] == "spirecv_msgs::XY":
        pass
    elif msg["type"] == "spirecv_msgs::XYList":
        msg["type"] = "spirecv_msgs::XY"
        msg["Y"] = msg["Y"][-1]
        msg["Y"]["binmask"] = binmask
        if output_extra_sizes is not None:
            msg["Y"]["extra_binmasks"] = extra_binmasks
        if output_split_mask:
            msg["Y"]["split_binmasks"] = split_binmasks

    return msg


def extract_centers_from_binmask(
        binary_img, 
        min_area=1, 
        max_area=None, 
        return_int=True
    ):
    """
    从二值图中提取所有白色小目标的中心坐标(质心).
    
    binary_img: np.ndarray, HxW, 0/255 或 0/1
    min_area: 过滤太小的噪点
    max_area: 过滤太大的区域(可选)
    return_int: True则返回四舍五入后的像素整数坐标
    
    return:
        centers: list of (x, y)  # 注意是(x列, y行)
        stats:   每个连通域的统计信息 [x, y, w, h, area]
    """
    # 保证是0/255的uint8二值
    if binary_img.dtype != np.uint8:
        binary = (binary_img > 0).astype(np.uint8) * 255
    else:
        binary = (binary_img > 0).astype(np.uint8) * 255

    # 连通域分析：8连通一般更合理
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binary, connectivity=8)

    centers = []
    kept_stats = []

    for i in range(1, num_labels):  # 0是背景
        x, y, w, h, area = stats[i]
        if area < min_area:
            continue
        if max_area is not None and area > max_area:
            continue

        cx, cy = centroids[i]  # float, (x, y)
        if return_int:
            cx, cy = int(round(cx)), int(round(cy))

        centers.append((cx, cy))
        kept_stats.append((x, y, w, h, area))

    return centers, kept_stats


def extract_peak_points_from_binmask(
        gray01, 
        thresh=0.1, 
        min_area=1, 
        max_area=None
    ):
    """
    gray01: HxW, float/uint8 均可（若float建议范围[0,1]）
    thresh: 连通域mask阈值 > thresh 认为是目标区域
    min_area/max_area: 过滤面积
    return:
        peaks: list of (x, y, max_val, area)
    """
    img = np.asarray(gray01)

    # 统一成 float32 方便后续取最大值
    if img.dtype != np.float32:
        img_f = img.astype(np.float32)
    else:
        img_f = img

    # 生成连通域mask（uint8 0/255）
    mask = (img_f > thresh).astype(np.uint8) * 255

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)

    peaks = []
    for i in range(1, num_labels):  # 0是背景
        x, y, w, h, area = stats[i]
        if area < min_area:
            continue
        if max_area is not None and area > max_area:
            continue

        # 在该连通域的bbox内找最大值像素（只在当前label内）
        lab_roi = labels[y:y+h, x:x+w]
        img_roi = img_f[y:y+h, x:x+w]

        roi_mask = (lab_roi == i)
        if not np.any(roi_mask):
            continue

        # 只保留目标区域像素，其他设为 -inf，argmax 就一定落在目标内
        tmp = np.where(roi_mask, img_roi, -np.inf)
        flat_idx = int(np.argmax(tmp))
        ry, rx = np.unravel_index(flat_idx, tmp.shape)

        px, py = int(x + rx), int(y + ry)
        max_val = float(img_f[py, px])
        peaks.append((px, py, max_val, int(area)))

    return peaks
