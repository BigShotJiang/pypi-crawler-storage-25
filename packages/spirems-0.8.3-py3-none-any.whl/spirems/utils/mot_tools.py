"""
MOT（多目标跟踪）评价工具模块

从 TrackEval 中提取 HOTA / CLEAR (MOTA) / Identity (IDF1) / Count 四个核心评价指标，
封装为自包含函数，不依赖 TrackEval 文件夹，仅依赖 numpy 和 scipy。

输入格式：
    gt_data / pred_data 为按帧排列的列表，每帧一个 dict：
        {
            'ids':     [int, ...],              # 目标 track ID
            'bboxes':  [[x, y, w, h], ...],     # 边界框 (xywh, 左上角)
            'classes': [int, ...],              # 类别 ID
            'scores':  [float, ...],            # (仅 pred_data) 置信度
        }
"""
import numpy as np
from copy import deepcopy
from scipy.optimize import linear_sum_assignment


# ============================================================================
# IoU 计算
# ============================================================================

def _calculate_box_ious(bboxes1, bboxes2, box_format='xywh'):
    """计算两组边界框之间的 IoU 矩阵

    @param bboxes1:  (M, 4) numpy array, 第一组框
    @param bboxes2:  (N, 4) numpy array, 第二组框
    @param box_format: 'xywh' 或 'x0y0x1y1'
    @return: (M, N) IoU 矩阵
    """
    if box_format == 'xywh':
        bboxes1 = deepcopy(bboxes1)
        bboxes2 = deepcopy(bboxes2)
        bboxes1[:, 2] = bboxes1[:, 0] + bboxes1[:, 2]
        bboxes1[:, 3] = bboxes1[:, 1] + bboxes1[:, 3]
        bboxes2[:, 2] = bboxes2[:, 0] + bboxes2[:, 2]
        bboxes2[:, 3] = bboxes2[:, 1] + bboxes2[:, 3]
    elif box_format != 'x0y0x1y1':
        raise ValueError(f'box_format {box_format} 不支持')

    min_ = np.minimum(bboxes1[:, np.newaxis, :], bboxes2[np.newaxis, :, :])
    max_ = np.maximum(bboxes1[:, np.newaxis, :], bboxes2[np.newaxis, :, :])
    intersection = np.maximum(min_[..., 2] - max_[..., 0], 0) * np.maximum(min_[..., 3] - max_[..., 1], 0)
    area1 = (bboxes1[..., 2] - bboxes1[..., 0]) * (bboxes1[..., 3] - bboxes1[..., 1])
    area2 = (bboxes2[..., 2] - bboxes2[..., 0]) * (bboxes2[..., 3] - bboxes2[..., 1])
    union = area1[:, np.newaxis] + area2[np.newaxis, :] - intersection
    intersection[area1 <= 0 + np.finfo('float').eps, :] = 0
    intersection[:, area2 <= 0 + np.finfo('float').eps] = 0
    intersection[union <= 0 + np.finfo('float').eps] = 0
    union[union <= 0 + np.finfo('float').eps] = 1
    return intersection / union


# ============================================================================
# 数据预处理：将按帧排列的 gt/pred 列表转换为 eval_sequence 所需 data dict
# ============================================================================

def _prepare_mot_data(gt_data, pred_data):
    """构建 MOT 评价所需的 data dict

    @param gt_data:   按帧排列的 gt 列表
    @param pred_data: 按帧排列的预测列表
    @return: data dict，包含 gt_ids, tracker_ids, gt_dets, tracker_dets,
             similarity_scores, 计数和 ID 数量等字段
    """
    num_timesteps = len(gt_data)
    assert len(pred_data) == num_timesteps, 'gt_data 和 pred_data 帧数不一致'

    data = {
        'gt_ids': [None] * num_timesteps,
        'tracker_ids': [None] * num_timesteps,
        'gt_dets': [None] * num_timesteps,
        'tracker_dets': [None] * num_timesteps,
        'tracker_confidences': [None] * num_timesteps,
        'gt_classes': [None] * num_timesteps,
        'tracker_classes': [None] * num_timesteps,
        'similarity_scores': [None] * num_timesteps,
    }
    num_gt_dets = 0
    num_tracker_dets = 0

    for t in range(num_timesteps):
        gt = gt_data[t]
        pred = pred_data[t]

        gt_ids_t = np.array(gt.get('ids', []), dtype=int)
        gt_bboxes_t = np.array(gt.get('bboxes', []), dtype=float)
        gt_classes_t = np.array(gt.get('classes', []), dtype=int)
        if gt_bboxes_t.ndim == 1 and len(gt_bboxes_t) > 0:
            gt_bboxes_t = gt_bboxes_t.reshape(-1, 4)

        pred_ids_t = np.array(pred.get('ids', []), dtype=int)
        pred_bboxes_t = np.array(pred.get('bboxes', []), dtype=float)
        pred_classes_t = np.array(pred.get('classes', []), dtype=int)
        pred_scores_t = np.array(pred.get('scores', []), dtype=float)
        if pred_bboxes_t.ndim == 1 and len(pred_bboxes_t) > 0:
            pred_bboxes_t = pred_bboxes_t.reshape(-1, 4)

        data['gt_ids'][t] = gt_ids_t
        data['gt_dets'][t] = gt_bboxes_t
        data['gt_classes'][t] = gt_classes_t
        data['tracker_ids'][t] = pred_ids_t
        data['tracker_dets'][t] = pred_bboxes_t
        data['tracker_classes'][t] = pred_classes_t
        data['tracker_confidences'][t] = pred_scores_t

        # IoU 相似度
        if len(gt_bboxes_t) > 0 and len(pred_bboxes_t) > 0:
            ious = _calculate_box_ious(gt_bboxes_t, pred_bboxes_t, box_format='xywh')
        else:
            ious = np.zeros((len(gt_bboxes_t), len(pred_bboxes_t)))
        data['similarity_scores'][t] = ious

        num_gt_dets += len(gt_ids_t)
        num_tracker_dets += len(pred_ids_t)

    # 第一遍：收集所有合法正数 ID
    all_gt_ids_flat = []
    all_tracker_ids_flat = []
    for t in range(num_timesteps):
        all_gt_ids_flat.extend([x for x in data['gt_ids'][t].tolist() if x >= 0])
        all_tracker_ids_flat.extend([x for x in data['tracker_ids'][t].tolist() if x >= 0])

    # GT ID 重新标号映射
    gt_id_map = {}
    if len(all_gt_ids_flat) > 0:
        for new_id, old_id in enumerate(sorted(set(all_gt_ids_flat))):
            gt_id_map[old_id] = new_id

    # Tracker ID 重新标号映射
    tracker_id_map = {}
    if len(all_tracker_ids_flat) > 0:
        for new_id, old_id in enumerate(sorted(set(all_tracker_ids_flat))):
            tracker_id_map[old_id] = new_id
    next_tracker_id = len(tracker_id_map)  # 用于给 -1 分配新 ID

    # 第二遍：逐帧重映射 ID
    for t in range(num_timesteps):
        # GT IDs
        gt_new = []
        for gid in data['gt_ids'][t]:
            if gid >= 0 and gid in gt_id_map:
                gt_new.append(gt_id_map[gid])
            else:
                gt_new.append(-1)  # 理论上不应该出现
        data['gt_ids'][t] = np.array(gt_new, dtype=int)

        # Tracker IDs
        trk_new = []
        for tid in data['tracker_ids'][t]:
            if tid >= 0 and tid in tracker_id_map:
                trk_new.append(tracker_id_map[tid])
            else:
                # -1 或未知 ID：分配一个唯一的新 ID（单例 track）
                trk_new.append(next_tracker_id)
                next_tracker_id += 1
        data['tracker_ids'][t] = np.array(trk_new, dtype=int)

    # 重新统计 ID 数量（所有 ID 现在都是非负的）
    all_gt_ids_set = set()
    all_tracker_ids_set = set()
    for t in range(num_timesteps):
        all_gt_ids_set.update(data['gt_ids'][t].tolist())
        all_tracker_ids_set.update(data['tracker_ids'][t].tolist())
    # GT 中不应有 -1，但安全起见过滤
    all_gt_ids_set.discard(-1)
    all_tracker_ids_set.discard(-1)

    data['num_gt_dets'] = int(num_gt_dets)
    data['num_tracker_dets'] = int(num_tracker_dets)
    data['num_gt_ids'] = len(all_gt_ids_set)
    data['num_tracker_ids'] = len(all_tracker_ids_set)
    data['num_timesteps'] = num_timesteps
    return data


# ============================================================================
# CLEAR 评价 (MOTA, MOTP, IDSW, MT, ML, Frag, FP, FN 等)
# ============================================================================

def evaluate_clear(data, threshold=0.5):
    """计算 CLEAR MOT 指标

    @param data:      _prepare_mot_data() 返回的 data dict
    @param threshold: IoU 匹配阈值，默认 0.5
    @return: dict，包含 MOTA, MOTP, IDSW, CLR_TP, CLR_FN, CLR_FP, MT, PT, ML, Frag 等
    """
    res = {
        'CLR_TP': 0, 'CLR_FN': 0, 'CLR_FP': 0, 'IDSW': 0,
        'MT': 0, 'PT': 0, 'ML': 0, 'Frag': 0,
        'MOTP_sum': 0.0, 'CLR_Frames': data['num_timesteps'],
    }

    if data['num_tracker_dets'] == 0:
        res['CLR_FN'] = data['num_gt_dets']
        res['ML'] = data['num_gt_ids']
        res['MLR'] = 1.0
        return _compute_clear_final(res)

    if data['num_gt_dets'] == 0:
        res['CLR_FP'] = data['num_tracker_dets']
        res['MLR'] = 1.0
        return _compute_clear_final(res)

    num_gt_ids = data['num_gt_ids']
    gt_id_count = np.zeros(num_gt_ids)
    gt_matched_count = np.zeros(num_gt_ids)
    gt_frag_count = np.zeros(num_gt_ids)
    prev_tracker_id = np.nan * np.zeros(num_gt_ids)
    prev_timestep_tracker_id = np.nan * np.zeros(num_gt_ids)

    num_t = data['num_timesteps']
    for t in range(num_t):
        gt_ids_t = data['gt_ids'][t]
        tracker_ids_t = data['tracker_ids'][t]
        similarity = data['similarity_scores'][t]

        if len(gt_ids_t) == 0:
            res['CLR_FP'] += len(tracker_ids_t)
            continue
        if len(tracker_ids_t) == 0:
            res['CLR_FN'] += len(gt_ids_t)
            gt_id_count[gt_ids_t] += 1
            continue

        score_mat = (tracker_ids_t[np.newaxis, :] == prev_timestep_tracker_id[gt_ids_t[:, np.newaxis]]).astype(float)
        score_mat = 1000.0 * score_mat + similarity
        score_mat[similarity < threshold - np.finfo('float').eps] = 0.0

        match_rows, match_cols = linear_sum_assignment(-score_mat)
        actually_matched = score_mat[match_rows, match_cols] > 0 + np.finfo('float').eps
        match_rows = match_rows[actually_matched]
        match_cols = match_cols[actually_matched]

        matched_gt_ids = gt_ids_t[match_rows]
        matched_tracker_ids = tracker_ids_t[match_cols]

        # IDSW
        prev_matched = prev_tracker_id[matched_gt_ids]
        is_idsw = (~np.isnan(prev_matched)) & (matched_tracker_ids != prev_matched)
        res['IDSW'] += int(np.sum(is_idsw))

        # MT/ML/PT/Frag
        gt_id_count[gt_ids_t] += 1
        gt_matched_count[matched_gt_ids] += 1
        not_previously_tracked = np.isnan(prev_timestep_tracker_id)
        prev_tracker_id[matched_gt_ids] = matched_tracker_ids
        prev_timestep_tracker_id[:] = np.nan
        prev_timestep_tracker_id[matched_gt_ids] = matched_tracker_ids
        currently_tracked = ~np.isnan(prev_timestep_tracker_id)
        gt_frag_count += (not_previously_tracked & currently_tracked).astype(int)

        num_matches = len(matched_gt_ids)
        res['CLR_TP'] += num_matches
        res['CLR_FN'] += len(gt_ids_t) - num_matches
        res['CLR_FP'] += len(tracker_ids_t) - num_matches
        if num_matches > 0:
            res['MOTP_sum'] += float(np.sum(similarity[match_rows, match_cols]))

    # MT/PT/ML/Frag
    tracked_ratio = np.divide(gt_matched_count[gt_id_count > 0], gt_id_count[gt_id_count > 0],
                              where=gt_id_count[gt_id_count > 0] > 0)
    res['MT'] = int(np.sum(tracked_ratio > 0.8))
    res['PT'] = int(np.sum(tracked_ratio >= 0.2)) - res['MT']
    res['ML'] = int(num_gt_ids - res['MT'] - res['PT'])
    res['Frag'] = int(np.sum(np.maximum(gt_frag_count[gt_frag_count > 0] - 1, 0)))

    res['MOTP'] = float(res['MOTP_sum'] / max(1.0, res['CLR_TP']))

    return _compute_clear_final(res)


def _compute_clear_final(res):
    """计算 CLEAR 次级指标"""
    num_gt_ids = res['MT'] + res['ML'] + res['PT']
    res['MTR'] = res['MT'] / max(1.0, num_gt_ids)
    res['MLR'] = res['ML'] / max(1.0, num_gt_ids)
    res['PTR'] = res['PT'] / max(1.0, num_gt_ids)
    res['CLR_Re'] = res['CLR_TP'] / max(1.0, res['CLR_TP'] + res['CLR_FN'])
    res['CLR_Pr'] = res['CLR_TP'] / max(1.0, res['CLR_TP'] + res['CLR_FP'])
    res['MODA'] = (res['CLR_TP'] - res['CLR_FP']) / max(1.0, res['CLR_TP'] + res['CLR_FN'])
    res['MOTA'] = (res['CLR_TP'] - res['CLR_FP'] - res['IDSW']) / max(1.0, res['CLR_TP'] + res['CLR_FN'])
    res['MOTP'] = res.get('MOTP', 0.0)
    res['CLR_F1'] = res['CLR_TP'] / max(1.0, res['CLR_TP'] + 0.5 * res['CLR_FN'] + 0.5 * res['CLR_FP'])
    res['FP_per_frame'] = res['CLR_FP'] / max(1.0, res['CLR_Frames'])
    return res


# ============================================================================
# Identity 评价 (IDF1, IDP, IDR)
# ============================================================================

def evaluate_identity(data, threshold=0.5):
    """计算 Identity 指标 (IDF1, IDP, IDR)

    @param data:      _prepare_mot_data() 返回的 data dict
    @param threshold: 相似度匹配阈值
    @return: dict，包含 IDF1, IDP, IDR, IDTP, IDFN, IDFP
    """
    res = {'IDTP': 0, 'IDFN': 0, 'IDFP': 0}

    if data['num_tracker_dets'] == 0:
        res['IDFN'] = data['num_gt_dets']
        return _compute_identity_final(res)
    if data['num_gt_dets'] == 0:
        res['IDFP'] = data['num_tracker_dets']
        return _compute_identity_final(res)

    potential_matches_count = np.zeros((data['num_gt_ids'], data['num_tracker_ids']))
    gt_id_count = np.zeros(data['num_gt_ids'])
    tracker_id_count = np.zeros(data['num_tracker_ids'])

    num_t = data['num_timesteps']
    for t in range(num_t):
        gt_ids_t = data['gt_ids'][t]
        tracker_ids_t = data['tracker_ids'][t]
        similarity = data['similarity_scores'][t]

        matches_mask = similarity >= threshold
        match_idx_gt, match_idx_tracker = np.nonzero(matches_mask)
        potential_matches_count[gt_ids_t[match_idx_gt], tracker_ids_t[match_idx_tracker]] += 1

        gt_id_count[gt_ids_t] += 1
        tracker_id_count[tracker_ids_t] += 1

    num_gt_ids = data['num_gt_ids']
    num_tracker_ids = data['num_tracker_ids']
    fp_mat = np.zeros((num_gt_ids + num_tracker_ids, num_gt_ids + num_tracker_ids))
    fn_mat = np.zeros((num_gt_ids + num_tracker_ids, num_gt_ids + num_tracker_ids))
    fp_mat[num_gt_ids:, :num_tracker_ids] = 1e10
    fn_mat[:num_gt_ids, num_tracker_ids:] = 1e10
    for gt_id in range(num_gt_ids):
        fn_mat[gt_id, :num_tracker_ids] = gt_id_count[gt_id]
        fn_mat[gt_id, num_tracker_ids + gt_id] = gt_id_count[gt_id]
    for tracker_id in range(num_tracker_ids):
        fp_mat[:num_gt_ids, tracker_id] = tracker_id_count[tracker_id]
        fp_mat[tracker_id + num_gt_ids, tracker_id] = tracker_id_count[tracker_id]
    fn_mat[:num_gt_ids, :num_tracker_ids] -= potential_matches_count
    fp_mat[:num_gt_ids, :num_tracker_ids] -= potential_matches_count

    match_rows, match_cols = linear_sum_assignment(fn_mat + fp_mat)

    res['IDFN'] = int(fn_mat[match_rows, match_cols].sum())
    res['IDFP'] = int(fp_mat[match_rows, match_cols].sum())
    res['IDTP'] = int(gt_id_count.sum() - res['IDFN'])

    return _compute_identity_final(res)


def _compute_identity_final(res):
    """计算 Identity 次级指标"""
    res['IDR'] = res['IDTP'] / max(1.0, res['IDTP'] + res['IDFN'])
    res['IDP'] = res['IDTP'] / max(1.0, res['IDTP'] + res['IDFP'])
    res['IDF1'] = res['IDTP'] / max(1.0, res['IDTP'] + 0.5 * res['IDFP'] + 0.5 * res['IDFN'])
    return res


# ============================================================================
# HOTA 评价
# ============================================================================

def evaluate_hota(data):
    """计算 HOTA 指标

    @param data: _prepare_mot_data() 返回的 data dict
    @return: dict，包含 HOTA, DetA, AssA, DetRe, DetPr, AssRe, AssPr, LocA 等
    """
    array_labels = np.arange(0.05, 0.99, 0.05)  # 19 个 alpha 阈值
    integer_array_fields = ['HOTA_TP', 'HOTA_FN', 'HOTA_FP']
    float_array_fields = ['HOTA', 'DetA', 'AssA', 'DetRe', 'DetPr', 'AssRe', 'AssPr', 'LocA', 'OWTA']
    float_fields = ['HOTA(0)', 'LocA(0)', 'HOTALocA(0)']

    res = {}
    for field in float_array_fields + integer_array_fields:
        res[field] = np.zeros(len(array_labels), dtype=float)
    for field in float_fields:
        res[field] = 0.0

    if data['num_tracker_dets'] == 0:
        res['HOTA_FN'] = data['num_gt_dets'] * np.ones(len(array_labels))
        res['LocA'] = np.ones(len(array_labels))
        res['LocA(0)'] = 1.0
        return _compute_hota_final(res, array_labels, float_array_fields)

    if data['num_gt_dets'] == 0:
        res['HOTA_FP'] = data['num_tracker_dets'] * np.ones(len(array_labels))
        res['LocA'] = np.ones(len(array_labels))
        res['LocA(0)'] = 1.0
        return _compute_hota_final(res, array_labels, float_array_fields)

    potential_matches_count = np.zeros((data['num_gt_ids'], data['num_tracker_ids']))
    gt_id_count = np.zeros((data['num_gt_ids'], 1))
    tracker_id_count = np.zeros((1, data['num_tracker_ids']))

    num_t = data['num_timesteps']
    for t in range(num_t):
        gt_ids_t = data['gt_ids'][t]
        tracker_ids_t = data['tracker_ids'][t]
        similarity = data['similarity_scores'][t]
        sim_iou_denom = similarity.sum(0)[np.newaxis, :] + similarity.sum(1)[:, np.newaxis] - similarity
        sim_iou = np.zeros_like(similarity)
        sim_iou_mask = sim_iou_denom > 0 + np.finfo('float').eps
        sim_iou[sim_iou_mask] = similarity[sim_iou_mask] / sim_iou_denom[sim_iou_mask]
        potential_matches_count[gt_ids_t[:, np.newaxis], tracker_ids_t[np.newaxis, :]] += sim_iou
        gt_id_count[gt_ids_t] += 1
        tracker_id_count[0, tracker_ids_t] += 1

    global_alignment_score = potential_matches_count / (gt_id_count + tracker_id_count - potential_matches_count)
    matches_counts = [np.zeros_like(potential_matches_count) for _ in array_labels]

    for t in range(num_t):
        gt_ids_t = data['gt_ids'][t]
        tracker_ids_t = data['tracker_ids'][t]

        if len(gt_ids_t) == 0:
            for a, _ in enumerate(array_labels):
                res['HOTA_FP'][a] += len(tracker_ids_t)
            continue
        if len(tracker_ids_t) == 0:
            for a, _ in enumerate(array_labels):
                res['HOTA_FN'][a] += len(gt_ids_t)
            continue

        similarity = data['similarity_scores'][t]
        score_mat = global_alignment_score[gt_ids_t[:, np.newaxis], tracker_ids_t[np.newaxis, :]] * similarity

        match_rows, match_cols = linear_sum_assignment(-score_mat)

        for a, alpha in enumerate(array_labels):
            actually_matched = similarity[match_rows, match_cols] >= alpha - np.finfo('float').eps
            alpha_match_rows = match_rows[actually_matched]
            alpha_match_cols = match_cols[actually_matched]
            num_matches = len(alpha_match_rows)
            res['HOTA_TP'][a] += num_matches
            res['HOTA_FN'][a] += len(gt_ids_t) - num_matches
            res['HOTA_FP'][a] += len(tracker_ids_t) - num_matches
            if num_matches > 0:
                res['LocA'][a] += float(np.sum(similarity[alpha_match_rows, alpha_match_cols]))
                matches_counts[a][gt_ids_t[alpha_match_rows], tracker_ids_t[alpha_match_cols]] += 1

    for a, alpha in enumerate(array_labels):
        matches_count = matches_counts[a]
        ass_a = matches_count / np.maximum(1, gt_id_count + tracker_id_count - matches_count)
        res['AssA'][a] = np.sum(matches_count * ass_a) / max(1.0, res['HOTA_TP'][a])
        ass_re = matches_count / np.maximum(1, gt_id_count)
        res['AssRe'][a] = np.sum(matches_count * ass_re) / max(1.0, res['HOTA_TP'][a])
        ass_pr = matches_count / np.maximum(1, tracker_id_count)
        res['AssPr'][a] = np.sum(matches_count * ass_pr) / max(1.0, res['HOTA_TP'][a])

    res['LocA'] = np.maximum(1e-10, res['LocA']) / np.maximum(1e-10, res['HOTA_TP'])

    return _compute_hota_final(res, array_labels, float_array_fields)


def _compute_hota_final(res, array_labels, float_array_fields):
    """计算 HOTA 次级指标"""
    res['DetRe'] = res['HOTA_TP'] / np.maximum(1, res['HOTA_TP'] + res['HOTA_FN'])
    res['DetPr'] = res['HOTA_TP'] / np.maximum(1, res['HOTA_TP'] + res['HOTA_FP'])
    res['DetA'] = res['HOTA_TP'] / np.maximum(1, res['HOTA_TP'] + res['HOTA_FN'] + res['HOTA_FP'])
    res['HOTA'] = np.sqrt(res['DetA'] * res['AssA'])
    res['OWTA'] = np.sqrt(res['DetRe'] * res['AssA'])

    res['HOTA(0)'] = float(res['HOTA'][0])
    res['LocA(0)'] = float(res['LocA'][0])
    res['HOTALocA(0)'] = res['HOTA(0)'] * res['LocA(0)']
    return res


# ============================================================================
# Count 评价（简单计数）
# ============================================================================

def evaluate_count(data):
    """返回检测和 ID 计数

    @param data: _prepare_mot_data() 返回的 data dict
    @return: dict, Dets, GT_Dets, IDs, GT_IDs, Frames
    """
    return {
        'Dets': data['num_tracker_dets'],
        'GT_Dets': data['num_gt_dets'],
        'IDs': data['num_tracker_ids'],
        'GT_IDs': data['num_gt_ids'],
        'Frames': data['num_timesteps'],
    }


# ============================================================================
# 顶层接口：一键评价
# ============================================================================

def evaluate_mot(gt_data, pred_data, threshold=0.5):
    """对一段序列进行 MOT 全指标评价

    @param gt_data:    按帧排列的 gt 列表，每帧 {'ids', 'bboxes', 'classes'}
    @param pred_data:  按帧排列的预测列表，每帧 {'ids', 'bboxes', 'classes', 'scores'}
    @param threshold:  IoU 匹配阈值
    @return: dict，合并了 CLEAR、Identity、HOTA、Count 的标量结果
    """
    data = _prepare_mot_data(gt_data, pred_data)

    clear = evaluate_clear(data, threshold=threshold)
    identity = evaluate_identity(data, threshold=threshold)
    hota = evaluate_hota(data)
    count = evaluate_count(data)

    # 合并结果（只取标量字段）
    result = {}

    # CLEAR
    for k in ['MOTA', 'MOTP', 'MODA', 'CLR_Re', 'CLR_Pr', 'CLR_F1',
              'IDSW', 'MT', 'PT', 'ML', 'MTR', 'PTR', 'MLR', 'Frag',
              'CLR_TP', 'CLR_FN', 'CLR_FP', 'FP_per_frame']:
        if k in clear:
            result[k] = clear[k]

    # Identity
    for k in ['IDF1', 'IDP', 'IDR', 'IDTP', 'IDFN', 'IDFP']:
        if k in identity:
            result[k] = identity[k]

    # HOTA (取 alpha 均值)
    for k in ['HOTA', 'DetA', 'AssA', 'DetRe', 'DetPr', 'AssRe', 'AssPr', 'LocA']:
        if k in hota and isinstance(hota[k], np.ndarray):
            result[k] = float(np.mean(hota[k]))
        elif k in hota:
            result[k] = float(hota[k])
    result['HOTA(0)'] = float(hota.get('HOTA(0)', 0))
    result['LocA(0)'] = float(hota.get('LocA(0)', 0))

    # Count
    result.update({k: count[k] for k in ['Dets', 'GT_Dets', 'IDs', 'GT_IDs', 'Frames']})

    return result
