#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import math
import cv2
import numpy as np
from spirems.msg_helper import def_msg


def draw_text_cv2(
        img: np.ndarray, 
        text: str, 
        lt_pt: list, 
        bg_color: tuple = (0, 0, 0), 
        text_color: tuple = (255, 255, 255)
    ):
    (text_w, text_h), baseline = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    cv2.rectangle(
        img,
        (lt_pt[0], lt_pt[1]),
        (lt_pt[0] + text_w + 2, lt_pt[1] + 17),
        bg_color,
        -1,
        cv2.LINE_AA
    )
    cv2.putText(
        img,
        text,
        (lt_pt[0] + 2, lt_pt[1] + 13),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        text_color,
        1
    )


def draw_xy_cv2(img: np.ndarray, y: dict, dataset: str | dict | None = None, draw_text: bool = False, bbox_style: str = "rect"):  # C, H, W
    c, h, w = img.shape
    assert c == 3 or c == 1, f"img.shape={img.shape}"
    img = np.ascontiguousarray(img.transpose(1, 2, 0))  # H, W, C
    if c == 1:
        img = np.repeat(img, 3, axis=2)  # H, W, 3

    min_siz = min(h, w)
    if min_siz <= 720:
        thickness = 1
    elif 720 < min_siz <= 1280:
        thickness = 1
    else:
        thickness = 2

    if "obj_cls" in y and "bboxes" in y:
        for i, (cl, bb) in enumerate(zip(y["obj_cls"], y["bboxes"])):
            obj_x1, obj_y1 = int((bb[0] - bb[2] / 2) * w), int((bb[1] - bb[3] / 2) * h)
            obj_x2, obj_y2 = int((bb[0] + bb[2] / 2) * w), int((bb[1] + bb[3] / 2) * h)
            obj_w, obj_h = int(bb[2] * w), int(bb[3] * h)
            if bbox_style == "lock":
                lock_len = int(math.ceil(min(obj_w, obj_h) * 0.3))
                """
                cv2.line(img, (obj_x1, obj_y1), (obj_x1 + lock_len, obj_y1), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                cv2.line(img, (obj_x1, obj_y1), (obj_x1, obj_y1 + lock_len), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                cv2.line(img, (obj_x1, obj_y2 - lock_len), (obj_x1, obj_y2), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                cv2.line(img, (obj_x1, obj_y2), (obj_x1 + lock_len, obj_y2), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                cv2.line(img, (obj_x2, obj_y1), (obj_x2 - lock_len, obj_y1), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                cv2.line(img, (obj_x2, obj_y1), (obj_x2, obj_y1 + lock_len), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                cv2.line(img, (obj_x2, obj_y2), (obj_x2, obj_y2 - lock_len), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                cv2.line(img, (obj_x2 - lock_len, obj_y2), (obj_x2, obj_y2), (255, 255, 255), thickness + 1, cv2.LINE_AA)
                """
                cv2.line(img, (obj_x1, obj_y1), (obj_x1 + lock_len, obj_y1), (0, 205, 0), thickness, cv2.LINE_AA)
                cv2.line(img, (obj_x1, obj_y1), (obj_x1, obj_y1 + lock_len), (0, 205, 0), thickness, cv2.LINE_AA)
                cv2.line(img, (obj_x1, obj_y2 - lock_len), (obj_x1, obj_y2), (0, 205, 0), thickness, cv2.LINE_AA)
                cv2.line(img, (obj_x1, obj_y2), (obj_x1 + lock_len, obj_y2), (0, 205, 0), thickness, cv2.LINE_AA)
                cv2.line(img, (obj_x2, obj_y1), (obj_x2 - lock_len, obj_y1), (0, 205, 0), thickness, cv2.LINE_AA)
                cv2.line(img, (obj_x2, obj_y1), (obj_x2, obj_y1 + lock_len), (0, 205, 0), thickness, cv2.LINE_AA)
                cv2.line(img, (obj_x2, obj_y2), (obj_x2, obj_y2 - lock_len), (0, 205, 0), thickness, cv2.LINE_AA)
                cv2.line(img, (obj_x2 - lock_len, obj_y2), (obj_x2, obj_y2), (0, 205, 0), thickness, cv2.LINE_AA)
            else:
                cv2.rectangle(
                    img,
                    (obj_x1, obj_y1),
                    (obj_x2, obj_y2),
                    (0, 0, 255),
                    thickness,
                    cv2.LINE_AA
                )
            if dataset is not None and draw_text:
                if isinstance(dataset, str):
                    dataset = def_msg("dataset_msgs::" + dataset)
                if isinstance(cl, list):
                    cl = cl[0]

                cate_text = dataset["names"][cl]
                if 'tracked_ids' in y:
                    cate_text = str(y['tracked_ids'][i]) + "-" + cate_text

                (text_w, text_h), baseline = cv2.getTextSize(cate_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                if obj_h < 50:  # pixel
                    cv2.rectangle(
                        img,
                        (obj_x1, obj_y1 - 1),
                        (obj_x1 + text_w + 2, obj_y1 - 17),
                        (0, 0, 0),
                        -1,
                        cv2.LINE_AA
                    )
                    cv2.putText(
                        img,
                        cate_text,
                        (obj_x1 + 2, obj_y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        (255, 255, 255),
                        1
                    )
                else:
                    cv2.rectangle(
                        img,
                        (obj_x1, obj_y1 + 1),
                        (obj_x1 + text_w + 2, obj_y1 + 17),
                        (0, 0, 0),
                        -1,
                        cv2.LINE_AA
                    )
                    cv2.putText(
                        img,
                        cate_text,
                        (obj_x1 + 2, obj_y1 + 13),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        (255, 255, 255),
                        1
                    )
    return img


def vis_img_XY(
        msg: dict,
        order: str = "chw",
        mode: str = "stack",
        scale: float = 1.0,
        dataset: str | dict | None = None,
        draw_text: bool = True,
        bbox_style: str = "rect"
    ):
    """
    可视化 spirecv_msgs::XY/XYList 消息
    :param msg: spirecv_msgs::XY/XYList 消息
    :param order: 输入数据的维度顺序，"tchw" 表示 (T, C, H, W), "chw" 表示 (C, H, W)
    :param mode: 可视化模式，"stack" 表示堆叠，"grid" 表示网格
    :param scale: 可视化缩放比例
    :return: np.ndarray, np.float32, BGR, [0, 1], (H, W, 3)
    """
    assert msg["type"] in ["spirecv_msgs::XY", "spirecv_msgs::XYList"]
    assert order in ["tchw", "chw"], f"order={order}"

    if dataset is None and "names" in msg["Y"]:
        dataset = {"names": msg["Y"]["names"]}
    
    if msg["type"] == "spirecv_msgs::XY":
        if order == "tchw":
            t, c, h, w = msg["X"]["img"].shape
            X = msg["X"]["img"].copy()  # np.ndarray, np.float32, BGR, [0, 1], (N, C, H, W)
            Y = msg["Y"]
            vis_img = draw_xy_cv2(X[-1, ...], Y, dataset, draw_text=draw_text, bbox_style=bbox_style)

            if scale != 1.0:
                vis_img = cv2.resize(vis_img, None, fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)
            return vis_img
        elif order == "chw":
            c, h, w = msg["X"]["img"].shape
            X = msg["X"]["img"].copy()  # np.ndarray, np.float32, BGR, [0, 1], (C, H, W)
            Y = msg["Y"]
            vis_img = draw_xy_cv2(X, Y, dataset, draw_text=draw_text, bbox_style=bbox_style)

            if scale != 1.0:
                vis_img = cv2.resize(vis_img, None, fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)
            return vis_img

    elif msg["type"] == "spirecv_msgs::XYList":
        t, c, h, w = msg["X"]["img"].shape
        assert order == "tchw", f"spirecv_msgs::XYList消息目前仅支持tchw格式，order={order}"
        X = msg["X"]["img"].copy()  # np.ndarray, np.float32, BGR, [0, 1], (N, C, H, W)
        Y = msg["Y"]
        assert isinstance(Y, list) and t == len(Y)
        xs = []
        for i, y in enumerate(Y):
            x = draw_xy_cv2(X[i], y, dataset, draw_text=True if (i == len(Y) - 1 and draw_text) or mode == "grid" else False, bbox_style=bbox_style)
            xs.append(x)
        
        if mode == "stack":
            normalized_weight = 1.0 / len(xs)
            vis_img = np.zeros_like(xs[0], dtype=np.float32)
            for x in xs:
                vis_img += x * normalized_weight
        elif mode == "grid":
            grid_size = int(np.ceil(np.sqrt(len(xs))))
            vis_img = np.zeros((grid_size * h, grid_size * w, 3), dtype=np.float32)
            for i, x in enumerate(xs):
                row = i // grid_size
                col = i % grid_size
                # 上边线：从(0, 0) 到 (width-1, 0)
                # cv2.line(x, (0, 0), (w - 1, 0), (1.0, 1.0, 1.0), 1)
                if row < grid_size - 1:
                    # 下边线：从(0, height-1) 到 (width-1, height-1)
                    cv2.line(x, (0, h - 1), (w - 1, h - 1), (1.0, 1.0, 1.0), 1)
                # 左边线：从(0, 0) 到 (0, height-1)
                # cv2.line(x, (0, 0), (0, h - 1), (1.0, 1.0, 1.0), 1)
                if col < grid_size - 1:
                    # 右边线：从(width-1, 0) 到 (width-1, height-1)
                    cv2.line(x, (w - 1, 0), (w - 1, h - 1), (1.0, 1.0, 1.0), 1)
                draw_text_cv2(x, f"Frame {i+1}", (0, 0), bg_color=(0.0, 0.3, 0.0), text_color=(1.0, 1.0, 1.0))
                vis_img[row * h:(row + 1) * h, col * w:(col + 1) * w, :] = x
        else:
            raise ValueError(f"mode={mode}")
        
        if scale != 1.0:
            vis_img = cv2.resize(vis_img, None, fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)
        return vis_img
    return None


def vis_img_batch_XY(
        msg: dict,
        order: str = "chw",
        mode: str = "stack",
        scale: float = 1.0,
        dataset: str | dict | None = None,
        draw_text: bool = True
    ):
    """
    可视化 spirecv_msgs::BatchXY/BatchXYList 消息
    :param msg: spirecv_msgs::BatchXY/BatchXYList 消息
    :param order: 输入数据的维度顺序，"tchw" 表示 (T, C, H, W), "chw" 表示 (C, H, W)
    :param mode: 可视化模式，"stack" 表示堆叠，"grid" 表示网格
    :param scale: 可视化缩放比例
    :return: List[np.ndarray]
    """
    assert msg["type"] in ["spirecv_msgs::BatchXY", "spirecv_msgs::BatchXYList"]
    if msg["type"] == "spirecv_msgs::BatchXY":
        BX = msg["batch"]
        vis_imgs = []
        for i, X in enumerate(BX):
            vis_img = vis_img_XY(
                X,
                order=order,
                mode=mode,
                scale=scale,
                dataset=dataset,
                draw_text=draw_text,
            )
            vis_imgs.append(vis_img)
    elif msg["type"] == "spirecv_msgs::BatchXYList":
        BX = msg["batch"]
        vis_imgs = []
        for i, X in enumerate(BX):
            vis_img = vis_img_XY(
                X,
                order=order,
                mode=mode,
                scale=scale,
                dataset=dataset,
                draw_text=draw_text,
            )
            vis_imgs.append(vis_img)
    return vis_imgs
