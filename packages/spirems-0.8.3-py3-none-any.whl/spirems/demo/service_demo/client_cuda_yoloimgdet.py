from spirems import Client, def_msg, cvimg2sms, sms2cvimg
import time
import sys
import cv2


cc = Client('/cuda/yoloimgdet', 'sensor_msgs::CompressedImage', 'sensor_msgs::CompressedImage')

img = cv2.imread("/home/jario/001.jpg")
if img is None:
    print(f"无法读取图片: {args.img}", file=sys.stderr)
    sys.exit(1)

smsmsg = cvimg2sms(img)
resimg = cc.request_once(smsmsg, timeout=10)
resimg = sms2cvimg(resimg)

out = "/home/jario/003.jpg"
cv2.imwrite(out, resimg)
print(f"检测完成，结果已保存: {out}")
