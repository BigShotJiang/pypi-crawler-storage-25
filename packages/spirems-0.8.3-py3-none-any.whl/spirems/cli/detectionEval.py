
import argparse
import sys
import os
import json
import time
from pathlib import Path
import cv2
import glob
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')  # 非交互式后端，避免 display 错误
import matplotlib.pyplot as plt
import numpy as np
from spirems.mod_helper import download_model
from spirems.utils.xy_tools import yolo_format_to_XY
from spirems.utils.vis_tools import vis_img_XY
from spirems import Client, def_msg, cvimg2sms, sms2cvimg, cvimg2sms_mem, cvimg2sms_mem_cleanup
from spirems.msg_helper import print_table
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

APP_DESCRIPTION = "基于COCO数据集的YOLO检测服务评估脚本，支持读取.json标注并对服务进行评测"


def load_coco_dataset(data_root, coco_gt_file=None):
    if coco_gt_file is None:
        json_files = [os.path.basename(f) for f in glob.glob(os.path.join(data_root, '*')) if f.endswith('.json')]
        assert len(json_files) > 0, "COCO格式数据集路径 [{}] 中未发现 .json 文件".format(data_root)
        sorted_json_files = sorted(json_files, key=os.path.basename, reverse=True)
        coco_gt_file = os.path.join(data_root, sorted_json_files[0])

    annotation_file = coco_gt_file
    tic = time.time()
    with open(annotation_file, 'r') as f:
        dataset = json.load(f)
    assert isinstance(dataset, dict), '数据集读取失败，{} 不支持'.format(type(dataset))
    print('数据集读取完成 (t={:0.2f}s)'.format(time.time() - tic))

    # 创建索引
    print('创建索引...')
    anns, cats, imgs = {}, {}, {}
    imgToAnns, catToImgs = defaultdict(list), defaultdict(list)
    if 'annotations' in dataset:
        for ann in dataset['annotations']:
            imgToAnns[ann['image_id']].append(ann)
            anns[ann['id']] = ann

    if 'images' in dataset:
        for img in dataset['images']:
            imgs[img['id']] = img

    if 'categories' in dataset:
        for cat in dataset['categories']:
            cats[cat['id']] = cat

    if 'annotations' in dataset and 'categories' in dataset:
        for ann in dataset['annotations']:
            catToImgs[ann['category_id']].append(ann['image_id'])

    print('索引创建完成!')
    category_name_to_cat_id = {v['name'].replace(" ", "_"): v['id'] for k, v in cats.items()}
    file_name_to_img_id = {os.path.basename(v['file_name']): v['id'] for k, v in imgs.items()}
    return {
        "anns": anns,
        "imgs": imgs,
        "cats": cats,
        "img_to_anns": imgToAnns,
        "cat_to_imgs": catToImgs,
        "img_keys": list(imgs.keys()),
        "gt_file": coco_gt_file,
        "category_name_to_cat_id": category_name_to_cat_id,
        "file_name_to_img_id": file_name_to_img_id
    }


def get_per_class_results(coco_gt, coco_eval):
    """获取单个类别的精度数据（AP, AP50, AP75）

    @param coco_gt:  COCO ground truth 对象
    @param coco_eval: 已完成 evaluate() 和 accumulate() 的 COCOeval 对象
    @return: (headers, rows) 表头和行数据列表，无类别时返回 (None, None)
    """
    prec = coco_eval.eval['precision']  # shape: [T=10, R=101, K, A=4, M=3]
    cat_ids = coco_eval.params.catIds
    if not cat_ids:
        return None, None

    cat_id_to_name = {cat['id']: cat['name'] for cat in coco_gt.loadCats(cat_ids)}

    headers = ['Class', 'AP', 'AP50', 'AP75', 'Num GT']
    rows = []
    for k, cat_id in enumerate(cat_ids):
        cat_name = cat_id_to_name.get(cat_id, str(cat_id))
        # AP (IoU=0.50:0.95, area=all, maxDets=100): prec[:, :, k, 0, -1]
        ap_all = prec[:, :, k, 0, -1]
        ap_all = ap_all[ap_all > -1]
        ap = round(float(ap_all.mean()) * 100, 1) if len(ap_all) > 0 else 0.0

        # AP50 (IoU=0.50, area=all, maxDets=100): prec[0, :, k, 0, -1]
        ap50_data = prec[0, :, k, 0, -1]
        ap50_data = ap50_data[ap50_data > -1]
        ap50 = round(float(ap50_data.mean()) * 100, 1) if len(ap50_data) > 0 else 0.0

        # AP75 (IoU=0.75, area=all, maxDets=100): prec[5, :, k, 0, -1]
        ap75_data = prec[5, :, k, 0, -1]
        ap75_data = ap75_data[ap75_data > -1]
        ap75 = round(float(ap75_data.mean()) * 100, 1) if len(ap75_data) > 0 else 0.0

        # 统计该类别标注数量
        ann_ids = coco_gt.getAnnIds(catIds=[cat_id])
        num_gt = len(ann_ids)

        rows.append([cat_name, ap, ap50, ap75, num_gt])

    return headers, rows


def compute_per_class_pr_f1(coco_eval, k_idx, iou_idx=0):
    """计算单个类别在指定IoU阈值下的Precision-Recall曲线和最佳F1-Score

    基于COCOeval的precision数组 (shape: [T=10, R=101, K, A=4, M=3])，
    取 IoU=iou_idx, area=all(0), maxDets=100(-1) 对应的precision曲线，
    与recThrs组成PR点，计算每个点的F1并取最大值。

    @param coco_eval: 已完成 evaluate() 和 accumulate() 的 COCOeval 对象
    @param k_idx:      类别在precision数组中的索引
    @param iou_idx:    IoU阈值索引，0对应IoU=0.50（AP50）
    @return: (recall_valid, precision_valid, best_f1, best_precision, best_recall)
             若无有效检测则返回 None
    """
    prec = coco_eval.eval['precision']          # [T, R, K, A, M]
    recall_thrs = coco_eval.params.recThrs       # 101个recall点, 0.0 ~ 1.0

    # IoU=iou_idx, area=all, maxDets=100
    precision_curve = prec[iou_idx, :, k_idx, 0, -1]
    recall_curve = recall_thrs

    # 过滤无效值 (precision == -1 表示该recall点无数据)
    valid_mask = precision_curve > -1
    if not np.any(valid_mask):
        return None

    precision_valid = precision_curve[valid_mask]
    recall_valid = recall_curve[valid_mask]

    # 逐点计算 F1 = 2 * P * R / (P + R)
    f1_scores = np.zeros_like(precision_valid)
    for i in range(len(precision_valid)):
        p = float(precision_valid[i])
        r = float(recall_valid[i])
        if p + r > 0:
            f1_scores[i] = 2.0 * p * r / (p + r)
        else:
            f1_scores[i] = 0.0

    best_idx = int(np.argmax(f1_scores))
    best_f1 = float(f1_scores[best_idx])
    best_precision = float(precision_valid[best_idx])
    best_recall = float(recall_valid[best_idx])

    return recall_valid, precision_valid, best_f1, best_precision, best_recall


def plot_pr_curve(recall, precision, cat_name, dataset_name, save_dir='.'):
    """绘制PR曲线并保存为PNG

    @param recall:       recall数组 (numpy array)
    @param precision:    precision数组 (numpy array)
    @param cat_name:     类别名称
    @param dataset_name: 数据集名称
    @param save_dir:     图片保存目录，默认为当前目录
    """
    plt.figure(figsize=(8, 6))
    plt.plot(recall, precision, 'b-', linewidth=2)
    plt.xlabel('Recall', fontsize=14)
    plt.ylabel('Precision', fontsize=14)
    plt.title(f'PR Curve - {dataset_name} / {cat_name} (IoU=0.5)', fontsize=14)
    plt.xlim(0.0, 1.0)
    plt.ylim(0.0, 1.05)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()

    save_path = os.path.join(save_dir, f'{dataset_name}_{cat_name}.png')
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f'  PR曲线已保存: {save_path}')


def print_per_class_results(coco_gt, coco_eval):
    """打印单个类别的精度（AP, AP50, AP75）

    @param coco_gt:  COCO ground truth 对象
    @param coco_eval: 已完成 evaluate() 和 accumulate() 的 COCOeval 对象
    """
    headers, rows = get_per_class_results(coco_gt, coco_eval)
    if headers is None:
        print('没有可用的类别进行评估')
        return
    print('--- Per-Class Results ---')
    print_table([headers] + rows)


def main():
    parser = argparse.ArgumentParser(description="YOLO目标检测（支持.pt模型，支持sms::自动下载）")
    parser.add_argument('--service', type=str, required=True, help='检测器服务话题，如/service/yolo_detector')
    parser.add_argument('--data', type=str, required=True, help='COCO格式数据集路径，目录下应包含.json文件')
    parser.add_argument('--ip', type=str, default='127.0.0.1', help='检测器服务IP地址')
    parser.add_argument('--port', type=int, default=9094, help='检测器服务端口号')
    args = parser.parse_args()

    # 基本检查：service 以 '/' 开头
    if not args.service.startswith('/'):
        print('错误: --service 必须以 "/" 开头，例如/service/yolo_detector')
        sys.exit(1)

    # 基本检查：ip 格式
    import socket
    try:
        socket.inet_aton(args.ip)
    except Exception:
        print(f'错误: --ip 格式非法: {args.ip}')
        sys.exit(1)

    # 基本检查：端口范围
    if args.port <= 0 or args.port > 65535:
        print(f'错误: --port 必须在 1-65535 范围内: {args.port}')
        sys.exit(1)

    # 打印各输入参数，参数名绿色高亮
    GREEN = '\033[32m'
    RESET = '\033[0m'
    print('====== detectionEval 参数 ======')
    for k, v in vars(args).items():
        print(f'{GREEN}{k}{RESET}: {v}')
    print('================================')

    if ',' in args.data:
        data = args.data.split(',')
    elif ';' in args.data:
        data = args.data.split(';')
    else:
        data = [args.data]

    # 将 ~ 展开为绝对路径
    data = [os.path.expanduser(data_root) if data_root.startswith('~') else data_root for data_root in data]

    for data_root in data:
        # 基本检查：data 路径存在并包含 .json 文件
        data_path = Path(data_root)
        if not data_path.exists():
            print(f'错误: --data 路径不存在: {data_root}')
            sys.exit(1)
        if not data_path.is_dir():
            print(f'错误: --data 必须是目录路径: {data_root}')
            sys.exit(1)
        json_files = list(data_path.glob('*.json'))
        if not json_files:
            print(f'警告: --data 目录中未发现 .json 文件: {data_root}')

    results = []
    for data_root in data:
        # 读取数据集
        coco = load_coco_dataset(data_root)

        assembled_results = []
        cc = Client(args.service, 'std_msgs::Null', 'spirecv_msgs::2DTargets', ip=args.ip, port=args.port)

        # 遍历数据集，带进度条
        try:
            from tqdm import tqdm
            iterator = tqdm(coco['img_keys'], desc='检测图像', ncols=80)
        except ImportError:
            iterator = coco['img_keys']

        for i, key in enumerate(iterator):
            img_info = coco['imgs'][key]
            img_path = os.path.join(data_root, img_info['file_name'])

            # 本机使用共享内存传输图像，非本机使用常规方式
            img = cv2.imread(img_path)
            if args.ip == '127.0.0.1':
                smsmsg = cvimg2sms_mem(img, "detection_eval_shm")
            else:
                smsmsg = cvimg2sms(img)

            req_i = 0
            while req_i < 3:
                req_i += 1
                smsmsg['conf'] = 0.001
                smsmsg['iou'] = 0.45
                res = cc.request(smsmsg)
                if res:
                    break
                else:
                    time.sleep(0.1)

            if req_i >= 3:
                print(f'警告: 未收到检测器响应，尝试 {req_i} 次')
                res['targets'] = []
            else:
                # 检测器类别与测试集类别匹配
                res['targets'] = [ann for ann in res['targets'] if ann['category_name'] in coco['category_name_to_cat_id']]

            assembled_results.extend(
                [
                    {
                        "image_id": key,
                        "category_id": coco['category_name_to_cat_id'][ann['category_name']],
                        "bbox": ann['bbox'],
                        "score": ann['score'],
                    }
                    for k, ann in enumerate(res['targets'])
                ]
            )

        cc.kill()
        if args.ip == '127.0.0.1':
            cvimg2sms_mem_cleanup("detection_eval_shm")
        coco_dt = os.path.join('/tmp', 'detections.json')
        with open(coco_dt, "w") as f:
            json.dump(assembled_results, f)

        coco_gt = COCO(coco['gt_file'])
        coco_dt = coco_gt.loadRes(coco_dt)
        coco_eval = COCOeval(coco_gt, coco_dt, "bbox")
        coco_eval.evaluate()
        coco_eval.accumulate()
        coco_eval.summarize()
        print_per_class_results(coco_gt, coco_eval)

        # ---- 逐类别计算 Precision / Recall / F1-Score (IoU=0.5) ----
        cat_ids = coco_eval.params.catIds
        cat_id_to_name = {cat['id']: cat['name'] for cat in coco_gt.loadCats(cat_ids)}
        dataset_name = os.path.basename(data_root.rstrip('/'))
        print('--- Per-Class Precision/Recall/F1 (IoU=0.5) ---')
        per_class_pr_f1 = []  # [(cat_name, best_f1, best_p, best_r), ...]
        for k, cat_id in enumerate(cat_ids):
            cat_name = cat_id_to_name.get(cat_id, str(cat_id))
            result = compute_per_class_pr_f1(coco_eval, k, iou_idx=0)
            if result is None:
                print(f'  {cat_name}: 无有效检测结果，跳过')
                continue
            recall, precision, best_f1, best_p, best_r = result
            print(f'  {cat_name}: Best F1={best_f1:.4f} @ Precision={best_p:.4f}, Recall={best_r:.4f}')
            per_class_pr_f1.append((cat_name, best_f1, best_p, best_r))
            plot_pr_curve(recall, precision, cat_name, dataset_name, save_dir=os.getcwd())
        print()

        stats_msgs = def_msg("spirecv_msgs::EvaluationResult")
        stats_msgs["metrics"] = ["mAP", "mAP50", "mAP75", "APs", "APm", "APl"]
        stats_msgs["results"] = [round(float(v) * 100, 1) if v > 0 else round(float(v), 1) for v in coco_eval.stats.tolist()[:6]]
        per_class_headers, per_class_rows = get_per_class_results(coco_gt, coco_eval)
        results.append((data_root, stats_msgs, per_class_headers, per_class_rows, per_class_pr_f1))

    for data_root, stats_msgs, per_class_headers, per_class_rows, per_class_pr_f1 in results:
        print(f'====== {data_root} ======')
        print_table([stats_msgs["metrics"], stats_msgs["results"]])
        if per_class_headers is not None and per_class_rows:
            print('--- Per-Class Results ---')
            print_table([per_class_headers] + per_class_rows)
        if per_class_pr_f1:
            pr_f1_headers = ['Class', 'Best F1', 'Precision', 'Recall']
            pr_f1_rows = [[name, round(f1, 3), round(p, 3), round(r, 3)] for name, f1, p, r in per_class_pr_f1]
            print('--- Per-Class Best F1 (IoU=0.5) ---')
            print_table([pr_f1_headers] + pr_f1_rows)
            print()


if __name__ == "__main__":
    main()
