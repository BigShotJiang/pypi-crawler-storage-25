"""
VisDrone MOT 序列标注格式转换为 SpireView 标注格式的转换工具

输入格式（VisDrone MOT）：
    - sequences/ 下每个子文件夹为一个视频序列，内含按帧索引命名的图像
    - annotations/ 下每个 .txt 对应一个序列，每行格式：
      <frame_index>,<target_id>,<bbox_left>,<bbox_top>,<bbox_width>,<bbox_height>,
      <score>,<object_category>,<truncation>,<occlusion>

    frame_index:  帧索引（从1开始）
    target_id:    跟踪目标 ID（GT 中提供跨帧对应关系）
    bbox_left/top/width/height: 边界框（左上角坐标 + 宽高）
    score:        GT 中 1=参与评估, 0=忽略
    object_category: 0=ignored, 1=pedestrian, 2=people, 3=bicycle, 4=car,
                      5=van, 6=truck, 7=tricycle, 8=awning-tricycle,
                      9=bus, 10=motor, 11=others
    truncation:   截断程度（0/1）
    occlusion:    遮挡程度（0/1/2）

输出格式（SpireView）：
    output_dir/
      seq_A/
        scaled_images/
          frame_0000001.jpg
        annotations/
          frame_0000001.json   # {file_name, height, width, annos: [{category_name, bbox, area, tracked_id, ...}]}

用法：
    smscli convertSeqtxt2Scv --seq-dir ~/VisDrone2019-MOT-val/sequences \
                             --txt-dir ~/VisDrone2019-MOT-val/annotations \
                             --output-dir ~/spire_mot_output
"""
import argparse
import sys
import os
import json
import shutil
from pathlib import Path
from collections import defaultdict
import cv2


APP_DESCRIPTION = "VisDrone MOT序列标注转SpireView格式工具"

# VisDrone 类别 ID → 名称映射
VISDRONE_CLASSES = {
    0: 'ignored_region',
    1: 'pedestrian',
    2: 'people',
    3: 'bicycle',
    4: 'car',
    5: 'van',
    6: 'truck',
    7: 'tricycle',
    8: 'awning_tricycle',
    9: 'bus',
    10: 'motor',
    11: 'others',
}


def parse_txt_annotations(txt_path):
    """解析单个序列的 VisDrone txt 标注文件

    @param txt_path: .txt 标注文件路径
    @return: dict {frame_index: [anno_dict, ...]}, 按帧索引分组
    """
    frame_annos = defaultdict(list)

    with open(txt_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            parts = line.split(',')
            if len(parts) < 9:
                continue

            frame_idx = int(parts[0])
            target_id = int(parts[1])
            bbox_left = float(parts[2])
            bbox_top = float(parts[3])
            bbox_width = float(parts[4])
            bbox_height = float(parts[5])
            score = float(parts[6])
            category = int(parts[7])
            truncation = int(parts[8]) if len(parts) > 8 else 0
            occlusion = int(parts[9]) if len(parts) > 9 else 0

            # 跳过忽略区域和标注为忽略的框
            if category == 0 or score == 0:
                continue

            frame_annos[frame_idx].append({
                'target_id': target_id,
                'bbox': [bbox_left, bbox_top, bbox_width, bbox_height],
                'category': category,
                'truncation': truncation,
                'occlusion': occlusion,
            })

    return dict(frame_annos)


def convert_sequence(seq_dir, txt_path, seq_output_dir, copy_images):
    """将一个序列的图像和标注转换为 SpireView 格式

    @param seq_dir:         序列图像目录
    @param txt_path:        序列标注 .txt 文件路径
    @param seq_output_dir:  该序列的 SpireView 输出目录
    @param copy_images:     是否复制图像
    @return: (converted, skipped) 计数
    """
    # 解析标注
    frame_annos = parse_txt_annotations(txt_path)
    if not frame_annos:
        print(f'  警告: 标注文件无有效数据: {txt_path}')
        return 0, 0

    # 查找图像文件
    img_extensions = {'.jpg', '.jpeg', '.png', '.bmp'}
    img_files = {}
    for f in sorted(seq_dir.iterdir()):
        if f.is_file() and f.suffix.lower() in img_extensions:
            img_files[f.stem] = f  # stem: "0000001"

    # 尝试按数字索引匹配：文件名如 0000001.jpg, img000001.jpg 等
    # 构建从 frame_index 到图像路径的映射
    frame_to_img = {}
    if img_files:
        # 策略1：文件名恰好是 frame_index 的零填充格式
        for fname, fpath in img_files.items():
            try:
                fidx = int(fname)
                frame_to_img[fidx] = fpath
            except ValueError:
                pass

        # 策略2：按排序位置匹配（若策略1未匹配到任何帧）
        if not frame_to_img:
            sorted_imgs = sorted(img_files.values())
            for i, fpath in enumerate(sorted_imgs):
                frame_to_img[i + 1] = fpath  # frame_index 从1开始

    if not frame_to_img:
        print(f'  警告: 序列目录中未找到图像: {seq_dir}')
        return 0, 0

    # 创建输出子目录
    images_out = seq_output_dir / 'scaled_images'
    annos_out = seq_output_dir / 'annotations'
    os.makedirs(images_out, exist_ok=True)
    os.makedirs(annos_out, exist_ok=True)

    converted = 0
    skipped = 0

    # 遍历所有有标注的帧
    max_frame_idx = max(frame_annos.keys())
    all_frame_indices = sorted(frame_annos.keys())

    for frame_idx in all_frame_indices:
        annos = frame_annos[frame_idx]
        img_path = frame_to_img.get(frame_idx)

        if img_path is None:
            skipped += 1
            continue

        # 读取图像尺寸
        img = cv2.imread(str(img_path))
        if img is None:
            skipped += 1
            continue
        height, width = img.shape[:2]

        # 构建 SpireView 标注
        spire_annos = []
        for a in annos:
            x, y, w, h = a['bbox']
            category_name = VISDRONE_CLASSES.get(a['category'], 'unknown')

            anno = {
                'category_name': category_name,
                'bbox': [round(x, 2), round(y, 2), round(w, 2), round(h, 2)],
                'area': round(w * h, 2),
                'tracked_id': int(a['target_id']),
            }
            if a['truncation'] != 0 or a['occlusion'] != 0:
                anno['obj_attrs'] = {
                    'truncation': int(a['truncation']),
                    'occlusion': int(a['occlusion']),
                }
            spire_annos.append(anno)

        if not spire_annos:
            skipped += 1
            continue

        # 输出文件名：序列名_帧号零填充
        # 获取序列名（从输出目录路径提取）
        seq_name = seq_output_dir.name
        # 帧号零填充宽度：根据最大帧索引自动计算
        max_idx = max(frame_annos.keys())
        zfill_width = max(len(str(max_idx)), 7)
        new_stem = f'{seq_name}_{str(frame_idx).zfill(zfill_width)}'
        new_img_name = new_stem + img_path.suffix
        new_json_name = new_img_name + '.json'

        spire = {
            'file_name': new_img_name,
            'height': height,
            'width': width,
            'annos': spire_annos,
        }

        # 写入 SpireView JSON（命名：序列名_帧号.json）
        out_json = annos_out / new_json_name
        with open(out_json, 'w') as f:
            json.dump(spire, f, ensure_ascii=False)

        # 复制图像（命名：序列名_帧号.jpg）
        if copy_images:
            dst_img = images_out / new_img_name
            shutil.copy2(img_path, dst_img)

        converted += 1

    return converted, skipped


def main():
    parser = argparse.ArgumentParser(description="VisDrone MOT序列标注转SpireView标注")
    parser.add_argument('--seq-dir', type=str, required=True,
                        help='图像序列父目录（内含每个序列的子文件夹，如 sequences/）')
    parser.add_argument('--txt-dir', type=str, required=True,
                        help='txt标注目录（内含每个序列的 .txt 文件，如 annotations/）')
    parser.add_argument('--output-dir', type=str, required=True,
                        help='SpireView 格式输出目录')
    parser.add_argument('--copy-images', action='store_true', default=True,
                        help='复制图像到输出目录（默认开启）')
    parser.add_argument('--no-copy-images', action='store_false', dest='copy_images',
                        help='不复制图像')
    args = parser.parse_args()

    seq_dir = Path(args.seq_dir)
    txt_dir = Path(args.txt_dir)
    output_dir = Path(args.output_dir)

    if not seq_dir.exists() or not seq_dir.is_dir():
        print(f'错误: 序列目录不存在: {args.seq_dir}', file=sys.stderr)
        sys.exit(1)
    if not txt_dir.exists() or not txt_dir.is_dir():
        print(f'错误: txt标注目录不存在: {args.txt_dir}', file=sys.stderr)
        sys.exit(1)

    # 查找序列子文件夹
    seq_subdirs = sorted([d for d in seq_dir.iterdir() if d.is_dir()])
    if not seq_subdirs:
        print(f'错误: {args.seq_dir} 中未找到序列子文件夹', file=sys.stderr)
        sys.exit(1)

    # 查找 .txt 标注文件
    txt_files = {f.stem: f for f in sorted(txt_dir.glob('*.txt'))}
    if not txt_files:
        print(f'错误: {args.txt_dir} 中未找到 .txt 文件', file=sys.stderr)
        sys.exit(1)

    print(f'找到 {len(seq_subdirs)} 个序列目录, {len(txt_files)} 个标注文件')

    # 匹配序列与标注文件
    total_converted = 0
    total_skipped = 0
    matched = 0
    unmatched = 0

    for subdir in seq_subdirs:
        seq_name = subdir.name

        # 尝试匹配同名的 .txt 文件
        txt_path = txt_files.get(seq_name)
        if txt_path is None:
            # 尝试模糊匹配：部分名称匹配
            for tname, tpath in txt_files.items():
                if seq_name in tname or tname in seq_name:
                    txt_path = tpath
                    break

        if txt_path is None:
            print(f'  跳过 {seq_name}: 未找到匹配的标注文件')
            unmatched += 1
            continue

        print(f'\n处理序列: {seq_name}')
        seq_output_dir = output_dir / seq_name
        conv, skip = convert_sequence(subdir, str(txt_path), seq_output_dir, args.copy_images)
        total_converted += conv
        total_skipped += skip
        matched += 1
        print(f'  完成: {conv} 帧, 跳过 {skip} 帧')

    # 统计
    print(f'\n{"="*50}')
    print(f'转换完成:')
    print(f'  序列数: {matched} 个成功, {unmatched} 个未匹配')
    print(f'  帧数: {total_converted} 个成功, {total_skipped} 个跳过')
    print(f'  输出目录: {output_dir}')


if __name__ == '__main__':
    main()
