
import argparse
import sys
from pathlib import Path
import cv2
from tqdm import tqdm
import numpy as np
from typing import List, Dict, Tuple
from spirems.mod_helper import download_model
from spirems.utils.xy_tools import yolo_format_to_XY
from spirems.utils.vis_tools import vis_img_XY
from spirems.utils.label_tools import bbox_iou_matrix_xywh

APP_DESCRIPTION = "基于YOLO的图片/视频检测与目标跟踪脚本，支持.pt模型与 sms:: 模型自动下载"

tracker_name = "nanotrack"

if tracker_name == "nanotrack":
    nanotrack_backbone_sim = download_model("SingleObjectTrackerNode", "nanotrack_backbone_sim.onnx")
    nanotrack_head_sim = download_model("SingleObjectTrackerNode", "nanotrack_head_sim.onnx")
    nanotrack_params = cv2.TrackerNano_Params()
    nanotrack_params.backbone = nanotrack_backbone_sim
    nanotrack_params.neckhead = nanotrack_head_sim
    nanotrack_params.backend = cv2.dnn.DNN_BACKEND_OPENCV
    nanotrack_params.target = cv2.dnn.DNN_TARGET_CPU

if tracker_name == "dasiamrpn":
    dasiamrpn_model = download_model("SingleObjectTrackerNode", "dasiamrpn_model.onnx")
    dasiamrpn_kernel_cls1 = download_model("SingleObjectTrackerNode", "dasiamrpn_kernel_cls1.onnx")
    dasiamrpn_kernel_r1 = download_model("SingleObjectTrackerNode", "dasiamrpn_kernel_r1.onnx")
    dasiamrpn_params = cv2.TrackerDaSiamRPN_Params()
    dasiamrpn_params.model = dasiamrpn_model
    dasiamrpn_params.kernel_cls1 = dasiamrpn_kernel_cls1
    dasiamrpn_params.kernel_r1 = dasiamrpn_kernel_r1
    dasiamrpn_params.backend = cv2.dnn.DNN_BACKEND_OPENCV
    dasiamrpn_params.target = cv2.dnn.DNN_TARGET_CPU


class TrackWrapper:
    def __init__(self, init_bbox: Tuple[float, float, float, float], obj_id: int, cate: int = -1, lock_step: int = 10):
        self.id = obj_id
        self.bbox = init_bbox
        self.cate = cate
        self.lock_step = lock_step
        self.lost = 0
        self.age = 0

    def init(self, img: np.ndarray, bbox: Tuple[float, float, float, float]):
        self.bbox = bbox
        self.lost = 0
        self.age += 1
        if tracker_name == "nanotrack":
            self.tracker = cv2.TrackerNano_create(nanotrack_params)
        elif tracker_name == "dasiamrpn":
            self.tracker = cv2.TrackerDaSiamRPN_create(dasiamrpn_params)
        else:
            self.tracker = cv2.TrackerKCF_create()
        self.tracker.init(img, tuple(int(x) for x in self.bbox))

    def update(self, img: np.ndarray):
        success, bbox = self.tracker.update(img)
        self.bbox = bbox
        return self.bbox

    def predict(self):
        self.lost += 1
        self.age += 1
        if self.age > self.lock_step:
            return self.bbox
        return None


class MultiObjectTracker:
    def __init__(self, iou_threshold: float = 0.1, max_lost: int = 10, lock_step: int = 10):
        self.trackers: Dict[int, TrackWrapper] = {}
        self.next_id = 1
        self.iou_threshold = iou_threshold
        self.max_lost = max_lost
        self.lock_step = lock_step

    def update(self, img: np.ndarray, detections: List):
        """
        更新跟踪器
        detections: List of (x, y, w, h, c) 检测框列表, c表示检测类别（可选）
        返回: List of (x, y, w, h, c, id) 更新后的检测框列表，包含跟踪ID
        """
        det_boxes = np.array([det[:4] for det in detections], dtype=float) if len(detections) > 0 else np.zeros((0, 4), dtype=float)
        trk_boxes = []
        for tid, trk in self.trackers.items():
            trk_boxes.append(trk.update(img))
        trk_boxes = np.array(trk_boxes, dtype=float) if len(trk_boxes) > 0 else np.zeros((0, 4), dtype=float)

        assigned = {}
        if len(trk_boxes) > 0 and len(det_boxes) > 0:
            # 计算跟踪框与检测框的IoU矩阵，贪心匹配
            iou_matrix = bbox_iou_matrix_xywh(trk_boxes, det_boxes)
            tracker_ids = list(self.trackers.keys())

            for _ in range(min(trk_boxes.shape[0], det_boxes.shape[0])):
                i, j = np.unravel_index(np.argmax(iou_matrix), iou_matrix.shape)
                i, j = int(i), int(j)
                if iou_matrix[i, j] < self.iou_threshold:
                    break
                tid = tracker_ids[i]
                assigned[tid] = j
                iou_matrix[i, :] = -1
                iou_matrix[:, j] = -1

        # 更新已分配跟踪器
        used_det = set()
        for tid, det_idx in assigned.items():
            self.trackers[tid].init(img, det_boxes[det_idx])
            detections[det_idx].append(tid)
            used_det.add(det_idx)

        # 预测未匹配跟踪器
        to_delete = []
        tracked_detections = []
        for tid, trk in self.trackers.items():
            if tid in assigned:
                continue
            prd_box = trk.predict()
            if trk.lost > self.max_lost:
                to_delete.append(tid)
            elif prd_box is not None:
                prd_box = list(prd_box)
                if trk.cate >= 0:
                    prd_box.append(trk.cate)
                prd_box.append(tid)
                tracked_detections.append(prd_box)

        # 新检测生成跟踪器（未匹配）
        for k, det in enumerate(detections):
            if k in used_det:
                continue
            if len(det) > 4:
                self.trackers[self.next_id] = TrackWrapper(det, self.next_id, det[4], self.lock_step)
                self.trackers[self.next_id].init(img, det[:4])
            else:
                self.trackers[self.next_id] = TrackWrapper(det, self.next_id, -1, self.lock_step)
                self.trackers[self.next_id].init(img, det)
            detections[k].append(self.next_id)
            self.next_id += 1

        detections.extend(tracked_detections)
        for tid in to_delete:
            del self.trackers[tid]

        return detections

    def get_tracks(self):
        return [{'id': tid, 'bbox': trk.bbox.copy(), 'lost': trk.lost, 'age': trk.age}
                for tid, trk in self.trackers.items()]


def main():
    parser = argparse.ArgumentParser(description="YOLO目标检测（支持.pt模型，支持sms::自动下载，支持图片/视频）")
    parser.add_argument('--model', type=str, required=True, help='YOLO pt模型路径或sms::模型名')
    parser.add_argument('--src', type=str, required=True, help='待检测图像或视频路径')
    parser.add_argument('--out', type=str, required=True, help='检测结果输出文件路径（图片jpg/png或视频avi/mp4）')
    parser.add_argument('--conf', type=float, default=0.25, help='置信度阈值')
    parser.add_argument('--iou', type=float, default=0.45, help='非极大抑制IoU阈值')
    args = parser.parse_args()

    # 动态导入ultralytics（YOLOv8/YOLOv6/YOLOv5均可用）
    try:
        from ultralytics import YOLO
    except ImportError:
        print("请先安装ultralytics库: pip install ultralytics", file=sys.stderr)
        sys.exit(1)

    src_path = Path(args.src)
    if not src_path.exists():
        print(f"输入文件不存在: {src_path}", file=sys.stderr)
        sys.exit(1)

    node_name = "YOLOv11DetNode_Cuda"
    model_path = download_model(node_name, args.model)
    model = YOLO(model_path)

    is_video = src_path.suffix.lower() in ['.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv']

    if not is_video:
        # 处理单张图片
        img = cv2.imread(str(src_path))
        if img is None:
            print(f"无法读取图片: {src_path}", file=sys.stderr)
            sys.exit(1)

        results = model(str(src_path), conf=args.conf, iou=args.iou, verbose=False, end2end=False)
        smsmsg = yolo_format_to_XY(results)
        res_img = vis_img_XY(smsmsg)
        cv2.imwrite(str(args.out), res_img)
        print(f"图片检测完成，结果已保存: {args.out}")
        return

    # 视频处理
    cap = cv2.VideoCapture(str(src_path))
    if not cap.isOpened():
        print(f"无法打开视频: {src_path}", file=sys.stderr)
        sys.exit(1)

    fourcc = cv2.VideoWriter_fourcc(*'mp4v') if Path(args.out).suffix.lower() in ['.mp4', '.mov', '.mkv'] else cv2.VideoWriter_fourcc(*'XVID')
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    out = cv2.VideoWriter(str(args.out), fourcc, fps, (width, height))
    frame_idx = 0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    pbar = tqdm(total=total_frames, desc='检测视频帧', unit='帧', ncols=80)

    tracker = MultiObjectTracker(iou_threshold=0.1, max_lost=5, lock_step=5)
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_idx += 1
        results = model(frame, conf=args.conf, iou=args.iou, verbose=False, end2end=False)
        smsmsg = yolo_format_to_XY(results)
        bboxes = smsmsg["Y"]["bboxes"]
        obj_cls = smsmsg["Y"]["obj_cls"]
        n1 = len(bboxes)
        h, w = frame.shape[:2]
        bboxes = [[(bb[0]-bb[2]/2) * w, (bb[1]-bb[3]/2) * h, bb[2] * w, bb[3] * h, cc] for bb, cc in zip(bboxes, obj_cls)]
        bboxes = tracker.update(frame, bboxes)
        for bb in bboxes:
            assert len(bb) >= 6, "每个检测框必须包含至少6个元素: x, y, w, h, c, id"
        n2 = len(bboxes)
        if n1 != n2:
            for bb in bboxes:
                img = smsmsg["X"]["img"]
                img = np.ascontiguousarray(img.transpose(1, 2, 0))  # H, W, C
                cv2.rectangle(img, (int(bb[0]), int(bb[1])), (int(bb[0]+bb[2]), int(bb[1]+bb[3])), (0, 0, 255), 1, cv2.LINE_AA)
                smsmsg["X"]["img"] = np.ascontiguousarray(img.transpose(2, 0, 1))  # C, H, W
        bbboxes = [[(bb[0]+bb[2]/2) / w, (bb[1]+bb[3]/2) / h, bb[2] / w, bb[3] / h] for bb in bboxes]
        smsmsg["Y"]["bboxes"] = bbboxes
        smsmsg["Y"]["obj_cls"] = [bb[4] for bb in bboxes]
        smsmsg["Y"]["tracked_ids"] = [bb[5] for bb in bboxes]

        res_frame = vis_img_XY(smsmsg, draw_text=True, bbox_style="lock")  # 视频帧不绘制文本，提升效率
        out.write(res_frame)

        pbar.update(1)

    cap.release()
    out.release()
    pbar.close()
    print(f"视频检测完成，结果视频已保存: {args.out}")


if __name__ == "__main__":
    main()
