"""
MOT（多目标跟踪）评估脚本

基于 TrackEval 算法（已封装至 mot_tools.py），对 serviceCudaYoloMotScv 服务的
跟踪结果进行 HOTA / MOTA / IDF1 等全指标评价。

输入数据集格式（ARDMAV 风格）：
    dataset_root/
    ├── COCO_xx_xx.json      # 所有序列的统一 COCO 标注
    ├── seq_A/                # 序列 A 的图像文件夹
    │   ├── frame_0001.jpg
    │   └── ...
    ├── seq_B/                # 序列 B 的图像文件夹
    │   └── ...
    └── meta.txt              # (可选)

用法：
    smscli motEval --service /yolomot/cuda --data ~/dataset/my_mot_data
"""
import argparse
import sys
import os
import json
import time
from pathlib import Path
from collections import defaultdict
import cv2
import numpy as np
from spirems import Client, def_msg, cvimg2sms, sms2cvimg, cvimg2sms_mem, cvimg2sms_mem_cleanup
from spirems.msg_helper import print_table
from spirems.utils.mot_tools import evaluate_mot


APP_DESCRIPTION = "MOT多目标跟踪评估脚本，支持ARDMAV格式数据集，调用MOT服务并对跟踪结果进行评价"


def load_ardmav_dataset(data_root):
    """加载 ARDMAV 风格数据集

    数据集根目录下包含一个 COCO_*.json 标注文件和若干图像子文件夹（每个子文件夹是一个视频序列）。
    图像按文件名排序即为帧顺序。

    @param data_root: 数据集根目录
    @return: dict {
        'gt_file': COCO JSON 文件路径,
        'dataset': 原始 JSON 数据,
        'sequences': {seq_name: [{'img_path': ..., 'img_id': ..., 'anns': [...]}, ...], ...}
    }
    """
    # 查找 COCO JSON 文件
    json_files = sorted(
        [f for f in os.listdir(data_root) if f.startswith('COCO_') and f.endswith('.json')],
        reverse=True
    )
    if not json_files:
        raise FileNotFoundError(f'数据集 {data_root} 中未找到 COCO_*.json 标注文件')
    gt_file = os.path.join(data_root, json_files[0])

    tic = time.time()
    with open(gt_file, 'r') as f:
        dataset = json.load(f)
    print(f'数据集读取完成 (t={time.time() - tic:.2f}s), {len(dataset["images"])} 张图像, '
          f'{len(dataset["annotations"])} 个标注')

    # 构建索引
    img_id_to_info = {img['id']: img for img in dataset['images']}
    img_id_to_anns = defaultdict(list)
    for ann in dataset['annotations']:
        img_id_to_anns[ann['image_id']].append(ann)

    cat_id_to_name = {cat['id']: cat['name'] for cat in dataset['categories']}
    # 构建反向映射：类别名 → ID（用于过滤预测结果中非数据集类别的误检）
    category_name_to_cat_id = {
        v['name'].replace(' ', '_').lower(): v['id']
        for v in dataset['categories']
    }

    # 按子文件夹（序列）分组
    seq_to_frames = defaultdict(list)
    for img_id, img_info in img_id_to_info.items():
        file_name = img_info['file_name']
        # 提取序列名：第一个路径分量
        parts = file_name.replace('\\', '/').split('/')
        seq_name = parts[0] if len(parts) > 1 else '__root__'
        img_path = os.path.join(data_root, file_name)
        seq_to_frames[seq_name].append({
            'img_path': img_path,
            'img_id': img_id,
            'file_name': file_name,
        })

    # 每个序列内按文件名排序
    sequences = {}
    for seq_name, frames in seq_to_frames.items():
        frames.sort(key=lambda x: x['file_name'])
        # 为每帧附加标注
        for frame in frames:
            frame['anns'] = img_id_to_anns.get(frame['img_id'], [])
        sequences[seq_name] = frames

    print(f'共 {len(sequences)} 个序列')
    for seq_name, frames in sequences.items():
        total_anns = sum(len(f['anns']) for f in frames)
        print(f'  {seq_name}: {len(frames)} 帧, {total_anns} 个标注')

    # 打印类别信息，便于诊断类别不匹配问题
    print(f'数据集类别: {list(category_name_to_cat_id.keys())}')
    print(f'（预测结果中非以上类别的检测将被过滤，避免计入 FP）')

    return {
        'gt_file': gt_file,
        'dataset': dataset,
        'sequences': sequences,
        'cat_id_to_name': cat_id_to_name,
        'category_name_to_cat_id': category_name_to_cat_id,
    }


def build_gt_data(frames, img_width, img_height):
    """根据 COCO 标注构建 GT 数据（mot_tools 格式）

    COCO bbox: [x, y, w, h] (左上角)
    mot_tools bbox: [x, y, w, h] (左上角) — 一致

    @param frames: 按帧排列的帧信息列表
    @param img_width: 图像宽度
    @param img_height: 图像高度
    @return: gt_data 列表，每帧一个 dict
    """
    gt_data = []
    for frame in frames:
        ids = []
        bboxes = []
        classes = []
        for ann in frame['anns']:
            ids.append(ann.get('instance_id', ann['id']))  # instance_id 是跟踪 ID
            x, y, w, h = ann['bbox']
            bboxes.append([float(x), float(y), float(w), float(h)])
            classes.append(ann['category_id'])
        gt_data.append({
            'ids': ids,
            'bboxes': bboxes,
            'classes': classes,
        })
    return gt_data


def build_pred_data(targets, img_width, img_height):
    """根据 MOT 服务返回的 targets 构建预测数据

    服务返回的 bbox: [x, y, w, h] (左上角)，与原图尺寸一致
    类别由 category_id 给出，track_id 用于标识

    @param targets:  服务返回的 targets 列表
    @param img_width: 图像宽度
    @param img_height: 图像高度
    @return: pred_data dict（单帧）
    """
    ids = []
    bboxes = []
    classes = []
    scores = []
    for t in targets:
        ids.append(t.get('tracked_id', -1))
        x, y, w, h = t['bbox']
        bboxes.append([float(x), float(y), float(w), float(h)])
        classes.append(t.get('category_id', 0))
        scores.append(t.get('score', 1.0))
    return {
        'ids': ids,
        'bboxes': bboxes,
        'classes': classes,
        'scores': scores,
    }


def print_mot_results(seq_name, results):
    """打印单个序列的 MOT 评价结果

    @param seq_name: 序列名
    @param results:  evaluate_mot() 的返回值
    """
    metrics_display = [
        ('HOTA', 'HOTA'), ('DetA', 'DetA'), ('AssA', 'AssA'),
        ('MOTA', 'MOTA'), ('MOTP', 'MOTP'), ('IDF1', 'IDF1'),
        ('IDP', 'IDP'), ('IDR', 'IDR'),
        ('MT', 'MT'), ('PT', 'PT'), ('ML', 'ML'),
        ('FP', 'CLR_FP'), ('FN', 'CLR_FN'), ('IDSW', 'IDSW'),
        ('Frag', 'Frag'),
    ]
    headers = [m[0] for m in metrics_display]
    row = []
    for _, key in metrics_display:
        val = results.get(key, 0)
        if key in ('HOTA', 'DetA', 'AssA', 'MOTA', 'MOTP', 'IDF1', 'IDP', 'IDR'):
            row.append(f'{float(val) * 100:.1f}')
        elif key in ('CLR_FP', 'CLR_FN', 'IDSW', 'Frag'):
            row.append(f'{int(val)}')
        else:
            row.append(f'{int(val)}')

    print(f'\n--- {seq_name} ---')
    print_table([headers, row])


def main():
    parser = argparse.ArgumentParser(description="MOT多目标跟踪评估")
    parser.add_argument('--service', type=str, required=True,
                        help='MOT服务话题，如 /yolomot/cuda')
    parser.add_argument('--data', type=str, required=True,
                        help='ARDMAV格式数据集路径（支持逗号/分号分隔多个）')
    parser.add_argument('--ip', type=str, default='127.0.0.1',
                        help='MOT服务IP')
    parser.add_argument('--port', type=int, default=9094,
                        help='MOT服务端口')
    parser.add_argument('--conf', type=float, default=0.001,
                        help='检测置信度阈值（默认0.001，与detectionEval一致。跟踪评估中所有检测都参与，'
                             'MOTA公式本身会通过FP惩罚低质量检测，无需过高阈值）')
    args = parser.parse_args()

    # 基本检查
    if not args.service.startswith('/'):
        print('错误: --service 必须以 "/" 开头')
        sys.exit(1)
    import socket
    try:
        socket.inet_aton(args.ip)
    except Exception:
        print(f'错误: --ip 格式非法: {args.ip}')
        sys.exit(1)
    if args.port <= 0 or args.port > 65535:
        print(f'错误: --port 必须在 1-65535 范围内')
        sys.exit(1)

    # 打印参数
    GREEN = '\033[32m'
    RESET = '\033[0m'
    print('====== motEval 参数 ======')
    for k, v in vars(args).items():
        print(f'{GREEN}{k}{RESET}: {v}')
    print('==========================')

    # 解析多数据集
    if ',' in args.data:
        data_roots = args.data.split(',')
    elif ';' in args.data:
        data_roots = args.data.split(';')
    else:
        data_roots = [args.data]
    data_roots = [os.path.expanduser(d) if d.startswith('~') else d for d in data_roots]

    # 基本路径检查
    for dr in data_roots:
        dp = Path(dr)
        if not dp.exists():
            print(f'错误: --data 路径不存在: {dr}')
            sys.exit(1)
        if not dp.is_dir():
            print(f'错误: --data 必须是目录路径: {dr}')
            sys.exit(1)

    all_results = []  # [(data_root, seq_results_list), ...]

    for data_root in data_roots:
        dataset_name = os.path.basename(data_root.rstrip('/'))
        print(f'\n{"="*60}')
        print(f'评估数据集: {data_root}')
        print(f'{"="*60}')

        # 加载数据集
        mot_data = load_ardmav_dataset(data_root)
        sequences = mot_data['sequences']

        # 创建 MOT 服务客户端
        cc = Client(args.service, 'std_msgs::Null', 'spirecv_msgs::2DTargets',
                    ip=args.ip, port=args.port)

        seq_results = []

        # 逐序列评估
        seq_names = sorted(sequences.keys())
        for seq_idx, seq_name in enumerate(seq_names):
            frames = sequences[seq_name]
            print(f'\n处理序列 [{seq_idx+1}/{len(seq_names)}]: {seq_name} ({len(frames)} 帧)')

            gt_data = []
            pred_data = []

            # 带进度条遍历帧
            try:
                from tqdm import tqdm
                frame_iter = tqdm(enumerate(frames), total=len(frames),
                                  desc=f'  {seq_name}', ncols=80, unit='f')
            except ImportError:
                frame_iter = enumerate(frames)

            first_frame = True
            for fi, frame in frame_iter:
                img_path = frame['img_path']
                if not os.path.exists(img_path):
                    print(f'  警告: 图像不存在 {img_path}')
                    # 使用空预测
                    img_height, img_width = 1080, 1920
                    gt_data.append(build_gt_data([frame], img_width, img_height)[0])
                    pred_data.append({'ids': [], 'bboxes': [], 'classes': [], 'scores': []})
                    first_frame = False
                    continue

                img = cv2.imread(img_path)
                if img is None:
                    print(f'  警告: 无法读取图像 {img_path}')
                    img_height, img_width = 1080, 1920
                    gt_data.append(build_gt_data([frame], img_width, img_height)[0])
                    pred_data.append({'ids': [], 'bboxes': [], 'classes': [], 'scores': []})
                    first_frame = False
                    continue

                img_height, img_width = img.shape[:2]

                # 构建 GT 数据（当前帧）
                gt_frame = build_gt_data([frame], img_width, img_height)[0]
                gt_data.append(gt_frame)

                # 传输图像到 MOT 服务
                if args.ip == '127.0.0.1':
                    smsmsg = cvimg2sms_mem(img, f"mot_eval_shm_{seq_name}")
                else:
                    smsmsg = cvimg2sms(img)

                smsmsg['conf'] = args.conf
                smsmsg['iou'] = 0.45
                # 第一个帧（或序列切换）需要 reinit
                if first_frame:
                    smsmsg['reinit'] = True
                    first_frame = False

                # 重试机制
                req_i = 0
                res = None
                while req_i < 3:
                    req_i += 1
                    res = cc.request(smsmsg)
                    if res:
                        break
                    time.sleep(0.1)

                if req_i >= 3 or res is None:
                    if fi == 0:
                        print(f'  警告: 第 {fi} 帧未收到响应')
                    pred_data.append({'ids': [], 'bboxes': [], 'classes': [], 'scores': []})
                else:
                    # 只保留数据集中存在的类别，过滤掉其他类别的误检
                    all_targets = res.get('targets', [])
                    targets = [t for t in all_targets
                               if t.get('category_name', '') in mot_data['category_name_to_cat_id']]

                    pred_frame = build_pred_data(targets, img_width, img_height)
                    pred_data.append(pred_frame)

            # 该序列评价
            if len(gt_data) == 0:
                print(f'  序列 {seq_name} 无有效帧，跳过评价')
                continue

            print(f'  正在评价序列 {seq_name} ...')
            mot_result = evaluate_mot(gt_data, pred_data, threshold=0.5)

            # 诊断：统计跟踪ID情况
            all_pred_ids = [pid for frame in pred_data for pid in frame['ids']]
            all_gt_ids = [gid for frame in gt_data for gid in frame['ids']]
            n_neg = sum(1 for pid in all_pred_ids if pid < 0)
            n_pos = len(all_pred_ids) - n_neg
            n_unique = len(set(pid for pid in all_pred_ids if pid >= 0))
            print(f'  诊断: GT IDs={len(set(all_gt_ids))}, 预测总检测={len(all_pred_ids)}, '
                  f'tracked_id=-1占{n_neg}个, 有效tracked_id种类={n_unique}')

            print_mot_results(seq_name, mot_result)
            seq_results.append((seq_name, mot_result))

        cc.kill()
        if args.ip == '127.0.0.1':
            for seq_name in seq_names:
                cvimg2sms_mem_cleanup(f"mot_eval_shm_{seq_name}")

        all_results.append((data_root, dataset_name, seq_results))

    # ======== 最终汇总 ========
    print(f'\n{"="*60}')
    print('最终汇总')
    print(f'{"="*60}')

    for data_root, dataset_name, seq_results in all_results:
        print(f'\n====== {dataset_name} ({data_root}) ======')

        # 汇总表头
        summary_headers = ['Sequence', 'HOTA', 'MOTA', 'IDF1', 'IDSW',
                           'MT', 'ML', 'FP', 'FN', 'Frag', 'Frames']
        summary_rows = []
        for seq_name, res in seq_results:
            frames = res.get('Frames', 0)
            summary_rows.append([
                seq_name,
                f'{float(res.get("HOTA", 0))*100:.1f}',
                f'{float(res.get("MOTA", 0))*100:.1f}',
                f'{float(res.get("IDF1", 0))*100:.1f}',
                f'{int(res.get("IDSW", 0))}',
                f'{int(res.get("MT", 0))}',
                f'{int(res.get("ML", 0))}',
                f'{int(res.get("CLR_FP", 0))}',
                f'{int(res.get("CLR_FN", 0))}',
                f'{int(res.get("Frag", 0))}',
                f'{frames}',
            ])
        print_table([summary_headers] + summary_rows)

        # 计算平均值（跨序列加权，按帧数）
        if seq_results:
            total_frames = sum(res.get('Frames', 0) for _, res in seq_results)
            weighted = {}
            for key in ['HOTA', 'DetA', 'AssA', 'MOTA', 'MOTP', 'IDF1', 'IDP', 'IDR']:
                values = []
                weights = []
                for _, res in seq_results:
                    v = float(res.get(key, 0))
                    w = res.get('Frames', 1)
                    values.append(v)
                    weights.append(w)
                if sum(weights) > 0:
                    weighted[key] = sum(v * w for v, w in zip(values, weights)) / sum(weights)
                else:
                    weighted[key] = 0.0

            for key in ['IDSW', 'CLR_FP', 'CLR_FN', 'Frag', 'MT', 'PT', 'ML',
                        'CLR_TP', 'GT_Dets', 'Dets']:
                total = 0
                for _, res in seq_results:
                    total += int(res.get(key, 0))
                weighted[key] = total

            avg_headers = ['Metric', 'Value']
            avg_rows = [
                ['HOTA', f'{weighted["HOTA"]*100:.1f}%'],
                ['DetA', f'{weighted["DetA"]*100:.1f}%'],
                ['AssA', f'{weighted["AssA"]*100:.1f}%'],
                ['MOTA', f'{weighted["MOTA"]*100:.1f}%'],
                ['IDF1', f'{weighted["IDF1"]*100:.1f}%'],
                ['IDSW', f'{int(weighted["IDSW"])}'],
                ['MT', f'{int(weighted["MT"])}'],
                ['ML', f'{int(weighted["ML"])}'],
                ['FP', f'{int(weighted["CLR_FP"])}'],
                ['FN', f'{int(weighted["CLR_FN"])}'],
                ['Frag', f'{int(weighted["Frag"])}'],
                ['Total Frames', f'{total_frames}'],
            ]
            print('\n--- Weighted Average ---')
            print_table([avg_headers] + avg_rows)

    print()


if __name__ == "__main__":
    main()
