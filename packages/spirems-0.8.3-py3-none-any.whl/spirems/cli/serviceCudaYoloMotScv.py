"""
YOLO多目标跟踪服务（MOT），接收图像并返回带 track_id 的 2DTargets 结构化跟踪结果
"""
import argparse
import sys
from spirems.mod_helper import download_model
from spirems import Service, cvimg2sms, sms2cvimg, def_msg
from spirems.utils.xy_tools import yolo_format_to_2DTargets

APP_DESCRIPTION = "YOLO多目标跟踪服务，接收图像并返回带 track_id 的 2DTargets 结构化跟踪结果，支持.pt模型与 sms:: 模型自动下载"

parser = argparse.ArgumentParser(description="YOLO多目标跟踪服务（支持.pt模型，支持sms::自动下载）")
parser.add_argument('--model', type=str, required=True, help='YOLO pt模型路径或sms::模型名')
parser.add_argument('--ip', type=str, default='127.0.0.1', help='SpireMS Core IP')
parser.add_argument('--port', type=int, default=9094, help='SpireMS Core Port')
parser.add_argument('--tracker', type=str, default='bytetrack.yaml',
                    help='跟踪器配置文件，如 bytetrack.yaml 或 botsort.yaml，默认 bytetrack.yaml')
args = parser.parse_args()

# 动态导入ultralytics
try:
    from ultralytics import YOLO
except ImportError:
    print("请先安装ultralytics库: pip install ultralytics", file=sys.stderr)
    sys.exit(1)

# 获取本地模型路径（支持sms::自动下载）
node_name = "YOLOv11DetNode_Cuda"
model_path = download_model(node_name, args.model)

# 加载模型
model = YOLO(model_path)


def callback_f(msg):
    """服务回调：接收图像，执行多目标跟踪，返回 2DTargets

    @param msg: 输入消息，包含图像数据及 conf/iou/reinit 参数
        - reinit (bool): 设为 True 时重新初始化跟踪器，适用于视频切换场景
    @return: spirecv_msgs::2DTargets 消息（每个 target 含 tracked_id）
    """
    cvimg = sms2cvimg(msg)

    conf = msg['conf'] if 'conf' in msg else 0.001
    iou = msg['iou'] if 'iou' in msg else 0.45

    # 重新初始化跟踪器：清空所有内部状态（tracked/lost/removed tracks、Kalman filter、track ID），
    # 适用于从一个视频切换到另一个视频的场景
    if msg.get('reinit', False):
        if hasattr(model.predictor, 'trackers'):
            for tracker in model.predictor.trackers:
                tracker.reset()
            print('[MotNode] 跟踪器已重新初始化')

    # 多目标跟踪推理，persist=True 保持帧间 track ID 连续性
    results = model.track(cvimg, persist=True, conf=conf, iou=iou, tracker=args.tracker)
    smsmsg = yolo_format_to_2DTargets(results)
    return smsmsg


if __name__ == "__main__":
    # 服务地址，接收请求类型，返回响应类型，回调函数
    ss = Service('/yolomot/cuda', 'std_msgs::Null', 'spirecv_msgs::2DTargets', callback_f, ip=args.ip, port=args.port)
    ss.join()
