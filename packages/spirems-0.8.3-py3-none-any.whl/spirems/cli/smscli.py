import argparse
import ast
import os
import sys
import subprocess
from pathlib import Path

CLI_DIR = Path(__file__).parent
APP_DESCRIPTION_NAME = "APP_DESCRIPTION"


def list_apps():
    return sorted([
        f.stem for f in CLI_DIR.glob("*.py")
        if f.name not in ("smscli.py", "__init__.py") and f.is_file()
    ])


def get_app_description(app_path: Path):
    try:
        source = app_path.read_text(encoding="utf-8")
    except Exception:
        return None

    try:
        module = ast.parse(source, filename=str(app_path))
    except SyntaxError:
        return None

    for node in module.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == APP_DESCRIPTION_NAME:
                    if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                        return node.value.value.strip()
        elif isinstance(node, ast.AnnAssign):
            target = node.target
            if isinstance(target, ast.Name) and target.id == APP_DESCRIPTION_NAME:
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    return node.value.value.strip()
    return None

def main():
    parser = argparse.ArgumentParser(description="SpireMS CLI manager")
    parser.add_argument("app", nargs="?", help="App name to run")
    parser.add_argument("args", nargs=argparse.REMAINDER, help="Arguments for the app")
    args = parser.parse_args()

    green = "\033[32m"
    grey = "\033[90m"
    bold = "\033[1m"
    reset = "\033[0m"

    if args.app is None or args.app == "ls":
        print(f"{bold}{green}Available apps:{reset}")
        for app in list_apps():
            desc = get_app_description(CLI_DIR / f"{app}.py")
            if desc:
                print(f"  {app}: {grey}{desc}{reset}")
            else:
                print(f"  {app}")
        return

    app_name = args.app
    app_path = CLI_DIR / f"{app_name}.py"
    if not app_path.exists():
        print(f"App '{app_name}' not found.")
        sys.exit(1)

    cmd = [sys.executable, str(app_path)] + args.args
    subprocess.run(cmd)

if __name__ == "__main__":
    main()
