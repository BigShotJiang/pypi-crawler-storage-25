
import argparse
import json
import sys
from pathlib import Path
import time
import cv2
from spirems.mod_helper import download_model
from spirems.utils.xy_tools import yolo_format_to_XY, yolo_format_to_SpireView, spirecv_2DTargets_to_XY, spirecv_2DTargets_to_SpireView
from spirems.utils.vis_tools import vis_img_XY
from spirems import Client, def_msg, cvimg2sms, sms2cvimg, cvimg2sms_mem, cvimg2sms_mem_cleanup


APP_DESCRIPTION = "基于sms::Client的图片/图片文件夹目标检测脚本，调用sms::Service的检测服务实现目标检测推理"


def is_image_file(path: Path):
    return path.is_file() and path.suffix.lower() in {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp'}


def collect_image_files(root: Path):
    for path in root.rglob('*'):
        if is_image_file(path):
            yield path


def main():
    parser = argparse.ArgumentParser(description="YOLO目标检测（支持.pt模型，支持sms::自动下载，支持单图像与图像目录，支持Spire格式输出）")
    parser.add_argument('--service', type=str, required=True, help='sms::Service地址')
    parser.add_argument('--img', type=str, required=True, help='待检测图片路径或图片目录路径')
    parser.add_argument('--out', type=str, required=True, help='检测结果输出文件路径或输出目录路径')
    parser.add_argument('--conf', type=float, default=0.25, help='置信度阈值')
    parser.add_argument('--iou', type=float, default=0.45, help='非极大抑制IoU阈值')
    parser.add_argument('--ip', type=str, default='127.0.0.1', help='检测器服务IP地址')
    parser.add_argument('--port', type=int, default=9094, help='检测器服务端口号')
    parser.add_argument('--spire', action='store_true', help='输出Spire格式结果，生成scaled_images和annotations结构')
    args = parser.parse_args()

    img_path = Path(args.img)
    out_path = Path(args.out)

    if not img_path.exists():
        print(f"输入路径不存在: {args.img}", file=sys.stderr)
        sys.exit(1)

    if args.spire and img_path.is_dir() and out_path.exists() and out_path.is_file():
        print(f"Spire格式输出时 out 必须是目录: {args.out}", file=sys.stderr)
        sys.exit(1)

    if img_path.is_file():
        image_files = [img_path]
        # 单文件不生成Spire格式输出
        if out_path.exists() and out_path.is_dir():
            out_files = [out_path / img_path.name]
        else:
            out_files = [out_path]
        json_files = [None]
    else:
        image_files = list(collect_image_files(img_path))
        if not image_files:
            print(f"目录中未发现支持的图像文件: {args.img}", file=sys.stderr)
            sys.exit(1)

        rel_paths = [file.relative_to(img_path) for file in image_files]

        if args.spire:
            # 目录 Spire 输出：根据每个图片的父目录调整输出路径
            out_files = []
            json_files = []
            for file in image_files:
                if file.parent.name == 'scaled_images':
                    try:
                        base_rel = file.parent.parent.relative_to(img_path)
                    except ValueError:
                        base_rel = Path('.')
                else:
                    base_rel = file.parent.relative_to(img_path)
                out_file = out_path / base_rel / 'scaled_images' / file.name
                json_file = out_path / base_rel / 'annotations' / (file.name + '.json')
                out_files.append(out_file)
                json_files.append(json_file)
        else:
            out_path.mkdir(parents=True, exist_ok=True)
            out_files = [out_path / rel_path for rel_path in rel_paths]
            json_files = [None] * len(image_files)

        for out_file in out_files:
            out_file.parent.mkdir(parents=True, exist_ok=True)
        if args.spire:
            for json_file in json_files:
                json_file.parent.mkdir(parents=True, exist_ok=True)

    cc = Client(args.service, 'std_msgs::Null', 'spirecv_msgs::2DTargets', ip=args.ip, port=args.port)

    for src_file, dst_file, json_file in zip(image_files, out_files, json_files):
        img = cv2.imread(str(src_file))
        if img is None:
            print(f"无法读取图片: {src_file}", file=sys.stderr)
            continue
        
        if args.ip == '127.0.0.1':
            smsmsg = cvimg2sms_mem(img, "client_yolo_detect_shm")
        else:
            smsmsg = cvimg2sms(img)
        smsmsg["conf"] = args.conf
        smsmsg["iou"] = args.iou

        if args.spire and json_file is not None:
            # Spire 模式：只复制原始图像，不生成可视化结果
            import shutil
            shutil.copy2(str(src_file), str(dst_file))
        else:
            # 普通模式：生成可视化结果
            req_i = 0
            while req_i < 3:
                req_i += 1
                res = cc.request(smsmsg)
                if res:
                    break
                else:
                    time.sleep(0.1)
            if req_i >= 3:
                print(f'警告: 未收到检测器响应，尝试 {req_i} 次')
                continue

            smsmsg = spirecv_2DTargets_to_XY(res, cvimg=img)
            res_img = vis_img_XY(smsmsg)
            cv2.imwrite(str(dst_file), res_img)

        if args.spire and json_file is not None:
            req_i = 0
            while req_i < 3:
                req_i += 1
                res = cc.request(smsmsg)
                if res:
                    break
                else:
                    time.sleep(0.1)
            if req_i >= 3:
                print(f'警告: 未收到检测器响应，尝试 {req_i} 次')
                continue

            spire_msg = spirecv_2DTargets_to_SpireView(res)
            spire_msg["file_name"] = str(src_file.name)
            with json_file.open('w', encoding='utf-8') as f:
                json.dump(spire_msg, f, ensure_ascii=False)
            print(f"检测完成: {src_file} -> {dst_file}, 生成Spire json: {json_file}")
        else:
            print(f"检测完成: {src_file} -> {dst_file}")

    cc.kill()
    if args.ip == '127.0.0.1':
        cvimg2sms_mem_cleanup("client_yolo_detect_shm")


if __name__ == "__main__":
    main()
