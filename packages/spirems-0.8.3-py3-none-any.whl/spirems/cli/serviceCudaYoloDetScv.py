
import argparse
import sys
from pathlib import Path
import cv2
from spirems.mod_helper import download_model
from spirems.utils.xy_tools import yolo_format_to_XY, yolo_format_to_2DTargets
from spirems.utils.vis_tools import vis_img_XY
from spirems import Service, def_msg, cvimg2sms, sms2cvimg

APP_DESCRIPTION = "YOLO目标检测服务，接收图像并返回 2DTargets 结构化检测结果，支持.pt模型与 sms:: 模型自动下载"

parser = argparse.ArgumentParser(description="YOLO目标检测服务（支持.pt模型，支持sms::自动下载）")
parser.add_argument('--model', type=str, required=True, help='YOLO pt模型路径或sms::模型名')
parser.add_argument('--ip', type=str, default='127.0.0.1', help='SpireMS Core IP')
parser.add_argument('--port', type=int, default=9094, help='SpireMS Core Port')
args = parser.parse_args()


# 动态导入ultralytics（YOLOv8/YOLOv6/YOLOv5均可用）
try:
    from ultralytics import YOLO
except ImportError:
    print("请先安装ultralytics库: pip install ultralytics", file=sys.stderr)
    sys.exit(1)

# 获取本地模型路径（支持sms::自动下载）
node_name = "YOLOv11DetNode_Cuda"
model_path = download_model(node_name, args.model)

# 加载模型
model = YOLO(model_path)


def callback_f(msg):
    cvimg = sms2cvimg(msg)

    conf = msg['conf'] if 'conf' in msg else 0.001
    iou = msg['iou'] if 'iou' in msg else 0.45
    # 推理
    results = model.predict(cvimg, conf=conf, iou=iou, end2end=False)
    smsmsg = yolo_format_to_2DTargets(results)
    return smsmsg


if __name__ == "__main__":
    # 服务地址，接收请求类型，返回响应类型，回调函数
    ss = Service('/yolodet/cuda', 'std_msgs::Null', 'spirecv_msgs::2DTargets', callback_f, ip=args.ip, port=args.port)
    ss.join()
