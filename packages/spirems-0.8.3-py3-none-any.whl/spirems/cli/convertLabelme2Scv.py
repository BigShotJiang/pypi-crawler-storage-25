"""
Labelme 标注格式转换为 SpireView 标注格式的转换工具

Labelme 格式说明：
    - 每个图像对应一个同名的 .json 文件
    - shapes[].label → 类别名称
    - shapes[].points → 多边形顶点 [[x1,y1], [x2,y2], ...] 或矩形顶点
    - shapes[].shape_type → "polygon" / "rectangle" / "circle"
    - imageHeight / imageWidth → 图像尺寸
    - imagePath → 图像相对路径

SpireView 格式说明：
    - 每个图像一个 .json，包含 file_name / height / width / annos
    - annos[].bbox → [x, y, w, h]（左上角）
    - annos[].category_name → 类别名
    - annos[].area → bbox 面积
    - annos[].segmentation → 多边形顶点（展平列表），矩形则无此字段
    - annos[].tracked_id → 跟踪 ID（group_id 映射）

用法：
    smscli convertLabelme2Scv --labelme-dir ~/bit-fl5 --output-dir ~/spire_output
"""
import argparse
import sys
import os
import json
import shutil
from pathlib import Path
import cv2


APP_DESCRIPTION = "Labelme标注格式转SpireView标注格式工具"


def polygon_to_bbox(points):
    """从多边形顶点计算外接矩形

    @param points: [[x1,y1], [x2,y2], ...]
    @return: [x, y, w, h]（左上角）
    """
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    x_min = min(xs)
    y_min = min(ys)
    w = max(xs) - x_min
    h = max(ys) - y_min
    return [round(x_min, 2), round(y_min, 2), round(w, 2), round(h, 2)]


def convert_labelme_to_spire(labelme_json_path):
    """将单个 Labelme JSON 转换为 SpireView JSON

    @param labelme_json_path: Labelme .json 文件路径
    @return: SpireView 格式 dict，若无需转换则返回 None
    """
    with open(labelme_json_path, 'r') as f:
        lm = json.load(f)

    # 提取图像文件名
    image_path_in_json = lm.get('imagePath', '')
    file_name = os.path.basename(image_path_in_json.replace('\\', '/'))
    if not file_name:
        # 从 JSON 文件名推断图像名
        base = os.path.splitext(os.path.basename(labelme_json_path))[0]
        file_name = base + '.jpg'

    height = lm.get('imageHeight', 0)
    width = lm.get('imageWidth', 0)

    # 如果 JSON 中没有尺寸，尝试从同名图像读取
    if height == 0 or width == 0:
        img_path_candidate = os.path.join(os.path.dirname(labelme_json_path), file_name)
        if os.path.exists(img_path_candidate):
            img = cv2.imread(img_path_candidate)
            if img is not None:
                height, width = img.shape[:2]

    annos = []
    shapes = lm.get('shapes', [])

    for shape in shapes:
        label = shape.get('label', 'unknown').strip()
        points = shape.get('points', [])
        shape_type = shape.get('shape_type', 'polygon')
        group_id = shape.get('group_id')

        if not points or len(points) < 2:
            continue

        # 类别名规范化：空格替换为下划线，小写
        category_name = label.replace(' ', '_').lower()

        # 计算 bbox
        if shape_type == 'rectangle' and len(points) == 2:
            # 矩形：两点 [左上, 右下]
            x1, y1 = points[0]
            x2, y2 = points[1]
            x = min(x1, x2)
            y = min(y1, y2)
            w = abs(x2 - x1)
            h = abs(y2 - y1)
            bbox = [round(float(x), 2), round(float(y), 2),
                    round(float(w), 2), round(float(h), 2)]
            segmentation = None
        elif shape_type == 'polygon' or shape_type == 'linestrip':
            # 多边形：从顶点计算 bbox
            bbox = polygon_to_bbox(points)
            # 分割：展平顶点列表
            segmentation = []
            for p in points:
                segmentation.extend([round(float(p[0]), 2), round(float(p[1]), 2)])
        elif shape_type == 'circle':
            # 圆形：用圆心和半径近似 bbox
            cx, cy = points[0]
            rx, ry = points[1] if len(points) > 1 else (cx + 1, cy + 1)
            r = ((rx - cx) ** 2 + (ry - cy) ** 2) ** 0.5
            bbox = [round(cx - r, 2), round(cy - r, 2),
                    round(2 * r, 2), round(2 * r, 2)]
            segmentation = None
        else:
            # 其他类型，尝试从 points 计算 bbox
            bbox = polygon_to_bbox(points)
            segmentation = None

        area = round(bbox[2] * bbox[3], 2)

        anno = {
            'category_name': category_name,
            'bbox': bbox,
            'area': area,
        }

        if segmentation is not None and len(segmentation) >= 6:
            anno['segmentation'] = [segmentation]

        if group_id is not None:
            anno['tracked_id'] = int(group_id)

        annos.append(anno)

    if not annos:
        return None

    spire = {
        'file_name': file_name,
        'height': height,
        'width': width,
        'annos': annos,
    }

    return spire


def main():
    parser = argparse.ArgumentParser(description="Labelme标注转SpireView标注")
    parser.add_argument('--labelme-dir', type=str, required=True,
                        help='Labelme 数据集目录（包含 .jpg 和同名 .json）')
    parser.add_argument('--output-dir', type=str, required=True,
                        help='SpireView 格式输出目录')
    parser.add_argument('--copy-images', action='store_true', default=True,
                        help='复制图像到输出目录（默认开启）')
    parser.add_argument('--no-copy-images', action='store_false', dest='copy_images',
                        help='不复制图像')
    args = parser.parse_args()

    labelme_dir = Path(args.labelme_dir)
    output_dir = Path(args.output_dir)

    if not labelme_dir.exists() or not labelme_dir.is_dir():
        print(f'错误: Labelme 目录不存在: {args.labelme_dir}', file=sys.stderr)
        sys.exit(1)

    # 创建输出目录结构
    images_out = output_dir / 'scaled_images'
    annos_out = output_dir / 'annotations'
    os.makedirs(images_out, exist_ok=True)
    os.makedirs(annos_out, exist_ok=True)

    # 查找所有 Labelme JSON 文件
    json_files = sorted(labelme_dir.glob('*.json'))
    if not json_files:
        print(f'错误: {args.labelme_dir} 中未找到 .json 文件', file=sys.stderr)
        sys.exit(1)

    print(f'找到 {len(json_files)} 个 Labelme 标注文件')

    converted = 0
    skipped = 0

    for jf in json_files:
        spire = convert_labelme_to_spire(str(jf))

        if spire is None:
            skipped += 1
            continue

        # 写入 SpireView JSON
        out_json = annos_out / (spire['file_name'] + '.json')
        with open(out_json, 'w') as f:
            json.dump(spire, f, ensure_ascii=False)

        # 复制图像
        if args.copy_images:
            src_img = labelme_dir / spire['file_name']
            if not src_img.exists():
                # 尝试查找同名但不同扩展名的图像
                stem = Path(spire['file_name']).stem
                candidates = list(labelme_dir.glob(f'{stem}.*'))
                # 过滤掉 .json
                candidates = [c for c in candidates if c.suffix.lower() != '.json']
                if candidates:
                    src_img = candidates[0]
            if src_img.exists():
                dst_img = images_out / spire['file_name']
                shutil.copy2(src_img, dst_img)
            else:
                print(f'  警告: 图像未找到 {spire["file_name"]}')

        converted += 1

    # 打印统计
    print(f'\n转换完成: {converted} 个成功, {skipped} 个跳过（无标注）')
    print(f'输出目录: {output_dir}')
    print(f'  图像: {images_out}')
    print(f'  标注: {annos_out}')


if __name__ == '__main__':
    main()
