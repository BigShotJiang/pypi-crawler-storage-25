#!/usr/bin/env python3
import argparse
import os
import sys
from pathlib import Path

from spirems.mod_helper import download_model

APP_DESCRIPTION = "模型下载脚本，支持从 sms 服务获取模型并保存到本地路径"


def main():
    parser = argparse.ArgumentParser(description="Download model from sms server using download_model")
    parser.add_argument("--node", type=str, required=True, help="Node name for download_model，例如 YOLOv11DetNode_Cuda")
    parser.add_argument("--model", type=str, required=True, help="Model name")
    parser.add_argument("--out", type=str, required=True, help="Local output directory or file path")
    args = parser.parse_args()

    node_name = args.node
    model_name = args.model
    out_path = Path(args.out)

    if out_path.is_dir():
        # 保持原始模型文件名
        filename = os.path.basename(model_name)
        if filename.startswith("sms::"):
            filename = filename[5:]
        dest = out_path / filename
    else:
        # 目标路径可以是文件路径，确保目录存在
        out_path.parent.mkdir(parents=True, exist_ok=True)
        dest = out_path

    print(f"下载模型：node={node_name} model={model_name}")
    downloaded = download_model(node_name, model_name)
    if downloaded is None or not os.path.exists(downloaded):
        print("模型下载失败", file=sys.stderr)
        sys.exit(1)

    # 拷贝到指定路径
    if os.path.abspath(downloaded) != str(dest):
        import shutil
        shutil.copyfile(downloaded, dest)

    print(f"模型已保存到: {dest}")


if __name__ == "__main__":
    main()
