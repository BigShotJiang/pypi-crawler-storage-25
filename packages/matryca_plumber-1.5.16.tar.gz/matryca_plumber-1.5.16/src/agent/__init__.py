"""Agent-facing MCP integration."""
