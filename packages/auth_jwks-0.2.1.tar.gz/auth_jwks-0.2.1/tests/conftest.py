# asyncio_mode = "auto" is configured in pyproject.toml
