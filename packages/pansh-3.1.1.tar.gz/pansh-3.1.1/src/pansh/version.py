"""Single source of truth for the package version."""

__version__ = "3.1.1"
