# AgentOS

Portable agent operating system with selective memory routing.

Full release coming soon. See [GitHub](https://github.com/DeckerOps/agentos) for details.
