"""AgentOS — placeholder package. Full release coming soon."""
__version__ = "0.0.1"
