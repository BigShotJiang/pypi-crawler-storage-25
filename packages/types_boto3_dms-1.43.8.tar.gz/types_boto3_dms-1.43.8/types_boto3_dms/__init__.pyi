"""
Main interface for dms service.

[Documentation](https://youtype.github.io/types_boto3_docs/types_boto3_dms/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from boto3.session import Session
    from types_boto3_dms import (
        Client,
        DatabaseMigrationServiceClient,
        DescribeCertificatesPaginator,
        DescribeConnectionsPaginator,
        DescribeDataMigrationsPaginator,
        DescribeEndpointTypesPaginator,
        DescribeEndpointsPaginator,
        DescribeEventSubscriptionsPaginator,
        DescribeEventsPaginator,
        DescribeMetadataModelChildrenPaginator,
        DescribeMetadataModelCreationsPaginator,
        DescribeOrderableReplicationInstancesPaginator,
        DescribeReplicationInstancesPaginator,
        DescribeReplicationSubnetGroupsPaginator,
        DescribeReplicationTaskAssessmentResultsPaginator,
        DescribeReplicationTasksPaginator,
        DescribeSchemasPaginator,
        DescribeTableStatisticsPaginator,
        EndpointDeletedWaiter,
        ExtensionPackAssociatedWaiter,
        MetadataModelAssessedWaiter,
        MetadataModelConversionCancelledWaiter,
        MetadataModelConvertedWaiter,
        MetadataModelCreatedWaiter,
        MetadataModelCreationCancelledWaiter,
        MetadataModelExportedAsScriptWaiter,
        MetadataModelExportedToTargetWaiter,
        MetadataModelImportedWaiter,
        ReplicationInstanceAvailableWaiter,
        ReplicationInstanceDeletedWaiter,
        ReplicationTaskDeletedWaiter,
        ReplicationTaskReadyWaiter,
        ReplicationTaskRunningWaiter,
        ReplicationTaskStoppedWaiter,
        TestConnectionSucceedsWaiter,
    )

    session = Session()
    client: DatabaseMigrationServiceClient = session.client("dms")

    endpoint_deleted_waiter: EndpointDeletedWaiter = client.get_waiter("endpoint_deleted")
    extension_pack_associated_waiter: ExtensionPackAssociatedWaiter = client.get_waiter("extension_pack_associated")
    metadata_model_assessed_waiter: MetadataModelAssessedWaiter = client.get_waiter("metadata_model_assessed")
    metadata_model_conversion_cancelled_waiter: MetadataModelConversionCancelledWaiter = client.get_waiter("metadata_model_conversion_cancelled")
    metadata_model_converted_waiter: MetadataModelConvertedWaiter = client.get_waiter("metadata_model_converted")
    metadata_model_created_waiter: MetadataModelCreatedWaiter = client.get_waiter("metadata_model_created")
    metadata_model_creation_cancelled_waiter: MetadataModelCreationCancelledWaiter = client.get_waiter("metadata_model_creation_cancelled")
    metadata_model_exported_as_script_waiter: MetadataModelExportedAsScriptWaiter = client.get_waiter("metadata_model_exported_as_script")
    metadata_model_exported_to_target_waiter: MetadataModelExportedToTargetWaiter = client.get_waiter("metadata_model_exported_to_target")
    metadata_model_imported_waiter: MetadataModelImportedWaiter = client.get_waiter("metadata_model_imported")
    replication_instance_available_waiter: ReplicationInstanceAvailableWaiter = client.get_waiter("replication_instance_available")
    replication_instance_deleted_waiter: ReplicationInstanceDeletedWaiter = client.get_waiter("replication_instance_deleted")
    replication_task_deleted_waiter: ReplicationTaskDeletedWaiter = client.get_waiter("replication_task_deleted")
    replication_task_ready_waiter: ReplicationTaskReadyWaiter = client.get_waiter("replication_task_ready")
    replication_task_running_waiter: ReplicationTaskRunningWaiter = client.get_waiter("replication_task_running")
    replication_task_stopped_waiter: ReplicationTaskStoppedWaiter = client.get_waiter("replication_task_stopped")
    test_connection_succeeds_waiter: TestConnectionSucceedsWaiter = client.get_waiter("test_connection_succeeds")

    describe_certificates_paginator: DescribeCertificatesPaginator = client.get_paginator("describe_certificates")
    describe_connections_paginator: DescribeConnectionsPaginator = client.get_paginator("describe_connections")
    describe_data_migrations_paginator: DescribeDataMigrationsPaginator = client.get_paginator("describe_data_migrations")
    describe_endpoint_types_paginator: DescribeEndpointTypesPaginator = client.get_paginator("describe_endpoint_types")
    describe_endpoints_paginator: DescribeEndpointsPaginator = client.get_paginator("describe_endpoints")
    describe_event_subscriptions_paginator: DescribeEventSubscriptionsPaginator = client.get_paginator("describe_event_subscriptions")
    describe_events_paginator: DescribeEventsPaginator = client.get_paginator("describe_events")
    describe_metadata_model_children_paginator: DescribeMetadataModelChildrenPaginator = client.get_paginator("describe_metadata_model_children")
    describe_metadata_model_creations_paginator: DescribeMetadataModelCreationsPaginator = client.get_paginator("describe_metadata_model_creations")
    describe_orderable_replication_instances_paginator: DescribeOrderableReplicationInstancesPaginator = client.get_paginator("describe_orderable_replication_instances")
    describe_replication_instances_paginator: DescribeReplicationInstancesPaginator = client.get_paginator("describe_replication_instances")
    describe_replication_subnet_groups_paginator: DescribeReplicationSubnetGroupsPaginator = client.get_paginator("describe_replication_subnet_groups")
    describe_replication_task_assessment_results_paginator: DescribeReplicationTaskAssessmentResultsPaginator = client.get_paginator("describe_replication_task_assessment_results")
    describe_replication_tasks_paginator: DescribeReplicationTasksPaginator = client.get_paginator("describe_replication_tasks")
    describe_schemas_paginator: DescribeSchemasPaginator = client.get_paginator("describe_schemas")
    describe_table_statistics_paginator: DescribeTableStatisticsPaginator = client.get_paginator("describe_table_statistics")
    ```
"""

from .client import DatabaseMigrationServiceClient
from .paginator import (
    DescribeCertificatesPaginator,
    DescribeConnectionsPaginator,
    DescribeDataMigrationsPaginator,
    DescribeEndpointsPaginator,
    DescribeEndpointTypesPaginator,
    DescribeEventsPaginator,
    DescribeEventSubscriptionsPaginator,
    DescribeMetadataModelChildrenPaginator,
    DescribeMetadataModelCreationsPaginator,
    DescribeOrderableReplicationInstancesPaginator,
    DescribeReplicationInstancesPaginator,
    DescribeReplicationSubnetGroupsPaginator,
    DescribeReplicationTaskAssessmentResultsPaginator,
    DescribeReplicationTasksPaginator,
    DescribeSchemasPaginator,
    DescribeTableStatisticsPaginator,
)
from .waiter import (
    EndpointDeletedWaiter,
    ExtensionPackAssociatedWaiter,
    MetadataModelAssessedWaiter,
    MetadataModelConversionCancelledWaiter,
    MetadataModelConvertedWaiter,
    MetadataModelCreatedWaiter,
    MetadataModelCreationCancelledWaiter,
    MetadataModelExportedAsScriptWaiter,
    MetadataModelExportedToTargetWaiter,
    MetadataModelImportedWaiter,
    ReplicationInstanceAvailableWaiter,
    ReplicationInstanceDeletedWaiter,
    ReplicationTaskDeletedWaiter,
    ReplicationTaskReadyWaiter,
    ReplicationTaskRunningWaiter,
    ReplicationTaskStoppedWaiter,
    TestConnectionSucceedsWaiter,
)

Client = DatabaseMigrationServiceClient

__all__ = (
    "Client",
    "DatabaseMigrationServiceClient",
    "DescribeCertificatesPaginator",
    "DescribeConnectionsPaginator",
    "DescribeDataMigrationsPaginator",
    "DescribeEndpointTypesPaginator",
    "DescribeEndpointsPaginator",
    "DescribeEventSubscriptionsPaginator",
    "DescribeEventsPaginator",
    "DescribeMetadataModelChildrenPaginator",
    "DescribeMetadataModelCreationsPaginator",
    "DescribeOrderableReplicationInstancesPaginator",
    "DescribeReplicationInstancesPaginator",
    "DescribeReplicationSubnetGroupsPaginator",
    "DescribeReplicationTaskAssessmentResultsPaginator",
    "DescribeReplicationTasksPaginator",
    "DescribeSchemasPaginator",
    "DescribeTableStatisticsPaginator",
    "EndpointDeletedWaiter",
    "ExtensionPackAssociatedWaiter",
    "MetadataModelAssessedWaiter",
    "MetadataModelConversionCancelledWaiter",
    "MetadataModelConvertedWaiter",
    "MetadataModelCreatedWaiter",
    "MetadataModelCreationCancelledWaiter",
    "MetadataModelExportedAsScriptWaiter",
    "MetadataModelExportedToTargetWaiter",
    "MetadataModelImportedWaiter",
    "ReplicationInstanceAvailableWaiter",
    "ReplicationInstanceDeletedWaiter",
    "ReplicationTaskDeletedWaiter",
    "ReplicationTaskReadyWaiter",
    "ReplicationTaskRunningWaiter",
    "ReplicationTaskStoppedWaiter",
    "TestConnectionSucceedsWaiter",
)
