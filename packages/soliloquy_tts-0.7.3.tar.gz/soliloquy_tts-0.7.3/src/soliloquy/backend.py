"""Dual-mode backend: runs SSE server for proxies + stdio for the launching session."""

import atexit

import anyio
import uvicorn
from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Route

import json
import sys
import urllib.request

from .lock import remove_lock


def _check_for_update():
    """Print a notice to stderr if a newer version is available on PyPI."""
    try:
        from . import __version__ as current

        req = urllib.request.Request(
            "https://pypi.org/pypi/soliloquy-tts/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            latest = json.loads(resp.read())["info"]["version"]

        if latest != current:
            print(
                f"\u26a0 Soliloquy {latest} available (you have {current}). "
                f"Run: uv cache clean soliloquy-tts",
                file=sys.stderr,
                flush=True,
            )
    except Exception:
        pass


async def _health(request: Request) -> PlainTextResponse:
    return PlainTextResponse("ok")


async def _stop(request: Request) -> PlainTextResponse:
    from .audio import stop_playback

    was_playing = stop_playback()
    if was_playing:
        return PlainTextResponse("stopped")
    return PlainTextResponse("nothing playing")


async def _status(request: Request) -> PlainTextResponse:
    from .audio import _playback

    import json

    return PlainTextResponse(
        json.dumps({"is_playing": _playback.is_playing}),
        media_type="application/json",
    )


async def _auto_speak(request: Request) -> PlainTextResponse:
    """Auto-speak endpoint for Claude Code Stop hook.

    Receives the hook payload with last_assistant_message and
    speaks it via the TTS pipeline. No MCP tool call needed —
    zero token overhead.

    Only speaks when auto-speak is enabled (flag file exists).
    """
    from .setup import AUTO_SPEAK_FLAG

    if not AUTO_SPEAK_FLAG.exists():
        return PlainTextResponse("auto-speak disabled")

    # Don't interrupt explicit speak/read_aloud calls
    from .audio import _playback
    if _playback.is_playing:
        return PlainTextResponse("already playing")

    try:
        body = await request.json()
        text = body.get("last_assistant_message", "")
    except Exception:
        text = ""

    if not text or not text.strip():
        return PlainTextResponse("nothing to speak")

    # Don't speak tool call results or very short responses
    text = text.strip()
    if len(text) < 10:
        return PlainTextResponse("too short")

    from .chunking import normalize_for_speech
    from .server import _synthesize_and_play, DEFAULT_VOICE, DEFAULT_LANG

    text = normalize_for_speech(text)
    if not text or len(text) < 10:
        return PlainTextResponse("nothing after normalization")

    try:
        _synthesize_and_play(text, DEFAULT_VOICE, 1.0, DEFAULT_LANG)
    except Exception:
        pass

    return PlainTextResponse("speaking")


async def run_backend_and_stdio(port: int) -> None:
    """Start the SSE backend and stdio MCP server concurrently.

    Lock file must already be written by the caller (main.py).
    """
    # Import server here to trigger kokoro/tool registration
    from . import server

    atexit.register(remove_lock)

    # Start menu bar app (macOS only, separate process)
    from .player import start_menu_bar, stop_menu_bar

    start_menu_bar(port)
    atexit.register(stop_menu_bar)

    # Build SSE app with health endpoint
    app = server.mcp.sse_app()
    app.routes.insert(0, Route("/health", _health))
    app.routes.insert(1, Route("/stop", _stop, methods=["POST"]))
    app.routes.insert(2, Route("/status", _status))
    app.routes.insert(3, Route("/auto-speak", _auto_speak, methods=["POST"]))

    try:
        async with anyio.create_task_group() as tg:

            async def run_sse():
                config = uvicorn.Config(
                    app, host="127.0.0.1", port=port, log_level="warning"
                )
                srv = uvicorn.Server(config)
                await srv.serve()

            async def run_stdio():
                await server.mcp.run_stdio_async()

            async def warm_up_background():
                # Run in a thread so it doesn't block the MCP handshake
                await anyio.to_thread.run_sync(server.warm_up)

            async def check_update_background():
                await anyio.to_thread.run_sync(_check_for_update)

            tg.start_soon(run_sse)
            tg.start_soon(run_stdio)
            tg.start_soon(warm_up_background)
            tg.start_soon(check_update_background)
    finally:
        remove_lock()
