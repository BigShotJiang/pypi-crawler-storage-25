"""Text segmentation, speech normalization, and adaptive chunk sizing for Soliloquy.

Splits text into sentences and feeds them to Kokoro in adaptive batches
based on playback queue depth — like TCP congestion control for audio.

Also provides normalize_for_speech() which transforms raw text (markdown,
symbols, code blocks, URLs) into natural prose suitable for TTS.
"""

from __future__ import annotations

import re
import threading
from typing import TYPE_CHECKING, Generator

import numpy as np
import spacy

if TYPE_CHECKING:
    from .audio import BufferState

_sent_nlp = None

# Minimum character count for a chunk sent to Kokoro.
# Short fragments produce poor prosody; combining them improves quality.
MIN_CHUNK_CHARS = 80

# Serialize all PyTorch inference — the CPU allocator corrupts the heap
# when multiple threads run LSTM ops concurrently (libtorch is not thread-safe).
_inference_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Speech normalization — transforms raw text into natural spoken prose
# ---------------------------------------------------------------------------

# Symbol-to-speech mappings
_SYMBOL_MAP = {
    "\u2192": " to ",        # →
    "\u2190": " from ",      # ←
    "\u2194": " to and from ",  # ↔
    "=>": " becomes ",
    ">=": " at least ",
    "<=": " at most ",
    "!=": " is not ",
    "==": " equals ",
    "&&": " and ",
    "||": " or ",
    "...": "\u2026",         # Proper ellipsis — Kokoro handles it well
}

# Technical unit expansions
_UNIT_MAP = {
    "kb": "kilobytes",
    "mb": "megabytes",
    "gb": "gigabytes",
    "tb": "terabytes",
    "khz": "kilohertz",
    "mhz": "megahertz",
    "ghz": "gigahertz",
    "ms": "milliseconds",
    "μs": "microseconds",
    "ns": "nanoseconds",
}


def _handle_code_blocks(text: str) -> str:
    """Replace code blocks with natural speech cues."""
    # Match fenced code blocks: ``` at start of line (with optional indent),
    # followed by anything until a closing ``` at start of line.
    code_pattern = re.compile(r"^[ \t]*```[^\n]*\n.*?\n[ \t]*```", re.MULTILINE | re.DOTALL)
    code_matches = code_pattern.findall(text)
    code_chars = sum(len(m) for m in code_matches)
    total_chars = len(text.strip())

    if total_chars > 0 and code_chars / total_chars > 0.6:
        # Mostly code — strip all code blocks and add a note
        text = code_pattern.sub("", text)
        non_code = text.strip()
        if non_code:
            return non_code + "\n\nThe rest is code."
        return "This response is mostly code."

    # Replace each code block with a contextual cue
    def _code_replacement(match):
        start = match.start()
        # Look at the 80 chars before the code block for context
        preceding = text[max(0, start - 80):start].lower()
        if any(w in preceding for w in ("here", "example", "following", "like this", "below")):
            return "\n\nSee the code.\n\n"
        elif any(w in preceding for w in ("run", "execute", "command", "install")):
            return "\n\nSee the command.\n\n"
        return "\n\nThere's a code snippet here.\n\n"

    text = code_pattern.sub(_code_replacement, text)

    # Clean up any remaining stray backticks (inline triple backticks, etc.)
    text = text.replace("```", "")

    return text


def _handle_inline_code(text: str) -> str:
    """Strip backticks from inline code and clean up for speech."""
    def _inline_replacement(match):
        content = match.group(1)
        # Replace underscores and hyphens with spaces for readability
        content = content.replace("_", " ").replace("-", " ")
        # Remove trailing parens from function names: "some function()" → "some function"
        content = re.sub(r"\(\)$", "", content)
        return content

    return re.sub(r"`([^`]+)`", _inline_replacement, text)


def _handle_markdown(text: str) -> str:
    """Strip markdown formatting, preserving readable text."""
    # Remove images
    text = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", text)
    # Convert links to just the text
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    # Remove headers (keep the text)
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    # Remove bold/italic markers
    text = re.sub(r"\*{1,3}([^*]+)\*{1,3}", r"\1", text)
    text = re.sub(r"_{1,3}([^_]+)_{1,3}", r"\1", text)
    # Remove horizontal rules — replace with pause
    text = re.sub(r"^[-*_]{3,}\s*$", ".", text, flags=re.MULTILINE)
    # Remove blockquote markers
    text = re.sub(r"^>\s+", "", text, flags=re.MULTILINE)
    return text


def _handle_tables(text: str) -> str:
    """Replace markdown tables with a spoken summary."""
    # Match markdown tables (lines starting with |)
    table_pattern = re.compile(
        r"(?:^[ \t]*\|.*\|[ \t]*\n){2,}",
        re.MULTILINE,
    )

    def _table_replacement(match):
        table_text = match.group(0)
        rows = [r.strip() for r in table_text.strip().splitlines() if r.strip()]
        # Filter out separator rows (---|---|---)
        data_rows = [r for r in rows if not re.match(r"^[\s|:-]+$", r)]
        count = max(0, len(data_rows) - 1)  # subtract header
        if count > 0:
            return f"\n\nThere's a table here with {count} rows.\n\n"
        return "\n\nThere's a table here.\n\n"

    return table_pattern.sub(_table_replacement, text)


def _handle_lists(text: str) -> str:
    """Convert list items into natural enumeration."""
    lines = text.split("\n")
    result = []
    list_counter = 0

    for line in lines:
        # Unordered list items
        ul_match = re.match(r"^[\s]*[-*+]\s+(.*)", line)
        # Ordered list items
        ol_match = re.match(r"^[\s]*\d+\.\s+(.*)", line)

        if ul_match or ol_match:
            list_counter += 1
            content = (ul_match or ol_match).group(1)
            if list_counter == 1:
                result.append(f"First, {content}")
            elif list_counter == 2:
                result.append(f"Second, {content}")
            elif list_counter == 3:
                result.append(f"Third, {content}")
            else:
                ordinals = {4: "Fourth", 5: "Fifth", 6: "Sixth",
                            7: "Seventh", 8: "Eighth", 9: "Ninth", 10: "Tenth"}
                prefix = ordinals.get(list_counter, f"Number {list_counter},")
                result.append(f"{prefix}, {content}")
        else:
            list_counter = 0
            result.append(line)

    return "\n".join(result)


def _normalize_symbols(text: str) -> str:
    """Replace symbols with spoken equivalents."""
    for symbol, speech in _SYMBOL_MAP.items():
        text = text.replace(symbol, speech)

    # URLs → omit or simplify
    text = re.sub(
        r"https?://[^\s)\]>]+",
        "a link",
        text,
    )

    # File paths — keep just the filename
    # Matches ~/path/to/file.ext or /path/to/file.ext or relative/path/file.ext
    def _simplify_path(match):
        path = match.group(0)
        filename = path.rsplit("/", 1)[-1]
        if "." in filename:
            return filename
        return path  # Not clearly a file path, leave it

    text = re.sub(r"(?:~/|/)[^\s:,)]+\.[a-zA-Z]{1,5}", _simplify_path, text)

    # Technical units: "24kHz" → "24 kilohertz"
    def _expand_unit(match):
        number = match.group(1)
        unit = match.group(2).lower()
        expanded = _UNIT_MAP.get(unit, unit)
        return f"{number} {expanded}"

    text = re.sub(
        r"(\d+(?:\.\d+)?)\s*(" + "|".join(re.escape(u) for u in _UNIT_MAP) + r")\b",
        _expand_unit,
        text,
        flags=re.IGNORECASE,
    )

    # Approximation: ~N → "about N"
    text = re.sub(r"~(\d)", r"about \1", text)

    # Pipe characters (stray table fragments) → remove
    text = re.sub(r"\|", " ", text)

    # Collapse multiple spaces
    text = re.sub(r"  +", " ", text)

    return text


def _optimize_for_speech(text: str) -> str:
    """Final prosody tuning for Kokoro."""
    # Parenthetical definitions: "MCP (Model Context Protocol)" → "MCP, or Model Context Protocol,"
    text = re.sub(
        r"(\b[A-Z]{2,})\s+\(([^)]+)\)",
        r"\1, or \2,",
        text,
    )

    # Collapse multiple blank lines into one pause
    text = re.sub(r"\n{3,}", "\n\n", text)

    # Remove any leftover empty lines with only whitespace
    text = re.sub(r"\n\s*\n\s*\n", "\n\n", text)

    # Paragraph breaks → ellipsis pause. Kokoro treats "..." as a natural
    # breath/pause, which sounds much better than running sentences together.
    text = re.sub(r"\n\n+", "...\n", text)

    return text.strip()


def normalize_for_speech(text: str) -> str:
    """Transform raw text into natural spoken prose for TTS.

    Three-stage pipeline:
    1. Code block / table handling — replace with natural cues
    2. Markdown stripping + symbol normalization
    3. Speech optimization — lists, prosody, cleanup
    """
    text = _handle_code_blocks(text)      # Stage 1a — code blocks
    text = _handle_tables(text)           # Stage 1b — tables
    text = _handle_markdown(text)         # Stage 2a — markdown syntax
    text = _handle_inline_code(text)      # Stage 2b — inline code
    text = _handle_lists(text)            # Stage 2c — list enumeration
    text = _normalize_symbols(text)       # Stage 2d — symbols, URLs, paths
    text = _optimize_for_speech(text)     # Stage 3  — final prosody tuning
    return text


def _get_sent_nlp():
    """Get or create a lightweight spaCy sentencizer (rule-based, no model load)."""
    global _sent_nlp
    if _sent_nlp is None:
        _sent_nlp = spacy.blank("en")
        _sent_nlp.add_pipe("sentencizer")
    return _sent_nlp


def _normalize_text_for_dialogue(text: str) -> str:
    """Join mid-sentence line breaks but preserve dialogue paragraph breaks.

    Like _normalize_text, but also treats a line ending with a closing quote
    followed by a line starting with an opening quote as a paragraph break —
    even without a blank line between them. This is critical for dialogue
    parsing in ebook-formatted text.
    """
    lines = text.splitlines()
    result = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            if result and re.search(r'[.!?"\u201d\u2019]\s*$', result[-1]):
                result.append("")
            continue
        if result and result[-1]:
            prev = result[-1]
            # Dialogue paragraph break: previous line ends with closing quote,
            # current line starts with opening quote
            if (re.search(r'["\u201d]\s*$', prev) and
                    re.match(r'^["\u201c]', stripped)):
                result.append("")  # insert paragraph break
                result.append(stripped)
            else:
                result[-1] = prev + " " + stripped
        else:
            result.append(stripped)

    cleaned = []
    for para in result:
        if para:
            cleaned.append(re.sub(r"  +", " ", para))
    return "\n\n".join(cleaned)


def _normalize_text(text: str) -> str:
    """Join mid-sentence line breaks into continuous prose.

    Many text sources (OCR, ebooks, copy-paste) break lines at page margins
    and insert blank lines at page boundaries — even mid-sentence. This
    joins all lines into continuous text, only preserving paragraph breaks
    where the preceding line ends with sentence-ending punctuation.
    """
    lines = text.splitlines()
    result = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            # Blank line — only treat as paragraph break if the previous
            # line ended with sentence-ending punctuation
            if result and re.search(r'[.!?"\u2019\u201d]\s*$', result[-1]):
                result.append("")  # real paragraph break
            # Otherwise skip it (page break mid-sentence)
            continue
        if result and result[-1]:
            # Append to current paragraph
            result[-1] = result[-1] + " " + stripped
        else:
            result.append(stripped)

    # Collapse multiple spaces and join with paragraph breaks
    cleaned = []
    for para in result:
        if para:
            cleaned.append(re.sub(r"  +", " ", para))
    return "\n\n".join(cleaned)


def split_sentences(text: str, lang: str = "en-us") -> list[str]:
    """Split text into sentences.

    Normalizes line breaks first, then uses spaCy's rule-based sentencizer
    for English. Falls back to regex for other languages.
    """
    text = _normalize_text(text)
    if not text:
        return []

    if lang in ("en-us", "en-gb"):
        nlp = _get_sent_nlp()
        doc = nlp(text)
        return [sent.text.strip() for sent in doc.sents if sent.text.strip()]
    else:
        parts = re.split(r"(?<=[.!?])\s+", text)
        return [p.strip() for p in parts if p.strip()]


def adaptive_chunks(
    sentences: list[str],
    pipeline,
    voice: str,
    speed: float,
    buffer: "BufferState",
    stop_event: threading.Event | None = None,
) -> Generator[np.ndarray, None, None]:
    """Yield audio chunks from sentences, adapting batch size to buffered duration.

    Buffered audio duration drives batch sizing:
      - <5s  (starving): 1 sentence — get audio out fast
      - <15s (building): 3 sentences — buffer growing
      - 15s+ (healthy):  up to 10 sentences — big efficient batches

    Short batches are padded to MIN_CHUNK_CHARS to prevent tiny fragments.
    If stop_event is set, the generator exits early.
    """
    i = 0
    while i < len(sentences):
        if stop_event is not None and stop_event.is_set():
            return
        buffered = buffer.seconds

        if buffered < 5.0:
            batch_size = 1
        elif buffered < 15.0:
            batch_size = 3
        else:
            batch_size = min(10, len(sentences) - i)

        # Build batch, adding more sentences if below minimum size
        end = i + batch_size
        batch = " ".join(sentences[i:end])
        while len(batch) < MIN_CHUNK_CHARS and end < len(sentences):
            end += 1
            batch = " ".join(sentences[i:end])

        i = end

        # Collect all audio from this pipeline call into one chunk.
        # Kokoro may yield multiple small chunks per call — concatenating
        # them produces one large WAV file with fewer playback gaps.
        # .copy() detaches arrays from PyTorch's memory pool to prevent
        # heap corruption when the player thread reads them concurrently.
        parts = []
        with _inference_lock:
            for _gs, _ps, audio in pipeline(batch, voice=voice, speed=speed):
                if not isinstance(audio, np.ndarray):
                    audio = np.array(audio, dtype=np.float32)
                parts.append(audio.copy())
        if parts:
            yield np.concatenate(parts) if len(parts) > 1 else parts[0]


def adaptive_dialogue_chunks(
    segments: list,
    pipeline,
    speed: float,
    buffer: "BufferState",
    stop_event: threading.Event | None = None,
    lang: str = "en-us",
) -> Generator[np.ndarray, None, None]:
    """Yield audio chunks switching voice per dialogue segment.

    Each segment has .text and .voice. Within a segment, reuses
    adaptive_chunks for batching. Voice switches happen at segment
    boundaries — seamless via the voice-agnostic audio queue.
    """
    for segment in segments:
        if stop_event is not None and stop_event.is_set():
            return
        sentences = split_sentences(segment.text, lang=lang)
        if not sentences:
            continue
        yield from adaptive_chunks(
            sentences, pipeline, segment.voice, speed, buffer, stop_event,
        )
