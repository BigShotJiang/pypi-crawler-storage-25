"""Entry point for Soliloquy — decides between backend and proxy mode."""

import signal
import sys
import time

import anyio

from .lock import find_free_port, is_backend_alive, read_lock, remove_lock


def main() -> None:
    """Start Soliloquy as backend (first instance) or proxy (subsequent).

    Smart context detection: if run from a terminal (TTY), enter setup mode.
    If run by Claude Code (stdin is a pipe), start as MCP server.
    """
    if "--uninstall" in sys.argv:
        from .setup import run_uninstall

        run_uninstall()
        return

    if sys.stdin.isatty():
        from .setup import run_setup

        run_setup()
        return

    lock = read_lock()

    if lock and is_backend_alive(lock):
        # Backend already running — start as lightweight proxy
        print(
            f"Connecting to existing Soliloquy backend (port {lock.port})...",
            file=sys.stderr,
            flush=True,
        )
        from .proxy import run_proxy

        anyio.run(run_proxy, lock.port)
        return

    # No backend running — take over
    if lock:
        print("Stale lock file found, cleaning up...", file=sys.stderr, flush=True)
        remove_lock()

    port = find_free_port()

    try:
        from .lock import write_lock

        write_lock(pid=__import__("os").getpid(), port=port)
    except FileExistsError:
        # Lost the race — another process just became backend
        time.sleep(0.5)
        lock = read_lock()
        if lock and is_backend_alive(lock):
            print(
                f"Connecting to existing Soliloquy backend (port {lock.port})...",
                file=sys.stderr,
                flush=True,
            )
            from .proxy import run_proxy

            anyio.run(run_proxy, lock.port)
            return
        # Race winner died — try again from scratch
        remove_lock()
        main()
        return

    # Clean up lock file and menu bar on SIGTERM (atexit doesn't run on signals)
    def _shutdown(sig, frame):
        from .player import stop_menu_bar
        stop_menu_bar()
        remove_lock()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown)

    from .backend import run_backend_and_stdio

    anyio.run(run_backend_and_stdio, port)
