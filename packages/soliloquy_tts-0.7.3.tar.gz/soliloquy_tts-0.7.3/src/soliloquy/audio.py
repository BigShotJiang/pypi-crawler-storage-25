"""Audio playback for Soliloquy via sounddevice.

Uses a persistent PortAudio stream for gapless audio output.
A queue of numpy arrays decouples generation from playback so
the stream never runs dry between chunks.
Cross-platform: macOS, Windows, Linux — no platform-specific code needed.
"""

import atexit
import queue
import threading
from typing import Callable, Iterable, Union

import numpy as np
import sounddevice as sd


# ---------------------------------------------------------------------------
# Buffer state — tracks buffered audio duration for adaptive chunking
# ---------------------------------------------------------------------------


class BufferState:
    """Thread-safe tracker for buffered audio duration (in seconds)."""

    def __init__(self, sample_rate: int = 24000):
        self._seconds = 0.0
        self._lock = threading.Lock()
        self._sample_rate = sample_rate

    def add(self, num_samples: int) -> None:
        with self._lock:
            self._seconds += num_samples / self._sample_rate

    def subtract(self, num_samples: int) -> None:
        with self._lock:
            self._seconds = max(0.0, self._seconds - num_samples / self._sample_rate)

    @property
    def seconds(self) -> float:
        with self._lock:
            return self._seconds


# ---------------------------------------------------------------------------
# Playback state — shared between MCP tools and background threads
# ---------------------------------------------------------------------------


class PlaybackState:
    """Module-level singleton for coordinating playback across threads."""

    def __init__(self):
        self.stop_event = threading.Event()
        self.stream: sd.OutputStream | None = None
        self.stream_lock = threading.Lock()
        self.feeder_thread: threading.Thread | None = None
        self.player_thread: threading.Thread | None = None
        self.audio_queue: queue.Queue[np.ndarray | None] | None = None
        self.is_playing = False

    def reset(self):
        """Reset state for a new playback session."""
        self.stop_event.clear()
        self.stream = None
        self.feeder_thread = None
        self.player_thread = None
        self.audio_queue = None
        self.is_playing = False


_playback = PlaybackState()


def stop_playback() -> bool:
    """Stop any currently-playing audio. Returns True if something was stopped."""
    if not _playback.is_playing:
        return False

    # 1. Signal feeder to stop generating
    _playback.stop_event.set()

    # 2. Drain the queue so player thread unblocks and exits its loop
    q = _playback.audio_queue
    if q is not None:
        try:
            q.put_nowait(None)
        except queue.Full:
            pass

    # 3. Wait for threads to exit — they close the stream on their way out
    for t in (_playback.feeder_thread, _playback.player_thread):
        if t is not None and t.is_alive():
            t.join(timeout=3.0)

    # 4. If the stream is still open (thread didn't clean up), close it safely
    with _playback.stream_lock:
        stream = _playback.stream
        if stream is not None:
            try:
                stream.stop()
                import time
                time.sleep(0.05)  # Let CoreAudio IOThread finish
                stream.close()
            except Exception:
                pass
            _playback.stream = None

    _playback.reset()
    return True


# Clean up on exit
atexit.register(stop_playback)


# ---------------------------------------------------------------------------
# Core playback
# ---------------------------------------------------------------------------


def play_audio(audio: np.ndarray, sample_rate: int = 24000) -> None:
    """Play audio in the background."""
    stream_play_audio(iter([audio]), sample_rate=sample_rate, blocking=False)


def stream_play_audio(
    chunks: Union[
        Iterable[np.ndarray],
        Callable[[BufferState], Iterable[np.ndarray]],
    ],
    sample_rate: int = 24000,
    blocking: bool = True,
) -> int:
    """Play audio chunks as they arrive, returning total sample count.

    Accepts either:
      - An iterable (list or generator) of audio chunks
      - A callable that receives a BufferState and returns an iterable
        (used by adaptive chunking to inspect buffered audio duration)

    Uses a producer-consumer pattern: the feeder thread generates audio
    and queues numpy arrays, the player thread writes them to a persistent
    sounddevice stream. The queue keeps the stream fed during generation
    pauses, eliminating gaps.

    When blocking=True (default): blocks until all audio finishes playing.
    When blocking=False: starts playback in background and returns immediately.
    Use stop_playback() to cancel non-blocking playback.
    """
    buffer_state = BufferState(sample_rate)
    total_samples = 0
    # Cap queue at 5 chunks (~30s of audio) to prevent unbounded memory
    # growth during long reads. Feeder blocks when full, which also
    # reduces threading pressure on MPS/Metal GPU inference.
    q: queue.Queue[np.ndarray | None] = queue.Queue(maxsize=5)

    # Support both plain iterables and buffer-aware callables
    chunk_iter = chunks(buffer_state) if callable(chunks) else chunks

    def player():
        """Pulls numpy arrays from the queue and writes to the audio stream."""
        stream = sd.OutputStream(
            samplerate=sample_rate,
            channels=1,
            dtype="float32",
        )

        with _playback.stream_lock:
            _playback.stream = stream

        stream.start()

        try:
            while True:
                chunk = q.get()
                if chunk is None:
                    break  # sentinel — feeder is done
                if _playback.stop_event.is_set():
                    continue  # drain queue without playing

                # Convert to numpy if torch tensor
                if not isinstance(chunk, np.ndarray):
                    chunk = np.array(chunk, dtype=np.float32)
                data = chunk.reshape(-1, 1).astype(np.float32)

                try:
                    stream.write(data)
                    buffer_state.subtract(len(chunk))
                except Exception:
                    break  # stream was aborted

            # Drain remaining audio in PortAudio buffer
            try:
                stream.stop()
            except Exception:
                pass
        finally:
            import time
            time.sleep(0.05)  # Let CoreAudio IOThread release buffers
            with _playback.stream_lock:
                if _playback.stream is stream:
                    try:
                        stream.close()
                    except Exception:
                        pass
                    _playback.stream = None
            _playback.is_playing = False

    def feeder():
        """Generates audio chunks and queues them for the player."""
        nonlocal total_samples
        try:
            for chunk in chunk_iter:
                if _playback.stop_event.is_set():
                    break
                num_samples = len(chunk)
                total_samples += num_samples
                buffer_state.add(num_samples)
                # Blocks if queue is full — backpressure on the generator
                while not _playback.stop_event.is_set():
                    try:
                        q.put(chunk, timeout=0.5)
                        break
                    except queue.Full:
                        continue
        finally:
            q.put(None)  # sentinel — tell player we're done

    if blocking:
        _playback.audio_queue = q

        pt = threading.Thread(target=player, daemon=True)
        pt.start()

        # Run feeder in this thread (blocking)
        feeder()

        pt.join()
        return total_samples
    else:
        _playback.stop_event.clear()
        _playback.is_playing = True
        _playback.audio_queue = q

        pt = threading.Thread(target=player, daemon=True)
        ft = threading.Thread(target=feeder, daemon=True)
        _playback.player_thread = pt
        _playback.feeder_thread = ft

        pt.start()
        ft.start()

        return 0
