"""Lock file protocol for Soliloquy backend discovery."""

import json
import os
import socket
import time
from dataclasses import dataclass
from pathlib import Path

import httpx

LOCK_DIR = Path.home() / ".soliloquy"
LOCK_FILE = LOCK_DIR / "backend.lock"


@dataclass
class LockInfo:
    pid: int
    port: int
    started: str


def read_lock() -> LockInfo | None:
    """Read the lock file and return its contents, or None if missing/corrupt."""
    try:
        data = json.loads(LOCK_FILE.read_text())
        return LockInfo(pid=data["pid"], port=data["port"], started=data["started"])
    except (FileNotFoundError, KeyError, json.JSONDecodeError):
        return None


def write_lock(pid: int, port: int) -> None:
    """Atomically create the lock file. Raises FileExistsError on race loss."""
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    data = json.dumps({"pid": pid, "port": port, "started": time.strftime("%Y-%m-%dT%H:%M:%S")})
    # O_CREAT | O_EXCL ensures atomic creation — only one process wins
    fd = os.open(str(LOCK_FILE), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
    try:
        os.write(fd, data.encode())
    finally:
        os.close(fd)


def remove_lock() -> None:
    """Delete the lock file if it exists."""
    try:
        LOCK_FILE.unlink()
    except FileNotFoundError:
        pass


def is_backend_alive(lock: LockInfo) -> bool:
    """Check if the backend process is alive via PID check + HTTP health probe."""
    # Check PID exists
    try:
        os.kill(lock.pid, 0)
    except OSError:
        return False

    # Confirm it's actually a Soliloquy backend via health endpoint
    try:
        resp = httpx.get(f"http://127.0.0.1:{lock.port}/health", timeout=2.0)
        return resp.status_code == 200
    except (httpx.ConnectError, httpx.TimeoutException):
        return False


def find_free_port() -> int:
    """Find an available port by binding to port 0."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
