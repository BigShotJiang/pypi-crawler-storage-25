"""Lightweight stdio-to-SSE proxy for Soliloquy.

Bridges Claude Code's stdio MCP connection to an existing Soliloquy SSE backend.
No Kokoro or torch imports — starts near-instantly.
"""

import anyio
from mcp.client.sse import sse_client
from mcp.server.stdio import stdio_server


async def run_proxy(port: int) -> None:
    """Forward MCP messages between stdio and the SSE backend."""
    url = f"http://127.0.0.1:{port}/sse"

    async with sse_client(url) as (sse_read, sse_write):
        async with stdio_server() as (stdio_read, stdio_write):
            async with anyio.create_task_group() as tg:

                async def forward_to_backend():
                    async for message in stdio_read:
                        await sse_write.send(message)

                async def forward_to_client():
                    async for message in sse_read:
                        if isinstance(message, Exception):
                            raise message
                        await stdio_write.send(message)

                tg.start_soon(forward_to_backend)
                tg.start_soon(forward_to_client)
