from soliloquy import main

main()
