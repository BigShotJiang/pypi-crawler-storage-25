"""One-command setup for Soliloquy.

Registers the MCP server with Claude Code and configures the
auto-speak Stop hook. Run `uvx soliloquy-tts` from a terminal
to trigger setup mode automatically.
"""

import json
import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path

SOLILOQUY_DIR = Path.home() / ".soliloquy"
HOOK_SCRIPT = SOLILOQUY_DIR / "auto-speak-hook.sh"
AUTO_SPEAK_FLAG = SOLILOQUY_DIR / "auto-speak.enabled"
CLAUDE_SETTINGS = Path.home() / ".claude" / "settings.json"

HOOK_SCRIPT_CONTENT = """\
#!/bin/bash
# Soliloquy auto-speak hook — voices Claude's responses automatically.
LOCK="$HOME/.soliloquy/backend.lock"
FLAG="$HOME/.soliloquy/auto-speak.enabled"
[ -f "$FLAG" ] || exit 0
[ -f "$LOCK" ] || exit 0
PORT=$(python3 -c "import json; print(json.load(open('$LOCK'))['port'])" 2>/dev/null)
[ -n "$PORT" ] || exit 0
cat | curl -s -X POST "http://127.0.0.1:${PORT}/auto-speak" \\
    -H "Content-Type: application/json" -d @- -o /dev/null --max-time 3 &
exit 0
"""


def _print(msg: str, prefix: str = "  ") -> None:
    print(f"{prefix}{msg}", flush=True)


def _check_claude_cli() -> bool:
    """Check if claude CLI is available."""
    return shutil.which("claude") is not None


def _register_mcp() -> bool:
    """Register Soliloquy as an MCP server with Claude Code."""
    _print("Registering MCP server...", "  ")
    # Check if already registered
    try:
        result = subprocess.run(
            ["claude", "mcp", "list"],
            capture_output=True, text=True, timeout=15,
        )
    except subprocess.TimeoutExpired:
        _print("\u2717 Timed out checking MCP status (is Claude Code running?)", "  ")
        return False

    if "soliloquy" in result.stdout.lower():
        _print("\u2713 MCP server already registered", "  ")
        return True

    # Register
    try:
        result = subprocess.run(
            ["claude", "mcp", "add", "soliloquy", "-s", "user", "--", "uvx", "soliloquy-tts"],
            capture_output=True, text=True, timeout=15,
        )
    except subprocess.TimeoutExpired:
        _print("\u2717 Timed out registering MCP server", "  ")
        return False

    if result.returncode == 0:
        _print("\u2713 MCP server registered (user scope)", "  ")
        return True
    else:
        _print(f"\u2717 Failed to register MCP server: {result.stderr.strip()}", "  ")
        return False


def _write_hook_script() -> bool:
    """Write the auto-speak hook script to ~/.soliloquy/."""
    SOLILOQUY_DIR.mkdir(parents=True, exist_ok=True)

    HOOK_SCRIPT.write_text(HOOK_SCRIPT_CONTENT)
    HOOK_SCRIPT.chmod(HOOK_SCRIPT.stat().st_mode | stat.S_IEXEC)
    _print("\u2713 Hook script written", "  ")
    return True


def _configure_hook() -> bool:
    """Add the Stop hook to Claude Code's user settings."""
    CLAUDE_SETTINGS.parent.mkdir(parents=True, exist_ok=True)

    # Read existing settings
    settings = {}
    if CLAUDE_SETTINGS.exists():
        try:
            settings = json.loads(CLAUDE_SETTINGS.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    # Check if hook already configured
    hooks = settings.get("hooks", {})
    stop_hooks = hooks.get("Stop", [])

    for entry in stop_hooks:
        for hook in entry.get("hooks", []):
            cmd = hook.get("command", "")
            if "auto-speak-hook.sh" in cmd or "auto-speak" in cmd:
                _print("\u2713 Auto-speak hook already configured", "  ")
                return True

    # Add the hook
    hook_entry = {
        "matcher": "",
        "hooks": [
            {
                "type": "command",
                "command": str(HOOK_SCRIPT),
                "timeout": 5,
            }
        ],
    }

    if "hooks" not in settings:
        settings["hooks"] = {}
    if "Stop" not in settings["hooks"]:
        settings["hooks"]["Stop"] = []

    settings["hooks"]["Stop"].append(hook_entry)

    # Write settings
    CLAUDE_SETTINGS.write_text(json.dumps(settings, indent=2) + "\n")
    _print("\u2713 Auto-speak hook configured", "  ")
    return True


def run_setup() -> None:
    """Run the interactive setup flow."""
    print()
    print("  \u25c9 Soliloquy \u2014 Give Claude Code a Voice")
    print()
    print("  Setting up...")

    if not _check_claude_cli():
        _print("\u2717 Claude Code CLI not found. Install it first: https://claude.ai/code")
        sys.exit(1)

    _register_mcp()
    _write_hook_script()
    _configure_hook()

    print()
    print("  You're ready! Start (or restart) Claude Code.")
    print()
    print("  Commands Claude understands:")
    print('    "speak aloud"        \u2014 voice a response')
    print('    "read this file"     \u2014 read a file aloud')
    print('    "turn on auto speak" \u2014 voice every response automatically')
    print('    "stop"               \u2014 stop audio playback')
    print()
    print("  Tip: Say \"turn on auto speak\" to automatically voice")
    print("       conversational responses with zero token overhead.")
    print()


def _unregister_mcp() -> bool:
    """Remove Soliloquy MCP server registration from Claude Code."""
    try:
        result = subprocess.run(
            ["claude", "mcp", "list"],
            capture_output=True, text=True, timeout=15,
        )
    except subprocess.TimeoutExpired:
        _print("\u2717 Timed out checking MCP status", "  ")
        return False

    if "soliloquy" not in result.stdout.lower():
        _print("\u2713 MCP server not registered (nothing to remove)", "  ")
        return True

    try:
        result = subprocess.run(
            ["claude", "mcp", "remove", "soliloquy", "-s", "user"],
            capture_output=True, text=True, timeout=15,
        )
    except subprocess.TimeoutExpired:
        _print("\u2717 Timed out removing MCP server", "  ")
        return False

    if result.returncode == 0:
        _print("\u2713 MCP server unregistered", "  ")
        return True
    else:
        _print(f"\u2717 Failed to unregister MCP server: {result.stderr.strip()}", "  ")
        return False


def _remove_hook() -> bool:
    """Remove the Soliloquy Stop hook from Claude Code settings."""
    if not CLAUDE_SETTINGS.exists():
        _print("\u2713 No hooks to remove", "  ")
        return True

    try:
        settings = json.loads(CLAUDE_SETTINGS.read_text())
    except (json.JSONDecodeError, OSError):
        _print("\u2713 No hooks to remove", "  ")
        return True

    stop_hooks = settings.get("hooks", {}).get("Stop", [])
    if not stop_hooks:
        _print("\u2713 No hooks to remove", "  ")
        return True

    # Filter out Soliloquy hooks
    filtered = []
    for entry in stop_hooks:
        hooks = entry.get("hooks", [])
        is_soliloquy = any(
            "auto-speak-hook.sh" in h.get("command", "") or "auto-speak" in h.get("command", "")
            for h in hooks
        )
        if not is_soliloquy:
            filtered.append(entry)

    settings["hooks"]["Stop"] = filtered

    # Clean up empty structures
    if not settings["hooks"]["Stop"]:
        del settings["hooks"]["Stop"]
    if not settings.get("hooks"):
        del settings["hooks"]

    CLAUDE_SETTINGS.write_text(json.dumps(settings, indent=2) + "\n")
    _print("\u2713 Auto-speak hook removed", "  ")
    return True


def _remove_soliloquy_dir() -> bool:
    """Remove ~/.soliloquy/ directory."""
    if not SOLILOQUY_DIR.exists():
        _print("\u2713 Config directory already clean", "  ")
        return True

    shutil.rmtree(SOLILOQUY_DIR)
    _print("\u2713 Config directory removed (~/.soliloquy/)", "  ")
    return True


def run_uninstall() -> None:
    """Run the uninstall flow."""
    print()
    print("  \u25c9 Soliloquy \u2014 Uninstall")
    print()
    print("  Cleaning up...")

    if _check_claude_cli():
        _unregister_mcp()
    else:
        _print("\u26a0 Claude CLI not found, skipping MCP removal", "  ")

    _remove_hook()
    _remove_soliloquy_dir()

    print()
    print("  Done. Soliloquy has been removed from Claude Code.")
    print()
    print("  To also remove the package:")
    print("    uvx: uv cache clean soliloquy-tts")
    print("    pip: pip uninstall soliloquy-tts")
    print()
