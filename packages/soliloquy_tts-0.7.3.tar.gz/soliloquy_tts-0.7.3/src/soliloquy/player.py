"""Menu bar playback control for Soliloquy (macOS via rumps).

Spawns a separate process for the menu bar app since macOS requires
AppKit/rumps to run on the main thread. The menu bar app communicates
with the Soliloquy backend via HTTP endpoints (/status, /stop).

Falls back gracefully on non-macOS platforms or if rumps isn't installed.
"""

import json
import os
import platform
import subprocess
import sys
import textwrap
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .audio import PlaybackState

_rumps_available = False
if platform.system() == "Darwin":
    try:
        import rumps  # noqa: F401

        _rumps_available = True
    except ImportError:
        pass

# The menu bar app as an inline script — spawned as a separate process
_MENU_BAR_SCRIPT = textwrap.dedent('''\
    import json
    import sys
    import urllib.request

    import rumps

    PORT = int(sys.argv[1])
    BASE_URL = f"http://127.0.0.1:{PORT}"


    class SoliloquyMenuBar(rumps.App):
        def __init__(self):
            super().__init__("Soliloquy", title="Sol", quit_button=None)
            self.status_item = rumps.MenuItem("Idle")
            self.stop_item = rumps.MenuItem("Stop Playback", callback=self.on_stop)
            self.quit_item = rumps.MenuItem("Quit", callback=self.on_quit)
            self.menu = [self.status_item, None, self.stop_item, None, self.quit_item]

        @rumps.timer(1)
        def check_status(self, _):
            try:
                resp = urllib.request.urlopen(f"{BASE_URL}/status", timeout=1)
                data = json.loads(resp.read())
                if data.get("is_playing"):
                    self.title = "Sol ▶"
                    self.status_item.title = "Playing..."
                else:
                    self.title = "Sol"
                    self.status_item.title = "Idle"
            except Exception:
                self.title = "Sol"
                self.status_item.title = "Disconnected"

        def on_stop(self, _):
            try:
                req = urllib.request.Request(f"{BASE_URL}/stop", method="POST")
                urllib.request.urlopen(req, timeout=2)
            except Exception:
                pass

        def on_quit(self, _):
            rumps.quit_application()


    if __name__ == "__main__":
        SoliloquyMenuBar().run()
''')


_menu_bar_process: subprocess.Popen | None = None
_process_lock = threading.Lock()


def _kill_orphaned_menu_bars() -> None:
    """Kill any leftover Soliloquy menu bar processes from previous backends."""
    try:
        result = subprocess.run(
            ["pgrep", "-f", "SoliloquyMenuBar"],
            capture_output=True, text=True,
        )
        for pid_str in result.stdout.strip().splitlines():
            try:
                os.kill(int(pid_str), 15)  # SIGTERM
            except (ProcessLookupError, ValueError):
                pass
    except Exception:
        pass


def start_menu_bar(port: int) -> None:
    """Spawn the menu bar app as a separate process."""
    global _menu_bar_process
    if not _rumps_available:
        return

    with _process_lock:
        if _menu_bar_process is not None and _menu_bar_process.poll() is None:
            return  # already running

        # Kill any orphaned menu bar processes from previous backends
        _kill_orphaned_menu_bars()

        # Find the Python executable in our venv
        python = sys.executable

        _menu_bar_process = subprocess.Popen(
            [python, "-c", _MENU_BAR_SCRIPT, str(port)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


def stop_menu_bar() -> None:
    """Kill the menu bar process."""
    global _menu_bar_process
    with _process_lock:
        if _menu_bar_process is not None:
            try:
                _menu_bar_process.terminate()
                _menu_bar_process.wait(timeout=2)
            except Exception:
                try:
                    _menu_bar_process.kill()
                except Exception:
                    pass
            _menu_bar_process = None


# Keep get_mini_player for backward compatibility with audio.py hooks
# but it's now a no-op — the menu bar runs independently via polling
def get_mini_player():
    """No-op — menu bar app runs as separate process via start_menu_bar()."""
    return None
