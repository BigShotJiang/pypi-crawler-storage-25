#!/bin/bash
# Claude Code Stop hook — automatically speaks Claude's responses via Soliloquy.
# Reads the backend port from the lock file and POSTs the response text.
#
# Add to .claude/settings.local.json:
# {
#   "hooks": {
#     "Stop": [{
#       "matcher": "",
#       "hooks": [{
#         "type": "command",
#         "command": "/path/to/soliloquy/scripts/auto-speak-hook.sh",
#         "timeout": 5
#       }]
#     }]
#   }
# }

LOCK_FILE="$HOME/.soliloquy/backend.lock"

# Check if backend is running
if [ ! -f "$LOCK_FILE" ]; then
    exit 0
fi

# Read port from lock file
PORT=$(python3 -c "import json; print(json.load(open('$LOCK_FILE'))['port'])" 2>/dev/null)
if [ -z "$PORT" ]; then
    exit 0
fi

# Read hook payload from stdin, extract last_assistant_message, POST to auto-speak
cat | curl -s -X POST "http://127.0.0.1:${PORT}/auto-speak" \
    -H "Content-Type: application/json" \
    -d @- \
    -o /dev/null \
    --max-time 3 &

exit 0
