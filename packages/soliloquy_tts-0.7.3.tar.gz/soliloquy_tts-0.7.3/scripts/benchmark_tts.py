"""
Kokoro TTS Latency Benchmark for M2 Max
Measures cold start, warm generation, time-to-first-chunk, and playback.
"""

import time
import os
import subprocess
import sys

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"

# --- Test sentences at different lengths ---
TEXTS = {
    "short": "The build succeeded with no errors.",
    "medium": "I've refactored the authentication module to use JWT tokens instead of session cookies. The new implementation is cleaner and more secure.",
    "long": (
        "I've completed the migration of the database layer from SQLite to PostgreSQL. "
        "This involved updating all repository classes, modifying the connection pooling "
        "configuration, rewriting seventeen migration scripts, and adding integration tests "
        "for each data access pattern. The test suite passes and performance benchmarks show "
        "a forty percent improvement in query throughput under concurrent load."
    ),
}

VOICE = "af_heart"
LANG = "a"  # American English


def benchmark_cold_start():
    """Measure time to load the model from scratch."""
    print("\n=== Cold Start (model loading) ===")
    t0 = time.perf_counter()
    from kokoro import KPipeline
    pipeline = KPipeline(lang_code=LANG)
    # Force model load by running a dummy generation
    for _ in pipeline("test", voice=VOICE):
        pass
    elapsed = time.perf_counter() - t0
    print(f"  Cold start: {elapsed:.2f}s")
    return pipeline


def benchmark_warm_generation(pipeline):
    """Measure generation latency with a warm model."""
    print("\n=== Warm Generation Latency ===")
    print(f"  {'Length':<8} {'Chars':<6} {'Total (ms)':<12} {'First chunk (ms)':<18} {'RTF':<8}")
    print(f"  {'─'*8} {'─'*6} {'─'*12} {'─'*18} {'─'*8}")

    for label, text in TEXTS.items():
        # Warm up caches for this length
        for _ in pipeline(text, voice=VOICE):
            pass

        # Measure 3 runs
        totals = []
        first_chunks = []
        audio_durations = []

        for _ in range(3):
            chunks = []
            t0 = time.perf_counter()
            first_chunk_time = None

            for gs, ps, audio in pipeline(text, voice=VOICE, speed=1.0):
                if first_chunk_time is None:
                    first_chunk_time = time.perf_counter() - t0
                chunks.append(audio)

            total_time = time.perf_counter() - t0
            totals.append(total_time)
            first_chunks.append(first_chunk_time)

            # Calculate audio duration (24kHz sample rate)
            import numpy as np
            total_samples = sum(len(c) for c in chunks)
            audio_durations.append(total_samples / 24000)

        avg_total = sum(totals) / len(totals) * 1000
        avg_first = sum(first_chunks) / len(first_chunks) * 1000
        avg_audio_dur = sum(audio_durations) / len(audio_durations)
        avg_total_s = sum(totals) / len(totals)
        rtf = avg_total_s / avg_audio_dur if avg_audio_dur > 0 else float('inf')

        print(f"  {label:<8} {len(text):<6} {avg_total:>8.0f} ms  {avg_first:>12.0f} ms      {rtf:>6.3f}x")


def benchmark_playback(pipeline):
    """Measure end-to-end: generation + playback start."""
    print("\n=== End-to-End (generate + play) ===")

    text = TEXTS["medium"]
    import soundfile as sf
    import tempfile

    t0 = time.perf_counter()
    chunks = []
    for gs, ps, audio in pipeline(text, voice=VOICE):
        chunks.append(audio)

    import numpy as np
    full_audio = np.concatenate(chunks)

    # Write to temp file
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        sf.write(f.name, full_audio, 24000)
        wav_path = f.name

    gen_time = time.perf_counter() - t0

    # Play with afplay (macOS) — non-blocking just to measure startup
    play_start = time.perf_counter()
    proc = subprocess.Popen(["afplay", wav_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # Wait for it to finish so we get total time
    proc.wait()
    play_time = time.perf_counter() - play_start

    os.unlink(wav_path)

    print(f"  Generation:    {gen_time*1000:.0f} ms")
    print(f"  Playback:      {play_time:.2f}s (includes audio duration)")
    print(f"  Time-to-voice: {gen_time*1000:.0f} ms (user waits this long before hearing audio)")


def check_device():
    """Report which compute device will be used."""
    print("=== Device Info ===")
    import torch
    if torch.backends.mps.is_available():
        print(f"  Device: MPS (Apple Silicon GPU)")
        print(f"  PyTorch: {torch.__version__}")
    elif torch.cuda.is_available():
        print(f"  Device: CUDA ({torch.cuda.get_device_name()})")
    else:
        print(f"  Device: CPU")
    print(f"  Python: {sys.version.split()[0]}")


if __name__ == "__main__":
    check_device()
    pipeline = benchmark_cold_start()
    benchmark_warm_generation(pipeline)
    benchmark_playback(pipeline)
    print("\n=== Done ===")
