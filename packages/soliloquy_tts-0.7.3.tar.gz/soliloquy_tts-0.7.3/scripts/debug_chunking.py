#!/usr/bin/env python3
"""Debug tool for adaptive chunking. Shows batch sizes, buffer state, and WAV sizes.

Usage:
    python scripts/debug_chunking.py /path/to/file.md
    python scripts/debug_chunking.py /path/to/file.md --max-chunks 5  (stop after 5 chunks)
"""

import os
import sys
import time
import argparse

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"

# Redirect stdout during imports to avoid kokoro noise
old_stdout = sys.stdout
sys.stdout = sys.stderr


def main():
    parser = argparse.ArgumentParser(description="Debug adaptive chunking")
    parser.add_argument("file", help="Path to text/markdown file")
    parser.add_argument("--max-chunks", type=int, default=0, help="Stop after N chunks (0=all)")
    args = parser.parse_args()

    # Read and process file
    with open(args.file, "r", encoding="utf-8") as f:
        text = f.read()

    from soliloquy.server import _strip_markdown
    from soliloquy.chunking import split_sentences, adaptive_chunks, _normalize_text
    from soliloquy.audio import BufferState

    if args.file.endswith((".md", ".markdown")):
        text = _strip_markdown(text)

    # Show normalization
    normalized = _normalize_text(text)
    sys.stdout = sys.__stdout__

    sentences = split_sentences(text.strip(), lang="en-us")
    print(f"=== File: {args.file} ===")
    print(f"Raw size: {len(text)} chars")
    print(f"Sentences: {len(sentences)}")
    print(f"Avg sentence length: {sum(len(s) for s in sentences) / max(len(sentences), 1):.0f} chars")
    print()

    # Show first 5 sentences
    print("=== First 5 sentences ===")
    for i, s in enumerate(sentences[:5]):
        print(f"  [{i}] ({len(s)} chars) {s[:100]}{'...' if len(s) > 100 else ''}")
    print()

    # Now run adaptive chunking with a real pipeline
    print("Loading Kokoro model...")
    sys.stdout = sys.stderr
    from soliloquy.server import _get_pipeline, _ensure_spacy_model, DEFAULT_VOICE, DEFAULT_LANG
    _ensure_spacy_model()
    pipeline = _get_pipeline(DEFAULT_LANG)
    # Warmup
    for _ in pipeline("warmup", voice=DEFAULT_VOICE):
        pass
    sys.stdout = sys.__stdout__
    print("Model ready.")
    print()

    # Simulate the adaptive chunking with buffer tracking
    buffer = BufferState()
    chunk_num = 0
    total_samples = 0
    total_duration = 0.0

    print(f"{'Chunk':>5} | {'Buffer':>8} | {'Batch':>5} | {'Sentences':>9} | {'Samples':>10} | {'Duration':>8} | {'WAV Size':>10}")
    print("-" * 80)

    i = 0
    while i < len(sentences):
        buffered = buffer.seconds

        if buffered < 5.0:
            batch_size = 1
        elif buffered < 15.0:
            batch_size = 3
        else:
            batch_size = min(10, len(sentences) - i)

        # Build batch with min chars padding
        end = i + batch_size
        batch = " ".join(sentences[i:end])
        while len(batch) < 80 and end < len(sentences):
            end += 1
            batch = " ".join(sentences[i:end])

        actual_sentences = end - i
        i = end

        # Generate audio
        t0 = time.perf_counter()
        chunk_samples = 0
        for _gs, _ps, audio in pipeline(batch, voice=DEFAULT_VOICE, speed=1.0):
            chunk_samples += len(audio)
            buffer.add(len(audio))

        gen_time = time.perf_counter() - t0
        chunk_duration = chunk_samples / 24000
        total_samples += chunk_samples
        total_duration += chunk_duration
        wav_bytes = chunk_samples * 2 + 44  # 16-bit PCM + WAV header

        chunk_num += 1
        print(f"{chunk_num:>5} | {buffered:>7.1f}s | {batch_size:>5} | {actual_sentences:>9} | {chunk_samples:>10} | {chunk_duration:>7.1f}s | {wav_bytes/1024:>8.0f} KB")

        # In the real code, the player thread subtracts buffer duration
        # only after afplay finishes (which takes real-time seconds).
        # Generation is 10-20x faster than playback, so the buffer
        # accumulates rapidly. We do NOT subtract here to match
        # real behavior — the buffer only drains during playback.

        if args.max_chunks and chunk_num >= args.max_chunks:
            print(f"\n(Stopped after {args.max_chunks} chunks)")
            break

    print("-" * 80)
    print(f"Total: {chunk_num} chunks, {total_samples} samples, {total_duration:.1f}s audio")


if __name__ == "__main__":
    main()
