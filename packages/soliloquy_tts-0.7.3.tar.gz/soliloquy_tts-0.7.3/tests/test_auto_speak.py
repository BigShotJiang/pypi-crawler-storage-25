"""Tests for auto-speak toggle tool and endpoint."""

import json
from unittest.mock import patch, AsyncMock

import pytest

from soliloquy.setup import AUTO_SPEAK_FLAG


@pytest.fixture(autouse=True)
def use_tmp_flag(tmp_path, monkeypatch):
    """Redirect the auto-speak flag file to a temp directory."""
    sol_dir = tmp_path / ".soliloquy"
    flag_file = sol_dir / "auto-speak.enabled"
    monkeypatch.setattr("soliloquy.setup.AUTO_SPEAK_FLAG", flag_file)
    return flag_file


# --- auto_speak toggle tool ---


def test_auto_speak_toggle_on(use_tmp_flag):
    from soliloquy.server import auto_speak

    assert not use_tmp_flag.exists()
    result = auto_speak()
    assert "ON" in result
    assert use_tmp_flag.exists()


def test_auto_speak_toggle_off(use_tmp_flag):
    from soliloquy.server import auto_speak

    use_tmp_flag.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_flag.touch()
    result = auto_speak()
    assert "OFF" in result
    assert not use_tmp_flag.exists()


def test_auto_speak_toggle_roundtrip(use_tmp_flag):
    from soliloquy.server import auto_speak

    # OFF -> ON
    result1 = auto_speak()
    assert "ON" in result1
    assert use_tmp_flag.exists()

    # ON -> OFF
    result2 = auto_speak()
    assert "OFF" in result2
    assert not use_tmp_flag.exists()

    # OFF -> ON again
    result3 = auto_speak()
    assert "ON" in result3
    assert use_tmp_flag.exists()


# --- /auto-speak endpoint ---


@pytest.fixture
def make_request():
    """Factory for mock Starlette requests."""
    def _make(body: dict | None = None):
        request = AsyncMock()
        if body is not None:
            request.json = AsyncMock(return_value=body)
        else:
            request.json = AsyncMock(side_effect=Exception("no body"))
        return request
    return _make


@pytest.mark.anyio
async def test_auto_speak_endpoint_disabled(use_tmp_flag, make_request):
    from soliloquy.backend import _auto_speak

    assert not use_tmp_flag.exists()
    request = make_request({"last_assistant_message": "Hello world, this is a test."})
    response = await _auto_speak(request)
    assert response.body == b"auto-speak disabled"


@pytest.mark.anyio
async def test_auto_speak_endpoint_enabled_speaks(use_tmp_flag, make_request):
    from soliloquy.backend import _auto_speak

    use_tmp_flag.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_flag.touch()

    request = make_request({"last_assistant_message": "Hello world, this is a test response from Claude."})

    with patch("soliloquy.backend._auto_speak.__module__", "soliloquy.backend"), \
         patch("soliloquy.server._synthesize_and_play") as mock_play:
        response = await _auto_speak(request)

    assert response.body == b"speaking"
    mock_play.assert_called_once()


@pytest.mark.anyio
async def test_auto_speak_endpoint_empty_text(use_tmp_flag, make_request):
    from soliloquy.backend import _auto_speak

    use_tmp_flag.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_flag.touch()

    request = make_request({"last_assistant_message": ""})
    response = await _auto_speak(request)
    assert response.body == b"nothing to speak"


@pytest.mark.anyio
async def test_auto_speak_endpoint_short_text(use_tmp_flag, make_request):
    from soliloquy.backend import _auto_speak

    use_tmp_flag.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_flag.touch()

    request = make_request({"last_assistant_message": "OK"})
    response = await _auto_speak(request)
    assert response.body == b"too short"


@pytest.mark.anyio
async def test_auto_speak_endpoint_missing_key(use_tmp_flag, make_request):
    from soliloquy.backend import _auto_speak

    use_tmp_flag.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_flag.touch()

    request = make_request({"some_other_key": "value"})
    response = await _auto_speak(request)
    assert response.body == b"nothing to speak"


@pytest.mark.anyio
async def test_auto_speak_endpoint_malformed_body(use_tmp_flag, make_request):
    from soliloquy.backend import _auto_speak

    use_tmp_flag.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_flag.touch()

    request = make_request(None)  # raises on .json()
    response = await _auto_speak(request)
    assert response.body == b"nothing to speak"


@pytest.mark.anyio
async def test_auto_speak_endpoint_whitespace_only(use_tmp_flag, make_request):
    from soliloquy.backend import _auto_speak

    use_tmp_flag.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_flag.touch()

    request = make_request({"last_assistant_message": "   \n\n  "})
    response = await _auto_speak(request)
    assert response.body == b"nothing to speak"
