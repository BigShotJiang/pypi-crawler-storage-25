"""Tests for read_aloud tool and markdown stripping."""

import os

import pytest

from soliloquy.server import _strip_markdown


# --- Markdown stripping ---


def test_strip_headers():
    assert _strip_markdown("# Title") == "Title"
    assert _strip_markdown("## Subtitle") == "Subtitle"
    assert _strip_markdown("### Deep Header") == "Deep Header"


def test_strip_bold_italic():
    assert _strip_markdown("**bold text**") == "bold text"
    assert _strip_markdown("*italic text*") == "italic text"
    assert _strip_markdown("***bold italic***") == "bold italic"


def test_strip_links():
    assert _strip_markdown("[click here](https://example.com)") == "click here"


def test_strip_images():
    assert _strip_markdown("![alt text](image.png)") == "alt text"


def test_strip_inline_code():
    assert _strip_markdown("use `pip install`") == "use pip install"


def test_strip_code_fences():
    text = "before\n```python\nprint('hello')\n```\nafter"
    result = _strip_markdown(text)
    assert "print" not in result
    assert "before" in result
    assert "after" in result


def test_strip_horizontal_rules():
    text = "above\n---\nbelow"
    result = _strip_markdown(text)
    assert "---" not in result
    assert "above" in result
    assert "below" in result


def test_strip_blockquotes():
    assert _strip_markdown("> quoted text") == "quoted text"


def test_strip_list_markers():
    text = "- item one\n- item two\n* item three"
    result = _strip_markdown(text)
    assert "item one" in result
    assert "item two" in result
    assert "item three" in result
    assert "-" not in result
    assert "*" not in result


def test_strip_numbered_list():
    text = "1. first\n2. second"
    result = _strip_markdown(text)
    assert "first" in result
    assert "second" in result


def test_collapse_blank_lines():
    text = "line one\n\n\n\n\nline two"
    result = _strip_markdown(text)
    assert "\n\n\n" not in result
    assert "line one" in result
    assert "line two" in result


def test_strip_plain_text_unchanged():
    text = "Just a normal sentence with no markdown."
    assert _strip_markdown(text) == text


def test_strip_complex_markdown():
    text = """# Chapter One

The **brave** knight went to [the castle](https://castle.com).

> "Who goes there?" asked the guard.

He carried:
- A sword
- A shield
- A `magic scroll`

---

The end."""
    result = _strip_markdown(text)
    assert "Chapter One" in result
    assert "brave" in result
    assert "**" not in result
    assert "the castle" in result
    assert "https://castle.com" not in result
    assert "Who goes there?" in result
    assert ">" not in result.split("Who")[0]  # blockquote marker removed
    assert "A sword" in result
    assert "magic scroll" in result
    assert "`" not in result
    assert "The end." in result


# --- File reading validation ---


def test_read_aloud_file_not_found(tmp_path):
    """_validate_params is tested elsewhere; just verify file-not-found path."""
    from soliloquy.server import _validate_params
    # Validation passes for valid params
    assert _validate_params("af_heart", 1.0, "en-us") is None


def test_read_aloud_with_tmp_file(tmp_path):
    """Verify we can read a file and strip markdown."""
    md_file = tmp_path / "test.md"
    md_file.write_text("# Hello\n\nThis is **bold** text.")

    with open(str(md_file), "r") as f:
        text = f.read()

    result = _strip_markdown(text)
    assert "Hello" in result
    assert "This is bold text." in result
    assert "**" not in result
    assert "#" not in result
