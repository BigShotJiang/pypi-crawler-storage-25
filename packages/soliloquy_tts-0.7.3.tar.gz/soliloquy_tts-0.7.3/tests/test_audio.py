"""Tests for audio playback module (sounddevice backend)."""

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from soliloquy.audio import BufferState, PlaybackState, _playback, stop_playback


# --- BufferState ---


def test_buffer_state_add():
    buf = BufferState(sample_rate=24000)
    buf.add(24000)  # 1 second
    assert abs(buf.seconds - 1.0) < 0.001


def test_buffer_state_subtract():
    buf = BufferState(sample_rate=24000)
    buf.add(48000)  # 2 seconds
    buf.subtract(24000)  # subtract 1 second
    assert abs(buf.seconds - 1.0) < 0.001


def test_buffer_state_no_negative():
    buf = BufferState(sample_rate=24000)
    buf.subtract(24000)
    assert buf.seconds == 0.0


# --- PlaybackState ---


def test_playback_state_reset():
    state = PlaybackState()
    state.stop_event.set()
    state.is_playing = True
    state.stream = "fake"
    state.feeder_thread = "fake"
    state.reset()
    assert not state.stop_event.is_set()
    assert not state.is_playing
    assert state.stream is None
    assert state.feeder_thread is None


# --- stop_playback ---


def test_stop_playback_when_not_playing():
    _playback.reset()
    _playback.is_playing = False
    result = stop_playback()
    assert result is False


def test_stop_playback_aborts_stream():
    _playback.reset()
    _playback.is_playing = True

    mock_stream = MagicMock()
    _playback.stream = mock_stream
    _playback.feeder_thread = MagicMock()
    _playback.feeder_thread.is_alive.return_value = False

    result = stop_playback()
    assert result is True
    mock_stream.stop.assert_called_once()
    mock_stream.close.assert_called_once()


def test_stop_playback_joins_feeder():
    _playback.reset()
    _playback.is_playing = True
    _playback.stream = None

    mock_thread = MagicMock()
    mock_thread.is_alive.return_value = True
    _playback.feeder_thread = mock_thread

    stop_playback()
    mock_thread.join.assert_called_once()


def test_stop_playback_resets_state():
    _playback.reset()
    _playback.is_playing = True
    _playback.stream = MagicMock()
    _playback.feeder_thread = MagicMock()
    _playback.feeder_thread.is_alive.return_value = False

    stop_playback()
    assert not _playback.is_playing
    assert _playback.stream is None
    assert _playback.feeder_thread is None
    assert not _playback.stop_event.is_set()


# --- stream_play_audio ---


def test_stream_play_audio_blocking():
    """Blocking mode should play all chunks and return total samples."""
    from soliloquy.audio import stream_play_audio

    chunks = [np.zeros(2400, dtype=np.float32), np.zeros(4800, dtype=np.float32)]

    with patch("soliloquy.audio.sd.OutputStream") as MockStream:
        mock_instance = MagicMock()
        MockStream.return_value = mock_instance

        total = stream_play_audio(iter(chunks), blocking=True)

    assert total == 7200
    assert mock_instance.start.called
    assert mock_instance.write.call_count == 2


def test_stream_play_audio_nonblocking_returns_immediately():
    """Non-blocking mode should return 0 immediately and set is_playing."""
    from soliloquy.audio import stream_play_audio

    _playback.reset()

    with patch("soliloquy.audio.sd.OutputStream") as MockStream:
        mock_instance = MagicMock()
        MockStream.return_value = mock_instance

        # Use a slow generator to ensure we return before it finishes
        def slow_chunks():
            import time
            time.sleep(0.1)
            yield np.zeros(2400, dtype=np.float32)

        result = stream_play_audio(slow_chunks(), blocking=False)

    assert result == 0
    assert _playback.is_playing is True

    # Clean up
    import time
    time.sleep(0.3)
    _playback.reset()
