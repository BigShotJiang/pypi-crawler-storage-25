"""Tests to verify core Soliloquy works without the dialogue module.

The dialogue module (multi-voice dialogue parsing, MLX correction,
annotate_dialogue tool) is an optional feature. Core functionality
(speak, read_aloud, stop, auto_speak, list_voices) must work even
if dialogue.py is not present.
"""

import importlib
import sys
from unittest.mock import patch

import pytest


@pytest.fixture()
def without_dialogue():
    """Temporarily make soliloquy.dialogue unimportable."""
    # Save and remove any cached dialogue imports
    cached = {}
    for key in list(sys.modules.keys()):
        if 'soliloquy.dialogue' in key:
            cached[key] = sys.modules.pop(key)

    # Make importlib.import_module fail for soliloquy.dialogue
    real_import_module = importlib.import_module

    def mock_import_module(name, *args, **kwargs):
        if 'dialogue' in name:
            raise ImportError(f"No module named '{name}' (blocked by test)")
        return real_import_module(name, *args, **kwargs)

    with patch.object(importlib, 'import_module', side_effect=mock_import_module):
        yield

    # Restore cached modules
    sys.modules.update(cached)


class TestDialogueDecoupling:
    """Verify core Soliloquy is not broken by absence of dialogue module."""

    def test_has_dialogue_support_returns_false_without_module(self, without_dialogue):
        """_has_dialogue_support() should return False when dialogue is missing."""
        from soliloquy.server import _has_dialogue_support
        assert _has_dialogue_support() is False

    def test_has_dialogue_support_returns_true_with_module(self):
        """_has_dialogue_support() should return True when dialogue is present."""
        from soliloquy.server import _has_dialogue_support
        result = _has_dialogue_support()
        try:
            import soliloquy.dialogue  # noqa: F401
            assert result is True
        except ImportError:
            pytest.skip("dialogue module not installed")

    def test_core_tools_importable(self):
        """Core MCP tools should always be importable."""
        from soliloquy.server import speak, read_aloud, stop, auto_speak, list_voices
        assert callable(speak)
        assert callable(read_aloud)
        assert callable(stop)
        assert callable(auto_speak)
        assert callable(list_voices)

    def test_annotate_dialogue_graceful_without_module(self, without_dialogue):
        """annotate_dialogue should return a helpful message, not crash."""
        from soliloquy.server import annotate_dialogue
        result = annotate_dialogue(path="/tmp/fake.md")
        assert "not installed" in result.lower() or "not available" in result.lower()

    def test_read_aloud_single_voice_without_module(self, without_dialogue, tmp_path):
        """read_aloud should fall back to single-voice without dialogue module."""
        from soliloquy.server import _has_dialogue_support
        assert _has_dialogue_support() is False
        # Core read_aloud should still work — just won't support characters
