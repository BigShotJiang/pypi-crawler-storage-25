"""Tests for text segmentation and adaptive chunk sizing."""

from unittest.mock import MagicMock

import numpy as np
import pytest

from soliloquy.audio import BufferState
from soliloquy.chunking import MIN_CHUNK_CHARS, _normalize_text, adaptive_chunks, split_sentences


# --- split_sentences ---


def test_split_sentences_basic():
    result = split_sentences("Hello world. How are you?")
    assert len(result) == 2
    assert result[0] == "Hello world."
    assert result[1] == "How are you?"


def test_split_sentences_abbreviations():
    result = split_sentences("Dr. Smith went to D.C. for a meeting.")
    assert len(result) == 1


def test_split_sentences_empty():
    assert split_sentences("") == []
    assert split_sentences("   ") == []


def test_split_sentences_single():
    result = split_sentences("Hello world")
    assert result == ["Hello world"]


def test_split_sentences_multiline_same_paragraph():
    # Single newlines within a paragraph get joined
    result = split_sentences("Line one.\nLine two.")
    assert len(result) == 2
    assert result[0] == "Line one."
    assert result[1] == "Line two."


def test_split_sentences_paragraph_break_preserved():
    # Double newlines are paragraph breaks — preserved
    result = split_sentences("Paragraph one.\n\nParagraph two.")
    assert len(result) == 2


def test_split_sentences_multiple():
    text = "First sentence. Second sentence. Third sentence. Fourth sentence."
    result = split_sentences(text)
    assert len(result) == 4


def test_split_sentences_non_english_fallback():
    result = split_sentences("Bonjour le monde. Comment allez-vous?", lang="fr")
    assert len(result) == 2


def test_split_sentences_question_and_exclamation():
    result = split_sentences("What happened? I can't believe it! This is amazing.")
    assert len(result) == 3


# --- adaptive_chunks ---


def _make_mock_pipeline(chunk_per_call=1):
    """Create a mock pipeline that yields dummy audio for each call."""
    def mock_pipeline(text, voice=None, speed=None):
        for _ in range(chunk_per_call):
            yield ("gs", "ps", np.zeros(2400, dtype=np.float32))
    return mock_pipeline


def test_adaptive_chunks_starving_buffer():
    """When buffer is empty (<5s), should use batch_size=1."""
    long_sent = "This is a fairly long sentence that should exceed the minimum chunk character threshold on its own."
    sentences = [long_sent, long_sent, long_sent]
    pipeline = _make_mock_pipeline()
    buffer = BufferState()  # 0 seconds buffered

    chunks = list(adaptive_chunks(sentences, pipeline, "af_heart", 1.0, buffer))
    assert len(chunks) == 3


def test_adaptive_chunks_healthy_buffer():
    """When buffer has 15+ seconds, should use larger batch sizes (up to 10)."""
    long = "This is a sentence that is long enough to exceed the minimum chunk character threshold."
    sentences = [long] * 10
    pipeline = _make_mock_pipeline()
    buffer = BufferState()

    # Simulate 20 seconds of buffered audio
    buffer.add(20 * 24000)

    chunks = list(adaptive_chunks(sentences, pipeline, "af_heart", 1.0, buffer))
    # With healthy buffer, batches up to 10 sentences → 10 sentences = 1 batch
    assert len(chunks) == 1


def test_adaptive_chunks_building_buffer():
    """When buffer has 5-15s, should use batch_size=3."""
    long = "This is a sentence that is long enough to exceed the minimum chunk character threshold."
    sentences = [long] * 9
    pipeline = _make_mock_pipeline()
    buffer = BufferState()

    # Simulate 10 seconds of buffered audio
    buffer.add(10 * 24000)

    chunks = list(adaptive_chunks(sentences, pipeline, "af_heart", 1.0, buffer))
    # batch_size=3 → 9 sentences = 3 batches
    assert len(chunks) == 3


def test_adaptive_chunks_all_sentences_processed():
    """Every sentence should be synthesized regardless of batch sizing."""
    sentences = ["A.", "B.", "C.", "D.", "E."]
    calls = []

    def tracking_pipeline(text, voice=None, speed=None):
        calls.append(text)
        yield ("gs", "ps", np.zeros(2400, dtype=np.float32))

    buffer = BufferState()
    list(adaptive_chunks(sentences, tracking_pipeline, "af_heart", 1.0, buffer))

    # All text should appear in the calls
    combined = " ".join(calls)
    for s in sentences:
        assert s in combined


def test_adaptive_chunks_empty_sentences():
    """Empty sentence list should yield nothing."""
    pipeline = _make_mock_pipeline()
    buffer = BufferState()
    chunks = list(adaptive_chunks([], pipeline, "af_heart", 1.0, buffer))
    assert chunks == []


def test_adaptive_chunks_short_sentences_padded():
    """Short sentences should be combined to meet MIN_CHUNK_CHARS."""
    sentences = ["Hi.", "Hey.", "Yo.", "Ok.", "Sure.", "Yes.", "No.", "Fine.", "Good.", "Great."]
    calls = []

    def tracking_pipeline(text, voice=None, speed=None):
        calls.append(text)
        yield ("gs", "ps", np.zeros(2400, dtype=np.float32))

    buffer = BufferState()
    list(adaptive_chunks(sentences, tracking_pipeline, "af_heart", 1.0, buffer))

    # Each call should be at least MIN_CHUNK_CHARS (or use all remaining)
    for call in calls[:-1]:
        assert len(call) >= MIN_CHUNK_CHARS or call == calls[-1]

    # All sentences should be present
    combined = " ".join(calls)
    for s in sentences:
        assert s in combined


# --- _normalize_text ---


def test_normalize_joins_mid_sentence_breaks():
    text = "the lodge had once more become\nthe unofficial meeting spot"
    result = _normalize_text(text)
    assert "\n" not in result
    assert "become the unofficial" in result


def test_normalize_preserves_paragraph_breaks():
    text = "End of paragraph one.\n\nStart of paragraph two."
    result = _normalize_text(text)
    assert "\n\n" in result
    assert "End of paragraph one." in result
    assert "Start of paragraph two." in result


def test_normalize_collapses_multiple_spaces():
    text = "word   word"
    result = _normalize_text(text)
    assert "  " not in result


def test_normalize_ebook_style_text():
    text = (
        "Jake didn't want those affiliated with large factions to take part,\n"
        "as he feared people would feel obligated to report the details of their\n"
        "discussion to their higher-ups.\n"
        "\n"
        "For now, though, the meeting was merely about the state of the\n"
        "Milky Way and their plans going forward."
    )
    result = _normalize_text(text)
    # Should be two paragraphs
    paragraphs = result.split("\n\n")
    assert len(paragraphs) == 2
    # No mid-sentence line breaks
    assert "\n" not in paragraphs[0]
    assert "\n" not in paragraphs[1]
