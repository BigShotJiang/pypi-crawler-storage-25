"""Tests for the lock file protocol."""

import json
import os
from unittest.mock import patch

import httpx
import pytest

from soliloquy.lock import (
    LOCK_FILE,
    LockInfo,
    find_free_port,
    is_backend_alive,
    read_lock,
    remove_lock,
    write_lock,
)


@pytest.fixture(autouse=True)
def use_tmp_lock(tmp_path, monkeypatch):
    """Redirect lock file operations to a temp directory."""
    lock_dir = tmp_path / ".soliloquy"
    lock_file = lock_dir / "backend.lock"
    monkeypatch.setattr("soliloquy.lock.LOCK_DIR", lock_dir)
    monkeypatch.setattr("soliloquy.lock.LOCK_FILE", lock_file)
    return lock_file


# --- read_lock ---


def test_read_lock_missing_file():
    assert read_lock() is None


def test_read_lock_valid(use_tmp_lock):
    use_tmp_lock.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_lock.write_text(json.dumps({"pid": 123, "port": 8000, "started": "2026-01-01T00:00:00"}))
    lock = read_lock()
    assert lock is not None
    assert lock.pid == 123
    assert lock.port == 8000
    assert lock.started == "2026-01-01T00:00:00"


def test_read_lock_corrupt_json(use_tmp_lock):
    use_tmp_lock.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_lock.write_text("not json")
    assert read_lock() is None


def test_read_lock_missing_keys(use_tmp_lock):
    use_tmp_lock.parent.mkdir(parents=True, exist_ok=True)
    use_tmp_lock.write_text(json.dumps({"pid": 123}))
    assert read_lock() is None


# --- write_lock ---


def test_write_lock_creates_file(use_tmp_lock):
    write_lock(pid=999, port=5000)
    assert use_tmp_lock.exists()
    data = json.loads(use_tmp_lock.read_text())
    assert data["pid"] == 999
    assert data["port"] == 5000
    assert "started" in data


def test_write_lock_race_protection(use_tmp_lock):
    write_lock(pid=1, port=1000)
    with pytest.raises(FileExistsError):
        write_lock(pid=2, port=2000)


# --- remove_lock ---


def test_remove_lock_deletes_file(use_tmp_lock):
    write_lock(pid=1, port=1000)
    assert use_tmp_lock.exists()
    remove_lock()
    assert not use_tmp_lock.exists()


def test_remove_lock_missing_file():
    remove_lock()  # should not raise


# --- is_backend_alive ---


def test_is_backend_alive_true():
    lock = LockInfo(pid=os.getpid(), port=9999, started="2026-01-01T00:00:00")
    with patch("soliloquy.lock.httpx.get") as mock_get:
        mock_get.return_value.status_code = 200
        assert is_backend_alive(lock) is True


def test_is_backend_alive_dead_pid():
    lock = LockInfo(pid=99999999, port=9999, started="2026-01-01T00:00:00")
    assert is_backend_alive(lock) is False


def test_is_backend_alive_health_timeout():
    lock = LockInfo(pid=os.getpid(), port=9999, started="2026-01-01T00:00:00")
    with patch("soliloquy.lock.httpx.get", side_effect=httpx.TimeoutException("")):
        assert is_backend_alive(lock) is False


def test_is_backend_alive_health_connection_error():
    lock = LockInfo(pid=os.getpid(), port=9999, started="2026-01-01T00:00:00")
    with patch("soliloquy.lock.httpx.get", side_effect=httpx.ConnectError("")):
        assert is_backend_alive(lock) is False


# --- find_free_port ---


def test_find_free_port_returns_valid():
    port = find_free_port()
    assert isinstance(port, int)
    assert port > 0
    assert port < 65536
