"""Tests for the speech normalization pipeline."""

from soliloquy.chunking import (
    _handle_code_blocks,
    _handle_inline_code,
    _handle_lists,
    _handle_markdown,
    _handle_tables,
    _normalize_symbols,
    _optimize_for_speech,
    normalize_for_speech,
)


# --- Code block handling ---


class TestCodeBlocks:
    def test_replaces_code_block_with_cue(self):
        text = "Here's an example:\n```python\nprint('hi')\n```\nThat's it."
        result = _handle_code_blocks(text)
        assert "print" not in result
        assert "code" in result.lower()
        assert "That's it." in result

    def test_contextual_cue_for_example(self):
        text = "Here's an example:\n```\nsome code\n```"
        result = _handle_code_blocks(text)
        assert "See the code." in result

    def test_contextual_cue_for_command(self):
        text = "Run this command:\n```\npip install foo\n```"
        result = _handle_code_blocks(text)
        assert "command" in result.lower()

    def test_generic_cue_without_context(self):
        text = "Check this out.\n```\nfoo bar\n```"
        result = _handle_code_blocks(text)
        assert "snippet" in result.lower() or "code" in result.lower()

    def test_mostly_code_response(self):
        code = "```python\n" + "x = 1\n" * 50 + "```"
        text = "Here.\n" + code
        result = _handle_code_blocks(text)
        assert "x = 1" not in result
        assert "code" in result.lower()

    def test_multiple_code_blocks(self):
        text = "First:\n```\naaa\n```\nThen:\n```\nbbb\n```"
        result = _handle_code_blocks(text)
        assert "aaa" not in result
        assert "bbb" not in result

    def test_no_code_blocks_unchanged(self):
        text = "Just regular text with no code."
        assert _handle_code_blocks(text) == text


# --- Inline code handling ---


class TestInlineCode:
    def test_strips_backticks(self):
        assert "hello" in _handle_inline_code("`hello`")

    def test_replaces_underscores_with_spaces(self):
        result = _handle_inline_code("`some_function`")
        assert "some function" in result
        assert "_" not in result

    def test_removes_trailing_parens(self):
        result = _handle_inline_code("`my_func()`")
        assert "my func" in result
        assert "()" not in result

    def test_preserves_regular_text(self):
        text = "No inline code here."
        assert _handle_inline_code(text) == text


# --- Markdown stripping ---


class TestMarkdown:
    def test_removes_headers(self):
        assert _handle_markdown("# Title") == "Title"
        assert _handle_markdown("### Section") == "Section"

    def test_removes_bold(self):
        assert "important" in _handle_markdown("**important**")
        assert "**" not in _handle_markdown("**important**")

    def test_removes_italic(self):
        assert "emphasis" in _handle_markdown("*emphasis*")

    def test_converts_links_to_text(self):
        result = _handle_markdown("[click here](https://example.com)")
        assert "click here" in result
        assert "https" not in result

    def test_removes_images(self):
        result = _handle_markdown("![alt text](image.png)")
        assert "alt text" in result
        assert "image.png" not in result

    def test_removes_blockquotes(self):
        result = _handle_markdown("> quoted text")
        assert "quoted text" in result
        assert ">" not in result

    def test_horizontal_rule_becomes_pause(self):
        result = _handle_markdown("---")
        assert "---" not in result


# --- Table handling ---


class TestTables:
    def test_replaces_table_with_summary(self):
        table = "| A | B |\n|---|---|\n| 1 | 2 |\n| 3 | 4 |\n"
        result = _handle_tables(table)
        assert "table" in result.lower()
        assert "|" not in result
        assert "2 rows" in result

    def test_no_table_unchanged(self):
        text = "Just regular text."
        assert _handle_tables(text) == text

    def test_table_embedded_in_text(self):
        text = "Here's the data:\n| X | Y |\n|---|---|\n| a | b |\nEnd."
        result = _handle_tables(text)
        assert "table" in result.lower()
        assert "End." in result


# --- List handling ---


class TestLists:
    def test_unordered_list_enumeration(self):
        text = "- First item\n- Second item\n- Third item"
        result = _handle_lists(text)
        assert "First, First item" in result
        assert "Second, Second item" in result
        assert "Third, Third item" in result

    def test_ordered_list_enumeration(self):
        text = "1. Alpha\n2. Beta\n3. Gamma"
        result = _handle_lists(text)
        assert "First, Alpha" in result
        assert "Second, Beta" in result
        assert "Third, Gamma" in result

    def test_resets_counter_between_lists(self):
        text = "- A\n- B\n\nSome text.\n\n- C\n- D"
        result = _handle_lists(text)
        assert result.count("First,") == 2

    def test_no_list_unchanged(self):
        text = "Just a regular paragraph."
        assert _handle_lists(text) == text


# --- Symbol normalization ---


class TestSymbols:
    def test_arrow_to_speech(self):
        assert "to" in _normalize_symbols("A \u2192 B")

    def test_left_arrow_to_speech(self):
        assert "from" in _normalize_symbols("A \u2190 B")

    def test_fat_arrow(self):
        assert "becomes" in _normalize_symbols("A => B")

    def test_comparison_operators(self):
        assert "at least" in _normalize_symbols(">=5")
        assert "at most" in _normalize_symbols("<=10")
        assert "is not" in _normalize_symbols("!=0")
        assert "equals" in _normalize_symbols("==true")

    def test_logical_operators(self):
        assert "and" in _normalize_symbols("A && B")
        assert "or" in _normalize_symbols("A || B")

    def test_url_simplified(self):
        result = _normalize_symbols("Visit https://example.com/foo/bar for more.")
        assert "https" not in result
        assert "link" in result

    def test_technical_units(self):
        result = _normalize_symbols("24kHz sample rate")
        assert "kilohertz" in result

    def test_unit_milliseconds(self):
        result = _normalize_symbols("takes 100ms")
        assert "milliseconds" in result

    def test_unit_gigabytes(self):
        result = _normalize_symbols("about 2GB")
        assert "gigabytes" in result

    def test_approximation(self):
        assert "about 5" in _normalize_symbols("~5 seconds")

    def test_pipe_characters_removed(self):
        result = _normalize_symbols("a | b | c")
        assert "|" not in result


# --- Speech optimization ---


class TestSpeechOptimization:
    def test_parenthetical_acronym(self):
        result = _optimize_for_speech("MCP (Model Context Protocol)")
        assert "MCP, or Model Context Protocol," in result

    def test_collapses_blank_lines(self):
        result = _optimize_for_speech("A\n\n\n\n\nB")
        assert "\n\n\n" not in result
        assert "A" in result
        assert "B" in result


# --- Full pipeline ---


class TestNormalizeForSpeech:
    def test_full_pipeline_strips_code(self):
        text = "Here's how:\n```python\nprint('hi')\n```\nDone."
        result = normalize_for_speech(text)
        assert "print" not in result
        assert "Done." in result

    def test_full_pipeline_handles_table(self):
        text = "Results:\n| A | B |\n|---|---|\n| 1 | 2 |\n"
        result = normalize_for_speech(text)
        assert "|" not in result
        assert "table" in result.lower()

    def test_full_pipeline_cleans_arrows(self):
        result = normalize_for_speech("A \u2192 B")
        assert "\u2192" not in result
        assert "to" in result

    def test_full_pipeline_naturalizes_lists(self):
        text = "Steps:\n- Do A\n- Do B\n- Do C"
        result = normalize_for_speech(text)
        assert "First," in result
        assert "-" not in result

    def test_full_pipeline_handles_inline_code(self):
        result = normalize_for_speech("Call `my_function()` to start.")
        assert "`" not in result
        assert "my function" in result

    def test_full_pipeline_handles_mixed_content(self):
        text = (
            "# Setup Guide\n\n"
            "Install with `pip install soliloquy-tts`.\n\n"
            "Then run:\n```bash\nsoliloquy\n```\n\n"
            "Features:\n"
            "- 28 voices\n"
            "- ~2GB install size\n"
            "- Supports en-us, en-gb, ja, zh\n"
        )
        result = normalize_for_speech(text)
        assert "```" not in result
        assert "`" not in result
        assert "#" not in result
        assert "First," in result
        assert "about 2" in result

    def test_empty_string(self):
        assert normalize_for_speech("") == ""

    def test_plain_text_mostly_unchanged(self):
        text = "This is a simple sentence with no special formatting."
        result = normalize_for_speech(text)
        assert "simple sentence" in result
