"""Tests for voice, speed, and language validation logic.

Imports constants directly from server.py. Note: importing server.py
triggers `from kokoro import KPipeline` which loads torch — these tests
will be slower than the lock tests but still don't load the model.
"""

import re

import pytest

from soliloquy.server import DEFAULT_LANG, DEFAULT_VOICE, LANG_MAP, VOICES


# --- Constants integrity ---


def test_voices_count():
    assert len(VOICES) == 28


def test_voices_naming_pattern():
    pattern = re.compile(r"^[ab][fm]_\w+$")
    for voice in VOICES:
        assert pattern.match(voice), f"Voice '{voice}' doesn't match [ab][fm]_* pattern"


def test_lang_map_count():
    assert len(LANG_MAP) == 9


def test_lang_map_codes_are_single_char():
    for lang, code in LANG_MAP.items():
        assert len(code) == 1, f"Lang code for '{lang}' should be single char, got '{code}'"


def test_default_voice_in_voices():
    assert DEFAULT_VOICE in VOICES


def test_default_lang_in_lang_map():
    assert DEFAULT_LANG in LANG_MAP


# --- Voice validation ---


def test_valid_voice_names():
    valid = ["af_heart", "am_adam", "bf_alice", "bm_daniel"]
    for v in valid:
        assert v in VOICES


def test_invalid_voice_not_in_set():
    assert "invalid_voice" not in VOICES
    assert "af_unknown" not in VOICES
    assert "" not in VOICES


# --- Speed validation ---


@pytest.mark.parametrize("speed", [0.5, 1.0, 1.5, 2.0])
def test_valid_speed(speed):
    assert 0.5 <= speed <= 2.0


@pytest.mark.parametrize("speed", [0.0, 0.49, 2.01, 3.0, -1.0])
def test_invalid_speed(speed):
    assert not (0.5 <= speed <= 2.0)


# --- Language validation ---


@pytest.mark.parametrize("lang", ["en-us", "en-gb", "ja", "zh", "es", "fr", "hi", "it", "pt-br"])
def test_valid_languages(lang):
    assert lang in LANG_MAP


def test_invalid_language():
    assert "de" not in LANG_MAP
    assert "kr" not in LANG_MAP
    assert "" not in LANG_MAP
