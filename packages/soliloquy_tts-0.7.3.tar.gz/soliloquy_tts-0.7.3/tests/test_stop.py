"""Tests for async playback and stop command."""

import threading
from unittest.mock import MagicMock

import numpy as np
import pytest

from soliloquy.audio import BufferState, PlaybackState, _playback, stop_playback


# --- PlaybackState ---


def test_playback_state_reset():
    state = PlaybackState()
    state.stop_event.set()
    state.is_playing = True
    state.stream = "fake"
    state.feeder_thread = "fake"
    state.reset()
    assert not state.stop_event.is_set()
    assert not state.is_playing
    assert state.stream is None
    assert state.feeder_thread is None


# --- stop_playback ---


def test_stop_playback_when_not_playing():
    _playback.reset()
    _playback.is_playing = False
    result = stop_playback()
    assert result is False


def test_stop_playback_aborts_and_closes_stream():
    _playback.reset()
    _playback.is_playing = True

    mock_stream = MagicMock()
    _playback.stream = mock_stream
    _playback.feeder_thread = MagicMock()
    _playback.feeder_thread.is_alive.return_value = False

    result = stop_playback()
    assert result is True
    mock_stream.stop.assert_called_once()
    mock_stream.close.assert_called_once()


def test_stop_event_is_set_on_stop():
    _playback.reset()
    _playback.is_playing = True
    _playback.stream = MagicMock()
    _playback.feeder_thread = MagicMock()
    _playback.feeder_thread.is_alive.return_value = False

    stop_playback()
    # After reset, stop_event is cleared
    assert not _playback.stop_event.is_set()


# --- Adaptive chunks with stop_event ---


def test_adaptive_chunks_stops_on_event():
    from soliloquy.chunking import adaptive_chunks

    long = "This is a sentence that is long enough to exceed the minimum chunk character threshold."
    sentences = [long] * 10

    def mock_pipeline(text, voice=None, speed=None):
        yield ("gs", "ps", np.zeros(2400, dtype=np.float32))

    buffer = BufferState()
    stop_event = threading.Event()
    stop_event.set()  # pre-set — should yield nothing

    chunks = list(adaptive_chunks(sentences, mock_pipeline, "af_heart", 1.0, buffer, stop_event))
    assert len(chunks) == 0


def test_adaptive_chunks_stops_mid_iteration():
    from soliloquy.chunking import adaptive_chunks

    long = "This is a sentence that is long enough to exceed the minimum chunk character threshold."
    sentences = [long] * 10
    call_count = 0

    stop_event = threading.Event()

    def mock_pipeline(text, voice=None, speed=None):
        nonlocal call_count
        call_count += 1
        if call_count >= 2:
            stop_event.set()  # stop after second call
        yield ("gs", "ps", np.zeros(2400, dtype=np.float32))

    buffer = BufferState()

    chunks = list(adaptive_chunks(sentences, mock_pipeline, "af_heart", 1.0, buffer, stop_event))
    assert len(chunks) < 10
    assert len(chunks) >= 2
