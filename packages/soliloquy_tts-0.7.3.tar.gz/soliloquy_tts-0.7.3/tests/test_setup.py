"""Tests for the one-command setup module."""

import json
import stat
from unittest.mock import patch, MagicMock

import pytest

from soliloquy.setup import (
    HOOK_SCRIPT_CONTENT,
    _check_claude_cli,
    _configure_hook,
    _register_mcp,
    _remove_hook,
    _remove_soliloquy_dir,
    _unregister_mcp,
    _write_hook_script,
)


@pytest.fixture(autouse=True)
def use_tmp_paths(tmp_path, monkeypatch):
    """Redirect all file operations to a temp directory."""
    sol_dir = tmp_path / ".soliloquy"
    hook_script = sol_dir / "auto-speak-hook.sh"
    flag_file = sol_dir / "auto-speak.enabled"
    claude_dir = tmp_path / ".claude"
    settings_file = claude_dir / "settings.json"

    monkeypatch.setattr("soliloquy.setup.SOLILOQUY_DIR", sol_dir)
    monkeypatch.setattr("soliloquy.setup.HOOK_SCRIPT", hook_script)
    monkeypatch.setattr("soliloquy.setup.AUTO_SPEAK_FLAG", flag_file)
    monkeypatch.setattr("soliloquy.setup.CLAUDE_SETTINGS", settings_file)

    return {
        "sol_dir": sol_dir,
        "hook_script": hook_script,
        "flag_file": flag_file,
        "claude_dir": claude_dir,
        "settings_file": settings_file,
    }


# --- _check_claude_cli ---


def test_check_claude_cli_found():
    with patch("soliloquy.setup.shutil.which", return_value="/usr/local/bin/claude"):
        assert _check_claude_cli() is True


def test_check_claude_cli_missing():
    with patch("soliloquy.setup.shutil.which", return_value=None):
        assert _check_claude_cli() is False


# --- _register_mcp ---


def test_register_mcp_already_registered():
    result = MagicMock()
    result.stdout = "soliloquy  user  uvx soliloquy-tts"
    with patch("soliloquy.setup.subprocess.run", return_value=result):
        assert _register_mcp() is True


def test_register_mcp_success():
    list_result = MagicMock()
    list_result.stdout = ""
    add_result = MagicMock()
    add_result.returncode = 0

    with patch("soliloquy.setup.subprocess.run", side_effect=[list_result, add_result]):
        assert _register_mcp() is True


def test_register_mcp_failure():
    list_result = MagicMock()
    list_result.stdout = ""
    add_result = MagicMock()
    add_result.returncode = 1
    add_result.stderr = "some error"

    with patch("soliloquy.setup.subprocess.run", side_effect=[list_result, add_result]):
        assert _register_mcp() is False


# --- _write_hook_script ---


def test_write_hook_script_creates_file(use_tmp_paths):
    assert _write_hook_script() is True
    script = use_tmp_paths["hook_script"]
    assert script.exists()
    assert script.read_text() == HOOK_SCRIPT_CONTENT


def test_write_hook_script_is_executable(use_tmp_paths):
    _write_hook_script()
    script = use_tmp_paths["hook_script"]
    assert script.stat().st_mode & stat.S_IEXEC


def test_write_hook_script_creates_parent_dir(use_tmp_paths):
    assert not use_tmp_paths["sol_dir"].exists()
    _write_hook_script()
    assert use_tmp_paths["sol_dir"].is_dir()


# --- _configure_hook ---


def test_configure_hook_creates_settings_from_scratch(use_tmp_paths):
    assert _configure_hook() is True

    settings = json.loads(use_tmp_paths["settings_file"].read_text())
    assert "hooks" in settings
    assert "Stop" in settings["hooks"]
    assert len(settings["hooks"]["Stop"]) == 1

    hook = settings["hooks"]["Stop"][0]["hooks"][0]
    assert hook["type"] == "command"
    assert "auto-speak-hook.sh" in hook["command"]
    assert hook["timeout"] == 5


def test_configure_hook_preserves_existing_settings(use_tmp_paths):
    # Pre-existing settings with other keys
    existing = {"permissions": {"allow": ["Read"]}, "theme": "dark"}
    use_tmp_paths["claude_dir"].mkdir(parents=True, exist_ok=True)
    use_tmp_paths["settings_file"].write_text(json.dumps(existing))

    _configure_hook()

    settings = json.loads(use_tmp_paths["settings_file"].read_text())
    assert settings["permissions"] == {"allow": ["Read"]}
    assert settings["theme"] == "dark"
    assert "hooks" in settings


def test_configure_hook_preserves_existing_hooks(use_tmp_paths):
    existing = {
        "hooks": {
            "PreToolUse": [{"matcher": "", "hooks": [{"type": "command", "command": "echo hi"}]}],
        }
    }
    use_tmp_paths["claude_dir"].mkdir(parents=True, exist_ok=True)
    use_tmp_paths["settings_file"].write_text(json.dumps(existing))

    _configure_hook()

    settings = json.loads(use_tmp_paths["settings_file"].read_text())
    assert "PreToolUse" in settings["hooks"]
    assert "Stop" in settings["hooks"]


def test_configure_hook_already_configured(use_tmp_paths):
    existing = {
        "hooks": {
            "Stop": [{
                "matcher": "",
                "hooks": [{"type": "command", "command": "/home/user/.soliloquy/auto-speak-hook.sh", "timeout": 5}],
            }]
        }
    }
    use_tmp_paths["claude_dir"].mkdir(parents=True, exist_ok=True)
    use_tmp_paths["settings_file"].write_text(json.dumps(existing))

    assert _configure_hook() is True

    # Should not duplicate
    settings = json.loads(use_tmp_paths["settings_file"].read_text())
    assert len(settings["hooks"]["Stop"]) == 1


def test_configure_hook_idempotent(use_tmp_paths):
    _configure_hook()
    _configure_hook()

    settings = json.loads(use_tmp_paths["settings_file"].read_text())
    assert len(settings["hooks"]["Stop"]) == 1


def test_configure_hook_corrupt_settings_overwritten(use_tmp_paths):
    use_tmp_paths["claude_dir"].mkdir(parents=True, exist_ok=True)
    use_tmp_paths["settings_file"].write_text("not valid json!!!")

    assert _configure_hook() is True
    settings = json.loads(use_tmp_paths["settings_file"].read_text())
    assert "hooks" in settings


# --- run_setup ---


def test_run_setup_full_flow(use_tmp_paths):
    from soliloquy.setup import run_setup

    with patch("soliloquy.setup._check_claude_cli", return_value=True), \
         patch("soliloquy.setup._register_mcp", return_value=True), \
         patch("soliloquy.setup._write_hook_script", return_value=True), \
         patch("soliloquy.setup._configure_hook", return_value=True):
        run_setup()  # should not raise


def test_run_setup_exits_without_claude_cli(use_tmp_paths):
    with patch("soliloquy.setup._check_claude_cli", return_value=False), \
         pytest.raises(SystemExit):
        from soliloquy.setup import run_setup
        run_setup()


# --- _unregister_mcp ---


def test_unregister_mcp_not_registered():
    result = MagicMock()
    result.stdout = ""
    with patch("soliloquy.setup.subprocess.run", return_value=result):
        assert _unregister_mcp() is True


def test_unregister_mcp_success():
    list_result = MagicMock()
    list_result.stdout = "soliloquy  user  uvx soliloquy-tts"
    remove_result = MagicMock()
    remove_result.returncode = 0

    with patch("soliloquy.setup.subprocess.run", side_effect=[list_result, remove_result]):
        assert _unregister_mcp() is True


def test_unregister_mcp_failure():
    list_result = MagicMock()
    list_result.stdout = "soliloquy  user  uvx soliloquy-tts"
    remove_result = MagicMock()
    remove_result.returncode = 1
    remove_result.stderr = "some error"

    with patch("soliloquy.setup.subprocess.run", side_effect=[list_result, remove_result]):
        assert _unregister_mcp() is False


# --- _remove_hook ---


def test_remove_hook_no_settings_file(use_tmp_paths):
    assert _remove_hook() is True


def test_remove_hook_removes_soliloquy_hook(use_tmp_paths):
    settings = {
        "hooks": {
            "Stop": [{
                "matcher": "",
                "hooks": [{"type": "command", "command": "/home/user/.soliloquy/auto-speak-hook.sh", "timeout": 5}],
            }]
        }
    }
    use_tmp_paths["claude_dir"].mkdir(parents=True, exist_ok=True)
    use_tmp_paths["settings_file"].write_text(json.dumps(settings))

    assert _remove_hook() is True

    result = json.loads(use_tmp_paths["settings_file"].read_text())
    assert "hooks" not in result


def test_remove_hook_preserves_other_hooks(use_tmp_paths):
    settings = {
        "hooks": {
            "Stop": [
                {
                    "matcher": "",
                    "hooks": [{"type": "command", "command": "/home/user/.soliloquy/auto-speak-hook.sh"}],
                },
                {
                    "matcher": "",
                    "hooks": [{"type": "command", "command": "echo done"}],
                },
            ],
            "PreToolUse": [{"matcher": "", "hooks": [{"type": "command", "command": "echo hi"}]}],
        }
    }
    use_tmp_paths["claude_dir"].mkdir(parents=True, exist_ok=True)
    use_tmp_paths["settings_file"].write_text(json.dumps(settings))

    assert _remove_hook() is True

    result = json.loads(use_tmp_paths["settings_file"].read_text())
    assert len(result["hooks"]["Stop"]) == 1
    assert result["hooks"]["Stop"][0]["hooks"][0]["command"] == "echo done"
    assert "PreToolUse" in result["hooks"]


def test_remove_hook_corrupt_settings(use_tmp_paths):
    use_tmp_paths["claude_dir"].mkdir(parents=True, exist_ok=True)
    use_tmp_paths["settings_file"].write_text("not json!!!")

    assert _remove_hook() is True


# --- _remove_soliloquy_dir ---


def test_remove_soliloquy_dir_exists(use_tmp_paths):
    sol_dir = use_tmp_paths["sol_dir"]
    sol_dir.mkdir(parents=True)
    (sol_dir / "auto-speak-hook.sh").write_text("#!/bin/bash")
    (sol_dir / "auto-speak.enabled").touch()
    (sol_dir / "backend.lock").write_text("{}")

    assert _remove_soliloquy_dir() is True
    assert not sol_dir.exists()


def test_remove_soliloquy_dir_already_gone(use_tmp_paths):
    assert not use_tmp_paths["sol_dir"].exists()
    assert _remove_soliloquy_dir() is True


# --- run_uninstall ---


def test_run_uninstall_full_flow(use_tmp_paths):
    from soliloquy.setup import run_uninstall

    with patch("soliloquy.setup._check_claude_cli", return_value=True), \
         patch("soliloquy.setup._unregister_mcp", return_value=True), \
         patch("soliloquy.setup._remove_hook", return_value=True), \
         patch("soliloquy.setup._remove_soliloquy_dir", return_value=True):
        run_uninstall()  # should not raise


def test_run_uninstall_without_claude_cli(use_tmp_paths):
    from soliloquy.setup import run_uninstall

    with patch("soliloquy.setup._check_claude_cli", return_value=False), \
         patch("soliloquy.setup._remove_hook", return_value=True), \
         patch("soliloquy.setup._remove_soliloquy_dir", return_value=True):
        run_uninstall()  # should not raise — just skips MCP removal
