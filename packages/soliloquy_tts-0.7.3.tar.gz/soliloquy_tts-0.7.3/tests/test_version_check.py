"""Tests for the background version update check."""

import json
import sys
from io import BytesIO, StringIO
from unittest.mock import patch

from soliloquy.backend import _check_for_update


def _mock_pypi_response(version):
    """Create a mock urllib response returning the given version."""
    data = json.dumps({"info": {"version": version}}).encode()
    return BytesIO(data)


def test_check_for_update_newer_available(monkeypatch):
    monkeypatch.setattr("soliloquy.__version__", "0.1.0")
    stderr = StringIO()
    monkeypatch.setattr(sys, "stderr", stderr)

    with patch("soliloquy.backend.urllib.request.urlopen", return_value=_mock_pypi_response("0.2.0")):
        _check_for_update()

    output = stderr.getvalue()
    assert "0.2.0 available" in output
    assert "0.1.0" in output


def test_check_for_update_up_to_date(monkeypatch):
    monkeypatch.setattr("soliloquy.__version__", "0.2.5")
    stderr = StringIO()
    monkeypatch.setattr(sys, "stderr", stderr)

    with patch("soliloquy.backend.urllib.request.urlopen", return_value=_mock_pypi_response("0.2.5")):
        _check_for_update()

    assert stderr.getvalue() == ""


def test_check_for_update_network_error(monkeypatch):
    monkeypatch.setattr("soliloquy.__version__", "0.2.5")
    stderr = StringIO()
    monkeypatch.setattr(sys, "stderr", stderr)

    with patch("soliloquy.backend.urllib.request.urlopen", side_effect=OSError("no network")):
        _check_for_update()  # should not raise

    assert stderr.getvalue() == ""
