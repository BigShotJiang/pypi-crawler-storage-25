# Inbox protocol

Every entity (track or originator) has a single `inbox/`. Communication is
peer-to-peer: sending mail = writing into the recipient's inbox.

## Message format

```yaml
---
from: trading
to: main
at: 2026-05-10T00-30-00Z
kind: report  # report | request | deploy-request | btw | broadcast | followup
subject: optional
---
```

## Agent contract

When consuming a message:
1. Move it to `inbox/.consumed/`
2. If work isn't complete, write a `followup/{timestamp}-{slug}.md`
3. When followup completes, move to `followup/.completed/`

## Backlog

```
backlog = count(inbox/*.md) + count(followup/*.md)
```

If backlog > 0 at end-of-wake, the supervisor forces immediate next wake.
