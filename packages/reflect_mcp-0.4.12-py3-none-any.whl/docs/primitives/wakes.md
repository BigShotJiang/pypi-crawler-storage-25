# Wakes

A **wake** is one execution of the agent loop: wake → read prior state → act →
write back → sleep.

## Anatomy of a wake

1. **Boot**: supervisor acquires `wake.lock`, smoke-tests the runtime
2. **Briefing**: reads inbox, recent reports, heartbeat log, scry
3. **Work**: agent decides what to do and executes
4. **Report**: writes a wake report to `agent/reports/`
5. **Heartbeat**: appends to `heartbeat.log`
6. **Sleep**: releases lock, optionally sets `next-wake-by.timestamp`

## Wake scheduling

- `next-wake-by.timestamp`: unix epoch; dispatcher fires when elapsed
- Backlog override: if `pending_inbox + pending_followup > 0` at wake end,
  supervisor sets `next-wake-by` to `now - 1` (immediate on next tick)
- Dispatcher tick: cron fires `reflect-dispatch` every 60s

## Wake control

```bash
reflect wake list                 # running wakes
reflect wake start <track>        # manual fire
reflect wake stop <track>         # graceful shutdown
reflect wake history [<track>]    # past wakes from wakes.tsv
```

## Auto-rollback

`bin/reflect-wake` smoke-tests `from agent.runtime.wake import main` before
booting. If the import fails, it rolls back `agent/runtime/` to the
`reflect/last-known-good` git ref and retries. Safety net for self-modification.

## Budget

Each wake has a token budget and iteration count cap. The `budget` tool reports
usage mid-wake. If approaching limits, sleep early.
