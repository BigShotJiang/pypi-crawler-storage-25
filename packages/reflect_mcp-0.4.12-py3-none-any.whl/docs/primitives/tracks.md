# Tracks

A track is a named unit of scheduling and state. Each track:

- Has its own `wake.md` (identity/scope), `objective.md` (current mission)
- Maintains an `inbox/` for incoming messages
- Has `followup/` for self-tracked work-in-progress
- Runs wakes independently via the dispatcher

## Layout

```
agent/runtime/tracks/<name>/
  wake.md
  objective.md
  wake.lock
  last-wake.timestamp
  last-wake-start.timestamp
  next-wake-by.timestamp
  inbox/
    *.md
    .consumed/
  followup/
    *.md
    .completed/
```

## Lifecycle

- `reflect track create <name>` — scaffold a new track
- `reflect track enable/disable <name>` — toggle scheduling
- `reflect track send <name> <message>` — queue work

## Scheduling

The dispatcher (`reflect dispatch`) fires wakes for tracks that have signal:
inbox messages, elapsed timers, or followup backlog. Designed for cron
(one entry, every minute).
