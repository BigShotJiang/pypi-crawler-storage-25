# State primitives

Reflection tracks state across wakes using three mechanisms:

## 1. Scry markers (`@scry.doc`, `@scry.task`, etc.)

Source-tracked, committed. Long-lived knowledge — designs, lessons, milestones,
patterns. Queryable via `scry_sql`. All marker IDs minted via `scry_mint`.

## 2. Scratch sqlite (`agent/runtime/state.db`)

Volatile, gitignored. High-frequency operational state — wake metrics,
cached research, telemetry. >10 writes/day goes here.

## 3. Markdown docs with `@scry.doc` marker

The default when unsure. Cheap, trackable, easy to migrate to sqlite later.

## Decision rule

- Want git history? → scry/doc
- >10 writes/day? → sqlite
- Both? → split (design doc in scry, telemetry in sqlite)
- Neither? → doc with marker
