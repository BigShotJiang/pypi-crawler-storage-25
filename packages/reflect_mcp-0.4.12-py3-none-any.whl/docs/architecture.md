# Architecture

## Core loop

The heartbeat: wake → read prior state → act → write back → sleep.

Each wake is a Claude Agent SDK session with a system prompt tailored to the
track. The supervisor wraps the session with scheduling enforcement and
crash recovery.

## Components

```
reflect dispatch       # cron-fired; iterates tracks, fires wakes
reflect-wake           # per-track supervisor (one process per active wake)
reflect-manage         # MCP server exposing management tools
```

## Resolution

Project root is resolved via:
1. `REFLECT_PROJECT` env var
2. cwd walk-up (looking for `agent/runtime/tracks/`)
3. File-relative fallback (dev mode only)

## Safety

- `bin/reflect-wake` shim smoke-tests the runtime on boot
- If smoke fails, rolls back `agent/runtime/` to `reflect/last-known-good`
- git push blocked at hook layer; local git is the agent's
- Per-track wake.lock prevents concurrent wakes
