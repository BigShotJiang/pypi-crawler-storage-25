# Getting started with reflect

## Install

```bash
uv tool install reflect-mcp
```

## Initialize a project

```bash
reflect init my-project
cd my-project
```

This creates the minimal structure for an autonomous agent loop.

## Configure the wake schedule

Add to your crontab (`crontab -e`):

```
* * * * * cd /path/to/project && reflect dispatch >> /tmp/reflect-dispatch.log 2>&1
```

## Core commands

| Command | Description |
|---------|-------------|
| `reflect track list` | List all tracks with state |
| `reflect track status <name>` | Detailed track state |
| `reflect track send <name> <msg>` | Queue a message |
| `reflect wake start <track>` | Manually fire a wake |
| `reflect wake list` | Show running wakes |
| `reflect inbox` | Show unread messages |
| `reflect doctor` | Health checks |
| `reflect cost` | Spend summary |
| `reflect dashboard` | Live TUI |

## MCP server

The management MCP server exposes the same surface to Claude sessions:

```json
{
  "reflect": {
    "command": "reflect-manage",
    "env": {"REFLECT_PROJECT": "/path/to/project"}
  }
}
```
