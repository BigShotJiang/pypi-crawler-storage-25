"""Agent-to-Orchestrator Status Channel — shared write helper.

DR7 from agent/design/design.orchestrator-status-channel~edc8302c.md.

Usage:
    from agent.lib.status import mark_running, mark_idle, mark_unhealthy, update_progress

Called by:
    - agent/runtime/wake.py: mark_running at wake start; mark_idle/mark_unhealthy in finally
    - Agent wakes (optionally): update_progress for mid-wake step reporting

All writes are atomic via temp+rename so the reader hook never sees a partial file.
"""
import json
import os
import pathlib
from datetime import datetime, timezone

from agent.lib.root import resolve_project_root

TRACKS_ROOT = resolve_project_root() / "agent" / "runtime" / "tracks"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _write_atomic(target: pathlib.Path, payload: dict) -> None:
    """Atomic write via temp+rename. Hook never reads a partial file."""
    tmp = target.with_suffix(".json.tmp")
    try:
        tmp.write_text(json.dumps(payload, indent=2))
        os.replace(str(tmp), str(target))
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def write_status(track: str, **fields) -> None:
    """Merge ``fields`` into the track's status.json and write atomically.

    Preserves existing fields not mentioned in ``fields``. Always stamps
    ``updated_at`` and ``schema_version``.
    """
    target = TRACKS_ROOT / track / "status.json"
    existing: dict = {}
    if target.exists():
        try:
            existing = json.loads(target.read_text())
        except Exception:
            pass  # malformed → rebuild from scratch

    # Merge: None values in fields are kept as explicit null in JSON (cleared).
    existing.update(fields)
    existing["updated_at"] = _now()
    existing["schema_version"] = 1
    existing.setdefault("track", track)

    _write_atomic(target, existing)


def mark_running(track: str, wake_id: str) -> None:
    """Write state=running at wake start. Clears prior exit/error fields."""
    write_status(
        track,
        state="running",
        wake_id=wake_id,
        started_at=_now(),
        progress=None,
        last_exit=None,
        last_error=None,
        last_summary=None,
    )


def mark_idle(track: str, summary: str) -> None:
    """Write state=idle after a clean sleep. Clears wake_id and progress."""
    write_status(
        track,
        state="idle",
        last_exit="sleep",
        last_summary=(summary or "")[:200],
        wake_id=None,
        progress=None,
    )


def mark_paused(track: str, wake_id: str | None = None) -> None:
    """Write state=paused when the wake enters the pause poll-loop.

    The process stays alive; work resumes when pause.requested is removed.
    """
    fields: dict = {"state": "paused", "last_exit": None}
    if wake_id is not None:
        fields["wake_id"] = wake_id
    write_status(track, **fields)


def mark_unhealthy(track: str, exit_reason: str, error: str = None, wake_id: str | None = None) -> None:
    """Write state=unhealthy on budget exhaustion, uncaught error, or signal.

    Preserves wake_id so postmortem readers can locate the transcript.
    """
    fields: dict = {
        "state": "unhealthy",
        "last_exit": exit_reason,
        "last_error": error,
    }
    if wake_id is not None:
        fields["wake_id"] = wake_id
    write_status(track, **fields)


def update_progress(
    track: str,
    current: int,
    total: int = None,
    label: str = None,
) -> None:
    """Update progress fields mid-wake (agent-callable). State stays 'running'."""
    write_status(
        track,
        progress={"current": current, "total": total, "label": label},
    )
