"""Claude OAuth proxy — translates Anthropic SDK calls to subscription auth.

Listens on 127.0.0.1:9000 by default, forwards every request to
https://api.anthropic.com, strips any client-supplied auth, and injects the
OAuth access token from ~/.claude/.credentials.json on every request.

Token is re-read from disk on every request, so running `claude` on this host
(which refreshes the token in-place) makes the proxy pick up the new token
automatically — no proxy restart needed.

Used by reflect when REFLECT_USE_API is NOT set: the wake runtime points the
SDK at ANTHROPIC_BASE_URL=http://localhost:9000 and uses a dummy API key.
The proxy translates those calls to the Claude Max subscription auth path.

Run via `reflect proxy` (CLI subcommand) — see agent/cli/main.py.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import aiohttp
from aiohttp import web

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 9000
DEFAULT_CREDS_PATH = Path.home() / ".claude" / ".credentials.json"
UPSTREAM = "https://api.anthropic.com"

HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host",
    "content-length",
}
STRIP_CLIENT_AUTH = {"authorization", "x-api-key"}


def read_token(creds_path: Path) -> tuple[str, int]:
    with open(creds_path) as f:
        creds = json.load(f)
    oauth = creds["claudeAiOauth"]
    return oauth["accessToken"], int(oauth.get("expiresAt", 0))


async def proxy_handler(request: web.Request) -> web.StreamResponse:
    session: aiohttp.ClientSession = request.app["session"]
    creds_path: Path = request.app["creds_path"]

    try:
        token, expires_at_ms = read_token(creds_path)
    except (FileNotFoundError, KeyError) as e:
        return web.json_response(
            {"error": f"no credentials at {creds_path}: {e}. Run `claude` here once to log in."},
            status=500,
        )

    if expires_at_ms and expires_at_ms < int(time.time() * 1000):
        print(
            f"[proxy] token expired at {expires_at_ms}, forwarding anyway — "
            "re-run `claude` on this host if upstream returns 401",
            file=sys.stderr,
        )

    url = UPSTREAM + request.path_qs

    headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in HOP_BY_HOP and k.lower() not in STRIP_CLIENT_AUTH
    }
    headers["Authorization"] = f"Bearer {token}"
    headers["Host"] = "api.anthropic.com"

    body = await request.read()

    print(f"[proxy] {request.method} {request.path_qs}", file=sys.stderr)

    try:
        upstream_resp = await session.request(
            request.method,
            url,
            headers=headers,
            data=body,
            allow_redirects=False,
            timeout=aiohttp.ClientTimeout(total=None, sock_connect=30, sock_read=None),
        )
    except aiohttp.ClientError as e:
        return web.json_response({"error": f"upstream connection failed: {e}"}, status=502)

    resp_headers = {
        k: v for k, v in upstream_resp.headers.items()
        if k.lower() not in HOP_BY_HOP
    }
    resp = web.StreamResponse(status=upstream_resp.status, headers=resp_headers)
    await resp.prepare(request)

    try:
        async for chunk in upstream_resp.content.iter_any():
            await resp.write(chunk)
    finally:
        upstream_resp.release()

    await resp.write_eof()
    return resp


async def health_handler(request: web.Request) -> web.Response:
    creds_path: Path = request.app["creds_path"]
    creds_present = creds_path.exists()
    return web.json_response({
        "ok": True,
        "credentials_present": creds_present,
        "credentials_path": str(creds_path),
    })


async def on_startup(app):
    app["session"] = aiohttp.ClientSession(auto_decompress=False)


async def on_cleanup(app):
    await app["session"].close()


def run(
    *,
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    creds_path: Path = DEFAULT_CREDS_PATH,
) -> None:
    if not creds_path.exists():
        print(
            f"warning: {creds_path} does not exist yet — log in with `claude` first",
            file=sys.stderr,
        )

    app = web.Application(client_max_size=1024 * 1024 * 64)
    app["creds_path"] = creds_path
    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    app.router.add_get("/health", health_handler)
    app.router.add_route("*", "/{path:.*}", proxy_handler)

    print(
        f"[proxy] listening on http://{host}:{port} -> {UPSTREAM} "
        f"(creds: {creds_path})",
        file=sys.stderr,
    )
    web.run_app(app, host=host, port=port, print=None)


def main() -> None:
    """Entrypoint for `reflect proxy` subcommand."""
    parser = argparse.ArgumentParser(
        prog="reflect proxy",
        description="Run the Claude OAuth proxy for subscription-auth wakes.",
    )
    parser.add_argument("--host", default=DEFAULT_HOST, help=f"Listen host (default: {DEFAULT_HOST})")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"Listen port (default: {DEFAULT_PORT})")
    parser.add_argument(
        "--credentials",
        type=Path,
        default=DEFAULT_CREDS_PATH,
        help=f"Path to Claude credentials JSON (default: {DEFAULT_CREDS_PATH})",
    )
    args = parser.parse_args()
    run(host=args.host, port=args.port, creds_path=args.credentials)


if __name__ == "__main__":
    main()
