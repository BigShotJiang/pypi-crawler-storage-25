"""DR8: Global track round-robin cursor for multi-project sweeps.

Global tracks that operate across multiple linked projects use this module to
implement fair, oldest-wins project selection. State is persisted in state.db
under the track__round_robin table.

Usage:
    import sqlite3
    from agent.lib.round_robin import ensure_table, bootstrap_projects, select_next, record_sweep

    db_path = ...  # state.db path
    con = sqlite3.connect(str(db_path))
    ensure_table(con)

    linked = ["proj1", "proj2", "proj3"]  # from agent/projects/ walk
    bootstrap_projects(con, "security-audit", linked)

    project = select_next(con, "security-audit", linked)
    if project:
        # ... sweep project ...
        record_sweep(con, "security-audit", project, status="ok")

DR8 properties:
  - Deterministic: same DB state → same next project.
  - Fair: oldest last_swept_at wins (NULL = never-swept → always wins).
  - Robust: newly-linked projects start with NULL and jump the queue.
  - Failure-aware: callers can record status='error' to deprioritize.
"""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path


DDL = """
CREATE TABLE IF NOT EXISTS track__round_robin (
    track          TEXT NOT NULL,
    project        TEXT NOT NULL,
    last_swept_at  INTEGER,          -- unix seconds; NULL = never-swept
    swept_count    INTEGER DEFAULT 0,
    last_status    TEXT,             -- 'ok', 'error', 'skipped'
    last_error     TEXT,
    PRIMARY KEY (track, project)
)
"""


def ensure_table(con: sqlite3.Connection) -> None:
    """Create track__round_robin table if it doesn't exist (idempotent)."""
    con.execute(DDL)
    con.commit()


def bootstrap_projects(
    con: sqlite3.Connection,
    track: str,
    projects: list[str],
) -> None:
    """Insert rows for any project not yet in the table (idempotent, per DR8).

    Newly-inserted rows have last_swept_at=NULL → they jump the queue.
    Existing rows are untouched.
    """
    for project in projects:
        con.execute(
            "INSERT OR IGNORE INTO track__round_robin (track, project) VALUES (?, ?)",
            (track, project),
        )
    con.commit()


def select_next(
    con: sqlite3.Connection,
    track: str,
    projects: list[str],
) -> str | None:
    """Select the next project to sweep for this track (oldest-wins algorithm).

    Only considers projects in the `projects` list (currently-linked projects).
    A project not in the list is skipped even if it has a row — unlinked projects
    are no longer eligible (DR8: "the implementation walks agent/projects/ at wake
    time to get the current linked-project names, then passes them as parameters").

    Returns the project name, or None if the list is empty.
    """
    if not projects:
        return None

    # SQLite cannot JOIN against a Python list; parameterize manually.
    placeholders = ",".join("?" * len(projects))
    row = con.execute(
        f"""
        SELECT project FROM track__round_robin
        WHERE track = ? AND project IN ({placeholders})
        ORDER BY COALESCE(last_swept_at, 0) ASC, project ASC
        LIMIT 1
        """,
        [track] + list(projects),
    ).fetchone()

    return row[0] if row else None


def record_sweep(
    con: sqlite3.Connection,
    track: str,
    project: str,
    status: str = "ok",
    error: str | None = None,
) -> None:
    """Update the sweep record for a project after a sweep attempt.

    Args:
        status: 'ok', 'error', or 'skipped'.
        error: optional error message (set when status='error').
    """
    now = int(time.time())
    con.execute(
        """
        INSERT INTO track__round_robin (track, project, last_swept_at, swept_count, last_status, last_error)
        VALUES (?, ?, ?, 1, ?, ?)
        ON CONFLICT(track, project) DO UPDATE SET
            last_swept_at = excluded.last_swept_at,
            swept_count   = swept_count + 1,
            last_status   = excluded.last_status,
            last_error    = excluded.last_error
        """,
        (track, project, now, status, error),
    )
    con.commit()


def linked_projects(orchestrator_root: Path) -> list[str]:
    """Walk agent/projects/ and return names of currently-linked projects.

    Returns alphabetically-sorted list of symlink names whose targets are alive.
    Dead symlinks are excluded.
    """
    proj_dir = orchestrator_root / "agent" / "projects"
    if not proj_dir.is_dir():
        return []
    names: list[str] = []
    for entry in sorted(proj_dir.iterdir()):
        if entry.name.startswith("."):
            continue
        if entry.is_symlink() and entry.is_dir():
            names.append(entry.name)
    return names
