# reflect MCP server

Exposes reflect's management surface as MCP tools. Started via `uv run reflect-manage`.

## Covered surface

| CLI command | MCP tool + action | Notes |
|---|---|---|
| `track list` | `track` action=list | |
| `track status <name>` | `track` action=status | |
| `track send <name> <msg>` | `track` action=send | |
| `track logs <name>` | `track` action=logs | reads `/tmp/reflect-tick-{name}.log` |
| `track tail <name>` | — | intentionally skipped — TUI-bound |
| `track enable <name>` | `track_admin` action=enable | |
| `track disable <name>` | `track_admin` action=disable | |
| `track create <name>` | `track_admin` action=create | |
| `track interrupt <name> <msg>` | `track_admin` action=interrupt | privileged: control-plane op |
| `project list` | `project` action=list | |
| `project link <path>` | `project` action=link | |
| `project unlink <name>` | `project` action=unlink | |
| `wake list` | `wake` action=status | |
| `wake start <track>` | `wake` action=start | |
| `wake stop <track>` | `wake` action=stop | soft stop via `stop.requested` flag |
| `wake history` | `wake` action=history | |
| `inbox [track]` | `inbox` list/peek/timeline | |
| `doctor` | `doctor` | |
| `cost [--by-track] [--since]` | `cost` | |
| `dashboard` | — | intentionally skipped — TUI-bound |

## Architecture

All MCP tools are thin adapters over `agent.cli.ops.*` modules — the same business
logic the CLI uses. No duplication. `track_admin` and `wake` follow the split pattern:
soft-delivery and read ops in the main tool; lifecycle-management ops in `_admin`.

## Adding new tools

1. Implement pure logic in `agent/cli/ops/<module>.py` (no stdout, no sys.exit)
2. Import in `server.py` and wire a `Tool` definition + handler case
3. Update this README's coverage table
