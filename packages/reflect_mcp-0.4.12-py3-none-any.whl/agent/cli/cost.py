"""Spend aggregation subcommand for the reflect CLI."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .output import OutputMode, print_record, print_table
from .track import PROJECT_ROOT
from .wake import _parse_wakes_tsv, _get_wake_track


def _parse_since(since_str: str) -> float:
    """Parse --since arg: ISO datetime or unix timestamp."""
    try:
        return float(since_str)
    except ValueError:
        pass
    # Try ISO format
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%MZ", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(since_str, fmt).replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except ValueError:
            continue
    raise ValueError(f"Cannot parse --since value: {since_str!r}")


def cmd_cost(args) -> None:
    mode = OutputMode(args.output)
    by_track = getattr(args, "by_track", False)
    since_str = getattr(args, "since", None)

    since_ts: float | None = None
    if since_str:
        try:
            since_ts = _parse_since(since_str)
        except ValueError as e:
            print(str(e), file=sys.stderr)
            sys.exit(1)

    rows = _parse_wakes_tsv()

    # Filter by since
    if since_ts is not None:
        filtered = []
        for row in rows:
            try:
                started = float(row.get("started_at", "0"))
                if started >= since_ts:
                    filtered.append(row)
            except (ValueError, TypeError):
                filtered.append(row)
        rows = filtered

    if not rows:
        if mode == OutputMode.HUMAN:
            print("No wake data found.")
        else:
            print(json.dumps({"total_cost_usd": 0, "wake_count": 0, "avg_cost_usd": 0}, indent=2))
        return

    if by_track:
        # Group by track
        track_costs: dict[str, list[float]] = {}
        for row in rows:
            wake_id = row.get("wake_id", "")
            track = _get_wake_track(wake_id) or "(unknown)"
            try:
                # Support both old (cost_usd) and new (api_equivalent_usd) column names
                cost = float(row.get("api_equivalent_usd") or row.get("cost_usd", "0"))
            except (ValueError, TypeError):
                cost = 0.0
            track_costs.setdefault(track, []).append(cost)

        if mode == OutputMode.JSON:
            out = []
            for track, costs in sorted(track_costs.items()):
                out.append({
                    "track": track,
                    "total_api_equivalent_usd": round(sum(costs), 6),
                    "wake_count": len(costs),
                    "avg_api_equivalent_usd": round(sum(costs) / len(costs), 6) if costs else 0,
                })
            print(json.dumps(out, indent=2))
        else:
            table_rows = []
            for track, costs in sorted(track_costs.items()):
                table_rows.append([
                    track,
                    len(costs),
                    f"${sum(costs):.4f}",
                    f"${sum(costs)/len(costs):.4f}" if costs else "$0.0000",
                ])
            print_table(["track", "wake_count", "total_api_equiv_usd", "avg_api_equiv_usd"], table_rows, mode)
        return

    # Global totals
    total_cost = 0.0
    count = 0
    for row in rows:
        try:
            # Support both old (cost_usd) and new (api_equivalent_usd) column names
            cost = float(row.get("api_equivalent_usd") or row.get("cost_usd", "0"))
            total_cost += cost
            count += 1
        except (ValueError, TypeError):
            pass

    avg = total_cost / count if count else 0.0
    record = {
        "total_api_equivalent_usd": round(total_cost, 6),
        "wake_count": count,
        "avg_api_equivalent_usd": round(avg, 6),
    }
    print_record(record, mode)
