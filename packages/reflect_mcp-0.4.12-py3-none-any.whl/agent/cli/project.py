"""Project subcommands: link, unlink, list."""
from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

from .output import OutputMode, print_table

from agent.cli.ops.root import resolve_project_root
PROJECT_ROOT = resolve_project_root()
PROJECTS_DIR = PROJECT_ROOT / "agent" / "projects"


def _orch_hash() -> str:
    """Short hash identifying this orchestrator (by absolute path)."""
    return hashlib.sha256(str(PROJECT_ROOT).encode()).hexdigest()[:12]


def _marker_path(project_dir: Path) -> Path:
    """Path to our reverse-pointer marker in a linked project."""
    return project_dir / "agent" / "runtime" / "orchestrators" / f"{_orch_hash()}.path"


def _validate_foreign_markers(project_dir: Path) -> list[str]:
    """Return list of valid foreign orchestrator paths for this project.
    Drops stale markers (orchestrator dir gone or symlink invalid).
    Returns non-empty list if a DIFFERENT valid orchestrator exists.
    """
    orch_dir = project_dir / "agent" / "runtime" / "orchestrators"
    if not orch_dir.is_dir():
        return []
    my_hash = _orch_hash()
    valid_foreign: list[str] = []
    for marker_file in orch_dir.glob("*.path"):
        if marker_file.stem == my_hash:
            continue  # skip our own
        try:
            orch_path_str = marker_file.read_text().strip()
            orch_path = Path(orch_path_str)
            if not orch_path.is_dir():
                marker_file.unlink(missing_ok=True)  # dead orchestrator
                continue
            expected_link = orch_path / "agent" / "projects" / project_dir.name
            if not expected_link.is_symlink():
                continue  # symlink gone but orch alive — stale, don't rm (let orch heal)
            link_target = expected_link.resolve()
            if link_target != project_dir.resolve():
                continue  # symlink points elsewhere — stale
            valid_foreign.append(orch_path_str)
        except (OSError, ValueError):
            pass
    return valid_foreign


def cmd_project_link(args) -> None:
    target = Path(args.path).resolve()
    if not target.is_dir():
        print(f"ERROR: {target} is not a directory.", file=sys.stderr)
        sys.exit(1)

    name = target.name
    link_path = PROJECTS_DIR / name
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

    # If link already exists pointing here: idempotent re-link (self-recognition).
    # Still write/heal the marker even on re-link — DR21 self-heal path.
    if link_path.is_symlink():
        if link_path.resolve() == target:
            marker = _marker_path(target)
            if not marker.exists():
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text(str(PROJECT_ROOT))
                print(f"Already linked (healed marker): {link_path} -> {target}")
            else:
                print(f"Already linked: {link_path} -> {target}")
            return
        else:
            print(f"ERROR: {link_path} already exists pointing to {link_path.resolve()}.", file=sys.stderr)
            print(f"  Unlink first: reflect project unlink {name}", file=sys.stderr)
            sys.exit(1)
    if link_path.exists():
        print(f"ERROR: {link_path} already exists (not a symlink).", file=sys.stderr)
        sys.exit(1)

    # Validate: no valid foreign orchestrator
    foreign = _validate_foreign_markers(target)
    if foreign:
        print(f"ERROR: {target} is already linked by another orchestrator:", file=sys.stderr)
        for f in foreign:
            print(f"  {f}", file=sys.stderr)
        print(f"  To free it: run `reflect project unlink {name}` from that orchestrator.", file=sys.stderr)
        sys.exit(1)

    # Write marker
    marker = _marker_path(target)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(str(PROJECT_ROOT))

    # Create symlink
    os.symlink(str(target), str(link_path))
    print(f"Linked: {link_path} -> {target}")
    print(f"Marker: {marker}")


def cmd_project_unlink(args) -> None:
    name = args.name
    # Accept either a name or a path
    if os.sep in name or name.startswith("."):
        target = Path(name).resolve()
        name = target.name
    link_path = PROJECTS_DIR / name

    if not link_path.exists() and not link_path.is_symlink():
        print(f"ERROR: No linked project named '{name}'.", file=sys.stderr)
        sys.exit(1)

    # Determine the real target to clean up the marker
    if link_path.is_symlink():
        target = link_path.resolve()
        marker = _marker_path(target)
        # Remove marker first, then symlink
        marker.unlink(missing_ok=True)
        link_path.unlink()
        print(f"Unlinked: {link_path}")
        print(f"Removed marker: {marker}")
    else:
        link_path.unlink()
        print(f"Removed: {link_path}")


def cmd_project_list(args) -> None:
    mode = OutputMode(args.output)
    if not PROJECTS_DIR.exists():
        if mode == OutputMode.JSON:
            print(json.dumps([]))
        else:
            print("No projects linked.")
        return

    rows = []
    for entry in sorted(PROJECTS_DIR.iterdir()):
        if entry.is_symlink():
            target = str(entry.readlink()) if hasattr(entry, "readlink") else os.readlink(str(entry))
            alive = entry.is_dir()
            rows.append([entry.name, target, "ok" if alive else "dead"])
        elif not entry.name.startswith("."):
            rows.append([entry.name, str(entry), "not-symlink"])

    if not rows:
        if mode == OutputMode.JSON:
            print(json.dumps([]))
        else:
            print("No projects linked.")
        return

    print_table(["name", "target", "status"], rows, mode)
