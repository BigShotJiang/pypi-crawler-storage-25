"""Output formatting helpers for the reflect CLI."""
from __future__ import annotations

import json
from enum import Enum
from typing import Any


class OutputMode(Enum):
    HUMAN = "human"
    JSON = "json"


def _try_rich() -> bool:
    try:
        import rich  # noqa: F401
        return True
    except ImportError:
        return False


def print_table(headers: list[str], rows: list[list[Any]], mode: OutputMode) -> None:
    if mode == OutputMode.JSON:
        records = [dict(zip(headers, row)) for row in rows]
        print(json.dumps(records, indent=2))
        return

    if _try_rich():
        from rich.console import Console
        from rich.table import Table

        table = Table(show_header=True, header_style="bold")
        for h in headers:
            table.add_column(h)
        for row in rows:
            table.add_row(*[str(c) if c is not None else "" for c in row])
        Console().print(table)
    else:
        # Plain-text fallback with padding
        col_widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], len(str(cell) if cell is not None else ""))
        fmt = "  ".join(f"{{:<{w}}}" for w in col_widths)
        print(fmt.format(*headers))
        print("  ".join("-" * w for w in col_widths))
        for row in rows:
            print(fmt.format(*[str(c) if c is not None else "" for c in row]))


def print_record(record: dict, mode: OutputMode) -> None:
    if mode == OutputMode.JSON:
        print(json.dumps(record, indent=2))
        return

    if _try_rich():
        from rich.console import Console
        from rich.table import Table

        table = Table(show_header=False, box=None)
        table.add_column("key", style="bold")
        table.add_column("value")
        for k, v in record.items():
            table.add_row(str(k), str(v) if v is not None else "")
        Console().print(table)
    else:
        for k, v in record.items():
            print(f"{k}: {v if v is not None else ''}")


def print_list(items: list[dict], mode: OutputMode) -> None:
    if mode == OutputMode.JSON:
        print(json.dumps(items, indent=2))
        return

    if not items:
        print("(none)")
        return

    if _try_rich():
        from rich.console import Console
        from rich.table import Table

        headers = list(items[0].keys())
        table = Table(show_header=True, header_style="bold")
        for h in headers:
            table.add_column(h)
        for item in items:
            table.add_row(*[str(item.get(h, "")) for h in headers])
        Console().print(table)
    else:
        if not items:
            return
        headers = list(items[0].keys())
        col_widths = [len(h) for h in headers]
        for item in items:
            for i, h in enumerate(headers):
                col_widths[i] = max(col_widths[i], len(str(item.get(h, ""))))
        fmt = "  ".join(f"{{:<{w}}}" for w in col_widths)
        print(fmt.format(*headers))
        print("  ".join("-" * w for w in col_widths))
        for item in items:
            print(fmt.format(*[str(item.get(h, "")) for h in headers]))
