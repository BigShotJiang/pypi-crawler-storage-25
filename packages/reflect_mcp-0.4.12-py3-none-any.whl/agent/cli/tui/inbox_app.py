"""Inbox TUI — interactive viewer for reflect inbox <track> -i.

Polling model: uses set_interval(2.0, ...) to check for new files every 2s.
No inotify — deliberate choice to keep deps minimal and behaviour predictable
across platforms (including NFS-mounted project dirs).
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widgets import Footer, Header, ListItem, ListView, Markdown
from textual.containers import Horizontal


class InboxApp(App[None]):
    """Interactive inbox viewer for a single track."""

    CSS = """
    Horizontal {
        height: 1fr;
    }
    ListView {
        width: 1fr;
        border: solid $primary;
    }
    Markdown {
        width: 2fr;
        border: solid $primary;
        padding: 1 2;
    }
    """

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=True),
        Binding("k", "cursor_up", "Up", show=True),
        Binding("enter", "open_editor", "Open in $EDITOR", show=True),
        Binding("c", "mark_consumed", "Consume", show=True),
        Binding("q", "quit", "Quit", show=True),
    ]

    def __init__(self, track: str, inbox_dir: Path) -> None:
        super().__init__()
        self.track = track
        self.inbox_dir = inbox_dir
        self.consumed_dir = inbox_dir / ".consumed"
        self._files: list[Path] = []

    # ── lifecycle ──────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal():
            yield ListView(id="file-list")
            yield Markdown("*Select a file to preview it.*", id="preview")
        yield Footer()

    def on_mount(self) -> None:
        self.title = f"reflect inbox  ·  {self.track}"
        self._load_files()
        self.set_interval(2.0, self._refresh_files)

    # ── internal helpers ───────────────────────────────────────────────────

    def _unread_files(self) -> list[Path]:
        if not self.inbox_dir.exists():
            return []
        consumed_names: set[str] = set()
        if self.consumed_dir.exists():
            consumed_names = {p.name for p in self.consumed_dir.glob("*.md")}
        return sorted(
            [p for p in self.inbox_dir.glob("*.md") if p.name not in consumed_names],
            reverse=True,
        )

    def _load_files(self) -> None:
        self._files = self._unread_files()
        lv: ListView = self.query_one("#file-list", ListView)
        lv.clear()
        for f in self._files:
            lv.append(ListItem(Markdown(f.name)))
        if self._files:
            lv.index = 0
            self._update_preview(self._files[0])
        else:
            self.query_one("#preview", Markdown).update("*No unread messages.*")

    def _update_preview(self, path: Path) -> None:
        try:
            content = path.read_text()
        except OSError:
            content = f"*Could not read {path.name}*"
        self.query_one("#preview", Markdown).update(content)

    def _selected_path(self) -> Path | None:
        lv: ListView = self.query_one("#file-list", ListView)
        idx = lv.index
        if idx is None or idx >= len(self._files):
            return None
        return self._files[idx]

    # ── polling refresh ────────────────────────────────────────────────────

    def _refresh_files(self) -> None:
        new_files = self._unread_files()
        if new_files != self._files:
            lv: ListView = self.query_one("#file-list", ListView)
            old_idx = lv.index or 0
            self._files = new_files
            lv.clear()
            for f in self._files:
                lv.append(ListItem(Markdown(f.name)))
            if self._files:
                new_idx = min(old_idx, len(self._files) - 1)
                lv.index = new_idx
                self._update_preview(self._files[new_idx])
            else:
                self.query_one("#preview", Markdown).update("*No unread messages.*")

    # ── reactive ───────────────────────────────────────────────────────────

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        lv: ListView = self.query_one("#file-list", ListView)
        idx = lv.index
        if idx is not None and idx < len(self._files):
            self._update_preview(self._files[idx])

    # ── actions ────────────────────────────────────────────────────────────

    def action_cursor_down(self) -> None:
        self.query_one("#file-list", ListView).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#file-list", ListView).action_cursor_up()

    def action_open_editor(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        editor = os.environ.get("EDITOR", "nano")
        with self.suspend():
            subprocess.run([editor, str(path)])

    def action_mark_consumed(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        self.consumed_dir.mkdir(parents=True, exist_ok=True)
        dest = self.consumed_dir / path.name
        path.rename(dest)
        self._load_files()
