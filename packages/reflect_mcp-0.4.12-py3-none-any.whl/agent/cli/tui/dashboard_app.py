"""Dashboard TUI — live multi-track status for reflect dashboard.

Design notes:
- Polling model: set_interval(1.0, ...) for table refresh, 500ms for tail view.
  No inotify — deliberate choice. Keeps deps minimal and works on NFS/remote
  filesystems without kernel-level FS event support.
- Cost column reads /tmp/reflect-wake-cost-{track}.json for {"usd": float}.
  This file is not yet written by the wake runtime — column always shows '-'
  until wired up. Lazy approach by design: the file is optional.
- Expand/collapse rebuilds table rows (simplest DataTable approach — clear +
  re-add). DataTable doesn't support nested rows natively.
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import time
import zlib
from pathlib import Path
from typing import Optional

from textual.app import App, ComposeResult, Screen
from textual.binding import Binding
from textual.events import Key
from textual.widgets import DataTable, Header, Input, Label, Static
from textual.containers import Vertical


# ── helpers ────────────────────────────────────────────────────────────────


def _is_pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _read_lock_pid(lock_path: Path) -> Optional[int]:
    try:
        content = lock_path.read_text().strip()
        for line in content.splitlines():
            line = line.strip()
            if line.isdigit():
                return int(line)
    except (OSError, ValueError):
        pass
    return None


def _track_state(track_dir: Path) -> str:
    from agent.cli.ops.track import _resolve_track_state
    return _resolve_track_state(track_dir)


_STATE_ICON = {
    "running": "●",
    "idle": "◌",
    "disabled": "⊘",
}


def _fmt_runtime(last_wake_start_path: Path) -> str:
    try:
        epoch = float(last_wake_start_path.read_text().strip())
        elapsed = int(time.time() - epoch)
        if elapsed < 0:
            return "-"
        mins, secs = divmod(elapsed, 60)
        if mins:
            return f"{mins}m{secs:02d}s"
        return f"{secs}s"
    except (OSError, ValueError):
        return "-"


def _fmt_activity(track_name: str) -> str:
    log_path = Path(f"/tmp/reflect-tick-{track_name}.log")
    try:
        lines = log_path.read_text().splitlines()[-20:]
    except OSError:
        return "-"
    emoji_starts = "🔧🧠💭📝🔍✅❌⚡🌐📦🗂️💡🚀📊"
    for line in reversed(lines):
        if line and line[0] in emoji_starts:
            return line[:30]
    return "-"


def _fmt_cost(track_name: str) -> str:
    cost_path = Path(f"/tmp/reflect-wake-cost-{track_name}.json")
    try:
        data = json.loads(cost_path.read_text())
        usd = float(data.get("usd", 0.0))
        return f"${usd:.4f}"
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return "-"


def _unread_count(track_dir: Path) -> int:
    """Count unread inbox messages. P9: reads from inbox/ (unified), not inbox/from-originator/."""
    inbox_dir = track_dir / "inbox"
    if not inbox_dir.exists():
        return 0
    consumed_dir = inbox_dir / ".consumed"
    # Only count .md files directly in inbox/, not subdirs
    all_md = {p.name for p in inbox_dir.glob("*.md")}
    consumed_md: set[str] = set()
    if consumed_dir.exists():
        consumed_md = {p.name for p in consumed_dir.glob("*.md")}
    return len(all_md - consumed_md)


def _dispatch_status() -> str:
    log = Path("/tmp/reflect-dispatch.log")
    try:
        mtime = log.stat().st_mtime
        ago = int(time.time() - mtime)
        if ago > 300:
            return f"⚠ stale ({ago}s ago)"
        return f"✓ {ago}s ago"
    except OSError:
        return "⚠ no log"


def _sort_key(name: str, state: str, track_dir: Path) -> tuple:
    order = {"running": 0, "stale-lock": 1, "idle": 2, "disabled": 3}
    rank = order.get(state, 2)
    lw_path = track_dir / "last-wake.timestamp"
    try:
        ts = int(lw_path.read_text().strip())
    except (OSError, ValueError):
        ts = 0
    return (rank, -ts)


# Curated palette for the per-track status-bar color. Buckets only into
# vibrant, medium, and pastel hues — no browns, olives, mustardy yellows,
# or muddy mid-tones. Indexed by a stable crc32 hash of the track name so
# a given track always renders with the same color across runs.
_TRACK_PALETTE: list[str] = [
    # Vibrant
    "#FF1744", "#FF4081", "#E91E63", "#9C27B0", "#673AB7",
    "#3F51B5", "#2196F3", "#00BCD4", "#009688", "#4CAF50",
    "#8BC34A", "#FF5722", "#FF9800",
    # Medium
    "#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8",
    "#7FB3D5", "#F1948A",
    # Pastel
    "#FFB6C1", "#B5EAD7", "#C7CEEA", "#C2F0FC", "#E0BBE4",
    "#FEC8D8", "#FFDFD3", "#B3E5FC", "#80DEEA",
]


def _track_color(name: str) -> tuple[str, str]:
    """Return (background_hex, foreground_hex) for a track's status bar.

    Stable across runs: same name → same color. Foreground is black or
    white depending on background luminance for legibility.
    """
    bucket = zlib.crc32(name.encode("utf-8")) % len(_TRACK_PALETTE)
    bg = _TRACK_PALETTE[bucket]
    r = int(bg[1:3], 16)
    g = int(bg[3:5], 16)
    b = int(bg[5:7], 16)
    luminance = 0.299 * r + 0.587 * g + 0.114 * b
    fg = "#000000" if luminance > 140 else "#FFFFFF"
    return bg, fg


def _tail_lines(track_name: str, n: int = 8) -> list[str]:
    log_path = Path(f"/tmp/reflect-tick-{track_name}.log")
    try:
        lines = log_path.read_text().splitlines()
        return lines[-n:]
    except OSError:
        return []


# ── tail screen ────────────────────────────────────────────────────────────


class TailScreen(Screen):
    """Full-screen transcript tail for a single track.

    Auto-transitions when a new wake fires — no need to restart.

    Detection: polls the latest-wake-for-track helper every second.
    When a new wake_id appears, a separator line is printed and the
    transcript reader resets to the new file.

    Content: AssistantMessage events rendered as thinking / text / tool-use
    lines.  UserMessage (tool results) and SystemMessage are omitted.

    Status bar: track color + wake_id (last 14 chars) + turn count + cost.
    Between wakes: idle state with "waiting for next wake".
    """

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
        Binding("l", "open_in_pager", "Less", show=True),
    ]

    DEFAULT_CSS = """
    #track-bar {
        dock: bottom;
        height: 1;
        padding: 0 2;
        text-style: bold;
    }
    #tail-content {
        padding: 1 2;
    }
    """

    def __init__(self, track_name: str) -> None:
        super().__init__()
        self.track_name = track_name
        self._current_wake_id: Optional[str] = None
        self._transcript_path: Optional[Path] = None
        self._transcript_line: int = 0
        self._display_lines: list[str] = []
        # Synthesizer state
        self._latest_status: Optional[str] = None
        self._synth_in_flight: bool = False
        self._synth_task: Optional[asyncio.Task] = None
        self._synthesizer = None  # lazy — import StatusSynthesizer on mount

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static(id="tail-content")
        yield Static(id="track-bar")

    def on_mount(self) -> None:
        self.title = f"reflect tail  ·  {self.track_name}"
        bg, fg = _track_color(self.track_name)
        bar = self.query_one("#track-bar", Static)
        bar.styles.background = bg
        bar.styles.color = fg
        self._set_bar_idle()
        # Seed with any current or most-recent wake
        self._check_for_new_wake()
        self.set_interval(0.5, self._poll_transcript)
        self.set_interval(1.0, self._check_for_new_wake)
        # Synthesizer: try to import; silently disable if anthropic not available
        try:
            from .status_synthesizer import StatusSynthesizer
            self._synthesizer = StatusSynthesizer()
        except Exception:
            self._synthesizer = None
        # Fire synthesizer every 15s
        self.set_interval(15.0, self._trigger_synthesis)

    def on_unmount(self) -> None:
        """Cancel in-flight synthesizer task on screen exit."""
        if self._synth_task is not None and not self._synth_task.done():
            self._synth_task.cancel()

    # ── status bar ──────────────────────────────────────────────────────────

    def _set_bar_idle(self) -> None:
        self.query_one("#track-bar", Static).update(
            f" {self.track_name}  ·  idle — waiting for next wake "
        )

    def _set_bar_wake(
        self,
        wake_id: str,
        turns: int,
        cost_usd: Optional[float],
        is_running: bool,
    ) -> None:
        short_id = wake_id[-14:] if len(wake_id) > 14 else wake_id
        state = "●" if is_running else "◌"
        cost_str = f"  ${cost_usd:.4f}" if cost_usd is not None else ""
        # Build core slots (fixed-width, high information density)
        core = f" {state} {self.track_name}  ·  {short_id}  ·  {turns} turns{cost_str}"
        # Live status slot (right side, truncated to fit terminal)
        if self._latest_status:
            status_slot = f'  ·  "{self._latest_status}"'
            # Respect terminal width: truncate status slot from the end
            try:
                term_width = os.get_terminal_size().columns
            except OSError:
                term_width = 200
            available = term_width - len(core) - 1  # 1 for trailing space
            if available < 6:
                status_slot = ""
            elif len(status_slot) > available:
                # Truncate with ellipsis, keep the opening quote
                status_slot = status_slot[: available - 1] + "…"
        else:
            status_slot = ""
        self.query_one("#track-bar", Static).update(f"{core}{status_slot} ")

    # ── pager ────────────────────────────────────────────────────────────────

    def action_open_in_pager(self) -> None:
        """Suspend the TUI and open current content in `less` for selection/copy."""
        import re
        import tempfile

        # Strip Rich markup to plain text for pager display
        plain = re.sub(r"\[/?[^\]]*\]", "", "\n".join(self._display_lines))
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix=f"reflect-tail-{self.track_name}-"
        ) as f:
            f.write(plain)
            tmp_path = f.name

        with self.app.suspend():
            subprocess.run(["less", "-R", tmp_path], check=False)

        import os as _os
        try:
            _os.unlink(tmp_path)
        except OSError:
            pass

    # ── synthesizer ─────────────────────────────────────────────────────────

    def _trigger_synthesis(self) -> None:
        """Fire a Haiku synthesis if track is running and no call in flight."""
        if self._synthesizer is None:
            return
        if not self._is_track_running():
            return
        if not self._display_lines:
            return
        if self._synth_in_flight:
            return  # drop — previous call hasn't returned

        self._synth_in_flight = True
        lines_snapshot = list(self._display_lines)

        async def _run():
            try:
                result = await self._synthesizer.synthesize(lines_snapshot)
                if result:
                    self._latest_status = result
                    # Re-render the bar immediately on update
                    self._set_bar_wake(
                        self._current_wake_id or "",
                        self._count_tool_turns(),
                        None,
                        self._is_track_running(),
                    )
            except Exception as exc:
                # Silent fallback — log to stderr only
                import sys
                print(f"[synthesizer error] {exc}", file=sys.stderr)
            finally:
                self._synth_in_flight = False

        self._synth_task = asyncio.create_task(_run())

    # ── wake detection ───────────────────────────────────────────────────────

    def _check_for_new_wake(self) -> None:
        """Detect a new or finished wake; transition display accordingly."""
        from ..ops.wake import latest_wake_for_track

        info = latest_wake_for_track(self.track_name)
        if info is None:
            if self._current_wake_id is not None:
                self._current_wake_id = None
                self._transcript_path = None
                self._latest_status = None
                self._set_bar_idle()
            return

        new_id = info["wake_id"]

        if new_id == self._current_wake_id:
            # Same wake — update bar when it finishes with final cost
            if not info["is_running"] and info["cost_usd"] is not None:
                self._set_bar_wake(
                    new_id, self._count_tool_turns(), info["cost_usd"], False
                )
            return

        # ── new wake! ────────────────────────────────────────────────────────
        if self._current_wake_id is not None:
            # Print transition separator
            self._display_lines.append("")
            self._display_lines.append(
                "─" * 40 + f"  {new_id}  " + "─" * 40
            )
            self._display_lines.append("")

        self._current_wake_id = new_id
        self._transcript_path = info["transcript_path"]
        self._transcript_line = 0
        # Clear live status on wake transition; synthesizer repopulates within 15s
        self._latest_status = None
        self._set_bar_wake(new_id, 0, info["cost_usd"], info["is_running"])
        # Drain whatever is already in the transcript
        self._poll_transcript()

    # ── transcript polling ───────────────────────────────────────────────────

    def _poll_transcript(self) -> None:
        """Append any new transcript events to the display."""
        if self._transcript_path is None:
            return
        from ..ops.wake import parse_transcript_tail

        new_lines, new_pos = parse_transcript_tail(
            self._transcript_path, self._transcript_line
        )
        if new_pos == self._transcript_line:
            return  # nothing new

        self._transcript_line = new_pos
        self._display_lines.extend(new_lines)

        # Render — cap at last 150 display lines to avoid unbounded growth
        content = "\n".join(self._display_lines[-150:])
        self.query_one("#tail-content", Static).update(content)

        # Refresh bar (cost unknown while running; will update on wake complete)
        turns = self._count_tool_turns()
        self._set_bar_wake(
            self._current_wake_id or "",
            turns,
            None,
            self._is_track_running(),
        )

    def _count_tool_turns(self) -> int:
        """Proxy for turn count: number of tool-call lines in the display buffer."""
        return sum(1 for line in self._display_lines if line.startswith("  🔧"))

    def _is_track_running(self) -> bool:
        # Same detection as latest_wake_for_track: start_ts > end_ts.
        track_dir = (
            Path(__file__).resolve().parents[3]
            / "agent" / "runtime" / "tracks" / self.track_name
        )
        lws = track_dir / "last-wake-start.timestamp"
        lwe = track_dir / "last-wake.timestamp"
        try:
            start_ts = int(lws.read_text().strip())
        except (OSError, ValueError):
            return False
        try:
            end_ts = int(lwe.read_text().strip())
        except (OSError, ValueError):
            end_ts = 0
        return start_ts > end_ts


# ── dashboard app ─────────────────────────────────────────────────────────


class DashboardApp(App[Optional[str]]):
    """Live multi-track dashboard.

    Returns track name if user pressed 'i' (caller opens inbox TUI).
    """

    CSS = """
    #status-bar {
        height: 1;
        background: $primary-darken-2;
        color: $text;
        padding: 0 2;
    }
    #filter-input {
        height: 3;
        display: none;
    }
    #filter-input.visible {
        display: block;
    }
    DataTable {
        height: 1fr;
    }
    #shortcuts-bar {
        height: 1;
        background: $primary-darken-3;
        color: $text-muted;
        padding: 0 1;
    }
    """

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=False, priority=True),
        Binding("k", "cursor_up", "Up", show=False, priority=True),
        Binding("space", "toggle_expand", "Expand", show=True, priority=True),
        Binding("enter", "open_tail", "Tail", show=True, priority=True),
        Binding("e", "toggle_enable", "Enable/Disable", show=True, priority=True),
        Binding("i", "open_inbox", "Inbox", show=True, priority=True),
        Binding("s", "wake_start", "Start", show=True, priority=True),
        Binding("x", "wake_stop", "Stop", show=True, priority=True),
        Binding("/", "focus_filter", "Filter", show=True, priority=True),
        Binding("escape", "clear_filter", "Clear filter", show=False, priority=True),
        Binding("q", "quit", "Quit", show=True, priority=True),
    ]

    def __init__(self, tracks_dir: Path) -> None:
        super().__init__()
        self.tracks_dir = tracks_dir
        self._expanded: set[str] = set()
        self._filter: str = ""
        self._track_rows: list[str] = []  # ordered track names in current table
        self._filtering = False

    # ── lifecycle ──────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static(id="status-bar")
        yield Input(placeholder="filter tracks…", id="filter-input")
        yield DataTable(id="dashboard-table")
        yield Static(
            " [j/k] Move  [spc] Expand  [enter] Tail  [e] En/Dis  [i] Inbox  [s] Start  [x] Stop  [/] Filter  [q] Quit",
            id="shortcuts-bar",
        )

    def on_mount(self) -> None:
        self.title = "reflect dashboard"
        table: DataTable = self.query_one("#dashboard-table", DataTable)
        table.cursor_type = "row"
        table.add_columns("▸/▾", "state", "name", "activity", "runtime", "cost", "📨")
        self._refresh_status_bar()
        self._refresh_table()
        self.set_interval(1.0, self._refresh_table)
        self.set_interval(5.0, self._refresh_status_bar)
        # DataTable is the primary interactive widget; ensure it has focus on startup
        # so keyboard bindings (j/k/e/s/x/space/enter) work immediately without
        # the operator having to click or tab into it.
        table.focus()

    # ── helpers ────────────────────────────────────────────────────────────

    def _all_tracks(self) -> list[str]:
        if not self.tracks_dir.exists():
            return []
        return sorted(
            d.name
            for d in self.tracks_dir.iterdir()
            if d.is_dir() and not d.name.startswith(".")
        )

    def _selected_track(self) -> Optional[str]:
        table: DataTable = self.query_one("#dashboard-table", DataTable)
        if not self._track_rows:
            return None
        row_idx = table.cursor_row
        # _track_rows includes only track rows (not expand sub-rows)
        # We need to figure out which track row the cursor is on
        # by iterating through the rendered rows
        if row_idx < 0 or row_idx >= table.row_count:
            return None
        # Walk through the row keys to find the track at cursor_row
        row_keys = list(table.rows.keys())
        if row_idx >= len(row_keys):
            return None
        key = row_keys[row_idx].value
        # key is either "track:{name}" or "expand:{name}:{lineno}"
        if key and key.startswith("track:"):
            return key[6:]
        # if on an expand sub-row, find the parent track
        if key and key.startswith("expand:"):
            parts = key.split(":", 2)
            return parts[1] if len(parts) >= 2 else None
        return None

    # ── refresh ────────────────────────────────────────────────────────────

    def _contract_health_badge(self) -> str:
        """Protocol validator removed — always clean."""
        return "✅ contract"

    def _refresh_status_bar(self) -> None:
        import datetime
        today = datetime.date.today().isoformat()
        disp = _dispatch_status()
        badge = self._contract_health_badge()
        self.query_one("#status-bar", Static).update(
            f"reflection  ·  {today}  ·  dispatcher: {disp}  ·  {badge}"
        )

    def _refresh_table(self) -> None:
        table: DataTable = self.query_one("#dashboard-table", DataTable)
        old_cursor = table.cursor_row

        all_names = self._all_tracks()

        # Filter
        if self._filter:
            names = [n for n in all_names if self._filter.lower() in n.lower()]
        else:
            names = all_names

        # Build state map and sort
        states = {}
        for name in names:
            track_dir = self.tracks_dir / name
            states[name] = _track_state(track_dir)

        names.sort(key=lambda n: _sort_key(n, states[n], self.tracks_dir / n))

        # Rebuild table
        table.clear()
        self._track_rows = []
        new_row_count = 0

        for name in names:
            state = states[name]
            icon = _STATE_ICON.get(state, "?")
            track_dir = self.tracks_dir / name

            if state == "running":
                activity = _fmt_activity(name)
                runtime = _fmt_runtime(track_dir / "last-wake-start.timestamp")
                cost = _fmt_cost(name)
            else:
                activity = "-"
                runtime = "-"
                cost = "-"

            unread = _unread_count(track_dir)
            expand_marker = "▾" if name in self._expanded else "▸"

            table.add_row(
                expand_marker,
                f"{icon} {state}",
                name,
                activity,
                runtime,
                cost,
                str(unread) if unread else "-",
                key=f"track:{name}",
            )
            self._track_rows.append(name)
            new_row_count += 1

            # Expand sub-rows
            if name in self._expanded:
                tail = _tail_lines(name, 8)
                if not tail:
                    tail = ["(no log)"]
                # Truncate to terminal width minus fixed column overhead (~30 chars)
                # so thinking blocks (🧠) are readable without wrapping off-screen.
                try:
                    _max_line = max(60, os.get_terminal_size().columns - 30)
                except OSError:
                    _max_line = 120
                for i, line in enumerate(tail):
                    truncated = line[:_max_line] if len(line) > _max_line else line
                    table.add_row(
                        "", "", f"  {truncated}", "", "", "", "",
                        key=f"expand:{name}:{i}",
                    )
                    new_row_count += 1

        # Restore cursor position
        if new_row_count > 0:
            table.move_cursor(row=min(old_cursor, new_row_count - 1))

    # ── actions ────────────────────────────────────────────────────────────

    def on_key(self, event: Key) -> None:
        """Explicit key routing — belt-and-suspenders over BINDINGS priority=True.

        Textual 0.89.x DataTable swallows keypresses before App-level BINDINGS
        fire even with priority=True. Route explicitly here to guarantee all
        shortcuts invoke their handlers.
        """
        if self._filtering:
            return  # Input widget handles keys while filter is active
        key_to_action: dict[str, str] = {
            "j": "cursor_down",
            "k": "cursor_up",
            "space": "toggle_expand",
            "enter": "open_tail",
            "e": "toggle_enable",
            "i": "open_inbox",
            "s": "wake_start",
            "x": "wake_stop",
            "slash": "focus_filter",
            "escape": "clear_filter",
            "q": "quit",
        }
        action_name = key_to_action.get(event.key)
        if action_name is not None:
            event.prevent_default()
            event.stop()
            self.call_later(self.run_action, action_name)

    def action_cursor_down(self) -> None:
        self.query_one("#dashboard-table", DataTable).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#dashboard-table", DataTable).action_cursor_up()

    def action_toggle_expand(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        if track in self._expanded:
            self._expanded.discard(track)
        else:
            self._expanded.add(track)
        self._refresh_table()

    def action_open_tail(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        self.push_screen(TailScreen(track))

    def action_toggle_enable(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        flag = self.tracks_dir / track / "disabled.flag"
        if flag.exists():
            flag.unlink()
        else:
            flag.touch()
        self._refresh_table()

    def action_open_inbox(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        self.exit(track)

    def action_wake_start(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        subprocess.Popen(
            ["reflect", "wake", "start", track],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def action_wake_stop(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        subprocess.Popen(
            ["reflect", "wake", "stop", track],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def action_focus_filter(self) -> None:
        inp: Input = self.query_one("#filter-input", Input)
        inp.add_class("visible")
        inp.focus()
        self._filtering = True

    def action_clear_filter(self) -> None:
        if self._filtering:
            inp: Input = self.query_one("#filter-input", Input)
            inp.remove_class("visible")
            inp.value = ""
            self._filter = ""
            self._filtering = False
            self.query_one("#dashboard-table", DataTable).focus()
            self._refresh_table()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "filter-input":
            self._filter = event.value
            self._refresh_table()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "filter-input":
            self.action_clear_filter()
