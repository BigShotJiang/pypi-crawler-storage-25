"""Async-compatible event and transcript pollers for the session TUI.

EventPoller reads structured events from the daily JSONL event file.
TranscriptPoller reads the live wake transcript (rendered assistant output).

Both are designed to be called from Textual set_interval callbacks — pure sync,
no threading.

Usage::

    # Transcript (primary pane content):
    tp = TranscriptPoller(track="main", replay_last=100)
    for line in tp.drain():   # on mount
        ...
    for line in tp.poll():    # each 0.2s tick
        ...

    # Events (status bar tally):
    ep = EventPoller(track="main", replay_last=20)
    for ev in ep.drain():
        ...
    for ev in ep.poll():
        ...
"""
from __future__ import annotations

import json
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Iterator, Optional


# ── Path helpers ──────────────────────────────────────────────────────────────


def _runtime_root() -> Path:
    return Path(__file__).parent.parent.parent / "runtime"


def _events_dir() -> Path:
    return _runtime_root() / "events"


def _current_file() -> Optional[Path]:
    sym = _runtime_root() / "events.jsonl"
    if sym.is_symlink():
        target = sym.resolve()
        if target.exists():
            return target
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    p = _events_dir() / f"{today}.jsonl"
    return p if p.exists() else None


def _file_date(path: Path) -> date:
    try:
        return datetime.strptime(path.stem, "%Y-%m-%d").date()
    except ValueError:
        return date.min


# ── EventPoller ───────────────────────────────────────────────────────────────


class EventPoller:
    """Polls the event file for new events from a specific track.

    Call ``drain()`` once on startup to get the last N historical events,
    then ``poll()`` on each timer tick to get new events since the last call.
    """

    def __init__(self, track: str, replay_last: int = 20) -> None:
        self._track = track
        self._replay_last = replay_last
        self._file: Optional[Path] = None
        self._pos: int = 0
        self._last_date: date = datetime.now(timezone.utc).date()

    def _read_from(self, path: Path, from_pos: int = 0) -> Iterator[dict]:
        """Yield all matching events from *path* starting at byte offset *from_pos*."""
        if not path.exists():
            return
        try:
            with path.open(errors="replace") as fh:
                if from_pos:
                    fh.seek(from_pos)
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        ev = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if self._track and ev.get("track") != self._track:
                        continue
                    yield ev
        except OSError:
            return

    def drain(self) -> list[dict]:
        """Return the last N events for this track (startup replay).

        After this call, ``poll()`` will return only events that arrive
        after the current file position.
        """
        self._file = _current_file()
        if self._file is None or not self._file.exists():
            return []

        # Read all events from today's file, keep last N
        all_events = list(self._read_from(self._file, from_pos=0))
        try:
            self._pos = self._file.stat().st_size
        except OSError:
            self._pos = 0

        return all_events[-self._replay_last :]

    def poll(self) -> list[dict]:
        """Return new events since the last poll.

        Handles day rollover: when a new daily file appears, resets
        position to 0 and reads the new file.
        """
        today = datetime.now(timezone.utc).date()
        if today != self._last_date:
            # Day rolled over — switch to new file
            self._last_date = today
            self._file = _current_file()
            self._pos = 0

        cf = _current_file()
        if cf is None:
            return []

        # File switched (e.g., after rotation)
        if cf != self._file:
            self._file = cf
            self._pos = 0

        if not self._file.exists():
            return []

        try:
            size = self._file.stat().st_size
        except OSError:
            return []

        if size < self._pos:
            # File was truncated; reset
            self._pos = 0

        if size == self._pos:
            return []

        events = list(self._read_from(self._file, from_pos=self._pos))
        try:
            self._pos = self._file.stat().st_size
        except OSError:
            pass
        return events


# ── TranscriptPoller ──────────────────────────────────────────────────────────


class TranscriptPoller:
    """Polls the live wake transcript for a track and returns rendered lines.

    The transcript is the primary content source for the session TUI tail pane.
    Each call to ``poll()`` returns new rendered text lines since the last call.

    Handles wake switching: when a new wake starts for the track, the poller
    automatically resets and begins reading the new transcript, emitting a
    visual separator so the viewer knows a new wake started.

    Rendered lines come from ``parse_transcript_tail`` in ``ops/wake.py``:
    - thinking blocks  → ``🧠 <text>``
    - text blocks      → raw assistant prose
    - tool-use blocks  → ``  🔧 tool_name(<args preview>)``
    """

    def __init__(self, track: str, replay_last: int = 150) -> None:
        self._track = track
        self._replay_last = replay_last
        self._wake_info: Optional[dict] = None
        self._from_line: int = 0

    def _latest(self) -> Optional[dict]:
        try:
            from agent.cli.ops.wake import latest_wake_for_track
            return latest_wake_for_track(self._track)
        except Exception:
            return None

    def drain(self) -> list[str]:
        """Initial load: returns up to replay_last rendered lines from the
        most recent wake transcript.  After this call, ``poll()`` will return
        only lines that arrive after the current file position.
        """
        self._wake_info = self._latest()
        if not self._wake_info:
            return []
        t_path = self._wake_info.get("transcript_path")
        if not t_path or not Path(t_path).exists():
            return []
        try:
            from agent.cli.ops.wake import parse_transcript_tail
            lines, self._from_line = parse_transcript_tail(Path(t_path), from_line=0)
        except Exception:
            return []
        return lines[-self._replay_last :]

    def poll(self) -> list[str]:
        """Return new rendered transcript lines since the last poll.

        Returns an empty list when nothing has changed.  If a new wake has
        started, prepends a visual separator before the new content.
        """
        current = self._latest()
        separator_lines: list[str] = []

        if current:
            cur_id = current.get("wake_id")
            prev_id = self._wake_info.get("wake_id") if self._wake_info else None
            if cur_id != prev_id:
                # New wake — reset and show separator
                self._wake_info = current
                self._from_line = 0
                separator_lines = [
                    "",
                    f"── wake {cur_id} ──────────────────────────",
                    "",
                ]
        elif not self._wake_info:
            return []

        if not self._wake_info:
            return []
        t_path = self._wake_info.get("transcript_path")
        if not t_path or not Path(t_path).exists():
            return []

        try:
            from agent.cli.ops.wake import parse_transcript_tail
            lines, self._from_line = parse_transcript_tail(
                Path(t_path), from_line=self._from_line
            )
        except Exception:
            return []

        return separator_lines + lines
