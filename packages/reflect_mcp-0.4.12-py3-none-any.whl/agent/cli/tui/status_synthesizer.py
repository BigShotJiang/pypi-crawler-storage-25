"""Status synthesizer — Haiku-powered live-status slot for the TailScreen bar.

Architecture:
  - Owns the Anthropic client and the synthesis prompt.
  - Pure function: input is a list of recent display lines, output is a string.
  - Caller (TailScreen) owns the timer and the async loop.
  - Cost is tracked separately in /tmp/reflect-tail-synthesizer-cost.json so
    it does not pollute the per-wake cost line.
  - Uses the same ANTHROPIC_BASE_URL proxy as the wake runtime, which routes
    through the Claude Max OAuth proxy. Haiku model IDs pass through transparently.

Proxy note:
  The wake runtime sets ANTHROPIC_BASE_URL=http://localhost:9000 + ANTHROPIC_API_KEY=dummy
  (unless REFLECT_USE_API=1). The synthesizer reads these env vars automatically via the
  default Anthropic() constructor — no special setup required.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Optional

_COST_FILE = Path("/tmp/reflect-tail-synthesizer-cost.json")

_HAIKU_MODEL = "claude-haiku-4-5-20251001"

# Haiku 4.5 pricing (approximate, per 1M tokens)
_HAIKU_INPUT_PER_TOKEN = 0.80 / 1_000_000
_HAIKU_OUTPUT_PER_TOKEN = 4.00 / 1_000_000

_SYSTEM_PROMPT = (
    "You are summarizing a coding agent's current activity in a status bar.\n"
    "Read the recent thinking/tool log below. Output a single short title\n"
    "(max 50 characters, no quotes, no period) describing what the agent\n"
    "is doing right now. Prefer present-progressive (\"editing X\",\n"
    "\"searching Y\", \"writing dossier on Z\"). Be specific about the artifact\n"
    "in play when possible. No emoji."
)

_MAX_LINES = 30
_MAX_INPUT_CHARS = 8000  # ~2K tokens at ~4 chars/token
_MAX_OUTPUT_CHARS = 50


def _load_cost() -> dict:
    try:
        return json.loads(_COST_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        return {"total_usd": 0.0, "calls": 0, "session_start": time.time()}


def _save_cost(data: dict) -> None:
    try:
        _COST_FILE.write_text(json.dumps(data, indent=2))
    except OSError:
        pass


def _record_cost(input_tokens: int, output_tokens: int) -> None:
    data = _load_cost()
    usd = input_tokens * _HAIKU_INPUT_PER_TOKEN + output_tokens * _HAIKU_OUTPUT_PER_TOKEN
    data["total_usd"] = data.get("total_usd", 0.0) + usd
    data["calls"] = data.get("calls", 0) + 1
    data["last_call_usd"] = usd
    data["last_call_ts"] = time.time()
    _save_cost(data)


class StatusSynthesizer:
    """Synthesizes a one-line status title from recent transcript lines.

    Usage:
        synth = StatusSynthesizer()
        title = await synth.synthesize(display_lines)

    Thread-safe for the asyncio single-thread model (no locking needed).
    The Anthropic SDK is imported lazily so import doesn't fail if the
    package is absent (TUI still loads; synthesizer is disabled).
    """

    def __init__(self) -> None:
        self._last_input_hash: Optional[str] = None
        self._last_result: Optional[str] = None
        self._client = None  # lazy

    def _get_client(self):
        if self._client is None:
            try:
                import anthropic
                self._client = anthropic.Anthropic()
            except ImportError:
                raise RuntimeError("anthropic package not available")
        return self._client

    def _build_input(self, display_lines: list[str]) -> str:
        """Build the recent-history log for Haiku.

        Takes the last _MAX_LINES lines, formats as plain text, truncates
        from the head if over the char cap.
        """
        recent = display_lines[-_MAX_LINES:]
        text = "\n".join(recent)
        if len(text) > _MAX_INPUT_CHARS:
            text = text[-_MAX_INPUT_CHARS:]
        return text.strip()

    async def synthesize(self, display_lines: list[str]) -> Optional[str]:
        """Return a synthesized status string, or None if nothing to say.

        Caches by input hash — skips the API call if lines haven't changed.
        Raises on network/API errors; caller should catch and keep last value.
        """
        if not display_lines:
            return None

        user_text = self._build_input(display_lines)
        if not user_text:
            return None

        # Cache hit
        input_hash = hashlib.sha256(user_text.encode()).hexdigest()[:16]
        if input_hash == self._last_input_hash and self._last_result is not None:
            return self._last_result

        client = self._get_client()

        # Use sync client in asyncio context via run_in_executor or directly.
        # The Anthropic sync client is blocking but calls are short (~0.5-1s).
        # Run in a thread to avoid blocking the event loop.
        import asyncio
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, self._call_api, user_text)

        self._last_input_hash = input_hash
        self._last_result = result
        return result

    def _call_api(self, user_text: str) -> str:
        """Synchronous API call (runs in executor thread)."""
        client = self._get_client()
        response = client.messages.create(
            model=_HAIKU_MODEL,
            max_tokens=80,
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_text}],
        )
        # Record cost
        usage = response.usage
        inp = getattr(usage, "input_tokens", 0) or 0
        out = getattr(usage, "output_tokens", 0) or 0
        _record_cost(inp, out)

        # Extract text
        text = ""
        for block in response.content:
            if hasattr(block, "text"):
                text = block.text.strip()
                break

        # Truncate to max chars
        if len(text) > _MAX_OUTPUT_CHARS:
            text = text[:_MAX_OUTPUT_CHARS - 1] + "…"
        return text
