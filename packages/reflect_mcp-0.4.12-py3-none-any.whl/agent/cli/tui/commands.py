"""Slash-command parser for the session TUI.

Input lines starting with ``/`` are parsed as commands.  Anything else
is a plain message to be routed to the track.

Usage::

    if text.startswith("/"):
        try:
            cmd, arg = parse_command(text)
        except CommandError as e:
            show_error(str(e))

Commands supported:

    /wake               Fire a new wake of this track.
    /stop               Send a stop signal to the running wake.
    /inbox              List queued inbox messages.
    /inbox <n>          Peek at the nth queued message.
    /status             Print the full track status block.
    /clear              Clear the tail pane.
    /cost               Show current wake cost (from cost file).
    /diff [sha]         Show git diff for a wake commit.
    /help               List commands.
    /quit, /q           Exit session.
"""
from __future__ import annotations

# ── Public interface ──────────────────────────────────────────────────────────

COMMANDS = {
    "wake": "Fire a new wake of this track.",
    "stop": "Send a stop signal to the running wake.",
    "pause": "Cooperatively pause the running wake (stays alive; resume to continue).",
    "resume": "Resume a paused wake from where it left off.",
    "inbox": "List queued messages (or peek at /inbox <n>).",
    "status": "Print full track status.",
    "clear": "Clear the tail pane.",
    "cost": "Show current wake cost.",
    "diff": "Show git diff for a commit (most recent if no arg).",
    "grep": "Filter event buffer by pattern (/grep to restore full view).",
    "help": "List available commands.",
    "quit": "Exit session. Wake continues running.",
    "q": "Alias for /quit.",
}

HELP_TEXT = "\n".join(
    f"  /{name:<8} {desc}" for name, desc in COMMANDS.items() if name != "q"
)


class CommandError(Exception):
    """Raised when a slash-command is unrecognised or malformed."""


def parse_command(text: str) -> tuple[str, str]:
    """Parse a slash-command line.

    Args:
        text: Raw input text starting with ``/``.

    Returns:
        ``(command_name, arg_string)`` where *arg_string* may be empty.

    Raises:
        CommandError: if the command is not recognised or text doesn't start with ``/``.
    """
    if not text.startswith("/"):
        raise CommandError("Not a slash-command (must start with '/')")

    parts = text[1:].split(maxsplit=1)
    if not parts:
        raise CommandError("Empty command — type /help to list commands.")

    cmd = parts[0].lower().strip()
    arg = parts[1].strip() if len(parts) > 1 else ""

    if cmd not in COMMANDS:
        raise CommandError(f"Unknown command: /{cmd}  (type /help to list commands)")

    # Normalize alias
    if cmd == "q":
        cmd = "quit"

    return cmd, arg
