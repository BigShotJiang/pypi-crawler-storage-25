"""reflect docs — CLI formatting layer."""
from __future__ import annotations

import os
import subprocess
import sys
from types import SimpleNamespace

from agent.cli.ops.docs import list_docs, find_doc


def cmd_docs(args: SimpleNamespace) -> None:
    """View reflect documentation."""
    if args.list_all:
        topics = list_docs()
        if not topics:
            print("No docs found.")
            return
        print("Available docs:")
        for t in topics:
            print(f"  {t}")
        return

    if not args.topic:
        print("Usage: reflect docs <topic> or --list to see all docs", file=sys.stderr)
        raise SystemExit(1)

    doc_path = find_doc(args.topic)
    if doc_path is None:
        topics = list_docs()
        print(f"No docs found for '{args.topic}'.", file=sys.stderr)
        if topics:
            print("Available docs:", file=sys.stderr)
            for t in topics:
                print(f"  {t}", file=sys.stderr)
        raise SystemExit(1)

    if args.path_only:
        print(doc_path)
        return

    # Open in pager
    pager = os.environ.get("PAGER", "less")
    try:
        subprocess.run([pager, str(doc_path)])
    except FileNotFoundError:
        # Fallback: just print
        print(doc_path.read_text())
