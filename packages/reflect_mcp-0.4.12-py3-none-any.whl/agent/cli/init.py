"""Init subcommand for the reflect CLI."""
from __future__ import annotations

import sys
from pathlib import Path

from .ops.init import init_project


def cmd_init(args) -> None:
    result = init_project(args.name, path=args.path)
    if result["ok"]:
        print(result["message"])
    else:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
