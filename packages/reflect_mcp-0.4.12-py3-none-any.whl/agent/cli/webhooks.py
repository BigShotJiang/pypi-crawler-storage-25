"""Webhooks subcommands for the reflect CLI.

  reflect webhooks list          — show all registered webhooks
  reflect webhooks add <url>     — register a new webhook
  reflect webhooks remove <id>   — remove a webhook by id
  reflect webhooks test <id>     — POST a test.ping event to a webhook
"""
from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from typing import Optional


def cmd_webhooks_list(args) -> None:
    from .output import OutputMode
    from ..runtime.webhooks import list_webhooks

    mode = OutputMode(args.output)
    hooks = list_webhooks()

    if mode == OutputMode.JSON:
        print(json.dumps(hooks, indent=2))
        return

    if not hooks:
        print("(no webhooks registered)")
        return

    for h in hooks:
        status_icon = "✓" if h.get("enabled") else "✗"
        et = ", ".join(h.get("event_types") or []) or "all"
        tr = ", ".join(h.get("tracks") or []) or "all"
        created = (h.get("created_at") or "")[:19]
        print(f"{status_icon} {h['id']}  {h['url']}")
        print(f"   events={et}  tracks={tr}  created={created}")


def cmd_webhooks_add(args) -> None:
    from ..runtime.webhooks import add_webhook

    event_types: list[str] = list(getattr(args, "event_type", None) or [])
    tracks: list[str] = list(getattr(args, "track", None) or [])

    hook = add_webhook(url=args.url, event_types=event_types, tracks=tracks)
    print(f"Added webhook {hook['id']} → {hook['url']}")
    if event_types:
        print(f"  event filter: {', '.join(event_types)}")
    if tracks:
        print(f"  track filter: {', '.join(tracks)}")


def cmd_webhooks_remove(args) -> None:
    from ..runtime.webhooks import remove_webhook

    ok = remove_webhook(args.id)
    if ok:
        print(f"Removed webhook {args.id}")
    else:
        print(f"reflect webhooks: no webhook with id {args.id!r}", file=sys.stderr)
        sys.exit(1)


def cmd_webhooks_test(args) -> None:
    """POST a test.ping event to a specific webhook and report the result."""
    from ..runtime.webhooks import list_webhooks

    hooks = list_webhooks()
    hook = next((h for h in hooks if h.get("id") == args.id), None)
    if hook is None:
        print(f"reflect webhooks: no webhook with id {args.id!r}", file=sys.stderr)
        sys.exit(1)

    event = {
        "id": f"evt_{int(time.time() * 1000)}_test",
        "type": "test.ping",
        "at": datetime.now(timezone.utc).isoformat(),
        "track": "main",
        "wake_id": "test",
        "event_schema_version": "1.0",
        "payload": {"test": True, "hook_id": hook["id"]},
    }

    body = json.dumps(event, default=str).encode()
    req = urllib.request.Request(
        hook["url"],
        data=body,
        headers={
            "Content-Type": "application/json",
            "X-Reflect-Event": "test.ping",
            "X-Reflect-Track": "main",
            "User-Agent": "reflect-webhook/1.0",
        },
        method="POST",
    )
    print(f"POSTing test.ping to {hook['url']} ...")
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            status = resp.getcode()
            print(f"✓ responded HTTP {status}")
    except urllib.error.HTTPError as exc:
        print(f"✗ HTTP {exc.code}: {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        print(f"✗ {exc}", file=sys.stderr)
        sys.exit(1)
