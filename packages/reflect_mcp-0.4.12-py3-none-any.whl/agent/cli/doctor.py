"""Health check subcommand for the reflect CLI."""
from __future__ import annotations

import fcntl
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

from .output import OutputMode, print_list
from .ops.track import (
    TRACKS_DIR,
    PROJECT_ROOT,
    _is_pid_alive,
    _read_lock_pid,
)

def _track_names():
    from .ops.track import list_tracks
    return list_tracks()

SCRY_DB = PROJECT_ROOT / "agent" / "drivers" / "@local" / "scry" / "data" / "project.db"
STATE_DB = PROJECT_ROOT / "agent" / "runtime" / "state.db"
DISPATCH_LOG = Path("/tmp/reflect-dispatch.log")


def _check(check_id: str, condition: bool, pass_msg: str, warn_msg: str, status_if_fail: str = "WARN") -> dict:
    if condition:
        return {"check": check_id, "status": "PASS", "message": pass_msg}
    return {"check": check_id, "status": status_if_fail, "message": warn_msg}


def run_checks() -> list[dict]:
    results = []

    # 1. crontab line
    try:
        out = subprocess.run(
            ["crontab", "-l"],
            capture_output=True,
            text=True,
        )
        has_dispatch = "reflect-dispatch" in out.stdout
    except (OSError, subprocess.SubprocessError):
        has_dispatch = False
    results.append(_check(
        "crontab-line",
        has_dispatch,
        "crontab contains reflect-dispatch",
        "crontab does not contain reflect-dispatch — dispatcher may not be running",
    ))

    # 2. dispatch log freshness (5 min)
    if DISPATCH_LOG.exists():
        age = time.time() - DISPATCH_LOG.stat().st_mtime
        fresh = age < 300
        results.append(_check(
            "dispatch-log-fresh",
            fresh,
            f"dispatch log updated {int(age)}s ago",
            f"dispatch log is stale ({int(age)}s ago) — cron may not be firing",
        ))
    else:
        results.append({
            "check": "dispatch-log-fresh",
            "status": "WARN",
            "message": f"dispatch log not found at {DISPATCH_LOG}",
        })

    # Per-track checks
    now = time.time()
    for name in _track_names():
        track_dir = TRACKS_DIR / name
        lock_path = track_dir / "wake.lock"

        is_disabled = (track_dir / "disabled.flag").exists()

        if lock_path.exists() and not is_disabled:
            # Zombie lock: try to acquire a non-blocking flock.
            # If we CAN acquire it, no wake is holding it (idle — fine).
            # If we CANNOT, a wake is running — that's expected when active.
            # A "zombie" is: flock held, but the pid that should own it is dead.
            # Since pids aren't written to the lock file, we detect this by
            # checking if the lock is held AND no reflect-wake process for this
            # track is running.
            try:
                with open(lock_path, "r") as fd:
                    held = False
                    try:
                        fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        fcntl.flock(fd.fileno(), fcntl.LOCK_UN)
                        # Lock not held — track is idle, no check needed
                    except BlockingIOError:
                        held = True
                if held:
                    # Lock IS held — check if a reflect-wake process exists for this track
                    try:
                        ps_out = subprocess.run(
                            ["pgrep", "-f", f"REFLECT_TRACK={name}"],
                            capture_output=True, text=True
                        )
                        has_process = ps_out.returncode == 0 and ps_out.stdout.strip()
                    except OSError:
                        has_process = True  # can't check; assume OK
                    results.append(_check(
                        f"zombie-lock-{name}",
                        bool(has_process),
                        f"lock held by live wake process",
                        f"lock held but no reflect-wake process found for {name} — zombie lock",
                    ))
            except OSError:
                pass

            # Stuck lock: mtime > 1 hour
            try:
                lock_age = now - lock_path.stat().st_mtime
                results.append(_check(
                    f"stuck-lock-{name}",
                    lock_age < 3600,
                    f"lock age {int(lock_age)}s is within 1 hour",
                    f"lock has been held for {int(lock_age)}s (>{3600}s) — possible stuck wake",
                ))
            except OSError:
                pass

        # Objective exists — skip human tracks (they use human.flag, not objective.md)
        if not (track_dir / "human.flag").exists():
            obj = track_dir / "objective.md"
            results.append(_check(
                f"objective-{name}",
                obj.exists(),
                f"objective.md exists for {name}",
                f"objective.md missing for track {name}",
            ))

    # Proxy: TCP reachability
    proxy_reachable = False
    try:
        with socket.create_connection(("127.0.0.1", 9000), timeout=1):
            proxy_reachable = True
    except (OSError, socket.timeout):
        proxy_reachable = False
    results.append(_check(
        "proxy-running",
        proxy_reachable,
        "Claude OAuth proxy is reachable at 127.0.0.1:9000",
        "Claude OAuth proxy not reachable at 127.0.0.1:9000 — start with ~/scripts/claude/proxy.py or the systemd unit; set REFLECT_USE_API=1 to bypass",
        status_if_fail="WARN",
    ))

    # Proxy: credentials validity
    creds_path = Path.home() / ".claude" / ".credentials.json"
    if creds_path.exists():
        try:
            creds = json.loads(creds_path.read_text())
            expires_at = creds.get("claudeAiOauth", {}).get("expiresAt", 0)
            # expiresAt is in milliseconds
            expires_ts = expires_at / 1000.0
            now_ts = time.time()
            if expires_ts > now_ts + 7 * 86400:
                results.append({"check": "proxy-credentials-valid", "status": "PASS",
                                 "message": f"OAuth token valid; expires {time.strftime('%Y-%m-%dT%H:%MZ', time.gmtime(expires_ts))}"})
            elif expires_ts > now_ts:
                days_left = int((expires_ts - now_ts) / 86400)
                results.append({"check": "proxy-credentials-valid", "status": "WARN",
                                 "message": f"OAuth token expires in {days_left}d — run `claude --version` to refresh"})
            else:
                results.append({"check": "proxy-credentials-valid", "status": "FAIL",
                                 "message": "OAuth token expired — run `claude --version` to refresh, or set REFLECT_USE_API=1 to bypass"})
        except (json.JSONDecodeError, OSError, KeyError, TypeError) as e:
            results.append({"check": "proxy-credentials-valid", "status": "WARN",
                             "message": f"Could not parse {creds_path}: {e}"})
    else:
        results.append({"check": "proxy-credentials-valid", "status": "WARN",
                         "message": f"Credentials file not found at {creds_path} — proxy may not authenticate"})

    # scry DB + state DB — check per project root.
    #
    # When reflect-mcp is installed via `uv tool install` without REFLECT_PROJECT
    # set, PROJECT_ROOT resolves to the install-site directory (not the user's
    # project).  In that case SCRY_DB won't exist at the install site, so we fall
    # back to iterating linked project targets (agent/projects/ symlinks).
    # This produces per-project PASS/WARN entries rather than one spurious WARN
    # pointing at the install-site.  See v0.3.2 CHANGELOG.
    _db_roots: list[tuple[str, Path]] = []  # (label_suffix, project_root)
    if SCRY_DB.exists():
        # Primary root is correct (in-tree dev or REFLECT_PROJECT set) — use it.
        _db_roots.append(("", PROJECT_ROOT))
    else:
        # Primary root has no scry DB — look at linked project targets.
        _projects_dir = PROJECT_ROOT / "agent" / "projects"
        if _projects_dir.is_dir():
            for _entry in sorted(_projects_dir.iterdir()):
                if _entry.name.startswith("."):
                    continue
                if _entry.is_dir() and (
                    _entry.is_symlink() or (_entry / "agent").is_dir()
                ):
                    _db_roots.append((f"-{_entry.name}", _entry.resolve()))
        if not _db_roots:
            # No linked projects found; fall back to primary root so we at least
            # emit a diagnostic (WARN) rather than silently skipping.
            _db_roots.append(("", PROJECT_ROOT))

    for _suffix, _root in _db_roots:
        _scry_db = _root / "agent" / "drivers" / "@local" / "scry" / "data" / "project.db"
        results.append(_check(
            f"scry-db{_suffix}",
            _scry_db.exists() and os.access(_scry_db, os.R_OK),
            f"scry DB readable at {_scry_db}",
            f"scry DB not readable at {_scry_db}",
        ))
        _state_db = _root / "agent" / "runtime" / "state.db"
        results.append(_check(
            f"state-db{_suffix}",
            _state_db.exists(),
            f"state DB exists at {_state_db}",
            f"state DB not found at {_state_db} (optional)",
        ))

    # Multi-project checks
    projects_dir = PROJECT_ROOT / "agent" / "projects"
    if projects_dir.is_dir():
        for entry in sorted(projects_dir.iterdir()):
            if entry.name.startswith("."):
                continue
            if entry.is_symlink():
                alive = entry.is_dir()
                results.append(_check(
                    f"project-link-{entry.name}",
                    alive,
                    f"symlink {entry.name} -> {os.readlink(str(entry))} resolves",
                    f"dead symlink {entry.name} -> {os.readlink(str(entry))} (target gone)",
                    status_if_fail="ERROR",
                ))
                if alive:
                    # Check reverse-pointer marker exists
                    from .project import _marker_path, _orch_hash, PROJECT_ROOT as PR
                    target = entry.resolve()
                    marker = _marker_path(target)
                    results.append(_check(
                        f"project-marker-{entry.name}",
                        marker.exists(),
                        f"orchestrator marker exists for {entry.name}",
                        f"orchestrator marker missing for {entry.name} — run `reflect project link {entry.name}` to heal",
                    ))
            elif entry.is_dir() and (entry / "agent").is_dir():
                # Nested project — real dir at agent/projects/<name> with its own agent/ subtree.
                from .project import _marker_path
                marker = _marker_path(entry)
                results.append(_check(
                    f"project-nested-{entry.name}",
                    marker.exists(),
                    f"nested project {entry.name} registered",
                    f"nested project {entry.name} missing marker — run `reflect project link {entry}` to heal",
                ))
            else:
                results.append({
                    "check": f"project-entry-{entry.name}",
                    "status": "WARN",
                    "message": f"agent/projects/{entry.name} is not a symlink or nested project",
                })

    # Inbox staleness: unread .md files older than 60min in active track inboxes
    STALE_INBOX_THRESHOLD = 3600  # 60 minutes
    for name in _track_names():
        track_dir = TRACKS_DIR / name
        if (track_dir / "human.flag").exists():
            continue
        if (track_dir / "disabled.flag").exists():
            continue
        inbox_dir = track_dir / "inbox"
        if not inbox_dir.is_dir():
            continue
        unread = [f for f in inbox_dir.iterdir() if f.is_file() and f.suffix == ".md"]
        for msg in unread:
            try:
                age = now - msg.stat().st_mtime
            except OSError:
                continue
            if age > STALE_INBOX_THRESHOLD:
                results.append({
                    "check": f"stale-inbox-{name}",
                    "status": "WARN",
                    "message": f"unread inbox message {msg.name} in {name} is {int(age/60)}min old",
                })

    # Stale sandbox worktrees
    try:
        wt_out = subprocess.run(
            ["git", "worktree", "list", "--porcelain"],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
        )
        for line in wt_out.stdout.splitlines():
            if line.startswith("worktree ") and ".sandbox-" in line:
                wt_path = line.split("worktree ", 1)[1]
                results.append({
                    "check": "stale-sandbox",
                    "status": "WARN",
                    "message": f"stale sandbox worktree: {wt_path} — run `git worktree remove {wt_path}` to clean up",
                })
    except (OSError, subprocess.SubprocessError):
        pass

    # Orphaned sandbox branches (reflect/sandbox-* with no worktree)
    try:
        br_out = subprocess.run(
            ["git", "branch", "--list", "reflect/sandbox-*"],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
        )
        active_sandboxes = set()
        for line in wt_out.stdout.splitlines():
            if line.startswith("branch refs/heads/reflect/sandbox-"):
                active_sandboxes.add(line.split("refs/heads/")[1])
        for line in br_out.stdout.splitlines():
            branch = line.strip().lstrip("* ")
            if branch and branch not in active_sandboxes:
                results.append({
                    "check": "orphan-sandbox-branch",
                    "status": "WARN",
                    "message": f"orphaned sandbox branch: {branch} — run `git branch -D {branch}` to clean up",
                })
    except (OSError, subprocess.SubprocessError):
        pass

    return results


def cmd_doctor(args) -> None:
    mode = OutputMode(args.output)
    checks = run_checks()

    if mode == OutputMode.JSON:
        print(json.dumps(checks, indent=2))
    else:
        # Human output
        from rich.console import Console
        from rich.table import Table

        try:
            console = Console()
            table = Table(show_header=True, header_style="bold")
            table.add_column("check")
            table.add_column("status")
            table.add_column("message")
            for c in checks:
                status = c["status"]
                style = ""
                if status == "PASS":
                    style = "green"
                elif status == "WARN":
                    style = "yellow"
                elif status == "ERROR":
                    style = "red"
                table.add_row(c["check"], f"[{style}]{status}[/{style}]", c["message"])
            console.print(table)
        except ImportError:
            # Plain text fallback
            for c in checks:
                print(f"[{c['status']}] {c['check']}: {c['message']}")

    # Exit codes
    statuses = {c["status"] for c in checks}
    if "ERROR" in statuses:
        sys.exit(2)
    elif "WARN" in statuses:
        sys.exit(1)
    else:
        sys.exit(0)
