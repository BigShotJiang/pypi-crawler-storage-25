"""Pure project operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured dicts. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Optional

from agent.cli.ops.root import resolve_project_root
PROJECT_ROOT = resolve_project_root()
PROJECTS_DIR = PROJECT_ROOT / "agent" / "projects"


# ── helpers ────────────────────────────────────────────────────────────────


def _orch_hash(root: Optional[Path] = None) -> str:
    base = root or PROJECT_ROOT
    return hashlib.sha256(str(base).encode()).hexdigest()[:12]


def _marker_path(project_dir: Path, root: Optional[Path] = None) -> Path:
    return project_dir / "agent" / "runtime" / "orchestrators" / f"{_orch_hash(root)}.path"


def _validate_foreign_markers(project_dir: Path) -> list[str]:
    orch_dir = project_dir / "agent" / "runtime" / "orchestrators"
    if not orch_dir.is_dir():
        return []
    my_hash = _orch_hash()
    valid_foreign: list[str] = []
    for marker_file in orch_dir.glob("*.path"):
        if marker_file.stem == my_hash:
            continue
        try:
            orch_path_str = marker_file.read_text().strip()
            orch_path = Path(orch_path_str)
            if not orch_path.is_dir():
                marker_file.unlink(missing_ok=True)
                continue
            expected_link = orch_path / "agent" / "projects" / project_dir.name
            if not expected_link.is_symlink():
                continue
            link_target = expected_link.resolve()
            if link_target != project_dir.resolve():
                continue
            valid_foreign.append(orch_path_str)
        except (OSError, ValueError):
            pass
    return valid_foreign


# ── public ops ─────────────────────────────────────────────────────────────


def list_projects(projects_dir: Optional[Path] = None) -> list[dict]:
    """Return list of linked project dicts.

    Each dict: {name, target, status, kind}
        status = "ok" | "dead" | "not-symlink"
        kind   = "linked" | "nested"  (only present when status == "ok")

    Nested projects are real directories placed directly under agent/projects/
    that contain their own agent/ subtree — first-class peers of linked
    (symlinked) projects.
    """
    pd = projects_dir or PROJECTS_DIR
    if not pd.exists():
        return []
    rows = []
    for entry in sorted(pd.iterdir()):
        if entry.name.startswith("."):
            continue
        if entry.is_symlink():
            try:
                target = os.readlink(str(entry))
            except OSError:
                target = "?"
            alive = entry.is_dir()
            row = {"name": entry.name, "target": target, "status": "ok" if alive else "dead"}
            if alive:
                row["kind"] = "linked"
            rows.append(row)
        elif entry.is_dir() and (entry / "agent").is_dir():
            rows.append({"name": entry.name, "target": str(entry),
                         "status": "ok", "kind": "nested"})
        else:
            rows.append({"name": entry.name, "target": str(entry), "status": "not-symlink"})
    return rows


def link_project(path: str, projects_dir: Optional[Path] = None) -> dict:
    """Link a project directory into this orchestrator.

    Returns {"ok": bool, "message": str, "link_path": str|None, "marker": str|None}
    """
    pd = projects_dir or PROJECTS_DIR
    target = Path(path).resolve()
    if not target.is_dir():
        return {"ok": False, "message": f"Not a directory: {target}", "link_path": None, "marker": None}

    name = target.name
    link_path = pd / name
    pd.mkdir(parents=True, exist_ok=True)

    # Nested-project case: target already sits at the canonical agent/projects/<name>
    # location as a real directory. No symlink to create — just write the marker so
    # mutual-exclusion + doctor checks treat it like a first-class linked project.
    if link_path.exists() and not link_path.is_symlink() and link_path.resolve() == target:
        marker = _marker_path(target)
        already = marker.exists()
        if not already:
            marker.parent.mkdir(parents=True, exist_ok=True)
            marker.write_text(str(PROJECT_ROOT))
        verb = "Already registered" if already else "Registered"
        return {"ok": True,
                "message": f"{verb} nested project: {target}",
                "link_path": str(link_path), "marker": str(marker)}

    if link_path.is_symlink():
        if link_path.resolve() == target:
            marker = _marker_path(target)
            if not marker.exists():
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text(str(PROJECT_ROOT))
                return {"ok": True, "message": f"Already linked (healed marker): {link_path} -> {target}",
                        "link_path": str(link_path), "marker": str(marker)}
            return {"ok": True, "message": f"Already linked: {link_path} -> {target}",
                    "link_path": str(link_path), "marker": str(_marker_path(target))}
        else:
            return {"ok": False,
                    "message": f"{link_path} already exists pointing elsewhere. Unlink first.",
                    "link_path": str(link_path), "marker": None}

    if link_path.exists():
        return {"ok": False, "message": f"{link_path} already exists (not a symlink).",
                "link_path": str(link_path), "marker": None}

    foreign = _validate_foreign_markers(target)
    if foreign:
        return {"ok": False,
                "message": f"{target} is already linked by another orchestrator: {foreign}",
                "link_path": None, "marker": None}

    marker = _marker_path(target)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(str(PROJECT_ROOT))
    os.symlink(str(target), str(link_path))
    return {"ok": True, "message": f"Linked: {link_path} -> {target}",
            "link_path": str(link_path), "marker": str(marker)}


def unlink_project(name: str, projects_dir: Optional[Path] = None) -> dict:
    """Unlink a project by name.

    Returns {"ok": bool, "message": str}
    """
    pd = projects_dir or PROJECTS_DIR
    if os.sep in name or name.startswith("."):
        target_path = Path(name).resolve()
        name = target_path.name
    link_path = pd / name

    if not link_path.exists() and not link_path.is_symlink():
        return {"ok": False, "message": f"No linked project named '{name}'."}

    if link_path.is_symlink():
        target = link_path.resolve()
        marker = _marker_path(target)
        marker.unlink(missing_ok=True)
        link_path.unlink()
        return {"ok": True, "message": f"Unlinked: {link_path}. Removed marker: {marker}"}
    else:
        link_path.unlink()
        return {"ok": True, "message": f"Removed: {link_path}"}
