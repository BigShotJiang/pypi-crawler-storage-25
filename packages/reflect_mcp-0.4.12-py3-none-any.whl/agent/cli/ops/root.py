"""Project root resolution for reflect ops.

Re-exports resolve_project_root() from agent.lib.root — the canonical
lib-layer implementation. Import from here or directly from agent.lib.root;
both are stable.

Resolution order (first match wins):
  1. REFLECT_PROJECT env var — absolute path to the project root.
     Set this in ~/.claude.json under the MCP server's "env" key when running
     reflect-manage as an MCP server outside its own project directory:
       "reflect": {"command": "reflect-manage", "env": {"REFLECT_PROJECT": "/path/to/project"}}
  2. File-relative fallback — correct when reflect runs from its own source
     tree (development mode or reflect's own wakes).
"""
from __future__ import annotations

# Re-export for backward compat — callers that import from here still work.
from agent.lib.root import resolve_project_root  # noqa: F401
