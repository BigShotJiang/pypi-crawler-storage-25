"""Pure business logic for reflect CLI operations.

Each module exposes pure functions that return structured data (dicts or dataclasses).
CLI adapters in agent/cli/ call these and format for terminal output.
MCP adapters in agent/mcp/ call these and return JSON to external agents.
"""
