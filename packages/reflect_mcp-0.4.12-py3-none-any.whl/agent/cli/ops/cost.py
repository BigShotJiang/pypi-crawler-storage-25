"""Pure cost / spend aggregation operations.

All functions return structured dicts. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .wake import get_wake_history, WAKES_TSV, PROJECT_ROOT


def _get_wake_track(wake_id: str) -> Optional[str]:
    wake_dir = PROJECT_ROOT / "agent" / "runtime" / "wakes" / wake_id
    try:
        return (wake_dir / "track.name").read_text().strip()
    except OSError:
        return None


def _parse_since(since_str: str) -> float:
    """Parse a --since value: ISO datetime or unix timestamp."""
    try:
        return float(since_str)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%MZ", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(since_str, fmt).replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except ValueError:
            continue
    raise ValueError(f"Cannot parse since value: {since_str!r}")


def _load_rows(since_ts: Optional[float] = None) -> list[dict]:
    """Load wakes.tsv rows, optionally filtered to rows after *since_ts*."""
    if not WAKES_TSV.exists():
        return []
    rows: list[dict] = []
    try:
        lines = WAKES_TSV.read_text().splitlines()
        if not lines:
            return []
        headers = lines[0].split("\t")
        for line in lines[1:]:
            if not line.strip():
                continue
            parts = line.split("\t")
            row = dict(zip(headers, parts))
            # Normalize legacy column name
            if "cost_usd" in row and "api_equivalent_usd" not in row:
                row["api_equivalent_usd"] = row.pop("cost_usd")
            rows.append(row)
    except OSError:
        return []

    if since_ts is not None:
        filtered = []
        for row in rows:
            try:
                started = float(row.get("started_at", "0"))
                if started >= since_ts:
                    filtered.append(row)
            except (ValueError, TypeError):
                filtered.append(row)
        rows = filtered

    return rows


def get_cost_summary(
    by_track: bool = False,
    since: Optional[str] = None,
) -> dict | list[dict]:
    """Return cost aggregation.

    Without *by_track*: returns a single dict with total, count, avg.
    With *by_track*: returns a list of per-track dicts sorted by track name.

    *since*: optional ISO timestamp or unix float string to filter rows.

    Raises ValueError if *since* cannot be parsed.
    """
    since_ts: Optional[float] = None
    if since:
        since_ts = _parse_since(since)

    rows = _load_rows(since_ts)

    if not rows:
        if by_track:
            return []
        return {
            "total_api_equivalent_usd": 0.0,
            "wake_count": 0,
            "avg_api_equivalent_usd": 0.0,
        }

    if by_track:
        track_costs: dict[str, list[float]] = {}
        for row in rows:
            wake_id = row.get("wake_id", "")
            track = _get_wake_track(wake_id) or "(unknown)"
            try:
                cost = float(row.get("api_equivalent_usd") or row.get("cost_usd", "0"))
            except (ValueError, TypeError):
                cost = 0.0
            track_costs.setdefault(track, []).append(cost)

        result = []
        for track, costs in sorted(track_costs.items()):
            result.append({
                "track": track,
                "total_api_equivalent_usd": round(sum(costs), 6),
                "wake_count": len(costs),
                "avg_api_equivalent_usd": round(sum(costs) / len(costs), 6) if costs else 0.0,
            })
        return result

    total = 0.0
    count = 0
    for row in rows:
        try:
            cost = float(row.get("api_equivalent_usd") or row.get("cost_usd", "0"))
            total += cost
            count += 1
        except (ValueError, TypeError):
            pass

    return {
        "total_api_equivalent_usd": round(total, 6),
        "wake_count": count,
        "avg_api_equivalent_usd": round(total / count, 6) if count else 0.0,
    }
