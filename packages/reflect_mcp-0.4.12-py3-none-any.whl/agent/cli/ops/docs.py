"""Pure docs operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured data. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from agent.lib.root import resolve_project_root

# Docs bundled with package — resolve relative to project root
DOCS_DIR = resolve_project_root() / "docs"


def list_docs() -> list[str]:
    """Return a sorted list of available doc topics (relative paths without .md)."""
    if not DOCS_DIR.exists():
        return []
    return sorted(
        str(md.relative_to(DOCS_DIR).with_suffix(""))
        for md in DOCS_DIR.rglob("*.md")
    )


def find_doc(topic: str) -> Path | None:
    """Find a doc by topic. Tries exact match, then substring match."""
    if not DOCS_DIR.exists():
        return None

    # Exact match: topic.md or topic as relative path
    exact = DOCS_DIR / f"{topic}.md"
    if exact.is_file():
        return exact

    # Try with .md already
    exact2 = DOCS_DIR / topic
    if exact2.is_file():
        return exact2

    # Substring/glob match
    candidates = list(DOCS_DIR.rglob(f"*{topic}*.md"))
    if candidates:
        return candidates[0]

    return None


def read_doc(topic: str) -> dict[str, Any]:
    """Read a doc's content. Returns {path, content} or {error}."""
    doc = find_doc(topic)
    if doc is None:
        return {"error": f"No docs found for '{topic}'", "available": list_docs()}
    return {
        "path": str(doc.relative_to(DOCS_DIR)),
        "content": doc.read_text(),
    }
