"""Permission gate for autonomous wakes.

The SDK already scopes file ops and Bash to `cwd`. This hook adds a thin layer of
deny rules for shell commands that are dangerous even within the working directory:
git push, hard resets, branch manipulation that leaves the wake's work in limbo.

Everything else is allowed by default — the safety net is git history (originator
can revert) plus the per-wake token/iteration caps.
"""
from typing import Any

from claude_agent_sdk import (
    PermissionResultAllow,
    PermissionResultDeny,
    ToolPermissionContext,
)


_FORBIDDEN_BASH_PATTERNS = (
    "git push",  # never push; affects shared state
    "rm -rf /",
    "rm -rf ~",
    "sudo ",
)


# Files the agent must not modify. The shim under bin/ is the rollback escape
# hatch; modifying it defeats recovery. Identity files reshape who reflection is —
# proposed changes go in the report under "what's still open" for originator review.
_FORBIDDEN_WRITE_PATHS = (
    "bin/reflect-wake",
    "concept.md",
    "wake.md",
    "agent/design/reflection.md",
    "agent/driver.yaml",
)


async def can_use_tool(
    tool_name: str, tool_input: dict[str, Any], context: ToolPermissionContext
) -> PermissionResultAllow | PermissionResultDeny:
    if tool_name == "Bash":
        cmd = tool_input.get("command", "")
        for pattern in _FORBIDDEN_BASH_PATTERNS:
            if pattern in cmd:
                return PermissionResultDeny(
                    message=(
                        f"Command blocked by reflection's wake bounds: pattern "
                        f"{pattern!r} is forbidden in autonomous wakes. If this is "
                        f"genuinely needed, surface it in the report under 'what's "
                        f"still open' and the originator can run it next session."
                    ),
                    interrupt=False,
                )

    if tool_name in ("Write", "Edit"):
        path = tool_input.get("file_path", "")
        for forbidden in _FORBIDDEN_WRITE_PATHS:
            # Match either a direct hit or a hit inside a sandbox worktree
            # (sandbox paths look like agent/runtime/.sandbox-<id>/<forbidden>).
            if path.endswith(forbidden) or f"/{forbidden}" in path:
                return PermissionResultDeny(
                    message=(
                        f"Write blocked: {forbidden} is off-limits to the agent. "
                        f"If you need to change it, surface a proposal in your "
                        f"report's 'What's still open' section."
                    ),
                    interrupt=False,
                )

    return PermissionResultAllow()
