"""Unit tests for wake event lifecycle and lock coordination.

Tests:
1. test_stop_requested_emits_wake_failed
2. test_orphan_detection_reaps_dead_pid
3. test_live_pid_lock_rejected

Run with:
    uv run pytest agent/runtime/tests/test_wake_events.py -v
"""
from __future__ import annotations

import os
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_emit_tracker():
    """Return (tracker_list, mock_emit) — mock_emit appends (event, kwargs) to tracker."""
    tracker = []

    def mock_emit(event, **kwargs):
        tracker.append((event, kwargs))

    return tracker, mock_emit


# ---------------------------------------------------------------------------
# Fix A: early exit paths emit wake.failed
# ---------------------------------------------------------------------------

def test_stop_requested_emits_wake_failed(tmp_path):
    """Pre-wake stop.requested check must emit wake.failed (not wake.completed)."""
    # Set up a fake TRACK_DIR with a stop.requested file
    track_dir = tmp_path / "tracks" / "main"
    track_dir.mkdir(parents=True)
    stop_file = track_dir / "stop.requested"
    stop_file.write_text("stop")

    emitted, mock_emit = _make_emit_tracker()

    # Patch the module-level symbols that _run_wake uses
    with (
        patch("agent.runtime.wake.TRACK_DIR", track_dir),
        patch("agent.runtime.wake.REFLECT_TRACK", "main"),
        patch("agent.runtime.wake.LAST_WAKE_TIMESTAMP", track_dir / "last-wake.timestamp"),
        patch("agent.runtime.wake.NEXT_WAKE_BY", track_dir / "next-wake-by.timestamp"),
        patch("agent.runtime.wake.WAKES_DIR", tmp_path / "wakes"),
        patch("agent.runtime.wake.WAKES_TSV", tmp_path / "wakes.tsv"),
        patch("agent.runtime.wake.PROJECT_ROOT", tmp_path),
        patch("agent.runtime.wake.emit_event", side_effect=mock_emit),
        patch("agent.runtime.wake._events_set_runtime_root"),
        patch("agent.runtime.wake.mark_running"),
        patch("agent.runtime.wake.mark_idle"),
        patch("agent.runtime.wake.mark_unhealthy"),
    ):
        import asyncio
        import agent.runtime.wake as wake_mod
        # Ensure the wakes dir exists so transcript_dir.mkdir doesn't fail
        (tmp_path / "wakes").mkdir(parents=True, exist_ok=True)
        result = asyncio.run(wake_mod._run_wake())

    # Should exit 0 (stop = graceful, not error)
    assert result == 0

    # The very first "wake.failed" event must have been emitted for stop_requested
    failed_events = [(e, kw) for e, kw in emitted if e == "wake.failed"]
    assert len(failed_events) >= 1, f"Expected wake.failed, got: {[e for e, _ in emitted]}"

    # The early-exit wake.failed should be for stop_requested
    early_failed = failed_events[0]
    assert early_failed[1]["payload"]["early_break_reason"] == "stop_requested"


# ---------------------------------------------------------------------------
# Fix F: tick.py orphan detection
# ---------------------------------------------------------------------------

def test_orphan_detection_reaps_dead_pid(tmp_path):
    """acquire_track_lock should reap a wake.lock containing a dead PID and return a lock."""
    track_dir = tmp_path / "agent" / "runtime" / "tracks" / "main"
    track_dir.mkdir(parents=True)
    lockfile = track_dir / "wake.lock"

    # Write a PID that is guaranteed to be dead (PID 1 is init but we use a very
    # large number that almost certainly doesn't exist; os.kill(pid, 0) raises
    # ProcessLookupError for missing PIDs on Linux).
    dead_pid = 999999999
    lockfile.write_text(f"{dead_pid}\n")

    with (
        patch("agent.lib.tick._effective_project_root", return_value=tmp_path),
        patch("agent.lib.tick.logger"),
    ):
        import agent.lib.tick as tick_mod
        # Reload to pick up patches
        fd = tick_mod.acquire_track_lock("main")

    assert fd is not None, "Expected a lock fd for dead PID, got None"
    try:
        fd.close()
    except Exception:
        pass

    # The orphaned file should have been removed (and replaced by an open(lockfile, "w"))
    # The lock was opened and held — file exists but was rewritten
    # Primary assertion: function did NOT return None
    assert True


def test_live_pid_lock_rejected(tmp_path):
    """acquire_track_lock should return None when wake.lock contains the current PID."""
    track_dir = tmp_path / "agent" / "runtime" / "tracks" / "main"
    track_dir.mkdir(parents=True)
    lockfile = track_dir / "wake.lock"

    # Write own PID — this process is definitely alive
    own_pid = os.getpid()
    lockfile.write_text(f"{own_pid}\n")

    with (
        patch("agent.lib.tick._effective_project_root", return_value=tmp_path),
        patch("agent.lib.tick.logger"),
    ):
        import agent.lib.tick as tick_mod
        fd = tick_mod.acquire_track_lock("main")

    assert fd is None, (
        f"Expected None (live PID {own_pid} holds lock), got fd={fd}"
    )
