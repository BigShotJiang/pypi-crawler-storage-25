"""Webhook registry and delivery for the reflect event stream.

Webhooks are stored in agent/runtime/webhooks.json as a list of objects:
  { id, url, event_types, tracks, created_at, enabled }

Filtering:
  event_types: [] → all event types deliver
  tracks:      [] → all tracks deliver

Delivery is fire-and-forget via a module-level ThreadPoolExecutor.
HTTP POST with JSON body = full event envelope.
Headers: Content-Type, X-Reflect-Event, X-Reflect-Track, User-Agent.
Timeouts: 5 seconds (connect + read). Non-2xx is logged; no retry in v1.

Design doc: agent/design/events-schema.md
"""
from __future__ import annotations

import json
import secrets
import sys
import threading
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Module-level thread pool for delivery (daemon threads — don't block Python exit)
_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="wh-delivery")

# RLock for webhooks.json reads/writes
_lock = threading.RLock()

_DEFAULT_RUNTIME_ROOT: Optional[Path] = None


def _runtime_root() -> Path:
    if _DEFAULT_RUNTIME_ROOT is not None:
        return _DEFAULT_RUNTIME_ROOT
    return Path(__file__).parent


def set_runtime_root(path: Path) -> None:
    """Called by wake.py on startup to mirror events.py root resolution."""
    global _DEFAULT_RUNTIME_ROOT
    _DEFAULT_RUNTIME_ROOT = path


def _config_path(runtime_root: Path) -> Path:
    return runtime_root / "webhooks.json"


def _load(runtime_root: Path) -> list[dict]:
    """Read webhooks.json; return [] on missing/corrupt."""
    path = _config_path(runtime_root)
    if not path.exists():
        return []
    try:
        with path.open() as fh:
            data = json.load(fh)
            if isinstance(data, list):
                return data
    except (json.JSONDecodeError, OSError):
        pass
    return []


def _save(hooks: list[dict], runtime_root: Path) -> None:
    """Atomic write via tmp-then-replace."""
    path = _config_path(runtime_root)
    tmp = path.with_suffix(".tmp")
    with tmp.open("w") as fh:
        json.dump(hooks, fh, indent=2, default=str)
        fh.write("\n")
    tmp.replace(path)


# ── Public CRUD ────────────────────────────────────────────────────────────────


def list_webhooks(runtime_root: Optional[Path] = None) -> list[dict]:
    """Return a copy of all registered webhooks."""
    root = runtime_root or _runtime_root()
    with _lock:
        return list(_load(root))


def add_webhook(
    url: str,
    event_types: list[str],
    tracks: list[str],
    runtime_root: Optional[Path] = None,
) -> dict:
    """Register a new webhook. Returns the created hook dict."""
    root = runtime_root or _runtime_root()
    hook: dict = {
        "id": secrets.token_hex(4),
        "url": url,
        "event_types": list(event_types),
        "tracks": list(tracks),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "enabled": True,
    }
    with _lock:
        hooks = _load(root)
        hooks.append(hook)
        _save(hooks, root)
    return hook


def remove_webhook(hook_id: str, runtime_root: Optional[Path] = None) -> bool:
    """Remove a webhook by id. Returns True if found and removed."""
    root = runtime_root or _runtime_root()
    with _lock:
        hooks = _load(root)
        before = len(hooks)
        hooks = [h for h in hooks if h.get("id") != hook_id]
        if len(hooks) == before:
            return False
        _save(hooks, root)
        return True


# ── Delivery engine ───────────────────────────────────────────────────────────


def _matches(hook: dict, event: dict) -> bool:
    """Return True if this event should be delivered to this hook."""
    if not hook.get("enabled", True):
        return False
    event_types: list[str] = hook.get("event_types") or []
    if event_types and event.get("type") not in event_types:
        return False
    tracks: list[str] = hook.get("tracks") or []
    if tracks and event.get("track") not in tracks:
        return False
    return True


def _deliver_one(hook: dict, event: dict) -> None:
    """Synchronously POST an event to one webhook. Called in thread-pool thread."""
    url = hook.get("url", "")
    if not url:
        return
    body = json.dumps(event, default=str).encode()
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "X-Reflect-Event": str(event.get("type", "")),
            "X-Reflect-Track": str(event.get("track", "")),
            "User-Agent": "reflect-webhook/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            status = resp.getcode()
            if status >= 300:
                print(
                    f"⚠️  webhook {hook.get('id')} → {url} returned HTTP {status}",
                    file=sys.stderr,
                )
    except urllib.error.HTTPError as exc:
        print(
            f"⚠️  webhook {hook.get('id')} → {url} returned HTTP {exc.code}",
            file=sys.stderr,
        )
    except Exception as exc:
        print(
            f"⚠️  webhook {hook.get('id')} delivery failed ({url}): {exc}",
            file=sys.stderr,
        )


def deliver_event(event: dict, runtime_root: Optional[Path] = None) -> None:
    """Fire-and-forget delivery of an event to all matching webhooks.

    Called from events.emit_event() after writing to JSONL.
    Never raises — all errors are logged to stderr only.
    If no webhooks are registered, returns immediately with zero overhead.
    """
    try:
        root = runtime_root or _runtime_root()
        with _lock:
            hooks = _load(root)
        if not hooks:
            return
        for hook in hooks:
            if _matches(hook, event):
                _executor.submit(_deliver_one, hook, dict(event))
    except Exception as exc:
        print(f"⚠️  webhook dispatch error: {exc}", file=sys.stderr)
