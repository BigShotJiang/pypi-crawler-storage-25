"""Python port of bin/reflect-dispatch.

One cron entry, forever. Iterates agent/runtime/tracks/*/ and fires per-track
wakes for tracks that have signal. Tracks run concurrently via background
processes (one uv run per track, delegated to agent.lib.tick).

Signal check and lock acquisition are delegated to agent/lib/tick.py — the
Python module is the single source of truth for "should this track wake?"

Adding a track: mkdir -p agent/runtime/tracks/{name}/inbox/
Decommissioning: mv agent/runtime/tracks/{name} agent/runtime/tracks/.decommissioned/
No crontab change needed for either operation.

Dry-run mode (no wakes fired, signal state printed):
    reflect-dispatch --dry-run

Suggested crontab (replaces bin/reflect-dispatch):
    * * * * * cd /home/user/.acp/projects/reflection && reflect-dispatch >> /tmp/reflect-dispatch.log 2>&1

Requirements: reflect-wake must accept --track <name> and export
REFLECT_TRACK to the Python runtime.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from agent.lib.root import resolve_project_root

PROJECT_ROOT = resolve_project_root()
TRACKS_DIR = PROJECT_ROOT / "agent" / "runtime" / "tracks"
PROJECTS_DIR = PROJECT_ROOT / "agent" / "projects"


def _project_root_for_track(track_dir: Path) -> Path:
    """Compute REFLECT_PROJECT_ROOT for a track directory (DR18.1).

    Returns orchestrator root for global tracks; resolved project root for
    project-nested tracks.

    Uses string-prefix matching on the UNRESOLVED (no symlink traversal)
    absolute path — mirrors the bash _project_root_for_track() exactly.
    A project-nested track path like agent/projects/foo/agent/runtime/tracks/bar
    resolves to the foo project's real root; a global track returns PROJECT_ROOT.
    """
    # Normalize to absolute WITHOUT following symlinks
    if track_dir.is_absolute():
        abs_track_dir = track_dir
    else:
        abs_track_dir = PROJECT_ROOT / track_dir

    if not PROJECTS_DIR.is_dir():
        return PROJECT_ROOT

    # projects_abs: absolute path to agent/projects/ without symlink traversal
    projects_abs = PROJECT_ROOT / "agent" / "projects"

    try:
        rel = abs_track_dir.relative_to(projects_abs)
    except ValueError:
        return PROJECT_ROOT  # not inside projects/ — global track

    # First component of rel is the project name
    proj_name = rel.parts[0]
    proj_link = projects_abs / proj_name
    try:
        return proj_link.resolve()
    except Exception:
        return PROJECT_ROOT


def _check_double_dispatch() -> None:
    """DR21: Refuse if any linked project has a double-dispatch cron entry.

    A linked project should NOT also be running its own scoped cron dispatcher.
    Detected by checking if any linked project's real path appears in the
    current crontab alongside reflect-dispatch.

    Raises SystemExit(1) on violation, printing a remediation message.
    """
    if not PROJECTS_DIR.is_dir():
        return

    try:
        result = subprocess.run(
            ["crontab", "-l"],
            capture_output=True, text=True,
        )
        crontab_lines = result.stdout if result.returncode == 0 else ""
    except Exception:
        crontab_lines = ""

    for proj_link in sorted(PROJECTS_DIR.iterdir()):
        if not proj_link.is_dir():
            continue
        proj_name = proj_link.name
        if proj_name.startswith("."):
            continue
        try:
            real_proj = str(proj_link.resolve())
        except Exception:
            continue
        if not real_proj:
            continue  # dead symlink; skip

        for line in crontab_lines.splitlines():
            if real_proj in line and "reflect-dispatch" in line:
                msg = (
                    "ERROR: dispatch config invalid\n"
                    f"  {proj_name} ({real_proj}) is symlinked at agent/projects/{proj_name}\n"
                    f"  AND has a scoped cron line: {line}\n"
                    "\n"
                    "  Resolve by removing exactly one:\n"
                    f"  (a) remove the symlink:    reflect project unlink {proj_name}\n"
                    f"  (b) remove the cron line:  crontab -e   (delete the {proj_name} dispatch line)\n"
                    "\n"
                    "  Refusing to run. See agent/design/design.multi-project-reflection~f7fd5be0.md DR2.1."
                )
                print(msg, file=sys.stderr, flush=True)
                # Also write to log for cron visibility
                log_path = "/tmp/reflect-dispatch.log"
                try:
                    with open(log_path, "a") as f:
                        f.write(msg + "\n")
                except Exception:
                    pass
                sys.exit(1)


def _dry_run() -> None:
    """Print signal state for all global tracks without firing any wakes.

    Mirrors the bash script's dry-run path: only global tracks are checked.
    Project-nested tracks are not iterated (they are a live-mode-only concern).
    """
    from agent.lib.tick import check_track_signal  # noqa: PLC0415

    if not TRACKS_DIR.is_dir():
        return

    for track_dir in sorted(TRACKS_DIR.iterdir()):
        if not track_dir.is_dir():
            continue
        name = track_dir.name
        if name.startswith("."):
            continue
        if (track_dir / "disabled.flag").exists():
            continue
        if (track_dir / "human.flag").exists():
            continue
        try:
            sig = check_track_signal(name)
            if sig.should_fire:
                print(f"[{name}] would fire: {sig.reason}", flush=True)
            else:
                print(f"[{name}] no signal", flush=True)
        except Exception as exc:
            print(f"[{name}] error checking signal: {exc}", flush=True)


def _fire_tracks(tracks_base: Path) -> list[subprocess.Popen]:
    """Launch background processes for all tracks with signal.

    Returns the list of Popen handles so the caller can wait on them.
    """
    procs: list[subprocess.Popen] = []
    if not tracks_base.is_dir():
        return procs

    for track_dir in sorted(tracks_base.iterdir()):
        if not track_dir.is_dir():
            continue
        name = track_dir.name
        if name.startswith("."):
            continue  # skip hidden / .decommissioned
        if (track_dir / "disabled.flag").exists():
            continue  # track disabled
        if (track_dir / "human.flag").exists():
            continue  # P9: human track — no wake supervisor

        # DR18.1: compute per-track project root
        track_project_root = str(_project_root_for_track(track_dir))

        env = os.environ.copy()
        env["REFLECT_PROJECT_ROOT"] = track_project_root

        log_path = f"/tmp/reflect-tick-{name}.log"
        try:
            log_fh = open(log_path, "a")
        except Exception:
            log_fh = subprocess.DEVNULL  # type: ignore[assignment]

        proc = subprocess.Popen(
            ["uv", "run", "python", "-m", "agent.lib.tick", "fire-if-signal", name],
            env=env,
            stdout=log_fh,
            stderr=log_fh,
        )
        procs.append(proc)

    return procs


def main() -> None:
    """Entry point for reflect-dispatch."""
    # Ensure PATH includes common local bin dirs (mirrors bash script)
    home = os.environ.get("HOME", "")
    existing_path = os.environ.get("PATH", "")
    local_bins = f"{home}/.local/bin:/usr/local/bin"
    if local_bins not in existing_path:
        os.environ["PATH"] = f"{local_bins}:{existing_path}"

    # Change into project root so relative paths work
    os.chdir(PROJECT_ROOT)

    args = sys.argv[1:]
    dry_run = "--dry-run" in args

    # DR21: double-dispatch fail-fast (always, even in dry-run)
    _check_double_dispatch()

    if dry_run:
        _dry_run()
        return

    # Live mode: fire background processes for all tracks with signal,
    # then wait for them all to complete.
    procs: list[subprocess.Popen] = []

    # Global tracks (orchestrator-owned)
    procs.extend(_fire_tracks(TRACKS_DIR))

    # Project-nested tracks (per linked project, DR7)
    if PROJECTS_DIR.is_dir():
        for proj_link in sorted(PROJECTS_DIR.iterdir()):
            if not proj_link.is_dir():
                continue
            if proj_link.name.startswith("."):
                continue
            proj_tracks = proj_link / "agent" / "runtime" / "tracks"
            if not proj_tracks.is_dir():
                continue
            procs.extend(_fire_tracks(proj_tracks))

    # wait for all background processes (mirrors bash's `wait`)
    for proc in procs:
        try:
            proc.wait()
        except Exception:
            pass


if __name__ == "__main__":
    main()
