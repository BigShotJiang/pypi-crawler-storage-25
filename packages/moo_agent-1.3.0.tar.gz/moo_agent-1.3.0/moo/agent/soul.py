"""
Soul loading — SOUL.md (immutable) + SOUL.patch.md (append-only). See
``docs/source/explanation/agent-internals.md`` (The Soul System).
"""

import re
from dataclasses import dataclass, field
from pathlib import Path

import mistune


@dataclass
class Rule:
    pattern: str
    command: str


@dataclass
class VerbMapping:
    intent: str
    template: str


@dataclass
class Soul:
    name: str = ""
    mission: str = ""
    persona: str = ""
    context: str = ""
    addendum: str = ""
    rules: list[Rule] = field(default_factory=list)
    verb_mappings: list[VerbMapping] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)


# Matches both ASCII arrow (->) and unicode arrow (→)
_ARROW_RE = re.compile(r"\s*[-–]>\s*|→")

_SECTION_RULES = "rules of engagement"
_SECTION_VERBS = "verb mapping"
_SECTION_TOOLS = "tools"
_SECTION_CONTEXT = "context"
_SECTION_ADDENDUM = "response format"


def _extract_text(node) -> str:
    """Recursively extract plain text from a mistune AST node or list of nodes."""
    if isinstance(node, str):
        return node
    if isinstance(node, list):
        return "".join(_extract_text(c) for c in node)
    if isinstance(node, dict):
        node_type = node.get("type", "")
        if node_type == "softbreak":
            return " "
        if node_type == "codespan":
            return node.get("raw", "")
        raw = node.get("raw", "")
        if raw:
            return raw
        children = node.get("children", [])
        return _extract_text(children)
    return ""


def _resolve_links(node, base_path: Path) -> str:
    """
    Extract text and inline any markdown links that resolve to existing
    ``.md`` / ``.txt`` files. Other links fall back to display text.
    """
    if isinstance(node, str):
        return node
    if isinstance(node, list):
        return "".join(_resolve_links(c, base_path) for c in node)
    if isinstance(node, dict):
        node_type = node.get("type", "")
        if node_type == "link":
            url = node.get("attrs", {}).get("url", "")
            link_path = (base_path / url).resolve()
            if link_path.exists() and link_path.suffix in (".md", ".txt"):
                return link_path.read_text(encoding="utf-8")
            # Fallback: include the link's display text
            return _extract_text(node.get("children", []))
        if node_type == "codespan":
            return node.get("raw", "")
        raw = node.get("raw", "")
        if raw:
            return raw
        children = node.get("children", [])
        return _resolve_links(children, base_path)
    return ""


def _parse_md_file(path: Path) -> Soul:
    """Parse a single SOUL.md-format file into a Soul dataclass."""
    soul = Soul()
    text = path.read_text(encoding="utf-8")
    md = mistune.create_markdown(renderer="ast")
    tokens = md(text)

    current_h1 = None
    current_h2 = None
    body_lines: list[str] = []
    context_parts: list[str] = []

    def flush(h1, h2, lines):
        content = "\n".join(lines).strip()
        if not content:
            return
        if h1 == "name":
            soul.name = content
        elif h1 == "mission":
            soul.mission = content
        elif h1 == "persona":
            if h2 is None:
                soul.persona = content
            elif h2 == _SECTION_ADDENDUM:
                soul.addendum = content
            elif h2 not in (_SECTION_RULES, _SECTION_VERBS, _SECTION_CONTEXT):
                # Unknown subsection — fold into context.
                context_parts.append(f"## {h2.title()}\n\n{content}")
        elif (
            h1 is None
            and h2 is not None
            and h2 not in (_SECTION_RULES, _SECTION_VERBS, _SECTION_CONTEXT, _SECTION_ADDENDUM)
        ):
            # Top-level H2 with no H1 parent (e.g. patch ## Lessons Learned).
            context_parts.append(f"## {h2.title()}\n\n{content}")

    for token in tokens:
        if not isinstance(token, dict):
            continue
        tok_type = token.get("type", "")

        if tok_type == "heading":
            flush(current_h1, current_h2, body_lines)
            body_lines = []
            level = token.get("attrs", {}).get("level", 1)
            heading_text = _extract_text(token.get("children", [])).strip().lower()
            if level == 1:
                current_h1 = heading_text
                current_h2 = None
            elif level == 2:
                current_h2 = heading_text

        elif current_h2 == _SECTION_CONTEXT and tok_type in ("list", "paragraph", "block_text"):
            for child in token.get("children", []):
                resolved = _resolve_links(child, path.parent)
                if resolved.strip():
                    context_parts.append(resolved.strip())

        elif current_h2 == _SECTION_CONTEXT and tok_type == "block_code":
            code = token.get("raw", "").strip()
            if code:
                context_parts.append(f"```\n{code}\n```")

        elif tok_type == "list":
            section = current_h2 or current_h1 or ""
            for item in token.get("children", []):
                raw = _extract_text(item.get("children", [])).strip()
                raw = raw.strip("`")
                parts = _ARROW_RE.split(raw, maxsplit=1)
                if section == _SECTION_TOOLS:
                    # Plain list of tool names, no arrow required.
                    name = raw.strip().strip("`")
                    if name:
                        soul.tools.append(name)
                elif len(parts) == 2:
                    left, right = parts[0].strip(), parts[1].strip()
                    if section == _SECTION_RULES:
                        soul.rules.append(Rule(pattern=left, command=right))
                    elif section == _SECTION_VERBS:
                        soul.verb_mappings.append(VerbMapping(intent=left, template=right))
                    else:
                        body_lines.append(f"- {raw}")
                else:
                    body_lines.append(f"- {raw}")

        elif tok_type == "paragraph":
            body_lines.append(_extract_text(token.get("children", [])).strip())

        elif tok_type == "block_text":
            body_lines.append(_extract_text(token.get("children", [])).strip())

        elif tok_type == "block_code":
            code = token.get("raw", "").strip()
            if code:
                body_lines.append(f"```\n{code}\n```")

    flush(current_h1, current_h2, body_lines)

    if context_parts:
        soul.context = "\n\n".join(context_parts)

    return soul


def parse_soul(config_dir: Path) -> Soul:
    """
    Load and merge SOUL.md, SOUL.patch.md, and (if present)
    ``../baseline.md``. Base rules are checked first at runtime, so SOUL.md
    entries take precedence over patch entries.
    """
    base = _parse_md_file(config_dir / "SOUL.md")

    baseline_path = config_dir.parent / "baseline.md"
    if baseline_path.exists():
        baseline_soul = _parse_md_file(baseline_path)
        baseline_text = baseline_path.read_text(encoding="utf-8")
        if base.context:
            base.context = baseline_text + "\n\n" + base.context
        else:
            base.context = baseline_text
        # Agent-specific entries first → first match wins at runtime.
        base.rules = base.rules + baseline_soul.rules
        base.verb_mappings = base.verb_mappings + baseline_soul.verb_mappings

    patch_path = config_dir / "SOUL.patch.md"
    if patch_path.exists() and patch_path.stat().st_size > 0:
        patch = _parse_md_file(patch_path)
        base.rules.extend(patch.rules)
        base.verb_mappings.extend(patch.verb_mappings)
        for t in patch.tools:
            if t not in base.tools:
                base.tools.append(t)
        if patch.context:
            base.context = (base.context + "\n\n" + patch.context).strip() if base.context else patch.context

    return base


def compile_rules(soul: Soul) -> list[tuple[re.Pattern, str]]:
    """Pre-compile rule patterns for O(1) matching at runtime."""
    return [(re.compile(r.pattern), r.command) for r in soul.rules]


def append_patch(config_dir: Path, entry_type: str, pattern_or_intent: str, command: str) -> None:
    """
    Append a "rule", "verb", or "note" entry to SOUL.patch.md, deduping
    identical entries and creating the section header on first use.
    """
    patch_path = config_dir / "SOUL.patch.md"

    if entry_type == "note":
        new_line = f"- {pattern_or_intent}"
        section_header = "## Lessons Learned"
    else:
        new_line = f"- {pattern_or_intent} -> {command}"
        section_header = "## Rules of Engagement" if entry_type == "rule" else "## Verb Mapping"

    existing = patch_path.read_text(encoding="utf-8") if patch_path.exists() else ""

    if new_line in existing:
        return

    lines_to_append: list[str] = []
    if section_header not in existing:
        if existing and not existing.endswith("\n"):
            lines_to_append.append("\n")
        lines_to_append.append(f"\n{section_header}\n")

    lines_to_append.append(f"{new_line}\n")

    with open(patch_path, "a", encoding="utf-8") as f:
        f.write("".join(lines_to_append))


def append_patch_directive(config_dir: Path, entry_type: str, directive: str) -> bool:
    """
    Parse a raw LLM ``SOUL_PATCH_*`` directive and append it. Notes are
    free text; rules/verbs use ``<pattern> -> <command>``. Returns False
    when the directive is malformed.
    """
    if entry_type == "note":
        note = directive.strip()
        if not note:
            return False
        append_patch(config_dir, "note", note, "")
        return True

    parts = _ARROW_RE.split(directive, maxsplit=1)
    if len(parts) != 2:
        return False
    pattern_or_intent, command = parts[0].strip(), parts[1].strip()
    if not pattern_or_intent or not command:
        return False
    append_patch(config_dir, entry_type, pattern_or_intent, command)
    return True
