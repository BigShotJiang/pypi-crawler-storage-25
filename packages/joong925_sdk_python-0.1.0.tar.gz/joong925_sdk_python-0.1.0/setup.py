from setuptools import setup, find_packages

setup(
    name="joong925-sdk-python",
    version="0.1.0",
    author="cjo",
    author_email="cjo@tesollo.com",
    description="Python SDK for Gripper",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "opencv-python"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.11',
)
