import socket
import struct
import time
from .constants import *

class DeltoController:
    def __init__(self, ip="192.168.1.119", port=502):
        self.ip = ip
        self.port = port
        self.client = None
        self.fingers = 5

    def connect(self):
        try:
            self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client.settimeout(2.0)
            self.client.connect((self.ip, self.port))
            print(f"Connection success: {self.ip}")
            return True
        except Exception as e:
            print(f"Connection failed: {e}")
            return False
        
    def disconnect(self):
        if self.client:
            self.client.close()
            print("Disconnected.")

    def _send_packet(self, cmd, data_bytes=None, expect_response=True):
        if data_bytes is None:
            data_bytes = b''
        
        packet_len = 2 + 1 + len(data_bytes)
        header = struct.pack('!HB', packet_len, cmd)
        packet = header + data_bytes
        
        try:
            self.client.send(packet)
            if expect_response:
                response = self.client.recv(1024)
                return response
            return None 
            
        except Exception as e:
            print(f"Communication error: {e}")
            return None
        
    def set_duty(self, duty_dict):
        data_bytes = b""
        for joint_id, duty_val in duty_dict.items():
            raw_duty = (duty_val / 450.0) * 1000.0
            
            target_duty = int(raw_duty)
            target_duty = max(-1000, min(1000, target_duty))
            
            data_bytes += struct.pack('!Bh', joint_id, target_duty)
            
        self._send_packet(CMD_SET_DUTY, data_bytes, expect_response=False)

    def get_data(self, data_types):
        response = self._send_packet(CMD_GET_DATA, bytes(data_types))
        if response:
            return self.parse_response(response, data_types)
        return None

    def parse_response(self, data, requested_types):
        if len(data) < 3: return None
        
        total_len = struct.unpack('!H', data[0:2])[0]
        cmd = data[2]
        
        packet = data[:total_len]

        results = {"joints": {}, "sensors": [None] * self.fingers, "gpio": None}
        
        end_offset = total_len
        
        if TYPE_GPIO in requested_types:
            end_offset -= 4
            results["gpio"] = packet[end_offset:end_offset+4].hex()
            
        if TYPE_TACTILE_SENSOR in requested_types:
            tactile_size = 15 * self.fingers
            end_offset -= tactile_size
            
            tactile_data = packet[end_offset:end_offset+tactile_size]
            
            for i in range(self.fingers):
                finger_bytes = tactile_data[i*15 : (i+1)*15]
                finger_values = list(finger_bytes)
                results["sensors"][i] = finger_values

        joint_types = [t for t in requested_types if t in (TYPE_POSITION, TYPE_CURRENT, TYPE_TEMPERATURE, TYPE_VELOCITY)]
        
        offset = 3
        if joint_types:
            while offset < end_offset:
                joint_id = packet[offset]
                offset += 1
                joint_info = {}

                for t in joint_types:
                    if t == TYPE_POSITION:
                        val = struct.unpack('!h', packet[offset:offset+2])[0]
                        joint_info['position'] = val * 0.1
                        offset += 2
                    elif t == TYPE_CURRENT:
                        val = struct.unpack('!h', packet[offset:offset+2])[0]
                        joint_info['current'] = val
                        offset += 2
                    elif t == TYPE_TEMPERATURE:
                        val = struct.unpack('!h', packet[offset:offset+2])[0]
                        joint_info['temperature'] = val * 0.1
                        offset += 2
                    elif t == TYPE_VELOCITY:
                        raw_val = packet[offset]
                        val = raw_val if raw_val < 128 else raw_val - 256
                        joint_info['velocity'] = val * 6.0 
                        offset += 1
                results["joints"][joint_id] = joint_info

        return results