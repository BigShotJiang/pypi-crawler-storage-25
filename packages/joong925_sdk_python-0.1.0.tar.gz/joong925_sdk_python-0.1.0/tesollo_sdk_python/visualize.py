import cv2
import numpy as np

def init_window(window_name="Tesollo Tactile Sensor Viewer"):
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 1200, 600)
    return window_name

def render_tactile_data(window_name, tactile_data_list):
    num_fingers = 5
    nrows, ncols = 5, 3
    
    resolution = 30  
    padding = 50

    img_h = (nrows * resolution) + (padding * 2)
    img_w = (num_fingers * ncols * resolution) + ((num_fingers - 1) * padding) + (padding * 2)
    
    vis_img = np.zeros((img_h, img_w, 3), dtype=np.uint8)

    for f_idx in range(num_fingers):
        finger_data = tactile_data_list[f_idx]
        
        start_x = padding + f_idx * (ncols * resolution + padding)
        start_y = padding

        cv2.putText(vis_img, f"Finger {f_idx + 1}", (start_x, start_y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 0)

        for r in range(nrows):
            for c in range(ncols):
                idx = r * ncols + c
                val = finger_data[idx]
                
                intensity = np.clip(val / 255.0, 0, 1)
                
                color_r = int(intensity * 255)
                color_g = int((1 - intensity) * 255)
                color_b = 0 
                
                center_x = start_x + (c * resolution) + (resolution // 2)
                center_y = start_y + (r * resolution) + (resolution // 2)
                
                cv2.circle(vis_img, (center_x, center_y), radius=(resolution // 2) - 3,  color=(color_b, color_g, color_r),  thickness=-1)

                text = str(val)
                font = cv2.FONT_HERSHEY_SIMPLEX
                font_scale = 0.3
                thickness = 0
                
                text_size, _ = cv2.getTextSize(text, font, font_scale, thickness)
                text_x = center_x - (text_size[0] // 2)
                text_y = center_y + (text_size[1] // 2)
                
                cv2.putText(vis_img, text, (text_x, text_y), font, font_scale, (255, 255, 255), thickness)

    cv2.imshow(window_name, vis_img)
