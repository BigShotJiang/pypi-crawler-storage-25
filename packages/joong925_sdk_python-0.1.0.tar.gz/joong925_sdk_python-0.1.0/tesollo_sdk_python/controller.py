import socket
import struct
import time
from .constants import *

class PDControllerCfg:
    def __init__(self, kp, kd, output_limit):
        self.kp = kp
        self.kd = kd
        self.output_limit = output_limit
        self.prev_error = {}

    def update(self, current_positions, target_positions, dt, duty_limits=None):
        if dt <= 0.0: dt = 1e-5 
        if duty_limits is None: duty_limits = {}

        duties = {}
        for joint_id, target_pos in target_positions.items():
            if joint_id not in current_positions:
                continue
                
            current_pos = current_positions[joint_id]
            error = target_pos - current_pos

            if joint_id not in self.prev_error:
                self.prev_error[joint_id] = 0.0

            p_term = self.kp * error
            d_error = (error - self.prev_error[joint_id]) / dt
            d_term = self.kd * d_error

            output = p_term + d_term

            joint_duty_limit = duty_limits.get(joint_id, self.output_limit)

            if output > joint_duty_limit:
                output = joint_duty_limit
            elif output < -joint_duty_limit:
                output = -joint_duty_limit

            duties[joint_id] = output
            self.prev_error[joint_id] = error
        
        return duties
    
class PDController:
    def __init__(self, kp=20.0, kd=0.5, output_limit=450):
        self.pd_controller = PDControllerCfg(kp, kd, output_limit)
        
        self.final_targets = {i: 0.0 for i in range(1, 21)}
        self.current_setpoints = {i: 0.0 for i in range(1, 21)}
        self.desired_speeds = {i: 450 for i in range(1, 21)}
        self.is_initialized = False

    def set_positions(self, targets, speeds=None):
        for jid, pos in targets.items():
            if 1 <= jid <= 20:
                self.final_targets[jid] = pos
        
        if speeds is not None:
            if isinstance(speeds, dict):
                for jid, speed in speeds.items():
                    if 1 <= jid <= 20: self.desired_speeds[jid] = speed
            else:
                for jid in targets.keys():
                    self.desired_speeds[jid] = float(speeds)

    def update(self, current_positions, dt):
        if not self.is_initialized and current_positions:
            for jid, pos in current_positions.items():
                self.current_setpoints[jid] = pos
            self.is_initialized = True

        for jid in range(1, 21):
            goal = self.final_targets[jid]
            curr_set = self.current_setpoints[jid]
            speed = self.desired_speeds[jid]
            
            max_step = speed * dt
            
            if curr_set < goal:
                self.current_setpoints[jid] = min(curr_set + max_step, goal)
            elif curr_set > goal:
                self.current_setpoints[jid] = max(curr_set - max_step, goal)

        return self.pd_controller.update(current_positions, self.current_setpoints, dt)