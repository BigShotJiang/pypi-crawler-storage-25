from fasr_vad_marblenet.marblenet import MarbleNetForVAD

__all__ = ["MarbleNetForVAD"]
