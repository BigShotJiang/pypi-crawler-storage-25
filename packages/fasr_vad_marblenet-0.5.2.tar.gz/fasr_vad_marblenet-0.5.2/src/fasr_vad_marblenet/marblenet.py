from __future__ import annotations

from pathlib import Path
from typing import List

from loguru import logger
import numpy as np
import onnxruntime as ort
from pydantic import Field, model_validator
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioSpan, AudioSpanList, Waveform
from fasr.model import VADModel


def _get_input_waveform(audio: AudioSpan) -> Waveform:
    if audio.waveform is None:
        raise ValueError("VAD input audio must carry `waveform`.")
    return audio.waveform


def _bind_segment_to_input(audio: AudioSpan, segment: AudioSpan) -> AudioSpan:
    if segment.start_ms is None or segment.end_ms is None:
        raise ValueError("Detected segment must carry both `start_ms` and `end_ms`.")
    relative_start_ms = int(round(segment.start_ms))
    relative_end_ms = int(round(segment.end_ms))
    cloned = segment.model_copy(deep=True)
    offset_ms = int(round(audio.start_ms or 0))
    cloned.start_ms = offset_ms + relative_start_ms
    cloned.end_ms = offset_ms + relative_end_ms
    cloned.waveform = _get_input_waveform(audio).select_by_ms(
        relative_start_ms,
        relative_end_ms,
    )
    return cloned


# Default checkpoint directory: the plugin-bundled model.onnx path.
DEFAULT_CHECKPOINT_DIR = Path(__file__).parent / "asset" / "marblenet"

# ---- Model-architecture constants (dictated by the MarbleNet ONNX weights; not user-configurable) ----
# Fixed input sample rate the model was trained/exported with; non-16kHz input will be resampled.
SAMPLE_RATE: int = 16000
# Number of input samples covered by each output frame; at 16kHz this equals 20ms/frame.
# Derived from the stride=4 x mel hop_length=160 front-end; changing it breaks timestamp math.
OUTPUT_FRAME_LENGTH: int = 320
# Maximum input duration (seconds) allowed per inference call; prevents OOM on extremely long audio.
# Audio longer than this is processed via sliding windows of `input_audio_length` without dropping data.
MAX_INPUT_SECONDS: int = 3600


class MarbleNetForVAD(VADModel):
    """Non-streaming VAD based on NVIDIA MarbleNet, driven by ONNX Runtime.

    MarbleNet [Jia et al., 2021] is NVIDIA's lightweight 1D depthwise-separable CNN for
    voice activity detection; with < 90k parameters it runs well above real time on CPU.
    This class wraps ONNX weight loading, input preprocessing, sliding-window inference,
    the dual-threshold state machine, and post-processing into a standard `AudioSpanList`.

    Registry name:
        ``marblenet`` -- registered via `registry.vad_models`. Consumers can obtain an
        instance through `VADModel.from_config(...)` or
        ``registry.vad_models.get("marblenet")()``.

    Core data flow (`detect`):
        +------------+   resample   +-----------+  int16-norm  +----------+
        | Waveform(*)| -----------> | 16 kHz PCM| -----------> | (1,1,N)  |
        +------------+              +-----------+              +----+-----+
                                                                    | pad / window
                                                                    v
                                              +-----------------------------------+
                                              | ONNX sliding-window inference     |
                                              |  -> (silence_score, active_score) |
                                              +------------------+----------------+
                                                                 | dual-threshold FSM
                                                                 v
                                                       frame-level silence/speak sequence
                                                                 | frame -> time
                                                                 v
                                                      list of (start_s, end_s)
                                                                 | filter + 2x merge
                                                                 v
                                                           AudioSpanList

    Key design choices:
        * **Dual-threshold hysteresis**: `speaking_score` and `silence_score` act as the
          rising-edge and falling-edge thresholds of the state machine, avoiding chatter
          near the confidence boundary. They can be tuned independently; equal values
          (both 0.5 by default) are equivalent to a single threshold.
        * **Non-overlapping sliding window**: when the audio exceeds the ONNX input
          length, the input is cut into windows of size `input_audio_length` with that
          same stride; the tail is padded with Gaussian noise whose RMS matches the
          source audio, keeping the statistical distribution close to the original signal
          and reducing boundary-frame errors.
        * **RMS-matched noise padding**: short audio is also padded with RMS-matched
          Gaussian noise instead of zeros, avoiding the DC step that would trigger
          spurious responses in the convolutional front-end.
        * **Frame-duration constant**: each frame spans
          `OUTPUT_FRAME_LENGTH / SAMPLE_RATE = 20ms`, and timestamps are derived as
          `frame_index * 20ms`.

    Architecture constants (module-level, not exposed as fields):
        * ``SAMPLE_RATE = 16000``            -- fixed input sample rate
        * ``OUTPUT_FRAME_LENGTH = 320``      -- 20ms per frame
        * ``MAX_INPUT_SECONDS = 3600``       -- per-call cap for dynamic-shape models

    Tunable fields (see each Field's description):
        * Download config : ``checkpoint``, ``endpoint``
        * VAD thresholds  : ``speaking_score``, ``silence_score``
        * Post-processing : ``fusion_threshold``, ``min_speech_duration``
        * ORT threading   : ``intra_op_num_threads``, ``inter_op_num_threads``

    Runtime state (populated by `load_checkpoint()`, marked `exclude=True` so it is
    skipped by `model_dump`):
        ``session``, ``input_name``, ``output_names``.

    Lifecycle:
        At instantiation, `validate_model` automatically calls
        `load_checkpoint(DEFAULT_CHECKPOINT_DIR)` to load the plugin-bundled weights.
        To use different weights, call `load_checkpoint` again post-construction, or
        set `checkpoint="<repo_id>"` at construction and then invoke
        `load_checkpoint()` explicitly (the constructor does not auto-download based on
        `checkpoint`).

    Thread safety:
        `ort.InferenceSession` is itself thread-safe, and the FSM's intermediate state is
        local to `detect`, so a single instance can call `detect` concurrently from
        multiple threads. However, mutating Field values (e.g. thresholds) is not atomic,
        so do not hot-reload parameters at runtime.

    Typical usage:
        >>> from fasr_vad_marblenet.marblenet import MarbleNetForVAD
        >>> from fasr.data import Waveform
        >>> vad = MarbleNetForVAD(speaking_score=0.6, silence_score=0.4)
        >>> from fasr.data import AudioSpan
        >>> spans = vad.detect(
        ...     AudioSpan(waveform=Waveform.from_file("audio.wav"), start_ms=0)
        ... )
        >>> for s in spans:
        ...     print(s.start_ms, s.end_ms)

    Reference:
        Jia, F., Majumdar, S., Ginsburg, B. "MarbleNet: Deep 1D Time-Channel Separable
        Convolutional Neural Network for Voice Activity Detection." ICASSP 2021.
    """

    # ==== Model download config ====
    checkpoint: str | None = Field(
        default=None,
        description="Remote model identifier (ModelScope/HuggingFace repo_id); when None, uses the plugin-bundled asset/marblenet model.",
    )
    endpoint: str = Field(
        default="modelscope",
        description="Download backend, one of 'modelscope' or 'huggingface'. Only used when checkpoint is non-empty.",
    )

    # ==== Dual-threshold VAD state-machine params (tunable) ====
    speaking_score: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Silence->speaking trigger threshold: while in silence, switch to speaking when the ONNX active_score >= this value. Higher=more conservative, may miss low-volume speech; lower=more sensitive, may classify noise as speech.",
    )
    silence_score: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Speaking->silence trigger threshold: while speaking, switch to silence when the ONNX silence_score >= this value. Higher=longer speech segments (trailing tail); lower=shorter speech segments (may truncate).",
    )

    # ==== Post-processing params (tunable) ====
    fusion_threshold: float = Field(
        default=0.1,
        ge=0.0,
        description="Merge-gap between adjacent speech segments (seconds): if segment_i+1.start - segment_i.end <= this value, the two are merged. Used to eliminate fragments caused by short within-sentence pauses.",
    )
    min_speech_duration: float = Field(
        default=0.05,
        ge=0.0,
        description="Minimum speech-segment duration (seconds): before merging, segments shorter than this are discarded. Used to suppress false triggers from clicks/coughs and similar transients.",
    )
    max_speech_duration: float | None = Field(
        default=None,
        gt=0.0,
        description="Maximum speech-segment duration (seconds): after filtering and merging, any segment longer than this limit is hard-split into contiguous sub-segments. None disables the limit.",
    )

    # ==== ONNX Runtime threading (tunable, performance-related) ====
    intra_op_num_threads: int = Field(
        default=2,
        ge=0,
        description="Intra-op parallelism (SIMD/threads within a single operator); 0 lets ORT decide automatically.",
    )
    inter_op_num_threads: int = Field(
        default=0,
        ge=0,
        description="Inter-op parallelism (running independent operators in parallel); 0 lets ORT decide automatically. Only effective when execution_mode=PARALLEL.",
    )

    # ==== Runtime state (populated by load_checkpoint, excluded from serialization) ====
    session: ort.InferenceSession | None = Field(
        default=None,
        exclude=True,
        description="ONNX Runtime inference session; created by load_checkpoint(). detect() raises if this is not initialized.",
    )
    input_name: str | None = Field(
        default=None,
        exclude=True,
        description="Name of the first ONNX input tensor, used as the key in the feed_dict of session.run.",
    )
    output_names: List[str] | None = Field(
        default=None,
        exclude=True,
        description="Names of the ONNX output tensors. For MarbleNet, the first three outputs are silence_score / active_score / signal_len (in order).",
    )

    def detect(self, audio: AudioSpan) -> AudioSpanList:
        """Run voice activity detection on the given audio and return detected speech spans.

        Pipeline:
            1. Check that the model is initialized (session must be created).
            2. Resample to 16kHz (if the source sample rate differs).
            3. Normalize audio to int16 range (-32767 ~ 32767).
            4. Align audio length (pad or window-cut to fit the model input).
            5. Sliding-window ONNX inference to obtain a per-frame silence sequence.
            6. Convert the state sequence into speech-segment timestamps.
            7. Post-process: filter short segments, merge adjacent ones.
            8. Build and return an AudioSpanList.

        Args:
            audio: Input audio span carrying waveform and optional absolute offset.

        Returns:
            AudioSpanList: detected speech segments; each span carries start_ms/end_ms.
        """
        if (
            self.session is None
            or self.input_name is None
            or len(self.output_names) < 3
        ):
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )

        waveform = _get_input_waveform(audio)

        # Step 1: resample to the model's required 16kHz.
        wav = (
            waveform.resample(SAMPLE_RATE)
            if waveform.sample_rate != SAMPLE_RATE
            else waveform
        )

        # Step 2: normalize to int16 range (the input format MarbleNet expects).
        audio_data = self._normalize_to_int16(wav.data)
        audio_len = int(audio_data.shape[0])

        # Empty audio -> empty result.
        if audio_len == 0:
            return AudioSpanList()

        # Reshape into a 3D tensor: (batch=1, channel=1, samples).
        audio_3d = audio_data.reshape(1, 1, -1)

        # Step 3: resolve the required input length and align the audio to it.
        input_audio_length = self._resolve_input_audio_length(audio_len)
        aligned_audio = self._align_audio_length(audio_3d, input_audio_length)

        # Step 4: run sliding-window inference to obtain the per-frame silence sequence.
        saved = self._infer_silence_states(aligned_audio, input_audio_length)

        # Step 5: convert the state sequence into timestamps.
        timestamps = self._vad_to_timestamps(saved)

        # Step 6: post-process (filter, merge).
        timestamps = self._process_timestamps(timestamps)

        # Step 7: build the AudioSpanList.
        segments = AudioSpanList()
        for start_s, end_s in timestamps:
            start_ms = int(round(start_s * 1000))
            end_ms = int(round(end_s * 1000))

            # Skip invalid spans (end not after start).
            if end_ms <= start_ms:
                continue

            segment = AudioSpan(start_ms=start_ms, end_ms=end_ms)
            segments.append(_bind_segment_to_input(audio, segment))

        return segments

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> None:
        """Load the ONNX model from a checkpoint and initialize the inference session.

        Resolution order for the ONNX weight file:
            1. ``checkpoint_dir`` argument (directory or direct ``.onnx`` file path).
            2. ``self.checkpoint`` (repo_id) -> ``self.download_checkpoint()``.
            3. The plugin-bundled ``DEFAULT_CHECKPOINT_DIR``.

        Threading (`intra_op_num_threads` / `inter_op_num_threads`) and the execution
        providers are taken from the instance fields / runtime environment; mutate those
        fields before calling this method if you need to override them.

        Args:
            checkpoint_dir: Model directory containing an ``.onnx`` file, or a direct
                path to an ``.onnx`` file. When ``None``, falls back to
                ``self.checkpoint`` (auto-download) or ``DEFAULT_CHECKPOINT_DIR``.

        Returns:
            Self: the instance itself, enabling method chaining.

        Raises:
            FileNotFoundError: ONNX model file not found.
            RuntimeError: ONNX model outputs do not match the expected layout.
        """
        checkpoint_dir = DEFAULT_CHECKPOINT_DIR
        onnx_path = checkpoint_dir / "model.onnx"
        sess_opts = ort.SessionOptions()
        sess_opts.inter_op_num_threads = max(0, int(self.inter_op_num_threads))
        sess_opts.intra_op_num_threads = max(0, int(self.intra_op_num_threads))
        sess_opts.enable_cpu_mem_arena = True
        sess_opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL

        available_providers = ort.get_available_providers()
        if "CUDAExecutionProvider" in available_providers:
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        else:
            providers = ["CPUExecutionProvider"]
        logger.info(f"Using providers: {providers}")

        session = ort.InferenceSession(
            str(onnx_path),
            sess_options=sess_opts,
            providers=providers,
        )
        self.session = session

        self.input_name = session.get_inputs()[0].name
        self.output_names = [output.name for output in session.get_outputs()]

        # MarbleNet must expose at least 3 outputs:
        # [0]: silence_score, [1]: active_score, [2]: signal_len
        if len(self.output_names) < 3:
            raise RuntimeError(
                "MarbleNet ONNX outputs are invalid, expected >=3 outputs "
                "(score_silence, score_active, signal_len)."
            )

    def get_config(self) -> Config:
        data = {
            "vad_model": {
                "@vad_models": "marblenet",
                "speaking_score": self.speaking_score,
                "silence_score": self.silence_score,
                "fusion_threshold": self.fusion_threshold,
                "min_speech_duration": self.min_speech_duration,
                "max_speech_duration": self.max_speech_duration,
                "intra_op_num_threads": self.intra_op_num_threads,
                "inter_op_num_threads": self.inter_op_num_threads,
            }
        }
        return Config(data=data)

    def _normalize_to_int16(self, audio: np.ndarray) -> np.ndarray:
        """Normalize audio data to the int16 range (-32767 ~ 32767).

        MarbleNet expects int16-formatted audio. This method scales by the peak absolute
        value so the audio spans the full int16 dynamic range, avoiding an overly weak
        signal.

        Args:
            audio: Raw audio samples with arbitrary numeric range.

        Returns:
            np.ndarray: int16 audio samples.
        """
        arr = np.asarray(audio, dtype=np.float32).reshape(-1)
        # Peak absolute value used as the scaling reference.
        max_val = float(np.max(np.abs(arr))) if arr.size > 0 else 0.0
        # Scale factor mapping the peak value to 32767.
        scale = 32767.0 / max_val if max_val > 0 else 1.0
        return (arr * scale).astype(np.int16)

    def _resolve_input_audio_length(self, raw_audio_len: int) -> int:
        """Resolve the input audio length the model requires.

        Reads the shape of the ONNX input tensor. If the model accepts dynamic input
        (shape is a string or None), the length is capped by `MAX_INPUT_SECONDS` or by
        the raw audio length, whichever is smaller.

        Args:
            raw_audio_len: Number of samples in the raw audio.

        Returns:
            int: required input length in samples.
        """
        # Shape info of the first input tensor.
        shape_value = self.session.get_inputs()[0].shape[-1]

        # Dynamic shape (string or None) -> use the configured cap.
        if isinstance(shape_value, str) or shape_value is None:
            return min(SAMPLE_RATE * MAX_INPUT_SECONDS, raw_audio_len)

        return int(shape_value)

    def _align_audio_length(
        self,
        audio_3d: np.ndarray,
        input_audio_length: int,
    ) -> np.ndarray:
        """Adjust the audio length to match the model input requirements.

        Strategy:
            - Exact match: return as-is.
            - Long audio: split by sliding window, pad the tail with RMS-matched noise.
            - Short audio: pad with RMS-matched noise up to the minimum length.

        RMS-matched noise preserves the statistical properties of the audio and avoids
        injecting anomalous signals via padding.

        Args:
            audio_3d: 3D audio tensor (batch=1, channel=1, samples).
            input_audio_length: Length required by the model.

        Returns:
            np.ndarray: length-adjusted audio tensor.
        """
        audio_len = audio_3d.shape[-1]

        # Case 1: lengths already match.
        if audio_len == input_audio_length:
            return audio_3d

        # Case 2: audio is longer than the model input (sliding-window cut).
        if audio_len > input_audio_length:
            # Number of windows required.
            # e.g. audio_len=1000, input=400 -> num_windows=3 (400, 400, 400).
            num_windows = (
                int(np.ceil((audio_len - input_audio_length) / input_audio_length)) + 1
            )
            # Total length after padding.
            total_length = (num_windows - 1) * input_audio_length + input_audio_length
            pad_amount = total_length - audio_len

            # Generate noise whose statistics match the tail RMS of the audio.
            tail = audio_3d[:, :, -pad_amount:].astype(np.float32)
            rms = float(np.sqrt(np.mean(tail * tail)))
            noise = (rms * np.random.normal(0.0, 1.0, size=(1, 1, pad_amount))).astype(
                audio_3d.dtype
            )
            return np.concatenate((audio_3d, noise), axis=-1)

        # Case 3: audio is shorter than required (pad).
        arr = audio_3d.astype(np.float32)
        # Whole-signal RMS.
        rms = float(np.sqrt(np.mean(arr * arr)))
        pad_amount = input_audio_length - audio_len

        # Pad with RMS-matched noise.
        noise = (rms * np.random.normal(0.0, 1.0, size=(1, 1, pad_amount))).astype(
            audio_3d.dtype
        )
        return np.concatenate((audio_3d, noise), axis=-1)

    def _infer_silence_states(
        self,
        aligned_audio: np.ndarray,
        input_audio_length: int,
    ) -> list[bool]:
        """Run sliding-window ONNX inference and return the per-frame silence states.

        The dual-threshold state machine decides speech boundaries:
            - While in silence: switch to speaking if active_score >= speaking_score.
            - While speaking: switch to silence if silence_score >= self.silence_score.

        This hysteresis design avoids frequent state flipping near the confidence
        boundary.

        Args:
            aligned_audio: Length-aligned 3D audio tensor.
            input_audio_length: Length of each window.

        Returns:
            list[bool]: per-frame silence states, True=silence, False=speaking.
        """
        # Initial state: silence.
        silence = True
        # Per-frame state log.
        saved: list[bool] = []

        # Stride equals window length (no overlap, except the final window).
        stride_step = input_audio_length
        slice_start = 0
        slice_end = input_audio_length

        # Iterate windows across the audio.
        while slice_end <= aligned_audio.shape[-1]:
            # Run ONNX inference; only the first three outputs matter.
            # outputs[0]: silence_score (batch, frames)
            # outputs[1]: active_score  (batch, frames)
            # outputs[2]: signal_len    (batch,) - number of valid frames in this window
            outputs = self.session.run(
                self.output_names[:3],
                {self.input_name: aligned_audio[:, :, slice_start:slice_end]},
            )
            score_silence, score_active, signal_len = outputs

            # Number of valid frames this window actually emits (may be < the theoretical max).
            frame_count = int(np.asarray(signal_len).reshape(-1)[0])

            # Per-frame state-machine decision.
            for i in range(frame_count):
                if silence:
                    # In silence: should we flip to speaking?
                    if float(score_active[:, i]) >= self.speaking_score:
                        silence = False
                else:
                    # Speaking: should we flip to silence?
                    if float(score_silence[:, i]) >= self.silence_score:
                        silence = True
                # Record the current-frame state.
                saved.append(silence)

            # Advance to the next window.
            slice_start += stride_step
            slice_end = slice_start + input_audio_length

        return saved

    def _vad_to_timestamps(self, vad_output: list[bool]) -> list[tuple[float, float]]:
        """Convert the per-frame silence sequence to speech-segment timestamps.

        Transitions:
            - silence -> speaking: record the segment start time.
            - speaking -> silence: record the segment end time and emit a segment.

        Note: if the final state is still "speaking", the last segment extends to the
        end of the audio.

        Args:
            vad_output: per-frame silence states, True=silence, False=speaking.

        Returns:
            list[tuple[float, float]]: list of (start_s, end_s) in seconds.
        """
        # Per-frame duration in seconds: 320/16000 = 20ms/frame.
        frame_duration = OUTPUT_FRAME_LENGTH / SAMPLE_RATE

        timestamps: list[tuple[float, float]] = []
        start: float | None = None  # start time of the current speech segment

        for i, is_silence in enumerate(vad_output):
            if is_silence:
                # Current frame is silence.
                if start is not None:
                    # speaking -> silence: close the current segment.
                    # End time = start of the current frame + frame duration.
                    end = i * frame_duration + frame_duration
                    timestamps.append((start, end))
                    start = None
            else:
                # Current frame is speaking.
                if start is None:
                    # silence -> speaking: open a new segment.
                    start = i * frame_duration

        # Close the final segment if the audio ends while still speaking.
        if start is not None:
            timestamps.append((start, len(vad_output) * frame_duration))

        return timestamps

    def _process_timestamps(
        self,
        timestamps: list[tuple[float, float]],
    ) -> list[tuple[float, float]]:
        """Post-process the timestamps: drop short segments, merge, then hard-split.

        Pipeline:
            1. Filter: remove segments shorter than `min_speech_duration` (typically noise).
            2. First merge: merge adjacent segments whose gap is <= `fusion_threshold`.
            3. Second merge: re-check and merge again (handles several consecutive small gaps).
            4. Hard-split merged segments whose duration exceeds `max_speech_duration`.

        The two-pass merge ensures that even chains of tiny-gap segments are merged
        correctly. The max-duration limit is applied after merging so the final output
        still respects the configured cap.

        Args:
            timestamps: raw speech-segment timestamps.

        Returns:
            list[tuple[float, float]]: processed timestamps.
        """
        # Step 1: drop short segments (noisy fragments below the minimum duration).
        filtered = [
            (start, end)
            for start, end in timestamps
            if (end - start) >= self.min_speech_duration
        ]

        # Step 2: first pass of adjacent-segment merging.
        # If the current segment's gap from the previous one is <= threshold, merge them.
        fused: list[tuple[float, float]] = []
        for start, end in filtered:
            if fused and (start - fused[-1][1] <= self.fusion_threshold):
                # Gap <= threshold: merge by extending the previous segment's end time.
                fused[-1] = (fused[-1][0], end)
            else:
                # Gap > threshold: keep as an independent segment.
                fused.append((start, end))

        # Step 3: second merge pass (handles chains of small gaps).
        # The first pass may create new adjacencies that need a re-check.
        fused_second_pass: list[tuple[float, float]] = []
        for start, end in fused:
            if fused_second_pass and (
                start - fused_second_pass[-1][1] <= self.fusion_threshold
            ):
                fused_second_pass[-1] = (fused_second_pass[-1][0], end)
            else:
                fused_second_pass.append((start, end))

        return self._split_long_timestamps(fused_second_pass)

    def _split_long_timestamps(
        self,
        timestamps: list[tuple[float, float]],
    ) -> list[tuple[float, float]]:
        """Hard-split timestamps that exceed `max_speech_duration`.

        Args:
            timestamps: processed speech-segment timestamps.

        Returns:
            list[tuple[float, float]]: timestamps after applying the max-duration cap.
        """
        if self.max_speech_duration is None:
            return timestamps

        split: list[tuple[float, float]] = []
        max_duration = self.max_speech_duration

        for start, end in timestamps:
            current_start = start
            while (end - current_start) > max_duration:
                current_end = current_start + max_duration
                split.append((current_start, current_end))
                current_start = current_end
            split.append((current_start, end))

        return split


@registry.vad_models.register("marblenet")
def marblenet_entrypoint(
    speaking_score: float = 0.5,
    silence_score: float = 0.5,
    fusion_threshold: float = 0.1,
    min_speech_duration: float = 0.05,
    max_speech_duration: float | None = None,
    intra_op_num_threads: int = 2,
    inter_op_num_threads: int = 0,
    **kwargs,
) -> MarbleNetForVAD:
    return MarbleNetForVAD(
        speaking_score=speaking_score,
        silence_score=silence_score,
        fusion_threshold=fusion_threshold,
        min_speech_duration=min_speech_duration,
        max_speech_duration=max_speech_duration,
        intra_op_num_threads=intra_op_num_threads,
        inter_op_num_threads=inter_op_num_threads,
        **kwargs,
    )
