# pyzero-joystick

pyzero-joystick is a simple joystick library inspired by Pygame Zero.

It allows beginners to use gamepads easily in Python games without dealing with complex event systems.

Works with the inputs library, making it compatible with Termux and Linux environments.

## Example

```python
from pyzero_joystick import joystick

def update(dt):
    if joystick.a:
        print("Jump!")
