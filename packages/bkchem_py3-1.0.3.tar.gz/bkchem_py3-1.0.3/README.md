BKChem-py3

BKChem-py3 is a modernized, high-performance port of the classic BKChem molecular editor, fully updated for Python 3.10 through Python 3.14+.

This project preserves the legacy of the original developers while introducing significant architectural improvements, new chemical drawing features, and modern deployment standards.

🚀 Quick Install

You can now install the latest stable version directly from PyPI:

# Standard installation
pip install bkchem-py3

# Installation with full image export support (PNG/PDF/SVG)
pip install "bkchem-py3[all]"


To launch the application after installation, simply type:

python -m bkchem.main 
bkchem



✨ New Features & Improvements

🎨 Chemical Drawing & UI

Expanded Arrow Set: Added specialized arrows including curly (mechanism), fishhook (radical), reversible, retrosynthetic, and equilibrium simple/complex arrows.

Modern Navigation: Added intuitive mouse-based zoom-in and zoom-out for precise canvas control.

Easier Annotations: Improved text material handling and label editing.

Undo System: Refactored undo/redo logic for better reliability.

🔬 Core Cheminformatics (OASA)

Rewritten SMILES Logic: Completely overhauled SMILES read/write functionality for superior handling of complex structures.

Thoroughly Modified OASA Library: Deep refactoring of the underlying OASA library to resolve legacy circular dependencies and support modern Python namespaces.

🛠️ Technical Modernization

Python 3.14+ Ready: Future-proofed plugin architecture using importlib (replacing the deprecated imp module).

Performance: Optimized code for significant improvements in speed and responsiveness.

Seamless Exporting: New 'Export to Image' functions to save structures directly in PNG, JPEG, and other file formats.

Reduced Dependencies: Streamlined requirements for easier installation across different environments.

Improved Page Setup: Enhanced printing and layout options for academic publications.

💻 Compatibility

Rigorously tested and verified on:

Windows 11

Python 3.10, 3.12, and 3.14 (WinPython)

Compatible with Linux (requires python3-tk)

🙏 Credits & Support

Original credit goes to the initial BKChem developers and maintainers who built the foundation of this tool. This port aims to keep their work alive and useful for the modern scientific community.

If you find this project useful for your research or teaching, please consider supporting further development:

☕ Support us on Buy Me a Coffee

Developed and maintained by Dr. Vijay Masand.