import logging
from abc import ABC, abstractmethod
from typing import Any, Generic, List, Optional, cast

from langchain_core.documents import (
    Document,  # or: from langchain.schema import Document
)
from pydantic import BaseModel, Field

from agentic_base.enums import EmbeddingPurposeEnum
from agentic_base.evaluation.async_batcher import AsyncBatcher
from agentic_base.mixins import FromConfigMixin
from agentic_base.types import TCEmbedder, TCProcessor, TCReranker, TCVectorStore

_logger = logging.getLogger(__name__)


class Processor(FromConfigMixin[TCProcessor], ABC, Generic[TCProcessor]):
    def __init__(self, config: TCProcessor) -> None:
        self.config = config

    @abstractmethod
    def __call__(self, text: str, purpose: EmbeddingPurposeEnum) -> str:
        raise NotImplementedError()


class Embedder(FromConfigMixin[TCEmbedder], ABC, Generic[TCEmbedder]):
    MAX_BATCH_SIZE: int = 15
    BATCH_TIMEOUT_MS: float = 4.921875

    def __init__(self, config: TCEmbedder) -> None:
        self.config = config
        self._batcher = AsyncBatcher[str, List[float]](
            batch_fn=self._aembed,
            max_batch_size=self.__class__.MAX_BATCH_SIZE,
            batch_timeout_ms=self.__class__.BATCH_TIMEOUT_MS,
        )
        _logger.info(f"Initialized Embedder | class={self.__class__.__name__}")

    # ---------------- ABSTRACT ----------------

    @abstractmethod
    async def _aembed(self, texts: List[str]) -> List[List[float]]:
        raise NotImplementedError()

    # ---------------- LIFECYCLE ----------------
    async def aclose(self) -> None:
        return None

    # ---------------- PUBLIC API ----------------

    async def aembed(self, texts: List[str]) -> List[List[float]]:
        return await self._batcher.submit(texts)

    async def aembed_queries(
        self,
        queries: List[str],
        processor: Optional[Processor[Any]] = None,
    ) -> List[List[float]]:
        if processor:
            queries = [
                processor(
                    text=query,
                    purpose=cast(EmbeddingPurposeEnum, EmbeddingPurposeEnum.QUERY),
                )
                for query in queries
            ]
        return await self.aembed(queries)

    async def aembed_query(
        self,
        query: str,
        processor: Optional[Processor[Any]] = None,
    ) -> List[float]:
        return (await self.aembed_queries([query], processor))[0]

    async def aembed_documents(
        self,
        docs: List[str],
        processor: Optional[Processor[Any]] = None,
    ) -> List[List[float]]:
        if processor:
            [
                processor(
                    text=doc,
                    purpose=cast(EmbeddingPurposeEnum, EmbeddingPurposeEnum.DOCUMENT),
                )
                for doc in docs
            ]
        return await self.aembed(docs)


class VectorStore(FromConfigMixin[TCVectorStore], ABC, Generic[TCVectorStore]):
    MAX_BATCH_SIZE: int = 3
    BATCH_TIMEOUT_MS: float = 0.984

    class VectorQuery(BaseModel):
        vector: List[float]
        limit: int

    class ScoredPoint(BaseModel):
        score: float = Field(
            ..., description="Points vector distance to the query vector"
        )
        document: Document

    class QueryResponse(BaseModel):
        points: List["VectorStore.ScoredPoint"]

    def __init__(self, config: TCVectorStore) -> None:
        self.config = config
        self._batcher = AsyncBatcher[
            VectorStore.VectorQuery,
            VectorStore.QueryResponse,
        ](
            batch_fn=self._abatch_query_points,
            max_batch_size=self.__class__.MAX_BATCH_SIZE,
            batch_timeout_ms=self.__class__.BATCH_TIMEOUT_MS,
        )
        _logger.info(
            f"Initialized VectorStore | class={self.__class__.__name__} | config={config}"
        )

    # -------- batching boundary --------

    @abstractmethod
    async def _abatch_query_points(
        self,
        requests: List["VectorStore.VectorQuery"],
    ) -> List["VectorStore.QueryResponse"]:
        """
        Backend-native batch query.
        Must return results in the same order as requests.
        """
        raise NotImplementedError()

    async def abatch_query_points(
        self,
        queries: List[List[float]],
        limit: int,
    ) -> List["VectorStore.QueryResponse"]:
        return await self._batcher.submit(
            [self.VectorQuery(vector=q, limit=limit) for q in queries]
        )

    async def aquery_points(
        self,
        query: List[float],
        limit: int,
    ) -> "VectorStore.QueryResponse":
        return (await self.abatch_query_points([query], limit))[0]

    # ---------------- LIFECYCLE ----------------
    async def aclose(self) -> None:
        """
        Close underlying async resources (HTTP clients, sockets, etc.).
        Default: no-op.
        """
        return None


class Reranker(FromConfigMixin[TCReranker], ABC):
    def __init__(self, config: TCReranker):
        super().__init__(config)

    @abstractmethod
    async def rerank(
        self,
        query: str,
        response: VectorStore.QueryResponse,
        limit: int,
    ) -> VectorStore.QueryResponse:
        """
        Given a query and retrieved candidates, return a reranked response.
        """
        raise NotImplementedError()

    async def aclose(self) -> None:
        return None
