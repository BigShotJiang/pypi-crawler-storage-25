from typing import Generator, List, Tuple

import httpx
from agentic_base.evaluation import Reranker, VectorStore
from agentic_base.evaluation.async_batcher import AsyncBatcher
from agentic_base.evaluation.settings import HFRerankerSettings, HTTPRerankerSettings
from agentic_base.exceptions import (
    RerankerHTTPError,
    RerankerResponseFormatError,
    RerankerValidationError,
)


class HFReranker(Reranker[HFRerankerSettings]):
    PADDING = True
    TRUNCATION = True

    def __init__(self, config: HFRerankerSettings) -> None:
        super().__init__(config)

        try:
            import torch
            from transformers import AutoModelForSequenceClassification, AutoTokenizer
        except ImportError as e:
            raise ImportError(
                "HFReranker requires torch + transformers.\n"
                "Install with: pip install agentic-base[torch]"
            ) from e

        self.torch = torch

        self.tokenizer = AutoTokenizer.from_pretrained(
            config.model_name,
            revision=config.revision,
        )

        self.model = AutoModelForSequenceClassification.from_pretrained(
            config.model_name,
            revision=config.revision,
        ).to(config.device)

        self.model.eval()

        self.batch_size = getattr(config, "batch_size", 16)

    def _batchify(
        self, data: List[Tuple[str, str]]
    ) -> Generator[List[Tuple[str, str]], None, None]:
        for i in range(0, len(data), self.batch_size):
            yield data[i : i + self.batch_size]

    async def rerank(
        self,
        query: str,
        response: VectorStore.QueryResponse,
        limit: int,
    ) -> VectorStore.QueryResponse:
        if not response.points:
            return response

        pairs = [(query, p.document.page_content) for p in response.points]

        all_scores = []

        with self.torch.no_grad():
            for batch in self._batchify(pairs):
                inputs = self.tokenizer(
                    batch,
                    padding=self.__class__.PADDING,
                    truncation=self.__class__.TRUNCATION,
                    return_tensors="pt",
                )

                inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
                logits = self.model(**inputs).logits.squeeze(-1)
                all_scores.extend(logits.cpu().tolist())

        reranked = sorted(
            zip(all_scores, response.points),
            key=lambda x: x[0],
            reverse=True,
        )[:limit]

        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=float(score),
                    document=point.document,
                )
                for score, point in reranked
            ]
        )


class HTTPReranker(Reranker["HTTPRerankerSettings"]):
    def __init__(self, config: "HTTPRerankerSettings") -> None:
        super().__init__(config)
        self.client = httpx.AsyncClient(timeout=self.config.timeout)
        self._batcher = AsyncBatcher[
            Tuple[str, str],  # (query, text)
            float,  # score
        ](
            batch_fn=self._batch_fn,
            max_batch_size=self.config.max_batch_size,
            batch_timeout_ms=self.config.batch_timeout_ms,
        )

    async def _batch_fn(self, inputs: List[Tuple[str, str]]) -> List[float]:
        """
        inputs: [(query, text), ...]
        returns: [score, ...] aligned with inputs
        """
        if not inputs:
            return []
        query = inputs[0][0]
        texts = [t for _, t in inputs]
        payload = {
            "query": query,
            "texts": texts,
        }
        try:
            r = await self.client.post(self.config.url, json=payload)
        except Exception as e:
            raise RerankerHTTPError(-1, f"Request failed: {e}", payload) from e
        self.handle_exceptions(r, payload)
        try:
            results = r.json()
        except Exception as e:
            raise RerankerResponseFormatError(r.text) from e
        try:
            scores = [0.0] * len(inputs)
            for item in results:
                idx = item["index"]
                score = float(item["score"])
                scores[idx] = score
        except Exception as e:
            raise RerankerResponseFormatError(results) from e

        return scores

    # ---------------- error handling ----------------

    def handle_exceptions(self, r: httpx.Response, payload: dict) -> None:
        if r.status_code == 422:
            raise RerankerValidationError(
                message=r.text,
                payload=payload,
            )

        if r.status_code >= 400:
            raise RerankerHTTPError(
                status_code=r.status_code,
                message=r.text,
                payload=payload,
            )

    # ---------------- main API ----------------

    async def rerank(
        self,
        query: str,
        response: VectorStore.QueryResponse,
        limit: int,
    ) -> VectorStore.QueryResponse:
        if not response.points:
            return response
        texts = [p.document.page_content for p in response.points if p.document]
        # 🔥 Submit ALL items to batcher (concurrent batching happens internally)
        scores = await self._batcher.submit([(query, text) for text in texts])
        # Map back
        scored = [(score, point) for score, point in zip(scores, response.points)]
        reranked = sorted(scored, key=lambda x: x[0], reverse=True)[:limit]
        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=score,
                    document=point.document,
                )
                for score, point in reranked
            ]
        )

    async def aclose(self) -> None:
        await self.client.aclose()
