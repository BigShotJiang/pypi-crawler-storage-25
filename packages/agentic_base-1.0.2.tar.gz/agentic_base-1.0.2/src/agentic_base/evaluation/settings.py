from typing import Any, Generic, List, Optional

from agentic_base.connector.settings import MinioDatasetConnectorSettings
from agentic_base.enums import FAISSIndexType
from agentic_base.settings import FromConfigMixinSettings
from agentic_base.types import (
    TCDatasetConnector,
    TCDenseRetriever,
    TCEmbedder,
    TCProcessor,
    TCReranker,
    TCRetriever,
    TCScore,
    TCVectorStore,
)
from pydantic import field_validator


class EmbedderSettings(FromConfigMixinSettings):
    model_name: str


class VLLMEmbedderSettings(EmbedderSettings):
    base_url: str


class ProcessorSettings(FromConfigMixinSettings):
    pass


class NomicProcessorSettings(ProcessorSettings):
    pass


class ScoreSettings(FromConfigMixinSettings):
    ks: List[int]


class RecallAtKScoreSettings(ScoreSettings):
    pass


class PrecisionAtKScoreSettings(ScoreSettings):
    pass


class MRRAtKScoreSettings(ScoreSettings):
    pass


class NDCGAtKScoreSettings(ScoreSettings):
    pass


class VectorStoreSettings(FromConfigMixinSettings):
    pass


class QdrantVectorStoreSettings(VectorStoreSettings):
    url: str
    collection_name: str
    timeout: Optional[int]


class FaissVectorStoreSettings(VectorStoreSettings):
    index_type: FAISSIndexType
    normalize: bool

    @field_validator("index_type", mode="before")
    @classmethod
    def normalize_index_type(cls, v: Any) -> FAISSIndexType:
        if isinstance(v, FAISSIndexType):
            return v
        if isinstance(v, str):
            try:
                return FAISSIndexType(v.lower())
            except ValueError as e:
                raise ValueError(f"Invalid FAISS index_type '{v}'.") from e
        raise TypeError(
            f"index_type must be a string or FAISSIndexType, got {type(v).__name__}"
        )


class RerankerSettings(FromConfigMixinSettings):
    pass


class HFRerankerSettings(RerankerSettings):
    model_name: str
    revision: Optional[str]
    device: str


class HTTPRerankerSettings(RerankerSettings):
    url: str
    timeout: float
    max_batch_size: int
    batch_timeout_ms: float


class RetrieverSettings(FromConfigMixinSettings, Generic[TCReranker]):
    reranker: Optional[TCReranker]


class BM25RetrieverSettings(
    RetrieverSettings[TCReranker],
    Generic[TCDatasetConnector, TCReranker],
):
    dataset_connector: TCDatasetConnector


class DenseRetrieverSettings(
    RetrieverSettings[TCReranker],
    Generic[TCEmbedder, TCVectorStore, TCProcessor, TCReranker],
):
    embedder: TCEmbedder
    vector_store: TCVectorStore
    processor: TCProcessor


class HybridRetrieverSettings(
    RetrieverSettings[TCReranker],
    Generic[TCDenseRetriever, TCDatasetConnector, TCReranker],
):
    dense_retriever: TCDenseRetriever
    bm25_retriever: BM25RetrieverSettings[TCDatasetConnector, TCReranker]
    rrf_k: int


class BM25QdrantVLLMHybridRetrieverSettings(
    HybridRetrieverSettings[
        DenseRetrieverSettings[
            VLLMEmbedderSettings,
            QdrantVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
        MinioDatasetConnectorSettings,
        RerankerSettings,
    ]
):
    pass


class EvaluatorSettings(
    FromConfigMixinSettings, Generic[TCDatasetConnector, TCRetriever]
):
    dataset_connector: TCDatasetConnector
    retriever: TCRetriever


class PythonEvaluatorSettings(
    EvaluatorSettings[TCDatasetConnector, TCRetriever],
    Generic[TCDatasetConnector, TCRetriever, TCScore],
):
    scores: List[TCScore]
    limit: int


class QdrantEvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        DenseRetrieverSettings[
            VLLMEmbedderSettings,
            QdrantVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
        RecallAtKScoreSettings,
    ]
):
    pass


class FaissEvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        DenseRetrieverSettings[
            TCEmbedder,
            FaissVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
        RecallAtKScoreSettings,
    ],
    Generic[TCEmbedder],
):
    pass


class BM25EvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        BM25RetrieverSettings[MinioDatasetConnectorSettings, RerankerSettings],
        RecallAtKScoreSettings,
    ]
):
    pass


class HybridRetrieverEvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        BM25QdrantVLLMHybridRetrieverSettings,
        RecallAtKScoreSettings,
    ]
):
    pass
