"""Legacy Option A charge-result adapter.

SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: this module is retained as a
compatibility import for callers that have not yet moved to
``MediBot_ServiceLineInput``.
"""

try:
    from MediBot.MediBot_ServiceLineInput import (
        calculate_option_a_charge_result,
        calculate_service_line_amount_result,
    )
except Exception:
    try:
        from MediBot_ServiceLineInput import (
            calculate_option_a_charge_result,
            calculate_service_line_amount_result,
        )
    except Exception:
        from MediCafe.charges_tool import calculate_option_a_charge_result
        from MediCafe.charges_tool import calculate_service_line_amount_result
