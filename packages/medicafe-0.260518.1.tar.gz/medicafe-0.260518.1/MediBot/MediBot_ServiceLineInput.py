"""Service Line Input charge-result adapter.

The charge rules live in ``MediCafe.charges_tool`` so other MediCafe surfaces
can share the same XP-safe review-only contract. This module is the canonical
MediBot-facing import for the renamed 837P Service Line Input workflow.
"""

try:
    from MediCafe.charges_tool import calculate_service_line_amount_result
except Exception:
    def calculate_service_line_amount_result(context):
        return {
            "schema_version": "charges_tool.unavailable",
            "charge_schema_version": "charges_tool.unavailable",
            "charge_status": "pending",
            "charge_display": "PENDING",
            "charge_note": "charge helper unavailable",
            "charge_amount": "",
            "charge_rule_id": "charge_helper_unavailable",
            "charge_source": "adapter_fallback",
            "billable": False,
            "requires_operator_review": True,
            "workflow_boundary": "preview_only_review_required",
            "claims_completion": False,
            "mutates_billing_state": False,
            "mutates_dat": False,
            "mutates_837p": False,
            "charges_entered": False,
        }


def calculate_option_a_charge_result(context):
    """Legacy Option A adapter name.

    SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: remove this compatibility
    alias only after callers and release-cycle sidecars have moved to
    ``calculate_service_line_amount_result``.
    """
    return calculate_service_line_amount_result(context)
