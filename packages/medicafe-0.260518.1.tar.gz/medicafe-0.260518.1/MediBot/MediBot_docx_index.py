import os
import json
import time
import zipfile
from datetime import datetime

try:
    from MediCafe.core_utils import get_config_loader_with_fallback
    MediLink_ConfigLoader = get_config_loader_with_fallback()
except Exception:
    MediLink_ConfigLoader = None

try:
    from MediBot.MediBot_docx_decoder import parse_docx, extract_date_of_service
except Exception:
    parse_docx = None
    extract_date_of_service = None

INDEX_FILENAME = '.docx_schedule_index.json'
STATUS_FILENAME = '.docx_schedule_index_status.json'
INDEX_VERSION = 1
PARSE_ERROR_MESSAGE_LIMIT = 200
_DOCX_INDEX_PARSE_FAILURE_COUNTS = {}
_DOCX_INDEX_PARSE_FAILURE_SAMPLES = {}


def _log(message, level="INFO"):
    if MediLink_ConfigLoader and hasattr(MediLink_ConfigLoader, 'log'):
        MediLink_ConfigLoader.log(message, level=level)
    else:
        print("[{}] {}".format(level, message))


def _default_index():
    return {
        'version': INDEX_VERSION,
        'files': {},
        'schedules': {}
    }

def _truncate_message(value, limit=PARSE_ERROR_MESSAGE_LIMIT):
    try:
        text = str(value)
    except Exception:
        return ''
    if len(text) <= limit:
        return text
    return text[:limit]


def _safe_basename(path):
    try:
        name = os.path.basename(str(path or '').replace('\\', '/'))
    except Exception:
        name = ''
    return name or '<unknown>'


def _sanitize_parse_error_message(exc, filepath):
    text = _truncate_message(exc)
    try:
        raw_path = str(filepath or '')
        if raw_path:
            basename = _safe_basename(raw_path)
            text = text.replace(raw_path, basename)
            text = text.replace(raw_path.replace('/', '\\'), basename)
            text = text.replace(raw_path.replace('\\', '/'), basename)
    except Exception:
        pass
    return text


def _log_parse_failure(filepath, error_type, exc):
    basename = _safe_basename(filepath)
    try:
        error_class = exc.__class__.__name__
    except Exception:
        error_class = 'Exception'
    key = (str(error_type or 'unknown'), basename, error_class)
    count = int(_DOCX_INDEX_PARSE_FAILURE_COUNTS.get(key, 0) or 0) + 1
    _DOCX_INDEX_PARSE_FAILURE_COUNTS[key] = count
    sample = _sanitize_parse_error_message(exc, filepath)
    samples = _DOCX_INDEX_PARSE_FAILURE_SAMPLES.get(key)
    if not isinstance(samples, list):
        samples = []
    if sample and sample not in samples and len(samples) < 3:
        samples.append(sample)
    _DOCX_INDEX_PARSE_FAILURE_SAMPLES[key] = samples
    if count == 1:
        _log(
            "DOCX index parse failure: file={} error_type={} error_class={} error={}".format(
                basename,
                error_type,
                error_class,
                sample,
            ),
            level="WARNING",
        )
    else:
        _log(
            "DOCX index parse failure repeat suppressed: file={} error_type={} error_class={} count={} samples={}".format(
                basename,
                error_type,
                error_class,
                count,
                samples,
            ),
            level="DEBUG",
        )


def classify_parse_error(exc):
    # Prefer type checks for broad IO failures; keep string checks for docx specifics.
    try:
        if isinstance(exc, (IOError, OSError)):
            return 'transient_io'
    except Exception:
        pass

    name = ''
    try:
        name = exc.__class__.__name__
    except Exception:
        name = ''

    if name in ('BadZipFile', 'PackageNotFoundError'):
        return 'corrupt_docx'
    if name in ('ValueError', 'ParseError'):
        return 'content_error'
    return 'unknown'


def classify_docx_package(filepath):
    """
    Validate the outer DOCX package before invoking python-docx.

    Returns a non-PII shape payload suitable for index records and support
    bundles. This avoids repeatedly sending known-invalid tiny files through
    the expensive parser path.
    """
    payload = {
        'valid': False,
        'reason': '',
        'missing_parts': [],
    }
    try:
        if not zipfile.is_zipfile(filepath):
            payload['reason'] = 'not_zip_package'
            return payload
        archive = zipfile.ZipFile(filepath, 'r')
        try:
            names = set(archive.namelist())
        finally:
            archive.close()
        missing = []
        for required in ('[Content_Types].xml', 'word/document.xml'):
            if required not in names:
                missing.append(required)
        if missing:
            payload['reason'] = 'missing_required_docx_parts'
            payload['missing_parts'] = missing
            return payload
        payload['valid'] = True
        payload['reason'] = 'valid_docx_package'
        return payload
    except Exception as exc:
        payload['reason'] = 'docx_package_validation_error'
        payload['error_class'] = exc.__class__.__name__
        payload['error_message'] = _truncate_message(_sanitize_parse_error_message(exc, filepath))
        return payload


def _extract_docx_date(docx_path):
    if extract_date_of_service is None:
        return None
    try:
        return extract_date_of_service(docx_path)
    except Exception:
        return None


def get_index_path(local_storage_path):
    return os.path.join(local_storage_path, INDEX_FILENAME)


def get_status_path(local_storage_path):
    return os.path.join(local_storage_path, STATUS_FILENAME)


def load_docx_schedule_index(local_storage_path):
    index_path = get_index_path(local_storage_path)
    if not os.path.exists(index_path):
        return _default_index()
    try:
        with open(index_path, 'r') as jf:
            data = json.load(jf)
        if not isinstance(data, dict):
            return _default_index()
        if 'files' not in data or 'schedules' not in data:
            return _default_index()
        if data.get('version') != INDEX_VERSION:
            # Simple upgrade path: preserve data where possible
            data.setdefault('files', {})
            data.setdefault('schedules', {})
            data['version'] = INDEX_VERSION
        return data
    except Exception:
        return _default_index()


def collect_failed_docx_parse_candidates(local_storage_path, index_data=None):
    """
    Return failed DOCX index records with current on-disk classification.

    The payload intentionally contains only filenames, fingerprints, and parser
    error metadata so it can be printed in operator previews without touching
    patient schedule rows.
    """
    if index_data is None:
        index_data = load_docx_schedule_index(local_storage_path)
    files = {}
    try:
        raw_files = index_data.get('files', {})
        if isinstance(raw_files, dict):
            files = raw_files
    except Exception:
        files = {}

    candidates = []
    for raw_name in sorted(files.keys()):
        rec = files.get(raw_name)
        if not isinstance(rec, dict) or not rec.get('parse_failed'):
            continue
        filename = _safe_basename(raw_name)
        resolved_path = os.path.join(local_storage_path, filename)
        present = os.path.isfile(resolved_path)
        prior_size = rec.get('size')
        prior_mtime = rec.get('mtime')
        current_size = None
        current_mtime = None
        changed_since_failure = False
        if present:
            try:
                stat_info = os.stat(resolved_path)
                current_size = stat_info.st_size
                current_mtime = stat_info.st_mtime
                changed_since_failure = (
                    prior_size != current_size or
                    prior_mtime != current_mtime
                )
            except Exception:
                present = False
        if not present:
            status = 'missing'
        elif changed_since_failure:
            status = 'changed_since_failure'
        else:
            status = 'present'
        candidates.append({
            'filename': filename,
            'path': resolved_path,
            'present': bool(present),
            'missing': not bool(present),
            'status': status,
            'changed_since_failure': bool(changed_since_failure),
            'parse_error_type': rec.get('parse_error_type') or 'unknown',
            'parse_error_message': rec.get('parse_error_message') or '',
            'date_of_service': rec.get('date_of_service'),
            'prior_size': prior_size,
            'prior_mtime': prior_mtime,
            'current_size': current_size,
            'current_mtime': current_mtime,
        })
    return candidates


def _safe_replace(src, dst):
    attempts = 0
    while attempts < 3:
        attempts += 1
        try:
            if os.path.exists(dst):
                os.remove(dst)
            os.rename(src, dst)
            return True
        except Exception:
            if attempts < 3:
                try:
                    time.sleep(0.05 * attempts)
                except Exception:
                    pass
    return False


def _save_docx_json_payload(path, payload, write_label, warning_label):
    try:
        from MediCafe.json_io import write_json_atomic
    except ImportError:
        write_json_atomic = None
    if write_json_atomic is not None:
        if write_json_atomic(
                path,
                payload,
                write_label,
                'MediBot_docx_index',
                indent=2,
                sort_keys=False,
                lock=False,
                ensure_ascii=False,
        ):
            return
        _log("Failed to write {}: atomic write returned false".format(warning_label), level="WARNING")
        return
    tmp_path = path + ".tmp"
    try:
        with open(tmp_path, 'w') as jf:
            json.dump(payload, jf)
        _safe_replace(tmp_path, path)
    except Exception as e:
        _log("Failed to write {}: {}".format(warning_label, e), level="WARNING")


def save_docx_schedule_index(local_storage_path, index_data):
    index_path = get_index_path(local_storage_path)
    _save_docx_json_payload(
        index_path,
        index_data,
        'docx_schedule_index',
        'DOCX schedule index',
    )


def load_docx_schedule_index_status(local_storage_path):
    status_path = get_status_path(local_storage_path)
    if not os.path.exists(status_path):
        return {}
    try:
        with open(status_path, 'r') as jf:
            data = json.load(jf)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_docx_schedule_index_status(local_storage_path, status_data):
    status_path = get_status_path(local_storage_path)
    _save_docx_json_payload(
        status_path,
        status_data,
        'docx_schedule_index_status',
        'DOCX schedule index status',
    )


def normalize_date_value(date_value):
    if date_value is None:
        return None
    if isinstance(date_value, datetime):
        return date_value.strftime('%m-%d-%Y')
    date_str = str(date_value).strip()
    if not date_str:
        return None
    # Common formats used in this project
    for fmt in ('%m-%d-%Y', '%m/%d/%Y', '%Y-%m-%d', '%Y/%m/%d'):
        try:
            return datetime.strptime(date_str, fmt).strftime('%m-%d-%Y')
        except Exception:
            continue
    # As-is fallback for already normalized strings
    if len(date_str) == 10 and date_str.count('-') == 2:
        return date_str
    return date_str


def _build_schedule_by_date(patient_data, schedule_positions=None):
    schedule_by_date = {}
    for patient_id, dates in patient_data.items():
        for date_str, details in dates.items():
            if date_str not in schedule_by_date:
                schedule_by_date[date_str] = {}
            entry = {
                'diagnosis': details[0] if isinstance(details, (list, tuple)) and len(details) > 0 else None,
                'eye': details[1] if isinstance(details, (list, tuple)) and len(details) > 1 else None,
                'femto': details[2] if isinstance(details, (list, tuple)) and len(details) > 2 else None
            }
            if schedule_positions and patient_id in schedule_positions:
                pos = schedule_positions[patient_id].get(date_str)
                if pos is not None:
                    entry['position'] = pos
            schedule_by_date[date_str][patient_id] = entry
    return schedule_by_date


def update_docx_schedule_index(local_storage_path, filepaths=None, capture_schedule_positions=False, force_rebuild=False, source='unknown', retry_failed=False):
    started_at = int(time.time())
    requested_file_count = None
    update_mode = 'full_scan' if filepaths is None else 'targeted'
    normalized_filepaths = None
    if filepaths is not None:
        normalized_filepaths = list(filepaths)
        requested_file_count = len(normalized_filepaths)
    if parse_docx is None:
        _log("DOCX parser unavailable; cannot update schedule index.", level="WARNING")
        stats = {'parsed': 0, 'skipped': 0, 'errors': 0, 'updated': False}
        save_docx_schedule_index_status(local_storage_path, {
            'source': source or 'unknown',
            'mode': update_mode,
            'requested_file_count': requested_file_count,
            'capture_schedule_positions': bool(capture_schedule_positions),
            'force_rebuild': bool(force_rebuild),
            'retry_failed': bool(retry_failed),
            'started_at': started_at,
            'completed_at': int(time.time()),
            'stats': stats,
            'parser_available': False,
        })
        return _default_index(), stats

    index_data = _default_index() if force_rebuild else load_docx_schedule_index(local_storage_path)
    index_files = index_data.get('files', {})
    index_schedules = index_data.get('schedules', {})

    if normalized_filepaths is None:
        try:
            listing = os.listdir(local_storage_path)
        except Exception as e:
            _log("Unable to list DOCX directory '{}': {}".format(local_storage_path, e), level="ERROR")
            stats = {'parsed': 0, 'skipped': 0, 'errors': 0, 'updated': False}
            save_docx_schedule_index_status(local_storage_path, {
                'source': source or 'unknown',
                'mode': update_mode,
                'requested_file_count': requested_file_count,
                'capture_schedule_positions': bool(capture_schedule_positions),
                'force_rebuild': bool(force_rebuild),
                'retry_failed': bool(retry_failed),
                'started_at': started_at,
                'completed_at': int(time.time()),
                'stats': stats,
                'parser_available': True,
                'error': _truncate_message(e),
            })
            return index_data, stats
        filepaths = [os.path.join(local_storage_path, f) for f in listing if f.lower().endswith('.docx')]
    else:
        filepaths = normalized_filepaths
    requested_file_count = len(filepaths)

    parsed = 0
    skipped = 0
    errors = 0
    invalid_docx_package = 0
    updated = False

    for filepath in filepaths:
        if not os.path.isfile(filepath):
            continue
        filename = os.path.basename(filepath)
        try:
            stat_info = os.stat(filepath)
        except Exception:
            errors += 1
            continue

        rec = index_files.get(filename)
        file_changed = True
        if rec is not None:
            file_changed = (
                rec.get('mtime') != stat_info.st_mtime or
                rec.get('size') != stat_info.st_size
            )

        needs_parse = False
        if force_rebuild or rec is None or file_changed:
            needs_parse = True
        else:
            # Do not retry failed parses unless the file changes or force_rebuild is requested
            if rec.get('parse_failed') and retry_failed:
                needs_parse = True
            elif rec.get('parse_failed'):
                needs_parse = False
            elif capture_schedule_positions and not rec.get('has_positions'):
                needs_parse = True

        if not needs_parse:
            skipped += 1
            continue

        package_info = classify_docx_package(filepath)
        if not package_info.get('valid'):
            errors += 1
            invalid_docx_package += 1
            parse_error_type = 'invalid_docx_package'
            parse_error_message = package_info.get('reason') or 'invalid_docx_package'
            missing_parts = package_info.get('missing_parts') or []
            if missing_parts:
                parse_error_message = parse_error_message + ': ' + ','.join(missing_parts)
            index_files[filename] = {
                'mtime': stat_info.st_mtime,
                'size': stat_info.st_size,
                'dates': [],
                'has_positions': bool(capture_schedule_positions),
                'parse_failed': True,
                'parse_error_type': parse_error_type,
                'parse_error_message': _truncate_message(parse_error_message),
                'parse_failed_at': int(time.time()),
                'date_of_service': None,
                'docx_package_valid': False,
                'docx_package_reason': package_info.get('reason') or '',
                'updated_at': int(time.time())
            }
            _log(
                "DOCX package validation failed: file={} reason={} size={}".format(
                    filename,
                    package_info.get('reason') or '',
                    stat_info.st_size,
                ),
                level="WARNING",
            )
            updated = True
            parsed += 1
            continue

        error_type = None
        error_message = None
        patient_data = None
        schedule_positions = None
        attempt = 0
        while attempt < 2:
            attempt += 1
            try:
                if capture_schedule_positions:
                    result = parse_docx(filepath, surgery_dates=None, capture_schedule_positions=True)
                    if isinstance(result, tuple) and len(result) == 2:
                        patient_data, schedule_positions = result
                    else:
                        patient_data = result if result else {}
                        schedule_positions = None
                else:
                    patient_data = parse_docx(filepath, surgery_dates=None, capture_schedule_positions=False)
                    schedule_positions = None
                error_type = None
                error_message = None
                break
            except Exception as exc:
                error_type = classify_parse_error(exc)
                error_message = _sanitize_parse_error_message(exc, filepath)
                # One immediate retry for transient IO issues only
                if error_type == 'transient_io' and attempt < 2:
                    continue
                _log_parse_failure(filepath, error_type, exc)
                errors += 1
                break

        if not patient_data:
            if error_type is None:
                errors += 1
            dos_value = _extract_docx_date(filepath)
            parse_error_type = error_type or 'empty_parse'
            parse_error_message = error_message or 'No patient data extracted from DOCX.'
            # Record fingerprint to avoid repeated parsing; keep parse_failed marker
            index_files[filename] = {
                'mtime': stat_info.st_mtime,
                'size': stat_info.st_size,
                'dates': [],
                'has_positions': bool(capture_schedule_positions),
                'parse_failed': True,
                'parse_error_type': parse_error_type,
                'parse_error_message': _truncate_message(parse_error_message),
                'parse_failed_at': int(time.time()),
                'date_of_service': dos_value,
                'updated_at': int(time.time())
            }
            updated = True
            parsed += 1
            continue

        schedule_by_date = _build_schedule_by_date(patient_data, schedule_positions)
        date_list = sorted(schedule_by_date.keys())

        # Update file record
        index_files[filename] = {
            'mtime': stat_info.st_mtime,
            'size': stat_info.st_size,
            'dates': date_list,
            'has_positions': bool(capture_schedule_positions),
            'parse_failed': False,
            'updated_at': int(time.time())
        }

        # Update schedules by date
        for date_str, patients in schedule_by_date.items():
            schedule_entry = index_schedules.get(date_str, {})
            current = schedule_entry.get('current')
            new_payload = {
                'source_file': filename,
                'source_mtime': stat_info.st_mtime,
                'patients': patients
            }
            if current:
                same_source = (
                    current.get('source_file') == filename and
                    current.get('source_mtime') == stat_info.st_mtime
                )
                if not same_source:
                    history = schedule_entry.get('history', [])
                    history.append(current)
                    schedule_entry['history'] = history
            schedule_entry['current'] = new_payload
            index_schedules[date_str] = schedule_entry

        parsed += 1
        updated = True

    index_data['files'] = index_files
    index_data['schedules'] = index_schedules

    if updated:
        save_docx_schedule_index(local_storage_path, index_data)

    stats = {
        'parsed': parsed,
        'skipped': skipped,
        'errors': errors,
        'invalid_docx_package': invalid_docx_package,
        'updated': updated,
    }
    save_docx_schedule_index_status(local_storage_path, {
        'source': source or 'unknown',
        'mode': update_mode,
        'requested_file_count': requested_file_count,
        'capture_schedule_positions': bool(capture_schedule_positions),
        'force_rebuild': bool(force_rebuild),
        'retry_failed': bool(retry_failed),
        'started_at': started_at,
        'completed_at': int(time.time()),
        'stats': stats,
        'parser_available': True,
    })
    return index_data, stats


def get_schedules_for_dates(index_data, date_values):
    schedules = index_data.get('schedules', {}) if isinstance(index_data, dict) else {}
    requested = []
    for value in date_values:
        normalized = normalize_date_value(value)
        if normalized:
            requested.append(normalized)
    result = {}
    for date_str in requested:
        entry = schedules.get(date_str)
        if entry and isinstance(entry, dict):
            current = entry.get('current')
            if current:
                result[date_str] = current
    return result


def get_diagnosis_code_allowed_set(local_storage_path, date_values):
    """
    Return a set of (patient_id_str, date_str) tuples for patient/date combinations
    that have a non-empty diagnosis code in the DOCX schedule index.
    
    Args:
        local_storage_path: Directory containing the DOCX schedule index
        date_values: List of date values (datetime, string, etc.) to check
    
    Returns:
        set: Set of (patient_id_str, date_str) tuples where date_str is 'MM-DD-YYYY' format
             and diagnosis is non-empty
    """
    index_data = load_docx_schedule_index(local_storage_path)
    schedules = get_schedules_for_dates(index_data, date_values)
    
    allowed_set = set()
    for date_str, current in schedules.items():
        patients = current.get('patients', {})
        for patient_id, payload in patients.items():
            diagnosis = (payload.get('diagnosis') or '').strip()
            if diagnosis:
                allowed_set.add((str(patient_id), date_str))
    
    return allowed_set

