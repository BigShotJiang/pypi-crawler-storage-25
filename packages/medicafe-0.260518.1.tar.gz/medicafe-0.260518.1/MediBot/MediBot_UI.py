#MediBot_UI.py
import ctypes, os, time, re, threading
from ctypes import wintypes
from sys import exit
from datetime import datetime, date

# Set up paths using core utilities

from MediCafe.core_utils import get_shared_config_loader
MediLink_ConfigLoader = get_shared_config_loader()
if MediLink_ConfigLoader is None:
    raise ImportError(
        "[MediBot_UI] CRITICAL: MediLink_ConfigLoader module import failed. "
        "This module requires MediLink_ConfigLoader to function. "
        "Check PYTHONPATH, module dependencies, and ensure MediCafe package is properly installed."
    )

# Import current_patient_context with fallback
try:
    from MediBot import current_patient_context
except ImportError:
    current_patient_context = None

try:
    from MediBot.MediBot_ServiceLineInput import calculate_service_line_amount_result
except Exception:
    try:
        from MediBot_ServiceLineInput import calculate_service_line_amount_result
    except Exception:
        try:
            from MediBot.MediBot_OptionA_Charge import calculate_option_a_charge_result
        except Exception:
            try:
                from MediBot_OptionA_Charge import calculate_option_a_charge_result
            except Exception:
                calculate_option_a_charge_result = None
            calculate_service_line_amount_result = calculate_option_a_charge_result
        else:
            calculate_service_line_amount_result = calculate_option_a_charge_result

calculate_option_a_charge_result = calculate_service_line_amount_result

try:
    from MediCafe import service_line_input_model as ServiceLineInputModel
except Exception:
    ServiceLineInputModel = None
    
# Set up lazy configuration loading using core utilities
from MediCafe.core_utils import create_config_cache
_get_config, (_config_cache, _crosswalk_cache) = create_config_cache()

# Optional operator/debug UX at triage: which CSV basename is loaded (often SX_CSV_*).
# Off by default; set MEDIBOT_DEBUG_TRIAGE_CSV=1 (or true/yes/y/on) to show.
def _debug_show_triage_source_csv():
    v = str(os.environ.get('MEDIBOT_DEBUG_TRIAGE_CSV', '') or '').strip().lower()
    return v in ('1', 'true', 'yes', 'y', 'on')

try:
    from MediCafe.patient_financial_display import get_patient_financial_display
except ImportError:
    get_patient_financial_display = None

try:
    from MediCafe.claim_lifecycle_display import (
        build_claim_lifecycle_context,
        get_claim_lifecycle_display_for_row,
        build_claim_lifecycle_mini_runbook_lines,
    )
except ImportError:
    build_claim_lifecycle_context = None
    get_claim_lifecycle_display_for_row = None
    build_claim_lifecycle_mini_runbook_lines = None


def _build_lifecycle_context_with_heartbeat(config=None, threshold_seconds=5.0, heartbeat_seconds=2.0, suppress_heartbeat=False):
    """Build lifecycle context with delayed heartbeat for long-running reads."""
    if not (build_claim_lifecycle_context and get_claim_lifecycle_display_for_row):
        return None
    if suppress_heartbeat:
        try:
            return build_claim_lifecycle_context(config=config)
        except Exception:
            return None

    started_at = time.time()
    stop_event = threading.Event()
    heartbeat_started = {'value': False}

    def _heartbeat():
        while not stop_event.wait(0.25):
            elapsed = time.time() - started_at
            if elapsed < threshold_seconds:
                continue
            if not heartbeat_started['value']:
                heartbeat_started['value'] = True
                print("[WORKING] Building claim lifecycle context (>{:.0f}s)".format(threshold_seconds))
                print("          Reading submission/status/remittance ledgers...")
                continue
            if stop_event.wait(heartbeat_seconds):
                break
            elapsed = time.time() - started_at
            print("          Still building claim lifecycle context... {:.1f}s".format(elapsed))

    thread = threading.Thread(target=_heartbeat)
    thread.daemon = True
    thread.start()
    try:
        result = build_claim_lifecycle_context(config=config)
    except Exception:
        result = None
    finally:
        stop_event.set()
        try:
            thread.join(0.5)
        except Exception:
            pass

    if heartbeat_started['value']:
        elapsed = time.time() - started_at
        print("[DONE] Claim lifecycle context ready ({:.1f}s)".format(elapsed))
    return result

def display_enhanced_patient_table(
    patient_info,
    title,
    show_line_numbers=True,
    interactive=False,
    config=None,
    suppress_lifecycle_heartbeat=False
):
    """
    Display an enhanced patient table with multiple surgery dates and diagnosis codes.
    
    Args:
        patient_info: List of tuples (surgery_date, patient_name, patient_id, diagnosis_code, patient_row)
        title: Title for the table section
        show_line_numbers: Whether to show line numbers (True for new patients, False for existing)
        interactive: Whether to use interactive mode (deprecated)
        config: Optional config dictionary for cache lookup (if None, cache lookups will be skipped)
        suppress_lifecycle_heartbeat: When True, suppress inner lifecycle heartbeat logging.
            Use this when the caller already wraps this function with an outer stage heartbeat.
    """
    if not patient_info:
        return
    
    print(title)
    print()

    lifecycle_context = _build_lifecycle_context_with_heartbeat(
        config=config,
        suppress_heartbeat=suppress_lifecycle_heartbeat
    )

    # Normalize data to avoid None and unexpected container types in sort key
    normalized_info = []
    for surgery_date, patient_name, patient_id, diagnosis_code, patient_row in patient_info:
        # Normalize date into comparable key and display string
        display_date = None
        current_date_dt = None
        try:
            if hasattr(surgery_date, 'strftime'):
                display_date = surgery_date.strftime('%m-%d')
                current_date_dt = surgery_date
            elif isinstance(surgery_date, str):
                # Date strings may be MM-DD-YYYY or already MM-DD
                parts = surgery_date.split('-') if surgery_date else []
                if len(parts) == 3 and all(parts):
                    display_date = "{}-{}".format(parts[0], parts[1])
                    try:
                        current_date_dt = datetime.strptime(surgery_date, '%m-%d-%Y')
                    except Exception:
                        current_date_dt = None
                else:
                    display_date = surgery_date or 'Unknown Date'
                    current_date_dt = None
            else:
                display_date = str(surgery_date) if surgery_date is not None else 'Unknown Date'
                current_date_dt = None
        except Exception:
            display_date = str(surgery_date) if surgery_date is not None else 'Unknown Date'
            current_date_dt = None
        
        # Normalize diagnosis display: only show "-Not Found-" when explicitly flagged as N/A
        # XP SP3 + Py3.4.4 compatible error handling
        display_diagnosis = diagnosis_code
        try:
            if diagnosis_code == "N/A":
                display_diagnosis = "-Not Found-"
            elif diagnosis_code is None:
                display_diagnosis = "-Not Found-"
            elif isinstance(diagnosis_code, str) and diagnosis_code.strip() == "":
                display_diagnosis = "-Not Found-"
            else:
                display_diagnosis = str(diagnosis_code)
        except (TypeError, ValueError) as e:
            # Log the specific error for debugging (ASCII-only compatible)
            try:
                error_msg = "Error converting diagnosis code to string: {}".format(str(e))
                MediLink_ConfigLoader.log(error_msg, level="WARNING")
            except Exception:
                # Fallback logging if string formatting fails
                MediLink_ConfigLoader.log("Error converting diagnosis code to string", level="WARNING")
            display_diagnosis = "-Not Found-"

        # Grouping: place all dates for a patient together under their earliest date
        primary_date_dt = None
        within_index = 0
        last_name_key = ''
        first_name_key = ''
        try:
            all_dates = []
            if patient_row is not None:
                raw_dates = patient_row.get('_all_surgery_dates', [])
                # Convert to datetime list and find primary
                for d in raw_dates:
                    try:
                        if hasattr(d, 'strftime'):
                            all_dates.append(d)
                        elif isinstance(d, str):
                            all_dates.append(datetime.strptime(d, '%m-%d-%Y'))
                    except Exception:
                        pass
                if all_dates:
                    all_dates.sort()
                    primary_date_dt = all_dates[0]
                    # Determine within-patient index of current date
                    if current_date_dt is not None:
                        # Find matching index by exact date
                        for idx, ad in enumerate(all_dates):
                            if current_date_dt == ad:
                                within_index = idx
                                break
                # Prefer explicit last/first from row for sorting
                try:
                    ln = patient_row.get('Patient Last')
                    fn = patient_row.get('Patient First')
                    if isinstance(ln, str):
                        last_name_key = ln.strip().upper()
                    if isinstance(fn, str):
                        first_name_key = fn.strip().upper()
                except Exception:
                    pass
        except Exception:
            primary_date_dt = None
            within_index = 0

        # Fallbacks if parsing failed
        if primary_date_dt is None:
            primary_date_dt = current_date_dt
        # If last/first not available from row, parse from display name "LAST, FIRST ..."
        if not last_name_key and isinstance(patient_name, str):
            try:
                parts = [p.strip() for p in patient_name.split(',')]
                if len(parts) >= 1:
                    last_name_key = parts[0].upper()
                if len(parts) >= 2:
                    first_name_key = parts[1].split()[0].upper() if parts[1] else ''
            except Exception:
                last_name_key = ''
                first_name_key = ''

        # Build composite sort key per requirement: by earliest date, then last name within date,
        # while keeping same patient's additional dates directly under the first line
        composite_sort_key = (primary_date_dt, last_name_key, first_name_key, str(patient_id or ''), within_index)
        
        # Perform shared cache lookup for insurance type + remaining amount
        it_code_display = '--'
        remaining_amount_display = 'N/A'
        if get_patient_financial_display and current_date_dt:
            try:
                lookup_patient_id = str(patient_id or '')
                if not lookup_patient_id and patient_row:
                    lookup_patient_id = str(patient_row.get('Patient ID #2', ''))
                
                if lookup_patient_id:
                    display_payload = get_patient_financial_display(
                        lookup_patient_id,
                        config=config,
                        service_date=current_date_dt
                    )
                    it_code_display = display_payload.get('it_code_display', '--')
                    remaining_amount_display = display_payload.get('remaining_amount_display', 'N/A')
            except Exception as e:
                # Fail gracefully - log at DEBUG level only (avoid HIPAA data in logs)
                try:
                    MediLink_ConfigLoader.log("Cache lookup error in display_enhanced_patient_table: {}".format(str(e)), level="DEBUG")
                except Exception:
                    pass  # Silently fail if logging unavailable
        
        claim_state_display = 'Not Sent'
        claim_detail_display = '-'
        if get_claim_lifecycle_display_for_row:
            try:
                lifecycle_row = {}
                if isinstance(patient_row, dict):
                    lifecycle_row.update(patient_row)
                if patient_id and 'patient_id' not in lifecycle_row:
                    lifecycle_row['patient_id'] = patient_id
                if current_date_dt:
                    lifecycle_row['dos'] = current_date_dt
                payload = get_claim_lifecycle_display_for_row(
                    lifecycle_row,
                    context=lifecycle_context,
                    config=config,
                    state_max=9,
                    detail_max=16,
                )
                claim_state_display = payload.get('claim_state_display', claim_state_display)
                claim_detail_display = payload.get('claim_substatus_display', claim_detail_display)
            except Exception:
                pass

        normalized_info.append((
            composite_sort_key,
            display_date,
            str(patient_name or ''),
            str(patient_id or ''),
            display_diagnosis,
            it_code_display,
            remaining_amount_display,
            claim_state_display,
            claim_detail_display
        ))
    
    # Sort so that all entries for a patient are grouped under their earliest date
    normalized_info.sort(key=lambda x: x[0])
    # Calculate column widths for proper alignment
    max_patient_id_len = max(len(r[3]) for r in normalized_info)
    max_patient_name_len = max(len(r[2]) for r in normalized_info)
    max_diagnosis_len = max(len(r[4]) for r in normalized_info)
    max_it_code_len = max(len(r[5]) for r in normalized_info)
    max_remaining_amount_len = max(len(r[6]) for r in normalized_info)
    max_claim_state_len = max(len(r[7]) for r in normalized_info)
    max_claim_detail_len = max(len(r[8]) for r in normalized_info)

    # Ensure minimum widths for readability
    max_patient_id_len = max(max_patient_id_len, 5)  # 5-digit ID max
    max_patient_name_len = max(max_patient_name_len, 12)  # "Patient Name" header
    max_diagnosis_len = max(max_diagnosis_len, 10)  # "Diagnosis" header
    max_it_code_len = max(max_it_code_len, 7)  # "IT Code" header
    max_remaining_amount_len = max(max_remaining_amount_len, 12)  # "Rem Amt" header
    max_claim_state_len = max(max_claim_state_len, 9)  # "CLM State" header
    max_claim_detail_len = max(max_claim_detail_len, 10)  # "CLM Detail" header
    
    # Display header row
    header_format = "{:<3}| {:<6} | {:<" + str(max_patient_id_len) + "} | {:<" + str(max_patient_name_len) + "} | {:<" + str(max_diagnosis_len) + "} | {:<" + str(max_it_code_len) + "} | {:<" + str(max_remaining_amount_len) + "} | {:<" + str(max_claim_state_len) + "} | {:<" + str(max_claim_detail_len) + "}"
    print(header_format.format("No.", "Date", "ID", "Name", "Diagnosis", "IT Code", "Rem Amt", "CLM State", "CLM Detail"))
    print("-" * len(header_format.format("No.", "Date", "ID", "Name", "Diagnosis", "IT Code", "Rem Amt", "CLM State", "CLM Detail")))
    
    current_patient = None
    line_number = 1
    
    for sort_key, formatted_date, patient_name, patient_id, display_diagnosis, it_code_display, remaining_amount_display, claim_state_display, claim_detail_display in normalized_info:
        if current_patient == patient_id:
            patient_id_dashes = '-' * len(patient_id)
            patient_name_dashes = '-' * len(patient_name)
            it_code_dashes = '-' * len(it_code_display)
            remaining_amount_dashes = '-' * len(remaining_amount_display)
            secondary_format = "     {:<6} | {:<" + str(max_patient_id_len) + "} | {:<" + str(max_patient_name_len) + "} | {:<" + str(max_diagnosis_len) + "} | {:<" + str(max_it_code_len) + "} | {:<" + str(max_remaining_amount_len) + "} | {:<" + str(max_claim_state_len) + "} | {:<" + str(max_claim_detail_len) + "}"
            claim_state_dashes = '-' * len(claim_state_display)
            claim_detail_dashes = '-' * len(claim_detail_display)
            print(secondary_format.format(formatted_date, patient_id_dashes, patient_name_dashes, display_diagnosis, it_code_dashes, remaining_amount_dashes, claim_state_dashes, claim_detail_dashes))
        else:
            current_patient = patient_id
            if show_line_numbers:
                primary_format = "{:03d}: {:<6} | {:<" + str(max_patient_id_len) + "} | {:<" + str(max_patient_name_len) + "} | {:<" + str(max_diagnosis_len) + "} | {:<" + str(max_it_code_len) + "} | {:<" + str(max_remaining_amount_len) + "} | {:<" + str(max_claim_state_len) + "} | {:<" + str(max_claim_detail_len) + "}"
                print(primary_format.format(line_number, formatted_date, patient_id, patient_name, display_diagnosis, it_code_display, remaining_amount_display, claim_state_display, claim_detail_display))
                line_number += 1
            else:
                primary_format = "     {:<6} | {:<" + str(max_patient_id_len) + "} | {:<" + str(max_patient_name_len) + "} | {:<" + str(max_diagnosis_len) + "} | {:<" + str(max_it_code_len) + "} | {:<" + str(max_remaining_amount_len) + "} | {:<" + str(max_claim_state_len) + "} | {:<" + str(max_claim_detail_len) + "}"
                print(primary_format.format(formatted_date, patient_id, patient_name, display_diagnosis, it_code_display, remaining_amount_display, claim_state_display, claim_detail_display))

    if build_claim_lifecycle_mini_runbook_lines:
        try:
            for _line in build_claim_lifecycle_mini_runbook_lines():
                print(_line)
        except Exception:
            pass

    def enrich_single_row(row_tuple, minutes_value, patient_row_dict):
        """Merge entered minutes into patient row dict for interactive prototype."""
        out = {}
        if isinstance(patient_row_dict, dict):
            out.update(patient_row_dict)
        if len(row_tuple) >= 4:
            out['Surgery Date'] = row_tuple[0]
            out['Patient Name'] = row_tuple[1]
            out['Patient ID #2'] = row_tuple[2]
            out['Diagnosis Code'] = row_tuple[3]
        out['Minutes'] = minutes_value
        return out

    if interactive:
        for i in range(len(patient_info)):
            # Redraw table up to current row (prototype: simple print)
            print("\n" + title)
            print("|" + "-" * 80 + "|")  # ASCII table border
            print("| Date | Name | ID | Diagnosis | Minutes | Deductible | Charge | Flags |")
            print("|" + "-" * 80 + "|")

            # Print previous rows (enriched)
            for j in range(i):
                r = patient_info[j]
                row_d = r[4] if len(r) > 4 and isinstance(r[4], dict) else {}
                print("| {} | {} | {} | {} | {} | {} | {} | {} |".format(
                    r[0], r[1][:10], r[2], r[3],
                    row_d.get('Minutes', ''),
                    row_d.get('Deductible', 'N/A'),
                    row_d.get('Charge', ''),
                    row_d.get('Flags', '')))

            # Prompt for current row
            current = patient_info[i]
            cur_row = current[4] if len(current) > 4 and isinstance(current[4], dict) else {}
            print("| {} | {} | {} | {} | [Input] | {} |        |               |".format(
                current[0], current[1][:10], current[2], current[3], cur_row.get('Deductible', 'N/A')))  # Highlight Minutes column

            while True:
                try:
                    minutes_str = input("Enter Minutes (1-59): ")
                    minutes = int(minutes_str)
                    if minutes > 59:
                        minutes = 59
                        confirm = input("Capped to 59. Proceed? (Y/N): ").upper()
                        if confirm != 'Y': continue
                    if 1 <= minutes <= 59: break
                    print("Invalid: 1-59 only.")
                except ValueError:
                    print("Invalid: Enter number.")

            # Enrich and update row (use cur_row — same safe index as lines 278/288, not raw [4])
            enriched_row = enrich_single_row(current, minutes, cur_row)
            patient_info[i] = (enriched_row['Surgery Date'], enriched_row['Patient Name'], enriched_row['Patient ID #2'], enriched_row['Diagnosis Code'], enriched_row)  # Update tuple

            # Redraw full table after update
            # (Repeat print logic above with all rows up to i)

        return patient_info  # Enriched

# Function to check if a specific key is pressed
def _get_vk_codes():
    """Get VK codes from config."""
    config, _ = _get_config()
    VK_END = int(config.get('VK_END', "23"), 16)  # Default to 23 if not in config
    VK_PAUSE = int(config.get('VK_PAUSE', "24"), 16)  # Default to 24 if not in config
    return VK_END, VK_PAUSE



class AppControl:
    def __init__(self):
        self.script_paused = False
        self.mapat_med_path = ''
        self.medisoft_shortcut = ''
        # PERFORMANCE FIX: Add configuration caching to reduce lookup overhead
        self._config_cache = {}  # Cache for Medicare vs Private configuration lookups
        # Load initial paths from config when instance is created
        try:
            self.load_paths_from_config()
        except Exception:
            # Defer configuration loading until first access if config is unavailable
            self._deferred_load = True
        else:
            self._deferred_load = False

    def get_pause_status(self):
        return self.script_paused

    def set_pause_status(self, status):
        self.script_paused = status

    def get_mapat_med_path(self):
        return self.mapat_med_path

    def set_mapat_med_path(self, path):
        self.mapat_med_path = path

    def get_medisoft_shortcut(self):
        return self.medisoft_shortcut

    def set_medisoft_shortcut(self, path):
        self.medisoft_shortcut = path

    def load_paths_from_config(self, medicare=False):
        # Load configuration when needed
        config, _ = _get_config()
        
        # PERFORMANCE FIX: Cache configuration lookups to reduce Medicare vs Private overhead
        cache_key = 'medicare' if medicare else 'private'
        
        if cache_key not in self._config_cache:
            # Build cache entry for this configuration type
            if medicare:
                cached_config = {
                    'mapat_path': config.get('MEDICARE_MAPAT_MED_PATH', ""),
                    'shortcut': config.get('MEDICARE_SHORTCUT', "")
                }
            else:
                cached_config = {
                    'mapat_path': config.get('MAPAT_MED_PATH', ""),
                    'shortcut': config.get('PRIVATE_SHORTCUT', "")
                }
            self._config_cache[cache_key] = cached_config
        
        # Use cached values to avoid repeated config lookups
        cached = self._config_cache[cache_key]
        self.mapat_med_path = cached['mapat_path']
        self.medisoft_shortcut = cached['shortcut']

def _get_app_control():
    global app_control
    ac = app_control
    if ac is None:
        ac = AppControl()
    # If deferred, attempt first load now
    try:
        if getattr(ac, '_deferred_load', False):
            ac.load_paths_from_config()
            ac._deferred_load = False
    except Exception:
        pass
    globals()['app_control'] = ac
    return ac

# Lazily filled by _get_app_control(); None until first access (avoid NameError probes for static analysis)
app_control = None


def is_key_pressed(key_code):
    user32 = ctypes.WinDLL('user32', use_last_error=True)
    user32.GetAsyncKeyState.restype = wintypes.SHORT
    user32.GetAsyncKeyState.argtypes = [wintypes.INT]
    return user32.GetAsyncKeyState(key_code) & 0x8000 != 0

def manage_script_pause(csv_data, error_message, reverse_mapping):
    user_action = 0 # initialize as 'continue'
    VK_END, VK_PAUSE = _get_vk_codes()
    
    ac = _get_app_control()
    if not ac.get_pause_status() and is_key_pressed(VK_PAUSE):
        ac.set_pause_status(True)
        print("Script paused. Opening menu...")
        interaction_mode = 'normal'  # Assuming normal interaction mode for script pause
        user_action = user_interaction(csv_data, interaction_mode, error_message, reverse_mapping)
    
    while ac.get_pause_status():
        if is_key_pressed(VK_END):
            ac.set_pause_status(False)
            print("Continuing...")
        elif is_key_pressed(VK_PAUSE):
            user_action = user_interaction(csv_data, 'normal', error_message, reverse_mapping)
        time.sleep(0.1)
    
    return user_action

# Menu Display & User Interaction
def display_patient_selection_menu(csv_data, reverse_mapping, proceed_as_medicare):
    selected_patient_ids = []
    selected_indices = []

    # TODO: Future enhancement - make this configurable via config file
    # Example: config.get('silent_initial_selection', True)
    SILENT_INITIAL_SELECTION = True  # Set to False to restore original interactive behavior

    def display_menu_header(title):
        print("\n" + "-" * 60)
        print(title)
        print("-" * 60)

    def display_patient_list(csv_data, reverse_mapping, medicare_filter=False, exclude_medicare=False):
        medicare_policy_pattern = r"^[a-zA-Z0-9]{11}$"  # Regex pattern for 11 alpha-numeric characters
        primary_policy_number_header = reverse_mapping.get('Primary Policy Number', 'Primary Policy Number')
        primary_insurance_header = reverse_mapping.get('Primary Insurance', 'Primary Insurance')  # Adjust field name as needed
        
        displayed_indices = []
        displayed_patient_ids = []

        for index, row in enumerate(csv_data):
            policy_number = row.get(primary_policy_number_header, "")
            primary_insurance = row.get(primary_insurance_header, "").upper()
            
            if medicare_filter and (not re.match(medicare_policy_pattern, policy_number) or "MEDICARE" not in primary_insurance):
                continue
            if exclude_medicare and re.match(medicare_policy_pattern, policy_number) and "MEDICARE" in primary_insurance:
                continue

            patient_id_header = reverse_mapping['Patient ID #2']
            patient_name_header = reverse_mapping['Patient Name']
            patient_id = row.get(patient_id_header, "N/A")
            patient_name = row.get(patient_name_header, "Unknown")
            surgery_date = row.get('Surgery Date', "Unknown Date")
            # Format surgery_date safely whether datetime/date or string
            try:
                formatted_date = surgery_date.strftime('%m-%d')
            except Exception:
                formatted_date = str(surgery_date)
            
            # Only display if not in silent mode
            if not SILENT_INITIAL_SELECTION:
                print("{0:03d}: {3} (ID: {2}) {1} ".format(index+1, patient_name, patient_id, formatted_date))

            displayed_indices.append(index)
            displayed_patient_ids.append(patient_id)

        return displayed_indices, displayed_patient_ids

    if proceed_as_medicare:
        if not SILENT_INITIAL_SELECTION:
            display_menu_header("MEDICARE Patient Selection for Today's Data Entry")
        selected_indices, selected_patient_ids = display_patient_list(csv_data, reverse_mapping, medicare_filter=True)
    else:
        if not SILENT_INITIAL_SELECTION:
            display_menu_header("PRIVATE Patient Selection for Today's Data Entry")
        selected_indices, selected_patient_ids = display_patient_list(csv_data, reverse_mapping, exclude_medicare=True)

    if not SILENT_INITIAL_SELECTION:
        print("-" * 60)
        proceed = input("\nDo you want to proceed with the selected patients? (yes/no): ").lower().strip() in ['yes', 'y']
    else:
        # Auto-confirm in silent mode
        proceed = True

    if not proceed:
        if not SILENT_INITIAL_SELECTION:
            display_menu_header("Patient Selection for Today's Data Entry")
            selected_indices, selected_patient_ids = display_patient_list(csv_data, reverse_mapping)
            print("-" * 60)
            
            while True:
                while True:
                    selection = input("\nEnter the number(s) of the patients you wish to proceed with\n(e.g., 1, 3, 5): ").strip()
                    if not selection:
                        print("Invalid entry. Please provide at least one number.")
                        continue
                    
                    selection = selection.replace('.', ',')  # Replace '.' with ',' in the user input just in case
                    selected_indices = [int(x.strip()) - 1 for x in selection.split(',') if x.strip().isdigit()]  
                    
                    if not selected_indices:
                        print("Invalid entry. Please provide at least one integer.")
                        continue
                    
                    proceed = True
                    break
                
                if not selection:
                    print("Invalid entry. Please provide at least one number.")
                    continue
                
                selection = selection.replace('.', ',')  # Replace '.' with ',' in the user input just in case
                selected_indices = [int(x.strip()) - 1 for x in selection.split(',') if x.strip().isdigit()]  
                
                if not selected_indices:
                    print("Invalid entry. Please provide at least one integer.")
                    continue
                
                proceed = True
                break

    patient_id_header = reverse_mapping['Patient ID #2']
    selected_patient_ids = [csv_data[i][patient_id_header] for i in selected_indices if i < len(csv_data)]

    return proceed, selected_patient_ids, selected_indices

def display_menu_header(title):
    print("\n" + "-" * 60)
    print(title)
    print("-" * 60)


def _format_option_a_preview_date(value):
    if value is None:
        return ""
    if isinstance(value, datetime):
        if value.hour == 0 and value.minute == 0 and value.second == 0 and value.microsecond == 0:
            return value.strftime("%Y-%m-%d")
        return str(value)
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    text = str(value or "")
    for suffix in (" 00:00:00", "T00:00:00"):
        if text.endswith(suffix):
            return text[:-len(suffix)]
    return text


def _clear_option_a_preview_screen():
    command = "cls" if os.name == "nt" else "clear"
    try:
        os.system(command)
    except Exception:
        # If terminal clear is unavailable, keep the preview usable.
        print("\n" * 3)


SERVICE_LINE_INPUT_PAGE_SIZE = 25
SERVICE_LINE_INPUT_INNER_WIDTH = 98
SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY = "preview_only_review_required"
SERVICE_LINE_INPUT_WORKFLOW_NAME = "service_line_input"

SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS = (
    "claims_completion",
    "mutates_billing_state",
    "mutates_dat",
    "mutates_837p",
    "charges_entered",
)

# SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: old Option A helper names below
# remain as compatibility shims for tests/importers during the rename cycle.
OPTION_A_PREVIEW_PAGE_SIZE = SERVICE_LINE_INPUT_PAGE_SIZE
OPTION_A_PREVIEW_INNER_WIDTH = SERVICE_LINE_INPUT_INNER_WIDTH


def _service_line_input_patient_row_value(patient_row, keys, default=""):
    if not isinstance(patient_row, dict):
        return default
    for key in keys:
        if key in patient_row and patient_row.get(key) is not None and patient_row.get(key) != "":
            return patient_row.get(key)
    return default


def _option_a_charge_context(row):
    return {
        "patient_id": row.get("patient_id") or "",
        "dos": row.get("date") or "",
        "diagnosis": row.get("diagnosis") or "",
        "diagnosis_source": row.get("diagnosis_source") or "",
        "cpt": row.get("cpt") or "",
        "cpt_source": row.get("cpt_source") or "",
        "minutes": row.get("minutes") or "",
        "status": row.get("status") or "",
        "same_patient_anchor_charge_amount": row.get("same_patient_anchor_charge_amount") or "",
        "same_patient_anchor_charge_display": row.get("same_patient_anchor_charge_display") or "",
        "same_patient_anchor_charge_rule_id": row.get("same_patient_anchor_charge_rule_id") or "",
        "same_patient_anchor_charge_note": row.get("same_patient_anchor_charge_note") or "",
        "source": row.get("source") or {},
    }


def _apply_option_a_charge_result(row, charge_calculator=None):
    calculator = charge_calculator or calculate_service_line_amount_result
    if calculator is None:
        row["charge_display"] = str(row.get("charge_display") or "PEND")
        row["charge_note"] = str(row.get("charge_note") or "charge helper unavailable")
        row["charge_amount"] = str(row.get("charge_amount") or "")
        row["charge_rule_id"] = str(row.get("charge_rule_id") or "charge_helper_unavailable")
        row["charge_status"] = str(row.get("charge_status") or "pending")
        row["workflow_name"] = SERVICE_LINE_INPUT_WORKFLOW_NAME
        row["workflow_boundary"] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
        for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
            row[false_key] = False
        return
    try:
        result = calculator(_option_a_charge_context(row))
    except Exception:
        result = {}
    if not isinstance(result, dict):
        result = {}
    if not result and calculate_service_line_amount_result is not None:
        result = calculate_service_line_amount_result(_option_a_charge_context(row))
        result["charge_note"] = "charge helper fallback"
        result["charge_rule_id"] = "charge_helper_error"
    if result.get("cpt"):
        row["cpt"] = str(result.get("cpt") or "")
    row["charge_display"] = str(result.get("charge_display") or result.get("charge_amount_display") or "")
    row["charge_amount"] = str(result.get("charge_amount") or "")
    row["charge_note"] = str(result.get("charge_note") or "")
    row["charge_rule_id"] = str(result.get("charge_rule_id") or "")
    row["charge_status"] = str(result.get("charge_status") or "")
    for key in (
        "schema_version",
        "charge_schema_version",
        "charge_source",
        "workflow_name",
        "workflow_boundary",
        "claims_completion",
        "mutates_billing_state",
        "mutates_dat",
        "mutates_837p",
        "charges_entered",
        "billable",
        "requires_operator_review",
        "minutes_normalized",
        "minutes_valid",
        "cpt_source",
        "cpt_confidence",
        "cpt_status",
    ):
        if key in result:
            row[key] = result.get(key)
    row["workflow_name"] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row["workflow_boundary"] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
    for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
        row[false_key] = False
    _clear_baseline_charge_note(row)


def _clear_baseline_charge_note(row):
    if not isinstance(row, dict):
        return
    note = str(row.get("charge_note") or "").strip().lower()
    rule_id = str(row.get("charge_rule_id") or "").strip().lower()
    source = str(row.get("charge_source") or "").strip().lower()
    if note.startswith("baseline ") or rule_id.startswith("baseline_") or source == "baseline_minutes_tier":
        row["charge_note"] = ""


def _sanitize_service_line_input_preview_row(row):
    if ServiceLineInputModel is not None:
        try:
            out = ServiceLineInputModel.sanitize_service_line_preview_row(row)
            for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
                out[false_key] = False
            return out
        except Exception:
            pass
    if not isinstance(row, dict):
        row = {}
    out = dict(row)
    for key in (
            "charges_entered",
            "claim_submitted",
            "claim_workflow_completion",
            "dat_mutation",
            "dat_write",
            "mutates_dat",
            "x12_837p_mutation",
            "837p_mutation",
            "837p_write",
            "mutates_837p",
            "billing_state_mutation"):
        if key in out:
            del out[key]
    out["workflow_name"] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    out["workflow_boundary"] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
    for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
        out[false_key] = False
    return out


def _shape_service_line_input_effective_row(row):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.resolve_effective_service_line_row(
                docx_row=row,
                fallback=row,
                target_identity=row.get("source") or row,
            )
        except Exception:
            try:
                return ServiceLineInputModel.shape_effective_service_line_row(
                    row,
                    target_identity=row.get("source") or row,
                )
            except Exception:
                pass
    return row


def _ensure_service_line_input_row_defaults(row):
    if not isinstance(row, dict):
        row = {}
    defaults = {
        "index": 0,
        "date": "",
        "name": "Unknown",
        "patient_id": "",
        "diagnosis": "-Not Found-",
        "diagnosis_code": "",
        "diagnosis_source": "docx_observation",
        "cpt": "",
        "cpt_code": "",
        "minutes": "",
        "status": "PENDING",
        "auto_skip": False,
        "status_reason": "",
        "source": {},
        "charge_display": "",
        "charge_amount": "",
        "charge_note": "",
        "charge_rule_id": "",
        "charge_status": "",
        "charge_schema_version": "",
        "charge_source": "",
        "cpt_source": "",
        "cpt_confidence": None,
        "cpt_status": "",
        "diagnosis_options": [],
        "cpt_options": [],
        "same_patient_anchor_charge_amount": "",
        "same_patient_anchor_charge_display": "",
        "same_patient_anchor_charge_rule_id": "",
        "same_patient_anchor_charge_note": "",
    }
    for key, value in defaults.items():
        if key not in row or row.get(key) is None:
            row[key] = value
    return row


def _service_line_input_context_footer(rows):
    messages = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        source = row.get("source") if isinstance(row.get("source"), dict) else {}
        message = str(source.get("docx_context_message") or "").strip()
        if message and message not in messages:
            messages.append(message)
        if len(messages) >= 2:
            break
    return " ".join(messages)


def _option_a_cpt_from_patient_row(patient_row):
    if not isinstance(patient_row, dict):
        return ""
    for key in (
        "_service_line_input_cpt",
        "_service_line_input_cpt_code",
        "_service_line_input_procedure_code",
        "_option_a_preview_cpt",
        "_option_a_preview_cpt_code",
        "_option_a_preview_procedure_code",
        "CPT",
        "CPT Code",
        "Procedure Code",
    ):
        value = patient_row.get(key)
        if value:
            return str(value)
    return ""


def _reset_option_a_row_for_edit(row, charge_calculator=None):
    row["status"] = "PENDING"
    row["minutes"] = ""
    row["auto_skip"] = False
    _apply_option_a_charge_result(row, charge_calculator)


def _normalize_service_line_input_code(value):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.normalize_service_line_code(value)
        except Exception:
            pass
    out = []
    for ch in str(value or "").upper():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def _option_list_from_value(value):
    if isinstance(value, (list, tuple)):
        return [str(item).strip() for item in value if str(item).strip()]
    text = str(value or "").strip()
    if not text:
        return []
    if "," in text:
        return [part.strip() for part in text.split(",") if part.strip()]
    return [text]


def _option_a_allowed_values(row, row_key, global_options):
    values = []
    for option in _option_list_from_value(global_options):
        if option not in values:
            values.append(option)
    for option in _option_list_from_value(row.get(row_key)):
        if option not in values:
            values.append(option)
    return values


def _option_value_is_allowed(value, allowed_values):
    if not allowed_values:
        return True
    normalized = _normalize_service_line_input_code(value)
    for option in allowed_values:
        if _normalize_service_line_input_code(option) == normalized:
            return True
    return False


def _service_line_input_format_diagnosis_display(value):
    text = str(value or "").strip().upper()
    normalized = _normalize_service_line_input_code(text)
    if normalized and len(normalized) > 3 and normalized[0].isalpha():
        return "{0}.{1}".format(normalized[:3], normalized[3:])
    return text


def _service_line_input_diagnosis_display(value, diagnosis_display_map=None):
    normalized = _normalize_service_line_input_code(value)
    if normalized and isinstance(diagnosis_display_map, dict):
        mapped = diagnosis_display_map.get(normalized)
        if mapped:
            return _service_line_input_format_diagnosis_display(mapped)
    return _service_line_input_format_diagnosis_display(value)


def _set_service_line_input_diagnosis(row, value, diagnosis_display_map=None,
                                      source="operator_overlay"):
    raw_value = str(value or "").strip()
    display_value = _service_line_input_diagnosis_display(raw_value, diagnosis_display_map)
    row["diagnosis_raw_value"] = raw_value.upper()
    row["diagnosis"] = display_value
    row["diagnosis_code"] = display_value
    row["diagnosis_source"] = source
    if raw_value and display_value != raw_value.upper():
        row["diagnosis_display_source"] = "crosswalk.diagnosis_to_medisoft"


def _apply_service_line_input_intake_result(row, result, diagnosis_display_map=None):
    if not isinstance(result, dict) or not result.get("ok"):
        return result.get("message") if isinstance(result, dict) else "Crosswalk intake did not complete."
    updates = result.get("row_updates")
    if not isinstance(updates, dict):
        updates = {}
    diagnosis = updates.get("diagnosis") or updates.get("diagnosis_code")
    if diagnosis:
        _set_service_line_input_diagnosis(
            row,
            diagnosis,
            diagnosis_display_map=diagnosis_display_map,
            source=updates.get("diagnosis_source") or "operator_crosswalk_intake",
        )
    if updates.get("diagnosis_raw_value"):
        row["diagnosis_raw_value"] = str(updates.get("diagnosis_raw_value") or "").strip().upper()
    for key in (
            "cpt",
            "cpt_code",
            "cpt_source",
            "cpt_confidence",
            "cpt_status",
            "validation_status",
            "validation_note",
            "crosswalk_intake_save_ok",
            "crosswalk_intake_message"):
        if key in updates:
            row[key] = updates.get(key)
    events = result.get("crosswalk_intake_events")
    if isinstance(events, list):
        existing = row.get("crosswalk_intake_events")
        if not isinstance(existing, list):
            existing = []
        existing.extend(events)
        row["crosswalk_intake_events"] = existing
    return result.get("message") or "Crosswalk updated for this Service Line Input row."


def _display_option_values(label, allowed_values):
    if allowed_values:
        print("{0} options: {1}".format(label, ", ".join(allowed_values[:20])))


def _edit_option_a_diagnosis(row, diagnosis_options=None, charge_calculator=None, direct_value=None,
                             diagnosis_display_map=None, crosswalk_intake_handler=None):
    allowed_values = _option_a_allowed_values(row, "diagnosis_options", diagnosis_options)
    if direct_value is None:
        _display_option_values("Diagnosis", allowed_values)
        direct_value = input("Enter diagnosis code (blank keeps current): ")
    value = str(direct_value or "").strip()
    if not value:
        return ""
    unknown_value = not _option_value_is_allowed(value, allowed_values)
    if unknown_value or (crosswalk_intake_handler is not None and not allowed_values):
        if crosswalk_intake_handler is None:
            return "Invalid diagnosis. Choose one of the listed diagnosis codes."
        result = crosswalk_intake_handler(row, "diagnosis", value)
        message = _apply_service_line_input_intake_result(row, result, diagnosis_display_map)
        if isinstance(result, dict) and result.get("ok"):
            _apply_option_a_charge_result(row, charge_calculator)
        return message
    old_cpt_source = str(row.get("cpt_source") or "").strip()
    _set_service_line_input_diagnosis(
        row,
        value,
        diagnosis_display_map=diagnosis_display_map,
        source="operator_overlay",
    )
    row["validation_status"] = "review_required"
    row["validation_note"] = "diagnosis edited in Service Line Input"
    if old_cpt_source != "operator_overlay":
        row["cpt"] = ""
        row["cpt_source"] = ""
        row["cpt_confidence"] = ""
        row["cpt_status"] = ""
    _apply_option_a_charge_result(row, charge_calculator)
    return "Diagnosis updated for review."


def _edit_option_a_cpt(row, cpt_options=None, charge_calculator=None, direct_value=None,
                       diagnosis_display_map=None, crosswalk_intake_handler=None):
    allowed_values = _option_a_allowed_values(row, "cpt_options", cpt_options)
    if direct_value is None:
        _display_option_values("CPT", allowed_values)
        direct_value = input("Enter CPT code (blank keeps current): ")
    value = str(direct_value or "").strip()
    if not value:
        return ""
    unknown_value = not _option_value_is_allowed(value, allowed_values)
    if unknown_value or (crosswalk_intake_handler is not None and not allowed_values):
        if crosswalk_intake_handler is None:
            return "Invalid CPT. Choose one of the listed CPT codes."
        result = crosswalk_intake_handler(row, "cpt", value)
        message = _apply_service_line_input_intake_result(row, result, diagnosis_display_map)
        if isinstance(result, dict) and result.get("ok"):
            _apply_option_a_charge_result(row, charge_calculator)
        return message
    row["cpt"] = value.upper()
    row["cpt_code"] = row["cpt"]
    row["cpt_source"] = "operator_overlay"
    row["cpt_confidence"] = "operator_confirmed"
    row["cpt_status"] = "operator_corrected"
    row["validation_status"] = "review_required"
    row["validation_note"] = "CPT edited in Service Line Input"
    _apply_option_a_charge_result(row, charge_calculator)
    return "CPT updated for review."


def _option_a_invalid_minutes_message():
    return "Invalid input. Enter minutes 5-59, 0 to cancel, q/b/s, dx=<code>, or cpt=<code>."


def _process_option_a_entry_value(rows, pos, value, charge_calculator=None,
                                  diagnosis_options=None, cpt_options=None,
                                  diagnosis_display_map=None,
                                  crosswalk_intake_handler=None):
    val = str(value or "").strip()
    if not val:
        return {"pos": pos, "quit": False, "advanced": False, "message": "Please enter minutes or a command."}
    low = val.lower()
    if low == 'q':
        return {"pos": pos, "quit": True, "advanced": False, "message": ""}
    if low == 'b':
        if pos > 0:
            pos -= 1
        return {"pos": pos, "quit": False, "advanced": False, "message": ""}
    if low == 's':
        rows[pos]["minutes"] = ""
        rows[pos]["status"] = "SKIPPED"
        _apply_option_a_charge_result(rows[pos], charge_calculator)
        return {"pos": pos + 1, "quit": False, "advanced": True, "message": ""}
    if low in ('d', 'dx'):
        message = _edit_option_a_diagnosis(
            rows[pos],
            diagnosis_options,
            charge_calculator,
            diagnosis_display_map=diagnosis_display_map,
            crosswalk_intake_handler=crosswalk_intake_handler,
        )
        return {"pos": pos, "quit": False, "advanced": False, "message": message}
    if low.startswith('dx=') or low.startswith('diag=') or low.startswith('dx ') or low.startswith('diag '):
        separator = '=' if '=' in val else ' '
        direct_value = val.split(separator, 1)[1]
        message = _edit_option_a_diagnosis(
            rows[pos],
            diagnosis_options,
            charge_calculator,
            direct_value,
            diagnosis_display_map=diagnosis_display_map,
            crosswalk_intake_handler=crosswalk_intake_handler,
        )
        return {"pos": pos, "quit": False, "advanced": False, "message": message}
    if low in ('c', 'cpt'):
        message = _edit_option_a_cpt(
            rows[pos],
            cpt_options,
            charge_calculator,
            diagnosis_display_map=diagnosis_display_map,
            crosswalk_intake_handler=crosswalk_intake_handler,
        )
        return {"pos": pos, "quit": False, "advanced": False, "message": message}
    if low.startswith('cpt=') or low.startswith('cpt '):
        separator = '=' if '=' in val else ' '
        direct_value = val.split(separator, 1)[1]
        message = _edit_option_a_cpt(
            rows[pos],
            cpt_options,
            charge_calculator,
            direct_value,
            diagnosis_display_map=diagnosis_display_map,
            crosswalk_intake_handler=crosswalk_intake_handler,
        )
        return {"pos": pos, "quit": False, "advanced": False, "message": message}
    if val == '0':
        rows[pos]["minutes"] = ""
        rows[pos]["status"] = "CANCELLED"
        _apply_option_a_charge_result(rows[pos], charge_calculator)
        return {"pos": pos + 1, "quit": False, "advanced": True, "message": ""}
    if not val.isdigit():
        return {"pos": pos, "quit": False, "advanced": False, "message": _option_a_invalid_minutes_message()}
    minutes = int(val)
    if minutes < 5 or minutes > 59:
        return {"pos": pos, "quit": False, "advanced": False, "message": _option_a_invalid_minutes_message()}
    rows[pos]["minutes"] = str(minutes)
    rows[pos]["status"] = "ENTERED"
    _apply_option_a_charge_result(rows[pos], charge_calculator)
    return {"pos": pos + 1, "quit": False, "advanced": True, "message": ""}


def _render_option_a_preview_table(rows, pos, date_of_service_label=None, show_prompt=True, footer_message=""):
    if not rows:
        return
    if pos < 0:
        pos = 0
    if pos >= len(rows):
        pos = len(rows) - 1
    header_dos = _format_option_a_preview_date(date_of_service_label or rows[pos].get("date")) or "Unknown"
    page_size = SERVICE_LINE_INPUT_PAGE_SIZE
    use_pages = len(rows) > page_size
    page_index = pos // page_size
    page_start = page_index * page_size
    page_end = min(page_start + page_size, len(rows))
    page_count = (len(rows) + page_size - 1) // page_size
    _clear_option_a_preview_screen()
    inner_width = SERVICE_LINE_INPUT_INNER_WIDTH
    print("+" + "-" * inner_width + "+")
    print("| MediLink Service Line Input".ljust(inner_width + 1) + "|")
    print("| DOS: {}".format(header_dos).ljust(inner_width + 1) + "|")
    if use_pages:
        print("| Page {0} of {1} - showing patients {2}-{3} of {4}".format(
            page_index + 1,
            page_count,
            page_start + 1,
            page_end,
            len(rows),
        ).ljust(inner_width + 1) + "|")
    print("+" + "-" * inner_width + "+")
    print("| #   Patient Name                 Diagnosis   CPT   Minutes   CHARGE     NOTE".ljust(inner_width + 1) + "|")
    print("|" + "-" * inner_width + "|")
    for row in rows[page_start:page_end]:
        marker = ">" if show_prompt and row["index"] == pos + 1 else " "
        line = "{0}{1:>2}  {2:<27}  {3:<10}  {4:<5} {5:<7} {6:<9} {7}".format(
            marker,
            row["index"],
            row["name"][:27],
            row["diagnosis"][:10],
            str(row.get("cpt") or "____")[:5],
            str(row["minutes"] or "____")[:7],
            str(row.get("charge_display") or "PENDING")[:9],
            str(row.get("charge_note") or "")[:24],
        )
        print("| " + line.ljust(inner_width - 2) + " |")
    print("+" + "-" * inner_width + "+")
    if use_pages:
        print("Showing patients {0}-{1} of {2}; pages advance automatically.".format(
            page_start + 1,
            page_end,
            len(rows),
        ))
    if footer_message:
        print(footer_message)
    if show_prompt:
        print("Enter minutes 5-59 for patient {0} of {1} (dx=<code>, cpt=<code>, q=quit, b=back, s=skip, 0=cancelled):".format(pos + 1, len(rows)))
    else:
        print("No pending patients remain for this DOS.")
        print("Press Enter to accept, enter row number to edit minutes, '<row> dx=<code>', '<row> cpt=<code>', or q.")


def _handle_option_a_completed_table_choice(rows, charge_calculator=None,
                                            diagnosis_options=None, cpt_options=None,
                                            diagnosis_display_map=None,
                                            crosswalk_intake_handler=None):
    raw_choice = (input("> ") or "").strip()
    choice = raw_choice.lower()
    if not choice:
        return ("accept", None)
    if choice == "q":
        return ("quit", None)
    parts = raw_choice.split(None, 1)
    if len(parts) == 2 and parts[0].isdigit():
        idx = int(parts[0]) - 1
        if idx >= 0 and idx < len(rows):
            field_choice = parts[1].strip()
            field_low = field_choice.lower()
            if field_low.startswith('dx=') or field_low.startswith('diag=') or field_low.startswith('dx ') or field_low.startswith('diag '):
                separator = '=' if '=' in field_choice else ' '
                message = _edit_option_a_diagnosis(
                    rows[idx],
                    diagnosis_options,
                    charge_calculator,
                    field_choice.split(separator, 1)[1],
                    diagnosis_display_map=diagnosis_display_map,
                    crosswalk_intake_handler=crosswalk_intake_handler,
                )
                if message:
                    print(message)
                return ("retry", None)
            if field_low.startswith('cpt=') or field_low.startswith('cpt '):
                separator = '=' if '=' in field_choice else ' '
                message = _edit_option_a_cpt(
                    rows[idx],
                    cpt_options,
                    charge_calculator,
                    field_choice.split(separator, 1)[1],
                    diagnosis_display_map=diagnosis_display_map,
                    crosswalk_intake_handler=crosswalk_intake_handler,
                )
                if message:
                    print(message)
                return ("retry", None)
    if raw_choice.isdigit():
        idx = int(raw_choice) - 1
        if idx >= 0 and idx < len(rows):
            _reset_option_a_row_for_edit(rows[idx], charge_calculator)
            return ("edit", idx)
    print("Invalid entry. Press Enter to accept, enter a row number, '<row> dx=<code>', '<row> cpt=<code>', or q.")
    return ("retry", None)


def run_service_line_input_entry(patient_info, date_of_service_label=None, charge_calculator=None,
                                 diagnosis_options=None, cpt_options=None, diagnosis_display_map=None,
                                 crosswalk_intake_handler=None):
    """
    XP-safe Service Line Input UI for review-only 837P line evidence.

    Args:
        patient_info: List of tuples (surgery_date, patient_name, patient_id, diagnosis_code, patient_row)
        date_of_service_label: Optional DOS label for header display

    Returns:
        dict summary with counts for entered/skipped/cancelled, plus per-row statuses.
    """
    rows = []
    idx = 0
    for item in patient_info or []:
        if not isinstance(item, tuple) or len(item) < 4:
            continue
        idx += 1
        surgery_date = item[0]
        patient_name = item[1]
        diagnosis_code = item[3]
        patient_row = item[4] if len(item) > 4 and isinstance(item[4], dict) else {}
        name = str(patient_name or "Unknown")
        diag = str(_service_line_input_patient_row_value(patient_row, (
            "_service_line_input_diagnosis",
            "_option_a_preview_diagnosis",
            "_service_line_input_diagnosis_code",
            "_option_a_preview_diagnosis_code",
        ), diagnosis_code or "-Not Found-"))
        if diag.strip() == "":
            diag = "-Not Found-"
        display_diag = _service_line_input_diagnosis_display(diag, diagnosis_display_map)
        status = str(_service_line_input_patient_row_value(patient_row, (
            "_service_line_input_status",
            "_option_a_preview_status",
        ), "PENDING")).strip().upper()
        if status not in ("PENDING", "ENTERED", "SKIPPED", "CANCELLED", "INVALID"):
            status = "PENDING"
        auto_skip = status != "PENDING"
        minutes_value = ""
        if status == "ENTERED":
            minutes_value = str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_minutes",
                "_option_a_preview_minutes",
            ), ""))
        row = {
            "index": idx,
            "date": str(surgery_date or ""),
            "name": name,
            "patient_id": str(item[2] or "") if len(item) > 2 else "",
            "diagnosis": display_diag,
            "diagnosis_code": display_diag,
            "diagnosis_raw_value": str(diag or "").strip().upper(),
            "diagnosis_display_source": (
                "crosswalk.diagnosis_to_medisoft"
                if str(display_diag or "").strip().upper() != str(diag or "").strip().upper()
                else ""
            ),
            "diagnosis_source": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_diagnosis_source",
                "_option_a_preview_diagnosis_source",
            ), "docx_observation")),
            "diagnosis_options": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_diagnosis_options",
                "_option_a_preview_diagnosis_options",
            ), diagnosis_options or []),
            "cpt": _option_a_cpt_from_patient_row(patient_row),
            "cpt_code": _option_a_cpt_from_patient_row(patient_row),
            "cpt_options": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_cpt_options",
                "_option_a_preview_cpt_options",
            ), cpt_options or []),
            "minutes": minutes_value,
            "status": status,
            "auto_skip": auto_skip,
            "status_reason": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_status_reason",
                "_option_a_preview_status_reason",
            ), "")),
            "source": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_source",
                "_option_a_preview_source",
            ), {}) or {},
            "charge_display": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_charge_display",
                "_service_line_input_amount_display",
                "_option_a_preview_charge_display",
            ), "")),
            "charge_amount": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_charge_amount",
                "_service_line_input_amount",
                "_option_a_preview_charge_amount",
            ), "")),
            "charge_note": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_charge_note",
                "_service_line_input_amount_note",
                "_option_a_preview_charge_note",
            ), "")),
            "charge_rule_id": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_charge_rule_id",
                "_service_line_input_amount_rule_id",
                "_option_a_preview_charge_rule_id",
            ), "")),
            "charge_status": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_charge_status",
                "_service_line_input_amount_status",
                "_option_a_preview_charge_status",
            ), "")),
            "charge_schema_version": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_charge_schema_version",
                "_service_line_input_amount_schema_version",
                "_option_a_preview_charge_schema_version",
            ), "")),
            "charge_source": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_charge_source",
                "_service_line_input_amount_source",
                "_option_a_preview_charge_source",
            ), "")),
            "workflow_name": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_workflow_name",
                "_option_a_preview_workflow_name",
            ), "")),
            "workflow_boundary": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_workflow_boundary",
                "_option_a_preview_workflow_boundary",
            ), "")),
            "claims_completion": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_claims_completion",
                "_option_a_preview_claims_completion",
            ), None),
            "mutates_billing_state": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_mutates_billing_state",
                "_option_a_preview_mutates_billing_state",
            ), None),
            "billable": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_billable",
                "_option_a_preview_billable",
            ), None),
            "requires_operator_review": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_requires_operator_review",
                "_option_a_preview_requires_operator_review",
            ), None),
            "cpt_source": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_cpt_source",
                "_option_a_preview_cpt_source",
            ), "")),
            "cpt_confidence": _service_line_input_patient_row_value(patient_row, (
                "_service_line_input_cpt_confidence",
                "_option_a_preview_cpt_confidence",
            ), None),
            "cpt_status": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_cpt_status",
                "_option_a_preview_cpt_status",
            ), "")),
            "same_patient_anchor_charge_amount": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_same_patient_anchor_charge_amount",
                "_option_a_preview_same_patient_anchor_charge_amount",
            ), "")),
            "same_patient_anchor_charge_display": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_same_patient_anchor_charge_display",
                "_option_a_preview_same_patient_anchor_charge_display",
            ), "")),
            "same_patient_anchor_charge_rule_id": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_same_patient_anchor_charge_rule_id",
                "_option_a_preview_same_patient_anchor_charge_rule_id",
            ), "")),
            "same_patient_anchor_charge_note": str(_service_line_input_patient_row_value(patient_row, (
                "_service_line_input_same_patient_anchor_charge_note",
                "_option_a_preview_same_patient_anchor_charge_note",
            ), "")),
        }
        row = _ensure_service_line_input_row_defaults(
            _shape_service_line_input_effective_row(row)
        )
        if not row.get("charge_display") or not row.get("charge_note"):
            _apply_option_a_charge_result(row, charge_calculator)
        _clear_baseline_charge_note(row)
        row = _sanitize_service_line_input_preview_row(row)
        rows.append(row)
    if not rows:
        print("No rows available for Service Line Input.")
        return {"entered": 0, "skipped": 0, "cancelled": 0, "rows": []}

    pos = 0
    terminal_table_rendered = False
    quit_requested = False
    context_footer = _service_line_input_context_footer(rows)
    footer_message = ""
    while pos < len(rows):
        while pos < len(rows) and rows[pos].get("auto_skip"):
            pos += 1
        if pos >= len(rows):
            while True:
                _render_option_a_preview_table(rows, 0, date_of_service_label, show_prompt=False, footer_message=footer_message or context_footer)
                footer_message = ""
                terminal_table_rendered = True
                action, edit_pos = _handle_option_a_completed_table_choice(
                    rows,
                    charge_calculator,
                    diagnosis_options=diagnosis_options,
                    cpt_options=cpt_options,
                    diagnosis_display_map=diagnosis_display_map,
                    crosswalk_intake_handler=crosswalk_intake_handler,
                )
                if action == "accept":
                    break
                if action == "quit":
                    quit_requested = True
                    break
                if action == "edit":
                    pos = edit_pos
                    terminal_table_rendered = False
                    break
            if quit_requested or pos >= len(rows):
                break
            continue
        _render_option_a_preview_table(rows, pos, date_of_service_label, show_prompt=True, footer_message=footer_message or context_footer)
        footer_message = ""
        val = input("> ").strip()
        result = _process_option_a_entry_value(
            rows,
            pos,
            val,
            charge_calculator,
            diagnosis_options=diagnosis_options,
            cpt_options=cpt_options,
            diagnosis_display_map=diagnosis_display_map,
            crosswalk_intake_handler=crosswalk_intake_handler,
        )
        if result.get("quit"):
            quit_requested = True
            break
        footer_message = result.get("message") or ""
        pos = result.get("pos", pos)

    if rows and not quit_requested and not terminal_table_rendered:
        pending_rows = [r for r in rows if r.get("status") == "PENDING"]
        if not pending_rows:
            while True:
                _render_option_a_preview_table(rows, len(rows) - 1, date_of_service_label, show_prompt=False, footer_message=footer_message or context_footer)
                footer_message = ""
                action, edit_pos = _handle_option_a_completed_table_choice(
                    rows,
                    charge_calculator,
                    diagnosis_options=diagnosis_options,
                    cpt_options=cpt_options,
                    diagnosis_display_map=diagnosis_display_map,
                    crosswalk_intake_handler=crosswalk_intake_handler,
                )
                if action == "accept":
                    break
                if action == "quit":
                    quit_requested = True
                    break
                if action == "edit":
                    pos = edit_pos
                    while pos < len(rows):
                        _render_option_a_preview_table(rows, pos, date_of_service_label, show_prompt=True, footer_message=footer_message or context_footer)
                        footer_message = ""
                        val = input("> ").strip()
                        result = _process_option_a_entry_value(
                            rows,
                            pos,
                            val,
                            charge_calculator,
                            diagnosis_options=diagnosis_options,
                            cpt_options=cpt_options,
                            diagnosis_display_map=diagnosis_display_map,
                            crosswalk_intake_handler=crosswalk_intake_handler,
                        )
                        if result.get("quit"):
                            quit_requested = True
                            break
                        footer_message = result.get("message") or ""
                        pos = result.get("pos", pos)
                        if result.get("advanced"):
                            break
                        if footer_message:
                            continue
                    if quit_requested:
                        break
                    continue

    entered = len([r for r in rows if r.get("status") == "ENTERED"])
    skipped = len([r for r in rows if r.get("status") == "SKIPPED"])
    cancelled = len([r for r in rows if r.get("status") == "CANCELLED"])
    pending = len([r for r in rows if r.get("status") == "PENDING"])
    invalid = len([r for r in rows if r.get("status") == "INVALID"])
    print("\nService line input complete: entered={}, skipped={}, cancelled={}.".format(
        entered, skipped, cancelled
    ))
    print("Returning to MediBot workflow...")
    return {
        "entered": entered,
        "skipped": skipped,
        "cancelled": cancelled,
        "pending": pending,
        "invalid": invalid,
        "review_complete": bool(not quit_requested and pending == 0 and invalid == 0),
        "operator_return_requested": bool(quit_requested),
        "quit_requested": bool(quit_requested),
        "terminal_action": "returned_to_workflow" if quit_requested else "accepted",
        "rows": rows,
    }


def run_option_a_minutes_entry_preview(patient_info, date_of_service_label=None, charge_calculator=None):
    """Legacy Option A entrypoint; delegates to Service Line Input.

    SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: remove after downstream tests,
    operators, and sidecars no longer reference the old preview name.
    """
    return run_service_line_input_entry(
        patient_info,
        date_of_service_label=date_of_service_label,
        charge_calculator=charge_calculator,
    )

def handle_user_interaction(interaction_mode, error_message):
    
    while True:
        # If interaction_mode is neither 'triage' nor 'error', then it's normal mode.
        title = "Error Occurred" if interaction_mode == 'error' else "Data Entry Options"
        display_menu_header(title)

        if interaction_mode == 'error':
            print("\nERROR: ", error_message)

        # PERFORMANCE FIX: Display patient context to address "won't be obvious anymore" issue
        # Show user which patient and field they're working with for better F11 menu usability
        if current_patient_context:
            patient_name = current_patient_context.get('patient_name', 'Unknown Patient')
            surgery_date = current_patient_context.get('surgery_date', 'Unknown Date')
            last_field = current_patient_context.get('last_field', 'Unknown Field')
            print("\nCurrent Context:")
            print("  Patient: {}".format(patient_name))
            print("  Surgery Date: {}".format(surgery_date))
            print("  Last Field: {}".format(last_field))
            print("")

        # Menu options with improved context (0 = exit, consistent with MediCafe operator UI)
        print("0: Exit script")
        print("1: Retry last entry")
        print("2: Skip to next patient and continue")
        print("3: Go back two patients and redo")
        print("-" * 60)
        choice = input("Enter your choice (0/1/2/3): ").strip()
        
        if choice == '0':
            print("Exiting the script.")
            exit()
        if choice == '1':
            print("Selected: 'Retry last entry'. Please press 'F12' to continue.")
            return -1
        elif choice == '2':
            print("Selected: 'Skip to next patient and continue'. Please press 'F12' to continue.")
            return 1
        elif choice == '3':
            print("Selected: 'Go back two patients and redo'. Please press 'F12' to continue.")
            # Returning a specific value to indicate the action of going back two patients
            # but we might run into a problem if we stop mid-run on the first row?
            return -2
        else:
            print("Invalid choice. Please enter a valid number.")

def user_interaction(csv_data, interaction_mode, error_message, reverse_mapping):
    global app_control  # Use the instance of AppControl
    selected_patient_ids = []
    selected_indices = []

    if interaction_mode == 'triage':
        display_menu_header("            =(^.^)= Welcome to MediBot! =(^.^)=")
        if _debug_show_triage_source_csv():
            try:
                import MediBot_Preprocessor_lib as _pre
                _csv_path = getattr(_pre, 'CSV_FILE_PATH', '') or ''
            except Exception:
                _csv_path = ''
            _csv_label = os.path.basename(_csv_path) if _csv_path else '(not set in config)'
            print("[DEBUG] CSV file: {}".format(_csv_label))
        
        # Ensure app_control is initialized before using it in triage
        ac = _get_app_control()
        app_control = ac

        while True:
            try:
                response = input("\nAm I processing Medicare patients? (yes/no): ").lower().strip()    
                
                if not response:
                    print("A response is required. Please try again.")
                    continue
                
                if response in ['yes', 'y']:
                    ac.load_paths_from_config(medicare=True)
                    break
                elif response in ['no', 'n']:
                    ac.load_paths_from_config(medicare=False)
                    break
                else:
                    print("Invalid entry. Please enter 'yes' or 'no'.")
                    
            except KeyboardInterrupt:
                print("\nOperation cancelled by user. Exiting script.")
                exit()

        # Load configuration when needed
        config, _ = _get_config()
        fixed_values = config.get('fixed_values', {})  # Get fixed values from config json 
        if response in ['yes', 'y']:
            medicare_added_fixed_values = config.get('medicare_added_fixed_values', {})
            fixed_values.update(medicare_added_fixed_values)  # Add any medicare-specific fixed values from config
        
        proceed, selected_patient_ids, selected_indices = display_patient_selection_menu(csv_data, reverse_mapping, response in ['yes', 'y'])
        is_medicare = response in ['yes', 'y']
        return proceed, selected_patient_ids, selected_indices, fixed_values, is_medicare

    # For non-triage modes (error, normal), return the action code directly
    # The caller (manage_script_pause) expects an integer for flow control
    result = handle_user_interaction(interaction_mode, error_message)
    if isinstance(result, int):
        return result
    # Unexpected return type - signal continue
    return 0
