#!/usr/bin/env python
from __future__ import print_function

import csv
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean


class MediLinkContextualFlowTests(unittest.TestCase):

    def test_build_contextual_deductible_patient_tuples_matches_candidate_csv_rows(self):
        from MediLink import MediLink_main as medilink_main
        temp_root = tempfile.mkdtemp(prefix='mc_deductible_ctx_')
        try:
            csv_path = os.path.join(temp_root, 'patients.csv')
            with open(csv_path, 'w') as handle:
                writer = csv.DictWriter(handle, fieldnames=['Patient ID #2', 'Patient DOB', 'Primary Policy Number', 'Ins1 Payer ID', 'Surgery Date'])
                writer.writeheader()
                writer.writerow({
                    'Patient ID #2': '12345',
                    'Patient DOB': '01/15/1950',
                    'Primary Policy Number': 'MEM001',
                    'Ins1 Payer ID': '87726',
                    'Surgery Date': '03/26/2026',
                })
            prepared_data = [{'patid': '12345', 'surgery_date_iso': '2026-03-26'}]
            config = {'CSV_FILE_PATH': csv_path, 'MediLink_Config': {}}
            patients = medilink_main._build_contextual_deductible_patient_tuples(prepared_data, config)
            self.assertEqual(patients, [('12345', '01/15/1950', 'MEM001', '87726', '2026-03-26')])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_remittances_menu_claim_status_option_launches_followup(self):
        from MediLink import MediLink_main as medilink_main
        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu'):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['4', '0']):
                    with patch.object(medilink_main, '_launch_claim_status_followup') as launch_mock:
                        medilink_main._remittances_menu({})
        launch_mock.assert_called_once_with()

    def test_remittances_menu_sync_now_starts_background_full_sync_repair(self):
        from MediLink import MediLink_main as medilink_main
        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu'):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['1', '0']):
                    with patch.object(medilink_main, '_start_background_remittance_sync', return_value=(True, {'status': 'queued'})) as start_mock:
                        medilink_main._remittances_menu({})
        start_mock.assert_called_once()
        args, kwargs = start_mock.call_args
        self.assertTrue(isinstance(args[0], dict))
        self.assertEqual(kwargs.get('source'), 'manual')
        self.assertEqual(kwargs.get('is_boot_scan'), False)
        self.assertEqual(kwargs.get('force_full_repair'), True)

    def test_remittances_menu_sync_now_does_not_run_checker_on_ui_thread_when_busy(self):
        from MediLink import MediLink_main as medilink_main
        running = {
            'status': 'running',
            'source': 'startup',
            'stage': 'checking_endpoints',
            'started_at': medilink_main.time.time(),
            'message': 'Checking remittance endpoints.',
        }
        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu'):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['1', '0']):
                    with patch.object(medilink_main, '_start_background_remittance_sync', return_value=(False, running)):
                        with patch.object(medilink_main, '_print_remittance_job_status') as status_mock:
                            with patch.object(medilink_main.MediLink_Down, 'check_for_new_remittances') as sync_mock:
                                status_mock.side_effect = lambda active_only=False: None
                                medilink_main._remittances_menu({})

        sync_mock.assert_not_called()

    def test_main_menu_options_put_deductible_report_before_submit_claims(self):
        from MediLink import MediLink_main as medilink_main

        self.assertEqual(medilink_main._main_menu_options(), [
            "Remittances",
            "Open deductible report (United, 90-day DOS)",
            "Submit claims",
            "Tools",
        ])

    def test_claim_lifecycle_menu_consolidates_deductible_report_and_advanced_checker(self):
        from MediLink import MediLink_main as medilink_main

        displayed = []

        def _capture_menu(options, zero_option='Back'):
            displayed.append(list(options))

        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu', side_effect=_capture_menu):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['0']):
                    medilink_main._claim_lifecycle_financial_menu({})

        self.assertEqual(displayed[0], [
            "Claim Status follow-up",
            "Run reconciliation gate now",
            "Open deductible report (United, 90-day DOS)",
            "Advanced/troubleshooting: run full deductible checker",
        ])

    def test_claim_lifecycle_menu_option_3_opens_deductible_report(self):
        from MediLink import MediLink_main as medilink_main

        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu'):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['3', '0']):
                    with patch.object(medilink_main, '_open_deductible_report_txt') as report_mock:
                        with patch.object(medilink_main, '_launch_deductible_followup') as legacy_mock:
                            medilink_main._claim_lifecycle_financial_menu({'cfg': True})
        report_mock.assert_called_once_with({'cfg': True})
        legacy_mock.assert_not_called()

    def test_claim_lifecycle_menu_option_4_keeps_advanced_legacy_checker(self):
        from MediLink import MediLink_main as medilink_main

        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu'):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['4', '0']):
                    with patch.object(medilink_main, '_open_deductible_report_txt') as report_mock:
                        with patch.object(medilink_main, '_launch_deductible_followup') as legacy_mock:
                            medilink_main._claim_lifecycle_financial_menu({})
        legacy_mock.assert_called_once_with()
        report_mock.assert_not_called()

    def test_deductible_report_workflow_boundary_marks_primary_and_legacy_surfaces(self):
        assert_workflow_boundary_clean('deductible_report', {
            'artifact': 'deductible_report.txt',
        }, [
            {
                'role': 'operator_menu',
                'name': 'top_level_deductible_report',
                'identity': {'artifact': 'deductible_report.txt'},
                'status': 'ok',
                'classification': 'success',
                'accepted': True,
                'claims_completion': True,
            },
            {
                'role': 'operator_menu',
                'name': 'advanced_legacy_checker',
                'identity': {'artifact': 'legacy_interactive_checker'},
                'classification': 'wrong_target_ignored',
                'accepted': False,
            },
        ])

    def test_active_remittance_exit_notice_explains_shutdown_wait(self):
        from MediLink import MediLink_main as medilink_main
        with medilink_main._remittance_job_lock:
            original = dict(medilink_main._remittance_job_state)
            medilink_main._remittance_job_state.clear()
            medilink_main._remittance_job_state.update({
                'status': 'running',
                'source': 'manual',
                'stage': 'checking_endpoints',
                'started_at': medilink_main.time.time(),
                'message': 'Checking remittance endpoints.',
            })
        try:
            with patch('builtins.print') as print_mock:
                shown = medilink_main._print_active_remittance_exit_notice()
        finally:
            with medilink_main._remittance_job_lock:
                medilink_main._remittance_job_state.clear()
                medilink_main._remittance_job_state.update(original)

        self.assertTrue(shown)
        printed = '\n'.join(str(call_args[0][0]) for call_args in print_mock.call_args_list if call_args[0])
        self.assertIn('MediLink will close after the current remittance write finishes.', printed)

    def test_active_remittance_exit_notice_skips_when_idle(self):
        from MediLink import MediLink_main as medilink_main
        with medilink_main._remittance_job_lock:
            original = dict(medilink_main._remittance_job_state)
            medilink_main._remittance_job_state.clear()
            medilink_main._remittance_job_state.update({'status': 'succeeded'})
        try:
            with patch('builtins.print') as print_mock:
                shown = medilink_main._print_active_remittance_exit_notice()
        finally:
            with medilink_main._remittance_job_lock:
                medilink_main._remittance_job_state.clear()
                medilink_main._remittance_job_state.update(original)

        self.assertFalse(shown)
        print_mock.assert_not_called()

    def test_remittances_menu_reconciliation_option_runs_gate(self):
        from MediLink import MediLink_main as medilink_main
        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu'):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['5', '0']):
                    with patch.object(medilink_main, '_run_reconciliation_gate', return_value=0) as recon_mock:
                        with patch.object(medilink_main.MediLink_UI, 'prompt_press_enter_to_continue'):
                            medilink_main._remittances_menu({'MediLink_Config': {}})
        recon_mock.assert_called_once_with({'MediLink_Config': {}}, context_label='manual-remittance')

    def test_tools_menu_claim_lifecycle_option_opens_submenu(self):
        from MediLink import MediLink_main as medilink_main
        with patch.object(medilink_main.MediLink_UI, 'display_menu'):
            with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['4', '0']):
                with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
                    with patch.object(medilink_main, '_claim_lifecycle_financial_menu') as submenu_mock:
                        medilink_main.MediLink_UI.tools_menu(
                            {'MediLink_Config': {}},
                            {'local_claims_path': '/tmp'},
                            claims_ops_handler=lambda: medilink_main._claim_lifecycle_financial_menu({'MediLink_Config': {}})
                        )
        submenu_mock.assert_called_once_with({'MediLink_Config': {}})

    def test_run_reconciliation_gate_normalizes_paths_into_config(self):
        from MediLink import MediLink_main as medilink_main
        rel_storage = 'tmp_storage_test'
        rel_receipts = 'tmp_receipts_test'
        config = {'MediLink_Config': {'local_storage_path': rel_storage, 'local_claims_path': rel_receipts}}
        expected_storage = os.path.abspath(os.path.join(medilink_main.workspace_dir, rel_storage))
        expected_receipts = os.path.abspath(os.path.join(medilink_main.workspace_dir, rel_receipts))

        with patch('MediCafe.reconciliation.run_reconciliation', return_value={'severity': 'PASS'}) as run_mock:
            with patch('MediCafe.reconciliation.print_reconciliation_summary'):
                with patch('MediCafe.reconciliation.write_reconciliation_artifacts'):
                    rc = medilink_main._run_reconciliation_gate(config, context_label='unit-test')

        self.assertEqual(rc, 0)
        self.assertEqual(config['MediLink_Config']['local_storage_path'], expected_storage)
        self.assertEqual(config['MediLink_Config']['local_claims_path'], expected_receipts)
        _args, kwargs = run_mock.call_args
        self.assertEqual(kwargs.get('storage_path'), expected_storage)
        self.assertEqual(kwargs.get('receipts_root'), expected_receipts)

    def test_prompt_post_submission_claim_status_followup_launches_on_yes(self):
        from MediLink import MediLink_main as medilink_main
        with patch('builtins.input', return_value='y'):
            with patch.object(medilink_main, '_launch_claim_status_followup', return_value=0) as launch_mock:
                rc = medilink_main._prompt_post_submission_claim_status_followup()
        self.assertEqual(rc, 0)
        launch_mock.assert_called_once_with()

    def test_handle_submission_runs_deductible_checkpoint_before_endpoint_review(self):
        from MediLink import MediLink_main as medilink_main
        candidate = {
            'patid': '12345',
            'patient_id': 'CH123',
            'patient_name': 'Test Patient',
            'primary_insurance': 'UNITED',
            'surgery_date': '03-26-26',
            'surgery_date_iso': '2026-03-26',
            'primary_procedure_code': '66984',
        }
        call_order = []
        with patch.object(medilink_main, 'prepare_submission_candidates', return_value=([dict(candidate)], {})):
            with patch.object(medilink_main, '_maybe_offer_contextual_deductible_review', side_effect=lambda prepared, cfg: call_order.append('deductible')):
                with patch('builtins.input', return_value='n'):
                    with patch.object(medilink_main.MediLink_UI, 'user_decision_on_suggestions', side_effect=lambda data, config, insurance_edited, crosswalk: (call_order.append('endpoint') or (data, None))):
                        with patch.object(medilink_main.MediLink_DataMgmt, 'confirm_all_suggested_endpoints', return_value=[dict(candidate)]):
                            with patch.object(medilink_main.MediLink_DataMgmt, 'organize_patient_data_by_endpoint', return_value={'AVAILITY': [dict(candidate)]}):
                                with patch.object(medilink_main.MediLink_Up, 'confirm_transmission', return_value=False):
                                    result = medilink_main.handle_submission([dict(candidate)], {'MediLink_Config': {}}, {})
        self.assertFalse(result)
        self.assertEqual(call_order, ['deductible', 'endpoint'])

    def test_handle_submission_returns_true_when_submit_claims_reports_success(self):
        from MediLink import MediLink_main as medilink_main
        candidate = {
            'patid': '12345',
            'patient_id': 'CH123',
            'patient_name': 'Test Patient',
            'primary_insurance': 'UNITED',
            'surgery_date': '03-26-26',
            'surgery_date_iso': '2026-03-26',
            'primary_procedure_code': '66984',
        }
        with patch.object(medilink_main, 'prepare_submission_candidates', return_value=([dict(candidate)], {})):
            with patch.object(medilink_main, '_maybe_offer_contextual_deductible_review', return_value=False):
                with patch('builtins.input', return_value='n'):
                    with patch.object(medilink_main.MediLink_UI, 'user_decision_on_suggestions', return_value=([dict(candidate)], None)):
                        with patch.object(medilink_main.MediLink_DataMgmt, 'confirm_all_suggested_endpoints', return_value=[dict(candidate)]):
                            with patch.object(medilink_main.MediLink_DataMgmt, 'organize_patient_data_by_endpoint', return_value={'AVAILITY': [dict(candidate)]}):
                                with patch.object(medilink_main.MediLink_Up, 'confirm_transmission', return_value=True):
                                    with patch.object(medilink_main.MediLink_Up, 'check_internet_connection', return_value=True):
                                        with patch.object(medilink_main.MediLink_Up, 'submit_claims', return_value={'AVAILITY': {'claim1': (True, 'ok')}}):
                                            result = medilink_main.handle_submission([dict(candidate)], {'MediLink_Config': {}}, {})
        self.assertTrue(result)

    def test_handle_submission_runs_optumai_provider_ab_prompt_before_final_review(self):
        from MediLink import MediLink_main as medilink_main
        candidate = {
            'patid': '12345',
            'patient_id': 'CH123',
            'patient_name': 'Test Patient',
            'primary_insurance': 'UNITED',
            'surgery_date': '03-26-26',
            'surgery_date_iso': '2026-03-26',
            'primary_procedure_code': '66984',
            'confirmed_endpoint': 'OPTUMAI',
        }
        confirmed = [dict(candidate)]
        call_order = []

        def fake_annotate(rows, advice, accepted):
            call_order.append('annotate')
            rows[0]['optumai_provider_ab_operator_choice'] = 'accepted' if accepted else 'declined'
            return rows

        with patch.object(medilink_main, 'prepare_submission_candidates', return_value=([dict(candidate)], {})):
            with patch.object(medilink_main, '_maybe_offer_contextual_deductible_review', return_value=False):
                with patch('builtins.input', return_value='n'):
                    with patch.object(medilink_main.MediLink_UI, 'user_decision_on_suggestions', return_value=([dict(candidate)], None)):
                        with patch.object(medilink_main.MediLink_DataMgmt, 'confirm_all_suggested_endpoints', return_value=confirmed):
                            with patch('MediCafe.optumai_provider_ab_advisor.build_provider_ab_advice', side_effect=lambda rows, cfg, cw: call_order.append('advice') or {'offered': True, 'patient_index': 0}):
                                with patch('MediCafe.optumai_provider_ab_advisor.prompt_provider_ab_advice', side_effect=lambda advice: call_order.append('prompt') or True):
                                    with patch('MediCafe.optumai_provider_ab_advisor.annotate_provider_ab_choice', side_effect=fake_annotate):
                                        with patch.object(medilink_main.MediLink_DataMgmt, 'organize_patient_data_by_endpoint', side_effect=lambda rows: call_order.append('organize') or {'OPTUMAI': rows}):
                                            with patch.object(medilink_main.MediLink_Up, 'confirm_transmission', side_effect=lambda grouped: call_order.append('confirm') or False):
                                                result = medilink_main.handle_submission([dict(candidate)], {'MediLink_Config': {}}, {})

        self.assertFalse(result)
        self.assertEqual(call_order, ['advice', 'prompt', 'annotate', 'organize', 'confirm'])
        self.assertEqual(confirmed[0].get('optumai_provider_ab_operator_choice'), 'accepted')

    def test_filter_detailed_data_by_consolidated_rows_matches_by_claim_key(self):
        from MediLink import MediLink_main as medilink_main

        detailed = [
            {
                'claim_key': 'ck-001',
                'patient_id': 'CH100',
                'surgery_date_iso': '2026-04-02',
                'primary_insurance': 'UHC',
            },
            {
                'claim_key': 'ck-002',
                'patient_id': 'CH200',
                'surgery_date_iso': '2026-04-02',
                'primary_insurance': 'UHC',
            },
        ]
        selected_rows = [
            {
                'claim_key': 'CK-001',
                'patient_id': 'DIFFERENT-ID',
                'dos': '2026-04-02',
            }
        ]

        filtered = medilink_main._filter_detailed_data_by_consolidated_rows(detailed, selected_rows)
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0].get('claim_key'), 'ck-001')

    def test_filter_detailed_data_by_consolidated_rows_matches_by_family_key(self):
        from MediLink import MediLink_main as medilink_main

        detailed = [
            {
                'patient_id': 'CH300',
                'surgery_date_iso': '2026-05-10',
                'primary_insurance': 'UHC',
                'patient_name': 'Alice Smith',
            },
            {
                'patient_id': 'CH300',
                'surgery_date_iso': '2026-05-10',
                'primary_insurance': 'AETNA',
                'patient_name': 'Alice Smith',
            },
        ]
        selected_rows = [
            {
                'family_key': 'CH300|UHC|2026-05-10',
                'patient_id': 'CH300',
                'payer_id': 'UHC',
                'dos': '2026-05-10',
            }
        ]

        filtered = medilink_main._filter_detailed_data_by_consolidated_rows(detailed, selected_rows)
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0].get('primary_insurance'), 'UHC')

    def test_filter_detailed_data_computes_patient_keys_once_per_row(self):
        from MediLink import MediLink_main as medilink_main

        detailed = [
            {
                'patient_id': 'CH300',
                'surgery_date_iso': '2026-05-10',
                'primary_insurance': 'UHC',
                'patient_name': 'Alice Smith',
            },
            {
                'patient_id': 'CH301',
                'surgery_date_iso': '2026-05-11',
                'primary_insurance': 'AETNA',
                'patient_name': 'Bob Smith',
            },
        ]
        selected_rows = [
            {
                'patient_id': 'CH300',
                'payer_id': 'UHC',
                'dos': '2026-05-10',
            }
        ]
        original = medilink_main._build_patient_data_match_keys
        calls = []

        def counted(data):
            calls.append(data.get('patient_id'))
            return original(data)

        with patch.object(medilink_main, '_build_patient_data_match_keys', side_effect=counted):
            filtered = medilink_main._filter_detailed_data_by_consolidated_rows(detailed, selected_rows)

        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0].get('patient_id'), 'CH300')
        self.assertEqual(calls, ['CH300', 'CH301'])

    def test_current_export_row_from_detailed_patient_carries_enriched_fields(self):
        from MediLink import MediLink_main as medilink_main

        payload = {
            'patient_id': 'CH300',
            'patid': '12345',
            'patient_name': 'Alice Smith',
            'surgery_date': '05-10-26',
            'surgery_date_iso': '2026-05-10',
            'primary_payer_id': '87726',
            'primary_insurance': 'UNITED',
            'suggested_endpoint': 'UHCAPI',
            'insurance_type': '12',
            'insurance_type_source': 'API',
            'primary_procedure_code': '66984',
            'amount': '123.45',
            'duplicate_candidate': True,
            'claim_key': 'ck-300',
            'file_path': 'Z.DAT',
        }
        row = medilink_main._current_export_row_from_detailed_patient(payload)
        self.assertEqual(row.get('patient_id'), 'CH300')
        self.assertEqual(row.get('payer_id'), '87726')
        self.assertEqual(row.get('payer_display'), 'UNITED')
        self.assertEqual(row.get('suggested_endpoint'), 'UHCAPI')
        self.assertEqual(row.get('insurance_type_source'), 'API')
        self.assertEqual(row.get('family_key'), 'CH300|87726|2026-05-10')
        self.assertIs(row.get('_parsed_patient_data'), payload)

    def test_build_current_export_enriched_selection_uses_single_detailed_parse(self):
        from MediLink import MediLink_main as medilink_main

        payload = {
            'patient_id': 'CH300',
            'patient_name': 'Alice Smith',
            'surgery_date_iso': '2026-05-10',
            'primary_payer_id': '87726',
            'primary_insurance': 'UNITED',
            'suggested_endpoint': 'UHCAPI',
            'file_path': 'Z.DAT',
        }
        with patch.object(
            medilink_main.MediLink_PatientProcessor,
            'collect_detailed_patient_data',
            return_value=[payload],
        ) as collect_mock:
            rows, detailed = medilink_main._build_current_export_enriched_selection(
                ['Z.DAT'],
                {'MediLink_Config': {}},
                {'payer_id': {}},
            )
        collect_mock.assert_called_once_with(
            ['Z.DAT'],
            {'MediLink_Config': {}},
            {'payer_id': {}},
            display_summaries=False
        )
        self.assertEqual(detailed, [payload])
        self.assertEqual(len(rows), 1)
        self.assertIs(rows[0].get('_parsed_patient_data'), payload)

    def test_build_current_export_enriched_selection_falls_back_empty_on_parse_error(self):
        from MediLink import MediLink_main as medilink_main

        with patch.object(
            medilink_main.MediLink_PatientProcessor,
            'collect_detailed_patient_data',
            side_effect=RuntimeError('parse failed'),
        ):
            rows, detailed = medilink_main._build_current_export_enriched_selection(
                ['Z.DAT'],
                {'MediLink_Config': {}},
                {'payer_id': {}},
            )
        self.assertEqual(rows, [])
        self.assertEqual(detailed, [])

    def test_explicit_legacy_action_uses_legacy_zdat_picker_even_when_flagged(self):
        from MediLink import MediLink_main as medilink_main

        files = ['old.Z.DAT', 'new.Z.DAT']
        with patch.object(
            medilink_main.MediLink_UI,
            'user_select_files',
            return_value=['old.Z.DAT'],
        ) as picker_mock:
            selected, used_picker = medilink_main._resolve_submit_source_files(
                {'action': 'legacy', 'selected_rows': [], 'selected_patient_data': [{'patient_id': 'CH001'}]},
                files,
                flagged_snapshot=True,
            )
        picker_mock.assert_called_once_with(files)
        self.assertEqual(selected, ['old.Z.DAT'])
        self.assertTrue(used_picker)

    def test_selected_action_uses_row_dat_files_without_legacy_picker(self):
        from MediLink import MediLink_main as medilink_main

        temp_root = tempfile.mkdtemp(prefix='mc_selected_dat_')
        try:
            dat_path = os.path.join(temp_root, 'selected.Z.DAT')
            with open(dat_path, 'w') as handle:
                handle.write('x')
            with patch.object(medilink_main.MediLink_UI, 'user_select_files') as picker_mock:
                selected, used_picker = medilink_main._resolve_submit_source_files(
                    {'action': 'selected', 'selected_rows': [{'dat_file': dat_path}]},
                    ['fallback.Z.DAT'],
                    flagged_snapshot=True,
                )
            self.assertEqual(selected, [dat_path])
            self.assertFalse(used_picker)
            self.assertEqual(picker_mock.call_count, 0)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_flagged_nonlegacy_flow_keeps_existing_latest_file_shortcut(self):
        from MediLink import MediLink_main as medilink_main

        old_path = 'old.Z.DAT'
        new_path = 'new.Z.DAT'
        file_times = {old_path: 1.0, new_path: 2.0}
        with patch.object(medilink_main.MediLink_UI, 'user_select_files') as picker_mock:
            with patch.object(medilink_main.os.path, 'getctime', side_effect=lambda p: file_times[p]):
                selected, used_picker = medilink_main._resolve_submit_source_files(
                    {'action': 'legacy_unrelated'},
                    [old_path, new_path],
                    flagged_snapshot=True,
                )
        self.assertEqual(selected, [new_path])
        self.assertFalse(used_picker)
        self.assertEqual(picker_mock.call_count, 0)

    def test_resolve_consolidated_rows_cached_uses_cache_then_refreshes(self):
        from MediLink import MediLink_main as medilink_main

        cache_state = {'rows': [], 'cached_at': 0.0, 'ttl_seconds': 3600.0, 'index_health': {}}
        config = {'MediLink_Config': {}}
        first_rows = [{'claim_key': 'a'}]
        refreshed_rows = [{'claim_key': 'b'}]
        first_health = {'invalid_lines': 0, 'total_lines': 10}
        refreshed_health = {'invalid_lines': 2, 'total_lines': 10}

        with patch('MediCafe.submission_query.get_consolidated_latest_variants_from_all_sources', side_effect=[first_rows, refreshed_rows]) as query_mock:
            with patch('MediCafe.submission_query.get_last_submission_index_health', side_effect=[first_health, refreshed_health]):
                r1 = medilink_main._resolve_consolidated_rows_cached(config, cache_state, force_refresh=False)
                r2 = medilink_main._resolve_consolidated_rows_cached(config, cache_state, force_refresh=False)
                r3 = medilink_main._resolve_consolidated_rows_cached(config, cache_state, force_refresh=True)

        self.assertEqual(query_mock.call_count, 2)
        self.assertEqual(r1, first_rows)
        self.assertEqual(r2, first_rows)
        self.assertEqual(r3, refreshed_rows)
        self.assertEqual(cache_state.get('index_health'), refreshed_health)

    def test_maybe_notify_submission_index_health_warns_once(self):
        from MediLink import MediLink_main as medilink_main

        cache_state = {
            'index_health': {
                'invalid_lines': 3,
                'total_lines': 18,
            }
        }
        notice_state = {'shown': False}
        with patch('builtins.print') as print_mock:
            with patch.object(medilink_main, '_safe_log') as log_mock:
                first = medilink_main._maybe_notify_submission_index_health(cache_state, notice_state)
                second = medilink_main._maybe_notify_submission_index_health(cache_state, notice_state)

        self.assertTrue(first)
        self.assertFalse(second)
        self.assertTrue(notice_state.get('shown'))
        self.assertEqual(print_mock.call_count, 1)
        self.assertEqual(log_mock.call_count, 1)

    def test_maybe_notify_combined_health_prints_parse_notice_when_json_degraded(self):
        from MediLink import MediLink_main as medilink_main

        cache_state = {
            'index_health': {
                'invalid_lines': 3,
                'total_lines': 18,
            }
        }
        notice_state = {'shown': False}
        with patch('MediCafe.submission_query.build_submission_index_health_notice', return_value={
            'operator_notice': 'parse notice',
            'log_message': 'parse degraded',
        }):
            with patch('MediCafe.json_health.build_json_health_notice', return_value={
                'operator_notice': 'json notice',
                'log_message': 'json degraded',
            }):
                with patch.object(medilink_main, '_scan_json_health', return_value={'status': 'degraded'}) as scan_mock:
                    with patch('builtins.print') as print_mock:
                        with patch.object(medilink_main, '_safe_log') as log_mock:
                            first = medilink_main._maybe_notify_combined_health({}, cache_state, notice_state, force_refresh=False)
                            second = medilink_main._maybe_notify_combined_health({}, cache_state, notice_state, force_refresh=False)

        self.assertTrue(first)
        self.assertFalse(second)
        self.assertTrue(notice_state.get('shown'))
        self.assertEqual(print_mock.call_count, 1)
        self.assertEqual(log_mock.call_count, 2)
        self.assertEqual(scan_mock.call_count, 1)
        self.assertEqual(print_mock.call_args[0][0], 'parse notice')

    def test_maybe_notify_combined_health_logs_json_without_operator_notice(self):
        from MediLink import MediLink_main as medilink_main

        cache_state = {'index_health': {'invalid_lines': 0, 'total_lines': 18}}
        notice_state = {'shown': False}
        with patch('MediCafe.submission_query.build_submission_index_health_notice', return_value=None):
            with patch('MediCafe.json_health.build_json_health_notice', return_value={
                'operator_notice': 'json notice',
                'log_message': 'json degraded',
            }):
                with patch.object(medilink_main, '_scan_json_health', return_value={'status': 'degraded'}) as scan_mock:
                    with patch('builtins.print') as print_mock:
                        with patch.object(medilink_main, '_safe_log') as log_mock:
                            emitted = medilink_main._maybe_notify_combined_health(
                                {}, cache_state, notice_state, force_refresh=False
                            )

        self.assertFalse(emitted)
        self.assertEqual(print_mock.call_count, 0)
        self.assertEqual(log_mock.call_count, 1)
        self.assertEqual(scan_mock.call_count, 1)

    def test_scan_json_health_runs_when_cache_is_empty_dict(self):
        from MediLink import MediLink_main as medilink_main

        cache_state = {'json_health': {}}
        with patch('MediCafe.json_health.run_json_health_scan', return_value={'scan_id': 'scan-1', 'status': 'ok'}) as scan_mock:
            summary = medilink_main._scan_json_health(
                {},
                cache_state,
                {},
                force_refresh=False,
                emit_notice=False,
            )
        self.assertEqual(summary.get('scan_id'), 'scan-1')
        self.assertEqual(scan_mock.call_count, 1)

    def test_scan_json_health_failure_logs_sanitized_exception_token(self):
        from MediLink import MediLink_main as medilink_main

        cache_state = {'json_health': None}
        with patch('MediCafe.json_health.run_json_health_scan', side_effect=RuntimeError('C:\\Users\\secret\\patient')):
            with patch.object(medilink_main, '_safe_log') as log_mock:
                summary = medilink_main._scan_json_health(
                    {},
                    cache_state,
                    {},
                    force_refresh=False,
                    emit_notice=False,
                )
        self.assertEqual(summary, {})
        self.assertEqual(log_mock.call_count, 1)
        msg = str(log_mock.call_args[0][0])
        self.assertIn('RuntimeError', msg)
        self.assertNotIn('C:\\Users\\secret\\patient', msg)

    def test_claim_status_json_health_falls_back_to_parse_notice_on_json_error(self):
        from MediLink import MediLink_ClaimStatus as claim_status

        notice_state = {'shown': False}
        parse_health = {'invalid_lines': 2, 'total_lines': 10}
        with patch.object(claim_status, '_scan_json_health_summary', side_effect=RuntimeError('boom')):
            with patch('MediCafe.submission_query.build_submission_index_health_notice', return_value={
                'operator_notice': 'parse degraded',
                'log_message': 'parse degraded',
            }):
                with patch('builtins.print') as print_mock:
                    emitted = claim_status._maybe_notify_json_health(
                        {},
                        notice_state,
                        submission_index_health=parse_health,
                    )
        self.assertTrue(emitted)
        self.assertEqual(print_mock.call_count, 1)

    def test_claim_status_json_health_degraded_is_log_only_without_parse_notice(self):
        from MediLink import MediLink_ClaimStatus as claim_status

        notice_state = {'shown': False}
        with patch.object(claim_status, '_scan_json_health_summary', return_value={'status': 'degraded'}):
            with patch('MediCafe.submission_query.build_submission_index_health_notice', return_value=None):
                with patch('MediCafe.json_health.build_json_health_notice', return_value={
                    'operator_notice': 'json notice',
                    'log_message': 'json degraded',
                }):
                    with patch('builtins.print') as print_mock:
                        emitted = claim_status._maybe_notify_json_health(
                            {},
                            notice_state,
                            submission_index_health={'invalid_lines': 0, 'total_lines': 10},
                        )

        self.assertFalse(emitted)
        self.assertEqual(print_mock.call_count, 0)

    def test_should_force_consolidated_refresh_on_submit(self):
        from MediLink import MediLink_main as medilink_main

        self.assertTrue(
            medilink_main._should_force_consolidated_refresh_on_submit(True, {}, 0.0)
        )
        self.assertFalse(
            medilink_main._should_force_consolidated_refresh_on_submit(False, {}, 0.0)
        )
        self.assertFalse(
            medilink_main._should_force_consolidated_refresh_on_submit(
                False, {'submit_dat_seen_mtime': 100.0}, 100.0
            )
        )
        self.assertTrue(
            medilink_main._should_force_consolidated_refresh_on_submit(
                False, {'submit_dat_seen_mtime': 100.0}, 200.0
            )
        )

    def test_resolve_current_export_dat_files_newest_batch_only(self):
        from MediLink import MediLink_main as medilink_main
        import time

        tmp = tempfile.mkdtemp(prefix='mc_export_resolve_')
        try:
            old_path = os.path.join(tmp, 'old.dat')
            new_path = os.path.join(tmp, 'new.dat')
            with open(old_path, 'wb') as f:
                f.write(b'x')
            old_t = time.time() - 250.0
            try:
                os.utime(old_path, (old_t, old_t))
            except Exception:
                pass
            with open(new_path, 'wb') as f:
                f.write(b'y')
            snap = [old_path, new_path]
            resolved = medilink_main._resolve_current_export_dat_files(snap, batch_window_seconds=120.0)
            self.assertEqual(len(resolved), 1)
            self.assertEqual(
                os.path.normcase(os.path.normpath(resolved[0])),
                os.path.normcase(os.path.normpath(new_path)),
            )
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_resolve_current_export_dat_files_prefers_timestamp_suffix_over_older_export(self):
        from MediLink import MediLink_main as medilink_main

        tmp = tempfile.mkdtemp(prefix='mc_ts_resolve_')
        try:
            older = os.path.join(tmp, 'batch_a_20260115_120000.dat')
            newer = os.path.join(tmp, 'batch_b_20260115_120100.dat')
            with open(older, 'wb') as f:
                f.write(b'a')
            with open(newer, 'wb') as f:
                f.write(b'b')
            snap = [older, newer]
            resolved = medilink_main._resolve_current_export_dat_files(snap)
            self.assertEqual(len(resolved), 1)
            self.assertEqual(
                os.path.normcase(os.path.normpath(resolved[0])),
                os.path.normcase(os.path.normpath(newer)),
            )
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_resolve_current_export_dat_files_includes_all_files_sharing_newest_timestamp(self):
        from MediLink import MediLink_main as medilink_main

        tmp = tempfile.mkdtemp(prefix='mc_ts_multi_')
        try:
            a = os.path.join(tmp, 'claims_a_20260115_120100.dat')
            b = os.path.join(tmp, 'claims_b_20260115_120100.dat')
            old = os.path.join(tmp, 'prior_20260115_115900.dat')
            for p in (a, b, old):
                with open(p, 'wb') as f:
                    f.write(b'x')
            snap = [a, b, old]
            resolved = medilink_main._resolve_current_export_dat_files(snap)
            self.assertEqual(len(resolved), 2)
            norm = {os.path.normcase(os.path.normpath(p)) for p in resolved}
            self.assertIn(os.path.normcase(os.path.normpath(a)), norm)
            self.assertIn(os.path.normcase(os.path.normpath(b)), norm)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_resolve_current_export_dat_files_prefers_detection_preferred_paths(self):
        from MediLink import MediLink_main as medilink_main

        tmp = tempfile.mkdtemp(prefix='mc_pref_')
        try:
            a = os.path.join(tmp, 'a_20260115_120000.dat')
            b = os.path.join(tmp, 'b_20260115_120500.dat')
            for p in (a, b):
                with open(p, 'wb') as f:
                    f.write(b'x')
            snap = [a, b]
            resolved = medilink_main._resolve_current_export_dat_files(snap, preferred_paths=[a])
            self.assertEqual(len(resolved), 1)
            self.assertEqual(
                os.path.normcase(os.path.normpath(resolved[0])),
                os.path.normcase(os.path.normpath(a)),
            )
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_detect_new_files_returns_renamed_paths(self):
        from MediLink.MediLink_DataMgmt import detect_new_files

        tmp = tempfile.mkdtemp(prefix='mc_detect_rename_')
        try:
            raw = os.path.join(tmp, 'Z.DAT')
            with open(raw, 'wb') as f:
                f.write(b'x')
            detected, flagged, renamed = detect_new_files(tmp, file_extension='.DAT')
            self.assertTrue(flagged)
            self.assertEqual(len(renamed), 1)
            self.assertFalse(os.path.isfile(raw))
            self.assertEqual(len(detected), 1)
            self.assertEqual(detected[0], renamed[0])
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_max_dat_mtime_in_paths(self):
        from MediLink import MediLink_main as medilink_main
        import time

        tmp = tempfile.mkdtemp(prefix='mc_mtime_')
        try:
            a = os.path.join(tmp, 'a.dat')
            b = os.path.join(tmp, 'b.dat')
            with open(a, 'wb') as f:
                f.write(b'1')
            time.sleep(0.05)
            with open(b, 'wb') as f:
                f.write(b'2')
            mx = medilink_main._max_dat_mtime_in_paths([a, b])
            self.assertGreaterEqual(mx, os.path.getmtime(b))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
