#!/usr/bin/env python
from __future__ import print_function

import os
import sys

_TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean

from MediCafe import charges_tool


def test_baseline_charge_tier_edges_are_canonical():
    cases = [
        (5, "450.00", "baseline_5_15"),
        (15, "450.00", "baseline_5_15"),
        (16, "540.00", "baseline_16_35"),
        (35, "540.00", "baseline_16_35"),
        (36, "580.00", "baseline_36_59"),
        (59, "580.00", "baseline_36_59"),
    ]

    for minutes, amount, rule_id in cases:
        result = charges_tool.calculate_charge_result({
            "status": "ENTERED",
            "minutes": str(minutes),
            "patient_id": "1",
            "dos": "01-20-2026",
            "cpt": "00142",
        })
        assert result["charge_status"] == "calculated"
        assert result["charge_amount"] == amount
        assert result["charge_note"] == ""
        assert result["charge_rule_id"] == rule_id
        assert result["charge_schema_version"] == "charges_tool.v1"
        assert result["workflow_boundary"] == "preview_only_review_required"
        assert result["claims_completion"] is False
        assert result["mutates_billing_state"] is False
        assert result["mutates_dat"] is False
        assert result["mutates_837p"] is False
        assert result["charges_entered"] is False
        assert result["billable"] is True
        assert result["requires_operator_review"] is True


def test_charge_tool_preserves_non_entered_statuses_without_billable_charge():
    cases = [
        ("PENDING", "", "PENDING", "pending_minutes"),
        ("SKIPPED", "", "SKIPPED", "operator_skipped"),
        ("CANCELLED", "", "CANCELLED", "operator_cancelled"),
    ]

    for status, minutes, display, rule_id in cases:
        result = charges_tool.calculate_charge_result({
            "status": status,
            "minutes": minutes,
            "patient_id": "1",
            "dos": "01-20-2026",
        })
        assert result["charge_display"] == display
        assert result["charge_amount"] == ""
        assert result["charge_note"] == ""
        assert result["charge_rule_id"] == rule_id
        assert result["billable"] is False
        assert result["claims_completion"] is False
        assert result["mutates_billing_state"] is False
        assert result["mutates_dat"] is False
        assert result["mutates_837p"] is False
        assert result["charges_entered"] is False


def test_charge_tool_rejects_out_of_domain_minutes_and_zero_remains_cancel_boundary():
    low = charges_tool.calculate_charge_result({"status": "ENTERED", "minutes": "4"})
    high = charges_tool.calculate_charge_result({"status": "ENTERED", "minutes": "60"})
    zero = charges_tool.calculate_charge_result({"status": "ENTERED", "minutes": "0"})

    assert low["charge_status"] == "invalid"
    assert low["charge_rule_id"] == "invalid_minutes"
    assert high["charge_status"] == "invalid"
    assert high["charge_rule_id"] == "invalid_minutes"
    assert zero["charge_status"] == "invalid"
    assert zero["charge_rule_id"] == "zero_cancelled_upstream"
    assert zero["charge_note"] == "0 is cancel upstream"
    assert zero["claims_completion"] is False


def test_charge_tool_uses_same_patient_dos_anchor_when_provided():
    result = charges_tool.calculate_charge_result({
        "status": "ENTERED",
        "minutes": "8",
        "patient_id": "1",
        "dos": "01-21-2026",
        "same_patient_anchor_charge_amount": "580.00",
        "same_patient_anchor_charge_display": "$580",
        "same_patient_anchor_charge_note": "same-patient DOS anchor from 01-20-2026",
    })

    assert result["charge_status"] == "calculated"
    assert result["charge_amount"] == "580.00"
    assert result["charge_display"] == "$580"
    assert result["charge_rule_id"] == "same_patient_dos_anchor"
    assert result["charge_source"] == "same_patient_dos_anchor"
    assert result["charge_note"] == "same-patient DOS anchor from 01-20-2026"
    assert result["baseline_charge_amount"] == "450.00"
    assert result["claims_completion"] is False
    assert result["mutates_billing_state"] is False
    assert result["mutates_dat"] is False
    assert result["mutates_837p"] is False
    assert result["charges_entered"] is False


def test_service_line_amount_api_and_legacy_option_a_alias_match():
    context = {
        "status": "ENTERED",
        "minutes": "18",
        "patient_id": "1",
        "dos": "01-20-2026",
        "cpt": "00142",
    }

    service_line_result = charges_tool.calculate_service_line_amount_result(context)
    legacy_result = charges_tool.calculate_option_a_charge_result(context)

    assert service_line_result == legacy_result
    assert service_line_result["workflow_name"] == "service_line_input"
    assert service_line_result["workflow_boundary"] == "preview_only_review_required"
    assert service_line_result["claims_completion"] is False
    assert service_line_result["mutates_billing_state"] is False
    assert service_line_result["mutates_dat"] is False
    assert service_line_result["mutates_837p"] is False
    assert service_line_result["charges_entered"] is False
    assert "claim_submitted" not in service_line_result
    assert "dat_mutation" not in service_line_result
    assert "x12_837p_mutation" not in service_line_result

    assert_workflow_boundary_clean(
        "service_line_input_charge_preview",
        {"patient_id": "1", "dos": "01-20-2026"},
        [
            {
                "name": "charges_tool_result",
                "role": "preview_evidence",
                "identity": {"patient_id": "1", "dos": "01-20-2026"},
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "billing_custody_mutation",
                "role": "state",
                "identity": {"patient_id": "1", "dos": "01-20-2026"},
                "classification": "missing",
                "terminal": False,
                "accepted": False,
                "claims_completion": False,
            },
        ],
    )
