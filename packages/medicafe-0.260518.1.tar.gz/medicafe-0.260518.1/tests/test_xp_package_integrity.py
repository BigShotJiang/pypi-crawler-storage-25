# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import shutil
import site
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    patch = None

from MediCafe import xp_package_integrity as xpi


class XpPackageIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="mc_xp_integrity_")

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _write(self, rel_path, body):
        path = os.path.join(self.root, rel_path.replace("/", os.sep))
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(path, "w") as fh:
            fh.write(body)
        return path

    def test_verify_installed_files_accepts_matching_manifest(self):
        self._write("scripts/unified_model/ingest_from_manifest.py", "print('ok')\n")
        manifest = xpi.build_expected_manifest(
            self.root,
            version="0.test.1",
            files=("scripts/unified_model/ingest_from_manifest.py",),
        )

        result = xpi.verify_installed_files(install_root=self.root, expected_manifest=manifest)

        self.assertTrue(result.get("ok"))
        self.assertEqual(result.get("verified_count"), 1)
        self.assertEqual(result.get("missing"), [])
        self.assertEqual(result.get("mismatched"), [])

    def test_verify_installed_files_rejects_stale_data_file(self):
        self._write("scripts/unified_model/ingest_from_manifest.py", "print('old')\n")
        manifest = xpi.build_expected_manifest(
            self.root,
            version="0.test.1",
            files=("scripts/unified_model/ingest_from_manifest.py",),
        )
        self._write("scripts/unified_model/ingest_from_manifest.py", "print('new')\n")

        result = xpi.verify_installed_files(install_root=self.root, expected_manifest=manifest)

        self.assertFalse(result.get("ok"))
        self.assertEqual(result.get("missing"), [])
        self.assertEqual(len(result.get("mismatched")), 1)
        self.assertEqual(result.get("mismatched")[0].get("path"), "scripts/unified_model/ingest_from_manifest.py")

    def test_write_expected_manifest_fails_when_critical_file_missing(self):
        with self.assertRaises(RuntimeError):
            xpi.write_expected_manifest(self.root, version="0.test.1")

    def test_default_expected_files_discovers_future_unified_model_scripts(self):
        rel = "scripts/unified_model/future_deterministic_step.py"
        self._write(rel, "print('future')\n")

        files = xpi.default_expected_files(self.root)

        self.assertIn(rel, files)

    def test_default_expected_files_includes_xp_critical_recommendation_modules(self):
        files = xpi.default_expected_files(self.root)

        self.assertIn("MediCafe/cloud_readiness_recommendations.py", files)
        self.assertIn("MediCafe/launcher_cloud_readiness_mixin.py", files)
        self.assertIn("MediCafe/layer1_runbook_model.py", files)
        self.assertIn("MediCafe/layer1_readiness_model.py", files)
        self.assertIn("MediBot/MediBot_docx_decoder.py", files)

    @unittest.skipIf(patch is None, "unittest.mock.patch unavailable")
    def test_verify_resolves_medicafe_package_modules_from_installed_package_parent(self):
        rel = "MediCafe/layer1_readiness_model.py"
        package_root = os.path.join(self.root, "site-packages")
        self._write("site-packages/" + rel, "fresh recommendation logic\n")
        manifest = xpi.build_expected_manifest(package_root, version="0.test.1", files=(rel,))

        fake_manifest_path = os.path.join(package_root, "MediCafe", xpi.MANIFEST_BASENAME)
        fake_prefix = os.path.join(self.root, "prefix_without_package")
        os.makedirs(fake_prefix)

        with patch.object(xpi, "__file__", os.path.join(package_root, "MediCafe", "xp_package_integrity.py")):
            with patch.object(xpi, "expected_manifest_path", return_value=fake_manifest_path):
                with patch.object(sys, "prefix", fake_prefix):
                    with patch.object(sys, "exec_prefix", fake_prefix):
                        result = xpi.verify_installed_files(install_root=None, expected_manifest=manifest)

        self.assertTrue(result.get("ok"), msg=repr(result))
        self.assertEqual(result.get("verified_count"), 1)
        checked = result.get("checked_files") or []
        self.assertEqual(checked[0].get("path"), rel)
        self.assertIn(package_root.replace("\\", "/"), checked[0].get("installed_path", "").replace("\\", "/"))

    @unittest.skipIf(patch is None, "unittest.mock.patch unavailable")
    def test_verify_resolves_medibot_package_modules_from_installed_package_parent(self):
        rel = "MediBot/MediBot_docx_decoder.py"
        package_root = os.path.join(self.root, "site-packages")
        self._write("site-packages/" + rel, "fresh docx parser logic\n")
        manifest = xpi.build_expected_manifest(package_root, version="0.test.1", files=(rel,))

        fake_manifest_path = os.path.join(package_root, "MediCafe", xpi.MANIFEST_BASENAME)
        fake_prefix = os.path.join(self.root, "prefix_without_package")
        os.makedirs(fake_prefix)

        with patch.object(xpi, "__file__", os.path.join(package_root, "MediCafe", "xp_package_integrity.py")):
            with patch.object(xpi, "expected_manifest_path", return_value=fake_manifest_path):
                with patch.object(sys, "prefix", fake_prefix):
                    with patch.object(sys, "exec_prefix", fake_prefix):
                        result = xpi.verify_installed_files(install_root=None, expected_manifest=manifest)

        self.assertTrue(result.get("ok"), msg=repr(result))
        self.assertEqual(result.get("verified_count"), 1)
        checked = result.get("checked_files") or []
        self.assertEqual(checked[0].get("path"), rel)
        self.assertIn(package_root.replace("\\", "/"), checked[0].get("installed_path", "").replace("\\", "/"))

    @unittest.skipIf(patch is None, "unittest.mock.patch unavailable")
    def test_verify_finds_data_files_under_user_base_for_user_install(self):
        """
        pip install --user places setuptools data_files under site.USER_BASE,
        not sys.prefix. Verification must search USER_BASE.
        """
        rel = "scripts/unified_model/ingest_from_manifest.py"
        user_base = os.path.join(self.root, "user_base")
        script_dir = os.path.join(user_base, "scripts", "unified_model")
        os.makedirs(script_dir)
        script_path = os.path.join(script_dir, "ingest_from_manifest.py")
        with open(script_path, "w") as fh:
            fh.write("user-scheme ok\n")

        manifest = xpi.build_expected_manifest(user_base, version="0.test.1", files=(rel,))

        fake_site = os.path.join(self.root, "site-packages")
        medicafe_dir = os.path.join(fake_site, "MediCafe")
        os.makedirs(medicafe_dir)
        manifest_path = os.path.join(medicafe_dir, xpi.MANIFEST_BASENAME)
        with open(manifest_path, "w") as fh:
            json.dump(manifest, fh)

        fake_prefix = os.path.join(self.root, "sys_prefix_no_scripts")
        os.makedirs(fake_prefix)

        with patch.object(xpi, "expected_manifest_path", return_value=manifest_path):
            with patch.object(sys, "prefix", fake_prefix):
                with patch.object(sys, "exec_prefix", fake_prefix):
                    with patch.object(site, "USER_BASE", user_base):
                        result = xpi.verify_installed_files(install_root=None, expected_manifest=manifest)

        self.assertTrue(result.get("ok"), msg=repr(result))
        self.assertEqual(result.get("verified_count"), 1)

    @unittest.skipIf(patch is None, "unittest.mock.patch unavailable")
    def test_verify_prefers_user_base_when_manifest_loads_from_user_site(self):
        """
        If both prefix and USER_BASE contain scripts/unified_model, prefer the tree
        that matches a user-site MediCafe install to avoid stale prefix files.
        """
        rel = "scripts/unified_model/ingest_from_manifest.py"
        user_base = os.path.join(self.root, "user_base")
        good_dir = os.path.join(user_base, "scripts", "unified_model")
        os.makedirs(good_dir)
        with open(os.path.join(good_dir, "ingest_from_manifest.py"), "w") as fh:
            fh.write("fresh\n")

        bad_prefix = os.path.join(self.root, "prefix")
        bad_dir = os.path.join(bad_prefix, "scripts", "unified_model")
        os.makedirs(bad_dir)
        with open(os.path.join(bad_dir, "ingest_from_manifest.py"), "w") as fh:
            fh.write("stale-old-content\n")

        manifest = xpi.build_expected_manifest(user_base, version="0.test.1", files=(rel,))

        fake_site = os.path.join(self.root, "site-packages")
        medicafe_dir = os.path.join(fake_site, "MediCafe")
        os.makedirs(medicafe_dir)
        manifest_path = os.path.join(medicafe_dir, xpi.MANIFEST_BASENAME)
        with open(manifest_path, "w") as fh:
            json.dump(manifest, fh)

        with patch.object(xpi, "expected_manifest_path", return_value=manifest_path):
            with patch.object(sys, "prefix", bad_prefix):
                with patch.object(sys, "exec_prefix", bad_prefix):
                    with patch.object(site, "USER_BASE", user_base):
                        with patch.object(site, "getusersitepackages", return_value=fake_site):
                            result = xpi.verify_installed_files(install_root=None, expected_manifest=manifest)

        self.assertTrue(result.get("ok"), msg=repr(result))
        checked = result.get("checked_files") or []
        self.assertEqual(len(checked), 1)
        self.assertIn(user_base.replace("\\", "/"), checked[0].get("installed_path", "").replace("\\", "/"))


if __name__ == "__main__":
    unittest.main()
