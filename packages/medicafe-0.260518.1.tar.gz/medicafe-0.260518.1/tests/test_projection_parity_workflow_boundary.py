import json
import os
import sys

from MediCafe import cloud_readiness

TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if TESTS_ROOT not in sys.path:
    sys.path.insert(0, TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean  # noqa: E402


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)


def test_run_projection_parity_run_scoped_latest_ignores_wrong_target_file(tmp_path):
    """
    Workflow-boundary contract regression harness for:
      scripts/unified_model/run_projection_parity.py::run_projection_parity

    Cloud readiness packaging should treat run_id as the preserved identity and
    must not accept a newer wrong-target projection_parity_summary_*.json.
    """
    lab_root = str(tmp_path)
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)

    rid_ok = "RID_OK"
    rid_wrong = "RID_WRONG"

    ok_path = os.path.join(reports_dir, "projection_parity_summary_{0}.json".format(rid_ok))
    wrong_path = os.path.join(reports_dir, "projection_parity_summary_{0}.json".format(rid_wrong))

    _write_json(ok_path, {"ok": True, "run_id": rid_ok})
    _write_json(wrong_path, {"ok": True, "run_id": rid_wrong})

    # Ensure wrong-target file wins by mtime so unscoped "latest by mtime" would pick it.
    os.utime(ok_path, (1, 1))
    os.utime(wrong_path, (2, 2))

    selected = cloud_readiness._latest_report_file_any_for_run_scope(
        reports_dir,
        ("projection_parity_summary_",),
        ".json",
        allowed_run_ids=set([rid_ok]),
    )
    assert os.path.normcase(selected) == os.path.normcase(ok_path)

    assert_workflow_boundary_clean("projection_parity_summary", {
        "run_id": rid_ok,
    }, [
        {
            "name": "diagnostics_state.json",
            "role": "preserved_context",
            "identity": {"run_id": rid_ok},
            "status": "completed",
            "accepted": False,
            "classification": "state_present_not_accepted",
            "claims_completion": False,
        },
        {
            "name": os.path.basename(wrong_path),
            "role": "mutable_evidence",
            "identity": {"run_id": rid_wrong},
            "status": "completed",
            "accepted": False,
            "classification": "ignored_mismatch",
            "claims_completion": False,
        },
        {
            "name": os.path.basename(ok_path),
            "role": "packaging_surface",
            "identity": {"run_id": rid_ok},
            "status": "completed",
            "accepted": True,
            "classification": "accepted",
            "claims_completion": True,
        },
    ])

