import importlib.util
import json
import os
import sys

import pytest


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_medibot_script_module():
    medibot_dir = os.path.join(_PROJECT_ROOT, "MediBot")
    if medibot_dir not in sys.path:
        sys.path.insert(0, medibot_dir)
    module_path = os.path.join(medibot_dir, "MediBot.py")
    spec = importlib.util.spec_from_file_location("medibot_script_for_service_line_ahk_overlay_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _write_state(module, tmp_path, rows):
    state = {
        "schema_version": "service_line_input_state.v1",
        "workflow_name": "service_line_input",
        "workflow_boundary": "preview_only_review_required",
        "rows": rows,
    }
    path = tmp_path / module.SERVICE_LINE_INPUT_STATE_FILENAME
    path.write_text(json.dumps(state), encoding="utf-8")


def _telemetry_lines(tmp_path):
    path = tmp_path / "telemetry" / "service_line_input_medisoft_handoff_events.jsonl"
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def test_ahk_diagnosis_overlay_uses_service_line_dx_bridge_without_billing_custody(tmp_path):
    medibot_script = _load_medibot_script_module()
    row_key = medibot_script._option_a_minutes_row_key("12345", "01-21-2026")
    _write_state(medibot_script, tmp_path, {
        row_key: {
            "patient_id": "12345",
            "dos": "01-21-2026",
            "status": "entered",
            "diagnosis_code": "H25.812",
            "diagnosis_source": "operator_overlay",
            "workflow_boundary": "preview_only_review_required",
            "claims_completion": False,
            "mutates_billing_state": False,
            "mutates_dat": False,
            "mutates_837p": False,
            "charges_entered": False,
        }
    })

    value = medibot_script._service_line_input_resolve_ahk_diagnosis_overlay(
        "Default Diagnosis #1",
        "25811",
        {"Patient ID #2": "12345", "Surgery Date": "01-21-2026"},
        {},
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
        {"diagnosis_to_medisoft": {"H25.812": "25812"}},
    )

    assert value == "25812"
    events = _telemetry_lines(tmp_path)
    assert events[-1]["decision"] == "applied"
    assert events[-1]["workflow_boundary"] == "preview_only_review_required"
    assert events[-1]["claims_completion"] is False
    assert events[-1]["mutates_dat"] is False
    assert events[-1]["mutates_837p"] is False
    assert events[-1]["charges_entered"] is False
    assert "H25.812" not in json.dumps(events[-1])
    assert "12345" not in json.dumps(events[-1])


def test_ahk_diagnosis_overlay_wrong_target_keeps_original_value(tmp_path):
    medibot_script = _load_medibot_script_module()
    row_key = medibot_script._option_a_minutes_row_key("99999", "01-21-2026")
    _write_state(medibot_script, tmp_path, {
        row_key: {
            "patient_id": "99999",
            "dos": "01-21-2026",
            "status": "entered",
            "diagnosis_code": "H25.812",
            "diagnosis_source": "operator_overlay",
            "workflow_boundary": "preview_only_review_required",
        }
    })

    value = medibot_script._service_line_input_resolve_ahk_diagnosis_overlay(
        "Default Diagnosis #1",
        "25811",
        {"Patient ID #2": "12345", "Surgery Date": "01-21-2026"},
        {},
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
        {"diagnosis_to_medisoft": {"H25.812": "25812"}},
    )

    assert value == "25811"
    assert _telemetry_lines(tmp_path)[-1]["decision"] == "normal_path"


def test_ahk_diagnosis_overlay_fails_closed_when_bridge_is_missing(tmp_path):
    medibot_script = _load_medibot_script_module()
    row_key = medibot_script._option_a_minutes_row_key("12345", "01-21-2026")
    _write_state(medibot_script, tmp_path, {
        row_key: {
            "patient_id": "12345",
            "dos": "01-21-2026",
            "status": "entered",
            "diagnosis_code": "H25.812",
            "diagnosis_source": "operator_overlay",
            "workflow_boundary": "preview_only_review_required",
            "claims_completion": False,
            "mutates_billing_state": False,
            "mutates_dat": False,
            "mutates_837p": False,
            "charges_entered": False,
        }
    })

    with pytest.raises(ValueError) as excinfo:
        medibot_script._service_line_input_resolve_ahk_diagnosis_overlay(
            "Default Diagnosis #1",
            "25811",
            {"Patient ID #2": "12345", "Surgery Date": "01-21-2026"},
            {},
            {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
            {},
        )

    assert "missing_diagnosis_to_medisoft_bridge" in str(excinfo.value)
    events = _telemetry_lines(tmp_path)
    assert events[-1]["decision"] == "blocked"
    assert events[-1]["block_reason"] == "missing_diagnosis_to_medisoft_bridge"
    assert events[-1]["claims_completion"] is False
