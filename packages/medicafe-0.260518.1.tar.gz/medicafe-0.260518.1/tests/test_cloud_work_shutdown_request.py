#!/usr/bin/env python
from __future__ import print_function

import json
import os
import tempfile
import unittest


class CloudWorkShutdownRequestTests(unittest.TestCase):

    def test_shadow_pipeline_stops_before_next_phase_when_shutdown_requested(self):
        from scripts.unified_model import run_shadow_pipeline as rsp

        with tempfile.TemporaryDirectory() as lab_root:
            reports = os.path.join(lab_root, 'reports')
            os.makedirs(reports)
            request_path = os.path.join(reports, 'cloud_work_shutdown_request.json')
            with open(request_path, 'w') as handle:
                json.dump({
                    'schema_version': 1,
                    'request_id': 'req-unit',
                    'status': 'requested',
                    'reason': 'operator_safe_cancel',
                }, handle)

            calls = []
            original_run_phase = rsp._run_phase
            try:
                rsp._run_phase = lambda *args, **kwargs: calls.append(args) or (True, 0)
                ok, _rid, failed_phase, error_code = rsp.run_shadow_pipeline(lab_root)
            finally:
                rsp._run_phase = original_run_phase

            self.assertFalse(ok)
            self.assertEqual(failed_phase, 'A')
            self.assertEqual(error_code, rsp.OPERATOR_SHUTDOWN_REQUESTED)
            self.assertEqual(calls, [])
            with open(request_path, 'r') as handle:
                request = json.load(handle)
            self.assertEqual(request.get('status'), 'stopped')
            self.assertEqual(request.get('stopped_before_phase'), 'A')


if __name__ == '__main__':
    unittest.main()
