#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import tempfile
import unittest
import zipfile
from io import StringIO

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

from MediBot import MediBot_docx_index as docx_index
from MediCafe import __main__ as medicafe_main
from MediCafe.launcher import MediCafeOrchestrator


def _write_minimal_docx_package(path):
    with zipfile.ZipFile(path, 'w') as archive:
        archive.writestr('[Content_Types].xml', '<Types></Types>')
        archive.writestr('word/document.xml', '<w:document></w:document>')


class DocxIndexRetryCliTests(unittest.TestCase):

    def test_docx_index_retry_failed_command_is_accepted_by_main(self):
        original_argv = sys.argv
        try:
            sys.argv = ['python -m MediCafe', 'docx_index_retry_failed']
            with patch.object(medicafe_main, 'run_docx_index_retry_failed', return_value=0):
                self.assertEqual(medicafe_main.main(), 0)
        finally:
            sys.argv = original_argv

    def test_retry_failed_cli_no_failed_files_exits_successfully(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_index.save_docx_schedule_index(tmpdir, {
                'version': docx_index.INDEX_VERSION,
                'files': {},
                'schedules': {},
            })
            captured = StringIO()
            with patch.object(medicafe_main, '_load_local_storage_path_for_docx_index', return_value=tmpdir):
                with patch('sys.stdout', captured):
                    rc = medicafe_main.run_docx_index_retry_failed()

            self.assertEqual(rc, 0)
            self.assertIn('No failed DOCX parses found', captured.getvalue())
            self.assertIn('New DOCX files are not scanned', captured.getvalue())

    def test_retry_failed_cli_missing_files_do_not_parse_and_exit_successfully(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_index.save_docx_schedule_index(tmpdir, {
                'version': docx_index.INDEX_VERSION,
                'files': {
                    'gone.docx': {
                        'mtime': 1,
                        'size': 2,
                        'parse_failed': True,
                        'parse_error_type': 'empty_parse',
                        'parse_error_message': 'No patient data extracted from DOCX.',
                    }
                },
                'schedules': {},
            })
            captured = StringIO()
            with patch.object(medicafe_main, '_load_local_storage_path_for_docx_index', return_value=tmpdir):
                with patch('MediBot.MediBot_docx_index.update_docx_schedule_index') as update_mock:
                    with patch('sys.stdout', captured):
                        rc = medicafe_main.run_docx_index_retry_failed()

            self.assertEqual(rc, 0)
            self.assertFalse(update_mock.called)
            output = captured.getvalue()
            self.assertIn('Missing failed DOCX files skipped: 1', output)
            self.assertIn('No present failed DOCX files to retry.', output)

    def test_retry_failed_cli_present_file_updates_persisted_index(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'retry.docx')
            _write_minimal_docx_package(docx_path)
            stat_info = os.stat(docx_path)
            docx_index.save_docx_schedule_index(tmpdir, {
                'version': docx_index.INDEX_VERSION,
                'files': {
                    'retry.docx': {
                        'mtime': stat_info.st_mtime,
                        'size': stat_info.st_size,
                        'dates': [],
                        'parse_failed': True,
                        'parse_error_type': 'empty_parse',
                        'parse_error_message': 'No patient data extracted from DOCX.',
                    }
                },
                'schedules': {},
            })

            original_parse = docx_index.parse_docx
            try:
                def successful_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    return {'321': {'05-07-2026': ['H25.9', 'OS', '']}}

                docx_index.parse_docx = successful_parse
                captured = StringIO()
                with patch.object(medicafe_main, '_load_local_storage_path_for_docx_index', return_value=tmpdir):
                    with patch('sys.stdout', captured):
                        rc = medicafe_main.run_docx_index_retry_failed()
            finally:
                docx_index.parse_docx = original_parse

            self.assertEqual(rc, 0)
            output = captured.getvalue()
            self.assertIn('Present retried: 1', output)
            self.assertIn('Parsed: 1', output)
            self.assertIn('Remaining failures: 0', output)
            persisted = docx_index.load_docx_schedule_index(tmpdir)
            rec = persisted.get('files', {}).get('retry.docx', {})
            self.assertFalse(rec.get('parse_failed'))
            current = persisted.get('schedules', {}).get('05-07-2026', {}).get('current', {})
            self.assertEqual(current.get('source_file'), 'retry.docx')
            self.assertIn('321', current.get('patients', {}))

    def test_launcher_retry_failed_helper_invokes_cli_command(self):
        orch = MediCafeOrchestrator.__new__(MediCafeOrchestrator)
        calls = []
        notices = []
        orch.run_medicafe_command = lambda command: calls.append(command) or 0
        orch._pause_to_continue = lambda message='': None
        orch._record_notice = lambda level, message, **kwargs: notices.append((level, message))

        orch._run_docx_index_retry_failed()

        self.assertEqual(calls, ['docx_index_retry_failed'])
        self.assertEqual(notices, [])

    def test_troubleshooting_menu_lists_retry_failed_and_shifted_numeric_options(self):
        orch = MediCafeOrchestrator.__new__(MediCafeOrchestrator)
        captured = StringIO()
        with patch('sys.stdout', captured):
            orch._print_troubleshooting_menu_options()

        output = captured.getvalue()
        self.assertIn('10) Rebuild DOCX schedule index (force full parse)', output)
        self.assertIn('11) Retry failed DOCX schedule parses', output)
        self.assertIn('12) Emergency MediCafe rollback', output)
        self.assertIn('14) Update API client secret', output)
        self.assertIn('16) Cloud Readiness & Advanced Tools...', output)


if __name__ == '__main__':
    unittest.main()
