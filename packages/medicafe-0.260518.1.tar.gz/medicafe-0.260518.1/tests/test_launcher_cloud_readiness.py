#!/usr/bin/env python
"""
Unit tests for launcher Cloud Readiness flows.
Tests ensure_lab_ready wiring and Phase F advanced menu prompt/validation/confirm.
"""
from __future__ import print_function

import ast
import codecs
import calendar
import json
import os
import sys
import tempfile
import unittest

try:
    from io import StringIO
except ImportError:
    from StringIO import StringIO  # pyright: ignore[reportMissingModuleSource]

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _cloud_readiness_menu_mocks(cr):
    """MagicMock cr.* defaults are truthy; real menu probes deferred-send and recommendations."""
    cr.read_operator_deferred_support_send = MagicMock(return_value=None)
    cr.clear_operator_deferred_support_send = MagicMock(return_value=True)
    cr.write_operator_deferred_support_send = MagicMock(return_value=True)
    cr.read_operator_deferred_phase_d_dat_smoke = MagicMock(return_value=None)
    cr.clear_operator_deferred_phase_d_dat_smoke = MagicMock(return_value=True)
    cr.write_operator_deferred_phase_d_dat_smoke = MagicMock(return_value=True)
    cr.read_phase_d_dat_smoke_state = MagicMock(return_value={})
    cr.preview_historical_phase_d_reprocess = MagicMock(return_value=(True, '', {}))
    cr.run_historical_phase_d_reprocess = MagicMock(return_value=(True, '', {}))
    cr.write_dat_terminal_source_shape_rejects_report = MagicMock(return_value=(True, 'created', {}))
    cr.compute_operator_support_send_recommendation = MagicMock(return_value={
        'primary_send': 'system_health',
        'preferred_when_stable': 'system_health',
        'best_now_send': 'system_health',
        'summary_line': '',
        'why_lines': [],
        'why_summary': 'Use System Health Pack for broad lab context.',
        'pipeline_label': 'idle',
        'pipeline_running': False,
        'recommended_action_kind': 'send_bundle',
        'best_now_action_kind': 'send_bundle',
        'preferred_when_stable_action_kind': 'send_bundle',
        'recommended_report_kind': 'system_health_pack',
        'recommended_artifact_classes': [],
        'action_requires_confirmation': False,
        'action_preview': {},
        'action_reason_lines': [],
    })


def _make_orchestrator():
    """Create MediCafeOrchestrator with minimal session config."""
    from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
    args = MagicMock()
    args.skip_csv = False
    args.direct_action = None
    args.debug_mode = False
    args.auto_choice = None
    session = SessionConfig(args)
    return MediCafeOrchestrator(session)


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(payload, handle)


def _write_text(path, body):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, 'w', encoding='utf-8') as handle:
        handle.write(body)


def _write_shadow_report_fixture(lab_root, run_id, app_version, pipeline_ok=True, failed_phase=''):
    reports = os.path.join(lab_root, 'reports')
    paths = []
    for prefix, rid in (
            ('artifact_discovery_summary_', 'b-' + run_id),
            ('ingest_write_summary_', 'c-' + run_id),
            ('qa_canonical_summary_', 'd-' + run_id),
            ('projection_parity_summary_', 'e-' + run_id)):
        path = os.path.join(reports, prefix + rid + '.json')
        _write_json(path, {'run_id': rid})
        paths.append(path)
    _write_json(os.path.join(lab_root, 'diagnostics_state.json'), {
        'last_shadow_pipeline_run_id': run_id,
        'pipeline_state': 'idle',
    })
    _write_json(os.path.join(lab_root, 'run_cursor.json'), {})
    report = {
        'run_id': run_id,
        'machine_app_version': app_version,
        'pipeline_ok': bool(pipeline_ok),
        'failed_phase': failed_phase,
        'source_summary_paths': paths,
        'phase_run_ids': {
            'B': 'b-' + run_id,
            'C': 'c-' + run_id,
            'D': 'd-' + run_id,
            'E': 'e-' + run_id,
        },
    }
    _write_json(os.path.join(reports, 'shadow_run_report_' + run_id + '.json'), report)
    return report


def _historical_phase_d_autofollow_rec():
    return {
        'primary_send': 'run_evidence',
        'preferred_when_stable': 'run_evidence',
        'best_now_send': 'run_evidence',
        'summary_line': 'Re-evaluate historical Phase D rejects.',
        'why_lines': ['Historical rejects still exist.'],
        'why_summary': 'Historical rejects need re-evaluation.',
        'pipeline_label': 'idle',
        'pipeline_running': False,
        'recommended_action_kind': 'historical_phase_d_reprocess',
        'best_now_action_kind': 'historical_phase_d_reprocess',
        'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
        'recommended_report_kind': 'artifact_triage_pack',
        'recommended_artifact_classes': ['dat'],
        'action_requires_confirmation': False,
        'operator_manual_review_required': False,
        'autonomous_followthrough_allowed': True,
        'autonomous_followthrough_reason': 'historical_phase_d_reprocess_safe_autofollow',
        'operator_burden_policy': 'autonomous_when_stable',
        'action_preview': {'qa_policy_version': 'qa_v2', 'anchor_run_id': 'run-new'},
        'action_reason_lines': ['Historical DAT rejects still exist.'],
        'recommendation_anchor_run_id': 'run-new',
    }


class TestConsoleHeartbeatProgress(unittest.TestCase):
    """Console heartbeat progress text stays lightweight but informative."""

    def test_console_heartbeat_progress_renders_latest_stage(self):
        from MediCafe.launcher_cloud_readiness_mixin import _ConsoleHeartbeatProgress

        progress = _ConsoleHeartbeatProgress('sending system health pack')
        self.assertEqual(progress.render(), 'sending system health pack')
        progress.update('creating zip bundle')
        self.assertEqual(progress.render(), 'sending system health pack; creating zip bundle')


class _FakeSupportSendJobManager(object):

    def __init__(self, jobs, stale_audit=None):
        self.jobs = list(jobs or [])
        self.notice_state = {}
        self.notice_writes = []
        self.stale_audit = dict(stale_audit or {})
        self.preflight_calls = 0
        self.ensure_worker_calls = 0
        self.ensure_pending_worker_liveness_calls = 0
        self.shutdown_requests = []

    def list_jobs(self, limit=25, ensure_liveness=True):
        self.last_ensure_liveness = ensure_liveness
        return self.jobs[:limit]

    def preflight_reap_stale_running_jobs(self):
        self.preflight_calls += 1
        return []

    def _ensure_worker_locked(self):
        self.ensure_worker_calls += 1

    def ensure_pending_worker_liveness(self, reason=''):
        self.ensure_pending_worker_liveness_calls += 1
        self._ensure_worker_locked()
        return True

    def read_notice_state(self):
        return dict(self.notice_state)

    def write_notice_state(self, state):
        payload = dict(state or {})
        self.notice_state.update(payload)
        self.notice_writes.append(payload)

    def read_stale_preflight_audit(self):
        return dict(self.stale_audit)

    def request_job_shutdown_if_possible(self, job_id, reason='', request_id=''):
        self.shutdown_requests.append({
            'job_id': job_id,
            'reason': reason,
            'request_id': request_id,
        })
        for job in self.jobs:
            if str(job.get('job_id')) == str(job_id):
                status = str(job.get('status', '') or '')
                if status in ('queued', 'blocked'):
                    job['status'] = 'canceled'
                    return {
                        'ok': True,
                        'job_id': job_id,
                        'policy_reason': 'canceled_queued',
                        'status': 'canceled',
                        'message': 'Queued job canceled.',
                    }
                if status == 'running':
                    job['cancel_requested'] = True
                    return {
                        'ok': True,
                        'job_id': job_id,
                        'policy_reason': 'cancel_requested_running',
                        'status': 'running',
                        'message': 'Safe shutdown requested.',
                    }
        return {
            'ok': False,
            'job_id': job_id,
            'policy_reason': 'missing_job',
            'message': 'Job not found.',
        }


class TestTerminalOnlyBackgroundJobStatus(unittest.TestCase):
    """Background support-send UX stays in terminal/menu flows only."""

    def _active_manager(self):
        return _FakeSupportSendJobManager([{
            'job_id': 'ssj-active',
            'status': 'running',
            'progress_stage': 'sending',
        }])

    def test_enqueue_acknowledgement_mentions_open_launcher_and_pauses(self):
        manager = MagicMock()
        manager.enqueue = MagicMock(return_value={
            'accepted': True,
            'policy_decision': 'started',
            'policy_reason': 'started_immediately',
            'job_id': 'ssj-accepted',
        })
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        orch._prompt = MagicMock(return_value='')
        with patch('sys.stdout', new=StringIO()) as out:
            res = orch._try_enqueue_support_send('system_health', recommendation={})
        rendered = out.getvalue()
        self.assertTrue(res.get('ok'))
        self.assertIn('Background cloud job accepted: ssj-accepted', rendered)
        self.assertIn('Troubleshooting -> Cloud Readiness -> Background cloud jobs', rendered)
        self.assertIn('Keep MediCafe open until this job finishes.', rendered)
        self.assertNotIn('Policy:', rendered)
        orch._prompt.assert_called_once_with('Press Enter to continue...')

    def test_enqueue_acknowledgement_can_skip_pause_for_auto_flow(self):
        manager = MagicMock()
        manager.enqueue = MagicMock(return_value={
            'accepted': True,
            'policy_decision': 'started',
            'policy_reason': 'started_immediately',
            'job_id': 'ssj-accepted',
        })
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        orch._prompt = MagicMock(return_value='')
        with patch('sys.stdout', new=StringIO()) as out:
            res = orch._try_enqueue_support_send('system_health', recommendation={}, pause_for_ack=False)
        rendered = out.getvalue()
        self.assertTrue(res.get('ok'))
        self.assertIn('Background cloud job accepted: ssj-accepted', rendered)
        self.assertIn('Troubleshooting -> Cloud Readiness -> Background cloud jobs', rendered)
        self.assertNotIn('Policy:', rendered)
        orch._prompt.assert_not_called()

    def test_post_update_enqueue_acknowledgement_is_terminal_quiet(self):
        manager = MagicMock()
        manager.enqueue = MagicMock(return_value={
            'accepted': True,
            'policy_decision': 'started',
            'policy_reason': 'started_immediately',
            'job_id': 'ssj-accepted',
        })
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        orch._prompt = MagicMock(return_value='')
        with patch('sys.stdout', new=StringIO()) as out:
            res = orch._try_enqueue_support_send(
                'system_health',
                recommendation={},
                source='post_update_cloud_autofollow',
                operator_execution_mode='post_update_autofollow',
                pause_for_ack=False,
            )
        self.assertTrue(res.get('ok'))
        self.assertEqual(out.getvalue(), '')
        orch._prompt.assert_not_called()

    def test_active_job_banner_prints_compact_terminal_status(self):
        orch = _make_orchestrator()
        mgr = self._active_manager()
        orch._support_send_job_manager = MagicMock(return_value=mgr)
        with patch('sys.stdout', new=StringIO()) as out:
            shown = orch._print_background_support_send_status_banner()
        rendered = out.getvalue()
        self.assertTrue(shown)
        self.assertIn('[BACKGROUND CLOUD JOB ACTIVE]', rendered)
        self.assertIn('Latest job: ssj-active status=running stage=sending', rendered)
        self.assertIn('Operator status: sending to support', rendered)
        self.assertIn('Troubleshooting -> Cloud Readiness -> Background cloud jobs', rendered)
        self.assertGreaterEqual(mgr.preflight_calls, 1)
        self.assertGreaterEqual(mgr.ensure_worker_calls, 1)

    def test_passive_active_job_banner_skips_recovery_poll(self):
        orch = _make_orchestrator()
        mgr = self._active_manager()
        orch._support_send_job_manager = MagicMock(return_value=mgr)
        with patch('sys.stdout', new=StringIO()) as out:
            shown = orch._print_background_support_send_status_banner(passive=True)
        self.assertTrue(shown)
        self.assertIn('[BACKGROUND CLOUD JOB ACTIVE]', out.getvalue())
        self.assertEqual(mgr.preflight_calls, 0)
        self.assertEqual(mgr.ensure_worker_calls, 0)
        self.assertFalse(mgr.last_ensure_liveness)

    def test_try_enqueue_shp_promotes_existing_job_without_second_enqueue(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        orch = _make_orchestrator()
        policy = SupportSendQueuePolicy()
        mgr = MagicMock()
        mgr.policy = policy
        mgr.find_existing_job_for_dedup_key = MagicMock(return_value={
            'job_id': 'ssj-existing',
            'status': 'running',
        })
        mgr.enqueue = MagicMock()
        orch._support_send_job_manager = MagicMock(return_value=mgr)
        rec = {
            'layer1_readiness': {'layer1_current_blocker': 'phase_c_db'},
            'action_preview': {'anchor_run_id': 'run-a'},
        }
        with patch('sys.stdout', new=StringIO()) as out:
            res = orch._try_enqueue_support_send('system_health', recommendation=rec, pause_for_ack=False)
        self.assertTrue(res.get('ok'))
        mgr.enqueue.assert_not_called()
        mgr.preflight_reap_stale_running_jobs.assert_called_once()
        mgr._ensure_worker_locked.assert_called_once()
        self.assertIn('already in flight', out.getvalue())
        self.assertIn('ssj-existing', out.getvalue())

    def test_operator_status_labels_support_bundle_lifecycle(self):
        orch = _make_orchestrator()
        self.assertEqual(
            orch._support_send_operator_state({'status': 'queued', 'progress_stage': 'queued'}),
            'pending/queued')
        self.assertEqual(
            orch._support_send_operator_state({'status': 'running', 'progress_stage': 'creating zip bundle'}),
            'assembling bundle')
        self.assertEqual(
            orch._support_send_operator_state({'status': 'running', 'progress_stage': 'sending email to support'}),
            'sending to support')
        self.assertEqual(
            orch._support_send_operator_state({'status': 'succeeded', 'progress_stage': 'sending email to support'}),
            'sent/succeeded')
        self.assertEqual(
            orch._support_send_operator_state({
                'status': 'blocked',
                'progress_stage': 'single_flight_busy',
                'policy_reason': 'single_flight_busy',
            }),
            'waiting behind another job')
        self.assertEqual(
            orch._support_send_operator_state({
                'status': 'running',
                'progress_stage': 'sending email to support',
                'cancel_requested': True,
            }),
            'safe cancel requested')
        self.assertEqual(
            orch._support_send_operator_state({
                'status': 'failed',
                'delivery_issue_code': 'SUPPORT_DELIVERY_REAUTH_REQUIRED',
            }),
            'blocked/needs attention')

    def test_background_cloud_jobs_menu_prints_operator_summary(self):
        jobs = [
            {'job_id': 'ssj-queued', 'status': 'queued', 'progress_stage': 'queued'},
            {'job_id': 'ssj-zip', 'status': 'running', 'progress_stage': 'creating zip bundle'},
            {'job_id': 'ssj-sent', 'status': 'succeeded', 'progress_stage': 'sending email to support'},
            {'job_id': 'ssj-blocked', 'status': 'blocked', 'progress_stage': 'single_flight_busy'},
        ]
        manager = _FakeSupportSendJobManager(jobs)
        manager.jobs_dir = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'support_send_jobs')
        manager.retry = MagicMock()
        manager.cancel_job_if_possible = MagicMock()
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        orch._prompt = MagicMock(return_value='0')
        with patch('sys.stdout', new=StringIO()) as out:
            orch._background_cloud_jobs_menu()
        rendered = out.getvalue()
        self.assertIn('Status: pending/queued=1, assembling=1, succeeded/sent=1, blocked=1', rendered)
        self.assertIn('operator_status=pending/queued', rendered)
        self.assertIn('operator_status=assembling bundle', rendered)
        self.assertIn('operator_status=sent/succeeded', rendered)
        self.assertIn('operator_status=waiting behind another job', rendered)
        self.assertIn('what_this_means=waiting behind another job', rendered)
        self.assertIn('elapsed=', rendered)
        self.assertIn('heartbeat_age=', rendered)

    def test_background_cloud_jobs_menu_prints_stale_cleanup_summary(self):
        manager = _FakeSupportSendJobManager([], stale_audit={
            'written_at_utc': '2026-05-03T05:00:00Z',
            'stale_running_jobs_found': 2,
            'resolved_count': 1,
            'unresolved_count': 1,
            'termination_attempt_count': 1,
        })
        manager.jobs_dir = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'support_send_jobs')
        manager.retry = MagicMock()
        manager.cancel_job_if_possible = MagicMock()
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        orch._prompt = MagicMock(return_value='0')
        with patch('sys.stdout', new=StringIO()) as out:
            orch._background_cloud_jobs_menu()
        rendered = out.getvalue()
        self.assertIn('Support-send cleanup: stale blockers found=2, cleaned=1, termination attempts=1, still blocked=1', rendered)
        self.assertIn('support_send_stale_preflight_latest.txt / .json', rendered)

    def test_completion_notice_prints_once_and_updates_notice_state(self):
        manager = _FakeSupportSendJobManager([{
            'job_id': 'ssj-done',
            'status': 'succeeded',
            'finished_at_utc': '2026-04-11T01:02:03Z',
            'result_message': 'sent',
        }])
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        with patch('sys.stdout', new=StringIO()) as first:
            orch._try_print_background_support_send_notice()
        with patch('sys.stdout', new=StringIO()) as second:
            orch._try_print_background_support_send_notice()
        self.assertIn('[NOTICE] Background cloud job ssj-done: succeeded', first.getvalue())
        self.assertIn('sent', first.getvalue())
        self.assertEqual(second.getvalue(), '')
        self.assertEqual(manager.notice_state.get('last_seen_job_id'), 'ssj-done')
        self.assertEqual(manager.notice_state.get('last_seen_finished_at_utc'), '2026-04-11T01:02:03Z')

    def test_stale_cleanup_notice_includes_pid_reason_and_audit_summary(self):
        manager = _FakeSupportSendJobManager([{
            'job_id': 'ssj-stale',
            'status': 'failed',
            'finished_at_utc': '2026-05-03T05:01:00Z',
            'result_message': 'Stale running support-send job reaped before queue/exit preflight.',
            'policy_reason': 'stale_detached_worker_terminated',
            'worker_pid': '424242',
            'stale_reaped_at_utc': '2026-05-03T05:01:00Z',
        }], stale_audit={
            'written_at_utc': '2026-05-03T05:01:00Z',
            'stale_running_jobs_found': 1,
            'resolved_count': 1,
            'unresolved_count': 0,
            'termination_attempt_count': 1,
        })
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        with patch('sys.stdout', new=StringIO()) as out:
            orch._try_print_background_support_send_notice()
        rendered = out.getvalue()
        self.assertIn('[NOTICE] Background cloud job ssj-stale: failed', rendered)
        self.assertIn('Cleanup: worker_pid=424242 reason=stale_detached_worker_terminated', rendered)
        self.assertIn('Support-send cleanup: stale blockers found=1, cleaned=1, termination attempts=1', rendered)

    def test_exit_guard_defaults_to_stay_open_while_active(self):
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=self._active_manager())
        orch._prompt = MagicMock(side_effect=['', ''])
        with patch('sys.stdout', new=StringIO()) as out:
            allowed = orch._confirm_exit_with_active_support_send_jobs()
        self.assertFalse(allowed)
        self.assertIn('Closing MediCafe now may interrupt evidence delivery.', out.getvalue())
        self.assertIn('Exit canceled.', out.getvalue())

    def test_exit_guard_allows_explicit_yes(self):
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=self._active_manager())
        orch._prompt = MagicMock(return_value='yes')
        with patch('sys.stdout', new=StringIO()):
            allowed = orch._confirm_exit_with_active_support_send_jobs()
        self.assertTrue(allowed)

    def test_exit_guard_allows_short_lowercase_y(self):
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=self._active_manager())
        orch._prompt = MagicMock(return_value='y')
        with patch('sys.stdout', new=StringIO()):
            allowed = orch._confirm_exit_with_active_support_send_jobs()
        self.assertTrue(allowed)

    def test_refresh_post_update_state_marks_missing_job_stale_after_grace(self):
        orch = _make_orchestrator()
        state = {
            'installed_version': '1.1.0',
            'status': 'running_send',
            'stage': 'sending',
            'job_id': 'ssj-missing',
            'updated_at_utc': '2026-04-11T01:02:03Z',
        }
        with patch.object(orch, '_read_post_update_autofollow_state', return_value=state), \
                patch.object(orch, '_find_background_support_send_job', return_value={}), \
                patch.object(orch, '_post_update_autofollow_missing_job_stale_sec', return_value=30), \
                patch('MediCafe.launcher_cloud_readiness_mixin.time.time', return_value=calendar.timegm((2026, 4, 11, 1, 3, 33, 0, 0, 0))), \
                patch.object(orch, '_patch_post_update_autofollow_state', MagicMock(return_value={'status': 'stale'})) as p_patch:
            refreshed = orch._refresh_post_update_autofollow_state()
        self.assertEqual(refreshed.get('status'), 'stale')
        updates = p_patch.call_args[0][0]
        self.assertEqual(str(updates.get('status')), 'stale')
        self.assertEqual(str(updates.get('last_reason')), 'missing_job_stale')

    def test_refresh_post_update_state_autowakes_queued_job_without_manual_status_action(self):
        orch = _make_orchestrator()
        state = {
            'installed_version': '1.1.0',
            'status': 'running_send',
            'stage': 'sending',
            'job_id': 'ssj-old-post-update',
            'updated_at_utc': '2026-04-11T01:02:03Z',
        }
        manager = _FakeSupportSendJobManager([{
            'job_id': 'ssj-old-post-update',
            'status': 'queued',
            'progress_stage': 'queued',
        }])
        orch._support_send_job_manager = MagicMock(return_value=manager)
        with patch.object(orch, '_read_post_update_autofollow_state', return_value=state), \
                patch.object(orch, '_patch_post_update_autofollow_state', MagicMock(return_value={
                    'status': 'queued_send',
                    'job_id': 'ssj-old-post-update',
                })) as p_patch:
            refreshed = orch._refresh_post_update_autofollow_state()
        self.assertEqual(refreshed.get('status'), 'queued_send')
        self.assertEqual(manager.ensure_pending_worker_liveness_calls, 1)
        self.assertEqual(manager.ensure_worker_calls, 1)
        updates = p_patch.call_args[0][0]
        self.assertEqual(str(updates.get('status')), 'queued_send')
        self.assertEqual(str(updates.get('job_id')), 'ssj-old-post-update')

    def test_exit_guard_hard_blocks_post_update_autofollow(self):
        orch = _make_orchestrator()
        orch._prompt = MagicMock(side_effect=['', ''])
        state = {
            'installed_version': '1.1.0',
            'status': 'running_send',
            'stage': 'sending',
            'job_id': 'ssj-active',
        }
        with patch.object(orch, '_refresh_post_update_autofollow_state', return_value=state):
            with patch('sys.stdout', new=StringIO()) as out:
                allowed = orch._confirm_exit_with_active_support_send_jobs()
        self.assertFalse(allowed)
        self.assertIn('Post-update developer evidence is still being generated', out.getvalue())
        self.assertIn('Job: ssj-active', out.getvalue())

    def test_exit_guard_wait_choice_prints_live_status_snapshot(self):
        orch = _make_orchestrator()
        orch._prompt = MagicMock(side_effect=['1', ''])
        state = {
            'installed_version': '1.1.0',
            'status': 'running_send',
            'stage': 'sending email to support',
            'job_id': 'ssj-active',
        }
        manager = _FakeSupportSendJobManager([{
            'job_id': 'ssj-active',
            'status': 'running',
            'progress_stage': 'sending email to support',
            'heartbeat_at_utc': '2026-04-11T01:02:03Z',
            'started_at_utc': '2026-04-11T01:00:00Z',
            'progress_events': [{
                'stage': 'sending email to support',
                'at_utc': '2026-04-11T01:02:03Z',
                'elapsed_since_start_sec': 123,
            }],
        }])
        orch._support_send_job_manager = MagicMock(return_value=manager)
        with patch.object(orch, '_refresh_post_update_autofollow_state', return_value=state), \
                patch.object(orch, '_post_update_operator_watch_sec', return_value=0), \
                patch('sys.stdout', new=StringIO()) as out:
            allowed = orch._confirm_exit_with_active_support_send_jobs()
        rendered = out.getvalue()
        self.assertFalse(allowed)
        self.assertIn('[WAIT] MediCafe is staying open and checking background cloud work.', rendered)
        self.assertIn('Still waiting: background cloud work is active.', rendered)
        self.assertIn('Latest status:', rendered)
        self.assertIn('Operator status: sending to support', rendered)
        self.assertIn('Last progress: sending email to support', rendered)
        self.assertIn('Returning to the menu now.', rendered)

    def test_exit_guard_post_update_override_proceeds_when_job_canceled(self):
        orch = _make_orchestrator()
        orch._prompt = MagicMock(side_effect=['3', 'OVERRIDE'])
        state = {
            'installed_version': '1.1.0',
            'status': 'running_send',
            'stage': 'sending',
            'job_id': 'ssj-active',
        }
        manager = MagicMock()
        manager.cancel_job_if_possible = MagicMock(return_value={
            'ok': True,
            'policy_reason': 'canceled_queued',
            'message': 'Queued job canceled.',
        })
        manager.list_jobs = MagicMock(return_value=[])
        orch._support_send_job_manager = MagicMock(return_value=manager)
        with patch.object(orch, '_refresh_post_update_autofollow_state', return_value=state), \
                patch.object(orch, '_patch_post_update_autofollow_state', MagicMock()) as p_patch:
            with patch('sys.stdout', new=StringIO()) as out:
                allowed = orch._confirm_exit_with_active_support_send_jobs()
        self.assertTrue(allowed)
        rendered = out.getvalue()
        self.assertIn('[FORCE OVERRIDE]', rendered)
        self.assertIn('Queued background job was canceled.', rendered)
        p_patch.assert_called_once()
        updates = p_patch.call_args[0][0]
        self.assertEqual(str(updates.get('last_reason')), 'manual_override_forced')
        self.assertEqual(str(updates.get('stage')), 'manual_override')
        self.assertEqual(str(updates.get('manual_override_mode')), 'forced')
        manager.cancel_job_if_possible.assert_called_once_with(
            'ssj-active',
            reason='post_update_manual_override',
        )

    def test_exit_guard_post_update_override_running_job_requires_second_confirm(self):
        orch = _make_orchestrator()
        orch._prompt = MagicMock(side_effect=['3', 'OVERRIDE', 'YES'])
        state = {
            'installed_version': '1.1.0',
            'status': 'running_send',
            'stage': 'sending',
            'job_id': 'ssj-active',
        }
        manager = MagicMock()
        manager.cancel_job_if_possible = MagicMock(return_value={
            'ok': False,
            'policy_reason': 'running_not_cancelable',
            'message': 'Cannot safely cancel a running job; it may still complete.',
        })
        manager.list_jobs = MagicMock(return_value=[{
            'job_id': 'ssj-active',
            'status': 'running',
            'progress_stage': 'sending',
        }])
        orch._support_send_job_manager = MagicMock(return_value=manager)
        with patch.object(orch, '_refresh_post_update_autofollow_state', return_value=state), \
                patch.object(orch, '_patch_post_update_autofollow_state', MagicMock()) as p_patch:
            with patch('sys.stdout', new=StringIO()) as out:
                allowed = orch._confirm_exit_with_active_support_send_jobs()
        self.assertTrue(allowed)
        self.assertIn('Warning: A background send may still be running', out.getvalue())
        self.assertIn('Current background job after override:', out.getvalue())
        self.assertIn('Override status:', out.getvalue())
        updates = p_patch.call_args[0][0]
        self.assertEqual(str(updates.get('last_reason')), 'manual_override_running_job_continues')

    def test_exit_guard_safe_cancel_running_job_prints_checkpoint_status(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            state_path = os.path.join(lab, 'reports', 'post_update_cloud_autofollow_state.json')
            _write_json(state_path, {
                'installed_version': '1.1.0',
                'status': 'running_send',
                'stage': 'sending email to support',
                'job_id': 'ssj-active',
            })
            manager = _FakeSupportSendJobManager([{
                'job_id': 'ssj-active',
                'status': 'running',
                'progress_stage': 'sending email to support',
                'heartbeat_at_utc': '2026-04-11T01:02:03Z',
                'started_at_utc': '2026-04-11T01:00:00Z',
            }])
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._support_send_job_manager = MagicMock(return_value=manager)
                orch._prompt = MagicMock(side_effect=['2', ''])
                with patch.object(orch, '_post_update_safe_cancel_grace_sec', return_value=0), \
                        patch('sys.stdout', new=StringIO()) as out:
                    allowed = orch._confirm_exit_with_active_support_send_jobs()
            rendered = out.getvalue()
            self.assertFalse(allowed)
            self.assertIn('[SAFE CANCEL] Requesting background cloud jobs to stop at safe checkpoints...', rendered)
            self.assertIn('Cancel requested; waiting for the running job to reach a safe checkpoint.', rendered)
            self.assertIn('Waiting for a safe checkpoint; MediCafe is checking the background job.', rendered)
            self.assertIn('Operator status: safe cancel requested', rendered)
            self.assertIn('Cancel: safe cancel requested', rendered)

    def test_exit_guard_safe_cancel_queued_job_proceeds_without_force(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            state_path = os.path.join(lab, 'reports', 'post_update_cloud_autofollow_state.json')
            _write_json(state_path, {
                'installed_version': '1.1.0',
                'status': 'queued_send',
                'stage': 'queued',
                'job_id': 'ssj-active',
            })
            manager = _FakeSupportSendJobManager([{
                'job_id': 'ssj-active',
                'status': 'queued',
                'progress_stage': 'queued',
            }])
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._support_send_job_manager = MagicMock(return_value=manager)
                orch._prompt = MagicMock(return_value='2')
                with patch('sys.stdout', new=StringIO()) as out:
                    allowed = orch._confirm_exit_with_active_support_send_jobs()
            self.assertTrue(allowed)
            rendered = out.getvalue()
            self.assertIn('Safely cancel background cloud jobs', rendered)
            self.assertIn('Safe cancel completed', rendered)
            self.assertEqual(len(manager.shutdown_requests), 1)
            with open(state_path, 'r', encoding='utf-8') as handle:
                final_state = json.load(handle)
            self.assertEqual(str(final_state.get('stage')), 'safe_cancel')
            self.assertEqual(str(final_state.get('shutdown_status')), 'terminal')
            self.assertEqual(str(final_state.get('last_reason')), 'canceled_queued')
            self.assertTrue(os.path.isfile(os.path.join(lab, 'reports', 'cloud_work_shutdown_request.json')))

    def test_post_update_version_mismatch_starts_fresh_pipeline_without_send(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            _write_shadow_report_fixture(lab, 'run-old', '1.0.0')
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            cr.run_shadow_pipeline = MagicMock(return_value=(True, 'started', {'status': 'started'}))
            cr.compute_operator_support_send_recommendation = MagicMock(return_value={})
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._start_post_update_autofollow_watchdog = MagicMock(return_value=True)
                orch._try_enqueue_support_send = MagicMock(return_value={'handled': True, 'ok': True})
                ok = orch._run_post_update_cloud_autofollow('1.1.0', '1.0.0')
            self.assertTrue(ok)
            cr.run_shadow_pipeline.assert_called_once()
            cr.compute_operator_support_send_recommendation.assert_not_called()
            orch._try_enqueue_support_send.assert_not_called()
            with open(os.path.join(lab, 'reports', 'post_update_cloud_autofollow_state.json'), 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            self.assertEqual(state.get('status'), 'waiting_for_fresh_pipeline')
            self.assertEqual(state.get('post_update_evidence_freshness_status'), 'stale')
            self.assertEqual(state.get('post_update_freshness_blocking_reason'), 'machine_app_version_mismatch')

    def test_post_update_fresh_report_recomputes_and_queues_send(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            _write_shadow_report_fixture(lab, 'run-new', '1.1.0')
            rec = {
                'primary_send': 'run_evidence',
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
                'recommended_action_kind': 'send_bundle',
                'preferred_when_stable_action_kind': 'send_bundle',
                'best_now_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'pipeline_running': False,
                'action_preview': {'anchor_run_id': 'run-new'},
                'recommendation_anchor_run_id': 'run-new',
            }
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            cr.run_shadow_pipeline = MagicMock(return_value=(True, 'unexpected', {}))
            cr.compute_operator_support_send_recommendation = MagicMock(return_value=rec)
            cr.check_pipeline_running_for_action = MagicMock(return_value=(False, ''))
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._start_post_update_autofollow_watchdog = MagicMock(return_value=True)
                orch._try_enqueue_support_send = MagicMock(return_value={'handled': True, 'ok': True})
                ok = orch._run_post_update_cloud_autofollow('1.1.0', '1.0.0')
            self.assertTrue(ok)
            cr.run_shadow_pipeline.assert_not_called()
            self.assertTrue(cr.compute_operator_support_send_recommendation.called)
            orch._try_enqueue_support_send.assert_called()
            self.assertEqual(orch._try_enqueue_support_send.call_args[0][0], 'run_evidence')

    def test_post_update_autofollow_historical_reprocess_starts_action(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            cr.compute_operator_support_send_recommendation = MagicMock(
                return_value=_historical_phase_d_autofollow_rec())
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._ensure_post_update_fresh_evidence = MagicMock(return_value=True)
                orch._start_post_update_autofollow_watchdog = MagicMock(return_value=True)
                orch._run_historical_phase_d_reprocess_action = MagicMock(return_value=True)
                ok = orch._run_post_update_cloud_autofollow('1.1.0', '1.0.0')
            self.assertTrue(ok)
            orch._run_historical_phase_d_reprocess_action.assert_called_once()
            with open(os.path.join(lab, 'reports', 'post_update_cloud_autofollow_state.json'), 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            self.assertEqual(state.get('status'), 'running_diagnostic_action')
            self.assertEqual(state.get('stage'), 'historical_phase_d_reprocess')
            self.assertEqual(state.get('diagnostic_action_id'), 'historical_phase_d_reprocess')
            self.assertEqual(state.get('last_reason'), 'diagnostic_action_started')

    def test_post_update_autofollow_historical_exception_stamps_terminal_failure(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            cr.compute_operator_support_send_recommendation = MagicMock(
                return_value=_historical_phase_d_autofollow_rec())
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._ensure_post_update_fresh_evidence = MagicMock(return_value=True)
                orch._run_historical_phase_d_reprocess_action = MagicMock(side_effect=RuntimeError('boom'))
                ok = orch._run_post_update_cloud_autofollow('1.1.0', '1.0.0')
            self.assertFalse(ok)
            with open(os.path.join(lab, 'reports', 'post_update_cloud_autofollow_state.json'), 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            self.assertEqual(state.get('status'), 'failed')
            self.assertEqual(state.get('stage'), 'historical_phase_d_reprocess')
            self.assertEqual(state.get('recommendation_action_kind'), 'historical_phase_d_reprocess')
            self.assertEqual(state.get('last_reason'), 'followthrough_exception:RuntimeError')

    def test_post_update_active_pipeline_waits_for_fresh_pipeline(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            _write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_shadow_pipeline_run_id': 'run-old',
                'active_run_id': 'run-active',
                'pipeline_state': 'running',
            })
            _write_json(os.path.join(lab, 'run_cursor.json'), {})
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            cr.run_shadow_pipeline = MagicMock(return_value=(True, 'unexpected', {}))
            cr.compute_operator_support_send_recommendation = MagicMock(return_value={})
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._start_post_update_autofollow_watchdog = MagicMock(return_value=True)
                ok = orch._run_post_update_cloud_autofollow('1.1.0', '1.0.0')
            self.assertTrue(ok)
            cr.run_shadow_pipeline.assert_not_called()
            with open(os.path.join(reports, 'post_update_cloud_autofollow_state.json'), 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            self.assertEqual(state.get('status'), 'waiting_for_fresh_pipeline')
            self.assertEqual(state.get('post_update_evidence_freshness_status'), 'live_status')
            self.assertEqual(state.get('post_update_fresh_pipeline_status'), 'running')

    def test_post_update_launch_failure_queues_unavailable_system_health(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            _write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_shadow_pipeline_run_id': 'run-old',
                'pipeline_state': 'idle',
            })
            _write_json(os.path.join(lab, 'run_cursor.json'), {})
            cr = MagicMock()
            cr.resolve_lab_root = MagicMock(return_value=lab)
            cr.run_shadow_pipeline = MagicMock(return_value=(False, 'launch failed', {}))
            cr.check_pipeline_running_for_action = MagicMock(return_value=(False, ''))
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._start_post_update_autofollow_watchdog = MagicMock(return_value=True)
                orch._try_enqueue_support_send = MagicMock(return_value={'handled': True, 'ok': True})
                ok = orch._run_post_update_cloud_autofollow('1.1.0', '1.0.0')
            self.assertTrue(ok)
            orch._try_enqueue_support_send.assert_called()
            args, kwargs = orch._try_enqueue_support_send.call_args
            self.assertEqual(args[0], 'system_health')
            self.assertEqual(kwargs.get('recommendation_action_kind'), 'post_update_fresh_pipeline_unavailable')
            self.assertTrue(os.path.isfile(os.path.join(
                lab, 'reports', 'post_update_autofollow_diagnostic_attachment.txt')))

    def test_post_update_fresh_pipeline_timeout_queues_unavailable_bundle(self):
        orch = _make_orchestrator()
        state = {
            'installed_version': '1.1.0',
            'previous_installed_version': '1.0.0',
            'status': 'waiting_for_fresh_pipeline',
            'stage': 'waiting_for_fresh_pipeline',
            'started_at_utc': '2026-04-11T01:00:00Z',
            'updated_at_utc': '2026-04-11T01:00:00Z',
        }
        assessment = {
            'post_update_evidence_freshness_status': 'stale',
            'post_update_freshness_blocking_reason': 'machine_app_version_mismatch',
            'post_update_fresh_pipeline_status': 'idle',
        }
        with patch.object(orch, '_assess_post_update_evidence_freshness', return_value=assessment), \
                patch.object(orch, '_patch_post_update_freshness_fields', MagicMock()), \
                patch.object(orch, '_post_update_autofollow_stale_sec', return_value=60), \
                patch('MediCafe.launcher_cloud_readiness_mixin.time.time', return_value=calendar.timegm((2026, 4, 11, 1, 2, 30, 0, 0, 0))), \
                patch.object(orch, '_queue_post_update_fresh_pipeline_unavailable', MagicMock(return_value={'status': 'queued_send'})) as p_queue:
            refreshed = orch._refresh_post_update_fresh_pipeline_wait(state)
        self.assertEqual(refreshed.get('status'), 'queued_send')
        p_queue.assert_called_once()
        self.assertEqual(p_queue.call_args[0][2], 'fresh_pipeline_timeout')

    def test_main_menu_redraw_prints_active_job_banner(self):
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=self._active_manager())
        with patch.object(orch, '_maybe_offer_startup_assistant', return_value=False), \
                patch.object(orch, '_get_menu_choice', return_value='exit'), \
                patch.object(orch, '_dispatch_launcher_action', return_value='exit'), \
                patch.object(orch, '_confirm_exit_with_active_support_send_jobs', return_value=True), \
                patch.object(orch, '_mark_clean_exit'), \
                patch.object(orch, '_join_payer_list_thread'), \
                patch('sys.stdout', new=StringIO()) as out:
            orch.main_menu_loop(show_header_on_first=True)
        self.assertIn('[BACKGROUND CLOUD JOB ACTIVE]', out.getvalue())

    def test_troubleshooting_menu_redraw_prints_active_job_banner(self):
        orch = _make_orchestrator()
        orch._support_send_job_manager = MagicMock(return_value=self._active_manager())
        orch._prompt = MagicMock(return_value='0')
        with patch('sys.stdout', new=StringIO()) as out:
            orch.troubleshooting_menu()
        self.assertIn('[BACKGROUND CLOUD JOB ACTIVE]', out.getvalue())

    def test_troubleshooting_support_selftest_debounce_blocks_second_send(self):
        from MediCafe import launcher as launcher_mod
        orch = _make_orchestrator()
        orch._prompt = MagicMock(side_effect=['1', '1', '0'])
        idx = {'i': 0}
        seq = [1000.0, 1005.0, 1010.0]

        def tf():
            i = idx['i']
            if i < len(seq):
                v = seq[i]
                idx['i'] = i + 1
                return v
            return 3000.0

        call_count = {'n': 0}

        def fake_run(cmd, extra_args=None, return_subprocess_ran=False):
            self.assertEqual(cmd, 'send_error_report')
            call_count['n'] += 1
            if return_subprocess_ran:
                return (0, True)
            return 0

        with patch.object(orch, '_clear_console'), \
                patch.object(orch, '_print_legacy_banner'), \
                patch.object(orch, '_print_troubleshooting_group'), \
                patch.object(orch, '_pause_to_continue'), \
                patch.object(orch, '_try_print_background_support_send_notice'), \
                patch.object(orch, '_print_background_support_send_status_banner'), \
                patch.object(launcher_mod.time, 'time', side_effect=tf), \
                patch.object(orch, 'run_medicafe_command', side_effect=fake_run), \
                patch('sys.stdout', new=StringIO()) as out:
            orch.troubleshooting_menu()
        self.assertEqual(call_count['n'], 1)
        text = out.getvalue()
        self.assertIn('Already sent recently', text)
        self.assertIn('finished without reporting an error', text)

    def test_troubleshooting_support_selftest_debounce_shows_problem_hint_after_failed_run(self):
        from MediCafe import launcher as launcher_mod
        orch = _make_orchestrator()
        orch._prompt = MagicMock(side_effect=['1', '1', '0'])
        idx = {'i': 0}
        seq = [1000.0, 1005.0, 1010.0]

        def tf():
            i = idx['i']
            if i < len(seq):
                v = seq[i]
                idx['i'] = i + 1
                return v
            return 3000.0

        call_count = {'n': 0}

        def fake_run(cmd, extra_args=None, return_subprocess_ran=False):
            call_count['n'] += 1
            if return_subprocess_ran:
                return (1, True)
            return 1

        with patch.object(orch, '_clear_console'), \
                patch.object(orch, '_print_legacy_banner'), \
                patch.object(orch, '_print_troubleshooting_group'), \
                patch.object(orch, '_pause_to_continue'), \
                patch.object(orch, '_try_print_background_support_send_notice'), \
                patch.object(orch, '_print_background_support_send_status_banner'), \
                patch.object(launcher_mod.time, 'time', side_effect=tf), \
                patch.object(orch, 'run_medicafe_command', side_effect=fake_run), \
                patch('sys.stdout', new=StringIO()) as out:
            orch.troubleshooting_menu()
        self.assertEqual(call_count['n'], 1)
        self.assertIn('reported a problem', out.getvalue())

    def test_run_medicafe_command_preflight_abort_subprocess_not_ran_tuple(self):
        orch = _make_orchestrator()
        with patch.object(orch, '_run_preflight_if_needed', return_value=False):
            rc, ran = orch.run_medicafe_command('send_error_report', return_subprocess_ran=True)
        self.assertEqual(rc, 1)
        self.assertFalse(ran)

    def test_cloud_readiness_menu_redraw_prints_active_job_banner(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._support_send_job_manager = MagicMock(return_value=self._active_manager())
            orch._prompt = MagicMock(return_value='0')
            with patch('sys.stdout', new=StringIO()) as out:
                orch._cloud_readiness_advanced_menu()
        self.assertIn('[BACKGROUND CLOUD JOB ACTIVE]', out.getvalue())

    def test_terminal_only_status_code_does_not_use_focus_apis(self):
        """AST scan of Call targets; does not flag comments/strings or dynamic getattr dispatch."""
        forbidden = ('MessageBox', 'SetForegroundWindow', 'ShowWindow', 'AppActivate', 'Shell_NotifyIcon')
        paths = [
            os.path.join(_PROJECT_ROOT, 'MediCafe', 'launcher.py'),
            os.path.join(_PROJECT_ROOT, 'MediCafe', 'launcher_cloud_readiness_mixin.py'),
        ]
        for path in paths:
            with codecs.open(path, 'r', 'utf-8-sig') as handle:
                tree = ast.parse(handle.read())
            offenders = []
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                for sub in ast.walk(node.func):
                    name = None
                    if isinstance(sub, ast.Name):
                        name = sub.id
                    elif isinstance(sub, ast.Attribute):
                        name = sub.attr
                    if not name:
                        continue
                    for token in forbidden:
                        if token in name:
                            offenders.append((getattr(sub, 'lineno', 0), token, name))
            self.assertFalse(
                offenders,
                'Forbidden focus/UI API referenced in call at {0}: {1}'.format(path, offenders[:20]),
            )


class TestStrictRebuildFlow(unittest.TestCase):
    """Strict rebuild (Phase F advanced option 2) prompt/validation/confirm."""

    def test_strict_empty_input_cancels(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
        cr.run_phase_f_manual_for_run_id.assert_not_called()

    def test_strict_valid_run_id_calls_service(self):
        from MediCafe import launcher as launcher_mod
        valid_rid = '20250216-120000-abc12345'
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock(return_value=(True, '', None))
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', valid_rid, '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_called_once()
            call_args = cr.run_phase_f_manual_for_run_id.call_args[0]
            self.assertEqual(call_args[3], valid_rid)

    def test_strict_non_standard_decline_cancels(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock()
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', 'non-standard-id', 'n', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_not_called()

    def test_strict_non_standard_accept_calls_service(self):
        from MediCafe import launcher as launcher_mod
        non_standard_rid = 'custom-run-123'
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock(return_value=(True, '', None))
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', non_standard_rid, 'y', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_called_once()
            call_args = cr.run_phase_f_manual_for_run_id.call_args[0]
            self.assertEqual(call_args[3], non_standard_rid)


class TestCloudReadinessAdvancedMenuEnsureLabReady(unittest.TestCase):
    """_cloud_readiness_advanced_menu calls ensure_lab_ready before rendering."""

    def test_calls_ensure_lab_ready_once_before_rendering(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['0']
                orch = _make_orchestrator()
                orch._cloud_readiness_advanced_menu()
        cr.ensure_lab_ready.assert_called_once()
        call_args = cr.ensure_lab_ready.call_args[0]
        self.assertEqual(call_args[0], orch.repo_root)
        self.assertEqual(call_args[1], orch.python_exe)
        self.assertEqual(call_args[2], orch.environment)
        self.assertTrue(cr.ensure_lab_ready.call_args[1].get('skip_recent_success_autopipeline'))

    def test_menu_renders_on_failure_warning_printed(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(False, 'Phase A bootstrap failed', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch.object(launcher_mod.MediCafeOrchestrator, '_clear_console'):
                    with patch.object(launcher_mod.MediCafeOrchestrator, '_print_legacy_banner'):
                        with patch.object(launcher_mod.MediCafeOrchestrator, '_print_troubleshooting_group'):
                            with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                                mock_prompt.side_effect = ['0']
                                orch = _make_orchestrator()
                                orch._cloud_readiness_advanced_menu()
        cr.get_health_lines.assert_called()
        warning_lines = [p for p in printed if '[WARNING]' in p and 'Phase A bootstrap failed' in p]
        self.assertEqual(len(warning_lines), 1)

    def test_manual_pipeline_letter_alias_b_triggers_phase_b(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_phase_b_discovery_manual = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['B', '', '0']
                orch._cloud_readiness_advanced_menu()
        orch._run_phase_b_discovery_manual.assert_called_once()


    def test_triage_option_runs_and_prints_hints(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.run_system_health_triage = MagicMock(return_value=(
            True,
            'System health triage completed.',
            {'hints': ['XP QA reject ratio: 0.21 (warn)', 'Hint: review latest qa_reject_samples_*.jsonl for unresolved QA rejects.']},
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                    mock_prompt.side_effect = ['9', '1', '', '0', '0']
                    orch = _make_orchestrator()
                    orch._cloud_readiness_advanced_menu()
        cr.run_system_health_triage.assert_called_once()
        rendered = '\n'.join(printed)
        self.assertIn('Manual validation quick hints', rendered)
        self.assertIn('unresolved QA rejects', rendered)

    def test_system_health_triage_honors_medicafe_cloud_required(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.run_system_health_triage = MagicMock(return_value=(True, 'ok', {}))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.dict(os.environ, {'MEDICAFE_CLOUD_REQUIRED': 'true'}, clear=False):
                orch._run_system_health_triage()
        kwargs = cr.run_system_health_triage.call_args[1]
        self.assertTrue(kwargs.get('cloud_required'))

    def test_other_support_sends_system_health_queues_background_job(self):
        """Menu path queues via support send manager; does not invoke synchronous cloud_readiness send."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.send_latest_system_health_pack = MagicMock(return_value=(False, 'send failed', {}))
        cr.open_report_delivery_status = MagicMock(return_value=(True, '', os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'report_delivery_status.txt')))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._try_enqueue_support_send = MagicMock(return_value={'handled': True, 'ok': True})
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                # 9 -> Advanced; 4 -> Other support sends; 1 -> system health send; pauses and backs.
                mock_prompt.side_effect = ['9', '4', '1', '', '0', '0', '0']
                orch._cloud_readiness_advanced_menu()
        orch._try_enqueue_support_send.assert_called()
        cr.send_latest_system_health_pack.assert_not_called()
        cr.open_report_delivery_status.assert_not_called()

    def test_send_latest_system_health_pack_failure_opens_delivery_diagnostics(self):
        """Direct helper still runs sync send path and opens diagnostics on failure."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.send_latest_system_health_pack = MagicMock(return_value=(False, 'send failed', {}))
        cr.open_report_delivery_status = MagicMock(return_value=(True, '', os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'report_delivery_status.txt')))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            ok = orch._send_latest_system_health_pack()
        self.assertFalse(ok)
        cr.send_latest_system_health_pack.assert_called_once()
        cr.open_report_delivery_status.assert_called_once()

    def test_send_system_health_pack_passes_progress_callback(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.send_latest_system_health_pack = MagicMock(return_value=(True, '', {}))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            ok = orch._send_latest_system_health_pack()
        self.assertTrue(ok)
        kwargs = cr.send_latest_system_health_pack.call_args[1]
        progress_callback = kwargs.get('progress_callback')
        self.assertTrue(callable(progress_callback))
        self.assertEqual(kwargs.get('send_source'), 'manual_system_health_pack')
        self.assertEqual(kwargs.get('operator_execution_mode'), 'explicit_send_menu')
        progress_callback('creating zip bundle')

    def test_send_run_evidence_bundle_passes_progress_callback(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.send_latest_run_evidence_bundle = MagicMock(return_value=(True, '', {}))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            ok = orch._send_latest_run_evidence_bundle()
        self.assertTrue(ok)
        kwargs = cr.send_latest_run_evidence_bundle.call_args[1]
        progress_callback = kwargs.get('progress_callback')
        self.assertTrue(callable(progress_callback))
        self.assertEqual(kwargs.get('send_source'), 'manual_run_evidence_bundle')
        self.assertEqual(kwargs.get('operator_execution_mode'), 'explicit_send_menu')
        progress_callback('sending email to support')

    def test_guided_patient_completeness_option_runs_letter_flow(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.get_guided_patient_completeness_options = MagicMock(return_value=(
            True,
            'Guided patient completeness options ready.',
            {
                'runbook_lines': ['Guided Patient Completeness Runbook:', ' - data_plane_status=WARN'],
                'options': [{
                    'code': 'A',
                    'title': 'Highest-Risk Completeness Gap',
                    'display_id': '12345',
                    'risk_label': 'HIGH',
                    'reason': 'Highest risk score across chain completeness.',
                    'context_run_id': '20260219-071129-5d5c869f',
                }],
            },
        ))
        cr.open_guided_patient_completeness_runbook = MagicMock(return_value=(
            True,
            'Patient completeness runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '1', 'A', '', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.get_guided_patient_completeness_options.assert_called_once()
        cr.open_guided_patient_completeness_runbook.assert_called_once_with(orch.repo_root, 'A')
        orch._launch_viewer.assert_called_once()

    def test_guided_patient_completeness_no_patient_rows_prints_guidance(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.get_guided_patient_completeness_options = MagicMock(return_value=(
            False,
            'Guided patient completeness unavailable due to current data-state (0 patient rows). Launcher is healthy; review runbook actions below.',
            {
                'condition': 'no_patient_rows',
                'runbook_lines': [
                    'Guided Patient Completeness Runbook:',
                    ' - patient_count=0',
                    ' - qa_reject_count=4',
                    ' - replay_pending_count=4',
                    ' - projection_success_count=0',
                    'What To Do Now:',
                    ' 1) Review QA rejects/replay queue first.',
                    ' 2) Re-open Cloud Readiness -> Investigate after data-state changes.',
                ],
                'actions': [
                    'Review QA rejects/replay queue first.',
                    'Re-open Cloud Readiness -> 2) Investigate patient / data -> 1) Guided completeness after data-state changes.',
                ],
                'options': [],
            },
        ))
        cr.open_guided_patient_completeness_runbook = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                    mock_prompt.side_effect = ['2', '1', '', '0', '0']
                    orch = _make_orchestrator()
                    orch._cloud_readiness_advanced_menu()
        cr.get_guided_patient_completeness_options.assert_called_once()
        cr.open_guided_patient_completeness_runbook.assert_not_called()
        rendered = '\n'.join(printed)
        self.assertIn('Guided runbook context:', rendered)
        self.assertIn('patient_count=0', rendered)
        self.assertIn('What To Do Now:', rendered)
        self.assertIn('Investigate', rendered)
        self.assertEqual(rendered.count('What To Do Now:'), 1)



    def test_patient_flow_runbook_option_opens_for_reference(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.get_patient_flow_reference_options = MagicMock(return_value=(
            True,
            'Patient flow reference options ready.',
            {'options': [{
                'index': 1,
                'display_id': '33333',
                'patient_ref': '33333',
                'risk_label': 'HIGH',
                'risk_score': 80,
            }]},
        ))
        cr.open_patient_flow_runbook = MagicMock(return_value=(
            True,
            'Patient flow runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '2', '1', '', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.get_patient_flow_reference_options.assert_called_once_with(orch.repo_root, limit=12)
        cr.open_patient_flow_runbook.assert_called_once_with(orch.repo_root, '33333')
        orch._launch_viewer.assert_called_once()

    def test_db_inspection_option_generates_and_opens_overview_report(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.open_data_plane_audit_report = MagicMock(return_value=(
            True,
            'DB data audit report generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'db_data_audit_overview_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '3', '1', '', '0', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_data_plane_audit_report.assert_called_once_with(
            orch.repo_root, report_type='overview', limit=60)
        orch._launch_viewer.assert_called_once()

    def test_db_inspection_manual_reference_opens_patient_flow_runbook(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.open_patient_flow_runbook = MagicMock(return_value=(
            True,
            'Patient flow runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '3', '5', '33333', '', '0', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_patient_flow_runbook.assert_called_once_with(orch.repo_root, '33333')
        orch._launch_viewer.assert_called_once()

    def test_artifact_tools_letter_a_opens_latest_triage_pack(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_latest_artifact_triage_pack = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['A', '', '0']
                orch._cloud_phase_artifacts_menu()
        orch._open_latest_artifact_triage_pack.assert_called_once()

    def test_artifact_tools_letter_d_opens_run_id_index(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_run_artifact_index_for_run_id = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['D', '20260219-064740-157a78b1', '', '0']
                orch._cloud_phase_artifacts_menu()
        orch._open_run_artifact_index_for_run_id.assert_called_once_with('20260219-064740-157a78b1')

    def test_manual_pipeline_letter_alias_a_triggers_full_pipeline(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_shadow_pipeline = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['a', '', '0']
                orch._cloud_readiness_advanced_menu()
        orch._run_shadow_pipeline.assert_called_once()

    def test_follow_recommendation_stable_send_queues_run_evidence(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Send run evidence.',
            'why_lines': [],
            'why_summary': 'ok',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'action_preview': {'anchor_run_id': '20260410-anchor'},
            'recommendation_anchor_run_id': '20260410-anchor',
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._try_enqueue_support_send = MagicMock(return_value={'handled': True, 'ok': True})
            orch._send_latest_run_evidence_bundle = MagicMock(return_value=True)
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', '0']
                orch._cloud_readiness_advanced_menu()
        orch._try_enqueue_support_send.assert_called_once()
        orch._send_latest_run_evidence_bundle.assert_not_called()

    def test_open_recommended_lab_report_uses_triage_when_run_evidence_preferred(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'why_lines': [],
            'why_summary': 'x',
            'pipeline_label': 'idle',
            'pipeline_running': False,
        })
        triage_path = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'triage.txt')
        cr.open_latest_artifact_triage_pack = MagicMock(return_value=(True, '', triage_path))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_latest_artifact_triage_pack.assert_called_once()
        orch._launch_viewer.assert_called_once_with(triage_path)

    def test_open_recommended_lab_report_uses_system_health_when_best_now_not_stable_pref(self):
        """When pipeline is running, Best now is system_health while stable pref is run_evidence - open health pack."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'why_lines': [],
            'why_summary': 'Pipeline active',
            'pipeline_label': 'running',
            'pipeline_running': True,
        })
        pack_path = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'health_pack.txt')
        cr.open_latest_system_health_pack = MagicMock(return_value=(True, '', pack_path))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_latest_artifact_triage_pack.assert_not_called()
        cr.open_latest_system_health_pack.assert_called_once()
        orch._launch_viewer.assert_called_once_with(pack_path)

    def test_s_alias_routes_to_follow_recommendation_flow(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._follow_recommendation_flow = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['S', '0']
                orch._cloud_readiness_advanced_menu()
        orch._follow_recommendation_flow.assert_called_once()

    def test_follow_recommendation_unstable_defer_writes_stable_preference(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'summary_line': 'Deferred example.',
            'why_lines': ['Pipeline running'],
            'why_summary': 'Pipeline active',
            'pipeline_label': 'running',
            'pipeline_running': True,
            'recommended_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '2', '0']
                orch._cloud_readiness_advanced_menu()
        cr.write_operator_deferred_support_send.assert_called_once()
        call_kw = cr.write_operator_deferred_support_send.call_args
        self.assertEqual(call_kw[0][1], 'run_evidence')
        self.assertEqual(call_kw[1].get('action_kind'), 'send_bundle')

    def test_follow_recommendation_stable_historical_reprocess_runs_preview_then_execute(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Re-evaluate historical Phase D rejects.',
            'why_lines': ['Historical rejects still exist.'],
            'why_summary': 'Historical rejects need re-evaluation.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'best_now_action_kind': 'historical_phase_d_reprocess',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {'qa_policy_version': 'qa_v2'},
            'action_reason_lines': ['Historical DAT rejects still exist.'],
            'recommendation_anchor_run_id': '20260329-anchor-run',
        })
        cr.preview_historical_phase_d_reprocess = MagicMock(return_value=(True, '', {
            'ok': True,
            'targeted_artifact_classes': ['dat'],
            'qa_version': 'qa_v2',
            'targeted_artifact_count': 389,
            'reject_counts_by_class': {'dat': 389},
            'pending_replay_counts_by_class': {'dat': 389},
            'report_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'phase_d_historical_reprocess_preview_latest.txt'),
        }))
        cr.run_historical_phase_d_reprocess = MagicMock(return_value=(True, 'started', {
            'execution_report_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'phase_d_historical_reprocess_execution_latest.txt'),
        }))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', '0']
                orch._cloud_readiness_advanced_menu()
        cr.preview_historical_phase_d_reprocess.assert_called_once_with(
            orch.repo_root,
            artifact_classes=['dat'],
            remediation_context_run_id='20260329-anchor-run',
        )
        cr.run_historical_phase_d_reprocess.assert_called_once_with(
            orch.repo_root,
            orch.python_exe,
            orch.environment,
            artifact_classes=['dat'],
            remediation_context_run_id='20260329-anchor-run',
        )
        cr.clear_operator_deferred_support_send.assert_called_once_with(orch.repo_root)

    def test_follow_recommendation_unstable_historical_reprocess_defers_action(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'summary_line': 'Wait, then re-evaluate historical rejects.',
            'why_lines': ['Pipeline running'],
            'why_summary': 'Pipeline active',
            'pipeline_label': 'running',
            'pipeline_running': True,
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'best_now_action_kind': 'wait_for_stable',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {'qa_policy_version': 'qa_v2'},
            'action_reason_lines': ['Historical DAT rejects still exist.'],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', '0']
                orch._cloud_readiness_advanced_menu()
        cr.write_operator_deferred_support_send.assert_called_once()
        self.assertEqual(cr.write_operator_deferred_support_send.call_args[1].get('action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(cr.write_operator_deferred_support_send.call_args[1].get('artifact_classes'), ['dat'])

    def test_follow_recommendation_terminal_dat_source_shape_runs_embedded_action_then_sends(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        rec = {
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Terminal DAT source shape.',
            'why_lines': ['DAT PATID is unreachable from source shape.'],
            'why_summary': 'Terminalize source-shape rejects.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'resolve_dat_terminal_source_shape_rejects',
            'best_now_action_kind': 'resolve_dat_terminal_source_shape_rejects',
            'preferred_when_stable_action_kind': 'resolve_dat_terminal_source_shape_rejects',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'recommendation_anchor_run_id': 'anchor-run',
            'action_preview': {
                'anchor_run_id': 'anchor-run',
                'followup_phase_d_run_id': 'follow-d',
                'phase_d_summary_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'qa_canonical_summary_follow-d.json'),
                'qa_reject_samples_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'qa_reject_samples_follow-d.jsonl'),
                'dat_qa_reject_count': 8,
            },
            'action_reason_lines': ['No operator helper is required.'],
        }
        cr.compute_operator_support_send_recommendation = MagicMock(return_value=rec)
        cr.write_dat_terminal_source_shape_rejects_report = MagicMock(return_value=(True, 'created', {
            'txt_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'dat_terminal_source_shape_rejects_anchor-run_follow-d.txt'),
        }))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._send_bundle_for_operator_type = MagicMock(return_value=True)
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1']
                orch._follow_recommendation_flow()
        cr.write_dat_terminal_source_shape_rejects_report.assert_called_once()
        args = cr.write_dat_terminal_source_shape_rejects_report.call_args[0]
        self.assertEqual(args[1], 'anchor-run')
        self.assertEqual(args[2], 'follow-d')
        orch._send_bundle_for_operator_type.assert_called_once()
        self.assertEqual(orch._send_bundle_for_operator_type.call_args[0][0], 'run_evidence')
        self.assertEqual(
            orch._send_bundle_for_operator_type.call_args[1].get('recommendation_action_kind'),
            'resolve_dat_terminal_source_shape_rejects',
        )

    def test_main_menu_autofollow_terminal_dat_source_shape_runs_embedded_action_then_sends(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        _cloud_readiness_menu_mocks(cr)
        rec = {
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'pipeline_running': False,
            'recommended_action_kind': 'resolve_dat_terminal_source_shape_rejects',
            'best_now_action_kind': 'resolve_dat_terminal_source_shape_rejects',
            'preferred_when_stable_action_kind': 'resolve_dat_terminal_source_shape_rejects',
            'recommended_artifact_classes': ['dat'],
            'action_preview': {
                'anchor_run_id': 'anchor-run',
                'followup_phase_d_run_id': 'follow-d',
                'dat_qa_reject_count': 8,
            },
        }
        cr.write_dat_terminal_source_shape_rejects_report = MagicMock(return_value=(True, 'created', {}))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._send_bundle_for_operator_type = MagicMock(return_value=True)
            ok = orch._start_cloud_recommendation_followthrough(
                rec,
                trigger='test',
                source='main_menu_cloud_autofollow',
                operator_execution_mode='main_menu_autofollow',
                quiet=True,
            )
        self.assertTrue(ok)
        cr.write_dat_terminal_source_shape_rejects_report.assert_called_once()
        orch._send_bundle_for_operator_type.assert_called_once()

    def test_main_menu_autofollow_historical_reprocess_starts_action(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            cr = MagicMock()
            _cloud_readiness_menu_mocks(cr)
            cr.resolve_lab_root = MagicMock(return_value=lab)
            rec = _historical_phase_d_autofollow_rec()
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._run_historical_phase_d_reprocess_action = MagicMock(return_value=True)
                ok = orch._maybe_autofollow_cloud_readiness_recommendation(
                    rec,
                    trigger='main_menu_launch',
                    source='main_menu_cloud_autofollow',
                    operator_execution_mode='main_menu_autofollow',
                    quiet=True,
                    queue_best_now_when_unstable=True,
                )
            self.assertTrue(ok)
            orch._run_historical_phase_d_reprocess_action.assert_called_once()
            with open(os.path.join(lab, 'reports', 'cloud_readiness_autofollow_state.json'), 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            self.assertEqual(state.get('last_status'), 'started')
            self.assertEqual(state.get('last_recommendation_action_kind'), 'historical_phase_d_reprocess')
            self.assertEqual(state.get('last_trigger'), 'main_menu_launch')

    def test_main_menu_autofollow_historical_exception_stamps_terminal_failure(self):
        from MediCafe import launcher as launcher_mod
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            cr = MagicMock()
            _cloud_readiness_menu_mocks(cr)
            cr.resolve_lab_root = MagicMock(return_value=lab)
            rec = _historical_phase_d_autofollow_rec()
            with patch.object(launcher_mod, 'cloud_readiness', cr):
                orch = _make_orchestrator()
                orch._run_historical_phase_d_reprocess_action = MagicMock(side_effect=RuntimeError('boom'))
                ok = orch._maybe_autofollow_cloud_readiness_recommendation(
                    rec,
                    trigger='main_menu_launch',
                    source='main_menu_cloud_autofollow',
                    operator_execution_mode='main_menu_autofollow',
                    quiet=True,
                    queue_best_now_when_unstable=True,
                )
            self.assertFalse(ok)
            with open(os.path.join(lab, 'reports', 'cloud_readiness_autofollow_state.json'), 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            self.assertEqual(state.get('last_status'), 'failed')
            self.assertEqual(state.get('last_failure_reason'), 'followthrough_exception:RuntimeError')
            self.assertEqual(state.get('last_failed_action_kind'), 'historical_phase_d_reprocess')

    def test_open_recommended_lab_report_uses_triage_for_historical_reprocess(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'system_health',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'why_lines': [],
            'why_summary': 'Historical reprocess guidance',
            'pipeline_label': 'running',
            'pipeline_running': True,
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'best_now_action_kind': 'wait_for_stable',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [],
        })
        triage_path = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'triage.txt')
        cr.open_latest_artifact_triage_pack = MagicMock(return_value=(True, '', triage_path))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_latest_artifact_triage_pack.assert_called_once()
        orch._launch_viewer.assert_called_once_with(triage_path)

    def test_open_recommended_lab_report_uses_triage_for_dat_qa_full_block(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'why_lines': [],
            'why_summary': 'Send the anchored DAT QA full-block run evidence bundle.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {'anchor_run_id': '20260329-171213-1ccb1c51'},
            'action_reason_lines': [],
        })
        triage_path = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'artifact_triage_pack_latest.txt')
        cr.open_latest_artifact_triage_pack = MagicMock(return_value=(True, '', triage_path))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            orch._open_run_artifact_index_for_run_id = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_latest_artifact_triage_pack.assert_called_once()
        orch._launch_viewer.assert_called_once_with(triage_path)
        orch._open_run_artifact_index_for_run_id.assert_not_called()

    def test_deferred_dat_smoke_stale_intent_clears_without_running(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.read_operator_deferred_phase_d_dat_smoke = MagicMock(return_value={
            'anchor_run_id': 'anchor-old',
            'context_run_id': 'ctx-old',
            'issue_code': 'ISSUE_OLD',
            'reference_phase_d_summary_path': '',
            'created_at_utc': '2026-03-31T00:00:00Z',
        })
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'system_health',
            'preferred_when_stable': 'system_health',
            'best_now_send': 'system_health',
            'summary_line': 'Run DAT smoke.',
            'why_lines': [],
            'why_summary': 'smoke needed',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'phase_d_dat_smoke',
            'best_now_action_kind': 'phase_d_dat_smoke',
            'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {
                'anchor_run_id': 'anchor-new',
                'phase_d_context_run_id': 'ctx-new',
                'remediation_issue_code': 'ISSUE_NEW',
                'reference_phase_d_summary_path': '',
            },
            'action_reason_lines': [],
        })
        cr.read_phase_d_dat_smoke_state = MagicMock(return_value={
            'last_requested_anchor_run_id': 'anchor-new',
            'last_requested_context_run_id': 'ctx-new',
            'last_remediation_issue_code': 'ISSUE_NEW',
            'last_status': 'completed',
            'cooldown_until_utc': '2999-01-01T00:00:00Z',
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_phase_d_dat_smoke = MagicMock(return_value=True)
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['0']
                orch._cloud_readiness_advanced_menu()
        cr.clear_operator_deferred_phase_d_dat_smoke.assert_called_once_with(orch.repo_root)
        orch._run_phase_d_dat_smoke.assert_not_called()

    def test_autorun_dat_smoke_suppressed_when_same_target_cooldown_active(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'system_health',
            'preferred_when_stable': 'system_health',
            'best_now_send': 'system_health',
            'summary_line': 'Run DAT smoke.',
            'why_lines': [],
            'why_summary': 'smoke needed',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'phase_d_dat_smoke',
            'best_now_action_kind': 'phase_d_dat_smoke',
            'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {
                'anchor_run_id': 'anchor-1',
                'phase_d_context_run_id': 'ctx-1',
                'remediation_issue_code': 'ISSUE_1',
                'reference_phase_d_summary_path': '',
            },
            'action_reason_lines': [],
        })
        cr.read_phase_d_dat_smoke_state = MagicMock(return_value={
            'last_requested_anchor_run_id': 'anchor-1',
            'last_requested_context_run_id': 'ctx-1',
            'last_remediation_issue_code': 'ISSUE_1',
            'last_status': 'completed',
            'cooldown_until_utc': '2999-01-01T00:00:00Z',
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_phase_d_dat_smoke = MagicMock(return_value=True)
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['0']
                orch._cloud_readiness_advanced_menu()
        orch._run_phase_d_dat_smoke.assert_not_called()

    def test_print_operator_send_why_includes_phase_d_remediation_lines(self):
        """Operator menu prints the same phase_d_remediation tokens cloud_readiness can return in why_lines."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'summary_line': 'Recommended: send latest System Health Pack.',
            'why_lines': [
                'phase_d_remediation: verification_target=phase_d_constraint_skips',
                'phase_d_remediation: verification_scope=global_phase_d',
                'phase_d_remediation glossary: verification_scope=dat_lane_only means the DAT-lane gate only;',
            ],
            'pipeline_label': 'idle',
            'pipeline_running': False,
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                orch._print_operator_send_why()
        out = buf.getvalue()
        self.assertIn('phase_d_remediation: verification_target=', out)
        self.assertIn('phase_d_remediation glossary:', out)

    def test_print_operator_send_why_includes_qa_full_block_provenance(self):
        """Show why prints provenance fields for review_dat_qa_full_block (anchored vs smoke)."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'summary_line': 'Recommended: send anchored run evidence bundle for the DAT QA full-block anchor.',
            'why_lines': ['Anchored Phase D telemetry shows DAT rows were selected but fully QA-blocked.'],
            'why_summary': 'Send the anchored run evidence bundle with embedded QA context.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_preview': {
                'anchor_run_id': '20260329-171213-1ccb1c51',
                'anchored_diagnosis_source': 'anchored_phase_d_shadow',
                'smoke_source_accepted': False,
                'ignored_smoke_mismatch': True,
                'smoke_anchor_run_id': '20260331-other-smoke-anchor',
                'source_mismatch_note': 'Smoke on disk is not used for displayed counters.',
                'dat_selected_count': 6,
                'dat_qa_pass_count': 0,
                'dat_qa_reject_count': 6,
                'dat_canonical_record_count': 0,
                'phase_d_summary_path': '/lab/reports/qa_x.json',
                'qa_reject_samples_path': '/lab/reports/reject.jsonl',
                'smoke_report_path': '/smoke/report.txt',
            },
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                orch._print_operator_send_why()
        out = buf.getvalue()
        self.assertIn('anchored_diagnosis_source=', out)
        self.assertIn('smoke_source_accepted=False', out)
        self.assertIn('ignored_smoke_mismatch=True', out)
        self.assertIn('smoke_anchor_run_id=', out)
        self.assertIn('source_mismatch_note=', out)
        self.assertIn('ignored_smoke_report_path=/smoke/report.txt', out)
        self.assertIn('ignore this smoke report for anchored review', out)

    def test_print_operator_send_why_includes_dat_verification_rerun_context(self):
        """Show why prints stale resolver-evidence context for DAT verification reruns."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'summary_line': 'Recommended: rerun focused Phase D DAT verification.',
            'why_lines': ['DAT payer-resolution evidence predates the resolver diagnostics.'],
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'phase_d_dat_verification_rerun',
            'best_now_action_kind': 'phase_d_dat_verification_rerun',
            'preferred_when_stable_action_kind': 'phase_d_dat_verification_rerun',
            'recommended_report_kind': 'system_health_pack',
            'recommended_artifact_classes': ['dat'],
            'action_preview': {
                'anchor_run_id': '20260508-145600-48c930d4',
                'phase_d_context_run_id': '20260508-145640-071f6b84',
                'dat_payer_resolution_evidence_status': 'stale_pre_resolution_diagnostics',
                'dat_selected_count': 419,
                'dat_qa_pass_count': 0,
                'dat_qa_reject_count': 419,
                'phase_d_summary_path': '/lab/reports/qa_canonical_summary_x.json',
                'qa_reject_samples_path': '/lab/reports/qa_reject_samples_x.jsonl',
            },
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                orch._print_operator_send_why()
        out = buf.getvalue()
        self.assertIn('dat_payer_resolution_evidence_status=stale_pre_resolution_diagnostics', out)
        self.assertIn('phase_d_context_run_id=20260508-145640-071f6b84', out)
        self.assertIn('dat_selected_count=419', out)

    def test_dat_verification_rerun_delegates_to_dat_only_historical_reprocess(self):
        """Focused DAT verification uses the existing historical Phase D reprocess implementation."""
        from MediCafe import launcher as launcher_mod
        orch = _make_orchestrator()
        orch._run_historical_phase_d_reprocess_action = MagicMock(return_value=True)
        rec = {
            'recommended_action_kind': 'phase_d_dat_verification_rerun',
            'action_preview': {
                'phase_d_context_run_id': '20260508-145640-071f6b84',
            },
        }
        with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print'):
            ok = orch._run_phase_d_dat_verification_rerun_action(rec, confirm_prompt=False)
        self.assertTrue(ok)
        passed_rec = orch._run_historical_phase_d_reprocess_action.call_args[0][0]
        self.assertEqual(passed_rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(passed_rec.get('recommended_artifact_classes'), ['dat'])
        self.assertEqual(passed_rec.get('recommendation_anchor_run_id'), '20260508-145640-071f6b84')
        self.assertEqual(
            orch._run_historical_phase_d_reprocess_action.call_args[1].get('confirm_prompt'),
            False,
        )

    def test_cloud_readiness_advanced_menu_dat_smoke_help_avoids_false_anchor_placeholder(self):
        """Manual DAT smoke menu lines must not promise phase_d_dat_smoke_report_<anchor>.txt."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                    mock_prompt.side_effect = ['0']
                    orch._cloud_readiness_advanced_menu()
        out = buf.getvalue()
        self.assertNotIn('phase_d_dat_smoke_report_<anchor>', out)
        self.assertIn('phase_d_dat_smoke_lab/reports/', out)
        self.assertIn('filename from smoke run', out)

    def test_print_operator_send_why_includes_skip_reasons_for_hidden_actions(self):
        """When recommendation remains send_bundle, operator should still see why historical/smoke were skipped."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'summary_line': 'Recommended: send latest run evidence bundle (phases B..F).',
            'why_lines': [
                'Evaluated artifact run_id=20260331-021819-229d2b48.',
            ],
            'historical_reprocess_evaluated': True,
            'historical_reprocess_available': False,
            'historical_reprocess_not_triggered_reason': 'historical reprocess not triggered: Phase D shows new pass/reject movement or row selection for this evaluated run.',
            'dat_smoke_evaluated': True,
            'dat_smoke_available': False,
            'dat_smoke_not_triggered_reason': 'DAT smoke not triggered: post_medisoft_blocked_stage=phase_d indicates the lane was already exercised.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                orch._print_operator_send_why()
        out = buf.getvalue()
        self.assertIn('historical_reprocess_not_triggered_reason=', out)
        self.assertIn('Phase D shows new pass/reject movement or row selection', out)
        self.assertIn('dat_smoke_not_triggered_reason=', out)
        self.assertIn('post_medisoft_blocked_stage=phase_d', out)

    def test_follow_recommendation_stable_dat_qa_full_block_sends_run_evidence(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Recommended: send anchored run evidence bundle for the DAT QA full-block anchor.',
            'why_lines': ['DAT lane is exercised and fully QA-blocked.'],
            'why_summary': 'Send the anchored run evidence bundle with embedded QA context.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {
                'anchor_run_id': '20260329-171213-1ccb1c51',
                'phase_d_summary_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'qa_canonical_summary_20260329-171213-1ccb1c51.json'),
            },
            'action_reason_lines': ['The QA summary, reject samples, and shadow report will be attached automatically.'],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._try_enqueue_support_send = MagicMock(return_value={'handled': True, 'ok': True})
            orch._send_latest_run_evidence_bundle = MagicMock(return_value=True)
            orch._open_run_artifact_index_for_run_id = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', '0']
                orch._cloud_readiness_advanced_menu()
        orch._try_enqueue_support_send.assert_called_once()
        call_kw = orch._try_enqueue_support_send.call_args[1]
        self.assertEqual(call_kw.get('operator_execution_mode'), 'follow_recommendation')
        self.assertTrue(isinstance(call_kw.get('recommendation'), dict))
        orch._send_latest_run_evidence_bundle.assert_not_called()
        orch._open_run_artifact_index_for_run_id.assert_not_called()
        cr.clear_operator_deferred_support_send.assert_called_once_with(orch.repo_root)

    def test_follow_recommendation_phase_d_why_lines_does_not_offer_historical_as_option_one(self):
        """phase_d_remediation in why_lines does not switch follow-recommendation Option 1 to historical reprocess (autonomy boundary)."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Recommended: send run evidence.',
            'why_lines': [
                'phase_d_remediation: issue_code=PHASE_D_INVALID_EXTERNAL_ID_SPIKE status=active context_run_id=rid-1',
                'phase_d_remediation: verification_target=phase_d_constraint_skips',
            ],
            'why_summary': 'ok',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [],
        })
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        print_name = 'builtins.print' if sys.version_info[0] >= 3 else '__builtin__.print'
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch(print_name, side_effect=_capture_print):
                with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt', side_effect=['0']):
                    orch._follow_recommendation_flow()
        blob = '\n'.join(printed)
        self.assertIn('Send now', blob)
        self.assertNotIn('historical Phase D re-evaluation', blob)
        cr.preview_historical_phase_d_reprocess.assert_not_called()
        cr.run_historical_phase_d_reprocess.assert_not_called()


class TestLauncherRefactorHelpers(unittest.TestCase):

    def test_open_report_result_launches_viewer_when_ok_and_path(self):
        orch = _make_orchestrator()
        orch._launch_viewer = MagicMock()
        with patch('sys.stdout', new=StringIO()) as out:
            opened = orch._open_report_result(True, 'report ready', 'tmp/report.html')
        self.assertTrue(opened)
        orch._launch_viewer.assert_called_once_with('tmp/report.html')
        self.assertIn('Opening: tmp/report.html', out.getvalue())

    def test_open_report_result_prints_message_when_not_opened(self):
        orch = _make_orchestrator()
        orch._launch_viewer = MagicMock()
        with patch('sys.stdout', new=StringIO()) as out:
            opened = orch._open_report_result(False, 'report unavailable', '')
        self.assertFalse(opened)
        orch._launch_viewer.assert_not_called()
        self.assertIn('report unavailable', out.getvalue())

    def test_open_phase_b_summary_uses_shared_cloud_readiness_open_helper(self):
        from MediCafe import launcher as launcher_mod

        orch = _make_orchestrator()
        cr = MagicMock()
        cr.open_phase_b_summary = MagicMock(return_value=(True, '', 'tmp/phase_b_report.txt'))
        orch._launch_viewer = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch('sys.stdout', new=StringIO()) as out:
                orch._open_phase_b_summary()
        cr.open_phase_b_summary.assert_called_once_with(orch.repo_root)
        orch._launch_viewer.assert_called_once_with('tmp/phase_b_report.txt')
        self.assertIn('Opening: tmp/phase_b_report.txt', out.getvalue())

    def test_run_phase_d_manual_uses_shared_cloud_readiness_run_helper(self):
        from MediCafe import launcher as launcher_mod

        orch = _make_orchestrator()
        cr = MagicMock()
        cr.run_phase_d_manual = MagicMock(return_value=(True, '', None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch('sys.stdout', new=StringIO()) as out:
                ok = orch._run_phase_d_manual()
        self.assertTrue(ok)
        cr.run_phase_d_manual.assert_called_once_with(orch.repo_root, orch.python_exe, orch.environment)
        self.assertIn('Phase D QA started in background.', out.getvalue())

    def test_run_phase_e_manual_prints_failure_message_from_shared_helper(self):
        from MediCafe import launcher as launcher_mod

        orch = _make_orchestrator()
        cr = MagicMock()
        cr.run_phase_e_manual = MagicMock(return_value=(False, 'launch blocked', None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch('sys.stdout', new=StringIO()) as out:
                ok = orch._run_phase_e_manual()
        self.assertFalse(ok)
        cr.run_phase_e_manual.assert_called_once_with(orch.repo_root, orch.python_exe, orch.environment)
        self.assertIn('launch blocked', out.getvalue())

    def test_shared_cloud_readiness_helpers_tolerate_missing_service(self):
        from MediCafe import launcher as launcher_mod

        orch = _make_orchestrator()
        orch._launch_viewer = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', None):
            self.assertFalse(orch._open_phase_b_summary())
            self.assertFalse(orch._run_phase_d_manual())
        orch._launch_viewer.assert_not_called()

    def test_pause_to_continue_swallows_prompt_errors(self):
        orch = _make_orchestrator()
        orch._prompt = MagicMock(side_effect=RuntimeError('prompt failure'))
        orch._pause_to_continue('Press Enter to continue...')


if __name__ == '__main__':
    unittest.main()
