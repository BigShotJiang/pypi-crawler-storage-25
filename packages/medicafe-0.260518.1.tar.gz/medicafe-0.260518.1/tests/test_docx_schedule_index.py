#!/usr/bin/env python
from __future__ import print_function

import os
import tempfile
import unittest
import zipfile

from MediBot import MediBot_docx_index as docx_index
from MediBot import MediBot_docx_decoder as docx_decoder


def _minimal_document_xml(*texts):
    runs = []
    for text in texts:
        runs.append('<w:p><w:r><w:t>{}</w:t></w:r></w:p>'.format(text))
    return (
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body>{}</w:body></w:document>'
    ).format(''.join(runs)).encode('utf-8')


def _write_minimal_docx_package(path):
    with zipfile.ZipFile(path, 'w') as archive:
        archive.writestr('[Content_Types].xml', '<Types></Types>')
        archive.writestr('word/document.xml', '<w:document></w:document>')


class DocxScheduleIndexTests(unittest.TestCase):

    def test_targeted_update_records_status_and_skips_unchanged_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'sample.docx')
            _write_minimal_docx_package(docx_path)

            parse_calls = []
            original_parse = docx_index.parse_docx
            try:
                def fake_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    parse_calls.append((filepath, capture_schedule_positions))
                    return {
                        '03-19-2026': {
                            '123': {
                                'diagnosis': 'H25.9',
                                'eye': 'OD',
                                'femto': ''
                            }
                        }
                    }

                docx_index.parse_docx = fake_parse

                _, first_stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    source='gmail_download'
                )
                self.assertEqual(first_stats.get('parsed'), 1)
                self.assertEqual(len(parse_calls), 1)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'gmail_download')
                self.assertEqual(status.get('mode'), 'targeted')
                self.assertEqual(status.get('requested_file_count'), 1)
                self.assertTrue(status.get('capture_schedule_positions'))
                self.assertEqual(status.get('stats', {}).get('parsed'), 1)

                _, second_stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    source='gmail_download'
                )
                self.assertEqual(second_stats.get('parsed'), 0)
                self.assertEqual(second_stats.get('skipped'), 1)
                self.assertEqual(len(parse_calls), 1)
            finally:
                docx_index.parse_docx = original_parse

    def test_full_scan_status_records_source(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'scan.docx')
            _write_minimal_docx_package(docx_path)

            original_parse = docx_index.parse_docx
            try:
                def fake_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    return {
                        '03-20-2026': {
                            '456': {
                                'diagnosis': 'H26.9',
                                'eye': 'OS',
                                'femto': ''
                            }
                        }
                    }

                docx_index.parse_docx = fake_parse

                _, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=None,
                    capture_schedule_positions=False,
                    source='medibot_preprocess'
                )
                self.assertEqual(stats.get('parsed'), 1)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'medibot_preprocess')
                self.assertEqual(status.get('mode'), 'full_scan')
                self.assertEqual(status.get('requested_file_count'), 1)
                self.assertFalse(status.get('capture_schedule_positions'))
                self.assertEqual(status.get('stats', {}).get('parsed'), 1)
            finally:
                docx_index.parse_docx = original_parse


    def test_parser_unavailable_full_scan_status_preserves_mode(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            original_parse = docx_index.parse_docx
            try:
                docx_index.parse_docx = None

                _, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=None,
                    capture_schedule_positions=False,
                    source='cli_rebuild'
                )
                self.assertEqual(stats.get('parsed'), 0)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'cli_rebuild')
                self.assertEqual(status.get('mode'), 'full_scan')
                self.assertIsNone(status.get('requested_file_count'))
                self.assertFalse(status.get('parser_available'))
            finally:
                docx_index.parse_docx = original_parse

    def test_docx_index_parse_failure_logs_basename_and_demotes_repeats(self):
        captured = []
        original_log = docx_index._log
        try:
            docx_index._DOCX_INDEX_PARSE_FAILURE_COUNTS.clear()
            docx_index._DOCX_INDEX_PARSE_FAILURE_SAMPLES.clear()
            docx_index._log = lambda message, level="INFO": captured.append((level, message))
            path = 'C:\\sensitive\\clinic\\folder\\bad.docx'
            exc = ValueError('cannot parse C:\\sensitive\\clinic\\folder\\bad.docx')

            docx_index._log_parse_failure(path, 'content_error', exc)
            docx_index._log_parse_failure(path, 'content_error', exc)
        finally:
            docx_index._log = original_log

        self.assertEqual(captured[0][0], 'WARNING')
        self.assertIn('file=bad.docx', captured[0][1])
        self.assertNotIn('C:\\sensitive\\clinic\\folder', captured[0][1])
        self.assertEqual(captured[1][0], 'DEBUG')
        self.assertIn('repeat suppressed', captured[1][1])

    def test_invalid_docx_package_is_recorded_without_calling_parser(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'tiny_bad.docx')
            with open(docx_path, 'wb') as handle:
                handle.write(b'not a zip')

            original_parse = docx_index.parse_docx
            try:
                def unexpected_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    raise AssertionError('invalid package should not reach parser')

                docx_index.parse_docx = unexpected_parse
                index_data, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=False,
                    source='invalid_package_test'
                )
            finally:
                docx_index.parse_docx = original_parse

            self.assertEqual(stats.get('parsed'), 1)
            self.assertEqual(stats.get('errors'), 1)
            self.assertEqual(stats.get('invalid_docx_package'), 1)
            rec = index_data.get('files', {}).get('tiny_bad.docx', {})
            self.assertTrue(rec.get('parse_failed'))
            self.assertEqual(rec.get('parse_error_type'), 'invalid_docx_package')
            self.assertEqual(rec.get('docx_package_reason'), 'not_zip_package')

    def test_failed_docx_candidate_discovery_classifies_present_missing_and_changed(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            empty_path = os.path.join(tmpdir, 'empty.docx')
            bad_path = os.path.join(tmpdir, 'bad.docx')
            _write_minimal_docx_package(empty_path)
            _write_minimal_docx_package(bad_path)
            empty_stat = os.stat(empty_path)
            bad_stat = os.stat(bad_path)
            docx_index.save_docx_schedule_index(tmpdir, {
                'version': docx_index.INDEX_VERSION,
                'files': {
                    'empty.docx': {
                        'mtime': empty_stat.st_mtime,
                        'size': empty_stat.st_size,
                        'parse_failed': True,
                        'parse_error_type': 'empty_parse',
                        'parse_error_message': 'No patient data extracted from DOCX.',
                        'date_of_service': '05-07-2026',
                    },
                    'bad.docx': {
                        'mtime': bad_stat.st_mtime - 1,
                        'size': bad_stat.st_size + 1,
                        'parse_failed': True,
                        'parse_error_type': 'invalid_docx_package',
                        'parse_error_message': 'not_zip_package',
                    },
                    'missing.docx': {
                        'mtime': 1,
                        'size': 2,
                        'parse_failed': True,
                        'parse_error_type': 'empty_parse',
                        'parse_error_message': 'No patient data extracted from DOCX.',
                    },
                    'success.docx': {
                        'mtime': 1,
                        'size': 2,
                        'parse_failed': False,
                    },
                },
                'schedules': {},
            })

            candidates = docx_index.collect_failed_docx_parse_candidates(tmpdir)
            by_name = dict((item.get('filename'), item) for item in candidates)

            self.assertEqual(set(by_name.keys()), set(['empty.docx', 'bad.docx', 'missing.docx']))
            self.assertTrue(by_name['empty.docx'].get('present'))
            self.assertEqual(by_name['empty.docx'].get('status'), 'present')
            self.assertEqual(by_name['empty.docx'].get('parse_error_type'), 'empty_parse')
            self.assertEqual(by_name['empty.docx'].get('date_of_service'), '05-07-2026')
            self.assertTrue(by_name['bad.docx'].get('present'))
            self.assertEqual(by_name['bad.docx'].get('status'), 'changed_since_failure')
            self.assertTrue(by_name['bad.docx'].get('changed_since_failure'))
            self.assertEqual(by_name['bad.docx'].get('parse_error_type'), 'invalid_docx_package')
            self.assertFalse(by_name['missing.docx'].get('present'))
            self.assertEqual(by_name['missing.docx'].get('status'), 'missing')

    def test_unchanged_failed_record_is_skipped_by_default_lazy_update(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'failed.docx')
            _write_minimal_docx_package(docx_path)
            stat_info = os.stat(docx_path)
            docx_index.save_docx_schedule_index(tmpdir, {
                'version': docx_index.INDEX_VERSION,
                'files': {
                    'failed.docx': {
                        'mtime': stat_info.st_mtime,
                        'size': stat_info.st_size,
                        'dates': [],
                        'parse_failed': True,
                        'parse_error_type': 'empty_parse',
                        'parse_error_message': 'No patient data extracted from DOCX.',
                    }
                },
                'schedules': {},
            })

            original_parse = docx_index.parse_docx
            try:
                def unexpected_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    raise AssertionError('unchanged failed record should be skipped by default')

                docx_index.parse_docx = unexpected_parse
                index_data, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    source='lazy_default'
                )
            finally:
                docx_index.parse_docx = original_parse

            self.assertEqual(stats.get('parsed'), 0)
            self.assertEqual(stats.get('skipped'), 1)
            self.assertTrue(index_data.get('files', {}).get('failed.docx', {}).get('parse_failed'))

    def test_retry_failed_reparses_unchanged_failed_record_and_clears_success(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'retry.docx')
            _write_minimal_docx_package(docx_path)
            stat_info = os.stat(docx_path)
            docx_index.save_docx_schedule_index(tmpdir, {
                'version': docx_index.INDEX_VERSION,
                'files': {
                    'retry.docx': {
                        'mtime': stat_info.st_mtime,
                        'size': stat_info.st_size,
                        'dates': [],
                        'parse_failed': True,
                        'parse_error_type': 'empty_parse',
                    }
                },
                'schedules': {},
            })

            original_parse = docx_index.parse_docx
            try:
                def successful_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    return {'123': {'05-07-2026': ['H25.9', 'OD', '']}}

                docx_index.parse_docx = successful_parse
                index_data, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    retry_failed=True,
                    source='retry_test'
                )
            finally:
                docx_index.parse_docx = original_parse

            self.assertEqual(stats.get('parsed'), 1)
            self.assertEqual(stats.get('skipped'), 0)
            rec = index_data.get('files', {}).get('retry.docx', {})
            self.assertFalse(rec.get('parse_failed'))
            self.assertEqual(rec.get('dates'), ['05-07-2026'])
            current = index_data.get('schedules', {}).get('05-07-2026', {}).get('current', {})
            self.assertEqual(current.get('source_file'), 'retry.docx')
            self.assertIn('123', current.get('patients', {}))
            persisted = docx_index.load_docx_schedule_index(tmpdir)
            persisted_rec = persisted.get('files', {}).get('retry.docx', {})
            self.assertFalse(persisted_rec.get('parse_failed'))
            persisted_current = persisted.get('schedules', {}).get('05-07-2026', {}).get('current', {})
            self.assertEqual(persisted_current.get('source_file'), 'retry.docx')
            self.assertIn('123', persisted_current.get('patients', {}))
            status = docx_index.load_docx_schedule_index_status(tmpdir)
            self.assertTrue(status.get('retry_failed'))

    def test_retry_failed_keeps_failed_record_with_refreshed_error_metadata(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'still_failed.docx')
            _write_minimal_docx_package(docx_path)
            stat_info = os.stat(docx_path)
            docx_index.save_docx_schedule_index(tmpdir, {
                'version': docx_index.INDEX_VERSION,
                'files': {
                    'still_failed.docx': {
                        'mtime': stat_info.st_mtime,
                        'size': stat_info.st_size,
                        'dates': [],
                        'parse_failed': True,
                        'parse_error_type': 'empty_parse',
                        'parse_error_message': 'old failure',
                    }
                },
                'schedules': {},
            })

            original_parse = docx_index.parse_docx
            try:
                def empty_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    return {}

                docx_index.parse_docx = empty_parse
                index_data, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    retry_failed=True,
                    source='retry_failed_test'
                )
            finally:
                docx_index.parse_docx = original_parse

            self.assertEqual(stats.get('parsed'), 1)
            self.assertEqual(stats.get('errors'), 1)
            rec = index_data.get('files', {}).get('still_failed.docx', {})
            self.assertTrue(rec.get('parse_failed'))
            self.assertEqual(rec.get('parse_error_type'), 'empty_parse')
            self.assertEqual(rec.get('parse_error_message'), 'No patient data extracted from DOCX.')
            self.assertTrue(rec.get('parse_failed_at'))

    def test_docx_decoder_open_failure_logs_basename_and_demotes_repeats(self):
        captured = []
        original_log = docx_decoder.MediLink_ConfigLoader.log
        try:
            docx_decoder._DOCX_OPEN_FAILURE_COUNTS.clear()
            docx_decoder._DOCX_OPEN_FAILURE_SAMPLES.clear()
            docx_decoder.MediLink_ConfigLoader.log = lambda message, level="INFO": captured.append((level, message))
            path = 'C:\\sensitive\\clinic\\folder\\bad.docx'
            exc = IOError('cannot open C:\\sensitive\\clinic\\folder\\bad.docx')

            docx_decoder._log_docx_open_failure('parse_docx_document', path, exc)
            docx_decoder._log_docx_open_failure('parse_docx_document', path, exc)
        finally:
            docx_decoder.MediLink_ConfigLoader.log = original_log

        self.assertEqual(captured[0][0], 'ERROR')
        self.assertIn('file=bad.docx', captured[0][1])
        self.assertNotIn('C:\\sensitive\\clinic\\folder', captured[0][1])
        self.assertEqual(captured[1][0], 'DEBUG')
        self.assertIn('repeat suppressed', captured[1][1])

    def test_docx_date_extraction_preserves_existing_space_separated_header(self):
        xml = _minimal_document_xml('Surgery Schedule', 'THURSDAY MAY 7 2026')

        result = docx_decoder.extract_date_from_content(xml)

        self.assertEqual(result, '05-07-2026')

    def test_docx_date_extraction_preserves_existing_comma_space_header(self):
        xml = _minimal_document_xml('Surgery Schedule', 'THURSDAY MAY 7, 2026')

        result = docx_decoder.extract_date_from_content(xml)

        self.assertEqual(result, '05-07-2026')

    def test_docx_date_extraction_falls_back_for_comma_without_space_before_year(self):
        captured = []
        original_log = docx_decoder.MediLink_ConfigLoader.log
        try:
            docx_decoder.MediLink_ConfigLoader.log = lambda message, level="INFO": captured.append((level, message))
            xml = _minimal_document_xml('Surgery Schedule', 'THURSDAY MAY 7,2026')

            result = docx_decoder.extract_date_from_content(xml)
        finally:
            docx_decoder.MediLink_ConfigLoader.log = original_log

        self.assertEqual(result, '05-07-2026')
        self.assertTrue(
            any('comma-to-space normalization' in message for _level, message in captured)
        )

    def test_docx_date_extraction_invalid_day_still_fails(self):
        xml = _minimal_document_xml('Surgery Schedule', 'THURSDAY MAY 72,026')

        result = docx_decoder.extract_date_from_content(xml)

        self.assertIsNone(result)

if __name__ == '__main__':
    unittest.main()

