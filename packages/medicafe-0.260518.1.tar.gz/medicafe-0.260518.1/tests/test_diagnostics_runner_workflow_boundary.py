import os
import sys

TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if TESTS_ROOT not in sys.path:
    sys.path.insert(0, TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean  # noqa: E402


def test_diagnostics_runner_run_extended_diagnostics_preserved_context_vs_latest_artifact_contract():
    """
    Workflow-boundary contract regression harness for:
      scripts/unified_model/diagnostics_runner.py::run_extended_diagnostics

    This test does not execute the subprocess-heavy diagnostic runner. Instead it
    models the preserved-context + mutable-evidence boundary that downstream
    consumers must uphold: a preserved run_id pointer must not be overridden by
    a newer wrong-target "latest by mtime" artifact.
    """
    target_run_id = "A"

    assert_workflow_boundary_clean("extended_diagnostics_attempt", {
        "run_id": target_run_id,
    }, [
        {
            "name": "diagnostics_state.json",
            "role": "preserved_context",
            "identity": {"run_id": target_run_id},
            "status": "completed",
            "accepted": False,
            "classification": "state_present_not_accepted",
            "claims_completion": False,
        },
        {
            "name": "reports/extended_diagnostics_B.json",
            "role": "mutable_evidence",
            "identity": {"run_id": "B"},
            "status": "completed",
            "accepted": False,
            "classification": "ignored_mismatch",
            "claims_completion": False,
        },
        {
            "name": "reports/extended_diagnostics_A.json",
            "role": "packaging_surface",
            "identity": {"run_id": target_run_id},
            "status": "completed",
            "accepted": True,
            "classification": "accepted",
            "claims_completion": True,
        },
    ])

