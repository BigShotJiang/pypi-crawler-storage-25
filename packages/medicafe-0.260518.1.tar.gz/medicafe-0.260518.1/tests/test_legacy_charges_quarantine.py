import os

import pytest


REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _read_repo_text(*parts):
    path = os.path.join(REPO_ROOT, *parts)
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def test_legacy_charge_modules_are_not_importable_components():
    from MediCafe.smart_import import get_components, list_components

    available = list_components()
    assert "medibot_charges" not in available
    assert "medilink_charges" not in available

    for component_name in ("medibot_charges", "medilink_charges"):
        with pytest.raises(ImportError) as excinfo:
            get_components(component_name)
        assert "Unknown component: {0}".format(component_name) in str(excinfo.value)


def test_legacy_charge_runtime_hooks_are_removed():
    medibot_source = _read_repo_text("MediBot", "MediBot.py")
    smart_import_source = _read_repo_text("MediCafe", "smart_import.py")

    assert "ENABLE_CHARGES_ENRICHMENT" not in medibot_source
    assert "enrich_with_charges" not in medibot_source
    assert "get_components('medibot_charges')" not in medibot_source
    assert "MediBot.MediBot_Charges" not in smart_import_source
    assert "MediLink.MediLink_Charges" not in smart_import_source


def test_legacy_charge_modules_are_quarantined_as_documented_intent_only():
    assert not os.path.exists(os.path.join(REPO_ROOT, "MediBot", "MediBot_Charges.py"))
    assert not os.path.exists(os.path.join(REPO_ROOT, "MediLink", "MediLink_Charges.py"))

    doc = _read_repo_text("docs", "LEGACY_CHARGES_WORKFLOW_INTENT.md")
    required_terms = [
        "MediBot/MediBot_Charges.py",
        "MediLink/MediLink_Charges.py",
        "preview_only_review_required",
        "claims_completion=False",
        "mutates_billing_state=False",
        "charges_entered",
        "837P",
        "MATRAN",
        "bilateral",
        "deductible",
        "Service Line Input",
        "charges_tool",
    ]
    for term in required_terms:
        assert term in doc
