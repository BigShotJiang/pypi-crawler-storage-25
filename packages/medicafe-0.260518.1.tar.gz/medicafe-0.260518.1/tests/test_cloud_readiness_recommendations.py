﻿#!/usr/bin/env python
"""
Unit tests for MediCafe.cloud_readiness.
Tests evidence selection, run_phase_f_manual, run_phase_f_manual_for_run_id, is_pipeline_running.
"""
from __future__ import print_function

import json
import os
import shutil
import sqlite3
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock  # pyright: ignore[reportMissingModuleSource]

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)
_TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean


def _make_lab():
    """Create temp lab dir with reports."""
    lab_root = tempfile.mkdtemp()
    reports_dir = os.path.join(lab_root, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    return lab_root, reports_dir


class TestOperatorSupportRecommendation(unittest.TestCase):
    def _write_json(self, path, data):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        return path

    def _snapshot_with_phase_payloads(self, reports_dir, run_id, shadow_payload, phase_c_payload, phase_d_payload):
        shadow_path = self._write_json(
            os.path.join(reports_dir, 'shadow_run_report_{0}.json'.format(run_id)),
            shadow_payload,
        )
        phase_c_path = self._write_json(
            os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(run_id)),
            phase_c_payload,
        )
        phase_d_path = self._write_json(
            os.path.join(reports_dir, 'qa_canonical_summary_{0}.json'.format(run_id)),
            phase_d_payload,
        )
        rows = []
        for code in ('B', 'C', 'D', 'E', 'F'):
            row = {
                'code': code,
                'name': code,
                'status': 'complete',
                'resolved_run_id': run_id,
                'files': [],
                'required_missing': [],
            }
            if code == 'C':
                row['files'] = [phase_c_path]
            elif code == 'D':
                row['files'] = [phase_d_path]
            elif code == 'F':
                row['files'] = [shadow_path]
            rows.append(row)
        return {
            'lab_root': os.path.dirname(reports_dir),
            'reports_dir': reports_dir,
            'run_id': run_id,
            'nearest_complete_run_id': '',
            'phase_rows': rows,
            'diagnostics_state': {},
        }

    def test_autonomous_followthrough_policy_marks_no_burden_recommendation(self):
        from MediCafe import cloud_readiness_recommendations as rec_mod

        rec = rec_mod._apply_autonomous_followthrough_policy({
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'pipeline_running': False,
            'action_requires_confirmation': False,
            'operator_manual_review_required': False,
        })

        self.assertTrue(rec.get('autonomous_followthrough_allowed'))
        self.assertEqual(rec.get('operator_burden_policy'), 'no_operator_decision_required')
        self.assertEqual(rec.get('autonomous_followthrough_mode'), 'recommendation_followthrough')
        self.assertEqual(
            rec.get('autonomous_followthrough_sequence')[0].get('step'),
            'run_diagnostic_action',
        )

    def test_autonomous_followthrough_policy_fails_closed_for_confirmation(self):
        from MediCafe import cloud_readiness_recommendations as rec_mod

        rec = rec_mod._apply_autonomous_followthrough_policy({
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'action_requires_confirmation': True,
        })

        self.assertFalse(rec.get('autonomous_followthrough_allowed'))
        self.assertEqual(rec.get('operator_burden_policy'), 'operator_confirmation_required')
        self.assertEqual(rec.get('autonomous_followthrough_reason'), 'action_requires_confirmation')

    def test_autonomous_followthrough_policy_preserves_preferred_send_after_idle(self):
        from MediCafe import cloud_readiness_recommendations as rec_mod

        rec = rec_mod._apply_autonomous_followthrough_policy({
            'recommended_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'pipeline_running': True,
            'best_now_send': 'system_health',
            'preferred_when_stable': 'run_evidence',
            'action_requires_confirmation': False,
        })

        self.assertTrue(rec.get('autonomous_followthrough_allowed'))
        self.assertEqual(rec.get('autonomous_followthrough_sequence'), [
            {'step': 'queue_bundle_send', 'send_type': 'system_health', 'action_kind': 'send_bundle'},
            {'step': 'defer_preferred_bundle_until_idle', 'send_type': 'run_evidence', 'action_kind': 'send_bundle'},
        ])

    def test_step2_manifest_sha_mismatch_fails_closed_without_precomputed_lineage(self):
        from MediCafe import cloud_readiness_recommendations as mcr

        lab, reports = _make_lab()
        run_id = 'run-step2'
        shadow_path = self._write_json(
            os.path.join(reports, 'shadow_run_report_{0}.json'.format(run_id)),
            {'run_id': run_id, 'phase_run_ids': {'D': 'd-step2'}},
        )
        shadow_index_path = self._write_json(
            os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(run_id)),
            {'run_id': run_id},
        )
        phase_d_path = self._write_json(
            os.path.join(reports, 'qa_canonical_summary_d-step2.json'),
            {'run_id': 'd-step2', 'rows_selected': 1},
        )
        snapshot = {
            'run_id': run_id,
            'reports_dir': reports,
            'artifact_files': [shadow_path, shadow_index_path, phase_d_path],
            'phase_rows': [{'code': 'D', 'files': [phase_d_path]}],
            'phase_run_ids': {'D': 'd-step2'},
            'diagnostics_state': {
                'last_manifest_sha256': 'sha-b',
                'last_ingest_manifest_sha256': 'sha-c',
            },
        }
        step2 = mcr._step2_run_coherence_from_snapshot(snapshot)
        self.assertFalse(step2.get('alignment_ok'))
        self.assertEqual(step2.get('alignment_note'), 'phase_c_manifest_sha_mismatch')
        self.assertIn('phase_c_manifest_sha_mismatch', step2.get('primary_lineage_issue'))
        assert_workflow_boundary_clean('step2_run_coherence', {
            'anchor_run_id': run_id,
        }, [
            {
                'name': 'snapshot',
                'role': 'artifact',
                'identity': {'anchor_run_id': run_id},
                'classification': 'review_required',
            },
            {
                'name': 'step2_run_coherence',
                'role': 'recommendation',
                'identity': {'anchor_run_id': run_id},
                'classification': 'review_required',
            },
        ])

    def test_phase_d_followup_evidence_is_packaged_as_non_closure_telemetry(self):
        from MediCafe import cloud_readiness_recommendations as mcr

        lab, reports = _make_lab()
        anchor = 'run-anchor'
        anchored_d = 'd-anchor'
        live_d = 'd-live'
        qa_path = self._write_json(
            os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(live_d)),
            {
                'run_id': live_d,
                'dat_telemetry': {
                    'dat_selected_count': 22,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 22,
                    'dat_canonical_record_count': 0,
                    'dat_qa_reject_counts_by_reason': {
                        'QA_DAT_EMPTY_FILE': 12,
                        'QA_DAT_PATIENT_ANCHOR_MISSING': 8,
                        'QA_DAT_PAYER_ANCHOR_MISSING': 2,
                    },
                    'dat_reject_file_prefix_counts': {'Z': 12, 'ZM': 10},
                },
            },
        )
        reject_path = os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(live_d))
        with open(reject_path, 'w', encoding='utf-8') as handle:
            handle.write('{"reason_code":"QA_DAT_EMPTY_FILE"}\n')
        dat_anchor_profile_json = os.path.join(reports, 'dat_anchor_failure_profile_{0}.json'.format(live_d))
        dat_anchor_profile_txt = os.path.join(reports, 'dat_anchor_failure_profile_{0}.txt'.format(live_d))
        with open(dat_anchor_profile_json, 'w', encoding='utf-8') as handle:
            json.dump({'run_id': live_d, 'schema_version': 'dat_anchor_failure_profile_v1'}, handle)
        with open(dat_anchor_profile_txt, 'w', encoding='utf-8') as handle:
            handle.write('DAT Anchor Failure Profile\n')
        snapshot = {
            'run_id': anchor,
            'phase_run_ids': {'D': anchored_d},
            'diagnostics_state': {'last_phase_d_run_id': live_d},
        }
        paths = mcr._phase_d_followup_paths_for_run_evidence(lab, snapshot)
        basenames = [os.path.basename(path) for path in paths]
        self.assertIn(os.path.basename(qa_path), basenames)
        self.assertIn(os.path.basename(reject_path), basenames)
        self.assertIn(os.path.basename(dat_anchor_profile_json), basenames)
        self.assertIn(os.path.basename(dat_anchor_profile_txt), basenames)
        note = os.path.join(reports, 'run_evidence_phase_d_followup_note_{0}.txt'.format(anchor))
        self.assertIn(os.path.basename(note), basenames)
        with open(note, 'r', encoding='utf-8') as handle:
            body = handle.read()
        self.assertIn('followup_phase_d_run_id={0}'.format(live_d), body)
        self.assertIn('phase_d_movement_classification=followup_only_not_anchor_closure', body)
        self.assertIn('accepted_as_reviewed_anchor_milestone=False', body)
        self.assertIn('dominant_reject_code=QA_DAT_EMPTY_FILE', body)
        self.assertIn('dominant_reject_count=12', body)
        self.assertIn('dat_reject_blocker_class=empty_dat_file', body)
        self.assertIn('safe_artifact_file_prefix_counts=Z:12,ZM:10', body)
        self.assertIn('recommended_developer_action=developer_action:', body)
        self.assertIn('dat_anchor_failure_profile_json_path={0}'.format(dat_anchor_profile_json), body)
        self.assertIn('dat_anchor_failure_profile_txt_path={0}'.format(dat_anchor_profile_txt), body)
        self.assertIn('live_state_warning=Current diagnostics_state may show post-anchor Phase D movement', body)
        assert_workflow_boundary_clean('phase_d_followup_evidence', {
            'anchor_run_id': anchor,
            'phase_d_run_id': live_d,
        }, [
            {
                'name': os.path.basename(qa_path),
                'role': 'artifact',
                'identity': {'anchor_run_id': anchor, 'phase_d_run_id': live_d},
                'status': 'completed',
                'terminal': True,
            },
            {
                'name': os.path.basename(note),
                'role': 'package',
                'identity': {'anchor_run_id': anchor, 'phase_d_run_id': live_d},
                'classification': 'note_present',
            },
        ])

    def test_phase_d_followup_evidence_uses_live_state_when_snapshot_is_stale(self):
        from MediCafe import cloud_readiness_recommendations as mcr

        lab, reports = _make_lab()
        try:
            anchor = 'run-anchor'
            anchored_d = 'd-anchor'
            stale_d = anchored_d
            live_d = 'd-live-after-package-start'
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({'last_phase_d_run_id': live_d}, handle)
            qa_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(live_d)),
                {
                    'run_id': live_d,
                    'dat_telemetry': {
                        'dat_selected_count': 22,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 22,
                        'dat_canonical_record_count': 0,
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_EMPTY_FILE': 22},
                    },
                },
            )
            reject_path = os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(live_d))
            with open(reject_path, 'w', encoding='utf-8') as handle:
                handle.write('{"reason_code":"QA_DAT_EMPTY_FILE"}\n')
            dat_anchor_profile_json = os.path.join(reports, 'dat_anchor_failure_profile_{0}.json'.format(live_d))
            with open(dat_anchor_profile_json, 'w', encoding='utf-8') as handle:
                json.dump({'run_id': live_d, 'schema_version': 'dat_anchor_failure_profile_v1'}, handle)
            snapshot = {
                'run_id': anchor,
                'phase_run_ids': {'D': anchored_d},
                'diagnostics_state': {'last_phase_d_run_id': stale_d},
            }

            paths = mcr._phase_d_followup_paths_for_run_evidence(lab, snapshot)
            basenames = [os.path.basename(path) for path in paths]
            note = os.path.join(reports, 'run_evidence_phase_d_followup_note_{0}.txt'.format(anchor))

            self.assertIn(os.path.basename(qa_path), basenames)
            self.assertIn(os.path.basename(reject_path), basenames)
            self.assertIn(os.path.basename(dat_anchor_profile_json), basenames)
            self.assertIn(os.path.basename(note), basenames)
            with open(note, 'r', encoding='utf-8') as handle:
                body = handle.read()
            self.assertIn('reviewed_anchor_phase_d_run_id={0}'.format(anchored_d), body)
            self.assertIn('followup_phase_d_run_id={0}'.format(live_d), body)
            self.assertIn('followup_source=live_diagnostics_state', body)
            self.assertIn('accepted_as_reviewed_anchor_milestone=False', body)
            assert_workflow_boundary_clean('phase_d_followup_evidence', {
                'anchor_run_id': anchor,
                'phase_d_run_id': live_d,
            }, [
                {
                    'name': os.path.basename(qa_path),
                    'role': 'artifact',
                    'identity': {'anchor_run_id': anchor, 'phase_d_run_id': live_d},
                    'status': 'completed',
                    'terminal': True,
                },
                {
                    'name': os.path.basename(note),
                    'role': 'package',
                    'identity': {'anchor_run_id': anchor, 'phase_d_run_id': live_d},
                    'classification': 'followup_only_not_anchor_closure',
                },
            ])
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_phase_d_followup_does_not_override_live_anchor_match_with_stale_snapshot(self):
        """Live last_phase_d agreeing with anchor must win over snapshot disagreement."""
        from MediCafe import cloud_readiness_recommendations as mcr

        lab, reports = _make_lab()
        try:
            anchor = 'run-anchor'
            anchored_d = 'd-anchor'
            stale_other = 'd-stale-snapshot-only'
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({'last_phase_d_run_id': anchored_d}, handle)
            self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(stale_other)),
                {
                    'run_id': stale_other,
                    'dat_telemetry': {
                        'dat_selected_count': 22,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 22,
                        'dat_canonical_record_count': 0,
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_EMPTY_FILE': 22},
                    },
                },
            )
            snapshot = {
                'run_id': anchor,
                'phase_run_ids': {'D': anchored_d},
                'diagnostics_state': {'last_phase_d_run_id': stale_other},
            }
            paths = mcr._phase_d_followup_paths_for_run_evidence(lab, snapshot)
            self.assertEqual(paths, [])
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_phase_d_movement_and_reject_classifier_tokens_are_stable(self):
        from MediCafe.phase_d_movement import classify_dat_reject_next_action
        from MediCafe.phase_d_movement import classify_phase_d_movement
        from MediCafe.phase_d_movement import classify_phase_d_selector_residue

        self.assertEqual(classify_phase_d_movement({
            'selected': 0, 'qa_pass': 0, 'qa_reject': 0, 'canonical': 0,
        }), 'zero_selection')
        self.assertEqual(classify_phase_d_movement({
            'selected': 22, 'qa_pass': 0, 'qa_reject': 22, 'canonical': 0,
        }), 'selected_rejected')
        self.assertEqual(classify_phase_d_movement({
            'selected': 22, 'qa_pass': 4, 'qa_reject': 18, 'canonical': 0,
        }), 'selected_passed_no_canonical')
        self.assertEqual(classify_phase_d_movement({
            'selected': 22, 'qa_pass': 4, 'qa_reject': 18, 'canonical': 4,
        }), 'milestone_candidate')
        self.assertEqual(classify_phase_d_movement({
            'selected': 22, 'qa_pass': 0, 'qa_reject': 22, 'canonical': 0,
        }, followup_only=True), 'followup_only_not_anchor_closure')
        selector = classify_phase_d_selector_residue({
            'rows_selected': 12,
            'dat_telemetry': {
                'dat_selected_count': 0,
                'dat_qa_pass_count': 0,
                'dat_qa_reject_count': 0,
                'dat_pre_qa_skipped_count': 12,
                'dat_pre_qa_terminal_result_count': 12,
                'dat_empty_file_skipped_count': 12,
            },
        })
        self.assertTrue(selector.get('present'))
        self.assertEqual(
            selector.get('selector_residue_class'),
            'empty_dat_residue_after_nonzero_dat_already_evaluated',
        )

        cases = [
            ('QA_DAT_EMPTY_FILE', 'empty_dat_file'),
            ('QA_DAT_PATIENT_ANCHOR_MISSING', 'patient_anchor_missing'),
            ('QA_DAT_PAYER_ANCHOR_MISSING', 'payer_anchor_missing'),
        ]
        for code, blocker in cases:
            result = classify_dat_reject_next_action({
                'dat_telemetry': {'dat_qa_reject_counts_by_reason': {code: 3}},
            })
            self.assertEqual(result.get('dominant_reject_code'), code)
            self.assertEqual(result.get('dominant_reject_count'), 3)
            self.assertEqual(result.get('dat_reject_blocker_class'), blocker)
            self.assertIn('developer_action:', result.get('recommended_developer_action'))

        mixed = classify_dat_reject_next_action({
            'dat_telemetry': {
                'dat_qa_reject_counts_by_reason': {
                    'QA_DAT_PATIENT_ANCHOR_MISSING': 5,
                    'QA_DAT_PAYER_ANCHOR_MISSING': 5,
                },
            },
        })
        self.assertEqual(mixed.get('dominant_reject_code'), 'QA_DAT_PATIENT_ANCHOR_MISSING')
        self.assertEqual(mixed.get('dat_reject_blocker_class'), 'mixed')

    def test_dat_qa_full_block_uses_phase_d_context_for_stale_resolver_evidence(self):
        """DAT full-block evidence is keyed by Phase D run id, not the shadow anchor."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260508-145600-48c930d4'
            phase_d = '20260508-145640-071f6b84'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_d_dat_selected_count': 419,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 419,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                },
            )
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'context_run_id': phase_d,
                    'status': 'active',
                },
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(phase_d)), {
                'run_id': phase_d,
            })
            with open(os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(phase_d)), 'w', encoding='utf-8') as f:
                f.write(json.dumps({'reject_code': 'QA_DAT_PAYER_ANCHOR_MISSING'}) + '\n')
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'F', 'files': [shadow_path], 'required_missing': []},
                    {'code': 'D', 'files': [], 'required_missing': []},
                ],
                'diagnostics_state': {},
            }

            candidate, skip = crr._IMPL__build_phase_d_dat_qa_full_block_recommendation(
                repo,
                snapshot,
                {},
                False,
            )

        self.assertEqual(skip, '')
        self.assertEqual(candidate.get('recommended_action_kind'), 'phase_d_dat_verification_rerun')
        preview = candidate.get('action_preview', {})
        self.assertEqual(preview.get('phase_d_context_run_id'), phase_d)
        self.assertTrue(str(preview.get('phase_d_summary_path', '')).endswith(
            'qa_canonical_summary_{0}.json'.format(phase_d)))
        self.assertTrue(str(preview.get('qa_reject_samples_path', '')).endswith(
            'qa_reject_samples_{0}.jsonl'.format(phase_d)))
        self.assertEqual(
            preview.get('dat_payer_resolution_evidence_status'),
            'stale_pre_resolution_diagnostics',
        )

    def test_dat_qa_full_block_uses_fresh_phase_d_context_before_shadow_counters(self):
        """A resolved focused Phase D rerun must suppress older shadow full-block counters."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260508-145600-48c930d4'
            old_phase_d = '20260508-145640-071f6b84'
            fresh_phase_d = '20260508-231835-e58e4826'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_run_ids': {'D': old_phase_d},
                    'phase_d_dat_selected_count': 419,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 419,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                },
            )
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(fresh_phase_d)),
                {
                    'run_id': fresh_phase_d,
                    'dat_telemetry': {
                        'dat_selected_count': 419,
                        'dat_qa_pass_count': 397,
                        'dat_qa_reject_count': 22,
                        'dat_canonical_record_count': 1610,
                    },
                },
            )
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'phase_d_remediation': {
                    'issue_code': '',
                    'context_run_id': fresh_phase_d,
                    'remediation_context_run_id': fresh_phase_d,
                    'status': 'resolved',
                },
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'F', 'files': [shadow_path], 'required_missing': []},
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': []},
                ],
                'diagnostics_state': {},
            }

            candidate, skip = crr._IMPL__build_phase_d_dat_qa_full_block_recommendation(
                repo,
                snapshot,
                {},
                False,
            )

        self.assertIsNone(candidate)
        self.assertIn('current Phase D context run_id={0}'.format(fresh_phase_d), skip)
        self.assertIn('dat_qa_pass_count=397', skip)
        self.assertIn('dat_canonical_record_count=1610', skip)

    def test_dat_qa_full_block_loads_resolved_context_summary_before_shadow_counters(self):
        """Resolved Phase D context on disk must supersede stale anchored shadow counters."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260508-145600-48c930d4'
            old_phase_d = '20260508-145640-071f6b84'
            fresh_phase_d = '20260508-231835-e58e4826'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_run_ids': {'D': old_phase_d},
                    'phase_d_dat_selected_count': 419,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 419,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                },
            )
            old_phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(old_phase_d)),
                {
                    'run_id': old_phase_d,
                    'dat_telemetry': {
                        'dat_selected_count': 419,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 419,
                        'dat_canonical_record_count': 0,
                    },
                },
            )
            self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(fresh_phase_d)),
                {
                    'run_id': fresh_phase_d,
                    'dat_telemetry': {
                        'dat_selected_count': 419,
                        'dat_qa_pass_count': 397,
                        'dat_qa_reject_count': 22,
                        'dat_canonical_record_count': 1610,
                    },
                },
            )
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'context_run_id': fresh_phase_d,
                    'remediation_context_run_id': fresh_phase_d,
                    'status': 'resolved',
                },
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'F', 'files': [shadow_path], 'required_missing': []},
                    {'code': 'D', 'files': [old_phase_d_path], 'required_missing': []},
                ],
                'diagnostics_state': {},
            }

            candidate, skip = crr._IMPL__build_phase_d_dat_qa_full_block_recommendation(
                repo,
                snapshot,
                {},
                False,
            )

        self.assertIsNone(candidate)
        self.assertIn('current Phase D context run_id={0}'.format(fresh_phase_d), skip)
        self.assertIn('dat_qa_pass_count=397', skip)
        self.assertIn('dat_canonical_record_count=1610', skip)

    def test_dat_qa_full_block_still_recommends_without_fresher_resolving_phase_d(self):
        """Stale shadow full-block remains actionable when no fresher Phase D DAT summary exists."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260509-140000-anchor0001'
            old_phase_d = '20260509-140100-phase0002'
            missing_fresh_phase_d = '20260509-231835-missing03'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_run_ids': {'D': old_phase_d},
                    'phase_d_dat_selected_count': 17,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 17,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                },
            )
            old_phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(old_phase_d)),
                {'run_id': old_phase_d, 'dat_telemetry': {}},
            )
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'context_run_id': missing_fresh_phase_d,
                    'remediation_context_run_id': missing_fresh_phase_d,
                    'status': 'resolved',
                },
            })
            with open(os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(old_phase_d)), 'w', encoding='utf-8') as handle:
                handle.write(json.dumps({'dat_payer_resolution_synthetic': True}) + '\n')
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'F', 'files': [shadow_path], 'required_missing': []},
                    {'code': 'D', 'files': [old_phase_d_path], 'required_missing': []},
                ],
                'diagnostics_state': {},
            }

            candidate, skip = crr._IMPL__build_phase_d_dat_qa_full_block_recommendation(
                repo,
                snapshot,
                {},
                False,
            )

        self.assertEqual(skip, '')
        self.assertIsNotNone(candidate)
        self.assertEqual(candidate.get('recommended_action_kind'), 'review_dat_qa_full_block')
        preview = candidate.get('action_preview', {})
        self.assertEqual(preview.get('anchored_diagnosis_source'), 'anchored_phase_d_shadow')
        self.assertEqual(int(preview.get('dat_qa_reject_count') or 0), 17)

    def test_dat_qa_full_block_empty_phase_d_dat_telemetry_keeps_shadow_counters(self):
        """Empty dat_telemetry must not suppress shadow DAT counters when resolving QA full-block review."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260509-120000-anchor0001'
            phase_d_rid = '20260509-120100-phase0002'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_run_ids': {'D': phase_d_rid},
                    'phase_d_dat_selected_count': 12,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 12,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                },
            )
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(phase_d_rid)),
                {
                    'run_id': phase_d_rid,
                    'dat_telemetry': {},
                },
            )
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'context_run_id': phase_d_rid,
                    'status': 'active',
                },
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'F', 'files': [shadow_path], 'required_missing': []},
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': []},
                ],
                'diagnostics_state': {},
            }

            candidate, skip = crr._IMPL__build_phase_d_dat_qa_full_block_recommendation(
                repo,
                snapshot,
                {},
                False,
            )

        self.assertEqual(skip, '')
        self.assertIsNotNone(candidate)
        preview = candidate.get('action_preview', {})
        self.assertEqual(preview.get('anchored_diagnosis_source'), 'anchored_phase_d_shadow')
        self.assertEqual(int(preview.get('dat_selected_count') or 0), 12)
        self.assertEqual(int(preview.get('dat_qa_reject_count') or 0), 12)

    def test_dat_qa_full_block_reject_samples_paired_to_snapshot_qa_summary_not_remediation_run(self):
        """Reject JSONL must match the snapshot Phase D summary path, not a looser remediation run id."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260508-200000-anchor0001'
            other = '20260508-200100-other00002'
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor)),
                {'run_id': anchor, 'phase_d_dat_selected_count': 5},
            )
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_d_dat_selected_count': 5,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 5,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                },
            )
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'context_run_id': other,
                    'status': 'active',
                },
            })
            with open(os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(anchor)), 'w', encoding='utf-8') as handle:
                handle.write(json.dumps({'reject_code': 'QA_DAT_PAYER_ANCHOR_MISSING'}) + '\n')
            with open(os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(other)), 'w', encoding='utf-8') as handle:
                handle.write(json.dumps({'dat_payer_resolution_synthetic': True}) + '\n')
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'F', 'files': [shadow_path], 'required_missing': []},
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': []},
                ],
                'diagnostics_state': {},
            }

            candidate, skip = crr._IMPL__build_phase_d_dat_qa_full_block_recommendation(
                repo,
                snapshot,
                {},
                False,
            )

        self.assertEqual(skip, '')
        self.assertIsNotNone(candidate)
        preview = candidate.get('action_preview', {})
        self.assertTrue(str(preview.get('phase_d_summary_path', '')).endswith(
            'qa_canonical_summary_{0}.json'.format(anchor)))
        self.assertTrue(str(preview.get('qa_reject_samples_path', '')).endswith(
            'qa_reject_samples_{0}.jsonl'.format(anchor)))
        self.assertEqual(
            preview.get('dat_payer_resolution_evidence_status'),
            'stale_pre_resolution_diagnostics',
        )

    def test_live_dat_full_block_context_does_not_override_anchor_zero_selection(self):
        """A later live Phase D full-block context must not become anchored review evidence."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260511-111543-a89e7f43'
            phase_b = '20260511-111544-4d5eb041'
            phase_c = '20260511-111603-44a78cb4'
            anchored_d = '20260511-111605-4600273d'
            phase_e = '20260511-111606-da6979e0'
            live_d = '20260511-111655-fe6d947f'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_run_ids': {'B': phase_b, 'C': phase_c, 'D': anchored_d, 'E': phase_e},
                    'phase_b_dat_manifest_rows_count': 419,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
            )
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchored_d)),
                {
                    'run_id': anchored_d,
                    'dat_telemetry': {
                        'dat_selected_count': 0,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 0,
                        'dat_canonical_record_count': 0,
                    },
                    'post_medisoft_blocked_stage': 'phase_d',
                },
            )
            self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(live_d)),
                {
                    'run_id': live_d,
                    'dat_telemetry': {
                        'dat_selected_count': 22,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 22,
                        'dat_canonical_record_count': 0,
                    },
                },
            )
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'context_run_id': live_d,
                    'remediation_context_run_id': live_d,
                    'status': 'active',
                },
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': [], 'status': 'complete'},
                    {'code': 'F', 'files': [shadow_path], 'required_missing': [], 'status': 'complete'},
                ],
                'phase_run_ids': {'B': phase_b, 'C': phase_c, 'D': anchored_d, 'E': phase_e},
                'diagnostics_state': {},
                'lineage_issues': [],
            }

            rec = crr._IMPL_compute_operator_support_send_recommendation_core(
                repo,
                snapshot,
                True,
                '',
                False,
                recommendation_source_scope='anchored_completed_run',
                recommendation_anchor_run_id=anchor,
                recommendation_live_run_id=anchor,
                recommendation_live_run_status='completed',
            )

        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('dat_smoke_self_decision'), 'run_now')
        self.assertIn('live/remediation context reports PHASE_D_DAT_QA_FULL_BLOCK', rec.get('dat_qa_full_block_not_triggered_reason'))
        preview = rec.get('action_preview', {})
        self.assertEqual(preview.get('anchor_run_id'), anchor)
        self.assertEqual(preview.get('phase_d_context_run_id'), anchored_d)

    def test_phase_d_followup_review_accepts_terminal_manual_attempt_without_historical_execution(self):
        """A terminal same-anchor Phase D diagnostic is enough to stop replay loops."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260513-153538-0e2d7d22'
            anchored_d = '20260513-153610-497751af'
            follow_d = '20260513-153627-5366cf92'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_run_ids': {'D': anchored_d},
                    'phase_b_dat_manifest_rows_count': 420,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                },
            )
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchored_d)),
                {
                    'run_id': anchored_d,
                    'dat_telemetry': {
                        'dat_selected_count': 0,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 0,
                        'dat_canonical_record_count': 0,
                    },
                },
            )
            follow_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(follow_d)),
                {
                    'run_id': follow_d,
                    'dat_telemetry': {
                        'dat_selected_count': 8,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 8,
                        'dat_canonical_record_count': 0,
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_PATIENT_ANCHOR_MISSING': 8},
                    },
                },
            )
            self._write_json(os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-1.json'), {
                'schema_version': 'diagnostic_attempt_v1',
                'diagnostic_kind': 'phase_d_manual',
                'target_anchor_run_id': anchor,
                'target_context_run_id': anchored_d,
                'status': 'succeeded',
                'returncode': 0,
                'accepted_for_anchor': True,
                'terminal': True,
                'primary_report_path': follow_path,
            })
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'last_phase_d_run_id': follow_d,
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': [], 'status': 'complete'},
                    {'code': 'F', 'files': [shadow_path], 'required_missing': [], 'status': 'complete'},
                ],
                'phase_run_ids': {'D': anchored_d},
                'diagnostics_state': {},
                'lineage_issues': [],
            }

            candidate, skip = crr._build_phase_d_followup_review_recommendation(repo, snapshot, False)

        self.assertEqual(skip, '')
        self.assertIsNotNone(candidate)
        self.assertEqual(candidate.get('recommended_action_kind'), 'send_bundle')
        preview = candidate.get('action_preview') or {}
        self.assertEqual(preview.get('followup_phase_d_run_id'), follow_d)
        self.assertEqual(preview.get('dat_selected_count'), 8)
        self.assertEqual(preview.get('dominant_reject_code'), 'QA_DAT_PATIENT_ANCHOR_MISSING')
        self.assertIn('terminal Phase D diagnostic', ' '.join(candidate.get('action_reason_lines') or []))

    def test_terminal_source_shape_followup_recommends_embedded_terminalization_first(self):
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = 'anchor-terminal'
            anchored_d = 'd-anchor'
            follow_d = 'd-follow'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {'run_id': anchor, 'phase_run_ids': {'D': anchored_d}, 'phase_b_dat_manifest_rows_count': 4},
            )
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchored_d)),
                {'run_id': anchored_d, 'dat_telemetry': {'dat_selected_count': 0}},
            )
            follow_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(follow_d)),
                {
                    'run_id': follow_d,
                    'dat_telemetry': {
                        'dat_selected_count': 4,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 4,
                        'dat_canonical_record_count': 0,
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_PATIENT_ANCHOR_MISSING': 4},
                        'dat_terminal_reject_counts_by_subcode': {'DAT_PATID_UNREACHABLE_SOURCE_SHAPE': 4},
                    },
                },
            )
            self._write_json(os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-1.json'), {
                'diagnostic_kind': 'phase_d_manual',
                'target_anchor_run_id': anchor,
                'target_context_run_id': anchored_d,
                'status': 'succeeded',
                'returncode': 0,
                'accepted_for_anchor': True,
                'terminal': True,
                'primary_report_path': follow_path,
            })
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'last_phase_d_run_id': follow_d,
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': [], 'status': 'complete'},
                    {'code': 'F', 'files': [shadow_path], 'required_missing': [], 'status': 'complete'},
                ],
                'phase_run_ids': {'D': anchored_d},
                'diagnostics_state': {},
                'lineage_issues': [],
            }

            candidate, skip = crr._build_phase_d_followup_review_recommendation(repo, snapshot, False)

        self.assertEqual(skip, '')
        self.assertEqual(candidate.get('recommended_action_kind'), 'resolve_dat_terminal_source_shape_rejects')
        self.assertFalse(candidate.get('action_requires_confirmation'))
        self.assertFalse(candidate.get('operator_manual_review_required'))
        self.assertTrue(candidate.get('action_preview', {}).get('terminal_source_shape_rejects'))
        self.assertIn('no XP operator helper', ' '.join(candidate.get('action_reason_lines') or []))
        stamped = crr._apply_autonomous_followthrough_policy(candidate)
        self.assertTrue(stamped.get('autonomous_followthrough_allowed'))
        self.assertEqual(stamped.get('autonomous_followthrough_sequence', [])[0].get('step'), 'run_embedded_action')

    def test_terminal_source_shape_report_dedupes_and_recommendation_becomes_send_bundle(self):
        from MediCafe import cloud_readiness_actions as cra
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = 'anchor-terminal'
            anchored_d = 'd-anchor'
            follow_d = 'd-follow'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {'run_id': anchor, 'phase_run_ids': {'D': anchored_d}, 'phase_b_dat_manifest_rows_count': 4},
            )
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchored_d)),
                {'run_id': anchored_d, 'dat_telemetry': {'dat_selected_count': 0}},
            )
            follow_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(follow_d)),
                {
                    'run_id': follow_d,
                    'dat_telemetry': {
                        'dat_selected_count': 4,
                        'dat_qa_reject_count': 4,
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_PATIENT_ANCHOR_MISSING': 4},
                        'dat_terminal_reject_counts_by_subcode': {'DAT_PATID_UNREACHABLE_SOURCE_SHAPE': 4},
                    },
                },
            )
            self._write_json(os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-1.json'), {
                'diagnostic_kind': 'phase_d_manual',
                'target_anchor_run_id': anchor,
                'target_context_run_id': anchored_d,
                'status': 'succeeded',
                'returncode': 0,
                'accepted_for_anchor': True,
                'terminal': True,
                'primary_report_path': follow_path,
            })
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'last_phase_d_run_id': follow_d,
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': [], 'status': 'complete'},
                    {'code': 'F', 'files': [shadow_path], 'required_missing': [], 'status': 'complete'},
                ],
                'phase_run_ids': {'D': anchored_d},
                'diagnostics_state': {},
                'lineage_issues': [],
            }

            ok1, msg1, data1 = cra.write_dat_terminal_source_shape_rejects_report(
                repo, anchor, follow_d, qa_summary_path=follow_path, terminal_reject_count=4)
            ok2, msg2, data2 = cra.write_dat_terminal_source_shape_rejects_report(
                repo, anchor, follow_d, qa_summary_path=follow_path, terminal_reject_count=4)
            candidate, skip = crr._build_phase_d_followup_review_recommendation(repo, snapshot, False)

        self.assertTrue(ok1)
        self.assertTrue(ok2)
        self.assertIn('created', msg1)
        self.assertIn('already exists', msg2)
        self.assertEqual(data1.get('json_path'), data2.get('json_path'))
        self.assertEqual(skip, '')
        self.assertEqual(candidate.get('recommended_action_kind'), 'send_bundle')
        self.assertEqual(candidate.get('action_preview', {}).get('terminalization_report_path'), data1.get('json_path'))

    def test_terminal_source_shape_report_scopes_db_terminalization_to_followup_reject_samples(self):
        from MediCafe import cloud_readiness_actions as cra
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = os.path.join(lab, 'unified_model_xp.db')
            reject_path = os.path.join(reports, 'qa_reject_samples_d-follow.jsonl')
            with open(reject_path, 'w', encoding='utf-8') as handle:
                handle.write(json.dumps({
                    'artifact_id': 101,
                    'reject_code': 'QA_DAT_PATIENT_ANCHOR_MISSING',
                    'reason': 'DAT_PATID_UNREACHABLE_SOURCE_SHAPE',
                }) + '\n')
            conn = sqlite3.connect(db_path)
            try:
                conn.execute(
                    'CREATE TABLE qa_result (artifact_id INTEGER, qa_stage TEXT, status TEXT, reject_code TEXT, reject_reason TEXT)')
                conn.execute(
                    'CREATE TABLE replay_queue (artifact_id INTEGER, status TEXT)')
                for artifact_id in (101, 202):
                    conn.execute(
                        'INSERT INTO qa_result VALUES (?, "phase_d", "reject", "QA_DAT_PATIENT_ANCHOR_MISSING", ?)',
                        (artifact_id, 'terminal DAT_PATID_UNREACHABLE_SOURCE_SHAPE reject'),
                    )
                    conn.execute(
                        'INSERT INTO replay_queue VALUES (?, "pending")',
                        (artifact_id,),
                    )
                conn.commit()
            finally:
                conn.close()

            ok, msg, data = cra.write_dat_terminal_source_shape_rejects_report(
                repo,
                'anchor-terminal',
                'd-follow',
                qa_reject_samples_path=reject_path,
                terminal_reject_count=1,
            )

            self.assertTrue(ok)
            self.assertIn('created', msg)
            self.assertEqual(data.get('artifact_scope_count'), 1)
            self.assertEqual(data.get('matching_qa_result_count'), 1)
            self.assertEqual(data.get('terminalized_replay_count'), 1)

            conn = sqlite3.connect(db_path)
            try:
                rows = dict(conn.execute(
                    'SELECT artifact_id, status FROM replay_queue ORDER BY artifact_id'
                ).fetchall())
            finally:
                conn.close()
        self.assertEqual(rows, {101: 'abandoned', 202: 'pending'})

    def test_terminal_source_shape_report_does_not_broaden_when_reject_samples_unusable(self):
        from MediCafe import cloud_readiness_actions as cra

        cases = [
            ('omitted_missing', None, 'missing', False),
            ('missing', None, 'missing', True),
            ('empty', '', 'empty', True),
            ('invalid', '{not-json}\n', 'invalid', True),
            ('no_artifact_id', json.dumps({'reject_code': 'QA_DAT_PATIENT_ANCHOR_MISSING'}) + '\n', 'no_artifact_id', True),
        ]
        for suffix, body, expected_scope_status, pass_path in cases:
            with self.subTest(suffix=suffix):
                with tempfile.TemporaryDirectory() as repo:
                    lab = os.path.join(repo, 'lab')
                    reports = os.path.join(lab, 'reports')
                    os.makedirs(reports)
                    db_path = os.path.join(lab, 'unified_model_xp.db')
                    reject_path = os.path.join(reports, 'qa_reject_samples_d-follow-{0}.jsonl'.format(suffix))
                    if body is not None:
                        with open(reject_path, 'w', encoding='utf-8') as handle:
                            handle.write(body)
                    conn = sqlite3.connect(db_path)
                    try:
                        conn.execute(
                            'CREATE TABLE qa_result (artifact_id INTEGER, qa_stage TEXT, status TEXT, reject_code TEXT, reject_reason TEXT)')
                        conn.execute(
                            'CREATE TABLE replay_queue (artifact_id INTEGER, status TEXT)')
                        for artifact_id in (101, 202):
                            conn.execute(
                                'INSERT INTO qa_result VALUES (?, "phase_d", "reject", "QA_DAT_PATIENT_ANCHOR_MISSING", ?)',
                                (artifact_id, 'terminal DAT_PATID_UNREACHABLE_SOURCE_SHAPE reject'),
                            )
                            conn.execute(
                                'INSERT INTO replay_queue VALUES (?, "pending")',
                                (artifact_id,),
                            )
                        conn.commit()
                    finally:
                        conn.close()

                    if pass_path:
                        ok, msg, data = cra.write_dat_terminal_source_shape_rejects_report(
                            repo,
                            'anchor-terminal-{0}'.format(suffix),
                            'd-follow-{0}'.format(suffix),
                            qa_reject_samples_path=reject_path,
                            terminal_reject_count=2,
                        )
                    else:
                        ok, msg, data = cra.write_dat_terminal_source_shape_rejects_report(
                            repo,
                            'anchor-terminal-{0}'.format(suffix),
                            'd-follow-{0}'.format(suffix),
                            terminal_reject_count=2,
                        )

                    self.assertTrue(ok)
                    self.assertIn('created', msg)
                    self.assertEqual(data.get('terminalization_status'), 'no_scoped_reject_samples')
                    self.assertEqual(data.get('terminalization_db_status'), 'no_scoped_reject_samples')
                    self.assertEqual(data.get('qa_reject_sample_scope_status'), expected_scope_status)
                    self.assertEqual(data.get('artifact_scope_count'), 0)
                    self.assertEqual(data.get('terminalized_replay_count'), 0)

                    conn = sqlite3.connect(db_path)
                    try:
                        rows = dict(conn.execute(
                            'SELECT artifact_id, status FROM replay_queue ORDER BY artifact_id'
                        ).fetchall())
                    finally:
                        conn.close()
                self.assertEqual(rows, {101: 'pending', 202: 'pending'})

    def test_compute_recommendation_prefers_terminal_followup_over_historical_replay(self):
        """Follow-up DAT reject telemetry is the current terminal state, not another replay request."""
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = 'anchor'
            phase_c = 'phase-c'
            anchored_d = 'd-anchor'
            follow_d = 'd-followup'
            shadow_path = self._write_json(
                os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                {
                    'run_id': anchor,
                    'phase_run_ids': {'C': phase_c, 'D': anchored_d},
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 100,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_b_dat_manifest_rows_count': 420,
                },
            )
            phase_c_path = self._write_json(
                os.path.join(reports, 'ingest_write_summary_{0}.json'.format(phase_c)),
                {
                    'run_id': phase_c,
                    'rows_inserted': 0,
                    'rows_skipped_duplicate': 100,
                },
            )
            phase_d_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchored_d)),
                {
                    'run_id': anchored_d,
                    'rows_selected': 0,
                    'qa_pass_count': 0,
                    'qa_reject_count': 0,
                    'qa_policy_version': 'qa_v2',
                    'historical_reprocess_candidate': True,
                    'historical_reprocess_targeted_artifact_classes': ['dat'],
                    'historical_reject_counts_by_class': {'dat': 8},
                    'pending_replay_counts_by_class': {'dat': 8},
                    'historical_reject_counts_by_version': {'qa_v1': 8},
                    'dat_telemetry': {
                        'dat_selected_count': 0,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 0,
                        'dat_canonical_record_count': 0,
                    },
                },
            )
            follow_path = self._write_json(
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(follow_d)),
                {
                    'run_id': follow_d,
                    'dat_telemetry': {
                        'dat_selected_count': 8,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 8,
                        'dat_canonical_record_count': 0,
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_PATIENT_ANCHOR_MISSING': 8},
                    },
                },
            )
            self._write_json(os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-1.json'), {
                'schema_version': 'diagnostic_attempt_v1',
                'diagnostic_kind': 'phase_d_manual',
                'target_anchor_run_id': anchor,
                'target_context_run_id': anchored_d,
                'status': 'succeeded',
                'returncode': 0,
                'accepted_for_anchor': True,
                'primary_report_path': follow_path,
            })
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_phase_c_ok': True,
                'last_phase_d_run_id': follow_d,
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'phase_rows': [
                    {'code': 'C', 'files': [phase_c_path], 'required_missing': [], 'status': 'complete'},
                    {'code': 'D', 'files': [phase_d_path], 'required_missing': [], 'status': 'complete'},
                    {'code': 'F', 'files': [shadow_path], 'required_missing': [], 'status': 'complete'},
                ],
                'phase_run_ids': {'C': phase_c, 'D': anchored_d},
                'diagnostics_state': {},
                'lineage_issues': [],
            }
            rec = crr._IMPL_compute_operator_support_send_recommendation_core(
                repo,
                snapshot,
                True,
                '',
                False,
                recommendation_source_scope='anchored_completed_run',
                recommendation_anchor_run_id=anchor,
                recommendation_live_run_id=anchor,
                recommendation_live_run_status='completed',
            )

        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertFalse(rec.get('historical_reprocess_available'))
        self.assertIn('terminal follow-up Phase D evidence', rec.get('historical_reprocess_not_triggered_reason', ''))
        self.assertIn('Follow-up Phase D run_id={0}'.format(follow_d), ' '.join(rec.get('action_reason_lines') or []))

    def test_compute_operator_support_send_recommendation_prefers_historical_reprocess_for_duplicate_only_dat(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommended_artifact_classes'), ['dat'])
        self.assertEqual(rec.get('recommended_report_kind'), 'artifact_triage_pack')
        self.assertIn('re-evaluate historical Phase D rejects', rec.get('summary_line', ''))
        self.assertIn('Phase B DAT manifest did not indicate discovered DAT rows', rec.get('dat_smoke_not_triggered_reason', ''))
        self.assertFalse(rec.get('action_requires_confirmation'))

    def test_layer1_runbook_historical_reprocess_action_overrides_default_send_bundle(self):
        from MediCafe import cloud_readiness_recommendations as crr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({
                    'phase_d_remediation': {
                        'issue_code': 'PHASE_D_HISTORICAL_BACKLOG_STALE_REJECTS',
                        'status': 'active',
                        'verification_target': 'historical_phase_d_pipeline',
                        'verification_scope': 'historical_reprocess',
                        'context_run_id': 'phase-d-1',
                    },
                }, handle)
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': 'anchor-1',
                'diagnostics_state': {},
                'source_summary_paths': {},
            }
            layer1_model = {
                'layer1_readiness_status': 'not_reached',
                'layer1_current_blocker': 'phase_d_zero_selection',
                'layer1_blocked_at_phase': 'D',
                'phase_d_selected_rows': 0,
            }
            with patch.object(crr, '_build_historical_phase_d_reprocess_recommendation', return_value=(None, 'historical unavailable')):
                with patch.object(crr, '_build_phase_d_dat_smoke_recommendation', return_value=(None, 'smoke unavailable')):
                    with patch.object(crr, '_build_phase_d_dat_qa_full_block_recommendation', return_value=(None, 'qa unavailable')):
                        with patch.object(crr, '_build_phase_d_selector_residue_recommendation', return_value=(None, 'selector unavailable')):
                            with patch.object(crr, '_build_phase_d_historical_replay_no_movement_recommendation', return_value=(None, 'no movement unavailable')):
                                with patch.object(crr, '_build_phase_d_followup_review_recommendation', return_value=(None, 'followup unavailable')):
                                    with patch('MediCafe.layer1_readiness_model.build_layer1_readiness_model', return_value=layer1_model):
                                        rec = crr._IMPL_compute_operator_support_send_recommendation_core(
                                            repo,
                                            snapshot,
                                            True,
                                            '',
                                            False,
                                            recommendation_source_scope='anchored_completed_run',
                                            recommendation_anchor_run_id='anchor-1',
                                            recommendation_live_run_id='anchor-1',
                                            recommendation_live_run_status='completed',
                                        )
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('preferred_when_stable_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'historical_phase_d_reprocess')
        self.assertFalse(rec.get('operator_manual_review_required'))
        self.assertFalse(rec.get('action_requires_confirmation'))
        self.assertTrue(rec.get('autonomous_followthrough_allowed'))
        self.assertEqual(
            (rec.get('autonomous_followthrough_sequence') or [{}])[0].get('step'),
            'run_diagnostic_action',
        )

    def test_historical_reprocess_not_recommended_after_same_anchor_replay_moved_phase_d(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            with open(os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt'), 'w', encoding='utf-8') as handle:
                handle.write('Historical Phase D Re-Evaluation Execution\n')
                handle.write('remediation_context_run_id={0}\n'.format(anchor))
                handle.write('execution_status=completed\n')
                handle.write('rows_reselected_for_next_phase_d_count=17\n')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({
                    'last_phase_d_run_id': 'phase-d-followup',
                    'last_phase_d_rows_selected': 17,
                    'last_phase_d_reject_count': 17,
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 10,
                        'dat_qa_reject_count': 10,
                    },
                }, handle)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                anchor,
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                    'run_id': anchor,
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {
                    'run_id': 'phase-d-anchor',
                    'rows_selected': 0,
                    'qa_pass_count': 0,
                    'qa_reject_count': 0,
                    'qa_policy_version': 'qa_v2',
                    'historical_reprocess_candidate': True,
                    'historical_reprocess_targeted_artifact_classes': ['dat'],
                    'historical_reject_counts_by_class': {'dat': 17},
                },
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 17},
                                'pending_replay_counts_by_class': {'dat': 17},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertFalse(rec.get('historical_reprocess_available'))
        self.assertIn('same-anchor historical replay already completed', rec.get('historical_reprocess_not_triggered_reason', ''))

    def test_compute_operator_support_send_recommendation_suppresses_historical_when_live_phase_c_failed(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({
                    'last_phase_c_ok': False,
                    'last_phase_c_error_code': 'PHASE_C_DB_WRITE_ERROR',
                }, handle)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260430-020617-7952eda8',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 814,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 814},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertFalse(rec.get('historical_reprocess_available'))
        self.assertIn('PHASE_C_DB_WRITE_ERROR', rec.get('historical_reprocess_not_triggered_reason', ''))

    def test_compute_operator_support_send_recommendation_uses_phase_d_summary_fallback_when_live_reject_snapshot_empty(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260410-135950-415f1239',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 780,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 780},
                {
                    'rows_selected': 0,
                    'qa_pass_count': 0,
                    'qa_reject_count': 0,
                    'qa_policy_version': 'qa_v2',
                    'historical_reprocess_candidate': True,
                    'historical_reprocess_targeted_artifact_classes': ['csv', 'dat', 'docx'],
                    'historical_reject_counts_by_class': {'csv': 10, 'dat': 785, 'docx': 6},
                    'historical_reject_counts_by_version': {'qa_v1': 6, 'qa_v2': 795},
                },
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommended_artifact_classes'), ['csv', 'dat', 'docx'])
        self.assertIn(
            'Using anchored Phase D summary fallback for historical replay targeting',
            ' '.join(rec.get('action_reason_lines', []))
        )

    def test_compute_operator_support_send_recommendation_uses_phase_d_summary_fallback_when_live_reject_snapshot_unavailable(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260410-135950-415f1239',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 780,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 780},
                {
                    'rows_selected': 0,
                    'qa_pass_count': 0,
                    'qa_reject_count': 0,
                    'qa_policy_version': 'qa_v2',
                    'historical_reprocess_candidate': True,
                    'historical_reprocess_targeted_artifact_classes': ['csv', 'dat', 'docx'],
                    'historical_reject_counts_by_class': {'csv': 10, 'dat': 785, 'docx': 6},
                    'historical_reject_counts_by_version': {'qa_v1': 6, 'qa_v2': 795},
                },
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', None):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommended_artifact_classes'), ['csv', 'dat', 'docx'])
        self.assertIn(
            'Using anchored Phase D summary fallback for historical replay targeting',
            ' '.join(rec.get('action_reason_lines', []))
        )

    def test_anchored_duplicate_only_historical_recommendation_with_lineage_skew_issue(self):
        """
        Real anchored XP runs: Phase D zero-selection may reference a different Phase C run id than
        shadow phase_run_ids, producing lineage_issues. That must not downgrade to send_bundle when
        duplicate-only + historical rejects still warrant historical_phase_d_reprocess.
        """
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260331-005932-ba25d2aa'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            snapshot['lineage_issues'] = [
                'phase_d_zero_selection_phase_c_run_id_mismatch expected_phase_c=a resolved_phase_c=b',
            ]
            snapshot['diagnostics_state'] = {
                'pipeline_state': 'completed',
                'last_shadow_pipeline_run_id': run_id,
                'active_run_id': '',
            }

            def fake_build(_repo_root, run_id='', **_kwargs):
                return True, '', dict(snapshot)

            with patch.object(cr, '_build_run_artifact_snapshot', side_effect=fake_build):
                with patch.object(cr, '_collect_system_health_artifacts', return_value={
                    'lab_root': lab,
                    'reports_dir': reports,
                    'repo_root': repo,
                    'shadow_report_path': '',
                }):
                    with patch.object(cr, '_build_system_health_pack_context', return_value={
                        'pack_scope': 'completed_run',
                        'anchor_run_id': run_id,
                    }):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={
                            'recommendation': 'send_current_run',
                            'score': 80,
                            'label': 'HIGH',
                        }):
                            with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                                with patch.object(cr, 'is_pipeline_running', return_value=False):
                                    with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                        'ok': True,
                                        'qa_version': 'qa_v2',
                                        'targeted_artifact_classes': ['dat'],
                                        'reject_counts_by_class': {'dat': 389},
                                        'pending_replay_counts_by_class': {'dat': 389},
                                    }):
                                        rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(str(rec.get('recommendation_anchor_run_id', '')), run_id)

    def test_compute_operator_support_send_recommendation_prefers_historical_reprocess_before_dat_smoke(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('follow_on_action_kind'), 'phase_d_dat_smoke')
        self.assertTrue(rec.get('historical_reprocess_available'))
        self.assertTrue(rec.get('dat_smoke_available'))
        self.assertIn('Follow-on after historical replay', ' '.join(rec.get('action_reason_lines', [])))

    def test_compute_operator_support_send_recommendation_does_not_switch_to_historical_while_dat_smoke_started(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260329-171213-1ccb1c51'
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': run_id,
                    'last_requested_context_run_id': run_id,
                    'last_remediation_issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'last_status': 'started',
                    'last_report_path': '',
                    'last_assessment': '',
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'run_id': run_id, 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertFalse(rec.get('historical_reprocess_available'))
        self.assertEqual(rec.get('dat_smoke_self_decision'), 'wait_for_existing_run')
        self.assertIn('DAT smoke is already running', rec.get('why_summary', ''))

    def test_compute_operator_support_send_recommendation_dat_smoke_wait_not_overridden_by_layer1(self):
        """Layer-1 not_reached must not replace 'wait for in-flight DAT smoke' when hist is deferred."""
        from MediCafe import cloud_readiness as cr

        def _forced_layer1_not_reached(*_args, **_kwargs):
            return {
                'layer1_readiness_status': 'not_reached',
                'layer1_current_blocker': 'phase_c_ingest_failed',
                'next_operator_action': 'Resolve Phase C ingest first.',
            }

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260329-171213-1ccb1c51'
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': run_id,
                    'last_requested_context_run_id': run_id,
                    'last_remediation_issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'last_status': 'started',
                    'last_report_path': '',
                    'last_assessment': '',
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'run_id': run_id, 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch('MediCafe.layer1_readiness_model.build_layer1_readiness_model', side_effect=_forced_layer1_not_reached):
                with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                    with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                        with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                            with patch.object(cr, 'is_pipeline_running', return_value=False):
                                with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                    'ok': True,
                                    'qa_version': 'qa_v2',
                                    'targeted_artifact_classes': ['dat'],
                                    'reject_counts_by_class': {'dat': 389},
                                    'pending_replay_counts_by_class': {'dat': 389},
                                }):
                                    rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertTrue(rec.get('dat_smoke_deferred_historical_reprocess'))
        self.assertEqual(rec.get('dat_smoke_self_decision'), 'wait_for_existing_run')
        self.assertIn('DAT smoke is already running', rec.get('why_summary', ''))

    def test_compute_operator_support_send_recommendation_waits_for_stable_when_pipeline_active(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 10,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 10},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=True):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 10},
                                'pending_replay_counts_by_class': {'dat': 10},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'wait_for_stable')

    def test_compute_operator_support_send_recommendation_targets_only_affected_classes(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 12,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 12},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['csv', 'docx'],
                                'reject_counts_by_class': {'csv': 7, 'docx': 5},
                                'pending_replay_counts_by_class': {'csv': 7, 'docx': 5},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_artifact_classes'), ['csv', 'docx'])

    def test_compute_operator_support_send_recommendation_stays_on_send_bundle_without_historical_rejects(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertEqual(rec.get('best_now_action_kind'), 'send_bundle')

    def test_compute_operator_support_send_recommendation_recommends_phase_d_dat_smoke_when_anchored_not_advanced(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 4,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 4, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('preferred_when_stable_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('best_now_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('strict_milestone_verdict'), 'Not advanced')
        self.assertEqual(rec.get('action_preview', {}).get('anchor_run_id'), '20260329-171213-1ccb1c51')

    def test_followup_phase_d_dat_rejects_package_before_smoke_loop(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = 'anchor-1'
            anchor_d = 'phase-d-anchor'
            follow_d = 'phase-d-follow'
            diag = {
                'last_phase_c_ok': True,
                'last_phase_d_run_id': follow_d,
                'last_phase_d_rows_selected': 10,
                'last_phase_d_reject_count': 10,
                'last_phase_d_dat_telemetry': {
                    'dat_selected_count': 10,
                    'dat_qa_reject_count': 10,
                },
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'status': 'active',
                    'context_run_id': follow_d,
                },
            }
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), diag)
            self._write_json(os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)), {
                'run_id': anchor,
                'phase_run_ids': {'D': anchor_d},
                'phase_b_dat_manifest_rows_count': 7,
                'phase_d_dat_selected_count': 0,
                'pipeline_ok': True,
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d)), {
                'run_id': anchor_d,
                'dat_telemetry': {'dat_selected_count': 0},
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(follow_d)), {
                'run_id': follow_d,
                'dat_telemetry': {
                    'dat_selected_count': 10,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 10,
                    'dat_canonical_record_count': 0,
                    'dat_qa_reject_counts_by_reason': {
                        'QA_DAT_PATIENT_ANCHOR_MISSING': 8,
                        'QA_DAT_PAYER_ANCHOR_MISSING': 2,
                    },
                },
            })
            with open(os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(follow_d)), 'w', encoding='utf-8') as f:
                f.write(json.dumps({'reject_reason': 'QA_DAT_PATIENT_ANCHOR_MISSING'}) + '\n')
            with open(os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('\n'.join([
                    'remediation_context_run_id={0}'.format(anchor),
                    'execution_status=completed',
                    'rows_reselected_for_next_phase_d_count=29',
                    '',
                ]))
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'nearest_complete_run_id': '',
                'phase_run_ids': {'D': anchor_d},
                'diagnostics_state': diag,
                'phase_rows': [
                    {
                        'code': 'D',
                        'name': 'D',
                        'status': 'complete',
                        'resolved_run_id': anchor_d,
                        'files': [os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d))],
                        'required_missing': [],
                    },
                    {
                        'code': 'F',
                        'name': 'F',
                        'status': 'complete',
                        'resolved_run_id': anchor,
                        'files': [os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor))],
                        'required_missing': [],
                    },
                ],
            }
            rec = cr.compute_operator_support_send_recommendation_core(
                repo,
                snapshot,
                ok_snap=True,
                snap_msg='',
                pipeline_running=False,
                recommendation_source_scope='anchored_completed_run',
                recommendation_anchor_run_id=anchor,
            )

        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertEqual(rec.get('preferred_when_stable'), 'run_evidence')
        self.assertEqual(rec.get('best_now_send'), 'run_evidence')
        self.assertFalse(rec.get('dat_smoke_available'))
        self.assertIn('newer Phase D movement exists', rec.get('dat_smoke_not_triggered_reason'))
        self.assertTrue(rec.get('phase_d_followup_available'))
        self.assertEqual(rec.get('action_preview', {}).get('followup_phase_d_run_id'), follow_d)
        self.assertEqual(rec.get('action_preview', {}).get('reviewed_anchor_phase_d_run_id'), anchor_d)
        self.assertFalse(rec.get('action_preview', {}).get('accepted_as_reviewed_anchor_milestone'))
        self.assertEqual(rec.get('action_preview', {}).get('dominant_reject_code'), 'QA_DAT_PATIENT_ANCHOR_MISSING')
        self.assertTrue(rec.get('autonomous_followthrough_allowed'))
        self.assertEqual(
            rec.get('autonomous_followthrough_sequence')[0],
            {'step': 'queue_bundle_send', 'send_type': 'run_evidence', 'action_kind': 'send_bundle'},
        )
        assert_workflow_boundary_clean('phase_d_followup_recommendation_sequence', {
            'reviewed_anchor_phase_d_run_id': anchor_d,
            'followup_phase_d_run_id': follow_d,
        }, [
            {
                'name': 'recommendation_action_preview',
                'role': 'recommendation',
                'identity': {
                    'reviewed_anchor_phase_d_run_id': anchor_d,
                    'followup_phase_d_run_id': follow_d,
                },
                'status': 'ready',
                'classification': 'followup_only',
                'claims_completion': False,
                'accepted': False,
            },
            {
                'name': 'autonomous_queue_run_evidence',
                'role': 'autofollow',
                'identity': {
                    'reviewed_anchor_phase_d_run_id': anchor_d,
                    'followup_phase_d_run_id': follow_d,
                },
                'status': 'queued',
                'classification': 'in_flight',
                'claims_completion': False,
                'accepted': False,
            },
        ])

    def test_completed_historical_replay_without_phase_d_movement_packages_selector_telemetry(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = 'anchor-1'
            anchor_d = 'phase-d-anchor'
            diag = {
                'last_phase_c_ok': True,
                'last_shadow_pipeline_run_id': anchor,
                'last_phase_d_run_id': anchor_d,
                'last_phase_d_rows_selected': 0,
                'last_phase_d_reject_count': 0,
                'last_phase_d_pass_count': 0,
                'last_phase_d_dat_telemetry': {
                    'dat_selected_count': 0,
                    'dat_qa_reject_count': 0,
                },
            }
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), diag)
            self._write_json(os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)), {
                'run_id': anchor,
                'phase_run_ids': {'D': anchor_d},
                'phase_b_dat_manifest_rows_count': 7,
                'phase_d_dat_selected_count': 0,
                'pipeline_ok': True,
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d)), {
                'run_id': anchor_d,
                'dat_telemetry': {
                    'dat_selected_count': 0,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 0,
                    'dat_canonical_record_count': 0,
                },
            })
            with open(os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('\n'.join([
                    'remediation_context_run_id={0}'.format(anchor),
                    'execution_status=completed',
                    'rows_reselected_for_next_phase_d_count=29',
                    'rows_invalidated_count=29',
                    '',
                ]))
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'nearest_complete_run_id': '',
                'phase_run_ids': {'D': anchor_d},
                'diagnostics_state': diag,
                'phase_rows': [
                    {
                        'code': 'D',
                        'name': 'D',
                        'status': 'complete',
                        'resolved_run_id': anchor_d,
                        'files': [os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d))],
                        'required_missing': [],
                    },
                    {
                        'code': 'F',
                        'name': 'F',
                        'status': 'complete',
                        'resolved_run_id': anchor,
                        'files': [os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor))],
                        'required_missing': [],
                    },
                ],
            }
            rec = cr.compute_operator_support_send_recommendation_core(
                repo,
                snapshot,
                ok_snap=True,
                snap_msg='',
                pipeline_running=False,
                recommendation_source_scope='anchored_completed_run',
                recommendation_anchor_run_id=anchor,
            )

        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertFalse(rec.get('historical_reprocess_available'))
        self.assertFalse(rec.get('dat_smoke_available'))
        self.assertTrue(rec.get('phase_d_historical_no_movement_available'))
        self.assertIn('same-anchor historical replay already completed', rec.get('historical_reprocess_not_triggered_reason'))
        self.assertIn('same-anchor historical replay already completed', rec.get('dat_smoke_not_triggered_reason'))
        preview = rec.get('action_preview') or {}
        self.assertEqual(preview.get('reviewed_anchor_phase_d_run_id'), anchor_d)
        self.assertEqual(preview.get('phase_d_movement_classification'), 'zero_selection')
        self.assertEqual(preview.get('historical_rows_reselected_for_next_phase_d_count'), 29)
        self.assertEqual(rec.get('autonomous_followthrough_sequence')[0].get('send_type'), 'run_evidence')

    def test_terminal_empty_dat_selector_residue_packages_run_evidence_instead_of_smoke(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = 'anchor-1'
            anchor_d = 'phase-d-anchor'
            diag = {
                'last_phase_c_ok': True,
                'last_shadow_pipeline_run_id': anchor,
                'last_phase_d_run_id': anchor_d,
                'last_phase_d_rows_selected': 12,
                'last_phase_d_reject_count': 12,
                'last_phase_d_pass_count': 0,
                'last_phase_d_dat_telemetry': {
                    'dat_selected_count': 0,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 0,
                    'dat_pre_qa_terminal_result_count': 12,
                    'dat_empty_file_skipped_count': 12,
                    'post_medisoft_blocked_stage': 'pre_qa_terminal_skip',
                },
            }
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), diag)
            self._write_json(os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)), {
                'run_id': anchor,
                'phase_run_ids': {'D': anchor_d},
                'phase_b_dat_manifest_rows_count': 420,
                'phase_d_rows_selected': 12,
                'phase_d_dat_selected_count': 0,
                'pipeline_ok': True,
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d)), {
                'run_id': anchor_d,
                'rows_selected': 12,
                'qa_pass_count': 0,
                'qa_reject_count': 12,
                'reject_counts_by_code': {'QA_DAT_EMPTY_FILE': 12},
                'dat_telemetry': {
                    'dat_candidate_count': 12,
                    'dat_selected_count': 0,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 0,
                    'dat_canonical_record_count': 0,
                    'dat_pre_qa_skipped_count': 12,
                    'dat_pre_qa_terminal_result_count': 12,
                    'dat_empty_file_skipped_count': 12,
                    'dat_pre_qa_skip_counts_by_reason': {'QA_DAT_EMPTY_FILE': 12},
                    'post_medisoft_blocked_stage': 'pre_qa_terminal_skip',
                },
            })
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'nearest_complete_run_id': '',
                'phase_run_ids': {'D': anchor_d},
                'diagnostics_state': diag,
                'phase_rows': [
                    {
                        'code': 'D',
                        'name': 'D',
                        'status': 'complete',
                        'resolved_run_id': anchor_d,
                        'files': [os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d))],
                        'required_missing': [],
                    },
                    {
                        'code': 'F',
                        'name': 'F',
                        'status': 'complete',
                        'resolved_run_id': anchor,
                        'files': [os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor))],
                        'required_missing': [],
                    },
                ],
            }
            rec = cr.compute_operator_support_send_recommendation_core(
                repo,
                snapshot,
                ok_snap=True,
                snap_msg='',
                pipeline_running=False,
                recommendation_source_scope='anchored_completed_run',
                recommendation_anchor_run_id=anchor,
            )

        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertFalse(rec.get('dat_smoke_available'))
        self.assertEqual(rec.get('dat_smoke_self_decision'), 'do_not_run')
        self.assertTrue(rec.get('phase_d_selector_residue_available'))
        self.assertIn('empty DAT selector residue', rec.get('dat_smoke_not_triggered_reason'))
        preview = rec.get('action_preview') or {}
        self.assertEqual(preview.get('phase_d_selector_residue_class'), 'empty_dat_residue_after_nonzero_dat_already_evaluated')
        self.assertEqual(preview.get('dat_pre_qa_terminal_result_count'), 12)
        self.assertEqual(rec.get('autonomous_followthrough_sequence')[0].get('send_type'), 'run_evidence')

    def test_followup_phase_d_pass_without_canonical_packages_canonical_blocker_telemetry(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = 'anchor-1'
            anchor_d = 'phase-d-anchor'
            follow_d = 'phase-d-follow'
            diag = {
                'last_phase_c_ok': True,
                'last_phase_d_run_id': follow_d,
                'last_phase_d_rows_selected': 4,
                'last_phase_d_pass_count': 4,
                'last_phase_d_reject_count': 0,
                'last_phase_d_dat_telemetry': {
                    'dat_selected_count': 4,
                    'dat_qa_pass_count': 4,
                    'dat_qa_reject_count': 0,
                },
            }
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), diag)
            self._write_json(os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)), {
                'run_id': anchor,
                'phase_run_ids': {'D': anchor_d},
                'phase_b_dat_manifest_rows_count': 7,
                'phase_d_dat_selected_count': 0,
                'pipeline_ok': True,
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d)), {
                'run_id': anchor_d,
                'dat_telemetry': {'dat_selected_count': 0},
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(follow_d)), {
                'run_id': follow_d,
                'dat_telemetry': {
                    'dat_selected_count': 4,
                    'dat_qa_pass_count': 4,
                    'dat_qa_reject_count': 0,
                    'dat_canonical_record_count': 0,
                },
            })
            with open(os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('\n'.join([
                    'remediation_context_run_id={0}'.format(anchor),
                    'execution_status=completed',
                    'rows_reselected_for_next_phase_d_count=29',
                    '',
                ]))
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'nearest_complete_run_id': '',
                'phase_run_ids': {'D': anchor_d},
                'diagnostics_state': diag,
                'phase_rows': [
                    {
                        'code': 'D',
                        'name': 'D',
                        'status': 'complete',
                        'resolved_run_id': anchor_d,
                        'files': [os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor_d))],
                        'required_missing': [],
                    },
                    {
                        'code': 'F',
                        'name': 'F',
                        'status': 'complete',
                        'resolved_run_id': anchor,
                        'files': [os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor))],
                        'required_missing': [],
                    },
                ],
            }
            rec = cr.compute_operator_support_send_recommendation_core(
                repo,
                snapshot,
                ok_snap=True,
                snap_msg='',
                pipeline_running=False,
                recommendation_source_scope='anchored_completed_run',
                recommendation_anchor_run_id=anchor,
            )

        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertFalse(rec.get('dat_smoke_available'))
        self.assertTrue(rec.get('phase_d_followup_available'))
        preview = rec.get('action_preview') or {}
        self.assertEqual(preview.get('followup_phase_d_run_id'), follow_d)
        self.assertEqual(preview.get('followup_phase_d_movement_classification'), 'followup_only_not_anchor_closure')
        self.assertEqual(preview.get('followup_phase_d_specific_movement_classification'), 'selected_passed_no_canonical')
        self.assertEqual(preview.get('dat_selected_count'), 4)
        self.assertEqual(preview.get('dat_qa_pass_count'), 4)
        self.assertEqual(preview.get('dat_canonical_record_count'), 0)
        self.assertFalse(preview.get('accepted_as_reviewed_anchor_milestone'))

    def test_compute_operator_support_send_recommendation_does_not_recommend_dat_smoke_for_truthful_dat_lane_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_verification_rerun')
        self.assertEqual(rec.get('best_now_action_kind'), 'phase_d_dat_verification_rerun')
        self.assertEqual(rec.get('preferred_when_stable'), 'system_health')
        self.assertEqual(rec.get('best_now_send'), 'system_health')
        self.assertIn('rerun focused phase d dat verification', rec.get('summary_line', '').lower())
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(preview.get('dat_selected_count'), 6)
        self.assertEqual(preview.get('dat_qa_reject_count'), 6)
        self.assertEqual(preview.get('dat_canonical_record_count'), 0)
        self.assertEqual(preview.get('dat_payer_resolution_evidence_status'), 'stale_pre_resolution_diagnostics')

    def test_review_dat_qa_full_block_preview_contains_layer1_when_present_in_phase_d_summary(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            phase_d = {
                'run_id': '20260329-171213-1ccb1c51',
                'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6},
                'layer1_join_debug_generated': True,
                'layer1_top_blocker': 'dat_parse_rejects',
                'layer1_join_debug_pack_path': os.path.join(reports, 'layer1_pack.txt'),
                'layer1_join_debug_summary_path': os.path.join(reports, 'layer1_sum.json'),
                'layer1_join_debug_samples_path': os.path.join(reports, 'layer1_smp.jsonl'),
            }
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                phase_d,
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
        self.assertTrue(preview.get('layer1_join_debug_generated'))
        self.assertEqual(preview.get('layer1_top_blocker'), 'dat_parse_rejects')
        lines = rec.get('action_reason_lines') if isinstance(rec.get('action_reason_lines'), list) else []
        merged = '\n'.join([str(x) for x in lines])
        self.assertIn('Layer 1 join debug', merged)
        self.assertEqual(rec.get('recommended_report_kind'), 'artifact_triage_pack')

    def test_review_dat_qa_full_block_suppressed_when_live_phase_c_failed(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({
                    'last_phase_c_ok': False,
                    'last_phase_c_error_code': 'PHASE_C_DB_WRITE_ERROR',
                }, handle)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        skip = str(rec.get('dat_qa_full_block_not_triggered_reason', '') or '')
        self.assertIn('Phase C', skip)

    def test_review_dat_qa_full_block_suppressed_when_live_phase_c_failed_without_error_code(self):
        """Stale diagnostics may omit last_phase_c_error_code — still suppress QA full-block."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({'last_phase_c_ok': False}, handle)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        skip = str(rec.get('dat_qa_full_block_not_triggered_reason', '') or '')
        self.assertIn('Phase C', skip)
        self.assertIn('error_code', skip.lower())

    def test_compute_operator_support_send_recommendation_replays_live_z_zm_full_block_pattern(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260421-003615-6722364b'
            smoke_anchor = '20260331-022246-3b508c10'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 408,
                    'phase_b_dat_selection_mode': 'configured',
                    'phase_b_dat_selected_root_source_id': 'dat_cfg_0',
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 0,
                    'phase_d_dat_selected_count': 5,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 5,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 0},
                {'run_id': '20260421-003627-6364b919', 'dat_telemetry': {
                    'dat_selected_count': 5,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 5,
                    'dat_canonical_record_count': 0,
                }},
            )
            with open(os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(run_id)), 'w', encoding='utf-8') as f:
                f.write('{"reject_code":"QA_DAT_PAYER_ANCHOR_MISSING"}\n')
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(smoke_anchor))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_verification_rerun')
        self.assertEqual(rec.get('recommended_report_kind'), 'artifact_triage_pack')
        self.assertIn('rerun focused phase d dat verification', rec.get('summary_line', '').lower())
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(preview.get('anchor_run_id'), run_id)
        self.assertEqual(preview.get('dat_selected_count'), 5)
        self.assertEqual(preview.get('dat_qa_reject_count'), 5)
        self.assertEqual(preview.get('dat_canonical_record_count'), 0)
        self.assertTrue(str(preview.get('qa_reject_samples_path', '')).endswith('qa_reject_samples_{0}.jsonl'.format(run_id)))
        self.assertTrue(preview.get('ignored_smoke_mismatch'))
        self.assertFalse(preview.get('smoke_source_accepted'))
        self.assertEqual(preview.get('anchored_diagnosis_source'), 'anchored_phase_d_shadow')
        reason_blob = ' '.join(rec.get('action_reason_lines', []))
        self.assertIn('selected=5, qa_pass=0, qa_reject=5, canonical=0', reason_blob)
        self.assertIn('Smoke on disk is not used for displayed counters', reason_blob)
        self.assertIn('payer-resolution diagnostics', reason_blob)

    def test_compute_operator_support_send_recommendation_uses_completed_smoke_for_truthful_dat_lane_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260329-171213-1ccb1c51'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 390,
                    'phase_c_inserted_count': 390,
                    'phase_c_skipped_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 390, 'rows_skipped_duplicate': 0},
                {'run_id': run_id, 'dat_telemetry': {'dat_selected_count': 0, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 0}},
            )
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(run_id))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(run_id))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'anchor_run_id': run_id,
                    'assessment': 'dat_selected_qa_blocked',
                    'strict_milestone_verdict': 'Partially advanced',
                    'dat_funnel': {
                        'dat_selected_count': 390,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 390,
                        'dat_canonical_record_count': 0,
                        'post_medisoft_blocked_stage': 'qa',
                    },
                }, f)
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': run_id,
                    'last_requested_context_run_id': run_id,
                    'last_remediation_issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_verification_rerun')
        self.assertEqual(rec.get('preferred_when_stable'), 'system_health')
        self.assertEqual(rec.get('best_now_send'), 'system_health')
        self.assertEqual(rec.get('dat_smoke_last_assessment'), 'dat_selected_qa_blocked')
        self.assertEqual(rec.get('action_preview', {}).get('smoke_assessment'), 'dat_selected_qa_blocked')
        self.assertEqual(rec.get('action_preview', {}).get('dat_selected_count'), 390)
        self.assertIn('rerun focused Phase D DAT verification', rec.get('why_summary', '') + ' ' + ' '.join(rec.get('action_reason_lines', [])))
        self.assertIn('Partially advanced', rec.get('why_summary', '') + ' ' + ' '.join(rec.get('action_reason_lines', [])))
        prev = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertTrue(prev.get('smoke_source_accepted'))
        self.assertEqual(prev.get('anchored_diagnosis_source'), 'smoke_corroborated')

    def test_compute_operator_support_send_recommendation_qa_full_block_ignores_mismatched_smoke_counters(self):
        """Smoke dat_funnel must not override anchored counts when smoke anchor != anchored run."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260329-171213-1ccb1c51'
            other_anchor = '20260331-022246-3b508c10'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': run_id, 'dat_telemetry': {
                    'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6,
                }},
            )
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(other_anchor))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(other_anchor))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'anchor_run_id': other_anchor,
                    'assessment': 'dat_selected_qa_blocked',
                    'dat_funnel': {
                        'dat_selected_count': 999,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 999,
                        'dat_canonical_record_count': 0,
                    },
                }, f)
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_verification_rerun')
        prev = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(prev.get('dat_selected_count'), 6)
        self.assertEqual(prev.get('dat_qa_reject_count'), 6)
        self.assertNotEqual(prev.get('dat_selected_count'), 999)
        self.assertTrue(prev.get('ignored_smoke_mismatch'))
        self.assertFalse(prev.get('smoke_source_accepted'))
        self.assertFalse(rec.get('dat_smoke_accepted_for_anchor'))
        self.assertTrue(rec.get('dat_smoke_ignored_mismatch'))
        self.assertEqual(rec.get('dat_smoke_last_report_path'), '')
        self.assertEqual(rec.get('dat_smoke_ignored_report_path'), smoke_txt)
        self.assertEqual(prev.get('anchored_diagnosis_source'), 'anchored_phase_d_shadow')
        reason_blob = ' '.join(rec.get('action_reason_lines', []))
        self.assertIn('Smoke on disk is not used for displayed counters', reason_blob)
        self.assertNotIn('matching smoke report', reason_blob)
        self.assertIn('payer-resolution diagnostics', reason_blob)

    def test_compute_operator_support_send_recommendation_suppresses_dat_smoke_when_same_target_in_cooldown(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': '20260329-171213-1ccb1c51',
                    'last_requested_context_run_id': '20260329-171213-1ccb1c51',
                    'last_remediation_issue_code': '',
                    'last_status': 'completed',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 4,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 4, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertIn('cooldown', str(rec.get('dat_smoke_not_triggered_reason', '')).lower())

    def test_compute_operator_support_send_recommendation_auto_embeds_qa_drop_issue_without_manual_reply(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'cloud_health_alert_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:Phase D skipped 13 patient upsert(s).',
                    'last_sent_epoch': 1774577782,
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertFalse(rec.get('reply_required_for_unblock'))
        self.assertEqual(rec.get('reply_required_issue_code'), 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT')
        lou = rec.get('live_operator_unblock', {}) if isinstance(rec.get('live_operator_unblock', {}), dict) else {}
        self.assertFalse(lou.get('reply_required'))
        self.assertTrue(lou.get('deprecation_active'))
        self.assertEqual(lou.get('closure_mode'), 'embedded_auto_closure')
        self.assertIn('embed_issue_code_in_recommendation', lou.get('closure_tasks', []))
        self.assertIn('Operator-reply deprecation active', '\n'.join(rec.get('action_reason_lines', [])))
        step2 = rec.get('step2_run_coherence', {}) if isinstance(rec.get('step2_run_coherence', {}), dict) else {}
        self.assertIn('alignment_note', step2)
        self.assertIn(step2.get('alignment_note'), ('step2_ready', 'missing_required_artifacts_for_step2', 'snapshot_coherence_blocked', 'phase_d_summary_run_id_mismatch'))
        self.assertIn('alignment_ok', step2)

    def test_compute_operator_support_send_recommendation_does_not_override_non_qa_alert_with_telemetry_fallback(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'cloud_health_alert_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_issue_key': 'PHASE_F_LOCK_FAIL:Phase F lock acquisition failed.',
                    'last_sent_epoch': 1774577782,
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260329-171213-1ccb1c51',
                    'last_discovery_dat_telemetry': {'dat_manifest_rows_count': 3},
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 0,
                        'post_medisoft_exercised': False,
                        'post_medisoft_blocked_stage': 'phase_d',
                    },
                }, f)
            with open(os.path.join(reports, 'shadow_run_report_20260329-171213-1ccb1c51.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'phase_d',
                    'phase_b_dat_manifest_rows_count': 3,
                    'phase_d_dat_selected_count': 0,
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertFalse(rec.get('reply_required_for_unblock'))
        self.assertEqual(rec.get('reply_required_issue_code'), '')



class TestPhaseDHistoricalReprocessWrappers(unittest.TestCase):
    def test_run_phase_d_manual_sets_artifact_class_filter_env(self):
        from MediCafe import cloud_readiness as cr
        with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', '/repo', '/repo/run_qa_canonical.py', [])):
            with patch.object(cr, 'resolve_lab_root', return_value='/repo/lab'):
                with patch.object(cr.subprocess, 'Popen') as mock_popen:
                    ok, msg, _ = cr.run_phase_d_manual('/repo', '/py', {}, artifact_classes=['dat', 'csv'])
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        proc_env = mock_popen.call_args[1].get('env', {})
        self.assertEqual(proc_env.get('MEDICAFE_LAB_DIR'), '/repo/lab')
        self.assertEqual(proc_env.get('MEDICAFE_PHASE_D_ARTIFACT_CLASSES'), 'dat,csv')

    def test_run_historical_phase_d_reprocess_resets_then_launches_filtered_phase_d(self):
        from MediCafe import cloud_readiness as cr
        payload = {
            'ok': True,
            'targeted_artifact_classes': ['dat'],
            'execution_report_path': '/repo/lab/reports/phase_d_historical_reprocess_execution_latest.txt',
        }
        with patch.object(cr, '_execute_historical_phase_d_reprocess_impl', return_value=payload):
            with patch.object(cr, 'resolve_lab_root', return_value='/repo/lab'):
                with patch.object(cr, 'run_phase_d_manual', return_value=(True, '', {
                        'attempt_id': 'attempt-1',
                        'attempt_path': '/repo/lab/reports/diagnostic_attempt_phase_d_manual_attempt-1.json',
                        'pid': 123,
                })) as mock_run:
                    ok, msg, data = cr.run_historical_phase_d_reprocess('/repo', '/py', {}, artifact_classes=['dat'])
        self.assertTrue(ok)
        self.assertIn('Historical Phase D re-evaluation reset completed and Phase D rerun started', msg)
        self.assertEqual(data.get('execution_report_path'), payload['execution_report_path'])
        self.assertEqual(data.get('phase_d_attempt_id'), 'attempt-1')
        self.assertEqual(data.get('phase_d_child_pid'), 123)
        mock_run.assert_called_once_with('/repo', '/py', {}, artifact_classes=['dat'])

    def test_run_historical_phase_d_reprocess_loads_helper_from_resolved_script(self):
        from MediCafe import cloud_readiness as cr
        temp_root = tempfile.mkdtemp()
        script_path = os.path.join(temp_root, 'phase_d_historical_reprocess.py')
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(
                'def normalize_artifact_classes(raw):\n'
                '    return list(raw or [])\n'
                'def collect_phase_d_reject_snapshot(lab_root, artifact_classes=None, qa_version=None):\n'
                '    return {"ok": True}\n'
                'def preview_historical_phase_d_reprocess(lab_root, artifact_classes=None, remediation_context_run_id=None):\n'
                '    return {"ok": True, "report_path": "preview.txt"}\n'
                'def execute_historical_phase_d_reprocess(lab_root, artifact_classes=None, remediation_context_run_id=None):\n'
                '    return {"ok": True, "targeted_artifact_classes": ["dat"], "execution_report_path": "execution.txt"}\n'
            )
        with patch.object(cr, '_preview_historical_phase_d_reprocess_impl', None):
            with patch.object(cr, '_execute_historical_phase_d_reprocess_impl', None):
                with patch.object(cr, '_normalize_phase_d_reprocess_classes_impl', None):
                    with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', None):
                        with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', temp_root, script_path, [])):
                            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(temp_root, 'lab')):
                                with patch.object(cr, 'run_phase_d_manual', return_value=(True, '', None)) as mock_run:
                                    ok, msg, data = cr.run_historical_phase_d_reprocess('/repo', '/py', {}, artifact_classes=['dat'])
        self.assertTrue(ok)
        self.assertIn('Historical Phase D re-evaluation reset completed and Phase D rerun started', msg)
        self.assertEqual(data.get('execution_report_path'), 'execution.txt')
        mock_run.assert_called_once_with('/repo', '/py', {}, artifact_classes=['dat'])



class TestEmbeddedRecommendationReporting(unittest.TestCase):
    def test_format_recommended_action_lines_includes_reply_required_fields(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'reply_required_for_unblock': True,
            'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
            'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example',
        })
        body = '\n'.join(lines)
        self.assertIn('reply_required_for_unblock=True', body)
        self.assertIn('reply_required_issue_code=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example', body)

    def test_format_recommended_action_lines_milestone_and_operator_lanes(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'milestone_verdict': 'Not advanced',
            'milestone_reason': 'dat_lane_not_exercised',
            'anchored_milestone_run_id': 'anchor-rid',
            'live_operator_unblock': {
                'reply_required': True,
                'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
                'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example',
            },
        })
        body = '\n'.join(lines)
        self.assertIn('Milestone verdict (anchored shadow payload):', body)
        self.assertIn('milestone_verdict=Not advanced', body)
        self.assertIn('Operator unblock (live alert / diagnostics):', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example', body)

    def test_format_recommended_action_lines_includes_followthrough_predictions(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'pipeline_running': True,
            'live_operator_unblock': {'reply_required': False},
        })
        body = '\n'.join(lines)
        self.assertIn('operator_primary_report_surface=artifact_triage_pack', body)
        self.assertIn('follow_recommendation_now=defer_until_idle', body)
        self.assertIn('follow_recommendation_when_stable=send_anchored_run_evidence_bundle', body)

    def test_send_bundle_artifact_triage_surface_follows_run_evidence(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'operator_primary_report_surface': 'artifact_triage_pack',
        })
        body = '\n'.join(lines)
        self.assertIn('operator_primary_report_surface=artifact_triage_pack', body)
        self.assertIn('follow_recommendation_now=send_run_evidence_bundle', body)
        self.assertIn('follow_recommendation_when_stable=send_run_evidence_bundle', body)
        self.assertEqual(
            tools.recommendation_followthrough_now({
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
            }),
            'send_run_evidence_bundle',
        )

    def test_format_recommended_action_lines_auto_ack_syncs_live_unblock_reply_required(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'reply_required_for_unblock': False,
            'reply_required_issue_code': '',
            'reply_required_issue_key': '',
            'live_operator_unblock': {
                'reply_required': True,
                'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
                'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:auto-ack',
            },
        })
        body = '\n'.join(lines)
        self.assertIn('Operator unblock (live alert / diagnostics):', body)
        self.assertIn(' - reply_required=False', body)
        self.assertNotIn('reply_required_for_unblock=True', body)
        self.assertIn('reply_required_issue_code=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:auto-ack', body)

    def test_format_recommended_action_lines_includes_qa_full_block_provenance(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommendation_anchor_run_id': '20260329-171213-1ccb1c51',
            'action_preview': {
                'anchor_run_id': '20260329-171213-1ccb1c51',
                'anchored_diagnosis_source': 'anchored_phase_d_shadow',
                'smoke_source_accepted': False,
                'ignored_smoke_mismatch': True,
                'smoke_anchor_run_id': 'other-anchor',
                'source_mismatch_note': 'Smoke on disk is not used for displayed counters.',
            },
            'live_operator_unblock': {'reply_required': False},
        })
        body = '\n'.join(lines)
        self.assertIn('operator_followthrough=send_anchored_run_evidence_bundle', body)
        self.assertIn('operator_manual_review_required=False', body)
        self.assertIn('QA full-block review provenance:', body)
        self.assertIn('anchored_diagnosis_source=anchored_phase_d_shadow', body)
        self.assertIn('smoke_source_accepted=False', body)
        self.assertIn('ignored_smoke_mismatch=True', body)
        self.assertIn('smoke_anchor_run_id=other-anchor', body)
        self.assertIn('source_mismatch_note=', body)

    def test_format_recommended_action_lines_qa_full_block_overrides_stale_manual_review_flag(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'review_dat_qa_full_block',
            'operator_manual_review_required': True,
            'recommended_report_kind': 'artifact_triage_pack',
            'action_preview': {'anchor_run_id': 'rid'},
            'live_operator_unblock': {'reply_required': False},
        })
        body = '\n'.join(lines)
        manual_lines = [ln for ln in lines if 'operator_manual_review_required' in ln]
        self.assertEqual(len(manual_lines), 1)
        self.assertIn('operator_manual_review_required=False', body)

    def test_open_latest_artifact_triage_pack_embeds_recommended_action_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'pipeline_run_id': '20260329-171213-1ccb1c51',
                'phase_rows': [
                    {'code': code, 'name': code, 'status': 'complete', 'resolved_run_id': '20260329-171213-1ccb1c51', 'files': [], 'required_missing': []}
                    for code in ('B', 'C', 'D', 'E', 'F')
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {},
                'nearest_complete_run_id': '',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {},
                'resolution_decision': 'single_token',
                'resolution_confidence': 'high',
                'resolution_reason': '',
                'resolution_notes': [],
            }
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'best_now_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': False,
                'action_preview': {'latest_phase_c_inserted_count': 0, 'latest_phase_c_skipped_count': 10, 'latest_phase_d_rows_selected': 0, 'latest_phase_d_pass_count': 0, 'latest_phase_d_reject_count': 0, 'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                    ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('recommended_action_kind=historical_phase_d_reprocess', body)
            self.assertIn('historical_reject_counts_by_class=dat:10', body)

    def test_open_latest_system_health_pack_embeds_recommended_action_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'best_now_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': False,
                'action_preview': {'latest_phase_c_inserted_count': 0, 'latest_phase_c_skipped_count': 10, 'latest_phase_d_rows_selected': 0, 'latest_phase_d_pass_count': 0, 'latest_phase_d_reject_count': 0, 'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': '20260329-171213-1ccb1c51',
                    'pack_scope': 'completed_run',
                    'active_run_id': '',
                    'expected_shadow_run_id': '20260329-171213-1ccb1c51',
                    'anchor_state': {},
                    'anchor_report_path': '',
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={'notes': [], 'audit_stale': False, 'expected_shadow_run_id': '20260329-171213-1ccb1c51'}):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored completed-run snapshot:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent shadow runs:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': False, 'error': 'no db'}):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                            with patch.object(cr, '_build_system_health_pack_runbook', return_value=['What To Do Now:', ' 1) test']):
                                                with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                    ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('recommended_action_kind=historical_phase_d_reprocess', body)
            self.assertIn('historical_reject_counts_by_class=dat:10', body)

    def test_open_latest_system_health_pack_orders_layer1_before_unified_db(self):
        """Definition-of-done: Layer 1 Readiness appears before Unified DB Readiness in the pack."""
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            with open(os.path.join(reports, 'artifact_discovery_summary_b1.json'), 'w', encoding='utf-8') as fh:
                json.dump({'run_id': 'b1', 'counts_by_class': {'dat': 2}, 'dat_telemetry': {'dat_manifest_rows_count': 2}}, fh)
            with open(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor)), 'w', encoding='utf-8') as fh:
                json.dump({'run_id': anchor, 'rows_selected': 1}, fh)
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'preferred_when_stable_action_kind': 'send_bundle',
                'best_now_action_kind': 'send_bundle',
                'recommended_report_kind': 'system_health_pack',
            }
            diag_state = {
                'last_discovery_ok': True,
                'last_phase_b_run_id': 'b1',
                'last_manifest_sha256': 'm',
                'last_ingest_manifest_sha256': 'm',
                'last_phase_c_ok': True,
                'last_shadow_pipeline_run_id': anchor,
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': anchor,
                    'pack_scope': 'completed_run',
                    'active_run_id': '',
                    'expected_shadow_run_id': anchor,
                    'anchor_state': diag_state,
                    'anchor_report_path': '',
                    'state': diag_state,
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={
                            'notes': [],
                            'audit_stale': False,
                            'expected_shadow_run_id': anchor,
                        }):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': False, 'error': 'no db'}):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=['db enrich:']):
                                            with patch.object(cr, '_build_unified_db_readiness_lines', return_value=[
                                                'Unified DB Readiness:',
                                                ' - overall=unavailable',
                                            ]):
                                                with patch.object(cr, '_build_system_health_pack_runbook', return_value=['runbook:']):
                                                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                        ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('Layer 1 Readiness:', body)
            self.assertIn('Unified DB Readiness:', body)
            self.assertLess(body.index('Layer 1 Readiness:'), body.index('Unified DB Readiness:'))

    def test_open_latest_system_health_pack_withholds_layer1_when_evidence_incoherent(self):
        """When evidence_mode is incoherent_state, do not surface full Layer 1 evaluation (stale vs lineage)."""
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            with open(os.path.join(reports, 'artifact_discovery_summary_b1.json'), 'w', encoding='utf-8') as fh:
                json.dump({'run_id': 'b1', 'counts_by_class': {'dat': 2}, 'dat_telemetry': {'dat_manifest_rows_count': 2}}, fh)
            with open(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor)), 'w', encoding='utf-8') as fh:
                json.dump({'run_id': anchor, 'rows_selected': 1, 'layer1_join_debug_generated': True}, fh)
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'preferred_when_stable_action_kind': 'send_bundle',
                'best_now_action_kind': 'send_bundle',
                'recommended_report_kind': 'system_health_pack',
            }
            diag_state = {
                'last_discovery_ok': True,
                'last_phase_b_run_id': 'b1',
                'last_manifest_sha256': 'sha-b',
                'last_ingest_manifest_sha256': 'sha-c',
                'last_phase_c_ok': False,
                'last_shadow_pipeline_run_id': anchor,
            }
            ev_mode = {
                'mode': 'incoherent_state',
                'blocking_reason': 'phase_c_manifest_sha_mismatch',
                'selected_run_id': anchor,
                'last_completed_run_id': anchor,
                'active_run_id': '',
                'decisive_run_evidence_current': False,
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': anchor,
                    'pack_scope': 'completed_run',
                    'active_run_id': '',
                    'expected_shadow_run_id': anchor,
                    'anchor_state': diag_state,
                    'anchor_report_path': '',
                    'state': diag_state,
                    'evidence_mode': ev_mode,
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={
                            'notes': [],
                            'audit_stale': False,
                            'expected_shadow_run_id': anchor,
                        }):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': False, 'error': 'no db'}):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=['db enrich:']):
                                            with patch.object(cr, '_build_unified_db_readiness_lines', return_value=[
                                                'Unified DB Readiness:',
                                                ' - overall=unavailable',
                                            ]):
                                                with patch.object(cr, '_build_system_health_pack_runbook', return_value=['runbook:']):
                                                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                        ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('current_evidence_mode=incoherent_state', body)
            self.assertIn('Layer_1_evaluated=False', body)
            self.assertIn('phase_c_manifest_sha_mismatch', body)
            self.assertIn('Decisive-run lab lineage is incoherent', body)

    def test_open_latest_system_health_pack_live_status_does_not_promote_stale_layer1_or_audit_debug(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            active = '20260501-010101-live'
            completed = '20260430-235959-done'
            audit_json = os.path.join(reports, 'migration_audit_summary.json')
            with open(audit_json, 'w', encoding='utf-8') as fh:
                json.dump({'hints': ['stale audit hint']}, fh)
            stale_l1 = os.path.join(reports, 'layer1_join_debug_summary_old.json')
            with open(stale_l1, 'w', encoding='utf-8') as fh:
                json.dump({'run_id': completed, 'layer1_join_evaluated': True}, fh)
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'preferred_when_stable_action_kind': 'send_bundle',
                'best_now_action_kind': 'send_bundle',
                'recommended_report_kind': 'system_health_pack',
                'current_evidence_mode': 'live_status',
                'current_decision': 'send_live_status_wait_for_completed_run',
            }
            diag_state = {
                'pipeline_state': 'running',
                'active_run_id': active,
                'last_shadow_pipeline_run_id': completed,
            }
            ev_mode = {
                'mode': 'live_status',
                'active_run_id': active,
                'last_completed_run_id': completed,
                'decisive_run_evidence_current': False,
                'current_decision': 'send_live_status_wait_for_completed_run',
                'blocking_reason': 'active_run_differs_from_last_completed',
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': audit_json,
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': completed,
                    'pack_scope': 'mixed_scope',
                    'active_run_id': active,
                    'expected_shadow_run_id': completed,
                    'anchor_state': diag_state,
                    'anchor_report_path': '',
                    'state': diag_state,
                    'evidence_mode': ev_mode,
                }):
                    with patch.object(cr, 'get_health_lines', return_value=[
                        ' - active_run_id={0}'.format(active),
                        ' - last_shadow_pipeline_run_id={0}'.format(completed),
                    ]):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={
                            'notes': ['audit stale vs active run'],
                            'audit_stale': True,
                            'expected_shadow_run_id': completed,
                        }):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': False, 'error': 'no db'}):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                            with patch.object(cr, '_build_unified_db_readiness_lines', return_value=[
                                                'Unified DB Readiness:',
                                                ' - overall=unavailable',
                                            ]):
                                                with patch.object(cr, '_build_system_health_pack_runbook', return_value=['runbook:']):
                                                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                        ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('current_evidence_mode=live_status', body)
            self.assertIn('decisive_run_evidence_current=False', body)
            self.assertIn('current_decision=send_live_status_wait_for_completed_run', body)
            self.assertIn('pack_live_active_run_id={0}'.format(active), body)
            self.assertIn('pack_last_completed_run_id={0}'.format(completed), body)
            self.assertIn('Latest completed phase summaries (from live diagnostics state):', body)
            self.assertIn('audit hints suppressed because audit summary is older than current completed-run evidence.', body)
            self.assertIn('Layer 1 Readiness:', body)
            self.assertIn(' - status=not_reached', body)
            self.assertIn(' - Layer_1_evaluated=False', body)
            self.assertIn(' - historical_layer1_debug_only=True', body)
            self.assertIn(' - current_layer1_debug_effective=False', body)
            self.assertIn('Current run evidence is still live/status-only', body)
            self.assertNotIn('Layer 1 evaluation completed for this run.', body)
            self.assertIn('recommended_report_kind=system_health_pack', body)

    def test_open_latest_system_health_pack_phase_c_manifest_not_ingested_false_clean_wording(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            with open(os.path.join(reports, 'artifact_discovery_summary_b1.json'), 'w', encoding='utf-8') as fh:
                json.dump({'run_id': 'b1', 'counts_by_class': {'dat': 2}, 'dat_telemetry': {'dat_manifest_rows_count': 2}}, fh)
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'preferred_when_stable_action_kind': 'send_bundle',
                'best_now_action_kind': 'send_bundle',
                'recommended_report_kind': 'system_health_pack',
            }
            diag_state = {
                'last_discovery_ok': True,
                'last_phase_b_run_id': 'b1',
                'last_manifest_sha256': 'sha-current',
                'last_ingest_manifest_sha256': 'sha-old',
                'last_phase_c_ok': True,
                'last_shadow_pipeline_run_id': anchor,
                'last_phase_c_execution_handoff_status': 'failed',
                'last_phase_c_execution_handoff_blocker_class': 'phase_c_script_entered_but_no_finish_diag',
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': anchor,
                    'pack_scope': 'completed_run',
                    'active_run_id': '',
                    'expected_shadow_run_id': anchor,
                    'anchor_state': diag_state,
                    'anchor_report_path': '',
                    'state': diag_state,
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={
                            'notes': [],
                            'audit_stale': False,
                            'expected_shadow_run_id': anchor,
                        }):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': False, 'error': 'no db'}):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=['db enrich:']):
                                            with patch.object(cr, '_build_unified_db_readiness_lines', return_value=[
                                                'Unified DB Readiness:',
                                                ' - overall=unavailable',
                                            ]):
                                                with patch.object(cr, '_build_system_health_pack_runbook', return_value=['runbook:']):
                                                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                        ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn(' - status=not_reached', body)
            self.assertIn(' - current_blocker=phase_c_manifest_not_ingested', body)
            self.assertIn('Phase C subprocess launched (rc=0) but publish artifacts are missing', body)
            self.assertIn('developer/support context, not a manual XP diagnostics requirement', body)

    def test_open_latest_system_health_pack_data_plane_counts_json_null_does_not_crash(self):
        """Regression: JSON null for snapshot counts must not break .get chaining (AttributeError)."""
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            with open(os.path.join(reports, 'artifact_discovery_summary_b1.json'), 'w', encoding='utf-8') as fh:
                json.dump({'run_id': 'b1', 'counts_by_class': {'dat': 2}, 'dat_telemetry': {'dat_manifest_rows_count': 2}}, fh)
            with open(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor)), 'w', encoding='utf-8') as fh:
                json.dump({'run_id': anchor, 'rows_selected': 1}, fh)
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'preferred_when_stable_action_kind': 'send_bundle',
                'best_now_action_kind': 'send_bundle',
                'recommended_report_kind': 'system_health_pack',
            }
            diag_state = {
                'last_discovery_ok': True,
                'last_phase_b_run_id': 'b1',
                'last_manifest_sha256': 'm',
                'last_ingest_manifest_sha256': 'm',
                'last_phase_c_ok': True,
                'last_shadow_pipeline_run_id': anchor,
            }
            bad_snap = {
                'ok': True,
                'counts': None,
                'status': 'PASS',
                'db_path': '',
                'patient_count_effective': 1,
                'patient_latest_identity_count': 1,
                'qa_reject_count_effective': 0,
                'qa_reject_count': 0,
                'projection_success_count_effective': 0,
                'projection_success_count': 0,
                'projection_reject_count_effective': 0,
                'projection_reject_count': 0,
                'qa_scope_version': '',
                'projection_scope_version': '',
                'replay_pending_count': 0,
                'orphan_claim_lines': 0,
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': anchor,
                    'pack_scope': 'completed_run',
                    'active_run_id': '',
                    'expected_shadow_run_id': anchor,
                    'anchor_state': diag_state,
                    'anchor_report_path': '',
                    'state': diag_state,
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={
                            'notes': [],
                            'audit_stale': False,
                            'expected_shadow_run_id': anchor,
                        }):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value=bad_snap):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                            with patch.object(cr, '_build_unified_db_readiness_lines', return_value=[]):
                                                with patch.object(cr, '_build_system_health_pack_runbook', return_value=['runbook:']):
                                                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                        ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok, msg)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('Data plane snapshot (cumulative lab state):', body)
            self.assertIn(' - patient_count=1', body)

    def test_open_latest_system_health_pack_context_mode_skips_guided_patient_preview(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260415-232243-0b19e55a'
            artifacts = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }
            pack_context = {
                'anchor_run_id': run_id,
                'pack_scope': 'completed_run',
                'active_run_id': '',
                'expected_shadow_run_id': run_id,
                'anchor_state': {},
                'anchor_report_path': '',
            }
            snapshot = {
                'ok': True,
                'status': 'ok',
                'db_path': os.path.join(lab, 'unified_model_xp.db'),
                'counts': {'patient': 9},
                'patient_count_effective': 4,
                'qa_reject_count_effective': 1,
                'projection_success_count_effective': 2,
                'projection_reject_count_effective': 0,
                'qa_scope_version': '',
                'projection_scope_version': 'scope-v1',
                'replay_pending_count': 0,
                'orphan_claim_lines': 0,
            }
            progress = []
            with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={'notes': [], 'audit_stale': False, 'expected_shadow_run_id': run_id}):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored completed-run snapshot:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent shadow runs:']):
                                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                                        with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(False, 'no eval', {}, {'live_run_id': '', 'live_run_status': ''})):
                                            with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value={}):
                                                with patch.object(cr, '_collect_data_plane_snapshot', return_value=snapshot):
                                                    with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                                        with patch.object(cr, '_collect_patient_chain_rows', side_effect=AssertionError('should not collect guided patient rows')) as mock_rows:
                                                            with patch.object(cr, '_build_system_health_pack_runbook', return_value=['What To Do Now:', ' 1) test']):
                                                                ok, msg, path = cr.open_latest_system_health_pack(
                                                                    repo,
                                                                    lambda _n, default: default,
                                                                    progress_callback=progress.append,
                                                                    include_guided_patient_preview=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertFalse(mock_rows.called)
            self.assertIn('building DB enrichment overview', progress)
            self.assertIn('building system health runbook', progress)
            self.assertNotIn('sampling guided patient preview', progress)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('guided_patient_options=skipped_context_pack', body)
            self.assertIn('projection_success_count=2', body)

    def test_open_latest_system_health_pack_skips_guided_preview_when_relational_depth_zero(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260430-020617-7952eda8'
            artifacts = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }
            pack_context = {
                'anchor_run_id': run_id,
                'pack_scope': 'completed_run',
                'active_run_id': '',
                'expected_shadow_run_id': run_id,
                'anchor_state': {},
                'anchor_report_path': '',
            }
            snapshot = {
                'ok': True,
                'status': 'WARN',
                'db_path': os.path.join(lab, 'unified_model_xp.db'),
                'counts': {
                    'patient': 5825,
                    'coverage': 0,
                    'encounter': 0,
                    'claim': 0,
                    'claim_line': 0,
                },
                'patient_count_effective': 2803,
                'qa_reject_count_effective': 842,
                'projection_success_count_effective': 19715,
                'projection_reject_count_effective': 0,
                'qa_scope_version': 'qa_v2',
                'projection_scope_version': 'proj_v2',
                'replay_pending_count': 842,
                'orphan_claim_lines': 0,
            }
            progress = []
            with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={'notes': [], 'audit_stale': False, 'expected_shadow_run_id': run_id}):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored completed-run snapshot:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent shadow runs:']):
                                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                                        with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(False, 'no eval', {}, {'live_run_id': '', 'live_run_status': ''})):
                                            with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value={}):
                                                with patch.object(cr, '_collect_data_plane_snapshot', return_value=snapshot):
                                                    with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                                        with patch.object(cr, '_collect_patient_chain_rows', side_effect=AssertionError('should not collect guided patient rows')) as mock_rows:
                                                            with patch.object(cr, '_build_system_health_pack_runbook', return_value=['What To Do Now:', ' 1) test']):
                                                                ok, msg, path = cr.open_latest_system_health_pack(
                                                                    repo,
                                                                    lambda _n, default: default,
                                                                    progress_callback=progress.append)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertFalse(mock_rows.called)
            self.assertNotIn('sampling guided patient preview', progress)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('guided_patient_options=skipped_relational_depth_zero', body)
            self.assertIn('patient_count=2803', body)

    def test_send_latest_run_evidence_bundle_attaches_context_note_and_reprocess_reports(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            rid = '20260329-171213-1ccb1c51'
            hdr = (
                'Historical Phase D Re-Evaluation Preview\n'
                'generated_at_utc=test\n'
                'remediation_context_run_id={0}\n'.format(rid))
            with open(preview_path, 'w', encoding='utf-8') as f:
                f.write(hdr)
            with open(execution_path, 'w', encoding='utf-8') as f:
                f.write(hdr.replace('Preview', 'Execution'))
            for path in (triage_path, index_path, delivery_path, context_note):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': False,
                'action_preview': {'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=(context_note, {'pack_scope': 'mixed_scope', 'anchor_run_id': 'other'})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn(os.path.basename(context_note), basenames)
            self.assertIn(os.path.basename(preview_path), basenames)
            self.assertIn(os.path.basename(execution_path), basenames)
            self.assertEqual(data.get('context_attachment_path'), context_note)

    def test_send_latest_run_evidence_bundle_reconciles_live_phase_d_followup_overtake(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-anchor'
            anchored_d = '20260329-171214-d-anchor'
            live_d = '20260329-171315-d-live'
            triage_path = os.path.join(reports, 'artifact_triage_pack_{0}.txt'.format(anchor))
            index_path = os.path.join(reports, 'run_artifact_index_{0}.txt'.format(anchor))
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_{0}.txt'.format(anchor))
            for path in (triage_path, index_path, delivery_path, context_note):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x\n')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'last_phase_d_run_id': live_d}, f)
            anchor_qa_path = os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchored_d))
            with open(anchor_qa_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': anchored_d,
                    'dat_telemetry': {
                        'dat_selected_count': 0,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 0,
                        'dat_canonical_record_count': 0,
                    },
                }, f)
            qa_path = os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(live_d))
            with open(qa_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': live_d,
                    'dat_telemetry': {
                        'dat_selected_count': 22,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 22,
                        'dat_canonical_record_count': 0,
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_EMPTY_FILE': 22},
                    },
                }, f)
            reject_path = os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(live_d))
            with open(reject_path, 'w', encoding='utf-8') as f:
                f.write('{"reason_code":"QA_DAT_EMPTY_FILE"}\n')
            dat_anchor_profile_json = os.path.join(reports, 'dat_anchor_failure_profile_{0}.json'.format(live_d))
            dat_anchor_profile_txt = os.path.join(reports, 'dat_anchor_failure_profile_{0}.txt'.format(live_d))
            with open(dat_anchor_profile_json, 'w', encoding='utf-8') as f:
                json.dump({'run_id': live_d, 'schema_version': 'dat_anchor_failure_profile_v1'}, f)
            with open(dat_anchor_profile_txt, 'w', encoding='utf-8') as f:
                f.write('DAT Anchor Failure Profile\n')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
                'phase_run_ids': {'D': anchored_d},
                'diagnostics_state': {'last_phase_d_run_id': anchored_d},
            }
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': anchor,
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': anchor, 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=(context_note, {'pack_scope': 'anchor_run', 'anchor_run_id': anchor})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle_followup.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            extra_files = mock_collect.call_args[1].get('extra_files', [])
            basenames = [item[0] for item in extra_files]
            note_name = 'run_evidence_phase_d_followup_note_{0}.txt'.format(anchor)
            self.assertIn(os.path.basename(qa_path), basenames)
            self.assertIn(os.path.basename(reject_path), basenames)
            self.assertIn(os.path.basename(dat_anchor_profile_json), basenames)
            self.assertIn(os.path.basename(dat_anchor_profile_txt), basenames)
            self.assertIn(note_name, basenames)
            manifest = mock_collect.call_args[1].get('evidence_manifest')
            rows = {
                row.get('archive_name'): row
                for row in (manifest or {}).get('attachments', [])
                if isinstance(row, dict)
            }
            self.assertEqual(rows[os.path.basename(qa_path)].get('source_kind'), 'followup_only')
            self.assertEqual(rows[os.path.basename(reject_path)].get('source_kind'), 'followup_only')
            self.assertEqual(rows[os.path.basename(dat_anchor_profile_json)].get('source_kind'), 'followup_only')
            self.assertEqual(rows[os.path.basename(dat_anchor_profile_txt)].get('source_kind'), 'followup_only')
            self.assertEqual(rows[note_name].get('source_kind'), 'followup_only')
            self.assertEqual(rows[os.path.basename(qa_path)].get('freshness'), 'followup_only')
            self.assertEqual((manifest or {}).get('scope', {}).get('phase_d_followup_run_id'), live_d)
            note_path = os.path.join(reports, note_name)
            with open(note_path, 'r', encoding='utf-8') as f:
                note_body = f.read()
            self.assertIn('reviewed_anchor_phase_d_run_id={0}'.format(anchored_d), note_body)
            self.assertIn('followup_phase_d_run_id={0}'.format(live_d), note_body)
            self.assertIn('followup_source=live_diagnostics_state', note_body)
            self.assertIn('accepted_as_reviewed_anchor_milestone=False', note_body)
            runbook_body = '\n'.join(data.get('runbook_lines', []))
            self.assertIn('Phase D follow-up evidence:', runbook_body)
            self.assertIn('anchor_phase_d_movement_classification=zero_selection', runbook_body)
            self.assertIn('followup_phase_d_movement_classification=selected_rejected', runbook_body)
            self.assertIn('accepted_as_reviewed_anchor_milestone=False', runbook_body)
            self.assertIn('dominant_reject_code=QA_DAT_EMPTY_FILE', runbook_body)
            self.assertIn('next_action=Treat the anchor milestone verdict as unchanged', runbook_body)
            assert_workflow_boundary_clean('run_evidence_bundle_phase_d_overtake', {
                'anchor_run_id': anchor,
                'phase_d_run_id': live_d,
            }, [
                {
                    'name': os.path.basename(qa_path),
                    'role': 'artifact',
                    'identity': {'anchor_run_id': anchor, 'phase_d_run_id': live_d},
                    'status': 'completed',
                    'terminal': True,
                },
                {
                    'name': note_name,
                    'role': 'packaging',
                    'identity': {'anchor_run_id': anchor, 'phase_d_run_id': live_d},
                    'status': 'completed',
                    'accepted': False,
                    'classification': 'note_present',
                    'claims_completion': False,
                },
            ])

    def test_send_latest_run_evidence_bundle_attaches_dat_smoke_artifacts_and_note(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_lab = os.path.join(repo, 'phase_d_dat_smoke_lab')
            smoke_reports = os.path.join(smoke_lab, 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            for path in (triage_path, index_path, delivery_path, context_note):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x')
            smoke_run = '20260330-000001-smoke'
            smoke_report_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(smoke_run))
            smoke_report_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(smoke_run))
            smoke_shadow_json = os.path.join(smoke_reports, 'shadow_run_report_{0}.json'.format(smoke_run))
            smoke_shadow_txt = os.path.join(smoke_reports, 'shadow_run_report_{0}.txt'.format(smoke_run))
            with open(smoke_report_txt, 'w', encoding='utf-8') as f:
                f.write('smoke txt\n')
            with open(smoke_report_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': smoke_run, 'assessment': 'dat_discovered_not_ingested'}, f)
            with open(smoke_shadow_json, 'w', encoding='utf-8') as f:
                json.dump({'run_id': smoke_run}, f)
            with open(smoke_shadow_txt, 'w', encoding='utf-8') as f:
                f.write('shadow txt\n')
            state_path = cr.phase_d_dat_smoke_state_path(repo)
            state_parent = os.path.dirname(state_path)
            if state_parent and not os.path.isdir(state_parent):
                os.makedirs(state_parent)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': '20260329-171213-1ccb1c51',
                    'last_requested_context_run_id': '20260329-171213-1ccb1c51',
                    'last_remediation_issue_code': '',
                    'last_status': 'completed',
                    'last_report_path': smoke_report_txt,
                    'last_assessment': 'dat_discovered_not_ingested',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'phase_d_dat_smoke',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': False,
                'dat_smoke_evaluated': True,
                'dat_smoke_available': True,
                'recommendation_anchor_run_id': '20260329-171213-1ccb1c51',
                'action_preview': {
                    'anchor_run_id': '20260329-171213-1ccb1c51',
                    'phase_d_context_run_id': '20260329-171213-1ccb1c51',
                    'smoke_lab_root': smoke_lab,
                    'smoke_reports_dir': smoke_reports,
                    'expected_report_path': os.path.join(smoke_reports, 'phase_d_dat_smoke_report_<smoke_pipeline_run_id>.txt'),
                    'reference_phase_d_summary_path': os.path.join(reports, 'qa_canonical_summary_20260329-171213-1ccb1c51.json'),
                },
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=(context_note, {'pack_scope': 'mixed_scope', 'anchor_run_id': 'other'})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle_smoke.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('phase_d_dat_smoke_state.json', basenames)
            self.assertIn(os.path.basename(smoke_report_txt), basenames)
            self.assertIn(os.path.basename(smoke_report_json), basenames)
            self.assertIn(os.path.basename(smoke_shadow_json), basenames)
            self.assertIn(os.path.basename(smoke_shadow_txt), basenames)
            self.assertIn('run_evidence_dat_smoke_note_20260329-171213-1ccb1c51.txt', basenames)

    def test_send_latest_run_evidence_bundle_omits_phase_d_reprocess_when_not_historical_action(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for path in (triage_path, index_path, delivery_path, context_note, preview_path, execution_path):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('stale\n')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=('', {})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle2.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertNotIn('phase_d_historical_reprocess_preview_latest.txt', basenames)
            self.assertNotIn('phase_d_historical_reprocess_execution_latest.txt', basenames)

    def test_send_latest_system_health_pack_post_update_with_delivery_ready_keeps_delivery_separate_from_evidence(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            diag_path = os.path.join(lab, 'diagnostics_state.json')
            cursor_path = os.path.join(lab, 'run_cursor.json')
            for path, text in (
                    (pack_path, 'System Health Pack\ncurrent_evidence_mode=live_status\n'),
                    (delivery_path, 'Report Delivery Status\n'),
                    (diag_path, '{}\n'),
                    (cursor_path, '{}\n')):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(text)
            preflight = {
                'token_available': True,
                'recipient_count': 2,
                'token_probe_error': '',
            }
            pack_context = {
                'anchor_run_id': 'completed-run',
                'pack_scope': 'mixed_scope',
                'active_run_id': 'active-run',
                'expected_shadow_run_id': 'completed-run',
                'anchor_state': {},
                'anchor_report_path': '',
                'state': {
                    'active_run_id': 'active-run',
                    'last_shadow_pipeline_run_id': 'completed-run',
                },
                'evidence_mode': {
                    'mode': 'live_status',
                    'active_run_id': 'active-run',
                    'last_completed_run_id': 'completed-run',
                    'decisive_run_evidence_current': False,
                    'current_decision': 'send_live_status_wait_for_completed_run',
                    'blocking_reason': 'active_run_differs_from_last_completed',
                },
            }
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'system_health_pack',
                'summary_line': 'Send live status pack.',
            }
            with patch.object(cr, '_collect_delivery_diagnostics', return_value=preflight):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(True, '', pack_path)):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value={
                        'repo_root': repo,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'consolidated_path': '',
                        'audit_summary_txt': '',
                        'audit_summary_json': '',
                        'audit_metrics_json': '',
                        'shadow_report_path': '',
                        'shadow_index_path': '',
                        'phase_f_mismatch_path': '',
                        'delivery_status_path': delivery_path,
                        'consolidated_message': '',
                        'consolidated_ok': True,
                    }):
                        with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                            with patch.object(cr, '_collect_current_state_bundle_companion_files', return_value=[]):
                                with patch.object(cr, '_latest_interrupt_report_paths', return_value=[]):
                                    with patch.object(cr, '_select_latest_evidence_files', return_value=[]):
                                        with patch.object(cr, 'collect_support_bundle', return_value=os.path.join(reports, 'bundle.zip')) as mock_collect:
                                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {'delivery_issue': ''})) as mock_submit:
                                                ok, msg, data = cr.send_latest_system_health_pack(
                                                    repo,
                                                    lambda _n, default: default,
                                                    recommendation=recommendation,
                                                    send_source='post_update_cloud_autofollow',
                                                    operator_execution_mode='post_update_autofollow',
                                                )
            self.assertTrue(ok)
            self.assertEqual(msg, 'sent')
            self.assertEqual(data.get('delivery_status_path'), delivery_path)
            self.assertEqual(data.get('delivery_diag'), preflight)
            extra_meta = mock_collect.call_args[1].get('extra_meta')
            self.assertEqual(extra_meta.get('email_delivery_preflight'), preflight)
            self.assertEqual(extra_meta.get('current_evidence_mode'), 'live_status')
            self.assertFalse(extra_meta.get('decisive_run_evidence_current'))
            self.assertEqual(extra_meta.get('layer1_readiness_status'), 'not_reached')
            self.assertTrue(extra_meta.get('historical_layer1_debug_only'))
            self.assertFalse(extra_meta.get('layer1_evaluated'))
            aliases = [row[0] for row in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('system_health_pack_latest.txt', aliases)
            self.assertIn('report_delivery_status.txt', aliases)
            self.assertNotIn('qa_canonical_summary_completed-run.json', aliases)
            mock_submit.assert_called_once()
            self.assertFalse(mock_submit.call_args[1].get('allow_interactive_reauth'))

    def test_send_latest_system_health_pack_attaches_same_anchor_historical_reprocess_execution_and_attempt(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            attempt_path = os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-1.json')
            attempt_txt = os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-1.txt')
            for path, body in (
                    (pack_path, 'System Health Pack\n'),
                    (delivery_path, 'Report Delivery Status\n'),
                    (execution_path, (
                        'Historical Phase D Re-Evaluation Execution\n'
                        'remediation_context_run_id={0}\n'
                        'execution_status=completed\n').format(anchor)),
                    (attempt_txt, 'Phase D manual attempt\n')):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(body)
            with open(attempt_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'schema_version': 'diagnostic_attempt_v1',
                    'diagnostic_kind': 'phase_d_manual',
                    'attempt_id': 'attempt-1',
                    'target_anchor_run_id': anchor,
                    'target_context_run_id': anchor,
                    'status': 'succeeded',
                    'accepted_for_anchor': True,
                }, f)
            pack_context = {
                'anchor_run_id': anchor,
                'pack_scope': 'completed_run',
                'active_run_id': '',
                'expected_shadow_run_id': anchor,
                'state': {
                    'last_shadow_pipeline_run_id': anchor,
                    'last_shadow_pipeline_phase_run_ids': {'D': anchor},
                },
                'evidence_mode': {
                    'mode': 'run_evidence',
                    'decisive_run_evidence_current': True,
                },
            }
            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(True, '', pack_path)):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value={
                        'repo_root': repo,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'consolidated_path': '',
                        'audit_summary_txt': '',
                        'audit_summary_json': '',
                        'audit_metrics_json': '',
                        'delivery_status_path': delivery_path,
                    }):
                        with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                            with patch.object(cr, '_collect_current_state_bundle_companion_files', return_value=[]):
                                with patch.object(cr, '_latest_interrupt_report_paths', return_value=[]):
                                    with patch.object(cr, '_select_latest_evidence_files', return_value=[]):
                                        with patch.object(cr, 'collect_support_bundle', return_value=os.path.join(reports, 'bundle.zip')) as mock_collect:
                                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {})):
                                                ok, msg, _data = cr.send_latest_system_health_pack(
                                                    repo,
                                                    lambda _n, default: default,
                                                    recommendation={'recommended_action_kind': 'send_bundle'},
                                                )
            self.assertTrue(ok)
            self.assertEqual(msg, 'sent')
            aliases = [row[0] for row in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('phase_d_historical_reprocess_execution_latest.txt', aliases)
            self.assertIn('diagnostic_attempt_phase_d_manual_attempt-1.json', aliases)
            self.assertIn('diagnostic_attempt_phase_d_manual_attempt-1.txt', aliases)
            extra_meta = mock_collect.call_args[1].get('extra_meta')
            self.assertEqual(extra_meta.get('phase_d_historical_reprocess_attachment_status'), 'execution_attached')
            self.assertTrue(extra_meta.get('phase_d_historical_reprocess_execution_attached'))
            self.assertFalse(extra_meta.get('phase_d_historical_reprocess_preview_attached'))
            self.assertEqual(extra_meta.get('phase_d_diagnostic_attempt_attachment_count'), 2)

    def test_send_latest_system_health_pack_marks_preview_only_as_not_execution_proof(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            for path, body in (
                    (pack_path, 'System Health Pack\n'),
                    (delivery_path, 'Report Delivery Status\n'),
                    (preview_path, (
                        'Historical Phase D Re-Evaluation Preview\n'
                        'remediation_context_run_id={0}\n').format(anchor))):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(body)
            pack_context = {
                'anchor_run_id': anchor,
                'pack_scope': 'completed_run',
                'active_run_id': '',
                'expected_shadow_run_id': anchor,
                'state': {'last_shadow_pipeline_run_id': anchor},
                'evidence_mode': {'mode': 'run_evidence', 'decisive_run_evidence_current': True},
            }
            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(True, '', pack_path)):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value={
                        'repo_root': repo,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'consolidated_path': '',
                        'audit_summary_txt': '',
                        'audit_summary_json': '',
                        'audit_metrics_json': '',
                        'delivery_status_path': delivery_path,
                    }):
                        with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                            with patch.object(cr, '_collect_current_state_bundle_companion_files', return_value=[]):
                                with patch.object(cr, '_latest_interrupt_report_paths', return_value=[]):
                                    with patch.object(cr, '_select_latest_evidence_files', return_value=[]):
                                        with patch.object(cr, 'collect_support_bundle', return_value=os.path.join(reports, 'bundle.zip')) as mock_collect:
                                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {})):
                                                ok, msg, _data = cr.send_latest_system_health_pack(
                                                    repo,
                                                    lambda _n, default: default,
                                                    recommendation={'recommended_action_kind': 'send_bundle'},
                                                )
            self.assertTrue(ok)
            self.assertEqual(msg, 'sent')
            aliases = [row[0] for row in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('phase_d_historical_reprocess_preview_latest.txt', aliases)
            self.assertNotIn('phase_d_historical_reprocess_execution_latest.txt', aliases)
            extra_meta = mock_collect.call_args[1].get('extra_meta')
            self.assertEqual(extra_meta.get('phase_d_historical_reprocess_attachment_status'), 'preview_only')
            self.assertTrue(extra_meta.get('phase_d_historical_reprocess_preview_attached'))
            self.assertFalse(extra_meta.get('phase_d_historical_reprocess_execution_attached'))

    def test_send_latest_system_health_pack_fail_closes_mismatched_historical_reprocess_execution(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            wrong_attempt = os.path.join(reports, 'diagnostic_attempt_phase_d_manual_wrong.json')
            for path, body in (
                    (pack_path, 'System Health Pack\n'),
                    (delivery_path, 'Report Delivery Status\n'),
                    (preview_path, (
                        'Historical Phase D Re-Evaluation Preview\n'
                        'remediation_context_run_id={0}\n').format(anchor)),
                    (execution_path, (
                        'Historical Phase D Re-Evaluation Execution\n'
                        'remediation_context_run_id=other-anchor\n'
                        'execution_status=completed\n'))):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(body)
            with open(wrong_attempt, 'w', encoding='utf-8') as f:
                json.dump({
                    'schema_version': 'diagnostic_attempt_v1',
                    'diagnostic_kind': 'phase_d_manual',
                    'attempt_id': 'wrong',
                    'target_anchor_run_id': 'other-anchor',
                    'target_context_run_id': 'other-anchor',
                    'status': 'succeeded',
                }, f)
            pack_context = {
                'anchor_run_id': anchor,
                'pack_scope': 'completed_run',
                'active_run_id': '',
                'expected_shadow_run_id': anchor,
                'state': {'last_shadow_pipeline_run_id': anchor},
                'evidence_mode': {'mode': 'run_evidence', 'decisive_run_evidence_current': True},
            }
            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(True, '', pack_path)):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value={
                        'repo_root': repo,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'consolidated_path': '',
                        'audit_summary_txt': '',
                        'audit_summary_json': '',
                        'audit_metrics_json': '',
                        'delivery_status_path': delivery_path,
                    }):
                        with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                            with patch.object(cr, '_collect_current_state_bundle_companion_files', return_value=[]):
                                with patch.object(cr, '_latest_interrupt_report_paths', return_value=[]):
                                    with patch.object(cr, '_select_latest_evidence_files', return_value=[]):
                                        with patch.object(cr, 'collect_support_bundle', return_value=os.path.join(reports, 'bundle.zip')) as mock_collect:
                                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {})):
                                                ok, msg, _data = cr.send_latest_system_health_pack(
                                                    repo,
                                                    lambda _n, default: default,
                                                    recommendation={'recommended_action_kind': 'send_bundle'},
                                                )
            self.assertTrue(ok)
            self.assertEqual(msg, 'sent')
            aliases = [row[0] for row in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('phase_d_historical_reprocess_preview_latest.txt', aliases)
            self.assertNotIn('phase_d_historical_reprocess_execution_latest.txt', aliases)
            self.assertIn('system_health_phase_d_reprocess_attachment_note_{0}.txt'.format(anchor), aliases)
            self.assertNotIn('diagnostic_attempt_phase_d_manual_wrong.json', aliases)
            extra_meta = mock_collect.call_args[1].get('extra_meta')
            self.assertEqual(extra_meta.get('phase_d_historical_reprocess_attachment_status'), 'fail_closed')
            self.assertEqual(extra_meta.get('phase_d_historical_reprocess_fail_closed_reason'), 'execution_context_mismatch')
            note_path = os.path.join(reports, 'system_health_phase_d_reprocess_attachment_note_{0}.txt'.format(anchor))
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('attachment_status=fail_closed', body)
            self.assertIn('attachment_reason=execution_context_mismatch', body)
            self.assertIn('execution_report_accepted=False', body)



class TestRecommendationAndBundleEdgeCases(unittest.TestCase):
    """Paths that exercise pack context, interrupt attachment rules, and Phase D dedupe."""

    def test_collect_run_evidence_context_attachment_uses_pack_text_anchor_without_second_artifact_scan(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260415-232243-0b19e55a'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            with open(pack_path, 'w', encoding='utf-8') as f:
                f.write('System Health Pack\n')
                f.write(' - recommendation_anchor_run_id={0}\n'.format(run_id))

            snapshot = {
                'reports_dir': reports,
                'lab_root': lab,
                'run_id': run_id,
            }
            with patch.object(cr, 'open_latest_system_health_pack', side_effect=AssertionError('should not rebuild system health pack')):
                with patch.object(cr, '_collect_system_health_artifacts', side_effect=AssertionError('should not rescan health artifacts')):
                    path, context = cr._collect_run_evidence_context_attachment(repo, snapshot)
        self.assertEqual(path, pack_path)
        self.assertEqual(context.get('anchor_run_id'), run_id)
        self.assertEqual(context.get('pack_scope'), 'completed_run')
        self.assertEqual(context.get('reuse_policy'), 'cached_same_anchor')

    def test_collect_run_evidence_context_attachment_writes_note_for_mismatched_cached_pack(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260415-232243-0b19e55a'
            other_run = '20260415-222222-other'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            with open(pack_path, 'w', encoding='utf-8') as f:
                f.write('System Health Pack\n')
                f.write(' - recommendation_anchor_run_id={0}\n'.format(other_run))

            snapshot = {
                'reports_dir': reports,
                'lab_root': lab,
                'run_id': run_id,
            }
            with patch.object(cr, 'open_latest_system_health_pack', side_effect=AssertionError('should not rebuild system health pack')):
                path, context = cr._collect_run_evidence_context_attachment(repo, snapshot)
            self.assertNotEqual(path, pack_path)
            self.assertTrue(os.path.basename(path).startswith('run_evidence_context_note_'))
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
        self.assertIn('did not match run evidence anchor', body)
        self.assertIn(other_run, body)
        self.assertEqual(context.get('anchor_run_id'), other_run)

    def test_refresh_support_send_job_context_for_meta_reads_current_job_snapshot(self):
        from MediCafe import cloud_readiness_recommendations as rec
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            jobs_dir = os.path.join(lab, 'reports', 'support_send_jobs')
            os.makedirs(jobs_dir)
            job_id = 'ssj_unit_123'
            stale = {
                'job_id': job_id,
                'status': 'running',
                'progress_stage': 'starting',
                'progress_events': [{'stage': 'starting'}],
            }
            current = {
                'job_id': job_id,
                'status': 'running',
                'progress_stage': 'checking cached context pack',
                'progress_events': [
                    {'stage': 'starting'},
                    {'stage': 'checking cached context pack', 'elapsed_since_start_sec': 2.0},
                ],
            }
            with open(os.path.join(jobs_dir, 'job_{0}.json'.format(job_id)), 'w', encoding='utf-8') as f:
                json.dump(current, f)
            refreshed = rec._refresh_support_send_job_context_for_meta(lab, stale)
        self.assertEqual(refreshed.get('progress_stage'), 'checking cached context pack')
        self.assertEqual(len(refreshed.get('progress_events')), 2)

    def test_send_latest_system_health_pack_refreshes_support_send_job_context_meta_from_job_file(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            jobs_dir = os.path.join(reports, 'support_send_jobs')
            os.makedirs(jobs_dir)
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            for path, text in (
                    (pack_path, 'System Health Pack\n'),
                    (delivery_path, 'Report Delivery Status\n'),
                    (os.path.join(lab, 'diagnostics_state.json'), '{}\n'),
                    (os.path.join(lab, 'run_cursor.json'), '{}\n')):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(text)
            job_id = 'ssj_refresh_meta_1'
            stale_ctx = {
                'job_id': job_id,
                'status': 'running',
                'progress_stage': 'starting',
                'progress_events': [{'stage': 'starting'}],
            }
            refreshed_ctx = {
                'job_id': job_id,
                'status': 'running',
                'progress_stage': 'collecting attachments',
                'progress_events': [
                    {'stage': 'starting'},
                    {'stage': 'collecting attachments', 'elapsed_since_start_sec': 3.0},
                ],
            }
            with open(os.path.join(jobs_dir, 'job_{0}.json'.format(job_id)), 'w', encoding='utf-8') as f:
                json.dump(refreshed_ctx, f)
            pack_context = {
                'anchor_run_id': 'completed-run',
                'pack_scope': 'completed_run',
                'active_run_id': 'completed-run',
                'expected_shadow_run_id': 'completed-run',
                'anchor_state': {},
                'anchor_report_path': pack_path,
                'state': {'last_shadow_pipeline_run_id': 'completed-run'},
                'evidence_mode': {
                    'mode': 'run_evidence',
                    'active_run_id': 'completed-run',
                    'last_completed_run_id': 'completed-run',
                    'decisive_run_evidence_current': True,
                },
            }
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'system_health_pack',
                'summary_line': 'Send system health pack.',
            }
            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(True, '', pack_path)):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value={
                        'repo_root': repo,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'consolidated_path': '',
                        'audit_summary_txt': '',
                        'audit_summary_json': '',
                        'audit_metrics_json': '',
                        'shadow_report_path': '',
                        'shadow_index_path': '',
                        'phase_f_mismatch_path': '',
                        'delivery_status_path': delivery_path,
                        'consolidated_message': '',
                        'consolidated_ok': True,
                    }):
                        with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                            with patch.object(cr, '_collect_current_state_bundle_companion_files', return_value=[]):
                                with patch.object(cr, '_latest_interrupt_report_paths', return_value=[]):
                                    with patch.object(cr, '_select_latest_evidence_files', return_value=[]):
                                        with patch.object(cr, 'collect_support_bundle', return_value=os.path.join(reports, 'bundle.zip')) as mock_collect:
                                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {})):
                                                ok, msg, _data = cr.send_latest_system_health_pack(
                                                    repo,
                                                    lambda _n, default: default,
                                                    recommendation=recommendation,
                                                    support_send_job_context=stale_ctx,
                                                )
            self.assertTrue(ok)
            self.assertEqual(msg, 'sent')
            meta = mock_collect.call_args[1].get('extra_meta', {})
            refreshed_meta = meta.get('support_send_job_context', {})
            self.assertEqual(refreshed_meta.get('progress_stage'), 'collecting attachments')
            self.assertEqual(len(refreshed_meta.get('progress_events')), 2)

    def test_recommendation_recent_shadow_helper_keeps_report_files_signature_after_global_sync(self):
        from MediCafe import cloud_readiness_recommendations as rec
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'reports')
            os.makedirs(reports)
            rec._sync_cloud_readiness_globals()
            lines = rec._build_recent_shadow_run_actual_lines(
                reports,
                limit=2,
                expected_run_id='',
                report_files=[],
            )
        self.assertTrue(lines)

    def test_followthrough_resolve_dat_integration_uses_system_health_pack(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        rec = {
            'recommended_action_kind': 'resolve_dat_integration_blocker',
            'preferred_when_stable_action_kind': 'resolve_dat_integration_blocker',
            'best_now_action_kind': 'resolve_dat_integration_blocker',
            'primary_send': 'system_health',
            'best_now_send': 'system_health',
        }
        self.assertEqual(tools.recommendation_followthrough_now(rec), 'send_system_health_pack')
        lines = tools.format_recommended_action_lines(rec)
        self.assertIn(' - operator_manual_review_required=False', lines)

    def test_followthrough_external_patient_id_contract_uses_system_health_pack(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        rec = {
            'recommended_action_kind': 'resolve_external_patient_id_contract_pressure',
            'preferred_when_stable_action_kind': 'resolve_external_patient_id_contract_pressure',
            'best_now_action_kind': 'resolve_external_patient_id_contract_pressure',
            'primary_send': 'system_health',
            'best_now_send': 'system_health',
        }
        self.assertEqual(tools.recommendation_followthrough_now(rec), 'send_system_health_pack')
        lines = tools.format_recommended_action_lines(rec)
        self.assertIn(' - operator_manual_review_required=False', lines)

    def test_deferred_support_send_preserves_external_patient_id_contract_action(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            self.assertTrue(cr.write_operator_deferred_support_send(
                repo,
                'system_health',
                reason='layer1 action deferred while pipeline busy',
                action_kind='resolve_external_patient_id_contract_pressure',
                recommended_report_kind='system_health_pack',
            ))
            payload = cr.read_operator_deferred_support_send(repo)
        self.assertEqual(payload.get('primary_send'), 'system_health')
        self.assertEqual(payload.get('action_kind'), 'resolve_external_patient_id_contract_pressure')
        self.assertEqual(payload.get('recommended_report_kind'), 'system_health_pack')

    def test_delivery_status_surfaces_self_observed_system_health_job(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            jobs_dir = os.path.join(lab, 'reports', 'support_send_jobs')
            os.makedirs(jobs_dir)
            with open(os.path.join(jobs_dir, 'job_shp.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'job_id': 'shp',
                    'created_epoch': 100.0,
                    'send_type': 'system_health',
                    'status': 'running',
                    'delivery_state': '',
                    'finished_at_utc': '',
                    'self_observation_status': 'self_observed_in_flight',
                }, f)
            with patch.object(cr, '_collect_delivery_diagnostics', return_value={
                'token_available': True,
                'recipient_count': 1,
                'queued_bundle_count': 0,
                'queued_bundle_paths': [],
            }):
                lines = cr.get_report_delivery_status_lines(lab)
        text = '\n'.join(lines)
        self.assertIn('Latest System Health support-send job:', text)
        self.assertIn('job_id=shp status=running', text)
        self.assertIn('self_observation_status=self_observed_in_flight', text)
        self.assertIn('final proof requires a later queue/status refresh', text)

    def test_phase_d_dat_smoke_paths_qa_full_block_mismatch_emits_note_only(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            reviewed = '20260329-171213-1ccb1c51'
            other = '20260331-022246-3b508c10'
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(other))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(other))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('x')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': other, 'assessment': 'dat_selected_qa_blocked'}, f)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommendation_anchor_run_id': reviewed,
                'action_preview': {'anchor_run_id': reviewed},
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, reviewed)
            self.assertTrue(any('run_evidence_smoke_anchor_mismatch_' in os.path.basename(p) for p in paths))
            self.assertFalse(any(os.path.basename(p).startswith('phase_d_dat_smoke_report') for p in paths))
            note_path = next(p for p in paths if 'run_evidence_smoke_anchor_mismatch_' in os.path.basename(p))
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('smoke_state_last_status=completed', body)
            self.assertIn('smoke_state_last_assessment=dat_selected_qa_blocked', body)
            self.assertIn('state_requested_anchor_run_id_missing', body)

    def test_phase_d_dat_smoke_paths_qa_full_block_missing_report_still_emits_note(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            reviewed = '20260329-171213-1ccb1c51'
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': '',
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommendation_anchor_run_id': reviewed,
                'action_preview': {'anchor_run_id': reviewed},
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, reviewed)
            self.assertEqual(len(paths), 1)
            note_path = paths[0]
            self.assertIn('run_evidence_smoke_anchor_mismatch_', os.path.basename(note_path))
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('last_report_path=-', body)
            self.assertIn('state_last_report_path_missing', body)
            self.assertIn('smoke_report_anchor_run_id_missing', body)

    def test_phase_d_dat_smoke_paths_current_strict_dat_suppresses_stale_history(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            bundle = '20260510-181934-f63c8f0d'
            old = '20260331-022246-3b508c10'
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(old))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(old))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('old smoke\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': old, 'assessment': 'dat_selected_qa_blocked'}, f)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'send_bundle',
                'layer1_readiness': {
                    'layer1_data_status': 'strict_dat_integrated',
                    'phase_d_dat_canonical_record_count': 1610,
                    'layer1_dat_strict_integrated_count': 1620,
                },
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, bundle)
            basenames = [os.path.basename(p) for p in paths]
            self.assertIn('run_evidence_dat_smoke_note_{0}.txt'.format(bundle), basenames)
            self.assertNotIn(os.path.basename(smoke_txt), basenames)
            self.assertNotIn(os.path.basename(smoke_json), basenames)
            note_path = [p for p in paths if os.path.basename(p).startswith('run_evidence_dat_smoke_note_')][0]
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('stale_smoke_context_status=superseded_by_current_phase_d_context', body)
            self.assertIn('attached_smoke_artifact_count=0', body)

    def test_phase_d_dat_smoke_paths_started_attempt_rejects_stale_last_report(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            target = '20260511-115334-b040ea72'
            old = '20260331-022246-3b508c10'
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(old))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(old))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('old smoke\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': old, 'assessment': 'dat_selected_qa_blocked'}, f)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': target,
                    'last_requested_context_run_id': '20260511-115358-ff787d8a',
                    'last_status': 'started',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'phase_d_dat_smoke',
                'recommendation_anchor_run_id': target,
                'dat_smoke_evaluated': True,
                'action_preview': {
                    'anchor_run_id': target,
                    'smoke_lab_root': os.path.join(repo, 'phase_d_dat_smoke_lab'),
                    'smoke_reports_dir': smoke_reports,
                },
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, target)
            basenames = [os.path.basename(p) for p in paths]
            self.assertIn('phase_d_dat_smoke_state.json', basenames)
            self.assertIn('run_evidence_dat_smoke_note_{0}.txt'.format(target), basenames)
            self.assertIn('run_evidence_smoke_anchor_mismatch_{0}.txt'.format(target), basenames)
            self.assertNotIn(os.path.basename(smoke_txt), basenames)
            self.assertNotIn(os.path.basename(smoke_json), basenames)
            note_path = [p for p in paths if os.path.basename(p).startswith('run_evidence_dat_smoke_note_')][0]
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('attached_smoke_artifact_count=2', body)
            self.assertIn('state_last_status=started', body)

    def test_phase_d_dat_smoke_note_marks_accepted_same_anchor_artifacts(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            target = '20260512-010537-94d80f96'
            context = '20260512-010607-5615b4e6'
            smoke = '20260512-010700-54f48ff6'
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(smoke))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(smoke))
            shadow_json = os.path.join(smoke_reports, 'shadow_run_report_{0}.json'.format(smoke))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('smoke\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': smoke, 'assessment': 'dat_discovered_not_ingested'}, f)
            with open(shadow_json, 'w', encoding='utf-8') as f:
                json.dump({'run_id': smoke}, f)
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': target,
                    'last_requested_context_run_id': context,
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_discovered_not_ingested',
                }, f)
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': target,
                'action_preview': {
                    'anchor_run_id': target,
                    'smoke_lab_root': os.path.join(repo, 'phase_d_dat_smoke_lab'),
                    'smoke_reports_dir': smoke_reports,
                },
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, target)
            note_path = [p for p in paths if os.path.basename(p).startswith('run_evidence_dat_smoke_note_')][0]
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('accepted_for_anchor=True', body)
            self.assertIn('target_context_run_id={0}'.format(context), body)
            self.assertIn('accepted_requested_anchor_run_id={0}'.format(target), body)
            self.assertIn('accepted_smoke_anchor_run_id={0}'.format(smoke), body)
            assert_workflow_boundary_clean('phase_d_dat_smoke_note', {
                'anchor_run_id': target,
                'context_run_id': context,
            }, [
                {
                    'name': 'phase_d_dat_smoke_state.json',
                    'role': 'attempt',
                    'identity': {'anchor_run_id': target, 'context_run_id': context},
                    'status': 'completed',
                    'terminal': True,
                },
                {
                    'name': os.path.basename(note_path),
                    'role': 'package',
                    'identity': {'anchor_run_id': target, 'context_run_id': context},
                    'classification': 'note_present',
                },
            ])

    def test_begin_phase_d_dat_smoke_attempt_clears_prior_terminal_fields(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(lab)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': 'old-anchor',
                    'last_finished_at_utc': '2026-03-31T02:23:35Z',
                    'last_status': 'completed',
                    'last_report_path': 'C:\\old\\phase_d_dat_smoke_report_old.txt',
                    'last_assessment': 'dat_selected_qa_blocked',
                    'cooldown_until_utc': '2026-03-31T02:53:35Z',
                }, f)
            self.assertTrue(cr.begin_phase_d_dat_smoke_attempt(
                repo,
                anchor_run_id='new-anchor',
                context_run_id='new-d',
                issue_code='PHASE_D_DAT_QA_FULL_BLOCK',
                started_at_utc='2026-05-11T11:54:34Z',
                attempt_id='attempt-1',
            ))
            st = cr.read_phase_d_dat_smoke_state(repo)
            self.assertEqual(st.get('last_attempt_id'), 'attempt-1')
            self.assertEqual(st.get('last_requested_anchor_run_id'), 'new-anchor')
            self.assertEqual(st.get('last_requested_context_run_id'), 'new-d')
            self.assertEqual(st.get('last_status'), 'started')
            self.assertEqual(st.get('last_finished_at_utc'), '')
            self.assertEqual(st.get('last_report_path'), '')
            self.assertEqual(st.get('last_assessment'), '')
            self.assertEqual(st.get('cooldown_until_utc'), '')
            self.assertEqual(st.get('previous_assessment'), 'dat_selected_qa_blocked')

    def test_phase_d_reprocess_paths_for_run_evidence_skips_metadata_mismatch(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for p in (prev, exe):
                with open(p, 'w', encoding='utf-8') as f:
                    f.write('Historical Phase D Re-Evaluation\n')
                    f.write('remediation_context_run_id=wrong-run\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'bundle-b')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_legacy_without_metadata_returns_empty(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            for name in (
                    'phase_d_historical_reprocess_preview_latest.txt',
                    'phase_d_historical_reprocess_execution_latest.txt'):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write('legacy pre-upgrade body\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'bundle-b')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_preview_only_missing_execution_returns_empty(self):
        """Preview-only historical reprocess report is surfaced elsewhere, not in run-evidence ZIP rules."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            with open(prev, 'w', encoding='utf-8') as f:
                f.write('Historical Phase D Re-Evaluation Preview\nremediation_context_run_id=anchor-z\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
                'historical_reprocess_preview_path': prev,
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'anchor-z')
            self.assertEqual(paths, [])

    def test_send_latest_run_evidence_bundle_adds_reprocess_fail_closed_note_when_reports_mismatch(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'anchor-z'
            triage_path = os.path.join(reports, 'artifact_triage_pack_{0}.txt'.format(rid))
            index_path = os.path.join(reports, 'run_artifact_index_{0}.txt'.format(rid))
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            with open(prev, 'w', encoding='utf-8') as f:
                f.write('Historical Phase D Re-Evaluation Preview\nremediation_context_run_id=other\n')
            with open(exe, 'w', encoding='utf-8') as f:
                f.write('Historical Phase D Re-Evaluation Execution\nremediation_context_run_id=other\n')
            for path in (triage_path, index_path, delivery_path):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x\n')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': rid,
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': rid,
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': rid, 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=('', {})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle_hist_note.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            note_name = 'run_evidence_phase_d_reprocess_attachment_note_{0}.txt'.format(rid)
            self.assertIn(note_name, basenames)
            self.assertNotIn('phase_d_historical_reprocess_preview_latest.txt', basenames)
            self.assertNotIn('phase_d_historical_reprocess_execution_latest.txt', basenames)
            with open(os.path.join(reports, note_name), 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('attachment_status=fail_closed', body)
            self.assertIn('attachment_reason=execution_context_mismatch', body)

    def test_send_latest_run_evidence_bundle_attaches_same_anchor_reprocess_after_recommendation_recomputes(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'anchor-z'
            d_rid = 'phase-d-z'
            triage_path = os.path.join(reports, 'artifact_triage_pack_{0}.txt'.format(rid))
            index_path = os.path.join(reports, 'run_artifact_index_{0}.txt'.format(rid))
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            attempt_json = os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-z.json')
            attempt_txt = os.path.join(reports, 'diagnostic_attempt_phase_d_manual_attempt-z.txt')
            with open(exe, 'w', encoding='utf-8') as f:
                f.write('Historical Phase D Re-Evaluation Execution\n')
                f.write('remediation_context_run_id={0}\n'.format(rid))
                f.write('execution_status=completed\n')
            with open(attempt_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'schema_version': 'diagnostic_attempt_v1',
                    'diagnostic_kind': 'phase_d_manual',
                    'attempt_id': 'attempt-z',
                    'target_anchor_run_id': rid,
                    'target_context_run_id': d_rid,
                    'status': 'succeeded',
                    'accepted_for_anchor': True,
                }, f)
            with open(attempt_txt, 'w', encoding='utf-8') as f:
                f.write('Phase D manual attempt\n')
            for path in (triage_path, index_path, delivery_path):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x\n')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': rid,
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
                'phase_run_ids': {'D': d_rid},
            }
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': rid,
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': rid, 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=('', {})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle_hist_exec.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('phase_d_historical_reprocess_execution_latest.txt', basenames)
            self.assertIn('diagnostic_attempt_phase_d_manual_attempt-z.json', basenames)
            self.assertIn('diagnostic_attempt_phase_d_manual_attempt-z.txt', basenames)
            extra_meta = mock_collect.call_args[1].get('extra_meta')
            self.assertEqual(extra_meta.get('phase_d_historical_reprocess_attachment_status'), 'execution_attached')
            self.assertTrue(extra_meta.get('phase_d_historical_reprocess_execution_attached'))
            self.assertEqual(extra_meta.get('phase_d_diagnostic_attempt_attachment_count'), 2)

    def test_phase_d_reprocess_paths_attaches_when_preview_execution_agree_and_match_bundle(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'bundle-match-1'
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for p in (prev, exe):
                with open(p, 'w', encoding='utf-8') as f:
                    f.write('Historical Phase D\nremediation_context_run_id={0}\n'.format(rid))
            rec = {'recommended_action_kind': 'historical_phase_d_reprocess'}
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, rid)
            self.assertEqual(len(paths), 2)
            self.assertIn(prev, paths)
            self.assertIn(exe, paths)

    def test_latest_interrupt_report_paths_filters_mismatched_bundle_run_id(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            jpath = os.path.join(reports, 'shadow_pipeline_interrupt_latest.json')
            with open(jpath, 'w', encoding='utf-8') as f:
                f.write(json.dumps({'run_id': 'run-a'}))
            tpath = os.path.join(reports, 'shadow_pipeline_interrupt_latest.txt')
            with open(tpath, 'w', encoding='utf-8') as f:
                f.write('interrupt txt')
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab, bundle_run_id='run-b')), 0)
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab, bundle_run_id='run-a')), 2)
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab)), 2)

    def test_collect_phase_d_reject_snapshot_dedupes_artifact_ids_across_qa_versions(self):
        from scripts.unified_model.phase_d_historical_reprocess import collect_phase_d_reject_snapshot
        with tempfile.TemporaryDirectory() as lab:
            db_path = os.path.join(lab, 'unified_model_xp.db')
            conn = sqlite3.connect(db_path)
            conn.execute(
                'CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY, source_type TEXT, payload_json TEXT)')
            conn.execute(
                'CREATE TABLE qa_result (artifact_id INTEGER, qa_stage TEXT, qa_version TEXT, status TEXT)')
            conn.execute('CREATE TABLE replay_queue (artifact_id INTEGER, status TEXT)')
            conn.execute('INSERT INTO ingest_artifact VALUES (1, "file_dat", "{}")')
            conn.execute('INSERT INTO qa_result VALUES (1, "phase_d", "qa_v1", "reject")')
            conn.execute('INSERT INTO qa_result VALUES (1, "phase_d", "qa_v2", "reject")')
            conn.commit()
            conn.close()
            snap = collect_phase_d_reject_snapshot(lab, qa_version=None)
            self.assertTrue(snap.get('ok'))
            self.assertEqual(snap.get('targeted_artifact_count'), 1)
            self.assertEqual(snap.get('targeted_artifact_ids'), [1])
            self.assertEqual(snap.get('reject_counts_by_class', {}).get('dat'), 2)

    def test_compute_operator_support_send_recommendation_invokes_selector_with_pack_context(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': os.path.join(lab, 'reports'),
                'shadow_report_path': '',
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'pack_scope': 'mixed_scope',
                    'anchor_run_id': 'anchor-rid',
                }):
                    with patch.object(cr, '_select_evaluation_snapshot_for_recommendation') as mock_sel:
                        mock_sel.return_value = (
                            True,
                            '',
                            {'run_id': 'anchor-rid', 'diagnostics_state': {}, 'lab_root': lab},
                            {
                                'live_run_id': 'live-rid',
                                'recommendation_source_scope': 'anchored_completed_run',
                                'recommendation_anchor_run_id': 'anchor-rid',
                                'fallback_note': '',
                                'newer_live_context_note': '',
                            },
                        )
                        with patch.object(cr, 'compute_operator_support_send_recommendation_core') as mock_core:
                            mock_core.return_value = {'summary_line': 'ok'}
                            cr.compute_operator_support_send_recommendation(repo)
        mock_sel.assert_called_once()
        self.assertEqual(mock_core.call_args[0][1].get('run_id'), 'anchor-rid')
        kwargs = mock_core.call_args[1]
        self.assertEqual(kwargs.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(kwargs.get('recommendation_anchor_run_id'), 'anchor-rid')
        self.assertEqual(kwargs.get('recommendation_live_run_id'), 'live-rid')

    def test_select_evaluation_snapshot_live_run_id_prefers_diagnostics_over_artifact_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            state_path = os.path.join(lab, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                f.write(json.dumps({'active_run_id': 'run-a', 'last_shadow_pipeline_run_id': ''}))
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', {'run_id': 'run-b'})):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    ok, _msg, _snap, meta = cr._select_evaluation_snapshot_for_recommendation(repo, {})
            self.assertEqual(meta.get('live_run_id'), 'run-a')

    def test_relax_anchor_clears_coherence_block_for_conflicting_live_diagnostics(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        anchor_id = '20260329-171213-1ccb1c51'
        anchor_snap = {
            'run_id': anchor_id,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': 'other-run',
                'last_shadow_pipeline_run_id': 'zzz',
            },
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(anchor_snap))
        relaxed = cr._relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
        self.assertFalse(art.artifact_snapshot_coherence_blocked(relaxed))

    def test_relax_anchor_clears_lineage_issues_for_handoff_coherence(self):
        """Zero-selection / phase_run_id skew surfaces as lineage_issues; anchor eval must ignore it."""
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        anchor_id = '20260331-005932-ba25d2aa'
        anchor_snap = {
            'run_id': anchor_id,
            'diagnostics_state': {},
            'lineage_issues': [
                'phase_d_zero_selection_phase_c_run_id_mismatch expected_phase_c=old resolved_phase_c=new',
            ],
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(anchor_snap))
        relaxed = cr._relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
        self.assertFalse(art.artifact_snapshot_coherence_blocked(relaxed))
        self.assertEqual(relaxed.get('lineage_issues'), [])

    def test_select_evaluation_snapshot_uses_live_status_for_mixed_scope(self):
        from MediCafe import cloud_readiness as cr
        anchor_id = '20260329-171213-1ccb1c51'
        anchor_snap_raw = {
            'run_id': anchor_id,
            'lab_root': '/tmp',
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': 'other',
                'last_shadow_pipeline_run_id': 'zzz',
            },
        }
        latest = {'run_id': 'older-artifact-run', 'diagnostics_state': {}}

        def fake_build(repo_root, run_id=''):
            rid = str(run_id or '').strip()
            if rid == anchor_id:
                return True, '', dict(anchor_snap_raw)
            return True, '', dict(latest)

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            with patch.object(cr, '_build_run_artifact_snapshot', side_effect=fake_build):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    ok, msg, snap, meta = cr._select_evaluation_snapshot_for_recommendation(
                        repo,
                        {'pack_scope': 'mixed_scope', 'anchor_run_id': anchor_id},
                    )
        self.assertTrue(ok)
        self.assertEqual(meta.get('recommendation_source_scope'), 'live_status')
        self.assertEqual(snap.get('run_id'), 'older-artifact-run')
        self.assertEqual(
            meta.get('newer_live_context_note'),
            'Mixed scope is non-actionable; using live status snapshot for recommendation.'
        )

    def test_run_phase_d_dat_smoke_returns_already_running_before_spawn(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            script_root = os.path.join(repo, 'scripts')
            script_path = os.path.join(script_root, 'run_phase_d_dat_smoke.py')
            os.makedirs(script_root)
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch.object(
                    cr,
                    '_resolve_unified_model_script',
                    return_value=(True, '', script_root, script_path, None)):
                with patch.object(cr, 'is_pipeline_running', return_value=True):
                    with patch.object(cr.subprocess, 'Popen') as mock_popen:
                        ok, msg, meta = cr.run_phase_d_dat_smoke(repo, sys.executable, {})
        self.assertFalse(ok)
        self.assertIn('already running', msg.lower())
        self.assertTrue(bool((meta or {}).get('already_running')))
        mock_popen.assert_not_called()

    def test_run_phase_d_dat_smoke_spawn_failure_transitions_to_failed_without_cooldown(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            script_root = os.path.join(repo, 'scripts')
            script_path = os.path.join(script_root, 'run_phase_d_dat_smoke.py')
            os.makedirs(script_root)
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')

            state_path = cr.phase_d_dat_smoke_state_path(repo)
            parent = os.path.dirname(state_path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': 'old-anchor',
                    'last_requested_context_run_id': 'old-context',
                    'last_remediation_issue_code': 'OLD_ISSUE',
                    'last_status': 'completed',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)

            with patch.object(
                    cr,
                    '_resolve_unified_model_script',
                    return_value=(True, '', script_root, script_path, None)):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    with patch.object(cr.subprocess, 'Popen', side_effect=RuntimeError('spawn failed')):
                        ok, msg, _meta = cr.run_phase_d_dat_smoke(
                            repo,
                            sys.executable,
                            {},
                            recommendation_anchor_run_id='anchor-new',
                            recommendation_context_run_id='ctx-new',
                            recommendation_issue_code='ISSUE_NEW',
                        )

            self.assertFalse(ok)
            self.assertIn('spawn failed', msg.lower())
            state = cr.read_phase_d_dat_smoke_state(repo)
            self.assertEqual(state.get('last_requested_anchor_run_id'), 'anchor-new')
            self.assertEqual(state.get('last_requested_context_run_id'), 'ctx-new')
            self.assertEqual(state.get('last_remediation_issue_code'), 'ISSUE_NEW')
            self.assertEqual(str(state.get('last_status', '')).lower(), 'failed')
            self.assertEqual(state.get('last_assessment'), 'spawn_failed')
            self.assertEqual(state.get('cooldown_until_utc'), '')
            self.assertTrue(bool(state.get('last_finished_at_utc')))
            self.assertFalse(
                cr._phase_d_dat_smoke_state_suppressed(state, 'anchor-new', 'ctx-new', 'ISSUE_NEW')
            )



class TestPhaseDRemediationOperatorSurfaces(unittest.TestCase):
    """phase_d_remediation formatting and recommendation merge; keeps operator surfaces aligned with phase_d_remediation.py."""

    def test_format_phase_d_remediation_surfaces_emits_stable_tokens(self):
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        rem = {
            'verification_target': 'phase_d_constraint_skips',
            'verification_scope': 'global_phase_d',
            'milestone_exit_ready': False,
            'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
            'status': 'active',
            'context_run_id': 'run-x',
        }
        lines = format_phase_d_remediation_surfaces(rem)
        joined = '\n'.join(lines)
        self.assertIn('phase_d_remediation: verification_target=phase_d_constraint_skips', joined)
        self.assertIn('phase_d_remediation: verification_scope=global_phase_d', joined)
        self.assertIn('phase_d_remediation: milestone_exit_ready=False', joined)
        self.assertIn('phase_d_remediation: issue_code=', joined)
        self.assertIn('phase_d_remediation glossary:', joined)

    def test_format_phase_d_remediation_surfaces_emits_shape_family_counts(self):
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        rem = {
            'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
            'status': 'active',
            'context_run_id': 'run-shapes',
            'confidence_inputs': {
                'invalid_external_id_shape_family_counts': {
                    'wrong_length_short': 3,
                    'blank/placeholder': 1,
                    'non_numeric': 0,
                },
                'invalid_external_id_source_contract_counts': {
                    'medibot_csv_patient_id_field': 3,
                },
                'invalid_external_id_contract_disposition_counts': {
                    'csv_patient_id_field_contains_display_text_or_wrong_column': 2,
                    'numeric_wrong_length': 1,
                },
                'external_patient_id_contract': {
                    'schema_version': 'external_patient_id_contract_v1',
                    'primary_scope': 'layer1_join_quality',
                    'primary_invalid_external_patient_id_count': 20,
                    'phase_d_patient_upsert': {'count': 13},
                    'layer1_join_quality': {'count': 20},
                    'contains_pii': False,
                },
            },
        }
        joined = '\n'.join(format_phase_d_remediation_surfaces(rem))
        self.assertIn(
            'phase_d_remediation: invalid_external_id_shape_families=wrong_length_short:3,blank/placeholder:1',
            joined,
        )
        self.assertIn(
            'phase_d_remediation: invalid_external_id_source_contracts=medibot_csv_patient_id_field:3',
            joined,
        )
        self.assertIn(
            'phase_d_remediation: invalid_external_id_contract_dispositions=csv_patient_id_field_contains_display_text_or_wrong_column:2,numeric_wrong_length:1',
            joined,
        )
        self.assertIn(
            'phase_d_remediation: external_patient_id_contract primary_scope=layer1_join_quality, primary_count=20, phase_d_patient_upsert=13, layer1_join_quality=20',
            joined,
        )
        self.assertNotIn('non_numeric:0', joined)
        self.assertNotIn('3712', joined)

    def test_compute_operator_support_send_recommendation_core_merges_phase_d_remediation(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(lab)
            rem = {
                'version': 1,
                'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
                'status': 'active',
                'context_run_id': 'rid-1',
                'verification_target': 'phase_d_constraint_skips',
                'verification_scope': 'global_phase_d',
                'milestone_exit_ready': False,
            }
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                f.write(json.dumps({'phase_d_remediation': rem}))
            # Positional order: repo_root, evaluation_snapshot, ok_snap, snap_msg, pipeline_running, ...
            out = cr.compute_operator_support_send_recommendation_core(
                repo,
                {'run_id': 'rid-1', 'nearest_complete_run_id': ''},
                ok_snap=False,
                snap_msg='no snapshot',
                pipeline_running=False,
            )
        self.assertEqual(out.get('phase_d_remediation'), rem)
        self.assertFalse(out.get('pipeline_running'))
        self.assertEqual(out.get('pipeline_label'), 'idle')
        expected_extra = format_phase_d_remediation_surfaces(rem)
        why = out.get('why_lines') or []
        for line in expected_extra:
            self.assertIn(line, why)

    def test_build_patient_trace_decision_surfaces_phase_d_remediation_keys(self):
        from MediCafe.cloud_readiness_patient_tools import build_patient_trace_decision
        selected = {
            'missing_fields': [],
            'reason': 'test',
            'claim_count': 1,
            'canonical_count': 1,
            'projection_reject_count': 0,
        }
        trace = {'rows': {'qa_result': [], 'replay_queue': []}}
        pdr = {
            'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
            'status': 'active',
            'context_run_id': 'anchor-rid',
            'verification_target': 'phase_d_dat_lane',
            'verification_scope': 'dat_lane_only',
            'milestone_exit_ready': None,
        }
        diag_state = {'phase_d_remediation': pdr}
        result = build_patient_trace_decision(selected, trace, diag_state)
        d = result.get('diagnostics') if isinstance(result.get('diagnostics'), dict) else {}
        self.assertEqual(d.get('phase_d_remediation_issue_code'), 'PHASE_D_DAT_QA_FULL_BLOCK')
        self.assertEqual(d.get('phase_d_remediation_status'), 'active')
        self.assertEqual(d.get('phase_d_remediation_context_run_id'), 'anchor-rid')
        self.assertEqual(d.get('phase_d_remediation_verification_target'), 'phase_d_dat_lane')
        self.assertEqual(d.get('phase_d_remediation_verification_scope'), 'dat_lane_only')
        self.assertIsNone(d.get('phase_d_remediation_milestone_exit_ready'))


class TestCloudReadinessRecommendationHelpers(unittest.TestCase):

    def test_build_recommendation_action_scaffold_defaults_preferred_action(self):
        from MediCafe import cloud_readiness_recommendations as crr

        payload = crr._build_recommendation_action_scaffold(
            recommended_action_kind='send_bundle',
            best_now_action_kind='wait_for_stable',
            recommended_artifact_classes=['dat'],
            action_reason_lines=['pipeline still running'],
        )

        self.assertEqual(payload.get('recommended_action_kind'), 'send_bundle')
        self.assertEqual(payload.get('preferred_when_stable_action_kind'), 'send_bundle')
        self.assertEqual(payload.get('best_now_action_kind'), 'wait_for_stable')
        self.assertEqual(payload.get('recommended_artifact_classes'), ['dat'])
        self.assertEqual(payload.get('action_reason_lines'), ['pipeline still running'])

    def test_diagnostics_section_returns_empty_dict_for_non_mapping_payload(self):
        from MediCafe import cloud_readiness_recommendations as crr

        self.assertEqual(crr._diagnostics_section({'phase_d_remediation': []}, 'phase_d_remediation'), {})
        self.assertEqual(crr._diagnostics_section({}, 'phase_d_remediation'), {})

    def test_sync_cloud_readiness_globals_preserves_module_identity(self):
        from MediCafe import cloud_readiness_recommendations as crr

        self.assertTrue(
            (crr.__name__ or '').endswith('cloud_readiness_recommendations'),
            msg='expected recommendations module name, got {0!r}'.format(crr.__name__),
        )
        self.assertIn('cloud_readiness_recommendations.py', crr.__file__ or '')
        crr._sync_cloud_readiness_globals()
        self.assertTrue(
            (crr.__name__ or '').endswith('cloud_readiness_recommendations'),
            msg='__name__ must stay on recommendations module after sync, got {0!r}'.format(crr.__name__),
        )
        self.assertIn('cloud_readiness_recommendations.py', crr.__file__ or '')
        # Decorated entry also re-syncs; identity must remain.
        crr._diagnostics_section({}, 'phase_d_remediation')
        self.assertTrue((crr.__name__ or '').endswith('cloud_readiness_recommendations'))
        self.assertIn('cloud_readiness_recommendations.py', crr.__file__ or '')

    def test_resolve_layer1_upstream_blocker_when_no_higher_priority_candidate(self):
        from MediCafe import cloud_readiness as mcr
        from MediCafe import cloud_readiness_recommendations as crr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            diag = {
                'last_discovery_ok': True,
                'last_phase_b_run_id': 'b1',
                'last_manifest_sha256': 'm',
                'last_ingest_manifest_sha256': 'm',
                'last_phase_c_ok': False,
                'last_phase_c_error_code': 'PHASE_C_DB_WRITE_ERROR',
                'last_phase_c_execution_handoff_status': 'failed',
                'last_phase_c_execution_handoff_blocker_class': 'phase_c_script_entered_but_no_finish_diag',
            }
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump(diag, f)
            with open(os.path.join(reports, 'artifact_discovery_summary_b1.json'), 'w', encoding='utf-8') as f:
                json.dump({'run_id': 'b1', 'counts_by_class': {'dat': 1}}, f)
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': 'x',
                'nearest_complete_run_id': '',
                'phase_rows': [],
                'diagnostics_state': diag,
            }
            with patch.object(mcr, 'resolve_lab_root', return_value=lab):
                with patch.object(mcr, '_artifact_bundle_quality', return_value={
                    'recommendation': 'review_lab_state',
                    'score': 40,
                    'label': 'LOW',
                }):
                    with patch.object(mcr, '_build_historical_phase_d_reprocess_recommendation', return_value=(None, '')):
                        with patch.object(mcr, '_build_phase_d_dat_smoke_recommendation', return_value=(None, '')):
                            with patch.object(mcr, '_build_phase_d_dat_qa_full_block_recommendation', return_value=(None, '')):
                                with patch.object(mcr, '_qa_drop_spike_reply_context', return_value={}):
                                    out = crr.compute_operator_support_send_recommendation_core(
                                        repo,
                                        snapshot,
                                        True,
                                        '',
                                        False,
                                    )
        self.assertEqual(out.get('recommended_action_kind'), 'resolve_layer1_upstream_blocker')
        self.assertEqual(out.get('recommended_report_kind'), 'system_health_pack')
        self.assertFalse(out.get('operator_manual_review_required'))
        self.assertFalse(out.get('reply_required'))
        self.assertFalse(out.get('reply_required_for_unblock'))
        self.assertNotIn('diagnostics_state.json', str(out.get('summary_line', '')))
        self.assertNotIn('diagnostics_state', '\n'.join(out.get('why_lines') or []))
        self.assertIn('layer1_readiness', out)

    def test_resolve_layer1_not_applied_when_dat_qa_full_block_wins(self):
        from MediCafe import cloud_readiness as mcr
        from MediCafe import cloud_readiness_recommendations as crr

        qa_candidate = {
            'recommended_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': ['qa full block'],
        }
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            diag = {
                'last_discovery_ok': True,
                'last_phase_b_run_id': 'b1',
                'last_manifest_sha256': 'm',
                'last_ingest_manifest_sha256': 'm',
                'last_phase_c_ok': False,
                'last_phase_c_error_code': 'PHASE_C_DB_WRITE_ERROR',
            }
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump(diag, f)
            with open(os.path.join(reports, 'artifact_discovery_summary_b1.json'), 'w', encoding='utf-8') as f:
                json.dump({'run_id': 'b1', 'counts_by_class': {'dat': 1}}, f)
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': 'x',
                'nearest_complete_run_id': '',
                'phase_rows': [],
                'diagnostics_state': diag,
            }
            with patch.object(mcr, 'resolve_lab_root', return_value=lab):
                with patch.object(mcr, '_build_historical_phase_d_reprocess_recommendation', return_value=(None, '')):
                    with patch.object(mcr, '_build_phase_d_dat_smoke_recommendation', return_value=(None, '')):
                        with patch.object(
                                mcr, '_build_phase_d_dat_qa_full_block_recommendation', return_value=(qa_candidate, '')):
                            with patch.object(mcr, '_qa_drop_spike_reply_context', return_value={}):
                                out = crr.compute_operator_support_send_recommendation_core(
                                    repo,
                                    snapshot,
                                    True,
                                    '',
                                    False,
                                )
        self.assertEqual(out.get('recommended_action_kind'), 'review_dat_qa_full_block')

    def test_resolve_layer1_when_phase_d_zero_and_bundle_not_send_current_run(self):
        """Phase D zero selection with DAT discovered still steers operator when bundle is not send_current_run."""
        from MediCafe import cloud_readiness as mcr
        from MediCafe import cloud_readiness_recommendations as crr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'run-dz-1'
            diag = {
                'last_discovery_ok': True,
                'last_phase_b_run_id': 'b1',
                'last_manifest_sha256': 'm',
                'last_ingest_manifest_sha256': 'm',
                'last_phase_c_ok': True,
                'last_shadow_pipeline_run_id': rid,
            }
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump(diag, f)
            with open(os.path.join(reports, 'artifact_discovery_summary_b1.json'), 'w', encoding='utf-8') as f:
                json.dump(
                    {'run_id': 'b1', 'counts_by_class': {'dat': 4}, 'dat_telemetry': {'dat_manifest_rows_count': 4}},
                    f,
                )
            with open(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                json.dump({'run_id': rid, 'rows_selected': 0}, f)
            snapshot = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': rid,
                'nearest_complete_run_id': '',
                'phase_rows': [],
                'diagnostics_state': diag,
            }
            with patch.object(mcr, 'resolve_lab_root', return_value=lab):
                with patch.object(mcr, '_artifact_bundle_quality', return_value={
                    'recommendation': 'review_lab_state',
                    'score': 40,
                    'label': 'LOW',
                }):
                    with patch.object(mcr, '_build_historical_phase_d_reprocess_recommendation', return_value=(None, '')):
                        with patch.object(mcr, '_build_phase_d_dat_smoke_recommendation', return_value=(None, '')):
                            with patch.object(mcr, '_build_phase_d_dat_qa_full_block_recommendation', return_value=(None, '')):
                                with patch.object(mcr, '_qa_drop_spike_reply_context', return_value={}):
                                    out = crr.compute_operator_support_send_recommendation_core(
                                        repo,
                                        snapshot,
                                        True,
                                        '',
                                        False,
                                    )
        self.assertEqual(out.get('recommended_action_kind'), 'resolve_layer1_upstream_blocker')
        self.assertEqual(out.get('recommended_report_kind'), 'system_health_pack')

    def test_review_dat_qa_forced_attachment_paths_scoped_to_lab_reports(self):
        from MediCafe import cloud_readiness_recommendations as crr

        lab_root, reports_dir = _make_lab()
        self.addCleanup(lambda: shutil.rmtree(lab_root, ignore_errors=True))
        inside = os.path.join(reports_dir, 'qa_reject_samples_test.jsonl')
        with open(inside, 'w', encoding='utf-8') as f:
            f.write('{}\n')
        outside = os.path.join(lab_root, 'outside_reports.txt')
        with open(outside, 'w', encoding='utf-8') as f:
            f.write('x')
        rec = {
            'action_preview': {
                'qa_reject_samples_path': inside,
                'phase_d_summary_path': outside,
            },
        }
        paths = crr._review_dat_qa_full_block_forced_attachment_paths(rec, lab_root)
        self.assertEqual(paths, [inside])
        self.assertEqual(crr._review_dat_qa_full_block_forced_attachment_paths(rec, None), [])
        self.assertEqual(crr._review_dat_qa_full_block_forced_attachment_paths(rec, ''), [])


class TestInteractiveReauthPolicy(unittest.TestCase):
    def test_allow_interactive_reauth_for_explicit_operator_send(self):
        from MediCafe import cloud_readiness_recommendations as crr

        self.assertTrue(
            crr._allow_interactive_reauth_for_send(
                send_source='manual_system_health_pack',
                operator_execution_mode='explicit_send_menu',
            )
        )

    def test_allow_interactive_reauth_for_background_and_autofollow_sends(self):
        from MediCafe import cloud_readiness_recommendations as crr

        self.assertFalse(
            crr._allow_interactive_reauth_for_send(
                send_source='background_support_send_job',
                operator_execution_mode='background_queue',
            )
        )
        self.assertFalse(
            crr._allow_interactive_reauth_for_send(
                send_source='post_update_cloud_autofollow',
                operator_execution_mode='post_update_autofollow',
            )
        )

