"""Static contract checks for the GAS/local MediLink Gmail handoff.

These checks cover Apps Script and HTML assets that are difficult to execute in
the Python test runner, but still need regression coverage for the handoff
protocol.
"""
from __future__ import absolute_import

import os


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read_repo_file(*parts):
    path = os.path.join(PROJECT_ROOT, *parts)
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def test_gas_direct_fallback_actions_are_available_and_clear_stale_results():
    main_js = _read_repo_file("MediLink", "main.js")

    assert "const ACTION_GET_DOCX_RESULTS = 'get_docx_results';" in main_js
    assert "case ACTION_GET_DOCX_RESULTS:" in main_js
    assert "function handleGetDocxResults(payload)" in main_js
    assert "function storeDownloadedEmailsForTransfer(downloadedEmails, telemetry, reason)" in main_js
    assert "deleteProperty('docxResult')" in main_js
    assert "return handleProcessDocx(payload);" in main_js


def test_browser_failure_telemetry_preserves_fetch_error_context_for_gas_logs():
    webapp_html = _read_repo_file("MediLink", "webapp.html")
    main_js = _read_repo_file("MediLink", "main.js")

    assert "failurePayload.downloadFailure = {" in webapp_html
    assert "stage: 'webapp_download_fetch_failed'" in webapp_html
    assert "failurePayload.downloadSuccess = false;" in webapp_html
    assert "downloadFailure: failureSource ? {" in main_js
    assert "errorMessage: String(failureSource.errorMessage || '')" in main_js


def test_transfer_status_rpc_and_post_action_wired():
    main_js = _read_repo_file("MediLink", "main.js")
    assert "const ACTION_GET_TRANSFER_STATUS = 'get_transfer_status';" in main_js
    assert "const TERMINAL_TRANSFER_OUTCOME_PARTIAL_DOWNLOAD_FAILED = 'partial_download_failed';" in main_js
    assert "const TERMINAL_TRANSFER_OUTCOME_PARTIAL_FAILURE = 'partial_failure';" in main_js
    assert "function get_transfer_status(expectedTransferRunId)" in main_js
    assert "action === ACTION_GET_TRANSFER_STATUS" in main_js
    assert "expectedTransferRunId" in main_js
    assert "function normalizeTransferFilesList(rawFiles)" in main_js
    assert "function normalizeTerminalTransferOutcome(rawOutcome)" in main_js
    assert "files: normalizeTransferFilesList(tel.files || [])" in main_js
    assert "files: normalizeTransferFilesList(raw.files)" in main_js


def test_partial_download_failed_status_is_terminal_not_safe_to_close():
    main_js = _read_repo_file("MediLink", "main.js")
    webapp_html = _read_repo_file("MediLink", "webapp.html")

    assert "terminalTransferOutcome: normalizeTerminalTransferOutcome(raw.terminalTransferOutcome)" in main_js
    assert "terminalTransferOutcome: normalizeTerminalTransferOutcome(tel.terminalTransferOutcome)" in main_js
    assert "partial_download_failed" in main_js
    assert "partial_failure" in main_js

    assert "function isPartialTransferFailureOutcome(term, stage)" in webapp_html
    assert "t === 'partial_download_failed' || t === 'partial_failure'" in webapp_html
    assert "Partial download failed: some files did not download. See Details before closing." in webapp_html
    assert "Partial download failed. Keep MediCafe open and review the launcher." in webapp_html
    assert "data.status === 'partial_failure'" in webapp_html
    assert "download-partial-failure" in webapp_html
    assert "setBannerPartialDownloadFailed()" in webapp_html
    assert "nextStatusPollMs = 5000;" in webapp_html
    assert "isPartialTransferFailureOutcome(term, dd.stage)" in webapp_html

    partial_idx = webapp_html.find("if (partialFailure)")
    assert partial_idx != -1
    success_idx = webapp_html.find("term === 'success'", partial_idx)
    assert success_idx != -1
    partial_chunk = webapp_html[partial_idx:success_idx]
    assert "SAFE_TO_CLOSE = false;" in partial_chunk


def test_webapp_polls_gas_transfer_status_and_hides_default_cert_messaging():
    webapp_html = _read_repo_file("MediLink", "webapp.html")
    assert "startGasTransferStatusPolling();" in webapp_html
    assert ".get_transfer_status(runArg);" in webapp_html
    assert "MediLink Transfer" in webapp_html
    assert "Progress above uses Google only" in webapp_html
    assert "loadDocxResultsReadOnly" in webapp_html
    assert "get_docx_results only" in webapp_html
    assert "View certificate" in webapp_html
    assert "runConnectivityDiagnostics" in webapp_html
    assert "syncManualHandoffBtnVisibility" in webapp_html
    assert "transferFileReceipt" in webapp_html
    assert "Type HANDOFF to confirm" in webapp_html
    assert "schedule-ro-filename" in webapp_html
    assert "term === 'handoff_timeout'" in webapp_html
    assert "Files found by GAS" in webapp_html
    assert "formatTransferFileSummaryLine" in webapp_html
    assert "waiting_for_gas" in webapp_html
    assert "return parts.join(' | ');" in webapp_html
    idx = webapp_html.find("function formatTransferFileSummaryLine")
    assert idx != -1
    end = webapp_html.find("function renderTransferFileReceipt", idx)
    assert end != -1
    receipt_summary_chunk = webapp_html[idx:end]
    # Middle-dot join (U+00B7) mojibakes under some legacy encodings; receipt summary stays ASCII.
    assert "\u00b7" not in receipt_summary_chunk


def test_direct_gas_primary_python_branch_skips_browser_fallback_worker():
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    assert "def _publish_transfer_status_to_gas(" in gmail_py
    assert "'action': 'save_transfer_telemetry'" in gmail_py
    start = gmail_py.find("if primary_route == 'direct_gas':")
    assert start != -1
    end = gmail_py.find("_record_transfer_telemetry('python_launch_gas_webapp_browser_attempt'", start)
    assert end != -1
    chunk = gmail_py[start:end]
    assert "_start_browser_handoff_fallback" not in chunk


def test_direct_gas_handoff_emits_documented_stages():
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    for stage in (
        "python_direct_gas_process_docx_start",
        "python_direct_gas_links_received",
        "python_direct_gas_local_download_start",
        "python_direct_gas_local_download_progress",
        "python_direct_gas_local_download_complete",
        "python_direct_gas_cleanup_start",
        "python_direct_gas_success",
        "python_direct_gas_error",
        "python_handoff_timeout",
        "python_direct_gas_waiting_for_gas_results",
    ):
        assert "'{}'".format(stage) in gmail_py or '"{}"'.format(stage) in gmail_py


def test_direct_gas_process_docx_timeout_exceeds_local_idle_watchdog():
    """Pre-link GAS processing must outlive the local idle watchdog deferral path."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    assert "DIRECT_GAS_PROCESS_DOCX_TIMEOUT_SEC = AUTO_SHUTDOWN_SECONDS +" in gmail_py
    action_idx = gmail_py.find('"action": "process_docx"')
    assert action_idx != -1
    window = gmail_py[action_idx : action_idx + 800]
    assert "timeout=DIRECT_GAS_PROCESS_DOCX_TIMEOUT_SEC" in window
    assert "timeout=120" not in window


def test_maybe_warn_secure_idle_gates_shutdown_on_handoff_pending():
    """Auto-shutdown must only terminalize when handoff is pending; else defer or generic shutdown."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    start = gmail_py.find("if elapsed > AUTO_SHUTDOWN_SECONDS and not SAFE_TO_CLOSE:")
    assert start != -1
    end = gmail_py.find("return elapsed", start)
    assert end != -1
    chunk = gmail_py[start:end]
    assert "if _handoff_pending_without_downloads():" in chunk
    assert "shutdown_event.set()" in chunk
    assert chunk.find("if _handoff_pending_without_downloads():") < chunk.find("shutdown_event.set()")


def test_terminal_handoff_timeout_sets_terminal_and_publishes_before_submit():
    """GAS UI and support bundle must see terminal handoff_timeout before bundle is built."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    start = gmail_py.find("def _terminal_handoff_timeout")
    assert start != -1
    end = gmail_py.find("\ndef _connection_watchdog_loop", start)
    assert end != -1
    body = gmail_py[start:end]
    i_term = body.find("set_terminal_transfer_outcome('handoff_timeout')")
    i_pub = body.find("'python_handoff_timeout'")
    i_sub = body.find("_submit_transfer_failure_report")
    assert i_term != -1 and i_pub != -1 and i_sub != -1
    assert i_term < i_pub < i_sub


def test_warn_handoff_stall_does_not_publish_terminal_timeout_to_gas():
    """Cert-trust stall path must not call _terminal_handoff_timeout (no operator terminalization)."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    start = gmail_py.find("def _warn_handoff_stall")
    assert start != -1
    end = gmail_py.find("def _terminal_handoff_timeout", start)
    assert end != -1
    body = gmail_py[start:end]
    assert "_submit_transfer_failure_report" in body
    assert "set_terminal_transfer_outcome" not in body
    assert "python_handoff_timeout" not in body


def test_cert_warning_branch_calls_warn_handoff_stall_not_terminal():
    """120s HTTPS certificate warning must not invoke the terminal timeout helper."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    needle = "no_local_https_activity_after_certificate_warning"
    i = gmail_py.find(needle)
    assert i != -1
    chunk = gmail_py[max(0, i - 200) : i + len(needle) + 40]
    assert "_warn_handoff_stall" in chunk
    assert "_terminal_handoff_timeout" not in chunk


def test_warn_handoff_stall_submits_without_connection_loss_dedupe():
    """Stall warning must not consume the shared CONNECTION_LOSS_REPORTED gate."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    start = gmail_py.find("def _warn_handoff_stall")
    assert start != -1
    end = gmail_py.find("def _terminal_handoff_timeout", start)
    assert end != -1
    body = gmail_py[start:end]
    assert "consume_connection_loss_dedupe=False" in body


def test_handoff_pending_excludes_direct_gas_idle_before_links():
    """Regression anchor: direct_gas + idle + zero links is not handoff-pending (no false stall)."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    start = gmail_py.find("def _handoff_pending_without_downloads")
    assert start != -1
    end = gmail_py.find("\ndef _browser_handoff_fallback_active", start)
    assert end != -1
    body = gmail_py[start:end]
    assert "route == 'direct_gas'" in body
    assert "links_rx" in body
    assert "phase == 'idle'" in body


def test_auto_shutdown_calls_terminal_handoff_timeout_before_outcome_log():
    """Watchdog should push operator state (inside _terminal_handoff_timeout) before structured outcome log."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    anchor = "Auto-shutdown: handoff still pending"
    i_anchor = gmail_py.find(anchor)
    assert i_anchor != -1
    window = gmail_py[i_anchor : i_anchor + 800]
    i_term = window.find("_terminal_handoff_timeout")
    i_log = window.find("_log_transfer_outcome_summary('handoff_timeout'")
    assert i_term != -1 and i_log != -1
    assert i_term < i_log


def test_direct_gas_links_received_publish_follows_counts_and_transfer_files():
    """Operator telemetry must include links + prepared rows before links_received is posted."""
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    needle = "python_direct_gas_links_received"
    idx = gmail_py.find(needle)
    assert idx != -1
    prefix = gmail_py[:idx]
    assert "set_counts(links_received=links_count)" in prefix
    assert "_transfer_files_set_prepared_from_links(download_links)" in prefix
    i_counts = prefix.rfind("set_counts(links_received=links_count)")
    i_prep = prefix.rfind("_transfer_files_set_prepared_from_links(download_links)")
    assert i_counts != -1 and i_prep != -1
    assert i_counts < i_prep < idx


def test_local_helper_binds_loopback_and_requires_handoff_auth():
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    webapp_html = _read_repo_file("MediLink", "webapp.html")

    assert "SecureHTTPServer((SERVER_HOST, server_port)" in gmail_py
    assert "SecureHTTPServer(('0.0.0.0', server_port)" not in gmail_py
    assert "LOCAL_CONTROL_TOKEN = uuid.uuid4().hex" in gmail_py
    assert "_require_local_control_auth(self, '/download', data)" in gmail_py
    assert "def _is_same_origin_local_request(handler):" in gmail_py
    assert "if require_admin and _is_same_origin_local_request(handler):" in gmail_py
    assert "local_auth={}" in gmail_py
    assert "var LOCAL_CONTROL_TOKEN = '';" in webapp_html
    assert "localAuthToken: LOCAL_CONTROL_TOKEN" in webapp_html


def test_local_helper_uses_restricted_cors_not_wildcard_origin():
    gmail_py = _read_repo_file("MediLink", "MediLink_Gmail.py")
    route_handlers = _read_repo_file("MediLink", "gmail_route_handlers.py")
    http_utils = _read_repo_file("MediLink", "gmail_http_utils.py")

    assert "allowed_cors_origin_value" in gmail_py
    assert "Access-Control-Allow-Origin', '*'" not in gmail_py
    assert "Access-Control-Allow-Origin', '*'" not in route_handlers
    assert "allowed_cors_origin_value(origin)" in http_utils
