"""Unit tests for tools/repo_audit.py CLI exit semantics."""

import importlib.util
import os
import sys
import types


def _repo_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _load_repo_audit_cli_module():
    module_path = os.path.join(_repo_root(), "tools", "repo_audit.py")
    spec = importlib.util.spec_from_file_location("repo_audit_cli_under_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _install_fake_repo_audit_modules(monkeypatch, specs):
    pkg = types.ModuleType("repo_audit")
    pkg.__path__ = []

    registry = types.ModuleType("repo_audit._registry")
    registry.load_registered_checks = lambda: None
    registry.checks_for_tier = lambda tier, single_check=None: specs

    render = types.ModuleType("repo_audit._render")
    render.render_text = lambda results: "text"
    render.render_markdown = lambda results: "md"
    render.render_json = lambda results: "{}"

    monkeypatch.setitem(sys.modules, "repo_audit", pkg)
    monkeypatch.setitem(sys.modules, "repo_audit._registry", registry)
    monkeypatch.setitem(sys.modules, "repo_audit._render", render)


def _spec(status, blocking):
    result = types.SimpleNamespace(status=status)
    return types.SimpleNamespace(blocking=blocking, run=lambda res=result: res)


def test_repo_audit_exits_zero_when_only_non_blocking_checks_fail(monkeypatch):
    monkeypatch.delenv("REPO_AUDIT_STRICT", raising=False)
    _install_fake_repo_audit_modules(
        monkeypatch,
        [
            _spec("fail", blocking=False),
            _spec("warn", blocking=False),
        ],
    )
    module = _load_repo_audit_cli_module()

    code = module.main(["--tier", "fast", "--format", "json"])

    assert code == 0


def test_repo_audit_exits_one_when_any_blocking_check_fails(monkeypatch):
    monkeypatch.delenv("REPO_AUDIT_STRICT", raising=False)
    _install_fake_repo_audit_modules(
        monkeypatch,
        [
            _spec("fail", blocking=True),
            _spec("ok", blocking=False),
        ],
    )
    module = _load_repo_audit_cli_module()

    code = module.main(["--tier", "fast", "--format", "json"])

    assert code == 1


def test_repo_audit_strict_exits_one_when_any_warning_exists(monkeypatch):
    monkeypatch.delenv("REPO_AUDIT_STRICT", raising=False)
    _install_fake_repo_audit_modules(
        monkeypatch,
        [
            _spec("warn", blocking=False),
            _spec("ok", blocking=True),
        ],
    )
    module = _load_repo_audit_cli_module()

    code = module.main(["--tier", "fast", "--strict", "--format", "json"])

    assert code == 1
