import json
import os
import sys
try:
    import imp
except ImportError:
    imp = None


REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
SCRIPT_DIR = os.path.join(REPO_ROOT, "scripts", "unified_model")
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from workflow_boundary_contract import assert_workflow_boundary_clean

import run_x12_cpt_dx_association as assoc


def _meta(run_id="test-run", basename="claim.txt", sha="abc123"):
    return {
        "run_id": run_id,
        "source_file_basename": basename,
        "source_file_sha256_prefix": sha,
    }


def _apply_crosswalk_fixture():
    return {
        "procedure_to_diagnosis": {
            "00142": ["H25.11"],
            "00140": ["H40.11X2"],
        },
        "diagnosis_to_procedure": {
            "H25.11": "00142",
            "H40.11X2": "00140",
        },
        "service_line_input_state": {
            "pending_rows": ["do-not-touch"],
        },
        "billing_state": {
            "charges_entered": False,
        },
    }


def _valid_apply_proposal():
    return {
        "schema_version": assoc.CROSSWALK_PROPOSAL_SCHEMA_VERSION,
        "run_id": "apply-run",
        "workflow_boundary": "report_only_review_required",
        "claim_workflow_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
        "requires_apply_confirmation": True,
        "diagnosis_to_procedure_eligible": [
            {"diagnosis_code": "H25.12", "cpt_code": "00142"},
            {"diagnosis_code": "H43.01", "cpt_code": "00145"},
        ],
        "procedure_to_diagnosis_additions": {
            "00142": ["H25.12"],
            "00145": ["H43.01"],
        },
        "maintenance": {
            "baseline_pairs_without_observed_support": [
                {"cpt_code": "00140", "diagnosis_code": "H40.11X2"}
            ],
            "baseline_pairs_not_removed_by_policy": True,
        },
    }


def _assert_apply_report_config_lane(report):
    assert report["workflow_boundary"] == "confirmed_config_update"
    assert report["claim_workflow_completion"] is False
    assert report["mutates_billing_state"] is False
    assert report["mutates_dat"] is False
    assert report["mutates_837p"] is False
    assert report["charges_entered"] is False
    assert report["baseline_pairs_removed"] == 0


def test_current_generated_shape_uses_sv1_pointer_to_hi():
    text = (
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001*005010X222A1~"
        "CLM*123*100***11:B:1*Y*A*Y*Y~"
        "HI*ABK:H2511~"
        "LX*1~"
        "SV1*HC:00142:24*100*MJ*15***1~"
        "DTP*472*D8*20260101~"
        "SE*8*0001~"
    )

    parsed = assoc.parse_x12_cpt_dx_pairs(text, _meta())

    assert parsed["claims"] == 1
    assert parsed["service_lines"] == 1
    assert parsed["warning_counts"] == {}
    assert parsed["pairs"] == [{
        "schema_version": assoc.PAIR_SCHEMA_VERSION,
        "run_id": "test-run",
        "source_file_basename": "claim.txt",
        "source_file_sha256_prefix": "abc123",
        "cpt_code": "00142",
        "diagnosis_code": "H2511",
        "diagnosis_qualifier": "ABK",
        "diagnosis_pointer": "1",
        "association_basis": "sv1_pointer_to_hi",
        "confidence": assoc.CONFIDENCE_POINTER_RESOLVED,
        "warning_codes": [],
        "line_count_in_claim": 1,
    }]


def test_multiple_hi_valid_pointer_selects_pointed_diagnosis():
    text = (
        "ST*837*0001~"
        "HI*ABK:H2511*ABF:H4011X2~"
        "LX*1~"
        "SV1*HC:00140:24*100*MJ*15***2~"
        "SE*5*0001~"
    )

    parsed = assoc.parse_x12_cpt_dx_pairs(text, _meta())

    assert len(parsed["pairs"]) == 1
    assert parsed["pairs"][0]["cpt_code"] == "00140"
    assert parsed["pairs"][0]["diagnosis_code"] == "H4011X2"
    assert parsed["pairs"][0]["diagnosis_qualifier"] == "ABF"
    assert parsed["pairs"][0]["confidence"] == assoc.CONFIDENCE_POINTER_RESOLVED


def test_missing_pointer_with_one_diagnosis_is_unambiguous():
    text = "ST*837*0001~HI*ABK:H4301~LX*1~SV1*HC:00145:24*100*MJ*15~SE*5*0001~"

    parsed = assoc.parse_x12_cpt_dx_pairs(text, _meta())

    assert len(parsed["pairs"]) == 1
    assert parsed["pairs"][0]["diagnosis_code"] == "H4301"
    assert parsed["pairs"][0]["association_basis"] == "single_hi_single_or_unpointed_sv1"
    assert parsed["pairs"][0]["confidence"] == assoc.CONFIDENCE_SINGLE_UNAMBIGUOUS


def test_missing_pointer_with_multiple_diagnoses_emits_candidate_pairs():
    text = "ST*837*0001~HI*ABK:H2511*ABF:H2512~LX*1~SV1*HC:00142:24*100*MJ*15~SE*5*0001~"

    parsed = assoc.parse_x12_cpt_dx_pairs(text, _meta())

    assert len(parsed["pairs"]) == 2
    assert sorted([p["diagnosis_code"] for p in parsed["pairs"]]) == ["H2511", "H2512"]
    assert all(p["confidence"] == assoc.CONFIDENCE_AMBIGUOUS_CANDIDATE for p in parsed["pairs"])
    assert all(assoc.WARNING_MULTIPLE_DX_NO_POINTER in p["warning_codes"] for p in parsed["pairs"])


def test_malformed_hi_and_invalid_pointer_are_counted_without_fatal_error():
    malformed_hi = "ST*837*0001~HI*ABK~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~"
    invalid_pointer = "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*100*MJ*15***2~SE*5*0001~"

    parsed_malformed = assoc.parse_x12_cpt_dx_pairs(malformed_hi, _meta())
    parsed_invalid = assoc.parse_x12_cpt_dx_pairs(invalid_pointer, _meta())

    assert parsed_malformed["pairs"] == []
    assert parsed_malformed["warning_counts"][assoc.WARNING_MALFORMED_SEGMENT] >= 1
    assert parsed_malformed["warning_counts"][assoc.WARNING_MISSING_HI] >= 1
    assert parsed_invalid["pairs"] == []
    assert parsed_invalid["warning_counts"][assoc.WARNING_POINTER_OUT_OF_RANGE] == 1


def test_txt_file_with_x12_payload_is_scanned(tmp_path):
    claim_path = tmp_path / "generated_claim.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )
    noise_path = tmp_path / "notes.txt"
    noise_path.write_text("not a claim", encoding="utf-8")

    found = list(assoc.iter_candidate_x12_files([str(tmp_path)]))

    assert str(claim_path) in found
    assert str(noise_path) not in found


def test_report_probability_privacy_and_baseline_comparison(tmp_path):
    claim_path = tmp_path / "claim_payload.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~"
        "ST*837*0002~HI*ABK:H2512~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0002~"
        "ST*837*0003~HI*ABK:H4301~LX*1~SV1*HC:00145:24*100*MJ*15***1~SE*5*0003~",
        encoding="utf-8",
    )
    bad_path = tmp_path / "not_x12.txt"
    bad_path.write_text("plain notes", encoding="utf-8")
    crosswalk_path = tmp_path / "crosswalk.json"
    crosswalk_path.write_text(json.dumps({
        "procedure_to_diagnosis": {
            "00142": ["H25.11"],
            "00140": ["H40.11X2"],
        },
        "diagnosis_to_procedure": {}
    }), encoding="utf-8")
    lab_dir = tmp_path / "lab"
    claim_before = claim_path.read_text(encoding="utf-8")
    crosswalk_before = crosswalk_path.read_text(encoding="utf-8")

    summary, pairs, artifacts = assoc.run_analysis(
        [str(claim_path), str(bad_path)],
        str(lab_dir),
        str(crosswalk_path),
        run_id="fixed-run",
    )

    assert summary["files_scanned"] == 1
    assert summary["files_parsed"] == 1
    assert summary["files_rejected"] == 0
    assert summary["workflow_boundary"] == "report_only_review_required"
    assert summary["claim_workflow_completion"] is False
    assert summary["operational_charge_update"] is False
    assert summary["mutates_dat"] is False
    assert summary["mutates_837p"] is False
    assert summary["total_claims"] == 3
    assert summary["total_pairs"] == 3
    assert summary["cpt_to_diagnosis"]["00142"]["total_pairs"] == 2
    associations = summary["cpt_to_diagnosis"]["00142"]["associations"]
    assert {a["code"]: a["probability"] for a in associations} == {
        "H2511": 0.5,
        "H2512": 0.5,
    }
    assert summary["diagnosis_to_cpt"]["H4301"]["associations"][0]["code"] == "00145"
    assert summary["baseline_comparison"]["observed_cpt_not_in_baseline"] == ["00145"]
    assert {"cpt_code": "00142", "diagnosis_code": "H2512"} in summary["baseline_comparison"]["observed_pairs_missing_from_baseline"]
    assert {"cpt_code": "00140", "diagnosis_code": "H4011X2"} in summary["baseline_comparison"]["baseline_pairs_without_observed_support"]
    proposal = summary["crosswalk_proposal"]
    assert proposal["schema_version"] == assoc.CROSSWALK_PROPOSAL_SCHEMA_VERSION
    assert proposal["workflow_boundary"] == "report_only_review_required"
    assert proposal["claim_workflow_completion"] is False
    assert proposal["mutates_billing_state"] is False
    assert proposal["mutates_dat"] is False
    assert proposal["mutates_837p"] is False
    assert proposal["charges_entered"] is False
    assert proposal["requires_apply_confirmation"] is True
    assert proposal["diagnosis_to_procedure"]["H25.12"] == "00142"
    assert proposal["diagnosis_to_procedure"]["H43.01"] == "00145"
    assert proposal["procedure_to_diagnosis_additions"]["00142"] == ["H25.12"]
    assert proposal["procedure_to_diagnosis_additions"]["00145"] == ["H43.01"]
    assert proposal["apply_summary"]["eligible_diagnosis_to_procedure_count"] == 3
    assert proposal["apply_summary"]["eligible_procedure_to_diagnosis_pair_count"] == 2
    assert proposal["apply_summary"]["diagnosis_to_medisoft_bridge_missing_count"] == 3
    assert proposal["diagnosis_to_medisoft_bridge_completeness"]["workflow_boundary"] == "report_only_review_required"
    assert proposal["diagnosis_to_medisoft_bridge_completeness"]["mutates_837p"] is False
    assert proposal["diagnosis_to_medisoft_bridge_completeness"]["bridge_apply_policy"] == "report_only_not_auto_applied"
    assert claim_path.read_text(encoding="utf-8") == claim_before
    assert crosswalk_path.read_text(encoding="utf-8") == crosswalk_before

    pairs_text = (lab_dir / "reports" / "x12_cpt_dx_association_pairs_fixed-run.jsonl").read_text(encoding="utf-8")
    summary_text = (lab_dir / "reports" / "x12_cpt_dx_association_summary_fixed-run.json").read_text(encoding="utf-8")
    summary_txt_text = (lab_dir / "reports" / "x12_cpt_dx_association_summary_fixed-run.txt").read_text(encoding="utf-8")
    proposal_text = (lab_dir / "reports" / "x12_cpt_dx_crosswalk_proposal_fixed-run.json").read_text(encoding="utf-8")
    proposal_txt_text = (lab_dir / "reports" / "x12_cpt_dx_crosswalk_proposal_fixed-run.txt").read_text(encoding="utf-8")
    assert "patient_name" not in pairs_text
    assert "member_id" not in pairs_text
    assert "CLM01" not in pairs_text
    assert str(claim_path) not in pairs_text
    assert str(claim_path) not in summary_text
    assert str(claim_path) not in summary_txt_text
    assert str(claim_path) not in proposal_text
    assert "CPT/Diagnosis Retrospective Review" in summary_txt_text
    assert "Executive Summary" in summary_txt_text
    assert "Top CPT To Diagnosis Associations" in summary_txt_text
    assert "CPT    Diagnosis" in summary_txt_text
    assert "00142  H2511" in summary_txt_text
    assert "Top Diagnosis To CPT Associations" in summary_txt_text
    assert "Baseline Comparison" in summary_txt_text
    assert "Crosswalk Proposal" in summary_txt_text
    assert "Diagnosis-to-Medisoft bridge present: 0 | missing: 3" in summary_txt_text
    assert "Bridge Repair Guidance" in proposal_txt_text
    assert "unconfirmed" in proposal_txt_text
    assert "Privacy" in summary_txt_text
    assert len(pairs) == 3
    assert os.path.exists(artifacts["summary_json"])

    operator_lines = assoc.format_operator_summary_lines(summary, max_rows=2)
    operator_text = "\n".join(operator_lines)
    assert "CPT/Diagnosis Review Results" in operator_text
    assert "Files: 1 analyzed" in operator_text
    assert "Top CPT -> diagnosis links:" in operator_text
    assert "00142 -> H2511" in operator_text
    assert "Diagnosis-to-Medisoft bridge gaps: 3" in operator_text

    assert_workflow_boundary_clean(
        "x12_cpt_dx_report_only_review",
        {"analytics_run_id": "fixed-run"},
        [
            {
                "name": "saved_837p_inventory",
                "role": "evidence_source",
                "identity": {"analytics_run_id": "fixed-run"},
                "status": "completed",
                "classification": "note_present",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": os.path.basename(artifacts["summary_json"]),
                "role": "report_artifact",
                "identity": {"analytics_run_id": "fixed-run"},
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": os.path.basename(artifacts["proposal_json"]),
                "role": "report_artifact",
                "identity": {"analytics_run_id": "fixed-run"},
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
        ],
    )


def test_bridge_completeness_treats_full_icd_and_medisoft_shorthand_as_equivalent(tmp_path):
    claim_path = tmp_path / "claim_payload.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H25811~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~"
        "ST*837*0002~HI*ABK:H4301~LX*1~SV1*HC:00145:24*100*MJ*15***1~SE*5*0002~",
        encoding="utf-8",
    )
    crosswalk_path = tmp_path / "crosswalk.json"
    crosswalk_path.write_text(json.dumps({
        "diagnosis_to_medisoft": {
            "H25.811": "25811",
        },
        "procedure_to_diagnosis": {
            "00142": ["H25.811"],
        },
        "diagnosis_to_procedure": {
            "H25.811": "00142",
        },
    }), encoding="utf-8")

    summary, _pairs, _artifacts = assoc.run_analysis(
        [str(claim_path)],
        str(tmp_path / "lab"),
        str(crosswalk_path),
        run_id="bridge-run",
    )

    bridge = summary["crosswalk_proposal"]["diagnosis_to_medisoft_bridge_completeness"]
    by_dx = dict((row["diagnosis_code_normalized"], row) for row in bridge["rows"])

    assert bridge["bridge_present_count"] == 1
    assert bridge["bridge_missing_count"] == 1
    assert bridge["bridge_ambiguous_count"] == 0
    assert by_dx["H25811"]["bridge_status"] == "present"
    assert by_dx["H25811"]["diagnosis_to_medisoft_matches"][0]["medisoft_code_normalized"] == "25811"
    assert by_dx["H4301"]["bridge_status"] == "missing"
    assert by_dx["H4301"]["associated_cpt_codes"] == ["00145"]
    assert bridge["repair_guidance_rows"][0]["diagnosis_code"] == "H43.01"
    assert bridge["repair_guidance_rows"][0]["unconfirmed_medisoft_code"] == "4301"
    assert bridge["repair_guidance_rows"][0]["auto_apply"] is False
    assert bridge["repair_guidance_rows"][0]["suggestion_source"] == "legacy_heuristic_unconfirmed"


def test_bridge_completeness_reports_ambiguous_medisoft_reverse_lookup(tmp_path):
    claim_path = tmp_path / "claim_payload.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H25811~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )
    crosswalk_path = tmp_path / "crosswalk.json"
    crosswalk_path.write_text(json.dumps({
        "diagnosis_to_medisoft": {
            "H25.811": "25811",
            "H25.812": "25811",
        },
        "procedure_to_diagnosis": {},
        "diagnosis_to_procedure": {},
    }), encoding="utf-8")

    summary, _pairs, _artifacts = assoc.run_analysis(
        [str(claim_path)],
        str(tmp_path / "lab"),
        str(crosswalk_path),
        run_id="bridge-ambiguous-run",
    )

    bridge = summary["crosswalk_proposal"]["diagnosis_to_medisoft_bridge_completeness"]
    assert bridge["bridge_present_count"] == 1
    assert bridge["bridge_missing_count"] == 0
    assert bridge["bridge_ambiguous_count"] == 1
    assert bridge["rows"][0]["bridge_ambiguous"] is True
    assert bridge["rows"][0]["requires_crosswalk_review"] is True
    assert bridge["reverse_ambiguity_rows"][0]["medisoft_code_normalized"] == "25811"
    assert bridge["reverse_ambiguity_rows"][0]["diagnosis_code_normalized_values"] == ["H25811", "H25812"]


def test_submission_index_inventory_is_preferred_and_archive_scan_fills_legacy_gap(tmp_path):
    receipts = tmp_path / "claims"
    receipts.mkdir()
    output = tmp_path / "outbox"
    output.mkdir()

    indexed_claim = receipts / "sent_indexed.txt"
    indexed_claim.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )
    legacy_claim = output / "legacy_generated.txt"
    legacy_claim.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0002~HI*ABK:H4301~LX*1~SV1*HC:00145:24*100*MJ*15***1~SE*5*0002~",
        encoding="utf-8",
    )
    missing_name = "missing_sent_file.txt"
    index_rows = [
        {"record_type": "submission", "receipt_file": indexed_claim.name, "status": "submitted"},
        {"record_type": "submission", "receipt_file": missing_name, "status": "submitted"},
        {"record_type": "ack_event", "receipt_file": "ack_only.txt", "notes": "ack event"},
    ]
    with (receipts / "submission_index.jsonl").open("w", encoding="utf-8") as f:
        for row in index_rows:
            f.write(json.dumps(row))
            f.write("\n")
        f.write("{not-json}\n")

    summary, pairs, _artifacts = assoc.run_analysis(
        [str(receipts), str(output)],
        str(tmp_path / "lab"),
        "",
        run_id="inventory-run",
    )

    inventory = summary["file_inventory"]
    assert summary["files_scanned"] == 2
    assert summary["total_claims"] == 2
    assert summary["total_service_lines"] == 2
    assert summary["service_lines_with_association"] == 2
    assert summary["health_telemetry"]["processed_837p_file_count"] == 2
    assert summary["health_telemetry"]["claim_loop_count"] == 2
    assert summary["health_telemetry"]["service_line_count"] == 2
    assert inventory["submission_index_count"] == 1
    assert inventory["submission_index_submission_rows"] == 2
    assert inventory["submission_index_existing_receipt_files"] == 1
    assert inventory["submission_index_missing_receipt_files"] == 1
    assert inventory["submission_index_invalid_json_lines"] == 1
    assert inventory["unique_submission_index_files"] == 1
    assert inventory["unique_content_scan_files"] == 2
    assert sorted([p["cpt_code"] for p in pairs]) == ["00142", "00145"]


def test_submission_index_inventory_accepts_direct_index_path_and_uses_shared_helper(tmp_path, monkeypatch):
    receipts = tmp_path / "claims"
    receipts.mkdir()
    output = tmp_path / "outbox"
    output.mkdir()

    indexed_claim = receipts / "sent_indexed.txt"
    indexed_claim.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )
    legacy_claim = output / "legacy_generated.txt"
    legacy_claim.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0002~HI*ABK:H4301~LX*1~SV1*HC:00145:24*100*MJ*15***1~SE*5*0002~",
        encoding="utf-8",
    )
    index_path = receipts / "submission_index.jsonl"
    with index_path.open("w", encoding="utf-8") as f:
        f.write(json.dumps({"record_type": "submission", "receipt_file": indexed_claim.name}))
        f.write("\n")
        f.write(json.dumps({"record_type": "submission", "receipt_file": "missing_sent_file.txt"}))
        f.write("\n")
        f.write("{not-json}\n")

    original = assoc.x12c.build_x12_scan_inventory
    calls = []

    def recording_build_x12_scan_inventory(scan_roots):
        calls.append(list(scan_roots or []))
        return original(scan_roots)

    monkeypatch.setattr(assoc.x12c, "build_x12_scan_inventory", recording_build_x12_scan_inventory)

    summary, pairs, _artifacts = assoc.run_analysis(
        [str(index_path), str(output)],
        str(tmp_path / "lab"),
        "",
        run_id="inventory-direct-path-run",
    )

    assert calls == [[str(index_path), str(output)]]
    inventory = summary["file_inventory"]
    assert summary["files_scanned"] == 2
    assert summary["total_claims"] == 2
    assert summary["service_lines_with_association"] == 2
    assert inventory["submission_index_count"] == 1
    assert inventory["submission_index_existing_receipt_files"] == 1
    assert inventory["submission_index_missing_receipt_files"] == 1
    assert inventory["submission_index_invalid_json_lines"] == 1
    assert sorted([p["cpt_code"] for p in pairs]) == ["00142", "00145"]


def test_build_health_telemetry_preserves_cpt_dx_contract():
    healthy = assoc.build_health_telemetry({
        "files_scanned": 1,
        "files_parsed": 1,
        "total_claims": 1,
        "total_service_lines": 5,
        "service_lines_with_association": 5,
        "total_pairs": 5,
        "file_inventory": {},
    })
    assert healthy["trust_level"] == "high"
    assert healthy["trust_reasons"] == ["candidate_files_parsed_with_high_service_line_association"]
    assert healthy["service_lines_with_association"] == 5
    assert healthy["service_lines_without_association"] == 0
    assert healthy["service_line_association_rate"] == 1.0
    assert healthy["emitted_pair_count"] == 5

    low_signal = assoc.build_health_telemetry({
        "files_scanned": 1,
        "files_parsed": 0,
        "total_claims": 0,
        "total_service_lines": 0,
        "service_lines_with_association": 0,
        "total_pairs": 0,
        "file_inventory": {},
    })
    assert low_signal["trust_level"] == "low"
    assert "candidate_files_not_parseable" in low_signal["trust_reasons"]

    zero_lines = assoc.build_health_telemetry({
        "files_scanned": 1,
        "files_parsed": 1,
        "total_claims": 1,
        "total_service_lines": 0,
        "service_lines_with_association": 0,
        "total_pairs": 0,
        "file_inventory": {},
    })
    assert zero_lines["trust_level"] == "low"
    assert "no_service_lines_found" in zero_lines["trust_reasons"]

    degraded = assoc.build_health_telemetry({
        "files_scanned": 2,
        "files_parsed": 2,
        "total_claims": 2,
        "total_service_lines": 5,
        "service_lines_with_association": 3,
        "total_pairs": 3,
        "file_inventory": {
            "submission_index_missing_receipt_files": 1,
            "submission_index_invalid_json_lines": 1,
            "submission_index_existing_receipt_files": 1,
            "fallback_content_scan_candidates": 2,
        },
    })
    assert degraded["trust_level"] == "medium"
    assert "service_line_association_rate_below_80_percent" in degraded["trust_reasons"]
    assert "submission_index_references_missing_files" in degraded["trust_reasons"]
    assert "submission_index_has_invalid_json_lines" in degraded["trust_reasons"]
    assert degraded["service_lines_with_association"] == 3
    assert degraded["service_lines_without_association"] == 2
    assert degraded["emitted_pair_count"] == 3


def test_cpt_dx_script_loaded_by_path_still_runs_analysis(tmp_path):
    if imp is None:
        return
    module = imp.load_source(
        "_test_run_x12_cpt_dx_loaded_by_path",
        os.path.join(SCRIPT_DIR, "run_x12_cpt_dx_association.py"),
    )
    claim_path = tmp_path / "claim_payload.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )
    crosswalk_path = tmp_path / "crosswalk.json"
    crosswalk_path.write_text(json.dumps({
        "diagnosis_to_medisoft": {},
        "procedure_to_diagnosis": {},
        "diagnosis_to_procedure": {},
    }), encoding="utf-8")

    summary, pairs, artifacts = module.run_analysis(
        [str(claim_path)],
        str(tmp_path / "lab"),
        str(crosswalk_path),
        run_id="imp-run",
    )

    assert summary["files_scanned"] == 1
    assert summary["service_lines_with_association"] == 1
    assert len(pairs) == 1
    assert os.path.exists(artifacts["summary_json"])


def test_crosswalk_proposal_apply_merges_without_claim_workflow_completion():
    from MediCafe import cpt_dx_crosswalk_learning

    crosswalk = _apply_crosswalk_fixture()
    proposal = _valid_apply_proposal()
    proposal["diagnosis_to_medisoft_bridge_completeness"] = {
        "bridge_present_count": 1,
        "bridge_missing_count": 2,
        "missing_rows": [
            {"diagnosis_code": "H25.12", "associated_cpt_codes": ["00142"]},
            {"diagnosis_code": "H43.01", "associated_cpt_codes": ["00145"]},
        ],
    }

    merged, report = cpt_dx_crosswalk_learning.merge_crosswalk_with_proposal(crosswalk, proposal)

    _assert_apply_report_config_lane(report)
    assert report["changed"] is True
    assert report["diagnosis_to_procedure_added"] == 2
    assert report["procedure_to_diagnosis_added"] == 2
    assert report["diagnosis_to_medisoft_added"] == 0
    assert report["diagnosis_to_medisoft_bridge_present_count"] == 1
    assert report["diagnosis_to_medisoft_bridge_missing_count"] == 2
    assert report["diagnosis_to_medisoft_bridge_ambiguous_count"] == 0
    assert report["diagnosis_to_medisoft_bridge_not_auto_applied"] is True
    assert set(merged.keys()) == set(crosswalk.keys())
    assert "diagnosis_to_medisoft" not in merged
    assert merged["service_line_input_state"] == crosswalk["service_line_input_state"]
    assert merged["billing_state"] == crosswalk["billing_state"]
    assert merged["diagnosis_to_procedure"]["H25.12"] == "00142"
    assert merged["diagnosis_to_procedure"]["H43.01"] == "00145"
    assert merged["diagnosis_to_procedure"]["H40.11X2"] == "00140"
    assert "H25.12" in merged["procedure_to_diagnosis"]["00142"]
    assert "H43.01" in merged["procedure_to_diagnosis"]["00145"]
    assert merged["procedure_to_diagnosis"]["00140"] == ["H40.11X2"]
    assert crosswalk["procedure_to_diagnosis"]["00142"] == ["H25.11"]


def test_crosswalk_apply_rejects_invalid_boundary_without_changes():
    from MediCafe import cpt_dx_crosswalk_learning

    crosswalk = _apply_crosswalk_fixture()
    proposal = _valid_apply_proposal()
    proposal["workflow_boundary"] = "service_line_input_state"

    merged, report = cpt_dx_crosswalk_learning.merge_crosswalk_with_proposal(crosswalk, proposal)

    _assert_apply_report_config_lane(report)
    assert report["error"] == "invalid_proposal_workflow_boundary"
    assert report["changed"] is False
    assert merged == crosswalk


def test_crosswalk_apply_rejects_unconfirmed_proposal_without_changes():
    from MediCafe import cpt_dx_crosswalk_learning

    crosswalk = _apply_crosswalk_fixture()
    proposal = _valid_apply_proposal()
    proposal["requires_apply_confirmation"] = False

    merged, report = cpt_dx_crosswalk_learning.merge_crosswalk_with_proposal(crosswalk, proposal)

    _assert_apply_report_config_lane(report)
    assert report["error"] == "proposal_requires_apply_confirmation"
    assert report["changed"] is False
    assert merged == crosswalk


def test_crosswalk_apply_rejects_invalid_schema_without_changes():
    from MediCafe import cpt_dx_crosswalk_learning

    crosswalk = _apply_crosswalk_fixture()
    proposal = _valid_apply_proposal()
    proposal["schema_version"] = "not_cpt_dx_crosswalk_proposal"

    merged, report = cpt_dx_crosswalk_learning.merge_crosswalk_with_proposal(crosswalk, proposal)

    _assert_apply_report_config_lane(report)
    assert report["error"] == "invalid_proposal_schema"
    assert report["changed"] is False
    assert merged == crosswalk


def test_service_line_input_overlay_events_feed_crosswalk_proposals_review_only():
    state = {
        "events": [{
            "schema_version": "service_line_input_overlay_event.v1",
            "workflow_boundary": "preview_only_review_required",
            "claims_completion": False,
            "mutates_billing_state": False,
            "mutates_dat": False,
            "mutates_837p": False,
            "charges_entered": False,
            "service_line_input_session_id": "session-1",
            "target_identity": {
                "patient_id": "1",
                "dos": "01-20-2026",
            },
            "effective_after": {
                "diagnosis_code": "H25.811",
                "cpt_code": "00142",
            },
        }],
    }

    pairs = assoc.service_line_input_correction_pairs_from_state(state, run_id="analytics-run")
    proposal = assoc.build_crosswalk_proposal(
        "analytics-run",
        {"baseline_comparison": {}},
        pairs,
        {},
        {},
    )

    assert pairs[0]["association_basis"] == "service_line_input_operator_overlay"
    assert pairs[0]["diagnosis_code"] == "H25811"
    assert pairs[0]["cpt_code"] == "00142"
    assert pairs[0]["workflow_boundary"] == "report_only_review_required"
    assert pairs[0]["claim_workflow_completion"] is False
    assert pairs[0]["mutates_dat"] is False
    assert pairs[0]["mutates_837p"] is False
    assert pairs[0]["charges_entered"] is False
    assert proposal["workflow_boundary"] == "report_only_review_required"
    assert proposal["diagnosis_to_procedure"]["H25.811"] == "00142"
    assert proposal["apply_summary"]["service_line_input_correction_pair_count"] == 1
    assert proposal["breadcrumbs"]["service_line_input_operator_overlay_evidence"] is True
    assert proposal["requires_apply_confirmation"] is True


def test_crosswalk_apply_treats_h25811_and_h25_811_as_same_existing_key():
    from MediCafe import cpt_dx_crosswalk_learning

    crosswalk = {
        "procedure_to_diagnosis": {
            "00142": ["H25.811"],
        },
        "diagnosis_to_procedure": {
            "H25.811": "00142",
        },
    }
    proposal = _valid_apply_proposal()
    proposal["diagnosis_to_procedure_eligible"] = [
        {"diagnosis_code": "H25811", "cpt_code": "00142"},
    ]
    proposal["procedure_to_diagnosis_additions"] = {
        "00142": ["H25811"],
    }

    merged, report = cpt_dx_crosswalk_learning.merge_crosswalk_with_proposal(crosswalk, proposal)

    _assert_apply_report_config_lane(report)
    assert report["changed"] is False
    assert report["diagnosis_to_procedure_added"] == 0
    assert report["diagnosis_to_procedure_updated"] == 0
    assert report["procedure_to_diagnosis_added"] == 0
    assert merged["diagnosis_to_procedure"] == {"H25.811": "00142"}
    assert merged["procedure_to_diagnosis"] == {"00142": ["H25.811"]}


def test_email_flow_bundles_report_only_boundary_without_local_workflow_completion(tmp_path, monkeypatch):
    from MediCafe import error_reporter

    claims = tmp_path / "claims"
    claims.mkdir()
    outbox = tmp_path / "outbox"
    outbox.mkdir()
    claim_path = claims / "sent_claim.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*100*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )

    captured = {}

    def fake_runtime_context():
        return {
            "medi": {
                "local_claims_path": str(claims),
                "outputFilePath": str(outbox),
                "local_storage_path": str(tmp_path / "storage"),
            }
        }

    def fake_collect_support_bundle(include_traceback=True, extra_meta=None, extra_files=None, **kwargs):
        captured["include_traceback"] = include_traceback
        captured["extra_meta"] = dict(extra_meta or {})
        captured["extra_files"] = list(extra_files or [])
        return str(tmp_path / "medicafe_bundle_x12_cpt_dx_analytics.zip")

    def fake_submit_support_bundle_email(**kwargs):
        captured["submit_kwargs"] = dict(kwargs)
        return True

    monkeypatch.setenv("MEDICAFE_LAB_DIR", str(tmp_path / "lab"))
    crosswalk_path = tmp_path / "crosswalk.json"
    crosswalk_path.write_text(json.dumps({
        "procedure_to_diagnosis": {"00142": ["H2511"]},
        "diagnosis_to_procedure": {},
    }), encoding="utf-8")
    monkeypatch.setenv("MEDICAFE_CROSSWALK_FILE", str(crosswalk_path))
    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", fake_runtime_context)
    monkeypatch.setattr(error_reporter, "collect_support_bundle", fake_collect_support_bundle)
    monkeypatch.setattr(error_reporter, "submit_support_bundle_email", fake_submit_support_bundle_email)

    rc = error_reporter.email_x12_cpt_dx_analytics_flow()

    assert rc == 0
    meta = captured["extra_meta"]
    assert captured["include_traceback"] is False
    assert meta["bundle_kind"] == "x12_cpt_dx_analytics"
    assert meta["x12_cpt_dx_workflow_boundary"] == "report_only_review_required"
    assert meta["x12_cpt_dx_claim_workflow_completion"] is False
    assert meta["x12_cpt_dx_operational_charge_update"] is False
    assert meta["x12_cpt_dx_mutates_billing_state"] is False
    assert meta["x12_cpt_dx_mutates_dat"] is False
    assert meta["x12_cpt_dx_mutates_837p"] is False
    assert meta["x12_cpt_dx_charges_entered"] is False
    assert meta["x12_cpt_dx_files_scanned"] == 1
    assert meta["x12_cpt_dx_total_claims"] == 1
    assert meta["x12_cpt_dx_total_service_lines"] == 1
    assert meta["x12_cpt_dx_service_lines_with_association"] == 1
    assert meta["x12_cpt_dx_crosswalk_apply_available"] is True
    assert meta["x12_cpt_dx_crosswalk_requires_apply_confirmation"] is True
    assert meta["x12_cpt_dx_crosswalk_eligible_diagnosis_to_procedure_count"] == 1
    assert meta["x12_cpt_dx_crosswalk_eligible_procedure_to_diagnosis_pair_count"] == 0
    assert meta["x12_cpt_dx_diagnosis_to_medisoft_bridge_present_count"] == 0
    assert meta["x12_cpt_dx_diagnosis_to_medisoft_bridge_missing_count"] == 1
    assert meta["x12_cpt_dx_diagnosis_to_medisoft_bridge_ambiguous_count"] == 0
    assert meta["x12_cpt_dx_diagnosis_to_medisoft_bridge_policy"] == "report_only_not_auto_applied"
    assert captured["submit_kwargs"]["skip_interactive_reauth"] is True
    assert captured["submit_kwargs"]["include_traceback"] is False
    assert [name for name, _path in captured["extra_files"]] == [
        "x12_cpt_dx_association_summary.json",
        "x12_cpt_dx_association_summary.txt",
        "x12_cpt_dx_association_pairs.jsonl",
        "x12_cpt_dx_crosswalk_proposal.json",
        "x12_cpt_dx_crosswalk_proposal.txt",
    ]

    meta_text = json.dumps(meta, sort_keys=True)
    assert str(claims) not in meta_text
    assert str(outbox) not in meta_text
    assert str(claim_path) not in meta_text

    identity = {
        "analytics_run_id": meta["x12_cpt_dx_run_id"],
        "bundle_kind": "x12_cpt_dx_analytics",
    }
    assert_workflow_boundary_clean(
        "x12_cpt_dx_support_bundle_boundary",
        identity,
        [
            {
                "name": "analytics_report_generation",
                "role": "attempt",
                "identity": identity,
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "support_bundle_metadata",
                "role": "package",
                "identity": identity,
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "support_email_delivery",
                "role": "support_send",
                "identity": identity,
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
        ],
    )


def test_email_flow_code_one_writes_self_test_diagnostic_breadcrumb(tmp_path, monkeypatch):
    from MediCafe import error_reporter

    storage = tmp_path / "storage"
    captured = {}

    def fake_runtime_context():
        return {
            "config": {},
            "medi": {
                "local_storage_path": str(storage),
                "local_claims_path": "",
                "outputFilePath": "",
            },
            "diagnostics": {},
        }

    def fail_collect_support_bundle(**kwargs):
        raise AssertionError("bundle collection should not run without scan roots")

    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", fake_runtime_context)
    monkeypatch.setattr(error_reporter, "collect_support_bundle", fail_collect_support_bundle)

    rc = error_reporter.email_x12_cpt_dx_analytics_flow()

    assert rc == 1
    diag_path = storage / "reports" / "x12_cpt_dx_review_latest.json"
    assert diag_path.exists()
    diag = json.loads(diag_path.read_text(encoding="utf-8"))
    captured["diag_text"] = json.dumps(diag, sort_keys=True)
    assert diag["status"] == "failed"
    assert diag["stage"] == "resolve_scan_roots"
    assert diag["reason_code"] == "no_saved_claim_file_locations_configured"
    assert diag["exit_code"] == 1
    assert diag["workflow_boundary"] == "report_only_review_required"
    assert diag["claim_workflow_completion"] is False
    assert str(tmp_path) not in captured["diag_text"]


def test_self_test_bundle_attaches_latest_cpt_dx_failure_diagnostic(tmp_path, monkeypatch):
    from MediCafe import error_reporter

    storage = tmp_path / "storage"
    reports = storage / "reports"
    reports.mkdir(parents=True)
    diag_path = reports / "x12_cpt_dx_review_latest.json"
    diag_path.write_text(json.dumps({
        "schema_version": 1,
        "status": "failed",
        "stage": "resolve_scan_roots",
        "reason_code": "no_saved_claim_file_locations_configured",
    }), encoding="utf-8")

    captured = {}

    def fake_runtime_context():
        return {
            "config": {"MediLink_Config": {"local_storage_path": str(storage)}},
            "medi": {
                "local_storage_path": str(storage),
                "logging": {},
                "error_reporting": {"email": {}},
            },
            "diagnostics": {},
        }

    def fake_build_support_zip(zip_path, local_storage_path, max_log_lines, traceback_text,
                               include_winscp, meta, claim_failure_summary=None,
                               extra_files=None, **kwargs):
        captured["zip_path"] = zip_path
        captured["local_storage_path"] = local_storage_path
        captured["extra_files"] = list(extra_files or [])
        captured["meta"] = dict(meta or {})
        return True

    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", fake_runtime_context)
    monkeypatch.setattr(error_reporter, "_build_support_zip", fake_build_support_zip)

    zip_path = error_reporter.collect_test_support_bundle()

    assert zip_path == captured["zip_path"]
    names = [name for name, _value in captured["extra_files"]]
    assert "self_test_report.json" in names
    assert "x12_cpt_dx_review_latest.json" in names
    attached = dict(captured["extra_files"])["x12_cpt_dx_review_latest.json"]
    assert attached == str(diag_path)
    assert captured["meta"]["bundle_kind"] == "test"


def test_error_reporter_can_load_cpt_dx_script_by_file_path(tmp_path):
    from MediCafe import error_reporter

    script_path = tmp_path / "run_x12_cpt_dx_association.py"
    script_path.write_text(
        "def marker_for_path_load():\n"
        "    return 'loaded'\n",
        encoding="utf-8",
    )

    mod = error_reporter._load_x12_cpt_dx_script_from_path(
        "_test_x12_cpt_dx_path_load",
        str(script_path),
    )

    assert mod.marker_for_path_load() == "loaded"


def test_cpt_dx_review_command_is_reporting_boundary_not_local_claim_workflow():
    from MediCafe import launcher

    assert "send_cpt_dx_review" not in launcher._LOCAL_WORKFLOW_COMMANDS
    assert_workflow_boundary_clean(
        "x12_cpt_dx_launcher_reporting_boundary",
        {"command": "send_cpt_dx_review"},
        [
            {
                "name": "troubleshooting_menu_action",
                "role": "operator_request",
                "identity": {"command": "send_cpt_dx_review"},
                "status": "started",
                "classification": "in_flight",
                "terminal": False,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "medicafe_cli_reporting_command",
                "role": "subprocess",
                "identity": {"command": "send_cpt_dx_review"},
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
        ],
    )
