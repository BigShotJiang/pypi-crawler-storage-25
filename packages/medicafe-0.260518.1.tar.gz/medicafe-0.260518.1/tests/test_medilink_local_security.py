import os

import pytest

from MediLink.local_security import (
    allowed_cors_origin_value,
    resolve_safe_download_path,
    sanitize_download_filename,
)


@pytest.mark.parametrize(
    "name",
    [
        "Schedule_RO 2026-05-03 (A).docx",
        "SS 5-22-2024 WEDNESDAY DR AKER & DR JON.docx",
        "Women's Health & Wellness.csv",
        "O'Connor & Associates Clinic.txt",
    ],
)
def test_download_filename_allows_expected_flat_names(name, tmp_path):
    path = resolve_safe_download_path(str(tmp_path), name)

    assert path == os.path.join(str(tmp_path), name)


@pytest.mark.parametrize(
    "name",
    [
        "../evil.docx",
        "..\\evil.docx",
        r"C:\temp\evil.docx",
        ".hidden.docx",
        "evil.exe",
        "bad/name.docx",
        "bad:name.docx",
        "bad<script>.docx",
        'bad"name".docx',
        "bad|pipe.docx",
        "bad?query.docx",
        "bad*glob.docx",
        "report.docx:Zone.Identifier",
        " report.docx",
        "report.docx ",
        "report.docx.",
        "line\nbreak.docx",
        "delete\x7fchar.docx",
        "CON.docx",
        "prn.csv",
        "AUX.txt",
        "NUL.dat",
        "COM1.docx",
        "com9.csv",
        "LPT1.tsv",
        "lpt9.txt",
        "CONIN$.docx",
        "conout$.txt",
    ],
)
def test_download_filename_rejects_path_traversal_and_unsafe_names(name, tmp_path):
    with pytest.raises(ValueError):
        resolve_safe_download_path(str(tmp_path), name)


@pytest.mark.parametrize(
    "name",
    [
        "COM10.docx",
        "LPT10.csv",
        "clinic & billing's notes.dat",
    ],
)
def test_download_filename_allows_similar_non_reserved_names(name):
    assert sanitize_download_filename(name) == name


def test_sanitize_download_filename_rejects_nested_gas_supplied_name():
    with pytest.raises(ValueError):
        sanitize_download_filename("exports/clinic_schedule.docx")


@pytest.mark.parametrize(
    "origin",
    [
        "https://script.google.com",
        "https://script.googleusercontent.com",
        "https://127.0.0.1:8000",
        "http://localhost:8000",
    ],
)
def test_cors_origin_allowlist_permits_local_and_gas_origins(origin):
    assert allowed_cors_origin_value(origin) == origin


@pytest.mark.parametrize(
    "origin",
    [
        "",
        "null",
        "https://evil.example",
        "https://script.google.com.evil.example",
        "http://script.google.com",
    ],
)
def test_cors_origin_allowlist_rejects_untrusted_origins(origin):
    assert allowed_cors_origin_value(origin) is None
