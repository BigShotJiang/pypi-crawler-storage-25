import os


REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _read_repo_text(*parts):
    path = os.path.join(REPO_ROOT, *parts)
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def test_service_line_input_transition_doc_inventory_names_current_and_target_surfaces():
    doc = _read_repo_text("docs", "OPTION_A_SERVICE_LINE_INPUT_NAMING_TRANSITION.md")
    required_terms = [
        "Option A To Service Line Input Naming Transition",
        "service_line_input",
        "mixed compatibility state",
        "run_service_line_input_entry",
        "run_option_a_minutes_entry_preview",
        "run_option_a_multi_dos_minutes_preview",
        "build_option_a_preview_*",
        "persist_option_a_minutes_summary",
        ".option_a_minutes_status.json",
        "_service_line_input_*",
        "_option_a_preview_*",
        "calculate_service_line_amount_result",
        "calculate_option_a_charge_result",
        "preview_only_review_required",
        "workflow_name=service_line_input",
        "claims_completion=False",
        "mutates_billing_state=False",
        "same patient and same DOS",
        "Do not remove Option A runtime functions",
        "MediBot/MediBot_UI.py",
        "MediBot/MediBot.py",
        "MediCafe/charges_tool.py",
        "MediBot/MediBot_ServiceLineInput.py",
        "Current XP Bundle Evidence",
        "medicafe_bundle_test_20260515_074122",
        "Service Line Input charge-anchor Option H",
        "persisted row state",
        "across exit/reopen",
    ]

    for term in required_terms:
        assert term in doc


def test_current_option_a_compatibility_symbols_are_still_inventory_backed():
    medibot = _read_repo_text("MediBot", "MediBot.py")
    medibot_ui = _read_repo_text("MediBot", "MediBot_UI.py")
    charges_tool = _read_repo_text("MediCafe", "charges_tool.py")
    adapter = _read_repo_text("MediBot", "MediBot_OptionA_Charge.py")
    service_line_adapter = _read_repo_text("MediBot", "MediBot_ServiceLineInput.py")

    assert "OPTION_A_MINUTES_STATUS_FILENAME = '.option_a_minutes_status.json'" in medibot
    assert "SERVICE_LINE_INPUT_STATE_FILENAME = '.service_line_input_state.json'" in medibot
    assert "def run_service_line_input_multi_dos_entry" in medibot
    assert "def run_option_a_multi_dos_minutes_preview" in medibot
    assert "return run_service_line_input_multi_dos_entry(" in medibot
    assert "def persist_service_line_input_summary" in medibot
    assert "def persist_option_a_minutes_summary" in medibot
    assert "def build_service_line_input_dos_groups_from_docx_index" in medibot
    assert "def build_option_a_preview_dos_groups_from_docx_index" in medibot
    assert "def run_service_line_input_entry" in medibot_ui
    assert "def run_option_a_minutes_entry_preview" in medibot_ui
    assert "return run_service_line_input_entry(" in medibot_ui
    assert "def calculate_service_line_amount_result" in charges_tool
    assert "def calculate_option_a_charge_result" in charges_tool
    assert "return calculate_service_line_amount_result(context)" in charges_tool
    assert "MediBot_ServiceLineInput" in adapter
    assert "from MediCafe.charges_tool import calculate_service_line_amount_result" in service_line_adapter
    assert "def calculate_option_a_charge_result" in service_line_adapter


def test_transition_doc_tracks_partial_service_line_input_runtime_rename():
    doc = _read_repo_text("docs", "OPTION_A_SERVICE_LINE_INPUT_NAMING_TRANSITION.md")
    medibot = _read_repo_text("MediBot", "MediBot.py")
    medibot_ui = _read_repo_text("MediBot", "MediBot_UI.py")
    charges_tool = _read_repo_text("MediCafe", "charges_tool.py")

    assert "Neutral" in doc
    assert "def run_service_line_input_multi_dos_entry" in medibot
    assert "def run_service_line_input_entry" in medibot_ui
    assert "def run_option_a_minutes_entry_preview" in medibot_ui
    assert "_service_line_input_status" in medibot_ui
    assert "_option_a_preview_status" in medibot_ui
    assert "def calculate_service_line_input_charge_result" not in charges_tool
    assert "def calculate_service_line_amount_result" in charges_tool


def test_service_line_input_handoff_and_crosswalk_intake_docs_are_inventory_backed():
    architecture_readme = _read_repo_text("docs", "architecture", "README.md")
    layered_doc = _read_repo_text("docs", "architecture", "SERVICE_LINE_INPUT_LAYERED_ARCHITECTURE.md")
    handoff_doc = _read_repo_text("docs", "architecture", "SERVICE_LINE_INPUT_BILLING_CUSTODY_HANDOFF_PLAN.md")
    crosswalk_utils = _read_repo_text("MediBot", "MediBot_Crosswalk_Utils.py")

    assert "SERVICE_LINE_INPUT_BILLING_CUSTODY_HANDOFF_PLAN.md" in architecture_readme
    assert "narrow Service Line Input crosswalk-intake save wrapper" in layered_doc
    assert "Handoff Gates" in handoff_doc
    assert "charges_entered" in handoff_doc
    assert "def save_service_line_input_crosswalk_intake_patch" in crosswalk_utils
    assert "save_crosswalk(None, config if isinstance(config, dict) else {}, merged, skip_api_operations=True)" not in _read_repo_text("MediBot", "MediBot.py")
