import os
import shutil
import subprocess
import zipfile

import pytest


def _powershell_exe():
    exe = shutil.which("powershell.exe") or shutil.which("pwsh")
    if not exe:
        pytest.skip("PowerShell is not available")
    return exe


def _run_refresh(script_path, repo_root, downloads_dir):
    env = os.environ.copy()
    env["MEDICAFE_REPO_ROOT"] = str(repo_root)
    proc = subprocess.run(
        [
            _powershell_exe(),
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script_path),
            "-RefreshOnly",
            "-DownloadsDir",
            str(downloads_dir),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        env=env,
        timeout=60,
    )
    return proc


def _write_zip(path, arcname, content):
    with zipfile.ZipFile(str(path), "w") as archive:
        archive.writestr(arcname, content)


def test_refresh_skips_invalid_cohort_zip_without_counting_or_deleting_it(tmp_path):
    repo_root = tmp_path / "repo"
    target_dir = repo_root / "input" / "test" / "test"
    downloads_dir = tmp_path / "downloads"
    target_dir.mkdir(parents=True)
    downloads_dir.mkdir()

    valid_zip = downloads_dir / "medicafe_bundle_system_health_pack_20260514_valid.zip"
    invalid_zip = downloads_dir / "medicafe_bundle_system_health_pack_20260514_invalid.zip"
    _write_zip(valid_zip, "manifest.txt", "valid bundle payload")
    invalid_zip.write_text("not a zip")
    now = None
    os.utime(str(valid_zip), now)
    os.utime(str(invalid_zip), now)

    script_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "scripts", "local_refresh_test_input.ps1")
    )
    proc = _run_refresh(script_path, repo_root, downloads_dir)

    assert proc.returncode == 0, proc.stdout
    assert "Skipping invalid medicafe_bundle cohort ZIP" in proc.stdout
    assert "Done: 1 bundle(s) from cohort" in proc.stdout
    assert not valid_zip.exists()
    assert invalid_zip.exists()
    assert (target_dir / "medicafe_bundle_system_health_pack_20260514_valid" / "manifest.txt").exists()


def test_refresh_preserves_existing_input_when_all_cohort_zips_are_invalid(tmp_path):
    repo_root = tmp_path / "repo"
    target_dir = repo_root / "input" / "test" / "test"
    downloads_dir = tmp_path / "downloads"
    target_dir.mkdir(parents=True)
    downloads_dir.mkdir()

    marker = target_dir / "keep.txt"
    marker.write_text("existing input")
    invalid_zip = downloads_dir / "medicafe_bundle_system_health_pack_20260514_invalid_only.zip"
    invalid_zip.write_text("not a zip")

    script_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "scripts", "local_refresh_test_input.ps1")
    )
    proc = _run_refresh(script_path, repo_root, downloads_dir)

    assert proc.returncode == 0, proc.stdout
    assert "Skipping invalid medicafe_bundle cohort ZIP" in proc.stdout
    assert "No valid matching .zip files" in proc.stdout
    assert marker.read_text() == "existing input"
    assert invalid_zip.exists()
