#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Run a diagnostic command and record its attempt lifecycle.

XP-compatible: Python 3.4+, stdlib only.  The expected
MediCafe.diagnostic_attempts API is:

    begin_attempt(lab_root=..., diagnostic_kind=..., attempt_id=...)
    mark_spawned(lab_root=..., diagnostic_kind=..., attempt_id=...)
    finish_attempt(lab_root=..., attempt_id=..., returncode=...,
                   stdout_tail=..., stderr_tail=...)
    fail_attempt(lab_root=..., attempt_id=..., returncode=...,
                 stdout_tail=..., stderr_tail=..., error=...)
    attempt_path(lab_root, attempt_id)

The calls are best-effort so this wrapper can run before that module is
present in older deployments.
"""
from __future__ import print_function

import argparse
import os
import subprocess
import sys
import tempfile
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
try:
    from MediCafe import cloud_work_shutdown
except Exception:
    cloud_work_shutdown = None

TAIL_BYTES = 32768
OPERATOR_SHUTDOWN_REQUESTED = "OPERATOR_SHUTDOWN_REQUESTED"
_CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME = "cloud_work_shutdown_request.json"


def _decode_tail(data, limit):
    if data is None:
        return ""
    if not isinstance(data, bytes):
        data = str(data).encode("utf-8", "replace")
    if len(data) > limit:
        data = data[-limit:]
    try:
        return data.decode("utf-8", "replace")
    except Exception:
        return str(data)


def _read_file_tail(handle, limit):
    try:
        handle.flush()
    except Exception:
        pass
    try:
        handle.seek(0, os.SEEK_END)
        size = handle.tell()
        start = 0
        if size > limit:
            start = size - limit
        handle.seek(start, os.SEEK_SET)
        return handle.read()
    except Exception:
        return b""


def _load_attempts_module():
    try:
        from MediCafe import diagnostic_attempts
        return diagnostic_attempts
    except Exception:
        return None


def _call_best_effort(fn, kwargs):
    if fn is None:
        return None
    try:
        return fn(**kwargs)
    except TypeError:
        # Keep compatibility with a simpler positional implementation if the
        # sibling worker lands that shape first.
        try:
            name = getattr(fn, "__name__", "")
            if name == "attempt_path":
                return fn(kwargs.get("lab_root"), kwargs.get("attempt_id"))
            if name == "mark_spawned":
                return fn(kwargs.get("lab_root"), kwargs.get("attempt_id"), kwargs.get("pid"))
            if name in ("finish_attempt", "fail_attempt"):
                return fn(kwargs.get("lab_root"), kwargs.get("attempt_id"), kwargs)
            if name == "begin_attempt":
                return fn(kwargs.get("lab_root"), kwargs.get("attempt_id"), kwargs)
        except Exception:
            return None
    except Exception:
        return None
    return None


def _iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _cloud_work_shutdown_request_path(lab_root):
    if cloud_work_shutdown is not None:
        return cloud_work_shutdown.request_path(lab_root)
    return os.path.join(lab_root, "reports", _CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME)


def _read_cloud_work_shutdown_request(lab_root):
    if cloud_work_shutdown is not None:
        return cloud_work_shutdown.read_request(lab_root)
    path = _cloud_work_shutdown_request_path(lab_root)
    try:
        if not os.path.isfile(path):
            return {}
        import json
        with open(path, "r") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except Exception:
        return {}
    return {}


def _write_cloud_work_shutdown_request(lab_root, payload):
    if cloud_work_shutdown is not None:
        cloud_work_shutdown.write_request(lab_root, payload)
        return
    path = _cloud_work_shutdown_request_path(lab_root)
    data = payload if isinstance(payload, dict) else {}
    try:
        reports_dir = os.path.dirname(path)
        if reports_dir and not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
        tmp_path = path + ".tmp"
        import json
        with open(tmp_path, "w") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
            handle.write("\n")
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass
        os.rename(tmp_path, path)
    except Exception:
        pass


def _operator_shutdown_requested(lab_root):
    if cloud_work_shutdown is not None:
        return cloud_work_shutdown.active_request(lab_root)
    req = _read_cloud_work_shutdown_request(lab_root)
    status = str(req.get("status") or "").strip()
    if status in ("requested", "running", "acknowledged"):
        return req
    return {}


def _mark_operator_shutdown_observed(lab_root, attempt_id, diagnostic_kind, request):
    if cloud_work_shutdown is not None:
        cloud_work_shutdown.mark_request_stopped(
            lab_root,
            request,
            {
                "stopped_diagnostic_attempt_id": str(attempt_id or ""),
                "stopped_diagnostic_kind": str(diagnostic_kind or ""),
            },
        )
        return
    req = dict(request if isinstance(request, dict) else {})
    req["status"] = "stopped"
    req["stopped_at_utc"] = _iso_utc_now()
    req["stopped_diagnostic_attempt_id"] = str(attempt_id or "")
    req["stopped_diagnostic_kind"] = str(diagnostic_kind or "")
    req["stop_reason"] = OPERATOR_SHUTDOWN_REQUESTED
    _write_cloud_work_shutdown_request(lab_root, req)


def _command_script_path(command):
    for item in command or []:
        text = str(item or "")
        if text.lower().endswith(".py"):
            return text
    if command:
        return str(command[0] or "")
    return ""


def _attempt_path(attempts, lab_root, diagnostic_kind, attempt_id):
    if attempts is None or not hasattr(attempts, "attempt_path"):
        return ""
    value = _call_best_effort(
        attempts.attempt_path,
        {"lab_root": lab_root, "diagnostic_kind": diagnostic_kind, "attempt_id": attempt_id},
    )
    return str(value or "")


def _begin_attempt(attempts, lab_root, attempt_id, diagnostic_kind, target_anchor_run_id,
                   target_context_run_id, issue_code):
    if attempts is None or not hasattr(attempts, "begin_attempt"):
        return
    _call_best_effort(
        attempts.begin_attempt,
        {
            "lab_root": lab_root,
            "diagnostic_kind": diagnostic_kind,
            "attempt_id": attempt_id,
            "target_anchor_run_id": target_anchor_run_id,
            "target_context_run_id": target_context_run_id,
            "issue_code": issue_code,
            "now_utc": _iso_utc_now(),
        },
    )


def _mark_spawned(attempts, lab_root, diagnostic_kind, attempt_id, pid, script_path, cwd):
    if attempts is None or not hasattr(attempts, "mark_spawned"):
        return
    _call_best_effort(
        attempts.mark_spawned,
        {
            "lab_root": lab_root,
            "diagnostic_kind": diagnostic_kind,
            "attempt_id": attempt_id,
            "child_pid": pid,
            "script_path": script_path,
            "cwd": cwd,
        },
    )


def _finish_attempt(attempts, lab_root, diagnostic_kind, attempt_id, returncode, stdout_tail, stderr_tail):
    if attempts is None:
        return
    kwargs = {
        "lab_root": lab_root,
        "diagnostic_kind": diagnostic_kind,
        "attempt_id": attempt_id,
        "returncode": returncode,
        "stdout_tail": stdout_tail,
        "stderr_tail": stderr_tail,
        "finished_at_utc": _iso_utc_now(),
    }
    if returncode == 0 and hasattr(attempts, "finish_attempt"):
        _call_best_effort(attempts.finish_attempt, kwargs)
    elif hasattr(attempts, "fail_attempt"):
        kwargs["domain_status"] = "child_returncode_{0}".format(returncode)
        kwargs["domain_detail"] = "tracked diagnostic child exited with returncode {0}".format(returncode)
        _call_best_effort(attempts.fail_attempt, kwargs)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run tracked diagnostic command")
    parser.add_argument("--lab-dir", default="", help="Lab root for attempt records")
    parser.add_argument("--kind", default="diagnostic", help="Diagnostic kind")
    parser.add_argument("--attempt-id", default="", help="Stable attempt id")
    parser.add_argument("--target-anchor-run-id", default="", help="Anchor run id for scoped attempt")
    parser.add_argument("--target-context-run-id", default="", help="Context run id for scoped attempt")
    parser.add_argument("--issue-code", default="", help="Remediation or diagnostic issue code")
    parser.add_argument("--cwd", default="", help="Child working directory")
    parser.add_argument("--tail-bytes", default=str(TAIL_BYTES), help="Captured tail byte limit")
    parser.add_argument("--echo-child-output", action="store_true", help="Echo captured child output after completion")
    parser.add_argument("command", nargs=argparse.REMAINDER, help="Command after --")
    args = parser.parse_args(argv)

    command = list(args.command or [])
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        print("run_tracked_diagnostic.py requires a child command after --", file=sys.stderr)
        return 2

    try:
        tail_bytes = int(args.tail_bytes)
    except Exception:
        tail_bytes = TAIL_BYTES
    if tail_bytes < 1024:
        tail_bytes = 1024

    lab_root = os.path.abspath(args.lab_dir) if args.lab_dir else ""
    cwd = os.path.abspath(args.cwd) if args.cwd else None
    attempt_id = str(args.attempt_id or "").strip()
    if not attempt_id:
        attempt_id = "{0}:{1}".format(str(args.kind or "diagnostic"), int(time.time()))

    attempts = _load_attempts_module()
    _begin_attempt(
        attempts,
        lab_root,
        attempt_id,
        args.kind,
        args.target_anchor_run_id,
        args.target_context_run_id,
        args.issue_code,
    )
    path = _attempt_path(attempts, lab_root, args.kind, attempt_id)
    shutdown_request = _operator_shutdown_requested(lab_root)
    if shutdown_request:
        _mark_operator_shutdown_observed(lab_root, attempt_id, args.kind, shutdown_request)
        if attempts is not None and hasattr(attempts, "fail_attempt"):
            _call_best_effort(
                attempts.fail_attempt,
                {
                    "lab_root": lab_root,
                    "diagnostic_kind": args.kind,
                    "attempt_id": attempt_id,
                    "returncode": 1,
                    "stdout_tail": "",
                    "stderr_tail": "",
                    "domain_status": "operator_shutdown_requested",
                    "domain_detail": "Operator requested safe Cloud shutdown before diagnostic launch.",
                    "finished_at_utc": _iso_utc_now(),
                },
            )
        return 1

    proc = None
    stdout_handle = None
    stderr_handle = None
    stdout_tail = ""
    stderr_tail = ""
    try:
        stdout_handle = tempfile.TemporaryFile()
        stderr_handle = tempfile.TemporaryFile()
        proc = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=stdout_handle,
            stderr=stderr_handle,
        )
        script_path = _command_script_path(command)
        _mark_spawned(attempts, lab_root, args.kind, attempt_id, proc.pid, script_path, cwd or "")
        proc.wait()
        stdout_data = _read_file_tail(stdout_handle, tail_bytes)
        stderr_data = _read_file_tail(stderr_handle, tail_bytes)
        stdout_tail = _decode_tail(stdout_data, tail_bytes)
        stderr_tail = _decode_tail(stderr_data, tail_bytes)
        rc = proc.returncode
        if rc is None:
            rc = 1
        _finish_attempt(attempts, lab_root, args.kind, attempt_id, rc, stdout_tail, stderr_tail)
        if args.echo_child_output and stdout_tail:
            try:
                sys.stdout.write(stdout_tail)
            except Exception:
                pass
        if args.echo_child_output and stderr_tail:
            try:
                sys.stderr.write(stderr_tail)
            except Exception:
                pass
        return int(rc)
    except Exception as e:
        rc = 1
        if proc is not None and proc.returncode is not None:
            rc = proc.returncode
        if attempts is not None and hasattr(attempts, "fail_attempt"):
            _call_best_effort(
                attempts.fail_attempt,
                {
                    "lab_root": lab_root,
                    "diagnostic_kind": args.kind,
                    "attempt_id": attempt_id,
                    "returncode": rc,
                    "stdout_tail": stdout_tail,
                    "stderr_tail": stderr_tail,
                    "domain_status": "tracked_diagnostic_wrapper_exception",
                    "domain_detail": str(e),
                    "finished_at_utc": _iso_utc_now(),
                },
            )
        print("tracked diagnostic failed to launch or finish: {0}".format(e), file=sys.stderr)
        return rc
    finally:
        for handle in (stdout_handle, stderr_handle):
            try:
                if handle is not None:
                    handle.close()
            except Exception:
                pass


if __name__ == "__main__":
    sys.exit(main())
