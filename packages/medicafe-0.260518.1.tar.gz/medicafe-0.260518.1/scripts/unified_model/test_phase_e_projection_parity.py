#!/usr/bin/env python
"""
Phase E projection and parity: unit tests.
Tests determinism, idempotency, no-op, lock-fail, projection logic.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import types
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_e_common import (
    PHASE_E_LOCK_FAIL,
    PHASE_E_STATE_WRITE_ERROR,
    PROJECTION_TYPE,
    PROJECTION_VERSION,
    QA_POLICY_VERSION,
    serialize_projection_json,
)

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab_with_db():
    """Create temp lab dir with unified_model_xp.db and schema."""
    lab_root = tempfile.mkdtemp()
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    if os.path.exists(SQL_PATH):
        with open(SQL_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(db_path)
            conn.executescript(f.read())
            conn.close()
    return lab_root, db_path, reports_dir


class TestPhaseFAutoReportNoiseGate(unittest.TestCase):
    def test_phase_f_auto_report_is_covered_by_active_post_update_support_send(self):
        from phase_e_auto_report import submit_phase_f_report

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir)
        try:
            with open(os.path.join(reports_dir, "post_update_cloud_autofollow_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "status": "running_send",
                        "send_type": "system_health",
                        "recommendation_action_kind": "send_bundle",
                        "updated_at_utc": "",
                    },
                    f,
                )
            fake_reporter = types.SimpleNamespace(
                report_dedup_try_reserve=MagicMock(return_value=(True, {})),
                report_dedup_release_if_failed=MagicMock(),
                collect_support_bundle=MagicMock(return_value="/tmp/fake.zip"),
                submit_support_bundle_email=MagicMock(return_value=True),
            )
            with patch.dict(sys.modules, {"MediCafe.error_reporter": fake_reporter}):
                ok = submit_phase_f_report(
                    lab_root,
                    os.path.join(reports_dir, "shadow_run_report_run.json"),
                    os.path.join(reports_dir, "shadow_run_report_run.txt"),
                    os.path.join(reports_dir, "shadow_evidence_index_run.json"),
                    {
                        "run_id": "run",
                        "pipeline_ok": False,
                        "failed_phase": "C",
                        "error_code": "PHASE_C_HANDOFF_INCOHERENT",
                    },
                )

            self.assertFalse(ok)
            self.assertFalse(fake_reporter.collect_support_bundle.called)
            self.assertFalse(fake_reporter.submit_support_bundle_email.called)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestProjectionSerialization(unittest.TestCase):
    """Deterministic projection JSON serialization."""

    def test_serialize_determinism(self):
        obj = {"b": 2, "a": 1, "c": 3}
        s1 = serialize_projection_json(obj)
        s2 = serialize_projection_json(obj)
        self.assertEqual(s1, s2)
        parsed = json.loads(s1)
        self.assertEqual(parsed["a"], 1)
        self.assertEqual(parsed["b"], 2)
        self.assertEqual(parsed["c"], 3)

    def test_sort_keys(self):
        obj = {"z": 1, "a": 2}
        s = serialize_projection_json(obj)
        self.assertTrue(s.index('"a"') < s.index('"z"'))


class TestRunProjectionParity(unittest.TestCase):
    """run_projection_parity: no-op, lock-fail, DB-fail."""

    def test_no_eligible_rows_ok(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertTrue(ok)
            assert summary is not None
            self.assertEqual(summary.get("eligible_count"), 0)
            self.assertEqual(summary.get("canonical_in_scope_total_semantics"), "cumulative_allowlisted_canonical_rows")
            self.assertIn("not unique patient counts", summary.get("cumulative_scope_note", ""))
            self.assertIsNone(err)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_lock_fail_returns_error(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_projection_parity.acquire_lock", side_effect=SystemExit(1)):
                ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_E_LOCK_FAIL)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPhaseEAutoReportSummary(unittest.TestCase):
    def test_phase_e_failure_summary_unchanged(self):
        from phase_e_auto_report import _build_failure_summary

        summary = _build_failure_summary("PHASE_E_LOCK_FAIL", "E")
        self.assertEqual(summary, "Phase E projection/parity failed: PHASE_E_LOCK_FAIL (E)")

    def test_non_phase_e_summary_uses_pipeline_wording(self):
        from phase_e_auto_report import _build_failure_summary

        summary = _build_failure_summary("PHASE_F_LOCK_FAIL", "F")
        self.assertEqual(summary, "Shadow pipeline failed at phase F: PHASE_F_LOCK_FAIL (F)")




class TestPhaseEFailureClassification(unittest.TestCase):
    def test_non_letter_first_failed_stays_phase_e_failure(self):
        from phase_e_auto_report import _classify_failure_origin, _build_failure_summary

        classification = _classify_failure_origin("prelock")
        self.assertTrue(classification.get("phase_e_failure"))
        self.assertFalse(classification.get("pipeline_failure"))
        summary = _build_failure_summary("PHASE_E_DB_WRITE_ERROR", "prelock")
        self.assertEqual(summary, "Phase E projection/parity failed: PHASE_E_DB_WRITE_ERROR (prelock)")

    def test_submit_phase_e_uses_phase_classification_for_meta(self):
        from phase_e_auto_report import submit_phase_e_failure_report

        submit_mock = MagicMock(return_value=True)
        fake_reporter = types.SimpleNamespace(
            report_dedup_try_reserve=MagicMock(return_value=(True, {})),
            report_dedup_release_if_failed=MagicMock(),
            collect_support_bundle=MagicMock(return_value="/tmp/fake.zip"),
            submit_support_bundle_email=submit_mock,
        )
        with patch.dict(sys.modules, {"MediCafe.error_reporter": fake_reporter}):
            sent = submit_phase_e_failure_report("/tmp/lab", {
                "error_code": "PHASE_E_STATE_WRITE_ERROR",
                "run_id": "rid-1",
                "first_failed": "disk full",
                "lab_root": "/tmp/lab",
            })

        self.assertTrue(sent)
        extra_meta = submit_mock.call_args[1].get("extra_meta", {})
        self.assertTrue(extra_meta.get("phase_e_failure"))
        self.assertFalse(extra_meta.get("pipeline_failure"))

    def test_pipeline_failure_report_includes_phase_c_context_pack(self):
        from phase_e_auto_report import submit_phase_e_failure_report

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir)
        c_rid = "20260501-205907-7be634c6"
        ingest_path = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(c_rid))
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({
                    "last_phase_c_run_id": c_rid,
                    "last_shadow_pipeline_phase_run_ids": {"B": "phase-b-run", "C": c_rid},
                }, f)
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"last_manifest_sha256": "sha-run"}, f)
            with open(ingest_path, "w", encoding="utf-8") as f:
                json.dump({
                    "run_id": c_rid,
                    "ok": False,
                    "error_code": "PHASE_C_DB_WRITE_ERROR",
                    "manifest_sha256": "sha-run",
                    "db_error_detail": "database is locked",
                }, f)

            collect_mock = MagicMock(return_value="/tmp/fake.zip")
            fake_reporter = types.SimpleNamespace(
                report_dedup_try_reserve=MagicMock(return_value=(True, {})),
                report_dedup_release_if_failed=MagicMock(),
                collect_support_bundle=collect_mock,
                submit_support_bundle_email=MagicMock(return_value=True),
            )
            with patch.dict(sys.modules, {"MediCafe.error_reporter": fake_reporter}):
                sent = submit_phase_e_failure_report(lab_root, {
                    "error_code": "PHASE_C_DB_WRITE_ERROR",
                    "run_id": "shadow-run",
                    "first_failed": "C",
                    "lab_root": lab_root,
                    "summary": {"phase": "pipeline", "failed_phase": "C"},
                })

            self.assertTrue(sent)
            extra_files = collect_mock.call_args[1].get("extra_files", [])
            archive_names = [item[0] for item in extra_files]
            self.assertIn("projection_parity_summary.json", archive_names)
            self.assertIn("phase_f_bc_correlation_note.txt", archive_names)
            self.assertEqual(archive_names.count("projection_parity_summary.json"), 1)
            em = collect_mock.call_args[1].get("evidence_manifest")
            self.assertIsNotNone(em)
            mf_names = [a.get("archive_name") for a in em.get("attachments", []) if isinstance(a, dict)]
            self.assertIn("diagnostics_state.json", mf_names)
            self.assertIn("run_cursor.json", mf_names)
            self.assertIn(os.path.basename(ingest_path), mf_names)
            self.assertIn("phase_c_bundle_correlation_note.txt", mf_names)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_operator_shutdown_uses_distinct_bundle_kind(self):
        from phase_e_auto_report import submit_phase_e_failure_report

        lab_root = tempfile.mkdtemp()
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({}, f)
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({}, f)
            collect_mock = MagicMock(return_value="/tmp/fake.zip")
            submit_mock = MagicMock(return_value=True)
            fake_reporter = types.SimpleNamespace(
                report_dedup_try_reserve=MagicMock(return_value=(True, {})),
                report_dedup_release_if_failed=MagicMock(),
                collect_support_bundle=collect_mock,
                submit_support_bundle_email=submit_mock,
            )
            with patch.dict(sys.modules, {"MediCafe.error_reporter": fake_reporter}):
                sent = submit_phase_e_failure_report(lab_root, {
                    "error_code": "OPERATOR_SHUTDOWN_REQUESTED",
                    "run_id": "shadow-run",
                    "first_failed": "A",
                    "lab_root": lab_root,
                    "summary": {"phase": "pipeline", "failed_phase": "A"},
                })

            self.assertTrue(sent)
            extra_meta = collect_mock.call_args[1].get("extra_meta", {})
            self.assertEqual(extra_meta.get("bundle_kind"), "operator_shutdown_report")
            self.assertTrue(extra_meta.get("operator_shutdown_requested"))
            self.assertEqual(extra_meta.get("workflow_boundary"), "operator_requested_shutdown_context")
            self.assertIn("Operator-requested shutdown", extra_meta.get("error_summary", ""))
            em = collect_mock.call_args[1].get("evidence_manifest")
            self.assertIsNotNone(em)
            self.assertEqual(em.get("request", {}).get("bundle_kind"), "operator_shutdown_report")
            sent_meta = submit_mock.call_args[1].get("extra_meta", {})
            self.assertEqual(sent_meta.get("bundle_kind"), "operator_shutdown_report")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_phase_f_evidence_includes_indexed_phase_summaries(self):
        from phase_e_auto_report import submit_phase_f_report

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir)
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"last_shadow_pipeline_run_id": "run1"}, f)
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({}, f)
            report_json = os.path.join(reports_dir, "shadow_run_report_run1.json")
            report_txt = os.path.join(reports_dir, "shadow_run_report_run1.txt")
            index_path = os.path.join(reports_dir, "shadow_evidence_index_run1.json")
            phase_b_summary = os.path.join(reports_dir, "artifact_discovery_summary_b-run.json")
            with open(report_json, "w", encoding="utf-8") as f:
                json.dump({"run_id": "run1"}, f)
            with open(report_txt, "w", encoding="utf-8") as f:
                f.write("run1\n")
            with open(phase_b_summary, "w", encoding="utf-8") as f:
                json.dump({"run_id": "b-run", "error_code": "PHASE_B_ROOT_RESOLUTION_FAIL"}, f)
            with open(index_path, "w", encoding="utf-8") as f:
                json.dump({
                    "artifact_files": [
                        {"role": "phase_b_summary", "path": phase_b_summary, "exists": True},
                        {"role": "phase_c_summary", "path": "__MISSING__", "exists": False},
                    ]
                }, f)

            collect_mock = MagicMock(return_value="/tmp/fake.zip")
            fake_reporter = types.SimpleNamespace(
                report_dedup_try_reserve=MagicMock(return_value=(True, {})),
                report_dedup_release_if_failed=MagicMock(),
                collect_support_bundle=collect_mock,
                submit_support_bundle_email=MagicMock(return_value=True),
            )
            with patch.dict(sys.modules, {"MediCafe.error_reporter": fake_reporter}):
                sent = submit_phase_f_report(lab_root, report_json, report_txt, index_path, {
                    "run_id": "run1",
                    "pipeline_ok": False,
                    "failed_phase": "B",
                    "error_code": "PHASE_B_ROOT_RESOLUTION_FAIL",
                    "contract_parity_status": "",
                })

            self.assertTrue(sent)
            extra_files = collect_mock.call_args[1].get("extra_files", [])
            archive_names = [item[0] for item in extra_files]
            self.assertIn("shadow_run_report.json", archive_names)
            self.assertIn("shadow_evidence_index.json", archive_names)
            em = collect_mock.call_args[1].get("evidence_manifest")
            self.assertIsNotNone(em)
            mf_names = [a.get("archive_name") for a in em.get("attachments", []) if isinstance(a, dict)]
            self.assertIn(os.path.basename(phase_b_summary), mf_names)
            self.assertIn("diagnostics_state.json", mf_names)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

class TestRunProjectionParityIntegration(unittest.TestCase):
    """End-to-end: canonical -> projection_result; determinism; idempotency."""

    def test_integration_projects_canonical(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("ingest_k1", "xp_local", "file_csv", "src|path", None, "", "",
                 json.dumps({"artifact_class": "csv", "locator": "x.csv"}), "ingested"),
            )
            conn.execute(
                "INSERT INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                "VALUES (1, 'phase_d', ?, 'pass', NULL, NULL, 'dk1')",
                (QA_POLICY_VERSION,),
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (1, 'patient_csv_row', 'pk1', 'canon_v1', "
                "'{\"Patient ID\":\"12345\",\"Birth Date\":\"1990-01-01\"}', '{\"artifact_id\":1}')",
            )
            conn.commit()
            conn.close()
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertTrue(ok)
            assert summary is not None
            self.assertEqual(summary.get("eligible_count"), 1)
            self.assertEqual(summary.get("projected_success_this_run"), 1)
            self.assertEqual(summary.get("projected_reject_this_run"), 0)
            conn = sqlite3.connect(db_path)
            proj_count = conn.execute(
                "SELECT COUNT(*) FROM projection_result WHERE projection_type=? AND projection_version=?",
                (PROJECTION_TYPE, PROJECTION_VERSION),
            ).fetchone()[0]
            self.assertEqual(proj_count, 1)
            conn.close()
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_idempotency_rerun_no_new_rows(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("ingest_k1", "xp_local", "file_csv", "src|path", None, "", "",
                 json.dumps({"artifact_class": "csv"}), "ingested"),
            )
            conn.execute(
                "INSERT INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                "VALUES (1, 'phase_d', ?, 'pass', NULL, NULL, 'dk1')",
                (QA_POLICY_VERSION,),
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (1, 'patient_csv_row', 'pk1', 'canon_v1', '{\"Patient ID\":\"12345\"}', '{}')",
            )
            conn.commit()
            conn.close()
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    ok1, _, _, _ = run_projection_parity(lab_root)
                    ok2, _, summary2, _ = run_projection_parity(lab_root)
            self.assertTrue(ok1)
            self.assertTrue(ok2)
            assert summary2 is not None  # narrow for type checker; ok path always returns summary
            self.assertEqual(summary2.get("eligible_count"), 0)
            self.assertEqual(summary2.get("projected_success_this_run"), 0)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestRunShadowPipelineLock(unittest.TestCase):
    """Pipeline lock: stale heartbeat + running PID => lock not stolen."""

    def test_stale_heartbeat_running_pid_lock_not_stolen(self):
        from run_shadow_pipeline import _acquire_pipeline_lock, _release_pipeline_lock
        import time
        lab_root = tempfile.mkdtemp()
        lock_path = os.path.join(lab_root, "shadow_pipeline.lock")
        try:
            # Create lock with stale heartbeat (over 3600s ago) and current PID (running)
            old_ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 4000))
            with open(lock_path, "w") as f:
                f.write("pid={0}\nacquired_at_utc={1}\nheartbeat_at_utc={1}\n".format(os.getpid(), old_ts))
            acquired = _acquire_pipeline_lock(lab_root)
            self.assertFalse(acquired, "Lock must not be stolen when PID is running even with stale heartbeat")
        finally:
            _release_pipeline_lock(lab_root)
            try:
                if os.path.exists(lock_path):
                    os.remove(lock_path)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestNoOpStateWriteFailure(unittest.TestCase):
    """No-op branch: persist_phase_e_state exception => PHASE_E_STATE_WRITE_ERROR."""

    def test_noop_persist_failure_returns_state_write_error(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    with patch("run_projection_parity.persist_phase_e_state", side_effect=RuntimeError("disk full")):
                        ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_E_STATE_WRITE_ERROR)
            assert summary is not None
            self.assertEqual(summary.get("error_code"), PHASE_E_STATE_WRITE_ERROR)
            self.assertIn("disk full", summary.get("error_detail", ""))
            self.assertEqual(summary.get("contract_parity_status"), "fail")
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestMainPathStateWriteFailure(unittest.TestCase):
    """Eligible rows path: persist_phase_e_state failure normalizes summary parity."""

    def test_main_path_persist_failure_contract_parity_not_pass(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("ingest_k1", "xp_local", "file_csv", "src|path", None, "", "",
                 json.dumps({"artifact_class": "csv", "locator": "x.csv"}), "ingested"),
            )
            conn.execute(
                "INSERT INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                "VALUES (1, 'phase_d', ?, 'pass', NULL, NULL, 'dk1')",
                (QA_POLICY_VERSION,),
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (1, 'patient_csv_row', 'pk1', 'canon_v1', "
                "'{\"Patient ID\":\"12345\",\"Birth Date\":\"1990-01-01\"}', '{\"artifact_id\":1}')",
            )
            conn.commit()
            conn.close()
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    with patch("run_projection_parity.persist_phase_e_state", side_effect=RuntimeError("disk full")):
                        ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_E_STATE_WRITE_ERROR)
            assert summary is not None
            self.assertEqual(summary.get("error_code"), PHASE_E_STATE_WRITE_ERROR)
            self.assertNotEqual(summary.get("contract_parity_status"), "pass")
            self.assertEqual(summary.get("contract_parity_status"), "fail")
            self.assertEqual(summary.get("eligible_count"), 1)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPersistPhaseEStateRollback(unittest.TestCase):
    """Cursor replace failure rolls back diagnostics_state.json to avoid XP_CURSOR_ALIGNMENT_DRIFT."""

    def test_cursor_write_failure_restores_diagnostics_state(self):
        import lab_lock
        from run_projection_parity import persist_phase_e_state

        lab_root = tempfile.mkdtemp()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            baseline_state = {
                "last_phase_e_run_id": "old-rid",
                "last_phase_e_ok": True,
                "other_key": 1,
            }
            baseline_cursor = {
                "last_phase_e_run_id": "old-rid",
                "last_phase_e_ok": True,
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(baseline_state, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(baseline_cursor, f)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor_on_disk_before = f.read()

            def replace_proxy(path, content):
                if os.path.basename(path) == "run_cursor.json":
                    raise RuntimeError("cursor fail")
                lab_lock.replace_safe_write(path, content)

            with patch("run_projection_parity.replace_safe_write", side_effect=replace_proxy):
                with self.assertRaises(RuntimeError):
                    persist_phase_e_state(lab_root, "new-rid", True, None, 1, 0, "pass", {})

            with open(state_path, "r", encoding="utf-8") as f:
                restored = json.load(f)
            self.assertEqual(restored.get("last_phase_e_run_id"), "old-rid")
            self.assertEqual(restored.get("other_key"), 1)
            with open(cursor_path, "r", encoding="utf-8") as f:
                self.assertEqual(f.read(), cursor_on_disk_before)
        finally:
            try:
                for name in ("diagnostics_state.json", "run_cursor.json"):
                    p = os.path.join(lab_root, name)
                    if os.path.exists(p):
                        os.remove(p)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPersistPhaseEStateRollbackCorruptDiagnostics(unittest.TestCase):
    """Unreadable diagnostics_state.json is restored as raw bytes when cursor write fails."""

    def test_cursor_write_failure_restores_corrupt_diagnostics_bytes(self):
        import lab_lock
        from run_projection_parity import persist_phase_e_state

        lab_root = tempfile.mkdtemp()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        corrupt = b"{not json\n"
        try:
            with open(state_path, "wb") as f:
                f.write(corrupt)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_e_run_id": "old"}, f)

            def replace_proxy(path, content):
                if os.path.basename(path) == "run_cursor.json":
                    raise RuntimeError("cursor fail")
                lab_lock.replace_safe_write(path, content)

            with patch("run_projection_parity.replace_safe_write", side_effect=replace_proxy):
                with self.assertRaises(RuntimeError):
                    persist_phase_e_state(lab_root, "new-rid", True, None, 1, 0, "pass", {})

            with open(state_path, "rb") as f:
                restored = f.read()
            self.assertEqual(restored, corrupt)
        finally:
            try:
                for name in ("diagnostics_state.json", "run_cursor.json"):
                    p = os.path.join(lab_root, name)
                    if os.path.exists(p):
                        os.remove(p)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPersistPhaseERunCursorUpdatedAt(unittest.TestCase):
    """persist_phase_e_state sets updated_at_utc to match last_phase_e_at_utc."""

    def test_updated_at_matches_phase_e_timestamp(self):
        from run_projection_parity import persist_phase_e_state

        lab_root = tempfile.mkdtemp()
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        try:
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"updated_at_utc": "2000-01-01T00:00:00Z"}, f)
            persist_phase_e_state(lab_root, "rid-e-test", True, None, 0, 0, "pass", {})
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertEqual(cursor.get("updated_at_utc"), cursor.get("last_phase_e_at_utc"))
            self.assertNotEqual(cursor.get("updated_at_utc"), "2000-01-01T00:00:00Z")
        finally:
            try:
                for name in ("diagnostics_state.json", "run_cursor.json"):
                    p = os.path.join(lab_root, name)
                    if os.path.exists(p):
                        os.remove(p)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestProjectionParitySummarySemantics(unittest.TestCase):
    """Summary distinguishes cumulative row totals from distinct-key totals."""

    def test_summary_reports_row_and_distinct_key_totals(self):
        from run_projection_parity import run_projection_parity

        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            artifacts = [
                ("ingest_k1", "file_csv", json.dumps({"artifact_class": "csv", "locator": "x.csv"})),
                ("ingest_k2", "file_dat", json.dumps({"artifact_class": "dat", "locator": "z.dat"})),
                ("ingest_k3", "file_docx", json.dumps({"artifact_class": "docx", "locator": "x.docx"})),
            ]
            artifact_id = 1
            for ingest_key, source_type, payload_json in artifacts:
                conn.execute(
                    "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                    "attachment_name, attachment_sha256, payload_json, ingest_status) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (ingest_key, "xp_local", source_type, "src|path", None, "", "", payload_json, "ingested"),
                )
                conn.execute(
                    "INSERT INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                    "VALUES (?, 'phase_d', ?, 'pass', NULL, NULL, ?)",
                    (artifact_id, QA_POLICY_VERSION, "dk{0}".format(artifact_id)),
                )
                artifact_id += 1
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (1, "patient_csv_row", "shared_pk", "canon_v1", '{"Patient ID":"12345"}', '{}'),
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (2, "dat_record", "shared_pk", "canon_v1", '{"PATID":"12345","PATNAME":"Jane Doe"}', '{}'),
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (3, "docx_schedule", "docx_unique", "canon_v1", '{}', '{"patient_id":"77777"}'),
            )
            conn.commit()
            conn.close()

            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    ok, rid, summary, err = run_projection_parity(lab_root)

            self.assertTrue(ok)
            self.assertIsNone(err)
            assert summary is not None
            self.assertEqual(summary.get("eligible_count"), 3)
            self.assertEqual(summary.get("projected_success_this_run"), 3)
            self.assertEqual(summary.get("canonical_in_scope_total"), 3)
            self.assertEqual(summary.get("canonical_in_scope_distinct_canonical_key_total"), 2)
            self.assertEqual(summary.get("projected_success_total"), 3)
            self.assertEqual(summary.get("projected_success_distinct_canonical_key_total"), 2)
            self.assertEqual(summary.get("canonical_in_scope_counts_by_type", {}).get("patient_csv_row"), 1)
            self.assertEqual(summary.get("canonical_in_scope_counts_by_type", {}).get("dat_record"), 1)
            self.assertEqual(summary.get("canonical_in_scope_counts_by_type", {}).get("docx_schedule"), 1)
            self.assertEqual(summary.get("canonical_in_scope_counts_by_type", {}).get("x12_member"), 0)
            self.assertEqual(summary.get("projected_success_counts_by_type", {}).get("patient_csv_row"), 1)
            self.assertEqual(summary.get("projected_success_counts_by_type", {}).get("dat_record"), 1)
            self.assertEqual(summary.get("projected_success_counts_by_type", {}).get("docx_schedule"), 1)
            self.assertEqual(summary.get("projected_success_counts_by_type", {}).get("x12_member"), 0)

            summary_json_path = os.path.join(reports_dir, "projection_parity_summary_{0}.json".format(rid))
            summary_txt_path = os.path.join(reports_dir, "projection_parity_summary_{0}.txt".format(rid))
            with open(summary_json_path, "r", encoding="utf-8") as f:
                summary_json = json.load(f)
            self.assertEqual(summary_json.get("projected_success_distinct_canonical_key_total"), 2)
            with open(summary_txt_path, "r", encoding="utf-8") as f:
                summary_text = f.read()
            self.assertIn("Cumulative lab totals (row-oriented; not unique patient counts):", summary_text)
            self.assertIn("canonical_in_scope_total: 3 (cumulative_allowlisted_canonical_rows)", summary_text)
            self.assertIn("canonical_in_scope_distinct_canonical_key_total: 2", summary_text)
            self.assertIn(
                "projected_success_counts_by_type: dat_record=1, docx_schedule=1, patient_csv_row=1, x12_member=0",
                summary_text,
            )
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

class TestProjectionCsvMapping(unittest.TestCase):
    """CSV mapping uses shared patient mapper aliases and full-name fallback."""

    def test_patient_csv_row_uses_patient_dob_and_first_last(self):
        from run_projection_parity import _project_canonical_to_patient
        status, projected_json = _project_canonical_to_patient(
            1,
            "patient_csv_row",
            "pk_test",
            json.dumps({
                "Patient ID": "12345",
                "Patient First": "Jane",
                "Patient Last": "Doe",
                "Patient DOB": "1980-01-02",
            }),
            "{}",
        )
        self.assertEqual(status, "success")
        projected = json.loads(projected_json)
        self.assertEqual(projected.get("external_patient_id"), "12345")
        self.assertEqual(projected.get("full_name"), "Jane Doe")
        self.assertEqual(projected.get("birth_date"), "1980-01-02")


if __name__ == "__main__":
    unittest.main()
