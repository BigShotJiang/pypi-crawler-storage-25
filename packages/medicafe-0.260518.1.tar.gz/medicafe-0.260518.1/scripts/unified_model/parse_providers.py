#!/usr/bin/env python
"""
Phase D Parse Provider layer: class-specific extraction wrappers returning
normalized envelope. Safe wrappers around legacy parsers. XP-compatible: Python 3.4.4.
"""
from __future__ import print_function

import csv
import io
import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    QA_FILE_READ_ERROR,
    QA_PARSE_ERROR,
    QA_PARSE_IMPORT_ERROR,
    QA_PARSE_RUNTIME_ERROR,
    QA_UNKNOWN_ARTIFACT_CLASS,
)
from dat_contract import normalize_dat_record
from dat_payer_resolution import build_dat_payer_resolution_context

_LAST_PARSE_DIAG = {}


def _set_parse_diag(provider, error_code="", error_detail="", source_exception_class=""):
    global _LAST_PARSE_DIAG
    _LAST_PARSE_DIAG = {
        "provider": str(provider or "").strip(),
        "error_code": str(error_code or "").strip(),
        "error_detail": str(error_detail or "").strip(),
        "source_exception_class": str(source_exception_class or "").strip(),
    }


def get_last_parse_diag():
    """Return most recent parse diagnostic payload."""
    return dict(_LAST_PARSE_DIAG or {})


def _bump_counter(mapping, key):
    if not isinstance(mapping, dict):
        return
    mapping[key] = int(mapping.get(key, 0) or 0) + 1


def _append_key_set_sample(samples, mapping, limit=3):
    if not isinstance(samples, list) or not isinstance(mapping, dict):
        return
    keys = [str(key) for key in mapping.keys() if str(key or '').strip()]
    keys.sort()
    label = ','.join(keys[:12]) if keys else '(no_keys)'
    critical = []
    for key in ("PATID", "patient_id", "patid", "CHART", "DATE", "DATE1", "DOS", "PAYERID", "INSID", "payer_id"):
        if key in mapping and key not in keys[:12]:
            critical.append(key)
    if critical:
        label = "{0}|critical_keys={1}".format(label, ",".join(critical))
    if label and label not in samples and len(samples) < int(limit or 0):
        samples.append(label)


def _safe_count(mapping):
    if isinstance(mapping, dict):
        return len(mapping)
    return 0


def _slice_pair(mapping, key):
    if not isinstance(mapping, dict):
        return None
    value = mapping.get(key)
    if not isinstance(value, (list, tuple)) or len(value) < 2:
        return None
    try:
        start = int(value[0])
        end = int(value[1])
    except Exception:
        return None
    if start < 0 or end <= start:
        return None
    return start, end


def _medisoft_personal_slices(config):
    try:
        from MediLink.MediLink_DataMgmt import extract_medilink_config
        medi = extract_medilink_config(config)
    except Exception:
        medi = {}
    fixed = medi.get("fixedWidthSlices", {}) if isinstance(medi, dict) else {}
    personal = fixed.get("personal_slices", {}) if isinstance(fixed, dict) else {}
    return personal if isinstance(personal, dict) else {}


def _dat_patid_slice_window_diagnostics(raw_records, config):
    """
    Safe source-shape telemetry for the DAT PATID slice.

    Values from the PATID window are never emitted; only aggregate counts and
    line-length/slice-shape facts are recorded so developers can distinguish
    upstream blank PATID exports from parser/slice-window problems.
    """
    personal_slices = _medisoft_personal_slices(config)
    patid_slice = _slice_pair(personal_slices, "PATID")
    diag = {
        "patid_slice_configured": bool(patid_slice),
        "patid_slice_start": patid_slice[0] if patid_slice else None,
        "patid_slice_end": patid_slice[1] if patid_slice else None,
        "tuple_records_seen": 0,
        "personal_line_too_short_for_patid_start_count": 0,
        "personal_line_too_short_for_patid_end_count": 0,
        "patid_slice_window_nonblank_count": 0,
        "patid_slice_window_blank_count": 0,
        "personal_line_length_min": 0,
        "personal_line_length_max": 0,
    }
    if not patid_slice:
        return diag
    start, end = patid_slice
    min_len = None
    max_len = 0
    for rec in raw_records or []:
        if not isinstance(rec, (tuple, list)) or len(rec) < 1:
            continue
        line = str(rec[0] or "")
        length = len(line)
        diag["tuple_records_seen"] += 1
        if min_len is None or length < min_len:
            min_len = length
        if length > max_len:
            max_len = length
        if length <= start:
            diag["personal_line_too_short_for_patid_start_count"] += 1
            diag["patid_slice_window_blank_count"] += 1
            continue
        if length < end:
            diag["personal_line_too_short_for_patid_end_count"] += 1
        if str(line[start:end] or "").strip():
            diag["patid_slice_window_nonblank_count"] += 1
        else:
            diag["patid_slice_window_blank_count"] += 1
    diag["personal_line_length_min"] = int(min_len or 0)
    diag["personal_line_length_max"] = int(max_len or 0)
    return diag


def _safe_wrap_legacy(func, *args, **kwargs):
    """
    Wrap legacy function call. Catches SystemExit, KeyboardInterrupt, Exception.
    Redirects stdout/stderr during call to suppress legacy print output.
    Returns (ok, data, parser_warning_code). Never raises.
    """
    _saved_stdout = sys.stdout
    _saved_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    try:
        result = func(*args, **kwargs)
        _set_parse_diag(func.__name__ if hasattr(func, "__name__") else "legacy_call")
        return (True, result, None)
    except SystemExit as e:
        _set_parse_diag(
            func.__name__ if hasattr(func, "__name__") else "legacy_call",
            QA_PARSE_RUNTIME_ERROR,
            str(e),
            "SystemExit",
        )
        return (False, None, QA_PARSE_RUNTIME_ERROR)
    except KeyboardInterrupt as e:
        _set_parse_diag(
            func.__name__ if hasattr(func, "__name__") else "legacy_call",
            QA_PARSE_RUNTIME_ERROR,
            str(e),
            "KeyboardInterrupt",
        )
        return (False, None, QA_PARSE_RUNTIME_ERROR)
    except Exception as e:
        _set_parse_diag(
            func.__name__ if hasattr(func, "__name__") else "legacy_call",
            QA_PARSE_RUNTIME_ERROR,
            str(e),
            e.__class__.__name__,
        )
        return (False, None, QA_PARSE_RUNTIME_ERROR)
    finally:
        sys.stdout = _saved_stdout
        sys.stderr = _saved_stderr


def _read_file_content(locator):
    """
    Fetch adapter: read file at locator (XP: filesystem path).
    Returns (ok, content_bytes, error_code). content_bytes is None on failure.
    """
    if not locator or not isinstance(locator, str) or not locator.strip():
        _set_parse_diag("file_reader", QA_FILE_READ_ERROR, "locator missing", "ValueError")
        return (False, None, QA_FILE_READ_ERROR)
    path = locator.strip()
    if not os.path.exists(path) or not os.path.isfile(path):
        _set_parse_diag("file_reader", QA_FILE_READ_ERROR, "path missing or not file", "IOError")
        return (False, None, QA_FILE_READ_ERROR)
    try:
        with open(path, "rb") as f:
            content = f.read()
        _set_parse_diag("file_reader")
        return (True, content, None)
    except (IOError, OSError) as e:
        _set_parse_diag("file_reader", QA_FILE_READ_ERROR, str(e), e.__class__.__name__)
        return (False, None, QA_FILE_READ_ERROR)


def _metadata_text(metadata, key):
    if not isinstance(metadata, dict):
        return ""
    value = metadata.get(key)
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:
        return ""


def _is_probably_abs_path(path):
    text = str(path or "").strip()
    if not text:
        return False
    if os.path.isabs(text):
        return True
    if len(text) >= 3 and text[1] == ":" and text[2] in ("\\", "/"):
        return True
    if text.startswith("\\\\") or text.startswith("//"):
        return True
    return False


def _resolve_docx_locator(locator, metadata):
    """
    Resolve DOCX locators that may have been persisted as basenames.

    Historical Phase D reprocess can replay artifacts whose payload locator is
    only the attachment name.  The live DOCX index and fallback parser need the
    actual file path, usually under local_storage_path.
    """
    metadata = metadata or {}
    candidates = []
    for value in (
            locator,
            _metadata_text(metadata, "locator"),
            _metadata_text(metadata, "normalized_path"),
            _metadata_text(metadata, "source_ref"),
            _metadata_text(metadata, "attachment_name")):
        text = str(value or "").strip()
        if text and text not in candidates:
            candidates.append(text)

    storage_candidates = []
    for key in ("local_storage_path", "storage_path", "docx_storage_path"):
        text = _metadata_text(metadata, key)
        if text and text not in storage_candidates:
            storage_candidates.append(text)

    for candidate in candidates:
        if _is_probably_abs_path(candidate) and os.path.isfile(candidate):
            return candidate, os.path.dirname(candidate)

    for candidate in candidates:
        if _is_probably_abs_path(candidate):
            return candidate, os.path.dirname(candidate)

    for storage in storage_candidates:
        for candidate in candidates:
            name = os.path.basename(candidate.replace("\\", os.sep).replace("/", os.sep))
            if not name:
                continue
            joined = os.path.join(storage, name)
            if os.path.isfile(joined):
                return joined, storage

    if candidates:
        first = candidates[0]
        if storage_candidates:
            name = os.path.basename(first.replace("\\", os.sep).replace("/", os.sep))
            if name:
                return os.path.join(storage_candidates[0], name), storage_candidates[0]
        return first, os.path.dirname(first)

    return str(locator or ""), _metadata_text(metadata, "local_storage_path")


def _normalize_csv_envelope(rows):
    """Convert CSV rows to normalized envelope for QA. Keys: rows, row_count, has_patient_id."""
    if not isinstance(rows, list):
        return None
    has_patient_id = False
    for row in rows:
        if isinstance(row, dict):
            pid = row.get("Patient ID") or row.get("patient_id") or ""
            if pid:
                has_patient_id = True
                break
    return {
        "rows": rows,
        "row_count": len(rows),
        "has_patient_id": has_patient_id,
    }


def _csv_header_shape_short_circuit(locator, content):
    try:
        from MediBot.MediBot_Preprocessor_lib import (
            classify_csv_header_subtype,
            scrub_csv_header_token,
        )
    except Exception:
        return None
    try:
        text = content.decode("utf-8", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        raw_headers = reader.fieldnames or []
        # Match clean_header's first pass so we do not reject feeds that only
        # reveal a surgery-date alias after stripping punctuation (e.g. "Surgery Date\u2122").
        headers = [scrub_csv_header_token(h) for h in raw_headers]
    except Exception:
        return None
    try:
        from MediBot.csv_intake_shape import classify_medibot_intake_headers
        intake_shape = classify_medibot_intake_headers(raw_headers)
        if intake_shape.get("reason") == "action_or_reconciliation_csv":
            return {
                "warning_code": QA_PARSE_ERROR,
                "detail": "csv_operational_profile=reconciliation_action_report; action_markers={0}".format(
                    ",".join(intake_shape.get("action_markers") or [])
                ),
                "source_exception_class": "CsvOperationalShape",
                "classification": intake_shape,
            }
    except Exception:
        pass
    try:
        classification = classify_csv_header_subtype(headers)
    except Exception:
        return None
    if not isinstance(classification, dict):
        return None
    if classification.get("has_surgery_date_alias"):
        return None
    subtype = str(classification.get("csv_subtype") or "")
    if subtype not in ("claim_payment_no_surgery_date", "patient_demographic_no_surgery_date"):
        return None
    detail = "csv_subtype={0}; matched_family={1}; serv_alias_policy={2}".format(
        subtype,
        classification.get("matched_family") or "",
        classification.get("serv_alias_policy") or "",
    )
    return {
        "warning_code": QA_PARSE_ERROR,
        "detail": detail,
        "source_exception_class": "CsvHeaderShape",
        "classification": classification,
    }


def parse_csv(locator, metadata=None):
    """
    Parse CSV artifact. Uses legacy load_csv_data via safe wrapper.
    Returns (ok, envelope, parser_warning_code).
    envelope: {rows, row_count, has_patient_id} or None.
    """
    metadata = metadata or {}
    _set_parse_diag("csv")
    file_ok, content, file_err = _read_file_content(locator)
    if not file_ok:
        return (False, None, file_err or QA_FILE_READ_ERROR)
    header_short_circuit = _csv_header_shape_short_circuit(locator, content)
    if header_short_circuit:
        _set_parse_diag(
            "csv",
            header_short_circuit.get("warning_code") or QA_PARSE_ERROR,
            header_short_circuit.get("detail") or "csv header shape not routed to surgery parser",
            header_short_circuit.get("source_exception_class") or "CsvHeaderShape",
        )
        return (False, None, header_short_circuit.get("warning_code") or QA_PARSE_ERROR)
    try:
        from MediBot.MediBot_Preprocessor_lib import load_csv_data
    except ImportError as e:
        _set_parse_diag("csv", QA_PARSE_IMPORT_ERROR, str(e), "ImportError")
        # Fallback: parse with stdlib csv only
        ok, content, err = _read_file_content(locator)
        if not ok:
            return (False, None, err or QA_FILE_READ_ERROR)
        try:
            text = content.decode("utf-8", errors="replace")
            reader = csv.DictReader(io.StringIO(text))
            rows = list(reader)
            envelope = _normalize_csv_envelope(rows)
            _set_parse_diag("csv")
            return (True, envelope, None)
        except Exception as parse_err:
            _set_parse_diag("csv", QA_PARSE_RUNTIME_ERROR, str(parse_err), parse_err.__class__.__name__)
            return (False, None, QA_PARSE_RUNTIME_ERROR)

    ok, data, err = _safe_wrap_legacy(load_csv_data, locator)
    if not ok:
        return (False, None, err or QA_PARSE_ERROR)
    envelope = _normalize_csv_envelope(data if isinstance(data, list) else [])
    return (True, envelope, None)


def _same_stat_as_index_record(locator, rec):
    if not isinstance(rec, dict):
        return False
    try:
        stat_info = os.stat(locator)
    except Exception:
        return False
    try:
        if int(rec.get("size")) != int(stat_info.st_size):
            return False
    except Exception:
        return False
    try:
        rec_mtime = float(rec.get("mtime"))
        return abs(rec_mtime - float(stat_info.st_mtime)) <= 0.001
    except Exception:
        return False


def _docx_index_failure_short_circuit(index_data, locator, current_filename):
    files = index_data.get("files") if isinstance(index_data, dict) else None
    if not isinstance(files, dict) or not current_filename:
        return None
    rec = files.get(current_filename)
    if not isinstance(rec, dict):
        return None
    if not rec.get("parse_failed"):
        return None
    if not _same_stat_as_index_record(locator, rec):
        return None
    parse_error_type = str(rec.get("parse_error_type") or "")
    docx_reason = str(rec.get("docx_package_reason") or "")
    if parse_error_type != "invalid_docx_package" and docx_reason not in (
            "not_zip_package", "missing_required_docx_parts", "docx_package_validation_error"):
        return None
    detail = "docx_index_parse_failed={0}; docx_package_reason={1}".format(
        parse_error_type,
        docx_reason,
    )
    return {
        "warning_code": QA_PARSE_ERROR,
        "detail": detail,
        "source_exception_class": "DocxIndexFailure",
    }


def parse_jsonl(locator, metadata=None):
    """
    Parse JSONL artifact. Returns (ok, envelope, parser_warning_code).
    envelope: {rows, row_count, has_claim_number}.
    """
    metadata = metadata or {}
    _set_parse_diag("jsonl")
    ok, content, err = _read_file_content(locator)
    if not ok:
        return (False, None, err or QA_FILE_READ_ERROR)
    try:
        text = content.decode("utf-8", errors="replace")
        rows = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except (ValueError, TypeError):
                pass
        has_claim = any(
            isinstance(r, dict) and (r.get("claim_number") or r.get("Claim #"))
            for r in rows
        )
        envelope = {
            "rows": rows,
            "row_count": len(rows),
            "has_claim_number": has_claim,
        }
        _set_parse_diag("jsonl")
        return (True, envelope, None)
    except Exception as e:
        _set_parse_diag("jsonl", QA_PARSE_RUNTIME_ERROR, str(e), e.__class__.__name__)
        return (False, None, QA_PARSE_RUNTIME_ERROR)


def parse_x12(locator, metadata=None):
    """
    Parse 837 X12 artifact. Uses x12_utils extractors.
    Returns (ok, envelope, parser_warning_code).
    envelope: {member_id, member_first_name, member_last_name, member_dob, service_start_date, service_end_date, payer_id}.
    """
    metadata = metadata or {}
    _set_parse_diag("837")
    ok, content, err = _read_file_content(locator)
    if not ok:
        return (False, None, err or QA_FILE_READ_ERROR)
    try:
        text = content.decode("utf-8", errors="replace")
        try:
            from MediCafe.x12_utils import (
                extract_member_id_from_x12,
                extract_member_name_from_x12,
                extract_member_dob_from_x12,
                extract_service_dates_from_x12,
                extract_payer_id_from_x12,
            )
        except ImportError as e:
            _set_parse_diag("837", QA_PARSE_IMPORT_ERROR, str(e), "ImportError")
            return (False, None, QA_PARSE_IMPORT_ERROR)
        member_id = extract_member_id_from_x12(text)
        first_name, last_name = extract_member_name_from_x12(text)
        dob = extract_member_dob_from_x12(text)
        service_start, service_end = extract_service_dates_from_x12(text)
        payer_id = extract_payer_id_from_x12(text)
        envelope = {
            "member_id": member_id,
            "member_first_name": first_name,
            "member_last_name": last_name,
            "member_dob": dob,
            "service_start_date": service_start,
            "service_end_date": service_end,
            "payer_id": payer_id,
        }
        _set_parse_diag("837")
        return (True, envelope, None)
    except Exception as e:
        _set_parse_diag("837", QA_PARSE_RUNTIME_ERROR, str(e), e.__class__.__name__)
        return (False, None, QA_PARSE_RUNTIME_ERROR)


def parse_dat(locator, metadata=None):
    """
    Parse DAT/fixed-width artifact. Uses MediLink_DataMgmt readers.
    Normalizes tuple records to dicts via parse_fixed_width_data.
    Returns (ok, envelope, parser_warning_code).
    """
    metadata = metadata or {}
    _set_parse_diag("dat")

    try:
        from MediLink.MediLink_DataMgmt import read_fixed_width_data, parse_fixed_width_data
    except ImportError as e:
        _set_parse_diag("dat", QA_PARSE_IMPORT_ERROR, str(e), "ImportError")
        return (False, None, QA_PARSE_IMPORT_ERROR)
    try:
        from MediCafe.core_utils import get_shared_config_loader
        config_loader = get_shared_config_loader()
        config, crosswalk = config_loader.load_configuration()
    except Exception as e:
        _set_parse_diag("dat", QA_PARSE_RUNTIME_ERROR, str(e), e.__class__.__name__)
        return (False, None, QA_PARSE_RUNTIME_ERROR)
    payer_resolution_context = build_dat_payer_resolution_context(config, crosswalk)
    ok, data, err = _safe_wrap_legacy(read_fixed_width_data, locator)
    if not ok:
        return (False, None, err or QA_PARSE_ERROR)
    raw_records = list(data) if data is not None else []
    file_size_bytes = 0
    try:
        if locator and os.path.isfile(locator):
            file_size_bytes = int(os.path.getsize(locator))
    except Exception:
        file_size_bytes = 0
    records = []
    parser_diagnostics = {
        "raw_record_count": len(raw_records),
        "parsed_record_count": 0,
        "tuple_candidate_count": 0,
        "tuple_parse_failure_count": 0,
        "first_failure_class": "",
        "first_failure_detail": "",
        "record_shape_counts": {},
        "raw_key_sets_sample": [],
        "payer_resolution_context_counts": {
            "insurance_name_to_id": _safe_count(payer_resolution_context.get("insurance_name_to_id")),
            "payer_ids_by_medisoft": _safe_count(payer_resolution_context.get("payer_ids_by_medisoft")),
            "payer_ids_by_crosswalk_name": _safe_count(payer_resolution_context.get("payer_ids_by_crosswalk_name")),
        },
        "patid_slice_window_diagnostics": _dat_patid_slice_window_diagnostics(raw_records, config),
    }
    for rec in raw_records:
        if isinstance(rec, dict):
            _bump_counter(parser_diagnostics["record_shape_counts"], "dict")
            _append_key_set_sample(parser_diagnostics["raw_key_sets_sample"], rec)
            records.append(normalize_dat_record(rec, payer_resolution_context=payer_resolution_context))
        elif isinstance(rec, (tuple, list)) and len(rec) >= 3:
            _bump_counter(parser_diagnostics["record_shape_counts"], "tuple")
            parser_diagnostics["tuple_candidate_count"] += 1
            try:
                personal_info = rec[0] if len(rec) > 0 else ""
                insurance_info = rec[1] if len(rec) > 1 else ""
                service_info = rec[2] if len(rec) > 2 else ""
                service_info_2 = rec[3] if len(rec) > 3 else None
                service_info_3 = rec[4] if len(rec) > 4 else None
                parsed = parse_fixed_width_data(
                    personal_info, insurance_info, service_info,
                    service_info_2, service_info_3, config=config
                )
                if isinstance(parsed, dict):
                    _append_key_set_sample(parser_diagnostics["raw_key_sets_sample"], parsed)
                    records.append(normalize_dat_record(parsed, payer_resolution_context=payer_resolution_context))
                else:
                    parser_diagnostics["tuple_parse_failure_count"] += 1
                    if not parser_diagnostics["first_failure_class"]:
                        parser_diagnostics["first_failure_class"] = "NonDictParsedRecord"
                        parser_diagnostics["first_failure_detail"] = "parse_fixed_width_data returned {0}".format(type(parsed).__name__)
            except Exception as e:
                parser_diagnostics["tuple_parse_failure_count"] += 1
                if not parser_diagnostics["first_failure_class"]:
                    parser_diagnostics["first_failure_class"] = e.__class__.__name__
                    parser_diagnostics["first_failure_detail"] = str(e)
        else:
            _bump_counter(parser_diagnostics["record_shape_counts"], "other")
    parser_diagnostics["parsed_record_count"] = len(records)
    envelope = {
        "records": records,
        "record_count": len(records),
        "file_size_bytes": file_size_bytes,
        "parser_name": "MediLink_DataMgmt.read_fixed_width_data",
        "parser_version": "1",
        "parser_diagnostics": parser_diagnostics,
    }
    _set_parse_diag("dat")
    return (True, envelope, None)


def parse_docx(locator, metadata=None):
    """
    Parse DOCX artifact. Prefers index (artifact-scoped by source_file), fallback to parse_docx.
    Returns (ok, envelope, parser_warning_code).
    """
    metadata = metadata or {}
    _set_parse_diag("docx")
    resolved_locator, resolved_storage = _resolve_docx_locator(locator, metadata)
    current_filename = os.path.basename(resolved_locator) if resolved_locator else os.path.basename(locator) if locator else ""
    local_storage = resolved_storage or metadata.get("local_storage_path") or (os.path.dirname(resolved_locator) if resolved_locator else "")
    try:
        from MediBot.MediBot_docx_index import load_docx_schedule_index
        index_data = load_docx_schedule_index(local_storage)
        index_failure = _docx_index_failure_short_circuit(index_data, resolved_locator, current_filename)
        if index_failure:
            _set_parse_diag(
                "docx",
                index_failure.get("warning_code") or QA_PARSE_ERROR,
                index_failure.get("detail") or "docx index failure record blocks fallback parsing",
                index_failure.get("source_exception_class") or "DocxIndexFailure",
            )
            return (False, None, index_failure.get("warning_code") or QA_PARSE_ERROR)
        if index_data and index_data.get("schedules") and current_filename:
            raw_schedules = index_data.get("schedules", {})
            scoped_schedules = {}
            for date_str, entry in raw_schedules.items():
                if not isinstance(entry, dict):
                    continue
                current = entry.get("current")
                if not isinstance(current, dict):
                    continue
                if current.get("source_file") != current_filename:
                    continue
                patients = current.get("patients") or {}
                if patients:
                    scoped_schedules[date_str] = patients
            if scoped_schedules:
                envelope = {"source": "index", "schedules": scoped_schedules}
                _set_parse_diag("docx")
                return (True, envelope, None)
    except ImportError:
        pass
    except Exception as e:
        _set_parse_diag("docx", QA_PARSE_RUNTIME_ERROR, str(e), e.__class__.__name__)
        pass
    try:
        from MediBot.MediBot_docx_decoder import parse_docx
    except ImportError as e:
        _set_parse_diag("docx", QA_PARSE_IMPORT_ERROR, str(e), "ImportError")
        return (False, None, QA_PARSE_IMPORT_ERROR)
    ok, data, err = _safe_wrap_legacy(parse_docx, resolved_locator, None, capture_schedule_positions=False)
    if not ok:
        return (False, None, err or QA_PARSE_RUNTIME_ERROR)
    envelope = {"source": "parse_docx", "patient_data": data if isinstance(data, dict) else {}}
    _set_parse_diag("docx")
    return (True, envelope, None)


def get_parse_provider(artifact_class):
    """
    Return parse provider function for artifact_class, or None if unsupported.
    """
    providers = {
        "csv": parse_csv,
        "jsonl": parse_jsonl,
        "837": parse_x12,
        "dat": parse_dat,
        "docx": parse_docx,
    }
    return providers.get(artifact_class)


def parse_artifact(locator, artifact_class, metadata=None):
    """
    Parse artifact by class. Returns (ok, envelope, parser_warning_code).
    If artifact_class unsupported, returns (False, None, QA_UNKNOWN_ARTIFACT_CLASS).
    """
    provider = get_parse_provider(artifact_class)
    if provider is None:
        _set_parse_diag(str(artifact_class or ""), QA_UNKNOWN_ARTIFACT_CLASS, "unsupported class", "LookupError")
        return (False, None, QA_UNKNOWN_ARTIFACT_CLASS)
    return provider(locator, metadata)
