#!/usr/bin/env python
"""
Retrospective CPT <-> diagnosis analytics from saved 837P/X12 files.

Report-only, XP-compatible (Python 3.4.4, stdlib only).
"""
from __future__ import print_function

import argparse
import hashlib
import io
import json
import os
import sys
import time
import uuid

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

import x12_analytics_common as x12c


PAIR_SCHEMA_VERSION = "x12_cpt_dx_association_pair_v1"
SUMMARY_SCHEMA_VERSION = "x12_cpt_dx_association_summary_v1"
CROSSWALK_PROPOSAL_SCHEMA_VERSION = "x12_cpt_dx_crosswalk_proposal_v1"
CROSSWALK_DIAGNOSIS_TO_PROCEDURE_THRESHOLD = 0.90
CROSSWALK_LOW_SUPPORT_WARNING_COUNT = 5

CONFIDENCE_POINTER_RESOLVED = 0.98
CONFIDENCE_SINGLE_UNAMBIGUOUS = 0.85
CONFIDENCE_AMBIGUOUS_CANDIDATE = 0.65

WARNING_MISSING_HI = "missing_hi"
WARNING_MISSING_SV1 = "missing_sv1"
WARNING_POINTER_OUT_OF_RANGE = "pointer_out_of_range"
WARNING_MULTIPLE_DX_NO_POINTER = "multiple_dx_no_pointer"
WARNING_MALFORMED_SEGMENT = "malformed_segment"

X12_EXTENSIONS = set([".837p", ".837", ".x12", ".edi", ".txt"])
X12_TOKENS = ("ISA*", "GS*HC", "ST*837", "HI*", "SV1*")
PHI_FIELDS_SUPPRESSED = [
    "patient_name",
    "member_id",
    "member_dob",
    "full_local_path",
    "claim_number",
    "CLM01",
    "REF_6R",
]


def _to_text(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def _path_label(path):
    path = _to_text(path).strip()
    if not path:
        return ""
    base = os.path.basename(os.path.normpath(path))
    if base:
        return base
    drive, _tail = os.path.splitdrive(path)
    if drive:
        return drive
    return "root"


def make_run_id():
    ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    try:
        suffix = uuid.uuid4().hex[:8]
    except Exception:
        suffix = hashlib.sha256(_to_text(time.time()).encode("utf-8")).hexdigest()[:8]
    return "{0}-{1}".format(ts, suffix)


def iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def normalize_code(value):
    out = []
    for ch in _to_text(value).upper():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def split_x12_segments(text):
    segments = []
    for raw in _to_text(text).replace("\r", "\n").split("~"):
        segment = raw.strip()
        if segment:
            segments.append(segment)
    return segments


def _split_composites(field):
    return _to_text(field).split(":")


def _parse_hi_segment(segment, warnings):
    diagnoses = []
    fields = segment.split("*")
    if len(fields) < 2:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return diagnoses
    for field in fields[1:]:
        parts = _split_composites(field)
        if len(parts) < 2:
            if _to_text(field).strip():
                _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
            continue
        qualifier = parts[0].strip()
        diagnosis_code = normalize_code(parts[1])
        if qualifier and diagnosis_code:
            diagnoses.append({
                "qualifier": qualifier,
                "diagnosis_code": diagnosis_code,
            })
        else:
            _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
    return diagnoses


def _parse_sv1_segment(segment, warnings):
    fields = segment.split("*")
    if len(fields) < 2:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return None

    composite = _split_composites(fields[1])
    if len(composite) < 2:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return None

    qualifier = composite[0].strip()
    cpt_code = normalize_code(composite[1])
    if qualifier != "HC" or not cpt_code:
        _add_warning(warnings, WARNING_MALFORMED_SEGMENT)
        return None

    diagnosis_pointer = ""
    if len(fields) > 7:
        diagnosis_pointer = fields[7].strip()

    return {
        "cpt_code": cpt_code,
        "diagnosis_pointer": diagnosis_pointer,
    }


def _add_warning(warnings, code):
    if code not in warnings:
        warnings.append(code)


def _copy_warning_counts(warnings, warning_counts):
    for code in warnings:
        warning_counts[code] = int(warning_counts.get(code, 0) or 0) + 1


def _claim_records_from_segments(segments):
    claims = []
    current = None
    for segment in segments:
        if segment.startswith("ST*"):
            if current is not None:
                claims.append(current)
            current = {"segments": []}
        if current is None:
            continue
        current["segments"].append(segment)
        if segment.startswith("SE*"):
            claims.append(current)
            current = None
    if current is not None and current.get("segments"):
        claims.append(current)
    if not claims:
        has_claim_content = False
        for segment in segments:
            if segment.startswith("HI*") or segment.startswith("SV1*"):
                has_claim_content = True
                break
        if has_claim_content:
            claims.append({"segments": segments})
    return claims


def _claim_context(claim_segments):
    warnings = []
    diagnoses = []
    service_lines = []
    current_lx = ""

    for segment in claim_segments:
        if segment.startswith("HI*"):
            diagnoses.extend(_parse_hi_segment(segment, warnings))
        elif segment.startswith("LX*"):
            fields = segment.split("*")
            current_lx = fields[1].strip() if len(fields) > 1 else ""
        elif segment.startswith("SV1*"):
            parsed = _parse_sv1_segment(segment, warnings)
            if parsed is not None:
                parsed["lx"] = current_lx
                service_lines.append(parsed)

    if not diagnoses:
        _add_warning(warnings, WARNING_MISSING_HI)
    if not service_lines:
        _add_warning(warnings, WARNING_MISSING_SV1)

    return diagnoses, service_lines, warnings


def _pointer_indices(pointer_text):
    pointer_text = _to_text(pointer_text).strip()
    if not pointer_text:
        return []
    values = []
    for part in pointer_text.replace(":", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            idx = int(part)
        except Exception:
            values.append(None)
            continue
        values.append(idx)
    return values


def _pairs_for_service_line(source_meta, diagnoses, service_line, claim_warnings, line_count):
    cpt_code = service_line.get("cpt_code", "")
    if not cpt_code or not diagnoses:
        return [], []

    pointer_text = service_line.get("diagnosis_pointer", "")
    indices = _pointer_indices(pointer_text)
    rows = []
    extra_warnings = []

    if indices:
        for idx in indices:
            warning_codes = list(claim_warnings)
            if idx is None or idx < 1 or idx > len(diagnoses):
                _add_warning(extra_warnings, WARNING_POINTER_OUT_OF_RANGE)
                continue
            dx = diagnoses[idx - 1]
            rows.append(_pair_row(
                source_meta, cpt_code, dx, pointer_text,
                "sv1_pointer_to_hi", CONFIDENCE_POINTER_RESOLVED,
                warning_codes, line_count))
        return rows, extra_warnings

    if len(diagnoses) == 1:
        rows.append(_pair_row(
            source_meta, cpt_code, diagnoses[0], "",
            "single_hi_single_or_unpointed_sv1", CONFIDENCE_SINGLE_UNAMBIGUOUS,
            list(claim_warnings), line_count))
        return rows, extra_warnings

    for dx in diagnoses:
        warning_codes = list(claim_warnings)
        _add_warning(warning_codes, WARNING_MULTIPLE_DX_NO_POINTER)
        rows.append(_pair_row(
            source_meta, cpt_code, dx, "",
            "multiple_hi_no_pointer_candidate", CONFIDENCE_AMBIGUOUS_CANDIDATE,
            warning_codes, line_count))
    return rows, extra_warnings


def _pair_row(source_meta, cpt_code, diagnosis, diagnosis_pointer, basis, confidence, warning_codes, line_count):
    return {
        "schema_version": PAIR_SCHEMA_VERSION,
        "run_id": source_meta.get("run_id", ""),
        "source_file_basename": source_meta.get("source_file_basename", ""),
        "source_file_sha256_prefix": source_meta.get("source_file_sha256_prefix", ""),
        "cpt_code": cpt_code,
        "diagnosis_code": diagnosis.get("diagnosis_code", ""),
        "diagnosis_qualifier": diagnosis.get("qualifier", ""),
        "diagnosis_pointer": diagnosis_pointer,
        "association_basis": basis,
        "confidence": confidence,
        "warning_codes": warning_codes,
        "line_count_in_claim": line_count,
    }


def parse_x12_cpt_dx_pairs(text, source_meta):
    segments = split_x12_segments(text)
    claims = _claim_records_from_segments(segments)
    pairs = []
    warning_counts = {}
    total_service_lines = 0
    service_lines_with_association = 0

    for claim in claims:
        diagnoses, service_lines, claim_warnings = _claim_context(claim.get("segments") or [])
        total_service_lines += len(service_lines)
        _copy_warning_counts(claim_warnings, warning_counts)
        for service_line in service_lines:
            line_pairs, extra_warnings = _pairs_for_service_line(
                source_meta, diagnoses, service_line, claim_warnings, len(service_lines))
            _copy_warning_counts(extra_warnings, warning_counts)
            if line_pairs:
                service_lines_with_association += 1
            for row in line_pairs:
                pairs.append(row)
                _copy_warning_counts(row.get("warning_codes") or [], warning_counts)

    return {
        "claims": len(claims),
        "service_lines": total_service_lines,
        "service_lines_with_association": service_lines_with_association,
        "pairs": pairs,
        "warning_counts": warning_counts,
    }


def looks_like_x12_claim_text(text):
    if not text:
        return False
    score = 0
    for token in X12_TOKENS:
        if token in text:
            score += 1
    return score >= 2 and ("SV1*" in text or "HI*" in text)


def _read_file_text(path, max_bytes=None):
    mode = "rb"
    with open(path, mode) as f:
        if max_bytes:
            data = f.read(max_bytes)
        else:
            data = f.read()
    try:
        return data.decode("utf-8", "replace")
    except Exception:
        try:
            return data.decode("latin-1", "replace")
        except Exception:
            return ""


def sha256_prefix_for_file(path, prefix_len=16):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()[:prefix_len]


def iter_candidate_x12_files(roots):
    seen = set()
    for root in roots:
        if not root:
            continue
        root = os.path.abspath(root)
        if os.path.isfile(root):
            candidates = [root]
        else:
            candidates = []
            for dirpath, dirnames, filenames in os.walk(root):
                for filename in filenames:
                    candidates.append(os.path.join(dirpath, filename))
        for path in candidates:
            key = os.path.normcase(os.path.abspath(path))
            if key in seen:
                continue
            seen.add(key)
            _, ext = os.path.splitext(path.lower())
            try:
                preview = _read_file_text(path, max_bytes=16384)
            except Exception:
                continue
            if ext in X12_EXTENSIONS or "837" in os.path.basename(path).lower():
                if looks_like_x12_claim_text(preview):
                    yield path
            elif looks_like_x12_claim_text(preview):
                yield path


def _is_submission_index_entry(row):
    if not isinstance(row, dict):
        return False
    notes = _to_text(row.get("notes")).strip()
    record_type = _to_text(row.get("record_type")).strip()
    if notes == "ack event" or record_type == "ack_event":
        return False
    return (not record_type) or record_type == "submission"


def _submission_index_path(receipts_root):
    return os.path.join(receipts_root, "submission_index.jsonl")


def _resolve_receipt_path(receipts_root, receipt_file):
    receipt_file = _to_text(receipt_file).strip()
    if not receipt_file:
        return ""
    if os.path.isabs(receipt_file):
        return os.path.normpath(receipt_file)
    if receipts_root:
        return os.path.normpath(os.path.join(receipts_root, receipt_file))
    return os.path.normpath(receipt_file)


def _increment_nested_count(bucket, first, second, confidence):
    first_map = bucket.get(first)
    if first_map is None:
        first_map = {}
        bucket[first] = first_map
    item = first_map.get(second)
    if item is None:
        item = {"count": 0, "confidence_weighted_support": 0.0}
        first_map[second] = item
    item["count"] = int(item.get("count", 0) or 0) + 1
    item["confidence_weighted_support"] = float(item.get("confidence_weighted_support", 0.0) or 0.0) + float(confidence or 0.0)


def _finalize_probability_map(bucket):
    out = {}
    for first in sorted(bucket.keys()):
        inner = bucket[first]
        total = 0
        for second in inner:
            total += int(inner[second].get("count", 0) or 0)
        rows = []
        for second in sorted(inner.keys()):
            count = int(inner[second].get("count", 0) or 0)
            weighted = float(inner[second].get("confidence_weighted_support", 0.0) or 0.0)
            prob = 0.0
            if total:
                prob = float(count) / float(total)
            rows.append({
                "code": second,
                "count": count,
                "probability": round(prob, 6),
                "confidence_weighted_support": round(weighted, 6),
            })
        rows.sort(key=lambda r: (-int(r.get("count", 0) or 0), r.get("code", "")))
        out[first] = {
            "total_pairs": total,
            "associations": rows,
        }
    return out


def load_procedure_to_diagnosis(crosswalk_path):
    if not crosswalk_path or not os.path.exists(crosswalk_path):
        return {}
    try:
        with io.open(crosswalk_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    proc_map = data.get("procedure_to_diagnosis") if isinstance(data, dict) else {}
    if not isinstance(proc_map, dict):
        return {}
    out = {}
    for proc in proc_map:
        proc_norm = normalize_code(proc)
        values = proc_map.get(proc)
        dxs = []
        if isinstance(values, list):
            for value in values:
                dx_norm = normalize_code(value)
                if dx_norm:
                    dxs.append(dx_norm)
        if proc_norm:
            out[proc_norm] = sorted(list(set(dxs)))
    return out


def load_diagnosis_to_procedure(crosswalk_path):
    if not crosswalk_path or not os.path.exists(crosswalk_path):
        return {}
    try:
        with io.open(crosswalk_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    dx_map = data.get("diagnosis_to_procedure") if isinstance(data, dict) else {}
    if not isinstance(dx_map, dict):
        return {}
    out = {}
    for dx in dx_map:
        dx_norm = normalize_code(dx)
        cpt_norm = normalize_code(dx_map.get(dx))
        if dx_norm and cpt_norm:
            out[dx_norm] = cpt_norm
    return out


def _diagnosis_display_code(value):
    code = normalize_code(value)
    if len(code) <= 3:
        return code
    if code and code[0].isalpha():
        return "{0}.{1}".format(code[:3], code[3:])
    return code


def _bridge_record_key(record):
    return "{0}|{1}|{2}".format(
        record.get("diagnosis_code_normalized", ""),
        record.get("medisoft_code_normalized", ""),
        record.get("bridge_match_side", ""),
    )


def load_diagnosis_to_medisoft(crosswalk_path):
    if not crosswalk_path or not os.path.exists(crosswalk_path):
        return {}
    try:
        with io.open(crosswalk_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    medisoft_map = data.get("diagnosis_to_medisoft") if isinstance(data, dict) else {}
    if not isinstance(medisoft_map, dict):
        return {}
    out = {}
    seen = set()
    for dx in medisoft_map:
        dx_norm = normalize_code(dx)
        medisoft_norm = normalize_code(medisoft_map.get(dx))
        if not dx_norm or not medisoft_norm:
            continue
        base_record = {
            "diagnosis_code": _diagnosis_display_code(dx_norm),
            "diagnosis_code_normalized": dx_norm,
            "medisoft_code": _to_text(medisoft_map.get(dx)).strip().upper(),
            "medisoft_code_normalized": medisoft_norm,
        }
        for match_norm, side in ((dx_norm, "diagnosis_key"), (medisoft_norm, "medisoft_value")):
            record = dict(base_record)
            record["bridge_match_side"] = side
            key = "{0}|{1}".format(match_norm, _bridge_record_key(record))
            if key in seen:
                continue
            seen.add(key)
            out.setdefault(match_norm, []).append(record)
    for code in out:
        out[code] = sorted(out.get(code) or [], key=lambda r: (
            r.get("diagnosis_code_normalized", ""),
            r.get("medisoft_code_normalized", ""),
            r.get("bridge_match_side", ""),
        ))
    return out


def format_icd10_code(value):
    """Return a crosswalk-friendly ICD-10 display code from an X12/no-dot code."""
    return _diagnosis_display_code(value)


def _safe_crosswalk_pair(row):
    if not isinstance(row, dict):
        return False
    if row.get("association_basis") == "multiple_hi_no_pointer_candidate":
        return False
    warning_codes = row.get("warning_codes") or []
    if WARNING_MULTIPLE_DX_NO_POINTER in warning_codes:
        return False
    return bool(normalize_code(row.get("cpt_code")) and normalize_code(row.get("diagnosis_code")))


def _service_line_input_event_after(event):
    if not isinstance(event, dict):
        return {}
    after = event.get("effective_after")
    if isinstance(after, dict):
        return after
    after = event.get("after")
    if isinstance(after, dict):
        return after
    return {}


def service_line_input_correction_pairs_from_state(state, run_id=None):
    """Return sanitized CPT/DX proposal evidence from SLI overlay events."""
    if not isinstance(state, dict):
        return []
    pairs = []
    events = state.get("events") if isinstance(state.get("events"), list) else []
    for event in events:
        if not isinstance(event, dict):
            continue
        if event.get("workflow_boundary") != "preview_only_review_required":
            continue
        if bool(event.get("claims_completion")) or bool(event.get("mutates_billing_state")):
            continue
        if bool(event.get("mutates_dat")) or bool(event.get("mutates_837p")):
            continue
        if bool(event.get("charges_entered")):
            continue
        after = _service_line_input_event_after(event)
        diagnosis = normalize_code(
            after.get("diagnosis_code")
            or after.get("diagnosis")
            or event.get("diagnosis_code")
            or ""
        )
        cpt = normalize_code(
            after.get("cpt_code")
            or after.get("cpt")
            or event.get("cpt_code")
            or ""
        )
        if not diagnosis or not cpt:
            continue
        identity = event.get("target_identity") if isinstance(event.get("target_identity"), dict) else {}
        pairs.append({
            "schema_version": PAIR_SCHEMA_VERSION,
            "run_id": run_id or event.get("service_line_input_session_id", ""),
            "source_file_basename": "service_line_input_overlay",
            "source_file_sha256_prefix": "",
            "cpt_code": cpt,
            "diagnosis_code": diagnosis,
            "diagnosis_qualifier": "SLI",
            "diagnosis_pointer": "",
            "association_basis": "service_line_input_operator_overlay",
            "confidence": 0.99,
            "warning_codes": [],
            "line_count_in_claim": 1,
            "service_line_input_session_id": event.get("service_line_input_session_id", ""),
            "patient_id_present": bool(identity.get("patient_id")),
            "dos_present": bool(identity.get("dos")),
            "workflow_boundary": "report_only_review_required",
            "claim_workflow_completion": False,
            "mutates_billing_state": False,
            "mutates_dat": False,
            "mutates_837p": False,
            "charges_entered": False,
        })
    return pairs


def load_service_line_input_correction_pairs(path, run_id=None):
    if not path or not os.path.exists(path):
        return []
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception:
        return []
    return service_line_input_correction_pairs_from_state(state, run_id=run_id)


def _top_probability_row(bucket):
    associations = bucket.get("associations") if isinstance(bucket, dict) else []
    if not associations:
        return {}
    return associations[0]


def _proposal_count_rows(mapping):
    total = 0
    for _key in mapping or {}:
        total += len(mapping.get(_key) or [])
    return total


def _pair_source_surface(row):
    basis = _to_text(row.get("association_basis")).strip()
    if basis == "service_line_input_operator_overlay":
        return "service_line_input_operator_overlay"
    if basis:
        return basis
    return "submitted_837p_analytics"


def _bridge_reverse_ambiguities(diagnosis_to_medisoft):
    by_medisoft = {}
    if not isinstance(diagnosis_to_medisoft, dict):
        return []
    for match_norm in diagnosis_to_medisoft:
        for record in diagnosis_to_medisoft.get(match_norm) or []:
            if record.get("bridge_match_side") != "medisoft_value":
                continue
            medisoft_norm = normalize_code(record.get("medisoft_code_normalized"))
            dx_norm = normalize_code(record.get("diagnosis_code_normalized"))
            if not medisoft_norm or not dx_norm:
                continue
            bucket = by_medisoft.get(medisoft_norm)
            if bucket is None:
                bucket = {}
                by_medisoft[medisoft_norm] = bucket
            bucket[dx_norm] = {
                "diagnosis_code": record.get("diagnosis_code", ""),
                "diagnosis_code_normalized": dx_norm,
                "medisoft_code": record.get("medisoft_code", ""),
                "medisoft_code_normalized": medisoft_norm,
            }
    rows = []
    for medisoft_norm in sorted(by_medisoft.keys()):
        bucket = by_medisoft.get(medisoft_norm) or {}
        if len(bucket.keys()) <= 1:
            continue
        rows.append({
            "medisoft_code": bucket[sorted(bucket.keys())[0]].get("medisoft_code", medisoft_norm),
            "medisoft_code_normalized": medisoft_norm,
            "diagnosis_codes": [bucket[key].get("diagnosis_code", "") for key in sorted(bucket.keys())],
            "diagnosis_code_normalized_values": sorted(bucket.keys()),
            "review_required": True,
        })
    return rows


def _suggest_unconfirmed_medisoft_shorthand(diagnosis_code):
    text = str(diagnosis_code or "").strip().upper()
    if not text:
        return ""
    try:
        candidate = text.lstrip("H").lstrip("T8").replace(".", "")[-5:]
    except Exception:
        return ""
    return candidate


def build_diagnosis_to_medisoft_bridge_completeness(pairs, diagnosis_to_medisoft):
    by_dx = {}
    for row in pairs or []:
        if not _safe_crosswalk_pair(row):
            continue
        dx = normalize_code(row.get("diagnosis_code"))
        cpt = normalize_code(row.get("cpt_code"))
        if not dx:
            continue
        item = by_dx.get(dx)
        if item is None:
            item = {
                "diagnosis_code": _diagnosis_display_code(dx),
                "diagnosis_code_normalized": dx,
                "associated_cpt_codes": set(),
                "source_surfaces": set(),
                "support_count": 0,
            }
            by_dx[dx] = item
        if cpt:
            item["associated_cpt_codes"].add(cpt)
        item["source_surfaces"].add(_pair_source_surface(row))
        item["support_count"] = int(item.get("support_count", 0) or 0) + 1

    rows = []
    missing_rows = []
    present_rows = []
    ambiguous_rows = []
    reverse_ambiguity_rows = _bridge_reverse_ambiguities(diagnosis_to_medisoft)
    ambiguous_medisoft_values = set([
        row.get("medisoft_code_normalized", "")
        for row in reverse_ambiguity_rows
        if row.get("medisoft_code_normalized", "")
    ])
    for dx in sorted(by_dx.keys()):
        item = by_dx.get(dx) or {}
        bridge_rows = diagnosis_to_medisoft.get(dx) if isinstance(diagnosis_to_medisoft, dict) else []
        if bridge_rows is None:
            bridge_rows = []
        bridge_status = "present" if bridge_rows else "missing"
        bridge_ambiguous = False
        for bridge_row in bridge_rows:
            medisoft_norm = normalize_code(bridge_row.get("medisoft_code_normalized"))
            if medisoft_norm and medisoft_norm in ambiguous_medisoft_values:
                bridge_ambiguous = True
                break
        row = {
            "diagnosis_code": item.get("diagnosis_code", ""),
            "diagnosis_code_normalized": dx,
            "associated_cpt_codes": sorted(list(item.get("associated_cpt_codes") or [])),
            "source_surfaces": sorted(list(item.get("source_surfaces") or [])),
            "support_count": int(item.get("support_count", 0) or 0),
            "bridge_status": bridge_status,
            "bridge_ambiguous": bridge_ambiguous,
            "diagnosis_to_medisoft_matches": bridge_rows,
            "requires_crosswalk_review": bridge_status == "missing",
        }
        if bridge_ambiguous:
            row["requires_crosswalk_review"] = True
        rows.append(row)
        if bridge_status == "missing":
            missing_rows.append(row)
        else:
            present_rows.append(row)
        if bridge_ambiguous:
            ambiguous_rows.append(row)

    repair_guidance_rows = []
    for row in missing_rows:
        guidance = {
            "diagnosis_code": row.get("diagnosis_code", ""),
            "diagnosis_code_normalized": row.get("diagnosis_code_normalized", ""),
            "associated_cpt_codes": row.get("associated_cpt_codes") or [],
            "support_count": int(row.get("support_count", 0) or 0),
            "source_surfaces": row.get("source_surfaces") or [],
            "unconfirmed_medisoft_code": _suggest_unconfirmed_medisoft_shorthand(row.get("diagnosis_code") or row.get("diagnosis_code_normalized")),
            "suggestion_source": "legacy_heuristic_unconfirmed",
            "recommended_resolution": "confirm diagnosis_to_medisoft bridge through Service Line Input unknown-code intake or a dedicated config-maintenance flow",
            "auto_apply": False,
        }
        repair_guidance_rows.append(guidance)

    return {
        "schema_version": "diagnosis_to_medisoft_bridge_completeness_v1",
        "workflow_boundary": "report_only_review_required",
        "claim_workflow_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
        "bridge_apply_policy": "report_only_not_auto_applied",
        "diagnosis_count": len(rows),
        "bridge_present_count": len(present_rows),
        "bridge_missing_count": len(missing_rows),
        "bridge_ambiguous_count": len(ambiguous_rows),
        "rows": rows,
        "missing_rows": missing_rows,
        "ambiguous_rows": ambiguous_rows,
        "reverse_ambiguity_rows": reverse_ambiguity_rows,
        "repair_guidance_rows": repair_guidance_rows,
    }


def build_crosswalk_proposal(run_id, summary, pairs, procedure_to_diagnosis, diagnosis_to_procedure,
                             diagnosis_to_medisoft=None):
    cpt_to_dx = {}
    dx_to_cpt = {}
    observed_pairs = set()
    service_line_input_correction_pair_count = 0
    for row in pairs or []:
        if not _safe_crosswalk_pair(row):
            continue
        if row.get("association_basis") == "service_line_input_operator_overlay":
            service_line_input_correction_pair_count += 1
        cpt = normalize_code(row.get("cpt_code"))
        dx = normalize_code(row.get("diagnosis_code"))
        observed_pairs.add((cpt, dx))
        _increment_nested_count(cpt_to_dx, cpt, dx, row.get("confidence"))
        _increment_nested_count(dx_to_cpt, dx, cpt, row.get("confidence"))

    cpt_to_dx_final = _finalize_probability_map(cpt_to_dx)
    dx_to_cpt_final = _finalize_probability_map(dx_to_cpt)

    proposed_dx_to_proc = {}
    eligible_rows = []
    conflict_rows = []
    low_support_rows = []
    already_present_rows = []
    threshold = CROSSWALK_DIAGNOSIS_TO_PROCEDURE_THRESHOLD

    for dx in sorted(dx_to_cpt_final.keys()):
        bucket = dx_to_cpt_final.get(dx) or {}
        top = _top_probability_row(bucket)
        if not top:
            continue
        probability = float(top.get("probability", 0.0) or 0.0)
        if probability < threshold:
            continue
        cpt = normalize_code(top.get("code"))
        count = int(top.get("count", 0) or 0)
        row = {
            "diagnosis_code": format_icd10_code(dx),
            "diagnosis_code_normalized": dx,
            "cpt_code": cpt,
            "probability": probability,
            "support_count": count,
            "total_pairs": int(bucket.get("total_pairs", 0) or 0),
            "confidence_weighted_support": float(top.get("confidence_weighted_support", 0.0) or 0.0),
            "status": "eligible",
            "warning_codes": [],
        }
        if count < CROSSWALK_LOW_SUPPORT_WARNING_COUNT:
            row["warning_codes"].append("low_support")
            low_support_rows.append(dict(row))
        existing = diagnosis_to_procedure.get(dx)
        if existing and existing != cpt:
            row["status"] = "conflict_requires_review"
            row["existing_cpt_code"] = existing
            conflict_rows.append(row)
            continue
        if existing == cpt:
            row["status"] = "already_present"
            already_present_rows.append(row)
        else:
            eligible_rows.append(row)
        proposed_dx_to_proc[row["diagnosis_code"]] = cpt

    proc_additions = {}
    proc_addition_rows = []
    baseline = procedure_to_diagnosis or {}
    for cpt in sorted(cpt_to_dx_final.keys()):
        current = set(baseline.get(cpt) or [])
        bucket = cpt_to_dx_final.get(cpt) or {}
        for assoc in bucket.get("associations") or []:
            dx = normalize_code(assoc.get("code"))
            if not dx or dx in current:
                continue
            display_dx = format_icd10_code(dx)
            proc_additions.setdefault(cpt, []).append(display_dx)
            row = {
                "cpt_code": cpt,
                "diagnosis_code": display_dx,
                "diagnosis_code_normalized": dx,
                "probability_within_cpt": float(assoc.get("probability", 0.0) or 0.0),
                "support_count": int(assoc.get("count", 0) or 0),
                "confidence_weighted_support": float(assoc.get("confidence_weighted_support", 0.0) or 0.0),
                "status": "eligible",
                "warning_codes": [],
            }
            if row["support_count"] < CROSSWALK_LOW_SUPPORT_WARNING_COUNT:
                row["warning_codes"].append("low_support")
            proc_addition_rows.append(row)

    for cpt in proc_additions:
        proc_additions[cpt] = sorted(list(set(proc_additions.get(cpt) or [])))

    baseline_comparison = summary.get("baseline_comparison") if isinstance(summary, dict) else {}
    unsupported = baseline_comparison.get("baseline_pairs_without_observed_support") if isinstance(baseline_comparison, dict) else []

    bridge_completeness = build_diagnosis_to_medisoft_bridge_completeness(
        pairs,
        diagnosis_to_medisoft or {},
    )

    return {
        "schema_version": CROSSWALK_PROPOSAL_SCHEMA_VERSION,
        "run_id": run_id,
        "generated_at_utc": iso_utc_now(),
        "workflow_boundary": "report_only_review_required",
        "claim_workflow_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
        "requires_apply_confirmation": True,
        "thresholds": {
            "diagnosis_to_procedure_min_probability": threshold,
            "minimum_support_for_warning_only": CROSSWALK_LOW_SUPPORT_WARNING_COUNT,
            "minimum_support_for_eligibility": 1,
            "ambiguous_candidate_pairs_excluded": True,
            "service_line_input_operator_overlay_allowed": True,
        },
        "diagnosis_to_procedure": proposed_dx_to_proc,
        "diagnosis_to_procedure_eligible": eligible_rows,
        "diagnosis_to_procedure_already_present": already_present_rows,
        "diagnosis_to_procedure_conflicts": conflict_rows,
        "low_support_warnings": low_support_rows,
        "procedure_to_diagnosis_additions": proc_additions,
        "procedure_to_diagnosis_addition_rows": proc_addition_rows,
        "diagnosis_to_medisoft_bridge_completeness": bridge_completeness,
        "maintenance": {
            "baseline_pairs_without_observed_support": unsupported or [],
            "baseline_pairs_not_removed_by_policy": True,
        },
        "apply_summary": {
            "eligible_diagnosis_to_procedure_count": len(eligible_rows),
            "eligible_procedure_to_diagnosis_pair_count": _proposal_count_rows(proc_additions),
            "conflict_count": len(conflict_rows),
            "low_support_warning_count": len(low_support_rows),
            "already_present_count": len(already_present_rows),
            "service_line_input_correction_pair_count": service_line_input_correction_pair_count,
            "diagnosis_to_medisoft_bridge_present_count": int(bridge_completeness.get("bridge_present_count", 0) or 0),
            "diagnosis_to_medisoft_bridge_missing_count": int(bridge_completeness.get("bridge_missing_count", 0) or 0),
            "diagnosis_to_medisoft_bridge_ambiguous_count": int(bridge_completeness.get("bridge_ambiguous_count", 0) or 0),
        },
        "breadcrumbs": {
            "service_line_input_cpt_suggestions": True,
            "service_line_input_operator_overlay_evidence": service_line_input_correction_pair_count > 0,
            "minutes_charge_analytics_future_crosswalk_surface": True,
            "charges_tool_future_rule_surface": True,
        },
    }


def build_baseline_comparison(procedure_to_diagnosis, observed_pairs):
    observed_by_cpt = {}
    observed_pairs_set = set()
    for row in observed_pairs:
        cpt = normalize_code(row.get("cpt_code"))
        dx = normalize_code(row.get("diagnosis_code"))
        if not cpt or not dx:
            continue
        if cpt not in observed_by_cpt:
            observed_by_cpt[cpt] = set()
        observed_by_cpt[cpt].add(dx)
        observed_pairs_set.add((cpt, dx))

    baseline_pairs = set()
    for proc in procedure_to_diagnosis:
        for dx in procedure_to_diagnosis.get(proc) or []:
            baseline_pairs.add((proc, dx))

    observed_cpts = set(observed_by_cpt.keys())
    baseline_cpts = set(procedure_to_diagnosis.keys())

    missing_from_baseline = []
    for cpt, dx in sorted(observed_pairs_set):
        if (cpt, dx) not in baseline_pairs:
            missing_from_baseline.append({"cpt_code": cpt, "diagnosis_code": dx})

    baseline_without_support = []
    for cpt, dx in sorted(baseline_pairs):
        if (cpt, dx) not in observed_pairs_set:
            baseline_without_support.append({"cpt_code": cpt, "diagnosis_code": dx})

    return {
        "baseline_procedure_count": len(baseline_cpts),
        "baseline_pair_count": len(baseline_pairs),
        "observed_cpt_not_in_baseline": sorted(list(observed_cpts - baseline_cpts)),
        "baseline_cpt_not_observed": sorted(list(baseline_cpts - observed_cpts)),
        "observed_pairs_missing_from_baseline": missing_from_baseline,
        "baseline_pairs_without_observed_support": baseline_without_support,
    }


def build_summary(run_id, scan_roots, file_results, all_pairs, warning_counts, procedure_to_diagnosis):
    cpt_to_dx = {}
    dx_to_cpt = {}
    distinct_cpts = set()
    distinct_dxs = set()
    claims = 0
    service_lines = 0
    service_lines_with_association = 0
    parsed_files = 0
    rejected_files = 0

    for result in file_results:
        if result.get("parsed"):
            parsed_files += 1
        else:
            rejected_files += 1
        claims += int(result.get("claims", 0) or 0)
        service_lines += int(result.get("service_lines", 0) or 0)
        service_lines_with_association += int(result.get("service_lines_with_association", 0) or 0)

    for row in all_pairs:
        cpt = normalize_code(row.get("cpt_code"))
        dx = normalize_code(row.get("diagnosis_code"))
        if not cpt or not dx:
            continue
        distinct_cpts.add(cpt)
        distinct_dxs.add(dx)
        _increment_nested_count(cpt_to_dx, cpt, dx, row.get("confidence"))
        _increment_nested_count(dx_to_cpt, dx, cpt, row.get("confidence"))

    summary = {
        "schema_version": SUMMARY_SCHEMA_VERSION,
        "run_id": run_id,
        "generated_at_utc": iso_utc_now(),
        "scan_root_count": len(scan_roots or []),
        "scan_root_labels": [_path_label(p) for p in (scan_roots or [])],
        "files_scanned": len(file_results),
        "files_parsed": parsed_files,
        "files_rejected": rejected_files,
        "total_claims": claims,
        "total_service_lines": service_lines,
        "service_lines_with_association": service_lines_with_association,
        "total_pairs": len(all_pairs),
        "distinct_cpt_count": len(distinct_cpts),
        "distinct_diagnosis_count": len(distinct_dxs),
        "warning_totals": warning_counts,
        "workflow_boundary": "report_only_review_required",
        "claim_workflow_completion": False,
        "operational_charge_update": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "cpt_to_diagnosis": _finalize_probability_map(cpt_to_dx),
        "diagnosis_to_cpt": _finalize_probability_map(dx_to_cpt),
        "baseline_comparison": build_baseline_comparison(procedure_to_diagnosis, all_pairs),
        "privacy": {
            "phi_fields_suppressed": PHI_FIELDS_SUPPRESSED,
            "hash_policy": "sha256 prefix, first 16 hex chars",
            "sample_rows_are_sanitized": True,
        },
    }
    if service_lines:
        summary["service_line_association_rate"] = round(float(service_lines_with_association) / float(service_lines), 6)
    else:
        summary["service_line_association_rate"] = 0.0
    if parsed_files:
        summary["average_claims_per_parsed_file"] = round(float(claims) / float(parsed_files), 6)
        summary["average_service_lines_per_parsed_file"] = round(float(service_lines) / float(parsed_files), 6)
    else:
        summary["average_claims_per_parsed_file"] = 0.0
        summary["average_service_lines_per_parsed_file"] = 0.0
    return summary


def build_health_telemetry(summary):
    core = x12c.build_report_only_health_telemetry_core(summary, {
        "observed_count_key": "service_lines_with_association",
        "emitted_count_key": "total_pairs",
        "low_rate_reason": "service_line_association_rate_below_80_percent",
        "success_reason": "candidate_files_parsed_with_high_service_line_association",
    })

    return {
        "trust_level": core["trust_level"],
        "trust_reasons": core["trust_reasons"],
        "processed_837p_file_count": core["processed_837p_file_count"],
        "parsed_837p_file_count": core["parsed_837p_file_count"],
        "claim_loop_count": core["claim_loop_count"],
        "service_line_count": core["service_line_count"],
        "service_lines_with_association": core["observed_count"],
        "service_lines_without_association": core["missing_count"],
        "service_line_association_rate": core["rate_value"],
        "emitted_pair_count": core["emitted_count"],
        "submission_index_existing_receipt_files": core["submission_index_existing_receipt_files"],
        "fallback_content_scan_candidates": core["fallback_content_scan_candidates"],
    }


def _merge_warning_counts(target, source):
    for code in source:
        target[code] = int(target.get(code, 0) or 0) + int(source.get(code, 0) or 0)


def analyze_files(paths, run_id):
    file_results = []
    all_pairs = []
    warning_counts = {}
    for item in paths:
        if isinstance(item, dict):
            path = item.get("path", "")
            sources = item.get("sources") or []
        else:
            path = item
            sources = []
        result = {
            "source_file_basename": os.path.basename(path),
            "inventory_sources": list(sources),
            "parsed": False,
            "claims": 0,
            "service_lines": 0,
            "service_lines_with_association": 0,
            "warning_counts": {},
        }
        try:
            text = _read_file_text(path)
            file_hash_prefix = sha256_prefix_for_file(path)
            source_meta = {
                "run_id": run_id,
                "source_file_basename": os.path.basename(path),
                "source_file_sha256_prefix": file_hash_prefix,
            }
            parsed = parse_x12_cpt_dx_pairs(text, source_meta)
            result["source_file_sha256_prefix"] = file_hash_prefix
            result["claims"] = parsed.get("claims", 0)
            result["service_lines"] = parsed.get("service_lines", 0)
            result["service_lines_with_association"] = parsed.get("service_lines_with_association", 0)
            result["warning_counts"] = parsed.get("warning_counts") or {}
            result["parsed"] = bool(parsed.get("claims") or parsed.get("service_lines") or parsed.get("pairs"))
            for row in parsed.get("pairs") or []:
                all_pairs.append(row)
            _merge_warning_counts(warning_counts, result["warning_counts"])
        except Exception:
            result["parsed"] = False
            result["warning_counts"] = {WARNING_MALFORMED_SEGMENT: 1}
            _merge_warning_counts(warning_counts, result["warning_counts"])
        file_results.append(result)
    return file_results, all_pairs, warning_counts


def _ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def write_reports(lab_dir, run_id, summary, pairs):
    reports_dir = os.path.join(lab_dir, "reports")
    _ensure_dir(reports_dir)
    summary_json = os.path.join(reports_dir, "x12_cpt_dx_association_summary_{0}.json".format(run_id))
    summary_txt = os.path.join(reports_dir, "x12_cpt_dx_association_summary_{0}.txt".format(run_id))
    pairs_jsonl = os.path.join(reports_dir, "x12_cpt_dx_association_pairs_{0}.jsonl".format(run_id))
    proposal_json = os.path.join(reports_dir, "x12_cpt_dx_crosswalk_proposal_{0}.json".format(run_id))
    proposal_txt = os.path.join(reports_dir, "x12_cpt_dx_crosswalk_proposal_{0}.txt".format(run_id))

    with io.open(summary_json, "w", encoding="utf-8") as f:
        f.write(json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=True))
        f.write("\n")

    with io.open(pairs_jsonl, "w", encoding="utf-8") as f:
        for row in pairs:
            f.write(json.dumps(row, sort_keys=True, ensure_ascii=True, separators=(",", ":")))
            f.write("\n")

    with io.open(summary_txt, "w", encoding="utf-8") as f:
        for line in format_summary_lines(summary):
            f.write(line)
            f.write("\n")

    proposal = summary.get("crosswalk_proposal") if isinstance(summary, dict) else {}
    if isinstance(proposal, dict):
        with io.open(proposal_json, "w", encoding="utf-8") as f:
            f.write(json.dumps(proposal, indent=2, sort_keys=True, ensure_ascii=True))
            f.write("\n")
        with io.open(proposal_txt, "w", encoding="utf-8") as f:
            for line in format_crosswalk_proposal_lines(proposal):
                f.write(line)
                f.write("\n")

    summary["artifacts"] = {
        "summary_json": summary_json,
        "summary_txt": summary_txt,
        "pairs_jsonl": pairs_jsonl,
        "proposal_json": proposal_json,
        "proposal_txt": proposal_txt,
    }
    return summary["artifacts"]


def _fmt_percent(value):
    try:
        return "{0:.1f}%".format(float(value or 0.0) * 100.0)
    except Exception:
        return "0.0%"


def _fmt_float(value, digits=2):
    try:
        return ("{0:." + str(int(digits)) + "f}").format(float(value or 0.0))
    except Exception:
        return "0.00"


def _top_association_rows(mapping, max_rows=12):
    collected = []
    for left in (mapping or {}):
        bucket = mapping.get(left) or {}
        total = int(bucket.get("total_pairs", 0) or 0)
        for assoc in bucket.get("associations") or []:
            collected.append({
                "left": left,
                "right": assoc.get("code", ""),
                "count": int(assoc.get("count", 0) or 0),
                "probability": float(assoc.get("probability", 0.0) or 0.0),
                "weighted": float(assoc.get("confidence_weighted_support", 0.0) or 0.0),
                "left_total": total,
            })
    collected.sort(key=lambda r: (
        -int(r.get("count", 0) or 0),
        -float(r.get("probability", 0.0) or 0.0),
        r.get("left", ""),
        r.get("right", ""),
    ))
    return collected[:max_rows]


def format_operator_summary_lines(summary, max_rows=5):
    health = summary.get("health_telemetry") or {}
    proposal = summary.get("crosswalk_proposal") or {}
    apply_summary = proposal.get("apply_summary") if isinstance(proposal, dict) else {}
    lines = []
    lines.append("CPT/Diagnosis Review Results")
    lines.append("Files: {0} analyzed ({1} parsed, {2} rejected)".format(
        _fmt_count(summary.get("files_scanned", 0)),
        _fmt_count(summary.get("files_parsed", 0)),
        _fmt_count(summary.get("files_rejected", 0))))
    lines.append("Claims: {0} | Service lines linked: {1}/{2} ({3}) | Trust: {4}".format(
        _fmt_count(summary.get("total_claims", 0)),
        _fmt_count(summary.get("service_lines_with_association", 0)),
        _fmt_count(summary.get("total_service_lines", 0)),
        _fmt_percent(summary.get("service_line_association_rate", 0.0)),
        health.get("trust_level", "unknown")))
    top_rows = _top_association_rows(summary.get("cpt_to_diagnosis") or {}, max_rows=max_rows)
    if top_rows:
        lines.append("Top CPT -> diagnosis links:")
        for row in top_rows:
            lines.append("  {0} -> {1}  {2} ({3} pair(s))".format(
                row.get("left", ""),
                row.get("right", ""),
                _fmt_percent(row.get("probability", 0.0)),
                _fmt_count(row.get("count", 0))))
    else:
        lines.append("Top CPT -> diagnosis links: none")
    if apply_summary:
        lines.append("Crosswalk proposal: {0} diagnosis->CPT and {1} CPT->diagnosis addition(s), {2} conflict(s).".format(
            _fmt_count(apply_summary.get("eligible_diagnosis_to_procedure_count", 0)),
            _fmt_count(apply_summary.get("eligible_procedure_to_diagnosis_pair_count", 0)),
            _fmt_count(apply_summary.get("conflict_count", 0))))
        lines.append("Diagnosis-to-Medisoft bridge gaps: {0}".format(
            _fmt_count(apply_summary.get("diagnosis_to_medisoft_bridge_missing_count", 0))))
        lines.append("Diagnosis-to-Medisoft bridge ambiguities: {0}".format(
            _fmt_count(apply_summary.get("diagnosis_to_medisoft_bridge_ambiguous_count", 0))))
    return lines


def format_crosswalk_proposal_lines(proposal):
    lines = []
    lines.append("CPT/Diagnosis Crosswalk Proposal")
    lines.append("================================")
    lines.append("Generated: {0}".format(proposal.get("generated_at_utc", "")))
    lines.append("Run ID: {0}".format(proposal.get("run_id", "")))
    lines.append("")
    lines.append("This proposal is generated from historical submitted 837P service-line evidence.")
    lines.append("It requires explicit confirmation before crosswalk changes are applied.")

    apply_summary = proposal.get("apply_summary") or {}
    thresholds = proposal.get("thresholds") or {}
    _section(lines, "Eligibility")
    lines.append("Diagnosis-to-CPT threshold: {0}".format(_fmt_percent(thresholds.get("diagnosis_to_procedure_min_probability", 0.0))))
    lines.append("Ambiguous unpointed multi-diagnosis candidate pairs excluded: {0}".format(bool(thresholds.get("ambiguous_candidate_pairs_excluded"))))
    lines.append("Eligible diagnosis-to-CPT mappings: {0}".format(_fmt_count(apply_summary.get("eligible_diagnosis_to_procedure_count", 0))))
    lines.append("Eligible CPT-to-diagnosis additions: {0}".format(_fmt_count(apply_summary.get("eligible_procedure_to_diagnosis_pair_count", 0))))
    lines.append("Conflicts requiring human review: {0}".format(_fmt_count(apply_summary.get("conflict_count", 0))))
    lines.append("Low-support warnings: {0}".format(_fmt_count(apply_summary.get("low_support_warning_count", 0))))
    lines.append("Diagnosis-to-Medisoft bridge gaps: {0}".format(_fmt_count(
        apply_summary.get("diagnosis_to_medisoft_bridge_missing_count", 0))))
    lines.append("Diagnosis-to-Medisoft bridge ambiguities: {0}".format(_fmt_count(
        apply_summary.get("diagnosis_to_medisoft_bridge_ambiguous_count", 0))))

    _section(lines, "Diagnosis To CPT")
    rows = []
    for row in proposal.get("diagnosis_to_procedure_eligible") or []:
        rows.append([
            row.get("diagnosis_code", ""),
            row.get("cpt_code", ""),
            _fmt_count(row.get("support_count", 0)),
            _fmt_percent(row.get("probability", 0.0)),
            _limit_join(row.get("warning_codes") or [], limit=3),
        ])
    for line in _table_lines(["Diagnosis", "CPT", "Pairs", "Probability", "Warnings"], rows):
        lines.append(line)

    _section(lines, "CPT To Diagnosis Additions")
    rows = []
    for row in proposal.get("procedure_to_diagnosis_addition_rows") or []:
        rows.append([
            row.get("cpt_code", ""),
            row.get("diagnosis_code", ""),
            _fmt_count(row.get("support_count", 0)),
            _fmt_percent(row.get("probability_within_cpt", 0.0)),
            _limit_join(row.get("warning_codes") or [], limit=3),
        ])
    for line in _table_lines(["CPT", "Diagnosis", "Pairs", "Within CPT", "Warnings"], rows):
        lines.append(line)

    _section(lines, "Conflicts")
    rows = []
    for row in proposal.get("diagnosis_to_procedure_conflicts") or []:
        rows.append([
            row.get("diagnosis_code", ""),
            row.get("existing_cpt_code", ""),
            row.get("cpt_code", ""),
            _fmt_count(row.get("support_count", 0)),
            _fmt_percent(row.get("probability", 0.0)),
        ])
    for line in _table_lines(["Diagnosis", "Existing", "Observed", "Pairs", "Probability"], rows):
        lines.append(line)

    _section(lines, "Diagnosis To Medisoft Bridge")
    bridge = proposal.get("diagnosis_to_medisoft_bridge_completeness") or {}
    lines.append("Bridge present: {0} | Missing: {1} | Ambiguous: {2}".format(
        _fmt_count(bridge.get("bridge_present_count", 0)),
        _fmt_count(bridge.get("bridge_missing_count", 0)),
        _fmt_count(bridge.get("bridge_ambiguous_count", 0))))
    lines.append("Policy: report-only; missing Medisoft shorthand bridges are not auto-applied from 837P analytics.")
    rows = []
    for row in bridge.get("missing_rows") or []:
        rows.append([
            row.get("diagnosis_code", ""),
            _limit_join(row.get("associated_cpt_codes") or [], limit=5),
            _fmt_count(row.get("support_count", 0)),
            _limit_join(row.get("source_surfaces") or [], limit=3),
        ])
    for line in _table_lines(["Diagnosis", "CPT(s)", "Pairs", "Source"], rows):
        lines.append(line)
    repair_guidance = bridge.get("repair_guidance_rows") or []
    if repair_guidance:
        _section(lines, "Bridge Repair Guidance")
        lines.append("Guidance is report-only. Suggested Medisoft codes are unconfirmed and must be operator-confirmed before config write.")
        rows = []
        for row in repair_guidance:
            rows.append([
                row.get("diagnosis_code", ""),
                _limit_join(row.get("associated_cpt_codes") or [], limit=5),
                row.get("unconfirmed_medisoft_code", ""),
                _fmt_count(row.get("support_count", 0)),
                "confirm via Service Line Input",
            ])
        for line in _table_lines(["Diagnosis", "CPT(s)", "Unconfirmed Medisoft", "Pairs", "Next step"], rows):
            lines.append(line)
    ambiguity_rows = []
    for row in bridge.get("reverse_ambiguity_rows") or []:
        ambiguity_rows.append([
            row.get("medisoft_code", ""),
            _limit_join(row.get("diagnosis_codes") or [], limit=5),
        ])
    if ambiguity_rows:
        lines.append("")
        lines.append("Ambiguous reverse bridges:")
        for line in _table_lines(["Medisoft", "Diagnosis keys"], ambiguity_rows):
            lines.append(line)

    _section(lines, "Maintenance Notes")
    maintenance = proposal.get("maintenance") or {}
    unsupported = maintenance.get("baseline_pairs_without_observed_support") or []
    lines.append("Unsupported baseline CPT/DX pairs reported only, not removed: {0}".format(_fmt_count(len(unsupported))))
    for row in unsupported[:10]:
        lines.append("  {0} -> {1}".format(row.get("cpt_code", ""), row.get("diagnosis_code", "")))
    if len(unsupported) > 10:
        lines.append("  (+{0} more)".format(len(unsupported) - 10))

    _section(lines, "Workflow Boundary")
    lines.append("workflow_boundary={0}".format(proposal.get("workflow_boundary", "report_only_review_required")))
    lines.append("claim_workflow_completion={0}".format(bool(proposal.get("claim_workflow_completion"))))
    lines.append("mutates_billing_state={0}".format(bool(proposal.get("mutates_billing_state"))))
    lines.append("mutates_dat={0}".format(bool(proposal.get("mutates_dat"))))
    lines.append("mutates_837p={0}".format(bool(proposal.get("mutates_837p"))))
    lines.append("charges_entered={0}".format(bool(proposal.get("charges_entered"))))
    lines.append("requires_apply_confirmation={0}".format(bool(proposal.get("requires_apply_confirmation"))))
    return lines


def format_summary_lines(summary):
    lines = []
    lines.append("CPT/Diagnosis Retrospective Review")
    lines.append("===================================")
    lines.append("Generated: {0}".format(summary.get("generated_at_utc", "")))
    lines.append("Run ID: {0}".format(summary.get("run_id", "")))
    lines.append("")
    lines.append("This report summarizes historical CPT and diagnosis associations found in saved 837P/X12 claim files.")
    lines.append("It is report-only unless a separate crosswalk apply confirmation is accepted.")

    _section(lines, "Executive Summary")
    lines.append("Files analyzed: {0} ({1} parsed, {2} rejected)".format(
        _fmt_count(summary.get("files_scanned", 0)),
        _fmt_count(summary.get("files_parsed", 0)),
        _fmt_count(summary.get("files_rejected", 0))))
    lines.append("Claim loops found: {0}".format(_fmt_count(summary.get("total_claims", 0))))
    lines.append("Service lines linked: {0} of {1} ({2})".format(
        _fmt_count(summary.get("service_lines_with_association", 0)),
        _fmt_count(summary.get("total_service_lines", 0)),
        _fmt_percent(summary.get("service_line_association_rate", 0.0))))
    lines.append("Association pairs emitted: {0}".format(_fmt_count(summary.get("total_pairs", 0))))
    lines.append("Distinct CPTs: {0} | Distinct diagnoses: {1}".format(
        _fmt_count(summary.get("distinct_cpt_count", 0)),
        _fmt_count(summary.get("distinct_diagnosis_count", 0))))
    lines.append("Average claims per parsed file: {0}".format(_fmt_float(summary.get("average_claims_per_parsed_file", 0.0), 2)))
    lines.append("Average service lines per parsed file: {0}".format(_fmt_float(summary.get("average_service_lines_per_parsed_file", 0.0), 2)))

    inventory = summary.get("file_inventory") or {}
    health = summary.get("health_telemetry") or {}
    _section(lines, "Reliability")
    if health:
        lines.append("Trust level: {0}".format(health.get("trust_level", "unknown")))
        reasons = health.get("trust_reasons") or []
        lines.append("Why: {0}".format(_limit_join(reasons, limit=10)))
        lines.append("Unlinked service lines: {0}".format(_fmt_count(health.get("service_lines_without_association", 0))))
    else:
        lines.append("Trust level: unknown")
    if inventory:
        lines.append("Archive sources: {0} candidate file(s), {1} from submission index, {2} from content scan".format(
            _fmt_count(inventory.get("unique_candidate_files", 0)),
            _fmt_count(inventory.get("unique_submission_index_files", 0)),
            _fmt_count(inventory.get("unique_content_scan_files", 0))))
        lines.append("Submission index receipts: {0} existing, {1} missing, {2} invalid JSON line(s)".format(
            _fmt_count(inventory.get("submission_index_existing_receipt_files", 0)),
            _fmt_count(inventory.get("submission_index_missing_receipt_files", 0)),
            _fmt_count(inventory.get("submission_index_invalid_json_lines", 0))))

    _section(lines, "Top CPT To Diagnosis Associations")
    rows = []
    for row in _top_association_rows(summary.get("cpt_to_diagnosis") or {}, max_rows=20):
        rows.append([
            row.get("left", ""),
            row.get("right", ""),
            _fmt_count(row.get("count", 0)),
            _fmt_percent(row.get("probability", 0.0)),
            _fmt_float(row.get("weighted", 0.0), 2),
        ])
    for line in _table_lines(["CPT", "Diagnosis", "Pairs", "Probability", "Weighted"], rows):
        lines.append(line)

    _section(lines, "Top Diagnosis To CPT Associations")
    rows = []
    for row in _top_association_rows(summary.get("diagnosis_to_cpt") or {}, max_rows=20):
        rows.append([
            row.get("left", ""),
            row.get("right", ""),
            _fmt_count(row.get("count", 0)),
            _fmt_percent(row.get("probability", 0.0)),
            _fmt_float(row.get("weighted", 0.0), 2),
        ])
    for line in _table_lines(["Diagnosis", "CPT", "Pairs", "Probability", "Weighted"], rows):
        lines.append(line)

    _section(lines, "Warnings")
    warning_totals = summary.get("warning_totals") or {}
    if warning_totals:
        for code in sorted(warning_totals.keys()):
            lines.append("{0}: {1}".format(code, _fmt_count(warning_totals.get(code))))
    else:
        lines.append("none")

    _section(lines, "Baseline Comparison")
    baseline = summary.get("baseline_comparison") or {}
    lines.append("Baseline procedures: {0} | Baseline CPT/DX pairs: {1}".format(
        _fmt_count(baseline.get("baseline_procedure_count", 0)),
        _fmt_count(baseline.get("baseline_pair_count", 0))))
    lines.append("Observed CPTs not in baseline: {0}".format(
        _limit_join(baseline.get("observed_cpt_not_in_baseline") or [], limit=20)))
    lines.append("Baseline CPTs not observed: {0}".format(
        _limit_join(baseline.get("baseline_cpt_not_observed") or [], limit=20)))
    missing_pairs = baseline.get("observed_pairs_missing_from_baseline") or []
    unsupported_pairs = baseline.get("baseline_pairs_without_observed_support") or []
    lines.append("Observed CPT/DX pairs missing from baseline: {0}".format(_fmt_count(len(missing_pairs))))
    for row in missing_pairs[:10]:
        lines.append("  {0} -> {1}".format(row.get("cpt_code", ""), row.get("diagnosis_code", "")))
    if len(missing_pairs) > 10:
        lines.append("  (+{0} more)".format(len(missing_pairs) - 10))
    lines.append("Baseline CPT/DX pairs without historical support: {0}".format(_fmt_count(len(unsupported_pairs))))
    for row in unsupported_pairs[:10]:
        lines.append("  {0} -> {1}".format(row.get("cpt_code", ""), row.get("diagnosis_code", "")))
    if len(unsupported_pairs) > 10:
        lines.append("  (+{0} more)".format(len(unsupported_pairs) - 10))

    proposal = summary.get("crosswalk_proposal") or {}
    if proposal:
        apply_summary = proposal.get("apply_summary") or {}
        _section(lines, "Crosswalk Proposal")
        lines.append("Eligible diagnosis-to-CPT mappings: {0}".format(
            _fmt_count(apply_summary.get("eligible_diagnosis_to_procedure_count", 0))))
        lines.append("Eligible CPT-to-diagnosis additions: {0}".format(
            _fmt_count(apply_summary.get("eligible_procedure_to_diagnosis_pair_count", 0))))
        lines.append("Conflicts requiring human review: {0}".format(
            _fmt_count(apply_summary.get("conflict_count", 0))))
        lines.append("Low-support warnings: {0}".format(
            _fmt_count(apply_summary.get("low_support_warning_count", 0))))
        bridge = proposal.get("diagnosis_to_medisoft_bridge_completeness") or {}
        lines.append("Diagnosis-to-Medisoft bridge present: {0} | missing: {1} | ambiguous: {2}".format(
            _fmt_count(bridge.get("bridge_present_count", 0)),
            _fmt_count(bridge.get("bridge_missing_count", 0)),
            _fmt_count(bridge.get("bridge_ambiguous_count", 0))))
        lines.append("Missing bridges are report-only and not auto-applied from submitted 837P analytics.")
        lines.append("Crosswalk apply requires explicit confirmation.")

    _section(lines, "Privacy")
    privacy = summary.get("privacy") or {}
    lines.append("Report rows use source basenames plus SHA-256 prefixes for auditability.")
    lines.append("Suppressed fields: {0}".format(_limit_join(privacy.get("phi_fields_suppressed") or PHI_FIELDS_SUPPRESSED, limit=20)))
    return lines


def _workspace_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))


def _default_lab_dir(workspace_root):
    env_lab = os.environ.get("MEDICAFE_LAB_DIR", "")
    if env_lab:
        return os.path.abspath(os.path.expandvars(os.path.expanduser(env_lab)))
    return os.path.join(workspace_root, "lab")


def _load_config_roots(config_path):
    roots = []
    if not config_path or not os.path.exists(config_path):
        return roots
    try:
        with io.open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return roots
    if not isinstance(data, dict):
        return roots
    cfg = data.get("MediLink_Config")
    if not isinstance(cfg, dict):
        cfg = data
    for key in ("local_claims_path", "outputFilePath"):
        value = cfg.get(key)
        if value and isinstance(value, str):
            roots.append(value)
    return roots


def _bind_shared_x12_helpers():
    globals()["_to_text"] = x12c.to_text
    globals()["_path_label"] = x12c.path_label
    globals()["make_run_id"] = x12c.make_run_id
    globals()["iso_utc_now"] = x12c.iso_utc_now
    globals()["normalize_code"] = x12c.normalize_code
    globals()["split_x12_segments"] = x12c.split_x12_segments
    globals()["_split_composites"] = x12c.split_composites
    globals()["_add_warning"] = x12c.add_warning
    globals()["_copy_warning_counts"] = x12c.copy_warning_counts
    globals()["_claim_records_from_segments"] = x12c.claim_records_from_segments
    globals()["looks_like_x12_claim_text"] = x12c.looks_like_x12_claim_text
    globals()["_read_file_text"] = x12c.read_file_text
    globals()["sha256_prefix_for_file"] = x12c.sha256_prefix_for_file
    globals()["iter_candidate_x12_files"] = x12c.iter_candidate_x12_files
    globals()["_is_submission_index_entry"] = x12c.is_submission_index_entry
    globals()["_submission_index_path"] = x12c.submission_index_path
    globals()["_resolve_receipt_path"] = x12c.resolve_receipt_path
    globals()["_merge_warning_counts"] = x12c.merge_warning_counts
    globals()["_ensure_dir"] = x12c.ensure_dir
    globals()["_fmt_percent"] = x12c.fmt_percent
    globals()["_fmt_float"] = x12c.fmt_float
    globals()["_fmt_count"] = x12c.fmt_count
    globals()["_limit_join"] = x12c.limit_join
    globals()["_section"] = x12c.section
    globals()["_table_lines"] = x12c.table_lines
    globals()["_top_association_rows"] = _top_cpt_dx_association_rows
    globals()["_workspace_root"] = _workspace_root_from_common
    globals()["_default_lab_dir"] = x12c.default_lab_dir
    globals()["_load_config_roots"] = x12c.load_config_roots


def _increment_nested_count(bucket, first, second, confidence):
    x12c.increment_nested_count(bucket, first, second, confidence)


def _finalize_probability_map(bucket):
    return x12c.finalize_probability_map(bucket, "confidence_weighted_support")


def _top_cpt_dx_association_rows(mapping, max_rows=12):
    return x12c.top_association_rows(mapping, max_rows=max_rows, support_key="confidence_weighted_support")


def _workspace_root_from_common():
    return x12c.workspace_root_for_script(__file__)


_bind_shared_x12_helpers()


def run_analysis(scan_roots, lab_dir, crosswalk_path, run_id=None, service_line_input_state_path=None):
    run_id = run_id or make_run_id()
    inventory_paths, inventory_summary = x12c.build_x12_scan_inventory(scan_roots)
    file_results, pairs, warning_counts = analyze_files(inventory_paths, run_id)
    service_line_input_pairs = load_service_line_input_correction_pairs(
        service_line_input_state_path,
        run_id=run_id,
    )
    procedure_to_diagnosis = load_procedure_to_diagnosis(crosswalk_path)
    diagnosis_to_procedure = load_diagnosis_to_procedure(crosswalk_path)
    diagnosis_to_medisoft = load_diagnosis_to_medisoft(crosswalk_path)
    summary = build_summary(run_id, scan_roots, file_results, pairs, warning_counts, procedure_to_diagnosis)
    summary["file_inventory"] = inventory_summary
    summary["service_line_input_correction_evidence"] = {
        "state_path_supplied": bool(service_line_input_state_path),
        "correction_pair_count": len(service_line_input_pairs),
        "workflow_boundary": "report_only_review_required",
        "claim_workflow_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }
    summary["health_telemetry"] = build_health_telemetry(summary)
    proposal_pairs = pairs + service_line_input_pairs
    summary["crosswalk_proposal"] = build_crosswalk_proposal(
        run_id,
        summary,
        proposal_pairs,
        procedure_to_diagnosis,
        diagnosis_to_procedure,
        diagnosis_to_medisoft,
    )
    summary["diagnosis_to_medisoft_bridge_completeness"] = (
        summary["crosswalk_proposal"].get("diagnosis_to_medisoft_bridge_completeness") or {}
    )
    artifacts = write_reports(lab_dir, run_id, summary, pairs)
    return summary, pairs, artifacts


def parse_args(argv):
    parser = argparse.ArgumentParser(description="Build CPT <-> diagnosis analytics from saved 837P/X12 files.")
    parser.add_argument("--root", action="append", default=[], help="File or directory to scan. May be repeated.")
    parser.add_argument("--lab-dir", default="", help="Lab directory for reports. Defaults to MEDICAFE_LAB_DIR or ./lab.")
    parser.add_argument("--config", default="", help="Optional config.json for local_claims_path/outputFilePath roots.")
    parser.add_argument("--crosswalk", default="", help="Optional crosswalk.json path for baseline comparison.")
    parser.add_argument("--service-line-input-state", default="", help="Optional .service_line_input_state.json for sanitized correction evidence.")
    parser.add_argument("--run-id", default="", help="Optional deterministic run id.")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])
    workspace = _workspace_root()
    config_path = args.config or os.path.join(workspace, "json", "config.json")
    crosswalk_path = args.crosswalk or os.path.join(workspace, "json", "crosswalk.json")
    lab_dir = args.lab_dir or _default_lab_dir(workspace)
    scan_roots = list(args.root or [])
    if not scan_roots:
        scan_roots.extend(_load_config_roots(config_path))
    if not scan_roots:
        print("No scan roots provided and no config roots found.", file=sys.stderr)
        return 2
    summary, pairs, artifacts = run_analysis(
        scan_roots,
        lab_dir,
        crosswalk_path,
        args.run_id or None,
        service_line_input_state_path=args.service_line_input_state or None,
    )
    print("Wrote summary: {0}".format(artifacts.get("summary_json")))
    print("Wrote pairs: {0}".format(artifacts.get("pairs_jsonl")))
    print("files_scanned={0} pairs={1}".format(summary.get("files_scanned"), len(pairs)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
