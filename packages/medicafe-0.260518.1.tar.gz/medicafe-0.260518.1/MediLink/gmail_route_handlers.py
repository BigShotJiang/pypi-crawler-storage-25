#!/usr/bin/env python
"""
HTTP route handler implementation extracted from MediLink.MediLink_Gmail.
"""
from __future__ import print_function

from functools import wraps


_LOCAL_HELPER_NAMES = set(['_gmail_module', '_sync_gmail_globals', '_with_gmail_globals'])


def _gmail_module():
    # When MediLink_Gmail.py is launched as a script, its live state is held by
    # __main__. Importing MediLink.MediLink_Gmail here creates a second module
    # with a different shutdown_event/SAFE_TO_CLOSE, which leaves the real
    # process waiting after a successful handoff.
    import sys
    main_mod = sys.modules.get('__main__')
    if main_mod is not None:
        main_file = str(getattr(main_mod, '__file__', '') or '').replace('\\', '/')
        if main_file.endswith('/MediLink_Gmail.py') or main_file == 'MediLink_Gmail.py':
            return main_mod
        if (
            getattr(main_mod, '__name__', None) == '__main__'
            and hasattr(main_mod, 'shutdown_event')
            and hasattr(main_mod, 'SERVER_STATUS')
            and hasattr(main_mod, 'set_safe_to_close')
        ):
            return main_mod
    existing = sys.modules.get('MediLink.MediLink_Gmail')
    if existing is not None:
        return existing
    from MediLink import MediLink_Gmail as _gm
    return _gm


def _sync_gmail_globals():
    gm = _gmail_module()
    g = globals()
    for name, value in gm.__dict__.items():
        if name in _LOCAL_HELPER_NAMES:
            continue
        g[name] = value


def _with_gmail_globals(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        _sync_gmail_globals()
        return fn(*args, **kwargs)
    return _wrapped


class RequestHandlerMixinBase(object):
    @_with_gmail_globals
    def _build_troubleshoot_html(self):
        """Build comprehensive troubleshooting HTML page.

        Delegates to gmail_html_utils.build_troubleshoot_html for HTML generation.
        """
        # Run diagnostics to gather environment/issue info
        diag_report = None
        if DIAGNOSTICS_AVAILABLE and not USE_HTTP_MODE:
            try:
                diag_report = run_connection_diagnostics(
                    cert_file=cert_file,
                    key_file=key_file,
                    server_port=server_port,
                    auto_fix=True,  # Enable auto-fix on troubleshoot page
                    openssl_cnf=get_openssl_cnf()
                )
                # If certificate was auto-fixed, log it
                if diag_report.get('fixes_successful'):
                    log("Auto-fixed certificate issues from troubleshoot page: {}".format(diag_report['fixes_successful']), level="INFO")
            except Exception as e:
                log("Error running diagnostics for troubleshoot page: {}".format(e), level="WARNING")

        # Get Firefox notes and browser hints
        firefox_notes = get_firefox_xp_compatibility_notes() if DIAGNOSTICS_AVAILABLE else {'notes': []}
        browser_hints = BROWSER_DIAGNOSTIC_HINTS if DIAGNOSTICS_AVAILABLE else {}

        # Get Firefox certificate diagnosis if available and certificate issues exist (skip in HTTP mode)
        firefox_diagnosis = None
        if not USE_HTTP_MODE and FIREFOX_CERT_DIAG_AVAILABLE and diag_report and diag_report.get('issues'):
            try:
                firefox_path = medi.get('firefox_path') or medi.get('browser_path')
                firefox_diagnosis = diagnose_firefox_certificate_exceptions(
                    cert_file=cert_file,
                    server_port=server_port,
                    firefox_path=firefox_path,
                    log=log
                )
            except Exception as fx_err:
                log("Firefox diagnosis unavailable for troubleshoot page: {}".format(fx_err), level="DEBUG")

        # Get certificate info for contextual guidance (skip in HTTP mode)
        cert_info = None
        if not USE_HTTP_MODE:
            try:
                cert_info = get_certificate_summary(cert_file)
            except Exception:
                pass

        # Delegate HTML generation to utility module
        provider_payload = None
        if not USE_HTTP_MODE:
            try:
                provider_payload = {
                    'mode': CERT_MODE,
                    'status': get_managed_ca_status(),
                    'san': MANAGED_CA_SAN_LIST,
                    'root_subject': MANAGED_CA_ROOT_SUBJECT,
                    'server_subject': MANAGED_CA_SERVER_SUBJECT
                }
            except Exception:
                provider_payload = None
        return html_build_troubleshoot_html(
            diag_report=diag_report,
            firefox_notes=firefox_notes,
            browser_hints=browser_hints,
            server_port=server_port,
            certificate_provider=provider_payload,
            firefox_diagnosis=firefox_diagnosis,
            cert_info=cert_info
        )

    @_with_gmail_globals
    def do_OPTIONS(self):
        # Patch A: log incoming preflight metadata before sending response
        try:
            path = self.path
            origin = self.headers.get('Origin', '')
            acrm = self.headers.get('Access-Control-Request-Method', '')
            acrh = self.headers.get('Access-Control-Request-Headers', '')
            acrpn = self.headers.get('Access-Control-Request-Private-Network', '')
            sfs = self.headers.get('Sec-Fetch-Site', '')
            sfm = self.headers.get('Sec-Fetch-Mode', '')
            log("preflight_incoming path={} Origin={} Access-Control-Request-Method={} Access-Control-Request-Headers={} Access-Control-Request-Private-Network={} Sec-Fetch-Site={} Sec-Fetch-Mode={}".format(
                path, origin, acrm, acrh, acrpn, sfs, sfm), level="DEBUG")
        except Exception:
            pass
        self.send_response(200)

        _preflight_sent_headers = {}

        def _log_preflight_sent(sent_headers):
            try:
                if isinstance(sent_headers, dict):
                    _preflight_sent_headers.update(sent_headers)
                log("preflight_response_headers " + str(sent_headers), level="DEBUG")
            except Exception:
                pass

        self._set_headers(log_sent_headers_fn=_log_preflight_sent)
        # Patch B: explicit Content-Length: 0 on OPTIONS (no body)
        self.send_header('Content-Length', '0')
        self.end_headers()
        record_request_event('OPTIONS', self.path, 200, note='preflight', client=_get_client_ip(self))
        try:
            origin = self.headers.get('Origin')
            host_header = self.headers.get('Host', '')
            req_headers = self.headers.get('Access-Control-Request-Headers', '')
            req_private_network = self.headers.get('Access-Control-Request-Private-Network', '')
        except Exception:
            origin = None
            host_header = ''
            req_headers = ''
            req_private_network = ''
        try:
            print("[CORS] Preflight {0} from {1} host={2} req_headers={3} req_private_network={4}".format(
                self.path, origin, host_header, req_headers, req_private_network
            ))
            print("[CORS] Preflight response allow_origin={0} allow_methods={1} allow_headers={2} allow_private_network={3}".format(
                _preflight_sent_headers.get('Access-Control-Allow-Origin', ''),
                _preflight_sent_headers.get('Access-Control-Allow-Methods', ''),
                _preflight_sent_headers.get('Access-Control-Allow-Headers', ''),
                _preflight_sent_headers.get('Access-Control-Allow-Private-Network', '')
            ))
        except Exception:
            pass

    @_with_gmail_globals
    def do_POST(self):
        """Handle POST requests with comprehensive exception handling to prevent server crashes."""
        from MediLink.gmail_http_utils import (
            parse_content_length, read_post_data, parse_json_data,
            send_error_response, safe_write_response, log_request_error
        )
        try:
            if self.path == '/download':
                request_id = str(int(time.time() * 1000))
                log("python_download_request_received path={} origin={} content_length={} client_ip={} request_id={}".format(
                    self.path,
                    self.headers.get('Origin', ''),
                    self.headers.get('Content-Length', ''),
                    _get_client_ip(self),
                    request_id
                ), level="INFO")
                set_phase('processing')
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    log("python_download_request_failed request_id={} exception_type={} exception_message={}".format(
                        request_id, type(e).__name__, str(e)), level="INFO")
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    _log_transfer_outcome_summary('aborted_download_request', {
                        'request_id': request_id,
                        'reason': 'invalid_content_length',
                        'error': str(e),
                    }, level='WARNING')
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    log("python_download_request_failed request_id={} exception_type=ClientDisconnect exception_message=post_data_is_None".format(
                        request_id), level="INFO")
                    _log_transfer_outcome_summary('aborted_download_request', {
                        'request_id': request_id,
                        'reason': 'client_disconnect',
                    }, level='WARNING')
                    return  # Client disconnected
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    log("python_download_request_failed request_id={} exception_type={} exception_message={}".format(
                        request_id, type(e).__name__, str(e)), level="INFO")
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    _log_transfer_outcome_summary('aborted_download_request', {
                        'request_id': request_id,
                        'reason': 'invalid_json',
                        'error': str(e),
                    }, level='WARNING')
                    return
                if not _require_local_control_auth(self, '/download', data):
                    record_request_event('POST', '/download', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                links = data.get('links', [])
                telemetry = data.get('telemetry', {}) if isinstance(data, dict) else {}
                log("python_download_payload_parsed request_id={} links_count={}".format(request_id, len(links)), level="INFO")
                log("Received download link manifest with {} item(s); URLs suppressed.".format(len(links)), level="DEBUG")
                _record_transfer_telemetry('python_download_request_received', telemetry, {
                    'links_received': len(links),
                    'client': _get_client_ip(self),
                    'path': self.path
                })
                if _current_transfer_route() == 'browser_handoff':
                    set_transfer_route_outcome('browser_handoff_received')
                else:
                    set_transfer_route_outcome('direct_gas_local_handoff_received')
                try:
                    print("[Handshake] Received {0} link(s) from webapp".format(len(links)))
                except Exception:
                    pass
                try:
                    set_counts(links_received=len(links))
                except Exception:
                    pass
                file_ids = [link.get('fileId', None) for link in links if link.get('fileId')]
                log("File IDs received from client: count={}".format(len(file_ids)), level="DEBUG")
                set_phase('downloading')
                download_ok = True
                download_summary = _new_download_batch_summary(len(links))
                try:
                    batch_result = download_docx_files(links, telemetry_context=telemetry)
                    if isinstance(batch_result, dict):
                        download_summary = batch_result
                    _record_transfer_telemetry('python_download_execution_complete', telemetry, {
                        'requested_links': len(links),
                        'downloaded_files': SERVER_STATUS.get('filesDownloaded', 0),
                        'failed_files': download_summary.get('failed_count')
                    })
                except Exception as e:
                    download_ok = False
                    set_phase('error')
                    set_error(str(e))
                    _record_transfer_telemetry('python_download_execution_error', telemetry, {
                        'error': str(e)
                    })
                try:
                    _fd_ct = int(download_summary.get('downloaded_count') or 0)
                except Exception:
                    _fd_ct = 0
                try:
                    _failed_ct = int(download_summary.get('failed_count') or 0)
                except Exception:
                    _failed_ct = 0
                try:
                    _already_ct = int(download_summary.get('already_downloaded_count') or 0)
                except Exception:
                    _already_ct = 0
                _successful_file_ct = _fd_ct + _already_ct
                partial_download_failed = bool(download_ok and _failed_ct > 0 and _successful_file_ct > 0)
                if download_ok and len(links) > 0 and _successful_file_ct == 0:
                    download_ok = False
                    set_phase('error')
                    set_error('Local download produced zero successful files for a non-empty link list')
                    _record_transfer_telemetry('python_download_zero_output', telemetry, {
                        'requested_links': len(links),
                        'failed_files': _failed_ct,
                    })
                if not download_ok:
                    try:
                        set_safe_to_close(False)
                    except Exception:
                        pass
                    _log_transfer_outcome_summary('error', {
                        'request_id': request_id,
                        'route_mode': _current_transfer_route(),
                        'requested_links': len(links),
                        'files_downloaded': _fd_ct,
                    }, level='ERROR')
                    try:
                        if len(links) > 0 and _fd_ct == 0:
                            _submit_transfer_failure_report('direct_gas_local_download_zero_files', None, allow_during_fallback=True)
                    except Exception:
                        pass
                    try:
                        for ent in SERVER_STATUS.get('transferFiles') or []:
                            if isinstance(ent, dict) and str(ent.get('status') or '') == 'prepared':
                                ent['status'] = 'failed'
                                ent['error'] = (str(SERVER_STATUS.get('lastError') or 'download failed'))[:200]
                    except Exception:
                        pass
                    self.send_response(502)
                    self._set_headers()
                    self.end_headers()
                    safe_write_response(self, json.dumps({
                        'status': 'error',
                        'message': str(SERVER_STATUS.get('lastError') or 'Download failed'),
                        'safeToClose': False,
                        'downloadSummary': download_summary,
                    }))
                    shutdown_event.set()
                    bring_window_to_foreground()
                    record_request_event('POST', '/download', 502, note='download_failed', client=_get_client_ip(self))
                    return
                # Only delete files that actually downloaded successfully
                successful_ids = _successful_ids_from_download_summary(links, download_summary)
                try:
                    set_counts(files_to_delete=len(successful_ids))
                except Exception:
                    pass
                # Trigger cleanup in Apps Script with auth
                try:
                    cleanup_ok = False
                    if successful_ids:
                        ok = send_delete_request_to_gas(successful_ids)
                        if ok:
                            set_phase('cleanup_confirmed')
                            try:
                                set_counts(files_deleted=len(successful_ids))
                            except Exception:
                                pass
                            cleanup_ok = True
                        else:
                            set_phase('cleanup_triggered')
                            set_error('Cleanup request not confirmed')
                    else:
                        log("No successful file IDs to delete after download.")
                        set_phase('done')
                        cleanup_ok = True  # nothing to delete -> safe
                except Exception as e:
                    log("Cleanup trigger failed: {}".format(e))
                    set_phase('error')
                    set_error(str(e))
                    cleanup_ok = False
                try:
                    _mark_transfer_files_cleanup_terminal(bool(cleanup_ok))
                except Exception:
                    pass
                if partial_download_failed:
                    set_phase('partial_download_failed')
                    set_error('Some files failed to download')
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    set_safe_to_close(bool(cleanup_ok and not partial_download_failed))
                except Exception:
                    pass
                if partial_download_failed:
                    response_status = 'partial_failure'
                    response_message = 'Some files failed to download'
                elif cleanup_ok:
                    response_status = 'success'
                    response_message = 'All files downloaded'
                else:
                    response_status = 'cleanup_pending'
                    response_message = 'Files downloaded; cleanup pending'
                response = json.dumps({
                    "status": response_status,
                    "message": response_message,
                    "fileIds": successful_ids,
                    "safeToClose": bool(cleanup_ok and not partial_download_failed),
                    "downloadSummary": download_summary,
                })
                safe_write_response(self, response)
                _record_transfer_telemetry('python_download_response_sent', telemetry, {
                    'cleanup_ok': bool(cleanup_ok),
                    'successful_ids': len(successful_ids),
                    'partial_download_failed': bool(partial_download_failed),
                    'failed_files': _failed_ct
                })
                if partial_download_failed:
                    _term = 'partial_download_failed'
                elif not download_ok:
                    _term = 'error'
                elif cleanup_ok:
                    _term = 'success'
                else:
                    _term = 'cleanup_pending'
                _log_transfer_outcome_summary(
                    _term,
                    {
                        'request_id': request_id,
                        'route_mode': _current_transfer_route(),
                        'successful_ids': len(successful_ids),
                        'requested_links': len(links),
                        'failed_files': _failed_ct
                    },
                    level='INFO' if (cleanup_ok and download_ok and not partial_download_failed) else 'WARNING'
                )
                try:
                    print("[Handshake] Completed. Returning success for {0} fileId(s)".format(len(successful_ids)))
                except Exception:
                    pass
                log("python_download_request_completed request_id={} links_count={} safeToClose={}".format(
                    request_id, len(links), bool(cleanup_ok)), level="INFO")
                shutdown_event.set()
                bring_window_to_foreground()
                record_request_event('POST', '/download', 200, note='download', client=_get_client_ip(self))
                return
            elif self.path == '/shutdown':
                if not _require_local_control_auth(self, '/shutdown', None, require_admin=True):
                    record_request_event('POST', '/shutdown', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                log("Shutdown request received.")
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                response = json.dumps({"status": "success", "message": "Server is shutting down."})
                safe_write_response(self, response)
                shutdown_event.set()
                record_request_event('POST', '/shutdown', 200, note='shutdown', client=_get_client_ip(self))
                return
            elif self.path == '/delete-files':
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    return  # Client disconnected
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    return
                if not _require_local_control_auth(self, '/delete-files', data, require_admin=True):
                    record_request_event('POST', '/delete-files', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                file_ids = data.get('fileIds', [])
                log("File IDs to delete received from client: {}".format(file_ids))
                if not isinstance(file_ids, list):
                    send_error_response(self, 400, "Invalid fileIds parameter.", log_fn=log)
                    return
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                response = json.dumps({"status": "success", "message": "Files deleted successfully."})
                safe_write_response(self, response)
                record_request_event('POST', '/delete-files', 200, note='cleanup', client=_get_client_ip(self))
                return
            elif self.path == '/ca/enable':
                if USE_HTTP_MODE:
                    self.send_response(503)
                    self._set_headers()
                    self.end_headers()
                    safe_write_response(self, json.dumps({"error": "Certificate authority management not available in HTTP mode"}))
                    record_request_event('POST', '/ca/enable', 503, note='ca-enable-http-mode', client=_get_client_ip(self))
                    return
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    return
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    return
                if not _require_local_control_auth(self, '/ca/enable', data, require_admin=True):
                    record_request_event('POST', '/ca/enable', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                desired_mode = _str_or_default(data.get('mode'), 'managed_ca').lower()
                if desired_mode not in ('managed_ca', 'self_signed'):
                    desired_mode = 'managed_ca'
                extra_fields = {}
                if desired_mode == 'managed_ca':
                    extra_fields = {
                        'profile': MANAGED_CA_PROFILE_NAME,
                        'root_subject': MANAGED_CA_ROOT_SUBJECT,
                        'server_subject': MANAGED_CA_SERVER_SUBJECT,
                        'san': MANAGED_CA_SAN_LIST,
                        'root_valid_days': MANAGED_CA_ROOT_VALID_DAYS,
                        'server_valid_days': MANAGED_CA_SERVER_VALID_DAYS
                    }
                success, error = _update_certificate_provider_mode(desired_mode, extra_fields)
                response = {
                    'success': bool(success),
                    'mode': CERT_MODE,
                    'managed': is_managed_ca_active()
                }
                if error:
                    response['error'] = error
                status_code = 200 if success else 500
                self.send_response(status_code)
                self._set_headers()
                self.end_headers()
                safe_write_response(self, json.dumps(response))
                record_request_event('POST', '/ca/enable', status_code, note='ca-enable', client=_get_client_ip(self))
                return
            elif self.path == '/ca/repair':
                if USE_HTTP_MODE:
                    self.send_response(503)
                    self._set_headers()
                    self.end_headers()
                    safe_write_response(self, json.dumps({"error": "Certificate repair not available in HTTP mode"}))
                    record_request_event('POST', '/ca/repair', 503, note='ca-repair-http-mode', client=_get_client_ip(self))
                    return
                if not (CERTIFICATE_AUTHORITY_AVAILABLE and is_managed_ca_active()):
                    self.send_response(503)
                    self._set_headers()
                    self.end_headers()
                    safe_write_response(self, json.dumps({"error": "Managed certificate authority is not available"}))
                    record_request_event('POST', '/ca/repair', 503, note='ca-repair-unavailable', client=_get_client_ip(self))
                    return
                try:
                    content_length = int(self.headers.get('Content-Length', '0') or 0)
                except Exception:
                    content_length = 0
                post_data = b''
                if content_length > 0:
                    post_data = read_post_data(self, content_length, log_fn=log)
                    if post_data is None:
                        return
                data = {}
                if post_data:
                    try:
                        data = parse_json_data(post_data, log_fn=log)
                    except (ValueError, UnicodeDecodeError) as e:
                        send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                        return
                if not _require_local_control_auth(self, '/ca/repair', data, require_admin=True):
                    record_request_event('POST', '/ca/repair', 403, note='auth-denied', client=_get_client_ip(self))
                    return
                force_root = False
                if isinstance(data, dict):
                    force_root = bool(data.get('force_root'))
                global CA_STATUS_CACHE
                try:
                    status = certificate_authority.repair_managed_certificate(
                        CA_PROFILE,
                        log=log,
                        subprocess_module=subprocess,
                        force_root=force_root
                    )
                    CA_STATUS_CACHE = status
                    response = {
                        'success': True,
                        'mode': CERT_MODE,
                        'managed': is_managed_ca_active(),
                        'status': status,
                        'message': 'Certificate repair completed. Restart the MediLink helper and browser if issues persist.'
                    }
                    status_code = 200
                except Exception as repair_err:
                    response = {
                        'success': False,
                        'mode': CERT_MODE,
                        'managed': is_managed_ca_active(),
                        'error': str(repair_err)
                    }
                    status_code = 500
                self.send_response(status_code)
                self._set_headers()
                self.end_headers()
                safe_write_response(self, json.dumps(response))
                record_request_event('POST', '/ca/repair', status_code, note='ca-repair', client=_get_client_ip(self))
                return
            elif self.path == '/client-telemetry':
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    return
                # NOTE (scale assessment): we intentionally do not enforce an additional hard body-size cap here.
                # This endpoint is only called by the local helper webapp, telemetry payloads are tiny JSON,
                # and current deployment volume is low enough that oversized-body pressure is a non-issue.
                # Revisit if exposure scope or event volume increases materially.
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    return
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    return
                client_ip = _get_client_ip(self)
                envelope = _record_webapp_telemetry(data, client_ip=client_ip)
                self.send_response(202)
                self._set_headers()
                self.end_headers()
                safe_write_response(self, json.dumps({
                    'status': 'accepted',
                    'eventType': ((envelope.get('telemetry') or {}).get('eventType') or 'unknown')
                }))
                record_request_event('POST', '/client-telemetry', 202, note='webapp-telemetry', client=client_ip)
                return
            else:
                self.send_response(404)
                self._set_headers()
                self.end_headers()
        except KeyError as e:
            send_error_response(self, 400, "Missing required header: {}".format(str(e)), log_fn=log, error_details=str(e))
        except (ValueError, TypeError) as e:
            # Note: json.JSONDecodeError doesn't exist in Python 3.4.4; json.loads raises ValueError
            send_error_response(self, 400, "Invalid request format: {}".format(str(e)), log_fn=log, error_details=str(e))
        except OSError as e:
            from MediLink.gmail_http_utils import _is_expected_disconnect
            if _is_expected_disconnect(e):
                log("Client disconnected during POST request handling: {}".format(e), level="DEBUG")
                self.close_connection = True
            else:
                log("Connection error in POST request: {} - This usually indicates a network error, client disconnect, or socket issue on Windows XP".format(e), level="ERROR")
                send_error_response(self, 500, "Connection error", log_fn=log, error_details=str(e))
        except Exception as e:
            log_request_error(e, self.path, "POST", log, headers=self.headers)
            send_error_response(self, 500, "Internal server error", log_fn=log, error_details=str(e))

    @_with_gmail_globals
    def do_GET(self):
        """Handle GET requests with comprehensive exception handling to prevent server crashes."""
        # INSTRUMENTATION POINT: Log GET requests (path, headers) to track which endpoints are being accessed.
        from MediLink.gmail_http_utils import (
            _is_expected_disconnect,
            send_error_response, log_request_error
        )
        try:
            log("Full request path: {}".format(self.path), level="DEBUG")
            if self.path == '/_health':
                try:
                    print("[Health] Probe OK")
                except Exception:
                    pass
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    self.wfile.write(json.dumps({"status": "ok"}).encode('ascii'))
                except Exception:
                    try:
                        self.wfile.write(b'{"status":"ok"}')
                    except OSError as e:
                        if _is_expected_disconnect(e):
                            self.close_connection = True
                        else:
                            raise
                record_request_event('GET', '/_health', 200, note='health-probe', client=_get_client_ip(self))
                return
            elif self.path == '/mode':
                # Server mode endpoint for webapp detection
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                mode_response = {
                    'mode': 'http' if USE_HTTP_MODE else 'https',
                    'use_http_mode': USE_HTTP_MODE
                }
                try:
                    self.wfile.write(json.dumps(mode_response).encode('utf-8'))
                except Exception as write_err:
                    log("Failed to write mode response: {}".format(write_err))
                record_request_event('GET', '/mode', 200, note='mode-endpoint', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_selftest'):
                # Run self-tests to verify server connectivity and SSL configuration
                # This endpoint helps diagnose Firefox/XP connectivity issues
                self.send_response(200)

                # Check if HTML format is requested
                want_html = 'html=1' in self.path or 'format=html' in self.path

                if USE_HTTP_MODE:
                    # In HTTP mode, skip SSL/certificate tests
                    selftest_results = {
                        'note': 'HTTP mode: SSL/certificate tests skipped',
                        'tests': {},
                        'summary': {'total': 0, 'passed': 0, 'failed': 0, 'all_passed': True},
                        'mode': 'http'
                    }
                elif DIAGNOSTICS_AVAILABLE and _run_all_selftests:
                    try:
                        # Run self-tests (skip network tests since we ARE the server)
                        selftest_results = _run_all_selftests(
                            port=server_port,
                            cert_file=cert_file,
                            include_network=False  # Can't test ourselves while handling request
                        )
                        # Add note about network tests
                        selftest_results['note'] = 'Network tests skipped (cannot self-test while handling request). Run from external script for full test.'
                    except Exception as st_err:
                        log("Error running self-tests: {}".format(st_err), level="ERROR")
                        selftest_results = {
                            'error': str(st_err),
                            'tests': {},
                            'summary': {'total': 0, 'passed': 0, 'failed': 0, 'all_passed': False}
                        }
                else:
                    selftest_results = {
                        'error': 'Diagnostics module not available',
                        'tests': {},
                        'summary': {'total': 0, 'passed': 0, 'failed': 0, 'all_passed': False}
                    }

                if want_html:
                    # Build simple HTML response
                    html_parts = ['<!DOCTYPE html><html><head><meta charset="utf-8"><title>MediLink Self-Test</title>',
                                  '<style>body{font-family:Arial,sans-serif;padding:20px;background:#f5f3e8;}',
                                  '.container{max-width:800px;margin:0 auto;background:white;padding:24px;border:1px solid #ccc;}',
                                  'h1{color:#3B2323;}.pass{color:#1f5132;}.fail{color:#dc2626;}',
                                  'pre{background:#f0f0f0;padding:12px;overflow:auto;}</style></head><body>',
                                  '<div class="container"><h1>MediLink Self-Test Results</h1>']

                    summary = selftest_results.get('summary', {})
                    if summary.get('all_passed'):
                        html_parts.append('<p class="pass"><strong>All tests passed</strong></p>')
                    else:
                        html_parts.append('<p class="fail"><strong>{} of {} tests failed</strong></p>'.format(
                            summary.get('failed', 0), summary.get('total', 0)))

                    if selftest_results.get('note'):
                        html_parts.append('<p><em>{}</em></p>'.format(selftest_results['note']))

                    html_parts.append('<h2>Test Results</h2><pre>{}</pre>'.format(
                        json.dumps(selftest_results, indent=2, default=str)))

                    html_parts.append('<p><a href="/_diag?html=1">Full Diagnostics</a> | ')
                    html_parts.append('<a href="/_troubleshoot">Troubleshooting Guide</a> | ')
                    html_parts.append('<a href="/">Server Status</a></p>')
                    html_parts.append('</div></body></html>')

                    response_body = ''.join(html_parts)
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                else:
                    response_body = json.dumps(selftest_results, indent=2, default=str)
                    self.send_header('Content-type', 'application/json')

                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.end_headers()

                try:
                    self.wfile.write(response_body.encode('utf-8'))
                except Exception as write_err:
                    log("Failed to write selftest response: {}".format(write_err))

                record_request_event('GET', '/_selftest', 200, note='selftest', client=_get_client_ip(self))
                return
            elif self.path == '/status':
                maybe_warn_secure_idle()
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    payload = json.dumps(get_safe_status())
                except Exception:
                    payload = '{}'
                try:
                    self.wfile.write(payload.encode('ascii'))
                except Exception:
                    try:
                        self.wfile.write(payload.encode('utf-8'))
                    except Exception:
                        try:
                            self.wfile.write(payload.encode('utf-8', errors='ignore'))
                        except OSError as e:
                            if _is_expected_disconnect(e):
                                self.close_connection = True
                            else:
                                raise
                record_request_event('GET', '/status', 200, note='status', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_diag'):
                # Check if HTML format is requested (browser access)
                want_html = 'html=1' in self.path or 'format=html' in self.path
                include_full = 'full=1' in self.path or 'refresh=1' in self.path

                # Build basic diagnostics payload
                diag_payload = build_diagnostics_payload()

                # Run comprehensive diagnostics if available and requested (skip in HTTP mode)
                if not USE_HTTP_MODE and DIAGNOSTICS_AVAILABLE and include_full:
                    try:
                        # Enable auto_fix for runtime diagnostics
                        # User will be notified if server restart is needed
                        full_diag = run_connection_diagnostics(
                            cert_file=cert_file,
                            key_file=key_file,
                            server_port=server_port,
                            auto_fix=True,  # Enable auto-fix during runtime
                            openssl_cnf=get_openssl_cnf()
                        )
                        diag_payload['fullDiagnostics'] = full_diag

                        # If certificate was auto-fixed, add prominent notification
                        if full_diag.get('user_action_required') and full_diag['user_action_required'].get('requires_restart'):
                            diag_payload['certificateAutoFixed'] = True
                            diag_payload['restartRequired'] = True

                        diag_payload['firefoxNotes'] = get_firefox_xp_compatibility_notes()
                        diag_payload['browserHints'] = BROWSER_DIAGNOSTIC_HINTS
                    except Exception as full_diag_err:
                        log("Error running full diagnostics: {}".format(full_diag_err), level="WARNING")
                        diag_payload['fullDiagnosticsError'] = str(full_diag_err)

                self.send_response(200)

                if want_html and DIAGNOSTICS_AVAILABLE and not USE_HTTP_MODE:
                    # Return HTML diagnostics page
                    try:
                        if 'fullDiagnostics' not in diag_payload:
                            # Enable auto_fix for HTML diagnostics view
                            full_diag = run_connection_diagnostics(
                                cert_file=cert_file,
                                key_file=key_file,
                                server_port=server_port,
                                auto_fix=True,  # Enable auto-fix during runtime
                                openssl_cnf=get_openssl_cnf()
                            )
                            # Check if certificate was auto-fixed
                            if full_diag.get('user_action_required') and full_diag['user_action_required'].get('requires_restart'):
                                diag_payload['certificateAutoFixed'] = True
                                diag_payload['restartRequired'] = True
                        else:
                            full_diag = diag_payload['fullDiagnostics']
                        # Pass auto-fix flags to HTML builder
                        diag_html = html_build_diagnostics_html(full_diag, server_port, certificate_auto_fixed=diag_payload.get('certificateAutoFixed', False), restart_required=diag_payload.get('restartRequired', False))
                    except Exception as html_err:
                        log("Error building diagnostics HTML: {}".format(html_err), level="WARNING")
                        diag_html = "<html><body><h1>Diagnostics</h1><pre>{}</pre></body></html>".format(
                            json.dumps(diag_payload, indent=2)
                        )
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                    self._send_cors_origin_header()
                    self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                    self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                    self.send_header('Access-Control-Allow-Private-Network', 'true')
                    self.end_headers()
                    try:
                        self.wfile.write(diag_html.encode('utf-8'))
                    except Exception as write_err:
                        log("Failed to write diagnostics HTML: {}".format(write_err))
                else:
                    # Return JSON diagnostics
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps(diag_payload).encode('utf-8'))
                    except Exception as write_err:
                        log("Failed to write diagnostics payload: {}".format(write_err))
                record_request_event('GET', '/_diag', 200, note='diagnostics', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_troubleshoot'):
                # Comprehensive troubleshooting page
                try:
                    troubleshoot_html = self._build_troubleshoot_html()
                except Exception as ts_err:
                    log("Error building troubleshoot page: {}".format(ts_err), level="ERROR")
                    troubleshoot_html = html_build_simple_error_html("Troubleshooting Error", str(ts_err), server_port)
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.end_headers()
                try:
                    self.wfile.write(troubleshoot_html.encode('utf-8'))
                except Exception as write_err:
                    log("Failed to write troubleshoot page: {}".format(write_err))
                record_request_event('GET', '/_troubleshoot', 200, note='troubleshoot', client=_get_client_ip(self))
                return
            elif self.path == '/_cert_download' or self.path.startswith('/_cert_download'):
                # Certificate download endpoint - not available in HTTP mode
                if USE_HTTP_MODE:
                    self.send_response(404)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(b'Certificate download not available in HTTP mode')
                    record_request_event('GET', '/_cert_download', 404, note='cert-download-http-mode', client=_get_client_ip(self))
                    return
                # Serve certificate file for download (check before /_cert to avoid path matching conflict)
                try:
                    if os.path.exists(cert_file):
                        self.send_response(200)
                        self.send_header('Content-type', 'application/x-x509-ca-cert')
                        self.send_header('Content-Disposition', 'attachment; filename="medilink-local.crt"')
                        self._send_cors_origin_header()
                        self.end_headers()
                        with open(cert_file, 'rb') as f:
                            self.wfile.write(f.read())
                        record_request_event('GET', '/_cert_download', 200, note='cert-download', client=_get_client_ip(self))
                    else:
                        self.send_response(404)
                        self._set_headers()
                        self.end_headers()
                        self.wfile.write(b'Certificate file not found')
                        record_request_event('GET', '/_cert_download', 404, note='cert-not-found', client=_get_client_ip(self))
                except Exception as e:
                    log("Error serving certificate download: {}".format(e), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(b'Error serving certificate file')
                    except Exception:
                        pass
                return
            elif self.path == '/_cert_fingerprint':
                # Certificate fingerprint endpoint - not available in HTTP mode
                if USE_HTTP_MODE:
                    self.send_response(503)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": "Certificate fingerprint not available in HTTP mode"}).encode('utf-8'))
                    record_request_event('GET', '/_cert_fingerprint', 503, note='cert-fingerprint-http-mode', client=_get_client_ip(self))
                    return
                # Return certificate fingerprint as JSON (for diagnostics) - check before /_cert to avoid path matching conflict
                try:
                    fingerprint = http_get_certificate_fingerprint(cert_file, log=log)
                    cert_info = get_certificate_summary(cert_file)
                    response_data = {
                        'fingerprint': fingerprint,
                        'certificate': cert_info,
                        'download_url': '/_cert_download'
                    }
                    self.send_response(200)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps(response_data).encode('utf-8'))
                    record_request_event('GET', '/_cert_fingerprint', 200, note='cert-fingerprint', client=_get_client_ip(self))
                except Exception as e:
                    log("Error serving certificate fingerprint: {}".format(e), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': str(e)}).encode('utf-8'))
                    except Exception:
                        pass
                return
            elif self.path == '/_cert_diagnose_firefox':
                # Firefox certificate diagnosis endpoint - not available in HTTP mode
                if USE_HTTP_MODE:
                    self.send_response(503)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": "Firefox certificate diagnosis not available in HTTP mode"}).encode('utf-8'))
                    record_request_event('GET', '/_cert_diagnose_firefox', 503, note='cert-diagnose-firefox-http-mode', client=_get_client_ip(self))
                    return
                # Diagnose Firefox certificate exceptions - check before /_cert to avoid path matching conflict
                try:
                    if not FIREFOX_CERT_DIAG_AVAILABLE:
                        response_data = {'error': 'Firefox certificate diagnostics not available'}
                    else:
                        # Try to get Firefox path from config
                        firefox_path = medi.get('firefox_path') or medi.get('browser_path')
                        diagnosis = diagnose_firefox_certificate_exceptions(
                            cert_file=cert_file,
                            server_port=server_port,
                            firefox_path=firefox_path,
                            log=log
                        )
                        response_data = diagnosis

                    self.send_response(200)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps(response_data).encode('utf-8'))
                    record_request_event('GET', '/_cert_diagnose_firefox', 200, note='cert-diagnose-firefox', client=_get_client_ip(self))
                except Exception as e:
                    log("Error serving Firefox certificate diagnosis: {}".format(e), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': str(e)}).encode('utf-8'))
                    except Exception:
                        pass
                return
            elif self.path == '/_cert' or self.path.startswith('/_cert'):
                # Certificate info endpoint - not available in HTTP mode
                if USE_HTTP_MODE:
                    self.send_response(503)
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                    self._send_cors_origin_header()
                    self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                    self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                    self.send_header('Access-Control-Allow-Private-Network', 'true')
                    self.end_headers()
                    error_html = "<html><body><h1>Certificate Information</h1><p>Certificate information not available in HTTP mode.</p><p><a href='/'>Return to server status</a></p></body></html>"
                    try:
                        self.wfile.write(error_html.encode('utf-8'))
                    except Exception as write_err:
                        log("Failed to write cert error response: {}".format(write_err))
                    record_request_event('GET', '/_cert', 503, note='cert-info-http-mode', client=_get_client_ip(self))
                    return
                try:
                    cert_info = get_certificate_summary(cert_file)
                    fingerprint = http_get_certificate_fingerprint(cert_file, log=log)

                    # Detect browser from User-Agent header for tailored instructions
                    browser_info = None
                    try:
                        user_agent = self.headers.get('User-Agent', '')
                        if 'Firefox/52' in user_agent and 'Windows NT 5' in user_agent:
                            browser_info = {'name': 'Firefox', 'version': '52', 'isWindowsXP': True}
                        elif 'Firefox/' in user_agent:
                            # Try to extract Firefox version
                            match = re.search(r'Firefox/(\d+)', user_agent)
                            if match:
                                version = match.group(1)
                                is_xp = 'Windows NT 5' in user_agent
                                browser_info = {'name': 'Firefox', 'version': version, 'isWindowsXP': is_xp}
                    except Exception as ua_err:
                        log("Error detecting browser from User-Agent: {}".format(ua_err), level="DEBUG")

                    cert_html = html_build_cert_info_html(cert_info, fingerprint=fingerprint, browser_info=browser_info, server_port=server_port)
                except Exception as cert_err:
                    log("Error generating certificate info page: {}".format(cert_err), level="ERROR")
                    # Provide a fallback HTML page on error
                    cert_html = html_build_fallback_cert_html(str(cert_err), server_port)
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.end_headers()
                try:
                    self.wfile.write(cert_html.encode('utf-8'))
                except Exception as write_err:
                    log("Failed to write cert info payload: {}".format(write_err))
                record_request_event('GET', '/_cert', 200, note='cert-info', client=_get_client_ip(self))
                return
            elif self.path.startswith('/ca/root.crt'):
                if USE_HTTP_MODE:
                    self.send_response(404)
                    self._set_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps({'error': 'Managed CA not available in HTTP mode'}).encode('utf-8'))
                    record_request_event('GET', '/ca/root.crt', 404, note='ca-root-http-mode', client=_get_client_ip(self))
                    return
                if not is_managed_ca_active():
                    self.send_response(404)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': 'Managed CA mode disabled'}).encode('utf-8'))
                    except Exception:
                        pass
                    record_request_event('GET', '/ca/root.crt', 404, note='ca-root-missing', client=_get_client_ip(self))
                    return
                root_path = CA_PROFILE.get('root_cert_path')
                if not root_path or not os.path.exists(root_path):
                    try:
                        certificate_authority.ensure_root(CA_PROFILE, log=log, subprocess_module=subprocess)
                        root_path = CA_PROFILE.get('root_cert_path')
                    except Exception as root_err:
                        log("Unable to ensure managed CA root before download: {}".format(root_err), level="ERROR")
                if not root_path or not os.path.exists(root_path):
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': 'Managed CA root not available'}).encode('utf-8'))
                    except Exception:
                        pass
                    record_request_event('GET', '/ca/root.crt', 500, note='ca-root-error', client=_get_client_ip(self))
                    return
                try:
                    with open(root_path, 'rb') as root_file:
                        root_bytes = root_file.read()
                except Exception as read_err:
                    log("Failed to read managed CA root for download: {}".format(read_err), level="ERROR")
                    self.send_response(500)
                    self._set_headers()
                    self.end_headers()
                    try:
                        self.wfile.write(json.dumps({'error': 'Unable to read managed root'}).encode('utf-8'))
                    except Exception:
                        pass
                    record_request_event('GET', '/ca/root.crt', 500, note='ca-root-read-failed', client=_get_client_ip(self))
                    return
                self.send_response(200)
                self.send_header('Content-type', 'application/x-x509-ca-cert')
                self.send_header('Content-Disposition', 'attachment; filename="medilink-managed-root.crt"')
                self.send_header('Cache-Control', 'no-store, max-age=0')
                self.send_header('Content-Length', str(len(root_bytes)))
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.end_headers()
                try:
                    self.wfile.write(root_bytes)
                except Exception as write_err:
                    log("Failed to stream managed CA root: {}".format(write_err), level="ERROR")
                record_request_event('GET', '/ca/root.crt', 200, note='ca-root-download', client=_get_client_ip(self))
                return
            elif self.path.startswith('/ca/server-info'):
                refresh = 'refresh=1' in self.path or 'full=1' in self.path
                status = get_managed_ca_status(refresh=refresh) if not USE_HTTP_MODE else {}
                payload = {
                    'mode': CERT_MODE,
                    'managed': is_managed_ca_active() if not USE_HTTP_MODE else False,
                    'status': status,
                    'download': '/ca/root.crt' if not USE_HTTP_MODE else None,
                    'repair': '/ca/repair' if not USE_HTTP_MODE else None
                }
                if USE_HTTP_MODE:
                    payload['error'] = 'Managed CA not available in HTTP mode'
                response_code = 200 if (payload['managed'] or USE_HTTP_MODE) else 503
                self.send_response(response_code)
                self._set_headers()
                self.end_headers()
                try:
                    self.wfile.write(json.dumps(payload).encode('utf-8'))
                except Exception as info_err:
                    log("Failed to write CA status payload: {}".format(info_err), level="ERROR")
                record_request_event('GET', '/ca/server-info.json', response_code, note='ca-info', client=_get_client_ip(self))
                return
            auth_code = _extract_oauth_code_from_path(self.path)
            if auth_code:
                try:
                    auth_code = requests.utils.unquote(auth_code)
                except Exception as e:
                    log("Error unquoting authorization code: {}".format(e), level="ERROR")
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    try:
                        self.wfile.write("Invalid authorization code format. Please try again.".encode())
                    except Exception:
                        pass
                    return
                log("Received authorization code: {}".format(_mask_token_value(auth_code)), level="DEBUG")
                if oauth_is_valid_authorization_code(auth_code, log):
                    try:
                        token_response = exchange_code_for_token(auth_code)
                        if 'access_token' not in token_response:
                            if token_response.get("status") == "error":
                                self.send_response(400)
                                self.send_header('Content-type', 'text/html')
                                self.end_headers()
                                self.wfile.write(token_response["message"].encode())
                                return
                            raise ValueError("Access token not found in response.")
                    except Exception as e:
                        log("Error during token exchange: {}".format(e))
                        self.send_response(500)
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        self.wfile.write("An error occurred during authentication. Please try again.".encode())
                    else:
                        log("Token response: {}".format(_mask_sensitive_dict(token_response)), level="DEBUG")
                    if 'access_token' in token_response:
                        if shared_save_gmail_token(token_response, log=log, medi_config=medi):
                            # Success - continue with response
                            self.send_response(200)
                            self.send_header('Content-type', 'text/html')
                            self.end_headers()
                            self.wfile.write("Authentication successful. You can close this window now.".encode())

                        # Only launch webapp if not in Gmail send-only mode
                        global httpd
                        if httpd is not None and not getattr(httpd, 'gmail_send_only_mode', False):
                            initiate_link_retrieval(config)
                        else:
                            # For Gmail send-only: just signal completion
                            log("Gmail send-only authentication complete. Server will shutdown after token poll.")
                            shutdown_event.set()
                    else:
                        log("Authentication failed with response: {}".format(_mask_sensitive_dict(token_response)))
                        if 'error' in token_response:
                            error_description = token_response.get('error_description', 'No description provided.')
                            log("Error details: {}".format(error_description))
                        if token_response.get('error') == 'invalid_grant':
                            log("Invalid grant error encountered. Authorization code: {}, Response: {}".format(_mask_token_value(auth_code), _mask_sensitive_dict(token_response)), level="DEBUG")
                            check_invalid_grant_causes(auth_code)
                            shared_clear_token_cache(log=log, medi_config=medi)
                            user_message = "Authentication failed: Invalid or expired authorization code. Please try again."
                        else:
                            user_message = "Authentication failed. Please check the logs for more details."
                        self.send_response(400)
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        self.wfile.write(user_message.encode())
                        shutdown_event.set()
                else:
                    log("Invalid authorization code format: {}".format(_mask_token_value(auth_code)), level="DEBUG")
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    try:
                        self.wfile.write("Invalid authorization code format. Please try again.".encode())
                    except Exception:
                        pass
                    shutdown_event.set()
            elif self.path == '/downloaded-emails':
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                downloaded_emails = load_downloaded_emails()
                response = json.dumps({"downloadedEmails": list(downloaded_emails)})
                try:
                    self.wfile.write(response.encode('utf-8'))
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
            elif self.path == '/':
                # Serve friendly root status page
                # Detect Firefox from User-Agent
                user_agent = self.headers.get('User-Agent', '')
                is_firefox = 'Firefox/' in user_agent

                # Run Firefox certificate diagnostic if Firefox detected (skip in HTTP mode)
                firefox_diagnosis = None
                if not USE_HTTP_MODE and is_firefox and FIREFOX_CERT_DIAG_AVAILABLE:
                    try:
                        firefox_path = medi.get('firefox_path') or medi.get('browser_path')
                        firefox_diagnosis = diagnose_firefox_certificate_exceptions(
                            cert_file=cert_file,
                            server_port=server_port,
                            firefox_path=firefox_path,
                            log=log
                        )
                    except Exception as diag_err:
                        log("Error running Firefox diagnostic for root page: {}".format(diag_err), level="DEBUG")
                        # Continue without diagnosis - page will still render

                try:
                    safe_status = get_safe_status()
                    cert_info = get_certificate_summary(cert_file) if not USE_HTTP_MODE else None
                    ca_payload = {
                        'mode': CERT_MODE,
                        'managed': is_managed_ca_active() if not USE_HTTP_MODE else False,
                        'status': get_managed_ca_status() if not USE_HTTP_MODE else {}
                    }
                    root_html = html_build_root_status_html(
                        safe_status,
                        cert_info,
                        RECENT_REQUESTS,
                        server_port,
                        firefox_diagnosis=firefox_diagnosis,
                        ca_details=ca_payload,
                        use_http_mode=USE_HTTP_MODE
                    )
                except Exception as e:
                    log("Error building root status HTML: {}".format(e))
                    root_html = html_build_fallback_status_html(server_port)
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.end_headers()
                try:
                    self.wfile.write(root_html.encode('utf-8'))
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
                record_request_event('GET', '/', 200, note='root-page', client=_get_client_ip(self))
                return
            else:
                self.send_response(200)
                self._send_cors_origin_header()
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Access-Control-Allow-Private-Network', 'true')
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                try:
                    server_msg = b'HTTP server is running.' if USE_HTTP_MODE else b'HTTPS server is running.'
                    self.wfile.write(server_msg)
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
        except IndexError as e:
            log("IndexError in do_GET for path {}: {}".format(self.path, e), level="ERROR")
            try:
                self.send_response(400)
                self._set_headers()
                self.end_headers()
                error_response = json.dumps({"status": "error", "message": "Invalid request path format"})
                self.wfile.write(error_response.encode('utf-8'))
            except Exception:
                pass
        except OSError as e:
            from MediLink.gmail_http_utils import _is_expected_disconnect
            if _is_expected_disconnect(e):
                log("Client disconnected during GET request: {}".format(e), level="DEBUG")
                self.close_connection = True
            else:
                log("Connection error in GET request: {} - This usually indicates a network error, client disconnect, or socket issue on Windows XP".format(e), level="ERROR")
                send_error_response(self, 500, "Connection error", log_fn=log, error_details=str(e))
        except Exception as e:
            log_request_error(e, self.path, "GET", log, headers=self.headers)
            send_error_response(self, 500, "Internal server error", log_fn=log, error_details=str(e))
