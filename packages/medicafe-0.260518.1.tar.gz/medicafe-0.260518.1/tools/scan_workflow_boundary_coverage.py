#!/usr/bin/env python3
"""Find likely workflow-boundary test coverage gaps.

This is a reviewer aid, not a proof engine.  It scans stateful workflow code for
surfaces where request/attempt/outcome/artifact/operator wording can diverge,
then checks whether nearby feature-level tests consume
tests/workflow_boundary_contract.py.
"""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import sys
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple


SOURCE_ROOTS = ("MediCafe", "scripts", "cloud", "xp_client")
TEST_ROOTS = ("tests", os.path.join("scripts", "unified_model"))
HELPER_TEST_FILES = set([
    os.path.normcase(os.path.join("tests", "workflow_boundary_contract.py")),
    os.path.normcase(os.path.join("tests", "test_workflow_boundary_contract.py")),
    os.path.normcase(os.path.join("tests", "test_workflow_boundary_coverage_scanner.py")),
])

# Known scanner-noise sources:
# - `cloud/orchestrator/setup_*.py` are setup/ops scripts, not runtime workflow boundaries.
# - `MediCafe/self_test_canary_plugin.py` is explicitly "future wiring" and not production-wired.
_EXCLUDED_REL_PATH_PATTERNS = (
    re.compile(r"^cloud/orchestrator/setup_.*\.py$", re.IGNORECASE),
    re.compile(r"^medicafe/self_test_canary_plugin\.py$", re.IGNORECASE),
)

IDENTITY_TERMS = set([
    "run_id",
    "job_id",
    "attempt_id",
    "manifest_sha",
    "manifest_sha256",
    "anchor_run_id",
    "context_run_id",
    "phase_run_ids",
    "source_scope",
    "bundle_id",
])

STATE_TERMS = set([
    "latest",
    "accepted",
    "completed",
    "started",
    "running",
    "queued",
    "blocked",
    "deferred",
    "fail_closed",
    "ignored_mismatch",
    "terminal",
    "status",
])

ARTIFACT_TERMS = set([
    "artifact_path",
    "report_path",
    "summary_path",
    "bundle_path",
    "meta.json",
    "zip",
    "reports",
    "diagnostics_state",
    "run_cursor",
])

PRESERVED_CONTEXT_TERMS = set([
    "snapshot",
    "anchor",
    "anchored",
    "frozen",
    "cached",
    "queued_request",
    "request_context",
    "intent",
    "recommendation",
    "source_scope",
    "deferred",
])

MUTABLE_EVIDENCE_TERMS = set([
    "live",
    "current",
    "latest",
    "diagnostics_state",
    "run_cursor",
    "state_path",
    "cursor_path",
    "report_path",
    "artifact_path",
    "mtime",
])

CONSUMER_BOUNDARY_TERMS = set([
    "bundle",
    "package",
    "packaging",
    "attachment",
    "archive_name",
    "source_path",
    "source_kind",
    "freshness",
    "meta",
    "zip",
    "manifest",
    "recommendation",
    "operator",
    "wording",
    "runbook",
    "prompt",
])

WEAK_PRESERVED_CONTEXT_TERMS = set(["intent"])
WEAK_MUTABLE_EVIDENCE_TERMS = set(["current"])


@dataclass(frozen=True)
class BoundaryProfile:
    profile_id: str
    label: str
    keywords: Tuple[str, ...]
    recommendation: str


PROFILES = (
    BoundaryProfile(
        "queue_background_job",
        "Queues/background jobs",
        ("queue", "queued", "dequeue", "enqueue", "background", "worker", "job", "single_flight"),
        "Add a feature-level queue test that imports assert_workflow_boundary_clean and proves queued/running/blocked jobs cannot be packaged or worded as complete without same-job terminal success.",
    ),
    BoundaryProfile(
        "smoke_diagnostic_attempt",
        "Smoke tests and diagnostic attempts",
        ("smoke", "diagnostic", "attempt", "probe", "started", "latest", "report"),
        "Add a feature-level diagnostic test that models request, attempt state, report artifact, and recommendation/package wording for the same attempt id.",
    ),
    BoundaryProfile(
        "support_bundle_packaging",
        "Support bundle and run evidence packaging",
        ("support_bundle", "run_evidence", "artifact_triage", "bundle", "meta", "zip", "evidence_manifest", "attachment", "archive_name", "source_path", "source_kind", "freshness", "latest"),
        "Add a feature-level packaging test that treats each attachment row as a workflow-boundary surface, rejects stale or wrong-target artifacts, and only marks bundle evidence accepted after same-target terminal evidence.",
    ),
    BoundaryProfile(
        "attachment_manifest_scope",
        "Attachment manifest scope and latest-artifact gating",
        ("attachment", "archive_name", "source_path", "source_kind", "freshness", "scope", "run_id", "anchor_run_id", "latest", "ignored_mismatch"),
        "Add a feature-level attachment-manifest test with a wrong-target latest file and a same-target terminal file; assert the wrong-target file is omitted or explicitly ignored_mismatch while the same-target file is accepted.",
    ),
    BoundaryProfile(
        "cloud_readiness_recommendation",
        "Cloud readiness recommendations",
        ("recommendation", "recommended_action", "follow_recommendation", "best_now", "preferred_when_stable", "operator"),
        "Add a feature-level recommendation test that binds recommendation intent, target identity, attempt state, terminal evidence, and operator wording through assert_workflow_boundary_clean.",
    ),
    BoundaryProfile(
        "launcher_followthrough",
        "Launcher followthrough/autofollow/deferred actions",
        ("followthrough", "autofollow", "deferred", "post_update", "launcher", "start_cloud", "operator_execution_mode"),
        "Add a feature-level launcher test that proves deferred/autofollow request state does not override launch-time target identity or terminal outcome.",
    ),
    BoundaryProfile(
        "phase_handoff_lineage",
        "Phase B/C/D/E handoff and run-id lineage",
        ("handoff", "last_phase", "phase_b", "phase_c", "phase_d", "phase_e", "run_cursor", "manifest_sha", "lineage"),
        "Add a feature-level handoff test that exercises mismatched phase run ids or manifest SHAs and asserts fail-closed package/recommendation behavior.",
    ),
    BoundaryProfile(
        "preserved_context_live_evidence",
        "Preserved context plus mutable evidence consumer boundary",
        tuple(sorted(PRESERVED_CONTEXT_TERMS | MUTABLE_EVIDENCE_TERMS | CONSUMER_BOUNDARY_TERMS)),
        "Add a feature-level test where a preserved context snapshot/request/recommendation is followed by live state or latest artifact advancement before the consumer finalizes; assert the consumer re-reconciles same-target evidence or marks the live evidence stale, follow-up-only, ignored, or fail_closed.",
    ),
    BoundaryProfile(
        "latest_state_artifact",
        "Latest/state/artifact path acceptance logic",
        ("latest", "accepted", "completed", "started", "running", "fail_closed", "ignored_mismatch", "artifact_path", "report_path"),
        "Add a feature-level test for latest-path selection that refuses wrong-target latest artifacts and labels them stale, ignored, or fail_closed.",
    ),
)


@dataclass
class CodeBlock:
    rel_path: str
    qualname: str
    lineno: int
    end_lineno: int
    text: str


@dataclass
class TestFile:
    rel_path: str
    text: str
    consumes_contract: bool


@dataclass
class Finding:
    profile: BoundaryProfile
    block: CodeBlock
    score: int
    matched_keywords: List[str]
    existing_tests: List[TestFile]

    @property
    def contract_coverage_exists(self) -> bool:
        return any(t.consumes_contract for t in self.existing_tests)


def _repo_root_from_here() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8-sig", errors="ignore") as handle:
        return handle.read()


def _iter_py_files(root: str, rel_roots: Sequence[str]) -> Iterable[str]:
    for rel_root in rel_roots:
        abs_root = os.path.join(root, rel_root)
        if not os.path.isdir(abs_root):
            continue
        for dirpath, dirnames, filenames in os.walk(abs_root):
            dirnames[:] = [
                d for d in dirnames
                if d not in (".git", "__pycache__", ".pytest_cache", "build", "dist")
            ]
            for filename in filenames:
                if filename.endswith(".py"):
                    yield os.path.join(dirpath, filename)


def _rel(root: str, path: str) -> str:
    return os.path.relpath(path, root).replace(os.sep, "/")


def _line_offsets(text: str) -> List[int]:
    offsets = [0]
    pos = 0
    for line in text.splitlines(True):
        pos += len(line)
        offsets.append(pos)
    return offsets


def _slice_lines(text: str, lineno: int, end_lineno: int) -> str:
    lines = text.splitlines(True)
    start = max(lineno - 1, 0)
    end = min(end_lineno, len(lines))
    return "".join(lines[start:end])


def _iter_code_blocks(root: str) -> List[CodeBlock]:
    blocks: List[CodeBlock] = []
    for path in _iter_py_files(root, SOURCE_ROOTS):
        rel_path = _rel(root, path)
        base = os.path.basename(path)
        if base.startswith("test_") or base.endswith("_test.py"):
            continue
        text = _read_text(path)
        try:
            tree = ast.parse(text, filename=rel_path)
        except SyntaxError:
            blocks.append(CodeBlock(rel_path, "<module>", 1, max(1, len(text.splitlines())), text))
            continue

        found = False
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                lineno = int(getattr(node, "lineno", 1) or 1)
                end_lineno = int(getattr(node, "end_lineno", lineno) or lineno)
                block_text = _slice_lines(text, lineno, end_lineno)
                blocks.append(CodeBlock(rel_path, getattr(node, "name", "<block>"), lineno, end_lineno, block_text))
                found = True
        if not found:
            blocks.append(CodeBlock(rel_path, "<module>", 1, max(1, len(text.splitlines())), text))
    return blocks


def _test_file_consumes_contract(rel_path: str, text: str) -> bool:
    normalized = os.path.normcase(rel_path.replace("/", os.sep))
    if normalized in HELPER_TEST_FILES:
        return False
    return "assert_workflow_boundary_clean" in text or "WorkflowBoundaryContract" in text


def _iter_tests(root: str) -> List[TestFile]:
    tests = []
    for path in _iter_py_files(root, TEST_ROOTS):
        rel_path = _rel(root, path)
        base = os.path.basename(path)
        if not (base.startswith("test_") or base.endswith("_test.py")):
            continue
        text = _read_text(path)
        tests.append(TestFile(rel_path, text, _test_file_consumes_contract(rel_path, text)))
    return tests


def _term_hits(text: str, terms: Iterable[str]) -> List[str]:
    lower = text.lower()
    hits = []
    for term in terms:
        if term.lower() in lower:
            hits.append(term)
    return sorted(set(hits))


def _tokens(value: str) -> List[str]:
    pieces = re.split(r"[^A-Za-z0-9]+", value.lower())
    return [p for p in pieces if len(p) >= 4]


def _matching_tests(block: CodeBlock, profile: BoundaryProfile, tests: Sequence[TestFile]) -> List[TestFile]:
    file_stem = os.path.splitext(os.path.basename(block.rel_path))[0].lower()
    qualname = block.qualname.lower()
    direct_terms = set([file_stem])
    direct_terms.update(t for t in _tokens(file_stem) if len(t) >= 5)
    direct_terms.update(t for t in _tokens(qualname) if len(t) >= 5)
    direct_terms.discard("")

    matches = []
    for test in tests:
        text = test.text.lower()
        test_path = test.rel_path.lower()
        score = 0
        for term in direct_terms:
            if term and (term in text or term in test_path):
                score += 1
        if file_stem in text or file_stem in test_path:
            score += 3
        if qualname != "<module>" and qualname in text:
            score += 3
        if score >= 3:
            matches.append(test)
    matches.sort(key=lambda t: (not t.consumes_contract, t.rel_path))
    return matches[:6]


def _score_block(block: CodeBlock, profile: BoundaryProfile) -> Tuple[int, List[str]]:
    haystack = (block.rel_path + "\n" + block.qualname + "\n" + block.text).lower()
    profile_hits = _term_hits(haystack, profile.keywords)
    identity_hits = _term_hits(haystack, IDENTITY_TERMS)
    state_hits = _term_hits(haystack, STATE_TERMS)
    artifact_hits = _term_hits(haystack, ARTIFACT_TERMS)
    preserved_hits = _term_hits(haystack, PRESERVED_CONTEXT_TERMS)
    mutable_hits = _term_hits(haystack, MUTABLE_EVIDENCE_TERMS)
    consumer_hits = _term_hits(haystack, CONSUMER_BOUNDARY_TERMS)
    if not profile_hits:
        return 0, []
    if not identity_hits and not state_hits and not artifact_hits:
        return 0, []
    if profile.profile_id == "preserved_context_live_evidence":
        strong_preserved_hits = [
            hit for hit in preserved_hits
            if hit not in WEAK_PRESERVED_CONTEXT_TERMS
        ]
        strong_mutable_hits = [
            hit for hit in mutable_hits
            if hit not in WEAK_MUTABLE_EVIDENCE_TERMS
        ]
        preserved_ok = bool(strong_preserved_hits) or (
            "intent" in preserved_hits and bool(identity_hits)
        )
        mutable_ok = bool(strong_mutable_hits)
        if not preserved_ok or not mutable_ok or not consumer_hits:
            return 0, []
        profile_hits = sorted(set(preserved_hits + mutable_hits + consumer_hits))

    score = len(profile_hits) * 3 + len(identity_hits) * 2 + len(state_hits) + len(artifact_hits)
    if profile.profile_id == "preserved_context_live_evidence":
        score += 8
    if block.qualname != "<module>":
        score += 1
    if "tests/" in block.rel_path or block.rel_path.startswith("scripts/unified_model/test_"):
        score -= 4
    return score, sorted(set(profile_hits + identity_hits + state_hits + artifact_hits))


def scan_repo(root: str, limit: int = 15) -> Dict[str, object]:
    root = os.path.abspath(root)
    tests = _iter_tests(root)
    contract_consumers = sorted(t.rel_path for t in tests if t.consumes_contract)
    findings: List[Finding] = []

    for block in _iter_code_blocks(root):
        if block.rel_path.startswith("tests/"):
            continue
        rel_path = block.rel_path.replace("\\", "/")
        if any(pattern.search(rel_path) for pattern in _EXCLUDED_REL_PATH_PATTERNS):
            continue
        for profile in PROFILES:
            score, hits = _score_block(block, profile)
            if score < 10:
                continue
            matches = _matching_tests(block, profile, tests)
            findings.append(Finding(profile, block, score, hits, matches))

    findings.sort(key=lambda f: (f.contract_coverage_exists, -f.score, f.block.rel_path, f.block.lineno))
    limited = findings[:limit]
    missing = [f for f in findings if not f.contract_coverage_exists]
    return {
        "repo_root": root,
        "contract_consumers": contract_consumers,
        "candidate_count": len(findings),
        "missing_contract_count": len(missing),
        "findings": [_finding_to_dict(f) for f in limited],
    }


def _finding_to_dict(finding: Finding) -> Dict[str, object]:
    return {
        "suspected_workflow_boundary": finding.profile.label,
        "profile_id": finding.profile.profile_id,
        "file": finding.block.rel_path,
        "function": finding.block.qualname,
        "line": finding.block.lineno,
        "score": finding.score,
        "matched_keywords": finding.matched_keywords[:16],
        "existing_tests": [
            {
                "file": t.rel_path,
                "workflow_boundary_contract_coverage": t.consumes_contract,
            }
            for t in finding.existing_tests
        ],
        "workflow_boundary_contract_coverage_exists": finding.contract_coverage_exists,
        "recommended_next_test": finding.profile.recommendation,
    }


def render_text(result: Dict[str, object]) -> str:
    lines = []
    lines.append("Workflow-boundary coverage scan")
    lines.append("Repo: {0}".format(result["repo_root"]))
    lines.append("Candidates: {0}; likely missing contract coverage: {1}".format(
        result["candidate_count"],
        result["missing_contract_count"],
    ))
    consumers = result.get("contract_consumers") or []
    if consumers:
        lines.append("Feature-level contract consumers: {0}".format(", ".join(consumers)))
    else:
        lines.append("Feature-level contract consumers: none")
    lines.append("")

    findings = result.get("findings") or []
    if not findings:
        lines.append("No suspected workflow-boundary gaps found by this heuristic.")
        return "\n".join(lines)

    for idx, finding in enumerate(findings, 1):
        tests = finding.get("existing_tests") or []
        if tests:
            test_bits = []
            for test in tests:
                suffix = "contract" if test.get("workflow_boundary_contract_coverage") else "test-only"
                test_bits.append("{0} [{1}]".format(test.get("file"), suffix))
            tests_line = "; ".join(test_bits)
        else:
            tests_line = "none found"
        coverage = "yes" if finding.get("workflow_boundary_contract_coverage_exists") else "no"
        lines.append("{0}. {1}".format(idx, finding.get("suspected_workflow_boundary")))
        lines.append("   Files/functions: {0}:{1} {2}".format(
            finding.get("file"),
            finding.get("line"),
            finding.get("function"),
        ))
        lines.append("   Existing tests: {0}".format(tests_line))
        lines.append("   Workflow-boundary contract coverage exists: {0}".format(coverage))
        lines.append("   Matched signals: {0}".format(", ".join(finding.get("matched_keywords") or [])))
        lines.append("   Recommended next test: {0}".format(finding.get("recommended_next_test")))
    return "\n".join(lines)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Scan MediCafe workflow-boundary contract coverage")
    parser.add_argument("--root", default=_repo_root_from_here(), help="Repository root")
    parser.add_argument("--limit", type=int, default=15, help="Maximum findings to print")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    parser.add_argument(
        "--fail-on-missing-contract",
        action="store_true",
        help="Exit 1 when likely gaps without contract-consuming feature tests are found",
    )
    args = parser.parse_args(argv)

    result = scan_repo(args.root, limit=args.limit)
    if args.format == "json":
        sys.stdout.write(json.dumps(result, indent=2, sort_keys=True))
        sys.stdout.write("\n")
    else:
        sys.stdout.write(render_text(result))
        sys.stdout.write("\n")
    if args.fail_on_missing_contract and int(result.get("missing_contract_count") or 0) > 0:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
