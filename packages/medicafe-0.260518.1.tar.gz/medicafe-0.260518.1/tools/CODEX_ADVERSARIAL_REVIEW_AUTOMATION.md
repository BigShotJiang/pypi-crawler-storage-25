# Codex Adversarial Review Automation

Use this prompt as an independent review pass after implementation and before merge when the change touches:

- parsers or validators
- encoding or header readers
- path resolution or artifact lookup
- workflow state, queued/running/terminal surfaces
- evidence manifests, attachments, bundles, or recommendation wording
- XP packaging or installed-layout file-path loading

Start by reading:

- `docs/CHANGE_SURFACE_CONTROL.md`
- `docs/PR_REVIEW_CHECKLIST.md`
- the author's change-surface declaration if available

Suggested prompt body:

```text
Run an adversarial review pass for this change.

1. Restate the target identity and the surfaces that claim to represent it.
2. Try to break the contract using nearby valid or stale shapes:
   - grammar and whitespace variants
   - inline comments or markers
   - UTF-8 BOM / UTF-16 / header read failures
   - Windows versus POSIX path forms
   - stale inner metadata versus filename-derived identity
   - scoped versus unscoped latest-artifact fallback
   - queued / running / partial / fail-closed states
   - repo-root success versus installed-layout or XP file-path loading
3. Identify any place where a request, path, latest file, or helper artifact could be mistaken for same-target terminal success.
4. If workflow boundaries are involved, run:
   `py -3.11 tools/scan_workflow_boundary_coverage.py --format json --limit 30`
5. Prefer adding or updating feature-level tests that consume `tests/workflow_boundary_contract.py` when the change crosses stateful surfaces.
6. Return only concrete findings or a clean result with residual risk notes.
```

## When To Use A Subagent

An independent Codex subagent is useful when the diff is broad enough that one pass is likely to miss adjacent surfaces, especially:

- many-file workflow rollouts
- parser plus packaging plus operator-surface changes in one branch
- high-churn files where the implementer already had to hold too much local state

Do not require a subagent for every small fix. The required behavior is the adversarial pass itself; the subagent is only one execution strategy for independence.
