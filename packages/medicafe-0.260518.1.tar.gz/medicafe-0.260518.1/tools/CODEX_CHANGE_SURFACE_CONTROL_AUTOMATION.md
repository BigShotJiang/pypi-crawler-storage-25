# Codex Change Surface Control Automation

Use this prompt at feature start for any `feat` or risky `chore` that touches parsing, workflow state, reports, bundles, recommendations, artifact lookup, or XP packaging.

Start by reading:

- `docs/CHANGE_SURFACE_CONTROL.md`
- `docs/PR_REVIEW_CHECKLIST.md`

Suggested prompt body:

```text
Apply the change-surface-control workflow to this repository.

Before editing:
1. Identify the target identity the change must preserve.
2. Fill out the change-surface declaration template from `docs/templates/CHANGE_SURFACE_DECLARATION_TEMPLATE.md`.
3. List the required coherent surfaces:
   - state / cursor
   - reports / artifacts
   - recommendations / operator wording
   - evidence manifest / bundle attachments
   - launcher or UI entrypoints
   - XP packaging or installed-layout loading
4. Choose one canonical parser, normalizer, or resolver so nearby callers do not drift.
5. If the work is broad, propose PR slices that match the declared surfaces instead of one bulk rollout.

During implementation:
6. Reuse the canonical helper instead of adding another local parser or fallback ladder.
7. Make mismatch, stale, follow-up-only, and fail-closed outcomes explicit.
8. Add targeted tests for the declared contract, not just the happy path.

Before concluding:
9. Summarize which surfaces were intentionally updated.
10. Hand off to the adversarial review pass in `tools/CODEX_ADVERSARIAL_REVIEW_AUTOMATION.md`.
```

This is the default build-time scaffold. Use it before the workflow-boundary scan when the feature is still being shaped.
