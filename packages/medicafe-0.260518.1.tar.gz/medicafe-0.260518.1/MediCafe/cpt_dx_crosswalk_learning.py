"""Apply reviewed CPT/diagnosis analytics proposals to the crosswalk.

This module is intentionally narrow. Proposal generation remains report-only in
``scripts/unified_model/run_x12_cpt_dx_association.py``; this module performs a
confirmed config update only after the operator accepts that proposal.
"""
from __future__ import print_function

import copy
import io
import json
import os
import time


APPLY_SCHEMA_VERSION = "x12_cpt_dx_crosswalk_apply_v1"
PROPOSAL_SCHEMA_VERSION = "x12_cpt_dx_crosswalk_proposal_v1"
PROPOSAL_WORKFLOW_BOUNDARY = "report_only_review_required"


def _to_text(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def _normalize_code(value):
    out = []
    for ch in _to_text(value).upper():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def _iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def load_proposal(path):
    if not path:
        return {}
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    return data


def _clean_diagnosis_to_procedure(rows):
    out = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        dx = _to_text(row.get("diagnosis_code")).strip().upper()
        cpt = _normalize_code(row.get("cpt_code"))
        if dx and cpt:
            out[dx] = cpt
    return out


def _clean_procedure_to_diagnosis(mapping):
    out = {}
    if not isinstance(mapping, dict):
        return out
    for cpt in mapping:
        cpt_norm = _normalize_code(cpt)
        if not cpt_norm:
            continue
        values = mapping.get(cpt)
        if not isinstance(values, list):
            continue
        rows = []
        for value in values:
            dx = _to_text(value).strip().upper()
            if dx:
                rows.append(dx)
        if rows:
            out[cpt_norm] = sorted(list(set(rows)))
    return out


def _find_existing_normalized_key(mapping, code):
    target = _normalize_code(code)
    if not target or not isinstance(mapping, dict):
        return ""
    for key in mapping:
        if _normalize_code(key) == target:
            return key
    return ""


def _validate_proposal_boundary(proposal):
    if not isinstance(proposal, dict):
        return "invalid_proposal_schema"
    if proposal.get("schema_version") != PROPOSAL_SCHEMA_VERSION:
        return "invalid_proposal_schema"
    if proposal.get("workflow_boundary") != PROPOSAL_WORKFLOW_BOUNDARY:
        return "invalid_proposal_workflow_boundary"
    if proposal.get("requires_apply_confirmation") is not True:
        return "proposal_requires_apply_confirmation"
    return ""


def merge_crosswalk_with_proposal(crosswalk, proposal):
    merged = copy.deepcopy(crosswalk if isinstance(crosswalk, dict) else {})
    if not isinstance(proposal, dict):
        proposal = {}

    report = {
        "schema_version": APPLY_SCHEMA_VERSION,
        "run_id": _to_text(proposal.get("run_id")),
        "generated_at_utc": _iso_utc_now(),
        "workflow_boundary": "confirmed_config_update",
        "workflow_name": "cpt_dx_crosswalk_apply",
        "claim_workflow_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
        "changed": False,
        "diagnosis_to_procedure_added": 0,
        "diagnosis_to_procedure_updated": 0,
        "procedure_to_diagnosis_added": 0,
        "conflicts_skipped": 0,
        "baseline_pairs_removed": 0,
        "diagnosis_to_medisoft_added": 0,
        "diagnosis_to_medisoft_bridge_present_count": 0,
        "diagnosis_to_medisoft_bridge_missing_count": 0,
        "diagnosis_to_medisoft_bridge_ambiguous_count": 0,
        "diagnosis_to_medisoft_bridge_not_auto_applied": True,
        "error": "",
    }

    validation_error = _validate_proposal_boundary(proposal)
    if validation_error:
        report["error"] = validation_error
        return merged, report

    bridge = proposal.get("diagnosis_to_medisoft_bridge_completeness")
    if isinstance(bridge, dict):
        report["diagnosis_to_medisoft_bridge_present_count"] = int(bridge.get("bridge_present_count", 0) or 0)
        report["diagnosis_to_medisoft_bridge_missing_count"] = int(bridge.get("bridge_missing_count", 0) or 0)
        report["diagnosis_to_medisoft_bridge_ambiguous_count"] = int(bridge.get("bridge_ambiguous_count", 0) or 0)

    dx_existing = merged.get("diagnosis_to_procedure")
    if not isinstance(dx_existing, dict):
        dx_existing = {}
        merged["diagnosis_to_procedure"] = dx_existing

    for dx, cpt in _clean_diagnosis_to_procedure(
            proposal.get("diagnosis_to_procedure_eligible") or []).items():
        existing_key = _find_existing_normalized_key(dx_existing, dx)
        write_key = existing_key or dx
        existing = _normalize_code(dx_existing.get(existing_key)) if existing_key else ""
        if existing == cpt:
            continue
        if existing and existing != cpt:
            report["conflicts_skipped"] += 1
            continue
        if existing:
            report["diagnosis_to_procedure_updated"] += 1
        else:
            report["diagnosis_to_procedure_added"] += 1
        dx_existing[write_key] = cpt
        report["changed"] = True

    proc_existing = merged.get("procedure_to_diagnosis")
    if not isinstance(proc_existing, dict):
        proc_existing = {}
        merged["procedure_to_diagnosis"] = proc_existing

    additions = _clean_procedure_to_diagnosis(proposal.get("procedure_to_diagnosis_additions"))
    for cpt in sorted(additions.keys()):
        current = proc_existing.get(cpt)
        if not isinstance(current, list):
            current = []
        seen = set([_normalize_code(item) for item in current])
        changed_list = False
        for dx in additions.get(cpt) or []:
            dx_norm = _normalize_code(dx)
            if dx_norm and dx_norm not in seen:
                current.append(dx)
                seen.add(dx_norm)
                changed_list = True
                report["procedure_to_diagnosis_added"] += 1
        if changed_list:
            proc_existing[cpt] = sorted(current)
            report["changed"] = True

    return merged, report


def _load_runtime_config_and_crosswalk(config_path="", crosswalk_path=""):
    from MediCafe import MediLink_ConfigLoader
    if config_path or crosswalk_path:
        return MediLink_ConfigLoader.load_configuration(config_path or None, crosswalk_path or None)
    return MediLink_ConfigLoader.load_configuration()


def apply_proposal_file(proposal_path, config=None, crosswalk=None, client=None, save=True):
    proposal = load_proposal(proposal_path)
    if config is None or crosswalk is None:
        loaded_config, loaded_crosswalk = _load_runtime_config_and_crosswalk()
        if config is None:
            config = loaded_config
        if crosswalk is None:
            crosswalk = loaded_crosswalk
    merged, report = merge_crosswalk_with_proposal(crosswalk, proposal)
    report["proposal_path_basename"] = os.path.basename(_to_text(proposal_path))
    report["save_attempted"] = False
    report["save_ok"] = False
    if save and not report.get("error") and report.get("changed"):
        report["save_attempted"] = True
        try:
            from MediBot.MediBot_Crosswalk_Utils import save_crosswalk
            report["save_ok"] = bool(save_crosswalk(
                client,
                config if isinstance(config, dict) else {},
                merged,
                skip_api_operations=True,
            ))
        except Exception as exc:
            report["error"] = "save_failed:{0}".format(_to_text(exc)[:160])
            report["save_ok"] = False
    elif save and not report.get("changed"):
        report["save_ok"] = True
    return merged, report


def write_apply_report(local_storage_path, report):
    if not local_storage_path:
        return ""
    reports_dir = os.path.join(local_storage_path, "reports")
    try:
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return ""
    path = os.path.join(reports_dir, "x12_cpt_dx_crosswalk_apply_latest.json")
    try:
        with io.open(path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(report if isinstance(report, dict) else {}, indent=2, sort_keys=True, ensure_ascii=True))
            handle.write("\n")
        txt_path = os.path.join(reports_dir, "x12_cpt_dx_crosswalk_apply_latest.txt")
        with io.open(txt_path, "w", encoding="utf-8") as handle:
            handle.write("CPT/DX crosswalk apply\n")
            handle.write("changed={0}\n".format(bool(report.get("changed")) if isinstance(report, dict) else False))
            handle.write("save_ok={0}\n".format(bool(report.get("save_ok")) if isinstance(report, dict) else False))
            handle.write("error={0}\n".format(_to_text(report.get("error")) if isinstance(report, dict) else ""))
        return path
    except Exception:
        return ""
