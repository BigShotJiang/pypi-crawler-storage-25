#!/usr/bin/env python
from __future__ import print_function

import json
import os
import time


CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME = "cloud_work_shutdown_request.json"
OPERATOR_SHUTDOWN_REQUESTED = "OPERATOR_SHUTDOWN_REQUESTED"
ACTIVE_REQUEST_STATUSES = ("requested", "running", "acknowledged")
TERMINAL_REQUEST_STATUSES = ("canceled", "stopped", "completed", "terminal")


def iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def request_path(lab_root):
    return os.path.join(str(lab_root or ""), "reports", CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME)


def read_request(lab_root):
    path = request_path(lab_root)
    try:
        if not os.path.isfile(path):
            return {}
        with open(path, "r") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except Exception:
        return {}
    return {}


def write_request(lab_root, payload):
    path = request_path(lab_root)
    data = payload if isinstance(payload, dict) else {}
    try:
        reports_dir = os.path.dirname(path)
        if reports_dir and not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
        tmp_path = path + ".tmp"
        with open(tmp_path, "w") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
            handle.write("\n")
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass
        os.rename(tmp_path, path)
        return path
    except Exception:
        return ""


def active_request(lab_root):
    req = read_request(lab_root)
    status = str(req.get("status") or "").strip()
    if status in ACTIVE_REQUEST_STATUSES:
        return req
    return {}


def request_is_terminal(request):
    status = str((request if isinstance(request, dict) else {}).get("status") or "").strip()
    return status in TERMINAL_REQUEST_STATUSES


def mark_request_stopped(lab_root, request, updates):
    req = dict(request if isinstance(request, dict) else {})
    req["status"] = "stopped"
    req["stopped_at_utc"] = iso_utc_now()
    req["stop_reason"] = OPERATOR_SHUTDOWN_REQUESTED
    if isinstance(updates, dict):
        req.update(updates)
    write_request(lab_root, req)
    return req
