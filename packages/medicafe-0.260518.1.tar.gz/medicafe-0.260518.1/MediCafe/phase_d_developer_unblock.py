#!/usr/bin/env python
"""Phase D developer-unblock evidence contract helpers.

The XP operator should not have to decide which helper report matters. Phase D
summaries declare the developer-safe evidence reports here, and bundle builders
consume the same contract.
"""
from __future__ import print_function

import os


SCHEMA_VERSION = "phase_d_developer_unblock_v1"
EXTERNAL_PATIENT_ID_CONTRACT_SCHEMA_VERSION = "external_patient_id_contract_v1"
ACTION_RESOLVE_EXTERNAL_PATIENT_ID_CONTRACT = "resolve_external_patient_id_contract_pressure"
BLOCKER_INVALID_EXTERNAL_PATIENT_ID = "invalid_external_patient_id"


def _safe_str(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def _safe_basename(path):
    text = _safe_str(path).strip()
    if not text:
        return ""
    return os.path.basename(text)


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def _dict(value):
    return value if isinstance(value, dict) else {}


def _copy_int_dict(value):
    out = {}
    if not isinstance(value, dict):
        return out
    for key, raw in value.items():
        text = _safe_str(key).strip()
        if not text:
            continue
        count = _safe_int(raw, 0)
        if count > 0:
            out[text] = count
    return out


def _sum_counts(value):
    total = 0
    if not isinstance(value, dict):
        return 0
    for raw in value.values():
        total += _safe_int(raw, 0)
    return total


def _count_any(counts, names):
    total = 0
    data = _dict(counts)
    wanted = {}
    for name in names:
        wanted[_safe_str(name).strip().lower()] = True
    for key, value in data.items():
        if _safe_str(key).strip().lower() in wanted:
            total += _safe_int(value, 0)
    return total


def _phase_d_scope(summary):
    data = _dict(summary)
    constraints = _dict(data.get("constraint_skip_counts"))
    count = _safe_int(constraints.get("patient_invalid_external_id"), 0)
    by_source_contract = _copy_int_dict(
        constraints.get("patient_invalid_external_id_by_source_contract"))
    by_disposition = _copy_int_dict(
        constraints.get("patient_invalid_external_id_by_contract_disposition"))
    by_artifact = _copy_int_dict(
        constraints.get("patient_invalid_external_id_by_artifact_class"))
    by_pattern = _copy_int_dict(
        constraints.get("patient_invalid_external_id_by_pattern_family"))
    by_field = _copy_int_dict(constraints.get("patient_invalid_external_id_by_source"))
    if count <= 0:
        count = _sum_counts(by_source_contract)
    if count > 0 and not by_source_contract:
        by_source_contract = {"unknown_external_patient_id_contract": count}
    if count > 0 and not by_disposition:
        by_disposition = {"unknown": count}
    if count > 0 and not by_artifact:
        by_artifact = {"unknown": count}
    leading_zero = (
        _count_any(by_pattern, ("too_short", "wrong_length_short"))
        or _count_any(by_disposition, ("numeric_wrong_length",))
    )
    leading_by_source = {}
    if leading_zero > 0 and len(by_source_contract) == 1:
        for key in by_source_contract:
            leading_by_source[key] = min(leading_zero, _safe_int(by_source_contract.get(key), 0))
    return {
        "scope": "phase_d_patient_upsert",
        "count": count,
        "source_contract_counts": by_source_contract,
        "contract_disposition_counts": by_disposition,
        "artifact_class_counts": by_artifact,
        "field_counts": by_field,
        "pattern_family_counts": by_pattern,
        "leading_zero_loss_candidate_count": leading_zero,
        "leading_zero_loss_candidate_by_source_contract": leading_by_source,
    }


def _layer1_scope(summary):
    data = _dict(summary)
    count = _safe_int(data.get("layer1_invalid_external_patient_id_count"), 0)
    if count <= 0:
        count = _safe_int(data.get("layer1_invalid_external_pressure"), 0)
    by_source_contract = _copy_int_dict(
        data.get("layer1_invalid_external_patient_id_by_source_contract"))
    by_disposition = _copy_int_dict(
        data.get("layer1_invalid_external_patient_id_by_contract_disposition"))
    if count <= 0:
        count = _sum_counts(by_source_contract)
    if count > 0 and not by_source_contract:
        by_source_contract = {"unknown_external_patient_id_contract": count}
    if count > 0 and not by_disposition:
        by_disposition = {"unknown": count}
    leading_by_source = _copy_int_dict(
        data.get("layer1_leading_zero_loss_candidate_by_source_contract"))
    leading_count = _safe_int(data.get("layer1_leading_zero_loss_candidate_count"), 0)
    if leading_count <= 0:
        leading_count = _sum_counts(leading_by_source)
    return {
        "scope": "layer1_join_quality",
        "count": count,
        "source_contract_counts": by_source_contract,
        "contract_disposition_counts": by_disposition,
        "artifact_class_counts": {},
        "field_counts": {},
        "pattern_family_counts": {},
        "leading_zero_loss_candidate_count": leading_count,
        "leading_zero_loss_candidate_by_source_contract": leading_by_source,
    }


def _has_layer1_invalid_block(summary):
    data = _dict(summary)
    status = _safe_str(data.get("layer1_data_quality_status")).strip().lower()
    blocker = _safe_str(data.get("layer1_top_blocker")).strip().lower()
    integration = _safe_str(data.get("layer1_dat_integration_blocker")).strip().lower()
    blockers = data.get("layer1_data_quality_blockers")
    if not isinstance(blockers, list):
        blockers = []
    if status == "blocked":
        return True
    if blocker == BLOCKER_INVALID_EXTERNAL_PATIENT_ID:
        return True
    if integration == BLOCKER_INVALID_EXTERNAL_PATIENT_ID:
        return True
    for item in blockers:
        if _safe_str(item).strip().lower() == BLOCKER_INVALID_EXTERNAL_PATIENT_ID:
            return True
    return False


def _primary_scope(summary, phase_scope, layer1_scope):
    phase_count = _safe_int(phase_scope.get("count"), 0)
    layer1_count = _safe_int(layer1_scope.get("count"), 0)
    if layer1_count > 0 and _has_layer1_invalid_block(summary):
        return "layer1_join_quality"
    if phase_count > 0:
        return "phase_d_patient_upsert"
    if layer1_count > 0:
        return "layer1_join_quality"
    return ""


def _scope_by_name(name, phase_scope, layer1_scope):
    if name == "layer1_join_quality":
        return layer1_scope
    if name == "phase_d_patient_upsert":
        return phase_scope
    return {}


def _normalization_preview(primary, phase_scope, layer1_scope):
    phase_missing = _count_any(
        phase_scope.get("contract_disposition_counts"),
        ("missing_or_blank", "blank/placeholder", "empty", "missing"))
    layer1_missing = _count_any(
        layer1_scope.get("contract_disposition_counts"),
        ("missing_or_blank", "blank/placeholder", "empty", "missing"))
    leading = _safe_int(primary.get("leading_zero_loss_candidate_count"), 0)
    return {
        "left_pad_to_5_candidate_count": leading,
        "secondary_match_confirmed_count": 0,
        "secondary_match_unconfirmed_count": leading,
        "blank_or_missing_count": phase_missing + layer1_missing,
    }


def _report_rows_from_scope(scope):
    out = []
    scope_name = _safe_str(scope.get("scope")).strip()
    source_counts = _dict(scope.get("source_contract_counts"))
    dispositions = _dict(scope.get("contract_disposition_counts"))
    artifacts = _dict(scope.get("artifact_class_counts"))
    fields = _dict(scope.get("field_counts"))
    disposition = "unknown"
    if dispositions:
        disposition = sorted(dispositions.items(), key=lambda kv: (-_safe_int(kv[1], 0), _safe_str(kv[0])))[0][0]
    artifact = "unknown"
    if artifacts:
        artifact = sorted(artifacts.items(), key=lambda kv: (-_safe_int(kv[1], 0), _safe_str(kv[0])))[0][0]
    field_name = "external_patient_id"
    if fields:
        field_name = sorted(fields.items(), key=lambda kv: (-_safe_int(kv[1], 0), _safe_str(kv[0])))[0][0]
    for contract, raw_count in source_counts.items():
        count = _safe_int(raw_count, 0)
        if count <= 0:
            continue
        out.append({
            "scope": scope_name,
            "source_contract": _safe_str(contract),
            "contract_disposition": _safe_str(disposition) or "unknown",
            "artifact_class": _safe_str(artifact) or "unknown",
            "field_name": _safe_str(field_name) or "external_patient_id",
            "count": count,
            "shape_family": "redacted_external_patient_id_shape",
            "source_token": "***",
            "safe_examples": [
                {
                    "redacted_value": "<redacted>",
                    "shape_family": "redacted_external_patient_id_shape",
                    "note": "raw patient identifiers are intentionally omitted",
                }
            ],
        })
    return out


def build_external_patient_id_contract_model(summary):
    """Return the shared non-PII invalid external patient ID contract model."""
    data = _dict(summary)
    phase_scope = _phase_d_scope(data)
    layer1_scope = _layer1_scope(data)
    primary_name = _primary_scope(data, phase_scope, layer1_scope)
    primary = _scope_by_name(primary_name, phase_scope, layer1_scope)
    leading_count = _safe_int(primary.get("leading_zero_loss_candidate_count"), 0)
    leading_by_source = _copy_int_dict(primary.get("leading_zero_loss_candidate_by_source_contract"))
    rows = []
    rows.extend(_report_rows_from_scope(phase_scope))
    rows.extend(_report_rows_from_scope(layer1_scope))
    rows.sort(key=lambda item: (
        0 if item.get("scope") == primary_name else 1,
        -_safe_int(item.get("count"), 0),
        _safe_str(item.get("scope")),
        _safe_str(item.get("source_contract")),
    ))
    return {
        "schema_version": EXTERNAL_PATIENT_ID_CONTRACT_SCHEMA_VERSION,
        "run_id": _safe_str(data.get("run_id")).strip(),
        "primary_scope": primary_name,
        "primary_invalid_external_patient_id_count": _safe_int(primary.get("count"), 0),
        "primary_source_contract_counts": _copy_int_dict(primary.get("source_contract_counts")),
        "primary_contract_disposition_counts": _copy_int_dict(primary.get("contract_disposition_counts")),
        "phase_d_patient_upsert": phase_scope,
        "layer1_join_quality": layer1_scope,
        "leading_zero_loss_candidate_count": leading_count,
        "leading_zero_loss_candidate_by_source_contract": leading_by_source,
        "leading_zero_loss_confirmation": (
            "requires_secondary_match" if leading_count > 0 else "not_applicable"),
        "normalization_preview": _normalization_preview(primary, phase_scope, layer1_scope),
        "contains_pii": False,
        "redaction_policy": "counts_and_shape_families_only_no_raw_patient_identifiers",
        "rows": rows,
    }


def _report_entry(path, required=True):
    text = _safe_str(path).strip()
    if not text:
        return None
    return {
        "path": text,
        "archive_name": _safe_basename(text),
        "required": bool(required),
        "contains_pii": False,
        "safe_for_bundle": True,
    }


def build_invalid_external_patient_id_unblock(summary, report_paths):
    """Build the canonical Phase D unblock contract for invalid patient IDs."""
    data = summary if isinstance(summary, dict) else {}
    contract_model = build_external_patient_id_contract_model(data)
    paths = report_paths if isinstance(report_paths, (list, tuple)) else []
    reports = []
    seen = {}
    for path in paths:
        entry = _report_entry(path, required=True)
        if not entry:
            continue
        key = entry.get("archive_name") or entry.get("path")
        if seen.get(key):
            continue
        seen[key] = True
        reports.append(entry)
    return {
        "schema_version": SCHEMA_VERSION,
        "status": "action_ready",
        "blocker_code": BLOCKER_INVALID_EXTERNAL_PATIENT_ID,
        "recommended_action_kind": ACTION_RESOLVE_EXTERNAL_PATIENT_ID_CONTRACT,
        "operator_manual_review_required": False,
        "safe_for_bundle": True,
        "contains_pii": False,
        "evidence_reports": reports,
        "external_patient_id_contract": contract_model,
        "next_predicted_stall": _safe_str(data.get("next_predicted_stall")).strip(),
        "next_predicted_stall_evidence": (
            data.get("next_predicted_stall_evidence")
            if isinstance(data.get("next_predicted_stall_evidence"), dict)
            else {}
        ),
        "developer_next_step": (
            "Use the attached redacted contract report(s) to fix the upstream "
            "patient ID contract; do not ask the XP operator to inspect local PII."
        ),
    }


def evidence_report_entries_from_summary(summary):
    """Return developer-unblock evidence report entries declared by a summary."""
    data = summary if isinstance(summary, dict) else {}
    contract = data.get("phase_d_developer_unblock")
    # Explicit contract opt-out must disable legacy fallback too; otherwise bundle
    # builders would still attach phase_d_invalid_external_id_contract_report_* paths.
    if isinstance(contract, dict) and contract.get("safe_for_bundle") is False:
        return []
    entries = []
    if isinstance(contract, dict):
        raw_entries = contract.get("evidence_reports")
        if isinstance(raw_entries, list):
            for raw in raw_entries:
                if isinstance(raw, dict):
                    path = _safe_str(raw.get("path")).strip()
                    if not path:
                        continue
                    entries.append({
                        "path": path,
                        "archive_name": _safe_str(raw.get("archive_name")).strip() or _safe_basename(path),
                        "required": bool(raw.get("required", True)),
                        "contains_pii": bool(raw.get("contains_pii", False)),
                        "safe_for_bundle": bool(raw.get("safe_for_bundle", True)),
                    })
                else:
                    entry = _report_entry(raw, required=True)
                    if entry:
                        entries.append(entry)
    if entries:
        return _dedupe_entries(entries)

    # Backward-compatible fallback for summaries produced before the contract.
    fallback = []
    for key in (
            "phase_d_invalid_external_id_contract_report_json_path",
            "phase_d_invalid_external_id_contract_report_txt_path"):
        entry = _report_entry(data.get(key), required=True)
        if entry:
            fallback.append(entry)
    return _dedupe_entries(fallback)


def evidence_report_tuples_from_summary(summary):
    """Return ``(archive_name, path)`` tuples for bundle extra_files callers."""
    out = []
    for entry in evidence_report_entries_from_summary(summary):
        if not bool(entry.get("safe_for_bundle", True)):
            continue
        if bool(entry.get("contains_pii", False)):
            continue
        out.append((entry.get("archive_name") or _safe_basename(entry.get("path")), entry.get("path")))
    return out


def _dedupe_entries(entries):
    out = []
    seen = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        path = _safe_str(entry.get("path")).strip()
        if not path:
            continue
        key = entry.get("archive_name") or path
        if seen.get(key):
            continue
        seen[key] = True
        out.append(entry)
    return out
