#!/usr/bin/env python
"""Shared Phase D DAT movement and reject classification helpers.

This module is intentionally small and Python 3.4 compatible.  It is used by
XP-facing bundle text, recommendations, and developer replay tooling so live
follow-up movement is described consistently without changing anchor verdicts.
"""
from __future__ import print_function


MOVEMENT_ZERO_SELECTION = 'zero_selection'
MOVEMENT_SELECTED_REJECTED = 'selected_rejected'
MOVEMENT_SELECTED_PASSED_NO_CANONICAL = 'selected_passed_no_canonical'
MOVEMENT_MILESTONE_CANDIDATE = 'milestone_candidate'
MOVEMENT_FOLLOWUP_ONLY_NOT_ANCHOR_CLOSURE = 'followup_only_not_anchor_closure'

SELECTOR_RESIDUE_EMPTY_DAT = 'empty_dat_residue_after_nonzero_dat_already_evaluated'

DAT_BLOCKER_EMPTY_FILE = 'empty_dat_file'
DAT_BLOCKER_PATIENT_ANCHOR = 'patient_anchor_missing'
DAT_BLOCKER_PAYER_ANCHOR = 'payer_anchor_missing'
DAT_BLOCKER_MIXED = 'mixed'
DAT_PATID_UNREACHABLE_SOURCE_SHAPE = 'DAT_PATID_UNREACHABLE_SOURCE_SHAPE'


def _safe_int(value, default=0):
    try:
        if value is None or value == '':
            return default
        return int(value)
    except Exception:
        return default


def _dict(value):
    return value if isinstance(value, dict) else {}


def _counter_dict(value):
    out = {}
    data = _dict(value)
    for key, count in data.items():
        key_s = str(key or '').strip()
        count_i = _safe_int(count, 0)
        if key_s and count_i > 0:
            out[key_s] = count_i
    return out


def _first_count(data, keys, default=0):
    for key in keys:
        if key in data:
            return _safe_int(data.get(key), default)
    return default


def extract_phase_d_dat_counts(payload, fallback=None):
    """Return stable selected/pass/reject/canonical/v2 counts from a summary-like dict."""
    data = _dict(payload)
    fb = _dict(fallback)
    tel = _dict(data.get('dat_telemetry'))
    return {
        'selected': _first_count(tel, ('dat_selected_count',), _first_count(data, (
            'selected', 'dat_selected_count', 'phase_d_dat_selected_count', 'rows_selected'), _first_count(fb, (
                'selected', 'dat_selected_count', 'phase_d_dat_selected_count', 'rows_selected'), 0))),
        'qa_pass': _first_count(tel, ('dat_qa_pass_count',), _first_count(data, (
            'qa_pass', 'dat_qa_pass_count', 'phase_d_dat_qa_pass_count', 'qa_pass_count'), _first_count(fb, (
                'qa_pass', 'dat_qa_pass_count', 'phase_d_dat_qa_pass_count', 'qa_pass_count'), 0))),
        'qa_reject': _first_count(tel, ('dat_qa_reject_count',), _first_count(data, (
            'qa_reject', 'dat_qa_reject_count', 'phase_d_dat_qa_reject_count', 'qa_reject_count'), _first_count(fb, (
                'qa_reject', 'dat_qa_reject_count', 'phase_d_dat_qa_reject_count', 'qa_reject_count'), 0))),
        'canonical': _first_count(tel, ('dat_canonical_record_count',), _first_count(data, (
            'canonical', 'dat_canonical_record_count', 'phase_d_dat_canonical_record_count'), _first_count(fb, (
                'canonical', 'dat_canonical_record_count', 'phase_d_dat_canonical_record_count'), 0))),
        'v2_inserted': _first_count(tel, ('phase_d_dat_v2_inserted_total', 'dat_v2_inserted_total'), _first_count(data, (
            'v2_inserted', 'phase_d_dat_v2_inserted_total', 'dat_v2_inserted_total'), _first_count(fb, (
                'v2_inserted', 'phase_d_dat_v2_inserted_total', 'dat_v2_inserted_total'), 0))),
    }


def classify_phase_d_movement(counts_or_payload, followup_only=False):
    """Classify Phase D DAT movement using the shared bundle/replay vocabulary."""
    if followup_only:
        return MOVEMENT_FOLLOWUP_ONLY_NOT_ANCHOR_CLOSURE
    counts = counts_or_payload if isinstance(counts_or_payload, dict) else {}
    if not any(key in counts for key in ('selected', 'qa_pass', 'qa_reject', 'canonical', 'v2_inserted')):
        counts = extract_phase_d_dat_counts(counts_or_payload)
    selected = _safe_int(counts.get('selected'), 0)
    qa_pass = _safe_int(counts.get('qa_pass'), 0)
    qa_reject = _safe_int(counts.get('qa_reject'), 0)
    canonical = _safe_int(counts.get('canonical'), 0)
    if selected <= 0 and qa_pass <= 0 and qa_reject <= 0 and canonical <= 0:
        return MOVEMENT_ZERO_SELECTION
    if selected > 0 and qa_pass > 0 and canonical > 0:
        return MOVEMENT_MILESTONE_CANDIDATE
    if selected > 0 and qa_pass > 0 and canonical <= 0:
        return MOVEMENT_SELECTED_PASSED_NO_CANONICAL
    return MOVEMENT_SELECTED_REJECTED


def classify_phase_d_selector_residue(payload):
    """Classify terminal pre-QA selector residue without treating it as DAT movement."""
    data = _dict(payload)
    tel = _dict(data.get('dat_telemetry'))
    rows_selected = _first_count(data, ('rows_selected', 'phase_d_rows_selected'), 0)
    counts = extract_phase_d_dat_counts(data)
    dat_selected = _safe_int(counts.get('selected'), 0)
    dat_pass = _safe_int(counts.get('qa_pass'), 0)
    dat_reject = _safe_int(counts.get('qa_reject'), 0)
    dat_canonical = _safe_int(counts.get('canonical'), 0)
    pre_qa_skip = _safe_int(tel.get('dat_pre_qa_skipped_count'), 0)
    terminal_count = _safe_int(tel.get('dat_pre_qa_terminal_result_count'), 0)
    empty_count = _safe_int(tel.get('dat_empty_file_skipped_count'), 0)
    if empty_count <= 0:
        empty_count = _safe_int(_dict(tel.get('dat_pre_qa_skip_counts_by_reason')).get('QA_DAT_EMPTY_FILE'), 0)
    present = bool(
        rows_selected > 0
        and dat_selected <= 0
        and dat_pass <= 0
        and dat_reject <= 0
        and dat_canonical <= 0
        and empty_count > 0
        and (pre_qa_skip >= rows_selected or terminal_count >= rows_selected or empty_count >= rows_selected)
    )
    return {
        'present': present,
        'selector_residue_class': SELECTOR_RESIDUE_EMPTY_DAT if present else '',
        'rows_selected': rows_selected,
        'dat_selected_count': dat_selected,
        'dat_qa_pass_count': dat_pass,
        'dat_qa_reject_count': dat_reject,
        'dat_canonical_record_count': dat_canonical,
        'dat_pre_qa_skipped_count': pre_qa_skip,
        'dat_pre_qa_terminal_result_count': terminal_count,
        'dat_empty_file_skipped_count': empty_count,
        'recommended_developer_action': (
            'developer_action: keep zero-byte DAT artifacts terminally classified for Phase D QA so selector residue '
            'cannot loop; continue with non-empty DAT hydration diagnostics.'
        ) if present else '',
    }


def extract_dat_reject_counts(payload):
    data = _dict(payload)
    tel = _dict(data.get('dat_telemetry'))
    counts = _counter_dict(tel.get('dat_qa_reject_counts_by_reason'))
    if counts:
        return counts
    counts = _counter_dict(data.get('dat_qa_reject_counts_by_reason'))
    if counts:
        return counts
    generic = _counter_dict(data.get('reject_counts_by_code'))
    out = {}
    for key, value in generic.items():
        if key.startswith('QA_DAT_'):
            out[key] = value
    return out


def extract_dat_reject_subcode_counts(payload):
    data = _dict(payload)
    tel = _dict(data.get('dat_telemetry'))
    for source in (tel, data):
        for key in (
                'dat_terminal_reject_counts_by_subcode',
                'dat_terminal_reject_subcode_counts',
                'dat_qa_reject_counts_by_subcode',
                'dat_qa_reject_subcode_counts',
                'terminal_dat_reject_counts_by_subcode',
                'reject_counts_by_subcode'):
            counts = _counter_dict(source.get(key))
            if counts:
                return counts
    return {}


def is_terminal_dat_patid_unreachable_source_shape(payload, reject_count=0):
    reject_counts = extract_dat_reject_counts(payload)
    subcode_counts = extract_dat_reject_subcode_counts(payload)
    expected = _safe_int(reject_count, 0)
    if expected <= 0:
        counts = extract_phase_d_dat_counts(payload)
        expected = _safe_int(counts.get('qa_reject'), 0)
    top_count = _safe_int(reject_counts.get('QA_DAT_PATIENT_ANCHOR_MISSING'), 0)
    subcode_count = _safe_int(subcode_counts.get(DAT_PATID_UNREACHABLE_SOURCE_SHAPE), 0)
    top_total = sum(_safe_int(v, 0) for _k, v in reject_counts.items())
    subcode_total = sum(_safe_int(v, 0) for _k, v in subcode_counts.items())
    return bool(
        expected > 0
        and top_count == expected
        and top_total == expected
        and subcode_count == expected
        and subcode_total == expected
    )


def extract_dat_reject_file_prefix_counts(payload):
    data = _dict(payload)
    tel = _dict(data.get('dat_telemetry'))
    counts = _counter_dict(tel.get('dat_reject_file_prefix_counts'))
    if counts:
        return counts
    return _counter_dict(data.get('dat_reject_file_prefix_counts'))


def _sorted_count_items(counts):
    items = []
    for key, value in _counter_dict(counts).items():
        items.append((key, value))
    items.sort(key=lambda item: (-item[1], item[0]))
    return items


def _blocker_for_code(code):
    if code == 'QA_DAT_EMPTY_FILE':
        return DAT_BLOCKER_EMPTY_FILE
    if code == 'QA_DAT_PATIENT_ANCHOR_MISSING':
        return DAT_BLOCKER_PATIENT_ANCHOR
    if code == 'QA_DAT_PAYER_ANCHOR_MISSING':
        return DAT_BLOCKER_PAYER_ANCHOR
    return DAT_BLOCKER_MIXED


def _developer_action_for_blocker(blocker):
    if blocker == DAT_BLOCKER_EMPTY_FILE:
        return (
            'developer_action: inspect DAT source discovery/parser handling for empty or header-only DAT artifacts; '
            'exclude or classify unreadable DAT files before QA.'
        )
    if blocker == DAT_BLOCKER_PATIENT_ANCHOR:
        return (
            'developer_action: repair DAT patient anchor mapping from redacted patient-key presence and join telemetry; '
            'do not require XP operator inspection.'
        )
    if blocker == DAT_BLOCKER_PAYER_ANCHOR:
        return (
            'developer_action: repair DAT payer anchor mapping from redacted payer alias telemetry; '
            'do not require XP operator inspection.'
        )
    return (
        'developer_action: review the DAT reject mix and address the largest parser/anchor blocker first using '
        'redacted reject samples and field-presence telemetry.'
    )


def classify_dat_reject_next_action(payload):
    """Return safe developer-facing DAT reject blocker telemetry."""
    reject_counts = extract_dat_reject_counts(payload)
    file_counts = extract_dat_reject_file_prefix_counts(payload)
    items = _sorted_count_items(reject_counts)
    dominant_code = ''
    dominant_count = 0
    blocker = ''
    if items:
        dominant_code, dominant_count = items[0]
        total = sum(value for _key, value in items)
        if len(items) > 1 and dominant_count * 2 <= total:
            blocker = DAT_BLOCKER_MIXED
        else:
            blocker = _blocker_for_code(dominant_code)
    return {
        'dominant_reject_code': dominant_code,
        'dominant_reject_count': dominant_count,
        'dat_reject_blocker_class': blocker or '',
        'dat_reject_counts_by_reason': reject_counts,
        'safe_artifact_file_prefix_counts': file_counts,
        'recommended_developer_action': _developer_action_for_blocker(blocker) if blocker else '',
    }


def format_count_map(counts, limit=8):
    items = _sorted_count_items(counts)
    if limit and len(items) > limit:
        items = items[:limit]
    if not items:
        return 'none'
    return ','.join('{0}:{1}'.format(key, value) for key, value in items)
