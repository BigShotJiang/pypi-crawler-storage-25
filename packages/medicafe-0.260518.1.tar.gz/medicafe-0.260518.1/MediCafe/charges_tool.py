"""XP-safe charge calculation helpers.

This module is intentionally pure: it does not write scheduler state, DAT
fields, 837P files, or Medisoft charge-entry markers. Callers may use the
returned evidence for preview/review surfaces, but operational charge entry
must remain a separate explicit workflow.
"""

CHARGE_SCHEMA_VERSION = "charges_tool.v1"
MIN_BILLABLE_MINUTES = 5
MAX_BILLABLE_MINUTES = 59
WORKFLOW_BOUNDARY = "preview_only_review_required"
SERVICE_LINE_INPUT_WORKFLOW_NAME = "service_line_input"


def _clean_text(value):
    return str(value or "").strip()


def _clean_status(value):
    return _clean_text(value).upper()


def _format_amount_display(amount):
    try:
        return "${0}".format(int(amount))
    except Exception:
        return ""


def _base_result(context, status, display, note, amount, rule_id, source,
                 billable=False, requires_operator_review=True):
    if context is None or not isinstance(context, dict):
        context = {}
    result = {
        "schema_version": CHARGE_SCHEMA_VERSION,
        "charge_schema_version": CHARGE_SCHEMA_VERSION,
        "charge_status": status,
        "charge_display": display,
        "charge_note": note,
        "charge_amount": amount,
        "charge_rule_id": rule_id,
        "charge_source": source,
        "billable": bool(billable),
        "requires_operator_review": bool(requires_operator_review),
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": WORKFLOW_BOUNDARY,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
        "minutes_min": MIN_BILLABLE_MINUTES,
        "minutes_max": MAX_BILLABLE_MINUTES,
    }
    cpt = _clean_text(context.get("cpt"))
    if cpt:
        result["cpt"] = cpt
    patient_id = _clean_text(context.get("patient_id"))
    if patient_id:
        result["patient_id"] = patient_id
    dos = _clean_text(context.get("dos"))
    if dos:
        result["dos"] = dos
    return result


def coerce_billable_minutes(value):
    """Return ``(minutes, valid)`` for the supported billable minute domain."""
    text = _clean_text(value)
    try:
        minutes = int(text)
    except Exception:
        return (0, False)
    if minutes < MIN_BILLABLE_MINUTES or minutes > MAX_BILLABLE_MINUTES:
        return (minutes, False)
    return (minutes, True)


def calculate_baseline_charge(minutes):
    """Return baseline tier evidence for a valid integer minute value."""
    minutes_value, valid = coerce_billable_minutes(minutes)
    if not valid:
        return None
    if minutes_value <= 15:
        return {
            "minutes": minutes_value,
            "charge_amount": "450.00",
            "charge_display": "$450",
            "charge_note": "",
            "charge_rule_id": "baseline_5_15",
            "charge_source": "baseline_minutes_tier",
        }
    if minutes_value <= 35:
        return {
            "minutes": minutes_value,
            "charge_amount": "540.00",
            "charge_display": "$540",
            "charge_note": "",
            "charge_rule_id": "baseline_16_35",
            "charge_source": "baseline_minutes_tier",
        }
    return {
        "minutes": minutes_value,
        "charge_amount": "580.00",
        "charge_display": "$580",
        "charge_note": "",
        "charge_rule_id": "baseline_36_59",
        "charge_source": "baseline_minutes_tier",
    }


def calculate_charge_result(context):
    """Calculate a review-only charge result from a small context dictionary.

    Expected context keys are intentionally plain strings so XP callers and UI
    adapters can pass existing row dictionaries without new object types.
    """
    if context is None or not isinstance(context, dict):
        context = {}
    status = _clean_status(context.get("status"))
    if status == "PENDING" or (not status and not _clean_text(context.get("minutes"))):
        return _base_result(
            context,
            "pending",
            "PENDING",
            "",
            "",
            "pending_minutes",
            "operator_preview_status",
            billable=False,
            requires_operator_review=False,
        )
    if status == "SKIPPED":
        return _base_result(
            context,
            "skipped",
            "SKIPPED",
            "",
            "",
            "operator_skipped",
            "operator_preview_status",
            billable=False,
            requires_operator_review=True,
        )
    if status == "CANCELLED":
        return _base_result(
            context,
            "cancelled",
            "CANCELLED",
            "",
            "",
            "operator_cancelled",
            "operator_preview_status",
            billable=False,
            requires_operator_review=True,
        )

    tier = calculate_baseline_charge(context.get("minutes"))
    if tier is None:
        minutes_value, _valid = coerce_billable_minutes(context.get("minutes"))
        result = _base_result(
            context,
            "invalid",
            "INVALID",
            "minutes 5-59 only",
            "",
            "invalid_minutes",
            "minutes_domain_guard",
            billable=False,
            requires_operator_review=True,
        )
        result["minutes_normalized"] = minutes_value
        result["minutes_valid"] = False
        if minutes_value == 0:
            result["charge_note"] = "0 is cancel upstream"
            result["charge_rule_id"] = "zero_cancelled_upstream"
        return result

    anchor_amount = _clean_text(context.get("same_patient_anchor_charge_amount"))
    anchor_display = _clean_text(context.get("same_patient_anchor_charge_display"))
    if anchor_amount or anchor_display:
        result = _base_result(
            context,
            "calculated",
            anchor_display or _format_amount_display(anchor_amount),
            _clean_text(context.get("same_patient_anchor_charge_note")) or "same-patient DOS anchor",
            anchor_amount,
            _clean_text(context.get("same_patient_anchor_charge_rule_id")) or "same_patient_dos_anchor",
            "same_patient_dos_anchor",
            billable=True,
            requires_operator_review=True,
        )
        result["minutes_normalized"] = tier.get("minutes")
        result["minutes_valid"] = True
        result["baseline_charge_amount"] = tier.get("charge_amount") or ""
        result["baseline_charge_display"] = tier.get("charge_display") or ""
        return result

    result = _base_result(
        context,
        "calculated",
        tier.get("charge_display") or _format_amount_display(tier.get("charge_amount")),
        tier.get("charge_note") or "",
        tier.get("charge_amount") or "",
        tier.get("charge_rule_id") or "",
        tier.get("charge_source") or "baseline_minutes_tier",
        billable=True,
        requires_operator_review=True,
    )
    result["minutes_normalized"] = tier.get("minutes")
    result["minutes_valid"] = True
    return result


def calculate_service_line_amount_result(context):
    """Compatibility-stable API for Service Line Input amount evidence."""
    return calculate_charge_result(context)


def calculate_option_a_charge_result(context):
    """Legacy API for the former Option A minutes menu.

    SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: keep this alias through the
    first release cycle that writes `.service_line_input_state.json`.
    """
    return calculate_service_line_amount_result(context)
