# Phase 0b: receive agent harness from culture — design

| Field        | Value                                                                                              |
|--------------|----------------------------------------------------------------------------------------------------|
| Status       | Draft (brainstorming output)                                                                       |
| Date         | 2026-05-09                                                                                         |
| Tracks       | [agentculture/cultureagent#3](https://github.com/agentculture/cultureagent/issues/3)               |
| Defers       | [agentculture/cultureagent#4](https://github.com/agentculture/cultureagent/issues/4) (telemetry schema extraction) |
| Source spec  | [culture@main:docs/superpowers/specs/2026-05-09-cultureagent-extraction-design.md](https://github.com/agentculture/culture/blob/main/docs/superpowers/specs/2026-05-09-cultureagent-extraction-design.md) |

## 1. Problem

Culture's agent harness today lives inside `agentculture/culture` in two layers:

- `culture/clients/shared/` — 9 modules with no backend-specific behavior
  (`attention`, `ipc`, `irc_transport`, `message_buffer`, `rooms`,
  `socket_server`, `telemetry`, `webhook`, `webhook_types`).
- `culture/clients/{claude,codex,copilot,acp}/` — per-backend working copies of
  `agent_runner.py`, `supervisor.py`, `daemon.py`, `config.py`, `constants.py`,
  `culture.yaml`, `__main__.py`, and `skill/`.

Plus a citation reference at `culture/packages/agent-harness/`.

Phase 0b moves all of the above into `agentculture/cultureagent` so it can be
released as a standalone PyPI package (`cultureagent`) that culture consumes
during its Phase 1 cutover. Post-cutover, two install modes coexist:

- `uv tool install culture` — integrated experience, pulls cultureagent
  transitively.
- `uv tool install cultureagent` — agent runtime only, no operator CLI / IRCd.

## 2. Migration invariant

**Never lose functionality across the cutover.** cultureagent must publish a
release containing all four backends + shared tier + reference impl with all
harness unit tests green BEFORE culture's Phase 1 cutover PR ships. Culture
flips on a single all-backends-included release; intermediate cultureagent
releases are not consumed.

This is a behavior-preserving move. No improvements, refactors, or surface
changes ride along. Improvements land as separate cultureagent PRs before or
after the migration window.

## 3. Decisions locked during brainstorming

| Decision                          | Choice                                                                          |
|-----------------------------------|---------------------------------------------------------------------------------|
| Internal phasing                  | Incremental: 0.2.0 ships shared tier, 0.3.0 ships backends + reference          |
| Vendoring of `culture.*` utilities | Mirror culture's layout under `cultureagent/` (private, not on stable surface)  |
| Coverage gate timing              | Land in 0.2.0 (scoped to `cultureagent/clients/shared/`); expand in 0.3.0       |
| `cultureagent.api` façade         | Out of scope (deferred per issue #3)                                            |
| Telemetry schema extraction       | Out of scope, tracked at #4                                                     |
| Migration-script tool             | `libcst` for AST-faithful Python rewrites + bounded regex for string-literal classes |

## 4. Repository layout (post-0.3.0)

```text
cultureagent/
├── cli/                                  (existing AFI frame — untouched)
├── explain/                              (existing — untouched)
├── clients/                              (NEW — receives harness)
│   ├── __init__.py
│   ├── shared/                           (lands in 0.2.0)
│   │   ├── __init__.py
│   │   ├── attention.py
│   │   ├── ipc.py
│   │   ├── irc_transport.py
│   │   ├── message_buffer.py
│   │   ├── rooms.py
│   │   ├── socket_server.py
│   │   ├── telemetry.py
│   │   ├── webhook.py
│   │   └── webhook_types.py
│   ├── claude/                           (lands 0.3.0; same shape ×4)
│   │   ├── __init__.py
│   │   ├── __main__.py                   (subprocess entry: -m cultureagent.clients.claude)
│   │   ├── agent_runner.py
│   │   ├── supervisor.py
│   │   ├── daemon.py
│   │   ├── config.py
│   │   ├── constants.py
│   │   ├── culture.yaml
│   │   └── skill/
│   │       ├── __init__.py
│   │       └── irc_client.py             (subprocess entry: -m …skill.irc_client)
│   ├── codex/                            (same shape; needs new __main__.py)
│   ├── copilot/                          (same shape; needs new __main__.py)
│   └── acp/                              (same shape; needs new __main__.py)
├── aio.py                                (NEW; vendored from culture, private)
├── pidfile.py                            (NEW; vendored, private)
├── _constants.py                         (NEW; vendored, private)
├── constants.py                          (NEW; vendored, private)
├── cli/shared/constants.py               (NEW under existing cli/; vendored, private)
├── telemetry/
│   ├── __init__.py
│   └── context.py                        (NEW; vendored, private)
└── protocol/
    ├── __init__.py
    └── message.py                        (NEW; vendored, private)
packages/agent-harness/                   (NEW top-level dir; lands 0.3.0; verbatim copy)
docs/
├── architecture.md                       (existing — updated, not replaced)
├── api-stability.md                      (NEW; lands 0.2.0, expanded 0.3.0)
├── attention.md                          (MOVED from culture/docs/attention.md; 137 lines)
├── concepts/
│   └── harnesses.md                      (MOVED from culture/docs/shared/concepts/harnesses.md)
├── reference/architecture/
│   ├── agent-harness-spec.md             (MOVED from culture; canonical 498-line spec; lands 0.3.0)
│   └── shared-vs-cited.md                (MOVED from culture/docs/architecture/)
├── observability/
│   └── harness-telemetry.md              (MOVED from culture/docs/agentirc/harness-telemetry.md)
└── migration/
    └── 2026-05-09-phase-0b-receive.md    (NEW; receipt log)
tests/
├── test_cli.py                           (existing AFI — untouched)
├── test_self_doctor.py                   (existing AFI — untouched)
├── harness/                              (NEW subtree)
│   ├── conftest.py
│   ├── test_attention.py                                      (0.2.0)
│   ├── test_attention_config.py                               (0.2.0)
│   ├── test_irc_transport_propagation.py                      (0.2.0)
│   ├── test_telemetry_module.py                               (0.2.0)
│   ├── test_webhook_config_shared.py                          (0.2.0)
│   ├── test_record_llm_call.py                                (0.2.0)
│   ├── test_no_per_backend_copy_of_shared_modules.py          (0.3.0 — needs backend dirs)
│   ├── test_agent_runner_{claude,codex,copilot,acp}.py        (0.3.0 ×4)
│   ├── test_all_backends_parity.py                            (0.3.0)
│   └── test_daemon_telemetry.py                               (0.3.0)
├── test_irc_transport.py                                      (0.2.0)
├── test_irc_transport_tags.py                                 (0.2.0)
├── test_message_buffer.py                                     (0.2.0)
├── test_skill_client.py                                       (split — see §7)
├── test_socket_server.py                                      (0.2.0)
├── test_supervisor.py                                         (0.3.0)
├── test_webhook.py                                            (0.2.0)
├── test_acp_daemon.py                                         (0.3.0)
├── test_codex_daemon.py                                       (0.3.0)
├── test_copilot_daemon.py                                     (0.3.0)
├── test_daemon.py                                             (0.3.0)
├── test_daemon_config.py                                      (0.3.0)
├── test_daemon_ipc.py                                         (0.3.0)
└── test_agent_runner.py                                       (0.3.0)
```

The 8 `test_integration_*.py` files in culture **stay in culture** as
end-to-end safety nets for culture's consumption of cultureagent.

## 5. Stable import surface — `docs/api-stability.md`

The contract culture commits to. Behavior-stable through the entire 0.x line;
breaking changes only at major bumps. Deprecation policy: one minor cycle
warning before removal at next major.

### 5.1 Shared tier (added in 0.2.0)

| Import path                                                  | Stable since |
|--------------------------------------------------------------|--------------|
| `cultureagent.clients.shared.attention.AttentionTracker`     | 0.2.0        |
| `cultureagent.clients.shared.attention.Band`                 | 0.2.0        |
| `cultureagent.clients.shared.message_buffer.MessageBuffer`   | 0.2.0        |
| `cultureagent.clients.shared.ipc.decode_message`             | 0.2.0        |
| `cultureagent.clients.shared.ipc.encode_message`             | 0.2.0        |
| `cultureagent.clients.shared.ipc.make_request`               | 0.2.0        |
| `cultureagent.clients.shared.ipc.make_response`              | 0.2.0        |
| `cultureagent.clients.shared.irc_transport.IRCTransport`     | 0.2.0        |
| `cultureagent.clients.shared.socket_server.SocketServer`     | 0.2.0        |
| `cultureagent.clients.shared.telemetry.init_harness_telemetry` | 0.2.0      |
| `cultureagent.clients.shared.webhook.AlertEvent`             | 0.2.0        |
| `cultureagent.clients.shared.webhook.WebhookClient`          | 0.2.0        |
| `cultureagent.clients.shared.webhook_types.WebhookConfig`    | 0.2.0        |
| `cultureagent.clients.shared.rooms.parse_room_meta`          | 0.2.0        |

The brief's `…` ellipses (e.g., `attention.{AttentionTracker, Band, …}`) are
resolved at release time by reading each module's `__all__` and freezing the
list in this table. Modules without `__all__` get one added during the
migration — a non-behavior change, declared in the receipt log.

### 5.2 Per-backend (added in 0.3.0)

For each backend in `{claude, codex, copilot, acp}`:

| Import path                                                  | Stable since |
|--------------------------------------------------------------|--------------|
| `cultureagent.clients.<backend>.config.AgentConfig`          | 0.3.0        |
| `cultureagent.clients.<backend>.config.DaemonConfig`         | 0.3.0        |
| `cultureagent.clients.<backend>.constants.*` (whole module)  | 0.3.0        |

### 5.3 Subprocess entry points (added in 0.3.0)

For each backend:

- `python -m cultureagent.clients.<backend>` — daemon entry. argv contract,
  exit codes, signal handling are stable.
- `python -m cultureagent.clients.<backend>.skill.irc_client` — whisper IPC
  client. argv contract and stdout/stderr split are stable.

### 5.4 Explicitly NOT public

- `cultureagent.clients.<backend>.{agent_runner,supervisor,daemon}.*`
  (internals; access only through the subprocess entry points)
- `cultureagent.{aio,pidfile,_constants,constants,protocol,telemetry}.*`
  (vendored utility modules; private — may move to an external package)
- `cultureagent.cli.shared.constants.*` (private; supports the AFI CLI frame)
- `packages/agent-harness/*` (citation reference — copy and own it)
- Any test scaffolds (`_FakeProcess`, conftest fixtures)
- `cultureagent.protocol.message.Message` — flagged: arguably belongs in
  agentirc; tracked separately as part of the agentirc-10.0 cleanup

## 6. Migration mechanics

### 6.1 Five rewrite rules

1. **Python `from`/`import` statements with allow-listed prefixes.**
   - `from culture.clients.{shared,claude,codex,copilot,acp}…`
     → `from cultureagent.clients.{shared,…}…`
   - `from culture.{aio,pidfile,_constants,constants,protocol,telemetry,cli.shared.constants}…`
     → `from cultureagent.{aio,pidfile,_constants,constants,protocol,telemetry,cli.shared.constants}…`
   - Any other `from culture.…` / `import culture.…` line is unexpected and
     fails the migration script loudly. Receipt log captures the case.

2. **String literals matching `mock.patch(...)` and module-equality targets**
   beginning with `"culture.clients."` → rewrite to `"cultureagent.clients."`.
   Bounded regex is safe because no telemetry namespace begins with
   `culture.clients.`.

3. **Telemetry semantic strings** matching `culture.harness*`,
   `culture.trace.*`, `culture.attention.*` are **untouched**. Verified by
   per-file grep parity check post-rewrite.

4. **Filename strings** like `culture.yaml` are **untouched** — they are
   paths-on-disk, not module paths.

5. **Filesystem path strings** like `_REPO_ROOT / "culture" / "clients"` →
   `_REPO_ROOT / "cultureagent" / "clients"`. Surfaces in two test files:
   - `tests/harness/test_no_per_backend_copy_of_shared_modules.py:22`
   - `tests/harness/test_all_backends_parity.py:29`
   Handled by the migration script via a targeted regex pass.

### 6.2 Migration script

Lives at `.claude/skills/cicd/scripts/migrate-from-culture.sh` (or as a
one-shot runbook, not part of the published package). Steps:

1. Copy directories and files from `../culture` to their target paths in
   `cultureagent/`, `packages/agent-harness/`, `tests/`.
2. Run the libcst-based Python rewriter on every `*.py` file, applying
   rule 1.
3. Run the regex passes for rules 2 and 5.
4. Run the verification checks (rule 3 grep parity; rule 4 untouched).
5. Emit a machine-readable receipt (`migration-receipt.json`) with: source
   SHA, per-file diff stats, telemetry string counts, list of any
   non-mechanical edits. The implementer derives the human-readable
   `docs/migration/2026-05-09-phase-0b-receive.md` (per §6.3) from this JSON.
6. Fail the script if any verification fails.

`libcst` runs at migration time only — never a runtime dependency.

### 6.3 Behavior-preservation receipt

Committed alongside each migration PR as
`docs/migration/2026-05-09-phase-0b-receive.md` — a Markdown summary derived
from the script's JSON output (§6.2 step 5). For each migrated file:

- **Source SHA** of culture's main at copy time
- **Diff stats** — empty if mechanical, populated with a one-line reason if not
- **Telemetry-string parity** — `grep -c '"culture\.\(harness\|trace\|attention\)' src` equals same on dst

## 7. `tests/test_skill_client.py` split

The file exercises both `cultureagent.clients.shared.ipc` (lands 0.2.0) and
per-backend `skill/irc_client.py` (lands 0.3.0). Splitting:

- 0.2.0 ships the shared/ipc-only sections of the file (potentially as a
  trimmed `tests/test_skill_client.py` or renamed `tests/test_ipc_client.py`).
- 0.3.0 ships the backend-specific sections, exercising one
  `cultureagent.clients.<backend>.skill.irc_client` per test.

The split is mechanical (the file is structured by class).

## 8. `pyproject.toml` changes

### 8.1 Runtime dependencies

**0.2.0** — `[project] dependencies`:

```toml
dependencies = [
    "pyyaml>=6.0",
    "opentelemetry-api>=1.25",
    "opentelemetry-sdk>=1.25",
    "opentelemetry-exporter-otlp-proto-grpc>=1.25",
    "opentelemetry-semantic-conventions>=0.46b0",
    "opentelemetry-instrumentation-aiohttp-server>=0.46b0",
]
```

Floors mirror culture's pinned set to avoid version-skew incidents at cutover.

**0.3.0** — `[project.optional-dependencies]`:

```toml
[project.optional-dependencies]
backend-claude = ["claude-agent-sdk>=0.1", "anthropic>=0.40"]
backend-codex = []
backend-copilot = ["github-copilot-sdk"]
backend-acp = []

all-backends = [
    "cultureagent[backend-claude]",
    "cultureagent[backend-copilot]",
]
```

Why optional: the brief's "lighter install" promise (`uv tool install
cultureagent` for agent runtime only) requires backends to be opt-in.
Culture-the-package will declare `cultureagent[all-backends]` so the
integrated install behaves identically to today.

**Dev dependencies (0.2.0)** — add `pytest-asyncio>=0.25`.

### 8.2 Wheel inclusion

```toml
[tool.hatch.build.targets.wheel.force-include]
"cultureagent/clients/claude/culture.yaml"  = "cultureagent/clients/claude/culture.yaml"
"cultureagent/clients/codex/culture.yaml"   = "cultureagent/clients/codex/culture.yaml"
"cultureagent/clients/copilot/culture.yaml" = "cultureagent/clients/copilot/culture.yaml"
"cultureagent/clients/acp/culture.yaml"     = "cultureagent/clients/acp/culture.yaml"
```

`packages/agent-harness/` is **not** in the wheel — it is a citation
reference for human/agent readers.

## 9. CI changes

### 9.1 `tests.yml` — `test` job

**0.2.0** — append a second coverage report scoped to shared tier:

```yaml
- run: uv run pytest -n auto --cov=cultureagent --cov-report=xml:coverage.xml --cov-report=term -v
- name: Harness coverage gate (>=80% shared tier)
  run: uv run coverage report --include='cultureagent/clients/shared/*' --fail-under=80
```

**0.3.0** — expand the gate to all harness paths:

```yaml
- name: Harness coverage gate (>=80% shared + backends)
  run: uv run coverage report --include='cultureagent/clients/*,packages/agent-harness/*' --fail-under=80
```

Existing global `[tool.coverage.report] fail_under = 60` stays — covers the
AFI CLI frame.

### 9.2 `tests.yml` — new `no-cycle` lint step (lands 0.2.0)

In the existing `lint` job, append:

```yaml
- name: No culture import cycle
  run: |
    if grep -rn 'from culture\b\|import culture\b' cultureagent/ tests/ ; then
      echo "::error::cultureagent must not import from culture (cycle risk)"
      exit 1
    fi
```

### 9.3 `publish.yml` — trigger paths (modified in 0.3.0)

Add `packages/**` to the path filter alongside `cultureagent/**`.

### 9.4 `version-check` (no changes)

Already enforces every-PR bump.

## 10. Release cadence

| PR                                                            | Version after | Notes                                                      |
|---------------------------------------------------------------|---------------|------------------------------------------------------------|
| 0.2.0 — shared tier + utilities + docs + coverage gate        | `0.2.0`       | Tag triggers PyPI publish. Culture cannot consume yet.     |
| 0.3.0 — backends + agent-harness reference + remaining tests  | `0.3.0`       | Tag triggers PyPI publish. Reply on issue #3.              |

If a third intermediate landing is needed, the next bump is `0.2.1` — only
call it `0.3.0` once all four backends + reference are present.

Pre-release dev builds (`*.dev<run_number>` to TestPyPI) happen automatically
per PR via `publish.yml`.

## 11. Verification gate before tagging 0.3.0

CI must pass:

```text
uv run pytest -n auto -v
uv run coverage report --include='cultureagent/clients/*,packages/agent-harness/*' --fail-under=80
uv run black --check cultureagent tests
uv run isort --check-only cultureagent tests
uv run flake8 cultureagent tests
uv run bandit -c pyproject.toml -r cultureagent
markdownlint-cli2 "**/*.md" "#node_modules" "#.local"
afi cli doctor .
```

Plus a manual smoke step in the PR body:

```text
uv run python -m cultureagent.clients.claude --help
uv run python -m cultureagent.clients.codex --help
uv run python -m cultureagent.clients.copilot --help
uv run python -m cultureagent.clients.acp --help
uv run python -m cultureagent.clients.claude.skill.irc_client --help
```

All five must print non-error help. The smoke output may be pasted into the
PR body or into the receipt log.

## 12. Release protocol on issue #3

After 0.3.0 PR merges and `publish.yml` tags `0.3.0` on PyPI:

1. Verify with `uv tool install cultureagent==0.3.0` in a clean shell.
2. Comment on issue #3:

   > Ready, `cultureagent==0.3.0`. All four backends + shared tier + reference
   > impl tagged. Stable surface declared at `docs/api-stability.md`.
   > Coverage gate >=80% green.
   >
   > - cultureagent (Claude)

3. Issue #3 is closed by culture from their side once their Phase 1 cutover
   PR merges.

## 13. Risks and mitigations

| ID | Risk                                                                                         | Mitigation                                                                                                                                                |
|----|----------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
| R1 | Telemetry namespace strings silently rewritten, breaking dashboards/alerts mesh-wide         | libcst-based AST rewrite (never touches string literals); per-file grep parity check post-rewrite; counts captured in receipt log                          |
| R2 | cultureagent transitively depends on culture (cycle)                                         | New `no-cycle` lint step in CI greps for `from culture` / `import culture` in `cultureagent/` and `tests/`; fails the PR                                 |
| R3 | `cultureagent.protocol.message.Message` arguably belongs in agentirc, not cultureagent        | Vendor private under `cultureagent/protocol/` for now; explicit "may move" note in `docs/api-stability.md`; tracked alongside agentirc-10.0 cleanup       |
| R4 | Coverage gate misconfigured, regresses silently                                              | Two gates: global 60% via `tool.coverage.report.fail_under`; per-path 80% via `coverage report --include`; intentional-fail test in 0.3.0 PR receipt log  |
| R5 | Subprocess entry-point contract drift (codex/copilot/acp `__main__.py` written from scratch) | `--help` smoke step in 0.3.0 verification gate; `subprocess.run` parity assertions added to `test_all_backends_parity.py`                                  |
| R6 | A backend's `culture.yaml` migrated to the wrong dir or content                              | SHA-pinned source paths in receipt log enable byte-equality verification                                                                                  |
| R7 | culture's stale doc copies drift from cultureagent's after the move                          | Request culture replace docs with redirect stubs as part of Phase 1 cutover PR (culture's responsibility, surfaced in issue #3 ready-comment)             |
| R8 | culture's Phase 0a integration tests break against `cultureagent==0.3.0`                     | Round-trip protocol per issue #3: culture files a brief here; resolution = fix / pushback / instruct; never yank — patch via 0.3.1                         |

## 14. Out of scope

- `cultureagent.api` façade (deferred per issue #3)
- Phase 1 cutover PR mechanics on culture's side
- Improvements to harness internals (behavior-preserving move only)
- agentirc-10.0 cleanup (separate concern; see #4)
- Telemetry-schema extraction to a sibling package — gradual split, after
  Phase 0b ships ([#4](https://github.com/agentculture/cultureagent/issues/4))
- Trove classifier / README marketing updates
- Cross-backend refactoring opportunities
- Culture-side shim mechanics

## 15. Reverse-out path

If 0.3.0 is tagged but culture's Phase 1 cutover surfaces a contract-breaking
issue:

1. Round-trip protocol per issue #3 — culture files a brief here.
2. Resolution shape: **fix** (we tag `0.3.1`, culture bumps pin) /
   **pushback** (contract was X, culture adapts) / **instruct** (use Y
   instead).
3. We never yank `0.3.0` from PyPI. Patches only.
