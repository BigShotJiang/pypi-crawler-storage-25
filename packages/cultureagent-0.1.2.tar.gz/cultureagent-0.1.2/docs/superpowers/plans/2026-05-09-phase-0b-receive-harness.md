# Phase 0b: Receive Agent Harness — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Migrate culture's agent harness (shared tier + 4 backends + reference impl + 28 tests + 5 docs) into cultureagent across two sequential releases (0.2.0 shared tier, 0.3.0 backends), preserving behavior and the wire-level mesh telemetry namespaces.

**Architecture:** Behavior-preserving copy with mechanical import rewriting via libcst (Python AST) plus bounded regex (string literals, filesystem paths). Mesh telemetry namespaces (`culture.harness.*` / `culture.trace.*` / `culture.attention.*`) are *not* rewritten. Vendored utility modules from culture mirror culture's layout under `cultureagent/` and remain private. Stable surface declared at `docs/api-stability.md`. Each migration PR ships a JSON receipt + Markdown summary that proves byte-equality / SHA traceability per file.

**Tech Stack:** Python 3.12, uv, hatchling, pytest + pytest-asyncio + pytest-xdist + pytest-cov, libcst, OpenTelemetry SDK, GitHub Actions, Trusted-Publishing to PyPI.

**Source spec:** `docs/superpowers/specs/2026-05-09-phase-0b-receive-harness-design.md`. Read the spec end-to-end before starting Phase 0.

**Sibling assumption:** `../culture` is a sibling checkout containing the source files. Verify with `ls ../culture/culture/clients/shared/attention.py` before Phase A starts.

---

## Phase 0: Migration tooling

Phase 0 lands inside the 0.2.0 PR (the same branch). It builds the migration script that Phases A and B reuse. The script lives at `.claude/skills/cicd/scripts/migrate-from-culture.sh` plus a Python helper at `.claude/skills/cicd/scripts/_migrate_rewriter.py`. Neither is shipped in the wheel.

### Task 0.1: Add libcst as a dev dependency

**Files:**

- Modify: `pyproject.toml` (`[dependency-groups] dev`)

- [ ] **Step 1: Add libcst to dev deps**

Edit `pyproject.toml`, in `[dependency-groups] dev`, add `"libcst>=1.5"` to the list (after `pytest-cov>=4.1`).

- [ ] **Step 2: Sync**

Run: `uv sync`
Expected: libcst installed, no errors.

- [ ] **Step 3: Verify import**

Run: `uv run python -c "import libcst; print(libcst.__version__)"`
Expected: prints a version >=1.5.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "deps(dev): add libcst for migration tooling"
```

### Task 0.2: Build the import rewriter (TDD)

**Files:**

- Create: `.claude/skills/cicd/scripts/_migrate_rewriter.py`
- Test: `.claude/skills/cicd/scripts/_test_migrate_rewriter.py`

- [ ] **Step 1: Write the failing test for ImportFrom rewrites**

Create `.claude/skills/cicd/scripts/_test_migrate_rewriter.py`:

```python
"""Tests for the libcst-based import rewriter used by the
culture -> cultureagent migration."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent))
from _migrate_rewriter import rewrite_module  # noqa: E402


ALLOWLIST = (
    "culture.clients.shared",
    "culture.clients.claude",
    "culture.clients.codex",
    "culture.clients.copilot",
    "culture.clients.acp",
    "culture.aio",
    "culture.pidfile",
    "culture._constants",
    "culture.constants",
    "culture.protocol",
    "culture.telemetry",
    "culture.cli.shared.constants",
)


def test_rewrites_from_culture_clients_shared():
    src = "from culture.clients.shared.attention import AttentionTracker\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "from cultureagent.clients.shared.attention import AttentionTracker\n"
    assert edits == 1


def test_rewrites_from_culture_aio():
    src = "from culture.aio import maybe_await\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "from cultureagent.aio import maybe_await\n"
    assert edits == 1


def test_does_not_rewrite_unknown_culture_path():
    src = "from culture.agentirc.events import EventType\n"
    with pytest.raises(ValueError, match="unexpected culture import"):
        rewrite_module(src, ALLOWLIST)


def test_leaves_telemetry_string_literals_untouched():
    src = (
        'TRACER = "culture.harness"\n'
        'attrs = {"culture.trace.origin": "remote"}\n'
    )
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == src
    assert edits == 0


def test_leaves_non_culture_imports_untouched():
    src = "from opentelemetry.sdk import trace\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == src
    assert edits == 0


def test_rewrites_dotted_import_form():
    src = "import culture.clients.shared.telemetry as t\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "import cultureagent.clients.shared.telemetry as t\n"
    assert edits == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest .claude/skills/cicd/scripts/_test_migrate_rewriter.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named '_migrate_rewriter'`.

- [ ] **Step 3: Write the rewriter implementation**

Create `.claude/skills/cicd/scripts/_migrate_rewriter.py`:

```python
"""libcst-based Python import rewriter for the
culture -> cultureagent migration.

Rewrites `from culture.<X> import …` and `import culture.<X>` statements
when `culture.<X>` is on the allow-list. Any other `culture.*` import
raises ValueError so the migration script can stop and surface it.

String literals — including telemetry namespace strings like
"culture.harness" — are NEVER touched. Use a separate regex pass for
the bounded string-rewrite classes.
"""

from __future__ import annotations

from typing import Sequence

import libcst as cst


def _starts_with_allowlisted(dotted: str, allowlist: Sequence[str]) -> bool:
    return any(dotted == p or dotted.startswith(p + ".") for p in allowlist)


class _Rewriter(cst.CSTTransformer):
    def __init__(self, allowlist: Sequence[str]):
        self.allowlist = allowlist
        self.edits = 0

    def _rewrite_dotted(self, dotted: str) -> str:
        if not dotted.startswith("culture."):
            return dotted
        if not _starts_with_allowlisted(dotted, self.allowlist):
            raise ValueError(f"unexpected culture import: {dotted}")
        self.edits += 1
        return "cultureagent." + dotted[len("culture."):]

    def leave_ImportFrom(self, original_node, updated_node):
        if updated_node.module is None:
            return updated_node
        dotted = _attr_to_dotted(updated_node.module)
        new_dotted = self._rewrite_dotted(dotted)
        if new_dotted == dotted:
            return updated_node
        return updated_node.with_changes(module=_dotted_to_attr(new_dotted))

    def leave_Import(self, original_node, updated_node):
        new_names = []
        changed = False
        for alias in updated_node.names:
            dotted = _attr_to_dotted(alias.name)
            new_dotted = self._rewrite_dotted(dotted)
            if new_dotted == dotted:
                new_names.append(alias)
            else:
                new_names.append(alias.with_changes(name=_dotted_to_attr(new_dotted)))
                changed = True
        if not changed:
            return updated_node
        return updated_node.with_changes(names=new_names)


def _attr_to_dotted(node) -> str:
    if isinstance(node, cst.Name):
        return node.value
    if isinstance(node, cst.Attribute):
        return _attr_to_dotted(node.value) + "." + node.attr.value
    raise TypeError(f"unsupported node: {type(node)}")


def _dotted_to_attr(dotted: str):
    parts = dotted.split(".")
    node = cst.Name(parts[0])
    for part in parts[1:]:
        node = cst.Attribute(value=node, attr=cst.Name(part))
    return node


def rewrite_module(source: str, allowlist: Sequence[str]) -> tuple[str, int]:
    """Rewrite imports in source. Returns (new_source, edit_count).

    Raises ValueError if an unallowed `culture.*` import is encountered.
    """
    tree = cst.parse_module(source)
    rewriter = _Rewriter(allowlist)
    new_tree = tree.visit(rewriter)
    return new_tree.code, rewriter.edits
```

- [ ] **Step 4: Run tests to verify all pass**

Run: `uv run pytest .claude/skills/cicd/scripts/_test_migrate_rewriter.py -v`
Expected: 6 passed.

- [ ] **Step 5: Commit**

```bash
git add .claude/skills/cicd/scripts/_migrate_rewriter.py \
        .claude/skills/cicd/scripts/_test_migrate_rewriter.py
git commit -m "feat(migrate): libcst-based import rewriter (TDD)"
```

### Task 0.3: Add the bounded-regex string-rewrite pass (TDD)

**Files:**

- Modify: `.claude/skills/cicd/scripts/_migrate_rewriter.py`
- Modify: `.claude/skills/cicd/scripts/_test_migrate_rewriter.py`

- [ ] **Step 1: Add failing tests for string-rewrite cases**

Append to `_test_migrate_rewriter.py`:

```python
from _migrate_rewriter import rewrite_strings  # noqa: E402


def test_rewrites_mock_patch_target():
    src = '"culture.clients.codex.agent_runner.asyncio.timeout"\n'
    out, edits = rewrite_strings(src)
    assert out == '"cultureagent.clients.codex.agent_runner.asyncio.timeout"\n'
    assert edits == 1


def test_rewrites_module_equality_string():
    src = 'expected_module = "culture.clients.shared.telemetry"\n'
    out, edits = rewrite_strings(src)
    assert out == 'expected_module = "cultureagent.clients.shared.telemetry"\n'
    assert edits == 1


def test_leaves_telemetry_namespace_strings_untouched():
    cases = [
        '"culture.harness"',
        '"culture.harness.claude"',
        '"culture.trace.origin"',
        '"culture.attention.transitions"',
        '"culture.harness.llm.tokens.input"',
    ]
    for src in cases:
        out, edits = rewrite_strings(src)
        assert out == src, f"telemetry namespace was rewritten: {src} -> {out}"
        assert edits == 0


def test_rewrites_filesystem_path_string():
    src = '_REPO_ROOT / "culture" / "clients"\n'
    out, edits = rewrite_strings(src)
    assert out == '_REPO_ROOT / "cultureagent" / "clients"\n'
    assert edits == 1


def test_does_not_rewrite_culture_yaml_filename():
    src = 'yaml_path = backend_dir / "culture.yaml"\n'
    out, edits = rewrite_strings(src)
    assert out == src
    assert edits == 0
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest .claude/skills/cicd/scripts/_test_migrate_rewriter.py -v`
Expected: 5 new tests FAIL with `ImportError: cannot import name 'rewrite_strings'`.

- [ ] **Step 3: Implement rewrite_strings**

Append to `_migrate_rewriter.py`:

```python
import re

_MOCK_PATCH_RE = re.compile(r'"(culture\.clients\.[a-zA-Z0-9_.]+)"')
_FS_PATH_RE = re.compile(r'(/\s*)?"culture"(\s*/\s*"clients")')


def rewrite_strings(source: str) -> tuple[str, int]:
    """Rewrite bounded string-literal classes:
      1. mock.patch / module-equality dotted targets ("culture.clients.X")
      2. filesystem path strings ("culture" / "clients")

    Telemetry namespace strings ("culture.harness*", "culture.trace.*",
    "culture.attention.*") are NOT touched. The mock-patch regex is
    bounded to "culture.clients." so telemetry strings (which start with
    "culture.harness", "culture.trace", "culture.attention") cannot match.
    """
    edits = 0

    def _patch_repl(m):
        nonlocal edits
        edits += 1
        return f'"cultureagent.{m.group(1)[len("culture."):]}"'

    def _fs_repl(m):
        nonlocal edits
        edits += 1
        prefix = m.group(1) or ""
        suffix = m.group(2)
        return f'{prefix}"cultureagent"{suffix}'

    out = _MOCK_PATCH_RE.sub(_patch_repl, source)
    out = _FS_PATH_RE.sub(_fs_repl, out)
    return out, edits
```

- [ ] **Step 4: Run tests to verify all pass**

Run: `uv run pytest .claude/skills/cicd/scripts/_test_migrate_rewriter.py -v`
Expected: 11 passed.

- [ ] **Step 5: Commit**

```bash
git add .claude/skills/cicd/scripts/_migrate_rewriter.py \
        .claude/skills/cicd/scripts/_test_migrate_rewriter.py
git commit -m "feat(migrate): bounded-regex string rewriter (TDD)"
```

### Task 0.4: Add the parity grep verification (TDD)

**Files:**

- Modify: `.claude/skills/cicd/scripts/_migrate_rewriter.py`
- Modify: `.claude/skills/cicd/scripts/_test_migrate_rewriter.py`

- [ ] **Step 1: Add failing test for parity check**

Append to `_test_migrate_rewriter.py`:

```python
from _migrate_rewriter import telemetry_namespace_count  # noqa: E402


def test_telemetry_namespace_count():
    src = (
        '"culture.harness"\n'
        '"culture.harness.claude"\n'
        '"culture.trace.origin"\n'
        '"culture.attention.transitions"\n'
        '"culture.clients.shared.telemetry"\n'
        'service = "culture.harness"  # appears twice in two lines\n'
    )
    assert telemetry_namespace_count(src) == 5
```

- [ ] **Step 2: Run test, verify it fails**

Run: `uv run pytest .claude/skills/cicd/scripts/_test_migrate_rewriter.py::test_telemetry_namespace_count -v`
Expected: FAIL with `ImportError`.

- [ ] **Step 3: Implement telemetry_namespace_count**

Append to `_migrate_rewriter.py`:

```python
_TELEMETRY_NS_RE = re.compile(r'"(culture\.(?:harness|trace|attention)[^"]*)"')


def telemetry_namespace_count(source: str) -> int:
    """Count telemetry-namespace string literals (for migration parity check)."""
    return len(_TELEMETRY_NS_RE.findall(source))
```

- [ ] **Step 4: Run test, verify it passes**

Run: `uv run pytest .claude/skills/cicd/scripts/_test_migrate_rewriter.py -v`
Expected: 12 passed.

- [ ] **Step 5: Commit**

```bash
git add .claude/skills/cicd/scripts/_migrate_rewriter.py \
        .claude/skills/cicd/scripts/_test_migrate_rewriter.py
git commit -m "feat(migrate): telemetry-namespace parity counter (TDD)"
```

### Task 0.5: Build the migration driver script

**Files:**

- Create: `.claude/skills/cicd/scripts/migrate-from-culture.sh`
- Create: `.claude/skills/cicd/scripts/_migrate_driver.py`

- [ ] **Step 1: Create the Python driver**

Create `.claude/skills/cicd/scripts/_migrate_driver.py`:

```python
"""Driver for the culture -> cultureagent migration.

Usage:
    python _migrate_driver.py --phase {a,b} --culture-root ../culture \
        --output-receipt migration-receipt.json

Reads a manifest of (source_path, dest_path) pairs for the chosen phase,
copies each file, applies the rewrite passes, and emits a JSON receipt
with per-file stats:
    [
      {
        "src": "culture/clients/shared/attention.py",
        "dst": "cultureagent/clients/shared/attention.py",
        "src_sha": "<git blob sha>",
        "import_edits": 4,
        "string_edits": 0,
        "telemetry_count_src": 0,
        "telemetry_count_dst": 0,
        "diff_lines": 4
      },
      ...
    ]

Fails non-zero if telemetry_count_src != telemetry_count_dst for any
file (parity-check guarantee from spec section 6.1, rule 3).
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

from _migrate_rewriter import (
    rewrite_module,
    rewrite_strings,
    telemetry_namespace_count,
)


ALLOWLIST = (
    "culture.clients.shared",
    "culture.clients.claude",
    "culture.clients.codex",
    "culture.clients.copilot",
    "culture.clients.acp",
    "culture.aio",
    "culture.pidfile",
    "culture._constants",
    "culture.constants",
    "culture.protocol",
    "culture.telemetry",
    "culture.cli.shared.constants",
)


# Phase A — 0.2.0 manifest. (src relative to culture-root, dst relative to repo root.)
PHASE_A = [
    # Vendored utility modules
    ("culture/aio.py", "cultureagent/aio.py"),
    ("culture/pidfile.py", "cultureagent/pidfile.py"),
    ("culture/_constants.py", "cultureagent/_constants.py"),
    ("culture/constants.py", "cultureagent/constants.py"),
    ("culture/cli/shared/constants.py", "cultureagent/cli/shared/constants.py"),
    ("culture/telemetry/__init__.py", "cultureagent/telemetry/__init__.py"),
    ("culture/telemetry/context.py", "cultureagent/telemetry/context.py"),
    ("culture/protocol/__init__.py", "cultureagent/protocol/__init__.py"),
    ("culture/protocol/message.py", "cultureagent/protocol/message.py"),
    # Shared tier
    ("culture/clients/__init__.py", "cultureagent/clients/__init__.py"),
    ("culture/clients/shared/__init__.py", "cultureagent/clients/shared/__init__.py"),
    ("culture/clients/shared/attention.py", "cultureagent/clients/shared/attention.py"),
    ("culture/clients/shared/ipc.py", "cultureagent/clients/shared/ipc.py"),
    ("culture/clients/shared/irc_transport.py", "cultureagent/clients/shared/irc_transport.py"),
    ("culture/clients/shared/message_buffer.py", "cultureagent/clients/shared/message_buffer.py"),
    ("culture/clients/shared/rooms.py", "cultureagent/clients/shared/rooms.py"),
    ("culture/clients/shared/socket_server.py", "cultureagent/clients/shared/socket_server.py"),
    ("culture/clients/shared/telemetry.py", "cultureagent/clients/shared/telemetry.py"),
    ("culture/clients/shared/webhook.py", "cultureagent/clients/shared/webhook.py"),
    ("culture/clients/shared/webhook_types.py", "cultureagent/clients/shared/webhook_types.py"),
    # Phase A tests
    ("tests/harness/conftest.py", "tests/harness/conftest.py"),
    ("tests/harness/test_attention.py", "tests/harness/test_attention.py"),
    ("tests/harness/test_attention_config.py", "tests/harness/test_attention_config.py"),
    ("tests/harness/test_irc_transport_propagation.py", "tests/harness/test_irc_transport_propagation.py"),
    ("tests/harness/test_telemetry_module.py", "tests/harness/test_telemetry_module.py"),
    ("tests/harness/test_webhook_config_shared.py", "tests/harness/test_webhook_config_shared.py"),
    ("tests/harness/test_record_llm_call.py", "tests/harness/test_record_llm_call.py"),
    ("tests/test_irc_transport.py", "tests/test_irc_transport.py"),
    ("tests/test_irc_transport_tags.py", "tests/test_irc_transport_tags.py"),
    ("tests/test_message_buffer.py", "tests/test_message_buffer.py"),
    ("tests/test_socket_server.py", "tests/test_socket_server.py"),
    ("tests/test_webhook.py", "tests/test_webhook.py"),
    # test_skill_client.py — split: 0.2.0 keeps the shared/ipc-only blocks
    # The driver does not split files; the implementer hand-edits this one
    # after the bulk pass. See plan task A.5.
]


# Phase B — 0.3.0 manifest. Generated programmatically for the four backends.
def _phase_b_manifest():
    items = [
        ("packages/agent-harness/config.py", "packages/agent-harness/config.py"),
        ("packages/agent-harness/constants.py", "packages/agent-harness/constants.py"),
        ("packages/agent-harness/daemon.py", "packages/agent-harness/daemon.py"),
        ("packages/agent-harness/culture.yaml", "packages/agent-harness/culture.yaml"),
        ("packages/agent-harness/README.md", "packages/agent-harness/README.md"),
        ("packages/agent-harness/skill/__init__.py", "packages/agent-harness/skill/__init__.py"),
        ("packages/agent-harness/skill/irc_client.py", "packages/agent-harness/skill/irc_client.py"),
        # Phase B tests
        ("tests/harness/test_no_per_backend_copy_of_shared_modules.py",
         "tests/harness/test_no_per_backend_copy_of_shared_modules.py"),
        ("tests/harness/test_all_backends_parity.py",
         "tests/harness/test_all_backends_parity.py"),
        ("tests/harness/test_daemon_telemetry.py", "tests/harness/test_daemon_telemetry.py"),
        ("tests/test_supervisor.py", "tests/test_supervisor.py"),
        ("tests/test_acp_daemon.py", "tests/test_acp_daemon.py"),
        ("tests/test_codex_daemon.py", "tests/test_codex_daemon.py"),
        ("tests/test_copilot_daemon.py", "tests/test_copilot_daemon.py"),
        ("tests/test_daemon.py", "tests/test_daemon.py"),
        ("tests/test_daemon_config.py", "tests/test_daemon_config.py"),
        ("tests/test_daemon_ipc.py", "tests/test_daemon_ipc.py"),
        ("tests/test_agent_runner.py", "tests/test_agent_runner.py"),
        ("tests/test_skill_client.py", "tests/test_skill_client.py"),
    ]
    for backend in ("claude", "codex", "copilot", "acp"):
        items.extend([
            (f"culture/clients/{backend}/__init__.py",
             f"cultureagent/clients/{backend}/__init__.py"),
            (f"culture/clients/{backend}/agent_runner.py",
             f"cultureagent/clients/{backend}/agent_runner.py"),
            (f"culture/clients/{backend}/supervisor.py",
             f"cultureagent/clients/{backend}/supervisor.py"),
            (f"culture/clients/{backend}/daemon.py",
             f"cultureagent/clients/{backend}/daemon.py"),
            (f"culture/clients/{backend}/config.py",
             f"cultureagent/clients/{backend}/config.py"),
            (f"culture/clients/{backend}/constants.py",
             f"cultureagent/clients/{backend}/constants.py"),
            (f"culture/clients/{backend}/culture.yaml",
             f"cultureagent/clients/{backend}/culture.yaml"),
            (f"culture/clients/{backend}/skill/__init__.py",
             f"cultureagent/clients/{backend}/skill/__init__.py"),
            (f"culture/clients/{backend}/skill/irc_client.py",
             f"cultureagent/clients/{backend}/skill/irc_client.py"),
        ])
        items.append(
            (f"tests/harness/test_agent_runner_{backend}.py",
             f"tests/harness/test_agent_runner_{backend}.py"),
        )
    items.append(
        ("culture/clients/claude/__main__.py",
         "cultureagent/clients/claude/__main__.py"),
    )
    return items


PHASE_B = _phase_b_manifest()


def git_blob_sha(path: Path) -> str:
    out = subprocess.run(
        ["git", "hash-object", str(path)],
        capture_output=True, text=True, check=True,
    )
    return out.stdout.strip()


def migrate_one(src: Path, dst: Path, is_python: bool) -> dict:
    src_text = src.read_text(encoding="utf-8")
    src_telemetry = telemetry_namespace_count(src_text)
    src_sha = git_blob_sha(src)

    if is_python:
        rewritten, import_edits = rewrite_module(src_text, ALLOWLIST)
        rewritten, string_edits = rewrite_strings(rewritten)
    else:
        rewritten, import_edits, string_edits = src_text, 0, 0

    dst_telemetry = telemetry_namespace_count(rewritten)
    if dst_telemetry != src_telemetry:
        raise SystemExit(
            f"PARITY FAIL: {src} telemetry count {src_telemetry} -> "
            f"{dst} count {dst_telemetry}"
        )

    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(rewritten, encoding="utf-8")

    src_lines = src_text.splitlines()
    dst_lines = rewritten.splitlines()
    diff_lines = sum(1 for a, b in zip(src_lines, dst_lines) if a != b)
    diff_lines += abs(len(src_lines) - len(dst_lines))

    return {
        "src": str(src),
        "dst": str(dst),
        "src_sha": src_sha,
        "import_edits": import_edits,
        "string_edits": string_edits,
        "telemetry_count_src": src_telemetry,
        "telemetry_count_dst": dst_telemetry,
        "diff_lines": diff_lines,
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--phase", choices=("a", "b"), required=True)
    p.add_argument("--culture-root", required=True)
    p.add_argument("--output-receipt", required=True)
    args = p.parse_args()

    manifest = {"a": PHASE_A, "b": PHASE_B}[args.phase]
    culture_root = Path(args.culture_root).resolve()
    repo_root = Path(__file__).parent.parent.parent.parent.resolve()

    receipt = []
    for src_rel, dst_rel in manifest:
        src = culture_root / src_rel
        dst = repo_root / dst_rel
        is_python = src.suffix == ".py"
        if not src.exists():
            print(f"MISSING: {src}", file=sys.stderr)
            return 2
        receipt.append(migrate_one(src, dst, is_python))

    Path(args.output_receipt).write_text(
        json.dumps(receipt, indent=2), encoding="utf-8"
    )
    print(f"OK: {len(receipt)} files migrated; receipt at {args.output_receipt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 2: Create the shell wrapper**

Create `.claude/skills/cicd/scripts/migrate-from-culture.sh`:

```bash
#!/usr/bin/env bash
# Driver for the Phase 0b culture -> cultureagent migration.
#
# Usage:
#   migrate-from-culture.sh --phase {a|b} [--culture-root PATH] [--receipt PATH]
#
# Defaults:
#   --culture-root  ../culture
#   --receipt       migration-receipt-phase-<a|b>.json

set -euo pipefail

PHASE=""
CULTURE_ROOT="../culture"
RECEIPT=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --phase) PHASE="$2"; shift 2 ;;
        --culture-root) CULTURE_ROOT="$2"; shift 2 ;;
        --receipt) RECEIPT="$2"; shift 2 ;;
        *) echo "Unknown flag: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$PHASE" ]]; then
    echo "Usage: migrate-from-culture.sh --phase {a|b} [--culture-root PATH] [--receipt PATH]" >&2
    exit 2
fi

if [[ -z "$RECEIPT" ]]; then
    RECEIPT="migration-receipt-phase-${PHASE}.json"
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/../../../.."

uv run python "$SCRIPT_DIR/_migrate_driver.py" \
    --phase "$PHASE" \
    --culture-root "$CULTURE_ROOT" \
    --output-receipt "$RECEIPT"
```

- [ ] **Step 3: Make executable**

Run: `chmod +x .claude/skills/cicd/scripts/migrate-from-culture.sh`

- [ ] **Step 4: Smoke-test the driver against a single file**

Run a one-off check that the driver can locate culture and migrate one file (without committing the result):

```bash
uv run python -c "
from pathlib import Path
import sys
sys.path.insert(0, '.claude/skills/cicd/scripts')
from _migrate_driver import migrate_one
result = migrate_one(
    Path('../culture/culture/aio.py'),
    Path('/tmp/_smoke_aio.py'),
    is_python=True,
)
print(result)
"
```

Expected: prints a dict with `import_edits=0`, `string_edits=0`, `telemetry_count_src=telemetry_count_dst`. The file at `/tmp/_smoke_aio.py` is created.

Cleanup: `rm /tmp/_smoke_aio.py`

- [ ] **Step 5: Commit**

```bash
git add .claude/skills/cicd/scripts/_migrate_driver.py \
        .claude/skills/cicd/scripts/migrate-from-culture.sh
git commit -m "feat(migrate): driver script for phase-A/phase-B migrations"
```

---

## Phase A: 0.2.0 — shared tier + utilities + docs + CI gates

After Phase 0 is committed on the same branch, Phase A runs the migration script for shared tier, hand-edits the test-skill-client split, ships docs, configures CI, and tags 0.2.0.

### Task A.1: Branch off

- [ ] **Step 1: Create the 0.2.0 branch from main**

Assumes the spec PR (#5) has merged. If not, branch off the spec branch instead.

```bash
git checkout main
git pull
git checkout -b feat/0.2.0-shared-tier
```

### Task A.2: Run the Phase A migration

**Files:**

- Create: ~21 files under `cultureagent/`, `tests/harness/`, `tests/`
- Create: `migration-receipt-phase-a.json` (transient — deleted before commit)

- [ ] **Step 1: Run the migration**

Run: `bash .claude/skills/cicd/scripts/migrate-from-culture.sh --phase a`
Expected: `OK: <N> files migrated; receipt at migration-receipt-phase-a.json`

- [ ] **Step 2: Inspect the receipt**

Run: `jq '[.[] | {dst, import_edits, string_edits, diff_lines}] | sort_by(.diff_lines) | reverse | .[0:5]' migration-receipt-phase-a.json`
Expected: top diff_lines entries are reasonable (highest will be `irc_transport.py`, `telemetry.py` due to import-heavy headers).

- [ ] **Step 3: Verify no leftover `from culture.` / `import culture.` imports**

Run: `grep -rn 'from culture\b\|import culture\b' cultureagent/ tests/harness/ tests/ 2>/dev/null | grep -v 'tests/test_self_doctor\|tests/test_cli'`
Expected: no output (empty).

- [ ] **Step 4: Verify telemetry namespace strings preserved**

Run:

```bash
SRC_COUNT=$(grep -rho '"culture\.\(harness\|trace\|attention\)[^"]*"' \
    ../culture/culture/clients/shared/ \
    ../culture/tests/harness/test_irc_transport_propagation.py \
    | wc -l)
DST_COUNT=$(grep -rho '"culture\.\(harness\|trace\|attention\)[^"]*"' \
    cultureagent/clients/shared/ \
    tests/harness/test_irc_transport_propagation.py \
    | wc -l)
echo "src=$SRC_COUNT dst=$DST_COUNT"
```

Expected: `src=N dst=N` with same N.

### Task A.3: Hand-split `tests/test_skill_client.py`

Per spec section 7. The driver copied the full file in Phase A; remove the backend-specific blocks (which exercise per-backend `skill/irc_client.py`, none of which exist yet at 0.2.0). Defer those blocks to Phase B by re-running with the full file.

**Files:**

- Modify: `tests/test_skill_client.py`

- [ ] **Step 1: Identify backend-specific test classes**

Run: `grep -n '^class\|^def test_' tests/test_skill_client.py | head -30`
Manually identify which classes/functions reference per-backend `skill.irc_client`. Mark a list of line ranges to remove for 0.2.0.

- [ ] **Step 2: Remove the backend-specific blocks**

Edit `tests/test_skill_client.py`. Delete classes/functions that import from `cultureagent.clients.<backend>.skill.irc_client`. Leave only the blocks exercising `cultureagent.clients.shared.ipc`.

If the file becomes effectively empty, rename it to `tests/test_ipc_client.py` to better reflect its content.

- [ ] **Step 3: Verify the trimmed file imports cleanly**

Run: `uv run python -c "import ast; ast.parse(open('tests/test_skill_client.py').read())"`
Expected: no error.

- [ ] **Step 4: Note the deferred coverage in the receipt**

Note in `docs/migration/2026-05-09-phase-0b-receive.md` (created in Task A.7): "test_skill_client.py is split — backend-specific blocks deferred to 0.3.0."

### Task A.4: Run the harness unit tests

**Files:**

- (no edits — verification only)

- [ ] **Step 1: Run pytest on the migrated tests**

Run: `uv run pytest -n auto tests/harness/ tests/test_irc_transport.py tests/test_irc_transport_tags.py tests/test_message_buffer.py tests/test_socket_server.py tests/test_webhook.py tests/test_skill_client.py -v`
Expected: all pass.

- [ ] **Step 2: If any fail**

Read the failure carefully:

- Missing `__all__` declaration on a shared module → add it (declared in the spec section 5.1 as "non-behavior change, declared in receipt log").
- An unexpected `culture.*` import surfaced → grep for it, decide whether it's a missed allow-list entry or a real bug, and fix.
- A `_FakeProcess` or other private scaffold not migrated → locate it in `../culture` (likely inside one of the `clients/shared/*.py` modules) and confirm it travelled with the file.

Document any non-mechanical edit in the receipt log (Task A.7).

### Task A.5: Update `pyproject.toml` for 0.2.0

**Files:**

- Modify: `pyproject.toml`

- [ ] **Step 1: Add runtime dependencies**

Edit `pyproject.toml`'s `[project] dependencies = []` to be:

```toml
dependencies = [
    "pyyaml>=6.0",
    "opentelemetry-api>=1.25",
    "opentelemetry-sdk>=1.25",
    "opentelemetry-exporter-otlp-proto-grpc>=1.25",
    "opentelemetry-semantic-conventions>=0.46b0",
    "opentelemetry-instrumentation-aiohttp-server>=0.46b0",
]
```

- [ ] **Step 2: Add pytest-asyncio to dev deps**

In `[dependency-groups] dev`, append `"pytest-asyncio>=0.25"`.

- [ ] **Step 3: Bump version**

Run: `python3 .claude/skills/version-bump/scripts/bump.py minor` with stdin:

```bash
python3 .claude/skills/version-bump/scripts/bump.py minor <<'EOF'
{"added": [
    "cultureagent/clients/shared/* — 9 modules (attention, ipc, irc_transport, message_buffer, rooms, socket_server, telemetry, webhook, webhook_types) migrated from culture",
    "cultureagent/{aio,pidfile,_constants,constants,protocol/message,telemetry/context}.py and cultureagent/cli/shared/constants.py — vendored utility modules from culture (private)",
    "docs/api-stability.md — declared shared-tier import surface",
    "docs/{attention.md,concepts/harnesses.md,reference/architecture/shared-vs-cited.md,observability/harness-telemetry.md} — moved from culture",
    "docs/migration/2026-05-09-phase-0b-receive.md — migration receipt log",
    "tests/harness/* and tests/test_{irc_transport,message_buffer,socket_server,webhook,skill_client}*.py — 13 harness unit tests migrated",
    "CI: harness coverage gate (>=80% on cultureagent/clients/shared/), no-cycle lint step",
    "Runtime deps: pyyaml, opentelemetry-{api,sdk,exporter-otlp-proto-grpc,semantic-conventions,instrumentation-aiohttp-server}"
]}
EOF
```

Expected: prints `0.1.X -> 0.2.0`.

- [ ] **Step 4: Sync**

Run: `uv sync`
Expected: dependencies installed, no errors.

### Task A.6: Add `docs/api-stability.md`

**Files:**

- Create: `docs/api-stability.md`

- [ ] **Step 1: Author the doc**

Create `docs/api-stability.md` containing the content from spec section 5 — but **only the shared-tier table** (table 5.1) and the "Stability promise" preamble. Per-backend (5.2) and subprocess entries (5.3) become valid only at 0.3.0; they get added in Task B.10.

Resolve the spec's `…` ellipses by reading each shared module's `__all__`. If a module lacks `__all__`, this is the moment to add one (non-behavior change, document in receipt log).

Concrete commands to discover `__all__`:

```bash
for mod in attention ipc irc_transport message_buffer rooms socket_server telemetry webhook webhook_types; do
    echo "=== $mod ==="
    uv run python -c "import cultureagent.clients.shared.${mod} as m; print(getattr(m, '__all__', 'NO __all__'))"
done
```

- [ ] **Step 2: Verify markdownlint clean**

Run: `markdownlint-cli2 docs/api-stability.md`
Expected: 0 errors.

### Task A.7: Move docs from culture

**Files:**

- Create: `docs/attention.md` (from `../culture/docs/attention.md`)
- Create: `docs/concepts/harnesses.md` (from `../culture/docs/shared/concepts/harnesses.md`)
- Create: `docs/reference/architecture/shared-vs-cited.md` (from `../culture/docs/architecture/shared-vs-cited.md`)
- Create: `docs/observability/harness-telemetry.md` (from `../culture/docs/agentirc/harness-telemetry.md`)
- Create: `docs/migration/2026-05-09-phase-0b-receive.md`

- [ ] **Step 1: Copy the four moved docs**

```bash
mkdir -p docs/concepts docs/reference/architecture docs/observability docs/migration
cp ../culture/docs/attention.md docs/attention.md
cp ../culture/docs/shared/concepts/harnesses.md docs/concepts/harnesses.md
cp ../culture/docs/architecture/shared-vs-cited.md docs/reference/architecture/shared-vs-cited.md
cp ../culture/docs/agentirc/harness-telemetry.md docs/observability/harness-telemetry.md
```

- [ ] **Step 2: Sed any internal links that point to other moved docs**

Run:

```bash
grep -rln "docs/attention.md\|docs/shared/concepts/harnesses\|docs/architecture/shared-vs-cited\|docs/agentirc/harness-telemetry" docs/
```

Expected: any hits within the four newly-copied files. For each, rewrite the link to the new local path.

- [ ] **Step 3: Verify markdownlint clean**

Run: `markdownlint-cli2 "docs/**/*.md"`
Expected: 0 errors. If errors fire on the moved content (culture's lint config may differ), use the `lint-fix` agent or fix inline.

- [ ] **Step 4: Author the receipt log**

Create `docs/migration/2026-05-09-phase-0b-receive.md` with this scaffold:

```markdown
# Phase 0b receive — migration receipt

Generated alongside the 0.2.0 and 0.3.0 PRs migrating culture's agent
harness into cultureagent. Source design:
[2026-05-09-phase-0b-receive-harness-design.md](../superpowers/specs/2026-05-09-phase-0b-receive-harness-design.md).

## 0.2.0 — shared tier

**Source SHA on `agentculture/culture@main`:** <FILL IN AT MIGRATION TIME>

**Migration script:** `.claude/skills/cicd/scripts/migrate-from-culture.sh --phase a`

**Files migrated:** see `migration-receipt-phase-a.json` (not committed; the
table below is its human-readable summary).

### File-by-file summary

| Source                                  | Destination                                  | Import edits | String edits | Telemetry strings (src=dst) | Notes |
|-----------------------------------------|----------------------------------------------|--------------|--------------|-----------------------------|-------|
| culture/aio.py                          | cultureagent/aio.py                          | 0            | 0            | 0                           |       |
| culture/pidfile.py                      | cultureagent/pidfile.py                      | 0            | 0            | 0                           |       |
| culture/_constants.py                   | cultureagent/_constants.py                   | 0            | 0            | 0                           |       |
| culture/constants.py                    | cultureagent/constants.py                    | 0            | 0            | 0                           |       |
| culture/cli/shared/constants.py         | cultureagent/cli/shared/constants.py         | 0            | 0            | 0                           |       |
| culture/telemetry/context.py            | cultureagent/telemetry/context.py            | 0            | 0            | 0                           |       |
| culture/protocol/message.py             | cultureagent/protocol/message.py             | 0            | 0            | 0                           | private; may move to agentirc later (#4-adjacent) |
| culture/clients/shared/attention.py     | cultureagent/clients/shared/attention.py     | <N>          | <N>          | <N>                         |       |
| ...                                     | ...                                          | ...          | ...          | ...                         | (one row per migrated file) |

(Rows generated by `jq` from `migration-receipt-phase-a.json`.)

### Non-mechanical edits

- **`tests/test_skill_client.py` split** — backend-specific blocks removed
  for 0.2.0; deferred to 0.3.0.
- **`__all__` additions** — list any modules where we added `__all__`
  during the migration to declare the public surface (non-behavior change,
  per spec section 5.1).
- **Other** — list anything else that wasn't a mechanical rewrite, with
  rationale.

### Verification

- [x] `uv run pytest -n auto tests/harness/ tests/test_*.py -v` passed
- [x] `grep -rn 'from culture\b\|import culture\b' cultureagent/ tests/` empty
- [x] Telemetry namespace string counts equal in src vs dst per file
```

Fill in the table by running `jq -r '.[] | "| \(.src) | \(.dst) | \(.import_edits) | \(.string_edits) | \(.telemetry_count_src) |  |"' migration-receipt-phase-a.json`.

Capture the source SHA: `git -C ../culture rev-parse HEAD`.

- [ ] **Step 5: Verify markdownlint clean**

Run: `markdownlint-cli2 docs/migration/2026-05-09-phase-0b-receive.md`
Expected: 0 errors.

### Task A.8: CI changes — coverage gate + no-cycle lint

**Files:**

- Modify: `.github/workflows/tests.yml`

- [ ] **Step 1: Add the harness coverage gate**

Edit `.github/workflows/tests.yml`. In the `test` job, after the existing `pytest --cov=cultureagent ...` step, append:

```yaml
      - name: Harness coverage gate (>=80% shared tier)
        run: uv run coverage report --include='cultureagent/clients/shared/*' --fail-under=80
```

- [ ] **Step 2: Add the no-cycle lint step**

In the `lint` job, after the `markdownlint-cli2` step, append:

```yaml
      - name: No culture import cycle
        run: |
          if grep -rn 'from culture\b\|import culture\b' cultureagent/ tests/ ; then
            echo "::error::cultureagent must not import from culture (cycle risk)"
            exit 1
          fi
```

- [ ] **Step 3: Locally validate the no-cycle lint**

Run:

```bash
if grep -rn 'from culture\b\|import culture\b' cultureagent/ tests/ ; then
    echo "would fail"
else
    echo "would pass"
fi
```

Expected: `would pass`.

- [ ] **Step 4: Locally validate the coverage gate**

Run:

```bash
uv run pytest -n auto --cov=cultureagent --cov-report=term tests/
uv run coverage report --include='cultureagent/clients/shared/*' --fail-under=80
```

Expected: gate passes (>=80% on shared tier). If it fails, the migrated unit tests don't exercise enough — augment with targeted tests until it passes.

### Task A.9: Update existing docs/architecture.md hint

**Files:**

- Modify: `docs/architecture.md`

- [ ] **Step 1: Update the "Tomorrow" section partial**

Edit `docs/architecture.md`. The section "Tomorrow: agent-runtime migration from culture" stays mostly intact (Phase B will rewrite to "Today" once backends land), but update the line that says "Spec lives at `../culture/docs/reference/architecture/agent-harness-spec.md`" to say "Spec is being migrated to `docs/reference/architecture/agent-harness-spec.md` in 0.3.0; the canonical version still lives at culture's main during 0.2.0."

- [ ] **Step 2: Verify markdownlint clean**

Run: `markdownlint-cli2 docs/architecture.md`
Expected: 0 errors.

### Task A.10: Full local verification

**Files:**

- (no edits — verification only)

- [ ] **Step 1: Run all formatters**

Run: `uv run black cultureagent tests && uv run isort cultureagent tests`
Expected: no diff (or auto-fix applied; commit separately if so).

- [ ] **Step 2: Run all linters**

Run:

```bash
uv run black --check cultureagent tests
uv run isort --check-only cultureagent tests
uv run flake8 cultureagent tests
uv run bandit -c pyproject.toml -r cultureagent
markdownlint-cli2 "**/*.md" "#node_modules" "#.local"
```

Expected: all clean.

- [ ] **Step 3: Full test suite**

Run: `uv run pytest -n auto -v`
Expected: all green (existing AFI tests + new harness tests).

- [ ] **Step 4: AFI rubric**

Run: `uv run python -m cultureagent learn --json | jq -e '.purpose,.commands' >/dev/null`
Expected: exit 0.

If `afi` is on PATH: `afi cli doctor .`
Expected: green.

- [ ] **Step 5: Run the cicd portability lint**

Run: `bash .claude/skills/cicd/scripts/workflow.sh lint`
Expected: pass (no `/home/`, no per-user dotfile refs).

### Task A.11: Commit

**Files:**

- (commits all above changes)

- [ ] **Step 1: Stage and commit**

```bash
# Discard the JSON receipt — only the markdown summary is committed
rm -f migration-receipt-phase-a.json

git add cultureagent/ tests/ pyproject.toml uv.lock CHANGELOG.md \
        docs/ .github/workflows/tests.yml \
        .claude/skills/cicd/scripts/migrate-from-culture.sh \
        .claude/skills/cicd/scripts/_migrate_driver.py
git status --short
git commit -m "$(cat <<'EOF'
feat: receive harness shared tier from culture (0.2.0)

Migrates culture's clients/shared/ (9 modules) and the seven
non-clients utility imports the harness pulls from (aio, pidfile,
_constants, constants, cli/shared/constants, telemetry/context,
protocol/message). Lands declared API stability surface for the shared
tier, four moved harness docs, the migration receipt, and the harness
coverage gate (>=80%) + no-cycle lint step.

Tracks #3. Defers per-backend tier to 0.3.0; defers telemetry-schema
extraction to #4.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

### Task A.12: Push and open PR

- [ ] **Step 1: Push the branch**

Run: `git push -u origin feat/0.2.0-shared-tier`

- [ ] **Step 2: Open the PR via cicd skill**

Author the PR body to `/tmp/pr-body-a.md` summarizing:

- This is the 0.2.0 PR for issue #3 (shared tier only)
- 0.3.0 follow-up will land the four backends + reference impl
- Hard rule: cultureagent does not import from culture (no-cycle CI lint added)
- Coverage gate active on `cultureagent/clients/shared/` at >=80%

Run: `bash .claude/skills/cicd/scripts/workflow.sh open-pr --title "feat: receive harness shared tier from culture (0.2.0) (#3)" --body-file /tmp/pr-body-a.md --wait 180`

Wait for output. Expected: PR opens, all CI checks green, Qodo/Copilot comments appear.

- [ ] **Step 3: Address review feedback**

Use the cicd skill's `reply <PR>` subcommand to batch-reply. For each Qodo comment, decide: fix / pushback / instruct. Push fixes onto the same branch; the publish workflow will re-run.

- [ ] **Step 4: Merge once green and reviewed**

Once approved and CI green, merge via GitHub UI (or `gh pr merge --squash`).

- [ ] **Step 5: Verify 0.2.0 published to PyPI**

Run: `uv tool install cultureagent==0.2.0` in a clean environment (or `uv pip install --dry-run cultureagent==0.2.0` to just check availability).
Expected: install succeeds.

---

## Phase B: 0.3.0 — backends + reference impl + remaining tests

Phase B starts after 0.2.0 has merged to main and tagged. New branch `feat/0.3.0-backends`.

### Task B.1: Branch off 0.2.0

- [ ] **Step 1: Sync main and branch**

```bash
git checkout main
git pull
git checkout -b feat/0.3.0-backends
```

### Task B.2: Run the Phase B migration

**Files:**

- Create: ~50 files under `cultureagent/clients/{claude,codex,copilot,acp}/`, `packages/agent-harness/`, `tests/harness/`, `tests/`

- [ ] **Step 1: Run the migration**

Run: `bash .claude/skills/cicd/scripts/migrate-from-culture.sh --phase b`
Expected: `OK: <N> files migrated; receipt at migration-receipt-phase-b.json`.

- [ ] **Step 2: Inspect the receipt**

Run: `jq '[.[] | {dst, import_edits, string_edits, diff_lines}] | sort_by(.diff_lines) | reverse | .[0:10]' migration-receipt-phase-b.json`
Expected: top-diff entries are heavy import-rewrite files (`agent_runner.py` per backend, `daemon.py` per backend).

- [ ] **Step 3: Confirm `culture.yaml` files are byte-identical**

Run:

```bash
for backend in claude codex copilot acp; do
    diff "../culture/culture/clients/$backend/culture.yaml" \
         "cultureagent/clients/$backend/culture.yaml" \
         && echo "$backend culture.yaml: identical"
done
diff "../culture/packages/agent-harness/culture.yaml" \
     "packages/agent-harness/culture.yaml" \
     && echo "reference culture.yaml: identical"
```

Expected: all five "identical" lines.

- [ ] **Step 4: No-cycle check**

Run: `grep -rn 'from culture\b\|import culture\b' cultureagent/ tests/`
Expected: empty output.

### Task B.3: Add `__main__.py` for codex, copilot, acp

The driver only copied claude's `__main__.py` (only one with this file in culture). The other three backends need new ones to satisfy the `python -m cultureagent.clients.<backend>` contract.

**Files:**

- Create: `cultureagent/clients/codex/__main__.py`
- Create: `cultureagent/clients/copilot/__main__.py`
- Create: `cultureagent/clients/acp/__main__.py`

- [ ] **Step 1: Read claude's `__main__.py` for the pattern**

Run: `cat cultureagent/clients/claude/__main__.py`

- [ ] **Step 2: Create codex/copilot/acp `__main__.py` from the same pattern**

For each of the three backends, create a `__main__.py` that mirrors claude's structure but routes to the same backend's `daemon.run()` (or whatever entrypoint claude calls). Read the daemon module:

```bash
grep -n "^def \|^async def " cultureagent/clients/codex/daemon.py | head -10
```

The shape is typically:

```python
"""Subprocess entry: ``python -m cultureagent.clients.codex``.

Routes argv to the codex daemon. See cultureagent/clients/codex/daemon.py.
"""

from __future__ import annotations

import asyncio
import sys

from cultureagent.clients.codex.daemon import main as _daemon_main


def main(argv: list[str] | None = None) -> int:
    return asyncio.run(_daemon_main(argv if argv is not None else sys.argv[1:]))


if __name__ == "__main__":
    sys.exit(main())
```

If the actual daemon `main` is sync, drop the `asyncio.run` wrapper. Match claude's exact structure.

- [ ] **Step 3: Smoke-test each entry point**

Run:

```bash
uv run python -m cultureagent.clients.claude --help 2>&1 | head -3
uv run python -m cultureagent.clients.codex --help 2>&1 | head -3
uv run python -m cultureagent.clients.copilot --help 2>&1 | head -3
uv run python -m cultureagent.clients.acp --help 2>&1 | head -3
uv run python -m cultureagent.clients.claude.skill.irc_client --help 2>&1 | head -3
```

Expected: all five print non-error help (or at least don't `ImportError` / `ModuleNotFoundError`).

If any exits with a usage error from argparse but doesn't traceback, that's acceptable — the contract is `--help` works. If any tracebacks, fix the new `__main__.py`.

### Task B.4: Run all harness tests

- [ ] **Step 1: Run pytest**

Run: `uv run pytest -n auto -v`
Expected: all 28+ harness tests + AFI tests green.

- [ ] **Step 2: Investigate failures**

For each failure, decide:

- Missing import alias rename → patch the missed import
- Missing `__all__` declaration → add it (record in receipt log)
- Test assumes culture-specific path that wasn't rewritten → patch
- Real behavior change introduced by the migration → ROLLBACK that file and investigate

Document any non-mechanical edits in the receipt log.

### Task B.5: Update `pyproject.toml` for 0.3.0

**Files:**

- Modify: `pyproject.toml`

- [ ] **Step 1: Add optional-dependencies block**

Add (or extend) the `[project.optional-dependencies]` block:

```toml
[project.optional-dependencies]
backend-claude = ["claude-agent-sdk>=0.1", "anthropic>=0.40"]
backend-codex = []
backend-copilot = ["github-copilot-sdk"]
backend-acp = []

all-backends = [
    "cultureagent[backend-claude]",
    "cultureagent[backend-copilot]",
]
```

- [ ] **Step 2: Add force-include for culture.yaml files**

Add (or extend) the `[tool.hatch.build.targets.wheel.force-include]` block:

```toml
[tool.hatch.build.targets.wheel.force-include]
"cultureagent/clients/claude/culture.yaml"  = "cultureagent/clients/claude/culture.yaml"
"cultureagent/clients/codex/culture.yaml"   = "cultureagent/clients/codex/culture.yaml"
"cultureagent/clients/copilot/culture.yaml" = "cultureagent/clients/copilot/culture.yaml"
"cultureagent/clients/acp/culture.yaml"     = "cultureagent/clients/acp/culture.yaml"
```

- [ ] **Step 3: Bump version**

```bash
python3 .claude/skills/version-bump/scripts/bump.py minor <<'EOF'
{"added": [
    "cultureagent/clients/{claude,codex,copilot,acp}/* — four backend implementations migrated from culture",
    "packages/agent-harness/* — citation reference impl moved verbatim from culture",
    "tests/harness/test_{agent_runner_*,all_backends_parity,daemon_telemetry,no_per_backend_copy_of_shared_modules}.py and tests/test_{supervisor,acp_daemon,codex_daemon,copilot_daemon,daemon,daemon_config,daemon_ipc,agent_runner,skill_client}.py — 15 backend-tier harness tests",
    "docs/api-stability.md — expanded with per-backend surface and subprocess entry points",
    "docs/reference/architecture/agent-harness-spec.md — moved from culture; canonical spec for the harness reference impl",
    "Subprocess entries: __main__.py added for codex, copilot, acp (claude already had one)",
    "Optional dependencies: backend-claude (claude-agent-sdk, anthropic), backend-copilot (github-copilot-sdk), all-backends meta",
    "CI: harness coverage gate expanded to cultureagent/clients/* and packages/agent-harness/* (>=80%); publish trigger paths include packages/**"
]}
EOF
```

Expected: prints `0.2.X -> 0.3.0`.

- [ ] **Step 4: Sync**

Run: `uv sync`

### Task B.6: Expand `docs/api-stability.md`

**Files:**

- Modify: `docs/api-stability.md`

- [ ] **Step 1: Add per-backend section**

Append the per-backend table (spec section 5.2) and the subprocess entry-point section (spec section 5.3). Use the actual symbols present after the migration:

```bash
for backend in claude codex copilot acp; do
    echo "=== $backend.config ==="
    uv run python -c "
from cultureagent.clients.${backend} import config as c
import inspect
for name, obj in inspect.getmembers(c):
    if not name.startswith('_') and inspect.isclass(obj) and obj.__module__ == c.__name__:
        print(name)
"
done
```

Expected: each backend has at least `AgentConfig` and `DaemonConfig`.

- [ ] **Step 2: Update the "NOT public" section**

Reflect the now-present backend trees:

- `cultureagent.clients.<backend>.{agent_runner,supervisor,daemon}.*`
- `packages/agent-harness/*`

### Task B.7: Move the canonical spec

**Files:**

- Create: `docs/reference/architecture/agent-harness-spec.md`

- [ ] **Step 1: Copy and rewrite paths**

```bash
cp ../culture/docs/reference/architecture/agent-harness-spec.md docs/reference/architecture/agent-harness-spec.md
```

- [ ] **Step 2: Sed culture/clients/ paths to cultureagent/clients/**

Run: `sed -i 's|culture/clients/|cultureagent/clients/|g' docs/reference/architecture/agent-harness-spec.md`

- [ ] **Step 3: Sed culture.clients. dotted paths to cultureagent.clients.**

Run: `sed -i 's|culture\.clients\.|cultureagent.clients.|g' docs/reference/architecture/agent-harness-spec.md`

- [ ] **Step 4: Spot-check that no telemetry namespace strings were touched**

Run: `grep -n '"culture\.\(harness\|trace\|attention\)' docs/reference/architecture/agent-harness-spec.md | head -10`
Expected: any matches in the spec (it discusses telemetry namespaces) are unchanged.

- [ ] **Step 5: Markdownlint**

Run: `markdownlint-cli2 docs/reference/architecture/agent-harness-spec.md`
Expected: 0 errors.

### Task B.8: Update `docs/architecture.md`

**Files:**

- Modify: `docs/architecture.md`

- [ ] **Step 1: Replace "Tomorrow" with "Today"**

Edit the section heading and body — what was "Tomorrow: agent-runtime migration from culture" becomes "Today: agent-runtime is here". Update the spec pointer to the local path. Drop the "will move here as part of the migration" qualifier.

### Task B.9: Append 0.3.0 receipt

**Files:**

- Modify: `docs/migration/2026-05-09-phase-0b-receive.md`

- [ ] **Step 1: Append a "0.3.0 — backend tier" section**

Same shape as the 0.2.0 section — source SHA, file table from `migration-receipt-phase-b.json`, list of non-mechanical edits (especially the three new `__main__.py` files), verification log.

Capture: `git -C ../culture rev-parse HEAD`.

### Task B.10: CI changes — expand gate, add packages/** trigger

**Files:**

- Modify: `.github/workflows/tests.yml`
- Modify: `.github/workflows/publish.yml`

- [ ] **Step 1: Expand the harness coverage gate**

Edit `.github/workflows/tests.yml` — change the harness-coverage-gate step's `--include` from `cultureagent/clients/shared/*` to `cultureagent/clients/*,packages/agent-harness/*`. The fail-under stays at 80.

- [ ] **Step 2: Add packages/** to publish triggers**

Edit `.github/workflows/publish.yml`. In both `pull_request:` and `push:` triggers, append `"packages/**"` to the `paths:` list.

### Task B.11: Add subprocess parity assertions

**Files:**

- Modify: `tests/harness/test_all_backends_parity.py`

- [ ] **Step 1: Append a subprocess-help-parity test**

After the existing parity tests (which already check `culture.yaml` and import surface), append:

```python
import subprocess
import sys


@pytest.mark.parametrize("backend", BACKENDS)
def test_backend_module_help_works(backend):
    """python -m cultureagent.clients.<backend> --help prints help cleanly."""
    result = subprocess.run(
        [sys.executable, "-m", f"cultureagent.clients.{backend}", "--help"],
        capture_output=True, text=True, timeout=15,
    )
    assert result.returncode == 0, (
        f"backend={backend}: rc={result.returncode}\n"
        f"stdout={result.stdout}\nstderr={result.stderr}"
    )


@pytest.mark.parametrize("backend", BACKENDS)
def test_backend_skill_irc_client_help_works(backend):
    """python -m cultureagent.clients.<backend>.skill.irc_client --help works."""
    result = subprocess.run(
        [sys.executable, "-m",
         f"cultureagent.clients.{backend}.skill.irc_client", "--help"],
        capture_output=True, text=True, timeout=15,
    )
    assert result.returncode == 0, (
        f"backend={backend}: rc={result.returncode}\n"
        f"stdout={result.stdout}\nstderr={result.stderr}"
    )
```

Verify `BACKENDS` already exists at the top of the file (it does — referenced in the existing parity test).

- [ ] **Step 2: Run the new tests**

Run: `uv run pytest tests/harness/test_all_backends_parity.py -v`
Expected: all (existing + 8 new) pass.

### Task B.12: Full local verification

**Files:**

- (no edits — verification only)

- [ ] **Step 1: Run all formatters/linters/tests**

Run:

```bash
uv run black --check cultureagent tests
uv run isort --check-only cultureagent tests
uv run flake8 cultureagent tests
uv run bandit -c pyproject.toml -r cultureagent
markdownlint-cli2 "**/*.md" "#node_modules" "#.local"
uv run pytest -n auto -v
uv run coverage report --include='cultureagent/clients/*,packages/agent-harness/*' --fail-under=80
```

Expected: all clean.

- [ ] **Step 2: Five-entry-point smoke**

Run:

```bash
for backend in claude codex copilot acp; do
    uv run python -m cultureagent.clients.${backend} --help 2>&1 | head -3
done
uv run python -m cultureagent.clients.claude.skill.irc_client --help 2>&1 | head -3
```

Expected: each prints non-error help. Capture stdout into a file for the PR body smoke section.

- [ ] **Step 3: Wheel build sanity**

Run: `uv build && tar tzf dist/cultureagent-0.3.0.tar.gz | grep -E 'culture\.yaml$|/__main__\.py$' | sort`
Expected: 4× `culture.yaml`, 4× `__main__.py` present.

### Task B.13: Commit

- [ ] **Step 1: Stage and commit**

```bash
rm -f migration-receipt-phase-b.json

git add cultureagent/ packages/ tests/ pyproject.toml uv.lock CHANGELOG.md \
        docs/ .github/
git status --short
git commit -m "$(cat <<'EOF'
feat: receive harness backends + reference from culture (0.3.0)

Migrates culture's clients/{claude,codex,copilot,acp}/ four backends
and packages/agent-harness/ reference impl. Adds __main__.py for
codex/copilot/acp to satisfy the python -m cultureagent.clients.<backend>
subprocess contract. Adds backend-* optional-deps groups, force-includes
the four culture.yaml files in the wheel, and expands the harness
coverage gate to cover all of cultureagent/clients/ and
packages/agent-harness/ at >=80%.

Tests: 15 additional harness tests including 4 per-backend agent_runner,
all-backends parity (with new subprocess --help assertions), no-per-backend-
copy-of-shared-modules guard, and the test_skill_client.py backend blocks
deferred from 0.2.0.

Closes the implementation half of #3 — culture flips after this is tagged
on PyPI.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

### Task B.14: Push and open PR

- [ ] **Step 1: Push the branch**

Run: `git push -u origin feat/0.3.0-backends`

- [ ] **Step 2: Open the PR via cicd skill**

Author `/tmp/pr-body-b.md`. Include:

- This is the all-backends-included release (issue #3 acceptance criterion)
- Verification gate output (paste the five `--help` outputs)
- Coverage gate is now active on the full harness path
- After merge + tag, comment "Ready, cultureagent==0.3.0" on issue #3

Run: `bash .claude/skills/cicd/scripts/workflow.sh open-pr --title "feat: receive harness backends + reference from culture (0.3.0) (#3)" --body-file /tmp/pr-body-b.md --wait 180`

- [ ] **Step 3: Address feedback, merge**

Same flow as Task A.12.

### Task B.15: Verify 0.3.0 on PyPI and reply on issue #3

- [ ] **Step 1: Verify the release**

Run: `uv tool install cultureagent==0.3.0` in a clean shell.
Expected: install succeeds.

Then verify the four daemons + skill-client subprocess entries:

```bash
for backend in claude codex copilot acp; do
    cultureagent-test-env --module "cultureagent.clients.${backend}" --help \
        || uv run python -m cultureagent.clients.${backend} --help
done
```

(Use uv run from the freshly-installed environment.)

- [ ] **Step 2: Comment on issue #3**

```bash
gh issue comment 3 --repo agentculture/cultureagent --body "$(cat <<'EOF'
Ready, `cultureagent==0.3.0`. All four backends + shared tier + reference
impl tagged on PyPI. Stable surface declared at `docs/api-stability.md`.
Coverage gate >=80% green on `cultureagent/clients/*` +
`packages/agent-harness/*`. Subprocess entry points (`python -m
cultureagent.clients.<backend>` ×4 and the whisper IPC client for each)
all respond to `--help` cleanly.

Round-trip protocol per the brief — if culture's Phase 1 cutover surfaces
a contract surprise, file a brief here in the documented shape and I'll
triage as fix / pushback / instruct.

Telemetry-schema extraction tracked at #4 (gradual split, after Phase 0b).

- cultureagent (Claude)
EOF
)"
```

- [ ] **Step 3: Update task tracking**

Mark this plan's tasks complete in any tracking system. Issue #3 stays open until culture closes it from their side after Phase 1 cutover.

---

## Self-Review (already performed by the planner)

Performed by the writing-plans agent against the spec:

1. **Spec coverage:** every spec section has a task. Section 4 layout → Tasks A.2/A.3/B.2/B.3. Section 5 stability surface → Task A.6 + B.6. Section 6 mechanics → Phase 0 (Tasks 0.1–0.5). Section 7 test split → Task A.3. Section 8 pyproject → Tasks A.5/B.5. Section 9 CI → Tasks A.8/B.10. Section 10 release cadence → Tasks A.11/A.12/B.13/B.14/B.15. Section 11 verification gate → Tasks A.10/B.12. Section 12 release protocol → Task B.15. Section 13 risks all addressed in flow (R1 telemetry parity = Task 0.4 + Task A.2 step 4; R2 cycle lint = Task A.8 step 2; R3 protocol/message = note in api-stability doc + receipt; R4 coverage gate = Task A.10 step 4; R5 subprocess = Task B.11; R6 culture.yaml = Task B.2 step 3; R7 culture stale docs = mention in B.15 reply; R8 round-trip = mentioned in B.15 reply). Section 14 OOS not implemented (correct). Section 15 reverse-out is operational, no task needed.

2. **Placeholder scan:** no "TBD" / "TODO" / "implement later". A few `<N>` placeholders in receipt-log table are explicit "fill in after running migration" instructions, not hidden TODOs.

3. **Type consistency:** `rewrite_module` / `rewrite_strings` / `telemetry_namespace_count` are the same across Tasks 0.2/0.3/0.4 and 0.5. ALLOWLIST is identical between test fixture and driver. The five rewrite rules from spec section 6.1 map cleanly onto the two functions plus the parity counter (rule 4 "filenames untouched" is structurally satisfied — the regexes don't match `culture.yaml`).

---

## Execution choice

**Plan complete and saved to `docs/superpowers/plans/2026-05-09-phase-0b-receive-harness.md`.**

Two execution options:

1. **Subagent-Driven (recommended)** — fresh subagent per task, two-stage review between tasks, fast iteration. Each subagent gets one task with full context; they don't share session memory.
2. **Inline Execution** — execute tasks in this session, batched with checkpoints for review.

Recommend Subagent-Driven for this plan because the migration touches many files and benefits from clean per-task contexts (the migration script tasks are quite different from the docs-and-CI tasks).
