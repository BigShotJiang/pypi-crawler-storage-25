from typing import List, Dict


# -----------------------------
# 🔹 LLM CLIENT
# -----------------------------

class LLMClient:
    def __init__(self, provider):
        if not hasattr(provider, "generate"):
            raise ValueError("Provider does not support LLM capability")
        self.provider = provider

    def chat(self, messages: List[Dict], **kwargs) -> str:
        # simple validation (no Pydantic)
        if not isinstance(messages, list):
            raise ValueError("messages must be a list of dicts")

        for i, msg in enumerate(messages):
            if not isinstance(msg, dict):
                raise ValueError(f"Message at index {i} must be a dict")
            if "role" not in msg or "content" not in msg:
                raise ValueError(f"Message at index {i} must have 'role' and 'content'")

        return self.provider.generate(messages, **kwargs)


# -----------------------------
# 🔹 TTS CLIENT
# -----------------------------

class TTSClient:
    def __init__(self, provider):
        if not hasattr(provider, "generate_speech"):
            raise ValueError("Provider does not support TTS capability")
        self.provider = provider

    def speak(self, text: str, **kwargs) -> str:
        if not isinstance(text, str) or not text.strip():
            raise ValueError("Text must be a non-empty string")

        return self.provider.generate_speech(text, **kwargs)


# -----------------------------
# 🔹 STT CLIENT
# -----------------------------

class STTClient:
    def __init__(self, provider):
        if not hasattr(provider, "generate_text"):
            raise ValueError("Provider does not support STT capability")
        self.provider = provider

    def transcribe(self, audio_input: str, **kwargs) -> str:
        if not isinstance(audio_input, str) or not audio_input.strip():
            raise ValueError("audio_input must be a valid file path or URL")

        return self.provider.generate_text(audio_input, **kwargs)