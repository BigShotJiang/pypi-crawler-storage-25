from groq import Groq
from ai_services.base import LLMProviderBase
from ai_services.prompts.evaluation_prompt_generator import generate_evaluation_prompt
import json
import logging
from ai_services.utils.error_handler import handle_api_errors
import os

logger = logging.getLogger(__name__)

class GroqProvider(LLMProviderBase):
    def __init__(
        self,
        key: str | None = None,
        model: str = "llama3-8b-8192",  
        temperature: float = 0.7,
        max_tokens: int = 2048,
        event_logger=None
    ):
        if key is None:
         key = os.getenv("GROQ_API_KEY")

        if not key:
            raise ValueError("GROQ API key is required")
        self.client = Groq(api_key=key)
        self.model = model
        self.default_args = {
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        self.event_logger = event_logger  # ✅ Add event logger
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"GroqProvider initialized with model: {self.model}")

    def generate(self, messages, **kwargs):
        args = {**self.default_args, **kwargs}

        try:
            if not self.validate_messages(messages):
                self.logger.warning("Message validation failed. Aborting Groq generation.")
                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="LLM",
                        module=__name__,
                        function="generate",
                        request_data={"messages": messages},
                        status="validation_failed",
                        error="Invalid message format"
                    )
                return None

            self.logger.info(f"Generating response using Groq model: {self.model}")
            self.logger.debug(f"Input messages: {json.dumps(messages, indent=2)}")
            self.logger.debug(f"Generation arguments: {args}")

            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                **args
            )

            if hasattr(response, "choices") and response.choices:
                message = response.choices[0].message
                if hasattr(message, "content") and message.content:
                    result = message.content.strip()
                    self.logger.info(f"LLM response (truncated): {result[:75]}...")

                    if self.event_logger:
                        self.event_logger.log_event(
                            service_type="LLM",
                            module=__name__,
                            function="generate",
                            request_data={"messages": messages},
                            response_data={"result": result}
                        )

                    return result
                else:
                    self.logger.warning("Groq response message content is empty.")
                    return None
            else:
                self.logger.warning("Groq response has no choices.")
                return None

        except Exception as e:
            handle_api_errors(self.__class__.__name__, e, context="generating LLM response")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    status="error",
                    error=str(e)
                )

            return None
