import io
import pygame
import os
import logging
from ai_services.logger import setup_logger
from openai import OpenAI
from ai_services.base import LLMProviderBase, TTSProviderBase, STTProviderBase
from ai_services.dependencies.tts_common_functions import _play_audio
from ai_services.utils.error_handler import handle_api_errors
from dotenv import load_dotenv

load_dotenv()

setup_logger()
logger = logging.getLogger(__name__)

class OpenAIProvider(LLMProviderBase):
    def __init__(self, key: str | None = None, model: str = "gpt-4o-mini", temperature: float = 0.7, max_tokens: int = 2048,event_logger=None):
        if key is None:
         key = os.getenv("OPENAI_API_KEY")

        if not key:
            raise ValueError("OPENAI API key is required")

        self.client = OpenAI(api_key=key)    
        self.model = model
        self.default_args = {
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        self.event_logger = event_logger
        self.logger = logging.getLogger(__name__)

    def generate(self, messages, **kwargs):
        if not self.validate_messages(messages):
            self.logger.warning("Invalid LLM message input.")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    response_data=None,
                    status="validation_failed",
                    error="Invalid message structure"
                )
            return None                                           
        
        try:
            self.logger.info(f"Generating response with model: {self.model}")
            args = {**self.default_args, **kwargs}
            self.logger.debug(f"Generation args: {args}")
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                **args
            )
            result = response.choices[0].message.content
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    response_data={"result": result}
                )
            return result
        except Exception as e:
            handle_api_errors(self.__class__.__name__, e, context="generating LLM response")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    status="error",
                    error=e
                )
            return None
   
class OpenAITTSProvider(TTSProviderBase):
   
    def __init__(self, key: str | None = None, model: str = "tts-1", voice: str = "onyx",event_logger=None):       
        if key is None:
         key = os.getenv("OPENAI_API_KEY")

        if not key:
            raise ValueError("OPENAI API key is required")        
        self.client = OpenAI(api_key=key)
        self.model = model
        self.voice = voice
        self.event_logger = event_logger
        try:
            pygame.mixer.init()
        except Exception as e:
            logger.error(f"Failed to initialize pygame mixer: {e}")
        self.logger = logging.getLogger(__name__)

    def generate_speech(self, text: str) -> io.BytesIO:      
        if not self.validate_text(text):
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    response_data=None,
                    status="validation_failed",
                    error="Text input is empty or whitespace"
                )
            return None
                 
        try:
            self.logger.info(f"Generating speech with model: {self.model}")
            response = self.client.audio.speech.create(
                model=self.model,
                voice=self.voice,
                input=text,
                response_format="mp3"
               
            )
            
            audio_data = response.content
            if not audio_data:
                self.logger.warning("No audio data received from TTS.")
                return None
            
            audio_io = io.BytesIO(audio_data)
            audio_io.seek(0)

            try:            
                _play_audio(audio_io)
            except Exception as e:
                self.logger.error(f"Error during audio playback: {e}")


            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text, "model": self.model, "voice": self.voice},
                    response_data={"status": "audio_generated"}
                )

            return audio_io

        except Exception as e:
            handle_api_errors(self.__class__.__name__, e, context="generating TTS response")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    status="error",
                    error=e
                )
            return None

      
  
class OpenAISTTProvider(STTProviderBase):
    def __init__(self, key: str | None = None, model="whisper-1", max_tokens=1024, event_logger=None):
        if key is None:
         key = os.getenv("OPENAI_API_KEY")

        if not key:
            raise ValueError("OPENAI API key is required")
        self.client = OpenAI(api_key=key)
        self.model = model
        self.default_args = {"max_tokens": max_tokens}
        self.logger = logging.getLogger(__name__)
        self.event_logger = event_logger
        

    def generate_text(self, audio_path):
        """Transcribe audio file using OpenAI Whisper."""
        try:
            if not audio_path or not os.path.exists(audio_path):
                self.logger.warning(f"Audio file not found: {audio_path}")
                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="STT",
                        module=__name__,
                        function="generate_text",
                        request_data={"audio_path": audio_path},
                        status="validation_failed",
                        error="Audio file path is invalid or does not exist"
                    )
                return None
                

            with open(audio_path, "rb") as audio_file:
                response = self.client.audio.transcriptions.create(
                    model=self.model,
                    file=audio_file,
                    language="en"
                )

            text = response.text.strip()
            if text:
                self.logger.info(f"Transcription successful: {text[:50]}...")
            else:
                self.logger.warning("No text returned from transcription.")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="STT",
                    module=__name__,
                    function="generate_text",
                    request_data={"audio_path": audio_path, "model": self.model},
                    response_data={"transcription": text},
                    status="success" if text else "empty"
                )

            return text if text else None

        except Exception as e:
            self.logger.error(f"Error in transcribing audio: {str(e)}")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="STT",
                    module=__name__,
                    function="generate_text",
                    request_data={"audio_path": audio_path},
                    status="error",
                    error=e
                )
            return None
