import anthropic
from ai_services.base import LLMProviderBase
import logging
from ai_services.utils.error_handler import handle_api_errors
import os

logger = logging.getLogger(__name__)

class ClaudeProvider(LLMProviderBase):
    def __init__(
        self,
        key: str | None = None,
        model: str = "claude-3-opus-20240229",
        temperature: float = 0.7,
        max_tokens: int = 2048,
        event_logger=None
    ):
        if key is None:
         key = os.getenv("ANTHROPIC_API_KEY")

        if not key:
            raise ValueError("ANTHROPIC API key is required")
        self.client = anthropic.Anthropic(api_key=key)
        self.model = model
        self.default_args = {
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        self.event_logger = event_logger  # ✅ Added
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"ClaudeProvider initialized with model: {self.model}")

    def generate(self, messages, **kwargs):
        if not self.validate_messages(messages):
            self.logger.warning("Message validation failed. Aborting Claude generation.")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    status="validation_failed",
                    error="Invalid message format"
                )
            return None

        try:
            args = {**self.default_args, **kwargs}

            system_prompt = next((m["content"] for m in messages if m["role"] == "system"), None)
            user_messages = [m["content"] for m in messages if m["role"] == "user"]
            user_content = " ".join(user_messages).strip()

            if not system_prompt:
                self.logger.warning("System prompt not found. Proceeding without system prompt.")
            if not user_content:
                self.logger.warning("No user content found for generation.")
                return None

            self.logger.info(f"Generating response with model: {self.model}")
            self.logger.debug(f"System prompt: {system_prompt}")
            self.logger.debug(f"User content (first 100 chars): {user_content[:100]}")

            response = self.client.messages.create(
                model=self.model,
                system=system_prompt,
                messages=[{"role": "user", "content": user_content}],
                **args
            )

            if not response or not response.content:
                self.logger.warning("Claude returned an empty response.")
                return None

            text_response = response.content[0].text.strip()
            self.logger.info(f"Claude response (first 100 chars): {text_response[:100]}")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    response_data={"result": text_response}
                )

            return text_response

        except Exception as e:
            self.logger.exception("Exception occurred during Claude generation.")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    status="error",
                    error=str(e)
                )
            return "Error generating response from Claude."
