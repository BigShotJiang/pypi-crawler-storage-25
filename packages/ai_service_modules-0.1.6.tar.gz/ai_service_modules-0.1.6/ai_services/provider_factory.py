
import logging


logger = logging.getLogger(__name__)

def get_provider(name: str, provider_type: str = "llm", **kwargs,):
    logger.info(f"Requesting provider: name={name}, type={provider_type}")

    # Input validation
    if not isinstance(name, str) or not name.strip():
        logger.error("Invalid provider name passed.")
        raise ValueError("Provider name must be a non-empty string.")
    if not isinstance(provider_type, str) or not provider_type.strip():
        logger.error("Invalid provider type passed.")
        raise ValueError("Provider type must be a non-empty string.")

    name = name.lower()
    provider_type = provider_type.lower()
    logger.debug(f"Normalized name: {name}, provider_type: {provider_type}")
    logger.debug(f"Keyword arguments passed: {list(kwargs.keys())}")

    try:
        if provider_type == "llm":

            if name == "openai":
                from ai_services.providers.openai_provider import OpenAIProvider
                return OpenAIProvider(**kwargs)

            elif name == "anthropic":
                from ai_services.providers.anthropic_provider import ClaudeProvider
                return ClaudeProvider(**kwargs)

            elif name == "gemini":
                from ai_services.providers.gemini_provider import GeminiClientProvider
                return GeminiClientProvider(**kwargs)

            elif name == "groq":
                from ai_services.providers.groq_provider import GroqProvider
                return GroqProvider(**kwargs)

        elif provider_type == "tts":

            if name == "openai":
                from ai_services.providers.openai_provider import OpenAITTSProvider
                return OpenAITTSProvider(**kwargs)

            elif name == "gtts":
                from ai_services.providers.gtts_provider import GTTSProvider
                return GTTSProvider(**kwargs)

            elif name == "gemini":
                from ai_services.providers.gemini_provider import GeminiTTSProvider
                return GeminiTTSProvider(**kwargs)

        elif provider_type == "stt":

            if name == "openai":
                from ai_services.providers.openai_provider import OpenAISTTProvider
                return OpenAISTTProvider(**kwargs)

        

        else:
            logger.error(f"Unsupported provider type: '{provider_type}' (expected 'llm', 'tts', or 'stt')")
            raise ValueError(f"Unsupported provider type: '{provider_type}'")

    except TypeError as e:
        logger.exception(f"Provider initialization failed for '{name}' with type '{provider_type}': {e}")
        raise

    except Exception as e:
        logger.exception(f"Unexpected error while creating provider '{name}' of type '{provider_type}': {e}")
        raise
