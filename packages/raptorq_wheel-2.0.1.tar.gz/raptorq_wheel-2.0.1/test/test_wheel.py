"""
Post-build wheel validation tests for raptorq.

These tests verify that the installed wheel works correctly across
different platforms, data sizes, and edge cases. They are designed
to run against the installed package (not a development build).
"""

import os
import platform
import random
import sys
from unittest import TestCase


class WheelSmokeTestCase(TestCase):
    """Basic smoke tests to verify the wheel is importable and functional."""

    def test_import(self):
        """Verify the module can be imported."""
        import raptorq

        self.assertTrue(hasattr(raptorq, "Encoder"))
        self.assertTrue(hasattr(raptorq, "Decoder"))

    def test_platform_info(self):
        """Print platform info for debugging CI failures."""
        print(f"\n  Python: {sys.version}")
        print(f"  Platform: {platform.platform()}")
        print(f"  Architecture: {platform.machine()}")
        print(f"  OS: {platform.system()}")


class RoundtripTestCase(TestCase):
    """Encode-decode roundtrip tests with various data sizes."""

    def _roundtrip(self, data_size, mtu, repair_packets):
        """Helper: encode data, simulate packet loss, decode and verify."""
        from raptorq import Decoder, Encoder

        data = os.urandom(data_size)
        encoder = Encoder.with_defaults(data, mtu)
        packets = encoder.get_encoded_packets(repair_packets)

        # Simulate packet loss by shuffling and dropping some packets
        random.shuffle(packets)
        # Keep only 90% of packets (simulate 10% loss)
        keep_count = max(1, int(len(packets) * 0.9))
        packets = packets[:keep_count]

        decoder = Decoder.with_defaults(len(data), mtu)
        result = None
        for packet in packets:
            result = decoder.decode(packet)
            if result is not None:
                break

        self.assertIsNotNone(result, f"Failed to decode {data_size} bytes with MTU={mtu}")
        self.assertEqual(result, data)

    def test_small_data(self):
        """Roundtrip with small data (< 1 MTU)."""
        self._roundtrip(data_size=100, mtu=512, repair_packets=10)

    def test_medium_data(self):
        """Roundtrip with medium data (~1KB)."""
        self._roundtrip(data_size=1024, mtu=512, repair_packets=20)

    def test_large_data(self):
        """Roundtrip with larger data (~10KB)."""
        self._roundtrip(data_size=10000, mtu=1400, repair_packets=15)

    def test_large_mtu(self):
        """Roundtrip with large MTU relative to data."""
        self._roundtrip(data_size=5000, mtu=4000, repair_packets=10)

    def test_minimum_mtu(self):
        """Roundtrip with the smallest practical MTU."""
        # Minimum MTU that works with raptorq is around 4 bytes (header overhead)
        self._roundtrip(data_size=1000, mtu=100, repair_packets=30)

    def test_exact_mtu_boundary(self):
        """Data size equals MTU (single source block)."""
        self._roundtrip(data_size=512, mtu=512, repair_packets=10)


class EncoderTestCase(TestCase):
    """Tests focused on Encoder behavior."""

    def test_encoder_produces_packets(self):
        """Encoder should produce packets as list of bytes."""
        from raptorq import Encoder

        data = os.urandom(2048)
        encoder = Encoder.with_defaults(data, 512)
        packets = encoder.get_encoded_packets(10)

        self.assertIsInstance(packets, list)
        self.assertGreater(len(packets), 0)
        for packet in packets:
            self.assertIsInstance(packet, bytes)
            self.assertGreater(len(packet), 0)

    def test_encoder_deterministic(self):
        """Same input should produce same packets."""
        from raptorq import Encoder

        data = os.urandom(1024)
        encoder1 = Encoder.with_defaults(data, 512)
        encoder2 = Encoder.with_defaults(data, 512)
        packets1 = encoder1.get_encoded_packets(5)
        packets2 = encoder2.get_encoded_packets(5)

        self.assertEqual(packets1, packets2)

    def test_encoder_repair_packets_count(self):
        """Encoder should produce at least repair_packets_per_block extra packets."""
        from raptorq import Encoder

        data = os.urandom(2048)
        encoder = Encoder.with_defaults(data, 512)

        packets_5 = encoder.get_encoded_packets(5)
        packets_20 = encoder.get_encoded_packets(20)

        # More repair packets should produce more total packets
        self.assertGreater(len(packets_20), len(packets_5))


class DecoderTestCase(TestCase):
    """Tests focused on Decoder behavior."""

    def test_decoder_insufficient_packets(self):
        """Decoder should return None when insufficient packets received."""
        from raptorq import Decoder, Encoder

        data = os.urandom(4096)
        encoder = Encoder.with_defaults(data, 512)
        packets = encoder.get_encoded_packets(5)

        # Only feed 1 packet - should not be enough to decode
        decoder = Decoder.with_defaults(len(data), 512)
        result = decoder.decode(packets[0])
        # With large data and few packets, decoding should fail
        # (it might succeed if data is very small relative to MTU)
        if len(packets) > 2:
            self.assertIsNone(result)

    def test_decoder_all_source_packets(self):
        """Decoder should succeed with just source packets (no repair)."""
        from raptorq import Decoder, Encoder

        data = os.urandom(1024)
        encoder = Encoder.with_defaults(data, 512)
        # 0 repair packets = only source packets
        packets = encoder.get_encoded_packets(0)

        decoder = Decoder.with_defaults(len(data), 512)
        result = None
        for packet in packets:
            result = decoder.decode(packet)
            if result is not None:
                break

        self.assertIsNotNone(result)
        self.assertEqual(result, data)


class StressTestCase(TestCase):
    """Stress tests with larger data to verify correctness under load."""

    def test_large_payload(self):
        """Roundtrip with ~100KB data."""
        from raptorq import Decoder, Encoder

        data = os.urandom(100_000)
        encoder = Encoder.with_defaults(data, 1400)
        packets = encoder.get_encoded_packets(20)

        random.shuffle(packets)
        # Drop 10 packets
        packets = packets[10:]

        decoder = Decoder.with_defaults(len(data), 1400)
        result = None
        for packet in packets:
            result = decoder.decode(packet)
            if result is not None:
                break

        self.assertIsNotNone(result)
        self.assertEqual(result, data)

    def test_multiple_roundtrips(self):
        """Multiple sequential encode-decode cycles."""
        from raptorq import Decoder, Encoder

        for i in range(10):
            size = random.randint(500, 5000)
            data = os.urandom(size)
            encoder = Encoder.with_defaults(data, 512)
            packets = encoder.get_encoded_packets(15)

            random.shuffle(packets)

            decoder = Decoder.with_defaults(len(data), 512)
            result = None
            for packet in packets:
                result = decoder.decode(packet)
                if result is not None:
                    break

            self.assertIsNotNone(result, f"Failed on iteration {i} with size {size}")
            self.assertEqual(result, data)
