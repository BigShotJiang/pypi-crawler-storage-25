"""Helper functions for S3 operations."""

import json
import os
import time
from datetime import datetime, timezone
from typing import Literal, Optional, Tuple, TypedDict

import click
import requests
from loguru import logger

from gable.api.client import GableAPIClient
from gable.cli.commands.asset_plugins.sca_prime import ScaPrimePlugin
from gable.cli.helpers.npm import (
    get_installed_package_dir,
    run_sca_prime_version_check,
    start_sca_prime,
)
from gable.cli.helpers.repo_interactions import get_git_repo_info, get_pr_link
from gable.common_types import LineageDataFile
from gable.openapi import (
    Action1,
    CollectionMechanism,
    ErrorResponse,
    GetConfigResponse,
    JobTrigger,
    OutputFormat,
    PostScaStartRunRequest,
    PrBaseBranch,
    SourceType,
    StaticAnalysisCodeMetadata,
    StaticAnalysisPathsApiRequest,
    StaticAnalysisToolConfig,
    StaticAnalysisToolMetadata,
    Type,
)


class GithubEventMetadata(TypedDict, total=False):
    """Metadata extracted from GitHub event data."""

    event_repo: Optional[str]
    job_trigger: Optional[JobTrigger]
    is_default_branch: Optional[bool]
    pr_base_branch: Optional[PrBaseBranch]
    pr_number: Optional[int]


class AdditionalMetadata(TypedDict, total=False):
    """Additional metadata for the StaticAnalysisCodeMetadata."""

    operating_system: Optional[str]
    has_uncommitted_changes: Optional[bool]
    namespace: Optional[str]
    docker_image_version: Optional[str]
    sca_config_version: Optional[str]


class DuplicateStartRunConflict(click.ClickException):
    """Raised when start-run returns a duplicate-run conflict."""


def extract_additional_metadata(
    additional_metadata: str, cli_namespace: Optional[str] = None
) -> AdditionalMetadata:
    try:
        additional_metadata_dict = json.loads(additional_metadata)
    except json.JSONDecodeError:
        logger.debug(f"Error parsing additional metadata: {additional_metadata}")
        additional_metadata_dict = {}
    env_namespace = additional_metadata_dict.get("namespace")

    # Resolve namespace conflict
    if cli_namespace is not None and env_namespace is not None:
        if cli_namespace != env_namespace:
            raise click.ClickException(
                f"Namespace conflict: CLI option '{cli_namespace}' does not match "
                f"environment variable '{env_namespace}'. Please use only one method "
                "to specify the namespace."
            )
    # Use CLI option if provided, otherwise fall back to env var
    resolved_namespace = cli_namespace if cli_namespace is not None else env_namespace

    return AdditionalMetadata(
        operating_system=additional_metadata_dict.get("operating_system"),
        has_uncommitted_changes=additional_metadata_dict.get("has_uncommitted_changes"),
        namespace=resolved_namespace,
        docker_image_version=additional_metadata_dict.get("docker_image_version"),
        sca_config_version=additional_metadata_dict.get("sca_config_version"),
    )


def extract_job_trigger(
    event_data: dict,
) -> JobTrigger:
    job_trigger = os.getenv("GITHUB_EVENT_NAME")
    logger.debug(f"Event type: {job_trigger}")
    git_action = event_data.get("action", "")
    logger.debug(f"Action: {git_action}")
    if job_trigger == "pull_request":
        if git_action == "opened":
            return JobTrigger.PULL_REQUEST_CREATED
        elif git_action == "synchronize":
            return JobTrigger.PULL_REQUEST_UPDATED
    elif job_trigger == "issue_comment":
        if (
            git_action == "created"
            and "pull_request" in event_data.get("issue", {})
            and event_data.get("comment", {})
            .get("body", "")
            .lower()
            .startswith("/gable")
        ):
            return JobTrigger.PULL_REQUEST_COMMENT
    elif job_trigger == "push":
        if event_data.get("ref", "") in [
            "refs/heads/main",
            "refs/heads/master",
        ]:
            return JobTrigger.MERGE_TO_MAIN
    return JobTrigger.UNKNOWN


def extract_github_event_metadata(
    event_data: dict,
    git_branch: str,
    user_job_trigger: JobTrigger | None,
) -> GithubEventMetadata:
    """Extract metadata from GitHub event data for StaticAnalysisCodeMetadata.

    Args:
        event_data: The GitHub event JSON data
        git_branch: The current git branch name

    Returns:
        A dictionary with extracted metadata fields
    """
    # Extract repository info
    repository_data = event_data.get("repository")
    repository_dict = repository_data if isinstance(repository_data, dict) else {}
    event_repo = repository_dict.get("full_name")
    job_trigger = (
        user_job_trigger
        if user_job_trigger is not None
        else extract_job_trigger(event_data)
    )
    logger.debug(f"Chosen event type for upload: '{job_trigger}'")

    # Check if this is the default branch
    default_branch = repository_dict.get("default_branch")
    is_default_branch = default_branch == git_branch if default_branch else None

    # Get PR base branch
    pr_base_branch = None
    pr_number = None
    pull_request_data = event_data.get("pull_request")
    pull_request_dict = pull_request_data if isinstance(pull_request_data, dict) else {}
    if pull_request_dict:
        base_ref = pull_request_dict.get("base", {}).get("ref")
        base_sha = pull_request_dict.get("base", {}).get("sha")
        if base_ref or base_sha:
            pr_base_branch = PrBaseBranch(branch=base_ref, commit=base_sha)
        pr_number = pull_request_dict.get("number")
    else:
        issue_data = event_data.get("issue")
        issue_dict = issue_data if isinstance(issue_data, dict) else {}
        if issue_dict:
            pr_number = issue_dict.get("number")

    return {
        "event_repo": event_repo,
        "job_trigger": job_trigger,
        "is_default_branch": is_default_branch,
        "pr_base_branch": pr_base_branch,
        "pr_number": pr_number,
    }


def format_repo_commit_timestamp(commit_timestamp: datetime | None) -> str | None:
    """Serialize a git commit timestamp to the API's UTC ISO-8601 format."""
    if commit_timestamp is None:
        return None

    if commit_timestamp.tzinfo is None:
        commit_timestamp = commit_timestamp.replace(tzinfo=timezone.utc)

    return commit_timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def resolve_repo_commit_timestamp_from_env() -> str | None:
    """Resolve repo commit timestamp from the additional metadata envelope."""
    try:
        additional_metadata = json.loads(os.getenv("GABLE_ADDITIONAL_METADATA", "{}"))
        raw_timestamp = additional_metadata.get(
            "repo_commit_timestamp"
        ) or additional_metadata.get("repoCommitTimestamp")
    except json.JSONDecodeError:
        raw_timestamp = None

    if not raw_timestamp:
        return None

    try:
        parsed = datetime.fromisoformat(str(raw_timestamp).replace("Z", "+00:00"))
    except ValueError:
        logger.debug(
            f"Invalid repo_commit_timestamp in GABLE_ADDITIONAL_METADATA: {raw_timestamp}. Expected ISO-8601."
        )
        return None

    return format_repo_commit_timestamp(parsed)


def start_sca_run(
    client: GableAPIClient,
    project_root: str,
    action: Literal["register", "check", "upload"],
    output: str | None,
    include_unchanged_assets: bool | None,
    external_component_id: str | None,
    upload_type: Type | None,
    repo_name: str | None,
    namespace: str | None = None,
    user_job_trigger: JobTrigger | None = None,
    collection_mechanism: CollectionMechanism | None = None,
) -> Tuple[str, GetConfigResponse | None]:
    """Call the SCA start run API to get the S3 presigned URL to upload the SCA results

    Args:
        client: The Gable API client
        project_root: The root directory of the project to analyze

    Returns:
        A tuple of (run_id, presigned_url, config)
        config will be None if not present in the response

    Raises:
        ClickException: If the API call was not successful
    """
    repo_commit_timestamp = None
    try:
        git_info = get_git_repo_info(project_root)
        repo_commit_timestamp = format_repo_commit_timestamp(git_info["mergedAt"])
    except click.ClickException:
        logger.debug(
            f"No git repository found at project root {project_root}, trying env vars instead, otherwise default values"
        )
        git_info = {
            "gitRemoteOriginHTTPS": os.environ.get(
                "GABLE_REMOTE_ORIGIN_HTTPS", "unknown"
            ),
            "gitBranch": os.environ.get("GABLE_BRANCH", "unknown"),
            "gitHash": os.environ.get("GABLE_HASH", "unknown"),
        }

    # Fallback for split-container flows (e.g. C1): first container can pass commit timestamp
    # to upload container through env/metadata when git is not mounted.
    if repo_commit_timestamp is None:
        repo_commit_timestamp = resolve_repo_commit_timestamp_from_env()

    package_name, package_version = get_sca_package_info()
    include = True if include_unchanged_assets else False
    output_f = None
    if action == "check":
        if output == "markdown":
            output_f = OutputFormat.markdown
        elif output == "text":
            output_f = OutputFormat.text
        else:
            output_f = OutputFormat.json

    event_data = json.loads(os.getenv("GITHUB_EVENT", "{}"))
    logger.debug(f"All event data dict: {event_data}")
    github_metadata = extract_github_event_metadata(
        event_data, git_info["gitBranch"], user_job_trigger
    )
    logger.debug(f"GitHub metadata: {github_metadata}")
    additional_metadata: AdditionalMetadata = extract_additional_metadata(
        os.getenv("GABLE_ADDITIONAL_METADATA", "{}"), cli_namespace=namespace
    )

    # Call the SCA start run API to create backend run and fetch config
    request_kwargs: dict = dict(
        code_info=StaticAnalysisCodeMetadata(
            repo_uri=git_info["gitRemoteOriginHTTPS"],
            repo_branch=git_info["gitBranch"],
            repo_commit=git_info["gitHash"],
            repo_commit_timestamp=repo_commit_timestamp,
            project_root=project_root,
            external_component_id=external_component_id,
            repo_name=repo_name,
            operating_system=additional_metadata.get("operating_system"),
            has_uncommitted_changes=additional_metadata.get("has_uncommitted_changes"),
            docker_image_version=additional_metadata.get("docker_image_version"),
            namespace=additional_metadata.get("namespace"),
            sca_config_version=additional_metadata.get("sca_config_version"),
            **github_metadata,
        ),
        sca_info=StaticAnalysisToolMetadata(
            name=package_name,
            version=package_version,
            config=StaticAnalysisToolConfig(
                ingress_signatures=[],
                egress_signatures=[],
            ),
        ),
        action=Action1(action),
        pr_link=get_pr_link(),
        output_format=output_f,
        include_unchanged_assets=include,
        type=upload_type,
    )
    request_kwargs["collection_mechanism"] = (
        collection_mechanism
        if collection_mechanism is not None
        else CollectionMechanism.BYOL
    )

    response, success, status_code = client.post_sca_start_run(
        PostScaStartRunRequest(**request_kwargs)
    )

    if not success or isinstance(response, ErrorResponse):
        if (
            status_code == 409
            and isinstance(response, ErrorResponse)
            and response.title in {"DuplicateEventIdError", "DuplicateRunIdError"}
        ):
            raise DuplicateStartRunConflict(
                f"Duplicate run detected: {response.title} - {response.message}"
            )
        raise click.ClickException(
            f"Error starting static code analysis run: {response.title} - {response.message}"  # type: ignore
        )

    return response.runId, response.config


def get_sca_package_info() -> tuple[str, str]:
    """Get the name and version of the installed @gable-eng/sca package."""
    try:
        package_dir = get_installed_package_dir()
        package_json_path = os.path.join(package_dir, "package.json")
        with open(package_json_path, "r") as f:
            package_data = json.load(f)
            return (package_data.get("name", ""), package_data.get("version", ""))
    except Exception as e:
        logger.debug(f"Error getting SCA package info: {e}")
        return ("", "")


def poll_sca_job_status(
    api_client: GableAPIClient,
    job_id: str,
    timeout_seconds: float = 300,
    interval_seconds: float = 5,
) -> dict:
    """
    Poll the job status until it completes successfully or fails, or until timeout.

    Parameters:
        api_client (GableAPIClient): Client used to fetch job status.
        job_id (str): The ID of the job to check.
        timeout_seconds (float): Max seconds to poll before timing out.
        interval_seconds (float): Seconds to wait between polling attempts.

    Returns:
        dict: The final status response from the API.

    Raises:
        click.ClickException: If the job fails or polling times out.
    """
    start_time = time.time()
    logger.debug(f"Polling job status for job_id: {job_id}")
    poll_until_complete = False if timeout_seconds <= 0 else True
    while True:
        elapsed_time = time.time() - start_time

        if poll_until_complete and elapsed_time > timeout_seconds:
            raise click.ClickException(
                f"Timed out after {timeout_seconds}s waiting for job ID: {job_id}"
            )
        try:
            response, success, _ = api_client.get_sca_run_status(job_id)
        except requests.RequestException as error:
            click.echo(f"[retrying] Error polling job status: {error}", err=True)
            logger.error("Error polling job status: %s, retrying…", error)
            time.sleep(interval_seconds)
            continue
        if not success or isinstance(response, ErrorResponse):
            error_msg = (
                f"Error polling job status for job ID {job_id}: " f"{response.message}"
            )
            logger.error(error_msg)
            raise click.ClickException(error_msg)
        status_data = response.dict()
        job_status = status_data.get("status", "").lower()
        message = status_data.get("message", "")
        click.echo(
            f"[{int(elapsed_time)}s] Status for Job with ID {job_id}: {job_status}"
        )
        click.echo(f"{message}")
        if not poll_until_complete:
            return status_data

        if job_status == "success":
            return status_data

        if job_status == "error":
            error_msg = status_data.get("message", "No error message provided.")
            raise click.ClickException(
                f"Job failed with status '{job_status}': {error_msg}"
            )

        time.sleep(interval_seconds)


def run_sca_prime_and_capture(
    client: GableAPIClient,
    project_root: str,
    language: str,
    prime_annotation: tuple[str, ...],
    prime_exclude_pattern: tuple[str, ...],
    prime_rules_file: str | None,
    prime_debug: bool,
) -> LineageDataFile | None:
    try:
        source_type = SourceType(language)
    except ValueError as exc:
        supported_languages = ", ".join(source.value for source in SourceType)
        raise click.ClickException(
            f"Unsupported language '{language}' for SCA Prime. "
            f"Supported values: {supported_languages}"
        ) from exc

    if not os.path.exists(project_root):
        raise click.ClickException(f"Project root does not exist: {project_root}")

    if prime_rules_file is not None and not os.path.exists(prime_rules_file):
        raise click.ClickException(f"Rules file does not exist: {prime_rules_file}")

    run_sca_prime_version_check(client)
    semgrep_bin_path = ScaPrimePlugin(source_type).install_semgrep()

    sca_prime_future = start_sca_prime(
        client=client,
        project_root=project_root,
        annotations=list(prime_annotation),
        exclude_patterns=list(prime_exclude_pattern),
        lang=source_type,
        sca_debug=prime_debug,
        semgrep_bin_path=semgrep_bin_path,
        rules_file=prime_rules_file,
    )

    if not sca_prime_future:
        return None

    process_future, temp_dir = sca_prime_future
    process_future.wait()
    findings_file = os.path.join(temp_dir, "product-findings.json")

    # Convert to LineageDataFile format to mimic asset-detector output
    try:
        with open(findings_file, "r") as f:
            findings_data = f.read()
            paths = StaticAnalysisPathsApiRequest.model_validate_json(findings_data)
            return LineageDataFile.model_validate(paths.model_dump())

    except FileExistsError as fileNotFound:
        raise click.ClickException(
            f"Findings file does not exist: {findings_file}: {fileNotFound}"
        )
