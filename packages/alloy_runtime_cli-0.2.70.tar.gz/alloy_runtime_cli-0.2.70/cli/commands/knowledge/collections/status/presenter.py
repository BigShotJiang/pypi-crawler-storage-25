from math import ceil
from typing import cast

from pydantic import BaseModel

from alloy_runtime_types.dtos.knowledge import ListCollectionDocumentStatusesResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def present_collection_statuses(
    response: ListCollectionDocumentStatusesResponse,
) -> None:
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="collection_name",
            header_label="Collection",
            compact_line=1,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="total_documents",
            header_label="Total",
            align="right",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="queued_documents",
            header_label="Queued",
            align="right",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="processing_documents",
            header_label="Processing",
            align="right",
            compact_line=1,
            compact_style="magenta",
        ),
        ColumnConfig(
            source_field="completed_documents",
            header_label="Completed",
            align="right",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="failed_documents",
            header_label="Failed",
            align="right",
            compact_line=1,
            compact_style="red",
        ),
        ColumnConfig(
            source_field="duplicate_documents",
            header_label="Duplicate",
            align="right",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="filtered_documents",
            header_label="Filtered",
            align="right",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="estimated_remaining_processing_ms",
            header_label="ETA",
            align="right",
            compact_line=1,
            compact_style="yellow",
            formatter=_format_processing_eta,
        ),
    ]

    output.table(
        items=cast(list[BaseModel], response.collections),
        title=f"Collection Status ({response.total})",
        columns=columns,
        raw_payload=response,
        total_count=response.total,
    )


def _format_processing_eta(value: object) -> str:
    if not isinstance(value, int) or value <= 0:
        return "—"

    total_seconds = ceil(value / 1000)
    if total_seconds < 60:
        return f"{total_seconds}s"

    minutes, seconds = divmod(total_seconds, 60)
    if minutes < 60:
        return f"{minutes}m {seconds}s" if seconds else f"{minutes}m"

    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f"{hours}h {minutes}m" if minutes else f"{hours}h"

    days, hours = divmod(hours, 24)
    return f"{days}d {hours}h" if hours else f"{days}d"
