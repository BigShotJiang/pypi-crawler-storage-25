from pathlib import Path
from json import loads, dumps
from mimetypes import guess_type
from threading import Thread
from io import BytesIO
from typing import IO, Any
import secrets
import string
import time

LimitedStream = Any

storageTypes = ["gdrive", "local"]

class Metadata:
    id: str
    name: str
    mimeType: str
    size: int
    delete: str
    hidden: bool
    created_at: float
    delete_after: float

    optional_parentfolderID: str
    optional_gfileID: str

    def to_dict(self, private: bool = False):
        data = {
            "id": self.id,
            "name": self.name,
            "mimeType": self.mimeType,
            "size": self.size,
            "hidden": self.hidden,
            "created_at": self.created_at,
            "delete_after": self.delete_after
        }

        if private:
            data["delete"] = self.delete

        return data

    def to_json(self, ensure_ascii: bool = False, indent: int = 0, private: bool = False):
        return dumps(self.to_dict(private=private), ensure_ascii=ensure_ascii, indent=indent)
    
    def load(self, data: dict = {}, dataraw: str = "", dataPath: Path = Path()):
        if data:
            self.id = str(data["id"])
            self.name = str(data["name"])
            self.mimeType = data["mimeType"]
            self.size = int(data["size"])
            self.delete = str(data["delete"])
            self.hidden = bool(data["hidden"] if "hidden" in data else False)
            self.created_at = float(data["created_at"] if "created_at" in data else int(time.time()))
            self.delete_after = float(data["delete_after"] if "delete_after" in data else -1)
            return
        
        elif dataraw:
            data = loads(dataraw)
        
        elif dataPath:
            data = loads(dataPath.read_text())
            self.load(data)
        
        else:
            raise ValueError("No data provided")

class storage():
    folderidlength: int
    ownerkeylength: int
    chunksize: int
    cache: bool

    def __init__(self, config: dict, configPath: Path):
        self.folderidlength = config["folderidlength"]
        # ``deletelength`` is the pre-1.0.0 spelling. We prefer the new
        # ``ownerkeylength`` but fall back so existing deployments don't
        # need to edit their config.json on upgrade.
        if "ownerkeylength" in config:
            self.ownerkeylength = int(config["ownerkeylength"])
        elif "deletelength" in config:
            self.ownerkeylength = int(config["deletelength"])
            print(
                "WARNING: 'deletelength' in config.json is deprecated; "
                "rename it to 'ownerkeylength'."
            )
        else:
            self.ownerkeylength = 12
        self.chunksize = config["chunk"]
        
        if "delete" in config:
            self.delete_rule = config["delete"]
        else:
            # In-memory default only; do not write to config on disk — the file
            # may be mounted read-only (e.g. docker bind mount with :ro).
            self.delete_rule = {
                "enabled": False,
                "after": 3600,
                "permanently": False,
                "reaper_interval": 3600,
            }

    def _save(self, filename: str, fileid: str = ""):
        if not fileid:
            fileid = self.create_fileid()
        mimetype = guess_type(filename)[0] or "application/octet-stream"
        metadataname = filename+".metadata"

        return fileid, mimetype, metadataname
    
    def remove(self, fileid: str, filename: str, deletepass: str, force: bool = False, permanently: bool = False) -> bool: ...
    def save(self, file: LimitedStream | IO[bytes], filesize: int | None, filename: str, fileid: str = "") -> Metadata: ...
    def load_metadata(self, fileid: str, filename: str) -> Metadata: ...
    def download(self, fileid: str, filename: str) -> Any: ...
    def get_list(self, path, dir) -> list[str]: ...
    def is_fid_exists(self, fileid: str) -> bool: ...
    def is_cached(self, fileid: str, filename: str) -> bool: return False
    def get_cached(self, fileid: str, filename: str) -> Path: raise FileNotFoundError(f"Cache file not found: {fileid} {filename}")

    def _config_check(self, config: dict, configPath: Path) -> dict:
        # Apply in-memory defaults only. Runtime writes back to config.json are
        # unsafe on read-only mounts.
        if "delete" not in config:
            config["delete"] = {
                "enabled": False,
                "after": 3600,
                "permanently": False,
                "reaper_interval": 3600,
            }

        return config


    def _create_id(self, length: int) -> str:
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))
    
    def create_fileid(self) -> str:
        folderid = self._create_id(self.folderidlength)
        if self.is_fid_exists(folderid):
            return self.create_fileid()
        return folderid

    def make_metadata(self, filesize: int, filename: str, fileid: str, mimetype: str) -> Metadata:
        metadata = Metadata()
        metadata.id = fileid
        metadata.name = filename
        metadata.mimeType = mimetype
        metadata.size = filesize
        metadata.delete = self._create_id(self.ownerkeylength)
        metadata.hidden = False
        metadata.created_at = int(time.time())

        if self.delete_rule.get("enabled", False):
            try:
                after_value = float(self.delete_rule.get("after", -1))
            except (TypeError, ValueError):
                after_value = -1.0
            metadata.delete_after = after_value if after_value > 0 else -1.0
        else:
            metadata.delete_after = -1.0
        return metadata
    
    def write_stream(self, stream: LimitedStream, path: Path):
        with path.open("wb") as f:
            while True:
                chunk = stream.read(self.chunksize)
                if not chunk: break
                f.write(chunk)

class gdrive(storage):
    from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload
    import googleapiclient.http

    class _UPSStreamSlice(object):
        """Truncated stream.

        Takes a stream and presents a stream that is a slice of the original stream.
        This is used when uploading media in chunks. In later versions of Python a
        stream can be passed to httplib in place of the string of data to send. The
        problem is that httplib just blindly reads to the end of the stream. This
        wrapper presents a virtual stream that only reads to the end of the chunk.
        """

        def __init__(self, stream: LimitedStream, begin, chunksize):
            """Constructor.

            Args:
            stream: (io.Base, file object), the stream to wrap.
            begin: int, the seek position the chunk begins at.
            chunksize: int, the size of the chunk.
            """
            self._stream = stream
            self._begin = begin
            self._chunksize = chunksize

            if chunksize != 1 and chunksize < 262144:
                chunksize = 262144

        def read(self, n=-1):
            """Read n bytes.

            Args:
            n, int, the number of bytes to read.

            Returns:
            A string of length 'n', or less if EOF is reached.
            """
            # The data left available to read sits in [cur, end)
            cur = self._stream.tell()
            end = self._begin + self._chunksize
            if n == -1 or cur + n > end:
                n = end - cur
            return self._stream.read(n)

    class UPSMediaIoStreamUpload(MediaIoBaseUpload):
        from googleapiclient import _helpers as util
        DEFAULT_CHUNK_SIZE = 100 * 1024 * 1024

        @util.positional(3)
        def __init__(self, fd, mimetype, size, chunksize=DEFAULT_CHUNK_SIZE, resumable=False):
            from googleapiclient.errors import InvalidChunkSizeError
            self._fd = fd
            self._mimetype = mimetype
            if not (chunksize == -1 or chunksize > 0):
                raise InvalidChunkSizeError()
            self._chunksize = chunksize
            self._resumable = resumable
            self._size = size

    #del(googleapiclient.http._StreamSlice)
    #googleapiclient.http._StreamSlice = _UPSStreamSlice

    def __init__(self, config: dict, configPath: Path):
        super().__init__(config, configPath)
        config = self._config_check(config, configPath)

        from googleapiclient.discovery import build
        from google.oauth2 import service_account
        self.credential = service_account.Credentials.from_service_account_info(config["gdrive"]["credential"], scopes=config["gdrive"]["scopes"])
        self.service = build('drive', 'v3', credentials=self.credential)
        self.root: str = str(config["gdrive"]["root"])
        self.cache: bool = bool(config["gdrive"]["cache"])
        if self.cache:
            print("Cache setup")
            self._cache_setup(config)
        else:
            del(self.googleapiclient.http._StreamSlice)
            self.googleapiclient.http._StreamSlice = self._UPSStreamSlice

    def add_cache(self, fileid: str, metadata: Metadata, file_info: dict, file_metadata_info: dict):
        new = {
            "fileid": fileid,
            "metadata": metadata,
            "file_info": file_info,
            "file_metadata_info": file_metadata_info
        }

        # Populate the lookup dict before exposing the id to the worker via the queue;
        # otherwise the worker can pop() and observe a half-initialized entry.
        self.cachequeueID[fileid] = new
        self.cachequeue.append(fileid)

    def _cache_setup(self, config: dict):
        cache_config = config.copy()
        cache_config["storage"] = "local"
        cache_config["local"] = {"root": "cache"}
        self.cacheControl = local(cache_config, Path("cache.json"))
        self.cachequeue = []
        self.cachequeueID: dict[str, dict[str, str|dict[str,str]|Metadata]] = {}

        self.cacheThread = Thread(target=self._cache_worker, daemon=True)
        self.cacheThread.start()
        print("Cache Worker Started")

        g_files = self.get_list(dir=self.root, mimeType="application/vnd.google-apps.folder")

        for fileid in self.cacheControl.get_list(self.cacheControl.root, dir=True):
            filename: str | None = None
            for file in self.cacheControl.get_list(self.cacheControl.root / fileid):
                if not file.endswith(".metadata"):
                    filename = file
            
            if not filename: continue

            metadata = self.cacheControl.load_metadata(fileid, filename)
            folderid = g_files[fileid] if fileid in g_files else self.mkdir(fileid)
            file_info = {
                'name': filename,
                'parents': [folderid]
            }
            file_metadata_info = {
                'name': f"{filename}.metadata",
                'parents': [folderid]
            }

            self.add_cache(fileid, metadata, file_info, file_metadata_info)
            print("Cache added", fileid, filename)

    
    def _cache_worker(self):
        # Any exception escaping this loop kills the daemon thread and silently
        # strands all queued uploads for the rest of the process lifetime. Catch
        # everything, log, and move on to the next item.
        while True:
            try:
                if len(self.cachequeue) == 0:
                    time.sleep(1)
                    continue

                fileid = self.cachequeue.pop(0)

                raw_metadata = self.cachequeueID.get(fileid, {}).get("metadata")
                raw_info = self.cachequeueID.get(fileid, {}).get("file_info")
                raw_metadata_info = self.cachequeueID.get(fileid, {}).get("file_metadata_info")

                metadata: Metadata
                file_info: dict
                file_metadata_info: dict

                if isinstance(raw_metadata, Metadata): metadata = raw_metadata
                else: continue
                if isinstance(raw_info, dict): file_info = raw_info
                else: continue
                if isinstance(raw_metadata_info, dict): file_metadata_info = raw_metadata_info
                else: continue

                filePath = self.cacheControl.get_file_path(metadata.id, metadata.name)
                metadataPath = self.cacheControl.get_file_path(metadata.id, metadata.name, metadata=True)

                if not (filePath and metadataPath):
                    print(f"[cache worker] cache file missing: {metadata.id} {metadata.name}")
                    continue

                self.save_MediaFileUpload(filePath, metadataPath, metadata, file_info, file_metadata_info)
                self.cacheControl.remove(metadata.id, metadata.name, metadata.delete, force=True, permanently=True)
                self.cachequeueID.pop(fileid, None)
            except Exception as exc:
                print(f"[cache worker] exception: {exc!r}")
                time.sleep(1)

    def get_cached(self, fileid: str, filename: str) -> Path:
        if self.cache and fileid in self.cachequeueID:
            return self.cacheControl.get_file_path(fileid, filename)
        raise FileNotFoundError(f"Cache file not found: {fileid} {filename}")

    def is_cached(self, fileid: str, filename: str) -> bool:
        metadata = self.cachequeueID.get(fileid, {}).get("metadata", None)
        if isinstance(metadata, Metadata):
            return self.cache and fileid in self.cachequeueID and filename == metadata.name
        return False

    def _config_check(self, config: dict, configPath: Path):
        config = super()._config_check(config, configPath)
        if not config["gdrive"]["root"]:
            raise ValueError("Google drive root is not defined.")
        # In-memory default only; do not persist back to config.json.
        if "cache" not in config["gdrive"]:
            config["gdrive"]["cache"] = False

        return config

    def _get_files(self, **kwargs):
        if "fields" not in kwargs:
            kwargs["fields"] = "nextPageToken, files(id, name, mimeType)"
        return self.service.files().list(includeItemsFromAllDrives=True, supportsAllDrives=True, pageSize=1000, **kwargs)
    
    def remove(self, fileid: str, filename: str, deletepass: str, force: bool = False, permanently: bool = False) -> bool:
        try:
            metadata = self.load_metadata(fileid, filename)
        except FileNotFoundError:
            return False

        if metadata.delete != deletepass and not force:
            return False

        rootList = self.get_list(dir=self.root, mimeType="application/vnd.google-apps.folder")
        parentFolderID = rootList[metadata.id]
        infiles = self.get_list(dir=parentFolderID)

        if permanently:
            for name, gid in infiles.items():
                self.service.files().delete(fileId=gid, supportsAllDrives=True).execute()
            self.service.files().delete(fileId=parentFolderID, supportsAllDrives=True).execute()
            return True

        if "delete" in rootList:
            deleteFolder = rootList["delete"]
            deleteFolderList = self.get_list(dir=deleteFolder)
        else:
            deleteFolder = self.mkdir("delete")
            deleteFolderList = {}

        while True: # deleted name duplication check
            newname = f"{metadata.name[0]}{self._create_id(5)}_{metadata.name}"
            duplicated = False
            for i in deleteFolderList:
                if newname == i:
                    duplicated = True
                    break
            
            if not duplicated:
                break

        filegid = infiles[metadata.name]
        metadatagid = infiles[f"{metadata.name}.metadata"]
        self.service.files().update(fileId=filegid, body={"name": newname}).execute()
        self.service.files().update(fileId=metadatagid, body={"name": f"{newname}.metadata"}).execute()
        self.service.files().update(fileId=filegid, addParents=deleteFolder, removeParents=parentFolderID).execute()
        self.service.files().update(fileId=metadatagid, addParents=deleteFolder, removeParents=parentFolderID).execute()
        if len(infiles) == 2:
            self.service.files().delete(fileId=parentFolderID).execute()

        return True
        
    def get_list(self, dir: str, mimeType: str = "") -> dict[str, str]:
        """
        Return:
            dict[name, gid]
        """
        query = f"'{dir}' in parents"
        if mimeType: query += f" and mimeType='{mimeType}'"
        results = self._get_files(q=query).execute()
        files = {}
        for i in results["files"]:
            files[i["name"]] = i["id"]
        
        return files

    def is_fid_exists(self, fileid: str) -> bool:
        results = self._get_files(q=f"'{self.root}' in parents and mimeType='application/vnd.google-apps.folder' and name='{fileid}'").execute()
        return len(results["files"]) > 0
    
    def upload(self, metadata: dict, media = None) -> str:
        kwargs = {"body": metadata, "fields": "id"}
        if media: kwargs["media_body"] = media
        file = self.service.files().create(supportsAllDrives=True, **kwargs).execute()
        return file.get('id')

    def mkdir(self, name: str) -> str:
        file_metadata = {
            'name': name,
            'mimeType': 'application/vnd.google-apps.folder',
            'parents': [self.root]
        }
        return self.upload(file_metadata)

    def save(self, file: LimitedStream, filesize: int, filename: str, fileid: str = "") -> Metadata:
        fileid, mimetype, metadataname = self._save(filename, fileid)
        parentFolderID = self.mkdir(fileid)
        metadata = self.make_metadata(filesize, filename, fileid, mimetype)

        file_info = {
            'name': filename,
            'parents': [parentFolderID]
        }
        file_metadata_info = {
            'name': metadataname,
            'parents': [parentFolderID]
        }

        if self.cache:
            metadata = self.cacheControl.save(file, filesize, filename, fileid)
            self.add_cache(fileid, metadata, file_info, file_metadata_info)
        else:
            metadata = self.save_BytesIO(file, metadata, file_info, file_metadata_info)
        
        return metadata

    def save_BytesIO(self, file: LimitedStream, metadata: Metadata, file_info: dict, file_metadata_info: dict) -> Metadata:
        metadataIO = BytesIO(metadata.to_json(private=True).encode("utf-8"))

        # chunksize must be -1 or > 0; guard zero-byte uploads so the
        # UPSMediaIoStreamUpload constructor does not raise InvalidChunkSizeError.
        chunksize = max(int(metadata.size), 1)
        media = self.UPSMediaIoStreamUpload(file, metadata.mimeType, metadata.size, chunksize=chunksize, resumable=True)
        mtdata = self.MediaIoBaseUpload(metadataIO, mimetype="application/json")
        self.upload(file_info, media)
        self.upload(file_metadata_info, mtdata)

        return metadata

    def save_MediaFileUpload(self, file: Path, file_meta: Path, metadata: Metadata, file_info: dict, file_metadata_info: dict):
        media = self.MediaFileUpload(file, mimetype=metadata.mimeType, resumable=True)
        mtdata = self.MediaFileUpload(file_meta, mimetype="application/json")
        self.upload(file_info, media)
        self.upload(file_metadata_info, mtdata)


    def load_metadata(self, fileid: str, filename: str) -> Metadata:
        if self.cache and fileid in self.cachequeueID:
            raw_metadata = self.cachequeueID.get(fileid, {}).get("metadata")
            if isinstance(raw_metadata, Metadata): metadata = raw_metadata
            else: raise TypeError("Invalid metadata type")
        else:
            rootList = self.get_list(dir=self.root, mimeType="application/vnd.google-apps.folder")
            if fileid not in rootList:
                raise FileNotFoundError(f"File id {fileid} or name {filename} not found")

            folderList = self.get_list(dir=rootList[fileid])
            if f"{filename}.metadata" not in folderList: 
                raise FileNotFoundError(f"File id {fileid} or name {filename} not found")
            
            metadata = Metadata()
            metadata.load(dataraw=self.service.files().get_media(fileId=folderList[f"{filename}.metadata"]).execute().decode("utf-8"))
            
            metadata.optional_parentfolderID = rootList[fileid]
            metadata.optional_gfileID = folderList[filename]
        
        if metadata.name != filename:
            raise FileNotFoundError(f"File id {fileid} or name {filename} not found")
        
        return metadata

    def download(self, fileid: str, filename: str) -> Any:
        raise NotImplementedError("storage.download is handled in routers/files.py for FastAPI")


class local(storage):
    def __init__(self, config: dict, configPath: Path):
        super().__init__(config, configPath)
        
        rootstr = config["local"]["root"]
        if rootstr.startswith("./"):
            rootstr = Path(__file__).parent / rootstr[2:]
        elif not rootstr.startswith("/"):
            rootstr = Path(__file__).parent / rootstr
            

        root = Path(rootstr)
        root.mkdir(exist_ok=True, parents=True)
        self.root = root.resolve()
        self.cache = False

    def get_list(self, path: Path, dir: bool = False) -> list[str]:
        if dir:
            return [f.name for f in path.iterdir() if f.is_dir()]
        else:
            return [f.name for f in path.iterdir() if f.is_file()]
    
    def is_fid_exists(self, fileid: str) -> bool:
        return (self.root / fileid).exists()

    def save(self, file: LimitedStream, filesize: int, filename: str, fileid: str = "") -> Metadata:
        # When the caller did not pin a fileid, retry on TOCTOU collisions
        # between is_fid_exists and mkdir. With a CSPRNG and 6+ chars the
        # collision rate is astronomically low, but a defensive retry keeps
        # concurrent uploads from surfacing 500s on the rare race.
        explicit_fileid = bool(fileid)
        for attempt in range(8):
            fileid_candidate, mimetype, metadataname = self._save(filename, fileid)
            folder = self.root / fileid_candidate
            try:
                folder.mkdir(exist_ok=False)
            except FileExistsError:
                if explicit_fileid:
                    raise
                continue

            metadata = self.make_metadata(filesize, filename, fileid_candidate, mimetype)
            self.write_stream(file, folder / filename)
            (folder / metadataname).write_text(metadata.to_json(private=True), encoding="utf-8")
            return metadata

        raise RuntimeError("Failed to allocate a unique fileid after retries")
    
    def remove(self, fileid: str, filename: str, deletepass: str, force: bool = False, permanently: bool = False):
        try:
            metadata = self.load_metadata(fileid, filename)
        except FileNotFoundError:
            return False
        
        if metadata.delete != deletepass and not force:
            return False
        
        if permanently:
            return self._remove_permanent(fileid, filename)
        
        deleteFolder = self.root / "delete"
        deleteFolder.mkdir(exist_ok=True)

        while True: # deleted name duplication check
            newname = f"{metadata.name[0]}{self._create_id(5)}_{metadata.name}"
            if not (deleteFolder / newname).exists():
                break

        (self.root / fileid / filename).rename(deleteFolder / newname)
        (self.root / fileid / f"{filename}.metadata").rename(deleteFolder / f"{newname}.metadata")

        return True

    def _remove_permanent(self, fileid: str, filename: str) -> bool:
        try:
            metadata = self.load_metadata(fileid, filename)
        except FileNotFoundError:
            return False

        # Move the entire folder to a tombstone path BEFORE unlinking. On
        # POSIX, ``Path.rename`` is atomic within the same filesystem, so
        # in-flight readers (FastAPI's FileResponse opens the FD lazily
        # inside its handler) keep their already-opened descriptors valid
        # even after we delete the renamed copies — and any new lookup
        # against ``self.root / fileid`` cleanly 404s the moment the
        # rename returns.
        folder = self.root / fileid
        if not folder.is_dir():
            return False

        tombstone_root = self.root / ".tombstones"
        tombstone_root.mkdir(exist_ok=True)
        tombstone = tombstone_root / f"{fileid}-{self._create_id(8)}"
        try:
            folder.rename(tombstone)
        except FileNotFoundError:
            return False

        for entry in tombstone.iterdir():
            try:
                entry.unlink()
            except FileNotFoundError:
                pass
        try:
            tombstone.rmdir()
        except OSError:
            pass

        return True
    
    def load_metadata(self, fileid: str, filename: str) -> Metadata:
        folderPath = self.root / fileid
        if not folderPath.exists(): 
            raise FileNotFoundError(f"File id {fileid} or name {filename} not found")
        
        metadataPath = (folderPath / f"{filename}.metadata")
        if not metadataPath.exists(): 
            raise FileNotFoundError(f"File id {fileid} or name {filename} not found")
        
        metadata = Metadata()
        metadata.load(dataPath=metadataPath)

        if metadata.name != filename:
            raise FileNotFoundError(f"File id {fileid} or name {filename} not found")
        
        return metadata
    
    def download(self, fileid: str, filename: str) -> Any:
        raise NotImplementedError("storage.download is handled in routers/files.py for FastAPI")

    def get_file_path(self, fileid: str, filename: str, metadata: bool = False) -> Path:
        self.load_metadata(fileid, filename)

        if metadata:
            return self.root / fileid / f"{filename}.metadata"
        else:
            return self.root / fileid / filename
