##  Production DB specs

The idea is to include a vectorial db like pinecone, pgvector,etc to store monitor queries, to reduce o(n) complexity

### expected output

a new class that implements a MonitorDB

### specs and discussions

- A mic of DBs must be implemnted, the log() method sould probably call  do the retrieval and once the vector was retireved log its metadata
- the real question here is: 
1- how to implement a foreign key to the vectorial base in the most optmized way? should vector be hashed??
2- should new queries be stored or just a representative vec?