from __future__ import annotations

import functools
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Callable, Optional

from .cache.cache import SemanticCache
from .models import RetrievalHandle
from .monitor.monitor import Monitor

if TYPE_CHECKING:
    from .cache.auto_promoter import AutoCachePromoter

logger = logging.getLogger(__name__)


class Middleware:
    def __init__(
        self,
        monitor: Optional[Monitor] = None,
        cache: Optional[SemanticCache] = None,
        embedder: Optional[Callable] = None,
        monitor_workers: int = 2,
        auto_promoter: Optional["AutoCachePromoter"] = None,
    ):
        self.monitor = monitor
        self.cache = cache
        self.embedder = embedder
        self.auto_promoter = auto_promoter
        self._executor = ThreadPoolExecutor(max_workers=monitor_workers) if monitor else None

    def track(self, fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(query: str, *args, **kwargs):
            monitor_kwargs = kwargs.pop("_monitor_kwargs", {})
            return self._execute(query, fn, *args, monitor_kwargs=monitor_kwargs, **kwargs)
        return wrapper

    def track_with_handle(self, fn: Callable) -> Callable:
        """
        Like track, but returns a RetrievalHandle instead of the plain answer.

        The handle carries cluster_id (always set) and event_id (set only when
        the underlying store keeps per-event history) so the caller can wire
        the answer to a feedback UI and later call monitor.record_feedback.

        Requires both a monitor and an embedder. Clustering runs synchronously
        so the IDs are populated before this returns; the event row is still
        written asynchronously.
        """
        if self.monitor is None:
            raise ValueError("track_with_handle requires a monitor")
        if self.embedder is None:
            raise ValueError("track_with_handle requires an embedder")

        @functools.wraps(fn)
        def wrapper(query: str, *args, **kwargs) -> RetrievalHandle:
            monitor_kwargs = kwargs.pop("_monitor_kwargs", {})
            return self._execute_with_handle(
                query, fn, *args, monitor_kwargs=monitor_kwargs, **kwargs
            )
        return wrapper

    def _execute(self, query: str, fn: Callable, *args, monitor_kwargs: dict = None, **kwargs):
        """Pipeline: cache → fn → monitor. Add future steps here."""
        monitor_kwargs = monitor_kwargs or {}
        vec = self.embedder(query) if self.embedder else None

        cached = self.cache.get(query, vec=vec) if self.cache else None
        if cached is not None:
            self._log_monitor(query, latency_ms=0.0, cache_hit=True, vec=vec, **monitor_kwargs)
            return cached

        start = time.time()
        result = fn(query, *args, **kwargs)

        self._log_monitor(query, latency_ms=Monitor.calculate_timing(start), vec=vec, **monitor_kwargs)
        return result

    def _execute_with_handle(
        self,
        query: str,
        fn: Callable,
        *args,
        monitor_kwargs: dict = None,
        **kwargs,
    ) -> RetrievalHandle:
        monitor_kwargs = monitor_kwargs or {}

        # Sync: cluster the query so cluster_id (and event_id, if applicable)
        # are known before we return.
        cluster_id, event_id, vec = self.monitor.assign_cluster(query)

        cached = self.cache.get(query, vec=vec) if self.cache else None
        if cached is not None:
            self._log_monitor(
                query,
                latency_ms=0.0,
                cache_hit=True,
                vec=vec,
                cluster_id=cluster_id,
                event_id=event_id,
                **monitor_kwargs,
            )
            return RetrievalHandle(answer=cached, cluster_id=cluster_id, event_id=event_id)

        start = time.time()
        answer = fn(query, *args, **kwargs)

        handle = RetrievalHandle(answer=answer, cluster_id=cluster_id, event_id=event_id)

        self._log_monitor(
            query,
            latency_ms=Monitor.calculate_timing(start),
            vec=vec,
            cluster_id=cluster_id,
            event_id=event_id,
            **monitor_kwargs,
        )
        if self.auto_promoter is not None:
            self._executor.submit(self._safe_on_answer, handle, answer)
        return handle

    def _safe_on_answer(self, handle: RetrievalHandle, response) -> None:
        try:
            self.auto_promoter.on_answer(handle, response)
        except Exception:
            logger.exception("AutoCachePromoter.on_answer failed for cluster %r", handle.cluster_id)

    def _log_monitor(self, query: str, **kwargs) -> None:
        if self.monitor is None:
            return
        self._executor.submit(self._safe_log, query, **kwargs)

    def _safe_log(self, query: str, **kwargs) -> None:
        try:
            self.monitor.log(query, **kwargs)
        except Exception:
            logger.exception("Monitor.log() failed for query %r", query)

    def shutdown(self, wait: bool = True) -> None:
        """Shut down the monitor thread pool. Call on app exit to flush pending logs."""
        if self._executor:
            self._executor.shutdown(wait=wait)
