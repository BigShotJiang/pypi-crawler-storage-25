# Automatic Cache Promotion — v1 Design

Once a cluster of similar queries gets enough volume *and* enough positive
feedback, the answer for that cluster is promoted into the semantic cache
automatically. Future similar queries are served from cache without hitting
the LLM. If the cluster's quality later drops, the cache entry is evicted.

## Design philosophy

- **Opt-in, fully off by default.** Users who don't want auto-cache see no
  storage overhead, no extra columns being written, no behavior change. The
  feature activates only when an `AutoCachePromoter` is wired in.
- **Library, not magic.** All thresholds and behaviors are explicit
  constructor parameters. No hidden heuristics.
- **Reuses existing stores.** No new SQL tables. Two small column additions
  (`clusters.latest_response`, `cache.cluster_id`) — both nullable, both
  idempotent migrations.
- **One component owns the orchestration.** A new `AutoCachePromoter`
  encapsulates the logic; `MonitorStore`, `CacheStore`, and `Middleware`
  stay narrowly responsible.
- **Humans win.** Cache entries set manually (`approved_by="human"`) are
  never auto-evicted. Auto entries (`approved_by="auto"`) are the only ones
  the promoter touches.
- **Durable, not in-memory.** Candidate responses persist in the DB so
  promotion survives process restarts and works across multi-worker
  deployments.

---

## Public API

### `AutoCachePromoter`

```python
from raggit.middleware import (
    AutoCachePromoter, Middleware, Monitor, SemanticCache,
    SQLiteCacheStore, SQLiteMonitorStore, SQLiteEventFeedbackStore,
)

db = ".raggit/middleware.db"

cache = SemanticCache(SQLiteCacheStore(db), embedder=embed, threshold=0.95)
store = SQLiteMonitorStore(db)
feedback_store = SQLiteEventFeedbackStore(db)

promoter = AutoCachePromoter(
    cache=cache,
    store=store,
    feedback_store=feedback_store,
    min_count=10,                # required: at least 10 events in cluster
    min_acceptance=0.8,          # optional: ≥80% thumb-up rate
    min_score=None,              # optional: average score floor (None = ignore)
)

monitor = Monitor(
    embedder=embed,
    store=store,
    feedback_store=feedback_store,
    auto_promoter=promoter,      # NEW: monitor calls promoter on feedback
)

mw = Middleware(
    monitor=monitor,
    cache=cache,
    embedder=embed,
    auto_promoter=promoter,      # NEW: middleware calls promoter on answer
)

@mw.track_with_handle
def retrieve(query: str) -> str:
    return my_index.search(query)[0]
```

Trigger semantics — all gates are AND, `None` means "ignore this dimension":

```python
AutoCachePromoter(cache, store, feedback_store, min_count=20)
# 20 events; no quality gate. Pure popularity.

AutoCachePromoter(cache, store, feedback_store, min_count=10, min_acceptance=0.9)
# 10 events AND 90%+ acceptance. Default flavor.

AutoCachePromoter(cache, store, feedback_store, min_count=5, min_score=0.8)
# 5 events AND average score ≥0.8. For rating-only UIs (no thumb data).
```

---

## Architecture

Three components touch this feature, each with a narrow role.

```
┌──────────────────┐
│   Middleware     │  on_answer → promoter.on_answer(handle, response)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐  on_feedback → promoter.on_feedback(handle)
│     Monitor      │
└────────┬─────────┘
         │
         ▼
┌─────────────────────────────────────────────────────┐
│             AutoCachePromoter                       │
│                                                     │
│  on_answer(handle, response):                       │
│    store.update_latest_response(cluster_id, resp)   │
│    [if count-only mode: check eligibility]          │
│                                                     │
│  on_feedback(handle):                               │
│    eligible = self._is_eligible(handle.cluster_id)  │
│    if eligible and not cached: promote              │
│    if cached_auto and not eligible: demote          │
└─────────────────────────────────────────────────────┘
```

### Why both Middleware and Monitor hold a reference

- **Middleware** is where the answer text is produced (in `_execute_with_handle`).
  It's the only place that has the response *and* the handle. So `on_answer`
  must fire from middleware.
- **Monitor** is where feedback is recorded (`monitor.record_feedback`). The
  user's HTTP route calls monitor directly, not middleware. So `on_feedback`
  must fire from monitor.

The promoter is passed to both — it's the same `Optional[AutoCachePromoter]`
reference, conceptually. No circular dependency: the promoter takes `cache`,
`store`, `feedback_store` (not `monitor` or `middleware`), so it's
constructible first and injected into both.

---

## Hook flow

### Path 1 — Answer produced (track_with_handle)

```
1. mw.retrieve("query") called
2. monitor.assign_cluster(query) → (cluster_id, event_id, vec) [sync]
3. fn(query) → response
4. async: monitor.log(...) writes event row
5. async: promoter.on_answer(handle, response):
     - store.update_latest_response(cluster_id, response)
     - if min_acceptance is None and min_score is None:  # count-only
         maybe promote based on count alone
6. return RetrievalHandle(answer=response, cluster_id=..., event_id=...)
```

### Path 2 — Feedback recorded

```
1. monitor.record_feedback(handle, accepted=True, score=0.9)
2. validation passes ("at least one of accepted/score")
3. feedback_store.record_feedback(handle, ...)
4. monitor calls promoter.on_feedback(handle) [sync, but cheap]:
     - read cluster.count, cluster.latest_response from store
     - read feedback aggregates for cluster_id from feedback_store
     - check eligibility against thresholds
     - branch:
         - eligible AND not cached → cache.set_auto(cluster_id, vec, response)
         - cached as auto AND no longer eligible → cache.delete_by_cluster(cluster_id)
         - cached as human → leave alone
         - else → no-op
```

`on_feedback` runs synchronously inside `record_feedback`. It's a few SQL
reads + at most one cache write — much faster than the feedback insert
itself. No need for the executor here.

---

## Storage additions

Two small idempotent column adds. No new tables.

### `clusters.latest_response`

Holds the most recent answer produced for each cluster — the candidate that
gets promoted to cache. Overwritten on every new answer (last-write-wins).

```sql
ALTER TABLE clusters ADD COLUMN latest_response TEXT;
```

Always added (negligible cost when NULL). Only populated when an
`AutoCachePromoter` is wired in via Middleware. Users without the promoter
have an unused NULL column; users with privacy concerns who don't want
responses persisted simply don't wire the promoter.

### `cache.cluster_id`

Lets the promoter find auto-promoted cache entries for demotion. NULL for
human-set entries, populated for auto-promoted ones. Indexed for O(log n)
lookup on demotion.

```sql
ALTER TABLE cache ADD COLUMN cluster_id TEXT;
CREATE INDEX IF NOT EXISTS idx_cache_cluster_id ON cache(cluster_id);
```

Both migrations check `PRAGMA table_info` first — safe to re-run on existing
databases.

---

## ABC and store additions

### `MonitorStore`

```python
def update_latest_response(self, cluster_id: str, response: str) -> None:
    """Store the latest answer produced for this cluster, overwriting any
    previous one. Used by AutoCachePromoter to track the candidate response
    for auto-promotion. Default raises NotImplementedError."""

def get_cluster(self, cluster_id: str) -> Optional[Cluster]:
    """Fetch a single cluster by id. Returns None if not found.
    Default raises NotImplementedError."""
```

`SQLiteMonitorStore` and `SQLiteClusterStore` both implement these. The
column add for `latest_response` happens in their `__init__` migrations.
`Cluster` model gains a `latest_response: Optional[str] = None` field.

### `FeedbackStore`

```python
def get_feedback_summary(self, cluster_id: str) -> Optional[dict]:
    """Return per-cluster feedback aggregates:
        {
            "feedback_count": int,
            "accepted_count": int,
            "acceptance_rate": Optional[float],  # None if no thumb feedback
            "score_count": int,
            "avg_score": Optional[float],         # None if no score feedback
        }
    Returns None if the cluster has no feedback at all.
    Default raises NotImplementedError."""
```

Both `SQLiteEventFeedbackStore` and `SQLiteClusterFeedbackStore` implement
this. The two read paths look different but return the same shape:

| Store | SQL underneath |
|---|---|
| `SQLiteEventFeedbackStore` | `SELECT COUNT(*), SUM(accepted=1), SUM(accepted IS NOT NULL), COUNT(score), AVG(score) FROM feedback WHERE event_id IN (SELECT event_id FROM events WHERE cluster_id = ?)` |
| `SQLiteClusterFeedbackStore` | `SELECT feedback_count, accepted_count, score_count, score_sum FROM clusters WHERE cluster_id = ?` then compute rate / avg in Python |

### `CacheStore`

```python
def set(
    self,
    vec: List[float],
    response: str,
    approved_by: str = "llm",
    cluster_id: Optional[str] = None,   # NEW
) -> None:
    """If cluster_id is provided and a row with the same cluster_id and
    approved_by='auto' already exists, the call is idempotent (no insert,
    no error). This is how the promoter avoids double-promotion races."""

def delete_by_cluster(self, cluster_id: str) -> None:
    """Delete cache entries with this cluster_id and approved_by='auto'.
    Human-set entries (any other approved_by) are never deleted by this.
    Default raises NotImplementedError; SQLiteCacheStore implements it."""
```

`SemanticCache` gains thin wrappers `set_auto(...)` and `delete_auto(...)`
that internally pass the cluster_id and the appropriate `approved_by`.

### `Monitor`

```python
def __init__(
    self,
    embedder: Callable[[str], List[float]],
    store: Optional[MonitorStore] = None,
    cluster_threshold: float = 0.92,
    feedback_store: Optional[FeedbackStore] = None,
    auto_promoter: Optional["AutoCachePromoter"] = None,    # NEW
):
    ...

def record_feedback(self, handle, accepted=None, score=None, comment=None):
    # ... existing validation + feedback_store call ...
    if self.auto_promoter is not None:
        self.auto_promoter.on_feedback(handle)
```

### `Middleware`

```python
def __init__(
    self,
    monitor: Optional[Monitor] = None,
    cache: Optional[SemanticCache] = None,
    embedder: Optional[Callable] = None,
    monitor_workers: int = 2,
    auto_promoter: Optional["AutoCachePromoter"] = None,    # NEW
):
    ...

def _execute_with_handle(self, query, fn, ...):
    # ... existing assign_cluster, cache.get, fn() ...
    self._log_monitor(query, ..., cluster_id=cluster_id, event_id=event_id)
    if self.auto_promoter is not None:
        self._executor.submit(
            self._safe_promote_answer, handle, answer
        )
    return RetrievalHandle(...)
```

---

## Promotion, demotion, idempotency

### Eligibility

```python
def _is_eligible(self, cluster_id: str) -> bool:
    cluster = self.store.get_cluster(cluster_id)
    if cluster is None or cluster.count < self.min_count:
        return False

    if self.min_acceptance is None and self.min_score is None:
        return True  # count-only mode

    summary = self.feedback_store.get_feedback_summary(cluster_id)
    if summary is None:
        return False  # quality gate set but no feedback yet

    if self.min_acceptance is not None:
        rate = summary.get("acceptance_rate")
        if rate is None or rate < self.min_acceptance:
            return False

    if self.min_score is not None:
        avg = summary.get("avg_score")
        if avg is None or avg < self.min_score:
            return False

    return True
```

### Promotion

```python
def _promote(self, cluster: Cluster) -> None:
    if cluster.latest_response is None:
        return  # nothing to cache yet
    self.cache.set_auto(
        vec=cluster.representative_vec,
        response=cluster.latest_response,
        cluster_id=cluster.cluster_id,
    )
```

`set_auto` is idempotent. If a row with this `cluster_id` and
`approved_by='auto'` already exists, the call is a no-op — no double-insert
on concurrent feedback events crossing threshold simultaneously.

### Demotion

```python
def _is_currently_auto_cached(self, cluster_id: str) -> bool:
    """Cheap check via cache store."""
    return self.cache.has_auto_entry(cluster_id)

def on_feedback(self, handle: RetrievalHandle) -> None:
    cluster_id = handle.cluster_id
    eligible = self._is_eligible(cluster_id)
    cached = self._is_currently_auto_cached(cluster_id)

    if eligible and not cached:
        cluster = self.store.get_cluster(cluster_id)
        self._promote(cluster)
    elif cached and not eligible:
        self.cache.delete_auto(cluster_id)
    # else: no state change
```

Demotion only touches `approved_by='auto'` entries. Human-set entries with
the same `cluster_id` (unlikely but possible) are never deleted.

---

## What does NOT change

- `@mw.track` (the original API). Doesn't return a handle, can't drive
  auto-promotion. Use `@mw.track_with_handle` for this feature.
- `monitor.log()` signature. Still doesn't carry the response text — only
  the handle path does.
- `SemanticCache.get()` semantics. Auto-promoted entries are matched by
  vector similarity exactly like any other entry — the `cluster_id` is
  bookkeeping for the promoter, not a query key.
- Existing users without an `AutoCachePromoter`. Zero behavior change. Two
  unused NULL columns in their schemas, no code paths exercised.

---

## Out of scope for v1 (deferred)

| Feature | Why deferred |
|---|---|
| Multiple candidate responses per cluster (best-of-N) | One latest_response is the simplest model. If users want best-of, they can capture handles + responses themselves and call `cache.set_auto` directly. |
| TTL on auto entries (expire after N days) | Cache eviction beyond demotion is its own design space. Not v1. |
| Promotion based on time decay (recent feedback weighted higher) | Equal weighting is the simple default. |
| Auto-promotion for ClusterStore-only setups (no events) | Works in the design — `SQLiteClusterFeedbackStore` already has cluster-level aggregates, so `get_feedback_summary` is trivially supported. Will be tested but not the primary flow. |
| Audit trail of promotions/demotions | A `cache_history` table could log every promote/demote. Not v1. |
| Notification hook (`on_promoted`, `on_demoted` callbacks for the user) | Easy to add later via a callback parameter. Not v1. |
| Multi-cluster cache entries (one cache row matches several clusters) | Current model is 1:1; multi-mapping would complicate demotion. |

---

## Privacy

The auto-cache feature **does** persist response text in the DB
(`clusters.latest_response`). Users with sensitive data should know:

- Without an `AutoCachePromoter` wired in, `latest_response` is never written
  (the column exists but stays NULL).
- With the promoter wired in, every track_with_handle answer is persisted
  into the `clusters` table. Users who don't want this should not use the
  promoter — there's no half-on mode.
- The `cache` table also persists responses (existing behavior — that's what
  caches do). Auto-promoted entries are not different in storage from
  human-set ones except for the `approved_by` and `cluster_id` columns.

This is documented in the README, not gated behind another flag.

---

## Implementation checklist

- [ ] `MonitorStore.update_latest_response(cluster_id, response)` —
      abstract-ish (NotImplementedError default).
- [ ] `MonitorStore.get_cluster(cluster_id)` — same.
- [ ] `Cluster` model gains `latest_response: Optional[str] = None`.
- [ ] `SQLiteMonitorStore` + `SQLiteClusterStore` `__init__` migrations:
      `ALTER TABLE clusters ADD COLUMN latest_response TEXT` (idempotent).
- [ ] `SQLiteMonitorStore` + `SQLiteClusterStore` implement the two new
      methods.
- [ ] `FeedbackStore.get_feedback_summary(cluster_id)` — abstract-ish.
- [ ] `SQLiteEventFeedbackStore` + `SQLiteClusterFeedbackStore` implement it.
- [ ] `CacheStore.set` gains `cluster_id` kwarg + idempotent semantics.
- [ ] `CacheStore.delete_by_cluster(cluster_id)` — new method.
- [ ] `CacheStore.has_auto_entry(cluster_id)` — new method (used for
      demotion check).
- [ ] `SQLiteCacheStore` `__init__` migration:
      `ALTER TABLE cache ADD COLUMN cluster_id TEXT` + index.
- [ ] `SemanticCache.set_auto / delete_auto / has_auto_entry` thin wrappers.
- [ ] New `AutoCachePromoter` class in
      `raggit/middleware/cache/auto_promoter.py` with `on_answer`,
      `on_feedback`, internal `_is_eligible`, `_promote`, `_demote`.
- [ ] `Monitor.__init__` accepts `auto_promoter`. `Monitor.record_feedback`
      calls `auto_promoter.on_feedback(handle)` after feedback persistence.
- [ ] `Middleware.__init__` accepts `auto_promoter`.
      `Middleware._execute_with_handle` submits `promoter.on_answer` to the
      executor after the async log.
- [ ] Tests:
  - threshold gates (count-only, count+acceptance, count+score, all three)
  - promotion happens once and is idempotent (two concurrent events → one row)
  - demotion only touches auto entries; human entries survive
  - promoter wires into both event-flavored and cluster-flavored pairings
  - cache hit on auto-promoted vector returns the right response
  - latest_response stays NULL when no promoter is wired (no schema noise)
- [ ] Update README — new "Automatic cache promotion" section with the full
      wiring example.
- [ ] Roadmap — add a checkbox.

---

## Open questions still worth thinking about

1. **Should promotion be exposed as a hook for users to override?** E.g.,
   pass a `should_promote: Callable[[Cluster, FeedbackSummary], bool]`
   instead of three knobs. More flexible but more surface. Probably v2.
2. **Should we re-score on every event (not just feedback)?** Today the
   plan is: count-only mode checks on `on_answer`; quality-gated mode
   checks on `on_feedback`. Hybrid (every event re-checks if quality gate
   is set) wastes cycles but catches "new event tipped count past
   threshold" cases. The current plan misses this — when an answer event
   bumps count to N and existing acceptance was already X%, the cluster
   becomes eligible but `on_feedback` doesn't fire (no new feedback).
   Worth resolving before implementation.
3. **What if the same cluster has multiple very different `latest_response`
   values over time?** Cache shows the latest one; users may have expected
   the "most-accepted" one. Not really solvable without per-response
   feedback (we have per-event feedback, but the per-event response isn't
   stored). v2 territory.
