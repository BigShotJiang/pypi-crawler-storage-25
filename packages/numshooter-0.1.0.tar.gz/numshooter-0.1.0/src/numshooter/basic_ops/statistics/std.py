import math
from .variance import variance

def standard_deviation(*numbers):
    if not numbers:
        return 0

    return math.sqrt(variance(*numbers))


std = standard_deviation
