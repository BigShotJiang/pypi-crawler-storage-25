def min_value(*numbers):
    return min(numbers) if numbers else 0


def max_value(*numbers):
    return max(numbers) if numbers else 0
