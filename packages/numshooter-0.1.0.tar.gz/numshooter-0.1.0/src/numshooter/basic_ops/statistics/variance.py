from .mean import mean

def variance(*numbers):
    if not numbers:
        return 0

    m = mean(*numbers)

    return sum((x - m) ** 2 for x in numbers) / len(numbers)
