def mode(*numbers):
    if not numbers:
        return 0

    freq = {}

    for n in numbers:
        freq[n] = freq.get(n, 0) + 1

    max_freq = max(freq.values())

    modes = [k for k, v in freq.items() if v == max_freq]

    return modes if len(modes) > 1 else modes[0]
