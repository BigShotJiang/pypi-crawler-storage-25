from .mean import mean, avg
from .median import median, med
from .variance import variance
from .std import standard_deviation, std
from .mode import mode
from .minmax import min_value, max_value
