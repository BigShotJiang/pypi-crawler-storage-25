from .statistics import *

def add(*numbers):
    if not numbers:
        return 0

    result = numbers[0]
    for n in numbers[1:]:
        result += n
    return result


def sub(*numbers):
    if not numbers:
        return 0

    result = numbers[0]
    for n in numbers[1:]:
        result -= n
    return result


def mul(*numbers):
    if not numbers:
        return 0

    result = numbers[0]
    for n in numbers[1:]:
        result *= n
    return result


def div(*numbers):
    if not numbers:
        return 0

    result = numbers[0]
    for n in numbers[1:]:
        if n == 0:
            raise ZeroDivisionError("division by zero")
        result /= n

    return result
