"""Pydantic response models for the Mipiti API.

All models use ``extra="allow"`` so new API fields pass through automatically
as attributes — no client update needed when the backend adds fields.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict


# ------------------------------------------------------------------
# Base
# ------------------------------------------------------------------


class _Base(BaseModel):
    model_config = ConfigDict(extra="allow")


# ------------------------------------------------------------------
# Enums
# ------------------------------------------------------------------


class SecurityProperty(str, Enum):
    C = "C"
    I = "I"  # noqa: E741
    A = "A"
    U = "U"


# ------------------------------------------------------------------
# Domain models
# ------------------------------------------------------------------


class Asset(_Base):
    id: str
    name: str
    description: str = ""
    security_properties: list[SecurityProperty] = []
    impact: str = "M"
    notes: str = ""
    # Soft-delete lifecycle. A deleted asset keeps its ID forever
    # (never reused); its linked (asset × attacker) control objectives
    # tombstone, and controls mapped to those COs surface as orphaned.
    # Restore via POST /assets/{id}/restore (MCP: restore_asset tool).
    deleted: bool = False
    deleted_at: str = ""
    deleted_by: str = ""


class Attacker(_Base):
    id: str
    capability: str
    position: str = ""
    archetype: str = ""
    likelihood: str = "M"
    # Same soft-delete lifecycle as Asset.
    deleted: bool = False
    deleted_at: str = ""
    deleted_by: str = ""


class TrustBoundary(_Base):
    id: str
    description: str
    crosses: list[str] = []


class ControlObjective(_Base):
    id: str
    asset_id: str
    security_property: SecurityProperty | None = None
    security_properties: list[SecurityProperty] = []
    attacker_id: str
    statement: str
    risk_tier: str = "medium"
    # Tombstone: a CO whose (asset, attacker) pair was removed in a
    # later version. The CO ID stays allocated forever (never reused)
    # so controls referring to it surface as "orphaned" rather than
    # silently rebinding to a different pair. Filter removed=True out
    # of live-CO views (coverage math, LLM prompts, etc.).
    removed: bool = False
    removed_at: str = ""
    removed_in_version: int = 0


class Assumption(_Base):
    id: str
    description: str
    status: str = "active"


class ControlEvidence(_Base):
    type: str = "code"
    label: str = ""
    url: str = ""
    collected_at: str = ""
    collected_by: str = ""


class Control(_Base):
    id: str
    control_objective_ids: list[str] = []
    description: str
    status: str = "not_implemented"
    implementation_notes: str = ""
    evidence: list[ControlEvidence] = []
    source: str = ""
    source_label: str = ""
    framework_refs: list[str] = []
    is_verified: bool = False
    verification_status: str = "pending"
    # Derived at read time: True when every mapped CO is tombstoned.
    # Orphaned controls are hidden from the default get_controls
    # listing — pass include_orphaned=True to see them. Remap to
    # live COs via remap_control, or soft-delete explicitly.
    orphaned: bool = False


class ThreatModel(_Base):
    id: str = ""
    feature_description: str = ""
    title: str = ""
    version: int = 1
    created_at: str = ""
    trust_boundaries: list[TrustBoundary] = []
    assets: list[Asset] = []
    attackers: list[Attacker] = []
    control_objectives: list[ControlObjective] = []
    assumptions: list[Assumption] = []


class ModelSummary(_Base):
    id: str
    title: str = ""
    feature_description: str = ""
    created_at: str = ""
    version: int = 1


# ------------------------------------------------------------------
# SSE streaming results
# ------------------------------------------------------------------


class GenerateResult(_Base):
    """Result from generate/refine SSE stream (``result`` event)."""
    threat_model: ThreatModel = ThreatModel()
    model_id: str = ""
    version: int = 1
    markdown: str = ""
    csv: str = ""
    # Refine-path semantic guard surfaces entries here when the LLM
    # proposed a rewrite that would have semantically replaced an
    # existing asset/attacker under its stable ID. Each entry:
    #   {"kind": "asset"|"attacker", "id": "A-N"|"T-N",
    #    "classification": "replace"|"ambiguous"|"unavailable",
    #    "reason": "...", "per_field": {...}}
    # The corresponding entity's identity fields in ``threat_model``
    # were reverted to pre-refine values, so the LLM's proposed
    # rewrite did not apply. Agents surfacing a refine result to the
    # operator should check this array and present each rejection.
    semantic_rejections: list[dict[str, Any]] = []


class ChatResponse(_Base):
    """Result from query/general SSE stream (``chat_response`` event)."""
    content: str = ""


# ------------------------------------------------------------------
# Controls responses
# ------------------------------------------------------------------


class ControlsResponse(_Base):
    controls: list[Control] = []
    model_id: str = ""
    model_version: int = 0
    total: int = 0
    returned: int = 0


class EvidenceActionResult(_Base):
    control_id: str = ""
    evidence_count: int = 0


class ImportConfirmResult(_Base):
    imported: int = 0
    controls: list[Control] = []


class DeleteControlResult(_Base):
    deleted: bool = False
    control_id: str = ""


class GapAnalysisResult(_Base):
    suggestions: list[dict[str, Any]] = []
    model_id: str = ""


class ScanPromptResult(_Base):
    control_id: str = ""
    prompt: str = ""
    message: str = ""


class ControlObjectivesResponse(_Base):
    model_id: str = ""
    version: int = 1
    total: int = 0
    returned: int = 0
    control_objectives: list[dict[str, Any]] = []


# ------------------------------------------------------------------
# Assurance
# ------------------------------------------------------------------


class AssessmentResult(_Base):
    """Deterministic assurance assessment result."""
    pass


class ReviewQueueResponse(_Base):
    """Stale controls not reviewed in 90+ days."""
    items: list[dict[str, Any]] = []


# ------------------------------------------------------------------
# Compliance
# ------------------------------------------------------------------


class ComplianceFramework(_Base):
    id: str
    name: str = ""
    version: str = ""
    description: str = ""
    source: str = ""
    total_requirements: int = 0


class SelectFrameworksResult(_Base):
    model_id: str = ""
    selected_frameworks: list[str] = []
    added: list[str] = []
    framework_count: int = 0


class ComplianceReport(_Base):
    framework_id: str = ""
    framework_name: str = ""
    coverage: int = 0


class AutoMapResult(_Base):
    mappings_created: int = 0
    controls_mapped: int = 0
    controls_total: int = 0


class RemediationSuggestions(_Base):
    suggestions: list[dict[str, Any]] = []
    gap_count: int = 0


class RemediationApplyResult(_Base):
    assets_added: int = 0
    attackers_added: int = 0
    # Remediation can also reanimate soft-deleted entities whose
    # identity matches a proposal (via the restore-candidate LLM gate).
    # Callers that report "what changed" to the operator should
    # include restored counts alongside added counts.
    assets_restored: int = 0
    attackers_restored: int = 0
    restored_asset_ids: list[str] = []
    restored_attacker_ids: list[str] = []
    # Per-proposal skip reasons — populated for ``similar`` verdicts and
    # fail-closed LLM failures. Each entry: {"kind": "asset"|"attacker",
    # "name"|"capability": "...", "reason": "..."}.
    skipped: list[dict] = []
    exclusions_created: int = 0
    controls_generated: int = 0
    mappings_created: int = 0
    version: int = 0


# ------------------------------------------------------------------
# Workspaces & Systems
# ------------------------------------------------------------------


class Workspace(_Base):
    id: str = ""
    name: str = ""
    description: str = ""
    is_personal: bool = False


class System(_Base):
    id: str = ""
    workspace_id: str = ""
    name: str = ""
    description: str = ""
    model_count: int = 0


class SystemSelectFrameworksResult(_Base):
    system_id: str = ""
    selected_frameworks: list[str] = []
    model_count: int = 0
    propagated_to_models: int = 0


# ------------------------------------------------------------------
# Assertions & Verification
# ------------------------------------------------------------------


class EvidenceAssertion(_Base):
    id: str = ""
    control_id: str = ""
    model_id: str = ""
    type: str = ""
    params: dict[str, Any] = {}
    description: str = ""
    tier1_status: str = "pending"
    tier2_status: str = "pending"


class SubmitAssertionsResult(_Base):
    assertions: list[EvidenceAssertion] = []
    coherence_warnings: list[dict[str, Any]] = []


class VerificationReport(_Base):
    model_id: str = ""
    version: int = 0
    total_assertions: int = 0
    tier1: dict[str, int] = {}
    tier2: dict[str, int] = {}
    controls: dict[str, dict[str, int]] = {}


# ------------------------------------------------------------------
# Findings
# ------------------------------------------------------------------


class Finding(_Base):
    id: str = ""
    control_id: str = ""
    model_id: str = ""
    title: str = ""
    description: str = ""
    severity: str = "medium"
    status: str = "discovered"


# ------------------------------------------------------------------
# Generic action results
# ------------------------------------------------------------------


class RenameResult(_Base):
    id: str = ""
    title: str = ""


class OkResult(_Base):
    ok: bool = False
