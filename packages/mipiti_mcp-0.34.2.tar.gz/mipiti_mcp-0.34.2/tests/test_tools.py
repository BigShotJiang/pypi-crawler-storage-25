"""Unit tests for MCP tool implementations."""

import json
from unittest.mock import AsyncMock, patch

import pytest
from fastmcp.exceptions import ToolError

from mipiti_mcp import server
from mipiti_mcp.types import (
    ChatResponse,
    Control,
    ControlsResponse,
    GenerateResult,
    ModelSummary,
    RenameResult,
    ThreatModel,
)
from mipiti_mcp.server import (
    add_asset,
    add_attacker,
    add_evidence,
    add_model_to_system,
    assess_model,
    auto_remediate,
    auto_map_controls,
    check_control_gaps,
    create_system,
    delete_assertion,
    delete_control,
    delete_threat_model,
    get_control_assumption_groups,
    set_control_assumption_groups,
    edit_asset,
    edit_attacker,
    export_threat_model,
    export_threat_model_archive,
    generate_threat_model,
    import_threat_model_archive,
    get_compliance_report,
    get_control_objectives,
    get_controls,
    get_review_queue,
    get_scan_prompt,
    get_system,
    get_system_compliance_report,
    get_threat_model,
    get_verification_report,
    import_controls,
    list_assertions,
    list_compliance_frameworks,
    list_findings,
    list_systems,
    list_threat_models,
    list_workspaces,
    map_control_to_requirement,
    query_threat_model,
    refine_threat_model,
    regenerate_controls,
    remove_asset,
    remove_attacker,
    remove_evidence,
    rename_threat_model,
    select_compliance_frameworks,
    select_system_compliance_frameworks,
    submit_assertions,
    submit_findings,
    refine_control,
    remap_control,
    restore_asset,
    restore_attacker,
    update_control_status,
    update_finding,
    model_coherence_report,
    get_reachability_verdicts,
    get_control_objective,
    get_asset,
    get_attacker,
    get_component,
    get_trust_boundary,
    get_assumption,
    get_control,
)

from .conftest import SAMPLE_CONTROLS, SAMPLE_MODELS_LIST, SAMPLE_THREAT_MODEL


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------



def _mock_client(**overrides: AsyncMock) -> AsyncMock:
    """Create a mocked MipitiClient with sensible defaults."""
    client = AsyncMock()
    client.api_url = "https://api.mipiti.io"

    _tm = ThreatModel.model_validate(SAMPLE_THREAT_MODEL)
    _controls = [Control.model_validate(c) for c in SAMPLE_CONTROLS["controls"]]

    defaults = {
        "generate_threat_model": GenerateResult(threat_model=_tm, model_id="tm-001", version=1),
        "refine_threat_model": GenerateResult(threat_model=_tm, model_id="tm-001", version=2),
        "query_threat_model": ChatResponse(content="The model covers SQL injection."),
        "list_models": [ModelSummary.model_validate(m) for m in SAMPLE_MODELS_LIST],
        "get_model": _tm,
        "rename_model": RenameResult(id="tm-001", title="New"),
        "delete_model": None,
        "export_model": b"AssetID,Name\nA1,Tokens\n",
        "get_controls": ControlsResponse(controls=_controls),
        "regenerate_controls": {"job_id": "job_regen"},
        "update_control_status": {"id": "CTRL-01", "status": "implemented"},
        "add_evidence": {"control_id": "CTRL-01", "evidence_count": 2},
        "remove_evidence": {"control_id": "CTRL-01", "evidence_count": 0},
        "import_controls": {"imported": 3},
        "delete_control": {"deleted": True},
        "check_control_gaps": {"job_id": "job_gaps"},
        "get_scan_prompt": {"prompt": "Scan for..."},
        "get_control_objectives": {"model_id": "tm-001", "total": 1},
        # Realistic API envelope shape: the backend returns a dict
        # with `model` + carry-forward metadata, not a raw entity.
        "add_asset": {"model": {"id": "tm-001", "assets": [{"id": "A3"}]},
                      "controls_carried": 0, "controls_orphaned": 0},
        "edit_asset": {"model": {"id": "tm-001", "assets": [{"id": "A1"}]},
                       "controls_carried": 0, "controls_orphaned": 0},
        "remove_asset": {"model": {"id": "tm-001", "assets": []},
                         "controls_carried": 0, "controls_orphaned": 0},
        "add_attacker": {"model": {"id": "tm-001", "attackers": [{"id": "T2"}]},
                         "controls_carried": 0, "controls_orphaned": 0},
        "edit_attacker": {"model": {"id": "tm-001", "attackers": [{"id": "T1"}]},
                          "controls_carried": 0, "controls_orphaned": 0},
        "remove_attacker": {"model": {"id": "tm-001", "attackers": []},
                            "controls_carried": 0, "controls_orphaned": 0},
        "assess_model": {"mitigated": 1, "at_risk": 0},
        "get_review_queue": {"items": []},
        "list_compliance_frameworks": {"frameworks": [{"id": "owasp-asvs"}]},
        "select_compliance_frameworks": {"selected": 1},
        "get_compliance_report": {"coverage": 0.8},
        "map_control_to_requirement": {"mapped": True},
        "auto_map_controls": {"job_id": "job_automap"},
        "auto_remediate": {"job_id": "job_auto_rem"},
        "get_operation": {"status": "completed", "result": {}},
        "select_system_compliance_frameworks": {"selected": 1},
        "get_system_compliance_report": {"coverage": 0.9},
        "submit_assertions": {"count": 2},
        "list_assertions": {"assertions": []},
        "delete_assertion": None,
        "get_verification_report": {"tier1_pass": 3},
        "submit_findings": {"count": 1},
        "list_findings": {"findings": []},
        "update_finding": {"id": "f1", "status": "acknowledged"},
        "list_workspaces": {"workspaces": []},
        "list_systems": {"systems": []},
        "get_system": {"id": "sys-1", "name": "Platform"},
        "create_system": {"id": "sys-2", "name": "New"},
        "add_model_to_system": {"added": True},
        "refine_control": {"accepted": True, "reason": "Coverage maintained.", "control": {"id": "CTRL-01"}},
        "remap_control": {
            "control": {"id": "CTRL-01", "control_objective_ids": ["CO1", "CO3"]},
            "model_id": "tm-001", "model_version": 2,
            "change_reason": "Restore mappings after v1->v2 renumber",
        },
        "restore_asset": {"id": "A1", "deleted": False},
        "restore_attacker": {"id": "T1", "deleted": False},
        "get_control_assumption_groups": {
            "control_id": "CTRL-01",
            "control_description": "Test control",
            "groups": {"1": [{"id": "AS1", "description": "AWS KMS", "active": True, "missing": False}]},
            "unmapped": [],
        },
        "set_control_assumption_groups": {
            "control_id": "CTRL-01",
            "assumption_groups": {"1": ["AS1"]},
            "justification": "AWS KMS handles this control.",
        },
        "model_coherence_report": {
            "model_id": "tm-001", "model_version": 1,
            "components_count": 1,
            "findings": [{"type": "co_asset_unbounded", "severity": "medium",
                          "co_id": "CO3", "asset_id": "A1", "attacker_id": "T1",
                          "reason": "asset_unbounded", "message": "...", "narration": "..."}],
            "summary": {"total": 1, "by_type": {}, "by_severity": {}},
        },
        "model_reachability_verdicts": {
            "model_id": "tm-001", "model_version": 1,
            "verdicts": [{"co_id": "CO3", "kind": "indeterminate",
                          "reason": "asset_unbounded", "narration": "...",
                          "boundary_id": "", "assumption_id": ""}],
        },
        "get_control_objective": {
            "model_id": "tm-001", "model_version": 1,
            "control_objective": {"id": "CO3", "asset_id": "A1", "attacker_id": "T1",
                                  "security_properties": ["C"], "statement": "...",
                                  "risk_tier": "medium", "boundary_reachable": False,
                                  "boundary_unreachable_reason": "", "removed": False,
                                  "removed_at": "", "removed_in_version": 0,
                                  "controls": []},
            "reachability_verdict": {"kind": "indeterminate", "reason": "asset_unbounded",
                                     "narration": "...", "boundary_id": "",
                                     "assumption_id": ""},
        },
        "get_asset": {"model_id": "tm-001", "model_version": 1,
                       "asset": {"id": "A1", "name": "Tokens"}},
        "get_attacker": {"model_id": "tm-001", "model_version": 1,
                          "attacker": {"id": "T1", "capability": "Network"}},
        "get_component": {"model_id": "tm-001", "model_version": 1,
                           "component": {"id": "C1", "name": "api", "repo_url": ""}},
        "get_trust_boundary": {"model_id": "tm-001", "model_version": 1,
                                "trust_boundary": {"id": "TB1", "passes": ["Network"]}},
        "get_assumption": {"model_id": "tm-001", "model_version": 1,
                            "assumption": {"id": "AS1", "description": "x",
                                           "deleted": False, "exclusion": None}},
        "get_control": {"model_id": "tm-001", "model_version": 1,
                         "control": {"id": "CTRL-01", "description": "test"}},
    }

    for name, default_val in defaults.items():
        mock_fn = overrides.get(name, AsyncMock(return_value=default_val))
        setattr(client, name, mock_fn)

    return client


def _mock_ctx() -> AsyncMock:
    ctx = AsyncMock()
    ctx.report_progress = AsyncMock()
    ctx.info = AsyncMock()
    return ctx


def _patch_client(mock=None):
    if mock is None:
        mock = _mock_client()
    return patch("mipiti_mcp.server._get_client", return_value=mock)


# ------------------------------------------------------------------
# Threat Model Generation & Management
# ------------------------------------------------------------------


class TestGenerateThreatModel:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await generate_threat_model(server_version="0", feature_description="User login", ctx=ctx)
        assert result["model_id"] == "tm-001"
        assert result["asset_count"] == 2
        mock.generate_threat_model.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_similar_models_short_circuit(self) -> None:
        """Backend returns similar_models instead of generating. Tool
        must pass the candidate IDs through with a suggestion, not
        raise a tool error."""
        mock = _mock_client(generate_threat_model=AsyncMock(return_value={
            "similar_models": [
                {"id": "tm-existing", "title": "Login Page",
                 "reason": "Same auth surface."},
            ],
        }))
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await generate_threat_model(
                server_version="0",
                feature_description="User login",
                ctx=ctx,
            )
        assert "similar_models" in result
        assert result["similar_models"][0]["id"] == "tm-existing"
        assert "refine_threat_model" in result["suggestion"]
        assert "force=True" in result["suggestion"]

    @pytest.mark.asyncio
    async def test_force_is_forwarded_to_client(self) -> None:
        """The `force` tool arg must reach the client as
        ``force_generate=True`` — otherwise retry-with-force has no
        effect and the agent stays stuck on the similar-models loop."""
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            await generate_threat_model(
                server_version="0",
                feature_description="User login",
                ctx=ctx,
                force=True,
            )
        call_kwargs = mock.generate_threat_model.await_args.kwargs
        assert call_kwargs.get("force_generate") is True


class TestRefineThreatModel:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await refine_threat_model(server_version="0", model_id="tm-001", instruction="Add CSRF", ctx=ctx)
        assert result["model_id"] == "tm-001"
        # Live-count keys are present and agree with mock shape.
        assert "live_asset_count" in result
        assert "live_attacker_count" in result
        assert "live_control_objective_count" in result
        # Semantic-rejections array surfaced (empty on happy path).
        assert result["semantic_rejections"] == []
        mock.refine_threat_model.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_semantic_rejections_surfaced(self) -> None:
        """When the refine-path guard reverted an identity-bearing
        rewrite, the tool must pass the rejection array through so
        the agent can surface what refine chose not to apply."""
        from mipiti_mcp.types import GenerateResult, ThreatModel
        rejected = GenerateResult(
            threat_model=ThreatModel(id="tm-001", title="t"),
            model_id="tm-001",
            version=3,
            semantic_rejections=[
                {
                    "kind": "asset", "id": "A-04",
                    "classification": "replace",
                    "reason": "Rename from OIDC Token to CI Attestation Bundle is a different asset.",
                    "per_field": {"name": "OIDC Token -> CI Attestation Bundle"},
                },
            ],
        )
        mock = _mock_client(refine_threat_model=AsyncMock(return_value=rejected))
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await refine_threat_model(
                server_version="0", model_id="tm-001",
                instruction="Rename A-04", ctx=ctx,
            )
        rejections = result["semantic_rejections"]
        assert len(rejections) == 1
        assert rejections[0]["kind"] == "asset"
        assert rejections[0]["id"] == "A-04"
        assert rejections[0]["classification"] == "replace"

    @pytest.mark.asyncio
    async def test_live_counts_exclude_soft_deleted(self) -> None:
        """live_asset_count / live_attacker_count / live_control_
        objective_count must exclude soft-deleted / tombstoned entries
        so agents don't surface stale totals."""
        from mipiti_mcp.types import (
            GenerateResult, ThreatModel, Asset, Attacker, ControlObjective,
        )
        tm = ThreatModel(
            id="tm-001",
            title="t",
            assets=[
                Asset(id="A1", name="Live"),
                Asset(id="A2", name="Dead", deleted=True),
            ],
            attackers=[
                Attacker(id="T1", capability="Live"),
                Attacker(id="T2", capability="Dead", deleted=True),
            ],
            control_objectives=[
                ControlObjective(id="CO1", asset_id="A1", attacker_id="T1", statement="s"),
                ControlObjective(id="CO2", asset_id="A2", attacker_id="T1",
                                 statement="", removed=True),
            ],
        )
        mock = _mock_client(refine_threat_model=AsyncMock(
            return_value=GenerateResult(threat_model=tm, model_id="tm-001", version=2),
        ))
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await refine_threat_model(
                server_version="0", model_id="tm-001",
                instruction="..", ctx=ctx,
            )
        assert result["asset_count"] == 2
        assert result["live_asset_count"] == 1
        assert result["attacker_count"] == 2
        assert result["live_attacker_count"] == 1
        assert result["control_objective_count"] == 2
        assert result["live_control_objective_count"] == 1


class TestProgressChannelClosed:
    """Streaming tools must tolerate the MCP progress channel closing
    mid-call. A ClosedResourceError from ctx.report_progress means the
    client is no longer listening, but the upstream work has already
    completed and persisted — the tool must still return its result
    instead of raising.
    """

    @pytest.mark.asyncio
    async def test_generate_returns_result_when_channel_closed(self) -> None:
        from anyio import ClosedResourceError

        async def _client_call(_desc, force_generate=False, on_progress=None):
            if on_progress is not None:
                await on_progress(1.0, 5.0, "Working")
            _tm = ThreatModel.model_validate(SAMPLE_THREAT_MODEL)
            return GenerateResult(threat_model=_tm, model_id="tm-001", version=1)

        mock = _mock_client(generate_threat_model=AsyncMock(side_effect=_client_call))
        ctx = AsyncMock()
        ctx.report_progress = AsyncMock(side_effect=ClosedResourceError())
        ctx.info = AsyncMock()
        with _patch_client(mock):
            result = await generate_threat_model(
                server_version="0",
                feature_description="Test feature",
                ctx=ctx,
            )
        assert result["model_id"] == "tm-001"

    @pytest.mark.asyncio
    async def test_refine_returns_result_when_channel_broken(self) -> None:
        from anyio import BrokenResourceError

        async def _client_call(_model_id, _instruction, on_progress=None):
            if on_progress is not None:
                await on_progress(2.0, 5.0, "Refining")
            _tm = ThreatModel.model_validate(SAMPLE_THREAT_MODEL)
            return GenerateResult(threat_model=_tm, model_id="tm-001", version=2)

        mock = _mock_client(refine_threat_model=AsyncMock(side_effect=_client_call))
        ctx = AsyncMock()
        ctx.report_progress = AsyncMock(side_effect=BrokenResourceError())
        ctx.info = AsyncMock()
        with _patch_client(mock):
            result = await refine_threat_model(
                server_version="0",
                model_id="tm-001",
                instruction="Add CSRF",
                ctx=ctx,
            )
        assert result["model_id"] == "tm-001"


class TestQueryThreatModel:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await query_threat_model(server_version="0", model_id="tm-001", question="SQL injection?", ctx=ctx)
        assert result["answer"] == "The model covers SQL injection."


class TestListThreatModels:
    @pytest.mark.asyncio
    async def test_returns_items(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await list_threat_models(server_version="0")
        assert result["count"] == 2
        assert result["items"][0]["id"] == "tm-001"
        # Default: lean response, no assessment_summary field
        assert "assessment_summary" not in result["items"][0]

    @pytest.mark.asyncio
    async def test_empty(self) -> None:
        mock = _mock_client(list_models=AsyncMock(return_value=[]))
        with _patch_client(mock):
            result = await list_threat_models(server_version="0")
        assert result["count"] == 0

    @pytest.mark.asyncio
    async def test_source_filter_forwarded(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            await list_threat_models(server_version="0", source="mcp")
        mock.list_models.assert_awaited_once_with(source="mcp", include="")

    @pytest.mark.asyncio
    async def test_include_assessment_summary_forwards_include_param(self) -> None:
        """When the caller requests posture, the tool must pass include=
        to the backend so the list response inlines the summary."""
        mock = _mock_client()
        with _patch_client(mock):
            await list_threat_models(
                server_version="0", include_assessment_summary=True,
            )
        mock.list_models.assert_awaited_once_with(
            source="", include="assessment_summary",
        )

    @pytest.mark.asyncio
    async def test_include_assessment_summary_surfaces_in_items(self) -> None:
        """When the backend returns an inlined assessment, the tool copies
        it onto each item as `assessment_summary`."""
        # Build a ModelSummary with the inlined assessment via extra="allow".
        tm_with_asmt = ModelSummary.model_validate({
            "id": "tm-001",
            "title": "Login API",
            "feature_description": "...",
            "created_at": "2026-01-01T00:00:00+00:00",
            "version": 1,
            "assessment": {
                "summary": {"mitigated": 9, "at_risk": 3, "unassessed": 0},
                "message": "13 controls not implemented, blocking 3 COs.",
            },
        })
        mock = _mock_client(list_models=AsyncMock(return_value=[tm_with_asmt]))
        with _patch_client(mock):
            result = await list_threat_models(
                server_version="0", include_assessment_summary=True,
            )
        assert result["count"] == 1
        item = result["items"][0]
        assert item["id"] == "tm-001"
        assert "assessment_summary" in item
        assert item["assessment_summary"]["summary"]["at_risk"] == 3
        assert "13 controls" in item["assessment_summary"]["message"]


class TestRenameThreatModel:
    @pytest.mark.asyncio
    async def test_rename(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await rename_threat_model(server_version="0", model_id="tm-001", name="New Name")
        assert result["title"] == "New"
        mock.rename_model.assert_awaited_once_with("tm-001", "New Name")


class TestDeleteThreatModel:
    @pytest.mark.asyncio
    async def test_delete(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await delete_threat_model(server_version="0", model_id="tm-001")
        assert result["deleted"] is True
        mock.delete_model.assert_awaited_once()


class TestExportThreatModelArchive:
    @pytest.mark.asyncio
    async def test_returns_envelope(self) -> None:
        mock = _mock_client()
        envelope = {
            "format_version": 1,
            "title": "Checkout",
            "versions": [{"version": 1, "data": {}, "created_at": "2026-04-20T00:00:00Z"}],
        }
        mock.export_model_full = AsyncMock(return_value=envelope)
        with _patch_client(mock):
            result = await export_threat_model_archive(server_version="0", model_id="tm-001")
        assert result["envelope"] == envelope
        mock.export_model_full.assert_awaited_once_with("tm-001")


class TestImportThreatModelArchive:
    @pytest.mark.asyncio
    async def test_imports_and_returns_new_id(self) -> None:
        mock = _mock_client()
        mock.import_model_full = AsyncMock(return_value={"model_id": "tm-new"})
        envelope = {"format_version": 1, "versions": [{"version": 1, "data": {}}]}
        with _patch_client(mock):
            result = await import_threat_model_archive(
                server_version="0", envelope=envelope, workspace_id="ws-1",
            )
        assert result["model_id"] == "tm-new"
        mock.import_model_full.assert_awaited_once_with(envelope, "ws-1")

    @pytest.mark.asyncio
    async def test_requires_envelope_dict(self) -> None:
        with _patch_client():
            with pytest.raises(ToolError):
                await import_threat_model_archive(
                    server_version="0", envelope="not a dict", workspace_id="ws-1",  # type: ignore[arg-type]
                )

    @pytest.mark.asyncio
    async def test_requires_workspace_id(self) -> None:
        with _patch_client():
            with pytest.raises(ToolError):
                await import_threat_model_archive(
                    server_version="0", envelope={"format_version": 1}, workspace_id="",
                )


class TestGetThreatModel:
    @pytest.mark.asyncio
    async def test_latest(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_threat_model(server_version="0", model_id="tm-001")
        assert result["id"] == "tm-001"
        mock.get_model.assert_awaited_once_with("tm-001", None)

    @pytest.mark.asyncio
    async def test_specific_version(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            await get_threat_model(server_version="0", model_id="tm-001", version=3)
        mock.get_model.assert_awaited_once_with("tm-001", 3)


class TestExportThreatModel:
    @pytest.mark.asyncio
    async def test_csv(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await export_threat_model(server_version="0", model_id="tm-001", format="csv")
        assert result["format"] == "csv"
        assert "AssetID,Name" in result["content"]

    @pytest.mark.asyncio
    async def test_pdf_returns_url(self) -> None:
        mock = _mock_client(export_model=AsyncMock(return_value=b"%PDF-binary"))
        with _patch_client(mock):
            result = await export_threat_model(server_version="0", model_id="tm-001", format="pdf")
        assert result["format"] == "pdf"
        assert "/api/models/tm-001/export?format=pdf" in result["download_url"]

    @pytest.mark.asyncio
    async def test_invalid_format(self) -> None:
        with pytest.raises(ToolError, match="format must be"):
            await export_threat_model(server_version="0", model_id="tm-001", format="xml")


# ------------------------------------------------------------------
# Controls
# ------------------------------------------------------------------


class TestGetControls:
    @pytest.mark.asyncio
    async def test_basic(self) -> None:
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await get_controls(server_version="0", model_id="tm-001", ctx=ctx)
        assert result["total"] == 2
        assert result["returned"] == 2

    @pytest.mark.asyncio
    async def test_filter_by_status(self) -> None:
        """Status filter is passed to the backend (server-side filtering)."""
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            await get_controls(server_version="0", model_id="tm-001", ctx=ctx, status="implemented")
        mock.get_controls.assert_awaited_once()
        call_kwargs = mock.get_controls.call_args[1]
        assert call_kwargs["status"] == "implemented"

    @pytest.mark.asyncio
    async def test_pagination(self) -> None:
        """Offset/limit are passed to the backend (server-side pagination)."""
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            await get_controls(server_version="0", model_id="tm-001", ctx=ctx, offset=0, limit=1)
        mock.get_controls.assert_awaited_once()
        call_kwargs = mock.get_controls.call_args[1]
        assert call_kwargs["limit"] == 1


class TestRegenerateControls:
    @pytest.mark.asyncio
    async def test_with_backend_job(self) -> None:
        mock = _mock_client()
        mock.get_operation = AsyncMock(return_value={
            "status": "completed",
            "result": {"controls": [{"id": "CTRL-01"}], "total": 1},
        })
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await regenerate_controls(server_version="0", model_id="tm-001", ctx=ctx)
        assert result["total"] == 1
        mock.get_operation.assert_awaited_once_with("job_regen")


class TestUpdateControlStatus:
    @pytest.mark.asyncio
    async def test_valid_status(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await update_control_status(server_version="0", model_id="tm-001", control_id="CTRL-01", status="implemented")
        assert result["status"] == "implemented"

    @pytest.mark.asyncio
    async def test_invalid_status(self) -> None:
        with pytest.raises(ToolError, match="status must be"):
            await update_control_status(server_version="0", model_id="tm-001", control_id="CTRL-01", status="invalid")



class TestRefineControl:
    @pytest.mark.asyncio
    async def test_accepted(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await refine_control(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
                description="Updated description matching implementation.",
                justification="Implementation uses FastAPI Depends, not middleware.",
            )
        assert result["accepted"] is True
        mock.refine_control.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_rejected(self) -> None:
        mock = _mock_client(
            refine_control=AsyncMock(return_value={
                "accepted": False,
                "reason": "CO1 would no longer be satisfied.",
                "per_co": {"CO1": {"satisfied": False, "reasoning": "Weakened."}},
            }),
        )
        with _patch_client(mock):
            result = await refine_control(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
                description="Weaker description.",
                justification="Trying to weaken the control.",
            )
        assert result["accepted"] is False
        assert "CO1" in result["per_co"]

    @pytest.mark.asyncio
    async def test_empty_description_and_findings(self) -> None:
        with pytest.raises(ToolError, match="Either description or codebase_findings is required"):
            await refine_control(server_version="0", model_id="tm-001", control_id="CTRL-01", description="  ", justification="Some justification here.")

    @pytest.mark.asyncio
    async def test_short_justification(self) -> None:
        with pytest.raises(ToolError, match="justification must be at least 10"):
            await refine_control(server_version="0", model_id="tm-001", control_id="CTRL-01", description="New desc.", justification="Short")


class TestRemapControl:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await remap_control(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
                co_ids="CO1, CO3",
                change_reason="Restore mappings after v1->v2 renumber",
            )
        assert "control" in result
        mock.remap_control.assert_awaited_once()
        args = mock.remap_control.await_args
        assert args.args[2] == ["CO1", "CO3"]

    @pytest.mark.asyncio
    async def test_empty_co_ids_rejected(self) -> None:
        with pytest.raises(ToolError, match="at least one CO ID"):
            await remap_control(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
                co_ids="",
                change_reason="Any valid change reason here.",
            )

    @pytest.mark.asyncio
    async def test_short_change_reason_rejected(self) -> None:
        with pytest.raises(ToolError, match="at least 10"):
            await remap_control(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
                co_ids="CO1",
                change_reason="short",
            )


class TestRestoreAssetAttacker:
    @pytest.mark.asyncio
    async def test_restore_asset(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await restore_asset(
                server_version="0", model_id="tm-001", asset_id="A1",
            )
        assert result["deleted"] is False
        mock.restore_asset.assert_awaited_once_with("tm-001", "A1")

    @pytest.mark.asyncio
    async def test_restore_attacker(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await restore_attacker(
                server_version="0", model_id="tm-001", attacker_id="T1",
            )
        assert result["deleted"] is False
        mock.restore_attacker.assert_awaited_once_with("tm-001", "T1")


class TestAddEvidence:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await add_evidence(server_version="0", model_id="tm-001", control_id="CTRL-01", type="code", label="bcrypt usage")
        assert result["evidence_count"] == 2

    @pytest.mark.asyncio
    async def test_empty_label(self) -> None:
        with pytest.raises(ToolError, match="label is required"):
            await add_evidence(server_version="0", model_id="tm-001", control_id="CTRL-01", type="code", label="  ")


class TestRemoveEvidence:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await remove_evidence(server_version="0", model_id="tm-001", control_id="CTRL-01", evidence_index=0)
        assert result["evidence_count"] == 0


class TestImportControls:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await import_controls(server_version="0", model_id="tm-001", ctx=ctx, free_text="Encrypt data at rest")
        assert result["imported"] == 3


class TestDeleteControl:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await delete_control(server_version="0", model_id="tm-001", control_id="CTRL-01", reason="Duplicate")
        assert result["deleted"] is True


class TestCheckControlGaps:
    @pytest.mark.asyncio
    async def test_with_backend_job(self) -> None:
        mock = _mock_client()
        mock.get_operation = AsyncMock(return_value={
            "status": "completed",
            "result": {"gaps": [], "gap_count": 0},
        })
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await check_control_gaps(server_version="0", model_id="tm-001", ctx=ctx)
        assert result["gap_count"] == 0
        mock.get_operation.assert_awaited_once_with("job_gaps")


# ------------------------------------------------------------------
# Control Objectives & Assurance
# ------------------------------------------------------------------


class TestGetControlObjectives:
    @pytest.mark.asyncio
    async def test_basic(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_control_objectives(server_version="0", model_id="tm-001")
        assert result["total"] == 1


class TestAssessModel:
    @pytest.mark.asyncio
    async def test_basic(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await assess_model(server_version="0", model_id="tm-001")
        assert result["mitigated"] == 1


class TestGetReviewQueue:
    @pytest.mark.asyncio
    async def test_basic(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_review_queue(server_version="0")
        assert "items" in result


# ------------------------------------------------------------------
# Assets & Attackers
# ------------------------------------------------------------------


class TestAddAsset:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        """Normal create: API returns {"model": ..., "controls_carried": ...}."""
        mock = _mock_client()
        with _patch_client(mock):
            result = await add_asset(server_version="0", model_id="tm-001", name="Session Store")
        assert "model" in result
        assert result["controls_carried"] == 0
        mock.add_asset.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_auto_restore_response_surfaced(self) -> None:
        """When the backend classifies the proposed asset as the same
        entity as a soft-deleted one, it auto-restores and returns
        `auto_restored: True`, `restored_asset_id`, and
        `discarded_fields`. The MCP tool must pass all of those
        through so the agent knows the call wasn't a fresh create
        AND can reapply non-identity proposed values if appropriate."""
        mock = _mock_client(add_asset=AsyncMock(return_value={
            "model": {"id": "tm-001", "assets": [{"id": "A-04"}]},
            "controls_carried": 2,
            "controls_orphaned": 0,
            "auto_restored": True,
            "restored_asset_id": "A-04",
            "reason": "Proposed asset matched soft-deleted A-04; restored it.",
            "discarded_fields": [
                {"field": "notes", "proposed_value": "extra context",
                 "preserved_value": "", "identity_bearing": False,
                 "reason": "Restored asset keeps archived notes."},
            ],
        }))
        with _patch_client(mock):
            result = await add_asset(
                server_version="0", model_id="tm-001",
                name="OIDC Token", notes="extra context",
            )
        assert result["auto_restored"] is True
        assert result["restored_asset_id"] == "A-04"
        # Agent needs the discarded fields to decide whether to reapply.
        assert len(result["discarded_fields"]) == 1
        assert result["discarded_fields"][0]["field"] == "notes"
        assert result["discarded_fields"][0]["identity_bearing"] is False

    @pytest.mark.asyncio
    async def test_add_asset_invalid_response_raises_502(self) -> None:
        """Distinct from 503 (evaluator down), 502 means the evaluator
        responded but output was malformed. Agent's retry profile
        differs: retry-same-prompt for 502, retry-with-backoff for 503."""
        import httpx
        err = httpx.HTTPStatusError(
            "502 Bad Gateway",
            request=httpx.Request("POST", "http://test"),
            response=httpx.Response(502, json={
                "detail": "Asset restore-candidate evaluator returned malformed output.",
            }),
        )
        mock = _mock_client(add_asset=AsyncMock(side_effect=err))
        with _patch_client(mock), pytest.raises(ToolError):
            await add_asset(server_version="0", model_id="tm-001", name="X")

    @pytest.mark.asyncio
    async def test_similar_verdict_rejected_with_suggestion(self) -> None:
        """When the LLM classifies as `similar` (might be the same but
        not confident), backend returns {accepted: False, ...} at
        HTTP 200. Tool passes the structured rejection through."""
        mock = _mock_client(add_asset=AsyncMock(return_value={
            "accepted": False,
            "classification": "similar",
            "candidate_restore_id": "A-04",
            "reason": "Names match but descriptions diverge.",
            "suggestion": "Call restore_asset, or re-submit with a distinctive description.",
        }))
        with _patch_client(mock):
            result = await add_asset(server_version="0", model_id="tm-001", name="OIDC Token")
        assert result["accepted"] is False
        assert result["classification"] == "similar"
        assert result["candidate_restore_id"] == "A-04"
        assert "restore_asset" in result["suggestion"]

    @pytest.mark.asyncio
    async def test_llm_unavailable_raises_tool_error(self) -> None:
        """503 from the backend (LLM evaluator down) surfaces as a
        tool error that agents can retry."""
        import httpx
        err = httpx.HTTPStatusError(
            "503 Service Unavailable",
            request=httpx.Request("POST", "http://test"),
            response=httpx.Response(503, json={
                "detail": "Asset restore-candidate evaluator unavailable.",
            }),
        )
        mock = _mock_client(add_asset=AsyncMock(side_effect=err))
        with _patch_client(mock), pytest.raises(ToolError):
            await add_asset(server_version="0", model_id="tm-001", name="OIDC Token")


class TestEditAsset:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await edit_asset(server_version="0", model_id="tm-001", asset_id="A1", name="Updated")
        assert "model" in result

    @pytest.mark.asyncio
    async def test_semantic_rejection_surfaced(self) -> None:
        """When the LLM classifies the edit as `replace` or
        `ambiguous`, backend returns HTTP 200 with a structured
        rejection. Tool passes it through so the agent can act."""
        mock = _mock_client(edit_asset=AsyncMock(return_value={
            "accepted": False,
            "classification": "replace",
            "reason": "Rename changes semantic identity.",
            "per_field": {"name": "Card Data -> Audit Log is a different asset"},
            "suggestion": "Soft-delete + add new.",
        }))
        with _patch_client(mock):
            result = await edit_asset(
                server_version="0", model_id="tm-001", asset_id="A1",
                name="Audit Log",
            )
        assert result["accepted"] is False
        assert result["classification"] == "replace"
        assert "per_field" in result

    @pytest.mark.asyncio
    async def test_llm_unavailable_raises_tool_error(self) -> None:
        import httpx
        err = httpx.HTTPStatusError(
            "503 Service Unavailable",
            request=httpx.Request("PUT", "http://test"),
            response=httpx.Response(503, json={
                "detail": "Asset semantic-preservation evaluator unavailable.",
            }),
        )
        mock = _mock_client(edit_asset=AsyncMock(side_effect=err))
        with _patch_client(mock), pytest.raises(ToolError):
            await edit_asset(
                server_version="0", model_id="tm-001", asset_id="A1",
                name="Renamed",
            )


class TestRemoveAsset:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        """Soft-delete: asset stays in model with deleted=True."""
        mock = _mock_client()
        with _patch_client(mock):
            result = await remove_asset(server_version="0", model_id="tm-001", asset_id="A1")
        assert "model" in result


class TestAddAttacker:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await add_attacker(server_version="0", model_id="tm-001", capability="Phishing")
        assert "model" in result

    @pytest.mark.asyncio
    async def test_auto_restore_response_surfaced(self) -> None:
        mock = _mock_client(add_attacker=AsyncMock(return_value={
            "model": {"id": "tm-001", "attackers": [{"id": "T-03"}]},
            "controls_carried": 1,
            "controls_orphaned": 0,
            "auto_restored": True,
            "restored_attacker_id": "T-03",
            "reason": "Matched soft-deleted T-03.",
        }))
        with _patch_client(mock):
            result = await add_attacker(
                server_version="0", model_id="tm-001", capability="Supply chain",
            )
        assert result["auto_restored"] is True
        assert result["restored_attacker_id"] == "T-03"

    @pytest.mark.asyncio
    async def test_similar_verdict_rejected(self) -> None:
        mock = _mock_client(add_attacker=AsyncMock(return_value={
            "accepted": False,
            "classification": "similar",
            "candidate_restore_id": "T-03",
            "reason": "Capability close but archetype differs.",
            "suggestion": "Call restore_attacker(T-03) or distinguish the new one.",
        }))
        with _patch_client(mock):
            result = await add_attacker(
                server_version="0", model_id="tm-001", capability="Supply chain",
            )
        assert result["accepted"] is False
        assert result["classification"] == "similar"


class TestEditAttacker:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await edit_attacker(server_version="0", model_id="tm-001", attacker_id="T1", capability="Updated")
        assert "model" in result

    @pytest.mark.asyncio
    async def test_semantic_rejection_surfaced(self) -> None:
        mock = _mock_client(edit_attacker=AsyncMock(return_value={
            "accepted": False,
            "classification": "replace",
            "reason": "Archetype change is a different adversary.",
            "per_field": {"archetype": "Unauthenticated -> Supply chain"},
            "suggestion": "Soft-delete + add new.",
        }))
        with _patch_client(mock):
            result = await edit_attacker(
                server_version="0", model_id="tm-001", attacker_id="T1",
                archetype="Supply chain",
            )
        assert result["accepted"] is False
        assert result["classification"] == "replace"


class TestRemoveAttacker:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await remove_attacker(server_version="0", model_id="tm-001", attacker_id="T1")
        assert "model" in result


# ------------------------------------------------------------------
# Compliance
# ------------------------------------------------------------------


class TestListComplianceFrameworks:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await list_compliance_frameworks(server_version="0")
        assert len(result["frameworks"]) == 1


class TestSelectComplianceFrameworks:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await select_compliance_frameworks(server_version="0", model_id="tm-001", framework_ids="owasp-asvs")
        assert result["selected"] == 1


class TestGetComplianceReport:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_compliance_report(server_version="0", model_id="tm-001", framework_id="owasp-asvs")
        assert result["coverage"] == 0.8


class TestMapControlToRequirement:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await map_control_to_requirement(
                server_version="0", model_id="tm-001", framework_id="owasp-asvs",
                requirement_id="V2.1.1", control_id="CTRL-01",
            )
        assert result["mapped"] is True


class TestAutoMapControls:
    @pytest.mark.asyncio
    async def test_with_backend_job(self) -> None:
        """Backend returns job_id, tool polls until completion."""
        mock = _mock_client()
        mock.get_operation = AsyncMock(return_value={
            "status": "completed",
            "result": {"mappings_created": 9, "controls_mapped": 5, "controls_total": 12},
        })
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await auto_map_controls(server_version="0", model_id="tm-001", framework_id="owasp-asvs", ctx=ctx)
        assert result["mappings_created"] == 9
        mock.get_operation.assert_awaited_once_with("job_automap")

    @pytest.mark.asyncio
    async def test_sync_response(self) -> None:
        """Backend returns result directly (e.g. all already mapped)."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"mappings_created": 0, "controls_mapped": 0, "controls_total": 5}))
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await auto_map_controls(server_version="0", model_id="tm-001", framework_id="owasp-asvs", ctx=ctx)
        assert result["controls_total"] == 5


class TestAutoRemediate:
    @pytest.mark.asyncio
    async def test_with_backend_job(self) -> None:
        mock = _mock_client(auto_remediate=AsyncMock(return_value={"job_id": "job_rem"}))
        mock.get_operation = AsyncMock(return_value={
            "status": "completed",
            "result": {"coverage": 0.95},
        })
        ctx = _mock_ctx()
        with _patch_client(mock):
            result = await auto_remediate(server_version="0", model_id="tm-001", framework_id="owasp-asvs", ctx=ctx)
        assert result["coverage"] == 0.95


class TestAwaitBackendJob:
    @pytest.mark.asyncio
    async def test_failure(self) -> None:
        """Backend job fails — ToolError raised with error message."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_fail"}))
        mock.get_operation = AsyncMock(return_value={
            "status": "failed",
            "error": "LLM rate limit exceeded",
        })
        ctx = _mock_ctx()
        with _patch_client(mock):
            with pytest.raises(ToolError, match="LLM rate limit exceeded"):
                await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

    @pytest.mark.asyncio
    async def test_timeout(self) -> None:
        """Backend job never completes — ToolError raised after timeout."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_hang"}))
        mock.get_operation = AsyncMock(return_value={
            "status": "running",
            "poll_after_seconds": 0,
        })
        ctx = _mock_ctx()
        # Make time.monotonic() jump past deadline on second call
        monotonic_values = iter([0, 0, 999])
        with _patch_client(mock), patch("mipiti_mcp.server.time") as mock_time:
            mock_time.monotonic = lambda: next(monotonic_values)
            with pytest.raises(ToolError, match="timed out"):
                await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

    @pytest.mark.asyncio
    async def test_client_disconnect_aborts_polling(self) -> None:
        """Client disconnects mid-poll — ToolError raised, no further polling."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_disconnect"}))
        mock.get_operation = AsyncMock(return_value={"status": "running", "poll_after_seconds": 0})
        ctx = _mock_ctx()

        fake_request = AsyncMock()
        fake_request.is_disconnected = AsyncMock(return_value=True)

        with _patch_client(mock), patch(
            "fastmcp.server.dependencies.get_http_request", return_value=fake_request
        ):
            with pytest.raises(ToolError, match="Client disconnected"):
                await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        # Verify we did NOT keep polling — at most one get_operation call (the disconnect
        # check happens at the top of the loop, before the operation poll).
        assert mock.get_operation.await_count == 0

    @pytest.mark.asyncio
    async def test_stdio_no_http_request_polls_normally(self) -> None:
        """stdio transport — no HTTP request — polling proceeds normally without disconnect check."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_stdio"}))
        mock.get_operation = AsyncMock(return_value={
            "status": "completed",
            "result": {"mappings_created": 3, "controls_mapped": 2, "controls_total": 5},
        })
        ctx = _mock_ctx()

        with _patch_client(mock), patch(
            "fastmcp.server.dependencies.get_http_request",
            side_effect=RuntimeError("No active HTTP request found."),
        ):
            result = await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        assert result["mappings_created"] == 3
        mock.get_operation.assert_awaited_once_with("job_stdio")

    @pytest.mark.asyncio
    async def test_is_disconnected_raises_treated_as_connected(self) -> None:
        """is_disconnected() raises an exception — treat as still-connected (no false positive)."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_robust"}))
        mock.get_operation = AsyncMock(return_value={
            "status": "completed",
            "result": {"mappings_created": 1, "controls_mapped": 1, "controls_total": 1},
        })
        ctx = _mock_ctx()

        fake_request = AsyncMock()
        fake_request.is_disconnected = AsyncMock(side_effect=RuntimeError("transport in unusual state"))

        with _patch_client(mock), patch(
            "fastmcp.server.dependencies.get_http_request", return_value=fake_request
        ):
            result = await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        assert result["controls_total"] == 1
        mock.get_operation.assert_awaited_once_with("job_robust")

    # ----- Progress monotonicity & total-constancy (MCP invariants) -----
    #
    # These tests drive _await_backend_job through scripted get_operation
    # responses and assert on captured ctx.report_progress calls. We don't
    # mock _safe_report_progress — the guard-wrapper must stay in the path.

    @staticmethod
    def _script(responses: list[dict]) -> AsyncMock:
        """Build a get_operation mock that yields a scripted response sequence
        and then reports `completed` forever."""
        final = {"status": "completed", "result": {"mappings_created": 0, "controls_mapped": 0, "controls_total": 0}}
        it = iter(responses)

        async def _next(_job_id: str) -> dict:
            try:
                return next(it)
            except StopIteration:
                return final

        return AsyncMock(side_effect=_next)

    @pytest.mark.asyncio
    async def test_progress_numeric_happy_path(self) -> None:
        """Backend advertises (cur, tot): (1,5) -> (2,5) -> (3,5).

        Expect three emissions, current strictly increasing, total constant.
        """
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_p1"}))
        mock.get_operation = self._script([
            {"status": "running", "progress": "step 1", "progress_current": 1, "progress_total": 5, "poll_after_seconds": 0},
            {"status": "running", "progress": "step 2", "progress_current": 2, "progress_total": 5, "poll_after_seconds": 0},
            {"status": "running", "progress": "step 3", "progress_current": 3, "progress_total": 5, "poll_after_seconds": 0},
        ])
        ctx = _mock_ctx()
        with _patch_client(mock):
            await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        calls = ctx.report_progress.await_args_list
        assert len(calls) == 3
        # Signature: ctx.report_progress(progress, total, message=...)
        assert [c.args[0] for c in calls] == [1.0, 2.0, 3.0]
        assert [c.args[1] for c in calls] == [5.0, 5.0, 5.0]
        assert [c.kwargs["message"] for c in calls] == ["step 1", "step 2", "step 3"]

    @pytest.mark.asyncio
    async def test_progress_duplicate_poll_skipped(self) -> None:
        """Backend repeats (1,5): only one emission (second would violate strict increase)."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_p2"}))
        mock.get_operation = self._script([
            {"status": "running", "progress": "step 1", "progress_current": 1, "progress_total": 5, "poll_after_seconds": 0},
            {"status": "running", "progress": "step 1", "progress_current": 1, "progress_total": 5, "poll_after_seconds": 0},
        ])
        ctx = _mock_ctx()
        with _patch_client(mock):
            await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        calls = ctx.report_progress.await_args_list
        assert len(calls) == 1
        assert calls[0].args[:2] == (1.0, 5.0)

    @pytest.mark.asyncio
    async def test_progress_total_changes_midflight_skipped(self) -> None:
        """Phase shift: (3,5) -> (1,10). Second emission is SKIPPED, locked total wins.

        We don't fall back to indeterminate mode either — the bar freezes where
        it was until numerics align with the locked total again.
        """
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_p3"}))
        mock.get_operation = self._script([
            {"status": "running", "progress": "phase A", "progress_current": 3, "progress_total": 5, "poll_after_seconds": 0},
            {"status": "running", "progress": "phase B", "progress_current": 1, "progress_total": 10, "poll_after_seconds": 0},
        ])
        ctx = _mock_ctx()
        with _patch_client(mock):
            await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        calls = ctx.report_progress.await_args_list
        assert len(calls) == 1
        assert calls[0].args[:2] == (3.0, 5.0)

    @pytest.mark.asyncio
    async def test_progress_numerics_disappear_after_present(self) -> None:
        """(2,5) first, then numerics disappear leaving only message.

        Indeterminate-mode elif fires with incrementing poll_counter.
        """
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_p4"}))
        mock.get_operation = self._script([
            {"status": "running", "progress": "step 2", "progress_current": 2, "progress_total": 5, "poll_after_seconds": 0},
            {"status": "running", "progress": "still working", "poll_after_seconds": 0},
            {"status": "running", "progress": "still working more", "poll_after_seconds": 0},
        ])
        ctx = _mock_ctx()
        with _patch_client(mock):
            await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        calls = ctx.report_progress.await_args_list
        assert len(calls) == 3
        assert calls[0].args[:2] == (2.0, 5.0)
        # Indeterminate: total=None, poll_counter increments 1, 2
        assert calls[1].args == (1, None)
        assert calls[2].args == (2, None)
        assert calls[1].kwargs["message"] == "still working"
        assert calls[2].kwargs["message"] == "still working more"

    @pytest.mark.asyncio
    async def test_progress_indeterminate_only(self) -> None:
        """No numerics ever — only message strings. poll_counter 1, 2, 3 with total=None."""
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_p5"}))
        mock.get_operation = self._script([
            {"status": "running", "progress": "msg a", "poll_after_seconds": 0},
            {"status": "running", "progress": "msg b", "poll_after_seconds": 0},
            {"status": "running", "progress": "msg c", "poll_after_seconds": 0},
        ])
        ctx = _mock_ctx()
        with _patch_client(mock):
            await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        calls = ctx.report_progress.await_args_list
        assert len(calls) == 3
        assert [c.args for c in calls] == [(1, None), (2, None), (3, None)]
        assert [c.kwargs["message"] for c in calls] == ["msg a", "msg b", "msg c"]

    @pytest.mark.asyncio
    async def test_progress_empty_poll_no_emission(self) -> None:
        """Poll with no numerics and no message: no emission that poll.

        Preserves the pre-fix behavior of never emitting on empty payloads.
        """
        mock = _mock_client(auto_map_controls=AsyncMock(return_value={"job_id": "job_p6"}))
        mock.get_operation = self._script([
            {"status": "running", "poll_after_seconds": 0},
            {"status": "running", "poll_after_seconds": 0},
        ])
        ctx = _mock_ctx()
        with _patch_client(mock):
            await auto_map_controls(server_version="0", model_id="tm-001", framework_id="f1", ctx=ctx)

        assert ctx.report_progress.await_count == 0


# ------------------------------------------------------------------
# Workspaces & Systems
# ------------------------------------------------------------------


class TestListWorkspaces:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await list_workspaces(server_version="0")
        assert "workspaces" in result


class TestListSystems:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await list_systems(server_version="0")
        assert "systems" in result


class TestGetSystem:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_system(server_version="0", system_id="sys-1")
        assert result["id"] == "sys-1"


class TestCreateSystem:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await create_system(server_version="0", name="Platform")
        assert result["id"] == "sys-2"


class TestAddModelToSystem:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await add_model_to_system(server_version="0", system_id="sys-1", model_id="tm-001")
        assert result["added"] is True


# ------------------------------------------------------------------
# System Compliance
# ------------------------------------------------------------------


class TestSelectSystemComplianceFrameworks:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await select_system_compliance_frameworks(server_version="0", system_id="sys-1", framework_ids="owasp-asvs")
        assert result["selected"] == 1


class TestGetSystemComplianceReport:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_system_compliance_report(server_version="0", system_id="sys-1", framework_id="owasp-asvs")
        assert result["coverage"] == 0.9


# ------------------------------------------------------------------
# Assertions & Verification
# ------------------------------------------------------------------


class TestSubmitAssertions:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await submit_assertions(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
                assertions_json=json.dumps([{"type": "file_exists", "params": {"path": "auth.py"}}]),
            )
        assert result["count"] == 2

    @pytest.mark.asyncio
    async def test_bad_json(self) -> None:
        with pytest.raises(ToolError, match="assertions_json must be valid JSON"):
            await submit_assertions(server_version="0", model_id="tm-001", control_id="CTRL-01", assertions_json="not-json")


class TestListAssertions:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await list_assertions(server_version="0", model_id="tm-001", control_id="CTRL-01")
        assert "assertions" in result


class TestDeleteAssertion:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await delete_assertion(server_version="0", model_id="tm-001", control_id="CTRL-01", assertion_id="a-1")
        assert result["deleted"] is True


class TestGetVerificationReport:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_verification_report(server_version="0", model_id="tm-001")
        assert result["tier1_pass"] == 3


# ------------------------------------------------------------------
# Findings
# ------------------------------------------------------------------


class TestSubmitFindings:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await submit_findings(
                server_version="0", model_id="tm-001",
                findings_json=json.dumps([{"control_id": "CTRL-01", "title": "Missing encryption"}]),
            )
        assert result["count"] == 1

    @pytest.mark.asyncio
    async def test_bad_json(self) -> None:
        with pytest.raises(ToolError, match="findings_json must be valid JSON"):
            await submit_findings(server_version="0", model_id="tm-001", findings_json="not-json")


class TestListFindings:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await list_findings(server_version="0", model_id="tm-001")
        assert "findings" in result


class TestUpdateFinding:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await update_finding(server_version="0", model_id="tm-001", finding_id="f1", status="acknowledged")
        assert result["status"] == "acknowledged"


# ------------------------------------------------------------------
# Scan Prompt
# ------------------------------------------------------------------


class TestGetScanPrompt:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_scan_prompt(server_version="0", model_id="tm-001")
        assert "prompt" in result




# ------------------------------------------------------------------
# Control Assumption Groups
# ------------------------------------------------------------------


class TestGetControlAssumptionGroups:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_control_assumption_groups(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
            )
        assert result["control_id"] == "CTRL-01"
        assert "1" in result["groups"]
        assert result["groups"]["1"][0]["id"] == "AS1"


class TestSetControlAssumptionGroups:
    @pytest.mark.asyncio
    async def test_single_group_single_member(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await set_control_assumption_groups(
                server_version="0",
                model_id="tm-001",
                control_id="CTRL-01",
                groups='{"1": ["AS1"]}',
                justification="AWS KMS handles this control.",
            )
        assert result["assumption_groups"] == {"1": ["AS1"]}

    @pytest.mark.asyncio
    async def test_compound_and_multi_group(self) -> None:
        mock = _mock_client()
        # Match the exact input — the mock returns whatever the fixture returns,
        # so we only need to verify the tool accepts the structure and forwards it.
        mock.set_control_assumption_groups = AsyncMock(return_value={
            "control_id": "CTRL-01",
            "assumption_groups": {"1": ["AS1", "AS2"], "2": ["AS3"]},
            "justification": "Either KMS+review or HSM.",
        })
        with _patch_client(mock):
            result = await set_control_assumption_groups(
                server_version="0",
                model_id="tm-001",
                control_id="CTRL-01",
                groups='{"1": ["AS1", "AS2"], "2": ["AS3"]}',
                justification="Either KMS+review or HSM.",
            )
        assert result["assumption_groups"] == {"1": ["AS1", "AS2"], "2": ["AS3"]}
        # Confirm the parsed dict was forwarded to the client (not the raw string)
        mock.set_control_assumption_groups.assert_awaited_once()
        call_args = mock.set_control_assumption_groups.call_args
        assert call_args.args[2] == {"1": ["AS1", "AS2"], "2": ["AS3"]}

    @pytest.mark.asyncio
    async def test_empty_groups_clears(self) -> None:
        mock = _mock_client()
        mock.set_control_assumption_groups = AsyncMock(return_value={
            "control_id": "CTRL-01",
            "assumption_groups": {},
            "justification": "",
        })
        with _patch_client(mock):
            # Empty groups: justification length check is bypassed.
            result = await set_control_assumption_groups(
                server_version="0",
                model_id="tm-001",
                control_id="CTRL-01",
                groups="{}",
            )
        assert result["assumption_groups"] == {}

    @pytest.mark.asyncio
    async def test_invalid_json_rejected(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            with pytest.raises(ToolError, match="valid JSON"):
                await set_control_assumption_groups(
                    server_version="0",
                    model_id="tm-001",
                    control_id="CTRL-01",
                    groups="not-json",
                    justification="long enough justification",
                )

    @pytest.mark.asyncio
    async def test_groups_not_object_rejected(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            with pytest.raises(ToolError, match="JSON object"):
                await set_control_assumption_groups(
                    server_version="0",
                    model_id="tm-001",
                    control_id="CTRL-01",
                    groups='["AS1"]',
                    justification="long enough justification",
                )

    @pytest.mark.asyncio
    async def test_short_justification_rejected_when_setting(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            with pytest.raises(ToolError, match="justification"):
                await set_control_assumption_groups(
                    server_version="0",
                    model_id="tm-001",
                    control_id="CTRL-01",
                    groups='{"1": ["AS1"]}',
                    justification="too short",
                )


# ------------------------------------------------------------------
# Per-entity GET tools + co_id filters
# ------------------------------------------------------------------


class TestPerIdGets:
    @pytest.mark.asyncio
    async def test_get_control_objective(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_control_objective(
                server_version="0", model_id="tm-001", co_id="CO3",
            )
        assert result["control_objective"]["id"] == "CO3"
        assert result["reachability_verdict"]["kind"] == "indeterminate"
        mock.get_control_objective.assert_awaited_once_with("tm-001", "CO3")

    @pytest.mark.asyncio
    async def test_get_asset(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_asset(
                server_version="0", model_id="tm-001", asset_id="A1",
            )
        assert result["asset"]["id"] == "A1"

    @pytest.mark.asyncio
    async def test_get_attacker(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_attacker(
                server_version="0", model_id="tm-001", attacker_id="T1",
            )
        assert result["attacker"]["id"] == "T1"

    @pytest.mark.asyncio
    async def test_get_component(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_component(
                server_version="0", model_id="tm-001", component_id="C1",
            )
        assert result["component"]["id"] == "C1"

    @pytest.mark.asyncio
    async def test_get_trust_boundary(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_trust_boundary(
                server_version="0", model_id="tm-001", tb_id="TB1",
            )
        assert result["trust_boundary"]["id"] == "TB1"
        assert "Network" in result["trust_boundary"]["passes"]

    @pytest.mark.asyncio
    async def test_get_assumption(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_assumption(
                server_version="0", model_id="tm-001", assumption_id="AS1",
            )
        assert result["assumption"]["id"] == "AS1"

    @pytest.mark.asyncio
    async def test_get_control(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            result = await get_control(
                server_version="0", model_id="tm-001", control_id="CTRL-01",
            )
        assert result["control"]["id"] == "CTRL-01"
        # Default version=0 maps to latest at the API layer.
        mock.get_control.assert_awaited_once_with("tm-001", "CTRL-01", version=0)


class TestCoIdFilters:
    @pytest.mark.asyncio
    async def test_reachability_co_id_passthrough(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            await get_reachability_verdicts(
                server_version="0", model_id="tm-001", co_id="CO3",
            )
        mock.model_reachability_verdicts.assert_awaited_once_with("tm-001", co_id="CO3")

    @pytest.mark.asyncio
    async def test_reachability_no_co_id(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            await get_reachability_verdicts(server_version="0", model_id="tm-001")
        mock.model_reachability_verdicts.assert_awaited_once_with("tm-001", co_id="")

    @pytest.mark.asyncio
    async def test_coherence_co_id_passthrough(self) -> None:
        mock = _mock_client()
        with _patch_client(mock):
            await model_coherence_report(
                server_version="0", model_id="tm-001", co_id="CO3",
            )
        mock.model_coherence_report.assert_awaited_once_with("tm-001", co_id="CO3")
