from __future__ import annotations

from ecss_poetry.vcs.git.backend import Git


__all__ = ["Git"]
