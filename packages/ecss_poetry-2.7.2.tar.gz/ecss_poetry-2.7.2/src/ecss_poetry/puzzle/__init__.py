from __future__ import annotations

from ecss_poetry.puzzle.solver import Solver


__all__ = ["Solver"]
