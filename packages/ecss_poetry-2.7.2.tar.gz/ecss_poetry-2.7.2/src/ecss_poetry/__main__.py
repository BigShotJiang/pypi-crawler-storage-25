from __future__ import annotations

import sys


if __name__ == "__main__":
    from ecss_poetry.console.application import main

    sys.exit(main())
