from __future__ import annotations

from ecss_poetry.layouts.layout import Layout
from ecss_poetry.layouts.src import SrcLayout


_LAYOUTS = {"src": SrcLayout, "standard": Layout}


def layout(name: str) -> type[Layout]:
    if name not in _LAYOUTS:
        raise ValueError("Invalid layout")

    return _LAYOUTS[name]
