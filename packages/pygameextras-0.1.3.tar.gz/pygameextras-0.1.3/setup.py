from setuptools import setup, find_packages

setup(
    name="PygameExtras",
    version="0.1.3",
    packages=find_packages(),
    install_requires=[],
    author="Marcus Collins",
    author_email="mjdj27123@gmail.com",
    description="Some extra classes and functions for pygame",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
    python_requires=">=3.6"
)