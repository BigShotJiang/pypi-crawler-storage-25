import pygame

class ImageButton:
    def __init__(self, rect: pygame.Rect, imageFilePath: str, onClick=None, bgColor: tuple[int, int, int]=(70, 70, 70), hoverColor: tuple[int, int, int]=(100, 100, 100), pressedColor: tuple[int, int, int]=(130, 130, 130)) -> None:
        self.rect = rect
        self.imageFilePath = imageFilePath
        self.onClick = onClick

        self.bgColor = bgColor
        self.hoverColor = hoverColor
        self.pressedColor = pressedColor

        self.hovered = False
        self.pressed = False

        self.LoadImage()

    def LoadImage(self) -> None:
        self.image = pygame.image.load(self.imageFilePath)
        self.image = pygame.transform.scale(self.image, (self.rect.width * 3 // 4, self.rect.height * 3 // 4))
        self.imageRect = self.image.get_rect(center=self.rect.center)

    def ChangeImageFilePath(self, imageFilePath: str) -> None:
        self.imageFilePath = imageFilePath
        self.LoadImage()
    
    def HandleEvent(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 and self.hovered:
                self.pressed = True
        
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1 and self.pressed and self.hovered and self.onClick:
                self.onClick()
            self.pressed = False

    def Draw(self, surface: pygame.Surface) -> None:
        color = self.pressedColor if self.pressed else self.hoverColor if self.hovered else self.bgColor
        pygame.draw.rect(surface, color, self.rect)
        surface.blit(self.image, self.imageRect)