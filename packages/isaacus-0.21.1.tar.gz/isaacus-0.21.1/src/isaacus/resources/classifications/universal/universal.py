# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.classifications.universal import universal_create_params
from ....types.classifications.universal.universal_classification_response import UniversalClassificationResponse

__all__ = ["UniversalResource", "AsyncUniversalResource"]


class UniversalResource(SyncAPIResource):
    """Classify documents with an Isaacus classification model."""

    @cached_property
    def with_raw_response(self) -> UniversalResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/isaacus-dev/isaacus-python#accessing-raw-response-data-eg-headers
        """
        return UniversalResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> UniversalResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/isaacus-dev/isaacus-python#with_streaming_response
        """
        return UniversalResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        model: Literal["kanon-universal-classifier"],
        query: str,
        texts: SequenceNotStr[str],
        is_iql: bool | Omit = omit,
        scoring_method: Literal["auto", "chunk_max", "chunk_avg", "chunk_min"] | Omit = omit,
        chunking_options: Optional[universal_create_params.ChunkingOptions] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UniversalClassificationResponse:
        """
        Classify documents with an Isaacus universal classification model.

        Args:
          model: The ID of the [model](https://docs.isaacus.com/models#universal-classification)
              to use for universal classification.

          query: The [Isaacus Query Language (IQL)](https://docs.isaacus.com/iql) query or, if
              IQL is disabled, the statement, to evaluate the texts against.

              The query must contain at least one non-whitespace character.

              Unlike the texts being classified, the query cannot be so long that it exceeds
              the maximum input length of the universal classifier.

          texts: The texts to classify.

              Each text must contain at least one non-whitespace character.

          is_iql: Whether the query should be interpreted as an
              [IQL](https://docs.isaacus.com/iql) query or else as a statement.

          scoring_method: The method to use for producing an overall confidence score.

              `auto` is the default scoring method and is recommended for most use cases.
              Currently, it is equivalent to `chunk_max`. In the future, it will automatically
              select the best method based on the model and inputs.

              `chunk_max` uses the highest confidence score of all of the texts' chunks.

              `chunk_avg` averages the confidence scores of all of the texts' chunks.

              `chunk_min` uses the lowest confidence score of all of the texts' chunks.

          chunking_options: Options for how to split text into smaller chunks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/classifications/universal",
            body=maybe_transform(
                {
                    "model": model,
                    "query": query,
                    "texts": texts,
                    "is_iql": is_iql,
                    "scoring_method": scoring_method,
                    "chunking_options": chunking_options,
                },
                universal_create_params.UniversalCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UniversalClassificationResponse,
        )


class AsyncUniversalResource(AsyncAPIResource):
    """Classify documents with an Isaacus classification model."""

    @cached_property
    def with_raw_response(self) -> AsyncUniversalResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/isaacus-dev/isaacus-python#accessing-raw-response-data-eg-headers
        """
        return AsyncUniversalResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncUniversalResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/isaacus-dev/isaacus-python#with_streaming_response
        """
        return AsyncUniversalResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        model: Literal["kanon-universal-classifier"],
        query: str,
        texts: SequenceNotStr[str],
        is_iql: bool | Omit = omit,
        scoring_method: Literal["auto", "chunk_max", "chunk_avg", "chunk_min"] | Omit = omit,
        chunking_options: Optional[universal_create_params.ChunkingOptions] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UniversalClassificationResponse:
        """
        Classify documents with an Isaacus universal classification model.

        Args:
          model: The ID of the [model](https://docs.isaacus.com/models#universal-classification)
              to use for universal classification.

          query: The [Isaacus Query Language (IQL)](https://docs.isaacus.com/iql) query or, if
              IQL is disabled, the statement, to evaluate the texts against.

              The query must contain at least one non-whitespace character.

              Unlike the texts being classified, the query cannot be so long that it exceeds
              the maximum input length of the universal classifier.

          texts: The texts to classify.

              Each text must contain at least one non-whitespace character.

          is_iql: Whether the query should be interpreted as an
              [IQL](https://docs.isaacus.com/iql) query or else as a statement.

          scoring_method: The method to use for producing an overall confidence score.

              `auto` is the default scoring method and is recommended for most use cases.
              Currently, it is equivalent to `chunk_max`. In the future, it will automatically
              select the best method based on the model and inputs.

              `chunk_max` uses the highest confidence score of all of the texts' chunks.

              `chunk_avg` averages the confidence scores of all of the texts' chunks.

              `chunk_min` uses the lowest confidence score of all of the texts' chunks.

          chunking_options: Options for how to split text into smaller chunks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/classifications/universal",
            body=await async_maybe_transform(
                {
                    "model": model,
                    "query": query,
                    "texts": texts,
                    "is_iql": is_iql,
                    "scoring_method": scoring_method,
                    "chunking_options": chunking_options,
                },
                universal_create_params.UniversalCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UniversalClassificationResponse,
        )


class UniversalResourceWithRawResponse:
    def __init__(self, universal: UniversalResource) -> None:
        self._universal = universal

        self.create = to_raw_response_wrapper(
            universal.create,
        )


class AsyncUniversalResourceWithRawResponse:
    def __init__(self, universal: AsyncUniversalResource) -> None:
        self._universal = universal

        self.create = async_to_raw_response_wrapper(
            universal.create,
        )


class UniversalResourceWithStreamingResponse:
    def __init__(self, universal: UniversalResource) -> None:
        self._universal = universal

        self.create = to_streamed_response_wrapper(
            universal.create,
        )


class AsyncUniversalResourceWithStreamingResponse:
    def __init__(self, universal: AsyncUniversalResource) -> None:
        self._universal = universal

        self.create = async_to_streamed_response_wrapper(
            universal.create,
        )
