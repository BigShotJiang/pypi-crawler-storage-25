"""Re-export the helper surface used by the public DaFab notebooks."""

from pathlib import Path

from dafab_client._rucio.dafab_lib import as_pretty_json as as_json

from .System.check_available_accounts import list_accounts, whoami
from .System.check_storage import check_storage, list_storages
from .check_server_health import ping
from .container_management.ensure_container import ensure_catalog, ensure_collection
from .container_management.list_containers import get_catalogs_and_collections, list_catalogs_and_collections
from .db_bootstrap.account_manager import add_rucio_account, add_rucio_identity
from .dataset_management.ensure_dataset import ensure_item
from .dataset_management.list_datasets import get_items
from .dataset_management.scope_management import ensure_scope_for_account, list_stac_scopes
from .did_management.operations import attach_stac_members, detach_stac_members, get_stac_objects
from .filtering.filter_by_bbox import get_items_by_bbox
from .filtering.filter_by_bbox_and_timerange import get_items_by_bbox_and_timerange
from .filtering.filter_by_enhanced_filter import get_items_by_enhanced_filter
from .filtering.filter_by_relationships import (
    get_item_ids_by_collection_field,
    get_item_ids_by_facet_value_catalog,
    get_item_ids_by_top_facet_catalog,
    get_related_item_ids_from_original_item,
    get_sibling_derived_item_ids,
    get_source_original_item_ids_from_derived_item,
)
from .filtering.filter_by_timerange import get_items_by_timerange
from .filtering.mapper import get_map
from .file_management.Workflows.manage_derived_assets import (
    build_stable_asset_href,
    download_all_derived_item_assets,
    download_asset_from_stable_href,
    download_item_asset,
    list_derived_items_with_missing_assets,
    list_item_asset_entries,
    publish_derived_asset,
)
from .file_management.Deletion.delete_file_of_scope_name import delete_file
from .file_management.Deletion.delete_replica_of_scope_name import delete_replica
from .metadata_management.Insertion.set_metadata import set_metadata
from .metadata_management.Preflight.validate_derived_item_file import validate_derived_item
from .metadata_management.Preflight.validate_facet_value_catalog_file import validate_facet_value_catalog_file
from .metadata_management.Preflight.validate_original_item_file import validate_original_item
from .metadata_management.Retrieval.Complete.get_metadata_for_scope_name import get_bulk_metadata
from .metadata_management.Retrieval.Partial.get_single_metadata_for_scope_name import extract_metadata_value
from .metadata_management.Workflows.sync_spatial_bbox_integrity import (
    sync_derived_collection_extent,
    sync_original_collection_extent,
)

__all__ = [
    "Path",
    "add_rucio_account",
    "add_rucio_identity",
    "as_json",
    "attach_stac_members",
    "build_stable_asset_href",
    "check_storage",
    "detach_stac_members",
    "delete_file",
    "delete_replica",
    "download_all_derived_item_assets",
    "download_asset_from_stable_href",
    "download_item_asset",
    "ensure_catalog",
    "ensure_collection",
    "ensure_item",
    "ensure_scope_for_account",
    "extract_metadata_value",
    "get_bulk_metadata",
    "get_catalogs_and_collections",
    "get_item_ids_by_collection_field",
    "get_item_ids_by_facet_value_catalog",
    "get_item_ids_by_top_facet_catalog",
    "get_items",
    "get_items_by_bbox",
    "get_items_by_bbox_and_timerange",
    "get_items_by_enhanced_filter",
    "get_items_by_timerange",
    "get_map",
    "get_related_item_ids_from_original_item",
    "get_sibling_derived_item_ids",
    "get_source_original_item_ids_from_derived_item",
    "get_stac_objects",
    "list_accounts",
    "list_catalogs_and_collections",
    "list_derived_items_with_missing_assets",
    "list_item_asset_entries",
    "list_stac_scopes",
    "list_storages",
    "ping",
    "publish_derived_asset",
    "set_metadata",
    "sync_derived_collection_extent",
    "sync_original_collection_extent",
    "validate_derived_item",
    "validate_facet_value_catalog_file",
    "validate_original_item",
    "whoami",
]
