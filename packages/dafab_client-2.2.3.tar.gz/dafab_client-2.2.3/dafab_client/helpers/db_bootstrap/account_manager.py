import inspect
import logging
import os
from time import sleep
from datetime import datetime
from pathlib import Path

from dafab_client._rucio.common.exception import AccountNotFound, Duplicate, AccessDenied
# import json_engine as jsn
# from psycopg2 import sql, connect, extras
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


cl = None


def _get_client():
    global cl
    if cl is None:
        cl = connection_manager()
    return cl

'''
def delete_token():
    import getpass
    from dafab_client._rucio.common.utils import get_tmp_dir
    try:
        token_file = get_tmp_dir() + '/.rucio_' + getpass.getuser() + '/auth_token_for_account_' + client_config['account']
        os.remove(token_file)
        LOG.info(f"Successfully deleted the file: {token_file}")
    except Exception as e:
        LOG.error(f"An error occurred while trying to delete the file: {e}")
'''


required_accounts_filepath = "accounts"

_satellite_containers = ["dafab"]
_scope = "dafab"

# Automatically detect the root directory of the project
root_path = Path(__file__).resolve().parent


# Initialize the client
'''
try:
    # delete_token()
    cl = Client(**client_config)

    # ping_result = _get_client().ping()
    # LOG.info(f"Server ping successful. Server version: {ping_result}")
    LOG.info("Client successfully initialized")
except CannotAuthenticate as ex:
    LOG.error(f"Authentication failed: {ex}")
    exit(1)
except Exception as _e:
    LOG.error(f"An error of type '{type(_e).__name__}' occurred while connecting to Rucio server: {_e}")
    exit(1)
'''


def list_class_methods(cls):
    """
    Lists all methods of a given class.

    This function retrieves and returns a list of method names implemented directly
    within a class, excluding inherited or indirectly-defined methods.

    Args:
        cls: The class object whose methods are to be listed.

    Returns:
        A list of strings where each string is the name of a method directly defined
        within the specified class.
    """
    methods = []
    for name, func in inspect.getmembers(cls, predicate=inspect.isfunction):
        if func.__qualname__.startswith(cls.__name__):
            methods.append(name)
    return methods


def list_inherited_methods(cls):
    """
    Lists all methods of each inherited class for the given class.

    The function iterates through the base classes of the provided class and
    prints the methods that each inherited class contains.

    Parameters:
    cls : type
        The class whose inherited classes' methods are to be listed.

    Returns:
    None
    """
    LOG.info("Listing methods for each inherited class of the Client class:\n")

    for base in cls.__bases__:
        LOG.info(f"Methods in '{base.__name__}':")
        methods = list_class_methods(base)
        for method in methods:
            LOG.info(f"  - {method}")
        LOG.info(" ")


def parse_required_accounts(file_path):
    """
    Parses a file containing account information and constructs a dictionary with
    names as keys and emails as values.

    The function reads a file where each line contains a name and an email,
    separated by a semicolon (;). Blank lines are ignored, and any surrounding
    whitespace in names or emails is stripped. Accounts are stored in a dictionary
    with the names as keys and their respective emails as values. If the file is
    not found or another exception occurs, appropriate error messages are printed.

    Arguments:
        file_path (str): The path to the file containing account information
        (name;email pairs separated by semicolons).

    Returns:
        dict: A dictionary where the keys are account names (str) and the values
        are emails (str).

    Raises:
        FileNotFoundError: If the file at the provided file path does not exist.
        Exception: If any other exceptions occur during file processing.
    """
    accounts_dict = {}
    try:
        with open(file_path) as file:
            for line in file:
                # Strip any leading/trailing whitespace characters (including newlines)
                line = line.strip()
                if line:  # Only process non-empty lines
                    name, email = line.split(';')
                    accounts_dict[name] = email
                    LOG.debug(f"Parsed account '{name}' with email '{email}' for registration.")
    except FileNotFoundError:
        LOG.warning(f"Error: The file at '{file_path}' was not found.")
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while parsing the accounts: {e}\n")
        exit(1)

    return accounts_dict


'''
def eo_feature_iterator(_directory):
    # Walk through each directory, subdirectory, and file
    for root, dirs, files in os.walk(_directory):
        for filename in files:
            if filename.endswith('.json'):
                # Get the town name from the filename
                _town = filename[5:].split(']')[0]

                # Full file path
                file_path = os.path.join(root, filename)

                with open(file_path, 'r') as file:
                    data = jsn.load(file)
                    # Check if the data has the 'features' key
                    if 'features' in data:
                        for _feature in data['features']:
                            yield _feature, _town
'''


def print_all_rucio_accounts():
    """
    Prints all Rucio accounts by fetching a list of accounts from the global `cl` object.

    This function retrieves a list of Rucio accounts using the global `cl` object's
    `list_accounts` method and prints each account. If an exception occurs during
    the process, it logs the error message and exits the program.

    Raises:
        Exception: If an error occurs during the execution of `_get_client().list_accounts`, the
        exception is caught and its type and message are printed to the standard output.
    """
    global cl
    try:
        # Call the list_accounts method
        _accounts = _get_client().list_accounts()
        # Iterate over the returned accounts and print them
        for account in _accounts:
            LOG.info(account)
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while listing accounts: {e}\n")
        exit(1)


def rucio_whoami():
    """
    Fetches and displays information about the current Rucio account and its global limits.

    This function connects to the Rucio REST API to retrieve the 'whoami' information about the
    current account using the global variable `cl`, then fetches the global account limits
    associated with the retrieved account. It prints the retrieved information to the console or
    logs errors in case of connection issues.

    Raises:
        Exception: Any exceptions encountered during the API requests are caught and logged,
        but not re-raised.
    """
    global cl

    # Make a request to the 'whoami' endpoint
    try:
        whoami_info = _get_client().whoami()
        LOG.info("Rucio REST-API 'whoami' response:", whoami_info)

        limits = _get_client().get_global_account_limits(whoami_info['account'])
        LOG.info(f"Global account limits for account '{whoami_info['account']}': {limits}")

    except Exception as e:
        LOG.error("Error connecting to Rucio REST-API:", e)


def add_rucio_account(account_name, email, account_type="USER", enforce_account_type=True):
    """
    Add a new Rucio account (or verify an existing one).

    If the account exists, email consistency is checked and (optionally) the
    expected account type is enforced. If it does not exist, it is created with
    the requested account type.

    Parameters:
        account_name (str): The name of the Rucio account to be verified or added.
        email (str): The associated email address for the Rucio account.
        account_type (str): Account classification in {'USER', 'GROUP', 'SERVICE'}.
            Defaults to 'USER'.
        enforce_account_type (bool): If True, raise when an existing account has
            a different type than the requested one. Defaults to True.

    Raises:
        ValueError: If account_type is invalid or existing type mismatches.
        Exception: In case of unexpected errors during account verification or creation.

    Returns:
        dict: Summary with keys `account`, `email`, `account_type`, `created`.
    """
    global cl

    if not isinstance(account_type, str):
        raise TypeError("account_type must be a string")

    normalized_type = account_type.upper()
    allowed_types = {"USER", "GROUP", "SERVICE"}
    if normalized_type not in allowed_types:
        raise ValueError(f"Invalid account_type '{account_type}'. Allowed values: {sorted(allowed_types)}")

    try:
        account_info = _get_client().get_account(account_name)
        existing_email = account_info.get("email")
        existing_type = str(account_info.get("account_type", "")).upper() or None

        if existing_email != email:
            LOG.info(
                f"Account '{account_name}' was found but with email '{existing_email}' instead of '{email}'. "
                "We are not changing it."
            )
        else:
            LOG.info(f"Account '{account_name}' was found with email '{existing_email}'.")

        if enforce_account_type and existing_type and existing_type != normalized_type:
            raise ValueError(
                f"Account '{account_name}' exists with type '{existing_type}' "
                f"but '{normalized_type}' was requested."
            )

        return {
            "account": account_name,
            "email": existing_email,
            "account_type": existing_type or normalized_type,
            "created": False,
        }

    except AccountNotFound:
        LOG.info(f"Account '{account_name}' with email '{email}' was not found. Adding it.")
        try:
            _get_client().add_account(account=account_name, type_=normalized_type, email=email)
        except AccessDenied as error:
            raise PermissionError(
                "Current account is not allowed to add new accounts on this server policy."
            ) from error
        LOG.info(
            f"Account '{account_name}' added successfully with email '{email}' and type '{normalized_type}'."
        )
        return {
            "account": account_name,
            "email": email,
            "account_type": normalized_type,
            "created": True,
        }
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while creating the account: {e}\n")
        raise


def add_multiple_rucio_accounts(required_accounts, account_type="USER"):
    """
    Add multiple Rucio accounts from a dictionary of accounts.

    :param required_accounts: A dictionary where keys are account names and values are emails.
    :param account_type: Account type used for all inserted accounts. Defaults to "USER".
    """
    for account_name, email in required_accounts.items():
        add_rucio_account(account_name, email, account_type=account_type)


def delete_rucio_account(account_name):
    """
    Deletes an existing Rucio account by its name. This function interacts with the global
    client instance to remove the specified account from the system. If the operation fails,
    an error message is printed and the program exits with an error code.

    Parameters:
        account_name (str): The name of the Rucio account to be deleted.
    """
    global cl
    try:
        # Delete an existing account
        _result = _get_client().delete_account(account_name)
        LOG.info(f"Account '{account_name}' deleted: {_result}.")
    except Exception as e:
        LOG.error(f"An error occurred while creating the account '{account_name}': {e}")
        exit(1)


def get_identities_for_account(account):
    """
    Fetches and prints identities associated with a specific account.

    This function retrieves identities linked to the given account through a global
    identity management system and logs the number of identities found along with their details.

    Arguments:
        account: The account identifier whose identities are to be retrieved.

    Returns:
        A list of identities associated with the given account.
    """
    global cl
    identities = list(_get_client().list_identities(account))
    LOG.info(f"Found {len(identities)} identities for account '{account}':")
    for identity in identities:
        LOG.info(identity)

    return identities


def add_rucio_identity(account, email, password=None, identity=None, authtype="userpass", default=True):
    """
    Adds a new identity and sets specific accounts as admins if necessary.

    The function adds an identity to the account with the specified email, authentication
    type, and optional password. If no identity is provided, it defaults to the account value.
    For accounts named 'xenakis' or 'dafab_admin', the function sets them as admins by
    adding the 'admin' attribute.

    Parameters:
    account (str): The name of the account for which the identity will be added.
    email (str): The email address associated with the identity.
    password (Optional[str]): The password for the identity. Defaults to None.
    identity (Optional[str]): The identity to be added. If None, defaults to the account.
    authtype (str): The authentication type for the identity. Defaults to 'userpass'.
    default (bool): Specifies whether the identity should be set as the default. Defaults to True.
    """
    global cl

    if not identity:
        identity = account

    try:
        # Add a new identity
        _result = _get_client().add_identity(account=account,
                                  identity=identity,
                                  authtype=authtype,
                                  email=email,
                                  default=default,
                                  password=password)
        LOG.info(f"Identity '{identity}' for account '{account}', email '{email}' "
                 f"and auth type '{authtype}' added successfully: {_result}")
    except Duplicate:
        LOG.warning(f"Identity '{identity}' for account '{account}', email '{email}' "
                    f"and auth type '{authtype}' exists")
        pass
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while adding "
                  f"the identity '{identity}' for account '{account}', email '{email}' "
                  f"and auth type '{authtype}': {e}")
        exit(1)

    # Make `xenakis` only account also admin
    if account in ["xenakis", "dafab_admin"]:
        try:
            # Add a new identity
            _result = _get_client().add_account_attribute(account=account, key='admin', value='True')
            LOG.info(f"Account '{account}' was successfully set as an admin: {_result}")
        except Exception as e:
            LOG.error(f"An error of type '{type(e).__name__}' occurred while making account '{account}' an admin': {e}")


def add_multiple_rucio_identities(required_accounts):
    """
    Add multiple Rucio identities from a dictionary of accounts.

    :param required_accounts: A dictionary where keys are account names and values are emails.
    """

    for account_name, email in required_accounts.items():
        add_rucio_identity(account_name, email, "dafab")


def delete_rucio_identity(account, identity=None, authtype="userpass"):
    """
    Deletes an identity associated with a Rucio account.

    This function is used to delete an existing identity from a Rucio account. It checks if an identity
    is provided, otherwise defaults to using the account as the identity. The specified identity and
    authentication type are removed from the account through the global client.

    Raises:
        Exception: If there is an error during the process of deleting the identity.

    Parameters:
        account (str): The Rucio account from which the identity will be removed.
        identity (str, optional): The identity to be removed. Defaults to None, in which case the account
            is used as the identity.
        authtype (str): The type of the authentication mechanism associated with the identity.
            Defaults to "userpass".
    """
    global cl

    if not identity:
        identity = account

    try:
        # Delete an existing account
        _result = _get_client().del_identity(account, identity, authtype)
        LOG.info(f"Identity '{identity}' of account '{account}' and type '{authtype}' deleted: {_result}.")
    except Exception as e:
        LOG.error(f"An error occurred while deleting identity '{identity}' "
                  f"for account '{account}' and auth type '{authtype}': {e}")


def ensure_scope(account_name, scope):
    """
    Ensures that a specific scope is added to an account and that the account is updated
    with a 'write' attribute corresponding to the given scope. If an error occurs during
    either the scope addition or attribute update, the function logs the error details.

    Parameters:
    account_name: str
        The name of the account to which the scope and attributes will be added.
    scope: str
        The scope to be added to the specified account.
    """
    global cl

    try:
        _get_client().add_scope(account=account_name, scope=scope)
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while adding scope '{scope}': {e}\n")

    try:
        _get_client().add_account_attribute(account=account_name, key='write', value=scope)
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while adding attributes\n")

'''
def ensure_containers(scope, dafab_containers):
    """
    Ensures that the dataset for the provided satellite collection is available
    """
    global cl

    for container_name in dafab_containers:
        # LOG.info(f"Ensuring dataset for satellite {sat}")

        try:
            try:
                container_result = _get_client().get_did(scope, container_name)
                if container_result['open']:
                    LOG.info(f"Container '{container_name}' is available and open.")
                else:
                    LOG.info(f"Container '{container_name}' is not available.")
                    exit(1)
            except DataIdentifierNotFound:
                LOG.warning(f"Container '{container_name}' does not exist. Creating it.")
                _get_client().add_container(scope=scope, name=container_name)
        except Exception as e:
            LOG.error(f"An error of type '{type(e).__name__}' occurred while checking for container '{container_name}': {e}\n")
'''

'''
def set_dafab_dataset(scope, did_name, town, dfe_feature_data, sat):
    global cl
    while True:
        try:
            # First let's ensure that the specific dataset exists
            try:
                try:
                    dataset_result = _get_client().get_did(scope, did_name)

                    if dataset_result['type'] != 'DATASET':
                        LOG.info(f"Dataset '{did_name}' was found to have a wrong type.")
                        exit(1)
                    else:
                        LOG.info(f"Dataset '{did_name}' already exists.")
                except DataIdentifierNotFound:
                    LOG.warning(f"Dataset '{did_name}' does not exist. Creating it.")
                    result = _get_client().add_dataset(scope=scope, name=did_name)
                    # LOG.warning(result)
            except Exception as e:
                LOG.error(f"An error of type '{type(e).__name__}' occurred while adding the dataset '{did_name}': {e}\n")
                continue

            # Ensure that the dataset of interest is linked to the correct container
            try:
                try:
                    result = _get_client().add_datasets_to_container(scope=scope, name=sat, dsns=[{'scope': scope, 'name': did_name}])
                except DuplicateContent:
                    LOG.warning(f"Dataset '{did_name}' is already in the container '{sat}'.")
                    pass
            except Exception as e:
                LOG.error(f"An error of type '{type(e).__name__}' occurred while linking the dataset '{did_name}': {e}\n")
                continue

            # Set metadata for the dataset
            # LOG.info("JSON data to store:")
            # LOG.info(jsn.dumps(dfe_feature_data, indent=2))

            try:
                # Add the key "town" which will be handled by the "JSON" plugin
                _get_client().set_metadata(scope=_scope,
                                name=did_name,
                                key='town',
                                value=town)

                _get_client().set_metadata(scope=_scope,
                                name=did_name,
                                key='{}',
                                value=dfe_feature_data)
            except Exception as e:
                LOG.error(f"An error of type '{type(e).__name__}' occurred while setting the metadata for the dataset '{did_name}': {e}\n")
                continue

            # In case no unexpected exception has triggered a retry, break the process to move on
            break

        except Exception as e:
            LOG.error(f"Exception: {e}. Retrying after 60s.")
            sleep(60)
            cl = Client(**client_config)
'''

'''
def add_bulk_dids_manually(bulk_content):

    global local_connection_params

    LOG.info(f"Processing {len(bulk_content)} items for bulk insertion")

    # Get current timestamp
    current_time = datetime.now()

    # Prepare the values for bulk insertion
    values_to_insert = []

    for scope, did_name, town, dfe_feature_data, sat in bulk_content:
        values_to_insert.append((
            scope,  # scope
            did_name,  # name
            'root',  # account
            'D',  # did_type (D for DATASET)
            True,  # is_open
            False,  # monotonic
            False,  # hidden
            False,  # obsolete
            True,  # is_new
            'A',  # availability (A for AVAILABLE)
            False,  # suppressed
            current_time,  # created_at
            current_time,  # updated_at
            False,  # transient
            True  # purge_replicas
        ))

    while True:
        try:
            # Connect to the PostgreSQL database
            conn = connect(**local_connection_params)
            cur = conn.cursor()

            # SQL query for bulk insertion
            insert_query = sql.SQL(
                """
                INSERT INTO dev.dids (scope, name, account, did_type, is_open, monotonic, hidden, obsolete, 
                                      is_new, availability, suppressed, created_at, updated_at, 
                                      transient, purge_replicas)
                VALUES %s
                ON CONFLICT (scope, name) DO NOTHING
                RETURNING scope, name;
                """)

            # LOG.info(values_to_insert)

            # Execute the bulk insertion
            extras.execute_values(cur, insert_query, values_to_insert)

            LOG.info("New DIDs inserted")
            conn.commit()
            break
        except Exception as e:
            LOG.error(f"Exception: {e}. Retrying after 60s.")
            sleep(60)
'''

'''
def add_bulk_metadata_manually(bulk_content):

    global local_connection_params

    LOG.info(f"Processing {len(bulk_content)} items for bulk insertion")

    # Prepare the values for bulk insertion
    values_to_insert = []

    for scope, did_name, town, dfe_feature_data, sat in bulk_content:
        values_to_insert.append((
            scope,  # scope
            did_name,  # name
            datetime.fromisoformat(dfe_feature_data['properties']['datetime']),  # created_at
            datetime.fromisoformat(dfe_feature_data['properties']['datetime']),  # updated_at
            jsn.dumps(dfe_feature_data),  # structured_meta
            float(dfe_feature_data['properties']['dfe:flood_detection']['surface_of_observed_water_bodies']),  # fix_var1
            str(dfe_feature_data['collection'])  # fix_var2
        ))

    while True:
        try:
            # Connect to the PostgreSQL database
            conn = connect(**local_connection_params)
            cur = conn.cursor()

            # SQL query for bulk insertion
            insert_query = sql.SQL(
                """
                INSERT INTO dev.did_meta (scope, name, created_at, updated_at, structured_meta, fix_var1, fix_var2)
                VALUES %s
                ON CONFLICT (scope, name) DO NOTHING
                RETURNING scope, name;
                """)

            # LOG.info(values_to_insert)

            # Execute the bulk insertion
            extras.execute_values(cur, insert_query, values_to_insert)

            LOG.info("New Metadata inserted")
            conn.commit()
            break
        except Exception as e:
            LOG.info(f"Exception: {e}. Retrying after 60s.")
            sleep(60)
'''

'''
def ensure_dafab_datasets(scope, base_eo_features, validate_schema=False, sql_bulk=False):
    global cl
    counter = 0
    bulk_content = []

    for feature_data, town in base_eo_features:
        # LOG.info(jsn.dumps(feature_data, indent=2))

        # We may also validate the STAC data
        if validate_schema:
            # Validate JSON data against the schema
            is_valid = jsn.validate_json(feature_data, jsn.dafab_feature_schema)
            if not is_valid:
                LOG.warning("JSON data is not valid against the schema.")
                exit()

        dfe_feature_data = jsn.expand_with_dfe_dummy_data(feature_data)
        # LOG.info(jsn.dumps(dfe_feature_data, indent=2))

        sat = dfe_feature_data.get('collection')
        did_name = dfe_feature_data.get('id')
        LOG.info(f"{counter}: Processing town '{town}' and sat '{sat}', the dataset '{did_name}'")

        if counter < 0:  # Use this to continue broken iterations
            continue

        if not sql_bulk:
            set_dafab_dataset(scope, did_name, town, dfe_feature_data, sat)
        else:
            bulk_content.append([scope, did_name, town, dfe_feature_data, sat])

        counter += 1

    if sql_bulk:
        add_bulk_dids_manually(bulk_content)
        add_bulk_metadata_manually(bulk_content)
'''

'''
def ensure_rse_and_protocol():

    global cl

    # 1. Add the RSE
    try:
        result = _get_client().add_rse(rse='DAFAB_RSE',
                            deterministic=False,
                            volatile=False,
                            city='Geneva',
                            region_code='GE',
                            country_name='Switzerland',
                            continent='EU',
                            time_zone='Europe/Zurich',
                            ISP='CERN',
                            staging_area=False,
                            latitude=6.143158,
                            longitude=46.204391,
                            ASN='CERN-ASN',
                            availability_read=True,
                            availability_write=True,
                            availability_delete=True)
        LOG.info(result)

    except Duplicate as e:
        LOG.warning(f"Skipping RSE 'DAFAB_RSE' creation as it already exists.")
    except Exception as e:
        LOG.error(f"An unexpected error occurred while trying to create RSE 'DAFAB_RSE': {e}")

    # 2. Add the WebDAV protocol
    try:
        protocol_params = {
            'scheme': 'https',
            'hostname': 'dafab.cern.ch',
            'port': 443,
            'prefix': '/data/',
            'impl': 'rucio.rse.protocols.webdav.Default',
            'domains': {
                'lan': {
                    'read': 1,
                    'write': 1,
                    'delete': 1
                },
                'wan': {
                    'read': 1,
                    'write': 1,
                    'delete': 1,
                    'third_party_copy_read': 1,
                    'third_party_copy_write': 1
                }
            }
        }
        result = _get_client().add_protocol(rse='DAFAB_RSE', params=protocol_params)
        LOG.info(result)

    except Exception as e:
        LOG.error(f"Error adding WebDAV protocol: {e}")

    # 3. Set only the essential attributes
    try:
        # Disable checksum verification for WebDAV
        _get_client().add_rse_attribute(rse='DAFAB_RSE', key='verify_checksum', value=False)

        # Set space limits to 50GB (in bytes) with some buffer
        total_space = 50 * (1024 ** 3)  # 50GB in bytes
        min_free_space = 5 * (1024 ** 3)  # Keep 5GB minimum free space
        _get_client().set_rse_limits(rse='DAFAB_RSE', name='MinFreeSpace', value=min_free_space)
        _get_client().set_rse_limits(rse='DAFAB_RSE', name='MaxUsedSpace', value=total_space)

    except Exception as e:
        LOG.error(f"Error setting attributes for WebDAV protocol: {e}")

    try:
        _get_client().add_account_attribute(account='xenakis', key='delete_replicas', value='DAFAB_RSE')
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while adding attributes\n")
'''

if __name__ == "__main__":
    # '''
    # Get user accounts from the local file structure
    _required_accounts = parse_required_accounts(required_accounts_filepath)

    # Python lib
    # list_inherited_methods(Client)

    # This must be executed from an admin account (set `_ACCOUNT = "root-dafab"` in `global_utils.py`.)
    # add_multiple_rucio_accounts(_required_accounts)  # Must be executed from an admin account

    # *****
    # print_all_rucio_accounts()  # Get all existing accounts
    # rucio_whoami()  # Check the current account
    # add_rucio_account("xenakis", "d.xenakis@ieee.org")
    # delete_rucio_account("xenakis")
    # *****

    # Identities (account creation must have been done prior to this)
    # add_rucio_identity(account='dafab_admin',
    #                    identity='CN=Dimitrios Xenakis,CN=877722,CN=dxenakis,OU=Users,OU=Organic Units,DC=cern,DC=ch',
    #                    authtype='x509',
    #                    email='d.xenakis@cern.ch')

    # To configure multiple accounts at once using a password.
    # add_multiple_rucio_identities(_required_accounts)

    # *****
    # get_identities_for_account("xenakis")
    # add_rucio_identity("xenakis", email="d.xenakis@ieee.orgs", password="dafab")
    # delete_rucio_identity("xenakis")
    # *****
    # '''

    # Assign a scope to a unique account
    ensure_scope(account_name='dafab_admin', scope='dafab')
    # ensure_scope(account_name='xenakis', scope='dafab')

    '''
    # Datasets
    ensure_containers(_scope, _satellite_containers)

    ensure_rse_and_protocol()

    # Data identifiers (Expensive run)
    # ensure_dafab_datasets(_scope, _base_eo_features, False, True)
    # *****
    # dids = _get_client().list_dids(_scope, [], "all", True, True)
    # LOG.info(len(list(dids)))
    # exit()
    # for did in dids:
    #     LOG.info(did)
    # *****

    # result = _get_client().list_dids("dafab", {})
    # LOG.info(len(list(result)))

    # LOG.info(_get_client().get_account("root"))
    # LOG.info(_get_client().get_config())
    # LOG.info(_get_client().account)

    # _get_client().set_metadata(scope=_scope,
    #                 name='S2B_MSIL1C_20240713T090559_N0510_R050_T34SGH_20240713T100243.SAFE',
    #                 key='town',
    #                 value='Anthousa')
    #
    # _get_client().set_metadata(scope=_scope,
    #                 name='S2B_MSIL1C_20240713T090559_N0510_R050_T34SGH_20240713T100243.SAFE',
    #                 key='{}',
    #                 value='{Anthousa}')

    # Get all JSON metadata
    # result = _get_client().get_metadata(scope=_scope,
    #                 name='S2A_MSIL2A_20240101T102431_N0510_R065_T31TGH_20240101T144052.SAFE',
    #                 plugin='DID_COLUMN')
    # LOG.info(result)

    # ************
    # # Validate JSON data against the schema
    # is_valid = jsn.validate_json(result, jsn.dafab_feature_schema)
    # if not is_valid:
    #     LOG.warning("JSON data is not valid against the schema.")
    # else:
    #     LOG.info("We fetched valid data")
    # ************

    # result3 = _get_client().get_metadata(scope=_scope,
    #                 name='S2A_MSIL2A_20240101T102431_N0510_R065_T31TGH_20240101T144052.SAFE',
    #                 plugin='JSON')
    # LOG.info(result3)
    # LOG.info(jsn.dumps(result3, indent=2))


    # =======
    # result = _get_client().get_did(scope=_scope,
    #                 name='S2A_MSIL2A_20240101T102431_N0510_R065_T31TGH_20240101T144052.SAFE')
    # LOG.info(result)
    # exit()
    # =======

    # =======
    # result = _get_client().get_metadata(scope='dafab',
    #                 name='S2A_MSIL2A_20240101T102431_N0510_R065_T31TGH_20240101T144052.SAFE',
    #                 plugin='STRUCTURED_JSON')
    # LOG.info(jsn.dumps(result, indent=2))
    # exit()
    # =======

    # =======
    # with open("rucio-workshops/metadata_example.json", 'r') as file:
    #     metadata_to_store = jsn.load(file)
    #
    # result = _get_client().set_metadata(scope=_scope,
    #                          name='S2A_MSIL2A_20240101T102431_N0510_R065_T31TGH_20240101T144052.SAFE',
    #                          key='{}',
    #                          value=metadata_to_store)
    # LOG.info(result)
    #
    # result = _get_client().get_metadata(scope=_scope,
    #                 name='S2A_MSIL2A_20240101T102431_N0510_R065_T31TGH_20240101T144052.SAFE',
    #                 plugin='STRUCTURED_JSON')
    # LOG.info(result)
    # LOG.info(jsn.dumps(result, indent=2))
    # =======
    '''

    LOG.info("Finish")
