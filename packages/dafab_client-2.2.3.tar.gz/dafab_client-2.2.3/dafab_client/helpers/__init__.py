"""Public helper namespace for DaFab notebooks and scripts."""

from . import demo_imports

__all__ = tuple(getattr(demo_imports, "__all__", ()))


def __getattr__(name: str):
    if name in __all__:
        return getattr(demo_imports, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
