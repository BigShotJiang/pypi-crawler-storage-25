"""Helpers to ensure container DIDs exist."""

from __future__ import annotations

from dafab_client._rucio.common.exception import DataIdentifierAlreadyExists, DataIdentifierNotFound
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


def _is_container(did: dict) -> bool:
    return str(did.get("type", "")).upper() == "CONTAINER"


def ensure_container(container_id: str, scope: str = "dafab") -> bool:
    """Ensure a container object exists for the provided scope/name.

    Args:
        container_id: Container identifier to verify/create.
        scope: Scope where the container should exist.

    Returns:
        bool: ``True`` when the container exists (pre-existing or created),
        otherwise ``False``.
    """
    cl = connection_manager()

    try:
        did = cl.get_did(scope=scope, name=container_id)
        if _is_container(did):
            LOG.result("Container '%s:%s' is present in Rucio database.", scope, container_id)
            return True
        LOG.error(
            "DID '%s:%s' exists but is not a container (type=%s).",
            scope,
            container_id,
            did.get("type"),
        )
        return False
    except DataIdentifierNotFound:
        pass

    try:
        cl.add_did(scope=scope, name=container_id, did_type="CONTAINER")
    except DataIdentifierAlreadyExists:
        pass
    except Exception as error:
        LOG.error("Failed to create container '%s:%s': %s", scope, container_id, error)
        return False

    try:
        did = cl.get_did(scope=scope, name=container_id)
    except Exception as error:
        LOG.error("Failed to fetch container '%s:%s' after creation: %s", scope, container_id, error)
        return False

    if _is_container(did):
        LOG.result("Container '%s:%s' is present in Rucio database.", scope, container_id)
        return True

    LOG.error(
        "DID '%s:%s' was created/fetched but is not a container (type=%s).",
        scope,
        container_id,
        did.get("type"),
    )
    return False


def ensure_catalog(catalog_id: str = "stac", scope: str = "dafab") -> bool:
    """Ensure the STAC catalog object exists.

    Args:
        catalog_id: Catalog identifier (defaults to ``"stac"``).
        scope: Scope where the catalog should exist.

    Returns:
        bool: ``True`` when available, ``False`` otherwise.
    """
    return ensure_container(container_id=catalog_id, scope=scope)


def ensure_collection(collection_id: str, scope: str = "dafab") -> bool:
    """Ensure a STAC collection object exists.

    Args:
        collection_id: Collection identifier to verify/create.
        scope: Scope where the collection should exist.

    Returns:
        bool: ``True`` when available, ``False`` otherwise.
    """
    return ensure_container(container_id=collection_id, scope=scope)
