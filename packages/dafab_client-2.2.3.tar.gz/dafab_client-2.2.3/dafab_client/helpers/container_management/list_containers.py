"""Helpers for discovering container level DIDs registered in Rucio."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from dafab_client._rucio.dafab_lib import as_pretty_json, connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


_DEFAULT_FILTER = {"name": "*"}


def _normalize_filters(filters: Any) -> list[dict[str, Any]]:
    """Ensure that ``filters`` follow the format expected by ``list_dids``."""
    if filters is None:
        return [_DEFAULT_FILTER.copy()]
    if isinstance(filters, dict):
        return [filters]
    if isinstance(filters, Iterable):
        return list(filters)
    raise TypeError("filters must be a dict, an iterable of dicts, or None")


def get_containers(
        scope: str = "dafab",
        filters: Any = None,
        long: bool = True,
        recursive: bool = False,
) -> list[dict[str, Any]]:
    """Return container objects that match the supplied filters.

    Args:
        scope: Scope to query.
        filters: Query filter dict (or list of dicts) forwarded to the client.
        long: Request long-form entries from the backend.
        recursive: Enable recursive lookup in nested structures.

    Returns:
        list[dict[str, Any]]: Container entries returned by the backend.
    """

    normalized_filters = _normalize_filters(filters)
    containers = connection_manager().list_dids(
        scope=scope,
        filters=normalized_filters,
        did_type="container",
        long=long,
        recursive=recursive,
    )
    return list(containers)


def list_containers(scope: str = "dafab", **kwargs: Any) -> None:
    """Log container entries discovered in ``scope``.

    Args:
        scope: Scope to query.
        **kwargs: Forwarded to :func:`get_containers`.
    """

    containers = get_containers(scope=scope, **kwargs)
    if not containers:
        LOG.result("No containers found in scope '%s'", scope)
        return

    LOG.info("Containers found in scope '%s':", scope)
    for container in containers:
        LOG.result(as_pretty_json(container))


def get_catalogs_and_collections(
        scope: str = "dafab",
        filters: Any = None,
        recursive: bool = False,
) -> list[dict[str, str]]:
    """Return STAC navigation nodes represented as container objects.

    Args:
        scope: Scope to query.
        filters: Optional container filters.
        recursive: Enable recursive lookup in nested structures.

    Returns:
        list[dict[str, str]]: Normalized entries with ``scope`` and ``id`` keys.
    """

    containers = get_containers(scope=scope, filters=filters, long=True, recursive=recursive)
    nodes: list[dict[str, str]] = []

    for container in containers:
        if isinstance(container, dict):
            name = str(container.get("name") or "")
            node_scope = str(container.get("scope") or scope)
        else:
            name = str(container)
            node_scope = scope

        if not name:
            continue
        nodes.append({"scope": node_scope, "id": name})

    return nodes


def list_catalogs_and_collections(scope: str = "dafab", **kwargs: Any) -> None:
    """Log catalog/collection identifiers discovered in ``scope``.

    Args:
        scope: Scope to query.
        **kwargs: Forwarded to :func:`get_catalogs_and_collections`.
    """

    nodes = get_catalogs_and_collections(scope=scope, **kwargs)
    if not nodes:
        LOG.result("No STAC catalogs/collections found in scope '%s'", scope)
        return

    LOG.info("STAC catalogs/collections found in scope '%s':", scope)
    for node in nodes:
        LOG.result(node["id"])


if __name__ == "__main__":
    list_containers()
