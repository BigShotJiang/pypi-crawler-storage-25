import argparse

from dafab_client.helpers.metadata_management.Operations.common import apply_metadata_operation_to_did


def delete_metadata_for_did(
        product_name: str,
        path: str = "",
        scope: str = "dafab",
        *,
        mode: str = "atomic",
) -> bool:
    """Apply patch operation `delete` for one DID."""
    return apply_metadata_operation_to_did(
        product_name=product_name,
        op="delete",
        path=path,
        scope=scope,
        mode=mode,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Delete metadata at a JSON pointer path for a DID.")
    parser.add_argument("product_name", type=str,
                        help="Name of the Copernicus product (e.g., S2B_43QDB_20240408_0_L2A).")
    parser.add_argument("path", nargs="?", default="",
                        help="JSON Pointer (or legacy comma path). Empty path clears the full document.")
    parser.add_argument("--scope", default="dafab",
                        help="Scope that contains the product. Defaults to 'dafab'.")
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic",
                        help="BulkMetaDoc execution mode. Defaults to 'atomic'.")

    args = parser.parse_args()
    success = delete_metadata_for_did(
        product_name=args.product_name,
        path=args.path,
        scope=args.scope,
        mode=args.mode,
    )
    exit(0 if success else 1)
