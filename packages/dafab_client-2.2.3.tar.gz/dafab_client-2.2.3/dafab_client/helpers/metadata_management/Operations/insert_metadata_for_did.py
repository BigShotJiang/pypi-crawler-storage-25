import argparse
from typing import Any

from dafab_client.helpers.metadata_management.Operations.common import apply_metadata_operation_to_did, load_value_from_cli


def insert_metadata_for_did(
        product_name: str,
        path: str,
        value: Any,
        scope: str = "dafab",
        *,
        mode: str = "atomic",
) -> bool:
    """Apply patch operation `insert` for one DID."""
    return apply_metadata_operation_to_did(
        product_name=product_name,
        op="insert",
        path=path,
        value=value,
        scope=scope,
        mode=mode,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Insert metadata at a JSON pointer path for a DID.")
    parser.add_argument("product_name", type=str,
                        help="Name of the Copernicus product (e.g., S2B_43QDB_20240408_0_L2A).")
    parser.add_argument("path", type=str,
                        help="JSON Pointer (or legacy comma path) where the value will be inserted.")
    parser.add_argument("--scope", default="dafab",
                        help="Scope that contains the product. Defaults to 'dafab'.")
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic",
                        help="BulkMetaDoc execution mode. Defaults to 'atomic'.")
    parser.add_argument("--value-json", default=None,
                        help="JSON value for the insert operation.")
    parser.add_argument("--value-file", default=None,
                        help="Path to a JSON file used as value for the insert operation.")

    args = parser.parse_args()
    value = load_value_from_cli(args.value_json, args.value_file, op="insert")
    success = insert_metadata_for_did(
        product_name=args.product_name,
        path=args.path,
        value=value,
        scope=args.scope,
        mode=args.mode,
    )
    exit(0 if success else 1)
