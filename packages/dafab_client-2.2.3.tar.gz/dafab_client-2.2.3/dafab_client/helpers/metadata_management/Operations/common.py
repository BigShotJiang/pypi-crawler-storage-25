"""Shared execution helpers for single-DID metadata patch operations."""

from __future__ import annotations

import json
import time
import traceback
from pathlib import Path
from typing import Any

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger
from dafab_client.helpers.metadata_management.document_api import build_patch_operation

LOG = setup_logger(__name__)
_MISSING = object()


def apply_metadata_operation_to_did(
        product_name: str,
        *,
        op: str,
        path: str,
        value: Any = _MISSING,
        scope: str = "dafab",
        mode: str = "atomic",
        max_retries: int = 5,
        retry_delay: int = 30,
) -> bool:
    """Apply one metadata patch operation to a single DID."""
    if value is _MISSING:
        operation = build_patch_operation(op=op, path=path)
    else:
        operation = build_patch_operation(op=op, path=path, value=value)

    for attempt in range(max_retries):
        try:
            cl = connection_manager()
            response = cl.patch_metadata_document(
                scope=scope,
                name=product_name,
                operations=[operation],
                mode=mode,
            )
            if mode == "best_effort" and isinstance(response, dict):
                failed_dids = response.get("failed_dids") or []
                if failed_dids:
                    first_failure = failed_dids[0] if isinstance(failed_dids[0], dict) else {"error": failed_dids[0]}
                    LOG.warning(
                        "Metadata %s operation failed for '%s' in best_effort mode: %s",
                        operation["op"],
                        product_name,
                        first_failure,
                    )
                    return False
            LOG.result(
                "Metadata %s operation succeeded for dataset '%s' at path '%s' (scope=%s).",
                operation["op"],
                product_name,
                operation["path"],
                scope,
            )
            return True
        except Exception as exc:
            LOG.warning(
                "Attempt %s/%s failed while applying %s on '%s' at '%s': %s",
                attempt + 1,
                max_retries,
                op,
                product_name,
                path,
                exc,
            )
            traceback.print_exc()
            if attempt < max_retries - 1:
                LOG.warning("Retrying in %s seconds...", retry_delay)
                time.sleep(retry_delay)

    LOG.warning("All retry attempts exhausted.")
    return False


def load_json_file(path: str | Path, *, base_dir: str | Path | None = None) -> Any:
    """Load and parse JSON from file."""
    resolved_path = Path(path).expanduser()
    if not resolved_path.is_absolute() and base_dir is not None and not resolved_path.exists():
        resolved_path = Path(base_dir) / resolved_path
    with open(resolved_path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def load_value_from_cli(value_json: str | None, value_file: str | None, *, op: str) -> Any:
    """Resolve CLI value input for insert/update/upsert operations."""
    if value_json is not None and value_file is not None:
        raise SystemExit("Use either --value-json or --value-file, not both.")
    if value_file is not None:
        return load_json_file(value_file)
    if value_json is not None:
        return json.loads(value_json)
    raise SystemExit(f"Operation '{op}' requires --value-json or --value-file.")
