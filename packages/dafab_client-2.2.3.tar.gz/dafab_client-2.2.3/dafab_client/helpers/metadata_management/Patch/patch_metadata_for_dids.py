import json
import argparse
from typing import Any, Sequence

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger
from dafab_client.helpers.metadata_management.document_api import build_patch_operation

LOG = setup_logger(__name__)
_MISSING = object()


def patch_metadata_for_dids(
        product_names: Sequence[str],
        *,
        op: str,
        path: str = "",
        value: Any = _MISSING,
        scope: str = "dafab",
        mode: str = "atomic",
) -> dict[str, Any]:
    """Apply one metadata document operation to multiple item identifiers.

    Args:
        product_names: Target item ids. Empty/blank entries are ignored.
        op: Operation name (``insert``, ``update``, ``upsert``, ``delete``).
        path: JSON Pointer-like target path. Empty string targets the document root.
        value: Operation payload for non-delete operations.
        scope: Namespace containing all target items.
        mode: Bulk execution strategy (``atomic`` or ``best_effort``).

    Returns:
        dict[str, Any]: Raw patch response normalized to a dictionary.
    """
    names = [name.strip() for name in product_names if name and name.strip()]
    if not names:
        raise ValueError("At least one DID name is required.")

    op_norm = op.strip().lower()
    if op_norm == "delete":
        operation = build_patch_operation(op=op_norm, path=path)
    else:
        if value is _MISSING:
            raise ValueError(f"Operation '{op_norm}' requires a JSON value.")
        operation = build_patch_operation(op=op_norm, path=path, value=value)

    dids = [{"scope": scope, "name": name} for name in names]
    result = connection_manager().patch_metadata_document_bulk(
        dids=dids,
        operations=[operation],
        mode=mode,
    )
    return result if isinstance(result, dict) else {"response": result}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Apply one metadata patch operation to multiple DIDs.")
    parser.add_argument("op", choices=("insert", "update", "upsert", "delete"),
                        help="Operation to apply.")
    parser.add_argument("path", nargs="?", default="",
                        help="JSON Pointer or legacy comma path. Empty path targets the full document root.")
    parser.add_argument("--name", action="append", required=True,
                        help="Dataset DID name. Repeat --name for multiple DIDs.")
    parser.add_argument("--scope", default="dafab",
                        help="Scope that contains the DIDs. Defaults to 'dafab'.")
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic",
                        help="BulkMetaDoc execution mode. Defaults to 'atomic'.")
    parser.add_argument("--value-json", default=None,
                        help="JSON value for insert/update/upsert operations.")
    parser.add_argument("--value-file", default=None,
                        help="Path to a JSON file used as value for insert/update/upsert operations.")

    args = parser.parse_args()

    if args.value_json is not None and args.value_file is not None:
        raise SystemExit("Use either --value-json or --value-file, not both.")

    if args.op == "delete":
        if args.value_json is not None or args.value_file is not None:
            raise SystemExit("Delete operations do not accept --value-json or --value-file.")
        value = _MISSING
    else:
        if args.value_file is not None:
            with open(args.value_file, "r", encoding="utf-8") as handle:
                value = json.load(handle)
        elif args.value_json is not None:
            value = json.loads(args.value_json)
        else:
            raise SystemExit(f"Operation '{args.op}' requires --value-json or --value-file.")

    try:
        result = patch_metadata_for_dids(
            product_names=args.name,
            op=args.op,
            path=args.path,
            value=value,
            scope=args.scope,
            mode=args.mode,
        )
    except Exception as exc:
        LOG.error("Failed to patch metadata for DIDs: %s", exc)
        raise SystemExit(1)

    LOG.result(json.dumps(result, indent=2, default=str))
