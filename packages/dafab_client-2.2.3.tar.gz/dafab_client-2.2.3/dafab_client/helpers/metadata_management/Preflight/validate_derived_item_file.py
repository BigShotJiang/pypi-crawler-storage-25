"""Validate derived-item metadata against the DaFab STAC contract."""

from __future__ import annotations

import argparse
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, Optional
from urllib.parse import urlparse

from jsonschema import Draft202012Validator, FormatChecker

from dafab_client._rucio.common.exception import DataIdentifierNotFound
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

from dafab_client.helpers.metadata_management.Operations.common import load_json_file
from dafab_client.helpers.metadata_management.Workflows.update_derived_item import (
    sync_derived_item_contract,
)
from dafab_client.helpers.runtime_paths import load_json_schema

LOG = setup_logger(__name__)

COLLECTION_TYPE_FILTER_PAYLOAD = {
    "filter": {
        "type": "comparison",
        "comparator": "equals",
        "path": ["type"],
        "value": "Collection",
        "valueType": "string",
    }
}

DEFAULT_SCHEMA_BY_COLLECTION: dict[str, str] = {
    "water_analysis": "dafab-water_analysis-item.schema.json",
    "smart_agriculture": "dafab-smart_agriculture-item.schema.json",
}

PROFILE_BLOCK_BY_COLLECTION: dict[str, tuple[str, str]] = {
    "water_analysis": ("dafab:water-analysis", "water_analysis_algorithm_version"),
    "smart_agriculture": ("dafab:smart-agriculture", "smart_agriculture_algorithm_version"),
}

ValidationPhase = Literal["pre_publish", "post_publish"]
ValidationSource = Literal["local", "server"]
RFC3339_TIMESTAMP_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+\-]\d{2}:\d{2})$"
)


def _resolve_validation_phase(
        *,
        source: ValidationSource,
        post_publish: Optional[bool],
) -> ValidationPhase:
    if post_publish is not None:
        return "post_publish" if post_publish else "pre_publish"
    return "post_publish" if source == "server" else "pre_publish"


def _normalize_collection_id(value: str) -> str:
    return value.strip().lower().replace("-", "_")


def _schema_errors(payload: Any, schema: dict[str, Any]) -> list[str]:
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(payload), key=lambda error: list(error.absolute_path))
    output: list[str] = []
    for error in errors:
        path = "/".join(str(token) for token in error.absolute_path) or "<root>"
        output.append(f"schema:{path}: {error.message}")
    output.extend(_schema_format_errors(payload=payload, schema=schema))
    return output


def _schema_format_errors(
        *,
        payload: Any,
        schema: Any,
        path: tuple[str | int, ...] = (),
) -> list[str]:
    if not isinstance(schema, dict):
        return []

    output: list[str] = []
    schema_format = schema.get("format")
    if isinstance(schema_format, str):
        location = "/".join(str(token) for token in path) or "<root>"
        if schema_format == "date-time":
            _, timestamp_error = _parse_timestamp(payload)
            if timestamp_error:
                output.append(f"schema:{location}: invalid date-time format.")
        elif schema_format == "uri":
            if not isinstance(payload, str):
                output.append(f"schema:{location}: invalid uri format.")
            else:
                parsed = urlparse(payload)
                if not parsed.scheme or not parsed.netloc:
                    output.append(f"schema:{location}: invalid uri format.")

    properties = schema.get("properties")
    if isinstance(properties, dict) and isinstance(payload, dict):
        for key, property_schema in properties.items():
            if key in payload:
                output.extend(
                    _schema_format_errors(
                        payload=payload[key],
                        schema=property_schema,
                        path=path + (key,),
                    )
                )

    item_schema = schema.get("items")
    if isinstance(payload, list) and isinstance(item_schema, dict):
        for index, item in enumerate(payload):
            output.extend(
                _schema_format_errors(
                    payload=item,
                    schema=item_schema,
                    path=path + (index,),
                )
            )

    return sorted(set(output))


def _collect_hrefs_by_rel(links: Any) -> dict[str, list[str]]:
    hrefs_by_rel: dict[str, list[str]] = {}
    if not isinstance(links, list):
        return hrefs_by_rel
    for link in links:
        if not isinstance(link, dict):
            continue
        rel = link.get("rel")
        href = link.get("href")
        if not isinstance(rel, str) or not isinstance(href, str):
            continue
        hrefs_by_rel.setdefault(rel, []).append(href)
    return hrefs_by_rel


def _last_path_segment(href: str) -> str:
    parsed = urlparse(href)
    segment = parsed.path.rstrip("/").split("/")[-1]
    return segment[:-5] if segment.endswith(".json") else segment


def _collection_segment_from_item_href(href: str) -> Optional[str]:
    parsed = urlparse(href)
    tokens = [token for token in parsed.path.strip("/").split("/") if token]
    for index, token in enumerate(tokens):
        if token == "collections" and index + 1 < len(tokens):
            return _normalize_collection_id(tokens[index + 1])
    return None


def _parse_timestamp(value: Any) -> tuple[Optional[datetime], Optional[str]]:
    if not isinstance(value, str) or not value.strip():
        return None, "missing or empty timestamp value."
    if RFC3339_TIMESTAMP_RE.match(value.strip()) is None:
        return None, f"timestamp '{value}' is not RFC3339 compliant."
    candidate = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(candidate), None
    except ValueError:
        return None, f"timestamp '{value}' is not parseable as RFC3339."


def _validate_bbox(bbox: Any) -> tuple[Optional[bool], Optional[str]]:
    if not isinstance(bbox, list):
        return False, "bbox must be a list."
    if len(bbox) not in (4, 6):
        return False, "bbox must have either 4 (2D) or 6 (3D) numeric values."
    if not all(isinstance(v, (int, float)) for v in bbox):
        return False, "bbox values must be numeric."
    if len(bbox) == 4 and (bbox[0] > bbox[2] or bbox[1] > bbox[3]):
        return False, "bbox has invalid 2D min/max ordering."
    if len(bbox) == 6 and (bbox[0] > bbox[3] or bbox[1] > bbox[4] or bbox[2] > bbox[5]):
        return False, "bbox has invalid 3D min/max ordering."
    return True, None


def _normalized_bbox_for_compare(bbox: Any) -> Optional[tuple[float, ...]]:
    bbox_ok, _ = _validate_bbox(bbox)
    if not bbox_ok or not isinstance(bbox, list):
        return None
    return tuple(float(value) for value in bbox)


def _extract_document(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    document = payload.get("document")
    if isinstance(document, dict):
        return document
    return payload


def _extract_items_from_stac_filter_response(response: Any) -> list[dict[str, Any]]:
    if not isinstance(response, list) or not response:
        return []
    items: list[dict[str, Any]] = []
    for entry in response:
        if not isinstance(entry, dict):
            continue
        entry_items = entry.get("items")
        if not isinstance(entry_items, list):
            continue
        items.extend([item for item in entry_items if isinstance(item, dict)])
    return items


def _list_collection_ids_via_filter(client: Any, *, scope: str) -> tuple[list[str], Optional[str]]:
    try:
        response = list(client.stac_filter({"scope": scope, **COLLECTION_TYPE_FILTER_PAYLOAD}))
    except Exception as exc:
        return [], f"collection_discovery: failed to list collections via filter: {exc}"

    collection_items = _extract_items_from_stac_filter_response(response)
    return sorted(
        {
            _normalize_collection_id(item_id)
            for item in collection_items
            if isinstance((item_id := item.get("id")), str)
        },
        key=len,
        reverse=True,
    ), None


def _split_derived_item_identifier(
        item_id: str,
        *,
        collection_ids: list[str],
        href_collection_id: Optional[str] = None,
) -> tuple[Optional[dict[str, str]], Optional[str]]:
    if "_" not in item_id:
        return None, "item id has no '_' separator to extract version."

    body, version = item_id.rsplit("_", 1)
    if not version.isdigit():
        return None, f"item version suffix '{version}' is not numeric."

    preferred_collections: list[str] = []
    if isinstance(href_collection_id, str) and href_collection_id.strip():
        preferred_collections.append(_normalize_collection_id(href_collection_id))
    for collection_id in sorted(collection_ids, key=len, reverse=True):
        normalized = _normalize_collection_id(collection_id)
        if normalized not in preferred_collections:
            preferred_collections.append(normalized)

    for collection_id in preferred_collections:
        marker = f"_{collection_id}"
        if not body.endswith(marker):
            continue
        original_item_id = body[:-len(marker)]
        if not original_item_id:
            return None, (
                f"item id '{item_id}' has empty original-item component before collection '{collection_id}'."
            )
        return {
            "original_item_id": original_item_id,
            "collection_id": collection_id,
            "version": version,
        }, None

    return None, (
        f"could not map item id '{item_id}' to any known collection id "
        f"(candidates: {preferred_collections if preferred_collections else '<none>'})."
    )


def _did_exists_with_type_with_error(
        client: Any,
        scope: str,
        name: str,
        expected_type: str,
) -> tuple[Optional[bool], Optional[str]]:
    try:
        did = client.get_did(scope=scope, name=name)
    except DataIdentifierNotFound:
        return False, None
    except Exception as exc:
        return None, f"catalog_state: failed to read object '{scope}:{name}': {exc}"
    return str(did.get("type", "")).upper() == expected_type.upper(), None


def _did_exists_with_type(client: Any, scope: str, name: str, expected_type: str) -> bool:
    exists, _ = _did_exists_with_type_with_error(client, scope, name, expected_type)
    return bool(exists)


def _is_child_attached_with_error(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        child_name: str,
) -> tuple[Optional[bool], Optional[str]]:
    try:
        content_entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception as exc:
        return None, f"catalog_state: failed to list members of '{scope}:{parent_name}': {exc}"
    for child in content_entries:
        if not isinstance(child, dict):
            continue
        child_scope = child.get("scope")
        child_scope_text = str(child_scope) if child_scope is not None else scope
        if child_scope_text == scope and child.get("name") == child_name:
            return True, None
    return False, None


def _is_child_attached(client: Any, *, scope: str, parent_name: str, child_name: str) -> bool:
    attached, _ = _is_child_attached_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        child_name=child_name,
    )
    return bool(attached)


def _list_child_names_by_type_with_error(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        expected_type: str,
) -> tuple[list[str], Optional[str]]:
    try:
        content_entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception as exc:
        return [], f"catalog_state: failed to list members of '{scope}:{parent_name}': {exc}"

    expected = expected_type.upper()
    names: set[str] = set()
    type_resolution_errors: list[str] = []
    for entry in content_entries:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name")
        if not isinstance(name, str) or not name.strip():
            continue
        entry_scope = entry.get("scope")
        entry_scope_text = str(entry_scope) if entry_scope is not None else scope
        if entry_scope_text != scope:
            continue
        entry_type = entry.get("type")
        if isinstance(entry_type, str):
            resolved_type = entry_type.upper()
        else:
            container_exists, did_error = _did_exists_with_type_with_error(client, scope, name, "CONTAINER")
            if did_error:
                type_resolution_errors.append(did_error)
                continue
            resolved_type = "CONTAINER" if container_exists else "DATASET"
        if resolved_type == expected:
            names.add(name)
    if type_resolution_errors:
        return sorted(names), "; ".join(sorted(set(type_resolution_errors)))
    return sorted(names), None


def _list_child_names_by_type(client: Any, *, scope: str, parent_name: str, expected_type: str) -> list[str]:
    names, _ = _list_child_names_by_type_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        expected_type=expected_type,
    )
    return names


def _list_container_children_with_error(client: Any, *, scope: str, parent_name: str) -> tuple[list[str], Optional[str]]:
    return _list_child_names_by_type_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        expected_type="CONTAINER",
    )


def _list_container_children(client: Any, *, scope: str, parent_name: str) -> list[str]:
    names, _ = _list_container_children_with_error(client, scope=scope, parent_name=parent_name)
    return names


def _list_facet_value_catalog_ids_with_error(
        client: Any,
        *,
        scope: str,
        collection_id: str,
) -> tuple[list[str], Optional[str]]:
    facet_value_catalog_ids: set[str] = set()
    facet_errors: list[str] = []
    facet_parent_catalog_ids, parent_error = _list_container_children_with_error(
        client,
        scope=scope,
        parent_name=collection_id,
    )
    if parent_error:
        facet_errors.append(parent_error)
    for facet_parent_catalog_id in facet_parent_catalog_ids:
        facet_value_ids, facet_value_error = _list_container_children_with_error(
            client,
            scope=scope,
            parent_name=facet_parent_catalog_id,
        )
        facet_value_catalog_ids.update(facet_value_ids)
        if facet_value_error:
            facet_errors.append(facet_value_error)
    if facet_errors:
        return sorted(facet_value_catalog_ids), "; ".join(sorted(set(facet_errors)))
    return sorted(facet_value_catalog_ids), None


def _list_facet_value_catalog_ids(client: Any, *, scope: str, collection_id: str) -> list[str]:
    ids, _ = _list_facet_value_catalog_ids_with_error(client, scope=scope, collection_id=collection_id)
    return ids


def _container_parent_names_for_did_with_error(
        client: Any,
        *,
        scope: str,
        name: str,
) -> tuple[list[str], Optional[str]]:
    try:
        parent_entries = list(client.list_parent_dids(scope=scope, name=name))
    except Exception as exc:
        return [], f"catalog_state: failed to list parents for '{scope}:{name}': {exc}"

    parent_names: set[str] = set()
    type_resolution_errors: list[str] = []
    for entry in parent_entries:
        if not isinstance(entry, dict):
            continue
        parent_name = entry.get("name")
        if not isinstance(parent_name, str) or not parent_name.strip():
            continue
        entry_scope = entry.get("scope")
        entry_scope_text = str(entry_scope) if entry_scope is not None else scope
        if entry_scope_text != scope:
            continue
        entry_type = entry.get("type")
        if isinstance(entry_type, str):
            resolved_type = entry_type.upper()
        else:
            container_exists, did_error = _did_exists_with_type_with_error(client, scope, parent_name, "CONTAINER")
            if did_error:
                type_resolution_errors.append(did_error)
                continue
            resolved_type = "CONTAINER" if container_exists else "DATASET"
        if resolved_type == "CONTAINER":
            parent_names.add(parent_name)
    if type_resolution_errors:
        return sorted(parent_names), "; ".join(sorted(set(type_resolution_errors)))
    return sorted(parent_names), None


def _catalog_parent_name_from_metadata_with_error(
        client: Any,
        *,
        scope: str,
        catalog_id: str,
) -> tuple[Optional[str], Optional[str]]:
    try:
        catalog_doc = _extract_document(client.get_metadata_document(scope=scope, name=catalog_id))
    except Exception as exc:
        return None, f"catalog_state: failed to read metadata for '{scope}:{catalog_id}': {exc}"

    links = catalog_doc.get("links")
    if not isinstance(links, list):
        return None, f"catalog_state: metadata links missing for '{scope}:{catalog_id}'."

    parent_hrefs = [
        str(link.get("href", "")).strip()
        for link in links
        if isinstance(link, dict)
        and str(link.get("rel", "")).strip() == "parent"
        and str(link.get("href", "")).strip()
    ]
    if len(parent_hrefs) != 1:
        return None, (
            f"catalog_state: expected exactly one parent link in '{scope}:{catalog_id}', "
            f"found {len(parent_hrefs)}."
        )

    parent_name = _last_path_segment(parent_hrefs[0]).strip()
    if not parent_name:
        return None, f"catalog_state: invalid parent href in '{scope}:{catalog_id}'."
    return parent_name, None


def _collect_missing_lineage_attachments_with_error(
        client: Any,
        *,
        scope: str,
        collection_id: str,
        catalog_id: str,
        max_hops: int = 8,
) -> tuple[list[tuple[str, str]], Optional[str]]:
    if catalog_id == collection_id:
        return [], None

    missing: list[tuple[str, str]] = []
    current_catalog = catalog_id
    visited: set[str] = {current_catalog}

    for _ in range(max_hops):
        parent_name, parent_error = _catalog_parent_name_from_metadata_with_error(
            client,
            scope=scope,
            catalog_id=current_catalog,
        )
        if parent_error:
            return missing, parent_error
        if parent_name is None:
            return missing, f"catalog_state: missing parent metadata for '{scope}:{current_catalog}'."

        attached, attached_error = _is_child_attached_with_error(
            client,
            scope=scope,
            parent_name=parent_name,
            child_name=current_catalog,
        )
        if attached_error:
            return missing, attached_error
        if attached is False:
            missing.append((parent_name, current_catalog))

        if parent_name == collection_id:
            return missing, None

        if parent_name in visited:
            return missing, (
                f"catalog_state: cycle detected while resolving parent lineage from "
                f"'{scope}:{catalog_id}'."
            )
        visited.add(parent_name)
        current_catalog = parent_name

    return missing, (
        f"catalog_state: parent lineage from '{scope}:{catalog_id}' exceeded {max_hops} hops before "
        f"reaching '{scope}:{collection_id}'."
    )


def _has_link(links: Any, *, rel: str, href: str) -> bool:
    if not isinstance(links, list):
        return False
    for link in links:
        if not isinstance(link, dict):
            continue
        if str(link.get("rel", "")).strip() != rel:
            continue
        if str(link.get("href", "")).strip() == href:
            return True
    return False


def _resolve_schema_path(
        *,
        schema_path: str | Path | None,
        payload_collection_id: Any,
        expected_collection_id: Optional[str],
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    if schema_path is not None:
        normalized_collection = None
        if isinstance(expected_collection_id, str) and expected_collection_id.strip():
            normalized_collection = _normalize_collection_id(expected_collection_id)
        elif isinstance(payload_collection_id, str) and payload_collection_id.strip():
            normalized_collection = _normalize_collection_id(payload_collection_id)
        return str(schema_path), normalized_collection, None

    effective_collection = expected_collection_id
    if not isinstance(effective_collection, str) or not effective_collection.strip():
        effective_collection = payload_collection_id if isinstance(payload_collection_id, str) else None
    if not isinstance(effective_collection, str) or not effective_collection.strip():
        return None, None, "schema_resolution: provide 'schema_path' or a valid collection id."

    normalized_collection = _normalize_collection_id(effective_collection)
    default_path = DEFAULT_SCHEMA_BY_COLLECTION.get(normalized_collection)
    if not default_path:
        supported = sorted(DEFAULT_SCHEMA_BY_COLLECTION.keys())
        return None, None, (
            f"schema_resolution: unsupported collection '{effective_collection}'. Supported: {supported}."
        )
    return default_path, normalized_collection, None


def _infer_collection_id_from_payload(payload: Any) -> Optional[str]:
    if not isinstance(payload, dict):
        return None

    payload_id = payload.get("id")
    href_collection_id: Optional[str] = None
    hrefs_by_rel = _collect_hrefs_by_rel(payload.get("links"))
    self_links = hrefs_by_rel.get("self", [])
    if len(self_links) == 1:
        href_collection_id = _collection_segment_from_item_href(self_links[0])

    known_collections = sorted(DEFAULT_SCHEMA_BY_COLLECTION.keys(), key=len, reverse=True)
    if isinstance(payload_id, str) and payload_id.strip():
        parsed_id, _ = _split_derived_item_identifier(
            payload_id.strip(),
            collection_ids=known_collections,
            href_collection_id=href_collection_id,
        )
        if parsed_id is not None:
            return parsed_id["collection_id"]

    if isinstance(href_collection_id, str) and href_collection_id.strip():
        return _normalize_collection_id(href_collection_id)

    payload_collection_id = payload.get("collection")
    if isinstance(payload_collection_id, str) and payload_collection_id.strip():
        return _normalize_collection_id(payload_collection_id)

    return None


def _load_payload_from_source(
        *,
        source: ValidationSource,
        item_path: str | Path | None,
        expected_item_id: str | None,
        scope: str,
        client: Any,
) -> tuple[Optional[dict[str, Any]], Optional[str]]:
    if source == "local":
        if item_path is None:
            return None, "item_file: 'item_path' is required when source='local'."
        try:
            payload = load_json_file(item_path)
        except Exception as exc:
            return None, f"item_file: could not load item file '{item_path}': {exc}"
        if not isinstance(payload, dict):
            return None, "item_file: payload must be a JSON object."
        return payload, None

    if source == "server":
        if not expected_item_id or not expected_item_id.strip():
            return None, "server_source: non-empty 'expected_item_id' is required when source='server'."
        if client is None:
            return None, "server_source: client connection is not available."
        try:
            response = client.get_metadata_document(scope=scope, name=expected_item_id)
        except Exception as exc:
            return None, f"server_source: failed to read metadata for '{scope}:{expected_item_id}': {exc}"
        payload = _extract_document(response)
        if not payload:
            return None, f"server_source: metadata document for '{scope}:{expected_item_id}' is empty."
        return payload, None

    return None, f"validation_source: unsupported source '{source}'."


def _evaluate_derived_item_payload(
        *,
        item_payload: dict[str, Any],
        schema_payload: dict[str, Any],
        validation_phase: ValidationPhase,
        scope: str,
        expected_item_id: Optional[str],
        state_item_id: Optional[str],
        expected_collection_id: Optional[str],
        root_href: str,
        expected_stac_version: str,
        check_catalog_state: bool,
        client: Any,
        original_collection_id: str,
        enforce_profile_mapping: bool,
) -> dict[str, Any]:
    """Evaluate one derived-item payload and return a structured report.

    Args:
        item_payload: Payload to validate.
        schema_payload: JSON schema used for structure checks.
        validation_phase: Validation profile controlling link/state expectations.
        scope: Scope used for optional state checks.
        expected_item_id: Optional strict expected item id.
        state_item_id: Catalog object id used for state checks/autofix targeting.
        expected_collection_id: Optional strict expected collection id.
        root_href: Expected root href for navigation checks.
        expected_stac_version: Expected ``stac_version`` value.
        check_catalog_state: Enable object existence/hierarchy/backlink checks.
        client: Client instance used for state checks.
        original_collection_id: Collection id expected to contain original source items.
        enforce_profile_mapping: Require collection-specific profile mapping.

    Returns:
        dict[str, Any]: Full validation report (checks, state checks, errors, summary).
    """
    report: dict[str, Any] = {
        "valid": False,
        "schema_valid": False,
        "item_id": None,
        "collection_field": None,
        "parsed_id": {
            "original_item_id": None,
            "collection_id": None,
            "version": None,
        },
        "checks": {
            "core_fields_valid": None,
            "derived_id_structure_valid": None,
            "collection_name_compatible": None,
            "link_structure_valid": None,
            "link_id_consistency_valid": None,
            "navigation_links_valid": None,
            "root_link_valid": None,
            "derived_from_link_valid": None,
            "stac_version_valid": None,
            "geometry_valid": None,
            "bbox_valid": None,
            "temporal_valid": None,
            "assets_valid": None,
            "profile_block_present": None,
            "profile_version_matches_id": None,
        },
        "state_checks": {
            "item_exists_as_dataset": None,
            "collection_exists_as_container": None,
            "collection_excludes_direct_item": None,
            "collection_metadata_excludes_item_href": None,
            "item_attached_to_facet_value_catalog": None,
            "facet_value_catalog_metadata_includes_item_href": None,
            "original_item_exists_as_dataset": None,
            "original_item_in_original_collection": None,
            "coordinates_match_original_item": None,
            "original_item_metadata_has_related_backlink": None,
        },
        "facet_value_catalog_membership": {
            "catalog_ids": [],
            "catalogs_with_item": [],
            "catalogs_missing_item_href": [],
            "item_parent_catalog_ids": [],
            "lineage_missing_attachments": [],
            "error": None,
        },
        "collection_backlink": {
            "expected_item_href": None,
            "present": None,
            "error": None,
        },
        "original_item_backlink": {
            "expected_related_href": None,
            "present": None,
            "error": None,
        },
        "errors": [],
        "summary": "",
    }
    errors: list[str] = []

    schema_issues = _schema_errors(item_payload, schema_payload)
    report["schema_valid"] = len(schema_issues) == 0
    errors.extend(schema_issues)

    item_id = item_payload.get("id")
    collection_field = item_payload.get("collection")
    report["item_id"] = item_id
    report["collection_field"] = collection_field

    core_fields = {
        "type": item_payload.get("type"),
        "stac_version": item_payload.get("stac_version"),
        "id": item_id,
        "collection": collection_field,
        "properties": item_payload.get("properties"),
        "geometry": item_payload.get("geometry"),
        "bbox": item_payload.get("bbox"),
        "links": item_payload.get("links"),
        "assets": item_payload.get("assets"),
    }
    missing_core = [field for field, value in core_fields.items() if value in (None, "", [], {})]
    if missing_core:
        report["checks"]["core_fields_valid"] = False
        errors.append(f"core_fields: missing or empty fields: {missing_core}")
    else:
        report["checks"]["core_fields_valid"] = True

    if core_fields["type"] != "Feature":
        report["checks"]["core_fields_valid"] = False
        errors.append(f"core_fields:type: expected 'Feature', found '{core_fields['type']}'")

    if expected_item_id and isinstance(item_id, str) and item_id != expected_item_id:
        errors.append(f"id_consistency: expected item id '{expected_item_id}', found '{item_id}'")

    links = core_fields["links"]
    hrefs_by_rel = _collect_hrefs_by_rel(links)
    root_links = hrefs_by_rel.get("root", [])
    self_links = hrefs_by_rel.get("self", [])
    collection_links = hrefs_by_rel.get("collection", [])
    derived_from_links = hrefs_by_rel.get("derived_from", [])

    link_structure_valid = True
    if len(root_links) != 1:
        link_structure_valid = False
        errors.append(f"links: expected exactly one 'root' link, found {len(root_links)}")
    if len(self_links) != 1:
        link_structure_valid = False
        errors.append(f"links: expected exactly one 'self' link, found {len(self_links)}")
    if len(collection_links) != 1:
        link_structure_valid = False
        errors.append(f"links: expected exactly one 'collection' link, found {len(collection_links)}")
    if len(derived_from_links) != 1:
        link_structure_valid = False
        errors.append(f"links: expected exactly one 'derived_from' link, found {len(derived_from_links)}")
    report["checks"]["link_structure_valid"] = link_structure_valid

    if len(root_links) == 1:
        report["checks"]["root_link_valid"] = root_links[0] == root_href
        if root_links[0] != root_href:
            errors.append(f"root_link: expected '{root_href}', found '{root_links[0]}'")

    link_id_consistency_valid = False
    self_collection_id = None
    if isinstance(item_id, str) and len(self_links) == 1:
        self_item_id = _last_path_segment(self_links[0])
        self_collection_id = _collection_segment_from_item_href(self_links[0])
        link_id_consistency_valid = True
        if self_item_id != item_id:
            link_id_consistency_valid = False
            errors.append(f"links:self: href-derived id '{self_item_id}' does not match payload id '{item_id}'")
    report["checks"]["link_id_consistency_valid"] = link_id_consistency_valid

    authoritative_item_id = (
        state_item_id.strip()
        if isinstance(state_item_id, str) and state_item_id.strip()
        else item_id.strip()
        if isinstance(item_id, str) and item_id.strip()
        else None
    )

    collection_ids: list[str] = []
    if client is not None:
        discovered_collection_ids, collection_discovery_error = _list_collection_ids_via_filter(client, scope=scope)
        collection_ids.extend(discovered_collection_ids)
        if collection_discovery_error:
            errors.append(collection_discovery_error)
    if isinstance(expected_collection_id, str) and expected_collection_id.strip():
        collection_ids.append(_normalize_collection_id(expected_collection_id))
    if isinstance(collection_field, str) and collection_field.strip():
        collection_ids.append(_normalize_collection_id(collection_field))
    if isinstance(self_collection_id, str) and self_collection_id.strip():
        collection_ids.append(_normalize_collection_id(self_collection_id))
    collection_ids = sorted(set(collection_ids), key=len, reverse=True)

    derived_id_structure_valid = True
    parsed_id_payload: Optional[dict[str, str]] = None
    if isinstance(item_id, str):
        parsed_id_payload, parse_error = _split_derived_item_identifier(
            item_id,
            collection_ids=collection_ids,
            href_collection_id=self_collection_id,
        )
        if parse_error:
            derived_id_structure_valid = False
            errors.append(f"derived_id: {parse_error}")
    else:
        derived_id_structure_valid = False
        errors.append("derived_id: payload id is missing or not a string.")
    report["checks"]["derived_id_structure_valid"] = derived_id_structure_valid

    parsed_id_context = parsed_id_payload
    if isinstance(authoritative_item_id, str) and authoritative_item_id != item_id:
        parsed_from_authoritative, authoritative_parse_error = _split_derived_item_identifier(
            authoritative_item_id,
            collection_ids=collection_ids,
            href_collection_id=self_collection_id,
        )
        if authoritative_parse_error:
            errors.append(f"state_id_parse: {authoritative_parse_error}")
            parsed_id_context = None
        else:
            parsed_id_context = parsed_from_authoritative

    effective_collection_id = None
    original_item_id = None
    parsed_version = None
    if parsed_id_context is not None:
        effective_collection_id = parsed_id_context["collection_id"]
        original_item_id = parsed_id_context["original_item_id"]
        parsed_version = parsed_id_context["version"]
        report["parsed_id"] = {
            "original_item_id": original_item_id,
            "collection_id": effective_collection_id,
            "version": parsed_version,
        }

    collection_compatible = None
    if isinstance(collection_field, str) and effective_collection_id is not None:
        collection_compatible = _normalize_collection_id(collection_field) == effective_collection_id
        if not collection_compatible:
            errors.append(
                f"collection_consistency: payload collection '{collection_field}' does not match parsed "
                f"collection '{effective_collection_id}'."
            )
    if isinstance(expected_collection_id, str) and effective_collection_id is not None:
        expected_normalized = _normalize_collection_id(expected_collection_id)
        expected_match = expected_normalized == effective_collection_id
        collection_compatible = expected_match if collection_compatible is None else (collection_compatible and expected_match)
        if not expected_match:
            errors.append(
                f"collection_consistency: parsed collection '{effective_collection_id}' does not match expected "
                f"collection '{expected_collection_id}'."
            )
    report["checks"]["collection_name_compatible"] = collection_compatible

    navigation_links_valid = False
    if isinstance(item_id, str) and isinstance(effective_collection_id, str) and len(self_links) == 1 and len(
            collection_links
    ) == 1:
        root = root_href.rstrip("/")
        expected_self = f"{root}/collections/{effective_collection_id}/items/{item_id}"
        expected_collection = f"{root}/collections/{effective_collection_id}"
        navigation_links_valid = True
        if len(self_links) == 1 and self_links[0] != expected_self:
            navigation_links_valid = False
            errors.append(f"links:self: expected '{expected_self}', found '{self_links[0]}'.")
        if len(collection_links) == 1 and collection_links[0] != expected_collection:
            navigation_links_valid = False
            errors.append(f"links:collection: expected '{expected_collection}', found '{collection_links[0]}'.")
    elif not (isinstance(item_id, str) and isinstance(effective_collection_id, str)):
        navigation_links_valid = False
        errors.append("links:navigation: could not validate navigation links (missing item id or collection id).")
    report["checks"]["navigation_links_valid"] = navigation_links_valid

    derived_from_valid = True
    if isinstance(original_item_id, str) and len(derived_from_links) == 1:
        expected_derived_from = f"{root_href.rstrip('/')}/collections/{original_collection_id}/items/{original_item_id}"
        if derived_from_links[0] != expected_derived_from:
            derived_from_valid = False
            errors.append(
                f"links:derived_from: expected '{expected_derived_from}', found '{derived_from_links[0]}'."
            )
    elif len(derived_from_links) == 1:
        derived_from_valid = False
        errors.append("links:derived_from: original item id could not be derived from payload id.")
    else:
        derived_from_valid = False
    report["checks"]["derived_from_link_valid"] = derived_from_valid

    report["checks"]["stac_version_valid"] = core_fields["stac_version"] == expected_stac_version
    if not report["checks"]["stac_version_valid"]:
        errors.append(f"stac_version: expected '{expected_stac_version}', found '{core_fields['stac_version']}'.")

    geometry = core_fields["geometry"]
    geometry_valid = True
    if not isinstance(geometry, dict):
        geometry_valid = False
        errors.append("geometry: geometry must be an object.")
    else:
        if not isinstance(geometry.get("type"), str) or not geometry.get("type"):
            geometry_valid = False
            errors.append("geometry:type: missing or empty geometry type.")
        if "coordinates" not in geometry:
            geometry_valid = False
            errors.append("geometry:coordinates: missing coordinates.")
    report["checks"]["geometry_valid"] = geometry_valid

    bbox_ok, bbox_error = _validate_bbox(core_fields["bbox"])
    report["checks"]["bbox_valid"] = bbox_ok
    if bbox_error:
        errors.append(f"bbox: {bbox_error}")

    properties = core_fields["properties"] if isinstance(core_fields["properties"], dict) else {}
    temporal_valid = True
    _, datetime_error = _parse_timestamp(properties.get("datetime"))
    if datetime_error:
        temporal_valid = False
        errors.append(f"properties:datetime: {datetime_error}")
    report["checks"]["temporal_valid"] = temporal_valid

    assets = core_fields["assets"]
    assets_valid = True
    if not isinstance(assets, dict) or not assets:
        assets_valid = False
        errors.append("assets: expected a non-empty assets object.")
    else:
        for asset_name, asset_data in assets.items():
            if not isinstance(asset_data, dict):
                assets_valid = False
                errors.append(f"assets:{asset_name}: asset entry must be an object.")
                continue
            href = asset_data.get("href")
            asset_type = asset_data.get("type")
            if not isinstance(href, str) or not href.strip():
                assets_valid = False
                errors.append(f"assets:{asset_name}: missing or empty 'href'.")
            if not isinstance(asset_type, str) or not asset_type.strip():
                assets_valid = False
                errors.append(f"assets:{asset_name}: missing or empty 'type'.")
    report["checks"]["assets_valid"] = assets_valid

    profile_collection_id = effective_collection_id
    if not isinstance(profile_collection_id, str) and isinstance(expected_collection_id, str) and expected_collection_id.strip():
        profile_collection_id = _normalize_collection_id(expected_collection_id)
    if not isinstance(profile_collection_id, str) and isinstance(collection_field, str):
        profile_collection_id = _normalize_collection_id(collection_field)
    profile_mapping = PROFILE_BLOCK_BY_COLLECTION.get(profile_collection_id or "")
    profile_block_present: Optional[bool] = None
    profile_version_matches_id: Optional[bool] = None
    if profile_mapping is None:
        if enforce_profile_mapping:
            profile_block_present = False
            profile_version_matches_id = False
            errors.append(f"profile: unsupported collection '{profile_collection_id or collection_field}'.")
    else:
        profile_key, version_key = profile_mapping
        profile_payload = properties.get(profile_key)
        if not isinstance(profile_payload, dict):
            profile_block_present = False
            profile_version_matches_id = False
            errors.append(f"profile:{profile_key}: missing or invalid profile block.")
        else:
            profile_block_present = True
            version_value = profile_payload.get(version_key)
            if parsed_version is None:
                profile_version_matches_id = False
                errors.append(
                    f"profile:{version_key}: id version could not be parsed from item id '{item_id}'."
                )
            elif not isinstance(version_value, int) or str(version_value) != str(parsed_version):
                profile_version_matches_id = False
                errors.append(
                    f"profile:{version_key}: value '{version_value}' does not match id version '{parsed_version}'."
                )
            else:
                profile_version_matches_id = True
    report["checks"]["profile_block_present"] = profile_block_present
    report["checks"]["profile_version_matches_id"] = profile_version_matches_id

    catalog_item_id = state_item_id.strip() if isinstance(state_item_id, str) and state_item_id.strip() else (
        item_id if isinstance(item_id, str) and item_id.strip() else None
    )

    if check_catalog_state and client is not None and isinstance(catalog_item_id, str):
        item_exists, item_exists_error = _did_exists_with_type_with_error(client, scope, catalog_item_id, "DATASET")
        if item_exists_error:
            report["state_checks"]["item_exists_as_dataset"] = None
            errors.append(item_exists_error)
        else:
            report["state_checks"]["item_exists_as_dataset"] = item_exists
            if not item_exists:
                errors.append(f"catalog_item: '{scope}:{catalog_item_id}' does not exist as an item dataset.")

        if isinstance(effective_collection_id, str):
            collection_exists, collection_exists_error = _did_exists_with_type_with_error(
                client,
                scope,
                effective_collection_id,
                "CONTAINER",
            )
            if collection_exists_error:
                report["state_checks"]["collection_exists_as_container"] = None
                errors.append(collection_exists_error)
            else:
                report["state_checks"]["collection_exists_as_container"] = collection_exists
            if collection_exists:
                expected_item_href = (
                    f"{root_href.rstrip('/')}/collections/{effective_collection_id}/items/{catalog_item_id}"
                )
                report["collection_backlink"]["expected_item_href"] = expected_item_href

                collection_contains_item, collection_membership_error = _is_child_attached_with_error(
                    client,
                    scope=scope,
                    parent_name=effective_collection_id,
                    child_name=catalog_item_id,
                )
                if collection_membership_error:
                    report["state_checks"]["collection_excludes_direct_item"] = None
                    errors.append(collection_membership_error)
                elif collection_contains_item is not None:
                    report["state_checks"]["collection_excludes_direct_item"] = not collection_contains_item
                    if collection_contains_item:
                        errors.append(
                            f"catalog_hierarchy: collection '{scope}:{effective_collection_id}' contains derived item "
                            f"'{scope}:{catalog_item_id}' directly; derived items must be attached through facet value "
                            "catalogs."
                        )

                try:
                    collection_doc = _extract_document(
                        client.get_metadata_document(scope=scope, name=effective_collection_id)
                    )
                    has_collection_item_link = _has_link(
                        collection_doc.get("links"),
                        rel="item",
                        href=expected_item_href,
                    )
                    report["collection_backlink"]["present"] = has_collection_item_link
                    report["state_checks"]["collection_metadata_excludes_item_href"] = not has_collection_item_link
                    if has_collection_item_link:
                        errors.append(
                            f"collection_navigation: collection '{scope}:{effective_collection_id}' includes derived "
                            f"item href '{expected_item_href}' in links with rel='item'; this must be stored on "
                            "facet value catalogs."
                        )
                except Exception as exc:
                    report["collection_backlink"]["error"] = str(exc)
                    errors.append(
                        f"collection_metadata: failed to read collection metadata for "
                        f"'{scope}:{effective_collection_id}': {exc}"
                    )

                facet_value_catalog_ids, facet_value_catalog_error = _list_facet_value_catalog_ids_with_error(
                    client,
                    scope=scope,
                    collection_id=effective_collection_id,
                )
                report["facet_value_catalog_membership"]["catalog_ids"] = facet_value_catalog_ids
                if facet_value_catalog_error:
                    report["facet_value_catalog_membership"]["error"] = facet_value_catalog_error
                    report["state_checks"]["item_attached_to_facet_value_catalog"] = None
                    report["state_checks"]["facet_value_catalog_metadata_includes_item_href"] = None
                    errors.append(facet_value_catalog_error)
                else:
                    catalogs_with_item: list[str] = []
                    catalog_attachment_errors: list[str] = []
                    for catalog_id in facet_value_catalog_ids:
                        item_attached, item_attached_error = _is_child_attached_with_error(
                            client,
                            scope=scope,
                            parent_name=catalog_id,
                            child_name=catalog_item_id,
                        )
                        if item_attached_error:
                            catalog_attachment_errors.append(item_attached_error)
                            continue
                        if item_attached:
                            catalogs_with_item.append(catalog_id)
                    report["facet_value_catalog_membership"]["catalogs_with_item"] = catalogs_with_item
                    if catalog_attachment_errors:
                        report["facet_value_catalog_membership"]["error"] = "; ".join(
                            sorted(set(catalog_attachment_errors))
                        )
                        report["state_checks"]["item_attached_to_facet_value_catalog"] = None
                        report["state_checks"]["facet_value_catalog_metadata_includes_item_href"] = None
                        errors.append(report["facet_value_catalog_membership"]["error"])
                    else:
                        report["state_checks"]["item_attached_to_facet_value_catalog"] = bool(catalogs_with_item)
                        if not catalogs_with_item:
                            errors.append(
                                f"catalog_hierarchy: derived item '{scope}:{catalog_item_id}' is not attached to any "
                                f"facet value catalog under collection '{scope}:{effective_collection_id}'."
                            )
                            parent_catalog_ids, parent_catalog_error = _container_parent_names_for_did_with_error(
                                client,
                                scope=scope,
                                name=catalog_item_id,
                            )
                            report["facet_value_catalog_membership"]["item_parent_catalog_ids"] = parent_catalog_ids
                            if parent_catalog_error:
                                errors.append(parent_catalog_error)

                            missing_attachments: set[tuple[str, str]] = set()
                            lineage_errors: list[str] = []
                            for parent_catalog_id in parent_catalog_ids:
                                missing_pairs, lineage_error = _collect_missing_lineage_attachments_with_error(
                                    client,
                                    scope=scope,
                                    collection_id=effective_collection_id,
                                    catalog_id=parent_catalog_id,
                                )
                                for parent_name, child_name in missing_pairs:
                                    missing_attachments.add((parent_name, child_name))
                                if lineage_error:
                                    lineage_errors.append(lineage_error)

                            if missing_attachments:
                                missing_edges = [
                                    f"{scope}:{parent_name}->{scope}:{child_name}"
                                    for parent_name, child_name in sorted(missing_attachments)
                                ]
                                report["facet_value_catalog_membership"]["lineage_missing_attachments"] = missing_edges
                                errors.append(
                                    "catalog_hierarchy: missing catalog attachment(s) required by metadata lineage "
                                    f"to reach collection '{scope}:{effective_collection_id}': {missing_edges}"
                                )

                            if lineage_errors:
                                errors.extend(sorted(set(lineage_errors)))

                        missing_item_href_catalogs: list[str] = []
                        facet_metadata_errors: list[str] = []
                        for catalog_id in catalogs_with_item:
                            try:
                                catalog_doc = _extract_document(client.get_metadata_document(scope=scope, name=catalog_id))
                            except Exception as exc:
                                facet_metadata_errors.append(
                                    f"facet_value_metadata: failed to read metadata for '{scope}:{catalog_id}': {exc}"
                                )
                                continue
                            if not _has_link(catalog_doc.get("links"), rel="item", href=expected_item_href):
                                missing_item_href_catalogs.append(catalog_id)
                        report["facet_value_catalog_membership"]["catalogs_missing_item_href"] = missing_item_href_catalogs
                        if facet_metadata_errors:
                            report["facet_value_catalog_membership"]["error"] = "; ".join(
                                sorted(set(facet_metadata_errors))
                            )
                            report["state_checks"]["facet_value_catalog_metadata_includes_item_href"] = None
                            errors.append(report["facet_value_catalog_membership"]["error"])
                        else:
                            report["state_checks"]["facet_value_catalog_metadata_includes_item_href"] = (
                                len(catalogs_with_item) > 0 and len(missing_item_href_catalogs) == 0
                            )
                            if missing_item_href_catalogs:
                                errors.append(
                                    f"facet_value_navigation: missing rel='item' href '{expected_item_href}' in facet "
                                    f"value catalog metadata: {missing_item_href_catalogs}"
                                )
            elif collection_exists is False:
                errors.append(
                    f"catalog_collection: '{scope}:{effective_collection_id}' does not exist as a collection container."
                )

        if isinstance(original_item_id, str):
            original_exists, original_exists_error = _did_exists_with_type_with_error(
                client,
                scope,
                original_item_id,
                "DATASET",
            )
            if original_exists_error:
                report["state_checks"]["original_item_exists_as_dataset"] = None
                errors.append(original_exists_error)
            else:
                report["state_checks"]["original_item_exists_as_dataset"] = original_exists
            if original_exists:
                original_in_source_collection, original_collection_error = _is_child_attached_with_error(
                    client,
                    scope=scope,
                    parent_name=original_collection_id,
                    child_name=original_item_id,
                )
                if original_collection_error:
                    report["state_checks"]["original_item_in_original_collection"] = None
                    errors.append(original_collection_error)
                elif original_in_source_collection is not None:
                    report["state_checks"]["original_item_in_original_collection"] = original_in_source_collection
                    if not original_in_source_collection:
                        errors.append(
                            f"catalog_hierarchy: original collection '{scope}:{original_collection_id}' does not "
                            f"contain item '{scope}:{original_item_id}'."
                        )

                try:
                    original_doc = _extract_document(
                        client.get_metadata_document(scope=scope, name=original_item_id)
                    )
                except Exception as exc:
                    report["original_item_backlink"]["error"] = str(exc)
                    errors.append(
                        f"original_metadata: failed to read metadata for '{scope}:{original_item_id}': {exc}"
                    )
                    original_doc = None

                if isinstance(original_doc, dict):
                    original_geometry = original_doc.get("geometry")
                    original_bbox = _normalized_bbox_for_compare(original_doc.get("bbox"))
                    derived_bbox = _normalized_bbox_for_compare(core_fields["bbox"])
                    if (
                            not isinstance(original_geometry, dict)
                            or not isinstance(geometry, dict)
                            or original_bbox is None
                            or derived_bbox is None
                    ):
                        report["state_checks"]["coordinates_match_original_item"] = False
                        errors.append("coordinate_parity: derived/original geometry or bbox is missing/invalid.")
                    else:
                        coordinates_match = geometry == original_geometry and derived_bbox == original_bbox
                        report["state_checks"]["coordinates_match_original_item"] = coordinates_match
                        if not coordinates_match:
                            errors.append(
                                "coordinate_parity: derived item geometry/bbox differs from referenced original item."
                            )

                if isinstance(effective_collection_id, str):
                    expected_related_href = (
                        f"{root_href.rstrip('/')}/collections/{effective_collection_id}/items/{catalog_item_id}"
                    )
                    report["original_item_backlink"]["expected_related_href"] = expected_related_href
                    if isinstance(original_doc, dict):
                        has_related_backlink = _has_link(
                            original_doc.get("links"),
                            rel="related",
                            href=expected_related_href,
                        )
                        report["original_item_backlink"]["present"] = has_related_backlink
                        report["state_checks"]["original_item_metadata_has_related_backlink"] = has_related_backlink
                        if validation_phase == "post_publish" and not has_related_backlink:
                            errors.append(
                                f"original_navigation: original item '{scope}:{original_item_id}' does not include "
                                f"related href '{expected_related_href}'."
                            )
            elif original_exists is False:
                errors.append(f"catalog_original_item: '{scope}:{original_item_id}' does not exist as an item dataset.")

    report["errors"] = errors
    report["valid"] = len(errors) == 0
    report["summary"] = "Validation passed." if report["valid"] else f"{len(errors)} validation issue(s) found."
    return report


def _failed_checks(checks: Any) -> list[str]:
    if not isinstance(checks, dict):
        return []
    return sorted([name for name, status in checks.items() if status is False])


def _compact_validation_report(report: dict[str, Any]) -> dict[str, Any]:
    checks = report.get("checks") if isinstance(report.get("checks"), dict) else {}
    state_checks = report.get("state_checks") if isinstance(report.get("state_checks"), dict) else {}
    errors = report.get("errors") if isinstance(report.get("errors"), list) else []
    valid_value = report.get("valid")
    autofix_requested = bool(report.get("autofix_requested"))
    autofix_applied = bool(report.get("autofix_applied"))
    compact: dict[str, Any] = {
        "valid": valid_value if isinstance(valid_value, bool) or valid_value is None else bool(valid_value),
        "summary": report.get("summary"),
        "validation_phase": report.get("validation_phase"),
        "source": report.get("source"),
        "scope": report.get("scope"),
        "item_id": report.get("item_id"),
        "collection_field": report.get("collection_field"),
        "parsed_id": report.get("parsed_id"),
        "schema_valid": report.get("schema_valid"),
        "checks": checks,
        "state_checks": state_checks,
        "facet_value_catalog_membership": report.get("facet_value_catalog_membership"),
        "failed_checks": _failed_checks(checks),
        "error_count": len(errors),
        "errors": errors[:10],
        "autofix_requested": autofix_requested,
        "autofix_applied": autofix_applied,
    }
    if len(errors) > 10:
        compact["errors_truncated"] = True
    if report.get("autofix_error"):
        compact["autofix_error"] = report.get("autofix_error")

    autofix_payload = report.get("autofix")
    if isinstance(autofix_payload, dict):
        autofix_errors = autofix_payload.get("errors") if isinstance(autofix_payload.get("errors"), list) else []
        compact["autofix"] = {
            "updated": bool(autofix_payload.get("updated")),
            "error_count": len(autofix_errors),
        }

    post_fix = report.get("post_fix_validation")
    if isinstance(post_fix, dict):
        post_fix_errors = post_fix.get("errors") if isinstance(post_fix.get("errors"), list) else []
        post_fix_valid = post_fix.get("valid")
        compact["post_fix_validation"] = {
            "valid": (
                post_fix_valid
                if isinstance(post_fix_valid, bool) or post_fix_valid is None
                else bool(post_fix_valid)
            ),
            "summary": post_fix.get("summary"),
            "error_count": len(post_fix_errors),
        }

    post_fix_status = compact.get("post_fix_validation", {}).get("valid")
    if not autofix_requested:
        compact["autofix_effect"] = "not_requested"
    elif not autofix_applied:
        compact["autofix_effect"] = "requested_no_changes"
    elif post_fix_status is True:
        compact["autofix_effect"] = "changes_applied_validation_passed"
    elif post_fix_status is False:
        compact["autofix_effect"] = "changes_applied_validation_failed"
    else:
        compact["autofix_effect"] = "changes_applied_validation_unknown"

    return compact


def validate_derived_item(
        *,
        post_publish: Optional[bool] = None,
        source: ValidationSource = "local",
        item_path: str | Path | None = None,
        schema_path: str | Path | None = None,
        scope: str = "dafab",
        expected_item_id: Optional[str] = None,
        expected_collection_id: Optional[str] = None,
        original_collection_id: str = "sentinel_2_l2a",
        root_href: str = "https://dafab.cern.ch/stac",
        expected_stac_version: str = "1.1.0",
        check_catalog_state: Optional[bool] = None,
        autofix: bool = False,
        autofix_apply_remote: bool = True,
        autofix_fix_profile: bool = True,
        autofix_fix_bbox: bool = True,
        autofix_ensure_original_attachment: bool = True,
        autofix_ensure_relationship_links: bool = True,
        autofix_allow_create_missing_objects: bool = False,
        mode: str = "atomic",
        compact_result: bool = True,
) -> dict[str, Any]:
    """Validate derived-item metadata against pre-publish or post-publish contract checks.

    Modes:
    - ``pre_publish`` (pre-publish) validates local payload structure and contract fields.
    - ``post_publish`` (post-publish) additionally validates persisted hierarchy and navigation links.

    Args:
        post_publish: Optional boolean mode selector. ``True`` enables post-publish mode,
            ``False`` enables pre-publish mode. When omitted, mode is inferred from ``source``.
        source: Payload source (`local` reads local JSON, `server` reads stored metadata).
        item_path: Local JSON path used when ``source='local'``.
        schema_path: Optional schema path. If omitted, inferred from collection id/profile.
        scope: Scope where objects are resolved for state checks.
        expected_item_id: Expected id for strict id consistency checks and the server
            lookup identifier when ``source='server'``.
        expected_collection_id: Optional expected collection id for compatibility checks.
        original_collection_id: Collection id expected to contain original source items.
        root_href: Expected STAC root href for navigation validation.
        expected_stac_version: Expected ``stac_version`` value.
        check_catalog_state: Force-enable/disable state checks. ``None`` follows mode defaults.
        autofix: Attempt to apply repair actions when validation fails.
        autofix_apply_remote: Re-read and re-validate from the server after autofix.
        autofix_fix_profile: Normalize profile block and algorithm version.
        autofix_fix_bbox: Recompute and patch bbox from geometry.
        autofix_ensure_original_attachment: Ensure original item attachment to original collection.
        autofix_ensure_relationship_links: Ensure facet value and original-item relationship links.
        autofix_allow_create_missing_objects: Create missing objects before relationship fixes.
        mode: Metadata patch execution mode used by autofix.
        compact_result: Return compact report (``True``) or full report (``False``).

    Returns:
        dict[str, Any]: Validation report with schema/link/profile checks, parsed id parts,
        optional state checks, and full error list.
    """
    if source not in {"local", "server"}:
        raise ValueError("Unsupported source. Use 'local' or 'server'.")
    if source == "server" and (not expected_item_id or not expected_item_id.strip()):
        raise ValueError("When source='server', 'expected_item_id' is required.")
    resolved_validation_phase = _resolve_validation_phase(
        source=source,
        post_publish=post_publish,
    )

    if check_catalog_state is None:
        check_catalog_state = resolved_validation_phase == "post_publish"

    report: dict[str, Any] = {
        "valid": False,
        "validation_phase": resolved_validation_phase,
        "source": source,
        "item_path": str(Path(item_path)) if item_path is not None else None,
        "schema_path": str(schema_path) if schema_path is not None else None,
        "scope": scope,
        "item_id": expected_item_id if source == "server" else None,
        "expected_item_id": expected_item_id,
        "expected_collection_id": expected_collection_id,
        "original_collection_id": original_collection_id,
        "root_href": root_href,
        "autofix_requested": autofix,
        "autofix_applied": False,
    }

    client = None
    if source == "server" or check_catalog_state:
        try:
            client = connection_manager()
        except Exception as exc:
            report["errors"] = [f"server_connection: failed to connect to client: {exc}"]
            report["summary"] = "1 validation issue(s) found."
            return _compact_validation_report(report) if compact_result else report

    payload, payload_error = _load_payload_from_source(
        source=source,
        item_path=item_path,
        expected_item_id=expected_item_id,
        scope=scope,
        client=client,
    )
    if payload_error:
        report["errors"] = [payload_error]
        report["summary"] = "1 validation issue(s) found."
        return _compact_validation_report(report) if compact_result else report

    inferred_collection_id = _infer_collection_id_from_payload(payload)

    resolved_schema_path, normalized_collection, schema_error = _resolve_schema_path(
        schema_path=schema_path,
        payload_collection_id=inferred_collection_id or payload.get("collection"),
        expected_collection_id=expected_collection_id,
    )
    if schema_error:
        report["errors"] = [schema_error]
        report["summary"] = "1 validation issue(s) found."
        return _compact_validation_report(report) if compact_result else report
    report["schema_path"] = resolved_schema_path
    effective_expected_collection_id = expected_collection_id
    if not effective_expected_collection_id and inferred_collection_id:
        effective_expected_collection_id = inferred_collection_id
    if not effective_expected_collection_id and normalized_collection:
        effective_expected_collection_id = normalized_collection
    report["expected_collection_id"] = effective_expected_collection_id

    try:
        schema_payload, resolved_schema_source = load_json_schema(resolved_schema_path)
        report["schema_path"] = resolved_schema_source
    except Exception as schema_exc:
        # Compatibility fallback for call sites/tests that patch ``load_json_file``
        # and provide virtual schema paths.
        try:
            schema_payload = load_json_file(str(resolved_schema_path))
            report["schema_path"] = str(resolved_schema_path)
        except Exception:
            report["errors"] = [f"schema_file: could not load schema '{resolved_schema_path}': {schema_exc}"]
            report["summary"] = "1 validation issue(s) found."
            return _compact_validation_report(report) if compact_result else report

    evaluation = _evaluate_derived_item_payload(
        item_payload=payload,
        schema_payload=schema_payload,
        validation_phase=resolved_validation_phase,
        scope=scope,
        expected_item_id=expected_item_id,
        state_item_id=expected_item_id if source == "server" else None,
        expected_collection_id=effective_expected_collection_id,
        root_href=root_href,
        expected_stac_version=expected_stac_version,
        check_catalog_state=check_catalog_state,
        client=client,
        original_collection_id=original_collection_id,
        enforce_profile_mapping=schema_path is None,
    )
    report.update(evaluation)

    if report["valid"]:
        LOG.result("Derived item contract validation passed for '%s'.", report.get("item_id"))
    else:
        LOG.warning("Derived item contract validation found %s issue(s).", len(report.get("errors", [])))

    if not autofix or report["valid"]:
        return _compact_validation_report(report) if compact_result else report

    if source != "server":
        report["autofix_error"] = "autofix requires source='server'."
        return _compact_validation_report(report) if compact_result else report

    effective_item_id = expected_item_id if source == "server" else report.get("item_id")
    if not isinstance(effective_item_id, str) or not effective_item_id.strip():
        report["autofix_error"] = "autofix requires a valid item id."
        return _compact_validation_report(report) if compact_result else report

    sync_result = sync_derived_item_contract(
        derived_item_id=effective_item_id,
        scope=scope,
        expected_collection_id=effective_expected_collection_id,
        original_collection_id=original_collection_id,
        root_href=root_href,
        stac_version=expected_stac_version,
        mode=mode,
        ensure_original_attachment=autofix_ensure_original_attachment,
        ensure_facet_value_item_links=autofix_ensure_relationship_links,
        ensure_original_related_link=autofix_ensure_relationship_links,
        fix_profile=autofix_fix_profile,
        fix_bbox_from_geometry=autofix_fix_bbox,
        allow_create_missing_objects=autofix_allow_create_missing_objects,
        client=client,
        compact_result=False,
    )
    report["autofix"] = sync_result
    report["autofix_applied"] = bool(sync_result.get("updated"))

    if not report["autofix_applied"]:
        return _compact_validation_report(report) if compact_result else report

    if not autofix_apply_remote:
        report["post_fix_validation"] = {
            "valid": None,
            "summary": "Skipped (autofix_apply_remote=False).",
            "errors": [],
        }
        report["valid"] = None
        report["summary"] = "Autofix applied; remote re-validation skipped."
        report["errors"] = []
        report["checks"] = {}
        report["state_checks"] = {}
        return _compact_validation_report(report) if compact_result else report

    refreshed_payload, refresh_error = _load_payload_from_source(
        source="server",
        item_path=None,
        expected_item_id=effective_item_id,
        scope=scope,
        client=client,
    )
    if refresh_error or refreshed_payload is None:
        report["autofix_error"] = refresh_error
        return _compact_validation_report(report) if compact_result else report

    post_fix = _evaluate_derived_item_payload(
        item_payload=refreshed_payload,
        schema_payload=schema_payload,
        validation_phase=resolved_validation_phase,
        scope=scope,
        expected_item_id=expected_item_id,
        state_item_id=effective_item_id,
        expected_collection_id=effective_expected_collection_id,
        root_href=root_href,
        expected_stac_version=expected_stac_version,
        check_catalog_state=check_catalog_state,
        client=client,
        original_collection_id=original_collection_id,
        enforce_profile_mapping=schema_path is None,
    )
    report["post_fix_validation"] = post_fix
    report["valid"] = post_fix["valid"]
    post_fix_error_count = len(post_fix.get("errors", [])) if isinstance(post_fix.get("errors"), list) else 0
    if post_fix["valid"] is True:
        report["summary"] = "Autofix applied and post-fix validation passed."
    elif post_fix["valid"] is False:
        report["summary"] = (
            f"Autofix applied but {post_fix_error_count} validation issue(s) remain."
        )
    else:
        report["summary"] = "Autofix applied; post-fix validation result is unknown."
    report["errors"] = post_fix["errors"]
    report["schema_valid"] = post_fix["schema_valid"]
    report["item_id"] = post_fix["item_id"]
    report["collection_field"] = post_fix["collection_field"]
    report["parsed_id"] = post_fix["parsed_id"]
    report["checks"] = post_fix["checks"]
    report["state_checks"] = post_fix["state_checks"]
    report["facet_value_catalog_membership"] = post_fix["facet_value_catalog_membership"]
    report["collection_backlink"] = post_fix["collection_backlink"]
    report["original_item_backlink"] = post_fix["original_item_backlink"]

    return _compact_validation_report(report) if compact_result else report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Validate a derived STAC item payload.")
    parser.add_argument("--post-publish", action="store_true",
                        help="Run post-publish validation mode (default infers mode from --source).")
    parser.add_argument("--source", choices=("local", "server"), default="local",
                        help="Read payload from local file or from server metadata.")
    parser.add_argument("item_path", nargs="?", default=None,
                        help="Path to derived-item JSON file (required when --source=local).")
    parser.add_argument("--schema-path", default=None,
                        help="Optional schema path; otherwise selected from collection id.")
    parser.add_argument("--scope", default="dafab", help="Scope where objects are expected.")
    parser.add_argument("--expected-item-id", default=None,
                        help="Expected item id; required when --source=server.")
    parser.add_argument("--expected-collection-id", default=None, help="Expected collection id.")
    parser.add_argument("--original-collection-id", default="sentinel_2_l2a",
                        help="Collection id containing the original source item.")
    parser.add_argument("--root-href", default="https://dafab.cern.ch/stac", help="Expected STAC root href.")
    parser.add_argument("--expected-stac-version", default="1.1.0", help="Expected stac_version value.")
    parser.add_argument("--disable-catalog-state-checks", action="store_true",
                        help="Disable existence/hierarchy/backlink checks.")
    parser.add_argument("--autofix", action="store_true", help="Attempt to repair derived-item contract fields.")
    parser.add_argument("--disable-autofix-remote-recheck", action="store_true",
                        help="Skip revalidation after applying autofix.")
    parser.add_argument("--disable-autofix-profile", action="store_true",
                        help="Skip profile block/algorithm version normalization.")
    parser.add_argument("--disable-autofix-bbox", action="store_true",
                        help="Skip bbox recomputation from geometry.")
    parser.add_argument("--disable-autofix-original-attachment", action="store_true",
                        help="Skip original collection attachment repair.")
    parser.add_argument("--disable-autofix-relationship-links", action="store_true",
                        help="Skip relationship link repair in facet value and original item metadata.")
    parser.add_argument("--allow-create-missing-objects", action="store_true",
                        help="Allow autofix to create missing objects before relationship fixes.")
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic",
                        help="Metadata patch execution mode used by autofix.")
    args = parser.parse_args()
    if args.source == "server" and (not args.expected_item_id or not args.expected_item_id.strip()):
        parser.error("--expected-item-id is required when --source=server.")

    result = validate_derived_item(
        post_publish=True if args.post_publish else None,
        source=args.source,
        item_path=args.item_path,
        schema_path=args.schema_path,
        scope=args.scope,
        expected_item_id=args.expected_item_id,
        expected_collection_id=args.expected_collection_id,
        original_collection_id=args.original_collection_id,
        root_href=args.root_href,
        expected_stac_version=args.expected_stac_version,
        check_catalog_state=None if not args.disable_catalog_state_checks else False,
        autofix=args.autofix,
        autofix_apply_remote=not args.disable_autofix_remote_recheck,
        autofix_fix_profile=not args.disable_autofix_profile,
        autofix_fix_bbox=not args.disable_autofix_bbox,
        autofix_ensure_original_attachment=not args.disable_autofix_original_attachment,
        autofix_ensure_relationship_links=not args.disable_autofix_relationship_links,
        autofix_allow_create_missing_objects=args.allow_create_missing_objects,
        mode=args.mode,
    )
    print(result)
    exit(0 if result.get("valid") else 1)
