"""Validate and optionally repair original-item metadata against DaFab contract phases."""

from __future__ import annotations

import argparse
import copy
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, Optional
from urllib.parse import urlparse

from jsonschema import Draft7Validator

from dafab_client._rucio.common.exception import DataIdentifierNotFound
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

from dafab_client.helpers.metadata_management.Operations.common import load_json_file
from dafab_client.helpers.metadata_management.Workflows.update_original_item import (
    build_original_item_navigation_links,
    discover_generated_item_related_links,
    sync_original_item_contract,
)
from dafab_client.helpers.runtime_paths import load_json_schema

LOG = setup_logger(__name__)

DEFAULT_SCHEMA_PATH = "Schema_Copernicus_with_dafab.json"
ValidationPhase = Literal["pre_publish", "post_publish"]
ValidationSource = Literal["local", "server"]
STATE_ERROR_PREFIXES = (
    "rucio_item:",
    "rucio_collection:",
    "rucio_hierarchy:",
    "collection_navigation:",
    "collection_metadata:",
    "catalog_state:",
)


def _resolve_validation_phase(
        *,
        source: ValidationSource,
        post_publish: Optional[bool],
) -> ValidationPhase:
    if post_publish is not None:
        return "post_publish" if post_publish else "pre_publish"
    return "post_publish" if source == "server" else "pre_publish"


def _schema_errors(payload: Any, schema: dict[str, Any]) -> list[str]:
    validator = Draft7Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda error: list(error.absolute_path))
    output: list[str] = []
    for error in errors:
        path = "/".join(str(token) for token in error.absolute_path) or "<root>"
        output.append(f"schema:{path}: {error.message}")
    return output


def _collect_hrefs_by_rel(links: Any) -> dict[str, list[str]]:
    hrefs_by_rel: dict[str, list[str]] = {}
    if not isinstance(links, list):
        return hrefs_by_rel
    for link in links:
        if not isinstance(link, dict):
            continue
        rel = link.get("rel")
        href = link.get("href")
        if not isinstance(rel, str) or not isinstance(href, str):
            continue
        hrefs_by_rel.setdefault(rel, []).append(href)
    return hrefs_by_rel


def _item_id_from_href(href: str) -> Optional[str]:
    parsed = urlparse(href)
    segment = parsed.path.rstrip("/").split("/")[-1]
    if not segment:
        return None
    if segment.endswith(".json"):
        segment = segment[:-5]
    return segment or None


def _parse_timestamp(value: Any) -> tuple[Optional[datetime], Optional[str]]:
    if not isinstance(value, str) or not value.strip():
        return None, "missing or empty timestamp value."
    candidate = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(candidate), None
    except ValueError:
        return None, f"timestamp '{value}' is not ISO-8601 parseable."


def _did_exists_with_type_with_error(
        client: Any,
        scope: str,
        name: str,
        expected_type: str,
) -> tuple[Optional[bool], Optional[str]]:
    try:
        did = client.get_did(scope=scope, name=name)
    except DataIdentifierNotFound:
        return False, None
    except Exception as exc:
        return None, f"catalog_state: failed to read object '{scope}:{name}': {exc}"
    return str(did.get("type", "")).upper() == expected_type.upper(), None


def _did_exists_with_type(client: Any, scope: str, name: str, expected_type: str) -> bool:
    exists, _ = _did_exists_with_type_with_error(client, scope, name, expected_type)
    return bool(exists)


def _is_child_attached_with_error(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        child_name: str,
) -> tuple[Optional[bool], Optional[str]]:
    try:
        content_entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception as exc:
        return None, f"catalog_state: failed to list members of '{scope}:{parent_name}': {exc}"
    for child in content_entries:
        if not isinstance(child, dict):
            continue
        child_scope = child.get("scope")
        child_scope_text = str(child_scope) if child_scope is not None else scope
        if child_scope_text == scope and child.get("name") == child_name:
            return True, None
    return False, None


def _is_child_attached(client: Any, *, scope: str, parent_name: str, child_name: str) -> bool:
    attached, _ = _is_child_attached_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        child_name=child_name,
    )
    return bool(attached)


def _has_item_href_link(links: Any, *, item_href: str) -> bool:
    if not isinstance(links, list):
        return False
    for link in links:
        if not isinstance(link, dict):
            continue
        if str(link.get("rel", "")).strip() != "item":
            continue
        if str(link.get("href", "")).strip() == item_href:
            return True
    return False


def _normalize_collection_id(value: str) -> str:
    return value.strip().lower().replace("-", "_")


def _validate_bbox(bbox: Any) -> tuple[Optional[bool], Optional[str]]:
    if not isinstance(bbox, list):
        return False, "bbox must be a list."
    if len(bbox) not in (4, 6):
        return False, "bbox must have either 4 (2D) or 6 (3D) numeric values."
    if not all(isinstance(v, (int, float)) for v in bbox):
        return False, "bbox values must be numeric."
    if len(bbox) == 4:
        if bbox[0] > bbox[2] or bbox[1] > bbox[3]:
            return False, "bbox has invalid 2D min/max ordering."
    if len(bbox) == 6:
        if bbox[0] > bbox[3] or bbox[1] > bbox[4] or bbox[2] > bbox[5]:
            return False, "bbox has invalid 3D min/max ordering."
    return True, None


def _validate_item_id_semantics(item_id: Any, sequence: Any) -> tuple[Optional[bool], list[str]]:
    issues: list[str] = []
    if not isinstance(item_id, str) or not item_id.strip():
        return False, ["item id is missing or empty."]

    parts = item_id.split("_")
    if len(parts) < 5:
        issues.append("item id does not match expected Sentinel token layout '<platform>_<tile>_<date>_<sequence>_<level>'.")
        return False, issues

    platform_token = parts[0]
    sequence_token = parts[-2]
    level_token = parts[-1]

    if not platform_token.startswith("S2"):
        issues.append(f"item id platform token '{platform_token}' does not look like Sentinel-2.")
    if not sequence_token.isdigit():
        issues.append(f"item id sequence token '{sequence_token}' is not numeric.")
    if level_token not in {"L1C", "L2A"}:
        issues.append(f"item id level token '{level_token}' is not one of expected values (L1C/L2A).")

    if sequence is not None and str(sequence) != sequence_token:
        issues.append(
            f"properties['s2:sequence'] ('{sequence}') does not match item id sequence token '{sequence_token}'."
        )

    return len(issues) == 0, issues


def _extract_document(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    document = payload.get("document")
    if isinstance(document, dict):
        return document
    return payload


def _load_payload_from_source(
        *,
        source: ValidationSource,
        item_path: str | Path | None,
        expected_item_id: str | None,
        scope: str,
        client: Any,
) -> tuple[Optional[dict[str, Any]], Optional[str]]:
    if source == "local":
        if item_path is None:
            return None, "item_file: 'item_path' is required when source='local'."
        try:
            payload = load_json_file(item_path)
        except Exception as exc:
            return None, f"item_file: could not load item file '{item_path}': {exc}"
        if not isinstance(payload, dict):
            return None, "item_file: payload must be a JSON object."
        return payload, None

    if source == "server":
        if not expected_item_id or not expected_item_id.strip():
            return None, "server_source: non-empty 'expected_item_id' is required when source='server'."
        if client is None:
            return None, "server_source: client connection is not available."
        try:
            response = client.get_metadata_document(scope=scope, name=expected_item_id)
        except Exception as exc:
            return None, f"server_source: failed to load metadata document for '{scope}:{expected_item_id}': {exc}"
        payload = _extract_document(response)
        if not payload:
            return None, f"server_source: metadata document for '{scope}:{expected_item_id}' is empty."
        return payload, None

    return None, f"validation_source: unsupported source '{source}'."


def _compute_stage_links(
        *,
        item_id: str,
        collection_id: str,
        root_href: str,
        existing_links: Any,
        include_related_links: bool,
        related_hrefs: Optional[list[str]],
) -> list[dict[str, Any]]:
    navigation_links = build_original_item_navigation_links(
        original_item_id=item_id,
        collection_id=collection_id,
        root_href=root_href,
    )

    base_links = [link for link in existing_links if isinstance(link, dict)] if isinstance(existing_links, list) else []
    remove_rels = {"root", "self", "collection"}
    if include_related_links and related_hrefs is not None:
        remove_rels.add("related")

    merged_links: list[dict[str, Any]] = []
    for link in base_links:
        rel = str(link.get("rel", "")).strip()
        href = str(link.get("href", "")).strip()
        if rel in remove_rels or not rel or not href:
            continue
        preserved_link = dict(link)
        preserved_link["rel"] = rel
        preserved_link["href"] = href
        merged_links.append(preserved_link)

    merged_links.extend(navigation_links)
    if include_related_links and related_hrefs is not None:
        merged_links.extend({"rel": "related", "href": href} for href in related_hrefs)

    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for link in merged_links:
        rel = str(link.get("rel", "")).strip()
        href = str(link.get("href", "")).strip()
        if not rel or not href:
            continue
        key = (rel, href)
        if key in seen:
            continue
        seen.add(key)
        normalized_link = dict(link)
        normalized_link["rel"] = rel
        normalized_link["href"] = href
        deduped.append(normalized_link)
    return deduped


def _evaluate_original_item_payload(
        *,
        item_payload: dict[str, Any],
        schema_payload: dict[str, Any],
        validation_phase: ValidationPhase,
        scope: str,
        expected_item_id: Optional[str],
        state_item_id: Optional[str],
        expected_collection_id: Optional[str],
        root_href: str,
        expected_stac_version: str,
        check_catalog_state: bool,
        check_related_links: bool,
        client: Any,
) -> dict[str, Any]:
    """Evaluate one original-item payload and return a structured report.

    Args:
        item_payload: Payload to validate.
        schema_payload: JSON schema used for structure checks.
        validation_phase: Validation profile controlling link/state expectations.
        scope: Scope used for optional state checks.
        expected_item_id: Optional strict expected item id.
        state_item_id: Catalog object id used for state checks and server-side sync targeting.
        expected_collection_id: Optional strict expected collection id.
        root_href: Expected root href for navigation checks.
        expected_stac_version: Expected ``stac_version`` value in post-publish mode.
        check_catalog_state: Enable object existence/hierarchy checks against catalog state.
        check_related_links: Enable generated-item related-link coverage checks.
        client: Client instance used for state checks.

    Returns:
        dict[str, Any]: Full validation report (checks, state checks, errors, summary).
    """
    report: dict[str, Any] = {
        "valid": False,
        "schema_valid": False,
        "item_id": None,
        "collection_field": None,
        "checks": {
            "core_fields_valid": None,
            "link_structure_valid": None,
            "link_id_consistency_valid": None,
            "root_link_valid": None,
            "dafab_navigation_links_valid": None,
            "stac_version_valid": None,
            "geometry_valid": None,
            "bbox_valid": None,
            "temporal_valid": None,
            "assets_valid": None,
            "item_id_semantics_valid": None,
            "collection_name_compatible": None,
            "related_links_valid": None,
        },
        "did_checks": {
            "item_exists_as_dataset": None,
            "collection_exists_as_container": None,
            "collection_contains_item": None,
            "collection_metadata_includes_item_href": None,
        },
        "collection_backlink": {
            "expected_item_href": None,
            "present": None,
            "error": None,
        },
        "related_link_analysis": {
            "generated_item_ids": [],
            "expected_related_hrefs": [],
            "actual_related_hrefs": [],
            "missing_related_hrefs": [],
            "unexpected_related_hrefs": [],
            "unparsed_generated_item_ids": [],
        },
        "errors": [],
        "summary": "",
    }
    errors: list[str] = []

    schema_issues = _schema_errors(item_payload, schema_payload)
    report["schema_valid"] = len(schema_issues) == 0
    errors.extend(schema_issues)

    item_id = item_payload.get("id")
    collection_field = item_payload.get("collection")
    report["item_id"] = item_id
    report["collection_field"] = collection_field

    core_fields = {
        "type": item_payload.get("type"),
        "stac_version": item_payload.get("stac_version"),
        "id": item_id,
        "properties": item_payload.get("properties"),
        "geometry": item_payload.get("geometry"),
        "bbox": item_payload.get("bbox"),
        "links": item_payload.get("links"),
        "assets": item_payload.get("assets"),
        "collection": collection_field,
    }
    missing_core = [field for field, value in core_fields.items() if value in (None, "", [], {})]
    if missing_core:
        errors.append(f"core_fields: missing or empty fields: {missing_core}")
        report["checks"]["core_fields_valid"] = False
    else:
        report["checks"]["core_fields_valid"] = True

    if core_fields["type"] != "Feature":
        errors.append(f"core_fields:type: expected 'Feature', found '{core_fields['type']}'")
        report["checks"]["core_fields_valid"] = False

    if expected_item_id and isinstance(item_id, str) and item_id != expected_item_id:
        errors.append(f"id_consistency: expected item id '{expected_item_id}', found '{item_id}'")

    authoritative_item_id = (
        state_item_id.strip()
        if isinstance(state_item_id, str) and state_item_id.strip()
        else item_id.strip()
        if isinstance(item_id, str) and item_id.strip()
        else None
    )

    links = core_fields["links"]
    hrefs_by_rel = _collect_hrefs_by_rel(links)
    self_links = hrefs_by_rel.get("self", [])
    canonical_links = hrefs_by_rel.get("canonical", [])
    derived_from_links = hrefs_by_rel.get("derived_from", [])
    root_links = hrefs_by_rel.get("root", [])
    collection_links = hrefs_by_rel.get("collection", [])

    link_structure_valid = True
    if validation_phase == "pre_publish":
        if len(self_links) != 1:
            link_structure_valid = False
            errors.append(f"links: expected exactly one 'self' link, found {len(self_links)}")
        if len(canonical_links) != 1:
            link_structure_valid = False
            errors.append(f"links: expected exactly one 'canonical' link, found {len(canonical_links)}")
        if len(derived_from_links) < 1:
            link_structure_valid = False
            errors.append("links: expected at least one 'derived_from' link.")

        if root_links:
            root_valid = all(link == root_href for link in root_links)
            report["checks"]["root_link_valid"] = root_valid
            if not root_valid:
                errors.append(f"root_link: expected all root hrefs to be '{root_href}', found {root_links}")

        link_id_consistency_valid = False
        if isinstance(item_id, str):
            for rel_name, rel_links in {"self": self_links, "canonical": canonical_links}.items():
                for href in rel_links:
                    parsed_id = _item_id_from_href(href)
                    if parsed_id is None:
                        errors.append(f"links:{rel_name}: could not extract item id from href '{href}'")
                        continue
                    if parsed_id != item_id:
                        errors.append(
                            f"links:{rel_name}: href-derived id '{parsed_id}' does not match payload id '{item_id}'"
                        )
            if len(self_links) == 1 and len(canonical_links) == 1:
                parsed_self_id = _item_id_from_href(self_links[0])
                parsed_canonical_id = _item_id_from_href(canonical_links[0])
                link_id_consistency_valid = (
                    parsed_self_id is not None
                    and parsed_canonical_id is not None
                    and parsed_self_id == item_id
                    and parsed_canonical_id == item_id
                )
        report["checks"]["link_id_consistency_valid"] = link_id_consistency_valid

    if validation_phase == "post_publish":
        if len(root_links) != 1:
            link_structure_valid = False
            errors.append(f"links: expected exactly one 'root' link, found {len(root_links)}")
        if len(self_links) != 1:
            link_structure_valid = False
            errors.append(f"links: expected exactly one 'self' link, found {len(self_links)}")
        if len(collection_links) != 1:
            link_structure_valid = False
            errors.append(f"links: expected exactly one 'collection' link, found {len(collection_links)}")

        report["checks"]["stac_version_valid"] = core_fields["stac_version"] == expected_stac_version
        if not report["checks"]["stac_version_valid"]:
            errors.append(
                f"stac_version: expected '{expected_stac_version}', found '{core_fields['stac_version']}'."
            )

        effective_collection_id = (
            expected_collection_id
            if isinstance(expected_collection_id, str)
            else collection_field if isinstance(collection_field, str) else None
        )
        navigation_valid = True
        if isinstance(item_id, str) and isinstance(effective_collection_id, str):
            expected_links = {
                link["rel"]: link["href"]
                for link in build_original_item_navigation_links(
                    original_item_id=item_id,
                    collection_id=effective_collection_id,
                    root_href=root_href,
                )
            }
            actual_links = {
                "root": root_links[0] if len(root_links) == 1 else None,
                "self": self_links[0] if len(self_links) == 1 else None,
                "collection": collection_links[0] if len(collection_links) == 1 else None,
            }
            for rel, expected_href in expected_links.items():
                if actual_links.get(rel) != expected_href:
                    navigation_valid = False
                    errors.append(
                        f"links:{rel}: expected '{expected_href}', found '{actual_links.get(rel)}'."
                    )
        else:
            navigation_valid = False
            errors.append("links:navigation: could not validate navigation links (missing item id or collection id).")
        report["checks"]["dafab_navigation_links_valid"] = navigation_valid

        if len(root_links) == 1:
            report["checks"]["root_link_valid"] = root_links[0] == root_href
            if root_links[0] != root_href:
                errors.append(f"root_link: expected '{root_href}', found '{root_links[0]}'")

        link_id_consistency_valid = False
        if isinstance(item_id, str) and len(self_links) == 1:
            link_id_consistency_valid = True
            parsed_id = _item_id_from_href(self_links[0])
            if parsed_id != item_id:
                link_id_consistency_valid = False
                errors.append(
                    f"links:self: href-derived id '{parsed_id}' does not match payload id '{item_id}'"
                )
        report["checks"]["link_id_consistency_valid"] = link_id_consistency_valid

        if check_related_links:
            if client is not None and isinstance(authoritative_item_id, str):
                try:
                    discovered = discover_generated_item_related_links(
                        client=client,
                        scope=scope,
                        original_item_id=authoritative_item_id,
                        root_href=root_href,
                    )
                except Exception as exc:
                    report["checks"]["related_links_valid"] = None
                    errors.append(f"related_links: failed to discover related links: {exc}")
                else:
                    expected_related_hrefs = sorted(set(discovered.get("related_hrefs", [])))
                    actual_related_hrefs = sorted(set(hrefs_by_rel.get("related", [])))
                    missing_related_hrefs = sorted(set(expected_related_hrefs) - set(actual_related_hrefs))
                    unexpected_related_hrefs = sorted(set(actual_related_hrefs) - set(expected_related_hrefs))
                    unparsed_generated_item_ids = discovered.get("unparsed_generated_item_ids", [])

                    report["related_link_analysis"]["generated_item_ids"] = discovered.get("generated_item_ids", [])
                    report["related_link_analysis"]["expected_related_hrefs"] = expected_related_hrefs
                    report["related_link_analysis"]["actual_related_hrefs"] = actual_related_hrefs
                    report["related_link_analysis"]["missing_related_hrefs"] = missing_related_hrefs
                    report["related_link_analysis"]["unexpected_related_hrefs"] = unexpected_related_hrefs
                    report["related_link_analysis"]["unparsed_generated_item_ids"] = unparsed_generated_item_ids

                    related_valid = not missing_related_hrefs and not unexpected_related_hrefs
                    report["checks"]["related_links_valid"] = related_valid if not unparsed_generated_item_ids else None
                    if missing_related_hrefs:
                        errors.append(f"related_links: missing expected hrefs: {missing_related_hrefs}")
                    if unexpected_related_hrefs:
                        errors.append(f"related_links: unexpected hrefs: {unexpected_related_hrefs}")
                    if unparsed_generated_item_ids:
                        errors.append(
                            "related_links: could not infer collection id for generated items "
                            f"{unparsed_generated_item_ids}"
                        )
            else:
                report["checks"]["related_links_valid"] = None

    report["checks"]["link_structure_valid"] = link_structure_valid

    geometry = core_fields["geometry"]
    geometry_valid = True
    if not isinstance(geometry, dict):
        geometry_valid = False
        errors.append("geometry: geometry must be an object.")
    else:
        if not isinstance(geometry.get("type"), str) or not geometry.get("type"):
            geometry_valid = False
            errors.append("geometry:type: missing or empty geometry type.")
        if "coordinates" not in geometry:
            geometry_valid = False
            errors.append("geometry:coordinates: missing coordinates.")
    report["checks"]["geometry_valid"] = geometry_valid

    bbox_ok, bbox_error = _validate_bbox(core_fields["bbox"])
    report["checks"]["bbox_valid"] = bbox_ok
    if bbox_error:
        errors.append(f"bbox: {bbox_error}")

    properties = core_fields["properties"] if isinstance(core_fields["properties"], dict) else {}
    temporal_valid = True
    datetime_value = properties.get("datetime")
    _, datetime_error = _parse_timestamp(datetime_value)
    if datetime_error:
        temporal_valid = False
        errors.append(f"properties:datetime: {datetime_error}")
    created_dt, created_error = _parse_timestamp(properties.get("created")) if "created" in properties else (None, None)
    updated_dt, updated_error = _parse_timestamp(properties.get("updated")) if "updated" in properties else (None, None)
    if created_error:
        temporal_valid = False
        errors.append(f"properties:created: {created_error}")
    if updated_error:
        temporal_valid = False
        errors.append(f"properties:updated: {updated_error}")
    if created_dt and updated_dt and created_dt > updated_dt:
        temporal_valid = False
        errors.append("properties:created_updated: 'created' timestamp is later than 'updated'.")
    report["checks"]["temporal_valid"] = temporal_valid

    assets = core_fields["assets"]
    assets_valid = True
    if not isinstance(assets, dict) or not assets:
        assets_valid = False
        errors.append("assets: expected a non-empty assets object.")
    else:
        for asset_name, asset_data in assets.items():
            if not isinstance(asset_data, dict):
                assets_valid = False
                errors.append(f"assets:{asset_name}: asset entry must be an object.")
                continue
            href = asset_data.get("href")
            mime_type = asset_data.get("type")
            if not isinstance(href, str) or not href.strip():
                assets_valid = False
                errors.append(f"assets:{asset_name}: missing or empty 'href'.")
            if not isinstance(mime_type, str) or not mime_type.strip():
                assets_valid = False
                errors.append(f"assets:{asset_name}: missing or empty 'type'.")
    report["checks"]["assets_valid"] = assets_valid

    item_id_semantics_valid, item_id_semantic_issues = _validate_item_id_semantics(item_id, properties.get("s2:sequence"))
    report["checks"]["item_id_semantics_valid"] = item_id_semantics_valid
    errors.extend([f"item_id_semantics: {issue}" for issue in item_id_semantic_issues])

    if expected_collection_id and isinstance(collection_field, str):
        compatibility = _normalize_collection_id(collection_field) == _normalize_collection_id(expected_collection_id)
        report["checks"]["collection_name_compatible"] = compatibility
        if not compatibility:
            errors.append(
                f"collection_consistency: payload collection '{collection_field}' is not compatible with expected "
                f"collection '{expected_collection_id}'."
            )

    if check_catalog_state and client is not None and isinstance(authoritative_item_id, str):
        item_exists, item_exists_error = _did_exists_with_type_with_error(
            client,
            scope,
            authoritative_item_id,
            "DATASET",
        )
        if item_exists_error:
            report["did_checks"]["item_exists_as_dataset"] = None
            errors.append(item_exists_error)
        else:
            report["did_checks"]["item_exists_as_dataset"] = item_exists
            if not item_exists:
                errors.append(f"rucio_item: '{scope}:{authoritative_item_id}' does not exist as a dataset DID.")

        effective_collection_id = expected_collection_id if isinstance(expected_collection_id, str) else collection_field
        if isinstance(effective_collection_id, str):
            collection_exists, collection_exists_error = _did_exists_with_type_with_error(
                client,
                scope,
                effective_collection_id,
                "CONTAINER",
            )
            if collection_exists_error:
                report["did_checks"]["collection_exists_as_container"] = None
                errors.append(collection_exists_error)
            else:
                report["did_checks"]["collection_exists_as_container"] = collection_exists
            if collection_exists is False:
                errors.append(
                    f"rucio_collection: '{scope}:{effective_collection_id}' does not exist as a container DID."
                )
            elif collection_exists is True:
                contains_item, contains_item_error = _is_child_attached_with_error(
                    client,
                    scope=scope,
                    parent_name=effective_collection_id,
                    child_name=authoritative_item_id,
                )
                if contains_item_error:
                    report["did_checks"]["collection_contains_item"] = None
                    errors.append(contains_item_error)
                else:
                    report["did_checks"]["collection_contains_item"] = contains_item
                    if not contains_item:
                        errors.append(
                            f"rucio_hierarchy: collection '{scope}:{effective_collection_id}' does not contain item "
                            f"'{scope}:{authoritative_item_id}'."
                        )

                if validation_phase == "post_publish":
                    expected_item_href = (
                        f"{root_href.rstrip('/')}/collections/{effective_collection_id}/items/{authoritative_item_id}"
                    )
                    report["collection_backlink"]["expected_item_href"] = expected_item_href
                    try:
                        collection_doc_response = client.get_metadata_document(
                            scope=scope,
                            name=effective_collection_id,
                        )
                        collection_doc = _extract_document(collection_doc_response)
                        backlink_present = _has_item_href_link(
                            collection_doc.get("links"),
                            item_href=expected_item_href,
                        )
                        report["collection_backlink"]["present"] = backlink_present
                        report["did_checks"]["collection_metadata_includes_item_href"] = backlink_present
                        if not backlink_present:
                            errors.append(
                                "collection_navigation: collection "
                                f"'{scope}:{effective_collection_id}' does not include item href "
                                f"'{expected_item_href}' in `links` with rel='item'."
                            )
                    except Exception as exc:
                        report["collection_backlink"]["error"] = str(exc)
                        errors.append(
                            "collection_metadata: failed to read collection metadata for "
                            f"'{scope}:{effective_collection_id}': {exc}"
                        )
        else:
            errors.append("collection_consistency: no expected collection id provided and payload collection is invalid.")

    report["errors"] = errors
    report["valid"] = len(errors) == 0
    report["summary"] = "Validation passed." if report["valid"] else f"{len(errors)} validation issue(s) found."
    return report


def _autofix_payload_for_stage1(
        *,
        payload: dict[str, Any],
        item_id: str,
        collection_id: str,
        root_href: str,
        stac_version: str,
        include_related_links: bool,
        related_hrefs: Optional[list[str]],
) -> dict[str, Any]:
    updated = copy.deepcopy(payload)
    updated["stac_version"] = stac_version
    updated["collection"] = collection_id
    updated["links"] = _compute_stage_links(
        item_id=item_id,
        collection_id=collection_id,
        root_href=root_href,
        existing_links=updated.get("links"),
        include_related_links=include_related_links,
        related_hrefs=related_hrefs,
    )
    return updated


def _failed_checks(checks: Any) -> list[str]:
    if not isinstance(checks, dict):
        return []
    return sorted([name for name, status in checks.items() if status is False])


def _is_state_error(error: str) -> bool:
    return any(error.startswith(prefix) for prefix in STATE_ERROR_PREFIXES)


def _compact_related_link_analysis(analysis: Any) -> dict[str, Any]:
    if not isinstance(analysis, dict):
        return {
            "generated_item_count": 0,
            "expected_href_count": 0,
            "actual_href_count": 0,
            "missing_href_count": 0,
            "unexpected_href_count": 0,
            "unparsed_generated_item_count": 0,
        }
    return {
        "generated_item_count": len(analysis.get("generated_item_ids", [])),
        "expected_href_count": len(analysis.get("expected_related_hrefs", [])),
        "actual_href_count": len(analysis.get("actual_related_hrefs", [])),
        "missing_href_count": len(analysis.get("missing_related_hrefs", [])),
        "unexpected_href_count": len(analysis.get("unexpected_related_hrefs", [])),
        "unparsed_generated_item_count": len(analysis.get("unparsed_generated_item_ids", [])),
    }


def _log_validation_details(report: dict[str, Any]) -> None:
    failed_checks = _failed_checks(report.get("checks"))
    LOG.info(
        "Validation details: item=%s mode=%s valid=%s failed_checks=%s",
        report.get("item_id"),
        report.get("validation_phase"),
        report.get("valid"),
        failed_checks,
    )
    did_checks = report.get("did_checks")
    if isinstance(did_checks, dict):
        LOG.info("State checks: %s", did_checks)

    backlink = report.get("collection_backlink")
    if isinstance(backlink, dict) and backlink.get("expected_item_href"):
        LOG.info(
            "Collection backlink details: expected_href=%s present=%s error=%s",
            backlink.get("expected_item_href"),
            backlink.get("present"),
            backlink.get("error"),
        )

    analysis = report.get("related_link_analysis")
    if isinstance(analysis, dict):
        LOG.info("Related-link summary: %s", _compact_related_link_analysis(analysis))
        if analysis.get("missing_related_hrefs"):
            LOG.info("Missing related hrefs: %s", analysis.get("missing_related_hrefs"))
        if analysis.get("unexpected_related_hrefs"):
            LOG.info("Unexpected related hrefs: %s", analysis.get("unexpected_related_hrefs"))
        if analysis.get("unparsed_generated_item_ids"):
            LOG.info("Unparsed generated item IDs: %s", analysis.get("unparsed_generated_item_ids"))

    errors = report.get("errors", [])
    if isinstance(errors, list):
        for error in errors:
            LOG.info("Validation issue detail: %s", error)


def _compact_validation_report(report: dict[str, Any]) -> dict[str, Any]:
    checks = report.get("checks") if isinstance(report.get("checks"), dict) else {}
    did_checks = report.get("did_checks") if isinstance(report.get("did_checks"), dict) else {}
    errors = report.get("errors") if isinstance(report.get("errors"), list) else []
    valid_value = report.get("valid")

    compact: dict[str, Any] = {
        "valid": valid_value if isinstance(valid_value, bool) or valid_value is None else bool(valid_value),
        "summary": report.get("summary"),
        "validation_phase": report.get("validation_phase"),
        "source": report.get("source"),
        "scope": report.get("scope"),
        "item_id": report.get("item_id"),
        "collection_field": report.get("collection_field"),
        "expected_item_id": report.get("expected_item_id"),
        "expected_collection_id": report.get("expected_collection_id"),
        "schema_valid": report.get("schema_valid"),
        "checks": checks,
        "did_checks": did_checks,
        "collection_backlink": report.get("collection_backlink"),
        "failed_checks": _failed_checks(checks),
        "error_count": len(errors),
        "errors": errors[:10],
        "autofix_requested": bool(report.get("autofix_requested")),
        "autofix_applied": bool(report.get("autofix_applied")),
        "related_link_summary": _compact_related_link_analysis(report.get("related_link_analysis")),
    }
    if len(errors) > 10:
        compact["errors_truncated"] = True

    if report.get("autofix_error"):
        compact["autofix_error"] = report.get("autofix_error")
    if report.get("autofix_written_path"):
        compact["autofix_written_path"] = report.get("autofix_written_path")

    autofix_remote = report.get("autofix")
    if isinstance(autofix_remote, dict):
        compact["autofix_remote"] = {
            "updated": bool(autofix_remote.get("updated")),
            "error": autofix_remote.get("error"),
            "collection_item_link_updated": autofix_remote.get("collection_item_link_updated"),
        }

    post_fix = report.get("post_fix_validation")
    if isinstance(post_fix, dict):
        post_fix_errors = post_fix.get("errors") if isinstance(post_fix.get("errors"), list) else []
        post_fix_valid = post_fix.get("valid")
        compact["post_fix_validation"] = {
            "valid": (
                post_fix_valid
                if isinstance(post_fix_valid, bool) or post_fix_valid is None
                else bool(post_fix_valid)
            ),
            "summary": post_fix.get("summary"),
            "error_count": len(post_fix_errors),
        }

    return compact


def _finalize_validation_report(report: dict[str, Any], *, compact_result: bool) -> dict[str, Any]:
    if not compact_result:
        return report
    _log_validation_details(report)
    return _compact_validation_report(report)


def validate_original_item(
        *,
        post_publish: Optional[bool] = None,
        source: ValidationSource = "local",
        item_path: str | Path | None = None,
        schema_path: str | Path = DEFAULT_SCHEMA_PATH,
        scope: str = "dafab",
        expected_item_id: Optional[str] = None,
        expected_collection_id: Optional[str] = None,
        root_href: str = "https://dafab.cern.ch/stac",
        expected_stac_version: str = "1.1.0",
        check_catalog_state: Optional[bool] = None,
        check_related_links: bool = True,
        autofix: bool = False,
        autofix_write_back: bool = False,
        autofix_output_path: str | Path | None = None,
        autofix_include_related_links: bool = True,
        autofix_apply_remote: bool = True,
        mode: str = "atomic",
        compact_result: bool = True,
) -> dict[str, Any]:
    """
    Validate original-item metadata against pre-publish or post-publish DaFab contract checks.

    Modes:
    - pre-publish mode validates source payload before publication.
    - post-publish mode validates persisted/updated payload with DaFab stage-1 fields,
      and optionally verifies ``related`` links against generated items discovered in Rucio.

    Args:
        post_publish: Optional boolean mode selector. ``True`` enables post-publish mode,
            ``False`` enables pre-publish mode. When omitted, mode is inferred from ``source``.
        source: Payload source (`local` reads local JSON, `server` reads stored metadata).
        item_path: Local JSON path used when ``source='local'``.
        schema_path: Schema filename or explicit schema path used for JSON-structure validation.
        scope: Scope where objects are resolved for state checks.
        expected_item_id: Expected id for strict id consistency checks and the server
            lookup identifier when ``source='server'``.
        expected_collection_id: Optional expected collection id for compatibility checks.
        root_href: Expected STAC root href for navigation validation.
        expected_stac_version: Expected ``stac_version`` value in post-publish mode.
        check_catalog_state: Force-enable/disable state checks. ``None`` follows mode defaults.
        check_related_links: Validate ``related`` links against discovered generated items.
        autofix: Attempt post-publish contract repair when validation fails.
        autofix_write_back: Write repaired payload to disk in local-source mode.
        autofix_output_path: Optional output path for local-source autofix writes.
        autofix_include_related_links: Include regenerated ``related`` links during autofix.
        autofix_apply_remote: In server mode, re-validate after writing fixes back to the server.
        mode: Metadata patch execution mode for remote autofix.
        compact_result: Return compact report (``True``) or full report (``False``).

    Returns:
        dict[str, Any]: Validation report with checks, state checks, error list, and optional
        autofix/post-fix results.
    """

    if source not in {"local", "server"}:
        raise ValueError("Unsupported source. Use 'local' or 'server'.")
    if source == "server" and (not expected_item_id or not expected_item_id.strip()):
        raise ValueError("When source='server', 'expected_item_id' is required.")
    resolved_validation_phase = _resolve_validation_phase(
        source=source,
        post_publish=post_publish,
    )

    if check_catalog_state is None:
        check_catalog_state = resolved_validation_phase == "post_publish"

    report: dict[str, Any] = {
        "valid": False,
        "validation_phase": resolved_validation_phase,
        "source": source,
        "item_path": str(Path(item_path)) if item_path is not None else None,
        "schema_path": str(schema_path),
        "scope": scope,
        "item_id": expected_item_id if source == "server" else None,
        "expected_item_id": expected_item_id,
        "expected_collection_id": expected_collection_id,
        "expected_stac_version": expected_stac_version,
        "root_href": root_href,
        "autofix_requested": autofix,
        "autofix_applied": False,
    }

    errors: list[str] = []
    try:
        schema_payload, resolved_schema_source = load_json_schema(schema_path)
        report["schema_path"] = resolved_schema_source
    except Exception as schema_exc:
        # Compatibility fallback for call sites/tests that patch ``load_json_file``
        # and provide virtual schema paths.
        try:
            schema_payload = load_json_file(str(schema_path))
            report["schema_path"] = str(schema_path)
        except Exception:
            errors.append(f"schema_file: could not load schema '{schema_path}': {schema_exc}")
            report["errors"] = errors
            report["summary"] = f"{len(errors)} validation issue(s) found."
            return _finalize_validation_report(report, compact_result=compact_result)

    client = None
    needs_client = (
        source == "server"
        or check_catalog_state
        or (resolved_validation_phase == "post_publish" and check_related_links)
        or (
            source == "local"
            and resolved_validation_phase == "post_publish"
            and autofix
            and autofix_include_related_links
        )
    )
    if needs_client:
        try:
            client = connection_manager()
        except Exception as exc:
            errors.append(f"server_connection: failed to connect to server client: {exc}")

    payload, payload_error = _load_payload_from_source(
        source=source,
        item_path=item_path,
        expected_item_id=expected_item_id,
        scope=scope,
        client=client,
    )
    if payload_error:
        report["errors"] = errors + [payload_error]
        report["summary"] = f"{len(report['errors'])} validation issue(s) found."
        return _finalize_validation_report(report, compact_result=compact_result)

    evaluation = _evaluate_original_item_payload(
        item_payload=payload,
        schema_payload=schema_payload,
        validation_phase=resolved_validation_phase,
        scope=scope,
        expected_item_id=expected_item_id,
        state_item_id=expected_item_id if source == "server" else None,
        expected_collection_id=expected_collection_id,
        root_href=root_href,
        expected_stac_version=expected_stac_version,
        check_catalog_state=check_catalog_state,
        check_related_links=check_related_links,
        client=client,
    )
    report.update(evaluation)
    if errors:
        merged_errors = list(errors)
        for evaluation_error in report.get("errors", []):
            if evaluation_error not in merged_errors:
                merged_errors.append(evaluation_error)
        report["errors"] = merged_errors
        report["valid"] = len(merged_errors) == 0
        report["summary"] = "Validation passed." if report["valid"] else f"{len(merged_errors)} validation issue(s) found."

    if not autofix or resolved_validation_phase != "post_publish" or report["valid"]:
        if report["valid"]:
            LOG.result("Original item contract validation passed for '%s'.", report.get("item_id"))
        else:
            LOG.warning("Original item contract validation found %s issue(s).", len(report.get("errors", [])))
        return _finalize_validation_report(report, compact_result=compact_result)

    effective_item_id = expected_item_id if source == "server" else report.get("item_id")
    effective_collection_id = expected_collection_id or report.get("collection_field")
    if not isinstance(effective_item_id, str) or not isinstance(effective_collection_id, str):
        report["autofix_error"] = "autofix: requires both item id and collection id."
        return _finalize_validation_report(report, compact_result=compact_result)

    if source == "server":
        sync_result = sync_original_item_contract(
            original_item_id=effective_item_id,
            scope=scope,
            collection_id=effective_collection_id,
            root_href=root_href,
            stac_version=expected_stac_version,
            include_related_links=autofix_include_related_links,
            ensure_collection_item_link=True,
            preserve_existing_links=True,
            mode=mode,
        )
        report["autofix"] = sync_result
        report["autofix_applied"] = bool(sync_result.get("updated"))
        if not sync_result.get("updated"):
            return _finalize_validation_report(report, compact_result=compact_result)
        if not autofix_apply_remote:
            report["post_fix_validation"] = {
                "valid": None,
                "summary": "Skipped (autofix_apply_remote=False).",
                "errors": [],
            }
            report["valid"] = None
            report["summary"] = "Autofix applied; remote re-validation skipped."
            report["errors"] = []
            report["checks"] = {}
            report["did_checks"] = {}
            report["collection_backlink"] = {}
            report["related_link_analysis"] = {}
            return _finalize_validation_report(report, compact_result=compact_result)

        refreshed_payload, refresh_error = _load_payload_from_source(
            source="server",
            item_path=None,
            expected_item_id=effective_item_id,
            scope=scope,
            client=client,
        )
        if refresh_error or refreshed_payload is None:
            report["autofix_error"] = (
                refresh_error
                if isinstance(refresh_error, str) and refresh_error.strip()
                else f"server_source: metadata document for '{scope}:{effective_item_id}' is empty after autofix."
            )
            report["post_fix_validation"] = {
                "valid": None,
                "summary": "Skipped (post-fix metadata reload failed).",
                "errors": [],
            }
            report["valid"] = None
            report["summary"] = "Autofix applied; post-fix re-validation failed."
            report["errors"] = []
            report["checks"] = {}
            report["did_checks"] = {}
            report["collection_backlink"] = {}
            report["related_link_analysis"] = {}
            return _finalize_validation_report(report, compact_result=compact_result)

        post_fix = _evaluate_original_item_payload(
            item_payload=refreshed_payload,
            schema_payload=schema_payload,
            validation_phase=resolved_validation_phase,
            scope=scope,
            expected_item_id=expected_item_id,
            state_item_id=effective_item_id,
            expected_collection_id=expected_collection_id,
            root_href=root_href,
            expected_stac_version=expected_stac_version,
            check_catalog_state=check_catalog_state,
            check_related_links=check_related_links,
            client=client,
        )
        report["post_fix_validation"] = post_fix
        report["valid"] = post_fix["valid"]
        report["errors"] = post_fix["errors"]
        report["summary"] = post_fix["summary"]
        report["checks"] = post_fix["checks"]
        report["did_checks"] = post_fix["did_checks"]
        report["collection_backlink"] = post_fix["collection_backlink"]
        report["related_link_analysis"] = post_fix["related_link_analysis"]
        return _finalize_validation_report(report, compact_result=compact_result)

    pre_fix_errors = list(report.get("errors", []))
    pre_fix_valid = report.get("valid")
    pre_fix_summary = report.get("summary")
    pre_fix_checks = copy.deepcopy(report.get("checks"))
    pre_fix_related_link_analysis = copy.deepcopy(report.get("related_link_analysis"))
    pre_fix_did_checks = copy.deepcopy(report.get("did_checks"))
    pre_fix_collection_backlink = copy.deepcopy(report.get("collection_backlink"))

    discovered_related_hrefs: Optional[list[str]] = None
    if autofix_include_related_links and client is not None:
        try:
            discovered = discover_generated_item_related_links(
                client=client,
                scope=scope,
                original_item_id=effective_item_id,
                root_href=root_href,
            )
        except Exception as exc:
            errors.append(f"related_links: failed to discover related links during autofix: {exc}")
            report["autofix_discovery_error"] = str(exc)
        else:
            report["autofix_discovery"] = discovered
            unparsed_generated = discovered.get("unparsed_generated_item_ids", [])
            if unparsed_generated:
                errors.append(
                    "related_links: discovery incomplete during autofix; preserving existing related links "
                    f"for generated items {unparsed_generated}."
                )
            else:
                discovered_related_hrefs = discovered.get("related_hrefs", [])

    fixed_payload = _autofix_payload_for_stage1(
        payload=payload,
        item_id=effective_item_id,
        collection_id=effective_collection_id,
        root_href=root_href,
        stac_version=expected_stac_version,
        include_related_links=autofix_include_related_links,
        related_hrefs=discovered_related_hrefs,
    )
    output_path = Path(autofix_output_path) if autofix_output_path else (Path(item_path) if item_path else None)

    if autofix_write_back and output_path is not None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(fixed_payload, indent=2) + "\n")
        report["autofix_written_path"] = str(output_path)
        report["autofix_applied"] = True
    else:
        report["autofix_applied"] = False
    report["autofix_payload"] = fixed_payload

    post_fix = _evaluate_original_item_payload(
        item_payload=fixed_payload,
        schema_payload=schema_payload,
        validation_phase=resolved_validation_phase,
        scope=scope,
        expected_item_id=expected_item_id,
        state_item_id=expected_item_id if source == "server" else None,
        expected_collection_id=expected_collection_id,
        root_href=root_href,
        expected_stac_version=expected_stac_version,
        check_catalog_state=False,
        check_related_links=check_related_links,
        client=client,
    )
    report["post_fix_validation"] = post_fix
    if not autofix_write_back:
        report["valid"] = pre_fix_valid
        report["checks"] = pre_fix_checks if isinstance(pre_fix_checks, dict) else {}
        report["did_checks"] = pre_fix_did_checks if isinstance(pre_fix_did_checks, dict) else {}
        report["collection_backlink"] = (
            pre_fix_collection_backlink if isinstance(pre_fix_collection_backlink, dict) else {}
        )
        report["related_link_analysis"] = (
            pre_fix_related_link_analysis if isinstance(pre_fix_related_link_analysis, dict) else {}
        )

        merged_errors = list(pre_fix_errors)
        for attempt_error in errors:
            if attempt_error not in merged_errors:
                merged_errors.append(attempt_error)
        report["errors"] = merged_errors

        if isinstance(report["valid"], bool):
            report["summary"] = (
                "Validation passed."
                if report["valid"]
                else f"{len(report['errors'])} validation issue(s) found."
            )
        else:
            report["valid"] = len(report["errors"]) == 0
            report["summary"] = (
                "Validation passed."
                if report["valid"]
                else f"{len(report['errors'])} validation issue(s) found."
            )
        return _finalize_validation_report(report, compact_result=compact_result)

    report["valid"] = post_fix["valid"]
    report["errors"] = post_fix["errors"]
    report["summary"] = post_fix["summary"]
    report["checks"] = post_fix["checks"]
    report["did_checks"] = post_fix["did_checks"]
    report["collection_backlink"] = post_fix["collection_backlink"]
    report["related_link_analysis"] = post_fix["related_link_analysis"]
    state_errors = [error for error in pre_fix_errors if _is_state_error(error)] if check_catalog_state else []
    if check_catalog_state and isinstance(pre_fix_did_checks, dict):
        report["did_checks"] = pre_fix_did_checks
    if check_catalog_state and isinstance(pre_fix_collection_backlink, dict):
        report["collection_backlink"] = pre_fix_collection_backlink

    merged_errors: list[str] = []
    for error_group in (report.get("errors", []), state_errors, errors):
        for error in error_group:
            if error not in merged_errors:
                merged_errors.append(error)
    report["errors"] = merged_errors
    report["valid"] = len(merged_errors) == 0
    report["summary"] = "Validation passed." if report["valid"] else f"{len(merged_errors)} validation issue(s) found."
    return _finalize_validation_report(report, compact_result=compact_result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Validate/repair a STAC original-item payload.")
    parser.add_argument("--post-publish", action="store_true",
                        help="Run post-publish validation mode (default infers mode from --source).")
    parser.add_argument("--source", choices=("local", "server"), default="local",
                        help="Read payload from local file or from server metadata document.")
    parser.add_argument("item_path", nargs="?", default=None,
                        help="Path to original-item JSON file (required when --source=local).")
    parser.add_argument("--schema-path", default=DEFAULT_SCHEMA_PATH,
                        help="Schema filename or explicit schema path.")
    parser.add_argument("--scope", default="dafab", help="Rucio scope where DIDs are expected.")
    parser.add_argument("--expected-item-id", default=None,
                        help="Expected item id; required when --source=server.")
    parser.add_argument("--expected-collection-id", default=None, help="Expected Rucio collection/container id.")
    parser.add_argument("--root-href", default="https://dafab.cern.ch/stac", help="Expected STAC root href.")
    parser.add_argument("--expected-stac-version", default="1.1.0", help="Expected stac_version for post-publish mode.")
    parser.add_argument("--disable-rucio-state-checks", action="store_true",
                        help="Disable DID and attachment checks.")
    parser.add_argument("--disable-related-checks", action="store_true",
                        help="Disable related-link coverage checks in post-publish mode.")
    parser.add_argument("--autofix", action="store_true", help="Attempt to repair post-publish contract fields.")
    parser.add_argument("--autofix-write-back", action="store_true",
                        help="Write fixed payload back to disk (local source only).")
    parser.add_argument("--autofix-output-path", default=None,
                        help="Alternative path for writing fixed payload (local source only).")
    parser.add_argument("--no-autofix-related", action="store_true",
                        help="Do not synthesize related links during autofix.")
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic",
                        help="BulkMetaDoc execution mode for remote autofix.")
    args = parser.parse_args()
    if args.source == "server" and (not args.expected_item_id or not args.expected_item_id.strip()):
        parser.error("--expected-item-id is required when --source=server.")

    result = validate_original_item(
        post_publish=True if args.post_publish else None,
        source=args.source,
        item_path=args.item_path,
        schema_path=args.schema_path,
        scope=args.scope,
        expected_item_id=args.expected_item_id,
        expected_collection_id=args.expected_collection_id,
        root_href=args.root_href,
        expected_stac_version=args.expected_stac_version,
        check_catalog_state=None if not args.disable_rucio_state_checks else False,
        check_related_links=not args.disable_related_checks,
        autofix=args.autofix,
        autofix_write_back=args.autofix_write_back,
        autofix_output_path=args.autofix_output_path,
        autofix_include_related_links=not args.no_autofix_related,
        mode=args.mode,
    )
    print(result)
    exit(0 if result.get("valid") else 1)
