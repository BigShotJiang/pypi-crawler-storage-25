"""Validate STAC facet-value catalog files before catalog registration/attachment."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

from jsonschema import Draft7Validator

from dafab_client._rucio.common.exception import DataIdentifierNotFound
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger
from dafab_client.helpers.metadata_management.Operations.common import load_json_file
from dafab_client.helpers.runtime_paths import load_json_schema

LOG = setup_logger(__name__)

COLLECTION_TYPE_FILTER_PAYLOAD = {
    "filter": {
        "type": "comparison",
        "comparator": "equals",
        "path": ["type"],
        "value": "Collection",
        "valueType": "string",
    }
}


def _last_path_segment(href: str) -> str:
    parsed = urlparse(href)
    return parsed.path.rstrip("/").split("/")[-1]


def _collection_segment_from_item_href(href: str) -> Optional[str]:
    parsed = urlparse(href)
    tokens = [token for token in parsed.path.strip("/").split("/") if token]
    for index, token in enumerate(tokens):
        if token == "collections" and index + 1 < len(tokens):
            return tokens[index + 1]
    return None


def _schema_errors(payload: Any, schema: dict[str, Any]) -> list[str]:
    validator = Draft7Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda error: list(error.absolute_path))
    output: list[str] = []
    for error in errors:
        path = "/".join(str(token) for token in error.absolute_path) or "<root>"
        output.append(f"schema:{path}: {error.message}")
    return output


def _collect_hrefs_by_rel(links: Any) -> dict[str, list[str]]:
    hrefs_by_rel: dict[str, list[str]] = {}
    if not isinstance(links, list):
        return hrefs_by_rel
    for link in links:
        if not isinstance(link, dict):
            continue
        rel = link.get("rel")
        href = link.get("href")
        if not isinstance(rel, str) or not isinstance(href, str):
            continue
        hrefs_by_rel.setdefault(rel, []).append(href)
    return hrefs_by_rel


def _extract_items_from_stac_filter_response(response: Any) -> list[dict[str, Any]]:
    if not isinstance(response, list) or not response:
        return []
    first_entry = response[0]
    if not isinstance(first_entry, dict):
        return []
    items = first_entry.get("items")
    if not isinstance(items, list):
        return []
    return [item for item in items if isinstance(item, dict)]


def _list_collection_ids_via_filter(client: Any, *, scope: str) -> tuple[list[str], Optional[str]]:
    try:
        response = list(client.stac_filter({"scope": scope, **COLLECTION_TYPE_FILTER_PAYLOAD}))
    except Exception as exc:  # pragma: no cover - network/client dependent
        return [], f"collection_filter: failed to list collections via filtering: {exc}"

    collection_items = _extract_items_from_stac_filter_response(response)
    collection_ids = sorted(
        {item_id for item in collection_items if isinstance((item_id := item.get("id")), str)},
        key=len,
        reverse=True,
    )
    if not collection_ids:
        return [], "collection_filter: no collection ids returned by the Collection-type filter query."
    return collection_ids, None


def _split_item_identifier(
        item_id: str,
        *,
        collection_ids: list[str],
        href_collection_id: Optional[str] = None,
) -> tuple[Optional[dict[str, str]], Optional[str]]:
    if "_" not in item_id:
        return None, "item id has no '_' separator to extract version."

    body, version = item_id.rsplit("_", 1)
    if not version.isdigit():
        return None, f"item version suffix '{version}' is not numeric."

    preferred_collections: list[str] = []
    if href_collection_id:
        preferred_collections.append(href_collection_id)

    for collection_id in sorted(collection_ids, key=len, reverse=True):
        if collection_id not in preferred_collections:
            preferred_collections.append(collection_id)

    for collection_id in preferred_collections:
        marker = f"_{collection_id}"
        if not body.endswith(marker):
            continue
        original_item_id = body[:-len(marker)]
        if not original_item_id:
            return None, f"item id '{item_id}' has empty original-item component before collection '{collection_id}'."
        return {
            "container_id": collection_id,
            "version": version,
            "original_item_id": original_item_id,
        }, None

    return None, (
        f"could not map item id '{item_id}' to any known collection id "
        f"(candidates: {preferred_collections if preferred_collections else '<none>'})."
    )


def _did_exists_with_type(client: Any, scope: str, name: str, expected_type: str) -> bool:
    try:
        did = client.get_did(scope=scope, name=name)
    except DataIdentifierNotFound:
        return False
    except Exception:
        return False
    return str(did.get("type", "")).upper() == expected_type.upper()


def _is_child_attached(client: Any, *, scope: str, parent_name: str, child_name: str) -> bool:
    try:
        content_entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception:
        return False
    for child in content_entries:
        if not isinstance(child, dict):
            continue
        child_scope = child.get("scope")
        child_scope_text = str(child_scope) if child_scope is not None else scope
        if child_scope_text == scope and child.get("name") == child_name:
            return True
    return False


def validate_facet_value_catalog_file(
        catalog_path: str | Path,
        *,
        schema_path: str | Path,
        scope: str = "dafab",
        root_href: str = "https://dafab.cern.ch/stac",
) -> dict[str, Any]:
    """
    Validate a facet-value catalog JSON file and report all discovered issues.

    Validation includes:
    - JSON schema structure checks.
    - Link presence and consistency checks for ``root``, ``self`` and ``parent``.
    - Identifier consistency (``id`` equals last segment of ``self`` href).
    - Collection discovery via enhanced filtering (`type == Collection`) and id parsing for item links.
    - DID existence checks for self/parent catalogs, linked derived items, extracted original items, and containers.
    - Relationship checks ensuring:
      - parent catalog contains self catalog,
      - extracted container contains parent catalog.

    Args:
        catalog_path: Path to the facet-value catalog JSON payload.
        schema_path: Schema filename or explicit path used for structure validation.
        scope: Scope where catalogs/collections/items are expected for state checks.
        root_href: Expected root href for navigation link validation.

    Returns:
        dict[str, Any]: Validation report containing:
        - overall status (``valid``/``summary``),
        - schema and link checks,
        - parsed per-item ID components,
        - state/hierarchy checks,
        - full error list.
    """

    report: dict[str, Any] = {
        "valid": False,
        "catalog_path": str(Path(catalog_path)),
        "scope": scope,
        "schema_path": str(Path(schema_path)),
        "schema_valid": False,
        "catalog_id": None,
        "self_catalog_id": None,
        "parent_catalog_id": None,
        "item_ids": [],
        "collection_ids_from_filter": [],
        "parsed_item_links": [],
        "relationship_checks": {
            "parent_contains_self_catalog": None,
            "collection_contains_parent_catalog": {},
        },
        "errors": [],
        "summary": "",
    }
    errors: list[str] = []

    try:
        schema_payload, resolved_schema_source = load_json_schema(schema_path)
        report["schema_path"] = resolved_schema_source
    except Exception as schema_exc:
        # Compatibility fallback for call sites/tests that patch ``load_json_file``
        # and provide virtual schema paths.
        try:
            schema_payload = load_json_file(str(schema_path))
            report["schema_path"] = str(schema_path)
        except Exception:
            errors.append(f"schema_file: could not load schema '{schema_path}': {schema_exc}")
            report["errors"] = errors
            report["summary"] = f"{len(errors)} validation issue(s) found."
            return report

    try:
        catalog_payload = load_json_file(catalog_path)
    except Exception as exc:
        errors.append(f"catalog_file: could not load catalog file '{catalog_path}': {exc}")
        report["errors"] = errors
        report["summary"] = f"{len(errors)} validation issue(s) found."
        return report

    schema_issues = _schema_errors(catalog_payload, schema_payload)
    report["schema_valid"] = len(schema_issues) == 0
    errors.extend(schema_issues)

    catalog_id = catalog_payload.get("id") if isinstance(catalog_payload, dict) else None
    report["catalog_id"] = catalog_id

    links = catalog_payload.get("links") if isinstance(catalog_payload, dict) else None
    hrefs_by_rel = _collect_hrefs_by_rel(links)

    root_links = hrefs_by_rel.get("root", [])
    self_links = hrefs_by_rel.get("self", [])
    parent_links = hrefs_by_rel.get("parent", [])
    item_links = hrefs_by_rel.get("item", [])

    if len(root_links) != 1:
        errors.append(f"links: expected exactly one 'root' link, found {len(root_links)}")
    if len(self_links) != 1:
        errors.append(f"links: expected exactly one 'self' link, found {len(self_links)}")
    if len(parent_links) != 1:
        errors.append(f"links: expected exactly one 'parent' link, found {len(parent_links)}")

    root_link = root_links[0] if root_links else None
    self_link = self_links[0] if self_links else None
    parent_link = parent_links[0] if parent_links else None

    if isinstance(root_link, str) and root_link != root_href:
        errors.append(f"root_link: expected '{root_href}', found '{root_link}'")

    self_catalog_id = _last_path_segment(self_link) if isinstance(self_link, str) else None
    parent_catalog_id = _last_path_segment(parent_link) if isinstance(parent_link, str) else None

    report["self_catalog_id"] = self_catalog_id
    report["parent_catalog_id"] = parent_catalog_id

    if isinstance(catalog_id, str) and isinstance(self_catalog_id, str) and catalog_id != self_catalog_id:
        errors.append(
            f"id_consistency: catalog id '{catalog_id}' does not match self href last segment '{self_catalog_id}'"
        )

    extracted_item_rows: list[dict[str, Any]] = []
    item_ids: list[str] = []
    for index, item_href in enumerate(item_links):
        item_id = _last_path_segment(item_href)
        if not item_id:
            errors.append(f"item_link[{index}]: could not extract item id from href '{item_href}'")
            continue
        item_ids.append(item_id)
        extracted_item_rows.append(
            {
                "item_href": item_href,
                "item_id": item_id,
                "href_collection_id": _collection_segment_from_item_href(item_href),
                "version": None,
                "container_id": None,
                "original_item_id": None,
                "checks": {
                    "derived_item_exists_as_dataset": None,
                    "original_item_exists_as_dataset": None,
                    "container_exists_as_container": None,
                    "container_contains_parent_catalog": None,
                },
            }
        )
    report["item_ids"] = item_ids

    client = None
    try:
        client = connection_manager()
    except Exception as exc:
        errors.append(f"rucio_connection: failed to connect to Rucio client: {exc}")

    if client is not None:
        collection_ids, collection_filter_error = _list_collection_ids_via_filter(client, scope=scope)
        report["collection_ids_from_filter"] = collection_ids
        if collection_filter_error:
            errors.append(collection_filter_error)

        if isinstance(self_catalog_id, str):
            if not _did_exists_with_type(client, scope, self_catalog_id, "CONTAINER"):
                errors.append(
                    f"rucio_catalog: '{scope}:{self_catalog_id}' does not exist as a catalog/collection container"
                )

        if isinstance(parent_catalog_id, str):
            if not _did_exists_with_type(client, scope, parent_catalog_id, "CONTAINER"):
                errors.append(
                    f"rucio_parent_catalog: '{scope}:{parent_catalog_id}' does not exist as a catalog/collection container"
                )

        if isinstance(parent_catalog_id, str) and isinstance(self_catalog_id, str):
            parent_contains_self = _is_child_attached(
                client,
                scope=scope,
                parent_name=parent_catalog_id,
                child_name=self_catalog_id,
            )
            report["relationship_checks"]["parent_contains_self_catalog"] = parent_contains_self
            if not parent_contains_self:
                errors.append(
                    f"rucio_hierarchy: parent catalog '{scope}:{parent_catalog_id}' does not contain self catalog "
                    f"'{scope}:{self_catalog_id}'."
                )

        container_parent_attachment: dict[str, bool] = {}
        for row in extracted_item_rows:
            item_id = row["item_id"]
            derived_exists = _did_exists_with_type(client, scope, item_id, "DATASET")
            row["checks"]["derived_item_exists_as_dataset"] = derived_exists
            if not derived_exists:
                errors.append(f"rucio_item: '{scope}:{item_id}' does not exist as a derived item (dataset DID).")

            parsed, parse_error = _split_item_identifier(
                item_id,
                collection_ids=collection_ids,
                href_collection_id=row.get("href_collection_id"),
            )
            if parse_error:
                errors.append(f"item_parse:{item_id}: {parse_error}")
                continue

            container_id = parsed["container_id"]
            original_item_id = parsed["original_item_id"]
            version = parsed["version"]
            row["container_id"] = container_id
            row["original_item_id"] = original_item_id
            row["version"] = version

            href_collection_id = row.get("href_collection_id")
            if isinstance(href_collection_id, str) and href_collection_id != container_id:
                errors.append(
                    f"item_parse:{item_id}: href collection '{href_collection_id}' does not match extracted container "
                    f"'{container_id}'."
                )

            original_exists = _did_exists_with_type(client, scope, original_item_id, "DATASET")
            row["checks"]["original_item_exists_as_dataset"] = original_exists
            if not original_exists:
                errors.append(
                    f"rucio_original_item: '{scope}:{original_item_id}' does not exist as an original item (dataset DID)."
                )

            container_exists = _did_exists_with_type(client, scope, container_id, "CONTAINER")
            row["checks"]["container_exists_as_container"] = container_exists
            if not container_exists:
                errors.append(f"rucio_container: '{scope}:{container_id}' does not exist as a container DID.")

            if isinstance(parent_catalog_id, str):
                if container_id not in container_parent_attachment:
                    container_parent_attachment[container_id] = _is_child_attached(
                        client,
                        scope=scope,
                        parent_name=container_id,
                        child_name=parent_catalog_id,
                    )
                container_contains_parent = container_parent_attachment[container_id]
                row["checks"]["container_contains_parent_catalog"] = container_contains_parent
                if not container_contains_parent:
                    errors.append(
                        f"rucio_hierarchy: collection/container '{scope}:{container_id}' does not contain parent catalog "
                        f"'{scope}:{parent_catalog_id}'."
                    )

        report["relationship_checks"]["collection_contains_parent_catalog"] = container_parent_attachment

    report["parsed_item_links"] = extracted_item_rows
    report["errors"] = errors
    report["valid"] = len(errors) == 0
    report["summary"] = "Validation passed." if report["valid"] else f"{len(errors)} validation issue(s) found."

    if report["valid"]:
        LOG.result("Facet value catalog '%s' validation passed.", catalog_id)
    else:
        LOG.warning("Facet value catalog validation found %s issue(s).", len(errors))
        for issue in errors:
            LOG.warning("- %s", issue)

    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Validate a STAC facet-value catalog JSON file.")
    parser.add_argument("catalog_path", type=str, help="Path to facet-value catalog JSON.")
    parser.add_argument("schema_path", type=str, help="Path to JSON schema file.")
    parser.add_argument("--scope", default="dafab", help="Rucio scope where catalogs/items are expected.")
    parser.add_argument("--root-href", default="https://dafab.cern.ch/stac", help="Expected STAC root href.")
    args = parser.parse_args()

    result = validate_facet_value_catalog_file(
        catalog_path=args.catalog_path,
        schema_path=args.schema_path,
        scope=args.scope,
        root_href=args.root_href,
    )
    print(result)
    exit(0 if result.get("valid") else 1)
