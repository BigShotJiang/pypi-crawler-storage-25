import time
import argparse
import traceback
from typing import Sequence

from dafab_client._rucio.dafab_lib import as_pretty_json, connection_manager, validate_metadata
from dafab_client._rucio.global_utils import setup_logger
from dafab_client.helpers.metadata_management.document_api import coerce_paths
from dafab_client.helpers.runtime_paths import load_json_schema

LOG = setup_logger(__name__)


def get_bulk_metadata(
        pname: str,
        scope: str = 'dafab',
        *,
        paths: Sequence[str] | None = None,
        max_retries: int = 5,
        retry_delay: int = 30,
):
    """Retrieve all metadata stored for a Copernicus dataset.

    Parameters
    ----------
    pname : str
        Name of the dataset whose metadata should be retrieved.
    scope : str, optional
        Rucio scope that contains the dataset. Defaults to ``'dafab'``.
    max_retries : int, optional
        Number of retry attempts when the client raises an exception. Defaults to ``5``.
    retry_delay : int, optional
        Delay (in seconds) between retries. Defaults to ``30``.

    Returns
    -------
    dict | None
        The metadata dictionary if retrieval succeeds, otherwise ``None`` after
        all retry attempts have failed.
    """

    for attempt in range(max_retries):
        try:
            row = connection_manager().get_metadata_document(
                scope=scope,
                name=pname,
                paths=coerce_paths(list(paths) if paths is not None else None),
            )
            if paths:
                values = row.get("values")
                return values if isinstance(values, dict) else {}
            document = row.get("document")
            if isinstance(document, dict):
                return document
            if isinstance(row, dict):
                return row
            return None
        except Exception as e:
            LOG.warning(
                f"Attempt {attempt + 1}/{max_retries}: An unexpected error "
                f"of type '{type(e).__name__}' occurred "
                f"while getting all metadata of the dataset '{pname}': {e}\n"
            )

            # Get the full traceback for debugging:
            traceback.print_exc()

            if attempt < max_retries - 1:  # Don't sleep after the last attempt
                LOG.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)

    LOG.warning("All retry attempts for retrieving metadata have been exhausted.")
    return None


def get_metadata_for_scope_name(pname: str, scope: str = 'dafab', schema_filename: str = 'Schema_Copernicus_with_dafab.json'):
    """Retrieve and validate the metadata for ``pname``.

    The helper mirrors the behaviour of the original CLI script while also being
    importable from ``demo.py``. Metadata is fetched via :func:`get_bulk_metadata`,
    validated against the bundled schema and logged in a readable format.

    Parameters
    ----------
    pname : str
        Name of the dataset whose metadata should be retrieved.
    scope : str, optional
        Rucio scope that contains the dataset. Defaults to ``'dafab'``.
    schema_filename : str, optional
        Schema filename or explicit schema path used for validation.
        Defaults to ``'Schema_Copernicus_with_dafab.json'``.

    Returns
    -------
    dict | None
        Validated metadata dictionary or ``None`` when retrieval/validation fails.
    """

    LOG.debug(f"Validating the {pname} content..")

    try:
        metadata_schema, metadata_schema_source = load_json_schema(schema_filename)
        LOG.debug("Loaded metadata schema from %s", metadata_schema_source)
    except Exception as exc:
        LOG.error("Schema file '%s' could not be loaded: %s", schema_filename, exc)
        return None

    all_metadata = get_bulk_metadata(pname, scope=scope)
    if all_metadata is None:
        return None

    validation_success = validate_metadata(pname, all_metadata, metadata_schema_source, metadata_schema)
    if not validation_success:
        LOG.error(
            f"The metadata for product '{pname}' is not valid according to schema '{metadata_schema_source}'."
        )
        return None

    return all_metadata


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Get the unified metadata.')
    parser.add_argument('product_name', type=str,
                        help='Name of the Copernicus product (e.g., S2B_43QDB_20240408_0_L2A).')
    parser.add_argument('--scope', default='dafab',
                        help="Scope that contains the product. Defaults to 'dafab'.")
    parser.add_argument('--schema-filename', default='Schema_Copernicus_with_dafab.json',
                        help="Schema filename or explicit path used for validation.")

    args = parser.parse_args()

    metadata = get_metadata_for_scope_name(
        args.product_name,
        scope=args.scope,
        schema_filename=args.schema_filename,
    )
    if metadata is not None:
        print(as_pretty_json(metadata))

    exit(0 if metadata else 1)
