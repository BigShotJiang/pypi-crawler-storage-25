import argparse
import json as jsn
from typing import Any

from dafab_client.helpers.metadata_management.Retrieval.Complete.get_metadata_for_scope_name import get_bulk_metadata
from dafab_client.helpers.metadata_management.document_api import normalize_metadata_path
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


def _decode_json_pointer(pointer: str) -> list[str]:
    if pointer == "":
        return []
    if not pointer.startswith("/"):
        raise ValueError(f"Invalid JSON Pointer '{pointer}'.")
    return [token.replace("~1", "/").replace("~0", "~") for token in pointer.split("/")[1:]]


def _extract_by_pointer(pointer: str, metadata: Any) -> Any:
    current = metadata
    for token in _decode_json_pointer(pointer):
        if isinstance(current, dict):
            if token not in current:
                return None
            current = current[token]
            continue

        if isinstance(current, list):
            try:
                idx = int(token)
            except ValueError:
                return None
            if idx < 0 or idx >= len(current):
                return None
            current = current[idx]
            continue

        return None
    return current


def _format_value(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return jsn.dumps(value, indent=2)
    return str(value)


def extract_metadata_value(
        value_path: str,
        metadata: Any | None = None,
        *,
        pname: str | None = None,
        scope: str = 'dafab',
):
    """Extract one metadata value using a path expression.

    Path handling:
    1. ``value_path`` is normalized to JSON Pointer form.
    2. If ``metadata`` is provided, extraction runs locally.
    3. Otherwise, metadata is fetched for ``pname`` in ``scope`` and then resolved.

    Args:
        value_path: JSON Pointer (or legacy path notation) to resolve.
        metadata: Optional in-memory metadata object to read from.
        pname: Target object identifier used when ``metadata`` is not provided.
        scope: Scope used together with ``pname`` for metadata retrieval.

    Returns:
        str | None:
            Formatted extracted value, or ``None`` if resolution/fetch fails.
    """
    pointer = normalize_metadata_path(value_path)

    if metadata is None:
        if pname is None:
            LOG.error("Either 'metadata' or 'pname' must be supplied to extract a value.")
            return None

        values = get_bulk_metadata(pname, scope=scope, paths=[pointer])
        if isinstance(values, dict):
            resolved = values.get(pointer)
            if isinstance(resolved, dict) and bool(resolved.get("found")):
                value = resolved.get("value")
                return _format_value(value)

        metadata = get_bulk_metadata(pname, scope=scope)
        if metadata is None:
            LOG.error("Unable to retrieve metadata for product '%s' in scope '%s'.", pname, scope)
            return None

    extracted = _extract_by_pointer(pointer, metadata)
    if extracted is None:
        LOG.warning("Could not resolve metadata path '%s'.", value_path)
        return None

    formatted = _format_value(extracted)
    return formatted


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Retrieve a single metadata value (can be of any valid JSON type).')
    parser.add_argument('product_name', type=str,
                        help='Name of the Copernicus product (e.g., S2B_43QDB_20240408_0_L2A).')
    parser.add_argument('metadata_value_path', type=str,
                        help='Metadata path as JSON Pointer or legacy comma-separated notation.')
    parser.add_argument('--scope', default='dafab',
                        help="Scope that contains the product. Defaults to 'dafab'.")

    args = parser.parse_args()

    LOG.info("Trying to retrieve metadata value for product %s at '%s'", args.product_name, args.metadata_value_path)
    extracted_metadata_value = extract_metadata_value(args.metadata_value_path, pname=args.product_name, scope=args.scope)
    if extracted_metadata_value is not None:
        print(extracted_metadata_value)
    exit(0 if extracted_metadata_value is not None else 1)
