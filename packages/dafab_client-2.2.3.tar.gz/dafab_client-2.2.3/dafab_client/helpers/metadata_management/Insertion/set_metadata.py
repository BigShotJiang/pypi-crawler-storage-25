"""High-level helpers to modify dataset metadata."""

from pathlib import Path
from typing import Any, Optional, Union

from dafab_client.helpers.metadata_management.Operations.common import load_json_file
from dafab_client.helpers.metadata_management.Operations.delete_metadata_for_did import delete_metadata_for_did
from dafab_client.helpers.metadata_management.Operations.insert_metadata_for_did import insert_metadata_for_did
from dafab_client.helpers.metadata_management.Operations.update_metadata_for_did import update_metadata_for_did
from dafab_client.helpers.metadata_management.Operations.upsert_metadata_for_did import upsert_metadata_for_did

_MISSING = object()


def set_metadata(
        object: str,
        metadata_path: Optional[Union[str, Path]] = None,
        value_path: Optional[str] = None,
        value: Any = _MISSING,
        scope: str = "dafab",
        op: str = "upsert",
        mode: str = "atomic",
):
    """Apply metadata changes through a single high-level interface.

    Exactly one input style is accepted for non-delete operations:
    1. ``metadata_path`` for root-document operations, or
    2. ``value_path`` + ``value`` for single-path operations.

    Args:
        object: Target object identifier.
        metadata_path: JSON file path used as full-document payload.
        value_path: JSON Pointer-like path for single-path operations.
        value: Value used by single-path operations. Ignored for delete.
        scope: Scope that contains the target object.
        op: Operation name (``insert``, ``update``, ``upsert``, ``delete``).
        mode: Execution mode passed to the metadata backend.

    Returns:
        Any: Backend response from the selected operation helper.

    Raises:
        ValueError: If argument combinations are invalid for the selected operation.
    """
    op_normalized = op.strip().lower()
    if op_normalized not in {"insert", "update", "upsert", "delete"}:
        raise ValueError("Unsupported metadata operation. Use one of: insert, update, upsert, delete.")

    if op_normalized == "delete":
        if metadata_path:
            raise ValueError("'metadata_path' cannot be used with delete operations.")
        if value is not _MISSING:
            raise ValueError("Delete operations do not accept 'value'.")
        return delete_metadata_for_did(
            product_name=object,
            path=value_path or "",
            scope=scope,
            mode=mode,
        )

    if metadata_path and value_path:
        raise ValueError("Provide either 'metadata_path' or 'value_path', not both.")
    if not metadata_path and not value_path:
        raise ValueError("Either 'metadata_path' or 'value_path' must be provided.")

    if metadata_path:
        if op_normalized == "insert":
            raise ValueError("Root document insert is not supported. Use op='upsert' or op='update'.")
        metadata_value = load_json_file(metadata_path)
        if op_normalized == "update":
            return update_metadata_for_did(
                product_name=object,
                path="",
                value=metadata_value,
                scope=scope,
                mode=mode,
            )
        return upsert_metadata_for_did(
            product_name=object,
            path="",
            value=metadata_value,
            scope=scope,
            mode=mode,
        )

    if value is _MISSING:
        raise ValueError("Non-delete single-path operations require 'value'.")
    if op_normalized == "insert":
        return insert_metadata_for_did(
            product_name=object,
            path=value_path,
            value=value,
            scope=scope,
            mode=mode,
        )
    if op_normalized == "update":
        return update_metadata_for_did(
            product_name=object,
            path=value_path,
            value=value,
            scope=scope,
            mode=mode,
        )
    return upsert_metadata_for_did(
        product_name=object,
        path=value_path,
        value=value,
        scope=scope,
        mode=mode,
    )
