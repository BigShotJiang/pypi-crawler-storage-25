"""Contract-aligned sync helpers for original STAC item metadata."""

from __future__ import annotations

import argparse
from typing import Any

from dafab_client.helpers.metadata_management.document_api import build_patch_operation
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


COLLECTION_TYPE_FILTER_PAYLOAD = {
    "filter": {
        "type": "comparison",
        "comparator": "equals",
        "path": ["type"],
        "value": "Collection",
        "valueType": "string",
    }
}


def build_original_item_navigation_links(
        original_item_id: str,
        *,
        collection_id: str,
        root_href: str,
) -> list[dict[str, str]]:
    """Build the contract navigation links for one original item.

    Args:
        original_item_id: Original item identifier.
        collection_id: Collection identifier where the item is exposed.
        root_href: STAC root href used as navigation base.

    Returns:
        list[dict[str, str]]: ``root``, ``self``, and ``collection`` links.
    """
    root = root_href.rstrip("/")
    collection_href = f"{root}/collections/{collection_id}"
    return [
        {"rel": "root", "href": root},
        {"rel": "self", "href": f"{collection_href}/items/{original_item_id}"},
        {"rel": "collection", "href": collection_href},
    ]


def _extract_items_from_stac_filter_response(response: Any) -> list[dict[str, Any]]:
    if not isinstance(response, list) or not response:
        return []
    first_entry = response[0]
    if not isinstance(first_entry, dict):
        return []
    items = first_entry.get("items")
    if not isinstance(items, list):
        return []
    return [item for item in items if isinstance(item, dict)]


def _list_collection_ids_via_filter(client: Any, *, scope: str) -> list[str]:
    try:
        response = list(client.stac_filter({"scope": scope, **COLLECTION_TYPE_FILTER_PAYLOAD}))
    except Exception:
        return []
    collection_items = _extract_items_from_stac_filter_response(response)
    return sorted(
        {item_id for item in collection_items if isinstance((item_id := item.get("id")), str)},
        key=len,
        reverse=True,
    )


def _split_generated_item_identifier(
        generated_item_id: str,
        *,
        original_item_id: str,
        collection_ids: list[str],
) -> dict[str, str] | None:
    prefix = f"{original_item_id}_"
    if not generated_item_id.startswith(prefix):
        return None

    tail = generated_item_id[len(prefix):]
    if "_" not in tail:
        return None
    body, version = tail.rsplit("_", 1)
    if not version.isdigit():
        return None

    for collection_id in collection_ids:
        if body == collection_id:
            return {"collection_id": collection_id, "version": version}
    return None


def discover_generated_item_related_links(
        *,
        client: Any,
        scope: str,
        original_item_id: str,
        root_href: str,
) -> dict[str, Any]:
    """Discover generated items and build contract ``related`` hrefs.

    Args:
        client: Active client instance.
        scope: Scope containing source and generated items.
        original_item_id: Original item identifier used as prefix for generated IDs.
        root_href: STAC root href used to build related item links.

    Returns:
        dict[str, Any]: Discovery payload with generated ids, related hrefs,
        discovered collection ids, and unparsed generated ids.
    """
    root = root_href.rstrip("/")
    result: dict[str, Any] = {
        "generated_item_ids": [],
        "related_hrefs": [],
        "collection_ids": [],
        "unparsed_generated_item_ids": [],
    }

    try:
        did_rows = list(
            client.list_dids(
                scope=scope,
                filters=[{"name": f"{original_item_id}_*"}],
                did_type="dataset",
                long=True,
                recursive=False,
            )
        )
    except Exception:
        return result

    generated_item_ids = sorted(
        {
            str(row.get("name"))
            for row in did_rows
            if isinstance(row, dict) and isinstance(row.get("name"), str)
        }
    )
    result["generated_item_ids"] = generated_item_ids
    if not generated_item_ids:
        return result

    collection_ids = _list_collection_ids_via_filter(client, scope=scope)
    if not collection_ids:
        inferred_collections = sorted(
            {
                gid[len(f"{original_item_id}_"):].rsplit("_", 1)[0]
                for gid in generated_item_ids
                if gid.startswith(f"{original_item_id}_") and "_" in gid[len(f"{original_item_id}_"):]
            },
            key=len,
            reverse=True,
        )
        collection_ids = inferred_collections
    result["collection_ids"] = collection_ids

    related_hrefs: list[str] = []
    unparsed: list[str] = []
    for generated_item_id in generated_item_ids:
        split_result = _split_generated_item_identifier(
            generated_item_id,
            original_item_id=original_item_id,
            collection_ids=collection_ids,
        )
        if split_result is None:
            unparsed.append(generated_item_id)
            continue
        related_hrefs.append(
            f"{root}/collections/{split_result['collection_id']}/items/{generated_item_id}"
        )

    result["unparsed_generated_item_ids"] = unparsed
    result["related_hrefs"] = sorted(set(related_hrefs))
    return result


def _extract_document(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    document = payload.get("document")
    if isinstance(document, dict):
        return document
    return payload


def _collect_links(payload: dict[str, Any]) -> list[dict[str, Any]]:
    links = payload.get("links")
    if not isinstance(links, list):
        return []
    return [link for link in links if isinstance(link, dict)]


def _collection_item_href(
        *,
        original_item_id: str,
        collection_id: str,
        root_href: str,
) -> str:
    root = root_href.rstrip("/")
    return f"{root}/collections/{collection_id}/items/{original_item_id}"


def _has_link(links: list[dict[str, Any]], *, rel: str, href: str) -> bool:
    for link in links:
        if str(link.get("rel", "")).strip() == rel and str(link.get("href", "")).strip() == href:
            return True
    return False


def _merge_collection_item_link(
        existing_links: list[dict[str, Any]],
        *,
        item_href: str,
) -> list[dict[str, Any]]:
    merged = [
        {
            "rel": str(link.get("rel", "")).strip(),
            "href": str(link.get("href", "")).strip(),
        }
        for link in existing_links
        if str(link.get("rel", "")).strip() and str(link.get("href", "")).strip()
    ]
    if not _has_link(merged, rel="item", href=item_href):
        merged.append({"rel": "item", "href": item_href})

    deduped: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for link in merged:
        key = (link["rel"], link["href"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(link)
    return deduped


def _merge_links(
        existing_links: list[dict[str, Any]],
        *,
        navigation_links: list[dict[str, str]],
        related_hrefs: list[str] | None,
) -> list[dict[str, Any]]:
    navigation_rels = {link["rel"] for link in navigation_links}
    remove_rels = set(navigation_rels)
    if related_hrefs is not None:
        remove_rels.add("related")

    merged = [
        link
        for link in existing_links
        if str(link.get("rel", "")).strip() not in remove_rels
    ]
    merged.extend(navigation_links)
    if related_hrefs is not None:
        merged.extend({"rel": "related", "href": href} for href in related_hrefs)

    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for link in merged:
        rel = str(link.get("rel", "")).strip()
        href = str(link.get("href", "")).strip()
        if not rel or not href:
            continue
        key = (rel, href)
        if key in seen:
            continue
        seen.add(key)
        deduped.append({"rel": rel, "href": href})
    return deduped


def _log_sync_details(result: dict[str, Any]) -> None:
    LOG.info(
        "Original-item sync details: item=%s scope=%s collection=%s updated=%s paths=%s",
        result.get("item"),
        result.get("scope"),
        result.get("collection"),
        result.get("updated"),
        result.get("updated_paths"),
    )
    if result.get("include_related_links"):
        LOG.info(
            "Related-link sync: count=%s generated=%s unparsed=%s",
            len(result.get("related_links", [])),
            len(result.get("generated_item_ids", [])),
            len(result.get("unparsed_generated_item_ids", [])),
        )
    if result.get("ensure_collection_item_link"):
        LOG.info(
            "Collection backlink sync: present_before=%s updated=%s href=%s",
            result.get("collection_item_link_present_before"),
            result.get("collection_item_link_updated"),
            result.get("collection_item_link_href"),
        )
    if result.get("error"):
        LOG.info("Original-item sync error: %s", result.get("error"))
    if result.get("collection_item_link_error"):
        LOG.info("Collection backlink sync error: %s", result.get("collection_item_link_error"))


def _compact_sync_result(result: dict[str, Any]) -> dict[str, Any]:
    compact = {
        "updated": bool(result.get("updated")),
        "item_id": result.get("item"),
        "scope": result.get("scope"),
        "collection_id": result.get("collection"),
        "stac_version": result.get("stac_version"),
        "updated_paths": result.get("updated_paths", ["/stac_version", "/collection", "/links"]),
        "related_sync_enabled": bool(result.get("include_related_links")),
        "related_link_count": len(result.get("related_links", [])),
        "generated_item_count": len(result.get("generated_item_ids", [])),
        "unparsed_generated_item_count": len(result.get("unparsed_generated_item_ids", [])),
        "collection_backlink_enforced": bool(result.get("ensure_collection_item_link")),
        "collection_item_link_present_before": result.get("collection_item_link_present_before"),
        "collection_item_link_updated": result.get("collection_item_link_updated"),
        "collection_item_link_href": result.get("collection_item_link_href"),
    }
    if result.get("error"):
        compact["error"] = result.get("error")
    if result.get("collection_item_link_error"):
        compact["collection_item_link_error"] = result.get("collection_item_link_error")
    return compact


def sync_original_item_contract(
        original_item_id: str,
        *,
        scope: str = "dafab",
        collection_id: str = "sentinel_2_l2a",
        root_href: str = "https://dafab.cern.ch/stac",
        stac_version: str = "1.1.0",
        include_related_links: bool = False,
        ensure_collection_item_link: bool = False,
        preserve_existing_links: bool = True,
        mode: str = "atomic",
        compact_result: bool = True,
) -> dict[str, Any]:
    """Synchronize one original item with DaFab stage-1 contract fields.

    Effects:
    1. Upserts ``/stac_version``.
    2. Upserts ``/collection``.
    3. Rebuilds ``/links`` navigation entries (and optionally ``related`` links).
    4. Optionally adds the item backlink entry to the collection metadata.

    Args:
        original_item_id: Original item identifier to synchronize.
        scope: Scope containing the item and collection.
        collection_id: Collection id used for navigation links and ``/collection`` value.
        root_href: STAC root href used to build canonical navigation URLs.
        stac_version: Value written to ``/stac_version``.
        include_related_links: When ``True``, recompute ``related`` links from discovered generated items.
        ensure_collection_item_link: When ``True``, ensure collection metadata includes ``rel=item`` backlink.
        preserve_existing_links: Keep non-navigation links already present in metadata.
        mode: Metadata patch execution mode.
        compact_result: Return compact summary (``True``) or full detail payload (``False``).

    Returns:
        dict[str, Any]: Synchronization report containing update status, paths, and optional errors.
    """

    if not original_item_id or not original_item_id.strip():
        raise ValueError("'original_item_id' must be a non-empty string.")
    if not collection_id or not collection_id.strip():
        raise ValueError("'collection_id' must be a non-empty string.")

    client = connection_manager()
    navigation_links = build_original_item_navigation_links(
        original_item_id=original_item_id,
        collection_id=collection_id,
        root_href=root_href,
    )
    result: dict[str, Any] = {
        "updated": False,
        "item": original_item_id,
        "scope": scope,
        "stac_version": stac_version,
        "collection": collection_id,
        "navigation_links": navigation_links,
        "include_related_links": include_related_links,
        "ensure_collection_item_link": ensure_collection_item_link,
        "preserve_existing_links": preserve_existing_links,
        "related_links": [],
        "unparsed_generated_item_ids": [],
        "updated_paths": ["/stac_version", "/collection", "/links"],
    }

    existing_links: list[dict[str, Any]] = []
    if preserve_existing_links:
        try:
            current = client.get_metadata_document(scope=scope, name=original_item_id)
            existing_links = _collect_links(_extract_document(current))
        except Exception as exc:
            LOG.warning(
                "Could not read existing links for '%s:%s'; only contract links will be written: %s",
                scope,
                original_item_id,
                exc,
            )

    related_hrefs: list[str] | None = None
    if include_related_links:
        discovered = discover_generated_item_related_links(
            client=client,
            scope=scope,
            original_item_id=original_item_id,
            root_href=root_href,
        )
        related_hrefs = discovered["related_hrefs"]
        result["related_links"] = related_hrefs
        result["unparsed_generated_item_ids"] = discovered["unparsed_generated_item_ids"]
        result["generated_item_ids"] = discovered["generated_item_ids"]

    merged_links = _merge_links(
        existing_links if preserve_existing_links else [],
        navigation_links=navigation_links,
        related_hrefs=related_hrefs,
    )
    result["links"] = merged_links

    operations = [
        build_patch_operation(op="upsert", path="/stac_version", value=stac_version),
        build_patch_operation(op="upsert", path="/collection", value=collection_id),
        build_patch_operation(op="upsert", path="/links", value=merged_links),
    ]

    try:
        response = client.patch_metadata_document(
            scope=scope,
            name=original_item_id,
            operations=operations,
            mode=mode,
        )
        result["updated"] = True
        result["response"] = response
        LOG.result(
            "Synced original item '%s' contract fields (scope=%s, collection=%s, related=%s).",
            original_item_id,
            scope,
            collection_id,
            "on" if include_related_links else "off",
        )

        if ensure_collection_item_link:
            item_href = _collection_item_href(
                original_item_id=original_item_id,
                collection_id=collection_id,
                root_href=root_href,
            )
            result["collection_item_link_href"] = item_href
            try:
                collection_current = client.get_metadata_document(scope=scope, name=collection_id)
                collection_links = _collect_links(_extract_document(collection_current))
                result["collection_item_link_present_before"] = _has_link(
                    collection_links,
                    rel="item",
                    href=item_href,
                )
                if not result["collection_item_link_present_before"]:
                    merged_collection_links = _merge_collection_item_link(collection_links, item_href=item_href)
                    collection_response = client.patch_metadata_document(
                        scope=scope,
                        name=collection_id,
                        operations=[build_patch_operation(op="upsert", path="/links", value=merged_collection_links)],
                        mode=mode,
                    )
                    result["collection_item_link_updated"] = True
                    result["collection_response"] = collection_response
                else:
                    result["collection_item_link_updated"] = False
            except Exception as exc:
                result["collection_item_link_error"] = str(exc)
                LOG.warning(
                    "Failed to ensure collection item link for '%s:%s' -> '%s:%s': %s",
                    scope,
                    original_item_id,
                    scope,
                    collection_id,
                    exc,
                )
        if compact_result:
            _log_sync_details(result)
            return _compact_sync_result(result)
        return result
    except Exception as exc:
        result["error"] = str(exc)
        LOG.warning(
            "Failed to sync original item '%s' (scope=%s): %s",
            original_item_id,
            scope,
            exc,
        )
        if compact_result:
            _log_sync_details(result)
            return _compact_sync_result(result)
        return result


def update_original_item(
        original_item_id: str,
        *,
        scope: str = "dafab",
        collection_id: str = "sentinel_2_l2a",
        root_href: str = "https://dafab.cern.ch/stac",
        stac_version: str = "1.1.0",
        mode: str = "atomic",
        compact_result: bool = True,
) -> dict[str, Any]:
    """Backward-compatible wrapper around :func:`sync_original_item_contract`.

    Args:
        original_item_id: Original item identifier to synchronize.
        scope: Scope containing the item and collection.
        collection_id: Collection id used for navigation links and ``/collection`` value.
        root_href: STAC root href used to build canonical navigation URLs.
        stac_version: Value written to ``/stac_version``.
        mode: Metadata patch execution mode.
        compact_result: Return compact summary (``True``) or full detail payload (``False``).

    Returns:
        dict[str, Any]: Synchronization report.
    """
    return sync_original_item_contract(
        original_item_id=original_item_id,
        scope=scope,
        collection_id=collection_id,
        root_href=root_href,
        stac_version=stac_version,
        include_related_links=False,
        preserve_existing_links=True,
        mode=mode,
        compact_result=compact_result,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Sync contract metadata fields for an original STAC item.")
    parser.add_argument("original_item_id", help="Original item identifier.")
    parser.add_argument("--scope", default="dafab", help="Scope containing the original item.")
    parser.add_argument("--collection-id", default="sentinel_2_l2a", help="Target STAC collection id.")
    parser.add_argument("--root-href", default="https://dafab.cern.ch/stac", help="STAC root href.")
    parser.add_argument("--stac-version", default="1.1.0", help="STAC version value to set.")
    parser.add_argument(
        "--include-related-links",
        action="store_true",
        help="Also sync 'related' links discovered from generated item DIDs.",
    )
    parser.add_argument(
        "--replace-links-only",
        action="store_true",
        help="Do not preserve existing non-navigation links.",
    )
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic",
                        help="BulkMetaDoc execution mode.")
    args = parser.parse_args()

    output = sync_original_item_contract(
        original_item_id=args.original_item_id,
        scope=args.scope,
        collection_id=args.collection_id,
        root_href=args.root_href,
        stac_version=args.stac_version,
        include_related_links=args.include_related_links,
        preserve_existing_links=not args.replace_links_only,
        mode=args.mode,
    )
    print(output)
    exit(0 if output.get("updated") else 1)
