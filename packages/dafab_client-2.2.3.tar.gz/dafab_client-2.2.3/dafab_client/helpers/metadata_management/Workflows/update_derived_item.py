"""Contract-aligned sync helpers for derived STAC item metadata."""

from __future__ import annotations

import argparse
from typing import Any, Optional
from urllib.parse import urlparse

from dafab_client.helpers.metadata_management.document_api import build_patch_operation
from dafab_client._rucio.common.exception import DataIdentifierNotFound
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


COLLECTION_TYPE_FILTER_PAYLOAD = {
    "filter": {
        "type": "comparison",
        "comparator": "equals",
        "path": ["type"],
        "value": "Collection",
        "valueType": "string",
    }
}

PROFILE_BLOCK_BY_COLLECTION: dict[str, tuple[str, str]] = {
    "water_analysis": ("dafab:water-analysis", "water_analysis_algorithm_version"),
    "smart_agriculture": ("dafab:smart-agriculture", "smart_agriculture_algorithm_version"),
}


def _normalize_collection_id(value: str) -> str:
    return value.strip().lower().replace("-", "_")


def _extract_document(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    document = payload.get("document")
    if isinstance(document, dict):
        return document
    return payload


def _extract_items_from_stac_filter_response(response: Any) -> list[dict[str, Any]]:
    if not isinstance(response, list) or not response:
        return []
    first_entry = response[0]
    if not isinstance(first_entry, dict):
        return []
    items = first_entry.get("items")
    if not isinstance(items, list):
        return []
    return [item for item in items if isinstance(item, dict)]


def _list_collection_ids_via_filter(client: Any, *, scope: str) -> list[str]:
    try:
        response = list(client.stac_filter({"scope": scope, **COLLECTION_TYPE_FILTER_PAYLOAD}))
    except Exception:
        return []
    collection_items = _extract_items_from_stac_filter_response(response)
    return sorted(
        {
            _normalize_collection_id(item_id)
            for item in collection_items
            if isinstance((item_id := item.get("id")), str)
        },
        key=len,
        reverse=True,
    )


def _split_derived_item_identifier(
        item_id: str,
        *,
        collection_ids: list[str],
        expected_collection_id: str | None = None,
) -> tuple[Optional[dict[str, str]], Optional[str]]:
    if "_" not in item_id:
        return None, "item id has no '_' separator to extract version."

    body, version = item_id.rsplit("_", 1)
    if not version.isdigit():
        return None, f"item version suffix '{version}' is not numeric."

    preferred_collections: list[str] = []
    if isinstance(expected_collection_id, str) and expected_collection_id.strip():
        preferred_collections.append(_normalize_collection_id(expected_collection_id))
    for collection_id in sorted(collection_ids, key=len, reverse=True):
        normalized = _normalize_collection_id(collection_id)
        if normalized not in preferred_collections:
            preferred_collections.append(normalized)

    for collection_id in preferred_collections:
        marker = f"_{collection_id}"
        if not body.endswith(marker):
            continue
        original_item_id = body[:-len(marker)]
        if not original_item_id:
            return None, (
                f"item id '{item_id}' has empty original-item component before collection '{collection_id}'."
            )
        return {
            "original_item_id": original_item_id,
            "collection_id": collection_id,
            "version": version,
        }, None

    return None, (
        f"could not map item id '{item_id}' to any known collection id "
        f"(candidates: {preferred_collections if preferred_collections else '<none>'})."
    )


def _did_type(client: Any, *, scope: str, name: str) -> Optional[str]:
    try:
        did = client.get_did(scope=scope, name=name)
    except DataIdentifierNotFound:
        return None
    except Exception:
        return None
    did_type = did.get("type")
    return str(did_type).upper() if did_type is not None else None


def _ensure_object_exists(
        client: Any,
        *,
        scope: str,
        name: str,
        expected_type: str,
        allow_create: bool,
) -> tuple[bool, bool, Optional[str]]:
    current_type = _did_type(client, scope=scope, name=name)
    if current_type == expected_type:
        return True, False, None
    if current_type is None:
        if not allow_create:
            return False, False, f"missing:{scope}:{name}"
        try:
            client.add_did(scope=scope, name=name, did_type=expected_type)
        except Exception as exc:
            return False, False, f"create_failed:{scope}:{name}: {exc}"
        created_type = _did_type(client, scope=scope, name=name)
        if created_type != expected_type:
            return False, False, (
                f"create_failed:{scope}:{name}: expected {expected_type}, found {created_type or 'missing'}"
            )
        return True, True, None
    return False, False, (
        f"type_mismatch:{scope}:{name}: expected {expected_type}, found {current_type}"
    )


def _is_child_attached(client: Any, *, scope: str, parent_name: str, child_name: str) -> bool:
    try:
        content_entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception:
        return False
    for child in content_entries:
        if not isinstance(child, dict):
            continue
        child_scope = child.get("scope")
        child_scope_text = str(child_scope) if child_scope is not None else scope
        if child_scope_text == scope and child.get("name") == child_name:
            return True
    return False


def _ensure_attachment(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        child_name: str,
) -> tuple[bool, bool, Optional[str]]:
    if _is_child_attached(client, scope=scope, parent_name=parent_name, child_name=child_name):
        return True, False, None
    try:
        client.attach_dids(
            scope=scope,
            name=parent_name,
            dids=[{"scope": scope, "name": child_name}],
        )
    except Exception as exc:
        return False, False, str(exc)
    attached_now = _is_child_attached(client, scope=scope, parent_name=parent_name, child_name=child_name)
    if not attached_now:
        return False, False, "attach_call_succeeded_but_member_not_present"
    return True, True, None


def _detach_attachment(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        child_name: str,
) -> tuple[bool, bool, Optional[str]]:
    if not _is_child_attached(client, scope=scope, parent_name=parent_name, child_name=child_name):
        return True, False, None
    try:
        client.detach_dids(
            scope=scope,
            name=parent_name,
            dids=[{"scope": scope, "name": child_name}],
        )
    except Exception as exc:
        return False, False, str(exc)
    still_attached = _is_child_attached(client, scope=scope, parent_name=parent_name, child_name=child_name)
    if still_attached:
        return False, False, "detach_call_succeeded_but_member_still_present"
    return True, True, None


def _list_child_names_by_type(client: Any, *, scope: str, parent_name: str, expected_type: str) -> list[str]:
    try:
        entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception:
        return []

    names: set[str] = set()
    expected = expected_type.upper()
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name")
        if not isinstance(name, str) or not name.strip():
            continue
        entry_scope = entry.get("scope")
        entry_scope_text = str(entry_scope) if entry_scope is not None else scope
        if entry_scope_text != scope:
            continue
        entry_type = entry.get("type")
        resolved_type = str(entry_type).upper() if entry_type is not None else _did_type(client, scope=scope, name=name)
        if resolved_type == expected:
            names.add(name)
    return sorted(names)


def _list_container_children(client: Any, *, scope: str, parent_name: str) -> list[str]:
    return _list_child_names_by_type(
        client,
        scope=scope,
        parent_name=parent_name,
        expected_type="CONTAINER",
    )


def _list_facet_value_catalog_ids(client: Any, *, scope: str, collection_id: str) -> list[str]:
    facet_value_ids: set[str] = set()
    facet_parent_ids = _list_container_children(client, scope=scope, parent_name=collection_id)
    for facet_parent_id in facet_parent_ids:
        facet_value_ids.update(_list_container_children(client, scope=scope, parent_name=facet_parent_id))
    return sorted(facet_value_ids)


def _remove_link(
        existing_links: list[dict[str, Any]],
        *,
        rel: str,
        href: str,
) -> list[dict[str, str]]:
    pruned = [
        {
            "rel": str(link.get("rel", "")).strip(),
            "href": str(link.get("href", "")).strip(),
        }
        for link in existing_links
        if str(link.get("rel", "")).strip()
        and str(link.get("href", "")).strip()
        and not (str(link.get("rel", "")).strip() == rel and str(link.get("href", "")).strip() == href)
    ]
    deduped: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for link in pruned:
        key = (link["rel"], link["href"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(link)
    return deduped


def _collect_links(payload: dict[str, Any]) -> list[dict[str, Any]]:
    links = payload.get("links")
    if not isinstance(links, list):
        return []
    return [link for link in links if isinstance(link, dict)]


def _has_link(links: list[dict[str, Any]], *, rel: str, href: str) -> bool:
    for link in links:
        if str(link.get("rel", "")).strip() == rel and str(link.get("href", "")).strip() == href:
            return True
    return False


def _merge_navigation_links(
        existing_links: list[dict[str, Any]],
        *,
        navigation_links: list[dict[str, str]],
) -> list[dict[str, str]]:
    remove_rels = {"root", "self", "collection", "derived_from"}
    merged = [
        {
            "rel": str(link.get("rel", "")).strip(),
            "href": str(link.get("href", "")).strip(),
        }
        for link in existing_links
        if str(link.get("rel", "")).strip() not in remove_rels
        and str(link.get("rel", "")).strip()
        and str(link.get("href", "")).strip()
    ]
    merged.extend(navigation_links)

    deduped: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for link in merged:
        key = (link["rel"], link["href"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(link)
    return deduped


def _merge_single_link(
        existing_links: list[dict[str, Any]],
        *,
        rel: str,
        href: str,
) -> list[dict[str, str]]:
    merged = [
        {
            "rel": str(link.get("rel", "")).strip(),
            "href": str(link.get("href", "")).strip(),
        }
        for link in existing_links
        if str(link.get("rel", "")).strip() and str(link.get("href", "")).strip()
    ]
    if not _has_link(merged, rel=rel, href=href):
        merged.append({"rel": rel, "href": href})

    deduped: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for link in merged:
        key = (link["rel"], link["href"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(link)
    return deduped


def _iter_xy_pairs(node: Any) -> list[tuple[float, float]]:
    pairs: list[tuple[float, float]] = []
    if isinstance(node, list):
        if len(node) >= 2 and isinstance(node[0], (int, float)) and isinstance(node[1], (int, float)):
            pairs.append((float(node[0]), float(node[1])))
            return pairs
        for child in node:
            pairs.extend(_iter_xy_pairs(child))
    return pairs


def _bbox_from_geometry(geometry: Any) -> tuple[Optional[list[float]], Optional[str]]:
    if not isinstance(geometry, dict):
        return None, "geometry_missing_or_invalid"
    coordinates = geometry.get("coordinates")
    pairs = _iter_xy_pairs(coordinates)
    if not pairs:
        return None, "geometry_coordinates_missing_or_invalid"
    xs = [pair[0] for pair in pairs]
    ys = [pair[1] for pair in pairs]
    return [min(xs), min(ys), max(xs), max(ys)], None


def _collection_id_from_href(href: str) -> Optional[str]:
    parsed = urlparse(href)
    tokens = [token for token in parsed.path.strip("/").split("/") if token]
    for index, token in enumerate(tokens):
        if token == "collections" and index + 1 < len(tokens):
            return _normalize_collection_id(tokens[index + 1])
    return None


def _last_path_segment(href: str) -> str:
    parsed = urlparse(href)
    segment = parsed.path.rstrip("/").split("/")[-1]
    return segment[:-5] if segment.endswith(".json") else segment


def _container_parent_name_from_metadata(
        client: Any,
        *,
        scope: str,
        catalog_id: str,
) -> tuple[Optional[str], Optional[str]]:
    try:
        catalog_doc = _extract_document(client.get_metadata_document(scope=scope, name=catalog_id))
    except Exception as exc:
        return None, f"metadata_read_failed:{scope}:{catalog_id}:{exc}"
    links = catalog_doc.get("links")
    if not isinstance(links, list):
        return None, f"metadata_links_missing:{scope}:{catalog_id}"

    parent_hrefs = [
        str(link.get("href", "")).strip()
        for link in links
        if isinstance(link, dict)
        and str(link.get("rel", "")).strip() == "parent"
        and str(link.get("href", "")).strip()
    ]
    if len(parent_hrefs) != 1:
        return None, f"expected_single_parent_link:{scope}:{catalog_id}:found_{len(parent_hrefs)}"
    parent_name = _last_path_segment(parent_hrefs[0]).strip()
    if not parent_name:
        return None, f"invalid_parent_href:{scope}:{catalog_id}:{parent_hrefs[0]}"
    return parent_name, None


def _container_parent_names_for_did(
        client: Any,
        *,
        scope: str,
        name: str,
) -> tuple[list[str], Optional[str]]:
    try:
        parent_entries = list(client.list_parent_dids(scope=scope, name=name))
    except Exception as exc:
        return [], str(exc)

    parent_names: set[str] = set()
    for entry in parent_entries:
        if not isinstance(entry, dict):
            continue
        parent_name = entry.get("name")
        if not isinstance(parent_name, str) or not parent_name.strip():
            continue
        entry_scope = entry.get("scope")
        entry_scope_text = str(entry_scope) if entry_scope is not None else scope
        if entry_scope_text != scope:
            continue
        entry_type = entry.get("type")
        resolved_type = str(entry_type).upper() if entry_type is not None else _did_type(
            client,
            scope=scope,
            name=parent_name,
        )
        if resolved_type == "CONTAINER":
            parent_names.add(parent_name)
    return sorted(parent_names), None


def _ensure_catalog_lineage_to_collection(
        client: Any,
        *,
        scope: str,
        collection_id: str,
        catalog_id: str,
        max_hops: int = 8,
) -> tuple[int, list[str]]:
    if catalog_id == collection_id:
        return 0, []

    repaired_links = 0
    errors: list[str] = []
    child_name = catalog_id
    visited: set[str] = {child_name}

    for _ in range(max_hops):
        parent_name, parent_error = _container_parent_name_from_metadata(
            client,
            scope=scope,
            catalog_id=child_name,
        )
        if parent_error:
            errors.append(parent_error)
            return repaired_links, errors

        if parent_name is None:
            errors.append(f"lineage_parent_missing:{scope}:{child_name}")
            return repaired_links, errors

        attach_ok, attached_now, attach_error = _ensure_attachment(
            client,
            scope=scope,
            parent_name=parent_name,
            child_name=child_name,
        )
        if attach_error:
            errors.append(f"lineage_attach_failed:{scope}:{parent_name}->{child_name}:{attach_error}")
        elif attach_ok and attached_now:
            repaired_links += 1

        if parent_name == collection_id:
            return repaired_links, errors

        if parent_name in visited:
            errors.append(f"lineage_cycle_detected:{scope}:{parent_name}")
            return repaired_links, errors
        visited.add(parent_name)
        child_name = parent_name

    errors.append(
        f"lineage_depth_exceeded:{scope}:{catalog_id}:collection:{collection_id}:max_hops:{max_hops}"
    )
    return repaired_links, errors


def _repair_item_facet_catalog_hierarchy(
        client: Any,
        *,
        scope: str,
        collection_id: str,
        item_id: str,
) -> tuple[int, list[str], list[str]]:
    candidate_catalogs, parent_error = _container_parent_names_for_did(
        client,
        scope=scope,
        name=item_id,
    )
    if parent_error:
        return 0, [], [f"item_parent_listing_failed:{scope}:{item_id}:{parent_error}"]

    repaired = 0
    errors: list[str] = []
    used_candidates: list[str] = []
    for catalog_id in candidate_catalogs:
        if catalog_id == collection_id:
            continue
        used_candidates.append(catalog_id)
        repaired_count, lineage_errors = _ensure_catalog_lineage_to_collection(
            client,
            scope=scope,
            collection_id=collection_id,
            catalog_id=catalog_id,
        )
        repaired += repaired_count
        errors.extend(lineage_errors)
    return repaired, sorted(set(used_candidates)), sorted(set(errors))


def _normalize_properties_for_profile(
        *,
        properties: Any,
        collection_id: str,
        parsed_version: str,
) -> tuple[Optional[dict[str, Any]], Optional[str]]:
    profile_mapping = PROFILE_BLOCK_BY_COLLECTION.get(collection_id)
    if profile_mapping is None:
        return None, f"unsupported_profile_collection:{collection_id}"

    normalized_properties = dict(properties) if isinstance(properties, dict) else {}
    profile_key, version_key = profile_mapping
    profile_payload = normalized_properties.get(profile_key)
    profile_dict = dict(profile_payload) if isinstance(profile_payload, dict) else {}
    profile_dict[version_key] = int(parsed_version)
    normalized_properties[profile_key] = profile_dict
    return normalized_properties, None


def _compact_sync_result(result: dict[str, Any]) -> dict[str, Any]:
    errors = result.get("errors", []) if isinstance(result.get("errors"), list) else []
    compact = {
        "updated": bool(result.get("updated")),
        "scope": result.get("scope"),
        "item_id": result.get("item_id"),
        "collection_id": result.get("collection_id"),
        "original_item_id": result.get("original_item_id"),
        "version": result.get("version"),
        "metadata_updated": bool(result.get("metadata_updated")),
        "collection_item_detached": bool(result.get("collection_item_detached")),
        "original_collection_contains_item_updated": bool(result.get("original_collection_contains_item_updated")),
        "collection_item_link_removed": bool(result.get("collection_item_link_removed")),
        "facet_value_item_link_updates": int(result.get("facet_value_item_link_updates") or 0),
        "facet_hierarchy_attachment_repairs": int(result.get("facet_hierarchy_attachment_repairs") or 0),
        "facet_value_catalog_count": len(result.get("facet_value_catalog_ids", [])),
        "original_related_link_updated": bool(result.get("original_related_link_updated")),
        "created_objects": result.get("created_objects", {}),
        "error_count": len(errors),
        "errors": errors[:10],
    }
    if len(errors) > 10:
        compact["errors_truncated"] = True
    return compact


def sync_derived_item_contract(
        derived_item_id: str,
        *,
        scope: str = "dafab",
        expected_collection_id: str | None = None,
        original_collection_id: str = "sentinel_2_l2a",
        root_href: str = "https://dafab.cern.ch/stac",
        stac_version: str = "1.1.0",
        mode: str = "atomic",
        preserve_existing_links: bool = True,
        ensure_original_attachment: bool = True,
        ensure_facet_value_item_links: bool = True,
        ensure_original_related_link: bool = True,
        fix_profile: bool = True,
        fix_bbox_from_geometry: bool = True,
        allow_create_missing_objects: bool = False,
        client: Any | None = None,
        compact_result: bool = True,
) -> dict[str, Any]:
    """Synchronize one derived item with DaFab contract metadata and relationships.

    Args:
        derived_item_id: Derived item identifier to synchronize.
        scope: Scope containing all related objects.
        expected_collection_id: Optional expected collection id for strict consistency.
        original_collection_id: Collection id containing original source items.
        root_href: STAC root href used to build navigation links.
        stac_version: Value written to ``/stac_version``.
        mode: Metadata patch execution mode.
        preserve_existing_links: Keep non-navigation links already present in metadata.
        ensure_original_attachment: Ensure the original item is attached to the original collection.
        ensure_facet_value_item_links: Ensure matching facet value catalogs include ``rel=item`` backlink.
        ensure_original_related_link: Ensure original item metadata includes ``rel=related`` backlink.
        fix_profile: Normalize profile block and algorithm version under ``/properties``.
        fix_bbox_from_geometry: Recompute and update ``/bbox`` from geometry coordinates.
        allow_create_missing_objects: Create missing objects before applying relationship fixes.
        client: Optional existing client instance (used internally by validators).
        compact_result: Return compact summary (``True``) or full detail payload (``False``).

    Returns:
        dict[str, Any]: Synchronization report with update actions and errors.
    """
    if not isinstance(derived_item_id, str) or not derived_item_id.strip():
        raise ValueError("'derived_item_id' must be a non-empty string.")

    item_id = derived_item_id.strip()
    client = client if client is not None else connection_manager()
    root = root_href.rstrip("/")
    normalized_original_collection = _normalize_collection_id(original_collection_id)

    result: dict[str, Any] = {
        "updated": False,
        "scope": scope,
        "item_id": item_id,
        "collection_id": None,
        "original_item_id": None,
        "version": None,
        "metadata_updated": False,
        "collection_item_detached": False,
        "original_collection_contains_item_updated": False,
        "collection_item_link_removed": False,
        "facet_value_item_link_updates": 0,
        "facet_hierarchy_attachment_repairs": 0,
        "facet_hierarchy_candidate_catalog_ids": [],
        "facet_value_catalog_ids": [],
        "original_related_link_updated": False,
        "created_objects": {
            "item": False,
            "collection": False,
            "original_item": False,
            "original_collection": False,
        },
        "errors": [],
    }
    errors: list[str] = []

    collection_ids = _list_collection_ids_via_filter(client, scope=scope)
    if isinstance(expected_collection_id, str) and expected_collection_id.strip():
        collection_ids.append(_normalize_collection_id(expected_collection_id))
    collection_ids = sorted(set(collection_ids), key=len, reverse=True)

    parsed_id, parse_error = _split_derived_item_identifier(
        item_id,
        collection_ids=collection_ids,
        expected_collection_id=expected_collection_id,
    )
    if parse_error or parsed_id is None:
        errors.append(f"id_parse: {parse_error}")
        result["errors"] = errors
        return _compact_sync_result(result) if compact_result else result

    collection_id = parsed_id["collection_id"]
    original_item_id = parsed_id["original_item_id"]
    parsed_version = parsed_id["version"]
    result["collection_id"] = collection_id
    result["original_item_id"] = original_item_id
    result["version"] = parsed_version

    if expected_collection_id and _normalize_collection_id(expected_collection_id) != collection_id:
        errors.append(
            f"collection_mismatch: parsed collection '{collection_id}' does not match expected '{expected_collection_id}'."
        )
        result["errors"] = errors
        return _compact_sync_result(result) if compact_result else result

    item_exists, item_created, item_error = _ensure_object_exists(
        client,
        scope=scope,
        name=item_id,
        expected_type="DATASET",
        allow_create=allow_create_missing_objects,
    )
    result["created_objects"]["item"] = item_created
    if item_error:
        errors.append(f"item_object: {item_error}")
    if not item_exists:
        result["errors"] = errors
        return _compact_sync_result(result) if compact_result else result

    collection_exists, collection_created, collection_error = _ensure_object_exists(
        client,
        scope=scope,
        name=collection_id,
        expected_type="CONTAINER",
        allow_create=allow_create_missing_objects,
    )
    result["created_objects"]["collection"] = collection_created
    if collection_error:
        errors.append(f"collection_object: {collection_error}")

    original_item_exists, original_item_created, original_item_error = _ensure_object_exists(
        client,
        scope=scope,
        name=original_item_id,
        expected_type="DATASET",
        allow_create=allow_create_missing_objects,
    )
    result["created_objects"]["original_item"] = original_item_created
    if original_item_error:
        errors.append(f"original_item_object: {original_item_error}")

    original_collection_exists, original_collection_created, original_collection_error = _ensure_object_exists(
        client,
        scope=scope,
        name=normalized_original_collection,
        expected_type="CONTAINER",
        allow_create=allow_create_missing_objects,
    )
    result["created_objects"]["original_collection"] = original_collection_created
    if original_collection_error:
        errors.append(f"original_collection_object: {original_collection_error}")

    try:
        item_document = _extract_document(client.get_metadata_document(scope=scope, name=item_id))
    except Exception as exc:
        item_document = {}
        errors.append(f"item_metadata_read: {exc}")

    existing_links = _collect_links(item_document) if preserve_existing_links else []
    self_href = f"{root}/collections/{collection_id}/items/{item_id}"
    collection_href = f"{root}/collections/{collection_id}"
    derived_from_href = f"{root}/collections/{normalized_original_collection}/items/{original_item_id}"
    navigation_links = [
        {"rel": "root", "href": root},
        {"rel": "self", "href": self_href},
        {"rel": "collection", "href": collection_href},
        {"rel": "derived_from", "href": derived_from_href},
    ]
    merged_links = _merge_navigation_links(existing_links, navigation_links=navigation_links)

    patch_operations: list[dict[str, Any]] = [
        build_patch_operation(op="upsert", path="/stac_version", value=stac_version),
        build_patch_operation(op="upsert", path="/collection", value=collection_id),
        build_patch_operation(op="upsert", path="/links", value=merged_links),
    ]

    if fix_profile:
        normalized_properties, profile_error = _normalize_properties_for_profile(
            properties=item_document.get("properties"),
            collection_id=collection_id,
            parsed_version=parsed_version,
        )
        if profile_error:
            errors.append(f"profile_fix: {profile_error}")
        elif normalized_properties is not None:
            patch_operations.append(build_patch_operation(op="upsert", path="/properties", value=normalized_properties))

    if fix_bbox_from_geometry:
        computed_bbox, bbox_error = _bbox_from_geometry(item_document.get("geometry"))
        if computed_bbox is not None:
            patch_operations.append(build_patch_operation(op="upsert", path="/bbox", value=computed_bbox))
        elif bbox_error:
            errors.append(f"bbox_fix: {bbox_error}")

    try:
        item_patch_response = client.patch_metadata_document(
            scope=scope,
            name=item_id,
            operations=patch_operations,
            mode=mode,
        )
        result["metadata_updated"] = True
        result["item_patch_response"] = item_patch_response
    except Exception as exc:
        errors.append(f"item_metadata_patch: {exc}")

    if ensure_original_attachment and original_collection_exists and original_item_exists:
        attached_ok, attached_now, attach_error = _ensure_attachment(
            client,
            scope=scope,
            parent_name=normalized_original_collection,
            child_name=original_item_id,
        )
        if attach_error:
            errors.append(f"original_collection_attachment: {attach_error}")
        if attached_ok and attached_now:
            result["original_collection_contains_item_updated"] = True

    if collection_exists:
        detached_ok, detached_now, detach_error = _detach_attachment(
            client,
            scope=scope,
            parent_name=collection_id,
            child_name=item_id,
        )
        if detach_error:
            errors.append(f"collection_direct_attachment_cleanup: {detach_error}")
        if detached_ok and detached_now:
            result["collection_item_detached"] = True

        try:
            collection_doc = _extract_document(client.get_metadata_document(scope=scope, name=collection_id))
            collection_links = _collect_links(collection_doc)
            if _has_link(collection_links, rel="item", href=self_href):
                pruned_collection_links = _remove_link(collection_links, rel="item", href=self_href)
                client.patch_metadata_document(
                    scope=scope,
                    name=collection_id,
                    operations=[build_patch_operation(op="upsert", path="/links", value=pruned_collection_links)],
                    mode=mode,
                )
                result["collection_item_link_removed"] = True
        except Exception as exc:
            errors.append(f"collection_link_cleanup: {exc}")

    if ensure_facet_value_item_links and collection_exists:
        repaired_links, hierarchy_candidates, hierarchy_errors = _repair_item_facet_catalog_hierarchy(
            client,
            scope=scope,
            collection_id=collection_id,
            item_id=item_id,
        )
        result["facet_hierarchy_attachment_repairs"] = repaired_links
        result["facet_hierarchy_candidate_catalog_ids"] = hierarchy_candidates
        errors.extend([f"facet_hierarchy_attachment:{error}" for error in hierarchy_errors])

        facet_value_catalog_ids = _list_facet_value_catalog_ids(client, scope=scope, collection_id=collection_id)
        result["facet_value_catalog_ids"] = facet_value_catalog_ids
        matching_catalogs: list[str] = []
        for facet_value_catalog_id in facet_value_catalog_ids:
            if _is_child_attached(
                    client,
                    scope=scope,
                    parent_name=facet_value_catalog_id,
                    child_name=item_id,
            ):
                matching_catalogs.append(facet_value_catalog_id)
        if not matching_catalogs:
            errors.append(
                f"facet_value_attachment: item '{scope}:{item_id}' is not attached to any facet value catalog "
                f"under collection '{scope}:{collection_id}'."
            )
        for facet_value_catalog_id in matching_catalogs:
            try:
                facet_value_doc = _extract_document(client.get_metadata_document(scope=scope, name=facet_value_catalog_id))
                facet_value_links = _collect_links(facet_value_doc)
                if _has_link(facet_value_links, rel="item", href=self_href):
                    continue
                merged_facet_links = _merge_single_link(facet_value_links, rel="item", href=self_href)
                client.patch_metadata_document(
                    scope=scope,
                    name=facet_value_catalog_id,
                    operations=[build_patch_operation(op="upsert", path="/links", value=merged_facet_links)],
                    mode=mode,
                )
                result["facet_value_item_link_updates"] += 1
            except Exception as exc:
                errors.append(f"facet_value_item_link:{facet_value_catalog_id}: {exc}")

    if ensure_original_related_link and original_item_exists:
        try:
            original_doc = _extract_document(client.get_metadata_document(scope=scope, name=original_item_id))
            original_links = _collect_links(original_doc)
            merged_original_links = _merge_single_link(original_links, rel="related", href=self_href)
            if not _has_link(original_links, rel="related", href=self_href):
                client.patch_metadata_document(
                    scope=scope,
                    name=original_item_id,
                    operations=[build_patch_operation(op="upsert", path="/links", value=merged_original_links)],
                    mode=mode,
                )
                result["original_related_link_updated"] = True
        except Exception as exc:
            errors.append(f"original_backlink: {exc}")

    result["errors"] = errors
    result["updated"] = any(
        [
            result["metadata_updated"],
            result["collection_item_detached"],
            result["original_collection_contains_item_updated"],
            result["collection_item_link_removed"],
            result["facet_hierarchy_attachment_repairs"] > 0,
            result["facet_value_item_link_updates"] > 0,
            result["original_related_link_updated"],
            any(result["created_objects"].values()),
        ]
    )

    if errors:
        LOG.warning(
            "Derived-item sync completed with %s issue(s) for '%s'.",
            len(errors),
            item_id,
        )
    else:
        LOG.result("Derived-item sync completed for '%s'.", item_id)

    return _compact_sync_result(result) if compact_result else result


def update_derived_item(
        derived_item_id: str,
        *,
        scope: str = "dafab",
        expected_collection_id: str | None = None,
        original_collection_id: str = "sentinel_2_l2a",
        root_href: str = "https://dafab.cern.ch/stac",
        stac_version: str = "1.1.0",
        mode: str = "atomic",
        compact_result: bool = True,
) -> dict[str, Any]:
    """Backward-compatible wrapper around :func:`sync_derived_item_contract`.

    Args:
        derived_item_id: Derived item identifier to synchronize.
        scope: Scope containing all related objects.
        expected_collection_id: Optional expected collection id for strict consistency.
        original_collection_id: Collection id containing original source items.
        root_href: STAC root href used to build navigation links.
        stac_version: Value written to ``/stac_version``.
        mode: Metadata patch execution mode.
        compact_result: Return compact summary (``True``) or full detail payload (``False``).

    Returns:
        dict[str, Any]: Synchronization report.
    """
    return sync_derived_item_contract(
        derived_item_id=derived_item_id,
        scope=scope,
        expected_collection_id=expected_collection_id,
        original_collection_id=original_collection_id,
        root_href=root_href,
        stac_version=stac_version,
        mode=mode,
        compact_result=compact_result,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Sync contract metadata fields for a derived STAC item.")
    parser.add_argument("derived_item_id", help="Derived item identifier.")
    parser.add_argument("--scope", default="dafab", help="Scope containing related objects.")
    parser.add_argument("--expected-collection-id", default=None, help="Expected target collection id.")
    parser.add_argument("--original-collection-id", default="sentinel_2_l2a", help="Original source collection id.")
    parser.add_argument("--root-href", default="https://dafab.cern.ch/stac", help="STAC root href.")
    parser.add_argument("--stac-version", default="1.1.0", help="STAC version value to set.")
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic",
                        help="Bulk metadata patch execution mode.")
    parser.add_argument("--disable-original-attachment", action="store_true",
                        help="Do not enforce original collection attachment.")
    parser.add_argument("--disable-facet-value-item-links", action="store_true",
                        help="Do not enforce rel=item backlinks in matching facet value catalogs.")
    parser.add_argument("--disable-original-related-link", action="store_true",
                        help="Do not enforce original related backlink.")
    parser.add_argument("--disable-profile-fix", action="store_true", help="Do not normalize profile block.")
    parser.add_argument("--disable-bbox-fix", action="store_true", help="Do not recompute bbox from geometry.")
    parser.add_argument("--allow-create-missing-objects", action="store_true",
                        help="Create missing item/collection objects before syncing.")
    args = parser.parse_args()

    output = sync_derived_item_contract(
        derived_item_id=args.derived_item_id,
        scope=args.scope,
        expected_collection_id=args.expected_collection_id,
        original_collection_id=args.original_collection_id,
        root_href=args.root_href,
        stac_version=args.stac_version,
        mode=args.mode,
        ensure_original_attachment=not args.disable_original_attachment,
        ensure_facet_value_item_links=not args.disable_facet_value_item_links,
        ensure_original_related_link=not args.disable_original_related_link,
        fix_profile=not args.disable_profile_fix,
        fix_bbox_from_geometry=not args.disable_bbox_fix,
        allow_create_missing_objects=args.allow_create_missing_objects,
    )
    print(output)
    exit(0 if not output.get("errors") else 1)
