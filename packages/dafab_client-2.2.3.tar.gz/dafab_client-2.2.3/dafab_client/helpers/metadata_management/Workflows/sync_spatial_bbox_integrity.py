"""Reconcile item bbox and collection extent values from item metadata."""

from __future__ import annotations

import argparse
import copy
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Optional, Sequence
from urllib.parse import urlparse

from dafab_client._rucio.common.exception import DataIdentifierNotFound
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

from dafab_client.helpers.metadata_management.document_api import build_patch_operation

LOG = setup_logger(__name__)

SEED_ITEM_PARTIAL_PATHS: tuple[str, ...] = ("/collection", "/links")
CHILD_ITEM_PARTIAL_PATHS: tuple[str, ...] = ("/collection", "/links", "/geometry", "/properties", "/bbox")
ORIGINAL_ITEM_PARTIAL_PATHS: tuple[str, ...] = ("/collection", "/links", "/geometry", "/bbox")
DEFAULT_ORIGINAL_COLLECTION_ID = "sentinel_2_l2a"
DEFAULT_STAC_ROOT_HREF = "https://dafab.cern.ch/stac"


def _did_type_with_error(client: Any, *, scope: str, name: str) -> tuple[Optional[str], Optional[str]]:
    try:
        did = client.get_did(scope=scope, name=name)
    except DataIdentifierNotFound:
        return None, None
    except Exception as exc:
        return None, f"did_lookup_failed:{exc}"
    did_type = did.get("type")
    return (str(did_type).upper() if did_type is not None else None), None


def _did_type(client: Any, *, scope: str, name: str) -> Optional[str]:
    did_type, _ = _did_type_with_error(client, scope=scope, name=name)
    return did_type


def _is_dataset(client: Any, *, scope: str, name: str) -> bool:
    return _did_type(client, scope=scope, name=name) == "DATASET"


def _is_container(client: Any, *, scope: str, name: str) -> bool:
    return _did_type(client, scope=scope, name=name) == "CONTAINER"


def _is_child_attached_with_error(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        child_name: str,
) -> tuple[Optional[bool], Optional[str]]:
    try:
        content_entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception as exc:
        return None, f"content_read_failed:{exc}"
    for child in content_entries:
        if not isinstance(child, dict):
            continue
        child_scope = child.get("scope")
        child_scope_text = str(child_scope) if child_scope is not None else scope
        if child_scope_text == scope and child.get("name") == child_name:
            return True, None
    return False, None


def _is_child_attached(client: Any, *, scope: str, parent_name: str, child_name: str) -> bool:
    attached, _ = _is_child_attached_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        child_name=child_name,
    )
    return bool(attached)


def _list_child_names_by_type_with_error(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        expected_type: str,
) -> tuple[list[str], Optional[str]]:
    try:
        entries = list(client.list_content(scope=scope, name=parent_name))
    except Exception as exc:
        return [], f"content_read_failed:{exc}"

    expected = expected_type.upper()
    names: set[str] = set()
    lookup_errors: list[str] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name")
        if not isinstance(name, str) or not name.strip():
            continue
        child_scope = entry.get("scope")
        child_scope_text = str(child_scope) if child_scope is not None else scope
        if child_scope_text != scope:
            continue
        entry_type = entry.get("type")
        if entry_type is not None:
            resolved_type = str(entry_type).upper()
        else:
            resolved_type, resolved_error = _did_type_with_error(client, scope=scope, name=name)
            if resolved_error is not None:
                lookup_errors.append(f"{name}:{resolved_error}")
                continue
        if resolved_type == expected:
            names.add(name)
    if lookup_errors:
        unique_errors = sorted(set(lookup_errors))
        preview = ";".join(unique_errors[:3])
        suffix = f";+{len(unique_errors) - 3}_more" if len(unique_errors) > 3 else ""
        return sorted(names), f"child_type_lookup_failed:{preview}{suffix}"
    return sorted(names), None


def _list_child_names_by_type(client: Any, *, scope: str, parent_name: str, expected_type: str) -> list[str]:
    names, _ = _list_child_names_by_type_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        expected_type=expected_type,
    )
    return names


def _list_dataset_children(client: Any, *, scope: str, parent_name: str) -> list[str]:
    return _list_child_names_by_type(
        client,
        scope=scope,
        parent_name=parent_name,
        expected_type="DATASET",
    )


def _list_container_children(client: Any, *, scope: str, parent_name: str) -> list[str]:
    return _list_child_names_by_type(
        client,
        scope=scope,
        parent_name=parent_name,
        expected_type="CONTAINER",
    )


def _detach_attachment(
        client: Any,
        *,
        scope: str,
        parent_name: str,
        child_name: str,
) -> tuple[bool, Optional[str]]:
    attached_before, attached_before_error = _is_child_attached_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        child_name=child_name,
    )
    if attached_before_error is not None:
        return False, attached_before_error
    if not attached_before:
        return False, None
    try:
        client.detach_dids(
            scope=scope,
            name=parent_name,
            dids=[{"scope": scope, "name": child_name}],
        )
    except Exception as exc:
        return False, str(exc)
    attached_after, attached_after_error = _is_child_attached_with_error(
        client,
        scope=scope,
        parent_name=parent_name,
        child_name=child_name,
    )
    if attached_after_error is not None:
        return False, attached_after_error
    detached = not bool(attached_after)
    if not detached:
        return False, "detach_call_succeeded_but_member_still_present"
    return True, None


def _extract_document(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    document = payload.get("document")
    if isinstance(document, dict):
        return document
    return payload


def _decode_json_pointer(pointer: str) -> list[str]:
    if pointer == "":
        return []
    if not pointer.startswith("/"):
        return []
    return [token.replace("~1", "/").replace("~0", "~") for token in pointer.split("/")[1:]]


def _assign_pointer_value(target: dict[str, Any], *, pointer: str, value: Any) -> None:
    tokens = _decode_json_pointer(pointer)
    if not tokens:
        return
    cursor: dict[str, Any] = target
    for token in tokens[:-1]:
        child = cursor.get(token)
        if not isinstance(child, dict):
            child = {}
            cursor[token] = child
        cursor = child
    cursor[tokens[-1]] = value


def _extract_document_from_values(values: Any) -> dict[str, Any]:
    if not isinstance(values, dict):
        return {}
    document: dict[str, Any] = {}
    for pointer, resolved in values.items():
        if not isinstance(pointer, str):
            continue
        if isinstance(resolved, dict):
            if resolved.get("found") is False:
                continue
            if "value" not in resolved:
                continue
            _assign_pointer_value(document, pointer=pointer, value=resolved.get("value"))
            continue
        _assign_pointer_value(document, pointer=pointer, value=resolved)
    return document


def _extract_document_from_row(row: dict[str, Any], *, paths: Sequence[str] | None) -> tuple[dict[str, Any], Optional[str]]:
    if not isinstance(row, dict):
        return {}, "metadata_row_invalid"
    if paths is not None:
        values_doc = _extract_document_from_values(row.get("values"))
        if values_doc:
            return values_doc, None
        if "values" in row or "error" in row:
            message = row.get("error")
            if isinstance(message, str) and message.strip():
                return {}, f"metadata_read_failed: {message.strip()}"
            return {}, "metadata_document_empty"
    document = _extract_document(row)
    if document:
        return document, None
    message = row.get("error")
    if isinstance(message, str) and message.strip():
        return {}, f"metadata_read_failed: {message.strip()}"
    return {}, "metadata_document_empty"


def _load_document(
        client: Any,
        *,
        scope: str,
        name: str,
        paths: Sequence[str] | None = None,
) -> tuple[dict[str, Any], Optional[str]]:
    try:
        if paths is None:
            payload = client.get_metadata_document(scope=scope, name=name)
        else:
            try:
                payload = client.get_metadata_document(scope=scope, name=name, paths=list(paths))
            except TypeError:
                # Compatibility fallback for thin stubs that do not expose `paths`.
                payload = client.get_metadata_document(scope=scope, name=name)
    except Exception as exc:
        return {}, f"metadata_read_failed: {exc}"
    return _extract_document_from_row(payload, paths=paths)


def _load_documents_bulk(
        client: Any,
        *,
        scope: str,
        names: Sequence[str],
        paths: Sequence[str] | None = None,
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    documents_by_name: dict[str, dict[str, Any]] = {}
    errors_by_name: dict[str, str] = {}
    unique_names = sorted({name for name in names if isinstance(name, str) and name.strip()})
    if not unique_names:
        return documents_by_name, errors_by_name

    dids = [{"scope": scope, "name": name} for name in unique_names]
    rows: list[dict[str, Any]] | None = None
    if hasattr(client, "get_metadata_document_bulk"):
        try:
            rows = client.get_metadata_document_bulk(
                dids=dids,
                paths=list(paths) if paths is not None else None,
            )
        except Exception:
            rows = None

    if rows is not None:
        row_by_name: dict[str, dict[str, Any]] = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            row_name = row.get("name")
            if isinstance(row_name, str):
                row_by_name[row_name] = row

        for name in unique_names:
            row = row_by_name.get(name)
            if row is None:
                errors_by_name[name] = "metadata_document_empty"
                continue
            document, error = _extract_document_from_row(row, paths=paths)
            if error is not None:
                errors_by_name[name] = error
                continue
            documents_by_name[name] = document
        return documents_by_name, errors_by_name

    for name in unique_names:
        document, error = _load_document(
            client,
            scope=scope,
            name=name,
            paths=paths,
        )
        if error is not None:
            errors_by_name[name] = error
            continue
        documents_by_name[name] = document

    return documents_by_name, errors_by_name


def _iter_xy_pairs(node: Any) -> list[tuple[float, float]]:
    pairs: list[tuple[float, float]] = []
    if isinstance(node, list):
        if len(node) >= 2 and isinstance(node[0], (int, float)) and isinstance(node[1], (int, float)):
            pairs.append((float(node[0]), float(node[1])))
            return pairs
        for child in node:
            pairs.extend(_iter_xy_pairs(child))
    return pairs


def _bbox_from_geometry(geometry: Any) -> tuple[Optional[list[float]], Optional[str]]:
    if not isinstance(geometry, dict):
        return None, "geometry_missing_or_invalid"
    coordinates = geometry.get("coordinates")
    pairs = _iter_xy_pairs(coordinates)
    if not pairs:
        return None, "geometry_coordinates_missing_or_invalid"
    xs = [pair[0] for pair in pairs]
    ys = [pair[1] for pair in pairs]
    return [min(xs), min(ys), max(xs), max(ys)], None


def _bbox_equal(left: Any, right: Any, *, tol: float = 1e-12) -> bool:
    if not isinstance(left, list) or not isinstance(right, list) or len(left) != len(right):
        return False
    for lval, rval in zip(left, right):
        if not isinstance(lval, (int, float)) or not isinstance(rval, (int, float)):
            return False
        if abs(float(lval) - float(rval)) > tol:
            return False
    return True


def _bbox_to_2d(bbox: Any) -> Optional[list[float]]:
    if not isinstance(bbox, list):
        return None
    if len(bbox) == 4 and all(isinstance(v, (int, float)) for v in bbox):
        return [float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3])]
    if len(bbox) == 6 and all(isinstance(v, (int, float)) for v in bbox):
        # STAC 3D ordering: [minx, miny, minz, maxx, maxy, maxz] -> project to 2D.
        return [float(bbox[0]), float(bbox[1]), float(bbox[3]), float(bbox[4])]
    return None


def _parse_utc_datetime(value: Any) -> Optional[datetime]:
    if not isinstance(value, str) or not value.strip():
        return None
    rendered = value.strip()
    if rendered.endswith("Z"):
        rendered = rendered[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(rendered)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _format_utc_datetime(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _temporal_bounds_from_properties(properties: Any) -> tuple[Optional[tuple[datetime, datetime]], Optional[str]]:
    if not isinstance(properties, dict):
        return None, "properties_missing_or_invalid"

    datetime_value = properties.get("datetime")
    if datetime_value is not None:
        point = _parse_utc_datetime(datetime_value)
        if point is None:
            return None, "datetime_missing_or_invalid"
        return (point, point), None

    start_value = properties.get("start_datetime")
    end_value = properties.get("end_datetime")
    if start_value is None and end_value is None:
        return None, "temporal_fields_missing_or_invalid"
    if start_value is None or end_value is None:
        return None, "temporal_interval_missing_boundary"

    start_point = _parse_utc_datetime(start_value)
    end_point = _parse_utc_datetime(end_value)
    if start_point is None or end_point is None:
        return None, "temporal_interval_invalid"
    if end_point < start_point:
        return None, "temporal_interval_reversed"
    return (start_point, end_point), None


def _temporal_interval_from_bounds(bounds: tuple[datetime, datetime]) -> list[str]:
    return [_format_utc_datetime(bounds[0]), _format_utc_datetime(bounds[1])]


def _extract_collection_temporal_interval(collection_doc: dict[str, Any]) -> Optional[list[Optional[str]]]:
    extent = collection_doc.get("extent")
    if not isinstance(extent, dict):
        return None
    temporal = extent.get("temporal")
    if not isinstance(temporal, dict):
        return None
    interval_value = temporal.get("interval")
    if not isinstance(interval_value, list) or not interval_value:
        return None
    first_interval = interval_value[0]
    if not isinstance(first_interval, list) or len(first_interval) < 2:
        return None
    start_value = first_interval[0]
    end_value = first_interval[1]
    if start_value is not None and not isinstance(start_value, str):
        return None
    if end_value is not None and not isinstance(end_value, str):
        return None
    return [start_value, end_value]


def _temporal_interval_equal(left: Any, right: Any) -> bool:
    if not isinstance(left, list) or not isinstance(right, list) or len(left) != 2 or len(right) != 2:
        return False
    left_start = _parse_utc_datetime(left[0])
    left_end = _parse_utc_datetime(left[1])
    right_start = _parse_utc_datetime(right[0])
    right_end = _parse_utc_datetime(right[1])
    if left_start is None or left_end is None or right_start is None or right_end is None:
        return False
    return left_start == right_start and left_end == right_end


def _union_temporal_bounds(bounds: list[tuple[datetime, datetime]]) -> tuple[datetime, datetime]:
    return min(bound[0] for bound in bounds), max(bound[1] for bound in bounds)


def _canonical_collection_href(*, root_href: str, collection_id: str) -> str:
    return f"{root_href.rstrip('/')}/collections/{collection_id}"


def _collection_link_matches(
        links: Any,
        *,
        collection_id: str,
        root_href: str = DEFAULT_STAC_ROOT_HREF,
) -> bool:
    if not isinstance(links, list):
        return False
    expected_href = _canonical_collection_href(root_href=root_href, collection_id=collection_id)
    collection_links: list[dict[str, Any]] = []
    for link in links:
        if not isinstance(link, dict):
            continue
        if str(link.get("rel", "")).strip() != "collection":
            continue
        collection_links.append(link)
    if len(collection_links) != 1:
        return False
    href = collection_links[0].get("href")
    if not isinstance(href, str) or not href.strip():
        return False
    return href.strip() == expected_href


def _item_id_from_href(href: str) -> Optional[str]:
    parsed = urlparse(href)
    segment = parsed.path.rstrip("/").split("/")[-1]
    if not segment:
        return None
    if segment.endswith(".json"):
        segment = segment[:-5]
    return segment or None


def _derived_from_original_item_id(item_doc: dict[str, Any]) -> tuple[Optional[str], Optional[str]]:
    links = item_doc.get("links")
    if not isinstance(links, list):
        return None, "derived_from_link_missing_or_invalid"

    derived_from_links = [
        link
        for link in links
        if isinstance(link, dict) and str(link.get("rel", "")).strip() == "derived_from"
    ]
    if len(derived_from_links) != 1:
        return None, "derived_from_link_missing_or_invalid"
    href = derived_from_links[0].get("href")
    if not isinstance(href, str) or not href.strip():
        return None, "derived_from_link_missing_or_invalid"
    original_item_id = _item_id_from_href(href.strip())
    if not original_item_id:
        return None, "derived_from_link_unparseable"
    return original_item_id, None


def _is_valid_bbox_2d(value: Any) -> bool:
    return _bbox_to_2d(value) is not None


def _patch_item_coordinates(
        client: Any,
        *,
        scope: str,
        name: str,
        geometry: Any,
        bbox: list[float],
        mode: str,
) -> tuple[bool, Optional[str]]:
    try:
        operations = [
            build_patch_operation(op="upsert", path="/geometry", value=geometry),
            build_patch_operation(op="upsert", path="/bbox", value=bbox),
        ]
        client.patch_metadata_document(
            scope=scope,
            name=name,
            operations=operations,
            mode=mode,
        )
        return True, None
    except Exception as exc:
        return False, str(exc)


def _extract_collection_spatial_bbox(collection_doc: dict[str, Any]) -> Optional[list[float]]:
    extent = collection_doc.get("extent")
    if not isinstance(extent, dict):
        return None
    spatial = extent.get("spatial")
    if not isinstance(spatial, dict):
        return None
    bbox_value = spatial.get("bbox")
    if not isinstance(bbox_value, list) or not bbox_value:
        return None
    first_bbox = bbox_value[0]
    if not isinstance(first_bbox, list):
        return None
    return _bbox_to_2d(first_bbox)


def _is_stac_collection_document(collection_doc: dict[str, Any]) -> bool:
    collection_type = collection_doc.get("type")
    return isinstance(collection_type, str) and collection_type.strip().lower() == "collection"


def _collection_spatial_bbox_needs_normalization(collection_doc: dict[str, Any]) -> bool:
    extent = collection_doc.get("extent")
    if not isinstance(extent, dict):
        return False
    spatial = extent.get("spatial")
    if not isinstance(spatial, dict):
        return False
    bbox_value = spatial.get("bbox")
    return isinstance(bbox_value, list) and len(bbox_value) != 1


def _collection_temporal_interval_needs_normalization(collection_doc: dict[str, Any]) -> bool:
    extent = collection_doc.get("extent")
    if not isinstance(extent, dict):
        return False
    temporal = extent.get("temporal")
    if not isinstance(temporal, dict):
        return False
    interval_value = temporal.get("interval")
    return isinstance(interval_value, list) and len(interval_value) != 1


def _patch_collection_extent(
        client: Any,
        *,
        scope: str,
        collection_id: str,
        collection_doc: dict[str, Any],
        bbox: list[float],
        temporal_interval: list[str],
        mode: str,
) -> tuple[bool, Optional[str]]:
    extent = copy.deepcopy(collection_doc.get("extent")) if isinstance(collection_doc.get("extent"), dict) else {}
    spatial = extent.get("spatial")
    if not isinstance(spatial, dict):
        spatial = {}
    spatial["bbox"] = [bbox]
    extent["spatial"] = spatial

    temporal = extent.get("temporal")
    if not isinstance(temporal, dict):
        temporal = {}
    temporal["interval"] = [temporal_interval]
    extent["temporal"] = temporal

    try:
        operations = [build_patch_operation(op="upsert", path="/extent", value=extent)]
        client.patch_metadata_document(
            scope=scope,
            name=collection_id,
            operations=operations,
            mode=mode,
        )
        return True, None
    except Exception as exc:
        return False, str(exc)


def _remove_collection_item_href_links(
        client: Any,
        *,
        scope: str,
        collection_id: str,
        item_ids: Sequence[str],
        root_href: str,
        mode: str,
        remove_all_item_links: bool = False,
        apply_changes: bool = True,
) -> tuple[int, Optional[str]]:
    if not item_ids and not remove_all_item_links:
        return 0, None
    collection_doc, collection_error = _load_document(client, scope=scope, name=collection_id)
    if collection_error is not None:
        return 0, collection_error
    links = collection_doc.get("links")
    if not isinstance(links, list):
        return 0, None

    item_hrefs = {
        f"{root_href.rstrip('/')}/collections/{collection_id}/items/{item_id}"
        for item_id in item_ids
        if isinstance(item_id, str) and item_id.strip()
    }
    if not remove_all_item_links and not item_hrefs:
        return 0, None

    removed_count = 0
    pruned_links: list[dict[str, Any]] = []
    for link in links:
        if not isinstance(link, dict):
            continue
        rel = str(link.get("rel", "")).strip()
        href = str(link.get("href", "")).strip()
        if rel == "item" and (remove_all_item_links or href in item_hrefs):
            removed_count += 1
            continue
        pruned_links.append(link)

    if removed_count == 0:
        return 0, None

    if not apply_changes:
        return removed_count, None

    try:
        client.patch_metadata_document(
            scope=scope,
            name=collection_id,
            operations=[build_patch_operation(op="upsert", path="/links", value=pruned_links)],
            mode=mode,
        )
    except Exception as exc:
        return 0, str(exc)
    return removed_count, None


def _canonical_collection_catalog_href(
        *,
        root_href: str,
        collection_id: str,
        catalog_id: str,
) -> str:
    return f"{root_href.rstrip('/')}/collections/{collection_id}/catalogs/{catalog_id}"


def _reconcile_collection_child_catalog_links(
        client: Any,
        *,
        scope: str,
        collection_id: str,
        collection_doc: dict[str, Any],
        child_catalog_ids: Sequence[str],
        root_href: str,
        mode: str,
        apply_changes: bool = True,
) -> tuple[dict[str, Any], Optional[str]]:
    expected_hrefs = sorted(
        {
            _canonical_collection_catalog_href(
                root_href=root_href,
                collection_id=collection_id,
                catalog_id=catalog_id,
            )
            for catalog_id in child_catalog_ids
            if isinstance(catalog_id, str) and catalog_id.strip()
        }
    )
    expected_href_set = set(expected_hrefs)

    links_value = collection_doc.get("links")
    existing_links = links_value if isinstance(links_value, list) else []

    non_child_links: list[dict[str, Any]] = []
    kept_child_links: dict[str, dict[str, Any]] = {}
    existing_child_entries = 0
    for link in existing_links:
        if not isinstance(link, dict):
            continue
        rel = str(link.get("rel", "")).strip()
        if rel != "child":
            non_child_links.append(link)
            continue
        existing_child_entries += 1
        href = str(link.get("href", "")).strip()
        if not href:
            continue
        if href in expected_href_set and href not in kept_child_links:
            kept_child_links[href] = link

    removed_count = existing_child_entries - len(kept_child_links)
    added_count = len(expected_href_set) - len(kept_child_links)
    updated = added_count > 0 or removed_count > 0

    result = {
        "updated": updated,
        "added": added_count,
        "removed": removed_count,
    }
    if not updated:
        return result, None

    rebuilt_links = list(non_child_links)
    for href in expected_hrefs:
        existing = kept_child_links.get(href)
        if existing is not None:
            rebuilt_links.append(existing)
        else:
            rebuilt_links.append({"rel": "child", "href": href})

    if not apply_changes:
        return result, None

    try:
        client.patch_metadata_document(
            scope=scope,
            name=collection_id,
            operations=[build_patch_operation(op="upsert", path="/links", value=rebuilt_links)],
            mode=mode,
        )
    except Exception as exc:
        return {
            "updated": False,
            "added": 0,
            "removed": 0,
        }, str(exc)
    return result, None


def _list_dataset_ids_with_error(client: Any, *, scope: str) -> tuple[list[str], Optional[str]]:
    try:
        rows = list(
            client.list_dids(
                scope=scope,
                filters=[{"name": "*"}],
                did_type="dataset",
                long=True,
                recursive=False,
            )
        )
    except Exception as exc:
        return [], f"seed_scan_failed:list_dids:{exc}"
    return sorted(
        {
            str(row.get("name"))
            for row in rows
            if isinstance(row, dict) and isinstance(row.get("name"), str)
        }
    ), None


def _list_container_ids_with_error(client: Any, *, scope: str) -> tuple[list[str], Optional[str]]:
    try:
        rows = list(
            client.list_dids(
                scope=scope,
                filters=[{"name": "*"}],
                did_type="container",
                long=True,
                recursive=False,
            )
        )
    except Exception as exc:
        return [], f"collection_discovery_failed:list_dids_container:{exc}"
    return sorted(
        {
            str(row.get("name"))
            for row in rows
            if isinstance(row, dict) and isinstance(row.get("name"), str)
        }
    ), None


def _discover_stac_collection_ids_with_error(client: Any, *, scope: str) -> tuple[list[str], list[str]]:
    container_ids, container_error = _list_container_ids_with_error(client, scope=scope)
    errors: list[str] = []
    if container_error is not None:
        errors.append(container_error)
        return [], errors

    container_docs, container_doc_errors = _load_documents_bulk(
        client,
        scope=scope,
        names=container_ids,
        paths=("/type",),
    )
    stac_collections: list[str] = []
    for container_id in container_ids:
        doc_error = container_doc_errors.get(container_id)
        if doc_error is not None:
            errors.append(f"collection_discovery_metadata_failed:{container_id}:{doc_error}")
            continue
        if _is_stac_collection_document(container_docs.get(container_id, {})):
            stac_collections.append(container_id)
    return sorted(set(stac_collections)), errors


def _list_dataset_ids(client: Any, *, scope: str) -> list[str]:
    names, _ = _list_dataset_ids_with_error(client, scope=scope)
    return names


def _union_bbox(bboxes: list[list[float]]) -> list[float]:
    return [
        min(bbox[0] for bbox in bboxes),
        min(bbox[1] for bbox in bboxes),
        max(bbox[2] for bbox in bboxes),
        max(bbox[3] for bbox in bboxes),
    ]


def _log_spatial_sync_details(report: dict[str, Any]) -> None:
    seed_issues = report.get("seed_selection_issues", [])
    if isinstance(seed_issues, list) and seed_issues:
        for issue in seed_issues:
            LOG.info("Seed selection issue: %s", issue)

    collections = report.get("collections", {})
    if isinstance(collections, dict):
        for collection_id, collection_report in collections.items():
            if not isinstance(collection_report, dict):
                continue
            included = collection_report.get("included_item_ids", [])
            excluded = collection_report.get("excluded_item_ids", [])
            LOG.info(
                "Collection extent details: collection=%s included=%s excluded=%s updated=%s error=%s",
                collection_id,
                len(included) if isinstance(included, list) else 0,
                len(excluded) if isinstance(excluded, list) else 0,
                collection_report.get("collection_bbox_updated"),
                collection_report.get("collection_bbox_update_error"),
            )
            if isinstance(excluded, list):
                for excluded_entry in excluded:
                    LOG.info("Excluded item detail (%s): %s", collection_id, excluded_entry)


def _compact_spatial_sync_report(report: dict[str, Any]) -> dict[str, Any]:
    collections_compact: dict[str, Any] = {}
    collections = report.get("collections", {})
    if isinstance(collections, dict):
        for collection_id, collection_report in collections.items():
            if not isinstance(collection_report, dict):
                continue
            included = collection_report.get("included_item_ids", [])
            excluded = collection_report.get("excluded_item_ids", [])
            collections_compact[collection_id] = {
                "computed_bbox": collection_report.get("computed_bbox"),
                "computed_temporal_interval": collection_report.get("computed_temporal_interval"),
                "collection_bbox_updated": collection_report.get("collection_bbox_updated"),
                "collection_bbox_update_error": collection_report.get("collection_bbox_update_error"),
                "collection_child_links_updated": collection_report.get("collection_child_links_updated"),
                "collection_child_links_added": collection_report.get("collection_child_links_added"),
                "collection_child_links_removed": collection_report.get("collection_child_links_removed"),
                "collection_child_links_update_error": collection_report.get("collection_child_links_update_error"),
                "included_stac_items_count": len(included) if isinstance(included, list) else 0,
                "excluded_stac_items_count": len(excluded) if isinstance(excluded, list) else 0,
                "facet_parent_catalog_count": len(collection_report.get("facet_parent_catalog_ids", [])),
                "facet_value_catalog_count": len(collection_report.get("facet_value_catalog_ids", [])),
                "direct_collection_item_attachments_removed": (
                    collection_report.get("direct_collection_item_attachments_removed")
                ),
                "direct_collection_item_links_removed": collection_report.get("direct_collection_item_links_removed"),
                "direct_collection_cleanup_error": collection_report.get("direct_collection_cleanup_error"),
            }

    seed_issues = report.get("seed_selection_issues", [])
    compact_seed_issues = seed_issues[:10] if isinstance(seed_issues, list) else []

    compact: dict[str, Any] = {
        "scope": report.get("scope"),
        "mode": report.get("mode"),
        "dry_run": report.get("dry_run"),
        "full_scan": report.get("full_scan"),
        "input_item_id": report.get("input_item_id"),
        "original_collection_id": report.get("original_collection_id"),
        "target_collection_ids": report.get("target_collection_ids"),
        "seed_selection_issue_count": len(seed_issues) if isinstance(seed_issues, list) else 0,
        "seed_selection_issues": compact_seed_issues,
        "collections": collections_compact,
        "summary": report.get("summary"),
    }
    if isinstance(seed_issues, list) and len(seed_issues) > 10:
        compact["seed_selection_issues_truncated"] = True
    return compact


def _finalize_spatial_sync_report(report: dict[str, Any], *, compact_result: bool) -> dict[str, Any]:
    if not compact_result:
        return report
    _log_spatial_sync_details(report)
    return _compact_spatial_sync_report(report)


def _sync_collection_extent_integrity(
        item_id: str | None = None,
        *,
        scope: str = "dafab",
        original_collection_id: str = DEFAULT_ORIGINAL_COLLECTION_ID,
        full_scan: bool = False,
        target_collection_kind: str = "auto",
        mode: str = "atomic",
        dry_run: bool = False,
        compact_result: bool = True,
) -> dict[str, Any]:
    """
    Reconcile collection extent from valid item metadata.

    Metadata retrieval uses partial JSON-pointer reads in bulk mode when the client
    supports it, and falls back to per-item reads otherwise.

    Spatial consistency policy:
    1. Items in ``original_collection_id`` are treated as source-truth products.
    2. Items in other collections are treated as derived products.
    3. Derived items are included only when their ``derived_from`` original exists in
       ``original_collection_id`` and original coordinates can be resolved.
    4. When derived coordinates differ from the original source item, derived metadata
       is aligned to the original ``geometry`` and ``bbox`` before aggregation.

    Eligibility rules for including an item in a collection extent:
    1. item exists in the catalog as an item object
    2. item metadata ``collection`` equals the target collection id
    3. item has exactly one canonical ``rel='collection'`` link equal to
       ``https://dafab.cern.ch/stac/collections/<collection_id>``
    4. original collection items are attached directly to the collection
    5. derived collection items are attached through facet value catalogs and
       are not directly attached under the derived collection
    6. item has spatial coordinates valid under the policy above
    7. item has valid temporal fields

    Args:
        item_id: Single seed item identifier. Required unless ``full_scan=True``.
        scope: Scope containing items and collections.
        original_collection_id: Collection id containing original source items.
        full_scan: When ``True``, process all item objects in scope and clean derived-collection
            direct item attachments/links before computing extents; also reconciles collection
            ``rel='child'`` links from live facet-parent hierarchy; ignores ``item_id``.
            When ``False``, ``item_id`` only selects the target collection(s); extent
            aggregation still uses all currently eligible items in each target collection.
            Seed link violations do not block collection selection when collection identity
            and membership can still be resolved; those violations are enforced during
            per-item eligibility checks.
        target_collection_kind: ``original`` for original-only processing, ``derived``
            for derived-only processing, ``auto`` for mixed processing.
        mode: Metadata patch execution mode used for write operations.
        dry_run: When ``True``, compute and report changes without writing metadata.
        compact_result: Return compact summary (``True``) or full detail payload (``False``).

    Returns:
        dict[str, Any]: Synchronization report with per-collection changes and summary counters.

    Raises:
        ValueError: If neither ``item_id`` nor ``full_scan=True`` is provided.
    """

    if not full_scan and (item_id is None or not item_id.strip()):
        raise ValueError("Provide 'item_id' or set 'full_scan=True'.")
    if target_collection_kind not in {"auto", "original", "derived"}:
        raise ValueError("Unsupported target collection kind. Use 'auto', 'original', or 'derived'.")

    client = connection_manager()
    report: dict[str, Any] = {
        "scope": scope,
        "mode": mode,
        "dry_run": dry_run,
        "full_scan": full_scan,
        "input_item_id": item_id,
        "original_collection_id": original_collection_id,
        "target_collection_kind": target_collection_kind,
        "seed_item_ids": [],
        "target_collection_ids": [],
        "collections": {},
        "seed_selection_issues": [],
        "summary": {
            "collections_processed": 0,
            "collections_updated": 0,
            "items_included": 0,
            "items_excluded": 0,
            "item_bbox_updates": 0,
            "item_bbox_update_failures": 0,
            "collection_bbox_update_failures": 0,
            "invalid_direct_item_attachments_removed": 0,
            "invalid_collection_item_links_removed": 0,
            "collection_child_links_updated": 0,
            "collection_child_links_added": 0,
            "collection_child_links_removed": 0,
        },
    }

    if full_scan:
        seed_item_ids, seed_scan_error = _list_dataset_ids_with_error(client, scope=scope)
        if seed_scan_error is not None:
            report["seed_selection_issues"].append(
                {"item_id": "<full_scan>", "reasons": [seed_scan_error]}
            )
        discovered_collection_ids, collection_discovery_errors = _discover_stac_collection_ids_with_error(
            client,
            scope=scope,
        )
        for discovery_error in collection_discovery_errors:
            report["seed_selection_issues"].append(
                {"item_id": "<collection_discovery>", "reasons": [discovery_error]}
            )
    else:
        seed_item_ids = [item_id.strip()]
        discovered_collection_ids = []
    report["seed_item_ids"] = seed_item_ids

    target_collections: set[str] = set()
    collection_seed_issues: dict[str, list[dict[str, Any]]] = defaultdict(list)
    seed_item_docs, seed_item_doc_errors = _load_documents_bulk(
        client,
        scope=scope,
        names=seed_item_ids,
        paths=SEED_ITEM_PARTIAL_PATHS,
    )
    for seed_item in seed_item_ids:
        did_type, did_type_error = _did_type_with_error(client, scope=scope, name=seed_item)
        if did_type_error is not None:
            report["seed_selection_issues"].append(
                {"item_id": seed_item, "reasons": [f"seed_item_lookup_failed:{did_type_error}"]}
            )
            continue
        if did_type != "DATASET":
            report["seed_selection_issues"].append(
                {"item_id": seed_item, "reasons": [f"item_not_found_or_not_item:{did_type or 'missing'}"]}
            )
            continue

        item_doc_error = seed_item_doc_errors.get(seed_item)
        if item_doc_error is not None:
            report["seed_selection_issues"].append({"item_id": seed_item, "reasons": [item_doc_error]})
            continue
        item_doc = seed_item_docs.get(seed_item, {})

        collection_id = item_doc.get("collection")
        if not isinstance(collection_id, str) or not collection_id.strip():
            report["seed_selection_issues"].append(
                {"item_id": seed_item, "reasons": ["collection_field_missing_or_invalid"]}
            )
            continue

        collection_id = collection_id.strip()

        seed_reasons: list[str] = []
        collection_exists_for_seed = False
        collection_is_stac_collection_seed = False
        seed_membership_observed = False
        collection_type, collection_type_error = _did_type_with_error(client, scope=scope, name=collection_id)
        if collection_type_error is not None:
            seed_reasons.append(f"collection_lookup_failed:{collection_type_error}")
        elif collection_type != "CONTAINER":
            seed_reasons.append("parent_collection_missing_or_invalid")
        else:
            collection_exists_for_seed = True
            collection_seed_doc, collection_seed_doc_error = _load_document(
                client,
                scope=scope,
                name=collection_id,
                paths=("/type",),
            )
            if collection_seed_doc_error is not None:
                seed_reasons.append(f"collection_metadata_read_failed:{collection_seed_doc_error}")
            elif not _is_stac_collection_document(collection_seed_doc):
                seed_reasons.append("parent_not_stac_collection")
            else:
                collection_is_stac_collection_seed = True
        collection_link_matches_seed = _collection_link_matches(item_doc.get("links"), collection_id=collection_id)
        if collection_is_stac_collection_seed and collection_id == original_collection_id:
            attached, attached_error = _is_child_attached_with_error(
                client,
                scope=scope,
                parent_name=collection_id,
                child_name=seed_item,
            )
            if attached_error is not None:
                seed_reasons.append(f"attachment_check_failed:{attached_error}")
            elif not attached:
                seed_reasons.append("item_not_attached_to_collection")
            else:
                seed_membership_observed = True
        elif collection_is_stac_collection_seed:
            facet_value_catalog_ids: set[str] = set()
            facet_parent_ids, facet_parent_error = _list_child_names_by_type_with_error(
                client,
                scope=scope,
                parent_name=collection_id,
                expected_type="CONTAINER",
            )
            if facet_parent_error is not None:
                seed_reasons.append(f"facet_parent_list_failed:{facet_parent_error}")
            else:
                for facet_parent_id in facet_parent_ids:
                    facet_values, facet_value_error = _list_child_names_by_type_with_error(
                        client,
                        scope=scope,
                        parent_name=facet_parent_id,
                        expected_type="CONTAINER",
                    )
                    if facet_value_error is not None:
                        seed_reasons.append(f"facet_value_list_failed:{facet_parent_id}:{facet_value_error}")
                        continue
                    facet_value_catalog_ids.update(facet_values)
            attached_to_any_facet_value = False
            facet_attachment_errors: list[str] = []
            for facet_value_catalog_id in facet_value_catalog_ids:
                attached, attached_error = _is_child_attached_with_error(
                    client,
                    scope=scope,
                    parent_name=facet_value_catalog_id,
                    child_name=seed_item,
                )
                if attached_error is not None:
                    facet_attachment_errors.append(f"{facet_value_catalog_id}:{attached_error}")
                    continue
                if attached:
                    attached_to_any_facet_value = True
                    break
            if not attached_to_any_facet_value:
                if facet_attachment_errors:
                    seed_reasons.append("facet_value_attachment_check_failed")
                else:
                    seed_reasons.append("item_not_attached_to_any_facet_value_catalog")
            else:
                seed_membership_observed = True
            direct_attached, direct_attachment_error = _is_child_attached_with_error(
                client,
                scope=scope,
                parent_name=collection_id,
                child_name=seed_item,
            )
            if direct_attachment_error is not None:
                seed_reasons.append(f"direct_collection_attachment_check_failed:{direct_attachment_error}")
            elif direct_attached:
                seed_membership_observed = True
                if not full_scan:
                    seed_reasons.append("item_directly_attached_to_collection")
        if not collection_link_matches_seed:
            seed_reasons.append("collection_link_missing_or_mismatch")
        seed_selects_collection = collection_is_stac_collection_seed and (
            collection_link_matches_seed or seed_membership_observed
        )
        if seed_reasons:
            seed_issue = {"item_id": seed_item, "reasons": seed_reasons}
            report["seed_selection_issues"].append(seed_issue)
            collection_seed_issues[collection_id].append(seed_issue)
            if not full_scan and seed_selects_collection:
                target_collections.add(collection_id)
            continue

        if seed_selects_collection:
            target_collections.add(collection_id)

    if full_scan:
        target_collections.update(discovered_collection_ids)

    if target_collection_kind == "original":
        target_collections = {collection_id for collection_id in target_collections if collection_id == original_collection_id}
    elif target_collection_kind == "derived":
        target_collections = {collection_id for collection_id in target_collections if collection_id != original_collection_id}

    report["target_collection_ids"] = sorted(target_collections)

    for collection_id in sorted(target_collections):
        collection_report: dict[str, Any] = {
            "collection_id": collection_id,
            "included_item_ids": [],
            "excluded_item_ids": [],
            "computed_bbox": None,
            "computed_temporal_interval": None,
            "collection_spatial_bbox_before": None,
            "collection_temporal_interval_before": None,
            "collection_bbox_updated": False,
            "collection_bbox_update_error": None,
            "facet_parent_catalog_ids": [],
            "facet_value_catalog_ids": [],
            "collection_child_links_updated": False,
            "collection_child_links_added": 0,
            "collection_child_links_removed": 0,
            "collection_child_links_update_error": None,
            "direct_collection_item_attachments_removed": 0,
            "direct_collection_item_links_removed": 0,
            "direct_collection_cleanup_error": None,
        }
        collection_inputs_incomplete = False
        report["collections"][collection_id] = collection_report
        report["summary"]["collections_processed"] += 1

        collection_type, collection_type_error = _did_type_with_error(client, scope=scope, name=collection_id)
        if collection_type_error is not None:
            collection_report["excluded_item_ids"].extend(collection_seed_issues.get(collection_id, []))
            collection_report["collection_bbox_update_error"] = f"collection_lookup_failed:{collection_type_error}"
            continue
        if collection_type != "CONTAINER":
            collection_report["excluded_item_ids"].extend(collection_seed_issues.get(collection_id, []))
            collection_report["collection_bbox_update_error"] = "parent_collection_missing_or_invalid"
            continue

        collection_doc, collection_doc_error = _load_document(client, scope=scope, name=collection_id)
        if collection_doc_error:
            collection_report["collection_bbox_update_error"] = f"collection_metadata_read_failed: {collection_doc_error}"
            collection_report["excluded_item_ids"].extend(collection_seed_issues.get(collection_id, []))
            continue
        if not _is_stac_collection_document(collection_doc):
            collection_report["collection_bbox_update_error"] = "target_not_stac_collection"
            collection_report["excluded_item_ids"].extend(collection_seed_issues.get(collection_id, []))
            continue
        collection_report["collection_spatial_bbox_before"] = _extract_collection_spatial_bbox(collection_doc)
        collection_report["collection_temporal_interval_before"] = _extract_collection_temporal_interval(collection_doc)

        direct_collection_dataset_ids, direct_list_error = _list_child_names_by_type_with_error(
            client,
            scope=scope,
            parent_name=collection_id,
            expected_type="DATASET",
        )
        if direct_list_error is not None:
            collection_report["collection_bbox_update_error"] = f"collection_content_read_failed:{direct_list_error}"
            collection_report["excluded_item_ids"].extend(collection_seed_issues.get(collection_id, []))
            continue
        child_dataset_ids: list[str] = []
        simulated_detached_direct_items: set[str] = set()

        if collection_id == original_collection_id:
            child_dataset_ids = direct_collection_dataset_ids
        else:
            if full_scan:
                detached_count = 0
                cleanup_error: Optional[str] = None
                for direct_item_id in direct_collection_dataset_ids:
                    if dry_run:
                        detached_count += 1
                        simulated_detached_direct_items.add(direct_item_id)
                        continue
                    detached, detach_error = _detach_attachment(
                        client,
                        scope=scope,
                        parent_name=collection_id,
                        child_name=direct_item_id,
                    )
                    if detached:
                        detached_count += 1
                    elif detach_error and cleanup_error is None:
                        cleanup_error = detach_error
                collection_report["direct_collection_item_attachments_removed"] = detached_count
                report["summary"]["invalid_direct_item_attachments_removed"] += detached_count

                removed_links, links_error = _remove_collection_item_href_links(
                    client,
                    scope=scope,
                    collection_id=collection_id,
                    item_ids=direct_collection_dataset_ids,
                    root_href=DEFAULT_STAC_ROOT_HREF,
                    mode=mode,
                    remove_all_item_links=True,
                    apply_changes=not dry_run,
                )
                collection_report["direct_collection_item_links_removed"] = removed_links
                report["summary"]["invalid_collection_item_links_removed"] += removed_links
                if links_error is not None and cleanup_error is None:
                    cleanup_error = f"collection_item_link_cleanup_failed:{links_error}"

                if cleanup_error is not None:
                    collection_report["direct_collection_cleanup_error"] = cleanup_error

            facet_parent_catalog_ids, facet_parent_error = _list_child_names_by_type_with_error(
                client,
                scope=scope,
                parent_name=collection_id,
                expected_type="CONTAINER",
            )
            if facet_parent_error is not None:
                collection_report["collection_bbox_update_error"] = f"facet_parent_list_failed:{facet_parent_error}"
                collection_report["excluded_item_ids"].extend(collection_seed_issues.get(collection_id, []))
                continue
            collection_report["facet_parent_catalog_ids"] = facet_parent_catalog_ids
            if full_scan:
                child_link_result, child_link_error = _reconcile_collection_child_catalog_links(
                    client,
                    scope=scope,
                    collection_id=collection_id,
                    collection_doc=collection_doc,
                    child_catalog_ids=facet_parent_catalog_ids,
                    root_href=DEFAULT_STAC_ROOT_HREF,
                    mode=mode,
                    apply_changes=not dry_run,
                )
                collection_report["collection_child_links_updated"] = bool(child_link_result.get("updated"))
                collection_report["collection_child_links_added"] = int(child_link_result.get("added", 0))
                collection_report["collection_child_links_removed"] = int(child_link_result.get("removed", 0))
                if collection_report["collection_child_links_updated"]:
                    report["summary"]["collection_child_links_updated"] += 1
                    report["summary"]["collection_child_links_added"] += collection_report["collection_child_links_added"]
                    report["summary"]["collection_child_links_removed"] += collection_report["collection_child_links_removed"]
                if child_link_error is not None:
                    collection_report["collection_child_links_update_error"] = (
                        f"collection_child_link_reconcile_failed:{child_link_error}"
                    )
            facet_value_catalog_ids: set[str] = set()
            for facet_parent_catalog_id in facet_parent_catalog_ids:
                facet_values, facet_value_error = _list_child_names_by_type_with_error(
                    client,
                    scope=scope,
                    parent_name=facet_parent_catalog_id,
                    expected_type="CONTAINER",
                )
                if facet_value_error is not None:
                    collection_report["collection_bbox_update_error"] = (
                        f"facet_value_list_failed:{facet_parent_catalog_id}:{facet_value_error}"
                    )
                    collection_inputs_incomplete = True
                    continue
                facet_value_catalog_ids.update(facet_values)
            collection_report["facet_value_catalog_ids"] = sorted(facet_value_catalog_ids)

            child_dataset_set: set[str] = set()
            for facet_value_catalog_id in collection_report["facet_value_catalog_ids"]:
                child_items, child_items_error = _list_child_names_by_type_with_error(
                    client,
                    scope=scope,
                    parent_name=facet_value_catalog_id,
                    expected_type="DATASET",
                )
                if child_items_error is not None:
                    collection_report["collection_bbox_update_error"] = (
                        f"facet_value_content_read_failed:{facet_value_catalog_id}:{child_items_error}"
                    )
                    collection_inputs_incomplete = True
                    continue
                child_dataset_set.update(child_items)
            child_dataset_ids = sorted(child_dataset_set)

        child_docs, child_doc_errors = _load_documents_bulk(
            client,
            scope=scope,
            names=child_dataset_ids,
            paths=CHILD_ITEM_PARTIAL_PATHS,
        )
        original_item_ids_needed: set[str] = set()
        if collection_id != original_collection_id:
            for child_item_id in child_dataset_ids:
                item_doc_error = child_doc_errors.get(child_item_id)
                if item_doc_error is not None:
                    continue
                item_doc = child_docs.get(child_item_id, {})
                original_item_id, original_ref_error = _derived_from_original_item_id(item_doc)
                if original_ref_error is None and original_item_id is not None:
                    original_item_ids_needed.add(original_item_id)
        original_docs, original_doc_errors = _load_documents_bulk(
            client,
            scope=scope,
            names=sorted(original_item_ids_needed),
            paths=ORIGINAL_ITEM_PARTIAL_PATHS,
        )
        included_bboxes: list[list[float]] = []
        included_temporal_bounds: list[tuple[datetime, datetime]] = []

        for child_item_id in child_dataset_ids:
            item_reasons: list[str] = []

            item_doc_error = child_doc_errors.get(child_item_id)
            if item_doc_error is not None:
                item_reasons.append(item_doc_error)
                collection_report["excluded_item_ids"].append({"item_id": child_item_id, "reasons": item_reasons})
                report["summary"]["items_excluded"] += 1
                continue
            item_doc = child_docs.get(child_item_id, {})

            item_collection = item_doc.get("collection")
            if item_collection != collection_id:
                item_reasons.append(
                    f"collection_field_mismatch:{item_collection if item_collection is not None else 'missing'}"
                )

            if not _collection_link_matches(item_doc.get("links"), collection_id=collection_id):
                item_reasons.append("collection_link_missing_or_mismatch")

            if collection_id == original_collection_id:
                attached, attached_error = _is_child_attached_with_error(
                    client,
                    scope=scope,
                    parent_name=collection_id,
                    child_name=child_item_id,
                )
                if attached_error is not None:
                    item_reasons.append(f"attachment_check_failed:{attached_error}")
                elif not attached:
                    item_reasons.append("item_not_attached_to_collection")
            else:
                attached_to_facet_value_catalog = False
                facet_attachment_errors: list[str] = []
                for facet_value_catalog_id in collection_report.get("facet_value_catalog_ids", []):
                    if not isinstance(facet_value_catalog_id, str):
                        continue
                    attached, attached_error = _is_child_attached_with_error(
                        client,
                        scope=scope,
                        parent_name=facet_value_catalog_id,
                        child_name=child_item_id,
                    )
                    if attached_error is not None:
                        facet_attachment_errors.append(f"{facet_value_catalog_id}:{attached_error}")
                        continue
                    if attached:
                        attached_to_facet_value_catalog = True
                        break
                if not attached_to_facet_value_catalog:
                    if facet_attachment_errors:
                        item_reasons.append(
                            "facet_value_attachment_check_failed:"
                            + ";".join(facet_attachment_errors[:3])
                        )
                    else:
                        item_reasons.append("item_not_attached_to_any_facet_value_catalog")
                direct_attached, direct_attachment_error = _is_child_attached_with_error(
                    client,
                    scope=scope,
                    parent_name=collection_id,
                    child_name=child_item_id,
                )
                if full_scan and dry_run and child_item_id in simulated_detached_direct_items:
                    direct_attached = False
                    direct_attachment_error = None
                if direct_attachment_error is not None:
                    item_reasons.append(f"direct_collection_attachment_check_failed:{direct_attachment_error}")
                elif direct_attached:
                    item_reasons.append("item_directly_attached_to_collection")

            item_geometry = item_doc.get("geometry")
            item_bbox_before = item_doc.get("bbox")
            item_bbox_before_2d = _bbox_to_2d(item_bbox_before)
            resolved_item_bbox: Optional[list[float]] = None
            item_bbox_updated = False
            item_bbox_update_error = None
            derived_coordinate_sync_required = False
            derived_target_geometry: Any = None

            if collection_id == original_collection_id:
                computed_item_bbox, geometry_error = _bbox_from_geometry(item_geometry)
                if geometry_error:
                    item_reasons.append(geometry_error)
                if item_bbox_before_2d is None:
                    item_reasons.append("bbox_missing_or_invalid")
                if computed_item_bbox is not None and item_bbox_before_2d is not None:
                    if not _bbox_equal(item_bbox_before_2d, computed_item_bbox):
                        item_reasons.append("original_bbox_geometry_mismatch")
                    else:
                        resolved_item_bbox = item_bbox_before_2d
            else:
                original_item_id, original_ref_error = _derived_from_original_item_id(item_doc)
                if original_ref_error is not None:
                    item_reasons.append(original_ref_error)
                else:
                    assert original_item_id is not None
                    original_item_type, original_item_type_error = _did_type_with_error(
                        client,
                        scope=scope,
                        name=original_item_id,
                    )
                    if original_item_type_error is not None:
                        item_reasons.append(f"original_item_lookup_failed:{original_item_type_error}")
                    elif original_item_type != "DATASET":
                        item_reasons.append("original_item_not_found_or_not_item")
                    original_attached, original_attachment_error = _is_child_attached_with_error(
                        client,
                        scope=scope,
                        parent_name=original_collection_id,
                        child_name=original_item_id,
                    )
                    if original_attachment_error is not None:
                        item_reasons.append(f"original_attachment_check_failed:{original_attachment_error}")
                    elif not original_attached:
                        item_reasons.append("original_item_not_attached_to_original_collection")

                    original_doc_error = original_doc_errors.get(original_item_id)
                    if original_doc_error is not None:
                        item_reasons.append(f"original_metadata:{original_doc_error}")
                    else:
                        original_doc = original_docs.get(original_item_id, {})
                        original_item_collection = original_doc.get("collection")
                        if original_item_collection != original_collection_id:
                            item_reasons.append(
                                "original_collection_field_mismatch:"
                                f"{original_item_collection if original_item_collection is not None else 'missing'}"
                            )
                        if not _collection_link_matches(original_doc.get("links"), collection_id=original_collection_id):
                            item_reasons.append("original_collection_link_missing_or_mismatch")

                        original_geometry = original_doc.get("geometry")
                        original_bbox = original_doc.get("bbox")
                        original_bbox_2d = _bbox_to_2d(original_bbox)
                        original_bbox_from_geometry, original_geometry_error = _bbox_from_geometry(original_geometry)
                        if original_geometry_error:
                            item_reasons.append(f"original_{original_geometry_error}")
                        if original_bbox_2d is None:
                            item_reasons.append("original_bbox_missing_or_invalid")

                        if original_bbox_from_geometry is not None and original_bbox_2d is not None:
                            if not _bbox_equal(original_bbox_2d, original_bbox_from_geometry):
                                item_reasons.append("original_bbox_geometry_mismatch")
                            else:
                                resolved_item_bbox = original_bbox_2d
                                coordinates_match = (
                                    item_geometry == original_geometry
                                    and item_bbox_before_2d is not None
                                    and _bbox_equal(item_bbox_before_2d, original_bbox_2d)
                                )
                                if not coordinates_match:
                                    derived_coordinate_sync_required = True
                                    derived_target_geometry = original_geometry

            item_temporal_bounds, temporal_error = _temporal_bounds_from_properties(item_doc.get("properties"))
            if temporal_error:
                item_reasons.append(temporal_error)

            if (
                    not item_reasons
                    and collection_id != original_collection_id
                    and derived_coordinate_sync_required
                    and resolved_item_bbox is not None
            ):
                if not dry_run:
                    item_bbox_updated, item_bbox_update_error = _patch_item_coordinates(
                        client,
                        scope=scope,
                        name=child_item_id,
                        geometry=derived_target_geometry,
                        bbox=resolved_item_bbox,
                        mode=mode,
                    )
                    if item_bbox_updated:
                        report["summary"]["item_bbox_updates"] += 1
                    else:
                        report["summary"]["item_bbox_update_failures"] += 1
                        item_reasons.append(
                            "derived_coordinate_sync_failed:"
                            f"{item_bbox_update_error or 'unknown_error'}"
                        )
                else:
                    item_bbox_updated = True
                    report["summary"]["item_bbox_updates"] += 1

            if item_reasons:
                entry: dict[str, Any] = {"item_id": child_item_id, "reasons": item_reasons}
                if resolved_item_bbox is not None:
                    entry["computed_item_bbox"] = resolved_item_bbox
                collection_report["excluded_item_ids"].append(entry)
                report["summary"]["items_excluded"] += 1
                continue

            assert resolved_item_bbox is not None
            assert item_temporal_bounds is not None

            collection_report["included_item_ids"].append(
                {
                    "item_id": child_item_id,
                    "item_bbox_before": item_bbox_before,
                    "computed_item_bbox": resolved_item_bbox,
                    "computed_item_temporal_interval": _temporal_interval_from_bounds(item_temporal_bounds),
                    "item_bbox_updated": item_bbox_updated,
                    "item_bbox_update_error": item_bbox_update_error,
                }
            )
            report["summary"]["items_included"] += 1
            included_bboxes.append(resolved_item_bbox)
            included_temporal_bounds.append(item_temporal_bounds)

        if collection_seed_issues.get(collection_id):
            known_excluded = {
                entry["item_id"]
                for entry in collection_report["excluded_item_ids"]
                if isinstance(entry, dict) and isinstance(entry.get("item_id"), str)
            }
            known_included = {
                entry["item_id"]
                for entry in collection_report["included_item_ids"]
                if isinstance(entry, dict) and isinstance(entry.get("item_id"), str)
            }
            for seed_issue in collection_seed_issues[collection_id]:
                if seed_issue["item_id"] not in known_excluded and seed_issue["item_id"] not in known_included:
                    collection_report["excluded_item_ids"].append(seed_issue)
                    report["summary"]["items_excluded"] += 1

        if collection_inputs_incomplete:
            if not collection_report.get("collection_bbox_update_error"):
                collection_report["collection_bbox_update_error"] = "collection_inputs_incomplete"
            continue

        if not included_bboxes:
            if not collection_report.get("collection_bbox_update_error"):
                collection_report["collection_bbox_update_error"] = "no_valid_items_for_collection_bbox"
            continue

        collection_bbox = _union_bbox(included_bboxes)
        collection_temporal_interval = _temporal_interval_from_bounds(_union_temporal_bounds(included_temporal_bounds))
        collection_report["computed_bbox"] = collection_bbox
        collection_report["computed_temporal_interval"] = collection_temporal_interval
        if (
            _collection_spatial_bbox_needs_normalization(collection_doc)
            or _collection_temporal_interval_needs_normalization(collection_doc)
            or not _bbox_equal(collection_report["collection_spatial_bbox_before"], collection_bbox)
            or not _temporal_interval_equal(
                collection_report["collection_temporal_interval_before"],
                collection_temporal_interval,
            )
        ):
            if not dry_run:
                updated, update_error = _patch_collection_extent(
                    client,
                    scope=scope,
                    collection_id=collection_id,
                    collection_doc=collection_doc,
                    bbox=collection_bbox,
                    temporal_interval=collection_temporal_interval,
                    mode=mode,
                )
                collection_report["collection_bbox_updated"] = updated
                collection_report["collection_bbox_update_error"] = update_error
                if updated:
                    report["summary"]["collections_updated"] += 1
                else:
                    report["summary"]["collection_bbox_update_failures"] += 1
            else:
                collection_report["collection_bbox_updated"] = True
                report["summary"]["collections_updated"] += 1

    LOG.result(
        "Spatial bbox sync finished (collections_processed=%s, collections_updated=%s, items_included=%s, items_excluded=%s).",
        report["summary"]["collections_processed"],
        report["summary"]["collections_updated"],
        report["summary"]["items_included"],
        report["summary"]["items_excluded"],
    )
    return _finalize_spatial_sync_report(report, compact_result=compact_result)


def sync_original_collection_extent(
        item_id: str | None = None,
        *,
        scope: str = "dafab",
        original_collection_id: str = DEFAULT_ORIGINAL_COLLECTION_ID,
        full_scan: bool = False,
        mode: str = "atomic",
        dry_run: bool = False,
        compact_result: bool = True,
) -> dict[str, Any]:
    """Reconcile bbox/temporal extent for the original collection path.

    Args:
        item_id: Optional seed item used to infer the target collection context.
        scope: Scope containing original items and collections.
        original_collection_id: Identifier of the original collection.
        full_scan: When ``True``, scan all eligible items instead of seed-only traversal.
        mode: Metadata patch mode passed to update operations.
        dry_run: Compute and report changes without applying patches.
        compact_result: Return compact summary when ``True``.

    Returns:
        dict[str, Any]: Sync report with processed objects, updates and failures.
    """
    return _sync_collection_extent_integrity(
        item_id=item_id,
        scope=scope,
        original_collection_id=original_collection_id,
        full_scan=full_scan,
        target_collection_kind="original",
        mode=mode,
        dry_run=dry_run,
        compact_result=compact_result,
    )


def sync_derived_collection_extent(
        item_id: str | None = None,
        *,
        scope: str = "dafab",
        original_collection_id: str = DEFAULT_ORIGINAL_COLLECTION_ID,
        full_scan: bool = False,
        mode: str = "atomic",
        dry_run: bool = False,
        compact_result: bool = True,
) -> dict[str, Any]:
    """Reconcile bbox/temporal extent for derived collections.

    Args:
        item_id: Optional seed item used to infer target collection context.
        scope: Scope containing derived items and collections.
        original_collection_id: Original collection used for source-coordinate checks.
        full_scan: When ``True``, scan all eligible items instead of seed-only traversal.
        mode: Metadata patch mode passed to update operations.
        dry_run: Compute and report changes without applying patches.
        compact_result: Return compact summary when ``True``.

    Returns:
        dict[str, Any]: Sync report with processed objects, updates and failures.
    """
    return _sync_collection_extent_integrity(
        item_id=item_id,
        scope=scope,
        original_collection_id=original_collection_id,
        full_scan=full_scan,
        target_collection_kind="derived",
        mode=mode,
        dry_run=dry_run,
        compact_result=compact_result,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reconcile item/collection bbox integrity from item geometries.")
    parser.add_argument("--item-id", default=None, help="Optional item id used to select target collection.")
    parser.add_argument("--scope", default="dafab", help="Scope containing item and collection objects.")
    parser.add_argument(
        "--original-collection-id",
        default=DEFAULT_ORIGINAL_COLLECTION_ID,
        help="Collection id containing original source items used as coordinate truth.",
    )
    parser.add_argument(
        "--full-scan",
        action="store_true",
        help="Scan all items in scope and reconcile all discovered collections.",
    )
    parser.add_argument(
        "--collection-kind",
        choices=("original", "derived"),
        default="derived",
        help="Choose whether to process original or derived collection integrity.",
    )
    parser.add_argument("--mode", choices=("atomic", "best_effort"), default="atomic", help="Patch execution mode.")
    parser.add_argument("--dry-run", action="store_true", help="Compute and report changes without writing.")
    args = parser.parse_args()

    sync_fn = sync_original_collection_extent if args.collection_kind == "original" else sync_derived_collection_extent
    output = sync_fn(
        item_id=args.item_id,
        scope=args.scope,
        original_collection_id=args.original_collection_id,
        full_scan=args.full_scan,
        mode=args.mode,
        dry_run=args.dry_run,
    )
    print(output)
