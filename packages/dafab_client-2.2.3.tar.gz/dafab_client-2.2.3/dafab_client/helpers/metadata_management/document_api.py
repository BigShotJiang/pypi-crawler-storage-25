"""Shared helpers for structured metadata document operations."""

from __future__ import annotations

from typing import Any

_MISSING = object()
_VALID_PATCH_OPS = {"insert", "update", "delete", "upsert"}


def _escape_pointer_token(token: str) -> str:
    return token.replace("~", "~0").replace("/", "~1")


def comma_path_to_json_pointer(path: str) -> str:
    """Convert a legacy comma-separated metadata path to JSON Pointer."""
    tokens = [token.strip() for token in path.split(",")]
    if not tokens or any(token == "" for token in tokens):
        raise ValueError(f"Invalid legacy metadata path '{path}'.")
    return "/" + "/".join(_escape_pointer_token(token) for token in tokens)


def normalize_metadata_path(path: str, *, allow_root: bool = True) -> str:
    """Normalize a metadata path to JSON Pointer while keeping legacy compatibility."""
    normalized = path.strip()
    if normalized == "{}":
        return ""
    if normalized == "":
        if allow_root:
            return ""
        raise ValueError("Root path '' is not allowed for this operation.")
    if normalized.startswith("/"):
        return normalized
    return comma_path_to_json_pointer(normalized)


def build_patch_operation(op: str, path: str, value: Any = _MISSING) -> dict[str, Any]:
    """Build and validate a BulkMetaDoc patch operation payload."""
    op_norm = op.strip().lower()
    if op_norm not in _VALID_PATCH_OPS:
        raise ValueError(f"Unsupported operation '{op}'.")

    pointer = normalize_metadata_path(path, allow_root=(op_norm != "insert"))
    if op_norm == "insert" and pointer == "":
        raise ValueError("Insert does not support the root path ''.")

    operation: dict[str, Any] = {"op": op_norm, "path": pointer}
    if op_norm == "delete":
        if value is not _MISSING:
            raise ValueError("Delete operations must not include a value.")
        return operation

    if value is _MISSING:
        raise ValueError(f"Operation '{op_norm}' requires a value.")
    operation["value"] = value
    return operation


def coerce_paths(paths: list[str] | tuple[str, ...] | None) -> list[str] | None:
    """Normalize a list of paths to JSON Pointer format."""
    if paths is None:
        return None
    normalized_paths = [normalize_metadata_path(path) for path in paths]
    return normalized_paths or None
