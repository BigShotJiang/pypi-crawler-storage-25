"""Path and schema helpers safe for installed-package execution."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

_SCHEMA_DIR = Path(__file__).resolve().parent / "resources" / "schemas"

_SCHEMA_ALIAS_TO_FILE = {
    "Schema_Copernicus_with_dafab.json": "Schema_Copernicus_with_dafab.json",
    "dasi-original-item.schema.json": "dasi-original-item.schema.json",
    "dafab-water_analysis-item.schema.json": "dafab-water_analysis-item.schema.json",
    "dafab-smart_agriculture-item.schema.json": "dafab-smart_agriculture-item.schema.json",
    "Schema_DaFab_Facet_Value_Catalog.json": "Schema_DaFab_Facet_Value_Catalog.json",
}


def get_demo_data_dir() -> Path:
    """Return writable demo-data directory (env override, else current working directory)."""
    custom = os.getenv("DAFAB_DEMO_DATA_DIR")
    if custom:
        return Path(custom).expanduser().resolve()
    return Path.cwd() / "demo-data"


def get_default_bbox_map_output_path() -> Path:
    """Return default map output path under writable demo-data."""
    return get_demo_data_dir() / "filters" / "bbox_map.html"


def _resolve_existing_file(path: str | Path, *, base_dir: str | Path | None = None) -> Path | None:
    candidate = Path(path).expanduser()
    candidates = [candidate]

    if not candidate.is_absolute():
        candidates.append(Path.cwd() / candidate)
        if base_dir is not None:
            candidates.append(Path(base_dir) / candidate)

    for option in candidates:
        if option.is_file():
            return option
    return None


def _builtin_schema_file_for(identifier: str | Path) -> Path | None:
    normalized = str(identifier).strip().replace("\\", "/")
    mapped = _SCHEMA_ALIAS_TO_FILE.get(normalized)
    if mapped is None:
        mapped = _SCHEMA_ALIAS_TO_FILE.get(Path(normalized).name)
    if mapped is None:
        return None
    candidate = _SCHEMA_DIR / mapped
    return candidate if candidate.is_file() else None


def load_json_schema(
        schema_identifier: str | Path,
        *,
        base_dir: str | Path | None = None,
) -> tuple[dict[str, Any], str]:
    """Load a JSON schema from explicit path or bundled fallback.

    Returns the parsed schema and a human-readable source descriptor.
    """
    file_path = _resolve_existing_file(schema_identifier, base_dir=base_dir)
    if file_path is not None:
        with file_path.open("r", encoding="utf-8") as handle:
            return json.load(handle), str(file_path)

    builtin_path = _builtin_schema_file_for(schema_identifier)
    if builtin_path is not None:
        with builtin_path.open("r", encoding="utf-8") as handle:
            return json.load(handle), f"builtin://{builtin_path.name}"

    raise FileNotFoundError(
        f"Schema '{schema_identifier}' not found as a local file and no bundled fallback exists."
    )
