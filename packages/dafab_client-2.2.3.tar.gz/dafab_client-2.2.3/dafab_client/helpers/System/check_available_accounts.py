from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)

cl = None


def _get_client():
    """Return a cached client instance used by this module."""
    global cl
    if cl is None:
        cl = connection_manager()
    return cl

"""
---
summary: List accounts
description: Lists all Rucio accounts matching the given filters.
tags:
  - Accounts
parameters:
- name: X-Rucio-Auth-Token
  in: header
  description: The authentication token obtained from the auth server.
  schema:
    type: string
  required: true
- name: X-Rucio-Account
  in: header
  description: The account to use for the operation.
  schema:
    type: string
  required: false
- name: X-Rucio-VO
  in: header
  description: The Virtual Organization to act on.
  schema:
    type: string
  required: false
  default: 'def'
- name: account_type
  in: query
  description: Filter accounts by type
  schema:
    type: string
    enum: ['USER', 'GROUP', 'SERVICE']
  required: false
- name: identity
  in: query
  description: The identity key name (e.g. x509 DN or username)
  schema:
    type: string
  required: false
- name: filters
  in: query
  description: Additional filters as key-value pairs
  schema:
    type: object
    additionalProperties: true
  required: false
  style: form
  explode: true
responses:
  200:
    description: OK
    content:
      application/x-json-stream:
        schema:
          type: array
          items:
            type: object
            properties:
              account:
                type: string
                description: The account name
              account_type:
                type: string
                description: The type of account
                enum: ['USER', 'GROUP', 'SERVICE']
              status:
                type: string
                description: Account status
                enum: ['ACTIVE', 'SUSPENDED', 'DELETED']
              email:
                type: string
                description: Email associated with the account
              created_at:
                type: string
                format: date-time
                description: Account creation timestamp
              suspended_at:
                type: string
                format: date-time
                description: Account suspension timestamp
              updated_at:
                type: string
                format: date-time
                description: Last update timestamp
  401:
    description: Invalid Auth Token
  404:
    description: Account not found
    content:
      application/json:
        schema:
          type: object
          properties:
            ExceptionClass:
              type: string
              example: AccountNotFound
            ExceptionMessage:
              type: string
              example: Account does not exist.
"""


def list_accounts():
    """List visible accounts and log each entry.

    Returns:
        None: Results are emitted through logger output.

    Raises:
        Exception: Re-raises client errors after logging.
    """
    try:
        # Call the list_accounts method
        _accounts = _get_client().list_accounts()
        for account in _accounts:
            LOG.result(account)
    except Exception as e:
        LOG.error(f"An error of type '{type(e).__name__}' occurred while listing accounts: {e}\n")
        raise


"""
---
summary: Who am I
description: Returns identity information for the authenticated Rucio client.
tags:
  - Accounts
responses:
  200:
    description: OK
    content:
      application/json:
        schema:
          type: object
          description: Identity and account metadata for the current session.
  401:
    description: Invalid Auth Token
  500:
    description: Internal error while querying identity
"""


def whoami():
    """Return identity information for the active authenticated session.

    Returns:
        dict[str, Any]: Identity payload returned by the server for the current token.

    Raises:
        Exception: Re-raises client errors after logging.
    """

    try:
        return _get_client().whoami()
    except Exception as e:
        LOG.error("Failed to retrieve identity due to '%s': %s", type(e).__name__, e)
        raise


if __name__ == "__main__":
    # Get all existing accounts
    list_accounts()

    whoami()
