from dafab_client._rucio.dafab_lib import connection_manager, as_pretty_json
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)

cl = None


def _get_client():
    global cl
    if cl is None:
        cl = connection_manager()
    return cl


"""
---
summary: List RSEs
description: Retrieves the configured RSEs available to the client.
tags:
  - Storage
responses:
  200:
    description: OK
  401:
    description: Invalid Auth Token
  500:
    description: Internal error while fetching RSEs
"""

def list_storages():
    """List storage endpoints visible to the active account.

    The function prints each RSE record via logger output and raises on client
    errors so callers can fail fast in scripts.
    """

    try:
        result = _get_client().list_rses()
        LOG.info("Configured RSEs:")
        for rse in result:
            LOG.result("\n" + as_pretty_json(rse))
    except Exception as e:
        LOG.error(f"Failed to list RSEs due to '{type(e).__name__}': {e}")
        raise


"""
---
summary: Get RSE
description: Returns the metadata for a specific RSE.
tags:
  - Storage
parameters:
- name: rse
  in: path
  description: The RSE name to inspect
  schema:
    type: string
responses:
  200:
    description: OK
  404:
    description: RSE not found
"""

def  check_storage(rse_name: str):
    """Return metadata for one storage endpoint.

    Args:
        rse_name: Storage endpoint identifier to inspect.

    Returns:
        dict[str, Any]: Full RSE metadata document returned by the server.

    Raises:
        Exception: Propagates client failures (for example unknown RSE or
            connectivity/authentication errors).
    """

    try:
        return _get_client().get_rse(rse_name)
    except Exception as e:
        LOG.error(
            "Failed to fetch details for RSE '%s' due to '%s': %s",
            rse_name,
            type(e).__name__,
            e,
        )
        raise


if __name__ == "__main__":
    # List RSEs and fetch details for a sample RSE when run as a script
    list_storages()
    check_storage("MELUXINA_S3")
