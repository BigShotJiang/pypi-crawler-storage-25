"""Helpers for listing file level DIDs."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Sequence

from dafab_client._rucio.dafab_lib import as_pretty_json, connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


_DEFAULT_FILTER = {"name": "*"}


def _normalize_filters(filters: Any) -> list[dict[str, Any]]:
    if filters is None:
        return [_DEFAULT_FILTER.copy()]
    if isinstance(filters, dict):
        return [filters]
    if isinstance(filters, Iterable):
        return list(filters)
    raise TypeError("filters must be a dict, an iterable of dicts, or None")


def get_assets(
        scope: str = "dafab",
        item: str | None = None,
        filters: Any = None,
        long: bool = True,
        recursive: bool = False,
) -> list[dict[str, Any]]:
    """Return file-level metadata either for one item or for a scope query.

    Args:
        scope: Namespace used when resolving file entries.
        item: Optional item id. When provided, the query is restricted to this item.
        filters: Optional scope-level DID filters used only when ``item`` is not provided.
        long: Include extended attributes in returned file entries.
        recursive: Traverse nested containers when ``item`` is not provided.

    Returns:
        list[dict[str, Any]]: File entries returned by the metadata service.
    """

    if item is not None:
        return assets_in_item(scope=scope, item=item, long=long)

    normalized_filters = _normalize_filters(filters)
    files = connection_manager().list_dids(
        scope=scope,
        filters=normalized_filters,
        did_type="file",
        long=long,
        recursive=recursive,
    )
    return list(files)


def assets_in_item(scope: str = "dafab", item: str | None = None, long: bool = True) -> list[dict[str, Any]]:
    """Return file entries attached to one item id.

    Args:
        scope: Namespace containing the target item.
        item: Item id whose file entries should be listed. Required.
        long: Include extended attributes in each returned file entry.

    Returns:
        list[dict[str, Any]]: File entries registered under the item.
    """

    if item is None:
        raise ValueError("'item' must be provided when listing files inside a dataset")

    files = connection_manager().list_files(scope=scope, name=item, long=long)
    return list(files)


def print_files(files: Sequence[dict[str, Any]], title: str) -> None:
    """Pretty print a list of file dictionaries."""

    if not files:
        LOG.result("No files found for %s", title)
        return

    LOG.info("Files for %s:", title)
    for file_info in files:
        LOG.result(file_info)


def list_assets(item: str | None = None, scope: str = "dafab", **kwargs: Any) -> None:
    """Print file entries for a scope or for one item.

    Args:
        item: Optional item id. When provided, prints files for that item only.
        scope: Namespace used to resolve the query.
        **kwargs: Forwarded to :func:`get_assets` (for example ``filters`` or ``long``).
    """
    files = get_assets(scope=scope, item=item, **kwargs)
    title = f"dataset {scope}:{item}" if item else f"scope '{scope}'"
    print_files(files, title)


def print_assets_in_item(scope: str = "dafab", item: str | None = None, long: bool = True) -> None:
    """Print file entries for one item.

    Args:
        scope: Namespace containing the item.
        item: Item id whose file entries are printed. Required.
        long: Include extended attributes in printed entries.
    """
    if item is None:
        raise ValueError("'item' must be provided when printing files for a dataset")

    files = assets_in_item(scope=scope, item=item, long=long)
    print_files(files, f"dataset {scope}:{item}")


if __name__ == "__main__":
    list_assets()
