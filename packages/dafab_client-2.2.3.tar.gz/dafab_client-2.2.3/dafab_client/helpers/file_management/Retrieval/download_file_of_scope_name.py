import os
import time
import argparse
import traceback
import json as jsn
from pathlib import Path
from typing import Optional, Union

from dafab_client._rucio.dafab_lib import download_manager, validate_metadata
from dafab_client.helpers.metadata_management.Retrieval.Complete.get_metadata_for_scope_name import get_bulk_metadata
from dafab_client.helpers.metadata_management.Retrieval.Partial.get_single_metadata_for_scope_name import extract_metadata_value
from dafab_client.helpers.runtime_paths import load_json_schema
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


# TODO[DX]: Convert to module if needed
# def list_dataset_replicas(replica_scope='dafab', replica_name='S4B_43QDB_20240408_0_L2A', deep_lookup=True):
#     dataset_replicas = cl.list_dataset_replicas(replica_scope, replica_name, deep_lookup)
#     LOG.info(f"Replicas with scope={replica_scope} and name={replica_name}:")
#     for dataset in dataset_replicas:
#         LOG.info(dataset)
# list_dataset_replicas()


def download_file(fname,
                  store_dir: Optional[Union[str, Path]] = None,
                  scope: str = 'dafab',
                  rse: str = 'MELUXINA_S3'
                  ):
    """
    Download a stored file with retry logic.

    A new downloader from `download_manager` is used for each attempt. Failures are logged
    and the operation is retried up to ``max_retries`` times with a pause of ``retry_delay``
    seconds between attempts.

    Parameters
    ----------
    fname : str
        Name of the file to retrieve.
    store_dir : Optional[Union[str, Path]] = None
        Destination directory for the downloaded file.
    scope : str, optional
        Rucio scope of the file. Defaults to ``'dafab'``.
    rse : str, optional
        RSE from which the file is downloaded. Defaults to ``'MELUXINA_S3'``.

    Returns
    -------
    bool
        ``True`` if the file is retrieved successfully, otherwise ``False`` after all
        retries are exhausted or the downloader reports a failure.
    """
    max_retries = 5
    retry_delay = 30  # seconds

    if store_dir:
        store_dir = str(store_dir)

    for attempt in range(max_retries):
        try:
            # Get a downloader connection
            downloader = download_manager()
            downloader.logger = LOG.log

            success = downloader.download_file(fname, store_dir, scope, rse)
            if success:
                return True
            else:
                LOG.warning(f"The download of file '{fname}' did not finish normally.\n")
                return False

        except Exception as e:
            LOG.warning(f"Attempt {attempt + 1}/{max_retries}: An unexpected error "
                        f"of type '{type(e).__name__}' occurred "
                        f"while downloading the requested file at '{store_dir}': {e}\n")

            # Get the full traceback for debugging:
            traceback.print_exc()

            if attempt < max_retries - 1:  # Don't sleep after the last attempt
                LOG.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)

    LOG.warning("All retry attempts exhausted.")
    return False


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Download file from Rucio storage.')
    parser.add_argument('product_name', type=str,
                        help='Name of the Copernicus product (e.g., S2B_43QDB_20240408_0_L2A).')
    parser.add_argument('base_dir',
                        type=str,
                        help='Base directory where the downloaded file will be stored (e.g., "{root_path}/demo-data/downloads/").')
    parser.add_argument('metadata_value_path', type=str,
                        help='The path of the value which will be extracted.')

    args = parser.parse_args()

    product_name = args.product_name
    base_dir = args.base_dir
    metadata_value_path = args.metadata_value_path  # JSON Pointer or legacy comma path (e.g. 'assets,dafab-field-boundaries,href')

    try:
        metadata_obj = get_bulk_metadata(product_name)
    except Exception as e:
        LOG.error(f"Failed to parse metadata string as JSON: {e}")
        exit(1)

    filename = extract_metadata_value(metadata_value_path, metadata_obj)
    if filename is None:
        exit(1)
    else:
        LOG.info(f"The .geojson file corresponding to the specified EO product {product_name}, "
                 f"\nhas already been successfully uploaded as {filename} prior to current download request.\n")

        dest_file_path = os.path.join(base_dir, filename)

        # Attempt to remove the file if it exists
        if os.path.exists(dest_file_path):
            try:
                os.remove(dest_file_path)
                LOG.info(f"Removed existing file at: {dest_file_path}")
            except OSError as e:
                LOG.error(f"Failed to remove {dest_file_path} before download: {e}")

        download_success = download_file(filename, base_dir)
        if not download_success:
            exit(1)

        schema_filename = 'Schema_GCore-FB.json'
        LOG.debug(f"Validating the {filename} content..")

        # Load the metadata schema to validate the retrieved generated metadata.
        metadata_schema, metadata_schema_source = load_json_schema(schema_filename)
        # LOG.debug(f"Loaded metadata schema from {metadata_schema_source}:")
        # LOG.debug(jsn.dumps(metadata_schema, indent=2))

        # Load the metadata content from the downloaded geojson file.
        with open(dest_file_path, 'r') as file:
            generated_metadata = jsn.load(file)
            # LOG.debug(f"Loaded key-value pairs from {metadata_path}:")
            # LOG.debug(jsn.dumps(generated_metadata, indent=2))

        validation_success = validate_metadata(filename, generated_metadata, metadata_schema_source, metadata_schema)
        exit(0 if validation_success else 1)
