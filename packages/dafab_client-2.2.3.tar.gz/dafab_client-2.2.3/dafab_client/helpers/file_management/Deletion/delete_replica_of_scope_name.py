import time
import argparse
import traceback

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.common.exception import AccessDenied, ReplicaNotFound
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


def delete_replica(
        fname: str,
        rse: str = 'MELUXINA_S3',
        scope: str = 'dafab',
        ignore_availability: bool = True,
):
    """
    Remove a file replica from Rucio.

    The helper attempts to deregister the replica identified by ``fname`` on
    the specified RSE.  It uses a Rucio client from `connection_manager`
    and retries a few times if transient failures occur.

    Parameters
    ----------
    fname : str
        Name of the file whose replica should be removed.
    rse : str, optional
        Target RSE from which to delete the replica, by default ``'MELUXINA_S3'``.
    scope : str, optional
        Rucio scope of the file, by default ``'dafab'``.
    ignore_availability : bool, optional
        Ignore RSE availability while deleting the replica, by default ``True``.

    Returns
    -------
    bool
        ``True`` if the replica was successfully removed or was already absent,
        ``False`` after all retry attempts failed.
    """
    max_retries = 5
    retry_delay = 30  # seconds

    for attempt in range(max_retries):
        try:
            # Get a client connection
            cl = connection_manager()

            success = cl.delete_replicas(
                rse=rse,
                files=[{'scope': scope, 'name': fname}],
                ignore_availability=ignore_availability,
            )
            if success:
                LOG.result(f"The '{scope}:{fname}' replica is deregistered from {rse}.\n")
                return True
            else:
                LOG.warning(f"Deletion of the '{scope}:{fname}' replica from {rse} was not successful.\n")
                return False

        except ReplicaNotFound:
            LOG.result(f"The '{scope}:{fname}' replica is already absent from {rse}.\n")
            return True
        except AccessDenied as e:
            LOG.warning(
                f"Access denied while deleting the '{scope}:{fname}' replica from {rse}: {e}\n"
            )
            return False
        except Exception as e:
            LOG.warning(f"Attempt {attempt + 1}/{max_retries}: An unexpected error "
                        f"of type '{type(e).__name__}' occurred "
                        f"while deleting the '{scope}:{fname}' replica from {rse}: {e}\n")

            # Get the full traceback for debugging:
            traceback.print_exc()

            if attempt < max_retries - 1:  # Don't sleep after the last attempt
                LOG.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)

    LOG.warning("All retry attempts exhausted.")
    return False


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Remove replica of a Copernicus metadata filename.')
    parser.add_argument('filename', type=str,
                        help='Copernicus metadata filename (e.g., field-boundaries-S2B_43QDB_20240408_0_L2A.geojson).')
    parser.add_argument('--scope', default='dafab', help='Rucio scope of the file. Defaults to dafab.')
    parser.add_argument('--rse', default='MELUXINA_S3', help='RSE from which to remove the replica.')

    args = parser.parse_args()

    filename = args.filename

    deletion_success = delete_replica(filename, scope=args.scope, rse=args.rse)
    exit(0 if deletion_success else 1)
