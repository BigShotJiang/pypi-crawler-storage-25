import argparse
import time
import traceback

import requests

from dafab_client._rucio.dafab_lib import connection_manager, upload_manager
from dafab_client._rucio.common.exception import AccessDenied, RucioException, SourceNotFound
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)

SIGNED_DELETE_TIMEOUT = 120


def _delete_file_via_signed_url(
        fname: str,
        scope: str,
        rse: str,
        timeout: int = SIGNED_DELETE_TIMEOUT,
) -> bool:
    """Delete a file through a signed HTTPS URL when the RSE supports sign_url."""
    client = connection_manager()
    did_str = f"{scope}:{fname}"
    pfn_map = client.lfns2pfns(
        rse=rse,
        lfns=[did_str],
        protocol_domain="wan",
        operation="delete",
        scheme="https",
    )
    delete_pfn = pfn_map.get(did_str)
    if not isinstance(delete_pfn, str) or not delete_pfn.strip():
        raise RucioException(f"Unable to resolve a delete PFN for {did_str} on {rse}.")

    rse_info = client.get_rse(rse)
    sign_service = rse_info.get("sign_url")
    if not sign_service:
        raise RucioException(f"RSE {rse} does not advertise sign_url support.")

    signed_url = client.get_signed_url(rse, str(sign_service), "delete", delete_pfn)
    response = requests.delete(signed_url, timeout=timeout)
    if response.status_code in {200, 202, 204}:
        return True
    if response.status_code == 404:
        raise SourceNotFound()
    if response.status_code in {401, 403}:
        raise AccessDenied(response.text or "Signed delete was rejected by the storage service.")
    raise RucioException(
        f"Signed delete failed with HTTP {response.status_code}: {response.text[:200]}"
    )


def delete_file(fname: str, scope: str = 'dafab', rse: str = 'MELUXINA_S3'):
    """
    Remove a file from an RSE in Rucio.

    For signed-URL storages such as ``MELUXINA_S3``, the helper resolves the PFN
    through the server and performs a direct HTTPS DELETE using a signed URL.
    Other RSEs fall back to the legacy upload-client delete path.

    Parameters
    ----------
    fname : str
        Name of the file to delete.
    scope : str, optional
        Rucio scope of the file, by default ``'dafab'``.
    rse : str, optional
        Target RSE from which the file is deleted, by default ``'MELUXINA_S3'``.

    Returns
    -------
    bool
        ``True`` if the file was removed successfully, ``False`` after all retry attempts failed.
    """
    max_retries = 5
    retry_delay = 30  # seconds

    for attempt in range(max_retries):
        try:
            client = connection_manager()
            rse_info = client.get_rse(rse)
            if rse_info.get("sign_url"):
                _delete_file_via_signed_url(fname, scope, rse)
            else:
                uploader = upload_manager()
                uploader.delete_file(fname, scope, rse)
            LOG.result(f"The deletion process of file '{fname}' from {rse} RSE finished.\n")
            return True
        except SourceNotFound:
            LOG.result(f"The file '{scope}:{fname}' is already absent from {rse}.\n")
            return True
        except AccessDenied as e:
            LOG.warning(
                f"Access denied while deleting the file '{scope}:{fname}' from {rse}: {e}\n"
            )
            return False
        except Exception as e:
            LOG.warning(f"Attempt {attempt + 1}/{max_retries}: An unexpected error of type '{type(e).__name__}' occurred "
                f"while deleting the '{fname}' file from {rse} RSE: {e}\n")

            # Get the full traceback for debugging:
            traceback.print_exc()

            if attempt < max_retries - 1:  # Don't sleep after the last attempt
                LOG.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)

    LOG.warning("All retry attempts exhausted.")
    return False


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Delete file of a Copernicus metadata filename.')
    parser.add_argument('filename', type=str,
                        help='Copernicus metadata filename (e.g., field-boundaries-S2A_10SGG_20230426_0_L2A-v1.1.0.geojson).')

    args = parser.parse_args()

    filename = args.filename

    deletion_success = delete_file(filename)
    exit(0 if deletion_success else 1)
