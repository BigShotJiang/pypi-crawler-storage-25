import os
import time
import argparse
import traceback
import json as jsn

from dafab_client._rucio.dafab_lib import upload_manager
from dafab_client.helpers.file_management.Deletion.delete_replica_of_scope_name import delete_replica
from dafab_client.helpers.file_management.Deletion.delete_file_of_scope_name import delete_file
from dafab_client.helpers.metadata_management.Operations.upsert_metadata_for_did import upsert_metadata_for_did
from dafab_client.helpers.runtime_paths import load_json_schema
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


def upload_file(fpath: str, pname: str, scope: str = 'dafab', rse: str = 'MELUXINA_S3'):
    """
    Upload a file to an RSE and register it in Rucio.

    Parameters
    ----------
    fpath : str
        Local filesystem path of the file to upload.
    pname : str
        Product name that will be used as the file's DID name.
    scope : str, optional
        Rucio scope under which the file will be registered, by default ``'dafab'``.
    rse : str, optional
        Name of the Rucio Storage Element where the file will be uploaded, by default ``'MELUXINA_S3'``.

    Notes
    -----
    The function retries failed uploads ``max_retries`` times with a pause of
    ``retry_delay`` seconds between attempts.

    Returns
    -------
    bool
        ``True`` if the upload and registration succeed, ``False`` after all retries are exhausted.
    """
    max_retries = 1
    retry_delay = 30  # seconds

    for attempt in range(max_retries):
        try:
            # Get an uploader connection
            uploader = upload_manager()

            add_success = uploader.upload_file(fpath, pname, scope, rse)
            if add_success:
                LOG.result(f"The file '{fpath}' is now available on Rucio storage and indexed in catalog.\n")
                return True
            else:
                LOG.warning(f"The upload of file '{fpath}' on Rucio storage did not finish normally.\n")
                return False

        except Exception as e:
            LOG.warning(f"Attempt {attempt + 1}/{max_retries}: An unexpected error "
                        f"of type '{type(e).__name__}' occurred "
                        f"while uploading the file '{fpath}' on Rucio storage: {e}\n")

            # Get the full traceback for debugging:
            traceback.print_exc()

            if attempt < max_retries - 1:  # Don't sleep after the last attempt
                LOG.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)

    LOG.warning("All retry attempts exhausted.")
    return False


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Upload file to Rucio storage.')
    parser.add_argument('product_name', type=str,
                        help='Name of the Copernicus product (e.g., S2B_43QDB_20240408_0_L2A).')
    parser.add_argument('filepath',
                        type=str,
                        help='Path of the metadata file being uploaded '
                             '(e.g., "{root_path}/demo-data/generated-metadata/field-boundaries-S2B_43QDB_20240408_0_L2A.geojson").')
    parser.add_argument('metadata_value_path', type=str,
                        help='The path of the value which will be updated.')

    args = parser.parse_args()

    product_name = args.product_name
    filepath = args.filepath
    filename = os.path.basename(filepath)
    metadata_value_path = args.metadata_value_path  # JSON Pointer or legacy comma path (e.g. 'assets,dafab-field-boundaries')

    schema_filename = 'Schema_GCore-FB.json'
    LOG.debug(f"Validating the {filename} content..")

    # Load the metadata schema to validate the generated metadata.
    metadata_schema, metadata_schema_source = load_json_schema(schema_filename)
    # LOG.debug(f"Loaded metadata schema from {metadata_schema_source}:")
    # LOG.debug(jsn.dumps(metadata_schema, indent=2))

    LOG.debug(f"Target path for uploading: {filepath}")
    # Load the metadata content from the generated geojson file.
    with open(filepath, 'r') as file:
        generated_metadata = jsn.load(file)
        # LOG.debug(f"Loaded key-value pairs from {metadata_path}:")
        # LOG.debug(jsn.dumps(generated_metadata, indent=2))

    # validation_success = validate_metadata(filename, generated_metadata, metadata_schema_source, metadata_schema)  # Enable for validation
    # if not validation_success:
    #     exit(1)

    LOG.info("Making sure replica is deregistered from the catalog.")
    r_deletion_success = delete_replica(filename)
    if not r_deletion_success:
        exit(1)

    LOG.info("Making sure file does not exist on the RSE.")
    f_deletion_finished = delete_file(filename)
    if not f_deletion_finished:
        exit(1)

    LOG.info("Uploading the file and registering the corresponding DID and replica.")
    f_upload_success = upload_file(fpath=filepath, pname=product_name)
    if not f_upload_success:
        exit(1)

    LOG.info("Updating the product's existing metadata.")
    metadata_value_to_insert = None
    if "dafab-field-boundaries" in metadata_value_path:
        metadata_value_to_insert = {
            "href": filename,
            "title": "dafab-field-boundaries",
            "description": "Field boundaries in the tile computed by a DaFab system algorithm",
            "type": "GeoJSON"
        }

    metadata_insertion_success = upsert_metadata_for_did(
        product_name=product_name,
        path=metadata_value_path,
        value=metadata_value_to_insert,
    )
    exit(0 if metadata_insertion_success else 1)
