"""High-level workflows for publishing and downloading derived item assets."""

from __future__ import annotations

import mimetypes
import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests
from requests.exceptions import RequestException

from dafab_client.helpers.file_management.Insertion.upload_file_of_scope_name import upload_file
from dafab_client.helpers.file_management.Retrieval.download_file_of_scope_name import download_file
from dafab_client.helpers.file_management.list_files import get_assets
from dafab_client.helpers.metadata_management.Patch.patch_metadata_for_dids import patch_metadata_for_dids
from dafab_client.helpers.metadata_management.Retrieval.Complete.get_metadata_for_scope_name import get_bulk_metadata
from dafab_client._rucio.common.checksum import adler32
from dafab_client._rucio.common.exception import FileReplicaAlreadyExists
from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)

DEFAULT_SCOPE = "dafab"
DEFAULT_STORAGE = "MELUXINA_S3"
DEFAULT_STAC_ROOT = "https://dafab.cern.ch/stac"


def _escape_pointer_token(token: str) -> str:
    return token.replace("~", "~0").replace("/", "~1")


def _asset_pointer(asset_key: str) -> str:
    return f"/assets/{_escape_pointer_token(asset_key)}"


def _unwrap_partial_value(value: Any) -> Any:
    if isinstance(value, dict) and "found" in value and "value" in value:
        if bool(value.get("found")):
            return value.get("value")
        return None
    return value


def _extract_asset_entry(item_id: str, asset_key: str, scope: str) -> dict[str, Any] | None:
    pointer = _asset_pointer(asset_key)
    partial = get_bulk_metadata(item_id, scope=scope, paths=[pointer])
    if isinstance(partial, dict):
        entry = _unwrap_partial_value(partial.get(pointer))
        if isinstance(entry, dict):
            return entry
    return None


def _is_http_url(value: Any) -> bool:
    return isinstance(value, str) and value.startswith(("http://", "https://"))


def _default_asset_title(asset_key: str) -> str:
    return asset_key.replace("_", " ").replace("-", " ").strip().title()


def _guess_media_type(file_name: str) -> str | None:
    guessed, _ = mimetypes.guess_type(file_name)
    return guessed


def _exception_payload_message(payload: bytes) -> str | None:
    if not payload:
        return None
    try:
        parsed = json.loads(payload.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None
    exc_cls = parsed.get("ExceptionClass")
    exc_msg = parsed.get("ExceptionMessage")
    if isinstance(exc_cls, str) and isinstance(exc_msg, str):
        return f"{exc_cls}: {exc_msg}"
    return None


def _attached_file_names(item_id: str, scope: str) -> list[str]:
    attached_assets = get_assets(scope=scope, item=item_id, long=True)
    return sorted(
        str(asset.get("name")).strip()
        for asset in attached_assets
        if isinstance(asset, dict) and isinstance(asset.get("name"), str) and str(asset.get("name")).strip()
    )


def _did_name(entry: Any) -> str | None:
    if isinstance(entry, str):
        name = entry.strip()
        return name or None
    if isinstance(entry, dict):
        name = entry.get("name")
        if isinstance(name, str):
            name = name.strip()
            return name or None
    return None


def _file_did_exists(*, scope: str, file_name: str) -> bool:
    try:
        did = connection_manager().get_did(scope=scope, name=file_name)
    except Exception:
        return False
    return str(did.get("type", "")).upper() == "FILE"


def _storage_names_for_file(*, scope: str, file_name: str) -> tuple[list[str], str | None]:
    try:
        replicas = list(
            connection_manager().list_replicas(
                dids=[{"scope": scope, "name": file_name}],
                ignore_availability=True,
                all_states=True,
            )
        )
    except Exception as exc:
        return [], f"{type(exc).__name__}: {exc}"

    storage_names: set[str] = set()
    for row in replicas:
        if not isinstance(row, dict):
            continue

        rses = row.get("rses")
        if isinstance(rses, dict):
            for rse_name, replicas_for_rse in rses.items():
                if isinstance(rse_name, str) and rse_name.strip() and replicas_for_rse:
                    storage_names.add(rse_name.strip())

        pfns = row.get("pfns")
        if isinstance(pfns, dict):
            for replica_meta in pfns.values():
                if not isinstance(replica_meta, dict):
                    continue
                rse_name = replica_meta.get("rse")
                if isinstance(rse_name, str) and rse_name.strip():
                    storage_names.add(rse_name.strip())

    return sorted(storage_names), None


def _ensure_file_attached_to_item(
        *,
        scope: str,
        item_id: str,
        file_name: str,
) -> tuple[bool, bool, str | None]:
    attached_names = _attached_file_names(item_id, scope)
    if file_name in attached_names:
        return True, False, None

    try:
        connection_manager().attach_dids(
            scope=scope,
            name=item_id,
            dids=[{"scope": scope, "name": file_name}],
        )
    except Exception as exc:
        return False, False, f"{type(exc).__name__}: {exc}"

    attached_names = _attached_file_names(item_id, scope)
    if file_name in attached_names:
        return True, True, None
    return False, True, "attach_call_completed_but_file_not_listed_on_item"


def _file_name_from_metadata_href(value: str) -> str | None:
    href = value.strip()
    if not href:
        return None
    if href.startswith(("http://", "https://")):
        parsed = urlparse(href)
        stable_match = re.search(r"/assets/[^/]+/items/[^/]+/[^/]+/?$", parsed.path or "")
        if stable_match:
            # Stable DaFab asset hrefs terminate with the asset key, not the physical file name.
            return None
        name = Path(parsed.path).name.strip()
        return name or None
    if "/" in href:
        tail = Path(href).name.strip()
        if tail:
            return tail
    if href.lower().startswith("url to "):
        candidate = href[7:].strip()
        return candidate or None
    return href


def _choose_attached_file_name(
        *,
        scope: str,
        item_id: str,
        asset_key: str,
        href: Any,
) -> tuple[str | None, str | None]:
    attached_names = _attached_file_names(item_id, scope)
    if not attached_names:
        return None, "No assets are attached to this item in the catalog."

    href_candidate = _file_name_from_metadata_href(href) if isinstance(href, str) else None
    if href_candidate and href_candidate in attached_names:
        return href_candidate, None

    if len(attached_names) == 1:
        return attached_names[0], None

    key_variants = _asset_key_variants(asset_key)

    for key_variant in key_variants:
        heuristic_matches = [name for name in attached_names if key_variant and key_variant in name.lower()]
        if len(heuristic_matches) == 1:
            return heuristic_matches[0], None

    return None, (
        f"Unable to map asset key '{asset_key}' to one attached file. "
        f"Attached names: {attached_names}"
    )


def _asset_key_variants(asset_key: str) -> set[str]:
    normalized_key = asset_key.replace("_", "-").lower().strip()
    variants = {normalized_key} if normalized_key else set()
    if normalized_key.startswith("dafab-"):
        trimmed = normalized_key[len("dafab-"):].strip()
        if trimmed:
            variants.add(trimmed)
    return variants


def _matches_asset_key(file_name: str, asset_key: str) -> bool:
    lowered_name = file_name.lower()
    return any(variant in lowered_name for variant in _asset_key_variants(asset_key))


def _detach_file_from_item(
        *,
        scope: str,
        item_id: str,
        file_name: str,
) -> tuple[bool, str | None]:
    try:
        connection_manager().detach_dids(
            scope=scope,
            name=item_id,
            dids=[{"scope": scope, "name": file_name}],
        )
        return True, None
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _delete_file_replicas_everywhere(
        *,
        scope: str,
        file_name: str,
) -> dict[str, Any]:
    storage_names, discovery_error = _storage_names_for_file(scope=scope, file_name=file_name)
    deleted_on: list[str] = []
    delete_errors: dict[str, str] = {}
    client = connection_manager()

    for storage_name in storage_names:
        try:
            ok = client.delete_replicas(
                rse=storage_name,
                files=[{"scope": scope, "name": file_name}],
                ignore_availability=True,
            )
            if ok:
                deleted_on.append(storage_name)
            else:
                delete_errors[storage_name] = "delete_replicas returned False"
        except Exception as exc:
            delete_errors[storage_name] = f"{type(exc).__name__}: {exc}"

    return {
        "discovery_error": discovery_error,
        "storage_names": storage_names,
        "deleted_on": deleted_on,
        "delete_errors": delete_errors,
    }


def _metadata_asset_keys(item_id: str, scope: str) -> list[str]:
    metadata = get_bulk_metadata(item_id, scope=scope)
    if not isinstance(metadata, dict):
        return []
    assets = metadata.get("assets")
    if not isinstance(assets, dict):
        return []
    return [key for key in assets.keys() if isinstance(key, str) and key.strip()]


def _upload_via_signed_write_url(
        *,
        scope: str,
        item_id: str,
        src: Path,
        storage_name: str,
        timeout: int = 120,
) -> tuple[bool, dict[str, Any]]:
    file_name = src.name
    did_str = f"{scope}:{file_name}"
    details: dict[str, Any] = {
        "method": "signed_write_url",
        "did": did_str,
        "pfn": None,
        "signed_url_length": None,
        "http_status_code": None,
        "replica_registered": False,
        "attach_error": None,
        "error": None,
    }

    try:
        client = connection_manager()
        pfn_map = client.lfns2pfns(
            rse=storage_name,
            lfns=[did_str],
            protocol_domain="wan",
            operation="write",
            scheme="https",
        )
        pfn = pfn_map.get(did_str)
        if not isinstance(pfn, str) or not pfn.strip():
            details["error"] = f"Unable to resolve PFN for {did_str} on {storage_name}."
            return False, details
        details["pfn"] = pfn

        rse_info = client.get_rse(storage_name)
        sign_service = str(rse_info.get("sign_url") or "s3")
        signed_url = client.get_signed_url(storage_name, sign_service, "write", pfn)
        details["signed_url_length"] = len(signed_url)

        with src.open("rb") as handle:
            put_response = requests.put(signed_url, data=handle, timeout=timeout)
        details["http_status_code"] = put_response.status_code
        if put_response.status_code not in {200, 201, 204}:
            details["error"] = (
                f"Signed upload failed with HTTP {put_response.status_code}: "
                f"{put_response.text[:200]}"
            )
            return False, details

        replica_payload = {
            "scope": scope,
            "name": file_name,
            "bytes": src.stat().st_size,
            "adler32": adler32(str(src)),
        }
        try:
            client.add_replicas(
                rse=storage_name,
                files=[replica_payload],
                ignore_availability=True,
            )
        except FileReplicaAlreadyExists:
            pass
        details["replica_registered"] = True

        attached, _changed, attach_error = _ensure_file_attached_to_item(
            scope=scope,
            item_id=item_id,
            file_name=file_name,
        )
        if not attached:
            details["attach_error"] = attach_error or "Attach call did not make file visible on item."
            details["error"] = details["attach_error"]
            return False, details
        return True, details
    except Exception as exc:
        details["error"] = f"{type(exc).__name__}: {exc}"
        return False, details


def _derived_item_guard(item_id: str, scope: str) -> tuple[bool, str]:
    metadata = get_bulk_metadata(item_id, scope=scope)
    if not isinstance(metadata, dict):
        return False, "Unable to load item metadata from the catalog."

    links = metadata.get("links")
    if not isinstance(links, list):
        return False, "Item metadata has no links array."

    has_derived_from = any(
        isinstance(link, dict)
        and str(link.get("rel", "")).strip() == "derived_from"
        and isinstance(link.get("href"), str)
        and str(link.get("href")).strip()
        for link in links
    )
    if not has_derived_from:
        return False, "Requested item is not a derived item (`derived_from` link is missing)."
    return True, ""


def list_derived_items_with_missing_assets(
        *,
        stac_namespace: str = DEFAULT_SCOPE,
        filters: Any = None,
        limit: int | None = None,
) -> dict[str, Any]:
    """List derived items whose metadata references at least one unavailable asset file."""
    client = connection_manager()
    all_items = list(
        client.list_dids(
            scope=stac_namespace,
            filters=filters if filters is not None else [{"name": "*"}],
            did_type="dataset",
            long=False,
            recursive=False,
        )
    )

    results: list[dict[str, Any]] = []
    scanned = 0
    for item in all_items:
        name = _did_name(item)
        if not name:
            continue
        scanned += 1

        metadata = get_bulk_metadata(name, scope=stac_namespace)
        if not isinstance(metadata, dict):
            continue
        links = metadata.get("links")
        if not isinstance(links, list):
            continue
        has_derived_from = any(
            isinstance(link, dict)
            and str(link.get("rel", "")).strip() == "derived_from"
            and isinstance(link.get("href"), str)
            and str(link.get("href")).strip()
            for link in links
        )
        if not has_derived_from:
            continue

        assets = metadata.get("assets")
        if not isinstance(assets, dict):
            results.append(
                {
                    "item_id": name,
                    "missing_assets": [
                        {
                            "asset_key": None,
                            "href": None,
                            "resolved_file_name": None,
                            "reason": "assets_block_missing_or_invalid",
                        }
                    ],
                }
            )
            if limit is not None and len(results) >= limit:
                break
            continue

        attached = set(_attached_file_names(name, stac_namespace))
        missing_assets: list[dict[str, Any]] = []
        for asset_key in sorted(assets.keys()):
            entry = assets.get(asset_key)
            if not isinstance(entry, dict):
                missing_assets.append(
                    {
                        "asset_key": asset_key,
                        "href": None,
                        "resolved_file_name": None,
                        "reason": "asset_entry_not_object",
                    }
                )
                continue

            href = entry.get("href")
            if not isinstance(href, str) or not href.strip():
                missing_assets.append(
                    {
                        "asset_key": asset_key,
                        "href": href,
                        "resolved_file_name": None,
                        "reason": "asset_href_missing_or_unusable",
                    }
                )
                continue

            resolved_name, resolve_error = _choose_attached_file_name(
                scope=stac_namespace,
                item_id=name,
                asset_key=asset_key,
                href=href,
            )
            if not resolved_name:
                missing_assets.append(
                    {
                        "asset_key": asset_key,
                        "href": href,
                        "resolved_file_name": None,
                        "reason": resolve_error or "unable_to_resolve_asset_to_attached_file",
                    }
                )
                continue

            if resolved_name not in attached:
                missing_assets.append(
                    {
                        "asset_key": asset_key,
                        "href": href,
                        "resolved_file_name": resolved_name,
                        "reason": "file_not_attached_to_item",
                    }
                )

        if missing_assets:
            results.append(
                {
                    "item_id": name,
                    "missing_assets": missing_assets,
                }
            )
            if limit is not None and len(results) >= limit:
                break

    return {
        "stac_namespace": stac_namespace,
        "datasets_scanned": scanned,
        "items_with_missing_assets": len(results),
        "results": results,
    }


def list_available_asset_files(
        *,
        stac_namespace: str = DEFAULT_SCOPE,
        item_id: str | None = None,
        filters: Any = None,
        limit: int | None = None,
) -> dict[str, Any]:
    """List available file assets in a scope or for one item."""
    if item_id is not None:
        item_report = list_item_asset_entries(
            item_id=item_id,
            stac_namespace=stac_namespace,
            check_storage=True,
        )
        if item_report.get("error"):
            return {
                "stac_namespace": stac_namespace,
                "item_id": item_id,
                "error": item_report.get("error"),
                "results": [],
            }

        results: list[dict[str, Any]] = []
        for entry in item_report.get("asset_entries", []):
            if not isinstance(entry, dict):
                continue
            row: dict[str, Any] = {
                "asset_key": entry.get("asset_key"),
                "href": entry.get("href"),
                "resolved_file_name": entry.get("resolved_file_name"),
                "is_dafab_asset": bool(entry.get("is_dafab_asset")),
                "available_on_storage": bool(entry.get("available_on_storage")),
                "storage_names": entry.get("storage_names", []),
            }
            if entry.get("reason"):
                row["reason"] = entry.get("reason")
            elif entry.get("resolution_error"):
                row["reason"] = entry.get("resolution_error")
            if entry.get("storage_error"):
                row["storage_error"] = entry.get("storage_error")
            results.append(row)

        if limit is not None:
            results = results[:limit]

        return {
            "stac_namespace": stac_namespace,
            "item_id": item_id,
            "metadata_asset_count": item_report.get("metadata_asset_count", 0),
            "dafab_assets_detected": item_report.get("dafab_assets_detected", 0),
            "available_on_storage_count": item_report.get("available_on_storage_count", 0),
            "results": results,
        }

    discovery_error: str | None = None
    try:
        files = get_assets(scope=stac_namespace, filters=filters, long=False)
    except Exception as exc:
        files = []
        discovery_error = f"{type(exc).__name__}: {exc}"
    names = {
        name
        for entry in files
        for name in [_did_name(entry)]
        if name
    }

    discovery_mode = "scope_file_query"
    if not names:
        discovery_mode = "dataset_attachment_scan"
        try:
            client = connection_manager()
            datasets = list(
                client.list_dids(
                    scope=stac_namespace,
                    filters=[{"name": "*"}],
                    did_type="dataset",
                    long=False,
                    recursive=False,
                )
            )
            for row in datasets:
                item_id = _did_name(row)
                if not item_id:
                    continue
                attached_files = get_assets(scope=stac_namespace, item=item_id, long=False)
                for entry in attached_files:
                    name = entry.get("name") if isinstance(entry, dict) else None
                    if isinstance(name, str) and name.strip():
                        names.add(name.strip())
        except Exception as exc:
            if discovery_error is None:
                discovery_error = f"{type(exc).__name__}: {exc}"
            else:
                discovery_error = f"{discovery_error} | fallback: {type(exc).__name__}: {exc}"

    sorted_names = sorted(names)
    if limit is not None:
        sorted_names = sorted_names[:limit]
    return {
        "stac_namespace": stac_namespace,
        "discovery_mode": discovery_mode,
        "total_asset_files": len(names),
        "returned_asset_files": len(sorted_names),
        "asset_file_names": sorted_names,
        "error": discovery_error,
    }


def list_item_asset_entries(
        item_id: str,
        *,
        stac_namespace: str = DEFAULT_SCOPE,
        check_storage: bool = False,
) -> dict[str, Any]:
    """List metadata asset entries for one item.

    When ``check_storage`` is enabled, each entry also reports whether the
    resolved file DID exists and on which storage endpoints replicas are found.

    Args:
        item_id: Item identifier whose ``assets`` block should be inspected.
        stac_namespace: Scope where metadata and file DIDs are resolved.
        check_storage: Enable replica discovery per resolved file DID.

    Returns:
        dict[str, Any]: Structured report containing one row per metadata asset.
    """
    metadata = get_bulk_metadata(item_id, scope=stac_namespace)
    if not isinstance(metadata, dict):
        return {
            "stac_namespace": stac_namespace,
            "item_id": item_id,
            "error": "Unable to load item metadata.",
            "asset_entries": [],
        }

    assets = metadata.get("assets")
    if not isinstance(assets, dict):
        return {
            "stac_namespace": stac_namespace,
            "item_id": item_id,
            "asset_entries": [],
            "metadata_asset_count": 0,
            "attached_asset_count": len(_attached_file_names(item_id, stac_namespace)),
            "storage_check_enabled": bool(check_storage),
        }

    attached_names = set(_attached_file_names(item_id, stac_namespace))
    entries: list[dict[str, Any]] = []
    for asset_key in sorted(assets.keys()):
        entry = assets.get(asset_key)
        if not isinstance(entry, dict):
            entries.append(
                {
                    "asset_key": asset_key,
                    "href": None,
                    "resolved_file_name": None,
                    "available_on_server": False,
                    "reason": "asset_entry_not_object",
                }
            )
            continue

        href = entry.get("href")
        resolved_name = None
        resolve_error = None
        if isinstance(href, str) and href.strip():
            resolved_name, resolve_error = _choose_attached_file_name(
                scope=stac_namespace,
                item_id=item_id,
                asset_key=asset_key,
                href=href,
            )
        row: dict[str, Any] = {
            "asset_key": asset_key,
            "href": href,
            "title": entry.get("title"),
            "type": entry.get("type"),
            "resolved_file_name": resolved_name,
            "available_on_server": bool(resolved_name and resolved_name in attached_names),
            "resolution_error": resolve_error,
        }
        if not isinstance(href, str) or not href.strip():
            row["reason"] = "asset_href_missing_or_unusable"

        if check_storage:
            is_dafab_asset = bool(resolved_name) and _file_did_exists(scope=stac_namespace, file_name=resolved_name)
            storage_names: list[str] = []
            storage_error: str | None = None
            if is_dafab_asset and resolved_name:
                storage_names, storage_error = _storage_names_for_file(
                    scope=stac_namespace,
                    file_name=resolved_name,
                )
            row["is_dafab_asset"] = is_dafab_asset
            row["available_on_storage"] = bool(storage_names)
            row["storage_names"] = storage_names
            if storage_error is not None:
                row["storage_error"] = storage_error
            if resolved_name and not is_dafab_asset:
                row["reason"] = "no_file_record_found_in_stac_namespace"
            if not resolved_name and not row.get("reason"):
                row["reason"] = resolve_error or "unable_to_resolve_asset_to_attached_file"

        entries.append(row)
    result = {
        "stac_namespace": stac_namespace,
        "item_id": item_id,
        "storage_check_enabled": bool(check_storage),
        "metadata_asset_count": len(entries),
        "attached_asset_count": len(attached_names),
        "asset_entries": entries,
    }
    if check_storage:
        result["dafab_assets_detected"] = sum(1 for row in entries if bool(row.get("is_dafab_asset")))
        result["available_on_storage_count"] = sum(1 for row in entries if bool(row.get("available_on_storage")))
    return result


def build_stable_asset_href(
        item_id: str,
        asset_key: str,
        *,
        scope: str = DEFAULT_SCOPE,
        stac_root_href: str = DEFAULT_STAC_ROOT,
) -> str:
    """Build the canonical stable asset URL stored in STAC metadata.

    Args:
        item_id: Target item identifier.
        asset_key: Asset key inside the metadata ``assets`` block.
        scope: Scope segment embedded in the stable URL.
        stac_root_href: STAC root URL prefix.

    Returns:
        str: Stable asset URL of the form ``<root>/assets/<scope>/items/<item>/<asset_key>``.
    """
    root = stac_root_href.rstrip("/")
    return f"{root}/assets/{scope}/items/{item_id}/{asset_key}"


def publish_derived_asset(
        derived_item_id: str,
        asset_path: str | Path,
        asset_key: str,
        *,
        overwrite: bool = False,
        scope: str = DEFAULT_SCOPE,
        storage_name: str = DEFAULT_STORAGE,
        stac_root_href: str = DEFAULT_STAC_ROOT,
        asset_title: str | None = None,
        asset_type: str | None = None,
        upload_timeout: int = 120,
) -> dict[str, Any]:
    """Upload an asset file, attach it to a derived item, and upsert stable asset metadata.

    Args:
        derived_item_id: Target derived item identifier.
        asset_path: Local path to the asset file to upload.
        asset_key: Key under metadata ``assets`` where this asset should be stored.
        overwrite: Replace existing metadata entry for ``assets.<asset_key>`` when present. When set to
            ``True``, stale file attachments matching the same asset type are detached and their replicas are
            removed from all discovered storage endpoints.
        scope: Catalog scope containing the target item.
        storage_name: Storage endpoint used for upload.
        stac_root_href: STAC root URL used to construct stable asset hrefs.
        asset_title: Optional title override stored in asset metadata.
        asset_type: Optional media type override stored in asset metadata.
        upload_timeout: Timeout in seconds for the signed-url upload request.

    Returns:
        dict[str, Any]: Compact status report for upload, metadata patch, and verification.
    """
    if not isinstance(derived_item_id, str) or not derived_item_id.strip():
        raise ValueError("'derived_item_id' must be a non-empty string.")
    if not isinstance(asset_key, str) or not asset_key.strip():
        raise ValueError("'asset_key' must be a non-empty string.")

    src = Path(asset_path).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Asset file not found: {src}")

    stable_href = build_stable_asset_href(
        derived_item_id.strip(),
        asset_key.strip(),
        scope=scope,
        stac_root_href=stac_root_href,
    )

    file_name = src.name
    existing_entry = _extract_asset_entry(derived_item_id, asset_key, scope)
    existing_href = existing_entry.get("href") if isinstance(existing_entry, dict) else None
    should_patch = overwrite or not isinstance(existing_entry, dict)

    upload_method = "signed_write_url"
    upload_ok, upload_details = _upload_via_signed_write_url(
        scope=scope,
        item_id=derived_item_id.strip(),
        src=src,
        storage_name=storage_name,
        timeout=upload_timeout,
    )

    if not upload_ok:
        upload_method = "legacy_upload_client"
        upload_ok = upload_file(
            fpath=str(src),
            pname=derived_item_id.strip(),
            scope=scope,
            rse=storage_name,
        )
        upload_details["legacy_upload_ok"] = bool(upload_ok)

    attached_before_fallback = _attached_file_names(derived_item_id.strip(), scope)
    attachment_present = file_name in attached_before_fallback

    attach_fallback_attempted = False
    attach_fallback_applied = False
    attach_fallback_error: str | None = None
    if not attachment_present and _file_did_exists(scope=scope, file_name=file_name):
        attach_fallback_attempted = True
        attachment_present, attach_fallback_applied, attach_fallback_error = _ensure_file_attached_to_item(
            scope=scope,
            item_id=derived_item_id.strip(),
            file_name=file_name,
        )

    effective_upload_ok = bool(upload_ok or attachment_present)

    metadata_updated = False
    patch_result: dict[str, Any] | None = None
    if effective_upload_ok and should_patch:
        payload: dict[str, Any] = {"href": stable_href}
        effective_title = asset_title or (existing_entry or {}).get("title") if isinstance(existing_entry, dict) else asset_title
        if not effective_title:
            effective_title = _default_asset_title(asset_key)
        payload["title"] = effective_title

        effective_type = asset_type or (existing_entry or {}).get("type") if isinstance(existing_entry, dict) else asset_type
        if not effective_type:
            effective_type = _guess_media_type(file_name)
        if effective_type:
            payload["type"] = effective_type

        patch_result = patch_metadata_for_dids(
            product_names=[derived_item_id.strip()],
            op="upsert",
            path=_asset_pointer(asset_key),
            value=payload,
            scope=scope,
            mode="atomic",
        )
        metadata_updated = True

    attached_names = _attached_file_names(derived_item_id.strip(), scope)
    attachment_present = file_name in attached_names

    final_entry = _extract_asset_entry(derived_item_id, asset_key, scope)
    final_href = final_entry.get("href") if isinstance(final_entry, dict) else None
    metadata_href_matches = final_href == stable_href

    pruned_files: list[dict[str, Any]] = []
    prune_skipped_reason: str | None = None
    if overwrite:
        if not (effective_upload_ok and metadata_href_matches and attachment_present):
            prune_skipped_reason = "prune_requires_successful_upload_attachment_and_metadata_match"
        else:
            stale_files = [
                attached_name
                for attached_name in sorted(attached_names)
                if attached_name != file_name and _matches_asset_key(attached_name, asset_key)
            ]
            if not stale_files:
                # When the item only exposes one metadata asset key (the target one),
                # any other attached file is stale for this publish operation.
                metadata_asset_keys = _metadata_asset_keys(derived_item_id.strip(), scope)
                if len(metadata_asset_keys) == 1 and metadata_asset_keys[0] == asset_key:
                    stale_files = [
                        attached_name
                        for attached_name in sorted(attached_names)
                        if attached_name != file_name
                    ]
            for stale_file in stale_files:
                detached, detach_error = _detach_file_from_item(
                    scope=scope,
                    item_id=derived_item_id.strip(),
                    file_name=stale_file,
                )
                prune_entry: dict[str, Any] = {
                    "file_name": stale_file,
                    "detached": detached,
                    "detach_error": detach_error,
                    "replicas_deleted": None,
                }
                if detached:
                    prune_entry["replicas_deleted"] = _delete_file_replicas_everywhere(
                        scope=scope,
                        file_name=stale_file,
                    )
                pruned_files.append(prune_entry)

    return {
        "scope": scope,
        "item_id": derived_item_id.strip(),
        "asset_key": asset_key.strip(),
        "asset_file_name": file_name,
        "stable_href": stable_href,
        "upload_method": upload_method,
        "upload_details": upload_details,
        "upload_ok": bool(upload_ok),
        "effective_upload_ok": effective_upload_ok,
        "metadata_updated": metadata_updated,
        "metadata_update_skipped_reason": None if should_patch else "asset_entry_exists_and_overwrite_false",
        "existing_href": existing_href,
        "metadata_href": final_href,
        "metadata_href_matches_expected": metadata_href_matches,
        "attach_fallback_attempted": attach_fallback_attempted,
        "attach_fallback_applied": attach_fallback_applied,
        "attach_fallback_error": attach_fallback_error,
        "attachment_present_on_item": attachment_present,
        "attached_asset_count": len(attached_names),
        "prune_enabled": overwrite,
        "prune_skipped_reason": prune_skipped_reason,
        "pruned_files": pruned_files,
        "patch_result": patch_result,
    }


def download_asset_from_stable_href(
        stable_href: str,
        *,
        destination_dir: str | Path = ".",
        file_name: str | None = None,
        overwrite: bool = False,
        timeout: int = 120,
        verify_tls: bool = False,
) -> dict[str, Any]:
    """Download one asset from a stable STAC URL.

    The URL is fetched via HTTP(S) with redirects enabled. If ``file_name`` is
    omitted, the final redirected URL path tail is used.

    Args:
        stable_href: Stable asset URL.
        destination_dir: Target directory for the downloaded file.
        file_name: Optional output filename override.
        overwrite: Allow replacing an existing local file.
        timeout: Request timeout in seconds.
        verify_tls: Enable/disable TLS certificate verification.

    Returns:
        dict[str, Any]: Download status payload (success or structured error).
    """
    if not _is_http_url(stable_href):
        raise ValueError("'stable_href' must be an absolute HTTP(S) URL.")

    target_dir = Path(destination_dir).expanduser().resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    response = requests.get(
        stable_href,
        allow_redirects=True,
        stream=True,
        timeout=timeout,
        verify=verify_tls,
    )
    response.raise_for_status()

    inferred_name = file_name
    if not inferred_name:
        parsed = urlparse(response.url)
        inferred_name = Path(parsed.path).name or "asset.bin"
    destination = target_dir / inferred_name
    if destination.exists() and not overwrite:
        raise FileExistsError(f"Target file already exists: {destination}")

    bytes_written = 0
    chunk_iterator = response.iter_content(chunk_size=1024 * 1024)
    first_chunk = next(chunk_iterator, b"")
    exception_message = _exception_payload_message(first_chunk)
    if exception_message is not None:
        return {
            "ok": False,
            "stable_href": stable_href,
            "final_url": response.url,
            "status_code": response.status_code,
            "error": exception_message,
            "verify_tls": bool(verify_tls),
        }

    with destination.open("wb") as handle:
        if first_chunk:
            handle.write(first_chunk)
            bytes_written += len(first_chunk)
        for chunk in chunk_iterator:
            if chunk:
                handle.write(chunk)
                bytes_written += len(chunk)

    return {
        "ok": True,
        "stable_href": stable_href,
        "final_url": response.url,
        "status_code": response.status_code,
        "download_path": str(destination),
        "bytes_written": bytes_written,
        "verify_tls": bool(verify_tls),
    }


def download_item_asset(
        item_id: str,
        asset_key: str,
        *,
        scope: str = DEFAULT_SCOPE,
        destination_dir: str | Path = ".",
        storage_name: str = DEFAULT_STORAGE,
        overwrite: bool = False,
        timeout: int = 120,
        verify_tls: bool = False,
) -> dict[str, Any]:
    """Download one asset for an item using metadata-driven resolution.

    Resolution strategy:
    - If metadata ``href`` is an HTTP(S) URL, download via stable-URL flow.
    - Otherwise resolve the attached file name and download via catalog storage.

    Args:
        item_id: Item identifier.
        asset_key: Asset key in ``assets``.
        scope: Scope used to resolve metadata and file DIDs.
        destination_dir: Target directory for downloaded content.
        storage_name: Storage endpoint used for catalog file downloads.
        overwrite: Allow replacing existing local files.
        timeout: Request timeout for URL-based downloads.
        verify_tls: Enable/disable TLS verification for URL-based downloads.

    Returns:
        dict[str, Any]: Download status payload (success or structured error).
    """
    entry = _extract_asset_entry(item_id, asset_key, scope)
    if not isinstance(entry, dict):
        return {
            "ok": False,
            "scope": scope,
            "item_id": item_id,
            "asset_key": asset_key,
            "error": "Asset entry not found in metadata.",
        }

    href = entry.get("href")
    stable_url_error: str | None = None
    if _is_http_url(href):
        try:
            result = download_asset_from_stable_href(
                str(href),
                destination_dir=destination_dir,
                overwrite=overwrite,
                timeout=timeout,
                verify_tls=verify_tls,
            )
            result["mode"] = "stable_url"
            result["scope"] = scope
            result["item_id"] = item_id
            result["asset_key"] = asset_key
            return result
        except RequestException as exc:
            stable_url_error = f"{type(exc).__name__}: {exc}"

    if not isinstance(href, str) or not href.strip():
        return {
            "ok": False,
            "scope": scope,
            "item_id": item_id,
            "asset_key": asset_key,
            "error": "Asset href is empty or invalid.",
            "stable_url_error": stable_url_error,
        }

    resolved_file_name, resolve_error = _choose_attached_file_name(
        scope=scope,
        item_id=item_id,
        asset_key=asset_key,
        href=href,
    )
    if not resolved_file_name:
        return {
            "ok": False,
            "scope": scope,
            "item_id": item_id,
            "asset_key": asset_key,
            "href": href.strip(),
            "error": resolve_error,
            "stable_url_error": stable_url_error,
        }

    target_dir = Path(destination_dir).expanduser().resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    destination = target_dir / resolved_file_name
    if destination.exists() and not overwrite:
        raise FileExistsError(f"Target file already exists: {destination}")

    ok = download_file(
        fname=resolved_file_name,
        store_dir=str(target_dir),
        scope=scope,
        rse=storage_name,
    )
    return {
        "ok": bool(ok),
        "mode": "catalog_file_name",
        "scope": scope,
        "item_id": item_id,
        "asset_key": asset_key,
        "href": href.strip(),
        "resolved_file_name": resolved_file_name,
        "stable_url_error": stable_url_error,
        "verify_tls": bool(verify_tls),
        "download_path": str(destination),
    }


def download_all_derived_item_assets(
        item_id: str,
        *,
        scope: str = DEFAULT_SCOPE,
        destination_dir: str | Path = ".",
        storage_name: str = DEFAULT_STORAGE,
        overwrite: bool = False,
        timeout: int = 120,
        verify_tls: bool = False,
) -> dict[str, Any]:
    """Download every metadata asset for a derived item.

    The helper first verifies that the item is derived (``rel=derived_from``),
    then delegates each asset to :func:`download_item_asset`.

    Args:
        item_id: Derived item identifier.
        scope: Scope used to resolve metadata and file DIDs.
        destination_dir: Target directory for downloaded files.
        storage_name: Storage endpoint used for catalog file downloads.
        overwrite: Allow replacing existing local files.
        timeout: Request timeout for URL-based downloads.
        verify_tls: Enable/disable TLS verification for URL-based downloads.

    Returns:
        dict[str, Any]: Aggregate status with per-asset download results.
    """
    is_derived, reason = _derived_item_guard(item_id, scope)
    if not is_derived:
        return {
            "ok": False,
            "scope": scope,
            "item_id": item_id,
            "error": reason,
        }

    metadata = get_bulk_metadata(item_id, scope=scope)
    assets = metadata.get("assets") if isinstance(metadata, dict) else None
    if not isinstance(assets, dict):
        return {
            "ok": False,
            "scope": scope,
            "item_id": item_id,
            "error": "Derived item has no assets object in metadata.",
        }

    results = []
    for asset_key in sorted(assets.keys()):
        try:
            result = download_item_asset(
                item_id=item_id,
                asset_key=asset_key,
                scope=scope,
                destination_dir=destination_dir,
                storage_name=storage_name,
                overwrite=overwrite,
                timeout=timeout,
                verify_tls=verify_tls,
            )
        except Exception as exc:
            result = {
                "ok": False,
                "scope": scope,
                "item_id": item_id,
                "asset_key": asset_key,
                "error": f"{type(exc).__name__}: {exc}",
            }
        results.append(result)

    ok_count = sum(1 for row in results if row.get("ok") is True)
    return {
        "ok": ok_count == len(results),
        "scope": scope,
        "item_id": item_id,
        "assets_total": len(results),
        "assets_downloaded": ok_count,
        "assets_failed": len(results) - ok_count,
        "results": results,
    }
