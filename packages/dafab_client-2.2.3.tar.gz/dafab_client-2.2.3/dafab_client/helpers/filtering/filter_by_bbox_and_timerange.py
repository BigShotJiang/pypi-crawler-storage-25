import argparse
from typing import Any, List, Literal, Sequence

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger
from dafab_client._rucio.common.filter import create_aoi_date_filter

LOG = setup_logger(__name__)
DEFAULT_STAC_SCOPE = "dafab"


def _validate_bbox(bbox: Sequence[float]) -> List[float]:
    if len(bbox) != 4:
        raise ValueError("Bounding box must contain exactly four coordinates [min_long, min_lat, max_long, max_lat].")
    return [float(coord) for coord in bbox]


def _validate_timerange(timerange: Sequence[str]) -> List[str]:
    if len(timerange) != 2:
        raise ValueError("Timerange must contain exactly two ISO 8601 date strings [start_date, end_date].")
    return [str(timerange[0]), str(timerange[1])]


def _fetch_items_by_bbox_and_timerange(
        bbox: Sequence[float],
        timerange: Sequence[str],
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    min_long, min_lat, max_long, max_lat = _validate_bbox(bbox)
    start_date, end_date = _validate_timerange(timerange)

    payload = {
        "scope": scope,
        "filter": create_aoi_date_filter(
            dt_start=start_date,
            dt_end=end_date,
            min_long=min_long,
            min_lat=min_lat,
            max_long=max_long,
            max_lat=max_lat,
            time_field=time_field,
        ).to_dict()
    }
    LOG.debug("Filter payload: %s", payload)

    items = list(connection_manager().stac_filter(payload))

    if not items:
        return []

    return items[0]["items"]


def _print_cli_rows(rows: List[Any], *, return_mode: Literal["ids", "metadata"], context_label: str) -> None:
    if not rows:
        LOG.info("No items found within the provided %s.", context_label)
        return

    if return_mode == "ids":
        for item_id in rows:
            print(item_id)
    else:
        for item in rows:
            print(f"{item['id']}: {dict(item)}")

    LOG.info("Found %s items within the provided %s.", len(rows), context_label)


def get_item_metadata_by_bbox_and_timerange(
        bbox: Sequence[float],
        timerange: Sequence[str],
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    """Return full item metadata for objects matching spatial+temporal constraints.

    Args:
        bbox: Bounding box ``[min_long, min_lat, max_long, max_lat]``.
        timerange: Temporal interval ``[start_date, end_date]`` in ISO-8601 format.
        time_field: Metadata timestamp field used by the temporal predicate.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        List[Any]: Matching item metadata objects. Empty list on errors/no matches.
    """
    min_long, min_lat, max_long, max_lat = _validate_bbox(bbox)
    start_date, end_date = _validate_timerange(timerange)

    try:
        items = _fetch_items_by_bbox_and_timerange(bbox, timerange, time_field=time_field, scope=scope)
        return items

    except Exception:  # pragma: no cover - logging path
        LOG.exception(
            "An error occurred while filtering items within the bounding box (%s, %s, %s, %s) and timerange %s to %s:",
            min_long,
            min_lat,
            max_long,
            max_lat,
            start_date,
            end_date,
        )
        return []


def get_item_ids_by_bbox_and_timerange(
        bbox: Sequence[float],
        timerange: Sequence[str],
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    """Return item ids for objects matching spatial+temporal constraints.

    Args:
        bbox: Bounding box ``[min_long, min_lat, max_long, max_lat]``.
        timerange: Temporal interval ``[start_date, end_date]`` in ISO-8601 format.
        time_field: Metadata timestamp field used by the temporal predicate.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        List[Any]: Matching item ids. Empty list on errors/no matches.
    """
    min_long, min_lat, max_long, max_lat = _validate_bbox(bbox)
    start_date, end_date = _validate_timerange(timerange)

    try:
        items = _fetch_items_by_bbox_and_timerange(bbox, timerange, time_field=time_field, scope=scope)
        return [item["id"] for item in items]

    except Exception:  # pragma: no cover - logging path
        LOG.exception(
            "An error occurred while filtering items within the bounding box (%s, %s, %s, %s) and timerange %s to %s:",
            min_long,
            min_lat,
            max_long,
            max_lat,
            start_date,
            end_date,
        )
        return []


def get_items_by_bbox_and_timerange(
        bbox: Sequence[float],
        timerange: Sequence[str],
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
        return_mode: Literal["ids", "metadata"] = "ids",
) -> List[Any]:
    """Dispatch spatial+temporal filtering and return either ids or metadata.

    Args:
        bbox: Bounding box ``[min_long, min_lat, max_long, max_lat]``.
        timerange: Temporal interval ``[start_date, end_date]`` in ISO-8601 format.
        time_field: Metadata timestamp field used by the temporal predicate.
        scope: STAC namespace automatically attached to the request payload.
        return_mode: ``ids`` for identifiers, ``metadata`` for full item payloads.

    Returns:
        List[Any]: Filter results in the requested representation.
    """
    if return_mode == "ids":
        return get_item_ids_by_bbox_and_timerange(bbox, timerange, time_field=time_field, scope=scope)
    if return_mode == "metadata":
        return get_item_metadata_by_bbox_and_timerange(bbox, timerange, time_field=time_field, scope=scope)
    raise ValueError(f"Unsupported return_mode: {return_mode}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Filter items by bbox and datetime range (Q3: bbox+time).")
    parser.add_argument("bbox_min_long", type=float, help="bbox min longitude")
    parser.add_argument("bbox_min_lat", type=float, help="bbox min latitude")
    parser.add_argument("bbox_max_long", type=float, help="bbox max longitude")
    parser.add_argument("bbox_max_lat", type=float, help="bbox max latitude")
    parser.add_argument("datetime_start", type=str, help="Starting datetime (ISO 8601).")
    parser.add_argument("datetime_end", type=str, help="Ending datetime (ISO 8601).")
    parser.add_argument(
        "--time-field",
        choices=("datetime", "created"),
        default="datetime",
        help="Temporal field under properties used by date filters.",
    )
    parser.add_argument(
        "--return-mode",
        choices=("ids", "metadata"),
        default="ids",
        help="Return ids (default) or full item metadata.",
    )
    args = parser.parse_args()

    rows = get_items_by_bbox_and_timerange(
        [args.bbox_min_long, args.bbox_min_lat, args.bbox_max_long, args.bbox_max_lat],
        [args.datetime_start, args.datetime_end],
        time_field=args.time_field,
        return_mode=args.return_mode,
    )
    _print_cli_rows(rows, return_mode=args.return_mode, context_label="bounding box and timerange")
    raise SystemExit(0)
