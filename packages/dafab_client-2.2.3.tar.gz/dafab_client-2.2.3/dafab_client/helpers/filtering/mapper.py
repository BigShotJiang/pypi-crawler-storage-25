# mapper.py

import os
import tempfile
from pathlib import Path

import folium
from folium.features import DivIcon
from folium.plugins import MousePosition
from dafab_client.helpers.runtime_paths import get_default_bbox_map_output_path


def _default_cartopy_data_dir() -> Path:
    return Path(tempfile.gettempdir()) / "dafab-cartopy-data"


def _default_xdg_data_home() -> Path:
    return Path(tempfile.gettempdir()) / "dafab-xdg-data-home"


# Keep cartopy data/cache in writable locations for local and packaged runs.
if "CARTOPY_DATA_DIR" not in os.environ:
    os.environ["CARTOPY_DATA_DIR"] = str(_default_cartopy_data_dir())
if "XDG_DATA_HOME" not in os.environ:
    os.environ["XDG_DATA_HOME"] = str(_default_xdg_data_home())


def get_map(
    metadata_batch,
    *,
    draw_ids=True,
    output_path: str | Path | None = None,
):
    """
    Draw an interactive world map with STAC-style bounding boxes and a lat/lon grid.

    Parameters
    ----------
    metadata_batch : list[dict]
        Each dict should contain:
          - "bbox": [min_lon, min_lat, max_lon, max_lat]  (STAC: [west, south, east, north])
          - "id":   string identifier for annotation

        Extra keys are ignored.
    draw_ids : bool, optional
        Whether to show IDs as polygon tooltips/popups and center labels.

    output_path : str | pathlib.Path | None, optional
        Target HTML file. When omitted, the map is stored at
        ``./demo-data/filters/bbox_map.html`` (or under ``$DAFAB_DEMO_DATA_DIR``).

    Behavior
    --------
    - Creates a world map.
    - Draws each bbox as a rectangle and annotates its center with the 'id'.
    - Adds a simple latitude/longitude grid (graticule) over the whole world.
    - Adds a mouse-position tool that shows coordinates under the cursor.
    - Saves the map to HTML.
    - Returns the folium.Map object (in case you want to tweak or inspect it).
    """

    # Base world map (we will fit to bounds later if we have any bboxes)
    fmap = folium.Map(location=[0.0, 0.0], zoom_start=2, tiles="OpenStreetMap")

    all_lats = []
    all_lons = []

    # Draw each bbox and label it with its id
    for item in metadata_batch:
        bbox = item.get("bbox")
        item_id = item.get("id", "")

        if not bbox or len(bbox) != 4:
            # Skip malformed entries
            continue

        min_lon, min_lat, max_lon, max_lat = bbox  # STAC: [west, south, east, north]

        # Track extents so we can fit the map nicely around all boxes
        all_lats.extend([min_lat, max_lat])
        all_lons.extend([min_lon, max_lon])

        # Rectangle coordinates (folium expects [lat, lon])
        corners = [
            [min_lat, min_lon],  # south-west
            [min_lat, max_lon],  # south-east
            [max_lat, max_lon],  # north-east
            [max_lat, min_lon],  # north-west
            [min_lat, min_lon],  # close polygon
        ]

        # Draw the bbox polygon
        polygon_kwargs = {
            "locations": corners,
            "weight": 2,
            "fill": True,
            "fill_opacity": 0.2,
        }
        if draw_ids and item_id:
            polygon_kwargs["tooltip"] = item_id  # hover
            polygon_kwargs["popup"] = item_id    # click

        folium.Polygon(**polygon_kwargs).add_to(fmap)

        # Place the id roughly in the center of the bbox as a label
        if draw_ids and item_id:
            center_lat = (min_lat + max_lat) / 2.0
            center_lon = (min_lon + max_lon) / 2.0

            folium.Marker(
                location=[center_lat, center_lon],
                icon=DivIcon(
                    icon_size=(150, 36),
                    icon_anchor=(0, 0),
                    html=f'<div style="font-size: 10pt; font-weight: bold;">{item_id}</div>',
                ),
            ).add_to(fmap)

    # Add a simple latitude/longitude grid (graticule) over the globe
    lat_step = 30  # degrees between horizontal grid lines
    lon_step = 30  # degrees between vertical grid lines

    # Vertical lines (constant longitude)
    for lon in range(-180, 181, lon_step):
        line = [[lat, lon] for lat in range(-90, 91, 5)]
        folium.PolyLine(
            locations=line,
            weight=1,
            opacity=0.3,
        ).add_to(fmap)

    # Horizontal lines (constant latitude)
    for lat in range(-90, 91, lat_step):
        line = [[lat, lon] for lon in range(-180, 181, 5)]
        folium.PolyLine(
            locations=line,
            weight=1,
            opacity=0.3,
        ).add_to(fmap)

    # Mouse-position control to display coordinates under the cursor
    MousePosition().add_to(fmap)

    # If we have any valid bboxes, fit the map to them
    if all_lats and all_lons:
        south, north = min(all_lats), max(all_lats)
        west, east = min(all_lons), max(all_lons)
        fmap.fit_bounds([[south, west], [north, east]])

    # Save to HTML (no attempt to open a browser)
    target_path = get_default_bbox_map_output_path() if output_path is None else Path(output_path).expanduser()
    if not target_path.is_absolute():
        target_path = (Path.cwd() / target_path).resolve()
    target_path.parent.mkdir(parents=True, exist_ok=True)
    fmap.save(str(target_path))

    return fmap


def render_world_bbox_pdf(
    metadata_batch,
    output_path,
    *,
    title="Pilot STAC Item BBox Coverage",
    annotate_ids=False,
    max_labels=30,
    extent=None,
):
    """
    Render STAC-like bboxes on a world-background map and save to PDF.

    Parameters
    ----------
    metadata_batch : list[dict]
        List of items with a "bbox" key in STAC order:
        [min_lon, min_lat, max_lon, max_lat].
        Optional "id" key is used only when annotate_ids=True.
    output_path : str | pathlib.Path
        Target PDF path.
    title : str
        Figure title.
    annotate_ids : bool
        Whether to annotate bbox centers with ids.
    max_labels : int
        Upper bound on number of labels drawn when annotate_ids=True.
    extent : tuple[float, float, float, float] | None
        Optional fixed viewport as `(min_lon, max_lon, min_lat, max_lat)`.
        If omitted, world extent is used.
    """

    import matplotlib.patches as mpatches
    import matplotlib.pyplot as plt
    import cartopy.crs as ccrs
    import cartopy.io.shapereader as shpreader
    from shapely.geometry import box as shapely_box

    out_path = Path(output_path).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    fig = plt.figure(figsize=(11.5, 6.2), dpi=320)
    ax = plt.axes(projection=ccrs.PlateCarree())
    if extent:
        min_lon, max_lon, min_lat, max_lat = extent
        ax.set_extent([min_lon, max_lon, min_lat, max_lat], crs=ccrs.PlateCarree())
    else:
        ax.set_global()
        min_lon, max_lon, min_lat, max_lat = -180.0, 180.0, -90.0, 90.0

    bbox_geoms = []
    parsed_items = []
    for item in metadata_batch:
        bbox = item.get("bbox")
        if not bbox or len(bbox) != 4:
            continue
        try:
            west, south, east, north = (float(v) for v in bbox)
        except (TypeError, ValueError):
            continue
        if east <= west or north <= south:
            continue
        parsed_items.append((item, west, south, east, north))
        bbox_geoms.append(shapely_box(west, south, east, north))

    # Prefer high-resolution vector basemap layers loaded from local shapefiles.
    country_label_points = {}
    try:
        Path(os.environ["CARTOPY_DATA_DIR"]).mkdir(parents=True, exist_ok=True)
        Path(os.environ["XDG_DATA_HOME"]).mkdir(parents=True, exist_ok=True)

        land_shp = shpreader.natural_earth(resolution="10m", category="physical", name="land")
        ocean_shp = shpreader.natural_earth(resolution="10m", category="physical", name="ocean")
        lakes_shp = shpreader.natural_earth(resolution="10m", category="physical", name="lakes")
        rivers_shp = shpreader.natural_earth(
            resolution="10m",
            category="physical",
            name="rivers_lake_centerlines",
        )
        countries_shp = shpreader.natural_earth(
            resolution="10m",
            category="cultural",
            name="admin_0_countries",
        )
        ax.set_facecolor("#dbeafe")

        ocean_geoms = list(shpreader.Reader(ocean_shp).geometries())
        land_geoms = list(shpreader.Reader(land_shp).geometries())
        lakes_geoms = list(shpreader.Reader(lakes_shp).geometries())
        river_geoms = list(shpreader.Reader(rivers_shp).geometries())
        ax.add_geometries(ocean_geoms, ccrs.PlateCarree(), facecolor="#dbeafe", edgecolor="none", zorder=0)
        ax.add_geometries(land_geoms, ccrs.PlateCarree(), facecolor="#f8faf2", edgecolor="none", zorder=1)
        ax.add_geometries(lakes_geoms, ccrs.PlateCarree(), facecolor="#dbeafe", edgecolor="none", zorder=2)
        ax.add_geometries(
            river_geoms,
            ccrs.PlateCarree(),
            facecolor="none",
            edgecolor="#93c5fd",
            linewidth=0.15,
            zorder=3,
        )

        country_reader = shpreader.Reader(countries_shp)

        extent_poly = shapely_box(min_lon, min_lat, max_lon, max_lat)
        visible_country_geoms = []
        touched_country_geoms = []

        for rec in country_reader.records():
            geom = rec.geometry
            if geom is None:
                continue
            if not geom.intersects(extent_poly):
                continue

            visible_country_geoms.append(geom)

            is_touched = any(geom.intersects(bbox_geom) for bbox_geom in bbox_geoms)
            if not is_touched:
                continue

            touched_country_geoms.append(geom)
            country_name = (
                rec.attributes.get("NAME_LONG")
                or rec.attributes.get("NAME")
                or rec.attributes.get("ADMIN")
                or "unknown"
            )
            rp = geom.representative_point()
            if min_lon <= rp.x <= max_lon and min_lat <= rp.y <= max_lat:
                country_label_points[country_name] = (rp.x, rp.y)

        ax.add_geometries(
            visible_country_geoms,
            ccrs.PlateCarree(),
            facecolor="none",
            edgecolor="#64748b",
            linewidth=0.35,
            zorder=3,
        )
        ax.add_geometries(
            touched_country_geoms,
            ccrs.PlateCarree(),
            facecolor="#fef08a",
            edgecolor="#d97706",
            linewidth=0.65,
            alpha=0.26,
            zorder=4,
        )
    except Exception:
        ax.set_facecolor("#dbeafe")

    grid = ax.gridlines(
        draw_labels=True,
        linewidth=0.4,
        color="#475569",
        alpha=0.32,
        linestyle="--",
    )
    grid.top_labels = False
    grid.right_labels = False
    grid.xlabel_style = {"size": 8}
    grid.ylabel_style = {"size": 8}

    valid = 0
    labels_drawn = 0
    for item, min_lon_box, min_lat_box, max_lon_box, max_lat_box in parsed_items:
        valid += 1
        rect = mpatches.Rectangle(
            (min_lon_box, min_lat_box),
            max_lon_box - min_lon_box,
            max_lat_box - min_lat_box,
            transform=ccrs.PlateCarree(),
            linewidth=0.35,
            edgecolor="#1e3a8a",
            facecolor="#2563eb",
            alpha=0.20,
            zorder=5,
        )
        ax.add_patch(rect)

        if annotate_ids and labels_drawn < max_labels:
            item_id = str(item.get("id", ""))
            if item_id:
                cx = (min_lon_box + max_lon_box) / 2.0
                cy = (min_lat_box + max_lat_box) / 2.0
                ax.text(
                    cx,
                    cy,
                    item_id,
                    transform=ccrs.PlateCarree(),
                    fontsize=5,
                    color="#0f172a",
                    ha="center",
                    va="center",
                    alpha=0.8,
                    zorder=6,
                )
                labels_drawn += 1

    for country_name, (x, y) in sorted(country_label_points.items()):
        ax.text(
            x,
            y,
            country_name,
            transform=ccrs.PlateCarree(),
            fontsize=6.2,
            color="#1f2937",
            ha="center",
            va="center",
            zorder=6,
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.65, "pad": 0.6},
        )

    country_names = sorted(country_label_points)
    ax.set_title(f"{title} (n={valid}, countries={len(country_names)})", fontsize=12, pad=10)
    if country_names:
        names_preview = ", ".join(country_names[:12])
        if len(country_names) > 12:
            names_preview += f", ... (+{len(country_names) - 12} more)"
        fig.text(
            0.01,
            0.012,
            f"Countries intersecting item bboxes: {names_preview}",
            fontsize=7,
            color="#334155",
        )
    fig.savefig(out_path, format="pdf", bbox_inches="tight")
    plt.close(fig)
    return out_path
