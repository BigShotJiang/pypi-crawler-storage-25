import argparse
from typing import Any, List, Literal

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger
from dafab_client._rucio.common.filter import create_date_range_filter

LOG = setup_logger(__name__)
DEFAULT_STAC_SCOPE = "dafab"


def _fetch_items_by_timerange(
        start_date: str,
        end_date: str,
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    payload = {
        "scope": scope,
        "filter": create_date_range_filter(start_date, end_date, time_field=time_field).to_dict(),
    }
    LOG.debug("Filter payload: %s", payload)

    items = list(connection_manager().stac_filter(payload))
    if not items:
        return []
    return items[0]["items"]


def _print_cli_rows(rows: List[Any], *, return_mode: Literal["ids", "metadata"], context_label: str) -> None:
    if not rows:
        LOG.info("No items found within the provided %s.", context_label)
        return

    if return_mode == "ids":
        for item_id in rows:
            print(item_id)
    else:
        for item in rows:
            print(f"{item['id']}: {dict(item)}")

    LOG.info("Found %s items within the provided %s.", len(rows), context_label)


def get_item_metadata_by_timerange(
        start_date: str,
        end_date: str,
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    """Return full item metadata for objects within a temporal interval.

    Args:
        start_date: Interval start in ISO-8601 format.
        end_date: Interval end in ISO-8601 format.
        time_field: Metadata timestamp field used by the filter expression.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        List[Any]: Matching item metadata objects. Empty list on errors/no matches.
    """
    try:
        return _fetch_items_by_timerange(start_date, end_date, time_field=time_field, scope=scope)

    except Exception:  # pragma: no cover - logging path
        LOG.exception(
            "An error occurred while filtering items between %s and %s:",
            start_date,
            end_date,
        )
        return []


def get_item_ids_by_timerange(
        start_date: str,
        end_date: str,
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    """Return item ids for objects within a temporal interval.

    Args:
        start_date: Interval start in ISO-8601 format.
        end_date: Interval end in ISO-8601 format.
        time_field: Metadata timestamp field used by the filter expression.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        List[Any]: Matching item ids. Empty list on errors/no matches.
    """
    try:
        items = _fetch_items_by_timerange(start_date, end_date, time_field=time_field, scope=scope)
        return [item["id"] for item in items]

    except Exception:  # pragma: no cover - logging path
        LOG.exception(
            "An error occurred while filtering items between %s and %s:",
            start_date,
            end_date,
        )
        return []


def get_items_by_timerange(
        start_date: str,
        end_date: str,
        *,
        time_field: str = "datetime",
        scope: str = DEFAULT_STAC_SCOPE,
        return_mode: Literal["ids", "metadata"] = "ids",
) -> List[Any]:
    """Dispatch temporal filtering and return either ids or full metadata.

    Args:
        start_date: Interval start in ISO-8601 format.
        end_date: Interval end in ISO-8601 format.
        time_field: Metadata timestamp field used by the filter expression.
        scope: STAC namespace automatically attached to the request payload.
        return_mode: ``ids`` for identifiers, ``metadata`` for full item payloads.

    Returns:
        List[Any]: Filter results in the requested representation.
    """
    if return_mode == "ids":
        return get_item_ids_by_timerange(start_date, end_date, time_field=time_field, scope=scope)
    if return_mode == "metadata":
        return get_item_metadata_by_timerange(start_date, end_date, time_field=time_field, scope=scope)
    raise ValueError(f"Unsupported return_mode: {return_mode}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Filter items by datetime range (Q1: time-only).")
    parser.add_argument("datetime_start", type=str, help="Starting datetime (ISO 8601).")
    parser.add_argument("datetime_end", type=str, help="Ending datetime (ISO 8601).")
    parser.add_argument(
        "--time-field",
        choices=("datetime", "created"),
        default="datetime",
        help="Temporal field under properties used by date filters.",
    )
    parser.add_argument(
        "--return-mode",
        choices=("ids", "metadata"),
        default="ids",
        help="Return ids (default) or full item metadata.",
    )
    args = parser.parse_args()

    rows = get_items_by_timerange(
        args.datetime_start,
        args.datetime_end,
        time_field=args.time_field,
        return_mode=args.return_mode,
    )
    _print_cli_rows(rows, return_mode=args.return_mode, context_label="time range")
    raise SystemExit(0)
