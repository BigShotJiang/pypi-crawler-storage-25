import argparse
from typing import Any, List, Literal

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger
from dafab_client._rucio.common.filter import create_bbox_filter_intersects

LOG = setup_logger(__name__)
DEFAULT_STAC_SCOPE = "dafab"


def _fetch_items_by_bbox(
    min_long: float,
    min_lat: float,
    max_long: float,
    max_lat: float,
    *,
    scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    payload = {
        "scope": scope,
        "filter": create_bbox_filter_intersects(min_long, min_lat, max_long, max_lat).to_dict(),
    }
    LOG.debug("Filter payload: %s", payload)

    items = list(connection_manager().stac_filter(payload))

    if not items:
        return []

    return items[0]["items"]


def _print_cli_rows(rows: List[Any], *, return_mode: Literal["ids", "metadata"], context_label: str) -> None:
    if not rows:
        LOG.info("No items found within the provided %s.", context_label)
        return

    if return_mode == "ids":
        for item_id in rows:
            print(item_id)
    else:
        for item in rows:
            print(f"{item['id']}: {dict(item)}")

    LOG.info("Found %s items within the provided %s.", len(rows), context_label)


def get_item_metadata_by_bbox(
    min_long: float,
    min_lat: float,
    max_long: float,
    max_lat: float,
    *,
    scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    """Return full item metadata for objects intersecting a bounding box.

    Args:
        min_long: Western longitude boundary.
        min_lat: Southern latitude boundary.
        max_long: Eastern longitude boundary.
        max_lat: Northern latitude boundary.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        List[Any]: Matching item metadata objects. Empty list on errors/no matches.
    """
    try:
        items = _fetch_items_by_bbox(min_long, min_lat, max_long, max_lat, scope=scope)
        return items

    except Exception:  # pragma: no cover - logging path
        LOG.exception(
            "An error occurred while filtering items within the bounding box (%s, %s, %s, %s):",
            min_long,
            min_lat,
            max_long,
            max_lat,
        )
        return []


def get_item_ids_by_bbox(
    min_long: float,
    min_lat: float,
    max_long: float,
    max_lat: float,
    *,
    scope: str = DEFAULT_STAC_SCOPE,
) -> List[Any]:
    """Return item ids for objects intersecting a bounding box.

    Args:
        min_long: Western longitude boundary.
        min_lat: Southern latitude boundary.
        max_long: Eastern longitude boundary.
        max_lat: Northern latitude boundary.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        List[Any]: Matching item ids. Empty list on errors/no matches.
    """
    try:
        items = _fetch_items_by_bbox(min_long, min_lat, max_long, max_lat, scope=scope)
        return [item["id"] for item in items]

    except Exception:  # pragma: no cover - logging path
        LOG.exception(
            "An error occurred while filtering items within the bounding box (%s, %s, %s, %s):",
            min_long,
            min_lat,
            max_long,
            max_lat,
        )
        return []


def get_items_by_bbox(
    min_long: float,
    min_lat: float,
    max_long: float,
    max_lat: float,
    *,
    scope: str = DEFAULT_STAC_SCOPE,
    return_mode: Literal["ids", "metadata"] = "ids",
) -> List[Any]:
    """Dispatch bbox filtering and return either ids or full metadata.

    Args:
        min_long: Western longitude boundary.
        min_lat: Southern latitude boundary.
        max_long: Eastern longitude boundary.
        max_lat: Northern latitude boundary.
        scope: STAC namespace automatically attached to the request payload.
        return_mode: ``ids`` for identifiers, ``metadata`` for full item payloads.

    Returns:
        List[Any]: Filter results in the requested representation.
    """
    if return_mode == "ids":
        return get_item_ids_by_bbox(min_long, min_lat, max_long, max_lat, scope=scope)
    if return_mode == "metadata":
        return get_item_metadata_by_bbox(min_long, min_lat, max_long, max_lat, scope=scope)
    raise ValueError(f"Unsupported return_mode: {return_mode}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Filter items by bounding box (Q2: bbox-only).")
    parser.add_argument("bbox_min_long", type=float, help="bbox min longitude")
    parser.add_argument("bbox_min_lat", type=float, help="bbox min latitude")
    parser.add_argument("bbox_max_long", type=float, help="bbox max longitude")
    parser.add_argument("bbox_max_lat", type=float, help="bbox max latitude")
    parser.add_argument(
        "--return-mode",
        choices=("ids", "metadata"),
        default="ids",
        help="Return ids (default) or full item metadata.",
    )
    args = parser.parse_args()

    rows = get_items_by_bbox(
        args.bbox_min_long,
        args.bbox_min_lat,
        args.bbox_max_long,
        args.bbox_max_lat,
        return_mode=args.return_mode,
    )
    _print_cli_rows(rows, return_mode=args.return_mode, context_label="bounding box")
    raise SystemExit(0)
