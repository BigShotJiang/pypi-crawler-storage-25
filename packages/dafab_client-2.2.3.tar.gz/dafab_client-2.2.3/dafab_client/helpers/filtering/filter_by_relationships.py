from typing import Any, Mapping
from urllib.parse import urlparse

from dafab_client.helpers.filtering.filter_by_enhanced_filter import get_items_by_enhanced_filter
from dafab_client.helpers.metadata_management.Retrieval.Complete.get_metadata_for_scope_name import get_bulk_metadata


def _metadata_document(pname: str, *, scope: str) -> dict[str, Any]:
    payload = get_bulk_metadata(pname, scope=scope, max_retries=1, retry_delay=0)
    if not isinstance(payload, dict):
        return {}
    document = payload.get("document")
    if isinstance(document, dict):
        return document
    return payload


def _href_value_after_token(href: str, *, token: str) -> str | None:
    path_tokens = [part for part in urlparse(href).path.strip("/").split("/") if part]
    for index, part in enumerate(path_tokens):
        if part == token and index + 1 < len(path_tokens):
            value = path_tokens[-1].strip()
            return value or None
    return None


def _stable_unique(values: list[str]) -> list[str]:
    return sorted({value for value in values if isinstance(value, str) and value.strip()})


def _link_hrefs_by_rel(metadata: Mapping[str, Any], rel: str) -> list[str]:
    links = metadata.get("links")
    if not isinstance(links, list):
        return []

    hrefs: list[str] = []
    for link in links:
        if not isinstance(link, Mapping):
            continue
        if link.get("rel") != rel:
            continue
        href = link.get("href")
        if isinstance(href, str) and href.strip():
            hrefs.append(href.strip())
    return hrefs


def _item_ids_from_hrefs(hrefs: list[str]) -> list[str]:
    return _stable_unique(
        [
            item_id
            for href in hrefs
            if (item_id := _href_value_after_token(href, token="items")) is not None
        ]
    )


def _catalog_ids_from_hrefs(hrefs: list[str]) -> list[str]:
    return _stable_unique(
        [
            catalog_id
            for href in hrefs
            if (catalog_id := _href_value_after_token(href, token="catalogs")) is not None
        ]
    )


def get_item_ids_by_collection_field(collection_id: str) -> list[str]:
    """List item ids whose metadata ``collection`` field matches ``collection_id``.

    Args:
        collection_id: Target collection identifier.

    Returns:
        list[str]: Stable-sorted unique item ids matching the collection.
    """
    filter_payload = {
        "filter": {
            "type": "comparison",
            "comparator": "equals",
            "path": ["collection"],
            "value": collection_id,
            "valueType": "string",
        }
    }
    rows = get_items_by_enhanced_filter(filter_payload, return_mode="ids")
    return _stable_unique([str(row) for row in rows])


def get_related_item_ids_from_original_item(original_item_id: str, *, scope: str = "dafab") -> list[str]:
    """Resolve derived item ids linked from one original item.

    Args:
        original_item_id: Original item identifier.
        scope: Scope used to resolve metadata.

    Returns:
        list[str]: Stable-sorted unique ids extracted from ``rel=related`` links.
    """
    metadata = _metadata_document(original_item_id, scope=scope)
    related_hrefs = _link_hrefs_by_rel(metadata, "related")
    return _item_ids_from_hrefs(related_hrefs)


def get_source_original_item_ids_from_derived_item(derived_item_id: str, *, scope: str = "dafab") -> list[str]:
    """Resolve source original item ids linked from one derived item.

    Args:
        derived_item_id: Derived item identifier.
        scope: Scope used to resolve metadata.

    Returns:
        list[str]: Stable-sorted unique ids extracted from ``rel=derived_from`` links.
    """
    metadata = _metadata_document(derived_item_id, scope=scope)
    derived_from_hrefs = _link_hrefs_by_rel(metadata, "derived_from")
    return _item_ids_from_hrefs(derived_from_hrefs)


def get_sibling_derived_item_ids(
        original_item_id: str,
        *,
        collection_id: str | None = None,
        scope: str = "dafab",
) -> list[str]:
    """Resolve sibling derived item ids for an original item.

    Args:
        original_item_id: Original item identifier.
        collection_id: Optional collection filter applied to related derived items.
        scope: Scope used to resolve metadata.

    Returns:
        list[str]: Stable-sorted unique derived ids related to the original item.
    """
    related_ids = get_related_item_ids_from_original_item(original_item_id, scope=scope)
    if collection_id is None:
        return related_ids

    matched_ids: list[str] = []
    for related_item_id in related_ids:
        related_metadata = _metadata_document(related_item_id, scope=scope)
        if related_metadata.get("collection") == collection_id:
            matched_ids.append(related_item_id)
    return _stable_unique(matched_ids)


def get_item_ids_by_facet_value_catalog(facet_value_catalog_id: str, *, scope: str = "dafab") -> list[str]:
    """Resolve item ids indexed under one facet value catalog.

    Args:
        facet_value_catalog_id: Facet value catalog identifier.
        scope: Scope used to resolve metadata.

    Returns:
        list[str]: Stable-sorted unique item ids extracted from ``rel=item`` links.
    """
    metadata = _metadata_document(facet_value_catalog_id, scope=scope)
    item_hrefs = _link_hrefs_by_rel(metadata, "item")
    return _item_ids_from_hrefs(item_hrefs)


def get_item_ids_by_top_facet_catalog(top_facet_catalog_id: str, *, scope: str = "dafab") -> list[str]:
    """Resolve item ids under a top facet catalog.

    The top facet catalog is traversed via ``rel=child`` facet-value catalogs and
    item ids are then collected from each child via ``rel=item`` links.

    Args:
        top_facet_catalog_id: Top facet catalog identifier.
        scope: Scope used to resolve metadata.

    Returns:
        list[str]: Stable-sorted unique union of item ids across all child catalogs.
    """
    metadata = _metadata_document(top_facet_catalog_id, scope=scope)
    child_catalog_hrefs = _link_hrefs_by_rel(metadata, "child")
    child_catalog_ids = _catalog_ids_from_hrefs(child_catalog_hrefs)

    item_ids: set[str] = set()
    for child_catalog_id in child_catalog_ids:
        item_ids.update(get_item_ids_by_facet_value_catalog(child_catalog_id, scope=scope))
    return sorted(item_ids)


def get_item_ids_by_facet_parent_catalog(facet_parent_catalog_id: str, *, scope: str = "dafab") -> list[str]:
    """Backward-compatible alias for ``get_item_ids_by_top_facet_catalog``."""
    return get_item_ids_by_top_facet_catalog(facet_parent_catalog_id, scope=scope)


def get_related_item_ids_in_facet_value_catalog(
        original_item_id: str,
        facet_value_catalog_id: str,
        *,
        collection_id: str | None = None,
        scope: str = "dafab",
) -> list[str]:
    """Return related derived ids from one original item that are also indexed in one facet value catalog."""
    related_ids = set(
        get_sibling_derived_item_ids(
            original_item_id,
            collection_id=collection_id,
            scope=scope,
        )
    )
    facet_value_ids = set(get_item_ids_by_facet_value_catalog(facet_value_catalog_id, scope=scope))
    return sorted(related_ids.intersection(facet_value_ids))
