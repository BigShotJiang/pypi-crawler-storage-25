from typing import Any, Literal, Mapping

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)
DEFAULT_STAC_SCOPE = "dafab"
_SCOPE_SELECTOR_KEYS = ("scope", "stac_scope", "stac_namespace", "namespace")


def _normalize_filter_payload(
        filter_payload: Mapping[str, Any],
        *,
        scope: str = DEFAULT_STAC_SCOPE,
) -> dict[str, Any]:
    if "filter" in filter_payload:
        payload = dict(filter_payload)
    else:
        payload = {"filter": dict(filter_payload)}

    if not any(key in payload for key in _SCOPE_SELECTOR_KEYS):
        payload["scope"] = scope
    return payload


def _fetch_items_by_enhanced_filter(
        filter_payload: Mapping[str, Any],
        *,
        scope: str = DEFAULT_STAC_SCOPE,
) -> list[dict[str, Any]]:
    payload = _normalize_filter_payload(filter_payload, scope=scope)
    LOG.debug("Filter payload: %s", payload)

    response = list(connection_manager().stac_filter(payload))
    if not response:
        return []

    first_entry = response[0]
    if not isinstance(first_entry, dict):
        return []

    items = first_entry.get("items", [])
    if not isinstance(items, list):
        return []

    return [item for item in items if isinstance(item, dict)]


def get_item_metadata_by_enhanced_filter(
        filter_payload: Mapping[str, Any],
        *,
        scope: str = DEFAULT_STAC_SCOPE,
) -> list[dict[str, Any]]:
    """Return full metadata objects for an enhanced-filter query.

    Args:
        filter_payload: Enhanced-filter payload. Accepts either a full
            ``{"filter": ...}`` object or a bare filter expression.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        list[dict[str, Any]]: Matching metadata objects. Returns an empty list
        on query errors.
    """
    try:
        return _fetch_items_by_enhanced_filter(filter_payload, scope=scope)
    except Exception:  # pragma: no cover - logging path
        LOG.exception("An error occurred while filtering items with the enhanced filter payload.")
        return []


def get_item_ids_by_enhanced_filter(
        filter_payload: Mapping[str, Any],
        *,
        scope: str = DEFAULT_STAC_SCOPE,
) -> list[str]:
    """Return matching item identifiers for an enhanced-filter query.

    Args:
        filter_payload: Enhanced-filter payload. Accepts either a full
            ``{"filter": ...}`` object or a bare filter expression.
        scope: STAC namespace automatically attached to the request payload.

    Returns:
        list[str]: Matching item identifiers. Returns an empty list on query errors.
    """
    try:
        items = _fetch_items_by_enhanced_filter(filter_payload, scope=scope)
        return [str(item.get("id")) for item in items if item.get("id") is not None]
    except Exception:  # pragma: no cover - logging path
        LOG.exception("An error occurred while filtering item IDs with the enhanced filter payload.")
        return []


def get_items_by_enhanced_filter(
        filter_payload: Mapping[str, Any],
        *,
        scope: str = DEFAULT_STAC_SCOPE,
        return_mode: Literal["ids", "metadata"] = "ids",
) -> list[Any]:
    """Return IDs or metadata for an enhanced-filter query.

    Args:
        filter_payload: Enhanced-filter payload. Accepts either a full
            ``{"filter": ...}`` object or a bare filter expression.
        scope: STAC namespace automatically attached to the request payload.
        return_mode: ``"ids"`` for item ids, ``"metadata"`` for full objects.

    Returns:
        list[Any]: Item ids or metadata objects, depending on ``return_mode``.

    Raises:
        ValueError: If ``return_mode`` is unsupported.
    """
    if return_mode == "ids":
        return get_item_ids_by_enhanced_filter(filter_payload, scope=scope)
    if return_mode == "metadata":
        return get_item_metadata_by_enhanced_filter(filter_payload, scope=scope)
    raise ValueError(f"Unsupported return_mode: {return_mode}")
