"""Utility helpers for listing STAC items registered in Rucio."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from dafab_client._rucio.dafab_lib import as_pretty_json, connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


_DEFAULT_FILTER = {"name": "*"}


def _normalize_filters(filters: Any) -> list[dict[str, Any]]:
    """Return filters in a format accepted by ``Client.list_dids``."""
    if filters is None:
        return [_DEFAULT_FILTER.copy()]
    if isinstance(filters, dict):
        return [filters]
    if isinstance(filters, Iterable):
        return list(filters)
    raise TypeError("filters must be a dict, an iterable of dicts, or None")


def get_items(
        scope: str = "dafab",
        filters: Any = None,
        long: bool = True,
        recursive: bool = False,
) -> list[dict[str, Any]]:
    """Return item-level dataset objects that match the supplied filters.

    Args:
        scope: Scope to query.
        filters: Query filter dict (or list of dicts) forwarded to the client.
        long: Request long-form entries from the backend.
        recursive: Enable recursive lookup in nested structures.

    Returns:
        list[dict[str, Any]]: Item dataset entries returned by the backend.
    """

    normalized_filters = _normalize_filters(filters)
    datasets = connection_manager().list_dids(
        scope=scope,
        filters=normalized_filters,
        did_type="dataset",
        long=long,
        recursive=recursive,
    )
    return list(datasets)


def list_items(scope: str = "dafab", **kwargs: Any) -> None:
    """Log item identifiers discovered by :func:`get_items`.

    Args:
        scope: Scope to query.
        **kwargs: Forwarded to :func:`get_items`.
    """

    datasets = get_items(scope=scope, **kwargs)
    if not datasets:
        LOG.result("No items found in scope '%s'", scope)
        return

    LOG.info("Items found in scope '%s':", scope)
    for dataset in datasets:
        LOG.result(dataset["name"])


if __name__ == "__main__":
    list_items()
