import time
import argparse
import traceback

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)


def ensure_item(item_id, scope='dafab'):
    """
    Ensure that an item dataset DID exists in Rucio.

    The function repeatedly attempts to create and fetch the dataset named ``item_id`` using
    a Rucio client obtained via `connection_manager`.  If the dataset already exists, it is
    simply retrieved.  Transient failures are logged and the operation is retried several
    times before giving up.

    Parameters
    ----------
    item_id : str
        STAC item identifier used as dataset DID name
        (for example ``"S2B_43QDB_20240408_0_L2A"``).
    scope : str, optional
        The scope of the dataset. Defaults to ``'dafab'``.

    Returns
    -------
    bool
        ``True`` if the dataset was successfully created or already existed,
        ``False`` if all retry attempts failed.
    """
    max_retries = 5
    retry_delay = 30  # seconds

    for attempt in range(max_retries):
        try:
            # Get a client connection
            cl = connection_manager()

            dataset = cl.ensure_dataset(name=item_id, scope=scope)
            LOG.debug(f"{dataset}\n")
            if dataset['name'] == item_id:
                LOG.result(f"Item '{item_id}' is present in Rucio database.")
                return True
            else:
                LOG.warning(f"Item '{item_id}' was not registered in Rucio database.")
                return False

        except Exception as e:
            LOG.warning(f"Attempt {attempt + 1}/{max_retries}: An unexpected error "
                        f"of type '{type(e).__name__}' occurred "
                        f"while creating and/or getting the dataset '{item_id}': {e}\n")

            # Get the full traceback for debugging:
            traceback.print_exc()

            if attempt < max_retries - 1:  # Don't sleep after the last attempt
                LOG.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)

    LOG.warning("All retry attempts exhausted.")
    return False


def ensure_dataset(pname, scope='dafab'):
    """Backward-compatible alias for :func:`ensure_item`.

    Args:
        pname: Item identifier to verify/create.
        scope: Scope where the item should exist.

    Returns:
        bool: ``True`` when available, ``False`` otherwise.
    """
    return ensure_item(item_id=pname, scope=scope)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Ensure item dataset DID.')
    parser.add_argument('product_name', type=str,
                        help='Item identifier (e.g., S2B_43QDB_20240408_0_L2A).')

    args = parser.parse_args()

    product_name = args.product_name

    creation_success = ensure_item(product_name)
    exit(0 if creation_success else 1)
