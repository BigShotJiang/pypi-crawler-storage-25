"""
Utility methods for interacting with Rucio scopes.

Each helper mirrors the lightweight utilities available in
``dafab_client.helpers.check_server_health`` and ``dafab_client.helpers.System.check_storage``
to make invoking scope operations from the demo (or an interactive shell) straightforward.
"""

from typing import Literal, Union
from dafab_client._rucio.common.exception import Duplicate

from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)

cl = None


def _get_client():
    """Return a cached client instance used by this module."""
    global cl
    if cl is None:
        cl = connection_manager()
    return cl


"""
---
summary: List scopes
description: Retrieves the scopes visible to the configured account.
tags:
  - Scope
responses:
  200:
    description: OK
  401:
    description: Invalid Auth Token
  500:
    description: Internal error while fetching scopes
"""

def list_stac_scopes() -> None:
    """List all visible STAC scopes for the active account.

    Returns:
        None: Results are emitted through logger output.

    Raises:
        Exception: Re-raises client errors after logging.
    """

    try:
        scopes = _get_client().list_scopes()
        LOG.info("Available STAC scopes:")
        for entry in scopes:
            LOG.result("%s", _format_scope_entry(entry))
    except Exception as e:  # pragma: no cover - thin wrapper around the SDK
        LOG.error("Failed to list scopes due to '%s': %s", type(e).__name__, e)
        raise


"""
---
summary: Ensure scope for account
description: Adds the provided scope to the target account if it does not already exist.
tags:
  - Scope
parameters:
- name: account
  in: path
  description: The Rucio account to receive the scope
  schema:
    type: string
- name: scope
  in: path
  description: Name of the scope that should be present
  schema:
    type: string
responses:
  200:
    description: Scope already existed or was created successfully
  409:
    description: Scope already exists on a different account
"""

def _scope_add_response(
        *,
        changed: bool,
        reason: Literal["added", "already_present", "duplicate"],
        account: str,
        scope: str,
        details: bool,
) -> bool | dict[str, str | bool]:
    if not details:
        return changed
    return {
        "changed": changed,
        "reason": reason,
        "account": account,
        "scope": scope,
    }


def ensure_scope_for_account(
        account: str,
        scope: str,
        *,
        details: bool = False,
) -> bool | dict[str, str | bool]:
    """Ensure a scope is available for a target account.

    Args:
        account: Account that should own or reference the scope.
        scope: Scope name to verify/create.
        details: When ``True``, return a detailed status payload instead of a bool.

    Returns:
        bool | dict[str, str | bool]:
            ``True`` when a scope was created, ``False`` when it already existed
            (or was reported as duplicate). If ``details=True``, returns
            ``{"changed", "reason", "account", "scope"}``.

    Raises:
        Exception: Re-raises unexpected client errors after logging.
    """
    client = _get_client()

    try:
        scopes = client.list_scopes_for_account(account)
        if scope in scopes:
            LOG.debug("Scope '%s' is already present for account '%s'.", scope, account)
            return _scope_add_response(
                changed=False,
                reason="already_present",
                account=account,
                scope=scope,
                details=details,
            )

        client.add_scope(account=account, scope=scope)
        LOG.debug("Scope '%s' added to account '%s'.", scope, account)
        return _scope_add_response(
            changed=True,
            reason="added",
            account=account,
            scope=scope,
            details=details,
        )
    except Duplicate:
        LOG.debug("Scope '%s' already exists for account '%s' (Duplicate).", scope, account)
        return _scope_add_response(
            changed=False,
            reason="duplicate",
            account=account,
            scope=scope,
            details=details,
        )
    except Exception as e:  # pragma: no cover - thin wrapper around the SDK
        LOG.error(
            "Failed to ensure scope '%s' for account '%s' due to '%s': %s",
            scope,
            account,
            type(e).__name__,
            e,
        )
        raise


def _format_scope_entry(entry: Union[str, dict[str, str]]) -> str:
    """Produce a readable representation for either a bare scope string or a scope dict."""

    if isinstance(entry, dict):
        scope = entry.get("scope") or entry.get("name") or entry
        owner = entry.get("account")
        if owner:
            return f"{scope} (owner: {owner})"
        return str(scope)
    return str(entry)


if __name__ == "__main__":
    list_stac_scopes()
