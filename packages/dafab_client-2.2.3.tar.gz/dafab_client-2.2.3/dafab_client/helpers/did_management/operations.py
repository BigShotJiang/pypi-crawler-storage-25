"""High level helpers for interacting with Data Identifiers (DIDs)."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from typing import Any, Literal

from dafab_client._rucio.dafab_lib import as_pretty_json, connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)

_DEFAULT_FILTER = {"name": "*"}


def _normalize_filters(filters: Any) -> list[dict[str, Any]]:
    if filters is None:
        return [_DEFAULT_FILTER.copy()]
    if isinstance(filters, dict):
        return [filters]
    if isinstance(filters, Iterable):
        return list(filters)
    raise TypeError("filters must be a dict, an iterable of dicts, or None")


def get_stac_objects(
        scope: str = "dafab",
        filters: Any = None,
        did_type: Literal["all", "collection", "dataset", "container", "file"] = "all",
        long: bool = True,
        recursive: bool = False,
) -> list[dict[str, Any]]:
    """Return objects that match the supplied filters.

    Args:
        scope: Scope to query.
        filters: Query filter dict (or list of dicts) forwarded to the client.
        did_type: Object type selector accepted by the backend.
        long: Request long-form entries from the backend.
        recursive: Enable recursive lookup in nested structures.

    Returns:
        list[dict[str, Any]]: Matching objects returned by the backend.
    """

    normalized_filters = _normalize_filters(filters)
    dids = connection_manager().list_dids(
        scope=scope,
        filters=normalized_filters,
        did_type=did_type,
        long=long,
        recursive=recursive,
    )
    return list(dids)


def list_stac_objects(scope: str = "dafab", **kwargs: Any) -> None:
    """Log objects returned by :func:`get_stac_objects`.

    Args:
        scope: Scope to query.
        **kwargs: Forwarded to :func:`get_stac_objects`.
    """
    dids = get_stac_objects(scope=scope, **kwargs)
    if not dids:
        LOG.result("No DIDs found in scope '%s'", scope)
        return

    LOG.info("DIDs found in scope '%s':", scope)
    for did in dids:
        LOG.result(did)


def add_item(
        scope: str = "dafab",
        name: str = None,
        did_type: Literal["DATASET", "CONTAINER"] = "DATASET",
        statuses: Mapping[str, Any] | None = None,
        meta: Mapping[str, Any] | None = None,
        rules: Sequence[Mapping[str, Any]] | None = None,
        lifetime: int | None = None,
        dids: Sequence[Mapping[str, Any]] | None = None,
        rse: str | None = None,
) -> bool:
    """Create an item/container object.

    Args:
        scope: Scope where the object should be created.
        name: Object identifier.
        did_type: Backend object type (``DATASET`` or ``CONTAINER``).
        statuses: Optional status flags passed to the backend.
        meta: Optional metadata dict for initial creation.
        rules: Optional placement rules passed to the backend.
        lifetime: Optional lifetime value in seconds.
        dids: Optional initial child attachments.
        rse: Optional storage selector.

    Returns:
        bool: ``True`` on success, ``False`` on failure.
    """

    try:
        connection_manager().add_did(
            scope=scope,
            name=name,
            did_type=did_type,
            statuses=statuses,
            meta=meta,
            rules=rules,
            lifetime=lifetime,
            dids=dids,
            rse=rse,
        )
        return True
    except Exception as e:
        LOG.error(f"Error adding {did_type}: {e}")
        return False


def attach_stac_members(
        scope: str = "dafab",
        name: str = None,
        members: Sequence[Mapping[str, Any]] | None = None,
        rse: str | None = None,
) -> bool:
    """Attach member objects to a parent container object.

    Args:
        scope: Scope of the parent and members.
        name: Parent container identifier.
        members: Member payloads of the form ``{"scope": ..., "name": ...}``.
        rse: Optional storage selector forwarded to the backend.

    Returns:
        bool: Backend result for the attach operation.
    """

    return connection_manager().attach_dids(scope=scope, name=name, dids=members, rse=rse)


def detach_stac_members(
        scope: str = "dafab",
        name: str = None,
        members: Sequence[Mapping[str, Any]] | None = None,
) -> bool:
    """Detach member objects from a parent container object.

    Args:
        scope: Scope of the parent and members.
        name: Parent container identifier.
        members: Member payloads of the form ``{"scope": ..., "name": ...}``.

    Returns:
        bool: Backend result for the detach operation.
    """

    return connection_manager().detach_dids(scope=scope, name=name, dids=members)

if __name__ == "__main__":
    list_stac_objects()
