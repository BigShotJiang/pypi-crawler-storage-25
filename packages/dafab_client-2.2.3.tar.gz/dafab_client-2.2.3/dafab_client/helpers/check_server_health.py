from dafab_client._rucio.dafab_lib import connection_manager
from dafab_client._rucio.global_utils import setup_logger

LOG = setup_logger(__name__)

cl = None


def _get_client():
    """Return a cached client instance used by this module."""
    global cl
    if cl is None:
        cl = connection_manager()
    return cl

"""
---
summary: Ping server
description: Sends a ping request to check the Rucio server status and connectivity.
tags:
  - Server
operationId: ping
get:
  /ping:
    description: Ping the Rucio server
parameters:
- name: X-Rucio-VO
  in: header
  description: The Virtual Organization to act on.
  schema:
    type: string
  required: false
  default: 'def'
- name: User-Agent
  in: header
  description: Client identifier. 
  schema:
    type: string
  required: true 
  example: 'rucio-clients/1.25.4'
responses:
  200:
    description: Server is alive
    content:
      application/json:
        schema:
          type: object
          description: Server information
          properties:
            version:
              type: string
              description: The server version
              example: "1.25.4"
            hostname:
              type: string 
              description: The server hostname
              example: "rucio-server-prod-01"
  500:
    description: Internal Server Error
    content:
      application/json:
        schema:
          type: object
          properties:
            ExceptionClass:
              type: string
              description: The type of exception that occurred
            ExceptionMessage:
              type: string
              description: A description of what went wrong
"""


def ping():
    """Ping the server and return the service payload.

    Returns:
        Any: The response object returned by the server ping endpoint
        (typically version/hostname information).
    """
    return _get_client().ping()


if __name__ == "__main__":
    # Ping the server
    ping()
