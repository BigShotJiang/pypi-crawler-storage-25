"""Public import namespace for the DaFab client package."""

from __future__ import annotations

from pathlib import Path
from shutil import copy2

from . import helpers
from ._rucio.global_utils import get_active_account, set_active_account

_ACCOUNT_API = ("get_active_account", "set_active_account")
_EXAMPLE_NOTEBOOKS_DIR = Path(__file__).resolve().parent / "example_notebooks"
_EXAMPLE_PROFILE_TO_NOTEBOOK = {
    "user": "dafab_simple_user_workflows.ipynb",
    "admin": "dafab_operator_workflows.ipynb",
    "skim": "dafab_skim_workflows.ipynb",
    "dasi": "dafab_dasi_workflows.ipynb",
}
_EXAMPLE_PROFILE_ALIASES = {
    "operator": "admin",
}

__all__ = ("helpers", *_ACCOUNT_API, "get_example", *helpers.__all__)


def get_example(profile: str | None = None, destination: str | Path = ".") -> list[Path]:
    """Copy packaged notebooks into ``destination`` and return copied local paths."""
    if profile is None:
        notebook_names = sorted(set(_EXAMPLE_PROFILE_TO_NOTEBOOK.values()))
    else:
        normalized = str(profile).strip().lower()
        normalized = _EXAMPLE_PROFILE_ALIASES.get(normalized, normalized)
        notebook_name = _EXAMPLE_PROFILE_TO_NOTEBOOK.get(normalized)
        if notebook_name is None:
            valid_profiles = ", ".join(sorted(_EXAMPLE_PROFILE_TO_NOTEBOOK))
            raise ValueError(
                f"Unknown profile '{profile}'. Supported values: {valid_profiles}."
            )
        notebook_names = [notebook_name]

    target_dir = Path(destination).expanduser().resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    copied_paths: list[Path] = []
    for notebook_name in notebook_names:
        source_path = _EXAMPLE_NOTEBOOKS_DIR / notebook_name
        if not source_path.is_file():
            raise FileNotFoundError(f"Missing packaged notebook: {source_path}")
        target_path = target_dir / notebook_name
        copy2(source_path, target_path)
        copied_paths.append(target_path)

    return copied_paths


def __getattr__(name: str):
    if name in helpers.__all__:
        return getattr(helpers, name)
    if name in _ACCOUNT_API:
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
