import os
import traceback
from collections.abc import Sequence, Iterator

from dafab_client._rucio.client import Client
from dafab_client._rucio.client.baseclient import choice
from dafab_client._rucio.client.uploadclient import UploadClient
from dafab_client._rucio.client.downloadclient import DownloadClient, FileDownloadState

from dafab_client._rucio.common import exception
from dafab_client._rucio.common.filter import EnhancedFilter
from dafab_client._rucio.common.constants import HTTPMethod
from dafab_client._rucio.common.utils import build_url, parse_response, date_to_str, make_valid_did
from dafab_client._rucio.common.exception import DataIdentifierAlreadyExists, ReplicaNotFound, NoFilesUploaded, NotAllFilesUploaded

from typing import Any, Optional, Literal, Union
from urllib.parse import quote_plus
from requests.status_codes import codes
from json import dumps, JSONDecodeError
from datetime import datetime

from dafab_client._rucio.global_utils import debug_mode, setup_logger

LOG = setup_logger(__name__)


class DevDownloadClient(DownloadClient):

    def download_file(self, fname, base_dir, scope: str, rse: str):

        LOG.info(f"Downloading file {fname} to {base_dir}")
        LOG.debug(f"Download requested with RSE expression: {rse}")

        # Prepare the file dictionary for upload
        file_item = {
            'base_dir': base_dir,  # Base directory where the downloaded files will be stored
            'did': f"{scope}:{fname}",  # DID string of this file (e.g. 'scope:file.name').
            'rse': rse,  # Target RSE name
            'transfer_timeout': 600,  # Timeout time for the download protocols.
            'no_subdir': True  # If true, files are written directly into base_dir.
        }

        LOG.debug(f"File download parameters: {file_item}")

        try:
            # Perform the download with all necessary parameters
            result = self.download_dids(items=[file_item])
            state = result[0]['clientState']

            # Check whether the requested file has been downloaded successfully
            if state == FileDownloadState.DONE or state == FileDownloadState.ALREADY_DONE:
                return True

        except Exception as error:
            LOG.debug(f"Failed to download file. Error: {error}")

            # Get the full traceback for debugging:
            if debug_mode:
                traceback.print_exc()

        return False


class DevUploadClient(UploadClient):

    def upload_file(self, fpath, pname, scope: str, rse: str):

        LOG.info(f"Uploading file for dataset_name: `{pname}`")
        filename = os.path.basename(fpath)

        if rse == 'MELUXINA_S3':
            # Prepare the file dictionary for upload
            file_item = {
                'path': fpath,  # Physical local path to the file
                'rse': rse,  # Target RSE name
                'did_scope': scope,  # Scope to assign to the uploaded geojson file (we use 'dafab' for the 'dafab')
                'did_name': filename,  # Name to assign to the uploaded geojson file (with file extension)
                'dataset_scope': scope,  # Scope of the product to which the file will be linked (we use 'dafab' for the 'dafab')
                'dataset_name': pname,  # Name of the product to which the uploaded file will be linked (without its file extension)
                'bytes': os.path.getsize(fpath),  # File size
                'meta': {'guid': None},  # Metadata (guid will be generated automatically)
                # 'dirname': os.path.dirname(os.path.abspath(fpath)),  # Directory part of path
                'no_register': False,
                'register_after_upload': True
            }

            try:
                # Perform the upload with all necessary parameters
                result = self.upload(
                    items=[file_item],  # List of files to upload
                    summary_file_path=None,  # No summary file needed
                    traces_copy_out=None,  # No trace copy needed
                    ignore_availability=False,  # Don't ignore RSE availability
                    activity=None  # No specific activity
                )

                if result == 0:  # Upload client returns 0 on success
                    LOG.debug(f"Successfully uploaded {filename} to {rse}")
                    return True
                else:
                    LOG.debug(f"Unexpected upload termination with return code {result}")
                    return False
            except NoFilesUploaded:
                # We assume that the files were not uploaded/registered because they are already set
                return True
            except NotAllFilesUploaded:
                # We assume that the files were not uploaded/registered because they are already set
                return True
            except Exception as error:
                LOG.debug(f"Failed to upload file. Error: {error}")

                # Get the full traceback for debugging:
                if debug_mode:
                    traceback.print_exc()

                return False

        else:
            # Prepare the file dictionary for upload
            file_item = {
                'path': fpath,  # Physical local path to the file
                'rse': rse,  # Target RSE name
                'did_scope': scope,  # Scope to assign to the uploaded geojson file (we use 'dafab' for the 'dafab')
                'did_name': filename,  # Name to assign to the uploaded geojson file (with file extension)
                'dataset_scope': scope,
                # Scope of the product to which the file will be linked (we use 'dafab' for the 'dafab')
                'dataset_name': pname,
                # Name of the product to which the uploaded file will be linked (without its file extension)
                'bytes': os.path.getsize(fpath),  # File size
                'meta': {'guid': None},  # Metadata (guid will be generated automatically)
                'dirname': os.path.dirname(os.path.abspath(fpath)),  # Directory part of path
                'no_register': False,
                'register_after_upload': False,
                'pfn': f'https://dafab.cern.ch:443/data/{filename}'
            }

            try:
                # Perform the upload with all necessary parameters
                result = self.upload(
                    items=[file_item],  # List of files to upload
                    summary_file_path=None,  # No summary file needed
                    traces_copy_out=None,  # No trace copy needed
                    ignore_availability=False,  # Don't ignore RSE availability
                    activity=None  # No specific activity
                )

                if result == 0:  # Upload client returns 0 on success
                    LOG.debug(f"Successfully uploaded {filename} to {rse}")
                    return True
                else:
                    LOG.debug(f"Unexpected upload termination with return code {result}")
                    return False
            except NoFilesUploaded:
                # We assume that the files were not uploaded/registered because they are already set
                return True
            except NotAllFilesUploaded:
                # We assume that the files were not uploaded/registered because they are already set
                return True
            except Exception as error:
                LOG.debug(f"Failed to upload file. Error: {error}")

                # Get the full traceback for debugging:
                if debug_mode:
                    traceback.print_exc()

                return False

    def delete_file(self, fname: str, scope: str, rse: str):

        LOG.debug(f"Removing file `{fname}` from `{rse}` RSE.")

        rse_settings = self.rses.setdefault(rse, self.client.get_rse(str(rse)))
        rse_sign_service = rse_settings.get('sign_url', None)

        lfn = {'filename': fname, 'scope': scope, 'name': fname}

        LOG.debug(f"RSE settings: {rse_settings}")

        # Construct protocol for delete operation.
        prt = self._create_protocol(rse_settings, 'delete', force_scheme=None, domain='wan', impl=None)

        # Calculate the resource destination
        delete_pfn = '%s' % list(prt.lfns2pfns(make_valid_did(lfn)).values())[0]

        LOG.debug(f"delete_pfn: {delete_pfn}")

        # Sign the resource destination
        signed_url = self.client.get_signed_url(rse_settings['rse'], rse_sign_service, 'delete', delete_pfn)

        prt.delete(signed_url)
        prt.close()


class DevClient(Client):
    """Extended DIDClient with debugging capabilities"""

    def _get_exception(
            self,
            headers: dict[str, str],
            status_code: Optional[int] = None,
            data=None
    ) -> tuple[type[exception.RucioException], str]:

        LOG.debug("\nDebug - Client Exception Parsing:")
        LOG.debug(f"Received Headers: {headers}")
        LOG.debug(f"Received Raw Data: {data}")

        if data is not None:
            try:
                parsed_data = parse_response(data)
                LOG.debug(f"Parsed Data: {parsed_data}")
                data = parsed_data
            except ValueError:
                LOG.debug("Failed to parse response data as JSON")
                data = {}
        else:
            data = {}

        exc_cls = 'RucioException'
        exc_msg = 'no error information passed (http status code: %s)' % status_code

        if 'ExceptionClass' in data:
            exc_cls = data['ExceptionClass']
            LOG.debug(f"Found ExceptionClass in data: {exc_cls}")
        elif 'ExceptionClass' in headers:
            exc_cls = headers['ExceptionClass']
            LOG.debug(f"Found ExceptionClass in headers: {exc_cls}")

        if 'ExceptionMessage' in data:
            exc_msg = data['ExceptionMessage']
            LOG.debug(f"Found ExceptionMessage in data: {exc_msg}")
        elif 'ExceptionMessage' in headers:
            exc_msg = headers['ExceptionMessage']
            LOG.debug(f"Found ExceptionMessage in headers: {exc_msg}")

        LOG.debug(f"Final Exception Class: {exc_cls}")
        LOG.debug(f"Final Exception Message: {exc_msg}")
        LOG.debug(f"Has exception attribute: {hasattr(exception, exc_cls)}")

        if hasattr(exception, exc_cls):
            return getattr(exception, exc_cls), exc_msg
        else:
            return exception.RucioException, "%s: %s" % (exc_cls, exc_msg)

    def list_dids(
            self,
            scope: str,
            filters: Union["Sequence[dict[str, Any]]", "EnhancedFilter"],
            did_type: Literal['all', 'collection', 'dataset', 'container', 'file'] = 'dataset',
            long: bool = True,
            recursive: bool = False
    ) -> "Iterator[dict[str, Any]]":
        """
        List all data identifiers in a scope which match a given pattern.

        Parameters
        ----------
            scope :
                The scope name.
            filters :
                A nested dictionary of key/value pairs like [{'key1': 'value1', 'key2.lte': 'value2'}, {'key3.gte, 'value3'}].
                Keypairs in the same dictionary are AND'ed together, dictionaries are OR'ed together. Keys should be suffixed
                like <key>.<operation>, e.g. key1 >= value1 is equivalent to {'key1.gte': value}, where <operation> belongs to one
                of the set {'lte', 'gte', 'gt', 'lt', 'ne' or ''}. Equivalence doesn't require an operator.
            did_type :
                The type of the DID: 'all'(container, dataset or file)|'collection'(dataset or container)|'dataset'|'container'|'file'
            long :
                Long format option to display more information for each DID.
            recursive :
                Recursively list DIDs content.
        """
        path = '/'.join([self.DIDS_BASEURL, quote_plus(scope), 'dids', 'search'])

        if not isinstance(filters, EnhancedFilter):
            # stringify dates.
            if isinstance(filters, dict):  # backwards compatibility for filters as single {}
                filters = [filters]
            for or_group in filters:
                for key, value in or_group.items():
                    if isinstance(value, datetime):
                        or_group[key] = date_to_str(value)

        # For both GET and POST:
        if isinstance(filters, EnhancedFilter):

            payload = {
                'type': did_type,
                'long': long,
                'recursive': recursive
            }
            url = build_url(choice(self.list_hosts), path=path, params=payload)

            LOG.debug(f"Sending filter with POST to {url}")

            r = self._send_request(url, method=HTTPMethod.POST, data=filters.to_json())
        else:

            payload = {
                'type': did_type,
                'filters': filters,
                'long': long,
                'recursive': recursive
            }
            url = build_url(choice(self.list_hosts), path=path, params={**payload, 'filters': filters})

            LOG.debug(f"Sending filters with GET to {url}")

            r = self._send_request(url, method=HTTPMethod.GET)

        if r.status_code == codes.ok:
            dids = self._load_json_data(r)
            return dids
        else:
            exc_cls, exc_msg = self._get_exception(headers=r.headers, status_code=r.status_code, data=r.content)
            raise exc_cls(exc_msg)

    def get_metadata(
            self,
            scope: str = 'dafab',
            name: str = None,
            plugin: str = 'STRUCTURED_JSON'
    ) -> dict[str, Any]:
        """
        Get data identifier metadata.

        Parameters
        ----------
        scope :
            The scope name.
        name :
            The data identifier name.
        plugin :
            Backend Metadata plugin the Rucio server should use to query data.
        """
        path = '/'.join([self.DIDS_BASEURL, quote_plus(scope), quote_plus(name), 'meta'])
        url = build_url(choice(self.list_hosts), path=path)
        payload = {'plugin': plugin}

        # Debug information before making request
        LOG.debug(f"\nDebug: Making request to URL: {url}")
        LOG.debug(f"Debug: With payload: {payload}")

        r = self._send_request(url, method=HTTPMethod.GET, params=payload)

        # Debug response information
        LOG.debug(f"\nDebug: Response received:")
        LOG.debug(f"Debug: Status Code: {r.status_code}")
        LOG.debug(f"Debug: Headers: {dict(r.headers)}")
        # LOG.debug(f"Debug: Content: {r.content.decode() if r.content else 'No content'}")

        if r.status_code == codes.ok:
            meta = self._load_json_data(r)
            return next(meta)
        else:
            # Debug exception information
            LOG.debug(f"\nDebug: Error occurred. Extracting exception details...")
            exc_cls, exc_msg = self._get_exception(headers=r.headers, status_code=r.status_code, data=r.content)
            LOG.debug(f"Debug: Exception class: {exc_cls}")
            LOG.debug(f"Debug: Exception message: {exc_msg}")
            raise exc_cls(exc_msg)

    def _bulkmetadoc_url(self) -> str:
        path = '/'.join([self.DIDS_BASEURL, 'bulkmetadoc'])
        return build_url(choice(self.list_hosts), path=path)

    @staticmethod
    def _parse_json_stream_response(response) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        try:
            for raw_line in response.iter_lines():
                if not raw_line:
                    continue
                row = parse_response(raw_line)
                if isinstance(row, dict):
                    rows.append(row)
        finally:
            response.close()
        return rows

    def get_metadata_document_bulk(
            self,
            dids: Sequence[dict[str, str]],
            paths: Optional[Sequence[str]] = None,
            plugin: str = 'STRUCTURED_JSON',
    ) -> list[dict[str, Any]]:
        """Retrieve metadata documents for one or more DIDs via BulkMetaDoc.

        The server selects the metadata plugin for document operations, so the
        request payload intentionally omits any client-side plugin override.
        """
        payload: dict[str, Any] = {'dids': list(dids)}
        if paths is not None:
            payload['paths'] = list(paths)

        response = self._send_request(
            self._bulkmetadoc_url(),
            method=HTTPMethod.POST,
            headers={'Content-Type': 'application/json', 'Accept': 'application/x-json-stream'},
            data=dumps(payload),
            stream=True,
        )
        if response.status_code == codes.ok:
            return self._parse_json_stream_response(response)

        exc_cls, exc_msg = self._get_exception(headers=response.headers, status_code=response.status_code, data=response.content)
        raise exc_cls(exc_msg)

    def get_metadata_document(
            self,
            scope: str = 'dafab',
            name: str = None,
            paths: Optional[Sequence[str]] = None,
            plugin: str = 'STRUCTURED_JSON',
    ) -> dict[str, Any]:
        """Retrieve a single DID metadata document (full or partial) via BulkMetaDoc."""
        rows = self.get_metadata_document_bulk(
            dids=[{'scope': scope, 'name': name}],
            paths=paths,
            plugin=plugin,
        )
        return rows[0] if rows else {}

    def patch_metadata_document_bulk(
            self,
            dids: Sequence[dict[str, str]],
            operations: Sequence[dict[str, Any]],
            mode: Literal['atomic', 'best_effort'] = 'atomic',
            plugin: str = 'STRUCTURED_JSON',
    ) -> dict[str, Any]:
        """Apply BulkMetaDoc patch operations to one or more DIDs.

        The server selects the metadata plugin for document operations, so the
        request payload intentionally omits any client-side plugin override.
        """
        payload: dict[str, Any] = {
            'dids': list(dids),
            'operations': list(operations),
            'mode': mode,
        }

        response = self._send_request(
            self._bulkmetadoc_url(),
            method=HTTPMethod.PATCH,
            headers={'Content-Type': 'application/json', 'Accept': 'application/json'},
            data=dumps(payload),
        )
        if response.status_code in (codes.ok, codes.created, codes.no_content):
            if not response.text:
                return {}
            parsed = parse_response(response.text)
            if isinstance(parsed, dict):
                return parsed
            return {'response': parsed}

        exc_cls, exc_msg = self._get_exception(headers=response.headers, status_code=response.status_code, data=response.content)
        raise exc_cls(exc_msg)

    def patch_metadata_document(
            self,
            scope: str = 'dafab',
            name: str = None,
            operations: Optional[Sequence[dict[str, Any]]] = None,
            mode: Literal['atomic', 'best_effort'] = 'atomic',
            plugin: str = 'STRUCTURED_JSON',
    ) -> dict[str, Any]:
        """Apply BulkMetaDoc patch operations to a single DID."""
        return self.patch_metadata_document_bulk(
            dids=[{'scope': scope, 'name': name}],
            operations=operations or [],
            mode=mode,
            plugin=plugin,
        )

    def set_metadata_bulk(
            self,
            scope: str = 'dafab',
            name: str = None,
            meta: "Mapping[str, Any]" = None,
            recursive: bool = False,
            plugin: str = 'STRUCTURED_JSON'
    ) -> bool:
        """
        Set data identifier metadata in bulk.

        :param scope: The scope of the DID.
        :param name: The data identifier name.
        :param meta: The dictionary holding the key-value metadata.
        :param recursive: Instruction to propagate the metadata change recursively to content (False by default).
        :param plugin: The selected backend metadata plugin to handle the operation ("all" by default)
        """
        """
        Set data identifier metadata in bulk.

        Parameters
        ----------
        scope :
            The scope name.
        name :
            The data identifier name.
        meta :
            The dictionary holding the key-value metadata.
        recursive :
            Instruction to propagate the metadata change recursively to content (False by default).
        plugin: 
            The selected backend metadata plugin to handle the operation ("all" by default)
        """

        if meta is None:
            meta = {}  # Default to an empty dictionary if not provided

        path = '/'.join([self.DIDS_BASEURL, quote_plus(scope), quote_plus(name), 'meta'])
        url = build_url(choice(self.list_hosts), path=path)
        data = dumps({'meta': meta, 'recursive': recursive, 'plugin': plugin})
        r = self._send_request(url, method=HTTPMethod.POST, data=data)
        if r.status_code == codes.created:
            return True
        else:
            exc_cls, exc_msg = self._get_exception(headers=r.headers, status_code=r.status_code, data=r.content)
            raise exc_cls(exc_msg)

    def set_metadata(
            self,
            scope: str = 'dafab',
            name: str = None,
            key: str = None,
            value: Any = None,
            recursive: bool = False,
            plugin: str = 'STRUCTURED_JSON'
    ) -> bool:
        """
        Add single metadata key:value entry to a DID using chunked data transmission if needed.

        Parameters
        ----------
        scope :
            The scope name.
        name :
            The data identifier name.
        key :
            The metadata key.
        value :
            The metadata value.
        recursive :
            Instruction to propagate the metadata change recursively to content (False by default).
        plugin:
            The selected backend metadata plugin to handle the operation ("all" by default)
        """

        # Switch to the chunked approach when the data being sent are bigger than a threshold (e.g. polygons).
        if False:
            return self.set_metadata_chunks(scope, name, key, value, recursive, plugin)
        else:
            path = '/'.join([self.DIDS_BASEURL, quote_plus(scope), quote_plus(name), 'meta', key])
            url = build_url(choice(self.list_hosts), path=path)

            # Serialize the value into JSON and encode it into bytes
            data = dumps({'value': value, 'recursive': recursive, 'plugin': plugin})

            r = self._send_request(url, method=HTTPMethod.POST, data=data)
            if r.status_code == codes.created:
                return True
            else:
                exc_cls, exc_msg = self._get_exception(headers=r.headers, status_code=r.status_code, data=r.content)
                raise exc_cls(exc_msg)

    ##################
    # The endpoint implements a chunked upload mechanism for large metadata values.
    # The data is sent in small chunks to manage memory efficiently while preserving data integrity.
    #
    # Endpoint Details
    #
    # Method: POST
    # Path: /dids/<scope>/<name>/meta_chunked/<key>
    #
    # scope: The scope of the DID
    # name: The name of the DID
    # key: The metadata key
    #
    # Content-Type: application/octet-stream
    #
    # Required headers:
    #   Content-Type: application/octet-stream
    #   Content-Length: <total_size_in_bytes>
    # Where:
    #   <total_size_in_bytes> is the total size of the JSON payload in bytes.
    #
    # The request body should contain a JSON object with the following structure, encoded as UTF-8 bytes:
    # {
    #     "value": <metadata_value>,
    #     "recursive": <boolean>,
    #     "plugin": <string>
    # }
    # Where:
    #   value: The metadata value to be stored
    #   recursive: Boolean flag for recursive metadata application (default: false)
    #   plugin: Metadata plugin to use (default: "all")
    #################
    def set_metadata_chunks(
            self,
            scope: str,
            name: str,
            key: str,
            value: Any,
            recursive: bool = False,
            plugin: str = "all"
    ) -> bool:
        """
        Add metadata using chunked transfer, similar to file uploads
        """
        path = '/'.join([self.DIDS_BASEURL, quote_plus(scope), quote_plus(name), 'meta_chunked', key])
        url = build_url(choice(self.list_hosts), path=path)

        try:
            data = dumps({'value': value, 'recursive': recursive, 'plugin': plugin}).encode('utf-8')
            LOG.debug(f"Data for insertion: {data}")
        except (TypeError, JSONDecodeError) as e:
            raise ValueError(f"Value cannot be serialized to JSON: {e}")

        class ChunkIterator:
            def __init__(self, data, chunk_size=8192):
                self.data = data
                self.chunk_size = chunk_size
                self.pos = 0
                self.total_size = len(data)

            def __iter__(self):
                return self

            def __next__(self):
                if self.pos >= self.total_size:
                    raise StopIteration

                chunk = self.data[self.pos:self.pos + self.chunk_size]
                self.pos += len(chunk)
                return chunk

            def __len__(self):
                return self.total_size

            def decode(self, *args, **kwargs):
                """Required by Rucio base client for logging"""
                return f"<ChunkIterator size={self.total_size}>"

            def __str__(self):
                """For string representation"""
                return self.decode()

        iterator = ChunkIterator(data)

        headers = {
            'Content-Type': 'application/octet-stream',
            'Content-Length': str(len(iterator))
        }

        # Sending chunks
        response = self._send_request(
            url,
            method=HTTPMethod.POST,
            data=iterator,
            headers=headers
        )

        if response.status_code != 200:
            exc_cls, exc_msg = self._get_exception(
                headers=response.headers,
                status_code=response.status_code,
                data=response.content
            )
            raise exc_cls(exc_msg)

        return True

    def delete_metadata(
            self,
            scope: str = 'dafab',
            name: str = None,
            key: str = None,
            plugin: str = 'STRUCTURED_JSON'
    ) -> bool:
        """
        Delete data identifier metadata.

        Parameters
        ----------
        scope :
            The scope name.
        name :
            The data identifier name.
        key :
            The metadata key to be deleted.
        plugin:
            The selected backend metadata plugin to handle the operation ("all" by default)
        """

        path = '/'.join([self.DIDS_BASEURL, quote_plus(scope), quote_plus(name), 'meta'])
        url = build_url(choice(self.list_hosts), path=path, params={'key': key})

        r = self._send_request(url, method=HTTPMethod.DELETE)
        if r.status_code == codes.ok:
            return True
        else:
            exc_cls, exc_msg = self._get_exception(headers=r.headers, status_code=r.status_code, data=r.content)
            raise exc_cls(exc_msg)

    def delete_replica(self, filename: str, rse: str):
        """
        Delete a single file replica from an RSE.

        :param filename: The name of the file.
        :param rse: The name of the RSE.
        :return: True if files have been deleted successfully.
        """
        try:
            return self.delete_replicas(rse=rse, files=[{'scope': 'dafab', 'name': filename}],
                                        ignore_availability=True)
        except ReplicaNotFound as e:
            return True
        except Exception:
            return False

    def delete_dataset(self, name: str = None):
        # TODO[DX]
        return None

    def ensure_dataset(self, name: str = None, scope='dafab'):
        LOG.debug(f"Adding the '{scope}' dataset '{name}'")
        # Try to add the specified '{scope}' dataset.
        try:
            self.add_dataset(scope=scope, name=name)
        except DataIdentifierAlreadyExists:
            # The specified dataset already exists.
            LOG.debug(f"Dataset {name} already exists")
            pass
        except Exception as e:
            LOG.debug(f"An unexpected error of type '{type(e).__name__}' occurred "
                      f"while adding the '{scope}' dataset '{name}': {e}\n")

        # TODO[DX]: Use only if we are about to use it
        '''
        # Ensure also that the dataset of interest is linked to the correct container.
        try:
            self.add_datasets_to_container(scope=scope, name='dafab',
                                           dsns=[{'scope': scope, 'name': name}])
        except DuplicateContent:
            # The specified dataset is already in the container 'dafab'.
            pass
        except Exception as e:
            LOG.debug(f"An unexpected error of type '{type(e).__name__}' occurred "
                  f"while linking the '{scope}' dataset '{name}' to the '{scope}' container: {e}\n")
        '''
        # Lastly, ensure that the dataset can be retrieved.
        return self.get_did(scope=scope, name=name)

    def stac_filter(self, filter_payload: dict[str, Any]) -> list[dict[str, Any]]:
        """Submit an enhanced filter payload to the custom ``stac_filter`` endpoint.

        Parameters
        ----------
        filter_payload : dict
            Dictionary containing the enhanced filter, including the top-level
            ``filter`` key.

        Returns
        -------
        list[dict[str, Any]]
            Parsed JSON response returned by the server.
        """
        path = "stac_filter"
        url = build_url(choice(self.list_hosts), path=path)
        headers = {"Content-Type": "application/json"}
        data = dumps(filter_payload)

        response = self._send_request(
            url,
            method=HTTPMethod.POST,
            headers=headers,
            data=data,
        )

        if response.status_code == codes.ok:
            return list(self._load_json_data(response))

        exc_cls, exc_msg = self._get_exception(
            headers=response.headers,
            status_code=response.status_code,
            data=response.content,
        )
        raise exc_cls(exc_msg)
