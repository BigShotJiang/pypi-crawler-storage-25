# Copyright European Organization for Nuclear Research (CERN) since 2012
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# from dogpile.cache import make_region # WinClient

# from rucio.common.config import is_client # WinClient
import logging  # WinClient
from dafab_client._rucio.common.constants import DEFAULT_VO
from dafab_client._rucio.rse import rsemanager
import dafab_client._rucio.global_utils as gu  # WinClient

LOG = logging.getLogger(__name__)  # WinClient

setattr(rsemanager, 'CLIENT_MODE', True)  # WinClient
setattr(rsemanager, 'SERVER_MODE', False)  # WinClient

# WinClient
"""
if is_client():
    setattr(rsemanager, 'CLIENT_MODE', True)
    setattr(rsemanager, 'SERVER_MODE', False)
else:
    setattr(rsemanager, 'CLIENT_MODE', False)
    setattr(rsemanager, 'SERVER_MODE', True)
"""


def get_rse_client(rse, vo=DEFAULT_VO, **kwarg):
    '''
    get_rse_client
    '''
    from dafab_client._rucio.client.rseclient import RSEClient
    from dafab_client._rucio.dafab_lib import get_client_config  # WinClient
    LOG.debug("Getting an RSE client for vo %s" % vo)  # WinClient

    gu.show_caller()  # WinClient

    client_config = get_client_config(gu.get_active_account())  # WinClient
    client = RSEClient(**client_config)  # WinClient
    # client = RSEClient(vo=vo)  # WinClient
    return client.get_rse(rse)


def get_signed_url_client(rse, service, op, url, vo=DEFAULT_VO):
    '''
    get_signed_url_client
    '''
    from dafab_client._rucio.dafab_lib import get_client_config  # WinClient
    from dafab_client._rucio.client.credentialclient import CredentialClient

    gu.show_caller()  # WinClient

    client_config = get_client_config(gu.get_active_account())  # WinClient
    return CredentialClient(**client_config).get_signed_url(rse, service, op, url)  # WinClient
    # return CredentialClient(vo=vo).get_signed_url(rse, service, op, url)  # WinClient

def get_signed_url_server(rse, service, op, url, vo=DEFAULT_VO):
    '''
    get_signed_url_server
    '''
    from dafab_client._rucio.core.credential import get_signed_url
    from dafab_client._rucio.core.rse import get_rse_id

    rse_id = get_rse_id(rse=rse, vo=vo)
    return get_signed_url(rse_id, service, op, url)


def rse_key_generator(namespace, fn, **kwargs):
    '''
    Key generator for RSE
    '''
    def generate_key(rse, vo=DEFAULT_VO, session=None):
        '''
        generate_key
        '''
        return '{}:{}'.format(rse, vo)
    return generate_key


# WinClient
"""
if rsemanager.CLIENT_MODE:   # pylint:disable=no-member
    setattr(rsemanager, '__request_rse_info', get_rse_client)
    setattr(rsemanager, '__get_signed_url', get_signed_url_client)

    # Preparing region for dogpile.cache
    RSE_REGION = make_region(function_key_generator=rse_key_generator).configure(
        'dogpile.cache.memory',
        expiration_time=900)
    setattr(rsemanager, 'RSE_REGION', RSE_REGION)

if rsemanager.SERVER_MODE:   # pylint:disable=no-member
    from dafab_client._rucio.common.cache import MemcacheRegion
    from dafab_client._rucio.core.rse import get_rse_id, get_rse_protocols
    from dafab_client._rucio.core.vo import map_vo

    def tmp_rse_info(rse=None, vo=DEFAULT_VO, rse_id=None, session=None):
        if rse_id is None:
            # This can be called directly by client tools if they're co-located on a server
            # i.e. running rucio cli on a server and during the test suite.
            # We have to map to VO name here for this situations, despite this nominally
            # not being a client interface.
            rse_id = get_rse_id(rse=rse, vo=map_vo(vo))
        return get_rse_protocols(rse_id=rse_id, session=session)

    setattr(rsemanager, '__request_rse_info', tmp_rse_info)
    setattr(rsemanager, '__get_signed_url', get_signed_url_server)
    RSE_REGION = MemcacheRegion(expiration_time=900)
    setattr(rsemanager, 'RSE_REGION', RSE_REGION)
"""

setattr(rsemanager, '__request_rse_info', get_rse_client)  # WinClient
setattr(rsemanager, '__get_signed_url', get_signed_url_client)  # WinClient
