import os
import traceback
from pathlib import Path
import json as jsn
from jsonschema import validate, ValidationError
import dafab_client._rucio.global_utils as gu
from dafab_client._rucio.client import Client
from dafab_client._rucio.overridden_rucio_client import DevClient, DevUploadClient, DevDownloadClient

LOG = gu.setup_logger(__name__)

# Package root directory (`.../site-packages/dafab_client`)
package_root_path = Path(__file__).resolve().parent.parent


def as_pretty_json(data) -> str:
    """Serialize arbitrary Python data to stable, human-readable JSON.

    Args:
        data: Any JSON-serializable object (or object exposing a string form).

    Returns:
        str: Pretty-printed JSON with sorted keys and deterministic formatting.
    """
    return jsn.dumps(data, indent=2, sort_keys=True, default=str)


def _resolve_profile_directory() -> Path:
    explicit_profile_dir = os.getenv("DAFAB_PROFILE_DIR")
    if explicit_profile_dir:
        return Path(explicit_profile_dir).expanduser()

    xdg_config_home = os.getenv("XDG_CONFIG_HOME")
    if xdg_config_home:
        return Path(xdg_config_home).expanduser() / "dafab-rucio-client" / "profiles"

    return Path.home() / ".config" / "dafab-rucio-client" / "profiles"


def _candidate_profile_config_paths(client_account: str) -> list[Path]:
    explicit_profile_path = os.getenv("DAFAB_PROFILE_PATH")
    if explicit_profile_path:
        return [Path(explicit_profile_path).expanduser()]

    profile_dir = _resolve_profile_directory()
    return [
        profile_dir / client_account / "config",
        package_root_path / "_rucio" / "secrets" / client_account / "config",
    ]


def _resolve_profile_config_path(client_account: str) -> Path:
    candidates = _candidate_profile_config_paths(client_account)
    for candidate in candidates:
        if candidate.is_file():
            return candidate

    raise FileNotFoundError(
        f"No profile config found for account '{client_account}'. Checked: "
        + ", ".join(str(path) for path in candidates)
    )


def get_profile_config_path(client_account: str) -> Path:
    """Return the resolved profile config path for ``client_account``."""

    return _resolve_profile_config_path(client_account)


def _expand_profile_config_tokens(account_config, client_account: str, account_path: Path):
    if isinstance(account_config, str):
        return (
            account_config
            .replace("$client_path", str(package_root_path))
            .replace("$client_account", str(client_account))
            .replace("$profile_path", str(account_path.parent))
        )
    if isinstance(account_config, list):
        return [
            _expand_profile_config_tokens(value, client_account, account_path)
            for value in account_config
        ]
    if isinstance(account_config, dict):
        return {
            key: _expand_profile_config_tokens(value, client_account, account_path)
            for key, value in account_config.items()
        }
    return account_config


def get_client_config(client_account):
    """
    Load the Rucio client configuration for ``client_account``.

    The configuration is resolved from the first existing path among:
    1) ``$DAFAB_PROFILE_PATH`` (if set),
    2) ``$DAFAB_PROFILE_DIR/<client_account>/config`` (local private profiles),
    3) ``dafab_client/_rucio/secrets/<client_account>/config`` (packaged fallback profile).

    If ``DAFAB_PROFILE_DIR`` is not set, default local profile directory is:
    - ``$XDG_CONFIG_HOME/dafab-rucio-client/profiles`` when ``XDG_CONFIG_HOME`` exists
    - otherwise ``~/.config/dafab-rucio-client/profiles``

    Any occurrences of ``$client_path``, ``$client_account`` and ``$profile_path`` are
    expanded in parsed string values. If ``proxy_path`` is present in the configuration, it is
    exported to ``X509_USER_PROXY`` and removed from the returned dictionary.

    Parameters
    ----------
    client_account : str
        Account name whose configuration should be loaded.

    Returns
    -------
    dict
        Configuration dictionary suitable for creating a Rucio client.
    """

    account_path = _resolve_profile_config_path(client_account)
    with open(account_path, encoding="utf-8") as file:
        account_attributes = jsn.load(file)
        client_configuration = _expand_profile_config_tokens(
            account_attributes,
            client_account,
            account_path,
        )
        if not isinstance(client_configuration, dict):
            raise ValueError(f"Profile config at '{account_path}' must be a JSON object.")

    if "proxy_path" in client_configuration:
        os.environ['X509_USER_PROXY'] = client_configuration["proxy_path"]
        del client_configuration["proxy_path"]

    return client_configuration


def connection_manager(official=False):
    """
    Create a Rucio client for the configured account.

    The configuration for the account defined in ``rucio.global_utils`` is
    loaded via `get_client_config`.  By default, the returned client is the
    development ``DevClient`` wrapper.  When ``official`` is ``True`` the
    official `rucio.client.Client` is used instead.

    Parameters
    ----------
    official : bool, optional
        Return the official client instead of ``DevClient``.  Default is ``False``.

    Returns
    -------
    Client
        Instance of ``DevClient`` or ``rucio.client.Client`` configured for the selected account.

    Raises
    ------
    Exception
        If any error occurs while creating the client.
    """
    account = gu.get_active_account()
    client_config = get_client_config(account)

    try:
        if not official:
            LOG.debug(f" Getting a DaFab DevClient for account '{account}'...")
            return DevClient(**client_config)
        else:
            LOG.debug(f" Getting an official Rucio Client for account '{account}'...")
            return Client(**client_config)
    except Exception as _e:
        LOG.debug(
            f"An error of type '{type(_e).__name__}' occurred while constructing Rucio's connection manager: {_e}\n")
        raise


def upload_manager():
    """
    Return an upload client for the configured account.

    The configuration for the account set in ``rucio.global_utils`` is loaded
    via `get_client_config`.  The returned `~rucio.overridden_rucio_client.DevUploadClient`
    wraps a `~rucio.overridden_rucio_client.DevClient` using this configuration.

    Returns
    -------
    DevUploadClient
        Upload client that can interact with the development Rucio
        environment.

    Raises
    ------
    Exception
        If the upload manager cannot be instantiated.
    """
    account = gu.get_active_account()
    client_config = get_client_config(account)

    try:
        return DevUploadClient(DevClient(**client_config))
    except Exception as _e:
        LOG.debug(f"An error of type '{type(_e).__name__}' occurred while constructing Rucio's upload manager: {_e}\n")

        # Get the full traceback for debugging:
        traceback.print_exc()

        raise


def download_manager():
    """
    Return a download client for the configured account.

    Configuration for the account defined in ``rucio.global_utils`` is loaded
    with `get_client_config`. The resulting `~rucio.overridden_rucio_client.DevDownloadClient`
    wraps a `~rucio.overridden_rucio_client.DevClient`.

    Returns
    -------
    DevDownloadClient
        Client capable of downloading files from the development Rucio environment.

    Raises
    ------
    Exception
        If the download manager cannot be instantiated.
    """
    account = gu.get_active_account()
    client_config = get_client_config(account)

    try:
        return DevDownloadClient(DevClient(**client_config))
    except Exception as _e:
        LOG.debug(
            f"An error of type '{type(_e).__name__}' occurred while constructing Rucio's download manager: {_e}\n")

        # Get the full traceback for debugging:
        traceback.print_exc()

        raise


def validate_metadata(pname, metadata, schema_fname, schema):
    """
    Validate ``metadata`` against ``schema`` and log the result.

    Parameters
    ----------
    pname : str
        Name of the dataset being validated. Used only for logging.
    metadata : dict
        The dataset metadata to validate.
    schema_fname : str
        Filename of the schema, included in log messages.
    schema : dict
        JSON schema describing the expected structure of ``metadata``.

    Returns
    -------
    bool
        ``True`` if validation succeeds, otherwise ``False``. Any validation
        error or unexpected exception is logged.
    """
    try:
        is_valid = validate_json(json_data=metadata, json_schema=schema)
        if is_valid:
            LOG.debug(f"'{pname}' content are valid against schema '{schema_fname}'.\n")  # WinClient
            return True
        else:
            LOG.warning(f"'{pname}' content are not valid against schema '{schema_fname}'.\n")  # WinClient
    except Exception as e:
        LOG.error(f"An unexpected error of type '{type(e).__name__}' occurred "
                  f"while validating '{pname}' against '{schema_fname}': {e}\n")
    return False


def validate_json(json_data: dict, json_schema: dict) -> bool:
    """
    Validates a JSON object against a JSON schema.

    Args:
        json_data (dict): The JSON data to be validated.
        json_schema (dict): The JSON schema to validate against.

    Returns:
        bool: True if the JSON data is valid, False otherwise.
    """
    try:
        validate(instance=json_data, schema=json_schema)
        return True
    except ValidationError as e:
        LOG.debug("Validation Error Message: %s", e.message)  # WinClient
        LOG.debug("Validator that failed: %s", e.validator)  # WinClient
        LOG.debug("Path to the failing element in instance: %s", list(e.path))  # WinClient
        LOG.warning("Path to the failing element in schema: %s", list(e.schema_path))  # WinClient
        LOG.debug("Check the schema used: %s", e.schema)  # WinClient
        LOG.debug("Check the invalid instance: %s", e.instance)  # WinClient
        # LOG.warning(jsn.dumps(json_data, indent=2))  # WinClient
        return False


def get_json_tests():
    """
        Iterate over all value-test content.
    """
    value_tests_path = package_root_path / "helpers" / "metadata_management" / "Insertion" / "Partial" / "value_tests"

    for json_file in value_tests_path.glob("*.json"):
        LOG.debug(f"Processing file: {json_file.name}")

        with open(json_file, 'r') as file:
            json_value = jsn.load(file)
            # LOG.debug(jsn.dumps(json_value, indent=2))
            yield json_value

    # Assess now other extreme cases
    yield "json_value"
