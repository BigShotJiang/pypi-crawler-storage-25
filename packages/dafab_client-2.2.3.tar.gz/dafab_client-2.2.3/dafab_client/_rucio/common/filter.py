# Copyright European Organization for Nuclear Research (CERN) since 2012
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json
from dataclasses import dataclass, field
from typing import Any, Literal, Union


@dataclass
class EnhancedFilter:
    """Base class for all filter types."""

    def to_dict(self) -> dict:
        """Convert the filter to a dictionary representation."""
        raise NotImplementedError

    def to_json(self, indent: int = 2) -> str:
        """Convert the filter to a JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    def __str__(self) -> str:
        return self.to_json()


@dataclass
class ComparisonFilter(EnhancedFilter):
    """Filter for field comparisons."""
    comparator: str
    path: list[Union[str, int]]
    value: Any
    valueType: str = None  # noqa: N815 - keep external/query field naming

    def to_dict(self) -> dict:
        base_dict = {
            "type": "comparison",
            "comparator": self.comparator,
            "path": self.path,
            "value": self.value
        }
        if self.valueType:
            base_dict["valueType"] = self.valueType
        return base_dict


@dataclass
class LogicalFilter(EnhancedFilter):
    """Filter for combining multiple filters with logical operations."""
    combinator: Literal["and", "or", "not"]
    filters: list[Union['LogicalFilter', ComparisonFilter]] = field(default_factory=list)

    def __post_init__(self):
        if self.combinator == "not" and len(self.filters) != 1:
            raise ValueError("NOT combinator must have exactly one filter")

    def to_dict(self) -> dict:
        return {
            "type": "logical",
            "combinator": self.combinator,
            "filters": [f.to_dict() for f in self.filters]
        }

    def add_filter(self, filter_obj: Union['LogicalFilter', ComparisonFilter]):
        """Add a filter to the filters list."""
        if self.combinator == "not" and self.filters:
            raise ValueError("NOT combinator cannot accept additional filters")
        self.filters.append(filter_obj)


def create_date_range_filter(
        dt_start: str,
        dt_end: str,
        time_field: str = "datetime",
        time_path: list[Union[str, int]] | None = None,
) -> LogicalFilter:
    """Create a date range filter on a metadata timestamp field."""
    path = time_path if time_path is not None else ["properties", time_field]
    return LogicalFilter(
        combinator="and",
        filters=[
            ComparisonFilter(
                comparator="greaterThanOrEqual",
                path=path,
                value=dt_start,
                valueType="date"
            ),
            ComparisonFilter(
                comparator="lessThanOrEqual",
                path=path,
                value=dt_end,
                valueType="date"
            )
        ]
    )


def create_bbox_filter_intersects(
        min_long: float,
        min_lat: float,
        max_long: float,
        max_lat: float
) -> LogicalFilter:
    """Create a filter that keeps items whose STAC ``bbox`` intersects the area.

    The STAC specification orders bounding boxes as ``[west, south, east, north]``;
    the inputs mirror that convention via ``min_long``, ``min_lat``, ``max_long``,
    and ``max_lat``. An item is considered disjoint when its western edge is east of
    ``max_long`` or its southern edge is north of ``max_lat``, etc. This filter wraps
    that disjoint condition in a NOT block so only intersecting items remain.
    """
    # disjoint if any of these:
    # west > max_long  OR  south > max_lat  OR  east < min_long  OR  north < min_lat
    return LogicalFilter(
        combinator="not",
        filters=[
            LogicalFilter(
                combinator="or",
                filters=[
                    ComparisonFilter(comparator="greaterThan", path=["bbox", 0], value=max_long, valueType="number"),
                    ComparisonFilter(comparator="greaterThan", path=["bbox", 1], value=max_lat, valueType="number"),
                    ComparisonFilter(comparator="lessThan", path=["bbox", 2], value=min_long, valueType="number"),
                    ComparisonFilter(comparator="lessThan", path=["bbox", 3], value=min_lat, valueType="number"),
                ],
            )
        ],
    )


def create_bbox_filter_within(
        min_long: float,
        min_lat: float,
        max_long: float,
        max_lat: float
) -> LogicalFilter:
    """Create a filter that keeps items entirely within a STAC ``bbox``.

    Bounding boxes follow the STAC ordering ``[west, south, east, north]``. The
    logic removes any item whose bounding box falls outside the requested area.
    """
    # outside if: west < min_long OR south < min_lat OR east > max_long OR north > max_lat
    return LogicalFilter(
        combinator="not",
        filters=[
            LogicalFilter(
                combinator="or",
                filters=[
                    ComparisonFilter(comparator="lessThan", path=["bbox", 0], value=min_long, valueType="number"),
                    ComparisonFilter(comparator="lessThan", path=["bbox", 1], value=min_lat, valueType="number"),
                    ComparisonFilter(comparator="greaterThan", path=["bbox", 2], value=max_long, valueType="number"),
                    ComparisonFilter(comparator="greaterThan", path=["bbox", 3], value=max_lat, valueType="number"),
                ],
            )
        ],
    )


def create_bbox_filter_contains(
        min_long: float,
        min_lat: float,
        max_long: float,
        max_lat: float
) -> LogicalFilter:
    """Create a filter that keeps items containing a requested STAC ``bbox``."""
    # keep when: west <= min_long AND south <= min_lat AND east >= max_long AND north >= max_lat
    return LogicalFilter(
        combinator="and",
        filters=[
            ComparisonFilter(comparator="lessThan", path=["bbox", 0], value=min_long, valueType="number"),
            ComparisonFilter(comparator="lessThan", path=["bbox", 1], value=min_lat, valueType="number"),
            ComparisonFilter(comparator="greaterThan", path=["bbox", 2], value=max_long, valueType="number"),
            ComparisonFilter(comparator="greaterThan", path=["bbox", 3], value=max_lat, valueType="number"),
        ],
    )


def create_aoi_date_filter(
        dt_start: str,
        dt_end: str,
        min_long: float,
        min_lat: float,
        max_long: float,
        max_lat: float,
        time_field: str = "datetime",
        time_path: list[Union[str, int]] | None = None,
) -> LogicalFilter:
    """Create a combined AOI and date filter."""
    return LogicalFilter(
        combinator="and",
        filters=[
            create_date_range_filter(dt_start, dt_end, time_field=time_field, time_path=time_path),
            create_bbox_filter_intersects(min_long, min_lat, max_long, max_lat)
        ]
    )
