import inspect
import logging
import os
from typing import Optional

import urllib3
from dafab_client._rucio.common.utils import setup_logger as _rucio_setup_logger

# Select the default profile account. Can be overridden via `DAFAB_PROFILE`.
_ACCOUNT = (os.getenv("DAFAB_PROFILE") or "user_dafab").strip() or "user_dafab"

debug_mode = False
minimal_logging = True  # If enabled, only the most basic logs will be displayed (overrides debug_mode selection)

# Custom log level used to surface essential results even when ``minimal_logging``
# is enabled.  Placed between ``INFO`` and ``WARNING`` so it is hidden in
# ``minimal_logging`` mode but visible above ``ERROR``.
RESULT_LEVEL = logging.INFO + 5
logging.addLevelName(RESULT_LEVEL, "RESULT")


def result(self: logging.Logger, message: str, *args, **kwargs) -> None:
    """Log 'message' with level ``RESULT_LEVEL``."""

    if self.isEnabledFor(RESULT_LEVEL):
        self._log(RESULT_LEVEL, message, args, **kwargs)


logging.Logger.result = result  # type: ignore[attr-defined]
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def setup_logger(module_name: Optional[str] = None) -> logging.Logger:
    """Return a logger configured according to the global flags."""

    logger_level = logging.INFO
    if minimal_logging:
        # Show warnings and errors as well as essential RESULT messages.
        logger_level = RESULT_LEVEL
    elif debug_mode:
        logger_level = logging.DEBUG

    logger = _rucio_setup_logger(module_name, logger_level=logger_level)
    logger.propagate = False
    return logger


# Configure the default logger for this module on import
LOG = setup_logger(__name__)


def get_active_account() -> str:
    return _ACCOUNT


def set_active_account(account: str) -> str:
    global _ACCOUNT

    if not isinstance(account, str):
        raise TypeError("Account name must be a string")

    normalized = account.strip()
    if not normalized:
        raise ValueError("Account name cannot be empty")

    _ACCOUNT = normalized
    return _ACCOUNT


def show_caller(force=False) -> None:
    """
    Logs the current function's name and the caller's details (function, module, file, and line number).
    """
    try:
        # Get the current function's name (one level up in the stack)
        current_frame = inspect.currentframe()
        if current_frame is None:
            if force:
                LOG.info("Unable to retrieve the current frame.")
            else:
                LOG.debug("Unable to retrieve the current frame.")
            return

        current_function = current_frame.f_back.f_code.co_name  # type: ignore[union-attr]

        # Get the caller of the caller (two levels up in the stack)
        caller = inspect.stack()[2]
        module = inspect.getmodule(caller.frame)
        module_name = module.__name__ if module else "UnknownModule"

        caller_info = f"{module_name}.{caller.function} in {caller.filename}:{caller.lineno}"
        if force:
            LOG.info(f"{current_function} called by: {caller_info}")
        else:
            LOG.debug(f"{current_function} called by: {caller_info}")

    except Exception as e:
        if force:
            LOG.info(f"Exception occurred when getting caller: {e}")
        else:
            LOG.debug(f"Exception occurred when getting caller: {e}")
