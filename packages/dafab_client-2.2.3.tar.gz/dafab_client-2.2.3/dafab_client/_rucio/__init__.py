"""Internal vendored Rucio modules used by dafab_client."""
