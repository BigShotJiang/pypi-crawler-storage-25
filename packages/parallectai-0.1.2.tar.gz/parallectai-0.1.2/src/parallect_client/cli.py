from __future__ import annotations

import argparse
import getpass

from .config import ClientConfig, load_config, save_config
from .http import ApiClient
from .aggregator import run_aggregator
from .worker import run_worker


def main() -> None:
    parser = argparse.ArgumentParser(prog="parallect")
    subparsers = parser.add_subparsers(dest="command", required=True)

    login_parser = subparsers.add_parser("login")
    login_parser.add_argument("--api-url", default="http://localhost:3000")
    login_parser.add_argument("--token")

    start_parser = subparsers.add_parser("start")
    start_parser.add_argument("--once", action="store_true")
    start_parser.add_argument(
        "--mode",
        choices=["worker", "aggregator"],
        default="worker",
        help="Run as a shard worker or an aggregator node.",
    )

    args = parser.parse_args()

    if args.command == "login":
        token = args.token or getpass.getpass("Parallect API token: ")
        save_config(ClientConfig(api_url=args.api_url, token=token.strip()))
        print("Logged in.")
        return

    if args.command == "start":
        config = load_config()
        if args.mode == "aggregator":
            run_aggregator(ApiClient(config.api_url, config.token), once=args.once)
        else:
            run_worker(ApiClient(config.api_url, config.token), once=args.once)
        return
