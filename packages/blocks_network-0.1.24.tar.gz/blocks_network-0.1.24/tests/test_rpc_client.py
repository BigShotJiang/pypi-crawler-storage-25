"""Tests for blocks_network.rpc_client -- JSON-RPC transport."""

from __future__ import annotations

import json
from io import BytesIO
from unittest.mock import MagicMock, patch

import pytest

from blocks_network.auth_provider import StaticAuthProvider
from blocks_network.rpc_client import RpcError, call_rpc, rpc_endpoint, with_retry


# ============================================================================
# rpc_endpoint
# ============================================================================


class TestRpcEndpoint:
    def test_raises_without_base_url(self):
        with pytest.raises(ValueError, match="base_url is required"):
            rpc_endpoint("sub-c-abc123")

    def test_url_with_base_url(self):
        url = rpc_endpoint("sub-c-abc123", base_url="http://localhost:3001")
        assert url == "http://localhost:3001/api/v1/rpc"

    def test_url_with_base_url_trailing_slash(self):
        url = rpc_endpoint("sub-c-abc123", base_url="http://localhost:3001/")
        assert url == "http://localhost:3001/api/v1/rpc"


# ============================================================================
# call_rpc
# ============================================================================


def _make_urlopen_response(body: dict, status: int = 200) -> MagicMock:
    """Create a mock response for urllib.request.urlopen."""
    resp = MagicMock()
    encoded = json.dumps(body).encode("utf-8")
    resp.read.return_value = encoded
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


class TestCallRpc:
    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_sends_correct_json_rpc_envelope(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(
            {"jsonrpc": "2.0", "id": "x", "result": {"ok": True}}
        )

        result = call_rpc("sub-c-test", "MyMethod", {"key": "val"}, base_url="http://localhost:3001")

        assert result == {"ok": True}

        # Verify the request was constructed correctly
        req = mock_urlopen.call_args[0][0]
        assert req.full_url == "http://localhost:3001/api/v1/rpc"
        assert req.method == "POST"

        body = json.loads(req.data.decode("utf-8"))
        assert body["jsonrpc"] == "2.0"
        assert body["method"] == "MyMethod"
        assert body["params"] == {"key": "val"}
        assert "id" in body

    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_no_auth_header_by_default(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(
            {"jsonrpc": "2.0", "id": "x", "result": None}
        )

        call_rpc("sub-c-test", "Ping", {}, base_url="http://localhost:3001")

        req = mock_urlopen.call_args[0][0]
        assert "Authorization" not in req.headers

    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_auth_header_when_provider_supplies_token(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(
            {"jsonrpc": "2.0", "id": "x", "result": None}
        )

        call_rpc(
            "sub-c-test",
            "Ping",
            {},
            base_url="http://localhost:3001",
            auth_provider=StaticAuthProvider("jwt-abc"),
        )

        req = mock_urlopen.call_args[0][0]
        assert req.headers["Authorization"] == "Bearer jwt-abc"

    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_happy_path_result_extraction(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(
            {"jsonrpc": "2.0", "id": "x", "result": {"taskId": "t-1", "queued": True}}
        )

        result = call_rpc("sub-c-test", "SendMessage", {"agentName": "echo"}, base_url="http://localhost:3001")

        assert result["taskId"] == "t-1"
        assert result["queued"] is True

    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_json_rpc_error_raises_rpc_error(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(
            {
                "jsonrpc": "2.0",
                "id": "x",
                "error": {
                    "code": -32600,
                    "message": "Invalid Request",
                    "data": {"message": "Missing agentName"},
                },
            }
        )

        with pytest.raises(RpcError) as exc_info:
            call_rpc("sub-c-test", "SendMessage", {}, base_url="http://localhost:3001")

        assert exc_info.value.rpc_message == "Missing agentName"
        assert exc_info.value.code == -32600

    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_json_rpc_error_fallback_message(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(
            {
                "jsonrpc": "2.0",
                "id": "x",
                "error": {"code": -32000, "message": "Server error"},
            }
        )

        with pytest.raises(RpcError) as exc_info:
            call_rpc("sub-c-test", "SendMessage", {}, base_url="http://localhost:3001")

        assert exc_info.value.rpc_message == "Server error"

    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_uses_custom_base_url(self, mock_urlopen):
        mock_urlopen.return_value = _make_urlopen_response(
            {"jsonrpc": "2.0", "id": "x", "result": {"ok": True}}
        )

        call_rpc("sub-c-test", "MyMethod", {"key": "val"}, base_url="http://localhost:8080")

        req = mock_urlopen.call_args[0][0]
        assert req.full_url == "http://localhost:8080/api/v1/rpc"

    @patch("blocks_network.rpc_client.urllib.request.urlopen")
    def test_http_error_raises_rpc_error(self, mock_urlopen):
        import urllib.error

        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="http://localhost:3001/api/v1/rpc", code=500, msg="ISE", hdrs={}, fp=BytesIO(b"")
        )

        with pytest.raises(RpcError) as exc_info:
            call_rpc("sub-c-test", "SendMessage", {}, base_url="http://localhost:3001")

        assert exc_info.value.rpc_message == "HTTP 500"
        assert exc_info.value.code == 500

    def test_raises_without_base_url(self):
        with pytest.raises(ValueError, match="base_url is required"):
            call_rpc("sub-c-test", "SendMessage", {})


# ============================================================================
# with_retry
# ============================================================================


class TestWithRetry:
    @patch("blocks_network.rpc_client.time.sleep")
    def test_retries_on_transient_error(self, mock_sleep):
        call_count = 0

        def flaky():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise OSError("ECONNRESET")
            return "ok"

        result = with_retry(flaky, max_retries=3, base_delay=0.0)
        assert result == "ok"
        assert call_count == 3

    def test_no_retry_on_non_transient_error(self):
        call_count = 0

        def bad():
            nonlocal call_count
            call_count += 1
            raise ValueError("bad input")

        with pytest.raises(ValueError, match="bad input"):
            with_retry(bad, max_retries=3, base_delay=0.0)

        assert call_count == 1

    @patch("blocks_network.rpc_client.time.sleep")
    def test_raises_after_max_retries_exhausted(self, mock_sleep):
        def always_transient():
            raise OSError("ETIMEDOUT")

        with pytest.raises(OSError, match="ETIMEDOUT"):
            with_retry(always_transient, max_retries=2, base_delay=0.0)
