"""
JSON-RPC 2.0 transport for PubNub Functions RPC gateway.

Port of ``rpc-client.ts``.

Provides:
- :func:`rpc_endpoint` -- builds the RPC gateway URL from a subscribe key
- :func:`call_rpc` -- sends a JSON-RPC 2.0 request with retry and error handling
- :class:`RpcError` -- structured error for JSON-RPC error responses
"""

from __future__ import annotations

import json
import random
import ssl
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Dict, Optional, TypeVar

import certifi

from .protocol_version import CURRENT_PROTOCOL_VERSION, PROTOCOL_VERSION_HEADER
from .write_affinity import capture_affinity, inject_affinity

T = TypeVar("T")

# ============================================================================
# RPC Error
# ============================================================================


class RpcError(Exception):
    """Structured error for JSON-RPC error responses."""

    def __init__(
        self,
        rpc_message: str,
        code: Optional[int] = None,
        data: Any = None,
    ) -> None:
        super().__init__(f"[RPC] {rpc_message}")
        self.rpc_message = rpc_message
        self.code = code
        self.data = data


# ============================================================================
# RPC Endpoint
# ============================================================================


def rpc_endpoint(subscribe_key: str, base_url: Optional[str] = None) -> str:
    """Build the RPC gateway URL from a backend root URL."""
    if not base_url:
        raise ValueError(
            "[RPC] base_url is required. Provide it via CDM config or pass base_url explicitly."
        )
    return f"{base_url.rstrip('/')}/api/v1/rpc"


# ============================================================================
# Retry Helper
# ============================================================================

_TRANSIENT_MARKERS = ("ENOTFOUND", "ETIMEDOUT", "ECONNRESET", "NetworkIssues")


def _is_transient(err: BaseException) -> bool:
    """Return ``True`` if the error looks like a transient network issue."""
    err_str = str(err)
    return any(marker in err_str for marker in _TRANSIENT_MARKERS)


def with_retry(
    fn: Callable[[], T],
    max_retries: int = 3,
    base_delay: float = 0.5,
) -> T:
    """Retry *fn* with exponential back-off on transient network errors."""
    last_error: Optional[BaseException] = None
    for attempt in range(max_retries):
        try:
            return fn()
        except Exception as err:
            last_error = err
            if not _is_transient(err) or attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt) + random.random() * 0.1
            time.sleep(delay)
    raise last_error  # type: ignore[misc]


# ============================================================================
# callRpc
# ============================================================================


def call_rpc(
    subscribe_key: str,
    method: str,
    params: Dict[str, Any],
    base_url: Optional[str] = None,
    agent_auth: Any = None,
    auth_provider: Any = None,
) -> Any:
    """Send a JSON-RPC 2.0 request to the PubNub Functions RPC gateway.

    Returns the ``result`` field from the JSON-RPC response.
    Raises :class:`RpcError` on HTTP or JSON-RPC errors.

    When ``agent_auth`` is provided, uses its ``authenticated_request()``
    for automatic 401 retry with token refresh.

    When ``auth_provider`` is provided, uses its ``get_auth_header()``
    for the Authorization header and ``on_auth_failure()`` for 401 retry.
    """
    url = rpc_endpoint(subscribe_key, base_url)
    request_id = f"rpc-{int(time.time() * 1000)}-{random.randbytes(4).hex()}"

    rpc_payload = json.dumps(
        {"jsonrpc": "2.0", "id": request_id, "method": method, "params": params}
    ).encode("utf-8")

    def _parse_rpc_response(data: Any) -> Any:
        if isinstance(data, dict) and data.get("error"):
            err = data["error"]
            message = (
                (err.get("data") or {}).get("message")
                or err.get("message")
                or "Unknown RPC error"
            )
            raise RpcError(message, err.get("code"), err.get("data"))
        return data.get("result") if isinstance(data, dict) else data

    if agent_auth is not None:
        def _do_auth_request() -> Any:
            resp_data, _status = agent_auth.authenticated_request(
                url,
                method="POST",
                body=rpc_payload,
                headers={
                    "Content-Type": "application/json",
                    PROTOCOL_VERSION_HEADER: CURRENT_PROTOCOL_VERSION,
                },
            )
            return _parse_rpc_response(resp_data)

        return with_retry(_do_auth_request)

    def _build_headers() -> Dict[str, str]:
        hdrs: Dict[str, str] = {
            "Content-Type": "application/json",
            PROTOCOL_VERSION_HEADER: CURRENT_PROTOCOL_VERSION,
        }
        if auth_provider is not None:
            auth_header = auth_provider.get_auth_header()
            if auth_header:
                hdrs["Authorization"] = auth_header
        inject_affinity(hdrs)
        return hdrs

    def _execute_request(hdrs: Dict[str, str]) -> Any:
        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        req = urllib.request.Request(url, data=rpc_payload, headers=hdrs, method="POST")

        try:
            with urllib.request.urlopen(req, context=ssl_ctx, timeout=30) as resp:
                capture_affinity(resp)
                body = resp.read().decode("utf-8")
                data = json.loads(body) if body else {}
        except urllib.error.HTTPError as exc:
            raise RpcError(f"HTTP {exc.code}", exc.code) from exc
        except urllib.error.URLError as exc:
            raise RpcError(str(exc.reason)) from exc

        return _parse_rpc_response(data)

    def _do_request() -> Any:
        hdrs = _build_headers()
        try:
            return _execute_request(hdrs)
        except RpcError as err:
            # 401 reactive refresh: retry once if auth_provider can refresh
            if err.code == 401 and auth_provider is not None:
                if auth_provider.on_auth_failure():
                    return _execute_request(_build_headers())
            raise

    return with_retry(_do_request)
