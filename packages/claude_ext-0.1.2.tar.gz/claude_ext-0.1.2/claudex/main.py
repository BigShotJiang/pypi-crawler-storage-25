import sys
import subprocess
from dotenv import load_dotenv, find_dotenv
import os


def run_claude(token: str | None, base_url: str, model: str | None):
    if token:
        os.environ["ANTHROPIC_AUTH_TOKEN"] = token

    os.environ["ANTHROPIC_BASE_URL"] = base_url
    os.environ["ANTHROPIC_API_KEY"] = ""
    os.environ["CLAUDE_CODE_ATTRIBUTION_HEADER"] = "0"
    os.environ["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] = "1"

    if model:
        os.environ["ANTHROPIC_MODEL"] = model

    args = sys.argv[1:]
    subprocess.run(["claude"] + args)


def run_claude_openrouter():
    load_dotenv(find_dotenv(usecwd=True))

    if "OPENROUTER_API_KEY" not in os.environ:
        print("Error: OPENROUTER_API_KEY is not set in the environment.")
        sys.exit(1)

    token = os.environ["OPENROUTER_API_KEY"]
    base_url = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api")
    if os.getenv("OPENROUTER_PROXY") == "1" and "OPENROUTER_BASE_URL" not in os.environ:
        base_url = "https://openrouter.x-infra.dev/api"
    model = os.getenv("OPENROUTER_MODEL")

    run_claude(token or "ollama", base_url, model)


OLLAMA_DEFAULT_MODEL = "qwen3.6"


def run_claude_ollama():
    load_dotenv(find_dotenv(usecwd=True))

    token = os.getenv("OLLAMA_API_KEY", "ollama")
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

    model = os.getenv("OLLAMA_MODEL", OLLAMA_DEFAULT_MODEL)

    print(token, base_url, model)
    run_claude(token, base_url, model)


def main():
    load_dotenv(find_dotenv(usecwd=True))

    api = os.getenv("CLAUDE_API", "openrouter").lower().strip()

    if api == "openrouter" or api == "or" or api == "":
        run_claude_openrouter()
    elif api == "proxy" or api == "or-proxy" or api == "openrouter-proxy":
        os.environ["OPENROUTER_PROXY"] = "1"
        run_claude_openrouter()
    elif api == "ollama":
        run_claude_ollama()
    else:
        print(
            f"Error: Unsupported CLAUDE_API '{api}'. Supported values are 'openrouter' and 'ollama'."
        )
        sys.exit(1)
