# Changelog

All notable changes to `keel-llm-reliability` are documented here, following
[Keep a Changelog](https://keepachangelog.com/). In `0.x`; pin exact versions.

## [Unreleased]

## [0.1.0] - 2026-05-22

### Added

- Two reliability strategies for multi-model LLM calls:
  - `fan_out` (quorum/parallel) — preempt unavailable/throttled models, dispatch
    survivors concurrently (single-shot, no retries), keep every success. Grounded
    in LLMCouncil's production fan-out (PR #77).
  - `failover` (primary + ordered fallbacks) — first success wins; category-
    dispatched, with opt-in **bounded, transient-only** same-provider retry
    (`transient_retries`, default 0). For the single-answer broad base.
- `ResilientClient` — high-level entrypoint binding adapters + injected
  collaborators + policy; exposes both strategies.
- **Transparent degradation:** every provider interaction is a visible `Attempt`
  (`success` / `preempted_open` / `preempted_limited` / `deferred_backpressure` /
  `failed`, with `error.category` and `latency_ms`). No silent retries/fallbacks;
  exhaustion returns visibly.
- **Category dispatch:** `backpressure` defers (never a breaker failure),
  `transient` records a breaker failure. `terminal` fails fast — request-level
  (`BadRequest`/`ContextLength`/`ContentFilter`) records nothing, but
  `Authentication` *does* record (a bad key is persistent, model-level, not
  request-level). A 200 with no usable output (no text and no tool calls) is the
  `empty` disposition — "up but mute," counts against health, never a `success`.
  (Auth-split + empty-handling grounded in LLMCouncil's production quorum oracle.)
- **Injected async collaborators:** `Breaker` / `Limiter` protocols (async, so a
  Redis-backed cross-worker implementation can satisfy them) + `InProcessBreaker`
  default (async shim over `keel-circuit-breaker`). Process-local state today
  swaps to shared state at scale without touching the orchestrator.
- PEP 561 `py.typed`; `mypy --strict` clean.

### Notes

- Composes `keel-llm-protocol` (taxonomy) + `keel-circuit-breaker` (in-process
  breaker), which stay independently usable. Quorum behavior was co-designed with
  the LLMCouncil product team against its production fan-out; the architectural
  recalibration (a high-level entrypoint that owns the call loop is fine, *under*
  the value-bars: transparent degradation + injected collaborators + observability
  + category-dispatch) is recorded in ADR-0004.
