"""Tests for keel-llm-reliability — both strategies, category dispatch, transparency.

Fakes conform to keel-llm-protocol's ModelAdapter / Breaker / Limiter, so these
also prove the composition wires together correctly.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence

from keel_llm_protocol import (
    AdapterResponse,
    AuthenticationError,
    BadRequestError,
    HealthStatus,
    Message,
    ModelAdapter,
    RateLimitError,
    ResponseFormat,
    TransientError,
    user,
)

from keel_llm_reliability import (
    Breaker,
    InProcessBreaker,
    Request,
    ResilientClient,
    failover,
    fan_out,
)


# --------------------------------------------------------------------------- #
# Fakes
# --------------------------------------------------------------------------- #


def resp(key: str, text: str = "ok") -> AdapterResponse:
    return AdapterResponse(text=text, model_key=key, model_id=key)


class FakeAdapter:
    """Returns/raises a programmed sequence of actions, one per generate() call."""

    def __init__(self, key: str, actions: Sequence[AdapterResponse | Exception]) -> None:
        self._key = key
        self._actions = list(actions)
        self.calls = 0

    @property
    def model_key(self) -> str:
        return self._key

    @property
    def capabilities(self) -> frozenset[str]:
        return frozenset()

    async def generate(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        action = self._actions[min(self.calls, len(self._actions) - 1)]
        self.calls += 1
        if isinstance(action, Exception):
            raise action
        return action

    async def health_check(self) -> HealthStatus:
        return HealthStatus(self._key, healthy=True)


class RecordingBreaker:
    def __init__(self, available: dict[str, bool] | None = None) -> None:
        self._available = available or {}
        self.successes: list[str] = []
        self.failures: list[str] = []

    async def is_available(self, key: str) -> bool:
        return self._available.get(key, True)

    async def record_success(self, key: str) -> None:
        self.successes.append(key)

    async def record_failure(self, key: str) -> None:
        self.failures.append(key)


class FakeLimiter:
    def __init__(self, allow: dict[str, bool] | None = None) -> None:
        self._allow = allow or {}

    async def try_acquire(self, key: str) -> bool:
        return self._allow.get(key, True)


REQ = Request(messages=[user("hi")])


# --------------------------------------------------------------------------- #
# Composition / conformance
# --------------------------------------------------------------------------- #


def test_fakes_conform_to_protocols() -> None:
    assert isinstance(FakeAdapter("m", [resp("m")]), ModelAdapter)
    assert isinstance(InProcessBreaker(), Breaker)
    assert isinstance(RecordingBreaker(), Breaker)


# --------------------------------------------------------------------------- #
# fan_out (quorum)
# --------------------------------------------------------------------------- #


def test_fan_out_keeps_all_successes() -> None:
    b = RecordingBreaker()
    a1, a2 = FakeAdapter("a", [resp("a")]), FakeAdapter("b", [resp("b")])
    r = asyncio.run(fan_out([a1, a2], REQ, breaker=b))
    assert {x.model_key for x in r.successes} == {"a", "b"}
    assert r.degraded is False
    assert sorted(b.successes) == ["a", "b"]


def test_fan_out_preempts_open_and_limited() -> None:
    b = RecordingBreaker(available={"open": False})
    limiter = FakeLimiter(allow={"limited": False})
    adapters = [FakeAdapter("open", [resp("open")]), FakeAdapter("limited", [resp("limited")]), FakeAdapter("ok", [resp("ok")])]
    r = asyncio.run(fan_out(adapters, REQ, breaker=b, limiter=limiter))
    by_key = {a.model_key: a.outcome for a in r.attempts}
    assert by_key["open"] == "preempted_open"
    assert by_key["limited"] == "preempted_limited"
    assert by_key["ok"] == "success"
    # preempted adapters were never dispatched
    assert adapters[0].calls == 0 and adapters[1].calls == 0


def test_fan_out_backpressure_deferred_not_failed() -> None:
    b = RecordingBreaker()
    adapters = [FakeAdapter("a", [RateLimitError("429")]), FakeAdapter("b", [resp("b")])]
    r = asyncio.run(fan_out(adapters, REQ, breaker=b))
    by_key = {a.model_key: a.outcome for a in r.attempts}
    assert by_key["a"] == "deferred_backpressure"
    assert "a" not in b.failures  # throttled != failed
    assert [x.model_key for x in r.successes] == ["b"]
    assert r.degraded is True


def test_fan_out_transient_records_breaker_failure() -> None:
    b = RecordingBreaker()
    asyncio.run(fan_out([FakeAdapter("a", [TransientError("503")])], REQ, breaker=b))
    assert b.failures == ["a"]


def test_fan_out_request_level_terminal_does_not_record() -> None:
    b = RecordingBreaker()
    r = asyncio.run(fan_out([FakeAdapter("a", [BadRequestError("400")])], REQ, breaker=b))
    assert r.attempts[0].outcome == "failed"
    assert b.failures == []  # bad-request is about THIS request, not model health


def test_fan_out_auth_records_breaker_failure() -> None:
    # Auth is the exception: persistent model-level (bad key fails every call) → record.
    b = RecordingBreaker()
    r = asyncio.run(fan_out([FakeAdapter("a", [AuthenticationError("401")])], REQ, breaker=b))
    assert r.attempts[0].outcome == "failed"
    assert b.failures == ["a"]


def test_fan_out_empty_content_is_not_success() -> None:
    # 200 with no usable output ("up but mute") — not a success; counts against health.
    b = RecordingBreaker()
    mute = AdapterResponse(text="", model_key="a", model_id="a")
    r = asyncio.run(fan_out([FakeAdapter("a", [mute])], REQ, breaker=b))
    assert r.attempts[0].outcome == "empty"
    assert r.successes == []
    assert b.failures == ["a"]


def test_fan_out_unexpected_exception_is_wrapped_and_visible() -> None:
    b = RecordingBreaker()
    r = asyncio.run(fan_out([FakeAdapter("a", [ValueError("bug")])], REQ, breaker=b))
    a = r.attempts[0]
    assert a.outcome == "failed"
    assert a.error is not None and a.error.category == "terminal"  # ProviderError-wrapped, visible


def test_fan_out_captures_latency() -> None:
    r = asyncio.run(fan_out([FakeAdapter("a", [resp("a")])], REQ, breaker=RecordingBreaker()))
    assert r.attempts[0].latency_ms >= 0


# --------------------------------------------------------------------------- #
# failover (primary + ordered fallbacks)
# --------------------------------------------------------------------------- #


def test_failover_first_success_short_circuits() -> None:
    b = RecordingBreaker()
    a1, a2 = FakeAdapter("a", [resp("a")]), FakeAdapter("b", [resp("b")])
    r = asyncio.run(failover([a1, a2], REQ, breaker=b))
    assert r.succeeded and r.response is not None and r.response.model_key == "a"
    assert a2.calls == 0  # never reached the fallback


def test_failover_request_level_terminal_moves_on_without_breaker_failure() -> None:
    b = RecordingBreaker()
    a1, a2 = FakeAdapter("a", [BadRequestError("400")]), FakeAdapter("b", [resp("b")])
    r = asyncio.run(failover([a1, a2], REQ, breaker=b))
    assert r.response is not None and r.response.model_key == "b"
    assert b.failures == []  # bad-request is request-level, not model health


def test_failover_transient_records_then_fails_over() -> None:
    b = RecordingBreaker()
    a1, a2 = FakeAdapter("a", [TransientError("503")]), FakeAdapter("b", [resp("b")])
    r = asyncio.run(failover([a1, a2], REQ, breaker=b))
    assert r.response is not None and r.response.model_key == "b"
    assert b.failures == ["a"]
    assert a1.calls == 1  # no retry at transient_retries=0


def test_failover_bounded_transient_retry_same_provider() -> None:
    b = RecordingBreaker()
    a1 = FakeAdapter("a", [TransientError("503"), resp("a")])  # fails then recovers
    r = asyncio.run(failover([a1], REQ, breaker=b, transient_retries=1))
    assert r.response is not None and r.response.model_key == "a"
    assert a1.calls == 2  # retried the same provider once
    # both interactions are visible attempts
    outcomes = [x.outcome for x in r.attempts]
    assert outcomes == ["failed", "success"]


def test_failover_backpressure_routes_immediately() -> None:
    b = RecordingBreaker()
    a1, a2 = FakeAdapter("a", [RateLimitError("429")]), FakeAdapter("b", [resp("b")])
    r = asyncio.run(failover([a1, a2], REQ, breaker=b, transient_retries=2))
    assert r.response is not None and r.response.model_key == "b"
    assert a1.calls == 1  # backpressure is NOT retried, even with retries enabled
    assert "a" not in b.failures
    assert r.attempts[0].outcome == "deferred_backpressure"


def test_failover_exhaustion_returns_none_with_visible_trail() -> None:
    b = RecordingBreaker()
    adapters = [FakeAdapter("a", [TransientError("503")]), FakeAdapter("b", [AuthenticationError("401")])]
    r = asyncio.run(failover(adapters, REQ, breaker=b))
    assert r.succeeded is False and r.response is None
    assert [x.outcome for x in r.attempts] == ["failed", "failed"]


def test_failover_preempts_open_then_uses_fallback() -> None:
    b = RecordingBreaker(available={"a": False})
    a1, a2 = FakeAdapter("a", [resp("a")]), FakeAdapter("b", [resp("b")])
    r = asyncio.run(failover([a1, a2], REQ, breaker=b))
    assert r.response is not None and r.response.model_key == "b"
    assert r.attempts[0].outcome == "preempted_open"
    assert a1.calls == 0


# --------------------------------------------------------------------------- #
# ResilientClient
# --------------------------------------------------------------------------- #


def test_client_defaults_to_inprocess_breaker() -> None:
    client = ResilientClient([FakeAdapter("a", [resp("a")])])
    r = asyncio.run(client.failover(REQ))
    assert r.succeeded


def test_client_fan_out_and_failover() -> None:
    client = ResilientClient([FakeAdapter("a", [resp("a")]), FakeAdapter("b", [resp("b")])])
    fo = asyncio.run(client.fan_out(REQ))
    assert len(fo.successes) == 2
    fv = asyncio.run(client.failover(REQ))
    assert fv.response is not None and fv.response.model_key == "a"


# --------------------------------------------------------------------------- #
# Quorum oracle invariants (LLMCouncil's validated behavior, real breaker)
# --------------------------------------------------------------------------- #


def test_all_backpressure_never_opens_circuit() -> None:
    """The +7/10 invariant: no number of 429s opens a model's circuit — the
    regression test that protects the whole reason this matters."""
    breaker = InProcessBreaker(failure_threshold=3)
    adapter = FakeAdapter("m", [RateLimitError("429")])  # always throttled
    last = None
    for _ in range(6):
        last = asyncio.run(fan_out([adapter], REQ, breaker=breaker))
        assert last.attempts[0].outcome == "deferred_backpressure"  # never preempted_open
    assert last is not None and last.successes == []


def test_health_threshold_opens_on_transient() -> None:
    breaker = InProcessBreaker(failure_threshold=3)
    adapter = FakeAdapter("m", [TransientError("503")])
    for _ in range(3):
        r = asyncio.run(fan_out([adapter], REQ, breaker=breaker))
        assert r.attempts[0].outcome == "failed"
    r = asyncio.run(fan_out([adapter], REQ, breaker=breaker))  # 3 failures → circuit open
    assert r.attempts[0].outcome == "preempted_open"


def test_health_threshold_opens_on_empty() -> None:
    breaker = InProcessBreaker(failure_threshold=3)
    adapter = FakeAdapter("m", [AdapterResponse(text="", model_key="m", model_id="m")])
    for _ in range(3):
        asyncio.run(fan_out([adapter], REQ, breaker=breaker))
    r = asyncio.run(fan_out([adapter], REQ, breaker=breaker))
    assert r.attempts[0].outcome == "preempted_open"  # "up but mute" counts toward health


def test_request_level_terminal_never_opens_circuit() -> None:
    breaker = InProcessBreaker(failure_threshold=3)
    adapter = FakeAdapter("m", [BadRequestError("400")])
    last = None
    for _ in range(5):
        last = asyncio.run(fan_out([adapter], REQ, breaker=breaker))
        assert last.attempts[0].outcome == "failed"  # never preempted (bad-request doesn't record)
    assert last is not None
