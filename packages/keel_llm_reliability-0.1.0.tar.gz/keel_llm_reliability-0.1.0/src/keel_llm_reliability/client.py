"""ResilientClient — the high-level entrypoint.

Binds the adapter set + injected collaborators + policy so callers don't re-pass
them every call, and exposes both strategies as bound methods. It owns the call
loop (fine — the value-bars, not a Position number, are what matter), but stays
**stateless**: all state lives in the injected breaker/limiter, so swapping in
Redis-backed collaborators later needs no change here.
"""

from __future__ import annotations

from collections.abc import Sequence

from keel_llm_protocol import ModelAdapter

from keel_llm_reliability.collaborators import Breaker, InProcessBreaker, Limiter
from keel_llm_reliability.core import (
    FailoverResult,
    FanOutResult,
    Request,
    failover,
    fan_out,
)

__all__ = ["ResilientClient"]


class ResilientClient:
    """Convenience over the ``fan_out`` / ``failover`` strategies.

    Defaults are batteries-included (an in-process breaker, no limiter, no
    retries); every collaborator and knob is overridable for scale.
    """

    def __init__(
        self,
        adapters: Sequence[ModelAdapter],
        *,
        breaker: Breaker | None = None,
        limiter: Limiter | None = None,
        transient_retries: int = 0,
    ) -> None:
        self._adapters = list(adapters)
        self._breaker: Breaker = breaker if breaker is not None else InProcessBreaker()
        self._limiter = limiter
        self._transient_retries = transient_retries

    async def fan_out(self, request: Request) -> FanOutResult:
        """Quorum: dispatch to all available candidates in parallel, keep every success."""
        return await fan_out(
            self._adapters, request, breaker=self._breaker, limiter=self._limiter
        )

    async def failover(self, request: Request) -> FailoverResult:
        """Primary + ordered failover: first success wins."""
        return await failover(
            self._adapters,
            request,
            breaker=self._breaker,
            limiter=self._limiter,
            transient_retries=self._transient_retries,
        )
