"""Injected collaborators — the breaker and (optional) limiter the orchestrator uses.

These are **async** structural protocols. The in-process breaker does no I/O and
returns immediately, but the protocol is async so a **Redis-backed** breaker (the
cross-worker capability that matters at scale) can satisfy the *same* protocol —
the orchestrator never knows which it got. A sync protocol would foreclose the
Redis implementation; async keeps the swap real (the keystone).

Collaborators are always **injected, never owned** by the orchestrator — that's
what lets process-local state today become shared state later without touching
the reliability logic.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from keel_circuit_breaker import CircuitBreaker, StructuredLogger

__all__ = ["Breaker", "InProcessBreaker", "Limiter"]


@runtime_checkable
class Breaker(Protocol):
    """Cross-call health gate, keyed by model. Async so a Redis-backed breaker fits."""

    async def is_available(self, key: str) -> bool: ...

    async def record_success(self, key: str) -> None: ...

    async def record_failure(self, key: str) -> None: ...


@runtime_checkable
class Limiter(Protocol):
    """Predictive rate gate, keyed by model. ``try_acquire`` returns False when the
    key's window is (predicted) full, so the orchestrator can preempt before dispatch."""

    async def try_acquire(self, key: str) -> bool: ...


class InProcessBreaker:
    """Default ``Breaker`` — an async shim over the (sync, zero-I/O) ``keel-circuit-breaker``.

    Zero-config, zero new dependencies: works out of the box for the broad base.
    The async methods return immediately (no real await); swap an actual
    Redis-backed breaker for cross-worker state when scale demands it.
    """

    def __init__(
        self,
        failure_threshold: int = 3,
        cooldown_seconds: float = 120.0,
        logger: StructuredLogger | None = None,
    ) -> None:
        self._cb = CircuitBreaker(
            failure_threshold=failure_threshold,
            cooldown_seconds=cooldown_seconds,
            logger=logger,
        )

    async def is_available(self, key: str) -> bool:
        return self._cb.is_available(key)

    async def record_success(self, key: str) -> None:
        self._cb.record_success(key)

    async def record_failure(self, key: str) -> None:
        self._cb.record_failure(key)
