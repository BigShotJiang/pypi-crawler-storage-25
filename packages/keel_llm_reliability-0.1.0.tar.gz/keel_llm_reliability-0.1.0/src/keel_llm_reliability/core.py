"""Request/result types and the two reliability strategies.

Both strategies follow the same validated philosophy (LLMCouncil PR #77):
**preempt > block; visible degradation > hidden retries.** Every provider
interaction becomes a visible ``Attempt`` in the result, so an operator sees what
happened (preempted / deferred / failed / succeeded) rather than trusting an
answer that silently degraded.

Category dispatch (the +7/10 distinction):
- ``backpressure`` → defer (never a breaker failure; the model is healthy, throttled),
- ``transient`` → counts as a breaker failure; retry/fail over,
- ``terminal`` → fail this provider (request-level problem, not model health → no
  breaker failure recorded).
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Literal

from keel_llm_protocol import (
    AdapterError,
    AdapterResponse,
    AuthenticationError,
    Message,
    ModelAdapter,
    ProviderError,
    ResponseFormat,
)

from keel_llm_reliability.collaborators import Breaker, Limiter

__all__ = [
    "Attempt",
    "FailoverResult",
    "FanOutResult",
    "Outcome",
    "Request",
    "failover",
    "fan_out",
]

# The disposition of one provider interaction (what the orchestrator *did*).
# The *cause* lives in Attempt.error.category; outcome names the action.
Outcome = Literal[
    "success",
    "preempted_open",  # breaker open — skipped before dispatch
    "preempted_limited",  # limiter predicted full — skipped before dispatch
    "deferred_backpressure",  # dispatched, got 429 — deferred, NOT a failure
    "empty",  # dispatched, 200 with no usable output ("up but mute") — counts as failure
    "failed",  # dispatched, errored (group on error.category: transient vs terminal)
]


@dataclass
class Request:
    """A single generation request, applied uniformly to every candidate adapter."""

    messages: Sequence[Message]
    temperature: float | None = None
    max_tokens: int | None = None
    stop: Sequence[str] | None = None
    response_format: ResponseFormat | None = None


@dataclass
class Attempt:
    """One provider interaction, as data — the unit of transparent degradation."""

    model_key: str
    outcome: Outcome
    latency_ms: int = 0
    response: AdapterResponse | None = None
    error: AdapterError | None = None  # carries .category


@dataclass
class FanOutResult:
    """Result of quorum / parallel fan-out: every success kept."""

    successes: list[AdapterResponse]
    attempts: list[Attempt]

    @property
    def degraded(self) -> bool:
        """True if any candidate didn't contribute a success (generalizes judges_count)."""
        return any(a.outcome != "success" for a in self.attempts)


@dataclass
class FailoverResult:
    """Result of primary + ordered failover: the first success, or None if exhausted."""

    response: AdapterResponse | None
    attempts: list[Attempt]

    @property
    def succeeded(self) -> bool:
        return self.response is not None


def _ms(t0: float) -> int:
    return int((time.monotonic() - t0) * 1000)


async def _invoke(
    adapter: ModelAdapter, request: Request
) -> tuple[AdapterResponse | None, AdapterError | None, int]:
    """Call one adapter; never raise — return (response, error, latency_ms).

    Unexpected (non-``AdapterError``) exceptions are wrapped in ``ProviderError``
    so they're typed and *visible* in the result, never silently swallowed.
    """
    t0 = time.monotonic()
    try:
        resp = await adapter.generate(
            request.messages,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            stop=request.stop,
            response_format=request.response_format,
        )
        return resp, None, _ms(t0)
    except AdapterError as exc:
        return None, exc, _ms(t0)
    except Exception as exc:  # noqa: BLE001 - wrap, don't swallow; surfaced as a failed Attempt
        return None, ProviderError(str(exc), model_key=adapter.model_key, provider_error=exc), _ms(t0)


async def _preempt(
    adapter: ModelAdapter, breaker: Breaker, limiter: Limiter | None
) -> Attempt | None:
    """Predictive skip before dispatch. Returns a preemption Attempt, or None to proceed."""
    key = adapter.model_key
    if not await breaker.is_available(key):
        return Attempt(key, "preempted_open")
    if limiter is not None and not await limiter.try_acquire(key):
        return Attempt(key, "preempted_limited")
    return None


async def _record_outcome(
    adapter: ModelAdapter,
    breaker: Breaker,
    response: AdapterResponse | None,
    error: AdapterError | None,
    latency_ms: int,
) -> Attempt:
    """Apply category dispatch + breaker bookkeeping for a dispatched call; return the Attempt."""
    key = adapter.model_key
    if error is None:
        # A 200 with no usable output (no text AND no tool calls) is "up but mute" —
        # it produced nothing, so it is NOT a success. Counts against health so a
        # mute model gets deprioritized instead of re-dispatched to keep contributing
        # nothing (the silent-degradation trap).
        if response is not None and (response.text or response.tool_calls):
            await breaker.record_success(key)
            return Attempt(key, "success", latency_ms, response=response)
        await breaker.record_failure(key)
        return Attempt(key, "empty", latency_ms, response=response)
    if error.category == "backpressure":
        # Healthy but throttled — defer; never a breaker failure.
        return Attempt(key, "deferred_backpressure", latency_ms, error=error)
    if error.category == "transient":
        # Real, retryable failure — counts against model health.
        await breaker.record_failure(key)
        return Attempt(key, "failed", latency_ms, error=error)
    # terminal. Most terminal errors are request-level (bad-request / context-length /
    # content-filter) — about THIS request, not model health → no breaker failure.
    # Auth is the exception: a bad/expired key fails *every* call to the model until a
    # human fixes it (persistent, model-level) → record it so the circuit cuts the
    # waste from every-request to once-per-cooldown.
    if isinstance(error, AuthenticationError):
        await breaker.record_failure(key)
    return Attempt(key, "failed", latency_ms, error=error)


async def fan_out(
    adapters: Sequence[ModelAdapter],
    request: Request,
    *,
    breaker: Breaker,
    limiter: Limiter | None = None,
) -> FanOutResult:
    """Quorum strategy: preempt unavailable/throttled models, dispatch the survivors
    **concurrently, single-shot, no retries**, keep every success. Degradation is
    simply fewer successes — visible in ``attempts``. (LLMCouncil PR #77 mode.)"""
    attempts: list[Attempt] = []
    active: list[ModelAdapter] = []
    for adapter in adapters:
        pre = await _preempt(adapter, breaker, limiter)
        if pre is not None:
            attempts.append(pre)
        else:
            active.append(adapter)

    invocations = await asyncio.gather(*[_invoke(a, request) for a in active])

    successes: list[AdapterResponse] = []
    for adapter, (response, error, latency_ms) in zip(active, invocations):
        attempt = await _record_outcome(adapter, breaker, response, error, latency_ms)
        attempts.append(attempt)
        if attempt.outcome == "success" and response is not None:
            successes.append(response)
    return FanOutResult(successes=successes, attempts=attempts)


async def failover(
    adapters: Sequence[ModelAdapter],
    request: Request,
    *,
    breaker: Breaker,
    limiter: Limiter | None = None,
    transient_retries: int = 0,
) -> FailoverResult:
    """Primary + ordered failover: try candidates in order; first success wins and
    short-circuits. On a non-success, move to the next candidate.

    - ``backpressure`` → route to the next candidate immediately (skip the throttled one).
    - ``transient`` → optionally retry the **same** candidate up to ``transient_retries``
      (bounded, transient-only) before moving on; each retry is its own visible ``Attempt``.
    - ``terminal`` → fail this candidate, move on (no breaker failure recorded).

    Returns the first success, or ``response=None`` with the full ``attempts`` trail
    if exhausted. Never blocks/sleeps — exhaustion is visible, not hidden behind waits.
    """
    attempts: list[Attempt] = []
    for adapter in adapters:
        pre = await _preempt(adapter, breaker, limiter)
        if pre is not None:
            attempts.append(pre)
            continue
        tries = 0
        while True:
            response, error, latency_ms = await _invoke(adapter, request)
            attempt = await _record_outcome(adapter, breaker, response, error, latency_ms)
            attempts.append(attempt)
            if attempt.outcome == "success" and response is not None:
                return FailoverResult(response=response, attempts=attempts)
            # transient-only, bounded same-provider retry before failing over
            if (
                error is not None
                and error.category == "transient"
                and tries < transient_retries
            ):
                tries += 1
                continue
            break  # backpressure / terminal / exhausted transient → next candidate
    return FailoverResult(response=None, attempts=attempts)
