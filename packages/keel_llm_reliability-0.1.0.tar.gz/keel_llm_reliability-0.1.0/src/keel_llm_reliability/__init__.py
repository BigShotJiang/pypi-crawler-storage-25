"""keel-llm-reliability — composed reliability for multi-model LLM calls.

The consumer-side machinery that *acts* on the `keel-llm-protocol` taxonomy, so a
product gets production-grade multi-model reliability by composing bricks rather
than hand-writing a fan-out/failover loop.

Two first-class strategies, both grounded in production (LLMCouncil PR #77 for
quorum; primary+failover for the single-answer broad base):

- **`fan_out`** (quorum) — preempt unavailable/throttled models, dispatch survivors
  concurrently (single-shot, no retries), keep every success.
- **`failover`** (primary + ordered fallbacks) — first success wins; category-
  dispatched (defer backpressure / bounded transient retry / fail-fast terminal).

Cross-cutting guarantees (these are *value*, kept regardless of architecture):
- **Transparent degradation** — every provider interaction is a visible `Attempt`
  in the result (preempted / deferred / failed / succeeded + category + latency).
  Nothing is silently retried or masked.
- **Category dispatch** — backpressure defers (never a breaker failure), transient
  is a real failure, terminal fails fast.
- **Injected async collaborators** — the `Breaker`/`Limiter` are passed in, so
  process-local state today swaps to Redis-backed/shared state at scale untouched.

Composes `keel-llm-protocol` (types/taxonomy) + `keel-circuit-breaker` (the
in-process breaker, wrapped async by `InProcessBreaker`).
"""

from __future__ import annotations

from keel_llm_reliability.client import ResilientClient
from keel_llm_reliability.collaborators import Breaker, InProcessBreaker, Limiter
from keel_llm_reliability.core import (
    Attempt,
    FailoverResult,
    FanOutResult,
    Outcome,
    Request,
    failover,
    fan_out,
)

__all__ = [
    "ResilientClient",
    "fan_out",
    "failover",
    "Request",
    "Attempt",
    "Outcome",
    "FanOutResult",
    "FailoverResult",
    "Breaker",
    "Limiter",
    "InProcessBreaker",
]
