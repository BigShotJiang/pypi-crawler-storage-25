"""MCP protocol adapter for ChronicleMCP.

This module provides the MCP server interface using FastMCP.
All business logic is delegated to the HistoryService in the core layer.
"""

import functools
import json
import logging
from collections.abc import Callable
from typing import Any, TypedDict, TypeVar

from fastmcp import FastMCP

from chronicle_mcp.config import setup_logging
from chronicle_mcp.core import (
    BrowserNotFoundError,
    DatabaseError,
    DatabaseLockedError,
    HistoryService,
    PermissionDeniedError,
    ServiceError,
    ValidationError,
)
from chronicle_mcp.core.formatters import format_error_message

setup_logging()
logger = logging.getLogger(__name__)

mcp = FastMCP("Chronicle")

T = TypeVar("T", bound=Callable[..., str])


class SearchHistoryResult(TypedDict):
    results: list[tuple[str, str, int]]
    count: int
    query: str
    message: str


class RecentHistoryResult(TypedDict):
    results: list[tuple[str, str, int]]
    count: int
    hours: int
    message: str


class CountVisitsResult(TypedDict):
    domain: str
    browser: str
    count: int
    message: str


class TopDomainsResult(TypedDict):
    domains: list[tuple[str, int]]
    count: int
    message: str


class MostVisitedPagesResult(TypedDict):
    pages: list[tuple[str, str, int]]
    count: int
    message: str


class SearchByDateResult(TypedDict):
    results: list[tuple[str, str, int]]
    count: int
    query: str
    start_date: str
    end_date: str
    message: str


class AdvancedSearchResult(TypedDict):
    results: list[tuple[str, str, int]]
    count: int
    query: str
    options: dict[str, Any]
    message: str


class BrowserStatsResult(TypedDict):
    stats: dict[str, Any]
    message: str


class BookmarksResult(TypedDict):
    results: list[tuple[str, str]]
    count: int
    browser: str
    message: str


class DownloadsResult(TypedDict):
    results: list[tuple[str, str, int]]
    count: int
    browser: str
    message: str


class DeleteHistoryResult(TypedDict):
    preview: bool | None
    deleted: int | None
    query: str
    count: int
    browser: str
    message: str


class ExportHistoryResult(TypedDict):
    format: str
    content: str


class SyncHistoryResult(TypedDict):
    dry_run: bool
    source: str
    target: str
    entries_count: int
    merge_strategy: str
    message: str


class BrowserListResult(TypedDict):
    browsers: list[str]
    message: str


def handle_service_error(error: Exception) -> str:
    """Convert service exceptions to MCP error strings.

    Args:
        error: Exception from service layer

    Returns:
        Formatted error message for MCP response
    """
    if isinstance(error, ValidationError):
        return format_error_message(error.message)
    elif isinstance(error, BrowserNotFoundError):
        return format_error_message(error.message)
    elif isinstance(error, DatabaseLockedError):
        return format_error_message(error.message)
    elif isinstance(error, PermissionDeniedError):
        return format_error_message(error.message)
    elif isinstance(error, DatabaseError):
        return format_error_message(error.message)
    elif isinstance(error, ServiceError):
        return format_error_message(error.message)
    else:
        logger.exception("Unexpected error in MCP tool")
        return format_error_message("An unexpected error occurred")


def mcp_tool(func: T) -> T:
    """Decorator to register MCP tools with standardized error handling.

    This decorator wraps MCP tools with consistent error handling,
    replacing the need for try/except blocks in each tool.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> str:
        try:
            return func(*args, **kwargs)
        except Exception as e:
            return handle_service_error(e)

    # Register with FastMCP
    mcp.tool()(wrapper)
    return wrapper  # type: ignore[return-value]


@mcp_tool
def list_available_browsers() -> str:
    """Returns a list of browsers with detected history databases on this system.

    Returns:
        List of available browsers (chrome, edge, firefox)
    """
    result = HistoryService.list_available_browsers()
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def search_history(
    query: str,
    limit: int = 5,
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Searches browser history for keywords in titles or URLs.

    Args:
        query: Search term to look for in titles or URLs
        limit: Maximum number of results to return (1-100)
        browser: Browser to search (chrome, edge, firefox) - case insensitive
        format_type: Output format (markdown or json)

    Returns:
        Formatted list of matching history entries or error message
    """
    result = HistoryService.search_history(
        query=query, limit=limit, browser=browser, format_type=format_type
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def get_recent_history(
    hours: int = 24,
    limit: int = 20,
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Gets recent browsing history from the last N hours.

    Args:
        hours: Number of hours to look back (default: 24)
        limit: Maximum number of results (1-100, default: 20)
        browser: Browser to search (chrome, edge, firefox)
        format_type: Output format (markdown or json)

    Returns:
        Formatted list of recent history entries or error message
    """
    result = HistoryService.get_recent_history(
        hours=hours, limit=limit, browser=browser, format_type=format_type
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def count_visits(domain: str, browser: str = "chrome") -> str:
    """Counts total visits to a specific domain.

    Args:
        domain: Domain to count (e.g., 'github.com', 'stackoverflow.com')
        browser: Browser to search (chrome, edge, firefox)

    Returns:
        Number of visits to the domain or error message
    """
    result = HistoryService.count_visits(domain=domain, browser=browser)
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def list_top_domains(
    limit: int = 10,
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Gets the most visited domains from browser history.

    Args:
        limit: Maximum number of domains to return (1-50, default: 10)
        browser: Browser to search (chrome, edge, firefox)
        format_type: Output format (markdown or json)

    Returns:
        Formatted list of top domains or error message
    """
    result = HistoryService.list_top_domains(limit=limit, browser=browser, format_type=format_type)
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def search_history_by_date(
    query: str,
    start_date: str,
    end_date: str,
    limit: int = 10,
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Searches browser history within a date range.

    Args:
        query: Search term to look for in titles or URLs
        start_date: Start date in ISO format (YYYY-MM-DD)
        end_date: End date in ISO format (YYYY-MM-DD)
        limit: Maximum number of results (1-100)
        browser: Browser to search (chrome, edge, firefox)
        format_type: Output format (markdown or json)

    Returns:
        Formatted list of matching history entries or error message
    """
    result = HistoryService.search_history_by_date(
        query=query,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        browser=browser,
        format_type=format_type,
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def delete_history(
    query: str,
    limit: int = 100,
    browser: str = "chrome",
    confirm: bool = False,
) -> str:
    """Deletes history entries matching a query.

    Args:
        query: Search term to match for deletion
        limit: Maximum number of entries to delete (1-500)
        browser: Browser to search (chrome, edge, firefox)
        confirm: Must be True to actually delete; False returns preview

    Returns:
        Number of entries deleted or preview message
    """
    result = HistoryService.delete_history(
        query=query, limit=limit, browser=browser, confirm=confirm
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def search_by_domain(
    domain: str,
    query: str | None = None,
    limit: int = 20,
    browser: str = "chrome",
    format_type: str = "markdown",
    exclude_domains: list[str] | None = None,
) -> str:
    """Searches history within specific domain(s).

    Args:
        domain: Domain to search within (e.g., 'github.com', 'docs.python.org')
        query: Optional search term within the domain
        limit: Maximum number of results (1-100)
        browser: Browser to search (chrome, edge, firefox)
        format_type: Output format (markdown or json)
        exclude_domains: Domains to exclude from results

    Returns:
        Formatted list of matching history entries or error message
    """
    result = HistoryService.search_by_domain(
        domain=domain,
        query=query,
        limit=limit,
        browser=browser,
        format_type=format_type,
        exclude_domains=exclude_domains,
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def get_browser_stats(browser: str = "chrome") -> str:
    """Gets browsing statistics for the browser database.

    Args:
        browser: Browser to get stats for (chrome, edge, firefox)

    Returns:
        JSON string with browsing statistics
    """
    result = HistoryService.get_browser_stats(browser=browser)
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def get_most_visited_pages(
    limit: int = 20,
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Gets the most visited individual pages.

    Args:
        limit: Maximum number of pages to return (1-100)
        browser: Browser to search (chrome, edge, firefox)
        format_type: Output format (markdown or json)

    Returns:
        Formatted list of most visited pages or error message
    """
    result = HistoryService.get_most_visited_pages(
        limit=limit, browser=browser, format_type=format_type
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def export_history(
    format_type: str = "csv",
    limit: int = 1000,
    query: str | None = None,
    browser: str = "chrome",
) -> str:
    """Exports history to CSV or JSON format.

    Args:
        format_type: Export format (csv or json)
        limit: Maximum entries to export (1-10000)
        query: Optional search filter
        browser: Browser to export from (chrome, edge, firefox)

    Returns:
        CSV or JSON formatted history data
    """
    result = HistoryService.export_history(
        format_type=format_type, limit=limit, query=query, browser=browser
    )
    return result["content"]  # type: ignore[no-any-return]


@mcp_tool
def search_history_advanced(
    query: str,
    limit: int = 20,
    browser: str = "chrome",
    format_type: str = "markdown",
    exclude_domains: list[str] | None = None,
    sort_by: str = "date",
    use_regex: bool = False,
    use_fuzzy: bool = False,
    fuzzy_threshold: float = 0.6,
) -> str:
    """Advanced search with multiple options.

    Args:
        query: Search term to look for in titles or URLs
        limit: Maximum number of results (1-100)
        browser: Browser to search (chrome, edge, firefox)
        format_type: Output format (markdown or json)
        exclude_domains: Domains to exclude from results
        sort_by: Sort order (date, visit_count, title)
        use_regex: Use regex pattern matching
        use_fuzzy: Use fuzzy matching for typos
        fuzzy_threshold: Minimum similarity score for fuzzy matching (0.0-1.0)

    Returns:
        Formatted list of matching history entries or error message
    """
    result = HistoryService.search_history_advanced(
        query=query,
        limit=limit,
        browser=browser,
        format_type=format_type,
        exclude_domains=exclude_domains,
        sort_by=sort_by,
        use_regex=use_regex,
        use_fuzzy=use_fuzzy,
        fuzzy_threshold=fuzzy_threshold,
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def sync_history(
    source_browser: str,
    target_browser: str,
    merge_strategy: str = "latest",
    dry_run: bool = True,
) -> str:
    """Syncs history between browsers.

    Args:
        source_browser: Browser to copy history from
        target_browser: Browser to copy history to
        merge_strategy: How to handle duplicates (latest, combine, dedupe)
        dry_run: If True, show what would be done without making changes

    Returns:
        Summary of sync operation
    """
    result = HistoryService.sync_history(
        source_browser=source_browser,
        target_browser=target_browser,
        merge_strategy=merge_strategy,
        dry_run=dry_run,
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def list_available_bookmarks() -> str:
    """Returns a list of browsers with detected bookmarks on this system.

    Returns:
        List of available browsers with bookmarks
    """
    result = HistoryService.list_available_bookmarks()
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def list_available_downloads() -> str:
    """Returns a list of browsers with detected downloads history on this system.

    Returns:
        List of available browsers with downloads
    """
    result = HistoryService.list_available_downloads()
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def get_bookmarks(
    query: str | None = None,
    limit: int = 50,
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Gets bookmarks from a browser.

    Args:
        query: Optional search term to filter bookmarks
        limit: Maximum number of results (1-100)
        browser: Browser to get bookmarks from (chrome, edge, firefox, brave, vivaldi, opera)
        format_type: Output format (markdown or json)

    Returns:
        Formatted list of bookmarks or error message
    """
    result = HistoryService.get_bookmarks(
        query=query,
        limit=limit,
        browser=browser,
        format_type=format_type,
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def get_downloads(
    query: str | None = None,
    limit: int = 50,
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Gets downloads history from a browser.

    Args:
        query: Optional search term to filter downloads
        limit: Maximum number of results (1-100)
        browser: Browser to get downloads from (chrome, edge, firefox, brave, vivaldi, opera)
        format_type: Output format (markdown or json)

    Returns:
        Formatted list of downloads or error message
    """
    result = HistoryService.get_downloads(
        query=query,
        limit=limit,
        browser=browser,
        format_type=format_type,
    )
    return result["message"]  # type: ignore[no-any-return]


@mcp_tool
def compare_time_periods(
    start_date1: str,
    end_date1: str,
    start_date2: str,
    end_date2: str,
    browser: str = "chrome",
) -> str:
    """Compare browsing statistics between two time periods.

    Args:
        start_date1: Start date of first period (ISO format, e.g., '2024-01-01')
        end_date1: End date of first period (ISO format)
        start_date2: Start date of second period (ISO format)
        end_date2: End date of second period (ISO format)
        browser: Browser to analyze (chrome, edge, firefox, etc.)

    Returns:
        Comparison data showing changes between periods
    """
    result = HistoryService.compare_time_periods(
        start_date1=start_date1,
        end_date1=end_date1,
        start_date2=start_date2,
        end_date2=end_date2,
        browser=browser,
    )
    return json.dumps(result, indent=2)


@mcp_tool
def analyze_productivity(
    start_date: str | None = None,
    end_date: str | None = None,
    browser: str = "chrome",
) -> str:
    """Analyze browsing productivity and generate recommendations.

    Args:
        start_date: Optional start date (ISO format)
        end_date: Optional end date (ISO format)
        browser: Browser to analyze

    Returns:
        Productivity score, category breakdown, and recommendations
    """
    result = HistoryService.analyze_productivity(
        start_date=start_date,
        end_date=end_date,
        browser=browser,
    )
    return json.dumps(result, indent=2)


@mcp_tool
def suggest_categories(
    browser: str = "chrome",
    limit: int = 20,
) -> str:
    """Suggest categories for uncategorized URLs.

    Args:
        browser: Browser to analyze
        limit: Maximum number of suggestions (1-100)

    Returns:
        List of URLs that could be categorized with suggested categories
    """
    result = HistoryService.suggest_categories(
        browser=browser,
        limit=limit,
    )
    return json.dumps(result, indent=2)


@mcp_tool
def export_visualization(
    format_type: str = "chart_json",
    period: str = "month",
    browser: str = "chrome",
) -> str:
    """Export data formatted for visualization (Chart.js compatible).

    Args:
        format_type: 'chart_json' for visualization data or 'csv'
        period: Time period - 'day', 'week', or 'month'
        browser: Browser to export from

    Returns:
        Chart-ready JSON data with category breakdown and activity patterns
    """
    result = HistoryService.export_visualization(
        format_type=format_type,
        period=period,
        browser=browser,
    )
    return json.dumps(result, indent=2)


@mcp_tool
def generate_insights_report(
    period: str = "week",
    browser: str = "chrome",
    format_type: str = "markdown",
) -> str:
    """Generate comprehensive browsing insights report.

    Args:
        period: Time period - 'day', 'week', or 'month'
        browser: Browser to analyze
        format_type: 'markdown' for text or 'json' for data

    Returns:
        Comprehensive insights with productivity score, category breakdown,
        top domains, and recommendations
    """
    result = HistoryService.generate_insights_report(
        period=period,
        browser=browser,
        format_type=format_type,
    )
    if format_type == "json":
        return json.dumps(result, indent=2)
    return result["summary_markdown"]  # type: ignore[no-any-return]


@mcp_tool
def subscribe_to_history(
    browser: str = "chrome",
    event_types: list[str] | None = None,
) -> str:
    """Subscribe to real-time history changes for a browser.

    Args:
        browser: Browser to subscribe to (chrome, edge, firefox, etc.)
        event_types: List of event types to receive. Options: history_added,
            history_deleted, history_updated, bookmark_added, bookmark_deleted,
            download_added, download_deleted. If None, receives all events.

    Returns:
        Subscription ID and status information
    """
    if event_types is None:
        event_types = ["history_added", "history_deleted"]

    result = HistoryService.subscribe_history_changes(
        browser=browser,
        event_types=event_types,
        callback=None,
    )
    return json.dumps(result, indent=2)


@mcp_tool
def unsubscribe_from_history(subscription_id: str) -> str:
    """Unsubscribe from history change notifications.

    Args:
        subscription_id: Subscription ID to remove

    Returns:
        Success status
    """
    result = HistoryService.unsubscribe_history_changes(subscription_id)
    return json.dumps(result, indent=2)


@mcp_tool
def get_subscription_status(subscription_id: str | None = None) -> str:
    """Get subscription status or global event statistics.

    Args:
        subscription_id: Optional specific subscription ID. If None, returns global stats.

    Returns:
        Subscription information or global statistics
    """
    result = HistoryService.get_subscription_status(subscription_id)
    return json.dumps(result, indent=2)


@mcp_tool
def find_duplicate_history(
    browser: str = "chrome",
    similarity_threshold: float = 0.9,
    limit: int = 100,
) -> str:
    """Find potential duplicate history entries based on URL similarity.

    Args:
        browser: Browser to analyze (chrome, edge, firefox, etc.)
        similarity_threshold: URL similarity threshold (0.0-1.0), default 0.9
        limit: Maximum number of duplicate groups to return (1-1000)

    Returns:
        JSON with duplicate groups and statistics
    """
    result = HistoryService.find_duplicate_entries(
        browser=browser,
        similarity_threshold=similarity_threshold,
        limit=limit,
    )
    return json.dumps(result, indent=2)


@mcp_tool
def delete_duplicate_history(
    browser: str = "chrome",
    similarity_threshold: float = 0.9,
    keep_strategy: str = "most_visits",
    confirm: bool = False,
) -> str:
    """Delete duplicate history entries.

    Args:
        browser: Browser to clean
        similarity_threshold: URL similarity threshold for duplicates (0.0-1.0)
        keep_strategy: Which entry to keep ('most_visits', 'most_recent', 'first')
        confirm: Must be True to actually delete; False returns preview

    Returns:
        Deletion results or preview
    """
    result = HistoryService.delete_duplicates(
        browser=browser,
        similarity_threshold=similarity_threshold,
        keep_strategy=keep_strategy,
        confirm=confirm,
    )
    return json.dumps(result, indent=2)
