"""Database connection management for ChronicleMCP.

This module provides a centralized way to connect to browser history databases
while avoiding 'Database Locked' errors by using temporary copies.
"""

from __future__ import annotations

import logging
import os
import shutil
import sqlite3
import tempfile
import time
from collections.abc import Callable, Generator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from chronicle_mcp.core.exceptions import (
        BrowserNotFoundError,
        BrowserPathNotFoundError,
        DatabaseLockedError,
        PermissionDeniedError,
    )

from chronicle_mcp.paths import get_browser_path

logger = logging.getLogger(__name__)


class ConnectionError(Exception):
    """Base exception for connection errors."""

    def __init__(self, message: str, browser: str, details: str | None = None):
        self.message = message
        self.browser = browser
        self.details = details
        super().__init__(self.message)


def get_temp_filename(browser: str) -> str:
    """Generate a unique temporary filename for the database copy.

    Args:
        browser: Browser name for identification

    Returns:
        Path string for the temporary file
    """
    temp_dir = tempfile.gettempdir()
    return os.path.join(
        temp_dir,
        f"chronicle_{browser}_temp_{os.getpid()}_{int(time.time() * 1000)}.db",
    )


def cleanup_temp_file(temp_path: str) -> None:
    """Safely remove a temporary database file.

    Args:
        temp_path: Path to the temporary file to remove
    """
    try:
        if os.path.exists(temp_path):
            os.remove(temp_path)
            logger.debug(f"Cleaned up temp file: {temp_path}")
    except OSError as e:
        logger.warning(f"Failed to clean up temp file {temp_path}: {e}")


@contextmanager
def get_history_connection(
    browser: str = "chrome",
    max_retries: int = 3,
    retry_delay: float = 0.1,
) -> Generator[sqlite3.Connection, None, None]:
    """Creates a temporary copy of the history database to avoid 'Database Locked' errors.

    This function copies the browser's history database to a temporary file,
    opens it, and ensures cleanup after the context exits. This prevents
    database locking issues when the browser is running.

    Args:
        browser: Browser name (chrome, edge, firefox) - case insensitive
        max_retries: Maximum number of retries on lock errors
        retry_delay: Initial delay between retries (exponential backoff)

    Yields:
        SQLite connection to the history database

    Raises:
        BrowserNotFoundError: If the browser is not recognized
        BrowserPathNotFoundError: If the history path doesn't exist
        PermissionDeniedError: If the file cannot be read
        DatabaseLockedError: If the database is locked after retries
    """
    from chronicle_mcp.core.exceptions import (
        BrowserNotFoundError,
        BrowserPathNotFoundError,
        DatabaseLockedError,
        PermissionDeniedError,
    )

    browser_lower = browser.lower()

    history_path = get_browser_path(browser_lower)

    if not history_path:
        raise BrowserNotFoundError(browser_lower)

    if not os.path.exists(history_path):
        raise BrowserPathNotFoundError(browser_lower, history_path)

    temp_path = get_temp_filename(browser_lower)

    for attempt in range(max_retries):
        try:
            logger.debug(f"Copying {browser} history to temp file: {temp_path}")
            shutil.copy2(history_path, temp_path)

            conn = sqlite3.connect(temp_path)
            try:
                yield conn
            except sqlite3.OperationalError as e:
                if "locked" in str(e).lower():
                    conn.close()
                    cleanup_temp_file(temp_path)
                    if attempt < max_retries - 1:
                        delay = retry_delay * (2**attempt)
                        logger.debug(
                            f"Database locked, retrying in {delay}s (attempt {attempt + 1}/{max_retries})"
                        )
                        time.sleep(delay)
                        continue
                    raise DatabaseLockedError(browser_lower, history_path) from e
                raise
            finally:
                conn.close()
                cleanup_temp_file(temp_path)
            return

        except PermissionDeniedError:
            raise
        except OSError as e:
            if "permission" in str(e).lower():
                raise PermissionDeniedError(browser_lower, history_path) from e
            cleanup_temp_file(temp_path)
            if attempt < max_retries - 1:
                delay = retry_delay * (2**attempt)
                logger.debug(
                    f"OS error, retrying in {delay}s (attempt {attempt + 1}/{max_retries}): {e}"
                )
                time.sleep(delay)
                continue
            raise ConnectionError(
                f"Failed to access {browser} history: {e}",
                browser=browser_lower,
                details=str(e),
            ) from e
        except Exception as e:
            cleanup_temp_file(temp_path)
            if attempt < max_retries - 1:
                delay = retry_delay * (2**attempt)
                logger.debug(
                    f"Unexpected error, retrying in {delay}s (attempt {attempt + 1}/{max_retries}): {e}"
                )
                time.sleep(delay)
                continue
            raise


def execute_with_connection(browser: str, func: Callable[[sqlite3.Connection], Any]) -> Any:
    """Execute a function with a database connection.

    This is a convenience function for synchronous operations that need
    a database connection without using the context manager pattern.

    Args:
        browser: Browser name
        func: Function to execute with the connection

    Returns:
        Result of the function execution

    Raises:
        ConnectionError: Any connection-related error
    """
    with get_history_connection(browser) as conn:
        return func(conn)


# Re-export exceptions from core.exceptions for backward compatibility
from chronicle_mcp.core.exceptions import (
    BrowserNotFoundError,
    BrowserPathNotFoundError,
    DatabaseLockedError,
    PermissionDeniedError,
)

__all__ = [
    "BrowserNotFoundError",
    "BrowserPathNotFoundError",
    "DatabaseLockedError",
    "PermissionDeniedError",
    "ConnectionError",
    "get_history_connection",
    "execute_with_connection",
    "get_temp_filename",
    "cleanup_temp_file",
]
