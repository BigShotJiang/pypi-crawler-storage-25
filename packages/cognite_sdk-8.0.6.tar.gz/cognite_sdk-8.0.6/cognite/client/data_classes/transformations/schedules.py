from __future__ import annotations

from abc import ABC
from typing import Any

from typing_extensions import Self

from cognite.client.data_classes._base import (
    CognitePrimitiveUpdate,
    CogniteResource,
    CogniteResourceList,
    CogniteUpdate,
    IdTransformerMixin,
    PropertySpec,
    WriteableCogniteResource,
    WriteableCogniteResourceList,
)
from cognite.client.utils._auxiliary import exactly_one_is_not_none


class TransformationScheduleCore(WriteableCogniteResource["TransformationScheduleWrite"], ABC):
    """The transformation schedules resource allows running recurrent transformations.

    Args:
        interval (str): Cron expression controls when the transformation will be run. Use http://www.cronmaker.com to create one.
        is_paused (bool): If true, the transformation is not scheduled.
    """

    def __init__(self, interval: str, is_paused: bool) -> None:
        self.interval = interval
        self.is_paused = is_paused


class TransformationSchedule(TransformationScheduleCore):
    """The transformation schedules resource allows running recurrent transformations.

    Args:
        id (int): Transformation id.
        external_id (str): Transformation external id.
        created_time (int): Time when the schedule was created.
        last_updated_time (int): Time when the schedule was last updated.
        interval (str): Cron expression controls when the transformation will be run. Use http://www.cronmaker.com to create one.
        is_paused (bool): If true, the transformation is not scheduled.
    """

    def __init__(
        self,
        id: int,
        external_id: str,
        created_time: int,
        last_updated_time: int,
        interval: str,
        is_paused: bool,
    ) -> None:
        super().__init__(interval=interval, is_paused=is_paused)
        self.id = id
        self.external_id = external_id
        self.is_paused = is_paused
        self.created_time = created_time
        self.last_updated_time = last_updated_time

    @classmethod
    def _load(cls, resource: dict[str, Any]) -> Self:
        return cls(
            id=resource["id"],
            external_id=resource["externalId"],
            created_time=resource["createdTime"],
            last_updated_time=resource["lastUpdatedTime"],
            interval=resource["interval"],
            is_paused=resource["isPaused"],
        )

    def as_write(self) -> TransformationScheduleWrite:
        """Returns this TransformationSchedule as a TransformationScheduleWrite"""
        return TransformationScheduleWrite(
            id=None,  # Must provide one of id or external_id
            external_id=self.external_id,
            interval=self.interval,
            is_paused=self.is_paused,
        )

    def __hash__(self) -> int:
        return hash(self.id)


class TransformationScheduleWrite(TransformationScheduleCore):
    """The transformation schedules resource allows running recurrent transformations.

    Args:
        interval (str): Cron expression controls when the transformation will be run. Use http://www.cronmaker.com to create one.
        id (int | None): Transformation id.
        external_id (str | None): Transformation external id.
        is_paused (bool): If true, the transformation is not scheduled.
    """

    def __init__(
        self,
        interval: str,
        id: int | None = None,
        external_id: str | None = None,
        is_paused: bool = False,
    ) -> None:
        super().__init__(interval=interval, is_paused=is_paused)
        self.id = id
        self.external_id = external_id
        if not exactly_one_is_not_none(id, external_id):
            raise ValueError(f"Either id or external_id must be specified (but not both), got {id=} and {external_id=}")

    @classmethod
    def _load(cls, resource: dict[str, Any]) -> TransformationScheduleWrite:
        return cls(
            interval=resource["interval"],
            id=resource.get("id"),
            external_id=resource.get("externalId"),
            is_paused=resource.get("isPaused", False),
        )

    def as_write(self) -> TransformationScheduleWrite:
        """Returns this TransformationScheduleWrite instance."""
        return self


class TransformationScheduleUpdate(CogniteUpdate):
    """Changes applied to transformation schedule

    Args:
        id (int): Transformation id.
        external_id (str): Transformation externalId.
    """

    class _PrimitiveTransformationScheduleUpdate(CognitePrimitiveUpdate):
        def set(self, value: Any) -> TransformationScheduleUpdate:
            return self._set(value)

    @property
    def interval(self) -> _PrimitiveTransformationScheduleUpdate:
        return TransformationScheduleUpdate._PrimitiveTransformationScheduleUpdate(self, "interval")

    @property
    def is_paused(self) -> _PrimitiveTransformationScheduleUpdate:
        return TransformationScheduleUpdate._PrimitiveTransformationScheduleUpdate(self, "isPaused")

    @classmethod
    def _get_update_properties(cls, item: CogniteResource | None = None) -> list[PropertySpec]:
        return [
            PropertySpec("interval", is_nullable=False),
            PropertySpec("is_paused", is_nullable=False),
        ]


class TransformationScheduleWriteList(CogniteResourceList[TransformationScheduleWrite], IdTransformerMixin):
    _RESOURCE = TransformationScheduleWrite


class TransformationScheduleList(
    WriteableCogniteResourceList[TransformationScheduleWrite, TransformationSchedule], IdTransformerMixin
):
    _RESOURCE = TransformationSchedule

    def as_write(self) -> TransformationScheduleWriteList:
        return TransformationScheduleWriteList([x.as_write() for x in self.data])
