from __future__ import annotations

from cognite.client._api_client import APIClient
from cognite.client.utils._url import interpolate_and_url_encode


class ThreeDFilesAPI(APIClient):
    _RESOURCE_PATH = "/3d/files"

    async def retrieve(self, id: int) -> bytes:
        """`Retrieve the contents of a 3d file by id. <https://api-docs.cognite.com/20230101/tag/3D-Files/operation/get3DFile>`_

        Args:
            id (int): The id of the file to retrieve.

        Returns:
            bytes: The contents of the file.

        Example:

            Retrieve the contents of a 3d file by id:

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> res = client.three_d.files.retrieve(1)
        """
        path = interpolate_and_url_encode(self._RESOURCE_PATH + "/{}", id)
        return (await self._get(path, semaphore=self._get_semaphore("read"))).content
