from nasap_net.isomorphism import is_isomorphic
from nasap_net.models import Assembly


def assemblies_equivalent(
        assembly1: Assembly,
        assembly2: Assembly,
) -> bool:
    """Check if two assemblies are equivalent.

    Two assemblies are considered equivalent if they are isomorphic,
    meaning there exists a one-to-one mapping between their components and
    binding sites that preserves the following properties:
        - Component kinds
        - Bond connections
        - Auxiliary edges (if present)
        - Auxiliary edge types (if present)

    Parameters
    ----------
    assembly1 : Assembly
        The first assembly to compare.
    assembly2 : Assembly
        The second assembly to compare.

    Returns
    -------
    bool
        True if the assemblies are equivalent, False otherwise.

    Examples
    --------
    >>> from nasap_net import Component, Assembly, Bond, assemblies_equivalent
    >>> M = Component(kind='M', sites=[0, 1])
    >>> L = Component(kind='L', sites=[0, 1])
    >>> a1 = Assembly(
    ...     components={'M0': M, 'L0': L},
    ...     bonds=[Bond('M0', 0, 'L0', 0)]
    ... )
    >>> a2 = Assembly(
    ...     components={'M1': M, 'L1': L},
    ...     bonds=[Bond('M1', 0, 'L1', 0)]
    ... )
    >>> # a1 and a2 have different component IDs but the same structure
    >>> assemblies_equivalent(a1, a2)
    True
    """
    if assembly1 == assembly2:
        return True
    return is_isomorphic(assembly1, assembly2)
