from dataclasses import dataclass
from functools import total_ordering

from nasap_net.types import ID, SupportsDunderLt


@total_ordering
@dataclass(frozen=True)
class BindingSite(SupportsDunderLt):
    """A specific binding site on a specific component.

    Parameters
    ----------
    component_id : ID
        The ID of the component this site belongs to.
    site_id : ID
        The site identifier within the component.

    Examples
    --------
    >>> from nasap_net import BindingSite
    >>> BindingSite('M0', 0)  # site 0 on component M0

    Creating a bond by passing binding sites explicitly:

    >>> from nasap_net import Bond
    >>> metal_bs = BindingSite('M0', 0)  # site 0 on component M0
    >>> ligand_bs = BindingSite('L0', 0)  # site 0 on component L0
    >>> Bond.from_sites(metal_bs, ligand_bs)
    """
    component_id: ID
    site_id: ID

    def __lt__(self, other):
        if not isinstance(other, BindingSite):
            return NotImplemented
        self_values = (self.component_id, self.site_id)
        other_values = (other.component_id, other.site_id)
        return self_values < other_values

    def __repr__(self):
        return f'BindingSite({self.component_id!r}, {self.site_id!r})'
