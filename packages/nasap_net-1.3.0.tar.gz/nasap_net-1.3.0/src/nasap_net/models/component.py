from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

from nasap_net.types import ID
from nasap_net.utils import construct_repr
from .aux_edge import AuxEdge
from .binding_site import BindingSite


@dataclass(frozen=True, init=False)
class Component:
    """A component in a self-assembly system.

    Parameters
    ----------
    kind : str
        The kind identifier for this component (e.g., ``'M'``, ``'L'``, ``'X'``).
    sites : Iterable[ID]
        The site IDs available for bonding on this component.
    aux_edges : Iterable[AuxEdge] | None, optional
        Auxiliary edges representing geometric constraints between sites
        (e.g., cis/trans relationships). Default is None.

    Examples
    --------
    >>> from nasap_net import Component
    >>> M = Component(kind='M', sites=[0, 1])  # metal with 2 binding sites
    >>> L = Component(kind='L', sites=[0, 1])  # bridging ligand with 2 binding sites
    >>> X = Component(kind='X', sites=[0])     # monodentate leaving ligand

    With auxiliary edges encoding geometric constraints:

    >>> from nasap_net import AuxEdge
    >>> M = Component(
    ...     kind='M', sites=[0, 1, 2, 3],
    ...     aux_edges=[AuxEdge(0, 1), AuxEdge(1, 2),
    ...                AuxEdge(2, 3), AuxEdge(3, 0)],
    ... )
    """
    kind: str
    site_ids: frozenset[ID]
    aux_edges: frozenset[AuxEdge]

    def __init__(
            self, kind: str, sites: Iterable[ID],
            aux_edges: Iterable[AuxEdge] | None = None
            ):
        object.__setattr__(self, 'kind', kind)
        object.__setattr__(self, 'site_ids', frozenset(sites))
        if aux_edges is None:
            aux_edges = frozenset()
        else:
            aux_edges = frozenset(aux_edges)
        object.__setattr__(self, 'aux_edges', aux_edges)

    def __repr__(self):
        fields: dict[str, Any] = {}
        fields['kind'] = self.kind
        fields['site_ids'] = sorted(self.site_ids)
        if self.aux_edges:
            fields['aux_edges'] = [
                aux_edge.to_tuple() for aux_edge in sorted(self.aux_edges)
            ]
        return construct_repr(self.__class__, fields)

    def get_binding_sites(self, comp_id: ID) -> frozenset[BindingSite]:
        """Return the binding sites of this component."""
        return frozenset(
            BindingSite(component_id=comp_id, site_id=site_id)
            for site_id in self.site_ids
        )
