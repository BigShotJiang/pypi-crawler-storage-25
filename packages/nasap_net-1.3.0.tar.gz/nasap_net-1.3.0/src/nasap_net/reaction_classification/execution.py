import logging
from collections.abc import Callable, Iterable

from nasap_net import Reaction

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

def classify_reactions(
        reactions: Iterable[Reaction],
        classifier: Callable[[Reaction], str],
) -> dict[Reaction, str]:
    """Classify reactions using a user-defined classifier function.

    Parameters
    ----------
    reactions : Iterable[Reaction]
        The reactions to classify.
    classifier : Callable[[Reaction], str]
        A function that takes a reaction and returns its class as a string.
        Should raise :class:`IncompleteReactionClassifierError` for unhandled
        reactions.

    Returns
    -------
    dict[Reaction, str]
        A mapping from each reaction to its assigned class.

    Examples
    --------
    >>> from nasap_net import classify_reactions, IncompleteReactionClassifierError
    >>> def classifier(reaction):
    ...     r = reaction.as_reaction_to_classify()
    ...     if r.leaving_kind == 'X' and r.entering_kind == 'L':
    ...         return 'X-to-L'
    ...     if r.leaving_kind == 'L' and r.entering_kind == 'X':
    ...         return 'L-to-X'
    ...     raise IncompleteReactionClassifierError(reaction)
    >>> reaction_to_class = classify_reactions(reactions, classifier)
    """
    result = {}
    for reaction in reactions:
        cls = classifier(reaction)
        result[reaction] = cls

        logger.info("%s -> %s", reaction, cls)

    return result
