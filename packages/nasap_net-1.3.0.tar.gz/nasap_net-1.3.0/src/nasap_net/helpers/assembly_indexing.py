from collections.abc import Iterable, Sequence

from nasap_net.models import Assembly
from nasap_net.utils import deduplicate_ids
from .composition_formula import generate_composition_formula


def assign_composition_formula_ids(
        assemblies: Iterable[Assembly],
        *,
        order: Sequence[str] | None = None,
) -> list[Assembly]:
    """Assign composition formula strings as IDs to the given assemblies.

    Parameters
    ----------
    assemblies : Iterable[Assembly]
        The assemblies to assign IDs to.
    order : Sequence[str] | None, optional
        The order of component kinds in the formula (e.g., ``['M', 'L', 'X']``).
        If None, kinds are sorted alphabetically. Default is None.

    Returns
    -------
    list[Assembly]
        Assemblies with composition formula strings as IDs
        (e.g., ``'M1L2X2'``). If multiple assemblies share the same
        formula, a numeric suffix is appended (e.g., ``'M1L1X1-1'``).

    Examples
    --------
    >>> from nasap_net import assign_composition_formula_ids
    >>> indexed = assign_composition_formula_ids(
    ...     assemblies, order=['M', 'L', 'X']
    ... )
    """
    assigned_assemblies = [
        assembly.copy_with(
            id_=generate_composition_formula(assembly, order=order)
        )
        for assembly in assemblies
    ]
    return deduplicate_ids(assigned_assemblies)  # type: ignore
