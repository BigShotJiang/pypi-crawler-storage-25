from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class Scope(StrEnum):
    USER = 'user'
    ADMIN = 'admin'
    EDITOR = 'editor'
    VIEWER = 'viewer'


class DataFormat(StrEnum):
    CSV = 'csv'
    PARQUET = 'parquet'
    JSON = 'json'


class DataType(StrEnum):
    BOOLEAN = 'boolean'
    STRING = 'string'
    CATEGORICAL = 'categorical'
    INT32 = 'int32'
    INT64 = 'int64'
    FLOAT32 = 'float32'
    FLOAT64 = 'float64'
    DECIMAL = 'decimal'
    DATE = 'date'
    DATETIME = 'datetime'
    TIME = 'time'
    UNKNOWN = 'unknown'


class DataJobStatus(StrEnum):
    PENDING = 'pending'
    PROCESSING = 'processing'
    COMPLETED = 'completed'
    FAILED = 'failed'


class DataJobType(StrEnum):
    UPLOAD = 'upload'
    UPDATE = 'update'
    DOWNLOAD = 'download'


class UpdateMode(StrEnum):
    APPEND = 'append'
    OVERWRITE = 'overwrite'
    UPSERT = 'upsert'


class Sensitivity(StrEnum):
    PUBLIC = 'public'
    INTERNAL = 'internal'


class RefreshFrequency(StrEnum):
    DAILY = 'daily'
    WEEKLY = 'weekly'
    BI_WEEKLY = 'bi-weekly'
    MONTHLY = 'monthly'
    BI_MONTHLY = 'bi-monthly'
    QUARTERLY = 'quarterly'
    YEARLY = 'yearly'
    MANUAL = 'manual'


class TransformationType(StrEnum):
    IDENTITY = 'identity'
    BUCKET = 'bucket'
    TRUNCATE = 'truncate'
    YEAR = 'year'
    MONTH = 'month'
    DAY = 'day'


class Token(BaseModel):
    access_token: str
    token_type: str
    jti: str | None = None


class PaginationMetadata(BaseModel):
    limit: int
    offset: int
    total_count: int
    has_next: bool
    filters: list[Any] = Field(default_factory=list)
    order_by: list[Any] = Field(default_factory=list)


# ── Users ────────────────────────────────────────────────────────────────────


class UserResponse(BaseModel):
    model_config = ConfigDict(extra='ignore')

    id: int
    username: str
    email: str
    scopes: set[Scope]
    is_active: bool
    created_at: datetime
    updated_at: datetime


class UsersListResponse(BaseModel):
    items: list[UserResponse]
    metadata: PaginationMetadata


# ── API Keys ─────────────────────────────────────────────────────────────────


class APIKeyResponse(BaseModel):
    id: int
    user_id: int
    jti: str
    name: str
    scopes: set[Scope]
    created_at: datetime
    expires_at: datetime


class APIKeysListResponse(BaseModel):
    items: list[APIKeyResponse]
    metadata: PaginationMetadata


# ── Namespaces ───────────────────────────────────────────────────────────────


class NamespaceMetadata(BaseModel):
    model_config = ConfigDict(extra='ignore')

    title: str = ''
    description: str | None = None
    tags: set[str] = Field(default_factory=set)
    created_by: str = ''
    created_at: datetime | None = None
    updated_at: datetime | None = None
    updated_by: str = ''


class NamespaceResponse(BaseModel):
    id: str
    metadata: NamespaceMetadata


class NamespaceResponseSummary(BaseModel):
    id: str
    metadata: NamespaceMetadata


class NamespaceResponseMinimal(BaseModel):
    id: str


class NamespacesListResponse(BaseModel):
    items: list[
        NamespaceResponse | NamespaceResponseSummary | NamespaceResponseMinimal
    ]
    metadata: PaginationMetadata


# ── Tables ───────────────────────────────────────────────────────────────────


class ExternalSource(BaseModel):
    name: str
    url: str
    license: str | None = None


class ColumnSchema(BaseModel):
    name: str
    description: str | None = None
    data_type: DataType = DataType.UNKNOWN
    required: bool = False


class ColumnSorting(BaseModel):
    name: str
    direction: str = 'desc'
    nulls_position: str = 'last'
    transform: TransformationType = TransformationType.IDENTITY


class ColumnPartitioning(BaseModel):
    name: str
    transform: TransformationType = TransformationType.IDENTITY


class TableMetadata(BaseModel):
    model_config = ConfigDict(extra='ignore')

    title: str = ''
    description: str | None = None
    tags: set[str] = Field(default_factory=set)
    sources: list[list[str]] = Field(default_factory=list)
    external_sources: list[ExternalSource] = Field(default_factory=list)
    license: str | None = None
    sensitivity: Sensitivity = Sensitivity.INTERNAL
    refresh_frequency: RefreshFrequency = RefreshFrequency.MANUAL
    created_by: str = ''
    engine_properties: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime | None = None
    updated_at: datetime | None = None


class TableResponse(BaseModel):
    model_config = ConfigDict(extra='ignore')

    id: str
    columns: list[ColumnSchema]
    sort_by: list[ColumnSorting] = Field(default_factory=list)
    partition_by: list[ColumnPartitioning] = Field(default_factory=list)
    metadata: TableMetadata


class TableResponseSummary(BaseModel):
    id: str
    metadata: TableMetadata


class TableResponseMinimal(BaseModel):
    id: str


class TablesListResponse(BaseModel):
    items: list[TableResponse | TableResponseSummary | TableResponseMinimal]
    metadata: PaginationMetadata


# ── Data ─────────────────────────────────────────────────────────────────────


class UpdateOptions(BaseModel):
    mode: UpdateMode
    key_columns: list[str] = Field(default_factory=list)


class Filter(BaseModel):
    field: str
    operator: str
    value: str | bool | datetime | int


class DatasetInfoResponse(BaseModel):
    table_id: str
    snapshot_id: int | None
    last_updated: datetime | None
    row_count: int | None
    data_files: int | None
    total_size_bytes: int | None


class DataJobResponse(BaseModel):
    job_id: str
    table_id: str | None
    job_type: DataJobType
    status: DataJobStatus
    error: str | None
    update_options: UpdateOptions | None
    filters: list[Filter] | None
    created_at: datetime
    updated_at: datetime


class QueryJobResponse(BaseModel):
    job_id: str
    status: DataJobStatus
    error: str | None = None
