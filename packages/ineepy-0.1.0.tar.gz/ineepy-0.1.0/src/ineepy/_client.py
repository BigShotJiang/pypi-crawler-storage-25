"""Sync and async client (Ineepy, AsyncIneepy) for the ineep lakehouse."""

from __future__ import annotations

from pathlib import Path
from types import TracebackType

import httpx

from ineepy._config import CONFIG_FILENAME, load_settings
from ineepy._resources.api_keys import APIKeysResource, AsyncAPIKeysResource
from ineepy._resources.data import AsyncDataResource, DataResource
from ineepy._resources.namespaces import (
    AsyncNamespacesResource,
    NamespacesResource,
)
from ineepy._resources.tables import AsyncTablesResource, TablesResource
from ineepy._resources.users import AsyncUsersResource, UsersResource


class Ineepy:
    """Synchronous client for the **ineep lakehouse API**.

    Configuration is resolved from three sources in priority order
    (highest to lowest): code-level arguments → ``ineepy.toml`` in the
    current directory → ``INEEPY_*`` environment variables.

    Can be used as a context manager (preferred) or manually closed.

    Args:
        token: Bearer token. Defaults to config/env ``INEEPY_TOKEN``.
            Obtain one with :func:`~ineepy.get_token`.
        base_url: API base URL. Defaults to config/env ``INEEPY_BASE_URL``
            (default ``https://ineep-lakehouse-prod.exe.xyz``).
        api_path: API path prefix. Defaults to config/env ``INEEPY_API_PATH``
            (default ``/api/v0``).
        config_file: Path to the TOML config file. Defaults to
            ``ineepy.toml`` in the current working directory.

    Example::

        # After calling get_token(...) once, the token is saved to
        # ineepy.toml and the client loads it automatically:
        with Ineepy() as client:
            user, etag = client.users.get('me')
    """

    def __init__(
        self,
        token: str | None = None,
        *,
        base_url: str | None = None,
        api_path: str | None = None,
        config_file: Path | None = None,
        _skip_health_check: bool = False,
    ) -> None:
        s = load_settings(config_file or Path.cwd() / CONFIG_FILENAME)
        _base = (base_url or s.base_url).rstrip('/')
        _path = (api_path or s.api_path).rstrip('/')
        self._health_url = f'{_base}/health'
        self._http = httpx.Client(
            base_url=f'{_base}{_path}/',
            headers={'Authorization': f'Bearer {token or s.token}'},
        )
        self.users = UsersResource(self._http)
        self.api_keys = APIKeysResource(self._http)
        self.namespaces = NamespacesResource(self._http)
        self.tables = TablesResource(self._http)
        self.data = DataResource(self._http)
        if not _skip_health_check:
            self._check_health()

    def _check_health(self) -> None:
        r = self._http.get(self._health_url)
        r.raise_for_status()

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> Ineepy:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()


class AsyncIneepy:
    """Async version of :class:`~ineepy.Ineepy`."""

    def __init__(
        self,
        token: str | None = None,
        *,
        base_url: str | None = None,
        api_path: str | None = None,
        config_file: Path | None = None,
        _skip_health_check: bool = False,
    ) -> None:
        s = load_settings(config_file or Path.cwd() / CONFIG_FILENAME)
        _base = (base_url or s.base_url).rstrip('/')
        _path = (api_path or s.api_path).rstrip('/')
        self._health_url = f'{_base}/health'
        self._http = httpx.AsyncClient(
            base_url=f'{_base}{_path}/',
            headers={'Authorization': f'Bearer {token or s.token}'},
        )
        self.users = AsyncUsersResource(self._http)
        self.api_keys = AsyncAPIKeysResource(self._http)
        self.namespaces = AsyncNamespacesResource(self._http)
        self.tables = AsyncTablesResource(self._http)
        self.data = AsyncDataResource(self._http)
        self._skip_health_check = _skip_health_check

    async def aclose(self) -> None:
        """Close the underlying async HTTP client."""
        await self._http.aclose()

    async def _acheck_health(self) -> None:
        r = await self._http.get(self._health_url)
        r.raise_for_status()

    async def __aenter__(self) -> AsyncIneepy:
        if not self._skip_health_check:
            await self._acheck_health()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()


AsyncIneepy.__doc__ = Ineepy.__doc__
AsyncIneepy.aclose.__doc__ = Ineepy.close.__doc__
