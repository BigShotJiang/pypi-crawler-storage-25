from collections.abc import Mapping
from pathlib import Path
import tomllib

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic_settings.sources import TomlConfigSettingsSource

CONFIG_FILENAME = 'ineepy.toml'


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix='INEEPY_',
        toml_file=CONFIG_FILENAME,
        toml_file_encoding='utf-8',
    )

    base_url: str = 'https://ineep-lakehouse-prod.exe.xyz'
    api_path: str = '/api/v0'
    token: str = ''

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls,
        init_settings,
        env_settings,
        dotenv_settings,
        **kwargs,
    ):
        return (
            init_settings,
            TomlConfigSettingsSource(settings_cls),
            env_settings,
        )


def load_settings(config_file: Path | None = None) -> Settings:
    if config_file is None:
        return Settings()
    init_overrides: dict[str, str] = {}
    if config_file.exists():
        with open(config_file, 'rb') as f:
            init_overrides = tomllib.load(f)
    return Settings(**init_overrides)


def write_config(path: Path, data: Mapping[str, str]) -> None:
    existing: dict[str, str] = {}
    if path.exists():
        with open(path, 'rb') as f:
            existing = tomllib.load(f)
    existing.update(data)
    lines = [f'{k} = "{v}"' for k, v in existing.items()]
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')


settings = Settings()
