class IneepyError(Exception):
    """Base class for all ineepy errors."""


class HTTPError(IneepyError):
    """HTTP error with a status code and detail message.

    Attributes:
        status_code: The HTTP status code returned by the server.
        detail: Human-readable error description from the response body.
    """

    def __init__(self, status_code: int, detail: str = '') -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f'HTTP {status_code}: {detail}')


class NotFoundError(HTTPError):
    """Raised when the requested resource does not exist (HTTP 404)."""


class ForbiddenError(HTTPError):
    """Raised when the token lacks the required scope (HTTP 403)."""


class UnauthorizedError(HTTPError):
    """Raised when the token is missing, invalid, or expired (HTTP 401)."""


class ConflictError(HTTPError):
    """Raised on a resource conflict (HTTP 409).

    Common causes: creating a resource that already exists, or attempting to
    delete a namespace that still contains tables.
    """


class PreconditionFailedError(HTTPError):
    """Raised when an ETag precondition check fails (HTTP 412).

    Indicates a concurrent modification: fetch the resource again to get the
    current ETag, then retry the update.
    """


class ValidationError(HTTPError):
    """Raised when the server rejects the request body (HTTP 422)."""


class JobFailedError(IneepyError):
    """Raised when an async data job fails on the server.

    Attributes:
        job_id: Identifier of the failed job.
        error: Server-side error message, if available.
    """

    def __init__(self, job_id: str, error: str | None = None) -> None:
        self.job_id = job_id
        self.error = error
        super().__init__(f'Job {job_id} failed: {error}')


class TimeoutError(IneepyError):
    """Raised when polling a job exceeds the configured timeout.

    Attributes:
        job_id: Identifier of the timed-out job.
    """

    def __init__(self, job_id: str) -> None:
        self.job_id = job_id
        super().__init__(f'Polling timed out for job {job_id}')
