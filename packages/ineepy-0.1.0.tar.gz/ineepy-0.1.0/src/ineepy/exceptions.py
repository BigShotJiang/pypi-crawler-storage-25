"""Public exceptions for ineepy.

All exception classes raised by the library are available here.
Catch :class:`IneepyError` for any library error, or a specific subclass for
finer control.
"""

from ineepy._exceptions import (
    ConflictError,
    ForbiddenError,
    HTTPError,
    IneepyError,
    JobFailedError,
    NotFoundError,
    PreconditionFailedError,
    TimeoutError,
    UnauthorizedError,
    ValidationError,
)

__all__ = [
    'IneepyError',
    'HTTPError',
    'NotFoundError',
    'ForbiddenError',
    'UnauthorizedError',
    'ConflictError',
    'PreconditionFailedError',
    'ValidationError',
    'JobFailedError',
    'TimeoutError',
]
