"""JWT auth: acquire and persist scoped access tokens via get_token()."""

from collections.abc import Sequence
from json import JSONDecodeError
from pathlib import Path

import httpx

from ineepy._config import CONFIG_FILENAME, load_settings, write_config
from ineepy._exceptions import ForbiddenError, ValidationError

_AUTH_MAP: dict[int, type[ValidationError | ForbiddenError]] = {
    400: ValidationError,
    401: ValidationError,
    403: ForbiddenError,
    422: ValidationError,
}


def _raise_auth(response: httpx.Response) -> None:
    if response.is_error:
        exc_class = _AUTH_MAP.get(response.status_code, ValidationError)
        try:
            detail = response.json().get('detail', '')
        except Exception:
            detail = ''
        raise exc_class(response.status_code, detail)


def get_token(  # noqa: PLR0913
    email: str,
    password: str,
    scopes: Sequence[str] = ['user'],
    *,
    base_url: str | None = None,
    api_path: str | None = None,
    config_file: Path | None = None,
    save_token: bool = True,
) -> str | None:
    """Obtain a JWT access token via email/password credentials.

    Configuration is resolved from three sources in priority order
    (highest to lowest): code-level arguments → ``ineepy.toml`` in the
    current directory → ``INEEPY_*`` environment variables.

    Args:
        email: User email address.
        password: User password.
        scopes: Requested scopes. Defaults to ``['user']``.
        base_url: API base URL. Defaults to config/env ``INEEPY_BASE_URL``
            (default ``https://ineep-lakehouse-prod.exe.xyz``).
        api_path: API path prefix. Defaults to config/env ``INEEPY_API_PATH``
            (default ``/api/v0``).
        config_file: Path to the TOML config file. Defaults to
            ``ineepy.toml`` in the current working directory.
        save_token: When ``True`` (default), writes ``base_url``,
            ``api_path``, and ``token`` to the config file and returns
            ``None``. When ``False``, skips writing and returns the token
            string.

    Returns:
        ``None`` when saved to config (``save_token=True``);
            the ``access_token`` string otherwise.

    """
    cfg_path = config_file or Path.cwd() / CONFIG_FILENAME
    s = load_settings(cfg_path)
    eff_base_url = base_url or s.base_url
    eff_api_path = api_path or s.api_path
    url = f'{eff_base_url}{eff_api_path}/auth/token'
    _scopes = scopes if scopes is not None else ['user']
    data = {
        'username': email,
        'password': password,
        'scope': ' '.join(_scopes),
    }
    with httpx.Client() as client:
        response = client.post(url, data=data)
    _raise_auth(response)
    try:
        token = response.json()['access_token']
    except JSONDecodeError, KeyError:
        raise ValidationError(
            response.status_code, 'Failed to extract access token'
        )
    if save_token:
        write_config(
            cfg_path,
            {
                'base_url': eff_base_url,
                'api_path': eff_api_path,
                'token': token,
            },
        )
        return None
    return token


async def async_get_token(  # noqa: PLR0913
    email: str,
    password: str,
    scopes: Sequence[str] = ['user'],
    *,
    base_url: str | None = None,
    api_path: str | None = None,
    config_file: Path | None = None,
    save_token: bool = True,
) -> str | None:
    """Async version of :func:`get_token`."""
    cfg_path = config_file or Path.cwd() / CONFIG_FILENAME
    s = load_settings(cfg_path)
    eff_base_url = base_url or s.base_url
    eff_api_path = api_path or s.api_path
    url = f'{eff_base_url}{eff_api_path}/auth/token'
    _scopes = scopes if scopes is not None else ['user']
    data = {
        'username': email,
        'password': password,
        'scope': ' '.join(_scopes),
    }
    async with httpx.AsyncClient() as client:
        response = await client.post(url, data=data)
    _raise_auth(response)
    try:
        token = response.json()['access_token']
    except JSONDecodeError, KeyError:
        raise ValidationError(
            response.status_code, 'Failed to extract access token'
        )
    if save_token:
        write_config(
            cfg_path,
            {
                'base_url': eff_base_url,
                'api_path': eff_api_path,
                'token': token,
            },
        )
        return None
    return token


async_get_token.__doc__ = get_token.__doc__
