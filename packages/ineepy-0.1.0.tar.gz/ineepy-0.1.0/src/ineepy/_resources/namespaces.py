"""Sync and async namespace resources: create, list, update, and delete."""

from __future__ import annotations

from collections.abc import Collection, Sequence

import httpx

from ineepy._models import (
    NamespaceResponse,
    NamespacesListResponse,
)
from ineepy._resources._base import AsyncBaseResource, BaseResource

_NS_URL = 'namespaces'


def _ns_body(
    title: str,
    description: str | None,
    tags: Collection[str] | None,
) -> dict:
    return {
        k: v
        for k, v in {
            'title': title,
            'description': description or '',
            'tags': list(tags) if tags is not None else None,
        }.items()
        if v is not None
    }


class NamespacesResource(BaseResource):
    """Synchronous access to the ``/namespaces`` endpoints."""

    def __init__(self, client: httpx.Client) -> None:
        super().__init__(client)

    def list(  # noqa: PLR0913
        self,
        namespace_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
        prefer: str = 'model=namespace; format=minimal',
    ) -> NamespacesListResponse:
        """List child namespaces under a parent namespace.

        Args:
            namespace_id: Parent namespace identifier (e.g. ``raw``).
            limit: Maximum number of items to return.
            offset: Number of items to skip.
            filters: Filter expressions in ``field:operator:value`` format.
            order_by: Sort expressions in ``field:direction`` format.
            prefer: ``Prefer`` header value controlling response verbosity.

        Returns:
            :class:`~ineepy.NamespacesListResponse` containing metadata and
            a list of :class:`~ineepy.NamespaceResponse` items.
        """
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = self._client.get(
            f'{_NS_URL}/{namespace_id}',
            params=params,
            headers={'Prefer': prefer},
        )
        self._raise_for_status(r)
        return NamespacesListResponse.model_validate(r.json())

    def get_metadata(self, namespace_id: str) -> tuple[NamespaceResponse, str]:
        """Return a namespace's metadata and its current ETag.

        Args:
            namespace_id: Namespace identifier.

        Returns:
            Tuple of :class:`~ineepy.NamespaceResponse` and ETag string.
        """
        r = self._client.get(f'{_NS_URL}/{namespace_id}/metadata')
        self._raise_for_status(r)
        return (
            NamespaceResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    def create(
        self,
        namespace_id: str,
        *,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
    ) -> tuple[NamespaceResponse, str]:
        """Create a new namespace.

        Args:
            namespace_id: Namespace identifier.
            title: Human-readable title.
            description: Optional description.
            tags: Optional tags.

        Returns:
            Created :class:`~ineepy.NamespaceResponse` and its ETag.

        Raises:
            ConflictError: Namespace already exists.
        """
        r = self._client.post(
            f'{_NS_URL}/{namespace_id}',
            json=_ns_body(title, description, tags),
        )
        self._raise_for_status(r)
        return (
            NamespaceResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    def update(
        self,
        namespace_id: str,
        etag: str,
        *,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
    ) -> tuple[NamespaceResponse, str]:
        """Replace a namespace's metadata.

        Args:
            namespace_id: Namespace identifier.
            etag: Current ETag from :meth:`get_metadata`
                for optimistic locking.
            title: Human-readable title.
            description: Optional description.
            tags: Optional tags.

        Returns:
            Updated :class:`~ineepy.NamespaceResponse` and new ETag.

        Raises:
            PreconditionFailedError: ETag mismatch.
        """
        r = self._client.put(
            f'{_NS_URL}/{namespace_id}',
            json=_ns_body(title, description, tags),
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return (
            NamespaceResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    def delete(self, namespace_id: str) -> None:
        """Delete an empty namespace.

        Args:
            namespace_id: Namespace identifier.

        Raises:
            ConflictError: Namespace still contains child namespaces or tables.
        """
        r = self._client.delete(f'{_NS_URL}/{namespace_id}')
        self._raise_for_status(r)


class AsyncNamespacesResource(AsyncBaseResource):
    """Async access to the ``/namespaces`` endpoints."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)

    async def list(  # noqa: PLR0913
        self,
        namespace_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
        prefer: str = 'model=namespace; format=minimal',
    ) -> NamespacesListResponse:
        """List child namespaces under ``namespace_id``."""
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = await self._client.get(
            f'{_NS_URL}/{namespace_id}',
            params=params,
            headers={'Prefer': prefer},
        )
        self._raise_for_status(r)
        return NamespacesListResponse.model_validate(r.json())

    async def get_metadata(
        self, namespace_id: str
    ) -> tuple[NamespaceResponse, str]:
        """Return a namespace's metadata and its current ETag."""
        r = await self._client.get(f'{_NS_URL}/{namespace_id}/metadata')
        self._raise_for_status(r)
        return (
            NamespaceResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    async def create(
        self,
        namespace_id: str,
        *,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
    ) -> tuple[NamespaceResponse, str]:
        """Create a new namespace."""
        r = await self._client.post(
            f'{_NS_URL}/{namespace_id}',
            json=_ns_body(title, description, tags),
        )
        self._raise_for_status(r)
        return (
            NamespaceResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    async def update(
        self,
        namespace_id: str,
        etag: str,
        *,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
    ) -> tuple[NamespaceResponse, str]:
        """Replace a namespace's metadata."""
        r = await self._client.put(
            f'{_NS_URL}/{namespace_id}',
            json=_ns_body(title, description, tags),
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return (
            NamespaceResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    async def delete(self, namespace_id: str) -> None:
        """Delete an empty namespace."""
        r = await self._client.delete(f'{_NS_URL}/{namespace_id}')
        self._raise_for_status(r)


AsyncNamespacesResource.list.__doc__ = NamespacesResource.list.__doc__
AsyncNamespacesResource.get_metadata.__doc__ = (
    NamespacesResource.get_metadata.__doc__
)
AsyncNamespacesResource.create.__doc__ = NamespacesResource.create.__doc__
AsyncNamespacesResource.update.__doc__ = NamespacesResource.update.__doc__
AsyncNamespacesResource.delete.__doc__ = NamespacesResource.delete.__doc__
