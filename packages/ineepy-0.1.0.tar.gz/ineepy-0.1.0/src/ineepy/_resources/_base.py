import httpx

from ineepy._exceptions import (
    ConflictError,
    ForbiddenError,
    HTTPError,
    NotFoundError,
    PreconditionFailedError,
    UnauthorizedError,
    ValidationError,
)

_STATUS_MAP: dict[int, type[HTTPError]] = {
    400: ValidationError,
    401: UnauthorizedError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    412: PreconditionFailedError,
    422: ValidationError,
}


class BaseResource:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        if response.is_error:
            exc_class = _STATUS_MAP.get(response.status_code, HTTPError)
            try:
                detail = response.json().get('detail', '')
            except Exception:
                detail = ''
            raise exc_class(response.status_code, detail)

    @staticmethod
    def _extract_etag(response: httpx.Response) -> str:
        return response.headers.get('ETag', '')


class AsyncBaseResource:
    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        if response.is_error:
            exc_class = _STATUS_MAP.get(response.status_code, HTTPError)
            try:
                detail = response.json().get('detail', '')
            except Exception:
                detail = ''
            raise exc_class(response.status_code, detail)

    @staticmethod
    def _extract_etag(response: httpx.Response) -> str:
        return response.headers.get('ETag', '')
